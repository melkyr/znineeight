#include "diagnostics_B9C6175E.h"
zT_F85C5DED_DiagnosticCollector zG_F85C5DED_DiagnosticCollector;
/* getLevelName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_1620F424_getLevelName(unsigned char level) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
switch (level) {
case 0: goto z_bb_1;
case 1: goto z_bb_2;
case 2: goto z_bb_3;
case 3: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_1:
    zT_2 = "error";
    zT_4 = 5;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s = zT_3;
    s = zT_3;
    s = zT_3;
    return s;
    z_bb_2:
    zT_6 = "warning";
    zT_8 = 7;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    s = zT_7;
    s = zT_7;
    s = zT_7;
    return s;
    z_bb_3:
    zT_10 = "info";
    zT_12 = 4;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    s = zT_11;
    s = zT_11;
    s = zT_11;
    return s;
    z_bb_4:
    zT_14 = "note";
    zT_16 = 4;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    s = zT_15;
    s = zT_15;
    s = zT_15;
    return s;
    z_bb_5:
    zT_18 = "unknown";
    zT_20 = 7;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    s = zT_19;
    s = zT_19;
    s = zT_19;
    return s;
    { zT_8F083A69_Slice_zT_0B42B2F8_u zT_ret_void = {0}; return zT_ret_void; }
}

/* formatU32 */
unsigned int zF_2FED9490_formatU32(unsigned int value, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    int zT_15;
    int zT_16;
    int zT_17;
    int zT_18;
    int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int v;
    unsigned int i;
    v = value;
    v = value;
    v = value;
    zT_5 = buf.len;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    i = zT_6;
    i = zT_6;
    zT_7 = 0;
    zT_8 = v == (unsigned int)zT_7;
    if (zT_8) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_9 = 1;
    zT_10 = (unsigned int)zT_9;
    zT_11 = i - zT_10;
    i = zT_11;
    i = zT_11;
    zT_12 = 48;
    zT_13 = buf.ptr;
    zT_14 = (unsigned int)i;
    zT_13[zT_14] = zT_12;
    goto z_bb_2;
    z_bb_2:
    zT_33 = buf.len;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_34 - i;
    return zT_35;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_15 = 0;
    zT_16 = v > (unsigned int)zT_15;
    if (zT_16) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = i - zT_21;
    i = zT_22;
    i = zT_22;
    zT_23 = 48;
    zT_24 = 10;
    zT_25 = v % zT_24;
    zT_26 = __bootstrap_u8_from_u32(zT_25);
    zT_27 = zT_23 + zT_26;
    zT_28 = buf.ptr;
    zT_29 = (unsigned int)i;
    zT_28[zT_29] = zT_27;
    zT_30 = 10;
    zT_31 = v / zT_30;
    v = zT_31;
    v = zT_31;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_18 = 0;
    zT_19 = i > (unsigned int)zT_18;
    zT_17 = zT_19;
    goto z_bb_10;
    z_bb_9:
    zT_17 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_17) goto z_bb_5; else goto z_bb_6;
}

/* writeStr */
void zF_76BE513B_writeStr(zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1;
    zT_1 = s;
    zF_E4B2EF19_stderr_write(zT_1);
    return;
}

/* compareDiag */
int zF_36E7146B_compareDiag(zT_50FBF81E_Diagnostic* a, zT_50FBF81E_Diagnostic* b) {
    unsigned int zT_2;
    unsigned int zT_3;
    int zT_4;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_15;
    int zT_16;
    int zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    int zT_20;
    unsigned char zT_21;
    int zT_22;
    unsigned char zT_23;
    int zT_24;
    int zT_25;
    int zT_26;
    int zT_27;
    zT_2 = a->file_id;
    zT_3 = b->file_id;
    zT_4 = zT_2 != zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = a->file_id;
    zT_6 = __bootstrap_i32_from_u32(zT_5);
    zT_7 = b->file_id;
    zT_8 = __bootstrap_i32_from_u32(zT_7);
    zT_9 = zT_6 - zT_8;
    return zT_9;
    z_bb_2:
    zT_10 = a->span_start;
    zT_11 = b->span_start;
    zT_12 = zT_10 != zT_11;
    if (zT_12) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = a->span_start;
    zT_14 = __bootstrap_i32_from_u32(zT_13);
    zT_15 = b->span_start;
    zT_16 = __bootstrap_i32_from_u32(zT_15);
    zT_17 = zT_14 - zT_16;
    return zT_17;
    z_bb_4:
    zT_18 = a->level;
    zT_19 = b->level;
    zT_20 = zT_18 != zT_19;
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_21 = a->level;
    zT_22 = (int)zT_21;
    zT_23 = b->level;
    zT_24 = (int)zT_23;
    zT_25 = zT_22 - zT_24;
    return zT_25;
    z_bb_6:
    zT_26 = 0;
    zT_27 = (int)zT_26;
    return zT_27;
}

/* sortDiagnostics */
void zF_F6BADF23_sortDiagnostics(zT_8D25846A_Slice_zT_50FBF81E_D diags) {
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_6;
    zT_50FBF81E_Diagnostic* zT_8;
    zT_50FBF81E_Diagnostic zT_9;
    int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    zT_50FBF81E_Diagnostic* zT_15;
    zT_50FBF81E_Diagnostic* zT_16;
    zT_50FBF81E_Diagnostic* zT_17;
    int zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_50FBF81E_Diagnostic* zT_21;
    zT_50FBF81E_Diagnostic* zT_22;
    int zT_23 = 0;
    int zT_24;
    int zT_25;
    zT_50FBF81E_Diagnostic* zT_26;
    int zT_27;
    int zT_28;
    unsigned int zT_29;
    zT_50FBF81E_Diagnostic zT_30;
    zT_50FBF81E_Diagnostic* zT_31;
    unsigned int zT_32;
    int zT_33;
    int zT_34;
    int zT_35;
    zT_50FBF81E_Diagnostic* zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int i;
    zT_50FBF81E_Diagnostic key;
    int j;
    zT_2 = 1;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    i = zT_3;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_5 = diags.len;
    zT_6 = i < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = diags.ptr;
    zT_9 = zT_8[i];
    key = zT_9;
    key = zT_9;
    key = zT_9;
    zT_11 = __bootstrap_i32_from_usize(i);
    j = zT_11;
    j = zT_11;
    j = zT_11;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_12 = 0;
    zT_13 = j > zT_12;
    if (zT_13) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_26 = diags.ptr;
    zT_27 = 1;
    zT_28 = j - zT_27;
    zT_29 = __bootstrap_usize_from_i32(zT_28);
    zT_30 = zT_26[zT_29];
    zT_31 = diags.ptr;
    zT_32 = __bootstrap_usize_from_i32(j);
    zT_31[zT_32] = zT_30;
    zT_33 = 1;
    zT_34 = (int)zT_33;
    zT_35 = j - zT_34;
    j = zT_35;
    j = zT_35;
    goto z_bb_8;
    z_bb_7:
    zT_36 = diags.ptr;
    zT_37 = __bootstrap_usize_from_i32(j);
    zT_36[zT_37] = key;
    zT_38 = 1;
    zT_39 = (unsigned int)zT_38;
    zT_40 = i + zT_39;
    i = zT_40;
    i = zT_40;
    goto z_bb_4;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_17 = diags.ptr;
    zT_18 = 1;
    zT_19 = j - zT_18;
    zT_20 = __bootstrap_usize_from_i32(zT_19);
    zT_21 = zT_17 + zT_20;
    zT_15 = zT_21;
    zT_22 = &key;
    zT_16 = zT_22;
    zT_23 = zF_36E7146B_compareDiag(zT_15, zT_16);
    zT_24 = 0;
    zT_25 = zT_23 > zT_24;
    zT_14 = zT_25;
    goto z_bb_11;
    z_bb_10:
    zT_14 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_14) goto z_bb_6; else goto z_bb_7;
}

/* diagnosticArrayListInit */
zT_C0B2E5AF_DiagnosticArrayList zF_D95B9309_diagnosticArrayList(zT_3E40CD83_Sand* allocator) {
    zT_C0B2E5AF_DiagnosticArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_50FBF81E_Diagnostic*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* diagnosticArrayListEnsureCapacity */
void zF_622A0C29_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    int zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_3E40CD83_Sand* zT_25;
    zT_50FBF81E_Diagnostic* zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_E637E89E_Opt_218 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_3E40CD83_Sand* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_171165BB_EU_812 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_47;
    zT_50FBF81E_Diagnostic* zT_49;
    zT_50FBF81E_Diagnostic* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_50FBF81E_Diagnostic* zT_53;
    unsigned int zT_54;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_55;
    zT_50FBF81E_Diagnostic* zT_56;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int new_cap;
    zT_E637E89E_Opt_218 grown;
    unsigned char* raw;
    zT_50FBF81E_Diagnostic* new_items;
    zT_50FBF81E_Diagnostic item;
    unsigned int i;
    zT_2 = self->capacity;
    zT_3 = new_capacity <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    new_cap = new_capacity;
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = new_cap < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    zT_13 = new_cap < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->capacity;
    zT_17 = 0;
    zT_18 = zT_16 > (unsigned int)zT_17;
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self->allocator;
    zT_20 = zT_25;
    zT_26 = self->items;
    zT_27 = (unsigned char*)zT_26;
    zT_21 = zT_27;
    zT_28 = self->capacity;
    zT_29 = 40;
    zT_30 = zT_28 * zT_29;
    zT_22 = zT_30;
    zT_31 = 40;
    zT_32 = new_cap * zT_31;
    zT_23 = zT_32;
    zT_33 = 4;
    zT_24 = zT_33;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, zT_21, zT_22, zT_23, zT_24);
    grown = zT_34;
    grown = zT_34;
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_40 = self->allocator;
    zT_37 = zT_40;
    zT_41 = 40;
    zT_42 = zT_41 * new_cap;
    zT_38 = zT_42;
    zT_43 = 4;
    zT_39 = zT_43;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, zT_38, zT_39);
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    z_bb_12:
    zT_47 = zT_44.data.payload;
    zT_46 = zT_47;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    raw = zT_46;
    raw = zT_46;
    zT_49 = (zT_50FBF81E_Diagnostic*)raw;
    new_items = zT_49;
    new_items = zT_49;
    new_items = zT_49;
    zT_50 = self->items;
    zT_51 = self->len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    zT_59 = i < zT_57;
    if (zT_59) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_61 = 1;
    zT_62 = i + zT_61;
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* diagnosticArrayListAppend */
void zF_075D71E7_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self, zT_50FBF81E_Diagnostic value) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    zT_50FBF81E_Diagnostic* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zT_6 = zT_4 + zT_5;
    zT_3 = zT_6;
    zF_622A0C29_diagnosticArrayList(zT_2, zT_3);
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    zT_11 = (unsigned int)zT_10;
    zT_12 = zT_9 + zT_11;
    self->len = zT_12;
    return;
}

/* diagnosticArrayListGetSlice */
zT_8D25846A_Slice_zT_50FBF81E_D zF_88E8322D_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self) {
    zT_50FBF81E_Diagnostic* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_50FBF81E_Diagnostic* zT_4;
    unsigned int zT_5;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* diagnosticCollectorInit */
zT_F85C5DED_DiagnosticCollector zF_C7BA7DAB_diagnosticCollector(zT_3E40CD83_Sand* allocator, zT_227EDE07_SourceManager* source_manager, zT_D3EB6303_StringInterner* interner) {
    zT_3E40CD83_Sand* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_171165BB_EU_812 zT_9 = {0};
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned char* zT_12;
    zT_C0B2E5AF_DiagnosticArrayList* zT_14;
    zT_3E40CD83_Sand* zT_15;
    zT_C0B2E5AF_DiagnosticArrayList zT_16 = {0};
    zT_F85C5DED_DiagnosticCollector zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char* d_raw;
    zT_C0B2E5AF_DiagnosticArrayList* d_ptr;
    zT_4 = allocator;
    zT_7 = 16;
    zT_5 = zT_7;
    zT_8 = 4;
    zT_6 = zT_8;
    zT_9 = zF_1395EB68_sandAlloc(zT_4, zT_5, zT_6);
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_12 = zT_9.data.payload;
    zT_11 = zT_12;
    goto z_bb_3;
    z_bb_3:
    d_raw = zT_11;
    d_raw = zT_11;
    d_raw = zT_11;
    zT_14 = (zT_C0B2E5AF_DiagnosticArrayList*)d_raw;
    d_ptr = zT_14;
    d_ptr = zT_14;
    d_ptr = zT_14;
    zT_15 = allocator;
    zT_16 = zF_D95B9309_diagnosticArrayList(zT_15);
    *d_ptr = zT_16;
    zT_17.diagnostics = d_ptr;
    zT_18 = 0;
    zT_17.related_span_items = (zT_B258D528_RelatedSpan*)zT_18;
    zT_19 = 0;
    zT_17.related_span_len = zT_19;
    zT_20 = 0;
    zT_17.related_span_cap = zT_20;
    zT_17.allocator = allocator;
    zT_17.source_manager = source_manager;
    zT_17.interner = interner;
    zT_21 = 0;
    zT_17.error_count = zT_21;
    zT_22 = 0;
    zT_17.warning_count = zT_22;
    zT_23 = 256;
    zT_17.max_diagnostics = zT_23;
    return zT_17;
}

/* diagnosticCollectorIntern */
unsigned int zF_14631FFD_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_D3EB6303_StringInterner* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5 = 0;
    zT_4 = self->interner;
    zT_2 = zT_4;
    zT_3 = msg;
    zT_5 = zF_50C274AF_stringInternerInter(zT_2, zT_3);
    return zT_5;
}

/* diagnosticCollectorAdd */
unsigned int zF_C82559AC_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned char level, unsigned short code, unsigned int file_id, unsigned int span_start, unsigned int span_end, zT_8F083A69_Slice_zT_0B42B2F8_u message) {
    int zT_7;
    int zT_8;
    unsigned int zT_9;
    zT_C0B2E5AF_DiagnosticArrayList* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_D3EB6303_StringInterner* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_D3EB6303_StringInterner* zT_21;
    unsigned int zT_22 = 0;
    zT_C0B2E5AF_DiagnosticArrayList* zT_23;
    zT_50FBF81E_Diagnostic zT_24;
    zT_C0B2E5AF_DiagnosticArrayList* zT_25;
    zT_50FBF81E_Diagnostic zT_26;
    unsigned char zT_27;
    unsigned short zT_28;
    unsigned char zT_29;
    unsigned short zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_D3EB6303_StringInterner* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_D3EB6303_StringInterner* zT_46;
    unsigned int zT_47 = 0;
    zT_C0B2E5AF_DiagnosticArrayList* zT_48;
    zT_50FBF81E_Diagnostic zT_49;
    zT_C0B2E5AF_DiagnosticArrayList* zT_50;
    zT_50FBF81E_Diagnostic zT_51;
    unsigned char zT_52;
    unsigned short zT_60;
    int zT_61;
    int zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    int zT_67;
    int zT_68;
    unsigned int zT_69;
    int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_C0B2E5AF_DiagnosticArrayList* zT_73;
    unsigned int zT_74;
    int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u overflow_msg;
    unsigned int msg_id;
    zT_7 = 9999;
    zT_8 = code == zT_7;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 0;
    return zT_9;
    z_bb_2:
    zT_10 = self->diagnostics;
    zT_11 = zT_10->len;
    zT_12 = self->max_diagnostics;
    zT_13 = zT_11 >= zT_12;
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = "too many errors, stopping";
    zT_17 = 25;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    overflow_msg = zT_16;
    overflow_msg = zT_16;
    overflow_msg = zT_16;
    zT_21 = self->interner;
    zT_19 = zT_21;
    zT_20 = overflow_msg;
    zT_22 = zF_50C274AF_stringInternerInter(zT_19, zT_20);
    msg_id = zT_22;
    msg_id = zT_22;
    msg_id = zT_22;
    zT_25 = self->diagnostics;
    zT_23 = zT_25;
    zT_27 = 0;
    zT_26.level = zT_27;
    zT_28 = 9999;
    zT_26.code = zT_28;
    zT_26.file_id = file_id;
    zT_26.span_start = span_start;
    zT_26.span_end = span_end;
    zT_26.message_id = msg_id;
    zT_29 = 0;
    zT_26.note_count = zT_29;
    (void)zT_26.note_ids;
    {
    unsigned int _j = 0;
    while (_j < 3) {
        zT_26.note_ids[_j] = 0;
        _j++;
    }
}
    zT_37 = 0;
    zT_26.related_span_idx = zT_37;
    zT_24 = zT_26;
    zF_075D71E7_diagnosticArrayList(zT_23, zT_24);
    zT_38 = self->error_count;
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    zT_41 = zT_38 + zT_40;
    self->error_count = zT_41;
    zT_42 = 0;
    return zT_42;
    z_bb_4:
    zT_46 = self->interner;
    zT_44 = zT_46;
    zT_45 = message;
    zT_47 = zF_50C274AF_stringInternerInter(zT_44, zT_45);
    msg_id = zT_47;
    msg_id = zT_47;
    msg_id = zT_47;
    zT_50 = self->diagnostics;
    zT_48 = zT_50;
    zT_51.level = level;
    zT_51.code = code;
    zT_51.file_id = file_id;
    zT_51.span_start = span_start;
    zT_51.span_end = span_end;
    zT_51.message_id = msg_id;
    zT_52 = 0;
    zT_51.note_count = zT_52;
    (void)zT_51.note_ids;
    {
    unsigned int _j = 0;
    while (_j < 3) {
        zT_51.note_ids[_j] = 0;
        _j++;
    }
}
    zT_60 = 0;
    zT_51.related_span_idx = zT_60;
    zT_49 = zT_51;
    zF_075D71E7_diagnosticArrayList(zT_48, zT_49);
    zT_61 = 0;
    zT_62 = level == zT_61;
    if (zT_62) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_63 = self->error_count;
    zT_64 = 1;
    zT_65 = (unsigned int)zT_64;
    zT_66 = zT_63 + zT_65;
    self->error_count = zT_66;
    goto z_bb_6;
    z_bb_6:
    zT_73 = self->diagnostics;
    zT_74 = zT_73->len;
    zT_75 = 1;
    zT_76 = zT_74 - zT_75;
    zT_77 = (unsigned int)zT_76;
    return zT_77;
    z_bb_7:
    zT_67 = 1;
    zT_68 = level == zT_67;
    if (zT_68) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_69 = self->warning_count;
    zT_70 = 1;
    zT_71 = (unsigned int)zT_70;
    zT_72 = zT_69 + zT_71;
    self->warning_count = zT_72;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
}

/* diagnosticCollectorHasErrors */
int zF_8F770780_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    int zT_2;
    int zT_3;
    zT_1 = self->error_count;
    zT_2 = 0;
    zT_3 = zT_1 > (unsigned int)zT_2;
    return zT_3;
}

/* diagnosticCollectorErrorCount */
unsigned int zF_4BDFF7E0_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    zT_1 = self->error_count;
    zT_2 = (unsigned int)zT_1;
    return zT_2;
}

/* diagnosticCollectorWarningCount */
unsigned int zF_4AF2092E_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    unsigned int zT_2;
    zT_1 = self->warning_count;
    zT_2 = (unsigned int)zT_1;
    return zT_2;
}

/* diagnosticCollectorAddNote */
void zF_426E1F18_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int diag_idx, zT_8F083A69_Slice_zT_0B42B2F8_u note) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_C0B2E5AF_DiagnosticArrayList* zT_8;
    zT_50FBF81E_Diagnostic* zT_9;
    unsigned int zT_10;
    zT_50FBF81E_Diagnostic* zT_11;
    unsigned char zT_12;
    int zT_13;
    int zT_14;
    zT_D3EB6303_StringInterner* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_D3EB6303_StringInterner* zT_17;
    unsigned int zT_18 = 0;
    unsigned int* zT_19;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned char zT_22;
    int zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    zT_50FBF81E_Diagnostic* d;
    zT_3 = self->diagnostics;
    zT_4 = zT_3->len;
    zT_5 = (unsigned int)zT_4;
    zT_6 = diag_idx >= zT_5;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->diagnostics;
    zT_9 = zT_8->items;
    zT_10 = (unsigned int)diag_idx;
    zT_11 = zT_9 + zT_10;
    d = zT_11;
    d = zT_11;
    d = zT_11;
    zT_12 = d->note_count;
    zT_13 = 3;
    zT_14 = zT_12 < zT_13;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = self->interner;
    zT_15 = zT_17;
    zT_16 = note;
    zT_18 = zF_50C274AF_stringInternerInter(zT_15, zT_16);
    zT_19 = d->note_ids;
    zT_20 = d->note_count;
    zT_21 = (unsigned int)zT_20;
    zT_19[zT_21] = zT_18;
    zT_22 = d->note_count;
    zT_23 = 1;
    zT_24 = (unsigned char)zT_23;
    zT_25 = zT_22 + zT_24;
    d->note_count = zT_25;
    goto z_bb_4;
    z_bb_4:
    return;
}

/* diagnosticCollectorAddRelatedSpan */
void zF_A9049B03_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int diag_idx, unsigned int file_id, unsigned int span_start, unsigned int span_end, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    int zT_9;
    zT_D3EB6303_StringInterner* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_D3EB6303_StringInterner* zT_13;
    unsigned int zT_14 = 0;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_24;
    int zT_25;
    int zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    int zT_30;
    int zT_31;
    zT_3E40CD83_Sand* zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_3E40CD83_Sand* zT_38;
    zT_B258D528_RelatedSpan* zT_39;
    unsigned char* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_E637E89E_Opt_218 zT_47 = {0};
    unsigned char zT_48;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_3E40CD83_Sand* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_3E40CD83_Sand* zT_56;
    unsigned int zT_57;
    zT_171165BB_EU_812 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    unsigned char* zT_61;
    zT_B258D528_RelatedSpan* zT_63;
    zT_B258D528_RelatedSpan* zT_64;
    unsigned int zT_65;
    int zT_66;
    zT_B258D528_RelatedSpan* zT_67;
    unsigned int zT_68;
    zT_1E07C3E5_Slice_zT_B258D528_R zT_69;
    zT_B258D528_RelatedSpan* zT_70;
    unsigned int zT_71;
    int zT_73;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_3E40CD83_Sand* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_3E40CD83_Sand* zT_84;
    unsigned int zT_85;
    zT_171165BB_EU_812 zT_86 = {0};
    unsigned char zT_87;
    unsigned char* zT_88;
    unsigned char* zT_89;
    zT_B258D528_RelatedSpan* zT_91;
    zT_B258D528_RelatedSpan* zT_92;
    unsigned int zT_93;
    int zT_94;
    zT_B258D528_RelatedSpan* zT_95;
    unsigned int zT_96;
    zT_1E07C3E5_Slice_zT_B258D528_R zT_97;
    zT_B258D528_RelatedSpan* zT_98;
    unsigned int zT_99;
    int zT_101;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_B258D528_RelatedSpan zT_105;
    zT_B258D528_RelatedSpan* zT_106;
    unsigned int zT_107;
    unsigned int zT_109;
    unsigned short zT_110;
    unsigned int zT_111;
    int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_C0B2E5AF_DiagnosticArrayList* zT_115;
    zT_50FBF81E_Diagnostic* zT_116;
    unsigned int zT_117;
    zT_50FBF81E_Diagnostic* zT_118;
    unsigned int msg_id;
    unsigned int new_len;
    unsigned int new_cap;
    unsigned short rs_idx;
    zT_E637E89E_Opt_218 grown;
    unsigned int sz;
    unsigned char* raw;
    zT_B258D528_RelatedSpan* items;
    zT_B258D528_RelatedSpan item;
    unsigned int i;
    zT_B258D528_RelatedSpan item_1;
    unsigned int i_2;
    zT_6 = self->diagnostics;
    zT_7 = zT_6->len;
    zT_8 = (unsigned int)zT_7;
    zT_9 = diag_idx >= zT_8;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = self->interner;
    zT_11 = zT_13;
    zT_12 = msg;
    zT_14 = zF_50C274AF_stringInternerInter(zT_11, zT_12);
    msg_id = zT_14;
    msg_id = zT_14;
    msg_id = zT_14;
    zT_16 = self->related_span_len;
    zT_17 = 1;
    zT_18 = zT_16 + zT_17;
    new_len = zT_18;
    new_len = zT_18;
    new_len = zT_18;
    zT_19 = self->related_span_cap;
    zT_20 = new_len >= zT_19;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_22 = self->related_span_cap;
    zT_23 = 2;
    zT_24 = zT_22 * zT_23;
    new_cap = zT_24;
    new_cap = zT_24;
    new_cap = zT_24;
    zT_25 = 8;
    zT_26 = new_cap < (unsigned int)zT_25;
    if (zT_26) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_105.span_file_id = file_id;
    zT_105.span_start = span_start;
    zT_105.span_end = span_end;
    zT_105.message_id = msg_id;
    zT_106 = self->related_span_items;
    zT_107 = self->related_span_len;
    zT_106[zT_107] = zT_105;
    zT_109 = self->related_span_len;
    zT_110 = (unsigned short)zT_109;
    rs_idx = zT_110;
    rs_idx = zT_110;
    rs_idx = zT_110;
    zT_111 = self->related_span_len;
    zT_112 = 1;
    zT_113 = (unsigned int)zT_112;
    zT_114 = zT_111 + zT_113;
    self->related_span_len = zT_114;
    zT_115 = self->diagnostics;
    zT_116 = zT_115->items;
    zT_117 = (unsigned int)diag_idx;
    zT_118 = zT_116 + zT_117;
    zT_118->related_span_idx = rs_idx;
    return;
    z_bb_5:
    zT_27 = 8;
    zT_28 = (unsigned int)zT_27;
    new_cap = zT_28;
    new_cap = zT_28;
    goto z_bb_6;
    z_bb_6:
    zT_29 = self->related_span_cap;
    zT_30 = 0;
    zT_31 = zT_29 > (unsigned int)zT_30;
    if (zT_31) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_38 = self->allocator;
    zT_33 = zT_38;
    zT_39 = self->related_span_items;
    zT_40 = (unsigned char*)zT_39;
    zT_34 = zT_40;
    zT_41 = self->related_span_cap;
    zT_42 = 16;
    zT_43 = zT_41 * zT_42;
    zT_35 = zT_43;
    zT_44 = 16;
    zT_45 = new_cap * zT_44;
    zT_36 = zT_45;
    zT_46 = 4;
    zT_37 = zT_46;
    zT_47 = zF_33A3D4F8_sandTryReallocInPla(zT_33, zT_34, zT_35, zT_36, zT_37);
    grown = zT_47;
    grown = zT_47;
    grown = zT_47;
    zT_48 = grown.has_value;
    if (zT_48) goto z_bb_10; else goto z_bb_12;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_78 = 16;
    zT_79 = zT_78 * new_cap;
    sz = zT_79;
    sz = zT_79;
    sz = zT_79;
    zT_84 = self->allocator;
    zT_81 = zT_84;
    zT_82 = sz;
    zT_85 = 4;
    zT_83 = zT_85;
    zT_86 = zF_1395EB68_sandAlloc(zT_81, zT_82, zT_83);
    zT_87 = zT_86.is_error;
    if (zT_87) goto z_bb_19; else goto z_bb_20;
    z_bb_10:
    self->related_span_cap = new_cap;
    goto z_bb_11;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_50 = 16;
    zT_51 = zT_50 * new_cap;
    sz = zT_51;
    sz = zT_51;
    sz = zT_51;
    zT_56 = self->allocator;
    zT_53 = zT_56;
    zT_54 = sz;
    zT_57 = 4;
    zT_55 = zT_57;
    zT_58 = zF_1395EB68_sandAlloc(zT_53, zT_54, zT_55);
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    z_bb_14:
    zT_61 = zT_58.data.payload;
    zT_60 = zT_61;
    goto z_bb_15;
    z_bb_15:
    raw = zT_60;
    raw = zT_60;
    raw = zT_60;
    zT_63 = (zT_B258D528_RelatedSpan*)raw;
    items = zT_63;
    items = zT_63;
    items = zT_63;
    zT_64 = self->related_span_items;
    zT_65 = self->related_span_len;
    zT_66 = 0;
    zT_67 = zT_64 + zT_66;
    zT_68 = zT_65 - zT_66;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_70 = zT_69.ptr;
    zT_71 = zT_69.len;
    i = 0;
    goto z_bb_16;
    z_bb_16:
    zT_73 = i < zT_71;
    if (zT_73) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    item = zT_70[i];
    items[i] = item;
    zT_75 = 1;
    zT_76 = i + zT_75;
    i = zT_76;
    goto z_bb_16;
    z_bb_18:
    self->related_span_items = items;
    self->related_span_cap = new_cap;
    goto z_bb_11;
    z_bb_19:
    z_bb_20:
    zT_89 = zT_86.data.payload;
    zT_88 = zT_89;
    goto z_bb_21;
    z_bb_21:
    raw = zT_88;
    raw = zT_88;
    raw = zT_88;
    zT_91 = (zT_B258D528_RelatedSpan*)raw;
    items = zT_91;
    items = zT_91;
    items = zT_91;
    zT_92 = self->related_span_items;
    zT_93 = self->related_span_len;
    zT_94 = 0;
    zT_95 = zT_92 + zT_94;
    zT_96 = zT_93 - zT_94;
    zT_97.ptr = zT_95;
    zT_97.len = zT_96;
    zT_98 = zT_97.ptr;
    zT_99 = zT_97.len;
    i_2 = 0;
    goto z_bb_22;
    z_bb_22:
    zT_101 = i_2 < zT_99;
    if (zT_101) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    item_1 = zT_98[i_2];
    items[i_2] = item_1;
    zT_103 = 1;
    zT_104 = i_2 + zT_103;
    i_2 = zT_104;
    goto z_bb_22;
    z_bb_24:
    self->related_span_items = items;
    self->related_span_cap = new_cap;
    goto z_bb_8;
}

/* diagnosticCollectorFlushAndExit */
void zF_E7E26C7E_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int exit_code) {
    zT_F85C5DED_DiagnosticCollector* zT_2;
    unsigned char zT_3;
    unsigned char zT_4;
    zT_2 = self;
    zF_8E894A93_diagnosticCollector(zT_2);
    zT_4 = __bootstrap_u8_from_u32(exit_code);
    zT_3 = zT_4;
    zF_CDED1A85_exit(zT_3);
    return;
}

/* diagnosticBuilderMakeMsg */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8C4BFF7C_diagnosticBuilderMa(zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u* parts, unsigned int count) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    zT_3E40CD83_Sand* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_21;
    int zT_22;
    unsigned int zT_23;
    zT_171165BB_EU_812 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    unsigned char* zT_31;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_41;
    int zT_42;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_50;
    int zT_51;
    unsigned char* zT_52;
    unsigned char zT_53;
    unsigned char* zT_54;
    int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    zT_D3EB6303_StringInterner* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65 = 0;
    zT_D3EB6303_StringInterner* zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68 = {0};
    unsigned int total;
    unsigned int ci;
    unsigned char* raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u fallback;
    zT_8F083A69_Slice_zT_0B42B2F8_u buf;
    unsigned int pos;
    zT_8F083A69_Slice_zT_0B42B2F8_u part;
    unsigned int pi;
    unsigned int sid;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    total = zT_5;
    total = zT_5;
    total = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ci = zT_8;
    ci = zT_8;
    ci = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_9 = ci < count;
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = (unsigned int)ci;
    zT_11 = parts[zT_10];
    zT_13 = zT_11.len;
    zT_14 = total + zT_13;
    total = zT_14;
    total = zT_14;
    goto z_bb_4;
    z_bb_3:
    zT_21 = interner->allocator;
    zT_18 = zT_21;
    zT_19 = total;
    zT_22 = 1;
    zT_23 = (unsigned int)zT_22;
    zT_20 = zT_23;
    zT_24 = zF_1395EB68_sandAlloc(zT_18, zT_19, zT_20);
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_15 = 1;
    zT_16 = ci + zT_15;
    ci = zT_16;
    ci = zT_16;
    goto z_bb_1;
    z_bb_5:
    zT_28 = "diagnostic message too long";
    zT_30 = 27;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    fallback = zT_29;
    fallback = zT_29;
    fallback = zT_29;
    return fallback;
    z_bb_6:
    zT_31 = zT_24.data.payload;
    zT_26 = zT_31;
    goto z_bb_7;
    z_bb_7:
    raw = zT_26;
    raw = zT_26;
    raw = zT_26;
    zT_33 = 0;
    zT_34 = raw + zT_33;
    zT_35 = total - zT_33;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    buf = zT_36;
    buf = zT_36;
    buf = zT_36;
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    pos = zT_39;
    pos = zT_39;
    pos = zT_39;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    ci = zT_41;
    ci = zT_41;
    goto z_bb_8;
    z_bb_8:
    zT_42 = ci < count;
    if (zT_42) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_44 = (unsigned int)ci;
    zT_45 = parts[zT_44];
    part = zT_45;
    part = zT_45;
    part = zT_45;
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    pi = zT_48;
    pi = zT_48;
    pi = zT_48;
    goto z_bb_12;
    z_bb_10:
    zT_63 = interner;
    zT_64 = buf;
    zT_65 = zF_50C274AF_stringInternerInter(zT_63, zT_64);
    sid = zT_65;
    sid = zT_65;
    sid = zT_65;
    zT_66 = interner;
    zT_67 = sid;
    zT_68 = zF_9134020D_stringInternerGet(zT_66, zT_67);
    return zT_68;
    z_bb_11:
    zT_60 = 1;
    zT_61 = ci + zT_60;
    ci = zT_61;
    ci = zT_61;
    goto z_bb_8;
    z_bb_12:
    zT_50 = part.len;
    zT_51 = pi < zT_50;
    if (zT_51) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_52 = part.ptr;
    zT_53 = zT_52[pi];
    zT_54 = buf.ptr;
    zT_54[pos] = zT_53;
    zT_55 = 1;
    zT_56 = (unsigned int)zT_55;
    zT_57 = pos + zT_56;
    pos = zT_57;
    pos = zT_57;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_58 = 1;
    zT_59 = pi + zT_58;
    pi = zT_59;
    pi = zT_59;
    goto z_bb_12;
}

/* diagnosticCollectorPrintAll */
void zF_8E894A93_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_1;
    unsigned int zT_2;
    int zT_3;
    int zT_4;
    zT_C0B2E5AF_DiagnosticArrayList* zT_6;
    zT_C0B2E5AF_DiagnosticArrayList* zT_7;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_8 = {0};
    zT_8D25846A_Slice_zT_50FBF81E_D zT_9;
    int zT_11;
    unsigned int zT_12;
    zT_C0B2E5AF_DiagnosticArrayList* zT_13;
    unsigned int zT_14;
    int zT_15;
    zT_50FBF81E_Diagnostic* zT_17;
    zT_50FBF81E_Diagnostic* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25 = {0};
    char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_C1AB0454_Arr_unsigned_char_8 zT_32;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned short zT_36;
    unsigned int zT_37;
    unsigned char* zT_38;
    int zT_40;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45 = 0;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned char* zT_51;
    unsigned int zT_53;
    unsigned char* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    int zT_64;
    zT_D3EB6303_StringInterner* zT_66;
    zT_EABC94D3_InternEntry* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_EABC94D3_InternEntry zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    zT_227EDE07_SourceManager* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_227EDE07_SourceManager* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_5BC08DC6_Location zT_88 = {0};
    zT_227EDE07_SourceManager* zT_90;
    unsigned int zT_91;
    zT_227EDE07_SourceManager* zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    zT_5426B97B_Arr_unsigned_char_1 zT_102;
    unsigned int zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    unsigned char* zT_107;
    int zT_109;
    int zT_110;
    unsigned char* zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114 = 0;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char* zT_120;
    unsigned int zT_122;
    unsigned char* zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    char* zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    zT_5426B97B_Arr_unsigned_char_1 zT_132;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    unsigned char* zT_137;
    int zT_139;
    int zT_140;
    unsigned char* zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144 = 0;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned char* zT_150;
    unsigned int zT_152;
    unsigned char* zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    char* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned char zT_162;
    unsigned char zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164 = {0};
    char* zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    zT_C1AB0454_Arr_unsigned_char_8 zT_171;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned short zT_175;
    unsigned int zT_176;
    unsigned char* zT_177;
    int zT_179;
    int zT_180;
    unsigned char* zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184 = 0;
    unsigned int zT_186;
    unsigned int zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned char* zT_190;
    unsigned int zT_192;
    unsigned char* zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    char* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    int zT_203;
    zT_D3EB6303_StringInterner* zT_205;
    zT_EABC94D3_InternEntry* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    zT_EABC94D3_InternEntry zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    zT_227EDE07_SourceManager* zT_223;
    unsigned int zT_224;
    zT_227EDE07_SourceManager* zT_225;
    unsigned int zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227 = {0};
    zT_227EDE07_SourceManager* zT_229;
    unsigned int zT_230;
    zT_227EDE07_SourceManager* zT_231;
    unsigned int zT_232;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_233 = {0};
    zT_3CB0179A_Slice_zT_05F374B1_u zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238 = 0;
    int zT_239;
    int zT_240;
    int zT_241;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned int* zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned int zT_248;
    unsigned int zT_251;
    int zT_253;
    unsigned int zT_254;
    unsigned int zT_256;
    unsigned int zT_257;
    int zT_258;
    unsigned int* zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned int zT_262;
    int zT_263;
    int zT_264;
    int zT_265;
    unsigned char* zT_266;
    int zT_267;
    unsigned int zT_268;
    unsigned char zT_269;
    unsigned char zT_270;
    int zT_271;
    int zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    int zT_277;
    int zT_278;
    unsigned int zT_280;
    int zT_281;
    unsigned char* zT_283;
    unsigned char* zT_285;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_298;
    unsigned int zT_299;
    unsigned int zT_300;
    unsigned int zT_301;
    int zT_302;
    int zT_303;
    int zT_304;
    unsigned int zT_305;
    zT_22590979_Arr_unsigned_char_2 zT_307;
    int zT_309;
    unsigned int zT_310;
    int zT_312;
    int zT_313;
    int zT_314;
    unsigned int zT_315;
    int zT_317;
    unsigned char zT_318;
    int zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    unsigned int zT_322;
    unsigned int zT_323;
    int zT_325;
    unsigned int zT_326;
    int zT_327;
    int zT_328;
    unsigned int zT_329;
    int zT_331;
    unsigned int zT_332;
    int zT_333;
    int zT_334;
    unsigned int zT_335;
    int zT_337;
    unsigned char zT_338;
    int zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned char* zT_345;
    int zT_347;
    unsigned char* zT_348;
    unsigned int zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    char* zT_352;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_353;
    unsigned int zT_354;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_355;
    int zT_357;
    unsigned char zT_358;
    unsigned char zT_359;
    int zT_360;
    char* zT_362;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_363;
    unsigned int zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    zT_D3EB6303_StringInterner* zT_367;
    zT_EABC94D3_InternEntry* zT_368;
    unsigned int* zT_369;
    unsigned int zT_370;
    unsigned int zT_371;
    unsigned int zT_372;
    zT_EABC94D3_InternEntry zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    char* zT_377;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_378;
    unsigned int zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380;
    int zT_381;
    unsigned char zT_382;
    unsigned char zT_383;
    unsigned short zT_384;
    int zT_385;
    int zT_386;
    int zT_387;
    unsigned short zT_388;
    unsigned int zT_389;
    unsigned short zT_390;
    int zT_391;
    zT_B258D528_RelatedSpan* zT_393;
    unsigned short zT_394;
    unsigned int zT_395;
    zT_B258D528_RelatedSpan zT_396;
    zT_227EDE07_SourceManager* zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    zT_227EDE07_SourceManager* zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    zT_5BC08DC6_Location zT_404 = {0};
    zT_227EDE07_SourceManager* zT_406;
    unsigned int zT_407;
    zT_227EDE07_SourceManager* zT_408;
    unsigned int zT_409;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_410 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    char* zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_414;
    unsigned int zT_415;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    zT_5426B97B_Arr_unsigned_char_1 zT_418;
    unsigned int zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421;
    unsigned int zT_422;
    unsigned char* zT_423;
    int zT_425;
    int zT_426;
    unsigned char* zT_427;
    unsigned int zT_428;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_429;
    unsigned int zT_430 = 0;
    unsigned int zT_432;
    unsigned int zT_433;
    unsigned int zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned char* zT_436;
    unsigned int zT_438;
    unsigned char* zT_439;
    unsigned int zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_441;
    char* zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_444;
    unsigned int zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    zT_D3EB6303_StringInterner* zT_448;
    zT_EABC94D3_InternEntry* zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    zT_EABC94D3_InternEntry zT_452;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_454;
    char* zT_456;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_457;
    unsigned int zT_458;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459;
    int zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    zT_8D25846A_Slice_zT_50FBF81E_D diags;
    unsigned int i;
    zT_50FBF81E_Diagnostic* d;
    zT_8F083A69_Slice_zT_0B42B2F8_u lb0;
    zT_C1AB0454_Arr_unsigned_char_8 code_buf0;
    unsigned int code_len0;
    unsigned int kcs0;
    zT_8F083A69_Slice_zT_0B42B2F8_u rb0;
    zT_5BC08DC6_Location loc;
    zT_8F083A69_Slice_zT_0B42B2F8_u fname;
    zT_8F083A69_Slice_zT_0B42B2F8_u col_s;
    zT_5426B97B_Arr_unsigned_char_1 line_buf;
    unsigned int line_len;
    unsigned int ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u col_s2;
    zT_5426B97B_Arr_unsigned_char_1 col_buf;
    unsigned int col_len;
    unsigned int cs;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep;
    zT_8F083A69_Slice_zT_0B42B2F8_u lb;
    zT_C1AB0454_Arr_unsigned_char_8 code_buf;
    unsigned int code_len;
    unsigned int kcs;
    zT_8F083A69_Slice_zT_0B42B2F8_u rb;
    zT_EABC94D3_InternEntry entry0;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl0;
    zT_EABC94D3_InternEntry entry;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    zT_3CB0179A_Slice_zT_05F374B1_u offsets;
    unsigned int line_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    unsigned int line_start;
    unsigned int line_end;
    unsigned int next_line;
    unsigned int l_start;
    unsigned int l_end;
    zT_8F083A69_Slice_zT_0B42B2F8_u line_text;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl2;
    unsigned int loc_col;
    unsigned int cspan;
    unsigned char n;
    zT_22590979_Arr_unsigned_char_2 caret_buf;
    unsigned int caret_len;
    unsigned int space_count;
    unsigned int _;
    unsigned int ulen;
    unsigned int max_carets;
    unsigned int __1;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl3;
    zT_8F083A69_Slice_zT_0B42B2F8_u note_hdr;
    zT_EABC94D3_InternEntry note_entry;
    zT_8F083A69_Slice_zT_0B42B2F8_u note_nl;
    zT_B258D528_RelatedSpan rs;
    zT_5BC08DC6_Location rs_loc;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_fname;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_col_s;
    zT_5426B97B_Arr_unsigned_char_1 rs_line_buf;
    unsigned int rs_line_len;
    unsigned int rls;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_sep;
    zT_EABC94D3_InternEntry rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_nl;
    zT_1 = self->diagnostics;
    zT_2 = zT_1->len;
    zT_3 = 0;
    zT_4 = zT_2 == (unsigned int)zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = self->diagnostics;
    zT_6 = zT_7;
    zT_8 = zF_88E8322D_diagnosticArrayList(zT_6);
    diags = zT_8;
    diags = zT_8;
    diags = zT_8;
    zT_9 = diags;
    zF_F6BADF23_sortDiagnostics(zT_9);
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    i = zT_12;
    i = zT_12;
    i = zT_12;
    goto z_bb_3;
    z_bb_3:
    zT_13 = self->diagnostics;
    zT_14 = zT_13->len;
    zT_15 = i < zT_14;
    if (zT_15) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = diags.ptr;
    zT_18 = zT_17 + i;
    d = zT_18;
    d = zT_18;
    d = zT_18;
    zT_19 = d->file_id;
    zT_20 = 0;
    zT_21 = zT_19 == zT_20;
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_24 = d->level;
    zT_23 = zT_24;
    zT_25 = zF_1620F424_getLevelName(zT_23);
    zT_22 = zT_25;
    zF_76BE513B_writeStr(zT_22);
    zT_27 = "[";
    zT_29 = 1;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    lb0 = zT_28;
    lb0 = zT_28;
    lb0 = zT_28;
    zT_30 = lb0;
    zF_76BE513B_writeStr(zT_30);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_32[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        code_buf0[_i] = zT_32[_i];
        _i++;
    }
}
    zT_36 = d->code;
    zT_37 = (unsigned int)zT_36;
    zT_34 = zT_37;
    zT_38 = (unsigned char*)code_buf0;
    zT_40 = 8;
    zT_41 = 0;
    zT_42 = zT_38 + zT_41;
    zT_43 = zT_40 - zT_41;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    zT_35 = zT_44;
    zT_45 = zF_2FED9490_formatU32(zT_34, zT_35);
    code_len0 = zT_45;
    code_len0 = zT_45;
    code_len0 = zT_45;
    zT_47 = 8;
    zT_48 = (unsigned int)code_len0;
    zT_49 = zT_47 - zT_48;
    kcs0 = zT_49;
    kcs0 = zT_49;
    kcs0 = zT_49;
    zT_51 = (unsigned char*)code_buf0;
    zT_53 = 8;
    zT_54 = zT_51 + kcs0;
    zT_55 = zT_53 - kcs0;
    zT_56.ptr = zT_54;
    zT_56.len = zT_55;
    zT_50 = zT_56;
    zF_76BE513B_writeStr(zT_50);
    zT_58 = "]: ";
    zT_60 = 3;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    rb0 = zT_59;
    rb0 = zT_59;
    rb0 = zT_59;
    zT_61 = rb0;
    zF_76BE513B_writeStr(zT_61);
    zT_62 = d->message_id;
    zT_63 = 0;
    zT_64 = zT_62 != zT_63;
    if (zT_64) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_85 = self->source_manager;
    zT_82 = zT_85;
    zT_86 = d->file_id;
    zT_83 = zT_86;
    zT_87 = d->span_start;
    zT_84 = zT_87;
    zT_88 = zF_4966CE4A_sourceManagerGetLoc(zT_82, zT_83, zT_84);
    loc = zT_88;
    loc = zT_88;
    loc = zT_88;
    zT_92 = self->source_manager;
    zT_90 = zT_92;
    zT_93 = d->file_id;
    zT_91 = zT_93;
    zT_94 = zF_B7076474_sourceManagerGetFil(zT_90, zT_91);
    fname = zT_94;
    fname = zT_94;
    fname = zT_94;
    zT_95 = fname;
    zF_76BE513B_writeStr(zT_95);
    zT_97 = ":";
    zT_99 = 1;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    col_s = zT_98;
    col_s = zT_98;
    col_s = zT_98;
    zT_100 = col_s;
    zF_76BE513B_writeStr(zT_100);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_102[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        line_buf[_i] = zT_102[_i];
        _i++;
    }
}
    zT_106 = loc.line;
    zT_104 = zT_106;
    zT_107 = (unsigned char*)line_buf;
    zT_109 = 16;
    zT_110 = 0;
    zT_111 = zT_107 + zT_110;
    zT_112 = zT_109 - zT_110;
    zT_113.ptr = zT_111;
    zT_113.len = zT_112;
    zT_105 = zT_113;
    zT_114 = zF_2FED9490_formatU32(zT_104, zT_105);
    line_len = zT_114;
    line_len = zT_114;
    line_len = zT_114;
    zT_116 = 16;
    zT_117 = (unsigned int)line_len;
    zT_118 = zT_116 - zT_117;
    ls = zT_118;
    ls = zT_118;
    ls = zT_118;
    zT_120 = (unsigned char*)line_buf;
    zT_122 = 16;
    zT_123 = zT_120 + ls;
    zT_124 = zT_122 - ls;
    zT_125.ptr = zT_123;
    zT_125.len = zT_124;
    zT_119 = zT_125;
    zF_76BE513B_writeStr(zT_119);
    zT_127 = ":";
    zT_129 = 1;
    zT_128.ptr = zT_127;
    zT_128.len = zT_129;
    col_s2 = zT_128;
    col_s2 = zT_128;
    col_s2 = zT_128;
    zT_130 = col_s2;
    zF_76BE513B_writeStr(zT_130);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_132[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        col_buf[_i] = zT_132[_i];
        _i++;
    }
}
    zT_136 = loc.col;
    zT_134 = zT_136;
    zT_137 = (unsigned char*)col_buf;
    zT_139 = 16;
    zT_140 = 0;
    zT_141 = zT_137 + zT_140;
    zT_142 = zT_139 - zT_140;
    zT_143.ptr = zT_141;
    zT_143.len = zT_142;
    zT_135 = zT_143;
    zT_144 = zF_2FED9490_formatU32(zT_134, zT_135);
    col_len = zT_144;
    col_len = zT_144;
    col_len = zT_144;
    zT_146 = 16;
    zT_147 = (unsigned int)col_len;
    zT_148 = zT_146 - zT_147;
    cs = zT_148;
    cs = zT_148;
    cs = zT_148;
    zT_150 = (unsigned char*)col_buf;
    zT_152 = 16;
    zT_153 = zT_150 + cs;
    zT_154 = zT_152 - cs;
    zT_155.ptr = zT_153;
    zT_155.len = zT_154;
    zT_149 = zT_155;
    zF_76BE513B_writeStr(zT_149);
    zT_157 = ": ";
    zT_159 = 2;
    zT_158.ptr = zT_157;
    zT_158.len = zT_159;
    sep = zT_158;
    sep = zT_158;
    sep = zT_158;
    zT_160 = sep;
    zF_76BE513B_writeStr(zT_160);
    zT_163 = d->level;
    zT_162 = zT_163;
    zT_164 = zF_1620F424_getLevelName(zT_162);
    zT_161 = zT_164;
    zF_76BE513B_writeStr(zT_161);
    zT_166 = "[";
    zT_168 = 1;
    zT_167.ptr = zT_166;
    zT_167.len = zT_168;
    lb = zT_167;
    lb = zT_167;
    lb = zT_167;
    zT_169 = lb;
    zF_76BE513B_writeStr(zT_169);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_171[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        code_buf[_i] = zT_171[_i];
        _i++;
    }
}
    zT_175 = d->code;
    zT_176 = (unsigned int)zT_175;
    zT_173 = zT_176;
    zT_177 = (unsigned char*)code_buf;
    zT_179 = 8;
    zT_180 = 0;
    zT_181 = zT_177 + zT_180;
    zT_182 = zT_179 - zT_180;
    zT_183.ptr = zT_181;
    zT_183.len = zT_182;
    zT_174 = zT_183;
    zT_184 = zF_2FED9490_formatU32(zT_173, zT_174);
    code_len = zT_184;
    code_len = zT_184;
    code_len = zT_184;
    zT_186 = 8;
    zT_187 = (unsigned int)code_len;
    zT_188 = zT_186 - zT_187;
    kcs = zT_188;
    kcs = zT_188;
    kcs = zT_188;
    zT_190 = (unsigned char*)code_buf;
    zT_192 = 8;
    zT_193 = zT_190 + kcs;
    zT_194 = zT_192 - kcs;
    zT_195.ptr = zT_193;
    zT_195.len = zT_194;
    zT_189 = zT_195;
    zF_76BE513B_writeStr(zT_189);
    zT_197 = "]: ";
    zT_199 = 3;
    zT_198.ptr = zT_197;
    zT_198.len = zT_199;
    rb = zT_198;
    rb = zT_198;
    rb = zT_198;
    zT_200 = rb;
    zF_76BE513B_writeStr(zT_200);
    zT_201 = d->message_id;
    zT_202 = 0;
    zT_203 = zT_201 != zT_202;
    if (zT_203) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_66 = self->interner;
    zT_67 = zT_66->entries_items;
    zT_68 = d->message_id;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zT_67[zT_69];
    entry0 = zT_70;
    entry0 = zT_70;
    entry0 = zT_70;
    zT_72 = entry0.text;
    zT_71 = zT_72;
    zF_76BE513B_writeStr(zT_71);
    goto z_bb_10;
    z_bb_10:
    zT_74 = "\n";
    zT_76 = 1;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    nl0 = zT_75;
    nl0 = zT_75;
    nl0 = zT_75;
    zT_77 = nl0;
    zF_76BE513B_writeStr(zT_77);
    zT_78 = 1;
    zT_79 = (unsigned int)zT_78;
    zT_80 = i + zT_79;
    i = zT_80;
    i = zT_80;
    goto z_bb_6;
    z_bb_11:
    zT_205 = self->interner;
    zT_206 = zT_205->entries_items;
    zT_207 = d->message_id;
    zT_208 = (unsigned int)zT_207;
    zT_209 = zT_206[zT_208];
    entry = zT_209;
    entry = zT_209;
    entry = zT_209;
    zT_211 = entry.text;
    zT_210 = zT_211;
    zF_76BE513B_writeStr(zT_210);
    goto z_bb_12;
    z_bb_12:
    zT_218 = "\n";
    zT_220 = 1;
    zT_219.ptr = zT_218;
    zT_219.len = zT_220;
    nl = zT_219;
    nl = zT_219;
    nl = zT_219;
    zT_221 = nl;
    zF_76BE513B_writeStr(zT_221);
    zT_225 = self->source_manager;
    zT_223 = zT_225;
    zT_226 = d->file_id;
    zT_224 = zT_226;
    zT_227 = zF_FFE72B39_sourceManagerGetSou(zT_223, zT_224);
    content = zT_227;
    content = zT_227;
    content = zT_227;
    zT_231 = self->source_manager;
    zT_229 = zT_231;
    zT_232 = d->file_id;
    zT_230 = zT_232;
    zT_233 = zF_5041A561_sourceManagerGetLin(zT_229, zT_230);
    offsets = zT_233;
    offsets = zT_233;
    offsets = zT_233;
    zT_235 = offsets;
    zT_237 = d->span_start;
    zT_236 = zT_237;
    zT_238 = zF_1457D8A5_binary_search(zT_235, zT_236);
    line_idx = zT_238;
    line_idx = zT_238;
    line_idx = zT_238;
    zT_239 = 0;
    zT_240 = line_idx > (unsigned int)zT_239;
    if (zT_240) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_213 = "(no message)";
    zT_215 = 12;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    em = zT_214;
    em = zT_214;
    em = zT_214;
    zT_216 = em;
    zF_76BE513B_writeStr(zT_216);
    goto z_bb_12;
    z_bb_14:
    zT_241 = 1;
    zT_242 = (unsigned int)zT_241;
    zT_243 = line_idx - zT_242;
    line_idx = zT_243;
    line_idx = zT_243;
    goto z_bb_15;
    z_bb_15:
    zT_245 = offsets.ptr;
    zT_246 = (unsigned int)line_idx;
    zT_247 = zT_245[zT_246];
    zT_248 = (unsigned int)zT_247;
    line_start = zT_248;
    line_start = zT_248;
    line_start = zT_248;
    zT_251 = content.len;
    line_end = zT_251;
    line_end = zT_251;
    line_end = zT_251;
    zT_253 = 1;
    zT_254 = line_idx + zT_253;
    next_line = zT_254;
    next_line = zT_254;
    next_line = zT_254;
    zT_256 = offsets.len;
    zT_257 = (unsigned int)zT_256;
    zT_258 = next_line < zT_257;
    if (zT_258) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_259 = offsets.ptr;
    zT_260 = (unsigned int)next_line;
    zT_261 = zT_259[zT_260];
    zT_262 = (unsigned int)zT_261;
    line_end = zT_262;
    line_end = zT_262;
    zT_263 = 0;
    zT_264 = line_end > (unsigned int)zT_263;
    if (zT_264) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    l_start = line_start;
    l_start = line_start;
    l_start = line_start;
    l_end = line_end;
    l_end = line_end;
    l_end = line_end;
    zT_277 = l_start < l_end;
    if (zT_277) goto z_bb_23; else goto z_bb_24;
    z_bb_18:
    zT_266 = content.ptr;
    zT_267 = 1;
    zT_268 = line_end - zT_267;
    zT_269 = zT_266[zT_268];
    zT_270 = 10;
    zT_271 = zT_269 == zT_270;
    zT_265 = zT_271;
    goto z_bb_20;
    z_bb_19:
    zT_265 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_265) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_272 = 1;
    zT_273 = (unsigned int)zT_272;
    zT_274 = line_end - zT_273;
    line_end = zT_274;
    line_end = zT_274;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_17;
    z_bb_23:
    zT_280 = content.len;
    zT_281 = l_end <= zT_280;
    zT_278 = zT_281;
    goto z_bb_25;
    z_bb_24:
    zT_278 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_278) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_283 = content.ptr;
    zT_285 = zT_283 + l_start;
    zT_286 = l_end - l_start;
    zT_287.ptr = zT_285;
    zT_287.len = zT_286;
    line_text = zT_287;
    line_text = zT_287;
    line_text = zT_287;
    zT_288 = line_text;
    zF_76BE513B_writeStr(zT_288);
    zT_290 = "\n";
    zT_292 = 1;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    nl2 = zT_291;
    nl2 = zT_291;
    nl2 = zT_291;
    zT_293 = nl2;
    zF_76BE513B_writeStr(zT_293);
    zT_295 = loc.col;
    zT_296 = (unsigned int)zT_295;
    loc_col = zT_296;
    loc_col = zT_296;
    loc_col = zT_296;
    zT_298 = d->span_end;
    zT_299 = d->span_start;
    zT_300 = zT_298 - zT_299;
    zT_301 = (unsigned int)zT_300;
    cspan = zT_301;
    cspan = zT_301;
    cspan = zT_301;
    zT_302 = 0;
    zT_303 = cspan == (unsigned int)zT_302;
    if (zT_303) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_357 = 0;
    zT_358 = (unsigned char)zT_357;
    n = zT_358;
    n = zT_358;
    n = zT_358;
    goto z_bb_42;
    z_bb_28:
    zT_304 = 1;
    zT_305 = (unsigned int)zT_304;
    cspan = zT_305;
    cspan = zT_305;
    goto z_bb_29;
    z_bb_29:
    {
    unsigned int _i = 0;
    while (_i < 256) {
        zT_307[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 256) {
        caret_buf[_i] = zT_307[_i];
        _i++;
    }
}
    zT_309 = 0;
    zT_310 = (unsigned int)zT_309;
    caret_len = zT_310;
    caret_len = zT_310;
    caret_len = zT_310;
    space_count = loc_col;
    space_count = loc_col;
    space_count = loc_col;
    zT_312 = 256;
    zT_313 = space_count > (unsigned int)zT_312;
    if (zT_313) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_314 = 256;
    zT_315 = (unsigned int)zT_314;
    space_count = zT_315;
    space_count = zT_315;
    goto z_bb_31;
    z_bb_31:
    _ = 0;
    goto z_bb_32;
    z_bb_32:
    zT_317 = (unsigned int)_ < space_count;
    if (zT_317) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_318 = 32;
    caret_buf[caret_len] = zT_318;
    zT_319 = 1;
    zT_320 = (unsigned int)zT_319;
    zT_321 = caret_len + zT_320;
    caret_len = zT_321;
    caret_len = zT_321;
    zT_322 = 1;
    zT_323 = _ + zT_322;
    _ = zT_323;
    goto z_bb_32;
    z_bb_34:
    ulen = cspan;
    ulen = cspan;
    ulen = cspan;
    zT_325 = 256;
    zT_326 = zT_325 - loc_col;
    zT_327 = ulen > zT_326;
    if (zT_327) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_328 = 256;
    zT_329 = zT_328 - loc_col;
    ulen = zT_329;
    ulen = zT_329;
    goto z_bb_36;
    z_bb_36:
    max_carets = ulen;
    max_carets = ulen;
    max_carets = ulen;
    zT_331 = 256;
    zT_332 = zT_331 - caret_len;
    zT_333 = max_carets > zT_332;
    if (zT_333) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_334 = 256;
    zT_335 = zT_334 - caret_len;
    max_carets = zT_335;
    max_carets = zT_335;
    goto z_bb_38;
    z_bb_38:
    __1 = 0;
    goto z_bb_39;
    z_bb_39:
    zT_337 = (unsigned int)__1 < max_carets;
    if (zT_337) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_338 = 94;
    caret_buf[caret_len] = zT_338;
    zT_339 = 1;
    zT_340 = (unsigned int)zT_339;
    zT_341 = caret_len + zT_340;
    caret_len = zT_341;
    caret_len = zT_341;
    zT_342 = 1;
    zT_343 = __1 + zT_342;
    __1 = zT_343;
    goto z_bb_39;
    z_bb_41:
    zT_345 = (unsigned char*)caret_buf;
    zT_347 = 0;
    zT_348 = zT_345 + zT_347;
    zT_349 = caret_len - zT_347;
    zT_350.ptr = zT_348;
    zT_350.len = zT_349;
    zT_344 = zT_350;
    zF_76BE513B_writeStr(zT_344);
    zT_352 = "\n";
    zT_354 = 1;
    zT_353.ptr = zT_352;
    zT_353.len = zT_354;
    nl3 = zT_353;
    nl3 = zT_353;
    nl3 = zT_353;
    zT_355 = nl3;
    zF_76BE513B_writeStr(zT_355);
    goto z_bb_27;
    z_bb_42:
    zT_359 = d->note_count;
    zT_360 = n < zT_359;
    if (zT_360) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_362 = "note: ";
    zT_364 = 6;
    zT_363.ptr = zT_362;
    zT_363.len = zT_364;
    note_hdr = zT_363;
    note_hdr = zT_363;
    note_hdr = zT_363;
    zT_365 = note_hdr;
    zF_76BE513B_writeStr(zT_365);
    zT_367 = self->interner;
    zT_368 = zT_367->entries_items;
    zT_369 = d->note_ids;
    zT_370 = (unsigned int)n;
    zT_371 = zT_369[zT_370];
    zT_372 = (unsigned int)zT_371;
    zT_373 = zT_368[zT_372];
    note_entry = zT_373;
    note_entry = zT_373;
    note_entry = zT_373;
    zT_375 = note_entry.text;
    zT_374 = zT_375;
    zF_76BE513B_writeStr(zT_374);
    zT_377 = "\n";
    zT_379 = 1;
    zT_378.ptr = zT_377;
    zT_378.len = zT_379;
    note_nl = zT_378;
    note_nl = zT_378;
    note_nl = zT_378;
    zT_380 = note_nl;
    zF_76BE513B_writeStr(zT_380);
    zT_381 = 1;
    zT_382 = (unsigned char)zT_381;
    zT_383 = n + zT_382;
    n = zT_383;
    n = zT_383;
    goto z_bb_45;
    z_bb_44:
    zT_384 = d->related_span_idx;
    zT_385 = 0;
    zT_386 = zT_384 > zT_385;
    if (zT_386) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_388 = d->related_span_idx;
    zT_389 = self->related_span_len;
    zT_390 = (unsigned short)zT_389;
    zT_391 = zT_388 < zT_390;
    zT_387 = zT_391;
    goto z_bb_48;
    z_bb_47:
    zT_387 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_387) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_393 = self->related_span_items;
    zT_394 = d->related_span_idx;
    zT_395 = (unsigned int)zT_394;
    zT_396 = zT_393[zT_395];
    rs = zT_396;
    rs = zT_396;
    rs = zT_396;
    zT_401 = self->source_manager;
    zT_398 = zT_401;
    zT_402 = rs.span_file_id;
    zT_399 = zT_402;
    zT_403 = rs.span_start;
    zT_400 = zT_403;
    zT_404 = zF_4966CE4A_sourceManagerGetLoc(zT_398, zT_399, zT_400);
    rs_loc = zT_404;
    rs_loc = zT_404;
    rs_loc = zT_404;
    zT_408 = self->source_manager;
    zT_406 = zT_408;
    zT_409 = rs.span_file_id;
    zT_407 = zT_409;
    zT_410 = zF_B7076474_sourceManagerGetFil(zT_406, zT_407);
    rs_fname = zT_410;
    rs_fname = zT_410;
    rs_fname = zT_410;
    zT_411 = rs_fname;
    zF_76BE513B_writeStr(zT_411);
    zT_413 = ":";
    zT_415 = 1;
    zT_414.ptr = zT_413;
    zT_414.len = zT_415;
    rs_col_s = zT_414;
    rs_col_s = zT_414;
    rs_col_s = zT_414;
    zT_416 = rs_col_s;
    zF_76BE513B_writeStr(zT_416);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_418[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        rs_line_buf[_i] = zT_418[_i];
        _i++;
    }
}
    zT_422 = rs_loc.line;
    zT_420 = zT_422;
    zT_423 = (unsigned char*)rs_line_buf;
    zT_425 = 16;
    zT_426 = 0;
    zT_427 = zT_423 + zT_426;
    zT_428 = zT_425 - zT_426;
    zT_429.ptr = zT_427;
    zT_429.len = zT_428;
    zT_421 = zT_429;
    zT_430 = zF_2FED9490_formatU32(zT_420, zT_421);
    rs_line_len = zT_430;
    rs_line_len = zT_430;
    rs_line_len = zT_430;
    zT_432 = 16;
    zT_433 = (unsigned int)rs_line_len;
    zT_434 = zT_432 - zT_433;
    rls = zT_434;
    rls = zT_434;
    rls = zT_434;
    zT_436 = (unsigned char*)rs_line_buf;
    zT_438 = 16;
    zT_439 = zT_436 + rls;
    zT_440 = zT_438 - rls;
    zT_441.ptr = zT_439;
    zT_441.len = zT_440;
    zT_435 = zT_441;
    zF_76BE513B_writeStr(zT_435);
    zT_443 = ": note: ";
    zT_445 = 8;
    zT_444.ptr = zT_443;
    zT_444.len = zT_445;
    rs_sep = zT_444;
    rs_sep = zT_444;
    rs_sep = zT_444;
    zT_446 = rs_sep;
    zF_76BE513B_writeStr(zT_446);
    zT_448 = self->interner;
    zT_449 = zT_448->entries_items;
    zT_450 = rs.message_id;
    zT_451 = (unsigned int)zT_450;
    zT_452 = zT_449[zT_451];
    rs_msg = zT_452;
    rs_msg = zT_452;
    rs_msg = zT_452;
    zT_454 = rs_msg.text;
    zT_453 = zT_454;
    zF_76BE513B_writeStr(zT_453);
    zT_456 = "\n";
    zT_458 = 1;
    zT_457.ptr = zT_456;
    zT_457.len = zT_458;
    rs_nl = zT_457;
    rs_nl = zT_457;
    rs_nl = zT_457;
    zT_459 = rs_nl;
    zF_76BE513B_writeStr(zT_459);
    goto z_bb_50;
    z_bb_50:
    zT_460 = 1;
    zT_461 = (unsigned int)zT_460;
    zT_462 = i + zT_461;
    i = zT_462;
    i = zT_462;
    goto z_bb_6;
}

/* typeKindSrcStr */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C14453DE_typeKindSrcStr(zT_33EF6BFB_TypeKind kind) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_33EF6BFB_TypeKind zT_119;
    int zT_120;
    zT_33EF6BFB_TypeKind zT_123;
    int zT_124;
    zT_33EF6BFB_TypeKind zT_127;
    int zT_128;
    zT_33EF6BFB_TypeKind zT_131;
    int zT_132;
    zT_33EF6BFB_TypeKind zT_135;
    int zT_136;
    zT_33EF6BFB_TypeKind zT_139;
    int zT_140;
    zT_33EF6BFB_TypeKind zT_143;
    int zT_144;
    zT_33EF6BFB_TypeKind zT_147;
    int zT_148;
    zT_33EF6BFB_TypeKind zT_151;
    int zT_152;
    zT_33EF6BFB_TypeKind zT_155;
    int zT_156;
    zT_33EF6BFB_TypeKind zT_159;
    int zT_160;
    zT_33EF6BFB_TypeKind zT_163;
    int zT_164;
    zT_33EF6BFB_TypeKind zT_167;
    int zT_168;
    zT_33EF6BFB_TypeKind zT_171;
    int zT_172;
    zT_33EF6BFB_TypeKind zT_175;
    int zT_176;
    zT_33EF6BFB_TypeKind zT_179;
    int zT_180;
    zT_33EF6BFB_TypeKind zT_183;
    int zT_184;
    zT_33EF6BFB_TypeKind zT_187;
    int zT_188;
    zT_33EF6BFB_TypeKind zT_191;
    int zT_192;
    zT_33EF6BFB_TypeKind zT_195;
    int zT_196;
    zT_33EF6BFB_TypeKind zT_199;
    int zT_200;
    zT_33EF6BFB_TypeKind zT_203;
    int zT_204;
    zT_33EF6BFB_TypeKind zT_207;
    int zT_208;
    zT_33EF6BFB_TypeKind zT_211;
    int zT_212;
    zT_33EF6BFB_TypeKind zT_215;
    int zT_216;
    zT_33EF6BFB_TypeKind zT_219;
    int zT_220;
    zT_33EF6BFB_TypeKind zT_223;
    int zT_224;
    zT_33EF6BFB_TypeKind zT_227;
    int zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_void;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ctl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u8_;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_struct;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_enum;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_union;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fn;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tuple;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_type;
    zT_2 = "source: void";
    zT_4 = 12;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_void = zT_3;
    s_void = zT_3;
    s_void = zT_3;
    zT_6 = "source: bool";
    zT_8 = 12;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    s_bool = zT_7;
    s_bool = zT_7;
    s_bool = zT_7;
    zT_10 = "source: comptime_int";
    zT_12 = 20;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    s_ctl = zT_11;
    s_ctl = zT_11;
    s_ctl = zT_11;
    zT_14 = "source: i8";
    zT_16 = 10;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    s_i8 = zT_15;
    s_i8 = zT_15;
    s_i8 = zT_15;
    zT_18 = "source: i16";
    zT_20 = 11;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    s_i16 = zT_19;
    s_i16 = zT_19;
    s_i16 = zT_19;
    zT_22 = "source: i32";
    zT_24 = 11;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    s_i32 = zT_23;
    s_i32 = zT_23;
    s_i32 = zT_23;
    zT_26 = "source: i64";
    zT_28 = 11;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    s_i64 = zT_27;
    s_i64 = zT_27;
    s_i64 = zT_27;
    zT_30 = "source: u8";
    zT_32 = 10;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    s_u8_ = zT_31;
    s_u8_ = zT_31;
    s_u8_ = zT_31;
    zT_34 = "source: u16";
    zT_36 = 11;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    s_u16 = zT_35;
    s_u16 = zT_35;
    s_u16 = zT_35;
    zT_38 = "source: u32";
    zT_40 = 11;
    zT_39.ptr = zT_38;
    zT_39.len = zT_40;
    s_u32 = zT_39;
    s_u32 = zT_39;
    s_u32 = zT_39;
    zT_42 = "source: u64";
    zT_44 = 11;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    s_u64 = zT_43;
    s_u64 = zT_43;
    s_u64 = zT_43;
    zT_46 = "source: f32";
    zT_48 = 11;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    s_f32 = zT_47;
    s_f32 = zT_47;
    s_f32 = zT_47;
    zT_50 = "source: f64";
    zT_52 = 11;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    s_f64 = zT_51;
    s_f64 = zT_51;
    s_f64 = zT_51;
    zT_54 = "source: pointer";
    zT_56 = 15;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    s_ptr = zT_55;
    s_ptr = zT_55;
    s_ptr = zT_55;
    zT_58 = "source: many-pointer";
    zT_60 = 20;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_mptr = zT_59;
    s_mptr = zT_59;
    s_mptr = zT_59;
    zT_62 = "source: slice";
    zT_64 = 13;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    s_slice = zT_63;
    s_slice = zT_63;
    s_slice = zT_63;
    zT_66 = "source: optional";
    zT_68 = 16;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    s_opt = zT_67;
    s_opt = zT_67;
    s_opt = zT_67;
    zT_70 = "source: error-union";
    zT_72 = 19;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    s_eu = zT_71;
    s_eu = zT_71;
    s_eu = zT_71;
    zT_74 = "source: error-set";
    zT_76 = 17;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    s_es = zT_75;
    s_es = zT_75;
    s_es = zT_75;
    zT_78 = "source: array";
    zT_80 = 13;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    s_arr = zT_79;
    s_arr = zT_79;
    s_arr = zT_79;
    zT_82 = "source: struct";
    zT_84 = 14;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    s_struct = zT_83;
    s_struct = zT_83;
    s_struct = zT_83;
    zT_86 = "source: enum";
    zT_88 = 12;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    s_enum = zT_87;
    s_enum = zT_87;
    s_enum = zT_87;
    zT_90 = "source: union";
    zT_92 = 13;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    s_union = zT_91;
    s_union = zT_91;
    s_union = zT_91;
    zT_94 = "source: tagged-union";
    zT_96 = 20;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    s_tu = zT_95;
    s_tu = zT_95;
    s_tu = zT_95;
    zT_98 = "source: function";
    zT_100 = 16;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    s_fn = zT_99;
    s_fn = zT_99;
    s_fn = zT_99;
    zT_102 = "source: tuple";
    zT_104 = 13;
    zT_103.ptr = zT_102;
    zT_103.len = zT_104;
    s_tuple = zT_103;
    s_tuple = zT_103;
    s_tuple = zT_103;
    zT_106 = "source: null";
    zT_108 = 12;
    zT_107.ptr = zT_106;
    zT_107.len = zT_108;
    s_null = zT_107;
    s_null = zT_107;
    s_null = zT_107;
    zT_110 = "source: noreturn";
    zT_112 = 16;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    s_nr = zT_111;
    s_nr = zT_111;
    s_nr = zT_111;
    zT_114 = "source: type";
    zT_116 = 12;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    s_type = zT_115;
    s_type = zT_115;
    s_type = zT_115;
    zT_119 = zT_33EF6BFB_TypeKind_void_type;
    zT_120 = kind == zT_119;
    if (zT_120) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return s_void;
    z_bb_2:
    zT_123 = zT_33EF6BFB_TypeKind_bool_type;
    zT_124 = kind == zT_123;
    if (zT_124) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return s_bool;
    z_bb_4:
    zT_127 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_128 = kind == zT_127;
    if (zT_128) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return s_ctl;
    z_bb_6:
    zT_131 = zT_33EF6BFB_TypeKind_i8_type;
    zT_132 = kind == zT_131;
    if (zT_132) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return s_i8;
    z_bb_8:
    zT_135 = zT_33EF6BFB_TypeKind_i16_type;
    zT_136 = kind == zT_135;
    if (zT_136) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return s_i16;
    z_bb_10:
    zT_139 = zT_33EF6BFB_TypeKind_i32_type;
    zT_140 = kind == zT_139;
    if (zT_140) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return s_i32;
    z_bb_12:
    zT_143 = zT_33EF6BFB_TypeKind_i64_type;
    zT_144 = kind == zT_143;
    if (zT_144) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return s_i64;
    z_bb_14:
    zT_147 = zT_33EF6BFB_TypeKind_u8_type;
    zT_148 = kind == zT_147;
    if (zT_148) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return s_u8_;
    z_bb_16:
    zT_151 = zT_33EF6BFB_TypeKind_u16_type;
    zT_152 = kind == zT_151;
    if (zT_152) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return s_u16;
    z_bb_18:
    zT_155 = zT_33EF6BFB_TypeKind_u32_type;
    zT_156 = kind == zT_155;
    if (zT_156) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return s_u32;
    z_bb_20:
    zT_159 = zT_33EF6BFB_TypeKind_u64_type;
    zT_160 = kind == zT_159;
    if (zT_160) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return s_u64;
    z_bb_22:
    zT_163 = zT_33EF6BFB_TypeKind_f32_type;
    zT_164 = kind == zT_163;
    if (zT_164) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return s_f32;
    z_bb_24:
    zT_167 = zT_33EF6BFB_TypeKind_f64_type;
    zT_168 = kind == zT_167;
    if (zT_168) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return s_f64;
    z_bb_26:
    zT_171 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_172 = kind == zT_171;
    if (zT_172) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return s_ptr;
    z_bb_28:
    zT_175 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_176 = kind == zT_175;
    if (zT_176) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return s_mptr;
    z_bb_30:
    zT_179 = zT_33EF6BFB_TypeKind_slice_type;
    zT_180 = kind == zT_179;
    if (zT_180) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return s_slice;
    z_bb_32:
    zT_183 = zT_33EF6BFB_TypeKind_optional_type;
    zT_184 = kind == zT_183;
    if (zT_184) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return s_opt;
    z_bb_34:
    zT_187 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_188 = kind == zT_187;
    if (zT_188) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return s_eu;
    z_bb_36:
    zT_191 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_192 = kind == zT_191;
    if (zT_192) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return s_es;
    z_bb_38:
    zT_195 = zT_33EF6BFB_TypeKind_array_type;
    zT_196 = kind == zT_195;
    if (zT_196) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return s_arr;
    z_bb_40:
    zT_199 = zT_33EF6BFB_TypeKind_struct_type;
    zT_200 = kind == zT_199;
    if (zT_200) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return s_struct;
    z_bb_42:
    zT_203 = zT_33EF6BFB_TypeKind_enum_type;
    zT_204 = kind == zT_203;
    if (zT_204) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return s_enum;
    z_bb_44:
    zT_207 = zT_33EF6BFB_TypeKind_union_type;
    zT_208 = kind == zT_207;
    if (zT_208) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return s_union;
    z_bb_46:
    zT_211 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_212 = kind == zT_211;
    if (zT_212) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return s_tu;
    z_bb_48:
    zT_215 = zT_33EF6BFB_TypeKind_fn_type;
    zT_216 = kind == zT_215;
    if (zT_216) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return s_fn;
    z_bb_50:
    zT_219 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_220 = kind == zT_219;
    if (zT_220) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return s_tuple;
    z_bb_52:
    zT_223 = zT_33EF6BFB_TypeKind_null_type;
    zT_224 = kind == zT_223;
    if (zT_224) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return s_null;
    z_bb_54:
    zT_227 = zT_33EF6BFB_TypeKind_noreturn_type;
    zT_228 = kind == zT_227;
    if (zT_228) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return s_nr;
    z_bb_56:
    return s_type;
}

/* typeKindTgtStr */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_CC479241_typeKindTgtStr(zT_33EF6BFB_TypeKind kind) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_33EF6BFB_TypeKind zT_119;
    int zT_120;
    zT_33EF6BFB_TypeKind zT_123;
    int zT_124;
    zT_33EF6BFB_TypeKind zT_127;
    int zT_128;
    zT_33EF6BFB_TypeKind zT_131;
    int zT_132;
    zT_33EF6BFB_TypeKind zT_135;
    int zT_136;
    zT_33EF6BFB_TypeKind zT_139;
    int zT_140;
    zT_33EF6BFB_TypeKind zT_143;
    int zT_144;
    zT_33EF6BFB_TypeKind zT_147;
    int zT_148;
    zT_33EF6BFB_TypeKind zT_151;
    int zT_152;
    zT_33EF6BFB_TypeKind zT_155;
    int zT_156;
    zT_33EF6BFB_TypeKind zT_159;
    int zT_160;
    zT_33EF6BFB_TypeKind zT_163;
    int zT_164;
    zT_33EF6BFB_TypeKind zT_167;
    int zT_168;
    zT_33EF6BFB_TypeKind zT_171;
    int zT_172;
    zT_33EF6BFB_TypeKind zT_175;
    int zT_176;
    zT_33EF6BFB_TypeKind zT_179;
    int zT_180;
    zT_33EF6BFB_TypeKind zT_183;
    int zT_184;
    zT_33EF6BFB_TypeKind zT_187;
    int zT_188;
    zT_33EF6BFB_TypeKind zT_191;
    int zT_192;
    zT_33EF6BFB_TypeKind zT_195;
    int zT_196;
    zT_33EF6BFB_TypeKind zT_199;
    int zT_200;
    zT_33EF6BFB_TypeKind zT_203;
    int zT_204;
    zT_33EF6BFB_TypeKind zT_207;
    int zT_208;
    zT_33EF6BFB_TypeKind zT_211;
    int zT_212;
    zT_33EF6BFB_TypeKind zT_215;
    int zT_216;
    zT_33EF6BFB_TypeKind zT_219;
    int zT_220;
    zT_33EF6BFB_TypeKind zT_223;
    int zT_224;
    zT_33EF6BFB_TypeKind zT_227;
    int zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_void;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ctl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u8_;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_struct;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_enum;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_union;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fn;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tuple;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_type;
    zT_2 = "target: void";
    zT_4 = 12;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_void = zT_3;
    s_void = zT_3;
    s_void = zT_3;
    zT_6 = "target: bool";
    zT_8 = 12;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    s_bool = zT_7;
    s_bool = zT_7;
    s_bool = zT_7;
    zT_10 = "target: comptime_int";
    zT_12 = 20;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    s_ctl = zT_11;
    s_ctl = zT_11;
    s_ctl = zT_11;
    zT_14 = "target: i8";
    zT_16 = 10;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    s_i8 = zT_15;
    s_i8 = zT_15;
    s_i8 = zT_15;
    zT_18 = "target: i16";
    zT_20 = 11;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    s_i16 = zT_19;
    s_i16 = zT_19;
    s_i16 = zT_19;
    zT_22 = "target: i32";
    zT_24 = 11;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    s_i32 = zT_23;
    s_i32 = zT_23;
    s_i32 = zT_23;
    zT_26 = "target: i64";
    zT_28 = 11;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    s_i64 = zT_27;
    s_i64 = zT_27;
    s_i64 = zT_27;
    zT_30 = "target: u8";
    zT_32 = 10;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    s_u8_ = zT_31;
    s_u8_ = zT_31;
    s_u8_ = zT_31;
    zT_34 = "target: u16";
    zT_36 = 11;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    s_u16 = zT_35;
    s_u16 = zT_35;
    s_u16 = zT_35;
    zT_38 = "target: u32";
    zT_40 = 11;
    zT_39.ptr = zT_38;
    zT_39.len = zT_40;
    s_u32 = zT_39;
    s_u32 = zT_39;
    s_u32 = zT_39;
    zT_42 = "target: u64";
    zT_44 = 11;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    s_u64 = zT_43;
    s_u64 = zT_43;
    s_u64 = zT_43;
    zT_46 = "target: f32";
    zT_48 = 11;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    s_f32 = zT_47;
    s_f32 = zT_47;
    s_f32 = zT_47;
    zT_50 = "target: f64";
    zT_52 = 11;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    s_f64 = zT_51;
    s_f64 = zT_51;
    s_f64 = zT_51;
    zT_54 = "target: pointer";
    zT_56 = 15;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    s_ptr = zT_55;
    s_ptr = zT_55;
    s_ptr = zT_55;
    zT_58 = "target: many-pointer";
    zT_60 = 20;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_mptr = zT_59;
    s_mptr = zT_59;
    s_mptr = zT_59;
    zT_62 = "target: slice";
    zT_64 = 13;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    s_slice = zT_63;
    s_slice = zT_63;
    s_slice = zT_63;
    zT_66 = "target: optional";
    zT_68 = 16;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    s_opt = zT_67;
    s_opt = zT_67;
    s_opt = zT_67;
    zT_70 = "target: error-union";
    zT_72 = 19;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    s_eu = zT_71;
    s_eu = zT_71;
    s_eu = zT_71;
    zT_74 = "target: error-set";
    zT_76 = 17;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    s_es = zT_75;
    s_es = zT_75;
    s_es = zT_75;
    zT_78 = "target: array";
    zT_80 = 13;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    s_arr = zT_79;
    s_arr = zT_79;
    s_arr = zT_79;
    zT_82 = "target: struct";
    zT_84 = 14;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    s_struct = zT_83;
    s_struct = zT_83;
    s_struct = zT_83;
    zT_86 = "target: enum";
    zT_88 = 12;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    s_enum = zT_87;
    s_enum = zT_87;
    s_enum = zT_87;
    zT_90 = "target: union";
    zT_92 = 13;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    s_union = zT_91;
    s_union = zT_91;
    s_union = zT_91;
    zT_94 = "target: tagged-union";
    zT_96 = 20;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    s_tu = zT_95;
    s_tu = zT_95;
    s_tu = zT_95;
    zT_98 = "target: function";
    zT_100 = 16;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    s_fn = zT_99;
    s_fn = zT_99;
    s_fn = zT_99;
    zT_102 = "target: tuple";
    zT_104 = 13;
    zT_103.ptr = zT_102;
    zT_103.len = zT_104;
    s_tuple = zT_103;
    s_tuple = zT_103;
    s_tuple = zT_103;
    zT_106 = "target: null";
    zT_108 = 12;
    zT_107.ptr = zT_106;
    zT_107.len = zT_108;
    s_null = zT_107;
    s_null = zT_107;
    s_null = zT_107;
    zT_110 = "target: noreturn";
    zT_112 = 16;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    s_nr = zT_111;
    s_nr = zT_111;
    s_nr = zT_111;
    zT_114 = "target: type";
    zT_116 = 12;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    s_type = zT_115;
    s_type = zT_115;
    s_type = zT_115;
    zT_119 = zT_33EF6BFB_TypeKind_void_type;
    zT_120 = kind == zT_119;
    if (zT_120) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return s_void;
    z_bb_2:
    zT_123 = zT_33EF6BFB_TypeKind_bool_type;
    zT_124 = kind == zT_123;
    if (zT_124) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return s_bool;
    z_bb_4:
    zT_127 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_128 = kind == zT_127;
    if (zT_128) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return s_ctl;
    z_bb_6:
    zT_131 = zT_33EF6BFB_TypeKind_i8_type;
    zT_132 = kind == zT_131;
    if (zT_132) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return s_i8;
    z_bb_8:
    zT_135 = zT_33EF6BFB_TypeKind_i16_type;
    zT_136 = kind == zT_135;
    if (zT_136) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return s_i16;
    z_bb_10:
    zT_139 = zT_33EF6BFB_TypeKind_i32_type;
    zT_140 = kind == zT_139;
    if (zT_140) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return s_i32;
    z_bb_12:
    zT_143 = zT_33EF6BFB_TypeKind_i64_type;
    zT_144 = kind == zT_143;
    if (zT_144) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return s_i64;
    z_bb_14:
    zT_147 = zT_33EF6BFB_TypeKind_u8_type;
    zT_148 = kind == zT_147;
    if (zT_148) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return s_u8_;
    z_bb_16:
    zT_151 = zT_33EF6BFB_TypeKind_u16_type;
    zT_152 = kind == zT_151;
    if (zT_152) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return s_u16;
    z_bb_18:
    zT_155 = zT_33EF6BFB_TypeKind_u32_type;
    zT_156 = kind == zT_155;
    if (zT_156) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return s_u32;
    z_bb_20:
    zT_159 = zT_33EF6BFB_TypeKind_u64_type;
    zT_160 = kind == zT_159;
    if (zT_160) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return s_u64;
    z_bb_22:
    zT_163 = zT_33EF6BFB_TypeKind_f32_type;
    zT_164 = kind == zT_163;
    if (zT_164) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return s_f32;
    z_bb_24:
    zT_167 = zT_33EF6BFB_TypeKind_f64_type;
    zT_168 = kind == zT_167;
    if (zT_168) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return s_f64;
    z_bb_26:
    zT_171 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_172 = kind == zT_171;
    if (zT_172) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return s_ptr;
    z_bb_28:
    zT_175 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_176 = kind == zT_175;
    if (zT_176) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return s_mptr;
    z_bb_30:
    zT_179 = zT_33EF6BFB_TypeKind_slice_type;
    zT_180 = kind == zT_179;
    if (zT_180) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return s_slice;
    z_bb_32:
    zT_183 = zT_33EF6BFB_TypeKind_optional_type;
    zT_184 = kind == zT_183;
    if (zT_184) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return s_opt;
    z_bb_34:
    zT_187 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_188 = kind == zT_187;
    if (zT_188) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return s_eu;
    z_bb_36:
    zT_191 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_192 = kind == zT_191;
    if (zT_192) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return s_es;
    z_bb_38:
    zT_195 = zT_33EF6BFB_TypeKind_array_type;
    zT_196 = kind == zT_195;
    if (zT_196) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return s_arr;
    z_bb_40:
    zT_199 = zT_33EF6BFB_TypeKind_struct_type;
    zT_200 = kind == zT_199;
    if (zT_200) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return s_struct;
    z_bb_42:
    zT_203 = zT_33EF6BFB_TypeKind_enum_type;
    zT_204 = kind == zT_203;
    if (zT_204) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return s_enum;
    z_bb_44:
    zT_207 = zT_33EF6BFB_TypeKind_union_type;
    zT_208 = kind == zT_207;
    if (zT_208) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return s_union;
    z_bb_46:
    zT_211 = zT_33EF6BFB_TypeKind_tagged_union_type;
    zT_212 = kind == zT_211;
    if (zT_212) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return s_tu;
    z_bb_48:
    zT_215 = zT_33EF6BFB_TypeKind_fn_type;
    zT_216 = kind == zT_215;
    if (zT_216) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return s_fn;
    z_bb_50:
    zT_219 = zT_33EF6BFB_TypeKind_tuple_type;
    zT_220 = kind == zT_219;
    if (zT_220) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return s_tuple;
    z_bb_52:
    zT_223 = zT_33EF6BFB_TypeKind_null_type;
    zT_224 = kind == zT_223;
    if (zT_224) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return s_null;
    z_bb_54:
    zT_227 = zT_33EF6BFB_TypeKind_noreturn_type;
    zT_228 = kind == zT_227;
    if (zT_228) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return s_nr;
    z_bb_56:
    return s_type;
}

/* __module_init */
void zF_780653D2___module_init_3(void) {
    zT_227EDE07_SourceManager zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zG_227EDE07_SourceManager = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    return;
}

/* EOF */
