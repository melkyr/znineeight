#include "diagnostics_B9C6175E.h"
zT_F85C5DED_DiagnosticCollector zG_F85C5DED_DiagnosticCollector;
/* getLevelName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_1620F424_getLevelName(unsigned char level) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
switch (level) {
case 0: goto z_bb_1;
case 1: goto z_bb_2;
case 2: goto z_bb_3;
case 3: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_1:
    zT_2 = "error";
    zT_4 = 5;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s = zT_3;
    return s;
    z_bb_2:
    zT_6 = "warning";
    zT_8 = 7;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    s = zT_7;
    return s;
    z_bb_3:
    zT_10 = "info";
    zT_12 = 4;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    s = zT_11;
    return s;
    z_bb_4:
    zT_14 = "note";
    zT_16 = 4;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    s = zT_15;
    return s;
    z_bb_5:
    zT_18 = "unknown";
    zT_20 = 7;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    s = zT_19;
    return s;
    { zT_8F083A69_Slice_zT_0B42B2F8_u zT_ret_void = {0}; return zT_ret_void; }
}

/* formatU32 */
unsigned int zF_2FED9490_formatU32(unsigned int value, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    int zT_9;
    unsigned int zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_22;
    int zT_24;
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned int v;
    unsigned int i;
    v = value;
    zT_5 = buf.len;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    zT_7 = 0;
    if ((unsigned char)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_9 = 1;
    zT_11 = i - (unsigned int)((unsigned int)zT_9);
    i = zT_11;
    zT_12 = 48;
    zT_13 = buf.ptr;
    zT_14 = (unsigned int)i;
    zT_13[zT_14] = zT_12;
    goto z_bb_2;
    z_bb_2:
    zT_33 = buf.len;
    return (unsigned int)((unsigned int)((unsigned int)zT_33) - i);
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_15 = 0;
    if ((unsigned char)(v > (unsigned int)zT_15)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_20 = 1;
    zT_22 = i - (unsigned int)((unsigned int)zT_20);
    i = zT_22;
    zT_24 = 10;
    zT_27 = (unsigned char)(48) + (unsigned char)((unsigned char)(unsigned int)(v % zT_24));
    zT_28 = buf.ptr;
    zT_29 = (unsigned int)i;
    zT_28[zT_29] = zT_27;
    zT_30 = 10;
    zT_31 = v / zT_30;
    v = zT_31;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_18 = 0;
    zT_17 = i > (unsigned int)zT_18;
    goto z_bb_10;
    z_bb_9:
    zT_17 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_17) goto z_bb_5; else goto z_bb_6;
}

/* writeStr */
void zF_76BE513B_writeStr(zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1;
    zT_1 = s;
    zF_E4B2EF19_stderr_write(zT_1);
    return;
}

/* compareDiag */
int zF_36E7146B_compareDiag(zT_50FBF81E_Diagnostic* a, zT_50FBF81E_Diagnostic* b) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char zT_18;
    unsigned char zT_19;
    unsigned char zT_21;
    unsigned char zT_23;
    int zT_26;
    zT_2 = a->file_id;
    zT_3 = b->file_id;
    if ((unsigned char)(zT_2 != zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = a->file_id;
    zT_7 = b->file_id;
    return (int)((int)((int)zT_5) - (int)((int)zT_7));
    z_bb_2:
    zT_10 = a->span_start;
    zT_11 = b->span_start;
    if ((unsigned char)(zT_10 != zT_11)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = a->span_start;
    zT_15 = b->span_start;
    return (int)((int)((int)zT_13) - (int)((int)zT_15));
    z_bb_4:
    zT_18 = a->level;
    zT_19 = b->level;
    if ((unsigned char)(zT_18 != zT_19)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_21 = a->level;
    zT_23 = b->level;
    return (int)((int)((int)zT_21) - (int)((int)zT_23));
    z_bb_6:
    zT_26 = 0;
    return (int)((int)zT_26);
}

/* sortDiagnostics */
void zF_F6BADF23_sortDiagnostics(zT_8D25846A_Slice_zT_50FBF81E_D diags) {
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_5;
    zT_50FBF81E_Diagnostic* zT_8;
    zT_50FBF81E_Diagnostic zT_9;
    int zT_11;
    int zT_12;
    unsigned char zT_14;
    zT_50FBF81E_Diagnostic* zT_15;
    zT_50FBF81E_Diagnostic* zT_16;
    zT_50FBF81E_Diagnostic* zT_17;
    int zT_18;
    zT_50FBF81E_Diagnostic* zT_21;
    zT_50FBF81E_Diagnostic* zT_22;
    int zT_23 = 0;
    int zT_24;
    zT_50FBF81E_Diagnostic* zT_26;
    int zT_27;
    unsigned int zT_29;
    zT_50FBF81E_Diagnostic zT_30;
    zT_50FBF81E_Diagnostic* zT_31;
    unsigned int zT_32;
    int zT_33;
    int zT_35;
    zT_50FBF81E_Diagnostic* zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned int zT_40;
    unsigned int i;
    zT_50FBF81E_Diagnostic key;
    int j;
    zT_2 = 1;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_5 = diags.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = diags.ptr;
    zT_9 = zT_8[i];
    key = zT_9;
    zT_11 = (int)i;
    j = zT_11;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_12 = 0;
    if ((unsigned char)(j > zT_12)) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_26 = diags.ptr;
    zT_27 = 1;
    zT_29 = (unsigned int)(int)(j - zT_27);
    zT_30 = zT_26[zT_29];
    zT_31 = diags.ptr;
    zT_32 = (unsigned int)j;
    zT_31[zT_32] = zT_30;
    zT_33 = 1;
    zT_35 = j - (int)((int)zT_33);
    j = zT_35;
    goto z_bb_8;
    z_bb_7:
    zT_36 = diags.ptr;
    zT_37 = (unsigned int)j;
    zT_36[zT_37] = key;
    zT_38 = 1;
    zT_40 = i + (unsigned int)((unsigned int)zT_38);
    i = zT_40;
    goto z_bb_4;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_17 = diags.ptr;
    zT_18 = 1;
    zT_21 = zT_17 + (unsigned int)((unsigned int)(int)(j - zT_18));
    zT_15 = zT_21;
    zT_22 = &key;
    zT_16 = zT_22;
    zT_23 = zF_36E7146B_compareDiag(zT_15, zT_16);
    zT_24 = 0;
    zT_14 = zT_23 > zT_24;
    goto z_bb_11;
    z_bb_10:
    zT_14 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_14) goto z_bb_6; else goto z_bb_7;
}

/* diagnosticArrayListInit */
zT_C0B2E5AF_DiagnosticArrayList zF_D95B9309_diagnosticArrayList(zT_3E40CD83_Sand* allocator) {
    zT_C0B2E5AF_DiagnosticArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_50FBF81E_Diagnostic*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* diagnosticArrayListEnsureCapacity */
void zF_622A0C29_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    zT_50FBF81E_Diagnostic* zT_26;
    unsigned int zT_28;
    zT_6A32A83C_Opt_238 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_0715C9B9_EU_832 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    zT_50FBF81E_Diagnostic* zT_49;
    zT_50FBF81E_Diagnostic* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_50FBF81E_Diagnostic* zT_53;
    unsigned int zT_54;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_55;
    zT_50FBF81E_Diagnostic* zT_56;
    unsigned int zT_57;
    unsigned int zT_62;
    unsigned int new_cap;
    zT_6A32A83C_Opt_238 grown;
    unsigned char* raw;
    zT_50FBF81E_Diagnostic* new_items;
    zT_50FBF81E_Diagnostic item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->capacity;
    zT_17 = 0;
    if ((unsigned char)(zT_16 > (unsigned int)zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = self->allocator;
    zT_26 = self->items;
    zT_28 = self->capacity;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), (unsigned int)(zT_28 * (unsigned int)(40)), (unsigned int)(new_cap * (unsigned int)(40)), (unsigned int)(4));
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_37 = self->allocator;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(40) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_46 = zT_44.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    zT_49 = (zT_50FBF81E_Diagnostic*)raw;
    new_items = zT_49;
    zT_50 = self->items;
    zT_51 = self->len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_62 = i + (unsigned int)(1);
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* diagnosticArrayListAppend */
void zF_075D71E7_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self, zT_50FBF81E_Diagnostic value) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_50FBF81E_Diagnostic* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_622A0C29_diagnosticArrayList(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* diagnosticArrayListGetSlice */
zT_8D25846A_Slice_zT_50FBF81E_D zF_88E8322D_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList* self) {
    zT_50FBF81E_Diagnostic* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_50FBF81E_Diagnostic* zT_4;
    unsigned int zT_5;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* diagnosticCollectorInit */
zT_F85C5DED_DiagnosticCollector zF_C7BA7DAB_diagnosticCollector(zT_3E40CD83_Sand* allocator, zT_227EDE07_SourceManager* source_manager, zT_D3EB6303_StringInterner* interner) {
    zT_3E40CD83_Sand* zT_4;
    zT_0715C9B9_EU_832 zT_9 = {0};
    unsigned char zT_10;
    unsigned char* zT_11;
    zT_C0B2E5AF_DiagnosticArrayList* zT_14;
    zT_3E40CD83_Sand* zT_15;
    zT_C0B2E5AF_DiagnosticArrayList zT_16 = {0};
    zT_F85C5DED_DiagnosticCollector zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char* d_raw;
    zT_C0B2E5AF_DiagnosticArrayList* d_ptr;
    zT_4 = allocator;
    zT_9 = zF_1395EB68_sandAlloc(zT_4, (unsigned int)(16), (unsigned int)(4));
    zT_10 = zT_9.is_error;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_11 = zT_9.data.payload;
    goto z_bb_3;
    z_bb_3:
    d_raw = zT_11;
    zT_14 = (zT_C0B2E5AF_DiagnosticArrayList*)d_raw;
    d_ptr = zT_14;
    zT_15 = allocator;
    zT_16 = zF_D95B9309_diagnosticArrayList(zT_15);
    *d_ptr = zT_16;
    zT_17.diagnostics = d_ptr;
    zT_18 = 0;
    zT_17.related_span_items = (zT_B258D528_RelatedSpan*)zT_18;
    zT_19 = 0;
    zT_17.related_span_len = zT_19;
    zT_20 = 0;
    zT_17.related_span_cap = zT_20;
    zT_17.allocator = allocator;
    zT_17.source_manager = source_manager;
    zT_17.interner = interner;
    zT_21 = 0;
    zT_17.error_count = zT_21;
    zT_22 = 0;
    zT_17.warning_count = zT_22;
    zT_23 = 256;
    zT_17.max_diagnostics = zT_23;
    zT_24 = 0;
    zT_17.diag_seen_items = (unsigned int*)zT_24;
    zT_25 = 0;
    zT_17.diag_seen_len = zT_25;
    zT_26 = 0;
    zT_17.diag_seen_cap = zT_26;
    return zT_17;
}

/* diagnosticCollectorIntern */
unsigned int zF_14631FFD_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_D3EB6303_StringInterner* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_5 = 0;
    zT_2 = self->interner;
    zT_3 = msg;
    zT_5 = zF_50C274AF_stringInternerInter(zT_2, zT_3);
    return zT_5;
}

/* diagnosticCollectorAdd */
unsigned int zF_C82559AC_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned char level, unsigned short code, unsigned int file_id, unsigned int span_start, unsigned int span_end, zT_8F083A69_Slice_zT_0B42B2F8_u message) {
    int zT_7;
    zT_C0B2E5AF_DiagnosticArrayList* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_D3EB6303_StringInterner* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_22 = 0;
    zT_C0B2E5AF_DiagnosticArrayList* zT_23;
    zT_50FBF81E_Diagnostic zT_24;
    zT_50FBF81E_Diagnostic zT_26;
    unsigned char zT_27;
    unsigned short zT_28;
    unsigned char zT_29;
    zT_959EEC26_Arr_unsigned_int_3 zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned short zT_37;
    unsigned int zT_38;
    int zT_39;
    zT_D3EB6303_StringInterner* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_47 = 0;
    zT_C0B2E5AF_DiagnosticArrayList* zT_48;
    zT_50FBF81E_Diagnostic zT_49;
    zT_50FBF81E_Diagnostic zT_51;
    unsigned char zT_52;
    zT_959EEC26_Arr_unsigned_int_3 zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned short zT_60;
    int zT_61;
    unsigned int zT_63;
    int zT_64;
    int zT_67;
    unsigned int zT_69;
    int zT_70;
    zT_C0B2E5AF_DiagnosticArrayList* zT_73;
    unsigned int zT_74;
    int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u overflow_msg;
    unsigned int msg_id;
    zT_7 = 9999;
    if ((unsigned char)(code == zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_10 = self->diagnostics;
    zT_11 = zT_10->len;
    zT_12 = self->max_diagnostics;
    if ((unsigned char)(zT_11 >= zT_12)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = "too many errors, stopping";
    zT_17 = 25;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    overflow_msg = zT_16;
    zT_19 = self->interner;
    zT_20 = overflow_msg;
    zT_22 = zF_50C274AF_stringInternerInter(zT_19, zT_20);
    msg_id = zT_22;
    zT_23 = self->diagnostics;
    zT_27 = 0;
    zT_26.level = zT_27;
    zT_28 = 9999;
    zT_26.code = zT_28;
    zT_26.file_id = file_id;
    zT_26.span_start = span_start;
    zT_26.span_end = span_end;
    zT_26.message_id = msg_id;
    zT_29 = 0;
    zT_26.note_count = zT_29;
    zT_31 = 0;
    zT_32 = 0;
    zT_30[zT_32] = zT_31;
    zT_33 = 0;
    zT_34 = 1;
    zT_30[zT_34] = zT_33;
    zT_35 = 0;
    zT_36 = 2;
    zT_30[zT_36] = zT_35;
    (void)zT_26.note_ids;
    {
    unsigned int _j = 0;
    while (_j < sizeof(zT_26.note_ids)) {
        ((unsigned char*)&zT_26.note_ids)[_j] = ((unsigned char*)&zT_30)[_j];
        _j++;
    }
}
    zT_37 = 0;
    zT_26.related_span_idx = zT_37;
    zT_24 = zT_26;
    zF_075D71E7_diagnosticArrayList(zT_23, zT_24);
    zT_38 = self->error_count;
    zT_39 = 1;
    self->error_count = (unsigned int)(zT_38 + (unsigned int)((unsigned int)zT_39));
    return (unsigned int)(0);
    z_bb_4:
    zT_44 = self->interner;
    zT_45 = message;
    zT_47 = zF_50C274AF_stringInternerInter(zT_44, zT_45);
    msg_id = zT_47;
    zT_48 = self->diagnostics;
    zT_51.level = level;
    zT_51.code = code;
    zT_51.file_id = file_id;
    zT_51.span_start = span_start;
    zT_51.span_end = span_end;
    zT_51.message_id = msg_id;
    zT_52 = 0;
    zT_51.note_count = zT_52;
    zT_54 = 0;
    zT_55 = 0;
    zT_53[zT_55] = zT_54;
    zT_56 = 0;
    zT_57 = 1;
    zT_53[zT_57] = zT_56;
    zT_58 = 0;
    zT_59 = 2;
    zT_53[zT_59] = zT_58;
    (void)zT_51.note_ids;
    {
    unsigned int _j = 0;
    while (_j < sizeof(zT_51.note_ids)) {
        ((unsigned char*)&zT_51.note_ids)[_j] = ((unsigned char*)&zT_53)[_j];
        _j++;
    }
}
    zT_60 = 0;
    zT_51.related_span_idx = zT_60;
    zT_49 = zT_51;
    zF_075D71E7_diagnosticArrayList(zT_48, zT_49);
    zT_61 = 0;
    if ((unsigned char)(level == zT_61)) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_63 = self->error_count;
    zT_64 = 1;
    self->error_count = (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64));
    goto z_bb_6;
    z_bb_6:
    zT_73 = self->diagnostics;
    zT_74 = zT_73->len;
    zT_75 = 1;
    return (unsigned int)((unsigned int)(unsigned int)(zT_74 - zT_75));
    z_bb_7:
    zT_67 = 1;
    if ((unsigned char)(level == zT_67)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_69 = self->warning_count;
    zT_70 = 1;
    self->warning_count = (unsigned int)(zT_69 + (unsigned int)((unsigned int)zT_70));
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
}

/* diagnosticCollectorHasErrors */
unsigned char zF_8F770780_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    int zT_2;
    zT_1 = self->error_count;
    zT_2 = 0;
    return (unsigned char)(zT_1 > (unsigned int)zT_2);
}

/* diagnosticCollectorErrorCount */
unsigned int zF_4BDFF7E0_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    zT_1 = self->error_count;
    return (unsigned int)((unsigned int)zT_1);
}

/* diagnosticCollectorMarkNodeOnce */
unsigned char zF_4DD9DB2D_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_21;
    unsigned int zT_23;
    int zT_24;
    zT_3E40CD83_Sand* zT_27;
    zT_0715C9B9_EU_832 zT_34 = {0};
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int* zT_45;
    unsigned int zT_46;
    int zT_47;
    unsigned int zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    int zT_53;
    unsigned int i;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* items;
    unsigned int ci;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->diag_seen_len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->diag_seen_items;
    zT_8 = zT_7[i];
    if ((unsigned char)(zT_8 == node_idx)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_14 = self->diag_seen_len;
    zT_15 = self->diag_seen_cap;
    if ((unsigned char)(zT_14 >= zT_15)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_11 = 1;
    zT_13 = i + (unsigned int)((unsigned int)zT_11);
    i = zT_13;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_18 = self->diag_seen_cap;
    if ((unsigned char)(zT_18 < (unsigned int)(16))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_50 = self->diag_seen_items;
    zT_51 = self->diag_seen_len;
    zT_50[zT_51] = node_idx;
    zT_52 = self->diag_seen_len;
    zT_53 = 1;
    self->diag_seen_len = (unsigned int)(zT_52 + (unsigned int)((unsigned int)zT_53));
    return (unsigned char)(1);
    z_bb_9:
    zT_21 = 16;
    goto z_bb_11;
    z_bb_10:
    zT_23 = self->diag_seen_cap;
    zT_24 = 2;
    zT_21 = zT_23 * zT_24;
    goto z_bb_11;
    z_bb_11:
    new_cap = zT_21;
    zT_27 = self->allocator;
    zT_34 = zF_1395EB68_sandAlloc(zT_27, (unsigned int)(new_cap * (unsigned int)(4)), (unsigned int)(4));
    zT_35 = zT_34.is_error;
    if (zT_35) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    pal_trap();
    z_bb_13:
    zT_36 = zT_34.data.payload;
    goto z_bb_14;
    z_bb_14:
    raw = zT_36;
    zT_39 = (unsigned int*)raw;
    items = zT_39;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ci = zT_42;
    goto z_bb_15;
    z_bb_15:
    zT_43 = self->diag_seen_len;
    if ((unsigned char)(ci < zT_43)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = self->diag_seen_items;
    zT_46 = zT_45[ci];
    items[ci] = zT_46;
    goto z_bb_18;
    z_bb_17:
    self->diag_seen_items = items;
    self->diag_seen_cap = new_cap;
    goto z_bb_8;
    z_bb_18:
    zT_47 = 1;
    zT_49 = ci + (unsigned int)((unsigned int)zT_47);
    ci = zT_49;
    goto z_bb_15;
}

/* diagnosticCollectorWarningCount */
unsigned int zF_4AF2092E_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    unsigned int zT_1;
    zT_1 = self->warning_count;
    return (unsigned int)((unsigned int)zT_1);
}

/* diagnosticCollectorAddNote */
void zF_426E1F18_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int diag_idx, zT_8F083A69_Slice_zT_0B42B2F8_u note) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_3;
    unsigned int zT_4;
    zT_C0B2E5AF_DiagnosticArrayList* zT_8;
    zT_50FBF81E_Diagnostic* zT_9;
    zT_50FBF81E_Diagnostic* zT_11;
    unsigned char zT_12;
    int zT_13;
    zT_D3EB6303_StringInterner* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_18 = 0;
    unsigned int* zT_19;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned char zT_22;
    int zT_23;
    zT_50FBF81E_Diagnostic* d;
    zT_3 = self->diagnostics;
    zT_4 = zT_3->len;
    if ((unsigned char)(diag_idx >= (unsigned int)((unsigned int)zT_4))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self->diagnostics;
    zT_9 = zT_8->items;
    zT_11 = zT_9 + (unsigned int)((unsigned int)diag_idx);
    d = zT_11;
    zT_12 = d->note_count;
    zT_13 = 3;
    if ((unsigned char)(zT_12 < zT_13)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self->interner;
    zT_16 = note;
    zT_18 = zF_50C274AF_stringInternerInter(zT_15, zT_16);
    zT_19 = d->note_ids;
    zT_20 = d->note_count;
    zT_21 = (unsigned int)zT_20;
    zT_19[zT_21] = zT_18;
    zT_22 = d->note_count;
    zT_23 = 1;
    d->note_count = (unsigned char)(zT_22 + (unsigned char)((unsigned char)zT_23));
    goto z_bb_4;
    z_bb_4:
    return;
}

/* diagnosticCollectorAddRelatedSpan */
void zF_A9049B03_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int diag_idx, unsigned int file_id, unsigned int span_start, unsigned int span_end, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_6;
    unsigned int zT_7;
    zT_D3EB6303_StringInterner* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_14 = 0;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_24;
    int zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    int zT_30;
    zT_3E40CD83_Sand* zT_33;
    zT_B258D528_RelatedSpan* zT_39;
    unsigned int zT_41;
    zT_6A32A83C_Opt_238 zT_47 = {0};
    unsigned char zT_48;
    unsigned int zT_51;
    zT_3E40CD83_Sand* zT_53;
    unsigned int zT_54;
    zT_0715C9B9_EU_832 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    zT_B258D528_RelatedSpan* zT_63;
    zT_B258D528_RelatedSpan* zT_64;
    unsigned int zT_65;
    int zT_66;
    zT_B258D528_RelatedSpan* zT_67;
    unsigned int zT_68;
    zT_1E07C3E5_Slice_zT_B258D528_R zT_69;
    zT_B258D528_RelatedSpan* zT_70;
    unsigned int zT_71;
    unsigned int zT_76;
    unsigned int zT_79;
    zT_3E40CD83_Sand* zT_81;
    unsigned int zT_82;
    zT_0715C9B9_EU_832 zT_86 = {0};
    unsigned char zT_87;
    unsigned char* zT_88;
    zT_B258D528_RelatedSpan* zT_91;
    zT_B258D528_RelatedSpan* zT_92;
    unsigned int zT_93;
    int zT_94;
    zT_B258D528_RelatedSpan* zT_95;
    unsigned int zT_96;
    zT_1E07C3E5_Slice_zT_B258D528_R zT_97;
    zT_B258D528_RelatedSpan* zT_98;
    unsigned int zT_99;
    unsigned int zT_104;
    zT_B258D528_RelatedSpan zT_105;
    zT_B258D528_RelatedSpan* zT_106;
    unsigned int zT_107;
    unsigned int zT_109;
    unsigned short zT_110;
    unsigned int zT_111;
    int zT_112;
    zT_C0B2E5AF_DiagnosticArrayList* zT_115;
    zT_50FBF81E_Diagnostic* zT_116;
    zT_50FBF81E_Diagnostic* zT_118;
    unsigned int msg_id;
    unsigned int new_len;
    unsigned int new_cap;
    unsigned short rs_idx;
    zT_6A32A83C_Opt_238 grown;
    unsigned int sz;
    unsigned char* raw;
    zT_B258D528_RelatedSpan* items;
    zT_B258D528_RelatedSpan item;
    unsigned int i;
    zT_B258D528_RelatedSpan item_1;
    unsigned int i_2;
    zT_6 = self->diagnostics;
    zT_7 = zT_6->len;
    if ((unsigned char)(diag_idx >= (unsigned int)((unsigned int)zT_7))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_11 = self->interner;
    zT_12 = msg;
    zT_14 = zF_50C274AF_stringInternerInter(zT_11, zT_12);
    msg_id = zT_14;
    zT_16 = self->related_span_len;
    zT_18 = zT_16 + (unsigned int)(1);
    new_len = zT_18;
    zT_19 = self->related_span_cap;
    if ((unsigned char)(new_len >= zT_19)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_22 = self->related_span_cap;
    zT_23 = 2;
    zT_24 = zT_22 * zT_23;
    new_cap = zT_24;
    zT_25 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_25)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_105.span_file_id = file_id;
    zT_105.span_start = span_start;
    zT_105.span_end = span_end;
    zT_105.message_id = msg_id;
    zT_106 = self->related_span_items;
    zT_107 = self->related_span_len;
    zT_106[zT_107] = zT_105;
    zT_109 = self->related_span_len;
    zT_110 = (unsigned short)zT_109;
    rs_idx = zT_110;
    zT_111 = self->related_span_len;
    zT_112 = 1;
    self->related_span_len = (unsigned int)(zT_111 + (unsigned int)((unsigned int)zT_112));
    zT_115 = self->diagnostics;
    zT_116 = zT_115->items;
    zT_118 = zT_116 + (unsigned int)((unsigned int)diag_idx);
    zT_118->related_span_idx = rs_idx;
    return;
    z_bb_5:
    zT_27 = 8;
    zT_28 = (unsigned int)zT_27;
    new_cap = zT_28;
    goto z_bb_6;
    z_bb_6:
    zT_29 = self->related_span_cap;
    zT_30 = 0;
    if ((unsigned char)(zT_29 > (unsigned int)zT_30)) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_33 = self->allocator;
    zT_39 = self->related_span_items;
    zT_41 = self->related_span_cap;
    zT_47 = zF_33A3D4F8_sandTryReallocInPla(zT_33, (unsigned char*)((unsigned char*)zT_39), (unsigned int)(zT_41 * (unsigned int)(16)), (unsigned int)(new_cap * (unsigned int)(16)), (unsigned int)(4));
    grown = zT_47;
    zT_48 = grown.has_value;
    if (zT_48) goto z_bb_10; else goto z_bb_12;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_79 = (unsigned int)(16) * new_cap;
    sz = zT_79;
    zT_81 = self->allocator;
    zT_82 = sz;
    zT_86 = zF_1395EB68_sandAlloc(zT_81, zT_82, (unsigned int)(4));
    zT_87 = zT_86.is_error;
    if (zT_87) goto z_bb_19; else goto z_bb_20;
    z_bb_10:
    self->related_span_cap = new_cap;
    goto z_bb_11;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_51 = (unsigned int)(16) * new_cap;
    sz = zT_51;
    zT_53 = self->allocator;
    zT_54 = sz;
    zT_58 = zF_1395EB68_sandAlloc(zT_53, zT_54, (unsigned int)(4));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    pal_trap();
    z_bb_14:
    zT_60 = zT_58.data.payload;
    goto z_bb_15;
    z_bb_15:
    raw = zT_60;
    zT_63 = (zT_B258D528_RelatedSpan*)raw;
    items = zT_63;
    zT_64 = self->related_span_items;
    zT_65 = self->related_span_len;
    zT_66 = 0;
    zT_67 = zT_64 + zT_66;
    zT_68 = zT_65 - zT_66;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_70 = zT_69.ptr;
    zT_71 = zT_69.len;
    i = 0;
    goto z_bb_16;
    z_bb_16:
    if ((unsigned char)(i < zT_71)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    item = zT_70[i];
    items[i] = item;
    zT_76 = i + (unsigned int)(1);
    i = zT_76;
    goto z_bb_16;
    z_bb_18:
    self->related_span_items = items;
    self->related_span_cap = new_cap;
    goto z_bb_11;
    z_bb_19:
    pal_trap();
    z_bb_20:
    zT_88 = zT_86.data.payload;
    goto z_bb_21;
    z_bb_21:
    raw = zT_88;
    zT_91 = (zT_B258D528_RelatedSpan*)raw;
    items = zT_91;
    zT_92 = self->related_span_items;
    zT_93 = self->related_span_len;
    zT_94 = 0;
    zT_95 = zT_92 + zT_94;
    zT_96 = zT_93 - zT_94;
    zT_97.ptr = zT_95;
    zT_97.len = zT_96;
    zT_98 = zT_97.ptr;
    zT_99 = zT_97.len;
    i_2 = 0;
    goto z_bb_22;
    z_bb_22:
    if ((unsigned char)(i_2 < zT_99)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    item_1 = zT_98[i_2];
    items[i_2] = item_1;
    zT_104 = i_2 + (unsigned int)(1);
    i_2 = zT_104;
    goto z_bb_22;
    z_bb_24:
    self->related_span_items = items;
    self->related_span_cap = new_cap;
    goto z_bb_8;
}

/* diagnosticCollectorFlushAndExit */
void zF_E7E26C7E_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self, unsigned int exit_code) {
    zT_F85C5DED_DiagnosticCollector* zT_2;
    zT_2 = self;
    zF_8E894A93_diagnosticCollector(zT_2);
    zF_CDED1A85_exit((unsigned char)((unsigned char)exit_code));
    return;
}

/* diagnosticBuilderMakeMsg */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8C4BFF7C_diagnosticBuilderMa(zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u* parts, unsigned int count) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_17;
    zT_3E40CD83_Sand* zT_19;
    unsigned int zT_20;
    int zT_23;
    zT_0715C9B9_EU_832 zT_25 = {0};
    unsigned char zT_26;
    unsigned char* zT_27;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    int zT_48;
    unsigned int zT_49;
    unsigned int zT_51;
    unsigned char* zT_53;
    unsigned char zT_54;
    unsigned char* zT_55;
    int zT_56;
    unsigned int zT_58;
    int zT_59;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_64;
    zT_D3EB6303_StringInterner* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68 = 0;
    zT_D3EB6303_StringInterner* zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71 = {0};
    unsigned int total;
    unsigned int ci;
    unsigned char* raw;
    zT_8F083A69_Slice_zT_0B42B2F8_u fallback;
    zT_8F083A69_Slice_zT_0B42B2F8_u buf;
    unsigned int pos;
    zT_8F083A69_Slice_zT_0B42B2F8_u part;
    unsigned int pi;
    unsigned int sid;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    total = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ci = zT_8;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(ci < count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = (unsigned int)ci;
    zT_11 = parts[zT_10];
    zT_13 = zT_11.len;
    zT_14 = total + zT_13;
    total = zT_14;
    goto z_bb_4;
    z_bb_3:
    zT_19 = interner->allocator;
    zT_20 = total;
    zT_23 = 1;
    zT_25 = zF_1395EB68_sandAlloc(zT_19, zT_20, (unsigned int)((unsigned int)zT_23));
    zT_26 = zT_25.is_error;
    if (zT_26) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_15 = 1;
    zT_17 = ci + (unsigned int)((unsigned int)zT_15);
    ci = zT_17;
    goto z_bb_1;
    z_bb_5:
    zT_29 = "diagnostic message too long";
    zT_31 = 27;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    fallback = zT_30;
    return fallback;
    z_bb_6:
    zT_27 = zT_25.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_27;
    zT_34 = 0;
    zT_35 = raw + zT_34;
    zT_36 = total - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    buf = zT_37;
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    pos = zT_40;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ci = zT_42;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(ci < count)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_45 = (unsigned int)ci;
    zT_46 = parts[zT_45];
    part = zT_46;
    zT_48 = 0;
    zT_49 = (unsigned int)zT_48;
    pi = zT_49;
    goto z_bb_12;
    z_bb_10:
    zT_66 = interner;
    zT_67 = buf;
    zT_68 = zF_50C274AF_stringInternerInter(zT_66, zT_67);
    sid = zT_68;
    zT_69 = interner;
    zT_70 = sid;
    zT_71 = zF_9134020D_stringInternerGet(zT_69, zT_70);
    return zT_71;
    z_bb_11:
    zT_62 = 1;
    zT_64 = ci + (unsigned int)((unsigned int)zT_62);
    ci = zT_64;
    goto z_bb_8;
    z_bb_12:
    zT_51 = part.len;
    if ((unsigned char)(pi < zT_51)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_53 = part.ptr;
    zT_54 = zT_53[pi];
    zT_55 = buf.ptr;
    zT_55[pos] = zT_54;
    zT_56 = 1;
    zT_58 = pos + (unsigned int)((unsigned int)zT_56);
    pos = zT_58;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_59 = 1;
    zT_61 = pi + (unsigned int)((unsigned int)zT_59);
    pi = zT_61;
    goto z_bb_12;
}

/* diagnosticCollectorPrintAll */
void zF_8E894A93_diagnosticCollector(zT_F85C5DED_DiagnosticCollector* self) {
    zT_C0B2E5AF_DiagnosticArrayList* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_227EDE07_SourceManager* zT_5;
    zT_C0B2E5AF_DiagnosticArrayList* zT_8;
    zT_8D25846A_Slice_zT_50FBF81E_D zT_10 = {0};
    zT_8D25846A_Slice_zT_50FBF81E_D zT_11;
    int zT_13;
    unsigned int zT_14;
    zT_C0B2E5AF_DiagnosticArrayList* zT_15;
    unsigned int zT_16;
    zT_50FBF81E_Diagnostic* zT_19;
    zT_50FBF81E_Diagnostic* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27 = {0};
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    zT_C1AB0454_Arr_unsigned_char_8 zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned short zT_38;
    int zT_42;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned char* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_D3EB6303_StringInterner* zT_68;
    zT_EABC94D3_InternEntry* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_EABC94D3_InternEntry zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    int zT_80;
    unsigned int zT_82;
    zT_227EDE07_SourceManager* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_5BC08DC6_Location zT_90 = {0};
    zT_227EDE07_SourceManager* zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    zT_5426B97B_Arr_unsigned_char_1 zT_104;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    int zT_111;
    int zT_112;
    unsigned char* zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116 = 0;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned char* zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    zT_5426B97B_Arr_unsigned_char_1 zT_134;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    int zT_141;
    int zT_142;
    unsigned char* zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146 = 0;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned char* zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned char zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166 = {0};
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    zT_C1AB0454_Arr_unsigned_char_8 zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned short zT_177;
    int zT_181;
    int zT_182;
    unsigned char* zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186 = 0;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned char* zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    zT_D3EB6303_StringInterner* zT_207;
    zT_EABC94D3_InternEntry* zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    zT_EABC94D3_InternEntry zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_213;
    unsigned char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned char* zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    zT_227EDE07_SourceManager* zT_225;
    unsigned int zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229 = {0};
    zT_227EDE07_SourceManager* zT_231;
    unsigned int zT_232;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_235 = {0};
    zT_3CB0179A_Slice_zT_05F374B1_u zT_237;
    unsigned int zT_238;
    unsigned int zT_240 = 0;
    unsigned int* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    unsigned int zT_248;
    int zT_250;
    unsigned int zT_251;
    unsigned int zT_253;
    unsigned int* zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    int zT_260;
    unsigned char zT_262;
    unsigned char* zT_263;
    int zT_264;
    unsigned int zT_265;
    unsigned char zT_266;
    int zT_269;
    unsigned int zT_271;
    unsigned char zT_275;
    unsigned int zT_277;
    unsigned char* zT_280;
    unsigned char* zT_282;
    unsigned int zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_285;
    unsigned char* zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_298;
    int zT_299;
    int zT_301;
    unsigned int zT_302;
    zT_22590979_Arr_unsigned_char_2 zT_304;
    int zT_306;
    unsigned int zT_307;
    int zT_309;
    int zT_311;
    unsigned int zT_312;
    unsigned char zT_315;
    int zT_316;
    unsigned int zT_318;
    unsigned int zT_320;
    int zT_322;
    int zT_325;
    unsigned int zT_326;
    int zT_328;
    int zT_331;
    unsigned int zT_332;
    unsigned char zT_335;
    int zT_336;
    unsigned int zT_338;
    unsigned int zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    int zT_344;
    unsigned char* zT_345;
    unsigned int zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    unsigned char* zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned int zT_351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_352;
    int zT_354;
    unsigned char zT_355;
    unsigned char zT_356;
    unsigned char* zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    unsigned int zT_361;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_362;
    zT_D3EB6303_StringInterner* zT_364;
    zT_EABC94D3_InternEntry* zT_365;
    unsigned int* zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    unsigned int zT_369;
    zT_EABC94D3_InternEntry zT_370;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_372;
    unsigned char* zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    unsigned int zT_376;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_377;
    int zT_378;
    unsigned char zT_380;
    unsigned short zT_381;
    int zT_382;
    unsigned char zT_384;
    unsigned short zT_385;
    unsigned int zT_386;
    zT_B258D528_RelatedSpan* zT_390;
    unsigned short zT_391;
    unsigned int zT_392;
    zT_B258D528_RelatedSpan zT_393;
    zT_227EDE07_SourceManager* zT_395;
    unsigned int zT_396;
    unsigned int zT_397;
    zT_5BC08DC6_Location zT_401 = {0};
    zT_227EDE07_SourceManager* zT_403;
    unsigned int zT_404;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_408;
    unsigned char* zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_412;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_413;
    zT_5426B97B_Arr_unsigned_char_1 zT_415;
    unsigned int zT_417;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_418;
    int zT_422;
    int zT_423;
    unsigned char* zT_424;
    unsigned int zT_425;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_426;
    unsigned int zT_427 = 0;
    unsigned int zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_432;
    unsigned char* zT_436;
    unsigned int zT_437;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_438;
    unsigned char* zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_441;
    unsigned int zT_442;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_443;
    zT_D3EB6303_StringInterner* zT_445;
    zT_EABC94D3_InternEntry* zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    zT_EABC94D3_InternEntry zT_449;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_450;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    unsigned char* zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_454;
    unsigned int zT_455;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_456;
    int zT_457;
    unsigned int zT_459;
    zT_8D25846A_Slice_zT_50FBF81E_D diags;
    unsigned int i;
    zT_50FBF81E_Diagnostic* d;
    zT_8F083A69_Slice_zT_0B42B2F8_u lb0;
    zT_C1AB0454_Arr_unsigned_char_8 code_buf0;
    unsigned int code_len0;
    unsigned int kcs0;
    zT_8F083A69_Slice_zT_0B42B2F8_u rb0;
    zT_5BC08DC6_Location loc;
    zT_8F083A69_Slice_zT_0B42B2F8_u fname;
    zT_8F083A69_Slice_zT_0B42B2F8_u col_s;
    zT_5426B97B_Arr_unsigned_char_1 line_buf;
    unsigned int line_len;
    unsigned int ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u col_s2;
    zT_5426B97B_Arr_unsigned_char_1 col_buf;
    unsigned int col_len;
    unsigned int cs;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep;
    zT_8F083A69_Slice_zT_0B42B2F8_u lb;
    zT_C1AB0454_Arr_unsigned_char_8 code_buf;
    unsigned int code_len;
    unsigned int kcs;
    zT_8F083A69_Slice_zT_0B42B2F8_u rb;
    zT_EABC94D3_InternEntry entry0;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl0;
    zT_EABC94D3_InternEntry entry;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    zT_3CB0179A_Slice_zT_05F374B1_u offsets;
    unsigned int line_idx;
    unsigned int line_start;
    unsigned int line_end;
    unsigned int next_line;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    unsigned int l_start;
    unsigned int l_end;
    zT_8F083A69_Slice_zT_0B42B2F8_u line_text;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl2;
    unsigned int loc_col;
    unsigned int cspan;
    unsigned char n;
    zT_22590979_Arr_unsigned_char_2 caret_buf;
    unsigned int caret_len;
    unsigned int space_count;
    unsigned int _;
    unsigned int ulen;
    unsigned int max_carets;
    unsigned int __1;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl3;
    zT_8F083A69_Slice_zT_0B42B2F8_u note_hdr;
    zT_EABC94D3_InternEntry note_entry;
    zT_8F083A69_Slice_zT_0B42B2F8_u note_nl;
    zT_B258D528_RelatedSpan rs;
    zT_5BC08DC6_Location rs_loc;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_fname;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_col_s;
    zT_5426B97B_Arr_unsigned_char_1 rs_line_buf;
    unsigned int rs_line_len;
    unsigned int rls;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_sep;
    zT_EABC94D3_InternEntry rs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs_nl;
    zT_1 = self->diagnostics;
    zT_2 = zT_1->len;
    zT_3 = 0;
    if ((unsigned char)(zT_2 == (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->source_manager;
    zF_196FDF3B_sourceManagerResetF(zT_5);
    zT_8 = self->diagnostics;
    zT_10 = zF_88E8322D_diagnosticArrayList(zT_8);
    diags = zT_10;
    zT_11 = diags;
    zF_F6BADF23_sortDiagnostics(zT_11);
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    i = zT_14;
    goto z_bb_3;
    z_bb_3:
    zT_15 = self->diagnostics;
    zT_16 = zT_15->len;
    if ((unsigned char)(i < zT_16)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = diags.ptr;
    zT_20 = zT_19 + i;
    d = zT_20;
    zT_21 = d->file_id;
    if ((unsigned char)(zT_21 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_25 = d->level;
    zT_27 = zF_1620F424_getLevelName(zT_25);
    zT_24 = zT_27;
    zF_76BE513B_writeStr(zT_24);
    zT_29 = "[";
    zT_31 = 1;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    lb0 = zT_30;
    zT_32 = lb0;
    zF_76BE513B_writeStr(zT_32);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_34[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        code_buf0[_i] = zT_34[_i];
        _i++;
    }
}
    zT_38 = d->code;
    zT_42 = 8;
    zT_43 = 0;
    zT_44 = (unsigned char*)((unsigned char*)code_buf0) + zT_43;
    zT_45 = zT_42 - zT_43;
    zT_46.ptr = zT_44;
    zT_46.len = zT_45;
    zT_37 = zT_46;
    zT_47 = zF_2FED9490_formatU32((unsigned int)((unsigned int)zT_38), zT_37);
    code_len0 = zT_47;
    zT_51 = (unsigned int)(8) - (unsigned int)((unsigned int)code_len0);
    kcs0 = zT_51;
    zT_56 = (unsigned char*)((unsigned char*)code_buf0) + kcs0;
    zT_57 = (unsigned int)(8) - kcs0;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_52 = zT_58;
    zF_76BE513B_writeStr(zT_52);
    zT_60 = "]: ";
    zT_62 = 3;
    zT_61.ptr = zT_60;
    zT_61.len = zT_62;
    rb0 = zT_61;
    zT_63 = rb0;
    zF_76BE513B_writeStr(zT_63);
    zT_64 = d->message_id;
    if ((unsigned char)(zT_64 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_84 = self->source_manager;
    zT_85 = d->file_id;
    zT_86 = d->span_start;
    zT_90 = zF_4966CE4A_sourceManagerGetLoc(zT_84, zT_85, zT_86);
    loc = zT_90;
    zT_92 = self->source_manager;
    zT_93 = d->file_id;
    zT_96 = zF_B7076474_sourceManagerGetFil(zT_92, zT_93);
    fname = zT_96;
    zT_97 = fname;
    zF_76BE513B_writeStr(zT_97);
    zT_99 = ":";
    zT_101 = 1;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    col_s = zT_100;
    zT_102 = col_s;
    zF_76BE513B_writeStr(zT_102);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_104[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        line_buf[_i] = zT_104[_i];
        _i++;
    }
}
    zT_106 = loc.line;
    zT_111 = 16;
    zT_112 = 0;
    zT_113 = (unsigned char*)((unsigned char*)line_buf) + zT_112;
    zT_114 = zT_111 - zT_112;
    zT_115.ptr = zT_113;
    zT_115.len = zT_114;
    zT_107 = zT_115;
    zT_116 = zF_2FED9490_formatU32(zT_106, zT_107);
    line_len = zT_116;
    zT_120 = (unsigned int)(16) - (unsigned int)((unsigned int)line_len);
    ls = zT_120;
    zT_125 = (unsigned char*)((unsigned char*)line_buf) + ls;
    zT_126 = (unsigned int)(16) - ls;
    zT_127.ptr = zT_125;
    zT_127.len = zT_126;
    zT_121 = zT_127;
    zF_76BE513B_writeStr(zT_121);
    zT_129 = ":";
    zT_131 = 1;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    col_s2 = zT_130;
    zT_132 = col_s2;
    zF_76BE513B_writeStr(zT_132);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_134[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        col_buf[_i] = zT_134[_i];
        _i++;
    }
}
    zT_136 = loc.col;
    zT_141 = 16;
    zT_142 = 0;
    zT_143 = (unsigned char*)((unsigned char*)col_buf) + zT_142;
    zT_144 = zT_141 - zT_142;
    zT_145.ptr = zT_143;
    zT_145.len = zT_144;
    zT_137 = zT_145;
    zT_146 = zF_2FED9490_formatU32(zT_136, zT_137);
    col_len = zT_146;
    zT_150 = (unsigned int)(16) - (unsigned int)((unsigned int)col_len);
    cs = zT_150;
    zT_155 = (unsigned char*)((unsigned char*)col_buf) + cs;
    zT_156 = (unsigned int)(16) - cs;
    zT_157.ptr = zT_155;
    zT_157.len = zT_156;
    zT_151 = zT_157;
    zF_76BE513B_writeStr(zT_151);
    zT_159 = ": ";
    zT_161 = 2;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    sep = zT_160;
    zT_162 = sep;
    zF_76BE513B_writeStr(zT_162);
    zT_164 = d->level;
    zT_166 = zF_1620F424_getLevelName(zT_164);
    zT_163 = zT_166;
    zF_76BE513B_writeStr(zT_163);
    zT_168 = "[";
    zT_170 = 1;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    lb = zT_169;
    zT_171 = lb;
    zF_76BE513B_writeStr(zT_171);
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_173[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        code_buf[_i] = zT_173[_i];
        _i++;
    }
}
    zT_177 = d->code;
    zT_181 = 8;
    zT_182 = 0;
    zT_183 = (unsigned char*)((unsigned char*)code_buf) + zT_182;
    zT_184 = zT_181 - zT_182;
    zT_185.ptr = zT_183;
    zT_185.len = zT_184;
    zT_176 = zT_185;
    zT_186 = zF_2FED9490_formatU32((unsigned int)((unsigned int)zT_177), zT_176);
    code_len = zT_186;
    zT_190 = (unsigned int)(8) - (unsigned int)((unsigned int)code_len);
    kcs = zT_190;
    zT_195 = (unsigned char*)((unsigned char*)code_buf) + kcs;
    zT_196 = (unsigned int)(8) - kcs;
    zT_197.ptr = zT_195;
    zT_197.len = zT_196;
    zT_191 = zT_197;
    zF_76BE513B_writeStr(zT_191);
    zT_199 = "]: ";
    zT_201 = 3;
    zT_200.ptr = zT_199;
    zT_200.len = zT_201;
    rb = zT_200;
    zT_202 = rb;
    zF_76BE513B_writeStr(zT_202);
    zT_203 = d->message_id;
    if ((unsigned char)(zT_203 != (unsigned int)(0))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_68 = self->interner;
    zT_69 = zT_68->entries_items;
    zT_70 = d->message_id;
    zT_71 = (unsigned int)zT_70;
    zT_72 = zT_69[zT_71];
    entry0 = zT_72;
    zT_74 = entry0.text;
    zT_73 = zT_74;
    zF_76BE513B_writeStr(zT_73);
    goto z_bb_10;
    z_bb_10:
    zT_76 = "\n";
    zT_78 = 1;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    nl0 = zT_77;
    zT_79 = nl0;
    zF_76BE513B_writeStr(zT_79);
    zT_80 = 1;
    zT_82 = i + (unsigned int)((unsigned int)zT_80);
    i = zT_82;
    goto z_bb_6;
    z_bb_11:
    zT_207 = self->interner;
    zT_208 = zT_207->entries_items;
    zT_209 = d->message_id;
    zT_210 = (unsigned int)zT_209;
    zT_211 = zT_208[zT_210];
    entry = zT_211;
    zT_213 = entry.text;
    zT_212 = zT_213;
    zF_76BE513B_writeStr(zT_212);
    goto z_bb_12;
    z_bb_12:
    zT_220 = "\n";
    zT_222 = 1;
    zT_221.ptr = zT_220;
    zT_221.len = zT_222;
    nl = zT_221;
    zT_223 = nl;
    zF_76BE513B_writeStr(zT_223);
    zT_225 = self->source_manager;
    zT_226 = d->file_id;
    zT_229 = zF_FFE72B39_sourceManagerGetSou(zT_225, zT_226);
    content = zT_229;
    zT_231 = self->source_manager;
    zT_232 = d->file_id;
    zT_235 = zF_5041A561_sourceManagerGetLin(zT_231, zT_232);
    offsets = zT_235;
    zT_237 = offsets;
    zT_238 = d->span_start;
    zT_240 = zF_1457D8A5_binary_search(zT_237, zT_238);
    line_idx = zT_240;
    zT_242 = offsets.ptr;
    zT_243 = (unsigned int)line_idx;
    zT_244 = zT_242[zT_243];
    zT_245 = (unsigned int)zT_244;
    line_start = zT_245;
    zT_248 = content.len;
    line_end = zT_248;
    zT_250 = 1;
    zT_251 = line_idx + zT_250;
    next_line = zT_251;
    zT_253 = offsets.len;
    if ((unsigned char)(next_line < (unsigned int)((unsigned int)zT_253))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_215 = "(no message)";
    zT_217 = 12;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    em = zT_216;
    zT_218 = em;
    zF_76BE513B_writeStr(zT_218);
    goto z_bb_12;
    z_bb_14:
    zT_256 = offsets.ptr;
    zT_257 = (unsigned int)next_line;
    zT_258 = zT_256[zT_257];
    zT_259 = (unsigned int)zT_258;
    line_end = zT_259;
    zT_260 = 0;
    if ((unsigned char)(line_end > (unsigned int)zT_260)) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    l_start = line_start;
    l_end = line_end;
    if ((unsigned char)(l_start < l_end)) goto z_bb_21; else goto z_bb_22;
    z_bb_16:
    zT_263 = content.ptr;
    zT_264 = 1;
    zT_265 = line_end - zT_264;
    zT_266 = zT_263[zT_265];
    zT_262 = zT_266 == (unsigned char)(10);
    goto z_bb_18;
    z_bb_17:
    zT_262 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_262) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_269 = 1;
    zT_271 = line_end - (unsigned int)((unsigned int)zT_269);
    line_end = zT_271;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
    z_bb_21:
    zT_277 = content.len;
    zT_275 = l_end <= zT_277;
    goto z_bb_23;
    z_bb_22:
    zT_275 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_275) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_280 = content.ptr;
    zT_282 = zT_280 + l_start;
    zT_283 = l_end - l_start;
    zT_284.ptr = zT_282;
    zT_284.len = zT_283;
    line_text = zT_284;
    zT_285 = line_text;
    zF_76BE513B_writeStr(zT_285);
    zT_287 = "\n";
    zT_289 = 1;
    zT_288.ptr = zT_287;
    zT_288.len = zT_289;
    nl2 = zT_288;
    zT_290 = nl2;
    zF_76BE513B_writeStr(zT_290);
    zT_292 = loc.col;
    zT_293 = (unsigned int)zT_292;
    loc_col = zT_293;
    zT_295 = d->span_end;
    zT_296 = d->span_start;
    zT_298 = (unsigned int)(unsigned int)(zT_295 - zT_296);
    cspan = zT_298;
    zT_299 = 0;
    if ((unsigned char)(cspan == (unsigned int)zT_299)) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    zT_354 = 0;
    zT_355 = (unsigned char)zT_354;
    n = zT_355;
    goto z_bb_40;
    z_bb_26:
    zT_301 = 1;
    zT_302 = (unsigned int)zT_301;
    cspan = zT_302;
    goto z_bb_27;
    z_bb_27:
    {
    unsigned int _i = 0;
    while (_i < 256) {
        zT_304[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 256) {
        caret_buf[_i] = zT_304[_i];
        _i++;
    }
}
    zT_306 = 0;
    zT_307 = (unsigned int)zT_306;
    caret_len = zT_307;
    space_count = loc_col;
    zT_309 = 256;
    if ((unsigned char)(space_count > (unsigned int)zT_309)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_311 = 256;
    zT_312 = (unsigned int)zT_311;
    space_count = zT_312;
    goto z_bb_29;
    z_bb_29:
    _ = 0;
    goto z_bb_30;
    z_bb_30:
    if ((unsigned char)((unsigned int)_ < space_count)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_315 = 32;
    caret_buf[caret_len] = zT_315;
    zT_316 = 1;
    zT_318 = caret_len + (unsigned int)((unsigned int)zT_316);
    caret_len = zT_318;
    zT_320 = _ + (unsigned int)(1);
    _ = zT_320;
    goto z_bb_30;
    z_bb_32:
    ulen = cspan;
    zT_322 = 256;
    if ((unsigned char)(ulen > (unsigned int)(zT_322 - loc_col))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_325 = 256;
    zT_326 = zT_325 - loc_col;
    ulen = zT_326;
    goto z_bb_34;
    z_bb_34:
    max_carets = ulen;
    zT_328 = 256;
    if ((unsigned char)(max_carets > (unsigned int)(zT_328 - caret_len))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_331 = 256;
    zT_332 = zT_331 - caret_len;
    max_carets = zT_332;
    goto z_bb_36;
    z_bb_36:
    __1 = 0;
    goto z_bb_37;
    z_bb_37:
    if ((unsigned char)((unsigned int)__1 < max_carets)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_335 = 94;
    caret_buf[caret_len] = zT_335;
    zT_336 = 1;
    zT_338 = caret_len + (unsigned int)((unsigned int)zT_336);
    caret_len = zT_338;
    zT_340 = __1 + (unsigned int)(1);
    __1 = zT_340;
    goto z_bb_37;
    z_bb_39:
    zT_344 = 0;
    zT_345 = (unsigned char*)((unsigned char*)caret_buf) + zT_344;
    zT_346 = caret_len - zT_344;
    zT_347.ptr = zT_345;
    zT_347.len = zT_346;
    zT_341 = zT_347;
    zF_76BE513B_writeStr(zT_341);
    zT_349 = "\n";
    zT_351 = 1;
    zT_350.ptr = zT_349;
    zT_350.len = zT_351;
    nl3 = zT_350;
    zT_352 = nl3;
    zF_76BE513B_writeStr(zT_352);
    goto z_bb_25;
    z_bb_40:
    zT_356 = d->note_count;
    if ((unsigned char)(n < zT_356)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_359 = "note: ";
    zT_361 = 6;
    zT_360.ptr = zT_359;
    zT_360.len = zT_361;
    note_hdr = zT_360;
    zT_362 = note_hdr;
    zF_76BE513B_writeStr(zT_362);
    zT_364 = self->interner;
    zT_365 = zT_364->entries_items;
    zT_366 = d->note_ids;
    zT_367 = (unsigned int)n;
    zT_368 = zT_366[zT_367];
    zT_369 = (unsigned int)zT_368;
    zT_370 = zT_365[zT_369];
    note_entry = zT_370;
    zT_372 = note_entry.text;
    zT_371 = zT_372;
    zF_76BE513B_writeStr(zT_371);
    zT_374 = "\n";
    zT_376 = 1;
    zT_375.ptr = zT_374;
    zT_375.len = zT_376;
    note_nl = zT_375;
    zT_377 = note_nl;
    zF_76BE513B_writeStr(zT_377);
    zT_378 = 1;
    zT_380 = n + (unsigned char)((unsigned char)zT_378);
    n = zT_380;
    goto z_bb_43;
    z_bb_42:
    zT_381 = d->related_span_idx;
    zT_382 = 0;
    if ((unsigned char)(zT_381 > zT_382)) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_385 = d->related_span_idx;
    zT_386 = self->related_span_len;
    zT_384 = zT_385 < (unsigned short)((unsigned short)zT_386);
    goto z_bb_46;
    z_bb_45:
    zT_384 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_384) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_390 = self->related_span_items;
    zT_391 = d->related_span_idx;
    zT_392 = (unsigned int)zT_391;
    zT_393 = zT_390[zT_392];
    rs = zT_393;
    zT_395 = self->source_manager;
    zT_396 = rs.span_file_id;
    zT_397 = rs.span_start;
    zT_401 = zF_4966CE4A_sourceManagerGetLoc(zT_395, zT_396, zT_397);
    rs_loc = zT_401;
    zT_403 = self->source_manager;
    zT_404 = rs.span_file_id;
    zT_407 = zF_B7076474_sourceManagerGetFil(zT_403, zT_404);
    rs_fname = zT_407;
    zT_408 = rs_fname;
    zF_76BE513B_writeStr(zT_408);
    zT_410 = ":";
    zT_412 = 1;
    zT_411.ptr = zT_410;
    zT_411.len = zT_412;
    rs_col_s = zT_411;
    zT_413 = rs_col_s;
    zF_76BE513B_writeStr(zT_413);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_415[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        rs_line_buf[_i] = zT_415[_i];
        _i++;
    }
}
    zT_417 = rs_loc.line;
    zT_422 = 16;
    zT_423 = 0;
    zT_424 = (unsigned char*)((unsigned char*)rs_line_buf) + zT_423;
    zT_425 = zT_422 - zT_423;
    zT_426.ptr = zT_424;
    zT_426.len = zT_425;
    zT_418 = zT_426;
    zT_427 = zF_2FED9490_formatU32(zT_417, zT_418);
    rs_line_len = zT_427;
    zT_431 = (unsigned int)(16) - (unsigned int)((unsigned int)rs_line_len);
    rls = zT_431;
    zT_436 = (unsigned char*)((unsigned char*)rs_line_buf) + rls;
    zT_437 = (unsigned int)(16) - rls;
    zT_438.ptr = zT_436;
    zT_438.len = zT_437;
    zT_432 = zT_438;
    zF_76BE513B_writeStr(zT_432);
    zT_440 = ": note: ";
    zT_442 = 8;
    zT_441.ptr = zT_440;
    zT_441.len = zT_442;
    rs_sep = zT_441;
    zT_443 = rs_sep;
    zF_76BE513B_writeStr(zT_443);
    zT_445 = self->interner;
    zT_446 = zT_445->entries_items;
    zT_447 = rs.message_id;
    zT_448 = (unsigned int)zT_447;
    zT_449 = zT_446[zT_448];
    rs_msg = zT_449;
    zT_451 = rs_msg.text;
    zT_450 = zT_451;
    zF_76BE513B_writeStr(zT_450);
    zT_453 = "\n";
    zT_455 = 1;
    zT_454.ptr = zT_453;
    zT_454.len = zT_455;
    rs_nl = zT_454;
    zT_456 = rs_nl;
    zF_76BE513B_writeStr(zT_456);
    goto z_bb_48;
    z_bb_48:
    zT_457 = 1;
    zT_459 = i + (unsigned int)((unsigned int)zT_457);
    i = zT_459;
    goto z_bb_6;
}

/* typeKindSrcStr */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C14453DE_typeKindSrcStr(zT_33EF6BFB_TypeKind kind) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_void;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ctl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u8_;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_struct;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_enum;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_union;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fn;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tuple;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_type;
    zT_2 = "source: void";
    zT_4 = 12;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_void = zT_3;
    zT_6 = "source: bool";
    zT_8 = 12;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    s_bool = zT_7;
    zT_10 = "source: comptime_int";
    zT_12 = 20;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    s_ctl = zT_11;
    zT_14 = "source: i8";
    zT_16 = 10;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    s_i8 = zT_15;
    zT_18 = "source: i16";
    zT_20 = 11;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    s_i16 = zT_19;
    zT_22 = "source: i32";
    zT_24 = 11;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    s_i32 = zT_23;
    zT_26 = "source: i64";
    zT_28 = 11;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    s_i64 = zT_27;
    zT_30 = "source: u8";
    zT_32 = 10;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    s_u8_ = zT_31;
    zT_34 = "source: u16";
    zT_36 = 11;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    s_u16 = zT_35;
    zT_38 = "source: u32";
    zT_40 = 11;
    zT_39.ptr = zT_38;
    zT_39.len = zT_40;
    s_u32 = zT_39;
    zT_42 = "source: u64";
    zT_44 = 11;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    s_u64 = zT_43;
    zT_46 = "source: f32";
    zT_48 = 11;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    s_f32 = zT_47;
    zT_50 = "source: f64";
    zT_52 = 11;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    s_f64 = zT_51;
    zT_54 = "source: pointer";
    zT_56 = 15;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    s_ptr = zT_55;
    zT_58 = "source: many-pointer";
    zT_60 = 20;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_mptr = zT_59;
    zT_62 = "source: slice";
    zT_64 = 13;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    s_slice = zT_63;
    zT_66 = "source: optional";
    zT_68 = 16;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    s_opt = zT_67;
    zT_70 = "source: error-union";
    zT_72 = 19;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    s_eu = zT_71;
    zT_74 = "source: error-set";
    zT_76 = 17;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    s_es = zT_75;
    zT_78 = "source: array";
    zT_80 = 13;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    s_arr = zT_79;
    zT_82 = "source: struct";
    zT_84 = 14;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    s_struct = zT_83;
    zT_86 = "source: enum";
    zT_88 = 12;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    s_enum = zT_87;
    zT_90 = "source: union";
    zT_92 = 13;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    s_union = zT_91;
    zT_94 = "source: tagged-union";
    zT_96 = 20;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    s_tu = zT_95;
    zT_98 = "source: function";
    zT_100 = 16;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    s_fn = zT_99;
    zT_102 = "source: tuple";
    zT_104 = 13;
    zT_103.ptr = zT_102;
    zT_103.len = zT_104;
    s_tuple = zT_103;
    zT_106 = "source: null";
    zT_108 = 12;
    zT_107.ptr = zT_106;
    zT_107.len = zT_108;
    s_null = zT_107;
    zT_110 = "source: noreturn";
    zT_112 = 16;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    s_nr = zT_111;
    zT_114 = "source: type";
    zT_116 = 12;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    s_type = zT_115;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return s_void;
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return s_bool;
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return s_ctl;
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return s_i8;
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return s_i16;
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return s_i32;
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return s_i64;
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return s_u8_;
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return s_u16;
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return s_u32;
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return s_u64;
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return s_f32;
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return s_f64;
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return s_ptr;
    z_bb_28:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return s_mptr;
    z_bb_30:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return s_slice;
    z_bb_32:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return s_opt;
    z_bb_34:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return s_eu;
    z_bb_36:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return s_es;
    z_bb_38:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return s_arr;
    z_bb_40:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return s_struct;
    z_bb_42:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return s_enum;
    z_bb_44:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return s_union;
    z_bb_46:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return s_tu;
    z_bb_48:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return s_fn;
    z_bb_50:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return s_tuple;
    z_bb_52:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return s_null;
    z_bb_54:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return s_nr;
    z_bb_56:
    return s_type;
}

/* typeKindTgtStr */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_CC479241_typeKindTgtStr(zT_33EF6BFB_TypeKind kind) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_void;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bool;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ctl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i8;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_i64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u8_;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u16;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_u64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f32;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_f64;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_es;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_arr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_struct;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_enum;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_union;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tu;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fn;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_tuple;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nr;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_type;
    zT_2 = "target: void";
    zT_4 = 12;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_void = zT_3;
    zT_6 = "target: bool";
    zT_8 = 12;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    s_bool = zT_7;
    zT_10 = "target: comptime_int";
    zT_12 = 20;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    s_ctl = zT_11;
    zT_14 = "target: i8";
    zT_16 = 10;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    s_i8 = zT_15;
    zT_18 = "target: i16";
    zT_20 = 11;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    s_i16 = zT_19;
    zT_22 = "target: i32";
    zT_24 = 11;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    s_i32 = zT_23;
    zT_26 = "target: i64";
    zT_28 = 11;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    s_i64 = zT_27;
    zT_30 = "target: u8";
    zT_32 = 10;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    s_u8_ = zT_31;
    zT_34 = "target: u16";
    zT_36 = 11;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    s_u16 = zT_35;
    zT_38 = "target: u32";
    zT_40 = 11;
    zT_39.ptr = zT_38;
    zT_39.len = zT_40;
    s_u32 = zT_39;
    zT_42 = "target: u64";
    zT_44 = 11;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    s_u64 = zT_43;
    zT_46 = "target: f32";
    zT_48 = 11;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    s_f32 = zT_47;
    zT_50 = "target: f64";
    zT_52 = 11;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    s_f64 = zT_51;
    zT_54 = "target: pointer";
    zT_56 = 15;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    s_ptr = zT_55;
    zT_58 = "target: many-pointer";
    zT_60 = 20;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_mptr = zT_59;
    zT_62 = "target: slice";
    zT_64 = 13;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    s_slice = zT_63;
    zT_66 = "target: optional";
    zT_68 = 16;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    s_opt = zT_67;
    zT_70 = "target: error-union";
    zT_72 = 19;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    s_eu = zT_71;
    zT_74 = "target: error-set";
    zT_76 = 17;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    s_es = zT_75;
    zT_78 = "target: array";
    zT_80 = 13;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    s_arr = zT_79;
    zT_82 = "target: struct";
    zT_84 = 14;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    s_struct = zT_83;
    zT_86 = "target: enum";
    zT_88 = 12;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    s_enum = zT_87;
    zT_90 = "target: union";
    zT_92 = 13;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    s_union = zT_91;
    zT_94 = "target: tagged-union";
    zT_96 = 20;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    s_tu = zT_95;
    zT_98 = "target: function";
    zT_100 = 16;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    s_fn = zT_99;
    zT_102 = "target: tuple";
    zT_104 = 13;
    zT_103.ptr = zT_102;
    zT_103.len = zT_104;
    s_tuple = zT_103;
    zT_106 = "target: null";
    zT_108 = 12;
    zT_107.ptr = zT_106;
    zT_107.len = zT_108;
    s_null = zT_107;
    zT_110 = "target: noreturn";
    zT_112 = 16;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    s_nr = zT_111;
    zT_114 = "target: type";
    zT_116 = 12;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    s_type = zT_115;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return s_void;
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return s_bool;
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return s_ctl;
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return s_i8;
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return s_i16;
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return s_i32;
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return s_i64;
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return s_u8_;
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return s_u16;
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return s_u32;
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return s_u64;
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return s_f32;
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return s_f64;
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return s_ptr;
    z_bb_28:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return s_mptr;
    z_bb_30:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return s_slice;
    z_bb_32:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return s_opt;
    z_bb_34:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return s_eu;
    z_bb_36:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return s_es;
    z_bb_38:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return s_arr;
    z_bb_40:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return s_struct;
    z_bb_42:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return s_enum;
    z_bb_44:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return s_union;
    z_bb_46:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return s_tu;
    z_bb_48:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return s_fn;
    z_bb_50:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return s_tuple;
    z_bb_52:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return s_null;
    z_bb_54:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return s_nr;
    z_bb_56:
    return s_type;
}

/* __module_init */
void zF_780653D2___module_init_3(void) {
    zT_227EDE07_SourceManager zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zG_227EDE07_SourceManager = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    return;
}

/* EOF */
