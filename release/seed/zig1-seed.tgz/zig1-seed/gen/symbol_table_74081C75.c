#include "symbol_table_74081C75.h"
zT_3D7259E2_SymbolRegistry zG_3D7259E2_SymbolRegistry;
zT_060CD1EB_SymbolTable zG_060CD1EB_SymbolTable;
zT_3C598AEF_SymbolKind zG_3C598AEF_SymbolKind;
/* symbolTableInit */
zT_060CD1EB_SymbolTable zF_26192335_symbolTableInit(zT_3E40CD83_Sand* allocator) {
    zT_060CD1EB_SymbolTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_3A105EF1_Symbol*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* symbolTableEnsureCapacity */
void zF_896A798D_symbolTableEnsureCa(zT_060CD1EB_SymbolTable* self, unsigned int new_capacity) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    int zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_3E40CD83_Sand* zT_25;
    zT_3A105EF1_Symbol* zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_7834FCDD_Opt_220 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_3E40CD83_Sand* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_A62CFBCC_EU_022 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_47;
    zT_3A105EF1_Symbol* zT_49;
    zT_3A105EF1_Symbol* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_3A105EF1_Symbol* zT_53;
    unsigned int zT_54;
    zT_E0618270_Slice_zT_3A105EF1_S zT_55;
    zT_3A105EF1_Symbol* zT_56;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int nc;
    zT_7834FCDD_Opt_220 grown;
    unsigned char* raw;
    zT_3A105EF1_Symbol* new_items;
    zT_3A105EF1_Symbol item;
    unsigned int i;
    zT_2 = self->capacity;
    zT_3 = new_capacity <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_capacity;
    nc = new_capacity;
    nc = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = nc < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    zT_13 = nc < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->capacity;
    zT_17 = 0;
    zT_18 = zT_16 > (unsigned int)zT_17;
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self->allocator;
    zT_20 = zT_25;
    zT_26 = self->items;
    zT_27 = (unsigned char*)zT_26;
    zT_21 = zT_27;
    zT_28 = self->capacity;
    zT_29 = 24;
    zT_30 = zT_28 * zT_29;
    zT_22 = zT_30;
    zT_31 = 24;
    zT_32 = nc * zT_31;
    zT_23 = zT_32;
    zT_33 = 4;
    zT_24 = zT_33;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, zT_21, zT_22, zT_23, zT_24);
    grown = zT_34;
    grown = zT_34;
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_40 = self->allocator;
    zT_37 = zT_40;
    zT_41 = 24;
    zT_42 = zT_41 * nc;
    zT_38 = zT_42;
    zT_43 = 4;
    zT_39 = zT_43;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, zT_38, zT_39);
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    z_bb_12:
    zT_47 = zT_44.data.payload;
    zT_46 = zT_47;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    raw = zT_46;
    raw = zT_46;
    zT_49 = (zT_3A105EF1_Symbol*)raw;
    new_items = zT_49;
    new_items = zT_49;
    new_items = zT_49;
    zT_50 = self->items;
    zT_51 = self->len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    zT_59 = i < zT_57;
    if (zT_59) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_61 = 1;
    zT_62 = i + zT_61;
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->items = new_items;
    self->capacity = nc;
    return;
}

/* symbolTableInsert */
int zF_D0156DDA_symbolTableInsert(zT_060CD1EB_SymbolTable* self, zT_3A105EF1_Symbol sym) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_3A105EF1_Symbol* zT_7;
    zT_3A105EF1_Symbol zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    int zT_12;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_060CD1EB_SymbolTable* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_3A105EF1_Symbol* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    int zT_27;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    i = zT_4;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->len;
    zT_6 = i < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->items;
    zT_8 = zT_7[i];
    zT_9 = zT_8.name_id;
    zT_10 = sym.name_id;
    zT_11 = zT_9 == zT_10;
    if (zT_11) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_16 = self;
    zT_18 = self->len;
    zT_19 = 1;
    zT_20 = zT_18 + zT_19;
    zT_17 = zT_20;
    zF_896A798D_symbolTableEnsureCa(zT_16, zT_17);
    zT_21 = self->items;
    zT_22 = self->len;
    zT_21[zT_22] = sym;
    zT_23 = self->len;
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23 + zT_25;
    self->len = zT_26;
    zT_27 = 1;
    return zT_27;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_12 = 0;
    return zT_12;
    z_bb_6:
    zT_13 = 1;
    zT_14 = (unsigned int)zT_13;
    zT_15 = i + zT_14;
    i = zT_15;
    i = zT_15;
    goto z_bb_4;
}

/* symbolTableLookup */
zT_E68301A1_Opt_804 zF_893B79A5_symbolTableLookup(zT_060CD1EB_SymbolTable* self, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_3A105EF1_Symbol* zT_7;
    zT_3A105EF1_Symbol zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_3A105EF1_Symbol* zT_11;
    zT_3A105EF1_Symbol* zT_12;
    zT_E68301A1_Opt_804 zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_E68301A1_Opt_804 zT_17 = {0};
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    i = zT_4;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->len;
    zT_6 = i < zT_5;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->items;
    zT_8 = zT_7[i];
    zT_9 = zT_8.name_id;
    zT_10 = zT_9 == name_id;
    if (zT_10) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17.has_value = 0;
    return zT_17;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = self->items;
    zT_12 = zT_11 + i;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_6:
    zT_14 = 1;
    zT_15 = (unsigned int)zT_14;
    zT_16 = i + zT_15;
    i = zT_16;
    i = zT_16;
    goto z_bb_4;
}

/* symbolRegistryEnsureCapacity */
void zF_BCFEB408_symbolRegistryEnsur(zT_3D7259E2_SymbolRegistry* self, unsigned int new_cap) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    int zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_3E40CD83_Sand* zT_25;
    zT_060CD1EB_SymbolTable* zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_7834FCDD_Opt_220 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_3E40CD83_Sand* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_A62CFBCC_EU_022 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_47;
    zT_060CD1EB_SymbolTable* zT_49;
    zT_060CD1EB_SymbolTable* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_060CD1EB_SymbolTable* zT_53;
    unsigned int zT_54;
    zT_DD67D991_Slice_zT_060CD1EB_S zT_55;
    zT_060CD1EB_SymbolTable* zT_56;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int nc;
    zT_7834FCDD_Opt_220 grown;
    unsigned char* raw;
    zT_060CD1EB_SymbolTable* new_items;
    zT_060CD1EB_SymbolTable item;
    unsigned int i;
    zT_2 = self->tables_cap;
    zT_3 = new_cap <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    nc = new_cap;
    nc = new_cap;
    zT_5 = self->tables_cap;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = nc < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->tables_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    zT_13 = nc < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->tables_cap;
    zT_17 = 0;
    zT_18 = zT_16 > (unsigned int)zT_17;
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self->tables_alloc;
    zT_20 = zT_25;
    zT_26 = self->tables_items;
    zT_27 = (unsigned char*)zT_26;
    zT_21 = zT_27;
    zT_28 = self->tables_cap;
    zT_29 = 16;
    zT_30 = zT_28 * zT_29;
    zT_22 = zT_30;
    zT_31 = 16;
    zT_32 = nc * zT_31;
    zT_23 = zT_32;
    zT_33 = 4;
    zT_24 = zT_33;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, zT_21, zT_22, zT_23, zT_24);
    grown = zT_34;
    grown = zT_34;
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_40 = self->tables_alloc;
    zT_37 = zT_40;
    zT_41 = 16;
    zT_42 = zT_41 * nc;
    zT_38 = zT_42;
    zT_43 = 4;
    zT_39 = zT_43;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, zT_38, zT_39);
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->tables_cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    z_bb_12:
    zT_47 = zT_44.data.payload;
    zT_46 = zT_47;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    raw = zT_46;
    raw = zT_46;
    zT_49 = (zT_060CD1EB_SymbolTable*)raw;
    new_items = zT_49;
    new_items = zT_49;
    new_items = zT_49;
    zT_50 = self->tables_items;
    zT_51 = self->tables_len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    zT_59 = i < zT_57;
    if (zT_59) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_61 = 1;
    zT_62 = i + zT_61;
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->tables_items = new_items;
    self->tables_cap = nc;
    return;
}

/* symbolRegistryInit */
zT_3D7259E2_SymbolRegistry zF_09A884A8_symbolRegistryInit(zT_3E40CD83_Sand* alloc) {
    zT_3D7259E2_SymbolRegistry zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.tables_items = (zT_060CD1EB_SymbolTable*)zT_2;
    zT_3 = 0;
    zT_1.tables_len = zT_3;
    zT_4 = 0;
    zT_1.tables_cap = zT_4;
    zT_1.tables_alloc = alloc;
    return zT_1;
}

/* symbolRegistryGetTable */
zT_060CD1EB_SymbolTable* zF_9B36C202_symbolRegistryGetTa(zT_3D7259E2_SymbolRegistry* self, unsigned int module_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    zT_3D7259E2_SymbolRegistry* zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    int zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_3E40CD83_Sand* zT_14;
    zT_060CD1EB_SymbolTable zT_15 = {0};
    zT_060CD1EB_SymbolTable* zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    zT_060CD1EB_SymbolTable* zT_22;
    zT_060CD1EB_SymbolTable* zT_23;
    unsigned int idx;
    unsigned int zi;
    zT_3 = (unsigned int)module_id;
    idx = zT_3;
    idx = zT_3;
    idx = zT_3;
    zT_4 = self->tables_len;
    zT_5 = idx >= zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zT_8 = 1;
    zT_9 = idx + zT_8;
    zT_7 = zT_9;
    zF_BCFEB408_symbolRegistryEnsur(zT_6, zT_7);
    zT_11 = self->tables_len;
    zi = zT_11;
    zi = zT_11;
    zi = zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_22 = self->tables_items;
    zT_23 = zT_22 + idx;
    return zT_23;
    z_bb_3:
    zT_12 = zi <= idx;
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = self->tables_alloc;
    zT_13 = zT_14;
    zT_15 = zF_26192335_symbolTableInit(zT_13);
    zT_16 = self->tables_items;
    zT_16[zi] = zT_15;
    zT_17 = 1;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zi + zT_18;
    zi = zT_19;
    zi = zT_19;
    goto z_bb_6;
    z_bb_5:
    zT_20 = 1;
    zT_21 = idx + zT_20;
    self->tables_len = zT_21;
    goto z_bb_2;
    z_bb_6:
    goto z_bb_3;
}

/* symbolIsPublic */
int zF_C08C479C_symbolIsPublic(zT_3A105EF1_Symbol* sym) {
    unsigned short zT_1;
    unsigned short zT_2;
    unsigned short zT_3;
    int zT_4;
    int zT_5;
    zT_1 = sym->flags;
    zT_2 = 2;
    zT_3 = zT_1 & zT_2;
    zT_4 = 0;
    zT_5 = zT_3 != zT_4;
    return zT_5;
}

/* symbolRegistryQualifiedLookup */
zT_E68301A1_Opt_804 zF_A398987E_symbolRegistryQuali(zT_3D7259E2_SymbolRegistry* reg, unsigned int mod_id, unsigned int name_id) {
    zT_3D7259E2_SymbolRegistry* zT_4;
    unsigned int zT_5;
    zT_060CD1EB_SymbolTable* zT_6 = 0;
    zT_060CD1EB_SymbolTable* zT_7;
    unsigned int zT_8;
    zT_E68301A1_Opt_804 zT_9 = {0};
    zT_060CD1EB_SymbolTable* table;
    zT_4 = reg;
    zT_5 = mod_id;
    zT_6 = zF_9B36C202_symbolRegistryGetTa(zT_4, zT_5);
    table = zT_6;
    table = zT_6;
    table = zT_6;
    zT_7 = table;
    zT_8 = name_id;
    zT_9 = zF_893B79A5_symbolTableLookup(zT_7, zT_8);
    return zT_9;
}

/* EOF */
