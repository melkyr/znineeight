#ifndef ZIG_MODULE_ANALYZER_2FA863C8_H
#define ZIG_MODULE_ANALYZER_2FA863C8_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "ast_2FA12982.h"
#include "type_registry_8EE489B8.h"
#include "string_interner_51340A9F.h"
#include "diagnostics_B9C6175E.h"
#include "allocator_E75B7A0B.h"
#include "state_map_1CD0D172.h"
#include "symbol_table_74081C75.h"

#ifndef ZIG_STRUCT_zT_7A19C4A5_DeferEntry
#define ZIG_STRUCT_zT_7A19C4A5_DeferEntry
struct zT_7A19C4A5_DeferEntry {
	unsigned char kind;
	unsigned int stmt_idx;
	unsigned int scope_depth;
};
#endif /* ZIG_STRUCT_zT_7A19C4A5_DeferEntry */
#ifndef ZIG_ENUM_zT_E48CAD8A_PtrState
#define ZIG_ENUM_zT_E48CAD8A_PtrState
typedef unsigned char zT_E48CAD8A_PtrState;
#define zT_E48CAD8A_PtrState_uninit 10
#define zT_E48CAD8A_PtrState_is_null 11
#define zT_E48CAD8A_PtrState_safe 12
#define zT_E48CAD8A_PtrState_maybe 13

#endif /* ZIG_ENUM_zT_E48CAD8A_PtrState */
#ifndef ZIG_ENUM_zT_32E64562_Provenance
#define ZIG_ENUM_zT_32E64562_Provenance
typedef unsigned char zT_32E64562_Provenance;
#define zT_32E64562_Provenance_unknown 0
#define zT_32E64562_Provenance_local 1
#define zT_32E64562_Provenance_param 2
#define zT_32E64562_Provenance_param_addr 3
#define zT_32E64562_Provenance_global 4
#define zT_32E64562_Provenance_heap 5

#endif /* ZIG_ENUM_zT_32E64562_Provenance */
#ifndef ZIG_ENUM_zT_480593AB_AllocState
#define ZIG_ENUM_zT_480593AB_AllocState
typedef unsigned char zT_480593AB_AllocState;
#define zT_480593AB_AllocState_untracked 0
#define zT_480593AB_AllocState_allocated 1
#define zT_480593AB_AllocState_freed 2
#define zT_480593AB_AllocState_returned_val 3
#define zT_480593AB_AllocState_transferred 4
#define zT_480593AB_AllocState_unknown 5

#endif /* ZIG_ENUM_zT_480593AB_AllocState */
#ifndef ZIG_STRUCT_zT_7E2F335A_AnalyzerContext
#define ZIG_STRUCT_zT_7E2F335A_AnalyzerContext
struct zT_7E2F335A_AnalyzerContext {
	zT_6B0A7D14_AstStore* store;
	zT_338B7C76_TypeRegistry* registry;
	zT_D3EB6303_StringInterner* interner;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_060CD1EB_SymbolTable* symbols;
	zT_3E40CD83_Sand* alloc;
	unsigned int current_fn_name;
	zT_7A19C4A5_DeferEntry* defer_queue_items;
	unsigned int defer_queue_len;
	unsigned int defer_queue_cap;
	zT_3E40CD83_Sand* defer_queue_alloc;
	unsigned int current_depth;
	unsigned char null_analysis_mode;
	unsigned char skip_null_check;
	unsigned char skip_lifetime_check;
	unsigned char skip_doublefree_check;
	unsigned char warn_all;
	zT_68F0EBCB_FP_void_zT_7E2F335A on_stmt_cb;
	unsigned char in_defer_exec;
	unsigned char lifetime_analysis_mode;
	unsigned char doublefree_analysis_mode;
};
#endif /* ZIG_STRUCT_zT_7E2F335A_AnalyzerContext */

/* Forward declarations */
unsigned int zF_2E24BD6B_identNameId(zT_6B0A7D14_AstStore*, unsigned int);
zT_BAEE192E_Opt_10 zF_92A5586D_resolveOrigin(zT_7E2F335A_AnalyzerContext*, unsigned int);
unsigned char zF_5542CD3C_classifyProvenance(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_8C7FC932_checkReturnProvenan(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned int);
int zF_264B254A_isAllocCall(zT_7E2F335A_AnalyzerContext*, unsigned int);
zT_BAEE192E_Opt_10 zF_E445D5FB_isFreeCall(zT_7E2F335A_AnalyzerContext*, unsigned int);
unsigned int zF_3504E8E2_compositeNameId(zT_D3EB6303_StringInterner*, unsigned int, unsigned int);
void zF_4330B9B8_handleAllocCall(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned int);
void zF_70D0501D_handleFreeCall(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_628B7574_checkLeaksOnScopeEx(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*);
void zF_67B7BB29_handleAllocAssign(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_65CAFC02_handleOwnershipRetu(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_9AFCA595_handleOwnershipPass(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_46BA7660_deferQueueEnsureCap(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_2A06A757_analyzeSignature(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_E153ECE7_validateSignatureTy(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
void zF_8D5B6C98_analyzeExpr(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
unsigned char zF_0619AC1C_classifyExpr(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
unsigned char zF_F32BD543_isNullExpr(zT_6B0A7D14_AstStore*, unsigned int);
zT_BAEE192E_Opt_10 zF_7B65B82E_isIdentExpr(zT_6B0A7D14_AstStore*, unsigned int);
zT_CBD46E1C_Opt_115 zF_8D299A60_detectNullGuard(zT_6B0A7D14_AstStore*, unsigned int);
void zF_76DBB626_applyNullGuardRefin(zT_6B0A7D14_AstStore*, unsigned int, zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*);
void zF_B7AD2EEF_handleNullVarDecl(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_847AD0EF_handleNullAssign(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_332F08BB_executeDeferQueue(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, unsigned char, zT_68F0EBCB_FP_void_zT_7E2F335A);
void zF_0F6AFE81_walkBlock(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, zT_68F0EBCB_FP_void_zT_7E2F335A);
void zF_468ECC89_visitStatement(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int, zT_68F0EBCB_FP_void_zT_7E2F335A, zT_68F0EBCB_FP_void_zT_7E2F335A);
void zF_43C99FB3_onNullStmt(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_3D2EF2C5_onLifetimeStmt(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_270EF995_onDoubleFreeStmt(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_DDE69BF2_runSignatureAnalyze(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_59D99CE2_detectorVisit(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
void zF_29CABD65_runNullAnalyzer(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_9B11D60F_runLifetimeAnalyzer(zT_7E2F335A_AnalyzerContext*, unsigned int, unsigned int);
void zF_D5F41043_runDoubleFreeAnalyz(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_F697813C_runAllAnalyzers(zT_7E2F335A_AnalyzerContext*, unsigned int);
void zF_780653D2___module_init_10(void);
/* Storage globals (extern decls) */
extern unsigned int zG_73BDFDC5_PER_FUNC_BUDGET;

#endif /* ZIG_MODULE_ANALYZER_2FA863C8_H */
