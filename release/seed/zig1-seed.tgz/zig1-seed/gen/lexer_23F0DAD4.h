#ifndef ZIG_MODULE_LEXER_23F0DAD4_H
#define ZIG_MODULE_LEXER_23F0DAD4_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "token_76C7CBBF.h"
#include "string_interner_51340A9F.h"
#include "diagnostics_B9C6175E.h"
#include "allocator_E75B7A0B.h"
#include "growable_array_6014E5AF.h"
#include "pal_388A8A1B.h"
#include "source_manager_0C564FCF.h"
#include "lexer_tests_CFD6E55C.h"

#ifndef ZIG_STRUCT_zT_138FFB41_Lexer
#define ZIG_STRUCT_zT_138FFB41_Lexer
struct zT_138FFB41_Lexer {
	zT_8F083A69_Slice_zT_0B42B2F8_u source;
	unsigned int pos;
	unsigned int line;
	unsigned int col;
	unsigned int file_id;
	zT_D3EB6303_StringInterner* interner;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_47B162D1_U8ArrayList* string_buf;
	unsigned char count_only;
};
#endif /* ZIG_STRUCT_zT_138FFB41_Lexer */

/* Forward declarations */
zT_138FFB41_Lexer zF_151E643F_lexerInit(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, zT_D3EB6303_StringInterner*, zT_F85C5DED_DiagnosticCollector*, zT_3E40CD83_Sand*);
zT_3A355BD2_Token zF_B976BEC9_lexerNextToken(zT_138FFB41_Lexer*);
unsigned char zF_7C2FDD01_lexerAdvance(zT_138FFB41_Lexer*);
unsigned char zF_6ACB12FA_lexerPeek(zT_138FFB41_Lexer*);
unsigned char zF_D1AE715C_lexerPeekN(zT_138FFB41_Lexer*, unsigned int);
unsigned char zF_07BC1EA1_lexerIsAtEnd(zT_138FFB41_Lexer*);
unsigned char zF_8A07967A_lexerMatch(zT_138FFB41_Lexer*, unsigned char);
void zF_F7949B41_lexerSkipWSC(zT_138FFB41_Lexer*);
zT_3A355BD2_Token zF_369DD718_lexerMakeToken(zT_138FFB41_Lexer*, zT_EAC3E484_TokenKind, unsigned int, zT_85CBA4DB_TokenValue);
zT_3A355BD2_Token zF_19A0FF20_lexerMakeErrorToken(zT_138FFB41_Lexer*, unsigned int);
zT_3A355BD2_Token zF_D28972ED_lexerScanString(zT_138FFB41_Lexer*, unsigned int);
zT_3A355BD2_Token zF_616D7368_lexerScanChar(zT_138FFB41_Lexer*, unsigned int);
zT_3A355BD2_Token zF_EF8134BD_lexerScanNumber(zT_138FFB41_Lexer*, unsigned int, unsigned char);
zT_3A355BD2_Token zF_EC7F12C5_lexerScanIdentifier(zT_138FFB41_Lexer*, unsigned int);
zT_3A355BD2_Token zF_9C3BDAA8_lexerScanBuiltinIde(zT_138FFB41_Lexer*, unsigned int);
unsigned char zF_0D29E41B_isAlpha(unsigned char);
unsigned char zF_C95A8EC6_isDigit(unsigned char);
unsigned char zF_97170599_isAlphaNum(unsigned char);
unsigned char zF_24E4C5BC_hexDigitValue(unsigned char);
unsigned char zF_3EAE09C6_lexerParseHexEscape(zT_138FFB41_Lexer*);
unsigned char zF_7D4EA30A_lexerParseEscapeSeq(zT_138FFB41_Lexer*);
unsigned char zF_C5E3A034_isDigitInBase(unsigned char, unsigned char);
zT_79FAE712_u64 zF_8EC79679_parseU64(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char);
zT_00435AEB_f64 zF_E24707C3_f64FromBits(zT_79FAE712_u64);
zT_00435AEB_f64 zF_4836A299_f64SignedZero(unsigned char);
zT_00435AEB_f64 zF_5493CDCE_f64SignedInf(unsigned char);
zT_79FAE712_u64 zF_E87F3361_pow5of(unsigned int);
unsigned int zF_DE0896E8_bitlen128(zT_79FAE712_u64, zT_79FAE712_u64);
zT_79FAE712_u64 zF_17BA7F4D_shr128(zT_79FAE712_u64, zT_79FAE712_u64, unsigned int);
zT_79FAE712_u64 zF_6E7F5C11_bit128(zT_79FAE712_u64, zT_79FAE712_u64, unsigned int);
unsigned char zF_62E97F03_lowNonZero128(zT_79FAE712_u64, zT_79FAE712_u64, unsigned int);
zT_00435AEB_f64 zF_13EBBFAD_fastRound(zT_79FAE712_u64, zT_79FAE712_u64, unsigned char, int, unsigned char);
void zF_BD11B99B_hpdTrim(zT_4324C233_Hpd*);
void zF_0E0CD583_hpdMul2(zT_4324C233_Hpd*);
void zF_A5013D9C_hpdDiv2(zT_4324C233_Hpd*);
zT_79FAE712_u64 zF_4EA36099_hpdRound(zT_4324C233_Hpd*);
zT_00435AEB_f64 zF_37CDE8A4_parseF64(zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_6E4D822B_isU64MaxLiteral(zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_F0A50871_assertEqBool(unsigned char, unsigned char, unsigned int);
void zF_EFB8936D_assertEqU32(unsigned int, unsigned int, unsigned int);
void zF_8856257C_assertEqU8(unsigned char, unsigned char, unsigned int);
void zF_1058D9A8_assertEqTokenKind(zT_EAC3E484_TokenKind, zT_EAC3E484_TokenKind, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_1(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
void zF_C3A6E90A_lexerRunAllTests(void);
void zF_519E4401_lexerTestSanityChec(void);
void zF_6492230E_lexerTestHelpers(void);
void zF_BF88F19A_lexerTestSkipWhites(void);
void zF_9AA3D1F6_lexerTestOperators(void);
void zF_4CB82885_lexerTestScanNumber(void);
void zF_A76AF035_lexerTestScanString(void);
void zF_13791BA0_lexerTestScanChar(void);
void zF_B8F07D3E_lexerTestIdentifier(void);
void zF_1C8729CF_lexerTestBuiltinIde(void);
void zF_6836167B_lexerTestDiagnostic(void);
void zF_780653D2___module_init_5(void);
/* Storage globals (extern decls) */
extern zT_138FFB41_Lexer zG_138FFB41_Lexer;

#endif /* ZIG_MODULE_LEXER_23F0DAD4_H */
