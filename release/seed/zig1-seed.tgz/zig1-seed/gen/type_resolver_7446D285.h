#ifndef ZIG_MODULE_TYPE_RESOLVER_7446D285_H
#define ZIG_MODULE_TYPE_RESOLVER_7446D285_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "pal_388A8A1B.h"
#include "type_registry_8EE489B8.h"
#include "diagnostics_B9C6175E.h"
#include "symbol_registrator_757C4BC5.h"
#include "ast_2FA12982.h"
#include "itoa_4E677A6A.h"
#include "string_interner_51340A9F.h"
#include "symbol_table_74081C75.h"
#include "module_registry_03A5D1FC.h"
#include "resolved_type_table_5F22E794.h"
#include "hash_02AFCD13.h"
#include "growable_array_6014E5AF.h"

#ifndef ZIG_STRUCT_zT_010C8DF0_ClassificationResul
#define ZIG_STRUCT_zT_010C8DF0_ClassificationResul
struct zT_010C8DF0_ClassificationResul {
	unsigned int* ids;
	unsigned int len;
};
#endif /* ZIG_STRUCT_zT_010C8DF0_ClassificationResul */
#ifndef ZIG_STRUCT_zT_C890C8CB_TypeResolver
#define ZIG_STRUCT_zT_C890C8CB_TypeResolver
struct zT_C890C8CB_TypeResolver {
	zT_338B7C76_TypeRegistry* registry;
	zT_52CDA6EF_DepEdge* depend_items;
	unsigned int depend_len;
	unsigned int depend_cap;
	unsigned int* in_degree_items;
	unsigned int in_degree_cap;
	unsigned int* sorted_items;
	unsigned int sorted_len;
	unsigned int* worklist_items;
	unsigned int worklist_len;
	unsigned int worklist_cap;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_C890C8CB_TypeResolver */
#ifndef ZIG_STRUCT_zT_ABC1EBBE_TypeResolveEnv
#define ZIG_STRUCT_zT_ABC1EBBE_TypeResolveEnv
struct zT_ABC1EBBE_TypeResolveEnv {
	zT_6B0A7D14_AstStore* store;
	zT_338B7C76_TypeRegistry* typereg;
	zT_3D7259E2_SymbolRegistry* symbol_reg;
	zT_D3EB6303_StringInterner* interner;
	unsigned int module_id;
	unsigned int source_file_id;
	zT_7334F4FE_Opt_225 diag;
	zT_F8B96B9C_Opt_393 local_consts;
};
#endif /* ZIG_STRUCT_zT_ABC1EBBE_TypeResolveEnv */

/* Forward declarations */
zT_E2DF2801_LocalConstScope zF_F5EBC2FF_localConstScopeInit(zT_3E40CD83_Sand*);
void zF_DA915531_localConstScopePush(zT_E2DF2801_LocalConstScope*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_6532C387_localConstScopeLook(zT_E2DF2801_LocalConstScope*, unsigned int);
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver*);
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver*, unsigned int, unsigned int);
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver*);
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver*, unsigned int);
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver*);
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver*, unsigned int);
unsigned int zF_D2BAC673_alignUp_1(unsigned int, unsigned int);
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver*, unsigned int);
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry*, zT_F85C5DED_DiagnosticCollector*, zT_3E40CD83_Sand*);
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver*, zT_4D61441E_DepGraph*);
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver*);
int zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind);
int zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind);
int zF_47951EE7_layoutFieldNeedsEdg(zT_33EF6BFB_TypeKind);
void zF_0E16D693_layoutAddTypeEdge(zT_C890C8CB_TypeResolver*, unsigned int, unsigned int);
void zF_0D59859C_layoutAddFieldEdges(zT_C890C8CB_TypeResolver*, unsigned int, unsigned short, unsigned int);
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver*);
zT_010C8DF0_ClassificationResul zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver*, zT_3E40CD83_Sand*);
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand*, unsigned int**, unsigned int**, unsigned int*, unsigned int);
zT_3CB0179A_Slice_zT_05F374B1_u zF_026BA788_typeResolverGetSort(zT_C890C8CB_TypeResolver*);
unsigned int zF_0E4084E4_evalConstModuleOfEx(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
zT_44E16D78_Opt_7 zF_FFFAAD16_evalConstI64Full(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
zT_CF761179_Opt_853 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
int zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind);
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv*, zT_DDCD424B_Slice_zT_6E8D187B_M);
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv*, zT_072B53A6_ModuleRegistry*, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv*, zT_DDCD424B_Slice_zT_6E8D187B_M, zT_072B53A6_ModuleRegistry*);
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv*, zT_DDCD424B_Slice_zT_6E8D187B_M);
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv*, zT_DDCD424B_Slice_zT_6E8D187B_M, zT_8EED1867_ResolvedTypeTable*);
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore*, zT_338B7C76_TypeRegistry*, zT_3D7259E2_SymbolRegistry*, zT_D3EB6303_StringInterner*, zT_8EED1867_ResolvedTypeTable*, zT_072B53A6_ModuleRegistry*, zT_F85C5DED_DiagnosticCollector*, zT_3E40CD83_Sand*);
void zF_780653D2___module_init_17(void);
/* Storage globals (extern decls) */
extern zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
extern unsigned int zG_E6DB2ACE_MODULE_ID_NONE;

#endif /* ZIG_MODULE_TYPE_RESOLVER_7446D285_H */
