#ifndef ZIG_MODULE_TYPE_RESOLVER_7446D285_H
#define ZIG_MODULE_TYPE_RESOLVER_7446D285_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "pal_388A8A1B.h"
#include "type_registry_8EE489B8.h"
#include "diagnostics_B9C6175E.h"
#include "symbol_registrator_757C4BC5.h"
#include "ast_2FA12982.h"
#include "itoa_4E677A6A.h"
#include "string_interner_51340A9F.h"
#include "symbol_table_74081C75.h"
#include "module_registry_03A5D1FC.h"
#include "resolved_type_table_5F22E794.h"
#include "hash_02AFCD13.h"
#include "comptime_eval_02C4526F.h"
#include "growable_array_6014E5AF.h"

#ifndef ZIG_STRUCT_zT_C890C8CB_TypeResolver
#define ZIG_STRUCT_zT_C890C8CB_TypeResolver
struct zT_C890C8CB_TypeResolver {
	zT_338B7C76_TypeRegistry* registry;
	zT_52CDA6EF_DepEdge* depend_items;
	unsigned int depend_len;
	unsigned int depend_cap;
	unsigned int* in_degree_items;
	unsigned int in_degree_cap;
	unsigned int* sorted_items;
	unsigned int sorted_len;
	unsigned int* worklist_items;
	unsigned int worklist_len;
	unsigned int worklist_cap;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_C890C8CB_TypeResolver */
#ifndef ZIG_STRUCT_zT_ABC1EBBE_TypeResolveEnv
#define ZIG_STRUCT_zT_ABC1EBBE_TypeResolveEnv
struct zT_ABC1EBBE_TypeResolveEnv {
	zT_6B0A7D14_AstStore* store;
	zT_338B7C76_TypeRegistry* typereg;
	zT_3D7259E2_SymbolRegistry* symbol_reg;
	zT_D3EB6303_StringInterner* interner;
	unsigned int module_id;
	unsigned int source_file_id;
	zT_622E1E76_Opt_254 diag;
	zT_9BD83C17_Opt_442 local_consts;
	zT_99D838F1_Opt_444 local_types;
};
#endif /* ZIG_STRUCT_zT_ABC1EBBE_TypeResolveEnv */

/* Forward declarations */
zT_C8A278E4_LocalTypeScope zF_8A85AA66_localTypeScopeInit(zT_3E40CD83_Sand*);
void zF_F638C869_nameScopeGrowPair(zT_3E40CD83_Sand*, unsigned int**, unsigned int**, unsigned int, unsigned int*, unsigned int);
zT_BAEE192E_Opt_10 zF_1B08A8E4_nameScopeLookup(unsigned int*, unsigned int*, unsigned int, unsigned int);
void zF_A3A445A0_localTypeScopePush(zT_C8A278E4_LocalTypeScope*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_C768898A_localTypeScopeLooku(zT_C8A278E4_LocalTypeScope*, unsigned int);
zT_E2DF2801_LocalConstScope zF_F5EBC2FF_localConstScopeInit(zT_3E40CD83_Sand*);
void zF_DA915531_localConstScopePush(zT_E2DF2801_LocalConstScope*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_6532C387_localConstScopeLook(zT_E2DF2801_LocalConstScope*, unsigned int);
void zF_BEFE4370_rawArrayEnsureCapac(zT_3E40CD83_Sand*, unsigned char**, unsigned int, unsigned int*, unsigned int, unsigned int);
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver*);
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver*, unsigned int, unsigned int);
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver*);
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver*, unsigned int);
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver*);
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver*, unsigned int);
unsigned int zF_D2BAC673_alignUp_1(unsigned int, unsigned int);
void zF_C8A36147_markerU32(unsigned int);
void zF_0E9E97D8_layoutCompute(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_BEEAF73E_layoutDepOk(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned char zF_B32C0425_layoutFieldDepsOk(zT_338B7C76_TypeRegistry*, unsigned int, unsigned short, unsigned int);
unsigned char zF_3E55D0D5_layoutEnsure(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver*, unsigned int);
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry*, zT_F85C5DED_DiagnosticCollector*, zT_3E40CD83_Sand*);
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver*, zT_4D61441E_DepGraph*);
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver*);
unsigned char zF_95CB1909_kindIsAggregateCore(zT_33EF6BFB_TypeKind);
unsigned char zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind);
unsigned char zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind);
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver*);
void zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver*, zT_786E6CF2_EmissionClassificat*, zT_3E40CD83_Sand*);
unsigned char zF_EEDBE6D1_classificationIsSyn(zT_33EF6BFB_TypeKind);
unsigned char zF_F673DF45_classificationNeeds(zT_D155D06D_Type);
void zF_586B7FD5_classificationShare(zT_338B7C76_TypeRegistry*, zT_21D3708C_U32ToU32Map*, zT_21D3708C_U32ToU32Map*);
void zF_7845A68F_collectNeededTuples(zT_338B7C76_TypeRegistry*, zT_21D3708C_U32ToU32Map*, unsigned int);
void zF_0DE160E2_classifyTypeEmissio(zT_338B7C76_TypeRegistry*, zT_786E6CF2_EmissionClassificat*);
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand*, unsigned int**, unsigned int**, unsigned int*, unsigned int);
unsigned int zF_0E4084E4_evalConstModuleOfEx(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
unsigned char zF_6AE4DFFC_evalConstScalarKind(zT_33EF6BFB_TypeKind);
zT_7634F9B7_Opt_222 zF_382591DE_evalConstIntFull(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
unsigned int zF_5C9D5CFF_evalConstIntToSize(zT_0163D9A4_ComptimeInt);
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
zT_44E16D78_Opt_7 zF_FFFAAD16_evalConstI64Full(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
unsigned char zF_88ABE016_evalConstEnumSource(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
zT_74F02D1B_Opt_965 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
unsigned int zF_66C54985_symbolTypeIdOfModul(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
unsigned int zF_DE1472AF_symbolLookupTypeAll(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
unsigned char zF_0FFDEDBD_enumMembersResolve(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned char, unsigned int, unsigned char, unsigned char, unsigned int*, unsigned int*, unsigned int*);
void zF_52B56F5B_reportEnumWalkFailu(zT_F85C5DED_DiagnosticCollector*, zT_6B0A7D14_AstStore*, unsigned int, unsigned int, unsigned int);
void zF_153D24FD_enumReevaluateAll(zT_6B0A7D14_AstStore*, zT_338B7C76_TypeRegistry*, zT_3D7259E2_SymbolRegistry*, zT_D3EB6303_StringInterner*, zT_072B53A6_ModuleRegistry*, zT_F85C5DED_DiagnosticCollector*);
unsigned int zF_27A59B24_containerAnonNameId(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
unsigned char zF_82C2F046_isContainerDeclKind(zT_8143F551_AstKind);
unsigned char zF_599C0D79_isCompoundTypeExprK(zT_8143F551_AstKind);
unsigned int zF_3B3163AB_containerFieldCount(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
unsigned char zF_E2A017C6_tupleElemArrayUnsup(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_3B3FE8D4_localEnumBackingTyp(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
void zF_D81528BB_validateLocalEnumBa(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, zT_F85C5DED_DiagnosticCollector*);
void zF_9084D8CB_validateLocalEnum(zT_ABC1EBBE_TypeResolveEnv*, unsigned int);
unsigned int zF_FE81311F_registerContainerTy(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, zT_8143F551_AstKind, unsigned int);
unsigned char zF_D43B245F_typeResolverCheckMe(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int, zT_3A105EF1_Symbol*);
unsigned char zF_54996FA4_typeResolverIsInfer(zT_6B0A7D14_AstStore*, zT_D3EB6303_StringInterner*, unsigned int);
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
unsigned char zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind);
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv*, zT_DDCD424B_Slice_zT_6E8D187B_M);
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv*, zT_072B53A6_ModuleRegistry*, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv*, zT_DDCD424B_Slice_zT_6E8D187B_M, zT_072B53A6_ModuleRegistry*);
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv*, zT_DDCD424B_Slice_zT_6E8D187B_M);
void zF_76A5E245_reportUndefinedSymb(zT_F85C5DED_DiagnosticCollector*, zT_D3EB6303_StringInterner*, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_2501AC4F_typeResolverDiagnos(zT_ABC1EBBE_TypeResolveEnv*, unsigned int, unsigned int);
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv*, zT_DDCD424B_Slice_zT_6E8D187B_M, zT_8EED1867_ResolvedTypeTable*);
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore*, zT_338B7C76_TypeRegistry*, zT_3D7259E2_SymbolRegistry*, zT_D3EB6303_StringInterner*, zT_8EED1867_ResolvedTypeTable*, zT_072B53A6_ModuleRegistry*, zT_F85C5DED_DiagnosticCollector*, zT_3E40CD83_Sand*);
void zF_780653D2___module_init_13(void);
/* Storage globals (extern decls) */
extern zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
extern unsigned int const zG_E6DB2ACE_MODULE_ID_NONE;

#endif /* ZIG_MODULE_TYPE_RESOLVER_7446D285_H */
