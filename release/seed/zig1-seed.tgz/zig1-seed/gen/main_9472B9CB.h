#ifndef ZIG_MODULE_MAIN_9472B9CB_H
#define ZIG_MODULE_MAIN_9472B9CB_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "string_interner_51340A9F.h"
#include "source_manager_0C564FCF.h"
#include "diagnostics_B9C6175E.h"
#include "name_mangler_27ED89E2.h"
#include "token_76C7CBBF.h"
#include "lexer_23F0DAD4.h"
#include "pal_388A8A1B.h"
#include "parser_61A67AF1.h"
#include "ast_2FA12982.h"
#include "itoa_4E677A6A.h"
#include "path_8DCF959C.h"
#include "module_registry_03A5D1FC.h"
#include "import_resolver_58BB752E.h"
#include "analyzer_2FA863C8.h"
#include "symbol_table_74081C75.h"
#include "type_registry_8EE489B8.h"
#include "c89_emit_7CEF756E.h"
#include "lower_1EB7D337.h"
#include "lir_64CB5435.h"
#include "lir_stream_0760A6EE.h"
#include "resolved_type_table_5F22E794.h"
#include "hash_02AFCD13.h"
#include "growable_array_6014E5AF.h"
#include "coercion_F654E5FA.h"
#include "semantic_analyzer_4DBE89E5.h"
#include "type_resolver_7446D285.h"
#include "comptime_eval_02C4526F.h"
#include "symbol_registrator_757C4BC5.h"
#include "const_alias_prepass_A733A209.h"
#include "front_resolution_D5E9117C.h"
#include "async_analysis_A8747991.h"
#include "async_frame_layout_08B81337.h"
#include "async_state_machine_A730A7D6.h"
#include "cinclude_6B99020D.h"
#include "spill_store_AC8E76BA.h"
#include "lir_opt_pass_3842C861.h"
#include "emit_support_51C949E9.h"
#include "lexer_tests_CFD6E55C.h"


/* Forward declarations */
void zF_EA90E208_main(int, unsigned char**);
void zF_74055C03_runCompiler(zT_5AB29387_CompilerContext*);
void zF_E2BA93CE_phase_ImportResolut(zT_5AB29387_CompilerContext*);
void zF_945DEA54_phase_SymbolRegistr(zT_5AB29387_CompilerContext*);
void zF_D3497187_phase_TypeResolutio(zT_5AB29387_CompilerContext*);
void zF_F862154A_phase_FrontResoluti(zT_5AB29387_CompilerContext*);
void zF_9609BF31_phase_ComptimeEvalu(zT_5AB29387_CompilerContext*);
void zF_0666ED4F_phase_SemanticAnaly(zT_5AB29387_CompilerContext*);
void zF_F3B55B42_phase_StaticAnalyze(zT_5AB29387_CompilerContext*);
void zF_9BC6214D_phase_AsyncFrameSiz(zT_5AB29387_CompilerContext*);
void zF_1F21ABE7_phase_LIRLowering(zT_5AB29387_CompilerContext*);
void zF_FC691B4D_errorCodeRegistryFi(zT_5AB29387_CompilerContext*);
void zF_BC6C7740_pruneTypeMarkByValu(zT_21D3708C_U32ToU32Map*, zT_338B7C76_TypeRegistry*, zT_A4CE86B7_U64ToU32Map*, unsigned int, unsigned int);
void zF_2268F8CE_phase_C89Emission(zT_5AB29387_CompilerContext*);
zT_C98AF326_CompilerCli zF_6143A521_parseArgs(void);
int zF_5FE51158_matchFlag(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
int zF_FBF91F7E_matchMMFlag(zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D0470E_cstrToSlice(unsigned char*);
unsigned int zF_6CF11065_parseSize(unsigned char*);
unsigned int zF_16BBA09E_parseU32(unsigned char*);
unsigned int zF_B9231BB9_parseMMBytes(zT_8F083A69_Slice_zT_0B42B2F8_u);
int zF_C4E3C361_matchSFlag(zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_153C3795_parseSLevel(zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_CAF40AAB_ColorMode zF_05AD3AFC_parseColorMode(unsigned char*);
zT_A4FB690E_ErrorFormat zF_A4602959_parseErrorFormat(unsigned char*);
int zF_06CC17EA_parseTargetIsWindow(unsigned char*);
void zF_266B1B8E_writeU32(unsigned int);
void zF_9D45DFBF_printUsage(void);
void zF_780653D2___module_init(void);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_MAIN_9472B9CB_H */
