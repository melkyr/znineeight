#ifndef ZIG_MODULE_MODULE_REGISTRY_03A5D1FC_H
#define ZIG_MODULE_MODULE_REGISTRY_03A5D1FC_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "allocator_E75B7A0B.h"
#include "diagnostics_B9C6175E.h"
#include "diagnostics_B9C6175E.h"
#include "string_interner_51340A9F.h"
#include "string_interner_51340A9F.h"
#include "pal_388A8A1B.h"
#include "panic_CE239B25.h"
#include "hash_02AFCD13.h"
#include "path_8DCF959C.h"
#include "source_manager_0C564FCF.h"
#include "growable_array_6014E5AF.h"
#include "spill_store_AC8E76BA.h"
#include "ast_2FA12982.h"
#include "ast_2FA12982.h"
#include "ast_2FA12982.h"


/* Forward declarations */
zT_E41AEC18_ModuleEntryArrayLis zF_CD3AB3CA_moduleEntryArrayLis(zT_3E40CD83_Sand*, unsigned int);
void zF_91E0DA42_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis*, unsigned int);
void zF_ABB1AEC0_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis*, zT_6E8D187B_ModuleEntry);
zT_DDCD424B_Slice_zT_6E8D187B_M zF_9FE5DB1E_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis*);
void zF_529FE8C7_searchDirArrayListE(zT_4EA49A91_SearchDirArrayList*, unsigned int);
void zF_DD10EA35_searchDirArrayListA(zT_4EA49A91_SearchDirArrayList*, unsigned int);
zT_E23A20E9_Opt_206 zF_05C4CBC2_joinPath(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_75D2520B_moduleDirPath(zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_02CE50E0_Opt_403 zF_64D8041C_appendZigExt(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*);
zT_BAEE192E_Opt_10 zF_25488423_moduleResolverTryDi(zT_4DB1475B_ModuleResolver*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*);
zT_4DB1475B_ModuleResolver zF_64765145_moduleResolverInit(zT_3E40CD83_Sand*, zT_D3EB6303_StringInterner*, zT_F85C5DED_DiagnosticCollector*);
void zF_B75A4515_moduleResolverAddSe(zT_4DB1475B_ModuleResolver*, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_BAEE192E_Opt_10 zF_6F148E15_moduleResolverResol(zT_4DB1475B_ModuleResolver*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*);
void zF_11AFB41C_importEdgesEnsureCa(unsigned int**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int);
void zF_358620BA_importEdgesAppend(unsigned int**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int);
zT_072B53A6_ModuleRegistry zF_896FAF3C_moduleRegistryInit(zT_3E40CD83_Sand*, zT_D3EB6303_StringInterner*, zT_F85C5DED_DiagnosticCollector*);
void zF_BD2BF0BD_moduleRegistrySetSo(zT_072B53A6_ModuleRegistry*, zT_227EDE07_SourceManager*);
unsigned int zF_E4DCE20D_moduleRegistryAddMo(zT_072B53A6_ModuleRegistry*, unsigned int);
zT_DDCD424B_Slice_zT_6E8D187B_M zF_3452C137_moduleRegistryGetMo(zT_072B53A6_ModuleRegistry*);
void zF_D00A7313_moduleRegistryAsser(zT_072B53A6_ModuleRegistry*);
unsigned int zF_AEB49EC3_moduleRegistryGetOr(zT_072B53A6_ModuleRegistry*, unsigned int);
void zF_F9E76704_moduleRegistryAddIm(zT_072B53A6_ModuleRegistry*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_620E3E3B_moduleRegistryResol(zT_072B53A6_ModuleRegistry*, unsigned int, unsigned int, zT_3E40CD83_Sand*);
void zF_67A3663A_hashSpillWriteU32(zT_D21A8776_SpillStore*, unsigned int);
unsigned int zF_C8FC272D_hashSpillReadU32(zT_D21A8776_SpillStore*);
void zF_090598CE_hashSpillWriteMap(zT_D21A8776_SpillStore*, zT_21D3708C_U32ToU32Map*, zT_ABD0FF08_HashMapSpillMeta*);
void zF_8767909B_moduleRegistrySpill(zT_072B53A6_ModuleRegistry*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_34911396_moduleRegistryFault(zT_072B53A6_ModuleRegistry*);
zT_BAEE192E_Opt_10 zF_A258E183_moduleRegistryPathT(zT_072B53A6_ModuleRegistry*, unsigned int);
void zF_DB8D7B50_importQueuePendingE(unsigned int**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int);
void zF_1649C2CE_importQueuePendingA(unsigned int**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int);
zT_BAEE192E_Opt_10 zF_79A6B129_importQueuePendingP(unsigned int**, unsigned int*);
zT_47A5CDFB_ImportQueue zF_4CF3FEA5_importQueueInit(zT_3E40CD83_Sand*, zT_F85C5DED_DiagnosticCollector*);
void zF_9BB96D13_importQueueEnqueue(zT_47A5CDFB_ImportQueue*, unsigned int);
zT_BAEE192E_Opt_10 zF_F8B96877_importQueueDequeue(zT_47A5CDFB_ImportQueue*);
void zF_30C22573_moduleRegistrySortM(zT_072B53A6_ModuleRegistry*);
void zF_F87B71D9_moduleRegistryVerif(zT_072B53A6_ModuleRegistry*);
void zF_7D71E4ED_moduleRegistryColle(zT_6B0A7D14_AstStore*, zT_3CB0179A_Slice_zT_05F374B1_u, zT_B687BB96_U32ArrayList*);
void zF_780653D2___module_init_9(void);
/* Storage globals (extern decls) */
extern zT_072B53A6_ModuleRegistry zG_072B53A6_ModuleRegistry;
extern unsigned char zG_E8C23D2C_source_man_stub;
extern unsigned char* zG_1DDFFDDD_HASH_SPILL_READ_MOD;
extern unsigned char* zG_034DEF1E_HASH_SPILL_WRITE_MO;
extern unsigned int zG_0BC1A97F_HASH_SPILL_MAX_MAP_;

#endif /* ZIG_MODULE_MODULE_REGISTRY_03A5D1FC_H */
