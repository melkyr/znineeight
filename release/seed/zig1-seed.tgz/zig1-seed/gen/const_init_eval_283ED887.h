#ifndef ZIG_MODULE_CONST_INIT_EVAL_283ED887_H
#define ZIG_MODULE_CONST_INIT_EVAL_283ED887_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "ast_2FA12982.h"
#include "type_registry_8EE489B8.h"
#include "symbol_table_74081C75.h"
#include "resolved_type_table_5F22E794.h"
#include "comptime_eval_02C4526F.h"
#include "module_registry_03A5D1FC.h"
#include "allocator_E75B7A0B.h"
#include "hash_02AFCD13.h"

#ifndef ZIG_STRUCT_zT_49DE1C22_ConstInitNode
#define ZIG_STRUCT_zT_49DE1C22_ConstInitNode
struct zT_49DE1C22_ConstInitNode {
	unsigned char kind;
	unsigned char _pad0;
	unsigned char _pad1;
	unsigned char _pad2;
	zT_79FAE712_u64 a;
	unsigned int b;
	unsigned int c;
	unsigned int child_start;
	unsigned int child_count;
};
#endif /* ZIG_STRUCT_zT_49DE1C22_ConstInitNode */
#ifndef ZIG_STRUCT_zT_4D150975_ConstInitEvalCtx
#define ZIG_STRUCT_zT_4D150975_ConstInitEvalCtx
struct zT_4D150975_ConstInitEvalCtx {
	zT_4065182A_ConstInitTable* tbl;
	zT_6B0A7D14_AstStore* store;
	zT_338B7C76_TypeRegistry* registry;
	zT_3D7259E2_SymbolRegistry* symbol_reg;
	zT_8EED1867_ResolvedTypeTable* resolved;
	zT_DA663F79_ComptimeEval* ce;
	zT_21D3708C_U32ToU32Map* enum_values;
	zT_072B53A6_ModuleRegistry* module_reg;
};
#endif /* ZIG_STRUCT_zT_4D150975_ConstInitEvalCtx */

/* Forward declarations */
zT_4065182A_ConstInitTable zF_046B7660_constInitTableInit(zT_3E40CD83_Sand*);
void zF_7EB8906A_tableEnsureNodes(zT_4065182A_ConstInitTable*, unsigned int);
void zF_0E390AEC_tableEnsureKids(zT_4065182A_ConstInitTable*, unsigned int);
unsigned int zF_094E0976_tableAddNode(zT_4065182A_ConstInitTable*, unsigned char, zT_79FAE712_u64, unsigned int, unsigned int);
void zF_D8E7F449_tableFinishAgg(zT_4065182A_ConstInitTable*, unsigned int, unsigned int*, unsigned int);
zT_49DE1C22_ConstInitNode zF_C30CDA77_constInitNodeAt(zT_4065182A_ConstInitTable*, unsigned int);
unsigned int zF_45C63E41_constInitChildAt(zT_4065182A_ConstInitTable*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_2B750645_constInitEvaluate(zT_4D150975_ConstInitEvalCtx*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_4E698A93_evalDecl(zT_4D150975_ConstInitEvalCtx*, unsigned int, unsigned int, unsigned int);
unsigned int zF_4E56FBAE_typeKindOf(zT_4D150975_ConstInitEvalCtx*, unsigned int);
unsigned char zF_092A96D8_isU8ish(zT_4D150975_ConstInitEvalCtx*, unsigned int);
zT_BAEE192E_Opt_10 zF_23832EEE_valNodeFromComptime(zT_4D150975_ConstInitEvalCtx*, zT_89B1DDDA_ComptimeVal, unsigned int);
unsigned char zF_145B7326_symbolIsConstGlobal(zT_3A105EF1_Symbol*);
unsigned int zF_644AB5CE_resolveModuleBaseNo(zT_4D150975_ConstInitEvalCtx*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_07765C6B_valueCopyDecl(zT_4D150975_ConstInitEvalCtx*, unsigned int, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_83AC95E3_classifyScalar(zT_4D150975_ConstInitEvalCtx*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned char zF_CEDEFC06_comptimeShapeKind(zT_8143F551_AstKind);
zT_BAEE192E_Opt_10 zF_19E37948_classifyAddr(zT_4D150975_ConstInitEvalCtx*, unsigned int, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_F7CF67F0_classifyAgg(zT_4D150975_ConstInitEvalCtx*, unsigned int, unsigned int, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_BF602E2F_classify(zT_4D150975_ConstInitEvalCtx*, unsigned int, unsigned int, unsigned int, unsigned int);
/* Storage globals (extern decls) */
extern unsigned char const zG_7572E8D7_CIE_ZERO;
extern unsigned char const zG_002ED8FA_CIE_INT;
extern unsigned char const zG_DE01BAF1_CIE_FLOAT;
extern unsigned char const zG_E69D9919_CIE_BOOL;
extern unsigned char const zG_DD770F31_CIE_CHAR;
extern unsigned char const zG_DC260CE4_CIE_STRING;
extern unsigned char const zG_8BCA4402_CIE_GLOBAL;
extern unsigned char const zG_AA7CCD69_CIE_FN;
extern unsigned char const zG_56522CBE_CIE_AGG;
extern unsigned int const zG_F7845E8F_CIE_NONE;

#endif /* ZIG_MODULE_CONST_INIT_EVAL_283ED887_H */
