#ifndef ZIG_MODULE_SYMBOL_TABLE_74081C75_H
#define ZIG_MODULE_SYMBOL_TABLE_74081C75_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"

#ifndef ZIG_STRUCT_zT_060CD1EB_SymbolTable
#define ZIG_STRUCT_zT_060CD1EB_SymbolTable
struct zT_060CD1EB_SymbolTable {
	zT_3A105EF1_Symbol* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_060CD1EB_SymbolTable */
#ifndef ZIG_STRUCT_zT_3D7259E2_SymbolRegistry
#define ZIG_STRUCT_zT_3D7259E2_SymbolRegistry
struct zT_3D7259E2_SymbolRegistry {
	zT_060CD1EB_SymbolTable* tables_items;
	unsigned int tables_len;
	unsigned int tables_cap;
	zT_3E40CD83_Sand* tables_alloc;
};
#endif /* ZIG_STRUCT_zT_3D7259E2_SymbolRegistry */

/* Forward declarations */
zT_060CD1EB_SymbolTable zF_26192335_symbolTableInit(zT_3E40CD83_Sand*);
void zF_896A798D_symbolTableEnsureCa(zT_060CD1EB_SymbolTable*, unsigned int);
int zF_D0156DDA_symbolTableInsert(zT_060CD1EB_SymbolTable*, zT_3A105EF1_Symbol);
zT_5979294E_Opt_849 zF_893B79A5_symbolTableLookup(zT_060CD1EB_SymbolTable*, unsigned int);
void zF_BCFEB408_symbolRegistryEnsur(zT_3D7259E2_SymbolRegistry*, unsigned int);
zT_3D7259E2_SymbolRegistry zF_09A884A8_symbolRegistryInit(zT_3E40CD83_Sand*);
zT_060CD1EB_SymbolTable* zF_9B36C202_symbolRegistryGetTa(zT_3D7259E2_SymbolRegistry*, unsigned int);
int zF_C08C479C_symbolIsPublic(zT_3A105EF1_Symbol*);
zT_5979294E_Opt_849 zF_A398987E_symbolRegistryQuali(zT_3D7259E2_SymbolRegistry*, unsigned int, unsigned int);
/* Storage globals (extern decls) */
extern zT_3D7259E2_SymbolRegistry zG_3D7259E2_SymbolRegistry;
extern zT_060CD1EB_SymbolTable zG_060CD1EB_SymbolTable;
extern zT_3C598AEF_SymbolKind zG_3C598AEF_SymbolKind;

#endif /* ZIG_MODULE_SYMBOL_TABLE_74081C75_H */
