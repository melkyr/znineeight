#ifndef ZIG_MODULE_DIAGNOSTICS_B9C6175E_H
#define ZIG_MODULE_DIAGNOSTICS_B9C6175E_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "type_registry_8EE489B8.h"
#include "allocator_E75B7A0B.h"
#include "source_manager_0C564FCF.h"
#include "mem_19CC4C40.h"
#include "string_interner_51340A9F.h"
#include "pal_388A8A1B.h"

#ifndef ZIG_ENUM_zT_76BAB79C_DiagnosticLevel
#define ZIG_ENUM_zT_76BAB79C_DiagnosticLevel
typedef unsigned char zT_76BAB79C_DiagnosticLevel;
#define zT_76BAB79C_DiagnosticLevel_err_lvl 0
#define zT_76BAB79C_DiagnosticLevel_warning 1
#define zT_76BAB79C_DiagnosticLevel_info 2
#define zT_76BAB79C_DiagnosticLevel_note 3

#endif /* ZIG_ENUM_zT_76BAB79C_DiagnosticLevel */
#ifndef ZIG_STRUCT_zT_B258D528_RelatedSpan
#define ZIG_STRUCT_zT_B258D528_RelatedSpan
struct zT_B258D528_RelatedSpan {
	unsigned int span_file_id;
	unsigned int span_start;
	unsigned int span_end;
	unsigned int message_id;
};
#endif /* ZIG_STRUCT_zT_B258D528_RelatedSpan */
#ifndef ZIG_STRUCT_zT_C0B2E5AF_DiagnosticArrayList
#define ZIG_STRUCT_zT_C0B2E5AF_DiagnosticArrayList
struct zT_C0B2E5AF_DiagnosticArrayList {
	zT_50FBF81E_Diagnostic* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_C0B2E5AF_DiagnosticArrayList */
#ifndef ZIG_STRUCT_zT_F85C5DED_DiagnosticCollector
#define ZIG_STRUCT_zT_F85C5DED_DiagnosticCollector
struct zT_F85C5DED_DiagnosticCollector {
	zT_C0B2E5AF_DiagnosticArrayList* diagnostics;
	zT_B258D528_RelatedSpan* related_span_items;
	unsigned int related_span_len;
	unsigned int related_span_cap;
	zT_3E40CD83_Sand* allocator;
	zT_227EDE07_SourceManager* source_manager;
	zT_D3EB6303_StringInterner* interner;
	unsigned int error_count;
	unsigned int warning_count;
	unsigned int max_diagnostics;
	unsigned int* diag_seen_items;
	unsigned int diag_seen_len;
	unsigned int diag_seen_cap;
};
#endif /* ZIG_STRUCT_zT_F85C5DED_DiagnosticCollector */

/* Forward declarations */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_1620F424_getLevelName(unsigned char);
unsigned int zF_2FED9490_formatU32(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_76BE513B_writeStr(zT_8F083A69_Slice_zT_0B42B2F8_u);
int zF_36E7146B_compareDiag(zT_50FBF81E_Diagnostic*, zT_50FBF81E_Diagnostic*);
void zF_F6BADF23_sortDiagnostics(zT_8D25846A_Slice_zT_50FBF81E_D);
zT_C0B2E5AF_DiagnosticArrayList zF_D95B9309_diagnosticArrayList(zT_3E40CD83_Sand*);
void zF_622A0C29_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList*, unsigned int);
void zF_075D71E7_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList*, zT_50FBF81E_Diagnostic);
zT_8D25846A_Slice_zT_50FBF81E_D zF_88E8322D_diagnosticArrayList(zT_C0B2E5AF_DiagnosticArrayList*);
zT_F85C5DED_DiagnosticCollector zF_C7BA7DAB_diagnosticCollector(zT_3E40CD83_Sand*, zT_227EDE07_SourceManager*, zT_D3EB6303_StringInterner*);
unsigned int zF_14631FFD_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_C82559AC_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, unsigned char, unsigned short, unsigned int, unsigned int, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_8F770780_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*);
unsigned int zF_4BDFF7E0_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*);
unsigned char zF_4DD9DB2D_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, unsigned int);
unsigned int zF_4AF2092E_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*);
void zF_426E1F18_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_A9049B03_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, unsigned int, unsigned int, unsigned int, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_E7E26C7E_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, unsigned int);
unsigned char zF_3D9E01BD_isIdentStartByte(unsigned char);
unsigned char zF_0998A79F_isIdentByte(unsigned char);
unsigned char zF_BCEBD9F2_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, unsigned int, unsigned int, unsigned int, unsigned int*, unsigned int*);
unsigned int zF_C887E05C_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, unsigned int, unsigned int, unsigned int, unsigned char);
unsigned int zF_DFE292F2_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*, unsigned int, unsigned int, unsigned int, unsigned char);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8C4BFF7C_diagnosticBuilderMa(zT_D3EB6303_StringInterner*, zT_8F083A69_Slice_zT_0B42B2F8_u*, unsigned int);
void zF_8E894A93_diagnosticCollector(zT_F85C5DED_DiagnosticCollector*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C14453DE_typeKindSrcStr(zT_33EF6BFB_TypeKind);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_CC479241_typeKindTgtStr(zT_33EF6BFB_TypeKind);
void zF_780653D2___module_init_3(void);
/* Storage globals (extern decls) */
extern zT_F85C5DED_DiagnosticCollector zG_F85C5DED_DiagnosticCollector;
extern unsigned short const zG_CD1D676D_ERR_1000_UNTERMINAT;
extern unsigned short const zG_03075056_ERR_1001_UNTERMINAT;
extern unsigned short const zG_28A81ECF_ERR_1002_INVALID_CH;
extern unsigned short const zG_C46AE43D_ERR_1003_INVALID_ES;
extern unsigned short const zG_9F2B9E01_ERR_1004_BARE_AT_SI;
extern unsigned short const zG_BDB44740_ERR_1005_UNRECOGNIZ;
extern unsigned short const zG_E5E7A1C2_WARN_1010_UNRECOGNI;
extern unsigned short const zG_F685B4FB_WARN_1011_INTEGER_O;
extern unsigned short const zG_21EFDA5B_ERR_3045_UNKNOWN_CA;
extern unsigned short const zG_20197026_ERR_3017_SUSPENDING;
extern unsigned int const zG_E55A587A_MAX_DIAGNOSTICS;

#endif /* ZIG_MODULE_DIAGNOSTICS_B9C6175E_H */
