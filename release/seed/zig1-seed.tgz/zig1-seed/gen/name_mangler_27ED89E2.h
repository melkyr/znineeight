#ifndef ZIG_MODULE_NAME_MANGLER_27ED89E2_H
#define ZIG_MODULE_NAME_MANGLER_27ED89E2_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "string_interner_51340A9F.h"
#include "type_registry_8EE489B8.h"
#include "allocator_E75B7A0B.h"
#include "hash_02AFCD13.h"
#include "itoa_4E677A6A.h"


/* Forward declarations */
void zF_8F8DE819_writeHex(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int*, unsigned int);
unsigned char zF_F2F86D29_isTempOrBuiltin(zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_5412D014_isC89Keyword(zT_CEC2984A_NameMangler*, unsigned int);
unsigned int zF_C3DD2126_mangleC89Keyword(zT_CEC2984A_NameMangler*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_F82AFAD8_nameManglerPopulate(zT_CEC2984A_NameMangler*);
zT_CEC2984A_NameMangler zF_27DA3900_nameManglerInit_1(zT_D3EB6303_StringInterner*, zT_3E40CD83_Sand*, unsigned int);
unsigned int zF_713D1938_nameManglerMangle(zT_CEC2984A_NameMangler*, unsigned int, unsigned char, unsigned int);
unsigned int zF_027E7C4F_nameManglerMangle_1(zT_CEC2984A_NameMangler*, zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_571F0158_nameManglerMintRaw(zT_CEC2984A_NameMangler*, unsigned int, unsigned int, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8D2701C5_nameManglerMintLoca(zT_CEC2984A_NameMangler*, unsigned int, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_455DE5CA_nameManglerMintFiel(zT_CEC2984A_NameMangler*, unsigned int, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_5EF2DC48_nameManglerMintMemb(zT_CEC2984A_NameMangler*, unsigned int, unsigned int);
unsigned int zF_79CB4DDA_nameManglerFnScope(zT_CEC2984A_NameMangler*, unsigned int, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_918A053C_nameManglerMintTemp(zT_CEC2984A_NameMangler*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_9DABAED9_nameManglerMintSynt(zT_CEC2984A_NameMangler*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C486DB29_nameManglerMintInde(zT_CEC2984A_NameMangler*, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C4A5232F_nameManglerMintModu(zT_CEC2984A_NameMangler*, zT_8F083A69_Slice_zT_0B42B2F8_u);
/* Storage globals (extern decls) */
extern zT_CEC2984A_NameMangler zG_CEC2984A_NameMangler;

#endif /* ZIG_MODULE_NAME_MANGLER_27ED89E2_H */
