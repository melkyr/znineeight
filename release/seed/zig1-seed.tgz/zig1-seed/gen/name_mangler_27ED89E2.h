#ifndef ZIG_MODULE_NAME_MANGLER_27ED89E2_H
#define ZIG_MODULE_NAME_MANGLER_27ED89E2_H

#include "zig_compat.h"
#include "zig_special_types.h"

#ifndef ZIG_STRUCT_zT_CEC2984A_NameMangler
#define ZIG_STRUCT_zT_CEC2984A_NameMangler
struct zT_CEC2984A_NameMangler {
	unsigned int counter;
};
#endif /* ZIG_STRUCT_zT_CEC2984A_NameMangler */

/* Forward declarations */
zT_CEC2984A_NameMangler zF_27DA3900_nameManglerInit(void);
/* Storage globals (extern decls) */
extern zT_CEC2984A_NameMangler zG_CEC2984A_NameMangler;

#endif /* ZIG_MODULE_NAME_MANGLER_27ED89E2_H */
