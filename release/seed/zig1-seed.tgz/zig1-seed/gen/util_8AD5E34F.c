#include "util_8AD5E34F.h"
/* min */
unsigned int zF_C98F4557_min(unsigned int a, unsigned int b) {
    int zT_2;
    zT_2 = a < b;
    if (zT_2) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    return a;
    return 0;
    z_bb_3:
    return b;
}

/* max */
unsigned int zF_D7A2E319_max(unsigned int a, unsigned int b) {
    int zT_2;
    zT_2 = a > b;
    if (zT_2) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    return a;
    return 0;
    z_bb_3:
    return b;
}

/* EOF */
