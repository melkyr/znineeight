#include "front_resolution_D5E9117C.h"
/* resolveTypeExpr */
unsigned int zF_EE3AA0D0_resolveTypeExpr(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, zT_F8B96B9C_Opt_393 scope, unsigned int source_file_id) {
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    zT_F85C5DED_DiagnosticCollector* zT_11;
    zT_7334F4FE_Opt_225 zT_12;
    zT_ABC1EBBE_TypeResolveEnv* zT_13;
    unsigned int zT_14;
    unsigned int zT_18 = 0;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_7 = ct->store;
    zT_6.store = zT_7;
    zT_8 = ct->typereg;
    zT_6.typereg = zT_8;
    zT_9 = ct->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = ct->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = module_id;
    zT_6.source_file_id = source_file_id;
    zT_11 = ct->diag;
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    zT_6.diag = zT_12;
    zT_6.local_consts = scope;
    env = zT_6;
    zT_13 = &env;
    zT_14 = node_idx;
    zT_18 = zF_F2107C15_resolveTypeExprFull(zT_13, zT_14, (unsigned int)(0));
    return zT_18;
}

/* countUntypedGlobals */
unsigned int zF_5DF8AD5B_countUntypedGlobals(zT_6DCFC8DB_FrontResCtx* ct) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_7;
    unsigned int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_11;
    zT_060CD1EB_SymbolTable* zT_12;
    zT_060CD1EB_SymbolTable zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_3A105EF1_Symbol* zT_20;
    zT_3A105EF1_Symbol zT_21;
    unsigned int zT_22;
    zT_3C598AEF_SymbolKind zT_25;
    int zT_30;
    zT_3C598AEF_SymbolKind zT_31;
    int zT_36;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int cnt;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol sym;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    cnt = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    ti = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = ct->symbol_reg;
    zT_8 = zT_7->tables_len;
    if ((int)(ti < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = ct->symbol_reg;
    zT_12 = zT_11->tables_items;
    zT_13 = zT_12[ti];
    table = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    si = zT_16;
    goto z_bb_5;
    z_bb_3:
    return cnt;
    z_bb_4:
    zT_41 = 1;
    zT_42 = ti + zT_41;
    ti = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_17 = table.len;
    if ((int)(si < zT_17)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = table.items;
    zT_21 = zT_20[si];
    sym = zT_21;
    zT_22 = sym.type_id;
    if ((int)(zT_22 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_39 = 1;
    zT_40 = si + zT_39;
    si = zT_40;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_25 = sym.kind;
    if ((int)(zT_25 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_31 = sym.kind;
    zT_30 = zT_31 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    goto z_bb_13;
    z_bb_12:
    zT_30 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_30) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_36 = 1;
    zT_38 = cnt + (unsigned int)((unsigned int)zT_36);
    cnt = zT_38;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
}

/* frontResolveModuleInits */
void zF_8A0E7747_frontResolveModuleI(zT_6DCFC8DB_FrontResCtx* ct) {
    zT_3E40CD83_Sand* zT_1;
    zT_6DCFC8DB_FrontResCtx* zT_4;
    unsigned int zT_5 = 0;
    unsigned int zT_7;
    int zT_9;
    unsigned int zT_10;
    unsigned char zT_13;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_3E40CD83_Sand* zT_24;
    zT_6E8D187B_ModuleEntry* zT_27;
    zT_6E8D187B_ModuleEntry zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    unsigned int zT_41 = 0;
    zT_6E8D187B_ModuleEntry* zT_43;
    zT_6E8D187B_ModuleEntry zT_44;
    unsigned int zT_45;
    zT_3E40CD83_Sand* zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_48;
    zT_F85C5DED_DiagnosticCollector* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_3D7259E2_SymbolRegistry* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_66E7D2EF_CoercionTable* zT_55;
    zT_21D3708C_U32ToU32Map* zT_56;
    zT_21D3708C_U32ToU32Map* zT_57;
    zT_D3EB6303_StringInterner* zT_58;
    zT_21D3708C_U32ToU32Map* zT_59;
    zT_21D3708C_U32ToU32Map* zT_60;
    zT_072B53A6_ModuleRegistry* zT_61;
    zT_A4CE86B7_U64ToU32Map* zT_62;
    zT_6E8D187B_ModuleEntry* zT_69;
    zT_6E8D187B_ModuleEntry zT_70;
    zT_38C12417_SemanticAnalyzer zT_80 = {0};
    int zT_82;
    unsigned int zT_83;
    zT_6B0A7D14_AstStore* zT_87;
    unsigned int zT_88;
    unsigned int zT_92 = 0;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_97 = {0};
    zT_8143F551_AstKind zT_98;
    unsigned int zT_103;
    zT_6DCFC8DB_FrontResCtx* zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    zT_F8B96B9C_Opt_393 zT_110;
    unsigned int zT_111;
    zT_6E8D187B_ModuleEntry* zT_112;
    zT_6E8D187B_ModuleEntry zT_113;
    zT_F8B96B9C_Opt_393 zT_116 = {0};
    unsigned int zT_117 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_8EED1867_ResolvedTypeTable* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_6B0A7D14_AstStore* zT_133;
    unsigned int zT_134;
    zT_22A7C88B_AstNode zT_137 = {0};
    zT_8143F551_AstKind zT_138;
    int zT_143;
    zT_8143F551_AstKind zT_144;
    zT_38C12417_SemanticAnalyzer* zT_150;
    unsigned int zT_151;
    unsigned int zT_153 = 0;
    zT_8143F551_AstKind zT_154;
    zT_6E8D187B_ModuleEntry* zT_162;
    zT_6E8D187B_ModuleEntry zT_163;
    unsigned int zT_164;
    zT_6B0A7D14_AstStore* zT_168;
    unsigned int zT_169;
    unsigned int zT_171 = 0;
    zT_79FAE712_u64 zT_173;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_79FAE712_u64 zT_175;
    unsigned int zT_176;
    zT_6B0A7D14_AstStore* zT_179;
    unsigned int zT_180;
    unsigned int zT_183 = 0;
    zT_3D7259E2_SymbolRegistry* zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    zT_6E8D187B_ModuleEntry* zT_189;
    zT_6E8D187B_ModuleEntry zT_190;
    zT_CF761179_Opt_853 zT_192 = {0};
    unsigned char zT_193;
    zT_3C598AEF_SymbolKind zT_195;
    zT_3D7259E2_SymbolRegistry* zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    zT_6E8D187B_ModuleEntry* zT_205;
    zT_6E8D187B_ModuleEntry zT_206;
    zT_6B0A7D14_AstStore* zT_208;
    unsigned int zT_209;
    unsigned int zT_211 = 0;
    zT_CF761179_Opt_853 zT_212 = {0};
    unsigned char zT_213;
    zT_3C598AEF_SymbolKind zT_215;
    unsigned char zT_223;
    zT_8EED1867_ResolvedTypeTable* zT_225;
    unsigned int zT_226;
    zT_BAEE192E_Opt_10 zT_228 = {0};
    int zT_231;
    int zT_234;
    int zT_237;
    unsigned char zT_238;
    zT_8EED1867_ResolvedTypeTable* zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    int zT_246;
    unsigned int zT_247;
    zT_8EED1867_ResolvedTypeTable* zT_251;
    unsigned int zT_252;
    zT_BAEE192E_Opt_10 zT_255 = {0};
    unsigned char zT_256;
    zT_8EED1867_ResolvedTypeTable* zT_260;
    unsigned int zT_261;
    unsigned int zT_262;
    int zT_267;
    int zT_270;
    int zT_273;
    zT_6B0A7D14_AstStore* zT_277;
    unsigned int zT_278;
    unsigned int zT_280 = 0;
    zT_3D7259E2_SymbolRegistry* zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    zT_6E8D187B_ModuleEntry* zT_286;
    zT_6E8D187B_ModuleEntry zT_287;
    zT_CF761179_Opt_853 zT_289 = {0};
    unsigned char zT_290;
    unsigned int zT_292;
    unsigned char zT_295;
    int zT_296;
    unsigned int zT_297;
    int zT_298;
    unsigned int zT_299;
    int zT_302;
    unsigned int zT_303;
    zT_3E40CD83_Sand* zT_304;
    unsigned int bound;
    unsigned int iter;
    unsigned char changed;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    unsigned int decls_n;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int rtype;
    zT_22A7C88B_AstNode init;
    unsigned int init_type;
    zT_BAEE192E_Opt_10 vd_existing;
    zT_79FAE712_u64 ck;
    unsigned int ref_name;
    zT_CF761179_Opt_853 ref_sym;
    zT_3A105EF1_Symbol* rs;
    zT_CF761179_Opt_853 own_sym;
    zT_3A105EF1_Symbol* os;
    zT_BAEE192E_Opt_10 mdt2;
    unsigned int mt2;
    unsigned int name_id;
    zT_CF761179_Opt_853 sym;
    zT_3A105EF1_Symbol* s;
    zT_1 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_1);
    zT_4 = ct;
    zT_5 = zF_5DF8AD5B_countUntypedGlobals(zT_4);
    zT_7 = zT_5 + (unsigned int)(1);
    bound = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    iter = zT_10;
    goto z_bb_1;
    z_bb_1:
    if ((int)(iter < bound)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = 0;
    changed = zT_13;
    zT_15 = ct->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_5;
    z_bb_3:
    zT_304 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_304);
    return;
    z_bb_4:
    zT_302 = 1;
    zT_303 = iter + zT_302;
    iter = zT_303;
    goto z_bb_1;
    z_bb_5:
    zT_22 = mods.len;
    if ((int)(mi < zT_22)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_24 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_24);
    zT_27 = mods.ptr;
    zT_28 = zT_27[mi];
    zT_29 = zT_28.ast_root;
    ast_root = zT_29;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    if ((int)(changed == (unsigned char)(0))) goto z_bb_75; else goto z_bb_76;
    z_bb_8:
    zT_298 = 1;
    zT_299 = mi + zT_298;
    mi = zT_299;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_33 = ct->store;
    zT_34 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    zT_38 = ct->store;
    zT_39 = ast_root;
    zT_41 = zF_152E19CB_astStoreNodeExtraCh(zT_38, zT_39);
    decls_n = zT_41;
    zT_43 = mods.ptr;
    zT_44 = zT_43[mi];
    zT_45 = zT_44.source_file_id;
    src_fid = zT_45;
    zT_47 = ct->scratch;
    zT_48 = ct->resolved_types;
    zT_49 = ct->diag;
    zT_50 = ct->typereg;
    zT_51 = ct->symbol_reg;
    zT_52 = ct->store;
    zT_69 = mods.ptr;
    zT_70 = zT_69[mi];
    zT_53 = zT_70.id;
    zT_54 = src_fid;
    zT_55 = ct->coercion_table;
    zT_56 = ct->enum_value_table;
    zT_57 = ct->error_code_registry;
    zT_58 = ct->interner;
    zT_59 = ct->call_arg_types;
    zT_60 = ct->call_param_map;
    zT_61 = ct->module_reg;
    zT_62 = ct->suspending_fns;
    zT_80 = zF_84ADA681_semanticAnalyzerIni(zT_47, zT_48, zT_49, zT_50, zT_51, zT_52, zT_53, zT_54, zT_55, zT_56, zT_57, zT_58, zT_59, zT_60, zT_61, zT_62);
    sa = zT_80;
    zT_82 = 0;
    zT_83 = (unsigned int)zT_82;
    di = zT_83;
    goto z_bb_11;
    z_bb_11:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_87 = ct->store;
    zT_88 = ast_root;
    zT_92 = zF_B10B1BC1_astStoreNodeExtraCh(zT_87, zT_88, (unsigned int)((unsigned int)di));
    decl_idx = zT_92;
    zT_94 = ct->store;
    zT_95 = decl_idx;
    zT_97 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    decl = zT_97;
    zT_98 = decl.kind;
    if ((int)(zT_98 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    zT_296 = 1;
    zT_297 = di + zT_296;
    di = zT_297;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    zT_103 = decl.child_0;
    if ((int)(zT_103 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_107 = ct;
    zT_112 = mods.ptr;
    zT_113 = zT_112[mi];
    zT_108 = zT_113.id;
    zT_109 = decl.child_0;
    zT_116.has_value = 0;
    zT_110 = zT_116;
    zT_111 = src_fid;
    zT_117 = zF_EE3AA0D0_resolveTypeExpr(zT_107, zT_108, zT_109, zT_110, zT_111);
    rtype = zT_117;
    if ((int)(rtype != (unsigned int)(18))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_129 = decl.child_1;
    if ((int)(zT_129 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_120 = ct->resolved_types;
    zT_121 = decl.child_0;
    zT_122 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_120, zT_121, zT_122);
    zT_125 = ct->resolved_types;
    zT_126 = decl_idx;
    zT_127 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_125, zT_126, zT_127);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_133 = ct->store;
    zT_134 = decl.child_1;
    zT_137 = zF_FCDD1D35_astStoreNodeAt(zT_133, zT_134);
    init = zT_137;
    zT_138 = init.kind;
    if ((int)(zT_138 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_14;
    z_bb_23:
    zT_144 = init.kind;
    zT_143 = zT_144 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_25;
    z_bb_24:
    zT_143 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_143) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_150 = &sa;
    zT_151 = decl_idx;
    zT_153 = zF_CC4377FA_semanticAnalyzerRes(zT_150, zT_151);
    init_type = zT_153;
    zT_154 = init.kind;
    if ((int)(zT_154 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    if ((int)(init_type != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_225 = ct->resolved_types;
    zT_226 = decl_idx;
    zT_228 = zF_999DCF51_resolvedTypeTableGe(zT_225, zT_226);
    vd_existing = zT_228;
    if ((int)(init_type != (unsigned int)(1))) goto z_bb_40; else goto z_bb_41;
    z_bb_30:
    zT_162 = mods.ptr;
    zT_163 = zT_162[mi];
    zT_164 = zT_163.id;
    zT_168 = ct->store;
    zT_169 = decl_idx;
    zT_171 = zF_8BA26B9E_astStoreNodePayload(zT_168, zT_169);
    zT_173 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_164) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_171);
    ck = zT_173;
    zT_174 = ct->typereg;
    zT_175 = ck;
    zT_176 = init_type;
    zF_5E95558D_nameCachePut(zT_174, zT_175, zT_176);
    goto z_bb_31;
    z_bb_31:
    zT_179 = ct->store;
    zT_180 = decl.child_1;
    zT_183 = zF_53458827_astStoreIdentifier(zT_179, zT_180);
    ref_name = zT_183;
    zT_185 = ct->symbol_reg;
    zT_189 = mods.ptr;
    zT_190 = zT_189[mi];
    zT_186 = zT_190.id;
    zT_187 = ref_name;
    zT_192 = zF_A398987E_symbolRegistryQuali(zT_185, zT_186, zT_187);
    ref_sym = zT_192;
    zT_193 = ref_sym.has_value;
    if (zT_193) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    rs = ref_sym.value;
    zT_195 = rs->kind;
    if ((int)(zT_195 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    zT_201 = ct->symbol_reg;
    zT_205 = mods.ptr;
    zT_206 = zT_205[mi];
    zT_202 = zT_206.id;
    zT_208 = ct->store;
    zT_209 = decl_idx;
    zT_211 = zF_8BA26B9E_astStoreNodePayload(zT_208, zT_209);
    zT_203 = zT_211;
    zT_212 = zF_A398987E_symbolRegistryQuali(zT_201, zT_202, zT_203);
    own_sym = zT_212;
    zT_213 = own_sym.has_value;
    if (zT_213) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    os = own_sym.value;
    zT_215 = os->kind;
    if ((int)(zT_215 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    os->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_223 = 1;
    changed = zT_223;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    zT_231 = init_type != (unsigned int)(18);
    goto z_bb_42;
    z_bb_41:
    zT_231 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_231) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_234 = init_type != (unsigned int)(20);
    goto z_bb_45;
    z_bb_44:
    zT_234 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_234) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_238 = vd_existing.has_value;
    zT_237 = !zT_238;
    goto z_bb_48;
    z_bb_47:
    zT_237 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_237) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_240 = ct->resolved_types;
    zT_241 = decl_idx;
    zT_242 = init_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_240, zT_241, zT_242);
    goto z_bb_50;
    z_bb_50:
    if ((int)(init_type == (unsigned int)(19))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_247 = decl.child_0;
    zT_246 = zT_247 != (unsigned int)(0);
    goto z_bb_53;
    z_bb_52:
    zT_246 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_246) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_251 = ct->resolved_types;
    zT_252 = decl.child_0;
    zT_255 = zF_999DCF51_resolvedTypeTableGe(zT_251, zT_252);
    mdt2 = zT_255;
    zT_256 = mdt2.has_value;
    if (zT_256) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if ((int)(init_type != (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_56:
    mt2 = mdt2.value;
    if ((int)(mt2 != (unsigned int)(18))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    goto z_bb_55;
    z_bb_58:
    zT_260 = ct->resolved_types;
    zT_261 = decl.child_1;
    zT_262 = mt2;
    zF_19B4A07D_resolvedTypeTableSe(zT_260, zT_261, zT_262);
    goto z_bb_59;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    zT_267 = init_type != (unsigned int)(1);
    goto z_bb_62;
    z_bb_61:
    zT_267 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_267) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_270 = init_type != (unsigned int)(18);
    goto z_bb_65;
    z_bb_64:
    zT_270 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_270) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_273 = init_type != (unsigned int)(20);
    goto z_bb_68;
    z_bb_67:
    zT_273 = 0;
    goto z_bb_68;
    z_bb_68:
    if (zT_273) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_277 = ct->store;
    zT_278 = decl_idx;
    zT_280 = zF_8BA26B9E_astStoreNodePayload(zT_277, zT_278);
    name_id = zT_280;
    zT_282 = ct->symbol_reg;
    zT_286 = mods.ptr;
    zT_287 = zT_286[mi];
    zT_283 = zT_287.id;
    zT_284 = name_id;
    zT_289 = zF_A398987E_symbolRegistryQuali(zT_282, zT_283, zT_284);
    sym = zT_289;
    zT_290 = sym.has_value;
    if (zT_290) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    goto z_bb_27;
    z_bb_71:
    s = sym.value;
    zT_292 = s->type_id;
    if ((int)(zT_292 == (unsigned int)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    goto z_bb_70;
    z_bb_73:
    s->type_id = init_type;
    zT_295 = 1;
    changed = zT_295;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_72;
    z_bb_75:
    goto z_bb_3;
    z_bb_76:
    goto z_bb_4;
}

/* resolveStmtTypes */
void zF_783226DA_resolveStmtTypes(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth, unsigned int source_file_id) {
    zT_3E40CD83_Sand* zT_6;
    zT_E2DF2801_LocalConstScope zT_8 = {0};
    zT_6DCFC8DB_FrontResCtx* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_E2DF2801_LocalConstScope* zT_14;
    zT_E2DF2801_LocalConstScope scope;
    zT_6 = ct->scratch;
    zT_8 = zF_F5EBC2FF_localConstScopeInit(zT_6);
    scope = zT_8;
    zT_9 = ct;
    zT_10 = module_id;
    zT_11 = node_idx;
    zT_12 = depth;
    zT_13 = source_file_id;
    zT_14 = &scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_9, zT_10, zT_11, zT_12, zT_13, zT_14);
    return;
}

/* resolveStmtTypesRec */
void zF_B1CC762C_resolveStmtTypesRec(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth, unsigned int source_file_id, zT_E2DF2801_LocalConstScope* scope) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    zT_8143F551_AstKind zT_13;
    unsigned int zT_18;
    int zT_19;
    zT_6DCFC8DB_FrontResCtx* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_F8B96B9C_Opt_393 zT_25;
    unsigned int zT_26;
    zT_F8B96B9C_Opt_393 zT_28;
    unsigned int zT_29 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_8EED1867_ResolvedTypeTable* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    int zT_46;
    unsigned int zT_47;
    int zT_48;
    zT_E2DF2801_LocalConstScope* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_56 = 0;
    zT_8143F551_AstKind zT_57;
    int zT_62;
    zT_8143F551_AstKind zT_63;
    int zT_68;
    zT_8143F551_AstKind zT_69;
    unsigned int zT_74;
    int zT_75;
    zT_6DCFC8DB_FrontResCtx* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    zT_F8B96B9C_Opt_393 zT_81;
    unsigned int zT_82;
    zT_F8B96B9C_Opt_393 zT_84;
    unsigned int zT_85 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_8143F551_AstKind zT_93;
    unsigned int zT_99;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    unsigned int zT_104 = 0;
    int zT_106;
    unsigned int zT_107;
    zT_6DCFC8DB_FrontResCtx* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_114;
    zT_E2DF2801_LocalConstScope* zT_115;
    zT_6B0A7D14_AstStore* zT_116;
    unsigned int zT_117;
    unsigned int zT_121 = 0;
    int zT_124;
    unsigned int zT_125;
    unsigned int zT_128;
    zT_8143F551_AstKind zT_129;
    unsigned int zT_134;
    int zT_135;
    zT_6DCFC8DB_FrontResCtx* zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    zT_E2DF2801_LocalConstScope* zT_142;
    unsigned int zT_144;
    int zT_145;
    zT_6DCFC8DB_FrontResCtx* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_E2DF2801_LocalConstScope* zT_152;
    zT_22A7C88B_AstNode node;
    unsigned int rtype;
    unsigned int scope_base;
    unsigned int decls_n;
    unsigned int di;
    unsigned int cd;
    if ((int)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = ct->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_13 = node.kind;
    if ((int)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = node.child_0;
    zT_19 = 0;
    if ((int)(zT_18 != (unsigned int)zT_19)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_57 = node.kind;
    if ((int)(zT_57 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_15; else goto z_bb_14;
    z_bb_5:
    zT_22 = ct;
    zT_23 = module_id;
    zT_24 = node.child_0;
    zT_28.has_value = 1;
    zT_28.value = scope;
    zT_25 = zT_28;
    zT_26 = source_file_id;
    zT_29 = zF_EE3AA0D0_resolveTypeExpr(zT_22, zT_23, zT_24, zT_25, zT_26);
    rtype = zT_29;
    if ((int)(rtype != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_41 = node.flags;
    if ((int)((unsigned char)(zT_41 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_32 = ct->resolved_types;
    zT_33 = node.child_0;
    zT_34 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_32, zT_33, zT_34);
    zT_37 = ct->resolved_types;
    zT_38 = node_idx;
    zT_39 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_37, zT_38, zT_39);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_47 = node.child_1;
    zT_48 = 0;
    zT_46 = zT_47 != (unsigned int)zT_48;
    goto z_bb_11;
    z_bb_10:
    zT_46 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_46) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_50 = scope;
    zT_53 = ct->store;
    zT_54 = node_idx;
    zT_56 = zF_8BA26B9E_astStoreNodePayload(zT_53, zT_54);
    zT_51 = zT_56;
    zT_52 = node_idx;
    zF_DA915531_localConstScopePush(zT_50, zT_51, zT_52);
    goto z_bb_13;
    z_bb_13:
    goto z_bb_4;
    z_bb_14:
    zT_63 = node.kind;
    zT_62 = zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init);
    goto z_bb_16;
    z_bb_15:
    zT_62 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_62) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_69 = node.kind;
    zT_68 = zT_69 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_19;
    z_bb_18:
    zT_68 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_68) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_74 = node.child_0;
    zT_75 = 0;
    if ((int)(zT_74 != (unsigned int)zT_75)) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_93 = node.kind;
    if ((int)(zT_93 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_26; else goto z_bb_27;
    z_bb_22:
    zT_78 = ct;
    zT_79 = module_id;
    zT_80 = node.child_0;
    zT_84.has_value = 1;
    zT_84.value = scope;
    zT_81 = zT_84;
    zT_82 = source_file_id;
    zT_85 = zF_EE3AA0D0_resolveTypeExpr(zT_78, zT_79, zT_80, zT_81, zT_82);
    rtype = zT_85;
    if ((int)(rtype != (unsigned int)(18))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_88 = ct->resolved_types;
    zT_89 = node.child_0;
    zT_90 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_88, zT_89, zT_90);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_99 = scope->count;
    scope_base = zT_99;
    zT_101 = ct->store;
    zT_102 = node_idx;
    zT_104 = zF_152E19CB_astStoreNodeExtraCh(zT_101, zT_102);
    decls_n = zT_104;
    zT_106 = 0;
    zT_107 = (unsigned int)zT_106;
    di = zT_107;
    goto z_bb_28;
    z_bb_27:
    zT_128 = depth + (unsigned int)(1);
    cd = zT_128;
    zT_129 = node.kind;
    if ((int)(zT_129 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_32; else goto z_bb_33;
    z_bb_28:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_110 = ct;
    zT_111 = module_id;
    zT_116 = ct->store;
    zT_117 = node_idx;
    zT_121 = zF_B10B1BC1_astStoreNodeExtraCh(zT_116, zT_117, (unsigned int)((unsigned int)di));
    zT_112 = zT_121;
    zT_114 = source_file_id;
    zT_115 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_110, zT_111, zT_112, (unsigned int)(depth + (unsigned int)(1)), zT_114, zT_115);
    goto z_bb_31;
    z_bb_30:
    scope->count = scope_base;
    goto z_bb_27;
    z_bb_31:
    zT_124 = 1;
    zT_125 = di + zT_124;
    di = zT_125;
    goto z_bb_28;
    z_bb_32:
    zT_134 = node.child_0;
    zT_135 = 0;
    if ((int)(zT_134 != (unsigned int)zT_135)) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    return;
    z_bb_34:
    zT_137 = ct;
    zT_138 = module_id;
    zT_139 = node.child_0;
    zT_140 = cd;
    zT_141 = source_file_id;
    zT_142 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_137, zT_138, zT_139, zT_140, zT_141, zT_142);
    goto z_bb_35;
    z_bb_35:
    zT_144 = node.child_1;
    zT_145 = 0;
    if ((int)(zT_144 != (unsigned int)zT_145)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_147 = ct;
    zT_148 = module_id;
    zT_149 = node.child_1;
    zT_150 = cd;
    zT_151 = source_file_id;
    zT_152 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_147, zT_148, zT_149, zT_150, zT_151, zT_152);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_33;
}

/* __module_init */
void zF_780653D2___module_init_20(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_F85C5DED_DiagnosticCollector zT_2 = {0};
    zT_8143F551_AstKind zT_3 = 0;
    zT_6B0A7D14_AstStore zT_4 = {0};
    zT_072B53A6_ModuleRegistry zT_5 = {0};
    zT_3D7259E2_SymbolRegistry zT_6 = {0};
    zT_338B7C76_TypeRegistry zT_7 = {0};
    zT_8EED1867_ResolvedTypeTable zT_8 = {0};
    zT_66E7D2EF_CoercionTable zT_9 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_F85C5DED_DiagnosticCollector = zT_2;
    zG_8143F551_AstKind = zT_3;
    zG_6B0A7D14_AstStore = zT_4;
    zG_072B53A6_ModuleRegistry = zT_5;
    zG_3D7259E2_SymbolRegistry = zT_6;
    zG_338B7C76_TypeRegistry = zT_7;
    zG_8EED1867_ResolvedTypeTable = zT_8;
    zG_66E7D2EF_CoercionTable = zT_9;
    return;
}

/* EOF */
