#include "front_resolution_D5E9117C.h"
/* resolveTypeExpr */
unsigned int zF_EE3AA0D0_resolveTypeExpr(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx) {
    zT_ABC1EBBE_TypeResolveEnv zT_4;
    zT_6B0A7D14_AstStore* zT_5;
    zT_338B7C76_TypeRegistry* zT_6;
    zT_3D7259E2_SymbolRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_ABC1EBBE_TypeResolveEnv* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_ABC1EBBE_TypeResolveEnv* zT_12;
    unsigned int zT_13;
    unsigned int zT_14 = 0;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_5 = ct->store;
    zT_4.store = zT_5;
    zT_6 = ct->typereg;
    zT_4.typereg = zT_6;
    zT_7 = ct->symbol_reg;
    zT_4.symbol_reg = zT_7;
    zT_8 = ct->interner;
    zT_4.interner = zT_8;
    zT_4.module_id = module_id;
    env = zT_4;
    env = zT_4;
    env = zT_4;
    zT_12 = &env;
    zT_9 = zT_12;
    zT_10 = node_idx;
    zT_13 = 0;
    zT_11 = zT_13;
    zT_14 = zF_F2107C15_resolveTypeExprFull(zT_9, zT_10, zT_11);
    return zT_14;
}

/* countUntypedGlobals */
unsigned int zF_5DF8AD5B_countUntypedGlobals(zT_6DCFC8DB_FrontResCtx* ct) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_7;
    unsigned int zT_8;
    int zT_9;
    zT_3D7259E2_SymbolRegistry* zT_11;
    zT_060CD1EB_SymbolTable* zT_12;
    zT_060CD1EB_SymbolTable zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_18;
    zT_3A105EF1_Symbol* zT_20;
    zT_3A105EF1_Symbol zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    zT_3C598AEF_SymbolKind zT_25;
    zT_3C598AEF_SymbolKind zT_28;
    int zT_29;
    int zT_30;
    zT_3C598AEF_SymbolKind zT_31;
    zT_3C598AEF_SymbolKind zT_34;
    int zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int cnt;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol sym;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    cnt = zT_3;
    cnt = zT_3;
    cnt = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    ti = zT_6;
    ti = zT_6;
    ti = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = ct->symbol_reg;
    zT_8 = zT_7->tables_len;
    zT_9 = ti < zT_8;
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = ct->symbol_reg;
    zT_12 = zT_11->tables_items;
    zT_13 = zT_12[ti];
    table = zT_13;
    table = zT_13;
    table = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    si = zT_16;
    si = zT_16;
    si = zT_16;
    goto z_bb_5;
    z_bb_3:
    return cnt;
    z_bb_4:
    zT_41 = 1;
    zT_42 = ti + zT_41;
    ti = zT_42;
    ti = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_17 = table.len;
    zT_18 = si < zT_17;
    if (zT_18) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = table.items;
    zT_21 = zT_20[si];
    sym = zT_21;
    sym = zT_21;
    sym = zT_21;
    zT_22 = sym.type_id;
    zT_23 = 0;
    zT_24 = zT_22 != zT_23;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_39 = 1;
    zT_40 = si + zT_39;
    si = zT_40;
    si = zT_40;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_25 = sym.kind;
    zT_28 = zT_3C598AEF_SymbolKind_global;
    zT_29 = zT_25 == zT_28;
    if (zT_29) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_31 = sym.kind;
    zT_34 = zT_3C598AEF_SymbolKind_type_alias;
    zT_35 = zT_31 == zT_34;
    zT_30 = zT_35;
    goto z_bb_13;
    z_bb_12:
    zT_30 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_30) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_36 = 1;
    zT_37 = (unsigned int)zT_36;
    zT_38 = cnt + zT_37;
    cnt = zT_38;
    cnt = zT_38;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
}

/* frontResolveModuleInits */
void zF_8A0E7747_frontResolveModuleI(zT_6DCFC8DB_FrontResCtx* ct) {
    zT_3E40CD83_Sand* zT_1;
    zT_3E40CD83_Sand* zT_2;
    zT_6DCFC8DB_FrontResCtx* zT_4;
    unsigned int zT_5 = 0;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned char zT_13;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_072B53A6_ModuleRegistry* zT_16;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    int zT_23;
    zT_3E40CD83_Sand* zT_24;
    zT_3E40CD83_Sand* zT_25;
    zT_6E8D187B_ModuleEntry* zT_27;
    zT_6E8D187B_ModuleEntry zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_35;
    zT_22A7C88B_AstNode zT_36 = {0};
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_6B0A7D14_AstStore* zT_40;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_41 = {0};
    zT_6E8D187B_ModuleEntry* zT_43;
    zT_6E8D187B_ModuleEntry zT_44;
    unsigned int zT_45;
    zT_3E40CD83_Sand* zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_48;
    zT_F85C5DED_DiagnosticCollector* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_3D7259E2_SymbolRegistry* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_66E7D2EF_CoercionTable* zT_55;
    zT_21D3708C_U32ToU32Map* zT_56;
    zT_21D3708C_U32ToU32Map* zT_57;
    zT_D3EB6303_StringInterner* zT_58;
    zT_21D3708C_U32ToU32Map* zT_59;
    zT_21D3708C_U32ToU32Map* zT_60;
    zT_072B53A6_ModuleRegistry* zT_61;
    zT_3E40CD83_Sand* zT_62;
    zT_8EED1867_ResolvedTypeTable* zT_63;
    zT_F85C5DED_DiagnosticCollector* zT_64;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_3D7259E2_SymbolRegistry* zT_66;
    zT_6B0A7D14_AstStore* zT_67;
    zT_6E8D187B_ModuleEntry* zT_68;
    zT_6E8D187B_ModuleEntry zT_69;
    unsigned int zT_70;
    zT_66E7D2EF_CoercionTable* zT_71;
    zT_21D3708C_U32ToU32Map* zT_72;
    zT_21D3708C_U32ToU32Map* zT_73;
    zT_D3EB6303_StringInterner* zT_74;
    zT_21D3708C_U32ToU32Map* zT_75;
    zT_21D3708C_U32ToU32Map* zT_76;
    zT_072B53A6_ModuleRegistry* zT_77;
    zT_38C12417_SemanticAnalyzer zT_78 = {0};
    int zT_80;
    unsigned int zT_81;
    unsigned int zT_83;
    int zT_84;
    zT_6B0A7D14_AstStore* zT_86;
    unsigned int zT_87;
    zT_6B0A7D14_AstStore* zT_88;
    unsigned int* zT_89;
    unsigned int zT_90;
    zT_22A7C88B_AstNode zT_91 = {0};
    zT_8143F551_AstKind zT_92;
    zT_8143F551_AstKind zT_95;
    int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    int zT_99;
    zT_6DCFC8DB_FrontResCtx* zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_6E8D187B_ModuleEntry* zT_104;
    zT_6E8D187B_ModuleEntry zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_108 = 0;
    unsigned int zT_109;
    int zT_110;
    zT_8EED1867_ResolvedTypeTable* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    zT_8EED1867_ResolvedTypeTable* zT_114;
    unsigned int zT_115;
    zT_8EED1867_ResolvedTypeTable* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_8EED1867_ResolvedTypeTable* zT_119;
    unsigned int* zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    int zT_124;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    zT_6B0A7D14_AstStore* zT_128;
    unsigned int zT_129;
    zT_22A7C88B_AstNode zT_130 = {0};
    zT_8143F551_AstKind zT_131;
    zT_8143F551_AstKind zT_134;
    int zT_135;
    int zT_136;
    zT_8143F551_AstKind zT_137;
    zT_8143F551_AstKind zT_140;
    int zT_141;
    zT_38C12417_SemanticAnalyzer* zT_143;
    unsigned int zT_144;
    zT_38C12417_SemanticAnalyzer* zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    unsigned int zT_148 = 0;
    zT_8143F551_AstKind zT_149;
    zT_8143F551_AstKind zT_152;
    int zT_153;
    unsigned int zT_154;
    int zT_155;
    zT_6E8D187B_ModuleEntry* zT_157;
    zT_6E8D187B_ModuleEntry zT_158;
    unsigned int zT_159;
    zT_79FAE712_u64 zT_160;
    zT_79FAE712_u64 zT_161;
    zT_79FAE712_u64 zT_162;
    zT_6B0A7D14_AstStore* zT_163;
    unsigned int zT_164;
    zT_6B0A7D14_AstStore* zT_165;
    unsigned int* zT_166;
    unsigned int zT_167;
    unsigned int zT_168 = 0;
    zT_79FAE712_u64 zT_169;
    zT_79FAE712_u64 zT_170;
    zT_338B7C76_TypeRegistry* zT_171;
    zT_79FAE712_u64 zT_172;
    unsigned int zT_173;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_8EED1867_ResolvedTypeTable* zT_176;
    unsigned int zT_177;
    zT_8EED1867_ResolvedTypeTable* zT_178;
    unsigned int* zT_179;
    unsigned int zT_180;
    zT_BAEE192E_Opt_10 zT_181 = {0};
    unsigned int zT_182;
    int zT_183;
    int zT_184;
    unsigned int zT_185;
    int zT_186;
    int zT_187;
    unsigned int zT_188;
    int zT_189;
    int zT_190;
    unsigned char zT_191;
    int zT_192;
    zT_8EED1867_ResolvedTypeTable* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    zT_8EED1867_ResolvedTypeTable* zT_196;
    unsigned int* zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    int zT_200;
    int zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    int zT_204;
    zT_8EED1867_ResolvedTypeTable* zT_206;
    unsigned int zT_207;
    zT_8EED1867_ResolvedTypeTable* zT_208;
    unsigned int zT_209;
    zT_BAEE192E_Opt_10 zT_210 = {0};
    unsigned char zT_211;
    unsigned int zT_213;
    int zT_214;
    zT_8EED1867_ResolvedTypeTable* zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    zT_8EED1867_ResolvedTypeTable* zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    int zT_221;
    int zT_222;
    unsigned int zT_223;
    int zT_224;
    int zT_225;
    unsigned int zT_226;
    int zT_227;
    int zT_228;
    unsigned int zT_229;
    int zT_230;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    zT_6B0A7D14_AstStore* zT_234;
    unsigned int* zT_235;
    unsigned int zT_236;
    unsigned int zT_237 = 0;
    zT_3D7259E2_SymbolRegistry* zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_3D7259E2_SymbolRegistry* zT_242;
    zT_6E8D187B_ModuleEntry* zT_243;
    zT_6E8D187B_ModuleEntry zT_244;
    unsigned int zT_245;
    zT_4108E5FF_Opt_796 zT_246 = {0};
    unsigned char zT_247;
    unsigned int zT_249;
    unsigned int zT_250;
    int zT_251;
    unsigned char zT_252;
    int zT_253;
    unsigned int zT_254;
    int zT_255;
    unsigned int zT_256;
    unsigned char zT_257;
    int zT_258;
    int zT_259;
    unsigned int zT_260;
    zT_3E40CD83_Sand* zT_261;
    zT_3E40CD83_Sand* zT_262;
    unsigned int bound;
    unsigned int iter;
    unsigned char changed;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    unsigned int rtype;
    zT_22A7C88B_AstNode init;
    unsigned int init_type;
    zT_BAEE192E_Opt_10 vd_existing;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 mdt2;
    unsigned int mt2;
    unsigned int name_id;
    zT_4108E5FF_Opt_796 sym;
    zT_3A105EF1_Symbol* s;
    zT_2 = ct->scratch;
    zT_1 = zT_2;
    zF_F1B3F8C2_sandReset(zT_1);
    zT_4 = ct;
    zT_5 = zF_5DF8AD5B_countUntypedGlobals(zT_4);
    zT_6 = 1;
    zT_7 = zT_5 + zT_6;
    bound = zT_7;
    bound = zT_7;
    bound = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    iter = zT_10;
    iter = zT_10;
    iter = zT_10;
    goto z_bb_1;
    z_bb_1:
    zT_11 = iter < bound;
    if (zT_11) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = 0;
    changed = zT_13;
    changed = zT_13;
    changed = zT_13;
    zT_16 = ct->module_reg;
    zT_15 = zT_16;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    mods = zT_17;
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    mi = zT_20;
    mi = zT_20;
    goto z_bb_5;
    z_bb_3:
    zT_262 = ct->scratch;
    zT_261 = zT_262;
    zF_F1B3F8C2_sandReset(zT_261);
    return;
    z_bb_4:
    zT_259 = 1;
    zT_260 = iter + zT_259;
    iter = zT_260;
    iter = zT_260;
    goto z_bb_1;
    z_bb_5:
    zT_22 = mods.len;
    zT_23 = mi < zT_22;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25 = ct->scratch;
    zT_24 = zT_25;
    zF_F1B3F8C2_sandReset(zT_24);
    zT_27 = mods.ptr;
    zT_28 = zT_27[mi];
    zT_29 = zT_28.ast_root;
    ast_root = zT_29;
    ast_root = zT_29;
    ast_root = zT_29;
    zT_30 = 0;
    zT_31 = ast_root == zT_30;
    if (zT_31) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_257 = 0;
    zT_258 = changed == zT_257;
    if (zT_258) goto z_bb_67; else goto z_bb_68;
    z_bb_8:
    zT_255 = 1;
    zT_256 = mi + zT_255;
    mi = zT_256;
    mi = zT_256;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_35 = ct->store;
    zT_33 = zT_35;
    zT_34 = ast_root;
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    (void)zT_36;
    zT_40 = ct->store;
    zT_38 = zT_40;
    zT_39 = ast_root;
    zT_41 = zF_850FDF81_astStoreNodeExtraCh(zT_38, zT_39);
    decls = zT_41;
    decls = zT_41;
    decls = zT_41;
    zT_43 = mods.ptr;
    zT_44 = zT_43[mi];
    zT_45 = zT_44.source_file_id;
    src_fid = zT_45;
    src_fid = zT_45;
    src_fid = zT_45;
    zT_62 = ct->scratch;
    zT_47 = zT_62;
    zT_63 = ct->resolved_types;
    zT_48 = zT_63;
    zT_64 = ct->diag;
    zT_49 = zT_64;
    zT_65 = ct->typereg;
    zT_50 = zT_65;
    zT_66 = ct->symbol_reg;
    zT_51 = zT_66;
    zT_67 = ct->store;
    zT_52 = zT_67;
    zT_68 = mods.ptr;
    zT_69 = zT_68[mi];
    zT_70 = zT_69.id;
    zT_53 = zT_70;
    zT_54 = src_fid;
    zT_71 = ct->coercion_table;
    zT_55 = zT_71;
    zT_72 = ct->enum_value_table;
    zT_56 = zT_72;
    zT_73 = ct->error_code_registry;
    zT_57 = zT_73;
    zT_74 = ct->interner;
    zT_58 = zT_74;
    zT_75 = ct->call_arg_types;
    zT_59 = zT_75;
    zT_76 = ct->call_param_map;
    zT_60 = zT_76;
    zT_77 = ct->module_reg;
    zT_61 = zT_77;
    zT_78 = zF_84ADA681_semanticAnalyzerIni(zT_47, zT_48, zT_49, zT_50, zT_51, zT_52, zT_53, zT_54, zT_55, zT_56, zT_57, zT_58, zT_59, zT_60, zT_61);
    sa = zT_78;
    sa = zT_78;
    sa = zT_78;
    zT_80 = 0;
    zT_81 = (unsigned int)zT_80;
    di = zT_81;
    di = zT_81;
    di = zT_81;
    goto z_bb_11;
    z_bb_11:
    zT_83 = decls.len;
    zT_84 = di < zT_83;
    if (zT_84) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_88 = ct->store;
    zT_86 = zT_88;
    zT_89 = decls.ptr;
    zT_90 = zT_89[di];
    zT_87 = zT_90;
    zT_91 = zF_FCDD1D35_astStoreNodeAt(zT_86, zT_87);
    decl = zT_91;
    decl = zT_91;
    decl = zT_91;
    zT_92 = decl.kind;
    zT_95 = zT_8143F551_AstKind_var_decl;
    zT_96 = zT_92 != zT_95;
    if (zT_96) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    zT_253 = 1;
    zT_254 = di + zT_253;
    di = zT_254;
    di = zT_254;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    zT_97 = decl.child_0;
    zT_98 = 0;
    zT_99 = zT_97 != zT_98;
    if (zT_99) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_101 = ct;
    zT_104 = mods.ptr;
    zT_105 = zT_104[mi];
    zT_106 = zT_105.id;
    zT_102 = zT_106;
    zT_107 = decl.child_0;
    zT_103 = zT_107;
    zT_108 = zF_EE3AA0D0_resolveTypeExpr(zT_101, zT_102, zT_103);
    rtype = zT_108;
    rtype = zT_108;
    rtype = zT_108;
    zT_109 = 18;
    zT_110 = rtype != zT_109;
    if (zT_110) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_122 = decl.child_1;
    zT_123 = 0;
    zT_124 = zT_122 != zT_123;
    if (zT_124) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_114 = ct->resolved_types;
    zT_111 = zT_114;
    zT_115 = decl.child_0;
    zT_112 = zT_115;
    zT_113 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_111, zT_112, zT_113);
    zT_119 = ct->resolved_types;
    zT_116 = zT_119;
    zT_120 = decls.ptr;
    zT_121 = zT_120[di];
    zT_117 = zT_121;
    zT_118 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_116, zT_117, zT_118);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_128 = ct->store;
    zT_126 = zT_128;
    zT_129 = decl.child_1;
    zT_127 = zT_129;
    zT_130 = zF_FCDD1D35_astStoreNodeAt(zT_126, zT_127);
    init = zT_130;
    init = zT_130;
    init = zT_130;
    zT_131 = init.kind;
    zT_134 = zT_8143F551_AstKind_struct_decl;
    zT_135 = zT_131 != zT_134;
    if (zT_135) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_14;
    z_bb_23:
    zT_137 = init.kind;
    zT_140 = zT_8143F551_AstKind_union_decl;
    zT_141 = zT_137 != zT_140;
    zT_136 = zT_141;
    goto z_bb_25;
    z_bb_24:
    zT_136 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_136) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_145 = &sa;
    zT_143 = zT_145;
    zT_146 = decls.ptr;
    zT_147 = zT_146[di];
    zT_144 = zT_147;
    zT_148 = zF_CC4377FA_semanticAnalyzerRes(zT_143, zT_144);
    init_type = zT_148;
    init_type = zT_148;
    init_type = zT_148;
    zT_149 = init.kind;
    zT_152 = zT_8143F551_AstKind_ident_expr;
    zT_153 = zT_149 == zT_152;
    if (zT_153) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    zT_154 = 18;
    zT_155 = init_type != zT_154;
    if (zT_155) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_178 = ct->resolved_types;
    zT_176 = zT_178;
    zT_179 = decls.ptr;
    zT_180 = zT_179[di];
    zT_177 = zT_180;
    zT_181 = zF_999DCF51_resolvedTypeTableGe(zT_176, zT_177);
    vd_existing = zT_181;
    vd_existing = zT_181;
    vd_existing = zT_181;
    zT_182 = 1;
    zT_183 = init_type != zT_182;
    if (zT_183) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    zT_157 = mods.ptr;
    zT_158 = zT_157[mi];
    zT_159 = zT_158.id;
    zT_160 = (zT_79FAE712_u64)zT_159;
    zT_161 = 4294967296ULL;
    zT_162 = zT_160 * zT_161;
    zT_165 = ct->store;
    zT_163 = zT_165;
    zT_166 = decls.ptr;
    zT_167 = zT_166[di];
    zT_164 = zT_167;
    zT_168 = zF_8BA26B9E_astStoreNodePayload(zT_163, zT_164);
    zT_169 = (zT_79FAE712_u64)zT_168;
    zT_170 = zT_162 + zT_169;
    ck = zT_170;
    ck = zT_170;
    ck = zT_170;
    zT_174 = ct->typereg;
    zT_171 = zT_174;
    zT_172 = ck;
    zT_173 = init_type;
    zF_5E95558D_nameCachePut(zT_171, zT_172, zT_173);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_185 = 18;
    zT_186 = init_type != zT_185;
    zT_184 = zT_186;
    goto z_bb_34;
    z_bb_33:
    zT_184 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_184) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_188 = 20;
    zT_189 = init_type != zT_188;
    zT_187 = zT_189;
    goto z_bb_37;
    z_bb_36:
    zT_187 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_187) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_191 = vd_existing.has_value;
    zT_192 = !zT_191;
    zT_190 = zT_192;
    goto z_bb_40;
    z_bb_39:
    zT_190 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_190) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_196 = ct->resolved_types;
    zT_193 = zT_196;
    zT_197 = decls.ptr;
    zT_198 = zT_197[di];
    zT_194 = zT_198;
    zT_195 = init_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_193, zT_194, zT_195);
    goto z_bb_42;
    z_bb_42:
    zT_199 = 19;
    zT_200 = init_type == zT_199;
    if (zT_200) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_202 = decl.child_0;
    zT_203 = 0;
    zT_204 = zT_202 != zT_203;
    zT_201 = zT_204;
    goto z_bb_45;
    z_bb_44:
    zT_201 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_201) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_208 = ct->resolved_types;
    zT_206 = zT_208;
    zT_209 = decl.child_0;
    zT_207 = zT_209;
    zT_210 = zF_999DCF51_resolvedTypeTableGe(zT_206, zT_207);
    mdt2 = zT_210;
    mdt2 = zT_210;
    mdt2 = zT_210;
    zT_211 = mdt2.has_value;
    if (zT_211) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    zT_220 = 0;
    zT_221 = init_type != zT_220;
    if (zT_221) goto z_bb_52; else goto z_bb_53;
    z_bb_48:
    mt2 = mdt2.value;
    zT_213 = 18;
    zT_214 = mt2 != zT_213;
    if (zT_214) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_218 = ct->resolved_types;
    zT_215 = zT_218;
    zT_219 = decl.child_1;
    zT_216 = zT_219;
    zT_217 = mt2;
    zF_19B4A07D_resolvedTypeTableSe(zT_215, zT_216, zT_217);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_49;
    z_bb_52:
    zT_223 = 1;
    zT_224 = init_type != zT_223;
    zT_222 = zT_224;
    goto z_bb_54;
    z_bb_53:
    zT_222 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_222) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_226 = 18;
    zT_227 = init_type != zT_226;
    zT_225 = zT_227;
    goto z_bb_57;
    z_bb_56:
    zT_225 = 0;
    goto z_bb_57;
    z_bb_57:
    if (zT_225) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_229 = 20;
    zT_230 = init_type != zT_229;
    zT_228 = zT_230;
    goto z_bb_60;
    z_bb_59:
    zT_228 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_228) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_234 = ct->store;
    zT_232 = zT_234;
    zT_235 = decls.ptr;
    zT_236 = zT_235[di];
    zT_233 = zT_236;
    zT_237 = zF_8BA26B9E_astStoreNodePayload(zT_232, zT_233);
    name_id = zT_237;
    name_id = zT_237;
    name_id = zT_237;
    zT_242 = ct->symbol_reg;
    zT_239 = zT_242;
    zT_243 = mods.ptr;
    zT_244 = zT_243[mi];
    zT_245 = zT_244.id;
    zT_240 = zT_245;
    zT_241 = name_id;
    zT_246 = zF_A398987E_symbolRegistryQuali(zT_239, zT_240, zT_241);
    sym = zT_246;
    sym = zT_246;
    sym = zT_246;
    zT_247 = sym.has_value;
    if (zT_247) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_27;
    z_bb_63:
    s = sym.value;
    zT_249 = s->type_id;
    zT_250 = 0;
    zT_251 = zT_249 == zT_250;
    if (zT_251) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    s->type_id = init_type;
    zT_252 = 1;
    changed = zT_252;
    changed = zT_252;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    goto z_bb_3;
    z_bb_68:
    goto z_bb_4;
}

/* resolveStmtTypes */
void zF_783226DA_resolveStmtTypes(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth) {
    unsigned int zT_4;
    int zT_5;
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_8143F551_AstKind zT_14;
    int zT_15;
    unsigned int zT_16;
    int zT_17;
    int zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    unsigned int zT_25;
    int zT_26;
    zT_8EED1867_ResolvedTypeTable* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8EED1867_ResolvedTypeTable* zT_30;
    unsigned int zT_31;
    zT_8EED1867_ResolvedTypeTable* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_8EED1867_ResolvedTypeTable* zT_35;
    zT_8143F551_AstKind zT_36;
    zT_8143F551_AstKind zT_39;
    int zT_40;
    int zT_41;
    zT_8143F551_AstKind zT_42;
    zT_8143F551_AstKind zT_45;
    int zT_46;
    int zT_47;
    zT_8143F551_AstKind zT_48;
    zT_8143F551_AstKind zT_51;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    int zT_55;
    zT_6DCFC8DB_FrontResCtx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61 = 0;
    unsigned int zT_62;
    int zT_63;
    zT_8EED1867_ResolvedTypeTable* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_8EED1867_ResolvedTypeTable* zT_67;
    unsigned int zT_68;
    zT_8143F551_AstKind zT_69;
    zT_8143F551_AstKind zT_72;
    int zT_73;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    zT_6B0A7D14_AstStore* zT_77;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_78 = {0};
    int zT_80;
    unsigned int zT_81;
    unsigned int zT_83;
    int zT_84;
    zT_6DCFC8DB_FrontResCtx* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_8143F551_AstKind zT_98;
    zT_8143F551_AstKind zT_101;
    int zT_102;
    unsigned int zT_103;
    int zT_104;
    int zT_105;
    zT_6DCFC8DB_FrontResCtx* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    int zT_112;
    int zT_113;
    zT_6DCFC8DB_FrontResCtx* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_22A7C88B_AstNode node;
    unsigned int rtype;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    unsigned int cd;
    zT_4 = 16;
    zT_5 = depth > zT_4;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = ct->store;
    zT_7 = zT_9;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    node = zT_10;
    node = zT_10;
    zT_11 = node.kind;
    zT_14 = zT_8143F551_AstKind_var_decl;
    zT_15 = zT_11 == zT_14;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = node.child_0;
    zT_17 = 0;
    zT_18 = zT_16 != (unsigned int)zT_17;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_36 = node.kind;
    zT_39 = zT_8143F551_AstKind_array_init;
    zT_40 = zT_36 == zT_39;
    if (zT_40) goto z_bb_10; else goto z_bb_9;
    z_bb_5:
    zT_20 = ct;
    zT_21 = module_id;
    zT_23 = node.child_0;
    zT_22 = zT_23;
    zT_24 = zF_EE3AA0D0_resolveTypeExpr(zT_20, zT_21, zT_22);
    rtype = zT_24;
    rtype = zT_24;
    rtype = zT_24;
    zT_25 = 18;
    zT_26 = rtype != zT_25;
    if (zT_26) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_30 = ct->resolved_types;
    zT_27 = zT_30;
    zT_31 = node.child_0;
    zT_28 = zT_31;
    zT_29 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_27, zT_28, zT_29);
    zT_35 = ct->resolved_types;
    zT_32 = zT_35;
    zT_33 = node_idx;
    zT_34 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_32, zT_33, zT_34);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_42 = node.kind;
    zT_45 = zT_8143F551_AstKind_struct_init;
    zT_46 = zT_42 == zT_45;
    zT_41 = zT_46;
    goto z_bb_11;
    z_bb_10:
    zT_41 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_41) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_48 = node.kind;
    zT_51 = zT_8143F551_AstKind_tuple_literal;
    zT_52 = zT_48 == zT_51;
    zT_47 = zT_52;
    goto z_bb_14;
    z_bb_13:
    zT_47 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_47) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_53 = node.child_0;
    zT_54 = 0;
    zT_55 = zT_53 != (unsigned int)zT_54;
    if (zT_55) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = node.kind;
    zT_72 = zT_8143F551_AstKind_block;
    zT_73 = zT_69 == zT_72;
    if (zT_73) goto z_bb_21; else goto z_bb_22;
    z_bb_17:
    zT_57 = ct;
    zT_58 = module_id;
    zT_60 = node.child_0;
    zT_59 = zT_60;
    zT_61 = zF_EE3AA0D0_resolveTypeExpr(zT_57, zT_58, zT_59);
    rtype = zT_61;
    rtype = zT_61;
    rtype = zT_61;
    zT_62 = 18;
    zT_63 = rtype != zT_62;
    if (zT_63) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_67 = ct->resolved_types;
    zT_64 = zT_67;
    zT_68 = node.child_0;
    zT_65 = zT_68;
    zT_66 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_64, zT_65, zT_66);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_77 = ct->store;
    zT_75 = zT_77;
    zT_76 = node_idx;
    zT_78 = zF_850FDF81_astStoreNodeExtraCh(zT_75, zT_76);
    decls = zT_78;
    decls = zT_78;
    decls = zT_78;
    zT_80 = 0;
    zT_81 = (unsigned int)zT_80;
    di = zT_81;
    di = zT_81;
    di = zT_81;
    goto z_bb_23;
    z_bb_22:
    zT_96 = 1;
    zT_97 = depth + zT_96;
    cd = zT_97;
    cd = zT_97;
    cd = zT_97;
    zT_98 = node.kind;
    zT_101 = zT_8143F551_AstKind_builtin_call;
    zT_102 = zT_98 != zT_101;
    if (zT_102) goto z_bb_27; else goto z_bb_28;
    z_bb_23:
    zT_83 = decls.len;
    zT_84 = di < zT_83;
    if (zT_84) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_85 = ct;
    zT_86 = module_id;
    zT_89 = decls.ptr;
    zT_90 = zT_89[di];
    zT_87 = zT_90;
    zT_91 = 1;
    zT_92 = depth + zT_91;
    zT_88 = zT_92;
    zF_783226DA_resolveStmtTypes(zT_85, zT_86, zT_87, zT_88);
    goto z_bb_26;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_93 = 1;
    zT_94 = di + zT_93;
    di = zT_94;
    di = zT_94;
    goto z_bb_23;
    z_bb_27:
    zT_103 = node.child_0;
    zT_104 = 0;
    zT_105 = zT_103 != (unsigned int)zT_104;
    if (zT_105) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    return;
    z_bb_29:
    zT_106 = ct;
    zT_107 = module_id;
    zT_110 = node.child_0;
    zT_108 = zT_110;
    zT_109 = cd;
    zF_783226DA_resolveStmtTypes(zT_106, zT_107, zT_108, zT_109);
    goto z_bb_30;
    z_bb_30:
    zT_111 = node.child_1;
    zT_112 = 0;
    zT_113 = zT_111 != (unsigned int)zT_112;
    if (zT_113) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_114 = ct;
    zT_115 = module_id;
    zT_118 = node.child_1;
    zT_116 = zT_118;
    zT_117 = cd;
    zF_783226DA_resolveStmtTypes(zT_114, zT_115, zT_116, zT_117);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_28;
}

/* __module_init */
void zF_780653D2___module_init_19(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_F85C5DED_DiagnosticCollector zT_2 = {0};
    zT_8143F551_AstKind zT_3 = 0;
    zT_6B0A7D14_AstStore zT_4 = {0};
    zT_072B53A6_ModuleRegistry zT_5 = {0};
    zT_3D7259E2_SymbolRegistry zT_6 = {0};
    zT_338B7C76_TypeRegistry zT_7 = {0};
    zT_8EED1867_ResolvedTypeTable zT_8 = {0};
    zT_66E7D2EF_CoercionTable zT_9 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_F85C5DED_DiagnosticCollector = zT_2;
    zG_8143F551_AstKind = zT_3;
    zG_6B0A7D14_AstStore = zT_4;
    zG_072B53A6_ModuleRegistry = zT_5;
    zG_3D7259E2_SymbolRegistry = zT_6;
    zG_338B7C76_TypeRegistry = zT_7;
    zG_8EED1867_ResolvedTypeTable = zT_8;
    zG_66E7D2EF_CoercionTable = zT_9;
    return;
}

/* EOF */
