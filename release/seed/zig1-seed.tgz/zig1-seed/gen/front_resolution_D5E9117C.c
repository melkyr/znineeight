#include "front_resolution_D5E9117C.h"
/* resolveTypeExpr */
unsigned int zF_EE3AA0D0_resolveTypeExpr(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, zT_02B97B5A_Opt_399 scope, unsigned int source_file_id) {
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    zT_F85C5DED_DiagnosticCollector* zT_11;
    zT_6F34EEB2_Opt_229 zT_12;
    zT_04CE5406_Opt_401 zT_13 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_14;
    unsigned int zT_15;
    unsigned int zT_19 = 0;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_7 = ct->store;
    zT_6.store = zT_7;
    zT_8 = ct->typereg;
    zT_6.typereg = zT_8;
    zT_9 = ct->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = ct->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = module_id;
    zT_6.source_file_id = source_file_id;
    zT_11 = ct->diag;
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    zT_6.diag = zT_12;
    zT_6.local_consts = scope;
    zT_13.has_value = 0;
    zT_6.local_types = zT_13;
    env = zT_6;
    zT_14 = &env;
    zT_15 = node_idx;
    zT_19 = zF_F2107C15_resolveTypeExprFull(zT_14, zT_15, (unsigned int)(0));
    return zT_19;
}

/* countUntypedGlobals */
unsigned int zF_5DF8AD5B_countUntypedGlobals(zT_6DCFC8DB_FrontResCtx* ct) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_7;
    unsigned int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_11;
    zT_060CD1EB_SymbolTable* zT_12;
    zT_060CD1EB_SymbolTable zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_3A105EF1_Symbol* zT_20;
    zT_3A105EF1_Symbol zT_21;
    unsigned int zT_22;
    zT_3C598AEF_SymbolKind zT_25;
    unsigned char zT_29;
    zT_3C598AEF_SymbolKind zT_30;
    int zT_34;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_42;
    unsigned int cnt;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol sym;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    cnt = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    ti = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = ct->symbol_reg;
    zT_8 = zT_7->tables_len;
    if ((unsigned char)(ti < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = ct->symbol_reg;
    zT_12 = zT_11->tables_items;
    zT_13 = zT_12[ti];
    table = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    si = zT_16;
    goto z_bb_5;
    z_bb_3:
    return cnt;
    z_bb_4:
    zT_40 = 1;
    zT_42 = ti + (unsigned int)((unsigned int)zT_40);
    ti = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_17 = table.len;
    if ((unsigned char)(si < zT_17)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = table.items;
    zT_21 = zT_20[si];
    sym = zT_21;
    zT_22 = sym.type_id;
    if ((unsigned char)(zT_22 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = 1;
    zT_39 = si + (unsigned int)((unsigned int)zT_37);
    si = zT_39;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_25 = sym.kind;
    if ((unsigned char)(zT_25 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_30 = sym.kind;
    zT_29 = zT_30 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_34 = 1;
    zT_36 = cnt + (unsigned int)((unsigned int)zT_34);
    cnt = zT_36;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
}

/* frontResolveModuleInits */
void zF_8A0E7747_frontResolveModuleI(zT_6DCFC8DB_FrontResCtx* ct) {
    zT_3E40CD83_Sand* zT_1;
    zT_6DCFC8DB_FrontResCtx* zT_4;
    unsigned int zT_5 = 0;
    unsigned int zT_7;
    int zT_9;
    unsigned int zT_10;
    unsigned char zT_13;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_3E40CD83_Sand* zT_24;
    zT_6E8D187B_ModuleEntry* zT_27;
    zT_6E8D187B_ModuleEntry zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    unsigned int zT_41 = 0;
    zT_6E8D187B_ModuleEntry* zT_43;
    zT_6E8D187B_ModuleEntry zT_44;
    unsigned int zT_45;
    zT_3E40CD83_Sand* zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_48;
    zT_F85C5DED_DiagnosticCollector* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_3D7259E2_SymbolRegistry* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_66E7D2EF_CoercionTable* zT_55;
    zT_21D3708C_U32ToU32Map* zT_56;
    zT_21D3708C_U32ToU32Map* zT_57;
    zT_D3EB6303_StringInterner* zT_58;
    zT_21D3708C_U32ToU32Map* zT_59;
    zT_21D3708C_U32ToU32Map* zT_60;
    zT_072B53A6_ModuleRegistry* zT_61;
    zT_A4CE86B7_U64ToU32Map* zT_62;
    zT_6E8D187B_ModuleEntry* zT_69;
    zT_6E8D187B_ModuleEntry zT_70;
    zT_38C12417_SemanticAnalyzer zT_80 = {0};
    int zT_82;
    unsigned int zT_83;
    zT_6B0A7D14_AstStore* zT_87;
    unsigned int zT_88;
    unsigned int zT_92 = 0;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_97 = {0};
    zT_8143F551_AstKind zT_98;
    unsigned int zT_102;
    zT_6DCFC8DB_FrontResCtx* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_02B97B5A_Opt_399 zT_109;
    unsigned int zT_110;
    zT_6E8D187B_ModuleEntry* zT_111;
    zT_6E8D187B_ModuleEntry zT_112;
    zT_02B97B5A_Opt_399 zT_115 = {0};
    unsigned int zT_116 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_8EED1867_ResolvedTypeTable* zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    zT_22A7C88B_AstNode zT_136 = {0};
    zT_8143F551_AstKind zT_137;
    unsigned char zT_141;
    zT_8143F551_AstKind zT_142;
    zT_38C12417_SemanticAnalyzer* zT_147;
    unsigned int zT_148;
    unsigned int zT_150 = 0;
    zT_8143F551_AstKind zT_151;
    zT_6E8D187B_ModuleEntry* zT_158;
    zT_6E8D187B_ModuleEntry zT_159;
    unsigned int zT_160;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    unsigned int zT_167 = 0;
    zT_79FAE712_u64 zT_169;
    zT_338B7C76_TypeRegistry* zT_170;
    zT_79FAE712_u64 zT_171;
    unsigned int zT_172;
    zT_6B0A7D14_AstStore* zT_175;
    unsigned int zT_176;
    unsigned int zT_179 = 0;
    zT_3D7259E2_SymbolRegistry* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_6E8D187B_ModuleEntry* zT_185;
    zT_6E8D187B_ModuleEntry zT_186;
    zT_567B632C_Opt_872 zT_188 = {0};
    unsigned char zT_189;
    zT_3C598AEF_SymbolKind zT_191;
    zT_3D7259E2_SymbolRegistry* zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    zT_6E8D187B_ModuleEntry* zT_200;
    zT_6E8D187B_ModuleEntry zT_201;
    zT_6B0A7D14_AstStore* zT_203;
    unsigned int zT_204;
    unsigned int zT_206 = 0;
    zT_567B632C_Opt_872 zT_207 = {0};
    unsigned char zT_208;
    zT_3C598AEF_SymbolKind zT_210;
    unsigned char zT_216;
    zT_8EED1867_ResolvedTypeTable* zT_218;
    unsigned int zT_219;
    zT_BAEE192E_Opt_10 zT_221 = {0};
    unsigned char zT_224;
    unsigned char zT_227;
    unsigned char zT_230;
    unsigned char zT_231;
    zT_8EED1867_ResolvedTypeTable* zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned char zT_239;
    unsigned int zT_240;
    zT_8EED1867_ResolvedTypeTable* zT_244;
    unsigned int zT_245;
    zT_BAEE192E_Opt_10 zT_248 = {0};
    unsigned char zT_249;
    zT_8EED1867_ResolvedTypeTable* zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned char zT_260;
    unsigned char zT_263;
    unsigned char zT_266;
    zT_6B0A7D14_AstStore* zT_270;
    unsigned int zT_271;
    unsigned int zT_273 = 0;
    zT_3D7259E2_SymbolRegistry* zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    zT_6E8D187B_ModuleEntry* zT_279;
    zT_6E8D187B_ModuleEntry zT_280;
    zT_567B632C_Opt_872 zT_282 = {0};
    unsigned char zT_283;
    unsigned int zT_285;
    unsigned char zT_288;
    int zT_289;
    unsigned int zT_291;
    int zT_292;
    unsigned int zT_294;
    int zT_297;
    unsigned int zT_299;
    zT_3E40CD83_Sand* zT_300;
    unsigned int bound;
    unsigned int iter;
    unsigned char changed;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    unsigned int decls_n;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int rtype;
    zT_22A7C88B_AstNode init;
    unsigned int init_type;
    zT_BAEE192E_Opt_10 vd_existing;
    zT_79FAE712_u64 ck;
    unsigned int ref_name;
    zT_567B632C_Opt_872 ref_sym;
    zT_3A105EF1_Symbol* rs;
    zT_567B632C_Opt_872 own_sym;
    zT_3A105EF1_Symbol* os;
    zT_BAEE192E_Opt_10 mdt2;
    unsigned int mt2;
    unsigned int name_id;
    zT_567B632C_Opt_872 sym;
    zT_3A105EF1_Symbol* s;
    zT_1 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_1);
    zT_4 = ct;
    zT_5 = zF_5DF8AD5B_countUntypedGlobals(zT_4);
    zT_7 = zT_5 + (unsigned int)(1);
    bound = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    iter = zT_10;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(iter < bound)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = 0;
    changed = zT_13;
    zT_15 = ct->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_5;
    z_bb_3:
    zT_300 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_300);
    return;
    z_bb_4:
    zT_297 = 1;
    zT_299 = iter + (unsigned int)((unsigned int)zT_297);
    iter = zT_299;
    goto z_bb_1;
    z_bb_5:
    zT_22 = mods.len;
    if ((unsigned char)(mi < zT_22)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_24 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_24);
    zT_27 = mods.ptr;
    zT_28 = zT_27[mi];
    zT_29 = zT_28.ast_root;
    ast_root = zT_29;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    if ((unsigned char)(changed == (unsigned char)(0))) goto z_bb_75; else goto z_bb_76;
    z_bb_8:
    zT_292 = 1;
    zT_294 = mi + (unsigned int)((unsigned int)zT_292);
    mi = zT_294;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_33 = ct->store;
    zT_34 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    zT_38 = ct->store;
    zT_39 = ast_root;
    zT_41 = zF_152E19CB_astStoreNodeExtraCh(zT_38, zT_39);
    decls_n = zT_41;
    zT_43 = mods.ptr;
    zT_44 = zT_43[mi];
    zT_45 = zT_44.source_file_id;
    src_fid = zT_45;
    zT_47 = ct->scratch;
    zT_48 = ct->resolved_types;
    zT_49 = ct->diag;
    zT_50 = ct->typereg;
    zT_51 = ct->symbol_reg;
    zT_52 = ct->store;
    zT_69 = mods.ptr;
    zT_70 = zT_69[mi];
    zT_53 = zT_70.id;
    zT_54 = src_fid;
    zT_55 = ct->coercion_table;
    zT_56 = ct->enum_value_table;
    zT_57 = ct->error_code_registry;
    zT_58 = ct->interner;
    zT_59 = ct->call_arg_types;
    zT_60 = ct->call_param_map;
    zT_61 = ct->module_reg;
    zT_62 = ct->suspending_fns;
    zT_80 = zF_84ADA681_semanticAnalyzerIni(zT_47, zT_48, zT_49, zT_50, zT_51, zT_52, zT_53, zT_54, zT_55, zT_56, zT_57, zT_58, zT_59, zT_60, zT_61, zT_62);
    sa = zT_80;
    zT_82 = 0;
    zT_83 = (unsigned int)zT_82;
    di = zT_83;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_87 = ct->store;
    zT_88 = ast_root;
    zT_92 = zF_B10B1BC1_astStoreNodeExtraCh(zT_87, zT_88, (unsigned int)((unsigned int)di));
    decl_idx = zT_92;
    zT_94 = ct->store;
    zT_95 = decl_idx;
    zT_97 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    decl = zT_97;
    zT_98 = decl.kind;
    if ((unsigned char)(zT_98 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    zT_289 = 1;
    zT_291 = di + (unsigned int)((unsigned int)zT_289);
    di = zT_291;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    zT_102 = decl.child_0;
    if ((unsigned char)(zT_102 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_106 = ct;
    zT_111 = mods.ptr;
    zT_112 = zT_111[mi];
    zT_107 = zT_112.id;
    zT_108 = decl.child_0;
    zT_115.has_value = 0;
    zT_109 = zT_115;
    zT_110 = src_fid;
    zT_116 = zF_EE3AA0D0_resolveTypeExpr(zT_106, zT_107, zT_108, zT_109, zT_110);
    rtype = zT_116;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_128 = decl.child_1;
    if ((unsigned char)(zT_128 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_119 = ct->resolved_types;
    zT_120 = decl.child_0;
    zT_121 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_119, zT_120, zT_121);
    zT_124 = ct->resolved_types;
    zT_125 = decl_idx;
    zT_126 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_124, zT_125, zT_126);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_132 = ct->store;
    zT_133 = decl.child_1;
    zT_136 = zF_FCDD1D35_astStoreNodeAt(zT_132, zT_133);
    init = zT_136;
    zT_137 = init.kind;
    if ((unsigned char)(zT_137 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_14;
    z_bb_23:
    zT_142 = init.kind;
    zT_141 = zT_142 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_25;
    z_bb_24:
    zT_141 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_141) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_147 = &sa;
    zT_148 = decl_idx;
    zT_150 = zF_CC4377FA_semanticAnalyzerRes(zT_147, zT_148);
    init_type = zT_150;
    zT_151 = init.kind;
    if ((unsigned char)(zT_151 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    if ((unsigned char)(init_type != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_218 = ct->resolved_types;
    zT_219 = decl_idx;
    zT_221 = zF_999DCF51_resolvedTypeTableGe(zT_218, zT_219);
    vd_existing = zT_221;
    if ((unsigned char)(init_type != (unsigned int)(1))) goto z_bb_40; else goto z_bb_41;
    z_bb_30:
    zT_158 = mods.ptr;
    zT_159 = zT_158[mi];
    zT_160 = zT_159.id;
    zT_164 = ct->store;
    zT_165 = decl_idx;
    zT_167 = zF_8BA26B9E_astStoreNodePayload(zT_164, zT_165);
    zT_169 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_160) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_167);
    ck = zT_169;
    zT_170 = ct->typereg;
    zT_171 = ck;
    zT_172 = init_type;
    zF_5E95558D_nameCachePut(zT_170, zT_171, zT_172);
    goto z_bb_31;
    z_bb_31:
    zT_175 = ct->store;
    zT_176 = decl.child_1;
    zT_179 = zF_53458827_astStoreIdentifier(zT_175, zT_176);
    ref_name = zT_179;
    zT_181 = ct->symbol_reg;
    zT_185 = mods.ptr;
    zT_186 = zT_185[mi];
    zT_182 = zT_186.id;
    zT_183 = ref_name;
    zT_188 = zF_A398987E_symbolRegistryQuali(zT_181, zT_182, zT_183);
    ref_sym = zT_188;
    zT_189 = ref_sym.has_value;
    if (zT_189) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    rs = ref_sym.value;
    zT_191 = rs->kind;
    if ((unsigned char)(zT_191 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    zT_196 = ct->symbol_reg;
    zT_200 = mods.ptr;
    zT_201 = zT_200[mi];
    zT_197 = zT_201.id;
    zT_203 = ct->store;
    zT_204 = decl_idx;
    zT_206 = zF_8BA26B9E_astStoreNodePayload(zT_203, zT_204);
    zT_198 = zT_206;
    zT_207 = zF_A398987E_symbolRegistryQuali(zT_196, zT_197, zT_198);
    own_sym = zT_207;
    zT_208 = own_sym.has_value;
    if (zT_208) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    os = own_sym.value;
    zT_210 = os->kind;
    if ((unsigned char)(zT_210 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    os->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_216 = 1;
    changed = zT_216;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    zT_224 = init_type != (unsigned int)(18);
    goto z_bb_42;
    z_bb_41:
    zT_224 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_224) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_227 = init_type != (unsigned int)(20);
    goto z_bb_45;
    z_bb_44:
    zT_227 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_227) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_231 = vd_existing.has_value;
    zT_230 = !zT_231;
    goto z_bb_48;
    z_bb_47:
    zT_230 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_230) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_233 = ct->resolved_types;
    zT_234 = decl_idx;
    zT_235 = init_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_233, zT_234, zT_235);
    goto z_bb_50;
    z_bb_50:
    if ((unsigned char)(init_type == (unsigned int)(19))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_240 = decl.child_0;
    zT_239 = zT_240 != (unsigned int)(0);
    goto z_bb_53;
    z_bb_52:
    zT_239 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_239) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_244 = ct->resolved_types;
    zT_245 = decl.child_0;
    zT_248 = zF_999DCF51_resolvedTypeTableGe(zT_244, zT_245);
    mdt2 = zT_248;
    zT_249 = mdt2.has_value;
    if (zT_249) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if ((unsigned char)(init_type != (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_56:
    mt2 = mdt2.value;
    if ((unsigned char)(mt2 != (unsigned int)(18))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    goto z_bb_55;
    z_bb_58:
    zT_253 = ct->resolved_types;
    zT_254 = decl.child_1;
    zT_255 = mt2;
    zF_19B4A07D_resolvedTypeTableSe(zT_253, zT_254, zT_255);
    goto z_bb_59;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    zT_260 = init_type != (unsigned int)(1);
    goto z_bb_62;
    z_bb_61:
    zT_260 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_260) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_263 = init_type != (unsigned int)(18);
    goto z_bb_65;
    z_bb_64:
    zT_263 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_263) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_266 = init_type != (unsigned int)(20);
    goto z_bb_68;
    z_bb_67:
    zT_266 = 0;
    goto z_bb_68;
    z_bb_68:
    if (zT_266) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_270 = ct->store;
    zT_271 = decl_idx;
    zT_273 = zF_8BA26B9E_astStoreNodePayload(zT_270, zT_271);
    name_id = zT_273;
    zT_275 = ct->symbol_reg;
    zT_279 = mods.ptr;
    zT_280 = zT_279[mi];
    zT_276 = zT_280.id;
    zT_277 = name_id;
    zT_282 = zF_A398987E_symbolRegistryQuali(zT_275, zT_276, zT_277);
    sym = zT_282;
    zT_283 = sym.has_value;
    if (zT_283) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    goto z_bb_27;
    z_bb_71:
    s = sym.value;
    zT_285 = s->type_id;
    if ((unsigned char)(zT_285 == (unsigned int)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    goto z_bb_70;
    z_bb_73:
    s->type_id = init_type;
    zT_288 = 1;
    changed = zT_288;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_72;
    z_bb_75:
    goto z_bb_3;
    z_bb_76:
    goto z_bb_4;
}

/* resolveStmtTypes */
void zF_783226DA_resolveStmtTypes(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth, unsigned int source_file_id) {
    zT_3E40CD83_Sand* zT_6;
    zT_E2DF2801_LocalConstScope zT_8 = {0};
    zT_6DCFC8DB_FrontResCtx* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_E2DF2801_LocalConstScope* zT_14;
    zT_E2DF2801_LocalConstScope scope;
    zT_6 = ct->scratch;
    zT_8 = zF_F5EBC2FF_localConstScopeInit(zT_6);
    scope = zT_8;
    zT_9 = ct;
    zT_10 = module_id;
    zT_11 = node_idx;
    zT_12 = depth;
    zT_13 = source_file_id;
    zT_14 = &scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_9, zT_10, zT_11, zT_12, zT_13, zT_14);
    return;
}

/* resolveStmtTypesRec */
void zF_B1CC762C_resolveStmtTypesRec(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth, unsigned int source_file_id, zT_E2DF2801_LocalConstScope* scope) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    zT_8143F551_AstKind zT_13;
    unsigned int zT_17;
    int zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_02B97B5A_Opt_399 zT_24;
    unsigned int zT_25;
    zT_02B97B5A_Opt_399 zT_27;
    unsigned int zT_28 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_8EED1867_ResolvedTypeTable* zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned char zT_45;
    unsigned int zT_46;
    int zT_47;
    zT_E2DF2801_LocalConstScope* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_55 = 0;
    zT_8143F551_AstKind zT_56;
    unsigned char zT_60;
    zT_8143F551_AstKind zT_61;
    unsigned char zT_65;
    zT_8143F551_AstKind zT_66;
    unsigned int zT_70;
    int zT_71;
    zT_6DCFC8DB_FrontResCtx* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_02B97B5A_Opt_399 zT_77;
    unsigned int zT_78;
    zT_02B97B5A_Opt_399 zT_80;
    unsigned int zT_81 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_8143F551_AstKind zT_89;
    unsigned int zT_94;
    zT_6B0A7D14_AstStore* zT_96;
    unsigned int zT_97;
    unsigned int zT_99 = 0;
    int zT_101;
    unsigned int zT_102;
    zT_6DCFC8DB_FrontResCtx* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_109;
    zT_E2DF2801_LocalConstScope* zT_110;
    zT_6B0A7D14_AstStore* zT_111;
    unsigned int zT_112;
    unsigned int zT_116 = 0;
    int zT_119;
    unsigned int zT_121;
    unsigned int zT_124;
    zT_8143F551_AstKind zT_125;
    unsigned int zT_129;
    int zT_130;
    zT_6DCFC8DB_FrontResCtx* zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    zT_E2DF2801_LocalConstScope* zT_137;
    unsigned int zT_139;
    int zT_140;
    zT_6DCFC8DB_FrontResCtx* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_E2DF2801_LocalConstScope* zT_147;
    zT_22A7C88B_AstNode node;
    unsigned int rtype;
    unsigned int scope_base;
    unsigned int decls_n;
    unsigned int di;
    unsigned int cd;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = ct->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_13 = node.kind;
    if ((unsigned char)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = node.child_0;
    zT_18 = 0;
    if ((unsigned char)(zT_17 != (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_56 = node.kind;
    if ((unsigned char)(zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_15; else goto z_bb_14;
    z_bb_5:
    zT_21 = ct;
    zT_22 = module_id;
    zT_23 = node.child_0;
    zT_27.has_value = 1;
    zT_27.value = scope;
    zT_24 = zT_27;
    zT_25 = source_file_id;
    zT_28 = zF_EE3AA0D0_resolveTypeExpr(zT_21, zT_22, zT_23, zT_24, zT_25);
    rtype = zT_28;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_40 = node.flags;
    if ((unsigned char)((unsigned char)(zT_40 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_31 = ct->resolved_types;
    zT_32 = node.child_0;
    zT_33 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_31, zT_32, zT_33);
    zT_36 = ct->resolved_types;
    zT_37 = node_idx;
    zT_38 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_36, zT_37, zT_38);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_46 = node.child_1;
    zT_47 = 0;
    zT_45 = zT_46 != (unsigned int)zT_47;
    goto z_bb_11;
    z_bb_10:
    zT_45 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_45) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_49 = scope;
    zT_52 = ct->store;
    zT_53 = node_idx;
    zT_55 = zF_8BA26B9E_astStoreNodePayload(zT_52, zT_53);
    zT_50 = zT_55;
    zT_51 = node_idx;
    zF_DA915531_localConstScopePush(zT_49, zT_50, zT_51);
    goto z_bb_13;
    z_bb_13:
    goto z_bb_4;
    z_bb_14:
    zT_61 = node.kind;
    zT_60 = zT_61 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init);
    goto z_bb_16;
    z_bb_15:
    zT_60 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_60) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_66 = node.kind;
    zT_65 = zT_66 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_19;
    z_bb_18:
    zT_65 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_65) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_70 = node.child_0;
    zT_71 = 0;
    if ((unsigned char)(zT_70 != (unsigned int)zT_71)) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_89 = node.kind;
    if ((unsigned char)(zT_89 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_26; else goto z_bb_27;
    z_bb_22:
    zT_74 = ct;
    zT_75 = module_id;
    zT_76 = node.child_0;
    zT_80.has_value = 1;
    zT_80.value = scope;
    zT_77 = zT_80;
    zT_78 = source_file_id;
    zT_81 = zF_EE3AA0D0_resolveTypeExpr(zT_74, zT_75, zT_76, zT_77, zT_78);
    rtype = zT_81;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_84 = ct->resolved_types;
    zT_85 = node.child_0;
    zT_86 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_84, zT_85, zT_86);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_94 = scope->count;
    scope_base = zT_94;
    zT_96 = ct->store;
    zT_97 = node_idx;
    zT_99 = zF_152E19CB_astStoreNodeExtraCh(zT_96, zT_97);
    decls_n = zT_99;
    zT_101 = 0;
    zT_102 = (unsigned int)zT_101;
    di = zT_102;
    goto z_bb_28;
    z_bb_27:
    zT_124 = depth + (unsigned int)(1);
    cd = zT_124;
    zT_125 = node.kind;
    if ((unsigned char)(zT_125 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_32; else goto z_bb_33;
    z_bb_28:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_105 = ct;
    zT_106 = module_id;
    zT_111 = ct->store;
    zT_112 = node_idx;
    zT_116 = zF_B10B1BC1_astStoreNodeExtraCh(zT_111, zT_112, (unsigned int)((unsigned int)di));
    zT_107 = zT_116;
    zT_109 = source_file_id;
    zT_110 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_105, zT_106, zT_107, (unsigned int)(depth + (unsigned int)(1)), zT_109, zT_110);
    goto z_bb_31;
    z_bb_30:
    scope->count = scope_base;
    goto z_bb_27;
    z_bb_31:
    zT_119 = 1;
    zT_121 = di + (unsigned int)((unsigned int)zT_119);
    di = zT_121;
    goto z_bb_28;
    z_bb_32:
    zT_129 = node.child_0;
    zT_130 = 0;
    if ((unsigned char)(zT_129 != (unsigned int)zT_130)) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    return;
    z_bb_34:
    zT_132 = ct;
    zT_133 = module_id;
    zT_134 = node.child_0;
    zT_135 = cd;
    zT_136 = source_file_id;
    zT_137 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_132, zT_133, zT_134, zT_135, zT_136, zT_137);
    goto z_bb_35;
    z_bb_35:
    zT_139 = node.child_1;
    zT_140 = 0;
    if ((unsigned char)(zT_139 != (unsigned int)zT_140)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_142 = ct;
    zT_143 = module_id;
    zT_144 = node.child_1;
    zT_145 = cd;
    zT_146 = source_file_id;
    zT_147 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_142, zT_143, zT_144, zT_145, zT_146, zT_147);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_33;
}

/* __module_init */
void zF_780653D2___module_init_20(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_F85C5DED_DiagnosticCollector zT_2 = {0};
    zT_8143F551_AstKind zT_3 = 0;
    zT_6B0A7D14_AstStore zT_4 = {0};
    zT_072B53A6_ModuleRegistry zT_5 = {0};
    zT_3D7259E2_SymbolRegistry zT_6 = {0};
    zT_338B7C76_TypeRegistry zT_7 = {0};
    zT_8EED1867_ResolvedTypeTable zT_8 = {0};
    zT_66E7D2EF_CoercionTable zT_9 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_F85C5DED_DiagnosticCollector = zT_2;
    zG_8143F551_AstKind = zT_3;
    zG_6B0A7D14_AstStore = zT_4;
    zG_072B53A6_ModuleRegistry = zT_5;
    zG_3D7259E2_SymbolRegistry = zT_6;
    zG_338B7C76_TypeRegistry = zT_7;
    zG_8EED1867_ResolvedTypeTable = zT_8;
    zG_66E7D2EF_CoercionTable = zT_9;
    return;
}

/* EOF */
