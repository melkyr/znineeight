#include "front_resolution_D5E9117C.h"
/* resolveTypeExpr */
unsigned int zF_EE3AA0D0_resolveTypeExpr(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, zT_05CE5599_Opt_400 scope, unsigned int source_file_id) {
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    zT_F85C5DED_DiagnosticCollector* zT_11;
    zT_7232B4D4_Opt_230 zT_12;
    zT_03CE5273_Opt_402 zT_13 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_14;
    unsigned int zT_15;
    unsigned int zT_19 = 0;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_7 = ct->store;
    zT_6.store = zT_7;
    zT_8 = ct->typereg;
    zT_6.typereg = zT_8;
    zT_9 = ct->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = ct->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = module_id;
    zT_6.source_file_id = source_file_id;
    zT_11 = ct->diag;
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    zT_6.diag = zT_12;
    zT_6.local_consts = scope;
    zT_13.has_value = 0;
    zT_6.local_types = zT_13;
    env = zT_6;
    zT_14 = &env;
    zT_15 = node_idx;
    zT_19 = zF_F2107C15_resolveTypeExprFull(zT_14, zT_15, (unsigned int)(0));
    return zT_19;
}

/* countUntypedGlobals */
unsigned int zF_5DF8AD5B_countUntypedGlobals(zT_6DCFC8DB_FrontResCtx* ct) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_7;
    unsigned int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_11;
    zT_060CD1EB_SymbolTable* zT_12;
    zT_060CD1EB_SymbolTable zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_3A105EF1_Symbol* zT_20;
    zT_3A105EF1_Symbol zT_21;
    unsigned int zT_22;
    zT_3C598AEF_SymbolKind zT_25;
    unsigned char zT_29;
    zT_3C598AEF_SymbolKind zT_30;
    int zT_34;
    unsigned int zT_36;
    int zT_37;
    unsigned int zT_39;
    int zT_40;
    unsigned int zT_42;
    unsigned int cnt;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol sym;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    cnt = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    ti = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = ct->symbol_reg;
    zT_8 = zT_7->tables_len;
    if ((unsigned char)(ti < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = ct->symbol_reg;
    zT_12 = zT_11->tables_items;
    zT_13 = zT_12[ti];
    table = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    si = zT_16;
    goto z_bb_5;
    z_bb_3:
    return cnt;
    z_bb_4:
    zT_40 = 1;
    zT_42 = ti + (unsigned int)((unsigned int)zT_40);
    ti = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_17 = table.len;
    if ((unsigned char)(si < zT_17)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = table.items;
    zT_21 = zT_20[si];
    sym = zT_21;
    zT_22 = sym.type_id;
    if ((unsigned char)(zT_22 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = 1;
    zT_39 = si + (unsigned int)((unsigned int)zT_37);
    si = zT_39;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_25 = sym.kind;
    if ((unsigned char)(zT_25 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_30 = sym.kind;
    zT_29 = zT_30 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_34 = 1;
    zT_36 = cnt + (unsigned int)((unsigned int)zT_34);
    cnt = zT_36;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
}

/* frontResolveModuleInits */
void zF_8A0E7747_frontResolveModuleI(zT_6DCFC8DB_FrontResCtx* ct) {
    zT_3E40CD83_Sand* zT_1;
    zT_6DCFC8DB_FrontResCtx* zT_4;
    unsigned int zT_5 = 0;
    unsigned int zT_7;
    int zT_9;
    unsigned int zT_10;
    unsigned char zT_13;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_3E40CD83_Sand* zT_24;
    zT_6E8D187B_ModuleEntry* zT_27;
    zT_6E8D187B_ModuleEntry zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    unsigned int zT_41 = 0;
    zT_6E8D187B_ModuleEntry* zT_43;
    zT_6E8D187B_ModuleEntry zT_44;
    unsigned int zT_45;
    zT_3E40CD83_Sand* zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_48;
    zT_F85C5DED_DiagnosticCollector* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_3D7259E2_SymbolRegistry* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_66E7D2EF_CoercionTable* zT_55;
    zT_21D3708C_U32ToU32Map* zT_56;
    zT_21D3708C_U32ToU32Map* zT_57;
    zT_21D3708C_U32ToU32Map* zT_58;
    zT_D3EB6303_StringInterner* zT_59;
    zT_21D3708C_U32ToU32Map* zT_60;
    zT_21D3708C_U32ToU32Map* zT_61;
    zT_072B53A6_ModuleRegistry* zT_62;
    zT_A4CE86B7_U64ToU32Map* zT_63;
    zT_6E8D187B_ModuleEntry* zT_70;
    zT_6E8D187B_ModuleEntry zT_71;
    zT_38C12417_SemanticAnalyzer zT_82 = {0};
    int zT_84;
    unsigned int zT_85;
    zT_6B0A7D14_AstStore* zT_89;
    unsigned int zT_90;
    unsigned int zT_94 = 0;
    zT_6B0A7D14_AstStore* zT_96;
    unsigned int zT_97;
    zT_22A7C88B_AstNode zT_99 = {0};
    zT_8143F551_AstKind zT_100;
    unsigned int zT_104;
    zT_6DCFC8DB_FrontResCtx* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_05CE5599_Opt_400 zT_111;
    unsigned int zT_112;
    zT_6E8D187B_ModuleEntry* zT_113;
    zT_6E8D187B_ModuleEntry zT_114;
    zT_05CE5599_Opt_400 zT_117 = {0};
    unsigned int zT_118 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    zT_8EED1867_ResolvedTypeTable* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_130;
    zT_6B0A7D14_AstStore* zT_134;
    unsigned int zT_135;
    zT_22A7C88B_AstNode zT_138 = {0};
    zT_8143F551_AstKind zT_139;
    unsigned char zT_143;
    zT_8143F551_AstKind zT_144;
    zT_38C12417_SemanticAnalyzer* zT_149;
    unsigned int zT_150;
    unsigned int zT_152 = 0;
    zT_8143F551_AstKind zT_153;
    zT_6E8D187B_ModuleEntry* zT_160;
    zT_6E8D187B_ModuleEntry zT_161;
    unsigned int zT_162;
    zT_6B0A7D14_AstStore* zT_166;
    unsigned int zT_167;
    unsigned int zT_169 = 0;
    zT_79FAE712_u64 zT_171;
    zT_338B7C76_TypeRegistry* zT_172;
    zT_79FAE712_u64 zT_173;
    unsigned int zT_174;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    unsigned int zT_181 = 0;
    zT_3D7259E2_SymbolRegistry* zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    zT_6E8D187B_ModuleEntry* zT_187;
    zT_6E8D187B_ModuleEntry zT_188;
    zT_527B5CE0_Opt_876 zT_190 = {0};
    unsigned char zT_191;
    zT_3C598AEF_SymbolKind zT_193;
    zT_3D7259E2_SymbolRegistry* zT_198;
    unsigned int zT_199;
    unsigned int zT_200;
    zT_6E8D187B_ModuleEntry* zT_202;
    zT_6E8D187B_ModuleEntry zT_203;
    zT_6B0A7D14_AstStore* zT_205;
    unsigned int zT_206;
    unsigned int zT_208 = 0;
    zT_527B5CE0_Opt_876 zT_209 = {0};
    unsigned char zT_210;
    zT_3C598AEF_SymbolKind zT_212;
    unsigned char zT_218;
    zT_8EED1867_ResolvedTypeTable* zT_220;
    unsigned int zT_221;
    zT_BAEE192E_Opt_10 zT_223 = {0};
    unsigned char zT_226;
    unsigned char zT_229;
    unsigned int zT_232;
    unsigned char zT_236;
    unsigned char zT_237;
    unsigned char zT_240;
    zT_8EED1867_ResolvedTypeTable* zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    unsigned char zT_247;
    zT_8EED1867_ResolvedTypeTable* zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned char zT_255;
    unsigned int zT_256;
    zT_8EED1867_ResolvedTypeTable* zT_260;
    unsigned int zT_261;
    zT_BAEE192E_Opt_10 zT_264 = {0};
    unsigned char zT_265;
    zT_8EED1867_ResolvedTypeTable* zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned char zT_276;
    unsigned char zT_279;
    unsigned char zT_282;
    zT_6B0A7D14_AstStore* zT_286;
    unsigned int zT_287;
    unsigned int zT_289 = 0;
    zT_3D7259E2_SymbolRegistry* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    zT_6E8D187B_ModuleEntry* zT_295;
    zT_6E8D187B_ModuleEntry zT_296;
    zT_527B5CE0_Opt_876 zT_298 = {0};
    unsigned char zT_299;
    unsigned int zT_301;
    unsigned int zT_304;
    unsigned char zT_306;
    unsigned int zT_307;
    unsigned char zT_310;
    int zT_311;
    unsigned int zT_313;
    int zT_314;
    unsigned int zT_316;
    int zT_319;
    unsigned int zT_321;
    zT_3E40CD83_Sand* zT_322;
    unsigned int bound;
    unsigned int iter;
    unsigned char changed;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    unsigned int decls_n;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int rtype;
    zT_22A7C88B_AstNode init;
    unsigned int init_type;
    zT_BAEE192E_Opt_10 vd_existing;
    zT_79FAE712_u64 ck;
    unsigned int ref_name;
    zT_527B5CE0_Opt_876 ref_sym;
    zT_3A105EF1_Symbol* rs;
    zT_527B5CE0_Opt_876 own_sym;
    zT_3A105EF1_Symbol* os;
    unsigned char need_set;
    unsigned int vex;
    zT_BAEE192E_Opt_10 mdt2;
    unsigned int mt2;
    unsigned int name_id;
    zT_527B5CE0_Opt_876 sym;
    zT_3A105EF1_Symbol* s;
    zT_1 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_1);
    zT_4 = ct;
    zT_5 = zF_5DF8AD5B_countUntypedGlobals(zT_4);
    zT_7 = zT_5 + (unsigned int)(1);
    bound = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    iter = zT_10;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(iter < bound)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = 0;
    changed = zT_13;
    zT_15 = ct->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_5;
    z_bb_3:
    zT_322 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_322);
    return;
    z_bb_4:
    zT_319 = 1;
    zT_321 = iter + (unsigned int)((unsigned int)zT_319);
    iter = zT_321;
    goto z_bb_1;
    z_bb_5:
    zT_22 = mods.len;
    if ((unsigned char)(mi < zT_22)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_24 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_24);
    zT_27 = mods.ptr;
    zT_28 = zT_27[mi];
    zT_29 = zT_28.ast_root;
    ast_root = zT_29;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    if ((unsigned char)(changed == (unsigned char)(0))) goto z_bb_88; else goto z_bb_89;
    z_bb_8:
    zT_314 = 1;
    zT_316 = mi + (unsigned int)((unsigned int)zT_314);
    mi = zT_316;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_33 = ct->store;
    zT_34 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    zT_38 = ct->store;
    zT_39 = ast_root;
    zT_41 = zF_152E19CB_astStoreNodeExtraCh(zT_38, zT_39);
    decls_n = zT_41;
    zT_43 = mods.ptr;
    zT_44 = zT_43[mi];
    zT_45 = zT_44.source_file_id;
    src_fid = zT_45;
    zT_47 = ct->scratch;
    zT_48 = ct->resolved_types;
    zT_49 = ct->diag;
    zT_50 = ct->typereg;
    zT_51 = ct->symbol_reg;
    zT_52 = ct->store;
    zT_70 = mods.ptr;
    zT_71 = zT_70[mi];
    zT_53 = zT_71.id;
    zT_54 = src_fid;
    zT_55 = ct->coercion_table;
    zT_56 = ct->enum_value_table;
    zT_57 = ct->tuple_index_table;
    zT_58 = ct->error_code_registry;
    zT_59 = ct->interner;
    zT_60 = ct->call_arg_types;
    zT_61 = ct->call_param_map;
    zT_62 = ct->module_reg;
    zT_63 = ct->suspending_fns;
    zT_82 = zF_84ADA681_semanticAnalyzerIni(zT_47, zT_48, zT_49, zT_50, zT_51, zT_52, zT_53, zT_54, zT_55, zT_56, zT_57, zT_58, zT_59, zT_60, zT_61, zT_62, zT_63);
    sa = zT_82;
    zT_84 = 0;
    zT_85 = (unsigned int)zT_84;
    di = zT_85;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_89 = ct->store;
    zT_90 = ast_root;
    zT_94 = zF_B10B1BC1_astStoreNodeExtraCh(zT_89, zT_90, (unsigned int)((unsigned int)di));
    decl_idx = zT_94;
    zT_96 = ct->store;
    zT_97 = decl_idx;
    zT_99 = zF_FCDD1D35_astStoreNodeAt(zT_96, zT_97);
    decl = zT_99;
    zT_100 = decl.kind;
    if ((unsigned char)(zT_100 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    zT_311 = 1;
    zT_313 = di + (unsigned int)((unsigned int)zT_311);
    di = zT_313;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    zT_104 = decl.child_0;
    if ((unsigned char)(zT_104 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_108 = ct;
    zT_113 = mods.ptr;
    zT_114 = zT_113[mi];
    zT_109 = zT_114.id;
    zT_110 = decl.child_0;
    zT_117.has_value = 0;
    zT_111 = zT_117;
    zT_112 = src_fid;
    zT_118 = zF_EE3AA0D0_resolveTypeExpr(zT_108, zT_109, zT_110, zT_111, zT_112);
    rtype = zT_118;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_130 = decl.child_1;
    if ((unsigned char)(zT_130 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_121 = ct->resolved_types;
    zT_122 = decl.child_0;
    zT_123 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_121, zT_122, zT_123);
    zT_126 = ct->resolved_types;
    zT_127 = decl_idx;
    zT_128 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_126, zT_127, zT_128);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_134 = ct->store;
    zT_135 = decl.child_1;
    zT_138 = zF_FCDD1D35_astStoreNodeAt(zT_134, zT_135);
    init = zT_138;
    zT_139 = init.kind;
    if ((unsigned char)(zT_139 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_14;
    z_bb_23:
    zT_144 = init.kind;
    zT_143 = zT_144 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_25;
    z_bb_24:
    zT_143 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_143) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_149 = &sa;
    zT_150 = decl_idx;
    zT_152 = zF_CC4377FA_semanticAnalyzerRes(zT_149, zT_150);
    init_type = zT_152;
    zT_153 = init.kind;
    if ((unsigned char)(zT_153 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    if ((unsigned char)(init_type != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_220 = ct->resolved_types;
    zT_221 = decl_idx;
    zT_223 = zF_999DCF51_resolvedTypeTableGe(zT_220, zT_221);
    vd_existing = zT_223;
    if ((unsigned char)(init_type != (unsigned int)(1))) goto z_bb_40; else goto z_bb_41;
    z_bb_30:
    zT_160 = mods.ptr;
    zT_161 = zT_160[mi];
    zT_162 = zT_161.id;
    zT_166 = ct->store;
    zT_167 = decl_idx;
    zT_169 = zF_8BA26B9E_astStoreNodePayload(zT_166, zT_167);
    zT_171 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_162) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_169);
    ck = zT_171;
    zT_172 = ct->typereg;
    zT_173 = ck;
    zT_174 = init_type;
    zF_5E95558D_nameCachePut(zT_172, zT_173, zT_174);
    goto z_bb_31;
    z_bb_31:
    zT_177 = ct->store;
    zT_178 = decl.child_1;
    zT_181 = zF_53458827_astStoreIdentifier(zT_177, zT_178);
    ref_name = zT_181;
    zT_183 = ct->symbol_reg;
    zT_187 = mods.ptr;
    zT_188 = zT_187[mi];
    zT_184 = zT_188.id;
    zT_185 = ref_name;
    zT_190 = zF_A398987E_symbolRegistryQuali(zT_183, zT_184, zT_185);
    ref_sym = zT_190;
    zT_191 = ref_sym.has_value;
    if (zT_191) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    rs = ref_sym.value;
    zT_193 = rs->kind;
    if ((unsigned char)(zT_193 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    zT_198 = ct->symbol_reg;
    zT_202 = mods.ptr;
    zT_203 = zT_202[mi];
    zT_199 = zT_203.id;
    zT_205 = ct->store;
    zT_206 = decl_idx;
    zT_208 = zF_8BA26B9E_astStoreNodePayload(zT_205, zT_206);
    zT_200 = zT_208;
    zT_209 = zF_A398987E_symbolRegistryQuali(zT_198, zT_199, zT_200);
    own_sym = zT_209;
    zT_210 = own_sym.has_value;
    if (zT_210) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    os = own_sym.value;
    zT_212 = os->kind;
    if ((unsigned char)(zT_212 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    os->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_218 = 1;
    changed = zT_218;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    zT_226 = init_type != (unsigned int)(18);
    goto z_bb_42;
    z_bb_41:
    zT_226 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_226) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_229 = init_type != (unsigned int)(20);
    goto z_bb_45;
    z_bb_44:
    zT_229 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_229) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_232 = decl.child_0;
    if ((unsigned char)(zT_232 == (unsigned int)(0))) goto z_bb_48; else goto z_bb_50;
    z_bb_47:
    if ((unsigned char)(init_type == (unsigned int)(19))) goto z_bb_59; else goto z_bb_60;
    z_bb_48:
    zT_236 = 1;
    need_set = zT_236;
    zT_237 = vd_existing.has_value;
    if (zT_237) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_247 = vd_existing.has_value;
    if ((unsigned char)(!zT_247)) goto z_bb_57; else goto z_bb_58;
    z_bb_51:
    vex = vd_existing.value;
    if ((unsigned char)(vex == init_type)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    if ((unsigned char)(need_set != (unsigned char)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_240 = 0;
    need_set = zT_240;
    goto z_bb_54;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_243 = ct->resolved_types;
    zT_244 = decl_idx;
    zT_245 = init_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_243, zT_244, zT_245);
    goto z_bb_56;
    z_bb_56:
    goto z_bb_49;
    z_bb_57:
    zT_249 = ct->resolved_types;
    zT_250 = decl_idx;
    zT_251 = init_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_249, zT_250, zT_251);
    goto z_bb_58;
    z_bb_58:
    goto z_bb_49;
    z_bb_59:
    zT_256 = decl.child_0;
    zT_255 = zT_256 != (unsigned int)(0);
    goto z_bb_61;
    z_bb_60:
    zT_255 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_255) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_260 = ct->resolved_types;
    zT_261 = decl.child_0;
    zT_264 = zF_999DCF51_resolvedTypeTableGe(zT_260, zT_261);
    mdt2 = zT_264;
    zT_265 = mdt2.has_value;
    if (zT_265) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    if ((unsigned char)(init_type != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_64:
    mt2 = mdt2.value;
    if ((unsigned char)(mt2 != (unsigned int)(18))) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    zT_269 = ct->resolved_types;
    zT_270 = decl.child_1;
    zT_271 = mt2;
    zF_19B4A07D_resolvedTypeTableSe(zT_269, zT_270, zT_271);
    goto z_bb_67;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_276 = init_type != (unsigned int)(1);
    goto z_bb_70;
    z_bb_69:
    zT_276 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_276) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_279 = init_type != (unsigned int)(18);
    goto z_bb_73;
    z_bb_72:
    zT_279 = 0;
    goto z_bb_73;
    z_bb_73:
    if (zT_279) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_282 = init_type != (unsigned int)(20);
    goto z_bb_76;
    z_bb_75:
    zT_282 = 0;
    goto z_bb_76;
    z_bb_76:
    if (zT_282) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_286 = ct->store;
    zT_287 = decl_idx;
    zT_289 = zF_8BA26B9E_astStoreNodePayload(zT_286, zT_287);
    name_id = zT_289;
    zT_291 = ct->symbol_reg;
    zT_295 = mods.ptr;
    zT_296 = zT_295[mi];
    zT_292 = zT_296.id;
    zT_293 = name_id;
    zT_298 = zF_A398987E_symbolRegistryQuali(zT_291, zT_292, zT_293);
    sym = zT_298;
    zT_299 = sym.has_value;
    if (zT_299) goto z_bb_79; else goto z_bb_80;
    z_bb_78:
    goto z_bb_27;
    z_bb_79:
    s = sym.value;
    zT_301 = decl.child_0;
    if ((unsigned char)(zT_301 == (unsigned int)(0))) goto z_bb_81; else goto z_bb_83;
    z_bb_80:
    goto z_bb_78;
    z_bb_81:
    zT_304 = s->type_id;
    if ((unsigned char)(zT_304 != init_type)) goto z_bb_84; else goto z_bb_85;
    z_bb_82:
    goto z_bb_80;
    z_bb_83:
    zT_307 = s->type_id;
    if ((unsigned char)(zT_307 == (unsigned int)(0))) goto z_bb_86; else goto z_bb_87;
    z_bb_84:
    s->type_id = init_type;
    zT_306 = 1;
    changed = zT_306;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    s->type_id = init_type;
    zT_310 = 1;
    changed = zT_310;
    goto z_bb_87;
    z_bb_87:
    goto z_bb_82;
    z_bb_88:
    goto z_bb_3;
    z_bb_89:
    goto z_bb_4;
}

/* resolveStmtTypes */
void zF_783226DA_resolveStmtTypes(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth, unsigned int source_file_id) {
    zT_3E40CD83_Sand* zT_6;
    zT_E2DF2801_LocalConstScope zT_8 = {0};
    zT_6DCFC8DB_FrontResCtx* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_E2DF2801_LocalConstScope* zT_14;
    zT_E2DF2801_LocalConstScope scope;
    zT_6 = ct->scratch;
    zT_8 = zF_F5EBC2FF_localConstScopeInit(zT_6);
    scope = zT_8;
    zT_9 = ct;
    zT_10 = module_id;
    zT_11 = node_idx;
    zT_12 = depth;
    zT_13 = source_file_id;
    zT_14 = &scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_9, zT_10, zT_11, zT_12, zT_13, zT_14);
    return;
}

/* resolveStmtTypesRec */
void zF_B1CC762C_resolveStmtTypesRec(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth, unsigned int source_file_id, zT_E2DF2801_LocalConstScope* scope) {
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    zT_8143F551_AstKind zT_13;
    unsigned int zT_17;
    int zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_05CE5599_Opt_400 zT_24;
    unsigned int zT_25;
    zT_05CE5599_Opt_400 zT_27;
    unsigned int zT_28 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_8EED1867_ResolvedTypeTable* zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_40;
    unsigned char zT_45;
    unsigned int zT_46;
    int zT_47;
    zT_E2DF2801_LocalConstScope* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_55 = 0;
    zT_8143F551_AstKind zT_56;
    unsigned char zT_60;
    zT_8143F551_AstKind zT_61;
    unsigned char zT_65;
    zT_8143F551_AstKind zT_66;
    unsigned int zT_70;
    int zT_71;
    zT_6DCFC8DB_FrontResCtx* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_05CE5599_Opt_400 zT_77;
    unsigned int zT_78;
    zT_05CE5599_Opt_400 zT_80;
    unsigned int zT_81 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_8143F551_AstKind zT_89;
    unsigned int zT_94;
    zT_6B0A7D14_AstStore* zT_96;
    unsigned int zT_97;
    unsigned int zT_99 = 0;
    int zT_101;
    unsigned int zT_102;
    zT_6DCFC8DB_FrontResCtx* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_109;
    zT_E2DF2801_LocalConstScope* zT_110;
    zT_6B0A7D14_AstStore* zT_111;
    unsigned int zT_112;
    unsigned int zT_116 = 0;
    int zT_119;
    unsigned int zT_121;
    unsigned int zT_124;
    zT_8143F551_AstKind zT_125;
    unsigned int zT_129;
    int zT_130;
    zT_6DCFC8DB_FrontResCtx* zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    zT_E2DF2801_LocalConstScope* zT_137;
    unsigned int zT_139;
    int zT_140;
    zT_6DCFC8DB_FrontResCtx* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_E2DF2801_LocalConstScope* zT_147;
    zT_22A7C88B_AstNode node;
    unsigned int rtype;
    unsigned int scope_base;
    unsigned int decls_n;
    unsigned int di;
    unsigned int cd;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = ct->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_13 = node.kind;
    if ((unsigned char)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = node.child_0;
    zT_18 = 0;
    if ((unsigned char)(zT_17 != (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_56 = node.kind;
    if ((unsigned char)(zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_15; else goto z_bb_14;
    z_bb_5:
    zT_21 = ct;
    zT_22 = module_id;
    zT_23 = node.child_0;
    zT_27.has_value = 1;
    zT_27.value = scope;
    zT_24 = zT_27;
    zT_25 = source_file_id;
    zT_28 = zF_EE3AA0D0_resolveTypeExpr(zT_21, zT_22, zT_23, zT_24, zT_25);
    rtype = zT_28;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_40 = node.flags;
    if ((unsigned char)((unsigned char)(zT_40 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_31 = ct->resolved_types;
    zT_32 = node.child_0;
    zT_33 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_31, zT_32, zT_33);
    zT_36 = ct->resolved_types;
    zT_37 = node_idx;
    zT_38 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_36, zT_37, zT_38);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_46 = node.child_1;
    zT_47 = 0;
    zT_45 = zT_46 != (unsigned int)zT_47;
    goto z_bb_11;
    z_bb_10:
    zT_45 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_45) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_49 = scope;
    zT_52 = ct->store;
    zT_53 = node_idx;
    zT_55 = zF_8BA26B9E_astStoreNodePayload(zT_52, zT_53);
    zT_50 = zT_55;
    zT_51 = node_idx;
    zF_DA915531_localConstScopePush(zT_49, zT_50, zT_51);
    goto z_bb_13;
    z_bb_13:
    goto z_bb_4;
    z_bb_14:
    zT_61 = node.kind;
    zT_60 = zT_61 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init);
    goto z_bb_16;
    z_bb_15:
    zT_60 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_60) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_66 = node.kind;
    zT_65 = zT_66 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_19;
    z_bb_18:
    zT_65 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_65) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_70 = node.child_0;
    zT_71 = 0;
    if ((unsigned char)(zT_70 != (unsigned int)zT_71)) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_89 = node.kind;
    if ((unsigned char)(zT_89 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_26; else goto z_bb_27;
    z_bb_22:
    zT_74 = ct;
    zT_75 = module_id;
    zT_76 = node.child_0;
    zT_80.has_value = 1;
    zT_80.value = scope;
    zT_77 = zT_80;
    zT_78 = source_file_id;
    zT_81 = zF_EE3AA0D0_resolveTypeExpr(zT_74, zT_75, zT_76, zT_77, zT_78);
    rtype = zT_81;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_84 = ct->resolved_types;
    zT_85 = node.child_0;
    zT_86 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_84, zT_85, zT_86);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_94 = scope->count;
    scope_base = zT_94;
    zT_96 = ct->store;
    zT_97 = node_idx;
    zT_99 = zF_152E19CB_astStoreNodeExtraCh(zT_96, zT_97);
    decls_n = zT_99;
    zT_101 = 0;
    zT_102 = (unsigned int)zT_101;
    di = zT_102;
    goto z_bb_28;
    z_bb_27:
    zT_124 = depth + (unsigned int)(1);
    cd = zT_124;
    zT_125 = node.kind;
    if ((unsigned char)(zT_125 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_32; else goto z_bb_33;
    z_bb_28:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_105 = ct;
    zT_106 = module_id;
    zT_111 = ct->store;
    zT_112 = node_idx;
    zT_116 = zF_B10B1BC1_astStoreNodeExtraCh(zT_111, zT_112, (unsigned int)((unsigned int)di));
    zT_107 = zT_116;
    zT_109 = source_file_id;
    zT_110 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_105, zT_106, zT_107, (unsigned int)(depth + (unsigned int)(1)), zT_109, zT_110);
    goto z_bb_31;
    z_bb_30:
    scope->count = scope_base;
    goto z_bb_27;
    z_bb_31:
    zT_119 = 1;
    zT_121 = di + (unsigned int)((unsigned int)zT_119);
    di = zT_121;
    goto z_bb_28;
    z_bb_32:
    zT_129 = node.child_0;
    zT_130 = 0;
    if ((unsigned char)(zT_129 != (unsigned int)zT_130)) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    return;
    z_bb_34:
    zT_132 = ct;
    zT_133 = module_id;
    zT_134 = node.child_0;
    zT_135 = cd;
    zT_136 = source_file_id;
    zT_137 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_132, zT_133, zT_134, zT_135, zT_136, zT_137);
    goto z_bb_35;
    z_bb_35:
    zT_139 = node.child_1;
    zT_140 = 0;
    if ((unsigned char)(zT_139 != (unsigned int)zT_140)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_142 = ct;
    zT_143 = module_id;
    zT_144 = node.child_1;
    zT_145 = cd;
    zT_146 = source_file_id;
    zT_147 = scope;
    zF_B1CC762C_resolveStmtTypesRec(zT_142, zT_143, zT_144, zT_145, zT_146, zT_147);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_33;
}

/* __module_init */
void zF_780653D2___module_init_20(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_F85C5DED_DiagnosticCollector zT_2 = {0};
    zT_8143F551_AstKind zT_3 = 0;
    zT_6B0A7D14_AstStore zT_4 = {0};
    zT_072B53A6_ModuleRegistry zT_5 = {0};
    zT_3D7259E2_SymbolRegistry zT_6 = {0};
    zT_338B7C76_TypeRegistry zT_7 = {0};
    zT_8EED1867_ResolvedTypeTable zT_8 = {0};
    zT_66E7D2EF_CoercionTable zT_9 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_F85C5DED_DiagnosticCollector = zT_2;
    zG_8143F551_AstKind = zT_3;
    zG_6B0A7D14_AstStore = zT_4;
    zG_072B53A6_ModuleRegistry = zT_5;
    zG_3D7259E2_SymbolRegistry = zT_6;
    zG_338B7C76_TypeRegistry = zT_7;
    zG_8EED1867_ResolvedTypeTable = zT_8;
    zG_66E7D2EF_CoercionTable = zT_9;
    return;
}

/* EOF */
