#include "front_resolution_D5E9117C.h"
/* resolveTypeExpr */
unsigned int zF_EE3AA0D0_resolveTypeExpr(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx) {
    zT_ABC1EBBE_TypeResolveEnv zT_4;
    zT_6B0A7D14_AstStore* zT_5;
    zT_338B7C76_TypeRegistry* zT_6;
    zT_3D7259E2_SymbolRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_ABC1EBBE_TypeResolveEnv* zT_9;
    unsigned int zT_10;
    unsigned int zT_14 = 0;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_5 = ct->store;
    zT_4.store = zT_5;
    zT_6 = ct->typereg;
    zT_4.typereg = zT_6;
    zT_7 = ct->symbol_reg;
    zT_4.symbol_reg = zT_7;
    zT_8 = ct->interner;
    zT_4.interner = zT_8;
    zT_4.module_id = module_id;
    env = zT_4;
    zT_9 = &env;
    zT_10 = node_idx;
    zT_14 = zF_F2107C15_resolveTypeExprFull(zT_9, zT_10, (unsigned int)(0));
    return zT_14;
}

/* countUntypedGlobals */
unsigned int zF_5DF8AD5B_countUntypedGlobals(zT_6DCFC8DB_FrontResCtx* ct) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_7;
    unsigned int zT_8;
    zT_3D7259E2_SymbolRegistry* zT_11;
    zT_060CD1EB_SymbolTable* zT_12;
    zT_060CD1EB_SymbolTable zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_3A105EF1_Symbol* zT_20;
    zT_3A105EF1_Symbol zT_21;
    unsigned int zT_22;
    zT_3C598AEF_SymbolKind zT_25;
    int zT_30;
    zT_3C598AEF_SymbolKind zT_31;
    int zT_36;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_42;
    unsigned int cnt;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol sym;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    cnt = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    ti = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = ct->symbol_reg;
    zT_8 = zT_7->tables_len;
    if ((int)(ti < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = ct->symbol_reg;
    zT_12 = zT_11->tables_items;
    zT_13 = zT_12[ti];
    table = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    si = zT_16;
    goto z_bb_5;
    z_bb_3:
    return cnt;
    z_bb_4:
    zT_41 = 1;
    zT_42 = ti + zT_41;
    ti = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_17 = table.len;
    if ((int)(si < zT_17)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = table.items;
    zT_21 = zT_20[si];
    sym = zT_21;
    zT_22 = sym.type_id;
    if ((int)(zT_22 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_39 = 1;
    zT_40 = si + zT_39;
    si = zT_40;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_25 = sym.kind;
    if ((int)(zT_25 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_31 = sym.kind;
    zT_30 = zT_31 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    goto z_bb_13;
    z_bb_12:
    zT_30 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_30) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_36 = 1;
    zT_38 = cnt + (unsigned int)((unsigned int)zT_36);
    cnt = zT_38;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
}

/* frontResolveModuleInits */
void zF_8A0E7747_frontResolveModuleI(zT_6DCFC8DB_FrontResCtx* ct) {
    zT_3E40CD83_Sand* zT_1;
    zT_6DCFC8DB_FrontResCtx* zT_4;
    unsigned int zT_5 = 0;
    unsigned int zT_7;
    int zT_9;
    unsigned int zT_10;
    unsigned char zT_13;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_3E40CD83_Sand* zT_24;
    zT_6E8D187B_ModuleEntry* zT_27;
    zT_6E8D187B_ModuleEntry zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_41 = {0};
    zT_6E8D187B_ModuleEntry* zT_43;
    zT_6E8D187B_ModuleEntry zT_44;
    unsigned int zT_45;
    zT_3E40CD83_Sand* zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_48;
    zT_F85C5DED_DiagnosticCollector* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_3D7259E2_SymbolRegistry* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_66E7D2EF_CoercionTable* zT_55;
    zT_21D3708C_U32ToU32Map* zT_56;
    zT_21D3708C_U32ToU32Map* zT_57;
    zT_D3EB6303_StringInterner* zT_58;
    zT_21D3708C_U32ToU32Map* zT_59;
    zT_21D3708C_U32ToU32Map* zT_60;
    zT_072B53A6_ModuleRegistry* zT_61;
    zT_6E8D187B_ModuleEntry* zT_68;
    zT_6E8D187B_ModuleEntry zT_69;
    zT_38C12417_SemanticAnalyzer zT_78 = {0};
    int zT_80;
    unsigned int zT_81;
    unsigned int zT_83;
    zT_6B0A7D14_AstStore* zT_86;
    unsigned int zT_87;
    unsigned int* zT_89;
    zT_22A7C88B_AstNode zT_91 = {0};
    zT_8143F551_AstKind zT_92;
    unsigned int zT_97;
    zT_6DCFC8DB_FrontResCtx* zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_6E8D187B_ModuleEntry* zT_104;
    zT_6E8D187B_ModuleEntry zT_105;
    unsigned int zT_108 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    zT_8EED1867_ResolvedTypeTable* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int* zT_120;
    unsigned int zT_122;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    zT_22A7C88B_AstNode zT_130 = {0};
    zT_8143F551_AstKind zT_131;
    int zT_136;
    zT_8143F551_AstKind zT_137;
    zT_38C12417_SemanticAnalyzer* zT_143;
    unsigned int zT_144;
    unsigned int* zT_146;
    unsigned int zT_148 = 0;
    zT_8143F551_AstKind zT_149;
    zT_6E8D187B_ModuleEntry* zT_157;
    zT_6E8D187B_ModuleEntry zT_158;
    unsigned int zT_159;
    zT_6B0A7D14_AstStore* zT_163;
    unsigned int zT_164;
    unsigned int* zT_166;
    unsigned int zT_168 = 0;
    zT_79FAE712_u64 zT_170;
    zT_338B7C76_TypeRegistry* zT_171;
    zT_79FAE712_u64 zT_172;
    unsigned int zT_173;
    zT_6B0A7D14_AstStore* zT_176;
    unsigned int zT_177;
    unsigned int zT_180 = 0;
    zT_3D7259E2_SymbolRegistry* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    zT_6E8D187B_ModuleEntry* zT_186;
    zT_6E8D187B_ModuleEntry zT_187;
    zT_D7876732_Opt_823 zT_189 = {0};
    unsigned char zT_190;
    zT_3C598AEF_SymbolKind zT_192;
    zT_3D7259E2_SymbolRegistry* zT_198;
    unsigned int zT_199;
    unsigned int zT_200;
    zT_6E8D187B_ModuleEntry* zT_202;
    zT_6E8D187B_ModuleEntry zT_203;
    zT_6B0A7D14_AstStore* zT_205;
    unsigned int zT_206;
    unsigned int* zT_208;
    unsigned int zT_210 = 0;
    zT_D7876732_Opt_823 zT_211 = {0};
    unsigned char zT_212;
    zT_3C598AEF_SymbolKind zT_214;
    unsigned char zT_222;
    zT_8EED1867_ResolvedTypeTable* zT_224;
    unsigned int zT_225;
    unsigned int* zT_227;
    zT_BAEE192E_Opt_10 zT_229 = {0};
    int zT_232;
    int zT_235;
    int zT_238;
    unsigned char zT_239;
    zT_8EED1867_ResolvedTypeTable* zT_241;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned int* zT_245;
    int zT_249;
    unsigned int zT_250;
    zT_8EED1867_ResolvedTypeTable* zT_254;
    unsigned int zT_255;
    zT_BAEE192E_Opt_10 zT_258 = {0};
    unsigned char zT_259;
    zT_8EED1867_ResolvedTypeTable* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    int zT_270;
    int zT_273;
    int zT_276;
    zT_6B0A7D14_AstStore* zT_280;
    unsigned int zT_281;
    unsigned int* zT_283;
    unsigned int zT_285 = 0;
    zT_3D7259E2_SymbolRegistry* zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    zT_6E8D187B_ModuleEntry* zT_291;
    zT_6E8D187B_ModuleEntry zT_292;
    zT_D7876732_Opt_823 zT_294 = {0};
    unsigned char zT_295;
    unsigned int zT_297;
    unsigned char zT_300;
    int zT_301;
    unsigned int zT_302;
    int zT_303;
    unsigned int zT_304;
    int zT_307;
    unsigned int zT_308;
    zT_3E40CD83_Sand* zT_309;
    unsigned int bound;
    unsigned int iter;
    unsigned char changed;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    unsigned int rtype;
    zT_22A7C88B_AstNode init;
    unsigned int init_type;
    zT_BAEE192E_Opt_10 vd_existing;
    zT_79FAE712_u64 ck;
    unsigned int ref_name;
    zT_D7876732_Opt_823 ref_sym;
    zT_3A105EF1_Symbol* rs;
    zT_D7876732_Opt_823 own_sym;
    zT_3A105EF1_Symbol* os;
    zT_BAEE192E_Opt_10 mdt2;
    unsigned int mt2;
    unsigned int name_id;
    zT_D7876732_Opt_823 sym;
    zT_3A105EF1_Symbol* s;
    zT_1 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_1);
    zT_4 = ct;
    zT_5 = zF_5DF8AD5B_countUntypedGlobals(zT_4);
    zT_7 = zT_5 + (unsigned int)(1);
    bound = zT_7;
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    iter = zT_10;
    goto z_bb_1;
    z_bb_1:
    if ((int)(iter < bound)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = 0;
    changed = zT_13;
    zT_15 = ct->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_5;
    z_bb_3:
    zT_309 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_309);
    return;
    z_bb_4:
    zT_307 = 1;
    zT_308 = iter + zT_307;
    iter = zT_308;
    goto z_bb_1;
    z_bb_5:
    zT_22 = mods.len;
    if ((int)(mi < zT_22)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_24 = ct->scratch;
    zF_F1B3F8C2_sandReset(zT_24);
    zT_27 = mods.ptr;
    zT_28 = zT_27[mi];
    zT_29 = zT_28.ast_root;
    ast_root = zT_29;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    if ((int)(changed == (unsigned char)(0))) goto z_bb_75; else goto z_bb_76;
    z_bb_8:
    zT_303 = 1;
    zT_304 = mi + zT_303;
    mi = zT_304;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_33 = ct->store;
    zT_34 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    zT_38 = ct->store;
    zT_39 = ast_root;
    zT_41 = zF_850FDF81_astStoreNodeExtraCh(zT_38, zT_39);
    decls = zT_41;
    zT_43 = mods.ptr;
    zT_44 = zT_43[mi];
    zT_45 = zT_44.source_file_id;
    src_fid = zT_45;
    zT_47 = ct->scratch;
    zT_48 = ct->resolved_types;
    zT_49 = ct->diag;
    zT_50 = ct->typereg;
    zT_51 = ct->symbol_reg;
    zT_52 = ct->store;
    zT_68 = mods.ptr;
    zT_69 = zT_68[mi];
    zT_53 = zT_69.id;
    zT_54 = src_fid;
    zT_55 = ct->coercion_table;
    zT_56 = ct->enum_value_table;
    zT_57 = ct->error_code_registry;
    zT_58 = ct->interner;
    zT_59 = ct->call_arg_types;
    zT_60 = ct->call_param_map;
    zT_61 = ct->module_reg;
    zT_78 = zF_84ADA681_semanticAnalyzerIni(zT_47, zT_48, zT_49, zT_50, zT_51, zT_52, zT_53, zT_54, zT_55, zT_56, zT_57, zT_58, zT_59, zT_60, zT_61);
    sa = zT_78;
    zT_80 = 0;
    zT_81 = (unsigned int)zT_80;
    di = zT_81;
    goto z_bb_11;
    z_bb_11:
    zT_83 = decls.len;
    if ((int)(di < zT_83)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_86 = ct->store;
    zT_89 = decls.ptr;
    zT_87 = zT_89[di];
    zT_91 = zF_FCDD1D35_astStoreNodeAt(zT_86, zT_87);
    decl = zT_91;
    zT_92 = decl.kind;
    if ((int)(zT_92 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    zT_301 = 1;
    zT_302 = di + zT_301;
    di = zT_302;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    zT_97 = decl.child_0;
    if ((int)(zT_97 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_101 = ct;
    zT_104 = mods.ptr;
    zT_105 = zT_104[mi];
    zT_102 = zT_105.id;
    zT_103 = decl.child_0;
    zT_108 = zF_EE3AA0D0_resolveTypeExpr(zT_101, zT_102, zT_103);
    rtype = zT_108;
    if ((int)(rtype != (unsigned int)(18))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_122 = decl.child_1;
    if ((int)(zT_122 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_111 = ct->resolved_types;
    zT_112 = decl.child_0;
    zT_113 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_111, zT_112, zT_113);
    zT_116 = ct->resolved_types;
    zT_120 = decls.ptr;
    zT_117 = zT_120[di];
    zT_118 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_116, zT_117, zT_118);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_126 = ct->store;
    zT_127 = decl.child_1;
    zT_130 = zF_FCDD1D35_astStoreNodeAt(zT_126, zT_127);
    init = zT_130;
    zT_131 = init.kind;
    if ((int)(zT_131 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_14;
    z_bb_23:
    zT_137 = init.kind;
    zT_136 = zT_137 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_25;
    z_bb_24:
    zT_136 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_136) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_143 = &sa;
    zT_146 = decls.ptr;
    zT_144 = zT_146[di];
    zT_148 = zF_CC4377FA_semanticAnalyzerRes(zT_143, zT_144);
    init_type = zT_148;
    zT_149 = init.kind;
    if ((int)(zT_149 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    if ((int)(init_type != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_224 = ct->resolved_types;
    zT_227 = decls.ptr;
    zT_225 = zT_227[di];
    zT_229 = zF_999DCF51_resolvedTypeTableGe(zT_224, zT_225);
    vd_existing = zT_229;
    if ((int)(init_type != (unsigned int)(1))) goto z_bb_40; else goto z_bb_41;
    z_bb_30:
    zT_157 = mods.ptr;
    zT_158 = zT_157[mi];
    zT_159 = zT_158.id;
    zT_163 = ct->store;
    zT_166 = decls.ptr;
    zT_164 = zT_166[di];
    zT_168 = zF_8BA26B9E_astStoreNodePayload(zT_163, zT_164);
    zT_170 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_159) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_168);
    ck = zT_170;
    zT_171 = ct->typereg;
    zT_172 = ck;
    zT_173 = init_type;
    zF_5E95558D_nameCachePut(zT_171, zT_172, zT_173);
    goto z_bb_31;
    z_bb_31:
    zT_176 = ct->store;
    zT_177 = decl.child_1;
    zT_180 = zF_53458827_astStoreIdentifier(zT_176, zT_177);
    ref_name = zT_180;
    zT_182 = ct->symbol_reg;
    zT_186 = mods.ptr;
    zT_187 = zT_186[mi];
    zT_183 = zT_187.id;
    zT_184 = ref_name;
    zT_189 = zF_A398987E_symbolRegistryQuali(zT_182, zT_183, zT_184);
    ref_sym = zT_189;
    zT_190 = ref_sym.has_value;
    if (zT_190) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    rs = ref_sym.value;
    zT_192 = rs->kind;
    if ((int)(zT_192 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    zT_198 = ct->symbol_reg;
    zT_202 = mods.ptr;
    zT_203 = zT_202[mi];
    zT_199 = zT_203.id;
    zT_205 = ct->store;
    zT_208 = decls.ptr;
    zT_206 = zT_208[di];
    zT_210 = zF_8BA26B9E_astStoreNodePayload(zT_205, zT_206);
    zT_200 = zT_210;
    zT_211 = zF_A398987E_symbolRegistryQuali(zT_198, zT_199, zT_200);
    own_sym = zT_211;
    zT_212 = own_sym.has_value;
    if (zT_212) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    os = own_sym.value;
    zT_214 = os->kind;
    if ((int)(zT_214 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    os->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_222 = 1;
    changed = zT_222;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    zT_232 = init_type != (unsigned int)(18);
    goto z_bb_42;
    z_bb_41:
    zT_232 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_232) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_235 = init_type != (unsigned int)(20);
    goto z_bb_45;
    z_bb_44:
    zT_235 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_235) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_239 = vd_existing.has_value;
    zT_238 = !zT_239;
    goto z_bb_48;
    z_bb_47:
    zT_238 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_238) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_241 = ct->resolved_types;
    zT_245 = decls.ptr;
    zT_242 = zT_245[di];
    zT_243 = init_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_241, zT_242, zT_243);
    goto z_bb_50;
    z_bb_50:
    if ((int)(init_type == (unsigned int)(19))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_250 = decl.child_0;
    zT_249 = zT_250 != (unsigned int)(0);
    goto z_bb_53;
    z_bb_52:
    zT_249 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_249) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_254 = ct->resolved_types;
    zT_255 = decl.child_0;
    zT_258 = zF_999DCF51_resolvedTypeTableGe(zT_254, zT_255);
    mdt2 = zT_258;
    zT_259 = mdt2.has_value;
    if (zT_259) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if ((int)(init_type != (unsigned int)(0))) goto z_bb_60; else goto z_bb_61;
    z_bb_56:
    mt2 = mdt2.value;
    if ((int)(mt2 != (unsigned int)(18))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    goto z_bb_55;
    z_bb_58:
    zT_263 = ct->resolved_types;
    zT_264 = decl.child_1;
    zT_265 = mt2;
    zF_19B4A07D_resolvedTypeTableSe(zT_263, zT_264, zT_265);
    goto z_bb_59;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    zT_270 = init_type != (unsigned int)(1);
    goto z_bb_62;
    z_bb_61:
    zT_270 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_270) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_273 = init_type != (unsigned int)(18);
    goto z_bb_65;
    z_bb_64:
    zT_273 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_273) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_276 = init_type != (unsigned int)(20);
    goto z_bb_68;
    z_bb_67:
    zT_276 = 0;
    goto z_bb_68;
    z_bb_68:
    if (zT_276) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_280 = ct->store;
    zT_283 = decls.ptr;
    zT_281 = zT_283[di];
    zT_285 = zF_8BA26B9E_astStoreNodePayload(zT_280, zT_281);
    name_id = zT_285;
    zT_287 = ct->symbol_reg;
    zT_291 = mods.ptr;
    zT_292 = zT_291[mi];
    zT_288 = zT_292.id;
    zT_289 = name_id;
    zT_294 = zF_A398987E_symbolRegistryQuali(zT_287, zT_288, zT_289);
    sym = zT_294;
    zT_295 = sym.has_value;
    if (zT_295) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    goto z_bb_27;
    z_bb_71:
    s = sym.value;
    zT_297 = s->type_id;
    if ((int)(zT_297 == (unsigned int)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    goto z_bb_70;
    z_bb_73:
    s->type_id = init_type;
    zT_300 = 1;
    changed = zT_300;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_72;
    z_bb_75:
    goto z_bb_3;
    z_bb_76:
    goto z_bb_4;
}

/* resolveStmtTypes */
void zF_783226DA_resolveStmtTypes(zT_6DCFC8DB_FrontResCtx* ct, unsigned int module_id, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    unsigned int zT_16;
    int zT_17;
    zT_6DCFC8DB_FrontResCtx* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8EED1867_ResolvedTypeTable* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_8143F551_AstKind zT_36;
    int zT_41;
    zT_8143F551_AstKind zT_42;
    int zT_47;
    zT_8143F551_AstKind zT_48;
    unsigned int zT_53;
    int zT_54;
    zT_6DCFC8DB_FrontResCtx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_61 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_8143F551_AstKind zT_69;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_78 = {0};
    int zT_80;
    unsigned int zT_81;
    unsigned int zT_83;
    zT_6DCFC8DB_FrontResCtx* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int* zT_89;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_97;
    zT_8143F551_AstKind zT_98;
    unsigned int zT_103;
    int zT_104;
    zT_6DCFC8DB_FrontResCtx* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_111;
    int zT_112;
    zT_6DCFC8DB_FrontResCtx* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_22A7C88B_AstNode node;
    unsigned int rtype;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int di;
    unsigned int cd;
    if ((int)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = ct->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((int)(zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = node.child_0;
    zT_17 = 0;
    if ((int)(zT_16 != (unsigned int)zT_17)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_36 = node.kind;
    if ((int)(zT_36 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_10; else goto z_bb_9;
    z_bb_5:
    zT_20 = ct;
    zT_21 = module_id;
    zT_22 = node.child_0;
    zT_24 = zF_EE3AA0D0_resolveTypeExpr(zT_20, zT_21, zT_22);
    rtype = zT_24;
    if ((int)(rtype != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_27 = ct->resolved_types;
    zT_28 = node.child_0;
    zT_29 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_27, zT_28, zT_29);
    zT_32 = ct->resolved_types;
    zT_33 = node_idx;
    zT_34 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_32, zT_33, zT_34);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_42 = node.kind;
    zT_41 = zT_42 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init);
    goto z_bb_11;
    z_bb_10:
    zT_41 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_41) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_48 = node.kind;
    zT_47 = zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_14;
    z_bb_13:
    zT_47 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_47) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_53 = node.child_0;
    zT_54 = 0;
    if ((int)(zT_53 != (unsigned int)zT_54)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = node.kind;
    if ((int)(zT_69 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_21; else goto z_bb_22;
    z_bb_17:
    zT_57 = ct;
    zT_58 = module_id;
    zT_59 = node.child_0;
    zT_61 = zF_EE3AA0D0_resolveTypeExpr(zT_57, zT_58, zT_59);
    rtype = zT_61;
    if ((int)(rtype != (unsigned int)(18))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_64 = ct->resolved_types;
    zT_65 = node.child_0;
    zT_66 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_64, zT_65, zT_66);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_75 = ct->store;
    zT_76 = node_idx;
    zT_78 = zF_850FDF81_astStoreNodeExtraCh(zT_75, zT_76);
    decls = zT_78;
    zT_80 = 0;
    zT_81 = (unsigned int)zT_80;
    di = zT_81;
    goto z_bb_23;
    z_bb_22:
    zT_97 = depth + (unsigned int)(1);
    cd = zT_97;
    zT_98 = node.kind;
    if ((int)(zT_98 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_27; else goto z_bb_28;
    z_bb_23:
    zT_83 = decls.len;
    if ((int)(di < zT_83)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_85 = ct;
    zT_86 = module_id;
    zT_89 = decls.ptr;
    zT_87 = zT_89[di];
    zF_783226DA_resolveStmtTypes(zT_85, zT_86, zT_87, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_26;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_93 = 1;
    zT_94 = di + zT_93;
    di = zT_94;
    goto z_bb_23;
    z_bb_27:
    zT_103 = node.child_0;
    zT_104 = 0;
    if ((int)(zT_103 != (unsigned int)zT_104)) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    return;
    z_bb_29:
    zT_106 = ct;
    zT_107 = module_id;
    zT_108 = node.child_0;
    zT_109 = cd;
    zF_783226DA_resolveStmtTypes(zT_106, zT_107, zT_108, zT_109);
    goto z_bb_30;
    z_bb_30:
    zT_111 = node.child_1;
    zT_112 = 0;
    if ((int)(zT_111 != (unsigned int)zT_112)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_114 = ct;
    zT_115 = module_id;
    zT_116 = node.child_1;
    zT_117 = cd;
    zF_783226DA_resolveStmtTypes(zT_114, zT_115, zT_116, zT_117);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_28;
}

/* __module_init */
void zF_780653D2___module_init_20(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_F85C5DED_DiagnosticCollector zT_2 = {0};
    zT_8143F551_AstKind zT_3 = 0;
    zT_6B0A7D14_AstStore zT_4 = {0};
    zT_072B53A6_ModuleRegistry zT_5 = {0};
    zT_3D7259E2_SymbolRegistry zT_6 = {0};
    zT_338B7C76_TypeRegistry zT_7 = {0};
    zT_8EED1867_ResolvedTypeTable zT_8 = {0};
    zT_66E7D2EF_CoercionTable zT_9 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_F85C5DED_DiagnosticCollector = zT_2;
    zG_8143F551_AstKind = zT_3;
    zG_6B0A7D14_AstStore = zT_4;
    zG_072B53A6_ModuleRegistry = zT_5;
    zG_3D7259E2_SymbolRegistry = zT_6;
    zG_338B7C76_TypeRegistry = zT_7;
    zG_8EED1867_ResolvedTypeTable = zT_8;
    zG_66E7D2EF_CoercionTable = zT_9;
    return;
}

/* EOF */
