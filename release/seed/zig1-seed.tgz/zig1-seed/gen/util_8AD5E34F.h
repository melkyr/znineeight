#ifndef ZIG_MODULE_UTIL_8AD5E34F_H
#define ZIG_MODULE_UTIL_8AD5E34F_H

#include "zig_compat.h"
#include "zig_special_types.h"


/* Forward declarations */
unsigned int zF_C98F4557_min(unsigned int, unsigned int);
unsigned int zF_D7A2E319_max(unsigned int, unsigned int);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_UTIL_8AD5E34F_H */
