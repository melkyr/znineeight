#ifndef ZIG_MODULE_RESOLVED_TYPE_TABLE_5F22E794_H
#define ZIG_MODULE_RESOLVED_TYPE_TABLE_5F22E794_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "type_registry_8EE489B8.h"
#include "panic_CE239B25.h"
#include "hash_02AFCD13.h"
#include "spill_store_AC8E76BA.h"


/* Forward declarations */
zT_8EED1867_ResolvedTypeTable zF_8D0F00B1_resolvedTypeTableIn(zT_3E40CD83_Sand*);
void zF_7238A436_resolvedTypeTableSe(zT_8EED1867_ResolvedTypeTable*, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_1CE20124_rttAlignedNodes(unsigned int);
void zF_01066AE9_rttOpenSpill(zT_8EED1867_ResolvedTypeTable*);
void zF_C592EFE9_rttExtend(zT_8EED1867_ResolvedTypeTable*, unsigned int);
void zF_79C87F6B_rttEnsureCache(zT_8EED1867_ResolvedTypeTable*);
unsigned char* zF_8D0C78B6_rttSlotBuf(zT_8EED1867_ResolvedTypeTable*, unsigned int);
unsigned int zF_5D06B445_rttResidentSlot(zT_8EED1867_ResolvedTypeTable*, unsigned int);
void zF_2C4861F7_rttWriteBack(zT_8EED1867_ResolvedTypeTable*, unsigned int);
unsigned int zF_41F8466C_rttBlockEnsure(zT_8EED1867_ResolvedTypeTable*, unsigned int);
unsigned int zF_AD4FEE31_rttReadU32(unsigned char*, unsigned int);
void zF_CEEF106E_rttWriteU32(unsigned char*, unsigned int, unsigned int);
void zF_75224871_resolvedTypeTableRe(zT_8EED1867_ResolvedTypeTable*, unsigned int);
void zF_19B4A07D_resolvedTypeTableSe(zT_8EED1867_ResolvedTypeTable*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_999DCF51_resolvedTypeTableGe(zT_8EED1867_ResolvedTypeTable*, unsigned int);
void zF_D976B454_resolvedSourceTable(zT_8EED1867_ResolvedTypeTable*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_F45AE288_resolvedSourceTable(zT_8EED1867_ResolvedTypeTable*, unsigned int);
void zF_5209815D_resolvedTypeTableCl(zT_8EED1867_ResolvedTypeTable*);
void zF_780653D2___module_init_14(void);
/* Storage globals (extern decls) */
extern zT_8EED1867_ResolvedTypeTable zG_8EED1867_ResolvedTypeTable;
extern unsigned char* zG_82B6E276_WRITE_MODE_1;

#endif /* ZIG_MODULE_RESOLVED_TYPE_TABLE_5F22E794_H */
