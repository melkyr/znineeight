#include "semantic_analyzer_4DBE89E5.h"
/* semanticAnalyzerInit */
zT_38C12417_SemanticAnalyzer zF_84ADA681_semanticAnalyzerIni(zT_3E40CD83_Sand* alloc, zT_8EED1867_ResolvedTypeTable* type_table, zT_F85C5DED_DiagnosticCollector* diag, zT_338B7C76_TypeRegistry* registry, zT_3D7259E2_SymbolRegistry* symbols, zT_6B0A7D14_AstStore* store, unsigned int module_id, unsigned int source_file_id, zT_66E7D2EF_CoercionTable* coercion_tab, zT_21D3708C_U32ToU32Map* enum_val_tab, zT_21D3708C_U32ToU32Map* error_code_reg, zT_D3EB6303_StringInterner* interner, zT_21D3708C_U32ToU32Map* cal_typs, zT_21D3708C_U32ToU32Map* cp_map, zT_072B53A6_ModuleRegistry* module_reg, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_D3EB6303_StringInterner* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23 = 0;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31 = 0;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39 = 0;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_D3EB6303_StringInterner* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_D3EB6303_StringInterner* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63 = 0;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71 = 0;
    unsigned char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_D3EB6303_StringInterner* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79 = 0;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_D3EB6303_StringInterner* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_D3EB6303_StringInterner* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95 = 0;
    unsigned char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_D3EB6303_StringInterner* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_D3EB6303_StringInterner* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111 = 0;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_D3EB6303_StringInterner* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119 = 0;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_D3EB6303_StringInterner* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127 = 0;
    unsigned char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_D3EB6303_StringInterner* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135 = 0;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_D3EB6303_StringInterner* zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned int zT_143 = 0;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_D3EB6303_StringInterner* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151 = 0;
    unsigned char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_D3EB6303_StringInterner* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159 = 0;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_D3EB6303_StringInterner* zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167 = 0;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_D3EB6303_StringInterner* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175 = 0;
    unsigned char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_D3EB6303_StringInterner* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183 = 0;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_D3EB6303_StringInterner* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191 = 0;
    unsigned char* zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    zT_D3EB6303_StringInterner* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199 = 0;
    unsigned char* zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    zT_D3EB6303_StringInterner* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207 = 0;
    unsigned char* zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    zT_D3EB6303_StringInterner* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215 = 0;
    unsigned char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_D3EB6303_StringInterner* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned int zT_223 = 0;
    unsigned char* zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_D3EB6303_StringInterner* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    unsigned int zT_231 = 0;
    unsigned char* zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    zT_D3EB6303_StringInterner* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239 = 0;
    unsigned char* zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243;
    zT_D3EB6303_StringInterner* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247 = 0;
    unsigned char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_D3EB6303_StringInterner* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255 = 0;
    unsigned char* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_259;
    zT_D3EB6303_StringInterner* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263 = 0;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_D3EB6303_StringInterner* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned int zT_271 = 0;
    unsigned char* zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_D3EB6303_StringInterner* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned int zT_279 = 0;
    unsigned char* zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    zT_D3EB6303_StringInterner* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287 = 0;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_D3EB6303_StringInterner* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned int zT_295 = 0;
    zT_38C12417_SemanticAnalyzer zT_296;
    int zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    int zT_310;
    int zT_311;
    int zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_3E40CD83_Sand* zT_315;
    zT_E2DF2801_LocalConstScope zT_316 = {0};
    zT_3E40CD83_Sand* zT_317;
    zT_C8A278E4_LocalTypeScope zT_318 = {0};
    int zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    int zT_322;
    int zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    int zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned char zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_text;
    unsigned int und_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_text;
    unsigned int pc_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pti_s;
    unsigned int ptin_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u itp_s;
    unsigned int itp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifp_s;
    unsigned int ifp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_s;
    unsigned int pfi_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpp_s;
    unsigned int fpp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc_s;
    unsigned int vc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_s;
    unsigned int bc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_s;
    unsigned int ic_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_s;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u if_s;
    unsigned int if_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ie_s;
    unsigned int ie_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u e2i_s;
    unsigned int e2i_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u as_s;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u so_s;
    unsigned int so_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ao_s;
    unsigned int ao_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u oo_s;
    unsigned int oo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bso_s;
    unsigned int bso_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u boo_s;
    unsigned int boo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc2_s;
    unsigned int pc2_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sow_s;
    unsigned int sow_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sew_s;
    unsigned int sew_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u gc_s;
    unsigned int gc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ex_s;
    unsigned int ex_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_s;
    unsigned int pn_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm_s;
    unsigned int sm_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u iw_s;
    unsigned int iw_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_s;
    unsigned int cc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cg_s;
    unsigned int cg_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u csc_s;
    unsigned int csc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u afs_s;
    unsigned int afs_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_s;
    unsigned int ain_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ars_s;
    unsigned int ars_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_s;
    unsigned int asu_id;
    zT_17 = "_";
    zT_19 = 1;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    und_text = zT_18;
    zT_21 = interner;
    zT_22 = und_text;
    zT_23 = zF_50C274AF_stringInternerInter(zT_21, zT_22);
    und_name_id = zT_23;
    zT_25 = "@ptrCast";
    zT_27 = 8;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    pc_text = zT_26;
    zT_29 = interner;
    zT_30 = pc_text;
    zT_31 = zF_50C274AF_stringInternerInter(zT_29, zT_30);
    pc_name_id = zT_31;
    zT_33 = "@ptrToInt";
    zT_35 = 9;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    pti_s = zT_34;
    zT_37 = interner;
    zT_38 = pti_s;
    zT_39 = zF_50C274AF_stringInternerInter(zT_37, zT_38);
    ptin_id = zT_39;
    zT_41 = "@intToPtr";
    zT_43 = 9;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    itp_s = zT_42;
    zT_45 = interner;
    zT_46 = itp_s;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    itp_id = zT_47;
    zT_49 = "@intFromPtr";
    zT_51 = 11;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    ifp_s = zT_50;
    zT_53 = interner;
    zT_54 = ifp_s;
    zT_55 = zF_50C274AF_stringInternerInter(zT_53, zT_54);
    ifp_id = zT_55;
    zT_57 = "@ptrFromInt";
    zT_59 = 11;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    pfi_s = zT_58;
    zT_61 = interner;
    zT_62 = pfi_s;
    zT_63 = zF_50C274AF_stringInternerInter(zT_61, zT_62);
    pfi_id = zT_63;
    zT_65 = "@fieldParentPtr";
    zT_67 = 15;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    fpp_s = zT_66;
    zT_69 = interner;
    zT_70 = fpp_s;
    zT_71 = zF_50C274AF_stringInternerInter(zT_69, zT_70);
    fpp_id = zT_71;
    zT_73 = "@volatileCast";
    zT_75 = 13;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    vc_s = zT_74;
    zT_77 = interner;
    zT_78 = vc_s;
    zT_79 = zF_50C274AF_stringInternerInter(zT_77, zT_78);
    vc_id = zT_79;
    zT_81 = "@bitCast";
    zT_83 = 8;
    zT_82.ptr = zT_81;
    zT_82.len = zT_83;
    bc_s = zT_82;
    zT_85 = interner;
    zT_86 = bc_s;
    zT_87 = zF_50C274AF_stringInternerInter(zT_85, zT_86);
    bc_id = zT_87;
    zT_89 = "@intCast";
    zT_91 = 8;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    ic_s = zT_90;
    zT_93 = interner;
    zT_94 = ic_s;
    zT_95 = zF_50C274AF_stringInternerInter(zT_93, zT_94);
    ic_id = zT_95;
    zT_97 = "@floatCast";
    zT_99 = 10;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    fc_s = zT_98;
    zT_101 = interner;
    zT_102 = fc_s;
    zT_103 = zF_50C274AF_stringInternerInter(zT_101, zT_102);
    fc_id = zT_103;
    zT_105 = "@intToFloat";
    zT_107 = 11;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    if_s = zT_106;
    zT_109 = interner;
    zT_110 = if_s;
    zT_111 = zF_50C274AF_stringInternerInter(zT_109, zT_110);
    if_id = zT_111;
    zT_113 = "@intToEnum";
    zT_115 = 10;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    ie_s = zT_114;
    zT_117 = interner;
    zT_118 = ie_s;
    zT_119 = zF_50C274AF_stringInternerInter(zT_117, zT_118);
    ie_id = zT_119;
    zT_121 = "@enumToInt";
    zT_123 = 10;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    e2i_s = zT_122;
    zT_125 = interner;
    zT_126 = e2i_s;
    zT_127 = zF_50C274AF_stringInternerInter(zT_125, zT_126);
    e2i_id = zT_127;
    zT_129 = "@as";
    zT_131 = 3;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    as_s = zT_130;
    zT_133 = interner;
    zT_134 = as_s;
    zT_135 = zF_50C274AF_stringInternerInter(zT_133, zT_134);
    as_id = zT_135;
    zT_137 = "@sizeOf";
    zT_139 = 7;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    so_s = zT_138;
    zT_141 = interner;
    zT_142 = so_s;
    zT_143 = zF_50C274AF_stringInternerInter(zT_141, zT_142);
    so_id = zT_143;
    zT_145 = "@alignOf";
    zT_147 = 8;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    ao_s = zT_146;
    zT_149 = interner;
    zT_150 = ao_s;
    zT_151 = zF_50C274AF_stringInternerInter(zT_149, zT_150);
    ao_id = zT_151;
    zT_153 = "@offsetOf";
    zT_155 = 9;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    oo_s = zT_154;
    zT_157 = interner;
    zT_158 = oo_s;
    zT_159 = zF_50C274AF_stringInternerInter(zT_157, zT_158);
    oo_id = zT_159;
    zT_161 = "@bitSizeOf";
    zT_163 = 10;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    bso_s = zT_162;
    zT_165 = interner;
    zT_166 = bso_s;
    zT_167 = zF_50C274AF_stringInternerInter(zT_165, zT_166);
    bso_id = zT_167;
    zT_169 = "@bitOffsetOf";
    zT_171 = 12;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    boo_s = zT_170;
    zT_173 = interner;
    zT_174 = boo_s;
    zT_175 = zF_50C274AF_stringInternerInter(zT_173, zT_174);
    boo_id = zT_175;
    zT_177 = "@putChar";
    zT_179 = 8;
    zT_178.ptr = zT_177;
    zT_178.len = zT_179;
    pc2_s = zT_178;
    zT_181 = interner;
    zT_182 = pc2_s;
    zT_183 = zF_50C274AF_stringInternerInter(zT_181, zT_182);
    pc2_id = zT_183;
    zT_185 = "@stdoutWrite";
    zT_187 = 12;
    zT_186.ptr = zT_185;
    zT_186.len = zT_187;
    sow_s = zT_186;
    zT_189 = interner;
    zT_190 = sow_s;
    zT_191 = zF_50C274AF_stringInternerInter(zT_189, zT_190);
    sow_id = zT_191;
    zT_193 = "@stderrWrite";
    zT_195 = 12;
    zT_194.ptr = zT_193;
    zT_194.len = zT_195;
    sew_s = zT_194;
    zT_197 = interner;
    zT_198 = sew_s;
    zT_199 = zF_50C274AF_stringInternerInter(zT_197, zT_198);
    sew_id = zT_199;
    zT_201 = "@getChar";
    zT_203 = 8;
    zT_202.ptr = zT_201;
    zT_202.len = zT_203;
    gc_s = zT_202;
    zT_205 = interner;
    zT_206 = gc_s;
    zT_207 = zF_50C274AF_stringInternerInter(zT_205, zT_206);
    gc_id = zT_207;
    zT_209 = "@exit";
    zT_211 = 5;
    zT_210.ptr = zT_209;
    zT_210.len = zT_211;
    ex_s = zT_210;
    zT_213 = interner;
    zT_214 = ex_s;
    zT_215 = zF_50C274AF_stringInternerInter(zT_213, zT_214);
    ex_id = zT_215;
    zT_217 = "@panic";
    zT_219 = 6;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    pn_s = zT_218;
    zT_221 = interner;
    zT_222 = pn_s;
    zT_223 = zF_50C274AF_stringInternerInter(zT_221, zT_222);
    pn_id = zT_223;
    zT_225 = "@sleepMs";
    zT_227 = 8;
    zT_226.ptr = zT_225;
    zT_226.len = zT_227;
    sm_s = zT_226;
    zT_229 = interner;
    zT_230 = sm_s;
    zT_231 = zF_50C274AF_stringInternerInter(zT_229, zT_230);
    sm_id = zT_231;
    zT_233 = "@isWindows";
    zT_235 = 10;
    zT_234.ptr = zT_233;
    zT_234.len = zT_235;
    iw_s = zT_234;
    zT_237 = interner;
    zT_238 = iw_s;
    zT_239 = zF_50C274AF_stringInternerInter(zT_237, zT_238);
    iw_id = zT_239;
    zT_241 = "@consoleClear";
    zT_243 = 13;
    zT_242.ptr = zT_241;
    zT_242.len = zT_243;
    cc_s = zT_242;
    zT_245 = interner;
    zT_246 = cc_s;
    zT_247 = zF_50C274AF_stringInternerInter(zT_245, zT_246);
    cc_id = zT_247;
    zT_249 = "@consoleGotoxy";
    zT_251 = 14;
    zT_250.ptr = zT_249;
    zT_250.len = zT_251;
    cg_s = zT_250;
    zT_253 = interner;
    zT_254 = cg_s;
    zT_255 = zF_50C274AF_stringInternerInter(zT_253, zT_254);
    cg_id = zT_255;
    zT_257 = "@consoleSetColor";
    zT_259 = 16;
    zT_258.ptr = zT_257;
    zT_258.len = zT_259;
    csc_s = zT_258;
    zT_261 = interner;
    zT_262 = csc_s;
    zT_263 = zF_50C274AF_stringInternerInter(zT_261, zT_262);
    csc_id = zT_263;
    zT_265 = "@asyncFrameSize";
    zT_267 = 15;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    afs_s = zT_266;
    zT_269 = interner;
    zT_270 = afs_s;
    zT_271 = zF_50C274AF_stringInternerInter(zT_269, zT_270);
    afs_id = zT_271;
    zT_273 = "@asyncInit";
    zT_275 = 10;
    zT_274.ptr = zT_273;
    zT_274.len = zT_275;
    ain_s = zT_274;
    zT_277 = interner;
    zT_278 = ain_s;
    zT_279 = zF_50C274AF_stringInternerInter(zT_277, zT_278);
    ain_id = zT_279;
    zT_281 = "@asyncResume";
    zT_283 = 12;
    zT_282.ptr = zT_281;
    zT_282.len = zT_283;
    ars_s = zT_282;
    zT_285 = interner;
    zT_286 = ars_s;
    zT_287 = zF_50C274AF_stringInternerInter(zT_285, zT_286);
    ars_id = zT_287;
    zT_289 = "@asyncSuspend";
    zT_291 = 13;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    asu_s = zT_290;
    zT_293 = interner;
    zT_294 = asu_s;
    zT_295 = zF_50C274AF_stringInternerInter(zT_293, zT_294);
    asu_id = zT_295;
    zT_296.type_table = type_table;
    zT_296.diag = diag;
    zT_296.registry = registry;
    zT_296.symbols = symbols;
    zT_296.store = store;
    zT_296.module_id = module_id;
    zT_296.source_file_id = source_file_id;
    zT_297 = 0;
    zT_296.expected_type_stack_items = (unsigned int*)zT_297;
    zT_298 = 0;
    zT_296.expected_type_stack_len = zT_298;
    zT_299 = 0;
    zT_296.expected_type_stack_cap = zT_299;
    zT_296.expected_type_stack_alloc = alloc;
    zT_300 = 0;
    zT_296.stmt_work_items = (unsigned int*)zT_300;
    zT_301 = 0;
    zT_296.stmt_work_len = zT_301;
    zT_302 = 0;
    zT_296.stmt_work_cap = zT_302;
    zT_303 = 0;
    zT_296.current_fn_return = zT_303;
    zT_304 = 0;
    zT_296.current_fn_name = zT_304;
    zT_296.coercion_table = coercion_tab;
    zT_296.enum_value_table = enum_val_tab;
    zT_296.error_code_registry = error_code_reg;
    zT_305 = 0;
    zT_296.current_switch_cond_tu = zT_305;
    zT_306 = 0;
    zT_296.switch_depth = zT_306;
    zT_307 = 0;
    zT_296.defer_depth = zT_307;
    zT_308 = 0;
    zT_296.defer_inner_loops = zT_308;
    zT_309 = 0;
    zT_296.defer_label_len = zT_309;
    zT_310 = 0;
    zT_296.local_decl_names = (unsigned int*)zT_310;
    zT_311 = 0;
    zT_296.local_decl_types = (unsigned int*)zT_311;
    zT_312 = 0;
    zT_296.local_decl_consts = (unsigned char*)zT_312;
    zT_313 = 0;
    zT_296.local_decl_count = zT_313;
    zT_314 = 0;
    zT_296.local_decl_cap = zT_314;
    zT_296.discard_name_id = und_name_id;
    zT_315 = alloc;
    zT_316 = zF_F5EBC2FF_localConstScopeInit(zT_315);
    zT_296.local_consts = zT_316;
    zT_317 = alloc;
    zT_318 = zF_8A85AA66_localTypeScopeInit(zT_317);
    zT_296.local_types = zT_318;
    zT_319 = 0;
    zT_296.packed_gate_items = (unsigned int*)zT_319;
    zT_320 = 0;
    zT_296.packed_gate_len = zT_320;
    zT_321 = 0;
    zT_296.packed_gate_cap = zT_321;
    zT_322 = 0;
    zT_296.packed_struct_tids = (unsigned int*)zT_322;
    zT_323 = 0;
    zT_296.packed_struct_decl_nodes = (unsigned int*)zT_323;
    zT_324 = 0;
    zT_296.packed_struct_cache_len = zT_324;
    zT_325 = 0;
    zT_296.packed_struct_cache_cap = zT_325;
    zT_326 = 0;
    zT_296.checked_struct_tids = (unsigned int*)zT_326;
    zT_327 = 0;
    zT_296.checked_struct_tids_len = zT_327;
    zT_328 = 0;
    zT_296.checked_struct_tids_cap = zT_328;
    zT_296._stub_0 = und_name_id;
    zT_329 = 0;
    zT_296._stub_1 = zT_329;
    zT_296.call_arg_types = cal_typs;
    zT_296.call_param_map = cp_map;
    zT_296.interner = interner;
    zT_296.ptrcast_name_id = pc_name_id;
    zT_296.volatilecast_name_id = vc_id;
    zT_296.ptrtoint_name_id = ptin_id;
    zT_296.inttoptr_name_id = itp_id;
    zT_296.int_from_ptr_name_id = ifp_id;
    zT_296.ptr_from_int_name_id = pfi_id;
    zT_296.field_parent_ptr_name_id = fpp_id;
    zT_296.bitcast_name_id = bc_id;
    zT_296.intcast_name_id = ic_id;
    zT_296.floatcast_name_id = fc_id;
    zT_296.inttofloat_name_id = if_id;
    zT_296.inttoenum_name_id = ie_id;
    zT_296.enumtoint_name_id = e2i_id;
    zT_296.as_name_id = as_id;
    zT_296.size_of_name_id = so_id;
    zT_296.align_of_name_id = ao_id;
    zT_296.offset_of_name_id = oo_id;
    zT_296.bit_size_of_name_id = bso_id;
    zT_296.bit_offset_of_name_id = boo_id;
    zT_296.putchar_name_id = pc2_id;
    zT_296.stdout_write_name_id = sow_id;
    zT_296.stderr_write_name_id = sew_id;
    zT_296.getchar_name_id = gc_id;
    zT_296.exit_name_id = ex_id;
    zT_296.panic_name_id = pn_id;
    zT_296.sleep_ms_name_id = sm_id;
    zT_296.is_windows_name_id = iw_id;
    zT_296.console_clear_name_id = cc_id;
    zT_296.console_gotoxy_name_id = cg_id;
    zT_296.console_set_color_name_id = csc_id;
    zT_296.async_frame_size_name_id = afs_id;
    zT_296.async_init_name_id = ain_id;
    zT_296.async_resume_name_id = ars_id;
    zT_296.async_suspend_name_id = asu_id;
    zT_330 = 1;
    zT_296.async_analysis_ready = zT_330;
    zT_296.module_reg = module_reg;
    zT_296.suspending_fns = suspending_fns;
    return zT_296;
}

/* semanticAnalyzerIsTypeValueCast */
unsigned char zF_3757023F_semanticAnalyzerIsT(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    zT_2 = self->ptrcast_name_id;
    if ((unsigned char)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_5 = self->volatilecast_name_id;
    if ((unsigned char)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_8 = self->inttoptr_name_id;
    if ((unsigned char)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_11 = self->intcast_name_id;
    if ((unsigned char)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    zT_14 = self->floatcast_name_id;
    if ((unsigned char)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_17 = self->inttofloat_name_id;
    if ((unsigned char)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_20 = self->inttoenum_name_id;
    if ((unsigned char)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    zT_23 = self->as_name_id;
    if ((unsigned char)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    return (unsigned char)(0);
}

/* semanticAnalyzerBuiltinNameEq */
unsigned char zF_2ACB4E23_semanticAnalyzerBui(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, zT_8F083A69_Slice_zT_0B42B2F8_u lit) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_20;
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned char zT_23;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    unsigned int ci;
    zT_4 = self->interner;
    zT_5 = name_id;
    zT_7 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    nm = zT_7;
    zT_9 = nm.len;
    zT_11 = lit.len;
    if ((unsigned char)(zT_9 != zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    ci = zT_16;
    goto z_bb_3;
    z_bb_3:
    zT_18 = nm.len;
    if ((unsigned char)(ci < zT_18)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = nm.ptr;
    zT_21 = zT_20[ci];
    zT_22 = lit.ptr;
    zT_23 = zT_22[ci];
    if ((unsigned char)(zT_21 != zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_27 = ci + (unsigned int)(1);
    ci = zT_27;
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    goto z_bb_6;
}

/* semanticAnalyzerIsBuiltinSupported */
unsigned char zF_CAF1FD28_semanticAnalyzerIsB(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_44;
    unsigned int zT_47;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_59;
    unsigned int zT_62;
    unsigned int zT_65;
    unsigned int zT_68;
    unsigned int zT_71;
    unsigned int zT_74;
    unsigned int zT_77;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned int zT_86;
    unsigned int zT_89;
    unsigned int zT_92;
    unsigned int zT_95;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_38C12417_SemanticAnalyzer* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned char zT_105 = 0;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_38C12417_SemanticAnalyzer* zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned char zT_114 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_38C12417_SemanticAnalyzer* zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned char zT_123 = 0;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_38C12417_SemanticAnalyzer* zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned char zT_132 = 0;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned char zT_141 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_e2i;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cvs;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cva;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cve;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_pan;
    zT_2 = self->ptrcast_name_id;
    if ((unsigned char)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_5 = self->volatilecast_name_id;
    if ((unsigned char)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_8 = self->ptrtoint_name_id;
    if ((unsigned char)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_11 = self->inttoptr_name_id;
    if ((unsigned char)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    zT_14 = self->int_from_ptr_name_id;
    if ((unsigned char)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_17 = self->ptr_from_int_name_id;
    if ((unsigned char)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_20 = self->field_parent_ptr_name_id;
    if ((unsigned char)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    zT_23 = self->bitcast_name_id;
    if ((unsigned char)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    zT_26 = self->intcast_name_id;
    if ((unsigned char)(name_id == zT_26)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    zT_29 = self->floatcast_name_id;
    if ((unsigned char)(name_id == zT_29)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    zT_32 = self->inttofloat_name_id;
    if ((unsigned char)(name_id == zT_32)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    zT_35 = self->inttoenum_name_id;
    if ((unsigned char)(name_id == zT_35)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    zT_38 = self->as_name_id;
    if ((unsigned char)(name_id == zT_38)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    zT_41 = self->size_of_name_id;
    if ((unsigned char)(name_id == zT_41)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    zT_44 = self->align_of_name_id;
    if ((unsigned char)(name_id == zT_44)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (unsigned char)(1);
    z_bb_30:
    zT_47 = self->offset_of_name_id;
    if ((unsigned char)(name_id == zT_47)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return (unsigned char)(1);
    z_bb_32:
    zT_50 = self->bit_size_of_name_id;
    if ((unsigned char)(name_id == zT_50)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned char)(1);
    z_bb_34:
    zT_53 = self->bit_offset_of_name_id;
    if ((unsigned char)(name_id == zT_53)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned char)(1);
    z_bb_36:
    zT_56 = self->putchar_name_id;
    if ((unsigned char)(name_id == zT_56)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    zT_59 = self->stdout_write_name_id;
    if ((unsigned char)(name_id == zT_59)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned char)(1);
    z_bb_40:
    zT_62 = self->stderr_write_name_id;
    if ((unsigned char)(name_id == zT_62)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (unsigned char)(1);
    z_bb_42:
    zT_65 = self->getchar_name_id;
    if ((unsigned char)(name_id == zT_65)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return (unsigned char)(1);
    z_bb_44:
    zT_68 = self->exit_name_id;
    if ((unsigned char)(name_id == zT_68)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (unsigned char)(1);
    z_bb_46:
    zT_71 = self->sleep_ms_name_id;
    if ((unsigned char)(name_id == zT_71)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned char)(1);
    z_bb_48:
    zT_74 = self->is_windows_name_id;
    if ((unsigned char)(name_id == zT_74)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return (unsigned char)(1);
    z_bb_50:
    zT_77 = self->console_clear_name_id;
    if ((unsigned char)(name_id == zT_77)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (unsigned char)(1);
    z_bb_52:
    zT_80 = self->console_gotoxy_name_id;
    if ((unsigned char)(name_id == zT_80)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return (unsigned char)(1);
    z_bb_54:
    zT_83 = self->console_set_color_name_id;
    if ((unsigned char)(name_id == zT_83)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (unsigned char)(1);
    z_bb_56:
    zT_86 = self->async_frame_size_name_id;
    if ((unsigned char)(name_id == zT_86)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned char)(1);
    z_bb_58:
    zT_89 = self->async_init_name_id;
    if ((unsigned char)(name_id == zT_89)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (unsigned char)(1);
    z_bb_60:
    zT_92 = self->async_resume_name_id;
    if ((unsigned char)(name_id == zT_92)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (unsigned char)(1);
    z_bb_62:
    zT_95 = self->async_suspend_name_id;
    if ((unsigned char)(name_id == zT_95)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (unsigned char)(1);
    z_bb_64:
    zT_99 = "@enumToInt";
    zT_101 = 10;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    l_e2i = zT_100;
    zT_102 = self;
    zT_103 = name_id;
    zT_104 = l_e2i;
    zT_105 = zF_2ACB4E23_semanticAnalyzerBui(zT_102, zT_103, zT_104);
    if (zT_105) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    return (unsigned char)(1);
    z_bb_66:
    zT_108 = "@cVaStart";
    zT_110 = 9;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    l_cvs = zT_109;
    zT_111 = self;
    zT_112 = name_id;
    zT_113 = l_cvs;
    zT_114 = zF_2ACB4E23_semanticAnalyzerBui(zT_111, zT_112, zT_113);
    if (zT_114) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    return (unsigned char)(1);
    z_bb_68:
    zT_117 = "@cVaArg";
    zT_119 = 7;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    l_cva = zT_118;
    zT_120 = self;
    zT_121 = name_id;
    zT_122 = l_cva;
    zT_123 = zF_2ACB4E23_semanticAnalyzerBui(zT_120, zT_121, zT_122);
    if (zT_123) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    return (unsigned char)(1);
    z_bb_70:
    zT_126 = "@cVaEnd";
    zT_128 = 7;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    l_cve = zT_127;
    zT_129 = self;
    zT_130 = name_id;
    zT_131 = l_cve;
    zT_132 = zF_2ACB4E23_semanticAnalyzerBui(zT_129, zT_130, zT_131);
    if (zT_132) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    return (unsigned char)(1);
    z_bb_72:
    zT_135 = "@panic";
    zT_137 = 6;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    l_pan = zT_136;
    zT_138 = self;
    zT_139 = name_id;
    zT_140 = l_pan;
    zT_141 = zF_2ACB4E23_semanticAnalyzerBui(zT_138, zT_139, zT_140);
    if (zT_141) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    return (unsigned char)(1);
    z_bb_74:
    return (unsigned char)(0);
}

/* semanticAnalyzerDiagAsyncOutsideSuspending */
void zF_D4D0798B_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char zT_2;
    zT_A4CE86B7_U64ToU32Map* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    zT_22A7C88B_AstNode zT_15 = {0};
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_F85C5DED_DiagnosticCollector* zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_38 = 0;
    zT_22A7C88B_AstNode a318_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u e318;
    zT_2 = self->async_analysis_ready;
    if ((unsigned char)(!zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = self->suspending_fns;
    zT_5 = self->module_id;
    zT_6 = self->current_fn_name;
    zT_10 = zF_7C7E43BF_asyncIsSuspending(zT_4, zT_5, zT_6);
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_12, zT_13);
    a318_node = zT_15;
    zT_17 = "@asyncSuspend used outside a suspending function";
    zT_19 = 48;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    e318 = zT_18;
    zT_20 = self->diag;
    zT_23 = self->source_file_id;
    zT_24 = a318_node.span_start;
    zT_34 = a318_node.span_start;
    zT_35 = a318_node.span_len;
    zT_26 = e318;
    zT_38 = zF_C82559AC_diagnosticCollector(zT_20, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3018_ASYNC_SUSPEND_OUTSIDE_SUSPENDING)), zT_23, zT_24, (unsigned int)(zT_34 + (unsigned int)((unsigned int)zT_35)), zT_26);
    (void)zT_38;
    return;
}

/* semanticAnalyzerDiagAsyncBuiltinInDefer */
void zF_2EC0CDC8_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_32 = 0;
    zT_22A7C88B_AstNode a319_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u e319;
    zT_2 = self->defer_depth;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    a319_node = zT_9;
    zT_11 = "@async builtin used inside a defer/errdefer body";
    zT_13 = 48;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    e319 = zT_12;
    zT_14 = self->diag;
    zT_17 = self->source_file_id;
    zT_18 = a319_node.span_start;
    zT_28 = a319_node.span_start;
    zT_29 = a319_node.span_len;
    zT_20 = e319;
    zT_32 = zF_C82559AC_diagnosticCollector(zT_14, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3019_ASYNC_BUILTIN_IN_DEFER)), zT_17, zT_18, (unsigned int)(zT_28 + (unsigned int)((unsigned int)zT_29)), zT_20);
    (void)zT_32;
    return;
}

/* semanticAnalyzerDiagDeferCtl */
void zF_398A7D41_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_A210EB18_ErrorCode code, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_25 = 0;
    zT_22A7C88B_AstNode node;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_9 = self->diag;
    zT_12 = self->source_file_id;
    zT_13 = node.span_start;
    zT_21 = node.span_start;
    zT_22 = node.span_len;
    zT_15 = msg;
    zT_25 = zF_C82559AC_diagnosticCollector(zT_9, (unsigned char)(0), (unsigned short)((unsigned short)code), zT_12, zT_13, (unsigned int)(zT_21 + (unsigned int)((unsigned int)zT_22)), zT_15);
    (void)zT_25;
    return;
}

/* semanticAnalyzerDeferBreakAllowed */
unsigned char zF_02E8B77C_semanticAnalyzerDef(zT_38C12417_SemanticAnalyzer* self, unsigned int label) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int* zT_11;
    unsigned int zT_12;
    unsigned int zT_16;
    unsigned int i;
    if ((unsigned char)(label == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->defer_inner_loops;
    return (unsigned char)(zT_4 > (unsigned int)(0));
    z_bb_2:
    zT_8 = 0;
    i = zT_8;
    goto z_bb_3;
    z_bb_3:
    zT_9 = self->defer_label_len;
    if ((unsigned char)(i < zT_9)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = self->defer_label_stack;
    zT_12 = zT_11[i];
    if ((unsigned char)(zT_12 == label)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_16 = i + (unsigned int)(1);
    i = zT_16;
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    goto z_bb_6;
}

/* semanticAnalyzerDeferContinueAllowed */
unsigned char zF_389B3480_semanticAnalyzerDef(zT_38C12417_SemanticAnalyzer* self, unsigned int label) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int* zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char zT_16;
    unsigned int zT_21;
    unsigned int i;
    if ((unsigned char)(label == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->defer_inner_loops;
    return (unsigned char)(zT_4 > (unsigned int)(0));
    z_bb_2:
    zT_8 = 0;
    i = zT_8;
    goto z_bb_3;
    z_bb_3:
    zT_9 = self->defer_label_len;
    if ((unsigned char)(i < zT_9)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = self->defer_label_stack;
    zT_12 = zT_11[i];
    if ((unsigned char)(zT_12 == label)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = i + (unsigned int)(1);
    i = zT_21;
    goto z_bb_3;
    z_bb_7:
    zT_15 = self->defer_label_isloop;
    zT_16 = zT_15[i];
    zT_14 = zT_16 != (unsigned char)(0);
    goto z_bb_9;
    z_bb_8:
    zT_14 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_14) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    goto z_bb_6;
}

/* semanticAnalyzerCheckDeferChildren */
void zF_0D8393D0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    unsigned char zT_9 = 0;
    unsigned char zT_10;
    zT_8143F551_AstKind zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    int zT_21;
    unsigned int zT_22;
    zT_38C12417_SemanticAnalyzer* zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_30 = 0;
    int zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_37;
    zT_8143F551_AstKind zT_38;
    unsigned char zT_42 = 0;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned char zT_49;
    zT_8143F551_AstKind zT_50;
    unsigned char zT_54 = 0;
    zT_38C12417_SemanticAnalyzer* zT_55;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned char zT_61;
    zT_8143F551_AstKind zT_62;
    unsigned char zT_66 = 0;
    zT_38C12417_SemanticAnalyzer* zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode node;
    unsigned int n;
    unsigned int i;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.kind;
    zT_9 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_7);
    if (zT_9) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = node.kind;
    zT_10 = zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call);
    goto z_bb_3;
    z_bb_2:
    zT_10 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = self->store;
    zT_17 = node_idx;
    zT_19 = zF_152E19CB_astStoreNodeExtraCh(zT_16, zT_17);
    n = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    i = zT_22;
    goto z_bb_6;
    z_bb_5:
    zT_34 = node.child_2;
    if ((unsigned char)(zT_34 != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_6:
    if ((unsigned char)(i < n)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = self;
    zT_26 = self->store;
    zT_27 = node_idx;
    zT_28 = i;
    zT_30 = zF_B10B1BC1_astStoreNodeExtraCh(zT_26, zT_27, zT_28);
    zT_25 = zT_30;
    zF_9E06A44F_semanticAnalyzerChe(zT_24, zT_25);
    goto z_bb_9;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_31 = 1;
    zT_33 = i + (unsigned int)((unsigned int)zT_31);
    i = zT_33;
    goto z_bb_6;
    z_bb_10:
    zT_38 = node.kind;
    zT_42 = zF_C395F6FD_nodeChildIsNode(zT_38, (unsigned char)(2));
    zT_37 = zT_42;
    goto z_bb_12;
    z_bb_11:
    zT_37 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_37) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_43 = self;
    zT_44 = node.child_2;
    zF_9E06A44F_semanticAnalyzerChe(zT_43, zT_44);
    goto z_bb_14;
    z_bb_14:
    zT_46 = node.child_1;
    if ((unsigned char)(zT_46 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_50 = node.kind;
    zT_54 = zF_C395F6FD_nodeChildIsNode(zT_50, (unsigned char)(1));
    zT_49 = zT_54;
    goto z_bb_17;
    z_bb_16:
    zT_49 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_49) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_55 = self;
    zT_56 = node.child_1;
    zF_9E06A44F_semanticAnalyzerChe(zT_55, zT_56);
    goto z_bb_19;
    z_bb_19:
    zT_58 = node.child_0;
    if ((unsigned char)(zT_58 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_62 = node.kind;
    zT_66 = zF_C395F6FD_nodeChildIsNode(zT_62, (unsigned char)(0));
    zT_61 = zT_66;
    goto z_bb_22;
    z_bb_21:
    zT_61 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_61) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_67 = self;
    zT_68 = node.child_0;
    zF_9E06A44F_semanticAnalyzerChe(zT_67, zT_68);
    goto z_bb_24;
    z_bb_24:
    return;
}

/* semanticAnalyzerCheckDeferBody */
void zF_9E06A44F_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned char zT_17;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    zT_38C12417_SemanticAnalyzer* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    unsigned int zT_54 = 0;
    zT_38C12417_SemanticAnalyzer* zT_55;
    unsigned int zT_56;
    unsigned char zT_57 = 0;
    unsigned char* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    zT_38C12417_SemanticAnalyzer* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_6B0A7D14_AstStore* zT_73;
    unsigned int zT_74;
    unsigned int zT_76 = 0;
    zT_38C12417_SemanticAnalyzer* zT_77;
    unsigned int zT_78;
    unsigned char zT_79 = 0;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_38C12417_SemanticAnalyzer* zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned char zT_94;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_38C12417_SemanticAnalyzer* zT_103;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_109;
    unsigned int zT_110;
    unsigned int zT_112 = 0;
    unsigned char zT_114;
    unsigned int zT_115;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_120;
    zT_22A7C88B_AstNode zT_123 = {0};
    zT_8143F551_AstKind zT_124;
    unsigned char zT_128;
    zT_8143F551_AstKind zT_129;
    unsigned char zT_133;
    unsigned char zT_135;
    unsigned int zT_136;
    unsigned int* zT_139;
    unsigned int zT_140;
    unsigned char* zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned char zT_146;
    zT_38C12417_SemanticAnalyzer* zT_147;
    unsigned int zT_148;
    unsigned int zT_151;
    zT_38C12417_SemanticAnalyzer* zT_154;
    unsigned int zT_155;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u m;
    unsigned int label;
    unsigned int saved_loops;
    unsigned char is_loop;
    zT_22A7C88B_AstNode inner;
    unsigned char pushed;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = node.kind;
    kind = zT_10;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_17 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_7;
    z_bb_6:
    zT_17 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_17) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_25 = "cannot return from defer expression";
    zT_27 = 35;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    m = zT_26;
    zT_28 = self;
    zT_29 = node_idx;
    zT_31 = m;
    zF_398A7D41_semanticAnalyzerDia(zT_28, zT_29, (zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3051_RETURN_INSIDE_DEFER), zT_31);
    goto z_bb_11;
    z_bb_11:
    zT_154 = self;
    zT_155 = node_idx;
    zF_0D8393D0_semanticAnalyzerChe(zT_154, zT_155);
    return;
    z_bb_12:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_13; else goto z_bb_15;
    z_bb_13:
    zT_38 = "'try' not allowed inside defer expression";
    zT_40 = 41;
    zT_39.ptr = zT_38;
    zT_39.len = zT_40;
    m = zT_39;
    zT_41 = self;
    zT_42 = node_idx;
    zT_44 = m;
    zF_398A7D41_semanticAnalyzerDia(zT_41, zT_42, (zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3054_TRY_INSIDE_DEFER), zT_44);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_51 = self->store;
    zT_52 = node_idx;
    zT_54 = zF_8BA26B9E_astStoreNodePayload(zT_51, zT_52);
    label = zT_54;
    zT_55 = self;
    zT_56 = label;
    zT_57 = zF_02E8B77C_semanticAnalyzerDef(zT_55, zT_56);
    if ((unsigned char)(!zT_57)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt))) goto z_bb_21; else goto z_bb_23;
    z_bb_19:
    zT_60 = "cannot break out of defer expression";
    zT_62 = 36;
    zT_61.ptr = zT_60;
    zT_61.len = zT_62;
    m = zT_61;
    zT_63 = self;
    zT_64 = node_idx;
    zT_66 = m;
    zF_398A7D41_semanticAnalyzerDia(zT_63, zT_64, (zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3052_BREAK_OUT_OF_DEFER), zT_66);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_73 = self->store;
    zT_74 = node_idx;
    zT_76 = zF_8BA26B9E_astStoreNodePayload(zT_73, zT_74);
    label = zT_76;
    zT_77 = self;
    zT_78 = label;
    zT_79 = zF_389B3480_semanticAnalyzerDef(zT_77, zT_78);
    if ((unsigned char)(!zT_79)) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_17;
    z_bb_23:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_27; else goto z_bb_26;
    z_bb_24:
    zT_82 = "cannot continue out of defer expression";
    zT_84 = 39;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    m = zT_83;
    zT_85 = self;
    zT_86 = node_idx;
    zT_88 = m;
    zF_398A7D41_semanticAnalyzerDia(zT_85, zT_86, (zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3053_CONTINUE_OUT_OF_DEFER), zT_88);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_94 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt);
    goto z_bb_28;
    z_bb_27:
    zT_94 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_94) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    zT_99 = self->defer_inner_loops;
    saved_loops = zT_99;
    zT_100 = self->defer_inner_loops;
    self->defer_inner_loops = (unsigned int)(zT_100 + (unsigned int)(1));
    zT_103 = self;
    zT_104 = node_idx;
    zF_0D8393D0_semanticAnalyzerChe(zT_103, zT_104);
    self->defer_inner_loops = saved_loops;
    return;
    z_bb_30:
    goto z_bb_22;
    z_bb_31:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_109 = self->store;
    zT_110 = node_idx;
    zT_112 = zF_8BA26B9E_astStoreNodePayload(zT_109, zT_110);
    label = zT_112;
    zT_114 = 0;
    is_loop = zT_114;
    zT_115 = node.child_0;
    if ((unsigned char)(zT_115 != (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_119 = self->store;
    zT_120 = node.child_0;
    zT_123 = zF_FCDD1D35_astStoreNodeAt(zT_119, zT_120);
    inner = zT_123;
    zT_124 = inner.kind;
    if ((unsigned char)(zT_124 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_37; else goto z_bb_36;
    z_bb_35:
    zT_135 = 0;
    pushed = zT_135;
    zT_136 = self->defer_label_len;
    if ((unsigned char)(zT_136 < (unsigned int)(16))) goto z_bb_41; else goto z_bb_42;
    z_bb_36:
    zT_129 = inner.kind;
    zT_128 = zT_129 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt);
    goto z_bb_38;
    z_bb_37:
    zT_128 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_128) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_133 = 1;
    is_loop = zT_133;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_35;
    z_bb_41:
    zT_139 = self->defer_label_stack;
    zT_140 = self->defer_label_len;
    zT_139[zT_140] = label;
    zT_141 = self->defer_label_isloop;
    zT_142 = self->defer_label_len;
    zT_141[zT_142] = is_loop;
    zT_143 = self->defer_label_len;
    self->defer_label_len = (unsigned int)(zT_143 + (unsigned int)(1));
    zT_146 = 1;
    pushed = zT_146;
    goto z_bb_42;
    z_bb_42:
    zT_147 = self;
    zT_148 = node_idx;
    zF_0D8393D0_semanticAnalyzerChe(zT_147, zT_148);
    if ((unsigned char)(pushed != (unsigned char)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_151 = self->defer_label_len;
    self->defer_label_len = (unsigned int)(zT_151 - (unsigned int)(1));
    goto z_bb_44;
    z_bb_44:
    return;
}

/* semanticAnalyzerGrowLocalDecls */
void zF_156C79D0_semanticAnalyzerGro(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_0715C9B9_EU_832 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    zT_3E40CD83_Sand* zT_23;
    zT_0715C9B9_EU_832 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    zT_3E40CD83_Sand* zT_35;
    unsigned int zT_36;
    zT_0715C9B9_EU_832 zT_40 = {0};
    unsigned char zT_41;
    unsigned char* zT_42;
    unsigned int* zT_45;
    unsigned int* zT_47;
    unsigned char* zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int* zT_58;
    unsigned int zT_59;
    unsigned int* zT_60;
    unsigned int zT_61;
    unsigned char* zT_62;
    unsigned char zT_63;
    int zT_64;
    unsigned int zT_66;
    unsigned int new_cap;
    unsigned char* raw_names;
    unsigned char* raw_types;
    unsigned char* raw_consts;
    unsigned int* ndst;
    unsigned int* tdst;
    unsigned char* cdst;
    unsigned int ci;
    zT_2 = self->local_decl_cap;
    if ((unsigned char)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->local_decl_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_names = zT_20;
    zT_23 = self->expected_type_stack_alloc;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_32 = zT_30.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_types = zT_32;
    zT_35 = self->expected_type_stack_alloc;
    zT_36 = new_cap;
    zT_40 = zF_1395EB68_sandAlloc(zT_35, zT_36, (unsigned int)(1));
    zT_41 = zT_40.is_error;
    if (zT_41) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_42 = zT_40.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_consts = zT_42;
    zT_45 = (unsigned int*)raw_names;
    ndst = zT_45;
    zT_47 = (unsigned int*)raw_types;
    tdst = zT_47;
    zT_49 = (unsigned char*)raw_consts;
    cdst = zT_49;
    zT_50 = self->local_decl_count;
    if ((unsigned char)(zT_50 > (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    ci = zT_55;
    goto z_bb_15;
    z_bb_14:
    self->local_decl_names = ndst;
    self->local_decl_types = tdst;
    self->local_decl_consts = cdst;
    self->local_decl_cap = new_cap;
    return;
    z_bb_15:
    zT_56 = self->local_decl_count;
    if ((unsigned char)(ci < zT_56)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_58 = self->local_decl_names;
    zT_59 = zT_58[ci];
    ndst[ci] = zT_59;
    zT_60 = self->local_decl_types;
    zT_61 = zT_60[ci];
    tdst[ci] = zT_61;
    zT_62 = self->local_decl_consts;
    zT_63 = zT_62[ci];
    cdst[ci] = zT_63;
    goto z_bb_18;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_64 = 1;
    zT_66 = ci + (unsigned int)((unsigned int)zT_64);
    ci = zT_66;
    goto z_bb_15;
}

/* registerLocalDecl */
void zF_7BD72017_registerLocalDecl(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    unsigned char* zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_tm;
    zT_3 = self->local_decl_count;
    zT_4 = self->local_decl_cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_8 = "SCT:n";
    zT_10 = 5;
    zT_9.ptr = zT_8;
    zT_9.len = zT_10;
    sct_nm = zT_9;
    zT_11 = sct_nm;
    zT_12 = name_id;
    zF_C914CB83_markerWriteInt(zT_11, zT_12);
    zT_14 = "SCT:t";
    zT_16 = 5;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    sct_tm = zT_15;
    zT_17 = sct_tm;
    zT_18 = type_id;
    zF_C914CB83_markerWriteInt(zT_17, zT_18);
    zT_19 = self->local_decl_names;
    zT_20 = self->local_decl_count;
    zT_19[zT_20] = name_id;
    zT_21 = self->local_decl_types;
    zT_22 = self->local_decl_count;
    zT_21[zT_22] = type_id;
    zT_23 = 1;
    zT_24 = self->local_decl_consts;
    zT_25 = self->local_decl_count;
    zT_24[zT_25] = zT_23;
    zT_26 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_26 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCheckLocalShadow */
void zF_C999EE08_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, unsigned int span_start, unsigned int span_end) {
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_11;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_F85C5DED_DiagnosticCollector* zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_33 = 0;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    zT_3D7259E2_SymbolRegistry* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_567DA1C3_Opt_868 zT_47 = {0};
    unsigned char zT_48;
    zT_3C598AEF_SymbolKind zT_50;
    unsigned char zT_54;
    zT_3C598AEF_SymbolKind zT_55;
    unsigned char zT_59;
    zT_3C598AEF_SymbolKind zT_60;
    unsigned char zT_64;
    zT_3C598AEF_SymbolKind zT_65;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_F85C5DED_DiagnosticCollector* zT_73;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_86 = 0;
    unsigned int li;
    zT_8F083A69_Slice_zT_0B42B2F8_u lsh_msg;
    unsigned int lsh_di;
    zT_8F083A69_Slice_zT_0B42B2F8_u lsh_note;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u osh_msg;
    zT_4 = self->discard_name_id;
    if ((unsigned char)(name_id == zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = self->local_decl_count;
    li = zT_7;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(li > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = li - (unsigned int)(1);
    li = zT_11;
    zT_12 = self->local_decl_names;
    zT_13 = zT_12[li];
    if ((unsigned char)(zT_13 == name_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_42 = self->symbols;
    zT_43 = self->module_id;
    zT_44 = name_id;
    zT_47 = zF_A398987E_symbolRegistryQuali(zT_42, zT_43, zT_44);
    zT_48 = zT_47.has_value;
    if (zT_48) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_16 = "local declaration shadows an earlier declaration in an enclosing scope";
    zT_18 = 70;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    lsh_msg = zT_17;
    zT_20 = self->diag;
    zT_23 = self->source_file_id;
    zT_24 = span_start;
    zT_25 = span_end;
    zT_26 = lsh_msg;
    zT_33 = zF_C82559AC_diagnosticCollector(zT_20, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3057_LOCAL_SHADOW)), zT_23, zT_24, zT_25, zT_26);
    lsh_di = zT_33;
    zT_35 = "previous declaration here";
    zT_37 = 25;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    lsh_note = zT_36;
    zT_38 = self->diag;
    zT_39 = lsh_di;
    zT_40 = lsh_note;
    zF_426E1F18_diagnosticCollector(zT_38, zT_39, zT_40);
    (void)self;
    return;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    s = zT_47.value;
    zT_50 = s->kind;
    if ((unsigned char)(zT_50 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_12; else goto z_bb_11;
    z_bb_10:
    return;
    z_bb_11:
    zT_55 = s->kind;
    zT_54 = zT_55 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function);
    goto z_bb_13;
    z_bb_12:
    zT_54 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_54) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_60 = s->kind;
    zT_59 = zT_60 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    goto z_bb_16;
    z_bb_15:
    zT_59 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_59) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_65 = s->kind;
    zT_64 = zT_65 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module);
    goto z_bb_19;
    z_bb_18:
    zT_64 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_64) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_70 = "local declaration shadows an outer-scope declaration";
    zT_72 = 52;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    osh_msg = zT_71;
    zT_73 = self->diag;
    zT_76 = self->source_file_id;
    zT_77 = span_start;
    zT_78 = span_end;
    zT_79 = osh_msg;
    zT_86 = zF_C82559AC_diagnosticCollector(zT_73, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3057_LOCAL_SHADOW)), zT_76, zT_77, zT_78, zT_79);
    (void)zT_86;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_10;
}

/* semanticAnalyzerPopScopeMarker */
unsigned char zF_2FC8BE84_semanticAnalyzerPop(zT_38C12417_SemanticAnalyzer* self, unsigned int item) {
    if ((unsigned char)(item >= (unsigned int)(2147483648u))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    self->local_decl_count = (unsigned int)((unsigned int)(unsigned int)(item & (unsigned int)(2147483647)));
    return (unsigned char)(1);
    z_bb_2:
    return (unsigned char)(0);
}

/* semanticAnalyzerNthIdentSpan */
unsigned char zF_4679EA8B_semanticAnalyzerNth(zT_38C12417_SemanticAnalyzer* self, unsigned int from, unsigned int limit, unsigned int n, unsigned int* out_start, unsigned int* out_end) {
    int zT_8;
    unsigned int zT_9;
    int zT_12;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int* zT_22;
    unsigned char zT_27 = 0;
    int zT_30;
    unsigned int zT_32;
    unsigned int f;
    unsigned int i;
    unsigned int s;
    unsigned int e;
    f = from;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < n)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    s = zT_13;
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    e = zT_16;
    zT_17 = self->diag;
    zT_18 = self->source_file_id;
    zT_19 = f;
    zT_20 = limit;
    zT_21 = &s;
    zT_22 = &e;
    zT_27 = zF_BCEBD9F2_diagnosticCollector(zT_17, zT_18, zT_19, zT_20, zT_21, zT_22);
    if ((unsigned char)(!zT_27)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_30 = 1;
    zT_32 = i + (unsigned int)((unsigned int)zT_30);
    i = zT_32;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    *out_start = s;
    *out_end = e;
    f = e;
    goto z_bb_4;
}

/* semanticAnalyzerCaptureType */
unsigned int zF_3E251D67_semanticAnalyzerCap(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_type) {
    zT_338B7C76_TypeRegistry* zT_6;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_0B10E8E9_OptionalPayload* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_0B10E8E9_OptionalPayload zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type capt_ty;
    if ((unsigned char)(cond_type == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_items;
    zT_8 = (unsigned int)cond_type;
    zT_9 = zT_7[zT_8];
    capt_ty = zT_9;
    zT_10 = capt_ty.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self->registry;
    zT_15 = zT_14->opt_items;
    zT_16 = capt_ty.payload_idx;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15[zT_17];
    zT_19 = zT_18.payload;
    return zT_19;
    z_bb_4:
    return cond_type;
}

/* semanticAnalyzerResolveIdent */
unsigned int zF_9F1ECA79_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int module_id, unsigned int name_id, unsigned int node_idx) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int* zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_79FAE712_u64 zT_63;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned int zT_70;
    zT_79FAE712_u64 zT_75;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_79FAE712_u64 zT_78;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    zT_3D7259E2_SymbolRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_567DA1C3_Opt_868 zT_87 = {0};
    unsigned char zT_88;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_3C598AEF_SymbolKind zT_95;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_104;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char zT_113;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char zT_120;
    unsigned char* zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_133;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    unsigned char* zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    unsigned char zT_149;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned char zT_164;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    unsigned char* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_184;
    unsigned int zT_186;
    unsigned char* zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    unsigned int* zT_195;
    unsigned int zT_196;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    unsigned int* zT_204;
    unsigned int zT_205;
    unsigned int zT_207;
    unsigned int zT_209;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    unsigned int* zT_218;
    unsigned int zT_219;
    unsigned char* zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned int zT_226;
    unsigned char zT_229;
    zT_D3EB6303_StringInterner* zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    zT_6B0A7D14_AstStore* zT_239;
    unsigned int zT_240;
    zT_22A7C88B_AstNode zT_242 = {0};
    unsigned char* zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    unsigned int zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    zT_8143F551_AstKind zT_249;
    zT_8EED1867_ResolvedTypeTable* zT_252;
    unsigned int zT_253;
    zT_BAEE192E_Opt_10 zT_255 = {0};
    unsigned char zT_256;
    unsigned char* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned int zT_274;
    unsigned char* zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned int zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_283;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    int zT_289;
    unsigned char* zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned int zT_293 = 0;
    unsigned int zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    unsigned char* zT_302;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    unsigned char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    zT_6B0A7D14_AstStore* zT_311;
    unsigned int zT_312;
    zT_22A7C88B_AstNode zT_314 = {0};
    unsigned int zT_316;
    unsigned int zT_318;
    unsigned int zT_320;
    zT_D3EB6303_StringInterner* zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325 = {0};
    unsigned char* zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    unsigned char* zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned int zT_333;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    zT_D3EB6303_StringInterner* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_341;
    int zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_348;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    unsigned int zT_361 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u ide;
    zT_8F083A69_Slice_zT_0B42B2F8_u sem_m;
    unsigned int li;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 ncg;
    zT_79FAE712_u64 mkey;
    zT_BAEE192E_Opt_10 ncgm;
    zT_567DA1C3_Opt_868 sym;
    unsigned int lcl_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u id1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lt_m;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u id2;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_talias;
    unsigned int ctm;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_sv;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_tm;
    unsigned int nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_ntm;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u id3;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8l_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8i_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cname;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8k_m;
    zT_BAEE192E_Opt_10 rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8nl2;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8z_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u idm;
    zT_5A26C2ED_Arr_unsigned_char_1 idnb;
    unsigned int idnl;
    unsigned int idns;
    zT_8F083A69_Slice_zT_0B42B2F8_u idc;
    zT_22A7C88B_AstNode uin;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u uinm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uiparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u uimsg;
    zT_5 = "IDE\n";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    ide = zT_6;
    zT_8 = ide;
    zF_48AC7B3A_markerWrite(zT_8);
    if ((unsigned char)(name_id == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = "SEM:vi";
    zT_14 = 6;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    sem_m = zT_13;
    zT_15 = sem_m;
    zT_16 = module_id;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_18 = self->local_decl_count;
    li = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(li > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = li - (unsigned int)(1);
    li = zT_22;
    zT_23 = self->local_decl_names;
    zT_24 = zT_23[li];
    if ((unsigned char)(zT_24 == name_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_63 = (zT_79FAE712_u64)name_id;
    key = zT_63;
    zT_65 = self->registry;
    zT_66 = key;
    zT_68 = zF_0EB68360_nameCacheGet(zT_65, zT_66);
    ncg = zT_68;
    zT_70 = self->module_id;
    zT_75 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_70) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    mkey = zT_75;
    zT_77 = self->registry;
    zT_78 = mkey;
    zT_80 = zF_0EB68360_nameCacheGet(zT_77, zT_78);
    ncgm = zT_80;
    zT_82 = self->symbols;
    zT_83 = self->module_id;
    zT_84 = name_id;
    zT_87 = zF_A398987E_symbolRegistryQuali(zT_82, zT_83, zT_84);
    sym = zT_87;
    zT_88 = sym.has_value;
    if (zT_88) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_27 = self->local_decl_types;
    zT_28 = zT_27[li];
    lcl_t = zT_28;
    zT_30 = "D7:Yn";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    d7m = zT_31;
    zT_33 = d7m;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_35 = "D7:n";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    d7n_m = zT_36;
    zT_38 = d7n_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_41 = "D7:t";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    d7tm = zT_42;
    zT_44 = d7tm;
    zF_48AC7B3A_markerWrite(zT_44);
    zT_46 = "D7";
    zT_48 = 2;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    d7t_m = zT_47;
    zT_49 = d7t_m;
    zT_50 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_49, zT_50);
    zT_52 = "L\n";
    zT_54 = 2;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    id1 = zT_53;
    zT_55 = id1;
    zF_48AC7B3A_markerWrite(zT_55);
    zT_57 = "L:t";
    zT_59 = 3;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    lt_m = zT_58;
    zT_60 = lt_m;
    zT_61 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_60, zT_61);
    return lcl_t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    s = sym.value;
    zT_91 = "S\n";
    zT_93 = 2;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    id2 = zT_92;
    zT_94 = id2;
    zF_48AC7B3A_markerWrite(zT_94);
    zT_95 = s->kind;
    if ((unsigned char)(zT_95 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_164 = ncg.has_value;
    if (zT_164) goto z_bb_23; else goto z_bb_24;
    z_bb_11:
    zT_99 = self;
    zT_100 = s->decl_node;
    zT_101 = s->module_id;
    zF_FC6E31C6_semanticAnalyzerMay(zT_99, zT_100, zT_101);
    zT_104 = s->type_id;
    if ((unsigned char)(zT_104 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_133 = s->type_id;
    if ((unsigned char)(zT_133 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    zT_108 = "TAL\n";
    zT_110 = 4;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    rdt_talias = zT_109;
    zT_111 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_111);
    zT_112 = s->type_id;
    return zT_112;
    z_bb_14:
    zT_113 = ncgm.has_value;
    if (zT_113) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    ctm = ncgm.value;
    zT_116 = "TAL\n";
    zT_118 = 4;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    rdt_talias = zT_117;
    zT_119 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_119);
    return ctm;
    z_bb_16:
    zT_120 = ncg.has_value;
    if (zT_120) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    ct = ncg.value;
    zT_123 = "TAL\n";
    zT_125 = 4;
    zT_124.ptr = zT_123;
    zT_124.len = zT_125;
    rdt_talias = zT_124;
    zT_126 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_126);
    return ct;
    z_bb_18:
    zT_128 = "SVO\n";
    zT_130 = 4;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    rdt_sv = zT_129;
    zT_131 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_131);
    return (unsigned int)(1);
    z_bb_19:
    zT_137 = "STY:N";
    zT_139 = 5;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    rdt_nm = zT_138;
    zT_140 = rdt_nm;
    zT_141 = name_id;
    zF_C914CB83_markerWriteInt(zT_140, zT_141);
    zT_143 = "STY:T";
    zT_145 = 5;
    zT_144.ptr = zT_143;
    zT_144.len = zT_145;
    rdt_tm = zT_144;
    zT_146 = rdt_tm;
    zT_147 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_146, zT_147);
    zT_149 = ncg.has_value;
    if (zT_149) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_159 = "SVO\n";
    zT_161 = 4;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    rdt_sv = zT_160;
    zT_162 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_162);
    return (unsigned int)(1);
    z_bb_21:
    nt = ncg.value;
    zT_152 = "STY:C";
    zT_154 = 5;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    rdt_ntm = zT_153;
    zT_155 = rdt_ntm;
    zT_156 = nt;
    zF_C914CB83_markerWriteInt(zT_155, zT_156);
    goto z_bb_22;
    z_bb_22:
    zT_157 = s->type_id;
    return zT_157;
    z_bb_23:
    t = ncg.value;
    zT_167 = "C2:T";
    zT_169 = 4;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    id3 = zT_168;
    zT_170 = id3;
    zT_171 = t;
    zF_C914CB83_markerWriteInt(zT_170, zT_171);
    return t;
    z_bb_24:
    zT_173 = "D8:Nn";
    zT_175 = 5;
    zT_174.ptr = zT_173;
    zT_174.len = zT_175;
    d8n_m = zT_174;
    zT_176 = d8n_m;
    zT_177 = name_id;
    zF_C914CB83_markerWriteInt(zT_176, zT_177);
    zT_179 = "D8:C";
    zT_181 = 4;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    d8c_m = zT_180;
    zT_182 = d8c_m;
    zT_184 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_182, (unsigned int)((unsigned int)zT_184));
    zT_186 = self->local_decl_count;
    if ((unsigned char)(zT_186 > (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_190 = "D8:F";
    zT_192 = 4;
    zT_191.ptr = zT_190;
    zT_191.len = zT_192;
    d8f_m = zT_191;
    zT_193 = d8f_m;
    zT_195 = self->local_decl_names;
    zT_196 = 0;
    zT_194 = zT_195[zT_196];
    zF_C914CB83_markerWriteInt(zT_193, zT_194);
    zT_199 = "D8:L";
    zT_201 = 4;
    zT_200.ptr = zT_199;
    zT_200.len = zT_201;
    d8l_m = zT_200;
    zT_202 = d8l_m;
    zT_204 = self->local_decl_names;
    zT_205 = self->local_decl_count;
    zT_207 = zT_205 - (unsigned int)(1);
    zT_203 = zT_204[zT_207];
    zF_C914CB83_markerWriteInt(zT_202, zT_203);
    goto z_bb_26;
    z_bb_26:
    zT_209 = self->local_decl_count;
    if ((unsigned char)(zT_209 > (unsigned int)(4))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_213 = "D8:X";
    zT_215 = 4;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    d8x_m = zT_214;
    zT_216 = d8x_m;
    zT_218 = self->local_decl_names;
    zT_219 = 4;
    zT_217 = zT_218[zT_219];
    zF_C914CB83_markerWriteInt(zT_216, zT_217);
    goto z_bb_28;
    z_bb_28:
    zT_222 = "D8:I";
    zT_224 = 4;
    zT_223.ptr = zT_222;
    zT_223.len = zT_224;
    d8i_m = zT_223;
    zT_225 = d8i_m;
    zT_226 = node_idx;
    zF_C914CB83_markerWriteInt(zT_225, zT_226);
    if ((unsigned char)(node_idx >= (unsigned int)(450))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_229 = node_idx <= (unsigned int)(660);
    goto z_bb_31;
    z_bb_30:
    zT_229 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_229) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_233 = self->interner;
    zT_234 = name_id;
    zT_236 = zF_9134020D_stringInternerGet(zT_233, zT_234);
    cname = zT_236;
    zT_237 = cname;
    zF_48AC7B3A_markerWrite(zT_237);
    zT_239 = self->store;
    zT_240 = node_idx;
    zT_242 = zF_FCDD1D35_astStoreNodeAt(zT_239, zT_240);
    cnode = zT_242;
    zT_244 = "D8";
    zT_246 = 2;
    zT_245.ptr = zT_244;
    zT_245.len = zT_246;
    d8k_m = zT_245;
    zT_247 = d8k_m;
    zT_249 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_247, (unsigned int)((unsigned int)zT_249));
    zT_252 = self->type_table;
    zT_253 = node_idx;
    zT_255 = zF_999DCF51_resolvedTypeTableGe(zT_252, zT_253);
    rt = zT_255;
    zT_256 = rt.has_value;
    if (zT_256) goto z_bb_34; else goto z_bb_36;
    z_bb_33:
    zT_274 = self->_stub_0;
    if ((unsigned char)(name_id == zT_274)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    t = rt.value;
    zT_259 = "D8:T";
    zT_261 = 4;
    zT_260.ptr = zT_259;
    zT_260.len = zT_261;
    d8t_m = zT_260;
    zT_262 = d8t_m;
    zT_263 = t;
    zF_C914CB83_markerWriteInt(zT_262, zT_263);
    goto z_bb_35;
    z_bb_35:
    zT_270 = "\n";
    zT_272 = 1;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    d8nl2 = zT_271;
    zT_273 = d8nl2;
    zF_48AC7B3A_markerWrite(zT_273);
    goto z_bb_33;
    z_bb_36:
    zT_265 = "D8:Z\n";
    zT_267 = 5;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    d8z_m = zT_266;
    zT_268 = d8z_m;
    zF_48AC7B3A_markerWrite(zT_268);
    goto z_bb_35;
    z_bb_37:
    return (unsigned int)(18);
    z_bb_38:
    zT_278 = "IDT:";
    zT_280 = 4;
    zT_279.ptr = zT_278;
    zT_279.len = zT_280;
    idm = zT_279;
    zT_281 = idm;
    zF_48AC7B3A_markerWrite(zT_281);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_283[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        idnb[_i] = zT_283[_i];
        _i++;
    }
}
    zT_285 = name_id;
    zT_289 = 0;
    zT_290 = (unsigned char*)((unsigned char*)idnb) + zT_289;
    zT_291 = (unsigned int)(10) - zT_289;
    zT_292.ptr = zT_290;
    zT_292.len = zT_291;
    zT_286 = zT_292;
    zT_293 = zF_A7504564_itoa(zT_285, zT_286);
    idnl = zT_293;
    zT_297 = (unsigned int)(9) - (unsigned int)((unsigned int)idnl);
    idns = zT_297;
    zT_302 = (unsigned char*)((unsigned char*)idnb) + idns;
    zT_303 = (unsigned int)(9) - idns;
    zT_304.ptr = zT_302;
    zT_304.len = zT_303;
    zT_298 = zT_304;
    zF_48AC7B3A_markerWrite(zT_298);
    zT_306 = ":VOID\n";
    zT_308 = 6;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    idc = zT_307;
    zT_309 = idc;
    zF_48AC7B3A_markerWrite(zT_309);
    zT_311 = self->store;
    zT_312 = node_idx;
    zT_314 = zF_FCDD1D35_astStoreNodeAt(zT_311, zT_312);
    uin = zT_314;
    zT_316 = uin.span_start;
    uisp = zT_316;
    zT_318 = uin.span_len;
    zT_320 = uisp + (unsigned int)((unsigned int)zT_318);
    uiep = zT_320;
    zT_322 = self->interner;
    zT_323 = name_id;
    zT_325 = zF_9134020D_stringInternerGet(zT_322, zT_323);
    uinm = zT_325;
    zT_327 = "identifier '";
    zT_329 = 12;
    zT_328.ptr = zT_327;
    zT_328.len = zT_329;
    ui1 = zT_328;
    zT_331 = "' is not declared or imported in this module";
    zT_333 = 44;
    zT_332.ptr = zT_331;
    zT_332.len = zT_333;
    ui2 = zT_332;
    zT_336 = 0;
    zT_335[zT_336] = ui1;
    zT_337 = 1;
    zT_335[zT_337] = uinm;
    zT_338 = 2;
    zT_335[zT_338] = ui2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uiparts[_i] = zT_335[_i];
        _i++;
    }
}
    zT_340 = self->interner;
    zT_344 = 0;
    zT_345 = uiparts + zT_344;
    zT_341 = zT_345;
    zT_347 = zF_8C4BFF7C_diagnosticBuilderMa(zT_340, zT_341, (unsigned int)(3));
    uimsg = zT_347;
    zT_348 = self->diag;
    zT_351 = self->source_file_id;
    zT_352 = uisp;
    zT_353 = uiep;
    zT_354 = uimsg;
    zT_361 = zF_C82559AC_diagnosticCollector(zT_348, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3001_UNDEFINED_SYMBOL)), zT_351, zT_352, zT_353, zT_354);
    (void)zT_361;
    return (unsigned int)(1);
}

/* semanticAnalyzerArrayFieldLen */
unsigned int zF_3F00B75F_semanticAnalyzerArr(zT_38C12417_SemanticAnalyzer* self, unsigned int base_node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_29;
    unsigned int zT_30;
    zT_338B7C76_TypeRegistry* zT_34;
    zT_D155D06D_Type* zT_35;
    unsigned int zT_36;
    zT_D155D06D_Type zT_37;
    zT_33EF6BFB_TypeKind zT_38;
    unsigned char zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_112BF819_PtrPayload* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_112BF819_PtrPayload zT_51;
    unsigned int zT_52;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_D155D06D_Type* zT_59;
    unsigned int zT_60;
    zT_D155D06D_Type zT_61;
    int zT_63;
    unsigned int zT_64;
    int zT_66;
    unsigned int zT_67;
    zT_33EF6BFB_TypeKind zT_68;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_406493CE_StructPayload* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_406493CE_StructPayload zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned short zT_80;
    unsigned int zT_81;
    zT_33EF6BFB_TypeKind zT_82;
    unsigned char zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    zT_338B7C76_TypeRegistry* zT_92;
    zT_AF9231A2_UnionPayload* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_AF9231A2_UnionPayload zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned short zT_99;
    unsigned int zT_100;
    int zT_103;
    unsigned int zT_104;
    zT_338B7C76_TypeRegistry* zT_106;
    zT_2DF01B61_FieldEntry* zT_107;
    unsigned int zT_108;
    zT_2DF01B61_FieldEntry zT_109;
    unsigned int zT_110;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_2DF01B61_FieldEntry* zT_114;
    unsigned int zT_115;
    zT_2DF01B61_FieldEntry zT_116;
    unsigned int zT_117;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    unsigned char zT_122;
    zT_338B7C76_TypeRegistry* zT_123;
    zT_D155D06D_Type* zT_124;
    unsigned int zT_125;
    zT_D155D06D_Type zT_126;
    zT_33EF6BFB_TypeKind zT_127;
    int zT_133;
    unsigned int zT_135;
    zT_22A7C88B_AstNode bn;
    unsigned int fname;
    unsigned int cont;
    zT_D155D06D_Type cty;
    unsigned int fstart;
    unsigned int fcount;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    zT_AF9231A2_UnionPayload up;
    unsigned int ft;
    zT_3 = self->store;
    zT_4 = base_node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    bn = zT_6;
    zT_7 = bn.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_13 = self->store;
    zT_14 = base_node_idx;
    zT_16 = zF_8BA26B9E_astStoreNodePayload(zT_13, zT_14);
    fname = zT_16;
    zT_18 = self;
    zT_19 = bn.child_0;
    zT_21 = zF_54F95822_semanticAnalyzerRes(zT_18, zT_19);
    cont = zT_21;
    if ((unsigned char)(cont == (unsigned int)(1))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_24 = cont == (unsigned int)(18);
    goto z_bb_5;
    z_bb_4:
    zT_24 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    zT_29 = self->registry;
    zT_30 = zT_29->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)cont) >= zT_30)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned int)(0);
    z_bb_9:
    zT_34 = self->registry;
    zT_35 = zT_34->types_items;
    zT_36 = (unsigned int)cont;
    zT_37 = zT_35[zT_36];
    cty = zT_37;
    zT_38 = cty.kind;
    if ((unsigned char)(zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_43 = cty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_12;
    z_bb_11:
    zT_42 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_42) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_47 = self->registry;
    zT_48 = zT_47->ptr_items;
    zT_49 = cty.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    zT_52 = zT_51.base;
    cont = zT_52;
    zT_54 = self->registry;
    zT_55 = zT_54->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)cont) >= zT_55)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_63 = 0;
    zT_64 = (unsigned int)zT_63;
    fstart = zT_64;
    zT_66 = 0;
    zT_67 = (unsigned int)zT_66;
    fcount = zT_67;
    zT_68 = cty.kind;
    if ((unsigned char)(zT_68 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    return (unsigned int)(0);
    z_bb_16:
    zT_58 = self->registry;
    zT_59 = zT_58->types_items;
    zT_60 = (unsigned int)cont;
    zT_61 = zT_59[zT_60];
    cty = zT_61;
    goto z_bb_14;
    z_bb_17:
    zT_73 = self->registry;
    zT_74 = zT_73->st_items;
    zT_75 = cty.payload_idx;
    zT_76 = (unsigned int)zT_75;
    zT_77 = zT_74[zT_76];
    sp = zT_77;
    zT_78 = sp.fields_start;
    zT_79 = (unsigned int)zT_78;
    fstart = zT_79;
    zT_80 = sp.fields_count;
    zT_81 = (unsigned int)zT_80;
    fcount = zT_81;
    goto z_bb_18;
    z_bb_18:
    zT_103 = 0;
    zT_104 = (unsigned int)zT_103;
    fi = zT_104;
    goto z_bb_26;
    z_bb_19:
    zT_82 = cty.kind;
    if ((unsigned char)(zT_82 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_87 = cty.kind;
    zT_86 = zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_22;
    z_bb_21:
    zT_86 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_86) goto z_bb_23; else goto z_bb_25;
    z_bb_23:
    zT_92 = self->registry;
    zT_93 = zT_92->un_items;
    zT_94 = cty.payload_idx;
    zT_95 = (unsigned int)zT_94;
    zT_96 = zT_93[zT_95];
    up = zT_96;
    zT_97 = up.fields_start;
    zT_98 = (unsigned int)zT_97;
    fstart = zT_98;
    zT_99 = up.fields_count;
    zT_100 = (unsigned int)zT_99;
    fcount = zT_100;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_18;
    z_bb_25:
    return (unsigned int)(0);
    z_bb_26:
    if ((unsigned char)(fi < fcount)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_106 = self->registry;
    zT_107 = zT_106->fe_items;
    zT_108 = fstart + fi;
    zT_109 = zT_107[zT_108];
    zT_110 = zT_109.name_id;
    if ((unsigned char)(zT_110 == fname)) goto z_bb_30; else goto z_bb_31;
    z_bb_28:
    return (unsigned int)(0);
    z_bb_29:
    zT_133 = 1;
    zT_135 = fi + (unsigned int)((unsigned int)zT_133);
    fi = zT_135;
    goto z_bb_26;
    z_bb_30:
    zT_113 = self->registry;
    zT_114 = zT_113->fe_items;
    zT_115 = fstart + fi;
    zT_116 = zT_114[zT_115];
    zT_117 = zT_116.type_id;
    ft = zT_117;
    zT_119 = self->registry;
    zT_120 = zT_119->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ft) < zT_120)) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_123 = self->registry;
    zT_124 = zT_123->types_items;
    zT_125 = (unsigned int)ft;
    zT_126 = zT_124[zT_125];
    zT_127 = zT_126.kind;
    zT_122 = zT_127 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_34;
    z_bb_33:
    zT_122 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_122) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned int)(13);
    z_bb_36:
    return (unsigned int)(0);
}

/* semanticAnalyzerResolveFieldAccess */
unsigned int zF_DDD991E1_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8143F551_AstKind zT_29;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8143F551_AstKind zT_37;
    zT_38C12417_SemanticAnalyzer* zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    unsigned int zT_51 = 0;
    zT_3D7259E2_SymbolRegistry* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_567DA1C3_Opt_868 zT_58 = {0};
    unsigned char zT_59;
    zT_3C598AEF_SymbolKind zT_61;
    unsigned int zT_66;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_D155D06D_Type* zT_71;
    unsigned int zT_72;
    zT_D155D06D_Type zT_73;
    zT_33EF6BFB_TypeKind zT_74;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_54FF90FA_TaggedUnionPayload* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_54FF90FA_TaggedUnionPayload zT_83;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned short zT_88;
    unsigned int zT_89;
    int zT_91;
    unsigned int zT_92;
    zT_338B7C76_TypeRegistry* zT_94;
    zT_2DF01B61_FieldEntry* zT_95;
    unsigned int zT_96;
    zT_2DF01B61_FieldEntry zT_97;
    unsigned int zT_98;
    zT_8EED1867_ResolvedTypeTable* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    int zT_104;
    unsigned int zT_106;
    zT_33EF6BFB_TypeKind zT_107;
    zT_338B7C76_TypeRegistry* zT_112;
    zT_457ECFEE_EnumPayload* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    zT_457ECFEE_EnumPayload zT_116;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned short zT_121;
    unsigned int zT_122;
    int zT_124;
    unsigned int zT_125;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_D96DCDF2_EnumMember* zT_128;
    unsigned int zT_129;
    zT_D96DCDF2_EnumMember zT_130;
    unsigned int zT_131;
    zT_8EED1867_ResolvedTypeTable* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    int zT_137;
    unsigned int zT_139;
    zT_33EF6BFB_TypeKind zT_140;
    zT_338B7C76_TypeRegistry* zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_149 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    zT_3C598AEF_SymbolKind zT_156;
    unsigned int zT_161;
    zT_3D7259E2_SymbolRegistry* zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    zT_567DA1C3_Opt_868 zT_167 = {0};
    unsigned char zT_168;
    unsigned char* zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned short zT_176;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    zT_3C598AEF_SymbolKind zT_184;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    unsigned short zT_199;
    zT_3C598AEF_SymbolKind zT_204;
    zT_8EED1867_ResolvedTypeTable* zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned int zT_213;
    unsigned int zT_214;
    zT_8EED1867_ResolvedTypeTable* zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned int zT_222;
    zT_3C598AEF_SymbolKind zT_223;
    unsigned char zT_227;
    unsigned int zT_228;
    unsigned char* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    zT_6B0A7D14_AstStore* zT_237;
    unsigned int zT_238;
    zT_22A7C88B_AstNode zT_241 = {0};
    zT_8143F551_AstKind zT_242;
    zT_6B0A7D14_AstStore* zT_247;
    zT_9C1673CC_anon_238694 zT_248;
    zT_243D6A41_FnProto* zT_249;
    zT_6B0A7D14_AstStore* zT_250;
    unsigned int zT_251;
    unsigned int zT_254 = 0;
    unsigned int zT_255;
    zT_243D6A41_FnProto zT_256;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned int zT_262;
    unsigned int zT_264;
    zT_8EED1867_ResolvedTypeTable* zT_268;
    unsigned int zT_269;
    zT_BAEE192E_Opt_10 zT_272 = {0};
    unsigned char zT_274;
    unsigned int zT_275;
    unsigned char* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    unsigned char zT_284;
    zT_338B7C76_TypeRegistry* zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    unsigned int zT_292;
    unsigned short zT_293;
    unsigned int zT_294;
    unsigned char zT_295;
    unsigned int zT_304 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    zT_ABC1EBBE_TypeResolveEnv zT_310;
    zT_6B0A7D14_AstStore* zT_311;
    zT_338B7C76_TypeRegistry* zT_312;
    zT_3D7259E2_SymbolRegistry* zT_313;
    zT_D3EB6303_StringInterner* zT_314;
    unsigned int zT_315;
    zT_F85C5DED_DiagnosticCollector* zT_316;
    zT_7034F045_Opt_228 zT_317;
    zT_03B97CED_Opt_398 zT_318 = {0};
    zT_05CE5599_Opt_400 zT_319 = {0};
    unsigned int zT_320;
    zT_ABC1EBBE_TypeResolveEnv* zT_322;
    unsigned int zT_323;
    unsigned int zT_328 = 0;
    unsigned char* zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    unsigned char* zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned int zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned int zT_341;
    zT_8EED1867_ResolvedTypeTable* zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    zT_338B7C76_TypeRegistry* zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_355;
    unsigned short zT_356;
    unsigned int zT_357;
    unsigned char zT_358;
    unsigned int zT_367 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_368;
    unsigned int zT_369;
    unsigned int zT_370;
    unsigned char* zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_374;
    unsigned int zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    zT_338B7C76_TypeRegistry* zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned int zT_383;
    unsigned short zT_384;
    unsigned char zT_386;
    unsigned int zT_396 = 0;
    unsigned char* zT_398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_399;
    unsigned int zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_401;
    unsigned int zT_402;
    zT_8EED1867_ResolvedTypeTable* zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned char* zT_408;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_409;
    unsigned int zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_412;
    zT_8EED1867_ResolvedTypeTable* zT_413;
    unsigned int zT_414;
    zT_8EED1867_ResolvedTypeTable* zT_421;
    unsigned int zT_422;
    zT_8143F551_AstKind zT_427;
    zT_6B0A7D14_AstStore* zT_432;
    unsigned int zT_433;
    unsigned int zT_436 = 0;
    zT_072B53A6_ModuleRegistry* zT_438;
    unsigned int zT_439;
    zT_BAEE192E_Opt_10 zT_441 = {0};
    unsigned char zT_442;
    zT_3D7259E2_SymbolRegistry* zT_445;
    unsigned int zT_446;
    unsigned int zT_447;
    zT_567DA1C3_Opt_868 zT_449 = {0};
    unsigned char zT_450;
    unsigned short zT_452;
    zT_3C598AEF_SymbolKind zT_457;
    zT_8EED1867_ResolvedTypeTable* zT_461;
    unsigned int zT_462;
    unsigned int zT_463;
    unsigned int zT_466;
    unsigned int zT_467;
    zT_8EED1867_ResolvedTypeTable* zT_470;
    unsigned int zT_471;
    unsigned int zT_472;
    unsigned int zT_475;
    zT_38C12417_SemanticAnalyzer* zT_477;
    unsigned int zT_478;
    unsigned int zT_480 = 0;
    unsigned char* zT_484;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_485;
    unsigned int zT_486;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_487;
    zT_8EED1867_ResolvedTypeTable* zT_488;
    unsigned int zT_489;
    zT_338B7C76_TypeRegistry* zT_495;
    zT_D155D06D_Type* zT_496;
    unsigned int zT_497;
    zT_D155D06D_Type zT_498;
    int zT_500;
    unsigned int zT_501;
    int zT_503;
    unsigned int zT_504;
    zT_33EF6BFB_TypeKind zT_505;
    unsigned char zT_509;
    zT_33EF6BFB_TypeKind zT_510;
    zT_33EF6BFB_TypeKind zT_515;
    zT_338B7C76_TypeRegistry* zT_516;
    zT_112BF819_PtrPayload* zT_517;
    unsigned int zT_518;
    unsigned int zT_519;
    zT_112BF819_PtrPayload zT_520;
    unsigned int zT_521;
    zT_338B7C76_TypeRegistry* zT_522;
    zT_D155D06D_Type* zT_523;
    unsigned int zT_524;
    zT_D155D06D_Type zT_525;
    unsigned char* zT_527;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_528;
    unsigned int zT_529;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_530;
    unsigned char* zT_534;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_535;
    unsigned int zT_536;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_537;
    zT_33EF6BFB_TypeKind zT_539;
    unsigned char* zT_542;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_543;
    unsigned int zT_544;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_545;
    unsigned char* zT_550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_551;
    unsigned int zT_552;
    zT_D3EB6303_StringInterner* zT_554;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_555;
    unsigned int zT_557 = 0;
    unsigned char* zT_560;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_561;
    unsigned int zT_562;
    zT_F85C5DED_DiagnosticCollector* zT_563;
    unsigned int zT_566;
    unsigned int zT_567;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_569;
    unsigned int zT_575;
    unsigned int zT_576;
    unsigned int zT_579 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_580;
    unsigned int zT_581;
    zT_33EF6BFB_TypeKind zT_586;
    unsigned int zT_591;
    unsigned int zT_593;
    unsigned int zT_595;
    unsigned char* zT_597;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_598;
    unsigned int zT_599;
    zT_F85C5DED_DiagnosticCollector* zT_600;
    unsigned int zT_603;
    unsigned int zT_604;
    unsigned int zT_605;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_606;
    unsigned int zT_611 = 0;
    zT_33EF6BFB_TypeKind zT_613;
    unsigned int zT_618;
    unsigned int zT_620;
    unsigned int zT_622;
    unsigned char* zT_624;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_625;
    unsigned int zT_626;
    zT_F85C5DED_DiagnosticCollector* zT_627;
    unsigned int zT_630;
    unsigned int zT_631;
    unsigned int zT_632;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_633;
    unsigned int zT_638 = 0;
    zT_33EF6BFB_TypeKind zT_640;
    zT_338B7C76_TypeRegistry* zT_645;
    zT_406493CE_StructPayload* zT_646;
    unsigned int zT_647;
    unsigned int zT_648;
    zT_406493CE_StructPayload zT_649;
    unsigned int zT_650;
    unsigned int zT_651;
    unsigned short zT_652;
    unsigned int zT_653;
    zT_33EF6BFB_TypeKind zT_654;
    unsigned char zT_658;
    zT_33EF6BFB_TypeKind zT_659;
    zT_338B7C76_TypeRegistry* zT_664;
    zT_AF9231A2_UnionPayload* zT_665;
    unsigned int zT_666;
    unsigned int zT_667;
    zT_AF9231A2_UnionPayload zT_668;
    unsigned int zT_669;
    unsigned int zT_670;
    unsigned short zT_671;
    unsigned int zT_672;
    zT_33EF6BFB_TypeKind zT_673;
    zT_338B7C76_TypeRegistry* zT_678;
    zT_54FF90FA_TaggedUnionPayload* zT_679;
    unsigned int zT_680;
    unsigned int zT_681;
    zT_54FF90FA_TaggedUnionPayload zT_682;
    unsigned char* zT_684;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_685;
    unsigned int zT_686;
    zT_D3EB6303_StringInterner* zT_688;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_689;
    unsigned int zT_691 = 0;
    unsigned char* zT_694;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_695;
    unsigned int zT_696;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_697;
    zT_8EED1867_ResolvedTypeTable* zT_698;
    unsigned int zT_699;
    unsigned int zT_700;
    unsigned int zT_703;
    unsigned char* zT_705;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_706;
    unsigned int zT_707;
    zT_D3EB6303_StringInterner* zT_709;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_710;
    unsigned int zT_712 = 0;
    unsigned short zT_715;
    unsigned int zT_716;
    int zT_718;
    unsigned int zT_719;
    zT_338B7C76_TypeRegistry* zT_722;
    zT_2DF01B61_FieldEntry* zT_723;
    unsigned int zT_724;
    unsigned int zT_726;
    zT_2DF01B61_FieldEntry zT_727;
    unsigned int zT_728;
    unsigned int zT_732;
    zT_338B7C76_TypeRegistry* zT_734;
    zT_D155D06D_Type* zT_735;
    unsigned int zT_736;
    zT_D155D06D_Type zT_737;
    zT_33EF6BFB_TypeKind zT_738;
    zT_338B7C76_TypeRegistry* zT_743;
    zT_E834303C_ArrayPayload* zT_744;
    unsigned int zT_745;
    unsigned int zT_746;
    zT_E834303C_ArrayPayload zT_747;
    unsigned int zT_748;
    zT_338B7C76_TypeRegistry* zT_749;
    unsigned int zT_750;
    unsigned int zT_754 = 0;
    unsigned char* zT_756;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    zT_8EED1867_ResolvedTypeTable* zT_760;
    unsigned int zT_761;
    unsigned int zT_762;
    int zT_764;
    unsigned int zT_766;
    unsigned int zT_767;
    unsigned int zT_768;
    unsigned short zT_769;
    unsigned int zT_770;
    zT_33EF6BFB_TypeKind zT_771;
    unsigned char* zT_776;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_777;
    unsigned int zT_778;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_779;
    zT_3D7259E2_SymbolRegistry* zT_781;
    unsigned int zT_782;
    unsigned int zT_783;
    zT_567DA1C3_Opt_868 zT_786 = {0};
    unsigned char zT_787;
    unsigned int zT_789;
    unsigned char* zT_793;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_794;
    unsigned int zT_795;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_796;
    zT_8EED1867_ResolvedTypeTable* zT_797;
    unsigned int zT_798;
    unsigned int zT_799;
    unsigned int zT_802;
    zT_3C598AEF_SymbolKind zT_803;
    zT_8EED1867_ResolvedTypeTable* zT_808;
    unsigned int zT_809;
    zT_BAEE192E_Opt_10 zT_812 = {0};
    unsigned char zT_813;
    unsigned char* zT_816;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_817;
    unsigned int zT_818;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_819;
    zT_8EED1867_ResolvedTypeTable* zT_820;
    unsigned int zT_821;
    unsigned int zT_822;
    unsigned char* zT_825;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_826;
    unsigned int zT_827;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_828;
    zT_6B0A7D14_AstStore* zT_830;
    unsigned int zT_831;
    zT_22A7C88B_AstNode zT_834 = {0};
    zT_8143F551_AstKind zT_835;
    zT_6B0A7D14_AstStore* zT_840;
    zT_9C1673CC_anon_238694 zT_841;
    zT_243D6A41_FnProto* zT_842;
    zT_6B0A7D14_AstStore* zT_843;
    unsigned int zT_844;
    unsigned int zT_847 = 0;
    unsigned int zT_848;
    zT_243D6A41_FnProto zT_849;
    unsigned char* zT_851;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_852;
    unsigned int zT_853;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_854;
    unsigned int zT_856;
    unsigned int zT_858;
    zT_8EED1867_ResolvedTypeTable* zT_862;
    unsigned int zT_863;
    zT_BAEE192E_Opt_10 zT_866 = {0};
    unsigned char zT_867;
    zT_338B7C76_TypeRegistry* zT_870;
    unsigned int zT_871;
    unsigned int zT_872;
    unsigned int zT_875;
    unsigned short zT_876;
    unsigned int zT_877;
    unsigned char zT_878;
    unsigned int zT_887 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_888;
    unsigned int zT_889;
    unsigned int zT_890;
    zT_ABC1EBBE_TypeResolveEnv zT_893;
    zT_6B0A7D14_AstStore* zT_894;
    zT_338B7C76_TypeRegistry* zT_895;
    zT_3D7259E2_SymbolRegistry* zT_896;
    zT_D3EB6303_StringInterner* zT_897;
    unsigned int zT_898;
    zT_F85C5DED_DiagnosticCollector* zT_899;
    zT_7034F045_Opt_228 zT_900;
    zT_03B97CED_Opt_398 zT_901 = {0};
    zT_05CE5599_Opt_400 zT_902 = {0};
    unsigned int zT_903;
    zT_ABC1EBBE_TypeResolveEnv* zT_905;
    unsigned int zT_906;
    unsigned int zT_911 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_914;
    unsigned int zT_915;
    unsigned int zT_916;
    zT_338B7C76_TypeRegistry* zT_920;
    unsigned int zT_921;
    unsigned int zT_922;
    unsigned int zT_925;
    unsigned short zT_926;
    unsigned int zT_927;
    unsigned char zT_928;
    unsigned int zT_937 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_938;
    unsigned int zT_939;
    unsigned int zT_940;
    zT_338B7C76_TypeRegistry* zT_943;
    unsigned int zT_944;
    unsigned int zT_945;
    unsigned int zT_948;
    unsigned short zT_949;
    unsigned char zT_951;
    unsigned int zT_961 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_962;
    unsigned int zT_963;
    unsigned int zT_964;
    unsigned char* zT_967;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_968;
    unsigned int zT_969;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_970;
    zT_3C598AEF_SymbolKind zT_972;
    unsigned char* zT_975;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_976;
    unsigned int zT_977;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_978;
    zT_8EED1867_ResolvedTypeTable* zT_979;
    unsigned int zT_980;
    zT_33EF6BFB_TypeKind zT_985;
    zT_338B7C76_TypeRegistry* zT_990;
    zT_0BB2A741_SlicePayload* zT_991;
    unsigned int zT_992;
    unsigned int zT_993;
    zT_0BB2A741_SlicePayload zT_994;
    unsigned char* zT_996;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_997;
    unsigned int zT_998;
    zT_D3EB6303_StringInterner* zT_1000;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1001;
    unsigned int zT_1003 = 0;
    unsigned char* zT_1006;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1007;
    unsigned int zT_1008;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1009;
    zT_8EED1867_ResolvedTypeTable* zT_1010;
    unsigned int zT_1011;
    unsigned char* zT_1017;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1018;
    unsigned int zT_1019;
    zT_D3EB6303_StringInterner* zT_1021;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1022;
    unsigned int zT_1024 = 0;
    zT_338B7C76_TypeRegistry* zT_1027;
    unsigned int zT_1028;
    unsigned char zT_1032;
    unsigned int zT_1037 = 0;
    unsigned char* zT_1039;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1040;
    unsigned int zT_1041;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1042;
    zT_8EED1867_ResolvedTypeTable* zT_1043;
    unsigned int zT_1044;
    unsigned int zT_1045;
    zT_33EF6BFB_TypeKind zT_1047;
    unsigned char* zT_1052;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1053;
    unsigned int zT_1054;
    zT_D3EB6303_StringInterner* zT_1056;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1057;
    unsigned int zT_1059 = 0;
    unsigned char* zT_1062;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1063;
    unsigned int zT_1064;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1065;
    zT_8EED1867_ResolvedTypeTable* zT_1066;
    unsigned int zT_1067;
    zT_33EF6BFB_TypeKind zT_1072;
    zT_338B7C76_TypeRegistry* zT_1077;
    unsigned int zT_1078;
    unsigned int zT_1079;
    unsigned int zT_1081 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_1084;
    unsigned int zT_1085;
    unsigned int zT_1086;
    zT_8EED1867_ResolvedTypeTable* zT_1088;
    unsigned int zT_1089;
    zT_33EF6BFB_TypeKind zT_1094;
    zT_338B7C76_TypeRegistry* zT_1099;
    zT_457ECFEE_EnumPayload* zT_1100;
    unsigned int zT_1101;
    unsigned int zT_1102;
    zT_457ECFEE_EnumPayload zT_1103;
    unsigned int zT_1105;
    unsigned int zT_1106;
    unsigned short zT_1108;
    unsigned int zT_1109;
    int zT_1111;
    unsigned int zT_1112;
    zT_338B7C76_TypeRegistry* zT_1114;
    zT_D96DCDF2_EnumMember* zT_1115;
    unsigned int zT_1116;
    zT_D96DCDF2_EnumMember zT_1117;
    unsigned int zT_1118;
    zT_8EED1867_ResolvedTypeTable* zT_1120;
    unsigned int zT_1121;
    unsigned int zT_1122;
    int zT_1124;
    unsigned int zT_1126;
    unsigned char* zT_1128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1129;
    unsigned int zT_1130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1131;
    zT_8EED1867_ResolvedTypeTable* zT_1132;
    unsigned int zT_1133;
    unsigned char* zT_1139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1140;
    unsigned int zT_1141;
    zT_D3EB6303_StringInterner* zT_1143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1144;
    unsigned int zT_1146 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1149;
    unsigned int zT_1150;
    unsigned int zT_1152 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_1155;
    unsigned int zT_1156;
    unsigned int zT_1157;
    unsigned char* zT_1160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1161;
    unsigned int zT_1162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1163;
    zT_8EED1867_ResolvedTypeTable* zT_1164;
    unsigned int zT_1165;
    int zT_1171;
    unsigned int zT_1172;
    zT_338B7C76_TypeRegistry* zT_1175;
    zT_2DF01B61_FieldEntry* zT_1176;
    unsigned int zT_1177;
    zT_2DF01B61_FieldEntry zT_1178;
    unsigned int zT_1179;
    unsigned int zT_1182;
    zT_338B7C76_TypeRegistry* zT_1184;
    zT_D155D06D_Type* zT_1185;
    unsigned int zT_1186;
    zT_D155D06D_Type zT_1187;
    zT_33EF6BFB_TypeKind zT_1188;
    zT_338B7C76_TypeRegistry* zT_1193;
    zT_E834303C_ArrayPayload* zT_1194;
    unsigned int zT_1195;
    unsigned int zT_1196;
    zT_E834303C_ArrayPayload zT_1197;
    unsigned int zT_1198;
    zT_338B7C76_TypeRegistry* zT_1199;
    unsigned int zT_1200;
    unsigned int zT_1204 = 0;
    unsigned char* zT_1206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1207;
    unsigned int zT_1208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1209;
    unsigned int zT_1210;
    zT_8EED1867_ResolvedTypeTable* zT_1211;
    unsigned int zT_1212;
    unsigned int zT_1213;
    int zT_1215;
    unsigned int zT_1217;
    unsigned char* zT_1219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1220;
    unsigned int zT_1221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1222;
    unsigned char* zT_1224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1225;
    unsigned int zT_1226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1227;
    unsigned int zT_1228;
    unsigned char* zT_1230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1231;
    unsigned int zT_1232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1233;
    unsigned int zT_1234;
    unsigned char* zT_1236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1237;
    unsigned int zT_1238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1239;
    unsigned int zT_1240;
    zT_8EED1867_ResolvedTypeTable* zT_1241;
    unsigned int zT_1242;
    zT_8F083A69_Slice_zT_0B42B2F8_u fae;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode base_node;
    unsigned int field_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_bkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_fnm;
    unsigned int base_rt;
    unsigned int base_ident_id;
    zT_567DA1C3_Opt_868 sym;
    unsigned int base_type_id;
    zT_3A105EF1_Symbol* s;
    unsigned int alias_type_id;
    zT_D155D06D_Type aty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int fi;
    zT_457ECFEE_EnumPayload ep;
    unsigned int estart;
    unsigned int ecount;
    unsigned int ei;
    unsigned int es_mi;
    unsigned int target_mod;
    zT_567DA1C3_Opt_868 field_sym;
    zT_3A105EF1_Symbol* fs;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1kl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1tl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1v_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fx;
    zT_22A7C88B_AstNode fn_dn;
    zT_243D6A41_FnProto proto;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre1_m;
    zT_BAEE192E_Opt_10 rtt;
    unsigned int rtt_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre3_m;
    unsigned int fn_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre4_m;
    unsigned int rv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre2_m;
    unsigned int rtv;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int resolved_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr1_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr2_m;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fa1;
    zT_D155D06D_Type base_ty;
    unsigned int fields_start;
    unsigned int fields_count;
    zT_33EF6BFB_TypeKind pre_kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_ok_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_dk_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u mpl_len_s;
    unsigned int mpl_len_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u mpl_msg;
    unsigned int sp;
    unsigned int ep_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u opt_msg;
    unsigned int ep_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u eu_msg;
    zT_406493CE_StructPayload sp_3;
    zT_AF9231A2_UnionPayload up;
    zT_8F083A69_Slice_zT_0B42B2F8_u tag_s;
    unsigned int tag_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ft_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u payload_s;
    unsigned int payload_id;
    unsigned int fpe_count;
    unsigned int fpei;
    zT_2DF01B61_FieldEntry fpe;
    unsigned int payload_res;
    zT_D155D06D_Type payload_rt;
    unsigned int payload_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpe_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfa;
    zT_567DA1C3_Opt_868 mod_field_sym;
    zT_3A105EF1_Symbol* mfs;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf3;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf1;
    zT_BAEE192E_Opt_10 fn_tid_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf2_m;
    unsigned int fn_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u mff;
    zT_22A7C88B_AstNode dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfp_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_b;
    unsigned int resolved_rt_b;
    zT_0BB2A741_SlicePayload sp_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u len_s;
    unsigned int len_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsl;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptr_s;
    unsigned int ptr_id;
    unsigned int pty;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u faa_m;
    unsigned int es_mi2;
    zT_457ECFEE_EnumPayload ep3;
    unsigned int estart3;
    unsigned int ecount3;
    unsigned int ei3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf;
    unsigned int afl_ty;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2b_m;
    unsigned int result;
    zT_D155D06D_Type rt;
    unsigned int elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_3 = "FAE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fae = zT_4;
    zT_6 = fae;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    base_node = zT_17;
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    field_name_id = zT_22;
    zT_24 = "PFA:BK";
    zT_26 = 6;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    pfa_bkm = zT_25;
    zT_27 = pfa_bkm;
    zT_29 = base_node.kind;
    zF_C914CB83_markerWriteInt(zT_27, (unsigned int)((unsigned int)zT_29));
    zT_32 = "PFA:FN";
    zT_34 = 6;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    pfa_fnm = zT_33;
    zT_35 = pfa_fnm;
    zT_36 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_35, zT_36);
    zT_37 = base_node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_42 = self;
    zT_43 = node.child_0;
    zT_45 = zF_54F95822_semanticAnalyzerRes(zT_42, zT_43);
    base_rt = zT_45;
    zT_47 = self->store;
    zT_48 = node.child_0;
    zT_51 = zF_53458827_astStoreIdentifier(zT_47, zT_48);
    base_ident_id = zT_51;
    zT_53 = self->symbols;
    zT_54 = self->module_id;
    zT_55 = base_ident_id;
    zT_58 = zF_A398987E_symbolRegistryQuali(zT_53, zT_54, zT_55);
    sym = zT_58;
    zT_59 = sym.has_value;
    if (zT_59) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_477 = self;
    zT_478 = node.child_0;
    zT_480 = zF_54F95822_semanticAnalyzerRes(zT_477, zT_478);
    base_type_id = zT_480;
    if ((unsigned char)(base_type_id == (unsigned int)(1))) goto z_bb_71; else goto z_bb_72;
    z_bb_3:
    zT_427 = base_node.kind;
    if ((unsigned char)(zT_427 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_59; else goto z_bb_60;
    z_bb_4:
    s = sym.value;
    zT_61 = s->kind;
    if ((unsigned char)(zT_61 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    if ((unsigned char)(base_rt == (unsigned int)(1))) goto z_bb_57; else goto z_bb_58;
    z_bb_7:
    zT_66 = s->type_id;
    alias_type_id = zT_66;
    if ((unsigned char)(alias_type_id != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_156 = s->kind;
    if ((unsigned char)(zT_156 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_31; else goto z_bb_32;
    z_bb_9:
    zT_70 = self->registry;
    zT_71 = zT_70->types_items;
    zT_72 = (unsigned int)alias_type_id;
    zT_73 = zT_71[zT_72];
    aty = zT_73;
    zT_74 = aty.kind;
    if ((unsigned char)(zT_74 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_79 = self->registry;
    zT_80 = zT_79->tu_items;
    zT_81 = aty.payload_idx;
    zT_82 = (unsigned int)zT_81;
    zT_83 = zT_80[zT_82];
    tp = zT_83;
    zT_85 = tp.fields_start;
    zT_86 = (unsigned int)zT_85;
    fstart = zT_86;
    zT_88 = tp.fields_count;
    zT_89 = (unsigned int)zT_88;
    fcount = zT_89;
    zT_91 = 0;
    zT_92 = (unsigned int)zT_91;
    fi = zT_92;
    goto z_bb_13;
    z_bb_12:
    zT_107 = aty.kind;
    if ((unsigned char)(zT_107 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    if ((unsigned char)(fi < fcount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_94 = self->registry;
    zT_95 = zT_94->fe_items;
    zT_96 = fstart + fi;
    zT_97 = zT_95[zT_96];
    zT_98 = zT_97.name_id;
    if ((unsigned char)(zT_98 == field_name_id)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_104 = 1;
    zT_106 = fi + (unsigned int)((unsigned int)zT_104);
    fi = zT_106;
    goto z_bb_13;
    z_bb_17:
    zT_100 = self->type_table;
    zT_101 = node_idx;
    zT_102 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_100, zT_101, zT_102);
    return alias_type_id;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_112 = self->registry;
    zT_113 = zT_112->en_items;
    zT_114 = aty.payload_idx;
    zT_115 = (unsigned int)zT_114;
    zT_116 = zT_113[zT_115];
    ep = zT_116;
    zT_118 = ep.members_start;
    zT_119 = (unsigned int)zT_118;
    estart = zT_119;
    zT_121 = ep.members_count;
    zT_122 = (unsigned int)zT_121;
    ecount = zT_122;
    zT_124 = 0;
    zT_125 = (unsigned int)zT_124;
    ei = zT_125;
    goto z_bb_21;
    z_bb_20:
    zT_140 = aty.kind;
    if ((unsigned char)(zT_140 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    if ((unsigned char)(ei < ecount)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_127 = self->registry;
    zT_128 = zT_127->em_items;
    zT_129 = estart + ei;
    zT_130 = zT_128[zT_129];
    zT_131 = zT_130.name_id;
    if ((unsigned char)(zT_131 == field_name_id)) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_137 = 1;
    zT_139 = ei + (unsigned int)((unsigned int)zT_137);
    ei = zT_139;
    goto z_bb_21;
    z_bb_25:
    zT_133 = self->type_table;
    zT_134 = node_idx;
    zT_135 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_133, zT_134, zT_135);
    return alias_type_id;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_145 = self->registry;
    zT_146 = alias_type_id;
    zT_147 = field_name_id;
    zT_149 = zF_D2ECD176_typeRegistryErrorSe(zT_145, zT_146, zT_147);
    es_mi = zT_149;
    if ((unsigned char)(es_mi != (unsigned int)(4294967295u))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    zT_152 = self->type_table;
    zT_153 = node_idx;
    zT_154 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_152, zT_153, zT_154);
    return alias_type_id;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_161 = s->module_id;
    target_mod = zT_161;
    zT_163 = self->symbols;
    zT_164 = target_mod;
    zT_165 = field_name_id;
    zT_167 = zF_A398987E_symbolRegistryQuali(zT_163, zT_164, zT_165);
    field_sym = zT_167;
    zT_168 = field_sym.has_value;
    if (zT_168) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_5;
    z_bb_33:
    fs = field_sym.value;
    zT_171 = "Q1:FL";
    zT_173 = 5;
    zT_172.ptr = zT_171;
    zT_172.len = zT_173;
    q1fl_m = zT_172;
    zT_174 = q1fl_m;
    zT_176 = fs->flags;
    zF_C914CB83_markerWriteInt(zT_174, (unsigned int)((unsigned int)zT_176));
    zT_179 = "Q1:KL";
    zT_181 = 5;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    q1kl_m = zT_180;
    zT_182 = q1kl_m;
    zT_184 = fs->kind;
    zF_C914CB83_markerWriteInt(zT_182, (unsigned int)((unsigned int)zT_184));
    zT_187 = "Q1:TL";
    zT_189 = 5;
    zT_188.ptr = zT_187;
    zT_188.len = zT_189;
    q1tl_m = zT_188;
    zT_190 = q1tl_m;
    zT_191 = fs->type_id;
    zF_C914CB83_markerWriteInt(zT_190, zT_191);
    zT_194 = "Q1:FN";
    zT_196 = 5;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    q1fn_m = zT_195;
    zT_197 = q1fn_m;
    zT_198 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_197, zT_198);
    zT_199 = fs->flags;
    if ((unsigned char)((unsigned short)(zT_199 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_408 = "Q1VF:FN";
    zT_410 = 7;
    zT_409.ptr = zT_408;
    zT_409.len = zT_410;
    q1v_m = zT_409;
    zT_411 = q1v_m;
    zT_412 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_411, zT_412);
    zT_413 = self->type_table;
    zT_414 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_413, zT_414, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_35:
    zT_204 = fs->kind;
    if ((unsigned char)(zT_204 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_223 = fs->kind;
    if ((unsigned char)(zT_223 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_41; else goto z_bb_42;
    z_bb_37:
    zT_208 = self->type_table;
    zT_209 = node_idx;
    zT_210 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_208, zT_209, zT_210);
    zT_213 = fs->type_id;
    return zT_213;
    z_bb_38:
    zT_214 = fs->type_id;
    if ((unsigned char)(zT_214 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_217 = self->type_table;
    zT_218 = node_idx;
    zT_219 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_217, zT_218, zT_219);
    zT_222 = fs->type_id;
    return zT_222;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_228 = fs->decl_node;
    zT_227 = zT_228 != (unsigned int)(0);
    goto z_bb_43;
    z_bb_42:
    zT_227 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_227) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_232 = "Q1FX\n";
    zT_234 = 5;
    zT_233.ptr = zT_232;
    zT_233.len = zT_234;
    q1fx = zT_233;
    zT_235 = q1fx;
    zF_48AC7B3A_markerWrite(zT_235);
    zT_237 = self->store;
    zT_238 = fs->decl_node;
    zT_241 = zF_FCDD1D35_astStoreNodeAt(zT_237, zT_238);
    fn_dn = zT_241;
    zT_242 = fn_dn.kind;
    if ((unsigned char)(zT_242 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_34;
    z_bb_46:
    zT_247 = self->store;
    zT_248 = zT_247->fn_protos;
    zT_249 = zT_248.items;
    zT_250 = self->store;
    zT_251 = fs->decl_node;
    zT_254 = zF_8BA26B9E_astStoreNodePayload(zT_250, zT_251);
    zT_255 = (unsigned int)zT_254;
    zT_256 = zT_249[zT_255];
    proto = zT_256;
    zT_258 = "BR:x";
    zT_260 = 4;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    bre1_m = zT_259;
    zT_261 = bre1_m;
    zT_262 = proto.name_id;
    zF_C914CB83_markerWriteInt(zT_261, zT_262);
    zT_264 = proto.return_type_node;
    if ((unsigned char)(zT_264 != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_268 = self->type_table;
    zT_269 = proto.return_type_node;
    zT_272 = zF_999DCF51_resolvedTypeTableGe(zT_268, zT_269);
    rtt = zT_272;
    zT_274 = rtt.has_value;
    if (zT_274) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    zT_373 = "BR:dv\n";
    zT_375 = 6;
    zT_374.ptr = zT_373;
    zT_374.len = zT_375;
    bre3_m = zT_374;
    zT_376 = bre3_m;
    zF_48AC7B3A_markerWrite(zT_376);
    zT_378 = self->registry;
    zT_379 = proto.name_id;
    zT_380 = fs->module_id;
    zT_383 = proto.params_start;
    zT_384 = proto.params_count;
    zT_386 = proto.call_conv;
    zT_396 = zF_474336D7_typeRegistryGetOrCr(zT_378, zT_379, zT_380, (unsigned char)(0), (unsigned char)(0), zT_383, zT_384, (unsigned int)(1), zT_386);
    fn_ty = zT_396;
    zT_398 = "BR:ft";
    zT_400 = 5;
    zT_399.ptr = zT_398;
    zT_399.len = zT_400;
    bre4_m = zT_399;
    zT_401 = bre4_m;
    zT_402 = fn_ty;
    zF_C914CB83_markerWriteInt(zT_401, zT_402);
    zT_403 = self->type_table;
    zT_404 = node_idx;
    zT_405 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_403, zT_404, zT_405);
    return fn_ty;
    z_bb_50:
    rv = rtt.value;
    zT_275 = rv;
    goto z_bb_52;
    z_bb_51:
    zT_275 = 0;
    goto z_bb_52;
    z_bb_52:
    rtt_val = zT_275;
    zT_279 = "BR:rt";
    zT_281 = 5;
    zT_280.ptr = zT_279;
    zT_280.len = zT_281;
    bre2_m = zT_280;
    zT_282 = bre2_m;
    zT_283 = rtt_val;
    zF_C914CB83_markerWriteInt(zT_282, zT_283);
    zT_284 = rtt.has_value;
    if (zT_284) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    rtv = rtt.value;
    zT_287 = self->registry;
    zT_288 = proto.name_id;
    zT_289 = fs->module_id;
    zT_292 = proto.params_start;
    zT_293 = proto.params_count;
    zT_294 = rtv;
    zT_295 = proto.call_conv;
    zT_304 = zF_474336D7_typeRegistryGetOrCr(zT_287, zT_288, zT_289, (unsigned char)(0), (unsigned char)(0), zT_292, zT_293, zT_294, zT_295);
    fn_ty = zT_304;
    zT_305 = self->type_table;
    zT_306 = node_idx;
    zT_307 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_305, zT_306, zT_307);
    return fn_ty;
    z_bb_54:
    zT_311 = self->store;
    zT_310.store = zT_311;
    zT_312 = self->registry;
    zT_310.typereg = zT_312;
    zT_313 = self->symbols;
    zT_310.symbol_reg = zT_313;
    zT_314 = self->interner;
    zT_310.interner = zT_314;
    zT_315 = fs->module_id;
    zT_310.module_id = zT_315;
    zT_316 = self->diag;
    zT_317.has_value = 1;
    zT_317.value = zT_316;
    zT_310.diag = zT_317;
    zT_318.has_value = 0;
    zT_310.local_consts = zT_318;
    zT_319.has_value = 0;
    zT_310.local_types = zT_319;
    zT_320 = self->source_file_id;
    zT_310.source_file_id = zT_320;
    tre_env = zT_310;
    zT_322 = &tre_env;
    zT_323 = proto.return_type_node;
    zT_328 = zF_F2107C15_resolveTypeExprFull(zT_322, zT_323, (unsigned int)(0));
    resolved_rt = zT_328;
    zT_330 = "BR:treN";
    zT_332 = 7;
    zT_331.ptr = zT_330;
    zT_331.len = zT_332;
    brr1_m = zT_331;
    zT_333 = brr1_m;
    zT_334 = proto.return_type_node;
    zF_C914CB83_markerWriteInt(zT_333, zT_334);
    zT_337 = "BR:treT";
    zT_339 = 7;
    zT_338.ptr = zT_337;
    zT_338.len = zT_339;
    brr2_m = zT_338;
    zT_340 = brr2_m;
    zT_341 = resolved_rt;
    zF_C914CB83_markerWriteInt(zT_340, zT_341);
    if ((unsigned char)(resolved_rt != (unsigned int)(18))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_344 = self->type_table;
    zT_345 = proto.return_type_node;
    zT_346 = resolved_rt;
    zF_19B4A07D_resolvedTypeTableSe(zT_344, zT_345, zT_346);
    zT_350 = self->registry;
    zT_351 = proto.name_id;
    zT_352 = fs->module_id;
    zT_355 = proto.params_start;
    zT_356 = proto.params_count;
    zT_357 = resolved_rt;
    zT_358 = proto.call_conv;
    zT_367 = zF_474336D7_typeRegistryGetOrCr(zT_350, zT_351, zT_352, (unsigned char)(0), (unsigned char)(0), zT_355, zT_356, zT_357, zT_358);
    fn_ty = zT_367;
    zT_368 = self->type_table;
    zT_369 = node_idx;
    zT_370 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_368, zT_369, zT_370);
    return fn_ty;
    z_bb_56:
    goto z_bb_49;
    z_bb_57:
    zT_421 = self->type_table;
    zT_422 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_421, zT_422, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_58:
    goto z_bb_5;
    z_bb_59:
    zT_432 = self->store;
    zT_433 = node.child_0;
    zT_436 = zF_8BA26B9E_astStoreNodePayload(zT_432, zT_433);
    path_id = zT_436;
    zT_438 = self->module_reg;
    zT_439 = path_id;
    zT_441 = zF_A258E183_moduleRegistryPathT(zT_438, zT_439);
    target = zT_441;
    zT_442 = target.has_value;
    if (zT_442) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_2;
    z_bb_61:
    mtid = target.value;
    zT_445 = self->symbols;
    zT_446 = mtid;
    zT_447 = field_name_id;
    zT_449 = zF_A398987E_symbolRegistryQuali(zT_445, zT_446, zT_447);
    field_sym = zT_449;
    zT_450 = field_sym.has_value;
    if (zT_450) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    fs = field_sym.value;
    zT_452 = fs->flags;
    if ((unsigned char)((unsigned short)(zT_452 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    zT_457 = fs->kind;
    if ((unsigned char)(zT_457 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_461 = self->type_table;
    zT_462 = node_idx;
    zT_463 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_461, zT_462, zT_463);
    zT_466 = fs->type_id;
    return zT_466;
    z_bb_68:
    zT_467 = fs->type_id;
    if ((unsigned char)(zT_467 != (unsigned int)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_470 = self->type_table;
    zT_471 = node_idx;
    zT_472 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_470, zT_471, zT_472);
    zT_475 = fs->type_id;
    return zT_475;
    z_bb_70:
    goto z_bb_66;
    z_bb_71:
    zT_484 = "FB\n";
    zT_486 = 3;
    zT_485.ptr = zT_484;
    zT_485.len = zT_486;
    fa1 = zT_485;
    zT_487 = fa1;
    zF_48AC7B3A_markerWrite(zT_487);
    zT_488 = self->type_table;
    zT_489 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_488, zT_489, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_72:
    zT_495 = self->registry;
    zT_496 = zT_495->types_items;
    zT_497 = (unsigned int)base_type_id;
    zT_498 = zT_496[zT_497];
    base_ty = zT_498;
    zT_500 = 0;
    zT_501 = (unsigned int)zT_500;
    fields_start = zT_501;
    zT_503 = 0;
    zT_504 = (unsigned int)zT_503;
    fields_count = zT_504;
    zT_505 = base_ty.kind;
    if ((unsigned char)(zT_505 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_510 = base_ty.kind;
    zT_509 = zT_510 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_75;
    z_bb_74:
    zT_509 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_509) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_515 = base_ty.kind;
    pre_kind = zT_515;
    zT_516 = self->registry;
    zT_517 = zT_516->ptr_items;
    zT_518 = base_ty.payload_idx;
    zT_519 = (unsigned int)zT_518;
    zT_520 = zT_517[zT_519];
    zT_521 = zT_520.base;
    base_type_id = zT_521;
    zT_522 = self->registry;
    zT_523 = zT_522->types_items;
    zT_524 = (unsigned int)base_type_id;
    zT_525 = zT_523[zT_524];
    base_ty = zT_525;
    zT_527 = "FAPR:OK";
    zT_529 = 7;
    zT_528.ptr = zT_527;
    zT_528.len = zT_529;
    fapr_ok_m = zT_528;
    zT_530 = fapr_ok_m;
    zF_C914CB83_markerWriteInt(zT_530, (unsigned int)((unsigned int)pre_kind));
    zT_534 = "FAPR:DK";
    zT_536 = 7;
    zT_535.ptr = zT_534;
    zT_535.len = zT_536;
    fapr_dk_m = zT_535;
    zT_537 = fapr_dk_m;
    zT_539 = base_ty.kind;
    zF_C914CB83_markerWriteInt(zT_537, (unsigned int)((unsigned int)zT_539));
    zT_542 = "\n";
    zT_544 = 1;
    zT_543.ptr = zT_542;
    zT_543.len = zT_544;
    fapr_nl = zT_543;
    zT_545 = fapr_nl;
    zF_48AC7B3A_markerWrite(zT_545);
    if ((unsigned char)(pre_kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_77:
    zT_586 = base_ty.kind;
    if ((unsigned char)(zT_586 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_82; else goto z_bb_83;
    z_bb_78:
    zT_550 = "len";
    zT_552 = 3;
    zT_551.ptr = zT_550;
    zT_551.len = zT_552;
    mpl_len_s = zT_551;
    zT_554 = self->interner;
    zT_555 = mpl_len_s;
    zT_557 = zF_50C274AF_stringInternerInter(zT_554, zT_555);
    mpl_len_id = zT_557;
    if ((unsigned char)(field_name_id == mpl_len_id)) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    goto z_bb_77;
    z_bb_80:
    zT_560 = "many-item pointer has no field 'len'";
    zT_562 = 36;
    zT_561.ptr = zT_560;
    zT_561.len = zT_562;
    mpl_msg = zT_561;
    zT_563 = self->diag;
    zT_566 = self->source_file_id;
    zT_567 = node.span_start;
    zT_575 = node.span_start;
    zT_576 = node.span_len;
    zT_569 = mpl_msg;
    zT_579 = zF_C82559AC_diagnosticCollector(zT_563, (unsigned char)(0), (unsigned short)(3000), zT_566, zT_567, (unsigned int)(zT_575 + (unsigned int)((unsigned int)zT_576)), zT_569);
    (void)zT_579;
    zT_580 = self->type_table;
    zT_581 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_580, zT_581, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_591 = node.span_start;
    sp = zT_591;
    zT_593 = node.span_len;
    zT_595 = sp + (unsigned int)((unsigned int)zT_593);
    ep_1 = zT_595;
    zT_597 = "cannot access field on optional type; use .? to unwrap first";
    zT_599 = 60;
    zT_598.ptr = zT_597;
    zT_598.len = zT_599;
    opt_msg = zT_598;
    zT_600 = self->diag;
    zT_603 = self->source_file_id;
    zT_604 = sp;
    zT_605 = ep_1;
    zT_606 = opt_msg;
    zT_611 = zF_C82559AC_diagnosticCollector(zT_600, (unsigned char)(0), (unsigned short)(3000), zT_603, zT_604, zT_605, zT_606);
    (void)zT_611;
    return (unsigned int)(1);
    z_bb_83:
    zT_613 = base_ty.kind;
    if ((unsigned char)(zT_613 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_618 = node.span_start;
    sp = zT_618;
    zT_620 = node.span_len;
    zT_622 = sp + (unsigned int)((unsigned int)zT_620);
    ep_2 = zT_622;
    zT_624 = "cannot access field on error-union type; handle the error first";
    zT_626 = 63;
    zT_625.ptr = zT_624;
    zT_625.len = zT_626;
    eu_msg = zT_625;
    zT_627 = self->diag;
    zT_630 = self->source_file_id;
    zT_631 = sp;
    zT_632 = ep_2;
    zT_633 = eu_msg;
    zT_638 = zF_C82559AC_diagnosticCollector(zT_627, (unsigned char)(0), (unsigned short)(3000), zT_630, zT_631, zT_632, zT_633);
    (void)zT_638;
    return (unsigned int)(1);
    z_bb_85:
    zT_640 = base_ty.kind;
    if ((unsigned char)(zT_640 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_86; else goto z_bb_88;
    z_bb_86:
    zT_645 = self->registry;
    zT_646 = zT_645->st_items;
    zT_647 = base_ty.payload_idx;
    zT_648 = (unsigned int)zT_647;
    zT_649 = zT_646[zT_648];
    sp_3 = zT_649;
    zT_650 = sp_3.fields_start;
    zT_651 = (unsigned int)zT_650;
    fields_start = zT_651;
    zT_652 = sp_3.fields_count;
    zT_653 = (unsigned int)zT_652;
    fields_count = zT_653;
    goto z_bb_87;
    z_bb_87:
    zT_1171 = 0;
    zT_1172 = (unsigned int)zT_1171;
    fi = zT_1172;
    goto z_bb_160;
    z_bb_88:
    zT_654 = base_ty.kind;
    if ((unsigned char)(zT_654 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_90; else goto z_bb_89;
    z_bb_89:
    zT_659 = base_ty.kind;
    zT_658 = zT_659 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_91;
    z_bb_90:
    zT_658 = 1;
    goto z_bb_91;
    z_bb_91:
    if (zT_658) goto z_bb_92; else goto z_bb_94;
    z_bb_92:
    zT_664 = self->registry;
    zT_665 = zT_664->un_items;
    zT_666 = base_ty.payload_idx;
    zT_667 = (unsigned int)zT_666;
    zT_668 = zT_665[zT_667];
    up = zT_668;
    zT_669 = up.fields_start;
    zT_670 = (unsigned int)zT_669;
    fields_start = zT_670;
    zT_671 = up.fields_count;
    zT_672 = (unsigned int)zT_671;
    fields_count = zT_672;
    goto z_bb_93;
    z_bb_93:
    goto z_bb_87;
    z_bb_94:
    zT_673 = base_ty.kind;
    if ((unsigned char)(zT_673 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_95; else goto z_bb_97;
    z_bb_95:
    zT_678 = self->registry;
    zT_679 = zT_678->tu_items;
    zT_680 = base_ty.payload_idx;
    zT_681 = (unsigned int)zT_680;
    zT_682 = zT_679[zT_681];
    tp = zT_682;
    zT_684 = "tag";
    zT_686 = 3;
    zT_685.ptr = zT_684;
    zT_685.len = zT_686;
    tag_s = zT_685;
    zT_688 = self->interner;
    zT_689 = tag_s;
    zT_691 = zF_50C274AF_stringInternerInter(zT_688, zT_689);
    tag_id = zT_691;
    if ((unsigned char)(field_name_id == tag_id)) goto z_bb_98; else goto z_bb_99;
    z_bb_96:
    goto z_bb_93;
    z_bb_97:
    zT_771 = base_ty.kind;
    if ((unsigned char)(zT_771 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_110; else goto z_bb_112;
    z_bb_98:
    zT_694 = "FT:TAG\n";
    zT_696 = 7;
    zT_695.ptr = zT_694;
    zT_695.len = zT_696;
    ft_m = zT_695;
    zT_697 = ft_m;
    zF_48AC7B3A_markerWrite(zT_697);
    zT_698 = self->type_table;
    zT_699 = node_idx;
    zT_700 = tp.tag_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_698, zT_699, zT_700);
    zT_703 = tp.tag_type;
    return zT_703;
    z_bb_99:
    zT_705 = "payload";
    zT_707 = 7;
    zT_706.ptr = zT_705;
    zT_706.len = zT_707;
    payload_s = zT_706;
    zT_709 = self->interner;
    zT_710 = payload_s;
    zT_712 = zF_50C274AF_stringInternerInter(zT_709, zT_710);
    payload_id = zT_712;
    if ((unsigned char)(field_name_id == payload_id)) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_715 = tp.fields_count;
    zT_716 = (unsigned int)zT_715;
    fpe_count = zT_716;
    zT_718 = 0;
    zT_719 = (unsigned int)zT_718;
    fpei = zT_719;
    goto z_bb_102;
    z_bb_101:
    zT_767 = tp.fields_start;
    zT_768 = (unsigned int)zT_767;
    fields_start = zT_768;
    zT_769 = tp.fields_count;
    zT_770 = (unsigned int)zT_769;
    fields_count = zT_770;
    goto z_bb_96;
    z_bb_102:
    if ((unsigned char)(fpei < fpe_count)) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_722 = self->registry;
    zT_723 = zT_722->fe_items;
    zT_724 = tp.fields_start;
    zT_726 = (unsigned int)((unsigned int)zT_724) + fpei;
    zT_727 = zT_723[zT_726];
    fpe = zT_727;
    zT_728 = fpe.type_id;
    if ((unsigned char)(zT_728 != (unsigned int)(1))) goto z_bb_106; else goto z_bb_107;
    z_bb_104:
    goto z_bb_101;
    z_bb_105:
    zT_764 = 1;
    zT_766 = fpei + (unsigned int)((unsigned int)zT_764);
    fpei = zT_766;
    goto z_bb_102;
    z_bb_106:
    zT_732 = fpe.type_id;
    payload_res = zT_732;
    zT_734 = self->registry;
    zT_735 = zT_734->types_items;
    zT_736 = (unsigned int)payload_res;
    zT_737 = zT_735[zT_736];
    payload_rt = zT_737;
    zT_738 = payload_rt.kind;
    if ((unsigned char)(zT_738 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    zT_743 = self->registry;
    zT_744 = zT_743->array_items;
    zT_745 = payload_rt.payload_idx;
    zT_746 = (unsigned int)zT_745;
    zT_747 = zT_744[zT_746];
    zT_748 = zT_747.elem;
    payload_elem = zT_748;
    zT_749 = self->registry;
    zT_750 = payload_elem;
    zT_754 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_749, zT_750, (unsigned char)(0));
    payload_res = zT_754;
    goto z_bb_109;
    z_bb_109:
    zT_756 = "FP:PAYLOAD\n";
    zT_758 = 11;
    zT_757.ptr = zT_756;
    zT_757.len = zT_758;
    fpe_m = zT_757;
    zT_759 = fpe_m;
    zF_48AC7B3A_markerWrite(zT_759);
    zT_760 = self->type_table;
    zT_761 = node_idx;
    zT_762 = payload_res;
    zF_19B4A07D_resolvedTypeTableSe(zT_760, zT_761, zT_762);
    return payload_res;
    z_bb_110:
    zT_776 = "MFA\n";
    zT_778 = 4;
    zT_777.ptr = zT_776;
    zT_777.len = zT_778;
    mfa = zT_777;
    zT_779 = mfa;
    zF_48AC7B3A_markerWrite(zT_779);
    zT_781 = self->symbols;
    zT_782 = base_ty.module_id;
    zT_783 = field_name_id;
    zT_786 = zF_A398987E_symbolRegistryQuali(zT_781, zT_782, zT_783);
    mod_field_sym = zT_786;
    zT_787 = mod_field_sym.has_value;
    if (zT_787) goto z_bb_113; else goto z_bb_115;
    z_bb_111:
    goto z_bb_96;
    z_bb_112:
    zT_985 = base_ty.kind;
    if ((unsigned char)(zT_985 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_130; else goto z_bb_132;
    z_bb_113:
    mfs = mod_field_sym.value;
    zT_789 = mfs->type_id;
    if ((unsigned char)(zT_789 != (unsigned int)(0))) goto z_bb_116; else goto z_bb_117;
    z_bb_114:
    zT_979 = self->type_table;
    zT_980 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_979, zT_980, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_115:
    zT_975 = "MF3\n";
    zT_977 = 4;
    zT_976.ptr = zT_975;
    zT_976.len = zT_977;
    mf3 = zT_976;
    zT_978 = mf3;
    zF_48AC7B3A_markerWrite(zT_978);
    goto z_bb_114;
    z_bb_116:
    zT_793 = "MF1\n";
    zT_795 = 4;
    zT_794.ptr = zT_793;
    zT_794.len = zT_795;
    mf1 = zT_794;
    zT_796 = mf1;
    zF_48AC7B3A_markerWrite(zT_796);
    zT_797 = self->type_table;
    zT_798 = node_idx;
    zT_799 = mfs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_797, zT_798, zT_799);
    zT_802 = mfs->type_id;
    return zT_802;
    z_bb_117:
    zT_803 = mfs->kind;
    if ((unsigned char)(zT_803 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_808 = self->type_table;
    zT_809 = mfs->decl_node;
    zT_812 = zF_999DCF51_resolvedTypeTableGe(zT_808, zT_809);
    fn_tid_opt = zT_812;
    zT_813 = fn_tid_opt.has_value;
    if (zT_813) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    zT_967 = "MF2";
    zT_969 = 3;
    zT_968.ptr = zT_967;
    zT_968.len = zT_969;
    mf2_m = zT_968;
    zT_970 = mf2_m;
    zT_972 = mfs->kind;
    zF_C914CB83_markerWriteInt(zT_970, (unsigned int)((unsigned int)zT_972));
    goto z_bb_114;
    z_bb_120:
    fn_tid = fn_tid_opt.value;
    zT_816 = "MF1\n";
    zT_818 = 4;
    zT_817.ptr = zT_816;
    zT_817.len = zT_818;
    mf1 = zT_817;
    zT_819 = mf1;
    zF_48AC7B3A_markerWrite(zT_819);
    zT_820 = self->type_table;
    zT_821 = node_idx;
    zT_822 = fn_tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_820, zT_821, zT_822);
    return fn_tid;
    z_bb_121:
    zT_825 = "MFF\n";
    zT_827 = 4;
    zT_826.ptr = zT_825;
    zT_826.len = zT_827;
    mff = zT_826;
    zT_828 = mff;
    zF_48AC7B3A_markerWrite(zT_828);
    zT_830 = self->store;
    zT_831 = mfs->decl_node;
    zT_834 = zF_FCDD1D35_astStoreNodeAt(zT_830, zT_831);
    dn = zT_834;
    zT_835 = dn.kind;
    if ((unsigned char)(zT_835 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_122; else goto z_bb_123;
    z_bb_122:
    zT_840 = self->store;
    zT_841 = zT_840->fn_protos;
    zT_842 = zT_841.items;
    zT_843 = self->store;
    zT_844 = mfs->decl_node;
    zT_847 = zF_8BA26B9E_astStoreNodePayload(zT_843, zT_844);
    zT_848 = (unsigned int)zT_847;
    zT_849 = zT_842[zT_848];
    proto = zT_849;
    zT_851 = "MFP";
    zT_853 = 3;
    zT_852.ptr = zT_851;
    zT_852.len = zT_853;
    mfp_m = zT_852;
    zT_854 = mfp_m;
    zT_856 = proto.params_start;
    zF_C914CB83_markerWriteInt(zT_854, (unsigned int)((unsigned int)zT_856));
    zT_858 = proto.return_type_node;
    if ((unsigned char)(zT_858 != (unsigned int)(0))) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    goto z_bb_119;
    z_bb_124:
    zT_862 = self->type_table;
    zT_863 = proto.return_type_node;
    zT_866 = zF_999DCF51_resolvedTypeTableGe(zT_862, zT_863);
    rtt = zT_866;
    zT_867 = rtt.has_value;
    if (zT_867) goto z_bb_126; else goto z_bb_127;
    z_bb_125:
    zT_943 = self->registry;
    zT_944 = proto.name_id;
    zT_945 = mfs->module_id;
    zT_948 = proto.params_start;
    zT_949 = proto.params_count;
    zT_951 = proto.call_conv;
    zT_961 = zF_474336D7_typeRegistryGetOrCr(zT_943, zT_944, zT_945, (unsigned char)(0), (unsigned char)(0), zT_948, zT_949, (unsigned int)(1), zT_951);
    fn_ty = zT_961;
    zT_962 = self->type_table;
    zT_963 = node_idx;
    zT_964 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_962, zT_963, zT_964);
    return fn_ty;
    z_bb_126:
    rtv = rtt.value;
    zT_870 = self->registry;
    zT_871 = proto.name_id;
    zT_872 = mfs->module_id;
    zT_875 = proto.params_start;
    zT_876 = proto.params_count;
    zT_877 = rtv;
    zT_878 = proto.call_conv;
    zT_887 = zF_474336D7_typeRegistryGetOrCr(zT_870, zT_871, zT_872, (unsigned char)(0), (unsigned char)(0), zT_875, zT_876, zT_877, zT_878);
    fn_ty = zT_887;
    zT_888 = self->type_table;
    zT_889 = node_idx;
    zT_890 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_888, zT_889, zT_890);
    return fn_ty;
    z_bb_127:
    zT_894 = self->store;
    zT_893.store = zT_894;
    zT_895 = self->registry;
    zT_893.typereg = zT_895;
    zT_896 = self->symbols;
    zT_893.symbol_reg = zT_896;
    zT_897 = self->interner;
    zT_893.interner = zT_897;
    zT_898 = mfs->module_id;
    zT_893.module_id = zT_898;
    zT_899 = self->diag;
    zT_900.has_value = 1;
    zT_900.value = zT_899;
    zT_893.diag = zT_900;
    zT_901.has_value = 0;
    zT_893.local_consts = zT_901;
    zT_902.has_value = 0;
    zT_893.local_types = zT_902;
    zT_903 = self->source_file_id;
    zT_893.source_file_id = zT_903;
    tre_env_b = zT_893;
    zT_905 = &tre_env_b;
    zT_906 = proto.return_type_node;
    zT_911 = zF_F2107C15_resolveTypeExprFull(zT_905, zT_906, (unsigned int)(0));
    resolved_rt_b = zT_911;
    if ((unsigned char)(resolved_rt_b != (unsigned int)(18))) goto z_bb_128; else goto z_bb_129;
    z_bb_128:
    zT_914 = self->type_table;
    zT_915 = proto.return_type_node;
    zT_916 = resolved_rt_b;
    zF_19B4A07D_resolvedTypeTableSe(zT_914, zT_915, zT_916);
    zT_920 = self->registry;
    zT_921 = proto.name_id;
    zT_922 = mfs->module_id;
    zT_925 = proto.params_start;
    zT_926 = proto.params_count;
    zT_927 = resolved_rt_b;
    zT_928 = proto.call_conv;
    zT_937 = zF_474336D7_typeRegistryGetOrCr(zT_920, zT_921, zT_922, (unsigned char)(0), (unsigned char)(0), zT_925, zT_926, zT_927, zT_928);
    fn_ty = zT_937;
    zT_938 = self->type_table;
    zT_939 = node_idx;
    zT_940 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_938, zT_939, zT_940);
    return fn_ty;
    z_bb_129:
    goto z_bb_125;
    z_bb_130:
    zT_990 = self->registry;
    zT_991 = zT_990->slice_items;
    zT_992 = base_ty.payload_idx;
    zT_993 = (unsigned int)zT_992;
    zT_994 = zT_991[zT_993];
    sp_4 = zT_994;
    zT_996 = "len";
    zT_998 = 3;
    zT_997.ptr = zT_996;
    zT_997.len = zT_998;
    len_s = zT_997;
    zT_1000 = self->interner;
    zT_1001 = len_s;
    zT_1003 = zF_50C274AF_stringInternerInter(zT_1000, zT_1001);
    len_id = zT_1003;
    if ((unsigned char)(field_name_id == len_id)) goto z_bb_133; else goto z_bb_134;
    z_bb_131:
    goto z_bb_111;
    z_bb_132:
    zT_1047 = base_ty.kind;
    if ((unsigned char)(zT_1047 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_137; else goto z_bb_139;
    z_bb_133:
    zT_1006 = "FSL:USIZE\n";
    zT_1008 = 10;
    zT_1007.ptr = zT_1006;
    zT_1007.len = zT_1008;
    fsl = zT_1007;
    zT_1009 = fsl;
    zF_48AC7B3A_markerWrite(zT_1009);
    zT_1010 = self->type_table;
    zT_1011 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1010, zT_1011, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_134:
    zT_1017 = "ptr";
    zT_1019 = 3;
    zT_1018.ptr = zT_1017;
    zT_1018.len = zT_1019;
    ptr_s = zT_1018;
    zT_1021 = self->interner;
    zT_1022 = ptr_s;
    zT_1024 = zF_50C274AF_stringInternerInter(zT_1021, zT_1022);
    ptr_id = zT_1024;
    if ((unsigned char)(field_name_id == ptr_id)) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_1027 = self->registry;
    zT_1028 = sp_4.elem;
    zT_1032 = base_ty.flags;
    zT_1037 = zF_402D622A_typeRegistryGetOrCr(zT_1027, zT_1028, (unsigned char)((unsigned char)(zT_1032 & (unsigned char)(1)) != (unsigned char)(0)));
    pty = zT_1037;
    zT_1039 = "FSP:PTR\n";
    zT_1041 = 8;
    zT_1040.ptr = zT_1039;
    zT_1040.len = zT_1041;
    fsp = zT_1040;
    zT_1042 = fsp;
    zF_48AC7B3A_markerWrite(zT_1042);
    zT_1043 = self->type_table;
    zT_1044 = node_idx;
    zT_1045 = pty;
    zF_19B4A07D_resolvedTypeTableSe(zT_1043, zT_1044, zT_1045);
    return pty;
    z_bb_136:
    goto z_bb_131;
    z_bb_137:
    zT_1052 = "len";
    zT_1054 = 3;
    zT_1053.ptr = zT_1052;
    zT_1053.len = zT_1054;
    len_s = zT_1053;
    zT_1056 = self->interner;
    zT_1057 = len_s;
    zT_1059 = zF_50C274AF_stringInternerInter(zT_1056, zT_1057);
    len_id = zT_1059;
    if ((unsigned char)(field_name_id == len_id)) goto z_bb_140; else goto z_bb_141;
    z_bb_138:
    goto z_bb_131;
    z_bb_139:
    zT_1072 = base_ty.kind;
    if ((unsigned char)(zT_1072 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_142; else goto z_bb_144;
    z_bb_140:
    zT_1062 = "FAA:USIZE\n";
    zT_1064 = 10;
    zT_1063.ptr = zT_1062;
    zT_1063.len = zT_1064;
    faa_m = zT_1063;
    zT_1065 = faa_m;
    zF_48AC7B3A_markerWrite(zT_1065);
    zT_1066 = self->type_table;
    zT_1067 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1066, zT_1067, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_141:
    goto z_bb_138;
    z_bb_142:
    zT_1077 = self->registry;
    zT_1078 = base_type_id;
    zT_1079 = field_name_id;
    zT_1081 = zF_D2ECD176_typeRegistryErrorSe(zT_1077, zT_1078, zT_1079);
    es_mi2 = zT_1081;
    if ((unsigned char)(es_mi2 != (unsigned int)(4294967295u))) goto z_bb_145; else goto z_bb_146;
    z_bb_143:
    goto z_bb_138;
    z_bb_144:
    zT_1094 = base_ty.kind;
    if ((unsigned char)(zT_1094 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_147; else goto z_bb_149;
    z_bb_145:
    zT_1084 = self->type_table;
    zT_1085 = node_idx;
    zT_1086 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1084, zT_1085, zT_1086);
    return base_type_id;
    z_bb_146:
    zT_1088 = self->type_table;
    zT_1089 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1088, zT_1089, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_147:
    zT_1099 = self->registry;
    zT_1100 = zT_1099->en_items;
    zT_1101 = base_ty.payload_idx;
    zT_1102 = (unsigned int)zT_1101;
    zT_1103 = zT_1100[zT_1102];
    ep3 = zT_1103;
    zT_1105 = ep3.members_start;
    zT_1106 = (unsigned int)zT_1105;
    estart3 = zT_1106;
    zT_1108 = ep3.members_count;
    zT_1109 = (unsigned int)zT_1108;
    ecount3 = zT_1109;
    zT_1111 = 0;
    zT_1112 = (unsigned int)zT_1111;
    ei3 = zT_1112;
    goto z_bb_150;
    goto z_bb_143;
    z_bb_149:
    zT_1139 = "len";
    zT_1141 = 3;
    zT_1140.ptr = zT_1139;
    zT_1140.len = zT_1141;
    len_s = zT_1140;
    zT_1143 = self->interner;
    zT_1144 = len_s;
    zT_1146 = zF_50C274AF_stringInternerInter(zT_1143, zT_1144);
    len_id = zT_1146;
    if ((unsigned char)(field_name_id == len_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_150:
    if ((unsigned char)(ei3 < ecount3)) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_1114 = self->registry;
    zT_1115 = zT_1114->em_items;
    zT_1116 = estart3 + ei3;
    zT_1117 = zT_1115[zT_1116];
    zT_1118 = zT_1117.name_id;
    if ((unsigned char)(zT_1118 == field_name_id)) goto z_bb_154; else goto z_bb_155;
    z_bb_152:
    zT_1128 = "FF\n";
    zT_1130 = 3;
    zT_1129.ptr = zT_1128;
    zT_1129.len = zT_1130;
    fnf = zT_1129;
    zT_1131 = fnf;
    zF_48AC7B3A_markerWrite(zT_1131);
    zT_1132 = self->type_table;
    zT_1133 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1132, zT_1133, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_153:
    zT_1124 = 1;
    zT_1126 = ei3 + (unsigned int)((unsigned int)zT_1124);
    ei3 = zT_1126;
    goto z_bb_150;
    z_bb_154:
    zT_1120 = self->type_table;
    zT_1121 = node_idx;
    zT_1122 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1120, zT_1121, zT_1122);
    return base_type_id;
    z_bb_155:
    goto z_bb_153;
    z_bb_156:
    zT_1149 = self;
    zT_1150 = node.child_0;
    zT_1152 = zF_3F00B75F_semanticAnalyzerArr(zT_1149, zT_1150);
    afl_ty = zT_1152;
    if ((unsigned char)(afl_ty != (unsigned int)(0))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_1160 = "FF\n";
    zT_1162 = 3;
    zT_1161.ptr = zT_1160;
    zT_1161.len = zT_1162;
    fnf = zT_1161;
    zT_1163 = fnf;
    zF_48AC7B3A_markerWrite(zT_1163);
    zT_1164 = self->type_table;
    zT_1165 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1164, zT_1165, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_158:
    zT_1155 = self->type_table;
    zT_1156 = node_idx;
    zT_1157 = afl_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_1155, zT_1156, zT_1157);
    return afl_ty;
    z_bb_159:
    goto z_bb_157;
    z_bb_160:
    if ((unsigned char)(fi < fields_count)) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    zT_1175 = self->registry;
    zT_1176 = zT_1175->fe_items;
    zT_1177 = fields_start + fi;
    zT_1178 = zT_1176[zT_1177];
    fe = zT_1178;
    zT_1179 = fe.name_id;
    if ((unsigned char)(zT_1179 == field_name_id)) goto z_bb_164; else goto z_bb_165;
    z_bb_162:
    zT_1219 = "NF\n";
    zT_1221 = 3;
    zT_1220.ptr = zT_1219;
    zT_1220.len = zT_1221;
    fnf2 = zT_1220;
    zT_1222 = fnf2;
    zF_48AC7B3A_markerWrite(zT_1222);
    zT_1224 = "FF2:N";
    zT_1226 = 5;
    zT_1225.ptr = zT_1224;
    zT_1225.len = zT_1226;
    ff2n_m = zT_1225;
    zT_1227 = ff2n_m;
    zT_1228 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1227, zT_1228);
    zT_1230 = "FF2:F";
    zT_1232 = 5;
    zT_1231.ptr = zT_1230;
    zT_1231.len = zT_1232;
    ff2f_m = zT_1231;
    zT_1233 = ff2f_m;
    zT_1234 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_1233, zT_1234);
    zT_1236 = "FF2:B";
    zT_1238 = 5;
    zT_1237.ptr = zT_1236;
    zT_1237.len = zT_1238;
    ff2b_m = zT_1237;
    zT_1239 = ff2b_m;
    zT_1240 = base_type_id;
    zF_C914CB83_markerWriteInt(zT_1239, zT_1240);
    zT_1241 = self->type_table;
    zT_1242 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1241, zT_1242, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_163:
    goto z_bb_160;
    z_bb_164:
    zT_1182 = fe.type_id;
    result = zT_1182;
    zT_1184 = self->registry;
    zT_1185 = zT_1184->types_items;
    zT_1186 = (unsigned int)result;
    zT_1187 = zT_1185[zT_1186];
    rt = zT_1187;
    zT_1188 = rt.kind;
    if ((unsigned char)(zT_1188 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_166; else goto z_bb_167;
    z_bb_165:
    zT_1215 = 1;
    zT_1217 = fi + (unsigned int)((unsigned int)zT_1215);
    fi = zT_1217;
    goto z_bb_163;
    z_bb_166:
    zT_1193 = self->registry;
    zT_1194 = zT_1193->array_items;
    zT_1195 = rt.payload_idx;
    zT_1196 = (unsigned int)zT_1195;
    zT_1197 = zT_1194[zT_1196];
    zT_1198 = zT_1197.elem;
    elem = zT_1198;
    zT_1199 = self->registry;
    zT_1200 = elem;
    zT_1204 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1199, zT_1200, (unsigned char)(0));
    result = zT_1204;
    goto z_bb_167;
    z_bb_167:
    zT_1206 = "FF:R";
    zT_1208 = 4;
    zT_1207.ptr = zT_1206;
    zT_1207.len = zT_1208;
    ff_m = zT_1207;
    zT_1209 = ff_m;
    zT_1210 = result;
    zF_C914CB83_markerWriteInt(zT_1209, zT_1210);
    zT_1211 = self->type_table;
    zT_1212 = node_idx;
    zT_1213 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_1211, zT_1212, zT_1213);
    return result;
}

/* semanticAnalyzerPackedGateGrow */
void zF_151B0DD7_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_0715C9B9_EU_832 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->packed_gate_cap;
    if ((unsigned char)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_gate_len;
    if ((unsigned char)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_gate_items = ndst;
    self->packed_gate_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->packed_gate_len;
    if ((unsigned char)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_gate_items;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerPackedGateMark */
void zF_E3B2C29D_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->packed_gate_len;
    zT_3 = self->packed_gate_cap;
    if ((unsigned char)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_151B0DD7_semanticAnalyzerPac(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->packed_gate_items;
    zT_7 = self->packed_gate_len;
    zT_6[zT_7] = node_idx;
    zT_8 = self->packed_gate_len;
    self->packed_gate_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedGateSeen */
unsigned char zF_5BBD6EB3_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_12;
    unsigned int gi;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    gi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_gate_len;
    if ((unsigned char)(gi < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_items;
    zT_8 = zT_7[gi];
    if ((unsigned char)(zT_8 == node_idx)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_12 = gi + (unsigned int)(1);
    gi = zT_12;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_4;
}

/* semanticAnalyzerPackedStructCacheGrow */
void zF_86D8CE03_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_0715C9B9_EU_832 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_0715C9B9_EU_832 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int* zT_58;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    unsigned char* raw2;
    unsigned int* ndst2;
    unsigned int ci2;
    zT_2 = self->packed_struct_cache_cap;
    if ((unsigned char)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_cache_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_struct_cache_len;
    if ((unsigned char)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_struct_tids = ndst;
    zT_37 = self->expected_type_stack_alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_13; else goto z_bb_14;
    z_bb_9:
    zT_30 = self->packed_struct_cache_len;
    if ((unsigned char)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
    z_bb_13:
    pal_trap();
    z_bb_14:
    zT_46 = zT_44.data.payload;
    goto z_bb_15;
    z_bb_15:
    raw2 = zT_46;
    zT_49 = (unsigned int*)raw2;
    ndst2 = zT_49;
    zT_50 = self->packed_struct_cache_len;
    if ((unsigned char)(zT_50 > (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    ci2 = zT_55;
    goto z_bb_18;
    z_bb_17:
    self->packed_struct_decl_nodes = ndst2;
    self->packed_struct_cache_cap = new_cap;
    return;
    z_bb_18:
    zT_56 = self->packed_struct_cache_len;
    if ((unsigned char)(ci2 < zT_56)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_58 = self->packed_struct_decl_nodes;
    zT_59 = zT_58[ci2];
    ndst2[ci2] = zT_59;
    goto z_bb_21;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_61 = ci2 + (unsigned int)(1);
    ci2 = zT_61;
    goto z_bb_18;
}

/* semanticAnalyzerPackedStructCacheAppend */
void zF_2C47D4E0_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_3 = self->packed_struct_cache_len;
    zT_4 = self->packed_struct_cache_cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_86D8CE03_semanticAnalyzerPac(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = self->packed_struct_cache_len;
    zT_7[zT_8] = struct_tid;
    zT_9 = self->packed_struct_decl_nodes;
    zT_10 = self->packed_struct_cache_len;
    zT_9[zT_10] = decl_node;
    zT_11 = self->packed_struct_cache_len;
    self->packed_struct_cache_len = (unsigned int)(zT_11 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCheckedStructTidsGrow */
void zF_055533B0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_0715C9B9_EU_832 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->checked_struct_tids_cap;
    if ((unsigned char)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->checked_struct_tids_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->checked_struct_tids_len;
    if ((unsigned char)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->checked_struct_tids = ndst;
    self->checked_struct_tids_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->checked_struct_tids_len;
    if ((unsigned char)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->checked_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerCheckedStructTidsAppend */
void zF_B5A1E8BB_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->checked_struct_tids_len;
    zT_3 = self->checked_struct_tids_cap;
    if ((unsigned char)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_055533B0_semanticAnalyzerChe(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->checked_struct_tids;
    zT_7 = self->checked_struct_tids_len;
    zT_6[zT_7] = struct_tid;
    zT_8 = self->checked_struct_tids_len;
    self->checked_struct_tids_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedFieldTypeAllowed */
unsigned char zF_E42B9323_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, unsigned char allow_packed_struct_type) {
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_18;
    unsigned char zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    unsigned char zT_28;
    unsigned char zT_29;
    zT_33EF6BFB_TypeKind zT_35;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    unsigned char zT_42 = 0;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    unsigned int zT_49 = 0;
    unsigned char zT_52;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    unsigned char zT_61 = 0;
    zT_338B7C76_TypeRegistry* zT_65;
    unsigned int zT_66;
    unsigned char zT_68 = 0;
    zT_D155D06D_Type ty;
    unsigned int ebt;
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ty = zT_12;
    zT_13 = ty.kind;
    if ((unsigned char)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_18 = ty.kind;
    if ((unsigned char)(zT_18 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if (allow_packed_struct_type) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = ty.kind;
    zT_23 = zT_24 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_9;
    z_bb_8:
    zT_23 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_23) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_29 = ty.flags;
    zT_28 = (unsigned char)(zT_29 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_28 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_28) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    zT_35 = ty.kind;
    if ((unsigned char)(zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_39 = self->registry;
    zT_40 = tid;
    zT_42 = zF_A3BA89EA_typeRegistryEnumHas(zT_39, zT_40);
    if ((unsigned char)(!zT_42)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_65 = self->registry;
    zT_66 = tid;
    zT_68 = zF_3290E9C4_typeRegistryIsInteg(zT_65, zT_66);
    return zT_68;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    zT_46 = self->registry;
    zT_47 = tid;
    zT_49 = zF_014D7530_typeRegistryEnumBac(zT_46, zT_47);
    ebt = zT_49;
    if ((unsigned char)(ebt == (unsigned int)(18))) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_54 = self->registry;
    zT_55 = zT_54->types_len;
    zT_52 = (unsigned int)((unsigned int)ebt) >= zT_55;
    goto z_bb_21;
    z_bb_20:
    zT_52 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_52) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_58 = self->registry;
    zT_59 = ebt;
    zT_61 = zF_B664AC19_typeRegistryIsUnsig(zT_58, zT_59);
    if ((unsigned char)(!zT_61)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (unsigned char)(0);
    z_bb_25:
    return (unsigned char)(1);
}

/* semanticAnalyzerGatePackedFields */
void zF_C26EF425_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_12;
    zT_38C12417_SemanticAnalyzer* zT_17;
    unsigned int zT_18;
    unsigned char zT_19 = 0;
    zT_38C12417_SemanticAnalyzer* zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_41 = 0;
    zT_22A7C88B_AstNode zT_42 = {0};
    zT_8143F551_AstKind zT_43;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned char zT_52;
    zT_ABC1EBBE_TypeResolveEnv zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_3D7259E2_SymbolRegistry* zT_59;
    zT_D3EB6303_StringInterner* zT_60;
    zT_F85C5DED_DiagnosticCollector* zT_61;
    zT_7034F045_Opt_228 zT_62;
    zT_03B97CED_Opt_398 zT_63 = {0};
    zT_05CE5599_Opt_400 zT_64 = {0};
    unsigned int zT_65;
    zT_ABC1EBBE_TypeResolveEnv* zT_67;
    unsigned int zT_68;
    unsigned int zT_72 = 0;
    unsigned char zT_75;
    unsigned char zT_78;
    zT_38C12417_SemanticAnalyzer* zT_79;
    unsigned int zT_80;
    unsigned char zT_83 = 0;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned char zT_87 = 0;
    unsigned char zT_90;
    unsigned char zT_91;
    unsigned int zT_95;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_F85C5DED_DiagnosticCollector* zT_106;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_117 = 0;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_F85C5DED_DiagnosticCollector* zT_122;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_133 = 0;
    unsigned int zT_135;
    zT_22A7C88B_AstNode node;
    unsigned int children_n;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u pw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pg_msg;
    zT_4 = self->store;
    zT_5 = struct_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = node.flags;
    if ((unsigned char)((unsigned char)(zT_12 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_17 = self;
    zT_18 = struct_node_idx;
    zT_19 = zF_5BBD6EB3_semanticAnalyzerPac(zT_17, zT_18);
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_20 = self;
    zT_21 = struct_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_20, zT_21);
    zT_23 = self->store;
    zT_24 = struct_node_idx;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    children_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(ci < (unsigned int)((unsigned int)children_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = self->store;
    zT_36 = self->store;
    zT_37 = struct_node_idx;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)ci));
    zT_34 = zT_41;
    zT_42 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    fd = zT_42;
    zT_43 = fd.kind;
    if ((unsigned char)(zT_43 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_135 = ci + (unsigned int)(1);
    ci = zT_135;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_48 = fd.child_0;
    type_node = zT_48;
    zT_50 = 0;
    gate_state = zT_50;
    zT_52 = 0;
    gate_wide = zT_52;
    if ((unsigned char)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_57 = self->store;
    zT_56.store = zT_57;
    zT_58 = self->registry;
    zT_56.typereg = zT_58;
    zT_59 = self->symbols;
    zT_56.symbol_reg = zT_59;
    zT_60 = self->interner;
    zT_56.interner = zT_60;
    zT_56.module_id = module_id;
    zT_61 = self->diag;
    zT_62.has_value = 1;
    zT_62.value = zT_61;
    zT_56.diag = zT_62;
    zT_63.has_value = 0;
    zT_56.local_consts = zT_63;
    zT_64.has_value = 0;
    zT_56.local_types = zT_64;
    zT_65 = self->source_file_id;
    zT_56.source_file_id = zT_65;
    tre_env = zT_56;
    zT_67 = &tre_env;
    zT_68 = type_node;
    zT_72 = zF_F2107C15_resolveTypeExprFull(zT_67, zT_68, (unsigned int)(0));
    ft = zT_72;
    if ((unsigned char)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((unsigned char)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_75 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_75 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_75) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_78 = 1;
    gate_state = zT_78;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_79 = self;
    zT_80 = ft;
    zT_83 = zF_E42B9323_semanticAnalyzerPac(zT_79, zT_80, (unsigned char)(1));
    if (zT_83) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_84 = self->registry;
    zT_85 = ft;
    zT_87 = zF_655972D5_typeRegistryIntWidt(zT_84, zT_85);
    if ((unsigned char)(zT_87 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_90 = 1;
    gate_wide = zT_90;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_91 = 1;
    gate_state = zT_91;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_95 = fd.span_start;
    fsp = zT_95;
    zT_97 = fd.span_len;
    zT_99 = fsp + (unsigned int)((unsigned int)zT_97);
    fep = zT_99;
    if ((unsigned char)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_103 = "packed struct field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_105 = 95;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    pw_msg = zT_104;
    zT_106 = self->diag;
    zT_109 = self->source_file_id;
    zT_110 = fsp;
    zT_111 = fep;
    zT_112 = pw_msg;
    zT_117 = zF_C82559AC_diagnosticCollector(zT_106, (unsigned char)(0), (unsigned short)(3000), zT_109, zT_110, zT_111, zT_112);
    (void)zT_117;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_119 = "packed struct fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed struct";
    zT_121 = 111;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    pg_msg = zT_120;
    zT_122 = self->diag;
    zT_125 = self->source_file_id;
    zT_126 = fsp;
    zT_127 = fep;
    zT_128 = pg_msg;
    zT_133 = zF_C82559AC_diagnosticCollector(zT_122, (unsigned char)(0), (unsigned short)(3000), zT_125, zT_126, zT_127, zT_128);
    (void)zT_133;
    goto z_bb_29;
}

/* semanticAnalyzerMaybeGateAliasDecl */
void zF_FC6E31C6_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned int zT_11;
    unsigned char zT_13;
    zT_8143F551_AstKind zT_14;
    zT_8143F551_AstKind zT_18;
    unsigned char zT_22;
    unsigned char zT_27;
    zT_8143F551_AstKind zT_28;
    unsigned char zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_46;
    zT_8143F551_AstKind zT_47;
    unsigned char zT_51;
    unsigned char zT_52;
    unsigned int zT_57;
    unsigned char zT_58;
    zT_38C12417_SemanticAnalyzer* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((unsigned char)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = decl_node;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    dnode = zT_9;
    zT_11 = 0;
    target = zT_11;
    zT_13 = 0;
    is_union = zT_13;
    zT_14 = dnode.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_18 = dnode.kind;
    if ((unsigned char)(zT_18 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_22 = dnode.flags;
    if ((unsigned char)((unsigned char)(zT_22 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_28 = dnode.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_27 = 1;
    is_union = zT_27;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_33 = dnode.child_1;
    zT_32 = zT_33 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_32 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_32) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_37 = self->store;
    zT_38 = dnode.child_1;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_37, zT_38);
    inn = zT_41;
    zT_42 = inn.kind;
    if ((unsigned char)(zT_42 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_46 = dnode.child_1;
    target = zT_46;
    goto z_bb_17;
    z_bb_17:
    zT_47 = inn.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_52 = inn.flags;
    zT_51 = (unsigned char)(zT_52 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_51 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_51) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_57 = dnode.child_1;
    target = zT_57;
    zT_58 = 1;
    is_union = zT_58;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((unsigned char)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_63 = self;
    zT_64 = target;
    zT_65 = module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_63, zT_64, zT_65);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_66 = self;
    zT_67 = target;
    zT_68 = module_id;
    zF_F705063A_semanticAnalyzerGat(zT_66, zT_67, zT_68);
    goto z_bb_26;
}

/* semanticAnalyzerGateModulePackedDecl */
void zF_6A91A8CC_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned char zT_12;
    zT_8143F551_AstKind zT_13;
    zT_8143F551_AstKind zT_17;
    unsigned char zT_21;
    unsigned char zT_26;
    zT_8143F551_AstKind zT_27;
    unsigned char zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_45;
    zT_8143F551_AstKind zT_46;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned int zT_56;
    unsigned char zT_57;
    zT_38C12417_SemanticAnalyzer* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((unsigned char)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    target = zT_10;
    zT_12 = 0;
    is_union = zT_12;
    zT_13 = dnode.kind;
    if ((unsigned char)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_17 = dnode.kind;
    if ((unsigned char)(zT_17 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_21 = dnode.flags;
    if ((unsigned char)((unsigned char)(zT_21 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_27 = dnode.kind;
    if ((unsigned char)(zT_27 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_26 = 1;
    is_union = zT_26;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_32 = dnode.child_1;
    zT_31 = zT_32 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_31 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_31) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_36 = self->store;
    zT_37 = dnode.child_1;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    inn = zT_40;
    zT_41 = inn.kind;
    if ((unsigned char)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_45 = dnode.child_1;
    target = zT_45;
    goto z_bb_17;
    z_bb_17:
    zT_46 = inn.kind;
    if ((unsigned char)(zT_46 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_51 = inn.flags;
    zT_50 = (unsigned char)(zT_51 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_50 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_50) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_56 = dnode.child_1;
    target = zT_56;
    zT_57 = 1;
    is_union = zT_57;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((unsigned char)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_62 = self;
    zT_63 = target;
    zT_64 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_62, zT_63, zT_64);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_66 = self;
    zT_67 = target;
    zT_68 = self->module_id;
    zF_F705063A_semanticAnalyzerGat(zT_66, zT_67, zT_68);
    goto z_bb_26;
}

/* semanticAnalyzerGatePackedUnionMembers */
void zF_F705063A_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int union_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_12;
    zT_38C12417_SemanticAnalyzer* zT_17;
    unsigned int zT_18;
    unsigned char zT_19 = 0;
    zT_38C12417_SemanticAnalyzer* zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_41 = 0;
    zT_22A7C88B_AstNode zT_42 = {0};
    zT_8143F551_AstKind zT_43;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned char zT_52;
    zT_ABC1EBBE_TypeResolveEnv zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_3D7259E2_SymbolRegistry* zT_59;
    zT_D3EB6303_StringInterner* zT_60;
    zT_F85C5DED_DiagnosticCollector* zT_61;
    zT_7034F045_Opt_228 zT_62;
    zT_03B97CED_Opt_398 zT_63 = {0};
    zT_05CE5599_Opt_400 zT_64 = {0};
    unsigned int zT_65;
    zT_ABC1EBBE_TypeResolveEnv* zT_67;
    unsigned int zT_68;
    unsigned int zT_72 = 0;
    unsigned char zT_75;
    unsigned char zT_78;
    zT_38C12417_SemanticAnalyzer* zT_79;
    unsigned int zT_80;
    unsigned char zT_83 = 0;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned char zT_87 = 0;
    unsigned char zT_90;
    unsigned char zT_91;
    unsigned int zT_95;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_F85C5DED_DiagnosticCollector* zT_106;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_117 = 0;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_F85C5DED_DiagnosticCollector* zT_122;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_133 = 0;
    unsigned int zT_135;
    zT_22A7C88B_AstNode node;
    unsigned int children_n;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u puw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pgu_msg;
    zT_4 = self->store;
    zT_5 = union_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = node.flags;
    if ((unsigned char)((unsigned char)(zT_12 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_17 = self;
    zT_18 = union_node_idx;
    zT_19 = zF_5BBD6EB3_semanticAnalyzerPac(zT_17, zT_18);
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_20 = self;
    zT_21 = union_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_20, zT_21);
    zT_23 = self->store;
    zT_24 = union_node_idx;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    children_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(ci < (unsigned int)((unsigned int)children_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = self->store;
    zT_36 = self->store;
    zT_37 = union_node_idx;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)ci));
    zT_34 = zT_41;
    zT_42 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    fd = zT_42;
    zT_43 = fd.kind;
    if ((unsigned char)(zT_43 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_135 = ci + (unsigned int)(1);
    ci = zT_135;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_48 = fd.child_0;
    type_node = zT_48;
    zT_50 = 0;
    gate_state = zT_50;
    zT_52 = 0;
    gate_wide = zT_52;
    if ((unsigned char)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_57 = self->store;
    zT_56.store = zT_57;
    zT_58 = self->registry;
    zT_56.typereg = zT_58;
    zT_59 = self->symbols;
    zT_56.symbol_reg = zT_59;
    zT_60 = self->interner;
    zT_56.interner = zT_60;
    zT_56.module_id = module_id;
    zT_61 = self->diag;
    zT_62.has_value = 1;
    zT_62.value = zT_61;
    zT_56.diag = zT_62;
    zT_63.has_value = 0;
    zT_56.local_consts = zT_63;
    zT_64.has_value = 0;
    zT_56.local_types = zT_64;
    zT_65 = self->source_file_id;
    zT_56.source_file_id = zT_65;
    tre_env = zT_56;
    zT_67 = &tre_env;
    zT_68 = type_node;
    zT_72 = zF_F2107C15_resolveTypeExprFull(zT_67, zT_68, (unsigned int)(0));
    ft = zT_72;
    if ((unsigned char)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((unsigned char)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_75 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_75 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_75) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_78 = 1;
    gate_state = zT_78;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_79 = self;
    zT_80 = ft;
    zT_83 = zF_E42B9323_semanticAnalyzerPac(zT_79, zT_80, (unsigned char)(1));
    if (zT_83) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_84 = self->registry;
    zT_85 = ft;
    zT_87 = zF_655972D5_typeRegistryIntWidt(zT_84, zT_85);
    if ((unsigned char)(zT_87 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_90 = 1;
    gate_wide = zT_90;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_91 = 1;
    gate_state = zT_91;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_95 = fd.span_start;
    fsp = zT_95;
    zT_97 = fd.span_len;
    zT_99 = fsp + (unsigned int)((unsigned int)zT_97);
    fep = zT_99;
    if ((unsigned char)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_103 = "packed union field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_105 = 94;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    puw_msg = zT_104;
    zT_106 = self->diag;
    zT_109 = self->source_file_id;
    zT_110 = fsp;
    zT_111 = fep;
    zT_112 = puw_msg;
    zT_117 = zF_C82559AC_diagnosticCollector(zT_106, (unsigned char)(0), (unsigned short)(3000), zT_109, zT_110, zT_111, zT_112);
    (void)zT_117;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_119 = "packed union fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed union";
    zT_121 = 109;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    pgu_msg = zT_120;
    zT_122 = self->diag;
    zT_125 = self->source_file_id;
    zT_126 = fsp;
    zT_127 = fep;
    zT_128 = pgu_msg;
    zT_133 = zF_C82559AC_diagnosticCollector(zT_122, (unsigned char)(0), (unsigned short)(3000), zT_125, zT_126, zT_127, zT_128);
    (void)zT_133;
    goto z_bb_29;
}

/* semanticAnalyzerGateEnumModuleDecl */
void zF_4E74AE9D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    zT_8143F551_AstKind zT_15;
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_8143F551_AstKind zT_25;
    unsigned char zT_29;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode zT_38 = {0};
    zT_8143F551_AstKind zT_39;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    unsigned int zT_47 = 0;
    unsigned int zT_48;
    unsigned int zT_52;
    zT_79FAE712_u64 zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_79FAE712_u64 zT_59;
    zT_BAEE192E_Opt_10 zT_61 = {0};
    unsigned char zT_62;
    zT_38C12417_SemanticAnalyzer* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    unsigned int backing_node;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    unsigned int tid;
    if ((unsigned char)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    enum_node = zT_10;
    zT_12 = 0;
    enum_name_id = zT_12;
    zT_14 = 0;
    backing_node = zT_14;
    zT_15 = dnode.kind;
    if ((unsigned char)(zT_15 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = dnode.child_1;
    zT_19 = zT_20 != (unsigned int)(0);
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_19) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    enum_node = decl_node;
    zT_23 = dnode.child_0;
    enum_name_id = zT_23;
    zT_24 = dnode.child_1;
    backing_node = zT_24;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_8:
    zT_25 = dnode.kind;
    if ((unsigned char)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_30 = dnode.child_1;
    zT_29 = zT_30 != (unsigned int)(0);
    goto z_bb_11;
    z_bb_10:
    zT_29 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_29) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_34 = self->store;
    zT_35 = dnode.child_1;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    inn = zT_38;
    zT_39 = inn.kind;
    if ((unsigned char)(zT_39 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    goto z_bb_7;
    z_bb_14:
    zT_43 = dnode.child_1;
    enum_node = zT_43;
    zT_44 = self->store;
    zT_45 = decl_node;
    zT_47 = zF_8BA26B9E_astStoreNodePayload(zT_44, zT_45);
    enum_name_id = zT_47;
    zT_48 = inn.child_0;
    backing_node = zT_48;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    return;
    z_bb_17:
    zT_52 = self->module_id;
    zT_57 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_52) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)enum_name_id);
    key = zT_57;
    zT_58 = self->registry;
    zT_59 = key;
    zT_61 = zF_0EB68360_nameCacheGet(zT_58, zT_59);
    zT_62 = zT_61.has_value;
    if (zT_62) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    tid = zT_61.value;
    zT_64 = self;
    zT_65 = tid;
    zT_66 = enum_node;
    zT_67 = backing_node;
    zF_5EF7F98D_semanticAnalyzerGat(zT_64, zT_65, zT_66, zT_67);
    goto z_bb_19;
    z_bb_19:
    return;
}

/* semanticAnalyzerGateEnumTypeDecl */
void zF_5EF7F98D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, unsigned int enum_node, unsigned int backing_node) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    zT_338B7C76_TypeRegistry* zT_23;
    zT_457ECFEE_EnumPayload* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_457ECFEE_EnumPayload zT_27;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    zT_22A7C88B_AstNode zT_35 = {0};
    unsigned int zT_37;
    unsigned int zT_39;
    unsigned int zT_41;
    zT_ABC1EBBE_TypeResolveEnv zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_3D7259E2_SymbolRegistry* zT_46;
    zT_D3EB6303_StringInterner* zT_47;
    unsigned int zT_48;
    zT_F85C5DED_DiagnosticCollector* zT_49;
    zT_7034F045_Opt_228 zT_50;
    zT_03B97CED_Opt_398 zT_51 = {0};
    zT_05CE5599_Opt_400 zT_52 = {0};
    unsigned int zT_53;
    zT_ABC1EBBE_TypeResolveEnv* zT_55;
    unsigned int zT_56;
    unsigned int zT_60 = 0;
    unsigned char zT_63;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_F85C5DED_DiagnosticCollector* zT_70;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_81 = 0;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_D155D06D_Type* zT_88;
    unsigned int zT_89;
    zT_D155D06D_Type zT_90;
    zT_33EF6BFB_TypeKind zT_91;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_F85C5DED_DiagnosticCollector* zT_99;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_110 = 0;
    zT_338B7C76_TypeRegistry* zT_111;
    unsigned int zT_112;
    unsigned char zT_114 = 0;
    zT_338B7C76_TypeRegistry* zT_116;
    unsigned int zT_117;
    unsigned char zT_119 = 0;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_F85C5DED_DiagnosticCollector* zT_124;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_135 = 0;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_F85C5DED_DiagnosticCollector* zT_140;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_151 = 0;
    zT_338B7C76_TypeRegistry* zT_153;
    unsigned int zT_154;
    unsigned char zT_156 = 0;
    unsigned int zT_157;
    zT_79FAE712_u64 zT_159;
    zT_79FAE712_u64 zT_166;
    zT_338B7C76_TypeRegistry* zT_168;
    zT_457ECFEE_EnumPayload* zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    zT_457ECFEE_EnumPayload zT_172;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned short zT_177;
    unsigned int zT_178;
    zT_6B0A7D14_AstStore* zT_180;
    unsigned int zT_181;
    unsigned int zT_183 = 0;
    unsigned int zT_185;
    int zT_187;
    unsigned int zT_188;
    zT_79FAE712_u64 zT_190;
    unsigned char zT_192;
    unsigned char zT_195;
    zT_6B0A7D14_AstStore* zT_198;
    unsigned int zT_199;
    zT_6B0A7D14_AstStore* zT_201;
    unsigned int zT_202;
    unsigned int zT_206 = 0;
    zT_22A7C88B_AstNode zT_207 = {0};
    zT_8143F551_AstKind zT_208;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_D96DCDF2_EnumMember* zT_214;
    unsigned int zT_215;
    zT_D96DCDF2_EnumMember zT_216;
    zT_C69B2266_i64 zT_217;
    zT_79FAE712_u64 zT_219;
    unsigned int zT_222;
    unsigned int zT_224;
    unsigned int zT_226;
    unsigned char* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_230;
    zT_F85C5DED_DiagnosticCollector* zT_231;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_242 = 0;
    unsigned char zT_243;
    unsigned char zT_245;
    unsigned int zT_246;
    unsigned int zT_250;
    unsigned int zT_252;
    unsigned int zT_254;
    unsigned char* zT_256;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_257;
    unsigned int zT_258;
    zT_F85C5DED_DiagnosticCollector* zT_259;
    unsigned int zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    unsigned int zT_270 = 0;
    unsigned char zT_271;
    unsigned int zT_273;
    unsigned int zT_275;
    zT_D155D06D_Type ety;
    unsigned int check_btid;
    zT_22A7C88B_AstNode bnode;
    unsigned int bsp;
    unsigned int bep;
    zT_ABC1EBBE_TypeResolveEnv tre_env2;
    unsigned int bt;
    unsigned int nbits;
    zT_79FAE712_u64 maxv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bg_msg;
    zT_D155D06D_Type bty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bb_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bi_msg;
    zT_457ECFEE_EnumPayload ep2;
    unsigned int mstart2;
    unsigned int mcount2;
    unsigned int children2_n;
    unsigned int fcount2;
    unsigned int ci2;
    zT_79FAE712_u64 prev_vu;
    unsigned char have_prev;
    zT_22A7C88B_AstNode fd2;
    zT_C69B2266_i64 mv;
    zT_79FAE712_u64 mvu;
    unsigned int msp;
    unsigned int mep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mv_msg;
    zT_5 = self->registry;
    zT_6 = zT_5->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ety = zT_12;
    zT_13 = ety.kind;
    if ((unsigned char)(zT_13 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_17 = ety.payload_idx;
    zT_19 = self->registry;
    zT_20 = zT_19->en_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_17) >= zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_23 = self->registry;
    zT_24 = zT_23->en_items;
    zT_25 = ety.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    zT_28 = zT_27.backing_type;
    check_btid = zT_28;
    if ((unsigned char)(backing_node != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_32 = self->store;
    zT_33 = backing_node;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    bnode = zT_35;
    zT_37 = bnode.span_start;
    bsp = zT_37;
    zT_39 = bnode.span_len;
    zT_41 = bsp + (unsigned int)((unsigned int)zT_39);
    bep = zT_41;
    zT_44 = self->store;
    zT_43.store = zT_44;
    zT_45 = self->registry;
    zT_43.typereg = zT_45;
    zT_46 = self->symbols;
    zT_43.symbol_reg = zT_46;
    zT_47 = self->interner;
    zT_43.interner = zT_47;
    zT_48 = self->module_id;
    zT_43.module_id = zT_48;
    zT_49 = self->diag;
    zT_50.has_value = 1;
    zT_50.value = zT_49;
    zT_43.diag = zT_50;
    zT_51.has_value = 0;
    zT_43.local_consts = zT_51;
    zT_52.has_value = 0;
    zT_43.local_types = zT_52;
    zT_53 = self->source_file_id;
    zT_43.source_file_id = zT_53;
    tre_env2 = zT_43;
    zT_55 = &tre_env2;
    zT_56 = backing_node;
    zT_60 = zF_F2107C15_resolveTypeExprFull(zT_55, zT_56, (unsigned int)(0));
    bt = zT_60;
    if ((unsigned char)(bt == (unsigned int)(18))) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    zT_153 = self->registry;
    zT_154 = check_btid;
    zT_156 = zF_655972D5_typeRegistryIntWidt(zT_153, zT_154);
    zT_157 = (unsigned int)zT_156;
    nbits = zT_157;
    zT_159 = 18446744073709551615ULL;
    maxv = zT_159;
    if ((unsigned char)(nbits < (unsigned int)(64))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    zT_63 = bt == (unsigned int)(1);
    goto z_bb_11;
    z_bb_10:
    zT_63 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_63) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_67 = "invalid enum backing type; enum(uN) requires an unsigned integer type name (u1..u64)";
    zT_69 = 84;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    bg_msg = zT_68;
    zT_70 = self->diag;
    zT_73 = self->source_file_id;
    zT_74 = bsp;
    zT_75 = bep;
    zT_76 = bg_msg;
    zT_81 = zF_C82559AC_diagnosticCollector(zT_70, (unsigned char)(0), (unsigned short)(3000), zT_73, zT_74, zT_75, zT_76);
    (void)zT_81;
    return;
    z_bb_13:
    zT_83 = self->registry;
    zT_84 = zT_83->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)bt) < zT_84)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_87 = self->registry;
    zT_88 = zT_87->types_items;
    zT_89 = (unsigned int)bt;
    zT_90 = zT_88[zT_89];
    bty = zT_90;
    zT_91 = bty.kind;
    if ((unsigned char)(zT_91 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_96 = "bool is not a valid enum backing; use an unsigned integer type (uN)";
    zT_98 = 67;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    bb_msg = zT_97;
    zT_99 = self->diag;
    zT_102 = self->source_file_id;
    zT_103 = bsp;
    zT_104 = bep;
    zT_105 = bb_msg;
    zT_110 = zF_C82559AC_diagnosticCollector(zT_99, (unsigned char)(0), (unsigned short)(3000), zT_102, zT_103, zT_104, zT_105);
    (void)zT_110;
    return;
    z_bb_17:
    zT_111 = self->registry;
    zT_112 = bt;
    zT_114 = zF_B664AC19_typeRegistryIsUnsig(zT_111, zT_112);
    if ((unsigned char)(!zT_114)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_116 = self->registry;
    zT_117 = bt;
    zT_119 = zF_01ED6537_typeRegistryIntIsSi(zT_116, zT_117);
    if (zT_119) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    check_btid = bt;
    goto z_bb_15;
    z_bb_20:
    zT_121 = "enum(iN) signed backings are not supported; use an unsigned backing (enum(uN))";
    zT_123 = 78;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    bs_msg = zT_122;
    zT_124 = self->diag;
    zT_127 = self->source_file_id;
    zT_128 = bsp;
    zT_129 = bep;
    zT_130 = bs_msg;
    zT_135 = zF_C82559AC_diagnosticCollector(zT_124, (unsigned char)(0), (unsigned short)(3000), zT_127, zT_128, zT_129, zT_130);
    (void)zT_135;
    goto z_bb_21;
    z_bb_21:
    return;
    z_bb_22:
    zT_137 = "invalid enum backing type; enum(uN) requires an unsigned integer type (uN)";
    zT_139 = 74;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    bi_msg = zT_138;
    zT_140 = self->diag;
    zT_143 = self->source_file_id;
    zT_144 = bsp;
    zT_145 = bep;
    zT_146 = bi_msg;
    zT_151 = zF_C82559AC_diagnosticCollector(zT_140, (unsigned char)(0), (unsigned short)(3000), zT_143, zT_144, zT_145, zT_146);
    (void)zT_151;
    goto z_bb_21;
    z_bb_23:
    zT_166 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)nbits)) - (zT_79FAE712_u64)(1);
    maxv = zT_166;
    goto z_bb_24;
    z_bb_24:
    zT_168 = self->registry;
    zT_169 = zT_168->en_items;
    zT_170 = ety.payload_idx;
    zT_171 = (unsigned int)zT_170;
    zT_172 = zT_169[zT_171];
    ep2 = zT_172;
    zT_174 = ep2.members_start;
    zT_175 = (unsigned int)zT_174;
    mstart2 = zT_175;
    zT_177 = ep2.members_count;
    zT_178 = (unsigned int)zT_177;
    mcount2 = zT_178;
    zT_180 = self->store;
    zT_181 = enum_node;
    zT_183 = zF_152E19CB_astStoreNodeExtraCh(zT_180, zT_181);
    children2_n = zT_183;
    zT_185 = 0;
    fcount2 = zT_185;
    zT_187 = 0;
    zT_188 = (unsigned int)zT_187;
    ci2 = zT_188;
    zT_190 = 0;
    prev_vu = zT_190;
    zT_192 = 0;
    have_prev = zT_192;
    goto z_bb_25;
    z_bb_25:
    if ((unsigned char)(ci2 < (unsigned int)((unsigned int)children2_n))) goto z_bb_29; else goto z_bb_30;
    z_bb_26:
    zT_198 = self->store;
    zT_201 = self->store;
    zT_202 = enum_node;
    zT_206 = zF_B10B1BC1_astStoreNodeExtraCh(zT_201, zT_202, (unsigned int)((unsigned int)ci2));
    zT_199 = zT_206;
    zT_207 = zF_FCDD1D35_astStoreNodeAt(zT_198, zT_199);
    fd2 = zT_207;
    zT_208 = fd2.kind;
    if ((unsigned char)(zT_208 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return;
    z_bb_28:
    zT_275 = ci2 + (unsigned int)(1);
    ci2 = zT_275;
    goto z_bb_25;
    z_bb_29:
    zT_195 = fcount2 < mcount2;
    goto z_bb_31;
    z_bb_30:
    zT_195 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_195) goto z_bb_26; else goto z_bb_27;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_213 = self->registry;
    zT_214 = zT_213->em_items;
    zT_215 = mstart2 + fcount2;
    zT_216 = zT_214[zT_215];
    zT_217 = zT_216.value;
    mv = zT_217;
    zT_219 = (zT_79FAE712_u64)mv;
    mvu = zT_219;
    if ((unsigned char)(mvu > maxv)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_222 = fd2.span_start;
    msp = zT_222;
    zT_224 = fd2.span_len;
    zT_226 = msp + (unsigned int)((unsigned int)zT_224);
    mep = zT_226;
    zT_228 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_230 = 91;
    zT_229.ptr = zT_228;
    zT_229.len = zT_230;
    mv_msg = zT_229;
    zT_231 = self->diag;
    zT_234 = self->source_file_id;
    zT_235 = msp;
    zT_236 = mep;
    zT_237 = mv_msg;
    zT_242 = zF_C82559AC_diagnosticCollector(zT_231, (unsigned char)(0), (unsigned short)(3000), zT_234, zT_235, zT_236, zT_237);
    (void)zT_242;
    return;
    z_bb_35:
    if (have_prev) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_243 = prev_vu == maxv;
    goto z_bb_38;
    z_bb_37:
    zT_243 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_243) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_246 = fd2.child_1;
    zT_245 = zT_246 == (unsigned int)(0);
    goto z_bb_41;
    z_bb_40:
    zT_245 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_245) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_250 = fd2.span_start;
    msp = zT_250;
    zT_252 = fd2.span_len;
    zT_254 = msp + (unsigned int)((unsigned int)zT_252);
    mep = zT_254;
    zT_256 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_258 = 91;
    zT_257.ptr = zT_256;
    zT_257.len = zT_258;
    mv_msg = zT_257;
    zT_259 = self->diag;
    zT_262 = self->source_file_id;
    zT_263 = msp;
    zT_264 = mep;
    zT_265 = mv_msg;
    zT_270 = zF_C82559AC_diagnosticCollector(zT_259, (unsigned char)(0), (unsigned short)(3000), zT_262, zT_263, zT_264, zT_265);
    (void)zT_270;
    return;
    z_bb_43:
    prev_vu = mvu;
    zT_271 = 1;
    have_prev = zT_271;
    zT_273 = fcount2 + (unsigned int)(1);
    fcount2 = zT_273;
    goto z_bb_28;
}

/* semanticAnalyzerCheckLocalEnum */
void zF_E3AF2BA9_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int enum_node) {
    zT_ABC1EBBE_TypeResolveEnv zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_3D7259E2_SymbolRegistry* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_F85C5DED_DiagnosticCollector* zT_12;
    zT_7034F045_Opt_228 zT_13;
    zT_03B97CED_Opt_398 zT_14 = {0};
    zT_05CE5599_Opt_400 zT_15 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_16;
    unsigned int zT_17;
    zT_ABC1EBBE_TypeResolveEnv env;
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_5.store = zT_6;
    zT_7 = self->registry;
    zT_5.typereg = zT_7;
    zT_8 = self->symbols;
    zT_5.symbol_reg = zT_8;
    zT_9 = self->interner;
    zT_5.interner = zT_9;
    zT_10 = self->module_id;
    zT_5.module_id = zT_10;
    zT_11 = self->source_file_id;
    zT_5.source_file_id = zT_11;
    zT_12 = self->diag;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    zT_5.diag = zT_13;
    zT_14.has_value = 0;
    zT_5.local_consts = zT_14;
    zT_15.has_value = 0;
    zT_5.local_types = zT_15;
    env = zT_5;
    zT_16 = &env;
    zT_17 = enum_node;
    zF_9084D8CB_validateLocalEnum(zT_16, zT_17);
    return;
}

/* semanticAnalyzerPackedStructDeclForType */
unsigned int zF_1BB4D489_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_43;
    unsigned int zT_44;
    zT_3D7259E2_SymbolRegistry* zT_47;
    zT_060CD1EB_SymbolTable* zT_48;
    zT_060CD1EB_SymbolTable zT_49;
    int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_3A105EF1_Symbol* zT_56;
    zT_3A105EF1_Symbol zT_57;
    zT_3C598AEF_SymbolKind zT_58;
    unsigned int zT_62;
    unsigned char zT_64;
    unsigned int zT_65;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    zT_22A7C88B_AstNode zT_73 = {0};
    unsigned int zT_75;
    zT_8143F551_AstKind zT_76;
    unsigned int zT_80;
    zT_8143F551_AstKind zT_81;
    unsigned char zT_85;
    unsigned int zT_86;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    zT_22A7C88B_AstNode zT_94 = {0};
    zT_8143F551_AstKind zT_95;
    unsigned int zT_99;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    zT_22A7C88B_AstNode zT_106 = {0};
    unsigned char zT_107;
    zT_38C12417_SemanticAnalyzer* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned int zT_118;
    zT_38C12417_SemanticAnalyzer* zT_119;
    unsigned int zT_120;
    unsigned int hc;
    unsigned int cc;
    zT_D155D06D_Type sty;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol s;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    zT_22A7C88B_AstNode inn;
    zT_22A7C88B_AstNode tnode;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    hc = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_struct_cache_len;
    if ((unsigned char)(hc < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = zT_7[hc];
    if ((unsigned char)(zT_8 == struct_tid)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    cc = zT_16;
    goto z_bb_7;
    z_bb_4:
    zT_13 = hc + (unsigned int)(1);
    hc = zT_13;
    goto z_bb_1;
    z_bb_5:
    zT_10 = self->packed_struct_decl_nodes;
    zT_11 = zT_10[hc];
    return zT_11;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_17 = self->checked_struct_tids_len;
    if ((unsigned char)(cc < zT_17)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_19 = self->checked_struct_tids;
    zT_20 = zT_19[cc];
    if ((unsigned char)(zT_20 == struct_tid)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_26 = self->registry;
    zT_27 = zT_26->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)struct_tid) >= zT_27)) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_24 = cc + (unsigned int)(1);
    cc = zT_24;
    goto z_bb_7;
    z_bb_11:
    return (unsigned int)(0);
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    return (unsigned int)(0);
    z_bb_14:
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)struct_tid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_35 = sty.kind;
    if ((unsigned char)(zT_35 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned int)(0);
    z_bb_16:
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ti = zT_42;
    goto z_bb_17;
    z_bb_17:
    zT_43 = self->symbols;
    zT_44 = zT_43->tables_len;
    if ((unsigned char)(ti < zT_44)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_47 = self->symbols;
    zT_48 = zT_47->tables_items;
    zT_49 = zT_48[ti];
    table = zT_49;
    zT_51 = 0;
    zT_52 = (unsigned int)zT_51;
    si = zT_52;
    goto z_bb_21;
    z_bb_19:
    zT_119 = self;
    zT_120 = struct_tid;
    zF_B5A1E8BB_semanticAnalyzerChe(zT_119, zT_120);
    return (unsigned int)(0);
    z_bb_20:
    zT_118 = ti + (unsigned int)(1);
    ti = zT_118;
    goto z_bb_17;
    z_bb_21:
    zT_53 = table.len;
    if ((unsigned char)(si < zT_53)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_56 = table.items;
    zT_57 = zT_56[si];
    s = zT_57;
    zT_58 = s.kind;
    if ((unsigned char)(zT_58 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_116 = si + (unsigned int)(1);
    si = zT_116;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_62 = s.type_id;
    if ((unsigned char)(zT_62 != struct_tid)) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_65 = s.decl_node;
    zT_64 = zT_65 == (unsigned int)(0);
    goto z_bb_29;
    z_bb_28:
    zT_64 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_64) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    goto z_bb_24;
    z_bb_31:
    zT_69 = self->store;
    zT_70 = s.decl_node;
    zT_73 = zF_FCDD1D35_astStoreNodeAt(zT_69, zT_70);
    dnode = zT_73;
    zT_75 = 0;
    target = zT_75;
    zT_76 = dnode.kind;
    if ((unsigned char)(zT_76 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_80 = s.decl_node;
    target = zT_80;
    goto z_bb_33;
    z_bb_33:
    if ((unsigned char)(target == (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_34:
    zT_81 = dnode.kind;
    if ((unsigned char)(zT_81 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_86 = dnode.child_1;
    zT_85 = zT_86 != (unsigned int)(0);
    goto z_bb_37;
    z_bb_36:
    zT_85 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_85) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_90 = self->store;
    zT_91 = dnode.child_1;
    zT_94 = zF_FCDD1D35_astStoreNodeAt(zT_90, zT_91);
    inn = zT_94;
    zT_95 = inn.kind;
    if ((unsigned char)(zT_95 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_33;
    z_bb_40:
    zT_99 = dnode.child_1;
    target = zT_99;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    goto z_bb_24;
    z_bb_43:
    zT_103 = self->store;
    zT_104 = target;
    zT_106 = zF_FCDD1D35_astStoreNodeAt(zT_103, zT_104);
    tnode = zT_106;
    zT_107 = tnode.flags;
    if ((unsigned char)((unsigned char)(zT_107 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_112 = self;
    zT_113 = struct_tid;
    zT_114 = target;
    zF_2C47D4E0_semanticAnalyzerPac(zT_112, zT_113, zT_114);
    return target;
    z_bb_45:
    goto z_bb_24;
}

/* semanticAnalyzerResolveArithmetic */
unsigned int zF_44006DDD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    zT_38C12417_SemanticAnalyzer* zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    unsigned char zT_20;
    unsigned char zT_27;
    zT_338B7C76_TypeRegistry* zT_32;
    unsigned int zT_33;
    unsigned char zT_35 = 0;
    unsigned char zT_36;
    zT_338B7C76_TypeRegistry* zT_37;
    unsigned int zT_38;
    unsigned char zT_40 = 0;
    zT_338B7C76_TypeRegistry* zT_42;
    unsigned int zT_43;
    unsigned char zT_45 = 0;
    unsigned char zT_46;
    zT_338B7C76_TypeRegistry* zT_50;
    unsigned int zT_51;
    unsigned char zT_53 = 0;
    unsigned char zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    unsigned int zT_56;
    unsigned char zT_58 = 0;
    unsigned char zT_59;
    unsigned char zT_63;
    zT_338B7C76_TypeRegistry* zT_64;
    unsigned int zT_65;
    unsigned char zT_67 = 0;
    unsigned char zT_68;
    unsigned char zT_71;
    unsigned char zT_75;
    unsigned char zT_76;
    unsigned char zT_80;
    zT_338B7C76_TypeRegistry* zT_81;
    unsigned int zT_82;
    unsigned char zT_84 = 0;
    unsigned char zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    unsigned int zT_89;
    unsigned char zT_91 = 0;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    unsigned char zT_95 = 0;
    unsigned char zT_97;
    zT_338B7C76_TypeRegistry* zT_98;
    unsigned int zT_99;
    unsigned char zT_101 = 0;
    zT_338B7C76_TypeRegistry* zT_105;
    unsigned int zT_106;
    unsigned char zT_108 = 0;
    unsigned char zT_109;
    zT_338B7C76_TypeRegistry* zT_110;
    unsigned int zT_111;
    unsigned char zT_113 = 0;
    zT_338B7C76_TypeRegistry* zT_115;
    unsigned int zT_116;
    unsigned char zT_118 = 0;
    zT_338B7C76_TypeRegistry* zT_120;
    unsigned int zT_121;
    unsigned char zT_123 = 0;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_D155D06D_Type* zT_127;
    unsigned int zT_128;
    zT_D155D06D_Type zT_129;
    unsigned int zT_130;
    zT_338B7C76_TypeRegistry* zT_132;
    zT_D155D06D_Type* zT_133;
    unsigned int zT_134;
    zT_D155D06D_Type zT_135;
    unsigned int zT_136;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    unsigned char lhs_ptr;
    unsigned char rhs_uint;
    unsigned char rhs_ptr;
    unsigned char lw;
    unsigned char rw;
    unsigned int ls;
    unsigned int rs;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    lhs = zT_12;
    zT_14 = self;
    zT_15 = node.child_1;
    zT_17 = zF_54F95822_semanticAnalyzerRes(zT_14, zT_15);
    rhs = zT_17;
    if ((unsigned char)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_20 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_20 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_20) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_27 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_8;
    z_bb_7:
    zT_27 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = self->registry;
    zT_33 = lhs;
    zT_35 = zF_AD61DB1B_typeRegistryIsPoint(zT_32, zT_33);
    if (zT_35) goto z_bb_12; else goto z_bb_11;
    z_bb_10:
    if ((unsigned char)(lhs == (unsigned int)(19))) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_37 = self->registry;
    zT_38 = lhs;
    zT_40 = zF_0F4CC580_typeRegistryIsSlice(zT_37, zT_38);
    zT_36 = zT_40;
    goto z_bb_13;
    z_bb_12:
    zT_36 = 1;
    goto z_bb_13;
    z_bb_13:
    lhs_ptr = zT_36;
    zT_42 = self->registry;
    zT_43 = rhs;
    zT_45 = zF_B664AC19_typeRegistryIsUnsig(zT_42, zT_43);
    if (zT_45) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_46 = rhs == (unsigned int)(19);
    goto z_bb_16;
    z_bb_15:
    zT_46 = 1;
    goto z_bb_16;
    z_bb_16:
    rhs_uint = zT_46;
    zT_50 = self->registry;
    zT_51 = rhs;
    zT_53 = zF_AD61DB1B_typeRegistryIsPoint(zT_50, zT_51);
    if (zT_53) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_55 = self->registry;
    zT_56 = rhs;
    zT_58 = zF_0F4CC580_typeRegistryIsSlice(zT_55, zT_56);
    zT_54 = zT_58;
    goto z_bb_19;
    z_bb_18:
    zT_54 = 1;
    goto z_bb_19;
    z_bb_19:
    rhs_ptr = zT_54;
    if (lhs_ptr) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_59 = rhs_uint;
    goto z_bb_22;
    z_bb_21:
    zT_59 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_59) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return lhs;
    z_bb_24:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_64 = self->registry;
    zT_65 = lhs;
    zT_67 = zF_B664AC19_typeRegistryIsUnsig(zT_64, zT_65);
    if (zT_67) goto z_bb_29; else goto z_bb_28;
    z_bb_26:
    zT_63 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_63) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_68 = lhs == (unsigned int)(19);
    goto z_bb_30;
    z_bb_29:
    zT_68 = 1;
    goto z_bb_30;
    z_bb_30:
    zT_63 = zT_68;
    goto z_bb_27;
    z_bb_31:
    zT_71 = rhs_ptr;
    goto z_bb_33;
    z_bb_32:
    zT_71 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_71) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return rhs;
    z_bb_35:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_75 = lhs_ptr;
    goto z_bb_38;
    z_bb_37:
    zT_75 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_75) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_76 = rhs_ptr;
    goto z_bb_41;
    z_bb_40:
    zT_76 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_76) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (unsigned int)(12);
    z_bb_43:
    goto z_bb_10;
    z_bb_44:
    zT_81 = self->registry;
    zT_82 = rhs;
    zT_84 = zF_3087E0A5_typeRegistryIsNumer(zT_81, zT_82);
    zT_80 = zT_84;
    goto z_bb_46;
    z_bb_45:
    zT_80 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_80) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return rhs;
    z_bb_48:
    if ((unsigned char)(rhs == (unsigned int)(19))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_88 = self->registry;
    zT_89 = lhs;
    zT_91 = zF_3087E0A5_typeRegistryIsNumer(zT_88, zT_89);
    zT_87 = zT_91;
    goto z_bb_51;
    z_bb_50:
    zT_87 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_87) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    return lhs;
    z_bb_53:
    zT_92 = self->registry;
    zT_93 = lhs;
    zT_95 = zF_3087E0A5_typeRegistryIsNumer(zT_92, zT_93);
    if ((unsigned char)(!zT_95)) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_98 = self->registry;
    zT_99 = rhs;
    zT_101 = zF_3087E0A5_typeRegistryIsNumer(zT_98, zT_99);
    zT_97 = !zT_101;
    goto z_bb_56;
    z_bb_55:
    zT_97 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_97) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned int)(1);
    z_bb_58:
    if ((unsigned char)(lhs == rhs)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return lhs;
    z_bb_60:
    zT_105 = self->registry;
    zT_106 = lhs;
    zT_108 = zF_3290E9C4_typeRegistryIsInteg(zT_105, zT_106);
    if (zT_108) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_110 = self->registry;
    zT_111 = rhs;
    zT_113 = zF_3290E9C4_typeRegistryIsInteg(zT_110, zT_111);
    zT_109 = zT_113;
    goto z_bb_63;
    z_bb_62:
    zT_109 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_109) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_115 = self->registry;
    zT_116 = lhs;
    zT_118 = zF_655972D5_typeRegistryIntWidt(zT_115, zT_116);
    lw = zT_118;
    zT_120 = self->registry;
    zT_121 = rhs;
    zT_123 = zF_655972D5_typeRegistryIntWidt(zT_120, zT_121);
    rw = zT_123;
    if ((unsigned char)(lw >= rw)) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    zT_126 = self->registry;
    zT_127 = zT_126->types_items;
    zT_128 = (unsigned int)lhs;
    zT_129 = zT_127[zT_128];
    zT_130 = zT_129.size;
    ls = zT_130;
    zT_132 = self->registry;
    zT_133 = zT_132->types_items;
    zT_134 = (unsigned int)rhs;
    zT_135 = zT_133[zT_134];
    zT_136 = zT_135.size;
    rs = zT_136;
    if ((unsigned char)(ls >= rs)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    return lhs;
    z_bb_67:
    return rhs;
    z_bb_68:
    return lhs;
    z_bb_69:
    return rhs;
}

/* semanticAnalyzerResolveBitwise */
unsigned int zF_733BCA9C_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned char zT_19;
    unsigned char zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    unsigned char zT_29 = 0;
    unsigned char zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    unsigned char zT_36 = 0;
    unsigned char zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    unsigned char zT_42 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    lhs = zT_11;
    zT_13 = self;
    zT_14 = node.child_1;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    rhs = zT_16;
    if ((unsigned char)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_19 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_19 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((unsigned char)(lhs == (unsigned int)(19))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_26 = self->registry;
    zT_27 = rhs;
    zT_29 = zF_3290E9C4_typeRegistryIsInteg(zT_26, zT_27);
    zT_25 = zT_29;
    goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_25) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return rhs;
    z_bb_10:
    if ((unsigned char)(rhs == (unsigned int)(19))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->registry;
    zT_34 = lhs;
    zT_36 = zF_3290E9C4_typeRegistryIsInteg(zT_33, zT_34);
    zT_32 = zT_36;
    goto z_bb_13;
    z_bb_12:
    zT_32 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_32) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return lhs;
    z_bb_15:
    if ((unsigned char)(lhs != rhs)) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_39 = self->registry;
    zT_40 = lhs;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_39, zT_40);
    zT_38 = !zT_42;
    goto z_bb_18;
    z_bb_17:
    zT_38 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_38) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned int)(1);
    z_bb_20:
    return lhs;
}

/* semanticAnalyzerResolveComparison */
unsigned int zF_EB621FF0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_24 = {0};
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    unsigned char zT_36;
    zT_8143F551_AstKind zT_37;
    unsigned char zT_41;
    zT_8143F551_AstKind zT_45;
    unsigned char zT_49;
    zT_8143F551_AstKind zT_50;
    unsigned char zT_54;
    unsigned char zT_59;
    zT_38C12417_SemanticAnalyzer* zT_62;
    unsigned int zT_63;
    unsigned int zT_65 = 0;
    int zT_67;
    unsigned int zT_68;
    int zT_69;
    unsigned char zT_71;
    unsigned char zT_74;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_D155D06D_Type* zT_78;
    unsigned int zT_79;
    zT_D155D06D_Type zT_80;
    zT_33EF6BFB_TypeKind zT_81;
    unsigned int zT_82;
    zT_8143F551_AstKind zT_83;
    unsigned char zT_87;
    unsigned char zT_91;
    zT_8143F551_AstKind zT_92;
    unsigned char zT_96;
    zT_38C12417_SemanticAnalyzer* zT_100;
    unsigned int zT_101;
    zT_38C12417_SemanticAnalyzer* zT_102;
    unsigned int zT_103;
    unsigned int zT_105 = 0;
    zT_38C12417_SemanticAnalyzer* zT_106;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_108;
    unsigned int zT_110 = 0;
    unsigned char zT_113;
    zT_38C12417_SemanticAnalyzer* zT_116;
    unsigned int zT_117;
    unsigned int zT_119 = 0;
    int zT_121;
    unsigned int zT_122;
    int zT_123;
    unsigned char zT_125;
    unsigned char zT_128;
    zT_338B7C76_TypeRegistry* zT_131;
    zT_D155D06D_Type* zT_132;
    unsigned int zT_133;
    zT_D155D06D_Type zT_134;
    zT_33EF6BFB_TypeKind zT_135;
    unsigned int zT_136;
    zT_8143F551_AstKind zT_137;
    unsigned char zT_141;
    unsigned char zT_145;
    zT_8143F551_AstKind zT_146;
    unsigned char zT_150;
    zT_38C12417_SemanticAnalyzer* zT_154;
    unsigned int zT_155;
    zT_38C12417_SemanticAnalyzer* zT_156;
    unsigned int zT_157;
    unsigned int zT_159 = 0;
    zT_38C12417_SemanticAnalyzer* zT_160;
    zT_38C12417_SemanticAnalyzer* zT_161;
    unsigned int zT_162;
    unsigned int zT_164 = 0;
    zT_38C12417_SemanticAnalyzer* zT_165;
    unsigned int zT_166;
    unsigned int zT_168 = 0;
    zT_38C12417_SemanticAnalyzer* zT_169;
    unsigned int zT_170;
    unsigned int zT_172 = 0;
    unsigned char zT_175;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned char zT_186;
    zT_338B7C76_TypeRegistry* zT_187;
    unsigned int zT_188;
    unsigned char zT_190 = 0;
    unsigned char* zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned char zT_199;
    zT_338B7C76_TypeRegistry* zT_200;
    unsigned int zT_201;
    unsigned char zT_203 = 0;
    unsigned char* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    zT_338B7C76_TypeRegistry* zT_211;
    unsigned int zT_212;
    unsigned char zT_214 = 0;
    unsigned char zT_215;
    unsigned char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned char zT_226;
    zT_338B7C76_TypeRegistry* zT_230;
    unsigned int zT_231;
    unsigned char zT_233 = 0;
    unsigned char zT_234;
    zT_338B7C76_TypeRegistry* zT_238;
    unsigned int zT_239;
    unsigned char zT_241 = 0;
    unsigned char zT_242;
    zT_338B7C76_TypeRegistry* zT_246;
    unsigned int zT_247;
    unsigned char zT_249 = 0;
    unsigned char zT_250;
    zT_338B7C76_TypeRegistry* zT_251;
    unsigned int zT_252;
    unsigned char zT_254 = 0;
    unsigned char* zT_256;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_257;
    unsigned int zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    zT_338B7C76_TypeRegistry* zT_270;
    unsigned int zT_271;
    unsigned char zT_273 = 0;
    unsigned char* zT_275;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_276;
    unsigned int zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    zT_338B7C76_TypeRegistry* zT_281;
    zT_D155D06D_Type* zT_282;
    unsigned int zT_283;
    zT_D155D06D_Type zT_284;
    zT_33EF6BFB_TypeKind zT_285;
    unsigned char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned char* zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_301;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    int zT_307;
    unsigned char* zT_308;
    unsigned int zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    unsigned int zT_311 = 0;
    unsigned int zT_315;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    unsigned char* zT_320;
    unsigned int zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned char* zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_329;
    unsigned int zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    int zT_335;
    unsigned char* zT_336;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned int zT_339 = 0;
    unsigned int zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned char* zT_348;
    unsigned int zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned char* zT_352;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_353;
    unsigned int zT_354;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_355;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_357;
    unsigned int zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    int zT_364;
    unsigned char* zT_365;
    unsigned int zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    unsigned int zT_368 = 0;
    unsigned int zT_372;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_373;
    unsigned char* zT_377;
    unsigned int zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned char* zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_382;
    unsigned int zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_22A7C88B_AstNode c0n;
    zT_22A7C88B_AstNode c1n;
    unsigned char c0_lit;
    unsigned char c1_lit;
    unsigned int peerk;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp0;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp2;
    unsigned char lhs_num;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp3;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp4;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_lb;
    unsigned int cpv_ll;
    unsigned int cpv_ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_rh;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_rb;
    unsigned int cpv_rl;
    unsigned int cpv_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_ih;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_ib;
    unsigned int cpv_il;
    unsigned int cpv_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp5;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp6;
    zT_33EF6BFB_TypeKind lk;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp7;
    zT_4 = "CPE";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    cpe = zT_5;
    zT_7 = cpe;
    zF_48AC7B3A_markerWrite(zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    lhs = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    rhs = zT_18;
    zT_20 = self->store;
    zT_21 = node.child_0;
    zT_24 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    c0n = zT_24;
    zT_26 = self->store;
    zT_27 = node.child_1;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    c1n = zT_30;
    zT_32 = c0n.kind;
    if ((unsigned char)(zT_32 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_37 = c0n.kind;
    zT_36 = zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_3;
    z_bb_2:
    zT_36 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_36) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_41 = 1;
    goto z_bb_6;
    z_bb_5:
    zT_41 = 0;
    goto z_bb_6;
    z_bb_6:
    c0_lit = zT_41;
    zT_45 = c1n.kind;
    if ((unsigned char)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_50 = c1n.kind;
    zT_49 = zT_50 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_9;
    z_bb_8:
    zT_49 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_49) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_54 = 1;
    goto z_bb_12;
    z_bb_11:
    zT_54 = 0;
    goto z_bb_12;
    z_bb_12:
    c1_lit = zT_54;
    if ((unsigned char)(c0_lit == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_59 = c1_lit != (unsigned char)(0);
    goto z_bb_15;
    z_bb_14:
    zT_59 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_59) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_62 = self;
    zT_63 = node.child_0;
    zT_65 = zF_54F95822_semanticAnalyzerRes(zT_62, zT_63);
    lhs = zT_65;
    zT_67 = 0;
    zT_68 = (unsigned int)zT_67;
    peerk = zT_68;
    zT_69 = 0;
    if ((unsigned char)(lhs != (unsigned int)zT_69)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    if ((unsigned char)(lhs == (unsigned int)(0))) goto z_bb_66; else goto z_bb_65;
    z_bb_18:
    if ((unsigned char)(c0_lit != (unsigned char)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_19:
    zT_71 = lhs != (unsigned int)(1);
    goto z_bb_21;
    z_bb_20:
    zT_71 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_71) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_74 = lhs != (unsigned int)(18);
    goto z_bb_24;
    z_bb_23:
    zT_74 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_74) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_77 = self->registry;
    zT_78 = zT_77->types_items;
    zT_79 = (unsigned int)lhs;
    zT_80 = zT_78[zT_79];
    zT_81 = zT_80.kind;
    zT_82 = (unsigned int)zT_81;
    peerk = zT_82;
    goto z_bb_26;
    z_bb_26:
    zT_83 = c1n.kind;
    if ((unsigned char)(zT_83 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_87 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_29;
    z_bb_28:
    zT_87 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_87) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_92 = c1n.kind;
    if ((unsigned char)(zT_92 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_91 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_91) goto z_bb_36; else goto z_bb_38;
    z_bb_33:
    zT_96 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_35;
    z_bb_34:
    zT_96 = 0;
    goto z_bb_35;
    z_bb_35:
    zT_91 = zT_96;
    goto z_bb_32;
    z_bb_36:
    zT_100 = self;
    zT_101 = lhs;
    zF_9665A229_pushExpectedType(zT_100, zT_101);
    zT_102 = self;
    zT_103 = node.child_1;
    zT_105 = zF_54F95822_semanticAnalyzerRes(zT_102, zT_103);
    rhs = zT_105;
    zT_106 = self;
    zF_BC478E78_popExpectedType(zT_106);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_17;
    z_bb_38:
    zT_107 = self;
    zT_108 = node.child_1;
    zT_110 = zF_54F95822_semanticAnalyzerRes(zT_107, zT_108);
    rhs = zT_110;
    goto z_bb_37;
    z_bb_39:
    zT_113 = c1_lit == (unsigned char)(0);
    goto z_bb_41;
    z_bb_40:
    zT_113 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_113) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_116 = self;
    zT_117 = node.child_1;
    zT_119 = zF_54F95822_semanticAnalyzerRes(zT_116, zT_117);
    rhs = zT_119;
    zT_121 = 0;
    zT_122 = (unsigned int)zT_121;
    peerk = zT_122;
    zT_123 = 0;
    if ((unsigned char)(rhs != (unsigned int)zT_123)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_17;
    z_bb_44:
    zT_165 = self;
    zT_166 = node.child_0;
    zT_168 = zF_54F95822_semanticAnalyzerRes(zT_165, zT_166);
    lhs = zT_168;
    zT_169 = self;
    zT_170 = node.child_1;
    zT_172 = zF_54F95822_semanticAnalyzerRes(zT_169, zT_170);
    rhs = zT_172;
    goto z_bb_43;
    z_bb_45:
    zT_125 = rhs != (unsigned int)(1);
    goto z_bb_47;
    z_bb_46:
    zT_125 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_125) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_128 = rhs != (unsigned int)(18);
    goto z_bb_50;
    z_bb_49:
    zT_128 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_128) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_131 = self->registry;
    zT_132 = zT_131->types_items;
    zT_133 = (unsigned int)rhs;
    zT_134 = zT_132[zT_133];
    zT_135 = zT_134.kind;
    zT_136 = (unsigned int)zT_135;
    peerk = zT_136;
    goto z_bb_52;
    z_bb_52:
    zT_137 = c0n.kind;
    if ((unsigned char)(zT_137 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_141 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_55;
    z_bb_54:
    zT_141 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_141) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_146 = c0n.kind;
    if ((unsigned char)(zT_146 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_145 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_145) goto z_bb_62; else goto z_bb_64;
    z_bb_59:
    zT_150 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_61;
    z_bb_60:
    zT_150 = 0;
    goto z_bb_61;
    z_bb_61:
    zT_145 = zT_150;
    goto z_bb_58;
    z_bb_62:
    zT_154 = self;
    zT_155 = rhs;
    zF_9665A229_pushExpectedType(zT_154, zT_155);
    zT_156 = self;
    zT_157 = node.child_0;
    zT_159 = zF_54F95822_semanticAnalyzerRes(zT_156, zT_157);
    lhs = zT_159;
    zT_160 = self;
    zF_BC478E78_popExpectedType(zT_160);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_43;
    z_bb_64:
    zT_161 = self;
    zT_162 = node.child_0;
    zT_164 = zF_54F95822_semanticAnalyzerRes(zT_161, zT_162);
    lhs = zT_164;
    goto z_bb_63;
    z_bb_65:
    zT_175 = rhs == (unsigned int)(0);
    goto z_bb_67;
    z_bb_66:
    zT_175 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_175) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_179 = "CP0";
    zT_181 = 3;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    cp0 = zT_180;
    zT_182 = cp0;
    zF_48AC7B3A_markerWrite(zT_182);
    return (unsigned int)(1);
    z_bb_69:
    if ((unsigned char)(lhs == (unsigned int)(19))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_187 = self->registry;
    zT_188 = rhs;
    zT_190 = zF_3087E0A5_typeRegistryIsNumer(zT_187, zT_188);
    zT_186 = zT_190;
    goto z_bb_72;
    z_bb_71:
    zT_186 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_186) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_192 = "CPB";
    zT_194 = 3;
    zT_193.ptr = zT_192;
    zT_193.len = zT_194;
    cp1 = zT_193;
    zT_195 = cp1;
    zF_48AC7B3A_markerWrite(zT_195);
    return (unsigned int)(2);
    z_bb_74:
    if ((unsigned char)(rhs == (unsigned int)(19))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_200 = self->registry;
    zT_201 = lhs;
    zT_203 = zF_3087E0A5_typeRegistryIsNumer(zT_200, zT_201);
    zT_199 = zT_203;
    goto z_bb_77;
    z_bb_76:
    zT_199 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_199) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_205 = "CPB";
    zT_207 = 3;
    zT_206.ptr = zT_205;
    zT_206.len = zT_207;
    cp2 = zT_206;
    zT_208 = cp2;
    zF_48AC7B3A_markerWrite(zT_208);
    return (unsigned int)(2);
    z_bb_79:
    zT_211 = self->registry;
    zT_212 = lhs;
    zT_214 = zF_3087E0A5_typeRegistryIsNumer(zT_211, zT_212);
    lhs_num = zT_214;
    if (lhs_num) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_215 = lhs == rhs;
    goto z_bb_82;
    z_bb_81:
    zT_215 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_215) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_218 = "CPB";
    zT_220 = 3;
    zT_219.ptr = zT_218;
    zT_219.len = zT_220;
    cp3 = zT_219;
    zT_221 = cp3;
    zF_48AC7B3A_markerWrite(zT_221);
    return (unsigned int)(2);
    z_bb_84:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_226 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_87;
    z_bb_86:
    zT_226 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_226) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_230 = self->registry;
    zT_231 = lhs;
    zT_233 = zF_DA6AF452_typeRegistryIsOptio(zT_230, zT_231);
    if (zT_233) goto z_bb_90; else goto z_bb_91;
    z_bb_89:
    if ((unsigned char)(lhs == rhs)) goto z_bb_105; else goto z_bb_106;
    z_bb_90:
    zT_234 = rhs == (unsigned int)(17);
    goto z_bb_92;
    z_bb_91:
    zT_234 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_234) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned int)(2);
    z_bb_94:
    zT_238 = self->registry;
    zT_239 = rhs;
    zT_241 = zF_DA6AF452_typeRegistryIsOptio(zT_238, zT_239);
    if (zT_241) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_242 = lhs == (unsigned int)(17);
    goto z_bb_97;
    z_bb_96:
    zT_242 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_242) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    return (unsigned int)(2);
    z_bb_99:
    zT_246 = self->registry;
    zT_247 = lhs;
    zT_249 = zF_B8767394_typeRegistryIsError(zT_246, zT_247);
    if (zT_249) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_251 = self->registry;
    zT_252 = rhs;
    zT_254 = zF_B8767394_typeRegistryIsError(zT_251, zT_252);
    zT_250 = zT_254;
    goto z_bb_102;
    z_bb_101:
    zT_250 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_250) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_256 = "CPB";
    zT_258 = 3;
    zT_257.ptr = zT_256;
    zT_257.len = zT_258;
    cp4 = zT_257;
    zT_259 = cp4;
    zF_48AC7B3A_markerWrite(zT_259);
    return (unsigned int)(2);
    z_bb_104:
    goto z_bb_89;
    z_bb_105:
    if ((unsigned char)(lhs == (unsigned int)(2))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_296 = "CPVl";
    zT_298 = 4;
    zT_297.ptr = zT_296;
    zT_297.len = zT_298;
    cpv = zT_297;
    zT_299 = cpv;
    zF_48AC7B3A_markerWrite(zT_299);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_301[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_lb[_i] = zT_301[_i];
        _i++;
    }
}
    zT_303 = lhs;
    zT_307 = 0;
    zT_308 = (unsigned char*)((unsigned char*)cpv_lb) + zT_307;
    zT_309 = (unsigned int)(10) - zT_307;
    zT_310.ptr = zT_308;
    zT_310.len = zT_309;
    zT_304 = zT_310;
    zT_311 = zF_A7504564_itoa(zT_303, zT_304);
    cpv_ll = zT_311;
    zT_315 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_ll);
    cpv_ls = zT_315;
    zT_320 = (unsigned char*)((unsigned char*)cpv_lb) + cpv_ls;
    zT_321 = (unsigned int)(9) - cpv_ls;
    zT_322.ptr = zT_320;
    zT_322.len = zT_321;
    zT_316 = zT_322;
    zF_48AC7B3A_markerWrite(zT_316);
    zT_324 = "r";
    zT_326 = 1;
    zT_325.ptr = zT_324;
    zT_325.len = zT_326;
    cpv_rh = zT_325;
    zT_327 = cpv_rh;
    zF_48AC7B3A_markerWrite(zT_327);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_329[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_rb[_i] = zT_329[_i];
        _i++;
    }
}
    zT_331 = rhs;
    zT_335 = 0;
    zT_336 = (unsigned char*)((unsigned char*)cpv_rb) + zT_335;
    zT_337 = (unsigned int)(10) - zT_335;
    zT_338.ptr = zT_336;
    zT_338.len = zT_337;
    zT_332 = zT_338;
    zT_339 = zF_A7504564_itoa(zT_331, zT_332);
    cpv_rl = zT_339;
    zT_343 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_rl);
    cpv_rs = zT_343;
    zT_348 = (unsigned char*)((unsigned char*)cpv_rb) + cpv_rs;
    zT_349 = (unsigned int)(9) - cpv_rs;
    zT_350.ptr = zT_348;
    zT_350.len = zT_349;
    zT_344 = zT_350;
    zF_48AC7B3A_markerWrite(zT_344);
    zT_352 = "n";
    zT_354 = 1;
    zT_353.ptr = zT_352;
    zT_353.len = zT_354;
    cpv_ih = zT_353;
    zT_355 = cpv_ih;
    zF_48AC7B3A_markerWrite(zT_355);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_357[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_ib[_i] = zT_357[_i];
        _i++;
    }
}
    zT_359 = node.child_0;
    zT_364 = 0;
    zT_365 = (unsigned char*)((unsigned char*)cpv_ib) + zT_364;
    zT_366 = (unsigned int)(10) - zT_364;
    zT_367.ptr = zT_365;
    zT_367.len = zT_366;
    zT_360 = zT_367;
    zT_368 = zF_A7504564_itoa(zT_359, zT_360);
    cpv_il = zT_368;
    zT_372 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_il);
    cpv_is = zT_372;
    zT_377 = (unsigned char*)((unsigned char*)cpv_ib) + cpv_is;
    zT_378 = (unsigned int)(9) - cpv_is;
    zT_379.ptr = zT_377;
    zT_379.len = zT_378;
    zT_373 = zT_379;
    zF_48AC7B3A_markerWrite(zT_373);
    zT_381 = "\n";
    zT_383 = 1;
    zT_382.ptr = zT_381;
    zT_382.len = zT_383;
    cpv_nl = zT_382;
    zT_384 = cpv_nl;
    zF_48AC7B3A_markerWrite(zT_384);
    return (unsigned int)(1);
    z_bb_107:
    zT_265 = "CPB";
    zT_267 = 3;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    cp5 = zT_266;
    zT_268 = cp5;
    zF_48AC7B3A_markerWrite(zT_268);
    return (unsigned int)(2);
    z_bb_108:
    zT_270 = self->registry;
    zT_271 = lhs;
    zT_273 = zF_AD61DB1B_typeRegistryIsPoint(zT_270, zT_271);
    if (zT_273) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_275 = "CPB";
    zT_277 = 3;
    zT_276.ptr = zT_275;
    zT_276.len = zT_277;
    cp6 = zT_276;
    zT_278 = cp6;
    zF_48AC7B3A_markerWrite(zT_278);
    return (unsigned int)(2);
    z_bb_110:
    zT_281 = self->registry;
    zT_282 = zT_281->types_items;
    zT_283 = (unsigned int)lhs;
    zT_284 = zT_282[zT_283];
    zT_285 = zT_284.kind;
    lk = zT_285;
    if ((unsigned char)(lk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_290 = "CPB";
    zT_292 = 3;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    cp7 = zT_291;
    zT_293 = cp7;
    zF_48AC7B3A_markerWrite(zT_293);
    return (unsigned int)(2);
    z_bb_112:
    goto z_bb_106;
}

/* semanticAnalyzerResolveLogical */
unsigned int zF_6F2B8B98_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    unsigned char zT_24;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u loe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo2;
    zT_3 = "LOE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    loe = zT_4;
    zT_6 = loe;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_18 = self;
    zT_19 = node.child_1;
    zT_21 = zF_54F95822_semanticAnalyzerRes(zT_18, zT_19);
    rhs = zT_21;
    if ((unsigned char)(lhs == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_24 = rhs == (unsigned int)(2);
    goto z_bb_3;
    z_bb_2:
    zT_24 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_24) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_28 = "LOB";
    zT_30 = 3;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    lo1 = zT_29;
    zT_31 = lo1;
    zF_48AC7B3A_markerWrite(zT_31);
    return (unsigned int)(2);
    z_bb_5:
    zT_34 = "LOV";
    zT_36 = 3;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    lo2 = zT_35;
    zT_37 = lo2;
    zF_48AC7B3A_markerWrite(zT_37);
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveNegate */
unsigned int zF_09421FDF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    unsigned char zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((unsigned char)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((unsigned char)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3087E0A5_typeRegistryIsNumer(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveBitNot */
unsigned int zF_6B59E8AD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    unsigned char zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((unsigned char)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((unsigned char)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3290E9C4_typeRegistryIsInteg(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerVolatileDrop */
unsigned char zF_57090266_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    unsigned char zT_5;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    unsigned char zT_37;
    zT_33EF6BFB_TypeKind zT_43;
    zT_338B7C76_TypeRegistry* zT_48;
    zT_112BF819_PtrPayload* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_112BF819_PtrPayload zT_52;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_D155D06D_Type* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    zT_D155D06D_Type zT_65;
    zT_33EF6BFB_TypeKind zT_66;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_E834303C_ArrayPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_E834303C_ArrayPayload zT_74;
    unsigned int zT_75;
    zT_33EF6BFB_TypeKind zT_76;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_112BF819_PtrPayload* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_112BF819_PtrPayload zT_85;
    unsigned char zT_86;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    unsigned int zT_96;
    zT_33EF6BFB_TypeKind zT_99;
    zT_338B7C76_TypeRegistry* zT_104;
    zT_112BF819_PtrPayload* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_112BF819_PtrPayload zT_108;
    unsigned char zT_109;
    unsigned int zT_115;
    zT_33EF6BFB_TypeKind zT_117;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_0BB2A741_SlicePayload* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_0BB2A741_SlicePayload zT_126;
    unsigned char zT_127;
    unsigned int zT_133;
    unsigned char zT_135;
    unsigned char zT_138;
    unsigned int zT_139;
    unsigned char zT_142;
    unsigned char zT_145;
    unsigned int zT_146;
    zT_33EF6BFB_TypeKind zT_149;
    zT_338B7C76_TypeRegistry* zT_154;
    zT_0B10E8E9_OptionalPayload* zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_0B10E8E9_OptionalPayload zT_158;
    zT_38C12417_SemanticAnalyzer* zT_159;
    unsigned int zT_160;
    unsigned int zT_162;
    zT_33EF6BFB_TypeKind zT_165;
    zT_338B7C76_TypeRegistry* zT_170;
    zT_112BF819_PtrPayload* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    zT_112BF819_PtrPayload zT_174;
    zT_33EF6BFB_TypeKind zT_175;
    zT_338B7C76_TypeRegistry* zT_180;
    zT_112BF819_PtrPayload* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_112BF819_PtrPayload zT_184;
    unsigned char zT_185;
    unsigned int zT_191;
    unsigned int zT_192;
    zT_33EF6BFB_TypeKind zT_194;
    zT_338B7C76_TypeRegistry* zT_199;
    zT_112BF819_PtrPayload* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    zT_112BF819_PtrPayload zT_203;
    unsigned char zT_204;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned char zT_213;
    unsigned int zT_214;
    zT_33EF6BFB_TypeKind zT_217;
    zT_338B7C76_TypeRegistry* zT_222;
    zT_0B10E8E9_OptionalPayload* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    zT_0B10E8E9_OptionalPayload zT_226;
    zT_38C12417_SemanticAnalyzer* zT_227;
    unsigned int zT_228;
    unsigned int zT_230;
    zT_33EF6BFB_TypeKind zT_233;
    zT_338B7C76_TypeRegistry* zT_238;
    zT_0BB2A741_SlicePayload* zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_0BB2A741_SlicePayload zT_242;
    zT_33EF6BFB_TypeKind zT_243;
    zT_338B7C76_TypeRegistry* zT_248;
    zT_0BB2A741_SlicePayload* zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    zT_0BB2A741_SlicePayload zT_252;
    unsigned char zT_253;
    unsigned int zT_259;
    unsigned int zT_260;
    zT_33EF6BFB_TypeKind zT_262;
    zT_338B7C76_TypeRegistry* zT_267;
    zT_112BF819_PtrPayload* zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    zT_112BF819_PtrPayload zT_271;
    unsigned char zT_272;
    unsigned int zT_278;
    unsigned int zT_279;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    zT_112BF819_PtrPayload sp;
    unsigned int sp_base_eff;
    zT_D155D06D_Type sp_pointee;
    zT_112BF819_PtrPayload dp;
    zT_112BF819_PtrPayload dp2;
    zT_0BB2A741_SlicePayload ds;
    zT_0B10E8E9_OptionalPayload opt;
    zT_112BF819_PtrPayload sp2;
    zT_112BF819_PtrPayload dp3;
    zT_112BF819_PtrPayload dp4;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_0BB2A741_SlicePayload ss;
    zT_0BB2A741_SlicePayload ds2;
    zT_112BF819_PtrPayload dp5;
    z_bb_0:
    if ((unsigned char)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    if ((unsigned char)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(src_type == dst_type)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_18 = self->registry;
    zT_19 = zT_18->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src_type) >= zT_19)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)dst_type) >= zT_24)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)src_type;
    zT_31 = zT_29[zT_30];
    s = zT_31;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)dst_type;
    zT_36 = zT_34[zT_35];
    d = zT_36;
    zT_37 = s.flags;
    if ((unsigned char)((unsigned char)(zT_37 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    zT_43 = s.kind;
    if ((unsigned char)(zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_48 = self->registry;
    zT_49 = zT_48->ptr_items;
    zT_50 = s.payload_idx;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_49[zT_51];
    sp = zT_52;
    zT_54 = sp.base;
    sp_base_eff = zT_54;
    zT_55 = sp.base;
    zT_57 = self->registry;
    zT_58 = zT_57->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_55) < zT_58)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_165 = s.kind;
    if ((unsigned char)(zT_165 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_54; else goto z_bb_55;
    z_bb_21:
    zT_61 = self->registry;
    zT_62 = zT_61->types_items;
    zT_63 = sp.base;
    zT_64 = (unsigned int)zT_63;
    zT_65 = zT_62[zT_64];
    sp_pointee = zT_65;
    zT_66 = sp_pointee.kind;
    if ((unsigned char)(zT_66 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_76 = d.kind;
    if ((unsigned char)(zT_76 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_70 = self->registry;
    zT_71 = zT_70->array_items;
    zT_72 = sp_pointee.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    zT_75 = zT_74.elem;
    sp_base_eff = zT_75;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_81 = self->registry;
    zT_82 = zT_81->ptr_items;
    zT_83 = d.payload_idx;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zT_82[zT_84];
    dp = zT_85;
    zT_86 = d.flags;
    if ((unsigned char)((unsigned char)(zT_86 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_99 = d.kind;
    if ((unsigned char)(zT_99 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    zT_92 = sp.base;
    zT_93 = dp.base;
    if ((unsigned char)(zT_92 == zT_93)) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_96 = dp.base;
    zT_95 = zT_96 == (unsigned int)(1);
    goto z_bb_31;
    z_bb_30:
    zT_95 = 1;
    goto z_bb_31;
    z_bb_31:
    return zT_95;
    z_bb_32:
    zT_104 = self->registry;
    zT_105 = zT_104->ptr_items;
    zT_106 = d.payload_idx;
    zT_107 = (unsigned int)zT_106;
    zT_108 = zT_105[zT_107];
    dp2 = zT_108;
    zT_109 = d.flags;
    if ((unsigned char)((unsigned char)(zT_109 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_117 = d.kind;
    if ((unsigned char)(zT_117 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    return (unsigned char)(0);
    z_bb_35:
    zT_115 = dp2.base;
    return (unsigned char)(sp_base_eff == zT_115);
    z_bb_36:
    zT_122 = self->registry;
    zT_123 = zT_122->slice_items;
    zT_124 = d.payload_idx;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zT_123[zT_125];
    ds = zT_126;
    zT_127 = d.flags;
    if ((unsigned char)((unsigned char)(zT_127 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_149 = d.kind;
    if ((unsigned char)(zT_149 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_52; else goto z_bb_53;
    z_bb_38:
    return (unsigned char)(0);
    z_bb_39:
    zT_133 = ds.elem;
    if ((unsigned char)(sp_base_eff == zT_133)) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    if ((unsigned char)(sp_base_eff == (unsigned int)(14))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_135 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_135) goto z_bb_47; else goto z_bb_46;
    z_bb_43:
    zT_139 = ds.elem;
    zT_138 = zT_139 == (unsigned int)(8);
    goto z_bb_45;
    z_bb_44:
    zT_138 = 0;
    goto z_bb_45;
    z_bb_45:
    zT_135 = zT_138;
    goto z_bb_42;
    z_bb_46:
    if ((unsigned char)(sp_base_eff == (unsigned int)(8))) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    zT_142 = 1;
    goto z_bb_48;
    z_bb_48:
    return zT_142;
    z_bb_49:
    zT_146 = ds.elem;
    zT_145 = zT_146 == (unsigned int)(14);
    goto z_bb_51;
    z_bb_50:
    zT_145 = 0;
    goto z_bb_51;
    z_bb_51:
    zT_142 = zT_145;
    goto z_bb_48;
    z_bb_52:
    zT_154 = self->registry;
    zT_155 = zT_154->opt_items;
    zT_156 = d.payload_idx;
    zT_157 = (unsigned int)zT_156;
    zT_158 = zT_155[zT_157];
    opt = zT_158;
    zT_159 = self;
    zT_160 = src_type;
    zT_162 = opt.payload;
    self = zT_159;
    src_type = zT_160;
    dst_type = zT_162;
    goto z_bb_0;
    z_bb_53:
    return (unsigned char)(0);
    z_bb_54:
    zT_170 = self->registry;
    zT_171 = zT_170->ptr_items;
    zT_172 = s.payload_idx;
    zT_173 = (unsigned int)zT_172;
    zT_174 = zT_171[zT_173];
    sp2 = zT_174;
    zT_175 = d.kind;
    if ((unsigned char)(zT_175 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    zT_233 = s.kind;
    if ((unsigned char)(zT_233 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_69; else goto z_bb_70;
    z_bb_56:
    zT_180 = self->registry;
    zT_181 = zT_180->ptr_items;
    zT_182 = d.payload_idx;
    zT_183 = (unsigned int)zT_182;
    zT_184 = zT_181[zT_183];
    dp3 = zT_184;
    zT_185 = d.flags;
    if ((unsigned char)((unsigned char)(zT_185 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    zT_194 = d.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_60; else goto z_bb_61;
    z_bb_58:
    return (unsigned char)(0);
    z_bb_59:
    zT_191 = sp2.base;
    zT_192 = dp3.base;
    return (unsigned char)(zT_191 == zT_192);
    z_bb_60:
    zT_199 = self->registry;
    zT_200 = zT_199->ptr_items;
    zT_201 = d.payload_idx;
    zT_202 = (unsigned int)zT_201;
    zT_203 = zT_200[zT_202];
    dp4 = zT_203;
    zT_204 = d.flags;
    if ((unsigned char)((unsigned char)(zT_204 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_217 = d.kind;
    if ((unsigned char)(zT_217 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_67; else goto z_bb_68;
    z_bb_62:
    return (unsigned char)(0);
    z_bb_63:
    zT_210 = sp2.base;
    zT_211 = dp4.base;
    if ((unsigned char)(zT_210 == zT_211)) goto z_bb_65; else goto z_bb_64;
    z_bb_64:
    zT_214 = dp4.base;
    zT_213 = zT_214 == (unsigned int)(1);
    goto z_bb_66;
    z_bb_65:
    zT_213 = 1;
    goto z_bb_66;
    z_bb_66:
    return zT_213;
    z_bb_67:
    zT_222 = self->registry;
    zT_223 = zT_222->opt_items;
    zT_224 = d.payload_idx;
    zT_225 = (unsigned int)zT_224;
    zT_226 = zT_223[zT_225];
    opt2 = zT_226;
    zT_227 = self;
    zT_228 = src_type;
    zT_230 = opt2.payload;
    self = zT_227;
    src_type = zT_228;
    dst_type = zT_230;
    goto z_bb_0;
    z_bb_68:
    return (unsigned char)(0);
    z_bb_69:
    zT_238 = self->registry;
    zT_239 = zT_238->slice_items;
    zT_240 = s.payload_idx;
    zT_241 = (unsigned int)zT_240;
    zT_242 = zT_239[zT_241];
    ss = zT_242;
    zT_243 = d.kind;
    if ((unsigned char)(zT_243 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    return (unsigned char)(0);
    z_bb_71:
    zT_248 = self->registry;
    zT_249 = zT_248->slice_items;
    zT_250 = d.payload_idx;
    zT_251 = (unsigned int)zT_250;
    zT_252 = zT_249[zT_251];
    ds2 = zT_252;
    zT_253 = d.flags;
    if ((unsigned char)((unsigned char)(zT_253 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    zT_262 = d.kind;
    if ((unsigned char)(zT_262 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return (unsigned char)(0);
    z_bb_74:
    zT_259 = ss.elem;
    zT_260 = ds2.elem;
    return (unsigned char)(zT_259 == zT_260);
    z_bb_75:
    zT_267 = self->registry;
    zT_268 = zT_267->ptr_items;
    zT_269 = d.payload_idx;
    zT_270 = (unsigned int)zT_269;
    zT_271 = zT_268[zT_270];
    dp5 = zT_271;
    zT_272 = d.flags;
    if ((unsigned char)((unsigned char)(zT_272 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    return (unsigned char)(0);
    z_bb_77:
    return (unsigned char)(0);
    z_bb_78:
    zT_278 = ss.elem;
    zT_279 = dp5.base;
    return (unsigned char)(zT_278 == zT_279);
}

/* semanticAnalyzerMaybeDiagVolatileDrop */
unsigned char zF_86AAA417_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int span_node, unsigned int src_type, unsigned int dst_type) {
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_7 = 0;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_F85C5DED_DiagnosticCollector* zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_35 = 0;
    zT_22A7C88B_AstNode vdrop_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdrop_msg;
    zT_4 = self;
    zT_5 = src_type;
    zT_6 = dst_type;
    zT_7 = zF_57090266_semanticAnalyzerVol(zT_4, zT_5, zT_6);
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_11 = self->store;
    zT_12 = span_node;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    vdrop_node = zT_14;
    zT_16 = "cannot implicitly discard 'volatile' qualifier; use @volatileCast to remove it";
    zT_18 = 78;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    vdrop_msg = zT_17;
    zT_19 = self->diag;
    zT_22 = self->source_file_id;
    zT_23 = vdrop_node.span_start;
    zT_31 = vdrop_node.span_start;
    zT_32 = vdrop_node.span_len;
    zT_25 = vdrop_msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_19, (unsigned char)(0), (unsigned short)(3000), zT_22, zT_23, (unsigned int)(zT_31 + (unsigned int)((unsigned int)zT_32)), zT_25);
    (void)zT_35;
    return (unsigned char)(1);
}

/* semanticAnalyzerPtrCastDropsVolatile */
unsigned char zF_5F2042EA_semanticAnalyzerPtr(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    unsigned char zT_5;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    zT_33EF6BFB_TypeKind zT_37;
    unsigned char zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    unsigned char zT_59;
    unsigned char zT_65;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    if ((unsigned char)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    if ((unsigned char)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(src_type == dst_type)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_18 = self->registry;
    zT_19 = zT_18->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src_type) >= zT_19)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)dst_type) >= zT_24)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)src_type;
    zT_31 = zT_29[zT_30];
    s = zT_31;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)dst_type;
    zT_36 = zT_34[zT_35];
    d = zT_36;
    zT_37 = s.kind;
    if ((unsigned char)(zT_37 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_42 = s.kind;
    zT_41 = zT_42 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_19;
    z_bb_18:
    zT_41 = 1;
    goto z_bb_19;
    z_bb_19:
    if ((unsigned char)(!zT_41)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    zT_48 = d.kind;
    if ((unsigned char)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_53 = d.kind;
    zT_52 = zT_53 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_24;
    z_bb_23:
    zT_52 = 1;
    goto z_bb_24;
    z_bb_24:
    if ((unsigned char)(!zT_52)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    zT_59 = s.flags;
    if ((unsigned char)((unsigned char)(zT_59 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    zT_65 = d.flags;
    return (unsigned char)((unsigned char)(zT_65 & (unsigned char)(2)) == (unsigned char)(0));
}

/* semanticAnalyzerVolatileCastValid */
unsigned char zF_EC29CB82_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    unsigned char zT_5;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_D155D06D_Type* zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type zT_29;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    unsigned char zT_39;
    zT_33EF6BFB_TypeKind zT_40;
    zT_33EF6BFB_TypeKind zT_46;
    unsigned char zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_57;
    unsigned char zT_63;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_112BF819_PtrPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_112BF819_PtrPayload zT_74;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_112BF819_PtrPayload* zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_112BF819_PtrPayload zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload dp;
    if ((unsigned char)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    if ((unsigned char)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src_type) >= zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_21 = self->registry;
    zT_22 = zT_21->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)dst_type) >= zT_22)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_26 = self->registry;
    zT_27 = zT_26->types_items;
    zT_28 = (unsigned int)src_type;
    zT_29 = zT_27[zT_28];
    s = zT_29;
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)dst_type;
    zT_34 = zT_32[zT_33];
    d = zT_34;
    zT_35 = s.kind;
    if ((unsigned char)(zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_40 = s.kind;
    zT_39 = zT_40 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_17;
    z_bb_16:
    zT_39 = 1;
    goto z_bb_17;
    z_bb_17:
    if ((unsigned char)(!zT_39)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (unsigned char)(0);
    z_bb_19:
    zT_46 = d.kind;
    if ((unsigned char)(zT_46 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_51 = d.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_22;
    z_bb_21:
    zT_50 = 1;
    goto z_bb_22;
    z_bb_22:
    if ((unsigned char)(!zT_50)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    zT_57 = s.flags;
    if ((unsigned char)((unsigned char)(zT_57 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    zT_63 = d.flags;
    if ((unsigned char)((unsigned char)(zT_63 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    zT_70 = self->registry;
    zT_71 = zT_70->ptr_items;
    zT_72 = s.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    sp = zT_74;
    zT_76 = self->registry;
    zT_77 = zT_76->ptr_items;
    zT_78 = d.payload_idx;
    zT_79 = (unsigned int)zT_78;
    zT_80 = zT_77[zT_79];
    dp = zT_80;
    zT_81 = sp.base;
    zT_82 = dp.base;
    return (unsigned char)(zT_81 == zT_82);
}

/* tryRecordCoercion */
void zF_DF7434EB_tryRecordCoercion(zT_38C12417_SemanticAnalyzer* self, unsigned int src_node, unsigned int src_type, unsigned int dst_type) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_338B7C76_TypeRegistry* zT_23;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_33EF6BFB_TypeKind zT_38;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_33EF6BFB_TypeKind zT_46;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_52 = {0};
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_8143F551_AstKind zT_59;
    unsigned char zT_63;
    zT_38C12417_SemanticAnalyzer* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_69 = 0;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74 = 0;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_0FB7FB13_CoercionKind zT_88 = 0;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned char zT_99;
    unsigned char zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    unsigned int zT_104;
    unsigned char zT_106 = 0;
    zT_66E7D2EF_CoercionTable* zT_107;
    unsigned int zT_108;
    zT_0FB7FB13_CoercionKind zT_109;
    unsigned int zT_110;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dm;
    zT_D155D06D_Type src_t;
    zT_D155D06D_Type dst_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_skm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dkm;
    zT_22A7C88B_AstNode snode;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs1_m;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u cka_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_km;
    zT_5 = "COE:N";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    coe_nm = zT_6;
    zT_8 = coe_nm;
    zT_9 = src_node;
    zF_C914CB83_markerWriteInt(zT_8, zT_9);
    zT_11 = "COE:S";
    zT_13 = 5;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    coe_sm = zT_12;
    zT_14 = coe_sm;
    zT_15 = src_type;
    zF_C914CB83_markerWriteInt(zT_14, zT_15);
    zT_17 = "COE:D";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    coe_dm = zT_18;
    zT_20 = coe_dm;
    zT_21 = dst_type;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = self->registry;
    zT_24 = zT_23->types_items;
    zT_25 = (unsigned int)src_type;
    zT_26 = zT_24[zT_25];
    src_t = zT_26;
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)dst_type;
    zT_31 = zT_29[zT_30];
    dst_t = zT_31;
    zT_33 = "COE:SK";
    zT_35 = 6;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    coe_skm = zT_34;
    zT_36 = coe_skm;
    zT_38 = src_t.kind;
    zF_C914CB83_markerWriteInt(zT_36, (unsigned int)((unsigned int)zT_38));
    zT_41 = "COE:DK";
    zT_43 = 6;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    coe_dkm = zT_42;
    zT_44 = coe_dkm;
    zT_46 = dst_t.kind;
    zF_C914CB83_markerWriteInt(zT_44, (unsigned int)((unsigned int)zT_46));
    zT_49 = self->store;
    zT_50 = src_node;
    zT_52 = zF_FCDD1D35_astStoreNodeAt(zT_49, zT_50);
    snode = zT_52;
    zT_54 = "COE:NK";
    zT_56 = 6;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    coe_nkm = zT_55;
    zT_57 = coe_nkm;
    zT_59 = snode.kind;
    zF_C914CB83_markerWriteInt(zT_57, (unsigned int)((unsigned int)zT_59));
    if ((unsigned char)(src_type == (unsigned int)(18))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_63 = src_type == dst_type;
    goto z_bb_3;
    z_bb_2:
    zT_63 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_63) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_65 = self;
    zT_66 = src_node;
    zT_67 = src_type;
    zT_68 = dst_type;
    zT_69 = zF_86AAA417_semanticAnalyzerMay(zT_65, zT_66, zT_67, zT_68);
    if (zT_69) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    zT_70 = self->registry;
    zT_71 = src_type;
    zT_72 = dst_type;
    zT_74 = zF_683AEB7F_typeRegistryIsAssig(zT_70, zT_71, zT_72);
    if ((unsigned char)(!zT_74)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    if ((unsigned char)(src_type == (unsigned int)(17))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_79 = "CS1\n";
    zT_81 = 4;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    cs1_m = zT_80;
    zT_82 = cs1_m;
    zF_48AC7B3A_markerWrite(zT_82);
    goto z_bb_11;
    z_bb_11:
    zT_84 = self->registry;
    zT_85 = src_type;
    zT_86 = dst_type;
    zT_88 = zF_713658BF_classifyCoercion(zT_84, zT_85, zT_86);
    ck = zT_88;
    zT_90 = "CCK:ca";
    zT_92 = 6;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    cka_m = zT_91;
    zT_93 = cka_m;
    zF_C914CB83_markerWriteInt(zT_93, (unsigned int)((unsigned int)ck));
    if ((unsigned char)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(src_type == (unsigned int)(17))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_99 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_99) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_103 = self->registry;
    zT_104 = dst_type;
    zT_106 = zF_AD61DB1B_typeRegistryIsPoint(zT_103, zT_104);
    zT_102 = zT_106;
    goto z_bb_17;
    z_bb_16:
    zT_102 = 0;
    goto z_bb_17;
    z_bb_17:
    zT_99 = zT_102;
    goto z_bb_14;
    z_bb_18:
    zT_107 = self->coercion_table;
    zT_108 = src_node;
    zT_109 = ck;
    zT_110 = dst_type;
    zF_D21AE60A_coercionTableAdd(zT_107, zT_108, zT_109, zT_110);
    zT_113 = "COR:N";
    zT_115 = 5;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    cor_nm = zT_114;
    zT_116 = cor_nm;
    zT_117 = src_node;
    zF_C914CB83_markerWriteInt(zT_116, zT_117);
    zT_119 = "COR:K";
    zT_121 = 5;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    cor_km = zT_120;
    zT_122 = cor_km;
    zF_C914CB83_markerWriteInt(zT_122, (unsigned int)((unsigned int)ck));
    goto z_bb_19;
    z_bb_19:
    return;
}

/* isStringLiteralSliceCoercion */
unsigned char zF_71304A07_isStringLiteralSlic(zT_0FB7FB13_CoercionKind k) {
    unsigned char zT_4;
    if ((unsigned char)(k == (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_string_to_slice))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = k == (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_4;
}

/* errLitSrcType */
unsigned int zF_FFC95E09_errLitSrcType(zT_38C12417_SemanticAnalyzer* self, unsigned int child_0, unsigned int target_ty, unsigned int ret_val) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_D155D06D_Type* zT_15;
    unsigned int zT_16;
    zT_D155D06D_Type zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_42C2D6BF_EUPayload* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_42C2D6BF_EUPayload zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode rn;
    zT_D155D06D_Type frt;
    zT_5 = self->store;
    zT_6 = child_0;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    rn = zT_8;
    zT_9 = rn.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self->registry;
    zT_15 = zT_14->types_items;
    zT_16 = (unsigned int)target_ty;
    zT_17 = zT_15[zT_16];
    frt = zT_17;
    zT_18 = frt.kind;
    if ((unsigned char)(zT_18 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return ret_val;
    z_bb_3:
    zT_22 = self->registry;
    zT_23 = zT_22->eu_items;
    zT_24 = frt.payload_idx;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23[zT_25];
    zT_27 = zT_26.error_set;
    return zT_27;
    z_bb_4:
    goto z_bb_2;
}

/* resolveReturnStmt */
void zF_F231D87F_resolveReturnStmt(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    unsigned char zT_13 = 0;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_F85C5DED_DiagnosticCollector* zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_35 = 0;
    unsigned int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    zT_38C12417_SemanticAnalyzer* zT_47;
    unsigned int zT_48;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_38C12417_SemanticAnalyzer* zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_82 = 0;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_88 = 0;
    unsigned char zT_90;
    zT_38C12417_SemanticAnalyzer* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_97 = 0;
    unsigned int zT_99;
    unsigned int zT_101;
    unsigned int zT_103;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_F85C5DED_DiagnosticCollector* zT_109;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_120 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_33EF6BFB_TypeKind zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_D155D06D_Type* zT_127;
    unsigned int zT_128;
    zT_D155D06D_Type zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_33EF6BFB_TypeKind zT_136;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_D155D06D_Type* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_D155D06D_Type zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143 = {0};
    zT_38C12417_SemanticAnalyzer* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_22A7C88B_AstNode node;
    unsigned int brsp;
    unsigned int brep;
    zT_8F083A69_Slice_zT_0B42B2F8_u br_msg;
    unsigned int ret_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_fm;
    unsigned int ret_eff;
    unsigned int rsp;
    unsigned int rep;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtm_msg;
    unsigned int rdi;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((unsigned char)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_11 = self->current_fn_return;
    zT_13 = zF_15CE7BE8_fnReturnRequiresVal(zT_10, zT_11);
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_36 = node.child_0;
    if ((unsigned char)(zT_36 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = node.span_start;
    brsp = zT_15;
    zT_17 = node.span_len;
    zT_19 = brsp + (unsigned int)((unsigned int)zT_17);
    brep = zT_19;
    zT_21 = "return with no value in function returning non-void";
    zT_23 = 51;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    br_msg = zT_22;
    zT_24 = self->diag;
    zT_27 = self->source_file_id;
    zT_28 = brsp;
    zT_29 = brep;
    zT_30 = br_msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_24, (unsigned char)(0), (unsigned short)(3003), zT_27, zT_28, zT_29, zT_30);
    (void)zT_35;
    goto z_bb_4;
    z_bb_4:
    return;
    z_bb_5:
    zT_39 = self;
    zT_40 = self->current_fn_return;
    zF_9665A229_pushExpectedType(zT_39, zT_40);
    zT_43 = self;
    zT_44 = node.child_0;
    zT_46 = zF_54F95822_semanticAnalyzerRes(zT_43, zT_44);
    ret_val = zT_46;
    zT_47 = self;
    zF_BC478E78_popExpectedType(zT_47);
    zT_48 = self->current_fn_return;
    if ((unsigned char)(zT_48 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_52 = self->current_fn_return;
    zT_51 = zT_52 != (unsigned int)(1);
    goto z_bb_9;
    z_bb_8:
    zT_51 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_51) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_56 = "T2F:C";
    zT_58 = 5;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    t2f_nm = zT_57;
    zT_59 = t2f_nm;
    zT_60 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_59, zT_60);
    zT_63 = "T2F:R";
    zT_65 = 5;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    t2f_rm = zT_64;
    zT_66 = t2f_rm;
    zT_67 = ret_val;
    zF_C914CB83_markerWriteInt(zT_66, zT_67);
    zT_69 = "T2F:F";
    zT_71 = 5;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    t2f_fm = zT_70;
    zT_72 = t2f_fm;
    zT_73 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_72, zT_73);
    zT_76 = self;
    zT_77 = node.child_0;
    zT_78 = self->current_fn_return;
    zT_79 = ret_val;
    zT_82 = zF_FFC95E09_errLitSrcType(zT_76, zT_77, zT_78, zT_79);
    ret_eff = zT_82;
    zT_83 = self->registry;
    zT_84 = ret_eff;
    zT_85 = self->current_fn_return;
    zT_88 = zF_683AEB7F_typeRegistryIsAssig(zT_83, zT_84, zT_85);
    if ((unsigned char)(!zT_88)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    goto z_bb_6;
    z_bb_12:
    zT_91 = self;
    zT_92 = ret_eff;
    zT_93 = self->current_fn_return;
    zT_97 = zF_D728034A_isBShapeMismatch(zT_91, zT_92, zT_93, (unsigned char)(0));
    zT_90 = zT_97;
    goto z_bb_14;
    z_bb_13:
    zT_90 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_90) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_99 = node.span_start;
    rsp = zT_99;
    zT_101 = node.span_len;
    zT_103 = rsp + (unsigned int)((unsigned int)zT_101);
    rep = zT_103;
    zT_105 = "type mismatch in return statement — value type may not be compatible with the function return type";
    zT_107 = 100;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    rtm_msg = zT_106;
    zT_109 = self->diag;
    zT_112 = self->source_file_id;
    zT_113 = rsp;
    zT_114 = rep;
    zT_115 = rtm_msg;
    zT_120 = zF_C82559AC_diagnosticCollector(zT_109, (unsigned char)(0), (unsigned short)(3000), zT_112, zT_113, zT_114, zT_115);
    rdi = zT_120;
    zT_121 = self->diag;
    zT_122 = rdi;
    zT_126 = self->registry;
    zT_127 = zT_126->types_items;
    zT_128 = (unsigned int)ret_eff;
    zT_129 = zT_127[zT_128];
    zT_125 = zT_129.kind;
    zT_131 = zF_C14453DE_typeKindSrcStr(zT_125);
    zT_123 = zT_131;
    zF_426E1F18_diagnosticCollector(zT_121, zT_122, zT_123);
    (void)self;
    zT_132 = self->diag;
    zT_133 = rdi;
    zT_137 = self->registry;
    zT_138 = zT_137->types_items;
    zT_139 = self->current_fn_return;
    zT_140 = (unsigned int)zT_139;
    zT_141 = zT_138[zT_140];
    zT_136 = zT_141.kind;
    zT_143 = zF_CC479241_typeKindTgtStr(zT_136);
    zT_134 = zT_143;
    zF_426E1F18_diagnosticCollector(zT_132, zT_133, zT_134);
    (void)self;
    goto z_bb_16;
    z_bb_16:
    zT_144 = self;
    zT_145 = node.child_0;
    zT_146 = ret_eff;
    zT_147 = self->current_fn_return;
    zF_DF7434EB_tryRecordCoercion(zT_144, zT_145, zT_146, zT_147);
    goto z_bb_11;
}

/* semanticAnalyzerResolveFnCall */
unsigned int zF_87E78775_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    unsigned int zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_8143F551_AstKind zT_23;
    zT_3D7259E2_SymbolRegistry* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_37 = 0;
    zT_567DA1C3_Opt_868 zT_38 = {0};
    unsigned char zT_39;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_3C598AEF_SymbolKind zT_56;
    unsigned char zT_60;
    unsigned int zT_61;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_70;
    zT_6B0A7D14_AstStore* zT_75;
    zT_9C1673CC_anon_238694 zT_76;
    zT_243D6A41_FnProto* zT_77;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_82 = 0;
    unsigned int zT_83;
    zT_243D6A41_FnProto zT_84;
    unsigned int zT_85;
    zT_8EED1867_ResolvedTypeTable* zT_89;
    unsigned int zT_90;
    zT_BAEE192E_Opt_10 zT_93 = {0};
    unsigned char zT_95;
    unsigned int zT_96;
    unsigned char* zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char zT_105;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_ABC1EBBE_TypeResolveEnv zT_114;
    zT_6B0A7D14_AstStore* zT_115;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_3D7259E2_SymbolRegistry* zT_117;
    zT_D3EB6303_StringInterner* zT_118;
    unsigned int zT_119;
    zT_F85C5DED_DiagnosticCollector* zT_120;
    zT_7034F045_Opt_228 zT_121;
    zT_03B97CED_Opt_398 zT_122 = {0};
    zT_05CE5599_Opt_400 zT_123 = {0};
    unsigned int zT_124;
    zT_ABC1EBBE_TypeResolveEnv* zT_126;
    unsigned int zT_127;
    unsigned int zT_132 = 0;
    unsigned char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    unsigned char* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_6B0A7D14_AstStore* zT_166;
    unsigned int zT_167;
    unsigned int zT_169 = 0;
    unsigned int zT_170;
    unsigned char zT_172;
    unsigned short zT_174;
    unsigned int zT_176;
    int zT_177;
    zT_8EED1867_ResolvedTypeTable* zT_180;
    unsigned int zT_181;
    zT_BAEE192E_Opt_10 zT_183 = {0};
    unsigned char zT_184;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    zT_338B7C76_TypeRegistry* zT_192;
    zT_D155D06D_Type* zT_193;
    unsigned int zT_194;
    zT_D155D06D_Type zT_195;
    zT_33EF6BFB_TypeKind zT_196;
    zT_338B7C76_TypeRegistry* zT_201;
    zT_0317B1D5_FnPayload* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_0317B1D5_FnPayload zT_205;
    unsigned short zT_206;
    unsigned int zT_207;
    unsigned char zT_208;
    int zT_210;
    unsigned int zT_211;
    unsigned int zT_214;
    unsigned char zT_217;
    unsigned int zT_225;
    unsigned int zT_226;
    zT_21D3708C_U32ToU32Map* zT_227;
    unsigned int zT_228;
    zT_BAEE192E_Opt_10 zT_230 = {0};
    unsigned char zT_231;
    zT_338B7C76_TypeRegistry* zT_233;
    unsigned int* zT_234;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_21D3708C_U32ToU32Map* zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    zT_6B0A7D14_AstStore* zT_242;
    unsigned int zT_243;
    unsigned int zT_247 = 0;
    zT_38C12417_SemanticAnalyzer* zT_248;
    unsigned int zT_249;
    zT_38C12417_SemanticAnalyzer* zT_251;
    unsigned int zT_252;
    zT_6B0A7D14_AstStore* zT_253;
    unsigned int zT_254;
    unsigned int zT_258 = 0;
    unsigned int zT_259 = 0;
    zT_38C12417_SemanticAnalyzer* zT_260;
    unsigned char zT_263;
    zT_38C12417_SemanticAnalyzer* zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    zT_6B0A7D14_AstStore* zT_271;
    unsigned int zT_272;
    unsigned int zT_276 = 0;
    unsigned int zT_277 = 0;
    zT_338B7C76_TypeRegistry* zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    unsigned char zT_282 = 0;
    unsigned char zT_284;
    zT_38C12417_SemanticAnalyzer* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned char zT_290 = 0;
    zT_6B0A7D14_AstStore* zT_292;
    unsigned int zT_293;
    zT_6B0A7D14_AstStore* zT_295;
    unsigned int zT_296;
    unsigned int zT_300 = 0;
    zT_22A7C88B_AstNode zT_301 = {0};
    unsigned int zT_303;
    unsigned int zT_305;
    unsigned int zT_307;
    unsigned char* zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    unsigned int zT_311;
    zT_F85C5DED_DiagnosticCollector* zT_313;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned int zT_324 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_325;
    unsigned int zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_33EF6BFB_TypeKind zT_329;
    zT_338B7C76_TypeRegistry* zT_330;
    zT_D155D06D_Type* zT_331;
    unsigned int zT_332;
    zT_D155D06D_Type zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_336;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    zT_33EF6BFB_TypeKind zT_340;
    zT_338B7C76_TypeRegistry* zT_341;
    zT_D155D06D_Type* zT_342;
    unsigned int zT_343;
    zT_D155D06D_Type zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346 = {0};
    zT_38C12417_SemanticAnalyzer* zT_347;
    unsigned int zT_348;
    unsigned int zT_349;
    unsigned int zT_350;
    zT_6B0A7D14_AstStore* zT_351;
    unsigned int zT_352;
    unsigned int zT_356 = 0;
    int zT_357;
    unsigned int zT_359;
    zT_8EED1867_ResolvedTypeTable* zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    zT_38C12417_SemanticAnalyzer* zT_365;
    unsigned int zT_366;
    unsigned int zT_368 = 0;
    unsigned char* zT_372;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_373;
    unsigned int zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    zT_338B7C76_TypeRegistry* zT_378;
    zT_D155D06D_Type* zT_379;
    unsigned int zT_380;
    zT_D155D06D_Type zT_381;
    zT_33EF6BFB_TypeKind zT_382;
    zT_338B7C76_TypeRegistry* zT_387;
    zT_112BF819_PtrPayload* zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    zT_112BF819_PtrPayload zT_391;
    zT_338B7C76_TypeRegistry* zT_393;
    zT_D155D06D_Type* zT_394;
    unsigned int zT_395;
    unsigned int zT_396;
    zT_D155D06D_Type zT_397;
    zT_33EF6BFB_TypeKind zT_398;
    unsigned int zT_402;
    zT_338B7C76_TypeRegistry* zT_403;
    zT_D155D06D_Type* zT_404;
    unsigned int zT_405;
    zT_D155D06D_Type zT_406;
    zT_33EF6BFB_TypeKind zT_407;
    unsigned char* zT_412;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_413;
    unsigned int zT_414;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_415;
    unsigned int zT_416;
    unsigned char* zT_418;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_419;
    unsigned int zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421;
    unsigned int zT_422;
    unsigned char* zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned int zT_426;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_427;
    zT_33EF6BFB_TypeKind zT_429;
    zT_6B0A7D14_AstStore* zT_432;
    unsigned int zT_433;
    unsigned int zT_435 = 0;
    unsigned int zT_437;
    zT_38C12417_SemanticAnalyzer* zT_440;
    zT_38C12417_SemanticAnalyzer* zT_443;
    unsigned int zT_444;
    zT_6B0A7D14_AstStore* zT_445;
    unsigned int zT_446;
    unsigned int zT_450 = 0;
    unsigned int zT_451 = 0;
    zT_38C12417_SemanticAnalyzer* zT_452;
    unsigned int zT_454;
    unsigned char* zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_458;
    unsigned int zT_459;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_460;
    zT_338B7C76_TypeRegistry* zT_462;
    zT_0317B1D5_FnPayload* zT_463;
    unsigned int zT_464;
    unsigned int zT_465;
    zT_0317B1D5_FnPayload zT_466;
    unsigned char* zT_468;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_469;
    unsigned int zT_470;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_471;
    unsigned short zT_473;
    unsigned int zT_474;
    unsigned int zT_476;
    unsigned int zT_477;
    unsigned char* zT_479;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_480;
    unsigned int zT_481;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_482;
    zT_6B0A7D14_AstStore* zT_484;
    unsigned int zT_485;
    unsigned int zT_487 = 0;
    unsigned int zT_488;
    unsigned char* zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    unsigned int zT_492;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_493;
    unsigned char zT_495;
    unsigned char zT_496;
    unsigned char zT_501;
    unsigned int zT_506;
    unsigned int zT_508;
    int zT_510;
    unsigned int zT_511;
    unsigned char* zT_513;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_514;
    unsigned int zT_515;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_516;
    unsigned char* zT_518;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_519;
    unsigned int zT_520;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_521;
    zT_338B7C76_TypeRegistry* zT_523;
    unsigned int zT_524;
    unsigned char* zT_527;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_528;
    unsigned int zT_529;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_530;
    unsigned char* zT_535;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_536;
    unsigned int zT_537;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_538;
    zT_338B7C76_TypeRegistry* zT_540;
    unsigned int* zT_541;
    unsigned int zT_542;
    unsigned int zT_543;
    zT_21D3708C_U32ToU32Map* zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    zT_6B0A7D14_AstStore* zT_548;
    unsigned int zT_549;
    unsigned int zT_553 = 0;
    unsigned char* zT_555;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_556;
    unsigned int zT_557;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_558;
    unsigned char* zT_562;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_563;
    unsigned int zT_564;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_565;
    unsigned int zT_566;
    unsigned char* zT_568;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_569;
    unsigned int zT_570;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_571;
    unsigned int zT_572;
    zT_6B0A7D14_AstStore* zT_573;
    unsigned int zT_574;
    unsigned int zT_578 = 0;
    unsigned char* zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned int zT_582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_583;
    zT_38C12417_SemanticAnalyzer* zT_584;
    unsigned int zT_585;
    zT_38C12417_SemanticAnalyzer* zT_587;
    unsigned int zT_588;
    zT_6B0A7D14_AstStore* zT_589;
    unsigned int zT_590;
    unsigned int zT_594 = 0;
    unsigned int zT_595 = 0;
    zT_38C12417_SemanticAnalyzer* zT_596;
    zT_21D3708C_U32ToU32Map* zT_601;
    unsigned int zT_602;
    unsigned int zT_603;
    zT_6B0A7D14_AstStore* zT_605;
    unsigned int zT_606;
    unsigned int zT_610 = 0;
    zT_21D3708C_U32ToU32Map* zT_615;
    unsigned int zT_616;
    unsigned int zT_617;
    zT_6B0A7D14_AstStore* zT_619;
    unsigned int zT_620;
    unsigned int zT_624 = 0;
    zT_38C12417_SemanticAnalyzer* zT_626;
    unsigned int zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    zT_6B0A7D14_AstStore* zT_630;
    unsigned int zT_631;
    unsigned int zT_635 = 0;
    unsigned int zT_636 = 0;
    zT_338B7C76_TypeRegistry* zT_637;
    unsigned int zT_638;
    unsigned int zT_639;
    unsigned char zT_641 = 0;
    unsigned char zT_643;
    zT_38C12417_SemanticAnalyzer* zT_644;
    unsigned int zT_645;
    unsigned int zT_646;
    unsigned char zT_649 = 0;
    zT_6B0A7D14_AstStore* zT_651;
    unsigned int zT_652;
    zT_6B0A7D14_AstStore* zT_654;
    unsigned int zT_655;
    unsigned int zT_659 = 0;
    zT_22A7C88B_AstNode zT_660 = {0};
    unsigned int zT_662;
    unsigned int zT_664;
    unsigned int zT_666;
    unsigned char* zT_668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_669;
    unsigned int zT_670;
    zT_F85C5DED_DiagnosticCollector* zT_672;
    unsigned int zT_675;
    unsigned int zT_676;
    unsigned int zT_677;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_678;
    unsigned int zT_683 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_684;
    unsigned int zT_685;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_686;
    zT_33EF6BFB_TypeKind zT_688;
    zT_338B7C76_TypeRegistry* zT_689;
    zT_D155D06D_Type* zT_690;
    unsigned int zT_691;
    zT_D155D06D_Type zT_692;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_694 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_695;
    unsigned int zT_696;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_697;
    zT_33EF6BFB_TypeKind zT_699;
    zT_338B7C76_TypeRegistry* zT_700;
    zT_D155D06D_Type* zT_701;
    unsigned int zT_702;
    zT_D155D06D_Type zT_703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705 = {0};
    zT_38C12417_SemanticAnalyzer* zT_706;
    unsigned int zT_707;
    unsigned int zT_708;
    unsigned int zT_709;
    zT_6B0A7D14_AstStore* zT_710;
    unsigned int zT_711;
    unsigned int zT_715 = 0;
    int zT_716;
    unsigned int zT_718;
    zT_38C12417_SemanticAnalyzer* zT_723;
    zT_38C12417_SemanticAnalyzer* zT_727;
    unsigned int zT_728;
    zT_6B0A7D14_AstStore* zT_729;
    unsigned int zT_730;
    unsigned int zT_734 = 0;
    unsigned int zT_735 = 0;
    zT_38C12417_SemanticAnalyzer* zT_736;
    zT_21D3708C_U32ToU32Map* zT_739;
    unsigned int zT_740;
    unsigned int zT_741;
    zT_6B0A7D14_AstStore* zT_743;
    unsigned int zT_744;
    unsigned int zT_748 = 0;
    int zT_749;
    unsigned int zT_751;
    unsigned char* zT_753;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_754;
    unsigned int zT_755;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_756;
    unsigned int zT_757;
    unsigned int zT_759;
    zT_8F083A69_Slice_zT_0B42B2F8_u fne;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee_node;
    unsigned int direct_ret;
    unsigned int decl_cap;
    zT_567DA1C3_Opt_868 sym;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u xf;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_22A7C88B_AstNode dn;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 rt;
    unsigned int rnt_val;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u brnt_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfnr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u drfb_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_fc;
    unsigned int fc_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1r_m;
    unsigned int args_n;
    unsigned char has_params;
    unsigned short pcount;
    unsigned int pstart;
    unsigned int callee_type;
    zT_BAEE192E_Opt_10 ft;
    unsigned int ai;
    unsigned int ftid;
    zT_8F083A69_Slice_zT_0B42B2F8_u sfm;
    zT_D155D06D_Type ft_ty;
    zT_0317B1D5_FnPayload ftp;
    unsigned int expected;
    unsigned int cpp_key;
    unsigned int dxc_at;
    unsigned int cpp_v;
    unsigned int carg_eff;
    zT_22A7C88B_AstNode argn;
    unsigned int csp;
    unsigned int cep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ctm_msg;
    unsigned int cdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn2;
    zT_D155D06D_Type callee_ty;
    zT_112BF819_PtrPayload cptr_pp;
    zT_D155D06D_Type cptr_pointee;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ck_m;
    unsigned int fn3_args_n;
    unsigned int fn3_i;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4a;
    zT_0317B1D5_FnPayload fnp;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4b;
    unsigned int pcount_1;
    unsigned int pstart_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4c;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4d;
    unsigned char is_var;
    unsigned int fixed;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4e;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4y_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4f;
    unsigned int param_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_am;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4g;
    unsigned int arg_type;
    unsigned int vi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4_rm;
    unsigned int varg_type;
    zT_3 = "FNE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fne = zT_4;
    zT_6 = fne;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    callee_node = zT_17;
    zT_19 = 0;
    direct_ret = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    decl_cap = zT_22;
    zT_23 = callee_node.kind;
    if ((unsigned char)(zT_23 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_28 = self->symbols;
    zT_29 = self->module_id;
    zT_33 = self->store;
    zT_34 = node.child_0;
    zT_37 = zF_53458827_astStoreIdentifier(zT_33, zT_34);
    zT_30 = zT_37;
    zT_38 = zF_A398987E_symbolRegistryQuali(zT_28, zT_29, zT_30);
    sym = zT_38;
    zT_39 = sym.has_value;
    if (zT_39) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    if ((unsigned char)(direct_ret != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    s = sym.value;
    zT_42 = "XF\n";
    zT_44 = 3;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    xf = zT_43;
    zT_45 = xf;
    zF_48AC7B3A_markerWrite(zT_45);
    zT_46 = s->decl_node;
    decl_cap = zT_46;
    zT_47 = s->type_id;
    if ((unsigned char)(zT_47 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_148 = "xS\n";
    zT_150 = 3;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    xs = zT_149;
    zT_151 = xs;
    zF_48AC7B3A_markerWrite(zT_151);
    goto z_bb_4;
    z_bb_6:
    zT_50 = self->type_table;
    zT_51 = node.child_0;
    zT_52 = s->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_50, zT_51, zT_52);
    goto z_bb_7;
    z_bb_7:
    zT_56 = s->kind;
    if ((unsigned char)(zT_56 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_61 = s->decl_node;
    zT_60 = zT_61 != (unsigned int)(0);
    goto z_bb_10;
    z_bb_9:
    zT_60 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_65 = self->store;
    zT_66 = s->decl_node;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    dn = zT_69;
    zT_70 = dn.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_4;
    z_bb_13:
    zT_75 = self->store;
    zT_76 = zT_75->fn_protos;
    zT_77 = zT_76.items;
    zT_78 = self->store;
    zT_79 = s->decl_node;
    zT_82 = zF_8BA26B9E_astStoreNodePayload(zT_78, zT_79);
    zT_83 = (unsigned int)zT_82;
    zT_84 = zT_77[zT_83];
    proto = zT_84;
    zT_85 = proto.return_type_node;
    if ((unsigned char)(zT_85 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_89 = self->type_table;
    zT_90 = proto.return_type_node;
    zT_93 = zF_999DCF51_resolvedTypeTableGe(zT_89, zT_90);
    rt = zT_93;
    zT_95 = rt.has_value;
    if (zT_95) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    t = rt.value;
    zT_96 = t;
    goto z_bb_19;
    z_bb_18:
    zT_96 = 0;
    goto z_bb_19;
    z_bb_19:
    rnt_val = zT_96;
    zT_100 = "BR:rnt";
    zT_102 = 6;
    zT_101.ptr = zT_100;
    zT_101.len = zT_102;
    brnt_m = zT_101;
    zT_103 = brnt_m;
    zT_104 = rnt_val;
    zF_C914CB83_markerWriteInt(zT_103, zT_104);
    zT_105 = rt.has_value;
    if (zT_105) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    t = rt.value;
    direct_ret = t;
    goto z_bb_21;
    z_bb_21:
    zT_142 = "BR:fnr";
    zT_144 = 6;
    zT_143.ptr = zT_142;
    zT_143.len = zT_144;
    brfnr_m = zT_143;
    zT_145 = brfnr_m;
    zT_146 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_145, zT_146);
    goto z_bb_16;
    z_bb_22:
    zT_108 = "DRETFB:n";
    zT_110 = 8;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    drfb_m = zT_109;
    zT_111 = drfb_m;
    zT_112 = node_idx;
    zF_C914CB83_markerWriteInt(zT_111, zT_112);
    zT_115 = self->store;
    zT_114.store = zT_115;
    zT_116 = self->registry;
    zT_114.typereg = zT_116;
    zT_117 = self->symbols;
    zT_114.symbol_reg = zT_117;
    zT_118 = self->interner;
    zT_114.interner = zT_118;
    zT_119 = s->module_id;
    zT_114.module_id = zT_119;
    zT_120 = self->diag;
    zT_121.has_value = 1;
    zT_121.value = zT_120;
    zT_114.diag = zT_121;
    zT_122.has_value = 0;
    zT_114.local_consts = zT_122;
    zT_123.has_value = 0;
    zT_114.local_types = zT_123;
    zT_124 = self->source_file_id;
    zT_114.source_file_id = zT_124;
    tre_env_fc = zT_114;
    zT_126 = &tre_env_fc;
    zT_127 = proto.return_type_node;
    zT_132 = zF_F2107C15_resolveTypeExprFull(zT_126, zT_127, (unsigned int)(0));
    fc_rt = zT_132;
    zT_134 = "BR:fc";
    zT_136 = 5;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    brfc_m = zT_135;
    zT_137 = brfc_m;
    zT_138 = fc_rt;
    zF_C914CB83_markerWriteInt(zT_137, zT_138);
    if ((unsigned char)(fc_rt != (unsigned int)(18))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    direct_ret = fc_rt;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_155 = "FN1\n";
    zT_157 = 4;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    fn1 = zT_156;
    zT_158 = fn1;
    zF_48AC7B3A_markerWrite(zT_158);
    zT_160 = "FN1:R";
    zT_162 = 5;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    fn1r_m = zT_161;
    zT_163 = fn1r_m;
    zT_164 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_163, zT_164);
    zT_166 = self->store;
    zT_167 = node_idx;
    zT_169 = zF_152E19CB_astStoreNodeExtraCh(zT_166, zT_167);
    zT_170 = (unsigned int)zT_169;
    args_n = zT_170;
    zT_172 = 0;
    has_params = zT_172;
    zT_174 = 0;
    pcount = zT_174;
    zT_176 = 0;
    pstart = zT_176;
    zT_177 = 0;
    if ((unsigned char)(decl_cap != (unsigned int)zT_177)) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_365 = self;
    zT_366 = node.child_0;
    zT_368 = zF_54F95822_semanticAnalyzerRes(zT_365, zT_366);
    callee_type = zT_368;
    if ((unsigned char)(callee_type == (unsigned int)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_27:
    zT_180 = self->type_table;
    zT_181 = decl_cap;
    zT_183 = zF_999DCF51_resolvedTypeTableGe(zT_180, zT_181);
    ft = zT_183;
    zT_184 = ft.has_value;
    if (zT_184) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_210 = 0;
    zT_211 = (unsigned int)zT_210;
    ai = zT_211;
    goto z_bb_33;
    z_bb_29:
    ftid = ft.value;
    zT_187 = "SF:H\n";
    zT_189 = 5;
    zT_188.ptr = zT_187;
    zT_188.len = zT_189;
    sfm = zT_188;
    zT_190 = sfm;
    zF_48AC7B3A_markerWrite(zT_190);
    zT_192 = self->registry;
    zT_193 = zT_192->types_items;
    zT_194 = (unsigned int)ftid;
    zT_195 = zT_193[zT_194];
    ft_ty = zT_195;
    zT_196 = ft_ty.kind;
    if ((unsigned char)(zT_196 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_201 = self->registry;
    zT_202 = zT_201->fn_items;
    zT_203 = ft_ty.payload_idx;
    zT_204 = (unsigned int)zT_203;
    zT_205 = zT_202[zT_204];
    ftp = zT_205;
    zT_206 = ftp.params_count;
    pcount = zT_206;
    zT_207 = ftp.params_start;
    pstart = zT_207;
    zT_208 = 1;
    has_params = zT_208;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    if ((unsigned char)(ai < args_n)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_214 = 0;
    expected = zT_214;
    if ((unsigned char)(has_params != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_360 = self->type_table;
    zT_361 = node_idx;
    zT_362 = direct_ret;
    zF_19B4A07D_resolvedTypeTableSe(zT_360, zT_361, zT_362);
    return direct_ret;
    z_bb_36:
    zT_357 = 1;
    zT_359 = ai + (unsigned int)((unsigned int)zT_357);
    ai = zT_359;
    goto z_bb_33;
    z_bb_37:
    zT_217 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_39;
    z_bb_38:
    zT_217 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_217) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_225 = (unsigned int)((unsigned int)((unsigned int)decl_cap) << (unsigned int)(16)) | (unsigned int)((unsigned int)ai);
    cpp_key = zT_225;
    zT_226 = 18;
    expected = zT_226;
    zT_227 = self->call_param_map;
    zT_228 = cpp_key;
    zT_230 = zF_F3EE5998_u32ToU32MapGet(zT_227, zT_228);
    zT_231 = zT_230.has_value;
    if (zT_231) goto z_bb_42; else goto z_bb_44;
    z_bb_41:
    zT_248 = self;
    zT_249 = expected;
    zF_9665A229_pushExpectedType(zT_248, zT_249);
    zT_251 = self;
    zT_253 = self->store;
    zT_254 = node_idx;
    zT_258 = zF_B10B1BC1_astStoreNodeExtraCh(zT_253, zT_254, (unsigned int)((unsigned int)ai));
    zT_252 = zT_258;
    zT_259 = zF_54F95822_semanticAnalyzerRes(zT_251, zT_252);
    dxc_at = zT_259;
    zT_260 = self;
    zF_BC478E78_popExpectedType(zT_260);
    if ((unsigned char)(has_params != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_42:
    cpp_v = zT_230.value;
    expected = cpp_v;
    goto z_bb_43;
    z_bb_43:
    zT_238 = self->call_arg_types;
    zT_242 = self->store;
    zT_243 = node_idx;
    zT_247 = zF_B10B1BC1_astStoreNodeExtraCh(zT_242, zT_243, (unsigned int)((unsigned int)ai));
    zT_239 = zT_247;
    zT_240 = expected;
    zF_26476265_u32ToU32MapPut(zT_238, zT_239, zT_240);
    goto z_bb_41;
    z_bb_44:
    zT_233 = self->registry;
    zT_234 = zT_233->xt_items;
    zT_236 = (unsigned int)((unsigned int)pstart) + ai;
    zT_237 = zT_234[zT_236];
    expected = zT_237;
    goto z_bb_43;
    z_bb_45:
    zT_263 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_47;
    z_bb_46:
    zT_263 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_263) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_267 = self;
    zT_271 = self->store;
    zT_272 = node_idx;
    zT_276 = zF_B10B1BC1_astStoreNodeExtraCh(zT_271, zT_272, (unsigned int)((unsigned int)ai));
    zT_268 = zT_276;
    zT_269 = expected;
    zT_270 = dxc_at;
    zT_277 = zF_FFC95E09_errLitSrcType(zT_267, zT_268, zT_269, zT_270);
    carg_eff = zT_277;
    zT_278 = self->registry;
    zT_279 = carg_eff;
    zT_280 = expected;
    zT_282 = zF_683AEB7F_typeRegistryIsAssig(zT_278, zT_279, zT_280);
    if ((unsigned char)(!zT_282)) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_36;
    z_bb_50:
    zT_285 = self;
    zT_286 = carg_eff;
    zT_287 = expected;
    zT_290 = zF_D728034A_isBShapeMismatch(zT_285, zT_286, zT_287, (unsigned char)(0));
    zT_284 = zT_290;
    goto z_bb_52;
    z_bb_51:
    zT_284 = 0;
    goto z_bb_52;
    z_bb_52:
    if (zT_284) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_292 = self->store;
    zT_295 = self->store;
    zT_296 = node_idx;
    zT_300 = zF_B10B1BC1_astStoreNodeExtraCh(zT_295, zT_296, (unsigned int)((unsigned int)ai));
    zT_293 = zT_300;
    zT_301 = zF_FCDD1D35_astStoreNodeAt(zT_292, zT_293);
    argn = zT_301;
    zT_303 = argn.span_start;
    csp = zT_303;
    zT_305 = argn.span_len;
    zT_307 = csp + (unsigned int)((unsigned int)zT_305);
    cep = zT_307;
    zT_309 = "type mismatch in function argument — argument type may not be compatible with the parameter type";
    zT_311 = 98;
    zT_310.ptr = zT_309;
    zT_310.len = zT_311;
    ctm_msg = zT_310;
    zT_313 = self->diag;
    zT_316 = self->source_file_id;
    zT_317 = csp;
    zT_318 = cep;
    zT_319 = ctm_msg;
    zT_324 = zF_C82559AC_diagnosticCollector(zT_313, (unsigned char)(0), (unsigned short)(3000), zT_316, zT_317, zT_318, zT_319);
    cdi = zT_324;
    zT_325 = self->diag;
    zT_326 = cdi;
    zT_330 = self->registry;
    zT_331 = zT_330->types_items;
    zT_332 = (unsigned int)carg_eff;
    zT_333 = zT_331[zT_332];
    zT_329 = zT_333.kind;
    zT_335 = zF_C14453DE_typeKindSrcStr(zT_329);
    zT_327 = zT_335;
    zF_426E1F18_diagnosticCollector(zT_325, zT_326, zT_327);
    (void)self;
    zT_336 = self->diag;
    zT_337 = cdi;
    zT_341 = self->registry;
    zT_342 = zT_341->types_items;
    zT_343 = (unsigned int)expected;
    zT_344 = zT_342[zT_343];
    zT_340 = zT_344.kind;
    zT_346 = zF_CC479241_typeKindTgtStr(zT_340);
    zT_338 = zT_346;
    zF_426E1F18_diagnosticCollector(zT_336, zT_337, zT_338);
    (void)self;
    goto z_bb_54;
    z_bb_54:
    zT_347 = self;
    zT_351 = self->store;
    zT_352 = node_idx;
    zT_356 = zF_B10B1BC1_astStoreNodeExtraCh(zT_351, zT_352, (unsigned int)((unsigned int)ai));
    zT_348 = zT_356;
    zT_349 = carg_eff;
    zT_350 = expected;
    zF_DF7434EB_tryRecordCoercion(zT_347, zT_348, zT_349, zT_350);
    goto z_bb_49;
    z_bb_55:
    zT_372 = "FN2\n";
    zT_374 = 4;
    zT_373.ptr = zT_372;
    zT_373.len = zT_374;
    fn2 = zT_373;
    zT_375 = fn2;
    zF_48AC7B3A_markerWrite(zT_375);
    return (unsigned int)(1);
    z_bb_56:
    zT_378 = self->registry;
    zT_379 = zT_378->types_items;
    zT_380 = (unsigned int)callee_type;
    zT_381 = zT_379[zT_380];
    callee_ty = zT_381;
    zT_382 = callee_ty.kind;
    if ((unsigned char)(zT_382 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_387 = self->registry;
    zT_388 = zT_387->ptr_items;
    zT_389 = callee_ty.payload_idx;
    zT_390 = (unsigned int)zT_389;
    zT_391 = zT_388[zT_390];
    cptr_pp = zT_391;
    zT_393 = self->registry;
    zT_394 = zT_393->types_items;
    zT_395 = cptr_pp.base;
    zT_396 = (unsigned int)zT_395;
    zT_397 = zT_394[zT_396];
    cptr_pointee = zT_397;
    zT_398 = cptr_pointee.kind;
    if ((unsigned char)(zT_398 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    zT_407 = callee_ty.kind;
    if ((unsigned char)(zT_407 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    zT_402 = cptr_pp.base;
    callee_type = zT_402;
    zT_403 = self->registry;
    zT_404 = zT_403->types_items;
    zT_405 = (unsigned int)callee_type;
    zT_406 = zT_404[zT_405];
    callee_ty = zT_406;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    zT_412 = "FN3:N";
    zT_414 = 5;
    zT_413.ptr = zT_412;
    zT_413.len = zT_414;
    fn3 = zT_413;
    zT_415 = fn3;
    zT_416 = node_idx;
    zF_C914CB83_markerWriteInt(zT_415, zT_416);
    zT_418 = "FN3:T";
    zT_420 = 5;
    zT_419.ptr = zT_418;
    zT_419.len = zT_420;
    fn3_ct_m = zT_419;
    zT_421 = fn3_ct_m;
    zT_422 = callee_type;
    zF_C914CB83_markerWriteInt(zT_421, zT_422);
    zT_424 = "FN3:K";
    zT_426 = 5;
    zT_425.ptr = zT_424;
    zT_425.len = zT_426;
    fn3_ck_m = zT_425;
    zT_427 = fn3_ck_m;
    zT_429 = callee_ty.kind;
    zF_C914CB83_markerWriteInt(zT_427, (unsigned int)((unsigned int)zT_429));
    zT_432 = self->store;
    zT_433 = node_idx;
    zT_435 = zF_152E19CB_astStoreNodeExtraCh(zT_432, zT_433);
    fn3_args_n = zT_435;
    zT_437 = 0;
    fn3_i = zT_437;
    goto z_bb_63;
    z_bb_62:
    zT_457 = "FN4a\n";
    zT_459 = 5;
    zT_458.ptr = zT_457;
    zT_458.len = zT_459;
    fn4a = zT_458;
    zT_460 = fn4a;
    zF_48AC7B3A_markerWrite(zT_460);
    zT_462 = self->registry;
    zT_463 = zT_462->fn_items;
    zT_464 = callee_ty.payload_idx;
    zT_465 = (unsigned int)zT_464;
    zT_466 = zT_463[zT_465];
    fnp = zT_466;
    zT_468 = "FN4b\n";
    zT_470 = 5;
    zT_469.ptr = zT_468;
    zT_469.len = zT_470;
    fn4b = zT_469;
    zT_471 = fn4b;
    zF_48AC7B3A_markerWrite(zT_471);
    zT_473 = fnp.params_count;
    zT_474 = (unsigned int)zT_473;
    pcount_1 = zT_474;
    zT_476 = fnp.params_start;
    zT_477 = (unsigned int)zT_476;
    pstart_2 = zT_477;
    zT_479 = "FN4c\n";
    zT_481 = 5;
    zT_480.ptr = zT_479;
    zT_480.len = zT_481;
    fn4c = zT_480;
    zT_482 = fn4c;
    zF_48AC7B3A_markerWrite(zT_482);
    zT_484 = self->store;
    zT_485 = node_idx;
    zT_487 = zF_152E19CB_astStoreNodeExtraCh(zT_484, zT_485);
    zT_488 = (unsigned int)zT_487;
    args_n = zT_488;
    zT_490 = "FN4d\n";
    zT_492 = 5;
    zT_491.ptr = zT_490;
    zT_491.len = zT_492;
    fn4d = zT_491;
    zT_493 = fn4d;
    zF_48AC7B3A_markerWrite(zT_493);
    zT_495 = 0;
    is_var = zT_495;
    zT_496 = fnp.flags_packed;
    if ((unsigned char)((unsigned char)(zT_496 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_63:
    if ((unsigned char)(fn3_i < (unsigned int)((unsigned int)fn3_args_n))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_440 = self;
    zF_9665A229_pushExpectedType(zT_440, (unsigned int)(0));
    zT_443 = self;
    zT_445 = self->store;
    zT_446 = node_idx;
    zT_450 = zF_B10B1BC1_astStoreNodeExtraCh(zT_445, zT_446, (unsigned int)((unsigned int)fn3_i));
    zT_444 = zT_450;
    zT_451 = zF_54F95822_semanticAnalyzerRes(zT_443, zT_444);
    (void)zT_451;
    zT_452 = self;
    zF_BC478E78_popExpectedType(zT_452);
    goto z_bb_66;
    z_bb_65:
    return (unsigned int)(1);
    z_bb_66:
    zT_454 = fn3_i + (unsigned int)(1);
    fn3_i = zT_454;
    goto z_bb_63;
    z_bb_67:
    zT_501 = 1;
    is_var = zT_501;
    goto z_bb_68;
    z_bb_68:
    fixed = pcount_1;
    if ((unsigned char)(is_var != (unsigned char)(0))) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    if ((unsigned char)(args_n < fixed)) goto z_bb_72; else goto z_bb_73;
    z_bb_70:
    zT_510 = 0;
    zT_511 = (unsigned int)zT_510;
    ai = zT_511;
    zT_513 = "FN4e\n";
    zT_515 = 5;
    zT_514.ptr = zT_513;
    zT_514.len = zT_515;
    fn4e = zT_514;
    zT_516 = fn4e;
    zF_48AC7B3A_markerWrite(zT_516);
    zT_518 = "FN4x:X";
    zT_520 = 6;
    zT_519.ptr = zT_518;
    zT_519.len = zT_520;
    fn4x_m = zT_519;
    zT_521 = fn4x_m;
    zT_523 = self->registry;
    zT_524 = zT_523->xt_len;
    zF_C914CB83_markerWriteInt(zT_521, (unsigned int)((unsigned int)zT_524));
    zT_527 = "FN4y:P";
    zT_529 = 6;
    zT_528.ptr = zT_527;
    zT_528.len = zT_529;
    fn4y_m = zT_528;
    zT_530 = fn4y_m;
    zF_C914CB83_markerWriteInt(zT_530, (unsigned int)((unsigned int)pstart_2));
    goto z_bb_76;
    z_bb_71:
    if ((unsigned char)(args_n != pcount_1)) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_506 = fnp.return_type;
    return zT_506;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    zT_508 = fnp.return_type;
    return zT_508;
    z_bb_75:
    goto z_bb_70;
    z_bb_76:
    if ((unsigned char)(ai < fixed)) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_535 = "FN4f\n";
    zT_537 = 5;
    zT_536.ptr = zT_535;
    zT_536.len = zT_537;
    fn4f = zT_536;
    zT_538 = fn4f;
    zF_48AC7B3A_markerWrite(zT_538);
    zT_540 = self->registry;
    zT_541 = zT_540->xt_items;
    zT_542 = pstart_2 + ai;
    zT_543 = zT_541[zT_542];
    param_type = zT_543;
    zT_544 = self->call_arg_types;
    zT_548 = self->store;
    zT_549 = node_idx;
    zT_553 = zF_B10B1BC1_astStoreNodeExtraCh(zT_548, zT_549, (unsigned int)((unsigned int)ai));
    zT_545 = zT_553;
    zT_546 = param_type;
    zF_26476265_u32ToU32MapPut(zT_544, zT_545, zT_546);
    zT_555 = "PTM:A";
    zT_557 = 5;
    zT_556.ptr = zT_555;
    zT_556.len = zT_557;
    ptm_am = zT_556;
    zT_558 = ptm_am;
    zF_C914CB83_markerWriteInt(zT_558, (unsigned int)((unsigned int)ai));
    zT_562 = "PTM:T";
    zT_564 = 5;
    zT_563.ptr = zT_562;
    zT_563.len = zT_564;
    ptm_tm = zT_563;
    zT_565 = ptm_tm;
    zT_566 = param_type;
    zF_C914CB83_markerWriteInt(zT_565, zT_566);
    zT_568 = "PTM:N";
    zT_570 = 5;
    zT_569.ptr = zT_568;
    zT_569.len = zT_570;
    ptm_nm = zT_569;
    zT_571 = ptm_nm;
    zT_573 = self->store;
    zT_574 = node_idx;
    zT_578 = zF_B10B1BC1_astStoreNodeExtraCh(zT_573, zT_574, (unsigned int)((unsigned int)ai));
    zT_572 = zT_578;
    zF_C914CB83_markerWriteInt(zT_571, zT_572);
    zT_580 = "FN4g\n";
    zT_582 = 5;
    zT_581.ptr = zT_580;
    zT_581.len = zT_582;
    fn4g = zT_581;
    zT_583 = fn4g;
    zF_48AC7B3A_markerWrite(zT_583);
    zT_584 = self;
    zT_585 = param_type;
    zF_9665A229_pushExpectedType(zT_584, zT_585);
    zT_587 = self;
    zT_589 = self->store;
    zT_590 = node_idx;
    zT_594 = zF_B10B1BC1_astStoreNodeExtraCh(zT_589, zT_590, (unsigned int)((unsigned int)ai));
    zT_588 = zT_594;
    zT_595 = zF_54F95822_semanticAnalyzerRes(zT_587, zT_588);
    arg_type = zT_595;
    zT_596 = self;
    zF_BC478E78_popExpectedType(zT_596);
    if ((unsigned char)(param_type == (unsigned int)(18))) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    if ((unsigned char)(is_var != (unsigned char)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_79:
    zT_716 = 1;
    zT_718 = ai + (unsigned int)((unsigned int)zT_716);
    ai = zT_718;
    goto z_bb_76;
    z_bb_80:
    if ((unsigned char)(arg_type != (unsigned int)(18))) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    if ((unsigned char)(param_type == (unsigned int)(1))) goto z_bb_84; else goto z_bb_85;
    z_bb_82:
    zT_601 = self->call_arg_types;
    zT_605 = self->store;
    zT_606 = node_idx;
    zT_610 = zF_B10B1BC1_astStoreNodeExtraCh(zT_605, zT_606, (unsigned int)((unsigned int)ai));
    zT_602 = zT_610;
    zT_603 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_601, zT_602, zT_603);
    goto z_bb_83;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    if ((unsigned char)(arg_type != (unsigned int)(18))) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    zT_626 = self;
    zT_630 = self->store;
    zT_631 = node_idx;
    zT_635 = zF_B10B1BC1_astStoreNodeExtraCh(zT_630, zT_631, (unsigned int)((unsigned int)ai));
    zT_627 = zT_635;
    zT_628 = param_type;
    zT_629 = arg_type;
    zT_636 = zF_FFC95E09_errLitSrcType(zT_626, zT_627, zT_628, zT_629);
    carg_eff = zT_636;
    zT_637 = self->registry;
    zT_638 = carg_eff;
    zT_639 = param_type;
    zT_641 = zF_683AEB7F_typeRegistryIsAssig(zT_637, zT_638, zT_639);
    if ((unsigned char)(!zT_641)) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    zT_615 = self->call_arg_types;
    zT_619 = self->store;
    zT_620 = node_idx;
    zT_624 = zF_B10B1BC1_astStoreNodeExtraCh(zT_619, zT_620, (unsigned int)((unsigned int)ai));
    zT_616 = zT_624;
    zT_617 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_615, zT_616, zT_617);
    goto z_bb_87;
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_644 = self;
    zT_645 = carg_eff;
    zT_646 = param_type;
    zT_649 = zF_D728034A_isBShapeMismatch(zT_644, zT_645, zT_646, (unsigned char)(0));
    zT_643 = zT_649;
    goto z_bb_90;
    z_bb_89:
    zT_643 = 0;
    goto z_bb_90;
    z_bb_90:
    if (zT_643) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_651 = self->store;
    zT_654 = self->store;
    zT_655 = node_idx;
    zT_659 = zF_B10B1BC1_astStoreNodeExtraCh(zT_654, zT_655, (unsigned int)((unsigned int)ai));
    zT_652 = zT_659;
    zT_660 = zF_FCDD1D35_astStoreNodeAt(zT_651, zT_652);
    argn = zT_660;
    zT_662 = argn.span_start;
    csp = zT_662;
    zT_664 = argn.span_len;
    zT_666 = csp + (unsigned int)((unsigned int)zT_664);
    cep = zT_666;
    zT_668 = "type mismatch in function argument — argument type may not be compatible with the parameter type";
    zT_670 = 98;
    zT_669.ptr = zT_668;
    zT_669.len = zT_670;
    ctm_msg = zT_669;
    zT_672 = self->diag;
    zT_675 = self->source_file_id;
    zT_676 = csp;
    zT_677 = cep;
    zT_678 = ctm_msg;
    zT_683 = zF_C82559AC_diagnosticCollector(zT_672, (unsigned char)(0), (unsigned short)(3000), zT_675, zT_676, zT_677, zT_678);
    cdi = zT_683;
    zT_684 = self->diag;
    zT_685 = cdi;
    zT_689 = self->registry;
    zT_690 = zT_689->types_items;
    zT_691 = (unsigned int)carg_eff;
    zT_692 = zT_690[zT_691];
    zT_688 = zT_692.kind;
    zT_694 = zF_C14453DE_typeKindSrcStr(zT_688);
    zT_686 = zT_694;
    zF_426E1F18_diagnosticCollector(zT_684, zT_685, zT_686);
    (void)self;
    zT_695 = self->diag;
    zT_696 = cdi;
    zT_700 = self->registry;
    zT_701 = zT_700->types_items;
    zT_702 = (unsigned int)param_type;
    zT_703 = zT_701[zT_702];
    zT_699 = zT_703.kind;
    zT_705 = zF_CC479241_typeKindTgtStr(zT_699);
    zT_697 = zT_705;
    zF_426E1F18_diagnosticCollector(zT_695, zT_696, zT_697);
    (void)self;
    goto z_bb_92;
    z_bb_92:
    zT_706 = self;
    zT_710 = self->store;
    zT_711 = node_idx;
    zT_715 = zF_B10B1BC1_astStoreNodeExtraCh(zT_710, zT_711, (unsigned int)((unsigned int)ai));
    zT_707 = zT_715;
    zT_708 = carg_eff;
    zT_709 = param_type;
    zF_DF7434EB_tryRecordCoercion(zT_706, zT_707, zT_708, zT_709);
    goto z_bb_79;
    z_bb_93:
    vi = fixed;
    goto z_bb_95;
    z_bb_94:
    zT_753 = "FN4:R";
    zT_755 = 5;
    zT_754.ptr = zT_753;
    zT_754.len = zT_755;
    fn4_rm = zT_754;
    zT_756 = fn4_rm;
    zT_757 = fnp.return_type;
    zF_C914CB83_markerWriteInt(zT_756, zT_757);
    zT_759 = fnp.return_type;
    return zT_759;
    z_bb_95:
    if ((unsigned char)(vi < args_n)) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_723 = self;
    zF_9665A229_pushExpectedType(zT_723, (unsigned int)(0));
    zT_727 = self;
    zT_729 = self->store;
    zT_730 = node_idx;
    zT_734 = zF_B10B1BC1_astStoreNodeExtraCh(zT_729, zT_730, (unsigned int)((unsigned int)vi));
    zT_728 = zT_734;
    zT_735 = zF_54F95822_semanticAnalyzerRes(zT_727, zT_728);
    varg_type = zT_735;
    zT_736 = self;
    zF_BC478E78_popExpectedType(zT_736);
    if ((unsigned char)(varg_type != (unsigned int)(18))) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    goto z_bb_94;
    z_bb_98:
    zT_749 = 1;
    zT_751 = vi + (unsigned int)((unsigned int)zT_749);
    vi = zT_751;
    goto z_bb_95;
    z_bb_99:
    zT_739 = self->call_arg_types;
    zT_743 = self->store;
    zT_744 = node_idx;
    zT_748 = zF_B10B1BC1_astStoreNodeExtraCh(zT_743, zT_744, (unsigned int)((unsigned int)vi));
    zT_740 = zT_748;
    zT_741 = varg_type;
    zF_26476265_u32ToU32MapPut(zT_739, zT_740, zT_741);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_98;
}

/* semanticAnalyzerResolveTryExpr */
unsigned int zF_B78F27CD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    zT_338B7C76_TypeRegistry* zT_29;
    zT_42C2D6BF_EUPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_42C2D6BF_EUPayload zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    zT_42C2D6BF_EUPayload eu;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((unsigned char)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(1);
    z_bb_7:
    zT_29 = self->registry;
    zT_30 = zT_29->eu_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    eu = zT_33;
    zT_34 = eu.payload;
    return zT_34;
}

/* semanticAnalyzerResolveOrelseExpr */
unsigned int zF_B36961FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_D155D06D_Type* zT_42;
    unsigned int zT_43;
    zT_D155D06D_Type zT_44;
    zT_33EF6BFB_TypeKind zT_46;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_0B10E8E9_OptionalPayload* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_0B10E8E9_OptionalPayload zT_55;
    unsigned int zT_56;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    unsigned int zT_61 = 0;
    zT_66E7D2EF_CoercionTable* zT_62;
    unsigned int zT_63;
    unsigned int zT_65;
    zT_33EF6BFB_TypeKind zT_71;
    zT_33EF6BFB_TypeKind zT_75;
    unsigned char zT_79;
    zT_33EF6BFB_TypeKind zT_80;
    unsigned char zT_84;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_110 = 0;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_0B10E8E9_OptionalPayload* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_0B10E8E9_OptionalPayload zT_117;
    zT_66E7D2EF_CoercionTable* zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned int zT_127;
    zT_38C12417_SemanticAnalyzer* zT_130;
    unsigned int zT_131;
    zT_38C12417_SemanticAnalyzer* zT_134;
    unsigned int zT_135;
    unsigned int zT_137 = 0;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned char zT_141;
    zT_38C12417_SemanticAnalyzer* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_150;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    unsigned int expected;
    zT_D155D06D_Type oe_et;
    unsigned int payload_type;
    zT_0B10E8E9_OptionalPayload oe_opt;
    unsigned int opt_target;
    zT_0B10E8E9_OptionalPayload opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u oe_msg;
    unsigned int rhs_result;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((unsigned char)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_28 = self->expected_type_stack_len;
    zT_27 = zT_28 > (unsigned int)(0);
    goto z_bb_8;
    z_bb_7:
    zT_27 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = self->expected_type_stack_items;
    zT_33 = self->expected_type_stack_len;
    zT_36 = (unsigned int)(unsigned int)(zT_33 - (unsigned int)(1));
    zT_37 = zT_32[zT_36];
    expected = zT_37;
    if ((unsigned char)(expected != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_71 = ty.kind;
    if ((unsigned char)(zT_71 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_11:
    zT_41 = self->registry;
    zT_42 = zT_41->types_items;
    zT_43 = (unsigned int)expected;
    zT_44 = zT_42[zT_43];
    oe_et = zT_44;
    payload_type = expected;
    zT_46 = oe_et.kind;
    if ((unsigned char)(zT_46 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_51 = self->registry;
    zT_52 = zT_51->opt_items;
    zT_53 = oe_et.payload_idx;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zT_52[zT_54];
    oe_opt = zT_55;
    zT_56 = oe_opt.payload;
    payload_type = zT_56;
    goto z_bb_14;
    z_bb_14:
    zT_58 = self->registry;
    zT_59 = payload_type;
    zT_61 = zF_74A7234F_typeRegistryGetOrCr(zT_58, zT_59);
    opt_target = zT_61;
    zT_62 = self->coercion_table;
    zT_63 = node.child_0;
    zT_65 = opt_target;
    zF_D21AE60A_coercionTableAdd(zT_62, zT_63, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional_null), zT_65);
    return payload_type;
    z_bb_15:
    zT_75 = ty.kind;
    if ((unsigned char)(zT_75 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_18; else goto z_bb_17;
    z_bb_16:
    zT_113 = self->registry;
    zT_114 = zT_113->opt_items;
    zT_115 = ty.payload_idx;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zT_114[zT_116];
    opt = zT_117;
    zT_118 = self->coercion_table;
    zT_119 = node.child_0;
    zT_121 = opt.payload;
    zF_D21AE60A_coercionTableAdd(zT_118, zT_119, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_121);
    zT_127 = node.child_1;
    if ((unsigned char)(zT_127 != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_17:
    zT_80 = ty.kind;
    zT_79 = zT_80 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_19;
    z_bb_18:
    zT_79 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_79) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_84 = inner == (unsigned int)(3);
    goto z_bb_22;
    z_bb_21:
    zT_84 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_84) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned int)(1);
    z_bb_24:
    zT_89 = "orelse requires an optional operand; use 'catch' for error unions";
    zT_91 = 65;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    oe_msg = zT_90;
    zT_92 = self->diag;
    zT_95 = self->source_file_id;
    zT_96 = node.span_start;
    zT_106 = node.span_start;
    zT_107 = node.span_len;
    zT_98 = oe_msg;
    zT_110 = zF_C82559AC_diagnosticCollector(zT_92, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3016_ORELSE_REQUIRES_OPTIONAL)), zT_95, zT_96, (unsigned int)(zT_106 + (unsigned int)((unsigned int)zT_107)), zT_98);
    (void)zT_110;
    return (unsigned int)(18);
    z_bb_25:
    zT_130 = self;
    zT_131 = opt.payload;
    zF_9665A229_pushExpectedType(zT_130, zT_131);
    zT_134 = self;
    zT_135 = node.child_1;
    zT_137 = zF_54F95822_semanticAnalyzerRes(zT_134, zT_135);
    rhs_result = zT_137;
    zT_138 = self;
    zF_BC478E78_popExpectedType(zT_138);
    if ((unsigned char)(rhs_result != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_150 = opt.payload;
    return zT_150;
    z_bb_27:
    zT_141 = rhs_result != (unsigned int)(1);
    goto z_bb_29;
    z_bb_28:
    zT_141 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_141) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_144 = self;
    zT_145 = node.child_1;
    zT_146 = rhs_result;
    zT_147 = opt.payload;
    zF_DF7434EB_tryRecordCoercion(zT_144, zT_145, zT_146, zT_147);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_26;
}

/* semanticAnalyzerConditionIsComptimeTrue */
unsigned char zF_27B72BD2_semanticAnalyzerCon(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    zT_D3EB6303_StringInterner* zT_22;
    zT_3D7259E2_SymbolRegistry* zT_23;
    zT_DA663F79_ComptimeEval zT_28 = {0};
    zT_E2DF2801_LocalConstScope* zT_29;
    zT_03B97CED_Opt_398 zT_30;
    zT_DA663F79_ComptimeEval* zT_32;
    unsigned int zT_33;
    zT_E53A25A2_Opt_203 zT_35 = {0};
    unsigned char zT_36;
    unsigned int zT_38;
    zT_79FAE712_u64 zT_41;
    zT_22A7C88B_AstNode cond;
    zT_DA663F79_ComptimeEval ce;
    zT_E53A25A2_Opt_203 folded;
    zT_89B1DDDA_ComptimeVal cv;
    if ((unsigned char)(cond_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = cond_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    cond = zT_9;
    zT_10 = cond.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = cond.flags;
    return (unsigned char)((unsigned char)(zT_14 & (unsigned char)(1)) != (unsigned char)(0));
    z_bb_4:
    zT_20 = self->registry;
    zT_21 = self->store;
    zT_22 = self->interner;
    zT_23 = self->symbols;
    zT_28 = zF_6D84C2E7_comptimeEvalInit(zT_20, zT_21, zT_22, zT_23);
    ce = zT_28;
    zT_29 = &self->local_consts;
    zT_30.has_value = 1;
    zT_30.value = zT_29;
    ce.local_consts = zT_30;
    zT_32 = &ce;
    zT_33 = cond_idx;
    zT_35 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_32, zT_33);
    folded = zT_35;
    zT_36 = folded.has_value;
    if (zT_36) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    cv = folded.value;
    zT_38 = cv.width_bits;
    if ((unsigned char)(zT_38 == (unsigned int)(1))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_41 = cv.bits;
    return (unsigned char)(zT_41 != (zT_79FAE712_u64)(0));
    z_bb_8:
    goto z_bb_6;
}

/* semanticAnalyzerResolveIfExpr */
unsigned int zF_8B8EE70D_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    unsigned int zT_14;
    unsigned char zT_19;
    unsigned char zT_22;
    unsigned char zT_25;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned char zT_32 = 0;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    unsigned char zT_40;
    unsigned char zT_42;
    zT_8EED1867_ResolvedTypeTable* zT_44;
    unsigned int zT_45;
    zT_BAEE192E_Opt_10 zT_48 = {0};
    unsigned char zT_49;
    unsigned char zT_53;
    unsigned char zT_56;
    zT_338B7C76_TypeRegistry* zT_60;
    zT_D155D06D_Type* zT_61;
    unsigned int zT_62;
    zT_D155D06D_Type zT_63;
    zT_33EF6BFB_TypeKind zT_64;
    unsigned char zT_68;
    unsigned char zT_72;
    unsigned char zT_76;
    unsigned char zT_77;
    zT_F85C5DED_DiagnosticCollector* zT_78;
    unsigned int zT_79;
    unsigned char zT_81 = 0;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_F85C5DED_DiagnosticCollector* zT_86;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_104 = 0;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_8EED1867_ResolvedTypeTable* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_38C12417_SemanticAnalyzer* zT_127;
    unsigned int zT_128;
    unsigned int zT_130 = 0;
    zT_38C12417_SemanticAnalyzer* zT_132;
    unsigned int zT_133 = 0;
    unsigned char zT_136;
    unsigned char zT_142;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    zT_22A7C88B_AstNode zT_147 = {0};
    zT_8143F551_AstKind zT_148;
    unsigned char zT_155;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    zT_22A7C88B_AstNode zT_160 = {0};
    zT_8143F551_AstKind zT_161;
    unsigned char zT_165;
    zT_338B7C76_TypeRegistry* zT_166;
    unsigned int zT_172 = 0;
    unsigned char zT_175;
    unsigned char zT_181;
    zT_0FB7FB13_CoercionKind zT_182;
    zT_338B7C76_TypeRegistry* zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    zT_0FB7FB13_CoercionKind zT_187 = 0;
    unsigned char zT_188 = 0;
    unsigned char zT_192;
    zT_0FB7FB13_CoercionKind zT_193;
    zT_338B7C76_TypeRegistry* zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    zT_0FB7FB13_CoercionKind zT_198 = 0;
    unsigned char zT_199 = 0;
    unsigned char zT_202;
    unsigned char zT_205;
    unsigned char zT_206;
    zT_338B7C76_TypeRegistry* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned char zT_211 = 0;
    unsigned char zT_214;
    unsigned char zT_217;
    unsigned char zT_218;
    zT_338B7C76_TypeRegistry* zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned char zT_223 = 0;
    unsigned char zT_224;
    zT_38C12417_SemanticAnalyzer* zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_38C12417_SemanticAnalyzer* zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    zT_8EED1867_ResolvedTypeTable* zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned char* zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned int zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247;
    unsigned char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_253;
    unsigned char* zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    zT_8EED1867_ResolvedTypeTable* zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_270;
    unsigned char* zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned int zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    unsigned char* zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned int zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    zT_8EED1867_ResolvedTypeTable* zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned int zT_293;
    unsigned char* zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    unsigned int zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    unsigned int zT_299;
    unsigned char* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    zT_8EED1867_ResolvedTypeTable* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned char zT_311;
    zT_338B7C76_TypeRegistry* zT_312;
    unsigned int zT_313;
    unsigned char zT_315 = 0;
    unsigned char* zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_318;
    unsigned int zT_319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    unsigned int zT_321;
    unsigned char* zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    unsigned int zT_327;
    unsigned char* zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    unsigned int zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    zT_66E7D2EF_CoercionTable* zT_333;
    unsigned int zT_334;
    unsigned int zT_336;
    zT_8EED1867_ResolvedTypeTable* zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    unsigned char zT_347;
    zT_338B7C76_TypeRegistry* zT_348;
    unsigned int zT_349;
    unsigned char zT_351 = 0;
    unsigned char* zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    unsigned int zT_355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    unsigned int zT_357;
    unsigned char* zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    unsigned int zT_361;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_362;
    unsigned int zT_363;
    unsigned char* zT_365;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_366;
    unsigned int zT_367;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    zT_66E7D2EF_CoercionTable* zT_369;
    unsigned int zT_370;
    unsigned int zT_372;
    zT_8EED1867_ResolvedTypeTable* zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned int zT_388;
    unsigned char* zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    unsigned int zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_394;
    unsigned char* zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397;
    unsigned int zT_398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_399;
    zT_8EED1867_ResolvedTypeTable* zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    unsigned char* zT_407;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_408;
    unsigned int zT_409;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_410;
    unsigned int zT_411;
    unsigned char* zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_414;
    unsigned int zT_415;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    unsigned int zT_417;
    unsigned char* zT_419;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_420;
    unsigned int zT_421;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_422;
    zT_8EED1867_ResolvedTypeTable* zT_423;
    unsigned int zT_424;
    unsigned int zT_425;
    unsigned char* zT_428;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_429;
    unsigned int zT_430;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_431;
    unsigned int zT_432;
    unsigned char* zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned int zT_436;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437;
    zT_8EED1867_ResolvedTypeTable* zT_438;
    unsigned int zT_439;
    zT_22A7C88B_AstNode node;
    unsigned int then_type;
    unsigned int else_type;
    unsigned int ie_exp;
    unsigned char iw_ok;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_nl;
    unsigned char iw_has_capture;
    unsigned char iw_cond_valid;
    zT_BAEE192E_Opt_10 iw_ct;
    unsigned int ct;
    zT_33EF6BFB_TypeKind iw_kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u iw_msg;
    unsigned char ie_then_lit;
    unsigned char ie_else_lit;
    unsigned char ie_then_str;
    unsigned char ie_else_str;
    unsigned char ie_then_ok;
    unsigned char ie_else_ok;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u siffm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sifftm;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_7, zT_8);
    zT_10 = self;
    zT_11 = node.child_1;
    zT_13 = zF_54F95822_semanticAnalyzerRes(zT_10, zT_11);
    then_type = zT_13;
    zT_14 = node.child_2;
    if ((unsigned char)(zT_14 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(then_type != (unsigned int)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_127 = self;
    zT_128 = node.child_2;
    zT_130 = zF_54F95822_semanticAnalyzerRes(zT_127, zT_128);
    else_type = zT_130;
    zT_132 = self;
    zT_133 = zF_4DE7C2BC_topExpectedType(zT_132);
    ie_exp = zT_133;
    if ((unsigned char)(ie_exp == (unsigned int)(0))) goto z_bb_42; else goto z_bb_41;
    z_bb_3:
    zT_19 = then_type != (unsigned int)(3);
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = then_type != (unsigned int)(0);
    goto z_bb_8;
    z_bb_7:
    zT_22 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_22) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25 = then_type != (unsigned int)(18);
    goto z_bb_11;
    z_bb_10:
    zT_25 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_25) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_29 = self;
    zT_30 = node.child_0;
    zT_32 = zF_27B72BD2_semanticAnalyzerCon(zT_29, zT_30);
    iw_ok = zT_32;
    if ((unsigned char)(!iw_ok)) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_106 = "SIF:0N";
    zT_108 = 6;
    zT_107.ptr = zT_106;
    zT_107.len = zT_108;
    sif_m = zT_107;
    zT_109 = sif_m;
    zT_110 = node_idx;
    zF_C914CB83_markerWriteInt(zT_109, zT_110);
    zT_112 = "T";
    zT_114 = 1;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    sif_tm = zT_113;
    zT_115 = sif_tm;
    zT_116 = then_type;
    zF_C914CB83_markerWriteInt(zT_115, zT_116);
    zT_118 = " ";
    zT_120 = 1;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    sif_nl = zT_119;
    zT_121 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_121);
    zT_122 = self->type_table;
    zT_123 = node_idx;
    zT_124 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_122, zT_123, zT_124);
    return then_type;
    z_bb_14:
    zT_35 = self->store;
    zT_36 = node_idx;
    zT_38 = zF_8BA26B9E_astStoreNodePayload(zT_35, zT_36);
    zT_40 = zT_38 != (unsigned int)(0);
    iw_has_capture = zT_40;
    zT_42 = 0;
    iw_cond_valid = zT_42;
    zT_44 = self->type_table;
    zT_45 = node.child_0;
    zT_48 = zF_999DCF51_resolvedTypeTableGe(zT_44, zT_45);
    iw_ct = zT_48;
    zT_49 = iw_ct.has_value;
    if (zT_49) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    ct = iw_ct.value;
    if ((unsigned char)(ct != (unsigned int)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    if (iw_cond_valid) goto z_bb_36; else goto z_bb_37;
    z_bb_18:
    zT_53 = ct != (unsigned int)(1);
    goto z_bb_20;
    z_bb_19:
    zT_53 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_53) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_56 = ct != (unsigned int)(18);
    goto z_bb_23;
    z_bb_22:
    zT_56 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_56) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_60 = self->registry;
    zT_61 = zT_60->types_items;
    zT_62 = (unsigned int)ct;
    zT_63 = zT_61[zT_62];
    zT_64 = zT_63.kind;
    iw_kind = zT_64;
    if (iw_has_capture) goto z_bb_26; else goto z_bb_28;
    z_bb_25:
    goto z_bb_17;
    z_bb_26:
    if ((unsigned char)(iw_kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_30; else goto z_bb_29;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    if ((unsigned char)(iw_kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_34; else goto z_bb_35;
    z_bb_29:
    zT_68 = iw_kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_31;
    z_bb_30:
    zT_68 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_68) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_72 = 1;
    iw_cond_valid = zT_72;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_27;
    z_bb_34:
    zT_76 = 1;
    iw_cond_valid = zT_76;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_27;
    z_bb_36:
    zT_78 = self->diag;
    zT_79 = node_idx;
    zT_81 = zF_4DD9DB2D_diagnosticCollector(zT_78, zT_79);
    zT_77 = zT_81;
    goto z_bb_38;
    z_bb_37:
    zT_77 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_77) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_83 = "if expression without 'else' cannot be used as a value (its type is 'void')";
    zT_85 = 75;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    iw_msg = zT_84;
    zT_86 = self->diag;
    zT_89 = self->source_file_id;
    zT_90 = node.span_start;
    zT_100 = node.span_start;
    zT_101 = node.span_len;
    zT_92 = iw_msg;
    zT_104 = zF_C82559AC_diagnosticCollector(zT_86, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3059_IF_WITHOUT_ELSE)), zT_89, zT_90, (unsigned int)(zT_100 + (unsigned int)((unsigned int)zT_101)), zT_92);
    (void)zT_104;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_15;
    z_bb_41:
    zT_136 = ie_exp == (unsigned int)(1);
    goto z_bb_43;
    z_bb_42:
    zT_136 = 1;
    goto z_bb_43;
    z_bb_43:
    if (zT_136) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    if ((unsigned char)(then_type != (unsigned int)(3))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    if ((unsigned char)(ie_exp != (unsigned int)(0))) goto z_bb_57; else goto z_bb_58;
    z_bb_46:
    zT_143 = self->store;
    zT_144 = node.child_1;
    zT_147 = zF_FCDD1D35_astStoreNodeAt(zT_143, zT_144);
    zT_148 = zT_147.kind;
    zT_142 = zT_148 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_48;
    z_bb_47:
    zT_142 = 0;
    goto z_bb_48;
    z_bb_48:
    ie_then_lit = zT_142;
    if ((unsigned char)(else_type != (unsigned int)(3))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_156 = self->store;
    zT_157 = node.child_2;
    zT_160 = zF_FCDD1D35_astStoreNodeAt(zT_156, zT_157);
    zT_161 = zT_160.kind;
    zT_155 = zT_161 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_51;
    z_bb_50:
    zT_155 = 0;
    goto z_bb_51;
    z_bb_51:
    ie_else_lit = zT_155;
    if (ie_then_lit) goto z_bb_53; else goto z_bb_52;
    z_bb_52:
    zT_165 = ie_else_lit;
    goto z_bb_54;
    z_bb_53:
    zT_165 = 1;
    goto z_bb_54;
    z_bb_54:
    if (zT_165) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_166 = self->registry;
    zT_172 = zF_8FC81A87_typeRegistryGetOrCr(zT_166, (unsigned int)(8), (unsigned char)(1));
    ie_exp = zT_172;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_45;
    z_bb_57:
    zT_175 = ie_exp != (unsigned int)(1);
    goto z_bb_59;
    z_bb_58:
    zT_175 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_175) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    if ((unsigned char)(then_type != (unsigned int)(3))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    if ((unsigned char)(then_type == else_type)) goto z_bb_95; else goto z_bb_96;
    z_bb_62:
    zT_183 = self->registry;
    zT_184 = then_type;
    zT_185 = ie_exp;
    zT_187 = zF_713658BF_classifyCoercion(zT_183, zT_184, zT_185);
    zT_182 = zT_187;
    zT_188 = zF_71304A07_isStringLiteralSlic(zT_182);
    zT_181 = zT_188;
    goto z_bb_64;
    z_bb_63:
    zT_181 = 0;
    goto z_bb_64;
    z_bb_64:
    ie_then_str = zT_181;
    if ((unsigned char)(else_type != (unsigned int)(3))) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_194 = self->registry;
    zT_195 = else_type;
    zT_196 = ie_exp;
    zT_198 = zF_713658BF_classifyCoercion(zT_194, zT_195, zT_196);
    zT_193 = zT_198;
    zT_199 = zF_71304A07_isStringLiteralSlic(zT_193);
    zT_192 = zT_199;
    goto z_bb_67;
    z_bb_66:
    zT_192 = 0;
    goto z_bb_67;
    z_bb_67:
    ie_else_str = zT_192;
    if ((unsigned char)(then_type == ie_exp)) goto z_bb_69; else goto z_bb_68;
    z_bb_68:
    zT_202 = then_type == (unsigned int)(3);
    goto z_bb_70;
    z_bb_69:
    zT_202 = 1;
    goto z_bb_70;
    z_bb_70:
    if (zT_202) goto z_bb_72; else goto z_bb_71;
    z_bb_71:
    zT_205 = ie_then_str;
    goto z_bb_73;
    z_bb_72:
    zT_205 = 1;
    goto z_bb_73;
    z_bb_73:
    if (zT_205) goto z_bb_75; else goto z_bb_74;
    z_bb_74:
    zT_207 = self->registry;
    zT_208 = then_type;
    zT_209 = ie_exp;
    zT_211 = zF_683AEB7F_typeRegistryIsAssig(zT_207, zT_208, zT_209);
    zT_206 = zT_211;
    goto z_bb_76;
    z_bb_75:
    zT_206 = 1;
    goto z_bb_76;
    z_bb_76:
    ie_then_ok = zT_206;
    if ((unsigned char)(else_type == ie_exp)) goto z_bb_78; else goto z_bb_77;
    z_bb_77:
    zT_214 = else_type == (unsigned int)(3);
    goto z_bb_79;
    z_bb_78:
    zT_214 = 1;
    goto z_bb_79;
    z_bb_79:
    if (zT_214) goto z_bb_81; else goto z_bb_80;
    z_bb_80:
    zT_217 = ie_else_str;
    goto z_bb_82;
    z_bb_81:
    zT_217 = 1;
    goto z_bb_82;
    z_bb_82:
    if (zT_217) goto z_bb_84; else goto z_bb_83;
    z_bb_83:
    zT_219 = self->registry;
    zT_220 = else_type;
    zT_221 = ie_exp;
    zT_223 = zF_683AEB7F_typeRegistryIsAssig(zT_219, zT_220, zT_221);
    zT_218 = zT_223;
    goto z_bb_85;
    z_bb_84:
    zT_218 = 1;
    goto z_bb_85;
    z_bb_85:
    ie_else_ok = zT_218;
    if (ie_then_ok) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_224 = ie_else_ok;
    goto z_bb_88;
    z_bb_87:
    zT_224 = 0;
    goto z_bb_88;
    z_bb_88:
    if (zT_224) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    if ((unsigned char)(then_type != ie_exp)) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    goto z_bb_61;
    z_bb_91:
    zT_226 = self;
    zT_227 = node.child_1;
    zT_228 = then_type;
    zT_229 = ie_exp;
    zF_DF7434EB_tryRecordCoercion(zT_226, zT_227, zT_228, zT_229);
    goto z_bb_92;
    z_bb_92:
    if ((unsigned char)(else_type != ie_exp)) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_232 = self;
    zT_233 = node.child_2;
    zT_234 = else_type;
    zT_235 = ie_exp;
    zF_DF7434EB_tryRecordCoercion(zT_232, zT_233, zT_234, zT_235);
    goto z_bb_94;
    z_bb_94:
    zT_237 = self->type_table;
    zT_238 = node_idx;
    zT_239 = ie_exp;
    zF_19B4A07D_resolvedTypeTableSe(zT_237, zT_238, zT_239);
    return ie_exp;
    z_bb_95:
    zT_243 = "SIF:1N";
    zT_245 = 6;
    zT_244.ptr = zT_243;
    zT_244.len = zT_245;
    sif_m = zT_244;
    zT_246 = sif_m;
    zT_247 = node_idx;
    zF_C914CB83_markerWriteInt(zT_246, zT_247);
    zT_249 = "T";
    zT_251 = 1;
    zT_250.ptr = zT_249;
    zT_250.len = zT_251;
    sif_tm = zT_250;
    zT_252 = sif_tm;
    zT_253 = then_type;
    zF_C914CB83_markerWriteInt(zT_252, zT_253);
    zT_255 = " ";
    zT_257 = 1;
    zT_256.ptr = zT_255;
    zT_256.len = zT_257;
    sif_nl = zT_256;
    zT_258 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_258);
    zT_259 = self->type_table;
    zT_260 = node_idx;
    zT_261 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_259, zT_260, zT_261);
    return then_type;
    z_bb_96:
    if ((unsigned char)(then_type == (unsigned int)(3))) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_266 = "SIF:2N";
    zT_268 = 6;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    sif2m = zT_267;
    zT_269 = sif2m;
    zT_270 = node_idx;
    zF_C914CB83_markerWriteInt(zT_269, zT_270);
    zT_272 = "T";
    zT_274 = 1;
    zT_273.ptr = zT_272;
    zT_273.len = zT_274;
    sif2tm = zT_273;
    zT_275 = sif2tm;
    zT_276 = else_type;
    zF_C914CB83_markerWriteInt(zT_275, zT_276);
    zT_278 = " ";
    zT_280 = 1;
    zT_279.ptr = zT_278;
    zT_279.len = zT_280;
    sif2nl = zT_279;
    zT_281 = sif2nl;
    zF_48AC7B3A_markerWrite(zT_281);
    zT_282 = self->type_table;
    zT_283 = node_idx;
    zT_284 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_282, zT_283, zT_284);
    return else_type;
    z_bb_98:
    if ((unsigned char)(else_type == (unsigned int)(3))) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_289 = "SIF:3N";
    zT_291 = 6;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    sif3m = zT_290;
    zT_292 = sif3m;
    zT_293 = node_idx;
    zF_C914CB83_markerWriteInt(zT_292, zT_293);
    zT_295 = "T";
    zT_297 = 1;
    zT_296.ptr = zT_295;
    zT_296.len = zT_297;
    sif3tm = zT_296;
    zT_298 = sif3tm;
    zT_299 = then_type;
    zF_C914CB83_markerWriteInt(zT_298, zT_299);
    zT_301 = " ";
    zT_303 = 1;
    zT_302.ptr = zT_301;
    zT_302.len = zT_303;
    sif3nl = zT_302;
    zT_304 = sif3nl;
    zF_48AC7B3A_markerWrite(zT_304);
    zT_305 = self->type_table;
    zT_306 = node_idx;
    zT_307 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_305, zT_306, zT_307);
    return then_type;
    z_bb_100:
    if ((unsigned char)(then_type == (unsigned int)(19))) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_312 = self->registry;
    zT_313 = else_type;
    zT_315 = zF_3087E0A5_typeRegistryIsNumer(zT_312, zT_313);
    zT_311 = zT_315;
    goto z_bb_103;
    z_bb_102:
    zT_311 = 0;
    goto z_bb_103;
    z_bb_103:
    if (zT_311) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    zT_317 = "SIF:4N";
    zT_319 = 6;
    zT_318.ptr = zT_317;
    zT_318.len = zT_319;
    sif4m = zT_318;
    zT_320 = sif4m;
    zT_321 = node_idx;
    zF_C914CB83_markerWriteInt(zT_320, zT_321);
    zT_323 = "T";
    zT_325 = 1;
    zT_324.ptr = zT_323;
    zT_324.len = zT_325;
    sif4tm = zT_324;
    zT_326 = sif4tm;
    zT_327 = else_type;
    zF_C914CB83_markerWriteInt(zT_326, zT_327);
    zT_329 = " ";
    zT_331 = 1;
    zT_330.ptr = zT_329;
    zT_330.len = zT_331;
    sif4nl = zT_330;
    zT_332 = sif4nl;
    zF_48AC7B3A_markerWrite(zT_332);
    zT_333 = self->coercion_table;
    zT_334 = node.child_1;
    zT_336 = else_type;
    zF_D21AE60A_coercionTableAdd(zT_333, zT_334, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_336);
    zT_341 = self->type_table;
    zT_342 = node_idx;
    zT_343 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_341, zT_342, zT_343);
    return else_type;
    z_bb_105:
    if ((unsigned char)(else_type == (unsigned int)(19))) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    zT_348 = self->registry;
    zT_349 = then_type;
    zT_351 = zF_3087E0A5_typeRegistryIsNumer(zT_348, zT_349);
    zT_347 = zT_351;
    goto z_bb_108;
    z_bb_107:
    zT_347 = 0;
    goto z_bb_108;
    z_bb_108:
    if (zT_347) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_353 = "SIF:5N";
    zT_355 = 6;
    zT_354.ptr = zT_353;
    zT_354.len = zT_355;
    sif5m = zT_354;
    zT_356 = sif5m;
    zT_357 = node_idx;
    zF_C914CB83_markerWriteInt(zT_356, zT_357);
    zT_359 = "T";
    zT_361 = 1;
    zT_360.ptr = zT_359;
    zT_360.len = zT_361;
    sif5tm = zT_360;
    zT_362 = sif5tm;
    zT_363 = then_type;
    zF_C914CB83_markerWriteInt(zT_362, zT_363);
    zT_365 = " ";
    zT_367 = 1;
    zT_366.ptr = zT_365;
    zT_366.len = zT_367;
    sif5nl = zT_366;
    zT_368 = sif5nl;
    zF_48AC7B3A_markerWrite(zT_368);
    zT_369 = self->coercion_table;
    zT_370 = node.child_2;
    zT_372 = then_type;
    zF_D21AE60A_coercionTableAdd(zT_369, zT_370, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_372);
    zT_377 = self->type_table;
    zT_378 = node_idx;
    zT_379 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_377, zT_378, zT_379);
    return then_type;
    z_bb_110:
    if ((unsigned char)(then_type == (unsigned int)(1))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_384 = "SIF:6N";
    zT_386 = 6;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    sif6m = zT_385;
    zT_387 = sif6m;
    zT_388 = node_idx;
    zF_C914CB83_markerWriteInt(zT_387, zT_388);
    zT_390 = "T";
    zT_392 = 1;
    zT_391.ptr = zT_390;
    zT_391.len = zT_392;
    sif6tm = zT_391;
    zT_393 = sif6tm;
    zT_394 = else_type;
    zF_C914CB83_markerWriteInt(zT_393, zT_394);
    zT_396 = " ";
    zT_398 = 1;
    zT_397.ptr = zT_396;
    zT_397.len = zT_398;
    sif6nl = zT_397;
    zT_399 = sif6nl;
    zF_48AC7B3A_markerWrite(zT_399);
    zT_400 = self->type_table;
    zT_401 = node_idx;
    zT_402 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_400, zT_401, zT_402);
    return else_type;
    z_bb_112:
    if ((unsigned char)(else_type == (unsigned int)(1))) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_407 = "SIF:7N";
    zT_409 = 6;
    zT_408.ptr = zT_407;
    zT_408.len = zT_409;
    sif7m = zT_408;
    zT_410 = sif7m;
    zT_411 = node_idx;
    zF_C914CB83_markerWriteInt(zT_410, zT_411);
    zT_413 = "T";
    zT_415 = 1;
    zT_414.ptr = zT_413;
    zT_414.len = zT_415;
    sif7tm = zT_414;
    zT_416 = sif7tm;
    zT_417 = then_type;
    zF_C914CB83_markerWriteInt(zT_416, zT_417);
    zT_419 = " ";
    zT_421 = 1;
    zT_420.ptr = zT_419;
    zT_420.len = zT_421;
    sif7nl = zT_420;
    zT_422 = sif7nl;
    zF_48AC7B3A_markerWrite(zT_422);
    zT_423 = self->type_table;
    zT_424 = node_idx;
    zT_425 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_423, zT_424, zT_425);
    return then_type;
    z_bb_114:
    zT_428 = "SIF:FN";
    zT_430 = 6;
    zT_429.ptr = zT_428;
    zT_429.len = zT_430;
    siffm = zT_429;
    zT_431 = siffm;
    zT_432 = node_idx;
    zF_C914CB83_markerWriteInt(zT_431, zT_432);
    zT_434 = "\n";
    zT_436 = 1;
    zT_435.ptr = zT_434;
    zT_435.len = zT_436;
    sifftm = zT_435;
    zT_437 = sifftm;
    zF_48AC7B3A_markerWrite(zT_437);
    zT_438 = self->type_table;
    zT_439 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_438, zT_439, (unsigned int)(1));
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveEnumLiteral */
unsigned int zF_8C008E53_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_54FF90FA_TaggedUnionPayload* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_54FF90FA_TaggedUnionPayload zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned short zT_40;
    unsigned int zT_41;
    zT_338B7C76_TypeRegistry* zT_43;
    zT_2DF01B61_FieldEntry* zT_44;
    zT_2DF01B61_FieldEntry zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    int zT_68;
    unsigned int zT_69;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_2DF01B61_FieldEntry* zT_73;
    unsigned int zT_74;
    zT_2DF01B61_FieldEntry zT_75;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_82;
    unsigned int zT_84;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_21D3708C_U32ToU32Map* zT_92;
    unsigned int zT_93;
    zT_21D3708C_U32ToU32Map* zT_95;
    unsigned int zT_96;
    zT_8EED1867_ResolvedTypeTable* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_105;
    int zT_106;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_457ECFEE_EnumPayload* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_457ECFEE_EnumPayload zT_118;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned short zT_123;
    unsigned int zT_124;
    int zT_126;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D96DCDF2_EnumMember* zT_131;
    unsigned int zT_132;
    zT_D96DCDF2_EnumMember zT_133;
    unsigned int zT_134;
    zT_21D3708C_U32ToU32Map* zT_136;
    unsigned int zT_137;
    zT_C69B2266_i64 zT_140;
    zT_8EED1867_ResolvedTypeTable* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_147;
    int zT_148;
    unsigned int zT_150;
    unsigned int zT_151;
    int zT_152;
    unsigned int* zT_155;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_338B7C76_TypeRegistry* zT_164;
    zT_D155D06D_Type* zT_165;
    unsigned int zT_166;
    zT_D155D06D_Type zT_167;
    zT_33EF6BFB_TypeKind zT_168;
    zT_338B7C76_TypeRegistry* zT_173;
    zT_54FF90FA_TaggedUnionPayload* zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    zT_54FF90FA_TaggedUnionPayload zT_177;
    unsigned int zT_179;
    unsigned int zT_180;
    unsigned short zT_182;
    unsigned int zT_183;
    int zT_185;
    unsigned int zT_186;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_2DF01B61_FieldEntry* zT_190;
    unsigned int zT_191;
    zT_2DF01B61_FieldEntry zT_192;
    unsigned int zT_193;
    unsigned int zT_195;
    zT_21D3708C_U32ToU32Map* zT_198;
    unsigned int zT_199;
    zT_8EED1867_ResolvedTypeTable* zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_208;
    unsigned int zT_210;
    unsigned int zT_212;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_F85C5DED_DiagnosticCollector* zT_217;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_230 = 0;
    int zT_232;
    unsigned int zT_234;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned int zT_240;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_F85C5DED_DiagnosticCollector* zT_245;
    unsigned int zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_258 = 0;
    zT_33EF6BFB_TypeKind zT_260;
    zT_338B7C76_TypeRegistry* zT_265;
    zT_457ECFEE_EnumPayload* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    zT_457ECFEE_EnumPayload zT_269;
    unsigned int zT_271;
    unsigned int zT_272;
    unsigned short zT_274;
    unsigned int zT_275;
    int zT_277;
    unsigned int zT_278;
    zT_338B7C76_TypeRegistry* zT_281;
    zT_D96DCDF2_EnumMember* zT_282;
    unsigned int zT_283;
    zT_D96DCDF2_EnumMember zT_284;
    unsigned int zT_285;
    zT_21D3708C_U32ToU32Map* zT_287;
    unsigned int zT_288;
    zT_C69B2266_i64 zT_291;
    zT_8EED1867_ResolvedTypeTable* zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    int zT_297;
    unsigned int zT_299;
    unsigned char* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    unsigned int zT_305;
    zT_8EED1867_ResolvedTypeTable* zT_306;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u el;
    zT_22A7C88B_AstNode node;
    unsigned int n;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int f0;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elc_m;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u elv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elm_m;
    zT_457ECFEE_EnumPayload enp;
    unsigned int estart;
    unsigned int ecount;
    unsigned int emi;
    zT_D96DCDF2_EnumMember member;
    unsigned int top;
    zT_D155D06D_Type top_ty;
    unsigned int fstart2;
    unsigned int fcount2;
    unsigned int fi2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u elr_msg;
    zT_457ECFEE_EnumPayload enp2;
    unsigned int estart2;
    unsigned int ecount2;
    unsigned int emi2;
    zT_D96DCDF2_EnumMember member2;
    zT_3 = "eL\n";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    el = zT_4;
    zT_6 = el;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node_idx;
    zT_16 = zF_53458827_astStoreIdentifier(zT_13, zT_14);
    n = zT_16;
    zT_17 = self->current_switch_cond_tu;
    if ((unsigned char)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = self->current_switch_cond_tu;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    tu_ty = zT_25;
    zT_26 = tu_ty.kind;
    if ((unsigned char)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_151 = self->expected_type_stack_len;
    zT_152 = 0;
    if ((unsigned char)(zT_151 > (unsigned int)zT_152)) goto z_bb_19; else goto z_bb_20;
    z_bb_3:
    zT_31 = self->registry;
    zT_32 = zT_31->tu_items;
    zT_33 = tu_ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    tp = zT_35;
    zT_37 = tp.fields_start;
    zT_38 = (unsigned int)zT_37;
    fstart = zT_38;
    zT_40 = tp.fields_count;
    zT_41 = (unsigned int)zT_40;
    fcount = zT_41;
    zT_43 = self->registry;
    zT_44 = zT_43->fe_items;
    zT_45 = zT_44[fstart];
    zT_46 = zT_45.name_id;
    zT_47 = (unsigned int)zT_46;
    f0 = zT_47;
    zT_49 = "EL:N";
    zT_51 = 4;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    eln_m = zT_50;
    zT_52 = eln_m;
    zT_53 = n;
    zF_C914CB83_markerWriteInt(zT_52, zT_53);
    zT_55 = "EL:F";
    zT_57 = 4;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    elf_m = zT_56;
    zT_58 = elf_m;
    zT_59 = f0;
    zF_C914CB83_markerWriteInt(zT_58, zT_59);
    zT_61 = "EL:C";
    zT_63 = 4;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    elc_m = zT_62;
    zT_64 = elc_m;
    zF_C914CB83_markerWriteInt(zT_64, (unsigned int)((unsigned int)fcount));
    zT_68 = 0;
    zT_69 = (unsigned int)zT_68;
    fi = zT_69;
    goto z_bb_5;
    z_bb_4:
    zT_109 = tu_ty.kind;
    if ((unsigned char)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_5:
    if ((unsigned char)(fi < fcount)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_72 = self->registry;
    zT_73 = zT_72->fe_items;
    zT_74 = fstart + fi;
    zT_75 = zT_73[zT_74];
    fe = zT_75;
    zT_77 = "EL:V";
    zT_79 = 4;
    zT_78.ptr = zT_77;
    zT_78.len = zT_79;
    elv_m = zT_78;
    zT_80 = elv_m;
    zT_82 = fe.name_id;
    zF_C914CB83_markerWriteInt(zT_80, (unsigned int)((unsigned int)zT_82));
    zT_84 = fe.name_id;
    if ((unsigned char)(zT_84 == n)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_106 = 1;
    zT_108 = fi + (unsigned int)((unsigned int)zT_106);
    fi = zT_108;
    goto z_bb_5;
    z_bb_9:
    zT_87 = "EL:M";
    zT_89 = 4;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    elm_m = zT_88;
    zT_90 = elm_m;
    zT_92 = self->enum_value_table;
    zT_93 = zT_92->count;
    zF_C914CB83_markerWriteInt(zT_90, (unsigned int)((unsigned int)zT_93));
    zT_95 = self->enum_value_table;
    zT_96 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_95, zT_96, (unsigned int)((unsigned int)fi));
    zT_100 = self->type_table;
    zT_101 = node_idx;
    zT_102 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_100, zT_101, zT_102);
    zT_105 = self->current_switch_cond_tu;
    return zT_105;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_114 = self->registry;
    zT_115 = zT_114->en_items;
    zT_116 = tu_ty.payload_idx;
    zT_117 = (unsigned int)zT_116;
    zT_118 = zT_115[zT_117];
    enp = zT_118;
    zT_120 = enp.members_start;
    zT_121 = (unsigned int)zT_120;
    estart = zT_121;
    zT_123 = enp.members_count;
    zT_124 = (unsigned int)zT_123;
    ecount = zT_124;
    zT_126 = 0;
    zT_127 = (unsigned int)zT_126;
    emi = zT_127;
    goto z_bb_13;
    z_bb_12:
    goto z_bb_2;
    z_bb_13:
    if ((unsigned char)(emi < ecount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_130 = self->registry;
    zT_131 = zT_130->em_items;
    zT_132 = estart + emi;
    zT_133 = zT_131[zT_132];
    member = zT_133;
    zT_134 = member.name_id;
    if ((unsigned char)(zT_134 == n)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_148 = 1;
    zT_150 = emi + (unsigned int)((unsigned int)zT_148);
    emi = zT_150;
    goto z_bb_13;
    z_bb_17:
    zT_136 = self->enum_value_table;
    zT_137 = node_idx;
    zT_140 = member.value;
    zF_26476265_u32ToU32MapPut(zT_136, zT_137, (unsigned int)((unsigned int)zT_140));
    zT_142 = self->type_table;
    zT_143 = node_idx;
    zT_144 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_142, zT_143, zT_144);
    zT_147 = self->current_switch_cond_tu;
    return zT_147;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_155 = self->expected_type_stack_items;
    zT_156 = self->expected_type_stack_len;
    zT_157 = 1;
    zT_159 = (unsigned int)(unsigned int)(zT_156 - zT_157);
    zT_160 = zT_155[zT_159];
    top = zT_160;
    if ((unsigned char)(top != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_301 = "ELV:N";
    zT_303 = 5;
    zT_302.ptr = zT_301;
    zT_302.len = zT_303;
    elv_m = zT_302;
    zT_304 = elv_m;
    zT_305 = n;
    zF_C914CB83_markerWriteInt(zT_304, zT_305);
    zT_306 = self->type_table;
    zT_307 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_306, zT_307, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_21:
    zT_164 = self->registry;
    zT_165 = zT_164->types_items;
    zT_166 = (unsigned int)top;
    zT_167 = zT_165[zT_166];
    top_ty = zT_167;
    zT_168 = top_ty.kind;
    if ((unsigned char)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_173 = self->registry;
    zT_174 = zT_173->tu_items;
    zT_175 = top_ty.payload_idx;
    zT_176 = (unsigned int)zT_175;
    zT_177 = zT_174[zT_176];
    tp = zT_177;
    zT_179 = tp.fields_start;
    zT_180 = (unsigned int)zT_179;
    fstart2 = zT_180;
    zT_182 = tp.fields_count;
    zT_183 = (unsigned int)zT_182;
    fcount2 = zT_183;
    zT_185 = 0;
    zT_186 = (unsigned int)zT_185;
    fi2 = zT_186;
    goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_260 = top_ty.kind;
    if ((unsigned char)(zT_260 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_26:
    if ((unsigned char)(fi2 < fcount2)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_189 = self->registry;
    zT_190 = zT_189->fe_items;
    zT_191 = fstart2 + fi2;
    zT_192 = zT_190[zT_191];
    fe = zT_192;
    zT_193 = fe.name_id;
    if ((unsigned char)(zT_193 == n)) goto z_bb_30; else goto z_bb_31;
    z_bb_28:
    zT_236 = node.span_start;
    sp = zT_236;
    zT_238 = node.span_len;
    zT_240 = sp + (unsigned int)((unsigned int)zT_238);
    ep = zT_240;
    zT_242 = "unknown enum literal member";
    zT_244 = 27;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    elu_msg = zT_243;
    zT_245 = self->diag;
    zT_248 = self->source_file_id;
    zT_249 = sp;
    zT_250 = ep;
    zT_251 = elu_msg;
    zT_258 = zF_C82559AC_diagnosticCollector(zT_245, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3009_UNKNOWN_ENUM_LITERAL_MEMBER)), zT_248, zT_249, zT_250, zT_251);
    (void)zT_258;
    return (unsigned int)(1);
    z_bb_29:
    zT_232 = 1;
    zT_234 = fi2 + (unsigned int)((unsigned int)zT_232);
    fi2 = zT_234;
    goto z_bb_26;
    z_bb_30:
    zT_195 = fe.type_id;
    if ((unsigned char)(zT_195 == (unsigned int)(1))) goto z_bb_32; else goto z_bb_34;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_198 = self->enum_value_table;
    zT_199 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_198, zT_199, (unsigned int)((unsigned int)fi2));
    zT_203 = self->type_table;
    zT_204 = node_idx;
    zT_205 = top;
    zF_19B4A07D_resolvedTypeTableSe(zT_203, zT_204, zT_205);
    return top;
    goto z_bb_31;
    z_bb_34:
    zT_208 = node.span_start;
    sp = zT_208;
    zT_210 = node.span_len;
    zT_212 = sp + (unsigned int)((unsigned int)zT_210);
    ep = zT_212;
    zT_214 = "enum literal member requires payload";
    zT_216 = 36;
    zT_215.ptr = zT_214;
    zT_215.len = zT_216;
    elr_msg = zT_215;
    zT_217 = self->diag;
    zT_220 = self->source_file_id;
    zT_221 = sp;
    zT_222 = ep;
    zT_223 = elr_msg;
    zT_230 = zF_C82559AC_diagnosticCollector(zT_217, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3008_ENUM_LITERAL_REQUIRES_PAYLOAD)), zT_220, zT_221, zT_222, zT_223);
    (void)zT_230;
    return (unsigned int)(1);
    z_bb_35:
    zT_265 = self->registry;
    zT_266 = zT_265->en_items;
    zT_267 = top_ty.payload_idx;
    zT_268 = (unsigned int)zT_267;
    zT_269 = zT_266[zT_268];
    enp2 = zT_269;
    zT_271 = enp2.members_start;
    zT_272 = (unsigned int)zT_271;
    estart2 = zT_272;
    zT_274 = enp2.members_count;
    zT_275 = (unsigned int)zT_274;
    ecount2 = zT_275;
    zT_277 = 0;
    zT_278 = (unsigned int)zT_277;
    emi2 = zT_278;
    goto z_bb_37;
    z_bb_36:
    goto z_bb_24;
    z_bb_37:
    if ((unsigned char)(emi2 < ecount2)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_281 = self->registry;
    zT_282 = zT_281->em_items;
    zT_283 = estart2 + emi2;
    zT_284 = zT_282[zT_283];
    member2 = zT_284;
    zT_285 = member2.name_id;
    if ((unsigned char)(zT_285 == n)) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_297 = 1;
    zT_299 = emi2 + (unsigned int)((unsigned int)zT_297);
    emi2 = zT_299;
    goto z_bb_37;
    z_bb_41:
    zT_287 = self->enum_value_table;
    zT_288 = node_idx;
    zT_291 = member2.value;
    zF_26476265_u32ToU32MapPut(zT_287, zT_288, (unsigned int)((unsigned int)zT_291));
    zT_293 = self->type_table;
    zT_294 = node_idx;
    zT_295 = top;
    zF_19B4A07D_resolvedTypeTableSe(zT_293, zT_294, zT_295);
    return top;
    z_bb_42:
    goto z_bb_40;
}

/* semanticAnalyzerResolveStructInit */
unsigned int zF_AD7EF126_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_38C12417_SemanticAnalyzer* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19 = 0;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_D155D06D_Type* zT_25;
    unsigned int zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_54FF90FA_TaggedUnionPayload* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_54FF90FA_TaggedUnionPayload zT_37;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned short zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    unsigned int zT_48 = 0;
    int zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_62 = 0;
    zT_22A7C88B_AstNode zT_63 = {0};
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_73 = 0;
    unsigned int zT_74 = 0;
    int zT_78;
    unsigned int zT_79;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_2DF01B61_FieldEntry* zT_82;
    unsigned int zT_83;
    zT_2DF01B61_FieldEntry zT_84;
    unsigned int zT_85;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_2DF01B61_FieldEntry* zT_92;
    unsigned int zT_93;
    zT_2DF01B61_FieldEntry zT_94;
    unsigned int zT_95;
    zT_38C12417_SemanticAnalyzer* zT_96;
    unsigned int zT_97;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    unsigned int zT_102 = 0;
    zT_38C12417_SemanticAnalyzer* zT_103;
    zT_38C12417_SemanticAnalyzer* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_111;
    int zT_112;
    unsigned int zT_114;
    zT_8EED1867_ResolvedTypeTable* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_33EF6BFB_TypeKind zT_119;
    zT_338B7C76_TypeRegistry* zT_124;
    zT_406493CE_StructPayload* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_406493CE_StructPayload zT_128;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned short zT_133;
    unsigned int zT_134;
    zT_6B0A7D14_AstStore* zT_136;
    unsigned int zT_137;
    unsigned int zT_139 = 0;
    int zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    unsigned int zT_153 = 0;
    zT_22A7C88B_AstNode zT_154 = {0};
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_159;
    unsigned int zT_160;
    unsigned int zT_164 = 0;
    unsigned int zT_165 = 0;
    int zT_169;
    unsigned int zT_170;
    zT_338B7C76_TypeRegistry* zT_172;
    zT_2DF01B61_FieldEntry* zT_173;
    unsigned int zT_174;
    zT_2DF01B61_FieldEntry zT_175;
    unsigned int zT_176;
    unsigned int zT_178;
    zT_338B7C76_TypeRegistry* zT_182;
    zT_2DF01B61_FieldEntry* zT_183;
    unsigned int zT_184;
    zT_2DF01B61_FieldEntry zT_185;
    unsigned int zT_186;
    zT_38C12417_SemanticAnalyzer* zT_187;
    unsigned int zT_188;
    zT_38C12417_SemanticAnalyzer* zT_190;
    unsigned int zT_191;
    unsigned int zT_193 = 0;
    zT_38C12417_SemanticAnalyzer* zT_194;
    zT_38C12417_SemanticAnalyzer* zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    int zT_200;
    unsigned int zT_202;
    int zT_203;
    unsigned int zT_205;
    zT_8EED1867_ResolvedTypeTable* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    zT_33EF6BFB_TypeKind zT_210;
    unsigned char zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    zT_338B7C76_TypeRegistry* zT_220;
    zT_AF9231A2_UnionPayload* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_AF9231A2_UnionPayload zT_224;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned short zT_229;
    unsigned int zT_230;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    unsigned int zT_235 = 0;
    int zT_237;
    unsigned int zT_238;
    zT_6B0A7D14_AstStore* zT_241;
    unsigned int zT_242;
    zT_6B0A7D14_AstStore* zT_244;
    unsigned int zT_245;
    unsigned int zT_249 = 0;
    zT_22A7C88B_AstNode zT_250 = {0};
    zT_6B0A7D14_AstStore* zT_252;
    unsigned int zT_253;
    zT_6B0A7D14_AstStore* zT_255;
    unsigned int zT_256;
    unsigned int zT_260 = 0;
    unsigned int zT_261 = 0;
    int zT_265;
    unsigned int zT_266;
    zT_338B7C76_TypeRegistry* zT_268;
    zT_2DF01B61_FieldEntry* zT_269;
    unsigned int zT_270;
    zT_2DF01B61_FieldEntry zT_271;
    unsigned int zT_272;
    unsigned int zT_274;
    zT_338B7C76_TypeRegistry* zT_278;
    zT_2DF01B61_FieldEntry* zT_279;
    unsigned int zT_280;
    zT_2DF01B61_FieldEntry zT_281;
    unsigned int zT_282;
    zT_38C12417_SemanticAnalyzer* zT_283;
    unsigned int zT_284;
    zT_38C12417_SemanticAnalyzer* zT_286;
    unsigned int zT_287;
    unsigned int zT_289 = 0;
    zT_38C12417_SemanticAnalyzer* zT_290;
    zT_38C12417_SemanticAnalyzer* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    int zT_296;
    unsigned int zT_298;
    int zT_299;
    unsigned int zT_301;
    zT_8EED1867_ResolvedTypeTable* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_22A7C88B_AstNode node;
    unsigned int target_type;
    zT_D155D06D_Type tgt;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int field_inits_n;
    unsigned int fii;
    zT_22A7C88B_AstNode fi_node;
    unsigned int fname_id;
    unsigned int fi;
    unsigned int field_type;
    unsigned int init_type;
    zT_406493CE_StructPayload sp;
    zT_AF9231A2_UnionPayload up;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = 0;
    target_type = zT_8;
    zT_9 = node.child_0;
    if ((unsigned char)(zT_9 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = node.child_0;
    zT_15 = zF_54F95822_semanticAnalyzerRes(zT_12, zT_13);
    target_type = zT_15;
    goto z_bb_2;
    z_bb_2:
    if ((unsigned char)(target_type == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = self;
    zT_19 = zF_4DE7C2BC_topExpectedType(zT_18);
    target_type = zT_19;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(target_type == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(1);
    z_bb_6:
    zT_24 = self->registry;
    zT_25 = zT_24->types_items;
    zT_26 = (unsigned int)target_type;
    zT_27 = zT_25[zT_26];
    tgt = zT_27;
    zT_28 = tgt.kind;
    if ((unsigned char)(zT_28 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_33 = self->registry;
    zT_34 = zT_33->tu_items;
    zT_35 = tgt.payload_idx;
    zT_36 = (unsigned int)zT_35;
    zT_37 = zT_34[zT_36];
    tp = zT_37;
    zT_39 = tp.fields_start;
    zT_40 = (unsigned int)zT_39;
    fstart = zT_40;
    zT_42 = tp.fields_count;
    zT_43 = (unsigned int)zT_42;
    fcount = zT_43;
    zT_45 = self->store;
    zT_46 = node_idx;
    zT_48 = zF_152E19CB_astStoreNodeExtraCh(zT_45, zT_46);
    field_inits_n = zT_48;
    zT_50 = 0;
    zT_51 = (unsigned int)zT_50;
    fii = zT_51;
    goto z_bb_9;
    z_bb_8:
    zT_119 = tgt.kind;
    if ((unsigned char)(zT_119 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    if ((unsigned char)(fii < field_inits_n)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_54 = self->store;
    zT_57 = self->store;
    zT_58 = node_idx;
    zT_62 = zF_B10B1BC1_astStoreNodeExtraCh(zT_57, zT_58, (unsigned int)((unsigned int)fii));
    zT_55 = zT_62;
    zT_63 = zF_FCDD1D35_astStoreNodeAt(zT_54, zT_55);
    fi_node = zT_63;
    zT_65 = self->store;
    zT_68 = self->store;
    zT_69 = node_idx;
    zT_73 = zF_B10B1BC1_astStoreNodeExtraCh(zT_68, zT_69, (unsigned int)((unsigned int)fii));
    zT_66 = zT_73;
    zT_74 = zF_8BA26B9E_astStoreNodePayload(zT_65, zT_66);
    fname_id = zT_74;
    if ((unsigned char)(fname_id != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_115 = self->type_table;
    zT_116 = node_idx;
    zT_117 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_115, zT_116, zT_117);
    return target_type;
    z_bb_12:
    zT_112 = 1;
    zT_114 = fii + (unsigned int)((unsigned int)zT_112);
    fii = zT_114;
    goto z_bb_9;
    z_bb_13:
    zT_78 = 0;
    zT_79 = (unsigned int)zT_78;
    fi = zT_79;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((unsigned char)(fi < fcount)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_81 = self->registry;
    zT_82 = zT_81->fe_items;
    zT_83 = fstart + fi;
    zT_84 = zT_82[zT_83];
    zT_85 = zT_84.name_id;
    if ((unsigned char)(zT_85 == fname_id)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_109 = 1;
    zT_111 = fi + (unsigned int)((unsigned int)zT_109);
    fi = zT_111;
    goto z_bb_15;
    z_bb_19:
    zT_87 = fi_node.child_0;
    if ((unsigned char)(zT_87 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_91 = self->registry;
    zT_92 = zT_91->fe_items;
    zT_93 = fstart + fi;
    zT_94 = zT_92[zT_93];
    zT_95 = zT_94.type_id;
    field_type = zT_95;
    zT_96 = self;
    zT_97 = field_type;
    zF_9665A229_pushExpectedType(zT_96, zT_97);
    zT_99 = self;
    zT_100 = fi_node.child_0;
    zT_102 = zF_54F95822_semanticAnalyzerRes(zT_99, zT_100);
    init_type = zT_102;
    zT_103 = self;
    zF_BC478E78_popExpectedType(zT_103);
    zT_104 = self;
    zT_105 = fi_node.child_0;
    zT_106 = init_type;
    zT_107 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_104, zT_105, zT_106, zT_107);
    goto z_bb_22;
    z_bb_22:
    goto z_bb_17;
    z_bb_23:
    zT_124 = self->registry;
    zT_125 = zT_124->st_items;
    zT_126 = tgt.payload_idx;
    zT_127 = (unsigned int)zT_126;
    zT_128 = zT_125[zT_127];
    sp = zT_128;
    zT_130 = sp.fields_start;
    zT_131 = (unsigned int)zT_130;
    fstart = zT_131;
    zT_133 = sp.fields_count;
    zT_134 = (unsigned int)zT_133;
    fcount = zT_134;
    zT_136 = self->store;
    zT_137 = node_idx;
    zT_139 = zF_152E19CB_astStoreNodeExtraCh(zT_136, zT_137);
    field_inits_n = zT_139;
    zT_141 = 0;
    zT_142 = (unsigned int)zT_141;
    fii = zT_142;
    goto z_bb_25;
    z_bb_24:
    zT_210 = tgt.kind;
    if ((unsigned char)(zT_210 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_40; else goto z_bb_39;
    z_bb_25:
    if ((unsigned char)(fii < field_inits_n)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_145 = self->store;
    zT_148 = self->store;
    zT_149 = node_idx;
    zT_153 = zF_B10B1BC1_astStoreNodeExtraCh(zT_148, zT_149, (unsigned int)((unsigned int)fii));
    zT_146 = zT_153;
    zT_154 = zF_FCDD1D35_astStoreNodeAt(zT_145, zT_146);
    fi_node = zT_154;
    zT_156 = self->store;
    zT_159 = self->store;
    zT_160 = node_idx;
    zT_164 = zF_B10B1BC1_astStoreNodeExtraCh(zT_159, zT_160, (unsigned int)((unsigned int)fii));
    zT_157 = zT_164;
    zT_165 = zF_8BA26B9E_astStoreNodePayload(zT_156, zT_157);
    fname_id = zT_165;
    if ((unsigned char)(fname_id != (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_206 = self->type_table;
    zT_207 = node_idx;
    zT_208 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_206, zT_207, zT_208);
    return target_type;
    z_bb_28:
    zT_203 = 1;
    zT_205 = fii + (unsigned int)((unsigned int)zT_203);
    fii = zT_205;
    goto z_bb_25;
    z_bb_29:
    zT_169 = 0;
    zT_170 = (unsigned int)zT_169;
    fi = zT_170;
    goto z_bb_31;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    if ((unsigned char)(fi < fcount)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_172 = self->registry;
    zT_173 = zT_172->fe_items;
    zT_174 = fstart + fi;
    zT_175 = zT_173[zT_174];
    zT_176 = zT_175.name_id;
    if ((unsigned char)(zT_176 == fname_id)) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_200 = 1;
    zT_202 = fi + (unsigned int)((unsigned int)zT_200);
    fi = zT_202;
    goto z_bb_31;
    z_bb_35:
    zT_178 = fi_node.child_0;
    if ((unsigned char)(zT_178 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_182 = self->registry;
    zT_183 = zT_182->fe_items;
    zT_184 = fstart + fi;
    zT_185 = zT_183[zT_184];
    zT_186 = zT_185.type_id;
    field_type = zT_186;
    zT_187 = self;
    zT_188 = field_type;
    zF_9665A229_pushExpectedType(zT_187, zT_188);
    zT_190 = self;
    zT_191 = fi_node.child_0;
    zT_193 = zF_54F95822_semanticAnalyzerRes(zT_190, zT_191);
    init_type = zT_193;
    zT_194 = self;
    zF_BC478E78_popExpectedType(zT_194);
    zT_195 = self;
    zT_196 = fi_node.child_0;
    zT_197 = init_type;
    zT_198 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_195, zT_196, zT_197, zT_198);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_33;
    z_bb_39:
    zT_215 = tgt.kind;
    zT_214 = zT_215 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_41;
    z_bb_40:
    zT_214 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_214) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_220 = self->registry;
    zT_221 = zT_220->un_items;
    zT_222 = tgt.payload_idx;
    zT_223 = (unsigned int)zT_222;
    zT_224 = zT_221[zT_223];
    up = zT_224;
    zT_226 = up.fields_start;
    zT_227 = (unsigned int)zT_226;
    fstart = zT_227;
    zT_229 = up.fields_count;
    zT_230 = (unsigned int)zT_229;
    fcount = zT_230;
    zT_232 = self->store;
    zT_233 = node_idx;
    zT_235 = zF_152E19CB_astStoreNodeExtraCh(zT_232, zT_233);
    field_inits_n = zT_235;
    zT_237 = 0;
    zT_238 = (unsigned int)zT_237;
    fii = zT_238;
    goto z_bb_44;
    z_bb_43:
    return (unsigned int)(1);
    z_bb_44:
    if ((unsigned char)(fii < field_inits_n)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_241 = self->store;
    zT_244 = self->store;
    zT_245 = node_idx;
    zT_249 = zF_B10B1BC1_astStoreNodeExtraCh(zT_244, zT_245, (unsigned int)((unsigned int)fii));
    zT_242 = zT_249;
    zT_250 = zF_FCDD1D35_astStoreNodeAt(zT_241, zT_242);
    fi_node = zT_250;
    zT_252 = self->store;
    zT_255 = self->store;
    zT_256 = node_idx;
    zT_260 = zF_B10B1BC1_astStoreNodeExtraCh(zT_255, zT_256, (unsigned int)((unsigned int)fii));
    zT_253 = zT_260;
    zT_261 = zF_8BA26B9E_astStoreNodePayload(zT_252, zT_253);
    fname_id = zT_261;
    if ((unsigned char)(fname_id != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    zT_302 = self->type_table;
    zT_303 = node_idx;
    zT_304 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_302, zT_303, zT_304);
    return target_type;
    z_bb_47:
    zT_299 = 1;
    zT_301 = fii + (unsigned int)((unsigned int)zT_299);
    fii = zT_301;
    goto z_bb_44;
    z_bb_48:
    zT_265 = 0;
    zT_266 = (unsigned int)zT_265;
    fi = zT_266;
    goto z_bb_50;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    if ((unsigned char)(fi < fcount)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_268 = self->registry;
    zT_269 = zT_268->fe_items;
    zT_270 = fstart + fi;
    zT_271 = zT_269[zT_270];
    zT_272 = zT_271.name_id;
    if ((unsigned char)(zT_272 == fname_id)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_296 = 1;
    zT_298 = fi + (unsigned int)((unsigned int)zT_296);
    fi = zT_298;
    goto z_bb_50;
    z_bb_54:
    zT_274 = fi_node.child_0;
    if ((unsigned char)(zT_274 != (unsigned int)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_278 = self->registry;
    zT_279 = zT_278->fe_items;
    zT_280 = fstart + fi;
    zT_281 = zT_279[zT_280];
    zT_282 = zT_281.type_id;
    field_type = zT_282;
    zT_283 = self;
    zT_284 = field_type;
    zF_9665A229_pushExpectedType(zT_283, zT_284);
    zT_286 = self;
    zT_287 = fi_node.child_0;
    zT_289 = zF_54F95822_semanticAnalyzerRes(zT_286, zT_287);
    init_type = zT_289;
    zT_290 = self;
    zF_BC478E78_popExpectedType(zT_290);
    zT_291 = self;
    zT_292 = fi_node.child_0;
    zT_293 = init_type;
    zT_294 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_291, zT_292, zT_293, zT_294);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_52;
}

/* semanticAnalyzerIsLValueConst */
unsigned char zF_689D82E1_semanticAnalyzerIsL(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_38C12417_SemanticAnalyzer* zT_14;
    unsigned int zT_16;
    zT_8143F551_AstKind zT_18;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_28;
    unsigned int zT_32;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned char* zT_36;
    unsigned char zT_37;
    zT_3D7259E2_SymbolRegistry* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_567DA1C3_Opt_868 zT_45 = {0};
    unsigned char zT_46;
    zT_3C598AEF_SymbolKind zT_48;
    unsigned char zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    zT_22A7C88B_AstNode zT_61 = {0};
    zT_8143F551_AstKind zT_62;
    unsigned short zT_66;
    zT_8143F551_AstKind zT_72;
    zT_8EED1867_ResolvedTypeTable* zT_76;
    unsigned int zT_77;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    unsigned char zT_81;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_D155D06D_Type* zT_89;
    unsigned int zT_90;
    zT_D155D06D_Type zT_91;
    zT_33EF6BFB_TypeKind zT_92;
    unsigned char zT_96;
    zT_33EF6BFB_TypeKind zT_97;
    unsigned char zT_101;
    zT_8143F551_AstKind zT_107;
    zT_8EED1867_ResolvedTypeTable* zT_111;
    unsigned int zT_112;
    zT_BAEE192E_Opt_10 zT_115 = {0};
    unsigned char zT_116;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    zT_338B7C76_TypeRegistry* zT_123;
    zT_D155D06D_Type* zT_124;
    unsigned int zT_125;
    zT_D155D06D_Type zT_126;
    zT_33EF6BFB_TypeKind zT_127;
    unsigned char zT_131;
    zT_33EF6BFB_TypeKind zT_132;
    unsigned char zT_136;
    zT_33EF6BFB_TypeKind zT_137;
    unsigned char zT_141;
    zT_33EF6BFB_TypeKind zT_146;
    zT_38C12417_SemanticAnalyzer* zT_150;
    unsigned int zT_152;
    zT_8143F551_AstKind zT_155;
    zT_6B0A7D14_AstStore* zT_160;
    unsigned int zT_161;
    unsigned int zT_163 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_164;
    unsigned int zT_165;
    zT_BAEE192E_Opt_10 zT_168 = {0};
    unsigned char zT_169;
    zT_338B7C76_TypeRegistry* zT_172;
    unsigned int zT_173;
    zT_338B7C76_TypeRegistry* zT_176;
    zT_D155D06D_Type* zT_177;
    unsigned int zT_178;
    zT_D155D06D_Type zT_179;
    zT_33EF6BFB_TypeKind zT_180;
    unsigned char zT_184;
    zT_33EF6BFB_TypeKind zT_185;
    unsigned char zT_189;
    zT_33EF6BFB_TypeKind zT_194;
    zT_3D7259E2_SymbolRegistry* zT_198;
    unsigned int zT_199;
    unsigned int zT_200;
    zT_567DA1C3_Opt_868 zT_203 = {0};
    unsigned char zT_204;
    zT_3C598AEF_SymbolKind zT_206;
    unsigned char zT_210;
    unsigned int zT_211;
    zT_6B0A7D14_AstStore* zT_215;
    unsigned int zT_216;
    zT_22A7C88B_AstNode zT_219 = {0};
    zT_8143F551_AstKind zT_220;
    unsigned short zT_224;
    zT_38C12417_SemanticAnalyzer* zT_230;
    unsigned int zT_232;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int li;
    zT_3A105EF1_Symbol* s;
    zT_22A7C88B_AstNode dn;
    unsigned int base_t;
    zT_D155D06D_Type bt;
    unsigned int field_name_id;
    zT_3A105EF1_Symbol* fs;
    zT_22A7C88B_AstNode fdn;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self;
    zT_16 = node.child_0;
    self = zT_14;
    node_idx = zT_16;
    goto z_bb_0;
    z_bb_4:
    zT_18 = node.kind;
    if ((unsigned char)(zT_18 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = self->store;
    zT_24 = node_idx;
    zT_26 = zF_53458827_astStoreIdentifier(zT_23, zT_24);
    name_id = zT_26;
    zT_28 = self->local_decl_count;
    li = zT_28;
    goto z_bb_7;
    z_bb_6:
    zT_72 = node.kind;
    if ((unsigned char)(zT_72 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_22; else goto z_bb_23;
    z_bb_7:
    if ((unsigned char)(li > (unsigned int)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = li - (unsigned int)(1);
    li = zT_32;
    zT_33 = self->local_decl_names;
    zT_34 = zT_33[li];
    if ((unsigned char)(zT_34 == name_id)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_40 = self->symbols;
    zT_41 = self->module_id;
    zT_42 = name_id;
    zT_45 = zF_A398987E_symbolRegistryQuali(zT_40, zT_41, zT_42);
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_36 = self->local_decl_consts;
    zT_37 = zT_36[li];
    return (unsigned char)(zT_37 != (unsigned char)(0));
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    s = zT_45.value;
    zT_48 = s->kind;
    if ((unsigned char)(zT_48 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    return (unsigned char)(0);
    z_bb_15:
    zT_53 = s->decl_node;
    zT_52 = zT_53 != (unsigned int)(0);
    goto z_bb_17;
    z_bb_16:
    zT_52 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_52) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_57 = self->store;
    zT_58 = s->decl_node;
    zT_61 = zF_FCDD1D35_astStoreNodeAt(zT_57, zT_58);
    dn = zT_61;
    zT_62 = dn.kind;
    if ((unsigned char)(zT_62 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_66 = s->flags;
    return (unsigned char)((unsigned short)(zT_66 & (unsigned short)(1)) == (unsigned short)(0));
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_76 = self->type_table;
    zT_77 = node.child_0;
    zT_80 = zF_999DCF51_resolvedTypeTableGe(zT_76, zT_77);
    zT_81 = zT_80.has_value;
    if (zT_81) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_107 = node.kind;
    if ((unsigned char)(zT_107 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_33; else goto z_bb_34;
    z_bb_24:
    base_t = zT_80.value;
    zT_84 = self->registry;
    zT_85 = zT_84->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)base_t) < zT_85)) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    zT_88 = self->registry;
    zT_89 = zT_88->types_items;
    zT_90 = (unsigned int)base_t;
    zT_91 = zT_89[zT_90];
    bt = zT_91;
    zT_92 = bt.kind;
    if ((unsigned char)(zT_92 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_29; else goto z_bb_28;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_97 = bt.kind;
    zT_96 = zT_97 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_30;
    z_bb_29:
    zT_96 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_96) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_101 = bt.flags;
    return (unsigned char)((unsigned char)(zT_101 & (unsigned char)(1)) != (unsigned char)(0));
    z_bb_32:
    goto z_bb_27;
    z_bb_33:
    zT_111 = self->type_table;
    zT_112 = node.child_0;
    zT_115 = zF_999DCF51_resolvedTypeTableGe(zT_111, zT_112);
    zT_116 = zT_115.has_value;
    if (zT_116) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_155 = node.kind;
    if ((unsigned char)(zT_155 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_49; else goto z_bb_50;
    z_bb_35:
    base_t = zT_115.value;
    zT_119 = self->registry;
    zT_120 = zT_119->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)base_t) < zT_120)) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    return (unsigned char)(0);
    z_bb_37:
    zT_123 = self->registry;
    zT_124 = zT_123->types_items;
    zT_125 = (unsigned int)base_t;
    zT_126 = zT_124[zT_125];
    bt = zT_126;
    zT_127 = bt.kind;
    if ((unsigned char)(zT_127 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_40; else goto z_bb_39;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    zT_132 = bt.kind;
    zT_131 = zT_132 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_41;
    z_bb_40:
    zT_131 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_131) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_137 = bt.kind;
    zT_136 = zT_137 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_44;
    z_bb_43:
    zT_136 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_136) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_141 = bt.flags;
    return (unsigned char)((unsigned char)(zT_141 & (unsigned char)(1)) != (unsigned char)(0));
    z_bb_46:
    zT_146 = bt.kind;
    if ((unsigned char)(zT_146 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_150 = self;
    zT_152 = node.child_0;
    self = zT_150;
    node_idx = zT_152;
    goto z_bb_0;
    z_bb_48:
    goto z_bb_38;
    z_bb_49:
    zT_160 = self->store;
    zT_161 = node_idx;
    zT_163 = zF_8BA26B9E_astStoreNodePayload(zT_160, zT_161);
    field_name_id = zT_163;
    zT_164 = self->type_table;
    zT_165 = node.child_0;
    zT_168 = zF_999DCF51_resolvedTypeTableGe(zT_164, zT_165);
    zT_169 = zT_168.has_value;
    if (zT_169) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    return (unsigned char)(0);
    z_bb_51:
    base_t = zT_168.value;
    zT_172 = self->registry;
    zT_173 = zT_172->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)base_t) < zT_173)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_230 = self;
    zT_232 = node.child_0;
    self = zT_230;
    node_idx = zT_232;
    goto z_bb_0;
    z_bb_53:
    zT_176 = self->registry;
    zT_177 = zT_176->types_items;
    zT_178 = (unsigned int)base_t;
    zT_179 = zT_177[zT_178];
    bt = zT_179;
    zT_180 = bt.kind;
    if ((unsigned char)(zT_180 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_56; else goto z_bb_55;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_185 = bt.kind;
    zT_184 = zT_185 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_57;
    z_bb_56:
    zT_184 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_184) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_189 = bt.flags;
    return (unsigned char)((unsigned char)(zT_189 & (unsigned char)(1)) != (unsigned char)(0));
    z_bb_59:
    zT_194 = bt.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_198 = self->symbols;
    zT_199 = bt.module_id;
    zT_200 = field_name_id;
    zT_203 = zF_A398987E_symbolRegistryQuali(zT_198, zT_199, zT_200);
    zT_204 = zT_203.has_value;
    if (zT_204) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    goto z_bb_54;
    z_bb_62:
    fs = zT_203.value;
    zT_206 = fs->kind;
    if ((unsigned char)(zT_206 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    return (unsigned char)(0);
    z_bb_64:
    zT_211 = fs->decl_node;
    zT_210 = zT_211 != (unsigned int)(0);
    goto z_bb_66;
    z_bb_65:
    zT_210 = 0;
    goto z_bb_66;
    z_bb_66:
    if (zT_210) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_215 = self->store;
    zT_216 = fs->decl_node;
    zT_219 = zF_FCDD1D35_astStoreNodeAt(zT_215, zT_216);
    fdn = zT_219;
    zT_220 = fdn.kind;
    if ((unsigned char)(zT_220 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    goto z_bb_63;
    z_bb_69:
    zT_224 = fs->flags;
    return (unsigned char)((unsigned short)(zT_224 & (unsigned short)(1)) == (unsigned short)(0));
    z_bb_70:
    goto z_bb_68;
}

/* semanticAnalyzerResolveAssign */
unsigned int zF_C0551BB8_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_22A7C88B_AstNode zT_25 = {0};
    zT_8143F551_AstKind zT_26;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int zT_38 = 0;
    zT_D3EB6303_StringInterner* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_42 = 0;
    zT_38C12417_SemanticAnalyzer* zT_44;
    unsigned int zT_45;
    unsigned int zT_47 = 0;
    zT_38C12417_SemanticAnalyzer* zT_49;
    unsigned int zT_50;
    unsigned char zT_52 = 0;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_22A7C88B_AstNode zT_58 = {0};
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_80 = 0;
    zT_38C12417_SemanticAnalyzer* zT_82;
    unsigned int zT_83;
    zT_38C12417_SemanticAnalyzer* zT_85;
    unsigned int zT_86;
    unsigned int zT_88 = 0;
    zT_38C12417_SemanticAnalyzer* zT_89;
    unsigned char zT_92;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    zT_38C12417_SemanticAnalyzer* zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_107 = 0;
    zT_38C12417_SemanticAnalyzer* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned char zT_113 = 0;
    zT_338B7C76_TypeRegistry* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned char zT_119 = 0;
    zT_38C12417_SemanticAnalyzer* zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_138;
    unsigned int zT_140;
    unsigned int zT_142;
    unsigned char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_338B7C76_TypeRegistry* zT_148;
    zT_D155D06D_Type* zT_149;
    unsigned int zT_150;
    zT_D155D06D_Type zT_151;
    zT_33EF6BFB_TypeKind zT_152;
    zT_338B7C76_TypeRegistry* zT_154;
    zT_D155D06D_Type* zT_155;
    unsigned int zT_156;
    zT_D155D06D_Type zT_157;
    zT_33EF6BFB_TypeKind zT_158;
    int zT_160;
    unsigned char zT_161;
    zT_38C12417_SemanticAnalyzer* zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    unsigned char zT_165 = 0;
    int zT_166;
    unsigned char zT_167;
    zT_38C12417_SemanticAnalyzer* zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned char zT_173 = 0;
    int zT_174;
    unsigned char zT_175;
    unsigned char zT_179;
    zT_338B7C76_TypeRegistry* zT_184;
    zT_42C2D6BF_EUPayload* zT_185;
    zT_338B7C76_TypeRegistry* zT_186;
    zT_D155D06D_Type* zT_187;
    unsigned int zT_188;
    zT_D155D06D_Type zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_42C2D6BF_EUPayload zT_192;
    zT_338B7C76_TypeRegistry* zT_194;
    zT_42C2D6BF_EUPayload* zT_195;
    zT_338B7C76_TypeRegistry* zT_196;
    zT_D155D06D_Type* zT_197;
    unsigned int zT_198;
    zT_D155D06D_Type zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_42C2D6BF_EUPayload zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    int zT_206;
    unsigned char zT_207;
    zT_F85C5DED_DiagnosticCollector* zT_209;
    unsigned char zT_210;
    unsigned int zT_212;
    unsigned int zT_213;
    unsigned int zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_219 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_220;
    unsigned int zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    zT_33EF6BFB_TypeKind zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_226;
    unsigned int zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    zT_33EF6BFB_TypeKind zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u ase;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    zT_22A7C88B_AstNode lhs_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u us_str;
    zT_22A7C88B_AstNode lv;
    unsigned int csp;
    unsigned int cep;
    zT_8F083A69_Slice_zT_0B42B2F8_u c_msg;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0;
    unsigned int eff_src;
    zT_8F083A69_Slice_zT_0B42B2F8_u as1;
    zT_8F083A69_Slice_zT_0B42B2F8_u as2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u tma_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_3 = "ASE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ase = zT_4;
    zT_6 = ase;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_17 = node.child_0;
    if ((unsigned char)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->store;
    zT_22 = node.child_0;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    lhs_node = zT_25;
    zT_26 = lhs_node.kind;
    if ((unsigned char)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_49 = self;
    zT_50 = node.child_0;
    zT_52 = zF_689D82E1_semanticAnalyzerIsL(zT_49, zT_50);
    if (zT_52) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    zT_31 = "_";
    zT_33 = 1;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    us_str = zT_32;
    zT_34 = self->store;
    zT_35 = node.child_0;
    zT_38 = zF_53458827_astStoreIdentifier(zT_34, zT_35);
    zT_39 = self->interner;
    zT_40 = us_str;
    zT_42 = zF_50C274AF_stringInternerInter(zT_39, zT_40);
    if ((unsigned char)(zT_38 == zT_42)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_44 = self;
    zT_45 = node.child_1;
    zT_47 = zF_54F95822_semanticAnalyzerRes(zT_44, zT_45);
    (void)zT_47;
    return (unsigned int)(1);
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_54 = self->store;
    zT_55 = node.child_0;
    zT_58 = zF_FCDD1D35_astStoreNodeAt(zT_54, zT_55);
    lv = zT_58;
    zT_60 = lv.span_start;
    csp = zT_60;
    zT_62 = lv.span_len;
    zT_64 = csp + (unsigned int)((unsigned int)zT_62);
    cep = zT_64;
    zT_66 = "cannot assign to immutable variable";
    zT_68 = 35;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    c_msg = zT_67;
    zT_69 = self->diag;
    zT_72 = self->source_file_id;
    zT_73 = csp;
    zT_74 = cep;
    zT_75 = c_msg;
    zT_80 = zF_C82559AC_diagnosticCollector(zT_69, (unsigned char)(0), (unsigned short)(3002), zT_72, zT_73, zT_74, zT_75);
    (void)zT_80;
    return (unsigned int)(1);
    z_bb_8:
    zT_82 = self;
    zT_83 = lhs;
    zF_9665A229_pushExpectedType(zT_82, zT_83);
    zT_85 = self;
    zT_86 = node.child_1;
    zT_88 = zF_54F95822_semanticAnalyzerRes(zT_85, zT_86);
    rhs = zT_88;
    zT_89 = self;
    zF_BC478E78_popExpectedType(zT_89);
    if ((unsigned char)(lhs == (unsigned int)(0))) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_92 = rhs == (unsigned int)(0);
    goto z_bb_11;
    z_bb_10:
    zT_92 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_92) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_96 = "AS0";
    zT_98 = 3;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    as0 = zT_97;
    zT_99 = as0;
    zF_48AC7B3A_markerWrite(zT_99);
    return (unsigned int)(1);
    z_bb_13:
    zT_102 = self;
    zT_103 = node.child_1;
    zT_104 = lhs;
    zT_105 = rhs;
    zT_107 = zF_FFC95E09_errLitSrcType(zT_102, zT_103, zT_104, zT_105);
    eff_src = zT_107;
    zT_108 = self;
    zT_109 = node.child_1;
    zT_110 = eff_src;
    zT_111 = lhs;
    zT_113 = zF_86AAA417_semanticAnalyzerMay(zT_108, zT_109, zT_110, zT_111);
    if (zT_113) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (unsigned int)(1);
    z_bb_15:
    zT_115 = self->registry;
    zT_116 = eff_src;
    zT_117 = lhs;
    zT_119 = zF_683AEB7F_typeRegistryIsAssig(zT_115, zT_116, zT_117);
    if (zT_119) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_120 = self;
    zT_121 = node.child_1;
    zT_122 = eff_src;
    zT_123 = lhs;
    zF_DF7434EB_tryRecordCoercion(zT_120, zT_121, zT_122, zT_123);
    zT_126 = "AS1";
    zT_128 = 3;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    as1 = zT_127;
    zT_129 = as1;
    zF_48AC7B3A_markerWrite(zT_129);
    return lhs;
    z_bb_17:
    zT_131 = "AS2";
    zT_133 = 3;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    as2 = zT_132;
    zT_134 = as2;
    zF_48AC7B3A_markerWrite(zT_134);
    if ((unsigned char)(lhs != (unsigned int)(1))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_138 = node.span_start;
    sp = zT_138;
    zT_140 = node.span_len;
    zT_142 = sp + (unsigned int)((unsigned int)zT_140);
    ep = zT_142;
    zT_144 = "type mismatch in assignment — internal type representations differ; generated code may be incorrect";
    zT_146 = 101;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    tma_msg = zT_145;
    zT_148 = self->registry;
    zT_149 = zT_148->types_items;
    zT_150 = (unsigned int)eff_src;
    zT_151 = zT_149[zT_150];
    zT_152 = zT_151.kind;
    sk = zT_152;
    zT_154 = self->registry;
    zT_155 = zT_154->types_items;
    zT_156 = (unsigned int)lhs;
    zT_157 = zT_155[zT_156];
    zT_158 = zT_157.kind;
    tk = zT_158;
    zT_160 = 1;
    zT_161 = (unsigned char)zT_160;
    level = zT_161;
    zT_162 = self;
    zT_163 = eff_src;
    zT_164 = lhs;
    zT_165 = zF_148F8E19_semanticAnalyzerFnP(zT_162, zT_163, zT_164);
    if (zT_165) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    return (unsigned int)(1);
    z_bb_20:
    zT_166 = 0;
    zT_167 = (unsigned char)zT_166;
    level = zT_167;
    goto z_bb_21;
    z_bb_21:
    zT_168 = self;
    zT_169 = eff_src;
    zT_170 = lhs;
    zT_173 = zF_D728034A_isBShapeMismatch(zT_168, zT_169, zT_170, (unsigned char)(1));
    if (zT_173) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_174 = 0;
    zT_175 = (unsigned char)zT_174;
    level = zT_175;
    goto z_bb_23;
    z_bb_23:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_179 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_26;
    z_bb_25:
    zT_179 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_179) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_184 = self->registry;
    zT_185 = zT_184->eu_items;
    zT_186 = self->registry;
    zT_187 = zT_186->types_items;
    zT_188 = (unsigned int)eff_src;
    zT_189 = zT_187[zT_188];
    zT_190 = zT_189.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_185[zT_191];
    eu_src = zT_192;
    zT_194 = self->registry;
    zT_195 = zT_194->eu_items;
    zT_196 = self->registry;
    zT_197 = zT_196->types_items;
    zT_198 = (unsigned int)lhs;
    zT_199 = zT_197[zT_198];
    zT_200 = zT_199.payload_idx;
    zT_201 = (unsigned int)zT_200;
    zT_202 = zT_195[zT_201];
    eu_tgt = zT_202;
    zT_203 = eu_src.error_set;
    zT_204 = eu_tgt.error_set;
    if ((unsigned char)(zT_203 == zT_204)) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_209 = self->diag;
    zT_210 = level;
    zT_212 = self->source_file_id;
    zT_213 = sp;
    zT_214 = ep;
    zT_215 = tma_msg;
    zT_219 = zF_C82559AC_diagnosticCollector(zT_209, zT_210, (unsigned short)(3000), zT_212, zT_213, zT_214, zT_215);
    di = zT_219;
    zT_220 = self->diag;
    zT_221 = di;
    zT_224 = sk;
    zT_225 = zF_C14453DE_typeKindSrcStr(zT_224);
    zT_222 = zT_225;
    zF_426E1F18_diagnosticCollector(zT_220, zT_221, zT_222);
    (void)self;
    zT_226 = self->diag;
    zT_227 = di;
    zT_230 = tk;
    zT_231 = zF_CC479241_typeKindTgtStr(zT_230);
    zT_228 = zT_231;
    zF_426E1F18_diagnosticCollector(zT_226, zT_227, zT_228);
    (void)self;
    goto z_bb_19;
    z_bb_29:
    zT_206 = 0;
    zT_207 = (unsigned char)zT_206;
    level = zT_207;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
}

/* semanticAnalyzerResolveSwitchExpr */
unsigned int zF_2DB4F186_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_8143F551_AstKind zT_29;
    zT_79FAE712_u64 zT_32 = 0;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_55;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    int zT_61;
    unsigned char* zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65 = 0;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zT_8EED1867_ResolvedTypeTable* zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    zT_38C12417_SemanticAnalyzer* zT_92;
    unsigned int zT_93;
    unsigned int zT_95 = 0;
    unsigned int zT_98;
    unsigned char zT_101;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D155D06D_Type* zT_106;
    unsigned int zT_107;
    zT_D155D06D_Type zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    unsigned char zT_113;
    zT_33EF6BFB_TypeKind zT_114;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_33EF6BFB_TypeKind zT_123;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    unsigned char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_338B7C76_TypeRegistry* zT_143;
    zT_42C2D6BF_EUPayload* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_42C2D6BF_EUPayload zT_147;
    unsigned int zT_148;
    unsigned char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    zT_6B0A7D14_AstStore* zT_161;
    unsigned int zT_162;
    unsigned int zT_164 = 0;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_173;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    int zT_179;
    unsigned char* zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183 = 0;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned char* zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned char* zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    zT_8EED1867_ResolvedTypeTable* zT_201;
    unsigned int zT_202;
    unsigned int zT_206;
    unsigned int zT_211;
    unsigned int zT_213;
    int zT_215;
    unsigned char zT_216;
    int zT_218;
    unsigned int zT_219;
    unsigned int zT_221;
    zT_6B0A7D14_AstStore* zT_225;
    unsigned int zT_226;
    unsigned int zT_230 = 0;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    zT_22A7C88B_AstNode zT_235 = {0};
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned char zT_239;
    int zT_244;
    unsigned char zT_245;
    unsigned char zT_246;
    unsigned char zT_251;
    unsigned char zT_252;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_F85C5DED_DiagnosticCollector* zT_261;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_272 = 0;
    unsigned int zT_275;
    zT_6B0A7D14_AstStore* zT_277;
    unsigned int zT_278;
    unsigned char* zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned int zT_284;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_285;
    unsigned int zT_286;
    unsigned char* zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    unsigned int zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    zT_6B0A7D14_AstStore* zT_293;
    unsigned int zT_294;
    zT_8143F551_AstKind zT_295;
    zT_79FAE712_u64 zT_298 = 0;
    unsigned int zT_302;
    unsigned char zT_305;
    zT_6B0A7D14_AstStore* zT_306;
    unsigned int zT_307;
    unsigned int zT_309 = 0;
    zT_6B0A7D14_AstStore* zT_313;
    unsigned int zT_314;
    unsigned int zT_316 = 0;
    int zT_318;
    unsigned int zT_319;
    zT_6B0A7D14_AstStore* zT_323;
    unsigned int zT_324;
    unsigned int zT_328 = 0;
    zT_6B0A7D14_AstStore* zT_330;
    unsigned int zT_331;
    zT_22A7C88B_AstNode zT_333 = {0};
    zT_8143F551_AstKind zT_335;
    unsigned int zT_336;
    unsigned char* zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    unsigned int zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    zT_8143F551_AstKind zT_343;
    zT_38C12417_SemanticAnalyzer* zT_347;
    unsigned int zT_348;
    unsigned int zT_349 = 0;
    zT_8143F551_AstKind zT_350;
    zT_38C12417_SemanticAnalyzer* zT_354;
    unsigned int zT_355;
    unsigned int zT_356 = 0;
    int zT_357;
    unsigned int zT_359;
    unsigned char zT_360;
    unsigned int zT_366;
    unsigned int zT_368;
    unsigned int zT_370;
    unsigned int zT_371;
    unsigned int zT_373;
    unsigned int zT_374;
    zT_6B0A7D14_AstStore* zT_378;
    unsigned int zT_379;
    zT_22A7C88B_AstNode zT_382 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    unsigned int zT_394 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned int* zT_401;
    unsigned int* zT_402;
    unsigned char zT_408 = 0;
    zT_38C12417_SemanticAnalyzer* zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned char* zT_414;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_415;
    unsigned int zT_416;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_417;
    unsigned int zT_418;
    unsigned char* zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421;
    unsigned int zT_422;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_423;
    zT_21D3708C_U32ToU32Map* zT_430;
    unsigned int zT_431;
    zT_6B0A7D14_AstStore* zT_433;
    unsigned int zT_434;
    unsigned int zT_438 = 0;
    zT_BAEE192E_Opt_10 zT_439 = {0};
    unsigned char zT_440;
    zT_338B7C76_TypeRegistry* zT_443;
    zT_D155D06D_Type* zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    zT_D155D06D_Type zT_447;
    zT_33EF6BFB_TypeKind zT_448;
    zT_338B7C76_TypeRegistry* zT_453;
    zT_54FF90FA_TaggedUnionPayload* zT_454;
    unsigned int zT_455;
    unsigned int zT_456;
    zT_54FF90FA_TaggedUnionPayload zT_457;
    zT_338B7C76_TypeRegistry* zT_459;
    zT_2DF01B61_FieldEntry* zT_460;
    unsigned int zT_461;
    unsigned int zT_464;
    zT_2DF01B61_FieldEntry zT_465;
    unsigned char* zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    unsigned int zT_469;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_470;
    unsigned int zT_471;
    unsigned char* zT_473;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_474;
    unsigned int zT_475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_476;
    unsigned int zT_477;
    unsigned char* zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned int zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    zT_33EF6BFB_TypeKind zT_485;
    unsigned int zT_487;
    unsigned int zT_488;
    zT_38C12417_SemanticAnalyzer* zT_490;
    unsigned int* zT_491;
    unsigned int zT_492;
    unsigned int zT_493;
    unsigned int* zT_494;
    unsigned int zT_495;
    unsigned char zT_496;
    unsigned char* zT_497;
    unsigned int zT_498;
    unsigned int zT_499;
    unsigned char* zT_503;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_504;
    unsigned int zT_505;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_506;
    unsigned int zT_507;
    unsigned char* zT_509;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_510;
    unsigned int zT_511;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_512;
    unsigned int zT_513;
    unsigned char* zT_516;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_517;
    unsigned int zT_518;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_519;
    unsigned int zT_520;
    zT_38C12417_SemanticAnalyzer* zT_521;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned char zT_527;
    zT_6B0A7D14_AstStore* zT_528;
    unsigned int zT_529;
    unsigned int zT_531 = 0;
    zT_6B0A7D14_AstStore* zT_535;
    unsigned int zT_536;
    unsigned int zT_538 = 0;
    int zT_540;
    unsigned int zT_541;
    zT_6B0A7D14_AstStore* zT_545;
    unsigned int zT_546;
    unsigned int zT_550 = 0;
    zT_6B0A7D14_AstStore* zT_552;
    unsigned int zT_553;
    zT_22A7C88B_AstNode zT_555 = {0};
    zT_8143F551_AstKind zT_556;
    zT_38C12417_SemanticAnalyzer* zT_560;
    unsigned int zT_561;
    zT_38C12417_SemanticAnalyzer* zT_562;
    unsigned int zT_563;
    unsigned int zT_564 = 0;
    zT_38C12417_SemanticAnalyzer* zT_565;
    int zT_566;
    unsigned int zT_568;
    unsigned int zT_570;
    unsigned int zT_572;
    zT_6B0A7D14_AstStore* zT_576;
    unsigned int zT_577;
    zT_22A7C88B_AstNode zT_579 = {0};
    zT_8143F551_AstKind zT_580;
    unsigned int zT_581;
    unsigned char* zT_583;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_584;
    unsigned int zT_585;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_586;
    unsigned int zT_587;
    unsigned char* zT_589;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_590;
    unsigned int zT_591;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_592;
    unsigned int zT_593;
    unsigned int zT_595;
    zT_38C12417_SemanticAnalyzer* zT_597;
    unsigned int zT_598;
    unsigned int zT_600 = 0;
    unsigned int zT_601;
    unsigned int zT_603;
    unsigned int* zT_607;
    unsigned int zT_608;
    unsigned int zT_609;
    zT_38C12417_SemanticAnalyzer* zT_610;
    unsigned int zT_611;
    unsigned char zT_612 = 0;
    unsigned char zT_614;
    zT_38C12417_SemanticAnalyzer* zT_617;
    unsigned int zT_618;
    unsigned char* zT_621;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_622;
    unsigned int zT_623;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_624;
    unsigned int zT_625;
    unsigned char* zT_628;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_629;
    unsigned int zT_630;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_631;
    unsigned int zT_632;
    unsigned char* zT_634;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_635;
    unsigned int zT_636;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_637;
    unsigned int zT_638;
    unsigned char* zT_641;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_642;
    unsigned int zT_643;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_644;
    unsigned char* zT_648;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_649;
    unsigned int zT_650;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_651;
    unsigned int zT_652;
    zT_38C12417_SemanticAnalyzer* zT_658;
    unsigned int zT_659 = 0;
    unsigned int zT_661;
    unsigned char zT_664;
    zT_6B0A7D14_AstStore* zT_665;
    unsigned int zT_666;
    zT_22A7C88B_AstNode zT_669 = {0};
    zT_8143F551_AstKind zT_670;
    unsigned char zT_674;
    unsigned char zT_677;
    zT_338B7C76_TypeRegistry* zT_680;
    unsigned int zT_686 = 0;
    unsigned char zT_689;
    unsigned char zT_692;
    zT_0FB7FB13_CoercionKind zT_693;
    zT_338B7C76_TypeRegistry* zT_694;
    unsigned int zT_695;
    unsigned int zT_696;
    zT_0FB7FB13_CoercionKind zT_698 = 0;
    unsigned char zT_699 = 0;
    unsigned int zT_700;
    zT_38C12417_SemanticAnalyzer* zT_701;
    unsigned int zT_702;
    unsigned int zT_703;
    unsigned int zT_704;
    unsigned int zT_706;
    zT_338B7C76_TypeRegistry* zT_708;
    unsigned int zT_709;
    unsigned int zT_710;
    zT_0FB7FB13_CoercionKind zT_712 = 0;
    zT_38C12417_SemanticAnalyzer* zT_716;
    unsigned int zT_717;
    unsigned int zT_718;
    unsigned int zT_719;
    zT_338B7C76_TypeRegistry* zT_721;
    unsigned int zT_722;
    unsigned int zT_723;
    zT_0FB7FB13_CoercionKind zT_725 = 0;
    zT_38C12417_SemanticAnalyzer* zT_729;
    unsigned int zT_730;
    unsigned int zT_731;
    unsigned int zT_732;
    unsigned int zT_733;
    unsigned int zT_735;
    zT_338B7C76_TypeRegistry* zT_736;
    unsigned int zT_737;
    unsigned char zT_739 = 0;
    unsigned int zT_740;
    unsigned char zT_743;
    unsigned char* zT_747;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_748;
    unsigned int zT_749;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_750;
    unsigned char* zT_754;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_755;
    unsigned int zT_756;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_758;
    unsigned char* zT_760;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_761;
    unsigned int zT_762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_763;
    unsigned int zT_764;
    unsigned char* zT_766;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_767;
    unsigned int zT_768;
    zT_338B7C76_TypeRegistry* zT_770;
    zT_D155D06D_Type* zT_771;
    unsigned int zT_772;
    zT_D155D06D_Type zT_773;
    zT_33EF6BFB_TypeKind zT_774;
    unsigned int zT_775;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_776;
    unsigned int zT_777;
    unsigned char* zT_779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_780;
    unsigned int zT_781;
    zT_338B7C76_TypeRegistry* zT_783;
    zT_D155D06D_Type* zT_784;
    unsigned int zT_785;
    zT_D155D06D_Type zT_786;
    zT_33EF6BFB_TypeKind zT_787;
    unsigned int zT_788;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_789;
    unsigned int zT_790;
    unsigned char* zT_792;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_793;
    unsigned int zT_794;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_795;
    unsigned int zT_796;
    unsigned char* zT_799;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_800;
    unsigned int zT_801;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_802;
    unsigned int zT_803;
    unsigned char* zT_806;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_807;
    unsigned int zT_808;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_809;
    unsigned char zT_811;
    unsigned char* zT_814;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_815;
    unsigned int zT_816;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_817;
    unsigned char* zT_821;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_822;
    unsigned int zT_823;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_824;
    unsigned int zT_825;
    zT_8EED1867_ResolvedTypeTable* zT_826;
    unsigned int zT_827;
    int zT_831;
    unsigned int zT_833;
    unsigned int zT_839;
    zT_8EED1867_ResolvedTypeTable* zT_840;
    unsigned int zT_841;
    unsigned int zT_842;
    unsigned char* zT_845;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_846;
    unsigned int zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    unsigned int zT_849;
    unsigned char* zT_851;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_852;
    unsigned int zT_853;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_854;
    unsigned int zT_855;
    unsigned int zT_856;
    zT_8F083A69_Slice_zT_0B42B2F8_u se;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swi_dm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_m;
    zT_5A26C2ED_Arr_unsigned_char_1 sep_b;
    unsigned int sep_l;
    unsigned int sep_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_nl;
    unsigned int cond_type;
    unsigned int cond_es;
    zT_D155D06D_Type cond_ty;
    unsigned int prongs_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_nl;
    zT_42C2D6BF_EUPayload cond_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pr0_b;
    unsigned int pr0_l;
    unsigned int pr0_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_nl;
    unsigned int unified;
    unsigned int unified_node;
    unsigned char has_else;
    unsigned int i;
    unsigned int sw_base;
    unsigned int prong_i;
    zT_22A7C88B_AstNode prong;
    unsigned int prong_scope_saved;
    zT_8F083A69_Slice_zT_0B42B2F8_u swec_msg;
    unsigned int pct;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppt_m;
    unsigned int case_n;
    unsigned int ci;
    unsigned int case_i;
    zT_22A7C88B_AstNode case_node;
    unsigned int cc_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_m;
    unsigned int cap_name;
    unsigned int sp_ns;
    unsigned int sp_ne;
    zT_22A7C88B_AstNode sp_body;
    unsigned int sp_arrow;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_lm;
    zT_BAEE192E_Opt_10 ev;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_rm;
    unsigned int idx;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_tm;
    unsigned int es_case_n;
    unsigned int es_ci;
    unsigned int pbd_b0;
    unsigned int pbd_k0;
    unsigned int es_case_i;
    zT_22A7C88B_AstNode es_case_node;
    zT_22A7C88B_AstNode pbd_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_km;
    unsigned int saved_tu;
    unsigned int bt;
    unsigned int wi;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_fm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_tm;
    unsigned int sw_exp0;
    unsigned int sw_peer;
    unsigned int unum;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_um;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_tk_m;
    unsigned int mix_tk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_uk_m;
    unsigned int mix_uk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_cd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_b_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_ni_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_tm;
    zT_2 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_2 + (unsigned int)(1));
    zT_6 = "SE";
    zT_8 = 2;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    se = zT_7;
    zT_9 = se;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    node = zT_14;
    zT_16 = "SWI:n";
    zT_18 = 5;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    swu_im = zT_17;
    zT_19 = swu_im;
    zT_20 = node_idx;
    zF_C914CB83_markerWriteInt(zT_19, zT_20);
    zT_22 = "SWI:p";
    zT_24 = 5;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    swu_pm = zT_23;
    zT_25 = swu_pm;
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_29 = node.kind;
    zT_32 = zF_0E4E10C6_astStoreNodePayload(zT_27, zT_28, zT_29);
    zF_C914CB83_markerWriteInt(zT_25, (unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_32 & (zT_79FAE712_u64)(4294967295u))));
    zT_37 = "SWI:d";
    zT_39 = 5;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    swi_dm = zT_38;
    zT_40 = swi_dm;
    zT_41 = self->switch_depth;
    zF_C914CB83_markerWriteInt(zT_40, zT_41);
    zT_43 = self->store;
    zT_44 = node_idx;
    zT_46 = zF_8BA26B9E_astStoreNodePayload(zT_43, zT_44);
    if ((unsigned char)(zT_46 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_50 = "P0: n";
    zT_52 = 5;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    sep_m = zT_51;
    zT_53 = sep_m;
    zF_48AC7B3A_markerWrite(zT_53);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_55[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        sep_b[_i] = zT_55[_i];
        _i++;
    }
}
    zT_57 = node_idx;
    zT_61 = 0;
    zT_62 = (unsigned char*)((unsigned char*)sep_b) + zT_61;
    zT_63 = (unsigned int)(10) - zT_61;
    zT_64.ptr = zT_62;
    zT_64.len = zT_63;
    zT_58 = zT_64;
    zT_65 = zF_A7504564_itoa(zT_57, zT_58);
    sep_l = zT_65;
    zT_69 = (unsigned int)(9) - (unsigned int)((unsigned int)sep_l);
    sep_s = zT_69;
    zT_74 = (unsigned char*)((unsigned char*)sep_b) + sep_s;
    zT_75 = (unsigned int)(9) - sep_s;
    zT_76.ptr = zT_74;
    zT_76.len = zT_75;
    zT_70 = zT_76;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_78 = "\n";
    zT_80 = 1;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    sep_nl = zT_79;
    zT_81 = sep_nl;
    zF_48AC7B3A_markerWrite(zT_81);
    zT_82 = self->type_table;
    zT_83 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_82, zT_83, (unsigned int)(1));
    zT_87 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_87 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_2:
    zT_92 = self;
    zT_93 = node.child_0;
    zT_95 = zF_54F95822_semanticAnalyzerRes(zT_92, zT_93);
    cond_type = zT_95;
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_98 = 0;
    cond_es = zT_98;
    if ((unsigned char)(cond_type != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_101 = cond_type != (unsigned int)(1);
    goto z_bb_5;
    z_bb_4:
    zT_101 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_101) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_105 = self->registry;
    zT_106 = zT_105->types_items;
    zT_107 = (unsigned int)cond_type;
    zT_108 = zT_106[zT_107];
    cond_ty = zT_108;
    zT_109 = cond_ty.kind;
    if ((unsigned char)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_9; else goto z_bb_8;
    z_bb_7:
    zT_161 = self->store;
    zT_162 = node_idx;
    zT_164 = zF_152E19CB_astStoreNodeExtraCh(zT_161, zT_162);
    prongs_n = zT_164;
    if ((unsigned char)(prongs_n == (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_8:
    zT_114 = cond_ty.kind;
    zT_113 = zT_114 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_10;
    z_bb_9:
    zT_113 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_113) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    self->current_switch_cond_tu = cond_type;
    zT_119 = "Z";
    zT_121 = 1;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    rs = zT_120;
    zT_122 = rs;
    zF_48AC7B3A_markerWrite(zT_122);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_7;
    z_bb_13:
    zT_123 = cond_ty.kind;
    if ((unsigned char)(zT_123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cond_es = cond_type;
    zT_128 = "SWES:e";
    zT_130 = 6;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    swes_m = zT_129;
    zT_131 = swes_m;
    zT_132 = cond_es;
    zF_C914CB83_markerWriteInt(zT_131, zT_132);
    zT_134 = "\n";
    zT_136 = 1;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    swes_nl = zT_135;
    zT_137 = swes_nl;
    zF_48AC7B3A_markerWrite(zT_137);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_138 = cond_ty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_143 = self->registry;
    zT_144 = zT_143->eu_items;
    zT_145 = cond_ty.payload_idx;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zT_144[zT_146];
    cond_eu = zT_147;
    zT_148 = cond_eu.error_set;
    cond_es = zT_148;
    zT_150 = "SWEU:e";
    zT_152 = 6;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    sweu_m = zT_151;
    zT_153 = sweu_m;
    zT_154 = cond_es;
    zF_C914CB83_markerWriteInt(zT_153, zT_154);
    zT_156 = "\n";
    zT_158 = 1;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    sweu_nl = zT_157;
    zT_159 = sweu_nl;
    zF_48AC7B3A_markerWrite(zT_159);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_168 = "PL0:n";
    zT_170 = 5;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    pr0_m = zT_169;
    zT_171 = pr0_m;
    zF_48AC7B3A_markerWrite(zT_171);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_173[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pr0_b[_i] = zT_173[_i];
        _i++;
    }
}
    zT_175 = node_idx;
    zT_179 = 0;
    zT_180 = (unsigned char*)((unsigned char*)pr0_b) + zT_179;
    zT_181 = (unsigned int)(10) - zT_179;
    zT_182.ptr = zT_180;
    zT_182.len = zT_181;
    zT_176 = zT_182;
    zT_183 = zF_A7504564_itoa(zT_175, zT_176);
    pr0_l = zT_183;
    zT_187 = (unsigned int)(9) - (unsigned int)((unsigned int)pr0_l);
    pr0_s = zT_187;
    zT_192 = (unsigned char*)((unsigned char*)pr0_b) + pr0_s;
    zT_193 = (unsigned int)(9) - pr0_s;
    zT_194.ptr = zT_192;
    zT_194.len = zT_193;
    zT_188 = zT_194;
    zF_48AC7B3A_markerWrite(zT_188);
    zT_196 = "\n";
    zT_198 = 1;
    zT_197.ptr = zT_196;
    zT_197.len = zT_198;
    pr0_nl = zT_197;
    zT_199 = pr0_nl;
    zF_48AC7B3A_markerWrite(zT_199);
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_201 = self->type_table;
    zT_202 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_201, zT_202, (unsigned int)(1));
    zT_206 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_206 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_20:
    zT_211 = 0;
    unified = zT_211;
    zT_213 = 0;
    unified_node = zT_213;
    zT_215 = 0;
    zT_216 = (unsigned char)zT_215;
    has_else = zT_216;
    zT_218 = 0;
    zT_219 = (unsigned int)zT_218;
    i = zT_219;
    zT_221 = self->stmt_work_len;
    sw_base = zT_221;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(i < (unsigned int)((unsigned int)prongs_n))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_225 = self->store;
    zT_226 = node_idx;
    zT_230 = zF_B10B1BC1_astStoreNodeExtraCh(zT_225, zT_226, (unsigned int)((unsigned int)i));
    prong_i = zT_230;
    zT_232 = self->store;
    zT_233 = prong_i;
    zT_235 = zF_FCDD1D35_astStoreNodeAt(zT_232, zT_233);
    prong = zT_235;
    zT_237 = self->local_decl_count;
    zT_238 = (unsigned int)zT_237;
    prong_scope_saved = zT_238;
    zT_239 = prong.flags;
    if ((unsigned char)((unsigned char)(zT_239 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    self->current_switch_cond_tu = (unsigned int)(0);
    if ((unsigned char)(has_else == (unsigned char)(0))) goto z_bb_126; else goto z_bb_127;
    z_bb_24:
    zT_831 = 1;
    zT_833 = i + (unsigned int)((unsigned int)zT_831);
    i = zT_833;
    goto z_bb_21;
    z_bb_25:
    zT_244 = 1;
    zT_245 = (unsigned char)zT_244;
    has_else = zT_245;
    goto z_bb_26;
    z_bb_26:
    zT_246 = prong.flags;
    if ((unsigned char)((unsigned char)(zT_246 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_252 = prong.flags;
    zT_251 = (unsigned char)(zT_252 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_29;
    z_bb_28:
    zT_251 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_251) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_258 = "switch else-prong capture (else => |capture|) is not supported";
    zT_260 = 62;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    swec_msg = zT_259;
    zT_261 = self->diag;
    zT_264 = self->source_file_id;
    zT_265 = node_idx;
    zT_266 = node_idx;
    zT_267 = swec_msg;
    zT_272 = zF_C82559AC_diagnosticCollector(zT_261, (unsigned char)(0), (unsigned short)(3001), zT_264, zT_265, zT_266, zT_267);
    (void)zT_272;
    return (unsigned int)(1);
    z_bb_31:
    zT_275 = self->current_switch_cond_tu;
    pct = zT_275;
    zT_277 = self->store;
    zT_278 = prong_i;
    (void)zF_8BA26B9E_astStoreNodePayload(zT_277, zT_278);
    zT_282 = "PCT:C";
    zT_284 = 5;
    zT_283.ptr = zT_282;
    zT_283.len = zT_284;
    pct_m2 = zT_283;
    zT_285 = pct_m2;
    zT_286 = pct;
    zF_C914CB83_markerWriteInt(zT_285, zT_286);
    zT_288 = "PCT:P";
    zT_290 = 5;
    zT_289.ptr = zT_288;
    zT_289.len = zT_290;
    ppt_m = zT_289;
    zT_291 = ppt_m;
    zT_293 = self->store;
    zT_294 = prong_i;
    zT_295 = prong.kind;
    zT_298 = zF_0E4E10C6_astStoreNodePayload(zT_293, zT_294, zT_295);
    zF_C914CB83_markerWriteInt(zT_291, (unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_298 & (zT_79FAE712_u64)(4294967295u))));
    zT_302 = self->current_switch_cond_tu;
    if ((unsigned char)(zT_302 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_306 = self->store;
    zT_307 = prong_i;
    zT_309 = zF_8BA26B9E_astStoreNodePayload(zT_306, zT_307);
    zT_305 = zT_309 != (unsigned int)(0);
    goto z_bb_34;
    z_bb_33:
    zT_305 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_305) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_313 = self->store;
    zT_314 = prong_i;
    zT_316 = zF_152E19CB_astStoreNodeExtraCh(zT_313, zT_314);
    case_n = zT_316;
    zT_318 = 0;
    zT_319 = (unsigned int)zT_318;
    ci = zT_319;
    goto z_bb_37;
    z_bb_36:
    if ((unsigned char)(cond_es != (unsigned int)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_37:
    if ((unsigned char)(ci < (unsigned int)((unsigned int)case_n))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_323 = self->store;
    zT_324 = prong_i;
    zT_328 = zF_B10B1BC1_astStoreNodeExtraCh(zT_323, zT_324, (unsigned int)((unsigned int)ci));
    case_i = zT_328;
    zT_330 = self->store;
    zT_331 = case_i;
    zT_333 = zF_FCDD1D35_astStoreNodeAt(zT_330, zT_331);
    case_node = zT_333;
    zT_335 = case_node.kind;
    zT_336 = (unsigned int)zT_335;
    cc_val = zT_336;
    zT_338 = "CC:K";
    zT_340 = 4;
    zT_339.ptr = zT_338;
    zT_339.len = zT_340;
    cc_m = zT_339;
    zT_341 = cc_m;
    zT_342 = cc_val;
    zF_C914CB83_markerWriteInt(zT_341, zT_342);
    zT_343 = case_node.kind;
    if ((unsigned char)(zT_343 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_41; else goto z_bb_43;
    z_bb_39:
    zT_360 = prong.flags;
    if ((unsigned char)((unsigned char)(zT_360 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_40:
    zT_357 = 1;
    zT_359 = ci + (unsigned int)((unsigned int)zT_357);
    ci = zT_359;
    goto z_bb_37;
    z_bb_41:
    zT_347 = self;
    zT_348 = case_i;
    zT_349 = zF_8C008E53_semanticAnalyzerRes(zT_347, zT_348);
    (void)zT_349;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_350 = case_node.kind;
    if ((unsigned char)(zT_350 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_354 = self;
    zT_355 = case_i;
    zT_356 = zF_8C008E53_semanticAnalyzerRes(zT_354, zT_355);
    (void)zT_356;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_366 = prong.child_1;
    cap_name = zT_366;
    zT_368 = prong.span_start;
    sp_ns = zT_368;
    zT_370 = prong.span_start;
    zT_371 = prong.span_len;
    zT_373 = zT_370 + (unsigned int)((unsigned int)zT_371);
    sp_ne = zT_373;
    zT_374 = prong.child_0;
    if ((unsigned char)(zT_374 != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_36;
    z_bb_48:
    zT_378 = self->store;
    zT_379 = prong.child_0;
    zT_382 = zF_FCDD1D35_astStoreNodeAt(zT_378, zT_379);
    sp_body = zT_382;
    zT_384 = self->diag;
    zT_385 = self->source_file_id;
    zT_386 = prong.span_start;
    zT_387 = sp_body.span_start;
    zT_394 = zF_DFE292F2_diagnosticCollector(zT_384, zT_385, zT_386, zT_387, (unsigned char)(62));
    sp_arrow = zT_394;
    if ((unsigned char)(sp_arrow != (unsigned int)(4294967295u))) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    zT_409 = self;
    zT_410 = cap_name;
    zT_411 = sp_ns;
    zT_412 = sp_ne;
    zF_C999EE08_semanticAnalyzerChe(zT_409, zT_410, zT_411, zT_412);
    zT_414 = "SCE:p";
    zT_416 = 5;
    zT_415.ptr = zT_414;
    zT_415.len = zT_416;
    sce_pm = zT_415;
    zT_417 = sce_pm;
    zT_418 = cap_name;
    zF_C914CB83_markerWriteInt(zT_417, zT_418);
    zT_420 = "SCE:l";
    zT_422 = 5;
    zT_421.ptr = zT_420;
    zT_421.len = zT_422;
    sce_lm = zT_421;
    zT_423 = sce_lm;
    zF_C914CB83_markerWriteInt(zT_423, (unsigned int)((unsigned int)case_n));
    if ((unsigned char)((unsigned int)((unsigned int)case_n) > (unsigned int)(0))) goto z_bb_52; else goto z_bb_54;
    z_bb_50:
    zT_397 = self->diag;
    zT_398 = self->source_file_id;
    zT_399 = sp_arrow;
    zT_400 = sp_body.span_start;
    zT_401 = &sp_ns;
    zT_402 = &sp_ne;
    zT_408 = zF_BCEBD9F2_diagnosticCollector(zT_397, zT_398, zT_399, zT_400, zT_401, zT_402);
    (void)zT_408;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_49;
    z_bb_52:
    zT_430 = self->enum_value_table;
    zT_433 = self->store;
    zT_434 = prong_i;
    zT_438 = zF_B10B1BC1_astStoreNodeExtraCh(zT_433, zT_434, (unsigned int)(0));
    zT_431 = zT_438;
    zT_439 = zF_F3EE5998_u32ToU32MapGet(zT_430, zT_431);
    ev = zT_439;
    zT_440 = ev.has_value;
    if (zT_440) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_47;
    z_bb_54:
    zT_516 = "SCE:R";
    zT_518 = 5;
    zT_517.ptr = zT_516;
    zT_517.len = zT_518;
    sce_rm = zT_517;
    zT_519 = sce_rm;
    zT_520 = cap_name;
    zF_C914CB83_markerWriteInt(zT_519, zT_520);
    zT_521 = self;
    zT_522 = cap_name;
    zT_523 = self->current_switch_cond_tu;
    zF_7BD72017_registerLocalDecl(zT_521, zT_522, zT_523);
    goto z_bb_53;
    z_bb_55:
    idx = ev.value;
    zT_443 = self->registry;
    zT_444 = zT_443->types_items;
    zT_445 = self->current_switch_cond_tu;
    zT_446 = (unsigned int)zT_445;
    zT_447 = zT_444[zT_446];
    tu_ty = zT_447;
    zT_448 = tu_ty.kind;
    if ((unsigned char)(zT_448 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_453 = self->registry;
    zT_454 = zT_453->tu_items;
    zT_455 = tu_ty.payload_idx;
    zT_456 = (unsigned int)zT_455;
    zT_457 = zT_454[zT_456];
    tp = zT_457;
    zT_459 = self->registry;
    zT_460 = zT_459->fe_items;
    zT_461 = tp.fields_start;
    zT_464 = (unsigned int)((unsigned int)zT_461) + (unsigned int)((unsigned int)idx);
    zT_465 = zT_460[zT_464];
    fe = zT_465;
    zT_467 = "SCFE:n";
    zT_469 = 6;
    zT_468.ptr = zT_467;
    zT_468.len = zT_469;
    scfe_nm = zT_468;
    zT_470 = scfe_nm;
    zT_471 = cap_name;
    zF_C914CB83_markerWriteInt(zT_470, zT_471);
    zT_473 = "SCFE:t";
    zT_475 = 6;
    zT_474.ptr = zT_473;
    zT_474.len = zT_475;
    scfe_tm = zT_474;
    zT_476 = scfe_tm;
    zT_477 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_476, zT_477);
    zT_480 = "SCFE:k";
    zT_482 = 6;
    zT_481.ptr = zT_480;
    zT_481.len = zT_482;
    scfe_km = zT_481;
    zT_483 = scfe_km;
    zT_485 = tu_ty.kind;
    zF_C914CB83_markerWriteInt(zT_483, (unsigned int)((unsigned int)zT_485));
    zT_487 = self->local_decl_count;
    zT_488 = self->local_decl_cap;
    if ((unsigned char)(zT_487 >= zT_488)) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    zT_490 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_490);
    goto z_bb_60;
    z_bb_60:
    zT_491 = self->local_decl_names;
    zT_492 = self->local_decl_count;
    zT_491[zT_492] = cap_name;
    zT_493 = fe.type_id;
    zT_494 = self->local_decl_types;
    zT_495 = self->local_decl_count;
    zT_494[zT_495] = zT_493;
    zT_496 = 1;
    zT_497 = self->local_decl_consts;
    zT_498 = self->local_decl_count;
    zT_497[zT_498] = zT_496;
    zT_499 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_499 + (unsigned int)(1));
    zT_503 = "SCAX:N";
    zT_505 = 6;
    zT_504.ptr = zT_503;
    zT_504.len = zT_505;
    scax_m = zT_504;
    zT_506 = scax_m;
    zT_507 = cap_name;
    zF_C914CB83_markerWriteInt(zT_506, zT_507);
    zT_509 = "SCAX:T";
    zT_511 = 6;
    zT_510.ptr = zT_509;
    zT_510.len = zT_511;
    scax_tm = zT_510;
    zT_512 = scax_tm;
    zT_513 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_512, zT_513);
    goto z_bb_58;
    z_bb_61:
    zT_528 = self->store;
    zT_529 = prong_i;
    zT_531 = zF_8BA26B9E_astStoreNodePayload(zT_528, zT_529);
    zT_527 = zT_531 != (unsigned int)(0);
    goto z_bb_63;
    z_bb_62:
    zT_527 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_527) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_535 = self->store;
    zT_536 = prong_i;
    zT_538 = zF_152E19CB_astStoreNodeExtraCh(zT_535, zT_536);
    es_case_n = zT_538;
    zT_540 = 0;
    zT_541 = (unsigned int)zT_540;
    es_ci = zT_541;
    goto z_bb_66;
    z_bb_65:
    zT_570 = prong.child_0;
    pbd_b0 = zT_570;
    zT_572 = 0;
    pbd_k0 = zT_572;
    if ((unsigned char)(pbd_b0 != (unsigned int)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_66:
    if ((unsigned char)(es_ci < (unsigned int)((unsigned int)es_case_n))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_545 = self->store;
    zT_546 = prong_i;
    zT_550 = zF_B10B1BC1_astStoreNodeExtraCh(zT_545, zT_546, (unsigned int)((unsigned int)es_ci));
    es_case_i = zT_550;
    zT_552 = self->store;
    zT_553 = es_case_i;
    zT_555 = zF_FCDD1D35_astStoreNodeAt(zT_552, zT_553);
    es_case_node = zT_555;
    zT_556 = es_case_node.kind;
    if ((unsigned char)(zT_556 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_70; else goto z_bb_71;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_566 = 1;
    zT_568 = es_ci + (unsigned int)((unsigned int)zT_566);
    es_ci = zT_568;
    goto z_bb_66;
    z_bb_70:
    zT_560 = self;
    zT_561 = cond_es;
    zF_9665A229_pushExpectedType(zT_560, zT_561);
    zT_562 = self;
    zT_563 = es_case_i;
    zT_564 = zF_54F95822_semanticAnalyzerRes(zT_562, zT_563);
    (void)zT_564;
    zT_565 = self;
    zF_BC478E78_popExpectedType(zT_565);
    goto z_bb_71;
    z_bb_71:
    goto z_bb_69;
    z_bb_72:
    zT_576 = self->store;
    zT_577 = pbd_b0;
    zT_579 = zF_FCDD1D35_astStoreNodeAt(zT_576, zT_577);
    pbd_n = zT_579;
    zT_580 = pbd_n.kind;
    zT_581 = (unsigned int)zT_580;
    pbd_k0 = zT_581;
    goto z_bb_73;
    z_bb_73:
    zT_583 = "PBD:N";
    zT_585 = 5;
    zT_584.ptr = zT_583;
    zT_584.len = zT_585;
    pbd_nm = zT_584;
    zT_586 = pbd_nm;
    zT_587 = pbd_b0;
    zF_C914CB83_markerWriteInt(zT_586, zT_587);
    zT_589 = "PBD:K";
    zT_591 = 5;
    zT_590.ptr = zT_589;
    zT_590.len = zT_591;
    pbd_km = zT_590;
    zT_592 = pbd_km;
    zT_593 = pbd_k0;
    zF_C914CB83_markerWriteInt(zT_592, zT_593);
    zT_595 = self->current_switch_cond_tu;
    saved_tu = zT_595;
    zT_597 = self;
    zT_598 = prong.child_0;
    zT_600 = zF_54F95822_semanticAnalyzerRes(zT_597, zT_598);
    bt = zT_600;
    self->current_switch_cond_tu = saved_tu;
    goto z_bb_74;
    z_bb_74:
    zT_601 = self->stmt_work_len;
    if ((unsigned char)(zT_601 > sw_base)) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_603 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_603 - (unsigned int)(1));
    zT_607 = self->stmt_work_items;
    zT_608 = self->stmt_work_len;
    zT_609 = zT_607[zT_608];
    wi = zT_609;
    zT_610 = self;
    zT_611 = wi;
    zT_612 = zF_2FC8BE84_semanticAnalyzerPop(zT_610, zT_611);
    if ((unsigned char)(!zT_612)) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    self->local_decl_count = (unsigned int)((unsigned int)prong_scope_saved);
    zT_621 = "PCT:n";
    zT_623 = 5;
    zT_622.ptr = zT_621;
    zT_622.len = zT_623;
    pct_m = zT_622;
    zT_624 = pct_m;
    zT_625 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_624, zT_625);
    zT_628 = "PCT:b";
    zT_630 = 5;
    zT_629.ptr = zT_628;
    zT_629.len = zT_630;
    pct_bm = zT_629;
    zT_631 = pct_bm;
    zT_632 = bt;
    zF_C914CB83_markerWriteInt(zT_631, zT_632);
    zT_634 = "PCT:f";
    zT_636 = 5;
    zT_635.ptr = zT_634;
    zT_635.len = zT_636;
    pct_fm = zT_635;
    zT_637 = pct_fm;
    zT_638 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_637, zT_638);
    zT_641 = "SWPB:i";
    zT_643 = 6;
    zT_642.ptr = zT_641;
    zT_642.len = zT_643;
    swpb_im = zT_642;
    zT_644 = swpb_im;
    zF_C914CB83_markerWriteInt(zT_644, (unsigned int)((unsigned int)i));
    zT_648 = "SWPB:t";
    zT_650 = 6;
    zT_649.ptr = zT_648;
    zT_649.len = zT_650;
    swpb_tm = zT_649;
    zT_651 = swpb_tm;
    zT_652 = bt;
    zF_C914CB83_markerWriteInt(zT_651, zT_652);
    if ((unsigned char)(bt == (unsigned int)(3))) goto z_bb_83; else goto z_bb_85;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_614 = wi != (unsigned int)(0);
    goto z_bb_80;
    z_bb_79:
    zT_614 = 0;
    goto z_bb_80;
    z_bb_80:
    if (zT_614) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_617 = self;
    zT_618 = wi;
    zF_10A0DC35_semanticAnalyzerRes(zT_617, zT_618);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_77;
    z_bb_83:
    goto z_bb_84;
    z_bb_84:
    goto z_bb_24;
    z_bb_85:
    if ((unsigned char)(unified == (unsigned int)(0))) goto z_bb_86; else goto z_bb_88;
    z_bb_86:
    zT_658 = self;
    zT_659 = zF_4DE7C2BC_topExpectedType(zT_658);
    sw_exp0 = zT_659;
    sw_peer = sw_exp0;
    zT_661 = prong.child_0;
    if ((unsigned char)(zT_661 != (unsigned int)(0))) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    goto z_bb_84;
    z_bb_88:
    if ((unsigned char)(bt == unified)) goto z_bb_109; else goto z_bb_111;
    z_bb_89:
    zT_665 = self->store;
    zT_666 = prong.child_0;
    zT_669 = zF_FCDD1D35_astStoreNodeAt(zT_665, zT_666);
    zT_670 = zT_669.kind;
    zT_664 = zT_670 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_91;
    z_bb_90:
    zT_664 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_664) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    if ((unsigned char)(sw_exp0 == (unsigned int)(0))) goto z_bb_96; else goto z_bb_95;
    z_bb_93:
    zT_674 = 0;
    goto z_bb_94;
    z_bb_94:
    if (zT_674) goto z_bb_98; else goto z_bb_99;
    z_bb_95:
    zT_677 = sw_exp0 == (unsigned int)(1);
    goto z_bb_97;
    z_bb_96:
    zT_677 = 1;
    goto z_bb_97;
    z_bb_97:
    zT_674 = zT_677;
    goto z_bb_94;
    z_bb_98:
    zT_680 = self->registry;
    zT_686 = zF_8FC81A87_typeRegistryGetOrCr(zT_680, (unsigned int)(8), (unsigned char)(1));
    sw_peer = zT_686;
    goto z_bb_99;
    z_bb_99:
    if ((unsigned char)(sw_peer != (unsigned int)(0))) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_689 = sw_peer != (unsigned int)(1);
    goto z_bb_102;
    z_bb_101:
    zT_689 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_689) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_694 = self->registry;
    zT_695 = bt;
    zT_696 = sw_peer;
    zT_698 = zF_713658BF_classifyCoercion(zT_694, zT_695, zT_696);
    zT_693 = zT_698;
    zT_699 = zF_71304A07_isStringLiteralSlic(zT_693);
    zT_692 = zT_699;
    goto z_bb_105;
    z_bb_104:
    zT_692 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_692) goto z_bb_106; else goto z_bb_108;
    z_bb_106:
    unified = sw_peer;
    zT_700 = prong.child_0;
    unified_node = zT_700;
    zT_701 = self;
    zT_702 = prong.child_0;
    zT_703 = bt;
    zT_704 = sw_peer;
    zF_DF7434EB_tryRecordCoercion(zT_701, zT_702, zT_703, zT_704);
    goto z_bb_107;
    z_bb_107:
    goto z_bb_87;
    z_bb_108:
    unified = bt;
    zT_706 = prong.child_0;
    unified_node = zT_706;
    goto z_bb_107;
    z_bb_109:
    goto z_bb_110;
    z_bb_110:
    goto z_bb_87;
    z_bb_111:
    zT_708 = self->registry;
    zT_709 = bt;
    zT_710 = unified;
    zT_712 = zF_713658BF_classifyCoercion(zT_708, zT_709, zT_710);
    if ((unsigned char)(zT_712 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_112; else goto z_bb_114;
    z_bb_112:
    zT_716 = self;
    zT_717 = prong.child_0;
    zT_718 = bt;
    zT_719 = unified;
    zF_DF7434EB_tryRecordCoercion(zT_716, zT_717, zT_718, zT_719);
    goto z_bb_113;
    z_bb_113:
    goto z_bb_110;
    z_bb_114:
    zT_721 = self->registry;
    zT_722 = unified;
    zT_723 = bt;
    zT_725 = zF_713658BF_classifyCoercion(zT_721, zT_722, zT_723);
    if ((unsigned char)(zT_725 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_115; else goto z_bb_117;
    z_bb_115:
    zT_729 = self;
    zT_730 = unified_node;
    zT_731 = unified;
    zT_732 = bt;
    zF_DF7434EB_tryRecordCoercion(zT_729, zT_730, zT_731, zT_732);
    unified = bt;
    zT_733 = prong.child_0;
    unified_node = zT_733;
    goto z_bb_116;
    z_bb_116:
    goto z_bb_113;
    z_bb_117:
    zT_735 = 0;
    unum = zT_735;
    zT_736 = self->registry;
    zT_737 = bt;
    zT_739 = zF_3087E0A5_typeRegistryIsNumer(zT_736, zT_737);
    if (zT_739) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_740 = 1;
    unum = zT_740;
    goto z_bb_119;
    z_bb_119:
    if ((unsigned char)(unified == (unsigned int)(19))) goto z_bb_120; else goto z_bb_121;
    z_bb_120:
    zT_743 = unum != (unsigned int)(0);
    goto z_bb_122;
    z_bb_121:
    zT_743 = 0;
    goto z_bb_122;
    z_bb_122:
    if (zT_743) goto z_bb_123; else goto z_bb_125;
    z_bb_123:
    unified = bt;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_116;
    z_bb_125:
    zT_747 = "MIX:P";
    zT_749 = 5;
    zT_748.ptr = zT_747;
    zT_748.len = zT_749;
    mix_pm = zT_748;
    zT_750 = mix_pm;
    zF_C914CB83_markerWriteInt(zT_750, (unsigned int)((unsigned int)i));
    zT_754 = "MIX:U";
    zT_756 = 5;
    zT_755.ptr = zT_754;
    zT_755.len = zT_756;
    mix_um = zT_755;
    zT_757 = mix_um;
    zT_758 = unified;
    zF_C914CB83_markerWriteInt(zT_757, zT_758);
    zT_760 = "MIX:B";
    zT_762 = 5;
    zT_761.ptr = zT_760;
    zT_761.len = zT_762;
    mix_bm = zT_761;
    zT_763 = mix_bm;
    zT_764 = bt;
    zF_C914CB83_markerWriteInt(zT_763, zT_764);
    zT_766 = "MIX:tk";
    zT_768 = 6;
    zT_767.ptr = zT_766;
    zT_767.len = zT_768;
    mix_tk_m = zT_767;
    zT_770 = self->registry;
    zT_771 = zT_770->types_items;
    zT_772 = (unsigned int)bt;
    zT_773 = zT_771[zT_772];
    zT_774 = zT_773.kind;
    zT_775 = (unsigned int)zT_774;
    mix_tk_v = zT_775;
    zT_776 = mix_tk_m;
    zT_777 = mix_tk_v;
    zF_C914CB83_markerWriteInt(zT_776, zT_777);
    zT_779 = "MIX:uk";
    zT_781 = 6;
    zT_780.ptr = zT_779;
    zT_780.len = zT_781;
    mix_uk_m = zT_780;
    zT_783 = self->registry;
    zT_784 = zT_783->types_items;
    zT_785 = (unsigned int)unified;
    zT_786 = zT_784[zT_785];
    zT_787 = zT_786.kind;
    zT_788 = (unsigned int)zT_787;
    mix_uk_v = zT_788;
    zT_789 = mix_uk_m;
    zT_790 = mix_uk_v;
    zF_C914CB83_markerWriteInt(zT_789, zT_790);
    zT_792 = "MIX:cd";
    zT_794 = 6;
    zT_793.ptr = zT_792;
    zT_793.len = zT_794;
    mix_cd_m = zT_793;
    zT_795 = mix_cd_m;
    zT_796 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_795, zT_796);
    zT_799 = "MIX:b";
    zT_801 = 5;
    zT_800.ptr = zT_799;
    zT_800.len = zT_801;
    mix_b_m = zT_800;
    zT_802 = mix_b_m;
    zT_803 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_802, zT_803);
    zT_806 = "MIX:pf";
    zT_808 = 6;
    zT_807.ptr = zT_806;
    zT_807.len = zT_808;
    mix_pf_m = zT_807;
    zT_809 = mix_pf_m;
    zT_811 = prong.flags;
    zF_C914CB83_markerWriteInt(zT_809, (unsigned int)((unsigned int)zT_811));
    zT_814 = "MIX:pn";
    zT_816 = 6;
    zT_815.ptr = zT_814;
    zT_815.len = zT_816;
    mix_pn_m = zT_815;
    zT_817 = mix_pn_m;
    zF_C914CB83_markerWriteInt(zT_817, (unsigned int)((unsigned int)prongs_n));
    zT_821 = "MIX:ni";
    zT_823 = 6;
    zT_822.ptr = zT_821;
    zT_822.len = zT_823;
    mix_ni_m = zT_822;
    zT_824 = mix_ni_m;
    zT_825 = node_idx;
    zF_C914CB83_markerWriteInt(zT_824, zT_825);
    zT_826 = self->type_table;
    zT_827 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_826, zT_827, (unsigned int)(1));
    goto z_bb_24;
    z_bb_126:
    goto z_bb_127;
    z_bb_127:
    if ((unsigned char)(unified == (unsigned int)(0))) goto z_bb_128; else goto z_bb_129;
    z_bb_128:
    zT_839 = 3;
    unified = zT_839;
    goto z_bb_129;
    z_bb_129:
    zT_840 = self->type_table;
    zT_841 = node_idx;
    zT_842 = unified;
    zF_19B4A07D_resolvedTypeTableSe(zT_840, zT_841, zT_842);
    zT_845 = "SWU:n";
    zT_847 = 5;
    zT_846.ptr = zT_845;
    zT_846.len = zT_847;
    swu_m = zT_846;
    zT_848 = swu_m;
    zT_849 = node_idx;
    zF_C914CB83_markerWriteInt(zT_848, zT_849);
    zT_851 = "SWU:t";
    zT_853 = 5;
    zT_852.ptr = zT_851;
    zT_852.len = zT_853;
    swu_tm = zT_852;
    zT_854 = swu_tm;
    zT_855 = unified;
    zF_C914CB83_markerWriteInt(zT_854, zT_855);
    zT_856 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_856 - (unsigned int)(1));
    return unified;
}

/* semanticAnalyzerResolveExpr */
unsigned int zF_54F95822_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    unsigned int zT_12;
    zT_8143F551_AstKind zT_13;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8143F551_AstKind zT_28;
    unsigned int zT_32;
    zT_8143F551_AstKind zT_33;
    unsigned int zT_37;
    zT_8143F551_AstKind zT_38;
    unsigned int zT_42;
    zT_8143F551_AstKind zT_43;
    unsigned int zT_47;
    zT_8143F551_AstKind zT_48;
    unsigned int zT_52;
    zT_8143F551_AstKind zT_53;
    unsigned int zT_57;
    zT_8143F551_AstKind zT_58;
    unsigned int zT_62;
    zT_8143F551_AstKind zT_63;
    unsigned int zT_68;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned int zT_73 = 0;
    zT_6B0A7D14_AstStore* zT_75;
    zT_211983C2_anon_238685 zT_76;
    unsigned int zT_77;
    zT_6B0A7D14_AstStore* zT_80;
    zT_211983C2_anon_238685 zT_81;
    unsigned int* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_D3EB6303_StringInterner* zT_86;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90 = {0};
    unsigned int zT_92;
    unsigned int zT_93;
    zT_338B7C76_TypeRegistry* zT_95;
    unsigned int zT_97;
    unsigned int zT_100 = 0;
    zT_338B7C76_TypeRegistry* zT_101;
    unsigned int zT_102;
    unsigned int zT_106 = 0;
    zT_8143F551_AstKind zT_107;
    zT_38C12417_SemanticAnalyzer* zT_111;
    unsigned int zT_112;
    unsigned int zT_113 = 0;
    zT_8143F551_AstKind zT_114;
    unsigned int zT_118;
    int zT_119;
    unsigned int* zT_122;
    unsigned int zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    int zT_127;
    int zT_130;
    unsigned int zT_131;
    zT_338B7C76_TypeRegistry* zT_133;
    zT_D155D06D_Type* zT_134;
    unsigned int zT_135;
    zT_D155D06D_Type zT_136;
    zT_33EF6BFB_TypeKind zT_138;
    zT_338B7C76_TypeRegistry* zT_143;
    zT_0B10E8E9_OptionalPayload* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_0B10E8E9_OptionalPayload zT_147;
    unsigned int zT_148;
    zT_338B7C76_TypeRegistry* zT_149;
    zT_D155D06D_Type* zT_150;
    unsigned int zT_151;
    zT_D155D06D_Type zT_152;
    zT_33EF6BFB_TypeKind zT_153;
    zT_33EF6BFB_TypeKind zT_157;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_42C2D6BF_EUPayload* zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_42C2D6BF_EUPayload zT_165;
    unsigned int zT_166;
    int zT_167;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    unsigned int zT_173 = 0;
    zT_338B7C76_TypeRegistry* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_179 = 0;
    zT_21D3708C_U32ToU32Map* zT_183;
    unsigned int zT_184;
    unsigned int zT_186 = 0;
    zT_21D3708C_U32ToU32Map* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_8EED1867_ResolvedTypeTable* zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_196;
    unsigned int zT_198;
    unsigned int zT_200;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_F85C5DED_DiagnosticCollector* zT_205;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_218 = 0;
    unsigned int zT_219;
    zT_33EF6BFB_TypeKind zT_220;
    zT_8EED1867_ResolvedTypeTable* zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_230;
    zT_8143F551_AstKind zT_231;
    zT_38C12417_SemanticAnalyzer* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    zT_6B0A7D14_AstStore* zT_240;
    unsigned int zT_241;
    unsigned int zT_243 = 0;
    unsigned int zT_244 = 0;
    zT_8143F551_AstKind zT_245;
    zT_38C12417_SemanticAnalyzer* zT_249;
    unsigned int zT_250;
    unsigned int zT_251 = 0;
    unsigned char* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    zT_8143F551_AstKind zT_258;
    zT_38C12417_SemanticAnalyzer* zT_262;
    unsigned int zT_263;
    unsigned int zT_264 = 0;
    zT_8143F551_AstKind zT_265;
    zT_38C12417_SemanticAnalyzer* zT_269;
    unsigned int zT_270;
    unsigned int zT_271 = 0;
    zT_8143F551_AstKind zT_272;
    zT_38C12417_SemanticAnalyzer* zT_277;
    unsigned int zT_278;
    unsigned int zT_280 = 0;
    unsigned char zT_283;
    zT_338B7C76_TypeRegistry* zT_287;
    zT_D155D06D_Type* zT_288;
    unsigned int zT_289;
    zT_D155D06D_Type zT_290;
    zT_33EF6BFB_TypeKind zT_291;
    unsigned char zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_112BF819_PtrPayload* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_112BF819_PtrPayload zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    zT_8143F551_AstKind zT_308;
    zT_38C12417_SemanticAnalyzer* zT_313;
    unsigned int zT_314;
    unsigned int zT_316 = 0;
    unsigned char zT_319;
    zT_6B0A7D14_AstStore* zT_323;
    unsigned int zT_324;
    zT_22A7C88B_AstNode zT_327 = {0};
    zT_8143F551_AstKind zT_328;
    zT_38C12417_SemanticAnalyzer* zT_333;
    unsigned int zT_334;
    unsigned int zT_336 = 0;
    unsigned char zT_340;
    zT_338B7C76_TypeRegistry* zT_344;
    zT_D155D06D_Type* zT_345;
    unsigned int zT_346;
    zT_D155D06D_Type zT_347;
    zT_33EF6BFB_TypeKind zT_348;
    unsigned char zT_352;
    zT_33EF6BFB_TypeKind zT_353;
    zT_338B7C76_TypeRegistry* zT_357;
    zT_112BF819_PtrPayload* zT_358;
    unsigned int zT_359;
    unsigned int zT_360;
    zT_112BF819_PtrPayload zT_361;
    unsigned int zT_362;
    zT_338B7C76_TypeRegistry* zT_363;
    zT_D155D06D_Type* zT_364;
    unsigned int zT_365;
    zT_D155D06D_Type zT_366;
    zT_33EF6BFB_TypeKind zT_367;
    zT_38C12417_SemanticAnalyzer* zT_372;
    unsigned int zT_373;
    unsigned int zT_374 = 0;
    unsigned int zT_378;
    unsigned int zT_380;
    unsigned int zT_382;
    unsigned char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_F85C5DED_DiagnosticCollector* zT_387;
    unsigned int zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_398 = 0;
    zT_33EF6BFB_TypeKind zT_399;
    unsigned int zT_404;
    unsigned int zT_406;
    unsigned int zT_408;
    unsigned char* zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_412;
    zT_F85C5DED_DiagnosticCollector* zT_413;
    unsigned int zT_416;
    unsigned int zT_417;
    unsigned int zT_418;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_419;
    unsigned int zT_424 = 0;
    zT_338B7C76_TypeRegistry* zT_425;
    unsigned int zT_426;
    unsigned int zT_430 = 0;
    unsigned int zT_431;
    zT_8143F551_AstKind zT_432;
    zT_38C12417_SemanticAnalyzer* zT_436;
    unsigned int zT_437;
    unsigned int zT_438 = 0;
    zT_8143F551_AstKind zT_439;
    unsigned char zT_443;
    zT_38C12417_SemanticAnalyzer* zT_444;
    unsigned int zT_445;
    unsigned char zT_447 = 0;
    unsigned char* zT_450;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    unsigned int zT_452;
    zT_F85C5DED_DiagnosticCollector* zT_453;
    unsigned int zT_456;
    unsigned int zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459;
    unsigned int zT_465;
    unsigned int zT_466;
    unsigned int zT_469 = 0;
    unsigned int zT_470;
    zT_8143F551_AstKind zT_471;
    zT_6B0A7D14_AstStore* zT_476;
    unsigned int zT_477;
    unsigned int zT_479 = 0;
    unsigned int zT_480;
    unsigned char* zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned int zT_486;
    unsigned char zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    unsigned char zT_492;
    unsigned int zT_493;
    unsigned int zT_494;
    unsigned char zT_496;
    unsigned int zT_497;
    unsigned int zT_498;
    unsigned char zT_500;
    unsigned int zT_501;
    unsigned int zT_502;
    zT_ABC1EBBE_TypeResolveEnv zT_507;
    zT_6B0A7D14_AstStore* zT_508;
    zT_338B7C76_TypeRegistry* zT_509;
    zT_3D7259E2_SymbolRegistry* zT_510;
    zT_D3EB6303_StringInterner* zT_511;
    unsigned int zT_512;
    zT_F85C5DED_DiagnosticCollector* zT_513;
    zT_7034F045_Opt_228 zT_514;
    zT_03B97CED_Opt_398 zT_515 = {0};
    zT_05CE5599_Opt_400 zT_516 = {0};
    unsigned int zT_517;
    zT_ABC1EBBE_TypeResolveEnv* zT_518;
    unsigned int zT_519;
    zT_6B0A7D14_AstStore* zT_522;
    unsigned int zT_523;
    unsigned int zT_527 = 0;
    unsigned int zT_529 = 0;
    unsigned int zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned char zT_534;
    unsigned int zT_535;
    unsigned int zT_536;
    zT_38C12417_SemanticAnalyzer* zT_540;
    unsigned int zT_541;
    zT_6B0A7D14_AstStore* zT_542;
    unsigned int zT_543;
    unsigned int zT_547 = 0;
    unsigned int zT_548 = 0;
    unsigned int zT_549;
    unsigned int zT_550;
    unsigned int zT_551;
    unsigned int zT_555;
    zT_38C12417_SemanticAnalyzer* zT_558;
    unsigned int zT_559;
    zT_6B0A7D14_AstStore* zT_560;
    unsigned int zT_561;
    unsigned int zT_565 = 0;
    unsigned int zT_566 = 0;
    zT_38C12417_SemanticAnalyzer* zT_568;
    unsigned int zT_569 = 0;
    unsigned char zT_572;
    zT_338B7C76_TypeRegistry* zT_576;
    zT_D155D06D_Type* zT_577;
    unsigned int zT_578;
    zT_D155D06D_Type zT_579;
    zT_33EF6BFB_TypeKind zT_580;
    unsigned char zT_584;
    zT_33EF6BFB_TypeKind zT_585;
    unsigned char* zT_592;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_593;
    unsigned int zT_594;
    zT_F85C5DED_DiagnosticCollector* zT_595;
    unsigned int zT_598;
    unsigned int zT_599;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    unsigned int zT_609;
    unsigned int zT_610;
    unsigned int zT_613 = 0;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned int zT_619;
    zT_ABC1EBBE_TypeResolveEnv zT_623;
    zT_6B0A7D14_AstStore* zT_624;
    zT_338B7C76_TypeRegistry* zT_625;
    zT_3D7259E2_SymbolRegistry* zT_626;
    zT_D3EB6303_StringInterner* zT_627;
    unsigned int zT_628;
    zT_F85C5DED_DiagnosticCollector* zT_629;
    zT_7034F045_Opt_228 zT_630;
    zT_03B97CED_Opt_398 zT_631 = {0};
    zT_05CE5599_Opt_400 zT_632 = {0};
    unsigned int zT_633;
    zT_ABC1EBBE_TypeResolveEnv* zT_635;
    unsigned int zT_636;
    zT_6B0A7D14_AstStore* zT_639;
    unsigned int zT_640;
    unsigned int zT_644 = 0;
    unsigned int zT_646 = 0;
    zT_38C12417_SemanticAnalyzer* zT_649;
    unsigned int zT_650;
    zT_6B0A7D14_AstStore* zT_651;
    unsigned int zT_652;
    unsigned int zT_656 = 0;
    unsigned int zT_657 = 0;
    zT_338B7C76_TypeRegistry* zT_658;
    unsigned int zT_659;
    unsigned int zT_663 = 0;
    unsigned int zT_664;
    unsigned int zT_665;
    unsigned int zT_669;
    zT_ABC1EBBE_TypeResolveEnv zT_673;
    zT_6B0A7D14_AstStore* zT_674;
    zT_338B7C76_TypeRegistry* zT_675;
    zT_3D7259E2_SymbolRegistry* zT_676;
    zT_D3EB6303_StringInterner* zT_677;
    unsigned int zT_678;
    zT_F85C5DED_DiagnosticCollector* zT_679;
    zT_7034F045_Opt_228 zT_680;
    zT_03B97CED_Opt_398 zT_681 = {0};
    zT_05CE5599_Opt_400 zT_682 = {0};
    unsigned int zT_683;
    zT_ABC1EBBE_TypeResolveEnv* zT_685;
    unsigned int zT_686;
    zT_6B0A7D14_AstStore* zT_689;
    unsigned int zT_690;
    unsigned int zT_694 = 0;
    unsigned int zT_696 = 0;
    zT_38C12417_SemanticAnalyzer* zT_700;
    unsigned int zT_701;
    zT_6B0A7D14_AstStore* zT_702;
    unsigned int zT_703;
    unsigned int zT_707 = 0;
    unsigned int zT_708 = 0;
    unsigned char zT_710;
    unsigned char zT_713;
    zT_338B7C76_TypeRegistry* zT_714;
    unsigned int zT_715;
    unsigned char zT_717 = 0;
    unsigned char zT_718;
    zT_338B7C76_TypeRegistry* zT_719;
    unsigned int zT_720;
    unsigned char zT_722 = 0;
    zT_338B7C76_TypeRegistry* zT_724;
    zT_D155D06D_Type* zT_725;
    unsigned int zT_726;
    zT_D155D06D_Type zT_727;
    zT_338B7C76_TypeRegistry* zT_729;
    zT_D155D06D_Type* zT_730;
    unsigned int zT_731;
    zT_D155D06D_Type zT_732;
    unsigned char zT_733;
    unsigned char zT_736;
    unsigned char zT_737;
    unsigned char zT_740;
    unsigned int zT_741;
    unsigned int zT_742;
    unsigned char zT_744;
    unsigned char* zT_748;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_749;
    unsigned int zT_750;
    zT_F85C5DED_DiagnosticCollector* zT_751;
    unsigned int zT_754;
    unsigned int zT_755;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_765;
    unsigned int zT_766;
    unsigned int zT_769 = 0;
    unsigned int zT_770;
    unsigned int zT_771;
    unsigned int zT_773;
    unsigned int zT_774;
    unsigned int zT_775;
    zT_38C12417_SemanticAnalyzer* zT_779;
    unsigned int zT_780;
    zT_6B0A7D14_AstStore* zT_781;
    unsigned int zT_782;
    unsigned int zT_786 = 0;
    unsigned int zT_787 = 0;
    unsigned int zT_788;
    unsigned int zT_789;
    unsigned int zT_790;
    zT_38C12417_SemanticAnalyzer* zT_794;
    unsigned int zT_795;
    zT_6B0A7D14_AstStore* zT_796;
    unsigned int zT_797;
    unsigned int zT_801 = 0;
    unsigned int zT_802 = 0;
    unsigned int zT_803;
    unsigned int zT_804;
    unsigned int zT_805;
    unsigned char zT_807;
    unsigned int zT_808;
    unsigned int zT_809;
    zT_38C12417_SemanticAnalyzer* zT_813;
    unsigned int zT_814;
    zT_6B0A7D14_AstStore* zT_815;
    unsigned int zT_816;
    unsigned int zT_820 = 0;
    unsigned int zT_821 = 0;
    unsigned int zT_822;
    unsigned int zT_823;
    unsigned int zT_824;
    unsigned char zT_826;
    unsigned int zT_827;
    unsigned int zT_828;
    zT_38C12417_SemanticAnalyzer* zT_832;
    unsigned int zT_833;
    zT_6B0A7D14_AstStore* zT_834;
    unsigned int zT_835;
    unsigned int zT_839 = 0;
    unsigned int zT_840 = 0;
    zT_38C12417_SemanticAnalyzer* zT_841;
    unsigned int zT_842;
    zT_6B0A7D14_AstStore* zT_843;
    unsigned int zT_844;
    unsigned int zT_848 = 0;
    unsigned int zT_849 = 0;
    zT_38C12417_SemanticAnalyzer* zT_852;
    unsigned int zT_853;
    zT_6B0A7D14_AstStore* zT_854;
    unsigned int zT_855;
    unsigned int zT_859 = 0;
    unsigned int zT_860 = 0;
    unsigned int zT_861;
    unsigned int zT_862;
    unsigned int zT_863;
    unsigned int zT_865;
    unsigned int zT_866;
    unsigned int zT_867;
    unsigned int zT_869;
    unsigned int zT_870;
    unsigned int zT_871;
    unsigned char zT_873;
    unsigned int zT_874;
    unsigned int zT_875;
    zT_38C12417_SemanticAnalyzer* zT_879;
    unsigned int zT_880;
    zT_6B0A7D14_AstStore* zT_881;
    unsigned int zT_882;
    unsigned int zT_886 = 0;
    unsigned int zT_887 = 0;
    zT_38C12417_SemanticAnalyzer* zT_888;
    unsigned int zT_889;
    zT_6B0A7D14_AstStore* zT_890;
    unsigned int zT_891;
    unsigned int zT_895 = 0;
    unsigned int zT_896 = 0;
    zT_38C12417_SemanticAnalyzer* zT_899;
    unsigned int zT_900;
    zT_6B0A7D14_AstStore* zT_901;
    unsigned int zT_902;
    unsigned int zT_906 = 0;
    unsigned int zT_907 = 0;
    unsigned int zT_908;
    unsigned int zT_909;
    unsigned int zT_910;
    zT_38C12417_SemanticAnalyzer* zT_914;
    unsigned int zT_915;
    zT_6B0A7D14_AstStore* zT_916;
    unsigned int zT_917;
    unsigned int zT_921 = 0;
    unsigned int zT_922 = 0;
    unsigned char zT_924;
    zT_6B0A7D14_AstStore* zT_925;
    zT_3D7259E2_SymbolRegistry* zT_926;
    unsigned int zT_927;
    unsigned int zT_928;
    zT_6B0A7D14_AstStore* zT_932;
    unsigned int zT_933;
    unsigned int zT_937 = 0;
    zT_BBEE1AC1_Opt_11 zT_938 = {0};
    unsigned char zT_939;
    unsigned int zT_944;
    unsigned int zT_948;
    zT_A4CE86B7_U64ToU32Map* zT_949;
    unsigned int zT_950;
    unsigned int zT_951;
    unsigned char zT_953 = 0;
    unsigned char zT_954;
    unsigned char* zT_957;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_958;
    unsigned int zT_959;
    zT_F85C5DED_DiagnosticCollector* zT_960;
    unsigned int zT_963;
    unsigned int zT_964;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_966;
    unsigned int zT_974;
    unsigned int zT_975;
    unsigned int zT_978 = 0;
    unsigned int zT_979;
    unsigned int zT_980;
    unsigned int zT_981;
    zT_38C12417_SemanticAnalyzer* zT_985;
    unsigned int zT_986;
    zT_6B0A7D14_AstStore* zT_987;
    unsigned int zT_988;
    unsigned int zT_992 = 0;
    unsigned int zT_993 = 0;
    zT_38C12417_SemanticAnalyzer* zT_994;
    unsigned int zT_995;
    zT_6B0A7D14_AstStore* zT_996;
    unsigned int zT_997;
    unsigned int zT_1001 = 0;
    unsigned int zT_1002 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1003;
    unsigned int zT_1004;
    zT_6B0A7D14_AstStore* zT_1005;
    unsigned int zT_1006;
    unsigned int zT_1010 = 0;
    unsigned int zT_1011 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1012;
    unsigned int zT_1013;
    zT_6B0A7D14_AstStore* zT_1014;
    unsigned int zT_1015;
    unsigned int zT_1019 = 0;
    unsigned int zT_1020 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1021;
    unsigned int zT_1022;
    zT_338B7C76_TypeRegistry* zT_1023;
    unsigned int zT_1029 = 0;
    unsigned int zT_1030;
    unsigned int zT_1031;
    zT_38C12417_SemanticAnalyzer* zT_1035;
    unsigned int zT_1036;
    zT_6B0A7D14_AstStore* zT_1037;
    unsigned int zT_1038;
    unsigned int zT_1042 = 0;
    unsigned int zT_1043 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1044;
    unsigned int zT_1045;
    zT_6B0A7D14_AstStore* zT_1046;
    unsigned int zT_1047;
    unsigned int zT_1051 = 0;
    unsigned int zT_1052 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1053;
    unsigned int zT_1054;
    zT_338B7C76_TypeRegistry* zT_1055;
    unsigned int zT_1056;
    zT_338B7C76_TypeRegistry* zT_1058;
    unsigned int zT_1064 = 0;
    unsigned int zT_1065 = 0;
    unsigned int zT_1066;
    unsigned int zT_1067;
    zT_38C12417_SemanticAnalyzer* zT_1071;
    unsigned int zT_1072;
    zT_6B0A7D14_AstStore* zT_1073;
    unsigned int zT_1074;
    unsigned int zT_1078 = 0;
    unsigned int zT_1079 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1080;
    unsigned int zT_1081;
    zT_38C12417_SemanticAnalyzer* zT_1082;
    unsigned int zT_1083;
    zT_338B7C76_TypeRegistry* zT_1084;
    unsigned int zT_1090 = 0;
    unsigned int zT_1091;
    unsigned int zT_1092;
    unsigned char zT_1094;
    unsigned char* zT_1098;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1099;
    unsigned int zT_1100;
    zT_F85C5DED_DiagnosticCollector* zT_1101;
    unsigned int zT_1104;
    unsigned int zT_1105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1107;
    unsigned int zT_1115;
    unsigned int zT_1116;
    unsigned int zT_1119 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1122;
    unsigned int zT_1123;
    zT_6B0A7D14_AstStore* zT_1124;
    unsigned int zT_1125;
    unsigned int zT_1129 = 0;
    unsigned int zT_1130 = 0;
    unsigned int zT_1131;
    zT_38C12417_SemanticAnalyzer* zT_1132;
    unsigned int zT_1133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1134;
    unsigned char zT_1136 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1139;
    unsigned int zT_1140;
    zT_6B0A7D14_AstStore* zT_1141;
    unsigned int zT_1142;
    unsigned int zT_1146 = 0;
    unsigned int zT_1147 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_1149;
    zT_6B0A7D14_AstStore* zT_1150;
    zT_338B7C76_TypeRegistry* zT_1151;
    zT_3D7259E2_SymbolRegistry* zT_1152;
    zT_D3EB6303_StringInterner* zT_1153;
    unsigned int zT_1154;
    zT_F85C5DED_DiagnosticCollector* zT_1155;
    zT_7034F045_Opt_228 zT_1156;
    zT_03B97CED_Opt_398 zT_1157 = {0};
    zT_05CE5599_Opt_400 zT_1158 = {0};
    unsigned int zT_1159;
    zT_ABC1EBBE_TypeResolveEnv* zT_1160;
    unsigned int zT_1161;
    zT_6B0A7D14_AstStore* zT_1164;
    unsigned int zT_1165;
    unsigned int zT_1169 = 0;
    unsigned int zT_1171 = 0;
    unsigned int zT_1172;
    zT_38C12417_SemanticAnalyzer* zT_1175;
    unsigned int zT_1176;
    unsigned char zT_1178 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1180;
    unsigned int zT_1181;
    zT_6B0A7D14_AstStore* zT_1182;
    unsigned int zT_1183;
    unsigned int zT_1187 = 0;
    unsigned int zT_1188 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_1190;
    zT_6B0A7D14_AstStore* zT_1191;
    zT_338B7C76_TypeRegistry* zT_1192;
    zT_3D7259E2_SymbolRegistry* zT_1193;
    zT_D3EB6303_StringInterner* zT_1194;
    unsigned int zT_1195;
    zT_F85C5DED_DiagnosticCollector* zT_1196;
    zT_7034F045_Opt_228 zT_1197;
    zT_03B97CED_Opt_398 zT_1198 = {0};
    zT_05CE5599_Opt_400 zT_1199 = {0};
    unsigned int zT_1200;
    zT_ABC1EBBE_TypeResolveEnv* zT_1201;
    unsigned int zT_1202;
    zT_6B0A7D14_AstStore* zT_1205;
    unsigned int zT_1206;
    unsigned int zT_1210 = 0;
    unsigned int zT_1212 = 0;
    unsigned int zT_1213;
    unsigned int zT_1214;
    unsigned char zT_1216;
    unsigned char zT_1219;
    zT_38C12417_SemanticAnalyzer* zT_1222;
    unsigned int zT_1223;
    unsigned int zT_1224;
    unsigned char zT_1225 = 0;
    unsigned char* zT_1227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1228;
    unsigned int zT_1229;
    zT_F85C5DED_DiagnosticCollector* zT_1230;
    unsigned int zT_1233;
    unsigned int zT_1234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1236;
    unsigned int zT_1242;
    unsigned int zT_1243;
    unsigned int zT_1246 = 0;
    unsigned int zT_1247;
    unsigned int zT_1248;
    unsigned char zT_1250;
    unsigned char zT_1253;
    zT_38C12417_SemanticAnalyzer* zT_1256;
    unsigned int zT_1257;
    unsigned int zT_1258;
    unsigned char zT_1259 = 0;
    unsigned char* zT_1262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1263;
    unsigned int zT_1264;
    zT_F85C5DED_DiagnosticCollector* zT_1265;
    unsigned int zT_1268;
    unsigned int zT_1269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1271;
    unsigned int zT_1277;
    unsigned int zT_1278;
    unsigned int zT_1281 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1282;
    unsigned int zT_1283;
    zT_6B0A7D14_AstStore* zT_1284;
    unsigned int zT_1285;
    unsigned int zT_1289 = 0;
    unsigned int zT_1290 = 0;
    unsigned int zT_1291;
    unsigned int zT_1292;
    unsigned char zT_1294;
    zT_38C12417_SemanticAnalyzer* zT_1298;
    unsigned int zT_1299;
    zT_6B0A7D14_AstStore* zT_1300;
    unsigned int zT_1301;
    unsigned int zT_1305 = 0;
    unsigned int zT_1306 = 0;
    zT_338B7C76_TypeRegistry* zT_1311;
    zT_D155D06D_Type* zT_1312;
    unsigned int zT_1313;
    zT_D155D06D_Type zT_1314;
    zT_33EF6BFB_TypeKind zT_1315;
    zT_338B7C76_TypeRegistry* zT_1320;
    unsigned int zT_1321;
    unsigned int zT_1323 = 0;
    unsigned char zT_1326;
    zT_338B7C76_TypeRegistry* zT_1328;
    unsigned int zT_1329;
    zT_38C12417_SemanticAnalyzer* zT_1333;
    unsigned int zT_1334;
    zT_6B0A7D14_AstStore* zT_1335;
    unsigned int zT_1336;
    unsigned int zT_1340 = 0;
    unsigned int zT_1341 = 0;
    unsigned int zT_1342;
    zT_8143F551_AstKind zT_1343;
    zT_38C12417_SemanticAnalyzer* zT_1347;
    unsigned int zT_1348;
    unsigned int zT_1350 = 0;
    unsigned int zT_1351;
    zT_8143F551_AstKind zT_1352;
    unsigned char zT_1356;
    zT_8143F551_AstKind zT_1357;
    zT_38C12417_SemanticAnalyzer* zT_1361;
    unsigned int zT_1362;
    unsigned int zT_1363 = 0;
    zT_8143F551_AstKind zT_1364;
    zT_38C12417_SemanticAnalyzer* zT_1368;
    unsigned int zT_1369;
    unsigned int zT_1370 = 0;
    zT_8143F551_AstKind zT_1371;
    zT_38C12417_SemanticAnalyzer* zT_1375;
    unsigned int zT_1376;
    unsigned int zT_1377 = 0;
    zT_8143F551_AstKind zT_1378;
    int zT_1383;
    unsigned int zT_1384;
    zT_38C12417_SemanticAnalyzer* zT_1385;
    unsigned int zT_1386;
    unsigned int zT_1388 = 0;
    zT_338B7C76_TypeRegistry* zT_1392;
    zT_D155D06D_Type* zT_1393;
    unsigned int zT_1394;
    zT_D155D06D_Type zT_1395;
    zT_33EF6BFB_TypeKind zT_1396;
    zT_338B7C76_TypeRegistry* zT_1400;
    zT_42C2D6BF_EUPayload* zT_1401;
    unsigned int zT_1402;
    unsigned int zT_1403;
    zT_42C2D6BF_EUPayload zT_1404;
    unsigned int zT_1405;
    zT_338B7C76_TypeRegistry* zT_1406;
    zT_42C2D6BF_EUPayload* zT_1407;
    unsigned int zT_1408;
    unsigned int zT_1409;
    zT_42C2D6BF_EUPayload zT_1410;
    unsigned int zT_1411;
    zT_66E7D2EF_CoercionTable* zT_1412;
    unsigned int zT_1413;
    unsigned int zT_1415;
    unsigned int zT_1421;
    unsigned int zT_1422;
    unsigned int zT_1423;
    int zT_1424;
    zT_6B0A7D14_AstStore* zT_1427;
    unsigned int zT_1428;
    zT_22A7C88B_AstNode zT_1431 = {0};
    zT_38C12417_SemanticAnalyzer* zT_1432;
    unsigned int zT_1433;
    unsigned int zT_1434;
    zT_6B0A7D14_AstStore* zT_1436;
    unsigned int zT_1437;
    unsigned int zT_1440 = 0;
    unsigned int zT_1442;
    unsigned int zT_1443;
    unsigned int zT_1446;
    unsigned int zT_1447;
    zT_38C12417_SemanticAnalyzer* zT_1449;
    zT_6B0A7D14_AstStore* zT_1450;
    unsigned int zT_1451;
    unsigned int zT_1454 = 0;
    unsigned int* zT_1455;
    unsigned int zT_1456;
    int zT_1457;
    unsigned int zT_1459;
    unsigned int* zT_1461;
    unsigned int zT_1462;
    unsigned char zT_1463;
    unsigned char* zT_1464;
    unsigned int zT_1465;
    unsigned int zT_1466;
    unsigned int zT_1469;
    int zT_1472;
    zT_6B0A7D14_AstStore* zT_1475;
    unsigned int zT_1476;
    zT_22A7C88B_AstNode zT_1479 = {0};
    zT_8143F551_AstKind zT_1480;
    zT_38C12417_SemanticAnalyzer* zT_1484;
    unsigned int zT_1485;
    zT_38C12417_SemanticAnalyzer* zT_1486;
    unsigned int zT_1487;
    unsigned int zT_1489 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1490;
    zT_38C12417_SemanticAnalyzer* zT_1491;
    unsigned int zT_1492;
    zT_8143F551_AstKind zT_1495;
    unsigned int zT_1500;
    unsigned int zT_1501;
    zT_38C12417_SemanticAnalyzer* zT_1502;
    unsigned int zT_1503;
    unsigned int zT_1504 = 0;
    zT_8143F551_AstKind zT_1506;
    unsigned char zT_1510;
    zT_8143F551_AstKind zT_1511;
    unsigned int zT_1515;
    zT_8143F551_AstKind zT_1516;
    unsigned char zT_1520;
    zT_8143F551_AstKind zT_1521;
    unsigned char zT_1525;
    zT_8143F551_AstKind zT_1526;
    unsigned char zT_1530;
    zT_8143F551_AstKind zT_1531;
    zT_38C12417_SemanticAnalyzer* zT_1535;
    unsigned int zT_1536;
    unsigned int zT_1537;
    zT_8143F551_AstKind zT_1538;
    unsigned int zT_1543;
    unsigned int zT_1544;
    zT_38C12417_SemanticAnalyzer* zT_1545;
    unsigned int zT_1546;
    unsigned int zT_1547 = 0;
    zT_8143F551_AstKind zT_1549;
    zT_38C12417_SemanticAnalyzer* zT_1553;
    unsigned int zT_1554;
    unsigned int zT_1555;
    zT_38C12417_SemanticAnalyzer* zT_1558;
    unsigned int zT_1559;
    unsigned int zT_1561;
    zT_38C12417_SemanticAnalyzer* zT_1564;
    unsigned int zT_1565;
    unsigned int zT_1567;
    zT_8143F551_AstKind zT_1568;
    zT_38C12417_SemanticAnalyzer* zT_1572;
    unsigned int zT_1573;
    unsigned int zT_1574;
    int zT_1575;
    zT_38C12417_SemanticAnalyzer* zT_1577;
    unsigned int zT_1578;
    unsigned int zT_1580;
    zT_8143F551_AstKind zT_1581;
    zT_38C12417_SemanticAnalyzer* zT_1585;
    unsigned int zT_1586;
    unsigned int zT_1587;
    int zT_1588;
    zT_38C12417_SemanticAnalyzer* zT_1590;
    unsigned int zT_1591;
    unsigned int zT_1593;
    zT_8143F551_AstKind zT_1594;
    zT_38C12417_SemanticAnalyzer* zT_1598;
    unsigned int zT_1599;
    unsigned int zT_1600 = 0;
    zT_8143F551_AstKind zT_1601;
    zT_38C12417_SemanticAnalyzer* zT_1605;
    unsigned int zT_1606;
    unsigned int zT_1607 = 0;
    zT_8143F551_AstKind zT_1608;
    zT_38C12417_SemanticAnalyzer* zT_1612;
    unsigned int zT_1613;
    unsigned int zT_1614 = 0;
    zT_8143F551_AstKind zT_1615;
    unsigned char* zT_1620;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1621;
    unsigned int zT_1622;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1623;
    unsigned int zT_1624;
    zT_38C12417_SemanticAnalyzer* zT_1625;
    unsigned int zT_1626;
    unsigned int zT_1627 = 0;
    zT_8143F551_AstKind zT_1628;
    unsigned char zT_1632;
    zT_8143F551_AstKind zT_1633;
    unsigned char zT_1637;
    zT_8143F551_AstKind zT_1638;
    unsigned char zT_1642;
    zT_8143F551_AstKind zT_1643;
    unsigned char zT_1647;
    zT_8143F551_AstKind zT_1648;
    unsigned char zT_1652;
    zT_8143F551_AstKind zT_1653;
    unsigned char zT_1657;
    zT_8143F551_AstKind zT_1658;
    unsigned char zT_1662;
    zT_8143F551_AstKind zT_1663;
    unsigned char zT_1667;
    zT_8143F551_AstKind zT_1668;
    unsigned char zT_1672;
    zT_8143F551_AstKind zT_1673;
    unsigned char zT_1677;
    zT_8143F551_AstKind zT_1678;
    zT_8143F551_AstKind zT_1682;
    zT_38C12417_SemanticAnalyzer* zT_1686;
    unsigned int zT_1687;
    unsigned int zT_1688;
    zT_8143F551_AstKind zT_1690;
    zT_38C12417_SemanticAnalyzer* zT_1694;
    unsigned int zT_1695;
    unsigned int zT_1696;
    zT_8143F551_AstKind zT_1697;
    zT_38C12417_SemanticAnalyzer* zT_1701;
    unsigned int zT_1702;
    unsigned int zT_1704 = 0;
    zT_8143F551_AstKind zT_1705;
    zT_38C12417_SemanticAnalyzer* zT_1709;
    unsigned int zT_1710;
    unsigned int zT_1711;
    zT_8143F551_AstKind zT_1712;
    zT_38C12417_SemanticAnalyzer* zT_1716;
    unsigned int zT_1717;
    unsigned int zT_1719 = 0;
    zT_8143F551_AstKind zT_1720;
    unsigned int zT_1724;
    zT_8143F551_AstKind zT_1725;
    unsigned int zT_1730;
    unsigned int zT_1731;
    unsigned int zT_1733;
    unsigned char* zT_1735;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1736;
    unsigned int zT_1737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1738;
    unsigned int zT_1739;
    zT_6B0A7D14_AstStore* zT_1741;
    unsigned int zT_1742;
    unsigned int zT_1744 = 0;
    unsigned char* zT_1746;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1747;
    unsigned int zT_1748;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1749;
    int zT_1755;
    unsigned int zT_1756;
    int zT_1758;
    unsigned char* zT_1762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1763;
    unsigned int zT_1764;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1765;
    unsigned char* zT_1769;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1770;
    unsigned int zT_1771;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1772;
    unsigned int zT_1773;
    zT_6B0A7D14_AstStore* zT_1774;
    unsigned int zT_1775;
    unsigned int zT_1779 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1780;
    unsigned int zT_1781;
    zT_6B0A7D14_AstStore* zT_1782;
    unsigned int zT_1783;
    unsigned int zT_1787 = 0;
    int zT_1788;
    unsigned int zT_1790;
    zT_6B0A7D14_AstStore* zT_1792;
    unsigned int zT_1793;
    unsigned int zT_1799 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1800;
    unsigned int zT_1801;
    unsigned int zT_1802 = 0;
    unsigned int zT_1803;
    unsigned int zT_1804;
    unsigned int zT_1806;
    unsigned int* zT_1810;
    unsigned int zT_1811;
    unsigned int zT_1812;
    zT_38C12417_SemanticAnalyzer* zT_1813;
    unsigned int zT_1814;
    unsigned char zT_1815 = 0;
    unsigned char zT_1817;
    zT_38C12417_SemanticAnalyzer* zT_1820;
    unsigned int zT_1821;
    zT_8143F551_AstKind zT_1823;
    unsigned char zT_1827;
    zT_8143F551_AstKind zT_1828;
    unsigned char zT_1832;
    zT_8143F551_AstKind zT_1833;
    unsigned char zT_1837;
    zT_8143F551_AstKind zT_1838;
    unsigned char zT_1842;
    zT_8143F551_AstKind zT_1843;
    unsigned char zT_1847;
    zT_8143F551_AstKind zT_1848;
    unsigned char zT_1852;
    zT_8143F551_AstKind zT_1853;
    unsigned char zT_1857;
    zT_8143F551_AstKind zT_1858;
    unsigned char zT_1862;
    zT_8143F551_AstKind zT_1863;
    unsigned char zT_1867;
    zT_8143F551_AstKind zT_1868;
    unsigned char zT_1872;
    zT_8143F551_AstKind zT_1873;
    zT_38C12417_SemanticAnalyzer* zT_1877;
    unsigned int zT_1878;
    zT_8143F551_AstKind zT_1879;
    unsigned int zT_1881 = 0;
    zT_8143F551_AstKind zT_1882;
    unsigned char zT_1886;
    zT_8143F551_AstKind zT_1887;
    unsigned char zT_1891;
    zT_8143F551_AstKind zT_1892;
    unsigned char zT_1896;
    zT_8143F551_AstKind zT_1897;
    unsigned char zT_1901;
    zT_8143F551_AstKind zT_1902;
    unsigned char zT_1906;
    zT_8143F551_AstKind zT_1907;
    zT_38C12417_SemanticAnalyzer* zT_1911;
    unsigned int zT_1912;
    unsigned int zT_1913 = 0;
    zT_8143F551_AstKind zT_1914;
    unsigned char zT_1918;
    zT_8143F551_AstKind zT_1919;
    zT_38C12417_SemanticAnalyzer* zT_1923;
    unsigned int zT_1924;
    unsigned int zT_1925 = 0;
    zT_8143F551_AstKind zT_1926;
    unsigned char zT_1930;
    zT_8143F551_AstKind zT_1931;
    unsigned char zT_1935;
    zT_8143F551_AstKind zT_1936;
    unsigned char zT_1940;
    zT_8143F551_AstKind zT_1941;
    unsigned char zT_1945;
    zT_8143F551_AstKind zT_1946;
    unsigned char zT_1950;
    zT_8143F551_AstKind zT_1951;
    zT_38C12417_SemanticAnalyzer* zT_1955;
    unsigned int zT_1956;
    zT_8143F551_AstKind zT_1957;
    unsigned int zT_1959 = 0;
    zT_8143F551_AstKind zT_1960;
    unsigned char zT_1964;
    zT_8143F551_AstKind zT_1965;
    unsigned char zT_1969;
    zT_8143F551_AstKind zT_1970;
    unsigned char zT_1974;
    zT_8143F551_AstKind zT_1975;
    unsigned char zT_1979;
    zT_8143F551_AstKind zT_1980;
    unsigned char zT_1984;
    zT_8143F551_AstKind zT_1985;
    unsigned char zT_1989;
    zT_8143F551_AstKind zT_1990;
    unsigned char zT_1994;
    zT_8143F551_AstKind zT_1995;
    unsigned char zT_1999;
    zT_8143F551_AstKind zT_2000;
    unsigned char zT_2004;
    zT_8143F551_AstKind zT_2005;
    unsigned char zT_2009;
    zT_8143F551_AstKind zT_2010;
    unsigned char zT_2014;
    zT_8143F551_AstKind zT_2015;
    unsigned char zT_2019;
    zT_8143F551_AstKind zT_2020;
    unsigned char zT_2024;
    zT_8143F551_AstKind zT_2025;
    unsigned char zT_2029;
    zT_8143F551_AstKind zT_2030;
    unsigned char zT_2034;
    zT_8143F551_AstKind zT_2035;
    unsigned char zT_2039;
    zT_8143F551_AstKind zT_2040;
    unsigned char zT_2044;
    zT_8143F551_AstKind zT_2045;
    zT_38C12417_SemanticAnalyzer* zT_2049;
    unsigned int zT_2050;
    unsigned int zT_2051 = 0;
    zT_8143F551_AstKind zT_2052;
    unsigned char zT_2056;
    zT_8143F551_AstKind zT_2057;
    zT_38C12417_SemanticAnalyzer* zT_2061;
    unsigned int zT_2062;
    unsigned int zT_2064 = 0;
    unsigned int zT_2065;
    int zT_2066;
    zT_38C12417_SemanticAnalyzer* zT_2068;
    unsigned int zT_2069;
    unsigned int zT_2071 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_2072;
    unsigned int zT_2073;
    unsigned char* zT_2079;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2080;
    unsigned int zT_2081;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2082;
    unsigned int zT_2083;
    zT_8143F551_AstKind zT_2085;
    unsigned int zT_2086;
    unsigned char* zT_2088;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2089;
    unsigned int zT_2090;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2091;
    unsigned int zT_2092;
    unsigned char* zT_2094;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2095;
    unsigned int zT_2096;
    zT_F85C5DED_DiagnosticCollector* zT_2097;
    unsigned int zT_2100;
    unsigned int zT_2101;
    unsigned int zT_2102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2103;
    unsigned int zT_2108 = 0;
    unsigned char* zT_2111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2112;
    unsigned int zT_2113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2114;
    unsigned int zT_2115;
    zT_8143F551_AstKind zT_2117;
    unsigned int zT_2118;
    unsigned char* zT_2120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2121;
    unsigned int zT_2122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2123;
    unsigned int zT_2124;
    unsigned char* zT_2126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2127;
    unsigned int zT_2128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2129;
    unsigned int zT_2130;
    unsigned char* zT_2132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2133;
    unsigned int zT_2134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2135;
    unsigned int zT_2136;
    zT_8143F551_AstKind zT_2138;
    unsigned int zT_2139;
    unsigned char* zT_2141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2142;
    unsigned int zT_2143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2144;
    unsigned int zT_2145;
    unsigned char* zT_2147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2148;
    unsigned int zT_2149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2150;
    unsigned int zT_2151;
    zT_8EED1867_ResolvedTypeTable* zT_2152;
    unsigned int zT_2153;
    unsigned int zT_2154;
    unsigned char* zT_2157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2158;
    unsigned int zT_2159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2160;
    unsigned int zT_2161;
    unsigned char* zT_2163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2164;
    unsigned int zT_2165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2166;
    unsigned int zT_2167;
    unsigned int result;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rx_sw_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rxs_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_m;
    unsigned int stx_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_nm;
    unsigned int a4_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_rm;
    unsigned int sl_len;
    unsigned int sl_payload;
    unsigned int sl_str_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl_bytes;
    unsigned int sl_arr;
    unsigned int top;
    unsigned int es;
    zT_D155D06D_Type tty;
    unsigned int eff_top;
    unsigned int opt_pay;
    unsigned int name_id;
    unsigned int ord;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u fad;
    unsigned int base;
    zT_D155D06D_Type bt;
    zT_112BF819_PtrPayload pp;
    zT_22A7C88B_AstNode base_node;
    unsigned int fa_base_t;
    unsigned int st;
    zT_D155D06D_Type st_ty;
    unsigned int sd;
    unsigned int aps;
    unsigned int ape;
    zT_8F083A69_Slice_zT_0B42B2F8_u aof_msg;
    unsigned int apu_s;
    unsigned int apu_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u aou_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ub_msg;
    unsigned int ec_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u cva;
    zT_ABC1EBBE_TypeResolveEnv so_env;
    unsigned int pfi_res;
    unsigned int pfi_top;
    zT_D155D06D_Type pfi_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_msg;
    unsigned int fpp_res;
    zT_ABC1EBBE_TypeResolveEnv fpp_env;
    unsigned int fpp_outer;
    unsigned int bc_res;
    zT_ABC1EBBE_TypeResolveEnv bc_env;
    unsigned int bc_dst;
    unsigned int bc_src;
    unsigned char bc_ok;
    zT_D155D06D_Type bc_dty;
    zT_D155D06D_Type bc_sty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_msg;
    unsigned char afs_susp;
    zT_79FAE712_u64 afs_k;
    unsigned int afs_mid;
    unsigned int afs_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u e3046;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc3049;
    zT_ABC1EBBE_TypeResolveEnv cva_env;
    unsigned int tv_src;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcq_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcc_msg;
    unsigned int e2i_arg;
    unsigned int e2i_res;
    zT_D155D06D_Type e2i_ty;
    unsigned int e2i_bt;
    unsigned int catch_es;
    zT_D155D06D_Type clt;
    unsigned int catch_scope_saved;
    zT_22A7C88B_AstNode capture_node;
    zT_22A7C88B_AstNode child1;
    unsigned int orelse_scope_saved;
    unsigned int ifexpr_scope_saved;
    zT_8F083A69_Slice_zT_0B42B2F8_u ai_dbg;
    unsigned int eblk_scope_saved;
    unsigned int eblk_work_base;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_m;
    unsigned int children_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm2;
    unsigned int last_child;
    unsigned int eblk_wi;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_m;
    unsigned int st_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u unr_msg;
    zT_3 = 0;
    result = zT_3;
    zT_4 = 0;
    result = zT_4;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return result;
    z_bb_2:
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_12 = 1;
    result = zT_12;
    zT_13 = node.kind;
    if ((unsigned char)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = "RXS";
    zT_20 = 3;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rx_sw_m = zT_19;
    zT_21 = rx_sw_m;
    zF_48AC7B3A_markerWrite(zT_21);
    zT_23 = "RXS:n";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    rxs_nm = zT_24;
    zT_26 = rxs_nm;
    zT_27 = node_idx;
    zF_C914CB83_markerWriteInt(zT_26, zT_27);
    goto z_bb_4;
    z_bb_4:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_32 = 19;
    result = zT_32;
    goto z_bb_6;
    z_bb_6:
    zT_2111 = "STX:n";
    zT_2113 = 5;
    zT_2112.ptr = zT_2111;
    zT_2112.len = zT_2113;
    stx_m = zT_2112;
    zT_2114 = stx_m;
    zT_2115 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2114, zT_2115);
    zT_2117 = node.kind;
    zT_2118 = (unsigned int)zT_2117;
    stx_kv = zT_2118;
    zT_2120 = "STX:k";
    zT_2122 = 5;
    zT_2121.ptr = zT_2120;
    zT_2121.len = zT_2122;
    stx_km = zT_2121;
    zT_2123 = stx_km;
    zT_2124 = stx_kv;
    zF_C914CB83_markerWriteInt(zT_2123, zT_2124);
    zT_2126 = "STX:r";
    zT_2128 = 5;
    zT_2127.ptr = zT_2126;
    zT_2127.len = zT_2128;
    stx_rm = zT_2127;
    zT_2129 = stx_rm;
    zT_2130 = result;
    zF_C914CB83_markerWriteInt(zT_2129, zT_2130);
    zT_2132 = "A4:N";
    zT_2134 = 4;
    zT_2133.ptr = zT_2132;
    zT_2133.len = zT_2134;
    a4_nm = zT_2133;
    zT_2135 = a4_nm;
    zT_2136 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2135, zT_2136);
    zT_2138 = node.kind;
    zT_2139 = (unsigned int)zT_2138;
    a4_kv = zT_2139;
    zT_2141 = "A4:K";
    zT_2143 = 4;
    zT_2142.ptr = zT_2141;
    zT_2142.len = zT_2143;
    a4_km = zT_2142;
    zT_2144 = a4_km;
    zT_2145 = a4_kv;
    zF_C914CB83_markerWriteInt(zT_2144, zT_2145);
    zT_2147 = "A4:R";
    zT_2149 = 4;
    zT_2148.ptr = zT_2147;
    zT_2148.len = zT_2149;
    a4_rm = zT_2148;
    zT_2150 = a4_rm;
    zT_2151 = result;
    zF_C914CB83_markerWriteInt(zT_2150, zT_2151);
    zT_2152 = self->type_table;
    zT_2153 = node_idx;
    zT_2154 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_2152, zT_2153, zT_2154);
    zT_2157 = "STB:N";
    zT_2159 = 5;
    zT_2158.ptr = zT_2157;
    zT_2158.len = zT_2159;
    stb_nm = zT_2158;
    zT_2160 = stb_nm;
    zT_2161 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2160, zT_2161);
    zT_2163 = "STB:R";
    zT_2165 = 5;
    zT_2164.ptr = zT_2163;
    zT_2164.len = zT_2165;
    stb_rm = zT_2164;
    zT_2166 = stb_rm;
    zT_2167 = result;
    zF_C914CB83_markerWriteInt(zT_2166, zT_2167);
    return result;
    z_bb_7:
    zT_33 = node.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_37 = 16;
    result = zT_37;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_38 = node.kind;
    if ((unsigned char)(zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_42 = 8;
    result = zT_42;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_43 = node.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_47 = 2;
    result = zT_47;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_48 = node.kind;
    if ((unsigned char)(zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_52 = 17;
    result = zT_52;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_53 = node.kind;
    if ((unsigned char)(zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_57 = 18;
    result = zT_57;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_58 = node.kind;
    if ((unsigned char)(zT_58 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_unreachable_expr))) goto z_bb_23; else goto z_bb_25;
    z_bb_23:
    zT_62 = 3;
    result = zT_62;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_63 = node.kind;
    if ((unsigned char)(zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_68 = 0;
    sl_len = zT_68;
    zT_70 = self->store;
    zT_71 = node_idx;
    zT_73 = zF_8BA26B9E_astStoreNodePayload(zT_70, zT_71);
    sl_payload = zT_73;
    zT_75 = self->store;
    zT_76 = zT_75->string_values;
    zT_77 = zT_76.len;
    if ((unsigned char)((unsigned int)((unsigned int)sl_payload) < zT_77)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_107 = node.kind;
    if ((unsigned char)(zT_107 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_31; else goto z_bb_33;
    z_bb_29:
    zT_80 = self->store;
    zT_81 = zT_80->string_values;
    zT_82 = zT_81.items;
    zT_83 = (unsigned int)sl_payload;
    zT_84 = zT_82[zT_83];
    sl_str_id = zT_84;
    zT_88 = self->registry;
    zT_86 = zT_88->interner;
    zT_87 = sl_str_id;
    zT_90 = zF_9134020D_stringInternerGet(zT_86, zT_87);
    sl_bytes = zT_90;
    zT_92 = sl_bytes.len;
    zT_93 = (unsigned int)zT_92;
    sl_len = zT_93;
    goto z_bb_30;
    z_bb_30:
    zT_95 = self->registry;
    zT_97 = sl_len;
    zT_100 = zF_BA693C74_typeRegistryGetOrCr(zT_95, (unsigned int)(8), zT_97);
    sl_arr = zT_100;
    zT_101 = self->registry;
    zT_102 = sl_arr;
    zT_106 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_101, zT_102, (unsigned char)(1));
    result = zT_106;
    goto z_bb_27;
    z_bb_31:
    zT_111 = self;
    zT_112 = node_idx;
    zT_113 = zF_8C008E53_semanticAnalyzerRes(zT_111, zT_112);
    result = zT_113;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_27;
    z_bb_33:
    zT_114 = node.kind;
    if ((unsigned char)(zT_114 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_118 = self->expected_type_stack_len;
    zT_119 = 0;
    if ((unsigned char)(zT_118 > (unsigned int)zT_119)) goto z_bb_37; else goto z_bb_39;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_231 = node.kind;
    if ((unsigned char)(zT_231 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_59; else goto z_bb_61;
    z_bb_37:
    zT_122 = self->expected_type_stack_items;
    zT_123 = self->expected_type_stack_len;
    zT_124 = 1;
    zT_125 = zT_123 - zT_124;
    zT_126 = zT_122[zT_125];
    top = zT_126;
    zT_127 = 0;
    if ((unsigned char)(top != (unsigned int)zT_127)) goto z_bb_40; else goto z_bb_42;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_230 = 1;
    result = zT_230;
    goto z_bb_38;
    z_bb_40:
    zT_130 = 0;
    zT_131 = (unsigned int)zT_130;
    es = zT_131;
    zT_133 = self->registry;
    zT_134 = zT_133->types_items;
    zT_135 = (unsigned int)top;
    zT_136 = zT_134[zT_135];
    tty = zT_136;
    eff_top = top;
    zT_138 = tty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_229 = 1;
    result = zT_229;
    goto z_bb_41;
    z_bb_43:
    zT_143 = self->registry;
    zT_144 = zT_143->opt_items;
    zT_145 = tty.payload_idx;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zT_144[zT_146];
    zT_148 = zT_147.payload;
    opt_pay = zT_148;
    zT_149 = self->registry;
    zT_150 = zT_149->types_items;
    zT_151 = (unsigned int)opt_pay;
    zT_152 = zT_150[zT_151];
    tty = zT_152;
    eff_top = opt_pay;
    goto z_bb_44;
    z_bb_44:
    zT_153 = tty.kind;
    if ((unsigned char)(zT_153 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_45; else goto z_bb_47;
    z_bb_45:
    es = eff_top;
    goto z_bb_46;
    z_bb_46:
    zT_167 = 0;
    if ((unsigned char)(es != (unsigned int)zT_167)) goto z_bb_50; else goto z_bb_52;
    z_bb_47:
    zT_157 = tty.kind;
    if ((unsigned char)(zT_157 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_161 = self->registry;
    zT_162 = zT_161->eu_items;
    zT_163 = tty.payload_idx;
    zT_164 = (unsigned int)zT_163;
    zT_165 = zT_162[zT_164];
    zT_166 = zT_165.error_set;
    es = zT_166;
    goto z_bb_49;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_170 = self->store;
    zT_171 = node_idx;
    zT_173 = zF_8BA26B9E_astStoreNodePayload(zT_170, zT_171);
    name_id = zT_173;
    zT_175 = self->registry;
    zT_176 = es;
    zT_177 = name_id;
    zT_179 = zF_D2ECD176_typeRegistryErrorSe(zT_175, zT_176, zT_177);
    ord = zT_179;
    if ((unsigned char)(ord != (unsigned int)(4294967295u))) goto z_bb_53; else goto z_bb_55;
    z_bb_51:
    goto z_bb_41;
    z_bb_52:
    zT_220 = tty.kind;
    if ((unsigned char)(zT_220 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_56; else goto z_bb_58;
    z_bb_53:
    zT_183 = self->error_code_registry;
    zT_184 = name_id;
    zT_186 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_183, zT_184);
    reg_code = zT_186;
    zT_187 = self->enum_value_table;
    zT_188 = node_idx;
    zT_189 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_187, zT_188, zT_189);
    zT_191 = self->type_table;
    zT_192 = node_idx;
    zT_193 = es;
    zF_19B4A07D_resolvedTypeTableSe(zT_191, zT_192, zT_193);
    result = es;
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_196 = node.span_start;
    sp = zT_196;
    zT_198 = node.span_len;
    zT_200 = sp + (unsigned int)((unsigned int)zT_198);
    ep = zT_200;
    zT_202 = "error literal not found in error set";
    zT_204 = 36;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    eln_msg = zT_203;
    zT_205 = self->diag;
    zT_208 = self->source_file_id;
    zT_209 = sp;
    zT_210 = ep;
    zT_211 = eln_msg;
    zT_218 = zF_C82559AC_diagnosticCollector(zT_205, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3011_ERROR_LITERAL_NOT_IN_SET)), zT_208, zT_209, zT_210, zT_211);
    (void)zT_218;
    zT_219 = 1;
    result = zT_219;
    goto z_bb_54;
    z_bb_56:
    zT_224 = self->type_table;
    zT_225 = node_idx;
    zT_226 = eff_top;
    zF_19B4A07D_resolvedTypeTableSe(zT_224, zT_225, zT_226);
    result = eff_top;
    goto z_bb_57;
    z_bb_57:
    goto z_bb_51;
    z_bb_58:
    zT_228 = 1;
    result = zT_228;
    goto z_bb_57;
    z_bb_59:
    zT_235 = self;
    zT_236 = self->module_id;
    zT_240 = self->store;
    zT_241 = node_idx;
    zT_243 = zF_53458827_astStoreIdentifier(zT_240, zT_241);
    zT_237 = zT_243;
    zT_238 = node_idx;
    zT_244 = zF_9F1ECA79_semanticAnalyzerRes(zT_235, zT_236, zT_237, zT_238);
    result = zT_244;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_35;
    z_bb_61:
    zT_245 = node.kind;
    if ((unsigned char)(zT_245 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    zT_249 = self;
    zT_250 = node_idx;
    zT_251 = zF_DDD991E1_semanticAnalyzerRes(zT_249, zT_250);
    result = zT_251;
    zT_253 = "FAD:R";
    zT_255 = 5;
    zT_254.ptr = zT_253;
    zT_254.len = zT_255;
    fad = zT_254;
    zT_256 = fad;
    zT_257 = result;
    zF_C914CB83_markerWriteInt(zT_256, zT_257);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_258 = node.kind;
    if ((unsigned char)(zT_258 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_65; else goto z_bb_67;
    z_bb_65:
    zT_262 = self;
    zT_263 = node_idx;
    zT_264 = zF_1926BC05_semanticAnalyzerRes(zT_262, zT_263);
    result = zT_264;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_265 = node.kind;
    if ((unsigned char)(zT_265 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_68; else goto z_bb_70;
    z_bb_68:
    zT_269 = self;
    zT_270 = node_idx;
    zT_271 = zF_F902E73E_semanticAnalyzerRes(zT_269, zT_270);
    result = zT_271;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_66;
    z_bb_70:
    zT_272 = node.kind;
    if ((unsigned char)(zT_272 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_71; else goto z_bb_73;
    z_bb_71:
    zT_277 = self;
    zT_278 = node.child_0;
    zT_280 = zF_54F95822_semanticAnalyzerRes(zT_277, zT_278);
    base = zT_280;
    if ((unsigned char)(base != (unsigned int)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    goto z_bb_69;
    z_bb_73:
    zT_308 = node.kind;
    if ((unsigned char)(zT_308 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_86; else goto z_bb_88;
    z_bb_74:
    zT_283 = base != (unsigned int)(1);
    goto z_bb_76;
    z_bb_75:
    zT_283 = 0;
    goto z_bb_76;
    z_bb_76:
    if (zT_283) goto z_bb_77; else goto z_bb_79;
    z_bb_77:
    zT_287 = self->registry;
    zT_288 = zT_287->types_items;
    zT_289 = (unsigned int)base;
    zT_290 = zT_288[zT_289];
    bt = zT_290;
    zT_291 = bt.kind;
    if ((unsigned char)(zT_291 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_81; else goto z_bb_80;
    z_bb_78:
    goto z_bb_72;
    z_bb_79:
    zT_307 = 1;
    result = zT_307;
    goto z_bb_78;
    z_bb_80:
    zT_296 = bt.kind;
    zT_295 = zT_296 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_82;
    z_bb_81:
    zT_295 = 1;
    goto z_bb_82;
    z_bb_82:
    if (zT_295) goto z_bb_83; else goto z_bb_85;
    z_bb_83:
    zT_301 = self->registry;
    zT_302 = zT_301->ptr_items;
    zT_303 = bt.payload_idx;
    zT_304 = (unsigned int)zT_303;
    zT_305 = zT_302[zT_304];
    pp = zT_305;
    zT_306 = pp.base;
    result = zT_306;
    goto z_bb_84;
    z_bb_84:
    goto z_bb_78;
    z_bb_85:
    result = base;
    goto z_bb_84;
    z_bb_86:
    zT_313 = self;
    zT_314 = node.child_0;
    zT_316 = zF_54F95822_semanticAnalyzerRes(zT_313, zT_314);
    base = zT_316;
    if ((unsigned char)(base != (unsigned int)(0))) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    goto z_bb_72;
    z_bb_88:
    zT_432 = node.kind;
    if ((unsigned char)(zT_432 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_113; else goto z_bb_115;
    z_bb_89:
    zT_319 = base != (unsigned int)(1);
    goto z_bb_91;
    z_bb_90:
    zT_319 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_319) goto z_bb_92; else goto z_bb_94;
    z_bb_92:
    zT_323 = self->store;
    zT_324 = node.child_0;
    zT_327 = zF_FCDD1D35_astStoreNodeAt(zT_323, zT_324);
    base_node = zT_327;
    zT_328 = base_node.kind;
    if ((unsigned char)(zT_328 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_95; else goto z_bb_96;
    z_bb_93:
    goto z_bb_87;
    z_bb_94:
    zT_431 = 1;
    result = zT_431;
    goto z_bb_93;
    z_bb_95:
    zT_333 = self;
    zT_334 = base_node.child_0;
    zT_336 = zF_54F95822_semanticAnalyzerRes(zT_333, zT_334);
    fa_base_t = zT_336;
    st = fa_base_t;
    if ((unsigned char)(fa_base_t != (unsigned int)(0))) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    zT_425 = self->registry;
    zT_426 = base;
    zT_430 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_425, zT_426, (unsigned char)(0));
    result = zT_430;
    goto z_bb_93;
    z_bb_97:
    zT_340 = fa_base_t != (unsigned int)(1);
    goto z_bb_99;
    z_bb_98:
    zT_340 = 0;
    goto z_bb_99;
    z_bb_99:
    if (zT_340) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_344 = self->registry;
    zT_345 = zT_344->types_items;
    zT_346 = (unsigned int)st;
    zT_347 = zT_345[zT_346];
    st_ty = zT_347;
    zT_348 = st_ty.kind;
    if ((unsigned char)(zT_348 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_103; else goto z_bb_102;
    z_bb_101:
    goto z_bb_96;
    z_bb_102:
    zT_353 = st_ty.kind;
    zT_352 = zT_353 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_104;
    z_bb_103:
    zT_352 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_352) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_357 = self->registry;
    zT_358 = zT_357->ptr_items;
    zT_359 = st_ty.payload_idx;
    zT_360 = (unsigned int)zT_359;
    zT_361 = zT_358[zT_360];
    zT_362 = zT_361.base;
    st = zT_362;
    zT_363 = self->registry;
    zT_364 = zT_363->types_items;
    zT_365 = (unsigned int)st;
    zT_366 = zT_364[zT_365];
    st_ty = zT_366;
    goto z_bb_106;
    z_bb_106:
    zT_367 = st_ty.kind;
    if ((unsigned char)(zT_367 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_372 = self;
    zT_373 = st;
    zT_374 = zF_1BB4D489_semanticAnalyzerPac(zT_372, zT_373);
    sd = zT_374;
    if ((unsigned char)(sd != (unsigned int)(0))) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    zT_399 = st_ty.kind;
    if ((unsigned char)(zT_399 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_111; else goto z_bb_112;
    z_bb_109:
    zT_378 = node.span_start;
    aps = zT_378;
    zT_380 = node.span_len;
    zT_382 = aps + (unsigned int)((unsigned int)zT_380);
    ape = zT_382;
    zT_384 = "cannot take the address of a field of a packed struct; packed fields have no address";
    zT_386 = 84;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    aof_msg = zT_385;
    zT_387 = self->diag;
    zT_390 = self->source_file_id;
    zT_391 = aps;
    zT_392 = ape;
    zT_393 = aof_msg;
    zT_398 = zF_C82559AC_diagnosticCollector(zT_387, (unsigned char)(0), (unsigned short)(3000), zT_390, zT_391, zT_392, zT_393);
    (void)zT_398;
    goto z_bb_110;
    z_bb_110:
    goto z_bb_108;
    z_bb_111:
    zT_404 = node.span_start;
    apu_s = zT_404;
    zT_406 = node.span_len;
    zT_408 = apu_s + (unsigned int)((unsigned int)zT_406);
    apu_e = zT_408;
    zT_410 = "cannot take the address of a field of a packed union; packed fields have no address";
    zT_412 = 83;
    zT_411.ptr = zT_410;
    zT_411.len = zT_412;
    aou_msg = zT_411;
    zT_413 = self->diag;
    zT_416 = self->source_file_id;
    zT_417 = apu_s;
    zT_418 = apu_e;
    zT_419 = aou_msg;
    zT_424 = zF_C82559AC_diagnosticCollector(zT_413, (unsigned char)(0), (unsigned short)(3000), zT_416, zT_417, zT_418, zT_419);
    (void)zT_424;
    goto z_bb_112;
    z_bb_112:
    goto z_bb_101;
    z_bb_113:
    zT_436 = self;
    zT_437 = node_idx;
    zT_438 = zF_87E78775_semanticAnalyzerRes(zT_436, zT_437);
    result = zT_438;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_87;
    z_bb_115:
    zT_439 = node.kind;
    if ((unsigned char)(zT_439 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_444 = self;
    zT_445 = node.child_0;
    zT_447 = zF_CAF1FD28_semanticAnalyzerIsB(zT_444, zT_445);
    zT_443 = !zT_447;
    goto z_bb_118;
    z_bb_117:
    zT_443 = 0;
    goto z_bb_118;
    z_bb_118:
    if (zT_443) goto z_bb_119; else goto z_bb_121;
    z_bb_119:
    zT_450 = "unsupported builtin function";
    zT_452 = 28;
    zT_451.ptr = zT_450;
    zT_451.len = zT_452;
    ub_msg = zT_451;
    zT_453 = self->diag;
    zT_456 = self->source_file_id;
    zT_457 = node.span_start;
    zT_465 = node.span_start;
    zT_466 = node.span_len;
    zT_459 = ub_msg;
    zT_469 = zF_C82559AC_diagnosticCollector(zT_453, (unsigned char)(0), (unsigned short)(3000), zT_456, zT_457, (unsigned int)(zT_465 + (unsigned int)((unsigned int)zT_466)), zT_459);
    (void)zT_469;
    zT_470 = 1;
    result = zT_470;
    goto z_bb_120;
    z_bb_120:
    goto z_bb_114;
    z_bb_121:
    zT_471 = node.kind;
    if ((unsigned char)(zT_471 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_122; else goto z_bb_124;
    z_bb_122:
    zT_476 = self->store;
    zT_477 = node_idx;
    zT_479 = zF_152E19CB_astStoreNodeExtraCh(zT_476, zT_477);
    zT_480 = (unsigned int)zT_479;
    ec_n = zT_480;
    zT_482 = "@cVaArg";
    zT_484 = 7;
    zT_483.ptr = zT_482;
    zT_483.len = zT_484;
    cva = zT_483;
    zT_485 = node.child_0;
    zT_486 = self->size_of_name_id;
    if ((unsigned char)(zT_485 == zT_486)) goto z_bb_126; else goto z_bb_125;
    z_bb_123:
    goto z_bb_120;
    z_bb_124:
    zT_1343 = node.kind;
    if ((unsigned char)(zT_1343 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_332; else goto z_bb_334;
    z_bb_125:
    zT_489 = node.child_0;
    zT_490 = self->align_of_name_id;
    zT_488 = zT_489 == zT_490;
    goto z_bb_127;
    z_bb_126:
    zT_488 = 1;
    goto z_bb_127;
    z_bb_127:
    if (zT_488) goto z_bb_129; else goto z_bb_128;
    z_bb_128:
    zT_493 = node.child_0;
    zT_494 = self->offset_of_name_id;
    zT_492 = zT_493 == zT_494;
    goto z_bb_130;
    z_bb_129:
    zT_492 = 1;
    goto z_bb_130;
    z_bb_130:
    if (zT_492) goto z_bb_132; else goto z_bb_131;
    z_bb_131:
    zT_497 = node.child_0;
    zT_498 = self->bit_size_of_name_id;
    zT_496 = zT_497 == zT_498;
    goto z_bb_133;
    z_bb_132:
    zT_496 = 1;
    goto z_bb_133;
    z_bb_133:
    if (zT_496) goto z_bb_135; else goto z_bb_134;
    z_bb_134:
    zT_501 = node.child_0;
    zT_502 = self->bit_offset_of_name_id;
    zT_500 = zT_501 == zT_502;
    goto z_bb_136;
    z_bb_135:
    zT_500 = 1;
    goto z_bb_136;
    z_bb_136:
    if (zT_500) goto z_bb_137; else goto z_bb_139;
    z_bb_137:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_140; else goto z_bb_141;
    z_bb_138:
    goto z_bb_123;
    z_bb_139:
    zT_531 = node.child_0;
    zT_532 = self->ptrtoint_name_id;
    if ((unsigned char)(zT_531 == zT_532)) goto z_bb_143; else goto z_bb_142;
    z_bb_140:
    zT_508 = self->store;
    zT_507.store = zT_508;
    zT_509 = self->registry;
    zT_507.typereg = zT_509;
    zT_510 = self->symbols;
    zT_507.symbol_reg = zT_510;
    zT_511 = self->interner;
    zT_507.interner = zT_511;
    zT_512 = self->module_id;
    zT_507.module_id = zT_512;
    zT_513 = self->diag;
    zT_514.has_value = 1;
    zT_514.value = zT_513;
    zT_507.diag = zT_514;
    zT_515.has_value = 0;
    zT_507.local_consts = zT_515;
    zT_516.has_value = 0;
    zT_507.local_types = zT_516;
    zT_517 = self->source_file_id;
    zT_507.source_file_id = zT_517;
    so_env = zT_507;
    zT_518 = &so_env;
    zT_522 = self->store;
    zT_523 = node_idx;
    zT_527 = zF_B10B1BC1_astStoreNodeExtraCh(zT_522, zT_523, (unsigned int)(0));
    zT_519 = zT_527;
    zT_529 = zF_F2107C15_resolveTypeExprFull(zT_518, zT_519, (unsigned int)(0));
    (void)zT_529;
    goto z_bb_141;
    z_bb_141:
    zT_530 = 19;
    result = zT_530;
    goto z_bb_138;
    z_bb_142:
    zT_535 = node.child_0;
    zT_536 = self->int_from_ptr_name_id;
    zT_534 = zT_535 == zT_536;
    goto z_bb_144;
    z_bb_143:
    zT_534 = 1;
    goto z_bb_144;
    z_bb_144:
    if (zT_534) goto z_bb_145; else goto z_bb_147;
    z_bb_145:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_148; else goto z_bb_149;
    z_bb_146:
    goto z_bb_138;
    z_bb_147:
    zT_550 = node.child_0;
    zT_551 = self->ptr_from_int_name_id;
    if ((unsigned char)(zT_550 == zT_551)) goto z_bb_150; else goto z_bb_152;
    z_bb_148:
    zT_540 = self;
    zT_542 = self->store;
    zT_543 = node_idx;
    zT_547 = zF_B10B1BC1_astStoreNodeExtraCh(zT_542, zT_543, (unsigned int)(0));
    zT_541 = zT_547;
    zT_548 = zF_54F95822_semanticAnalyzerRes(zT_540, zT_541);
    (void)zT_548;
    goto z_bb_149;
    z_bb_149:
    zT_549 = 13;
    result = zT_549;
    goto z_bb_146;
    z_bb_150:
    zT_555 = 1;
    pfi_res = zT_555;
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_153; else goto z_bb_154;
    z_bb_151:
    goto z_bb_146;
    z_bb_152:
    zT_614 = node.child_0;
    zT_615 = self->field_parent_ptr_name_id;
    if ((unsigned char)(zT_614 == zT_615)) goto z_bb_167; else goto z_bb_169;
    z_bb_153:
    zT_558 = self;
    zT_560 = self->store;
    zT_561 = node_idx;
    zT_565 = zF_B10B1BC1_astStoreNodeExtraCh(zT_560, zT_561, (unsigned int)(0));
    zT_559 = zT_565;
    zT_566 = zF_54F95822_semanticAnalyzerRes(zT_558, zT_559);
    (void)zT_566;
    zT_568 = self;
    zT_569 = zF_4DE7C2BC_topExpectedType(zT_568);
    pfi_top = zT_569;
    if ((unsigned char)(pfi_top != (unsigned int)(0))) goto z_bb_155; else goto z_bb_156;
    z_bb_154:
    if ((unsigned char)(pfi_res == (unsigned int)(1))) goto z_bb_165; else goto z_bb_166;
    z_bb_155:
    zT_572 = pfi_top != (unsigned int)(18);
    goto z_bb_157;
    z_bb_156:
    zT_572 = 0;
    goto z_bb_157;
    z_bb_157:
    if (zT_572) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_576 = self->registry;
    zT_577 = zT_576->types_items;
    zT_578 = (unsigned int)pfi_top;
    zT_579 = zT_577[zT_578];
    pfi_ty = zT_579;
    zT_580 = pfi_ty.kind;
    if ((unsigned char)(zT_580 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_161; else goto z_bb_160;
    z_bb_159:
    goto z_bb_154;
    z_bb_160:
    zT_585 = pfi_ty.kind;
    zT_584 = zT_585 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_162;
    z_bb_161:
    zT_584 = 1;
    goto z_bb_162;
    z_bb_162:
    if (zT_584) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    pfi_res = pfi_top;
    goto z_bb_164;
    z_bb_164:
    goto z_bb_159;
    z_bb_165:
    zT_592 = "cannot infer pointer type for @ptrFromInt; annotate the target variable type";
    zT_594 = 76;
    zT_593.ptr = zT_592;
    zT_593.len = zT_594;
    pfi_msg = zT_593;
    zT_595 = self->diag;
    zT_598 = self->source_file_id;
    zT_599 = node.span_start;
    zT_609 = node.span_start;
    zT_610 = node.span_len;
    zT_601 = pfi_msg;
    zT_613 = zF_C82559AC_diagnosticCollector(zT_595, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_598, zT_599, (unsigned int)(zT_609 + (unsigned int)((unsigned int)zT_610)), zT_601);
    (void)zT_613;
    goto z_bb_166;
    z_bb_166:
    result = pfi_res;
    goto z_bb_151;
    z_bb_167:
    zT_619 = 1;
    fpp_res = zT_619;
    if ((unsigned char)(ec_n >= (unsigned int)(3))) goto z_bb_170; else goto z_bb_171;
    z_bb_168:
    goto z_bb_151;
    z_bb_169:
    zT_664 = node.child_0;
    zT_665 = self->bitcast_name_id;
    if ((unsigned char)(zT_664 == zT_665)) goto z_bb_174; else goto z_bb_176;
    z_bb_170:
    zT_624 = self->store;
    zT_623.store = zT_624;
    zT_625 = self->registry;
    zT_623.typereg = zT_625;
    zT_626 = self->symbols;
    zT_623.symbol_reg = zT_626;
    zT_627 = self->interner;
    zT_623.interner = zT_627;
    zT_628 = self->module_id;
    zT_623.module_id = zT_628;
    zT_629 = self->diag;
    zT_630.has_value = 1;
    zT_630.value = zT_629;
    zT_623.diag = zT_630;
    zT_631.has_value = 0;
    zT_623.local_consts = zT_631;
    zT_632.has_value = 0;
    zT_623.local_types = zT_632;
    zT_633 = self->source_file_id;
    zT_623.source_file_id = zT_633;
    fpp_env = zT_623;
    zT_635 = &fpp_env;
    zT_639 = self->store;
    zT_640 = node_idx;
    zT_644 = zF_B10B1BC1_astStoreNodeExtraCh(zT_639, zT_640, (unsigned int)(0));
    zT_636 = zT_644;
    zT_646 = zF_F2107C15_resolveTypeExprFull(zT_635, zT_636, (unsigned int)(0));
    fpp_outer = zT_646;
    if ((unsigned char)(fpp_outer != (unsigned int)(18))) goto z_bb_172; else goto z_bb_173;
    z_bb_171:
    result = fpp_res;
    goto z_bb_168;
    z_bb_172:
    zT_649 = self;
    zT_651 = self->store;
    zT_652 = node_idx;
    zT_656 = zF_B10B1BC1_astStoreNodeExtraCh(zT_651, zT_652, (unsigned int)(2));
    zT_650 = zT_656;
    zT_657 = zF_54F95822_semanticAnalyzerRes(zT_649, zT_650);
    (void)zT_657;
    zT_658 = self->registry;
    zT_659 = fpp_outer;
    zT_663 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_658, zT_659, (unsigned char)(0));
    fpp_res = zT_663;
    goto z_bb_173;
    z_bb_173:
    goto z_bb_171;
    z_bb_174:
    zT_669 = 1;
    bc_res = zT_669;
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_177; else goto z_bb_178;
    z_bb_175:
    goto z_bb_168;
    z_bb_176:
    zT_770 = node.child_0;
    zT_771 = self->getchar_name_id;
    if ((unsigned char)(zT_770 == zT_771)) goto z_bb_199; else goto z_bb_201;
    z_bb_177:
    zT_674 = self->store;
    zT_673.store = zT_674;
    zT_675 = self->registry;
    zT_673.typereg = zT_675;
    zT_676 = self->symbols;
    zT_673.symbol_reg = zT_676;
    zT_677 = self->interner;
    zT_673.interner = zT_677;
    zT_678 = self->module_id;
    zT_673.module_id = zT_678;
    zT_679 = self->diag;
    zT_680.has_value = 1;
    zT_680.value = zT_679;
    zT_673.diag = zT_680;
    zT_681.has_value = 0;
    zT_673.local_consts = zT_681;
    zT_682.has_value = 0;
    zT_673.local_types = zT_682;
    zT_683 = self->source_file_id;
    zT_673.source_file_id = zT_683;
    bc_env = zT_673;
    zT_685 = &bc_env;
    zT_689 = self->store;
    zT_690 = node_idx;
    zT_694 = zF_B10B1BC1_astStoreNodeExtraCh(zT_689, zT_690, (unsigned int)(0));
    zT_686 = zT_694;
    zT_696 = zF_F2107C15_resolveTypeExprFull(zT_685, zT_686, (unsigned int)(0));
    bc_dst = zT_696;
    if ((unsigned char)(bc_dst != (unsigned int)(18))) goto z_bb_179; else goto z_bb_180;
    z_bb_178:
    result = bc_res;
    goto z_bb_175;
    z_bb_179:
    zT_700 = self;
    zT_702 = self->store;
    zT_703 = node_idx;
    zT_707 = zF_B10B1BC1_astStoreNodeExtraCh(zT_702, zT_703, (unsigned int)(1));
    zT_701 = zT_707;
    zT_708 = zF_54F95822_semanticAnalyzerRes(zT_700, zT_701);
    bc_src = zT_708;
    zT_710 = 0;
    bc_ok = zT_710;
    if ((unsigned char)(bc_src != (unsigned int)(18))) goto z_bb_181; else goto z_bb_182;
    z_bb_180:
    goto z_bb_178;
    z_bb_181:
    zT_714 = self->registry;
    zT_715 = bc_dst;
    zT_717 = zF_3290E9C4_typeRegistryIsInteg(zT_714, zT_715);
    zT_713 = zT_717;
    goto z_bb_183;
    z_bb_182:
    zT_713 = 0;
    goto z_bb_183;
    z_bb_183:
    if (zT_713) goto z_bb_184; else goto z_bb_185;
    z_bb_184:
    zT_719 = self->registry;
    zT_720 = bc_src;
    zT_722 = zF_3290E9C4_typeRegistryIsInteg(zT_719, zT_720);
    zT_718 = zT_722;
    goto z_bb_186;
    z_bb_185:
    zT_718 = 0;
    goto z_bb_186;
    z_bb_186:
    if (zT_718) goto z_bb_187; else goto z_bb_188;
    z_bb_187:
    zT_724 = self->registry;
    zT_725 = zT_724->types_items;
    zT_726 = (unsigned int)bc_dst;
    zT_727 = zT_725[zT_726];
    bc_dty = zT_727;
    zT_729 = self->registry;
    zT_730 = zT_729->types_items;
    zT_731 = (unsigned int)bc_src;
    zT_732 = zT_730[zT_731];
    bc_sty = zT_732;
    zT_733 = bc_dty.state;
    if ((unsigned char)(zT_733 == (unsigned char)(2))) goto z_bb_189; else goto z_bb_190;
    z_bb_188:
    bc_res = bc_dst;
    if ((unsigned char)(bc_ok == (unsigned char)(0))) goto z_bb_197; else goto z_bb_198;
    z_bb_189:
    zT_737 = bc_sty.state;
    zT_736 = zT_737 == (unsigned char)(2);
    goto z_bb_191;
    z_bb_190:
    zT_736 = 0;
    goto z_bb_191;
    z_bb_191:
    if (zT_736) goto z_bb_192; else goto z_bb_193;
    z_bb_192:
    zT_741 = bc_dty.size;
    zT_742 = bc_sty.size;
    zT_740 = zT_741 == zT_742;
    goto z_bb_194;
    z_bb_193:
    zT_740 = 0;
    goto z_bb_194;
    z_bb_194:
    if (zT_740) goto z_bb_195; else goto z_bb_196;
    z_bb_195:
    zT_744 = 1;
    bc_ok = zT_744;
    goto z_bb_196;
    z_bb_196:
    goto z_bb_188;
    z_bb_197:
    zT_748 = "@bitCast requires same-size integer source and destination types";
    zT_750 = 64;
    zT_749.ptr = zT_748;
    zT_749.len = zT_750;
    bc_msg = zT_749;
    zT_751 = self->diag;
    zT_754 = self->source_file_id;
    zT_755 = node.span_start;
    zT_765 = node.span_start;
    zT_766 = node.span_len;
    zT_757 = bc_msg;
    zT_769 = zF_C82559AC_diagnosticCollector(zT_751, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_754, zT_755, (unsigned int)(zT_765 + (unsigned int)((unsigned int)zT_766)), zT_757);
    (void)zT_769;
    goto z_bb_198;
    z_bb_198:
    goto z_bb_180;
    z_bb_199:
    zT_773 = 8;
    result = zT_773;
    goto z_bb_200;
    z_bb_200:
    goto z_bb_175;
    z_bb_201:
    zT_774 = node.child_0;
    zT_775 = self->exit_name_id;
    if ((unsigned char)(zT_774 == zT_775)) goto z_bb_202; else goto z_bb_204;
    z_bb_202:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_205; else goto z_bb_206;
    z_bb_203:
    goto z_bb_200;
    z_bb_204:
    zT_789 = node.child_0;
    zT_790 = self->panic_name_id;
    if ((unsigned char)(zT_789 == zT_790)) goto z_bb_207; else goto z_bb_209;
    z_bb_205:
    zT_779 = self;
    zT_781 = self->store;
    zT_782 = node_idx;
    zT_786 = zF_B10B1BC1_astStoreNodeExtraCh(zT_781, zT_782, (unsigned int)(0));
    zT_780 = zT_786;
    zT_787 = zF_54F95822_semanticAnalyzerRes(zT_779, zT_780);
    (void)zT_787;
    goto z_bb_206;
    z_bb_206:
    zT_788 = 3;
    result = zT_788;
    goto z_bb_203;
    z_bb_207:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_210; else goto z_bb_211;
    z_bb_208:
    goto z_bb_203;
    z_bb_209:
    zT_804 = node.child_0;
    zT_805 = self->putchar_name_id;
    if ((unsigned char)(zT_804 == zT_805)) goto z_bb_213; else goto z_bb_212;
    z_bb_210:
    zT_794 = self;
    zT_796 = self->store;
    zT_797 = node_idx;
    zT_801 = zF_B10B1BC1_astStoreNodeExtraCh(zT_796, zT_797, (unsigned int)(0));
    zT_795 = zT_801;
    zT_802 = zF_54F95822_semanticAnalyzerRes(zT_794, zT_795);
    (void)zT_802;
    goto z_bb_211;
    z_bb_211:
    zT_803 = 3;
    result = zT_803;
    goto z_bb_208;
    z_bb_212:
    zT_808 = node.child_0;
    zT_809 = self->sleep_ms_name_id;
    zT_807 = zT_808 == zT_809;
    goto z_bb_214;
    z_bb_213:
    zT_807 = 1;
    goto z_bb_214;
    z_bb_214:
    if (zT_807) goto z_bb_215; else goto z_bb_217;
    z_bb_215:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_218; else goto z_bb_219;
    z_bb_216:
    goto z_bb_208;
    z_bb_217:
    zT_823 = node.child_0;
    zT_824 = self->stdout_write_name_id;
    if ((unsigned char)(zT_823 == zT_824)) goto z_bb_221; else goto z_bb_220;
    z_bb_218:
    zT_813 = self;
    zT_815 = self->store;
    zT_816 = node_idx;
    zT_820 = zF_B10B1BC1_astStoreNodeExtraCh(zT_815, zT_816, (unsigned int)(0));
    zT_814 = zT_820;
    zT_821 = zF_54F95822_semanticAnalyzerRes(zT_813, zT_814);
    (void)zT_821;
    goto z_bb_219;
    z_bb_219:
    zT_822 = 1;
    result = zT_822;
    goto z_bb_216;
    z_bb_220:
    zT_827 = node.child_0;
    zT_828 = self->stderr_write_name_id;
    zT_826 = zT_827 == zT_828;
    goto z_bb_222;
    z_bb_221:
    zT_826 = 1;
    goto z_bb_222;
    z_bb_222:
    if (zT_826) goto z_bb_223; else goto z_bb_225;
    z_bb_223:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_226; else goto z_bb_228;
    z_bb_224:
    goto z_bb_216;
    z_bb_225:
    zT_862 = node.child_0;
    zT_863 = self->is_windows_name_id;
    if ((unsigned char)(zT_862 == zT_863)) goto z_bb_231; else goto z_bb_233;
    z_bb_226:
    zT_832 = self;
    zT_834 = self->store;
    zT_835 = node_idx;
    zT_839 = zF_B10B1BC1_astStoreNodeExtraCh(zT_834, zT_835, (unsigned int)(0));
    zT_833 = zT_839;
    zT_840 = zF_54F95822_semanticAnalyzerRes(zT_832, zT_833);
    (void)zT_840;
    zT_841 = self;
    zT_843 = self->store;
    zT_844 = node_idx;
    zT_848 = zF_B10B1BC1_astStoreNodeExtraCh(zT_843, zT_844, (unsigned int)(1));
    zT_842 = zT_848;
    zT_849 = zF_54F95822_semanticAnalyzerRes(zT_841, zT_842);
    (void)zT_849;
    goto z_bb_227;
    z_bb_227:
    zT_861 = 1;
    result = zT_861;
    goto z_bb_224;
    z_bb_228:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_229; else goto z_bb_230;
    z_bb_229:
    zT_852 = self;
    zT_854 = self->store;
    zT_855 = node_idx;
    zT_859 = zF_B10B1BC1_astStoreNodeExtraCh(zT_854, zT_855, (unsigned int)(0));
    zT_853 = zT_859;
    zT_860 = zF_54F95822_semanticAnalyzerRes(zT_852, zT_853);
    (void)zT_860;
    goto z_bb_230;
    z_bb_230:
    goto z_bb_227;
    z_bb_231:
    zT_865 = 2;
    result = zT_865;
    goto z_bb_232;
    z_bb_232:
    goto z_bb_224;
    z_bb_233:
    zT_866 = node.child_0;
    zT_867 = self->console_clear_name_id;
    if ((unsigned char)(zT_866 == zT_867)) goto z_bb_234; else goto z_bb_236;
    z_bb_234:
    zT_869 = 1;
    result = zT_869;
    goto z_bb_235;
    z_bb_235:
    goto z_bb_232;
    z_bb_236:
    zT_870 = node.child_0;
    zT_871 = self->console_gotoxy_name_id;
    if ((unsigned char)(zT_870 == zT_871)) goto z_bb_238; else goto z_bb_237;
    z_bb_237:
    zT_874 = node.child_0;
    zT_875 = self->console_set_color_name_id;
    zT_873 = zT_874 == zT_875;
    goto z_bb_239;
    z_bb_238:
    zT_873 = 1;
    goto z_bb_239;
    z_bb_239:
    if (zT_873) goto z_bb_240; else goto z_bb_242;
    z_bb_240:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_243; else goto z_bb_245;
    z_bb_241:
    goto z_bb_235;
    z_bb_242:
    zT_909 = node.child_0;
    zT_910 = self->async_frame_size_name_id;
    if ((unsigned char)(zT_909 == zT_910)) goto z_bb_248; else goto z_bb_250;
    z_bb_243:
    zT_879 = self;
    zT_881 = self->store;
    zT_882 = node_idx;
    zT_886 = zF_B10B1BC1_astStoreNodeExtraCh(zT_881, zT_882, (unsigned int)(0));
    zT_880 = zT_886;
    zT_887 = zF_54F95822_semanticAnalyzerRes(zT_879, zT_880);
    (void)zT_887;
    zT_888 = self;
    zT_890 = self->store;
    zT_891 = node_idx;
    zT_895 = zF_B10B1BC1_astStoreNodeExtraCh(zT_890, zT_891, (unsigned int)(1));
    zT_889 = zT_895;
    zT_896 = zF_54F95822_semanticAnalyzerRes(zT_888, zT_889);
    (void)zT_896;
    goto z_bb_244;
    z_bb_244:
    zT_908 = 1;
    result = zT_908;
    goto z_bb_241;
    z_bb_245:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    zT_899 = self;
    zT_901 = self->store;
    zT_902 = node_idx;
    zT_906 = zF_B10B1BC1_astStoreNodeExtraCh(zT_901, zT_902, (unsigned int)(0));
    zT_900 = zT_906;
    zT_907 = zF_54F95822_semanticAnalyzerRes(zT_899, zT_900);
    (void)zT_907;
    goto z_bb_247;
    z_bb_247:
    goto z_bb_244;
    z_bb_248:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_251; else goto z_bb_252;
    z_bb_249:
    goto z_bb_241;
    z_bb_250:
    zT_980 = node.child_0;
    zT_981 = self->async_init_name_id;
    if ((unsigned char)(zT_980 == zT_981)) goto z_bb_259; else goto z_bb_261;
    z_bb_251:
    zT_914 = self;
    zT_916 = self->store;
    zT_917 = node_idx;
    zT_921 = zF_B10B1BC1_astStoreNodeExtraCh(zT_916, zT_917, (unsigned int)(0));
    zT_915 = zT_921;
    zT_922 = zF_54F95822_semanticAnalyzerRes(zT_914, zT_915);
    (void)zT_922;
    zT_924 = 0;
    afs_susp = zT_924;
    zT_925 = self->store;
    zT_926 = self->symbols;
    zT_927 = self->module_id;
    zT_932 = self->store;
    zT_933 = node_idx;
    zT_937 = zF_B10B1BC1_astStoreNodeExtraCh(zT_932, zT_933, (unsigned int)(0));
    zT_928 = zT_937;
    zT_938 = zF_860C82EC_resolveCalleeKey(zT_925, zT_926, zT_927, zT_928);
    zT_939 = zT_938.has_value;
    if (zT_939) goto z_bb_253; else goto z_bb_254;
    z_bb_252:
    zT_979 = 19;
    result = zT_979;
    goto z_bb_249;
    z_bb_253:
    afs_k = zT_938.value;
    zT_944 = (unsigned int)(zT_79FAE712_u64)(afs_k >> (zT_79FAE712_u64)(32));
    afs_mid = zT_944;
    zT_948 = (unsigned int)(zT_79FAE712_u64)(afs_k & (zT_79FAE712_u64)(4294967295u));
    afs_nid = zT_948;
    zT_949 = self->suspending_fns;
    zT_950 = afs_mid;
    zT_951 = afs_nid;
    zT_953 = zF_7C7E43BF_asyncIsSuspending(zT_949, zT_950, zT_951);
    if (zT_953) goto z_bb_255; else goto z_bb_256;
    z_bb_254:
    if ((unsigned char)(!afs_susp)) goto z_bb_257; else goto z_bb_258;
    z_bb_255:
    zT_954 = 1;
    afs_susp = zT_954;
    goto z_bb_256;
    z_bb_256:
    goto z_bb_254;
    z_bb_257:
    zT_957 = "@asyncFrameSize argument must be a known suspending function";
    zT_959 = 60;
    zT_958.ptr = zT_957;
    zT_958.len = zT_959;
    e3046 = zT_958;
    zT_960 = self->diag;
    zT_963 = self->source_file_id;
    zT_964 = node.span_start;
    zT_974 = node.span_start;
    zT_975 = node.span_len;
    zT_966 = e3046;
    zT_978 = zF_C82559AC_diagnosticCollector(zT_960, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3046_ASYNC_FRAME_SIZE_INVALID)), zT_963, zT_964, (unsigned int)(zT_974 + (unsigned int)((unsigned int)zT_975)), zT_966);
    (void)zT_978;
    goto z_bb_258;
    z_bb_258:
    goto z_bb_252;
    z_bb_259:
    if ((unsigned char)(ec_n >= (unsigned int)(4))) goto z_bb_262; else goto z_bb_263;
    z_bb_260:
    goto z_bb_249;
    z_bb_261:
    zT_1030 = node.child_0;
    zT_1031 = self->async_resume_name_id;
    if ((unsigned char)(zT_1030 == zT_1031)) goto z_bb_264; else goto z_bb_266;
    z_bb_262:
    zT_985 = self;
    zT_987 = self->store;
    zT_988 = node_idx;
    zT_992 = zF_B10B1BC1_astStoreNodeExtraCh(zT_987, zT_988, (unsigned int)(0));
    zT_986 = zT_992;
    zT_993 = zF_54F95822_semanticAnalyzerRes(zT_985, zT_986);
    (void)zT_993;
    zT_994 = self;
    zT_996 = self->store;
    zT_997 = node_idx;
    zT_1001 = zF_B10B1BC1_astStoreNodeExtraCh(zT_996, zT_997, (unsigned int)(1));
    zT_995 = zT_1001;
    zT_1002 = zF_54F95822_semanticAnalyzerRes(zT_994, zT_995);
    (void)zT_1002;
    zT_1003 = self;
    zT_1005 = self->store;
    zT_1006 = node_idx;
    zT_1010 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1005, zT_1006, (unsigned int)(2));
    zT_1004 = zT_1010;
    zT_1011 = zF_54F95822_semanticAnalyzerRes(zT_1003, zT_1004);
    (void)zT_1011;
    zT_1012 = self;
    zT_1014 = self->store;
    zT_1015 = node_idx;
    zT_1019 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1014, zT_1015, (unsigned int)(3));
    zT_1013 = zT_1019;
    zT_1020 = zF_54F95822_semanticAnalyzerRes(zT_1012, zT_1013);
    (void)zT_1020;
    goto z_bb_263;
    z_bb_263:
    zT_1021 = self;
    zT_1022 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1021, zT_1022);
    zT_1023 = self->registry;
    zT_1029 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1023, (unsigned int)(1), (unsigned char)(0));
    result = zT_1029;
    goto z_bb_260;
    z_bb_264:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_267; else goto z_bb_268;
    z_bb_265:
    goto z_bb_260;
    z_bb_266:
    zT_1066 = node.child_0;
    zT_1067 = self->async_suspend_name_id;
    if ((unsigned char)(zT_1066 == zT_1067)) goto z_bb_269; else goto z_bb_271;
    z_bb_267:
    zT_1035 = self;
    zT_1037 = self->store;
    zT_1038 = node_idx;
    zT_1042 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1037, zT_1038, (unsigned int)(0));
    zT_1036 = zT_1042;
    zT_1043 = zF_54F95822_semanticAnalyzerRes(zT_1035, zT_1036);
    (void)zT_1043;
    zT_1044 = self;
    zT_1046 = self->store;
    zT_1047 = node_idx;
    zT_1051 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1046, zT_1047, (unsigned int)(1));
    zT_1045 = zT_1051;
    zT_1052 = zF_54F95822_semanticAnalyzerRes(zT_1044, zT_1045);
    (void)zT_1052;
    goto z_bb_268;
    z_bb_268:
    zT_1053 = self;
    zT_1054 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1053, zT_1054);
    zT_1055 = self->registry;
    zT_1058 = self->registry;
    zT_1064 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1058, (unsigned int)(1), (unsigned char)(0));
    zT_1056 = zT_1064;
    zT_1065 = zF_74A7234F_typeRegistryGetOrCr(zT_1055, zT_1056);
    result = zT_1065;
    goto z_bb_265;
    z_bb_269:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_272; else goto z_bb_273;
    z_bb_270:
    goto z_bb_265;
    z_bb_271:
    zT_1091 = node.child_0;
    zT_1092 = self->ptrcast_name_id;
    if ((unsigned char)(zT_1091 == zT_1092)) goto z_bb_274; else goto z_bb_275;
    z_bb_272:
    zT_1071 = self;
    zT_1073 = self->store;
    zT_1074 = node_idx;
    zT_1078 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1073, zT_1074, (unsigned int)(0));
    zT_1072 = zT_1078;
    zT_1079 = zF_54F95822_semanticAnalyzerRes(zT_1071, zT_1072);
    (void)zT_1079;
    goto z_bb_273;
    z_bb_273:
    zT_1080 = self;
    zT_1081 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1080, zT_1081);
    zT_1082 = self;
    zT_1083 = node_idx;
    zF_D4D0798B_semanticAnalyzerDia(zT_1082, zT_1083);
    zT_1084 = self->registry;
    zT_1090 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1084, (unsigned int)(1), (unsigned char)(0));
    result = zT_1090;
    goto z_bb_270;
    z_bb_274:
    zT_1094 = ec_n != (unsigned int)(2);
    goto z_bb_276;
    z_bb_275:
    zT_1094 = 0;
    goto z_bb_276;
    z_bb_276:
    if (zT_1094) goto z_bb_277; else goto z_bb_279;
    z_bb_277:
    zT_1098 = "@ptrCast requires exactly two arguments: @ptrCast(T, expr)";
    zT_1100 = 58;
    zT_1099.ptr = zT_1098;
    zT_1099.len = zT_1100;
    pc3049 = zT_1099;
    zT_1101 = self->diag;
    zT_1104 = self->source_file_id;
    zT_1105 = node.span_start;
    zT_1115 = node.span_start;
    zT_1116 = node.span_len;
    zT_1107 = pc3049;
    zT_1119 = zF_C82559AC_diagnosticCollector(zT_1101, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3049_PTRCAST_REQUIRES_TWO_ARGS)), zT_1104, zT_1105, (unsigned int)(zT_1115 + (unsigned int)((unsigned int)zT_1116)), zT_1107);
    (void)zT_1119;
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_280; else goto z_bb_281;
    z_bb_278:
    goto z_bb_270;
    z_bb_279:
    zT_1132 = self;
    zT_1133 = node.child_0;
    zT_1134 = cva;
    zT_1136 = zF_2ACB4E23_semanticAnalyzerBui(zT_1132, zT_1133, zT_1134);
    if (zT_1136) goto z_bb_282; else goto z_bb_284;
    z_bb_280:
    zT_1122 = self;
    zT_1124 = self->store;
    zT_1125 = node_idx;
    zT_1129 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1124, zT_1125, (unsigned int)(0));
    zT_1123 = zT_1129;
    zT_1130 = zF_54F95822_semanticAnalyzerRes(zT_1122, zT_1123);
    (void)zT_1130;
    goto z_bb_281;
    z_bb_281:
    zT_1131 = 18;
    result = zT_1131;
    goto z_bb_278;
    z_bb_282:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_285; else goto z_bb_287;
    z_bb_283:
    goto z_bb_278;
    z_bb_284:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_288; else goto z_bb_290;
    z_bb_285:
    zT_1139 = self;
    zT_1141 = self->store;
    zT_1142 = node_idx;
    zT_1146 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1141, zT_1142, (unsigned int)(0));
    zT_1140 = zT_1146;
    zT_1147 = zF_54F95822_semanticAnalyzerRes(zT_1139, zT_1140);
    (void)zT_1147;
    zT_1150 = self->store;
    zT_1149.store = zT_1150;
    zT_1151 = self->registry;
    zT_1149.typereg = zT_1151;
    zT_1152 = self->symbols;
    zT_1149.symbol_reg = zT_1152;
    zT_1153 = self->interner;
    zT_1149.interner = zT_1153;
    zT_1154 = self->module_id;
    zT_1149.module_id = zT_1154;
    zT_1155 = self->diag;
    zT_1156.has_value = 1;
    zT_1156.value = zT_1155;
    zT_1149.diag = zT_1156;
    zT_1157.has_value = 0;
    zT_1149.local_consts = zT_1157;
    zT_1158.has_value = 0;
    zT_1149.local_types = zT_1158;
    zT_1159 = self->source_file_id;
    zT_1149.source_file_id = zT_1159;
    cva_env = zT_1149;
    zT_1160 = &cva_env;
    zT_1164 = self->store;
    zT_1165 = node_idx;
    zT_1169 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1164, zT_1165, (unsigned int)(1));
    zT_1161 = zT_1169;
    zT_1171 = zF_F2107C15_resolveTypeExprFull(zT_1160, zT_1161, (unsigned int)(0));
    result = zT_1171;
    goto z_bb_286;
    z_bb_286:
    goto z_bb_283;
    z_bb_287:
    zT_1172 = 1;
    result = zT_1172;
    goto z_bb_286;
    z_bb_288:
    zT_1175 = self;
    zT_1176 = node.child_0;
    zT_1178 = zF_3757023F_semanticAnalyzerIsT(zT_1175, zT_1176);
    if (zT_1178) goto z_bb_291; else goto z_bb_293;
    z_bb_289:
    goto z_bb_283;
    z_bb_290:
    zT_1291 = node.child_0;
    zT_1292 = self->enumtoint_name_id;
    if ((unsigned char)(zT_1291 == zT_1292)) goto z_bb_314; else goto z_bb_315;
    z_bb_291:
    zT_1180 = self;
    zT_1182 = self->store;
    zT_1183 = node_idx;
    zT_1187 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1182, zT_1183, (unsigned int)(1));
    zT_1181 = zT_1187;
    zT_1188 = zF_54F95822_semanticAnalyzerRes(zT_1180, zT_1181);
    tv_src = zT_1188;
    zT_1191 = self->store;
    zT_1190.store = zT_1191;
    zT_1192 = self->registry;
    zT_1190.typereg = zT_1192;
    zT_1193 = self->symbols;
    zT_1190.symbol_reg = zT_1193;
    zT_1194 = self->interner;
    zT_1190.interner = zT_1194;
    zT_1195 = self->module_id;
    zT_1190.module_id = zT_1195;
    zT_1196 = self->diag;
    zT_1197.has_value = 1;
    zT_1197.value = zT_1196;
    zT_1190.diag = zT_1197;
    zT_1198.has_value = 0;
    zT_1190.local_consts = zT_1198;
    zT_1199.has_value = 0;
    zT_1190.local_types = zT_1199;
    zT_1200 = self->source_file_id;
    zT_1190.source_file_id = zT_1200;
    tre_env = zT_1190;
    zT_1201 = &tre_env;
    zT_1205 = self->store;
    zT_1206 = node_idx;
    zT_1210 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1205, zT_1206, (unsigned int)(0));
    zT_1202 = zT_1210;
    zT_1212 = zF_F2107C15_resolveTypeExprFull(zT_1201, zT_1202, (unsigned int)(0));
    result = zT_1212;
    zT_1213 = node.child_0;
    zT_1214 = self->ptrcast_name_id;
    if ((unsigned char)(zT_1213 == zT_1214)) goto z_bb_294; else goto z_bb_295;
    z_bb_292:
    goto z_bb_289;
    z_bb_293:
    zT_1282 = self;
    zT_1284 = self->store;
    zT_1285 = node_idx;
    zT_1289 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1284, zT_1285, (unsigned int)(0));
    zT_1283 = zT_1289;
    zT_1290 = zF_54F95822_semanticAnalyzerRes(zT_1282, zT_1283);
    result = zT_1290;
    goto z_bb_292;
    z_bb_294:
    zT_1216 = tv_src != (unsigned int)(18);
    goto z_bb_296;
    z_bb_295:
    zT_1216 = 0;
    goto z_bb_296;
    z_bb_296:
    if (zT_1216) goto z_bb_297; else goto z_bb_298;
    z_bb_297:
    zT_1219 = result != (unsigned int)(18);
    goto z_bb_299;
    z_bb_298:
    zT_1219 = 0;
    goto z_bb_299;
    z_bb_299:
    if (zT_1219) goto z_bb_300; else goto z_bb_301;
    z_bb_300:
    zT_1222 = self;
    zT_1223 = tv_src;
    zT_1224 = result;
    zT_1225 = zF_5F2042EA_semanticAnalyzerPtr(zT_1222, zT_1223, zT_1224);
    if (zT_1225) goto z_bb_302; else goto z_bb_303;
    z_bb_301:
    zT_1247 = node.child_0;
    zT_1248 = self->volatilecast_name_id;
    if ((unsigned char)(zT_1247 == zT_1248)) goto z_bb_304; else goto z_bb_305;
    z_bb_302:
    zT_1227 = "@ptrCast cannot discard the 'volatile' qualifier; use @volatileCast to remove it";
    zT_1229 = 80;
    zT_1228.ptr = zT_1227;
    zT_1228.len = zT_1229;
    pcq_msg = zT_1228;
    zT_1230 = self->diag;
    zT_1233 = self->source_file_id;
    zT_1234 = node.span_start;
    zT_1242 = node.span_start;
    zT_1243 = node.span_len;
    zT_1236 = pcq_msg;
    zT_1246 = zF_C82559AC_diagnosticCollector(zT_1230, (unsigned char)(0), (unsigned short)(3000), zT_1233, zT_1234, (unsigned int)(zT_1242 + (unsigned int)((unsigned int)zT_1243)), zT_1236);
    (void)zT_1246;
    goto z_bb_303;
    z_bb_303:
    goto z_bb_301;
    z_bb_304:
    zT_1250 = tv_src != (unsigned int)(18);
    goto z_bb_306;
    z_bb_305:
    zT_1250 = 0;
    goto z_bb_306;
    z_bb_306:
    if (zT_1250) goto z_bb_307; else goto z_bb_308;
    z_bb_307:
    zT_1253 = result != (unsigned int)(18);
    goto z_bb_309;
    z_bb_308:
    zT_1253 = 0;
    goto z_bb_309;
    z_bb_309:
    if (zT_1253) goto z_bb_310; else goto z_bb_311;
    z_bb_310:
    zT_1256 = self;
    zT_1257 = tv_src;
    zT_1258 = result;
    zT_1259 = zF_EC29CB82_semanticAnalyzerVol(zT_1256, zT_1257, zT_1258);
    if ((unsigned char)(!zT_1259)) goto z_bb_312; else goto z_bb_313;
    z_bb_311:
    goto z_bb_292;
    z_bb_312:
    zT_1262 = "@volatileCast requires a volatile pointer source and a destination with the same base type";
    zT_1264 = 90;
    zT_1263.ptr = zT_1262;
    zT_1263.len = zT_1264;
    vcc_msg = zT_1263;
    zT_1265 = self->diag;
    zT_1268 = self->source_file_id;
    zT_1269 = node.span_start;
    zT_1277 = node.span_start;
    zT_1278 = node.span_len;
    zT_1271 = vcc_msg;
    zT_1281 = zF_C82559AC_diagnosticCollector(zT_1265, (unsigned char)(0), (unsigned short)(3000), zT_1268, zT_1269, (unsigned int)(zT_1277 + (unsigned int)((unsigned int)zT_1278)), zT_1271);
    (void)zT_1281;
    goto z_bb_313;
    z_bb_313:
    goto z_bb_311;
    z_bb_314:
    zT_1294 = ec_n >= (unsigned int)(1);
    goto z_bb_316;
    z_bb_315:
    zT_1294 = 0;
    goto z_bb_316;
    z_bb_316:
    if (zT_1294) goto z_bb_317; else goto z_bb_319;
    z_bb_317:
    zT_1298 = self;
    zT_1300 = self->store;
    zT_1301 = node_idx;
    zT_1305 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1300, zT_1301, (unsigned int)(0));
    zT_1299 = zT_1305;
    zT_1306 = zF_54F95822_semanticAnalyzerRes(zT_1298, zT_1299);
    e2i_arg = zT_1306;
    e2i_res = e2i_arg;
    if ((unsigned char)(e2i_arg != (unsigned int)(18))) goto z_bb_320; else goto z_bb_321;
    z_bb_318:
    goto z_bb_289;
    z_bb_319:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_329; else goto z_bb_331;
    z_bb_320:
    zT_1311 = self->registry;
    zT_1312 = zT_1311->types_items;
    zT_1313 = (unsigned int)e2i_arg;
    zT_1314 = zT_1312[zT_1313];
    e2i_ty = zT_1314;
    zT_1315 = e2i_ty.kind;
    if ((unsigned char)(zT_1315 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_322; else goto z_bb_323;
    z_bb_321:
    result = e2i_res;
    goto z_bb_318;
    z_bb_322:
    zT_1320 = self->registry;
    zT_1321 = e2i_arg;
    zT_1323 = zF_014D7530_typeRegistryEnumBac(zT_1320, zT_1321);
    e2i_bt = zT_1323;
    if ((unsigned char)(e2i_bt != (unsigned int)(18))) goto z_bb_324; else goto z_bb_325;
    z_bb_323:
    goto z_bb_321;
    z_bb_324:
    zT_1328 = self->registry;
    zT_1329 = zT_1328->types_len;
    zT_1326 = (unsigned int)((unsigned int)e2i_bt) < zT_1329;
    goto z_bb_326;
    z_bb_325:
    zT_1326 = 0;
    goto z_bb_326;
    z_bb_326:
    if (zT_1326) goto z_bb_327; else goto z_bb_328;
    z_bb_327:
    e2i_res = e2i_bt;
    goto z_bb_328;
    z_bb_328:
    goto z_bb_323;
    z_bb_329:
    zT_1333 = self;
    zT_1335 = self->store;
    zT_1336 = node_idx;
    zT_1340 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1335, zT_1336, (unsigned int)(0));
    zT_1334 = zT_1340;
    zT_1341 = zF_54F95822_semanticAnalyzerRes(zT_1333, zT_1334);
    result = zT_1341;
    goto z_bb_330;
    z_bb_330:
    goto z_bb_318;
    z_bb_331:
    zT_1342 = 1;
    result = zT_1342;
    goto z_bb_330;
    z_bb_332:
    zT_1347 = self;
    zT_1348 = node.child_0;
    zT_1350 = zF_54F95822_semanticAnalyzerRes(zT_1347, zT_1348);
    (void)zT_1350;
    zT_1351 = 2;
    result = zT_1351;
    goto z_bb_333;
    z_bb_333:
    goto z_bb_123;
    z_bb_334:
    zT_1352 = node.kind;
    if ((unsigned char)(zT_1352 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_336; else goto z_bb_335;
    z_bb_335:
    zT_1357 = node.kind;
    zT_1356 = zT_1357 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_negate);
    goto z_bb_337;
    z_bb_336:
    zT_1356 = 1;
    goto z_bb_337;
    z_bb_337:
    if (zT_1356) goto z_bb_338; else goto z_bb_340;
    z_bb_338:
    zT_1361 = self;
    zT_1362 = node_idx;
    zT_1363 = zF_09421FDF_semanticAnalyzerRes(zT_1361, zT_1362);
    result = zT_1363;
    goto z_bb_339;
    z_bb_339:
    goto z_bb_333;
    z_bb_340:
    zT_1364 = node.kind;
    if ((unsigned char)(zT_1364 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_341; else goto z_bb_343;
    z_bb_341:
    zT_1368 = self;
    zT_1369 = node_idx;
    zT_1370 = zF_6B59E8AD_semanticAnalyzerRes(zT_1368, zT_1369);
    result = zT_1370;
    goto z_bb_342;
    z_bb_342:
    goto z_bb_339;
    z_bb_343:
    zT_1371 = node.kind;
    if ((unsigned char)(zT_1371 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_344; else goto z_bb_346;
    z_bb_344:
    zT_1375 = self;
    zT_1376 = node_idx;
    zT_1377 = zF_B78F27CD_semanticAnalyzerRes(zT_1375, zT_1376);
    result = zT_1377;
    goto z_bb_345;
    z_bb_345:
    goto z_bb_342;
    z_bb_346:
    zT_1378 = node.kind;
    if ((unsigned char)(zT_1378 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_347; else goto z_bb_349;
    z_bb_347:
    zT_1383 = 0;
    zT_1384 = (unsigned int)zT_1383;
    catch_es = zT_1384;
    zT_1385 = self;
    zT_1386 = node.child_0;
    zT_1388 = zF_54F95822_semanticAnalyzerRes(zT_1385, zT_1386);
    result = zT_1388;
    if ((unsigned char)(result != (unsigned int)(18))) goto z_bb_350; else goto z_bb_351;
    z_bb_348:
    goto z_bb_345;
    z_bb_349:
    zT_1495 = node.kind;
    if ((unsigned char)(zT_1495 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_367; else goto z_bb_369;
    z_bb_350:
    zT_1392 = self->registry;
    zT_1393 = zT_1392->types_items;
    zT_1394 = (unsigned int)result;
    zT_1395 = zT_1393[zT_1394];
    clt = zT_1395;
    zT_1396 = clt.kind;
    if ((unsigned char)(zT_1396 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_352; else goto z_bb_353;
    z_bb_351:
    zT_1421 = self->local_decl_count;
    zT_1422 = (unsigned int)zT_1421;
    catch_scope_saved = zT_1422;
    zT_1423 = node.child_2;
    zT_1424 = 0;
    if ((unsigned char)(zT_1423 != (unsigned int)zT_1424)) goto z_bb_354; else goto z_bb_355;
    z_bb_352:
    zT_1400 = self->registry;
    zT_1401 = zT_1400->eu_items;
    zT_1402 = clt.payload_idx;
    zT_1403 = (unsigned int)zT_1402;
    zT_1404 = zT_1401[zT_1403];
    zT_1405 = zT_1404.error_set;
    catch_es = zT_1405;
    zT_1406 = self->registry;
    zT_1407 = zT_1406->eu_items;
    zT_1408 = clt.payload_idx;
    zT_1409 = (unsigned int)zT_1408;
    zT_1410 = zT_1407[zT_1409];
    zT_1411 = zT_1410.payload;
    result = zT_1411;
    zT_1412 = self->coercion_table;
    zT_1413 = node.child_0;
    zT_1415 = result;
    zF_D21AE60A_coercionTableAdd(zT_1412, zT_1413, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_1415);
    goto z_bb_353;
    z_bb_353:
    goto z_bb_351;
    z_bb_354:
    zT_1427 = self->store;
    zT_1428 = node.child_2;
    zT_1431 = zF_FCDD1D35_astStoreNodeAt(zT_1427, zT_1428);
    capture_node = zT_1431;
    zT_1432 = self;
    zT_1436 = self->store;
    zT_1437 = node.child_2;
    zT_1440 = zF_8BA26B9E_astStoreNodePayload(zT_1436, zT_1437);
    zT_1433 = zT_1440;
    zT_1434 = capture_node.span_start;
    zT_1442 = capture_node.span_start;
    zT_1443 = capture_node.span_len;
    zF_C999EE08_semanticAnalyzerChe(zT_1432, zT_1433, zT_1434, (unsigned int)(zT_1442 + (unsigned int)((unsigned int)zT_1443)));
    zT_1446 = self->local_decl_count;
    zT_1447 = self->local_decl_cap;
    if ((unsigned char)(zT_1446 >= zT_1447)) goto z_bb_356; else goto z_bb_357;
    z_bb_355:
    zT_1469 = node.child_1;
    if ((unsigned char)(zT_1469 != (unsigned int)(0))) goto z_bb_361; else goto z_bb_362;
    z_bb_356:
    zT_1449 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_1449);
    goto z_bb_357;
    z_bb_357:
    zT_1450 = self->store;
    zT_1451 = node.child_2;
    zT_1454 = zF_8BA26B9E_astStoreNodePayload(zT_1450, zT_1451);
    zT_1455 = self->local_decl_names;
    zT_1456 = self->local_decl_count;
    zT_1455[zT_1456] = zT_1454;
    zT_1457 = 0;
    if ((unsigned char)(catch_es != (unsigned int)zT_1457)) goto z_bb_358; else goto z_bb_359;
    z_bb_358:
    zT_1459 = catch_es;
    goto z_bb_360;
    z_bb_359:
    zT_1459 = 6;
    goto z_bb_360;
    z_bb_360:
    zT_1461 = self->local_decl_types;
    zT_1462 = self->local_decl_count;
    zT_1461[zT_1462] = zT_1459;
    zT_1463 = 1;
    zT_1464 = self->local_decl_consts;
    zT_1465 = self->local_decl_count;
    zT_1464[zT_1465] = zT_1463;
    zT_1466 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_1466 + (unsigned int)(1));
    goto z_bb_355;
    z_bb_361:
    zT_1472 = 0;
    if ((unsigned char)(catch_es != (unsigned int)zT_1472)) goto z_bb_363; else goto z_bb_364;
    z_bb_362:
    self->local_decl_count = (unsigned int)((unsigned int)catch_scope_saved);
    goto z_bb_348;
    z_bb_363:
    zT_1475 = self->store;
    zT_1476 = node.child_1;
    zT_1479 = zF_FCDD1D35_astStoreNodeAt(zT_1475, zT_1476);
    child1 = zT_1479;
    zT_1480 = child1.kind;
    if ((unsigned char)(zT_1480 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_365; else goto z_bb_366;
    z_bb_364:
    zT_1491 = self;
    zT_1492 = node.child_1;
    zF_10A0DC35_semanticAnalyzerRes(zT_1491, zT_1492);
    goto z_bb_362;
    z_bb_365:
    zT_1484 = self;
    zT_1485 = catch_es;
    zF_9665A229_pushExpectedType(zT_1484, zT_1485);
    zT_1486 = self;
    zT_1487 = node.child_1;
    zT_1489 = zF_54F95822_semanticAnalyzerRes(zT_1486, zT_1487);
    (void)zT_1489;
    zT_1490 = self;
    zF_BC478E78_popExpectedType(zT_1490);
    goto z_bb_366;
    z_bb_366:
    goto z_bb_364;
    z_bb_367:
    zT_1500 = self->local_decl_count;
    zT_1501 = (unsigned int)zT_1500;
    orelse_scope_saved = zT_1501;
    zT_1502 = self;
    zT_1503 = node_idx;
    zT_1504 = zF_B36961FA_semanticAnalyzerRes(zT_1502, zT_1503);
    result = zT_1504;
    self->local_decl_count = (unsigned int)((unsigned int)orelse_scope_saved);
    goto z_bb_368;
    z_bb_368:
    goto z_bb_348;
    z_bb_369:
    zT_1506 = node.kind;
    if ((unsigned char)(zT_1506 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_371; else goto z_bb_370;
    z_bb_370:
    zT_1511 = node.kind;
    zT_1510 = zT_1511 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt);
    goto z_bb_372;
    z_bb_371:
    zT_1510 = 1;
    goto z_bb_372;
    z_bb_372:
    if (zT_1510) goto z_bb_373; else goto z_bb_375;
    z_bb_373:
    zT_1515 = 1;
    result = zT_1515;
    goto z_bb_374;
    z_bb_374:
    goto z_bb_368;
    z_bb_375:
    zT_1516 = node.kind;
    if ((unsigned char)(zT_1516 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_377; else goto z_bb_376;
    z_bb_376:
    zT_1521 = node.kind;
    zT_1520 = zT_1521 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt);
    goto z_bb_378;
    z_bb_377:
    zT_1520 = 1;
    goto z_bb_378;
    z_bb_378:
    if (zT_1520) goto z_bb_380; else goto z_bb_379;
    z_bb_379:
    zT_1526 = node.kind;
    zT_1525 = zT_1526 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_381;
    z_bb_380:
    zT_1525 = 1;
    goto z_bb_381;
    z_bb_381:
    if (zT_1525) goto z_bb_383; else goto z_bb_382;
    z_bb_382:
    zT_1531 = node.kind;
    zT_1530 = zT_1531 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt);
    goto z_bb_384;
    z_bb_383:
    zT_1530 = 1;
    goto z_bb_384;
    z_bb_384:
    if (zT_1530) goto z_bb_385; else goto z_bb_387;
    z_bb_385:
    zT_1535 = self;
    zT_1536 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_1535, zT_1536);
    zT_1537 = 1;
    result = zT_1537;
    goto z_bb_386;
    z_bb_386:
    goto z_bb_374;
    z_bb_387:
    zT_1538 = node.kind;
    if ((unsigned char)(zT_1538 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_388; else goto z_bb_390;
    z_bb_388:
    zT_1543 = self->local_decl_count;
    zT_1544 = (unsigned int)zT_1543;
    ifexpr_scope_saved = zT_1544;
    zT_1545 = self;
    zT_1546 = node_idx;
    zT_1547 = zF_8B8EE70D_semanticAnalyzerRes(zT_1545, zT_1546);
    result = zT_1547;
    self->local_decl_count = (unsigned int)((unsigned int)ifexpr_scope_saved);
    goto z_bb_389;
    z_bb_389:
    goto z_bb_386;
    z_bb_390:
    zT_1549 = node.kind;
    if ((unsigned char)(zT_1549 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_391; else goto z_bb_393;
    z_bb_391:
    zT_1553 = self;
    zT_1554 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_1553, zT_1554);
    zT_1555 = node.child_2;
    if ((unsigned char)(zT_1555 != (unsigned int)(0))) goto z_bb_394; else goto z_bb_395;
    z_bb_392:
    goto z_bb_389;
    z_bb_393:
    zT_1568 = node.kind;
    if ((unsigned char)(zT_1568 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_398; else goto z_bb_400;
    z_bb_394:
    zT_1558 = self;
    zT_1559 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_1558, zT_1559);
    goto z_bb_395;
    z_bb_395:
    zT_1561 = node.child_1;
    if ((unsigned char)(zT_1561 != (unsigned int)(0))) goto z_bb_396; else goto z_bb_397;
    z_bb_396:
    zT_1564 = self;
    zT_1565 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1564, zT_1565);
    goto z_bb_397;
    z_bb_397:
    zT_1567 = 1;
    result = zT_1567;
    goto z_bb_392;
    z_bb_398:
    zT_1572 = self;
    zT_1573 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_1572, zT_1573);
    zT_1574 = node.child_1;
    zT_1575 = 0;
    if ((unsigned char)(zT_1574 != (unsigned int)zT_1575)) goto z_bb_401; else goto z_bb_402;
    z_bb_399:
    goto z_bb_392;
    z_bb_400:
    zT_1581 = node.kind;
    if ((unsigned char)(zT_1581 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_403; else goto z_bb_405;
    z_bb_401:
    zT_1577 = self;
    zT_1578 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1577, zT_1578);
    goto z_bb_402;
    z_bb_402:
    zT_1580 = 1;
    result = zT_1580;
    goto z_bb_399;
    z_bb_403:
    zT_1585 = self;
    zT_1586 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_1585, zT_1586);
    zT_1587 = node.child_1;
    zT_1588 = 0;
    if ((unsigned char)(zT_1587 != (unsigned int)zT_1588)) goto z_bb_406; else goto z_bb_407;
    z_bb_404:
    goto z_bb_399;
    z_bb_405:
    zT_1594 = node.kind;
    if ((unsigned char)(zT_1594 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_408; else goto z_bb_410;
    z_bb_406:
    zT_1590 = self;
    zT_1591 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1590, zT_1591);
    goto z_bb_407;
    z_bb_407:
    zT_1593 = 1;
    result = zT_1593;
    goto z_bb_404;
    z_bb_408:
    zT_1598 = self;
    zT_1599 = node_idx;
    zT_1600 = zF_2DB4F186_semanticAnalyzerRes(zT_1598, zT_1599);
    result = zT_1600;
    goto z_bb_409;
    z_bb_409:
    goto z_bb_404;
    z_bb_410:
    zT_1601 = node.kind;
    if ((unsigned char)(zT_1601 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_411; else goto z_bb_413;
    z_bb_411:
    zT_1605 = self;
    zT_1606 = node_idx;
    zT_1607 = zF_227D2404_semanticAnalyzerRes(zT_1605, zT_1606);
    result = zT_1607;
    goto z_bb_412;
    z_bb_412:
    goto z_bb_409;
    z_bb_413:
    zT_1608 = node.kind;
    if ((unsigned char)(zT_1608 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_414; else goto z_bb_416;
    z_bb_414:
    zT_1612 = self;
    zT_1613 = node_idx;
    zT_1614 = zF_AD7EF126_semanticAnalyzerRes(zT_1612, zT_1613);
    result = zT_1614;
    goto z_bb_415;
    z_bb_415:
    goto z_bb_412;
    z_bb_416:
    zT_1615 = node.kind;
    if ((unsigned char)(zT_1615 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_417; else goto z_bb_419;
    z_bb_417:
    zT_1620 = "AW:R";
    zT_1622 = 4;
    zT_1621.ptr = zT_1620;
    zT_1621.len = zT_1622;
    ai_dbg = zT_1621;
    zT_1623 = ai_dbg;
    zT_1624 = result;
    zF_C914CB83_markerWriteInt(zT_1623, zT_1624);
    zT_1625 = self;
    zT_1626 = node_idx;
    zT_1627 = zF_F3DAABE0_semanticAnalyzerRes(zT_1625, zT_1626);
    result = zT_1627;
    goto z_bb_418;
    z_bb_418:
    goto z_bb_415;
    z_bb_419:
    zT_1628 = node.kind;
    if ((unsigned char)(zT_1628 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_421; else goto z_bb_420;
    z_bb_420:
    zT_1633 = node.kind;
    zT_1632 = zT_1633 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_422;
    z_bb_421:
    zT_1632 = 1;
    goto z_bb_422;
    z_bb_422:
    if (zT_1632) goto z_bb_424; else goto z_bb_423;
    z_bb_423:
    zT_1638 = node.kind;
    zT_1637 = zT_1638 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_425;
    z_bb_424:
    zT_1637 = 1;
    goto z_bb_425;
    z_bb_425:
    if (zT_1637) goto z_bb_427; else goto z_bb_426;
    z_bb_426:
    zT_1643 = node.kind;
    zT_1642 = zT_1643 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_428;
    z_bb_427:
    zT_1642 = 1;
    goto z_bb_428;
    z_bb_428:
    if (zT_1642) goto z_bb_430; else goto z_bb_429;
    z_bb_429:
    zT_1648 = node.kind;
    zT_1647 = zT_1648 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_431;
    z_bb_430:
    zT_1647 = 1;
    goto z_bb_431;
    z_bb_431:
    if (zT_1647) goto z_bb_433; else goto z_bb_432;
    z_bb_432:
    zT_1653 = node.kind;
    zT_1652 = zT_1653 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_434;
    z_bb_433:
    zT_1652 = 1;
    goto z_bb_434;
    z_bb_434:
    if (zT_1652) goto z_bb_436; else goto z_bb_435;
    z_bb_435:
    zT_1658 = node.kind;
    zT_1657 = zT_1658 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_437;
    z_bb_436:
    zT_1657 = 1;
    goto z_bb_437;
    z_bb_437:
    if (zT_1657) goto z_bb_439; else goto z_bb_438;
    z_bb_438:
    zT_1663 = node.kind;
    zT_1662 = zT_1663 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl);
    goto z_bb_440;
    z_bb_439:
    zT_1662 = 1;
    goto z_bb_440;
    z_bb_440:
    if (zT_1662) goto z_bb_442; else goto z_bb_441;
    z_bb_441:
    zT_1668 = node.kind;
    zT_1667 = zT_1668 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_443;
    z_bb_442:
    zT_1667 = 1;
    goto z_bb_443;
    z_bb_443:
    if (zT_1667) goto z_bb_445; else goto z_bb_444;
    z_bb_444:
    zT_1673 = node.kind;
    zT_1672 = zT_1673 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_446;
    z_bb_445:
    zT_1672 = 1;
    goto z_bb_446;
    z_bb_446:
    if (zT_1672) goto z_bb_448; else goto z_bb_447;
    z_bb_447:
    zT_1678 = node.kind;
    zT_1677 = zT_1678 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_449;
    z_bb_448:
    zT_1677 = 1;
    goto z_bb_449;
    z_bb_449:
    if (zT_1677) goto z_bb_450; else goto z_bb_452;
    z_bb_450:
    zT_1682 = node.kind;
    if ((unsigned char)(zT_1682 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_453; else goto z_bb_454;
    z_bb_451:
    goto z_bb_418;
    z_bb_452:
    zT_1697 = node.kind;
    if ((unsigned char)(zT_1697 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_457; else goto z_bb_459;
    z_bb_453:
    zT_1686 = self;
    zT_1687 = node_idx;
    zT_1688 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_1686, zT_1687, zT_1688);
    goto z_bb_454;
    z_bb_454:
    zT_1690 = node.kind;
    if ((unsigned char)(zT_1690 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_455; else goto z_bb_456;
    z_bb_455:
    zT_1694 = self;
    zT_1695 = node_idx;
    zF_E3AF2BA9_semanticAnalyzerChe(zT_1694, zT_1695);
    goto z_bb_456;
    z_bb_456:
    zT_1696 = 20;
    result = zT_1696;
    goto z_bb_451;
    z_bb_457:
    zT_1701 = self;
    zT_1702 = node.child_0;
    zT_1704 = zF_54F95822_semanticAnalyzerRes(zT_1701, zT_1702);
    result = zT_1704;
    goto z_bb_458;
    z_bb_458:
    goto z_bb_451;
    z_bb_459:
    zT_1705 = node.kind;
    if ((unsigned char)(zT_1705 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_460; else goto z_bb_462;
    z_bb_460:
    zT_1709 = self;
    zT_1710 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_1709, zT_1710);
    zT_1711 = 3;
    result = zT_1711;
    goto z_bb_461;
    z_bb_461:
    goto z_bb_458;
    z_bb_462:
    zT_1712 = node.kind;
    if ((unsigned char)(zT_1712 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_463; else goto z_bb_465;
    z_bb_463:
    zT_1716 = self;
    zT_1717 = node.child_0;
    zT_1719 = zF_54F95822_semanticAnalyzerRes(zT_1716, zT_1717);
    result = zT_1719;
    goto z_bb_464;
    z_bb_464:
    goto z_bb_461;
    z_bb_465:
    zT_1720 = node.kind;
    if ((unsigned char)(zT_1720 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_466; else goto z_bb_468;
    z_bb_466:
    zT_1724 = 1;
    result = zT_1724;
    goto z_bb_467;
    z_bb_467:
    goto z_bb_464;
    z_bb_468:
    zT_1725 = node.kind;
    if ((unsigned char)(zT_1725 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_469; else goto z_bb_471;
    z_bb_469:
    zT_1730 = self->local_decl_count;
    zT_1731 = (unsigned int)zT_1730;
    eblk_scope_saved = zT_1731;
    zT_1733 = self->stmt_work_len;
    eblk_work_base = zT_1733;
    zT_1735 = "EBLK:N";
    zT_1737 = 6;
    zT_1736.ptr = zT_1735;
    zT_1736.len = zT_1737;
    eblk_m = zT_1736;
    zT_1738 = eblk_m;
    zT_1739 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1738, zT_1739);
    zT_1741 = self->store;
    zT_1742 = node_idx;
    zT_1744 = zF_152E19CB_astStoreNodeExtraCh(zT_1741, zT_1742);
    children_n = zT_1744;
    zT_1746 = "EBLK:C";
    zT_1748 = 6;
    zT_1747.ptr = zT_1746;
    zT_1747.len = zT_1748;
    eblk_cm = zT_1747;
    zT_1749 = eblk_cm;
    zF_C914CB83_markerWriteInt(zT_1749, (unsigned int)((unsigned int)children_n));
    if ((unsigned char)(children_n > (unsigned int)(0))) goto z_bb_472; else goto z_bb_474;
    z_bb_470:
    goto z_bb_467;
    z_bb_471:
    zT_1823 = node.kind;
    if ((unsigned char)(zT_1823 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_489; else goto z_bb_488;
    z_bb_472:
    zT_1755 = 0;
    zT_1756 = (unsigned int)zT_1755;
    si = zT_1756;
    goto z_bb_475;
    z_bb_473:
    goto z_bb_479;
    z_bb_474:
    zT_1803 = 1;
    result = zT_1803;
    goto z_bb_473;
    z_bb_475:
    zT_1758 = 1;
    if ((unsigned char)(si < (unsigned int)((unsigned int)((unsigned int)children_n) - zT_1758))) goto z_bb_476; else goto z_bb_477;
    z_bb_476:
    zT_1762 = "EBLK:S";
    zT_1764 = 6;
    zT_1763.ptr = zT_1762;
    zT_1763.len = zT_1764;
    eblk_sm = zT_1763;
    zT_1765 = eblk_sm;
    zF_C914CB83_markerWriteInt(zT_1765, (unsigned int)((unsigned int)si));
    zT_1769 = "EBLK:D";
    zT_1771 = 6;
    zT_1770.ptr = zT_1769;
    zT_1770.len = zT_1771;
    eblk_cm2 = zT_1770;
    zT_1772 = eblk_cm2;
    zT_1774 = self->store;
    zT_1775 = node_idx;
    zT_1779 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1774, zT_1775, (unsigned int)((unsigned int)si));
    zT_1773 = zT_1779;
    zF_C914CB83_markerWriteInt(zT_1772, zT_1773);
    zT_1780 = self;
    zT_1782 = self->store;
    zT_1783 = node_idx;
    zT_1787 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1782, zT_1783, (unsigned int)((unsigned int)si));
    zT_1781 = zT_1787;
    zF_10A0DC35_semanticAnalyzerRes(zT_1780, zT_1781);
    goto z_bb_478;
    z_bb_477:
    zT_1792 = self->store;
    zT_1793 = node_idx;
    zT_1799 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1792, zT_1793, (unsigned int)((unsigned int)((unsigned int)children_n) - (unsigned int)(1)));
    last_child = zT_1799;
    zT_1800 = self;
    zT_1801 = last_child;
    zT_1802 = zF_54F95822_semanticAnalyzerRes(zT_1800, zT_1801);
    result = zT_1802;
    goto z_bb_473;
    z_bb_478:
    zT_1788 = 1;
    zT_1790 = si + (unsigned int)((unsigned int)zT_1788);
    si = zT_1790;
    goto z_bb_475;
    z_bb_479:
    zT_1804 = self->stmt_work_len;
    if ((unsigned char)(zT_1804 > eblk_work_base)) goto z_bb_480; else goto z_bb_481;
    z_bb_480:
    zT_1806 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_1806 - (unsigned int)(1));
    zT_1810 = self->stmt_work_items;
    zT_1811 = self->stmt_work_len;
    zT_1812 = zT_1810[zT_1811];
    eblk_wi = zT_1812;
    zT_1813 = self;
    zT_1814 = eblk_wi;
    zT_1815 = zF_2FC8BE84_semanticAnalyzerPop(zT_1813, zT_1814);
    if ((unsigned char)(!zT_1815)) goto z_bb_483; else goto z_bb_484;
    z_bb_481:
    self->local_decl_count = (unsigned int)((unsigned int)eblk_scope_saved);
    goto z_bb_470;
    z_bb_482:
    goto z_bb_479;
    z_bb_483:
    zT_1817 = eblk_wi != (unsigned int)(0);
    goto z_bb_485;
    z_bb_484:
    zT_1817 = 0;
    goto z_bb_485;
    z_bb_485:
    if (zT_1817) goto z_bb_486; else goto z_bb_487;
    z_bb_486:
    zT_1820 = self;
    zT_1821 = eblk_wi;
    zF_10A0DC35_semanticAnalyzerRes(zT_1820, zT_1821);
    goto z_bb_487;
    z_bb_487:
    goto z_bb_482;
    z_bb_488:
    zT_1828 = node.kind;
    zT_1827 = zT_1828 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_490;
    z_bb_489:
    zT_1827 = 1;
    goto z_bb_490;
    z_bb_490:
    if (zT_1827) goto z_bb_492; else goto z_bb_491;
    z_bb_491:
    zT_1833 = node.kind;
    zT_1832 = zT_1833 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_493;
    z_bb_492:
    zT_1832 = 1;
    goto z_bb_493;
    z_bb_493:
    if (zT_1832) goto z_bb_495; else goto z_bb_494;
    z_bb_494:
    zT_1838 = node.kind;
    zT_1837 = zT_1838 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_496;
    z_bb_495:
    zT_1837 = 1;
    goto z_bb_496;
    z_bb_496:
    if (zT_1837) goto z_bb_498; else goto z_bb_497;
    z_bb_497:
    zT_1843 = node.kind;
    zT_1842 = zT_1843 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_499;
    z_bb_498:
    zT_1842 = 1;
    goto z_bb_499;
    z_bb_499:
    if (zT_1842) goto z_bb_501; else goto z_bb_500;
    z_bb_500:
    zT_1848 = node.kind;
    zT_1847 = zT_1848 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add);
    goto z_bb_502;
    z_bb_501:
    zT_1847 = 1;
    goto z_bb_502;
    z_bb_502:
    if (zT_1847) goto z_bb_504; else goto z_bb_503;
    z_bb_503:
    zT_1853 = node.kind;
    zT_1852 = zT_1853 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub);
    goto z_bb_505;
    z_bb_504:
    zT_1852 = 1;
    goto z_bb_505;
    z_bb_505:
    if (zT_1852) goto z_bb_507; else goto z_bb_506;
    z_bb_506:
    zT_1858 = node.kind;
    zT_1857 = zT_1858 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul);
    goto z_bb_508;
    z_bb_507:
    zT_1857 = 1;
    goto z_bb_508;
    z_bb_508:
    if (zT_1857) goto z_bb_510; else goto z_bb_509;
    z_bb_509:
    zT_1863 = node.kind;
    zT_1862 = zT_1863 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add);
    goto z_bb_511;
    z_bb_510:
    zT_1862 = 1;
    goto z_bb_511;
    z_bb_511:
    if (zT_1862) goto z_bb_513; else goto z_bb_512;
    z_bb_512:
    zT_1868 = node.kind;
    zT_1867 = zT_1868 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub);
    goto z_bb_514;
    z_bb_513:
    zT_1867 = 1;
    goto z_bb_514;
    z_bb_514:
    if (zT_1867) goto z_bb_516; else goto z_bb_515;
    z_bb_515:
    zT_1873 = node.kind;
    zT_1872 = zT_1873 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul);
    goto z_bb_517;
    z_bb_516:
    zT_1872 = 1;
    goto z_bb_517;
    z_bb_517:
    if (zT_1872) goto z_bb_518; else goto z_bb_520;
    z_bb_518:
    zT_1877 = self;
    zT_1878 = node_idx;
    zT_1879 = node.kind;
    zT_1881 = zF_44006DDD_semanticAnalyzerRes(zT_1877, zT_1878, zT_1879);
    result = zT_1881;
    goto z_bb_519;
    z_bb_519:
    goto z_bb_470;
    z_bb_520:
    zT_1882 = node.kind;
    if ((unsigned char)(zT_1882 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_522; else goto z_bb_521;
    z_bb_521:
    zT_1887 = node.kind;
    zT_1886 = zT_1887 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_523;
    z_bb_522:
    zT_1886 = 1;
    goto z_bb_523;
    z_bb_523:
    if (zT_1886) goto z_bb_525; else goto z_bb_524;
    z_bb_524:
    zT_1892 = node.kind;
    zT_1891 = zT_1892 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_526;
    z_bb_525:
    zT_1891 = 1;
    goto z_bb_526;
    z_bb_526:
    if (zT_1891) goto z_bb_528; else goto z_bb_527;
    z_bb_527:
    zT_1897 = node.kind;
    zT_1896 = zT_1897 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_529;
    z_bb_528:
    zT_1896 = 1;
    goto z_bb_529;
    z_bb_529:
    if (zT_1896) goto z_bb_531; else goto z_bb_530;
    z_bb_530:
    zT_1902 = node.kind;
    zT_1901 = zT_1902 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_532;
    z_bb_531:
    zT_1901 = 1;
    goto z_bb_532;
    z_bb_532:
    if (zT_1901) goto z_bb_534; else goto z_bb_533;
    z_bb_533:
    zT_1907 = node.kind;
    zT_1906 = zT_1907 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl);
    goto z_bb_535;
    z_bb_534:
    zT_1906 = 1;
    goto z_bb_535;
    z_bb_535:
    if (zT_1906) goto z_bb_536; else goto z_bb_538;
    z_bb_536:
    zT_1911 = self;
    zT_1912 = node_idx;
    zT_1913 = zF_733BCA9C_semanticAnalyzerRes(zT_1911, zT_1912);
    result = zT_1913;
    goto z_bb_537;
    z_bb_537:
    goto z_bb_519;
    z_bb_538:
    zT_1914 = node.kind;
    if ((unsigned char)(zT_1914 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_540; else goto z_bb_539;
    z_bb_539:
    zT_1919 = node.kind;
    zT_1918 = zT_1919 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_541;
    z_bb_540:
    zT_1918 = 1;
    goto z_bb_541;
    z_bb_541:
    if (zT_1918) goto z_bb_542; else goto z_bb_544;
    z_bb_542:
    zT_1923 = self;
    zT_1924 = node_idx;
    zT_1925 = zF_6F2B8B98_semanticAnalyzerRes(zT_1923, zT_1924);
    result = zT_1925;
    goto z_bb_543;
    z_bb_543:
    goto z_bb_537;
    z_bb_544:
    zT_1926 = node.kind;
    if ((unsigned char)(zT_1926 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_546; else goto z_bb_545;
    z_bb_545:
    zT_1931 = node.kind;
    zT_1930 = zT_1931 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_547;
    z_bb_546:
    zT_1930 = 1;
    goto z_bb_547;
    z_bb_547:
    if (zT_1930) goto z_bb_549; else goto z_bb_548;
    z_bb_548:
    zT_1936 = node.kind;
    zT_1935 = zT_1936 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_550;
    z_bb_549:
    zT_1935 = 1;
    goto z_bb_550;
    z_bb_550:
    if (zT_1935) goto z_bb_552; else goto z_bb_551;
    z_bb_551:
    zT_1941 = node.kind;
    zT_1940 = zT_1941 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_553;
    z_bb_552:
    zT_1940 = 1;
    goto z_bb_553;
    z_bb_553:
    if (zT_1940) goto z_bb_555; else goto z_bb_554;
    z_bb_554:
    zT_1946 = node.kind;
    zT_1945 = zT_1946 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_556;
    z_bb_555:
    zT_1945 = 1;
    goto z_bb_556;
    z_bb_556:
    if (zT_1945) goto z_bb_558; else goto z_bb_557;
    z_bb_557:
    zT_1951 = node.kind;
    zT_1950 = zT_1951 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_559;
    z_bb_558:
    zT_1950 = 1;
    goto z_bb_559;
    z_bb_559:
    if (zT_1950) goto z_bb_560; else goto z_bb_562;
    z_bb_560:
    zT_1955 = self;
    zT_1956 = node_idx;
    zT_1957 = node.kind;
    zT_1959 = zF_EB621FF0_semanticAnalyzerRes(zT_1955, zT_1956, zT_1957);
    result = zT_1959;
    goto z_bb_561;
    z_bb_561:
    goto z_bb_543;
    z_bb_562:
    zT_1960 = node.kind;
    if ((unsigned char)(zT_1960 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_564; else goto z_bb_563;
    z_bb_563:
    zT_1965 = node.kind;
    zT_1964 = zT_1965 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_565;
    z_bb_564:
    zT_1964 = 1;
    goto z_bb_565;
    z_bb_565:
    if (zT_1964) goto z_bb_567; else goto z_bb_566;
    z_bb_566:
    zT_1970 = node.kind;
    zT_1969 = zT_1970 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_568;
    z_bb_567:
    zT_1969 = 1;
    goto z_bb_568;
    z_bb_568:
    if (zT_1969) goto z_bb_570; else goto z_bb_569;
    z_bb_569:
    zT_1975 = node.kind;
    zT_1974 = zT_1975 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_571;
    z_bb_570:
    zT_1974 = 1;
    goto z_bb_571;
    z_bb_571:
    if (zT_1974) goto z_bb_573; else goto z_bb_572;
    z_bb_572:
    zT_1980 = node.kind;
    zT_1979 = zT_1980 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_574;
    z_bb_573:
    zT_1979 = 1;
    goto z_bb_574;
    z_bb_574:
    if (zT_1979) goto z_bb_576; else goto z_bb_575;
    z_bb_575:
    zT_1985 = node.kind;
    zT_1984 = zT_1985 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_577;
    z_bb_576:
    zT_1984 = 1;
    goto z_bb_577;
    z_bb_577:
    if (zT_1984) goto z_bb_579; else goto z_bb_578;
    z_bb_578:
    zT_1990 = node.kind;
    zT_1989 = zT_1990 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_580;
    z_bb_579:
    zT_1989 = 1;
    goto z_bb_580;
    z_bb_580:
    if (zT_1989) goto z_bb_582; else goto z_bb_581;
    z_bb_581:
    zT_1995 = node.kind;
    zT_1994 = zT_1995 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_583;
    z_bb_582:
    zT_1994 = 1;
    goto z_bb_583;
    z_bb_583:
    if (zT_1994) goto z_bb_585; else goto z_bb_584;
    z_bb_584:
    zT_2000 = node.kind;
    zT_1999 = zT_2000 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_586;
    z_bb_585:
    zT_1999 = 1;
    goto z_bb_586;
    z_bb_586:
    if (zT_1999) goto z_bb_588; else goto z_bb_587;
    z_bb_587:
    zT_2005 = node.kind;
    zT_2004 = zT_2005 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_589;
    z_bb_588:
    zT_2004 = 1;
    goto z_bb_589;
    z_bb_589:
    if (zT_2004) goto z_bb_591; else goto z_bb_590;
    z_bb_590:
    zT_2010 = node.kind;
    zT_2009 = zT_2010 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_592;
    z_bb_591:
    zT_2009 = 1;
    goto z_bb_592;
    z_bb_592:
    if (zT_2009) goto z_bb_594; else goto z_bb_593;
    z_bb_593:
    zT_2015 = node.kind;
    zT_2014 = zT_2015 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_595;
    z_bb_594:
    zT_2014 = 1;
    goto z_bb_595;
    z_bb_595:
    if (zT_2014) goto z_bb_597; else goto z_bb_596;
    z_bb_596:
    zT_2020 = node.kind;
    zT_2019 = zT_2020 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_598;
    z_bb_597:
    zT_2019 = 1;
    goto z_bb_598;
    z_bb_598:
    if (zT_2019) goto z_bb_600; else goto z_bb_599;
    z_bb_599:
    zT_2025 = node.kind;
    zT_2024 = zT_2025 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_601;
    z_bb_600:
    zT_2024 = 1;
    goto z_bb_601;
    z_bb_601:
    if (zT_2024) goto z_bb_603; else goto z_bb_602;
    z_bb_602:
    zT_2030 = node.kind;
    zT_2029 = zT_2030 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_604;
    z_bb_603:
    zT_2029 = 1;
    goto z_bb_604;
    z_bb_604:
    if (zT_2029) goto z_bb_606; else goto z_bb_605;
    z_bb_605:
    zT_2035 = node.kind;
    zT_2034 = zT_2035 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_607;
    z_bb_606:
    zT_2034 = 1;
    goto z_bb_607;
    z_bb_607:
    if (zT_2034) goto z_bb_609; else goto z_bb_608;
    z_bb_608:
    zT_2040 = node.kind;
    zT_2039 = zT_2040 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_610;
    z_bb_609:
    zT_2039 = 1;
    goto z_bb_610;
    z_bb_610:
    if (zT_2039) goto z_bb_612; else goto z_bb_611;
    z_bb_611:
    zT_2045 = node.kind;
    zT_2044 = zT_2045 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_613;
    z_bb_612:
    zT_2044 = 1;
    goto z_bb_613;
    z_bb_613:
    if (zT_2044) goto z_bb_614; else goto z_bb_616;
    z_bb_614:
    zT_2049 = self;
    zT_2050 = node_idx;
    zT_2051 = zF_C0551BB8_semanticAnalyzerRes(zT_2049, zT_2050);
    result = zT_2051;
    goto z_bb_615;
    z_bb_615:
    goto z_bb_561;
    z_bb_616:
    zT_2052 = node.kind;
    if ((unsigned char)(zT_2052 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_618; else goto z_bb_617;
    z_bb_617:
    zT_2057 = node.kind;
    zT_2056 = zT_2057 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_619;
    z_bb_618:
    zT_2056 = 1;
    goto z_bb_619;
    z_bb_619:
    if (zT_2056) goto z_bb_620; else goto z_bb_622;
    z_bb_620:
    zT_2061 = self;
    zT_2062 = node.child_0;
    zT_2064 = zF_54F95822_semanticAnalyzerRes(zT_2061, zT_2062);
    (void)zT_2064;
    zT_2065 = node.child_1;
    zT_2066 = 0;
    if ((unsigned char)(zT_2065 != (unsigned int)zT_2066)) goto z_bb_623; else goto z_bb_624;
    goto z_bb_615;
    z_bb_622:
    zT_2079 = "ST:N";
    zT_2081 = 4;
    zT_2080.ptr = zT_2079;
    zT_2080.len = zT_2081;
    st_m = zT_2080;
    zT_2082 = st_m;
    zT_2083 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2082, zT_2083);
    zT_2085 = node.kind;
    zT_2086 = (unsigned int)zT_2085;
    st_kv = zT_2086;
    zT_2088 = "ST:K";
    zT_2090 = 4;
    zT_2089.ptr = zT_2088;
    zT_2089.len = zT_2090;
    st_km = zT_2089;
    zT_2091 = st_km;
    zT_2092 = st_kv;
    zF_C914CB83_markerWriteInt(zT_2091, zT_2092);
    zT_2094 = "internal error: unhandled node kind in type resolution";
    zT_2096 = 54;
    zT_2095.ptr = zT_2094;
    zT_2095.len = zT_2096;
    unr_msg = zT_2095;
    zT_2097 = self->diag;
    zT_2100 = self->source_file_id;
    zT_2101 = node_idx;
    zT_2102 = node_idx;
    zT_2103 = unr_msg;
    zT_2108 = zF_C82559AC_diagnosticCollector(zT_2097, (unsigned char)(0), (unsigned short)(3020), zT_2100, zT_2101, zT_2102, zT_2103);
    (void)zT_2108;
    return (unsigned int)(1);
    z_bb_623:
    zT_2068 = self;
    zT_2069 = node.child_1;
    zT_2071 = zF_54F95822_semanticAnalyzerRes(zT_2068, zT_2069);
    (void)zT_2071;
    goto z_bb_624;
    z_bb_624:
    zT_2072 = self->type_table;
    zT_2073 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_2072, zT_2073, (unsigned int)(10));
    return (unsigned int)(10);
}

/* semanticAnalyzerFnPtrConvMismatch */
unsigned char zF_148F8E19_semanticAnalyzerFnP(zT_38C12417_SemanticAnalyzer* self, unsigned int src, unsigned int tgt) {
    zT_338B7C76_TypeRegistry* zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_338B7C76_TypeRegistry* zT_11;
    unsigned int zT_12;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_D155D06D_Type* zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_112BF819_PtrPayload* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_112BF819_PtrPayload zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_D155D06D_Type* zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type zT_35;
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D155D06D_Type* zT_38;
    unsigned int zT_39;
    zT_D155D06D_Type zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_112BF819_PtrPayload* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_112BF819_PtrPayload zT_49;
    unsigned int zT_50;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_D155D06D_Type* zT_52;
    unsigned int zT_53;
    zT_D155D06D_Type zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    unsigned char zT_59;
    zT_33EF6BFB_TypeKind zT_60;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_0317B1D5_FnPayload* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_0317B1D5_FnPayload zT_70;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_0317B1D5_FnPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_0317B1D5_FnPayload zT_76;
    unsigned char zT_77;
    unsigned char zT_80;
    unsigned int s;
    unsigned int t;
    zT_D155D06D_Type st;
    zT_D155D06D_Type tt;
    zT_0317B1D5_FnPayload sfp;
    zT_0317B1D5_FnPayload tfp;
    if ((unsigned char)(src == tgt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src) >= zT_7)) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_11 = self->registry;
    zT_12 = zT_11->types_len;
    zT_9 = (unsigned int)((unsigned int)tgt) >= zT_12;
    goto z_bb_5;
    z_bb_4:
    zT_9 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_9) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    s = src;
    t = tgt;
    zT_18 = self->registry;
    zT_19 = zT_18->types_items;
    zT_20 = (unsigned int)s;
    zT_21 = zT_19[zT_20];
    st = zT_21;
    zT_22 = st.kind;
    if ((unsigned char)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = self->registry;
    zT_27 = zT_26->ptr_items;
    zT_28 = st.payload_idx;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zT_27[zT_29];
    zT_31 = zT_30.base;
    s = zT_31;
    zT_32 = self->registry;
    zT_33 = zT_32->types_items;
    zT_34 = (unsigned int)s;
    zT_35 = zT_33[zT_34];
    st = zT_35;
    goto z_bb_9;
    z_bb_9:
    zT_37 = self->registry;
    zT_38 = zT_37->types_items;
    zT_39 = (unsigned int)t;
    zT_40 = zT_38[zT_39];
    tt = zT_40;
    zT_41 = tt.kind;
    if ((unsigned char)(zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_45 = self->registry;
    zT_46 = zT_45->ptr_items;
    zT_47 = tt.payload_idx;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zT_46[zT_48];
    zT_50 = zT_49.base;
    t = zT_50;
    zT_51 = self->registry;
    zT_52 = zT_51->types_items;
    zT_53 = (unsigned int)t;
    zT_54 = zT_52[zT_53];
    tt = zT_54;
    goto z_bb_11;
    z_bb_11:
    zT_55 = st.kind;
    if ((unsigned char)(zT_55 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_60 = tt.kind;
    zT_59 = zT_60 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_14;
    z_bb_13:
    zT_59 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_59) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_66 = self->registry;
    zT_67 = zT_66->fn_items;
    zT_68 = st.payload_idx;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zT_67[zT_69];
    sfp = zT_70;
    zT_72 = self->registry;
    zT_73 = zT_72->fn_items;
    zT_74 = tt.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    tfp = zT_76;
    zT_77 = sfp.flags_packed;
    zT_80 = tfp.flags_packed;
    return (unsigned char)((unsigned char)(zT_77 & (unsigned char)(2)) != (unsigned char)(zT_80 & (unsigned char)(2)));
}

/* isBShapeMismatch */
unsigned char zF_D728034A_isBShapeMismatch(zT_38C12417_SemanticAnalyzer* self, unsigned int src_ty, unsigned int tgt_ty, unsigned char full) {
    unsigned char zT_6;
    zT_338B7C76_TypeRegistry* zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned char zT_35;
    unsigned char zT_40;
    unsigned char zT_44;
    unsigned char zT_52;
    unsigned char zT_60;
    unsigned char zT_68;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    if ((unsigned char)(src_ty == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_6 = tgt_ty == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_6) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_11 = self->registry;
    zT_12 = zT_11->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src_ty) >= zT_12)) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    zT_14 = (unsigned int)((unsigned int)tgt_ty) >= zT_17;
    goto z_bb_8;
    z_bb_7:
    zT_14 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_14) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = (unsigned int)src_ty;
    zT_24 = zT_22[zT_23];
    zT_25 = zT_24.kind;
    sk = zT_25;
    zT_27 = self->registry;
    zT_28 = zT_27->types_items;
    zT_29 = (unsigned int)tgt_ty;
    zT_30 = zT_28[zT_29];
    zT_31 = zT_30.kind;
    tk = zT_31;
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_35 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_13;
    z_bb_12:
    zT_35 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_35) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (unsigned char)(1);
    z_bb_15:
    if (full) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_40 = sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_18;
    z_bb_17:
    zT_40 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_40) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_44 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_21;
    z_bb_20:
    zT_44 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_44) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (unsigned char)(1);
    z_bb_23:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_52 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_26;
    z_bb_25:
    zT_52 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_52) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_60 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_31;
    z_bb_30:
    zT_60 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_60) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    return (unsigned char)(1);
    z_bb_33:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_69 = self->registry;
    zT_70 = tgt_ty;
    zT_72 = zF_3290E9C4_typeRegistryIsInteg(zT_69, zT_70);
    zT_68 = zT_72;
    goto z_bb_36;
    z_bb_35:
    zT_68 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_68) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    return (unsigned char)(0);
}

/* semanticAnalyzerResolveFnBody */
void zF_406A2501_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int fn_decl_node) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_E2DF2801_LocalConstScope* zT_9;
    zT_C8A278E4_LocalTypeScope* zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16 = {0};
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_22;
    zT_9C1673CC_anon_238694 zT_24;
    zT_243D6A41_FnProto* zT_25;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29 = 0;
    unsigned int zT_30;
    zT_243D6A41_FnProto zT_31;
    zT_8EED1867_ResolvedTypeTable* zT_33;
    unsigned int zT_34;
    zT_BAEE192E_Opt_10 zT_36 = {0};
    unsigned char zT_37;
    zT_338B7C76_TypeRegistry* zT_40;
    unsigned int zT_41;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_D155D06D_Type* zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_0317B1D5_FnPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_0317B1D5_FnPayload zT_57;
    unsigned char zT_58;
    unsigned char zT_63;
    unsigned char zT_64;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_F85C5DED_DiagnosticCollector* zT_73;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_91 = 0;
    unsigned int zT_92;
    unsigned short zT_95;
    unsigned int zT_99;
    unsigned short zT_103;
    zT_79FAE712_u64 zT_105;
    zT_6B0A7D14_AstStore* zT_107;
    zT_79FAE712_u64 zT_108;
    unsigned int zT_109 = 0;
    unsigned int zT_111;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    zT_6B0A7D14_AstStore* zT_117;
    zT_79FAE712_u64 zT_118;
    unsigned int zT_121 = 0;
    zT_22A7C88B_AstNode zT_122 = {0};
    unsigned int zT_123;
    zT_38C12417_SemanticAnalyzer* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_130;
    unsigned int zT_131;
    zT_6B0A7D14_AstStore* zT_132;
    zT_79FAE712_u64 zT_133;
    unsigned int zT_136 = 0;
    unsigned int zT_137 = 0;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_143;
    unsigned int zT_144;
    zT_38C12417_SemanticAnalyzer* zT_146;
    zT_6B0A7D14_AstStore* zT_147;
    unsigned int zT_148;
    zT_6B0A7D14_AstStore* zT_149;
    zT_79FAE712_u64 zT_150;
    unsigned int zT_153 = 0;
    unsigned int zT_154 = 0;
    unsigned int* zT_155;
    unsigned int zT_156;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_6B0A7D14_AstStore* zT_163;
    unsigned int zT_164;
    zT_6B0A7D14_AstStore* zT_165;
    zT_79FAE712_u64 zT_166;
    unsigned int zT_169 = 0;
    unsigned int zT_170 = 0;
    unsigned char* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8EED1867_ResolvedTypeTable* zT_179;
    unsigned int zT_180;
    zT_BAEE192E_Opt_10 zT_183 = {0};
    unsigned char zT_184;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    unsigned int* zT_192;
    unsigned int zT_193;
    unsigned char* zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    unsigned int* zT_200;
    unsigned int zT_201;
    unsigned char zT_202;
    unsigned char* zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_209;
    zT_8EED1867_ResolvedTypeTable* zT_211;
    unsigned int zT_212;
    zT_BAEE192E_Opt_10 zT_215 = {0};
    unsigned char zT_216;
    unsigned int zT_218;
    zT_38C12417_SemanticAnalyzer* zT_219;
    unsigned int zT_220;
    zT_38C12417_SemanticAnalyzer* zT_223;
    unsigned int zT_224;
    unsigned char zT_226 = 0;
    unsigned char zT_227;
    zT_38C12417_SemanticAnalyzer* zT_228;
    unsigned int zT_229;
    unsigned char zT_231 = 0;
    unsigned int zT_234;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned char* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    zT_F85C5DED_DiagnosticCollector* zT_243;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned int zT_248;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_249;
    unsigned int zT_254 = 0;
    zT_21D3708C_U32ToU32Map* zT_256;
    unsigned int zT_257;
    zT_21D3708C_U32ToU32Map* zT_259;
    unsigned int zT_260;
    unsigned char* zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    unsigned char* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned int zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u fb;
    zT_22A7C88B_AstNode decl;
    zT_6B0A7D14_AstStore* store;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 vsc_tt;
    unsigned int vsc_tid;
    zT_D155D06D_Type vsc_ty;
    zT_0317B1D5_FnPayload vsc_fp;
    zT_8F083A69_Slice_zT_0B42B2F8_u vs_msg;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    zT_BAEE192E_Opt_10 fn_rt;
    zT_22A7C88B_AstNode pnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rta_m;
    zT_BAEE192E_Opt_10 rt;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u rth_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtm2;
    unsigned int frt;
    unsigned int mrsp;
    unsigned int mrep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr_msg;
    unsigned int evcap;
    unsigned int evcnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u vm;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcm;
    zT_3 = "FB";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fb = zT_4;
    zT_6 = fb;
    zF_48AC7B3A_markerWrite(zT_6);
    self->local_decl_count = (unsigned int)(0);
    zT_9 = &self->local_consts;
    zT_9->count = (unsigned int)(0);
    zT_11 = &self->local_types;
    zT_11->count = (unsigned int)(0);
    zT_13 = self->store;
    zT_14 = fn_decl_node;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    decl = zT_16;
    zT_17 = decl.kind;
    if ((unsigned char)(zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_22 = self->store;
    store = zT_22;
    zT_24 = store->fn_protos;
    zT_25 = zT_24.items;
    zT_26 = self->store;
    zT_27 = fn_decl_node;
    zT_29 = zF_8BA26B9E_astStoreNodePayload(zT_26, zT_27);
    zT_30 = (unsigned int)zT_29;
    zT_31 = zT_25[zT_30];
    proto = zT_31;
    zT_33 = self->type_table;
    zT_34 = fn_decl_node;
    zT_36 = zF_999DCF51_resolvedTypeTableGe(zT_33, zT_34);
    vsc_tt = zT_36;
    zT_37 = vsc_tt.has_value;
    if (zT_37) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    vsc_tid = vsc_tt.value;
    zT_40 = self->registry;
    zT_41 = zT_40->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)vsc_tid) < zT_41)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_92 = decl.child_0;
    if ((unsigned char)(zT_92 == (unsigned int)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_5:
    zT_44 = self->registry;
    zT_45 = zT_44->types_items;
    zT_46 = (unsigned int)vsc_tid;
    zT_47 = zT_45[zT_46];
    vsc_ty = zT_47;
    zT_48 = vsc_ty.kind;
    if ((unsigned char)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_53 = self->registry;
    zT_54 = zT_53->fn_items;
    zT_55 = vsc_ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    vsc_fp = zT_57;
    zT_58 = vsc_fp.flags_packed;
    if ((unsigned char)((unsigned char)(zT_58 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_64 = vsc_fp.flags_packed;
    zT_63 = (unsigned char)(zT_64 & (unsigned char)(2)) != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_63 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_63) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_70 = "variadic functions cannot use the stdcall calling convention";
    zT_72 = 60;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    vs_msg = zT_71;
    zT_73 = self->diag;
    zT_76 = self->source_file_id;
    zT_77 = decl.span_start;
    zT_87 = decl.span_start;
    zT_88 = decl.span_len;
    zT_79 = vs_msg;
    zT_91 = zF_C82559AC_diagnosticCollector(zT_73, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3012_VARARGS_INVALID)), zT_76, zT_77, (unsigned int)(zT_87 + (unsigned int)((unsigned int)zT_88)), zT_79);
    (void)zT_91;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    return;
    z_bb_15:
    zT_95 = proto.params_count;
    if ((unsigned char)(zT_95 > (unsigned short)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_99 = proto.params_start;
    zT_103 = proto.params_count;
    zT_105 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_99) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_103);
    p_payload = zT_105;
    zT_107 = store;
    zT_108 = p_payload;
    zT_109 = zF_03CE8CAB_astStoreGetExtraChi(zT_107, zT_108);
    pnodes_n = zT_109;
    zT_111 = 0;
    pi = zT_111;
    goto z_bb_18;
    z_bb_17:
    zT_211 = self->type_table;
    zT_212 = proto.return_type_node;
    zT_215 = zF_999DCF51_resolvedTypeTableGe(zT_211, zT_212);
    fn_rt = zT_215;
    zT_216 = fn_rt.has_value;
    if (zT_216) goto z_bb_29; else goto z_bb_30;
    z_bb_18:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_115 = store;
    zT_117 = store;
    zT_118 = p_payload;
    zT_121 = zF_E5B10421_astStoreGetExtraChi(zT_117, zT_118, (unsigned int)((unsigned int)pi));
    zT_116 = zT_121;
    zT_122 = zF_FCDD1D35_astStoreNodeAt(zT_115, zT_116);
    pnode = zT_122;
    zT_123 = pnode.child_0;
    if ((unsigned char)(zT_123 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_209 = pi + (unsigned int)(1);
    pi = zT_209;
    goto z_bb_18;
    z_bb_22:
    zT_126 = self;
    zT_130 = store;
    zT_132 = store;
    zT_133 = p_payload;
    zT_136 = zF_E5B10421_astStoreGetExtraChi(zT_132, zT_133, (unsigned int)((unsigned int)pi));
    zT_131 = zT_136;
    zT_137 = zF_8BA26B9E_astStoreNodePayload(zT_130, zT_131);
    zT_127 = zT_137;
    zT_128 = pnode.span_start;
    zT_139 = pnode.span_start;
    zT_140 = pnode.span_len;
    zF_C999EE08_semanticAnalyzerChe(zT_126, zT_127, zT_128, (unsigned int)(zT_139 + (unsigned int)((unsigned int)zT_140)));
    zT_143 = self->local_decl_count;
    zT_144 = self->local_decl_cap;
    if ((unsigned char)(zT_143 >= zT_144)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_146 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_146);
    goto z_bb_25;
    z_bb_25:
    zT_147 = store;
    zT_149 = store;
    zT_150 = p_payload;
    zT_153 = zF_E5B10421_astStoreGetExtraChi(zT_149, zT_150, (unsigned int)((unsigned int)pi));
    zT_148 = zT_153;
    zT_154 = zF_8BA26B9E_astStoreNodePayload(zT_147, zT_148);
    zT_155 = self->local_decl_names;
    zT_156 = self->local_decl_count;
    zT_155[zT_156] = zT_154;
    zT_158 = "RT:P";
    zT_160 = 4;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    rtp_m = zT_159;
    zT_161 = rtp_m;
    zT_163 = store;
    zT_165 = store;
    zT_166 = p_payload;
    zT_169 = zF_E5B10421_astStoreGetExtraChi(zT_165, zT_166, (unsigned int)((unsigned int)pi));
    zT_164 = zT_169;
    zT_170 = zF_8BA26B9E_astStoreNodePayload(zT_163, zT_164);
    zT_162 = zT_170;
    zF_C914CB83_markerWriteInt(zT_161, zT_162);
    zT_172 = "RT:A";
    zT_174 = 4;
    zT_173.ptr = zT_172;
    zT_173.len = zT_174;
    rta_m = zT_173;
    zT_175 = rta_m;
    zT_176 = pnode.child_0;
    zF_C914CB83_markerWriteInt(zT_175, zT_176);
    zT_179 = self->type_table;
    zT_180 = pnode.child_0;
    zT_183 = zF_999DCF51_resolvedTypeTableGe(zT_179, zT_180);
    rt = zT_183;
    zT_184 = rt.has_value;
    if (zT_184) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    t = rt.value;
    zT_187 = "RT:T";
    zT_189 = 4;
    zT_188.ptr = zT_187;
    zT_188.len = zT_189;
    rth_m = zT_188;
    zT_190 = rth_m;
    zT_191 = t;
    zF_C914CB83_markerWriteInt(zT_190, zT_191);
    zT_192 = self->local_decl_types;
    zT_193 = self->local_decl_count;
    zT_192[zT_193] = t;
    goto z_bb_27;
    z_bb_27:
    zT_202 = 1;
    zT_203 = self->local_decl_consts;
    zT_204 = self->local_decl_count;
    zT_203[zT_204] = zT_202;
    zT_205 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_205 + (unsigned int)(1));
    goto z_bb_23;
    z_bb_28:
    zT_195 = "RT:M\n";
    zT_197 = 5;
    zT_196.ptr = zT_195;
    zT_196.len = zT_197;
    rtm2 = zT_196;
    zT_198 = rtm2;
    zF_48AC7B3A_markerWrite(zT_198);
    zT_199 = 18;
    zT_200 = self->local_decl_types;
    zT_201 = self->local_decl_count;
    zT_200[zT_201] = zT_199;
    goto z_bb_27;
    z_bb_29:
    frt = fn_rt.value;
    self->current_fn_return = frt;
    goto z_bb_30;
    z_bb_30:
    zT_218 = proto.name_id;
    self->current_fn_name = zT_218;
    zT_219 = self;
    zT_220 = decl.child_0;
    zF_979B6CFF_semanticAnalyzerRes(zT_219, zT_220);
    self->current_fn_name = (unsigned int)(0);
    zT_223 = self;
    zT_224 = self->current_fn_return;
    zT_226 = zF_15CE7BE8_fnReturnRequiresVal(zT_223, zT_224);
    if (zT_226) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_228 = self;
    zT_229 = decl.child_0;
    zT_231 = zF_AA164297_astTerminates(zT_228, zT_229);
    zT_227 = !zT_231;
    goto z_bb_33;
    z_bb_32:
    zT_227 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_227) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_234 = decl.span_start;
    mrsp = zT_234;
    zT_236 = decl.span_len;
    zT_238 = mrsp + (unsigned int)((unsigned int)zT_236);
    mrep = zT_238;
    zT_240 = "missing return: not all control paths return a value";
    zT_242 = 52;
    zT_241.ptr = zT_240;
    zT_241.len = zT_242;
    mr_msg = zT_241;
    zT_243 = self->diag;
    zT_246 = self->source_file_id;
    zT_247 = mrsp;
    zT_248 = mrep;
    zT_249 = mr_msg;
    zT_254 = zF_C82559AC_diagnosticCollector(zT_243, (unsigned char)(0), (unsigned short)(3003), zT_246, zT_247, zT_248, zT_249);
    (void)zT_254;
    goto z_bb_35;
    z_bb_35:
    zT_256 = self->enum_value_table;
    zT_257 = zT_256->capacity;
    evcap = zT_257;
    zT_259 = self->enum_value_table;
    zT_260 = zT_259->count;
    evcnt = zT_260;
    zT_262 = "EVC:N";
    zT_264 = 5;
    zT_263.ptr = zT_262;
    zT_263.len = zT_264;
    vm = zT_263;
    zT_265 = vm;
    zF_C914CB83_markerWriteInt(zT_265, (unsigned int)((unsigned int)evcnt));
    zT_269 = "EVC:C";
    zT_271 = 5;
    zT_270.ptr = zT_269;
    zT_270.len = zT_271;
    vcm = zT_270;
    zT_272 = vcm;
    zF_C914CB83_markerWriteInt(zT_272, (unsigned int)((unsigned int)evcap));
    return;
}

/* fnReturnRequiresValue */
unsigned char zF_15CE7BE8_fnReturnRequiresVal(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    unsigned char zT_4;
    unsigned char zT_7;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_D155D06D_Type* zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_42C2D6BF_EUPayload* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_42C2D6BF_EUPayload zT_30;
    unsigned int zT_31;
    zT_33EF6BFB_TypeKind zT_35;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_0B10E8E9_OptionalPayload* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_0B10E8E9_OptionalPayload zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type t;
    zT_42C2D6BF_EUPayload eu;
    zT_0B10E8E9_OptionalPayload op;
    if ((unsigned char)(ty == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = ty == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = ty == (unsigned int)(3);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_7) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_12 = self->registry;
    zT_13 = zT_12->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ty) >= zT_13)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_17 = self->registry;
    zT_18 = zT_17->types_items;
    zT_19 = (unsigned int)ty;
    zT_20 = zT_18[zT_19];
    t = zT_20;
    zT_21 = t.kind;
    if ((unsigned char)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_26 = self->registry;
    zT_27 = zT_26->eu_items;
    zT_28 = t.payload_idx;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zT_27[zT_29];
    eu = zT_30;
    zT_31 = eu.payload;
    if ((unsigned char)(zT_31 == (unsigned int)(1))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_35 = t.kind;
    if ((unsigned char)(zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_40 = self->registry;
    zT_41 = zT_40->opt_items;
    zT_42 = t.payload_idx;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zT_41[zT_43];
    op = zT_44;
    zT_45 = op.payload;
    if ((unsigned char)(zT_45 == (unsigned int)(1))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    goto z_bb_16;
}

/* astTerminates */
unsigned char zF_AA164297_astTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_8EED1867_ResolvedTypeTable* zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_8143F551_AstKind zT_24;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    unsigned int zT_34;
    zT_38C12417_SemanticAnalyzer* zT_37;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    unsigned int zT_44 = 0;
    unsigned char zT_45 = 0;
    int zT_47;
    unsigned int zT_49;
    zT_8143F551_AstKind zT_51;
    unsigned char zT_55;
    zT_8143F551_AstKind zT_56;
    unsigned int zT_60;
    zT_38C12417_SemanticAnalyzer* zT_64;
    unsigned int zT_65;
    unsigned char zT_67 = 0;
    unsigned char zT_68;
    zT_38C12417_SemanticAnalyzer* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    zT_8143F551_AstKind zT_73;
    unsigned int zT_77;
    zT_38C12417_SemanticAnalyzer* zT_81;
    unsigned int zT_83;
    zT_8143F551_AstKind zT_85;
    zT_38C12417_SemanticAnalyzer* zT_89;
    unsigned int zT_90;
    unsigned char zT_91 = 0;
    zT_8143F551_AstKind zT_92;
    zT_38C12417_SemanticAnalyzer* zT_96;
    unsigned int zT_97;
    unsigned char zT_98 = 0;
    zT_8143F551_AstKind zT_99;
    unsigned int zT_103;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_109;
    zT_8143F551_AstKind zT_111;
    unsigned char zT_115;
    zT_8143F551_AstKind zT_116;
    unsigned char zT_120;
    zT_8143F551_AstKind zT_121;
    unsigned char zT_125;
    zT_8143F551_AstKind zT_126;
    unsigned char zT_130;
    zT_8143F551_AstKind zT_131;
    unsigned char zT_135;
    zT_8143F551_AstKind zT_136;
    unsigned char zT_140;
    zT_8143F551_AstKind zT_141;
    unsigned char zT_145;
    zT_8143F551_AstKind zT_146;
    unsigned char zT_150;
    zT_8143F551_AstKind zT_151;
    unsigned char zT_155;
    zT_8143F551_AstKind zT_156;
    unsigned char zT_160;
    zT_8143F551_AstKind zT_161;
    unsigned char zT_165;
    zT_8143F551_AstKind zT_166;
    unsigned char zT_170;
    zT_8143F551_AstKind zT_171;
    unsigned char zT_175;
    zT_8143F551_AstKind zT_176;
    unsigned char zT_180;
    zT_8143F551_AstKind zT_181;
    unsigned char zT_185;
    zT_8143F551_AstKind zT_186;
    unsigned char zT_190;
    zT_8143F551_AstKind zT_191;
    unsigned char zT_195;
    zT_8143F551_AstKind zT_196;
    unsigned int zT_200;
    zT_38C12417_SemanticAnalyzer* zT_204;
    unsigned int zT_206;
    zT_22A7C88B_AstNode node;
    unsigned int t;
    unsigned int ch_n;
    unsigned int bi;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_15 = self->type_table;
    zT_16 = node_idx;
    zT_18 = zF_999DCF51_resolvedTypeTableGe(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    t = zT_18.value;
    if ((unsigned char)(t == (unsigned int)(3))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_24 = node.kind;
    if ((unsigned char)(zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_29 = self->store;
    zT_30 = node_idx;
    zT_32 = zF_152E19CB_astStoreNodeExtraCh(zT_29, zT_30);
    ch_n = zT_32;
    zT_34 = 0;
    bi = zT_34;
    goto z_bb_11;
    z_bb_10:
    zT_51 = node.kind;
    if ((unsigned char)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)ch_n))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_37 = self;
    zT_39 = self->store;
    zT_40 = node_idx;
    zT_44 = zF_B10B1BC1_astStoreNodeExtraCh(zT_39, zT_40, (unsigned int)((unsigned int)bi));
    zT_38 = zT_44;
    zT_45 = zF_AA164297_astTerminates(zT_37, zT_38);
    if (zT_45) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_47 = 1;
    zT_49 = bi + (unsigned int)((unsigned int)zT_47);
    bi = zT_49;
    goto z_bb_11;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_56 = node.kind;
    zT_55 = zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr);
    goto z_bb_19;
    z_bb_18:
    zT_55 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_55) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_60 = node.child_2;
    if ((unsigned char)(zT_60 == (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_73 = node.kind;
    if ((unsigned char)(zT_73 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_27; else goto z_bb_28;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_64 = self;
    zT_65 = node.child_1;
    zT_67 = zF_AA164297_astTerminates(zT_64, zT_65);
    if (zT_67) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_69 = self;
    zT_70 = node.child_2;
    zT_72 = zF_AA164297_astTerminates(zT_69, zT_70);
    zT_68 = zT_72;
    goto z_bb_26;
    z_bb_25:
    zT_68 = 0;
    goto z_bb_26;
    z_bb_26:
    return zT_68;
    z_bb_27:
    zT_77 = node.child_0;
    if ((unsigned char)(zT_77 == (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_85 = node.kind;
    if ((unsigned char)(zT_85 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return (unsigned char)(0);
    z_bb_30:
    zT_81 = self;
    zT_83 = node.child_0;
    self = zT_81;
    node_idx = zT_83;
    goto z_bb_0;
    z_bb_31:
    zT_89 = self;
    zT_90 = node_idx;
    zT_91 = zF_A3A1FD27_astSwitchTerminates(zT_89, zT_90);
    return zT_91;
    z_bb_32:
    zT_92 = node.kind;
    if ((unsigned char)(zT_92 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_96 = self;
    zT_97 = node_idx;
    zT_98 = zF_FB2132D0_astWhileTerminates(zT_96, zT_97);
    return zT_98;
    z_bb_34:
    zT_99 = node.kind;
    if ((unsigned char)(zT_99 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_103 = node.child_1;
    if ((unsigned char)(zT_103 == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_111 = node.kind;
    if ((unsigned char)(zT_111 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_40; else goto z_bb_39;
    z_bb_37:
    return (unsigned char)(0);
    z_bb_38:
    zT_107 = self;
    zT_109 = node.child_1;
    self = zT_107;
    node_idx = zT_109;
    goto z_bb_0;
    z_bb_39:
    zT_116 = node.kind;
    zT_115 = zT_116 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_41;
    z_bb_40:
    zT_115 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_115) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_121 = node.kind;
    zT_120 = zT_121 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_44;
    z_bb_43:
    zT_120 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_120) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_126 = node.kind;
    zT_125 = zT_126 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_47;
    z_bb_46:
    zT_125 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_125) goto z_bb_49; else goto z_bb_48;
    z_bb_48:
    zT_131 = node.kind;
    zT_130 = zT_131 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_50;
    z_bb_49:
    zT_130 = 1;
    goto z_bb_50;
    z_bb_50:
    if (zT_130) goto z_bb_52; else goto z_bb_51;
    z_bb_51:
    zT_136 = node.kind;
    zT_135 = zT_136 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_53;
    z_bb_52:
    zT_135 = 1;
    goto z_bb_53;
    z_bb_53:
    if (zT_135) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_141 = node.kind;
    zT_140 = zT_141 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_56;
    z_bb_55:
    zT_140 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_140) goto z_bb_58; else goto z_bb_57;
    z_bb_57:
    zT_146 = node.kind;
    zT_145 = zT_146 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_59;
    z_bb_58:
    zT_145 = 1;
    goto z_bb_59;
    z_bb_59:
    if (zT_145) goto z_bb_61; else goto z_bb_60;
    z_bb_60:
    zT_151 = node.kind;
    zT_150 = zT_151 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_62;
    z_bb_61:
    zT_150 = 1;
    goto z_bb_62;
    z_bb_62:
    if (zT_150) goto z_bb_64; else goto z_bb_63;
    z_bb_63:
    zT_156 = node.kind;
    zT_155 = zT_156 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_65;
    z_bb_64:
    zT_155 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_155) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_161 = node.kind;
    zT_160 = zT_161 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_68;
    z_bb_67:
    zT_160 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_160) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_166 = node.kind;
    zT_165 = zT_166 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_71;
    z_bb_70:
    zT_165 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_165) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_171 = node.kind;
    zT_170 = zT_171 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_74;
    z_bb_73:
    zT_170 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_170) goto z_bb_76; else goto z_bb_75;
    z_bb_75:
    zT_176 = node.kind;
    zT_175 = zT_176 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_77;
    z_bb_76:
    zT_175 = 1;
    goto z_bb_77;
    z_bb_77:
    if (zT_175) goto z_bb_79; else goto z_bb_78;
    z_bb_78:
    zT_181 = node.kind;
    zT_180 = zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_80;
    z_bb_79:
    zT_180 = 1;
    goto z_bb_80;
    z_bb_80:
    if (zT_180) goto z_bb_82; else goto z_bb_81;
    z_bb_81:
    zT_186 = node.kind;
    zT_185 = zT_186 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_83;
    z_bb_82:
    zT_185 = 1;
    goto z_bb_83;
    z_bb_83:
    if (zT_185) goto z_bb_85; else goto z_bb_84;
    z_bb_84:
    zT_191 = node.kind;
    zT_190 = zT_191 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_86;
    z_bb_85:
    zT_190 = 1;
    goto z_bb_86;
    z_bb_86:
    if (zT_190) goto z_bb_88; else goto z_bb_87;
    z_bb_87:
    zT_196 = node.kind;
    zT_195 = zT_196 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_89;
    z_bb_88:
    zT_195 = 1;
    goto z_bb_89;
    z_bb_89:
    if (zT_195) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_200 = node.child_1;
    if ((unsigned char)(zT_200 == (unsigned int)(0))) goto z_bb_92; else goto z_bb_93;
    z_bb_91:
    return (unsigned char)(0);
    z_bb_92:
    return (unsigned char)(0);
    z_bb_93:
    zT_204 = self;
    zT_206 = node.child_1;
    self = zT_204;
    node_idx = zT_206;
    goto z_bb_0;
}

/* astSwitchTerminates */
unsigned char zF_A3A1FD27_astSwitchTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    unsigned char zT_16;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_30 = 0;
    zT_22A7C88B_AstNode zT_31 = {0};
    unsigned char zT_32;
    unsigned char zT_37;
    zT_38C12417_SemanticAnalyzer* zT_38;
    unsigned int zT_39;
    unsigned char zT_41 = 0;
    int zT_44;
    unsigned int zT_46;
    zT_38C12417_SemanticAnalyzer* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned char zT_52 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int prongs_n;
    unsigned char has_else;
    unsigned int pi;
    zT_22A7C88B_AstNode pr;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_152E19CB_astStoreNodeExtraCh(zT_8, zT_9);
    prongs_n = zT_11;
    if ((unsigned char)(prongs_n == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_16 = 0;
    has_else = zT_16;
    zT_18 = 0;
    pi = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)prongs_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = self->store;
    zT_25 = self->store;
    zT_26 = node_idx;
    zT_30 = zF_B10B1BC1_astStoreNodeExtraCh(zT_25, zT_26, (unsigned int)((unsigned int)pi));
    zT_23 = zT_30;
    zT_31 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    pr = zT_31;
    zT_32 = pr.flags;
    if ((unsigned char)((unsigned char)(zT_32 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    if (has_else) goto z_bb_11; else goto z_bb_12;
    z_bb_6:
    zT_44 = 1;
    zT_46 = pi + (unsigned int)((unsigned int)zT_44);
    pi = zT_46;
    goto z_bb_3;
    z_bb_7:
    zT_37 = 1;
    has_else = zT_37;
    goto z_bb_8;
    z_bb_8:
    zT_38 = self;
    zT_39 = pr.child_0;
    zT_41 = zF_AA164297_astTerminates(zT_38, zT_39);
    if ((unsigned char)(!zT_41)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    goto z_bb_6;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_48 = self;
    zT_49 = node.child_0;
    zT_50 = node_idx;
    zT_52 = zF_DCF9800F_astSwitchExhaustive(zT_48, zT_49, zT_50);
    return zT_52;
}

/* astSwitchExhaustive */
unsigned char zF_DCF9800F_astSwitchExhaustive(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_idx, unsigned int switch_node_idx) {
    zT_8EED1867_ResolvedTypeTable* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    unsigned int zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_457ECFEE_EnumPayload* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_457ECFEE_EnumPayload zT_35;
    unsigned short zT_36;
    unsigned int zT_37;
    zT_33EF6BFB_TypeKind zT_38;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_54FF90FA_TaggedUnionPayload* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_54FF90FA_TaggedUnionPayload zT_46;
    unsigned short zT_47;
    unsigned int zT_48;
    zT_33EF6BFB_TypeKind zT_49;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_0B73C507_ErrorSetPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_0B73C507_ErrorSetPayload zT_57;
    unsigned short zT_58;
    unsigned int zT_59;
    zT_33EF6BFB_TypeKind zT_60;
    unsigned int zT_64;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    unsigned int zT_72 = 0;
    unsigned int zT_74;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_86 = 0;
    unsigned int zT_87 = 0;
    unsigned int zT_89;
    int zT_90;
    unsigned int zT_92;
    unsigned int ct;
    zT_D155D06D_Type ty;
    unsigned int member_count;
    unsigned int covered;
    unsigned int prongs_n;
    unsigned int pi;
    unsigned int items_n;
    zT_4 = self->type_table;
    zT_5 = cond_idx;
    zT_7 = zF_999DCF51_resolvedTypeTableGe(zT_4, zT_5);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = zT_7.value;
    goto z_bb_3;
    z_bb_3:
    ct = zT_9;
    if ((unsigned char)(ct == (unsigned int)(0))) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    zT_14 = (unsigned int)((unsigned int)ct) >= zT_17;
    goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_14) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = (unsigned int)ct;
    zT_24 = zT_22[zT_23];
    ty = zT_24;
    zT_26 = 0;
    member_count = zT_26;
    zT_27 = ty.kind;
    if ((unsigned char)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_31 = self->registry;
    zT_32 = zT_31->en_items;
    zT_33 = ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    zT_36 = zT_35.members_count;
    zT_37 = (unsigned int)zT_36;
    member_count = zT_37;
    goto z_bb_10;
    z_bb_10:
    zT_67 = 0;
    covered = zT_67;
    zT_69 = self->store;
    zT_70 = switch_node_idx;
    zT_72 = zF_152E19CB_astStoreNodeExtraCh(zT_69, zT_70);
    prongs_n = zT_72;
    zT_74 = 0;
    pi = zT_74;
    goto z_bb_21;
    z_bb_11:
    zT_38 = ty.kind;
    if ((unsigned char)(zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_42 = self->registry;
    zT_43 = zT_42->tu_items;
    zT_44 = ty.payload_idx;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zT_43[zT_45];
    zT_47 = zT_46.fields_count;
    zT_48 = (unsigned int)zT_47;
    member_count = zT_48;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_49 = ty.kind;
    if ((unsigned char)(zT_49 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_53 = self->registry;
    zT_54 = zT_53->es_items;
    zT_55 = ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    zT_58 = zT_57.tags_count;
    zT_59 = (unsigned int)zT_58;
    member_count = zT_59;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_60 = ty.kind;
    if ((unsigned char)(zT_60 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_64 = 2;
    member_count = zT_64;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)prongs_n))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_78 = self->store;
    zT_81 = self->store;
    zT_82 = switch_node_idx;
    zT_86 = zF_B10B1BC1_astStoreNodeExtraCh(zT_81, zT_82, (unsigned int)((unsigned int)pi));
    zT_79 = zT_86;
    zT_87 = zF_152E19CB_astStoreNodeExtraCh(zT_78, zT_79);
    items_n = zT_87;
    zT_89 = covered + (unsigned int)((unsigned int)items_n);
    covered = zT_89;
    goto z_bb_24;
    z_bb_23:
    return (unsigned char)(covered >= member_count);
    z_bb_24:
    zT_90 = 1;
    zT_92 = pi + (unsigned int)((unsigned int)zT_90);
    pi = zT_92;
    goto z_bb_21;
}

/* astWhileTerminates */
unsigned char zF_FB2132D0_astWhileTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    unsigned char zT_10;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_20 = {0};
    zT_8143F551_AstKind zT_21;
    unsigned char zT_26;
    zT_38C12417_SemanticAnalyzer* zT_32;
    unsigned int zT_33;
    unsigned char zT_35 = 0;
    zT_38C12417_SemanticAnalyzer* zT_37;
    unsigned int zT_38;
    unsigned char zT_40 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode cond;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((unsigned char)(zT_7 == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = node.child_1;
    zT_10 = zT_11 == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_10 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_16 = self->store;
    zT_17 = node.child_0;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    cond = zT_20;
    zT_21 = cond.kind;
    if ((unsigned char)(zT_21 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_26 = cond.flags;
    if ((unsigned char)((unsigned char)(zT_26 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_32 = self;
    zT_33 = node.child_1;
    zT_35 = zF_B5177CCC_astSubtreeHasBreak(zT_32, zT_33);
    if (zT_35) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(0);
    z_bb_11:
    zT_37 = self;
    zT_38 = node.child_1;
    zT_40 = zF_AA164297_astTerminates(zT_37, zT_38);
    return zT_40;
}

/* astSubtreeHasBreak */
unsigned char zF_B5177CCC_astSubtreeHasBreak(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned int zT_15;
    unsigned char zT_18;
    zT_8143F551_AstKind zT_19;
    unsigned char zT_23 = 0;
    unsigned char zT_24;
    zT_38C12417_SemanticAnalyzer* zT_25;
    unsigned int zT_26;
    unsigned char zT_28 = 0;
    unsigned int zT_30;
    unsigned char zT_33;
    zT_8143F551_AstKind zT_34;
    unsigned char zT_38 = 0;
    unsigned char zT_39;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned char zT_43 = 0;
    unsigned int zT_45;
    unsigned char zT_48;
    zT_8143F551_AstKind zT_49;
    unsigned char zT_53 = 0;
    unsigned char zT_54;
    zT_38C12417_SemanticAnalyzer* zT_55;
    unsigned int zT_56;
    unsigned char zT_58 = 0;
    zT_8143F551_AstKind zT_60;
    unsigned char zT_62 = 0;
    unsigned char zT_63;
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    unsigned int zT_67 = 0;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_74 = 0;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_38C12417_SemanticAnalyzer* zT_79;
    unsigned int zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_86 = 0;
    unsigned char zT_87 = 0;
    int zT_89;
    unsigned int zT_91;
    zT_22A7C88B_AstNode node;
    unsigned int ec_n;
    unsigned int ei;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_15 = node.child_0;
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = node.kind;
    zT_23 = zF_C395F6FD_nodeChildIsNode(zT_19, (unsigned char)(0));
    zT_18 = zT_23;
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = self;
    zT_26 = node.child_0;
    zT_28 = zF_B5177CCC_astSubtreeHasBreak(zT_25, zT_26);
    zT_24 = zT_28;
    goto z_bb_10;
    z_bb_9:
    zT_24 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_24) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_30 = node.child_1;
    if ((unsigned char)(zT_30 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_34 = node.kind;
    zT_38 = zF_C395F6FD_nodeChildIsNode(zT_34, (unsigned char)(1));
    zT_33 = zT_38;
    goto z_bb_15;
    z_bb_14:
    zT_33 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_33) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_40 = self;
    zT_41 = node.child_1;
    zT_43 = zF_B5177CCC_astSubtreeHasBreak(zT_40, zT_41);
    zT_39 = zT_43;
    goto z_bb_18;
    z_bb_17:
    zT_39 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_39) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    zT_45 = node.child_2;
    if ((unsigned char)(zT_45 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_49 = node.kind;
    zT_53 = zF_C395F6FD_nodeChildIsNode(zT_49, (unsigned char)(2));
    zT_48 = zT_53;
    goto z_bb_23;
    z_bb_22:
    zT_48 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_48) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_55 = self;
    zT_56 = node.child_2;
    zT_58 = zF_B5177CCC_astSubtreeHasBreak(zT_55, zT_56);
    zT_54 = zT_58;
    goto z_bb_26;
    z_bb_25:
    zT_54 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_54) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    zT_60 = node.kind;
    zT_62 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_60);
    if (zT_62) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_64 = self->store;
    zT_65 = node_idx;
    zT_67 = zF_8BA26B9E_astStoreNodePayload(zT_64, zT_65);
    zT_63 = zT_67 != (unsigned int)(0);
    goto z_bb_31;
    z_bb_30:
    zT_63 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_63) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_71 = self->store;
    zT_72 = node_idx;
    zT_74 = zF_152E19CB_astStoreNodeExtraCh(zT_71, zT_72);
    zT_75 = (unsigned int)zT_74;
    ec_n = zT_75;
    zT_77 = 0;
    ei = zT_77;
    goto z_bb_34;
    z_bb_33:
    return (unsigned char)(0);
    z_bb_34:
    if ((unsigned char)(ei < ec_n)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_79 = self;
    zT_81 = self->store;
    zT_82 = node_idx;
    zT_86 = zF_B10B1BC1_astStoreNodeExtraCh(zT_81, zT_82, (unsigned int)((unsigned int)ei));
    zT_80 = zT_86;
    zT_87 = zF_B5177CCC_astSubtreeHasBreak(zT_79, zT_80);
    if (zT_87) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_89 = 1;
    zT_91 = ei + (unsigned int)((unsigned int)zT_89);
    ei = zT_91;
    goto z_bb_34;
    z_bb_38:
    return (unsigned char)(1);
    z_bb_39:
    goto z_bb_37;
}

/* semanticAnalyzerStmtWorkPush */
void zF_7AB741D8_semanticAnalyzerStm(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_0715C9B9_EU_832 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->stmt_work_len;
    zT_3 = self->stmt_work_cap;
    if ((unsigned char)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->stmt_work_cap;
    if ((unsigned char)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->stmt_work_items;
    zT_38 = self->stmt_work_len;
    zT_37[zT_38] = node_idx;
    zT_39 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->stmt_work_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->stmt_work_len;
    if ((unsigned char)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->stmt_work_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->stmt_work_items = ndst;
    self->stmt_work_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* pushExpectedType */
void zF_9665A229_pushExpectedType(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_0715C9B9_EU_832 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->expected_type_stack_len;
    zT_3 = self->expected_type_stack_cap;
    if ((unsigned char)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->expected_type_stack_cap;
    if ((unsigned char)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->expected_type_stack_items;
    zT_38 = self->expected_type_stack_len;
    zT_37[zT_38] = ty;
    zT_39 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->expected_type_stack_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->expected_type_stack_len;
    if ((unsigned char)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->expected_type_stack_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->expected_type_stack_items = ndst;
    self->expected_type_stack_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* popExpectedType */
void zF_BC478E78_popExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int zT_4;
    zT_1 = self->expected_type_stack_len;
    if ((unsigned char)(zT_1 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_4 - (unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    return;
}

/* topExpectedType */
unsigned int zF_4DE7C2BC_topExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_1 = self->expected_type_stack_len;
    if ((unsigned char)(zT_1 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_5 = self->expected_type_stack_items;
    zT_6 = self->expected_type_stack_len;
    zT_8 = zT_6 - (unsigned int)(1);
    zT_9 = zT_5[zT_8];
    return zT_9;
}

/* semanticAnalyzerCheckConditionType */
void zF_64F73ABA_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, unsigned int cond_idx, unsigned int cond_t, unsigned char has_capture) {
    unsigned char zT_7;
    unsigned char zT_10;
    unsigned char zT_13;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_D155D06D_Type* zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    unsigned char zT_23;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    unsigned char zT_31;
    unsigned char zT_35;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    unsigned char zT_42;
    unsigned char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_F85C5DED_DiagnosticCollector* zT_46;
    unsigned int zT_47;
    unsigned char zT_49 = 0;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_22A7C88B_AstNode zT_55 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_56;
    unsigned int zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_74 = 0;
    zT_33EF6BFB_TypeKind ck;
    unsigned char ok;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_msg;
    zT_22A7C88B_AstNode cond_node;
    if ((unsigned char)(cond_t == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_7 = cond_t == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_7) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_10 = cond_t == (unsigned int)(3);
    goto z_bb_6;
    z_bb_5:
    zT_10 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_10) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_13 = cond_t == (unsigned int)(18);
    goto z_bb_9;
    z_bb_8:
    zT_13 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_13) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return;
    z_bb_11:
    zT_17 = self->registry;
    zT_18 = zT_17->types_items;
    zT_19 = (unsigned int)cond_t;
    zT_20 = zT_18[zT_19];
    zT_21 = zT_20.kind;
    ck = zT_21;
    zT_23 = 0;
    ok = zT_23;
    zT_25 = "invalid condition";
    zT_27 = 17;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    cc_msg = zT_26;
    if (has_capture) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    if ((unsigned char)(ck == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_16; else goto z_bb_15;
    z_bb_13:
    if (ok) goto z_bb_24; else goto z_bb_25;
    z_bb_14:
    if ((unsigned char)(ck == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_15:
    zT_31 = ck == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_17;
    z_bb_16:
    zT_31 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_31) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_35 = 1;
    ok = zT_35;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_13;
    z_bb_20:
    zT_36 = "capture condition must be an optional or error union type";
    zT_38 = 57;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    cc_msg = zT_37;
    goto z_bb_19;
    z_bb_21:
    zT_42 = 1;
    ok = zT_42;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_13;
    z_bb_23:
    zT_43 = "condition must be of type 'bool'";
    zT_45 = 32;
    zT_44.ptr = zT_43;
    zT_44.len = zT_45;
    cc_msg = zT_44;
    goto z_bb_22;
    z_bb_24:
    return;
    z_bb_25:
    zT_46 = self->diag;
    zT_47 = node_idx;
    zT_49 = zF_4DD9DB2D_diagnosticCollector(zT_46, zT_47);
    if ((unsigned char)(!zT_49)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    return;
    z_bb_27:
    zT_52 = self->store;
    zT_53 = cond_idx;
    zT_55 = zF_FCDD1D35_astStoreNodeAt(zT_52, zT_53);
    cond_node = zT_55;
    zT_56 = self->diag;
    zT_59 = self->source_file_id;
    zT_60 = cond_node.span_start;
    zT_70 = cond_node.span_start;
    zT_71 = cond_node.span_len;
    zT_62 = cc_msg;
    zT_74 = zF_C82559AC_diagnosticCollector(zT_56, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3058_CONDITION_NOT_BOOL)), zT_59, zT_60, (unsigned int)(zT_70 + (unsigned int)((unsigned int)zT_71)), zT_62);
    (void)zT_74;
    return;
}

/* semanticAnalyzerResolveIfHeader */
void zF_0324C9A3_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_39 = 0;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_38C12417_SemanticAnalyzer* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_49;
    unsigned int zT_51 = 0;
    zT_38C12417_SemanticAnalyzer* zT_52;
    unsigned int zT_53;
    unsigned int zT_54 = 0;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    unsigned int zT_59 = 0;
    unsigned char zT_61;
    zT_38C12417_SemanticAnalyzer* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_939EE900_Arr_unsigned_int_1 zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_939EE900_Arr_unsigned_int_1 zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    int zT_76;
    unsigned int zT_77;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    int zT_84;
    zT_22A7C88B_AstNode zT_86 = {0};
    zT_8143F551_AstKind zT_87;
    unsigned int zT_88;
    int zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    unsigned char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    int zT_102;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    int zT_110;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_939EE900_Arr_unsigned_int_1 zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    zT_6B0A7D14_AstStore* zT_127;
    unsigned int zT_128;
    zT_22A7C88B_AstNode zT_131 = {0};
    zT_8143F551_AstKind zT_132;
    unsigned int zT_133;
    int zT_134;
    unsigned char* zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    int zT_141;
    zT_22A7C88B_AstNode node;
    unsigned int icond_t;
    unsigned int icap_idx;
    zT_22A7C88B_AstNode icap_node;
    unsigned char icap_present;
    zT_939EE900_Arr_unsigned_int_1 ifs_b;
    zT_939EE900_Arr_unsigned_int_1 ifs_k;
    zT_22A7C88B_AstNode ifs_cn;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_cm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_c2m;
    zT_939EE900_Arr_unsigned_int_1 ifs_k2;
    zT_22A7C88B_AstNode ifs_cn2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_k2m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    icond_t = zT_11;
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    icap_idx = zT_22;
    zT_24 = self->store;
    zT_25 = icap_idx;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    icap_node = zT_27;
    zT_28 = icap_node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_56 = self->store;
    zT_57 = node_idx;
    zT_59 = zF_8BA26B9E_astStoreNodePayload(zT_56, zT_57);
    zT_61 = zT_59 != (unsigned int)(0);
    icap_present = zT_61;
    zT_62 = self;
    zT_63 = node_idx;
    zT_64 = node.child_0;
    zT_65 = icond_t;
    zT_66 = icap_present;
    zF_64F73ABA_semanticAnalyzerChe(zT_62, zT_63, zT_64, zT_65, zT_66);
    zT_70 = node.child_1;
    zT_71 = 0;
    zT_69[zT_71] = zT_70;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_b[_i] = zT_69[_i];
        _i++;
    }
}
    zT_74 = 0;
    zT_75 = 0;
    zT_73[zT_75] = zT_74;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k[_i] = zT_73[_i];
        _i++;
    }
}
    zT_76 = 0;
    zT_77 = ifs_b[zT_76];
    if ((unsigned char)(zT_77 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_32 = self;
    zT_36 = self->store;
    zT_37 = icap_idx;
    zT_39 = zF_8BA26B9E_astStoreNodePayload(zT_36, zT_37);
    zT_33 = zT_39;
    zT_34 = icap_node.span_start;
    zT_41 = icap_node.span_start;
    zT_42 = icap_node.span_len;
    zF_C999EE08_semanticAnalyzerChe(zT_32, zT_33, zT_34, (unsigned int)(zT_41 + (unsigned int)((unsigned int)zT_42)));
    zT_45 = self;
    zT_48 = self->store;
    zT_49 = icap_idx;
    zT_51 = zF_8BA26B9E_astStoreNodePayload(zT_48, zT_49);
    zT_46 = zT_51;
    zT_52 = self;
    zT_53 = icond_t;
    zT_54 = zF_3E251D67_semanticAnalyzerCap(zT_52, zT_53);
    zT_47 = zT_54;
    zF_7BD72017_registerLocalDecl(zT_45, zT_46, zT_47);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_81 = self->store;
    zT_84 = 0;
    zT_82 = ifs_b[zT_84];
    zT_86 = zF_FCDD1D35_astStoreNodeAt(zT_81, zT_82);
    ifs_cn = zT_86;
    zT_87 = ifs_cn.kind;
    zT_88 = (unsigned int)zT_87;
    zT_89 = 0;
    ifs_k[zT_89] = zT_88;
    goto z_bb_6;
    z_bb_6:
    zT_91 = "IFST:N";
    zT_93 = 6;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    ifst_nm = zT_92;
    zT_94 = ifst_nm;
    zT_95 = node_idx;
    zF_C914CB83_markerWriteInt(zT_94, zT_95);
    zT_97 = "IFST:C";
    zT_99 = 6;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    ifst_cm = zT_98;
    zT_100 = ifst_cm;
    zT_102 = 0;
    zT_101 = ifs_b[zT_102];
    zF_C914CB83_markerWriteInt(zT_100, zT_101);
    zT_105 = "IFST:K";
    zT_107 = 6;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    ifst_km = zT_106;
    zT_108 = ifst_km;
    zT_110 = 0;
    zT_109 = ifs_k[zT_110];
    zF_C914CB83_markerWriteInt(zT_108, zT_109);
    zT_113 = "IFST:2";
    zT_115 = 6;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    ifst_c2m = zT_114;
    zT_116 = ifst_c2m;
    zT_117 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_116, zT_117);
    zT_121 = 0;
    zT_122 = 0;
    zT_120[zT_122] = zT_121;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k2[_i] = zT_120[_i];
        _i++;
    }
}
    zT_123 = node.child_2;
    if ((unsigned char)(zT_123 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_127 = self->store;
    zT_128 = node.child_2;
    zT_131 = zF_FCDD1D35_astStoreNodeAt(zT_127, zT_128);
    ifs_cn2 = zT_131;
    zT_132 = ifs_cn2.kind;
    zT_133 = (unsigned int)zT_132;
    zT_134 = 0;
    ifs_k2[zT_134] = zT_133;
    goto z_bb_8;
    z_bb_8:
    zT_136 = "IFST:K2";
    zT_138 = 7;
    zT_137.ptr = zT_136;
    zT_137.len = zT_138;
    ifst_k2m = zT_137;
    zT_139 = ifst_k2m;
    zT_141 = 0;
    zT_140 = ifs_k2[zT_141];
    zF_C914CB83_markerWriteInt(zT_139, zT_140);
    return;
}

/* semanticAnalyzerResolveForHeader */
void zF_8CE01C41_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_24 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_36 = 0;
    int zT_40;
    unsigned int zT_41;
    int zT_43;
    unsigned int zT_44;
    zT_F85C5DED_DiagnosticCollector* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int* zT_49;
    unsigned int* zT_50;
    unsigned char zT_56 = 0;
    int zT_58;
    unsigned int zT_59;
    int zT_61;
    unsigned int zT_62;
    zT_F85C5DED_DiagnosticCollector* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int* zT_67;
    unsigned int* zT_68;
    unsigned char zT_74 = 0;
    zT_38C12417_SemanticAnalyzer* zT_75;
    unsigned int zT_76;
    unsigned int zT_78 = 0;
    unsigned char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_6B0A7D14_AstStore* zT_87;
    unsigned int zT_88;
    zT_22A7C88B_AstNode zT_91 = {0};
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    zT_8143F551_AstKind zT_98;
    zT_8EED1867_ResolvedTypeTable* zT_101;
    unsigned int zT_102;
    zT_BAEE192E_Opt_10 zT_105 = {0};
    unsigned char zT_106;
    unsigned char* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_D155D06D_Type* zT_116;
    unsigned int zT_117;
    zT_D155D06D_Type zT_118;
    zT_939EE900_Arr_unsigned_int_1 zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_33EF6BFB_TypeKind zT_123;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_0BB2A741_SlicePayload* zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    zT_0BB2A741_SlicePayload zT_131;
    unsigned int zT_132;
    int zT_133;
    zT_33EF6BFB_TypeKind zT_134;
    zT_338B7C76_TypeRegistry* zT_138;
    zT_E834303C_ArrayPayload* zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    zT_E834303C_ArrayPayload zT_142;
    unsigned int zT_143;
    int zT_144;
    zT_8143F551_AstKind zT_145;
    unsigned char zT_149;
    zT_8143F551_AstKind zT_150;
    int zT_154;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    unsigned int zT_158 = 0;
    unsigned char zT_161;
    int zT_162;
    unsigned int zT_163;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_6B0A7D14_AstStore* zT_172;
    unsigned int zT_173;
    unsigned int zT_175 = 0;
    unsigned char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    int zT_182;
    zT_38C12417_SemanticAnalyzer* zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    zT_6B0A7D14_AstStore* zT_188;
    unsigned int zT_189;
    unsigned int zT_191 = 0;
    unsigned int zT_192;
    unsigned int zT_193;
    zT_38C12417_SemanticAnalyzer* zT_195;
    zT_6B0A7D14_AstStore* zT_196;
    unsigned int zT_197;
    unsigned int zT_199 = 0;
    unsigned int* zT_200;
    unsigned int zT_201;
    int zT_202;
    unsigned int zT_203;
    unsigned int* zT_204;
    unsigned int zT_205;
    unsigned char zT_206;
    unsigned char* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_6B0A7D14_AstStore* zT_218;
    unsigned int zT_219;
    unsigned int zT_221 = 0;
    unsigned char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    int zT_228;
    unsigned char* zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    zT_38C12417_SemanticAnalyzer* zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    unsigned int zT_243;
    unsigned int zT_244;
    zT_38C12417_SemanticAnalyzer* zT_246;
    unsigned int zT_247;
    unsigned int* zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int* zT_251;
    unsigned int zT_252;
    unsigned char zT_253;
    unsigned char* zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned char* zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned int zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    zT_22A7C88B_AstNode node;
    unsigned int for_item_s;
    unsigned int for_item_e;
    unsigned int for_idx_s;
    unsigned int for_idx_e;
    zT_22A7C88B_AstNode for_body;
    unsigned int for_close;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_c_m;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_ck_m;
    zT_BAEE192E_Opt_10 it_tid;
    unsigned int fi_s;
    unsigned int fi_e;
    unsigned int ix_s;
    unsigned int ix_e;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_tid_m;
    zT_D155D06D_Type ty;
    zT_939EE900_Arr_unsigned_int_1 elem_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u a5_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_p_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_e_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u f2_m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = node.span_start;
    for_item_s = zT_8;
    zT_10 = node.span_start;
    zT_11 = node.span_len;
    zT_13 = zT_10 + (unsigned int)((unsigned int)zT_11);
    for_item_e = zT_13;
    for_idx_s = for_item_s;
    for_idx_e = for_item_e;
    zT_16 = node.child_1;
    if ((unsigned char)(zT_16 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_20 = self->store;
    zT_21 = node.child_1;
    zT_24 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    for_body = zT_24;
    zT_26 = self->diag;
    zT_27 = self->source_file_id;
    zT_28 = node.span_start;
    zT_29 = for_body.span_start;
    zT_36 = zF_C887E05C_diagnosticCollector(zT_26, zT_27, zT_28, zT_29, (unsigned char)(41));
    for_close = zT_36;
    if ((unsigned char)(for_close != (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_75 = self;
    zT_76 = node.child_0;
    zT_78 = zF_54F95822_semanticAnalyzerRes(zT_75, zT_76);
    (void)zT_78;
    zT_80 = "FS:C";
    zT_82 = 4;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    fs_c_m = zT_81;
    zT_83 = fs_c_m;
    zT_84 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_83, zT_84);
    zT_87 = self->store;
    zT_88 = node.child_0;
    zT_91 = zF_FCDD1D35_astStoreNodeAt(zT_87, zT_88);
    cnode = zT_91;
    zT_93 = "FS:CK";
    zT_95 = 5;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    fs_ck_m = zT_94;
    zT_96 = fs_ck_m;
    zT_98 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_96, (unsigned int)((unsigned int)zT_98));
    zT_101 = self->type_table;
    zT_102 = node.child_0;
    zT_105 = zF_999DCF51_resolvedTypeTableGe(zT_101, zT_102);
    it_tid = zT_105;
    zT_106 = it_tid.has_value;
    if (zT_106) goto z_bb_9; else goto z_bb_11;
    z_bb_3:
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    fi_s = zT_41;
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    fi_e = zT_44;
    zT_45 = self->diag;
    zT_46 = self->source_file_id;
    zT_47 = for_close;
    zT_48 = for_body.span_start;
    zT_49 = &fi_s;
    zT_50 = &fi_e;
    zT_56 = zF_BCEBD9F2_diagnosticCollector(zT_45, zT_46, zT_47, zT_48, zT_49, zT_50);
    if (zT_56) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    for_item_s = fi_s;
    for_item_e = fi_e;
    goto z_bb_6;
    z_bb_6:
    zT_58 = 0;
    zT_59 = (unsigned int)zT_58;
    ix_s = zT_59;
    zT_61 = 0;
    zT_62 = (unsigned int)zT_61;
    ix_e = zT_62;
    zT_63 = self->diag;
    zT_64 = self->source_file_id;
    zT_65 = for_item_e;
    zT_66 = for_body.span_start;
    zT_67 = &ix_s;
    zT_68 = &ix_e;
    zT_74 = zF_BCEBD9F2_diagnosticCollector(zT_63, zT_64, zT_65, zT_66, zT_67, zT_68);
    if (zT_74) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    for_idx_s = ix_s;
    for_idx_e = ix_e;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    tid = it_tid.value;
    zT_109 = "FS:T";
    zT_111 = 4;
    zT_110.ptr = zT_109;
    zT_110.len = zT_111;
    fs_tid_m = zT_110;
    zT_112 = fs_tid_m;
    zT_113 = tid;
    zF_C914CB83_markerWriteInt(zT_112, zT_113);
    zT_115 = self->registry;
    zT_116 = zT_115->types_items;
    zT_117 = (unsigned int)tid;
    zT_118 = zT_116[zT_117];
    ty = zT_118;
    zT_121 = 18;
    zT_122 = 0;
    zT_120[zT_122] = zT_121;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        elem_box[_i] = zT_120[_i];
        _i++;
    }
}
    zT_123 = ty.kind;
    if ((unsigned char)(zT_123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_10:
    zT_235 = node.child_2;
    if ((unsigned char)(zT_235 != (unsigned int)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_11:
    zT_231 = "FS:M\n";
    zT_233 = 5;
    zT_232.ptr = zT_231;
    zT_232.len = zT_233;
    a5_m = zT_232;
    zT_234 = a5_m;
    zF_48AC7B3A_markerWrite(zT_234);
    goto z_bb_10;
    z_bb_12:
    zT_127 = self->registry;
    zT_128 = zT_127->slice_items;
    zT_129 = ty.payload_idx;
    zT_130 = (unsigned int)zT_129;
    zT_131 = zT_128[zT_130];
    zT_132 = zT_131.elem;
    zT_133 = 0;
    elem_box[zT_133] = zT_132;
    goto z_bb_13;
    z_bb_13:
    zT_155 = self->store;
    zT_156 = node_idx;
    zT_158 = zF_8BA26B9E_astStoreNodePayload(zT_155, zT_156);
    if ((unsigned char)(zT_158 != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_14:
    zT_134 = ty.kind;
    if ((unsigned char)(zT_134 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_138 = self->registry;
    zT_139 = zT_138->array_items;
    zT_140 = ty.payload_idx;
    zT_141 = (unsigned int)zT_140;
    zT_142 = zT_139[zT_141];
    zT_143 = zT_142.elem;
    zT_144 = 0;
    elem_box[zT_144] = zT_143;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_145 = cnode.kind;
    if ((unsigned char)(zT_145 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_150 = cnode.kind;
    zT_149 = zT_150 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_20;
    z_bb_19:
    zT_149 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_149) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_154 = 0;
    elem_box[zT_154] = tid;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_16;
    z_bb_23:
    zT_162 = 0;
    zT_163 = elem_box[zT_162];
    zT_161 = zT_163 != (unsigned int)(18);
    goto z_bb_25;
    z_bb_24:
    zT_161 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_161) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_167 = "FS:P";
    zT_169 = 4;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    fs_p_m = zT_168;
    zT_170 = fs_p_m;
    zT_172 = self->store;
    zT_173 = node_idx;
    zT_175 = zF_8BA26B9E_astStoreNodePayload(zT_172, zT_173);
    zT_171 = zT_175;
    zF_C914CB83_markerWriteInt(zT_170, zT_171);
    zT_177 = "FS:E";
    zT_179 = 4;
    zT_178.ptr = zT_177;
    zT_178.len = zT_179;
    fs_e_m = zT_178;
    zT_180 = fs_e_m;
    zT_182 = 0;
    zT_181 = elem_box[zT_182];
    zF_C914CB83_markerWriteInt(zT_180, zT_181);
    zT_184 = self;
    zT_188 = self->store;
    zT_189 = node_idx;
    zT_191 = zF_8BA26B9E_astStoreNodePayload(zT_188, zT_189);
    zT_185 = zT_191;
    zT_186 = for_item_s;
    zT_187 = for_item_e;
    zF_C999EE08_semanticAnalyzerChe(zT_184, zT_185, zT_186, zT_187);
    zT_192 = self->local_decl_count;
    zT_193 = self->local_decl_cap;
    if ((unsigned char)(zT_192 >= zT_193)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_10;
    z_bb_28:
    zT_195 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_195);
    goto z_bb_29;
    z_bb_29:
    zT_196 = self->store;
    zT_197 = node_idx;
    zT_199 = zF_8BA26B9E_astStoreNodePayload(zT_196, zT_197);
    zT_200 = self->local_decl_names;
    zT_201 = self->local_decl_count;
    zT_200[zT_201] = zT_199;
    zT_202 = 0;
    zT_203 = elem_box[zT_202];
    zT_204 = self->local_decl_types;
    zT_205 = self->local_decl_count;
    zT_204[zT_205] = zT_203;
    zT_206 = 1;
    zT_207 = self->local_decl_consts;
    zT_208 = self->local_decl_count;
    zT_207[zT_208] = zT_206;
    zT_209 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_209 + (unsigned int)(1));
    zT_213 = "D4F:N";
    zT_215 = 5;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    d4f_n = zT_214;
    zT_216 = d4f_n;
    zT_218 = self->store;
    zT_219 = node_idx;
    zT_221 = zF_8BA26B9E_astStoreNodePayload(zT_218, zT_219);
    zT_217 = zT_221;
    zF_C914CB83_markerWriteInt(zT_216, zT_217);
    zT_223 = "D4F:T";
    zT_225 = 5;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    d4f_t = zT_224;
    zT_226 = d4f_t;
    zT_228 = 0;
    zT_227 = elem_box[zT_228];
    zF_C914CB83_markerWriteInt(zT_226, zT_227);
    goto z_bb_27;
    z_bb_30:
    zT_238 = self;
    zT_239 = node.child_2;
    zT_240 = for_idx_s;
    zT_241 = for_idx_e;
    zF_C999EE08_semanticAnalyzerChe(zT_238, zT_239, zT_240, zT_241);
    zT_243 = self->local_decl_count;
    zT_244 = self->local_decl_cap;
    if ((unsigned char)(zT_243 >= zT_244)) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    return;
    z_bb_32:
    zT_246 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_246);
    goto z_bb_33;
    z_bb_33:
    zT_247 = node.child_2;
    zT_248 = self->local_decl_names;
    zT_249 = self->local_decl_count;
    zT_248[zT_249] = zT_247;
    zT_250 = 13;
    zT_251 = self->local_decl_types;
    zT_252 = self->local_decl_count;
    zT_251[zT_252] = zT_250;
    zT_253 = 1;
    zT_254 = self->local_decl_consts;
    zT_255 = self->local_decl_count;
    zT_254[zT_255] = zT_253;
    zT_256 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_256 + (unsigned int)(1));
    zT_260 = "FIX2:LN";
    zT_262 = 7;
    zT_261.ptr = zT_260;
    zT_261.len = zT_262;
    f2_m = zT_261;
    zT_263 = f2_m;
    zT_264 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_263, zT_264);
    goto z_bb_31;
}

/* semanticAnalyzerResolveWhileHeader */
void zF_10900223_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_15 = {0};
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_38C12417_SemanticAnalyzer* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_62 = 0;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_38C12417_SemanticAnalyzer* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_74 = 0;
    zT_38C12417_SemanticAnalyzer* zT_75;
    unsigned int zT_76;
    unsigned int zT_77 = 0;
    zT_6B0A7D14_AstStore* zT_79;
    unsigned int zT_80;
    unsigned int zT_82 = 0;
    unsigned char zT_84;
    zT_38C12417_SemanticAnalyzer* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned char zT_89;
    unsigned int zT_91;
    zT_38C12417_SemanticAnalyzer* zT_94;
    unsigned int zT_95;
    unsigned int zT_97 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode ws_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_km;
    unsigned int wcond_t;
    unsigned int wcap_idx;
    zT_22A7C88B_AstNode wcap_node;
    unsigned char wcap_present;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_1;
    if ((unsigned char)(zT_7 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self->store;
    zT_12 = node.child_1;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    ws_node = zT_15;
    zT_17 = "WST:N";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    wst_nm = zT_18;
    zT_20 = wst_nm;
    zT_21 = node_idx;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = "WST:K";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    wst_km = zT_24;
    zT_26 = wst_km;
    zT_28 = ws_node.kind;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    goto z_bb_2;
    z_bb_2:
    zT_31 = self;
    zT_32 = node.child_0;
    zT_34 = zF_54F95822_semanticAnalyzerRes(zT_31, zT_32);
    wcond_t = zT_34;
    zT_35 = self->store;
    zT_36 = node_idx;
    zT_38 = zF_8BA26B9E_astStoreNodePayload(zT_35, zT_36);
    if ((unsigned char)(zT_38 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_42 = self->store;
    zT_43 = node_idx;
    zT_45 = zF_8BA26B9E_astStoreNodePayload(zT_42, zT_43);
    wcap_idx = zT_45;
    zT_47 = self->store;
    zT_48 = wcap_idx;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    wcap_node = zT_50;
    zT_51 = wcap_node.kind;
    if ((unsigned char)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_79 = self->store;
    zT_80 = node_idx;
    zT_82 = zF_8BA26B9E_astStoreNodePayload(zT_79, zT_80);
    zT_84 = zT_82 != (unsigned int)(0);
    wcap_present = zT_84;
    zT_85 = self;
    zT_86 = node_idx;
    zT_87 = node.child_0;
    zT_88 = wcond_t;
    zT_89 = wcap_present;
    zF_64F73ABA_semanticAnalyzerChe(zT_85, zT_86, zT_87, zT_88, zT_89);
    zT_91 = node.child_2;
    if ((unsigned char)(zT_91 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_55 = self;
    zT_59 = self->store;
    zT_60 = wcap_idx;
    zT_62 = zF_8BA26B9E_astStoreNodePayload(zT_59, zT_60);
    zT_56 = zT_62;
    zT_57 = wcap_node.span_start;
    zT_64 = wcap_node.span_start;
    zT_65 = wcap_node.span_len;
    zF_C999EE08_semanticAnalyzerChe(zT_55, zT_56, zT_57, (unsigned int)(zT_64 + (unsigned int)((unsigned int)zT_65)));
    zT_68 = self;
    zT_71 = self->store;
    zT_72 = wcap_idx;
    zT_74 = zF_8BA26B9E_astStoreNodePayload(zT_71, zT_72);
    zT_69 = zT_74;
    zT_75 = self;
    zT_76 = wcond_t;
    zT_77 = zF_3E251D67_semanticAnalyzerCap(zT_75, zT_76);
    zT_70 = zT_77;
    zF_7BD72017_registerLocalDecl(zT_68, zT_69, zT_70);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_94 = self;
    zT_95 = node.child_2;
    zT_97 = zF_54F95822_semanticAnalyzerRes(zT_94, zT_95);
    (void)zT_97;
    goto z_bb_8;
    z_bb_8:
    return;
}

/* semanticAnalyzerResolveStmtIter */
void zF_10A0DC35_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int root_node) {
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_38C12417_SemanticAnalyzer* zT_15;
    unsigned int zT_16;
    unsigned char zT_17 = 0;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_22A7C88B_AstNode zT_24 = {0};
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_31;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8143F551_AstKind zT_39;
    zT_8143F551_AstKind zT_41;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    unsigned int zT_49 = 0;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_75;
    unsigned int zT_76;
    unsigned int zT_82 = 0;
    unsigned char* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_6B0A7D14_AstStore* zT_105;
    unsigned int zT_106;
    zT_22A7C88B_AstNode zT_108 = {0};
    zT_8143F551_AstKind zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    zT_38C12417_SemanticAnalyzer* zT_117;
    unsigned int zT_118;
    unsigned int zT_120;
    unsigned char* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    zT_8143F551_AstKind zT_126;
    zT_6B0A7D14_AstStore* zT_130;
    unsigned int zT_131;
    unsigned int zT_133 = 0;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    unsigned char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    unsigned int zT_150;
    zT_6B0A7D14_AstStore* zT_154;
    unsigned int zT_155;
    zT_22A7C88B_AstNode zT_158 = {0};
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    zT_8143F551_AstKind zT_165;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    zT_6B0A7D14_AstStore* zT_173;
    unsigned int zT_174;
    unsigned int zT_176 = 0;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_183;
    unsigned int zT_187;
    unsigned char zT_189;
    unsigned int zT_191;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned int zT_196;
    zT_38C12417_SemanticAnalyzer* zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    unsigned int* zT_201;
    unsigned int* zT_202;
    unsigned char zT_207 = 0;
    zT_38C12417_SemanticAnalyzer* zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_6B0A7D14_AstStore* zT_212;
    unsigned int zT_213;
    unsigned int zT_215 = 0;
    unsigned int zT_216;
    unsigned char zT_219;
    unsigned int zT_220;
    zT_6B0A7D14_AstStore* zT_224;
    unsigned int zT_225;
    zT_22A7C88B_AstNode zT_228 = {0};
    unsigned char zT_230;
    unsigned char zT_234;
    zT_8143F551_AstKind zT_235;
    unsigned char zT_237 = 0;
    zT_8143F551_AstKind zT_238;
    zT_38C12417_SemanticAnalyzer* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    zT_8143F551_AstKind zT_247;
    zT_38C12417_SemanticAnalyzer* zT_251;
    unsigned int zT_252;
    zT_ABC1EBBE_TypeResolveEnv zT_255;
    zT_6B0A7D14_AstStore* zT_256;
    zT_338B7C76_TypeRegistry* zT_257;
    zT_3D7259E2_SymbolRegistry* zT_258;
    zT_D3EB6303_StringInterner* zT_259;
    unsigned int zT_260;
    zT_F85C5DED_DiagnosticCollector* zT_261;
    zT_7034F045_Opt_228 zT_262;
    zT_E2DF2801_LocalConstScope* zT_263;
    zT_03B97CED_Opt_398 zT_264;
    zT_C8A278E4_LocalTypeScope* zT_265;
    zT_05CE5599_Opt_400 zT_266;
    unsigned int zT_267;
    zT_ABC1EBBE_TypeResolveEnv* zT_268;
    unsigned int zT_269;
    zT_8143F551_AstKind zT_270;
    unsigned int zT_276 = 0;
    zT_338B7C76_TypeRegistry* zT_280;
    unsigned int zT_281;
    unsigned char zT_285 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    zT_8EED1867_ResolvedTypeTable* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    zT_C8A278E4_LocalTypeScope* zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    zT_6B0A7D14_AstStore* zT_299;
    unsigned int zT_300;
    unsigned int zT_302 = 0;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_38C12417_SemanticAnalyzer* zT_306;
    zT_6B0A7D14_AstStore* zT_307;
    unsigned int zT_308;
    unsigned int zT_310 = 0;
    unsigned int* zT_311;
    unsigned int zT_312;
    unsigned int* zT_313;
    unsigned int zT_314;
    unsigned char zT_315;
    unsigned char* zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_F85C5DED_DiagnosticCollector* zT_325;
    unsigned int zT_328;
    unsigned int zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int zT_341 = 0;
    unsigned char zT_342;
    zT_8143F551_AstKind zT_343;
    zT_6B0A7D14_AstStore* zT_348;
    unsigned int zT_349;
    unsigned int zT_352 = 0;
    zT_C8A278E4_LocalTypeScope* zT_353;
    unsigned int zT_354;
    zT_BAEE192E_Opt_10 zT_356 = {0};
    unsigned char zT_357;
    unsigned char* zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    unsigned int zT_361;
    zT_F85C5DED_DiagnosticCollector* zT_362;
    unsigned int zT_365;
    unsigned int zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    unsigned int zT_374;
    unsigned int zT_375;
    unsigned int zT_378 = 0;
    unsigned char zT_379;
    zT_8143F551_AstKind zT_380;
    unsigned char zT_382 = 0;
    unsigned char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_F85C5DED_DiagnosticCollector* zT_387;
    unsigned int zT_390;
    unsigned int zT_391;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned int zT_403 = 0;
    unsigned char zT_404;
    unsigned int zT_405;
    zT_6B0A7D14_AstStore* zT_409;
    unsigned int zT_410;
    zT_22A7C88B_AstNode zT_413 = {0};
    zT_8143F551_AstKind zT_414;
    zT_38C12417_SemanticAnalyzer* zT_418;
    unsigned int zT_419;
    unsigned int zT_421 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_425;
    zT_6B0A7D14_AstStore* zT_426;
    zT_338B7C76_TypeRegistry* zT_427;
    zT_3D7259E2_SymbolRegistry* zT_428;
    zT_D3EB6303_StringInterner* zT_429;
    unsigned int zT_430;
    zT_F85C5DED_DiagnosticCollector* zT_431;
    zT_7034F045_Opt_228 zT_432;
    zT_E2DF2801_LocalConstScope* zT_433;
    zT_03B97CED_Opt_398 zT_434;
    zT_C8A278E4_LocalTypeScope* zT_435;
    zT_05CE5599_Opt_400 zT_436;
    unsigned int zT_437;
    zT_ABC1EBBE_TypeResolveEnv* zT_439;
    unsigned int zT_440;
    unsigned int zT_445 = 0;
    unsigned char* zT_449;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_450;
    unsigned int zT_451;
    zT_F85C5DED_DiagnosticCollector* zT_452;
    unsigned int zT_455;
    unsigned int zT_456;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_458;
    unsigned int zT_464;
    unsigned int zT_465;
    unsigned int zT_468 = 0;
    unsigned int zT_469;
    zT_8EED1867_ResolvedTypeTable* zT_471;
    unsigned int zT_472;
    zT_BAEE192E_Opt_10 zT_475 = {0};
    unsigned char zT_476;
    zT_ABC1EBBE_TypeResolveEnv zT_479;
    zT_6B0A7D14_AstStore* zT_480;
    zT_338B7C76_TypeRegistry* zT_481;
    zT_3D7259E2_SymbolRegistry* zT_482;
    zT_D3EB6303_StringInterner* zT_483;
    unsigned int zT_484;
    zT_F85C5DED_DiagnosticCollector* zT_485;
    zT_7034F045_Opt_228 zT_486;
    zT_E2DF2801_LocalConstScope* zT_487;
    zT_03B97CED_Opt_398 zT_488;
    zT_C8A278E4_LocalTypeScope* zT_489;
    zT_05CE5599_Opt_400 zT_490;
    unsigned int zT_491;
    zT_ABC1EBBE_TypeResolveEnv* zT_492;
    unsigned int zT_493;
    unsigned int zT_498 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_501;
    unsigned int zT_502;
    unsigned int zT_503;
    int zT_506;
    unsigned char* zT_512;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_513;
    unsigned int zT_514;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_515;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_517;
    unsigned int zT_519;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_520;
    int zT_524;
    unsigned char* zT_525;
    unsigned int zT_526;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_527;
    unsigned int zT_528 = 0;
    unsigned int zT_532;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_533;
    unsigned char* zT_537;
    unsigned int zT_538;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_539;
    unsigned char* zT_541;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_542;
    unsigned int zT_543;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_544;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_546;
    unsigned int zT_548;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_549;
    int zT_552;
    unsigned char* zT_553;
    unsigned int zT_554;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_555;
    unsigned int zT_556 = 0;
    unsigned int zT_560;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_561;
    unsigned char* zT_565;
    unsigned int zT_566;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_567;
    unsigned char* zT_569;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_570;
    unsigned int zT_571;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_572;
    unsigned int zT_573;
    unsigned char zT_576;
    unsigned int zT_581;
    unsigned int zT_583;
    unsigned int zT_585;
    unsigned char* zT_587;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_588;
    unsigned int zT_589;
    zT_F85C5DED_DiagnosticCollector* zT_590;
    unsigned int zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_596;
    unsigned int zT_603 = 0;
    unsigned int zT_604;
    zT_6B0A7D14_AstStore* zT_608;
    unsigned int zT_609;
    zT_22A7C88B_AstNode zT_612 = {0};
    unsigned char* zT_614;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_615;
    unsigned int zT_616;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_617;
    zT_8143F551_AstKind zT_619;
    unsigned int zT_625;
    zT_38C12417_SemanticAnalyzer* zT_627;
    unsigned int zT_628;
    zT_38C12417_SemanticAnalyzer* zT_630;
    unsigned int zT_631;
    unsigned int zT_633 = 0;
    zT_38C12417_SemanticAnalyzer* zT_634;
    unsigned char zT_638;
    zT_8143F551_AstKind zT_639;
    zT_6B0A7D14_AstStore* zT_644;
    unsigned int zT_645;
    unsigned int zT_648 = 0;
    int zT_650;
    unsigned int zT_651;
    zT_338B7C76_TypeRegistry* zT_652;
    unsigned int zT_653;
    zT_338B7C76_TypeRegistry* zT_655;
    zT_D155D06D_Type* zT_656;
    zT_D155D06D_Type zT_657;
    zT_33EF6BFB_TypeKind zT_658;
    zT_338B7C76_TypeRegistry* zT_663;
    unsigned int zT_665;
    unsigned int zT_668 = 0;
    unsigned int zT_672;
    zT_21D3708C_U32ToU32Map* zT_674;
    unsigned int zT_675;
    unsigned int zT_677 = 0;
    zT_21D3708C_U32ToU32Map* zT_678;
    unsigned int zT_679;
    unsigned int zT_680;
    zT_8EED1867_ResolvedTypeTable* zT_683;
    unsigned int zT_684;
    unsigned int zT_685;
    int zT_688;
    unsigned int zT_690;
    unsigned char zT_694;
    zT_8143F551_AstKind zT_695;
    unsigned int zT_700;
    unsigned int zT_702;
    unsigned int zT_704;
    unsigned char* zT_706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_707;
    unsigned int zT_708;
    zT_F85C5DED_DiagnosticCollector* zT_709;
    unsigned int zT_712;
    unsigned int zT_713;
    unsigned int zT_714;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_715;
    unsigned int zT_722 = 0;
    unsigned char zT_726;
    unsigned char* zT_731;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_732;
    unsigned int zT_733;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_734;
    zT_38C12417_SemanticAnalyzer* zT_736;
    unsigned int zT_737;
    unsigned int zT_738;
    unsigned int zT_739;
    unsigned int zT_741 = 0;
    zT_38C12417_SemanticAnalyzer* zT_742;
    unsigned int zT_743;
    unsigned int zT_744;
    unsigned int zT_745;
    unsigned char zT_747 = 0;
    zT_338B7C76_TypeRegistry* zT_749;
    unsigned int zT_750;
    unsigned int zT_751;
    zT_0FB7FB13_CoercionKind zT_753 = 0;
    unsigned char* zT_755;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_756;
    unsigned int zT_757;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_758;
    unsigned char zT_764;
    zT_338B7C76_TypeRegistry* zT_765;
    unsigned int zT_766;
    unsigned int zT_767;
    unsigned char zT_769 = 0;
    zT_66E7D2EF_CoercionTable* zT_770;
    unsigned int zT_771;
    zT_0FB7FB13_CoercionKind zT_772;
    unsigned int zT_773;
    unsigned char zT_778;
    zT_338B7C76_TypeRegistry* zT_779;
    unsigned int zT_780;
    unsigned int zT_781;
    unsigned char zT_783 = 0;
    unsigned int zT_786;
    unsigned int zT_788;
    unsigned int zT_790;
    unsigned char* zT_792;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_793;
    unsigned int zT_794;
    zT_338B7C76_TypeRegistry* zT_796;
    zT_D155D06D_Type* zT_797;
    unsigned int zT_798;
    zT_D155D06D_Type zT_799;
    zT_33EF6BFB_TypeKind zT_800;
    zT_338B7C76_TypeRegistry* zT_802;
    zT_D155D06D_Type* zT_803;
    unsigned int zT_804;
    zT_D155D06D_Type zT_805;
    zT_33EF6BFB_TypeKind zT_806;
    int zT_808;
    unsigned char zT_809;
    zT_38C12417_SemanticAnalyzer* zT_810;
    unsigned int zT_811;
    unsigned int zT_812;
    unsigned char zT_813 = 0;
    int zT_814;
    unsigned char zT_815;
    zT_38C12417_SemanticAnalyzer* zT_816;
    unsigned int zT_817;
    unsigned int zT_818;
    unsigned char zT_821 = 0;
    int zT_822;
    unsigned char zT_823;
    unsigned char zT_827;
    zT_338B7C76_TypeRegistry* zT_832;
    zT_42C2D6BF_EUPayload* zT_833;
    zT_338B7C76_TypeRegistry* zT_834;
    zT_D155D06D_Type* zT_835;
    unsigned int zT_836;
    zT_D155D06D_Type zT_837;
    unsigned int zT_838;
    unsigned int zT_839;
    zT_42C2D6BF_EUPayload zT_840;
    zT_338B7C76_TypeRegistry* zT_842;
    zT_42C2D6BF_EUPayload* zT_843;
    zT_338B7C76_TypeRegistry* zT_844;
    zT_D155D06D_Type* zT_845;
    unsigned int zT_846;
    zT_D155D06D_Type zT_847;
    unsigned int zT_848;
    unsigned int zT_849;
    zT_42C2D6BF_EUPayload zT_850;
    unsigned int zT_851;
    unsigned int zT_852;
    int zT_854;
    unsigned char zT_855;
    zT_F85C5DED_DiagnosticCollector* zT_857;
    unsigned char zT_858;
    unsigned int zT_860;
    unsigned int zT_861;
    unsigned int zT_862;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_863;
    unsigned int zT_867 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_868;
    unsigned int zT_869;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_870;
    zT_33EF6BFB_TypeKind zT_872;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_873 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_874;
    unsigned int zT_875;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_876;
    zT_33EF6BFB_TypeKind zT_878;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_879 = {0};
    unsigned char* zT_886;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_887;
    unsigned int zT_888;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_889;
    unsigned char* zT_891;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_892;
    unsigned int zT_893;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_894;
    unsigned int zT_896;
    unsigned int zT_898;
    unsigned int zT_900;
    unsigned char* zT_902;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_903;
    unsigned int zT_904;
    zT_F85C5DED_DiagnosticCollector* zT_905;
    unsigned int zT_908;
    unsigned int zT_909;
    unsigned int zT_910;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_911;
    unsigned int zT_916 = 0;
    zT_66E7D2EF_CoercionTable* zT_918;
    unsigned int zT_919;
    zT_5CC037A7_Opt_194 zT_922 = {0};
    unsigned char zT_923;
    zT_8EED1867_ResolvedTypeTable* zT_925;
    unsigned int zT_926;
    unsigned int zT_927;
    unsigned char zT_930;
    unsigned char zT_935;
    unsigned int zT_936;
    zT_E2DF2801_LocalConstScope* zT_939;
    unsigned int zT_940;
    unsigned int zT_941;
    zT_6B0A7D14_AstStore* zT_943;
    unsigned int zT_944;
    unsigned int zT_946 = 0;
    unsigned int zT_947;
    unsigned int zT_948;
    zT_38C12417_SemanticAnalyzer* zT_950;
    zT_6B0A7D14_AstStore* zT_954;
    unsigned int zT_955;
    unsigned int zT_957 = 0;
    unsigned int* zT_958;
    unsigned int zT_959;
    unsigned int* zT_960;
    unsigned int zT_961;
    unsigned char zT_962;
    unsigned char zT_967;
    unsigned char* zT_970;
    unsigned int zT_971;
    unsigned int zT_972;
    unsigned int zT_976;
    zT_6B0A7D14_AstStore* zT_980;
    unsigned int zT_981;
    unsigned int zT_983 = 0;
    zT_79FAE712_u64 zT_985;
    zT_338B7C76_TypeRegistry* zT_986;
    zT_79FAE712_u64 zT_987;
    unsigned int zT_988;
    unsigned char* zT_991;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_992;
    unsigned int zT_993;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_994;
    unsigned int zT_995;
    zT_6B0A7D14_AstStore* zT_996;
    unsigned int zT_997;
    unsigned int zT_999 = 0;
    unsigned char* zT_1001;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1002;
    unsigned int zT_1003;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1004;
    unsigned int zT_1005;
    zT_8143F551_AstKind zT_1006;
    unsigned int zT_1011;
    unsigned int zT_1012;
    zT_38C12417_SemanticAnalyzer* zT_1013;
    unsigned int zT_1014;
    zT_38C12417_SemanticAnalyzer* zT_1015;
    unsigned int zT_1019;
    zT_38C12417_SemanticAnalyzer* zT_1022;
    unsigned int zT_1023;
    unsigned int zT_1025;
    zT_38C12417_SemanticAnalyzer* zT_1028;
    unsigned int zT_1029;
    zT_8143F551_AstKind zT_1031;
    unsigned int zT_1036;
    unsigned int zT_1037;
    zT_38C12417_SemanticAnalyzer* zT_1038;
    unsigned int zT_1039;
    zT_38C12417_SemanticAnalyzer* zT_1040;
    unsigned int zT_1044;
    zT_38C12417_SemanticAnalyzer* zT_1047;
    unsigned int zT_1048;
    zT_8143F551_AstKind zT_1050;
    unsigned int zT_1055;
    unsigned int zT_1056;
    zT_38C12417_SemanticAnalyzer* zT_1057;
    unsigned int zT_1058;
    zT_38C12417_SemanticAnalyzer* zT_1059;
    unsigned int zT_1063;
    zT_38C12417_SemanticAnalyzer* zT_1066;
    unsigned int zT_1067;
    zT_8143F551_AstKind zT_1069;
    zT_38C12417_SemanticAnalyzer* zT_1073;
    unsigned int zT_1074;
    zT_8143F551_AstKind zT_1075;
    unsigned char zT_1079;
    zT_8143F551_AstKind zT_1080;
    unsigned char zT_1084;
    zT_8143F551_AstKind zT_1085;
    unsigned char zT_1089;
    zT_8143F551_AstKind zT_1090;
    unsigned char zT_1094;
    zT_8143F551_AstKind zT_1095;
    unsigned char zT_1099;
    zT_8143F551_AstKind zT_1100;
    unsigned char zT_1104;
    zT_8143F551_AstKind zT_1105;
    unsigned char zT_1109;
    zT_8143F551_AstKind zT_1110;
    unsigned char zT_1114;
    zT_8143F551_AstKind zT_1115;
    unsigned char zT_1119;
    zT_8143F551_AstKind zT_1120;
    unsigned char zT_1124;
    zT_8143F551_AstKind zT_1125;
    unsigned char zT_1129;
    zT_8143F551_AstKind zT_1130;
    unsigned char zT_1134;
    zT_8143F551_AstKind zT_1135;
    unsigned char zT_1139;
    zT_8143F551_AstKind zT_1140;
    unsigned char zT_1144;
    zT_8143F551_AstKind zT_1145;
    unsigned char zT_1149;
    zT_8143F551_AstKind zT_1150;
    unsigned char zT_1154;
    zT_8143F551_AstKind zT_1155;
    unsigned char zT_1159;
    zT_8143F551_AstKind zT_1160;
    zT_38C12417_SemanticAnalyzer* zT_1164;
    unsigned int zT_1165;
    unsigned int zT_1166 = 0;
    zT_8143F551_AstKind zT_1167;
    unsigned int zT_1171;
    zT_38C12417_SemanticAnalyzer* zT_1174;
    unsigned int zT_1175;
    zT_8143F551_AstKind zT_1177;
    unsigned char zT_1181;
    zT_8143F551_AstKind zT_1182;
    unsigned int zT_1186;
    unsigned int zT_1190;
    unsigned int zT_1192;
    zT_38C12417_SemanticAnalyzer* zT_1195;
    unsigned int zT_1196;
    unsigned int zT_1198;
    zT_38C12417_SemanticAnalyzer* zT_1201;
    unsigned int zT_1202;
    unsigned int zT_1204;
    zT_8143F551_AstKind zT_1207;
    zT_8143F551_AstKind zT_1211;
    unsigned char* zT_1216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1217;
    unsigned int zT_1218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1219;
    unsigned int zT_1220;
    unsigned char* zT_1222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1223;
    unsigned int zT_1224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1225;
    zT_8143F551_AstKind zT_1227;
    unsigned int zT_1229;
    unsigned char* zT_1233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1234;
    unsigned int zT_1235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1236;
    unsigned int zT_1237;
    zT_38C12417_SemanticAnalyzer* zT_1240;
    unsigned int zT_1241;
    unsigned int zT_1242 = 0;
    unsigned char zT_1245;
    zT_338B7C76_TypeRegistry* zT_1247;
    unsigned int zT_1248;
    unsigned char zT_1250;
    zT_338B7C76_TypeRegistry* zT_1251;
    zT_D155D06D_Type* zT_1252;
    unsigned int zT_1253;
    zT_D155D06D_Type zT_1254;
    zT_33EF6BFB_TypeKind zT_1255;
    unsigned int zT_1260;
    unsigned int zT_1262;
    unsigned int zT_1264;
    unsigned char* zT_1266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1267;
    unsigned int zT_1268;
    zT_F85C5DED_DiagnosticCollector* zT_1269;
    unsigned int zT_1272;
    unsigned int zT_1273;
    unsigned int zT_1274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1275;
    unsigned int zT_1282 = 0;
    unsigned int zT_1283;
    zT_6B0A7D14_AstStore* zT_1287;
    unsigned int zT_1288;
    zT_22A7C88B_AstNode zT_1291 = {0};
    zT_8143F551_AstKind zT_1292;
    unsigned int zT_1296;
    zT_6B0A7D14_AstStore* zT_1300;
    unsigned int zT_1301;
    zT_22A7C88B_AstNode zT_1304 = {0};
    zT_8143F551_AstKind zT_1305;
    unsigned int sp_base;
    unsigned int node_idx;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u spk_m;
    unsigned int children_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_cm;
    unsigned int blk_scope_saved;
    unsigned int i;
    unsigned int ci;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_nm;
    zT_8143F551_AstKind cnode_k;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u bcej;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd2_m;
    unsigned int decl_type;
    unsigned char vd_type_binding;
    unsigned int vd_ns;
    unsigned int vd_ne;
    zT_22A7C88B_AstNode inode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10k_m;
    zT_22A7C88B_AstNode vd_init_node;
    unsigned char vd_is_const;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_var_msg;
    zT_ABC1EBBE_TypeResolveEnv vd_lt_env;
    unsigned int vd_alias_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_alias_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_texpr_msg;
    zT_22A7C88B_AstNode ann;
    zT_BAEE192E_Opt_10 rt;
    zT_ABC1EBBE_TypeResolveEnv cd_env;
    unsigned int cd_full;
    zT_8F083A69_Slice_zT_0B42B2F8_u ut_msg;
    unsigned int t;
    zT_ABC1EBBE_TypeResolveEnv tre_env_vd;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1m;
    zT_5A26C2ED_Arr_unsigned_char_1 b1nb;
    unsigned int b1nl;
    unsigned int b1ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1c;
    zT_5A26C2ED_Arr_unsigned_char_1 b1tb;
    unsigned int b1tl;
    unsigned int b1ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1nl2;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui_msg;
    zT_22A7C88B_AstNode init_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ik_m;
    unsigned int vd_exp;
    unsigned int it;
    unsigned int name_id;
    unsigned int ei;
    unsigned int ord;
    unsigned int es_type_id;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs4_m;
    unsigned int it_eff;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u ckv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmd_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdag_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vfvd_m;
    unsigned int vsp;
    unsigned int vep;
    zT_8F083A69_Slice_zT_0B42B2F8_u vv_msg;
    zT_5CC037A7_Opt_194 ct_entry;
    zT_79FAE712_u64 ck_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u regcp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u regct_m;
    unsigned int if_scope_saved;
    unsigned int w_scope_saved;
    unsigned int for_scope_saved;
    unsigned int dc_saved_loops;
    unsigned int dc_saved_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_c0m;
    unsigned int els_r;
    unsigned int eisp;
    unsigned int eiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ei_msg;
    zT_22A7C88B_AstNode nc;
    zT_3 = self->stmt_work_len;
    sp_base = zT_3;
    zT_4 = self;
    zT_5 = root_node;
    zF_7AB741D8_semanticAnalyzerStm(zT_4, zT_5);
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->stmt_work_len;
    if ((unsigned char)(zT_6 > sp_base)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_8 - (unsigned int)(1));
    zT_12 = self->stmt_work_items;
    zT_13 = self->stmt_work_len;
    zT_14 = zT_12[zT_13];
    node_idx = zT_14;
    zT_15 = self;
    zT_16 = node_idx;
    zT_17 = zF_2FC8BE84_semanticAnalyzerPop(zT_15, zT_16);
    if (zT_17) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_21 = self->store;
    zT_22 = node_idx;
    zT_24 = zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    node = zT_24;
    zT_26 = "SP:n";
    zT_28 = 4;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    sp_m = zT_27;
    zT_29 = sp_m;
    zT_31 = self->stmt_work_len;
    zF_C914CB83_markerWriteInt(zT_29, (unsigned int)((unsigned int)zT_31));
    zT_34 = "SP:K";
    zT_36 = 4;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    spk_m = zT_35;
    zT_37 = spk_m;
    zT_39 = node.kind;
    zF_C914CB83_markerWriteInt(zT_37, (unsigned int)((unsigned int)zT_39));
    zT_41 = node.kind;
    if ((unsigned char)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_46 = self->store;
    zT_47 = node_idx;
    zT_49 = zF_152E19CB_astStoreNodeExtraCh(zT_46, zT_47);
    children_n = zT_49;
    zT_51 = "BLK:N";
    zT_53 = 5;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    blk_nm = zT_52;
    zT_54 = blk_nm;
    zT_55 = node_idx;
    zF_C914CB83_markerWriteInt(zT_54, zT_55);
    zT_57 = "BLK:C";
    zT_59 = 5;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    blk_cm = zT_58;
    zT_60 = blk_cm;
    zF_C914CB83_markerWriteInt(zT_60, (unsigned int)((unsigned int)children_n));
    zT_64 = self->local_decl_count;
    zT_65 = (unsigned int)zT_64;
    blk_scope_saved = zT_65;
    zT_66 = self;
    zF_7AB741D8_semanticAnalyzerStm(zT_66, (unsigned int)((unsigned int)(2147483648u) | blk_scope_saved));
    zT_71 = (unsigned int)children_n;
    i = zT_71;
    goto z_bb_12;
    z_bb_10:
    zT_1283 = node.child_0;
    if ((unsigned char)(zT_1283 != (unsigned int)(0))) goto z_bb_248; else goto z_bb_249;
    z_bb_11:
    zT_126 = node.kind;
    if ((unsigned char)(zT_126 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_16; else goto z_bb_18;
    z_bb_12:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_75 = self->store;
    zT_76 = node_idx;
    zT_82 = zF_B10B1BC1_astStoreNodeExtraCh(zT_75, zT_76, (unsigned int)((unsigned int)((unsigned int)i) - (unsigned int)(1)));
    ci = zT_82;
    zT_84 = "BCK:B";
    zT_86 = 5;
    zT_85.ptr = zT_84;
    zT_85.len = zT_86;
    bc_m = zT_85;
    zT_87 = bc_m;
    zT_88 = node_idx;
    zF_C914CB83_markerWriteInt(zT_87, zT_88);
    zT_90 = "BCK:I";
    zT_92 = 5;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    bc_im = zT_91;
    zT_93 = bc_im;
    zF_C914CB83_markerWriteInt(zT_93, (unsigned int)((unsigned int)(unsigned int)(i - (unsigned int)(1))));
    zT_99 = "BCK:N";
    zT_101 = 5;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    bc_nm = zT_100;
    zT_102 = bc_nm;
    zT_103 = ci;
    zF_C914CB83_markerWriteInt(zT_102, zT_103);
    zT_105 = self->store;
    zT_106 = ci;
    zT_108 = zF_FCDD1D35_astStoreNodeAt(zT_105, zT_106);
    zT_109 = zT_108.kind;
    cnode_k = zT_109;
    zT_111 = "BCK:K";
    zT_113 = 5;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    bc_km = zT_112;
    zT_114 = bc_km;
    zF_C914CB83_markerWriteInt(zT_114, (unsigned int)((unsigned int)cnode_k));
    zT_117 = self;
    zT_118 = ci;
    zF_7AB741D8_semanticAnalyzerStm(zT_117, zT_118);
    goto z_bb_15;
    z_bb_14:
    zT_122 = "]\n";
    zT_124 = 2;
    zT_123.ptr = zT_122;
    zT_123.len = zT_124;
    bcej = zT_123;
    zT_125 = bcej;
    zF_48AC7B3A_markerWrite(zT_125);
    goto z_bb_10;
    z_bb_15:
    zT_120 = i - (unsigned int)(1);
    i = zT_120;
    goto z_bb_12;
    z_bb_16:
    zT_130 = self->store;
    zT_131 = node_idx;
    zT_133 = zF_8BA26B9E_astStoreNodePayload(zT_130, zT_131);
    if ((unsigned char)(zT_133 == (unsigned int)(55))) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_1006 = node.kind;
    if ((unsigned char)(zT_1006 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_145; else goto z_bb_147;
    z_bb_19:
    zT_137 = "D10:C0";
    zT_139 = 6;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    d10n_m = zT_138;
    zT_140 = d10n_m;
    zT_141 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_140, zT_141);
    zT_144 = "D10:C1";
    zT_146 = 6;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    d10c_m = zT_145;
    zT_147 = d10c_m;
    zT_148 = node.child_1;
    zF_C914CB83_markerWriteInt(zT_147, zT_148);
    zT_150 = node.child_1;
    if ((unsigned char)(zT_150 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_168 = "VD:N";
    zT_170 = 4;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    vd_m = zT_169;
    zT_171 = vd_m;
    zT_173 = self->store;
    zT_174 = node_idx;
    zT_176 = zF_8BA26B9E_astStoreNodePayload(zT_173, zT_174);
    zT_172 = zT_176;
    zF_C914CB83_markerWriteInt(zT_171, zT_172);
    zT_178 = "VD:C";
    zT_180 = 4;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    vd2_m = zT_179;
    zT_181 = vd2_m;
    zT_183 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_181, (unsigned int)((unsigned int)zT_183));
    zT_187 = 18;
    decl_type = zT_187;
    zT_189 = 0;
    vd_type_binding = zT_189;
    zT_191 = node.span_start;
    vd_ns = zT_191;
    zT_193 = node.span_start;
    zT_194 = node.span_len;
    zT_196 = zT_193 + (unsigned int)((unsigned int)zT_194);
    vd_ne = zT_196;
    zT_197 = self;
    zT_198 = node.span_start;
    zT_199 = vd_ne;
    zT_201 = &vd_ns;
    zT_202 = &vd_ne;
    zT_207 = zF_4679EA8B_semanticAnalyzerNth(zT_197, zT_198, zT_199, (unsigned int)(2), zT_201, zT_202);
    (void)zT_207;
    zT_208 = self;
    zT_212 = self->store;
    zT_213 = node_idx;
    zT_215 = zF_8BA26B9E_astStoreNodePayload(zT_212, zT_213);
    zT_209 = zT_215;
    zT_210 = vd_ns;
    zT_211 = vd_ne;
    zF_C999EE08_semanticAnalyzerChe(zT_208, zT_209, zT_210, zT_211);
    zT_216 = node.child_0;
    if ((unsigned char)(zT_216 == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    zT_154 = self->store;
    zT_155 = node.child_1;
    zT_158 = zF_FCDD1D35_astStoreNodeAt(zT_154, zT_155);
    inode = zT_158;
    zT_160 = "D10:IK";
    zT_162 = 6;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    d10k_m = zT_161;
    zT_163 = d10k_m;
    zT_165 = inode.kind;
    zF_C914CB83_markerWriteInt(zT_163, (unsigned int)((unsigned int)zT_165));
    goto z_bb_22;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_220 = node.child_1;
    zT_219 = zT_220 != (unsigned int)(0);
    goto z_bb_25;
    z_bb_24:
    zT_219 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_219) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_224 = self->store;
    zT_225 = node.child_1;
    zT_228 = zF_FCDD1D35_astStoreNodeAt(zT_224, zT_225);
    vd_init_node = zT_228;
    zT_230 = node.flags;
    zT_234 = (unsigned char)(zT_230 & (unsigned char)(1)) == (unsigned char)(0);
    vd_is_const = zT_234;
    zT_235 = vd_init_node.kind;
    zT_237 = zF_82C2F046_isContainerDeclKind(zT_235);
    if (zT_237) goto z_bb_28; else goto z_bb_30;
    z_bb_27:
    zT_405 = node.child_0;
    if ((unsigned char)(zT_405 != (unsigned int)(0))) goto z_bb_49; else goto z_bb_50;
    z_bb_28:
    if (vd_is_const) goto z_bb_31; else goto z_bb_33;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    zT_343 = vd_init_node.kind;
    if ((unsigned char)(zT_343 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_42; else goto z_bb_44;
    z_bb_31:
    zT_238 = vd_init_node.kind;
    if ((unsigned char)(zT_238 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    zT_342 = 1;
    vd_type_binding = zT_342;
    goto z_bb_29;
    z_bb_33:
    zT_322 = "a local type value must be declared with 'const'";
    zT_324 = 48;
    zT_323.ptr = zT_322;
    zT_323.len = zT_324;
    vd_var_msg = zT_323;
    zT_325 = self->diag;
    zT_328 = self->source_file_id;
    zT_329 = node.span_start;
    zT_337 = node.span_start;
    zT_338 = node.span_len;
    zT_331 = vd_var_msg;
    zT_341 = zF_C82559AC_diagnosticCollector(zT_325, (unsigned char)(0), (unsigned short)(3000), zT_328, zT_329, (unsigned int)(zT_337 + (unsigned int)((unsigned int)zT_338)), zT_331);
    (void)zT_341;
    goto z_bb_32;
    z_bb_34:
    zT_242 = self;
    zT_243 = node.child_1;
    zT_244 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_242, zT_243, zT_244);
    goto z_bb_35;
    z_bb_35:
    zT_247 = vd_init_node.kind;
    if ((unsigned char)(zT_247 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_251 = self;
    zT_252 = node.child_1;
    zF_E3AF2BA9_semanticAnalyzerChe(zT_251, zT_252);
    goto z_bb_37;
    z_bb_37:
    zT_256 = self->store;
    zT_255.store = zT_256;
    zT_257 = self->registry;
    zT_255.typereg = zT_257;
    zT_258 = self->symbols;
    zT_255.symbol_reg = zT_258;
    zT_259 = self->interner;
    zT_255.interner = zT_259;
    zT_260 = self->module_id;
    zT_255.module_id = zT_260;
    zT_261 = self->diag;
    zT_262.has_value = 1;
    zT_262.value = zT_261;
    zT_255.diag = zT_262;
    zT_263 = &self->local_consts;
    zT_264.has_value = 1;
    zT_264.value = zT_263;
    zT_255.local_consts = zT_264;
    zT_265 = &self->local_types;
    zT_266.has_value = 1;
    zT_266.value = zT_265;
    zT_255.local_types = zT_266;
    zT_267 = self->source_file_id;
    zT_255.source_file_id = zT_267;
    vd_lt_env = zT_255;
    zT_268 = &vd_lt_env;
    zT_269 = node.child_1;
    zT_270 = vd_init_node.kind;
    zT_276 = zF_FE81311F_registerContainerTy(zT_268, zT_269, zT_270, (unsigned int)(0));
    decl_type = zT_276;
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_280 = self->registry;
    zT_281 = decl_type;
    zT_285 = zF_3E55D0D5_layoutEnsure(zT_280, zT_281, (unsigned int)(0));
    (void)zT_285;
    zT_286 = self->type_table;
    zT_287 = node.child_1;
    zT_288 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_286, zT_287, zT_288);
    zT_291 = self->type_table;
    zT_292 = node_idx;
    zT_293 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_291, zT_292, zT_293);
    zT_295 = &self->local_types;
    zT_299 = self->store;
    zT_300 = node_idx;
    zT_302 = zF_8BA26B9E_astStoreNodePayload(zT_299, zT_300);
    zT_296 = zT_302;
    zT_297 = decl_type;
    zF_A3A445A0_localTypeScopePush(zT_295, zT_296, zT_297);
    zT_303 = self->local_decl_count;
    zT_304 = self->local_decl_cap;
    if ((unsigned char)(zT_303 >= zT_304)) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_32;
    z_bb_40:
    zT_306 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_306);
    goto z_bb_41;
    z_bb_41:
    zT_307 = self->store;
    zT_308 = node_idx;
    zT_310 = zF_8BA26B9E_astStoreNodePayload(zT_307, zT_308);
    zT_311 = self->local_decl_names;
    zT_312 = self->local_decl_count;
    zT_311[zT_312] = zT_310;
    zT_313 = self->local_decl_types;
    zT_314 = self->local_decl_count;
    zT_313[zT_314] = decl_type;
    zT_315 = 1;
    zT_316 = self->local_decl_consts;
    zT_317 = self->local_decl_count;
    zT_316[zT_317] = zT_315;
    zT_318 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_318 + (unsigned int)(1));
    goto z_bb_39;
    z_bb_42:
    zT_348 = self->store;
    zT_349 = node.child_1;
    zT_352 = zF_53458827_astStoreIdentifier(zT_348, zT_349);
    vd_alias_name = zT_352;
    zT_353 = &self->local_types;
    zT_354 = vd_alias_name;
    zT_356 = zF_C768898A_localTypeScopeLooku(zT_353, zT_354);
    zT_357 = zT_356.has_value;
    if (zT_357) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_29;
    z_bb_44:
    zT_380 = vd_init_node.kind;
    zT_382 = zF_599C0D79_isCompoundTypeExprK(zT_380);
    if (zT_382) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    zT_359 = "local type aliases are not supported; bind the container declaration directly";
    zT_361 = 77;
    zT_360.ptr = zT_359;
    zT_360.len = zT_361;
    vd_alias_msg = zT_360;
    zT_362 = self->diag;
    zT_365 = self->source_file_id;
    zT_366 = node.span_start;
    zT_374 = node.span_start;
    zT_375 = node.span_len;
    zT_368 = vd_alias_msg;
    zT_378 = zF_C82559AC_diagnosticCollector(zT_362, (unsigned char)(0), (unsigned short)(3000), zT_365, zT_366, (unsigned int)(zT_374 + (unsigned int)((unsigned int)zT_375)), zT_368);
    (void)zT_378;
    zT_379 = 1;
    vd_type_binding = zT_379;
    goto z_bb_46;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_384 = "local type aliases are not supported; bind the container declaration directly";
    zT_386 = 77;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    vd_texpr_msg = zT_385;
    zT_387 = self->diag;
    zT_390 = self->source_file_id;
    zT_391 = node.span_start;
    zT_399 = node.span_start;
    zT_400 = node.span_len;
    zT_393 = vd_texpr_msg;
    zT_403 = zF_C82559AC_diagnosticCollector(zT_387, (unsigned char)(0), (unsigned short)(3000), zT_390, zT_391, (unsigned int)(zT_399 + (unsigned int)((unsigned int)zT_400)), zT_393);
    (void)zT_403;
    zT_404 = 1;
    vd_type_binding = zT_404;
    goto z_bb_48;
    z_bb_48:
    goto z_bb_43;
    z_bb_49:
    zT_409 = self->store;
    zT_410 = node.child_0;
    zT_413 = zF_FCDD1D35_astStoreNodeAt(zT_409, zT_410);
    ann = zT_413;
    zT_414 = ann.kind;
    if ((unsigned char)(zT_414 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_51; else goto z_bb_53;
    z_bb_50:
    zT_506 = 0;
    if ((unsigned char)(vd_type_binding == zT_506)) goto z_bb_63; else goto z_bb_64;
    z_bb_51:
    zT_418 = self;
    zT_419 = node.child_0;
    zT_421 = zF_54F95822_semanticAnalyzerRes(zT_418, zT_419);
    decl_type = zT_421;
    if ((unsigned char)(decl_type == (unsigned int)(1))) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    zT_471 = self->type_table;
    zT_472 = node.child_0;
    zT_475 = zF_999DCF51_resolvedTypeTableGe(zT_471, zT_472);
    rt = zT_475;
    zT_476 = rt.has_value;
    if (zT_476) goto z_bb_58; else goto z_bb_60;
    z_bb_54:
    zT_426 = self->store;
    zT_425.store = zT_426;
    zT_427 = self->registry;
    zT_425.typereg = zT_427;
    zT_428 = self->symbols;
    zT_425.symbol_reg = zT_428;
    zT_429 = self->interner;
    zT_425.interner = zT_429;
    zT_430 = self->module_id;
    zT_425.module_id = zT_430;
    zT_431 = self->diag;
    zT_432.has_value = 1;
    zT_432.value = zT_431;
    zT_425.diag = zT_432;
    zT_433 = &self->local_consts;
    zT_434.has_value = 1;
    zT_434.value = zT_433;
    zT_425.local_consts = zT_434;
    zT_435 = &self->local_types;
    zT_436.has_value = 1;
    zT_436.value = zT_435;
    zT_425.local_types = zT_436;
    zT_437 = self->source_file_id;
    zT_425.source_file_id = zT_437;
    cd_env = zT_425;
    zT_439 = &cd_env;
    zT_440 = node.child_0;
    zT_445 = zF_F2107C15_resolveTypeExprFull(zT_439, zT_440, (unsigned int)(0));
    cd_full = zT_445;
    if ((unsigned char)(cd_full == (unsigned int)(18))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_449 = "unknown type in variable declaration";
    zT_451 = 36;
    zT_450.ptr = zT_449;
    zT_450.len = zT_451;
    ut_msg = zT_450;
    zT_452 = self->diag;
    zT_455 = self->source_file_id;
    zT_456 = ann.span_start;
    zT_464 = ann.span_start;
    zT_465 = ann.span_len;
    zT_458 = ut_msg;
    zT_468 = zF_C82559AC_diagnosticCollector(zT_452, (unsigned char)(0), (unsigned short)(3000), zT_455, zT_456, (unsigned int)(zT_464 + (unsigned int)((unsigned int)zT_465)), zT_458);
    (void)zT_468;
    zT_469 = 18;
    decl_type = zT_469;
    goto z_bb_57;
    z_bb_57:
    goto z_bb_55;
    z_bb_58:
    t = rt.value;
    decl_type = t;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_52;
    z_bb_60:
    zT_480 = self->store;
    zT_479.store = zT_480;
    zT_481 = self->registry;
    zT_479.typereg = zT_481;
    zT_482 = self->symbols;
    zT_479.symbol_reg = zT_482;
    zT_483 = self->interner;
    zT_479.interner = zT_483;
    zT_484 = self->module_id;
    zT_479.module_id = zT_484;
    zT_485 = self->diag;
    zT_486.has_value = 1;
    zT_486.value = zT_485;
    zT_479.diag = zT_486;
    zT_487 = &self->local_consts;
    zT_488.has_value = 1;
    zT_488.value = zT_487;
    zT_479.local_consts = zT_488;
    zT_489 = &self->local_types;
    zT_490.has_value = 1;
    zT_490.value = zT_489;
    zT_479.local_types = zT_490;
    zT_491 = self->source_file_id;
    zT_479.source_file_id = zT_491;
    tre_env_vd = zT_479;
    zT_492 = &tre_env_vd;
    zT_493 = node.child_0;
    zT_498 = zF_F2107C15_resolveTypeExprFull(zT_492, zT_493, (unsigned int)(0));
    decl_type = zT_498;
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_501 = self->type_table;
    zT_502 = node.child_0;
    zT_503 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_501, zT_502, zT_503);
    goto z_bb_62;
    z_bb_62:
    goto z_bb_59;
    z_bb_63:
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_17;
    z_bb_65:
    zT_512 = "VRT:";
    zT_514 = 4;
    zT_513.ptr = zT_512;
    zT_513.len = zT_514;
    b1m = zT_513;
    zT_515 = b1m;
    zF_48AC7B3A_markerWrite(zT_515);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_517[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1nb[_i] = zT_517[_i];
        _i++;
    }
}
    zT_519 = node.child_0;
    zT_524 = 0;
    zT_525 = (unsigned char*)((unsigned char*)b1nb) + zT_524;
    zT_526 = (unsigned int)(10) - zT_524;
    zT_527.ptr = zT_525;
    zT_527.len = zT_526;
    zT_520 = zT_527;
    zT_528 = zF_A7504564_itoa(zT_519, zT_520);
    b1nl = zT_528;
    zT_532 = (unsigned int)(9) - (unsigned int)((unsigned int)b1nl);
    b1ns = zT_532;
    zT_537 = (unsigned char*)((unsigned char*)b1nb) + b1ns;
    zT_538 = (unsigned int)(9) - b1ns;
    zT_539.ptr = zT_537;
    zT_539.len = zT_538;
    zT_533 = zT_539;
    zF_48AC7B3A_markerWrite(zT_533);
    zT_541 = ":";
    zT_543 = 1;
    zT_542.ptr = zT_541;
    zT_542.len = zT_543;
    b1c = zT_542;
    zT_544 = b1c;
    zF_48AC7B3A_markerWrite(zT_544);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_546[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1tb[_i] = zT_546[_i];
        _i++;
    }
}
    zT_548 = decl_type;
    zT_552 = 0;
    zT_553 = (unsigned char*)((unsigned char*)b1tb) + zT_552;
    zT_554 = (unsigned int)(10) - zT_552;
    zT_555.ptr = zT_553;
    zT_555.len = zT_554;
    zT_549 = zT_555;
    zT_556 = zF_A7504564_itoa(zT_548, zT_549);
    b1tl = zT_556;
    zT_560 = (unsigned int)(9) - (unsigned int)((unsigned int)b1tl);
    b1ts = zT_560;
    zT_565 = (unsigned char*)((unsigned char*)b1tb) + b1ts;
    zT_566 = (unsigned int)(9) - b1ts;
    zT_567.ptr = zT_565;
    zT_567.len = zT_566;
    zT_561 = zT_567;
    zF_48AC7B3A_markerWrite(zT_561);
    zT_569 = "\n";
    zT_571 = 1;
    zT_570.ptr = zT_569;
    zT_570.len = zT_571;
    b1nl2 = zT_570;
    zT_572 = b1nl2;
    zF_48AC7B3A_markerWrite(zT_572);
    goto z_bb_66;
    z_bb_66:
    zT_573 = node.child_1;
    if ((unsigned char)(zT_573 == (unsigned int)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_576 = decl_type != (unsigned int)(18);
    goto z_bb_69;
    z_bb_68:
    zT_576 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_576) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_581 = node.span_start;
    uisp = zT_581;
    zT_583 = node.span_len;
    zT_585 = uisp + (unsigned int)((unsigned int)zT_583);
    uiep = zT_585;
    zT_587 = "variable must be initialized; use '= undefined' to opt out";
    zT_589 = 58;
    zT_588.ptr = zT_587;
    zT_588.len = zT_589;
    ui_msg = zT_588;
    zT_590 = self->diag;
    zT_593 = self->source_file_id;
    zT_594 = uisp;
    zT_595 = uiep;
    zT_596 = ui_msg;
    zT_603 = zF_C82559AC_diagnosticCollector(zT_590, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3014_USE_OF_UNDEFINED_VARIABLE)), zT_593, zT_594, zT_595, zT_596);
    (void)zT_603;
    goto z_bb_71;
    z_bb_71:
    zT_604 = node.child_1;
    if ((unsigned char)(zT_604 != (unsigned int)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_608 = self->store;
    zT_609 = node.child_1;
    zT_612 = zF_FCDD1D35_astStoreNodeAt(zT_608, zT_609);
    init_node = zT_612;
    zT_614 = "I:K";
    zT_616 = 3;
    zT_615.ptr = zT_614;
    zT_615.len = zT_616;
    ik_m = zT_615;
    zT_617 = ik_m;
    zT_619 = init_node.kind;
    zF_C914CB83_markerWriteInt(zT_617, (unsigned int)((unsigned int)zT_619));
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_74; else goto z_bb_75;
    z_bb_73:
    zT_930 = node.flags;
    if ((unsigned char)((unsigned char)(zT_930 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_133; else goto z_bb_134;
    z_bb_74:
    zT_625 = decl_type;
    goto z_bb_76;
    z_bb_75:
    zT_625 = 0;
    goto z_bb_76;
    z_bb_76:
    vd_exp = zT_625;
    zT_627 = self;
    zT_628 = vd_exp;
    zF_9665A229_pushExpectedType(zT_627, zT_628);
    zT_630 = self;
    zT_631 = node.child_1;
    zT_633 = zF_54F95822_semanticAnalyzerRes(zT_630, zT_631);
    it = zT_633;
    zT_634 = self;
    zF_BC478E78_popExpectedType(zT_634);
    if ((unsigned char)(decl_type == (unsigned int)(18))) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_639 = init_node.kind;
    zT_638 = zT_639 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal);
    goto z_bb_79;
    z_bb_78:
    zT_638 = 0;
    goto z_bb_79;
    z_bb_79:
    if (zT_638) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_644 = self->store;
    zT_645 = node.child_1;
    zT_648 = zF_8BA26B9E_astStoreNodePayload(zT_644, zT_645);
    name_id = zT_648;
    zT_650 = 0;
    zT_651 = (unsigned int)zT_650;
    ei = zT_651;
    goto z_bb_82;
    z_bb_81:
    if ((unsigned char)(decl_type == (unsigned int)(18))) goto z_bb_90; else goto z_bb_91;
    z_bb_82:
    zT_652 = self->registry;
    zT_653 = zT_652->types_len;
    if ((unsigned char)(ei < zT_653)) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_655 = self->registry;
    zT_656 = zT_655->types_items;
    zT_657 = zT_656[ei];
    zT_658 = zT_657.kind;
    if ((unsigned char)(zT_658 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_86; else goto z_bb_87;
    z_bb_84:
    goto z_bb_81;
    z_bb_85:
    zT_688 = 1;
    zT_690 = ei + (unsigned int)((unsigned int)zT_688);
    ei = zT_690;
    goto z_bb_82;
    z_bb_86:
    zT_663 = self->registry;
    zT_665 = name_id;
    zT_668 = zF_D2ECD176_typeRegistryErrorSe(zT_663, (unsigned int)((unsigned int)ei), zT_665);
    ord = zT_668;
    if ((unsigned char)(ord != (unsigned int)(4294967295u))) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_672 = (unsigned int)ei;
    es_type_id = zT_672;
    zT_674 = self->error_code_registry;
    zT_675 = name_id;
    zT_677 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_674, zT_675);
    reg_code = zT_677;
    zT_678 = self->enum_value_table;
    zT_679 = node.child_1;
    zT_680 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_678, zT_679, zT_680);
    zT_683 = self->type_table;
    zT_684 = node.child_1;
    zT_685 = es_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_683, zT_684, zT_685);
    it = es_type_id;
    goto z_bb_84;
    z_bb_89:
    goto z_bb_87;
    z_bb_90:
    zT_695 = init_node.kind;
    zT_694 = zT_695 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_92;
    z_bb_91:
    zT_694 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_694) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_700 = init_node.span_start;
    sp = zT_700;
    zT_702 = init_node.span_len;
    zT_704 = sp + (unsigned int)((unsigned int)zT_702);
    ep = zT_704;
    zT_706 = "unable to infer type of enum literal without context";
    zT_708 = 52;
    zT_707.ptr = zT_706;
    zT_707.len = zT_708;
    elu_msg = zT_707;
    zT_709 = self->diag;
    zT_712 = self->source_file_id;
    zT_713 = sp;
    zT_714 = ep;
    zT_715 = elu_msg;
    zT_722 = zF_C82559AC_diagnosticCollector(zT_709, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3010_CANNOT_INFER_ENUM_LITERAL_TYPE)), zT_712, zT_713, zT_714, zT_715);
    (void)zT_722;
    goto z_bb_94;
    z_bb_94:
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_726 = it != decl_type;
    goto z_bb_97;
    z_bb_96:
    zT_726 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_726) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    if ((unsigned char)(it == (unsigned int)(17))) goto z_bb_100; else goto z_bb_101;
    z_bb_99:
    if ((unsigned char)(decl_type == (unsigned int)(18))) goto z_bb_127; else goto z_bb_128;
    z_bb_100:
    zT_731 = "CS4\n";
    zT_733 = 4;
    zT_732.ptr = zT_731;
    zT_732.len = zT_733;
    cs4_m = zT_732;
    zT_734 = cs4_m;
    zF_48AC7B3A_markerWrite(zT_734);
    goto z_bb_101;
    z_bb_101:
    zT_736 = self;
    zT_737 = node.child_1;
    zT_738 = decl_type;
    zT_739 = it;
    zT_741 = zF_FFC95E09_errLitSrcType(zT_736, zT_737, zT_738, zT_739);
    it_eff = zT_741;
    zT_742 = self;
    zT_743 = node.child_1;
    zT_744 = it_eff;
    zT_745 = decl_type;
    zT_747 = zF_86AAA417_semanticAnalyzerMay(zT_742, zT_743, zT_744, zT_745);
    if (zT_747) goto z_bb_102; else goto z_bb_104;
    z_bb_102:
    goto z_bb_103;
    z_bb_103:
    goto z_bb_99;
    z_bb_104:
    zT_749 = self->registry;
    zT_750 = it_eff;
    zT_751 = decl_type;
    zT_753 = zF_713658BF_classifyCoercion(zT_749, zT_750, zT_751);
    ck = zT_753;
    zT_755 = "CCK:vr";
    zT_757 = 6;
    zT_756.ptr = zT_755;
    zT_756.len = zT_757;
    ckv_m = zT_756;
    zT_758 = ckv_m;
    zF_C914CB83_markerWriteInt(zT_758, (unsigned int)((unsigned int)ck));
    if ((unsigned char)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_765 = self->registry;
    zT_766 = it_eff;
    zT_767 = decl_type;
    zT_769 = zF_683AEB7F_typeRegistryIsAssig(zT_765, zT_766, zT_767);
    zT_764 = zT_769;
    goto z_bb_107;
    z_bb_106:
    zT_764 = 0;
    goto z_bb_107;
    z_bb_107:
    if (zT_764) goto z_bb_108; else goto z_bb_110;
    z_bb_108:
    zT_770 = self->coercion_table;
    zT_771 = node.child_1;
    zT_772 = ck;
    zT_773 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_770, zT_771, zT_772, zT_773);
    goto z_bb_109;
    z_bb_109:
    goto z_bb_103;
    z_bb_110:
    if ((unsigned char)(it != (unsigned int)(18))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_779 = self->registry;
    zT_780 = it;
    zT_781 = decl_type;
    zT_783 = zF_683AEB7F_typeRegistryIsAssig(zT_779, zT_780, zT_781);
    zT_778 = !zT_783;
    goto z_bb_113;
    z_bb_112:
    zT_778 = 0;
    goto z_bb_113;
    z_bb_113:
    if (zT_778) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_786 = node.span_start;
    sp = zT_786;
    zT_788 = node.span_len;
    zT_790 = sp + (unsigned int)((unsigned int)zT_788);
    ep = zT_790;
    zT_792 = "type mismatch in variable declaration — initialization type may not be compatible with declared type";
    zT_794 = 102;
    zT_793.ptr = zT_792;
    zT_793.len = zT_794;
    tmd_msg = zT_793;
    zT_796 = self->registry;
    zT_797 = zT_796->types_items;
    zT_798 = (unsigned int)it;
    zT_799 = zT_797[zT_798];
    zT_800 = zT_799.kind;
    sk = zT_800;
    zT_802 = self->registry;
    zT_803 = zT_802->types_items;
    zT_804 = (unsigned int)decl_type;
    zT_805 = zT_803[zT_804];
    zT_806 = zT_805.kind;
    tk = zT_806;
    zT_808 = 1;
    zT_809 = (unsigned char)zT_808;
    level = zT_809;
    zT_810 = self;
    zT_811 = it;
    zT_812 = decl_type;
    zT_813 = zF_148F8E19_semanticAnalyzerFnP(zT_810, zT_811, zT_812);
    if (zT_813) goto z_bb_116; else goto z_bb_117;
    z_bb_115:
    goto z_bb_109;
    z_bb_116:
    zT_814 = 0;
    zT_815 = (unsigned char)zT_814;
    level = zT_815;
    goto z_bb_117;
    z_bb_117:
    zT_816 = self;
    zT_817 = it;
    zT_818 = decl_type;
    zT_821 = zF_D728034A_isBShapeMismatch(zT_816, zT_817, zT_818, (unsigned char)(1));
    if (zT_821) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_822 = 0;
    zT_823 = (unsigned char)zT_822;
    level = zT_823;
    goto z_bb_119;
    z_bb_119:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_120; else goto z_bb_121;
    z_bb_120:
    zT_827 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_122;
    z_bb_121:
    zT_827 = 0;
    goto z_bb_122;
    z_bb_122:
    if (zT_827) goto z_bb_123; else goto z_bb_124;
    z_bb_123:
    zT_832 = self->registry;
    zT_833 = zT_832->eu_items;
    zT_834 = self->registry;
    zT_835 = zT_834->types_items;
    zT_836 = (unsigned int)it;
    zT_837 = zT_835[zT_836];
    zT_838 = zT_837.payload_idx;
    zT_839 = (unsigned int)zT_838;
    zT_840 = zT_833[zT_839];
    eu_src = zT_840;
    zT_842 = self->registry;
    zT_843 = zT_842->eu_items;
    zT_844 = self->registry;
    zT_845 = zT_844->types_items;
    zT_846 = (unsigned int)decl_type;
    zT_847 = zT_845[zT_846];
    zT_848 = zT_847.payload_idx;
    zT_849 = (unsigned int)zT_848;
    zT_850 = zT_843[zT_849];
    eu_tgt = zT_850;
    zT_851 = eu_src.error_set;
    zT_852 = eu_tgt.error_set;
    if ((unsigned char)(zT_851 == zT_852)) goto z_bb_125; else goto z_bb_126;
    z_bb_124:
    zT_857 = self->diag;
    zT_858 = level;
    zT_860 = self->source_file_id;
    zT_861 = sp;
    zT_862 = ep;
    zT_863 = tmd_msg;
    zT_867 = zF_C82559AC_diagnosticCollector(zT_857, zT_858, (unsigned short)(3000), zT_860, zT_861, zT_862, zT_863);
    di = zT_867;
    zT_868 = self->diag;
    zT_869 = di;
    zT_872 = sk;
    zT_873 = zF_C14453DE_typeKindSrcStr(zT_872);
    zT_870 = zT_873;
    zF_426E1F18_diagnosticCollector(zT_868, zT_869, zT_870);
    (void)self;
    zT_874 = self->diag;
    zT_875 = di;
    zT_878 = tk;
    zT_879 = zF_CC479241_typeKindTgtStr(zT_878);
    zT_876 = zT_879;
    zF_426E1F18_diagnosticCollector(zT_874, zT_875, zT_876);
    (void)self;
    goto z_bb_115;
    z_bb_125:
    zT_854 = 0;
    zT_855 = (unsigned char)zT_854;
    level = zT_855;
    goto z_bb_126;
    z_bb_126:
    goto z_bb_124;
    z_bb_127:
    decl_type = it;
    goto z_bb_128;
    z_bb_128:
    if ((unsigned char)(decl_type == (unsigned int)(1))) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    zT_886 = "VDIAG:void_var\n";
    zT_888 = 15;
    zT_887.ptr = zT_886;
    zT_887.len = zT_888;
    vdag_m = zT_887;
    zT_889 = vdag_m;
    zF_48AC7B3A_markerWrite(zT_889);
    zT_891 = "VFLOW:vdag\n";
    zT_893 = 11;
    zT_892.ptr = zT_891;
    zT_892.len = zT_893;
    vfvd_m = zT_892;
    zT_894 = vfvd_m;
    zF_48AC7B3A_markerWrite(zT_894);
    zT_896 = node.span_start;
    vsp = zT_896;
    zT_898 = node.span_len;
    zT_900 = vsp + (unsigned int)((unsigned int)zT_898);
    vep = zT_900;
    zT_902 = "cannot declare variable of type void";
    zT_904 = 36;
    zT_903.ptr = zT_902;
    zT_903.len = zT_904;
    vv_msg = zT_903;
    zT_905 = self->diag;
    zT_908 = self->source_file_id;
    zT_909 = vsp;
    zT_910 = vep;
    zT_911 = vv_msg;
    zT_916 = zF_C82559AC_diagnosticCollector(zT_905, (unsigned char)(0), (unsigned short)(3000), zT_908, zT_909, zT_910, zT_911);
    (void)zT_916;
    goto z_bb_130;
    z_bb_130:
    zT_918 = self->coercion_table;
    zT_919 = node.child_1;
    zT_922 = zF_46B66789_coercionTableGet(zT_918, zT_919);
    ct_entry = zT_922;
    zT_923 = ct_entry.has_value;
    if ((unsigned char)(!zT_923)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_925 = self->type_table;
    zT_926 = node.child_1;
    zT_927 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_925, zT_926, zT_927);
    goto z_bb_132;
    z_bb_132:
    goto z_bb_73;
    z_bb_133:
    zT_936 = node.child_1;
    zT_935 = zT_936 != (unsigned int)(0);
    goto z_bb_135;
    z_bb_134:
    zT_935 = 0;
    goto z_bb_135;
    z_bb_135:
    if (zT_935) goto z_bb_136; else goto z_bb_137;
    z_bb_136:
    zT_939 = &self->local_consts;
    zT_943 = self->store;
    zT_944 = node_idx;
    zT_946 = zF_8BA26B9E_astStoreNodePayload(zT_943, zT_944);
    zT_940 = zT_946;
    zT_941 = node_idx;
    zF_DA915531_localConstScopePush(zT_939, zT_940, zT_941);
    goto z_bb_137;
    z_bb_137:
    zT_947 = self->local_decl_count;
    zT_948 = self->local_decl_cap;
    if ((unsigned char)(zT_947 >= zT_948)) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    zT_950 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_950);
    goto z_bb_139;
    z_bb_139:
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_140; else goto z_bb_141;
    z_bb_140:
    zT_954 = self->store;
    zT_955 = node_idx;
    zT_957 = zF_8BA26B9E_astStoreNodePayload(zT_954, zT_955);
    zT_958 = self->local_decl_names;
    zT_959 = self->local_decl_count;
    zT_958[zT_959] = zT_957;
    zT_960 = self->local_decl_types;
    zT_961 = self->local_decl_count;
    zT_960[zT_961] = decl_type;
    zT_962 = node.flags;
    if ((unsigned char)((unsigned char)(zT_962 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    goto z_bb_64;
    z_bb_142:
    zT_967 = 1;
    goto z_bb_144;
    z_bb_143:
    zT_967 = 0;
    goto z_bb_144;
    z_bb_144:
    zT_970 = self->local_decl_consts;
    zT_971 = self->local_decl_count;
    zT_970[zT_971] = zT_967;
    zT_972 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_972 + (unsigned int)(1));
    zT_976 = self->module_id;
    zT_980 = self->store;
    zT_981 = node_idx;
    zT_983 = zF_8BA26B9E_astStoreNodePayload(zT_980, zT_981);
    zT_985 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_976) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_983);
    ck_1 = zT_985;
    zT_986 = self->registry;
    zT_987 = ck_1;
    zT_988 = decl_type;
    zF_5E95558D_nameCachePut(zT_986, zT_987, zT_988);
    zT_991 = "REG:cp";
    zT_993 = 6;
    zT_992.ptr = zT_991;
    zT_992.len = zT_993;
    regcp_m = zT_992;
    zT_994 = regcp_m;
    zT_996 = self->store;
    zT_997 = node_idx;
    zT_999 = zF_8BA26B9E_astStoreNodePayload(zT_996, zT_997);
    zT_995 = zT_999;
    zF_C914CB83_markerWriteInt(zT_994, zT_995);
    zT_1001 = "REG:ct";
    zT_1003 = 6;
    zT_1002.ptr = zT_1001;
    zT_1002.len = zT_1003;
    regct_m = zT_1002;
    zT_1004 = regct_m;
    zT_1005 = decl_type;
    zF_C914CB83_markerWriteInt(zT_1004, zT_1005);
    goto z_bb_141;
    z_bb_145:
    zT_1011 = self->local_decl_count;
    zT_1012 = (unsigned int)zT_1011;
    if_scope_saved = zT_1012;
    zT_1013 = self;
    zT_1014 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_1013, zT_1014);
    zT_1015 = self;
    zF_7AB741D8_semanticAnalyzerStm(zT_1015, (unsigned int)((unsigned int)(2147483648u) | if_scope_saved));
    zT_1019 = node.child_2;
    if ((unsigned char)(zT_1019 != (unsigned int)(0))) goto z_bb_148; else goto z_bb_149;
    z_bb_146:
    goto z_bb_17;
    z_bb_147:
    zT_1031 = node.kind;
    if ((unsigned char)(zT_1031 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_152; else goto z_bb_154;
    z_bb_148:
    zT_1022 = self;
    zT_1023 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_1022, zT_1023);
    goto z_bb_149;
    z_bb_149:
    zT_1025 = node.child_1;
    if ((unsigned char)(zT_1025 != (unsigned int)(0))) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    zT_1028 = self;
    zT_1029 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1028, zT_1029);
    goto z_bb_151;
    z_bb_151:
    goto z_bb_146;
    z_bb_152:
    zT_1036 = self->local_decl_count;
    zT_1037 = (unsigned int)zT_1036;
    w_scope_saved = zT_1037;
    zT_1038 = self;
    zT_1039 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_1038, zT_1039);
    zT_1040 = self;
    zF_7AB741D8_semanticAnalyzerStm(zT_1040, (unsigned int)((unsigned int)(2147483648u) | w_scope_saved));
    zT_1044 = node.child_1;
    if ((unsigned char)(zT_1044 != (unsigned int)(0))) goto z_bb_155; else goto z_bb_156;
    z_bb_153:
    goto z_bb_146;
    z_bb_154:
    zT_1050 = node.kind;
    if ((unsigned char)(zT_1050 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_157; else goto z_bb_159;
    z_bb_155:
    zT_1047 = self;
    zT_1048 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1047, zT_1048);
    goto z_bb_156;
    z_bb_156:
    goto z_bb_153;
    z_bb_157:
    zT_1055 = self->local_decl_count;
    zT_1056 = (unsigned int)zT_1055;
    for_scope_saved = zT_1056;
    zT_1057 = self;
    zT_1058 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_1057, zT_1058);
    zT_1059 = self;
    zF_7AB741D8_semanticAnalyzerStm(zT_1059, (unsigned int)((unsigned int)(2147483648u) | for_scope_saved));
    zT_1063 = node.child_1;
    if ((unsigned char)(zT_1063 != (unsigned int)(0))) goto z_bb_160; else goto z_bb_161;
    z_bb_158:
    goto z_bb_153;
    z_bb_159:
    zT_1069 = node.kind;
    if ((unsigned char)(zT_1069 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_162; else goto z_bb_164;
    z_bb_160:
    zT_1066 = self;
    zT_1067 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1066, zT_1067);
    goto z_bb_161;
    z_bb_161:
    goto z_bb_158;
    z_bb_162:
    zT_1073 = self;
    zT_1074 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_1073, zT_1074);
    goto z_bb_163;
    z_bb_163:
    goto z_bb_158;
    z_bb_164:
    zT_1075 = node.kind;
    if ((unsigned char)(zT_1075 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_166; else goto z_bb_165;
    z_bb_165:
    zT_1080 = node.kind;
    zT_1079 = zT_1080 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_167;
    z_bb_166:
    zT_1079 = 1;
    goto z_bb_167;
    z_bb_167:
    if (zT_1079) goto z_bb_169; else goto z_bb_168;
    z_bb_168:
    zT_1085 = node.kind;
    zT_1084 = zT_1085 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_170;
    z_bb_169:
    zT_1084 = 1;
    goto z_bb_170;
    z_bb_170:
    if (zT_1084) goto z_bb_172; else goto z_bb_171;
    z_bb_171:
    zT_1090 = node.kind;
    zT_1089 = zT_1090 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_173;
    z_bb_172:
    zT_1089 = 1;
    goto z_bb_173;
    z_bb_173:
    if (zT_1089) goto z_bb_175; else goto z_bb_174;
    z_bb_174:
    zT_1095 = node.kind;
    zT_1094 = zT_1095 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_176;
    z_bb_175:
    zT_1094 = 1;
    goto z_bb_176;
    z_bb_176:
    if (zT_1094) goto z_bb_178; else goto z_bb_177;
    z_bb_177:
    zT_1100 = node.kind;
    zT_1099 = zT_1100 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_179;
    z_bb_178:
    zT_1099 = 1;
    goto z_bb_179;
    z_bb_179:
    if (zT_1099) goto z_bb_181; else goto z_bb_180;
    z_bb_180:
    zT_1105 = node.kind;
    zT_1104 = zT_1105 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_182;
    z_bb_181:
    zT_1104 = 1;
    goto z_bb_182;
    z_bb_182:
    if (zT_1104) goto z_bb_184; else goto z_bb_183;
    z_bb_183:
    zT_1110 = node.kind;
    zT_1109 = zT_1110 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_185;
    z_bb_184:
    zT_1109 = 1;
    goto z_bb_185;
    z_bb_185:
    if (zT_1109) goto z_bb_187; else goto z_bb_186;
    z_bb_186:
    zT_1115 = node.kind;
    zT_1114 = zT_1115 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_188;
    z_bb_187:
    zT_1114 = 1;
    goto z_bb_188;
    z_bb_188:
    if (zT_1114) goto z_bb_190; else goto z_bb_189;
    z_bb_189:
    zT_1120 = node.kind;
    zT_1119 = zT_1120 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_191;
    z_bb_190:
    zT_1119 = 1;
    goto z_bb_191;
    z_bb_191:
    if (zT_1119) goto z_bb_193; else goto z_bb_192;
    z_bb_192:
    zT_1125 = node.kind;
    zT_1124 = zT_1125 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_194;
    z_bb_193:
    zT_1124 = 1;
    goto z_bb_194;
    z_bb_194:
    if (zT_1124) goto z_bb_196; else goto z_bb_195;
    z_bb_195:
    zT_1130 = node.kind;
    zT_1129 = zT_1130 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_197;
    z_bb_196:
    zT_1129 = 1;
    goto z_bb_197;
    z_bb_197:
    if (zT_1129) goto z_bb_199; else goto z_bb_198;
    z_bb_198:
    zT_1135 = node.kind;
    zT_1134 = zT_1135 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_200;
    z_bb_199:
    zT_1134 = 1;
    goto z_bb_200;
    z_bb_200:
    if (zT_1134) goto z_bb_202; else goto z_bb_201;
    z_bb_201:
    zT_1140 = node.kind;
    zT_1139 = zT_1140 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_203;
    z_bb_202:
    zT_1139 = 1;
    goto z_bb_203;
    z_bb_203:
    if (zT_1139) goto z_bb_205; else goto z_bb_204;
    z_bb_204:
    zT_1145 = node.kind;
    zT_1144 = zT_1145 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_206;
    z_bb_205:
    zT_1144 = 1;
    goto z_bb_206;
    z_bb_206:
    if (zT_1144) goto z_bb_208; else goto z_bb_207;
    z_bb_207:
    zT_1150 = node.kind;
    zT_1149 = zT_1150 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_209;
    z_bb_208:
    zT_1149 = 1;
    goto z_bb_209;
    z_bb_209:
    if (zT_1149) goto z_bb_211; else goto z_bb_210;
    z_bb_210:
    zT_1155 = node.kind;
    zT_1154 = zT_1155 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_212;
    z_bb_211:
    zT_1154 = 1;
    goto z_bb_212;
    z_bb_212:
    if (zT_1154) goto z_bb_214; else goto z_bb_213;
    z_bb_213:
    zT_1160 = node.kind;
    zT_1159 = zT_1160 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_215;
    z_bb_214:
    zT_1159 = 1;
    goto z_bb_215;
    z_bb_215:
    if (zT_1159) goto z_bb_216; else goto z_bb_218;
    z_bb_216:
    zT_1164 = self;
    zT_1165 = node_idx;
    zT_1166 = zF_54F95822_semanticAnalyzerRes(zT_1164, zT_1165);
    (void)zT_1166;
    goto z_bb_217;
    z_bb_217:
    goto z_bb_163;
    z_bb_218:
    zT_1167 = node.kind;
    if ((unsigned char)(zT_1167 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_219; else goto z_bb_221;
    z_bb_219:
    zT_1171 = node.child_0;
    if ((unsigned char)(zT_1171 != (unsigned int)(0))) goto z_bb_222; else goto z_bb_223;
    z_bb_220:
    goto z_bb_217;
    z_bb_221:
    zT_1177 = node.kind;
    if ((unsigned char)(zT_1177 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_225; else goto z_bb_224;
    z_bb_222:
    zT_1174 = self;
    zT_1175 = node.child_0;
    zF_7AB741D8_semanticAnalyzerStm(zT_1174, zT_1175);
    goto z_bb_223;
    z_bb_223:
    goto z_bb_220;
    z_bb_224:
    zT_1182 = node.kind;
    zT_1181 = zT_1182 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_226;
    z_bb_225:
    zT_1181 = 1;
    goto z_bb_226;
    z_bb_226:
    if (zT_1181) goto z_bb_227; else goto z_bb_229;
    z_bb_227:
    zT_1186 = node.child_0;
    if ((unsigned char)(zT_1186 != (unsigned int)(0))) goto z_bb_230; else goto z_bb_231;
    z_bb_228:
    goto z_bb_220;
    z_bb_229:
    zT_1207 = node.kind;
    if ((unsigned char)(zT_1207 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_232; else goto z_bb_234;
    z_bb_230:
    zT_1190 = self->defer_inner_loops;
    dc_saved_loops = zT_1190;
    zT_1192 = self->defer_label_len;
    dc_saved_len = zT_1192;
    self->defer_inner_loops = (unsigned int)(0);
    self->defer_label_len = (unsigned int)(0);
    zT_1195 = self;
    zT_1196 = node.child_0;
    zF_9E06A44F_semanticAnalyzerChe(zT_1195, zT_1196);
    self->defer_inner_loops = dc_saved_loops;
    self->defer_label_len = dc_saved_len;
    zT_1198 = self->defer_depth;
    self->defer_depth = (unsigned int)(zT_1198 + (unsigned int)(1));
    zT_1201 = self;
    zT_1202 = node.child_0;
    zF_10A0DC35_semanticAnalyzerRes(zT_1201, zT_1202);
    zT_1204 = self->defer_depth;
    self->defer_depth = (unsigned int)(zT_1204 - (unsigned int)(1));
    goto z_bb_231;
    z_bb_231:
    goto z_bb_228;
    z_bb_232:
    goto z_bb_233;
    z_bb_233:
    goto z_bb_228;
    z_bb_234:
    zT_1211 = node.kind;
    if ((unsigned char)(zT_1211 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt))) goto z_bb_235; else goto z_bb_237;
    z_bb_235:
    goto z_bb_236;
    z_bb_236:
    goto z_bb_233;
    z_bb_237:
    zT_1216 = "ELS:n";
    zT_1218 = 5;
    zT_1217.ptr = zT_1216;
    zT_1217.len = zT_1218;
    els_nm = zT_1217;
    zT_1219 = els_nm;
    zT_1220 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1219, zT_1220);
    zT_1222 = "ELS:k";
    zT_1224 = 5;
    zT_1223.ptr = zT_1222;
    zT_1223.len = zT_1224;
    els_km = zT_1223;
    zT_1225 = els_km;
    zT_1227 = node.kind;
    zF_C914CB83_markerWriteInt(zT_1225, (unsigned int)((unsigned int)zT_1227));
    zT_1229 = node.child_0;
    if ((unsigned char)(zT_1229 != (unsigned int)(0))) goto z_bb_238; else goto z_bb_239;
    z_bb_238:
    zT_1233 = "ELS:c";
    zT_1235 = 5;
    zT_1234.ptr = zT_1233;
    zT_1234.len = zT_1235;
    els_c0m = zT_1234;
    zT_1236 = els_c0m;
    zT_1237 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_1236, zT_1237);
    goto z_bb_239;
    z_bb_239:
    zT_1240 = self;
    zT_1241 = node_idx;
    zT_1242 = zF_54F95822_semanticAnalyzerRes(zT_1240, zT_1241);
    els_r = zT_1242;
    if ((unsigned char)(els_r != (unsigned int)(0))) goto z_bb_240; else goto z_bb_241;
    z_bb_240:
    zT_1247 = self->registry;
    zT_1248 = zT_1247->types_len;
    zT_1245 = (unsigned int)((unsigned int)els_r) < zT_1248;
    goto z_bb_242;
    z_bb_241:
    zT_1245 = 0;
    goto z_bb_242;
    z_bb_242:
    if (zT_1245) goto z_bb_243; else goto z_bb_244;
    z_bb_243:
    zT_1251 = self->registry;
    zT_1252 = zT_1251->types_items;
    zT_1253 = (unsigned int)els_r;
    zT_1254 = zT_1252[zT_1253];
    zT_1255 = zT_1254.kind;
    zT_1250 = zT_1255 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_245;
    z_bb_244:
    zT_1250 = 0;
    goto z_bb_245;
    z_bb_245:
    if (zT_1250) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    zT_1260 = node.span_start;
    eisp = zT_1260;
    zT_1262 = node.span_len;
    zT_1264 = eisp + (unsigned int)((unsigned int)zT_1262);
    eiep = zT_1264;
    zT_1266 = "error union result is ignored; use 'try', 'catch', or assign the result";
    zT_1268 = 71;
    zT_1267.ptr = zT_1266;
    zT_1267.len = zT_1268;
    ei_msg = zT_1267;
    zT_1269 = self->diag;
    zT_1272 = self->source_file_id;
    zT_1273 = eisp;
    zT_1274 = eiep;
    zT_1275 = ei_msg;
    zT_1282 = zF_C82559AC_diagnosticCollector(zT_1269, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3015_ERROR_IGNORED)), zT_1272, zT_1273, zT_1274, zT_1275);
    (void)zT_1282;
    goto z_bb_247;
    z_bb_247:
    goto z_bb_236;
    z_bb_248:
    zT_1287 = self->store;
    zT_1288 = node.child_0;
    zT_1291 = zF_FCDD1D35_astStoreNodeAt(zT_1287, zT_1288);
    nc = zT_1291;
    zT_1292 = nc.kind;
    if ((unsigned char)(zT_1292 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_250; else goto z_bb_251;
    z_bb_249:
    zT_1296 = node.child_1;
    if ((unsigned char)(zT_1296 != (unsigned int)(0))) goto z_bb_252; else goto z_bb_253;
    z_bb_250:
    goto z_bb_4;
    z_bb_251:
    goto z_bb_249;
    z_bb_252:
    zT_1300 = self->store;
    zT_1301 = node.child_1;
    zT_1304 = zF_FCDD1D35_astStoreNodeAt(zT_1300, zT_1301);
    nc = zT_1304;
    zT_1305 = nc.kind;
    if ((unsigned char)(zT_1305 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_254; else goto z_bb_255;
    z_bb_253:
    goto z_bb_4;
    z_bb_254:
    goto z_bb_4;
    z_bb_255:
    goto z_bb_253;
}

/* semaTraceStep */
unsigned int zF_DE5079F2_semaTraceStep(zT_38C12417_SemanticAnalyzer* self, unsigned int* cur_name, unsigned char* done) {
    zT_3D7259E2_SymbolRegistry* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_567DA1C3_Opt_868 zT_10 = {0};
    unsigned char zT_11;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    zT_8143F551_AstKind zT_24;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    zT_22A7C88B_AstNode zT_57 = {0};
    zT_8143F551_AstKind zT_58;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    unsigned int zT_69 = 0;
    zT_567DA1C3_Opt_868 ss;
    zT_3A105EF1_Symbol* s;
    zT_22A7C88B_AstNode dn;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode c0;
    unsigned int nn;
    zT_4 = self->symbols;
    zT_5 = self->module_id;
    zT_6 = *cur_name;
    zT_10 = zF_A398987E_symbolRegistryQuali(zT_4, zT_5, zT_6);
    ss = zT_10;
    zT_11 = ss.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s = ss.value;
    zT_13 = s->decl_node;
    if ((unsigned char)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_3:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_4:
    zT_19 = self->store;
    zT_20 = s->decl_node;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    dn = zT_23;
    zT_24 = dn.kind;
    if ((unsigned char)(zT_24 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_6:
    zT_30 = dn.child_1;
    if ((unsigned char)(zT_30 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_8:
    zT_36 = self->store;
    zT_37 = dn.child_1;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    init = zT_40;
    zT_41 = init.kind;
    if ((unsigned char)(zT_41 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_10:
    zT_47 = init.child_0;
    if ((unsigned char)(zT_47 == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_12:
    zT_53 = self->store;
    zT_54 = init.child_0;
    zT_57 = zF_FCDD1D35_astStoreNodeAt(zT_53, zT_54);
    c0 = zT_57;
    zT_58 = c0.kind;
    if ((unsigned char)(zT_58 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_14:
    zT_65 = self->store;
    zT_66 = init.child_0;
    zT_69 = zF_53458827_astStoreIdentifier(zT_65, zT_66);
    nn = zT_69;
    *cur_name = nn;
    return nn;
}

/* semanticAnalyzerResolveIndexAccess */
unsigned int zF_1926BC05_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    unsigned int zT_14;
    zT_38C12417_SemanticAnalyzer* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    zT_38C12417_SemanticAnalyzer* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_28 = {0};
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8143F551_AstKind zT_35;
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_46 = 0;
    unsigned char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned char zT_62;
    zT_38C12417_SemanticAnalyzer* zT_65;
    unsigned int* zT_66;
    unsigned char* zT_67;
    unsigned int zT_70 = 0;
    unsigned int zT_72;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zT_8EED1867_ResolvedTypeTable* zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned char zT_102;
    unsigned int zT_103;
    zT_8EED1867_ResolvedTypeTable* zT_106;
    unsigned int zT_107;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_D155D06D_Type* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_D155D06D_Type zT_117;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    unsigned int zT_123 = 0;
    unsigned char* zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_33EF6BFB_TypeKind zT_132;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_666DC2E1_TuplePayload* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_666DC2E1_TuplePayload zT_141;
    zT_338B7C76_TypeRegistry* zT_143;
    unsigned int* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned char* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    unsigned char zT_155;
    zT_33EF6BFB_TypeKind zT_156;
    unsigned char zT_160;
    zT_33EF6BFB_TypeKind zT_161;
    unsigned char zT_165;
    zT_33EF6BFB_TypeKind zT_166;
    unsigned char zT_170;
    zT_33EF6BFB_TypeKind zT_171;
    unsigned char zT_175;
    zT_33EF6BFB_TypeKind zT_176;
    unsigned char zT_180;
    zT_33EF6BFB_TypeKind zT_181;
    unsigned char zT_185;
    zT_33EF6BFB_TypeKind zT_186;
    unsigned char zT_190;
    zT_33EF6BFB_TypeKind zT_191;
    unsigned char zT_195;
    zT_33EF6BFB_TypeKind zT_196;
    unsigned char zT_200;
    zT_33EF6BFB_TypeKind zT_201;
    unsigned char zT_205;
    zT_33EF6BFB_TypeKind zT_206;
    unsigned char zT_210;
    zT_33EF6BFB_TypeKind zT_211;
    unsigned char zT_215;
    zT_33EF6BFB_TypeKind zT_216;
    unsigned char zT_220;
    zT_33EF6BFB_TypeKind zT_221;
    unsigned char zT_225;
    zT_33EF6BFB_TypeKind zT_226;
    unsigned char zT_230;
    zT_33EF6BFB_TypeKind zT_231;
    unsigned char zT_235;
    zT_33EF6BFB_TypeKind zT_236;
    unsigned char zT_240;
    zT_33EF6BFB_TypeKind zT_241;
    unsigned char zT_245;
    zT_33EF6BFB_TypeKind zT_246;
    unsigned char zT_250;
    zT_33EF6BFB_TypeKind zT_251;
    unsigned char zT_255;
    zT_33EF6BFB_TypeKind zT_256;
    unsigned char zT_260;
    zT_33EF6BFB_TypeKind zT_261;
    unsigned char zT_265;
    zT_33EF6BFB_TypeKind zT_266;
    unsigned char zT_270;
    zT_33EF6BFB_TypeKind zT_271;
    unsigned char zT_275;
    zT_33EF6BFB_TypeKind zT_276;
    unsigned char zT_280;
    zT_33EF6BFB_TypeKind zT_281;
    unsigned char zT_285;
    zT_33EF6BFB_TypeKind zT_286;
    unsigned char zT_290;
    unsigned char* zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned int zT_296;
    zT_F85C5DED_DiagnosticCollector* zT_297;
    unsigned int zT_300;
    unsigned int zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned int zT_309;
    unsigned int zT_310;
    unsigned int zT_313 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_314;
    unsigned int zT_315;
    unsigned int zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixa_m;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_22A7C88B_AstNode c0_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u c0k_m;
    unsigned int c0_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ste_m;
    unsigned int src_cur_name;
    unsigned int src_depth;
    unsigned int src_name;
    unsigned char src_done;
    zT_8F083A69_Slice_zT_0B42B2F8_u ix_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_s;
    zT_D155D06D_Type bt;
    unsigned int ix_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixr_m;
    unsigned char nidx_bad;
    zT_666DC2E1_TuplePayload tp;
    unsigned int r4;
    zT_8F083A69_Slice_zT_0B42B2F8_u nidx_msg;
    unsigned int ret;
    zT_3 = "IXA:N";
    zT_5 = 5;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ixa_m = zT_4;
    zT_6 = ixa_m;
    zT_7 = node_idx;
    zF_C914CB83_markerWriteInt(zT_6, zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = self->_stub_0;
    saved = zT_14;
    zT_15 = self;
    zT_16 = node.child_1;
    zT_18 = zF_54F95822_semanticAnalyzerRes(zT_15, zT_16);
    (void)zT_18;
    zT_19 = self;
    zT_20 = node.child_0;
    zT_22 = zF_54F95822_semanticAnalyzerRes(zT_19, zT_20);
    self->_stub_0 = zT_22;
    zT_24 = self->store;
    zT_25 = node.child_0;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    c0_node = zT_28;
    zT_30 = "C0K:K";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    c0k_m = zT_31;
    zT_33 = c0k_m;
    zT_35 = c0_node.kind;
    zF_C914CB83_markerWriteInt(zT_33, (unsigned int)((unsigned int)zT_35));
    zT_37 = c0_node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_42 = self->store;
    zT_43 = node.child_0;
    zT_46 = zF_53458827_astStoreIdentifier(zT_42, zT_43);
    c0_name_id = zT_46;
    zT_48 = "STE:N";
    zT_50 = 5;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    ste_m = zT_49;
    zT_51 = ste_m;
    zT_52 = node_idx;
    zF_C914CB83_markerWriteInt(zT_51, zT_52);
    src_cur_name = c0_name_id;
    zT_55 = 0;
    src_depth = zT_55;
    zT_57 = 0;
    src_name = zT_57;
    zT_59 = 0;
    src_done = zT_59;
    goto z_bb_3;
    z_bb_2:
    zT_93 = "IX:T";
    zT_95 = 4;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    ix_m = zT_94;
    zT_96 = ix_m;
    zT_97 = self->_stub_0;
    zF_C914CB83_markerWriteInt(zT_96, zT_97);
    zT_99 = self->_stub_0;
    if ((unsigned char)(zT_99 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_12;
    z_bb_3:
    if ((unsigned char)(src_done == (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_65 = self;
    zT_66 = &src_cur_name;
    zT_67 = &src_done;
    zT_70 = zF_DE5079F2_semaTraceStep(zT_65, zT_66, zT_67);
    src_name = zT_70;
    goto z_bb_6;
    z_bb_5:
    if ((unsigned char)(src_name != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_6:
    zT_72 = src_depth + (unsigned int)(1);
    src_depth = zT_72;
    goto z_bb_3;
    z_bb_7:
    zT_62 = src_depth < (unsigned int)(3);
    goto z_bb_9;
    z_bb_8:
    zT_62 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_62) goto z_bb_4; else goto z_bb_5;
    z_bb_10:
    zT_76 = "SRC:N";
    zT_78 = 5;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    srs_n = zT_77;
    zT_79 = srs_n;
    zT_80 = node_idx;
    zF_C914CB83_markerWriteInt(zT_79, zT_80);
    zT_82 = "SRC:S";
    zT_84 = 5;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    srs_s = zT_83;
    zT_85 = srs_s;
    zT_86 = src_name;
    zF_C914CB83_markerWriteInt(zT_85, zT_86);
    zT_87 = self->type_table;
    zT_88 = node.child_0;
    zT_89 = src_name;
    zF_D976B454_resolvedSourceTable(zT_87, zT_88, zT_89);
    (void)self;
    goto z_bb_11;
    z_bb_11:
    goto z_bb_2;
    z_bb_12:
    zT_103 = self->_stub_0;
    zT_102 = zT_103 == (unsigned int)(1);
    goto z_bb_14;
    z_bb_13:
    zT_102 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_102) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    self->_stub_0 = saved;
    zT_106 = self->type_table;
    zT_107 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_106, zT_107, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_16:
    zT_113 = self->registry;
    zT_114 = zT_113->types_items;
    zT_115 = self->_stub_0;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zT_114[zT_116];
    bt = zT_117;
    zT_119 = self->registry;
    zT_120 = self->_stub_0;
    zT_123 = zF_E02A7BC0_typeRegistryIndexed(zT_119, zT_120);
    ix_elem = zT_123;
    if ((unsigned char)(ix_elem != (unsigned int)(18))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_127 = "IX:R";
    zT_129 = 4;
    zT_128.ptr = zT_127;
    zT_128.len = zT_129;
    ixr_m = zT_128;
    zT_130 = ixr_m;
    zT_131 = ix_elem;
    zF_C914CB83_markerWriteInt(zT_130, zT_131);
    self->_stub_0 = saved;
    return ix_elem;
    z_bb_18:
    zT_155 = 0;
    nidx_bad = zT_155;
    zT_156 = bt.kind;
    if ((unsigned char)(zT_156 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_19:
    zT_132 = bt.kind;
    if ((unsigned char)(zT_132 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_137 = self->registry;
    zT_138 = zT_137->tup_items;
    zT_139 = bt.payload_idx;
    zT_140 = (unsigned int)zT_139;
    zT_141 = zT_138[zT_140];
    tp = zT_141;
    zT_143 = self->registry;
    zT_144 = zT_143->xt_items;
    zT_145 = tp.elems_start;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zT_144[zT_146];
    r4 = zT_147;
    zT_149 = "IX:R";
    zT_151 = 4;
    zT_150.ptr = zT_149;
    zT_150.len = zT_151;
    ixr_m = zT_150;
    zT_152 = ixr_m;
    zT_153 = r4;
    zF_C914CB83_markerWriteInt(zT_152, zT_153);
    self->_stub_0 = saved;
    return r4;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_161 = bt.kind;
    zT_160 = zT_161 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type);
    goto z_bb_24;
    z_bb_23:
    zT_160 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_160) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_166 = bt.kind;
    zT_165 = zT_166 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_27;
    z_bb_26:
    zT_165 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_165) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_171 = bt.kind;
    zT_170 = zT_171 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_30;
    z_bb_29:
    zT_170 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_170) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_176 = bt.kind;
    zT_175 = zT_176 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_33;
    z_bb_32:
    zT_175 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_175) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_181 = bt.kind;
    zT_180 = zT_181 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_36;
    z_bb_35:
    zT_180 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_180) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_186 = bt.kind;
    zT_185 = zT_186 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_39;
    z_bb_38:
    zT_185 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_185) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_191 = bt.kind;
    zT_190 = zT_191 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_42;
    z_bb_41:
    zT_190 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_190) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_196 = bt.kind;
    zT_195 = zT_196 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_45;
    z_bb_44:
    zT_195 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_195) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_201 = bt.kind;
    zT_200 = zT_201 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_48;
    z_bb_47:
    zT_200 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_200) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_206 = bt.kind;
    zT_205 = zT_206 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_51;
    z_bb_50:
    zT_205 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_205) goto z_bb_53; else goto z_bb_52;
    z_bb_52:
    zT_211 = bt.kind;
    zT_210 = zT_211 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_54;
    z_bb_53:
    zT_210 = 1;
    goto z_bb_54;
    z_bb_54:
    if (zT_210) goto z_bb_56; else goto z_bb_55;
    z_bb_55:
    zT_216 = bt.kind;
    zT_215 = zT_216 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type);
    goto z_bb_57;
    z_bb_56:
    zT_215 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_215) goto z_bb_59; else goto z_bb_58;
    z_bb_58:
    zT_221 = bt.kind;
    zT_220 = zT_221 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_60;
    z_bb_59:
    zT_220 = 1;
    goto z_bb_60;
    z_bb_60:
    if (zT_220) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_226 = bt.kind;
    zT_225 = zT_226 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_63;
    z_bb_62:
    zT_225 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_225) goto z_bb_65; else goto z_bb_64;
    z_bb_64:
    zT_231 = bt.kind;
    zT_230 = zT_231 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_66;
    z_bb_65:
    zT_230 = 1;
    goto z_bb_66;
    z_bb_66:
    if (zT_230) goto z_bb_68; else goto z_bb_67;
    z_bb_67:
    zT_236 = bt.kind;
    zT_235 = zT_236 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_69;
    z_bb_68:
    zT_235 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_235) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_241 = bt.kind;
    zT_240 = zT_241 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_72;
    z_bb_71:
    zT_240 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_240) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_246 = bt.kind;
    zT_245 = zT_246 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_75;
    z_bb_74:
    zT_245 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_245) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_251 = bt.kind;
    zT_250 = zT_251 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_78;
    z_bb_77:
    zT_250 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_250) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_256 = bt.kind;
    zT_255 = zT_256 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_81;
    z_bb_80:
    zT_255 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_255) goto z_bb_83; else goto z_bb_82;
    z_bb_82:
    zT_261 = bt.kind;
    zT_260 = zT_261 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_84;
    z_bb_83:
    zT_260 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_260) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_266 = bt.kind;
    zT_265 = zT_266 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_87;
    z_bb_86:
    zT_265 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_265) goto z_bb_89; else goto z_bb_88;
    z_bb_88:
    zT_271 = bt.kind;
    zT_270 = zT_271 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_90;
    z_bb_89:
    zT_270 = 1;
    goto z_bb_90;
    z_bb_90:
    if (zT_270) goto z_bb_92; else goto z_bb_91;
    z_bb_91:
    zT_276 = bt.kind;
    zT_275 = zT_276 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_93;
    z_bb_92:
    zT_275 = 1;
    goto z_bb_93;
    z_bb_93:
    if (zT_275) goto z_bb_95; else goto z_bb_94;
    z_bb_94:
    zT_281 = bt.kind;
    zT_280 = zT_281 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type);
    goto z_bb_96;
    z_bb_95:
    zT_280 = 1;
    goto z_bb_96;
    z_bb_96:
    if (zT_280) goto z_bb_98; else goto z_bb_97;
    z_bb_97:
    zT_286 = bt.kind;
    zT_285 = zT_286 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_99;
    z_bb_98:
    zT_285 = 1;
    goto z_bb_99;
    z_bb_99:
    if (zT_285) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_290 = 1;
    nidx_bad = zT_290;
    goto z_bb_101;
    z_bb_101:
    if ((unsigned char)(nidx_bad != (unsigned char)(0))) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_294 = "cannot index a value of non-array, non-pointer type";
    zT_296 = 51;
    zT_295.ptr = zT_294;
    zT_295.len = zT_296;
    nidx_msg = zT_295;
    zT_297 = self->diag;
    zT_300 = self->source_file_id;
    zT_301 = node.span_start;
    zT_309 = node.span_start;
    zT_310 = node.span_len;
    zT_303 = nidx_msg;
    zT_313 = zF_C82559AC_diagnosticCollector(zT_297, (unsigned char)(0), (unsigned short)(3000), zT_300, zT_301, (unsigned int)(zT_309 + (unsigned int)((unsigned int)zT_310)), zT_303);
    (void)zT_313;
    self->_stub_0 = saved;
    zT_314 = self->type_table;
    zT_315 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_314, zT_315, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_103:
    zT_321 = self->_stub_0;
    ret = zT_321;
    self->_stub_0 = saved;
    return ret;
}

/* semanticAnalyzerResolveSliceExpr */
unsigned int zF_F902E73E_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    unsigned int zT_13;
    zT_38C12417_SemanticAnalyzer* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    unsigned int zT_20;
    zT_38C12417_SemanticAnalyzer* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    unsigned char zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_D155D06D_Type zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    unsigned char zT_45;
    zT_33EF6BFB_TypeKind zT_46;
    unsigned char zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_76 = 0;
    zT_338B7C76_TypeRegistry* zT_80;
    unsigned int zT_81;
    unsigned int zT_84 = 0;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned char zT_93;
    zT_33EF6BFB_TypeKind zT_94;
    unsigned char zT_98;
    zT_33EF6BFB_TypeKind zT_99;
    unsigned char zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    unsigned char zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    unsigned char zT_113;
    unsigned char zT_118;
    zT_338B7C76_TypeRegistry* zT_120;
    unsigned int zT_121;
    unsigned char zT_122;
    unsigned int zT_125 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_D155D06D_Type bt;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl_msg;
    unsigned int ix_elem2;
    unsigned char se_is_const;
    unsigned int ret;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    self->_stub_0 = zT_12;
    zT_13 = node.child_1;
    if ((unsigned char)(zT_13 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self;
    zT_17 = node.child_1;
    zT_19 = zF_54F95822_semanticAnalyzerRes(zT_16, zT_17);
    (void)zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_20 = node.child_2;
    if ((unsigned char)(zT_20 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_23 = self;
    zT_24 = node.child_2;
    zT_26 = zF_54F95822_semanticAnalyzerRes(zT_23, zT_24);
    (void)zT_26;
    goto z_bb_4;
    z_bb_4:
    zT_27 = self->_stub_0;
    if ((unsigned char)(zT_27 == (unsigned int)(0))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_31 = self->_stub_0;
    zT_30 = zT_31 == (unsigned int)(1);
    goto z_bb_7;
    z_bb_6:
    zT_30 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_9:
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_38 = self->_stub_0;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    bt = zT_40;
    zT_41 = bt.kind;
    if ((unsigned char)(zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_46 = bt.kind;
    zT_45 = zT_46 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_12;
    z_bb_11:
    zT_45 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_45) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_51 = bt.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_15;
    z_bb_14:
    zT_50 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_50) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_56 = bt.kind;
    zT_55 = zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_18;
    z_bb_17:
    zT_55 = 1;
    goto z_bb_18;
    z_bb_18:
    if ((unsigned char)(!zT_55)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_62 = "cannot slice base type: expected array, slice, or many-pointer";
    zT_64 = 62;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    sl_msg = zT_63;
    zT_65 = self->diag;
    zT_68 = self->source_file_id;
    zT_69 = node_idx;
    zT_70 = node_idx;
    zT_71 = sl_msg;
    zT_76 = zF_C82559AC_diagnosticCollector(zT_65, (unsigned char)(0), (unsigned short)(2000), zT_68, zT_69, zT_70, zT_71);
    (void)zT_76;
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_20:
    self->_stub_1 = (unsigned int)(1);
    zT_80 = self->registry;
    zT_81 = self->_stub_0;
    zT_84 = zF_E02A7BC0_typeRegistryIndexed(zT_80, zT_81);
    ix_elem2 = zT_84;
    if ((unsigned char)(ix_elem2 != (unsigned int)(18))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    self->_stub_1 = ix_elem2;
    goto z_bb_22;
    z_bb_22:
    zT_88 = self->_stub_1;
    if ((unsigned char)(zT_88 == (unsigned int)(1))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_87 = self->_stub_0;
    self->_stub_1 = zT_87;
    goto z_bb_22;
    z_bb_24:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_25:
    zT_93 = 0;
    se_is_const = zT_93;
    zT_94 = bt.kind;
    if ((unsigned char)(zT_94 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_99 = bt.kind;
    zT_98 = zT_99 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_28;
    z_bb_27:
    zT_98 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_98) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_104 = bt.kind;
    zT_103 = zT_104 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_31;
    z_bb_30:
    zT_103 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_103) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_109 = bt.kind;
    zT_108 = zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_34;
    z_bb_33:
    zT_108 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_108) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_113 = bt.flags;
    if ((unsigned char)((unsigned char)(zT_113 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_120 = self->registry;
    zT_121 = self->_stub_1;
    zT_122 = se_is_const;
    zT_125 = zF_8FC81A87_typeRegistryGetOrCr(zT_120, zT_121, zT_122);
    ret = zT_125;
    self->_stub_0 = saved;
    return ret;
    z_bb_37:
    zT_118 = 1;
    se_is_const = zT_118;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_36;
}

/* semanticAnalyzerResolveTupleLiteral */
unsigned int zF_227D2404_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_23;
    unsigned int zT_24;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    unsigned int zT_33 = 0;
    unsigned int zT_34 = 0;
    unsigned int zT_35;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    unsigned int zT_44;
    zT_338B7C76_TypeRegistry* zT_45;
    unsigned int zT_46;
    unsigned int zT_50 = 0;
    unsigned int saved;
    unsigned int ec_n;
    unsigned int start;
    unsigned int i;
    zT_3 = self->store;
    zT_4 = node_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_152E19CB_astStoreNodeExtraCh(zT_10, zT_11);
    zT_14 = (unsigned int)zT_13;
    ec_n = zT_14;
    if ((unsigned char)(ec_n == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_2:
    zT_19 = self->registry;
    zT_20 = zT_19->xt_len;
    zT_21 = (unsigned int)zT_20;
    start = zT_21;
    zT_23 = 0;
    zT_24 = (unsigned int)zT_23;
    i = zT_24;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < ec_n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_26 = self;
    zT_28 = self->store;
    zT_29 = node_idx;
    zT_33 = zF_B10B1BC1_astStoreNodeExtraCh(zT_28, zT_29, (unsigned int)((unsigned int)i));
    zT_27 = zT_33;
    zT_34 = zF_54F95822_semanticAnalyzerRes(zT_26, zT_27);
    self->_stub_0 = zT_34;
    zT_35 = self->_stub_0;
    if ((unsigned char)(zT_35 == (unsigned int)(1))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    self->_stub_0 = saved;
    zT_45 = self->registry;
    zT_46 = start;
    zT_50 = zF_9996320F_typeRegistryGetOrCr(zT_45, zT_46, (unsigned short)((unsigned short)ec_n));
    return zT_50;
    z_bb_6:
    zT_44 = i + (unsigned int)(1);
    i = zT_44;
    goto z_bb_3;
    z_bb_7:
    self->_stub_0 = (unsigned int)(6);
    goto z_bb_8;
    z_bb_8:
    zT_39 = self->registry;
    zT_40 = self->_stub_0;
    zF_4C03AE3D_xtAppend(zT_39, zT_40);
    goto z_bb_6;
}

/* semanticAnalyzerResolveArrayInit */
unsigned int zF_F3DAABE0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    zT_ABC1EBBE_TypeResolveEnv zT_49;
    zT_6B0A7D14_AstStore* zT_50;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_3D7259E2_SymbolRegistry* zT_52;
    zT_D3EB6303_StringInterner* zT_53;
    unsigned int zT_54;
    zT_F85C5DED_DiagnosticCollector* zT_55;
    zT_7034F045_Opt_228 zT_56;
    zT_E2DF2801_LocalConstScope* zT_57;
    zT_03B97CED_Opt_398 zT_58;
    zT_C8A278E4_LocalTypeScope* zT_59;
    zT_05CE5599_Opt_400 zT_60;
    unsigned int zT_61;
    zT_ABC1EBBE_TypeResolveEnv* zT_63;
    unsigned int zT_64;
    unsigned int zT_69 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_D155D06D_Type* zT_75;
    unsigned int zT_76;
    zT_D155D06D_Type zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_8EED1867_ResolvedTypeTable* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    zT_22A7C88B_AstNode zT_95 = {0};
    unsigned char zT_97;
    zT_8143F551_AstKind zT_98;
    unsigned char zT_102;
    unsigned int zT_103;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    zT_22A7C88B_AstNode zT_111 = {0};
    zT_8143F551_AstKind zT_112;
    zT_6B0A7D14_AstStore* zT_117;
    unsigned int zT_118;
    unsigned int zT_121 = 0;
    zT_D3EB6303_StringInterner* zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126 = {0};
    unsigned int zT_128;
    unsigned char zT_131;
    unsigned char* zT_132;
    int zT_133;
    unsigned char zT_134;
    unsigned char zT_137;
    unsigned char zT_138;
    unsigned int zT_139;
    zT_ABC1EBBE_TypeResolveEnv zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_3D7259E2_SymbolRegistry* zT_146;
    zT_D3EB6303_StringInterner* zT_147;
    unsigned int zT_148;
    zT_F85C5DED_DiagnosticCollector* zT_149;
    zT_7034F045_Opt_228 zT_150;
    zT_E2DF2801_LocalConstScope* zT_151;
    zT_03B97CED_Opt_398 zT_152;
    zT_C8A278E4_LocalTypeScope* zT_153;
    zT_05CE5599_Opt_400 zT_154;
    unsigned int zT_155;
    zT_ABC1EBBE_TypeResolveEnv* zT_157;
    unsigned int zT_158;
    unsigned int zT_163 = 0;
    zT_6B0A7D14_AstStore* zT_168;
    unsigned int zT_169;
    unsigned int zT_171 = 0;
    unsigned int zT_172;
    unsigned int zT_181;
    unsigned char zT_186;
    zT_338B7C76_TypeRegistry* zT_190;
    unsigned int zT_191;
    unsigned int zT_193 = 0;
    unsigned int zT_195;
    zT_6B0A7D14_AstStore* zT_198;
    unsigned int zT_199;
    zT_6B0A7D14_AstStore* zT_201;
    unsigned int zT_202;
    unsigned int zT_206 = 0;
    zT_22A7C88B_AstNode zT_207 = {0};
    unsigned int zT_210;
    zT_8143F551_AstKind zT_211;
    unsigned int zT_215;
    zT_8143F551_AstKind zT_216;
    unsigned int zT_220;
    zT_38C12417_SemanticAnalyzer* zT_224;
    unsigned int zT_225;
    zT_38C12417_SemanticAnalyzer* zT_226;
    unsigned int zT_227;
    zT_6B0A7D14_AstStore* zT_228;
    unsigned int zT_229;
    unsigned int zT_233 = 0;
    unsigned int zT_234 = 0;
    zT_38C12417_SemanticAnalyzer* zT_238;
    unsigned int zT_245;
    zT_338B7C76_TypeRegistry* zT_252;
    unsigned int zT_253;
    unsigned int zT_257 = 0;
    zT_338B7C76_TypeRegistry* zT_259;
    unsigned int zT_260;
    unsigned int zT_264 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    unsigned int annot_tid;
    unsigned int annot_elem_tid;
    zT_BAEE192E_Opt_10 rt;
    unsigned int ec_n;
    unsigned int t;
    zT_D155D06D_Type tt;
    zT_22A7C88B_AstNode ann_kind_node;
    zT_ABC1EBBE_TypeResolveEnv tre_env0;
    unsigned int at0;
    zT_D155D06D_Type at0ty;
    zT_22A7C88B_AstNode annot_node;
    unsigned char inferred_len;
    zT_22A7C88B_AstNode sz_node;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int et;
    unsigned int arr_elem_tid;
    unsigned int elem_expected;
    unsigned int aei;
    zT_22A7C88B_AstNode el;
    unsigned int el_tid;
    unsigned int arr_tid;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_11 = 18;
    annot_tid = zT_11;
    zT_14 = 18;
    annot_elem_tid = zT_14;
    zT_15 = node.child_0;
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->type_table;
    zT_20 = node.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_168 = self->store;
    zT_169 = node_idx;
    zT_171 = zF_152E19CB_astStoreNodeExtraCh(zT_168, zT_169);
    zT_172 = (unsigned int)zT_171;
    ec_n = zT_172;
    if ((unsigned char)(ec_n == (unsigned int)(0))) goto z_bb_36; else goto z_bb_37;
    z_bb_3:
    t = rt.value;
    zT_27 = self->registry;
    zT_28 = zT_27->types_items;
    zT_29 = (unsigned int)t;
    zT_30 = zT_28[zT_29];
    tt = zT_30;
    zT_31 = tt.kind;
    if ((unsigned char)(zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(annot_tid == (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    annot_tid = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_39 = self->store;
    zT_40 = node.child_0;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_39, zT_40);
    ann_kind_node = zT_43;
    zT_44 = ann_kind_node.kind;
    if ((unsigned char)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(annot_tid == (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_9:
    zT_50 = self->store;
    zT_49.store = zT_50;
    zT_51 = self->registry;
    zT_49.typereg = zT_51;
    zT_52 = self->symbols;
    zT_49.symbol_reg = zT_52;
    zT_53 = self->interner;
    zT_49.interner = zT_53;
    zT_54 = self->module_id;
    zT_49.module_id = zT_54;
    zT_55 = self->diag;
    zT_56.has_value = 1;
    zT_56.value = zT_55;
    zT_49.diag = zT_56;
    zT_57 = &self->local_consts;
    zT_58.has_value = 1;
    zT_58.value = zT_57;
    zT_49.local_consts = zT_58;
    zT_59 = &self->local_types;
    zT_60.has_value = 1;
    zT_60.value = zT_59;
    zT_49.local_types = zT_60;
    zT_61 = self->source_file_id;
    zT_49.source_file_id = zT_61;
    tre_env0 = zT_49;
    zT_63 = &tre_env0;
    zT_64 = node.child_0;
    zT_69 = zF_F2107C15_resolveTypeExprFull(zT_63, zT_64, (unsigned int)(0));
    at0 = zT_69;
    if ((unsigned char)(at0 != (unsigned int)(18))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_74 = self->registry;
    zT_75 = zT_74->types_items;
    zT_76 = (unsigned int)at0;
    zT_77 = zT_75[zT_76];
    at0ty = zT_77;
    zT_78 = at0ty.kind;
    if ((unsigned char)(zT_78 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    annot_tid = at0;
    zT_82 = self->type_table;
    zT_83 = node.child_0;
    zT_84 = at0;
    zF_19B4A07D_resolvedTypeTableSe(zT_82, zT_83, zT_84);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_91 = self->store;
    zT_92 = node.child_0;
    zT_95 = zF_FCDD1D35_astStoreNodeAt(zT_91, zT_92);
    annot_node = zT_95;
    zT_97 = 0;
    inferred_len = zT_97;
    zT_98 = annot_node.kind;
    if ((unsigned char)(zT_98 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_2;
    z_bb_17:
    zT_103 = annot_node.child_1;
    zT_102 = zT_103 != (unsigned int)(0);
    goto z_bb_19;
    z_bb_18:
    zT_102 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_102) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_107 = self->store;
    zT_108 = annot_node.child_1;
    zT_111 = zF_FCDD1D35_astStoreNodeAt(zT_107, zT_108);
    sz_node = zT_111;
    zT_112 = sz_node.kind;
    if ((unsigned char)(zT_112 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    if (inferred_len) goto z_bb_29; else goto z_bb_30;
    z_bb_22:
    zT_117 = self->store;
    zT_118 = annot_node.child_1;
    zT_121 = zF_53458827_astStoreIdentifier(zT_117, zT_118);
    sz_name = zT_121;
    zT_123 = self->interner;
    zT_124 = sz_name;
    zT_126 = zF_9134020D_stringInternerGet(zT_123, zT_124);
    sz_text = zT_126;
    zT_128 = sz_text.len;
    if ((unsigned char)(zT_128 == (unsigned int)(1))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_132 = sz_text.ptr;
    zT_133 = 0;
    zT_134 = zT_132[zT_133];
    zT_131 = zT_134 == (unsigned char)(95);
    goto z_bb_26;
    z_bb_25:
    zT_131 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_131) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_137 = 1;
    inferred_len = zT_137;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_139 = annot_node.child_0;
    zT_138 = zT_139 != (unsigned int)(0);
    goto z_bb_31;
    z_bb_30:
    zT_138 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_138) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_144 = self->store;
    zT_143.store = zT_144;
    zT_145 = self->registry;
    zT_143.typereg = zT_145;
    zT_146 = self->symbols;
    zT_143.symbol_reg = zT_146;
    zT_147 = self->interner;
    zT_143.interner = zT_147;
    zT_148 = self->module_id;
    zT_143.module_id = zT_148;
    zT_149 = self->diag;
    zT_150.has_value = 1;
    zT_150.value = zT_149;
    zT_143.diag = zT_150;
    zT_151 = &self->local_consts;
    zT_152.has_value = 1;
    zT_152.value = zT_151;
    zT_143.local_consts = zT_152;
    zT_153 = &self->local_types;
    zT_154.has_value = 1;
    zT_154.value = zT_153;
    zT_143.local_types = zT_154;
    zT_155 = self->source_file_id;
    zT_143.source_file_id = zT_155;
    tre_env = zT_143;
    zT_157 = &tre_env;
    zT_158 = annot_node.child_0;
    zT_163 = zF_F2107C15_resolveTypeExprFull(zT_157, zT_158, (unsigned int)(0));
    et = zT_163;
    if ((unsigned char)(et != (unsigned int)(18))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_16;
    z_bb_34:
    annot_elem_tid = et;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    self->_stub_0 = saved;
    if ((unsigned char)(annot_tid != (unsigned int)(18))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_181 = 1;
    arr_elem_tid = zT_181;
    elem_expected = annot_elem_tid;
    if ((unsigned char)(elem_expected == (unsigned int)(18))) goto z_bb_40; else goto z_bb_41;
    z_bb_38:
    return annot_tid;
    z_bb_39:
    return (unsigned int)(1);
    z_bb_40:
    zT_186 = annot_tid != (unsigned int)(18);
    goto z_bb_42;
    z_bb_41:
    zT_186 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_186) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_190 = self->registry;
    zT_191 = annot_tid;
    zT_193 = zF_E02A7BC0_typeRegistryIndexed(zT_190, zT_191);
    elem_expected = zT_193;
    goto z_bb_44;
    z_bb_44:
    zT_195 = 0;
    aei = zT_195;
    goto z_bb_45;
    z_bb_45:
    if ((unsigned char)(aei < ec_n)) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_198 = self->store;
    zT_201 = self->store;
    zT_202 = node_idx;
    zT_206 = zF_B10B1BC1_astStoreNodeExtraCh(zT_201, zT_202, (unsigned int)((unsigned int)aei));
    zT_199 = zT_206;
    zT_207 = zF_FCDD1D35_astStoreNodeAt(zT_198, zT_199);
    el = zT_207;
    zT_210 = 1;
    el_tid = zT_210;
    zT_211 = el.kind;
    if ((unsigned char)(zT_211 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_49; else goto z_bb_51;
    z_bb_47:
    if ((unsigned char)(annot_tid != (unsigned int)(18))) goto z_bb_63; else goto z_bb_64;
    z_bb_48:
    zT_245 = aei + (unsigned int)(1);
    aei = zT_245;
    goto z_bb_45;
    z_bb_49:
    zT_215 = 8;
    el_tid = zT_215;
    goto z_bb_50;
    z_bb_50:
    if ((unsigned char)(el_tid == (unsigned int)(1))) goto z_bb_59; else goto z_bb_60;
    z_bb_51:
    zT_216 = el.kind;
    if ((unsigned char)(zT_216 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_52; else goto z_bb_54;
    z_bb_52:
    zT_220 = 10;
    el_tid = zT_220;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    if ((unsigned char)(elem_expected != (unsigned int)(18))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_224 = self;
    zT_225 = elem_expected;
    zF_9665A229_pushExpectedType(zT_224, zT_225);
    goto z_bb_56;
    z_bb_56:
    zT_226 = self;
    zT_228 = self->store;
    zT_229 = node_idx;
    zT_233 = zF_B10B1BC1_astStoreNodeExtraCh(zT_228, zT_229, (unsigned int)((unsigned int)aei));
    zT_227 = zT_233;
    zT_234 = zF_54F95822_semanticAnalyzerRes(zT_226, zT_227);
    el_tid = zT_234;
    if ((unsigned char)(elem_expected != (unsigned int)(18))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_238 = self;
    zF_BC478E78_popExpectedType(zT_238);
    goto z_bb_58;
    z_bb_58:
    goto z_bb_53;
    z_bb_59:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_60:
    if ((unsigned char)(aei == (unsigned int)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    arr_elem_tid = el_tid;
    goto z_bb_62;
    z_bb_62:
    goto z_bb_48;
    z_bb_63:
    self->_stub_0 = saved;
    return annot_tid;
    z_bb_64:
    if ((unsigned char)(annot_elem_tid != (unsigned int)(18))) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    self->_stub_0 = saved;
    zT_252 = self->registry;
    zT_253 = annot_elem_tid;
    zT_257 = zF_BA693C74_typeRegistryGetOrCr(zT_252, zT_253, (unsigned int)((unsigned int)ec_n));
    return zT_257;
    z_bb_66:
    zT_259 = self->registry;
    zT_260 = arr_elem_tid;
    zT_264 = zF_BA693C74_typeRegistryGetOrCr(zT_259, zT_260, (unsigned int)((unsigned int)ec_n));
    arr_tid = zT_264;
    self->_stub_0 = saved;
    return arr_tid;
}

/* semanticAnalyzerResolveStmt */
void zF_979B6CFF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_38C12417_SemanticAnalyzer* zT_2;
    unsigned int zT_3;
    zT_2 = self;
    zT_3 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_2, zT_3);
    return;
}

/* semanticAnalyzerResolveModuleVarDecl */
unsigned int zF_CC4377FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_38C12417_SemanticAnalyzer* zT_33;
    unsigned char zT_37;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_38C12417_SemanticAnalyzer* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51 = 0;
    zT_338B7C76_TypeRegistry* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_0FB7FB13_CoercionKind zT_57 = 0;
    zT_66E7D2EF_CoercionTable* zT_61;
    unsigned int zT_62;
    zT_0FB7FB13_CoercionKind zT_63;
    unsigned int zT_64;
    zT_22A7C88B_AstNode decl;
    unsigned int decl_type;
    zT_BAEE192E_Opt_10 rt;
    unsigned int it;
    unsigned int t;
    unsigned int it_eff;
    zT_0FB7FB13_CoercionKind ck;
    zT_3 = self->store;
    zT_4 = decl_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    decl = zT_6;
    zT_7 = decl.child_1;
    if ((unsigned char)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_14 = 18;
    decl_type = zT_14;
    zT_15 = decl.child_0;
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = self->type_table;
    zT_20 = decl.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_26 = self;
    zT_27 = decl_type;
    zF_9665A229_pushExpectedType(zT_26, zT_27);
    zT_29 = self;
    zT_30 = decl.child_1;
    zT_32 = zF_54F95822_semanticAnalyzerRes(zT_29, zT_30);
    it = zT_32;
    zT_33 = self;
    zF_BC478E78_popExpectedType(zT_33);
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    t = rt.value;
    decl_type = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_37 = it != decl_type;
    goto z_bb_9;
    z_bb_8:
    zT_37 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_37) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_40 = self;
    zT_41 = decl.child_1;
    zT_42 = decl_type;
    zT_43 = it;
    zT_45 = zF_FFC95E09_errLitSrcType(zT_40, zT_41, zT_42, zT_43);
    it_eff = zT_45;
    zT_46 = self;
    zT_47 = decl.child_1;
    zT_48 = it_eff;
    zT_49 = decl_type;
    zT_51 = zF_86AAA417_semanticAnalyzerMay(zT_46, zT_47, zT_48, zT_49);
    if (zT_51) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return it;
    z_bb_12:
    return it;
    z_bb_13:
    zT_53 = self->registry;
    zT_54 = it_eff;
    zT_55 = decl_type;
    zT_57 = zF_713658BF_classifyCoercion(zT_53, zT_54, zT_55);
    ck = zT_57;
    if ((unsigned char)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_61 = self->coercion_table;
    zT_62 = decl.child_1;
    zT_63 = ck;
    zT_64 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_61, zT_62, zT_63, zT_64);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_11;
}

/* EOF */
