#include "semantic_analyzer_4DBE89E5.h"
/* semanticAnalyzerInit */
zT_38C12417_SemanticAnalyzer zF_84ADA681_semanticAnalyzerIni(zT_3E40CD83_Sand* alloc, zT_8EED1867_ResolvedTypeTable* type_table, zT_F85C5DED_DiagnosticCollector* diag, zT_338B7C76_TypeRegistry* registry, zT_3D7259E2_SymbolRegistry* symbols, zT_6B0A7D14_AstStore* store, unsigned int module_id, unsigned int source_file_id, zT_66E7D2EF_CoercionTable* coercion_tab, zT_21D3708C_U32ToU32Map* enum_val_tab, zT_21D3708C_U32ToU32Map* error_code_reg, zT_D3EB6303_StringInterner* interner, zT_21D3708C_U32ToU32Map* cal_typs, zT_21D3708C_U32ToU32Map* cp_map, zT_072B53A6_ModuleRegistry* module_reg, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_D3EB6303_StringInterner* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23 = 0;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31 = 0;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39 = 0;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_D3EB6303_StringInterner* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_D3EB6303_StringInterner* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63 = 0;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71 = 0;
    unsigned char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_D3EB6303_StringInterner* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79 = 0;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_D3EB6303_StringInterner* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_D3EB6303_StringInterner* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95 = 0;
    unsigned char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_D3EB6303_StringInterner* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_D3EB6303_StringInterner* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111 = 0;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_D3EB6303_StringInterner* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119 = 0;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_D3EB6303_StringInterner* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127 = 0;
    unsigned char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_D3EB6303_StringInterner* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135 = 0;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_D3EB6303_StringInterner* zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned int zT_143 = 0;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_D3EB6303_StringInterner* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151 = 0;
    unsigned char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_D3EB6303_StringInterner* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159 = 0;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_D3EB6303_StringInterner* zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167 = 0;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_D3EB6303_StringInterner* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175 = 0;
    unsigned char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_D3EB6303_StringInterner* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183 = 0;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_D3EB6303_StringInterner* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191 = 0;
    unsigned char* zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    zT_D3EB6303_StringInterner* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199 = 0;
    unsigned char* zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    zT_D3EB6303_StringInterner* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207 = 0;
    unsigned char* zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    zT_D3EB6303_StringInterner* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215 = 0;
    unsigned char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_D3EB6303_StringInterner* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned int zT_223 = 0;
    unsigned char* zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_D3EB6303_StringInterner* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    unsigned int zT_231 = 0;
    unsigned char* zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    zT_D3EB6303_StringInterner* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239 = 0;
    unsigned char* zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243;
    zT_D3EB6303_StringInterner* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247 = 0;
    unsigned char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_D3EB6303_StringInterner* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255 = 0;
    unsigned char* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_259;
    zT_D3EB6303_StringInterner* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263 = 0;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_D3EB6303_StringInterner* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned int zT_271 = 0;
    unsigned char* zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_D3EB6303_StringInterner* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned int zT_279 = 0;
    unsigned char* zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    zT_D3EB6303_StringInterner* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287 = 0;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_D3EB6303_StringInterner* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned int zT_295 = 0;
    zT_38C12417_SemanticAnalyzer zT_296;
    int zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    int zT_310;
    int zT_311;
    unsigned int zT_312;
    unsigned int zT_313;
    zT_3E40CD83_Sand* zT_314;
    zT_E2DF2801_LocalConstScope zT_315 = {0};
    zT_3E40CD83_Sand* zT_316;
    zT_C8A278E4_LocalTypeScope zT_317 = {0};
    int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    int zT_321;
    int zT_322;
    unsigned int zT_323;
    unsigned int zT_324;
    int zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    unsigned int zT_328;
    unsigned char zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_text;
    unsigned int und_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_text;
    unsigned int pc_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pti_s;
    unsigned int ptin_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u itp_s;
    unsigned int itp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifp_s;
    unsigned int ifp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_s;
    unsigned int pfi_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpp_s;
    unsigned int fpp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc_s;
    unsigned int vc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_s;
    unsigned int bc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_s;
    unsigned int ic_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_s;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u if_s;
    unsigned int if_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ie_s;
    unsigned int ie_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u e2i_s;
    unsigned int e2i_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u as_s;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u so_s;
    unsigned int so_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ao_s;
    unsigned int ao_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u oo_s;
    unsigned int oo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bso_s;
    unsigned int bso_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u boo_s;
    unsigned int boo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc2_s;
    unsigned int pc2_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sow_s;
    unsigned int sow_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sew_s;
    unsigned int sew_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u gc_s;
    unsigned int gc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ex_s;
    unsigned int ex_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_s;
    unsigned int pn_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm_s;
    unsigned int sm_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u iw_s;
    unsigned int iw_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_s;
    unsigned int cc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cg_s;
    unsigned int cg_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u csc_s;
    unsigned int csc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u afs_s;
    unsigned int afs_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_s;
    unsigned int ain_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ars_s;
    unsigned int ars_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_s;
    unsigned int asu_id;
    zT_17 = "_";
    zT_19 = 1;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    und_text = zT_18;
    zT_21 = interner;
    zT_22 = und_text;
    zT_23 = zF_50C274AF_stringInternerInter(zT_21, zT_22);
    und_name_id = zT_23;
    zT_25 = "@ptrCast";
    zT_27 = 8;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    pc_text = zT_26;
    zT_29 = interner;
    zT_30 = pc_text;
    zT_31 = zF_50C274AF_stringInternerInter(zT_29, zT_30);
    pc_name_id = zT_31;
    zT_33 = "@ptrToInt";
    zT_35 = 9;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    pti_s = zT_34;
    zT_37 = interner;
    zT_38 = pti_s;
    zT_39 = zF_50C274AF_stringInternerInter(zT_37, zT_38);
    ptin_id = zT_39;
    zT_41 = "@intToPtr";
    zT_43 = 9;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    itp_s = zT_42;
    zT_45 = interner;
    zT_46 = itp_s;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    itp_id = zT_47;
    zT_49 = "@intFromPtr";
    zT_51 = 11;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    ifp_s = zT_50;
    zT_53 = interner;
    zT_54 = ifp_s;
    zT_55 = zF_50C274AF_stringInternerInter(zT_53, zT_54);
    ifp_id = zT_55;
    zT_57 = "@ptrFromInt";
    zT_59 = 11;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    pfi_s = zT_58;
    zT_61 = interner;
    zT_62 = pfi_s;
    zT_63 = zF_50C274AF_stringInternerInter(zT_61, zT_62);
    pfi_id = zT_63;
    zT_65 = "@fieldParentPtr";
    zT_67 = 15;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    fpp_s = zT_66;
    zT_69 = interner;
    zT_70 = fpp_s;
    zT_71 = zF_50C274AF_stringInternerInter(zT_69, zT_70);
    fpp_id = zT_71;
    zT_73 = "@volatileCast";
    zT_75 = 13;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    vc_s = zT_74;
    zT_77 = interner;
    zT_78 = vc_s;
    zT_79 = zF_50C274AF_stringInternerInter(zT_77, zT_78);
    vc_id = zT_79;
    zT_81 = "@bitCast";
    zT_83 = 8;
    zT_82.ptr = zT_81;
    zT_82.len = zT_83;
    bc_s = zT_82;
    zT_85 = interner;
    zT_86 = bc_s;
    zT_87 = zF_50C274AF_stringInternerInter(zT_85, zT_86);
    bc_id = zT_87;
    zT_89 = "@intCast";
    zT_91 = 8;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    ic_s = zT_90;
    zT_93 = interner;
    zT_94 = ic_s;
    zT_95 = zF_50C274AF_stringInternerInter(zT_93, zT_94);
    ic_id = zT_95;
    zT_97 = "@floatCast";
    zT_99 = 10;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    fc_s = zT_98;
    zT_101 = interner;
    zT_102 = fc_s;
    zT_103 = zF_50C274AF_stringInternerInter(zT_101, zT_102);
    fc_id = zT_103;
    zT_105 = "@intToFloat";
    zT_107 = 11;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    if_s = zT_106;
    zT_109 = interner;
    zT_110 = if_s;
    zT_111 = zF_50C274AF_stringInternerInter(zT_109, zT_110);
    if_id = zT_111;
    zT_113 = "@intToEnum";
    zT_115 = 10;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    ie_s = zT_114;
    zT_117 = interner;
    zT_118 = ie_s;
    zT_119 = zF_50C274AF_stringInternerInter(zT_117, zT_118);
    ie_id = zT_119;
    zT_121 = "@enumToInt";
    zT_123 = 10;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    e2i_s = zT_122;
    zT_125 = interner;
    zT_126 = e2i_s;
    zT_127 = zF_50C274AF_stringInternerInter(zT_125, zT_126);
    e2i_id = zT_127;
    zT_129 = "@as";
    zT_131 = 3;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    as_s = zT_130;
    zT_133 = interner;
    zT_134 = as_s;
    zT_135 = zF_50C274AF_stringInternerInter(zT_133, zT_134);
    as_id = zT_135;
    zT_137 = "@sizeOf";
    zT_139 = 7;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    so_s = zT_138;
    zT_141 = interner;
    zT_142 = so_s;
    zT_143 = zF_50C274AF_stringInternerInter(zT_141, zT_142);
    so_id = zT_143;
    zT_145 = "@alignOf";
    zT_147 = 8;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    ao_s = zT_146;
    zT_149 = interner;
    zT_150 = ao_s;
    zT_151 = zF_50C274AF_stringInternerInter(zT_149, zT_150);
    ao_id = zT_151;
    zT_153 = "@offsetOf";
    zT_155 = 9;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    oo_s = zT_154;
    zT_157 = interner;
    zT_158 = oo_s;
    zT_159 = zF_50C274AF_stringInternerInter(zT_157, zT_158);
    oo_id = zT_159;
    zT_161 = "@bitSizeOf";
    zT_163 = 10;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    bso_s = zT_162;
    zT_165 = interner;
    zT_166 = bso_s;
    zT_167 = zF_50C274AF_stringInternerInter(zT_165, zT_166);
    bso_id = zT_167;
    zT_169 = "@bitOffsetOf";
    zT_171 = 12;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    boo_s = zT_170;
    zT_173 = interner;
    zT_174 = boo_s;
    zT_175 = zF_50C274AF_stringInternerInter(zT_173, zT_174);
    boo_id = zT_175;
    zT_177 = "@putChar";
    zT_179 = 8;
    zT_178.ptr = zT_177;
    zT_178.len = zT_179;
    pc2_s = zT_178;
    zT_181 = interner;
    zT_182 = pc2_s;
    zT_183 = zF_50C274AF_stringInternerInter(zT_181, zT_182);
    pc2_id = zT_183;
    zT_185 = "@stdoutWrite";
    zT_187 = 12;
    zT_186.ptr = zT_185;
    zT_186.len = zT_187;
    sow_s = zT_186;
    zT_189 = interner;
    zT_190 = sow_s;
    zT_191 = zF_50C274AF_stringInternerInter(zT_189, zT_190);
    sow_id = zT_191;
    zT_193 = "@stderrWrite";
    zT_195 = 12;
    zT_194.ptr = zT_193;
    zT_194.len = zT_195;
    sew_s = zT_194;
    zT_197 = interner;
    zT_198 = sew_s;
    zT_199 = zF_50C274AF_stringInternerInter(zT_197, zT_198);
    sew_id = zT_199;
    zT_201 = "@getChar";
    zT_203 = 8;
    zT_202.ptr = zT_201;
    zT_202.len = zT_203;
    gc_s = zT_202;
    zT_205 = interner;
    zT_206 = gc_s;
    zT_207 = zF_50C274AF_stringInternerInter(zT_205, zT_206);
    gc_id = zT_207;
    zT_209 = "@exit";
    zT_211 = 5;
    zT_210.ptr = zT_209;
    zT_210.len = zT_211;
    ex_s = zT_210;
    zT_213 = interner;
    zT_214 = ex_s;
    zT_215 = zF_50C274AF_stringInternerInter(zT_213, zT_214);
    ex_id = zT_215;
    zT_217 = "@panic";
    zT_219 = 6;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    pn_s = zT_218;
    zT_221 = interner;
    zT_222 = pn_s;
    zT_223 = zF_50C274AF_stringInternerInter(zT_221, zT_222);
    pn_id = zT_223;
    zT_225 = "@sleepMs";
    zT_227 = 8;
    zT_226.ptr = zT_225;
    zT_226.len = zT_227;
    sm_s = zT_226;
    zT_229 = interner;
    zT_230 = sm_s;
    zT_231 = zF_50C274AF_stringInternerInter(zT_229, zT_230);
    sm_id = zT_231;
    zT_233 = "@isWindows";
    zT_235 = 10;
    zT_234.ptr = zT_233;
    zT_234.len = zT_235;
    iw_s = zT_234;
    zT_237 = interner;
    zT_238 = iw_s;
    zT_239 = zF_50C274AF_stringInternerInter(zT_237, zT_238);
    iw_id = zT_239;
    zT_241 = "@consoleClear";
    zT_243 = 13;
    zT_242.ptr = zT_241;
    zT_242.len = zT_243;
    cc_s = zT_242;
    zT_245 = interner;
    zT_246 = cc_s;
    zT_247 = zF_50C274AF_stringInternerInter(zT_245, zT_246);
    cc_id = zT_247;
    zT_249 = "@consoleGotoxy";
    zT_251 = 14;
    zT_250.ptr = zT_249;
    zT_250.len = zT_251;
    cg_s = zT_250;
    zT_253 = interner;
    zT_254 = cg_s;
    zT_255 = zF_50C274AF_stringInternerInter(zT_253, zT_254);
    cg_id = zT_255;
    zT_257 = "@consoleSetColor";
    zT_259 = 16;
    zT_258.ptr = zT_257;
    zT_258.len = zT_259;
    csc_s = zT_258;
    zT_261 = interner;
    zT_262 = csc_s;
    zT_263 = zF_50C274AF_stringInternerInter(zT_261, zT_262);
    csc_id = zT_263;
    zT_265 = "@asyncFrameSize";
    zT_267 = 15;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    afs_s = zT_266;
    zT_269 = interner;
    zT_270 = afs_s;
    zT_271 = zF_50C274AF_stringInternerInter(zT_269, zT_270);
    afs_id = zT_271;
    zT_273 = "@asyncInit";
    zT_275 = 10;
    zT_274.ptr = zT_273;
    zT_274.len = zT_275;
    ain_s = zT_274;
    zT_277 = interner;
    zT_278 = ain_s;
    zT_279 = zF_50C274AF_stringInternerInter(zT_277, zT_278);
    ain_id = zT_279;
    zT_281 = "@asyncResume";
    zT_283 = 12;
    zT_282.ptr = zT_281;
    zT_282.len = zT_283;
    ars_s = zT_282;
    zT_285 = interner;
    zT_286 = ars_s;
    zT_287 = zF_50C274AF_stringInternerInter(zT_285, zT_286);
    ars_id = zT_287;
    zT_289 = "@asyncSuspend";
    zT_291 = 13;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    asu_s = zT_290;
    zT_293 = interner;
    zT_294 = asu_s;
    zT_295 = zF_50C274AF_stringInternerInter(zT_293, zT_294);
    asu_id = zT_295;
    zT_296.type_table = type_table;
    zT_296.diag = diag;
    zT_296.registry = registry;
    zT_296.symbols = symbols;
    zT_296.store = store;
    zT_296.module_id = module_id;
    zT_296.source_file_id = source_file_id;
    zT_297 = 0;
    zT_296.expected_type_stack_items = (unsigned int*)zT_297;
    zT_298 = 0;
    zT_296.expected_type_stack_len = zT_298;
    zT_299 = 0;
    zT_296.expected_type_stack_cap = zT_299;
    zT_296.expected_type_stack_alloc = alloc;
    zT_300 = 0;
    zT_296.stmt_work_items = (unsigned int*)zT_300;
    zT_301 = 0;
    zT_296.stmt_work_len = zT_301;
    zT_302 = 0;
    zT_296.stmt_work_cap = zT_302;
    zT_303 = 0;
    zT_296.current_fn_return = zT_303;
    zT_304 = 0;
    zT_296.current_fn_name = zT_304;
    zT_296.coercion_table = coercion_tab;
    zT_296.enum_value_table = enum_val_tab;
    zT_296.error_code_registry = error_code_reg;
    zT_305 = 0;
    zT_296.current_switch_cond_tu = zT_305;
    zT_306 = 0;
    zT_296.switch_depth = zT_306;
    zT_307 = 0;
    zT_296.defer_depth = zT_307;
    zT_308 = 0;
    zT_296.defer_inner_loops = zT_308;
    zT_309 = 0;
    zT_296.defer_label_len = zT_309;
    zT_310 = 0;
    zT_296.local_decl_names = (unsigned int*)zT_310;
    zT_311 = 0;
    zT_296.local_decl_types = (unsigned int*)zT_311;
    zT_312 = 0;
    zT_296.local_decl_count = zT_312;
    zT_313 = 0;
    zT_296.local_decl_cap = zT_313;
    zT_314 = alloc;
    zT_315 = zF_F5EBC2FF_localConstScopeInit(zT_314);
    zT_296.local_consts = zT_315;
    zT_316 = alloc;
    zT_317 = zF_8A85AA66_localTypeScopeInit(zT_316);
    zT_296.local_types = zT_317;
    zT_318 = 0;
    zT_296.packed_gate_items = (unsigned int*)zT_318;
    zT_319 = 0;
    zT_296.packed_gate_len = zT_319;
    zT_320 = 0;
    zT_296.packed_gate_cap = zT_320;
    zT_321 = 0;
    zT_296.packed_struct_tids = (unsigned int*)zT_321;
    zT_322 = 0;
    zT_296.packed_struct_decl_nodes = (unsigned int*)zT_322;
    zT_323 = 0;
    zT_296.packed_struct_cache_len = zT_323;
    zT_324 = 0;
    zT_296.packed_struct_cache_cap = zT_324;
    zT_325 = 0;
    zT_296.checked_struct_tids = (unsigned int*)zT_325;
    zT_326 = 0;
    zT_296.checked_struct_tids_len = zT_326;
    zT_327 = 0;
    zT_296.checked_struct_tids_cap = zT_327;
    zT_296._stub_0 = und_name_id;
    zT_328 = 0;
    zT_296._stub_1 = zT_328;
    zT_296.call_arg_types = cal_typs;
    zT_296.call_param_map = cp_map;
    zT_296.interner = interner;
    zT_296.ptrcast_name_id = pc_name_id;
    zT_296.volatilecast_name_id = vc_id;
    zT_296.ptrtoint_name_id = ptin_id;
    zT_296.inttoptr_name_id = itp_id;
    zT_296.int_from_ptr_name_id = ifp_id;
    zT_296.ptr_from_int_name_id = pfi_id;
    zT_296.field_parent_ptr_name_id = fpp_id;
    zT_296.bitcast_name_id = bc_id;
    zT_296.intcast_name_id = ic_id;
    zT_296.floatcast_name_id = fc_id;
    zT_296.inttofloat_name_id = if_id;
    zT_296.inttoenum_name_id = ie_id;
    zT_296.enumtoint_name_id = e2i_id;
    zT_296.as_name_id = as_id;
    zT_296.size_of_name_id = so_id;
    zT_296.align_of_name_id = ao_id;
    zT_296.offset_of_name_id = oo_id;
    zT_296.bit_size_of_name_id = bso_id;
    zT_296.bit_offset_of_name_id = boo_id;
    zT_296.putchar_name_id = pc2_id;
    zT_296.stdout_write_name_id = sow_id;
    zT_296.stderr_write_name_id = sew_id;
    zT_296.getchar_name_id = gc_id;
    zT_296.exit_name_id = ex_id;
    zT_296.panic_name_id = pn_id;
    zT_296.sleep_ms_name_id = sm_id;
    zT_296.is_windows_name_id = iw_id;
    zT_296.console_clear_name_id = cc_id;
    zT_296.console_gotoxy_name_id = cg_id;
    zT_296.console_set_color_name_id = csc_id;
    zT_296.async_frame_size_name_id = afs_id;
    zT_296.async_init_name_id = ain_id;
    zT_296.async_resume_name_id = ars_id;
    zT_296.async_suspend_name_id = asu_id;
    zT_329 = 1;
    zT_296.async_analysis_ready = zT_329;
    zT_296.module_reg = module_reg;
    zT_296.suspending_fns = suspending_fns;
    return zT_296;
}

/* semanticAnalyzerIsTypeValueCast */
unsigned char zF_3757023F_semanticAnalyzerIsT(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    zT_2 = self->ptrcast_name_id;
    if ((unsigned char)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_5 = self->volatilecast_name_id;
    if ((unsigned char)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_8 = self->inttoptr_name_id;
    if ((unsigned char)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_11 = self->intcast_name_id;
    if ((unsigned char)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    zT_14 = self->floatcast_name_id;
    if ((unsigned char)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_17 = self->inttofloat_name_id;
    if ((unsigned char)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_20 = self->inttoenum_name_id;
    if ((unsigned char)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    zT_23 = self->as_name_id;
    if ((unsigned char)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    return (unsigned char)(0);
}

/* semanticAnalyzerBuiltinNameEq */
unsigned char zF_2ACB4E23_semanticAnalyzerBui(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, zT_8F083A69_Slice_zT_0B42B2F8_u lit) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_20;
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned char zT_23;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    unsigned int ci;
    zT_4 = self->interner;
    zT_5 = name_id;
    zT_7 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    nm = zT_7;
    zT_9 = nm.len;
    zT_11 = lit.len;
    if ((unsigned char)(zT_9 != zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    ci = zT_16;
    goto z_bb_3;
    z_bb_3:
    zT_18 = nm.len;
    if ((unsigned char)(ci < zT_18)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = nm.ptr;
    zT_21 = zT_20[ci];
    zT_22 = lit.ptr;
    zT_23 = zT_22[ci];
    if ((unsigned char)(zT_21 != zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_27 = ci + (unsigned int)(1);
    ci = zT_27;
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    goto z_bb_6;
}

/* semanticAnalyzerIsBuiltinSupported */
unsigned char zF_CAF1FD28_semanticAnalyzerIsB(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_44;
    unsigned int zT_47;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_59;
    unsigned int zT_62;
    unsigned int zT_65;
    unsigned int zT_68;
    unsigned int zT_71;
    unsigned int zT_74;
    unsigned int zT_77;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned int zT_86;
    unsigned int zT_89;
    unsigned int zT_92;
    unsigned int zT_95;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_38C12417_SemanticAnalyzer* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned char zT_105 = 0;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_38C12417_SemanticAnalyzer* zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned char zT_114 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_38C12417_SemanticAnalyzer* zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned char zT_123 = 0;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_38C12417_SemanticAnalyzer* zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned char zT_132 = 0;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned char zT_141 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_e2i;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cvs;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cva;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cve;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_pan;
    zT_2 = self->ptrcast_name_id;
    if ((unsigned char)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_5 = self->volatilecast_name_id;
    if ((unsigned char)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_8 = self->ptrtoint_name_id;
    if ((unsigned char)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_11 = self->inttoptr_name_id;
    if ((unsigned char)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    zT_14 = self->int_from_ptr_name_id;
    if ((unsigned char)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_17 = self->ptr_from_int_name_id;
    if ((unsigned char)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_20 = self->field_parent_ptr_name_id;
    if ((unsigned char)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    zT_23 = self->bitcast_name_id;
    if ((unsigned char)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    zT_26 = self->intcast_name_id;
    if ((unsigned char)(name_id == zT_26)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    zT_29 = self->floatcast_name_id;
    if ((unsigned char)(name_id == zT_29)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    zT_32 = self->inttofloat_name_id;
    if ((unsigned char)(name_id == zT_32)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    zT_35 = self->inttoenum_name_id;
    if ((unsigned char)(name_id == zT_35)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    zT_38 = self->as_name_id;
    if ((unsigned char)(name_id == zT_38)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    zT_41 = self->size_of_name_id;
    if ((unsigned char)(name_id == zT_41)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    zT_44 = self->align_of_name_id;
    if ((unsigned char)(name_id == zT_44)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (unsigned char)(1);
    z_bb_30:
    zT_47 = self->offset_of_name_id;
    if ((unsigned char)(name_id == zT_47)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return (unsigned char)(1);
    z_bb_32:
    zT_50 = self->bit_size_of_name_id;
    if ((unsigned char)(name_id == zT_50)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (unsigned char)(1);
    z_bb_34:
    zT_53 = self->bit_offset_of_name_id;
    if ((unsigned char)(name_id == zT_53)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned char)(1);
    z_bb_36:
    zT_56 = self->putchar_name_id;
    if ((unsigned char)(name_id == zT_56)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    zT_59 = self->stdout_write_name_id;
    if ((unsigned char)(name_id == zT_59)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (unsigned char)(1);
    z_bb_40:
    zT_62 = self->stderr_write_name_id;
    if ((unsigned char)(name_id == zT_62)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (unsigned char)(1);
    z_bb_42:
    zT_65 = self->getchar_name_id;
    if ((unsigned char)(name_id == zT_65)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return (unsigned char)(1);
    z_bb_44:
    zT_68 = self->exit_name_id;
    if ((unsigned char)(name_id == zT_68)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (unsigned char)(1);
    z_bb_46:
    zT_71 = self->sleep_ms_name_id;
    if ((unsigned char)(name_id == zT_71)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned char)(1);
    z_bb_48:
    zT_74 = self->is_windows_name_id;
    if ((unsigned char)(name_id == zT_74)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return (unsigned char)(1);
    z_bb_50:
    zT_77 = self->console_clear_name_id;
    if ((unsigned char)(name_id == zT_77)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (unsigned char)(1);
    z_bb_52:
    zT_80 = self->console_gotoxy_name_id;
    if ((unsigned char)(name_id == zT_80)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return (unsigned char)(1);
    z_bb_54:
    zT_83 = self->console_set_color_name_id;
    if ((unsigned char)(name_id == zT_83)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (unsigned char)(1);
    z_bb_56:
    zT_86 = self->async_frame_size_name_id;
    if ((unsigned char)(name_id == zT_86)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned char)(1);
    z_bb_58:
    zT_89 = self->async_init_name_id;
    if ((unsigned char)(name_id == zT_89)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (unsigned char)(1);
    z_bb_60:
    zT_92 = self->async_resume_name_id;
    if ((unsigned char)(name_id == zT_92)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (unsigned char)(1);
    z_bb_62:
    zT_95 = self->async_suspend_name_id;
    if ((unsigned char)(name_id == zT_95)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (unsigned char)(1);
    z_bb_64:
    zT_99 = "@enumToInt";
    zT_101 = 10;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    l_e2i = zT_100;
    zT_102 = self;
    zT_103 = name_id;
    zT_104 = l_e2i;
    zT_105 = zF_2ACB4E23_semanticAnalyzerBui(zT_102, zT_103, zT_104);
    if (zT_105) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    return (unsigned char)(1);
    z_bb_66:
    zT_108 = "@cVaStart";
    zT_110 = 9;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    l_cvs = zT_109;
    zT_111 = self;
    zT_112 = name_id;
    zT_113 = l_cvs;
    zT_114 = zF_2ACB4E23_semanticAnalyzerBui(zT_111, zT_112, zT_113);
    if (zT_114) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    return (unsigned char)(1);
    z_bb_68:
    zT_117 = "@cVaArg";
    zT_119 = 7;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    l_cva = zT_118;
    zT_120 = self;
    zT_121 = name_id;
    zT_122 = l_cva;
    zT_123 = zF_2ACB4E23_semanticAnalyzerBui(zT_120, zT_121, zT_122);
    if (zT_123) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    return (unsigned char)(1);
    z_bb_70:
    zT_126 = "@cVaEnd";
    zT_128 = 7;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    l_cve = zT_127;
    zT_129 = self;
    zT_130 = name_id;
    zT_131 = l_cve;
    zT_132 = zF_2ACB4E23_semanticAnalyzerBui(zT_129, zT_130, zT_131);
    if (zT_132) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    return (unsigned char)(1);
    z_bb_72:
    zT_135 = "@panic";
    zT_137 = 6;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    l_pan = zT_136;
    zT_138 = self;
    zT_139 = name_id;
    zT_140 = l_pan;
    zT_141 = zF_2ACB4E23_semanticAnalyzerBui(zT_138, zT_139, zT_140);
    if (zT_141) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    return (unsigned char)(1);
    z_bb_74:
    return (unsigned char)(0);
}

/* semanticAnalyzerDiagAsyncOutsideSuspending */
void zF_D4D0798B_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char zT_2;
    zT_A4CE86B7_U64ToU32Map* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    zT_22A7C88B_AstNode zT_15 = {0};
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_F85C5DED_DiagnosticCollector* zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_38 = 0;
    zT_22A7C88B_AstNode a318_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u e318;
    zT_2 = self->async_analysis_ready;
    if ((unsigned char)(!zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = self->suspending_fns;
    zT_5 = self->module_id;
    zT_6 = self->current_fn_name;
    zT_10 = zF_7C7E43BF_asyncIsSuspending(zT_4, zT_5, zT_6);
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_12, zT_13);
    a318_node = zT_15;
    zT_17 = "@asyncSuspend used outside a suspending function";
    zT_19 = 48;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    e318 = zT_18;
    zT_20 = self->diag;
    zT_23 = self->source_file_id;
    zT_24 = a318_node.span_start;
    zT_34 = a318_node.span_start;
    zT_35 = a318_node.span_len;
    zT_26 = e318;
    zT_38 = zF_C82559AC_diagnosticCollector(zT_20, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3018_ASYNC_SUSPEND_OUTSIDE_SUSPENDING)), zT_23, zT_24, (unsigned int)(zT_34 + (unsigned int)((unsigned int)zT_35)), zT_26);
    (void)zT_38;
    return;
}

/* semanticAnalyzerDiagAsyncBuiltinInDefer */
void zF_2EC0CDC8_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_32 = 0;
    zT_22A7C88B_AstNode a319_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u e319;
    zT_2 = self->defer_depth;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    a319_node = zT_9;
    zT_11 = "@async builtin used inside a defer/errdefer body";
    zT_13 = 48;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    e319 = zT_12;
    zT_14 = self->diag;
    zT_17 = self->source_file_id;
    zT_18 = a319_node.span_start;
    zT_28 = a319_node.span_start;
    zT_29 = a319_node.span_len;
    zT_20 = e319;
    zT_32 = zF_C82559AC_diagnosticCollector(zT_14, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3019_ASYNC_BUILTIN_IN_DEFER)), zT_17, zT_18, (unsigned int)(zT_28 + (unsigned int)((unsigned int)zT_29)), zT_20);
    (void)zT_32;
    return;
}

/* semanticAnalyzerDiagDeferCtl */
void zF_398A7D41_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_A210EB18_ErrorCode code, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_25 = 0;
    zT_22A7C88B_AstNode node;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_9 = self->diag;
    zT_12 = self->source_file_id;
    zT_13 = node.span_start;
    zT_21 = node.span_start;
    zT_22 = node.span_len;
    zT_15 = msg;
    zT_25 = zF_C82559AC_diagnosticCollector(zT_9, (unsigned char)(0), (unsigned short)((unsigned short)code), zT_12, zT_13, (unsigned int)(zT_21 + (unsigned int)((unsigned int)zT_22)), zT_15);
    (void)zT_25;
    return;
}

/* semanticAnalyzerDeferBreakAllowed */
unsigned char zF_02E8B77C_semanticAnalyzerDef(zT_38C12417_SemanticAnalyzer* self, unsigned int label) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int* zT_11;
    unsigned int zT_12;
    unsigned int zT_16;
    unsigned int i;
    if ((unsigned char)(label == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->defer_inner_loops;
    return (unsigned char)(zT_4 > (unsigned int)(0));
    z_bb_2:
    zT_8 = 0;
    i = zT_8;
    goto z_bb_3;
    z_bb_3:
    zT_9 = self->defer_label_len;
    if ((unsigned char)(i < zT_9)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = self->defer_label_stack;
    zT_12 = zT_11[i];
    if ((unsigned char)(zT_12 == label)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_16 = i + (unsigned int)(1);
    i = zT_16;
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    goto z_bb_6;
}

/* semanticAnalyzerDeferContinueAllowed */
unsigned char zF_389B3480_semanticAnalyzerDef(zT_38C12417_SemanticAnalyzer* self, unsigned int label) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int* zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char zT_16;
    unsigned int zT_21;
    unsigned int i;
    if ((unsigned char)(label == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->defer_inner_loops;
    return (unsigned char)(zT_4 > (unsigned int)(0));
    z_bb_2:
    zT_8 = 0;
    i = zT_8;
    goto z_bb_3;
    z_bb_3:
    zT_9 = self->defer_label_len;
    if ((unsigned char)(i < zT_9)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = self->defer_label_stack;
    zT_12 = zT_11[i];
    if ((unsigned char)(zT_12 == label)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = i + (unsigned int)(1);
    i = zT_21;
    goto z_bb_3;
    z_bb_7:
    zT_15 = self->defer_label_isloop;
    zT_16 = zT_15[i];
    zT_14 = zT_16 != (unsigned char)(0);
    goto z_bb_9;
    z_bb_8:
    zT_14 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_14) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    goto z_bb_6;
}

/* semanticAnalyzerCheckDeferChildren */
void zF_0D8393D0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    unsigned char zT_9 = 0;
    unsigned char zT_10;
    zT_8143F551_AstKind zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    int zT_21;
    unsigned int zT_22;
    zT_38C12417_SemanticAnalyzer* zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_30 = 0;
    int zT_31;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_37;
    zT_8143F551_AstKind zT_38;
    unsigned char zT_42 = 0;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned char zT_49;
    zT_8143F551_AstKind zT_50;
    unsigned char zT_54 = 0;
    zT_38C12417_SemanticAnalyzer* zT_55;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned char zT_61;
    zT_8143F551_AstKind zT_62;
    unsigned char zT_66 = 0;
    zT_38C12417_SemanticAnalyzer* zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode node;
    unsigned int n;
    unsigned int i;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.kind;
    zT_9 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_7);
    if (zT_9) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = node.kind;
    zT_10 = zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call);
    goto z_bb_3;
    z_bb_2:
    zT_10 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = self->store;
    zT_17 = node_idx;
    zT_19 = zF_152E19CB_astStoreNodeExtraCh(zT_16, zT_17);
    n = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    i = zT_22;
    goto z_bb_6;
    z_bb_5:
    zT_34 = node.child_2;
    if ((unsigned char)(zT_34 != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_6:
    if ((unsigned char)(i < n)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = self;
    zT_26 = self->store;
    zT_27 = node_idx;
    zT_28 = i;
    zT_30 = zF_B10B1BC1_astStoreNodeExtraCh(zT_26, zT_27, zT_28);
    zT_25 = zT_30;
    zF_9E06A44F_semanticAnalyzerChe(zT_24, zT_25);
    goto z_bb_9;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_31 = 1;
    zT_33 = i + (unsigned int)((unsigned int)zT_31);
    i = zT_33;
    goto z_bb_6;
    z_bb_10:
    zT_38 = node.kind;
    zT_42 = zF_C395F6FD_nodeChildIsNode(zT_38, (unsigned char)(2));
    zT_37 = zT_42;
    goto z_bb_12;
    z_bb_11:
    zT_37 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_37) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_43 = self;
    zT_44 = node.child_2;
    zF_9E06A44F_semanticAnalyzerChe(zT_43, zT_44);
    goto z_bb_14;
    z_bb_14:
    zT_46 = node.child_1;
    if ((unsigned char)(zT_46 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_50 = node.kind;
    zT_54 = zF_C395F6FD_nodeChildIsNode(zT_50, (unsigned char)(1));
    zT_49 = zT_54;
    goto z_bb_17;
    z_bb_16:
    zT_49 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_49) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_55 = self;
    zT_56 = node.child_1;
    zF_9E06A44F_semanticAnalyzerChe(zT_55, zT_56);
    goto z_bb_19;
    z_bb_19:
    zT_58 = node.child_0;
    if ((unsigned char)(zT_58 != (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_62 = node.kind;
    zT_66 = zF_C395F6FD_nodeChildIsNode(zT_62, (unsigned char)(0));
    zT_61 = zT_66;
    goto z_bb_22;
    z_bb_21:
    zT_61 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_61) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_67 = self;
    zT_68 = node.child_0;
    zF_9E06A44F_semanticAnalyzerChe(zT_67, zT_68);
    goto z_bb_24;
    z_bb_24:
    return;
}

/* semanticAnalyzerCheckDeferBody */
void zF_9E06A44F_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned char zT_17;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    zT_38C12417_SemanticAnalyzer* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    unsigned int zT_54 = 0;
    zT_38C12417_SemanticAnalyzer* zT_55;
    unsigned int zT_56;
    unsigned char zT_57 = 0;
    unsigned char* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    zT_38C12417_SemanticAnalyzer* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_6B0A7D14_AstStore* zT_73;
    unsigned int zT_74;
    unsigned int zT_76 = 0;
    zT_38C12417_SemanticAnalyzer* zT_77;
    unsigned int zT_78;
    unsigned char zT_79 = 0;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_38C12417_SemanticAnalyzer* zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned char zT_94;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_38C12417_SemanticAnalyzer* zT_103;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_109;
    unsigned int zT_110;
    unsigned int zT_112 = 0;
    unsigned char zT_114;
    unsigned int zT_115;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_120;
    zT_22A7C88B_AstNode zT_123 = {0};
    zT_8143F551_AstKind zT_124;
    unsigned char zT_128;
    zT_8143F551_AstKind zT_129;
    unsigned char zT_133;
    unsigned char zT_135;
    unsigned int zT_136;
    unsigned int* zT_139;
    unsigned int zT_140;
    unsigned char* zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned char zT_146;
    zT_38C12417_SemanticAnalyzer* zT_147;
    unsigned int zT_148;
    unsigned int zT_151;
    zT_38C12417_SemanticAnalyzer* zT_154;
    unsigned int zT_155;
    zT_22A7C88B_AstNode node;
    zT_8143F551_AstKind kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u m;
    unsigned int label;
    unsigned int saved_loops;
    unsigned char is_loop;
    zT_22A7C88B_AstNode inner;
    unsigned char pushed;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = node.kind;
    kind = zT_10;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_17 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_7;
    z_bb_6:
    zT_17 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_17) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_25 = "cannot return from defer expression";
    zT_27 = 35;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    m = zT_26;
    zT_28 = self;
    zT_29 = node_idx;
    zT_31 = m;
    zF_398A7D41_semanticAnalyzerDia(zT_28, zT_29, (zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3051_RETURN_INSIDE_DEFER), zT_31);
    goto z_bb_11;
    z_bb_11:
    zT_154 = self;
    zT_155 = node_idx;
    zF_0D8393D0_semanticAnalyzerChe(zT_154, zT_155);
    return;
    z_bb_12:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_13; else goto z_bb_15;
    z_bb_13:
    zT_38 = "'try' not allowed inside defer expression";
    zT_40 = 41;
    zT_39.ptr = zT_38;
    zT_39.len = zT_40;
    m = zT_39;
    zT_41 = self;
    zT_42 = node_idx;
    zT_44 = m;
    zF_398A7D41_semanticAnalyzerDia(zT_41, zT_42, (zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3054_TRY_INSIDE_DEFER), zT_44);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_51 = self->store;
    zT_52 = node_idx;
    zT_54 = zF_8BA26B9E_astStoreNodePayload(zT_51, zT_52);
    label = zT_54;
    zT_55 = self;
    zT_56 = label;
    zT_57 = zF_02E8B77C_semanticAnalyzerDef(zT_55, zT_56);
    if ((unsigned char)(!zT_57)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt))) goto z_bb_21; else goto z_bb_23;
    z_bb_19:
    zT_60 = "cannot break out of defer expression";
    zT_62 = 36;
    zT_61.ptr = zT_60;
    zT_61.len = zT_62;
    m = zT_61;
    zT_63 = self;
    zT_64 = node_idx;
    zT_66 = m;
    zF_398A7D41_semanticAnalyzerDia(zT_63, zT_64, (zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3052_BREAK_OUT_OF_DEFER), zT_66);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_73 = self->store;
    zT_74 = node_idx;
    zT_76 = zF_8BA26B9E_astStoreNodePayload(zT_73, zT_74);
    label = zT_76;
    zT_77 = self;
    zT_78 = label;
    zT_79 = zF_389B3480_semanticAnalyzerDef(zT_77, zT_78);
    if ((unsigned char)(!zT_79)) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_17;
    z_bb_23:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_27; else goto z_bb_26;
    z_bb_24:
    zT_82 = "cannot continue out of defer expression";
    zT_84 = 39;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    m = zT_83;
    zT_85 = self;
    zT_86 = node_idx;
    zT_88 = m;
    zF_398A7D41_semanticAnalyzerDia(zT_85, zT_86, (zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3053_CONTINUE_OUT_OF_DEFER), zT_88);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_94 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt);
    goto z_bb_28;
    z_bb_27:
    zT_94 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_94) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    zT_99 = self->defer_inner_loops;
    saved_loops = zT_99;
    zT_100 = self->defer_inner_loops;
    self->defer_inner_loops = (unsigned int)(zT_100 + (unsigned int)(1));
    zT_103 = self;
    zT_104 = node_idx;
    zF_0D8393D0_semanticAnalyzerChe(zT_103, zT_104);
    self->defer_inner_loops = saved_loops;
    return;
    z_bb_30:
    goto z_bb_22;
    z_bb_31:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_109 = self->store;
    zT_110 = node_idx;
    zT_112 = zF_8BA26B9E_astStoreNodePayload(zT_109, zT_110);
    label = zT_112;
    zT_114 = 0;
    is_loop = zT_114;
    zT_115 = node.child_0;
    if ((unsigned char)(zT_115 != (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_119 = self->store;
    zT_120 = node.child_0;
    zT_123 = zF_FCDD1D35_astStoreNodeAt(zT_119, zT_120);
    inner = zT_123;
    zT_124 = inner.kind;
    if ((unsigned char)(zT_124 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_37; else goto z_bb_36;
    z_bb_35:
    zT_135 = 0;
    pushed = zT_135;
    zT_136 = self->defer_label_len;
    if ((unsigned char)(zT_136 < (unsigned int)(16))) goto z_bb_41; else goto z_bb_42;
    z_bb_36:
    zT_129 = inner.kind;
    zT_128 = zT_129 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt);
    goto z_bb_38;
    z_bb_37:
    zT_128 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_128) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_133 = 1;
    is_loop = zT_133;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_35;
    z_bb_41:
    zT_139 = self->defer_label_stack;
    zT_140 = self->defer_label_len;
    zT_139[zT_140] = label;
    zT_141 = self->defer_label_isloop;
    zT_142 = self->defer_label_len;
    zT_141[zT_142] = is_loop;
    zT_143 = self->defer_label_len;
    self->defer_label_len = (unsigned int)(zT_143 + (unsigned int)(1));
    zT_146 = 1;
    pushed = zT_146;
    goto z_bb_42;
    z_bb_42:
    zT_147 = self;
    zT_148 = node_idx;
    zF_0D8393D0_semanticAnalyzerChe(zT_147, zT_148);
    if ((unsigned char)(pushed != (unsigned char)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_151 = self->defer_label_len;
    self->defer_label_len = (unsigned int)(zT_151 - (unsigned int)(1));
    goto z_bb_44;
    z_bb_44:
    return;
}

/* semanticAnalyzerGrowLocalDecls */
void zF_156C79D0_semanticAnalyzerGro(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_ACA03DB3_EU_632 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    zT_3E40CD83_Sand* zT_23;
    zT_ACA03DB3_EU_632 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int* zT_35;
    unsigned int* zT_37;
    unsigned int zT_38;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_52;
    unsigned int new_cap;
    unsigned char* raw_names;
    unsigned char* raw_types;
    unsigned int* ndst;
    unsigned int* tdst;
    unsigned int ci;
    zT_2 = self->local_decl_cap;
    if ((unsigned char)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->local_decl_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_names = zT_20;
    zT_23 = self->expected_type_stack_alloc;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_32 = zT_30.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_types = zT_32;
    zT_35 = (unsigned int*)raw_names;
    ndst = zT_35;
    zT_37 = (unsigned int*)raw_types;
    tdst = zT_37;
    zT_38 = self->local_decl_count;
    if ((unsigned char)(zT_38 > (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    goto z_bb_12;
    z_bb_11:
    self->local_decl_names = ndst;
    self->local_decl_types = tdst;
    self->local_decl_cap = new_cap;
    return;
    z_bb_12:
    zT_44 = self->local_decl_count;
    if ((unsigned char)(ci < zT_44)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = self->local_decl_names;
    zT_47 = zT_46[ci];
    ndst[ci] = zT_47;
    zT_48 = self->local_decl_types;
    zT_49 = zT_48[ci];
    tdst[ci] = zT_49;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_50 = 1;
    zT_52 = ci + (unsigned int)((unsigned int)zT_50);
    ci = zT_52;
    goto z_bb_12;
}

/* registerLocalDecl */
void zF_7BD72017_registerLocalDecl(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    unsigned char* zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_tm;
    zT_3 = self->local_decl_count;
    zT_4 = self->local_decl_cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_8 = "SCT:n";
    zT_10 = 5;
    zT_9.ptr = zT_8;
    zT_9.len = zT_10;
    sct_nm = zT_9;
    zT_11 = sct_nm;
    zT_12 = name_id;
    zF_C914CB83_markerWriteInt(zT_11, zT_12);
    zT_14 = "SCT:t";
    zT_16 = 5;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    sct_tm = zT_15;
    zT_17 = sct_tm;
    zT_18 = type_id;
    zF_C914CB83_markerWriteInt(zT_17, zT_18);
    zT_19 = self->local_decl_names;
    zT_20 = self->local_decl_count;
    zT_19[zT_20] = name_id;
    zT_21 = self->local_decl_types;
    zT_22 = self->local_decl_count;
    zT_21[zT_22] = type_id;
    zT_23 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_23 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCaptureType */
unsigned int zF_3E251D67_semanticAnalyzerCap(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_type) {
    zT_338B7C76_TypeRegistry* zT_6;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_0B10E8E9_OptionalPayload* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_0B10E8E9_OptionalPayload zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type capt_ty;
    if ((unsigned char)(cond_type == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_items;
    zT_8 = (unsigned int)cond_type;
    zT_9 = zT_7[zT_8];
    capt_ty = zT_9;
    zT_10 = capt_ty.kind;
    if ((unsigned char)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self->registry;
    zT_15 = zT_14->opt_items;
    zT_16 = capt_ty.payload_idx;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15[zT_17];
    zT_19 = zT_18.payload;
    return zT_19;
    z_bb_4:
    return cond_type;
}

/* semanticAnalyzerResolveIdent */
unsigned int zF_9F1ECA79_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int module_id, unsigned int name_id, unsigned int node_idx) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int* zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_79FAE712_u64 zT_63;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned int zT_70;
    zT_79FAE712_u64 zT_75;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_79FAE712_u64 zT_78;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    zT_3D7259E2_SymbolRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_5D7DACC8_Opt_861 zT_87 = {0};
    unsigned char zT_88;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_3C598AEF_SymbolKind zT_95;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_104;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char zT_113;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char zT_120;
    unsigned char* zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_133;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    unsigned char* zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    unsigned char zT_149;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned char zT_164;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    unsigned char* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_184;
    unsigned int zT_186;
    unsigned char* zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    unsigned int* zT_195;
    unsigned int zT_196;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    unsigned int* zT_204;
    unsigned int zT_205;
    unsigned int zT_207;
    unsigned int zT_209;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    unsigned int* zT_218;
    unsigned int zT_219;
    unsigned char* zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned int zT_226;
    unsigned char zT_229;
    zT_D3EB6303_StringInterner* zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    zT_6B0A7D14_AstStore* zT_239;
    unsigned int zT_240;
    zT_22A7C88B_AstNode zT_242 = {0};
    unsigned char* zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    unsigned int zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    zT_8143F551_AstKind zT_249;
    zT_8EED1867_ResolvedTypeTable* zT_252;
    unsigned int zT_253;
    zT_BAEE192E_Opt_10 zT_255 = {0};
    unsigned char zT_256;
    unsigned char* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned int zT_274;
    unsigned char* zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned int zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_283;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    int zT_289;
    unsigned char* zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned int zT_293 = 0;
    unsigned int zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    unsigned char* zT_302;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    unsigned char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u ide;
    zT_8F083A69_Slice_zT_0B42B2F8_u sem_m;
    unsigned int li;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 ncg;
    zT_79FAE712_u64 mkey;
    zT_BAEE192E_Opt_10 ncgm;
    zT_5D7DACC8_Opt_861 sym;
    unsigned int lcl_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u id1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lt_m;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u id2;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_talias;
    unsigned int ctm;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_sv;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_tm;
    unsigned int nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_ntm;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u id3;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8l_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8i_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cname;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8k_m;
    zT_BAEE192E_Opt_10 rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8nl2;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8z_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u idm;
    zT_5A26C2ED_Arr_unsigned_char_1 idnb;
    unsigned int idnl;
    unsigned int idns;
    zT_8F083A69_Slice_zT_0B42B2F8_u idc;
    zT_5 = "IDE\n";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    ide = zT_6;
    zT_8 = ide;
    zF_48AC7B3A_markerWrite(zT_8);
    if ((unsigned char)(name_id == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = "SEM:vi";
    zT_14 = 6;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    sem_m = zT_13;
    zT_15 = sem_m;
    zT_16 = module_id;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_18 = self->local_decl_count;
    li = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(li > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = li - (unsigned int)(1);
    li = zT_22;
    zT_23 = self->local_decl_names;
    zT_24 = zT_23[li];
    if ((unsigned char)(zT_24 == name_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_63 = (zT_79FAE712_u64)name_id;
    key = zT_63;
    zT_65 = self->registry;
    zT_66 = key;
    zT_68 = zF_0EB68360_nameCacheGet(zT_65, zT_66);
    ncg = zT_68;
    zT_70 = self->module_id;
    zT_75 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_70) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    mkey = zT_75;
    zT_77 = self->registry;
    zT_78 = mkey;
    zT_80 = zF_0EB68360_nameCacheGet(zT_77, zT_78);
    ncgm = zT_80;
    zT_82 = self->symbols;
    zT_83 = self->module_id;
    zT_84 = name_id;
    zT_87 = zF_A398987E_symbolRegistryQuali(zT_82, zT_83, zT_84);
    sym = zT_87;
    zT_88 = sym.has_value;
    if (zT_88) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_27 = self->local_decl_types;
    zT_28 = zT_27[li];
    lcl_t = zT_28;
    zT_30 = "D7:Yn";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    d7m = zT_31;
    zT_33 = d7m;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_35 = "D7:n";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    d7n_m = zT_36;
    zT_38 = d7n_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_41 = "D7:t";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    d7tm = zT_42;
    zT_44 = d7tm;
    zF_48AC7B3A_markerWrite(zT_44);
    zT_46 = "D7";
    zT_48 = 2;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    d7t_m = zT_47;
    zT_49 = d7t_m;
    zT_50 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_49, zT_50);
    zT_52 = "L\n";
    zT_54 = 2;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    id1 = zT_53;
    zT_55 = id1;
    zF_48AC7B3A_markerWrite(zT_55);
    zT_57 = "L:t";
    zT_59 = 3;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    lt_m = zT_58;
    zT_60 = lt_m;
    zT_61 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_60, zT_61);
    return lcl_t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    s = sym.value;
    zT_91 = "S\n";
    zT_93 = 2;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    id2 = zT_92;
    zT_94 = id2;
    zF_48AC7B3A_markerWrite(zT_94);
    zT_95 = s->kind;
    if ((unsigned char)(zT_95 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_164 = ncg.has_value;
    if (zT_164) goto z_bb_23; else goto z_bb_24;
    z_bb_11:
    zT_99 = self;
    zT_100 = s->decl_node;
    zT_101 = s->module_id;
    zF_FC6E31C6_semanticAnalyzerMay(zT_99, zT_100, zT_101);
    zT_104 = s->type_id;
    if ((unsigned char)(zT_104 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_133 = s->type_id;
    if ((unsigned char)(zT_133 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    zT_108 = "TAL\n";
    zT_110 = 4;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    rdt_talias = zT_109;
    zT_111 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_111);
    zT_112 = s->type_id;
    return zT_112;
    z_bb_14:
    zT_113 = ncgm.has_value;
    if (zT_113) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    ctm = ncgm.value;
    zT_116 = "TAL\n";
    zT_118 = 4;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    rdt_talias = zT_117;
    zT_119 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_119);
    return ctm;
    z_bb_16:
    zT_120 = ncg.has_value;
    if (zT_120) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    ct = ncg.value;
    zT_123 = "TAL\n";
    zT_125 = 4;
    zT_124.ptr = zT_123;
    zT_124.len = zT_125;
    rdt_talias = zT_124;
    zT_126 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_126);
    return ct;
    z_bb_18:
    zT_128 = "SVO\n";
    zT_130 = 4;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    rdt_sv = zT_129;
    zT_131 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_131);
    return (unsigned int)(1);
    z_bb_19:
    zT_137 = "STY:N";
    zT_139 = 5;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    rdt_nm = zT_138;
    zT_140 = rdt_nm;
    zT_141 = name_id;
    zF_C914CB83_markerWriteInt(zT_140, zT_141);
    zT_143 = "STY:T";
    zT_145 = 5;
    zT_144.ptr = zT_143;
    zT_144.len = zT_145;
    rdt_tm = zT_144;
    zT_146 = rdt_tm;
    zT_147 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_146, zT_147);
    zT_149 = ncg.has_value;
    if (zT_149) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_159 = "SVO\n";
    zT_161 = 4;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    rdt_sv = zT_160;
    zT_162 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_162);
    return (unsigned int)(1);
    z_bb_21:
    nt = ncg.value;
    zT_152 = "STY:C";
    zT_154 = 5;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    rdt_ntm = zT_153;
    zT_155 = rdt_ntm;
    zT_156 = nt;
    zF_C914CB83_markerWriteInt(zT_155, zT_156);
    goto z_bb_22;
    z_bb_22:
    zT_157 = s->type_id;
    return zT_157;
    z_bb_23:
    t = ncg.value;
    zT_167 = "C2:T";
    zT_169 = 4;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    id3 = zT_168;
    zT_170 = id3;
    zT_171 = t;
    zF_C914CB83_markerWriteInt(zT_170, zT_171);
    return t;
    z_bb_24:
    zT_173 = "D8:Nn";
    zT_175 = 5;
    zT_174.ptr = zT_173;
    zT_174.len = zT_175;
    d8n_m = zT_174;
    zT_176 = d8n_m;
    zT_177 = name_id;
    zF_C914CB83_markerWriteInt(zT_176, zT_177);
    zT_179 = "D8:C";
    zT_181 = 4;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    d8c_m = zT_180;
    zT_182 = d8c_m;
    zT_184 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_182, (unsigned int)((unsigned int)zT_184));
    zT_186 = self->local_decl_count;
    if ((unsigned char)(zT_186 > (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_190 = "D8:F";
    zT_192 = 4;
    zT_191.ptr = zT_190;
    zT_191.len = zT_192;
    d8f_m = zT_191;
    zT_193 = d8f_m;
    zT_195 = self->local_decl_names;
    zT_196 = 0;
    zT_194 = zT_195[zT_196];
    zF_C914CB83_markerWriteInt(zT_193, zT_194);
    zT_199 = "D8:L";
    zT_201 = 4;
    zT_200.ptr = zT_199;
    zT_200.len = zT_201;
    d8l_m = zT_200;
    zT_202 = d8l_m;
    zT_204 = self->local_decl_names;
    zT_205 = self->local_decl_count;
    zT_207 = zT_205 - (unsigned int)(1);
    zT_203 = zT_204[zT_207];
    zF_C914CB83_markerWriteInt(zT_202, zT_203);
    goto z_bb_26;
    z_bb_26:
    zT_209 = self->local_decl_count;
    if ((unsigned char)(zT_209 > (unsigned int)(4))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_213 = "D8:X";
    zT_215 = 4;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    d8x_m = zT_214;
    zT_216 = d8x_m;
    zT_218 = self->local_decl_names;
    zT_219 = 4;
    zT_217 = zT_218[zT_219];
    zF_C914CB83_markerWriteInt(zT_216, zT_217);
    goto z_bb_28;
    z_bb_28:
    zT_222 = "D8:I";
    zT_224 = 4;
    zT_223.ptr = zT_222;
    zT_223.len = zT_224;
    d8i_m = zT_223;
    zT_225 = d8i_m;
    zT_226 = node_idx;
    zF_C914CB83_markerWriteInt(zT_225, zT_226);
    if ((unsigned char)(node_idx >= (unsigned int)(450))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_229 = node_idx <= (unsigned int)(660);
    goto z_bb_31;
    z_bb_30:
    zT_229 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_229) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_233 = self->interner;
    zT_234 = name_id;
    zT_236 = zF_9134020D_stringInternerGet(zT_233, zT_234);
    cname = zT_236;
    zT_237 = cname;
    zF_48AC7B3A_markerWrite(zT_237);
    zT_239 = self->store;
    zT_240 = node_idx;
    zT_242 = zF_FCDD1D35_astStoreNodeAt(zT_239, zT_240);
    cnode = zT_242;
    zT_244 = "D8";
    zT_246 = 2;
    zT_245.ptr = zT_244;
    zT_245.len = zT_246;
    d8k_m = zT_245;
    zT_247 = d8k_m;
    zT_249 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_247, (unsigned int)((unsigned int)zT_249));
    zT_252 = self->type_table;
    zT_253 = node_idx;
    zT_255 = zF_999DCF51_resolvedTypeTableGe(zT_252, zT_253);
    rt = zT_255;
    zT_256 = rt.has_value;
    if (zT_256) goto z_bb_34; else goto z_bb_36;
    z_bb_33:
    zT_274 = self->_stub_0;
    if ((unsigned char)(name_id == zT_274)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    t = rt.value;
    zT_259 = "D8:T";
    zT_261 = 4;
    zT_260.ptr = zT_259;
    zT_260.len = zT_261;
    d8t_m = zT_260;
    zT_262 = d8t_m;
    zT_263 = t;
    zF_C914CB83_markerWriteInt(zT_262, zT_263);
    goto z_bb_35;
    z_bb_35:
    zT_270 = "\n";
    zT_272 = 1;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    d8nl2 = zT_271;
    zT_273 = d8nl2;
    zF_48AC7B3A_markerWrite(zT_273);
    goto z_bb_33;
    z_bb_36:
    zT_265 = "D8:Z\n";
    zT_267 = 5;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    d8z_m = zT_266;
    zT_268 = d8z_m;
    zF_48AC7B3A_markerWrite(zT_268);
    goto z_bb_35;
    z_bb_37:
    return (unsigned int)(18);
    z_bb_38:
    zT_278 = "IDT:";
    zT_280 = 4;
    zT_279.ptr = zT_278;
    zT_279.len = zT_280;
    idm = zT_279;
    zT_281 = idm;
    zF_48AC7B3A_markerWrite(zT_281);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_283[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        idnb[_i] = zT_283[_i];
        _i++;
    }
}
    zT_285 = name_id;
    zT_289 = 0;
    zT_290 = (unsigned char*)((unsigned char*)idnb) + zT_289;
    zT_291 = (unsigned int)(10) - zT_289;
    zT_292.ptr = zT_290;
    zT_292.len = zT_291;
    zT_286 = zT_292;
    zT_293 = zF_A7504564_itoa(zT_285, zT_286);
    idnl = zT_293;
    zT_297 = (unsigned int)(9) - (unsigned int)((unsigned int)idnl);
    idns = zT_297;
    zT_302 = (unsigned char*)((unsigned char*)idnb) + idns;
    zT_303 = (unsigned int)(9) - idns;
    zT_304.ptr = zT_302;
    zT_304.len = zT_303;
    zT_298 = zT_304;
    zF_48AC7B3A_markerWrite(zT_298);
    zT_306 = ":VOID\n";
    zT_308 = 6;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    idc = zT_307;
    zT_309 = idc;
    zF_48AC7B3A_markerWrite(zT_309);
    return (unsigned int)(1);
}

/* semanticAnalyzerArrayFieldLen */
unsigned int zF_3F00B75F_semanticAnalyzerArr(zT_38C12417_SemanticAnalyzer* self, unsigned int base_node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_8143F551_AstKind zT_7;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_29;
    unsigned int zT_30;
    zT_338B7C76_TypeRegistry* zT_34;
    zT_D155D06D_Type* zT_35;
    unsigned int zT_36;
    zT_D155D06D_Type zT_37;
    zT_33EF6BFB_TypeKind zT_38;
    unsigned char zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_112BF819_PtrPayload* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_112BF819_PtrPayload zT_51;
    unsigned int zT_52;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_D155D06D_Type* zT_59;
    unsigned int zT_60;
    zT_D155D06D_Type zT_61;
    int zT_63;
    unsigned int zT_64;
    int zT_66;
    unsigned int zT_67;
    zT_33EF6BFB_TypeKind zT_68;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_406493CE_StructPayload* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_406493CE_StructPayload zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned short zT_80;
    unsigned int zT_81;
    zT_33EF6BFB_TypeKind zT_82;
    unsigned char zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    zT_338B7C76_TypeRegistry* zT_92;
    zT_AF9231A2_UnionPayload* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_AF9231A2_UnionPayload zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned short zT_99;
    unsigned int zT_100;
    int zT_103;
    unsigned int zT_104;
    zT_338B7C76_TypeRegistry* zT_106;
    zT_2DF01B61_FieldEntry* zT_107;
    unsigned int zT_108;
    zT_2DF01B61_FieldEntry zT_109;
    unsigned int zT_110;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_2DF01B61_FieldEntry* zT_114;
    unsigned int zT_115;
    zT_2DF01B61_FieldEntry zT_116;
    unsigned int zT_117;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    unsigned char zT_122;
    zT_338B7C76_TypeRegistry* zT_123;
    zT_D155D06D_Type* zT_124;
    unsigned int zT_125;
    zT_D155D06D_Type zT_126;
    zT_33EF6BFB_TypeKind zT_127;
    int zT_133;
    unsigned int zT_135;
    zT_22A7C88B_AstNode bn;
    unsigned int fname;
    unsigned int cont;
    zT_D155D06D_Type cty;
    unsigned int fstart;
    unsigned int fcount;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    zT_AF9231A2_UnionPayload up;
    unsigned int ft;
    zT_3 = self->store;
    zT_4 = base_node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    bn = zT_6;
    zT_7 = bn.kind;
    if ((unsigned char)(zT_7 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_13 = self->store;
    zT_14 = base_node_idx;
    zT_16 = zF_8BA26B9E_astStoreNodePayload(zT_13, zT_14);
    fname = zT_16;
    zT_18 = self;
    zT_19 = bn.child_0;
    zT_21 = zF_54F95822_semanticAnalyzerRes(zT_18, zT_19);
    cont = zT_21;
    if ((unsigned char)(cont == (unsigned int)(1))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_24 = cont == (unsigned int)(18);
    goto z_bb_5;
    z_bb_4:
    zT_24 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_24) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(0);
    z_bb_7:
    zT_29 = self->registry;
    zT_30 = zT_29->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)cont) >= zT_30)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned int)(0);
    z_bb_9:
    zT_34 = self->registry;
    zT_35 = zT_34->types_items;
    zT_36 = (unsigned int)cont;
    zT_37 = zT_35[zT_36];
    cty = zT_37;
    zT_38 = cty.kind;
    if ((unsigned char)(zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_43 = cty.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_12;
    z_bb_11:
    zT_42 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_42) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_47 = self->registry;
    zT_48 = zT_47->ptr_items;
    zT_49 = cty.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    zT_52 = zT_51.base;
    cont = zT_52;
    zT_54 = self->registry;
    zT_55 = zT_54->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)cont) >= zT_55)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_63 = 0;
    zT_64 = (unsigned int)zT_63;
    fstart = zT_64;
    zT_66 = 0;
    zT_67 = (unsigned int)zT_66;
    fcount = zT_67;
    zT_68 = cty.kind;
    if ((unsigned char)(zT_68 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    return (unsigned int)(0);
    z_bb_16:
    zT_58 = self->registry;
    zT_59 = zT_58->types_items;
    zT_60 = (unsigned int)cont;
    zT_61 = zT_59[zT_60];
    cty = zT_61;
    goto z_bb_14;
    z_bb_17:
    zT_73 = self->registry;
    zT_74 = zT_73->st_items;
    zT_75 = cty.payload_idx;
    zT_76 = (unsigned int)zT_75;
    zT_77 = zT_74[zT_76];
    sp = zT_77;
    zT_78 = sp.fields_start;
    zT_79 = (unsigned int)zT_78;
    fstart = zT_79;
    zT_80 = sp.fields_count;
    zT_81 = (unsigned int)zT_80;
    fcount = zT_81;
    goto z_bb_18;
    z_bb_18:
    zT_103 = 0;
    zT_104 = (unsigned int)zT_103;
    fi = zT_104;
    goto z_bb_26;
    z_bb_19:
    zT_82 = cty.kind;
    if ((unsigned char)(zT_82 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_87 = cty.kind;
    zT_86 = zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_22;
    z_bb_21:
    zT_86 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_86) goto z_bb_23; else goto z_bb_25;
    z_bb_23:
    zT_92 = self->registry;
    zT_93 = zT_92->un_items;
    zT_94 = cty.payload_idx;
    zT_95 = (unsigned int)zT_94;
    zT_96 = zT_93[zT_95];
    up = zT_96;
    zT_97 = up.fields_start;
    zT_98 = (unsigned int)zT_97;
    fstart = zT_98;
    zT_99 = up.fields_count;
    zT_100 = (unsigned int)zT_99;
    fcount = zT_100;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_18;
    z_bb_25:
    return (unsigned int)(0);
    z_bb_26:
    if ((unsigned char)(fi < fcount)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_106 = self->registry;
    zT_107 = zT_106->fe_items;
    zT_108 = fstart + fi;
    zT_109 = zT_107[zT_108];
    zT_110 = zT_109.name_id;
    if ((unsigned char)(zT_110 == fname)) goto z_bb_30; else goto z_bb_31;
    z_bb_28:
    return (unsigned int)(0);
    z_bb_29:
    zT_133 = 1;
    zT_135 = fi + (unsigned int)((unsigned int)zT_133);
    fi = zT_135;
    goto z_bb_26;
    z_bb_30:
    zT_113 = self->registry;
    zT_114 = zT_113->fe_items;
    zT_115 = fstart + fi;
    zT_116 = zT_114[zT_115];
    zT_117 = zT_116.type_id;
    ft = zT_117;
    zT_119 = self->registry;
    zT_120 = zT_119->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ft) < zT_120)) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_123 = self->registry;
    zT_124 = zT_123->types_items;
    zT_125 = (unsigned int)ft;
    zT_126 = zT_124[zT_125];
    zT_127 = zT_126.kind;
    zT_122 = zT_127 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_34;
    z_bb_33:
    zT_122 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_122) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned int)(13);
    z_bb_36:
    return (unsigned int)(0);
}

/* semanticAnalyzerResolveFieldAccess */
unsigned int zF_DDD991E1_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8143F551_AstKind zT_29;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8143F551_AstKind zT_37;
    zT_38C12417_SemanticAnalyzer* zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    unsigned int zT_51 = 0;
    zT_3D7259E2_SymbolRegistry* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_5D7DACC8_Opt_861 zT_58 = {0};
    unsigned char zT_59;
    zT_3C598AEF_SymbolKind zT_61;
    unsigned int zT_66;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_D155D06D_Type* zT_71;
    unsigned int zT_72;
    zT_D155D06D_Type zT_73;
    zT_33EF6BFB_TypeKind zT_74;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_54FF90FA_TaggedUnionPayload* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_54FF90FA_TaggedUnionPayload zT_83;
    unsigned int zT_85;
    unsigned int zT_86;
    unsigned short zT_88;
    unsigned int zT_89;
    int zT_91;
    unsigned int zT_92;
    zT_338B7C76_TypeRegistry* zT_94;
    zT_2DF01B61_FieldEntry* zT_95;
    unsigned int zT_96;
    zT_2DF01B61_FieldEntry zT_97;
    unsigned int zT_98;
    zT_8EED1867_ResolvedTypeTable* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    int zT_104;
    unsigned int zT_106;
    zT_33EF6BFB_TypeKind zT_107;
    zT_338B7C76_TypeRegistry* zT_112;
    zT_457ECFEE_EnumPayload* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    zT_457ECFEE_EnumPayload zT_116;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned short zT_121;
    unsigned int zT_122;
    int zT_124;
    unsigned int zT_125;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_D96DCDF2_EnumMember* zT_128;
    unsigned int zT_129;
    zT_D96DCDF2_EnumMember zT_130;
    unsigned int zT_131;
    zT_8EED1867_ResolvedTypeTable* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    int zT_137;
    unsigned int zT_139;
    zT_33EF6BFB_TypeKind zT_140;
    zT_338B7C76_TypeRegistry* zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_149 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    zT_3C598AEF_SymbolKind zT_156;
    unsigned int zT_161;
    zT_3D7259E2_SymbolRegistry* zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    zT_5D7DACC8_Opt_861 zT_167 = {0};
    unsigned char zT_168;
    unsigned char* zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned short zT_176;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    zT_3C598AEF_SymbolKind zT_184;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    unsigned short zT_199;
    zT_3C598AEF_SymbolKind zT_204;
    zT_8EED1867_ResolvedTypeTable* zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned int zT_213;
    unsigned int zT_214;
    zT_8EED1867_ResolvedTypeTable* zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned int zT_222;
    zT_3C598AEF_SymbolKind zT_223;
    unsigned char zT_227;
    unsigned int zT_228;
    unsigned char* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    zT_6B0A7D14_AstStore* zT_237;
    unsigned int zT_238;
    zT_22A7C88B_AstNode zT_241 = {0};
    zT_8143F551_AstKind zT_242;
    zT_6B0A7D14_AstStore* zT_247;
    zT_7ABA3706_anon_234425 zT_248;
    zT_243D6A41_FnProto* zT_249;
    zT_6B0A7D14_AstStore* zT_250;
    unsigned int zT_251;
    unsigned int zT_254 = 0;
    unsigned int zT_255;
    zT_243D6A41_FnProto zT_256;
    unsigned char* zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned int zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned int zT_262;
    unsigned int zT_264;
    zT_8EED1867_ResolvedTypeTable* zT_268;
    unsigned int zT_269;
    zT_BAEE192E_Opt_10 zT_272 = {0};
    unsigned char zT_274;
    unsigned int zT_275;
    unsigned char* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    unsigned char zT_284;
    zT_338B7C76_TypeRegistry* zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    unsigned int zT_292;
    unsigned short zT_293;
    unsigned int zT_294;
    unsigned char zT_295;
    unsigned int zT_304 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    zT_ABC1EBBE_TypeResolveEnv zT_310;
    zT_6B0A7D14_AstStore* zT_311;
    zT_338B7C76_TypeRegistry* zT_312;
    zT_3D7259E2_SymbolRegistry* zT_313;
    zT_D3EB6303_StringInterner* zT_314;
    unsigned int zT_315;
    zT_F85C5DED_DiagnosticCollector* zT_316;
    zT_7234F36B_Opt_226 zT_317;
    zT_F5B966E3_Opt_396 zT_318 = {0};
    zT_03B97CED_Opt_398 zT_319 = {0};
    unsigned int zT_320;
    zT_ABC1EBBE_TypeResolveEnv* zT_322;
    unsigned int zT_323;
    unsigned int zT_328 = 0;
    unsigned char* zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    unsigned char* zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned int zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned int zT_341;
    zT_8EED1867_ResolvedTypeTable* zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    zT_338B7C76_TypeRegistry* zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_355;
    unsigned short zT_356;
    unsigned int zT_357;
    unsigned char zT_358;
    unsigned int zT_367 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_368;
    unsigned int zT_369;
    unsigned int zT_370;
    unsigned char* zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_374;
    unsigned int zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    zT_338B7C76_TypeRegistry* zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned int zT_383;
    unsigned short zT_384;
    unsigned char zT_386;
    unsigned int zT_396 = 0;
    unsigned char* zT_398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_399;
    unsigned int zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_401;
    unsigned int zT_402;
    zT_8EED1867_ResolvedTypeTable* zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned char* zT_408;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_409;
    unsigned int zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_412;
    zT_8EED1867_ResolvedTypeTable* zT_413;
    unsigned int zT_414;
    unsigned int zT_422;
    unsigned int zT_424;
    unsigned int zT_426;
    zT_D3EB6303_StringInterner* zT_428;
    unsigned int zT_429;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_431 = {0};
    unsigned char* zT_433;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    unsigned int zT_435;
    unsigned char* zT_437;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_438;
    unsigned int zT_439;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_441;
    unsigned int zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    zT_D3EB6303_StringInterner* zT_446;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_447;
    int zT_450;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_451;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_453 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_454;
    unsigned int zT_457;
    unsigned int zT_458;
    unsigned int zT_459;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_460;
    unsigned int zT_467 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_468;
    unsigned int zT_469;
    zT_8143F551_AstKind zT_474;
    zT_6B0A7D14_AstStore* zT_479;
    unsigned int zT_480;
    unsigned int zT_483 = 0;
    zT_072B53A6_ModuleRegistry* zT_485;
    unsigned int zT_486;
    zT_BAEE192E_Opt_10 zT_488 = {0};
    unsigned char zT_489;
    zT_3D7259E2_SymbolRegistry* zT_492;
    unsigned int zT_493;
    unsigned int zT_494;
    zT_5D7DACC8_Opt_861 zT_496 = {0};
    unsigned char zT_497;
    unsigned short zT_499;
    zT_3C598AEF_SymbolKind zT_504;
    zT_8EED1867_ResolvedTypeTable* zT_508;
    unsigned int zT_509;
    unsigned int zT_510;
    unsigned int zT_513;
    unsigned int zT_514;
    zT_8EED1867_ResolvedTypeTable* zT_517;
    unsigned int zT_518;
    unsigned int zT_519;
    unsigned int zT_522;
    zT_38C12417_SemanticAnalyzer* zT_524;
    unsigned int zT_525;
    unsigned int zT_527 = 0;
    unsigned char* zT_531;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_532;
    unsigned int zT_533;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_534;
    zT_8EED1867_ResolvedTypeTable* zT_535;
    unsigned int zT_536;
    zT_338B7C76_TypeRegistry* zT_542;
    zT_D155D06D_Type* zT_543;
    unsigned int zT_544;
    zT_D155D06D_Type zT_545;
    int zT_547;
    unsigned int zT_548;
    int zT_550;
    unsigned int zT_551;
    zT_33EF6BFB_TypeKind zT_552;
    unsigned char zT_556;
    zT_33EF6BFB_TypeKind zT_557;
    zT_33EF6BFB_TypeKind zT_562;
    zT_338B7C76_TypeRegistry* zT_563;
    zT_112BF819_PtrPayload* zT_564;
    unsigned int zT_565;
    unsigned int zT_566;
    zT_112BF819_PtrPayload zT_567;
    unsigned int zT_568;
    zT_338B7C76_TypeRegistry* zT_569;
    zT_D155D06D_Type* zT_570;
    unsigned int zT_571;
    zT_D155D06D_Type zT_572;
    unsigned char* zT_574;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_575;
    unsigned int zT_576;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_577;
    unsigned char* zT_581;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_582;
    unsigned int zT_583;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_584;
    zT_33EF6BFB_TypeKind zT_586;
    unsigned char* zT_589;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_590;
    unsigned int zT_591;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_592;
    unsigned char* zT_597;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_598;
    unsigned int zT_599;
    zT_D3EB6303_StringInterner* zT_601;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_602;
    unsigned int zT_604 = 0;
    unsigned char* zT_607;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_608;
    unsigned int zT_609;
    zT_F85C5DED_DiagnosticCollector* zT_610;
    unsigned int zT_613;
    unsigned int zT_614;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_616;
    unsigned int zT_622;
    unsigned int zT_623;
    unsigned int zT_626 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_627;
    unsigned int zT_628;
    zT_33EF6BFB_TypeKind zT_633;
    unsigned int zT_638;
    unsigned int zT_640;
    unsigned int zT_642;
    unsigned char* zT_644;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_645;
    unsigned int zT_646;
    zT_F85C5DED_DiagnosticCollector* zT_647;
    unsigned int zT_650;
    unsigned int zT_651;
    unsigned int zT_652;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_653;
    unsigned int zT_658 = 0;
    zT_33EF6BFB_TypeKind zT_660;
    unsigned int zT_665;
    unsigned int zT_667;
    unsigned int zT_669;
    unsigned char* zT_671;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_672;
    unsigned int zT_673;
    zT_F85C5DED_DiagnosticCollector* zT_674;
    unsigned int zT_677;
    unsigned int zT_678;
    unsigned int zT_679;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_680;
    unsigned int zT_685 = 0;
    zT_33EF6BFB_TypeKind zT_687;
    zT_338B7C76_TypeRegistry* zT_692;
    zT_406493CE_StructPayload* zT_693;
    unsigned int zT_694;
    unsigned int zT_695;
    zT_406493CE_StructPayload zT_696;
    unsigned int zT_697;
    unsigned int zT_698;
    unsigned short zT_699;
    unsigned int zT_700;
    zT_33EF6BFB_TypeKind zT_701;
    unsigned char zT_705;
    zT_33EF6BFB_TypeKind zT_706;
    zT_338B7C76_TypeRegistry* zT_711;
    zT_AF9231A2_UnionPayload* zT_712;
    unsigned int zT_713;
    unsigned int zT_714;
    zT_AF9231A2_UnionPayload zT_715;
    unsigned int zT_716;
    unsigned int zT_717;
    unsigned short zT_718;
    unsigned int zT_719;
    zT_33EF6BFB_TypeKind zT_720;
    zT_338B7C76_TypeRegistry* zT_725;
    zT_54FF90FA_TaggedUnionPayload* zT_726;
    unsigned int zT_727;
    unsigned int zT_728;
    zT_54FF90FA_TaggedUnionPayload zT_729;
    unsigned char* zT_731;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_732;
    unsigned int zT_733;
    zT_D3EB6303_StringInterner* zT_735;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_736;
    unsigned int zT_738 = 0;
    unsigned char* zT_741;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_742;
    unsigned int zT_743;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_744;
    zT_8EED1867_ResolvedTypeTable* zT_745;
    unsigned int zT_746;
    unsigned int zT_747;
    unsigned int zT_750;
    unsigned char* zT_752;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_753;
    unsigned int zT_754;
    zT_D3EB6303_StringInterner* zT_756;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_759 = 0;
    unsigned short zT_762;
    unsigned int zT_763;
    int zT_765;
    unsigned int zT_766;
    zT_338B7C76_TypeRegistry* zT_769;
    zT_2DF01B61_FieldEntry* zT_770;
    unsigned int zT_771;
    unsigned int zT_773;
    zT_2DF01B61_FieldEntry zT_774;
    unsigned int zT_775;
    unsigned int zT_779;
    zT_338B7C76_TypeRegistry* zT_781;
    zT_D155D06D_Type* zT_782;
    unsigned int zT_783;
    zT_D155D06D_Type zT_784;
    zT_33EF6BFB_TypeKind zT_785;
    zT_338B7C76_TypeRegistry* zT_790;
    zT_E834303C_ArrayPayload* zT_791;
    unsigned int zT_792;
    unsigned int zT_793;
    zT_E834303C_ArrayPayload zT_794;
    unsigned int zT_795;
    zT_338B7C76_TypeRegistry* zT_796;
    unsigned int zT_797;
    unsigned int zT_801 = 0;
    unsigned char* zT_803;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_804;
    unsigned int zT_805;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_806;
    zT_8EED1867_ResolvedTypeTable* zT_807;
    unsigned int zT_808;
    unsigned int zT_809;
    int zT_811;
    unsigned int zT_813;
    unsigned int zT_814;
    unsigned int zT_815;
    unsigned short zT_816;
    unsigned int zT_817;
    zT_33EF6BFB_TypeKind zT_818;
    unsigned char* zT_823;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_824;
    unsigned int zT_825;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_826;
    zT_3D7259E2_SymbolRegistry* zT_828;
    unsigned int zT_829;
    unsigned int zT_830;
    zT_5D7DACC8_Opt_861 zT_833 = {0};
    unsigned char zT_834;
    unsigned int zT_836;
    unsigned char* zT_840;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_841;
    unsigned int zT_842;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_843;
    zT_8EED1867_ResolvedTypeTable* zT_844;
    unsigned int zT_845;
    unsigned int zT_846;
    unsigned int zT_849;
    zT_3C598AEF_SymbolKind zT_850;
    zT_8EED1867_ResolvedTypeTable* zT_855;
    unsigned int zT_856;
    zT_BAEE192E_Opt_10 zT_859 = {0};
    unsigned char zT_860;
    unsigned char* zT_863;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_864;
    unsigned int zT_865;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_866;
    zT_8EED1867_ResolvedTypeTable* zT_867;
    unsigned int zT_868;
    unsigned int zT_869;
    unsigned char* zT_872;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_873;
    unsigned int zT_874;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_875;
    zT_6B0A7D14_AstStore* zT_877;
    unsigned int zT_878;
    zT_22A7C88B_AstNode zT_881 = {0};
    zT_8143F551_AstKind zT_882;
    zT_6B0A7D14_AstStore* zT_887;
    zT_7ABA3706_anon_234425 zT_888;
    zT_243D6A41_FnProto* zT_889;
    zT_6B0A7D14_AstStore* zT_890;
    unsigned int zT_891;
    unsigned int zT_894 = 0;
    unsigned int zT_895;
    zT_243D6A41_FnProto zT_896;
    unsigned char* zT_898;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_899;
    unsigned int zT_900;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_901;
    unsigned int zT_903;
    unsigned int zT_905;
    zT_8EED1867_ResolvedTypeTable* zT_909;
    unsigned int zT_910;
    zT_BAEE192E_Opt_10 zT_913 = {0};
    unsigned char zT_914;
    zT_338B7C76_TypeRegistry* zT_917;
    unsigned int zT_918;
    unsigned int zT_919;
    unsigned int zT_922;
    unsigned short zT_923;
    unsigned int zT_924;
    unsigned char zT_925;
    unsigned int zT_934 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_935;
    unsigned int zT_936;
    unsigned int zT_937;
    zT_ABC1EBBE_TypeResolveEnv zT_940;
    zT_6B0A7D14_AstStore* zT_941;
    zT_338B7C76_TypeRegistry* zT_942;
    zT_3D7259E2_SymbolRegistry* zT_943;
    zT_D3EB6303_StringInterner* zT_944;
    unsigned int zT_945;
    zT_F85C5DED_DiagnosticCollector* zT_946;
    zT_7234F36B_Opt_226 zT_947;
    zT_F5B966E3_Opt_396 zT_948 = {0};
    zT_03B97CED_Opt_398 zT_949 = {0};
    unsigned int zT_950;
    zT_ABC1EBBE_TypeResolveEnv* zT_952;
    unsigned int zT_953;
    unsigned int zT_958 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_961;
    unsigned int zT_962;
    unsigned int zT_963;
    zT_338B7C76_TypeRegistry* zT_967;
    unsigned int zT_968;
    unsigned int zT_969;
    unsigned int zT_972;
    unsigned short zT_973;
    unsigned int zT_974;
    unsigned char zT_975;
    unsigned int zT_984 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_985;
    unsigned int zT_986;
    unsigned int zT_987;
    zT_338B7C76_TypeRegistry* zT_990;
    unsigned int zT_991;
    unsigned int zT_992;
    unsigned int zT_995;
    unsigned short zT_996;
    unsigned char zT_998;
    unsigned int zT_1008 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_1009;
    unsigned int zT_1010;
    unsigned int zT_1011;
    unsigned char* zT_1014;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1015;
    unsigned int zT_1016;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1017;
    zT_3C598AEF_SymbolKind zT_1019;
    unsigned char* zT_1022;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1023;
    unsigned int zT_1024;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1025;
    zT_8EED1867_ResolvedTypeTable* zT_1026;
    unsigned int zT_1027;
    zT_33EF6BFB_TypeKind zT_1032;
    zT_338B7C76_TypeRegistry* zT_1037;
    zT_0BB2A741_SlicePayload* zT_1038;
    unsigned int zT_1039;
    unsigned int zT_1040;
    zT_0BB2A741_SlicePayload zT_1041;
    unsigned char* zT_1043;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1044;
    unsigned int zT_1045;
    zT_D3EB6303_StringInterner* zT_1047;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1048;
    unsigned int zT_1050 = 0;
    unsigned char* zT_1053;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1054;
    unsigned int zT_1055;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1056;
    zT_8EED1867_ResolvedTypeTable* zT_1057;
    unsigned int zT_1058;
    unsigned char* zT_1064;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1065;
    unsigned int zT_1066;
    zT_D3EB6303_StringInterner* zT_1068;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1069;
    unsigned int zT_1071 = 0;
    zT_338B7C76_TypeRegistry* zT_1074;
    unsigned int zT_1075;
    unsigned char zT_1079;
    unsigned int zT_1084 = 0;
    unsigned char* zT_1086;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1087;
    unsigned int zT_1088;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1089;
    zT_8EED1867_ResolvedTypeTable* zT_1090;
    unsigned int zT_1091;
    unsigned int zT_1092;
    zT_33EF6BFB_TypeKind zT_1094;
    unsigned char* zT_1099;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1100;
    unsigned int zT_1101;
    zT_D3EB6303_StringInterner* zT_1103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1104;
    unsigned int zT_1106 = 0;
    unsigned char* zT_1109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1110;
    unsigned int zT_1111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1112;
    zT_8EED1867_ResolvedTypeTable* zT_1113;
    unsigned int zT_1114;
    zT_33EF6BFB_TypeKind zT_1119;
    zT_338B7C76_TypeRegistry* zT_1124;
    unsigned int zT_1125;
    unsigned int zT_1126;
    unsigned int zT_1128 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_1131;
    unsigned int zT_1132;
    unsigned int zT_1133;
    zT_8EED1867_ResolvedTypeTable* zT_1135;
    unsigned int zT_1136;
    zT_33EF6BFB_TypeKind zT_1141;
    zT_338B7C76_TypeRegistry* zT_1146;
    zT_457ECFEE_EnumPayload* zT_1147;
    unsigned int zT_1148;
    unsigned int zT_1149;
    zT_457ECFEE_EnumPayload zT_1150;
    unsigned int zT_1152;
    unsigned int zT_1153;
    unsigned short zT_1155;
    unsigned int zT_1156;
    int zT_1158;
    unsigned int zT_1159;
    zT_338B7C76_TypeRegistry* zT_1161;
    zT_D96DCDF2_EnumMember* zT_1162;
    unsigned int zT_1163;
    zT_D96DCDF2_EnumMember zT_1164;
    unsigned int zT_1165;
    zT_8EED1867_ResolvedTypeTable* zT_1167;
    unsigned int zT_1168;
    unsigned int zT_1169;
    int zT_1171;
    unsigned int zT_1173;
    unsigned char* zT_1175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1176;
    unsigned int zT_1177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1178;
    zT_8EED1867_ResolvedTypeTable* zT_1179;
    unsigned int zT_1180;
    unsigned char* zT_1186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1187;
    unsigned int zT_1188;
    zT_D3EB6303_StringInterner* zT_1190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1191;
    unsigned int zT_1193 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1196;
    unsigned int zT_1197;
    unsigned int zT_1199 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_1202;
    unsigned int zT_1203;
    unsigned int zT_1204;
    unsigned char* zT_1207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1208;
    unsigned int zT_1209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1210;
    zT_8EED1867_ResolvedTypeTable* zT_1211;
    unsigned int zT_1212;
    int zT_1218;
    unsigned int zT_1219;
    zT_338B7C76_TypeRegistry* zT_1222;
    zT_2DF01B61_FieldEntry* zT_1223;
    unsigned int zT_1224;
    zT_2DF01B61_FieldEntry zT_1225;
    unsigned int zT_1226;
    unsigned int zT_1229;
    zT_338B7C76_TypeRegistry* zT_1231;
    zT_D155D06D_Type* zT_1232;
    unsigned int zT_1233;
    zT_D155D06D_Type zT_1234;
    zT_33EF6BFB_TypeKind zT_1235;
    zT_338B7C76_TypeRegistry* zT_1240;
    zT_E834303C_ArrayPayload* zT_1241;
    unsigned int zT_1242;
    unsigned int zT_1243;
    zT_E834303C_ArrayPayload zT_1244;
    unsigned int zT_1245;
    zT_338B7C76_TypeRegistry* zT_1246;
    unsigned int zT_1247;
    unsigned int zT_1251 = 0;
    unsigned char* zT_1253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1254;
    unsigned int zT_1255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1256;
    unsigned int zT_1257;
    zT_8EED1867_ResolvedTypeTable* zT_1258;
    unsigned int zT_1259;
    unsigned int zT_1260;
    int zT_1262;
    unsigned int zT_1264;
    unsigned char* zT_1266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1267;
    unsigned int zT_1268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1269;
    unsigned char* zT_1271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1272;
    unsigned int zT_1273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1274;
    unsigned int zT_1275;
    unsigned char* zT_1277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1278;
    unsigned int zT_1279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1280;
    unsigned int zT_1281;
    unsigned char* zT_1283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1284;
    unsigned int zT_1285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1286;
    unsigned int zT_1287;
    zT_8EED1867_ResolvedTypeTable* zT_1288;
    unsigned int zT_1289;
    zT_8F083A69_Slice_zT_0B42B2F8_u fae;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode base_node;
    unsigned int field_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_bkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_fnm;
    unsigned int base_rt;
    unsigned int base_ident_id;
    zT_5D7DACC8_Opt_861 sym;
    unsigned int base_type_id;
    zT_3A105EF1_Symbol* s;
    unsigned int alias_type_id;
    zT_D155D06D_Type aty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int fi;
    zT_457ECFEE_EnumPayload ep;
    unsigned int estart;
    unsigned int ecount;
    unsigned int ei;
    unsigned int es_mi;
    unsigned int target_mod;
    zT_5D7DACC8_Opt_861 field_sym;
    zT_3A105EF1_Symbol* fs;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1kl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1tl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1v_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fx;
    zT_22A7C88B_AstNode fn_dn;
    zT_243D6A41_FnProto proto;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre1_m;
    zT_BAEE192E_Opt_10 rtt;
    unsigned int rtt_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre3_m;
    unsigned int fn_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre4_m;
    unsigned int rv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre2_m;
    unsigned int rtv;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int resolved_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr1_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr2_m;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u uinm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uiparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u uimsg;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fa1;
    zT_D155D06D_Type base_ty;
    unsigned int fields_start;
    unsigned int fields_count;
    zT_33EF6BFB_TypeKind pre_kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_ok_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_dk_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u mpl_len_s;
    unsigned int mpl_len_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u mpl_msg;
    unsigned int sp;
    unsigned int ep_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u opt_msg;
    unsigned int ep_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u eu_msg;
    zT_406493CE_StructPayload sp_3;
    zT_AF9231A2_UnionPayload up;
    zT_8F083A69_Slice_zT_0B42B2F8_u tag_s;
    unsigned int tag_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ft_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u payload_s;
    unsigned int payload_id;
    unsigned int fpe_count;
    unsigned int fpei;
    zT_2DF01B61_FieldEntry fpe;
    unsigned int payload_res;
    zT_D155D06D_Type payload_rt;
    unsigned int payload_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpe_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfa;
    zT_5D7DACC8_Opt_861 mod_field_sym;
    zT_3A105EF1_Symbol* mfs;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf3;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf1;
    zT_BAEE192E_Opt_10 fn_tid_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf2_m;
    unsigned int fn_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u mff;
    zT_22A7C88B_AstNode dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfp_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_b;
    unsigned int resolved_rt_b;
    zT_0BB2A741_SlicePayload sp_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u len_s;
    unsigned int len_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsl;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptr_s;
    unsigned int ptr_id;
    unsigned int pty;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u faa_m;
    unsigned int es_mi2;
    zT_457ECFEE_EnumPayload ep3;
    unsigned int estart3;
    unsigned int ecount3;
    unsigned int ei3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf;
    unsigned int afl_ty;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2b_m;
    unsigned int result;
    zT_D155D06D_Type rt;
    unsigned int elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_3 = "FAE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fae = zT_4;
    zT_6 = fae;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    base_node = zT_17;
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    field_name_id = zT_22;
    zT_24 = "PFA:BK";
    zT_26 = 6;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    pfa_bkm = zT_25;
    zT_27 = pfa_bkm;
    zT_29 = base_node.kind;
    zF_C914CB83_markerWriteInt(zT_27, (unsigned int)((unsigned int)zT_29));
    zT_32 = "PFA:FN";
    zT_34 = 6;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    pfa_fnm = zT_33;
    zT_35 = pfa_fnm;
    zT_36 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_35, zT_36);
    zT_37 = base_node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_42 = self;
    zT_43 = node.child_0;
    zT_45 = zF_54F95822_semanticAnalyzerRes(zT_42, zT_43);
    base_rt = zT_45;
    zT_47 = self->store;
    zT_48 = node.child_0;
    zT_51 = zF_53458827_astStoreIdentifier(zT_47, zT_48);
    base_ident_id = zT_51;
    zT_53 = self->symbols;
    zT_54 = self->module_id;
    zT_55 = base_ident_id;
    zT_58 = zF_A398987E_symbolRegistryQuali(zT_53, zT_54, zT_55);
    sym = zT_58;
    zT_59 = sym.has_value;
    if (zT_59) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_524 = self;
    zT_525 = node.child_0;
    zT_527 = zF_54F95822_semanticAnalyzerRes(zT_524, zT_525);
    base_type_id = zT_527;
    if ((unsigned char)(base_type_id == (unsigned int)(1))) goto z_bb_71; else goto z_bb_72;
    z_bb_3:
    zT_474 = base_node.kind;
    if ((unsigned char)(zT_474 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_59; else goto z_bb_60;
    z_bb_4:
    s = sym.value;
    zT_61 = s->kind;
    if ((unsigned char)(zT_61 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    if ((unsigned char)(base_rt == (unsigned int)(1))) goto z_bb_57; else goto z_bb_58;
    z_bb_7:
    zT_66 = s->type_id;
    alias_type_id = zT_66;
    if ((unsigned char)(alias_type_id != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_156 = s->kind;
    if ((unsigned char)(zT_156 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_31; else goto z_bb_32;
    z_bb_9:
    zT_70 = self->registry;
    zT_71 = zT_70->types_items;
    zT_72 = (unsigned int)alias_type_id;
    zT_73 = zT_71[zT_72];
    aty = zT_73;
    zT_74 = aty.kind;
    if ((unsigned char)(zT_74 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_79 = self->registry;
    zT_80 = zT_79->tu_items;
    zT_81 = aty.payload_idx;
    zT_82 = (unsigned int)zT_81;
    zT_83 = zT_80[zT_82];
    tp = zT_83;
    zT_85 = tp.fields_start;
    zT_86 = (unsigned int)zT_85;
    fstart = zT_86;
    zT_88 = tp.fields_count;
    zT_89 = (unsigned int)zT_88;
    fcount = zT_89;
    zT_91 = 0;
    zT_92 = (unsigned int)zT_91;
    fi = zT_92;
    goto z_bb_13;
    z_bb_12:
    zT_107 = aty.kind;
    if ((unsigned char)(zT_107 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    if ((unsigned char)(fi < fcount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_94 = self->registry;
    zT_95 = zT_94->fe_items;
    zT_96 = fstart + fi;
    zT_97 = zT_95[zT_96];
    zT_98 = zT_97.name_id;
    if ((unsigned char)(zT_98 == field_name_id)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_104 = 1;
    zT_106 = fi + (unsigned int)((unsigned int)zT_104);
    fi = zT_106;
    goto z_bb_13;
    z_bb_17:
    zT_100 = self->type_table;
    zT_101 = node_idx;
    zT_102 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_100, zT_101, zT_102);
    return alias_type_id;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_112 = self->registry;
    zT_113 = zT_112->en_items;
    zT_114 = aty.payload_idx;
    zT_115 = (unsigned int)zT_114;
    zT_116 = zT_113[zT_115];
    ep = zT_116;
    zT_118 = ep.members_start;
    zT_119 = (unsigned int)zT_118;
    estart = zT_119;
    zT_121 = ep.members_count;
    zT_122 = (unsigned int)zT_121;
    ecount = zT_122;
    zT_124 = 0;
    zT_125 = (unsigned int)zT_124;
    ei = zT_125;
    goto z_bb_21;
    z_bb_20:
    zT_140 = aty.kind;
    if ((unsigned char)(zT_140 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    if ((unsigned char)(ei < ecount)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_127 = self->registry;
    zT_128 = zT_127->em_items;
    zT_129 = estart + ei;
    zT_130 = zT_128[zT_129];
    zT_131 = zT_130.name_id;
    if ((unsigned char)(zT_131 == field_name_id)) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_137 = 1;
    zT_139 = ei + (unsigned int)((unsigned int)zT_137);
    ei = zT_139;
    goto z_bb_21;
    z_bb_25:
    zT_133 = self->type_table;
    zT_134 = node_idx;
    zT_135 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_133, zT_134, zT_135);
    return alias_type_id;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_145 = self->registry;
    zT_146 = alias_type_id;
    zT_147 = field_name_id;
    zT_149 = zF_D2ECD176_typeRegistryErrorSe(zT_145, zT_146, zT_147);
    es_mi = zT_149;
    if ((unsigned char)(es_mi != (unsigned int)(4294967295u))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    zT_152 = self->type_table;
    zT_153 = node_idx;
    zT_154 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_152, zT_153, zT_154);
    return alias_type_id;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_161 = s->module_id;
    target_mod = zT_161;
    zT_163 = self->symbols;
    zT_164 = target_mod;
    zT_165 = field_name_id;
    zT_167 = zF_A398987E_symbolRegistryQuali(zT_163, zT_164, zT_165);
    field_sym = zT_167;
    zT_168 = field_sym.has_value;
    if (zT_168) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_5;
    z_bb_33:
    fs = field_sym.value;
    zT_171 = "Q1:FL";
    zT_173 = 5;
    zT_172.ptr = zT_171;
    zT_172.len = zT_173;
    q1fl_m = zT_172;
    zT_174 = q1fl_m;
    zT_176 = fs->flags;
    zF_C914CB83_markerWriteInt(zT_174, (unsigned int)((unsigned int)zT_176));
    zT_179 = "Q1:KL";
    zT_181 = 5;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    q1kl_m = zT_180;
    zT_182 = q1kl_m;
    zT_184 = fs->kind;
    zF_C914CB83_markerWriteInt(zT_182, (unsigned int)((unsigned int)zT_184));
    zT_187 = "Q1:TL";
    zT_189 = 5;
    zT_188.ptr = zT_187;
    zT_188.len = zT_189;
    q1tl_m = zT_188;
    zT_190 = q1tl_m;
    zT_191 = fs->type_id;
    zF_C914CB83_markerWriteInt(zT_190, zT_191);
    zT_194 = "Q1:FN";
    zT_196 = 5;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    q1fn_m = zT_195;
    zT_197 = q1fn_m;
    zT_198 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_197, zT_198);
    zT_199 = fs->flags;
    if ((unsigned char)((unsigned short)(zT_199 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_408 = "Q1VF:FN";
    zT_410 = 7;
    zT_409.ptr = zT_408;
    zT_409.len = zT_410;
    q1v_m = zT_409;
    zT_411 = q1v_m;
    zT_412 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_411, zT_412);
    zT_413 = self->type_table;
    zT_414 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_413, zT_414, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_35:
    zT_204 = fs->kind;
    if ((unsigned char)(zT_204 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_223 = fs->kind;
    if ((unsigned char)(zT_223 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_41; else goto z_bb_42;
    z_bb_37:
    zT_208 = self->type_table;
    zT_209 = node_idx;
    zT_210 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_208, zT_209, zT_210);
    zT_213 = fs->type_id;
    return zT_213;
    z_bb_38:
    zT_214 = fs->type_id;
    if ((unsigned char)(zT_214 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_217 = self->type_table;
    zT_218 = node_idx;
    zT_219 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_217, zT_218, zT_219);
    zT_222 = fs->type_id;
    return zT_222;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_228 = fs->decl_node;
    zT_227 = zT_228 != (unsigned int)(0);
    goto z_bb_43;
    z_bb_42:
    zT_227 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_227) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_232 = "Q1FX\n";
    zT_234 = 5;
    zT_233.ptr = zT_232;
    zT_233.len = zT_234;
    q1fx = zT_233;
    zT_235 = q1fx;
    zF_48AC7B3A_markerWrite(zT_235);
    zT_237 = self->store;
    zT_238 = fs->decl_node;
    zT_241 = zF_FCDD1D35_astStoreNodeAt(zT_237, zT_238);
    fn_dn = zT_241;
    zT_242 = fn_dn.kind;
    if ((unsigned char)(zT_242 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_34;
    z_bb_46:
    zT_247 = self->store;
    zT_248 = zT_247->fn_protos;
    zT_249 = zT_248.items;
    zT_250 = self->store;
    zT_251 = fs->decl_node;
    zT_254 = zF_8BA26B9E_astStoreNodePayload(zT_250, zT_251);
    zT_255 = (unsigned int)zT_254;
    zT_256 = zT_249[zT_255];
    proto = zT_256;
    zT_258 = "BR:x";
    zT_260 = 4;
    zT_259.ptr = zT_258;
    zT_259.len = zT_260;
    bre1_m = zT_259;
    zT_261 = bre1_m;
    zT_262 = proto.name_id;
    zF_C914CB83_markerWriteInt(zT_261, zT_262);
    zT_264 = proto.return_type_node;
    if ((unsigned char)(zT_264 != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_268 = self->type_table;
    zT_269 = proto.return_type_node;
    zT_272 = zF_999DCF51_resolvedTypeTableGe(zT_268, zT_269);
    rtt = zT_272;
    zT_274 = rtt.has_value;
    if (zT_274) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    zT_373 = "BR:dv\n";
    zT_375 = 6;
    zT_374.ptr = zT_373;
    zT_374.len = zT_375;
    bre3_m = zT_374;
    zT_376 = bre3_m;
    zF_48AC7B3A_markerWrite(zT_376);
    zT_378 = self->registry;
    zT_379 = proto.name_id;
    zT_380 = fs->module_id;
    zT_383 = proto.params_start;
    zT_384 = proto.params_count;
    zT_386 = proto.call_conv;
    zT_396 = zF_474336D7_typeRegistryGetOrCr(zT_378, zT_379, zT_380, (unsigned char)(0), (unsigned char)(0), zT_383, zT_384, (unsigned int)(1), zT_386);
    fn_ty = zT_396;
    zT_398 = "BR:ft";
    zT_400 = 5;
    zT_399.ptr = zT_398;
    zT_399.len = zT_400;
    bre4_m = zT_399;
    zT_401 = bre4_m;
    zT_402 = fn_ty;
    zF_C914CB83_markerWriteInt(zT_401, zT_402);
    zT_403 = self->type_table;
    zT_404 = node_idx;
    zT_405 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_403, zT_404, zT_405);
    return fn_ty;
    z_bb_50:
    rv = rtt.value;
    zT_275 = rv;
    goto z_bb_52;
    z_bb_51:
    zT_275 = 0;
    goto z_bb_52;
    z_bb_52:
    rtt_val = zT_275;
    zT_279 = "BR:rt";
    zT_281 = 5;
    zT_280.ptr = zT_279;
    zT_280.len = zT_281;
    bre2_m = zT_280;
    zT_282 = bre2_m;
    zT_283 = rtt_val;
    zF_C914CB83_markerWriteInt(zT_282, zT_283);
    zT_284 = rtt.has_value;
    if (zT_284) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    rtv = rtt.value;
    zT_287 = self->registry;
    zT_288 = proto.name_id;
    zT_289 = fs->module_id;
    zT_292 = proto.params_start;
    zT_293 = proto.params_count;
    zT_294 = rtv;
    zT_295 = proto.call_conv;
    zT_304 = zF_474336D7_typeRegistryGetOrCr(zT_287, zT_288, zT_289, (unsigned char)(0), (unsigned char)(0), zT_292, zT_293, zT_294, zT_295);
    fn_ty = zT_304;
    zT_305 = self->type_table;
    zT_306 = node_idx;
    zT_307 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_305, zT_306, zT_307);
    return fn_ty;
    z_bb_54:
    zT_311 = self->store;
    zT_310.store = zT_311;
    zT_312 = self->registry;
    zT_310.typereg = zT_312;
    zT_313 = self->symbols;
    zT_310.symbol_reg = zT_313;
    zT_314 = self->interner;
    zT_310.interner = zT_314;
    zT_315 = fs->module_id;
    zT_310.module_id = zT_315;
    zT_316 = self->diag;
    zT_317.has_value = 1;
    zT_317.value = zT_316;
    zT_310.diag = zT_317;
    zT_318.has_value = 0;
    zT_310.local_consts = zT_318;
    zT_319.has_value = 0;
    zT_310.local_types = zT_319;
    zT_320 = self->source_file_id;
    zT_310.source_file_id = zT_320;
    tre_env = zT_310;
    zT_322 = &tre_env;
    zT_323 = proto.return_type_node;
    zT_328 = zF_F2107C15_resolveTypeExprFull(zT_322, zT_323, (unsigned int)(0));
    resolved_rt = zT_328;
    zT_330 = "BR:treN";
    zT_332 = 7;
    zT_331.ptr = zT_330;
    zT_331.len = zT_332;
    brr1_m = zT_331;
    zT_333 = brr1_m;
    zT_334 = proto.return_type_node;
    zF_C914CB83_markerWriteInt(zT_333, zT_334);
    zT_337 = "BR:treT";
    zT_339 = 7;
    zT_338.ptr = zT_337;
    zT_338.len = zT_339;
    brr2_m = zT_338;
    zT_340 = brr2_m;
    zT_341 = resolved_rt;
    zF_C914CB83_markerWriteInt(zT_340, zT_341);
    if ((unsigned char)(resolved_rt != (unsigned int)(18))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_344 = self->type_table;
    zT_345 = proto.return_type_node;
    zT_346 = resolved_rt;
    zF_19B4A07D_resolvedTypeTableSe(zT_344, zT_345, zT_346);
    zT_350 = self->registry;
    zT_351 = proto.name_id;
    zT_352 = fs->module_id;
    zT_355 = proto.params_start;
    zT_356 = proto.params_count;
    zT_357 = resolved_rt;
    zT_358 = proto.call_conv;
    zT_367 = zF_474336D7_typeRegistryGetOrCr(zT_350, zT_351, zT_352, (unsigned char)(0), (unsigned char)(0), zT_355, zT_356, zT_357, zT_358);
    fn_ty = zT_367;
    zT_368 = self->type_table;
    zT_369 = node_idx;
    zT_370 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_368, zT_369, zT_370);
    return fn_ty;
    z_bb_56:
    goto z_bb_49;
    z_bb_57:
    zT_422 = base_node.span_start;
    uisp = zT_422;
    zT_424 = base_node.span_len;
    zT_426 = uisp + (unsigned int)((unsigned int)zT_424);
    uiep = zT_426;
    zT_428 = self->interner;
    zT_429 = base_ident_id;
    zT_431 = zF_9134020D_stringInternerGet(zT_428, zT_429);
    uinm = zT_431;
    zT_433 = "identifier '";
    zT_435 = 12;
    zT_434.ptr = zT_433;
    zT_434.len = zT_435;
    ui1 = zT_434;
    zT_437 = "' is not declared or imported in this module";
    zT_439 = 44;
    zT_438.ptr = zT_437;
    zT_438.len = zT_439;
    ui2 = zT_438;
    zT_442 = 0;
    zT_441[zT_442] = ui1;
    zT_443 = 1;
    zT_441[zT_443] = uinm;
    zT_444 = 2;
    zT_441[zT_444] = ui2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uiparts[_i] = zT_441[_i];
        _i++;
    }
}
    zT_446 = self->interner;
    zT_450 = 0;
    zT_451 = uiparts + zT_450;
    zT_447 = zT_451;
    zT_453 = zF_8C4BFF7C_diagnosticBuilderMa(zT_446, zT_447, (unsigned int)(3));
    uimsg = zT_453;
    zT_454 = self->diag;
    zT_457 = self->source_file_id;
    zT_458 = uisp;
    zT_459 = uiep;
    zT_460 = uimsg;
    zT_467 = zF_C82559AC_diagnosticCollector(zT_454, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3001_UNDEFINED_SYMBOL)), zT_457, zT_458, zT_459, zT_460);
    (void)zT_467;
    zT_468 = self->type_table;
    zT_469 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_468, zT_469, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_58:
    goto z_bb_5;
    z_bb_59:
    zT_479 = self->store;
    zT_480 = node.child_0;
    zT_483 = zF_8BA26B9E_astStoreNodePayload(zT_479, zT_480);
    path_id = zT_483;
    zT_485 = self->module_reg;
    zT_486 = path_id;
    zT_488 = zF_A258E183_moduleRegistryPathT(zT_485, zT_486);
    target = zT_488;
    zT_489 = target.has_value;
    if (zT_489) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_2;
    z_bb_61:
    mtid = target.value;
    zT_492 = self->symbols;
    zT_493 = mtid;
    zT_494 = field_name_id;
    zT_496 = zF_A398987E_symbolRegistryQuali(zT_492, zT_493, zT_494);
    field_sym = zT_496;
    zT_497 = field_sym.has_value;
    if (zT_497) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    fs = field_sym.value;
    zT_499 = fs->flags;
    if ((unsigned char)((unsigned short)(zT_499 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    zT_504 = fs->kind;
    if ((unsigned char)(zT_504 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_508 = self->type_table;
    zT_509 = node_idx;
    zT_510 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_508, zT_509, zT_510);
    zT_513 = fs->type_id;
    return zT_513;
    z_bb_68:
    zT_514 = fs->type_id;
    if ((unsigned char)(zT_514 != (unsigned int)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_517 = self->type_table;
    zT_518 = node_idx;
    zT_519 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_517, zT_518, zT_519);
    zT_522 = fs->type_id;
    return zT_522;
    z_bb_70:
    goto z_bb_66;
    z_bb_71:
    zT_531 = "FB\n";
    zT_533 = 3;
    zT_532.ptr = zT_531;
    zT_532.len = zT_533;
    fa1 = zT_532;
    zT_534 = fa1;
    zF_48AC7B3A_markerWrite(zT_534);
    zT_535 = self->type_table;
    zT_536 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_535, zT_536, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_72:
    zT_542 = self->registry;
    zT_543 = zT_542->types_items;
    zT_544 = (unsigned int)base_type_id;
    zT_545 = zT_543[zT_544];
    base_ty = zT_545;
    zT_547 = 0;
    zT_548 = (unsigned int)zT_547;
    fields_start = zT_548;
    zT_550 = 0;
    zT_551 = (unsigned int)zT_550;
    fields_count = zT_551;
    zT_552 = base_ty.kind;
    if ((unsigned char)(zT_552 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_557 = base_ty.kind;
    zT_556 = zT_557 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_75;
    z_bb_74:
    zT_556 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_556) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_562 = base_ty.kind;
    pre_kind = zT_562;
    zT_563 = self->registry;
    zT_564 = zT_563->ptr_items;
    zT_565 = base_ty.payload_idx;
    zT_566 = (unsigned int)zT_565;
    zT_567 = zT_564[zT_566];
    zT_568 = zT_567.base;
    base_type_id = zT_568;
    zT_569 = self->registry;
    zT_570 = zT_569->types_items;
    zT_571 = (unsigned int)base_type_id;
    zT_572 = zT_570[zT_571];
    base_ty = zT_572;
    zT_574 = "FAPR:OK";
    zT_576 = 7;
    zT_575.ptr = zT_574;
    zT_575.len = zT_576;
    fapr_ok_m = zT_575;
    zT_577 = fapr_ok_m;
    zF_C914CB83_markerWriteInt(zT_577, (unsigned int)((unsigned int)pre_kind));
    zT_581 = "FAPR:DK";
    zT_583 = 7;
    zT_582.ptr = zT_581;
    zT_582.len = zT_583;
    fapr_dk_m = zT_582;
    zT_584 = fapr_dk_m;
    zT_586 = base_ty.kind;
    zF_C914CB83_markerWriteInt(zT_584, (unsigned int)((unsigned int)zT_586));
    zT_589 = "\n";
    zT_591 = 1;
    zT_590.ptr = zT_589;
    zT_590.len = zT_591;
    fapr_nl = zT_590;
    zT_592 = fapr_nl;
    zF_48AC7B3A_markerWrite(zT_592);
    if ((unsigned char)(pre_kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_77:
    zT_633 = base_ty.kind;
    if ((unsigned char)(zT_633 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_82; else goto z_bb_83;
    z_bb_78:
    zT_597 = "len";
    zT_599 = 3;
    zT_598.ptr = zT_597;
    zT_598.len = zT_599;
    mpl_len_s = zT_598;
    zT_601 = self->interner;
    zT_602 = mpl_len_s;
    zT_604 = zF_50C274AF_stringInternerInter(zT_601, zT_602);
    mpl_len_id = zT_604;
    if ((unsigned char)(field_name_id == mpl_len_id)) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    goto z_bb_77;
    z_bb_80:
    zT_607 = "many-item pointer has no field 'len'";
    zT_609 = 36;
    zT_608.ptr = zT_607;
    zT_608.len = zT_609;
    mpl_msg = zT_608;
    zT_610 = self->diag;
    zT_613 = self->source_file_id;
    zT_614 = node.span_start;
    zT_622 = node.span_start;
    zT_623 = node.span_len;
    zT_616 = mpl_msg;
    zT_626 = zF_C82559AC_diagnosticCollector(zT_610, (unsigned char)(0), (unsigned short)(3000), zT_613, zT_614, (unsigned int)(zT_622 + (unsigned int)((unsigned int)zT_623)), zT_616);
    (void)zT_626;
    zT_627 = self->type_table;
    zT_628 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_627, zT_628, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_638 = node.span_start;
    sp = zT_638;
    zT_640 = node.span_len;
    zT_642 = sp + (unsigned int)((unsigned int)zT_640);
    ep_1 = zT_642;
    zT_644 = "cannot access field on optional type; use .? to unwrap first";
    zT_646 = 60;
    zT_645.ptr = zT_644;
    zT_645.len = zT_646;
    opt_msg = zT_645;
    zT_647 = self->diag;
    zT_650 = self->source_file_id;
    zT_651 = sp;
    zT_652 = ep_1;
    zT_653 = opt_msg;
    zT_658 = zF_C82559AC_diagnosticCollector(zT_647, (unsigned char)(0), (unsigned short)(3000), zT_650, zT_651, zT_652, zT_653);
    (void)zT_658;
    return (unsigned int)(1);
    z_bb_83:
    zT_660 = base_ty.kind;
    if ((unsigned char)(zT_660 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_665 = node.span_start;
    sp = zT_665;
    zT_667 = node.span_len;
    zT_669 = sp + (unsigned int)((unsigned int)zT_667);
    ep_2 = zT_669;
    zT_671 = "cannot access field on error-union type; handle the error first";
    zT_673 = 63;
    zT_672.ptr = zT_671;
    zT_672.len = zT_673;
    eu_msg = zT_672;
    zT_674 = self->diag;
    zT_677 = self->source_file_id;
    zT_678 = sp;
    zT_679 = ep_2;
    zT_680 = eu_msg;
    zT_685 = zF_C82559AC_diagnosticCollector(zT_674, (unsigned char)(0), (unsigned short)(3000), zT_677, zT_678, zT_679, zT_680);
    (void)zT_685;
    return (unsigned int)(1);
    z_bb_85:
    zT_687 = base_ty.kind;
    if ((unsigned char)(zT_687 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_86; else goto z_bb_88;
    z_bb_86:
    zT_692 = self->registry;
    zT_693 = zT_692->st_items;
    zT_694 = base_ty.payload_idx;
    zT_695 = (unsigned int)zT_694;
    zT_696 = zT_693[zT_695];
    sp_3 = zT_696;
    zT_697 = sp_3.fields_start;
    zT_698 = (unsigned int)zT_697;
    fields_start = zT_698;
    zT_699 = sp_3.fields_count;
    zT_700 = (unsigned int)zT_699;
    fields_count = zT_700;
    goto z_bb_87;
    z_bb_87:
    zT_1218 = 0;
    zT_1219 = (unsigned int)zT_1218;
    fi = zT_1219;
    goto z_bb_160;
    z_bb_88:
    zT_701 = base_ty.kind;
    if ((unsigned char)(zT_701 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_90; else goto z_bb_89;
    z_bb_89:
    zT_706 = base_ty.kind;
    zT_705 = zT_706 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_91;
    z_bb_90:
    zT_705 = 1;
    goto z_bb_91;
    z_bb_91:
    if (zT_705) goto z_bb_92; else goto z_bb_94;
    z_bb_92:
    zT_711 = self->registry;
    zT_712 = zT_711->un_items;
    zT_713 = base_ty.payload_idx;
    zT_714 = (unsigned int)zT_713;
    zT_715 = zT_712[zT_714];
    up = zT_715;
    zT_716 = up.fields_start;
    zT_717 = (unsigned int)zT_716;
    fields_start = zT_717;
    zT_718 = up.fields_count;
    zT_719 = (unsigned int)zT_718;
    fields_count = zT_719;
    goto z_bb_93;
    z_bb_93:
    goto z_bb_87;
    z_bb_94:
    zT_720 = base_ty.kind;
    if ((unsigned char)(zT_720 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_95; else goto z_bb_97;
    z_bb_95:
    zT_725 = self->registry;
    zT_726 = zT_725->tu_items;
    zT_727 = base_ty.payload_idx;
    zT_728 = (unsigned int)zT_727;
    zT_729 = zT_726[zT_728];
    tp = zT_729;
    zT_731 = "tag";
    zT_733 = 3;
    zT_732.ptr = zT_731;
    zT_732.len = zT_733;
    tag_s = zT_732;
    zT_735 = self->interner;
    zT_736 = tag_s;
    zT_738 = zF_50C274AF_stringInternerInter(zT_735, zT_736);
    tag_id = zT_738;
    if ((unsigned char)(field_name_id == tag_id)) goto z_bb_98; else goto z_bb_99;
    z_bb_96:
    goto z_bb_93;
    z_bb_97:
    zT_818 = base_ty.kind;
    if ((unsigned char)(zT_818 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_110; else goto z_bb_112;
    z_bb_98:
    zT_741 = "FT:TAG\n";
    zT_743 = 7;
    zT_742.ptr = zT_741;
    zT_742.len = zT_743;
    ft_m = zT_742;
    zT_744 = ft_m;
    zF_48AC7B3A_markerWrite(zT_744);
    zT_745 = self->type_table;
    zT_746 = node_idx;
    zT_747 = tp.tag_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_745, zT_746, zT_747);
    zT_750 = tp.tag_type;
    return zT_750;
    z_bb_99:
    zT_752 = "payload";
    zT_754 = 7;
    zT_753.ptr = zT_752;
    zT_753.len = zT_754;
    payload_s = zT_753;
    zT_756 = self->interner;
    zT_757 = payload_s;
    zT_759 = zF_50C274AF_stringInternerInter(zT_756, zT_757);
    payload_id = zT_759;
    if ((unsigned char)(field_name_id == payload_id)) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_762 = tp.fields_count;
    zT_763 = (unsigned int)zT_762;
    fpe_count = zT_763;
    zT_765 = 0;
    zT_766 = (unsigned int)zT_765;
    fpei = zT_766;
    goto z_bb_102;
    z_bb_101:
    zT_814 = tp.fields_start;
    zT_815 = (unsigned int)zT_814;
    fields_start = zT_815;
    zT_816 = tp.fields_count;
    zT_817 = (unsigned int)zT_816;
    fields_count = zT_817;
    goto z_bb_96;
    z_bb_102:
    if ((unsigned char)(fpei < fpe_count)) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_769 = self->registry;
    zT_770 = zT_769->fe_items;
    zT_771 = tp.fields_start;
    zT_773 = (unsigned int)((unsigned int)zT_771) + fpei;
    zT_774 = zT_770[zT_773];
    fpe = zT_774;
    zT_775 = fpe.type_id;
    if ((unsigned char)(zT_775 != (unsigned int)(1))) goto z_bb_106; else goto z_bb_107;
    z_bb_104:
    goto z_bb_101;
    z_bb_105:
    zT_811 = 1;
    zT_813 = fpei + (unsigned int)((unsigned int)zT_811);
    fpei = zT_813;
    goto z_bb_102;
    z_bb_106:
    zT_779 = fpe.type_id;
    payload_res = zT_779;
    zT_781 = self->registry;
    zT_782 = zT_781->types_items;
    zT_783 = (unsigned int)payload_res;
    zT_784 = zT_782[zT_783];
    payload_rt = zT_784;
    zT_785 = payload_rt.kind;
    if ((unsigned char)(zT_785 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    zT_790 = self->registry;
    zT_791 = zT_790->array_items;
    zT_792 = payload_rt.payload_idx;
    zT_793 = (unsigned int)zT_792;
    zT_794 = zT_791[zT_793];
    zT_795 = zT_794.elem;
    payload_elem = zT_795;
    zT_796 = self->registry;
    zT_797 = payload_elem;
    zT_801 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_796, zT_797, (unsigned char)(0));
    payload_res = zT_801;
    goto z_bb_109;
    z_bb_109:
    zT_803 = "FP:PAYLOAD\n";
    zT_805 = 11;
    zT_804.ptr = zT_803;
    zT_804.len = zT_805;
    fpe_m = zT_804;
    zT_806 = fpe_m;
    zF_48AC7B3A_markerWrite(zT_806);
    zT_807 = self->type_table;
    zT_808 = node_idx;
    zT_809 = payload_res;
    zF_19B4A07D_resolvedTypeTableSe(zT_807, zT_808, zT_809);
    return payload_res;
    z_bb_110:
    zT_823 = "MFA\n";
    zT_825 = 4;
    zT_824.ptr = zT_823;
    zT_824.len = zT_825;
    mfa = zT_824;
    zT_826 = mfa;
    zF_48AC7B3A_markerWrite(zT_826);
    zT_828 = self->symbols;
    zT_829 = base_ty.module_id;
    zT_830 = field_name_id;
    zT_833 = zF_A398987E_symbolRegistryQuali(zT_828, zT_829, zT_830);
    mod_field_sym = zT_833;
    zT_834 = mod_field_sym.has_value;
    if (zT_834) goto z_bb_113; else goto z_bb_115;
    z_bb_111:
    goto z_bb_96;
    z_bb_112:
    zT_1032 = base_ty.kind;
    if ((unsigned char)(zT_1032 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_130; else goto z_bb_132;
    z_bb_113:
    mfs = mod_field_sym.value;
    zT_836 = mfs->type_id;
    if ((unsigned char)(zT_836 != (unsigned int)(0))) goto z_bb_116; else goto z_bb_117;
    z_bb_114:
    zT_1026 = self->type_table;
    zT_1027 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1026, zT_1027, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_115:
    zT_1022 = "MF3\n";
    zT_1024 = 4;
    zT_1023.ptr = zT_1022;
    zT_1023.len = zT_1024;
    mf3 = zT_1023;
    zT_1025 = mf3;
    zF_48AC7B3A_markerWrite(zT_1025);
    goto z_bb_114;
    z_bb_116:
    zT_840 = "MF1\n";
    zT_842 = 4;
    zT_841.ptr = zT_840;
    zT_841.len = zT_842;
    mf1 = zT_841;
    zT_843 = mf1;
    zF_48AC7B3A_markerWrite(zT_843);
    zT_844 = self->type_table;
    zT_845 = node_idx;
    zT_846 = mfs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_844, zT_845, zT_846);
    zT_849 = mfs->type_id;
    return zT_849;
    z_bb_117:
    zT_850 = mfs->kind;
    if ((unsigned char)(zT_850 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_855 = self->type_table;
    zT_856 = mfs->decl_node;
    zT_859 = zF_999DCF51_resolvedTypeTableGe(zT_855, zT_856);
    fn_tid_opt = zT_859;
    zT_860 = fn_tid_opt.has_value;
    if (zT_860) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    zT_1014 = "MF2";
    zT_1016 = 3;
    zT_1015.ptr = zT_1014;
    zT_1015.len = zT_1016;
    mf2_m = zT_1015;
    zT_1017 = mf2_m;
    zT_1019 = mfs->kind;
    zF_C914CB83_markerWriteInt(zT_1017, (unsigned int)((unsigned int)zT_1019));
    goto z_bb_114;
    z_bb_120:
    fn_tid = fn_tid_opt.value;
    zT_863 = "MF1\n";
    zT_865 = 4;
    zT_864.ptr = zT_863;
    zT_864.len = zT_865;
    mf1 = zT_864;
    zT_866 = mf1;
    zF_48AC7B3A_markerWrite(zT_866);
    zT_867 = self->type_table;
    zT_868 = node_idx;
    zT_869 = fn_tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_867, zT_868, zT_869);
    return fn_tid;
    z_bb_121:
    zT_872 = "MFF\n";
    zT_874 = 4;
    zT_873.ptr = zT_872;
    zT_873.len = zT_874;
    mff = zT_873;
    zT_875 = mff;
    zF_48AC7B3A_markerWrite(zT_875);
    zT_877 = self->store;
    zT_878 = mfs->decl_node;
    zT_881 = zF_FCDD1D35_astStoreNodeAt(zT_877, zT_878);
    dn = zT_881;
    zT_882 = dn.kind;
    if ((unsigned char)(zT_882 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_122; else goto z_bb_123;
    z_bb_122:
    zT_887 = self->store;
    zT_888 = zT_887->fn_protos;
    zT_889 = zT_888.items;
    zT_890 = self->store;
    zT_891 = mfs->decl_node;
    zT_894 = zF_8BA26B9E_astStoreNodePayload(zT_890, zT_891);
    zT_895 = (unsigned int)zT_894;
    zT_896 = zT_889[zT_895];
    proto = zT_896;
    zT_898 = "MFP";
    zT_900 = 3;
    zT_899.ptr = zT_898;
    zT_899.len = zT_900;
    mfp_m = zT_899;
    zT_901 = mfp_m;
    zT_903 = proto.params_start;
    zF_C914CB83_markerWriteInt(zT_901, (unsigned int)((unsigned int)zT_903));
    zT_905 = proto.return_type_node;
    if ((unsigned char)(zT_905 != (unsigned int)(0))) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    goto z_bb_119;
    z_bb_124:
    zT_909 = self->type_table;
    zT_910 = proto.return_type_node;
    zT_913 = zF_999DCF51_resolvedTypeTableGe(zT_909, zT_910);
    rtt = zT_913;
    zT_914 = rtt.has_value;
    if (zT_914) goto z_bb_126; else goto z_bb_127;
    z_bb_125:
    zT_990 = self->registry;
    zT_991 = proto.name_id;
    zT_992 = mfs->module_id;
    zT_995 = proto.params_start;
    zT_996 = proto.params_count;
    zT_998 = proto.call_conv;
    zT_1008 = zF_474336D7_typeRegistryGetOrCr(zT_990, zT_991, zT_992, (unsigned char)(0), (unsigned char)(0), zT_995, zT_996, (unsigned int)(1), zT_998);
    fn_ty = zT_1008;
    zT_1009 = self->type_table;
    zT_1010 = node_idx;
    zT_1011 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_1009, zT_1010, zT_1011);
    return fn_ty;
    z_bb_126:
    rtv = rtt.value;
    zT_917 = self->registry;
    zT_918 = proto.name_id;
    zT_919 = mfs->module_id;
    zT_922 = proto.params_start;
    zT_923 = proto.params_count;
    zT_924 = rtv;
    zT_925 = proto.call_conv;
    zT_934 = zF_474336D7_typeRegistryGetOrCr(zT_917, zT_918, zT_919, (unsigned char)(0), (unsigned char)(0), zT_922, zT_923, zT_924, zT_925);
    fn_ty = zT_934;
    zT_935 = self->type_table;
    zT_936 = node_idx;
    zT_937 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_935, zT_936, zT_937);
    return fn_ty;
    z_bb_127:
    zT_941 = self->store;
    zT_940.store = zT_941;
    zT_942 = self->registry;
    zT_940.typereg = zT_942;
    zT_943 = self->symbols;
    zT_940.symbol_reg = zT_943;
    zT_944 = self->interner;
    zT_940.interner = zT_944;
    zT_945 = mfs->module_id;
    zT_940.module_id = zT_945;
    zT_946 = self->diag;
    zT_947.has_value = 1;
    zT_947.value = zT_946;
    zT_940.diag = zT_947;
    zT_948.has_value = 0;
    zT_940.local_consts = zT_948;
    zT_949.has_value = 0;
    zT_940.local_types = zT_949;
    zT_950 = self->source_file_id;
    zT_940.source_file_id = zT_950;
    tre_env_b = zT_940;
    zT_952 = &tre_env_b;
    zT_953 = proto.return_type_node;
    zT_958 = zF_F2107C15_resolveTypeExprFull(zT_952, zT_953, (unsigned int)(0));
    resolved_rt_b = zT_958;
    if ((unsigned char)(resolved_rt_b != (unsigned int)(18))) goto z_bb_128; else goto z_bb_129;
    z_bb_128:
    zT_961 = self->type_table;
    zT_962 = proto.return_type_node;
    zT_963 = resolved_rt_b;
    zF_19B4A07D_resolvedTypeTableSe(zT_961, zT_962, zT_963);
    zT_967 = self->registry;
    zT_968 = proto.name_id;
    zT_969 = mfs->module_id;
    zT_972 = proto.params_start;
    zT_973 = proto.params_count;
    zT_974 = resolved_rt_b;
    zT_975 = proto.call_conv;
    zT_984 = zF_474336D7_typeRegistryGetOrCr(zT_967, zT_968, zT_969, (unsigned char)(0), (unsigned char)(0), zT_972, zT_973, zT_974, zT_975);
    fn_ty = zT_984;
    zT_985 = self->type_table;
    zT_986 = node_idx;
    zT_987 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_985, zT_986, zT_987);
    return fn_ty;
    z_bb_129:
    goto z_bb_125;
    z_bb_130:
    zT_1037 = self->registry;
    zT_1038 = zT_1037->slice_items;
    zT_1039 = base_ty.payload_idx;
    zT_1040 = (unsigned int)zT_1039;
    zT_1041 = zT_1038[zT_1040];
    sp_4 = zT_1041;
    zT_1043 = "len";
    zT_1045 = 3;
    zT_1044.ptr = zT_1043;
    zT_1044.len = zT_1045;
    len_s = zT_1044;
    zT_1047 = self->interner;
    zT_1048 = len_s;
    zT_1050 = zF_50C274AF_stringInternerInter(zT_1047, zT_1048);
    len_id = zT_1050;
    if ((unsigned char)(field_name_id == len_id)) goto z_bb_133; else goto z_bb_134;
    z_bb_131:
    goto z_bb_111;
    z_bb_132:
    zT_1094 = base_ty.kind;
    if ((unsigned char)(zT_1094 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_137; else goto z_bb_139;
    z_bb_133:
    zT_1053 = "FSL:USIZE\n";
    zT_1055 = 10;
    zT_1054.ptr = zT_1053;
    zT_1054.len = zT_1055;
    fsl = zT_1054;
    zT_1056 = fsl;
    zF_48AC7B3A_markerWrite(zT_1056);
    zT_1057 = self->type_table;
    zT_1058 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1057, zT_1058, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_134:
    zT_1064 = "ptr";
    zT_1066 = 3;
    zT_1065.ptr = zT_1064;
    zT_1065.len = zT_1066;
    ptr_s = zT_1065;
    zT_1068 = self->interner;
    zT_1069 = ptr_s;
    zT_1071 = zF_50C274AF_stringInternerInter(zT_1068, zT_1069);
    ptr_id = zT_1071;
    if ((unsigned char)(field_name_id == ptr_id)) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_1074 = self->registry;
    zT_1075 = sp_4.elem;
    zT_1079 = base_ty.flags;
    zT_1084 = zF_402D622A_typeRegistryGetOrCr(zT_1074, zT_1075, (unsigned char)((unsigned char)(zT_1079 & (unsigned char)(1)) != (unsigned char)(0)));
    pty = zT_1084;
    zT_1086 = "FSP:PTR\n";
    zT_1088 = 8;
    zT_1087.ptr = zT_1086;
    zT_1087.len = zT_1088;
    fsp = zT_1087;
    zT_1089 = fsp;
    zF_48AC7B3A_markerWrite(zT_1089);
    zT_1090 = self->type_table;
    zT_1091 = node_idx;
    zT_1092 = pty;
    zF_19B4A07D_resolvedTypeTableSe(zT_1090, zT_1091, zT_1092);
    return pty;
    z_bb_136:
    goto z_bb_131;
    z_bb_137:
    zT_1099 = "len";
    zT_1101 = 3;
    zT_1100.ptr = zT_1099;
    zT_1100.len = zT_1101;
    len_s = zT_1100;
    zT_1103 = self->interner;
    zT_1104 = len_s;
    zT_1106 = zF_50C274AF_stringInternerInter(zT_1103, zT_1104);
    len_id = zT_1106;
    if ((unsigned char)(field_name_id == len_id)) goto z_bb_140; else goto z_bb_141;
    z_bb_138:
    goto z_bb_131;
    z_bb_139:
    zT_1119 = base_ty.kind;
    if ((unsigned char)(zT_1119 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_142; else goto z_bb_144;
    z_bb_140:
    zT_1109 = "FAA:USIZE\n";
    zT_1111 = 10;
    zT_1110.ptr = zT_1109;
    zT_1110.len = zT_1111;
    faa_m = zT_1110;
    zT_1112 = faa_m;
    zF_48AC7B3A_markerWrite(zT_1112);
    zT_1113 = self->type_table;
    zT_1114 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1113, zT_1114, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_141:
    goto z_bb_138;
    z_bb_142:
    zT_1124 = self->registry;
    zT_1125 = base_type_id;
    zT_1126 = field_name_id;
    zT_1128 = zF_D2ECD176_typeRegistryErrorSe(zT_1124, zT_1125, zT_1126);
    es_mi2 = zT_1128;
    if ((unsigned char)(es_mi2 != (unsigned int)(4294967295u))) goto z_bb_145; else goto z_bb_146;
    z_bb_143:
    goto z_bb_138;
    z_bb_144:
    zT_1141 = base_ty.kind;
    if ((unsigned char)(zT_1141 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_147; else goto z_bb_149;
    z_bb_145:
    zT_1131 = self->type_table;
    zT_1132 = node_idx;
    zT_1133 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1131, zT_1132, zT_1133);
    return base_type_id;
    z_bb_146:
    zT_1135 = self->type_table;
    zT_1136 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1135, zT_1136, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_147:
    zT_1146 = self->registry;
    zT_1147 = zT_1146->en_items;
    zT_1148 = base_ty.payload_idx;
    zT_1149 = (unsigned int)zT_1148;
    zT_1150 = zT_1147[zT_1149];
    ep3 = zT_1150;
    zT_1152 = ep3.members_start;
    zT_1153 = (unsigned int)zT_1152;
    estart3 = zT_1153;
    zT_1155 = ep3.members_count;
    zT_1156 = (unsigned int)zT_1155;
    ecount3 = zT_1156;
    zT_1158 = 0;
    zT_1159 = (unsigned int)zT_1158;
    ei3 = zT_1159;
    goto z_bb_150;
    goto z_bb_143;
    z_bb_149:
    zT_1186 = "len";
    zT_1188 = 3;
    zT_1187.ptr = zT_1186;
    zT_1187.len = zT_1188;
    len_s = zT_1187;
    zT_1190 = self->interner;
    zT_1191 = len_s;
    zT_1193 = zF_50C274AF_stringInternerInter(zT_1190, zT_1191);
    len_id = zT_1193;
    if ((unsigned char)(field_name_id == len_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_150:
    if ((unsigned char)(ei3 < ecount3)) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_1161 = self->registry;
    zT_1162 = zT_1161->em_items;
    zT_1163 = estart3 + ei3;
    zT_1164 = zT_1162[zT_1163];
    zT_1165 = zT_1164.name_id;
    if ((unsigned char)(zT_1165 == field_name_id)) goto z_bb_154; else goto z_bb_155;
    z_bb_152:
    zT_1175 = "FF\n";
    zT_1177 = 3;
    zT_1176.ptr = zT_1175;
    zT_1176.len = zT_1177;
    fnf = zT_1176;
    zT_1178 = fnf;
    zF_48AC7B3A_markerWrite(zT_1178);
    zT_1179 = self->type_table;
    zT_1180 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1179, zT_1180, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_153:
    zT_1171 = 1;
    zT_1173 = ei3 + (unsigned int)((unsigned int)zT_1171);
    ei3 = zT_1173;
    goto z_bb_150;
    z_bb_154:
    zT_1167 = self->type_table;
    zT_1168 = node_idx;
    zT_1169 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1167, zT_1168, zT_1169);
    return base_type_id;
    z_bb_155:
    goto z_bb_153;
    z_bb_156:
    zT_1196 = self;
    zT_1197 = node.child_0;
    zT_1199 = zF_3F00B75F_semanticAnalyzerArr(zT_1196, zT_1197);
    afl_ty = zT_1199;
    if ((unsigned char)(afl_ty != (unsigned int)(0))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_1207 = "FF\n";
    zT_1209 = 3;
    zT_1208.ptr = zT_1207;
    zT_1208.len = zT_1209;
    fnf = zT_1208;
    zT_1210 = fnf;
    zF_48AC7B3A_markerWrite(zT_1210);
    zT_1211 = self->type_table;
    zT_1212 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1211, zT_1212, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_158:
    zT_1202 = self->type_table;
    zT_1203 = node_idx;
    zT_1204 = afl_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_1202, zT_1203, zT_1204);
    return afl_ty;
    z_bb_159:
    goto z_bb_157;
    z_bb_160:
    if ((unsigned char)(fi < fields_count)) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    zT_1222 = self->registry;
    zT_1223 = zT_1222->fe_items;
    zT_1224 = fields_start + fi;
    zT_1225 = zT_1223[zT_1224];
    fe = zT_1225;
    zT_1226 = fe.name_id;
    if ((unsigned char)(zT_1226 == field_name_id)) goto z_bb_164; else goto z_bb_165;
    z_bb_162:
    zT_1266 = "NF\n";
    zT_1268 = 3;
    zT_1267.ptr = zT_1266;
    zT_1267.len = zT_1268;
    fnf2 = zT_1267;
    zT_1269 = fnf2;
    zF_48AC7B3A_markerWrite(zT_1269);
    zT_1271 = "FF2:N";
    zT_1273 = 5;
    zT_1272.ptr = zT_1271;
    zT_1272.len = zT_1273;
    ff2n_m = zT_1272;
    zT_1274 = ff2n_m;
    zT_1275 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1274, zT_1275);
    zT_1277 = "FF2:F";
    zT_1279 = 5;
    zT_1278.ptr = zT_1277;
    zT_1278.len = zT_1279;
    ff2f_m = zT_1278;
    zT_1280 = ff2f_m;
    zT_1281 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_1280, zT_1281);
    zT_1283 = "FF2:B";
    zT_1285 = 5;
    zT_1284.ptr = zT_1283;
    zT_1284.len = zT_1285;
    ff2b_m = zT_1284;
    zT_1286 = ff2b_m;
    zT_1287 = base_type_id;
    zF_C914CB83_markerWriteInt(zT_1286, zT_1287);
    zT_1288 = self->type_table;
    zT_1289 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1288, zT_1289, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_163:
    goto z_bb_160;
    z_bb_164:
    zT_1229 = fe.type_id;
    result = zT_1229;
    zT_1231 = self->registry;
    zT_1232 = zT_1231->types_items;
    zT_1233 = (unsigned int)result;
    zT_1234 = zT_1232[zT_1233];
    rt = zT_1234;
    zT_1235 = rt.kind;
    if ((unsigned char)(zT_1235 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_166; else goto z_bb_167;
    z_bb_165:
    zT_1262 = 1;
    zT_1264 = fi + (unsigned int)((unsigned int)zT_1262);
    fi = zT_1264;
    goto z_bb_163;
    z_bb_166:
    zT_1240 = self->registry;
    zT_1241 = zT_1240->array_items;
    zT_1242 = rt.payload_idx;
    zT_1243 = (unsigned int)zT_1242;
    zT_1244 = zT_1241[zT_1243];
    zT_1245 = zT_1244.elem;
    elem = zT_1245;
    zT_1246 = self->registry;
    zT_1247 = elem;
    zT_1251 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1246, zT_1247, (unsigned char)(0));
    result = zT_1251;
    goto z_bb_167;
    z_bb_167:
    zT_1253 = "FF:R";
    zT_1255 = 4;
    zT_1254.ptr = zT_1253;
    zT_1254.len = zT_1255;
    ff_m = zT_1254;
    zT_1256 = ff_m;
    zT_1257 = result;
    zF_C914CB83_markerWriteInt(zT_1256, zT_1257);
    zT_1258 = self->type_table;
    zT_1259 = node_idx;
    zT_1260 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_1258, zT_1259, zT_1260);
    return result;
}

/* semanticAnalyzerPackedGateGrow */
void zF_151B0DD7_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_ACA03DB3_EU_632 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->packed_gate_cap;
    if ((unsigned char)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_gate_len;
    if ((unsigned char)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_gate_items = ndst;
    self->packed_gate_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->packed_gate_len;
    if ((unsigned char)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_gate_items;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerPackedGateMark */
void zF_E3B2C29D_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->packed_gate_len;
    zT_3 = self->packed_gate_cap;
    if ((unsigned char)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_151B0DD7_semanticAnalyzerPac(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->packed_gate_items;
    zT_7 = self->packed_gate_len;
    zT_6[zT_7] = node_idx;
    zT_8 = self->packed_gate_len;
    self->packed_gate_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedGateSeen */
unsigned char zF_5BBD6EB3_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_12;
    unsigned int gi;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    gi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_gate_len;
    if ((unsigned char)(gi < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_items;
    zT_8 = zT_7[gi];
    if ((unsigned char)(zT_8 == node_idx)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_12 = gi + (unsigned int)(1);
    gi = zT_12;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_4;
}

/* semanticAnalyzerPackedStructCacheGrow */
void zF_86D8CE03_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_ACA03DB3_EU_632 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_ACA03DB3_EU_632 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int* zT_58;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    unsigned char* raw2;
    unsigned int* ndst2;
    unsigned int ci2;
    zT_2 = self->packed_struct_cache_cap;
    if ((unsigned char)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_cache_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_struct_cache_len;
    if ((unsigned char)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_struct_tids = ndst;
    zT_37 = self->expected_type_stack_alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_13; else goto z_bb_14;
    z_bb_9:
    zT_30 = self->packed_struct_cache_len;
    if ((unsigned char)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
    z_bb_13:
    pal_trap();
    z_bb_14:
    zT_46 = zT_44.data.payload;
    goto z_bb_15;
    z_bb_15:
    raw2 = zT_46;
    zT_49 = (unsigned int*)raw2;
    ndst2 = zT_49;
    zT_50 = self->packed_struct_cache_len;
    if ((unsigned char)(zT_50 > (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    ci2 = zT_55;
    goto z_bb_18;
    z_bb_17:
    self->packed_struct_decl_nodes = ndst2;
    self->packed_struct_cache_cap = new_cap;
    return;
    z_bb_18:
    zT_56 = self->packed_struct_cache_len;
    if ((unsigned char)(ci2 < zT_56)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_58 = self->packed_struct_decl_nodes;
    zT_59 = zT_58[ci2];
    ndst2[ci2] = zT_59;
    goto z_bb_21;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_61 = ci2 + (unsigned int)(1);
    ci2 = zT_61;
    goto z_bb_18;
}

/* semanticAnalyzerPackedStructCacheAppend */
void zF_2C47D4E0_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_3 = self->packed_struct_cache_len;
    zT_4 = self->packed_struct_cache_cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_86D8CE03_semanticAnalyzerPac(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = self->packed_struct_cache_len;
    zT_7[zT_8] = struct_tid;
    zT_9 = self->packed_struct_decl_nodes;
    zT_10 = self->packed_struct_cache_len;
    zT_9[zT_10] = decl_node;
    zT_11 = self->packed_struct_cache_len;
    self->packed_struct_cache_len = (unsigned int)(zT_11 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCheckedStructTidsGrow */
void zF_055533B0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_ACA03DB3_EU_632 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->checked_struct_tids_cap;
    if ((unsigned char)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->checked_struct_tids_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->checked_struct_tids_len;
    if ((unsigned char)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->checked_struct_tids = ndst;
    self->checked_struct_tids_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->checked_struct_tids_len;
    if ((unsigned char)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->checked_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerCheckedStructTidsAppend */
void zF_B5A1E8BB_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->checked_struct_tids_len;
    zT_3 = self->checked_struct_tids_cap;
    if ((unsigned char)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_055533B0_semanticAnalyzerChe(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->checked_struct_tids;
    zT_7 = self->checked_struct_tids_len;
    zT_6[zT_7] = struct_tid;
    zT_8 = self->checked_struct_tids_len;
    self->checked_struct_tids_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedFieldTypeAllowed */
unsigned char zF_E42B9323_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, unsigned char allow_packed_struct_type) {
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_18;
    unsigned char zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    unsigned char zT_28;
    unsigned char zT_29;
    zT_33EF6BFB_TypeKind zT_35;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    unsigned char zT_42 = 0;
    zT_338B7C76_TypeRegistry* zT_46;
    unsigned int zT_47;
    unsigned int zT_49 = 0;
    unsigned char zT_52;
    zT_338B7C76_TypeRegistry* zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    unsigned char zT_61 = 0;
    zT_338B7C76_TypeRegistry* zT_65;
    unsigned int zT_66;
    unsigned char zT_68 = 0;
    zT_D155D06D_Type ty;
    unsigned int ebt;
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ty = zT_12;
    zT_13 = ty.kind;
    if ((unsigned char)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_18 = ty.kind;
    if ((unsigned char)(zT_18 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if (allow_packed_struct_type) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = ty.kind;
    zT_23 = zT_24 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_9;
    z_bb_8:
    zT_23 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_23) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_29 = ty.flags;
    zT_28 = (unsigned char)(zT_29 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_28 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_28) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    zT_35 = ty.kind;
    if ((unsigned char)(zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_39 = self->registry;
    zT_40 = tid;
    zT_42 = zF_A3BA89EA_typeRegistryEnumHas(zT_39, zT_40);
    if ((unsigned char)(!zT_42)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_65 = self->registry;
    zT_66 = tid;
    zT_68 = zF_3290E9C4_typeRegistryIsInteg(zT_65, zT_66);
    return zT_68;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    zT_46 = self->registry;
    zT_47 = tid;
    zT_49 = zF_014D7530_typeRegistryEnumBac(zT_46, zT_47);
    ebt = zT_49;
    if ((unsigned char)(ebt == (unsigned int)(18))) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_54 = self->registry;
    zT_55 = zT_54->types_len;
    zT_52 = (unsigned int)((unsigned int)ebt) >= zT_55;
    goto z_bb_21;
    z_bb_20:
    zT_52 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_52) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_58 = self->registry;
    zT_59 = ebt;
    zT_61 = zF_B664AC19_typeRegistryIsUnsig(zT_58, zT_59);
    if ((unsigned char)(!zT_61)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (unsigned char)(0);
    z_bb_25:
    return (unsigned char)(1);
}

/* semanticAnalyzerGatePackedFields */
void zF_C26EF425_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_12;
    zT_38C12417_SemanticAnalyzer* zT_17;
    unsigned int zT_18;
    unsigned char zT_19 = 0;
    zT_38C12417_SemanticAnalyzer* zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_41 = 0;
    zT_22A7C88B_AstNode zT_42 = {0};
    zT_8143F551_AstKind zT_43;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned char zT_52;
    zT_ABC1EBBE_TypeResolveEnv zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_3D7259E2_SymbolRegistry* zT_59;
    zT_D3EB6303_StringInterner* zT_60;
    zT_F85C5DED_DiagnosticCollector* zT_61;
    zT_7234F36B_Opt_226 zT_62;
    zT_F5B966E3_Opt_396 zT_63 = {0};
    zT_03B97CED_Opt_398 zT_64 = {0};
    unsigned int zT_65;
    zT_ABC1EBBE_TypeResolveEnv* zT_67;
    unsigned int zT_68;
    unsigned int zT_72 = 0;
    unsigned char zT_75;
    unsigned char zT_78;
    zT_38C12417_SemanticAnalyzer* zT_79;
    unsigned int zT_80;
    unsigned char zT_83 = 0;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned char zT_87 = 0;
    unsigned char zT_90;
    unsigned char zT_91;
    unsigned int zT_95;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_F85C5DED_DiagnosticCollector* zT_106;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_117 = 0;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_F85C5DED_DiagnosticCollector* zT_122;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_133 = 0;
    unsigned int zT_135;
    zT_22A7C88B_AstNode node;
    unsigned int children_n;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u pw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pg_msg;
    zT_4 = self->store;
    zT_5 = struct_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = node.flags;
    if ((unsigned char)((unsigned char)(zT_12 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_17 = self;
    zT_18 = struct_node_idx;
    zT_19 = zF_5BBD6EB3_semanticAnalyzerPac(zT_17, zT_18);
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_20 = self;
    zT_21 = struct_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_20, zT_21);
    zT_23 = self->store;
    zT_24 = struct_node_idx;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    children_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(ci < (unsigned int)((unsigned int)children_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = self->store;
    zT_36 = self->store;
    zT_37 = struct_node_idx;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)ci));
    zT_34 = zT_41;
    zT_42 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    fd = zT_42;
    zT_43 = fd.kind;
    if ((unsigned char)(zT_43 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_135 = ci + (unsigned int)(1);
    ci = zT_135;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_48 = fd.child_0;
    type_node = zT_48;
    zT_50 = 0;
    gate_state = zT_50;
    zT_52 = 0;
    gate_wide = zT_52;
    if ((unsigned char)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_57 = self->store;
    zT_56.store = zT_57;
    zT_58 = self->registry;
    zT_56.typereg = zT_58;
    zT_59 = self->symbols;
    zT_56.symbol_reg = zT_59;
    zT_60 = self->interner;
    zT_56.interner = zT_60;
    zT_56.module_id = module_id;
    zT_61 = self->diag;
    zT_62.has_value = 1;
    zT_62.value = zT_61;
    zT_56.diag = zT_62;
    zT_63.has_value = 0;
    zT_56.local_consts = zT_63;
    zT_64.has_value = 0;
    zT_56.local_types = zT_64;
    zT_65 = self->source_file_id;
    zT_56.source_file_id = zT_65;
    tre_env = zT_56;
    zT_67 = &tre_env;
    zT_68 = type_node;
    zT_72 = zF_F2107C15_resolveTypeExprFull(zT_67, zT_68, (unsigned int)(0));
    ft = zT_72;
    if ((unsigned char)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((unsigned char)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_75 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_75 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_75) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_78 = 1;
    gate_state = zT_78;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_79 = self;
    zT_80 = ft;
    zT_83 = zF_E42B9323_semanticAnalyzerPac(zT_79, zT_80, (unsigned char)(1));
    if (zT_83) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_84 = self->registry;
    zT_85 = ft;
    zT_87 = zF_655972D5_typeRegistryIntWidt(zT_84, zT_85);
    if ((unsigned char)(zT_87 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_90 = 1;
    gate_wide = zT_90;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_91 = 1;
    gate_state = zT_91;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_95 = fd.span_start;
    fsp = zT_95;
    zT_97 = fd.span_len;
    zT_99 = fsp + (unsigned int)((unsigned int)zT_97);
    fep = zT_99;
    if ((unsigned char)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_103 = "packed struct field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_105 = 95;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    pw_msg = zT_104;
    zT_106 = self->diag;
    zT_109 = self->source_file_id;
    zT_110 = fsp;
    zT_111 = fep;
    zT_112 = pw_msg;
    zT_117 = zF_C82559AC_diagnosticCollector(zT_106, (unsigned char)(0), (unsigned short)(3000), zT_109, zT_110, zT_111, zT_112);
    (void)zT_117;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_119 = "packed struct fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed struct";
    zT_121 = 111;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    pg_msg = zT_120;
    zT_122 = self->diag;
    zT_125 = self->source_file_id;
    zT_126 = fsp;
    zT_127 = fep;
    zT_128 = pg_msg;
    zT_133 = zF_C82559AC_diagnosticCollector(zT_122, (unsigned char)(0), (unsigned short)(3000), zT_125, zT_126, zT_127, zT_128);
    (void)zT_133;
    goto z_bb_29;
}

/* semanticAnalyzerMaybeGateAliasDecl */
void zF_FC6E31C6_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned int zT_11;
    unsigned char zT_13;
    zT_8143F551_AstKind zT_14;
    zT_8143F551_AstKind zT_18;
    unsigned char zT_22;
    unsigned char zT_27;
    zT_8143F551_AstKind zT_28;
    unsigned char zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_46;
    zT_8143F551_AstKind zT_47;
    unsigned char zT_51;
    unsigned char zT_52;
    unsigned int zT_57;
    unsigned char zT_58;
    zT_38C12417_SemanticAnalyzer* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((unsigned char)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = decl_node;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    dnode = zT_9;
    zT_11 = 0;
    target = zT_11;
    zT_13 = 0;
    is_union = zT_13;
    zT_14 = dnode.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_18 = dnode.kind;
    if ((unsigned char)(zT_18 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_22 = dnode.flags;
    if ((unsigned char)((unsigned char)(zT_22 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_28 = dnode.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_27 = 1;
    is_union = zT_27;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_33 = dnode.child_1;
    zT_32 = zT_33 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_32 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_32) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_37 = self->store;
    zT_38 = dnode.child_1;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_37, zT_38);
    inn = zT_41;
    zT_42 = inn.kind;
    if ((unsigned char)(zT_42 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_46 = dnode.child_1;
    target = zT_46;
    goto z_bb_17;
    z_bb_17:
    zT_47 = inn.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_52 = inn.flags;
    zT_51 = (unsigned char)(zT_52 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_51 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_51) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_57 = dnode.child_1;
    target = zT_57;
    zT_58 = 1;
    is_union = zT_58;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((unsigned char)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_63 = self;
    zT_64 = target;
    zT_65 = module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_63, zT_64, zT_65);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_66 = self;
    zT_67 = target;
    zT_68 = module_id;
    zF_F705063A_semanticAnalyzerGat(zT_66, zT_67, zT_68);
    goto z_bb_26;
}

/* semanticAnalyzerGateModulePackedDecl */
void zF_6A91A8CC_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned char zT_12;
    zT_8143F551_AstKind zT_13;
    zT_8143F551_AstKind zT_17;
    unsigned char zT_21;
    unsigned char zT_26;
    zT_8143F551_AstKind zT_27;
    unsigned char zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_45;
    zT_8143F551_AstKind zT_46;
    unsigned char zT_50;
    unsigned char zT_51;
    unsigned int zT_56;
    unsigned char zT_57;
    zT_38C12417_SemanticAnalyzer* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((unsigned char)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    target = zT_10;
    zT_12 = 0;
    is_union = zT_12;
    zT_13 = dnode.kind;
    if ((unsigned char)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_17 = dnode.kind;
    if ((unsigned char)(zT_17 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_21 = dnode.flags;
    if ((unsigned char)((unsigned char)(zT_21 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_27 = dnode.kind;
    if ((unsigned char)(zT_27 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_26 = 1;
    is_union = zT_26;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_32 = dnode.child_1;
    zT_31 = zT_32 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_31 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_31) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_36 = self->store;
    zT_37 = dnode.child_1;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    inn = zT_40;
    zT_41 = inn.kind;
    if ((unsigned char)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_45 = dnode.child_1;
    target = zT_45;
    goto z_bb_17;
    z_bb_17:
    zT_46 = inn.kind;
    if ((unsigned char)(zT_46 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_51 = inn.flags;
    zT_50 = (unsigned char)(zT_51 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_50 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_50) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_56 = dnode.child_1;
    target = zT_56;
    zT_57 = 1;
    is_union = zT_57;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((unsigned char)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_62 = self;
    zT_63 = target;
    zT_64 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_62, zT_63, zT_64);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_66 = self;
    zT_67 = target;
    zT_68 = self->module_id;
    zF_F705063A_semanticAnalyzerGat(zT_66, zT_67, zT_68);
    goto z_bb_26;
}

/* semanticAnalyzerGatePackedUnionMembers */
void zF_F705063A_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int union_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_12;
    zT_38C12417_SemanticAnalyzer* zT_17;
    unsigned int zT_18;
    unsigned char zT_19 = 0;
    zT_38C12417_SemanticAnalyzer* zT_20;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_41 = 0;
    zT_22A7C88B_AstNode zT_42 = {0};
    zT_8143F551_AstKind zT_43;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned char zT_52;
    zT_ABC1EBBE_TypeResolveEnv zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_3D7259E2_SymbolRegistry* zT_59;
    zT_D3EB6303_StringInterner* zT_60;
    zT_F85C5DED_DiagnosticCollector* zT_61;
    zT_7234F36B_Opt_226 zT_62;
    zT_F5B966E3_Opt_396 zT_63 = {0};
    zT_03B97CED_Opt_398 zT_64 = {0};
    unsigned int zT_65;
    zT_ABC1EBBE_TypeResolveEnv* zT_67;
    unsigned int zT_68;
    unsigned int zT_72 = 0;
    unsigned char zT_75;
    unsigned char zT_78;
    zT_38C12417_SemanticAnalyzer* zT_79;
    unsigned int zT_80;
    unsigned char zT_83 = 0;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned char zT_87 = 0;
    unsigned char zT_90;
    unsigned char zT_91;
    unsigned int zT_95;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_F85C5DED_DiagnosticCollector* zT_106;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_117 = 0;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_F85C5DED_DiagnosticCollector* zT_122;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_133 = 0;
    unsigned int zT_135;
    zT_22A7C88B_AstNode node;
    unsigned int children_n;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u puw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pgu_msg;
    zT_4 = self->store;
    zT_5 = union_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((unsigned char)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = node.flags;
    if ((unsigned char)((unsigned char)(zT_12 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_17 = self;
    zT_18 = union_node_idx;
    zT_19 = zF_5BBD6EB3_semanticAnalyzerPac(zT_17, zT_18);
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_20 = self;
    zT_21 = union_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_20, zT_21);
    zT_23 = self->store;
    zT_24 = union_node_idx;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    children_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(ci < (unsigned int)((unsigned int)children_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = self->store;
    zT_36 = self->store;
    zT_37 = union_node_idx;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)ci));
    zT_34 = zT_41;
    zT_42 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    fd = zT_42;
    zT_43 = fd.kind;
    if ((unsigned char)(zT_43 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_135 = ci + (unsigned int)(1);
    ci = zT_135;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_48 = fd.child_0;
    type_node = zT_48;
    zT_50 = 0;
    gate_state = zT_50;
    zT_52 = 0;
    gate_wide = zT_52;
    if ((unsigned char)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_57 = self->store;
    zT_56.store = zT_57;
    zT_58 = self->registry;
    zT_56.typereg = zT_58;
    zT_59 = self->symbols;
    zT_56.symbol_reg = zT_59;
    zT_60 = self->interner;
    zT_56.interner = zT_60;
    zT_56.module_id = module_id;
    zT_61 = self->diag;
    zT_62.has_value = 1;
    zT_62.value = zT_61;
    zT_56.diag = zT_62;
    zT_63.has_value = 0;
    zT_56.local_consts = zT_63;
    zT_64.has_value = 0;
    zT_56.local_types = zT_64;
    zT_65 = self->source_file_id;
    zT_56.source_file_id = zT_65;
    tre_env = zT_56;
    zT_67 = &tre_env;
    zT_68 = type_node;
    zT_72 = zF_F2107C15_resolveTypeExprFull(zT_67, zT_68, (unsigned int)(0));
    ft = zT_72;
    if ((unsigned char)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((unsigned char)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_75 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_75 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_75) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_78 = 1;
    gate_state = zT_78;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_79 = self;
    zT_80 = ft;
    zT_83 = zF_E42B9323_semanticAnalyzerPac(zT_79, zT_80, (unsigned char)(1));
    if (zT_83) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_84 = self->registry;
    zT_85 = ft;
    zT_87 = zF_655972D5_typeRegistryIntWidt(zT_84, zT_85);
    if ((unsigned char)(zT_87 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_90 = 1;
    gate_wide = zT_90;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_91 = 1;
    gate_state = zT_91;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_95 = fd.span_start;
    fsp = zT_95;
    zT_97 = fd.span_len;
    zT_99 = fsp + (unsigned int)((unsigned int)zT_97);
    fep = zT_99;
    if ((unsigned char)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_103 = "packed union field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_105 = 94;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    puw_msg = zT_104;
    zT_106 = self->diag;
    zT_109 = self->source_file_id;
    zT_110 = fsp;
    zT_111 = fep;
    zT_112 = puw_msg;
    zT_117 = zF_C82559AC_diagnosticCollector(zT_106, (unsigned char)(0), (unsigned short)(3000), zT_109, zT_110, zT_111, zT_112);
    (void)zT_117;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_119 = "packed union fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed union";
    zT_121 = 109;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    pgu_msg = zT_120;
    zT_122 = self->diag;
    zT_125 = self->source_file_id;
    zT_126 = fsp;
    zT_127 = fep;
    zT_128 = pgu_msg;
    zT_133 = zF_C82559AC_diagnosticCollector(zT_122, (unsigned char)(0), (unsigned short)(3000), zT_125, zT_126, zT_127, zT_128);
    (void)zT_133;
    goto z_bb_29;
}

/* semanticAnalyzerGateEnumModuleDecl */
void zF_4E74AE9D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    zT_8143F551_AstKind zT_15;
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_8143F551_AstKind zT_25;
    unsigned char zT_29;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode zT_38 = {0};
    zT_8143F551_AstKind zT_39;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    unsigned int zT_47 = 0;
    unsigned int zT_48;
    unsigned int zT_52;
    zT_79FAE712_u64 zT_57;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_79FAE712_u64 zT_59;
    zT_BAEE192E_Opt_10 zT_61 = {0};
    unsigned char zT_62;
    zT_38C12417_SemanticAnalyzer* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    unsigned int backing_node;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    unsigned int tid;
    if ((unsigned char)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    enum_node = zT_10;
    zT_12 = 0;
    enum_name_id = zT_12;
    zT_14 = 0;
    backing_node = zT_14;
    zT_15 = dnode.kind;
    if ((unsigned char)(zT_15 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_20 = dnode.child_1;
    zT_19 = zT_20 != (unsigned int)(0);
    goto z_bb_5;
    z_bb_4:
    zT_19 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_19) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    enum_node = decl_node;
    zT_23 = dnode.child_0;
    enum_name_id = zT_23;
    zT_24 = dnode.child_1;
    backing_node = zT_24;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_8:
    zT_25 = dnode.kind;
    if ((unsigned char)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_30 = dnode.child_1;
    zT_29 = zT_30 != (unsigned int)(0);
    goto z_bb_11;
    z_bb_10:
    zT_29 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_29) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_34 = self->store;
    zT_35 = dnode.child_1;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_34, zT_35);
    inn = zT_38;
    zT_39 = inn.kind;
    if ((unsigned char)(zT_39 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    goto z_bb_7;
    z_bb_14:
    zT_43 = dnode.child_1;
    enum_node = zT_43;
    zT_44 = self->store;
    zT_45 = decl_node;
    zT_47 = zF_8BA26B9E_astStoreNodePayload(zT_44, zT_45);
    enum_name_id = zT_47;
    zT_48 = inn.child_0;
    backing_node = zT_48;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    return;
    z_bb_17:
    zT_52 = self->module_id;
    zT_57 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_52) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)enum_name_id);
    key = zT_57;
    zT_58 = self->registry;
    zT_59 = key;
    zT_61 = zF_0EB68360_nameCacheGet(zT_58, zT_59);
    zT_62 = zT_61.has_value;
    if (zT_62) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    tid = zT_61.value;
    zT_64 = self;
    zT_65 = tid;
    zT_66 = enum_node;
    zT_67 = backing_node;
    zF_5EF7F98D_semanticAnalyzerGat(zT_64, zT_65, zT_66, zT_67);
    goto z_bb_19;
    z_bb_19:
    return;
}

/* semanticAnalyzerGateEnumTypeDecl */
void zF_5EF7F98D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, unsigned int enum_node, unsigned int backing_node) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    zT_338B7C76_TypeRegistry* zT_23;
    zT_457ECFEE_EnumPayload* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    zT_457ECFEE_EnumPayload zT_27;
    unsigned int zT_28;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    zT_22A7C88B_AstNode zT_35 = {0};
    unsigned int zT_37;
    unsigned int zT_39;
    unsigned int zT_41;
    zT_ABC1EBBE_TypeResolveEnv zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_3D7259E2_SymbolRegistry* zT_46;
    zT_D3EB6303_StringInterner* zT_47;
    unsigned int zT_48;
    zT_F85C5DED_DiagnosticCollector* zT_49;
    zT_7234F36B_Opt_226 zT_50;
    zT_F5B966E3_Opt_396 zT_51 = {0};
    zT_03B97CED_Opt_398 zT_52 = {0};
    unsigned int zT_53;
    zT_ABC1EBBE_TypeResolveEnv* zT_55;
    unsigned int zT_56;
    unsigned int zT_60 = 0;
    unsigned char zT_63;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_F85C5DED_DiagnosticCollector* zT_70;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_81 = 0;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_D155D06D_Type* zT_88;
    unsigned int zT_89;
    zT_D155D06D_Type zT_90;
    zT_33EF6BFB_TypeKind zT_91;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_F85C5DED_DiagnosticCollector* zT_99;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_110 = 0;
    zT_338B7C76_TypeRegistry* zT_111;
    unsigned int zT_112;
    unsigned char zT_114 = 0;
    zT_338B7C76_TypeRegistry* zT_116;
    unsigned int zT_117;
    unsigned char zT_119 = 0;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_F85C5DED_DiagnosticCollector* zT_124;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_135 = 0;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_F85C5DED_DiagnosticCollector* zT_140;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_151 = 0;
    zT_338B7C76_TypeRegistry* zT_153;
    unsigned int zT_154;
    unsigned char zT_156 = 0;
    unsigned int zT_157;
    zT_79FAE712_u64 zT_159;
    zT_79FAE712_u64 zT_166;
    zT_338B7C76_TypeRegistry* zT_168;
    zT_457ECFEE_EnumPayload* zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    zT_457ECFEE_EnumPayload zT_172;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned short zT_177;
    unsigned int zT_178;
    zT_6B0A7D14_AstStore* zT_180;
    unsigned int zT_181;
    unsigned int zT_183 = 0;
    unsigned int zT_185;
    int zT_187;
    unsigned int zT_188;
    zT_79FAE712_u64 zT_190;
    unsigned char zT_192;
    unsigned char zT_195;
    zT_6B0A7D14_AstStore* zT_198;
    unsigned int zT_199;
    zT_6B0A7D14_AstStore* zT_201;
    unsigned int zT_202;
    unsigned int zT_206 = 0;
    zT_22A7C88B_AstNode zT_207 = {0};
    zT_8143F551_AstKind zT_208;
    zT_338B7C76_TypeRegistry* zT_213;
    zT_D96DCDF2_EnumMember* zT_214;
    unsigned int zT_215;
    zT_D96DCDF2_EnumMember zT_216;
    zT_C69B2266_i64 zT_217;
    zT_79FAE712_u64 zT_219;
    unsigned int zT_222;
    unsigned int zT_224;
    unsigned int zT_226;
    unsigned char* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_230;
    zT_F85C5DED_DiagnosticCollector* zT_231;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_242 = 0;
    unsigned char zT_243;
    unsigned char zT_245;
    unsigned int zT_246;
    unsigned int zT_250;
    unsigned int zT_252;
    unsigned int zT_254;
    unsigned char* zT_256;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_257;
    unsigned int zT_258;
    zT_F85C5DED_DiagnosticCollector* zT_259;
    unsigned int zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    unsigned int zT_270 = 0;
    unsigned char zT_271;
    unsigned int zT_273;
    unsigned int zT_275;
    zT_D155D06D_Type ety;
    unsigned int check_btid;
    zT_22A7C88B_AstNode bnode;
    unsigned int bsp;
    unsigned int bep;
    zT_ABC1EBBE_TypeResolveEnv tre_env2;
    unsigned int bt;
    unsigned int nbits;
    zT_79FAE712_u64 maxv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bg_msg;
    zT_D155D06D_Type bty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bb_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bi_msg;
    zT_457ECFEE_EnumPayload ep2;
    unsigned int mstart2;
    unsigned int mcount2;
    unsigned int children2_n;
    unsigned int fcount2;
    unsigned int ci2;
    zT_79FAE712_u64 prev_vu;
    unsigned char have_prev;
    zT_22A7C88B_AstNode fd2;
    zT_C69B2266_i64 mv;
    zT_79FAE712_u64 mvu;
    unsigned int msp;
    unsigned int mep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mv_msg;
    zT_5 = self->registry;
    zT_6 = zT_5->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ety = zT_12;
    zT_13 = ety.kind;
    if ((unsigned char)(zT_13 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_17 = ety.payload_idx;
    zT_19 = self->registry;
    zT_20 = zT_19->en_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_17) >= zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_23 = self->registry;
    zT_24 = zT_23->en_items;
    zT_25 = ety.payload_idx;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24[zT_26];
    zT_28 = zT_27.backing_type;
    check_btid = zT_28;
    if ((unsigned char)(backing_node != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_32 = self->store;
    zT_33 = backing_node;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_32, zT_33);
    bnode = zT_35;
    zT_37 = bnode.span_start;
    bsp = zT_37;
    zT_39 = bnode.span_len;
    zT_41 = bsp + (unsigned int)((unsigned int)zT_39);
    bep = zT_41;
    zT_44 = self->store;
    zT_43.store = zT_44;
    zT_45 = self->registry;
    zT_43.typereg = zT_45;
    zT_46 = self->symbols;
    zT_43.symbol_reg = zT_46;
    zT_47 = self->interner;
    zT_43.interner = zT_47;
    zT_48 = self->module_id;
    zT_43.module_id = zT_48;
    zT_49 = self->diag;
    zT_50.has_value = 1;
    zT_50.value = zT_49;
    zT_43.diag = zT_50;
    zT_51.has_value = 0;
    zT_43.local_consts = zT_51;
    zT_52.has_value = 0;
    zT_43.local_types = zT_52;
    zT_53 = self->source_file_id;
    zT_43.source_file_id = zT_53;
    tre_env2 = zT_43;
    zT_55 = &tre_env2;
    zT_56 = backing_node;
    zT_60 = zF_F2107C15_resolveTypeExprFull(zT_55, zT_56, (unsigned int)(0));
    bt = zT_60;
    if ((unsigned char)(bt == (unsigned int)(18))) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    zT_153 = self->registry;
    zT_154 = check_btid;
    zT_156 = zF_655972D5_typeRegistryIntWidt(zT_153, zT_154);
    zT_157 = (unsigned int)zT_156;
    nbits = zT_157;
    zT_159 = 18446744073709551615ULL;
    maxv = zT_159;
    if ((unsigned char)(nbits < (unsigned int)(64))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    zT_63 = bt == (unsigned int)(1);
    goto z_bb_11;
    z_bb_10:
    zT_63 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_63) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_67 = "invalid enum backing type; enum(uN) requires an unsigned integer type name (u1..u64)";
    zT_69 = 84;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    bg_msg = zT_68;
    zT_70 = self->diag;
    zT_73 = self->source_file_id;
    zT_74 = bsp;
    zT_75 = bep;
    zT_76 = bg_msg;
    zT_81 = zF_C82559AC_diagnosticCollector(zT_70, (unsigned char)(0), (unsigned short)(3000), zT_73, zT_74, zT_75, zT_76);
    (void)zT_81;
    return;
    z_bb_13:
    zT_83 = self->registry;
    zT_84 = zT_83->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)bt) < zT_84)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_87 = self->registry;
    zT_88 = zT_87->types_items;
    zT_89 = (unsigned int)bt;
    zT_90 = zT_88[zT_89];
    bty = zT_90;
    zT_91 = bty.kind;
    if ((unsigned char)(zT_91 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_96 = "bool is not a valid enum backing; use an unsigned integer type (uN)";
    zT_98 = 67;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    bb_msg = zT_97;
    zT_99 = self->diag;
    zT_102 = self->source_file_id;
    zT_103 = bsp;
    zT_104 = bep;
    zT_105 = bb_msg;
    zT_110 = zF_C82559AC_diagnosticCollector(zT_99, (unsigned char)(0), (unsigned short)(3000), zT_102, zT_103, zT_104, zT_105);
    (void)zT_110;
    return;
    z_bb_17:
    zT_111 = self->registry;
    zT_112 = bt;
    zT_114 = zF_B664AC19_typeRegistryIsUnsig(zT_111, zT_112);
    if ((unsigned char)(!zT_114)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_116 = self->registry;
    zT_117 = bt;
    zT_119 = zF_01ED6537_typeRegistryIntIsSi(zT_116, zT_117);
    if (zT_119) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    check_btid = bt;
    goto z_bb_15;
    z_bb_20:
    zT_121 = "enum(iN) signed backings are not supported; use an unsigned backing (enum(uN))";
    zT_123 = 78;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    bs_msg = zT_122;
    zT_124 = self->diag;
    zT_127 = self->source_file_id;
    zT_128 = bsp;
    zT_129 = bep;
    zT_130 = bs_msg;
    zT_135 = zF_C82559AC_diagnosticCollector(zT_124, (unsigned char)(0), (unsigned short)(3000), zT_127, zT_128, zT_129, zT_130);
    (void)zT_135;
    goto z_bb_21;
    z_bb_21:
    return;
    z_bb_22:
    zT_137 = "invalid enum backing type; enum(uN) requires an unsigned integer type (uN)";
    zT_139 = 74;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    bi_msg = zT_138;
    zT_140 = self->diag;
    zT_143 = self->source_file_id;
    zT_144 = bsp;
    zT_145 = bep;
    zT_146 = bi_msg;
    zT_151 = zF_C82559AC_diagnosticCollector(zT_140, (unsigned char)(0), (unsigned short)(3000), zT_143, zT_144, zT_145, zT_146);
    (void)zT_151;
    goto z_bb_21;
    z_bb_23:
    zT_166 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)nbits)) - (zT_79FAE712_u64)(1);
    maxv = zT_166;
    goto z_bb_24;
    z_bb_24:
    zT_168 = self->registry;
    zT_169 = zT_168->en_items;
    zT_170 = ety.payload_idx;
    zT_171 = (unsigned int)zT_170;
    zT_172 = zT_169[zT_171];
    ep2 = zT_172;
    zT_174 = ep2.members_start;
    zT_175 = (unsigned int)zT_174;
    mstart2 = zT_175;
    zT_177 = ep2.members_count;
    zT_178 = (unsigned int)zT_177;
    mcount2 = zT_178;
    zT_180 = self->store;
    zT_181 = enum_node;
    zT_183 = zF_152E19CB_astStoreNodeExtraCh(zT_180, zT_181);
    children2_n = zT_183;
    zT_185 = 0;
    fcount2 = zT_185;
    zT_187 = 0;
    zT_188 = (unsigned int)zT_187;
    ci2 = zT_188;
    zT_190 = 0;
    prev_vu = zT_190;
    zT_192 = 0;
    have_prev = zT_192;
    goto z_bb_25;
    z_bb_25:
    if ((unsigned char)(ci2 < (unsigned int)((unsigned int)children2_n))) goto z_bb_29; else goto z_bb_30;
    z_bb_26:
    zT_198 = self->store;
    zT_201 = self->store;
    zT_202 = enum_node;
    zT_206 = zF_B10B1BC1_astStoreNodeExtraCh(zT_201, zT_202, (unsigned int)((unsigned int)ci2));
    zT_199 = zT_206;
    zT_207 = zF_FCDD1D35_astStoreNodeAt(zT_198, zT_199);
    fd2 = zT_207;
    zT_208 = fd2.kind;
    if ((unsigned char)(zT_208 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return;
    z_bb_28:
    zT_275 = ci2 + (unsigned int)(1);
    ci2 = zT_275;
    goto z_bb_25;
    z_bb_29:
    zT_195 = fcount2 < mcount2;
    goto z_bb_31;
    z_bb_30:
    zT_195 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_195) goto z_bb_26; else goto z_bb_27;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_213 = self->registry;
    zT_214 = zT_213->em_items;
    zT_215 = mstart2 + fcount2;
    zT_216 = zT_214[zT_215];
    zT_217 = zT_216.value;
    mv = zT_217;
    zT_219 = (zT_79FAE712_u64)mv;
    mvu = zT_219;
    if ((unsigned char)(mvu > maxv)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_222 = fd2.span_start;
    msp = zT_222;
    zT_224 = fd2.span_len;
    zT_226 = msp + (unsigned int)((unsigned int)zT_224);
    mep = zT_226;
    zT_228 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_230 = 91;
    zT_229.ptr = zT_228;
    zT_229.len = zT_230;
    mv_msg = zT_229;
    zT_231 = self->diag;
    zT_234 = self->source_file_id;
    zT_235 = msp;
    zT_236 = mep;
    zT_237 = mv_msg;
    zT_242 = zF_C82559AC_diagnosticCollector(zT_231, (unsigned char)(0), (unsigned short)(3000), zT_234, zT_235, zT_236, zT_237);
    (void)zT_242;
    return;
    z_bb_35:
    if (have_prev) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_243 = prev_vu == maxv;
    goto z_bb_38;
    z_bb_37:
    zT_243 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_243) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_246 = fd2.child_1;
    zT_245 = zT_246 == (unsigned int)(0);
    goto z_bb_41;
    z_bb_40:
    zT_245 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_245) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_250 = fd2.span_start;
    msp = zT_250;
    zT_252 = fd2.span_len;
    zT_254 = msp + (unsigned int)((unsigned int)zT_252);
    mep = zT_254;
    zT_256 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_258 = 91;
    zT_257.ptr = zT_256;
    zT_257.len = zT_258;
    mv_msg = zT_257;
    zT_259 = self->diag;
    zT_262 = self->source_file_id;
    zT_263 = msp;
    zT_264 = mep;
    zT_265 = mv_msg;
    zT_270 = zF_C82559AC_diagnosticCollector(zT_259, (unsigned char)(0), (unsigned short)(3000), zT_262, zT_263, zT_264, zT_265);
    (void)zT_270;
    return;
    z_bb_43:
    prev_vu = mvu;
    zT_271 = 1;
    have_prev = zT_271;
    zT_273 = fcount2 + (unsigned int)(1);
    fcount2 = zT_273;
    goto z_bb_28;
}

/* semanticAnalyzerCheckLocalEnum */
void zF_E3AF2BA9_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int enum_node) {
    zT_F85C5DED_DiagnosticCollector* zT_4;
    unsigned int zT_5;
    unsigned char zT_7 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_D3EB6303_StringInterner* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    zT_7234F36B_Opt_226 zT_18;
    zT_F5B966E3_Opt_396 zT_19 = {0};
    zT_03B97CED_Opt_398 zT_20 = {0};
    int zT_22;
    unsigned int zT_23;
    int zT_25;
    unsigned int zT_26;
    int zT_28;
    unsigned int zT_29;
    zT_ABC1EBBE_TypeResolveEnv* zT_30;
    unsigned int zT_31;
    unsigned int* zT_36;
    unsigned int* zT_37;
    unsigned int* zT_38;
    unsigned char zT_47 = 0;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_22A7C88B_AstNode zT_53 = {0};
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned int zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_82 = 0;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    zT_22A7C88B_AstNode fn_;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = self->diag;
    zT_5 = enum_node;
    zT_7 = zF_4DD9DB2D_diagnosticCollector(zT_4, zT_5);
    if ((unsigned char)(!zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_11 = self->store;
    zT_10.store = zT_11;
    zT_12 = self->registry;
    zT_10.typereg = zT_12;
    zT_13 = self->symbols;
    zT_10.symbol_reg = zT_13;
    zT_14 = self->interner;
    zT_10.interner = zT_14;
    zT_15 = self->module_id;
    zT_10.module_id = zT_15;
    zT_16 = self->source_file_id;
    zT_10.source_file_id = zT_16;
    zT_17 = self->diag;
    zT_18.has_value = 1;
    zT_18.value = zT_17;
    zT_10.diag = zT_18;
    zT_19.has_value = 0;
    zT_10.local_consts = zT_19;
    zT_20.has_value = 0;
    zT_10.local_types = zT_20;
    env = zT_10;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    count = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    fail_node = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    fail_kind = zT_29;
    zT_30 = &env;
    zT_31 = enum_node;
    zT_36 = &count;
    zT_37 = &fail_node;
    zT_38 = &fail_kind;
    zT_47 = zF_0FFDEDBD_enumMembersResolve(zT_30, zT_31, (unsigned char)(0), (unsigned int)(0), (unsigned char)(1), (unsigned char)(1), zT_36, zT_37, zT_38);
    if ((unsigned char)(!zT_47)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_50 = self->store;
    zT_51 = fail_node;
    zT_53 = zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    fn_ = zT_53;
    zT_55 = fn_.span_start;
    sp = zT_55;
    zT_57 = fn_.span_len;
    zT_59 = sp + (unsigned int)((unsigned int)zT_57);
    ep = zT_59;
    zT_61 = "enum member value is not a comptime-known integer expression";
    zT_63 = 60;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    msg = zT_62;
    if ((unsigned char)(fail_kind == (unsigned int)(2))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_66 = "duplicate enum tag value (tag values must be unique)";
    zT_68 = 52;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    msg = zT_67;
    goto z_bb_8;
    z_bb_8:
    zT_69 = self->diag;
    zT_72 = self->source_file_id;
    zT_73 = sp;
    zT_74 = ep;
    zT_75 = msg;
    zT_82 = zF_C82559AC_diagnosticCollector(zT_69, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3055_ENUM_VALUE_NOT_CONSTANT)), zT_72, zT_73, zT_74, zT_75);
    (void)zT_82;
    goto z_bb_6;
}

/* semanticAnalyzerPackedStructDeclForType */
unsigned int zF_1BB4D489_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_43;
    unsigned int zT_44;
    zT_3D7259E2_SymbolRegistry* zT_47;
    zT_060CD1EB_SymbolTable* zT_48;
    zT_060CD1EB_SymbolTable zT_49;
    int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_3A105EF1_Symbol* zT_56;
    zT_3A105EF1_Symbol zT_57;
    zT_3C598AEF_SymbolKind zT_58;
    unsigned int zT_62;
    unsigned char zT_64;
    unsigned int zT_65;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    zT_22A7C88B_AstNode zT_73 = {0};
    unsigned int zT_75;
    zT_8143F551_AstKind zT_76;
    unsigned int zT_80;
    zT_8143F551_AstKind zT_81;
    unsigned char zT_85;
    unsigned int zT_86;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    zT_22A7C88B_AstNode zT_94 = {0};
    zT_8143F551_AstKind zT_95;
    unsigned int zT_99;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    zT_22A7C88B_AstNode zT_106 = {0};
    unsigned char zT_107;
    zT_38C12417_SemanticAnalyzer* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned int zT_118;
    zT_38C12417_SemanticAnalyzer* zT_119;
    unsigned int zT_120;
    unsigned int hc;
    unsigned int cc;
    zT_D155D06D_Type sty;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol s;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    zT_22A7C88B_AstNode inn;
    zT_22A7C88B_AstNode tnode;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    hc = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_struct_cache_len;
    if ((unsigned char)(hc < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = zT_7[hc];
    if ((unsigned char)(zT_8 == struct_tid)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    cc = zT_16;
    goto z_bb_7;
    z_bb_4:
    zT_13 = hc + (unsigned int)(1);
    hc = zT_13;
    goto z_bb_1;
    z_bb_5:
    zT_10 = self->packed_struct_decl_nodes;
    zT_11 = zT_10[hc];
    return zT_11;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_17 = self->checked_struct_tids_len;
    if ((unsigned char)(cc < zT_17)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_19 = self->checked_struct_tids;
    zT_20 = zT_19[cc];
    if ((unsigned char)(zT_20 == struct_tid)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_26 = self->registry;
    zT_27 = zT_26->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)struct_tid) >= zT_27)) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_24 = cc + (unsigned int)(1);
    cc = zT_24;
    goto z_bb_7;
    z_bb_11:
    return (unsigned int)(0);
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    return (unsigned int)(0);
    z_bb_14:
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)struct_tid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_35 = sty.kind;
    if ((unsigned char)(zT_35 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned int)(0);
    z_bb_16:
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ti = zT_42;
    goto z_bb_17;
    z_bb_17:
    zT_43 = self->symbols;
    zT_44 = zT_43->tables_len;
    if ((unsigned char)(ti < zT_44)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_47 = self->symbols;
    zT_48 = zT_47->tables_items;
    zT_49 = zT_48[ti];
    table = zT_49;
    zT_51 = 0;
    zT_52 = (unsigned int)zT_51;
    si = zT_52;
    goto z_bb_21;
    z_bb_19:
    zT_119 = self;
    zT_120 = struct_tid;
    zF_B5A1E8BB_semanticAnalyzerChe(zT_119, zT_120);
    return (unsigned int)(0);
    z_bb_20:
    zT_118 = ti + (unsigned int)(1);
    ti = zT_118;
    goto z_bb_17;
    z_bb_21:
    zT_53 = table.len;
    if ((unsigned char)(si < zT_53)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_56 = table.items;
    zT_57 = zT_56[si];
    s = zT_57;
    zT_58 = s.kind;
    if ((unsigned char)(zT_58 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_116 = si + (unsigned int)(1);
    si = zT_116;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_62 = s.type_id;
    if ((unsigned char)(zT_62 != struct_tid)) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_65 = s.decl_node;
    zT_64 = zT_65 == (unsigned int)(0);
    goto z_bb_29;
    z_bb_28:
    zT_64 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_64) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    goto z_bb_24;
    z_bb_31:
    zT_69 = self->store;
    zT_70 = s.decl_node;
    zT_73 = zF_FCDD1D35_astStoreNodeAt(zT_69, zT_70);
    dnode = zT_73;
    zT_75 = 0;
    target = zT_75;
    zT_76 = dnode.kind;
    if ((unsigned char)(zT_76 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_80 = s.decl_node;
    target = zT_80;
    goto z_bb_33;
    z_bb_33:
    if ((unsigned char)(target == (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_34:
    zT_81 = dnode.kind;
    if ((unsigned char)(zT_81 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_86 = dnode.child_1;
    zT_85 = zT_86 != (unsigned int)(0);
    goto z_bb_37;
    z_bb_36:
    zT_85 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_85) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_90 = self->store;
    zT_91 = dnode.child_1;
    zT_94 = zF_FCDD1D35_astStoreNodeAt(zT_90, zT_91);
    inn = zT_94;
    zT_95 = inn.kind;
    if ((unsigned char)(zT_95 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_33;
    z_bb_40:
    zT_99 = dnode.child_1;
    target = zT_99;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    goto z_bb_24;
    z_bb_43:
    zT_103 = self->store;
    zT_104 = target;
    zT_106 = zF_FCDD1D35_astStoreNodeAt(zT_103, zT_104);
    tnode = zT_106;
    zT_107 = tnode.flags;
    if ((unsigned char)((unsigned char)(zT_107 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_112 = self;
    zT_113 = struct_tid;
    zT_114 = target;
    zF_2C47D4E0_semanticAnalyzerPac(zT_112, zT_113, zT_114);
    return target;
    z_bb_45:
    goto z_bb_24;
}

/* semanticAnalyzerResolveArithmetic */
unsigned int zF_44006DDD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    zT_38C12417_SemanticAnalyzer* zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    unsigned char zT_20;
    unsigned char zT_27;
    zT_338B7C76_TypeRegistry* zT_32;
    unsigned int zT_33;
    unsigned char zT_35 = 0;
    unsigned char zT_36;
    zT_338B7C76_TypeRegistry* zT_37;
    unsigned int zT_38;
    unsigned char zT_40 = 0;
    zT_338B7C76_TypeRegistry* zT_42;
    unsigned int zT_43;
    unsigned char zT_45 = 0;
    unsigned char zT_46;
    zT_338B7C76_TypeRegistry* zT_50;
    unsigned int zT_51;
    unsigned char zT_53 = 0;
    unsigned char zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    unsigned int zT_56;
    unsigned char zT_58 = 0;
    unsigned char zT_59;
    unsigned char zT_63;
    zT_338B7C76_TypeRegistry* zT_64;
    unsigned int zT_65;
    unsigned char zT_67 = 0;
    unsigned char zT_68;
    unsigned char zT_71;
    unsigned char zT_75;
    unsigned char zT_76;
    unsigned char zT_80;
    zT_338B7C76_TypeRegistry* zT_81;
    unsigned int zT_82;
    unsigned char zT_84 = 0;
    unsigned char zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    unsigned int zT_89;
    unsigned char zT_91 = 0;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    unsigned char zT_95 = 0;
    unsigned char zT_97;
    zT_338B7C76_TypeRegistry* zT_98;
    unsigned int zT_99;
    unsigned char zT_101 = 0;
    zT_338B7C76_TypeRegistry* zT_105;
    unsigned int zT_106;
    unsigned char zT_108 = 0;
    unsigned char zT_109;
    zT_338B7C76_TypeRegistry* zT_110;
    unsigned int zT_111;
    unsigned char zT_113 = 0;
    zT_338B7C76_TypeRegistry* zT_115;
    unsigned int zT_116;
    unsigned char zT_118 = 0;
    zT_338B7C76_TypeRegistry* zT_120;
    unsigned int zT_121;
    unsigned char zT_123 = 0;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_D155D06D_Type* zT_127;
    unsigned int zT_128;
    zT_D155D06D_Type zT_129;
    unsigned int zT_130;
    zT_338B7C76_TypeRegistry* zT_132;
    zT_D155D06D_Type* zT_133;
    unsigned int zT_134;
    zT_D155D06D_Type zT_135;
    unsigned int zT_136;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    unsigned char lhs_ptr;
    unsigned char rhs_uint;
    unsigned char rhs_ptr;
    unsigned char lw;
    unsigned char rw;
    unsigned int ls;
    unsigned int rs;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    lhs = zT_12;
    zT_14 = self;
    zT_15 = node.child_1;
    zT_17 = zF_54F95822_semanticAnalyzerRes(zT_14, zT_15);
    rhs = zT_17;
    if ((unsigned char)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_20 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_20 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_20) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_27 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_8;
    z_bb_7:
    zT_27 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = self->registry;
    zT_33 = lhs;
    zT_35 = zF_AD61DB1B_typeRegistryIsPoint(zT_32, zT_33);
    if (zT_35) goto z_bb_12; else goto z_bb_11;
    z_bb_10:
    if ((unsigned char)(lhs == (unsigned int)(19))) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_37 = self->registry;
    zT_38 = lhs;
    zT_40 = zF_0F4CC580_typeRegistryIsSlice(zT_37, zT_38);
    zT_36 = zT_40;
    goto z_bb_13;
    z_bb_12:
    zT_36 = 1;
    goto z_bb_13;
    z_bb_13:
    lhs_ptr = zT_36;
    zT_42 = self->registry;
    zT_43 = rhs;
    zT_45 = zF_B664AC19_typeRegistryIsUnsig(zT_42, zT_43);
    if (zT_45) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_46 = rhs == (unsigned int)(19);
    goto z_bb_16;
    z_bb_15:
    zT_46 = 1;
    goto z_bb_16;
    z_bb_16:
    rhs_uint = zT_46;
    zT_50 = self->registry;
    zT_51 = rhs;
    zT_53 = zF_AD61DB1B_typeRegistryIsPoint(zT_50, zT_51);
    if (zT_53) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_55 = self->registry;
    zT_56 = rhs;
    zT_58 = zF_0F4CC580_typeRegistryIsSlice(zT_55, zT_56);
    zT_54 = zT_58;
    goto z_bb_19;
    z_bb_18:
    zT_54 = 1;
    goto z_bb_19;
    z_bb_19:
    rhs_ptr = zT_54;
    if (lhs_ptr) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_59 = rhs_uint;
    goto z_bb_22;
    z_bb_21:
    zT_59 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_59) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return lhs;
    z_bb_24:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_64 = self->registry;
    zT_65 = lhs;
    zT_67 = zF_B664AC19_typeRegistryIsUnsig(zT_64, zT_65);
    if (zT_67) goto z_bb_29; else goto z_bb_28;
    z_bb_26:
    zT_63 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_63) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_68 = lhs == (unsigned int)(19);
    goto z_bb_30;
    z_bb_29:
    zT_68 = 1;
    goto z_bb_30;
    z_bb_30:
    zT_63 = zT_68;
    goto z_bb_27;
    z_bb_31:
    zT_71 = rhs_ptr;
    goto z_bb_33;
    z_bb_32:
    zT_71 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_71) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return rhs;
    z_bb_35:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_75 = lhs_ptr;
    goto z_bb_38;
    z_bb_37:
    zT_75 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_75) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_76 = rhs_ptr;
    goto z_bb_41;
    z_bb_40:
    zT_76 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_76) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (unsigned int)(12);
    z_bb_43:
    goto z_bb_10;
    z_bb_44:
    zT_81 = self->registry;
    zT_82 = rhs;
    zT_84 = zF_3087E0A5_typeRegistryIsNumer(zT_81, zT_82);
    zT_80 = zT_84;
    goto z_bb_46;
    z_bb_45:
    zT_80 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_80) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return rhs;
    z_bb_48:
    if ((unsigned char)(rhs == (unsigned int)(19))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_88 = self->registry;
    zT_89 = lhs;
    zT_91 = zF_3087E0A5_typeRegistryIsNumer(zT_88, zT_89);
    zT_87 = zT_91;
    goto z_bb_51;
    z_bb_50:
    zT_87 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_87) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    return lhs;
    z_bb_53:
    zT_92 = self->registry;
    zT_93 = lhs;
    zT_95 = zF_3087E0A5_typeRegistryIsNumer(zT_92, zT_93);
    if ((unsigned char)(!zT_95)) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_98 = self->registry;
    zT_99 = rhs;
    zT_101 = zF_3087E0A5_typeRegistryIsNumer(zT_98, zT_99);
    zT_97 = !zT_101;
    goto z_bb_56;
    z_bb_55:
    zT_97 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_97) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned int)(1);
    z_bb_58:
    if ((unsigned char)(lhs == rhs)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return lhs;
    z_bb_60:
    zT_105 = self->registry;
    zT_106 = lhs;
    zT_108 = zF_3290E9C4_typeRegistryIsInteg(zT_105, zT_106);
    if (zT_108) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_110 = self->registry;
    zT_111 = rhs;
    zT_113 = zF_3290E9C4_typeRegistryIsInteg(zT_110, zT_111);
    zT_109 = zT_113;
    goto z_bb_63;
    z_bb_62:
    zT_109 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_109) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_115 = self->registry;
    zT_116 = lhs;
    zT_118 = zF_655972D5_typeRegistryIntWidt(zT_115, zT_116);
    lw = zT_118;
    zT_120 = self->registry;
    zT_121 = rhs;
    zT_123 = zF_655972D5_typeRegistryIntWidt(zT_120, zT_121);
    rw = zT_123;
    if ((unsigned char)(lw >= rw)) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    zT_126 = self->registry;
    zT_127 = zT_126->types_items;
    zT_128 = (unsigned int)lhs;
    zT_129 = zT_127[zT_128];
    zT_130 = zT_129.size;
    ls = zT_130;
    zT_132 = self->registry;
    zT_133 = zT_132->types_items;
    zT_134 = (unsigned int)rhs;
    zT_135 = zT_133[zT_134];
    zT_136 = zT_135.size;
    rs = zT_136;
    if ((unsigned char)(ls >= rs)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    return lhs;
    z_bb_67:
    return rhs;
    z_bb_68:
    return lhs;
    z_bb_69:
    return rhs;
}

/* semanticAnalyzerResolveBitwise */
unsigned int zF_733BCA9C_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned char zT_19;
    unsigned char zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    unsigned char zT_29 = 0;
    unsigned char zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    unsigned char zT_36 = 0;
    unsigned char zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    unsigned char zT_42 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    lhs = zT_11;
    zT_13 = self;
    zT_14 = node.child_1;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    rhs = zT_16;
    if ((unsigned char)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_19 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_19 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((unsigned char)(lhs == (unsigned int)(19))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_26 = self->registry;
    zT_27 = rhs;
    zT_29 = zF_3290E9C4_typeRegistryIsInteg(zT_26, zT_27);
    zT_25 = zT_29;
    goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_25) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return rhs;
    z_bb_10:
    if ((unsigned char)(rhs == (unsigned int)(19))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->registry;
    zT_34 = lhs;
    zT_36 = zF_3290E9C4_typeRegistryIsInteg(zT_33, zT_34);
    zT_32 = zT_36;
    goto z_bb_13;
    z_bb_12:
    zT_32 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_32) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return lhs;
    z_bb_15:
    if ((unsigned char)(lhs != rhs)) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_39 = self->registry;
    zT_40 = lhs;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_39, zT_40);
    zT_38 = !zT_42;
    goto z_bb_18;
    z_bb_17:
    zT_38 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_38) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned int)(1);
    z_bb_20:
    return lhs;
}

/* semanticAnalyzerResolveComparison */
unsigned int zF_EB621FF0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_24 = {0};
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    unsigned char zT_36;
    zT_8143F551_AstKind zT_37;
    unsigned char zT_41;
    zT_8143F551_AstKind zT_45;
    unsigned char zT_49;
    zT_8143F551_AstKind zT_50;
    unsigned char zT_54;
    unsigned char zT_59;
    zT_38C12417_SemanticAnalyzer* zT_62;
    unsigned int zT_63;
    unsigned int zT_65 = 0;
    int zT_67;
    unsigned int zT_68;
    int zT_69;
    unsigned char zT_71;
    unsigned char zT_74;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_D155D06D_Type* zT_78;
    unsigned int zT_79;
    zT_D155D06D_Type zT_80;
    zT_33EF6BFB_TypeKind zT_81;
    unsigned int zT_82;
    zT_8143F551_AstKind zT_83;
    unsigned char zT_87;
    unsigned char zT_91;
    zT_8143F551_AstKind zT_92;
    unsigned char zT_96;
    zT_38C12417_SemanticAnalyzer* zT_100;
    unsigned int zT_101;
    zT_38C12417_SemanticAnalyzer* zT_102;
    unsigned int zT_103;
    unsigned int zT_105 = 0;
    zT_38C12417_SemanticAnalyzer* zT_106;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_108;
    unsigned int zT_110 = 0;
    unsigned char zT_113;
    zT_38C12417_SemanticAnalyzer* zT_116;
    unsigned int zT_117;
    unsigned int zT_119 = 0;
    int zT_121;
    unsigned int zT_122;
    int zT_123;
    unsigned char zT_125;
    unsigned char zT_128;
    zT_338B7C76_TypeRegistry* zT_131;
    zT_D155D06D_Type* zT_132;
    unsigned int zT_133;
    zT_D155D06D_Type zT_134;
    zT_33EF6BFB_TypeKind zT_135;
    unsigned int zT_136;
    zT_8143F551_AstKind zT_137;
    unsigned char zT_141;
    unsigned char zT_145;
    zT_8143F551_AstKind zT_146;
    unsigned char zT_150;
    zT_38C12417_SemanticAnalyzer* zT_154;
    unsigned int zT_155;
    zT_38C12417_SemanticAnalyzer* zT_156;
    unsigned int zT_157;
    unsigned int zT_159 = 0;
    zT_38C12417_SemanticAnalyzer* zT_160;
    zT_38C12417_SemanticAnalyzer* zT_161;
    unsigned int zT_162;
    unsigned int zT_164 = 0;
    zT_38C12417_SemanticAnalyzer* zT_165;
    unsigned int zT_166;
    unsigned int zT_168 = 0;
    zT_38C12417_SemanticAnalyzer* zT_169;
    unsigned int zT_170;
    unsigned int zT_172 = 0;
    unsigned char zT_175;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned char zT_186;
    zT_338B7C76_TypeRegistry* zT_187;
    unsigned int zT_188;
    unsigned char zT_190 = 0;
    unsigned char* zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned char zT_199;
    zT_338B7C76_TypeRegistry* zT_200;
    unsigned int zT_201;
    unsigned char zT_203 = 0;
    unsigned char* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    zT_338B7C76_TypeRegistry* zT_211;
    unsigned int zT_212;
    unsigned char zT_214 = 0;
    unsigned char zT_215;
    unsigned char* zT_218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    unsigned int zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned char zT_226;
    zT_338B7C76_TypeRegistry* zT_230;
    unsigned int zT_231;
    unsigned char zT_233 = 0;
    unsigned char zT_234;
    zT_338B7C76_TypeRegistry* zT_238;
    unsigned int zT_239;
    unsigned char zT_241 = 0;
    unsigned char zT_242;
    zT_338B7C76_TypeRegistry* zT_246;
    unsigned int zT_247;
    unsigned char zT_249 = 0;
    unsigned char zT_250;
    zT_338B7C76_TypeRegistry* zT_251;
    unsigned int zT_252;
    unsigned char zT_254 = 0;
    unsigned char* zT_256;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_257;
    unsigned int zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    zT_338B7C76_TypeRegistry* zT_270;
    unsigned int zT_271;
    unsigned char zT_273 = 0;
    unsigned char* zT_275;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_276;
    unsigned int zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    zT_338B7C76_TypeRegistry* zT_281;
    zT_D155D06D_Type* zT_282;
    unsigned int zT_283;
    zT_D155D06D_Type zT_284;
    zT_33EF6BFB_TypeKind zT_285;
    unsigned char* zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned char* zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_301;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    int zT_307;
    unsigned char* zT_308;
    unsigned int zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    unsigned int zT_311 = 0;
    unsigned int zT_315;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    unsigned char* zT_320;
    unsigned int zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned char* zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_329;
    unsigned int zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    int zT_335;
    unsigned char* zT_336;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned int zT_339 = 0;
    unsigned int zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned char* zT_348;
    unsigned int zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned char* zT_352;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_353;
    unsigned int zT_354;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_355;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_357;
    unsigned int zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    int zT_364;
    unsigned char* zT_365;
    unsigned int zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    unsigned int zT_368 = 0;
    unsigned int zT_372;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_373;
    unsigned char* zT_377;
    unsigned int zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned char* zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_382;
    unsigned int zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_22A7C88B_AstNode c0n;
    zT_22A7C88B_AstNode c1n;
    unsigned char c0_lit;
    unsigned char c1_lit;
    unsigned int peerk;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp0;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp2;
    unsigned char lhs_num;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp3;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp4;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_lb;
    unsigned int cpv_ll;
    unsigned int cpv_ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_rh;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_rb;
    unsigned int cpv_rl;
    unsigned int cpv_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_ih;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_ib;
    unsigned int cpv_il;
    unsigned int cpv_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp5;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp6;
    zT_33EF6BFB_TypeKind lk;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp7;
    zT_4 = "CPE";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    cpe = zT_5;
    zT_7 = cpe;
    zF_48AC7B3A_markerWrite(zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    lhs = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    rhs = zT_18;
    zT_20 = self->store;
    zT_21 = node.child_0;
    zT_24 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    c0n = zT_24;
    zT_26 = self->store;
    zT_27 = node.child_1;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    c1n = zT_30;
    zT_32 = c0n.kind;
    if ((unsigned char)(zT_32 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_37 = c0n.kind;
    zT_36 = zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_3;
    z_bb_2:
    zT_36 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_36) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_41 = 1;
    goto z_bb_6;
    z_bb_5:
    zT_41 = 0;
    goto z_bb_6;
    z_bb_6:
    c0_lit = zT_41;
    zT_45 = c1n.kind;
    if ((unsigned char)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_50 = c1n.kind;
    zT_49 = zT_50 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_9;
    z_bb_8:
    zT_49 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_49) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_54 = 1;
    goto z_bb_12;
    z_bb_11:
    zT_54 = 0;
    goto z_bb_12;
    z_bb_12:
    c1_lit = zT_54;
    if ((unsigned char)(c0_lit == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_59 = c1_lit != (unsigned char)(0);
    goto z_bb_15;
    z_bb_14:
    zT_59 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_59) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_62 = self;
    zT_63 = node.child_0;
    zT_65 = zF_54F95822_semanticAnalyzerRes(zT_62, zT_63);
    lhs = zT_65;
    zT_67 = 0;
    zT_68 = (unsigned int)zT_67;
    peerk = zT_68;
    zT_69 = 0;
    if ((unsigned char)(lhs != (unsigned int)zT_69)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    if ((unsigned char)(lhs == (unsigned int)(0))) goto z_bb_66; else goto z_bb_65;
    z_bb_18:
    if ((unsigned char)(c0_lit != (unsigned char)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_19:
    zT_71 = lhs != (unsigned int)(1);
    goto z_bb_21;
    z_bb_20:
    zT_71 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_71) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_74 = lhs != (unsigned int)(18);
    goto z_bb_24;
    z_bb_23:
    zT_74 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_74) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_77 = self->registry;
    zT_78 = zT_77->types_items;
    zT_79 = (unsigned int)lhs;
    zT_80 = zT_78[zT_79];
    zT_81 = zT_80.kind;
    zT_82 = (unsigned int)zT_81;
    peerk = zT_82;
    goto z_bb_26;
    z_bb_26:
    zT_83 = c1n.kind;
    if ((unsigned char)(zT_83 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_87 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_29;
    z_bb_28:
    zT_87 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_87) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_92 = c1n.kind;
    if ((unsigned char)(zT_92 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_91 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_91) goto z_bb_36; else goto z_bb_38;
    z_bb_33:
    zT_96 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_35;
    z_bb_34:
    zT_96 = 0;
    goto z_bb_35;
    z_bb_35:
    zT_91 = zT_96;
    goto z_bb_32;
    z_bb_36:
    zT_100 = self;
    zT_101 = lhs;
    zF_9665A229_pushExpectedType(zT_100, zT_101);
    zT_102 = self;
    zT_103 = node.child_1;
    zT_105 = zF_54F95822_semanticAnalyzerRes(zT_102, zT_103);
    rhs = zT_105;
    zT_106 = self;
    zF_BC478E78_popExpectedType(zT_106);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_17;
    z_bb_38:
    zT_107 = self;
    zT_108 = node.child_1;
    zT_110 = zF_54F95822_semanticAnalyzerRes(zT_107, zT_108);
    rhs = zT_110;
    goto z_bb_37;
    z_bb_39:
    zT_113 = c1_lit == (unsigned char)(0);
    goto z_bb_41;
    z_bb_40:
    zT_113 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_113) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_116 = self;
    zT_117 = node.child_1;
    zT_119 = zF_54F95822_semanticAnalyzerRes(zT_116, zT_117);
    rhs = zT_119;
    zT_121 = 0;
    zT_122 = (unsigned int)zT_121;
    peerk = zT_122;
    zT_123 = 0;
    if ((unsigned char)(rhs != (unsigned int)zT_123)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_17;
    z_bb_44:
    zT_165 = self;
    zT_166 = node.child_0;
    zT_168 = zF_54F95822_semanticAnalyzerRes(zT_165, zT_166);
    lhs = zT_168;
    zT_169 = self;
    zT_170 = node.child_1;
    zT_172 = zF_54F95822_semanticAnalyzerRes(zT_169, zT_170);
    rhs = zT_172;
    goto z_bb_43;
    z_bb_45:
    zT_125 = rhs != (unsigned int)(1);
    goto z_bb_47;
    z_bb_46:
    zT_125 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_125) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_128 = rhs != (unsigned int)(18);
    goto z_bb_50;
    z_bb_49:
    zT_128 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_128) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_131 = self->registry;
    zT_132 = zT_131->types_items;
    zT_133 = (unsigned int)rhs;
    zT_134 = zT_132[zT_133];
    zT_135 = zT_134.kind;
    zT_136 = (unsigned int)zT_135;
    peerk = zT_136;
    goto z_bb_52;
    z_bb_52:
    zT_137 = c0n.kind;
    if ((unsigned char)(zT_137 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_141 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_55;
    z_bb_54:
    zT_141 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_141) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_146 = c0n.kind;
    if ((unsigned char)(zT_146 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_145 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_145) goto z_bb_62; else goto z_bb_64;
    z_bb_59:
    zT_150 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_61;
    z_bb_60:
    zT_150 = 0;
    goto z_bb_61;
    z_bb_61:
    zT_145 = zT_150;
    goto z_bb_58;
    z_bb_62:
    zT_154 = self;
    zT_155 = rhs;
    zF_9665A229_pushExpectedType(zT_154, zT_155);
    zT_156 = self;
    zT_157 = node.child_0;
    zT_159 = zF_54F95822_semanticAnalyzerRes(zT_156, zT_157);
    lhs = zT_159;
    zT_160 = self;
    zF_BC478E78_popExpectedType(zT_160);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_43;
    z_bb_64:
    zT_161 = self;
    zT_162 = node.child_0;
    zT_164 = zF_54F95822_semanticAnalyzerRes(zT_161, zT_162);
    lhs = zT_164;
    goto z_bb_63;
    z_bb_65:
    zT_175 = rhs == (unsigned int)(0);
    goto z_bb_67;
    z_bb_66:
    zT_175 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_175) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_179 = "CP0";
    zT_181 = 3;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    cp0 = zT_180;
    zT_182 = cp0;
    zF_48AC7B3A_markerWrite(zT_182);
    return (unsigned int)(1);
    z_bb_69:
    if ((unsigned char)(lhs == (unsigned int)(19))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_187 = self->registry;
    zT_188 = rhs;
    zT_190 = zF_3087E0A5_typeRegistryIsNumer(zT_187, zT_188);
    zT_186 = zT_190;
    goto z_bb_72;
    z_bb_71:
    zT_186 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_186) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_192 = "CPB";
    zT_194 = 3;
    zT_193.ptr = zT_192;
    zT_193.len = zT_194;
    cp1 = zT_193;
    zT_195 = cp1;
    zF_48AC7B3A_markerWrite(zT_195);
    return (unsigned int)(2);
    z_bb_74:
    if ((unsigned char)(rhs == (unsigned int)(19))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_200 = self->registry;
    zT_201 = lhs;
    zT_203 = zF_3087E0A5_typeRegistryIsNumer(zT_200, zT_201);
    zT_199 = zT_203;
    goto z_bb_77;
    z_bb_76:
    zT_199 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_199) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_205 = "CPB";
    zT_207 = 3;
    zT_206.ptr = zT_205;
    zT_206.len = zT_207;
    cp2 = zT_206;
    zT_208 = cp2;
    zF_48AC7B3A_markerWrite(zT_208);
    return (unsigned int)(2);
    z_bb_79:
    zT_211 = self->registry;
    zT_212 = lhs;
    zT_214 = zF_3087E0A5_typeRegistryIsNumer(zT_211, zT_212);
    lhs_num = zT_214;
    if (lhs_num) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_215 = lhs == rhs;
    goto z_bb_82;
    z_bb_81:
    zT_215 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_215) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_218 = "CPB";
    zT_220 = 3;
    zT_219.ptr = zT_218;
    zT_219.len = zT_220;
    cp3 = zT_219;
    zT_221 = cp3;
    zF_48AC7B3A_markerWrite(zT_221);
    return (unsigned int)(2);
    z_bb_84:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_226 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_87;
    z_bb_86:
    zT_226 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_226) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_230 = self->registry;
    zT_231 = lhs;
    zT_233 = zF_DA6AF452_typeRegistryIsOptio(zT_230, zT_231);
    if (zT_233) goto z_bb_90; else goto z_bb_91;
    z_bb_89:
    if ((unsigned char)(lhs == rhs)) goto z_bb_105; else goto z_bb_106;
    z_bb_90:
    zT_234 = rhs == (unsigned int)(17);
    goto z_bb_92;
    z_bb_91:
    zT_234 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_234) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned int)(2);
    z_bb_94:
    zT_238 = self->registry;
    zT_239 = rhs;
    zT_241 = zF_DA6AF452_typeRegistryIsOptio(zT_238, zT_239);
    if (zT_241) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_242 = lhs == (unsigned int)(17);
    goto z_bb_97;
    z_bb_96:
    zT_242 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_242) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    return (unsigned int)(2);
    z_bb_99:
    zT_246 = self->registry;
    zT_247 = lhs;
    zT_249 = zF_B8767394_typeRegistryIsError(zT_246, zT_247);
    if (zT_249) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_251 = self->registry;
    zT_252 = rhs;
    zT_254 = zF_B8767394_typeRegistryIsError(zT_251, zT_252);
    zT_250 = zT_254;
    goto z_bb_102;
    z_bb_101:
    zT_250 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_250) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_256 = "CPB";
    zT_258 = 3;
    zT_257.ptr = zT_256;
    zT_257.len = zT_258;
    cp4 = zT_257;
    zT_259 = cp4;
    zF_48AC7B3A_markerWrite(zT_259);
    return (unsigned int)(2);
    z_bb_104:
    goto z_bb_89;
    z_bb_105:
    if ((unsigned char)(lhs == (unsigned int)(2))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_296 = "CPVl";
    zT_298 = 4;
    zT_297.ptr = zT_296;
    zT_297.len = zT_298;
    cpv = zT_297;
    zT_299 = cpv;
    zF_48AC7B3A_markerWrite(zT_299);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_301[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_lb[_i] = zT_301[_i];
        _i++;
    }
}
    zT_303 = lhs;
    zT_307 = 0;
    zT_308 = (unsigned char*)((unsigned char*)cpv_lb) + zT_307;
    zT_309 = (unsigned int)(10) - zT_307;
    zT_310.ptr = zT_308;
    zT_310.len = zT_309;
    zT_304 = zT_310;
    zT_311 = zF_A7504564_itoa(zT_303, zT_304);
    cpv_ll = zT_311;
    zT_315 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_ll);
    cpv_ls = zT_315;
    zT_320 = (unsigned char*)((unsigned char*)cpv_lb) + cpv_ls;
    zT_321 = (unsigned int)(9) - cpv_ls;
    zT_322.ptr = zT_320;
    zT_322.len = zT_321;
    zT_316 = zT_322;
    zF_48AC7B3A_markerWrite(zT_316);
    zT_324 = "r";
    zT_326 = 1;
    zT_325.ptr = zT_324;
    zT_325.len = zT_326;
    cpv_rh = zT_325;
    zT_327 = cpv_rh;
    zF_48AC7B3A_markerWrite(zT_327);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_329[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_rb[_i] = zT_329[_i];
        _i++;
    }
}
    zT_331 = rhs;
    zT_335 = 0;
    zT_336 = (unsigned char*)((unsigned char*)cpv_rb) + zT_335;
    zT_337 = (unsigned int)(10) - zT_335;
    zT_338.ptr = zT_336;
    zT_338.len = zT_337;
    zT_332 = zT_338;
    zT_339 = zF_A7504564_itoa(zT_331, zT_332);
    cpv_rl = zT_339;
    zT_343 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_rl);
    cpv_rs = zT_343;
    zT_348 = (unsigned char*)((unsigned char*)cpv_rb) + cpv_rs;
    zT_349 = (unsigned int)(9) - cpv_rs;
    zT_350.ptr = zT_348;
    zT_350.len = zT_349;
    zT_344 = zT_350;
    zF_48AC7B3A_markerWrite(zT_344);
    zT_352 = "n";
    zT_354 = 1;
    zT_353.ptr = zT_352;
    zT_353.len = zT_354;
    cpv_ih = zT_353;
    zT_355 = cpv_ih;
    zF_48AC7B3A_markerWrite(zT_355);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_357[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_ib[_i] = zT_357[_i];
        _i++;
    }
}
    zT_359 = node.child_0;
    zT_364 = 0;
    zT_365 = (unsigned char*)((unsigned char*)cpv_ib) + zT_364;
    zT_366 = (unsigned int)(10) - zT_364;
    zT_367.ptr = zT_365;
    zT_367.len = zT_366;
    zT_360 = zT_367;
    zT_368 = zF_A7504564_itoa(zT_359, zT_360);
    cpv_il = zT_368;
    zT_372 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_il);
    cpv_is = zT_372;
    zT_377 = (unsigned char*)((unsigned char*)cpv_ib) + cpv_is;
    zT_378 = (unsigned int)(9) - cpv_is;
    zT_379.ptr = zT_377;
    zT_379.len = zT_378;
    zT_373 = zT_379;
    zF_48AC7B3A_markerWrite(zT_373);
    zT_381 = "\n";
    zT_383 = 1;
    zT_382.ptr = zT_381;
    zT_382.len = zT_383;
    cpv_nl = zT_382;
    zT_384 = cpv_nl;
    zF_48AC7B3A_markerWrite(zT_384);
    return (unsigned int)(1);
    z_bb_107:
    zT_265 = "CPB";
    zT_267 = 3;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    cp5 = zT_266;
    zT_268 = cp5;
    zF_48AC7B3A_markerWrite(zT_268);
    return (unsigned int)(2);
    z_bb_108:
    zT_270 = self->registry;
    zT_271 = lhs;
    zT_273 = zF_AD61DB1B_typeRegistryIsPoint(zT_270, zT_271);
    if (zT_273) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_275 = "CPB";
    zT_277 = 3;
    zT_276.ptr = zT_275;
    zT_276.len = zT_277;
    cp6 = zT_276;
    zT_278 = cp6;
    zF_48AC7B3A_markerWrite(zT_278);
    return (unsigned int)(2);
    z_bb_110:
    zT_281 = self->registry;
    zT_282 = zT_281->types_items;
    zT_283 = (unsigned int)lhs;
    zT_284 = zT_282[zT_283];
    zT_285 = zT_284.kind;
    lk = zT_285;
    if ((unsigned char)(lk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_290 = "CPB";
    zT_292 = 3;
    zT_291.ptr = zT_290;
    zT_291.len = zT_292;
    cp7 = zT_291;
    zT_293 = cp7;
    zF_48AC7B3A_markerWrite(zT_293);
    return (unsigned int)(2);
    z_bb_112:
    goto z_bb_106;
}

/* semanticAnalyzerResolveLogical */
unsigned int zF_6F2B8B98_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    unsigned char zT_24;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u loe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo2;
    zT_3 = "LOE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    loe = zT_4;
    zT_6 = loe;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_18 = self;
    zT_19 = node.child_1;
    zT_21 = zF_54F95822_semanticAnalyzerRes(zT_18, zT_19);
    rhs = zT_21;
    if ((unsigned char)(lhs == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_24 = rhs == (unsigned int)(2);
    goto z_bb_3;
    z_bb_2:
    zT_24 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_24) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_28 = "LOB";
    zT_30 = 3;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    lo1 = zT_29;
    zT_31 = lo1;
    zF_48AC7B3A_markerWrite(zT_31);
    return (unsigned int)(2);
    z_bb_5:
    zT_34 = "LOV";
    zT_36 = 3;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    lo2 = zT_35;
    zT_37 = lo2;
    zF_48AC7B3A_markerWrite(zT_37);
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveNegate */
unsigned int zF_09421FDF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    unsigned char zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((unsigned char)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((unsigned char)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3087E0A5_typeRegistryIsNumer(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveBitNot */
unsigned int zF_6B59E8AD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    unsigned char zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((unsigned char)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((unsigned char)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3290E9C4_typeRegistryIsInteg(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerVolatileDrop */
unsigned char zF_57090266_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    unsigned char zT_5;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    unsigned char zT_37;
    zT_33EF6BFB_TypeKind zT_43;
    zT_338B7C76_TypeRegistry* zT_48;
    zT_112BF819_PtrPayload* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    zT_112BF819_PtrPayload zT_52;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_D155D06D_Type* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    zT_D155D06D_Type zT_65;
    zT_33EF6BFB_TypeKind zT_66;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_E834303C_ArrayPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_E834303C_ArrayPayload zT_74;
    unsigned int zT_75;
    zT_33EF6BFB_TypeKind zT_76;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_112BF819_PtrPayload* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_112BF819_PtrPayload zT_85;
    unsigned char zT_86;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_95;
    unsigned int zT_96;
    zT_33EF6BFB_TypeKind zT_99;
    zT_338B7C76_TypeRegistry* zT_104;
    zT_112BF819_PtrPayload* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_112BF819_PtrPayload zT_108;
    unsigned char zT_109;
    unsigned int zT_115;
    zT_33EF6BFB_TypeKind zT_117;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_0BB2A741_SlicePayload* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_0BB2A741_SlicePayload zT_126;
    unsigned char zT_127;
    unsigned int zT_133;
    unsigned char zT_135;
    unsigned char zT_138;
    unsigned int zT_139;
    unsigned char zT_142;
    unsigned char zT_145;
    unsigned int zT_146;
    zT_33EF6BFB_TypeKind zT_149;
    zT_338B7C76_TypeRegistry* zT_154;
    zT_0B10E8E9_OptionalPayload* zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_0B10E8E9_OptionalPayload zT_158;
    zT_38C12417_SemanticAnalyzer* zT_159;
    unsigned int zT_160;
    unsigned int zT_162;
    zT_33EF6BFB_TypeKind zT_165;
    zT_338B7C76_TypeRegistry* zT_170;
    zT_112BF819_PtrPayload* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    zT_112BF819_PtrPayload zT_174;
    zT_33EF6BFB_TypeKind zT_175;
    zT_338B7C76_TypeRegistry* zT_180;
    zT_112BF819_PtrPayload* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    zT_112BF819_PtrPayload zT_184;
    unsigned char zT_185;
    unsigned int zT_191;
    unsigned int zT_192;
    zT_33EF6BFB_TypeKind zT_194;
    zT_338B7C76_TypeRegistry* zT_199;
    zT_112BF819_PtrPayload* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    zT_112BF819_PtrPayload zT_203;
    unsigned char zT_204;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned char zT_213;
    unsigned int zT_214;
    zT_33EF6BFB_TypeKind zT_217;
    zT_338B7C76_TypeRegistry* zT_222;
    zT_0B10E8E9_OptionalPayload* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    zT_0B10E8E9_OptionalPayload zT_226;
    zT_38C12417_SemanticAnalyzer* zT_227;
    unsigned int zT_228;
    unsigned int zT_230;
    zT_33EF6BFB_TypeKind zT_233;
    zT_338B7C76_TypeRegistry* zT_238;
    zT_0BB2A741_SlicePayload* zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_0BB2A741_SlicePayload zT_242;
    zT_33EF6BFB_TypeKind zT_243;
    zT_338B7C76_TypeRegistry* zT_248;
    zT_0BB2A741_SlicePayload* zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    zT_0BB2A741_SlicePayload zT_252;
    unsigned char zT_253;
    unsigned int zT_259;
    unsigned int zT_260;
    zT_33EF6BFB_TypeKind zT_262;
    zT_338B7C76_TypeRegistry* zT_267;
    zT_112BF819_PtrPayload* zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    zT_112BF819_PtrPayload zT_271;
    unsigned char zT_272;
    unsigned int zT_278;
    unsigned int zT_279;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    zT_112BF819_PtrPayload sp;
    unsigned int sp_base_eff;
    zT_D155D06D_Type sp_pointee;
    zT_112BF819_PtrPayload dp;
    zT_112BF819_PtrPayload dp2;
    zT_0BB2A741_SlicePayload ds;
    zT_0B10E8E9_OptionalPayload opt;
    zT_112BF819_PtrPayload sp2;
    zT_112BF819_PtrPayload dp3;
    zT_112BF819_PtrPayload dp4;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_0BB2A741_SlicePayload ss;
    zT_0BB2A741_SlicePayload ds2;
    zT_112BF819_PtrPayload dp5;
    z_bb_0:
    if ((unsigned char)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    if ((unsigned char)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(src_type == dst_type)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_18 = self->registry;
    zT_19 = zT_18->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src_type) >= zT_19)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)dst_type) >= zT_24)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)src_type;
    zT_31 = zT_29[zT_30];
    s = zT_31;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)dst_type;
    zT_36 = zT_34[zT_35];
    d = zT_36;
    zT_37 = s.flags;
    if ((unsigned char)((unsigned char)(zT_37 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    zT_43 = s.kind;
    if ((unsigned char)(zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_48 = self->registry;
    zT_49 = zT_48->ptr_items;
    zT_50 = s.payload_idx;
    zT_51 = (unsigned int)zT_50;
    zT_52 = zT_49[zT_51];
    sp = zT_52;
    zT_54 = sp.base;
    sp_base_eff = zT_54;
    zT_55 = sp.base;
    zT_57 = self->registry;
    zT_58 = zT_57->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_55) < zT_58)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_165 = s.kind;
    if ((unsigned char)(zT_165 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_54; else goto z_bb_55;
    z_bb_21:
    zT_61 = self->registry;
    zT_62 = zT_61->types_items;
    zT_63 = sp.base;
    zT_64 = (unsigned int)zT_63;
    zT_65 = zT_62[zT_64];
    sp_pointee = zT_65;
    zT_66 = sp_pointee.kind;
    if ((unsigned char)(zT_66 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_76 = d.kind;
    if ((unsigned char)(zT_76 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_70 = self->registry;
    zT_71 = zT_70->array_items;
    zT_72 = sp_pointee.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    zT_75 = zT_74.elem;
    sp_base_eff = zT_75;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_81 = self->registry;
    zT_82 = zT_81->ptr_items;
    zT_83 = d.payload_idx;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zT_82[zT_84];
    dp = zT_85;
    zT_86 = d.flags;
    if ((unsigned char)((unsigned char)(zT_86 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_99 = d.kind;
    if ((unsigned char)(zT_99 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    zT_92 = sp.base;
    zT_93 = dp.base;
    if ((unsigned char)(zT_92 == zT_93)) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_96 = dp.base;
    zT_95 = zT_96 == (unsigned int)(1);
    goto z_bb_31;
    z_bb_30:
    zT_95 = 1;
    goto z_bb_31;
    z_bb_31:
    return zT_95;
    z_bb_32:
    zT_104 = self->registry;
    zT_105 = zT_104->ptr_items;
    zT_106 = d.payload_idx;
    zT_107 = (unsigned int)zT_106;
    zT_108 = zT_105[zT_107];
    dp2 = zT_108;
    zT_109 = d.flags;
    if ((unsigned char)((unsigned char)(zT_109 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_117 = d.kind;
    if ((unsigned char)(zT_117 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    return (unsigned char)(0);
    z_bb_35:
    zT_115 = dp2.base;
    return (unsigned char)(sp_base_eff == zT_115);
    z_bb_36:
    zT_122 = self->registry;
    zT_123 = zT_122->slice_items;
    zT_124 = d.payload_idx;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zT_123[zT_125];
    ds = zT_126;
    zT_127 = d.flags;
    if ((unsigned char)((unsigned char)(zT_127 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_149 = d.kind;
    if ((unsigned char)(zT_149 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_52; else goto z_bb_53;
    z_bb_38:
    return (unsigned char)(0);
    z_bb_39:
    zT_133 = ds.elem;
    if ((unsigned char)(sp_base_eff == zT_133)) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    if ((unsigned char)(sp_base_eff == (unsigned int)(14))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_135 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_135) goto z_bb_47; else goto z_bb_46;
    z_bb_43:
    zT_139 = ds.elem;
    zT_138 = zT_139 == (unsigned int)(8);
    goto z_bb_45;
    z_bb_44:
    zT_138 = 0;
    goto z_bb_45;
    z_bb_45:
    zT_135 = zT_138;
    goto z_bb_42;
    z_bb_46:
    if ((unsigned char)(sp_base_eff == (unsigned int)(8))) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    zT_142 = 1;
    goto z_bb_48;
    z_bb_48:
    return zT_142;
    z_bb_49:
    zT_146 = ds.elem;
    zT_145 = zT_146 == (unsigned int)(14);
    goto z_bb_51;
    z_bb_50:
    zT_145 = 0;
    goto z_bb_51;
    z_bb_51:
    zT_142 = zT_145;
    goto z_bb_48;
    z_bb_52:
    zT_154 = self->registry;
    zT_155 = zT_154->opt_items;
    zT_156 = d.payload_idx;
    zT_157 = (unsigned int)zT_156;
    zT_158 = zT_155[zT_157];
    opt = zT_158;
    zT_159 = self;
    zT_160 = src_type;
    zT_162 = opt.payload;
    self = zT_159;
    src_type = zT_160;
    dst_type = zT_162;
    goto z_bb_0;
    z_bb_53:
    return (unsigned char)(0);
    z_bb_54:
    zT_170 = self->registry;
    zT_171 = zT_170->ptr_items;
    zT_172 = s.payload_idx;
    zT_173 = (unsigned int)zT_172;
    zT_174 = zT_171[zT_173];
    sp2 = zT_174;
    zT_175 = d.kind;
    if ((unsigned char)(zT_175 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    zT_233 = s.kind;
    if ((unsigned char)(zT_233 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_69; else goto z_bb_70;
    z_bb_56:
    zT_180 = self->registry;
    zT_181 = zT_180->ptr_items;
    zT_182 = d.payload_idx;
    zT_183 = (unsigned int)zT_182;
    zT_184 = zT_181[zT_183];
    dp3 = zT_184;
    zT_185 = d.flags;
    if ((unsigned char)((unsigned char)(zT_185 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    zT_194 = d.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_60; else goto z_bb_61;
    z_bb_58:
    return (unsigned char)(0);
    z_bb_59:
    zT_191 = sp2.base;
    zT_192 = dp3.base;
    return (unsigned char)(zT_191 == zT_192);
    z_bb_60:
    zT_199 = self->registry;
    zT_200 = zT_199->ptr_items;
    zT_201 = d.payload_idx;
    zT_202 = (unsigned int)zT_201;
    zT_203 = zT_200[zT_202];
    dp4 = zT_203;
    zT_204 = d.flags;
    if ((unsigned char)((unsigned char)(zT_204 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_217 = d.kind;
    if ((unsigned char)(zT_217 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_67; else goto z_bb_68;
    z_bb_62:
    return (unsigned char)(0);
    z_bb_63:
    zT_210 = sp2.base;
    zT_211 = dp4.base;
    if ((unsigned char)(zT_210 == zT_211)) goto z_bb_65; else goto z_bb_64;
    z_bb_64:
    zT_214 = dp4.base;
    zT_213 = zT_214 == (unsigned int)(1);
    goto z_bb_66;
    z_bb_65:
    zT_213 = 1;
    goto z_bb_66;
    z_bb_66:
    return zT_213;
    z_bb_67:
    zT_222 = self->registry;
    zT_223 = zT_222->opt_items;
    zT_224 = d.payload_idx;
    zT_225 = (unsigned int)zT_224;
    zT_226 = zT_223[zT_225];
    opt2 = zT_226;
    zT_227 = self;
    zT_228 = src_type;
    zT_230 = opt2.payload;
    self = zT_227;
    src_type = zT_228;
    dst_type = zT_230;
    goto z_bb_0;
    z_bb_68:
    return (unsigned char)(0);
    z_bb_69:
    zT_238 = self->registry;
    zT_239 = zT_238->slice_items;
    zT_240 = s.payload_idx;
    zT_241 = (unsigned int)zT_240;
    zT_242 = zT_239[zT_241];
    ss = zT_242;
    zT_243 = d.kind;
    if ((unsigned char)(zT_243 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    return (unsigned char)(0);
    z_bb_71:
    zT_248 = self->registry;
    zT_249 = zT_248->slice_items;
    zT_250 = d.payload_idx;
    zT_251 = (unsigned int)zT_250;
    zT_252 = zT_249[zT_251];
    ds2 = zT_252;
    zT_253 = d.flags;
    if ((unsigned char)((unsigned char)(zT_253 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    zT_262 = d.kind;
    if ((unsigned char)(zT_262 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return (unsigned char)(0);
    z_bb_74:
    zT_259 = ss.elem;
    zT_260 = ds2.elem;
    return (unsigned char)(zT_259 == zT_260);
    z_bb_75:
    zT_267 = self->registry;
    zT_268 = zT_267->ptr_items;
    zT_269 = d.payload_idx;
    zT_270 = (unsigned int)zT_269;
    zT_271 = zT_268[zT_270];
    dp5 = zT_271;
    zT_272 = d.flags;
    if ((unsigned char)((unsigned char)(zT_272 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    return (unsigned char)(0);
    z_bb_77:
    return (unsigned char)(0);
    z_bb_78:
    zT_278 = ss.elem;
    zT_279 = dp5.base;
    return (unsigned char)(zT_278 == zT_279);
}

/* semanticAnalyzerMaybeDiagVolatileDrop */
unsigned char zF_86AAA417_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int span_node, unsigned int src_type, unsigned int dst_type) {
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_7 = 0;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_F85C5DED_DiagnosticCollector* zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_35 = 0;
    zT_22A7C88B_AstNode vdrop_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdrop_msg;
    zT_4 = self;
    zT_5 = src_type;
    zT_6 = dst_type;
    zT_7 = zF_57090266_semanticAnalyzerVol(zT_4, zT_5, zT_6);
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_11 = self->store;
    zT_12 = span_node;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    vdrop_node = zT_14;
    zT_16 = "cannot implicitly discard 'volatile' qualifier; use @volatileCast to remove it";
    zT_18 = 78;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    vdrop_msg = zT_17;
    zT_19 = self->diag;
    zT_22 = self->source_file_id;
    zT_23 = vdrop_node.span_start;
    zT_31 = vdrop_node.span_start;
    zT_32 = vdrop_node.span_len;
    zT_25 = vdrop_msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_19, (unsigned char)(0), (unsigned short)(3000), zT_22, zT_23, (unsigned int)(zT_31 + (unsigned int)((unsigned int)zT_32)), zT_25);
    (void)zT_35;
    return (unsigned char)(1);
}

/* semanticAnalyzerPtrCastDropsVolatile */
unsigned char zF_5F2042EA_semanticAnalyzerPtr(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    unsigned char zT_5;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    zT_33EF6BFB_TypeKind zT_37;
    unsigned char zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    zT_33EF6BFB_TypeKind zT_48;
    unsigned char zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    unsigned char zT_59;
    unsigned char zT_65;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    if ((unsigned char)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    if ((unsigned char)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(src_type == dst_type)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_18 = self->registry;
    zT_19 = zT_18->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src_type) >= zT_19)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)dst_type) >= zT_24)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)src_type;
    zT_31 = zT_29[zT_30];
    s = zT_31;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)dst_type;
    zT_36 = zT_34[zT_35];
    d = zT_36;
    zT_37 = s.kind;
    if ((unsigned char)(zT_37 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_42 = s.kind;
    zT_41 = zT_42 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_19;
    z_bb_18:
    zT_41 = 1;
    goto z_bb_19;
    z_bb_19:
    if ((unsigned char)(!zT_41)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    zT_48 = d.kind;
    if ((unsigned char)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_53 = d.kind;
    zT_52 = zT_53 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_24;
    z_bb_23:
    zT_52 = 1;
    goto z_bb_24;
    z_bb_24:
    if ((unsigned char)(!zT_52)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    zT_59 = s.flags;
    if ((unsigned char)((unsigned char)(zT_59 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    zT_65 = d.flags;
    return (unsigned char)((unsigned char)(zT_65 & (unsigned char)(2)) == (unsigned char)(0));
}

/* semanticAnalyzerVolatileCastValid */
unsigned char zF_EC29CB82_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    unsigned char zT_5;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_D155D06D_Type* zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type zT_29;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    unsigned char zT_39;
    zT_33EF6BFB_TypeKind zT_40;
    zT_33EF6BFB_TypeKind zT_46;
    unsigned char zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_57;
    unsigned char zT_63;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_112BF819_PtrPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_112BF819_PtrPayload zT_74;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_112BF819_PtrPayload* zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_112BF819_PtrPayload zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload dp;
    if ((unsigned char)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    if ((unsigned char)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src_type) >= zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_21 = self->registry;
    zT_22 = zT_21->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)dst_type) >= zT_22)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_26 = self->registry;
    zT_27 = zT_26->types_items;
    zT_28 = (unsigned int)src_type;
    zT_29 = zT_27[zT_28];
    s = zT_29;
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)dst_type;
    zT_34 = zT_32[zT_33];
    d = zT_34;
    zT_35 = s.kind;
    if ((unsigned char)(zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_40 = s.kind;
    zT_39 = zT_40 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_17;
    z_bb_16:
    zT_39 = 1;
    goto z_bb_17;
    z_bb_17:
    if ((unsigned char)(!zT_39)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (unsigned char)(0);
    z_bb_19:
    zT_46 = d.kind;
    if ((unsigned char)(zT_46 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_51 = d.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_22;
    z_bb_21:
    zT_50 = 1;
    goto z_bb_22;
    z_bb_22:
    if ((unsigned char)(!zT_50)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    zT_57 = s.flags;
    if ((unsigned char)((unsigned char)(zT_57 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    zT_63 = d.flags;
    if ((unsigned char)((unsigned char)(zT_63 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    zT_70 = self->registry;
    zT_71 = zT_70->ptr_items;
    zT_72 = s.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    sp = zT_74;
    zT_76 = self->registry;
    zT_77 = zT_76->ptr_items;
    zT_78 = d.payload_idx;
    zT_79 = (unsigned int)zT_78;
    zT_80 = zT_77[zT_79];
    dp = zT_80;
    zT_81 = sp.base;
    zT_82 = dp.base;
    return (unsigned char)(zT_81 == zT_82);
}

/* tryRecordCoercion */
void zF_DF7434EB_tryRecordCoercion(zT_38C12417_SemanticAnalyzer* self, unsigned int src_node, unsigned int src_type, unsigned int dst_type) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_338B7C76_TypeRegistry* zT_23;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_33EF6BFB_TypeKind zT_38;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_33EF6BFB_TypeKind zT_46;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_52 = {0};
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_8143F551_AstKind zT_59;
    unsigned char zT_63;
    zT_38C12417_SemanticAnalyzer* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned char zT_69 = 0;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char zT_74 = 0;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_0FB7FB13_CoercionKind zT_88 = 0;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned char zT_99;
    unsigned char zT_102;
    zT_338B7C76_TypeRegistry* zT_103;
    unsigned int zT_104;
    unsigned char zT_106 = 0;
    zT_66E7D2EF_CoercionTable* zT_107;
    unsigned int zT_108;
    zT_0FB7FB13_CoercionKind zT_109;
    unsigned int zT_110;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dm;
    zT_D155D06D_Type src_t;
    zT_D155D06D_Type dst_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_skm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dkm;
    zT_22A7C88B_AstNode snode;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs1_m;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u cka_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_km;
    zT_5 = "COE:N";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    coe_nm = zT_6;
    zT_8 = coe_nm;
    zT_9 = src_node;
    zF_C914CB83_markerWriteInt(zT_8, zT_9);
    zT_11 = "COE:S";
    zT_13 = 5;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    coe_sm = zT_12;
    zT_14 = coe_sm;
    zT_15 = src_type;
    zF_C914CB83_markerWriteInt(zT_14, zT_15);
    zT_17 = "COE:D";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    coe_dm = zT_18;
    zT_20 = coe_dm;
    zT_21 = dst_type;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = self->registry;
    zT_24 = zT_23->types_items;
    zT_25 = (unsigned int)src_type;
    zT_26 = zT_24[zT_25];
    src_t = zT_26;
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)dst_type;
    zT_31 = zT_29[zT_30];
    dst_t = zT_31;
    zT_33 = "COE:SK";
    zT_35 = 6;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    coe_skm = zT_34;
    zT_36 = coe_skm;
    zT_38 = src_t.kind;
    zF_C914CB83_markerWriteInt(zT_36, (unsigned int)((unsigned int)zT_38));
    zT_41 = "COE:DK";
    zT_43 = 6;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    coe_dkm = zT_42;
    zT_44 = coe_dkm;
    zT_46 = dst_t.kind;
    zF_C914CB83_markerWriteInt(zT_44, (unsigned int)((unsigned int)zT_46));
    zT_49 = self->store;
    zT_50 = src_node;
    zT_52 = zF_FCDD1D35_astStoreNodeAt(zT_49, zT_50);
    snode = zT_52;
    zT_54 = "COE:NK";
    zT_56 = 6;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    coe_nkm = zT_55;
    zT_57 = coe_nkm;
    zT_59 = snode.kind;
    zF_C914CB83_markerWriteInt(zT_57, (unsigned int)((unsigned int)zT_59));
    if ((unsigned char)(src_type == (unsigned int)(18))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_63 = src_type == dst_type;
    goto z_bb_3;
    z_bb_2:
    zT_63 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_63) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_65 = self;
    zT_66 = src_node;
    zT_67 = src_type;
    zT_68 = dst_type;
    zT_69 = zF_86AAA417_semanticAnalyzerMay(zT_65, zT_66, zT_67, zT_68);
    if (zT_69) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    zT_70 = self->registry;
    zT_71 = src_type;
    zT_72 = dst_type;
    zT_74 = zF_683AEB7F_typeRegistryIsAssig(zT_70, zT_71, zT_72);
    if ((unsigned char)(!zT_74)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    if ((unsigned char)(src_type == (unsigned int)(17))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_79 = "CS1\n";
    zT_81 = 4;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    cs1_m = zT_80;
    zT_82 = cs1_m;
    zF_48AC7B3A_markerWrite(zT_82);
    goto z_bb_11;
    z_bb_11:
    zT_84 = self->registry;
    zT_85 = src_type;
    zT_86 = dst_type;
    zT_88 = zF_713658BF_classifyCoercion(zT_84, zT_85, zT_86);
    ck = zT_88;
    zT_90 = "CCK:ca";
    zT_92 = 6;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    cka_m = zT_91;
    zT_93 = cka_m;
    zF_C914CB83_markerWriteInt(zT_93, (unsigned int)((unsigned int)ck));
    if ((unsigned char)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(src_type == (unsigned int)(17))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_99 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_99) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_103 = self->registry;
    zT_104 = dst_type;
    zT_106 = zF_AD61DB1B_typeRegistryIsPoint(zT_103, zT_104);
    zT_102 = zT_106;
    goto z_bb_17;
    z_bb_16:
    zT_102 = 0;
    goto z_bb_17;
    z_bb_17:
    zT_99 = zT_102;
    goto z_bb_14;
    z_bb_18:
    zT_107 = self->coercion_table;
    zT_108 = src_node;
    zT_109 = ck;
    zT_110 = dst_type;
    zF_D21AE60A_coercionTableAdd(zT_107, zT_108, zT_109, zT_110);
    zT_113 = "COR:N";
    zT_115 = 5;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    cor_nm = zT_114;
    zT_116 = cor_nm;
    zT_117 = src_node;
    zF_C914CB83_markerWriteInt(zT_116, zT_117);
    zT_119 = "COR:K";
    zT_121 = 5;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    cor_km = zT_120;
    zT_122 = cor_km;
    zF_C914CB83_markerWriteInt(zT_122, (unsigned int)((unsigned int)ck));
    goto z_bb_19;
    z_bb_19:
    return;
}

/* isStringLiteralSliceCoercion */
unsigned char zF_71304A07_isStringLiteralSlic(zT_0FB7FB13_CoercionKind k) {
    unsigned char zT_4;
    if ((unsigned char)(k == (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_string_to_slice))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = k == (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_4;
}

/* errLitSrcType */
unsigned int zF_FFC95E09_errLitSrcType(zT_38C12417_SemanticAnalyzer* self, unsigned int child_0, unsigned int target_ty, unsigned int ret_val) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_D155D06D_Type* zT_15;
    unsigned int zT_16;
    zT_D155D06D_Type zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_42C2D6BF_EUPayload* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_42C2D6BF_EUPayload zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode rn;
    zT_D155D06D_Type frt;
    zT_5 = self->store;
    zT_6 = child_0;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    rn = zT_8;
    zT_9 = rn.kind;
    if ((unsigned char)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self->registry;
    zT_15 = zT_14->types_items;
    zT_16 = (unsigned int)target_ty;
    zT_17 = zT_15[zT_16];
    frt = zT_17;
    zT_18 = frt.kind;
    if ((unsigned char)(zT_18 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return ret_val;
    z_bb_3:
    zT_22 = self->registry;
    zT_23 = zT_22->eu_items;
    zT_24 = frt.payload_idx;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23[zT_25];
    zT_27 = zT_26.error_set;
    return zT_27;
    z_bb_4:
    goto z_bb_2;
}

/* resolveReturnStmt */
void zF_F231D87F_resolveReturnStmt(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    unsigned char zT_13 = 0;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_F85C5DED_DiagnosticCollector* zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_35 = 0;
    unsigned int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    zT_38C12417_SemanticAnalyzer* zT_47;
    unsigned int zT_48;
    unsigned char zT_51;
    unsigned int zT_52;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_38C12417_SemanticAnalyzer* zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_82 = 0;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_88 = 0;
    unsigned char zT_90;
    zT_38C12417_SemanticAnalyzer* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned char zT_97 = 0;
    unsigned int zT_99;
    unsigned int zT_101;
    unsigned int zT_103;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_F85C5DED_DiagnosticCollector* zT_109;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_120 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_33EF6BFB_TypeKind zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_D155D06D_Type* zT_127;
    unsigned int zT_128;
    zT_D155D06D_Type zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_33EF6BFB_TypeKind zT_136;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_D155D06D_Type* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_D155D06D_Type zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143 = {0};
    zT_38C12417_SemanticAnalyzer* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_22A7C88B_AstNode node;
    unsigned int brsp;
    unsigned int brep;
    zT_8F083A69_Slice_zT_0B42B2F8_u br_msg;
    unsigned int ret_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_fm;
    unsigned int ret_eff;
    unsigned int rsp;
    unsigned int rep;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtm_msg;
    unsigned int rdi;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((unsigned char)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_11 = self->current_fn_return;
    zT_13 = zF_15CE7BE8_fnReturnRequiresVal(zT_10, zT_11);
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_36 = node.child_0;
    if ((unsigned char)(zT_36 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = node.span_start;
    brsp = zT_15;
    zT_17 = node.span_len;
    zT_19 = brsp + (unsigned int)((unsigned int)zT_17);
    brep = zT_19;
    zT_21 = "return with no value in function returning non-void";
    zT_23 = 51;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    br_msg = zT_22;
    zT_24 = self->diag;
    zT_27 = self->source_file_id;
    zT_28 = brsp;
    zT_29 = brep;
    zT_30 = br_msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_24, (unsigned char)(0), (unsigned short)(3003), zT_27, zT_28, zT_29, zT_30);
    (void)zT_35;
    goto z_bb_4;
    z_bb_4:
    return;
    z_bb_5:
    zT_39 = self;
    zT_40 = self->current_fn_return;
    zF_9665A229_pushExpectedType(zT_39, zT_40);
    zT_43 = self;
    zT_44 = node.child_0;
    zT_46 = zF_54F95822_semanticAnalyzerRes(zT_43, zT_44);
    ret_val = zT_46;
    zT_47 = self;
    zF_BC478E78_popExpectedType(zT_47);
    zT_48 = self->current_fn_return;
    if ((unsigned char)(zT_48 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_52 = self->current_fn_return;
    zT_51 = zT_52 != (unsigned int)(1);
    goto z_bb_9;
    z_bb_8:
    zT_51 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_51) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_56 = "T2F:C";
    zT_58 = 5;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    t2f_nm = zT_57;
    zT_59 = t2f_nm;
    zT_60 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_59, zT_60);
    zT_63 = "T2F:R";
    zT_65 = 5;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    t2f_rm = zT_64;
    zT_66 = t2f_rm;
    zT_67 = ret_val;
    zF_C914CB83_markerWriteInt(zT_66, zT_67);
    zT_69 = "T2F:F";
    zT_71 = 5;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    t2f_fm = zT_70;
    zT_72 = t2f_fm;
    zT_73 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_72, zT_73);
    zT_76 = self;
    zT_77 = node.child_0;
    zT_78 = self->current_fn_return;
    zT_79 = ret_val;
    zT_82 = zF_FFC95E09_errLitSrcType(zT_76, zT_77, zT_78, zT_79);
    ret_eff = zT_82;
    zT_83 = self->registry;
    zT_84 = ret_eff;
    zT_85 = self->current_fn_return;
    zT_88 = zF_683AEB7F_typeRegistryIsAssig(zT_83, zT_84, zT_85);
    if ((unsigned char)(!zT_88)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    goto z_bb_6;
    z_bb_12:
    zT_91 = self;
    zT_92 = ret_eff;
    zT_93 = self->current_fn_return;
    zT_97 = zF_D728034A_isBShapeMismatch(zT_91, zT_92, zT_93, (unsigned char)(0));
    zT_90 = zT_97;
    goto z_bb_14;
    z_bb_13:
    zT_90 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_90) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_99 = node.span_start;
    rsp = zT_99;
    zT_101 = node.span_len;
    zT_103 = rsp + (unsigned int)((unsigned int)zT_101);
    rep = zT_103;
    zT_105 = "type mismatch in return statement — value type may not be compatible with the function return type";
    zT_107 = 100;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    rtm_msg = zT_106;
    zT_109 = self->diag;
    zT_112 = self->source_file_id;
    zT_113 = rsp;
    zT_114 = rep;
    zT_115 = rtm_msg;
    zT_120 = zF_C82559AC_diagnosticCollector(zT_109, (unsigned char)(0), (unsigned short)(3000), zT_112, zT_113, zT_114, zT_115);
    rdi = zT_120;
    zT_121 = self->diag;
    zT_122 = rdi;
    zT_126 = self->registry;
    zT_127 = zT_126->types_items;
    zT_128 = (unsigned int)ret_eff;
    zT_129 = zT_127[zT_128];
    zT_125 = zT_129.kind;
    zT_131 = zF_C14453DE_typeKindSrcStr(zT_125);
    zT_123 = zT_131;
    zF_426E1F18_diagnosticCollector(zT_121, zT_122, zT_123);
    (void)self;
    zT_132 = self->diag;
    zT_133 = rdi;
    zT_137 = self->registry;
    zT_138 = zT_137->types_items;
    zT_139 = self->current_fn_return;
    zT_140 = (unsigned int)zT_139;
    zT_141 = zT_138[zT_140];
    zT_136 = zT_141.kind;
    zT_143 = zF_CC479241_typeKindTgtStr(zT_136);
    zT_134 = zT_143;
    zF_426E1F18_diagnosticCollector(zT_132, zT_133, zT_134);
    (void)self;
    goto z_bb_16;
    z_bb_16:
    zT_144 = self;
    zT_145 = node.child_0;
    zT_146 = ret_eff;
    zT_147 = self->current_fn_return;
    zF_DF7434EB_tryRecordCoercion(zT_144, zT_145, zT_146, zT_147);
    goto z_bb_11;
}

/* semanticAnalyzerResolveFnCall */
unsigned int zF_87E78775_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    unsigned int zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_8143F551_AstKind zT_23;
    zT_3D7259E2_SymbolRegistry* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_37 = 0;
    zT_5D7DACC8_Opt_861 zT_38 = {0};
    unsigned char zT_39;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_8EED1867_ResolvedTypeTable* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_3C598AEF_SymbolKind zT_56;
    unsigned char zT_60;
    unsigned int zT_61;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_70;
    zT_6B0A7D14_AstStore* zT_75;
    zT_7ABA3706_anon_234425 zT_76;
    zT_243D6A41_FnProto* zT_77;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int zT_82 = 0;
    unsigned int zT_83;
    zT_243D6A41_FnProto zT_84;
    unsigned int zT_85;
    zT_8EED1867_ResolvedTypeTable* zT_89;
    unsigned int zT_90;
    zT_BAEE192E_Opt_10 zT_93 = {0};
    unsigned char zT_95;
    unsigned int zT_96;
    unsigned char* zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char zT_105;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_ABC1EBBE_TypeResolveEnv zT_114;
    zT_6B0A7D14_AstStore* zT_115;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_3D7259E2_SymbolRegistry* zT_117;
    zT_D3EB6303_StringInterner* zT_118;
    unsigned int zT_119;
    zT_F85C5DED_DiagnosticCollector* zT_120;
    zT_7234F36B_Opt_226 zT_121;
    zT_F5B966E3_Opt_396 zT_122 = {0};
    zT_03B97CED_Opt_398 zT_123 = {0};
    unsigned int zT_124;
    zT_ABC1EBBE_TypeResolveEnv* zT_126;
    unsigned int zT_127;
    unsigned int zT_132 = 0;
    unsigned char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    unsigned char* zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_6B0A7D14_AstStore* zT_166;
    unsigned int zT_167;
    unsigned int zT_169 = 0;
    unsigned int zT_170;
    unsigned char zT_172;
    unsigned short zT_174;
    unsigned int zT_176;
    int zT_177;
    zT_8EED1867_ResolvedTypeTable* zT_180;
    unsigned int zT_181;
    zT_BAEE192E_Opt_10 zT_183 = {0};
    unsigned char zT_184;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    zT_338B7C76_TypeRegistry* zT_192;
    zT_D155D06D_Type* zT_193;
    unsigned int zT_194;
    zT_D155D06D_Type zT_195;
    zT_33EF6BFB_TypeKind zT_196;
    zT_338B7C76_TypeRegistry* zT_201;
    zT_0317B1D5_FnPayload* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_0317B1D5_FnPayload zT_205;
    unsigned short zT_206;
    unsigned int zT_207;
    unsigned char zT_208;
    int zT_210;
    unsigned int zT_211;
    unsigned int zT_214;
    unsigned char zT_217;
    unsigned int zT_225;
    unsigned int zT_226;
    zT_21D3708C_U32ToU32Map* zT_227;
    unsigned int zT_228;
    zT_BAEE192E_Opt_10 zT_230 = {0};
    unsigned char zT_231;
    zT_338B7C76_TypeRegistry* zT_233;
    unsigned int* zT_234;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_21D3708C_U32ToU32Map* zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    zT_6B0A7D14_AstStore* zT_242;
    unsigned int zT_243;
    unsigned int zT_247 = 0;
    zT_38C12417_SemanticAnalyzer* zT_248;
    unsigned int zT_249;
    zT_38C12417_SemanticAnalyzer* zT_251;
    unsigned int zT_252;
    zT_6B0A7D14_AstStore* zT_253;
    unsigned int zT_254;
    unsigned int zT_258 = 0;
    unsigned int zT_259 = 0;
    zT_38C12417_SemanticAnalyzer* zT_260;
    unsigned char zT_263;
    zT_38C12417_SemanticAnalyzer* zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    zT_6B0A7D14_AstStore* zT_271;
    unsigned int zT_272;
    unsigned int zT_276 = 0;
    unsigned int zT_277 = 0;
    zT_338B7C76_TypeRegistry* zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    unsigned char zT_282 = 0;
    unsigned char zT_284;
    zT_38C12417_SemanticAnalyzer* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned char zT_290 = 0;
    zT_6B0A7D14_AstStore* zT_292;
    unsigned int zT_293;
    zT_6B0A7D14_AstStore* zT_295;
    unsigned int zT_296;
    unsigned int zT_300 = 0;
    zT_22A7C88B_AstNode zT_301 = {0};
    unsigned int zT_303;
    unsigned int zT_305;
    unsigned int zT_307;
    unsigned char* zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    unsigned int zT_311;
    zT_F85C5DED_DiagnosticCollector* zT_313;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned int zT_324 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_325;
    unsigned int zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    zT_33EF6BFB_TypeKind zT_329;
    zT_338B7C76_TypeRegistry* zT_330;
    zT_D155D06D_Type* zT_331;
    unsigned int zT_332;
    zT_D155D06D_Type zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_336;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    zT_33EF6BFB_TypeKind zT_340;
    zT_338B7C76_TypeRegistry* zT_341;
    zT_D155D06D_Type* zT_342;
    unsigned int zT_343;
    zT_D155D06D_Type zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346 = {0};
    zT_38C12417_SemanticAnalyzer* zT_347;
    unsigned int zT_348;
    unsigned int zT_349;
    unsigned int zT_350;
    zT_6B0A7D14_AstStore* zT_351;
    unsigned int zT_352;
    unsigned int zT_356 = 0;
    int zT_357;
    unsigned int zT_359;
    zT_8EED1867_ResolvedTypeTable* zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    zT_38C12417_SemanticAnalyzer* zT_365;
    unsigned int zT_366;
    unsigned int zT_368 = 0;
    unsigned char* zT_372;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_373;
    unsigned int zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    zT_338B7C76_TypeRegistry* zT_378;
    zT_D155D06D_Type* zT_379;
    unsigned int zT_380;
    zT_D155D06D_Type zT_381;
    zT_33EF6BFB_TypeKind zT_382;
    zT_338B7C76_TypeRegistry* zT_387;
    zT_112BF819_PtrPayload* zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    zT_112BF819_PtrPayload zT_391;
    zT_338B7C76_TypeRegistry* zT_393;
    zT_D155D06D_Type* zT_394;
    unsigned int zT_395;
    unsigned int zT_396;
    zT_D155D06D_Type zT_397;
    zT_33EF6BFB_TypeKind zT_398;
    unsigned int zT_402;
    zT_338B7C76_TypeRegistry* zT_403;
    zT_D155D06D_Type* zT_404;
    unsigned int zT_405;
    zT_D155D06D_Type zT_406;
    zT_33EF6BFB_TypeKind zT_407;
    unsigned char* zT_412;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_413;
    unsigned int zT_414;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_415;
    unsigned int zT_416;
    unsigned char* zT_418;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_419;
    unsigned int zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421;
    unsigned int zT_422;
    unsigned char* zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned int zT_426;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_427;
    zT_33EF6BFB_TypeKind zT_429;
    zT_6B0A7D14_AstStore* zT_432;
    unsigned int zT_433;
    unsigned int zT_435 = 0;
    unsigned int zT_437;
    zT_38C12417_SemanticAnalyzer* zT_440;
    zT_38C12417_SemanticAnalyzer* zT_443;
    unsigned int zT_444;
    zT_6B0A7D14_AstStore* zT_445;
    unsigned int zT_446;
    unsigned int zT_450 = 0;
    unsigned int zT_451 = 0;
    zT_38C12417_SemanticAnalyzer* zT_452;
    unsigned int zT_454;
    unsigned char* zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_458;
    unsigned int zT_459;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_460;
    zT_338B7C76_TypeRegistry* zT_462;
    zT_0317B1D5_FnPayload* zT_463;
    unsigned int zT_464;
    unsigned int zT_465;
    zT_0317B1D5_FnPayload zT_466;
    unsigned char* zT_468;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_469;
    unsigned int zT_470;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_471;
    unsigned short zT_473;
    unsigned int zT_474;
    unsigned int zT_476;
    unsigned int zT_477;
    unsigned char* zT_479;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_480;
    unsigned int zT_481;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_482;
    zT_6B0A7D14_AstStore* zT_484;
    unsigned int zT_485;
    unsigned int zT_487 = 0;
    unsigned int zT_488;
    unsigned char* zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    unsigned int zT_492;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_493;
    unsigned char zT_495;
    unsigned char zT_496;
    unsigned char zT_501;
    unsigned int zT_506;
    unsigned int zT_508;
    int zT_510;
    unsigned int zT_511;
    unsigned char* zT_513;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_514;
    unsigned int zT_515;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_516;
    unsigned char* zT_518;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_519;
    unsigned int zT_520;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_521;
    zT_338B7C76_TypeRegistry* zT_523;
    unsigned int zT_524;
    unsigned char* zT_527;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_528;
    unsigned int zT_529;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_530;
    unsigned char* zT_535;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_536;
    unsigned int zT_537;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_538;
    zT_338B7C76_TypeRegistry* zT_540;
    unsigned int* zT_541;
    unsigned int zT_542;
    unsigned int zT_543;
    zT_21D3708C_U32ToU32Map* zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    zT_6B0A7D14_AstStore* zT_548;
    unsigned int zT_549;
    unsigned int zT_553 = 0;
    unsigned char* zT_555;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_556;
    unsigned int zT_557;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_558;
    unsigned char* zT_562;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_563;
    unsigned int zT_564;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_565;
    unsigned int zT_566;
    unsigned char* zT_568;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_569;
    unsigned int zT_570;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_571;
    unsigned int zT_572;
    zT_6B0A7D14_AstStore* zT_573;
    unsigned int zT_574;
    unsigned int zT_578 = 0;
    unsigned char* zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned int zT_582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_583;
    zT_38C12417_SemanticAnalyzer* zT_584;
    unsigned int zT_585;
    zT_38C12417_SemanticAnalyzer* zT_587;
    unsigned int zT_588;
    zT_6B0A7D14_AstStore* zT_589;
    unsigned int zT_590;
    unsigned int zT_594 = 0;
    unsigned int zT_595 = 0;
    zT_38C12417_SemanticAnalyzer* zT_596;
    zT_21D3708C_U32ToU32Map* zT_601;
    unsigned int zT_602;
    unsigned int zT_603;
    zT_6B0A7D14_AstStore* zT_605;
    unsigned int zT_606;
    unsigned int zT_610 = 0;
    zT_21D3708C_U32ToU32Map* zT_615;
    unsigned int zT_616;
    unsigned int zT_617;
    zT_6B0A7D14_AstStore* zT_619;
    unsigned int zT_620;
    unsigned int zT_624 = 0;
    zT_38C12417_SemanticAnalyzer* zT_626;
    unsigned int zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    zT_6B0A7D14_AstStore* zT_630;
    unsigned int zT_631;
    unsigned int zT_635 = 0;
    unsigned int zT_636 = 0;
    zT_338B7C76_TypeRegistry* zT_637;
    unsigned int zT_638;
    unsigned int zT_639;
    unsigned char zT_641 = 0;
    unsigned char zT_643;
    zT_38C12417_SemanticAnalyzer* zT_644;
    unsigned int zT_645;
    unsigned int zT_646;
    unsigned char zT_649 = 0;
    zT_6B0A7D14_AstStore* zT_651;
    unsigned int zT_652;
    zT_6B0A7D14_AstStore* zT_654;
    unsigned int zT_655;
    unsigned int zT_659 = 0;
    zT_22A7C88B_AstNode zT_660 = {0};
    unsigned int zT_662;
    unsigned int zT_664;
    unsigned int zT_666;
    unsigned char* zT_668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_669;
    unsigned int zT_670;
    zT_F85C5DED_DiagnosticCollector* zT_672;
    unsigned int zT_675;
    unsigned int zT_676;
    unsigned int zT_677;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_678;
    unsigned int zT_683 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_684;
    unsigned int zT_685;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_686;
    zT_33EF6BFB_TypeKind zT_688;
    zT_338B7C76_TypeRegistry* zT_689;
    zT_D155D06D_Type* zT_690;
    unsigned int zT_691;
    zT_D155D06D_Type zT_692;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_694 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_695;
    unsigned int zT_696;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_697;
    zT_33EF6BFB_TypeKind zT_699;
    zT_338B7C76_TypeRegistry* zT_700;
    zT_D155D06D_Type* zT_701;
    unsigned int zT_702;
    zT_D155D06D_Type zT_703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705 = {0};
    zT_38C12417_SemanticAnalyzer* zT_706;
    unsigned int zT_707;
    unsigned int zT_708;
    unsigned int zT_709;
    zT_6B0A7D14_AstStore* zT_710;
    unsigned int zT_711;
    unsigned int zT_715 = 0;
    int zT_716;
    unsigned int zT_718;
    zT_38C12417_SemanticAnalyzer* zT_723;
    zT_38C12417_SemanticAnalyzer* zT_727;
    unsigned int zT_728;
    zT_6B0A7D14_AstStore* zT_729;
    unsigned int zT_730;
    unsigned int zT_734 = 0;
    unsigned int zT_735 = 0;
    zT_38C12417_SemanticAnalyzer* zT_736;
    zT_21D3708C_U32ToU32Map* zT_739;
    unsigned int zT_740;
    unsigned int zT_741;
    zT_6B0A7D14_AstStore* zT_743;
    unsigned int zT_744;
    unsigned int zT_748 = 0;
    int zT_749;
    unsigned int zT_751;
    unsigned char* zT_753;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_754;
    unsigned int zT_755;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_756;
    unsigned int zT_757;
    unsigned int zT_759;
    zT_8F083A69_Slice_zT_0B42B2F8_u fne;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee_node;
    unsigned int direct_ret;
    unsigned int decl_cap;
    zT_5D7DACC8_Opt_861 sym;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u xf;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_22A7C88B_AstNode dn;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 rt;
    unsigned int rnt_val;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u brnt_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfnr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u drfb_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_fc;
    unsigned int fc_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1r_m;
    unsigned int args_n;
    unsigned char has_params;
    unsigned short pcount;
    unsigned int pstart;
    unsigned int callee_type;
    zT_BAEE192E_Opt_10 ft;
    unsigned int ai;
    unsigned int ftid;
    zT_8F083A69_Slice_zT_0B42B2F8_u sfm;
    zT_D155D06D_Type ft_ty;
    zT_0317B1D5_FnPayload ftp;
    unsigned int expected;
    unsigned int cpp_key;
    unsigned int dxc_at;
    unsigned int cpp_v;
    unsigned int carg_eff;
    zT_22A7C88B_AstNode argn;
    unsigned int csp;
    unsigned int cep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ctm_msg;
    unsigned int cdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn2;
    zT_D155D06D_Type callee_ty;
    zT_112BF819_PtrPayload cptr_pp;
    zT_D155D06D_Type cptr_pointee;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ck_m;
    unsigned int fn3_args_n;
    unsigned int fn3_i;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4a;
    zT_0317B1D5_FnPayload fnp;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4b;
    unsigned int pcount_1;
    unsigned int pstart_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4c;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4d;
    unsigned char is_var;
    unsigned int fixed;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4e;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4y_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4f;
    unsigned int param_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_am;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4g;
    unsigned int arg_type;
    unsigned int vi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4_rm;
    unsigned int varg_type;
    zT_3 = "FNE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fne = zT_4;
    zT_6 = fne;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    callee_node = zT_17;
    zT_19 = 0;
    direct_ret = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    decl_cap = zT_22;
    zT_23 = callee_node.kind;
    if ((unsigned char)(zT_23 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_28 = self->symbols;
    zT_29 = self->module_id;
    zT_33 = self->store;
    zT_34 = node.child_0;
    zT_37 = zF_53458827_astStoreIdentifier(zT_33, zT_34);
    zT_30 = zT_37;
    zT_38 = zF_A398987E_symbolRegistryQuali(zT_28, zT_29, zT_30);
    sym = zT_38;
    zT_39 = sym.has_value;
    if (zT_39) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    if ((unsigned char)(direct_ret != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    s = sym.value;
    zT_42 = "XF\n";
    zT_44 = 3;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    xf = zT_43;
    zT_45 = xf;
    zF_48AC7B3A_markerWrite(zT_45);
    zT_46 = s->decl_node;
    decl_cap = zT_46;
    zT_47 = s->type_id;
    if ((unsigned char)(zT_47 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_148 = "xS\n";
    zT_150 = 3;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    xs = zT_149;
    zT_151 = xs;
    zF_48AC7B3A_markerWrite(zT_151);
    goto z_bb_4;
    z_bb_6:
    zT_50 = self->type_table;
    zT_51 = node.child_0;
    zT_52 = s->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_50, zT_51, zT_52);
    goto z_bb_7;
    z_bb_7:
    zT_56 = s->kind;
    if ((unsigned char)(zT_56 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_61 = s->decl_node;
    zT_60 = zT_61 != (unsigned int)(0);
    goto z_bb_10;
    z_bb_9:
    zT_60 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_60) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_65 = self->store;
    zT_66 = s->decl_node;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    dn = zT_69;
    zT_70 = dn.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_4;
    z_bb_13:
    zT_75 = self->store;
    zT_76 = zT_75->fn_protos;
    zT_77 = zT_76.items;
    zT_78 = self->store;
    zT_79 = s->decl_node;
    zT_82 = zF_8BA26B9E_astStoreNodePayload(zT_78, zT_79);
    zT_83 = (unsigned int)zT_82;
    zT_84 = zT_77[zT_83];
    proto = zT_84;
    zT_85 = proto.return_type_node;
    if ((unsigned char)(zT_85 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_89 = self->type_table;
    zT_90 = proto.return_type_node;
    zT_93 = zF_999DCF51_resolvedTypeTableGe(zT_89, zT_90);
    rt = zT_93;
    zT_95 = rt.has_value;
    if (zT_95) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    t = rt.value;
    zT_96 = t;
    goto z_bb_19;
    z_bb_18:
    zT_96 = 0;
    goto z_bb_19;
    z_bb_19:
    rnt_val = zT_96;
    zT_100 = "BR:rnt";
    zT_102 = 6;
    zT_101.ptr = zT_100;
    zT_101.len = zT_102;
    brnt_m = zT_101;
    zT_103 = brnt_m;
    zT_104 = rnt_val;
    zF_C914CB83_markerWriteInt(zT_103, zT_104);
    zT_105 = rt.has_value;
    if (zT_105) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    t = rt.value;
    direct_ret = t;
    goto z_bb_21;
    z_bb_21:
    zT_142 = "BR:fnr";
    zT_144 = 6;
    zT_143.ptr = zT_142;
    zT_143.len = zT_144;
    brfnr_m = zT_143;
    zT_145 = brfnr_m;
    zT_146 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_145, zT_146);
    goto z_bb_16;
    z_bb_22:
    zT_108 = "DRETFB:n";
    zT_110 = 8;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    drfb_m = zT_109;
    zT_111 = drfb_m;
    zT_112 = node_idx;
    zF_C914CB83_markerWriteInt(zT_111, zT_112);
    zT_115 = self->store;
    zT_114.store = zT_115;
    zT_116 = self->registry;
    zT_114.typereg = zT_116;
    zT_117 = self->symbols;
    zT_114.symbol_reg = zT_117;
    zT_118 = self->interner;
    zT_114.interner = zT_118;
    zT_119 = s->module_id;
    zT_114.module_id = zT_119;
    zT_120 = self->diag;
    zT_121.has_value = 1;
    zT_121.value = zT_120;
    zT_114.diag = zT_121;
    zT_122.has_value = 0;
    zT_114.local_consts = zT_122;
    zT_123.has_value = 0;
    zT_114.local_types = zT_123;
    zT_124 = self->source_file_id;
    zT_114.source_file_id = zT_124;
    tre_env_fc = zT_114;
    zT_126 = &tre_env_fc;
    zT_127 = proto.return_type_node;
    zT_132 = zF_F2107C15_resolveTypeExprFull(zT_126, zT_127, (unsigned int)(0));
    fc_rt = zT_132;
    zT_134 = "BR:fc";
    zT_136 = 5;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    brfc_m = zT_135;
    zT_137 = brfc_m;
    zT_138 = fc_rt;
    zF_C914CB83_markerWriteInt(zT_137, zT_138);
    if ((unsigned char)(fc_rt != (unsigned int)(18))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    direct_ret = fc_rt;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_155 = "FN1\n";
    zT_157 = 4;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    fn1 = zT_156;
    zT_158 = fn1;
    zF_48AC7B3A_markerWrite(zT_158);
    zT_160 = "FN1:R";
    zT_162 = 5;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    fn1r_m = zT_161;
    zT_163 = fn1r_m;
    zT_164 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_163, zT_164);
    zT_166 = self->store;
    zT_167 = node_idx;
    zT_169 = zF_152E19CB_astStoreNodeExtraCh(zT_166, zT_167);
    zT_170 = (unsigned int)zT_169;
    args_n = zT_170;
    zT_172 = 0;
    has_params = zT_172;
    zT_174 = 0;
    pcount = zT_174;
    zT_176 = 0;
    pstart = zT_176;
    zT_177 = 0;
    if ((unsigned char)(decl_cap != (unsigned int)zT_177)) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_365 = self;
    zT_366 = node.child_0;
    zT_368 = zF_54F95822_semanticAnalyzerRes(zT_365, zT_366);
    callee_type = zT_368;
    if ((unsigned char)(callee_type == (unsigned int)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_27:
    zT_180 = self->type_table;
    zT_181 = decl_cap;
    zT_183 = zF_999DCF51_resolvedTypeTableGe(zT_180, zT_181);
    ft = zT_183;
    zT_184 = ft.has_value;
    if (zT_184) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_210 = 0;
    zT_211 = (unsigned int)zT_210;
    ai = zT_211;
    goto z_bb_33;
    z_bb_29:
    ftid = ft.value;
    zT_187 = "SF:H\n";
    zT_189 = 5;
    zT_188.ptr = zT_187;
    zT_188.len = zT_189;
    sfm = zT_188;
    zT_190 = sfm;
    zF_48AC7B3A_markerWrite(zT_190);
    zT_192 = self->registry;
    zT_193 = zT_192->types_items;
    zT_194 = (unsigned int)ftid;
    zT_195 = zT_193[zT_194];
    ft_ty = zT_195;
    zT_196 = ft_ty.kind;
    if ((unsigned char)(zT_196 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_201 = self->registry;
    zT_202 = zT_201->fn_items;
    zT_203 = ft_ty.payload_idx;
    zT_204 = (unsigned int)zT_203;
    zT_205 = zT_202[zT_204];
    ftp = zT_205;
    zT_206 = ftp.params_count;
    pcount = zT_206;
    zT_207 = ftp.params_start;
    pstart = zT_207;
    zT_208 = 1;
    has_params = zT_208;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    if ((unsigned char)(ai < args_n)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_214 = 0;
    expected = zT_214;
    if ((unsigned char)(has_params != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_360 = self->type_table;
    zT_361 = node_idx;
    zT_362 = direct_ret;
    zF_19B4A07D_resolvedTypeTableSe(zT_360, zT_361, zT_362);
    return direct_ret;
    z_bb_36:
    zT_357 = 1;
    zT_359 = ai + (unsigned int)((unsigned int)zT_357);
    ai = zT_359;
    goto z_bb_33;
    z_bb_37:
    zT_217 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_39;
    z_bb_38:
    zT_217 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_217) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_225 = (unsigned int)((unsigned int)((unsigned int)decl_cap) << (unsigned int)(16)) | (unsigned int)((unsigned int)ai);
    cpp_key = zT_225;
    zT_226 = 18;
    expected = zT_226;
    zT_227 = self->call_param_map;
    zT_228 = cpp_key;
    zT_230 = zF_F3EE5998_u32ToU32MapGet(zT_227, zT_228);
    zT_231 = zT_230.has_value;
    if (zT_231) goto z_bb_42; else goto z_bb_44;
    z_bb_41:
    zT_248 = self;
    zT_249 = expected;
    zF_9665A229_pushExpectedType(zT_248, zT_249);
    zT_251 = self;
    zT_253 = self->store;
    zT_254 = node_idx;
    zT_258 = zF_B10B1BC1_astStoreNodeExtraCh(zT_253, zT_254, (unsigned int)((unsigned int)ai));
    zT_252 = zT_258;
    zT_259 = zF_54F95822_semanticAnalyzerRes(zT_251, zT_252);
    dxc_at = zT_259;
    zT_260 = self;
    zF_BC478E78_popExpectedType(zT_260);
    if ((unsigned char)(has_params != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_42:
    cpp_v = zT_230.value;
    expected = cpp_v;
    goto z_bb_43;
    z_bb_43:
    zT_238 = self->call_arg_types;
    zT_242 = self->store;
    zT_243 = node_idx;
    zT_247 = zF_B10B1BC1_astStoreNodeExtraCh(zT_242, zT_243, (unsigned int)((unsigned int)ai));
    zT_239 = zT_247;
    zT_240 = expected;
    zF_26476265_u32ToU32MapPut(zT_238, zT_239, zT_240);
    goto z_bb_41;
    z_bb_44:
    zT_233 = self->registry;
    zT_234 = zT_233->xt_items;
    zT_236 = (unsigned int)((unsigned int)pstart) + ai;
    zT_237 = zT_234[zT_236];
    expected = zT_237;
    goto z_bb_43;
    z_bb_45:
    zT_263 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_47;
    z_bb_46:
    zT_263 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_263) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_267 = self;
    zT_271 = self->store;
    zT_272 = node_idx;
    zT_276 = zF_B10B1BC1_astStoreNodeExtraCh(zT_271, zT_272, (unsigned int)((unsigned int)ai));
    zT_268 = zT_276;
    zT_269 = expected;
    zT_270 = dxc_at;
    zT_277 = zF_FFC95E09_errLitSrcType(zT_267, zT_268, zT_269, zT_270);
    carg_eff = zT_277;
    zT_278 = self->registry;
    zT_279 = carg_eff;
    zT_280 = expected;
    zT_282 = zF_683AEB7F_typeRegistryIsAssig(zT_278, zT_279, zT_280);
    if ((unsigned char)(!zT_282)) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_36;
    z_bb_50:
    zT_285 = self;
    zT_286 = carg_eff;
    zT_287 = expected;
    zT_290 = zF_D728034A_isBShapeMismatch(zT_285, zT_286, zT_287, (unsigned char)(0));
    zT_284 = zT_290;
    goto z_bb_52;
    z_bb_51:
    zT_284 = 0;
    goto z_bb_52;
    z_bb_52:
    if (zT_284) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_292 = self->store;
    zT_295 = self->store;
    zT_296 = node_idx;
    zT_300 = zF_B10B1BC1_astStoreNodeExtraCh(zT_295, zT_296, (unsigned int)((unsigned int)ai));
    zT_293 = zT_300;
    zT_301 = zF_FCDD1D35_astStoreNodeAt(zT_292, zT_293);
    argn = zT_301;
    zT_303 = argn.span_start;
    csp = zT_303;
    zT_305 = argn.span_len;
    zT_307 = csp + (unsigned int)((unsigned int)zT_305);
    cep = zT_307;
    zT_309 = "type mismatch in function argument — argument type may not be compatible with the parameter type";
    zT_311 = 98;
    zT_310.ptr = zT_309;
    zT_310.len = zT_311;
    ctm_msg = zT_310;
    zT_313 = self->diag;
    zT_316 = self->source_file_id;
    zT_317 = csp;
    zT_318 = cep;
    zT_319 = ctm_msg;
    zT_324 = zF_C82559AC_diagnosticCollector(zT_313, (unsigned char)(0), (unsigned short)(3000), zT_316, zT_317, zT_318, zT_319);
    cdi = zT_324;
    zT_325 = self->diag;
    zT_326 = cdi;
    zT_330 = self->registry;
    zT_331 = zT_330->types_items;
    zT_332 = (unsigned int)carg_eff;
    zT_333 = zT_331[zT_332];
    zT_329 = zT_333.kind;
    zT_335 = zF_C14453DE_typeKindSrcStr(zT_329);
    zT_327 = zT_335;
    zF_426E1F18_diagnosticCollector(zT_325, zT_326, zT_327);
    (void)self;
    zT_336 = self->diag;
    zT_337 = cdi;
    zT_341 = self->registry;
    zT_342 = zT_341->types_items;
    zT_343 = (unsigned int)expected;
    zT_344 = zT_342[zT_343];
    zT_340 = zT_344.kind;
    zT_346 = zF_CC479241_typeKindTgtStr(zT_340);
    zT_338 = zT_346;
    zF_426E1F18_diagnosticCollector(zT_336, zT_337, zT_338);
    (void)self;
    goto z_bb_54;
    z_bb_54:
    zT_347 = self;
    zT_351 = self->store;
    zT_352 = node_idx;
    zT_356 = zF_B10B1BC1_astStoreNodeExtraCh(zT_351, zT_352, (unsigned int)((unsigned int)ai));
    zT_348 = zT_356;
    zT_349 = carg_eff;
    zT_350 = expected;
    zF_DF7434EB_tryRecordCoercion(zT_347, zT_348, zT_349, zT_350);
    goto z_bb_49;
    z_bb_55:
    zT_372 = "FN2\n";
    zT_374 = 4;
    zT_373.ptr = zT_372;
    zT_373.len = zT_374;
    fn2 = zT_373;
    zT_375 = fn2;
    zF_48AC7B3A_markerWrite(zT_375);
    return (unsigned int)(1);
    z_bb_56:
    zT_378 = self->registry;
    zT_379 = zT_378->types_items;
    zT_380 = (unsigned int)callee_type;
    zT_381 = zT_379[zT_380];
    callee_ty = zT_381;
    zT_382 = callee_ty.kind;
    if ((unsigned char)(zT_382 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_387 = self->registry;
    zT_388 = zT_387->ptr_items;
    zT_389 = callee_ty.payload_idx;
    zT_390 = (unsigned int)zT_389;
    zT_391 = zT_388[zT_390];
    cptr_pp = zT_391;
    zT_393 = self->registry;
    zT_394 = zT_393->types_items;
    zT_395 = cptr_pp.base;
    zT_396 = (unsigned int)zT_395;
    zT_397 = zT_394[zT_396];
    cptr_pointee = zT_397;
    zT_398 = cptr_pointee.kind;
    if ((unsigned char)(zT_398 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    zT_407 = callee_ty.kind;
    if ((unsigned char)(zT_407 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    zT_402 = cptr_pp.base;
    callee_type = zT_402;
    zT_403 = self->registry;
    zT_404 = zT_403->types_items;
    zT_405 = (unsigned int)callee_type;
    zT_406 = zT_404[zT_405];
    callee_ty = zT_406;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    zT_412 = "FN3:N";
    zT_414 = 5;
    zT_413.ptr = zT_412;
    zT_413.len = zT_414;
    fn3 = zT_413;
    zT_415 = fn3;
    zT_416 = node_idx;
    zF_C914CB83_markerWriteInt(zT_415, zT_416);
    zT_418 = "FN3:T";
    zT_420 = 5;
    zT_419.ptr = zT_418;
    zT_419.len = zT_420;
    fn3_ct_m = zT_419;
    zT_421 = fn3_ct_m;
    zT_422 = callee_type;
    zF_C914CB83_markerWriteInt(zT_421, zT_422);
    zT_424 = "FN3:K";
    zT_426 = 5;
    zT_425.ptr = zT_424;
    zT_425.len = zT_426;
    fn3_ck_m = zT_425;
    zT_427 = fn3_ck_m;
    zT_429 = callee_ty.kind;
    zF_C914CB83_markerWriteInt(zT_427, (unsigned int)((unsigned int)zT_429));
    zT_432 = self->store;
    zT_433 = node_idx;
    zT_435 = zF_152E19CB_astStoreNodeExtraCh(zT_432, zT_433);
    fn3_args_n = zT_435;
    zT_437 = 0;
    fn3_i = zT_437;
    goto z_bb_63;
    z_bb_62:
    zT_457 = "FN4a\n";
    zT_459 = 5;
    zT_458.ptr = zT_457;
    zT_458.len = zT_459;
    fn4a = zT_458;
    zT_460 = fn4a;
    zF_48AC7B3A_markerWrite(zT_460);
    zT_462 = self->registry;
    zT_463 = zT_462->fn_items;
    zT_464 = callee_ty.payload_idx;
    zT_465 = (unsigned int)zT_464;
    zT_466 = zT_463[zT_465];
    fnp = zT_466;
    zT_468 = "FN4b\n";
    zT_470 = 5;
    zT_469.ptr = zT_468;
    zT_469.len = zT_470;
    fn4b = zT_469;
    zT_471 = fn4b;
    zF_48AC7B3A_markerWrite(zT_471);
    zT_473 = fnp.params_count;
    zT_474 = (unsigned int)zT_473;
    pcount_1 = zT_474;
    zT_476 = fnp.params_start;
    zT_477 = (unsigned int)zT_476;
    pstart_2 = zT_477;
    zT_479 = "FN4c\n";
    zT_481 = 5;
    zT_480.ptr = zT_479;
    zT_480.len = zT_481;
    fn4c = zT_480;
    zT_482 = fn4c;
    zF_48AC7B3A_markerWrite(zT_482);
    zT_484 = self->store;
    zT_485 = node_idx;
    zT_487 = zF_152E19CB_astStoreNodeExtraCh(zT_484, zT_485);
    zT_488 = (unsigned int)zT_487;
    args_n = zT_488;
    zT_490 = "FN4d\n";
    zT_492 = 5;
    zT_491.ptr = zT_490;
    zT_491.len = zT_492;
    fn4d = zT_491;
    zT_493 = fn4d;
    zF_48AC7B3A_markerWrite(zT_493);
    zT_495 = 0;
    is_var = zT_495;
    zT_496 = fnp.flags_packed;
    if ((unsigned char)((unsigned char)(zT_496 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_63:
    if ((unsigned char)(fn3_i < (unsigned int)((unsigned int)fn3_args_n))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_440 = self;
    zF_9665A229_pushExpectedType(zT_440, (unsigned int)(0));
    zT_443 = self;
    zT_445 = self->store;
    zT_446 = node_idx;
    zT_450 = zF_B10B1BC1_astStoreNodeExtraCh(zT_445, zT_446, (unsigned int)((unsigned int)fn3_i));
    zT_444 = zT_450;
    zT_451 = zF_54F95822_semanticAnalyzerRes(zT_443, zT_444);
    (void)zT_451;
    zT_452 = self;
    zF_BC478E78_popExpectedType(zT_452);
    goto z_bb_66;
    z_bb_65:
    return (unsigned int)(1);
    z_bb_66:
    zT_454 = fn3_i + (unsigned int)(1);
    fn3_i = zT_454;
    goto z_bb_63;
    z_bb_67:
    zT_501 = 1;
    is_var = zT_501;
    goto z_bb_68;
    z_bb_68:
    fixed = pcount_1;
    if ((unsigned char)(is_var != (unsigned char)(0))) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    if ((unsigned char)(args_n < fixed)) goto z_bb_72; else goto z_bb_73;
    z_bb_70:
    zT_510 = 0;
    zT_511 = (unsigned int)zT_510;
    ai = zT_511;
    zT_513 = "FN4e\n";
    zT_515 = 5;
    zT_514.ptr = zT_513;
    zT_514.len = zT_515;
    fn4e = zT_514;
    zT_516 = fn4e;
    zF_48AC7B3A_markerWrite(zT_516);
    zT_518 = "FN4x:X";
    zT_520 = 6;
    zT_519.ptr = zT_518;
    zT_519.len = zT_520;
    fn4x_m = zT_519;
    zT_521 = fn4x_m;
    zT_523 = self->registry;
    zT_524 = zT_523->xt_len;
    zF_C914CB83_markerWriteInt(zT_521, (unsigned int)((unsigned int)zT_524));
    zT_527 = "FN4y:P";
    zT_529 = 6;
    zT_528.ptr = zT_527;
    zT_528.len = zT_529;
    fn4y_m = zT_528;
    zT_530 = fn4y_m;
    zF_C914CB83_markerWriteInt(zT_530, (unsigned int)((unsigned int)pstart_2));
    goto z_bb_76;
    z_bb_71:
    if ((unsigned char)(args_n != pcount_1)) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_506 = fnp.return_type;
    return zT_506;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    zT_508 = fnp.return_type;
    return zT_508;
    z_bb_75:
    goto z_bb_70;
    z_bb_76:
    if ((unsigned char)(ai < fixed)) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_535 = "FN4f\n";
    zT_537 = 5;
    zT_536.ptr = zT_535;
    zT_536.len = zT_537;
    fn4f = zT_536;
    zT_538 = fn4f;
    zF_48AC7B3A_markerWrite(zT_538);
    zT_540 = self->registry;
    zT_541 = zT_540->xt_items;
    zT_542 = pstart_2 + ai;
    zT_543 = zT_541[zT_542];
    param_type = zT_543;
    zT_544 = self->call_arg_types;
    zT_548 = self->store;
    zT_549 = node_idx;
    zT_553 = zF_B10B1BC1_astStoreNodeExtraCh(zT_548, zT_549, (unsigned int)((unsigned int)ai));
    zT_545 = zT_553;
    zT_546 = param_type;
    zF_26476265_u32ToU32MapPut(zT_544, zT_545, zT_546);
    zT_555 = "PTM:A";
    zT_557 = 5;
    zT_556.ptr = zT_555;
    zT_556.len = zT_557;
    ptm_am = zT_556;
    zT_558 = ptm_am;
    zF_C914CB83_markerWriteInt(zT_558, (unsigned int)((unsigned int)ai));
    zT_562 = "PTM:T";
    zT_564 = 5;
    zT_563.ptr = zT_562;
    zT_563.len = zT_564;
    ptm_tm = zT_563;
    zT_565 = ptm_tm;
    zT_566 = param_type;
    zF_C914CB83_markerWriteInt(zT_565, zT_566);
    zT_568 = "PTM:N";
    zT_570 = 5;
    zT_569.ptr = zT_568;
    zT_569.len = zT_570;
    ptm_nm = zT_569;
    zT_571 = ptm_nm;
    zT_573 = self->store;
    zT_574 = node_idx;
    zT_578 = zF_B10B1BC1_astStoreNodeExtraCh(zT_573, zT_574, (unsigned int)((unsigned int)ai));
    zT_572 = zT_578;
    zF_C914CB83_markerWriteInt(zT_571, zT_572);
    zT_580 = "FN4g\n";
    zT_582 = 5;
    zT_581.ptr = zT_580;
    zT_581.len = zT_582;
    fn4g = zT_581;
    zT_583 = fn4g;
    zF_48AC7B3A_markerWrite(zT_583);
    zT_584 = self;
    zT_585 = param_type;
    zF_9665A229_pushExpectedType(zT_584, zT_585);
    zT_587 = self;
    zT_589 = self->store;
    zT_590 = node_idx;
    zT_594 = zF_B10B1BC1_astStoreNodeExtraCh(zT_589, zT_590, (unsigned int)((unsigned int)ai));
    zT_588 = zT_594;
    zT_595 = zF_54F95822_semanticAnalyzerRes(zT_587, zT_588);
    arg_type = zT_595;
    zT_596 = self;
    zF_BC478E78_popExpectedType(zT_596);
    if ((unsigned char)(param_type == (unsigned int)(18))) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    if ((unsigned char)(is_var != (unsigned char)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_79:
    zT_716 = 1;
    zT_718 = ai + (unsigned int)((unsigned int)zT_716);
    ai = zT_718;
    goto z_bb_76;
    z_bb_80:
    if ((unsigned char)(arg_type != (unsigned int)(18))) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    if ((unsigned char)(param_type == (unsigned int)(1))) goto z_bb_84; else goto z_bb_85;
    z_bb_82:
    zT_601 = self->call_arg_types;
    zT_605 = self->store;
    zT_606 = node_idx;
    zT_610 = zF_B10B1BC1_astStoreNodeExtraCh(zT_605, zT_606, (unsigned int)((unsigned int)ai));
    zT_602 = zT_610;
    zT_603 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_601, zT_602, zT_603);
    goto z_bb_83;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    if ((unsigned char)(arg_type != (unsigned int)(18))) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    zT_626 = self;
    zT_630 = self->store;
    zT_631 = node_idx;
    zT_635 = zF_B10B1BC1_astStoreNodeExtraCh(zT_630, zT_631, (unsigned int)((unsigned int)ai));
    zT_627 = zT_635;
    zT_628 = param_type;
    zT_629 = arg_type;
    zT_636 = zF_FFC95E09_errLitSrcType(zT_626, zT_627, zT_628, zT_629);
    carg_eff = zT_636;
    zT_637 = self->registry;
    zT_638 = carg_eff;
    zT_639 = param_type;
    zT_641 = zF_683AEB7F_typeRegistryIsAssig(zT_637, zT_638, zT_639);
    if ((unsigned char)(!zT_641)) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    zT_615 = self->call_arg_types;
    zT_619 = self->store;
    zT_620 = node_idx;
    zT_624 = zF_B10B1BC1_astStoreNodeExtraCh(zT_619, zT_620, (unsigned int)((unsigned int)ai));
    zT_616 = zT_624;
    zT_617 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_615, zT_616, zT_617);
    goto z_bb_87;
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_644 = self;
    zT_645 = carg_eff;
    zT_646 = param_type;
    zT_649 = zF_D728034A_isBShapeMismatch(zT_644, zT_645, zT_646, (unsigned char)(0));
    zT_643 = zT_649;
    goto z_bb_90;
    z_bb_89:
    zT_643 = 0;
    goto z_bb_90;
    z_bb_90:
    if (zT_643) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_651 = self->store;
    zT_654 = self->store;
    zT_655 = node_idx;
    zT_659 = zF_B10B1BC1_astStoreNodeExtraCh(zT_654, zT_655, (unsigned int)((unsigned int)ai));
    zT_652 = zT_659;
    zT_660 = zF_FCDD1D35_astStoreNodeAt(zT_651, zT_652);
    argn = zT_660;
    zT_662 = argn.span_start;
    csp = zT_662;
    zT_664 = argn.span_len;
    zT_666 = csp + (unsigned int)((unsigned int)zT_664);
    cep = zT_666;
    zT_668 = "type mismatch in function argument — argument type may not be compatible with the parameter type";
    zT_670 = 98;
    zT_669.ptr = zT_668;
    zT_669.len = zT_670;
    ctm_msg = zT_669;
    zT_672 = self->diag;
    zT_675 = self->source_file_id;
    zT_676 = csp;
    zT_677 = cep;
    zT_678 = ctm_msg;
    zT_683 = zF_C82559AC_diagnosticCollector(zT_672, (unsigned char)(0), (unsigned short)(3000), zT_675, zT_676, zT_677, zT_678);
    cdi = zT_683;
    zT_684 = self->diag;
    zT_685 = cdi;
    zT_689 = self->registry;
    zT_690 = zT_689->types_items;
    zT_691 = (unsigned int)carg_eff;
    zT_692 = zT_690[zT_691];
    zT_688 = zT_692.kind;
    zT_694 = zF_C14453DE_typeKindSrcStr(zT_688);
    zT_686 = zT_694;
    zF_426E1F18_diagnosticCollector(zT_684, zT_685, zT_686);
    (void)self;
    zT_695 = self->diag;
    zT_696 = cdi;
    zT_700 = self->registry;
    zT_701 = zT_700->types_items;
    zT_702 = (unsigned int)param_type;
    zT_703 = zT_701[zT_702];
    zT_699 = zT_703.kind;
    zT_705 = zF_CC479241_typeKindTgtStr(zT_699);
    zT_697 = zT_705;
    zF_426E1F18_diagnosticCollector(zT_695, zT_696, zT_697);
    (void)self;
    goto z_bb_92;
    z_bb_92:
    zT_706 = self;
    zT_710 = self->store;
    zT_711 = node_idx;
    zT_715 = zF_B10B1BC1_astStoreNodeExtraCh(zT_710, zT_711, (unsigned int)((unsigned int)ai));
    zT_707 = zT_715;
    zT_708 = carg_eff;
    zT_709 = param_type;
    zF_DF7434EB_tryRecordCoercion(zT_706, zT_707, zT_708, zT_709);
    goto z_bb_79;
    z_bb_93:
    vi = fixed;
    goto z_bb_95;
    z_bb_94:
    zT_753 = "FN4:R";
    zT_755 = 5;
    zT_754.ptr = zT_753;
    zT_754.len = zT_755;
    fn4_rm = zT_754;
    zT_756 = fn4_rm;
    zT_757 = fnp.return_type;
    zF_C914CB83_markerWriteInt(zT_756, zT_757);
    zT_759 = fnp.return_type;
    return zT_759;
    z_bb_95:
    if ((unsigned char)(vi < args_n)) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_723 = self;
    zF_9665A229_pushExpectedType(zT_723, (unsigned int)(0));
    zT_727 = self;
    zT_729 = self->store;
    zT_730 = node_idx;
    zT_734 = zF_B10B1BC1_astStoreNodeExtraCh(zT_729, zT_730, (unsigned int)((unsigned int)vi));
    zT_728 = zT_734;
    zT_735 = zF_54F95822_semanticAnalyzerRes(zT_727, zT_728);
    varg_type = zT_735;
    zT_736 = self;
    zF_BC478E78_popExpectedType(zT_736);
    if ((unsigned char)(varg_type != (unsigned int)(18))) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    goto z_bb_94;
    z_bb_98:
    zT_749 = 1;
    zT_751 = vi + (unsigned int)((unsigned int)zT_749);
    vi = zT_751;
    goto z_bb_95;
    z_bb_99:
    zT_739 = self->call_arg_types;
    zT_743 = self->store;
    zT_744 = node_idx;
    zT_748 = zF_B10B1BC1_astStoreNodeExtraCh(zT_743, zT_744, (unsigned int)((unsigned int)vi));
    zT_740 = zT_748;
    zT_741 = varg_type;
    zF_26476265_u32ToU32MapPut(zT_739, zT_740, zT_741);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_98;
}

/* semanticAnalyzerResolveTryExpr */
unsigned int zF_B78F27CD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    zT_338B7C76_TypeRegistry* zT_29;
    zT_42C2D6BF_EUPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_42C2D6BF_EUPayload zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    zT_42C2D6BF_EUPayload eu;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((unsigned char)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(1);
    z_bb_7:
    zT_29 = self->registry;
    zT_30 = zT_29->eu_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    eu = zT_33;
    zT_34 = eu.payload;
    return zT_34;
}

/* semanticAnalyzerResolveOrelseExpr */
unsigned int zF_B36961FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_D155D06D_Type* zT_42;
    unsigned int zT_43;
    zT_D155D06D_Type zT_44;
    zT_33EF6BFB_TypeKind zT_46;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_0B10E8E9_OptionalPayload* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_0B10E8E9_OptionalPayload zT_55;
    unsigned int zT_56;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    unsigned int zT_61 = 0;
    zT_66E7D2EF_CoercionTable* zT_62;
    unsigned int zT_63;
    unsigned int zT_65;
    zT_33EF6BFB_TypeKind zT_71;
    zT_33EF6BFB_TypeKind zT_75;
    unsigned char zT_79;
    zT_33EF6BFB_TypeKind zT_80;
    unsigned char zT_84;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_110 = 0;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_0B10E8E9_OptionalPayload* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_0B10E8E9_OptionalPayload zT_117;
    zT_66E7D2EF_CoercionTable* zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned int zT_127;
    zT_38C12417_SemanticAnalyzer* zT_130;
    unsigned int zT_131;
    zT_38C12417_SemanticAnalyzer* zT_134;
    unsigned int zT_135;
    unsigned int zT_137 = 0;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned char zT_141;
    zT_38C12417_SemanticAnalyzer* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_150;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    unsigned int expected;
    zT_D155D06D_Type oe_et;
    unsigned int payload_type;
    zT_0B10E8E9_OptionalPayload oe_opt;
    unsigned int opt_target;
    zT_0B10E8E9_OptionalPayload opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u oe_msg;
    unsigned int rhs_result;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((unsigned char)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((unsigned char)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_28 = self->expected_type_stack_len;
    zT_27 = zT_28 > (unsigned int)(0);
    goto z_bb_8;
    z_bb_7:
    zT_27 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = self->expected_type_stack_items;
    zT_33 = self->expected_type_stack_len;
    zT_36 = (unsigned int)(unsigned int)(zT_33 - (unsigned int)(1));
    zT_37 = zT_32[zT_36];
    expected = zT_37;
    if ((unsigned char)(expected != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_71 = ty.kind;
    if ((unsigned char)(zT_71 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_11:
    zT_41 = self->registry;
    zT_42 = zT_41->types_items;
    zT_43 = (unsigned int)expected;
    zT_44 = zT_42[zT_43];
    oe_et = zT_44;
    payload_type = expected;
    zT_46 = oe_et.kind;
    if ((unsigned char)(zT_46 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_51 = self->registry;
    zT_52 = zT_51->opt_items;
    zT_53 = oe_et.payload_idx;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zT_52[zT_54];
    oe_opt = zT_55;
    zT_56 = oe_opt.payload;
    payload_type = zT_56;
    goto z_bb_14;
    z_bb_14:
    zT_58 = self->registry;
    zT_59 = payload_type;
    zT_61 = zF_74A7234F_typeRegistryGetOrCr(zT_58, zT_59);
    opt_target = zT_61;
    zT_62 = self->coercion_table;
    zT_63 = node.child_0;
    zT_65 = opt_target;
    zF_D21AE60A_coercionTableAdd(zT_62, zT_63, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional_null), zT_65);
    return payload_type;
    z_bb_15:
    zT_75 = ty.kind;
    if ((unsigned char)(zT_75 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_18; else goto z_bb_17;
    z_bb_16:
    zT_113 = self->registry;
    zT_114 = zT_113->opt_items;
    zT_115 = ty.payload_idx;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zT_114[zT_116];
    opt = zT_117;
    zT_118 = self->coercion_table;
    zT_119 = node.child_0;
    zT_121 = opt.payload;
    zF_D21AE60A_coercionTableAdd(zT_118, zT_119, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_121);
    zT_127 = node.child_1;
    if ((unsigned char)(zT_127 != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_17:
    zT_80 = ty.kind;
    zT_79 = zT_80 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_19;
    z_bb_18:
    zT_79 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_79) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_84 = inner == (unsigned int)(3);
    goto z_bb_22;
    z_bb_21:
    zT_84 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_84) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned int)(1);
    z_bb_24:
    zT_89 = "orelse requires an optional operand; use 'catch' for error unions";
    zT_91 = 65;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    oe_msg = zT_90;
    zT_92 = self->diag;
    zT_95 = self->source_file_id;
    zT_96 = node.span_start;
    zT_106 = node.span_start;
    zT_107 = node.span_len;
    zT_98 = oe_msg;
    zT_110 = zF_C82559AC_diagnosticCollector(zT_92, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3016_ORELSE_REQUIRES_OPTIONAL)), zT_95, zT_96, (unsigned int)(zT_106 + (unsigned int)((unsigned int)zT_107)), zT_98);
    (void)zT_110;
    return (unsigned int)(18);
    z_bb_25:
    zT_130 = self;
    zT_131 = opt.payload;
    zF_9665A229_pushExpectedType(zT_130, zT_131);
    zT_134 = self;
    zT_135 = node.child_1;
    zT_137 = zF_54F95822_semanticAnalyzerRes(zT_134, zT_135);
    rhs_result = zT_137;
    zT_138 = self;
    zF_BC478E78_popExpectedType(zT_138);
    if ((unsigned char)(rhs_result != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_150 = opt.payload;
    return zT_150;
    z_bb_27:
    zT_141 = rhs_result != (unsigned int)(1);
    goto z_bb_29;
    z_bb_28:
    zT_141 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_141) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_144 = self;
    zT_145 = node.child_1;
    zT_146 = rhs_result;
    zT_147 = opt.payload;
    zF_DF7434EB_tryRecordCoercion(zT_144, zT_145, zT_146, zT_147);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_26;
}

/* semanticAnalyzerResolveIfExpr */
unsigned int zF_8B8EE70D_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    unsigned int zT_14;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8EED1867_ResolvedTypeTable* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    zT_38C12417_SemanticAnalyzer* zT_44;
    unsigned int zT_45 = 0;
    unsigned char zT_48;
    unsigned char zT_54;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    zT_22A7C88B_AstNode zT_59 = {0};
    zT_8143F551_AstKind zT_60;
    unsigned char zT_67;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    zT_22A7C88B_AstNode zT_72 = {0};
    zT_8143F551_AstKind zT_73;
    unsigned char zT_77;
    zT_338B7C76_TypeRegistry* zT_78;
    unsigned int zT_84 = 0;
    unsigned char zT_87;
    unsigned char zT_93;
    zT_0FB7FB13_CoercionKind zT_94;
    zT_338B7C76_TypeRegistry* zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_0FB7FB13_CoercionKind zT_99 = 0;
    unsigned char zT_100 = 0;
    unsigned char zT_104;
    zT_0FB7FB13_CoercionKind zT_105;
    zT_338B7C76_TypeRegistry* zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    zT_0FB7FB13_CoercionKind zT_110 = 0;
    unsigned char zT_111 = 0;
    unsigned char zT_114;
    unsigned char zT_117;
    unsigned char zT_118;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned char zT_123 = 0;
    unsigned char zT_126;
    unsigned char zT_129;
    unsigned char zT_130;
    zT_338B7C76_TypeRegistry* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned char zT_135 = 0;
    unsigned char zT_136;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    zT_38C12417_SemanticAnalyzer* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_8EED1867_ResolvedTypeTable* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    zT_8EED1867_ResolvedTypeTable* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned char* zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    zT_8EED1867_ResolvedTypeTable* zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned char* zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    unsigned int zT_205;
    unsigned char* zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    unsigned int zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_8EED1867_ResolvedTypeTable* zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    unsigned char zT_223;
    zT_338B7C76_TypeRegistry* zT_224;
    unsigned int zT_225;
    unsigned char zT_227 = 0;
    unsigned char* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    unsigned int zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_233;
    unsigned char* zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239;
    unsigned char* zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    zT_66E7D2EF_CoercionTable* zT_245;
    unsigned int zT_246;
    unsigned int zT_248;
    zT_8EED1867_ResolvedTypeTable* zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned char zT_259;
    zT_338B7C76_TypeRegistry* zT_260;
    unsigned int zT_261;
    unsigned char zT_263 = 0;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned int zT_269;
    unsigned char* zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    unsigned char* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned int zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    zT_66E7D2EF_CoercionTable* zT_281;
    unsigned int zT_282;
    unsigned int zT_284;
    zT_8EED1867_ResolvedTypeTable* zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned char* zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned int zT_300;
    unsigned char* zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned int zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    unsigned int zT_306;
    unsigned char* zT_308;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    unsigned int zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    zT_8EED1867_ResolvedTypeTable* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    unsigned char* zT_319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    unsigned int zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned int zT_323;
    unsigned char* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    unsigned int zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    unsigned char* zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned int zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    zT_8EED1867_ResolvedTypeTable* zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned char* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    unsigned int zT_344;
    unsigned char* zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    unsigned int zT_348;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_349;
    zT_8EED1867_ResolvedTypeTable* zT_350;
    unsigned int zT_351;
    zT_22A7C88B_AstNode node;
    unsigned int then_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_nl;
    unsigned int else_type;
    unsigned int ie_exp;
    unsigned char ie_then_lit;
    unsigned char ie_else_lit;
    unsigned char ie_then_str;
    unsigned char ie_else_str;
    unsigned char ie_then_ok;
    unsigned char ie_else_ok;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u siffm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sifftm;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_7, zT_8);
    zT_10 = self;
    zT_11 = node.child_1;
    zT_13 = zF_54F95822_semanticAnalyzerRes(zT_10, zT_11);
    then_type = zT_13;
    zT_14 = node.child_2;
    if ((unsigned char)(zT_14 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = "SIF:0N";
    zT_20 = 6;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    sif_m = zT_19;
    zT_21 = sif_m;
    zT_22 = node_idx;
    zF_C914CB83_markerWriteInt(zT_21, zT_22);
    zT_24 = "T";
    zT_26 = 1;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    sif_tm = zT_25;
    zT_27 = sif_tm;
    zT_28 = then_type;
    zF_C914CB83_markerWriteInt(zT_27, zT_28);
    zT_30 = " ";
    zT_32 = 1;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    sif_nl = zT_31;
    zT_33 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_34 = self->type_table;
    zT_35 = node_idx;
    zT_36 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_34, zT_35, zT_36);
    return then_type;
    z_bb_2:
    zT_39 = self;
    zT_40 = node.child_2;
    zT_42 = zF_54F95822_semanticAnalyzerRes(zT_39, zT_40);
    else_type = zT_42;
    zT_44 = self;
    zT_45 = zF_4DE7C2BC_topExpectedType(zT_44);
    ie_exp = zT_45;
    if ((unsigned char)(ie_exp == (unsigned int)(0))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_48 = ie_exp == (unsigned int)(1);
    goto z_bb_5;
    z_bb_4:
    zT_48 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_48) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    if ((unsigned char)(then_type != (unsigned int)(3))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    if ((unsigned char)(ie_exp != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_8:
    zT_55 = self->store;
    zT_56 = node.child_1;
    zT_59 = zF_FCDD1D35_astStoreNodeAt(zT_55, zT_56);
    zT_60 = zT_59.kind;
    zT_54 = zT_60 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_10;
    z_bb_9:
    zT_54 = 0;
    goto z_bb_10;
    z_bb_10:
    ie_then_lit = zT_54;
    if ((unsigned char)(else_type != (unsigned int)(3))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_68 = self->store;
    zT_69 = node.child_2;
    zT_72 = zF_FCDD1D35_astStoreNodeAt(zT_68, zT_69);
    zT_73 = zT_72.kind;
    zT_67 = zT_73 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_13;
    z_bb_12:
    zT_67 = 0;
    goto z_bb_13;
    z_bb_13:
    ie_else_lit = zT_67;
    if (ie_then_lit) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_77 = ie_else_lit;
    goto z_bb_16;
    z_bb_15:
    zT_77 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_77) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_78 = self->registry;
    zT_84 = zF_8FC81A87_typeRegistryGetOrCr(zT_78, (unsigned int)(8), (unsigned char)(1));
    ie_exp = zT_84;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_7;
    z_bb_19:
    zT_87 = ie_exp != (unsigned int)(1);
    goto z_bb_21;
    z_bb_20:
    zT_87 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_87) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    if ((unsigned char)(then_type != (unsigned int)(3))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    if ((unsigned char)(then_type == else_type)) goto z_bb_57; else goto z_bb_58;
    z_bb_24:
    zT_95 = self->registry;
    zT_96 = then_type;
    zT_97 = ie_exp;
    zT_99 = zF_713658BF_classifyCoercion(zT_95, zT_96, zT_97);
    zT_94 = zT_99;
    zT_100 = zF_71304A07_isStringLiteralSlic(zT_94);
    zT_93 = zT_100;
    goto z_bb_26;
    z_bb_25:
    zT_93 = 0;
    goto z_bb_26;
    z_bb_26:
    ie_then_str = zT_93;
    if ((unsigned char)(else_type != (unsigned int)(3))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_106 = self->registry;
    zT_107 = else_type;
    zT_108 = ie_exp;
    zT_110 = zF_713658BF_classifyCoercion(zT_106, zT_107, zT_108);
    zT_105 = zT_110;
    zT_111 = zF_71304A07_isStringLiteralSlic(zT_105);
    zT_104 = zT_111;
    goto z_bb_29;
    z_bb_28:
    zT_104 = 0;
    goto z_bb_29;
    z_bb_29:
    ie_else_str = zT_104;
    if ((unsigned char)(then_type == ie_exp)) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_114 = then_type == (unsigned int)(3);
    goto z_bb_32;
    z_bb_31:
    zT_114 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_114) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_117 = ie_then_str;
    goto z_bb_35;
    z_bb_34:
    zT_117 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_117) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_119 = self->registry;
    zT_120 = then_type;
    zT_121 = ie_exp;
    zT_123 = zF_683AEB7F_typeRegistryIsAssig(zT_119, zT_120, zT_121);
    zT_118 = zT_123;
    goto z_bb_38;
    z_bb_37:
    zT_118 = 1;
    goto z_bb_38;
    z_bb_38:
    ie_then_ok = zT_118;
    if ((unsigned char)(else_type == ie_exp)) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_126 = else_type == (unsigned int)(3);
    goto z_bb_41;
    z_bb_40:
    zT_126 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_126) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_129 = ie_else_str;
    goto z_bb_44;
    z_bb_43:
    zT_129 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_129) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_131 = self->registry;
    zT_132 = else_type;
    zT_133 = ie_exp;
    zT_135 = zF_683AEB7F_typeRegistryIsAssig(zT_131, zT_132, zT_133);
    zT_130 = zT_135;
    goto z_bb_47;
    z_bb_46:
    zT_130 = 1;
    goto z_bb_47;
    z_bb_47:
    ie_else_ok = zT_130;
    if (ie_then_ok) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_136 = ie_else_ok;
    goto z_bb_50;
    z_bb_49:
    zT_136 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_136) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    if ((unsigned char)(then_type != ie_exp)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_23;
    z_bb_53:
    zT_138 = self;
    zT_139 = node.child_1;
    zT_140 = then_type;
    zT_141 = ie_exp;
    zF_DF7434EB_tryRecordCoercion(zT_138, zT_139, zT_140, zT_141);
    goto z_bb_54;
    z_bb_54:
    if ((unsigned char)(else_type != ie_exp)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_144 = self;
    zT_145 = node.child_2;
    zT_146 = else_type;
    zT_147 = ie_exp;
    zF_DF7434EB_tryRecordCoercion(zT_144, zT_145, zT_146, zT_147);
    goto z_bb_56;
    z_bb_56:
    zT_149 = self->type_table;
    zT_150 = node_idx;
    zT_151 = ie_exp;
    zF_19B4A07D_resolvedTypeTableSe(zT_149, zT_150, zT_151);
    return ie_exp;
    z_bb_57:
    zT_155 = "SIF:1N";
    zT_157 = 6;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    sif_m = zT_156;
    zT_158 = sif_m;
    zT_159 = node_idx;
    zF_C914CB83_markerWriteInt(zT_158, zT_159);
    zT_161 = "T";
    zT_163 = 1;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    sif_tm = zT_162;
    zT_164 = sif_tm;
    zT_165 = then_type;
    zF_C914CB83_markerWriteInt(zT_164, zT_165);
    zT_167 = " ";
    zT_169 = 1;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    sif_nl = zT_168;
    zT_170 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_170);
    zT_171 = self->type_table;
    zT_172 = node_idx;
    zT_173 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_171, zT_172, zT_173);
    return then_type;
    z_bb_58:
    if ((unsigned char)(then_type == (unsigned int)(3))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_178 = "SIF:2N";
    zT_180 = 6;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    sif2m = zT_179;
    zT_181 = sif2m;
    zT_182 = node_idx;
    zF_C914CB83_markerWriteInt(zT_181, zT_182);
    zT_184 = "T";
    zT_186 = 1;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    sif2tm = zT_185;
    zT_187 = sif2tm;
    zT_188 = else_type;
    zF_C914CB83_markerWriteInt(zT_187, zT_188);
    zT_190 = " ";
    zT_192 = 1;
    zT_191.ptr = zT_190;
    zT_191.len = zT_192;
    sif2nl = zT_191;
    zT_193 = sif2nl;
    zF_48AC7B3A_markerWrite(zT_193);
    zT_194 = self->type_table;
    zT_195 = node_idx;
    zT_196 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_194, zT_195, zT_196);
    return else_type;
    z_bb_60:
    if ((unsigned char)(else_type == (unsigned int)(3))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_201 = "SIF:3N";
    zT_203 = 6;
    zT_202.ptr = zT_201;
    zT_202.len = zT_203;
    sif3m = zT_202;
    zT_204 = sif3m;
    zT_205 = node_idx;
    zF_C914CB83_markerWriteInt(zT_204, zT_205);
    zT_207 = "T";
    zT_209 = 1;
    zT_208.ptr = zT_207;
    zT_208.len = zT_209;
    sif3tm = zT_208;
    zT_210 = sif3tm;
    zT_211 = then_type;
    zF_C914CB83_markerWriteInt(zT_210, zT_211);
    zT_213 = " ";
    zT_215 = 1;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    sif3nl = zT_214;
    zT_216 = sif3nl;
    zF_48AC7B3A_markerWrite(zT_216);
    zT_217 = self->type_table;
    zT_218 = node_idx;
    zT_219 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_217, zT_218, zT_219);
    return then_type;
    z_bb_62:
    if ((unsigned char)(then_type == (unsigned int)(19))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_224 = self->registry;
    zT_225 = else_type;
    zT_227 = zF_3087E0A5_typeRegistryIsNumer(zT_224, zT_225);
    zT_223 = zT_227;
    goto z_bb_65;
    z_bb_64:
    zT_223 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_223) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_229 = "SIF:4N";
    zT_231 = 6;
    zT_230.ptr = zT_229;
    zT_230.len = zT_231;
    sif4m = zT_230;
    zT_232 = sif4m;
    zT_233 = node_idx;
    zF_C914CB83_markerWriteInt(zT_232, zT_233);
    zT_235 = "T";
    zT_237 = 1;
    zT_236.ptr = zT_235;
    zT_236.len = zT_237;
    sif4tm = zT_236;
    zT_238 = sif4tm;
    zT_239 = else_type;
    zF_C914CB83_markerWriteInt(zT_238, zT_239);
    zT_241 = " ";
    zT_243 = 1;
    zT_242.ptr = zT_241;
    zT_242.len = zT_243;
    sif4nl = zT_242;
    zT_244 = sif4nl;
    zF_48AC7B3A_markerWrite(zT_244);
    zT_245 = self->coercion_table;
    zT_246 = node.child_1;
    zT_248 = else_type;
    zF_D21AE60A_coercionTableAdd(zT_245, zT_246, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_248);
    zT_253 = self->type_table;
    zT_254 = node_idx;
    zT_255 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_253, zT_254, zT_255);
    return else_type;
    z_bb_67:
    if ((unsigned char)(else_type == (unsigned int)(19))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_260 = self->registry;
    zT_261 = then_type;
    zT_263 = zF_3087E0A5_typeRegistryIsNumer(zT_260, zT_261);
    zT_259 = zT_263;
    goto z_bb_70;
    z_bb_69:
    zT_259 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_259) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_265 = "SIF:5N";
    zT_267 = 6;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    sif5m = zT_266;
    zT_268 = sif5m;
    zT_269 = node_idx;
    zF_C914CB83_markerWriteInt(zT_268, zT_269);
    zT_271 = "T";
    zT_273 = 1;
    zT_272.ptr = zT_271;
    zT_272.len = zT_273;
    sif5tm = zT_272;
    zT_274 = sif5tm;
    zT_275 = then_type;
    zF_C914CB83_markerWriteInt(zT_274, zT_275);
    zT_277 = " ";
    zT_279 = 1;
    zT_278.ptr = zT_277;
    zT_278.len = zT_279;
    sif5nl = zT_278;
    zT_280 = sif5nl;
    zF_48AC7B3A_markerWrite(zT_280);
    zT_281 = self->coercion_table;
    zT_282 = node.child_2;
    zT_284 = then_type;
    zF_D21AE60A_coercionTableAdd(zT_281, zT_282, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_284);
    zT_289 = self->type_table;
    zT_290 = node_idx;
    zT_291 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_289, zT_290, zT_291);
    return then_type;
    z_bb_72:
    if ((unsigned char)(then_type == (unsigned int)(1))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_296 = "SIF:6N";
    zT_298 = 6;
    zT_297.ptr = zT_296;
    zT_297.len = zT_298;
    sif6m = zT_297;
    zT_299 = sif6m;
    zT_300 = node_idx;
    zF_C914CB83_markerWriteInt(zT_299, zT_300);
    zT_302 = "T";
    zT_304 = 1;
    zT_303.ptr = zT_302;
    zT_303.len = zT_304;
    sif6tm = zT_303;
    zT_305 = sif6tm;
    zT_306 = else_type;
    zF_C914CB83_markerWriteInt(zT_305, zT_306);
    zT_308 = " ";
    zT_310 = 1;
    zT_309.ptr = zT_308;
    zT_309.len = zT_310;
    sif6nl = zT_309;
    zT_311 = sif6nl;
    zF_48AC7B3A_markerWrite(zT_311);
    zT_312 = self->type_table;
    zT_313 = node_idx;
    zT_314 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_312, zT_313, zT_314);
    return else_type;
    z_bb_74:
    if ((unsigned char)(else_type == (unsigned int)(1))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_319 = "SIF:7N";
    zT_321 = 6;
    zT_320.ptr = zT_319;
    zT_320.len = zT_321;
    sif7m = zT_320;
    zT_322 = sif7m;
    zT_323 = node_idx;
    zF_C914CB83_markerWriteInt(zT_322, zT_323);
    zT_325 = "T";
    zT_327 = 1;
    zT_326.ptr = zT_325;
    zT_326.len = zT_327;
    sif7tm = zT_326;
    zT_328 = sif7tm;
    zT_329 = then_type;
    zF_C914CB83_markerWriteInt(zT_328, zT_329);
    zT_331 = " ";
    zT_333 = 1;
    zT_332.ptr = zT_331;
    zT_332.len = zT_333;
    sif7nl = zT_332;
    zT_334 = sif7nl;
    zF_48AC7B3A_markerWrite(zT_334);
    zT_335 = self->type_table;
    zT_336 = node_idx;
    zT_337 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_335, zT_336, zT_337);
    return then_type;
    z_bb_76:
    zT_340 = "SIF:FN";
    zT_342 = 6;
    zT_341.ptr = zT_340;
    zT_341.len = zT_342;
    siffm = zT_341;
    zT_343 = siffm;
    zT_344 = node_idx;
    zF_C914CB83_markerWriteInt(zT_343, zT_344);
    zT_346 = "\n";
    zT_348 = 1;
    zT_347.ptr = zT_346;
    zT_347.len = zT_348;
    sifftm = zT_347;
    zT_349 = sifftm;
    zF_48AC7B3A_markerWrite(zT_349);
    zT_350 = self->type_table;
    zT_351 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_350, zT_351, (unsigned int)(1));
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveEnumLiteral */
unsigned int zF_8C008E53_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_54FF90FA_TaggedUnionPayload* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_54FF90FA_TaggedUnionPayload zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned short zT_40;
    unsigned int zT_41;
    zT_338B7C76_TypeRegistry* zT_43;
    zT_2DF01B61_FieldEntry* zT_44;
    zT_2DF01B61_FieldEntry zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    int zT_68;
    unsigned int zT_69;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_2DF01B61_FieldEntry* zT_73;
    unsigned int zT_74;
    zT_2DF01B61_FieldEntry zT_75;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_82;
    unsigned int zT_84;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_21D3708C_U32ToU32Map* zT_92;
    unsigned int zT_93;
    zT_21D3708C_U32ToU32Map* zT_95;
    unsigned int zT_96;
    zT_8EED1867_ResolvedTypeTable* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_105;
    int zT_106;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_457ECFEE_EnumPayload* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_457ECFEE_EnumPayload zT_118;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned short zT_123;
    unsigned int zT_124;
    int zT_126;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D96DCDF2_EnumMember* zT_131;
    unsigned int zT_132;
    zT_D96DCDF2_EnumMember zT_133;
    unsigned int zT_134;
    zT_21D3708C_U32ToU32Map* zT_136;
    unsigned int zT_137;
    zT_C69B2266_i64 zT_140;
    zT_8EED1867_ResolvedTypeTable* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_147;
    int zT_148;
    unsigned int zT_150;
    unsigned int zT_151;
    int zT_152;
    unsigned int* zT_155;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_338B7C76_TypeRegistry* zT_164;
    zT_D155D06D_Type* zT_165;
    unsigned int zT_166;
    zT_D155D06D_Type zT_167;
    zT_33EF6BFB_TypeKind zT_168;
    zT_338B7C76_TypeRegistry* zT_173;
    zT_54FF90FA_TaggedUnionPayload* zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    zT_54FF90FA_TaggedUnionPayload zT_177;
    unsigned int zT_179;
    unsigned int zT_180;
    unsigned short zT_182;
    unsigned int zT_183;
    int zT_185;
    unsigned int zT_186;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_2DF01B61_FieldEntry* zT_190;
    unsigned int zT_191;
    zT_2DF01B61_FieldEntry zT_192;
    unsigned int zT_193;
    unsigned int zT_195;
    zT_21D3708C_U32ToU32Map* zT_198;
    unsigned int zT_199;
    zT_8EED1867_ResolvedTypeTable* zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_208;
    unsigned int zT_210;
    unsigned int zT_212;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_F85C5DED_DiagnosticCollector* zT_217;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_230 = 0;
    int zT_232;
    unsigned int zT_234;
    unsigned int zT_236;
    unsigned int zT_238;
    unsigned int zT_240;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_F85C5DED_DiagnosticCollector* zT_245;
    unsigned int zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_258 = 0;
    zT_33EF6BFB_TypeKind zT_260;
    zT_338B7C76_TypeRegistry* zT_265;
    zT_457ECFEE_EnumPayload* zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    zT_457ECFEE_EnumPayload zT_269;
    unsigned int zT_271;
    unsigned int zT_272;
    unsigned short zT_274;
    unsigned int zT_275;
    int zT_277;
    unsigned int zT_278;
    zT_338B7C76_TypeRegistry* zT_281;
    zT_D96DCDF2_EnumMember* zT_282;
    unsigned int zT_283;
    zT_D96DCDF2_EnumMember zT_284;
    unsigned int zT_285;
    zT_21D3708C_U32ToU32Map* zT_287;
    unsigned int zT_288;
    zT_C69B2266_i64 zT_291;
    zT_8EED1867_ResolvedTypeTable* zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    int zT_297;
    unsigned int zT_299;
    unsigned char* zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    unsigned int zT_305;
    zT_8EED1867_ResolvedTypeTable* zT_306;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u el;
    zT_22A7C88B_AstNode node;
    unsigned int n;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int f0;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elc_m;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u elv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elm_m;
    zT_457ECFEE_EnumPayload enp;
    unsigned int estart;
    unsigned int ecount;
    unsigned int emi;
    zT_D96DCDF2_EnumMember member;
    unsigned int top;
    zT_D155D06D_Type top_ty;
    unsigned int fstart2;
    unsigned int fcount2;
    unsigned int fi2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u elr_msg;
    zT_457ECFEE_EnumPayload enp2;
    unsigned int estart2;
    unsigned int ecount2;
    unsigned int emi2;
    zT_D96DCDF2_EnumMember member2;
    zT_3 = "eL\n";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    el = zT_4;
    zT_6 = el;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node_idx;
    zT_16 = zF_53458827_astStoreIdentifier(zT_13, zT_14);
    n = zT_16;
    zT_17 = self->current_switch_cond_tu;
    if ((unsigned char)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = self->current_switch_cond_tu;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    tu_ty = zT_25;
    zT_26 = tu_ty.kind;
    if ((unsigned char)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_151 = self->expected_type_stack_len;
    zT_152 = 0;
    if ((unsigned char)(zT_151 > (unsigned int)zT_152)) goto z_bb_19; else goto z_bb_20;
    z_bb_3:
    zT_31 = self->registry;
    zT_32 = zT_31->tu_items;
    zT_33 = tu_ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    tp = zT_35;
    zT_37 = tp.fields_start;
    zT_38 = (unsigned int)zT_37;
    fstart = zT_38;
    zT_40 = tp.fields_count;
    zT_41 = (unsigned int)zT_40;
    fcount = zT_41;
    zT_43 = self->registry;
    zT_44 = zT_43->fe_items;
    zT_45 = zT_44[fstart];
    zT_46 = zT_45.name_id;
    zT_47 = (unsigned int)zT_46;
    f0 = zT_47;
    zT_49 = "EL:N";
    zT_51 = 4;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    eln_m = zT_50;
    zT_52 = eln_m;
    zT_53 = n;
    zF_C914CB83_markerWriteInt(zT_52, zT_53);
    zT_55 = "EL:F";
    zT_57 = 4;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    elf_m = zT_56;
    zT_58 = elf_m;
    zT_59 = f0;
    zF_C914CB83_markerWriteInt(zT_58, zT_59);
    zT_61 = "EL:C";
    zT_63 = 4;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    elc_m = zT_62;
    zT_64 = elc_m;
    zF_C914CB83_markerWriteInt(zT_64, (unsigned int)((unsigned int)fcount));
    zT_68 = 0;
    zT_69 = (unsigned int)zT_68;
    fi = zT_69;
    goto z_bb_5;
    z_bb_4:
    zT_109 = tu_ty.kind;
    if ((unsigned char)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_5:
    if ((unsigned char)(fi < fcount)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_72 = self->registry;
    zT_73 = zT_72->fe_items;
    zT_74 = fstart + fi;
    zT_75 = zT_73[zT_74];
    fe = zT_75;
    zT_77 = "EL:V";
    zT_79 = 4;
    zT_78.ptr = zT_77;
    zT_78.len = zT_79;
    elv_m = zT_78;
    zT_80 = elv_m;
    zT_82 = fe.name_id;
    zF_C914CB83_markerWriteInt(zT_80, (unsigned int)((unsigned int)zT_82));
    zT_84 = fe.name_id;
    if ((unsigned char)(zT_84 == n)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_106 = 1;
    zT_108 = fi + (unsigned int)((unsigned int)zT_106);
    fi = zT_108;
    goto z_bb_5;
    z_bb_9:
    zT_87 = "EL:M";
    zT_89 = 4;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    elm_m = zT_88;
    zT_90 = elm_m;
    zT_92 = self->enum_value_table;
    zT_93 = zT_92->count;
    zF_C914CB83_markerWriteInt(zT_90, (unsigned int)((unsigned int)zT_93));
    zT_95 = self->enum_value_table;
    zT_96 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_95, zT_96, (unsigned int)((unsigned int)fi));
    zT_100 = self->type_table;
    zT_101 = node_idx;
    zT_102 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_100, zT_101, zT_102);
    zT_105 = self->current_switch_cond_tu;
    return zT_105;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_114 = self->registry;
    zT_115 = zT_114->en_items;
    zT_116 = tu_ty.payload_idx;
    zT_117 = (unsigned int)zT_116;
    zT_118 = zT_115[zT_117];
    enp = zT_118;
    zT_120 = enp.members_start;
    zT_121 = (unsigned int)zT_120;
    estart = zT_121;
    zT_123 = enp.members_count;
    zT_124 = (unsigned int)zT_123;
    ecount = zT_124;
    zT_126 = 0;
    zT_127 = (unsigned int)zT_126;
    emi = zT_127;
    goto z_bb_13;
    z_bb_12:
    goto z_bb_2;
    z_bb_13:
    if ((unsigned char)(emi < ecount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_130 = self->registry;
    zT_131 = zT_130->em_items;
    zT_132 = estart + emi;
    zT_133 = zT_131[zT_132];
    member = zT_133;
    zT_134 = member.name_id;
    if ((unsigned char)(zT_134 == n)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_148 = 1;
    zT_150 = emi + (unsigned int)((unsigned int)zT_148);
    emi = zT_150;
    goto z_bb_13;
    z_bb_17:
    zT_136 = self->enum_value_table;
    zT_137 = node_idx;
    zT_140 = member.value;
    zF_26476265_u32ToU32MapPut(zT_136, zT_137, (unsigned int)((unsigned int)zT_140));
    zT_142 = self->type_table;
    zT_143 = node_idx;
    zT_144 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_142, zT_143, zT_144);
    zT_147 = self->current_switch_cond_tu;
    return zT_147;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_155 = self->expected_type_stack_items;
    zT_156 = self->expected_type_stack_len;
    zT_157 = 1;
    zT_159 = (unsigned int)(unsigned int)(zT_156 - zT_157);
    zT_160 = zT_155[zT_159];
    top = zT_160;
    if ((unsigned char)(top != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_301 = "ELV:N";
    zT_303 = 5;
    zT_302.ptr = zT_301;
    zT_302.len = zT_303;
    elv_m = zT_302;
    zT_304 = elv_m;
    zT_305 = n;
    zF_C914CB83_markerWriteInt(zT_304, zT_305);
    zT_306 = self->type_table;
    zT_307 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_306, zT_307, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_21:
    zT_164 = self->registry;
    zT_165 = zT_164->types_items;
    zT_166 = (unsigned int)top;
    zT_167 = zT_165[zT_166];
    top_ty = zT_167;
    zT_168 = top_ty.kind;
    if ((unsigned char)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_173 = self->registry;
    zT_174 = zT_173->tu_items;
    zT_175 = top_ty.payload_idx;
    zT_176 = (unsigned int)zT_175;
    zT_177 = zT_174[zT_176];
    tp = zT_177;
    zT_179 = tp.fields_start;
    zT_180 = (unsigned int)zT_179;
    fstart2 = zT_180;
    zT_182 = tp.fields_count;
    zT_183 = (unsigned int)zT_182;
    fcount2 = zT_183;
    zT_185 = 0;
    zT_186 = (unsigned int)zT_185;
    fi2 = zT_186;
    goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_260 = top_ty.kind;
    if ((unsigned char)(zT_260 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_26:
    if ((unsigned char)(fi2 < fcount2)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_189 = self->registry;
    zT_190 = zT_189->fe_items;
    zT_191 = fstart2 + fi2;
    zT_192 = zT_190[zT_191];
    fe = zT_192;
    zT_193 = fe.name_id;
    if ((unsigned char)(zT_193 == n)) goto z_bb_30; else goto z_bb_31;
    z_bb_28:
    zT_236 = node.span_start;
    sp = zT_236;
    zT_238 = node.span_len;
    zT_240 = sp + (unsigned int)((unsigned int)zT_238);
    ep = zT_240;
    zT_242 = "unknown enum literal member";
    zT_244 = 27;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    elu_msg = zT_243;
    zT_245 = self->diag;
    zT_248 = self->source_file_id;
    zT_249 = sp;
    zT_250 = ep;
    zT_251 = elu_msg;
    zT_258 = zF_C82559AC_diagnosticCollector(zT_245, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3009_UNKNOWN_ENUM_LITERAL_MEMBER)), zT_248, zT_249, zT_250, zT_251);
    (void)zT_258;
    return (unsigned int)(1);
    z_bb_29:
    zT_232 = 1;
    zT_234 = fi2 + (unsigned int)((unsigned int)zT_232);
    fi2 = zT_234;
    goto z_bb_26;
    z_bb_30:
    zT_195 = fe.type_id;
    if ((unsigned char)(zT_195 == (unsigned int)(1))) goto z_bb_32; else goto z_bb_34;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_198 = self->enum_value_table;
    zT_199 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_198, zT_199, (unsigned int)((unsigned int)fi2));
    zT_203 = self->type_table;
    zT_204 = node_idx;
    zT_205 = top;
    zF_19B4A07D_resolvedTypeTableSe(zT_203, zT_204, zT_205);
    return top;
    goto z_bb_31;
    z_bb_34:
    zT_208 = node.span_start;
    sp = zT_208;
    zT_210 = node.span_len;
    zT_212 = sp + (unsigned int)((unsigned int)zT_210);
    ep = zT_212;
    zT_214 = "enum literal member requires payload";
    zT_216 = 36;
    zT_215.ptr = zT_214;
    zT_215.len = zT_216;
    elr_msg = zT_215;
    zT_217 = self->diag;
    zT_220 = self->source_file_id;
    zT_221 = sp;
    zT_222 = ep;
    zT_223 = elr_msg;
    zT_230 = zF_C82559AC_diagnosticCollector(zT_217, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3008_ENUM_LITERAL_REQUIRES_PAYLOAD)), zT_220, zT_221, zT_222, zT_223);
    (void)zT_230;
    return (unsigned int)(1);
    z_bb_35:
    zT_265 = self->registry;
    zT_266 = zT_265->en_items;
    zT_267 = top_ty.payload_idx;
    zT_268 = (unsigned int)zT_267;
    zT_269 = zT_266[zT_268];
    enp2 = zT_269;
    zT_271 = enp2.members_start;
    zT_272 = (unsigned int)zT_271;
    estart2 = zT_272;
    zT_274 = enp2.members_count;
    zT_275 = (unsigned int)zT_274;
    ecount2 = zT_275;
    zT_277 = 0;
    zT_278 = (unsigned int)zT_277;
    emi2 = zT_278;
    goto z_bb_37;
    z_bb_36:
    goto z_bb_24;
    z_bb_37:
    if ((unsigned char)(emi2 < ecount2)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_281 = self->registry;
    zT_282 = zT_281->em_items;
    zT_283 = estart2 + emi2;
    zT_284 = zT_282[zT_283];
    member2 = zT_284;
    zT_285 = member2.name_id;
    if ((unsigned char)(zT_285 == n)) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_297 = 1;
    zT_299 = emi2 + (unsigned int)((unsigned int)zT_297);
    emi2 = zT_299;
    goto z_bb_37;
    z_bb_41:
    zT_287 = self->enum_value_table;
    zT_288 = node_idx;
    zT_291 = member2.value;
    zF_26476265_u32ToU32MapPut(zT_287, zT_288, (unsigned int)((unsigned int)zT_291));
    zT_293 = self->type_table;
    zT_294 = node_idx;
    zT_295 = top;
    zF_19B4A07D_resolvedTypeTableSe(zT_293, zT_294, zT_295);
    return top;
    z_bb_42:
    goto z_bb_40;
}

/* semanticAnalyzerResolveStructInit */
unsigned int zF_AD7EF126_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_38C12417_SemanticAnalyzer* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19 = 0;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_D155D06D_Type* zT_25;
    unsigned int zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_54FF90FA_TaggedUnionPayload* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_54FF90FA_TaggedUnionPayload zT_37;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned short zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    unsigned int zT_48 = 0;
    int zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_62 = 0;
    zT_22A7C88B_AstNode zT_63 = {0};
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_73 = 0;
    unsigned int zT_74 = 0;
    int zT_78;
    unsigned int zT_79;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_2DF01B61_FieldEntry* zT_82;
    unsigned int zT_83;
    zT_2DF01B61_FieldEntry zT_84;
    unsigned int zT_85;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_2DF01B61_FieldEntry* zT_92;
    unsigned int zT_93;
    zT_2DF01B61_FieldEntry zT_94;
    unsigned int zT_95;
    zT_38C12417_SemanticAnalyzer* zT_96;
    unsigned int zT_97;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    unsigned int zT_102 = 0;
    zT_38C12417_SemanticAnalyzer* zT_103;
    zT_38C12417_SemanticAnalyzer* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_111;
    int zT_112;
    unsigned int zT_114;
    zT_8EED1867_ResolvedTypeTable* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_33EF6BFB_TypeKind zT_119;
    zT_338B7C76_TypeRegistry* zT_124;
    zT_406493CE_StructPayload* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_406493CE_StructPayload zT_128;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned short zT_133;
    unsigned int zT_134;
    zT_6B0A7D14_AstStore* zT_136;
    unsigned int zT_137;
    unsigned int zT_139 = 0;
    int zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    unsigned int zT_153 = 0;
    zT_22A7C88B_AstNode zT_154 = {0};
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_159;
    unsigned int zT_160;
    unsigned int zT_164 = 0;
    unsigned int zT_165 = 0;
    int zT_169;
    unsigned int zT_170;
    zT_338B7C76_TypeRegistry* zT_172;
    zT_2DF01B61_FieldEntry* zT_173;
    unsigned int zT_174;
    zT_2DF01B61_FieldEntry zT_175;
    unsigned int zT_176;
    unsigned int zT_178;
    zT_338B7C76_TypeRegistry* zT_182;
    zT_2DF01B61_FieldEntry* zT_183;
    unsigned int zT_184;
    zT_2DF01B61_FieldEntry zT_185;
    unsigned int zT_186;
    zT_38C12417_SemanticAnalyzer* zT_187;
    unsigned int zT_188;
    zT_38C12417_SemanticAnalyzer* zT_190;
    unsigned int zT_191;
    unsigned int zT_193 = 0;
    zT_38C12417_SemanticAnalyzer* zT_194;
    zT_38C12417_SemanticAnalyzer* zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    int zT_200;
    unsigned int zT_202;
    int zT_203;
    unsigned int zT_205;
    zT_8EED1867_ResolvedTypeTable* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    zT_33EF6BFB_TypeKind zT_210;
    unsigned char zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    zT_338B7C76_TypeRegistry* zT_220;
    zT_AF9231A2_UnionPayload* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_AF9231A2_UnionPayload zT_224;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned short zT_229;
    unsigned int zT_230;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    unsigned int zT_235 = 0;
    int zT_237;
    unsigned int zT_238;
    zT_6B0A7D14_AstStore* zT_241;
    unsigned int zT_242;
    zT_6B0A7D14_AstStore* zT_244;
    unsigned int zT_245;
    unsigned int zT_249 = 0;
    zT_22A7C88B_AstNode zT_250 = {0};
    zT_6B0A7D14_AstStore* zT_252;
    unsigned int zT_253;
    zT_6B0A7D14_AstStore* zT_255;
    unsigned int zT_256;
    unsigned int zT_260 = 0;
    unsigned int zT_261 = 0;
    int zT_265;
    unsigned int zT_266;
    zT_338B7C76_TypeRegistry* zT_268;
    zT_2DF01B61_FieldEntry* zT_269;
    unsigned int zT_270;
    zT_2DF01B61_FieldEntry zT_271;
    unsigned int zT_272;
    unsigned int zT_274;
    zT_338B7C76_TypeRegistry* zT_278;
    zT_2DF01B61_FieldEntry* zT_279;
    unsigned int zT_280;
    zT_2DF01B61_FieldEntry zT_281;
    unsigned int zT_282;
    zT_38C12417_SemanticAnalyzer* zT_283;
    unsigned int zT_284;
    zT_38C12417_SemanticAnalyzer* zT_286;
    unsigned int zT_287;
    unsigned int zT_289 = 0;
    zT_38C12417_SemanticAnalyzer* zT_290;
    zT_38C12417_SemanticAnalyzer* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    int zT_296;
    unsigned int zT_298;
    int zT_299;
    unsigned int zT_301;
    zT_8EED1867_ResolvedTypeTable* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_22A7C88B_AstNode node;
    unsigned int target_type;
    zT_D155D06D_Type tgt;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int field_inits_n;
    unsigned int fii;
    zT_22A7C88B_AstNode fi_node;
    unsigned int fname_id;
    unsigned int fi;
    unsigned int field_type;
    unsigned int init_type;
    zT_406493CE_StructPayload sp;
    zT_AF9231A2_UnionPayload up;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = 0;
    target_type = zT_8;
    zT_9 = node.child_0;
    if ((unsigned char)(zT_9 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = node.child_0;
    zT_15 = zF_54F95822_semanticAnalyzerRes(zT_12, zT_13);
    target_type = zT_15;
    goto z_bb_2;
    z_bb_2:
    if ((unsigned char)(target_type == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = self;
    zT_19 = zF_4DE7C2BC_topExpectedType(zT_18);
    target_type = zT_19;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(target_type == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(1);
    z_bb_6:
    zT_24 = self->registry;
    zT_25 = zT_24->types_items;
    zT_26 = (unsigned int)target_type;
    zT_27 = zT_25[zT_26];
    tgt = zT_27;
    zT_28 = tgt.kind;
    if ((unsigned char)(zT_28 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_33 = self->registry;
    zT_34 = zT_33->tu_items;
    zT_35 = tgt.payload_idx;
    zT_36 = (unsigned int)zT_35;
    zT_37 = zT_34[zT_36];
    tp = zT_37;
    zT_39 = tp.fields_start;
    zT_40 = (unsigned int)zT_39;
    fstart = zT_40;
    zT_42 = tp.fields_count;
    zT_43 = (unsigned int)zT_42;
    fcount = zT_43;
    zT_45 = self->store;
    zT_46 = node_idx;
    zT_48 = zF_152E19CB_astStoreNodeExtraCh(zT_45, zT_46);
    field_inits_n = zT_48;
    zT_50 = 0;
    zT_51 = (unsigned int)zT_50;
    fii = zT_51;
    goto z_bb_9;
    z_bb_8:
    zT_119 = tgt.kind;
    if ((unsigned char)(zT_119 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    if ((unsigned char)(fii < field_inits_n)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_54 = self->store;
    zT_57 = self->store;
    zT_58 = node_idx;
    zT_62 = zF_B10B1BC1_astStoreNodeExtraCh(zT_57, zT_58, (unsigned int)((unsigned int)fii));
    zT_55 = zT_62;
    zT_63 = zF_FCDD1D35_astStoreNodeAt(zT_54, zT_55);
    fi_node = zT_63;
    zT_65 = self->store;
    zT_68 = self->store;
    zT_69 = node_idx;
    zT_73 = zF_B10B1BC1_astStoreNodeExtraCh(zT_68, zT_69, (unsigned int)((unsigned int)fii));
    zT_66 = zT_73;
    zT_74 = zF_8BA26B9E_astStoreNodePayload(zT_65, zT_66);
    fname_id = zT_74;
    if ((unsigned char)(fname_id != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_115 = self->type_table;
    zT_116 = node_idx;
    zT_117 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_115, zT_116, zT_117);
    return target_type;
    z_bb_12:
    zT_112 = 1;
    zT_114 = fii + (unsigned int)((unsigned int)zT_112);
    fii = zT_114;
    goto z_bb_9;
    z_bb_13:
    zT_78 = 0;
    zT_79 = (unsigned int)zT_78;
    fi = zT_79;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((unsigned char)(fi < fcount)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_81 = self->registry;
    zT_82 = zT_81->fe_items;
    zT_83 = fstart + fi;
    zT_84 = zT_82[zT_83];
    zT_85 = zT_84.name_id;
    if ((unsigned char)(zT_85 == fname_id)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_109 = 1;
    zT_111 = fi + (unsigned int)((unsigned int)zT_109);
    fi = zT_111;
    goto z_bb_15;
    z_bb_19:
    zT_87 = fi_node.child_0;
    if ((unsigned char)(zT_87 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_91 = self->registry;
    zT_92 = zT_91->fe_items;
    zT_93 = fstart + fi;
    zT_94 = zT_92[zT_93];
    zT_95 = zT_94.type_id;
    field_type = zT_95;
    zT_96 = self;
    zT_97 = field_type;
    zF_9665A229_pushExpectedType(zT_96, zT_97);
    zT_99 = self;
    zT_100 = fi_node.child_0;
    zT_102 = zF_54F95822_semanticAnalyzerRes(zT_99, zT_100);
    init_type = zT_102;
    zT_103 = self;
    zF_BC478E78_popExpectedType(zT_103);
    zT_104 = self;
    zT_105 = fi_node.child_0;
    zT_106 = init_type;
    zT_107 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_104, zT_105, zT_106, zT_107);
    goto z_bb_22;
    z_bb_22:
    goto z_bb_17;
    z_bb_23:
    zT_124 = self->registry;
    zT_125 = zT_124->st_items;
    zT_126 = tgt.payload_idx;
    zT_127 = (unsigned int)zT_126;
    zT_128 = zT_125[zT_127];
    sp = zT_128;
    zT_130 = sp.fields_start;
    zT_131 = (unsigned int)zT_130;
    fstart = zT_131;
    zT_133 = sp.fields_count;
    zT_134 = (unsigned int)zT_133;
    fcount = zT_134;
    zT_136 = self->store;
    zT_137 = node_idx;
    zT_139 = zF_152E19CB_astStoreNodeExtraCh(zT_136, zT_137);
    field_inits_n = zT_139;
    zT_141 = 0;
    zT_142 = (unsigned int)zT_141;
    fii = zT_142;
    goto z_bb_25;
    z_bb_24:
    zT_210 = tgt.kind;
    if ((unsigned char)(zT_210 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_40; else goto z_bb_39;
    z_bb_25:
    if ((unsigned char)(fii < field_inits_n)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_145 = self->store;
    zT_148 = self->store;
    zT_149 = node_idx;
    zT_153 = zF_B10B1BC1_astStoreNodeExtraCh(zT_148, zT_149, (unsigned int)((unsigned int)fii));
    zT_146 = zT_153;
    zT_154 = zF_FCDD1D35_astStoreNodeAt(zT_145, zT_146);
    fi_node = zT_154;
    zT_156 = self->store;
    zT_159 = self->store;
    zT_160 = node_idx;
    zT_164 = zF_B10B1BC1_astStoreNodeExtraCh(zT_159, zT_160, (unsigned int)((unsigned int)fii));
    zT_157 = zT_164;
    zT_165 = zF_8BA26B9E_astStoreNodePayload(zT_156, zT_157);
    fname_id = zT_165;
    if ((unsigned char)(fname_id != (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_206 = self->type_table;
    zT_207 = node_idx;
    zT_208 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_206, zT_207, zT_208);
    return target_type;
    z_bb_28:
    zT_203 = 1;
    zT_205 = fii + (unsigned int)((unsigned int)zT_203);
    fii = zT_205;
    goto z_bb_25;
    z_bb_29:
    zT_169 = 0;
    zT_170 = (unsigned int)zT_169;
    fi = zT_170;
    goto z_bb_31;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    if ((unsigned char)(fi < fcount)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_172 = self->registry;
    zT_173 = zT_172->fe_items;
    zT_174 = fstart + fi;
    zT_175 = zT_173[zT_174];
    zT_176 = zT_175.name_id;
    if ((unsigned char)(zT_176 == fname_id)) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_200 = 1;
    zT_202 = fi + (unsigned int)((unsigned int)zT_200);
    fi = zT_202;
    goto z_bb_31;
    z_bb_35:
    zT_178 = fi_node.child_0;
    if ((unsigned char)(zT_178 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_182 = self->registry;
    zT_183 = zT_182->fe_items;
    zT_184 = fstart + fi;
    zT_185 = zT_183[zT_184];
    zT_186 = zT_185.type_id;
    field_type = zT_186;
    zT_187 = self;
    zT_188 = field_type;
    zF_9665A229_pushExpectedType(zT_187, zT_188);
    zT_190 = self;
    zT_191 = fi_node.child_0;
    zT_193 = zF_54F95822_semanticAnalyzerRes(zT_190, zT_191);
    init_type = zT_193;
    zT_194 = self;
    zF_BC478E78_popExpectedType(zT_194);
    zT_195 = self;
    zT_196 = fi_node.child_0;
    zT_197 = init_type;
    zT_198 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_195, zT_196, zT_197, zT_198);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_33;
    z_bb_39:
    zT_215 = tgt.kind;
    zT_214 = zT_215 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_41;
    z_bb_40:
    zT_214 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_214) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_220 = self->registry;
    zT_221 = zT_220->un_items;
    zT_222 = tgt.payload_idx;
    zT_223 = (unsigned int)zT_222;
    zT_224 = zT_221[zT_223];
    up = zT_224;
    zT_226 = up.fields_start;
    zT_227 = (unsigned int)zT_226;
    fstart = zT_227;
    zT_229 = up.fields_count;
    zT_230 = (unsigned int)zT_229;
    fcount = zT_230;
    zT_232 = self->store;
    zT_233 = node_idx;
    zT_235 = zF_152E19CB_astStoreNodeExtraCh(zT_232, zT_233);
    field_inits_n = zT_235;
    zT_237 = 0;
    zT_238 = (unsigned int)zT_237;
    fii = zT_238;
    goto z_bb_44;
    z_bb_43:
    return (unsigned int)(1);
    z_bb_44:
    if ((unsigned char)(fii < field_inits_n)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_241 = self->store;
    zT_244 = self->store;
    zT_245 = node_idx;
    zT_249 = zF_B10B1BC1_astStoreNodeExtraCh(zT_244, zT_245, (unsigned int)((unsigned int)fii));
    zT_242 = zT_249;
    zT_250 = zF_FCDD1D35_astStoreNodeAt(zT_241, zT_242);
    fi_node = zT_250;
    zT_252 = self->store;
    zT_255 = self->store;
    zT_256 = node_idx;
    zT_260 = zF_B10B1BC1_astStoreNodeExtraCh(zT_255, zT_256, (unsigned int)((unsigned int)fii));
    zT_253 = zT_260;
    zT_261 = zF_8BA26B9E_astStoreNodePayload(zT_252, zT_253);
    fname_id = zT_261;
    if ((unsigned char)(fname_id != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    zT_302 = self->type_table;
    zT_303 = node_idx;
    zT_304 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_302, zT_303, zT_304);
    return target_type;
    z_bb_47:
    zT_299 = 1;
    zT_301 = fii + (unsigned int)((unsigned int)zT_299);
    fii = zT_301;
    goto z_bb_44;
    z_bb_48:
    zT_265 = 0;
    zT_266 = (unsigned int)zT_265;
    fi = zT_266;
    goto z_bb_50;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    if ((unsigned char)(fi < fcount)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_268 = self->registry;
    zT_269 = zT_268->fe_items;
    zT_270 = fstart + fi;
    zT_271 = zT_269[zT_270];
    zT_272 = zT_271.name_id;
    if ((unsigned char)(zT_272 == fname_id)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_296 = 1;
    zT_298 = fi + (unsigned int)((unsigned int)zT_296);
    fi = zT_298;
    goto z_bb_50;
    z_bb_54:
    zT_274 = fi_node.child_0;
    if ((unsigned char)(zT_274 != (unsigned int)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_278 = self->registry;
    zT_279 = zT_278->fe_items;
    zT_280 = fstart + fi;
    zT_281 = zT_279[zT_280];
    zT_282 = zT_281.type_id;
    field_type = zT_282;
    zT_283 = self;
    zT_284 = field_type;
    zF_9665A229_pushExpectedType(zT_283, zT_284);
    zT_286 = self;
    zT_287 = fi_node.child_0;
    zT_289 = zF_54F95822_semanticAnalyzerRes(zT_286, zT_287);
    init_type = zT_289;
    zT_290 = self;
    zF_BC478E78_popExpectedType(zT_290);
    zT_291 = self;
    zT_292 = fi_node.child_0;
    zT_293 = init_type;
    zT_294 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_291, zT_292, zT_293, zT_294);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_52;
}

/* semanticAnalyzerResolveAssign */
unsigned int zF_C0551BB8_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_22A7C88B_AstNode zT_25 = {0};
    zT_8143F551_AstKind zT_26;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int zT_38 = 0;
    zT_D3EB6303_StringInterner* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_42 = 0;
    zT_38C12417_SemanticAnalyzer* zT_44;
    unsigned int zT_45;
    unsigned int zT_47 = 0;
    zT_38C12417_SemanticAnalyzer* zT_49;
    unsigned int zT_50;
    zT_38C12417_SemanticAnalyzer* zT_52;
    unsigned int zT_53;
    unsigned int zT_55 = 0;
    zT_38C12417_SemanticAnalyzer* zT_56;
    unsigned char zT_59;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_38C12417_SemanticAnalyzer* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_74 = 0;
    zT_38C12417_SemanticAnalyzer* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned char zT_80 = 0;
    zT_338B7C76_TypeRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned char zT_86 = 0;
    zT_38C12417_SemanticAnalyzer* zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int zT_105;
    unsigned int zT_107;
    unsigned int zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_D155D06D_Type* zT_116;
    unsigned int zT_117;
    zT_D155D06D_Type zT_118;
    zT_33EF6BFB_TypeKind zT_119;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_D155D06D_Type* zT_122;
    unsigned int zT_123;
    zT_D155D06D_Type zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    int zT_127;
    unsigned char zT_128;
    zT_38C12417_SemanticAnalyzer* zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned char zT_132 = 0;
    int zT_133;
    unsigned char zT_134;
    zT_38C12417_SemanticAnalyzer* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned char zT_140 = 0;
    int zT_141;
    unsigned char zT_142;
    unsigned char zT_146;
    zT_338B7C76_TypeRegistry* zT_151;
    zT_42C2D6BF_EUPayload* zT_152;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_D155D06D_Type* zT_154;
    unsigned int zT_155;
    zT_D155D06D_Type zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    zT_42C2D6BF_EUPayload zT_159;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_42C2D6BF_EUPayload* zT_162;
    zT_338B7C76_TypeRegistry* zT_163;
    zT_D155D06D_Type* zT_164;
    unsigned int zT_165;
    zT_D155D06D_Type zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    zT_42C2D6BF_EUPayload zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    int zT_173;
    unsigned char zT_174;
    zT_F85C5DED_DiagnosticCollector* zT_176;
    unsigned char zT_177;
    unsigned int zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_186 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    zT_33EF6BFB_TypeKind zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    zT_33EF6BFB_TypeKind zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u ase;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    zT_22A7C88B_AstNode lhs_node;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u us_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0;
    unsigned int eff_src;
    zT_8F083A69_Slice_zT_0B42B2F8_u as1;
    zT_8F083A69_Slice_zT_0B42B2F8_u as2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u tma_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_3 = "ASE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ase = zT_4;
    zT_6 = ase;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_17 = node.child_0;
    if ((unsigned char)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->store;
    zT_22 = node.child_0;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    lhs_node = zT_25;
    zT_26 = lhs_node.kind;
    if ((unsigned char)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_49 = self;
    zT_50 = lhs;
    zF_9665A229_pushExpectedType(zT_49, zT_50);
    zT_52 = self;
    zT_53 = node.child_1;
    zT_55 = zF_54F95822_semanticAnalyzerRes(zT_52, zT_53);
    rhs = zT_55;
    zT_56 = self;
    zF_BC478E78_popExpectedType(zT_56);
    if ((unsigned char)(lhs == (unsigned int)(0))) goto z_bb_8; else goto z_bb_7;
    z_bb_3:
    zT_31 = "_";
    zT_33 = 1;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    us_str = zT_32;
    zT_34 = self->store;
    zT_35 = node.child_0;
    zT_38 = zF_53458827_astStoreIdentifier(zT_34, zT_35);
    zT_39 = self->interner;
    zT_40 = us_str;
    zT_42 = zF_50C274AF_stringInternerInter(zT_39, zT_40);
    if ((unsigned char)(zT_38 == zT_42)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_44 = self;
    zT_45 = node.child_1;
    zT_47 = zF_54F95822_semanticAnalyzerRes(zT_44, zT_45);
    (void)zT_47;
    return (unsigned int)(1);
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_59 = rhs == (unsigned int)(0);
    goto z_bb_9;
    z_bb_8:
    zT_59 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_59) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_63 = "AS0";
    zT_65 = 3;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    as0 = zT_64;
    zT_66 = as0;
    zF_48AC7B3A_markerWrite(zT_66);
    return (unsigned int)(1);
    z_bb_11:
    zT_69 = self;
    zT_70 = node.child_1;
    zT_71 = lhs;
    zT_72 = rhs;
    zT_74 = zF_FFC95E09_errLitSrcType(zT_69, zT_70, zT_71, zT_72);
    eff_src = zT_74;
    zT_75 = self;
    zT_76 = node.child_1;
    zT_77 = eff_src;
    zT_78 = lhs;
    zT_80 = zF_86AAA417_semanticAnalyzerMay(zT_75, zT_76, zT_77, zT_78);
    if (zT_80) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_82 = self->registry;
    zT_83 = eff_src;
    zT_84 = lhs;
    zT_86 = zF_683AEB7F_typeRegistryIsAssig(zT_82, zT_83, zT_84);
    if (zT_86) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_87 = self;
    zT_88 = node.child_1;
    zT_89 = eff_src;
    zT_90 = lhs;
    zF_DF7434EB_tryRecordCoercion(zT_87, zT_88, zT_89, zT_90);
    zT_93 = "AS1";
    zT_95 = 3;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    as1 = zT_94;
    zT_96 = as1;
    zF_48AC7B3A_markerWrite(zT_96);
    return lhs;
    z_bb_15:
    zT_98 = "AS2";
    zT_100 = 3;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    as2 = zT_99;
    zT_101 = as2;
    zF_48AC7B3A_markerWrite(zT_101);
    if ((unsigned char)(lhs != (unsigned int)(1))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_105 = node.span_start;
    sp = zT_105;
    zT_107 = node.span_len;
    zT_109 = sp + (unsigned int)((unsigned int)zT_107);
    ep = zT_109;
    zT_111 = "type mismatch in assignment — internal type representations differ; generated code may be incorrect";
    zT_113 = 101;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    tma_msg = zT_112;
    zT_115 = self->registry;
    zT_116 = zT_115->types_items;
    zT_117 = (unsigned int)eff_src;
    zT_118 = zT_116[zT_117];
    zT_119 = zT_118.kind;
    sk = zT_119;
    zT_121 = self->registry;
    zT_122 = zT_121->types_items;
    zT_123 = (unsigned int)lhs;
    zT_124 = zT_122[zT_123];
    zT_125 = zT_124.kind;
    tk = zT_125;
    zT_127 = 1;
    zT_128 = (unsigned char)zT_127;
    level = zT_128;
    zT_129 = self;
    zT_130 = eff_src;
    zT_131 = lhs;
    zT_132 = zF_148F8E19_semanticAnalyzerFnP(zT_129, zT_130, zT_131);
    if (zT_132) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    return (unsigned int)(1);
    z_bb_18:
    zT_133 = 0;
    zT_134 = (unsigned char)zT_133;
    level = zT_134;
    goto z_bb_19;
    z_bb_19:
    zT_135 = self;
    zT_136 = eff_src;
    zT_137 = lhs;
    zT_140 = zF_D728034A_isBShapeMismatch(zT_135, zT_136, zT_137, (unsigned char)(1));
    if (zT_140) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_141 = 0;
    zT_142 = (unsigned char)zT_141;
    level = zT_142;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_146 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_24;
    z_bb_23:
    zT_146 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_146) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_151 = self->registry;
    zT_152 = zT_151->eu_items;
    zT_153 = self->registry;
    zT_154 = zT_153->types_items;
    zT_155 = (unsigned int)eff_src;
    zT_156 = zT_154[zT_155];
    zT_157 = zT_156.payload_idx;
    zT_158 = (unsigned int)zT_157;
    zT_159 = zT_152[zT_158];
    eu_src = zT_159;
    zT_161 = self->registry;
    zT_162 = zT_161->eu_items;
    zT_163 = self->registry;
    zT_164 = zT_163->types_items;
    zT_165 = (unsigned int)lhs;
    zT_166 = zT_164[zT_165];
    zT_167 = zT_166.payload_idx;
    zT_168 = (unsigned int)zT_167;
    zT_169 = zT_162[zT_168];
    eu_tgt = zT_169;
    zT_170 = eu_src.error_set;
    zT_171 = eu_tgt.error_set;
    if ((unsigned char)(zT_170 == zT_171)) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_176 = self->diag;
    zT_177 = level;
    zT_179 = self->source_file_id;
    zT_180 = sp;
    zT_181 = ep;
    zT_182 = tma_msg;
    zT_186 = zF_C82559AC_diagnosticCollector(zT_176, zT_177, (unsigned short)(3000), zT_179, zT_180, zT_181, zT_182);
    di = zT_186;
    zT_187 = self->diag;
    zT_188 = di;
    zT_191 = sk;
    zT_192 = zF_C14453DE_typeKindSrcStr(zT_191);
    zT_189 = zT_192;
    zF_426E1F18_diagnosticCollector(zT_187, zT_188, zT_189);
    (void)self;
    zT_193 = self->diag;
    zT_194 = di;
    zT_197 = tk;
    zT_198 = zF_CC479241_typeKindTgtStr(zT_197);
    zT_195 = zT_198;
    zF_426E1F18_diagnosticCollector(zT_193, zT_194, zT_195);
    (void)self;
    goto z_bb_17;
    z_bb_27:
    zT_173 = 0;
    zT_174 = (unsigned char)zT_173;
    level = zT_174;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_26;
}

/* semanticAnalyzerResolveSwitchExpr */
unsigned int zF_2DB4F186_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_8143F551_AstKind zT_29;
    zT_79FAE712_u64 zT_32 = 0;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_55;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    int zT_61;
    unsigned char* zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65 = 0;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zT_8EED1867_ResolvedTypeTable* zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    zT_38C12417_SemanticAnalyzer* zT_92;
    unsigned int zT_93;
    unsigned int zT_95 = 0;
    unsigned int zT_98;
    unsigned char zT_101;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D155D06D_Type* zT_106;
    unsigned int zT_107;
    zT_D155D06D_Type zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    unsigned char zT_113;
    zT_33EF6BFB_TypeKind zT_114;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_33EF6BFB_TypeKind zT_123;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    unsigned char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_338B7C76_TypeRegistry* zT_143;
    zT_42C2D6BF_EUPayload* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_42C2D6BF_EUPayload zT_147;
    unsigned int zT_148;
    unsigned char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    zT_6B0A7D14_AstStore* zT_161;
    unsigned int zT_162;
    unsigned int zT_164 = 0;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_173;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    int zT_179;
    unsigned char* zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183 = 0;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned char* zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned char* zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    zT_8EED1867_ResolvedTypeTable* zT_201;
    unsigned int zT_202;
    unsigned int zT_206;
    unsigned int zT_211;
    unsigned int zT_213;
    int zT_215;
    unsigned char zT_216;
    int zT_218;
    unsigned int zT_219;
    unsigned int zT_221;
    zT_6B0A7D14_AstStore* zT_225;
    unsigned int zT_226;
    unsigned int zT_230 = 0;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    zT_22A7C88B_AstNode zT_235 = {0};
    unsigned char zT_236;
    int zT_241;
    unsigned char zT_242;
    unsigned char zT_243;
    unsigned char zT_248;
    unsigned char zT_249;
    unsigned char* zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    zT_F85C5DED_DiagnosticCollector* zT_258;
    unsigned int zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    unsigned int zT_269 = 0;
    unsigned int zT_272;
    zT_6B0A7D14_AstStore* zT_274;
    unsigned int zT_275;
    unsigned char* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    unsigned char* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    zT_6B0A7D14_AstStore* zT_290;
    unsigned int zT_291;
    zT_8143F551_AstKind zT_292;
    zT_79FAE712_u64 zT_295 = 0;
    unsigned int zT_299;
    unsigned char zT_302;
    zT_6B0A7D14_AstStore* zT_303;
    unsigned int zT_304;
    unsigned int zT_306 = 0;
    zT_6B0A7D14_AstStore* zT_310;
    unsigned int zT_311;
    unsigned int zT_313 = 0;
    int zT_315;
    unsigned int zT_316;
    zT_6B0A7D14_AstStore* zT_320;
    unsigned int zT_321;
    unsigned int zT_325 = 0;
    zT_6B0A7D14_AstStore* zT_327;
    unsigned int zT_328;
    zT_22A7C88B_AstNode zT_330 = {0};
    zT_8143F551_AstKind zT_332;
    unsigned int zT_333;
    unsigned char* zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned int zT_339;
    zT_8143F551_AstKind zT_340;
    zT_38C12417_SemanticAnalyzer* zT_344;
    unsigned int zT_345;
    unsigned int zT_346 = 0;
    zT_8143F551_AstKind zT_347;
    zT_38C12417_SemanticAnalyzer* zT_351;
    unsigned int zT_352;
    unsigned int zT_353 = 0;
    int zT_354;
    unsigned int zT_356;
    unsigned char zT_357;
    unsigned int zT_363;
    unsigned char* zT_365;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_366;
    unsigned int zT_367;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    unsigned int zT_369;
    unsigned char* zT_371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_372;
    unsigned int zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_374;
    zT_21D3708C_U32ToU32Map* zT_381;
    unsigned int zT_382;
    zT_6B0A7D14_AstStore* zT_384;
    unsigned int zT_385;
    unsigned int zT_389 = 0;
    zT_BAEE192E_Opt_10 zT_390 = {0};
    unsigned char zT_391;
    zT_338B7C76_TypeRegistry* zT_394;
    zT_D155D06D_Type* zT_395;
    unsigned int zT_396;
    unsigned int zT_397;
    zT_D155D06D_Type zT_398;
    zT_33EF6BFB_TypeKind zT_399;
    zT_338B7C76_TypeRegistry* zT_404;
    zT_54FF90FA_TaggedUnionPayload* zT_405;
    unsigned int zT_406;
    unsigned int zT_407;
    zT_54FF90FA_TaggedUnionPayload zT_408;
    zT_338B7C76_TypeRegistry* zT_410;
    zT_2DF01B61_FieldEntry* zT_411;
    unsigned int zT_412;
    unsigned int zT_415;
    zT_2DF01B61_FieldEntry zT_416;
    unsigned char* zT_418;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_419;
    unsigned int zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421;
    unsigned int zT_422;
    unsigned char* zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned int zT_426;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_427;
    unsigned int zT_428;
    unsigned char* zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_432;
    unsigned int zT_433;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    zT_33EF6BFB_TypeKind zT_436;
    unsigned int zT_438;
    unsigned int zT_439;
    zT_38C12417_SemanticAnalyzer* zT_441;
    unsigned int* zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    unsigned int* zT_445;
    unsigned int zT_446;
    unsigned int zT_447;
    unsigned char* zT_451;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_452;
    unsigned int zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_454;
    unsigned int zT_455;
    unsigned char* zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_458;
    unsigned int zT_459;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_460;
    unsigned int zT_461;
    unsigned char* zT_464;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_465;
    unsigned int zT_466;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_467;
    unsigned int zT_468;
    zT_38C12417_SemanticAnalyzer* zT_469;
    unsigned int zT_470;
    unsigned int zT_471;
    unsigned char zT_475;
    zT_6B0A7D14_AstStore* zT_476;
    unsigned int zT_477;
    unsigned int zT_479 = 0;
    zT_6B0A7D14_AstStore* zT_483;
    unsigned int zT_484;
    unsigned int zT_486 = 0;
    int zT_488;
    unsigned int zT_489;
    zT_6B0A7D14_AstStore* zT_493;
    unsigned int zT_494;
    unsigned int zT_498 = 0;
    zT_6B0A7D14_AstStore* zT_500;
    unsigned int zT_501;
    zT_22A7C88B_AstNode zT_503 = {0};
    zT_8143F551_AstKind zT_504;
    zT_38C12417_SemanticAnalyzer* zT_508;
    unsigned int zT_509;
    zT_38C12417_SemanticAnalyzer* zT_510;
    unsigned int zT_511;
    unsigned int zT_512 = 0;
    zT_38C12417_SemanticAnalyzer* zT_513;
    int zT_514;
    unsigned int zT_516;
    unsigned int zT_518;
    unsigned int zT_520;
    zT_6B0A7D14_AstStore* zT_524;
    unsigned int zT_525;
    zT_22A7C88B_AstNode zT_527 = {0};
    zT_8143F551_AstKind zT_528;
    unsigned int zT_529;
    unsigned char* zT_531;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_532;
    unsigned int zT_533;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_534;
    unsigned int zT_535;
    unsigned char* zT_537;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_538;
    unsigned int zT_539;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_540;
    unsigned int zT_541;
    unsigned int zT_543;
    zT_38C12417_SemanticAnalyzer* zT_545;
    unsigned int zT_546;
    unsigned int zT_548 = 0;
    unsigned int zT_549;
    unsigned int zT_551;
    unsigned int* zT_555;
    unsigned int zT_556;
    unsigned int zT_557;
    zT_38C12417_SemanticAnalyzer* zT_560;
    unsigned int zT_561;
    unsigned char* zT_563;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_564;
    unsigned int zT_565;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_566;
    unsigned int zT_567;
    unsigned char* zT_570;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_571;
    unsigned int zT_572;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_573;
    unsigned int zT_574;
    unsigned char* zT_576;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_577;
    unsigned int zT_578;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_579;
    unsigned int zT_580;
    unsigned char* zT_583;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_584;
    unsigned int zT_585;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_586;
    unsigned char* zT_590;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_591;
    unsigned int zT_592;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_593;
    unsigned int zT_594;
    zT_38C12417_SemanticAnalyzer* zT_600;
    unsigned int zT_601 = 0;
    unsigned int zT_603;
    unsigned char zT_606;
    zT_6B0A7D14_AstStore* zT_607;
    unsigned int zT_608;
    zT_22A7C88B_AstNode zT_611 = {0};
    zT_8143F551_AstKind zT_612;
    unsigned char zT_616;
    unsigned char zT_619;
    zT_338B7C76_TypeRegistry* zT_622;
    unsigned int zT_628 = 0;
    unsigned char zT_631;
    unsigned char zT_634;
    zT_0FB7FB13_CoercionKind zT_635;
    zT_338B7C76_TypeRegistry* zT_636;
    unsigned int zT_637;
    unsigned int zT_638;
    zT_0FB7FB13_CoercionKind zT_640 = 0;
    unsigned char zT_641 = 0;
    unsigned int zT_642;
    zT_38C12417_SemanticAnalyzer* zT_643;
    unsigned int zT_644;
    unsigned int zT_645;
    unsigned int zT_646;
    unsigned int zT_648;
    zT_338B7C76_TypeRegistry* zT_650;
    unsigned int zT_651;
    unsigned int zT_652;
    zT_0FB7FB13_CoercionKind zT_654 = 0;
    zT_38C12417_SemanticAnalyzer* zT_658;
    unsigned int zT_659;
    unsigned int zT_660;
    unsigned int zT_661;
    zT_338B7C76_TypeRegistry* zT_663;
    unsigned int zT_664;
    unsigned int zT_665;
    zT_0FB7FB13_CoercionKind zT_667 = 0;
    zT_38C12417_SemanticAnalyzer* zT_671;
    unsigned int zT_672;
    unsigned int zT_673;
    unsigned int zT_674;
    unsigned int zT_675;
    unsigned int zT_677;
    zT_338B7C76_TypeRegistry* zT_678;
    unsigned int zT_679;
    unsigned char zT_681 = 0;
    unsigned int zT_682;
    unsigned char zT_685;
    unsigned char* zT_689;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_690;
    unsigned int zT_691;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_692;
    unsigned char* zT_696;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_697;
    unsigned int zT_698;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_699;
    unsigned int zT_700;
    unsigned char* zT_702;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_703;
    unsigned int zT_704;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705;
    unsigned int zT_706;
    unsigned char* zT_708;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    unsigned int zT_710;
    zT_338B7C76_TypeRegistry* zT_712;
    zT_D155D06D_Type* zT_713;
    unsigned int zT_714;
    zT_D155D06D_Type zT_715;
    zT_33EF6BFB_TypeKind zT_716;
    unsigned int zT_717;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_718;
    unsigned int zT_719;
    unsigned char* zT_721;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_722;
    unsigned int zT_723;
    zT_338B7C76_TypeRegistry* zT_725;
    zT_D155D06D_Type* zT_726;
    unsigned int zT_727;
    zT_D155D06D_Type zT_728;
    zT_33EF6BFB_TypeKind zT_729;
    unsigned int zT_730;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_731;
    unsigned int zT_732;
    unsigned char* zT_734;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    unsigned int zT_736;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_737;
    unsigned int zT_738;
    unsigned char* zT_741;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_742;
    unsigned int zT_743;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_744;
    unsigned int zT_745;
    unsigned char* zT_748;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_749;
    unsigned int zT_750;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_751;
    unsigned char zT_753;
    unsigned char* zT_756;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    unsigned char* zT_763;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_764;
    unsigned int zT_765;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_766;
    unsigned int zT_767;
    zT_8EED1867_ResolvedTypeTable* zT_768;
    unsigned int zT_769;
    int zT_773;
    unsigned int zT_775;
    unsigned int zT_781;
    zT_8EED1867_ResolvedTypeTable* zT_782;
    unsigned int zT_783;
    unsigned int zT_784;
    unsigned char* zT_787;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_788;
    unsigned int zT_789;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_790;
    unsigned int zT_791;
    unsigned char* zT_793;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_794;
    unsigned int zT_795;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_796;
    unsigned int zT_797;
    unsigned int zT_798;
    zT_8F083A69_Slice_zT_0B42B2F8_u se;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swi_dm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_m;
    zT_5A26C2ED_Arr_unsigned_char_1 sep_b;
    unsigned int sep_l;
    unsigned int sep_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_nl;
    unsigned int cond_type;
    unsigned int cond_es;
    zT_D155D06D_Type cond_ty;
    unsigned int prongs_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_nl;
    zT_42C2D6BF_EUPayload cond_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pr0_b;
    unsigned int pr0_l;
    unsigned int pr0_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_nl;
    unsigned int unified;
    unsigned int unified_node;
    unsigned char has_else;
    unsigned int i;
    unsigned int sw_base;
    unsigned int prong_i;
    zT_22A7C88B_AstNode prong;
    zT_8F083A69_Slice_zT_0B42B2F8_u swec_msg;
    unsigned int pct;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppt_m;
    unsigned int case_n;
    unsigned int ci;
    unsigned int case_i;
    zT_22A7C88B_AstNode case_node;
    unsigned int cc_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_m;
    unsigned int cap_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_lm;
    zT_BAEE192E_Opt_10 ev;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_rm;
    unsigned int idx;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_tm;
    unsigned int es_case_n;
    unsigned int es_ci;
    unsigned int pbd_b0;
    unsigned int pbd_k0;
    unsigned int es_case_i;
    zT_22A7C88B_AstNode es_case_node;
    zT_22A7C88B_AstNode pbd_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_km;
    unsigned int saved_tu;
    unsigned int bt;
    unsigned int wi;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_fm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_tm;
    unsigned int sw_exp0;
    unsigned int sw_peer;
    unsigned int unum;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_um;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_tk_m;
    unsigned int mix_tk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_uk_m;
    unsigned int mix_uk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_cd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_b_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_ni_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_tm;
    zT_2 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_2 + (unsigned int)(1));
    zT_6 = "SE";
    zT_8 = 2;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    se = zT_7;
    zT_9 = se;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    node = zT_14;
    zT_16 = "SWI:n";
    zT_18 = 5;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    swu_im = zT_17;
    zT_19 = swu_im;
    zT_20 = node_idx;
    zF_C914CB83_markerWriteInt(zT_19, zT_20);
    zT_22 = "SWI:p";
    zT_24 = 5;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    swu_pm = zT_23;
    zT_25 = swu_pm;
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_29 = node.kind;
    zT_32 = zF_0E4E10C6_astStoreNodePayload(zT_27, zT_28, zT_29);
    zF_C914CB83_markerWriteInt(zT_25, (unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_32 & (zT_79FAE712_u64)(4294967295u))));
    zT_37 = "SWI:d";
    zT_39 = 5;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    swi_dm = zT_38;
    zT_40 = swi_dm;
    zT_41 = self->switch_depth;
    zF_C914CB83_markerWriteInt(zT_40, zT_41);
    zT_43 = self->store;
    zT_44 = node_idx;
    zT_46 = zF_8BA26B9E_astStoreNodePayload(zT_43, zT_44);
    if ((unsigned char)(zT_46 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_50 = "P0: n";
    zT_52 = 5;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    sep_m = zT_51;
    zT_53 = sep_m;
    zF_48AC7B3A_markerWrite(zT_53);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_55[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        sep_b[_i] = zT_55[_i];
        _i++;
    }
}
    zT_57 = node_idx;
    zT_61 = 0;
    zT_62 = (unsigned char*)((unsigned char*)sep_b) + zT_61;
    zT_63 = (unsigned int)(10) - zT_61;
    zT_64.ptr = zT_62;
    zT_64.len = zT_63;
    zT_58 = zT_64;
    zT_65 = zF_A7504564_itoa(zT_57, zT_58);
    sep_l = zT_65;
    zT_69 = (unsigned int)(9) - (unsigned int)((unsigned int)sep_l);
    sep_s = zT_69;
    zT_74 = (unsigned char*)((unsigned char*)sep_b) + sep_s;
    zT_75 = (unsigned int)(9) - sep_s;
    zT_76.ptr = zT_74;
    zT_76.len = zT_75;
    zT_70 = zT_76;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_78 = "\n";
    zT_80 = 1;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    sep_nl = zT_79;
    zT_81 = sep_nl;
    zF_48AC7B3A_markerWrite(zT_81);
    zT_82 = self->type_table;
    zT_83 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_82, zT_83, (unsigned int)(1));
    zT_87 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_87 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_2:
    zT_92 = self;
    zT_93 = node.child_0;
    zT_95 = zF_54F95822_semanticAnalyzerRes(zT_92, zT_93);
    cond_type = zT_95;
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_98 = 0;
    cond_es = zT_98;
    if ((unsigned char)(cond_type != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_101 = cond_type != (unsigned int)(1);
    goto z_bb_5;
    z_bb_4:
    zT_101 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_101) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_105 = self->registry;
    zT_106 = zT_105->types_items;
    zT_107 = (unsigned int)cond_type;
    zT_108 = zT_106[zT_107];
    cond_ty = zT_108;
    zT_109 = cond_ty.kind;
    if ((unsigned char)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_9; else goto z_bb_8;
    z_bb_7:
    zT_161 = self->store;
    zT_162 = node_idx;
    zT_164 = zF_152E19CB_astStoreNodeExtraCh(zT_161, zT_162);
    prongs_n = zT_164;
    if ((unsigned char)(prongs_n == (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_8:
    zT_114 = cond_ty.kind;
    zT_113 = zT_114 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_10;
    z_bb_9:
    zT_113 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_113) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    self->current_switch_cond_tu = cond_type;
    zT_119 = "Z";
    zT_121 = 1;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    rs = zT_120;
    zT_122 = rs;
    zF_48AC7B3A_markerWrite(zT_122);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_7;
    z_bb_13:
    zT_123 = cond_ty.kind;
    if ((unsigned char)(zT_123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cond_es = cond_type;
    zT_128 = "SWES:e";
    zT_130 = 6;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    swes_m = zT_129;
    zT_131 = swes_m;
    zT_132 = cond_es;
    zF_C914CB83_markerWriteInt(zT_131, zT_132);
    zT_134 = "\n";
    zT_136 = 1;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    swes_nl = zT_135;
    zT_137 = swes_nl;
    zF_48AC7B3A_markerWrite(zT_137);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_138 = cond_ty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_143 = self->registry;
    zT_144 = zT_143->eu_items;
    zT_145 = cond_ty.payload_idx;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zT_144[zT_146];
    cond_eu = zT_147;
    zT_148 = cond_eu.error_set;
    cond_es = zT_148;
    zT_150 = "SWEU:e";
    zT_152 = 6;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    sweu_m = zT_151;
    zT_153 = sweu_m;
    zT_154 = cond_es;
    zF_C914CB83_markerWriteInt(zT_153, zT_154);
    zT_156 = "\n";
    zT_158 = 1;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    sweu_nl = zT_157;
    zT_159 = sweu_nl;
    zF_48AC7B3A_markerWrite(zT_159);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_168 = "PL0:n";
    zT_170 = 5;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    pr0_m = zT_169;
    zT_171 = pr0_m;
    zF_48AC7B3A_markerWrite(zT_171);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_173[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pr0_b[_i] = zT_173[_i];
        _i++;
    }
}
    zT_175 = node_idx;
    zT_179 = 0;
    zT_180 = (unsigned char*)((unsigned char*)pr0_b) + zT_179;
    zT_181 = (unsigned int)(10) - zT_179;
    zT_182.ptr = zT_180;
    zT_182.len = zT_181;
    zT_176 = zT_182;
    zT_183 = zF_A7504564_itoa(zT_175, zT_176);
    pr0_l = zT_183;
    zT_187 = (unsigned int)(9) - (unsigned int)((unsigned int)pr0_l);
    pr0_s = zT_187;
    zT_192 = (unsigned char*)((unsigned char*)pr0_b) + pr0_s;
    zT_193 = (unsigned int)(9) - pr0_s;
    zT_194.ptr = zT_192;
    zT_194.len = zT_193;
    zT_188 = zT_194;
    zF_48AC7B3A_markerWrite(zT_188);
    zT_196 = "\n";
    zT_198 = 1;
    zT_197.ptr = zT_196;
    zT_197.len = zT_198;
    pr0_nl = zT_197;
    zT_199 = pr0_nl;
    zF_48AC7B3A_markerWrite(zT_199);
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_201 = self->type_table;
    zT_202 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_201, zT_202, (unsigned int)(1));
    zT_206 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_206 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_20:
    zT_211 = 0;
    unified = zT_211;
    zT_213 = 0;
    unified_node = zT_213;
    zT_215 = 0;
    zT_216 = (unsigned char)zT_215;
    has_else = zT_216;
    zT_218 = 0;
    zT_219 = (unsigned int)zT_218;
    i = zT_219;
    zT_221 = self->stmt_work_len;
    sw_base = zT_221;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(i < (unsigned int)((unsigned int)prongs_n))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_225 = self->store;
    zT_226 = node_idx;
    zT_230 = zF_B10B1BC1_astStoreNodeExtraCh(zT_225, zT_226, (unsigned int)((unsigned int)i));
    prong_i = zT_230;
    zT_232 = self->store;
    zT_233 = prong_i;
    zT_235 = zF_FCDD1D35_astStoreNodeAt(zT_232, zT_233);
    prong = zT_235;
    zT_236 = prong.flags;
    if ((unsigned char)((unsigned char)(zT_236 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    self->current_switch_cond_tu = (unsigned int)(0);
    if ((unsigned char)(has_else == (unsigned char)(0))) goto z_bb_119; else goto z_bb_120;
    z_bb_24:
    zT_773 = 1;
    zT_775 = i + (unsigned int)((unsigned int)zT_773);
    i = zT_775;
    goto z_bb_21;
    z_bb_25:
    zT_241 = 1;
    zT_242 = (unsigned char)zT_241;
    has_else = zT_242;
    goto z_bb_26;
    z_bb_26:
    zT_243 = prong.flags;
    if ((unsigned char)((unsigned char)(zT_243 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_249 = prong.flags;
    zT_248 = (unsigned char)(zT_249 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_29;
    z_bb_28:
    zT_248 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_248) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_255 = "switch else-prong capture (else => |capture|) is not supported";
    zT_257 = 62;
    zT_256.ptr = zT_255;
    zT_256.len = zT_257;
    swec_msg = zT_256;
    zT_258 = self->diag;
    zT_261 = self->source_file_id;
    zT_262 = node_idx;
    zT_263 = node_idx;
    zT_264 = swec_msg;
    zT_269 = zF_C82559AC_diagnosticCollector(zT_258, (unsigned char)(0), (unsigned short)(3001), zT_261, zT_262, zT_263, zT_264);
    (void)zT_269;
    return (unsigned int)(1);
    z_bb_31:
    zT_272 = self->current_switch_cond_tu;
    pct = zT_272;
    zT_274 = self->store;
    zT_275 = prong_i;
    (void)zF_8BA26B9E_astStoreNodePayload(zT_274, zT_275);
    zT_279 = "PCT:C";
    zT_281 = 5;
    zT_280.ptr = zT_279;
    zT_280.len = zT_281;
    pct_m2 = zT_280;
    zT_282 = pct_m2;
    zT_283 = pct;
    zF_C914CB83_markerWriteInt(zT_282, zT_283);
    zT_285 = "PCT:P";
    zT_287 = 5;
    zT_286.ptr = zT_285;
    zT_286.len = zT_287;
    ppt_m = zT_286;
    zT_288 = ppt_m;
    zT_290 = self->store;
    zT_291 = prong_i;
    zT_292 = prong.kind;
    zT_295 = zF_0E4E10C6_astStoreNodePayload(zT_290, zT_291, zT_292);
    zF_C914CB83_markerWriteInt(zT_288, (unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_295 & (zT_79FAE712_u64)(4294967295u))));
    zT_299 = self->current_switch_cond_tu;
    if ((unsigned char)(zT_299 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_303 = self->store;
    zT_304 = prong_i;
    zT_306 = zF_8BA26B9E_astStoreNodePayload(zT_303, zT_304);
    zT_302 = zT_306 != (unsigned int)(0);
    goto z_bb_34;
    z_bb_33:
    zT_302 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_302) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_310 = self->store;
    zT_311 = prong_i;
    zT_313 = zF_152E19CB_astStoreNodeExtraCh(zT_310, zT_311);
    case_n = zT_313;
    zT_315 = 0;
    zT_316 = (unsigned int)zT_315;
    ci = zT_316;
    goto z_bb_37;
    z_bb_36:
    if ((unsigned char)(cond_es != (unsigned int)(0))) goto z_bb_57; else goto z_bb_58;
    z_bb_37:
    if ((unsigned char)(ci < (unsigned int)((unsigned int)case_n))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_320 = self->store;
    zT_321 = prong_i;
    zT_325 = zF_B10B1BC1_astStoreNodeExtraCh(zT_320, zT_321, (unsigned int)((unsigned int)ci));
    case_i = zT_325;
    zT_327 = self->store;
    zT_328 = case_i;
    zT_330 = zF_FCDD1D35_astStoreNodeAt(zT_327, zT_328);
    case_node = zT_330;
    zT_332 = case_node.kind;
    zT_333 = (unsigned int)zT_332;
    cc_val = zT_333;
    zT_335 = "CC:K";
    zT_337 = 4;
    zT_336.ptr = zT_335;
    zT_336.len = zT_337;
    cc_m = zT_336;
    zT_338 = cc_m;
    zT_339 = cc_val;
    zF_C914CB83_markerWriteInt(zT_338, zT_339);
    zT_340 = case_node.kind;
    if ((unsigned char)(zT_340 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_41; else goto z_bb_43;
    z_bb_39:
    zT_357 = prong.flags;
    if ((unsigned char)((unsigned char)(zT_357 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_40:
    zT_354 = 1;
    zT_356 = ci + (unsigned int)((unsigned int)zT_354);
    ci = zT_356;
    goto z_bb_37;
    z_bb_41:
    zT_344 = self;
    zT_345 = case_i;
    zT_346 = zF_8C008E53_semanticAnalyzerRes(zT_344, zT_345);
    (void)zT_346;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_347 = case_node.kind;
    if ((unsigned char)(zT_347 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_351 = self;
    zT_352 = case_i;
    zT_353 = zF_8C008E53_semanticAnalyzerRes(zT_351, zT_352);
    (void)zT_353;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_363 = prong.child_1;
    cap_name = zT_363;
    zT_365 = "SCE:p";
    zT_367 = 5;
    zT_366.ptr = zT_365;
    zT_366.len = zT_367;
    sce_pm = zT_366;
    zT_368 = sce_pm;
    zT_369 = cap_name;
    zF_C914CB83_markerWriteInt(zT_368, zT_369);
    zT_371 = "SCE:l";
    zT_373 = 5;
    zT_372.ptr = zT_371;
    zT_372.len = zT_373;
    sce_lm = zT_372;
    zT_374 = sce_lm;
    zF_C914CB83_markerWriteInt(zT_374, (unsigned int)((unsigned int)case_n));
    if ((unsigned char)((unsigned int)((unsigned int)case_n) > (unsigned int)(0))) goto z_bb_48; else goto z_bb_50;
    z_bb_47:
    goto z_bb_36;
    z_bb_48:
    zT_381 = self->enum_value_table;
    zT_384 = self->store;
    zT_385 = prong_i;
    zT_389 = zF_B10B1BC1_astStoreNodeExtraCh(zT_384, zT_385, (unsigned int)(0));
    zT_382 = zT_389;
    zT_390 = zF_F3EE5998_u32ToU32MapGet(zT_381, zT_382);
    ev = zT_390;
    zT_391 = ev.has_value;
    if (zT_391) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_464 = "SCE:R";
    zT_466 = 5;
    zT_465.ptr = zT_464;
    zT_465.len = zT_466;
    sce_rm = zT_465;
    zT_467 = sce_rm;
    zT_468 = cap_name;
    zF_C914CB83_markerWriteInt(zT_467, zT_468);
    zT_469 = self;
    zT_470 = cap_name;
    zT_471 = self->current_switch_cond_tu;
    zF_7BD72017_registerLocalDecl(zT_469, zT_470, zT_471);
    goto z_bb_49;
    z_bb_51:
    idx = ev.value;
    zT_394 = self->registry;
    zT_395 = zT_394->types_items;
    zT_396 = self->current_switch_cond_tu;
    zT_397 = (unsigned int)zT_396;
    zT_398 = zT_395[zT_397];
    tu_ty = zT_398;
    zT_399 = tu_ty.kind;
    if ((unsigned char)(zT_399 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_404 = self->registry;
    zT_405 = zT_404->tu_items;
    zT_406 = tu_ty.payload_idx;
    zT_407 = (unsigned int)zT_406;
    zT_408 = zT_405[zT_407];
    tp = zT_408;
    zT_410 = self->registry;
    zT_411 = zT_410->fe_items;
    zT_412 = tp.fields_start;
    zT_415 = (unsigned int)((unsigned int)zT_412) + (unsigned int)((unsigned int)idx);
    zT_416 = zT_411[zT_415];
    fe = zT_416;
    zT_418 = "SCFE:n";
    zT_420 = 6;
    zT_419.ptr = zT_418;
    zT_419.len = zT_420;
    scfe_nm = zT_419;
    zT_421 = scfe_nm;
    zT_422 = cap_name;
    zF_C914CB83_markerWriteInt(zT_421, zT_422);
    zT_424 = "SCFE:t";
    zT_426 = 6;
    zT_425.ptr = zT_424;
    zT_425.len = zT_426;
    scfe_tm = zT_425;
    zT_427 = scfe_tm;
    zT_428 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_427, zT_428);
    zT_431 = "SCFE:k";
    zT_433 = 6;
    zT_432.ptr = zT_431;
    zT_432.len = zT_433;
    scfe_km = zT_432;
    zT_434 = scfe_km;
    zT_436 = tu_ty.kind;
    zF_C914CB83_markerWriteInt(zT_434, (unsigned int)((unsigned int)zT_436));
    zT_438 = self->local_decl_count;
    zT_439 = self->local_decl_cap;
    if ((unsigned char)(zT_438 >= zT_439)) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_441 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_441);
    goto z_bb_56;
    z_bb_56:
    zT_442 = self->local_decl_names;
    zT_443 = self->local_decl_count;
    zT_442[zT_443] = cap_name;
    zT_444 = fe.type_id;
    zT_445 = self->local_decl_types;
    zT_446 = self->local_decl_count;
    zT_445[zT_446] = zT_444;
    zT_447 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_447 + (unsigned int)(1));
    zT_451 = "SCAX:N";
    zT_453 = 6;
    zT_452.ptr = zT_451;
    zT_452.len = zT_453;
    scax_m = zT_452;
    zT_454 = scax_m;
    zT_455 = cap_name;
    zF_C914CB83_markerWriteInt(zT_454, zT_455);
    zT_457 = "SCAX:T";
    zT_459 = 6;
    zT_458.ptr = zT_457;
    zT_458.len = zT_459;
    scax_tm = zT_458;
    zT_460 = scax_tm;
    zT_461 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_460, zT_461);
    goto z_bb_54;
    z_bb_57:
    zT_476 = self->store;
    zT_477 = prong_i;
    zT_479 = zF_8BA26B9E_astStoreNodePayload(zT_476, zT_477);
    zT_475 = zT_479 != (unsigned int)(0);
    goto z_bb_59;
    z_bb_58:
    zT_475 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_475) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_483 = self->store;
    zT_484 = prong_i;
    zT_486 = zF_152E19CB_astStoreNodeExtraCh(zT_483, zT_484);
    es_case_n = zT_486;
    zT_488 = 0;
    zT_489 = (unsigned int)zT_488;
    es_ci = zT_489;
    goto z_bb_62;
    z_bb_61:
    zT_518 = prong.child_0;
    pbd_b0 = zT_518;
    zT_520 = 0;
    pbd_k0 = zT_520;
    if ((unsigned char)(pbd_b0 != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_62:
    if ((unsigned char)(es_ci < (unsigned int)((unsigned int)es_case_n))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_493 = self->store;
    zT_494 = prong_i;
    zT_498 = zF_B10B1BC1_astStoreNodeExtraCh(zT_493, zT_494, (unsigned int)((unsigned int)es_ci));
    es_case_i = zT_498;
    zT_500 = self->store;
    zT_501 = es_case_i;
    zT_503 = zF_FCDD1D35_astStoreNodeAt(zT_500, zT_501);
    es_case_node = zT_503;
    zT_504 = es_case_node.kind;
    if ((unsigned char)(zT_504 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_514 = 1;
    zT_516 = es_ci + (unsigned int)((unsigned int)zT_514);
    es_ci = zT_516;
    goto z_bb_62;
    z_bb_66:
    zT_508 = self;
    zT_509 = cond_es;
    zF_9665A229_pushExpectedType(zT_508, zT_509);
    zT_510 = self;
    zT_511 = es_case_i;
    zT_512 = zF_54F95822_semanticAnalyzerRes(zT_510, zT_511);
    (void)zT_512;
    zT_513 = self;
    zF_BC478E78_popExpectedType(zT_513);
    goto z_bb_67;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_524 = self->store;
    zT_525 = pbd_b0;
    zT_527 = zF_FCDD1D35_astStoreNodeAt(zT_524, zT_525);
    pbd_n = zT_527;
    zT_528 = pbd_n.kind;
    zT_529 = (unsigned int)zT_528;
    pbd_k0 = zT_529;
    goto z_bb_69;
    z_bb_69:
    zT_531 = "PBD:N";
    zT_533 = 5;
    zT_532.ptr = zT_531;
    zT_532.len = zT_533;
    pbd_nm = zT_532;
    zT_534 = pbd_nm;
    zT_535 = pbd_b0;
    zF_C914CB83_markerWriteInt(zT_534, zT_535);
    zT_537 = "PBD:K";
    zT_539 = 5;
    zT_538.ptr = zT_537;
    zT_538.len = zT_539;
    pbd_km = zT_538;
    zT_540 = pbd_km;
    zT_541 = pbd_k0;
    zF_C914CB83_markerWriteInt(zT_540, zT_541);
    zT_543 = self->current_switch_cond_tu;
    saved_tu = zT_543;
    zT_545 = self;
    zT_546 = prong.child_0;
    zT_548 = zF_54F95822_semanticAnalyzerRes(zT_545, zT_546);
    bt = zT_548;
    self->current_switch_cond_tu = saved_tu;
    goto z_bb_70;
    z_bb_70:
    zT_549 = self->stmt_work_len;
    if ((unsigned char)(zT_549 > sw_base)) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_551 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_551 - (unsigned int)(1));
    zT_555 = self->stmt_work_items;
    zT_556 = self->stmt_work_len;
    zT_557 = zT_555[zT_556];
    wi = zT_557;
    if ((unsigned char)(wi != (unsigned int)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_563 = "PCT:n";
    zT_565 = 5;
    zT_564.ptr = zT_563;
    zT_564.len = zT_565;
    pct_m = zT_564;
    zT_566 = pct_m;
    zT_567 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_566, zT_567);
    zT_570 = "PCT:b";
    zT_572 = 5;
    zT_571.ptr = zT_570;
    zT_571.len = zT_572;
    pct_bm = zT_571;
    zT_573 = pct_bm;
    zT_574 = bt;
    zF_C914CB83_markerWriteInt(zT_573, zT_574);
    zT_576 = "PCT:f";
    zT_578 = 5;
    zT_577.ptr = zT_576;
    zT_577.len = zT_578;
    pct_fm = zT_577;
    zT_579 = pct_fm;
    zT_580 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_579, zT_580);
    zT_583 = "SWPB:i";
    zT_585 = 6;
    zT_584.ptr = zT_583;
    zT_584.len = zT_585;
    swpb_im = zT_584;
    zT_586 = swpb_im;
    zF_C914CB83_markerWriteInt(zT_586, (unsigned int)((unsigned int)i));
    zT_590 = "SWPB:t";
    zT_592 = 6;
    zT_591.ptr = zT_590;
    zT_591.len = zT_592;
    swpb_tm = zT_591;
    zT_593 = swpb_tm;
    zT_594 = bt;
    zF_C914CB83_markerWriteInt(zT_593, zT_594);
    if ((unsigned char)(bt == (unsigned int)(3))) goto z_bb_76; else goto z_bb_78;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    zT_560 = self;
    zT_561 = wi;
    zF_10A0DC35_semanticAnalyzerRes(zT_560, zT_561);
    goto z_bb_75;
    z_bb_75:
    goto z_bb_73;
    z_bb_76:
    goto z_bb_77;
    z_bb_77:
    goto z_bb_24;
    z_bb_78:
    if ((unsigned char)(unified == (unsigned int)(0))) goto z_bb_79; else goto z_bb_81;
    z_bb_79:
    zT_600 = self;
    zT_601 = zF_4DE7C2BC_topExpectedType(zT_600);
    sw_exp0 = zT_601;
    sw_peer = sw_exp0;
    zT_603 = prong.child_0;
    if ((unsigned char)(zT_603 != (unsigned int)(0))) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    goto z_bb_77;
    z_bb_81:
    if ((unsigned char)(bt == unified)) goto z_bb_102; else goto z_bb_104;
    z_bb_82:
    zT_607 = self->store;
    zT_608 = prong.child_0;
    zT_611 = zF_FCDD1D35_astStoreNodeAt(zT_607, zT_608);
    zT_612 = zT_611.kind;
    zT_606 = zT_612 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_84;
    z_bb_83:
    zT_606 = 0;
    goto z_bb_84;
    z_bb_84:
    if (zT_606) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    if ((unsigned char)(sw_exp0 == (unsigned int)(0))) goto z_bb_89; else goto z_bb_88;
    z_bb_86:
    zT_616 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_616) goto z_bb_91; else goto z_bb_92;
    z_bb_88:
    zT_619 = sw_exp0 == (unsigned int)(1);
    goto z_bb_90;
    z_bb_89:
    zT_619 = 1;
    goto z_bb_90;
    z_bb_90:
    zT_616 = zT_619;
    goto z_bb_87;
    z_bb_91:
    zT_622 = self->registry;
    zT_628 = zF_8FC81A87_typeRegistryGetOrCr(zT_622, (unsigned int)(8), (unsigned char)(1));
    sw_peer = zT_628;
    goto z_bb_92;
    z_bb_92:
    if ((unsigned char)(sw_peer != (unsigned int)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_631 = sw_peer != (unsigned int)(1);
    goto z_bb_95;
    z_bb_94:
    zT_631 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_631) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_636 = self->registry;
    zT_637 = bt;
    zT_638 = sw_peer;
    zT_640 = zF_713658BF_classifyCoercion(zT_636, zT_637, zT_638);
    zT_635 = zT_640;
    zT_641 = zF_71304A07_isStringLiteralSlic(zT_635);
    zT_634 = zT_641;
    goto z_bb_98;
    z_bb_97:
    zT_634 = 0;
    goto z_bb_98;
    z_bb_98:
    if (zT_634) goto z_bb_99; else goto z_bb_101;
    z_bb_99:
    unified = sw_peer;
    zT_642 = prong.child_0;
    unified_node = zT_642;
    zT_643 = self;
    zT_644 = prong.child_0;
    zT_645 = bt;
    zT_646 = sw_peer;
    zF_DF7434EB_tryRecordCoercion(zT_643, zT_644, zT_645, zT_646);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_80;
    z_bb_101:
    unified = bt;
    zT_648 = prong.child_0;
    unified_node = zT_648;
    goto z_bb_100;
    z_bb_102:
    goto z_bb_103;
    z_bb_103:
    goto z_bb_80;
    z_bb_104:
    zT_650 = self->registry;
    zT_651 = bt;
    zT_652 = unified;
    zT_654 = zF_713658BF_classifyCoercion(zT_650, zT_651, zT_652);
    if ((unsigned char)(zT_654 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    zT_658 = self;
    zT_659 = prong.child_0;
    zT_660 = bt;
    zT_661 = unified;
    zF_DF7434EB_tryRecordCoercion(zT_658, zT_659, zT_660, zT_661);
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_663 = self->registry;
    zT_664 = unified;
    zT_665 = bt;
    zT_667 = zF_713658BF_classifyCoercion(zT_663, zT_664, zT_665);
    if ((unsigned char)(zT_667 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_108; else goto z_bb_110;
    z_bb_108:
    zT_671 = self;
    zT_672 = unified_node;
    zT_673 = unified;
    zT_674 = bt;
    zF_DF7434EB_tryRecordCoercion(zT_671, zT_672, zT_673, zT_674);
    unified = bt;
    zT_675 = prong.child_0;
    unified_node = zT_675;
    goto z_bb_109;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    zT_677 = 0;
    unum = zT_677;
    zT_678 = self->registry;
    zT_679 = bt;
    zT_681 = zF_3087E0A5_typeRegistryIsNumer(zT_678, zT_679);
    if (zT_681) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_682 = 1;
    unum = zT_682;
    goto z_bb_112;
    z_bb_112:
    if ((unsigned char)(unified == (unsigned int)(19))) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_685 = unum != (unsigned int)(0);
    goto z_bb_115;
    z_bb_114:
    zT_685 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_685) goto z_bb_116; else goto z_bb_118;
    z_bb_116:
    unified = bt;
    goto z_bb_117;
    z_bb_117:
    goto z_bb_109;
    z_bb_118:
    zT_689 = "MIX:P";
    zT_691 = 5;
    zT_690.ptr = zT_689;
    zT_690.len = zT_691;
    mix_pm = zT_690;
    zT_692 = mix_pm;
    zF_C914CB83_markerWriteInt(zT_692, (unsigned int)((unsigned int)i));
    zT_696 = "MIX:U";
    zT_698 = 5;
    zT_697.ptr = zT_696;
    zT_697.len = zT_698;
    mix_um = zT_697;
    zT_699 = mix_um;
    zT_700 = unified;
    zF_C914CB83_markerWriteInt(zT_699, zT_700);
    zT_702 = "MIX:B";
    zT_704 = 5;
    zT_703.ptr = zT_702;
    zT_703.len = zT_704;
    mix_bm = zT_703;
    zT_705 = mix_bm;
    zT_706 = bt;
    zF_C914CB83_markerWriteInt(zT_705, zT_706);
    zT_708 = "MIX:tk";
    zT_710 = 6;
    zT_709.ptr = zT_708;
    zT_709.len = zT_710;
    mix_tk_m = zT_709;
    zT_712 = self->registry;
    zT_713 = zT_712->types_items;
    zT_714 = (unsigned int)bt;
    zT_715 = zT_713[zT_714];
    zT_716 = zT_715.kind;
    zT_717 = (unsigned int)zT_716;
    mix_tk_v = zT_717;
    zT_718 = mix_tk_m;
    zT_719 = mix_tk_v;
    zF_C914CB83_markerWriteInt(zT_718, zT_719);
    zT_721 = "MIX:uk";
    zT_723 = 6;
    zT_722.ptr = zT_721;
    zT_722.len = zT_723;
    mix_uk_m = zT_722;
    zT_725 = self->registry;
    zT_726 = zT_725->types_items;
    zT_727 = (unsigned int)unified;
    zT_728 = zT_726[zT_727];
    zT_729 = zT_728.kind;
    zT_730 = (unsigned int)zT_729;
    mix_uk_v = zT_730;
    zT_731 = mix_uk_m;
    zT_732 = mix_uk_v;
    zF_C914CB83_markerWriteInt(zT_731, zT_732);
    zT_734 = "MIX:cd";
    zT_736 = 6;
    zT_735.ptr = zT_734;
    zT_735.len = zT_736;
    mix_cd_m = zT_735;
    zT_737 = mix_cd_m;
    zT_738 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_737, zT_738);
    zT_741 = "MIX:b";
    zT_743 = 5;
    zT_742.ptr = zT_741;
    zT_742.len = zT_743;
    mix_b_m = zT_742;
    zT_744 = mix_b_m;
    zT_745 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_744, zT_745);
    zT_748 = "MIX:pf";
    zT_750 = 6;
    zT_749.ptr = zT_748;
    zT_749.len = zT_750;
    mix_pf_m = zT_749;
    zT_751 = mix_pf_m;
    zT_753 = prong.flags;
    zF_C914CB83_markerWriteInt(zT_751, (unsigned int)((unsigned int)zT_753));
    zT_756 = "MIX:pn";
    zT_758 = 6;
    zT_757.ptr = zT_756;
    zT_757.len = zT_758;
    mix_pn_m = zT_757;
    zT_759 = mix_pn_m;
    zF_C914CB83_markerWriteInt(zT_759, (unsigned int)((unsigned int)prongs_n));
    zT_763 = "MIX:ni";
    zT_765 = 6;
    zT_764.ptr = zT_763;
    zT_764.len = zT_765;
    mix_ni_m = zT_764;
    zT_766 = mix_ni_m;
    zT_767 = node_idx;
    zF_C914CB83_markerWriteInt(zT_766, zT_767);
    zT_768 = self->type_table;
    zT_769 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_768, zT_769, (unsigned int)(1));
    goto z_bb_24;
    z_bb_119:
    goto z_bb_120;
    z_bb_120:
    if ((unsigned char)(unified == (unsigned int)(0))) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_781 = 3;
    unified = zT_781;
    goto z_bb_122;
    z_bb_122:
    zT_782 = self->type_table;
    zT_783 = node_idx;
    zT_784 = unified;
    zF_19B4A07D_resolvedTypeTableSe(zT_782, zT_783, zT_784);
    zT_787 = "SWU:n";
    zT_789 = 5;
    zT_788.ptr = zT_787;
    zT_788.len = zT_789;
    swu_m = zT_788;
    zT_790 = swu_m;
    zT_791 = node_idx;
    zF_C914CB83_markerWriteInt(zT_790, zT_791);
    zT_793 = "SWU:t";
    zT_795 = 5;
    zT_794.ptr = zT_793;
    zT_794.len = zT_795;
    swu_tm = zT_794;
    zT_796 = swu_tm;
    zT_797 = unified;
    zF_C914CB83_markerWriteInt(zT_796, zT_797);
    zT_798 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_798 - (unsigned int)(1));
    return unified;
}

/* semanticAnalyzerResolveExpr */
unsigned int zF_54F95822_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    unsigned int zT_12;
    zT_8143F551_AstKind zT_13;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8143F551_AstKind zT_28;
    unsigned int zT_32;
    zT_8143F551_AstKind zT_33;
    unsigned int zT_37;
    zT_8143F551_AstKind zT_38;
    unsigned int zT_42;
    zT_8143F551_AstKind zT_43;
    unsigned int zT_47;
    zT_8143F551_AstKind zT_48;
    unsigned int zT_52;
    zT_8143F551_AstKind zT_53;
    unsigned int zT_57;
    zT_8143F551_AstKind zT_58;
    unsigned int zT_62;
    zT_8143F551_AstKind zT_63;
    unsigned int zT_68;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned int zT_73 = 0;
    zT_6B0A7D14_AstStore* zT_75;
    zT_87BC8A14_anon_234416 zT_76;
    unsigned int zT_77;
    zT_6B0A7D14_AstStore* zT_80;
    zT_87BC8A14_anon_234416 zT_81;
    unsigned int* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_D3EB6303_StringInterner* zT_86;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90 = {0};
    unsigned int zT_92;
    unsigned int zT_93;
    zT_338B7C76_TypeRegistry* zT_95;
    unsigned int zT_97;
    unsigned int zT_100 = 0;
    zT_338B7C76_TypeRegistry* zT_101;
    unsigned int zT_102;
    unsigned int zT_106 = 0;
    zT_8143F551_AstKind zT_107;
    zT_38C12417_SemanticAnalyzer* zT_111;
    unsigned int zT_112;
    unsigned int zT_113 = 0;
    zT_8143F551_AstKind zT_114;
    unsigned int zT_118;
    int zT_119;
    unsigned int* zT_122;
    unsigned int zT_123;
    int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    int zT_127;
    int zT_130;
    unsigned int zT_131;
    zT_338B7C76_TypeRegistry* zT_133;
    zT_D155D06D_Type* zT_134;
    unsigned int zT_135;
    zT_D155D06D_Type zT_136;
    zT_33EF6BFB_TypeKind zT_138;
    zT_338B7C76_TypeRegistry* zT_143;
    zT_0B10E8E9_OptionalPayload* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_0B10E8E9_OptionalPayload zT_147;
    unsigned int zT_148;
    zT_338B7C76_TypeRegistry* zT_149;
    zT_D155D06D_Type* zT_150;
    unsigned int zT_151;
    zT_D155D06D_Type zT_152;
    zT_33EF6BFB_TypeKind zT_153;
    zT_33EF6BFB_TypeKind zT_157;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_42C2D6BF_EUPayload* zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_42C2D6BF_EUPayload zT_165;
    unsigned int zT_166;
    int zT_167;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    unsigned int zT_173 = 0;
    zT_338B7C76_TypeRegistry* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_179 = 0;
    zT_21D3708C_U32ToU32Map* zT_183;
    unsigned int zT_184;
    unsigned int zT_186 = 0;
    zT_21D3708C_U32ToU32Map* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_8EED1867_ResolvedTypeTable* zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_196;
    unsigned int zT_198;
    unsigned int zT_200;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_F85C5DED_DiagnosticCollector* zT_205;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned int zT_218 = 0;
    unsigned int zT_219;
    zT_33EF6BFB_TypeKind zT_220;
    zT_8EED1867_ResolvedTypeTable* zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_230;
    zT_8143F551_AstKind zT_231;
    zT_38C12417_SemanticAnalyzer* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    zT_6B0A7D14_AstStore* zT_240;
    unsigned int zT_241;
    unsigned int zT_243 = 0;
    unsigned int zT_244 = 0;
    zT_8143F551_AstKind zT_245;
    zT_38C12417_SemanticAnalyzer* zT_249;
    unsigned int zT_250;
    unsigned int zT_251 = 0;
    unsigned char* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    zT_8143F551_AstKind zT_258;
    zT_38C12417_SemanticAnalyzer* zT_262;
    unsigned int zT_263;
    unsigned int zT_264 = 0;
    zT_8143F551_AstKind zT_265;
    zT_38C12417_SemanticAnalyzer* zT_269;
    unsigned int zT_270;
    unsigned int zT_271 = 0;
    zT_8143F551_AstKind zT_272;
    zT_38C12417_SemanticAnalyzer* zT_277;
    unsigned int zT_278;
    unsigned int zT_280 = 0;
    unsigned char zT_283;
    zT_338B7C76_TypeRegistry* zT_287;
    zT_D155D06D_Type* zT_288;
    unsigned int zT_289;
    zT_D155D06D_Type zT_290;
    zT_33EF6BFB_TypeKind zT_291;
    unsigned char zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_112BF819_PtrPayload* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_112BF819_PtrPayload zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    zT_8143F551_AstKind zT_308;
    zT_38C12417_SemanticAnalyzer* zT_313;
    unsigned int zT_314;
    unsigned int zT_316 = 0;
    unsigned char zT_319;
    zT_6B0A7D14_AstStore* zT_323;
    unsigned int zT_324;
    zT_22A7C88B_AstNode zT_327 = {0};
    zT_8143F551_AstKind zT_328;
    zT_38C12417_SemanticAnalyzer* zT_333;
    unsigned int zT_334;
    unsigned int zT_336 = 0;
    unsigned char zT_340;
    zT_338B7C76_TypeRegistry* zT_344;
    zT_D155D06D_Type* zT_345;
    unsigned int zT_346;
    zT_D155D06D_Type zT_347;
    zT_33EF6BFB_TypeKind zT_348;
    unsigned char zT_352;
    zT_33EF6BFB_TypeKind zT_353;
    zT_338B7C76_TypeRegistry* zT_357;
    zT_112BF819_PtrPayload* zT_358;
    unsigned int zT_359;
    unsigned int zT_360;
    zT_112BF819_PtrPayload zT_361;
    unsigned int zT_362;
    zT_338B7C76_TypeRegistry* zT_363;
    zT_D155D06D_Type* zT_364;
    unsigned int zT_365;
    zT_D155D06D_Type zT_366;
    zT_33EF6BFB_TypeKind zT_367;
    zT_38C12417_SemanticAnalyzer* zT_372;
    unsigned int zT_373;
    unsigned int zT_374 = 0;
    unsigned int zT_378;
    unsigned int zT_380;
    unsigned int zT_382;
    unsigned char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_F85C5DED_DiagnosticCollector* zT_387;
    unsigned int zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_398 = 0;
    zT_33EF6BFB_TypeKind zT_399;
    unsigned int zT_404;
    unsigned int zT_406;
    unsigned int zT_408;
    unsigned char* zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_412;
    zT_F85C5DED_DiagnosticCollector* zT_413;
    unsigned int zT_416;
    unsigned int zT_417;
    unsigned int zT_418;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_419;
    unsigned int zT_424 = 0;
    zT_338B7C76_TypeRegistry* zT_425;
    unsigned int zT_426;
    unsigned int zT_430 = 0;
    unsigned int zT_431;
    zT_8143F551_AstKind zT_432;
    zT_38C12417_SemanticAnalyzer* zT_436;
    unsigned int zT_437;
    unsigned int zT_438 = 0;
    zT_8143F551_AstKind zT_439;
    unsigned char zT_443;
    zT_38C12417_SemanticAnalyzer* zT_444;
    unsigned int zT_445;
    unsigned char zT_447 = 0;
    unsigned char* zT_450;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    unsigned int zT_452;
    zT_F85C5DED_DiagnosticCollector* zT_453;
    unsigned int zT_456;
    unsigned int zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459;
    unsigned int zT_465;
    unsigned int zT_466;
    unsigned int zT_469 = 0;
    unsigned int zT_470;
    zT_8143F551_AstKind zT_471;
    zT_6B0A7D14_AstStore* zT_476;
    unsigned int zT_477;
    unsigned int zT_479 = 0;
    unsigned int zT_480;
    unsigned char* zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned int zT_486;
    unsigned char zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    unsigned char zT_492;
    unsigned int zT_493;
    unsigned int zT_494;
    unsigned char zT_496;
    unsigned int zT_497;
    unsigned int zT_498;
    unsigned char zT_500;
    unsigned int zT_501;
    unsigned int zT_502;
    zT_ABC1EBBE_TypeResolveEnv zT_507;
    zT_6B0A7D14_AstStore* zT_508;
    zT_338B7C76_TypeRegistry* zT_509;
    zT_3D7259E2_SymbolRegistry* zT_510;
    zT_D3EB6303_StringInterner* zT_511;
    unsigned int zT_512;
    zT_F85C5DED_DiagnosticCollector* zT_513;
    zT_7234F36B_Opt_226 zT_514;
    zT_F5B966E3_Opt_396 zT_515 = {0};
    zT_03B97CED_Opt_398 zT_516 = {0};
    unsigned int zT_517;
    zT_ABC1EBBE_TypeResolveEnv* zT_518;
    unsigned int zT_519;
    zT_6B0A7D14_AstStore* zT_522;
    unsigned int zT_523;
    unsigned int zT_527 = 0;
    unsigned int zT_529 = 0;
    unsigned int zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned char zT_534;
    unsigned int zT_535;
    unsigned int zT_536;
    zT_38C12417_SemanticAnalyzer* zT_540;
    unsigned int zT_541;
    zT_6B0A7D14_AstStore* zT_542;
    unsigned int zT_543;
    unsigned int zT_547 = 0;
    unsigned int zT_548 = 0;
    unsigned int zT_549;
    unsigned int zT_550;
    unsigned int zT_551;
    unsigned int zT_555;
    zT_38C12417_SemanticAnalyzer* zT_558;
    unsigned int zT_559;
    zT_6B0A7D14_AstStore* zT_560;
    unsigned int zT_561;
    unsigned int zT_565 = 0;
    unsigned int zT_566 = 0;
    zT_38C12417_SemanticAnalyzer* zT_568;
    unsigned int zT_569 = 0;
    unsigned char zT_572;
    zT_338B7C76_TypeRegistry* zT_576;
    zT_D155D06D_Type* zT_577;
    unsigned int zT_578;
    zT_D155D06D_Type zT_579;
    zT_33EF6BFB_TypeKind zT_580;
    unsigned char zT_584;
    zT_33EF6BFB_TypeKind zT_585;
    unsigned char* zT_592;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_593;
    unsigned int zT_594;
    zT_F85C5DED_DiagnosticCollector* zT_595;
    unsigned int zT_598;
    unsigned int zT_599;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    unsigned int zT_609;
    unsigned int zT_610;
    unsigned int zT_613 = 0;
    unsigned int zT_614;
    unsigned int zT_615;
    unsigned int zT_619;
    zT_ABC1EBBE_TypeResolveEnv zT_623;
    zT_6B0A7D14_AstStore* zT_624;
    zT_338B7C76_TypeRegistry* zT_625;
    zT_3D7259E2_SymbolRegistry* zT_626;
    zT_D3EB6303_StringInterner* zT_627;
    unsigned int zT_628;
    zT_F85C5DED_DiagnosticCollector* zT_629;
    zT_7234F36B_Opt_226 zT_630;
    zT_F5B966E3_Opt_396 zT_631 = {0};
    zT_03B97CED_Opt_398 zT_632 = {0};
    unsigned int zT_633;
    zT_ABC1EBBE_TypeResolveEnv* zT_635;
    unsigned int zT_636;
    zT_6B0A7D14_AstStore* zT_639;
    unsigned int zT_640;
    unsigned int zT_644 = 0;
    unsigned int zT_646 = 0;
    zT_38C12417_SemanticAnalyzer* zT_649;
    unsigned int zT_650;
    zT_6B0A7D14_AstStore* zT_651;
    unsigned int zT_652;
    unsigned int zT_656 = 0;
    unsigned int zT_657 = 0;
    zT_338B7C76_TypeRegistry* zT_658;
    unsigned int zT_659;
    unsigned int zT_663 = 0;
    unsigned int zT_664;
    unsigned int zT_665;
    unsigned int zT_669;
    zT_ABC1EBBE_TypeResolveEnv zT_673;
    zT_6B0A7D14_AstStore* zT_674;
    zT_338B7C76_TypeRegistry* zT_675;
    zT_3D7259E2_SymbolRegistry* zT_676;
    zT_D3EB6303_StringInterner* zT_677;
    unsigned int zT_678;
    zT_F85C5DED_DiagnosticCollector* zT_679;
    zT_7234F36B_Opt_226 zT_680;
    zT_F5B966E3_Opt_396 zT_681 = {0};
    zT_03B97CED_Opt_398 zT_682 = {0};
    unsigned int zT_683;
    zT_ABC1EBBE_TypeResolveEnv* zT_685;
    unsigned int zT_686;
    zT_6B0A7D14_AstStore* zT_689;
    unsigned int zT_690;
    unsigned int zT_694 = 0;
    unsigned int zT_696 = 0;
    zT_38C12417_SemanticAnalyzer* zT_700;
    unsigned int zT_701;
    zT_6B0A7D14_AstStore* zT_702;
    unsigned int zT_703;
    unsigned int zT_707 = 0;
    unsigned int zT_708 = 0;
    unsigned char zT_710;
    unsigned char zT_713;
    zT_338B7C76_TypeRegistry* zT_714;
    unsigned int zT_715;
    unsigned char zT_717 = 0;
    unsigned char zT_718;
    zT_338B7C76_TypeRegistry* zT_719;
    unsigned int zT_720;
    unsigned char zT_722 = 0;
    zT_338B7C76_TypeRegistry* zT_724;
    zT_D155D06D_Type* zT_725;
    unsigned int zT_726;
    zT_D155D06D_Type zT_727;
    zT_338B7C76_TypeRegistry* zT_729;
    zT_D155D06D_Type* zT_730;
    unsigned int zT_731;
    zT_D155D06D_Type zT_732;
    unsigned char zT_733;
    unsigned char zT_736;
    unsigned char zT_737;
    unsigned char zT_740;
    unsigned int zT_741;
    unsigned int zT_742;
    unsigned char zT_744;
    unsigned char* zT_748;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_749;
    unsigned int zT_750;
    zT_F85C5DED_DiagnosticCollector* zT_751;
    unsigned int zT_754;
    unsigned int zT_755;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_765;
    unsigned int zT_766;
    unsigned int zT_769 = 0;
    unsigned int zT_770;
    unsigned int zT_771;
    unsigned int zT_773;
    unsigned int zT_774;
    unsigned int zT_775;
    zT_38C12417_SemanticAnalyzer* zT_779;
    unsigned int zT_780;
    zT_6B0A7D14_AstStore* zT_781;
    unsigned int zT_782;
    unsigned int zT_786 = 0;
    unsigned int zT_787 = 0;
    unsigned int zT_788;
    unsigned int zT_789;
    unsigned int zT_790;
    zT_38C12417_SemanticAnalyzer* zT_794;
    unsigned int zT_795;
    zT_6B0A7D14_AstStore* zT_796;
    unsigned int zT_797;
    unsigned int zT_801 = 0;
    unsigned int zT_802 = 0;
    unsigned int zT_803;
    unsigned int zT_804;
    unsigned int zT_805;
    unsigned char zT_807;
    unsigned int zT_808;
    unsigned int zT_809;
    zT_38C12417_SemanticAnalyzer* zT_813;
    unsigned int zT_814;
    zT_6B0A7D14_AstStore* zT_815;
    unsigned int zT_816;
    unsigned int zT_820 = 0;
    unsigned int zT_821 = 0;
    unsigned int zT_822;
    unsigned int zT_823;
    unsigned int zT_824;
    unsigned char zT_826;
    unsigned int zT_827;
    unsigned int zT_828;
    zT_38C12417_SemanticAnalyzer* zT_832;
    unsigned int zT_833;
    zT_6B0A7D14_AstStore* zT_834;
    unsigned int zT_835;
    unsigned int zT_839 = 0;
    unsigned int zT_840 = 0;
    zT_38C12417_SemanticAnalyzer* zT_841;
    unsigned int zT_842;
    zT_6B0A7D14_AstStore* zT_843;
    unsigned int zT_844;
    unsigned int zT_848 = 0;
    unsigned int zT_849 = 0;
    zT_38C12417_SemanticAnalyzer* zT_852;
    unsigned int zT_853;
    zT_6B0A7D14_AstStore* zT_854;
    unsigned int zT_855;
    unsigned int zT_859 = 0;
    unsigned int zT_860 = 0;
    unsigned int zT_861;
    unsigned int zT_862;
    unsigned int zT_863;
    unsigned int zT_865;
    unsigned int zT_866;
    unsigned int zT_867;
    unsigned int zT_869;
    unsigned int zT_870;
    unsigned int zT_871;
    unsigned char zT_873;
    unsigned int zT_874;
    unsigned int zT_875;
    zT_38C12417_SemanticAnalyzer* zT_879;
    unsigned int zT_880;
    zT_6B0A7D14_AstStore* zT_881;
    unsigned int zT_882;
    unsigned int zT_886 = 0;
    unsigned int zT_887 = 0;
    zT_38C12417_SemanticAnalyzer* zT_888;
    unsigned int zT_889;
    zT_6B0A7D14_AstStore* zT_890;
    unsigned int zT_891;
    unsigned int zT_895 = 0;
    unsigned int zT_896 = 0;
    zT_38C12417_SemanticAnalyzer* zT_899;
    unsigned int zT_900;
    zT_6B0A7D14_AstStore* zT_901;
    unsigned int zT_902;
    unsigned int zT_906 = 0;
    unsigned int zT_907 = 0;
    unsigned int zT_908;
    unsigned int zT_909;
    unsigned int zT_910;
    zT_38C12417_SemanticAnalyzer* zT_914;
    unsigned int zT_915;
    zT_6B0A7D14_AstStore* zT_916;
    unsigned int zT_917;
    unsigned int zT_921 = 0;
    unsigned int zT_922 = 0;
    unsigned char zT_924;
    zT_6B0A7D14_AstStore* zT_925;
    zT_3D7259E2_SymbolRegistry* zT_926;
    unsigned int zT_927;
    unsigned int zT_928;
    zT_6B0A7D14_AstStore* zT_932;
    unsigned int zT_933;
    unsigned int zT_937 = 0;
    zT_BBEE1AC1_Opt_11 zT_938 = {0};
    unsigned char zT_939;
    unsigned int zT_944;
    unsigned int zT_948;
    zT_A4CE86B7_U64ToU32Map* zT_949;
    unsigned int zT_950;
    unsigned int zT_951;
    unsigned char zT_953 = 0;
    unsigned char zT_954;
    unsigned char* zT_957;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_958;
    unsigned int zT_959;
    zT_F85C5DED_DiagnosticCollector* zT_960;
    unsigned int zT_963;
    unsigned int zT_964;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_966;
    unsigned int zT_974;
    unsigned int zT_975;
    unsigned int zT_978 = 0;
    unsigned int zT_979;
    unsigned int zT_980;
    unsigned int zT_981;
    zT_38C12417_SemanticAnalyzer* zT_985;
    unsigned int zT_986;
    zT_6B0A7D14_AstStore* zT_987;
    unsigned int zT_988;
    unsigned int zT_992 = 0;
    unsigned int zT_993 = 0;
    zT_38C12417_SemanticAnalyzer* zT_994;
    unsigned int zT_995;
    zT_6B0A7D14_AstStore* zT_996;
    unsigned int zT_997;
    unsigned int zT_1001 = 0;
    unsigned int zT_1002 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1003;
    unsigned int zT_1004;
    zT_6B0A7D14_AstStore* zT_1005;
    unsigned int zT_1006;
    unsigned int zT_1010 = 0;
    unsigned int zT_1011 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1012;
    unsigned int zT_1013;
    zT_6B0A7D14_AstStore* zT_1014;
    unsigned int zT_1015;
    unsigned int zT_1019 = 0;
    unsigned int zT_1020 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1021;
    unsigned int zT_1022;
    zT_338B7C76_TypeRegistry* zT_1023;
    unsigned int zT_1029 = 0;
    unsigned int zT_1030;
    unsigned int zT_1031;
    zT_38C12417_SemanticAnalyzer* zT_1035;
    unsigned int zT_1036;
    zT_6B0A7D14_AstStore* zT_1037;
    unsigned int zT_1038;
    unsigned int zT_1042 = 0;
    unsigned int zT_1043 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1044;
    unsigned int zT_1045;
    zT_6B0A7D14_AstStore* zT_1046;
    unsigned int zT_1047;
    unsigned int zT_1051 = 0;
    unsigned int zT_1052 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1053;
    unsigned int zT_1054;
    zT_338B7C76_TypeRegistry* zT_1055;
    unsigned int zT_1056;
    zT_338B7C76_TypeRegistry* zT_1058;
    unsigned int zT_1064 = 0;
    unsigned int zT_1065 = 0;
    unsigned int zT_1066;
    unsigned int zT_1067;
    zT_38C12417_SemanticAnalyzer* zT_1071;
    unsigned int zT_1072;
    zT_6B0A7D14_AstStore* zT_1073;
    unsigned int zT_1074;
    unsigned int zT_1078 = 0;
    unsigned int zT_1079 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1080;
    unsigned int zT_1081;
    zT_38C12417_SemanticAnalyzer* zT_1082;
    unsigned int zT_1083;
    zT_338B7C76_TypeRegistry* zT_1084;
    unsigned int zT_1090 = 0;
    unsigned int zT_1091;
    unsigned int zT_1092;
    unsigned char zT_1094;
    unsigned char* zT_1098;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1099;
    unsigned int zT_1100;
    zT_F85C5DED_DiagnosticCollector* zT_1101;
    unsigned int zT_1104;
    unsigned int zT_1105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1107;
    unsigned int zT_1115;
    unsigned int zT_1116;
    unsigned int zT_1119 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1122;
    unsigned int zT_1123;
    zT_6B0A7D14_AstStore* zT_1124;
    unsigned int zT_1125;
    unsigned int zT_1129 = 0;
    unsigned int zT_1130 = 0;
    unsigned int zT_1131;
    zT_38C12417_SemanticAnalyzer* zT_1132;
    unsigned int zT_1133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1134;
    unsigned char zT_1136 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1139;
    unsigned int zT_1140;
    zT_6B0A7D14_AstStore* zT_1141;
    unsigned int zT_1142;
    unsigned int zT_1146 = 0;
    unsigned int zT_1147 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_1149;
    zT_6B0A7D14_AstStore* zT_1150;
    zT_338B7C76_TypeRegistry* zT_1151;
    zT_3D7259E2_SymbolRegistry* zT_1152;
    zT_D3EB6303_StringInterner* zT_1153;
    unsigned int zT_1154;
    zT_F85C5DED_DiagnosticCollector* zT_1155;
    zT_7234F36B_Opt_226 zT_1156;
    zT_F5B966E3_Opt_396 zT_1157 = {0};
    zT_03B97CED_Opt_398 zT_1158 = {0};
    unsigned int zT_1159;
    zT_ABC1EBBE_TypeResolveEnv* zT_1160;
    unsigned int zT_1161;
    zT_6B0A7D14_AstStore* zT_1164;
    unsigned int zT_1165;
    unsigned int zT_1169 = 0;
    unsigned int zT_1171 = 0;
    unsigned int zT_1172;
    zT_38C12417_SemanticAnalyzer* zT_1175;
    unsigned int zT_1176;
    unsigned char zT_1178 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1180;
    unsigned int zT_1181;
    zT_6B0A7D14_AstStore* zT_1182;
    unsigned int zT_1183;
    unsigned int zT_1187 = 0;
    unsigned int zT_1188 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_1190;
    zT_6B0A7D14_AstStore* zT_1191;
    zT_338B7C76_TypeRegistry* zT_1192;
    zT_3D7259E2_SymbolRegistry* zT_1193;
    zT_D3EB6303_StringInterner* zT_1194;
    unsigned int zT_1195;
    zT_F85C5DED_DiagnosticCollector* zT_1196;
    zT_7234F36B_Opt_226 zT_1197;
    zT_F5B966E3_Opt_396 zT_1198 = {0};
    zT_03B97CED_Opt_398 zT_1199 = {0};
    unsigned int zT_1200;
    zT_ABC1EBBE_TypeResolveEnv* zT_1201;
    unsigned int zT_1202;
    zT_6B0A7D14_AstStore* zT_1205;
    unsigned int zT_1206;
    unsigned int zT_1210 = 0;
    unsigned int zT_1212 = 0;
    unsigned int zT_1213;
    unsigned int zT_1214;
    unsigned char zT_1216;
    unsigned char zT_1219;
    zT_38C12417_SemanticAnalyzer* zT_1222;
    unsigned int zT_1223;
    unsigned int zT_1224;
    unsigned char zT_1225 = 0;
    unsigned char* zT_1227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1228;
    unsigned int zT_1229;
    zT_F85C5DED_DiagnosticCollector* zT_1230;
    unsigned int zT_1233;
    unsigned int zT_1234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1236;
    unsigned int zT_1242;
    unsigned int zT_1243;
    unsigned int zT_1246 = 0;
    unsigned int zT_1247;
    unsigned int zT_1248;
    unsigned char zT_1250;
    unsigned char zT_1253;
    zT_38C12417_SemanticAnalyzer* zT_1256;
    unsigned int zT_1257;
    unsigned int zT_1258;
    unsigned char zT_1259 = 0;
    unsigned char* zT_1262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1263;
    unsigned int zT_1264;
    zT_F85C5DED_DiagnosticCollector* zT_1265;
    unsigned int zT_1268;
    unsigned int zT_1269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1271;
    unsigned int zT_1277;
    unsigned int zT_1278;
    unsigned int zT_1281 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1282;
    unsigned int zT_1283;
    zT_6B0A7D14_AstStore* zT_1284;
    unsigned int zT_1285;
    unsigned int zT_1289 = 0;
    unsigned int zT_1290 = 0;
    unsigned int zT_1291;
    unsigned int zT_1292;
    unsigned char zT_1294;
    zT_38C12417_SemanticAnalyzer* zT_1298;
    unsigned int zT_1299;
    zT_6B0A7D14_AstStore* zT_1300;
    unsigned int zT_1301;
    unsigned int zT_1305 = 0;
    unsigned int zT_1306 = 0;
    zT_338B7C76_TypeRegistry* zT_1311;
    zT_D155D06D_Type* zT_1312;
    unsigned int zT_1313;
    zT_D155D06D_Type zT_1314;
    zT_33EF6BFB_TypeKind zT_1315;
    zT_338B7C76_TypeRegistry* zT_1320;
    unsigned int zT_1321;
    unsigned int zT_1323 = 0;
    unsigned char zT_1326;
    zT_338B7C76_TypeRegistry* zT_1328;
    unsigned int zT_1329;
    zT_38C12417_SemanticAnalyzer* zT_1333;
    unsigned int zT_1334;
    zT_6B0A7D14_AstStore* zT_1335;
    unsigned int zT_1336;
    unsigned int zT_1340 = 0;
    unsigned int zT_1341 = 0;
    unsigned int zT_1342;
    zT_8143F551_AstKind zT_1343;
    zT_38C12417_SemanticAnalyzer* zT_1347;
    unsigned int zT_1348;
    unsigned int zT_1350 = 0;
    unsigned int zT_1351;
    zT_8143F551_AstKind zT_1352;
    unsigned char zT_1356;
    zT_8143F551_AstKind zT_1357;
    zT_38C12417_SemanticAnalyzer* zT_1361;
    unsigned int zT_1362;
    unsigned int zT_1363 = 0;
    zT_8143F551_AstKind zT_1364;
    zT_38C12417_SemanticAnalyzer* zT_1368;
    unsigned int zT_1369;
    unsigned int zT_1370 = 0;
    zT_8143F551_AstKind zT_1371;
    zT_38C12417_SemanticAnalyzer* zT_1375;
    unsigned int zT_1376;
    unsigned int zT_1377 = 0;
    zT_8143F551_AstKind zT_1378;
    int zT_1383;
    unsigned int zT_1384;
    zT_38C12417_SemanticAnalyzer* zT_1385;
    unsigned int zT_1386;
    unsigned int zT_1388 = 0;
    zT_338B7C76_TypeRegistry* zT_1392;
    zT_D155D06D_Type* zT_1393;
    unsigned int zT_1394;
    zT_D155D06D_Type zT_1395;
    zT_33EF6BFB_TypeKind zT_1396;
    zT_338B7C76_TypeRegistry* zT_1400;
    zT_42C2D6BF_EUPayload* zT_1401;
    unsigned int zT_1402;
    unsigned int zT_1403;
    zT_42C2D6BF_EUPayload zT_1404;
    unsigned int zT_1405;
    zT_338B7C76_TypeRegistry* zT_1406;
    zT_42C2D6BF_EUPayload* zT_1407;
    unsigned int zT_1408;
    unsigned int zT_1409;
    zT_42C2D6BF_EUPayload zT_1410;
    unsigned int zT_1411;
    zT_66E7D2EF_CoercionTable* zT_1412;
    unsigned int zT_1413;
    unsigned int zT_1415;
    unsigned int zT_1420;
    int zT_1421;
    zT_6B0A7D14_AstStore* zT_1424;
    unsigned int zT_1425;
    unsigned int zT_1429;
    unsigned int zT_1430;
    zT_38C12417_SemanticAnalyzer* zT_1432;
    zT_6B0A7D14_AstStore* zT_1433;
    unsigned int zT_1434;
    unsigned int zT_1437 = 0;
    unsigned int* zT_1438;
    unsigned int zT_1439;
    int zT_1440;
    unsigned int zT_1442;
    unsigned int* zT_1444;
    unsigned int zT_1445;
    unsigned int zT_1446;
    unsigned int zT_1449;
    int zT_1452;
    zT_6B0A7D14_AstStore* zT_1455;
    unsigned int zT_1456;
    zT_22A7C88B_AstNode zT_1459 = {0};
    zT_8143F551_AstKind zT_1460;
    zT_38C12417_SemanticAnalyzer* zT_1464;
    unsigned int zT_1465;
    zT_38C12417_SemanticAnalyzer* zT_1466;
    unsigned int zT_1467;
    unsigned int zT_1469 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1470;
    zT_38C12417_SemanticAnalyzer* zT_1471;
    unsigned int zT_1472;
    zT_8143F551_AstKind zT_1474;
    zT_38C12417_SemanticAnalyzer* zT_1478;
    unsigned int zT_1479;
    unsigned int zT_1480 = 0;
    zT_8143F551_AstKind zT_1481;
    unsigned char zT_1485;
    zT_8143F551_AstKind zT_1486;
    unsigned int zT_1490;
    zT_8143F551_AstKind zT_1491;
    unsigned char zT_1495;
    zT_8143F551_AstKind zT_1496;
    unsigned char zT_1500;
    zT_8143F551_AstKind zT_1501;
    unsigned char zT_1505;
    zT_8143F551_AstKind zT_1506;
    zT_38C12417_SemanticAnalyzer* zT_1510;
    unsigned int zT_1511;
    unsigned int zT_1512;
    zT_8143F551_AstKind zT_1513;
    zT_38C12417_SemanticAnalyzer* zT_1517;
    unsigned int zT_1518;
    unsigned int zT_1519 = 0;
    zT_8143F551_AstKind zT_1520;
    zT_38C12417_SemanticAnalyzer* zT_1524;
    unsigned int zT_1525;
    unsigned int zT_1526;
    zT_38C12417_SemanticAnalyzer* zT_1529;
    unsigned int zT_1530;
    unsigned int zT_1532;
    zT_38C12417_SemanticAnalyzer* zT_1535;
    unsigned int zT_1536;
    unsigned int zT_1538;
    zT_8143F551_AstKind zT_1539;
    zT_38C12417_SemanticAnalyzer* zT_1543;
    unsigned int zT_1544;
    unsigned int zT_1545;
    int zT_1546;
    zT_38C12417_SemanticAnalyzer* zT_1548;
    unsigned int zT_1549;
    unsigned int zT_1551;
    zT_8143F551_AstKind zT_1552;
    zT_38C12417_SemanticAnalyzer* zT_1556;
    unsigned int zT_1557;
    unsigned int zT_1558;
    int zT_1559;
    zT_38C12417_SemanticAnalyzer* zT_1561;
    unsigned int zT_1562;
    unsigned int zT_1564;
    zT_8143F551_AstKind zT_1565;
    zT_38C12417_SemanticAnalyzer* zT_1569;
    unsigned int zT_1570;
    unsigned int zT_1571 = 0;
    zT_8143F551_AstKind zT_1572;
    zT_38C12417_SemanticAnalyzer* zT_1576;
    unsigned int zT_1577;
    unsigned int zT_1578 = 0;
    zT_8143F551_AstKind zT_1579;
    zT_38C12417_SemanticAnalyzer* zT_1583;
    unsigned int zT_1584;
    unsigned int zT_1585 = 0;
    zT_8143F551_AstKind zT_1586;
    unsigned char* zT_1591;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1592;
    unsigned int zT_1593;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1594;
    unsigned int zT_1595;
    zT_38C12417_SemanticAnalyzer* zT_1596;
    unsigned int zT_1597;
    unsigned int zT_1598 = 0;
    zT_8143F551_AstKind zT_1599;
    unsigned char zT_1603;
    zT_8143F551_AstKind zT_1604;
    unsigned char zT_1608;
    zT_8143F551_AstKind zT_1609;
    unsigned char zT_1613;
    zT_8143F551_AstKind zT_1614;
    unsigned char zT_1618;
    zT_8143F551_AstKind zT_1619;
    unsigned char zT_1623;
    zT_8143F551_AstKind zT_1624;
    unsigned char zT_1628;
    zT_8143F551_AstKind zT_1629;
    unsigned char zT_1633;
    zT_8143F551_AstKind zT_1634;
    unsigned char zT_1638;
    zT_8143F551_AstKind zT_1639;
    unsigned char zT_1643;
    zT_8143F551_AstKind zT_1644;
    unsigned char zT_1648;
    zT_8143F551_AstKind zT_1649;
    zT_8143F551_AstKind zT_1653;
    zT_38C12417_SemanticAnalyzer* zT_1657;
    unsigned int zT_1658;
    unsigned int zT_1659;
    zT_8143F551_AstKind zT_1661;
    zT_38C12417_SemanticAnalyzer* zT_1665;
    unsigned int zT_1666;
    unsigned int zT_1667;
    zT_8143F551_AstKind zT_1668;
    zT_38C12417_SemanticAnalyzer* zT_1672;
    unsigned int zT_1673;
    unsigned int zT_1675 = 0;
    zT_8143F551_AstKind zT_1676;
    zT_38C12417_SemanticAnalyzer* zT_1680;
    unsigned int zT_1681;
    unsigned int zT_1682;
    zT_8143F551_AstKind zT_1683;
    zT_38C12417_SemanticAnalyzer* zT_1687;
    unsigned int zT_1688;
    unsigned int zT_1690 = 0;
    zT_8143F551_AstKind zT_1691;
    unsigned int zT_1695;
    zT_8143F551_AstKind zT_1696;
    unsigned char* zT_1701;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1702;
    unsigned int zT_1703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1704;
    unsigned int zT_1705;
    zT_6B0A7D14_AstStore* zT_1707;
    unsigned int zT_1708;
    unsigned int zT_1710 = 0;
    unsigned char* zT_1712;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1713;
    unsigned int zT_1714;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1715;
    int zT_1721;
    unsigned int zT_1722;
    int zT_1724;
    unsigned char* zT_1728;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1729;
    unsigned int zT_1730;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1731;
    unsigned char* zT_1735;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1736;
    unsigned int zT_1737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1738;
    unsigned int zT_1739;
    zT_6B0A7D14_AstStore* zT_1740;
    unsigned int zT_1741;
    unsigned int zT_1745 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1746;
    unsigned int zT_1747;
    zT_6B0A7D14_AstStore* zT_1748;
    unsigned int zT_1749;
    unsigned int zT_1753 = 0;
    int zT_1754;
    unsigned int zT_1756;
    zT_6B0A7D14_AstStore* zT_1758;
    unsigned int zT_1759;
    unsigned int zT_1765 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1766;
    unsigned int zT_1767;
    unsigned int zT_1768 = 0;
    unsigned int zT_1769;
    zT_8143F551_AstKind zT_1770;
    unsigned char zT_1774;
    zT_8143F551_AstKind zT_1775;
    unsigned char zT_1779;
    zT_8143F551_AstKind zT_1780;
    unsigned char zT_1784;
    zT_8143F551_AstKind zT_1785;
    unsigned char zT_1789;
    zT_8143F551_AstKind zT_1790;
    unsigned char zT_1794;
    zT_8143F551_AstKind zT_1795;
    unsigned char zT_1799;
    zT_8143F551_AstKind zT_1800;
    unsigned char zT_1804;
    zT_8143F551_AstKind zT_1805;
    unsigned char zT_1809;
    zT_8143F551_AstKind zT_1810;
    unsigned char zT_1814;
    zT_8143F551_AstKind zT_1815;
    unsigned char zT_1819;
    zT_8143F551_AstKind zT_1820;
    zT_38C12417_SemanticAnalyzer* zT_1824;
    unsigned int zT_1825;
    zT_8143F551_AstKind zT_1826;
    unsigned int zT_1828 = 0;
    zT_8143F551_AstKind zT_1829;
    unsigned char zT_1833;
    zT_8143F551_AstKind zT_1834;
    unsigned char zT_1838;
    zT_8143F551_AstKind zT_1839;
    unsigned char zT_1843;
    zT_8143F551_AstKind zT_1844;
    unsigned char zT_1848;
    zT_8143F551_AstKind zT_1849;
    unsigned char zT_1853;
    zT_8143F551_AstKind zT_1854;
    zT_38C12417_SemanticAnalyzer* zT_1858;
    unsigned int zT_1859;
    unsigned int zT_1860 = 0;
    zT_8143F551_AstKind zT_1861;
    unsigned char zT_1865;
    zT_8143F551_AstKind zT_1866;
    zT_38C12417_SemanticAnalyzer* zT_1870;
    unsigned int zT_1871;
    unsigned int zT_1872 = 0;
    zT_8143F551_AstKind zT_1873;
    unsigned char zT_1877;
    zT_8143F551_AstKind zT_1878;
    unsigned char zT_1882;
    zT_8143F551_AstKind zT_1883;
    unsigned char zT_1887;
    zT_8143F551_AstKind zT_1888;
    unsigned char zT_1892;
    zT_8143F551_AstKind zT_1893;
    unsigned char zT_1897;
    zT_8143F551_AstKind zT_1898;
    zT_38C12417_SemanticAnalyzer* zT_1902;
    unsigned int zT_1903;
    zT_8143F551_AstKind zT_1904;
    unsigned int zT_1906 = 0;
    zT_8143F551_AstKind zT_1907;
    unsigned char zT_1911;
    zT_8143F551_AstKind zT_1912;
    unsigned char zT_1916;
    zT_8143F551_AstKind zT_1917;
    unsigned char zT_1921;
    zT_8143F551_AstKind zT_1922;
    unsigned char zT_1926;
    zT_8143F551_AstKind zT_1927;
    unsigned char zT_1931;
    zT_8143F551_AstKind zT_1932;
    unsigned char zT_1936;
    zT_8143F551_AstKind zT_1937;
    unsigned char zT_1941;
    zT_8143F551_AstKind zT_1942;
    unsigned char zT_1946;
    zT_8143F551_AstKind zT_1947;
    unsigned char zT_1951;
    zT_8143F551_AstKind zT_1952;
    unsigned char zT_1956;
    zT_8143F551_AstKind zT_1957;
    unsigned char zT_1961;
    zT_8143F551_AstKind zT_1962;
    unsigned char zT_1966;
    zT_8143F551_AstKind zT_1967;
    unsigned char zT_1971;
    zT_8143F551_AstKind zT_1972;
    unsigned char zT_1976;
    zT_8143F551_AstKind zT_1977;
    unsigned char zT_1981;
    zT_8143F551_AstKind zT_1982;
    unsigned char zT_1986;
    zT_8143F551_AstKind zT_1987;
    unsigned char zT_1991;
    zT_8143F551_AstKind zT_1992;
    zT_38C12417_SemanticAnalyzer* zT_1996;
    unsigned int zT_1997;
    unsigned int zT_1998 = 0;
    zT_8143F551_AstKind zT_1999;
    unsigned char zT_2003;
    zT_8143F551_AstKind zT_2004;
    zT_38C12417_SemanticAnalyzer* zT_2008;
    unsigned int zT_2009;
    unsigned int zT_2011 = 0;
    unsigned int zT_2012;
    int zT_2013;
    zT_38C12417_SemanticAnalyzer* zT_2015;
    unsigned int zT_2016;
    unsigned int zT_2018 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_2019;
    unsigned int zT_2020;
    unsigned char* zT_2026;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2027;
    unsigned int zT_2028;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2029;
    unsigned int zT_2030;
    zT_8143F551_AstKind zT_2032;
    unsigned int zT_2033;
    unsigned char* zT_2035;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2036;
    unsigned int zT_2037;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2038;
    unsigned int zT_2039;
    unsigned char* zT_2041;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2042;
    unsigned int zT_2043;
    zT_F85C5DED_DiagnosticCollector* zT_2044;
    unsigned int zT_2047;
    unsigned int zT_2048;
    unsigned int zT_2049;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2050;
    unsigned int zT_2055 = 0;
    unsigned char* zT_2058;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2059;
    unsigned int zT_2060;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2061;
    unsigned int zT_2062;
    zT_8143F551_AstKind zT_2064;
    unsigned int zT_2065;
    unsigned char* zT_2067;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2068;
    unsigned int zT_2069;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2070;
    unsigned int zT_2071;
    unsigned char* zT_2073;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2074;
    unsigned int zT_2075;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2076;
    unsigned int zT_2077;
    unsigned char* zT_2079;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2080;
    unsigned int zT_2081;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2082;
    unsigned int zT_2083;
    zT_8143F551_AstKind zT_2085;
    unsigned int zT_2086;
    unsigned char* zT_2088;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2089;
    unsigned int zT_2090;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2091;
    unsigned int zT_2092;
    unsigned char* zT_2094;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2095;
    unsigned int zT_2096;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2097;
    unsigned int zT_2098;
    zT_8EED1867_ResolvedTypeTable* zT_2099;
    unsigned int zT_2100;
    unsigned int zT_2101;
    unsigned char* zT_2104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2105;
    unsigned int zT_2106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2107;
    unsigned int zT_2108;
    unsigned char* zT_2110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2111;
    unsigned int zT_2112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2113;
    unsigned int zT_2114;
    unsigned int result;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rx_sw_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rxs_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_m;
    unsigned int stx_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_nm;
    unsigned int a4_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_rm;
    unsigned int sl_len;
    unsigned int sl_payload;
    unsigned int sl_str_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl_bytes;
    unsigned int sl_arr;
    unsigned int top;
    unsigned int es;
    zT_D155D06D_Type tty;
    unsigned int eff_top;
    unsigned int opt_pay;
    unsigned int name_id;
    unsigned int ord;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u fad;
    unsigned int base;
    zT_D155D06D_Type bt;
    zT_112BF819_PtrPayload pp;
    zT_22A7C88B_AstNode base_node;
    unsigned int fa_base_t;
    unsigned int st;
    zT_D155D06D_Type st_ty;
    unsigned int sd;
    unsigned int aps;
    unsigned int ape;
    zT_8F083A69_Slice_zT_0B42B2F8_u aof_msg;
    unsigned int apu_s;
    unsigned int apu_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u aou_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ub_msg;
    unsigned int ec_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u cva;
    zT_ABC1EBBE_TypeResolveEnv so_env;
    unsigned int pfi_res;
    unsigned int pfi_top;
    zT_D155D06D_Type pfi_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_msg;
    unsigned int fpp_res;
    zT_ABC1EBBE_TypeResolveEnv fpp_env;
    unsigned int fpp_outer;
    unsigned int bc_res;
    zT_ABC1EBBE_TypeResolveEnv bc_env;
    unsigned int bc_dst;
    unsigned int bc_src;
    unsigned char bc_ok;
    zT_D155D06D_Type bc_dty;
    zT_D155D06D_Type bc_sty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_msg;
    unsigned char afs_susp;
    zT_79FAE712_u64 afs_k;
    unsigned int afs_mid;
    unsigned int afs_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u e3046;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc3049;
    zT_ABC1EBBE_TypeResolveEnv cva_env;
    unsigned int tv_src;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcq_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcc_msg;
    unsigned int e2i_arg;
    unsigned int e2i_res;
    zT_D155D06D_Type e2i_ty;
    unsigned int e2i_bt;
    unsigned int catch_es;
    zT_D155D06D_Type clt;
    zT_22A7C88B_AstNode child1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ai_dbg;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_m;
    unsigned int children_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm2;
    unsigned int last_child;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_m;
    unsigned int st_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u unr_msg;
    zT_3 = 0;
    result = zT_3;
    zT_4 = 0;
    result = zT_4;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return result;
    z_bb_2:
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_12 = 1;
    result = zT_12;
    zT_13 = node.kind;
    if ((unsigned char)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = "RXS";
    zT_20 = 3;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rx_sw_m = zT_19;
    zT_21 = rx_sw_m;
    zF_48AC7B3A_markerWrite(zT_21);
    zT_23 = "RXS:n";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    rxs_nm = zT_24;
    zT_26 = rxs_nm;
    zT_27 = node_idx;
    zF_C914CB83_markerWriteInt(zT_26, zT_27);
    goto z_bb_4;
    z_bb_4:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_32 = 19;
    result = zT_32;
    goto z_bb_6;
    z_bb_6:
    zT_2058 = "STX:n";
    zT_2060 = 5;
    zT_2059.ptr = zT_2058;
    zT_2059.len = zT_2060;
    stx_m = zT_2059;
    zT_2061 = stx_m;
    zT_2062 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2061, zT_2062);
    zT_2064 = node.kind;
    zT_2065 = (unsigned int)zT_2064;
    stx_kv = zT_2065;
    zT_2067 = "STX:k";
    zT_2069 = 5;
    zT_2068.ptr = zT_2067;
    zT_2068.len = zT_2069;
    stx_km = zT_2068;
    zT_2070 = stx_km;
    zT_2071 = stx_kv;
    zF_C914CB83_markerWriteInt(zT_2070, zT_2071);
    zT_2073 = "STX:r";
    zT_2075 = 5;
    zT_2074.ptr = zT_2073;
    zT_2074.len = zT_2075;
    stx_rm = zT_2074;
    zT_2076 = stx_rm;
    zT_2077 = result;
    zF_C914CB83_markerWriteInt(zT_2076, zT_2077);
    zT_2079 = "A4:N";
    zT_2081 = 4;
    zT_2080.ptr = zT_2079;
    zT_2080.len = zT_2081;
    a4_nm = zT_2080;
    zT_2082 = a4_nm;
    zT_2083 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2082, zT_2083);
    zT_2085 = node.kind;
    zT_2086 = (unsigned int)zT_2085;
    a4_kv = zT_2086;
    zT_2088 = "A4:K";
    zT_2090 = 4;
    zT_2089.ptr = zT_2088;
    zT_2089.len = zT_2090;
    a4_km = zT_2089;
    zT_2091 = a4_km;
    zT_2092 = a4_kv;
    zF_C914CB83_markerWriteInt(zT_2091, zT_2092);
    zT_2094 = "A4:R";
    zT_2096 = 4;
    zT_2095.ptr = zT_2094;
    zT_2095.len = zT_2096;
    a4_rm = zT_2095;
    zT_2097 = a4_rm;
    zT_2098 = result;
    zF_C914CB83_markerWriteInt(zT_2097, zT_2098);
    zT_2099 = self->type_table;
    zT_2100 = node_idx;
    zT_2101 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_2099, zT_2100, zT_2101);
    zT_2104 = "STB:N";
    zT_2106 = 5;
    zT_2105.ptr = zT_2104;
    zT_2105.len = zT_2106;
    stb_nm = zT_2105;
    zT_2107 = stb_nm;
    zT_2108 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2107, zT_2108);
    zT_2110 = "STB:R";
    zT_2112 = 5;
    zT_2111.ptr = zT_2110;
    zT_2111.len = zT_2112;
    stb_rm = zT_2111;
    zT_2113 = stb_rm;
    zT_2114 = result;
    zF_C914CB83_markerWriteInt(zT_2113, zT_2114);
    return result;
    z_bb_7:
    zT_33 = node.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_37 = 16;
    result = zT_37;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_38 = node.kind;
    if ((unsigned char)(zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_42 = 8;
    result = zT_42;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_43 = node.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_47 = 2;
    result = zT_47;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_48 = node.kind;
    if ((unsigned char)(zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_52 = 17;
    result = zT_52;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_53 = node.kind;
    if ((unsigned char)(zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_57 = 18;
    result = zT_57;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_58 = node.kind;
    if ((unsigned char)(zT_58 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_unreachable_expr))) goto z_bb_23; else goto z_bb_25;
    z_bb_23:
    zT_62 = 3;
    result = zT_62;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_63 = node.kind;
    if ((unsigned char)(zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_68 = 0;
    sl_len = zT_68;
    zT_70 = self->store;
    zT_71 = node_idx;
    zT_73 = zF_8BA26B9E_astStoreNodePayload(zT_70, zT_71);
    sl_payload = zT_73;
    zT_75 = self->store;
    zT_76 = zT_75->string_values;
    zT_77 = zT_76.len;
    if ((unsigned char)((unsigned int)((unsigned int)sl_payload) < zT_77)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_107 = node.kind;
    if ((unsigned char)(zT_107 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_31; else goto z_bb_33;
    z_bb_29:
    zT_80 = self->store;
    zT_81 = zT_80->string_values;
    zT_82 = zT_81.items;
    zT_83 = (unsigned int)sl_payload;
    zT_84 = zT_82[zT_83];
    sl_str_id = zT_84;
    zT_88 = self->registry;
    zT_86 = zT_88->interner;
    zT_87 = sl_str_id;
    zT_90 = zF_9134020D_stringInternerGet(zT_86, zT_87);
    sl_bytes = zT_90;
    zT_92 = sl_bytes.len;
    zT_93 = (unsigned int)zT_92;
    sl_len = zT_93;
    goto z_bb_30;
    z_bb_30:
    zT_95 = self->registry;
    zT_97 = sl_len;
    zT_100 = zF_BA693C74_typeRegistryGetOrCr(zT_95, (unsigned int)(8), zT_97);
    sl_arr = zT_100;
    zT_101 = self->registry;
    zT_102 = sl_arr;
    zT_106 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_101, zT_102, (unsigned char)(1));
    result = zT_106;
    goto z_bb_27;
    z_bb_31:
    zT_111 = self;
    zT_112 = node_idx;
    zT_113 = zF_8C008E53_semanticAnalyzerRes(zT_111, zT_112);
    result = zT_113;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_27;
    z_bb_33:
    zT_114 = node.kind;
    if ((unsigned char)(zT_114 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_118 = self->expected_type_stack_len;
    zT_119 = 0;
    if ((unsigned char)(zT_118 > (unsigned int)zT_119)) goto z_bb_37; else goto z_bb_39;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_231 = node.kind;
    if ((unsigned char)(zT_231 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_59; else goto z_bb_61;
    z_bb_37:
    zT_122 = self->expected_type_stack_items;
    zT_123 = self->expected_type_stack_len;
    zT_124 = 1;
    zT_125 = zT_123 - zT_124;
    zT_126 = zT_122[zT_125];
    top = zT_126;
    zT_127 = 0;
    if ((unsigned char)(top != (unsigned int)zT_127)) goto z_bb_40; else goto z_bb_42;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_230 = 1;
    result = zT_230;
    goto z_bb_38;
    z_bb_40:
    zT_130 = 0;
    zT_131 = (unsigned int)zT_130;
    es = zT_131;
    zT_133 = self->registry;
    zT_134 = zT_133->types_items;
    zT_135 = (unsigned int)top;
    zT_136 = zT_134[zT_135];
    tty = zT_136;
    eff_top = top;
    zT_138 = tty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_229 = 1;
    result = zT_229;
    goto z_bb_41;
    z_bb_43:
    zT_143 = self->registry;
    zT_144 = zT_143->opt_items;
    zT_145 = tty.payload_idx;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zT_144[zT_146];
    zT_148 = zT_147.payload;
    opt_pay = zT_148;
    zT_149 = self->registry;
    zT_150 = zT_149->types_items;
    zT_151 = (unsigned int)opt_pay;
    zT_152 = zT_150[zT_151];
    tty = zT_152;
    eff_top = opt_pay;
    goto z_bb_44;
    z_bb_44:
    zT_153 = tty.kind;
    if ((unsigned char)(zT_153 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_45; else goto z_bb_47;
    z_bb_45:
    es = eff_top;
    goto z_bb_46;
    z_bb_46:
    zT_167 = 0;
    if ((unsigned char)(es != (unsigned int)zT_167)) goto z_bb_50; else goto z_bb_52;
    z_bb_47:
    zT_157 = tty.kind;
    if ((unsigned char)(zT_157 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_161 = self->registry;
    zT_162 = zT_161->eu_items;
    zT_163 = tty.payload_idx;
    zT_164 = (unsigned int)zT_163;
    zT_165 = zT_162[zT_164];
    zT_166 = zT_165.error_set;
    es = zT_166;
    goto z_bb_49;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_170 = self->store;
    zT_171 = node_idx;
    zT_173 = zF_8BA26B9E_astStoreNodePayload(zT_170, zT_171);
    name_id = zT_173;
    zT_175 = self->registry;
    zT_176 = es;
    zT_177 = name_id;
    zT_179 = zF_D2ECD176_typeRegistryErrorSe(zT_175, zT_176, zT_177);
    ord = zT_179;
    if ((unsigned char)(ord != (unsigned int)(4294967295u))) goto z_bb_53; else goto z_bb_55;
    z_bb_51:
    goto z_bb_41;
    z_bb_52:
    zT_220 = tty.kind;
    if ((unsigned char)(zT_220 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_56; else goto z_bb_58;
    z_bb_53:
    zT_183 = self->error_code_registry;
    zT_184 = name_id;
    zT_186 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_183, zT_184);
    reg_code = zT_186;
    zT_187 = self->enum_value_table;
    zT_188 = node_idx;
    zT_189 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_187, zT_188, zT_189);
    zT_191 = self->type_table;
    zT_192 = node_idx;
    zT_193 = es;
    zF_19B4A07D_resolvedTypeTableSe(zT_191, zT_192, zT_193);
    result = es;
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_196 = node.span_start;
    sp = zT_196;
    zT_198 = node.span_len;
    zT_200 = sp + (unsigned int)((unsigned int)zT_198);
    ep = zT_200;
    zT_202 = "error literal not found in error set";
    zT_204 = 36;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    eln_msg = zT_203;
    zT_205 = self->diag;
    zT_208 = self->source_file_id;
    zT_209 = sp;
    zT_210 = ep;
    zT_211 = eln_msg;
    zT_218 = zF_C82559AC_diagnosticCollector(zT_205, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3011_ERROR_LITERAL_NOT_IN_SET)), zT_208, zT_209, zT_210, zT_211);
    (void)zT_218;
    zT_219 = 1;
    result = zT_219;
    goto z_bb_54;
    z_bb_56:
    zT_224 = self->type_table;
    zT_225 = node_idx;
    zT_226 = eff_top;
    zF_19B4A07D_resolvedTypeTableSe(zT_224, zT_225, zT_226);
    result = eff_top;
    goto z_bb_57;
    z_bb_57:
    goto z_bb_51;
    z_bb_58:
    zT_228 = 1;
    result = zT_228;
    goto z_bb_57;
    z_bb_59:
    zT_235 = self;
    zT_236 = self->module_id;
    zT_240 = self->store;
    zT_241 = node_idx;
    zT_243 = zF_53458827_astStoreIdentifier(zT_240, zT_241);
    zT_237 = zT_243;
    zT_238 = node_idx;
    zT_244 = zF_9F1ECA79_semanticAnalyzerRes(zT_235, zT_236, zT_237, zT_238);
    result = zT_244;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_35;
    z_bb_61:
    zT_245 = node.kind;
    if ((unsigned char)(zT_245 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    zT_249 = self;
    zT_250 = node_idx;
    zT_251 = zF_DDD991E1_semanticAnalyzerRes(zT_249, zT_250);
    result = zT_251;
    zT_253 = "FAD:R";
    zT_255 = 5;
    zT_254.ptr = zT_253;
    zT_254.len = zT_255;
    fad = zT_254;
    zT_256 = fad;
    zT_257 = result;
    zF_C914CB83_markerWriteInt(zT_256, zT_257);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_258 = node.kind;
    if ((unsigned char)(zT_258 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_65; else goto z_bb_67;
    z_bb_65:
    zT_262 = self;
    zT_263 = node_idx;
    zT_264 = zF_1926BC05_semanticAnalyzerRes(zT_262, zT_263);
    result = zT_264;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_265 = node.kind;
    if ((unsigned char)(zT_265 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_68; else goto z_bb_70;
    z_bb_68:
    zT_269 = self;
    zT_270 = node_idx;
    zT_271 = zF_F902E73E_semanticAnalyzerRes(zT_269, zT_270);
    result = zT_271;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_66;
    z_bb_70:
    zT_272 = node.kind;
    if ((unsigned char)(zT_272 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_71; else goto z_bb_73;
    z_bb_71:
    zT_277 = self;
    zT_278 = node.child_0;
    zT_280 = zF_54F95822_semanticAnalyzerRes(zT_277, zT_278);
    base = zT_280;
    if ((unsigned char)(base != (unsigned int)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    goto z_bb_69;
    z_bb_73:
    zT_308 = node.kind;
    if ((unsigned char)(zT_308 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_86; else goto z_bb_88;
    z_bb_74:
    zT_283 = base != (unsigned int)(1);
    goto z_bb_76;
    z_bb_75:
    zT_283 = 0;
    goto z_bb_76;
    z_bb_76:
    if (zT_283) goto z_bb_77; else goto z_bb_79;
    z_bb_77:
    zT_287 = self->registry;
    zT_288 = zT_287->types_items;
    zT_289 = (unsigned int)base;
    zT_290 = zT_288[zT_289];
    bt = zT_290;
    zT_291 = bt.kind;
    if ((unsigned char)(zT_291 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_81; else goto z_bb_80;
    z_bb_78:
    goto z_bb_72;
    z_bb_79:
    zT_307 = 1;
    result = zT_307;
    goto z_bb_78;
    z_bb_80:
    zT_296 = bt.kind;
    zT_295 = zT_296 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_82;
    z_bb_81:
    zT_295 = 1;
    goto z_bb_82;
    z_bb_82:
    if (zT_295) goto z_bb_83; else goto z_bb_85;
    z_bb_83:
    zT_301 = self->registry;
    zT_302 = zT_301->ptr_items;
    zT_303 = bt.payload_idx;
    zT_304 = (unsigned int)zT_303;
    zT_305 = zT_302[zT_304];
    pp = zT_305;
    zT_306 = pp.base;
    result = zT_306;
    goto z_bb_84;
    z_bb_84:
    goto z_bb_78;
    z_bb_85:
    result = base;
    goto z_bb_84;
    z_bb_86:
    zT_313 = self;
    zT_314 = node.child_0;
    zT_316 = zF_54F95822_semanticAnalyzerRes(zT_313, zT_314);
    base = zT_316;
    if ((unsigned char)(base != (unsigned int)(0))) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    goto z_bb_72;
    z_bb_88:
    zT_432 = node.kind;
    if ((unsigned char)(zT_432 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_113; else goto z_bb_115;
    z_bb_89:
    zT_319 = base != (unsigned int)(1);
    goto z_bb_91;
    z_bb_90:
    zT_319 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_319) goto z_bb_92; else goto z_bb_94;
    z_bb_92:
    zT_323 = self->store;
    zT_324 = node.child_0;
    zT_327 = zF_FCDD1D35_astStoreNodeAt(zT_323, zT_324);
    base_node = zT_327;
    zT_328 = base_node.kind;
    if ((unsigned char)(zT_328 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_95; else goto z_bb_96;
    z_bb_93:
    goto z_bb_87;
    z_bb_94:
    zT_431 = 1;
    result = zT_431;
    goto z_bb_93;
    z_bb_95:
    zT_333 = self;
    zT_334 = base_node.child_0;
    zT_336 = zF_54F95822_semanticAnalyzerRes(zT_333, zT_334);
    fa_base_t = zT_336;
    st = fa_base_t;
    if ((unsigned char)(fa_base_t != (unsigned int)(0))) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    zT_425 = self->registry;
    zT_426 = base;
    zT_430 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_425, zT_426, (unsigned char)(0));
    result = zT_430;
    goto z_bb_93;
    z_bb_97:
    zT_340 = fa_base_t != (unsigned int)(1);
    goto z_bb_99;
    z_bb_98:
    zT_340 = 0;
    goto z_bb_99;
    z_bb_99:
    if (zT_340) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_344 = self->registry;
    zT_345 = zT_344->types_items;
    zT_346 = (unsigned int)st;
    zT_347 = zT_345[zT_346];
    st_ty = zT_347;
    zT_348 = st_ty.kind;
    if ((unsigned char)(zT_348 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_103; else goto z_bb_102;
    z_bb_101:
    goto z_bb_96;
    z_bb_102:
    zT_353 = st_ty.kind;
    zT_352 = zT_353 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_104;
    z_bb_103:
    zT_352 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_352) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_357 = self->registry;
    zT_358 = zT_357->ptr_items;
    zT_359 = st_ty.payload_idx;
    zT_360 = (unsigned int)zT_359;
    zT_361 = zT_358[zT_360];
    zT_362 = zT_361.base;
    st = zT_362;
    zT_363 = self->registry;
    zT_364 = zT_363->types_items;
    zT_365 = (unsigned int)st;
    zT_366 = zT_364[zT_365];
    st_ty = zT_366;
    goto z_bb_106;
    z_bb_106:
    zT_367 = st_ty.kind;
    if ((unsigned char)(zT_367 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_372 = self;
    zT_373 = st;
    zT_374 = zF_1BB4D489_semanticAnalyzerPac(zT_372, zT_373);
    sd = zT_374;
    if ((unsigned char)(sd != (unsigned int)(0))) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    zT_399 = st_ty.kind;
    if ((unsigned char)(zT_399 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_111; else goto z_bb_112;
    z_bb_109:
    zT_378 = node.span_start;
    aps = zT_378;
    zT_380 = node.span_len;
    zT_382 = aps + (unsigned int)((unsigned int)zT_380);
    ape = zT_382;
    zT_384 = "cannot take the address of a field of a packed struct; packed fields have no address";
    zT_386 = 84;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    aof_msg = zT_385;
    zT_387 = self->diag;
    zT_390 = self->source_file_id;
    zT_391 = aps;
    zT_392 = ape;
    zT_393 = aof_msg;
    zT_398 = zF_C82559AC_diagnosticCollector(zT_387, (unsigned char)(0), (unsigned short)(3000), zT_390, zT_391, zT_392, zT_393);
    (void)zT_398;
    goto z_bb_110;
    z_bb_110:
    goto z_bb_108;
    z_bb_111:
    zT_404 = node.span_start;
    apu_s = zT_404;
    zT_406 = node.span_len;
    zT_408 = apu_s + (unsigned int)((unsigned int)zT_406);
    apu_e = zT_408;
    zT_410 = "cannot take the address of a field of a packed union; packed fields have no address";
    zT_412 = 83;
    zT_411.ptr = zT_410;
    zT_411.len = zT_412;
    aou_msg = zT_411;
    zT_413 = self->diag;
    zT_416 = self->source_file_id;
    zT_417 = apu_s;
    zT_418 = apu_e;
    zT_419 = aou_msg;
    zT_424 = zF_C82559AC_diagnosticCollector(zT_413, (unsigned char)(0), (unsigned short)(3000), zT_416, zT_417, zT_418, zT_419);
    (void)zT_424;
    goto z_bb_112;
    z_bb_112:
    goto z_bb_101;
    z_bb_113:
    zT_436 = self;
    zT_437 = node_idx;
    zT_438 = zF_87E78775_semanticAnalyzerRes(zT_436, zT_437);
    result = zT_438;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_87;
    z_bb_115:
    zT_439 = node.kind;
    if ((unsigned char)(zT_439 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_444 = self;
    zT_445 = node.child_0;
    zT_447 = zF_CAF1FD28_semanticAnalyzerIsB(zT_444, zT_445);
    zT_443 = !zT_447;
    goto z_bb_118;
    z_bb_117:
    zT_443 = 0;
    goto z_bb_118;
    z_bb_118:
    if (zT_443) goto z_bb_119; else goto z_bb_121;
    z_bb_119:
    zT_450 = "unsupported builtin function";
    zT_452 = 28;
    zT_451.ptr = zT_450;
    zT_451.len = zT_452;
    ub_msg = zT_451;
    zT_453 = self->diag;
    zT_456 = self->source_file_id;
    zT_457 = node.span_start;
    zT_465 = node.span_start;
    zT_466 = node.span_len;
    zT_459 = ub_msg;
    zT_469 = zF_C82559AC_diagnosticCollector(zT_453, (unsigned char)(0), (unsigned short)(3000), zT_456, zT_457, (unsigned int)(zT_465 + (unsigned int)((unsigned int)zT_466)), zT_459);
    (void)zT_469;
    zT_470 = 1;
    result = zT_470;
    goto z_bb_120;
    z_bb_120:
    goto z_bb_114;
    z_bb_121:
    zT_471 = node.kind;
    if ((unsigned char)(zT_471 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_122; else goto z_bb_124;
    z_bb_122:
    zT_476 = self->store;
    zT_477 = node_idx;
    zT_479 = zF_152E19CB_astStoreNodeExtraCh(zT_476, zT_477);
    zT_480 = (unsigned int)zT_479;
    ec_n = zT_480;
    zT_482 = "@cVaArg";
    zT_484 = 7;
    zT_483.ptr = zT_482;
    zT_483.len = zT_484;
    cva = zT_483;
    zT_485 = node.child_0;
    zT_486 = self->size_of_name_id;
    if ((unsigned char)(zT_485 == zT_486)) goto z_bb_126; else goto z_bb_125;
    z_bb_123:
    goto z_bb_120;
    z_bb_124:
    zT_1343 = node.kind;
    if ((unsigned char)(zT_1343 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_332; else goto z_bb_334;
    z_bb_125:
    zT_489 = node.child_0;
    zT_490 = self->align_of_name_id;
    zT_488 = zT_489 == zT_490;
    goto z_bb_127;
    z_bb_126:
    zT_488 = 1;
    goto z_bb_127;
    z_bb_127:
    if (zT_488) goto z_bb_129; else goto z_bb_128;
    z_bb_128:
    zT_493 = node.child_0;
    zT_494 = self->offset_of_name_id;
    zT_492 = zT_493 == zT_494;
    goto z_bb_130;
    z_bb_129:
    zT_492 = 1;
    goto z_bb_130;
    z_bb_130:
    if (zT_492) goto z_bb_132; else goto z_bb_131;
    z_bb_131:
    zT_497 = node.child_0;
    zT_498 = self->bit_size_of_name_id;
    zT_496 = zT_497 == zT_498;
    goto z_bb_133;
    z_bb_132:
    zT_496 = 1;
    goto z_bb_133;
    z_bb_133:
    if (zT_496) goto z_bb_135; else goto z_bb_134;
    z_bb_134:
    zT_501 = node.child_0;
    zT_502 = self->bit_offset_of_name_id;
    zT_500 = zT_501 == zT_502;
    goto z_bb_136;
    z_bb_135:
    zT_500 = 1;
    goto z_bb_136;
    z_bb_136:
    if (zT_500) goto z_bb_137; else goto z_bb_139;
    z_bb_137:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_140; else goto z_bb_141;
    z_bb_138:
    goto z_bb_123;
    z_bb_139:
    zT_531 = node.child_0;
    zT_532 = self->ptrtoint_name_id;
    if ((unsigned char)(zT_531 == zT_532)) goto z_bb_143; else goto z_bb_142;
    z_bb_140:
    zT_508 = self->store;
    zT_507.store = zT_508;
    zT_509 = self->registry;
    zT_507.typereg = zT_509;
    zT_510 = self->symbols;
    zT_507.symbol_reg = zT_510;
    zT_511 = self->interner;
    zT_507.interner = zT_511;
    zT_512 = self->module_id;
    zT_507.module_id = zT_512;
    zT_513 = self->diag;
    zT_514.has_value = 1;
    zT_514.value = zT_513;
    zT_507.diag = zT_514;
    zT_515.has_value = 0;
    zT_507.local_consts = zT_515;
    zT_516.has_value = 0;
    zT_507.local_types = zT_516;
    zT_517 = self->source_file_id;
    zT_507.source_file_id = zT_517;
    so_env = zT_507;
    zT_518 = &so_env;
    zT_522 = self->store;
    zT_523 = node_idx;
    zT_527 = zF_B10B1BC1_astStoreNodeExtraCh(zT_522, zT_523, (unsigned int)(0));
    zT_519 = zT_527;
    zT_529 = zF_F2107C15_resolveTypeExprFull(zT_518, zT_519, (unsigned int)(0));
    (void)zT_529;
    goto z_bb_141;
    z_bb_141:
    zT_530 = 19;
    result = zT_530;
    goto z_bb_138;
    z_bb_142:
    zT_535 = node.child_0;
    zT_536 = self->int_from_ptr_name_id;
    zT_534 = zT_535 == zT_536;
    goto z_bb_144;
    z_bb_143:
    zT_534 = 1;
    goto z_bb_144;
    z_bb_144:
    if (zT_534) goto z_bb_145; else goto z_bb_147;
    z_bb_145:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_148; else goto z_bb_149;
    z_bb_146:
    goto z_bb_138;
    z_bb_147:
    zT_550 = node.child_0;
    zT_551 = self->ptr_from_int_name_id;
    if ((unsigned char)(zT_550 == zT_551)) goto z_bb_150; else goto z_bb_152;
    z_bb_148:
    zT_540 = self;
    zT_542 = self->store;
    zT_543 = node_idx;
    zT_547 = zF_B10B1BC1_astStoreNodeExtraCh(zT_542, zT_543, (unsigned int)(0));
    zT_541 = zT_547;
    zT_548 = zF_54F95822_semanticAnalyzerRes(zT_540, zT_541);
    (void)zT_548;
    goto z_bb_149;
    z_bb_149:
    zT_549 = 13;
    result = zT_549;
    goto z_bb_146;
    z_bb_150:
    zT_555 = 1;
    pfi_res = zT_555;
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_153; else goto z_bb_154;
    z_bb_151:
    goto z_bb_146;
    z_bb_152:
    zT_614 = node.child_0;
    zT_615 = self->field_parent_ptr_name_id;
    if ((unsigned char)(zT_614 == zT_615)) goto z_bb_167; else goto z_bb_169;
    z_bb_153:
    zT_558 = self;
    zT_560 = self->store;
    zT_561 = node_idx;
    zT_565 = zF_B10B1BC1_astStoreNodeExtraCh(zT_560, zT_561, (unsigned int)(0));
    zT_559 = zT_565;
    zT_566 = zF_54F95822_semanticAnalyzerRes(zT_558, zT_559);
    (void)zT_566;
    zT_568 = self;
    zT_569 = zF_4DE7C2BC_topExpectedType(zT_568);
    pfi_top = zT_569;
    if ((unsigned char)(pfi_top != (unsigned int)(0))) goto z_bb_155; else goto z_bb_156;
    z_bb_154:
    if ((unsigned char)(pfi_res == (unsigned int)(1))) goto z_bb_165; else goto z_bb_166;
    z_bb_155:
    zT_572 = pfi_top != (unsigned int)(18);
    goto z_bb_157;
    z_bb_156:
    zT_572 = 0;
    goto z_bb_157;
    z_bb_157:
    if (zT_572) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_576 = self->registry;
    zT_577 = zT_576->types_items;
    zT_578 = (unsigned int)pfi_top;
    zT_579 = zT_577[zT_578];
    pfi_ty = zT_579;
    zT_580 = pfi_ty.kind;
    if ((unsigned char)(zT_580 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_161; else goto z_bb_160;
    z_bb_159:
    goto z_bb_154;
    z_bb_160:
    zT_585 = pfi_ty.kind;
    zT_584 = zT_585 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_162;
    z_bb_161:
    zT_584 = 1;
    goto z_bb_162;
    z_bb_162:
    if (zT_584) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    pfi_res = pfi_top;
    goto z_bb_164;
    z_bb_164:
    goto z_bb_159;
    z_bb_165:
    zT_592 = "cannot infer pointer type for @ptrFromInt; annotate the target variable type";
    zT_594 = 76;
    zT_593.ptr = zT_592;
    zT_593.len = zT_594;
    pfi_msg = zT_593;
    zT_595 = self->diag;
    zT_598 = self->source_file_id;
    zT_599 = node.span_start;
    zT_609 = node.span_start;
    zT_610 = node.span_len;
    zT_601 = pfi_msg;
    zT_613 = zF_C82559AC_diagnosticCollector(zT_595, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_598, zT_599, (unsigned int)(zT_609 + (unsigned int)((unsigned int)zT_610)), zT_601);
    (void)zT_613;
    goto z_bb_166;
    z_bb_166:
    result = pfi_res;
    goto z_bb_151;
    z_bb_167:
    zT_619 = 1;
    fpp_res = zT_619;
    if ((unsigned char)(ec_n >= (unsigned int)(3))) goto z_bb_170; else goto z_bb_171;
    z_bb_168:
    goto z_bb_151;
    z_bb_169:
    zT_664 = node.child_0;
    zT_665 = self->bitcast_name_id;
    if ((unsigned char)(zT_664 == zT_665)) goto z_bb_174; else goto z_bb_176;
    z_bb_170:
    zT_624 = self->store;
    zT_623.store = zT_624;
    zT_625 = self->registry;
    zT_623.typereg = zT_625;
    zT_626 = self->symbols;
    zT_623.symbol_reg = zT_626;
    zT_627 = self->interner;
    zT_623.interner = zT_627;
    zT_628 = self->module_id;
    zT_623.module_id = zT_628;
    zT_629 = self->diag;
    zT_630.has_value = 1;
    zT_630.value = zT_629;
    zT_623.diag = zT_630;
    zT_631.has_value = 0;
    zT_623.local_consts = zT_631;
    zT_632.has_value = 0;
    zT_623.local_types = zT_632;
    zT_633 = self->source_file_id;
    zT_623.source_file_id = zT_633;
    fpp_env = zT_623;
    zT_635 = &fpp_env;
    zT_639 = self->store;
    zT_640 = node_idx;
    zT_644 = zF_B10B1BC1_astStoreNodeExtraCh(zT_639, zT_640, (unsigned int)(0));
    zT_636 = zT_644;
    zT_646 = zF_F2107C15_resolveTypeExprFull(zT_635, zT_636, (unsigned int)(0));
    fpp_outer = zT_646;
    if ((unsigned char)(fpp_outer != (unsigned int)(18))) goto z_bb_172; else goto z_bb_173;
    z_bb_171:
    result = fpp_res;
    goto z_bb_168;
    z_bb_172:
    zT_649 = self;
    zT_651 = self->store;
    zT_652 = node_idx;
    zT_656 = zF_B10B1BC1_astStoreNodeExtraCh(zT_651, zT_652, (unsigned int)(2));
    zT_650 = zT_656;
    zT_657 = zF_54F95822_semanticAnalyzerRes(zT_649, zT_650);
    (void)zT_657;
    zT_658 = self->registry;
    zT_659 = fpp_outer;
    zT_663 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_658, zT_659, (unsigned char)(0));
    fpp_res = zT_663;
    goto z_bb_173;
    z_bb_173:
    goto z_bb_171;
    z_bb_174:
    zT_669 = 1;
    bc_res = zT_669;
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_177; else goto z_bb_178;
    z_bb_175:
    goto z_bb_168;
    z_bb_176:
    zT_770 = node.child_0;
    zT_771 = self->getchar_name_id;
    if ((unsigned char)(zT_770 == zT_771)) goto z_bb_199; else goto z_bb_201;
    z_bb_177:
    zT_674 = self->store;
    zT_673.store = zT_674;
    zT_675 = self->registry;
    zT_673.typereg = zT_675;
    zT_676 = self->symbols;
    zT_673.symbol_reg = zT_676;
    zT_677 = self->interner;
    zT_673.interner = zT_677;
    zT_678 = self->module_id;
    zT_673.module_id = zT_678;
    zT_679 = self->diag;
    zT_680.has_value = 1;
    zT_680.value = zT_679;
    zT_673.diag = zT_680;
    zT_681.has_value = 0;
    zT_673.local_consts = zT_681;
    zT_682.has_value = 0;
    zT_673.local_types = zT_682;
    zT_683 = self->source_file_id;
    zT_673.source_file_id = zT_683;
    bc_env = zT_673;
    zT_685 = &bc_env;
    zT_689 = self->store;
    zT_690 = node_idx;
    zT_694 = zF_B10B1BC1_astStoreNodeExtraCh(zT_689, zT_690, (unsigned int)(0));
    zT_686 = zT_694;
    zT_696 = zF_F2107C15_resolveTypeExprFull(zT_685, zT_686, (unsigned int)(0));
    bc_dst = zT_696;
    if ((unsigned char)(bc_dst != (unsigned int)(18))) goto z_bb_179; else goto z_bb_180;
    z_bb_178:
    result = bc_res;
    goto z_bb_175;
    z_bb_179:
    zT_700 = self;
    zT_702 = self->store;
    zT_703 = node_idx;
    zT_707 = zF_B10B1BC1_astStoreNodeExtraCh(zT_702, zT_703, (unsigned int)(1));
    zT_701 = zT_707;
    zT_708 = zF_54F95822_semanticAnalyzerRes(zT_700, zT_701);
    bc_src = zT_708;
    zT_710 = 0;
    bc_ok = zT_710;
    if ((unsigned char)(bc_src != (unsigned int)(18))) goto z_bb_181; else goto z_bb_182;
    z_bb_180:
    goto z_bb_178;
    z_bb_181:
    zT_714 = self->registry;
    zT_715 = bc_dst;
    zT_717 = zF_3290E9C4_typeRegistryIsInteg(zT_714, zT_715);
    zT_713 = zT_717;
    goto z_bb_183;
    z_bb_182:
    zT_713 = 0;
    goto z_bb_183;
    z_bb_183:
    if (zT_713) goto z_bb_184; else goto z_bb_185;
    z_bb_184:
    zT_719 = self->registry;
    zT_720 = bc_src;
    zT_722 = zF_3290E9C4_typeRegistryIsInteg(zT_719, zT_720);
    zT_718 = zT_722;
    goto z_bb_186;
    z_bb_185:
    zT_718 = 0;
    goto z_bb_186;
    z_bb_186:
    if (zT_718) goto z_bb_187; else goto z_bb_188;
    z_bb_187:
    zT_724 = self->registry;
    zT_725 = zT_724->types_items;
    zT_726 = (unsigned int)bc_dst;
    zT_727 = zT_725[zT_726];
    bc_dty = zT_727;
    zT_729 = self->registry;
    zT_730 = zT_729->types_items;
    zT_731 = (unsigned int)bc_src;
    zT_732 = zT_730[zT_731];
    bc_sty = zT_732;
    zT_733 = bc_dty.state;
    if ((unsigned char)(zT_733 == (unsigned char)(2))) goto z_bb_189; else goto z_bb_190;
    z_bb_188:
    bc_res = bc_dst;
    if ((unsigned char)(bc_ok == (unsigned char)(0))) goto z_bb_197; else goto z_bb_198;
    z_bb_189:
    zT_737 = bc_sty.state;
    zT_736 = zT_737 == (unsigned char)(2);
    goto z_bb_191;
    z_bb_190:
    zT_736 = 0;
    goto z_bb_191;
    z_bb_191:
    if (zT_736) goto z_bb_192; else goto z_bb_193;
    z_bb_192:
    zT_741 = bc_dty.size;
    zT_742 = bc_sty.size;
    zT_740 = zT_741 == zT_742;
    goto z_bb_194;
    z_bb_193:
    zT_740 = 0;
    goto z_bb_194;
    z_bb_194:
    if (zT_740) goto z_bb_195; else goto z_bb_196;
    z_bb_195:
    zT_744 = 1;
    bc_ok = zT_744;
    goto z_bb_196;
    z_bb_196:
    goto z_bb_188;
    z_bb_197:
    zT_748 = "@bitCast requires same-size integer source and destination types";
    zT_750 = 64;
    zT_749.ptr = zT_748;
    zT_749.len = zT_750;
    bc_msg = zT_749;
    zT_751 = self->diag;
    zT_754 = self->source_file_id;
    zT_755 = node.span_start;
    zT_765 = node.span_start;
    zT_766 = node.span_len;
    zT_757 = bc_msg;
    zT_769 = zF_C82559AC_diagnosticCollector(zT_751, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_754, zT_755, (unsigned int)(zT_765 + (unsigned int)((unsigned int)zT_766)), zT_757);
    (void)zT_769;
    goto z_bb_198;
    z_bb_198:
    goto z_bb_180;
    z_bb_199:
    zT_773 = 8;
    result = zT_773;
    goto z_bb_200;
    z_bb_200:
    goto z_bb_175;
    z_bb_201:
    zT_774 = node.child_0;
    zT_775 = self->exit_name_id;
    if ((unsigned char)(zT_774 == zT_775)) goto z_bb_202; else goto z_bb_204;
    z_bb_202:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_205; else goto z_bb_206;
    z_bb_203:
    goto z_bb_200;
    z_bb_204:
    zT_789 = node.child_0;
    zT_790 = self->panic_name_id;
    if ((unsigned char)(zT_789 == zT_790)) goto z_bb_207; else goto z_bb_209;
    z_bb_205:
    zT_779 = self;
    zT_781 = self->store;
    zT_782 = node_idx;
    zT_786 = zF_B10B1BC1_astStoreNodeExtraCh(zT_781, zT_782, (unsigned int)(0));
    zT_780 = zT_786;
    zT_787 = zF_54F95822_semanticAnalyzerRes(zT_779, zT_780);
    (void)zT_787;
    goto z_bb_206;
    z_bb_206:
    zT_788 = 3;
    result = zT_788;
    goto z_bb_203;
    z_bb_207:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_210; else goto z_bb_211;
    z_bb_208:
    goto z_bb_203;
    z_bb_209:
    zT_804 = node.child_0;
    zT_805 = self->putchar_name_id;
    if ((unsigned char)(zT_804 == zT_805)) goto z_bb_213; else goto z_bb_212;
    z_bb_210:
    zT_794 = self;
    zT_796 = self->store;
    zT_797 = node_idx;
    zT_801 = zF_B10B1BC1_astStoreNodeExtraCh(zT_796, zT_797, (unsigned int)(0));
    zT_795 = zT_801;
    zT_802 = zF_54F95822_semanticAnalyzerRes(zT_794, zT_795);
    (void)zT_802;
    goto z_bb_211;
    z_bb_211:
    zT_803 = 3;
    result = zT_803;
    goto z_bb_208;
    z_bb_212:
    zT_808 = node.child_0;
    zT_809 = self->sleep_ms_name_id;
    zT_807 = zT_808 == zT_809;
    goto z_bb_214;
    z_bb_213:
    zT_807 = 1;
    goto z_bb_214;
    z_bb_214:
    if (zT_807) goto z_bb_215; else goto z_bb_217;
    z_bb_215:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_218; else goto z_bb_219;
    z_bb_216:
    goto z_bb_208;
    z_bb_217:
    zT_823 = node.child_0;
    zT_824 = self->stdout_write_name_id;
    if ((unsigned char)(zT_823 == zT_824)) goto z_bb_221; else goto z_bb_220;
    z_bb_218:
    zT_813 = self;
    zT_815 = self->store;
    zT_816 = node_idx;
    zT_820 = zF_B10B1BC1_astStoreNodeExtraCh(zT_815, zT_816, (unsigned int)(0));
    zT_814 = zT_820;
    zT_821 = zF_54F95822_semanticAnalyzerRes(zT_813, zT_814);
    (void)zT_821;
    goto z_bb_219;
    z_bb_219:
    zT_822 = 1;
    result = zT_822;
    goto z_bb_216;
    z_bb_220:
    zT_827 = node.child_0;
    zT_828 = self->stderr_write_name_id;
    zT_826 = zT_827 == zT_828;
    goto z_bb_222;
    z_bb_221:
    zT_826 = 1;
    goto z_bb_222;
    z_bb_222:
    if (zT_826) goto z_bb_223; else goto z_bb_225;
    z_bb_223:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_226; else goto z_bb_228;
    z_bb_224:
    goto z_bb_216;
    z_bb_225:
    zT_862 = node.child_0;
    zT_863 = self->is_windows_name_id;
    if ((unsigned char)(zT_862 == zT_863)) goto z_bb_231; else goto z_bb_233;
    z_bb_226:
    zT_832 = self;
    zT_834 = self->store;
    zT_835 = node_idx;
    zT_839 = zF_B10B1BC1_astStoreNodeExtraCh(zT_834, zT_835, (unsigned int)(0));
    zT_833 = zT_839;
    zT_840 = zF_54F95822_semanticAnalyzerRes(zT_832, zT_833);
    (void)zT_840;
    zT_841 = self;
    zT_843 = self->store;
    zT_844 = node_idx;
    zT_848 = zF_B10B1BC1_astStoreNodeExtraCh(zT_843, zT_844, (unsigned int)(1));
    zT_842 = zT_848;
    zT_849 = zF_54F95822_semanticAnalyzerRes(zT_841, zT_842);
    (void)zT_849;
    goto z_bb_227;
    z_bb_227:
    zT_861 = 1;
    result = zT_861;
    goto z_bb_224;
    z_bb_228:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_229; else goto z_bb_230;
    z_bb_229:
    zT_852 = self;
    zT_854 = self->store;
    zT_855 = node_idx;
    zT_859 = zF_B10B1BC1_astStoreNodeExtraCh(zT_854, zT_855, (unsigned int)(0));
    zT_853 = zT_859;
    zT_860 = zF_54F95822_semanticAnalyzerRes(zT_852, zT_853);
    (void)zT_860;
    goto z_bb_230;
    z_bb_230:
    goto z_bb_227;
    z_bb_231:
    zT_865 = 2;
    result = zT_865;
    goto z_bb_232;
    z_bb_232:
    goto z_bb_224;
    z_bb_233:
    zT_866 = node.child_0;
    zT_867 = self->console_clear_name_id;
    if ((unsigned char)(zT_866 == zT_867)) goto z_bb_234; else goto z_bb_236;
    z_bb_234:
    zT_869 = 1;
    result = zT_869;
    goto z_bb_235;
    z_bb_235:
    goto z_bb_232;
    z_bb_236:
    zT_870 = node.child_0;
    zT_871 = self->console_gotoxy_name_id;
    if ((unsigned char)(zT_870 == zT_871)) goto z_bb_238; else goto z_bb_237;
    z_bb_237:
    zT_874 = node.child_0;
    zT_875 = self->console_set_color_name_id;
    zT_873 = zT_874 == zT_875;
    goto z_bb_239;
    z_bb_238:
    zT_873 = 1;
    goto z_bb_239;
    z_bb_239:
    if (zT_873) goto z_bb_240; else goto z_bb_242;
    z_bb_240:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_243; else goto z_bb_245;
    z_bb_241:
    goto z_bb_235;
    z_bb_242:
    zT_909 = node.child_0;
    zT_910 = self->async_frame_size_name_id;
    if ((unsigned char)(zT_909 == zT_910)) goto z_bb_248; else goto z_bb_250;
    z_bb_243:
    zT_879 = self;
    zT_881 = self->store;
    zT_882 = node_idx;
    zT_886 = zF_B10B1BC1_astStoreNodeExtraCh(zT_881, zT_882, (unsigned int)(0));
    zT_880 = zT_886;
    zT_887 = zF_54F95822_semanticAnalyzerRes(zT_879, zT_880);
    (void)zT_887;
    zT_888 = self;
    zT_890 = self->store;
    zT_891 = node_idx;
    zT_895 = zF_B10B1BC1_astStoreNodeExtraCh(zT_890, zT_891, (unsigned int)(1));
    zT_889 = zT_895;
    zT_896 = zF_54F95822_semanticAnalyzerRes(zT_888, zT_889);
    (void)zT_896;
    goto z_bb_244;
    z_bb_244:
    zT_908 = 1;
    result = zT_908;
    goto z_bb_241;
    z_bb_245:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    zT_899 = self;
    zT_901 = self->store;
    zT_902 = node_idx;
    zT_906 = zF_B10B1BC1_astStoreNodeExtraCh(zT_901, zT_902, (unsigned int)(0));
    zT_900 = zT_906;
    zT_907 = zF_54F95822_semanticAnalyzerRes(zT_899, zT_900);
    (void)zT_907;
    goto z_bb_247;
    z_bb_247:
    goto z_bb_244;
    z_bb_248:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_251; else goto z_bb_252;
    z_bb_249:
    goto z_bb_241;
    z_bb_250:
    zT_980 = node.child_0;
    zT_981 = self->async_init_name_id;
    if ((unsigned char)(zT_980 == zT_981)) goto z_bb_259; else goto z_bb_261;
    z_bb_251:
    zT_914 = self;
    zT_916 = self->store;
    zT_917 = node_idx;
    zT_921 = zF_B10B1BC1_astStoreNodeExtraCh(zT_916, zT_917, (unsigned int)(0));
    zT_915 = zT_921;
    zT_922 = zF_54F95822_semanticAnalyzerRes(zT_914, zT_915);
    (void)zT_922;
    zT_924 = 0;
    afs_susp = zT_924;
    zT_925 = self->store;
    zT_926 = self->symbols;
    zT_927 = self->module_id;
    zT_932 = self->store;
    zT_933 = node_idx;
    zT_937 = zF_B10B1BC1_astStoreNodeExtraCh(zT_932, zT_933, (unsigned int)(0));
    zT_928 = zT_937;
    zT_938 = zF_860C82EC_resolveCalleeKey(zT_925, zT_926, zT_927, zT_928);
    zT_939 = zT_938.has_value;
    if (zT_939) goto z_bb_253; else goto z_bb_254;
    z_bb_252:
    zT_979 = 19;
    result = zT_979;
    goto z_bb_249;
    z_bb_253:
    afs_k = zT_938.value;
    zT_944 = (unsigned int)(zT_79FAE712_u64)(afs_k >> (zT_79FAE712_u64)(32));
    afs_mid = zT_944;
    zT_948 = (unsigned int)(zT_79FAE712_u64)(afs_k & (zT_79FAE712_u64)(4294967295u));
    afs_nid = zT_948;
    zT_949 = self->suspending_fns;
    zT_950 = afs_mid;
    zT_951 = afs_nid;
    zT_953 = zF_7C7E43BF_asyncIsSuspending(zT_949, zT_950, zT_951);
    if (zT_953) goto z_bb_255; else goto z_bb_256;
    z_bb_254:
    if ((unsigned char)(!afs_susp)) goto z_bb_257; else goto z_bb_258;
    z_bb_255:
    zT_954 = 1;
    afs_susp = zT_954;
    goto z_bb_256;
    z_bb_256:
    goto z_bb_254;
    z_bb_257:
    zT_957 = "@asyncFrameSize argument must be a known suspending function";
    zT_959 = 60;
    zT_958.ptr = zT_957;
    zT_958.len = zT_959;
    e3046 = zT_958;
    zT_960 = self->diag;
    zT_963 = self->source_file_id;
    zT_964 = node.span_start;
    zT_974 = node.span_start;
    zT_975 = node.span_len;
    zT_966 = e3046;
    zT_978 = zF_C82559AC_diagnosticCollector(zT_960, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3046_ASYNC_FRAME_SIZE_INVALID)), zT_963, zT_964, (unsigned int)(zT_974 + (unsigned int)((unsigned int)zT_975)), zT_966);
    (void)zT_978;
    goto z_bb_258;
    z_bb_258:
    goto z_bb_252;
    z_bb_259:
    if ((unsigned char)(ec_n >= (unsigned int)(4))) goto z_bb_262; else goto z_bb_263;
    z_bb_260:
    goto z_bb_249;
    z_bb_261:
    zT_1030 = node.child_0;
    zT_1031 = self->async_resume_name_id;
    if ((unsigned char)(zT_1030 == zT_1031)) goto z_bb_264; else goto z_bb_266;
    z_bb_262:
    zT_985 = self;
    zT_987 = self->store;
    zT_988 = node_idx;
    zT_992 = zF_B10B1BC1_astStoreNodeExtraCh(zT_987, zT_988, (unsigned int)(0));
    zT_986 = zT_992;
    zT_993 = zF_54F95822_semanticAnalyzerRes(zT_985, zT_986);
    (void)zT_993;
    zT_994 = self;
    zT_996 = self->store;
    zT_997 = node_idx;
    zT_1001 = zF_B10B1BC1_astStoreNodeExtraCh(zT_996, zT_997, (unsigned int)(1));
    zT_995 = zT_1001;
    zT_1002 = zF_54F95822_semanticAnalyzerRes(zT_994, zT_995);
    (void)zT_1002;
    zT_1003 = self;
    zT_1005 = self->store;
    zT_1006 = node_idx;
    zT_1010 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1005, zT_1006, (unsigned int)(2));
    zT_1004 = zT_1010;
    zT_1011 = zF_54F95822_semanticAnalyzerRes(zT_1003, zT_1004);
    (void)zT_1011;
    zT_1012 = self;
    zT_1014 = self->store;
    zT_1015 = node_idx;
    zT_1019 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1014, zT_1015, (unsigned int)(3));
    zT_1013 = zT_1019;
    zT_1020 = zF_54F95822_semanticAnalyzerRes(zT_1012, zT_1013);
    (void)zT_1020;
    goto z_bb_263;
    z_bb_263:
    zT_1021 = self;
    zT_1022 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1021, zT_1022);
    zT_1023 = self->registry;
    zT_1029 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1023, (unsigned int)(1), (unsigned char)(0));
    result = zT_1029;
    goto z_bb_260;
    z_bb_264:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_267; else goto z_bb_268;
    z_bb_265:
    goto z_bb_260;
    z_bb_266:
    zT_1066 = node.child_0;
    zT_1067 = self->async_suspend_name_id;
    if ((unsigned char)(zT_1066 == zT_1067)) goto z_bb_269; else goto z_bb_271;
    z_bb_267:
    zT_1035 = self;
    zT_1037 = self->store;
    zT_1038 = node_idx;
    zT_1042 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1037, zT_1038, (unsigned int)(0));
    zT_1036 = zT_1042;
    zT_1043 = zF_54F95822_semanticAnalyzerRes(zT_1035, zT_1036);
    (void)zT_1043;
    zT_1044 = self;
    zT_1046 = self->store;
    zT_1047 = node_idx;
    zT_1051 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1046, zT_1047, (unsigned int)(1));
    zT_1045 = zT_1051;
    zT_1052 = zF_54F95822_semanticAnalyzerRes(zT_1044, zT_1045);
    (void)zT_1052;
    goto z_bb_268;
    z_bb_268:
    zT_1053 = self;
    zT_1054 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1053, zT_1054);
    zT_1055 = self->registry;
    zT_1058 = self->registry;
    zT_1064 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1058, (unsigned int)(1), (unsigned char)(0));
    zT_1056 = zT_1064;
    zT_1065 = zF_74A7234F_typeRegistryGetOrCr(zT_1055, zT_1056);
    result = zT_1065;
    goto z_bb_265;
    z_bb_269:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_272; else goto z_bb_273;
    z_bb_270:
    goto z_bb_265;
    z_bb_271:
    zT_1091 = node.child_0;
    zT_1092 = self->ptrcast_name_id;
    if ((unsigned char)(zT_1091 == zT_1092)) goto z_bb_274; else goto z_bb_275;
    z_bb_272:
    zT_1071 = self;
    zT_1073 = self->store;
    zT_1074 = node_idx;
    zT_1078 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1073, zT_1074, (unsigned int)(0));
    zT_1072 = zT_1078;
    zT_1079 = zF_54F95822_semanticAnalyzerRes(zT_1071, zT_1072);
    (void)zT_1079;
    goto z_bb_273;
    z_bb_273:
    zT_1080 = self;
    zT_1081 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1080, zT_1081);
    zT_1082 = self;
    zT_1083 = node_idx;
    zF_D4D0798B_semanticAnalyzerDia(zT_1082, zT_1083);
    zT_1084 = self->registry;
    zT_1090 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1084, (unsigned int)(1), (unsigned char)(0));
    result = zT_1090;
    goto z_bb_270;
    z_bb_274:
    zT_1094 = ec_n != (unsigned int)(2);
    goto z_bb_276;
    z_bb_275:
    zT_1094 = 0;
    goto z_bb_276;
    z_bb_276:
    if (zT_1094) goto z_bb_277; else goto z_bb_279;
    z_bb_277:
    zT_1098 = "@ptrCast requires exactly two arguments: @ptrCast(T, expr)";
    zT_1100 = 58;
    zT_1099.ptr = zT_1098;
    zT_1099.len = zT_1100;
    pc3049 = zT_1099;
    zT_1101 = self->diag;
    zT_1104 = self->source_file_id;
    zT_1105 = node.span_start;
    zT_1115 = node.span_start;
    zT_1116 = node.span_len;
    zT_1107 = pc3049;
    zT_1119 = zF_C82559AC_diagnosticCollector(zT_1101, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3049_PTRCAST_REQUIRES_TWO_ARGS)), zT_1104, zT_1105, (unsigned int)(zT_1115 + (unsigned int)((unsigned int)zT_1116)), zT_1107);
    (void)zT_1119;
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_280; else goto z_bb_281;
    z_bb_278:
    goto z_bb_270;
    z_bb_279:
    zT_1132 = self;
    zT_1133 = node.child_0;
    zT_1134 = cva;
    zT_1136 = zF_2ACB4E23_semanticAnalyzerBui(zT_1132, zT_1133, zT_1134);
    if (zT_1136) goto z_bb_282; else goto z_bb_284;
    z_bb_280:
    zT_1122 = self;
    zT_1124 = self->store;
    zT_1125 = node_idx;
    zT_1129 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1124, zT_1125, (unsigned int)(0));
    zT_1123 = zT_1129;
    zT_1130 = zF_54F95822_semanticAnalyzerRes(zT_1122, zT_1123);
    (void)zT_1130;
    goto z_bb_281;
    z_bb_281:
    zT_1131 = 18;
    result = zT_1131;
    goto z_bb_278;
    z_bb_282:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_285; else goto z_bb_287;
    z_bb_283:
    goto z_bb_278;
    z_bb_284:
    if ((unsigned char)(ec_n >= (unsigned int)(2))) goto z_bb_288; else goto z_bb_290;
    z_bb_285:
    zT_1139 = self;
    zT_1141 = self->store;
    zT_1142 = node_idx;
    zT_1146 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1141, zT_1142, (unsigned int)(0));
    zT_1140 = zT_1146;
    zT_1147 = zF_54F95822_semanticAnalyzerRes(zT_1139, zT_1140);
    (void)zT_1147;
    zT_1150 = self->store;
    zT_1149.store = zT_1150;
    zT_1151 = self->registry;
    zT_1149.typereg = zT_1151;
    zT_1152 = self->symbols;
    zT_1149.symbol_reg = zT_1152;
    zT_1153 = self->interner;
    zT_1149.interner = zT_1153;
    zT_1154 = self->module_id;
    zT_1149.module_id = zT_1154;
    zT_1155 = self->diag;
    zT_1156.has_value = 1;
    zT_1156.value = zT_1155;
    zT_1149.diag = zT_1156;
    zT_1157.has_value = 0;
    zT_1149.local_consts = zT_1157;
    zT_1158.has_value = 0;
    zT_1149.local_types = zT_1158;
    zT_1159 = self->source_file_id;
    zT_1149.source_file_id = zT_1159;
    cva_env = zT_1149;
    zT_1160 = &cva_env;
    zT_1164 = self->store;
    zT_1165 = node_idx;
    zT_1169 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1164, zT_1165, (unsigned int)(1));
    zT_1161 = zT_1169;
    zT_1171 = zF_F2107C15_resolveTypeExprFull(zT_1160, zT_1161, (unsigned int)(0));
    result = zT_1171;
    goto z_bb_286;
    z_bb_286:
    goto z_bb_283;
    z_bb_287:
    zT_1172 = 1;
    result = zT_1172;
    goto z_bb_286;
    z_bb_288:
    zT_1175 = self;
    zT_1176 = node.child_0;
    zT_1178 = zF_3757023F_semanticAnalyzerIsT(zT_1175, zT_1176);
    if (zT_1178) goto z_bb_291; else goto z_bb_293;
    z_bb_289:
    goto z_bb_283;
    z_bb_290:
    zT_1291 = node.child_0;
    zT_1292 = self->enumtoint_name_id;
    if ((unsigned char)(zT_1291 == zT_1292)) goto z_bb_314; else goto z_bb_315;
    z_bb_291:
    zT_1180 = self;
    zT_1182 = self->store;
    zT_1183 = node_idx;
    zT_1187 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1182, zT_1183, (unsigned int)(1));
    zT_1181 = zT_1187;
    zT_1188 = zF_54F95822_semanticAnalyzerRes(zT_1180, zT_1181);
    tv_src = zT_1188;
    zT_1191 = self->store;
    zT_1190.store = zT_1191;
    zT_1192 = self->registry;
    zT_1190.typereg = zT_1192;
    zT_1193 = self->symbols;
    zT_1190.symbol_reg = zT_1193;
    zT_1194 = self->interner;
    zT_1190.interner = zT_1194;
    zT_1195 = self->module_id;
    zT_1190.module_id = zT_1195;
    zT_1196 = self->diag;
    zT_1197.has_value = 1;
    zT_1197.value = zT_1196;
    zT_1190.diag = zT_1197;
    zT_1198.has_value = 0;
    zT_1190.local_consts = zT_1198;
    zT_1199.has_value = 0;
    zT_1190.local_types = zT_1199;
    zT_1200 = self->source_file_id;
    zT_1190.source_file_id = zT_1200;
    tre_env = zT_1190;
    zT_1201 = &tre_env;
    zT_1205 = self->store;
    zT_1206 = node_idx;
    zT_1210 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1205, zT_1206, (unsigned int)(0));
    zT_1202 = zT_1210;
    zT_1212 = zF_F2107C15_resolveTypeExprFull(zT_1201, zT_1202, (unsigned int)(0));
    result = zT_1212;
    zT_1213 = node.child_0;
    zT_1214 = self->ptrcast_name_id;
    if ((unsigned char)(zT_1213 == zT_1214)) goto z_bb_294; else goto z_bb_295;
    z_bb_292:
    goto z_bb_289;
    z_bb_293:
    zT_1282 = self;
    zT_1284 = self->store;
    zT_1285 = node_idx;
    zT_1289 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1284, zT_1285, (unsigned int)(0));
    zT_1283 = zT_1289;
    zT_1290 = zF_54F95822_semanticAnalyzerRes(zT_1282, zT_1283);
    result = zT_1290;
    goto z_bb_292;
    z_bb_294:
    zT_1216 = tv_src != (unsigned int)(18);
    goto z_bb_296;
    z_bb_295:
    zT_1216 = 0;
    goto z_bb_296;
    z_bb_296:
    if (zT_1216) goto z_bb_297; else goto z_bb_298;
    z_bb_297:
    zT_1219 = result != (unsigned int)(18);
    goto z_bb_299;
    z_bb_298:
    zT_1219 = 0;
    goto z_bb_299;
    z_bb_299:
    if (zT_1219) goto z_bb_300; else goto z_bb_301;
    z_bb_300:
    zT_1222 = self;
    zT_1223 = tv_src;
    zT_1224 = result;
    zT_1225 = zF_5F2042EA_semanticAnalyzerPtr(zT_1222, zT_1223, zT_1224);
    if (zT_1225) goto z_bb_302; else goto z_bb_303;
    z_bb_301:
    zT_1247 = node.child_0;
    zT_1248 = self->volatilecast_name_id;
    if ((unsigned char)(zT_1247 == zT_1248)) goto z_bb_304; else goto z_bb_305;
    z_bb_302:
    zT_1227 = "@ptrCast cannot discard the 'volatile' qualifier; use @volatileCast to remove it";
    zT_1229 = 80;
    zT_1228.ptr = zT_1227;
    zT_1228.len = zT_1229;
    pcq_msg = zT_1228;
    zT_1230 = self->diag;
    zT_1233 = self->source_file_id;
    zT_1234 = node.span_start;
    zT_1242 = node.span_start;
    zT_1243 = node.span_len;
    zT_1236 = pcq_msg;
    zT_1246 = zF_C82559AC_diagnosticCollector(zT_1230, (unsigned char)(0), (unsigned short)(3000), zT_1233, zT_1234, (unsigned int)(zT_1242 + (unsigned int)((unsigned int)zT_1243)), zT_1236);
    (void)zT_1246;
    goto z_bb_303;
    z_bb_303:
    goto z_bb_301;
    z_bb_304:
    zT_1250 = tv_src != (unsigned int)(18);
    goto z_bb_306;
    z_bb_305:
    zT_1250 = 0;
    goto z_bb_306;
    z_bb_306:
    if (zT_1250) goto z_bb_307; else goto z_bb_308;
    z_bb_307:
    zT_1253 = result != (unsigned int)(18);
    goto z_bb_309;
    z_bb_308:
    zT_1253 = 0;
    goto z_bb_309;
    z_bb_309:
    if (zT_1253) goto z_bb_310; else goto z_bb_311;
    z_bb_310:
    zT_1256 = self;
    zT_1257 = tv_src;
    zT_1258 = result;
    zT_1259 = zF_EC29CB82_semanticAnalyzerVol(zT_1256, zT_1257, zT_1258);
    if ((unsigned char)(!zT_1259)) goto z_bb_312; else goto z_bb_313;
    z_bb_311:
    goto z_bb_292;
    z_bb_312:
    zT_1262 = "@volatileCast requires a volatile pointer source and a destination with the same base type";
    zT_1264 = 90;
    zT_1263.ptr = zT_1262;
    zT_1263.len = zT_1264;
    vcc_msg = zT_1263;
    zT_1265 = self->diag;
    zT_1268 = self->source_file_id;
    zT_1269 = node.span_start;
    zT_1277 = node.span_start;
    zT_1278 = node.span_len;
    zT_1271 = vcc_msg;
    zT_1281 = zF_C82559AC_diagnosticCollector(zT_1265, (unsigned char)(0), (unsigned short)(3000), zT_1268, zT_1269, (unsigned int)(zT_1277 + (unsigned int)((unsigned int)zT_1278)), zT_1271);
    (void)zT_1281;
    goto z_bb_313;
    z_bb_313:
    goto z_bb_311;
    z_bb_314:
    zT_1294 = ec_n >= (unsigned int)(1);
    goto z_bb_316;
    z_bb_315:
    zT_1294 = 0;
    goto z_bb_316;
    z_bb_316:
    if (zT_1294) goto z_bb_317; else goto z_bb_319;
    z_bb_317:
    zT_1298 = self;
    zT_1300 = self->store;
    zT_1301 = node_idx;
    zT_1305 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1300, zT_1301, (unsigned int)(0));
    zT_1299 = zT_1305;
    zT_1306 = zF_54F95822_semanticAnalyzerRes(zT_1298, zT_1299);
    e2i_arg = zT_1306;
    e2i_res = e2i_arg;
    if ((unsigned char)(e2i_arg != (unsigned int)(18))) goto z_bb_320; else goto z_bb_321;
    z_bb_318:
    goto z_bb_289;
    z_bb_319:
    if ((unsigned char)(ec_n >= (unsigned int)(1))) goto z_bb_329; else goto z_bb_331;
    z_bb_320:
    zT_1311 = self->registry;
    zT_1312 = zT_1311->types_items;
    zT_1313 = (unsigned int)e2i_arg;
    zT_1314 = zT_1312[zT_1313];
    e2i_ty = zT_1314;
    zT_1315 = e2i_ty.kind;
    if ((unsigned char)(zT_1315 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_322; else goto z_bb_323;
    z_bb_321:
    result = e2i_res;
    goto z_bb_318;
    z_bb_322:
    zT_1320 = self->registry;
    zT_1321 = e2i_arg;
    zT_1323 = zF_014D7530_typeRegistryEnumBac(zT_1320, zT_1321);
    e2i_bt = zT_1323;
    if ((unsigned char)(e2i_bt != (unsigned int)(18))) goto z_bb_324; else goto z_bb_325;
    z_bb_323:
    goto z_bb_321;
    z_bb_324:
    zT_1328 = self->registry;
    zT_1329 = zT_1328->types_len;
    zT_1326 = (unsigned int)((unsigned int)e2i_bt) < zT_1329;
    goto z_bb_326;
    z_bb_325:
    zT_1326 = 0;
    goto z_bb_326;
    z_bb_326:
    if (zT_1326) goto z_bb_327; else goto z_bb_328;
    z_bb_327:
    e2i_res = e2i_bt;
    goto z_bb_328;
    z_bb_328:
    goto z_bb_323;
    z_bb_329:
    zT_1333 = self;
    zT_1335 = self->store;
    zT_1336 = node_idx;
    zT_1340 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1335, zT_1336, (unsigned int)(0));
    zT_1334 = zT_1340;
    zT_1341 = zF_54F95822_semanticAnalyzerRes(zT_1333, zT_1334);
    result = zT_1341;
    goto z_bb_330;
    z_bb_330:
    goto z_bb_318;
    z_bb_331:
    zT_1342 = 1;
    result = zT_1342;
    goto z_bb_330;
    z_bb_332:
    zT_1347 = self;
    zT_1348 = node.child_0;
    zT_1350 = zF_54F95822_semanticAnalyzerRes(zT_1347, zT_1348);
    (void)zT_1350;
    zT_1351 = 2;
    result = zT_1351;
    goto z_bb_333;
    z_bb_333:
    goto z_bb_123;
    z_bb_334:
    zT_1352 = node.kind;
    if ((unsigned char)(zT_1352 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_336; else goto z_bb_335;
    z_bb_335:
    zT_1357 = node.kind;
    zT_1356 = zT_1357 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_negate);
    goto z_bb_337;
    z_bb_336:
    zT_1356 = 1;
    goto z_bb_337;
    z_bb_337:
    if (zT_1356) goto z_bb_338; else goto z_bb_340;
    z_bb_338:
    zT_1361 = self;
    zT_1362 = node_idx;
    zT_1363 = zF_09421FDF_semanticAnalyzerRes(zT_1361, zT_1362);
    result = zT_1363;
    goto z_bb_339;
    z_bb_339:
    goto z_bb_333;
    z_bb_340:
    zT_1364 = node.kind;
    if ((unsigned char)(zT_1364 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_341; else goto z_bb_343;
    z_bb_341:
    zT_1368 = self;
    zT_1369 = node_idx;
    zT_1370 = zF_6B59E8AD_semanticAnalyzerRes(zT_1368, zT_1369);
    result = zT_1370;
    goto z_bb_342;
    z_bb_342:
    goto z_bb_339;
    z_bb_343:
    zT_1371 = node.kind;
    if ((unsigned char)(zT_1371 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_344; else goto z_bb_346;
    z_bb_344:
    zT_1375 = self;
    zT_1376 = node_idx;
    zT_1377 = zF_B78F27CD_semanticAnalyzerRes(zT_1375, zT_1376);
    result = zT_1377;
    goto z_bb_345;
    z_bb_345:
    goto z_bb_342;
    z_bb_346:
    zT_1378 = node.kind;
    if ((unsigned char)(zT_1378 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_347; else goto z_bb_349;
    z_bb_347:
    zT_1383 = 0;
    zT_1384 = (unsigned int)zT_1383;
    catch_es = zT_1384;
    zT_1385 = self;
    zT_1386 = node.child_0;
    zT_1388 = zF_54F95822_semanticAnalyzerRes(zT_1385, zT_1386);
    result = zT_1388;
    if ((unsigned char)(result != (unsigned int)(18))) goto z_bb_350; else goto z_bb_351;
    z_bb_348:
    goto z_bb_345;
    z_bb_349:
    zT_1474 = node.kind;
    if ((unsigned char)(zT_1474 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_367; else goto z_bb_369;
    z_bb_350:
    zT_1392 = self->registry;
    zT_1393 = zT_1392->types_items;
    zT_1394 = (unsigned int)result;
    zT_1395 = zT_1393[zT_1394];
    clt = zT_1395;
    zT_1396 = clt.kind;
    if ((unsigned char)(zT_1396 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_352; else goto z_bb_353;
    z_bb_351:
    zT_1420 = node.child_2;
    zT_1421 = 0;
    if ((unsigned char)(zT_1420 != (unsigned int)zT_1421)) goto z_bb_354; else goto z_bb_355;
    z_bb_352:
    zT_1400 = self->registry;
    zT_1401 = zT_1400->eu_items;
    zT_1402 = clt.payload_idx;
    zT_1403 = (unsigned int)zT_1402;
    zT_1404 = zT_1401[zT_1403];
    zT_1405 = zT_1404.error_set;
    catch_es = zT_1405;
    zT_1406 = self->registry;
    zT_1407 = zT_1406->eu_items;
    zT_1408 = clt.payload_idx;
    zT_1409 = (unsigned int)zT_1408;
    zT_1410 = zT_1407[zT_1409];
    zT_1411 = zT_1410.payload;
    result = zT_1411;
    zT_1412 = self->coercion_table;
    zT_1413 = node.child_0;
    zT_1415 = result;
    zF_D21AE60A_coercionTableAdd(zT_1412, zT_1413, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_1415);
    goto z_bb_353;
    z_bb_353:
    goto z_bb_351;
    z_bb_354:
    zT_1424 = self->store;
    zT_1425 = node.child_2;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_1424, zT_1425);
    zT_1429 = self->local_decl_count;
    zT_1430 = self->local_decl_cap;
    if ((unsigned char)(zT_1429 >= zT_1430)) goto z_bb_356; else goto z_bb_357;
    z_bb_355:
    zT_1449 = node.child_1;
    if ((unsigned char)(zT_1449 != (unsigned int)(0))) goto z_bb_361; else goto z_bb_362;
    z_bb_356:
    zT_1432 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_1432);
    goto z_bb_357;
    z_bb_357:
    zT_1433 = self->store;
    zT_1434 = node.child_2;
    zT_1437 = zF_8BA26B9E_astStoreNodePayload(zT_1433, zT_1434);
    zT_1438 = self->local_decl_names;
    zT_1439 = self->local_decl_count;
    zT_1438[zT_1439] = zT_1437;
    zT_1440 = 0;
    if ((unsigned char)(catch_es != (unsigned int)zT_1440)) goto z_bb_358; else goto z_bb_359;
    z_bb_358:
    zT_1442 = catch_es;
    goto z_bb_360;
    z_bb_359:
    zT_1442 = 6;
    goto z_bb_360;
    z_bb_360:
    zT_1444 = self->local_decl_types;
    zT_1445 = self->local_decl_count;
    zT_1444[zT_1445] = zT_1442;
    zT_1446 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_1446 + (unsigned int)(1));
    goto z_bb_355;
    z_bb_361:
    zT_1452 = 0;
    if ((unsigned char)(catch_es != (unsigned int)zT_1452)) goto z_bb_363; else goto z_bb_364;
    z_bb_362:
    goto z_bb_348;
    z_bb_363:
    zT_1455 = self->store;
    zT_1456 = node.child_1;
    zT_1459 = zF_FCDD1D35_astStoreNodeAt(zT_1455, zT_1456);
    child1 = zT_1459;
    zT_1460 = child1.kind;
    if ((unsigned char)(zT_1460 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_365; else goto z_bb_366;
    z_bb_364:
    zT_1471 = self;
    zT_1472 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1471, zT_1472);
    goto z_bb_362;
    z_bb_365:
    zT_1464 = self;
    zT_1465 = catch_es;
    zF_9665A229_pushExpectedType(zT_1464, zT_1465);
    zT_1466 = self;
    zT_1467 = node.child_1;
    zT_1469 = zF_54F95822_semanticAnalyzerRes(zT_1466, zT_1467);
    (void)zT_1469;
    zT_1470 = self;
    zF_BC478E78_popExpectedType(zT_1470);
    goto z_bb_366;
    z_bb_366:
    goto z_bb_364;
    z_bb_367:
    zT_1478 = self;
    zT_1479 = node_idx;
    zT_1480 = zF_B36961FA_semanticAnalyzerRes(zT_1478, zT_1479);
    result = zT_1480;
    goto z_bb_368;
    z_bb_368:
    goto z_bb_348;
    z_bb_369:
    zT_1481 = node.kind;
    if ((unsigned char)(zT_1481 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_371; else goto z_bb_370;
    z_bb_370:
    zT_1486 = node.kind;
    zT_1485 = zT_1486 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt);
    goto z_bb_372;
    z_bb_371:
    zT_1485 = 1;
    goto z_bb_372;
    z_bb_372:
    if (zT_1485) goto z_bb_373; else goto z_bb_375;
    z_bb_373:
    zT_1490 = 1;
    result = zT_1490;
    goto z_bb_374;
    z_bb_374:
    goto z_bb_368;
    z_bb_375:
    zT_1491 = node.kind;
    if ((unsigned char)(zT_1491 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_377; else goto z_bb_376;
    z_bb_376:
    zT_1496 = node.kind;
    zT_1495 = zT_1496 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt);
    goto z_bb_378;
    z_bb_377:
    zT_1495 = 1;
    goto z_bb_378;
    z_bb_378:
    if (zT_1495) goto z_bb_380; else goto z_bb_379;
    z_bb_379:
    zT_1501 = node.kind;
    zT_1500 = zT_1501 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_381;
    z_bb_380:
    zT_1500 = 1;
    goto z_bb_381;
    z_bb_381:
    if (zT_1500) goto z_bb_383; else goto z_bb_382;
    z_bb_382:
    zT_1506 = node.kind;
    zT_1505 = zT_1506 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt);
    goto z_bb_384;
    z_bb_383:
    zT_1505 = 1;
    goto z_bb_384;
    z_bb_384:
    if (zT_1505) goto z_bb_385; else goto z_bb_387;
    z_bb_385:
    zT_1510 = self;
    zT_1511 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_1510, zT_1511);
    zT_1512 = 1;
    result = zT_1512;
    goto z_bb_386;
    z_bb_386:
    goto z_bb_374;
    z_bb_387:
    zT_1513 = node.kind;
    if ((unsigned char)(zT_1513 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_388; else goto z_bb_390;
    z_bb_388:
    zT_1517 = self;
    zT_1518 = node_idx;
    zT_1519 = zF_8B8EE70D_semanticAnalyzerRes(zT_1517, zT_1518);
    result = zT_1519;
    goto z_bb_389;
    z_bb_389:
    goto z_bb_386;
    z_bb_390:
    zT_1520 = node.kind;
    if ((unsigned char)(zT_1520 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_391; else goto z_bb_393;
    z_bb_391:
    zT_1524 = self;
    zT_1525 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_1524, zT_1525);
    zT_1526 = node.child_2;
    if ((unsigned char)(zT_1526 != (unsigned int)(0))) goto z_bb_394; else goto z_bb_395;
    z_bb_392:
    goto z_bb_389;
    z_bb_393:
    zT_1539 = node.kind;
    if ((unsigned char)(zT_1539 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_398; else goto z_bb_400;
    z_bb_394:
    zT_1529 = self;
    zT_1530 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_1529, zT_1530);
    goto z_bb_395;
    z_bb_395:
    zT_1532 = node.child_1;
    if ((unsigned char)(zT_1532 != (unsigned int)(0))) goto z_bb_396; else goto z_bb_397;
    z_bb_396:
    zT_1535 = self;
    zT_1536 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1535, zT_1536);
    goto z_bb_397;
    z_bb_397:
    zT_1538 = 1;
    result = zT_1538;
    goto z_bb_392;
    z_bb_398:
    zT_1543 = self;
    zT_1544 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_1543, zT_1544);
    zT_1545 = node.child_1;
    zT_1546 = 0;
    if ((unsigned char)(zT_1545 != (unsigned int)zT_1546)) goto z_bb_401; else goto z_bb_402;
    z_bb_399:
    goto z_bb_392;
    z_bb_400:
    zT_1552 = node.kind;
    if ((unsigned char)(zT_1552 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_403; else goto z_bb_405;
    z_bb_401:
    zT_1548 = self;
    zT_1549 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1548, zT_1549);
    goto z_bb_402;
    z_bb_402:
    zT_1551 = 1;
    result = zT_1551;
    goto z_bb_399;
    z_bb_403:
    zT_1556 = self;
    zT_1557 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_1556, zT_1557);
    zT_1558 = node.child_1;
    zT_1559 = 0;
    if ((unsigned char)(zT_1558 != (unsigned int)zT_1559)) goto z_bb_406; else goto z_bb_407;
    z_bb_404:
    goto z_bb_399;
    z_bb_405:
    zT_1565 = node.kind;
    if ((unsigned char)(zT_1565 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_408; else goto z_bb_410;
    z_bb_406:
    zT_1561 = self;
    zT_1562 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1561, zT_1562);
    goto z_bb_407;
    z_bb_407:
    zT_1564 = 1;
    result = zT_1564;
    goto z_bb_404;
    z_bb_408:
    zT_1569 = self;
    zT_1570 = node_idx;
    zT_1571 = zF_2DB4F186_semanticAnalyzerRes(zT_1569, zT_1570);
    result = zT_1571;
    goto z_bb_409;
    z_bb_409:
    goto z_bb_404;
    z_bb_410:
    zT_1572 = node.kind;
    if ((unsigned char)(zT_1572 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_411; else goto z_bb_413;
    z_bb_411:
    zT_1576 = self;
    zT_1577 = node_idx;
    zT_1578 = zF_227D2404_semanticAnalyzerRes(zT_1576, zT_1577);
    result = zT_1578;
    goto z_bb_412;
    z_bb_412:
    goto z_bb_409;
    z_bb_413:
    zT_1579 = node.kind;
    if ((unsigned char)(zT_1579 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_414; else goto z_bb_416;
    z_bb_414:
    zT_1583 = self;
    zT_1584 = node_idx;
    zT_1585 = zF_AD7EF126_semanticAnalyzerRes(zT_1583, zT_1584);
    result = zT_1585;
    goto z_bb_415;
    z_bb_415:
    goto z_bb_412;
    z_bb_416:
    zT_1586 = node.kind;
    if ((unsigned char)(zT_1586 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_417; else goto z_bb_419;
    z_bb_417:
    zT_1591 = "AW:R";
    zT_1593 = 4;
    zT_1592.ptr = zT_1591;
    zT_1592.len = zT_1593;
    ai_dbg = zT_1592;
    zT_1594 = ai_dbg;
    zT_1595 = result;
    zF_C914CB83_markerWriteInt(zT_1594, zT_1595);
    zT_1596 = self;
    zT_1597 = node_idx;
    zT_1598 = zF_F3DAABE0_semanticAnalyzerRes(zT_1596, zT_1597);
    result = zT_1598;
    goto z_bb_418;
    z_bb_418:
    goto z_bb_415;
    z_bb_419:
    zT_1599 = node.kind;
    if ((unsigned char)(zT_1599 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_421; else goto z_bb_420;
    z_bb_420:
    zT_1604 = node.kind;
    zT_1603 = zT_1604 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_422;
    z_bb_421:
    zT_1603 = 1;
    goto z_bb_422;
    z_bb_422:
    if (zT_1603) goto z_bb_424; else goto z_bb_423;
    z_bb_423:
    zT_1609 = node.kind;
    zT_1608 = zT_1609 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_425;
    z_bb_424:
    zT_1608 = 1;
    goto z_bb_425;
    z_bb_425:
    if (zT_1608) goto z_bb_427; else goto z_bb_426;
    z_bb_426:
    zT_1614 = node.kind;
    zT_1613 = zT_1614 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_428;
    z_bb_427:
    zT_1613 = 1;
    goto z_bb_428;
    z_bb_428:
    if (zT_1613) goto z_bb_430; else goto z_bb_429;
    z_bb_429:
    zT_1619 = node.kind;
    zT_1618 = zT_1619 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_431;
    z_bb_430:
    zT_1618 = 1;
    goto z_bb_431;
    z_bb_431:
    if (zT_1618) goto z_bb_433; else goto z_bb_432;
    z_bb_432:
    zT_1624 = node.kind;
    zT_1623 = zT_1624 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_434;
    z_bb_433:
    zT_1623 = 1;
    goto z_bb_434;
    z_bb_434:
    if (zT_1623) goto z_bb_436; else goto z_bb_435;
    z_bb_435:
    zT_1629 = node.kind;
    zT_1628 = zT_1629 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_437;
    z_bb_436:
    zT_1628 = 1;
    goto z_bb_437;
    z_bb_437:
    if (zT_1628) goto z_bb_439; else goto z_bb_438;
    z_bb_438:
    zT_1634 = node.kind;
    zT_1633 = zT_1634 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl);
    goto z_bb_440;
    z_bb_439:
    zT_1633 = 1;
    goto z_bb_440;
    z_bb_440:
    if (zT_1633) goto z_bb_442; else goto z_bb_441;
    z_bb_441:
    zT_1639 = node.kind;
    zT_1638 = zT_1639 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_443;
    z_bb_442:
    zT_1638 = 1;
    goto z_bb_443;
    z_bb_443:
    if (zT_1638) goto z_bb_445; else goto z_bb_444;
    z_bb_444:
    zT_1644 = node.kind;
    zT_1643 = zT_1644 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_446;
    z_bb_445:
    zT_1643 = 1;
    goto z_bb_446;
    z_bb_446:
    if (zT_1643) goto z_bb_448; else goto z_bb_447;
    z_bb_447:
    zT_1649 = node.kind;
    zT_1648 = zT_1649 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_449;
    z_bb_448:
    zT_1648 = 1;
    goto z_bb_449;
    z_bb_449:
    if (zT_1648) goto z_bb_450; else goto z_bb_452;
    z_bb_450:
    zT_1653 = node.kind;
    if ((unsigned char)(zT_1653 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_453; else goto z_bb_454;
    z_bb_451:
    goto z_bb_418;
    z_bb_452:
    zT_1668 = node.kind;
    if ((unsigned char)(zT_1668 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_457; else goto z_bb_459;
    z_bb_453:
    zT_1657 = self;
    zT_1658 = node_idx;
    zT_1659 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_1657, zT_1658, zT_1659);
    goto z_bb_454;
    z_bb_454:
    zT_1661 = node.kind;
    if ((unsigned char)(zT_1661 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_455; else goto z_bb_456;
    z_bb_455:
    zT_1665 = self;
    zT_1666 = node_idx;
    zF_E3AF2BA9_semanticAnalyzerChe(zT_1665, zT_1666);
    goto z_bb_456;
    z_bb_456:
    zT_1667 = 20;
    result = zT_1667;
    goto z_bb_451;
    z_bb_457:
    zT_1672 = self;
    zT_1673 = node.child_0;
    zT_1675 = zF_54F95822_semanticAnalyzerRes(zT_1672, zT_1673);
    result = zT_1675;
    goto z_bb_458;
    z_bb_458:
    goto z_bb_451;
    z_bb_459:
    zT_1676 = node.kind;
    if ((unsigned char)(zT_1676 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_460; else goto z_bb_462;
    z_bb_460:
    zT_1680 = self;
    zT_1681 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_1680, zT_1681);
    zT_1682 = 3;
    result = zT_1682;
    goto z_bb_461;
    z_bb_461:
    goto z_bb_458;
    z_bb_462:
    zT_1683 = node.kind;
    if ((unsigned char)(zT_1683 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_463; else goto z_bb_465;
    z_bb_463:
    zT_1687 = self;
    zT_1688 = node.child_0;
    zT_1690 = zF_54F95822_semanticAnalyzerRes(zT_1687, zT_1688);
    result = zT_1690;
    goto z_bb_464;
    z_bb_464:
    goto z_bb_461;
    z_bb_465:
    zT_1691 = node.kind;
    if ((unsigned char)(zT_1691 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_466; else goto z_bb_468;
    z_bb_466:
    zT_1695 = 1;
    result = zT_1695;
    goto z_bb_467;
    z_bb_467:
    goto z_bb_464;
    z_bb_468:
    zT_1696 = node.kind;
    if ((unsigned char)(zT_1696 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_469; else goto z_bb_471;
    z_bb_469:
    zT_1701 = "EBLK:N";
    zT_1703 = 6;
    zT_1702.ptr = zT_1701;
    zT_1702.len = zT_1703;
    eblk_m = zT_1702;
    zT_1704 = eblk_m;
    zT_1705 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1704, zT_1705);
    zT_1707 = self->store;
    zT_1708 = node_idx;
    zT_1710 = zF_152E19CB_astStoreNodeExtraCh(zT_1707, zT_1708);
    children_n = zT_1710;
    zT_1712 = "EBLK:C";
    zT_1714 = 6;
    zT_1713.ptr = zT_1712;
    zT_1713.len = zT_1714;
    eblk_cm = zT_1713;
    zT_1715 = eblk_cm;
    zF_C914CB83_markerWriteInt(zT_1715, (unsigned int)((unsigned int)children_n));
    if ((unsigned char)(children_n > (unsigned int)(0))) goto z_bb_472; else goto z_bb_474;
    z_bb_470:
    goto z_bb_467;
    z_bb_471:
    zT_1770 = node.kind;
    if ((unsigned char)(zT_1770 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_480; else goto z_bb_479;
    z_bb_472:
    zT_1721 = 0;
    zT_1722 = (unsigned int)zT_1721;
    si = zT_1722;
    goto z_bb_475;
    z_bb_473:
    goto z_bb_470;
    z_bb_474:
    zT_1769 = 1;
    result = zT_1769;
    goto z_bb_473;
    z_bb_475:
    zT_1724 = 1;
    if ((unsigned char)(si < (unsigned int)((unsigned int)((unsigned int)children_n) - zT_1724))) goto z_bb_476; else goto z_bb_477;
    z_bb_476:
    zT_1728 = "EBLK:S";
    zT_1730 = 6;
    zT_1729.ptr = zT_1728;
    zT_1729.len = zT_1730;
    eblk_sm = zT_1729;
    zT_1731 = eblk_sm;
    zF_C914CB83_markerWriteInt(zT_1731, (unsigned int)((unsigned int)si));
    zT_1735 = "EBLK:D";
    zT_1737 = 6;
    zT_1736.ptr = zT_1735;
    zT_1736.len = zT_1737;
    eblk_cm2 = zT_1736;
    zT_1738 = eblk_cm2;
    zT_1740 = self->store;
    zT_1741 = node_idx;
    zT_1745 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1740, zT_1741, (unsigned int)((unsigned int)si));
    zT_1739 = zT_1745;
    zF_C914CB83_markerWriteInt(zT_1738, zT_1739);
    zT_1746 = self;
    zT_1748 = self->store;
    zT_1749 = node_idx;
    zT_1753 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1748, zT_1749, (unsigned int)((unsigned int)si));
    zT_1747 = zT_1753;
    zF_10A0DC35_semanticAnalyzerRes(zT_1746, zT_1747);
    goto z_bb_478;
    z_bb_477:
    zT_1758 = self->store;
    zT_1759 = node_idx;
    zT_1765 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1758, zT_1759, (unsigned int)((unsigned int)((unsigned int)children_n) - (unsigned int)(1)));
    last_child = zT_1765;
    zT_1766 = self;
    zT_1767 = last_child;
    zT_1768 = zF_54F95822_semanticAnalyzerRes(zT_1766, zT_1767);
    result = zT_1768;
    goto z_bb_473;
    z_bb_478:
    zT_1754 = 1;
    zT_1756 = si + (unsigned int)((unsigned int)zT_1754);
    si = zT_1756;
    goto z_bb_475;
    z_bb_479:
    zT_1775 = node.kind;
    zT_1774 = zT_1775 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_481;
    z_bb_480:
    zT_1774 = 1;
    goto z_bb_481;
    z_bb_481:
    if (zT_1774) goto z_bb_483; else goto z_bb_482;
    z_bb_482:
    zT_1780 = node.kind;
    zT_1779 = zT_1780 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_484;
    z_bb_483:
    zT_1779 = 1;
    goto z_bb_484;
    z_bb_484:
    if (zT_1779) goto z_bb_486; else goto z_bb_485;
    z_bb_485:
    zT_1785 = node.kind;
    zT_1784 = zT_1785 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_487;
    z_bb_486:
    zT_1784 = 1;
    goto z_bb_487;
    z_bb_487:
    if (zT_1784) goto z_bb_489; else goto z_bb_488;
    z_bb_488:
    zT_1790 = node.kind;
    zT_1789 = zT_1790 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_490;
    z_bb_489:
    zT_1789 = 1;
    goto z_bb_490;
    z_bb_490:
    if (zT_1789) goto z_bb_492; else goto z_bb_491;
    z_bb_491:
    zT_1795 = node.kind;
    zT_1794 = zT_1795 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add);
    goto z_bb_493;
    z_bb_492:
    zT_1794 = 1;
    goto z_bb_493;
    z_bb_493:
    if (zT_1794) goto z_bb_495; else goto z_bb_494;
    z_bb_494:
    zT_1800 = node.kind;
    zT_1799 = zT_1800 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub);
    goto z_bb_496;
    z_bb_495:
    zT_1799 = 1;
    goto z_bb_496;
    z_bb_496:
    if (zT_1799) goto z_bb_498; else goto z_bb_497;
    z_bb_497:
    zT_1805 = node.kind;
    zT_1804 = zT_1805 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul);
    goto z_bb_499;
    z_bb_498:
    zT_1804 = 1;
    goto z_bb_499;
    z_bb_499:
    if (zT_1804) goto z_bb_501; else goto z_bb_500;
    z_bb_500:
    zT_1810 = node.kind;
    zT_1809 = zT_1810 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add);
    goto z_bb_502;
    z_bb_501:
    zT_1809 = 1;
    goto z_bb_502;
    z_bb_502:
    if (zT_1809) goto z_bb_504; else goto z_bb_503;
    z_bb_503:
    zT_1815 = node.kind;
    zT_1814 = zT_1815 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub);
    goto z_bb_505;
    z_bb_504:
    zT_1814 = 1;
    goto z_bb_505;
    z_bb_505:
    if (zT_1814) goto z_bb_507; else goto z_bb_506;
    z_bb_506:
    zT_1820 = node.kind;
    zT_1819 = zT_1820 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul);
    goto z_bb_508;
    z_bb_507:
    zT_1819 = 1;
    goto z_bb_508;
    z_bb_508:
    if (zT_1819) goto z_bb_509; else goto z_bb_511;
    z_bb_509:
    zT_1824 = self;
    zT_1825 = node_idx;
    zT_1826 = node.kind;
    zT_1828 = zF_44006DDD_semanticAnalyzerRes(zT_1824, zT_1825, zT_1826);
    result = zT_1828;
    goto z_bb_510;
    z_bb_510:
    goto z_bb_470;
    z_bb_511:
    zT_1829 = node.kind;
    if ((unsigned char)(zT_1829 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_513; else goto z_bb_512;
    z_bb_512:
    zT_1834 = node.kind;
    zT_1833 = zT_1834 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_514;
    z_bb_513:
    zT_1833 = 1;
    goto z_bb_514;
    z_bb_514:
    if (zT_1833) goto z_bb_516; else goto z_bb_515;
    z_bb_515:
    zT_1839 = node.kind;
    zT_1838 = zT_1839 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_517;
    z_bb_516:
    zT_1838 = 1;
    goto z_bb_517;
    z_bb_517:
    if (zT_1838) goto z_bb_519; else goto z_bb_518;
    z_bb_518:
    zT_1844 = node.kind;
    zT_1843 = zT_1844 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_520;
    z_bb_519:
    zT_1843 = 1;
    goto z_bb_520;
    z_bb_520:
    if (zT_1843) goto z_bb_522; else goto z_bb_521;
    z_bb_521:
    zT_1849 = node.kind;
    zT_1848 = zT_1849 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_523;
    z_bb_522:
    zT_1848 = 1;
    goto z_bb_523;
    z_bb_523:
    if (zT_1848) goto z_bb_525; else goto z_bb_524;
    z_bb_524:
    zT_1854 = node.kind;
    zT_1853 = zT_1854 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl);
    goto z_bb_526;
    z_bb_525:
    zT_1853 = 1;
    goto z_bb_526;
    z_bb_526:
    if (zT_1853) goto z_bb_527; else goto z_bb_529;
    z_bb_527:
    zT_1858 = self;
    zT_1859 = node_idx;
    zT_1860 = zF_733BCA9C_semanticAnalyzerRes(zT_1858, zT_1859);
    result = zT_1860;
    goto z_bb_528;
    z_bb_528:
    goto z_bb_510;
    z_bb_529:
    zT_1861 = node.kind;
    if ((unsigned char)(zT_1861 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_531; else goto z_bb_530;
    z_bb_530:
    zT_1866 = node.kind;
    zT_1865 = zT_1866 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_532;
    z_bb_531:
    zT_1865 = 1;
    goto z_bb_532;
    z_bb_532:
    if (zT_1865) goto z_bb_533; else goto z_bb_535;
    z_bb_533:
    zT_1870 = self;
    zT_1871 = node_idx;
    zT_1872 = zF_6F2B8B98_semanticAnalyzerRes(zT_1870, zT_1871);
    result = zT_1872;
    goto z_bb_534;
    z_bb_534:
    goto z_bb_528;
    z_bb_535:
    zT_1873 = node.kind;
    if ((unsigned char)(zT_1873 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_537; else goto z_bb_536;
    z_bb_536:
    zT_1878 = node.kind;
    zT_1877 = zT_1878 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_538;
    z_bb_537:
    zT_1877 = 1;
    goto z_bb_538;
    z_bb_538:
    if (zT_1877) goto z_bb_540; else goto z_bb_539;
    z_bb_539:
    zT_1883 = node.kind;
    zT_1882 = zT_1883 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_541;
    z_bb_540:
    zT_1882 = 1;
    goto z_bb_541;
    z_bb_541:
    if (zT_1882) goto z_bb_543; else goto z_bb_542;
    z_bb_542:
    zT_1888 = node.kind;
    zT_1887 = zT_1888 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_544;
    z_bb_543:
    zT_1887 = 1;
    goto z_bb_544;
    z_bb_544:
    if (zT_1887) goto z_bb_546; else goto z_bb_545;
    z_bb_545:
    zT_1893 = node.kind;
    zT_1892 = zT_1893 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_547;
    z_bb_546:
    zT_1892 = 1;
    goto z_bb_547;
    z_bb_547:
    if (zT_1892) goto z_bb_549; else goto z_bb_548;
    z_bb_548:
    zT_1898 = node.kind;
    zT_1897 = zT_1898 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_550;
    z_bb_549:
    zT_1897 = 1;
    goto z_bb_550;
    z_bb_550:
    if (zT_1897) goto z_bb_551; else goto z_bb_553;
    z_bb_551:
    zT_1902 = self;
    zT_1903 = node_idx;
    zT_1904 = node.kind;
    zT_1906 = zF_EB621FF0_semanticAnalyzerRes(zT_1902, zT_1903, zT_1904);
    result = zT_1906;
    goto z_bb_552;
    z_bb_552:
    goto z_bb_534;
    z_bb_553:
    zT_1907 = node.kind;
    if ((unsigned char)(zT_1907 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_555; else goto z_bb_554;
    z_bb_554:
    zT_1912 = node.kind;
    zT_1911 = zT_1912 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_556;
    z_bb_555:
    zT_1911 = 1;
    goto z_bb_556;
    z_bb_556:
    if (zT_1911) goto z_bb_558; else goto z_bb_557;
    z_bb_557:
    zT_1917 = node.kind;
    zT_1916 = zT_1917 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_559;
    z_bb_558:
    zT_1916 = 1;
    goto z_bb_559;
    z_bb_559:
    if (zT_1916) goto z_bb_561; else goto z_bb_560;
    z_bb_560:
    zT_1922 = node.kind;
    zT_1921 = zT_1922 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_562;
    z_bb_561:
    zT_1921 = 1;
    goto z_bb_562;
    z_bb_562:
    if (zT_1921) goto z_bb_564; else goto z_bb_563;
    z_bb_563:
    zT_1927 = node.kind;
    zT_1926 = zT_1927 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_565;
    z_bb_564:
    zT_1926 = 1;
    goto z_bb_565;
    z_bb_565:
    if (zT_1926) goto z_bb_567; else goto z_bb_566;
    z_bb_566:
    zT_1932 = node.kind;
    zT_1931 = zT_1932 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_568;
    z_bb_567:
    zT_1931 = 1;
    goto z_bb_568;
    z_bb_568:
    if (zT_1931) goto z_bb_570; else goto z_bb_569;
    z_bb_569:
    zT_1937 = node.kind;
    zT_1936 = zT_1937 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_571;
    z_bb_570:
    zT_1936 = 1;
    goto z_bb_571;
    z_bb_571:
    if (zT_1936) goto z_bb_573; else goto z_bb_572;
    z_bb_572:
    zT_1942 = node.kind;
    zT_1941 = zT_1942 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_574;
    z_bb_573:
    zT_1941 = 1;
    goto z_bb_574;
    z_bb_574:
    if (zT_1941) goto z_bb_576; else goto z_bb_575;
    z_bb_575:
    zT_1947 = node.kind;
    zT_1946 = zT_1947 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_577;
    z_bb_576:
    zT_1946 = 1;
    goto z_bb_577;
    z_bb_577:
    if (zT_1946) goto z_bb_579; else goto z_bb_578;
    z_bb_578:
    zT_1952 = node.kind;
    zT_1951 = zT_1952 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_580;
    z_bb_579:
    zT_1951 = 1;
    goto z_bb_580;
    z_bb_580:
    if (zT_1951) goto z_bb_582; else goto z_bb_581;
    z_bb_581:
    zT_1957 = node.kind;
    zT_1956 = zT_1957 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_583;
    z_bb_582:
    zT_1956 = 1;
    goto z_bb_583;
    z_bb_583:
    if (zT_1956) goto z_bb_585; else goto z_bb_584;
    z_bb_584:
    zT_1962 = node.kind;
    zT_1961 = zT_1962 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_586;
    z_bb_585:
    zT_1961 = 1;
    goto z_bb_586;
    z_bb_586:
    if (zT_1961) goto z_bb_588; else goto z_bb_587;
    z_bb_587:
    zT_1967 = node.kind;
    zT_1966 = zT_1967 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_589;
    z_bb_588:
    zT_1966 = 1;
    goto z_bb_589;
    z_bb_589:
    if (zT_1966) goto z_bb_591; else goto z_bb_590;
    z_bb_590:
    zT_1972 = node.kind;
    zT_1971 = zT_1972 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_592;
    z_bb_591:
    zT_1971 = 1;
    goto z_bb_592;
    z_bb_592:
    if (zT_1971) goto z_bb_594; else goto z_bb_593;
    z_bb_593:
    zT_1977 = node.kind;
    zT_1976 = zT_1977 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_595;
    z_bb_594:
    zT_1976 = 1;
    goto z_bb_595;
    z_bb_595:
    if (zT_1976) goto z_bb_597; else goto z_bb_596;
    z_bb_596:
    zT_1982 = node.kind;
    zT_1981 = zT_1982 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_598;
    z_bb_597:
    zT_1981 = 1;
    goto z_bb_598;
    z_bb_598:
    if (zT_1981) goto z_bb_600; else goto z_bb_599;
    z_bb_599:
    zT_1987 = node.kind;
    zT_1986 = zT_1987 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_601;
    z_bb_600:
    zT_1986 = 1;
    goto z_bb_601;
    z_bb_601:
    if (zT_1986) goto z_bb_603; else goto z_bb_602;
    z_bb_602:
    zT_1992 = node.kind;
    zT_1991 = zT_1992 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_604;
    z_bb_603:
    zT_1991 = 1;
    goto z_bb_604;
    z_bb_604:
    if (zT_1991) goto z_bb_605; else goto z_bb_607;
    z_bb_605:
    zT_1996 = self;
    zT_1997 = node_idx;
    zT_1998 = zF_C0551BB8_semanticAnalyzerRes(zT_1996, zT_1997);
    result = zT_1998;
    goto z_bb_606;
    z_bb_606:
    goto z_bb_552;
    z_bb_607:
    zT_1999 = node.kind;
    if ((unsigned char)(zT_1999 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_609; else goto z_bb_608;
    z_bb_608:
    zT_2004 = node.kind;
    zT_2003 = zT_2004 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_610;
    z_bb_609:
    zT_2003 = 1;
    goto z_bb_610;
    z_bb_610:
    if (zT_2003) goto z_bb_611; else goto z_bb_613;
    z_bb_611:
    zT_2008 = self;
    zT_2009 = node.child_0;
    zT_2011 = zF_54F95822_semanticAnalyzerRes(zT_2008, zT_2009);
    (void)zT_2011;
    zT_2012 = node.child_1;
    zT_2013 = 0;
    if ((unsigned char)(zT_2012 != (unsigned int)zT_2013)) goto z_bb_614; else goto z_bb_615;
    goto z_bb_606;
    z_bb_613:
    zT_2026 = "ST:N";
    zT_2028 = 4;
    zT_2027.ptr = zT_2026;
    zT_2027.len = zT_2028;
    st_m = zT_2027;
    zT_2029 = st_m;
    zT_2030 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2029, zT_2030);
    zT_2032 = node.kind;
    zT_2033 = (unsigned int)zT_2032;
    st_kv = zT_2033;
    zT_2035 = "ST:K";
    zT_2037 = 4;
    zT_2036.ptr = zT_2035;
    zT_2036.len = zT_2037;
    st_km = zT_2036;
    zT_2038 = st_km;
    zT_2039 = st_kv;
    zF_C914CB83_markerWriteInt(zT_2038, zT_2039);
    zT_2041 = "internal error: unhandled node kind in type resolution";
    zT_2043 = 54;
    zT_2042.ptr = zT_2041;
    zT_2042.len = zT_2043;
    unr_msg = zT_2042;
    zT_2044 = self->diag;
    zT_2047 = self->source_file_id;
    zT_2048 = node_idx;
    zT_2049 = node_idx;
    zT_2050 = unr_msg;
    zT_2055 = zF_C82559AC_diagnosticCollector(zT_2044, (unsigned char)(0), (unsigned short)(3020), zT_2047, zT_2048, zT_2049, zT_2050);
    (void)zT_2055;
    return (unsigned int)(1);
    z_bb_614:
    zT_2015 = self;
    zT_2016 = node.child_1;
    zT_2018 = zF_54F95822_semanticAnalyzerRes(zT_2015, zT_2016);
    (void)zT_2018;
    goto z_bb_615;
    z_bb_615:
    zT_2019 = self->type_table;
    zT_2020 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_2019, zT_2020, (unsigned int)(10));
    return (unsigned int)(10);
}

/* semanticAnalyzerFnPtrConvMismatch */
unsigned char zF_148F8E19_semanticAnalyzerFnP(zT_38C12417_SemanticAnalyzer* self, unsigned int src, unsigned int tgt) {
    zT_338B7C76_TypeRegistry* zT_6;
    unsigned int zT_7;
    unsigned char zT_9;
    zT_338B7C76_TypeRegistry* zT_11;
    unsigned int zT_12;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_D155D06D_Type* zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_112BF819_PtrPayload* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_112BF819_PtrPayload zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_D155D06D_Type* zT_33;
    unsigned int zT_34;
    zT_D155D06D_Type zT_35;
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D155D06D_Type* zT_38;
    unsigned int zT_39;
    zT_D155D06D_Type zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_112BF819_PtrPayload* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_112BF819_PtrPayload zT_49;
    unsigned int zT_50;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_D155D06D_Type* zT_52;
    unsigned int zT_53;
    zT_D155D06D_Type zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    unsigned char zT_59;
    zT_33EF6BFB_TypeKind zT_60;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_0317B1D5_FnPayload* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_0317B1D5_FnPayload zT_70;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_0317B1D5_FnPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_0317B1D5_FnPayload zT_76;
    unsigned char zT_77;
    unsigned char zT_80;
    unsigned int s;
    unsigned int t;
    zT_D155D06D_Type st;
    zT_D155D06D_Type tt;
    zT_0317B1D5_FnPayload sfp;
    zT_0317B1D5_FnPayload tfp;
    if ((unsigned char)(src == tgt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src) >= zT_7)) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_11 = self->registry;
    zT_12 = zT_11->types_len;
    zT_9 = (unsigned int)((unsigned int)tgt) >= zT_12;
    goto z_bb_5;
    z_bb_4:
    zT_9 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_9) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    s = src;
    t = tgt;
    zT_18 = self->registry;
    zT_19 = zT_18->types_items;
    zT_20 = (unsigned int)s;
    zT_21 = zT_19[zT_20];
    st = zT_21;
    zT_22 = st.kind;
    if ((unsigned char)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = self->registry;
    zT_27 = zT_26->ptr_items;
    zT_28 = st.payload_idx;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zT_27[zT_29];
    zT_31 = zT_30.base;
    s = zT_31;
    zT_32 = self->registry;
    zT_33 = zT_32->types_items;
    zT_34 = (unsigned int)s;
    zT_35 = zT_33[zT_34];
    st = zT_35;
    goto z_bb_9;
    z_bb_9:
    zT_37 = self->registry;
    zT_38 = zT_37->types_items;
    zT_39 = (unsigned int)t;
    zT_40 = zT_38[zT_39];
    tt = zT_40;
    zT_41 = tt.kind;
    if ((unsigned char)(zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_45 = self->registry;
    zT_46 = zT_45->ptr_items;
    zT_47 = tt.payload_idx;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zT_46[zT_48];
    zT_50 = zT_49.base;
    t = zT_50;
    zT_51 = self->registry;
    zT_52 = zT_51->types_items;
    zT_53 = (unsigned int)t;
    zT_54 = zT_52[zT_53];
    tt = zT_54;
    goto z_bb_11;
    z_bb_11:
    zT_55 = st.kind;
    if ((unsigned char)(zT_55 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_60 = tt.kind;
    zT_59 = zT_60 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_14;
    z_bb_13:
    zT_59 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_59) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_66 = self->registry;
    zT_67 = zT_66->fn_items;
    zT_68 = st.payload_idx;
    zT_69 = (unsigned int)zT_68;
    zT_70 = zT_67[zT_69];
    sfp = zT_70;
    zT_72 = self->registry;
    zT_73 = zT_72->fn_items;
    zT_74 = tt.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    tfp = zT_76;
    zT_77 = sfp.flags_packed;
    zT_80 = tfp.flags_packed;
    return (unsigned char)((unsigned char)(zT_77 & (unsigned char)(2)) != (unsigned char)(zT_80 & (unsigned char)(2)));
}

/* isBShapeMismatch */
unsigned char zF_D728034A_isBShapeMismatch(zT_38C12417_SemanticAnalyzer* self, unsigned int src_ty, unsigned int tgt_ty, unsigned char full) {
    unsigned char zT_6;
    zT_338B7C76_TypeRegistry* zT_11;
    unsigned int zT_12;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    unsigned char zT_35;
    unsigned char zT_40;
    unsigned char zT_44;
    unsigned char zT_52;
    unsigned char zT_60;
    unsigned char zT_68;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    if ((unsigned char)(src_ty == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_6 = tgt_ty == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_6) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_11 = self->registry;
    zT_12 = zT_11->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)src_ty) >= zT_12)) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    zT_14 = (unsigned int)((unsigned int)tgt_ty) >= zT_17;
    goto z_bb_8;
    z_bb_7:
    zT_14 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_14) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = (unsigned int)src_ty;
    zT_24 = zT_22[zT_23];
    zT_25 = zT_24.kind;
    sk = zT_25;
    zT_27 = self->registry;
    zT_28 = zT_27->types_items;
    zT_29 = (unsigned int)tgt_ty;
    zT_30 = zT_28[zT_29];
    zT_31 = zT_30.kind;
    tk = zT_31;
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_35 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_13;
    z_bb_12:
    zT_35 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_35) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (unsigned char)(1);
    z_bb_15:
    if (full) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_40 = sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_18;
    z_bb_17:
    zT_40 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_40) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_44 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_21;
    z_bb_20:
    zT_44 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_44) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (unsigned char)(1);
    z_bb_23:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_52 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_26;
    z_bb_25:
    zT_52 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_52) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_60 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_31;
    z_bb_30:
    zT_60 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_60) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    return (unsigned char)(1);
    z_bb_33:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_69 = self->registry;
    zT_70 = tgt_ty;
    zT_72 = zF_3290E9C4_typeRegistryIsInteg(zT_69, zT_70);
    zT_68 = zT_72;
    goto z_bb_36;
    z_bb_35:
    zT_68 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_68) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    return (unsigned char)(0);
}

/* semanticAnalyzerResolveFnBody */
void zF_406A2501_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int fn_decl_node) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_E2DF2801_LocalConstScope* zT_9;
    zT_C8A278E4_LocalTypeScope* zT_11;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16 = {0};
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_22;
    zT_7ABA3706_anon_234425 zT_24;
    zT_243D6A41_FnProto* zT_25;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29 = 0;
    unsigned int zT_30;
    zT_243D6A41_FnProto zT_31;
    zT_8EED1867_ResolvedTypeTable* zT_33;
    unsigned int zT_34;
    zT_BAEE192E_Opt_10 zT_36 = {0};
    unsigned char zT_37;
    zT_338B7C76_TypeRegistry* zT_40;
    unsigned int zT_41;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_D155D06D_Type* zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_0317B1D5_FnPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_0317B1D5_FnPayload zT_57;
    unsigned char zT_58;
    unsigned char zT_63;
    unsigned char zT_64;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_F85C5DED_DiagnosticCollector* zT_73;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_91 = 0;
    unsigned int zT_92;
    unsigned short zT_95;
    unsigned int zT_99;
    unsigned short zT_103;
    zT_79FAE712_u64 zT_105;
    zT_6B0A7D14_AstStore* zT_107;
    zT_79FAE712_u64 zT_108;
    unsigned int zT_109 = 0;
    unsigned int zT_111;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    zT_6B0A7D14_AstStore* zT_117;
    zT_79FAE712_u64 zT_118;
    unsigned int zT_121 = 0;
    zT_22A7C88B_AstNode zT_122 = {0};
    unsigned int zT_123;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_38C12417_SemanticAnalyzer* zT_129;
    zT_6B0A7D14_AstStore* zT_130;
    unsigned int zT_131;
    zT_6B0A7D14_AstStore* zT_132;
    zT_79FAE712_u64 zT_133;
    unsigned int zT_136 = 0;
    unsigned int zT_137 = 0;
    unsigned int* zT_138;
    unsigned int zT_139;
    unsigned char* zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned int zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    unsigned int zT_145;
    zT_6B0A7D14_AstStore* zT_146;
    unsigned int zT_147;
    zT_6B0A7D14_AstStore* zT_148;
    zT_79FAE712_u64 zT_149;
    unsigned int zT_152 = 0;
    unsigned int zT_153 = 0;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    zT_8EED1867_ResolvedTypeTable* zT_162;
    unsigned int zT_163;
    zT_BAEE192E_Opt_10 zT_166 = {0};
    unsigned char zT_167;
    unsigned char* zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    unsigned int* zT_175;
    unsigned int zT_176;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    unsigned int* zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned int zT_189;
    zT_8EED1867_ResolvedTypeTable* zT_191;
    unsigned int zT_192;
    zT_BAEE192E_Opt_10 zT_195 = {0};
    unsigned char zT_196;
    unsigned int zT_198;
    zT_38C12417_SemanticAnalyzer* zT_199;
    unsigned int zT_200;
    zT_38C12417_SemanticAnalyzer* zT_203;
    unsigned int zT_204;
    unsigned char zT_206 = 0;
    unsigned char zT_207;
    zT_38C12417_SemanticAnalyzer* zT_208;
    unsigned int zT_209;
    unsigned char zT_211 = 0;
    unsigned int zT_214;
    unsigned int zT_216;
    unsigned int zT_218;
    unsigned char* zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned int zT_222;
    zT_F85C5DED_DiagnosticCollector* zT_223;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_234 = 0;
    zT_21D3708C_U32ToU32Map* zT_236;
    unsigned int zT_237;
    zT_21D3708C_U32ToU32Map* zT_239;
    unsigned int zT_240;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    unsigned char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    zT_8F083A69_Slice_zT_0B42B2F8_u fb;
    zT_22A7C88B_AstNode decl;
    zT_6B0A7D14_AstStore* store;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 vsc_tt;
    unsigned int vsc_tid;
    zT_D155D06D_Type vsc_ty;
    zT_0317B1D5_FnPayload vsc_fp;
    zT_8F083A69_Slice_zT_0B42B2F8_u vs_msg;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    zT_BAEE192E_Opt_10 fn_rt;
    zT_22A7C88B_AstNode pnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rta_m;
    zT_BAEE192E_Opt_10 rt;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u rth_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtm2;
    unsigned int frt;
    unsigned int mrsp;
    unsigned int mrep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr_msg;
    unsigned int evcap;
    unsigned int evcnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u vm;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcm;
    zT_3 = "FB";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fb = zT_4;
    zT_6 = fb;
    zF_48AC7B3A_markerWrite(zT_6);
    self->local_decl_count = (unsigned int)(0);
    zT_9 = &self->local_consts;
    zT_9->count = (unsigned int)(0);
    zT_11 = &self->local_types;
    zT_11->count = (unsigned int)(0);
    zT_13 = self->store;
    zT_14 = fn_decl_node;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    decl = zT_16;
    zT_17 = decl.kind;
    if ((unsigned char)(zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_22 = self->store;
    store = zT_22;
    zT_24 = store->fn_protos;
    zT_25 = zT_24.items;
    zT_26 = self->store;
    zT_27 = fn_decl_node;
    zT_29 = zF_8BA26B9E_astStoreNodePayload(zT_26, zT_27);
    zT_30 = (unsigned int)zT_29;
    zT_31 = zT_25[zT_30];
    proto = zT_31;
    zT_33 = self->type_table;
    zT_34 = fn_decl_node;
    zT_36 = zF_999DCF51_resolvedTypeTableGe(zT_33, zT_34);
    vsc_tt = zT_36;
    zT_37 = vsc_tt.has_value;
    if (zT_37) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    vsc_tid = vsc_tt.value;
    zT_40 = self->registry;
    zT_41 = zT_40->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)vsc_tid) < zT_41)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_92 = decl.child_0;
    if ((unsigned char)(zT_92 == (unsigned int)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_5:
    zT_44 = self->registry;
    zT_45 = zT_44->types_items;
    zT_46 = (unsigned int)vsc_tid;
    zT_47 = zT_45[zT_46];
    vsc_ty = zT_47;
    zT_48 = vsc_ty.kind;
    if ((unsigned char)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_53 = self->registry;
    zT_54 = zT_53->fn_items;
    zT_55 = vsc_ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    vsc_fp = zT_57;
    zT_58 = vsc_fp.flags_packed;
    if ((unsigned char)((unsigned char)(zT_58 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_64 = vsc_fp.flags_packed;
    zT_63 = (unsigned char)(zT_64 & (unsigned char)(2)) != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_63 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_63) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_70 = "variadic functions cannot use the stdcall calling convention";
    zT_72 = 60;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    vs_msg = zT_71;
    zT_73 = self->diag;
    zT_76 = self->source_file_id;
    zT_77 = decl.span_start;
    zT_87 = decl.span_start;
    zT_88 = decl.span_len;
    zT_79 = vs_msg;
    zT_91 = zF_C82559AC_diagnosticCollector(zT_73, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3012_VARARGS_INVALID)), zT_76, zT_77, (unsigned int)(zT_87 + (unsigned int)((unsigned int)zT_88)), zT_79);
    (void)zT_91;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    return;
    z_bb_15:
    zT_95 = proto.params_count;
    if ((unsigned char)(zT_95 > (unsigned short)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_99 = proto.params_start;
    zT_103 = proto.params_count;
    zT_105 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_99) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_103);
    p_payload = zT_105;
    zT_107 = store;
    zT_108 = p_payload;
    zT_109 = zF_03CE8CAB_astStoreGetExtraChi(zT_107, zT_108);
    pnodes_n = zT_109;
    zT_111 = 0;
    pi = zT_111;
    goto z_bb_18;
    z_bb_17:
    zT_191 = self->type_table;
    zT_192 = proto.return_type_node;
    zT_195 = zF_999DCF51_resolvedTypeTableGe(zT_191, zT_192);
    fn_rt = zT_195;
    zT_196 = fn_rt.has_value;
    if (zT_196) goto z_bb_29; else goto z_bb_30;
    z_bb_18:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_115 = store;
    zT_117 = store;
    zT_118 = p_payload;
    zT_121 = zF_E5B10421_astStoreGetExtraChi(zT_117, zT_118, (unsigned int)((unsigned int)pi));
    zT_116 = zT_121;
    zT_122 = zF_FCDD1D35_astStoreNodeAt(zT_115, zT_116);
    pnode = zT_122;
    zT_123 = pnode.child_0;
    if ((unsigned char)(zT_123 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_189 = pi + (unsigned int)(1);
    pi = zT_189;
    goto z_bb_18;
    z_bb_22:
    zT_126 = self->local_decl_count;
    zT_127 = self->local_decl_cap;
    if ((unsigned char)(zT_126 >= zT_127)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_129 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_129);
    goto z_bb_25;
    z_bb_25:
    zT_130 = store;
    zT_132 = store;
    zT_133 = p_payload;
    zT_136 = zF_E5B10421_astStoreGetExtraChi(zT_132, zT_133, (unsigned int)((unsigned int)pi));
    zT_131 = zT_136;
    zT_137 = zF_8BA26B9E_astStoreNodePayload(zT_130, zT_131);
    zT_138 = self->local_decl_names;
    zT_139 = self->local_decl_count;
    zT_138[zT_139] = zT_137;
    zT_141 = "RT:P";
    zT_143 = 4;
    zT_142.ptr = zT_141;
    zT_142.len = zT_143;
    rtp_m = zT_142;
    zT_144 = rtp_m;
    zT_146 = store;
    zT_148 = store;
    zT_149 = p_payload;
    zT_152 = zF_E5B10421_astStoreGetExtraChi(zT_148, zT_149, (unsigned int)((unsigned int)pi));
    zT_147 = zT_152;
    zT_153 = zF_8BA26B9E_astStoreNodePayload(zT_146, zT_147);
    zT_145 = zT_153;
    zF_C914CB83_markerWriteInt(zT_144, zT_145);
    zT_155 = "RT:A";
    zT_157 = 4;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    rta_m = zT_156;
    zT_158 = rta_m;
    zT_159 = pnode.child_0;
    zF_C914CB83_markerWriteInt(zT_158, zT_159);
    zT_162 = self->type_table;
    zT_163 = pnode.child_0;
    zT_166 = zF_999DCF51_resolvedTypeTableGe(zT_162, zT_163);
    rt = zT_166;
    zT_167 = rt.has_value;
    if (zT_167) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    t = rt.value;
    zT_170 = "RT:T";
    zT_172 = 4;
    zT_171.ptr = zT_170;
    zT_171.len = zT_172;
    rth_m = zT_171;
    zT_173 = rth_m;
    zT_174 = t;
    zF_C914CB83_markerWriteInt(zT_173, zT_174);
    zT_175 = self->local_decl_types;
    zT_176 = self->local_decl_count;
    zT_175[zT_176] = t;
    goto z_bb_27;
    z_bb_27:
    zT_185 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_185 + (unsigned int)(1));
    goto z_bb_23;
    z_bb_28:
    zT_178 = "RT:M\n";
    zT_180 = 5;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    rtm2 = zT_179;
    zT_181 = rtm2;
    zF_48AC7B3A_markerWrite(zT_181);
    zT_182 = 18;
    zT_183 = self->local_decl_types;
    zT_184 = self->local_decl_count;
    zT_183[zT_184] = zT_182;
    goto z_bb_27;
    z_bb_29:
    frt = fn_rt.value;
    self->current_fn_return = frt;
    goto z_bb_30;
    z_bb_30:
    zT_198 = proto.name_id;
    self->current_fn_name = zT_198;
    zT_199 = self;
    zT_200 = decl.child_0;
    zF_979B6CFF_semanticAnalyzerRes(zT_199, zT_200);
    self->current_fn_name = (unsigned int)(0);
    zT_203 = self;
    zT_204 = self->current_fn_return;
    zT_206 = zF_15CE7BE8_fnReturnRequiresVal(zT_203, zT_204);
    if (zT_206) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_208 = self;
    zT_209 = decl.child_0;
    zT_211 = zF_AA164297_astTerminates(zT_208, zT_209);
    zT_207 = !zT_211;
    goto z_bb_33;
    z_bb_32:
    zT_207 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_207) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_214 = decl.span_start;
    mrsp = zT_214;
    zT_216 = decl.span_len;
    zT_218 = mrsp + (unsigned int)((unsigned int)zT_216);
    mrep = zT_218;
    zT_220 = "missing return: not all control paths return a value";
    zT_222 = 52;
    zT_221.ptr = zT_220;
    zT_221.len = zT_222;
    mr_msg = zT_221;
    zT_223 = self->diag;
    zT_226 = self->source_file_id;
    zT_227 = mrsp;
    zT_228 = mrep;
    zT_229 = mr_msg;
    zT_234 = zF_C82559AC_diagnosticCollector(zT_223, (unsigned char)(0), (unsigned short)(3003), zT_226, zT_227, zT_228, zT_229);
    (void)zT_234;
    goto z_bb_35;
    z_bb_35:
    zT_236 = self->enum_value_table;
    zT_237 = zT_236->capacity;
    evcap = zT_237;
    zT_239 = self->enum_value_table;
    zT_240 = zT_239->count;
    evcnt = zT_240;
    zT_242 = "EVC:N";
    zT_244 = 5;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    vm = zT_243;
    zT_245 = vm;
    zF_C914CB83_markerWriteInt(zT_245, (unsigned int)((unsigned int)evcnt));
    zT_249 = "EVC:C";
    zT_251 = 5;
    zT_250.ptr = zT_249;
    zT_250.len = zT_251;
    vcm = zT_250;
    zT_252 = vcm;
    zF_C914CB83_markerWriteInt(zT_252, (unsigned int)((unsigned int)evcap));
    return;
}

/* fnReturnRequiresValue */
unsigned char zF_15CE7BE8_fnReturnRequiresVal(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    unsigned char zT_4;
    unsigned char zT_7;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_D155D06D_Type* zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_42C2D6BF_EUPayload* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_42C2D6BF_EUPayload zT_30;
    unsigned int zT_31;
    zT_33EF6BFB_TypeKind zT_35;
    zT_338B7C76_TypeRegistry* zT_40;
    zT_0B10E8E9_OptionalPayload* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_0B10E8E9_OptionalPayload zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type t;
    zT_42C2D6BF_EUPayload eu;
    zT_0B10E8E9_OptionalPayload op;
    if ((unsigned char)(ty == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = ty == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = ty == (unsigned int)(3);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_7) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_12 = self->registry;
    zT_13 = zT_12->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ty) >= zT_13)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_17 = self->registry;
    zT_18 = zT_17->types_items;
    zT_19 = (unsigned int)ty;
    zT_20 = zT_18[zT_19];
    t = zT_20;
    zT_21 = t.kind;
    if ((unsigned char)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_26 = self->registry;
    zT_27 = zT_26->eu_items;
    zT_28 = t.payload_idx;
    zT_29 = (unsigned int)zT_28;
    zT_30 = zT_27[zT_29];
    eu = zT_30;
    zT_31 = eu.payload;
    if ((unsigned char)(zT_31 == (unsigned int)(1))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_35 = t.kind;
    if ((unsigned char)(zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_40 = self->registry;
    zT_41 = zT_40->opt_items;
    zT_42 = t.payload_idx;
    zT_43 = (unsigned int)zT_42;
    zT_44 = zT_41[zT_43];
    op = zT_44;
    zT_45 = op.payload;
    if ((unsigned char)(zT_45 == (unsigned int)(1))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    goto z_bb_16;
}

/* astTerminates */
unsigned char zF_AA164297_astTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_8EED1867_ResolvedTypeTable* zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 zT_18 = {0};
    unsigned char zT_19;
    zT_8143F551_AstKind zT_24;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    unsigned int zT_34;
    zT_38C12417_SemanticAnalyzer* zT_37;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    unsigned int zT_44 = 0;
    unsigned char zT_45 = 0;
    int zT_47;
    unsigned int zT_49;
    zT_8143F551_AstKind zT_51;
    unsigned char zT_55;
    zT_8143F551_AstKind zT_56;
    unsigned int zT_60;
    zT_38C12417_SemanticAnalyzer* zT_64;
    unsigned int zT_65;
    unsigned char zT_67 = 0;
    unsigned char zT_68;
    zT_38C12417_SemanticAnalyzer* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    zT_8143F551_AstKind zT_73;
    unsigned int zT_77;
    zT_38C12417_SemanticAnalyzer* zT_81;
    unsigned int zT_83;
    zT_8143F551_AstKind zT_85;
    zT_38C12417_SemanticAnalyzer* zT_89;
    unsigned int zT_90;
    unsigned char zT_91 = 0;
    zT_8143F551_AstKind zT_92;
    zT_38C12417_SemanticAnalyzer* zT_96;
    unsigned int zT_97;
    unsigned char zT_98 = 0;
    zT_8143F551_AstKind zT_99;
    unsigned int zT_103;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_109;
    zT_8143F551_AstKind zT_111;
    unsigned char zT_115;
    zT_8143F551_AstKind zT_116;
    unsigned char zT_120;
    zT_8143F551_AstKind zT_121;
    unsigned char zT_125;
    zT_8143F551_AstKind zT_126;
    unsigned char zT_130;
    zT_8143F551_AstKind zT_131;
    unsigned char zT_135;
    zT_8143F551_AstKind zT_136;
    unsigned char zT_140;
    zT_8143F551_AstKind zT_141;
    unsigned char zT_145;
    zT_8143F551_AstKind zT_146;
    unsigned char zT_150;
    zT_8143F551_AstKind zT_151;
    unsigned char zT_155;
    zT_8143F551_AstKind zT_156;
    unsigned char zT_160;
    zT_8143F551_AstKind zT_161;
    unsigned char zT_165;
    zT_8143F551_AstKind zT_166;
    unsigned char zT_170;
    zT_8143F551_AstKind zT_171;
    unsigned char zT_175;
    zT_8143F551_AstKind zT_176;
    unsigned char zT_180;
    zT_8143F551_AstKind zT_181;
    unsigned char zT_185;
    zT_8143F551_AstKind zT_186;
    unsigned char zT_190;
    zT_8143F551_AstKind zT_191;
    unsigned char zT_195;
    zT_8143F551_AstKind zT_196;
    unsigned int zT_200;
    zT_38C12417_SemanticAnalyzer* zT_204;
    unsigned int zT_206;
    zT_22A7C88B_AstNode node;
    unsigned int t;
    unsigned int ch_n;
    unsigned int bi;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_15 = self->type_table;
    zT_16 = node_idx;
    zT_18 = zF_999DCF51_resolvedTypeTableGe(zT_15, zT_16);
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    t = zT_18.value;
    if ((unsigned char)(t == (unsigned int)(3))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_24 = node.kind;
    if ((unsigned char)(zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_29 = self->store;
    zT_30 = node_idx;
    zT_32 = zF_152E19CB_astStoreNodeExtraCh(zT_29, zT_30);
    ch_n = zT_32;
    zT_34 = 0;
    bi = zT_34;
    goto z_bb_11;
    z_bb_10:
    zT_51 = node.kind;
    if ((unsigned char)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)ch_n))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_37 = self;
    zT_39 = self->store;
    zT_40 = node_idx;
    zT_44 = zF_B10B1BC1_astStoreNodeExtraCh(zT_39, zT_40, (unsigned int)((unsigned int)bi));
    zT_38 = zT_44;
    zT_45 = zF_AA164297_astTerminates(zT_37, zT_38);
    if (zT_45) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_47 = 1;
    zT_49 = bi + (unsigned int)((unsigned int)zT_47);
    bi = zT_49;
    goto z_bb_11;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_56 = node.kind;
    zT_55 = zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr);
    goto z_bb_19;
    z_bb_18:
    zT_55 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_55) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_60 = node.child_2;
    if ((unsigned char)(zT_60 == (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_73 = node.kind;
    if ((unsigned char)(zT_73 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_27; else goto z_bb_28;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_64 = self;
    zT_65 = node.child_1;
    zT_67 = zF_AA164297_astTerminates(zT_64, zT_65);
    if (zT_67) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_69 = self;
    zT_70 = node.child_2;
    zT_72 = zF_AA164297_astTerminates(zT_69, zT_70);
    zT_68 = zT_72;
    goto z_bb_26;
    z_bb_25:
    zT_68 = 0;
    goto z_bb_26;
    z_bb_26:
    return zT_68;
    z_bb_27:
    zT_77 = node.child_0;
    if ((unsigned char)(zT_77 == (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_85 = node.kind;
    if ((unsigned char)(zT_85 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return (unsigned char)(0);
    z_bb_30:
    zT_81 = self;
    zT_83 = node.child_0;
    self = zT_81;
    node_idx = zT_83;
    goto z_bb_0;
    z_bb_31:
    zT_89 = self;
    zT_90 = node_idx;
    zT_91 = zF_A3A1FD27_astSwitchTerminates(zT_89, zT_90);
    return zT_91;
    z_bb_32:
    zT_92 = node.kind;
    if ((unsigned char)(zT_92 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_96 = self;
    zT_97 = node_idx;
    zT_98 = zF_FB2132D0_astWhileTerminates(zT_96, zT_97);
    return zT_98;
    z_bb_34:
    zT_99 = node.kind;
    if ((unsigned char)(zT_99 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_103 = node.child_1;
    if ((unsigned char)(zT_103 == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_111 = node.kind;
    if ((unsigned char)(zT_111 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_40; else goto z_bb_39;
    z_bb_37:
    return (unsigned char)(0);
    z_bb_38:
    zT_107 = self;
    zT_109 = node.child_1;
    self = zT_107;
    node_idx = zT_109;
    goto z_bb_0;
    z_bb_39:
    zT_116 = node.kind;
    zT_115 = zT_116 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_41;
    z_bb_40:
    zT_115 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_115) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_121 = node.kind;
    zT_120 = zT_121 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_44;
    z_bb_43:
    zT_120 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_120) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_126 = node.kind;
    zT_125 = zT_126 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_47;
    z_bb_46:
    zT_125 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_125) goto z_bb_49; else goto z_bb_48;
    z_bb_48:
    zT_131 = node.kind;
    zT_130 = zT_131 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_50;
    z_bb_49:
    zT_130 = 1;
    goto z_bb_50;
    z_bb_50:
    if (zT_130) goto z_bb_52; else goto z_bb_51;
    z_bb_51:
    zT_136 = node.kind;
    zT_135 = zT_136 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_53;
    z_bb_52:
    zT_135 = 1;
    goto z_bb_53;
    z_bb_53:
    if (zT_135) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_141 = node.kind;
    zT_140 = zT_141 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_56;
    z_bb_55:
    zT_140 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_140) goto z_bb_58; else goto z_bb_57;
    z_bb_57:
    zT_146 = node.kind;
    zT_145 = zT_146 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_59;
    z_bb_58:
    zT_145 = 1;
    goto z_bb_59;
    z_bb_59:
    if (zT_145) goto z_bb_61; else goto z_bb_60;
    z_bb_60:
    zT_151 = node.kind;
    zT_150 = zT_151 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_62;
    z_bb_61:
    zT_150 = 1;
    goto z_bb_62;
    z_bb_62:
    if (zT_150) goto z_bb_64; else goto z_bb_63;
    z_bb_63:
    zT_156 = node.kind;
    zT_155 = zT_156 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_65;
    z_bb_64:
    zT_155 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_155) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_161 = node.kind;
    zT_160 = zT_161 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_68;
    z_bb_67:
    zT_160 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_160) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_166 = node.kind;
    zT_165 = zT_166 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_71;
    z_bb_70:
    zT_165 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_165) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_171 = node.kind;
    zT_170 = zT_171 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_74;
    z_bb_73:
    zT_170 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_170) goto z_bb_76; else goto z_bb_75;
    z_bb_75:
    zT_176 = node.kind;
    zT_175 = zT_176 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_77;
    z_bb_76:
    zT_175 = 1;
    goto z_bb_77;
    z_bb_77:
    if (zT_175) goto z_bb_79; else goto z_bb_78;
    z_bb_78:
    zT_181 = node.kind;
    zT_180 = zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_80;
    z_bb_79:
    zT_180 = 1;
    goto z_bb_80;
    z_bb_80:
    if (zT_180) goto z_bb_82; else goto z_bb_81;
    z_bb_81:
    zT_186 = node.kind;
    zT_185 = zT_186 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_83;
    z_bb_82:
    zT_185 = 1;
    goto z_bb_83;
    z_bb_83:
    if (zT_185) goto z_bb_85; else goto z_bb_84;
    z_bb_84:
    zT_191 = node.kind;
    zT_190 = zT_191 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_86;
    z_bb_85:
    zT_190 = 1;
    goto z_bb_86;
    z_bb_86:
    if (zT_190) goto z_bb_88; else goto z_bb_87;
    z_bb_87:
    zT_196 = node.kind;
    zT_195 = zT_196 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_89;
    z_bb_88:
    zT_195 = 1;
    goto z_bb_89;
    z_bb_89:
    if (zT_195) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_200 = node.child_1;
    if ((unsigned char)(zT_200 == (unsigned int)(0))) goto z_bb_92; else goto z_bb_93;
    z_bb_91:
    return (unsigned char)(0);
    z_bb_92:
    return (unsigned char)(0);
    z_bb_93:
    zT_204 = self;
    zT_206 = node.child_1;
    self = zT_204;
    node_idx = zT_206;
    goto z_bb_0;
}

/* astSwitchTerminates */
unsigned char zF_A3A1FD27_astSwitchTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    unsigned char zT_16;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_30 = 0;
    zT_22A7C88B_AstNode zT_31 = {0};
    unsigned char zT_32;
    unsigned char zT_37;
    zT_38C12417_SemanticAnalyzer* zT_38;
    unsigned int zT_39;
    unsigned char zT_41 = 0;
    int zT_44;
    unsigned int zT_46;
    zT_38C12417_SemanticAnalyzer* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned char zT_52 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int prongs_n;
    unsigned char has_else;
    unsigned int pi;
    zT_22A7C88B_AstNode pr;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_152E19CB_astStoreNodeExtraCh(zT_8, zT_9);
    prongs_n = zT_11;
    if ((unsigned char)(prongs_n == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_16 = 0;
    has_else = zT_16;
    zT_18 = 0;
    pi = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)prongs_n))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = self->store;
    zT_25 = self->store;
    zT_26 = node_idx;
    zT_30 = zF_B10B1BC1_astStoreNodeExtraCh(zT_25, zT_26, (unsigned int)((unsigned int)pi));
    zT_23 = zT_30;
    zT_31 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    pr = zT_31;
    zT_32 = pr.flags;
    if ((unsigned char)((unsigned char)(zT_32 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    if (has_else) goto z_bb_11; else goto z_bb_12;
    z_bb_6:
    zT_44 = 1;
    zT_46 = pi + (unsigned int)((unsigned int)zT_44);
    pi = zT_46;
    goto z_bb_3;
    z_bb_7:
    zT_37 = 1;
    has_else = zT_37;
    goto z_bb_8;
    z_bb_8:
    zT_38 = self;
    zT_39 = pr.child_0;
    zT_41 = zF_AA164297_astTerminates(zT_38, zT_39);
    if ((unsigned char)(!zT_41)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    goto z_bb_6;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_48 = self;
    zT_49 = node.child_0;
    zT_50 = node_idx;
    zT_52 = zF_DCF9800F_astSwitchExhaustive(zT_48, zT_49, zT_50);
    return zT_52;
}

/* astSwitchExhaustive */
unsigned char zF_DCF9800F_astSwitchExhaustive(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_idx, unsigned int switch_node_idx) {
    zT_8EED1867_ResolvedTypeTable* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    unsigned char zT_14;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    unsigned int zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_457ECFEE_EnumPayload* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_457ECFEE_EnumPayload zT_35;
    unsigned short zT_36;
    unsigned int zT_37;
    zT_33EF6BFB_TypeKind zT_38;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_54FF90FA_TaggedUnionPayload* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_54FF90FA_TaggedUnionPayload zT_46;
    unsigned short zT_47;
    unsigned int zT_48;
    zT_33EF6BFB_TypeKind zT_49;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_0B73C507_ErrorSetPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_0B73C507_ErrorSetPayload zT_57;
    unsigned short zT_58;
    unsigned int zT_59;
    zT_33EF6BFB_TypeKind zT_60;
    unsigned int zT_64;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    unsigned int zT_72 = 0;
    unsigned int zT_74;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_86 = 0;
    unsigned int zT_87 = 0;
    unsigned int zT_89;
    int zT_90;
    unsigned int zT_92;
    unsigned int ct;
    zT_D155D06D_Type ty;
    unsigned int member_count;
    unsigned int covered;
    unsigned int prongs_n;
    unsigned int pi;
    unsigned int items_n;
    zT_4 = self->type_table;
    zT_5 = cond_idx;
    zT_7 = zF_999DCF51_resolvedTypeTableGe(zT_4, zT_5);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = zT_7.value;
    goto z_bb_3;
    z_bb_3:
    ct = zT_9;
    if ((unsigned char)(ct == (unsigned int)(0))) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    zT_14 = (unsigned int)((unsigned int)ct) >= zT_17;
    goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_14) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = (unsigned int)ct;
    zT_24 = zT_22[zT_23];
    ty = zT_24;
    zT_26 = 0;
    member_count = zT_26;
    zT_27 = ty.kind;
    if ((unsigned char)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_31 = self->registry;
    zT_32 = zT_31->en_items;
    zT_33 = ty.payload_idx;
    zT_34 = (unsigned int)zT_33;
    zT_35 = zT_32[zT_34];
    zT_36 = zT_35.members_count;
    zT_37 = (unsigned int)zT_36;
    member_count = zT_37;
    goto z_bb_10;
    z_bb_10:
    zT_67 = 0;
    covered = zT_67;
    zT_69 = self->store;
    zT_70 = switch_node_idx;
    zT_72 = zF_152E19CB_astStoreNodeExtraCh(zT_69, zT_70);
    prongs_n = zT_72;
    zT_74 = 0;
    pi = zT_74;
    goto z_bb_21;
    z_bb_11:
    zT_38 = ty.kind;
    if ((unsigned char)(zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_42 = self->registry;
    zT_43 = zT_42->tu_items;
    zT_44 = ty.payload_idx;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zT_43[zT_45];
    zT_47 = zT_46.fields_count;
    zT_48 = (unsigned int)zT_47;
    member_count = zT_48;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_49 = ty.kind;
    if ((unsigned char)(zT_49 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_53 = self->registry;
    zT_54 = zT_53->es_items;
    zT_55 = ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    zT_58 = zT_57.tags_count;
    zT_59 = (unsigned int)zT_58;
    member_count = zT_59;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_60 = ty.kind;
    if ((unsigned char)(zT_60 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_64 = 2;
    member_count = zT_64;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)prongs_n))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_78 = self->store;
    zT_81 = self->store;
    zT_82 = switch_node_idx;
    zT_86 = zF_B10B1BC1_astStoreNodeExtraCh(zT_81, zT_82, (unsigned int)((unsigned int)pi));
    zT_79 = zT_86;
    zT_87 = zF_152E19CB_astStoreNodeExtraCh(zT_78, zT_79);
    items_n = zT_87;
    zT_89 = covered + (unsigned int)((unsigned int)items_n);
    covered = zT_89;
    goto z_bb_24;
    z_bb_23:
    return (unsigned char)(covered >= member_count);
    z_bb_24:
    zT_90 = 1;
    zT_92 = pi + (unsigned int)((unsigned int)zT_90);
    pi = zT_92;
    goto z_bb_21;
}

/* astWhileTerminates */
unsigned char zF_FB2132D0_astWhileTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    unsigned char zT_10;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_20 = {0};
    zT_8143F551_AstKind zT_21;
    unsigned char zT_26;
    zT_38C12417_SemanticAnalyzer* zT_32;
    unsigned int zT_33;
    unsigned char zT_35 = 0;
    zT_38C12417_SemanticAnalyzer* zT_37;
    unsigned int zT_38;
    unsigned char zT_40 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode cond;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((unsigned char)(zT_7 == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = node.child_1;
    zT_10 = zT_11 == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_10 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_16 = self->store;
    zT_17 = node.child_0;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    cond = zT_20;
    zT_21 = cond.kind;
    if ((unsigned char)(zT_21 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_26 = cond.flags;
    if ((unsigned char)((unsigned char)(zT_26 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_32 = self;
    zT_33 = node.child_1;
    zT_35 = zF_B5177CCC_astSubtreeHasBreak(zT_32, zT_33);
    if (zT_35) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(0);
    z_bb_11:
    zT_37 = self;
    zT_38 = node.child_1;
    zT_40 = zF_AA164297_astTerminates(zT_37, zT_38);
    return zT_40;
}

/* astSubtreeHasBreak */
unsigned char zF_B5177CCC_astSubtreeHasBreak(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned int zT_15;
    unsigned char zT_18;
    zT_8143F551_AstKind zT_19;
    unsigned char zT_23 = 0;
    unsigned char zT_24;
    zT_38C12417_SemanticAnalyzer* zT_25;
    unsigned int zT_26;
    unsigned char zT_28 = 0;
    unsigned int zT_30;
    unsigned char zT_33;
    zT_8143F551_AstKind zT_34;
    unsigned char zT_38 = 0;
    unsigned char zT_39;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned char zT_43 = 0;
    unsigned int zT_45;
    unsigned char zT_48;
    zT_8143F551_AstKind zT_49;
    unsigned char zT_53 = 0;
    unsigned char zT_54;
    zT_38C12417_SemanticAnalyzer* zT_55;
    unsigned int zT_56;
    unsigned char zT_58 = 0;
    zT_8143F551_AstKind zT_60;
    unsigned char zT_62 = 0;
    unsigned char zT_63;
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    unsigned int zT_67 = 0;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_74 = 0;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_38C12417_SemanticAnalyzer* zT_79;
    unsigned int zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_86 = 0;
    unsigned char zT_87 = 0;
    int zT_89;
    unsigned int zT_91;
    zT_22A7C88B_AstNode node;
    unsigned int ec_n;
    unsigned int ei;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_15 = node.child_0;
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = node.kind;
    zT_23 = zF_C395F6FD_nodeChildIsNode(zT_19, (unsigned char)(0));
    zT_18 = zT_23;
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = self;
    zT_26 = node.child_0;
    zT_28 = zF_B5177CCC_astSubtreeHasBreak(zT_25, zT_26);
    zT_24 = zT_28;
    goto z_bb_10;
    z_bb_9:
    zT_24 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_24) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_30 = node.child_1;
    if ((unsigned char)(zT_30 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_34 = node.kind;
    zT_38 = zF_C395F6FD_nodeChildIsNode(zT_34, (unsigned char)(1));
    zT_33 = zT_38;
    goto z_bb_15;
    z_bb_14:
    zT_33 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_33) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_40 = self;
    zT_41 = node.child_1;
    zT_43 = zF_B5177CCC_astSubtreeHasBreak(zT_40, zT_41);
    zT_39 = zT_43;
    goto z_bb_18;
    z_bb_17:
    zT_39 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_39) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    zT_45 = node.child_2;
    if ((unsigned char)(zT_45 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_49 = node.kind;
    zT_53 = zF_C395F6FD_nodeChildIsNode(zT_49, (unsigned char)(2));
    zT_48 = zT_53;
    goto z_bb_23;
    z_bb_22:
    zT_48 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_48) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_55 = self;
    zT_56 = node.child_2;
    zT_58 = zF_B5177CCC_astSubtreeHasBreak(zT_55, zT_56);
    zT_54 = zT_58;
    goto z_bb_26;
    z_bb_25:
    zT_54 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_54) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    zT_60 = node.kind;
    zT_62 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_60);
    if (zT_62) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_64 = self->store;
    zT_65 = node_idx;
    zT_67 = zF_8BA26B9E_astStoreNodePayload(zT_64, zT_65);
    zT_63 = zT_67 != (unsigned int)(0);
    goto z_bb_31;
    z_bb_30:
    zT_63 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_63) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_71 = self->store;
    zT_72 = node_idx;
    zT_74 = zF_152E19CB_astStoreNodeExtraCh(zT_71, zT_72);
    zT_75 = (unsigned int)zT_74;
    ec_n = zT_75;
    zT_77 = 0;
    ei = zT_77;
    goto z_bb_34;
    z_bb_33:
    return (unsigned char)(0);
    z_bb_34:
    if ((unsigned char)(ei < ec_n)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_79 = self;
    zT_81 = self->store;
    zT_82 = node_idx;
    zT_86 = zF_B10B1BC1_astStoreNodeExtraCh(zT_81, zT_82, (unsigned int)((unsigned int)ei));
    zT_80 = zT_86;
    zT_87 = zF_B5177CCC_astSubtreeHasBreak(zT_79, zT_80);
    if (zT_87) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_89 = 1;
    zT_91 = ei + (unsigned int)((unsigned int)zT_89);
    ei = zT_91;
    goto z_bb_34;
    z_bb_38:
    return (unsigned char)(1);
    z_bb_39:
    goto z_bb_37;
}

/* semanticAnalyzerStmtWorkPush */
void zF_7AB741D8_semanticAnalyzerStm(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_ACA03DB3_EU_632 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->stmt_work_len;
    zT_3 = self->stmt_work_cap;
    if ((unsigned char)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->stmt_work_cap;
    if ((unsigned char)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->stmt_work_items;
    zT_38 = self->stmt_work_len;
    zT_37[zT_38] = node_idx;
    zT_39 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->stmt_work_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->stmt_work_len;
    if ((unsigned char)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->stmt_work_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->stmt_work_items = ndst;
    self->stmt_work_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* pushExpectedType */
void zF_9665A229_pushExpectedType(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_ACA03DB3_EU_632 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->expected_type_stack_len;
    zT_3 = self->expected_type_stack_cap;
    if ((unsigned char)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->expected_type_stack_cap;
    if ((unsigned char)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->expected_type_stack_items;
    zT_38 = self->expected_type_stack_len;
    zT_37[zT_38] = ty;
    zT_39 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->expected_type_stack_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->expected_type_stack_len;
    if ((unsigned char)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->expected_type_stack_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->expected_type_stack_items = ndst;
    self->expected_type_stack_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* popExpectedType */
void zF_BC478E78_popExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int zT_4;
    zT_1 = self->expected_type_stack_len;
    if ((unsigned char)(zT_1 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_4 - (unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    return;
}

/* topExpectedType */
unsigned int zF_4DE7C2BC_topExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_1 = self->expected_type_stack_len;
    if ((unsigned char)(zT_1 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_5 = self->expected_type_stack_items;
    zT_6 = self->expected_type_stack_len;
    zT_8 = zT_6 - (unsigned int)(1);
    zT_9 = zT_5[zT_8];
    return zT_9;
}

/* semanticAnalyzerResolveIfHeader */
void zF_0324C9A3_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    unsigned int zT_41 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_939EE900_Arr_unsigned_int_1 zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    int zT_58;
    zT_22A7C88B_AstNode zT_60 = {0};
    zT_8143F551_AstKind zT_61;
    unsigned int zT_62;
    int zT_63;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    int zT_76;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    int zT_84;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_939EE900_Arr_unsigned_int_1 zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    zT_22A7C88B_AstNode zT_105 = {0};
    zT_8143F551_AstKind zT_106;
    unsigned int zT_107;
    int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    int zT_115;
    zT_22A7C88B_AstNode node;
    unsigned int icond_t;
    unsigned int icap_idx;
    zT_22A7C88B_AstNode icap_node;
    zT_939EE900_Arr_unsigned_int_1 ifs_b;
    zT_939EE900_Arr_unsigned_int_1 ifs_k;
    zT_22A7C88B_AstNode ifs_cn;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_cm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_c2m;
    zT_939EE900_Arr_unsigned_int_1 ifs_k2;
    zT_22A7C88B_AstNode ifs_cn2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_k2m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    icond_t = zT_11;
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    icap_idx = zT_22;
    zT_24 = self->store;
    zT_25 = icap_idx;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    icap_node = zT_27;
    zT_28 = icap_node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_44 = node.child_1;
    zT_45 = 0;
    zT_43[zT_45] = zT_44;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_b[_i] = zT_43[_i];
        _i++;
    }
}
    zT_48 = 0;
    zT_49 = 0;
    zT_47[zT_49] = zT_48;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k[_i] = zT_47[_i];
        _i++;
    }
}
    zT_50 = 0;
    zT_51 = ifs_b[zT_50];
    if ((unsigned char)(zT_51 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_32 = self;
    zT_35 = self->store;
    zT_36 = icap_idx;
    zT_38 = zF_8BA26B9E_astStoreNodePayload(zT_35, zT_36);
    zT_33 = zT_38;
    zT_39 = self;
    zT_40 = icond_t;
    zT_41 = zF_3E251D67_semanticAnalyzerCap(zT_39, zT_40);
    zT_34 = zT_41;
    zF_7BD72017_registerLocalDecl(zT_32, zT_33, zT_34);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_55 = self->store;
    zT_58 = 0;
    zT_56 = ifs_b[zT_58];
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_55, zT_56);
    ifs_cn = zT_60;
    zT_61 = ifs_cn.kind;
    zT_62 = (unsigned int)zT_61;
    zT_63 = 0;
    ifs_k[zT_63] = zT_62;
    goto z_bb_6;
    z_bb_6:
    zT_65 = "IFST:N";
    zT_67 = 6;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    ifst_nm = zT_66;
    zT_68 = ifst_nm;
    zT_69 = node_idx;
    zF_C914CB83_markerWriteInt(zT_68, zT_69);
    zT_71 = "IFST:C";
    zT_73 = 6;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    ifst_cm = zT_72;
    zT_74 = ifst_cm;
    zT_76 = 0;
    zT_75 = ifs_b[zT_76];
    zF_C914CB83_markerWriteInt(zT_74, zT_75);
    zT_79 = "IFST:K";
    zT_81 = 6;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    ifst_km = zT_80;
    zT_82 = ifst_km;
    zT_84 = 0;
    zT_83 = ifs_k[zT_84];
    zF_C914CB83_markerWriteInt(zT_82, zT_83);
    zT_87 = "IFST:2";
    zT_89 = 6;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    ifst_c2m = zT_88;
    zT_90 = ifst_c2m;
    zT_91 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_90, zT_91);
    zT_95 = 0;
    zT_96 = 0;
    zT_94[zT_96] = zT_95;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k2[_i] = zT_94[_i];
        _i++;
    }
}
    zT_97 = node.child_2;
    if ((unsigned char)(zT_97 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_101 = self->store;
    zT_102 = node.child_2;
    zT_105 = zF_FCDD1D35_astStoreNodeAt(zT_101, zT_102);
    ifs_cn2 = zT_105;
    zT_106 = ifs_cn2.kind;
    zT_107 = (unsigned int)zT_106;
    zT_108 = 0;
    ifs_k2[zT_108] = zT_107;
    goto z_bb_8;
    z_bb_8:
    zT_110 = "IFST:K2";
    zT_112 = 7;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    ifst_k2m = zT_111;
    zT_113 = ifst_k2m;
    zT_115 = 0;
    zT_114 = ifs_k2[zT_115];
    zF_C914CB83_markerWriteInt(zT_113, zT_114);
    return;
}

/* semanticAnalyzerResolveForHeader */
void zF_8CE01C41_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    unsigned int zT_10 = 0;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_8143F551_AstKind zT_30;
    zT_8EED1867_ResolvedTypeTable* zT_33;
    unsigned int zT_34;
    zT_BAEE192E_Opt_10 zT_37 = {0};
    unsigned char zT_38;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_D155D06D_Type* zT_48;
    unsigned int zT_49;
    zT_D155D06D_Type zT_50;
    zT_939EE900_Arr_unsigned_int_1 zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    zT_338B7C76_TypeRegistry* zT_59;
    zT_0BB2A741_SlicePayload* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_0BB2A741_SlicePayload zT_63;
    unsigned int zT_64;
    int zT_65;
    zT_33EF6BFB_TypeKind zT_66;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_E834303C_ArrayPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_E834303C_ArrayPayload zT_74;
    unsigned int zT_75;
    int zT_76;
    zT_8143F551_AstKind zT_77;
    unsigned char zT_81;
    zT_8143F551_AstKind zT_82;
    int zT_86;
    zT_6B0A7D14_AstStore* zT_87;
    unsigned int zT_88;
    unsigned int zT_90 = 0;
    unsigned char zT_93;
    int zT_94;
    unsigned int zT_95;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_105;
    unsigned int zT_107 = 0;
    unsigned char* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    int zT_114;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_38C12417_SemanticAnalyzer* zT_119;
    zT_6B0A7D14_AstStore* zT_120;
    unsigned int zT_121;
    unsigned int zT_123 = 0;
    unsigned int* zT_124;
    unsigned int zT_125;
    int zT_126;
    unsigned int zT_127;
    unsigned int* zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    zT_6B0A7D14_AstStore* zT_139;
    unsigned int zT_140;
    unsigned int zT_142 = 0;
    unsigned char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    int zT_149;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_38C12417_SemanticAnalyzer* zT_162;
    unsigned int zT_163;
    unsigned int* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    unsigned int* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    unsigned char* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_c_m;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_ck_m;
    zT_BAEE192E_Opt_10 it_tid;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_tid_m;
    zT_D155D06D_Type ty;
    zT_939EE900_Arr_unsigned_int_1 elem_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u a5_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_p_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_e_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u f2_m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node.child_0;
    zT_10 = zF_54F95822_semanticAnalyzerRes(zT_7, zT_8);
    (void)zT_10;
    zT_12 = "FS:C";
    zT_14 = 4;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    fs_c_m = zT_13;
    zT_15 = fs_c_m;
    zT_16 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_19 = self->store;
    zT_20 = node.child_0;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    cnode = zT_23;
    zT_25 = "FS:CK";
    zT_27 = 5;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    fs_ck_m = zT_26;
    zT_28 = fs_ck_m;
    zT_30 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_28, (unsigned int)((unsigned int)zT_30));
    zT_33 = self->type_table;
    zT_34 = node.child_0;
    zT_37 = zF_999DCF51_resolvedTypeTableGe(zT_33, zT_34);
    it_tid = zT_37;
    zT_38 = it_tid.has_value;
    if (zT_38) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    tid = it_tid.value;
    zT_41 = "FS:T";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    fs_tid_m = zT_42;
    zT_44 = fs_tid_m;
    zT_45 = tid;
    zF_C914CB83_markerWriteInt(zT_44, zT_45);
    zT_47 = self->registry;
    zT_48 = zT_47->types_items;
    zT_49 = (unsigned int)tid;
    zT_50 = zT_48[zT_49];
    ty = zT_50;
    zT_53 = 18;
    zT_54 = 0;
    zT_52[zT_54] = zT_53;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        elem_box[_i] = zT_52[_i];
        _i++;
    }
}
    zT_55 = ty.kind;
    if ((unsigned char)(zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_156 = node.child_2;
    if ((unsigned char)(zT_156 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_3:
    zT_152 = "FS:M\n";
    zT_154 = 5;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    a5_m = zT_153;
    zT_155 = a5_m;
    zF_48AC7B3A_markerWrite(zT_155);
    goto z_bb_2;
    z_bb_4:
    zT_59 = self->registry;
    zT_60 = zT_59->slice_items;
    zT_61 = ty.payload_idx;
    zT_62 = (unsigned int)zT_61;
    zT_63 = zT_60[zT_62];
    zT_64 = zT_63.elem;
    zT_65 = 0;
    elem_box[zT_65] = zT_64;
    goto z_bb_5;
    z_bb_5:
    zT_87 = self->store;
    zT_88 = node_idx;
    zT_90 = zF_8BA26B9E_astStoreNodePayload(zT_87, zT_88);
    if ((unsigned char)(zT_90 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_6:
    zT_66 = ty.kind;
    if ((unsigned char)(zT_66 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_70 = self->registry;
    zT_71 = zT_70->array_items;
    zT_72 = ty.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    zT_75 = zT_74.elem;
    zT_76 = 0;
    elem_box[zT_76] = zT_75;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_77 = cnode.kind;
    if ((unsigned char)(zT_77 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_82 = cnode.kind;
    zT_81 = zT_82 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_12;
    z_bb_11:
    zT_81 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_81) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_86 = 0;
    elem_box[zT_86] = tid;
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    zT_94 = 0;
    zT_95 = elem_box[zT_94];
    zT_93 = zT_95 != (unsigned int)(18);
    goto z_bb_17;
    z_bb_16:
    zT_93 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_93) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_99 = "FS:P";
    zT_101 = 4;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    fs_p_m = zT_100;
    zT_102 = fs_p_m;
    zT_104 = self->store;
    zT_105 = node_idx;
    zT_107 = zF_8BA26B9E_astStoreNodePayload(zT_104, zT_105);
    zT_103 = zT_107;
    zF_C914CB83_markerWriteInt(zT_102, zT_103);
    zT_109 = "FS:E";
    zT_111 = 4;
    zT_110.ptr = zT_109;
    zT_110.len = zT_111;
    fs_e_m = zT_110;
    zT_112 = fs_e_m;
    zT_114 = 0;
    zT_113 = elem_box[zT_114];
    zF_C914CB83_markerWriteInt(zT_112, zT_113);
    zT_116 = self->local_decl_count;
    zT_117 = self->local_decl_cap;
    if ((unsigned char)(zT_116 >= zT_117)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_119 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_119);
    goto z_bb_21;
    z_bb_21:
    zT_120 = self->store;
    zT_121 = node_idx;
    zT_123 = zF_8BA26B9E_astStoreNodePayload(zT_120, zT_121);
    zT_124 = self->local_decl_names;
    zT_125 = self->local_decl_count;
    zT_124[zT_125] = zT_123;
    zT_126 = 0;
    zT_127 = elem_box[zT_126];
    zT_128 = self->local_decl_types;
    zT_129 = self->local_decl_count;
    zT_128[zT_129] = zT_127;
    zT_130 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_130 + (unsigned int)(1));
    zT_134 = "D4F:N";
    zT_136 = 5;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    d4f_n = zT_135;
    zT_137 = d4f_n;
    zT_139 = self->store;
    zT_140 = node_idx;
    zT_142 = zF_8BA26B9E_astStoreNodePayload(zT_139, zT_140);
    zT_138 = zT_142;
    zF_C914CB83_markerWriteInt(zT_137, zT_138);
    zT_144 = "D4F:T";
    zT_146 = 5;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    d4f_t = zT_145;
    zT_147 = d4f_t;
    zT_149 = 0;
    zT_148 = elem_box[zT_149];
    zF_C914CB83_markerWriteInt(zT_147, zT_148);
    goto z_bb_19;
    z_bb_22:
    zT_159 = self->local_decl_count;
    zT_160 = self->local_decl_cap;
    if ((unsigned char)(zT_159 >= zT_160)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    return;
    z_bb_24:
    zT_162 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_162);
    goto z_bb_25;
    z_bb_25:
    zT_163 = node.child_2;
    zT_164 = self->local_decl_names;
    zT_165 = self->local_decl_count;
    zT_164[zT_165] = zT_163;
    zT_166 = 13;
    zT_167 = self->local_decl_types;
    zT_168 = self->local_decl_count;
    zT_167[zT_168] = zT_166;
    zT_169 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_169 + (unsigned int)(1));
    zT_173 = "FIX2:LN";
    zT_175 = 7;
    zT_174.ptr = zT_173;
    zT_174.len = zT_175;
    f2_m = zT_174;
    zT_176 = f2_m;
    zT_177 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_176, zT_177);
    goto z_bb_23;
}

/* semanticAnalyzerResolveWhileHeader */
void zF_10900223_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_15 = {0};
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_38C12417_SemanticAnalyzer* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    unsigned int zT_61 = 0;
    zT_38C12417_SemanticAnalyzer* zT_62;
    unsigned int zT_63;
    unsigned int zT_64 = 0;
    unsigned int zT_65;
    zT_38C12417_SemanticAnalyzer* zT_68;
    unsigned int zT_69;
    unsigned int zT_71 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode ws_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_km;
    unsigned int wcond_t;
    unsigned int wcap_idx;
    zT_22A7C88B_AstNode wcap_node;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_1;
    if ((unsigned char)(zT_7 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self->store;
    zT_12 = node.child_1;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    ws_node = zT_15;
    zT_17 = "WST:N";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    wst_nm = zT_18;
    zT_20 = wst_nm;
    zT_21 = node_idx;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = "WST:K";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    wst_km = zT_24;
    zT_26 = wst_km;
    zT_28 = ws_node.kind;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    goto z_bb_2;
    z_bb_2:
    zT_31 = self;
    zT_32 = node.child_0;
    zT_34 = zF_54F95822_semanticAnalyzerRes(zT_31, zT_32);
    wcond_t = zT_34;
    zT_35 = self->store;
    zT_36 = node_idx;
    zT_38 = zF_8BA26B9E_astStoreNodePayload(zT_35, zT_36);
    if ((unsigned char)(zT_38 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_42 = self->store;
    zT_43 = node_idx;
    zT_45 = zF_8BA26B9E_astStoreNodePayload(zT_42, zT_43);
    wcap_idx = zT_45;
    zT_47 = self->store;
    zT_48 = wcap_idx;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    wcap_node = zT_50;
    zT_51 = wcap_node.kind;
    if ((unsigned char)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_65 = node.child_2;
    if ((unsigned char)(zT_65 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_55 = self;
    zT_58 = self->store;
    zT_59 = wcap_idx;
    zT_61 = zF_8BA26B9E_astStoreNodePayload(zT_58, zT_59);
    zT_56 = zT_61;
    zT_62 = self;
    zT_63 = wcond_t;
    zT_64 = zF_3E251D67_semanticAnalyzerCap(zT_62, zT_63);
    zT_57 = zT_64;
    zF_7BD72017_registerLocalDecl(zT_55, zT_56, zT_57);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_68 = self;
    zT_69 = node.child_2;
    zT_71 = zF_54F95822_semanticAnalyzerRes(zT_68, zT_69);
    (void)zT_71;
    goto z_bb_8;
    z_bb_8:
    return;
}

/* semanticAnalyzerResolveStmtIter */
void zF_10A0DC35_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int root_node) {
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_21 = {0};
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_28;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_8143F551_AstKind zT_36;
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    unsigned char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_61;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    unsigned int zT_72 = 0;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    unsigned char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_99;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_108;
    unsigned int zT_110;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_8143F551_AstKind zT_116;
    zT_6B0A7D14_AstStore* zT_120;
    unsigned int zT_121;
    unsigned int zT_123 = 0;
    unsigned char* zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    unsigned char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    unsigned int zT_140;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_145;
    zT_22A7C88B_AstNode zT_148 = {0};
    unsigned char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    zT_8143F551_AstKind zT_155;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_6B0A7D14_AstStore* zT_163;
    unsigned int zT_164;
    unsigned int zT_166 = 0;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_173;
    unsigned int zT_177;
    unsigned char zT_179;
    unsigned int zT_180;
    unsigned char zT_183;
    unsigned int zT_184;
    unsigned char zT_187;
    unsigned char zT_188;
    zT_6B0A7D14_AstStore* zT_194;
    unsigned int zT_195;
    zT_22A7C88B_AstNode zT_198 = {0};
    zT_8143F551_AstKind zT_199;
    unsigned char zT_201 = 0;
    zT_8143F551_AstKind zT_202;
    zT_38C12417_SemanticAnalyzer* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    zT_8143F551_AstKind zT_211;
    zT_38C12417_SemanticAnalyzer* zT_215;
    unsigned int zT_216;
    zT_ABC1EBBE_TypeResolveEnv zT_219;
    zT_6B0A7D14_AstStore* zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    zT_3D7259E2_SymbolRegistry* zT_222;
    zT_D3EB6303_StringInterner* zT_223;
    unsigned int zT_224;
    zT_F85C5DED_DiagnosticCollector* zT_225;
    zT_7234F36B_Opt_226 zT_226;
    zT_E2DF2801_LocalConstScope* zT_227;
    zT_F5B966E3_Opt_396 zT_228;
    zT_C8A278E4_LocalTypeScope* zT_229;
    zT_03B97CED_Opt_398 zT_230;
    unsigned int zT_231;
    zT_ABC1EBBE_TypeResolveEnv* zT_232;
    unsigned int zT_233;
    zT_8143F551_AstKind zT_234;
    unsigned int zT_240 = 0;
    zT_338B7C76_TypeRegistry* zT_244;
    unsigned int zT_245;
    unsigned char zT_249 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    zT_8EED1867_ResolvedTypeTable* zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    zT_C8A278E4_LocalTypeScope* zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    zT_6B0A7D14_AstStore* zT_263;
    unsigned int zT_264;
    unsigned int zT_266 = 0;
    unsigned int zT_267;
    unsigned int zT_268;
    zT_38C12417_SemanticAnalyzer* zT_270;
    zT_6B0A7D14_AstStore* zT_271;
    unsigned int zT_272;
    unsigned int zT_274 = 0;
    unsigned int* zT_275;
    unsigned int zT_276;
    unsigned int* zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned char zT_282;
    zT_8143F551_AstKind zT_283;
    zT_6B0A7D14_AstStore* zT_288;
    unsigned int zT_289;
    unsigned int zT_292 = 0;
    zT_C8A278E4_LocalTypeScope* zT_293;
    unsigned int zT_294;
    zT_BAEE192E_Opt_10 zT_296 = {0};
    unsigned char zT_297;
    unsigned char* zT_299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_300;
    unsigned int zT_301;
    zT_F85C5DED_DiagnosticCollector* zT_302;
    unsigned int zT_305;
    unsigned int zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    unsigned int zT_314;
    unsigned int zT_315;
    unsigned int zT_318 = 0;
    unsigned char zT_319;
    unsigned int zT_320;
    zT_6B0A7D14_AstStore* zT_324;
    unsigned int zT_325;
    zT_22A7C88B_AstNode zT_328 = {0};
    zT_8143F551_AstKind zT_329;
    zT_38C12417_SemanticAnalyzer* zT_333;
    unsigned int zT_334;
    unsigned int zT_336 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_340;
    zT_6B0A7D14_AstStore* zT_341;
    zT_338B7C76_TypeRegistry* zT_342;
    zT_3D7259E2_SymbolRegistry* zT_343;
    zT_D3EB6303_StringInterner* zT_344;
    unsigned int zT_345;
    zT_F85C5DED_DiagnosticCollector* zT_346;
    zT_7234F36B_Opt_226 zT_347;
    zT_E2DF2801_LocalConstScope* zT_348;
    zT_F5B966E3_Opt_396 zT_349;
    zT_C8A278E4_LocalTypeScope* zT_350;
    zT_03B97CED_Opt_398 zT_351;
    unsigned int zT_352;
    zT_ABC1EBBE_TypeResolveEnv* zT_354;
    unsigned int zT_355;
    unsigned int zT_360 = 0;
    unsigned char* zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    unsigned int zT_366;
    zT_F85C5DED_DiagnosticCollector* zT_367;
    unsigned int zT_370;
    unsigned int zT_371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_373;
    unsigned int zT_379;
    unsigned int zT_380;
    unsigned int zT_383 = 0;
    unsigned int zT_384;
    zT_8EED1867_ResolvedTypeTable* zT_386;
    unsigned int zT_387;
    zT_BAEE192E_Opt_10 zT_390 = {0};
    unsigned char zT_391;
    zT_ABC1EBBE_TypeResolveEnv zT_394;
    zT_6B0A7D14_AstStore* zT_395;
    zT_338B7C76_TypeRegistry* zT_396;
    zT_3D7259E2_SymbolRegistry* zT_397;
    zT_D3EB6303_StringInterner* zT_398;
    unsigned int zT_399;
    zT_F85C5DED_DiagnosticCollector* zT_400;
    zT_7234F36B_Opt_226 zT_401;
    zT_E2DF2801_LocalConstScope* zT_402;
    zT_F5B966E3_Opt_396 zT_403;
    zT_C8A278E4_LocalTypeScope* zT_404;
    zT_03B97CED_Opt_398 zT_405;
    unsigned int zT_406;
    zT_ABC1EBBE_TypeResolveEnv* zT_407;
    unsigned int zT_408;
    unsigned int zT_413 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_416;
    unsigned int zT_417;
    unsigned int zT_418;
    int zT_421;
    unsigned char* zT_427;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_428;
    unsigned int zT_429;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_430;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_432;
    unsigned int zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    int zT_439;
    unsigned char* zT_440;
    unsigned int zT_441;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_442;
    unsigned int zT_443 = 0;
    unsigned int zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_448;
    unsigned char* zT_452;
    unsigned int zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_454;
    unsigned char* zT_456;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_457;
    unsigned int zT_458;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_461;
    unsigned int zT_463;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_464;
    int zT_467;
    unsigned char* zT_468;
    unsigned int zT_469;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_470;
    unsigned int zT_471 = 0;
    unsigned int zT_475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_476;
    unsigned char* zT_480;
    unsigned int zT_481;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_482;
    unsigned char* zT_484;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_485;
    unsigned int zT_486;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_487;
    unsigned int zT_488;
    unsigned char zT_491;
    unsigned int zT_496;
    unsigned int zT_498;
    unsigned int zT_500;
    unsigned char* zT_502;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_503;
    unsigned int zT_504;
    zT_F85C5DED_DiagnosticCollector* zT_505;
    unsigned int zT_508;
    unsigned int zT_509;
    unsigned int zT_510;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_511;
    unsigned int zT_518 = 0;
    unsigned int zT_519;
    zT_6B0A7D14_AstStore* zT_523;
    unsigned int zT_524;
    zT_22A7C88B_AstNode zT_527 = {0};
    unsigned char* zT_529;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_530;
    unsigned int zT_531;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_532;
    zT_8143F551_AstKind zT_534;
    unsigned int zT_540;
    zT_38C12417_SemanticAnalyzer* zT_542;
    unsigned int zT_543;
    zT_38C12417_SemanticAnalyzer* zT_545;
    unsigned int zT_546;
    unsigned int zT_548 = 0;
    zT_38C12417_SemanticAnalyzer* zT_549;
    unsigned char zT_553;
    zT_8143F551_AstKind zT_554;
    zT_6B0A7D14_AstStore* zT_559;
    unsigned int zT_560;
    unsigned int zT_563 = 0;
    int zT_565;
    unsigned int zT_566;
    zT_338B7C76_TypeRegistry* zT_567;
    unsigned int zT_568;
    zT_338B7C76_TypeRegistry* zT_570;
    zT_D155D06D_Type* zT_571;
    zT_D155D06D_Type zT_572;
    zT_33EF6BFB_TypeKind zT_573;
    zT_338B7C76_TypeRegistry* zT_578;
    unsigned int zT_580;
    unsigned int zT_583 = 0;
    unsigned int zT_587;
    zT_21D3708C_U32ToU32Map* zT_589;
    unsigned int zT_590;
    unsigned int zT_592 = 0;
    zT_21D3708C_U32ToU32Map* zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    zT_8EED1867_ResolvedTypeTable* zT_598;
    unsigned int zT_599;
    unsigned int zT_600;
    int zT_603;
    unsigned int zT_605;
    unsigned char zT_609;
    zT_8143F551_AstKind zT_610;
    unsigned int zT_615;
    unsigned int zT_617;
    unsigned int zT_619;
    unsigned char* zT_621;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_622;
    unsigned int zT_623;
    zT_F85C5DED_DiagnosticCollector* zT_624;
    unsigned int zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_630;
    unsigned int zT_637 = 0;
    unsigned char zT_641;
    unsigned char* zT_646;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_647;
    unsigned int zT_648;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_649;
    zT_38C12417_SemanticAnalyzer* zT_651;
    unsigned int zT_652;
    unsigned int zT_653;
    unsigned int zT_654;
    unsigned int zT_656 = 0;
    zT_38C12417_SemanticAnalyzer* zT_657;
    unsigned int zT_658;
    unsigned int zT_659;
    unsigned int zT_660;
    unsigned char zT_662 = 0;
    zT_338B7C76_TypeRegistry* zT_664;
    unsigned int zT_665;
    unsigned int zT_666;
    zT_0FB7FB13_CoercionKind zT_668 = 0;
    unsigned char* zT_670;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_671;
    unsigned int zT_672;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_673;
    unsigned char zT_679;
    zT_338B7C76_TypeRegistry* zT_680;
    unsigned int zT_681;
    unsigned int zT_682;
    unsigned char zT_684 = 0;
    zT_66E7D2EF_CoercionTable* zT_685;
    unsigned int zT_686;
    zT_0FB7FB13_CoercionKind zT_687;
    unsigned int zT_688;
    unsigned char zT_693;
    zT_338B7C76_TypeRegistry* zT_694;
    unsigned int zT_695;
    unsigned int zT_696;
    unsigned char zT_698 = 0;
    unsigned int zT_701;
    unsigned int zT_703;
    unsigned int zT_705;
    unsigned char* zT_707;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_708;
    unsigned int zT_709;
    zT_338B7C76_TypeRegistry* zT_711;
    zT_D155D06D_Type* zT_712;
    unsigned int zT_713;
    zT_D155D06D_Type zT_714;
    zT_33EF6BFB_TypeKind zT_715;
    zT_338B7C76_TypeRegistry* zT_717;
    zT_D155D06D_Type* zT_718;
    unsigned int zT_719;
    zT_D155D06D_Type zT_720;
    zT_33EF6BFB_TypeKind zT_721;
    int zT_723;
    unsigned char zT_724;
    zT_38C12417_SemanticAnalyzer* zT_725;
    unsigned int zT_726;
    unsigned int zT_727;
    unsigned char zT_728 = 0;
    int zT_729;
    unsigned char zT_730;
    zT_38C12417_SemanticAnalyzer* zT_731;
    unsigned int zT_732;
    unsigned int zT_733;
    unsigned char zT_736 = 0;
    int zT_737;
    unsigned char zT_738;
    unsigned char zT_742;
    zT_338B7C76_TypeRegistry* zT_747;
    zT_42C2D6BF_EUPayload* zT_748;
    zT_338B7C76_TypeRegistry* zT_749;
    zT_D155D06D_Type* zT_750;
    unsigned int zT_751;
    zT_D155D06D_Type zT_752;
    unsigned int zT_753;
    unsigned int zT_754;
    zT_42C2D6BF_EUPayload zT_755;
    zT_338B7C76_TypeRegistry* zT_757;
    zT_42C2D6BF_EUPayload* zT_758;
    zT_338B7C76_TypeRegistry* zT_759;
    zT_D155D06D_Type* zT_760;
    unsigned int zT_761;
    zT_D155D06D_Type zT_762;
    unsigned int zT_763;
    unsigned int zT_764;
    zT_42C2D6BF_EUPayload zT_765;
    unsigned int zT_766;
    unsigned int zT_767;
    int zT_769;
    unsigned char zT_770;
    zT_F85C5DED_DiagnosticCollector* zT_772;
    unsigned char zT_773;
    unsigned int zT_775;
    unsigned int zT_776;
    unsigned int zT_777;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_778;
    unsigned int zT_782 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_783;
    unsigned int zT_784;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_785;
    zT_33EF6BFB_TypeKind zT_787;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_788 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_789;
    unsigned int zT_790;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_791;
    zT_33EF6BFB_TypeKind zT_793;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_794 = {0};
    unsigned char* zT_801;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_802;
    unsigned int zT_803;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_804;
    unsigned char* zT_806;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_807;
    unsigned int zT_808;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_809;
    unsigned int zT_811;
    unsigned int zT_813;
    unsigned int zT_815;
    unsigned char* zT_817;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_818;
    unsigned int zT_819;
    zT_F85C5DED_DiagnosticCollector* zT_820;
    unsigned int zT_823;
    unsigned int zT_824;
    unsigned int zT_825;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_826;
    unsigned int zT_831 = 0;
    zT_66E7D2EF_CoercionTable* zT_833;
    unsigned int zT_834;
    zT_5CC037A7_Opt_194 zT_837 = {0};
    unsigned char zT_838;
    zT_8EED1867_ResolvedTypeTable* zT_840;
    unsigned int zT_841;
    unsigned int zT_842;
    unsigned char zT_845;
    unsigned char zT_850;
    unsigned int zT_851;
    zT_E2DF2801_LocalConstScope* zT_854;
    unsigned int zT_855;
    unsigned int zT_856;
    zT_6B0A7D14_AstStore* zT_858;
    unsigned int zT_859;
    unsigned int zT_861 = 0;
    unsigned int zT_862;
    unsigned int zT_863;
    zT_38C12417_SemanticAnalyzer* zT_865;
    zT_6B0A7D14_AstStore* zT_869;
    unsigned int zT_870;
    unsigned int zT_872 = 0;
    unsigned int* zT_873;
    unsigned int zT_874;
    unsigned int* zT_875;
    unsigned int zT_876;
    unsigned int zT_877;
    unsigned int zT_881;
    zT_6B0A7D14_AstStore* zT_885;
    unsigned int zT_886;
    unsigned int zT_888 = 0;
    zT_79FAE712_u64 zT_890;
    zT_338B7C76_TypeRegistry* zT_891;
    zT_79FAE712_u64 zT_892;
    unsigned int zT_893;
    unsigned char* zT_896;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_897;
    unsigned int zT_898;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_899;
    unsigned int zT_900;
    zT_6B0A7D14_AstStore* zT_901;
    unsigned int zT_902;
    unsigned int zT_904 = 0;
    unsigned char* zT_906;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_907;
    unsigned int zT_908;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_909;
    unsigned int zT_910;
    zT_8143F551_AstKind zT_911;
    zT_38C12417_SemanticAnalyzer* zT_915;
    unsigned int zT_916;
    unsigned int zT_917;
    zT_38C12417_SemanticAnalyzer* zT_920;
    unsigned int zT_921;
    unsigned int zT_923;
    zT_38C12417_SemanticAnalyzer* zT_926;
    unsigned int zT_927;
    zT_8143F551_AstKind zT_929;
    zT_38C12417_SemanticAnalyzer* zT_933;
    unsigned int zT_934;
    unsigned int zT_935;
    zT_38C12417_SemanticAnalyzer* zT_938;
    unsigned int zT_939;
    zT_8143F551_AstKind zT_941;
    zT_38C12417_SemanticAnalyzer* zT_945;
    unsigned int zT_946;
    unsigned int zT_947;
    zT_38C12417_SemanticAnalyzer* zT_950;
    unsigned int zT_951;
    zT_8143F551_AstKind zT_953;
    zT_38C12417_SemanticAnalyzer* zT_957;
    unsigned int zT_958;
    zT_8143F551_AstKind zT_959;
    unsigned char zT_963;
    zT_8143F551_AstKind zT_964;
    unsigned char zT_968;
    zT_8143F551_AstKind zT_969;
    unsigned char zT_973;
    zT_8143F551_AstKind zT_974;
    unsigned char zT_978;
    zT_8143F551_AstKind zT_979;
    unsigned char zT_983;
    zT_8143F551_AstKind zT_984;
    unsigned char zT_988;
    zT_8143F551_AstKind zT_989;
    unsigned char zT_993;
    zT_8143F551_AstKind zT_994;
    unsigned char zT_998;
    zT_8143F551_AstKind zT_999;
    unsigned char zT_1003;
    zT_8143F551_AstKind zT_1004;
    unsigned char zT_1008;
    zT_8143F551_AstKind zT_1009;
    unsigned char zT_1013;
    zT_8143F551_AstKind zT_1014;
    unsigned char zT_1018;
    zT_8143F551_AstKind zT_1019;
    unsigned char zT_1023;
    zT_8143F551_AstKind zT_1024;
    unsigned char zT_1028;
    zT_8143F551_AstKind zT_1029;
    unsigned char zT_1033;
    zT_8143F551_AstKind zT_1034;
    unsigned char zT_1038;
    zT_8143F551_AstKind zT_1039;
    unsigned char zT_1043;
    zT_8143F551_AstKind zT_1044;
    zT_38C12417_SemanticAnalyzer* zT_1048;
    unsigned int zT_1049;
    unsigned int zT_1050 = 0;
    zT_8143F551_AstKind zT_1051;
    unsigned int zT_1055;
    zT_38C12417_SemanticAnalyzer* zT_1058;
    unsigned int zT_1059;
    zT_8143F551_AstKind zT_1061;
    unsigned char zT_1065;
    zT_8143F551_AstKind zT_1066;
    unsigned int zT_1070;
    unsigned int zT_1074;
    unsigned int zT_1076;
    zT_38C12417_SemanticAnalyzer* zT_1079;
    unsigned int zT_1080;
    unsigned int zT_1082;
    zT_38C12417_SemanticAnalyzer* zT_1085;
    unsigned int zT_1086;
    unsigned int zT_1088;
    zT_8143F551_AstKind zT_1091;
    zT_8143F551_AstKind zT_1095;
    unsigned char* zT_1100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1101;
    unsigned int zT_1102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1103;
    unsigned int zT_1104;
    unsigned char* zT_1106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1107;
    unsigned int zT_1108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1109;
    zT_8143F551_AstKind zT_1111;
    unsigned int zT_1113;
    unsigned char* zT_1117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1118;
    unsigned int zT_1119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1120;
    unsigned int zT_1121;
    zT_38C12417_SemanticAnalyzer* zT_1124;
    unsigned int zT_1125;
    unsigned int zT_1126 = 0;
    unsigned char zT_1129;
    zT_338B7C76_TypeRegistry* zT_1131;
    unsigned int zT_1132;
    unsigned char zT_1134;
    zT_338B7C76_TypeRegistry* zT_1135;
    zT_D155D06D_Type* zT_1136;
    unsigned int zT_1137;
    zT_D155D06D_Type zT_1138;
    zT_33EF6BFB_TypeKind zT_1139;
    unsigned int zT_1144;
    unsigned int zT_1146;
    unsigned int zT_1148;
    unsigned char* zT_1150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1151;
    unsigned int zT_1152;
    zT_F85C5DED_DiagnosticCollector* zT_1153;
    unsigned int zT_1156;
    unsigned int zT_1157;
    unsigned int zT_1158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1159;
    unsigned int zT_1166 = 0;
    unsigned int zT_1167;
    zT_6B0A7D14_AstStore* zT_1171;
    unsigned int zT_1172;
    zT_22A7C88B_AstNode zT_1175 = {0};
    zT_8143F551_AstKind zT_1176;
    unsigned int zT_1180;
    zT_6B0A7D14_AstStore* zT_1184;
    unsigned int zT_1185;
    zT_22A7C88B_AstNode zT_1188 = {0};
    zT_8143F551_AstKind zT_1189;
    unsigned int sp_base;
    unsigned int node_idx;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u spk_m;
    unsigned int children_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_cm;
    unsigned int i;
    unsigned int ci;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_nm;
    zT_8143F551_AstKind cnode_k;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u bcej;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd2_m;
    unsigned int decl_type;
    unsigned char vd_type_binding;
    zT_22A7C88B_AstNode inode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10k_m;
    zT_22A7C88B_AstNode vd_init_node;
    zT_ABC1EBBE_TypeResolveEnv vd_lt_env;
    unsigned int vd_alias_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_alias_msg;
    zT_22A7C88B_AstNode ann;
    zT_BAEE192E_Opt_10 rt;
    zT_ABC1EBBE_TypeResolveEnv cd_env;
    unsigned int cd_full;
    zT_8F083A69_Slice_zT_0B42B2F8_u ut_msg;
    unsigned int t;
    zT_ABC1EBBE_TypeResolveEnv tre_env_vd;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1m;
    zT_5A26C2ED_Arr_unsigned_char_1 b1nb;
    unsigned int b1nl;
    unsigned int b1ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1c;
    zT_5A26C2ED_Arr_unsigned_char_1 b1tb;
    unsigned int b1tl;
    unsigned int b1ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1nl2;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui_msg;
    zT_22A7C88B_AstNode init_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ik_m;
    unsigned int vd_exp;
    unsigned int it;
    unsigned int name_id;
    unsigned int ei;
    unsigned int ord;
    unsigned int es_type_id;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs4_m;
    unsigned int it_eff;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u ckv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmd_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdag_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vfvd_m;
    unsigned int vsp;
    unsigned int vep;
    zT_8F083A69_Slice_zT_0B42B2F8_u vv_msg;
    zT_5CC037A7_Opt_194 ct_entry;
    zT_79FAE712_u64 ck_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u regcp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u regct_m;
    unsigned int dc_saved_loops;
    unsigned int dc_saved_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_c0m;
    unsigned int els_r;
    unsigned int eisp;
    unsigned int eiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ei_msg;
    zT_22A7C88B_AstNode nc;
    zT_3 = self->stmt_work_len;
    sp_base = zT_3;
    zT_4 = self;
    zT_5 = root_node;
    zF_7AB741D8_semanticAnalyzerStm(zT_4, zT_5);
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->stmt_work_len;
    if ((unsigned char)(zT_6 > sp_base)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_8 - (unsigned int)(1));
    zT_12 = self->stmt_work_items;
    zT_13 = self->stmt_work_len;
    zT_14 = zT_12[zT_13];
    node_idx = zT_14;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_18 = self->store;
    zT_19 = node_idx;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    node = zT_21;
    zT_23 = "SP:n";
    zT_25 = 4;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    sp_m = zT_24;
    zT_26 = sp_m;
    zT_28 = self->stmt_work_len;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    zT_31 = "SP:K";
    zT_33 = 4;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    spk_m = zT_32;
    zT_34 = spk_m;
    zT_36 = node.kind;
    zF_C914CB83_markerWriteInt(zT_34, (unsigned int)((unsigned int)zT_36));
    zT_38 = node.kind;
    if ((unsigned char)(zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_43 = self->store;
    zT_44 = node_idx;
    zT_46 = zF_152E19CB_astStoreNodeExtraCh(zT_43, zT_44);
    children_n = zT_46;
    zT_48 = "BLK:N";
    zT_50 = 5;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    blk_nm = zT_49;
    zT_51 = blk_nm;
    zT_52 = node_idx;
    zF_C914CB83_markerWriteInt(zT_51, zT_52);
    zT_54 = "BLK:C";
    zT_56 = 5;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    blk_cm = zT_55;
    zT_57 = blk_cm;
    zF_C914CB83_markerWriteInt(zT_57, (unsigned int)((unsigned int)children_n));
    zT_61 = (unsigned int)children_n;
    i = zT_61;
    goto z_bb_10;
    z_bb_8:
    zT_1167 = node.child_0;
    if ((unsigned char)(zT_1167 != (unsigned int)(0))) goto z_bb_240; else goto z_bb_241;
    z_bb_9:
    zT_116 = node.kind;
    if ((unsigned char)(zT_116 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_14; else goto z_bb_16;
    z_bb_10:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_65 = self->store;
    zT_66 = node_idx;
    zT_72 = zF_B10B1BC1_astStoreNodeExtraCh(zT_65, zT_66, (unsigned int)((unsigned int)((unsigned int)i) - (unsigned int)(1)));
    ci = zT_72;
    zT_74 = "BCK:B";
    zT_76 = 5;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    bc_m = zT_75;
    zT_77 = bc_m;
    zT_78 = node_idx;
    zF_C914CB83_markerWriteInt(zT_77, zT_78);
    zT_80 = "BCK:I";
    zT_82 = 5;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    bc_im = zT_81;
    zT_83 = bc_im;
    zF_C914CB83_markerWriteInt(zT_83, (unsigned int)((unsigned int)(unsigned int)(i - (unsigned int)(1))));
    zT_89 = "BCK:N";
    zT_91 = 5;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    bc_nm = zT_90;
    zT_92 = bc_nm;
    zT_93 = ci;
    zF_C914CB83_markerWriteInt(zT_92, zT_93);
    zT_95 = self->store;
    zT_96 = ci;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_95, zT_96);
    zT_99 = zT_98.kind;
    cnode_k = zT_99;
    zT_101 = "BCK:K";
    zT_103 = 5;
    zT_102.ptr = zT_101;
    zT_102.len = zT_103;
    bc_km = zT_102;
    zT_104 = bc_km;
    zF_C914CB83_markerWriteInt(zT_104, (unsigned int)((unsigned int)cnode_k));
    zT_107 = self;
    zT_108 = ci;
    zF_7AB741D8_semanticAnalyzerStm(zT_107, zT_108);
    goto z_bb_13;
    z_bb_12:
    zT_112 = "]\n";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    bcej = zT_113;
    zT_115 = bcej;
    zF_48AC7B3A_markerWrite(zT_115);
    goto z_bb_8;
    z_bb_13:
    zT_110 = i - (unsigned int)(1);
    i = zT_110;
    goto z_bb_10;
    z_bb_14:
    zT_120 = self->store;
    zT_121 = node_idx;
    zT_123 = zF_8BA26B9E_astStoreNodePayload(zT_120, zT_121);
    if ((unsigned char)(zT_123 == (unsigned int)(55))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_911 = node.kind;
    if ((unsigned char)(zT_911 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_137; else goto z_bb_139;
    z_bb_17:
    zT_127 = "D10:C0";
    zT_129 = 6;
    zT_128.ptr = zT_127;
    zT_128.len = zT_129;
    d10n_m = zT_128;
    zT_130 = d10n_m;
    zT_131 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_130, zT_131);
    zT_134 = "D10:C1";
    zT_136 = 6;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    d10c_m = zT_135;
    zT_137 = d10c_m;
    zT_138 = node.child_1;
    zF_C914CB83_markerWriteInt(zT_137, zT_138);
    zT_140 = node.child_1;
    if ((unsigned char)(zT_140 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_158 = "VD:N";
    zT_160 = 4;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    vd_m = zT_159;
    zT_161 = vd_m;
    zT_163 = self->store;
    zT_164 = node_idx;
    zT_166 = zF_8BA26B9E_astStoreNodePayload(zT_163, zT_164);
    zT_162 = zT_166;
    zF_C914CB83_markerWriteInt(zT_161, zT_162);
    zT_168 = "VD:C";
    zT_170 = 4;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    vd2_m = zT_169;
    zT_171 = vd2_m;
    zT_173 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_171, (unsigned int)((unsigned int)zT_173));
    zT_177 = 18;
    decl_type = zT_177;
    zT_179 = 0;
    vd_type_binding = zT_179;
    zT_180 = node.child_0;
    if ((unsigned char)(zT_180 == (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_144 = self->store;
    zT_145 = node.child_1;
    zT_148 = zF_FCDD1D35_astStoreNodeAt(zT_144, zT_145);
    inode = zT_148;
    zT_150 = "D10:IK";
    zT_152 = 6;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    d10k_m = zT_151;
    zT_153 = d10k_m;
    zT_155 = inode.kind;
    zF_C914CB83_markerWriteInt(zT_153, (unsigned int)((unsigned int)zT_155));
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_184 = node.child_1;
    zT_183 = zT_184 != (unsigned int)(0);
    goto z_bb_23;
    z_bb_22:
    zT_183 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_183) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_188 = node.flags;
    zT_187 = (unsigned char)(zT_188 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_187 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_187) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_194 = self->store;
    zT_195 = node.child_1;
    zT_198 = zF_FCDD1D35_astStoreNodeAt(zT_194, zT_195);
    vd_init_node = zT_198;
    zT_199 = vd_init_node.kind;
    zT_201 = zF_82C2F046_isContainerDeclKind(zT_199);
    if (zT_201) goto z_bb_29; else goto z_bb_31;
    z_bb_28:
    zT_320 = node.child_0;
    if ((unsigned char)(zT_320 != (unsigned int)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_29:
    zT_202 = vd_init_node.kind;
    if ((unsigned char)(zT_202 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_32; else goto z_bb_33;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_283 = vd_init_node.kind;
    if ((unsigned char)(zT_283 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_40; else goto z_bb_41;
    z_bb_32:
    zT_206 = self;
    zT_207 = node.child_1;
    zT_208 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_206, zT_207, zT_208);
    goto z_bb_33;
    z_bb_33:
    zT_211 = vd_init_node.kind;
    if ((unsigned char)(zT_211 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_215 = self;
    zT_216 = node.child_1;
    zF_E3AF2BA9_semanticAnalyzerChe(zT_215, zT_216);
    goto z_bb_35;
    z_bb_35:
    zT_220 = self->store;
    zT_219.store = zT_220;
    zT_221 = self->registry;
    zT_219.typereg = zT_221;
    zT_222 = self->symbols;
    zT_219.symbol_reg = zT_222;
    zT_223 = self->interner;
    zT_219.interner = zT_223;
    zT_224 = self->module_id;
    zT_219.module_id = zT_224;
    zT_225 = self->diag;
    zT_226.has_value = 1;
    zT_226.value = zT_225;
    zT_219.diag = zT_226;
    zT_227 = &self->local_consts;
    zT_228.has_value = 1;
    zT_228.value = zT_227;
    zT_219.local_consts = zT_228;
    zT_229 = &self->local_types;
    zT_230.has_value = 1;
    zT_230.value = zT_229;
    zT_219.local_types = zT_230;
    zT_231 = self->source_file_id;
    zT_219.source_file_id = zT_231;
    vd_lt_env = zT_219;
    zT_232 = &vd_lt_env;
    zT_233 = node.child_1;
    zT_234 = vd_init_node.kind;
    zT_240 = zF_FE81311F_registerContainerTy(zT_232, zT_233, zT_234, (unsigned int)(0));
    decl_type = zT_240;
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_244 = self->registry;
    zT_245 = decl_type;
    zT_249 = zF_3E55D0D5_layoutEnsure(zT_244, zT_245, (unsigned int)(0));
    (void)zT_249;
    zT_250 = self->type_table;
    zT_251 = node.child_1;
    zT_252 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_250, zT_251, zT_252);
    zT_255 = self->type_table;
    zT_256 = node_idx;
    zT_257 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_255, zT_256, zT_257);
    zT_259 = &self->local_types;
    zT_263 = self->store;
    zT_264 = node_idx;
    zT_266 = zF_8BA26B9E_astStoreNodePayload(zT_263, zT_264);
    zT_260 = zT_266;
    zT_261 = decl_type;
    zF_A3A445A0_localTypeScopePush(zT_259, zT_260, zT_261);
    zT_267 = self->local_decl_count;
    zT_268 = self->local_decl_cap;
    if ((unsigned char)(zT_267 >= zT_268)) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_282 = 1;
    vd_type_binding = zT_282;
    goto z_bb_30;
    z_bb_38:
    zT_270 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_270);
    goto z_bb_39;
    z_bb_39:
    zT_271 = self->store;
    zT_272 = node_idx;
    zT_274 = zF_8BA26B9E_astStoreNodePayload(zT_271, zT_272);
    zT_275 = self->local_decl_names;
    zT_276 = self->local_decl_count;
    zT_275[zT_276] = zT_274;
    zT_277 = self->local_decl_types;
    zT_278 = self->local_decl_count;
    zT_277[zT_278] = decl_type;
    zT_279 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_279 + (unsigned int)(1));
    goto z_bb_37;
    z_bb_40:
    zT_288 = self->store;
    zT_289 = node.child_1;
    zT_292 = zF_53458827_astStoreIdentifier(zT_288, zT_289);
    vd_alias_name = zT_292;
    zT_293 = &self->local_types;
    zT_294 = vd_alias_name;
    zT_296 = zF_C768898A_localTypeScopeLooku(zT_293, zT_294);
    zT_297 = zT_296.has_value;
    if (zT_297) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    goto z_bb_30;
    z_bb_42:
    zT_299 = "local type aliases are not supported; bind the container declaration directly";
    zT_301 = 77;
    zT_300.ptr = zT_299;
    zT_300.len = zT_301;
    vd_alias_msg = zT_300;
    zT_302 = self->diag;
    zT_305 = self->source_file_id;
    zT_306 = node.span_start;
    zT_314 = node.span_start;
    zT_315 = node.span_len;
    zT_308 = vd_alias_msg;
    zT_318 = zF_C82559AC_diagnosticCollector(zT_302, (unsigned char)(0), (unsigned short)(3000), zT_305, zT_306, (unsigned int)(zT_314 + (unsigned int)((unsigned int)zT_315)), zT_308);
    (void)zT_318;
    zT_319 = 1;
    vd_type_binding = zT_319;
    goto z_bb_43;
    z_bb_43:
    goto z_bb_41;
    z_bb_44:
    zT_324 = self->store;
    zT_325 = node.child_0;
    zT_328 = zF_FCDD1D35_astStoreNodeAt(zT_324, zT_325);
    ann = zT_328;
    zT_329 = ann.kind;
    if ((unsigned char)(zT_329 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_46; else goto z_bb_48;
    z_bb_45:
    zT_421 = 0;
    if ((unsigned char)(vd_type_binding == zT_421)) goto z_bb_58; else goto z_bb_59;
    z_bb_46:
    zT_333 = self;
    zT_334 = node.child_0;
    zT_336 = zF_54F95822_semanticAnalyzerRes(zT_333, zT_334);
    decl_type = zT_336;
    if ((unsigned char)(decl_type == (unsigned int)(1))) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_386 = self->type_table;
    zT_387 = node.child_0;
    zT_390 = zF_999DCF51_resolvedTypeTableGe(zT_386, zT_387);
    rt = zT_390;
    zT_391 = rt.has_value;
    if (zT_391) goto z_bb_53; else goto z_bb_55;
    z_bb_49:
    zT_341 = self->store;
    zT_340.store = zT_341;
    zT_342 = self->registry;
    zT_340.typereg = zT_342;
    zT_343 = self->symbols;
    zT_340.symbol_reg = zT_343;
    zT_344 = self->interner;
    zT_340.interner = zT_344;
    zT_345 = self->module_id;
    zT_340.module_id = zT_345;
    zT_346 = self->diag;
    zT_347.has_value = 1;
    zT_347.value = zT_346;
    zT_340.diag = zT_347;
    zT_348 = &self->local_consts;
    zT_349.has_value = 1;
    zT_349.value = zT_348;
    zT_340.local_consts = zT_349;
    zT_350 = &self->local_types;
    zT_351.has_value = 1;
    zT_351.value = zT_350;
    zT_340.local_types = zT_351;
    zT_352 = self->source_file_id;
    zT_340.source_file_id = zT_352;
    cd_env = zT_340;
    zT_354 = &cd_env;
    zT_355 = node.child_0;
    zT_360 = zF_F2107C15_resolveTypeExprFull(zT_354, zT_355, (unsigned int)(0));
    cd_full = zT_360;
    if ((unsigned char)(cd_full == (unsigned int)(18))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_47;
    z_bb_51:
    zT_364 = "unknown type in variable declaration";
    zT_366 = 36;
    zT_365.ptr = zT_364;
    zT_365.len = zT_366;
    ut_msg = zT_365;
    zT_367 = self->diag;
    zT_370 = self->source_file_id;
    zT_371 = ann.span_start;
    zT_379 = ann.span_start;
    zT_380 = ann.span_len;
    zT_373 = ut_msg;
    zT_383 = zF_C82559AC_diagnosticCollector(zT_367, (unsigned char)(0), (unsigned short)(3000), zT_370, zT_371, (unsigned int)(zT_379 + (unsigned int)((unsigned int)zT_380)), zT_373);
    (void)zT_383;
    zT_384 = 18;
    decl_type = zT_384;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    t = rt.value;
    decl_type = t;
    goto z_bb_54;
    z_bb_54:
    goto z_bb_47;
    z_bb_55:
    zT_395 = self->store;
    zT_394.store = zT_395;
    zT_396 = self->registry;
    zT_394.typereg = zT_396;
    zT_397 = self->symbols;
    zT_394.symbol_reg = zT_397;
    zT_398 = self->interner;
    zT_394.interner = zT_398;
    zT_399 = self->module_id;
    zT_394.module_id = zT_399;
    zT_400 = self->diag;
    zT_401.has_value = 1;
    zT_401.value = zT_400;
    zT_394.diag = zT_401;
    zT_402 = &self->local_consts;
    zT_403.has_value = 1;
    zT_403.value = zT_402;
    zT_394.local_consts = zT_403;
    zT_404 = &self->local_types;
    zT_405.has_value = 1;
    zT_405.value = zT_404;
    zT_394.local_types = zT_405;
    zT_406 = self->source_file_id;
    zT_394.source_file_id = zT_406;
    tre_env_vd = zT_394;
    zT_407 = &tre_env_vd;
    zT_408 = node.child_0;
    zT_413 = zF_F2107C15_resolveTypeExprFull(zT_407, zT_408, (unsigned int)(0));
    decl_type = zT_413;
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_416 = self->type_table;
    zT_417 = node.child_0;
    zT_418 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_416, zT_417, zT_418);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_54;
    z_bb_58:
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_15;
    z_bb_60:
    zT_427 = "VRT:";
    zT_429 = 4;
    zT_428.ptr = zT_427;
    zT_428.len = zT_429;
    b1m = zT_428;
    zT_430 = b1m;
    zF_48AC7B3A_markerWrite(zT_430);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_432[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1nb[_i] = zT_432[_i];
        _i++;
    }
}
    zT_434 = node.child_0;
    zT_439 = 0;
    zT_440 = (unsigned char*)((unsigned char*)b1nb) + zT_439;
    zT_441 = (unsigned int)(10) - zT_439;
    zT_442.ptr = zT_440;
    zT_442.len = zT_441;
    zT_435 = zT_442;
    zT_443 = zF_A7504564_itoa(zT_434, zT_435);
    b1nl = zT_443;
    zT_447 = (unsigned int)(9) - (unsigned int)((unsigned int)b1nl);
    b1ns = zT_447;
    zT_452 = (unsigned char*)((unsigned char*)b1nb) + b1ns;
    zT_453 = (unsigned int)(9) - b1ns;
    zT_454.ptr = zT_452;
    zT_454.len = zT_453;
    zT_448 = zT_454;
    zF_48AC7B3A_markerWrite(zT_448);
    zT_456 = ":";
    zT_458 = 1;
    zT_457.ptr = zT_456;
    zT_457.len = zT_458;
    b1c = zT_457;
    zT_459 = b1c;
    zF_48AC7B3A_markerWrite(zT_459);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_461[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1tb[_i] = zT_461[_i];
        _i++;
    }
}
    zT_463 = decl_type;
    zT_467 = 0;
    zT_468 = (unsigned char*)((unsigned char*)b1tb) + zT_467;
    zT_469 = (unsigned int)(10) - zT_467;
    zT_470.ptr = zT_468;
    zT_470.len = zT_469;
    zT_464 = zT_470;
    zT_471 = zF_A7504564_itoa(zT_463, zT_464);
    b1tl = zT_471;
    zT_475 = (unsigned int)(9) - (unsigned int)((unsigned int)b1tl);
    b1ts = zT_475;
    zT_480 = (unsigned char*)((unsigned char*)b1tb) + b1ts;
    zT_481 = (unsigned int)(9) - b1ts;
    zT_482.ptr = zT_480;
    zT_482.len = zT_481;
    zT_476 = zT_482;
    zF_48AC7B3A_markerWrite(zT_476);
    zT_484 = "\n";
    zT_486 = 1;
    zT_485.ptr = zT_484;
    zT_485.len = zT_486;
    b1nl2 = zT_485;
    zT_487 = b1nl2;
    zF_48AC7B3A_markerWrite(zT_487);
    goto z_bb_61;
    z_bb_61:
    zT_488 = node.child_1;
    if ((unsigned char)(zT_488 == (unsigned int)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_491 = decl_type != (unsigned int)(18);
    goto z_bb_64;
    z_bb_63:
    zT_491 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_491) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_496 = node.span_start;
    uisp = zT_496;
    zT_498 = node.span_len;
    zT_500 = uisp + (unsigned int)((unsigned int)zT_498);
    uiep = zT_500;
    zT_502 = "variable must be initialized; use '= undefined' to opt out";
    zT_504 = 58;
    zT_503.ptr = zT_502;
    zT_503.len = zT_504;
    ui_msg = zT_503;
    zT_505 = self->diag;
    zT_508 = self->source_file_id;
    zT_509 = uisp;
    zT_510 = uiep;
    zT_511 = ui_msg;
    zT_518 = zF_C82559AC_diagnosticCollector(zT_505, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3014_USE_OF_UNDEFINED_VARIABLE)), zT_508, zT_509, zT_510, zT_511);
    (void)zT_518;
    goto z_bb_66;
    z_bb_66:
    zT_519 = node.child_1;
    if ((unsigned char)(zT_519 != (unsigned int)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_523 = self->store;
    zT_524 = node.child_1;
    zT_527 = zF_FCDD1D35_astStoreNodeAt(zT_523, zT_524);
    init_node = zT_527;
    zT_529 = "I:K";
    zT_531 = 3;
    zT_530.ptr = zT_529;
    zT_530.len = zT_531;
    ik_m = zT_530;
    zT_532 = ik_m;
    zT_534 = init_node.kind;
    zF_C914CB83_markerWriteInt(zT_532, (unsigned int)((unsigned int)zT_534));
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    zT_845 = node.flags;
    if ((unsigned char)((unsigned char)(zT_845 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_128; else goto z_bb_129;
    z_bb_69:
    zT_540 = decl_type;
    goto z_bb_71;
    z_bb_70:
    zT_540 = 0;
    goto z_bb_71;
    z_bb_71:
    vd_exp = zT_540;
    zT_542 = self;
    zT_543 = vd_exp;
    zF_9665A229_pushExpectedType(zT_542, zT_543);
    zT_545 = self;
    zT_546 = node.child_1;
    zT_548 = zF_54F95822_semanticAnalyzerRes(zT_545, zT_546);
    it = zT_548;
    zT_549 = self;
    zF_BC478E78_popExpectedType(zT_549);
    if ((unsigned char)(decl_type == (unsigned int)(18))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_554 = init_node.kind;
    zT_553 = zT_554 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal);
    goto z_bb_74;
    z_bb_73:
    zT_553 = 0;
    goto z_bb_74;
    z_bb_74:
    if (zT_553) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_559 = self->store;
    zT_560 = node.child_1;
    zT_563 = zF_8BA26B9E_astStoreNodePayload(zT_559, zT_560);
    name_id = zT_563;
    zT_565 = 0;
    zT_566 = (unsigned int)zT_565;
    ei = zT_566;
    goto z_bb_77;
    z_bb_76:
    if ((unsigned char)(decl_type == (unsigned int)(18))) goto z_bb_85; else goto z_bb_86;
    z_bb_77:
    zT_567 = self->registry;
    zT_568 = zT_567->types_len;
    if ((unsigned char)(ei < zT_568)) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_570 = self->registry;
    zT_571 = zT_570->types_items;
    zT_572 = zT_571[ei];
    zT_573 = zT_572.kind;
    if ((unsigned char)(zT_573 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_81; else goto z_bb_82;
    z_bb_79:
    goto z_bb_76;
    z_bb_80:
    zT_603 = 1;
    zT_605 = ei + (unsigned int)((unsigned int)zT_603);
    ei = zT_605;
    goto z_bb_77;
    z_bb_81:
    zT_578 = self->registry;
    zT_580 = name_id;
    zT_583 = zF_D2ECD176_typeRegistryErrorSe(zT_578, (unsigned int)((unsigned int)ei), zT_580);
    ord = zT_583;
    if ((unsigned char)(ord != (unsigned int)(4294967295u))) goto z_bb_83; else goto z_bb_84;
    z_bb_82:
    goto z_bb_80;
    z_bb_83:
    zT_587 = (unsigned int)ei;
    es_type_id = zT_587;
    zT_589 = self->error_code_registry;
    zT_590 = name_id;
    zT_592 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_589, zT_590);
    reg_code = zT_592;
    zT_593 = self->enum_value_table;
    zT_594 = node.child_1;
    zT_595 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_593, zT_594, zT_595);
    zT_598 = self->type_table;
    zT_599 = node.child_1;
    zT_600 = es_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_598, zT_599, zT_600);
    it = es_type_id;
    goto z_bb_79;
    z_bb_84:
    goto z_bb_82;
    z_bb_85:
    zT_610 = init_node.kind;
    zT_609 = zT_610 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_87;
    z_bb_86:
    zT_609 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_609) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_615 = init_node.span_start;
    sp = zT_615;
    zT_617 = init_node.span_len;
    zT_619 = sp + (unsigned int)((unsigned int)zT_617);
    ep = zT_619;
    zT_621 = "unable to infer type of enum literal without context";
    zT_623 = 52;
    zT_622.ptr = zT_621;
    zT_622.len = zT_623;
    elu_msg = zT_622;
    zT_624 = self->diag;
    zT_627 = self->source_file_id;
    zT_628 = sp;
    zT_629 = ep;
    zT_630 = elu_msg;
    zT_637 = zF_C82559AC_diagnosticCollector(zT_624, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3010_CANNOT_INFER_ENUM_LITERAL_TYPE)), zT_627, zT_628, zT_629, zT_630);
    (void)zT_637;
    goto z_bb_89;
    z_bb_89:
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_641 = it != decl_type;
    goto z_bb_92;
    z_bb_91:
    zT_641 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_641) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    if ((unsigned char)(it == (unsigned int)(17))) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    if ((unsigned char)(decl_type == (unsigned int)(18))) goto z_bb_122; else goto z_bb_123;
    z_bb_95:
    zT_646 = "CS4\n";
    zT_648 = 4;
    zT_647.ptr = zT_646;
    zT_647.len = zT_648;
    cs4_m = zT_647;
    zT_649 = cs4_m;
    zF_48AC7B3A_markerWrite(zT_649);
    goto z_bb_96;
    z_bb_96:
    zT_651 = self;
    zT_652 = node.child_1;
    zT_653 = decl_type;
    zT_654 = it;
    zT_656 = zF_FFC95E09_errLitSrcType(zT_651, zT_652, zT_653, zT_654);
    it_eff = zT_656;
    zT_657 = self;
    zT_658 = node.child_1;
    zT_659 = it_eff;
    zT_660 = decl_type;
    zT_662 = zF_86AAA417_semanticAnalyzerMay(zT_657, zT_658, zT_659, zT_660);
    if (zT_662) goto z_bb_97; else goto z_bb_99;
    z_bb_97:
    goto z_bb_98;
    z_bb_98:
    goto z_bb_94;
    z_bb_99:
    zT_664 = self->registry;
    zT_665 = it_eff;
    zT_666 = decl_type;
    zT_668 = zF_713658BF_classifyCoercion(zT_664, zT_665, zT_666);
    ck = zT_668;
    zT_670 = "CCK:vr";
    zT_672 = 6;
    zT_671.ptr = zT_670;
    zT_671.len = zT_672;
    ckv_m = zT_671;
    zT_673 = ckv_m;
    zF_C914CB83_markerWriteInt(zT_673, (unsigned int)((unsigned int)ck));
    if ((unsigned char)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_680 = self->registry;
    zT_681 = it_eff;
    zT_682 = decl_type;
    zT_684 = zF_683AEB7F_typeRegistryIsAssig(zT_680, zT_681, zT_682);
    zT_679 = zT_684;
    goto z_bb_102;
    z_bb_101:
    zT_679 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_679) goto z_bb_103; else goto z_bb_105;
    z_bb_103:
    zT_685 = self->coercion_table;
    zT_686 = node.child_1;
    zT_687 = ck;
    zT_688 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_685, zT_686, zT_687, zT_688);
    goto z_bb_104;
    z_bb_104:
    goto z_bb_98;
    z_bb_105:
    if ((unsigned char)(it != (unsigned int)(18))) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    zT_694 = self->registry;
    zT_695 = it;
    zT_696 = decl_type;
    zT_698 = zF_683AEB7F_typeRegistryIsAssig(zT_694, zT_695, zT_696);
    zT_693 = !zT_698;
    goto z_bb_108;
    z_bb_107:
    zT_693 = 0;
    goto z_bb_108;
    z_bb_108:
    if (zT_693) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_701 = node.span_start;
    sp = zT_701;
    zT_703 = node.span_len;
    zT_705 = sp + (unsigned int)((unsigned int)zT_703);
    ep = zT_705;
    zT_707 = "type mismatch in variable declaration — initialization type may not be compatible with declared type";
    zT_709 = 102;
    zT_708.ptr = zT_707;
    zT_708.len = zT_709;
    tmd_msg = zT_708;
    zT_711 = self->registry;
    zT_712 = zT_711->types_items;
    zT_713 = (unsigned int)it;
    zT_714 = zT_712[zT_713];
    zT_715 = zT_714.kind;
    sk = zT_715;
    zT_717 = self->registry;
    zT_718 = zT_717->types_items;
    zT_719 = (unsigned int)decl_type;
    zT_720 = zT_718[zT_719];
    zT_721 = zT_720.kind;
    tk = zT_721;
    zT_723 = 1;
    zT_724 = (unsigned char)zT_723;
    level = zT_724;
    zT_725 = self;
    zT_726 = it;
    zT_727 = decl_type;
    zT_728 = zF_148F8E19_semanticAnalyzerFnP(zT_725, zT_726, zT_727);
    if (zT_728) goto z_bb_111; else goto z_bb_112;
    z_bb_110:
    goto z_bb_104;
    z_bb_111:
    zT_729 = 0;
    zT_730 = (unsigned char)zT_729;
    level = zT_730;
    goto z_bb_112;
    z_bb_112:
    zT_731 = self;
    zT_732 = it;
    zT_733 = decl_type;
    zT_736 = zF_D728034A_isBShapeMismatch(zT_731, zT_732, zT_733, (unsigned char)(1));
    if (zT_736) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_737 = 0;
    zT_738 = (unsigned char)zT_737;
    level = zT_738;
    goto z_bb_114;
    z_bb_114:
    if ((unsigned char)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_115; else goto z_bb_116;
    z_bb_115:
    zT_742 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_117;
    z_bb_116:
    zT_742 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_742) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_747 = self->registry;
    zT_748 = zT_747->eu_items;
    zT_749 = self->registry;
    zT_750 = zT_749->types_items;
    zT_751 = (unsigned int)it;
    zT_752 = zT_750[zT_751];
    zT_753 = zT_752.payload_idx;
    zT_754 = (unsigned int)zT_753;
    zT_755 = zT_748[zT_754];
    eu_src = zT_755;
    zT_757 = self->registry;
    zT_758 = zT_757->eu_items;
    zT_759 = self->registry;
    zT_760 = zT_759->types_items;
    zT_761 = (unsigned int)decl_type;
    zT_762 = zT_760[zT_761];
    zT_763 = zT_762.payload_idx;
    zT_764 = (unsigned int)zT_763;
    zT_765 = zT_758[zT_764];
    eu_tgt = zT_765;
    zT_766 = eu_src.error_set;
    zT_767 = eu_tgt.error_set;
    if ((unsigned char)(zT_766 == zT_767)) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    zT_772 = self->diag;
    zT_773 = level;
    zT_775 = self->source_file_id;
    zT_776 = sp;
    zT_777 = ep;
    zT_778 = tmd_msg;
    zT_782 = zF_C82559AC_diagnosticCollector(zT_772, zT_773, (unsigned short)(3000), zT_775, zT_776, zT_777, zT_778);
    di = zT_782;
    zT_783 = self->diag;
    zT_784 = di;
    zT_787 = sk;
    zT_788 = zF_C14453DE_typeKindSrcStr(zT_787);
    zT_785 = zT_788;
    zF_426E1F18_diagnosticCollector(zT_783, zT_784, zT_785);
    (void)self;
    zT_789 = self->diag;
    zT_790 = di;
    zT_793 = tk;
    zT_794 = zF_CC479241_typeKindTgtStr(zT_793);
    zT_791 = zT_794;
    zF_426E1F18_diagnosticCollector(zT_789, zT_790, zT_791);
    (void)self;
    goto z_bb_110;
    z_bb_120:
    zT_769 = 0;
    zT_770 = (unsigned char)zT_769;
    level = zT_770;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    decl_type = it;
    goto z_bb_123;
    z_bb_123:
    if ((unsigned char)(decl_type == (unsigned int)(1))) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    zT_801 = "VDIAG:void_var\n";
    zT_803 = 15;
    zT_802.ptr = zT_801;
    zT_802.len = zT_803;
    vdag_m = zT_802;
    zT_804 = vdag_m;
    zF_48AC7B3A_markerWrite(zT_804);
    zT_806 = "VFLOW:vdag\n";
    zT_808 = 11;
    zT_807.ptr = zT_806;
    zT_807.len = zT_808;
    vfvd_m = zT_807;
    zT_809 = vfvd_m;
    zF_48AC7B3A_markerWrite(zT_809);
    zT_811 = node.span_start;
    vsp = zT_811;
    zT_813 = node.span_len;
    zT_815 = vsp + (unsigned int)((unsigned int)zT_813);
    vep = zT_815;
    zT_817 = "cannot declare variable of type void";
    zT_819 = 36;
    zT_818.ptr = zT_817;
    zT_818.len = zT_819;
    vv_msg = zT_818;
    zT_820 = self->diag;
    zT_823 = self->source_file_id;
    zT_824 = vsp;
    zT_825 = vep;
    zT_826 = vv_msg;
    zT_831 = zF_C82559AC_diagnosticCollector(zT_820, (unsigned char)(0), (unsigned short)(3000), zT_823, zT_824, zT_825, zT_826);
    (void)zT_831;
    goto z_bb_125;
    z_bb_125:
    zT_833 = self->coercion_table;
    zT_834 = node.child_1;
    zT_837 = zF_46B66789_coercionTableGet(zT_833, zT_834);
    ct_entry = zT_837;
    zT_838 = ct_entry.has_value;
    if ((unsigned char)(!zT_838)) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_840 = self->type_table;
    zT_841 = node.child_1;
    zT_842 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_840, zT_841, zT_842);
    goto z_bb_127;
    z_bb_127:
    goto z_bb_68;
    z_bb_128:
    zT_851 = node.child_1;
    zT_850 = zT_851 != (unsigned int)(0);
    goto z_bb_130;
    z_bb_129:
    zT_850 = 0;
    goto z_bb_130;
    z_bb_130:
    if (zT_850) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_854 = &self->local_consts;
    zT_858 = self->store;
    zT_859 = node_idx;
    zT_861 = zF_8BA26B9E_astStoreNodePayload(zT_858, zT_859);
    zT_855 = zT_861;
    zT_856 = node_idx;
    zF_DA915531_localConstScopePush(zT_854, zT_855, zT_856);
    goto z_bb_132;
    z_bb_132:
    zT_862 = self->local_decl_count;
    zT_863 = self->local_decl_cap;
    if ((unsigned char)(zT_862 >= zT_863)) goto z_bb_133; else goto z_bb_134;
    z_bb_133:
    zT_865 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_865);
    goto z_bb_134;
    z_bb_134:
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_869 = self->store;
    zT_870 = node_idx;
    zT_872 = zF_8BA26B9E_astStoreNodePayload(zT_869, zT_870);
    zT_873 = self->local_decl_names;
    zT_874 = self->local_decl_count;
    zT_873[zT_874] = zT_872;
    zT_875 = self->local_decl_types;
    zT_876 = self->local_decl_count;
    zT_875[zT_876] = decl_type;
    zT_877 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_877 + (unsigned int)(1));
    zT_881 = self->module_id;
    zT_885 = self->store;
    zT_886 = node_idx;
    zT_888 = zF_8BA26B9E_astStoreNodePayload(zT_885, zT_886);
    zT_890 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_881) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_888);
    ck_1 = zT_890;
    zT_891 = self->registry;
    zT_892 = ck_1;
    zT_893 = decl_type;
    zF_5E95558D_nameCachePut(zT_891, zT_892, zT_893);
    zT_896 = "REG:cp";
    zT_898 = 6;
    zT_897.ptr = zT_896;
    zT_897.len = zT_898;
    regcp_m = zT_897;
    zT_899 = regcp_m;
    zT_901 = self->store;
    zT_902 = node_idx;
    zT_904 = zF_8BA26B9E_astStoreNodePayload(zT_901, zT_902);
    zT_900 = zT_904;
    zF_C914CB83_markerWriteInt(zT_899, zT_900);
    zT_906 = "REG:ct";
    zT_908 = 6;
    zT_907.ptr = zT_906;
    zT_907.len = zT_908;
    regct_m = zT_907;
    zT_909 = regct_m;
    zT_910 = decl_type;
    zF_C914CB83_markerWriteInt(zT_909, zT_910);
    goto z_bb_136;
    z_bb_136:
    goto z_bb_59;
    z_bb_137:
    zT_915 = self;
    zT_916 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_915, zT_916);
    zT_917 = node.child_2;
    if ((unsigned char)(zT_917 != (unsigned int)(0))) goto z_bb_140; else goto z_bb_141;
    z_bb_138:
    goto z_bb_15;
    z_bb_139:
    zT_929 = node.kind;
    if ((unsigned char)(zT_929 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_144; else goto z_bb_146;
    z_bb_140:
    zT_920 = self;
    zT_921 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_920, zT_921);
    goto z_bb_141;
    z_bb_141:
    zT_923 = node.child_1;
    if ((unsigned char)(zT_923 != (unsigned int)(0))) goto z_bb_142; else goto z_bb_143;
    z_bb_142:
    zT_926 = self;
    zT_927 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_926, zT_927);
    goto z_bb_143;
    z_bb_143:
    goto z_bb_138;
    z_bb_144:
    zT_933 = self;
    zT_934 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_933, zT_934);
    zT_935 = node.child_1;
    if ((unsigned char)(zT_935 != (unsigned int)(0))) goto z_bb_147; else goto z_bb_148;
    z_bb_145:
    goto z_bb_138;
    z_bb_146:
    zT_941 = node.kind;
    if ((unsigned char)(zT_941 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_149; else goto z_bb_151;
    z_bb_147:
    zT_938 = self;
    zT_939 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_938, zT_939);
    goto z_bb_148;
    z_bb_148:
    goto z_bb_145;
    z_bb_149:
    zT_945 = self;
    zT_946 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_945, zT_946);
    zT_947 = node.child_1;
    if ((unsigned char)(zT_947 != (unsigned int)(0))) goto z_bb_152; else goto z_bb_153;
    z_bb_150:
    goto z_bb_145;
    z_bb_151:
    zT_953 = node.kind;
    if ((unsigned char)(zT_953 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_154; else goto z_bb_156;
    z_bb_152:
    zT_950 = self;
    zT_951 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_950, zT_951);
    goto z_bb_153;
    z_bb_153:
    goto z_bb_150;
    z_bb_154:
    zT_957 = self;
    zT_958 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_957, zT_958);
    goto z_bb_155;
    z_bb_155:
    goto z_bb_150;
    z_bb_156:
    zT_959 = node.kind;
    if ((unsigned char)(zT_959 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_158; else goto z_bb_157;
    z_bb_157:
    zT_964 = node.kind;
    zT_963 = zT_964 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_159;
    z_bb_158:
    zT_963 = 1;
    goto z_bb_159;
    z_bb_159:
    if (zT_963) goto z_bb_161; else goto z_bb_160;
    z_bb_160:
    zT_969 = node.kind;
    zT_968 = zT_969 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_162;
    z_bb_161:
    zT_968 = 1;
    goto z_bb_162;
    z_bb_162:
    if (zT_968) goto z_bb_164; else goto z_bb_163;
    z_bb_163:
    zT_974 = node.kind;
    zT_973 = zT_974 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_165;
    z_bb_164:
    zT_973 = 1;
    goto z_bb_165;
    z_bb_165:
    if (zT_973) goto z_bb_167; else goto z_bb_166;
    z_bb_166:
    zT_979 = node.kind;
    zT_978 = zT_979 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_168;
    z_bb_167:
    zT_978 = 1;
    goto z_bb_168;
    z_bb_168:
    if (zT_978) goto z_bb_170; else goto z_bb_169;
    z_bb_169:
    zT_984 = node.kind;
    zT_983 = zT_984 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_171;
    z_bb_170:
    zT_983 = 1;
    goto z_bb_171;
    z_bb_171:
    if (zT_983) goto z_bb_173; else goto z_bb_172;
    z_bb_172:
    zT_989 = node.kind;
    zT_988 = zT_989 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_174;
    z_bb_173:
    zT_988 = 1;
    goto z_bb_174;
    z_bb_174:
    if (zT_988) goto z_bb_176; else goto z_bb_175;
    z_bb_175:
    zT_994 = node.kind;
    zT_993 = zT_994 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_177;
    z_bb_176:
    zT_993 = 1;
    goto z_bb_177;
    z_bb_177:
    if (zT_993) goto z_bb_179; else goto z_bb_178;
    z_bb_178:
    zT_999 = node.kind;
    zT_998 = zT_999 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_180;
    z_bb_179:
    zT_998 = 1;
    goto z_bb_180;
    z_bb_180:
    if (zT_998) goto z_bb_182; else goto z_bb_181;
    z_bb_181:
    zT_1004 = node.kind;
    zT_1003 = zT_1004 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_183;
    z_bb_182:
    zT_1003 = 1;
    goto z_bb_183;
    z_bb_183:
    if (zT_1003) goto z_bb_185; else goto z_bb_184;
    z_bb_184:
    zT_1009 = node.kind;
    zT_1008 = zT_1009 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_186;
    z_bb_185:
    zT_1008 = 1;
    goto z_bb_186;
    z_bb_186:
    if (zT_1008) goto z_bb_188; else goto z_bb_187;
    z_bb_187:
    zT_1014 = node.kind;
    zT_1013 = zT_1014 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_189;
    z_bb_188:
    zT_1013 = 1;
    goto z_bb_189;
    z_bb_189:
    if (zT_1013) goto z_bb_191; else goto z_bb_190;
    z_bb_190:
    zT_1019 = node.kind;
    zT_1018 = zT_1019 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_192;
    z_bb_191:
    zT_1018 = 1;
    goto z_bb_192;
    z_bb_192:
    if (zT_1018) goto z_bb_194; else goto z_bb_193;
    z_bb_193:
    zT_1024 = node.kind;
    zT_1023 = zT_1024 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_195;
    z_bb_194:
    zT_1023 = 1;
    goto z_bb_195;
    z_bb_195:
    if (zT_1023) goto z_bb_197; else goto z_bb_196;
    z_bb_196:
    zT_1029 = node.kind;
    zT_1028 = zT_1029 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_198;
    z_bb_197:
    zT_1028 = 1;
    goto z_bb_198;
    z_bb_198:
    if (zT_1028) goto z_bb_200; else goto z_bb_199;
    z_bb_199:
    zT_1034 = node.kind;
    zT_1033 = zT_1034 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_201;
    z_bb_200:
    zT_1033 = 1;
    goto z_bb_201;
    z_bb_201:
    if (zT_1033) goto z_bb_203; else goto z_bb_202;
    z_bb_202:
    zT_1039 = node.kind;
    zT_1038 = zT_1039 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_204;
    z_bb_203:
    zT_1038 = 1;
    goto z_bb_204;
    z_bb_204:
    if (zT_1038) goto z_bb_206; else goto z_bb_205;
    z_bb_205:
    zT_1044 = node.kind;
    zT_1043 = zT_1044 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_207;
    z_bb_206:
    zT_1043 = 1;
    goto z_bb_207;
    z_bb_207:
    if (zT_1043) goto z_bb_208; else goto z_bb_210;
    z_bb_208:
    zT_1048 = self;
    zT_1049 = node_idx;
    zT_1050 = zF_54F95822_semanticAnalyzerRes(zT_1048, zT_1049);
    (void)zT_1050;
    goto z_bb_209;
    z_bb_209:
    goto z_bb_155;
    z_bb_210:
    zT_1051 = node.kind;
    if ((unsigned char)(zT_1051 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_211; else goto z_bb_213;
    z_bb_211:
    zT_1055 = node.child_0;
    if ((unsigned char)(zT_1055 != (unsigned int)(0))) goto z_bb_214; else goto z_bb_215;
    z_bb_212:
    goto z_bb_209;
    z_bb_213:
    zT_1061 = node.kind;
    if ((unsigned char)(zT_1061 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_217; else goto z_bb_216;
    z_bb_214:
    zT_1058 = self;
    zT_1059 = node.child_0;
    zF_7AB741D8_semanticAnalyzerStm(zT_1058, zT_1059);
    goto z_bb_215;
    z_bb_215:
    goto z_bb_212;
    z_bb_216:
    zT_1066 = node.kind;
    zT_1065 = zT_1066 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_218;
    z_bb_217:
    zT_1065 = 1;
    goto z_bb_218;
    z_bb_218:
    if (zT_1065) goto z_bb_219; else goto z_bb_221;
    z_bb_219:
    zT_1070 = node.child_0;
    if ((unsigned char)(zT_1070 != (unsigned int)(0))) goto z_bb_222; else goto z_bb_223;
    z_bb_220:
    goto z_bb_212;
    z_bb_221:
    zT_1091 = node.kind;
    if ((unsigned char)(zT_1091 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_224; else goto z_bb_226;
    z_bb_222:
    zT_1074 = self->defer_inner_loops;
    dc_saved_loops = zT_1074;
    zT_1076 = self->defer_label_len;
    dc_saved_len = zT_1076;
    self->defer_inner_loops = (unsigned int)(0);
    self->defer_label_len = (unsigned int)(0);
    zT_1079 = self;
    zT_1080 = node.child_0;
    zF_9E06A44F_semanticAnalyzerChe(zT_1079, zT_1080);
    self->defer_inner_loops = dc_saved_loops;
    self->defer_label_len = dc_saved_len;
    zT_1082 = self->defer_depth;
    self->defer_depth = (unsigned int)(zT_1082 + (unsigned int)(1));
    zT_1085 = self;
    zT_1086 = node.child_0;
    zF_10A0DC35_semanticAnalyzerRes(zT_1085, zT_1086);
    zT_1088 = self->defer_depth;
    self->defer_depth = (unsigned int)(zT_1088 - (unsigned int)(1));
    goto z_bb_223;
    z_bb_223:
    goto z_bb_220;
    z_bb_224:
    goto z_bb_225;
    z_bb_225:
    goto z_bb_220;
    z_bb_226:
    zT_1095 = node.kind;
    if ((unsigned char)(zT_1095 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt))) goto z_bb_227; else goto z_bb_229;
    z_bb_227:
    goto z_bb_228;
    z_bb_228:
    goto z_bb_225;
    z_bb_229:
    zT_1100 = "ELS:n";
    zT_1102 = 5;
    zT_1101.ptr = zT_1100;
    zT_1101.len = zT_1102;
    els_nm = zT_1101;
    zT_1103 = els_nm;
    zT_1104 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1103, zT_1104);
    zT_1106 = "ELS:k";
    zT_1108 = 5;
    zT_1107.ptr = zT_1106;
    zT_1107.len = zT_1108;
    els_km = zT_1107;
    zT_1109 = els_km;
    zT_1111 = node.kind;
    zF_C914CB83_markerWriteInt(zT_1109, (unsigned int)((unsigned int)zT_1111));
    zT_1113 = node.child_0;
    if ((unsigned char)(zT_1113 != (unsigned int)(0))) goto z_bb_230; else goto z_bb_231;
    z_bb_230:
    zT_1117 = "ELS:c";
    zT_1119 = 5;
    zT_1118.ptr = zT_1117;
    zT_1118.len = zT_1119;
    els_c0m = zT_1118;
    zT_1120 = els_c0m;
    zT_1121 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_1120, zT_1121);
    goto z_bb_231;
    z_bb_231:
    zT_1124 = self;
    zT_1125 = node_idx;
    zT_1126 = zF_54F95822_semanticAnalyzerRes(zT_1124, zT_1125);
    els_r = zT_1126;
    if ((unsigned char)(els_r != (unsigned int)(0))) goto z_bb_232; else goto z_bb_233;
    z_bb_232:
    zT_1131 = self->registry;
    zT_1132 = zT_1131->types_len;
    zT_1129 = (unsigned int)((unsigned int)els_r) < zT_1132;
    goto z_bb_234;
    z_bb_233:
    zT_1129 = 0;
    goto z_bb_234;
    z_bb_234:
    if (zT_1129) goto z_bb_235; else goto z_bb_236;
    z_bb_235:
    zT_1135 = self->registry;
    zT_1136 = zT_1135->types_items;
    zT_1137 = (unsigned int)els_r;
    zT_1138 = zT_1136[zT_1137];
    zT_1139 = zT_1138.kind;
    zT_1134 = zT_1139 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_237;
    z_bb_236:
    zT_1134 = 0;
    goto z_bb_237;
    z_bb_237:
    if (zT_1134) goto z_bb_238; else goto z_bb_239;
    z_bb_238:
    zT_1144 = node.span_start;
    eisp = zT_1144;
    zT_1146 = node.span_len;
    zT_1148 = eisp + (unsigned int)((unsigned int)zT_1146);
    eiep = zT_1148;
    zT_1150 = "error union result is ignored; use 'try', 'catch', or assign the result";
    zT_1152 = 71;
    zT_1151.ptr = zT_1150;
    zT_1151.len = zT_1152;
    ei_msg = zT_1151;
    zT_1153 = self->diag;
    zT_1156 = self->source_file_id;
    zT_1157 = eisp;
    zT_1158 = eiep;
    zT_1159 = ei_msg;
    zT_1166 = zF_C82559AC_diagnosticCollector(zT_1153, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3015_ERROR_IGNORED)), zT_1156, zT_1157, zT_1158, zT_1159);
    (void)zT_1166;
    goto z_bb_239;
    z_bb_239:
    goto z_bb_228;
    z_bb_240:
    zT_1171 = self->store;
    zT_1172 = node.child_0;
    zT_1175 = zF_FCDD1D35_astStoreNodeAt(zT_1171, zT_1172);
    nc = zT_1175;
    zT_1176 = nc.kind;
    if ((unsigned char)(zT_1176 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_242; else goto z_bb_243;
    z_bb_241:
    zT_1180 = node.child_1;
    if ((unsigned char)(zT_1180 != (unsigned int)(0))) goto z_bb_244; else goto z_bb_245;
    z_bb_242:
    goto z_bb_4;
    z_bb_243:
    goto z_bb_241;
    z_bb_244:
    zT_1184 = self->store;
    zT_1185 = node.child_1;
    zT_1188 = zF_FCDD1D35_astStoreNodeAt(zT_1184, zT_1185);
    nc = zT_1188;
    zT_1189 = nc.kind;
    if ((unsigned char)(zT_1189 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_246; else goto z_bb_247;
    z_bb_245:
    goto z_bb_4;
    z_bb_246:
    goto z_bb_4;
    z_bb_247:
    goto z_bb_245;
}

/* semaTraceStep */
unsigned int zF_DE5079F2_semaTraceStep(zT_38C12417_SemanticAnalyzer* self, unsigned int* cur_name, unsigned char* done) {
    zT_3D7259E2_SymbolRegistry* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_5D7DACC8_Opt_861 zT_10 = {0};
    unsigned char zT_11;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    zT_8143F551_AstKind zT_24;
    unsigned int zT_30;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    zT_22A7C88B_AstNode zT_57 = {0};
    zT_8143F551_AstKind zT_58;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    unsigned int zT_69 = 0;
    zT_5D7DACC8_Opt_861 ss;
    zT_3A105EF1_Symbol* s;
    zT_22A7C88B_AstNode dn;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode c0;
    unsigned int nn;
    zT_4 = self->symbols;
    zT_5 = self->module_id;
    zT_6 = *cur_name;
    zT_10 = zF_A398987E_symbolRegistryQuali(zT_4, zT_5, zT_6);
    ss = zT_10;
    zT_11 = ss.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s = ss.value;
    zT_13 = s->decl_node;
    if ((unsigned char)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_3:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_4:
    zT_19 = self->store;
    zT_20 = s->decl_node;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    dn = zT_23;
    zT_24 = dn.kind;
    if ((unsigned char)(zT_24 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_6:
    zT_30 = dn.child_1;
    if ((unsigned char)(zT_30 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_8:
    zT_36 = self->store;
    zT_37 = dn.child_1;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    init = zT_40;
    zT_41 = init.kind;
    if ((unsigned char)(zT_41 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_10:
    zT_47 = init.child_0;
    if ((unsigned char)(zT_47 == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_12:
    zT_53 = self->store;
    zT_54 = init.child_0;
    zT_57 = zF_FCDD1D35_astStoreNodeAt(zT_53, zT_54);
    c0 = zT_57;
    zT_58 = c0.kind;
    if ((unsigned char)(zT_58 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_14:
    zT_65 = self->store;
    zT_66 = init.child_0;
    zT_69 = zF_53458827_astStoreIdentifier(zT_65, zT_66);
    nn = zT_69;
    *cur_name = nn;
    return nn;
}

/* semanticAnalyzerResolveIndexAccess */
unsigned int zF_1926BC05_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    unsigned int zT_14;
    zT_38C12417_SemanticAnalyzer* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    zT_38C12417_SemanticAnalyzer* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_28 = {0};
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8143F551_AstKind zT_35;
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_46 = 0;
    unsigned char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned char zT_59;
    unsigned char zT_62;
    zT_38C12417_SemanticAnalyzer* zT_65;
    unsigned int* zT_66;
    unsigned char* zT_67;
    unsigned int zT_70 = 0;
    unsigned int zT_72;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zT_8EED1867_ResolvedTypeTable* zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_97;
    unsigned int zT_99;
    unsigned char zT_102;
    unsigned int zT_103;
    zT_8EED1867_ResolvedTypeTable* zT_106;
    unsigned int zT_107;
    zT_338B7C76_TypeRegistry* zT_113;
    zT_D155D06D_Type* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_D155D06D_Type zT_117;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    unsigned int zT_123 = 0;
    unsigned char* zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_33EF6BFB_TypeKind zT_132;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_666DC2E1_TuplePayload* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_666DC2E1_TuplePayload zT_141;
    zT_338B7C76_TypeRegistry* zT_143;
    unsigned int* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned char* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    unsigned char zT_155;
    zT_33EF6BFB_TypeKind zT_156;
    unsigned char zT_160;
    zT_33EF6BFB_TypeKind zT_161;
    unsigned char zT_165;
    zT_33EF6BFB_TypeKind zT_166;
    unsigned char zT_170;
    zT_33EF6BFB_TypeKind zT_171;
    unsigned char zT_175;
    zT_33EF6BFB_TypeKind zT_176;
    unsigned char zT_180;
    zT_33EF6BFB_TypeKind zT_181;
    unsigned char zT_185;
    zT_33EF6BFB_TypeKind zT_186;
    unsigned char zT_190;
    zT_33EF6BFB_TypeKind zT_191;
    unsigned char zT_195;
    zT_33EF6BFB_TypeKind zT_196;
    unsigned char zT_200;
    zT_33EF6BFB_TypeKind zT_201;
    unsigned char zT_205;
    zT_33EF6BFB_TypeKind zT_206;
    unsigned char zT_210;
    zT_33EF6BFB_TypeKind zT_211;
    unsigned char zT_215;
    zT_33EF6BFB_TypeKind zT_216;
    unsigned char zT_220;
    zT_33EF6BFB_TypeKind zT_221;
    unsigned char zT_225;
    zT_33EF6BFB_TypeKind zT_226;
    unsigned char zT_230;
    zT_33EF6BFB_TypeKind zT_231;
    unsigned char zT_235;
    zT_33EF6BFB_TypeKind zT_236;
    unsigned char zT_240;
    zT_33EF6BFB_TypeKind zT_241;
    unsigned char zT_245;
    zT_33EF6BFB_TypeKind zT_246;
    unsigned char zT_250;
    zT_33EF6BFB_TypeKind zT_251;
    unsigned char zT_255;
    zT_33EF6BFB_TypeKind zT_256;
    unsigned char zT_260;
    zT_33EF6BFB_TypeKind zT_261;
    unsigned char zT_265;
    zT_33EF6BFB_TypeKind zT_266;
    unsigned char zT_270;
    zT_33EF6BFB_TypeKind zT_271;
    unsigned char zT_275;
    zT_33EF6BFB_TypeKind zT_276;
    unsigned char zT_280;
    zT_33EF6BFB_TypeKind zT_281;
    unsigned char zT_285;
    zT_33EF6BFB_TypeKind zT_286;
    unsigned char zT_290;
    unsigned char* zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned int zT_296;
    zT_F85C5DED_DiagnosticCollector* zT_297;
    unsigned int zT_300;
    unsigned int zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned int zT_309;
    unsigned int zT_310;
    unsigned int zT_313 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_314;
    unsigned int zT_315;
    unsigned int zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixa_m;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_22A7C88B_AstNode c0_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u c0k_m;
    unsigned int c0_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ste_m;
    unsigned int src_cur_name;
    unsigned int src_depth;
    unsigned int src_name;
    unsigned char src_done;
    zT_8F083A69_Slice_zT_0B42B2F8_u ix_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_s;
    zT_D155D06D_Type bt;
    unsigned int ix_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixr_m;
    unsigned char nidx_bad;
    zT_666DC2E1_TuplePayload tp;
    unsigned int r4;
    zT_8F083A69_Slice_zT_0B42B2F8_u nidx_msg;
    unsigned int ret;
    zT_3 = "IXA:N";
    zT_5 = 5;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ixa_m = zT_4;
    zT_6 = ixa_m;
    zT_7 = node_idx;
    zF_C914CB83_markerWriteInt(zT_6, zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = self->_stub_0;
    saved = zT_14;
    zT_15 = self;
    zT_16 = node.child_1;
    zT_18 = zF_54F95822_semanticAnalyzerRes(zT_15, zT_16);
    (void)zT_18;
    zT_19 = self;
    zT_20 = node.child_0;
    zT_22 = zF_54F95822_semanticAnalyzerRes(zT_19, zT_20);
    self->_stub_0 = zT_22;
    zT_24 = self->store;
    zT_25 = node.child_0;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    c0_node = zT_28;
    zT_30 = "C0K:K";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    c0k_m = zT_31;
    zT_33 = c0k_m;
    zT_35 = c0_node.kind;
    zF_C914CB83_markerWriteInt(zT_33, (unsigned int)((unsigned int)zT_35));
    zT_37 = c0_node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_42 = self->store;
    zT_43 = node.child_0;
    zT_46 = zF_53458827_astStoreIdentifier(zT_42, zT_43);
    c0_name_id = zT_46;
    zT_48 = "STE:N";
    zT_50 = 5;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    ste_m = zT_49;
    zT_51 = ste_m;
    zT_52 = node_idx;
    zF_C914CB83_markerWriteInt(zT_51, zT_52);
    src_cur_name = c0_name_id;
    zT_55 = 0;
    src_depth = zT_55;
    zT_57 = 0;
    src_name = zT_57;
    zT_59 = 0;
    src_done = zT_59;
    goto z_bb_3;
    z_bb_2:
    zT_93 = "IX:T";
    zT_95 = 4;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    ix_m = zT_94;
    zT_96 = ix_m;
    zT_97 = self->_stub_0;
    zF_C914CB83_markerWriteInt(zT_96, zT_97);
    zT_99 = self->_stub_0;
    if ((unsigned char)(zT_99 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_12;
    z_bb_3:
    if ((unsigned char)(src_done == (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_65 = self;
    zT_66 = &src_cur_name;
    zT_67 = &src_done;
    zT_70 = zF_DE5079F2_semaTraceStep(zT_65, zT_66, zT_67);
    src_name = zT_70;
    goto z_bb_6;
    z_bb_5:
    if ((unsigned char)(src_name != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_6:
    zT_72 = src_depth + (unsigned int)(1);
    src_depth = zT_72;
    goto z_bb_3;
    z_bb_7:
    zT_62 = src_depth < (unsigned int)(3);
    goto z_bb_9;
    z_bb_8:
    zT_62 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_62) goto z_bb_4; else goto z_bb_5;
    z_bb_10:
    zT_76 = "SRC:N";
    zT_78 = 5;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    srs_n = zT_77;
    zT_79 = srs_n;
    zT_80 = node_idx;
    zF_C914CB83_markerWriteInt(zT_79, zT_80);
    zT_82 = "SRC:S";
    zT_84 = 5;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    srs_s = zT_83;
    zT_85 = srs_s;
    zT_86 = src_name;
    zF_C914CB83_markerWriteInt(zT_85, zT_86);
    zT_87 = self->type_table;
    zT_88 = node.child_0;
    zT_89 = src_name;
    zF_D976B454_resolvedSourceTable(zT_87, zT_88, zT_89);
    (void)self;
    goto z_bb_11;
    z_bb_11:
    goto z_bb_2;
    z_bb_12:
    zT_103 = self->_stub_0;
    zT_102 = zT_103 == (unsigned int)(1);
    goto z_bb_14;
    z_bb_13:
    zT_102 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_102) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    self->_stub_0 = saved;
    zT_106 = self->type_table;
    zT_107 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_106, zT_107, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_16:
    zT_113 = self->registry;
    zT_114 = zT_113->types_items;
    zT_115 = self->_stub_0;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zT_114[zT_116];
    bt = zT_117;
    zT_119 = self->registry;
    zT_120 = self->_stub_0;
    zT_123 = zF_E02A7BC0_typeRegistryIndexed(zT_119, zT_120);
    ix_elem = zT_123;
    if ((unsigned char)(ix_elem != (unsigned int)(18))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_127 = "IX:R";
    zT_129 = 4;
    zT_128.ptr = zT_127;
    zT_128.len = zT_129;
    ixr_m = zT_128;
    zT_130 = ixr_m;
    zT_131 = ix_elem;
    zF_C914CB83_markerWriteInt(zT_130, zT_131);
    self->_stub_0 = saved;
    return ix_elem;
    z_bb_18:
    zT_155 = 0;
    nidx_bad = zT_155;
    zT_156 = bt.kind;
    if ((unsigned char)(zT_156 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_19:
    zT_132 = bt.kind;
    if ((unsigned char)(zT_132 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_137 = self->registry;
    zT_138 = zT_137->tup_items;
    zT_139 = bt.payload_idx;
    zT_140 = (unsigned int)zT_139;
    zT_141 = zT_138[zT_140];
    tp = zT_141;
    zT_143 = self->registry;
    zT_144 = zT_143->xt_items;
    zT_145 = tp.elems_start;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zT_144[zT_146];
    r4 = zT_147;
    zT_149 = "IX:R";
    zT_151 = 4;
    zT_150.ptr = zT_149;
    zT_150.len = zT_151;
    ixr_m = zT_150;
    zT_152 = ixr_m;
    zT_153 = r4;
    zF_C914CB83_markerWriteInt(zT_152, zT_153);
    self->_stub_0 = saved;
    return r4;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_161 = bt.kind;
    zT_160 = zT_161 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type);
    goto z_bb_24;
    z_bb_23:
    zT_160 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_160) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_166 = bt.kind;
    zT_165 = zT_166 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_27;
    z_bb_26:
    zT_165 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_165) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_171 = bt.kind;
    zT_170 = zT_171 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_30;
    z_bb_29:
    zT_170 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_170) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_176 = bt.kind;
    zT_175 = zT_176 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_33;
    z_bb_32:
    zT_175 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_175) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_181 = bt.kind;
    zT_180 = zT_181 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_36;
    z_bb_35:
    zT_180 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_180) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_186 = bt.kind;
    zT_185 = zT_186 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_39;
    z_bb_38:
    zT_185 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_185) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_191 = bt.kind;
    zT_190 = zT_191 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_42;
    z_bb_41:
    zT_190 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_190) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_196 = bt.kind;
    zT_195 = zT_196 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_45;
    z_bb_44:
    zT_195 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_195) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_201 = bt.kind;
    zT_200 = zT_201 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_48;
    z_bb_47:
    zT_200 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_200) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_206 = bt.kind;
    zT_205 = zT_206 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_51;
    z_bb_50:
    zT_205 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_205) goto z_bb_53; else goto z_bb_52;
    z_bb_52:
    zT_211 = bt.kind;
    zT_210 = zT_211 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_54;
    z_bb_53:
    zT_210 = 1;
    goto z_bb_54;
    z_bb_54:
    if (zT_210) goto z_bb_56; else goto z_bb_55;
    z_bb_55:
    zT_216 = bt.kind;
    zT_215 = zT_216 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type);
    goto z_bb_57;
    z_bb_56:
    zT_215 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_215) goto z_bb_59; else goto z_bb_58;
    z_bb_58:
    zT_221 = bt.kind;
    zT_220 = zT_221 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_60;
    z_bb_59:
    zT_220 = 1;
    goto z_bb_60;
    z_bb_60:
    if (zT_220) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_226 = bt.kind;
    zT_225 = zT_226 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_63;
    z_bb_62:
    zT_225 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_225) goto z_bb_65; else goto z_bb_64;
    z_bb_64:
    zT_231 = bt.kind;
    zT_230 = zT_231 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_66;
    z_bb_65:
    zT_230 = 1;
    goto z_bb_66;
    z_bb_66:
    if (zT_230) goto z_bb_68; else goto z_bb_67;
    z_bb_67:
    zT_236 = bt.kind;
    zT_235 = zT_236 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_69;
    z_bb_68:
    zT_235 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_235) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_241 = bt.kind;
    zT_240 = zT_241 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_72;
    z_bb_71:
    zT_240 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_240) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_246 = bt.kind;
    zT_245 = zT_246 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_75;
    z_bb_74:
    zT_245 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_245) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_251 = bt.kind;
    zT_250 = zT_251 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_78;
    z_bb_77:
    zT_250 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_250) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_256 = bt.kind;
    zT_255 = zT_256 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_81;
    z_bb_80:
    zT_255 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_255) goto z_bb_83; else goto z_bb_82;
    z_bb_82:
    zT_261 = bt.kind;
    zT_260 = zT_261 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_84;
    z_bb_83:
    zT_260 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_260) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_266 = bt.kind;
    zT_265 = zT_266 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_87;
    z_bb_86:
    zT_265 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_265) goto z_bb_89; else goto z_bb_88;
    z_bb_88:
    zT_271 = bt.kind;
    zT_270 = zT_271 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_90;
    z_bb_89:
    zT_270 = 1;
    goto z_bb_90;
    z_bb_90:
    if (zT_270) goto z_bb_92; else goto z_bb_91;
    z_bb_91:
    zT_276 = bt.kind;
    zT_275 = zT_276 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_93;
    z_bb_92:
    zT_275 = 1;
    goto z_bb_93;
    z_bb_93:
    if (zT_275) goto z_bb_95; else goto z_bb_94;
    z_bb_94:
    zT_281 = bt.kind;
    zT_280 = zT_281 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type);
    goto z_bb_96;
    z_bb_95:
    zT_280 = 1;
    goto z_bb_96;
    z_bb_96:
    if (zT_280) goto z_bb_98; else goto z_bb_97;
    z_bb_97:
    zT_286 = bt.kind;
    zT_285 = zT_286 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_99;
    z_bb_98:
    zT_285 = 1;
    goto z_bb_99;
    z_bb_99:
    if (zT_285) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_290 = 1;
    nidx_bad = zT_290;
    goto z_bb_101;
    z_bb_101:
    if ((unsigned char)(nidx_bad != (unsigned char)(0))) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_294 = "cannot index a value of non-array, non-pointer type";
    zT_296 = 51;
    zT_295.ptr = zT_294;
    zT_295.len = zT_296;
    nidx_msg = zT_295;
    zT_297 = self->diag;
    zT_300 = self->source_file_id;
    zT_301 = node.span_start;
    zT_309 = node.span_start;
    zT_310 = node.span_len;
    zT_303 = nidx_msg;
    zT_313 = zF_C82559AC_diagnosticCollector(zT_297, (unsigned char)(0), (unsigned short)(3000), zT_300, zT_301, (unsigned int)(zT_309 + (unsigned int)((unsigned int)zT_310)), zT_303);
    (void)zT_313;
    self->_stub_0 = saved;
    zT_314 = self->type_table;
    zT_315 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_314, zT_315, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_103:
    zT_321 = self->_stub_0;
    ret = zT_321;
    self->_stub_0 = saved;
    return ret;
}

/* semanticAnalyzerResolveSliceExpr */
unsigned int zF_F902E73E_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    unsigned int zT_13;
    zT_38C12417_SemanticAnalyzer* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    unsigned int zT_20;
    zT_38C12417_SemanticAnalyzer* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    unsigned char zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_D155D06D_Type zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    unsigned char zT_45;
    zT_33EF6BFB_TypeKind zT_46;
    unsigned char zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_76 = 0;
    zT_338B7C76_TypeRegistry* zT_80;
    unsigned int zT_81;
    unsigned int zT_84 = 0;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned char zT_93;
    zT_33EF6BFB_TypeKind zT_94;
    unsigned char zT_98;
    zT_33EF6BFB_TypeKind zT_99;
    unsigned char zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    unsigned char zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    unsigned char zT_113;
    unsigned char zT_118;
    zT_338B7C76_TypeRegistry* zT_120;
    unsigned int zT_121;
    unsigned char zT_122;
    unsigned int zT_125 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_D155D06D_Type bt;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl_msg;
    unsigned int ix_elem2;
    unsigned char se_is_const;
    unsigned int ret;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    self->_stub_0 = zT_12;
    zT_13 = node.child_1;
    if ((unsigned char)(zT_13 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self;
    zT_17 = node.child_1;
    zT_19 = zF_54F95822_semanticAnalyzerRes(zT_16, zT_17);
    (void)zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_20 = node.child_2;
    if ((unsigned char)(zT_20 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_23 = self;
    zT_24 = node.child_2;
    zT_26 = zF_54F95822_semanticAnalyzerRes(zT_23, zT_24);
    (void)zT_26;
    goto z_bb_4;
    z_bb_4:
    zT_27 = self->_stub_0;
    if ((unsigned char)(zT_27 == (unsigned int)(0))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_31 = self->_stub_0;
    zT_30 = zT_31 == (unsigned int)(1);
    goto z_bb_7;
    z_bb_6:
    zT_30 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_9:
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_38 = self->_stub_0;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    bt = zT_40;
    zT_41 = bt.kind;
    if ((unsigned char)(zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_46 = bt.kind;
    zT_45 = zT_46 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_12;
    z_bb_11:
    zT_45 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_45) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_51 = bt.kind;
    zT_50 = zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_15;
    z_bb_14:
    zT_50 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_50) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_56 = bt.kind;
    zT_55 = zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_18;
    z_bb_17:
    zT_55 = 1;
    goto z_bb_18;
    z_bb_18:
    if ((unsigned char)(!zT_55)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_62 = "cannot slice base type: expected array, slice, or many-pointer";
    zT_64 = 62;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    sl_msg = zT_63;
    zT_65 = self->diag;
    zT_68 = self->source_file_id;
    zT_69 = node_idx;
    zT_70 = node_idx;
    zT_71 = sl_msg;
    zT_76 = zF_C82559AC_diagnosticCollector(zT_65, (unsigned char)(0), (unsigned short)(2000), zT_68, zT_69, zT_70, zT_71);
    (void)zT_76;
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_20:
    self->_stub_1 = (unsigned int)(1);
    zT_80 = self->registry;
    zT_81 = self->_stub_0;
    zT_84 = zF_E02A7BC0_typeRegistryIndexed(zT_80, zT_81);
    ix_elem2 = zT_84;
    if ((unsigned char)(ix_elem2 != (unsigned int)(18))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    self->_stub_1 = ix_elem2;
    goto z_bb_22;
    z_bb_22:
    zT_88 = self->_stub_1;
    if ((unsigned char)(zT_88 == (unsigned int)(1))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_87 = self->_stub_0;
    self->_stub_1 = zT_87;
    goto z_bb_22;
    z_bb_24:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_25:
    zT_93 = 0;
    se_is_const = zT_93;
    zT_94 = bt.kind;
    if ((unsigned char)(zT_94 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_99 = bt.kind;
    zT_98 = zT_99 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_28;
    z_bb_27:
    zT_98 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_98) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_104 = bt.kind;
    zT_103 = zT_104 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_31;
    z_bb_30:
    zT_103 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_103) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_109 = bt.kind;
    zT_108 = zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_34;
    z_bb_33:
    zT_108 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_108) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_113 = bt.flags;
    if ((unsigned char)((unsigned char)(zT_113 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_120 = self->registry;
    zT_121 = self->_stub_1;
    zT_122 = se_is_const;
    zT_125 = zF_8FC81A87_typeRegistryGetOrCr(zT_120, zT_121, zT_122);
    ret = zT_125;
    self->_stub_0 = saved;
    return ret;
    z_bb_37:
    zT_118 = 1;
    se_is_const = zT_118;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_36;
}

/* semanticAnalyzerResolveTupleLiteral */
unsigned int zF_227D2404_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    unsigned int zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    int zT_23;
    unsigned int zT_24;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    unsigned int zT_33 = 0;
    unsigned int zT_34 = 0;
    unsigned int zT_35;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    unsigned int zT_44;
    zT_338B7C76_TypeRegistry* zT_45;
    unsigned int zT_46;
    unsigned int zT_50 = 0;
    unsigned int saved;
    unsigned int ec_n;
    unsigned int start;
    unsigned int i;
    zT_3 = self->store;
    zT_4 = node_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_152E19CB_astStoreNodeExtraCh(zT_10, zT_11);
    zT_14 = (unsigned int)zT_13;
    ec_n = zT_14;
    if ((unsigned char)(ec_n == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_2:
    zT_19 = self->registry;
    zT_20 = zT_19->xt_len;
    zT_21 = (unsigned int)zT_20;
    start = zT_21;
    zT_23 = 0;
    zT_24 = (unsigned int)zT_23;
    i = zT_24;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < ec_n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_26 = self;
    zT_28 = self->store;
    zT_29 = node_idx;
    zT_33 = zF_B10B1BC1_astStoreNodeExtraCh(zT_28, zT_29, (unsigned int)((unsigned int)i));
    zT_27 = zT_33;
    zT_34 = zF_54F95822_semanticAnalyzerRes(zT_26, zT_27);
    self->_stub_0 = zT_34;
    zT_35 = self->_stub_0;
    if ((unsigned char)(zT_35 == (unsigned int)(1))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    self->_stub_0 = saved;
    zT_45 = self->registry;
    zT_46 = start;
    zT_50 = zF_9996320F_typeRegistryGetOrCr(zT_45, zT_46, (unsigned short)((unsigned short)ec_n));
    return zT_50;
    z_bb_6:
    zT_44 = i + (unsigned int)(1);
    i = zT_44;
    goto z_bb_3;
    z_bb_7:
    self->_stub_0 = (unsigned int)(6);
    goto z_bb_8;
    z_bb_8:
    zT_39 = self->registry;
    zT_40 = self->_stub_0;
    zF_4C03AE3D_xtAppend(zT_39, zT_40);
    goto z_bb_6;
}

/* semanticAnalyzerResolveArrayInit */
unsigned int zF_F3DAABE0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    zT_ABC1EBBE_TypeResolveEnv zT_49;
    zT_6B0A7D14_AstStore* zT_50;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_3D7259E2_SymbolRegistry* zT_52;
    zT_D3EB6303_StringInterner* zT_53;
    unsigned int zT_54;
    zT_F85C5DED_DiagnosticCollector* zT_55;
    zT_7234F36B_Opt_226 zT_56;
    zT_E2DF2801_LocalConstScope* zT_57;
    zT_F5B966E3_Opt_396 zT_58;
    zT_C8A278E4_LocalTypeScope* zT_59;
    zT_03B97CED_Opt_398 zT_60;
    unsigned int zT_61;
    zT_ABC1EBBE_TypeResolveEnv* zT_63;
    unsigned int zT_64;
    unsigned int zT_69 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_D155D06D_Type* zT_75;
    unsigned int zT_76;
    zT_D155D06D_Type zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_8EED1867_ResolvedTypeTable* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    zT_22A7C88B_AstNode zT_95 = {0};
    unsigned char zT_97;
    zT_8143F551_AstKind zT_98;
    unsigned char zT_102;
    unsigned int zT_103;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    zT_22A7C88B_AstNode zT_111 = {0};
    zT_8143F551_AstKind zT_112;
    zT_6B0A7D14_AstStore* zT_117;
    unsigned int zT_118;
    unsigned int zT_121 = 0;
    zT_D3EB6303_StringInterner* zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126 = {0};
    unsigned int zT_128;
    unsigned char zT_131;
    unsigned char* zT_132;
    int zT_133;
    unsigned char zT_134;
    unsigned char zT_137;
    unsigned char zT_138;
    unsigned int zT_139;
    zT_ABC1EBBE_TypeResolveEnv zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_3D7259E2_SymbolRegistry* zT_146;
    zT_D3EB6303_StringInterner* zT_147;
    unsigned int zT_148;
    zT_F85C5DED_DiagnosticCollector* zT_149;
    zT_7234F36B_Opt_226 zT_150;
    zT_E2DF2801_LocalConstScope* zT_151;
    zT_F5B966E3_Opt_396 zT_152;
    zT_C8A278E4_LocalTypeScope* zT_153;
    zT_03B97CED_Opt_398 zT_154;
    unsigned int zT_155;
    zT_ABC1EBBE_TypeResolveEnv* zT_157;
    unsigned int zT_158;
    unsigned int zT_163 = 0;
    zT_6B0A7D14_AstStore* zT_168;
    unsigned int zT_169;
    unsigned int zT_171 = 0;
    unsigned int zT_172;
    unsigned int zT_181;
    unsigned char zT_186;
    zT_338B7C76_TypeRegistry* zT_190;
    unsigned int zT_191;
    unsigned int zT_193 = 0;
    unsigned int zT_195;
    zT_6B0A7D14_AstStore* zT_198;
    unsigned int zT_199;
    zT_6B0A7D14_AstStore* zT_201;
    unsigned int zT_202;
    unsigned int zT_206 = 0;
    zT_22A7C88B_AstNode zT_207 = {0};
    unsigned int zT_210;
    zT_8143F551_AstKind zT_211;
    unsigned int zT_215;
    zT_8143F551_AstKind zT_216;
    unsigned int zT_220;
    zT_38C12417_SemanticAnalyzer* zT_224;
    unsigned int zT_225;
    zT_38C12417_SemanticAnalyzer* zT_226;
    unsigned int zT_227;
    zT_6B0A7D14_AstStore* zT_228;
    unsigned int zT_229;
    unsigned int zT_233 = 0;
    unsigned int zT_234 = 0;
    zT_38C12417_SemanticAnalyzer* zT_238;
    unsigned int zT_245;
    zT_338B7C76_TypeRegistry* zT_252;
    unsigned int zT_253;
    unsigned int zT_257 = 0;
    zT_338B7C76_TypeRegistry* zT_259;
    unsigned int zT_260;
    unsigned int zT_264 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    unsigned int annot_tid;
    unsigned int annot_elem_tid;
    zT_BAEE192E_Opt_10 rt;
    unsigned int ec_n;
    unsigned int t;
    zT_D155D06D_Type tt;
    zT_22A7C88B_AstNode ann_kind_node;
    zT_ABC1EBBE_TypeResolveEnv tre_env0;
    unsigned int at0;
    zT_D155D06D_Type at0ty;
    zT_22A7C88B_AstNode annot_node;
    unsigned char inferred_len;
    zT_22A7C88B_AstNode sz_node;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int et;
    unsigned int arr_elem_tid;
    unsigned int elem_expected;
    unsigned int aei;
    zT_22A7C88B_AstNode el;
    unsigned int el_tid;
    unsigned int arr_tid;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_11 = 18;
    annot_tid = zT_11;
    zT_14 = 18;
    annot_elem_tid = zT_14;
    zT_15 = node.child_0;
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->type_table;
    zT_20 = node.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_168 = self->store;
    zT_169 = node_idx;
    zT_171 = zF_152E19CB_astStoreNodeExtraCh(zT_168, zT_169);
    zT_172 = (unsigned int)zT_171;
    ec_n = zT_172;
    if ((unsigned char)(ec_n == (unsigned int)(0))) goto z_bb_36; else goto z_bb_37;
    z_bb_3:
    t = rt.value;
    zT_27 = self->registry;
    zT_28 = zT_27->types_items;
    zT_29 = (unsigned int)t;
    zT_30 = zT_28[zT_29];
    tt = zT_30;
    zT_31 = tt.kind;
    if ((unsigned char)(zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(annot_tid == (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    annot_tid = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_39 = self->store;
    zT_40 = node.child_0;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_39, zT_40);
    ann_kind_node = zT_43;
    zT_44 = ann_kind_node.kind;
    if ((unsigned char)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(annot_tid == (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_9:
    zT_50 = self->store;
    zT_49.store = zT_50;
    zT_51 = self->registry;
    zT_49.typereg = zT_51;
    zT_52 = self->symbols;
    zT_49.symbol_reg = zT_52;
    zT_53 = self->interner;
    zT_49.interner = zT_53;
    zT_54 = self->module_id;
    zT_49.module_id = zT_54;
    zT_55 = self->diag;
    zT_56.has_value = 1;
    zT_56.value = zT_55;
    zT_49.diag = zT_56;
    zT_57 = &self->local_consts;
    zT_58.has_value = 1;
    zT_58.value = zT_57;
    zT_49.local_consts = zT_58;
    zT_59 = &self->local_types;
    zT_60.has_value = 1;
    zT_60.value = zT_59;
    zT_49.local_types = zT_60;
    zT_61 = self->source_file_id;
    zT_49.source_file_id = zT_61;
    tre_env0 = zT_49;
    zT_63 = &tre_env0;
    zT_64 = node.child_0;
    zT_69 = zF_F2107C15_resolveTypeExprFull(zT_63, zT_64, (unsigned int)(0));
    at0 = zT_69;
    if ((unsigned char)(at0 != (unsigned int)(18))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_74 = self->registry;
    zT_75 = zT_74->types_items;
    zT_76 = (unsigned int)at0;
    zT_77 = zT_75[zT_76];
    at0ty = zT_77;
    zT_78 = at0ty.kind;
    if ((unsigned char)(zT_78 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    annot_tid = at0;
    zT_82 = self->type_table;
    zT_83 = node.child_0;
    zT_84 = at0;
    zF_19B4A07D_resolvedTypeTableSe(zT_82, zT_83, zT_84);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_91 = self->store;
    zT_92 = node.child_0;
    zT_95 = zF_FCDD1D35_astStoreNodeAt(zT_91, zT_92);
    annot_node = zT_95;
    zT_97 = 0;
    inferred_len = zT_97;
    zT_98 = annot_node.kind;
    if ((unsigned char)(zT_98 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_2;
    z_bb_17:
    zT_103 = annot_node.child_1;
    zT_102 = zT_103 != (unsigned int)(0);
    goto z_bb_19;
    z_bb_18:
    zT_102 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_102) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_107 = self->store;
    zT_108 = annot_node.child_1;
    zT_111 = zF_FCDD1D35_astStoreNodeAt(zT_107, zT_108);
    sz_node = zT_111;
    zT_112 = sz_node.kind;
    if ((unsigned char)(zT_112 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    if (inferred_len) goto z_bb_29; else goto z_bb_30;
    z_bb_22:
    zT_117 = self->store;
    zT_118 = annot_node.child_1;
    zT_121 = zF_53458827_astStoreIdentifier(zT_117, zT_118);
    sz_name = zT_121;
    zT_123 = self->interner;
    zT_124 = sz_name;
    zT_126 = zF_9134020D_stringInternerGet(zT_123, zT_124);
    sz_text = zT_126;
    zT_128 = sz_text.len;
    if ((unsigned char)(zT_128 == (unsigned int)(1))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_132 = sz_text.ptr;
    zT_133 = 0;
    zT_134 = zT_132[zT_133];
    zT_131 = zT_134 == (unsigned char)(95);
    goto z_bb_26;
    z_bb_25:
    zT_131 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_131) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_137 = 1;
    inferred_len = zT_137;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_139 = annot_node.child_0;
    zT_138 = zT_139 != (unsigned int)(0);
    goto z_bb_31;
    z_bb_30:
    zT_138 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_138) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_144 = self->store;
    zT_143.store = zT_144;
    zT_145 = self->registry;
    zT_143.typereg = zT_145;
    zT_146 = self->symbols;
    zT_143.symbol_reg = zT_146;
    zT_147 = self->interner;
    zT_143.interner = zT_147;
    zT_148 = self->module_id;
    zT_143.module_id = zT_148;
    zT_149 = self->diag;
    zT_150.has_value = 1;
    zT_150.value = zT_149;
    zT_143.diag = zT_150;
    zT_151 = &self->local_consts;
    zT_152.has_value = 1;
    zT_152.value = zT_151;
    zT_143.local_consts = zT_152;
    zT_153 = &self->local_types;
    zT_154.has_value = 1;
    zT_154.value = zT_153;
    zT_143.local_types = zT_154;
    zT_155 = self->source_file_id;
    zT_143.source_file_id = zT_155;
    tre_env = zT_143;
    zT_157 = &tre_env;
    zT_158 = annot_node.child_0;
    zT_163 = zF_F2107C15_resolveTypeExprFull(zT_157, zT_158, (unsigned int)(0));
    et = zT_163;
    if ((unsigned char)(et != (unsigned int)(18))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_16;
    z_bb_34:
    annot_elem_tid = et;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    self->_stub_0 = saved;
    if ((unsigned char)(annot_tid != (unsigned int)(18))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_181 = 1;
    arr_elem_tid = zT_181;
    elem_expected = annot_elem_tid;
    if ((unsigned char)(elem_expected == (unsigned int)(18))) goto z_bb_40; else goto z_bb_41;
    z_bb_38:
    return annot_tid;
    z_bb_39:
    return (unsigned int)(1);
    z_bb_40:
    zT_186 = annot_tid != (unsigned int)(18);
    goto z_bb_42;
    z_bb_41:
    zT_186 = 0;
    goto z_bb_42;
    z_bb_42:
    if (zT_186) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_190 = self->registry;
    zT_191 = annot_tid;
    zT_193 = zF_E02A7BC0_typeRegistryIndexed(zT_190, zT_191);
    elem_expected = zT_193;
    goto z_bb_44;
    z_bb_44:
    zT_195 = 0;
    aei = zT_195;
    goto z_bb_45;
    z_bb_45:
    if ((unsigned char)(aei < ec_n)) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_198 = self->store;
    zT_201 = self->store;
    zT_202 = node_idx;
    zT_206 = zF_B10B1BC1_astStoreNodeExtraCh(zT_201, zT_202, (unsigned int)((unsigned int)aei));
    zT_199 = zT_206;
    zT_207 = zF_FCDD1D35_astStoreNodeAt(zT_198, zT_199);
    el = zT_207;
    zT_210 = 1;
    el_tid = zT_210;
    zT_211 = el.kind;
    if ((unsigned char)(zT_211 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_49; else goto z_bb_51;
    z_bb_47:
    if ((unsigned char)(annot_tid != (unsigned int)(18))) goto z_bb_63; else goto z_bb_64;
    z_bb_48:
    zT_245 = aei + (unsigned int)(1);
    aei = zT_245;
    goto z_bb_45;
    z_bb_49:
    zT_215 = 8;
    el_tid = zT_215;
    goto z_bb_50;
    z_bb_50:
    if ((unsigned char)(el_tid == (unsigned int)(1))) goto z_bb_59; else goto z_bb_60;
    z_bb_51:
    zT_216 = el.kind;
    if ((unsigned char)(zT_216 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_52; else goto z_bb_54;
    z_bb_52:
    zT_220 = 10;
    el_tid = zT_220;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    if ((unsigned char)(elem_expected != (unsigned int)(18))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_224 = self;
    zT_225 = elem_expected;
    zF_9665A229_pushExpectedType(zT_224, zT_225);
    goto z_bb_56;
    z_bb_56:
    zT_226 = self;
    zT_228 = self->store;
    zT_229 = node_idx;
    zT_233 = zF_B10B1BC1_astStoreNodeExtraCh(zT_228, zT_229, (unsigned int)((unsigned int)aei));
    zT_227 = zT_233;
    zT_234 = zF_54F95822_semanticAnalyzerRes(zT_226, zT_227);
    el_tid = zT_234;
    if ((unsigned char)(elem_expected != (unsigned int)(18))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_238 = self;
    zF_BC478E78_popExpectedType(zT_238);
    goto z_bb_58;
    z_bb_58:
    goto z_bb_53;
    z_bb_59:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_60:
    if ((unsigned char)(aei == (unsigned int)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    arr_elem_tid = el_tid;
    goto z_bb_62;
    z_bb_62:
    goto z_bb_48;
    z_bb_63:
    self->_stub_0 = saved;
    return annot_tid;
    z_bb_64:
    if ((unsigned char)(annot_elem_tid != (unsigned int)(18))) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    self->_stub_0 = saved;
    zT_252 = self->registry;
    zT_253 = annot_elem_tid;
    zT_257 = zF_BA693C74_typeRegistryGetOrCr(zT_252, zT_253, (unsigned int)((unsigned int)ec_n));
    return zT_257;
    z_bb_66:
    zT_259 = self->registry;
    zT_260 = arr_elem_tid;
    zT_264 = zF_BA693C74_typeRegistryGetOrCr(zT_259, zT_260, (unsigned int)((unsigned int)ec_n));
    arr_tid = zT_264;
    self->_stub_0 = saved;
    return arr_tid;
}

/* semanticAnalyzerResolveStmt */
void zF_979B6CFF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_38C12417_SemanticAnalyzer* zT_2;
    unsigned int zT_3;
    zT_2 = self;
    zT_3 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_2, zT_3);
    return;
}

/* semanticAnalyzerResolveModuleVarDecl */
unsigned int zF_CC4377FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_38C12417_SemanticAnalyzer* zT_33;
    unsigned char zT_37;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_38C12417_SemanticAnalyzer* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_51 = 0;
    zT_338B7C76_TypeRegistry* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_0FB7FB13_CoercionKind zT_57 = 0;
    zT_66E7D2EF_CoercionTable* zT_61;
    unsigned int zT_62;
    zT_0FB7FB13_CoercionKind zT_63;
    unsigned int zT_64;
    zT_22A7C88B_AstNode decl;
    unsigned int decl_type;
    zT_BAEE192E_Opt_10 rt;
    unsigned int it;
    unsigned int t;
    unsigned int it_eff;
    zT_0FB7FB13_CoercionKind ck;
    zT_3 = self->store;
    zT_4 = decl_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    decl = zT_6;
    zT_7 = decl.child_1;
    if ((unsigned char)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_14 = 18;
    decl_type = zT_14;
    zT_15 = decl.child_0;
    if ((unsigned char)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = self->type_table;
    zT_20 = decl.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_26 = self;
    zT_27 = decl_type;
    zF_9665A229_pushExpectedType(zT_26, zT_27);
    zT_29 = self;
    zT_30 = decl.child_1;
    zT_32 = zF_54F95822_semanticAnalyzerRes(zT_29, zT_30);
    it = zT_32;
    zT_33 = self;
    zF_BC478E78_popExpectedType(zT_33);
    if ((unsigned char)(decl_type != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    t = rt.value;
    decl_type = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_37 = it != decl_type;
    goto z_bb_9;
    z_bb_8:
    zT_37 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_37) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_40 = self;
    zT_41 = decl.child_1;
    zT_42 = decl_type;
    zT_43 = it;
    zT_45 = zF_FFC95E09_errLitSrcType(zT_40, zT_41, zT_42, zT_43);
    it_eff = zT_45;
    zT_46 = self;
    zT_47 = decl.child_1;
    zT_48 = it_eff;
    zT_49 = decl_type;
    zT_51 = zF_86AAA417_semanticAnalyzerMay(zT_46, zT_47, zT_48, zT_49);
    if (zT_51) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return it;
    z_bb_12:
    return it;
    z_bb_13:
    zT_53 = self->registry;
    zT_54 = it_eff;
    zT_55 = decl_type;
    zT_57 = zF_713658BF_classifyCoercion(zT_53, zT_54, zT_55);
    ck = zT_57;
    if ((unsigned char)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_61 = self->coercion_table;
    zT_62 = decl.child_1;
    zT_63 = ck;
    zT_64 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_61, zT_62, zT_63, zT_64);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_11;
}

/* EOF */
