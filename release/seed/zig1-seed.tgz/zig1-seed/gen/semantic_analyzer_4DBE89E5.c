#include "semantic_analyzer_4DBE89E5.h"
/* semanticAnalyzerInit */
zT_38C12417_SemanticAnalyzer zF_84ADA681_semanticAnalyzerIni(zT_3E40CD83_Sand* alloc, zT_8EED1867_ResolvedTypeTable* type_table, zT_F85C5DED_DiagnosticCollector* diag, zT_338B7C76_TypeRegistry* registry, zT_3D7259E2_SymbolRegistry* symbols, zT_6B0A7D14_AstStore* store, unsigned int module_id, unsigned int source_file_id, zT_66E7D2EF_CoercionTable* coercion_tab, zT_21D3708C_U32ToU32Map* enum_val_tab, zT_21D3708C_U32ToU32Map* error_code_reg, zT_D3EB6303_StringInterner* interner, zT_21D3708C_U32ToU32Map* cal_typs, zT_21D3708C_U32ToU32Map* cp_map, zT_072B53A6_ModuleRegistry* module_reg, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_D3EB6303_StringInterner* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23 = 0;
    char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31 = 0;
    char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39 = 0;
    char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_D3EB6303_StringInterner* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_D3EB6303_StringInterner* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63 = 0;
    char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71 = 0;
    char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_D3EB6303_StringInterner* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79 = 0;
    char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_D3EB6303_StringInterner* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_D3EB6303_StringInterner* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95 = 0;
    char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_D3EB6303_StringInterner* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_D3EB6303_StringInterner* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111 = 0;
    char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_D3EB6303_StringInterner* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119 = 0;
    char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_D3EB6303_StringInterner* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127 = 0;
    char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_D3EB6303_StringInterner* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135 = 0;
    char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_D3EB6303_StringInterner* zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned int zT_143 = 0;
    char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_D3EB6303_StringInterner* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151 = 0;
    char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_D3EB6303_StringInterner* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159 = 0;
    char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_D3EB6303_StringInterner* zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167 = 0;
    char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_D3EB6303_StringInterner* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175 = 0;
    char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_D3EB6303_StringInterner* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183 = 0;
    char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_D3EB6303_StringInterner* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191 = 0;
    char* zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    zT_D3EB6303_StringInterner* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199 = 0;
    char* zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    zT_D3EB6303_StringInterner* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207 = 0;
    char* zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    zT_D3EB6303_StringInterner* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215 = 0;
    char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_D3EB6303_StringInterner* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned int zT_223 = 0;
    char* zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_D3EB6303_StringInterner* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    unsigned int zT_231 = 0;
    char* zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    zT_D3EB6303_StringInterner* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239 = 0;
    char* zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243;
    zT_D3EB6303_StringInterner* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247 = 0;
    char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_D3EB6303_StringInterner* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255 = 0;
    char* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_259;
    zT_D3EB6303_StringInterner* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263 = 0;
    char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_D3EB6303_StringInterner* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned int zT_271 = 0;
    char* zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_D3EB6303_StringInterner* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned int zT_279 = 0;
    char* zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    zT_D3EB6303_StringInterner* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287 = 0;
    char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_D3EB6303_StringInterner* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned int zT_295 = 0;
    zT_38C12417_SemanticAnalyzer zT_296;
    int zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    int zT_308;
    int zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    int zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    int zT_315;
    int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    int zT_319;
    unsigned int zT_320;
    unsigned int zT_321;
    unsigned int zT_322;
    int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_text;
    unsigned int und_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_text;
    unsigned int pc_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pti_s;
    unsigned int ptin_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u itp_s;
    unsigned int itp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifp_s;
    unsigned int ifp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_s;
    unsigned int pfi_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpp_s;
    unsigned int fpp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc_s;
    unsigned int vc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_s;
    unsigned int bc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_s;
    unsigned int ic_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_s;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u if_s;
    unsigned int if_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ie_s;
    unsigned int ie_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u e2i_s;
    unsigned int e2i_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u as_s;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u so_s;
    unsigned int so_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ao_s;
    unsigned int ao_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u oo_s;
    unsigned int oo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bso_s;
    unsigned int bso_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u boo_s;
    unsigned int boo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc2_s;
    unsigned int pc2_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sow_s;
    unsigned int sow_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sew_s;
    unsigned int sew_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u gc_s;
    unsigned int gc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ex_s;
    unsigned int ex_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_s;
    unsigned int pn_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm_s;
    unsigned int sm_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u iw_s;
    unsigned int iw_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_s;
    unsigned int cc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cg_s;
    unsigned int cg_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u csc_s;
    unsigned int csc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u afs_s;
    unsigned int afs_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_s;
    unsigned int ain_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ars_s;
    unsigned int ars_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_s;
    unsigned int asu_id;
    zT_17 = "_";
    zT_19 = 1;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    und_text = zT_18;
    zT_21 = interner;
    zT_22 = und_text;
    zT_23 = zF_50C274AF_stringInternerInter(zT_21, zT_22);
    und_name_id = zT_23;
    zT_25 = "@ptrCast";
    zT_27 = 8;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    pc_text = zT_26;
    zT_29 = interner;
    zT_30 = pc_text;
    zT_31 = zF_50C274AF_stringInternerInter(zT_29, zT_30);
    pc_name_id = zT_31;
    zT_33 = "@ptrToInt";
    zT_35 = 9;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    pti_s = zT_34;
    zT_37 = interner;
    zT_38 = pti_s;
    zT_39 = zF_50C274AF_stringInternerInter(zT_37, zT_38);
    ptin_id = zT_39;
    zT_41 = "@intToPtr";
    zT_43 = 9;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    itp_s = zT_42;
    zT_45 = interner;
    zT_46 = itp_s;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    itp_id = zT_47;
    zT_49 = "@intFromPtr";
    zT_51 = 11;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    ifp_s = zT_50;
    zT_53 = interner;
    zT_54 = ifp_s;
    zT_55 = zF_50C274AF_stringInternerInter(zT_53, zT_54);
    ifp_id = zT_55;
    zT_57 = "@ptrFromInt";
    zT_59 = 11;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    pfi_s = zT_58;
    zT_61 = interner;
    zT_62 = pfi_s;
    zT_63 = zF_50C274AF_stringInternerInter(zT_61, zT_62);
    pfi_id = zT_63;
    zT_65 = "@fieldParentPtr";
    zT_67 = 15;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    fpp_s = zT_66;
    zT_69 = interner;
    zT_70 = fpp_s;
    zT_71 = zF_50C274AF_stringInternerInter(zT_69, zT_70);
    fpp_id = zT_71;
    zT_73 = "@volatileCast";
    zT_75 = 13;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    vc_s = zT_74;
    zT_77 = interner;
    zT_78 = vc_s;
    zT_79 = zF_50C274AF_stringInternerInter(zT_77, zT_78);
    vc_id = zT_79;
    zT_81 = "@bitCast";
    zT_83 = 8;
    zT_82.ptr = zT_81;
    zT_82.len = zT_83;
    bc_s = zT_82;
    zT_85 = interner;
    zT_86 = bc_s;
    zT_87 = zF_50C274AF_stringInternerInter(zT_85, zT_86);
    bc_id = zT_87;
    zT_89 = "@intCast";
    zT_91 = 8;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    ic_s = zT_90;
    zT_93 = interner;
    zT_94 = ic_s;
    zT_95 = zF_50C274AF_stringInternerInter(zT_93, zT_94);
    ic_id = zT_95;
    zT_97 = "@floatCast";
    zT_99 = 10;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    fc_s = zT_98;
    zT_101 = interner;
    zT_102 = fc_s;
    zT_103 = zF_50C274AF_stringInternerInter(zT_101, zT_102);
    fc_id = zT_103;
    zT_105 = "@intToFloat";
    zT_107 = 11;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    if_s = zT_106;
    zT_109 = interner;
    zT_110 = if_s;
    zT_111 = zF_50C274AF_stringInternerInter(zT_109, zT_110);
    if_id = zT_111;
    zT_113 = "@intToEnum";
    zT_115 = 10;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    ie_s = zT_114;
    zT_117 = interner;
    zT_118 = ie_s;
    zT_119 = zF_50C274AF_stringInternerInter(zT_117, zT_118);
    ie_id = zT_119;
    zT_121 = "@enumToInt";
    zT_123 = 10;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    e2i_s = zT_122;
    zT_125 = interner;
    zT_126 = e2i_s;
    zT_127 = zF_50C274AF_stringInternerInter(zT_125, zT_126);
    e2i_id = zT_127;
    zT_129 = "@as";
    zT_131 = 3;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    as_s = zT_130;
    zT_133 = interner;
    zT_134 = as_s;
    zT_135 = zF_50C274AF_stringInternerInter(zT_133, zT_134);
    as_id = zT_135;
    zT_137 = "@sizeOf";
    zT_139 = 7;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    so_s = zT_138;
    zT_141 = interner;
    zT_142 = so_s;
    zT_143 = zF_50C274AF_stringInternerInter(zT_141, zT_142);
    so_id = zT_143;
    zT_145 = "@alignOf";
    zT_147 = 8;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    ao_s = zT_146;
    zT_149 = interner;
    zT_150 = ao_s;
    zT_151 = zF_50C274AF_stringInternerInter(zT_149, zT_150);
    ao_id = zT_151;
    zT_153 = "@offsetOf";
    zT_155 = 9;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    oo_s = zT_154;
    zT_157 = interner;
    zT_158 = oo_s;
    zT_159 = zF_50C274AF_stringInternerInter(zT_157, zT_158);
    oo_id = zT_159;
    zT_161 = "@bitSizeOf";
    zT_163 = 10;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    bso_s = zT_162;
    zT_165 = interner;
    zT_166 = bso_s;
    zT_167 = zF_50C274AF_stringInternerInter(zT_165, zT_166);
    bso_id = zT_167;
    zT_169 = "@bitOffsetOf";
    zT_171 = 12;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    boo_s = zT_170;
    zT_173 = interner;
    zT_174 = boo_s;
    zT_175 = zF_50C274AF_stringInternerInter(zT_173, zT_174);
    boo_id = zT_175;
    zT_177 = "@putChar";
    zT_179 = 8;
    zT_178.ptr = zT_177;
    zT_178.len = zT_179;
    pc2_s = zT_178;
    zT_181 = interner;
    zT_182 = pc2_s;
    zT_183 = zF_50C274AF_stringInternerInter(zT_181, zT_182);
    pc2_id = zT_183;
    zT_185 = "@stdoutWrite";
    zT_187 = 12;
    zT_186.ptr = zT_185;
    zT_186.len = zT_187;
    sow_s = zT_186;
    zT_189 = interner;
    zT_190 = sow_s;
    zT_191 = zF_50C274AF_stringInternerInter(zT_189, zT_190);
    sow_id = zT_191;
    zT_193 = "@stderrWrite";
    zT_195 = 12;
    zT_194.ptr = zT_193;
    zT_194.len = zT_195;
    sew_s = zT_194;
    zT_197 = interner;
    zT_198 = sew_s;
    zT_199 = zF_50C274AF_stringInternerInter(zT_197, zT_198);
    sew_id = zT_199;
    zT_201 = "@getChar";
    zT_203 = 8;
    zT_202.ptr = zT_201;
    zT_202.len = zT_203;
    gc_s = zT_202;
    zT_205 = interner;
    zT_206 = gc_s;
    zT_207 = zF_50C274AF_stringInternerInter(zT_205, zT_206);
    gc_id = zT_207;
    zT_209 = "@exit";
    zT_211 = 5;
    zT_210.ptr = zT_209;
    zT_210.len = zT_211;
    ex_s = zT_210;
    zT_213 = interner;
    zT_214 = ex_s;
    zT_215 = zF_50C274AF_stringInternerInter(zT_213, zT_214);
    ex_id = zT_215;
    zT_217 = "@panic";
    zT_219 = 6;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    pn_s = zT_218;
    zT_221 = interner;
    zT_222 = pn_s;
    zT_223 = zF_50C274AF_stringInternerInter(zT_221, zT_222);
    pn_id = zT_223;
    zT_225 = "@sleepMs";
    zT_227 = 8;
    zT_226.ptr = zT_225;
    zT_226.len = zT_227;
    sm_s = zT_226;
    zT_229 = interner;
    zT_230 = sm_s;
    zT_231 = zF_50C274AF_stringInternerInter(zT_229, zT_230);
    sm_id = zT_231;
    zT_233 = "@isWindows";
    zT_235 = 10;
    zT_234.ptr = zT_233;
    zT_234.len = zT_235;
    iw_s = zT_234;
    zT_237 = interner;
    zT_238 = iw_s;
    zT_239 = zF_50C274AF_stringInternerInter(zT_237, zT_238);
    iw_id = zT_239;
    zT_241 = "@consoleClear";
    zT_243 = 13;
    zT_242.ptr = zT_241;
    zT_242.len = zT_243;
    cc_s = zT_242;
    zT_245 = interner;
    zT_246 = cc_s;
    zT_247 = zF_50C274AF_stringInternerInter(zT_245, zT_246);
    cc_id = zT_247;
    zT_249 = "@consoleGotoxy";
    zT_251 = 14;
    zT_250.ptr = zT_249;
    zT_250.len = zT_251;
    cg_s = zT_250;
    zT_253 = interner;
    zT_254 = cg_s;
    zT_255 = zF_50C274AF_stringInternerInter(zT_253, zT_254);
    cg_id = zT_255;
    zT_257 = "@consoleSetColor";
    zT_259 = 16;
    zT_258.ptr = zT_257;
    zT_258.len = zT_259;
    csc_s = zT_258;
    zT_261 = interner;
    zT_262 = csc_s;
    zT_263 = zF_50C274AF_stringInternerInter(zT_261, zT_262);
    csc_id = zT_263;
    zT_265 = "@asyncFrameSize";
    zT_267 = 15;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    afs_s = zT_266;
    zT_269 = interner;
    zT_270 = afs_s;
    zT_271 = zF_50C274AF_stringInternerInter(zT_269, zT_270);
    afs_id = zT_271;
    zT_273 = "@asyncInit";
    zT_275 = 10;
    zT_274.ptr = zT_273;
    zT_274.len = zT_275;
    ain_s = zT_274;
    zT_277 = interner;
    zT_278 = ain_s;
    zT_279 = zF_50C274AF_stringInternerInter(zT_277, zT_278);
    ain_id = zT_279;
    zT_281 = "@asyncResume";
    zT_283 = 12;
    zT_282.ptr = zT_281;
    zT_282.len = zT_283;
    ars_s = zT_282;
    zT_285 = interner;
    zT_286 = ars_s;
    zT_287 = zF_50C274AF_stringInternerInter(zT_285, zT_286);
    ars_id = zT_287;
    zT_289 = "@asyncSuspend";
    zT_291 = 13;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    asu_s = zT_290;
    zT_293 = interner;
    zT_294 = asu_s;
    zT_295 = zF_50C274AF_stringInternerInter(zT_293, zT_294);
    asu_id = zT_295;
    zT_296.type_table = type_table;
    zT_296.diag = diag;
    zT_296.registry = registry;
    zT_296.symbols = symbols;
    zT_296.store = store;
    zT_296.module_id = module_id;
    zT_296.source_file_id = source_file_id;
    zT_297 = 0;
    zT_296.expected_type_stack_items = (unsigned int*)zT_297;
    zT_298 = 0;
    zT_296.expected_type_stack_len = zT_298;
    zT_299 = 0;
    zT_296.expected_type_stack_cap = zT_299;
    zT_296.expected_type_stack_alloc = alloc;
    zT_300 = 0;
    zT_296.stmt_work_items = (unsigned int*)zT_300;
    zT_301 = 0;
    zT_296.stmt_work_len = zT_301;
    zT_302 = 0;
    zT_296.stmt_work_cap = zT_302;
    zT_303 = 0;
    zT_296.current_fn_return = zT_303;
    zT_304 = 0;
    zT_296.current_fn_name = zT_304;
    zT_296.coercion_table = coercion_tab;
    zT_296.enum_value_table = enum_val_tab;
    zT_296.error_code_registry = error_code_reg;
    zT_305 = 0;
    zT_296.current_switch_cond_tu = zT_305;
    zT_306 = 0;
    zT_296.switch_depth = zT_306;
    zT_307 = 0;
    zT_296.defer_depth = zT_307;
    zT_308 = 0;
    zT_296.local_decl_names = (unsigned int*)zT_308;
    zT_309 = 0;
    zT_296.local_decl_types = (unsigned int*)zT_309;
    zT_310 = 0;
    zT_296.local_decl_count = zT_310;
    zT_311 = 0;
    zT_296.local_decl_cap = zT_311;
    zT_312 = 0;
    zT_296.packed_gate_items = (unsigned int*)zT_312;
    zT_313 = 0;
    zT_296.packed_gate_len = zT_313;
    zT_314 = 0;
    zT_296.packed_gate_cap = zT_314;
    zT_315 = 0;
    zT_296.packed_struct_tids = (unsigned int*)zT_315;
    zT_316 = 0;
    zT_296.packed_struct_decl_nodes = (unsigned int*)zT_316;
    zT_317 = 0;
    zT_296.packed_struct_cache_len = zT_317;
    zT_318 = 0;
    zT_296.packed_struct_cache_cap = zT_318;
    zT_319 = 0;
    zT_296.checked_struct_tids = (unsigned int*)zT_319;
    zT_320 = 0;
    zT_296.checked_struct_tids_len = zT_320;
    zT_321 = 0;
    zT_296.checked_struct_tids_cap = zT_321;
    zT_296._stub_0 = und_name_id;
    zT_322 = 0;
    zT_296._stub_1 = zT_322;
    zT_296.call_arg_types = cal_typs;
    zT_296.call_param_map = cp_map;
    zT_296.interner = interner;
    zT_296.ptrcast_name_id = pc_name_id;
    zT_296.volatilecast_name_id = vc_id;
    zT_296.ptrtoint_name_id = ptin_id;
    zT_296.inttoptr_name_id = itp_id;
    zT_296.int_from_ptr_name_id = ifp_id;
    zT_296.ptr_from_int_name_id = pfi_id;
    zT_296.field_parent_ptr_name_id = fpp_id;
    zT_296.bitcast_name_id = bc_id;
    zT_296.intcast_name_id = ic_id;
    zT_296.floatcast_name_id = fc_id;
    zT_296.inttofloat_name_id = if_id;
    zT_296.inttoenum_name_id = ie_id;
    zT_296.enumtoint_name_id = e2i_id;
    zT_296.as_name_id = as_id;
    zT_296.size_of_name_id = so_id;
    zT_296.align_of_name_id = ao_id;
    zT_296.offset_of_name_id = oo_id;
    zT_296.bit_size_of_name_id = bso_id;
    zT_296.bit_offset_of_name_id = boo_id;
    zT_296.putchar_name_id = pc2_id;
    zT_296.stdout_write_name_id = sow_id;
    zT_296.stderr_write_name_id = sew_id;
    zT_296.getchar_name_id = gc_id;
    zT_296.exit_name_id = ex_id;
    zT_296.panic_name_id = pn_id;
    zT_296.sleep_ms_name_id = sm_id;
    zT_296.is_windows_name_id = iw_id;
    zT_296.console_clear_name_id = cc_id;
    zT_296.console_gotoxy_name_id = cg_id;
    zT_296.console_set_color_name_id = csc_id;
    zT_296.async_frame_size_name_id = afs_id;
    zT_296.async_init_name_id = ain_id;
    zT_296.async_resume_name_id = ars_id;
    zT_296.async_suspend_name_id = asu_id;
    zT_323 = 1;
    zT_296.async_analysis_ready = zT_323;
    zT_296.module_reg = module_reg;
    zT_296.suspending_fns = suspending_fns;
    return zT_296;
}

/* semanticAnalyzerIsTypeValueCast */
int zF_3757023F_semanticAnalyzerIsT(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    zT_2 = self->ptrcast_name_id;
    if ((int)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_5 = self->volatilecast_name_id;
    if ((int)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_8 = self->inttoptr_name_id;
    if ((int)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_11 = self->intcast_name_id;
    if ((int)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    zT_14 = self->floatcast_name_id;
    if ((int)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    zT_17 = self->inttofloat_name_id;
    if ((int)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_20 = self->inttoenum_name_id;
    if ((int)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    zT_23 = self->as_name_id;
    if ((int)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    return (int)(0);
}

/* semanticAnalyzerBuiltinNameEq */
int zF_2ACB4E23_semanticAnalyzerBui(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, zT_8F083A69_Slice_zT_0B42B2F8_u lit) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_20;
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned char zT_23;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    unsigned int ci;
    zT_4 = self->interner;
    zT_5 = name_id;
    zT_7 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    nm = zT_7;
    zT_9 = nm.len;
    zT_11 = lit.len;
    if ((int)(zT_9 != zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    ci = zT_16;
    goto z_bb_3;
    z_bb_3:
    zT_18 = nm.len;
    if ((int)(ci < zT_18)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = nm.ptr;
    zT_21 = zT_20[ci];
    zT_22 = lit.ptr;
    zT_23 = zT_22[ci];
    if ((int)(zT_21 != zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_27 = ci + (unsigned int)(1);
    ci = zT_27;
    goto z_bb_3;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    goto z_bb_6;
}

/* semanticAnalyzerIsBuiltinSupported */
int zF_CAF1FD28_semanticAnalyzerIsB(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_44;
    unsigned int zT_47;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_59;
    unsigned int zT_62;
    unsigned int zT_65;
    unsigned int zT_68;
    unsigned int zT_71;
    unsigned int zT_74;
    unsigned int zT_77;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned int zT_86;
    unsigned int zT_89;
    unsigned int zT_92;
    unsigned int zT_95;
    char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_38C12417_SemanticAnalyzer* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    int zT_105 = 0;
    char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_38C12417_SemanticAnalyzer* zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    int zT_114 = 0;
    char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_38C12417_SemanticAnalyzer* zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    int zT_123 = 0;
    char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_38C12417_SemanticAnalyzer* zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    int zT_132 = 0;
    char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    int zT_141 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_e2i;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cvs;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cva;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cve;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_pan;
    zT_2 = self->ptrcast_name_id;
    if ((int)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_5 = self->volatilecast_name_id;
    if ((int)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_8 = self->ptrtoint_name_id;
    if ((int)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_11 = self->inttoptr_name_id;
    if ((int)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    zT_14 = self->int_from_ptr_name_id;
    if ((int)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    zT_17 = self->ptr_from_int_name_id;
    if ((int)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_20 = self->field_parent_ptr_name_id;
    if ((int)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    zT_23 = self->bitcast_name_id;
    if ((int)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    zT_26 = self->intcast_name_id;
    if ((int)(name_id == zT_26)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    zT_29 = self->floatcast_name_id;
    if ((int)(name_id == zT_29)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    zT_32 = self->inttofloat_name_id;
    if ((int)(name_id == zT_32)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(1);
    z_bb_22:
    zT_35 = self->inttoenum_name_id;
    if ((int)(name_id == zT_35)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(1);
    z_bb_24:
    zT_38 = self->as_name_id;
    if ((int)(name_id == zT_38)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(1);
    z_bb_26:
    zT_41 = self->size_of_name_id;
    if ((int)(name_id == zT_41)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(1);
    z_bb_28:
    zT_44 = self->align_of_name_id;
    if ((int)(name_id == zT_44)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (int)(1);
    z_bb_30:
    zT_47 = self->offset_of_name_id;
    if ((int)(name_id == zT_47)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return (int)(1);
    z_bb_32:
    zT_50 = self->bit_size_of_name_id;
    if ((int)(name_id == zT_50)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (int)(1);
    z_bb_34:
    zT_53 = self->bit_offset_of_name_id;
    if ((int)(name_id == zT_53)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (int)(1);
    z_bb_36:
    zT_56 = self->putchar_name_id;
    if ((int)(name_id == zT_56)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (int)(1);
    z_bb_38:
    zT_59 = self->stdout_write_name_id;
    if ((int)(name_id == zT_59)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (int)(1);
    z_bb_40:
    zT_62 = self->stderr_write_name_id;
    if ((int)(name_id == zT_62)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (int)(1);
    z_bb_42:
    zT_65 = self->getchar_name_id;
    if ((int)(name_id == zT_65)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return (int)(1);
    z_bb_44:
    zT_68 = self->exit_name_id;
    if ((int)(name_id == zT_68)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (int)(1);
    z_bb_46:
    zT_71 = self->sleep_ms_name_id;
    if ((int)(name_id == zT_71)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (int)(1);
    z_bb_48:
    zT_74 = self->is_windows_name_id;
    if ((int)(name_id == zT_74)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return (int)(1);
    z_bb_50:
    zT_77 = self->console_clear_name_id;
    if ((int)(name_id == zT_77)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (int)(1);
    z_bb_52:
    zT_80 = self->console_gotoxy_name_id;
    if ((int)(name_id == zT_80)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return (int)(1);
    z_bb_54:
    zT_83 = self->console_set_color_name_id;
    if ((int)(name_id == zT_83)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (int)(1);
    z_bb_56:
    zT_86 = self->async_frame_size_name_id;
    if ((int)(name_id == zT_86)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (int)(1);
    z_bb_58:
    zT_89 = self->async_init_name_id;
    if ((int)(name_id == zT_89)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (int)(1);
    z_bb_60:
    zT_92 = self->async_resume_name_id;
    if ((int)(name_id == zT_92)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (int)(1);
    z_bb_62:
    zT_95 = self->async_suspend_name_id;
    if ((int)(name_id == zT_95)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (int)(1);
    z_bb_64:
    zT_99 = "@enumToInt";
    zT_101 = 10;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    l_e2i = zT_100;
    zT_102 = self;
    zT_103 = name_id;
    zT_104 = l_e2i;
    zT_105 = zF_2ACB4E23_semanticAnalyzerBui(zT_102, zT_103, zT_104);
    if (zT_105) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    return (int)(1);
    z_bb_66:
    zT_108 = "@cVaStart";
    zT_110 = 9;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    l_cvs = zT_109;
    zT_111 = self;
    zT_112 = name_id;
    zT_113 = l_cvs;
    zT_114 = zF_2ACB4E23_semanticAnalyzerBui(zT_111, zT_112, zT_113);
    if (zT_114) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    return (int)(1);
    z_bb_68:
    zT_117 = "@cVaArg";
    zT_119 = 7;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    l_cva = zT_118;
    zT_120 = self;
    zT_121 = name_id;
    zT_122 = l_cva;
    zT_123 = zF_2ACB4E23_semanticAnalyzerBui(zT_120, zT_121, zT_122);
    if (zT_123) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    return (int)(1);
    z_bb_70:
    zT_126 = "@cVaEnd";
    zT_128 = 7;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    l_cve = zT_127;
    zT_129 = self;
    zT_130 = name_id;
    zT_131 = l_cve;
    zT_132 = zF_2ACB4E23_semanticAnalyzerBui(zT_129, zT_130, zT_131);
    if (zT_132) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    return (int)(1);
    z_bb_72:
    zT_135 = "@panic";
    zT_137 = 6;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    l_pan = zT_136;
    zT_138 = self;
    zT_139 = name_id;
    zT_140 = l_pan;
    zT_141 = zF_2ACB4E23_semanticAnalyzerBui(zT_138, zT_139, zT_140);
    if (zT_141) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    return (int)(1);
    z_bb_74:
    return (int)(0);
}

/* semanticAnalyzerDiagAsyncOutsideSuspending */
void zF_D4D0798B_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    int zT_2;
    zT_A4CE86B7_U64ToU32Map* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    zT_22A7C88B_AstNode zT_15 = {0};
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_F85C5DED_DiagnosticCollector* zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_39 = 0;
    zT_22A7C88B_AstNode a318_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u e318;
    zT_2 = self->async_analysis_ready;
    if ((int)(!zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = self->suspending_fns;
    zT_5 = self->module_id;
    zT_6 = self->current_fn_name;
    zT_10 = zF_7C7E43BF_asyncIsSuspending(zT_4, zT_5, zT_6);
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_12, zT_13);
    a318_node = zT_15;
    zT_17 = "@asyncSuspend used outside a suspending function";
    zT_19 = 48;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    e318 = zT_18;
    zT_20 = self->diag;
    zT_23 = self->source_file_id;
    zT_24 = a318_node.span_start;
    zT_35 = a318_node.span_start;
    zT_36 = a318_node.span_len;
    zT_26 = e318;
    zT_39 = zF_C82559AC_diagnosticCollector(zT_20, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3018_ASYNC_SUSPEND_OUTSIDE_SUSPENDING)), zT_23, zT_24, (unsigned int)(zT_35 + (unsigned int)((unsigned int)zT_36)), zT_26);
    (void)zT_39;
    return;
}

/* semanticAnalyzerDiagAsyncBuiltinInDefer */
void zF_2EC0CDC8_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_33 = 0;
    zT_22A7C88B_AstNode a319_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u e319;
    zT_2 = self->defer_depth;
    if ((int)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    a319_node = zT_9;
    zT_11 = "@async builtin used inside a defer/errdefer body";
    zT_13 = 48;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    e319 = zT_12;
    zT_14 = self->diag;
    zT_17 = self->source_file_id;
    zT_18 = a319_node.span_start;
    zT_29 = a319_node.span_start;
    zT_30 = a319_node.span_len;
    zT_20 = e319;
    zT_33 = zF_C82559AC_diagnosticCollector(zT_14, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3019_ASYNC_BUILTIN_IN_DEFER)), zT_17, zT_18, (unsigned int)(zT_29 + (unsigned int)((unsigned int)zT_30)), zT_20);
    (void)zT_33;
    return;
}

/* semanticAnalyzerGrowLocalDecls */
void zF_156C79D0_semanticAnalyzerGro(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_9154F007_EU_232 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    zT_3E40CD83_Sand* zT_23;
    zT_9154F007_EU_232 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int* zT_35;
    unsigned int* zT_37;
    unsigned int zT_38;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw_names;
    unsigned char* raw_types;
    unsigned int* ndst;
    unsigned int* tdst;
    unsigned int ci;
    zT_2 = self->local_decl_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->local_decl_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_names = zT_20;
    zT_23 = self->expected_type_stack_alloc;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_32 = zT_30.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_types = zT_32;
    zT_35 = (unsigned int*)raw_names;
    ndst = zT_35;
    zT_37 = (unsigned int*)raw_types;
    tdst = zT_37;
    zT_38 = self->local_decl_count;
    if ((int)(zT_38 > (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    goto z_bb_12;
    z_bb_11:
    self->local_decl_names = ndst;
    self->local_decl_types = tdst;
    self->local_decl_cap = new_cap;
    return;
    z_bb_12:
    zT_44 = self->local_decl_count;
    if ((int)(ci < zT_44)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = self->local_decl_names;
    zT_47 = zT_46[ci];
    ndst[ci] = zT_47;
    zT_48 = self->local_decl_types;
    zT_49 = zT_48[ci];
    tdst[ci] = zT_49;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_50 = 1;
    zT_51 = ci + zT_50;
    ci = zT_51;
    goto z_bb_12;
}

/* registerLocalDecl */
void zF_7BD72017_registerLocalDecl(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    char* zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_tm;
    zT_3 = self->local_decl_count;
    zT_4 = self->local_decl_cap;
    if ((int)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_8 = "SCT:n";
    zT_10 = 5;
    zT_9.ptr = zT_8;
    zT_9.len = zT_10;
    sct_nm = zT_9;
    zT_11 = sct_nm;
    zT_12 = name_id;
    zF_C914CB83_markerWriteInt(zT_11, zT_12);
    zT_14 = "SCT:t";
    zT_16 = 5;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    sct_tm = zT_15;
    zT_17 = sct_tm;
    zT_18 = type_id;
    zF_C914CB83_markerWriteInt(zT_17, zT_18);
    zT_19 = self->local_decl_names;
    zT_20 = self->local_decl_count;
    zT_19[zT_20] = name_id;
    zT_21 = self->local_decl_types;
    zT_22 = self->local_decl_count;
    zT_21[zT_22] = type_id;
    zT_23 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_23 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCaptureType */
unsigned int zF_3E251D67_semanticAnalyzerCap(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_type) {
    zT_338B7C76_TypeRegistry* zT_6;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_0B10E8E9_OptionalPayload* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_0B10E8E9_OptionalPayload zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type capt_ty;
    if ((int)(cond_type == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_items;
    zT_8 = (unsigned int)cond_type;
    zT_9 = zT_7[zT_8];
    capt_ty = zT_9;
    zT_10 = capt_ty.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self->registry;
    zT_16 = zT_15->opt_items;
    zT_17 = capt_ty.payload_idx;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zT_16[zT_18];
    zT_20 = zT_19.payload;
    return zT_20;
    z_bb_4:
    return cond_type;
}

/* semanticAnalyzerResolveIdent */
unsigned int zF_9F1ECA79_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int module_id, unsigned int name_id, unsigned int node_idx) {
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int* zT_27;
    unsigned int zT_28;
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_79FAE712_u64 zT_63;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned int zT_70;
    zT_79FAE712_u64 zT_75;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_79FAE712_u64 zT_78;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    zT_3D7259E2_SymbolRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_50791B23_Opt_842 zT_87 = {0};
    unsigned char zT_88;
    char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_3C598AEF_SymbolKind zT_95;
    zT_38C12417_SemanticAnalyzer* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_105;
    char* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    unsigned char zT_114;
    char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned char zT_121;
    char* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_134;
    char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    unsigned char zT_150;
    char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned char zT_165;
    char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    char* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_185;
    unsigned int zT_187;
    char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    unsigned int* zT_196;
    unsigned int zT_197;
    char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    unsigned int* zT_205;
    unsigned int zT_206;
    unsigned int zT_208;
    unsigned int zT_210;
    char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_218;
    unsigned int* zT_219;
    unsigned int zT_220;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    int zT_230;
    zT_D3EB6303_StringInterner* zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    zT_6B0A7D14_AstStore* zT_240;
    unsigned int zT_241;
    zT_22A7C88B_AstNode zT_243 = {0};
    char* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    zT_8143F551_AstKind zT_250;
    zT_8EED1867_ResolvedTypeTable* zT_253;
    unsigned int zT_254;
    zT_BAEE192E_Opt_10 zT_256 = {0};
    unsigned char zT_257;
    char* zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned int zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    char* zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    char* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_284;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    int zT_290;
    unsigned char* zT_291;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned int zT_294 = 0;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned char* zT_303;
    unsigned int zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    char* zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    unsigned int zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u ide;
    zT_8F083A69_Slice_zT_0B42B2F8_u sem_m;
    unsigned int li;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 ncg;
    zT_79FAE712_u64 mkey;
    zT_BAEE192E_Opt_10 ncgm;
    zT_50791B23_Opt_842 sym;
    unsigned int lcl_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u id1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lt_m;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u id2;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_talias;
    unsigned int ctm;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_sv;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_tm;
    unsigned int nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_ntm;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u id3;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8l_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8i_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cname;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8k_m;
    zT_BAEE192E_Opt_10 rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8nl2;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8z_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u idm;
    zT_5A26C2ED_Arr_unsigned_char_1 idnb;
    unsigned int idnl;
    unsigned int idns;
    zT_8F083A69_Slice_zT_0B42B2F8_u idc;
    zT_5 = "IDE\n";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    ide = zT_6;
    zT_8 = ide;
    zF_48AC7B3A_markerWrite(zT_8);
    if ((int)(name_id == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = "SEM:vi";
    zT_14 = 6;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    sem_m = zT_13;
    zT_15 = sem_m;
    zT_16 = module_id;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_18 = self->local_decl_count;
    li = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((int)(li > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = li - (unsigned int)(1);
    li = zT_22;
    zT_23 = self->local_decl_names;
    zT_24 = zT_23[li];
    if ((int)(zT_24 == name_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_63 = (zT_79FAE712_u64)name_id;
    key = zT_63;
    zT_65 = self->registry;
    zT_66 = key;
    zT_68 = zF_0EB68360_nameCacheGet(zT_65, zT_66);
    ncg = zT_68;
    zT_70 = self->module_id;
    zT_75 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_70) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    mkey = zT_75;
    zT_77 = self->registry;
    zT_78 = mkey;
    zT_80 = zF_0EB68360_nameCacheGet(zT_77, zT_78);
    ncgm = zT_80;
    zT_82 = self->symbols;
    zT_83 = self->module_id;
    zT_84 = name_id;
    zT_87 = zF_A398987E_symbolRegistryQuali(zT_82, zT_83, zT_84);
    sym = zT_87;
    zT_88 = sym.has_value;
    if (zT_88) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_27 = self->local_decl_types;
    zT_28 = zT_27[li];
    lcl_t = zT_28;
    zT_30 = "D7:Yn";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    d7m = zT_31;
    zT_33 = d7m;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_35 = "D7:n";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    d7n_m = zT_36;
    zT_38 = d7n_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_41 = "D7:t";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    d7tm = zT_42;
    zT_44 = d7tm;
    zF_48AC7B3A_markerWrite(zT_44);
    zT_46 = "D7";
    zT_48 = 2;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    d7t_m = zT_47;
    zT_49 = d7t_m;
    zT_50 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_49, zT_50);
    zT_52 = "L\n";
    zT_54 = 2;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    id1 = zT_53;
    zT_55 = id1;
    zF_48AC7B3A_markerWrite(zT_55);
    zT_57 = "L:t";
    zT_59 = 3;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    lt_m = zT_58;
    zT_60 = lt_m;
    zT_61 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_60, zT_61);
    return lcl_t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    s = sym.value;
    zT_91 = "S\n";
    zT_93 = 2;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    id2 = zT_92;
    zT_94 = id2;
    zF_48AC7B3A_markerWrite(zT_94);
    zT_95 = s->kind;
    if ((int)(zT_95 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_165 = ncg.has_value;
    if (zT_165) goto z_bb_23; else goto z_bb_24;
    z_bb_11:
    zT_100 = self;
    zT_101 = s->decl_node;
    zT_102 = s->module_id;
    zF_FC6E31C6_semanticAnalyzerMay(zT_100, zT_101, zT_102);
    zT_105 = s->type_id;
    if ((int)(zT_105 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_134 = s->type_id;
    if ((int)(zT_134 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    zT_109 = "TAL\n";
    zT_111 = 4;
    zT_110.ptr = zT_109;
    zT_110.len = zT_111;
    rdt_talias = zT_110;
    zT_112 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_112);
    zT_113 = s->type_id;
    return zT_113;
    z_bb_14:
    zT_114 = ncgm.has_value;
    if (zT_114) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    ctm = ncgm.value;
    zT_117 = "TAL\n";
    zT_119 = 4;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    rdt_talias = zT_118;
    zT_120 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_120);
    return ctm;
    z_bb_16:
    zT_121 = ncg.has_value;
    if (zT_121) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    ct = ncg.value;
    zT_124 = "TAL\n";
    zT_126 = 4;
    zT_125.ptr = zT_124;
    zT_125.len = zT_126;
    rdt_talias = zT_125;
    zT_127 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_127);
    return ct;
    z_bb_18:
    zT_129 = "SVO\n";
    zT_131 = 4;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    rdt_sv = zT_130;
    zT_132 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_132);
    return (unsigned int)(1);
    z_bb_19:
    zT_138 = "STY:N";
    zT_140 = 5;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    rdt_nm = zT_139;
    zT_141 = rdt_nm;
    zT_142 = name_id;
    zF_C914CB83_markerWriteInt(zT_141, zT_142);
    zT_144 = "STY:T";
    zT_146 = 5;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    rdt_tm = zT_145;
    zT_147 = rdt_tm;
    zT_148 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_147, zT_148);
    zT_150 = ncg.has_value;
    if (zT_150) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_160 = "SVO\n";
    zT_162 = 4;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    rdt_sv = zT_161;
    zT_163 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_163);
    return (unsigned int)(1);
    z_bb_21:
    nt = ncg.value;
    zT_153 = "STY:C";
    zT_155 = 5;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    rdt_ntm = zT_154;
    zT_156 = rdt_ntm;
    zT_157 = nt;
    zF_C914CB83_markerWriteInt(zT_156, zT_157);
    goto z_bb_22;
    z_bb_22:
    zT_158 = s->type_id;
    return zT_158;
    z_bb_23:
    t = ncg.value;
    zT_168 = "C2:T";
    zT_170 = 4;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    id3 = zT_169;
    zT_171 = id3;
    zT_172 = t;
    zF_C914CB83_markerWriteInt(zT_171, zT_172);
    return t;
    z_bb_24:
    zT_174 = "D8:Nn";
    zT_176 = 5;
    zT_175.ptr = zT_174;
    zT_175.len = zT_176;
    d8n_m = zT_175;
    zT_177 = d8n_m;
    zT_178 = name_id;
    zF_C914CB83_markerWriteInt(zT_177, zT_178);
    zT_180 = "D8:C";
    zT_182 = 4;
    zT_181.ptr = zT_180;
    zT_181.len = zT_182;
    d8c_m = zT_181;
    zT_183 = d8c_m;
    zT_185 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_183, (unsigned int)((unsigned int)zT_185));
    zT_187 = self->local_decl_count;
    if ((int)(zT_187 > (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_191 = "D8:F";
    zT_193 = 4;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    d8f_m = zT_192;
    zT_194 = d8f_m;
    zT_196 = self->local_decl_names;
    zT_197 = 0;
    zT_195 = zT_196[zT_197];
    zF_C914CB83_markerWriteInt(zT_194, zT_195);
    zT_200 = "D8:L";
    zT_202 = 4;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    d8l_m = zT_201;
    zT_203 = d8l_m;
    zT_205 = self->local_decl_names;
    zT_206 = self->local_decl_count;
    zT_208 = zT_206 - (unsigned int)(1);
    zT_204 = zT_205[zT_208];
    zF_C914CB83_markerWriteInt(zT_203, zT_204);
    goto z_bb_26;
    z_bb_26:
    zT_210 = self->local_decl_count;
    if ((int)(zT_210 > (unsigned int)(4))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_214 = "D8:X";
    zT_216 = 4;
    zT_215.ptr = zT_214;
    zT_215.len = zT_216;
    d8x_m = zT_215;
    zT_217 = d8x_m;
    zT_219 = self->local_decl_names;
    zT_220 = 4;
    zT_218 = zT_219[zT_220];
    zF_C914CB83_markerWriteInt(zT_217, zT_218);
    goto z_bb_28;
    z_bb_28:
    zT_223 = "D8:I";
    zT_225 = 4;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    d8i_m = zT_224;
    zT_226 = d8i_m;
    zT_227 = node_idx;
    zF_C914CB83_markerWriteInt(zT_226, zT_227);
    if ((int)(node_idx >= (unsigned int)(450))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_230 = node_idx <= (unsigned int)(660);
    goto z_bb_31;
    z_bb_30:
    zT_230 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_230) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_234 = self->interner;
    zT_235 = name_id;
    zT_237 = zF_9134020D_stringInternerGet(zT_234, zT_235);
    cname = zT_237;
    zT_238 = cname;
    zF_48AC7B3A_markerWrite(zT_238);
    zT_240 = self->store;
    zT_241 = node_idx;
    zT_243 = zF_FCDD1D35_astStoreNodeAt(zT_240, zT_241);
    cnode = zT_243;
    zT_245 = "D8";
    zT_247 = 2;
    zT_246.ptr = zT_245;
    zT_246.len = zT_247;
    d8k_m = zT_246;
    zT_248 = d8k_m;
    zT_250 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_248, (unsigned int)((unsigned int)zT_250));
    zT_253 = self->type_table;
    zT_254 = node_idx;
    zT_256 = zF_999DCF51_resolvedTypeTableGe(zT_253, zT_254);
    rt = zT_256;
    zT_257 = rt.has_value;
    if (zT_257) goto z_bb_34; else goto z_bb_36;
    z_bb_33:
    zT_275 = self->_stub_0;
    if ((int)(name_id == zT_275)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    t = rt.value;
    zT_260 = "D8:T";
    zT_262 = 4;
    zT_261.ptr = zT_260;
    zT_261.len = zT_262;
    d8t_m = zT_261;
    zT_263 = d8t_m;
    zT_264 = t;
    zF_C914CB83_markerWriteInt(zT_263, zT_264);
    goto z_bb_35;
    z_bb_35:
    zT_271 = "\n";
    zT_273 = 1;
    zT_272.ptr = zT_271;
    zT_272.len = zT_273;
    d8nl2 = zT_272;
    zT_274 = d8nl2;
    zF_48AC7B3A_markerWrite(zT_274);
    goto z_bb_33;
    z_bb_36:
    zT_266 = "D8:Z\n";
    zT_268 = 5;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    d8z_m = zT_267;
    zT_269 = d8z_m;
    zF_48AC7B3A_markerWrite(zT_269);
    goto z_bb_35;
    z_bb_37:
    return (unsigned int)(18);
    z_bb_38:
    zT_279 = "IDT:";
    zT_281 = 4;
    zT_280.ptr = zT_279;
    zT_280.len = zT_281;
    idm = zT_280;
    zT_282 = idm;
    zF_48AC7B3A_markerWrite(zT_282);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_284[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        idnb[_i] = zT_284[_i];
        _i++;
    }
}
    zT_286 = name_id;
    zT_290 = 0;
    zT_291 = (unsigned char*)((unsigned char*)idnb) + zT_290;
    zT_292 = (unsigned int)(10) - zT_290;
    zT_293.ptr = zT_291;
    zT_293.len = zT_292;
    zT_287 = zT_293;
    zT_294 = zF_A7504564_itoa(zT_286, zT_287);
    idnl = zT_294;
    zT_298 = (unsigned int)(9) - (unsigned int)((unsigned int)idnl);
    idns = zT_298;
    zT_303 = (unsigned char*)((unsigned char*)idnb) + idns;
    zT_304 = (unsigned int)(9) - idns;
    zT_305.ptr = zT_303;
    zT_305.len = zT_304;
    zT_299 = zT_305;
    zF_48AC7B3A_markerWrite(zT_299);
    zT_307 = ":VOID\n";
    zT_309 = 6;
    zT_308.ptr = zT_307;
    zT_308.len = zT_309;
    idc = zT_308;
    zT_310 = idc;
    zF_48AC7B3A_markerWrite(zT_310);
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveFieldAccess */
unsigned int zF_DDD991E1_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8143F551_AstKind zT_29;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8143F551_AstKind zT_37;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_49;
    unsigned int zT_52 = 0;
    zT_3D7259E2_SymbolRegistry* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_50791B23_Opt_842 zT_59 = {0};
    unsigned char zT_60;
    zT_3C598AEF_SymbolKind zT_62;
    unsigned int zT_68;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_D155D06D_Type* zT_73;
    unsigned int zT_74;
    zT_D155D06D_Type zT_75;
    zT_33EF6BFB_TypeKind zT_76;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_54FF90FA_TaggedUnionPayload* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_54FF90FA_TaggedUnionPayload zT_86;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned short zT_91;
    unsigned int zT_92;
    int zT_94;
    unsigned int zT_95;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_2DF01B61_FieldEntry* zT_98;
    unsigned int zT_99;
    zT_2DF01B61_FieldEntry zT_100;
    unsigned int zT_101;
    zT_8EED1867_ResolvedTypeTable* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    int zT_107;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_457ECFEE_EnumPayload* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_457ECFEE_EnumPayload zT_119;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned short zT_124;
    unsigned int zT_125;
    int zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D96DCDF2_EnumMember* zT_131;
    unsigned int zT_132;
    zT_D96DCDF2_EnumMember zT_133;
    unsigned int zT_134;
    zT_8EED1867_ResolvedTypeTable* zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    int zT_140;
    unsigned int zT_141;
    zT_33EF6BFB_TypeKind zT_142;
    zT_338B7C76_TypeRegistry* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_152 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_3C598AEF_SymbolKind zT_159;
    unsigned int zT_165;
    zT_3D7259E2_SymbolRegistry* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_50791B23_Opt_842 zT_171 = {0};
    unsigned char zT_172;
    char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned short zT_180;
    char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    zT_3C598AEF_SymbolKind zT_188;
    char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    char* zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    unsigned short zT_203;
    zT_3C598AEF_SymbolKind zT_208;
    zT_8EED1867_ResolvedTypeTable* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int zT_218;
    unsigned int zT_219;
    zT_8EED1867_ResolvedTypeTable* zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    unsigned int zT_227;
    zT_3C598AEF_SymbolKind zT_228;
    int zT_233;
    unsigned int zT_234;
    char* zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    zT_6B0A7D14_AstStore* zT_243;
    unsigned int zT_244;
    zT_22A7C88B_AstNode zT_247 = {0};
    zT_8143F551_AstKind zT_248;
    zT_6B0A7D14_AstStore* zT_254;
    zT_623E1332_anon_217967 zT_255;
    zT_243D6A41_FnProto* zT_256;
    zT_6B0A7D14_AstStore* zT_257;
    unsigned int zT_258;
    unsigned int zT_261 = 0;
    unsigned int zT_262;
    zT_243D6A41_FnProto zT_263;
    char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned int zT_269;
    unsigned int zT_271;
    zT_8EED1867_ResolvedTypeTable* zT_275;
    unsigned int zT_276;
    zT_BAEE192E_Opt_10 zT_279 = {0};
    unsigned char zT_281;
    unsigned int zT_282;
    char* zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned int zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    unsigned int zT_290;
    unsigned char zT_291;
    zT_338B7C76_TypeRegistry* zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_299;
    unsigned short zT_300;
    unsigned int zT_301;
    unsigned char zT_302;
    unsigned int zT_311 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_ABC1EBBE_TypeResolveEnv zT_317;
    zT_6B0A7D14_AstStore* zT_318;
    zT_338B7C76_TypeRegistry* zT_319;
    zT_3D7259E2_SymbolRegistry* zT_320;
    zT_D3EB6303_StringInterner* zT_321;
    unsigned int zT_322;
    zT_ABC1EBBE_TypeResolveEnv* zT_324;
    unsigned int zT_325;
    unsigned int zT_330 = 0;
    char* zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    unsigned int zT_336;
    char* zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned int zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned int zT_343;
    zT_8EED1867_ResolvedTypeTable* zT_346;
    unsigned int zT_347;
    unsigned int zT_348;
    zT_338B7C76_TypeRegistry* zT_352;
    unsigned int zT_353;
    unsigned int zT_354;
    unsigned int zT_357;
    unsigned short zT_358;
    unsigned int zT_359;
    unsigned char zT_360;
    unsigned int zT_369 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_370;
    unsigned int zT_371;
    unsigned int zT_372;
    char* zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    unsigned int zT_377;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_378;
    zT_338B7C76_TypeRegistry* zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    unsigned int zT_385;
    unsigned short zT_386;
    unsigned char zT_388;
    unsigned int zT_398 = 0;
    char* zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_401;
    unsigned int zT_402;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    unsigned int zT_404;
    zT_8EED1867_ResolvedTypeTable* zT_405;
    unsigned int zT_406;
    unsigned int zT_407;
    char* zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_412;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_413;
    unsigned int zT_414;
    zT_8EED1867_ResolvedTypeTable* zT_415;
    unsigned int zT_416;
    unsigned int zT_424;
    unsigned int zT_426;
    unsigned int zT_428;
    zT_D3EB6303_StringInterner* zT_430;
    unsigned int zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433 = {0};
    char* zT_435;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_436;
    unsigned int zT_437;
    char* zT_439;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_440;
    unsigned int zT_441;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_443;
    unsigned int zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    zT_D3EB6303_StringInterner* zT_448;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_449;
    int zT_452;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_456;
    unsigned int zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_462;
    unsigned int zT_470 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_471;
    unsigned int zT_472;
    zT_8143F551_AstKind zT_477;
    zT_6B0A7D14_AstStore* zT_483;
    unsigned int zT_484;
    unsigned int zT_487 = 0;
    zT_072B53A6_ModuleRegistry* zT_489;
    unsigned int zT_490;
    zT_BAEE192E_Opt_10 zT_492 = {0};
    unsigned char zT_493;
    zT_3D7259E2_SymbolRegistry* zT_496;
    unsigned int zT_497;
    unsigned int zT_498;
    zT_50791B23_Opt_842 zT_500 = {0};
    unsigned char zT_501;
    unsigned short zT_503;
    zT_3C598AEF_SymbolKind zT_508;
    zT_8EED1867_ResolvedTypeTable* zT_513;
    unsigned int zT_514;
    unsigned int zT_515;
    unsigned int zT_518;
    unsigned int zT_519;
    zT_8EED1867_ResolvedTypeTable* zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    unsigned int zT_527;
    zT_38C12417_SemanticAnalyzer* zT_529;
    unsigned int zT_530;
    unsigned int zT_532 = 0;
    char* zT_536;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_537;
    unsigned int zT_538;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_539;
    zT_8EED1867_ResolvedTypeTable* zT_540;
    unsigned int zT_541;
    zT_338B7C76_TypeRegistry* zT_547;
    zT_D155D06D_Type* zT_548;
    unsigned int zT_549;
    zT_D155D06D_Type zT_550;
    int zT_552;
    unsigned int zT_553;
    int zT_555;
    unsigned int zT_556;
    zT_33EF6BFB_TypeKind zT_557;
    int zT_562;
    zT_33EF6BFB_TypeKind zT_563;
    zT_33EF6BFB_TypeKind zT_569;
    zT_338B7C76_TypeRegistry* zT_570;
    zT_112BF819_PtrPayload* zT_571;
    unsigned int zT_572;
    unsigned int zT_573;
    zT_112BF819_PtrPayload zT_574;
    unsigned int zT_575;
    zT_338B7C76_TypeRegistry* zT_576;
    zT_D155D06D_Type* zT_577;
    unsigned int zT_578;
    zT_D155D06D_Type zT_579;
    char* zT_581;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_582;
    unsigned int zT_583;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_584;
    char* zT_588;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_589;
    unsigned int zT_590;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_591;
    zT_33EF6BFB_TypeKind zT_593;
    char* zT_596;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_597;
    unsigned int zT_598;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_599;
    zT_33EF6BFB_TypeKind zT_600;
    unsigned int zT_606;
    unsigned int zT_608;
    unsigned int zT_610;
    char* zT_612;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_613;
    unsigned int zT_614;
    zT_F85C5DED_DiagnosticCollector* zT_615;
    unsigned int zT_618;
    unsigned int zT_619;
    unsigned int zT_620;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_621;
    unsigned int zT_626 = 0;
    zT_33EF6BFB_TypeKind zT_628;
    unsigned int zT_634;
    unsigned int zT_636;
    unsigned int zT_638;
    char* zT_640;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_641;
    unsigned int zT_642;
    zT_F85C5DED_DiagnosticCollector* zT_643;
    unsigned int zT_646;
    unsigned int zT_647;
    unsigned int zT_648;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_649;
    unsigned int zT_654 = 0;
    zT_33EF6BFB_TypeKind zT_656;
    zT_338B7C76_TypeRegistry* zT_662;
    zT_406493CE_StructPayload* zT_663;
    unsigned int zT_664;
    unsigned int zT_665;
    zT_406493CE_StructPayload zT_666;
    unsigned int zT_667;
    unsigned int zT_668;
    unsigned short zT_669;
    unsigned int zT_670;
    zT_33EF6BFB_TypeKind zT_671;
    int zT_676;
    zT_33EF6BFB_TypeKind zT_677;
    zT_338B7C76_TypeRegistry* zT_683;
    zT_AF9231A2_UnionPayload* zT_684;
    unsigned int zT_685;
    unsigned int zT_686;
    zT_AF9231A2_UnionPayload zT_687;
    unsigned int zT_688;
    unsigned int zT_689;
    unsigned short zT_690;
    unsigned int zT_691;
    zT_33EF6BFB_TypeKind zT_692;
    zT_338B7C76_TypeRegistry* zT_698;
    zT_54FF90FA_TaggedUnionPayload* zT_699;
    unsigned int zT_700;
    unsigned int zT_701;
    zT_54FF90FA_TaggedUnionPayload zT_702;
    char* zT_704;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705;
    unsigned int zT_706;
    zT_D3EB6303_StringInterner* zT_708;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    unsigned int zT_711 = 0;
    char* zT_714;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_715;
    unsigned int zT_716;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_717;
    zT_8EED1867_ResolvedTypeTable* zT_718;
    unsigned int zT_719;
    unsigned int zT_720;
    unsigned int zT_723;
    char* zT_725;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_726;
    unsigned int zT_727;
    zT_D3EB6303_StringInterner* zT_729;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_730;
    unsigned int zT_732 = 0;
    unsigned short zT_735;
    unsigned int zT_736;
    int zT_738;
    unsigned int zT_739;
    zT_338B7C76_TypeRegistry* zT_742;
    zT_2DF01B61_FieldEntry* zT_743;
    unsigned int zT_744;
    unsigned int zT_746;
    zT_2DF01B61_FieldEntry zT_747;
    unsigned int zT_748;
    unsigned int zT_752;
    zT_338B7C76_TypeRegistry* zT_754;
    zT_D155D06D_Type* zT_755;
    unsigned int zT_756;
    zT_D155D06D_Type zT_757;
    zT_33EF6BFB_TypeKind zT_758;
    zT_338B7C76_TypeRegistry* zT_764;
    zT_E834303C_ArrayPayload* zT_765;
    unsigned int zT_766;
    unsigned int zT_767;
    zT_E834303C_ArrayPayload zT_768;
    unsigned int zT_769;
    zT_338B7C76_TypeRegistry* zT_770;
    unsigned int zT_771;
    unsigned int zT_775 = 0;
    char* zT_777;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_778;
    unsigned int zT_779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_780;
    zT_8EED1867_ResolvedTypeTable* zT_781;
    unsigned int zT_782;
    unsigned int zT_783;
    int zT_785;
    unsigned int zT_786;
    unsigned int zT_787;
    unsigned int zT_788;
    unsigned short zT_789;
    unsigned int zT_790;
    zT_33EF6BFB_TypeKind zT_791;
    char* zT_797;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_798;
    unsigned int zT_799;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_800;
    zT_3D7259E2_SymbolRegistry* zT_802;
    unsigned int zT_803;
    unsigned int zT_804;
    zT_50791B23_Opt_842 zT_807 = {0};
    unsigned char zT_808;
    unsigned int zT_810;
    char* zT_814;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_815;
    unsigned int zT_816;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_817;
    zT_8EED1867_ResolvedTypeTable* zT_818;
    unsigned int zT_819;
    unsigned int zT_820;
    unsigned int zT_823;
    zT_3C598AEF_SymbolKind zT_824;
    zT_8EED1867_ResolvedTypeTable* zT_830;
    unsigned int zT_831;
    zT_BAEE192E_Opt_10 zT_834 = {0};
    unsigned char zT_835;
    char* zT_838;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_839;
    unsigned int zT_840;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_841;
    zT_8EED1867_ResolvedTypeTable* zT_842;
    unsigned int zT_843;
    unsigned int zT_844;
    char* zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    unsigned int zT_849;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_850;
    zT_6B0A7D14_AstStore* zT_852;
    unsigned int zT_853;
    zT_22A7C88B_AstNode zT_856 = {0};
    zT_8143F551_AstKind zT_857;
    zT_6B0A7D14_AstStore* zT_863;
    zT_623E1332_anon_217967 zT_864;
    zT_243D6A41_FnProto* zT_865;
    zT_6B0A7D14_AstStore* zT_866;
    unsigned int zT_867;
    unsigned int zT_870 = 0;
    unsigned int zT_871;
    zT_243D6A41_FnProto zT_872;
    char* zT_874;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_875;
    unsigned int zT_876;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_877;
    unsigned int zT_879;
    unsigned int zT_881;
    zT_8EED1867_ResolvedTypeTable* zT_885;
    unsigned int zT_886;
    zT_BAEE192E_Opt_10 zT_889 = {0};
    unsigned char zT_890;
    zT_338B7C76_TypeRegistry* zT_893;
    unsigned int zT_894;
    unsigned int zT_895;
    unsigned int zT_898;
    unsigned short zT_899;
    unsigned int zT_900;
    unsigned char zT_901;
    unsigned int zT_910 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_911;
    unsigned int zT_912;
    unsigned int zT_913;
    zT_ABC1EBBE_TypeResolveEnv zT_916;
    zT_6B0A7D14_AstStore* zT_917;
    zT_338B7C76_TypeRegistry* zT_918;
    zT_3D7259E2_SymbolRegistry* zT_919;
    zT_D3EB6303_StringInterner* zT_920;
    unsigned int zT_921;
    zT_ABC1EBBE_TypeResolveEnv* zT_923;
    unsigned int zT_924;
    unsigned int zT_929 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_932;
    unsigned int zT_933;
    unsigned int zT_934;
    zT_338B7C76_TypeRegistry* zT_938;
    unsigned int zT_939;
    unsigned int zT_940;
    unsigned int zT_943;
    unsigned short zT_944;
    unsigned int zT_945;
    unsigned char zT_946;
    unsigned int zT_955 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_956;
    unsigned int zT_957;
    unsigned int zT_958;
    zT_338B7C76_TypeRegistry* zT_961;
    unsigned int zT_962;
    unsigned int zT_963;
    unsigned int zT_966;
    unsigned short zT_967;
    unsigned char zT_969;
    unsigned int zT_979 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_980;
    unsigned int zT_981;
    unsigned int zT_982;
    char* zT_985;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_986;
    unsigned int zT_987;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_988;
    zT_3C598AEF_SymbolKind zT_990;
    char* zT_993;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_994;
    unsigned int zT_995;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_996;
    zT_8EED1867_ResolvedTypeTable* zT_997;
    unsigned int zT_998;
    zT_33EF6BFB_TypeKind zT_1003;
    zT_338B7C76_TypeRegistry* zT_1009;
    zT_0BB2A741_SlicePayload* zT_1010;
    unsigned int zT_1011;
    unsigned int zT_1012;
    zT_0BB2A741_SlicePayload zT_1013;
    char* zT_1015;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1016;
    unsigned int zT_1017;
    zT_D3EB6303_StringInterner* zT_1019;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1020;
    unsigned int zT_1022 = 0;
    char* zT_1025;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1026;
    unsigned int zT_1027;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1028;
    zT_8EED1867_ResolvedTypeTable* zT_1029;
    unsigned int zT_1030;
    char* zT_1036;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1037;
    unsigned int zT_1038;
    zT_D3EB6303_StringInterner* zT_1040;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1041;
    unsigned int zT_1043 = 0;
    zT_338B7C76_TypeRegistry* zT_1046;
    unsigned int zT_1047;
    unsigned int zT_1052 = 0;
    char* zT_1054;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1055;
    unsigned int zT_1056;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1057;
    zT_8EED1867_ResolvedTypeTable* zT_1058;
    unsigned int zT_1059;
    unsigned int zT_1060;
    zT_33EF6BFB_TypeKind zT_1062;
    char* zT_1068;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1069;
    unsigned int zT_1070;
    zT_D3EB6303_StringInterner* zT_1072;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1073;
    unsigned int zT_1075 = 0;
    char* zT_1078;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1079;
    unsigned int zT_1080;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1081;
    zT_8EED1867_ResolvedTypeTable* zT_1082;
    unsigned int zT_1083;
    zT_33EF6BFB_TypeKind zT_1088;
    zT_338B7C76_TypeRegistry* zT_1094;
    unsigned int zT_1095;
    unsigned int zT_1096;
    unsigned int zT_1098 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_1101;
    unsigned int zT_1102;
    unsigned int zT_1103;
    zT_8EED1867_ResolvedTypeTable* zT_1105;
    unsigned int zT_1106;
    zT_33EF6BFB_TypeKind zT_1111;
    zT_338B7C76_TypeRegistry* zT_1117;
    zT_457ECFEE_EnumPayload* zT_1118;
    unsigned int zT_1119;
    unsigned int zT_1120;
    zT_457ECFEE_EnumPayload zT_1121;
    unsigned int zT_1123;
    unsigned int zT_1124;
    unsigned short zT_1126;
    unsigned int zT_1127;
    int zT_1129;
    unsigned int zT_1130;
    zT_338B7C76_TypeRegistry* zT_1132;
    zT_D96DCDF2_EnumMember* zT_1133;
    unsigned int zT_1134;
    zT_D96DCDF2_EnumMember zT_1135;
    unsigned int zT_1136;
    zT_8EED1867_ResolvedTypeTable* zT_1138;
    unsigned int zT_1139;
    unsigned int zT_1140;
    int zT_1142;
    unsigned int zT_1143;
    char* zT_1145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1146;
    unsigned int zT_1147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1148;
    zT_8EED1867_ResolvedTypeTable* zT_1149;
    unsigned int zT_1150;
    char* zT_1156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1157;
    unsigned int zT_1158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1159;
    zT_8EED1867_ResolvedTypeTable* zT_1160;
    unsigned int zT_1161;
    int zT_1167;
    unsigned int zT_1168;
    zT_338B7C76_TypeRegistry* zT_1171;
    zT_2DF01B61_FieldEntry* zT_1172;
    unsigned int zT_1173;
    zT_2DF01B61_FieldEntry zT_1174;
    unsigned int zT_1175;
    unsigned int zT_1178;
    zT_338B7C76_TypeRegistry* zT_1180;
    zT_D155D06D_Type* zT_1181;
    unsigned int zT_1182;
    zT_D155D06D_Type zT_1183;
    zT_33EF6BFB_TypeKind zT_1184;
    zT_338B7C76_TypeRegistry* zT_1190;
    zT_E834303C_ArrayPayload* zT_1191;
    unsigned int zT_1192;
    unsigned int zT_1193;
    zT_E834303C_ArrayPayload zT_1194;
    unsigned int zT_1195;
    zT_338B7C76_TypeRegistry* zT_1196;
    unsigned int zT_1197;
    unsigned int zT_1201 = 0;
    char* zT_1203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1204;
    unsigned int zT_1205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1206;
    unsigned int zT_1207;
    zT_8EED1867_ResolvedTypeTable* zT_1208;
    unsigned int zT_1209;
    unsigned int zT_1210;
    int zT_1212;
    unsigned int zT_1214;
    char* zT_1216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1217;
    unsigned int zT_1218;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1219;
    char* zT_1221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1222;
    unsigned int zT_1223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1224;
    unsigned int zT_1225;
    char* zT_1227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1228;
    unsigned int zT_1229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1230;
    unsigned int zT_1231;
    char* zT_1233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1234;
    unsigned int zT_1235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1236;
    unsigned int zT_1237;
    zT_8EED1867_ResolvedTypeTable* zT_1238;
    unsigned int zT_1239;
    zT_8F083A69_Slice_zT_0B42B2F8_u fae;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode base_node;
    unsigned int field_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_bkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_fnm;
    unsigned int base_rt;
    unsigned int base_ident_id;
    zT_50791B23_Opt_842 sym;
    unsigned int base_type_id;
    zT_3A105EF1_Symbol* s;
    unsigned int alias_type_id;
    zT_D155D06D_Type aty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int fi;
    zT_457ECFEE_EnumPayload ep;
    unsigned int estart;
    unsigned int ecount;
    unsigned int ei;
    unsigned int es_mi;
    unsigned int target_mod;
    zT_50791B23_Opt_842 field_sym;
    zT_3A105EF1_Symbol* fs;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1kl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1tl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1v_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fx;
    zT_22A7C88B_AstNode fn_dn;
    zT_243D6A41_FnProto proto;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre1_m;
    zT_BAEE192E_Opt_10 rtt;
    unsigned int rtt_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre3_m;
    unsigned int fn_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre4_m;
    unsigned int rv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre2_m;
    unsigned int rtv;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int resolved_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr1_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr2_m;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u uinm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uiparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u uimsg;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fa1;
    zT_D155D06D_Type base_ty;
    unsigned int fields_start;
    unsigned int fields_count;
    zT_33EF6BFB_TypeKind pre_kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_ok_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_dk_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_nl;
    unsigned int sp;
    unsigned int ep_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u opt_msg;
    unsigned int ep_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u eu_msg;
    zT_406493CE_StructPayload sp_3;
    zT_AF9231A2_UnionPayload up;
    zT_8F083A69_Slice_zT_0B42B2F8_u tag_s;
    unsigned int tag_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ft_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u payload_s;
    unsigned int payload_id;
    unsigned int fpe_count;
    unsigned int fpei;
    zT_2DF01B61_FieldEntry fpe;
    unsigned int payload_res;
    zT_D155D06D_Type payload_rt;
    unsigned int payload_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpe_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfa;
    zT_50791B23_Opt_842 mod_field_sym;
    zT_3A105EF1_Symbol* mfs;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf3;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf1;
    zT_BAEE192E_Opt_10 fn_tid_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf2_m;
    unsigned int fn_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u mff;
    zT_22A7C88B_AstNode dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfp_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_b;
    unsigned int resolved_rt_b;
    zT_0BB2A741_SlicePayload sp_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u len_s;
    unsigned int len_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsl;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptr_s;
    unsigned int ptr_id;
    unsigned int pty;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u faa_m;
    unsigned int es_mi2;
    zT_457ECFEE_EnumPayload ep3;
    unsigned int estart3;
    unsigned int ecount3;
    unsigned int ei3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2b_m;
    unsigned int result;
    zT_D155D06D_Type rt;
    unsigned int elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_3 = "FAE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fae = zT_4;
    zT_6 = fae;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    base_node = zT_17;
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    field_name_id = zT_22;
    zT_24 = "PFA:BK";
    zT_26 = 6;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    pfa_bkm = zT_25;
    zT_27 = pfa_bkm;
    zT_29 = base_node.kind;
    zF_C914CB83_markerWriteInt(zT_27, (unsigned int)((unsigned int)zT_29));
    zT_32 = "PFA:FN";
    zT_34 = 6;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    pfa_fnm = zT_33;
    zT_35 = pfa_fnm;
    zT_36 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_35, zT_36);
    zT_37 = base_node.kind;
    if ((int)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_43 = self;
    zT_44 = node.child_0;
    zT_46 = zF_54F95822_semanticAnalyzerRes(zT_43, zT_44);
    base_rt = zT_46;
    zT_48 = self->store;
    zT_49 = node.child_0;
    zT_52 = zF_53458827_astStoreIdentifier(zT_48, zT_49);
    base_ident_id = zT_52;
    zT_54 = self->symbols;
    zT_55 = self->module_id;
    zT_56 = base_ident_id;
    zT_59 = zF_A398987E_symbolRegistryQuali(zT_54, zT_55, zT_56);
    sym = zT_59;
    zT_60 = sym.has_value;
    if (zT_60) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_529 = self;
    zT_530 = node.child_0;
    zT_532 = zF_54F95822_semanticAnalyzerRes(zT_529, zT_530);
    base_type_id = zT_532;
    if ((int)(base_type_id == (unsigned int)(1))) goto z_bb_71; else goto z_bb_72;
    z_bb_3:
    zT_477 = base_node.kind;
    if ((int)(zT_477 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_59; else goto z_bb_60;
    z_bb_4:
    s = sym.value;
    zT_62 = s->kind;
    if ((int)(zT_62 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    if ((int)(base_rt == (unsigned int)(1))) goto z_bb_57; else goto z_bb_58;
    z_bb_7:
    zT_68 = s->type_id;
    alias_type_id = zT_68;
    if ((int)(alias_type_id != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_159 = s->kind;
    if ((int)(zT_159 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_31; else goto z_bb_32;
    z_bb_9:
    zT_72 = self->registry;
    zT_73 = zT_72->types_items;
    zT_74 = (unsigned int)alias_type_id;
    zT_75 = zT_73[zT_74];
    aty = zT_75;
    zT_76 = aty.kind;
    if ((int)(zT_76 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_82 = self->registry;
    zT_83 = zT_82->tu_items;
    zT_84 = aty.payload_idx;
    zT_85 = (unsigned int)zT_84;
    zT_86 = zT_83[zT_85];
    tp = zT_86;
    zT_88 = tp.fields_start;
    zT_89 = (unsigned int)zT_88;
    fstart = zT_89;
    zT_91 = tp.fields_count;
    zT_92 = (unsigned int)zT_91;
    fcount = zT_92;
    zT_94 = 0;
    zT_95 = (unsigned int)zT_94;
    fi = zT_95;
    goto z_bb_13;
    z_bb_12:
    zT_109 = aty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    if ((int)(fi < fcount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_97 = self->registry;
    zT_98 = zT_97->fe_items;
    zT_99 = fstart + fi;
    zT_100 = zT_98[zT_99];
    zT_101 = zT_100.name_id;
    if ((int)(zT_101 == field_name_id)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_107 = 1;
    zT_108 = fi + zT_107;
    fi = zT_108;
    goto z_bb_13;
    z_bb_17:
    zT_103 = self->type_table;
    zT_104 = node_idx;
    zT_105 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_103, zT_104, zT_105);
    return alias_type_id;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_115 = self->registry;
    zT_116 = zT_115->en_items;
    zT_117 = aty.payload_idx;
    zT_118 = (unsigned int)zT_117;
    zT_119 = zT_116[zT_118];
    ep = zT_119;
    zT_121 = ep.members_start;
    zT_122 = (unsigned int)zT_121;
    estart = zT_122;
    zT_124 = ep.members_count;
    zT_125 = (unsigned int)zT_124;
    ecount = zT_125;
    zT_127 = 0;
    zT_128 = (unsigned int)zT_127;
    ei = zT_128;
    goto z_bb_21;
    z_bb_20:
    zT_142 = aty.kind;
    if ((int)(zT_142 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    if ((int)(ei < ecount)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_130 = self->registry;
    zT_131 = zT_130->em_items;
    zT_132 = estart + ei;
    zT_133 = zT_131[zT_132];
    zT_134 = zT_133.name_id;
    if ((int)(zT_134 == field_name_id)) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_140 = 1;
    zT_141 = ei + zT_140;
    ei = zT_141;
    goto z_bb_21;
    z_bb_25:
    zT_136 = self->type_table;
    zT_137 = node_idx;
    zT_138 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_136, zT_137, zT_138);
    return alias_type_id;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_148 = self->registry;
    zT_149 = alias_type_id;
    zT_150 = field_name_id;
    zT_152 = zF_D2ECD176_typeRegistryErrorSe(zT_148, zT_149, zT_150);
    es_mi = zT_152;
    if ((int)(es_mi != (unsigned int)(4294967295u))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    zT_155 = self->type_table;
    zT_156 = node_idx;
    zT_157 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_155, zT_156, zT_157);
    return alias_type_id;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_165 = s->module_id;
    target_mod = zT_165;
    zT_167 = self->symbols;
    zT_168 = target_mod;
    zT_169 = field_name_id;
    zT_171 = zF_A398987E_symbolRegistryQuali(zT_167, zT_168, zT_169);
    field_sym = zT_171;
    zT_172 = field_sym.has_value;
    if (zT_172) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_5;
    z_bb_33:
    fs = field_sym.value;
    zT_175 = "Q1:FL";
    zT_177 = 5;
    zT_176.ptr = zT_175;
    zT_176.len = zT_177;
    q1fl_m = zT_176;
    zT_178 = q1fl_m;
    zT_180 = fs->flags;
    zF_C914CB83_markerWriteInt(zT_178, (unsigned int)((unsigned int)zT_180));
    zT_183 = "Q1:KL";
    zT_185 = 5;
    zT_184.ptr = zT_183;
    zT_184.len = zT_185;
    q1kl_m = zT_184;
    zT_186 = q1kl_m;
    zT_188 = fs->kind;
    zF_C914CB83_markerWriteInt(zT_186, (unsigned int)((unsigned int)zT_188));
    zT_191 = "Q1:TL";
    zT_193 = 5;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    q1tl_m = zT_192;
    zT_194 = q1tl_m;
    zT_195 = fs->type_id;
    zF_C914CB83_markerWriteInt(zT_194, zT_195);
    zT_198 = "Q1:FN";
    zT_200 = 5;
    zT_199.ptr = zT_198;
    zT_199.len = zT_200;
    q1fn_m = zT_199;
    zT_201 = q1fn_m;
    zT_202 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_201, zT_202);
    zT_203 = fs->flags;
    if ((int)((unsigned short)(zT_203 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_410 = "Q1VF:FN";
    zT_412 = 7;
    zT_411.ptr = zT_410;
    zT_411.len = zT_412;
    q1v_m = zT_411;
    zT_413 = q1v_m;
    zT_414 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_413, zT_414);
    zT_415 = self->type_table;
    zT_416 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_415, zT_416, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_35:
    zT_208 = fs->kind;
    if ((int)(zT_208 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_228 = fs->kind;
    if ((int)(zT_228 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_41; else goto z_bb_42;
    z_bb_37:
    zT_213 = self->type_table;
    zT_214 = node_idx;
    zT_215 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_213, zT_214, zT_215);
    zT_218 = fs->type_id;
    return zT_218;
    z_bb_38:
    zT_219 = fs->type_id;
    if ((int)(zT_219 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_222 = self->type_table;
    zT_223 = node_idx;
    zT_224 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_222, zT_223, zT_224);
    zT_227 = fs->type_id;
    return zT_227;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_234 = fs->decl_node;
    zT_233 = zT_234 != (unsigned int)(0);
    goto z_bb_43;
    z_bb_42:
    zT_233 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_233) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_238 = "Q1FX\n";
    zT_240 = 5;
    zT_239.ptr = zT_238;
    zT_239.len = zT_240;
    q1fx = zT_239;
    zT_241 = q1fx;
    zF_48AC7B3A_markerWrite(zT_241);
    zT_243 = self->store;
    zT_244 = fs->decl_node;
    zT_247 = zF_FCDD1D35_astStoreNodeAt(zT_243, zT_244);
    fn_dn = zT_247;
    zT_248 = fn_dn.kind;
    if ((int)(zT_248 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_34;
    z_bb_46:
    zT_254 = self->store;
    zT_255 = zT_254->fn_protos;
    zT_256 = zT_255.items;
    zT_257 = self->store;
    zT_258 = fs->decl_node;
    zT_261 = zF_8BA26B9E_astStoreNodePayload(zT_257, zT_258);
    zT_262 = (unsigned int)zT_261;
    zT_263 = zT_256[zT_262];
    proto = zT_263;
    zT_265 = "BR:x";
    zT_267 = 4;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    bre1_m = zT_266;
    zT_268 = bre1_m;
    zT_269 = proto.name_id;
    zF_C914CB83_markerWriteInt(zT_268, zT_269);
    zT_271 = proto.return_type_node;
    if ((int)(zT_271 != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_275 = self->type_table;
    zT_276 = proto.return_type_node;
    zT_279 = zF_999DCF51_resolvedTypeTableGe(zT_275, zT_276);
    rtt = zT_279;
    zT_281 = rtt.has_value;
    if (zT_281) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    zT_375 = "BR:dv\n";
    zT_377 = 6;
    zT_376.ptr = zT_375;
    zT_376.len = zT_377;
    bre3_m = zT_376;
    zT_378 = bre3_m;
    zF_48AC7B3A_markerWrite(zT_378);
    zT_380 = self->registry;
    zT_381 = proto.name_id;
    zT_382 = fs->module_id;
    zT_385 = proto.params_start;
    zT_386 = proto.params_count;
    zT_388 = proto.call_conv;
    zT_398 = zF_474336D7_typeRegistryGetOrCr(zT_380, zT_381, zT_382, (unsigned char)(0), (unsigned char)(0), zT_385, zT_386, (unsigned int)(1), zT_388);
    fn_ty = zT_398;
    zT_400 = "BR:ft";
    zT_402 = 5;
    zT_401.ptr = zT_400;
    zT_401.len = zT_402;
    bre4_m = zT_401;
    zT_403 = bre4_m;
    zT_404 = fn_ty;
    zF_C914CB83_markerWriteInt(zT_403, zT_404);
    zT_405 = self->type_table;
    zT_406 = node_idx;
    zT_407 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_405, zT_406, zT_407);
    return fn_ty;
    z_bb_50:
    rv = rtt.value;
    zT_282 = rv;
    goto z_bb_52;
    z_bb_51:
    zT_282 = 0;
    goto z_bb_52;
    z_bb_52:
    rtt_val = zT_282;
    zT_286 = "BR:rt";
    zT_288 = 5;
    zT_287.ptr = zT_286;
    zT_287.len = zT_288;
    bre2_m = zT_287;
    zT_289 = bre2_m;
    zT_290 = rtt_val;
    zF_C914CB83_markerWriteInt(zT_289, zT_290);
    zT_291 = rtt.has_value;
    if (zT_291) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    rtv = rtt.value;
    zT_294 = self->registry;
    zT_295 = proto.name_id;
    zT_296 = fs->module_id;
    zT_299 = proto.params_start;
    zT_300 = proto.params_count;
    zT_301 = rtv;
    zT_302 = proto.call_conv;
    zT_311 = zF_474336D7_typeRegistryGetOrCr(zT_294, zT_295, zT_296, (unsigned char)(0), (unsigned char)(0), zT_299, zT_300, zT_301, zT_302);
    fn_ty = zT_311;
    zT_312 = self->type_table;
    zT_313 = node_idx;
    zT_314 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_312, zT_313, zT_314);
    return fn_ty;
    z_bb_54:
    zT_318 = self->store;
    zT_317.store = zT_318;
    zT_319 = self->registry;
    zT_317.typereg = zT_319;
    zT_320 = self->symbols;
    zT_317.symbol_reg = zT_320;
    zT_321 = self->interner;
    zT_317.interner = zT_321;
    zT_322 = fs->module_id;
    zT_317.module_id = zT_322;
    tre_env = zT_317;
    zT_324 = &tre_env;
    zT_325 = proto.return_type_node;
    zT_330 = zF_F2107C15_resolveTypeExprFull(zT_324, zT_325, (unsigned int)(0));
    resolved_rt = zT_330;
    zT_332 = "BR:treN";
    zT_334 = 7;
    zT_333.ptr = zT_332;
    zT_333.len = zT_334;
    brr1_m = zT_333;
    zT_335 = brr1_m;
    zT_336 = proto.return_type_node;
    zF_C914CB83_markerWriteInt(zT_335, zT_336);
    zT_339 = "BR:treT";
    zT_341 = 7;
    zT_340.ptr = zT_339;
    zT_340.len = zT_341;
    brr2_m = zT_340;
    zT_342 = brr2_m;
    zT_343 = resolved_rt;
    zF_C914CB83_markerWriteInt(zT_342, zT_343);
    if ((int)(resolved_rt != (unsigned int)(18))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_346 = self->type_table;
    zT_347 = proto.return_type_node;
    zT_348 = resolved_rt;
    zF_19B4A07D_resolvedTypeTableSe(zT_346, zT_347, zT_348);
    zT_352 = self->registry;
    zT_353 = proto.name_id;
    zT_354 = fs->module_id;
    zT_357 = proto.params_start;
    zT_358 = proto.params_count;
    zT_359 = resolved_rt;
    zT_360 = proto.call_conv;
    zT_369 = zF_474336D7_typeRegistryGetOrCr(zT_352, zT_353, zT_354, (unsigned char)(0), (unsigned char)(0), zT_357, zT_358, zT_359, zT_360);
    fn_ty = zT_369;
    zT_370 = self->type_table;
    zT_371 = node_idx;
    zT_372 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_370, zT_371, zT_372);
    return fn_ty;
    z_bb_56:
    goto z_bb_49;
    z_bb_57:
    zT_424 = base_node.span_start;
    uisp = zT_424;
    zT_426 = base_node.span_len;
    zT_428 = uisp + (unsigned int)((unsigned int)zT_426);
    uiep = zT_428;
    zT_430 = self->interner;
    zT_431 = base_ident_id;
    zT_433 = zF_9134020D_stringInternerGet(zT_430, zT_431);
    uinm = zT_433;
    zT_435 = "identifier '";
    zT_437 = 12;
    zT_436.ptr = zT_435;
    zT_436.len = zT_437;
    ui1 = zT_436;
    zT_439 = "' is not declared or imported in this module";
    zT_441 = 44;
    zT_440.ptr = zT_439;
    zT_440.len = zT_441;
    ui2 = zT_440;
    zT_444 = 0;
    zT_443[zT_444] = ui1;
    zT_445 = 1;
    zT_443[zT_445] = uinm;
    zT_446 = 2;
    zT_443[zT_446] = ui2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uiparts[_i] = zT_443[_i];
        _i++;
    }
}
    zT_448 = self->interner;
    zT_452 = 0;
    zT_453 = uiparts + zT_452;
    zT_449 = zT_453;
    zT_455 = zF_8C4BFF7C_diagnosticBuilderMa(zT_448, zT_449, (unsigned int)(3));
    uimsg = zT_455;
    zT_456 = self->diag;
    zT_459 = self->source_file_id;
    zT_460 = uisp;
    zT_461 = uiep;
    zT_462 = uimsg;
    zT_470 = zF_C82559AC_diagnosticCollector(zT_456, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3001_UNDEFINED_SYMBOL)), zT_459, zT_460, zT_461, zT_462);
    (void)zT_470;
    zT_471 = self->type_table;
    zT_472 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_471, zT_472, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_58:
    goto z_bb_5;
    z_bb_59:
    zT_483 = self->store;
    zT_484 = node.child_0;
    zT_487 = zF_8BA26B9E_astStoreNodePayload(zT_483, zT_484);
    path_id = zT_487;
    zT_489 = self->module_reg;
    zT_490 = path_id;
    zT_492 = zF_A258E183_moduleRegistryPathT(zT_489, zT_490);
    target = zT_492;
    zT_493 = target.has_value;
    if (zT_493) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_2;
    z_bb_61:
    mtid = target.value;
    zT_496 = self->symbols;
    zT_497 = mtid;
    zT_498 = field_name_id;
    zT_500 = zF_A398987E_symbolRegistryQuali(zT_496, zT_497, zT_498);
    field_sym = zT_500;
    zT_501 = field_sym.has_value;
    if (zT_501) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    fs = field_sym.value;
    zT_503 = fs->flags;
    if ((int)((unsigned short)(zT_503 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    zT_508 = fs->kind;
    if ((int)(zT_508 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_513 = self->type_table;
    zT_514 = node_idx;
    zT_515 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_513, zT_514, zT_515);
    zT_518 = fs->type_id;
    return zT_518;
    z_bb_68:
    zT_519 = fs->type_id;
    if ((int)(zT_519 != (unsigned int)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_522 = self->type_table;
    zT_523 = node_idx;
    zT_524 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_522, zT_523, zT_524);
    zT_527 = fs->type_id;
    return zT_527;
    z_bb_70:
    goto z_bb_66;
    z_bb_71:
    zT_536 = "FB\n";
    zT_538 = 3;
    zT_537.ptr = zT_536;
    zT_537.len = zT_538;
    fa1 = zT_537;
    zT_539 = fa1;
    zF_48AC7B3A_markerWrite(zT_539);
    zT_540 = self->type_table;
    zT_541 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_540, zT_541, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_72:
    zT_547 = self->registry;
    zT_548 = zT_547->types_items;
    zT_549 = (unsigned int)base_type_id;
    zT_550 = zT_548[zT_549];
    base_ty = zT_550;
    zT_552 = 0;
    zT_553 = (unsigned int)zT_552;
    fields_start = zT_553;
    zT_555 = 0;
    zT_556 = (unsigned int)zT_555;
    fields_count = zT_556;
    zT_557 = base_ty.kind;
    if ((int)(zT_557 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_563 = base_ty.kind;
    zT_562 = zT_563 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_75;
    z_bb_74:
    zT_562 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_562) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_569 = base_ty.kind;
    pre_kind = zT_569;
    zT_570 = self->registry;
    zT_571 = zT_570->ptr_items;
    zT_572 = base_ty.payload_idx;
    zT_573 = (unsigned int)zT_572;
    zT_574 = zT_571[zT_573];
    zT_575 = zT_574.base;
    base_type_id = zT_575;
    zT_576 = self->registry;
    zT_577 = zT_576->types_items;
    zT_578 = (unsigned int)base_type_id;
    zT_579 = zT_577[zT_578];
    base_ty = zT_579;
    zT_581 = "FAPR:OK";
    zT_583 = 7;
    zT_582.ptr = zT_581;
    zT_582.len = zT_583;
    fapr_ok_m = zT_582;
    zT_584 = fapr_ok_m;
    zF_C914CB83_markerWriteInt(zT_584, (unsigned int)((unsigned int)pre_kind));
    zT_588 = "FAPR:DK";
    zT_590 = 7;
    zT_589.ptr = zT_588;
    zT_589.len = zT_590;
    fapr_dk_m = zT_589;
    zT_591 = fapr_dk_m;
    zT_593 = base_ty.kind;
    zF_C914CB83_markerWriteInt(zT_591, (unsigned int)((unsigned int)zT_593));
    zT_596 = "\n";
    zT_598 = 1;
    zT_597.ptr = zT_596;
    zT_597.len = zT_598;
    fapr_nl = zT_597;
    zT_599 = fapr_nl;
    zF_48AC7B3A_markerWrite(zT_599);
    goto z_bb_77;
    z_bb_77:
    zT_600 = base_ty.kind;
    if ((int)(zT_600 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_606 = node.span_start;
    sp = zT_606;
    zT_608 = node.span_len;
    zT_610 = sp + (unsigned int)((unsigned int)zT_608);
    ep_1 = zT_610;
    zT_612 = "cannot access field on optional type; use .? to unwrap first";
    zT_614 = 60;
    zT_613.ptr = zT_612;
    zT_613.len = zT_614;
    opt_msg = zT_613;
    zT_615 = self->diag;
    zT_618 = self->source_file_id;
    zT_619 = sp;
    zT_620 = ep_1;
    zT_621 = opt_msg;
    zT_626 = zF_C82559AC_diagnosticCollector(zT_615, (unsigned char)(0), (unsigned short)(3000), zT_618, zT_619, zT_620, zT_621);
    (void)zT_626;
    return (unsigned int)(1);
    z_bb_79:
    zT_628 = base_ty.kind;
    if ((int)(zT_628 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_634 = node.span_start;
    sp = zT_634;
    zT_636 = node.span_len;
    zT_638 = sp + (unsigned int)((unsigned int)zT_636);
    ep_2 = zT_638;
    zT_640 = "cannot access field on error-union type; handle the error first";
    zT_642 = 63;
    zT_641.ptr = zT_640;
    zT_641.len = zT_642;
    eu_msg = zT_641;
    zT_643 = self->diag;
    zT_646 = self->source_file_id;
    zT_647 = sp;
    zT_648 = ep_2;
    zT_649 = eu_msg;
    zT_654 = zF_C82559AC_diagnosticCollector(zT_643, (unsigned char)(0), (unsigned short)(3000), zT_646, zT_647, zT_648, zT_649);
    (void)zT_654;
    return (unsigned int)(1);
    z_bb_81:
    zT_656 = base_ty.kind;
    if ((int)(zT_656 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_82; else goto z_bb_84;
    z_bb_82:
    zT_662 = self->registry;
    zT_663 = zT_662->st_items;
    zT_664 = base_ty.payload_idx;
    zT_665 = (unsigned int)zT_664;
    zT_666 = zT_663[zT_665];
    sp_3 = zT_666;
    zT_667 = sp_3.fields_start;
    zT_668 = (unsigned int)zT_667;
    fields_start = zT_668;
    zT_669 = sp_3.fields_count;
    zT_670 = (unsigned int)zT_669;
    fields_count = zT_670;
    goto z_bb_83;
    z_bb_83:
    zT_1167 = 0;
    zT_1168 = (unsigned int)zT_1167;
    fi = zT_1168;
    goto z_bb_152;
    z_bb_84:
    zT_671 = base_ty.kind;
    if ((int)(zT_671 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_677 = base_ty.kind;
    zT_676 = zT_677 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_87;
    z_bb_86:
    zT_676 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_676) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    zT_683 = self->registry;
    zT_684 = zT_683->un_items;
    zT_685 = base_ty.payload_idx;
    zT_686 = (unsigned int)zT_685;
    zT_687 = zT_684[zT_686];
    up = zT_687;
    zT_688 = up.fields_start;
    zT_689 = (unsigned int)zT_688;
    fields_start = zT_689;
    zT_690 = up.fields_count;
    zT_691 = (unsigned int)zT_690;
    fields_count = zT_691;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_83;
    z_bb_90:
    zT_692 = base_ty.kind;
    if ((int)(zT_692 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_698 = self->registry;
    zT_699 = zT_698->tu_items;
    zT_700 = base_ty.payload_idx;
    zT_701 = (unsigned int)zT_700;
    zT_702 = zT_699[zT_701];
    tp = zT_702;
    zT_704 = "tag";
    zT_706 = 3;
    zT_705.ptr = zT_704;
    zT_705.len = zT_706;
    tag_s = zT_705;
    zT_708 = self->interner;
    zT_709 = tag_s;
    zT_711 = zF_50C274AF_stringInternerInter(zT_708, zT_709);
    tag_id = zT_711;
    if ((int)(field_name_id == tag_id)) goto z_bb_94; else goto z_bb_95;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_791 = base_ty.kind;
    if ((int)(zT_791 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_106; else goto z_bb_108;
    z_bb_94:
    zT_714 = "FT:TAG\n";
    zT_716 = 7;
    zT_715.ptr = zT_714;
    zT_715.len = zT_716;
    ft_m = zT_715;
    zT_717 = ft_m;
    zF_48AC7B3A_markerWrite(zT_717);
    zT_718 = self->type_table;
    zT_719 = node_idx;
    zT_720 = tp.tag_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_718, zT_719, zT_720);
    zT_723 = tp.tag_type;
    return zT_723;
    z_bb_95:
    zT_725 = "payload";
    zT_727 = 7;
    zT_726.ptr = zT_725;
    zT_726.len = zT_727;
    payload_s = zT_726;
    zT_729 = self->interner;
    zT_730 = payload_s;
    zT_732 = zF_50C274AF_stringInternerInter(zT_729, zT_730);
    payload_id = zT_732;
    if ((int)(field_name_id == payload_id)) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_735 = tp.fields_count;
    zT_736 = (unsigned int)zT_735;
    fpe_count = zT_736;
    zT_738 = 0;
    zT_739 = (unsigned int)zT_738;
    fpei = zT_739;
    goto z_bb_98;
    z_bb_97:
    zT_787 = tp.fields_start;
    zT_788 = (unsigned int)zT_787;
    fields_start = zT_788;
    zT_789 = tp.fields_count;
    zT_790 = (unsigned int)zT_789;
    fields_count = zT_790;
    goto z_bb_92;
    z_bb_98:
    if ((int)(fpei < fpe_count)) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_742 = self->registry;
    zT_743 = zT_742->fe_items;
    zT_744 = tp.fields_start;
    zT_746 = (unsigned int)((unsigned int)zT_744) + fpei;
    zT_747 = zT_743[zT_746];
    fpe = zT_747;
    zT_748 = fpe.type_id;
    if ((int)(zT_748 != (unsigned int)(1))) goto z_bb_102; else goto z_bb_103;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_785 = 1;
    zT_786 = fpei + zT_785;
    fpei = zT_786;
    goto z_bb_98;
    z_bb_102:
    zT_752 = fpe.type_id;
    payload_res = zT_752;
    zT_754 = self->registry;
    zT_755 = zT_754->types_items;
    zT_756 = (unsigned int)payload_res;
    zT_757 = zT_755[zT_756];
    payload_rt = zT_757;
    zT_758 = payload_rt.kind;
    if ((int)(zT_758 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_104; else goto z_bb_105;
    z_bb_103:
    goto z_bb_101;
    z_bb_104:
    zT_764 = self->registry;
    zT_765 = zT_764->array_items;
    zT_766 = payload_rt.payload_idx;
    zT_767 = (unsigned int)zT_766;
    zT_768 = zT_765[zT_767];
    zT_769 = zT_768.elem;
    payload_elem = zT_769;
    zT_770 = self->registry;
    zT_771 = payload_elem;
    zT_775 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_770, zT_771, (int)(0));
    payload_res = zT_775;
    goto z_bb_105;
    z_bb_105:
    zT_777 = "FP:PAYLOAD\n";
    zT_779 = 11;
    zT_778.ptr = zT_777;
    zT_778.len = zT_779;
    fpe_m = zT_778;
    zT_780 = fpe_m;
    zF_48AC7B3A_markerWrite(zT_780);
    zT_781 = self->type_table;
    zT_782 = node_idx;
    zT_783 = payload_res;
    zF_19B4A07D_resolvedTypeTableSe(zT_781, zT_782, zT_783);
    return payload_res;
    z_bb_106:
    zT_797 = "MFA\n";
    zT_799 = 4;
    zT_798.ptr = zT_797;
    zT_798.len = zT_799;
    mfa = zT_798;
    zT_800 = mfa;
    zF_48AC7B3A_markerWrite(zT_800);
    zT_802 = self->symbols;
    zT_803 = base_ty.module_id;
    zT_804 = field_name_id;
    zT_807 = zF_A398987E_symbolRegistryQuali(zT_802, zT_803, zT_804);
    mod_field_sym = zT_807;
    zT_808 = mod_field_sym.has_value;
    if (zT_808) goto z_bb_109; else goto z_bb_111;
    z_bb_107:
    goto z_bb_92;
    z_bb_108:
    zT_1003 = base_ty.kind;
    if ((int)(zT_1003 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_126; else goto z_bb_128;
    z_bb_109:
    mfs = mod_field_sym.value;
    zT_810 = mfs->type_id;
    if ((int)(zT_810 != (unsigned int)(0))) goto z_bb_112; else goto z_bb_113;
    z_bb_110:
    zT_997 = self->type_table;
    zT_998 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_997, zT_998, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_111:
    zT_993 = "MF3\n";
    zT_995 = 4;
    zT_994.ptr = zT_993;
    zT_994.len = zT_995;
    mf3 = zT_994;
    zT_996 = mf3;
    zF_48AC7B3A_markerWrite(zT_996);
    goto z_bb_110;
    z_bb_112:
    zT_814 = "MF1\n";
    zT_816 = 4;
    zT_815.ptr = zT_814;
    zT_815.len = zT_816;
    mf1 = zT_815;
    zT_817 = mf1;
    zF_48AC7B3A_markerWrite(zT_817);
    zT_818 = self->type_table;
    zT_819 = node_idx;
    zT_820 = mfs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_818, zT_819, zT_820);
    zT_823 = mfs->type_id;
    return zT_823;
    z_bb_113:
    zT_824 = mfs->kind;
    if ((int)(zT_824 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_830 = self->type_table;
    zT_831 = mfs->decl_node;
    zT_834 = zF_999DCF51_resolvedTypeTableGe(zT_830, zT_831);
    fn_tid_opt = zT_834;
    zT_835 = fn_tid_opt.has_value;
    if (zT_835) goto z_bb_116; else goto z_bb_117;
    z_bb_115:
    zT_985 = "MF2";
    zT_987 = 3;
    zT_986.ptr = zT_985;
    zT_986.len = zT_987;
    mf2_m = zT_986;
    zT_988 = mf2_m;
    zT_990 = mfs->kind;
    zF_C914CB83_markerWriteInt(zT_988, (unsigned int)((unsigned int)zT_990));
    goto z_bb_110;
    z_bb_116:
    fn_tid = fn_tid_opt.value;
    zT_838 = "MF1\n";
    zT_840 = 4;
    zT_839.ptr = zT_838;
    zT_839.len = zT_840;
    mf1 = zT_839;
    zT_841 = mf1;
    zF_48AC7B3A_markerWrite(zT_841);
    zT_842 = self->type_table;
    zT_843 = node_idx;
    zT_844 = fn_tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_842, zT_843, zT_844);
    return fn_tid;
    z_bb_117:
    zT_847 = "MFF\n";
    zT_849 = 4;
    zT_848.ptr = zT_847;
    zT_848.len = zT_849;
    mff = zT_848;
    zT_850 = mff;
    zF_48AC7B3A_markerWrite(zT_850);
    zT_852 = self->store;
    zT_853 = mfs->decl_node;
    zT_856 = zF_FCDD1D35_astStoreNodeAt(zT_852, zT_853);
    dn = zT_856;
    zT_857 = dn.kind;
    if ((int)(zT_857 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_863 = self->store;
    zT_864 = zT_863->fn_protos;
    zT_865 = zT_864.items;
    zT_866 = self->store;
    zT_867 = mfs->decl_node;
    zT_870 = zF_8BA26B9E_astStoreNodePayload(zT_866, zT_867);
    zT_871 = (unsigned int)zT_870;
    zT_872 = zT_865[zT_871];
    proto = zT_872;
    zT_874 = "MFP";
    zT_876 = 3;
    zT_875.ptr = zT_874;
    zT_875.len = zT_876;
    mfp_m = zT_875;
    zT_877 = mfp_m;
    zT_879 = proto.params_start;
    zF_C914CB83_markerWriteInt(zT_877, (unsigned int)((unsigned int)zT_879));
    zT_881 = proto.return_type_node;
    if ((int)(zT_881 != (unsigned int)(0))) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    goto z_bb_115;
    z_bb_120:
    zT_885 = self->type_table;
    zT_886 = proto.return_type_node;
    zT_889 = zF_999DCF51_resolvedTypeTableGe(zT_885, zT_886);
    rtt = zT_889;
    zT_890 = rtt.has_value;
    if (zT_890) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_961 = self->registry;
    zT_962 = proto.name_id;
    zT_963 = mfs->module_id;
    zT_966 = proto.params_start;
    zT_967 = proto.params_count;
    zT_969 = proto.call_conv;
    zT_979 = zF_474336D7_typeRegistryGetOrCr(zT_961, zT_962, zT_963, (unsigned char)(0), (unsigned char)(0), zT_966, zT_967, (unsigned int)(1), zT_969);
    fn_ty = zT_979;
    zT_980 = self->type_table;
    zT_981 = node_idx;
    zT_982 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_980, zT_981, zT_982);
    return fn_ty;
    z_bb_122:
    rtv = rtt.value;
    zT_893 = self->registry;
    zT_894 = proto.name_id;
    zT_895 = mfs->module_id;
    zT_898 = proto.params_start;
    zT_899 = proto.params_count;
    zT_900 = rtv;
    zT_901 = proto.call_conv;
    zT_910 = zF_474336D7_typeRegistryGetOrCr(zT_893, zT_894, zT_895, (unsigned char)(0), (unsigned char)(0), zT_898, zT_899, zT_900, zT_901);
    fn_ty = zT_910;
    zT_911 = self->type_table;
    zT_912 = node_idx;
    zT_913 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_911, zT_912, zT_913);
    return fn_ty;
    z_bb_123:
    zT_917 = self->store;
    zT_916.store = zT_917;
    zT_918 = self->registry;
    zT_916.typereg = zT_918;
    zT_919 = self->symbols;
    zT_916.symbol_reg = zT_919;
    zT_920 = self->interner;
    zT_916.interner = zT_920;
    zT_921 = mfs->module_id;
    zT_916.module_id = zT_921;
    tre_env_b = zT_916;
    zT_923 = &tre_env_b;
    zT_924 = proto.return_type_node;
    zT_929 = zF_F2107C15_resolveTypeExprFull(zT_923, zT_924, (unsigned int)(0));
    resolved_rt_b = zT_929;
    if ((int)(resolved_rt_b != (unsigned int)(18))) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    zT_932 = self->type_table;
    zT_933 = proto.return_type_node;
    zT_934 = resolved_rt_b;
    zF_19B4A07D_resolvedTypeTableSe(zT_932, zT_933, zT_934);
    zT_938 = self->registry;
    zT_939 = proto.name_id;
    zT_940 = mfs->module_id;
    zT_943 = proto.params_start;
    zT_944 = proto.params_count;
    zT_945 = resolved_rt_b;
    zT_946 = proto.call_conv;
    zT_955 = zF_474336D7_typeRegistryGetOrCr(zT_938, zT_939, zT_940, (unsigned char)(0), (unsigned char)(0), zT_943, zT_944, zT_945, zT_946);
    fn_ty = zT_955;
    zT_956 = self->type_table;
    zT_957 = node_idx;
    zT_958 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_956, zT_957, zT_958);
    return fn_ty;
    z_bb_125:
    goto z_bb_121;
    z_bb_126:
    zT_1009 = self->registry;
    zT_1010 = zT_1009->slice_items;
    zT_1011 = base_ty.payload_idx;
    zT_1012 = (unsigned int)zT_1011;
    zT_1013 = zT_1010[zT_1012];
    sp_4 = zT_1013;
    zT_1015 = "len";
    zT_1017 = 3;
    zT_1016.ptr = zT_1015;
    zT_1016.len = zT_1017;
    len_s = zT_1016;
    zT_1019 = self->interner;
    zT_1020 = len_s;
    zT_1022 = zF_50C274AF_stringInternerInter(zT_1019, zT_1020);
    len_id = zT_1022;
    if ((int)(field_name_id == len_id)) goto z_bb_129; else goto z_bb_130;
    z_bb_127:
    goto z_bb_107;
    z_bb_128:
    zT_1062 = base_ty.kind;
    if ((int)(zT_1062 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_133; else goto z_bb_135;
    z_bb_129:
    zT_1025 = "FSL:USIZE\n";
    zT_1027 = 10;
    zT_1026.ptr = zT_1025;
    zT_1026.len = zT_1027;
    fsl = zT_1026;
    zT_1028 = fsl;
    zF_48AC7B3A_markerWrite(zT_1028);
    zT_1029 = self->type_table;
    zT_1030 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1029, zT_1030, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_130:
    zT_1036 = "ptr";
    zT_1038 = 3;
    zT_1037.ptr = zT_1036;
    zT_1037.len = zT_1038;
    ptr_s = zT_1037;
    zT_1040 = self->interner;
    zT_1041 = ptr_s;
    zT_1043 = zF_50C274AF_stringInternerInter(zT_1040, zT_1041);
    ptr_id = zT_1043;
    if ((int)(field_name_id == ptr_id)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_1046 = self->registry;
    zT_1047 = sp_4.elem;
    zT_1052 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1046, zT_1047, (int)(0));
    pty = zT_1052;
    zT_1054 = "FSP:PTR\n";
    zT_1056 = 8;
    zT_1055.ptr = zT_1054;
    zT_1055.len = zT_1056;
    fsp = zT_1055;
    zT_1057 = fsp;
    zF_48AC7B3A_markerWrite(zT_1057);
    zT_1058 = self->type_table;
    zT_1059 = node_idx;
    zT_1060 = pty;
    zF_19B4A07D_resolvedTypeTableSe(zT_1058, zT_1059, zT_1060);
    return pty;
    z_bb_132:
    goto z_bb_127;
    z_bb_133:
    zT_1068 = "len";
    zT_1070 = 3;
    zT_1069.ptr = zT_1068;
    zT_1069.len = zT_1070;
    len_s = zT_1069;
    zT_1072 = self->interner;
    zT_1073 = len_s;
    zT_1075 = zF_50C274AF_stringInternerInter(zT_1072, zT_1073);
    len_id = zT_1075;
    if ((int)(field_name_id == len_id)) goto z_bb_136; else goto z_bb_137;
    z_bb_134:
    goto z_bb_127;
    z_bb_135:
    zT_1088 = base_ty.kind;
    if ((int)(zT_1088 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_138; else goto z_bb_140;
    z_bb_136:
    zT_1078 = "FAA:USIZE\n";
    zT_1080 = 10;
    zT_1079.ptr = zT_1078;
    zT_1079.len = zT_1080;
    faa_m = zT_1079;
    zT_1081 = faa_m;
    zF_48AC7B3A_markerWrite(zT_1081);
    zT_1082 = self->type_table;
    zT_1083 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1082, zT_1083, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_1094 = self->registry;
    zT_1095 = base_type_id;
    zT_1096 = field_name_id;
    zT_1098 = zF_D2ECD176_typeRegistryErrorSe(zT_1094, zT_1095, zT_1096);
    es_mi2 = zT_1098;
    if ((int)(es_mi2 != (unsigned int)(4294967295u))) goto z_bb_141; else goto z_bb_142;
    z_bb_139:
    goto z_bb_134;
    z_bb_140:
    zT_1111 = base_ty.kind;
    if ((int)(zT_1111 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_143; else goto z_bb_145;
    z_bb_141:
    zT_1101 = self->type_table;
    zT_1102 = node_idx;
    zT_1103 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1101, zT_1102, zT_1103);
    return base_type_id;
    z_bb_142:
    zT_1105 = self->type_table;
    zT_1106 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1105, zT_1106, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_143:
    zT_1117 = self->registry;
    zT_1118 = zT_1117->en_items;
    zT_1119 = base_ty.payload_idx;
    zT_1120 = (unsigned int)zT_1119;
    zT_1121 = zT_1118[zT_1120];
    ep3 = zT_1121;
    zT_1123 = ep3.members_start;
    zT_1124 = (unsigned int)zT_1123;
    estart3 = zT_1124;
    zT_1126 = ep3.members_count;
    zT_1127 = (unsigned int)zT_1126;
    ecount3 = zT_1127;
    zT_1129 = 0;
    zT_1130 = (unsigned int)zT_1129;
    ei3 = zT_1130;
    goto z_bb_146;
    goto z_bb_139;
    z_bb_145:
    zT_1156 = "FF\n";
    zT_1158 = 3;
    zT_1157.ptr = zT_1156;
    zT_1157.len = zT_1158;
    fnf = zT_1157;
    zT_1159 = fnf;
    zF_48AC7B3A_markerWrite(zT_1159);
    zT_1160 = self->type_table;
    zT_1161 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1160, zT_1161, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_146:
    if ((int)(ei3 < ecount3)) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_1132 = self->registry;
    zT_1133 = zT_1132->em_items;
    zT_1134 = estart3 + ei3;
    zT_1135 = zT_1133[zT_1134];
    zT_1136 = zT_1135.name_id;
    if ((int)(zT_1136 == field_name_id)) goto z_bb_150; else goto z_bb_151;
    z_bb_148:
    zT_1145 = "FF\n";
    zT_1147 = 3;
    zT_1146.ptr = zT_1145;
    zT_1146.len = zT_1147;
    fnf = zT_1146;
    zT_1148 = fnf;
    zF_48AC7B3A_markerWrite(zT_1148);
    zT_1149 = self->type_table;
    zT_1150 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1149, zT_1150, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_149:
    zT_1142 = 1;
    zT_1143 = ei3 + zT_1142;
    ei3 = zT_1143;
    goto z_bb_146;
    z_bb_150:
    zT_1138 = self->type_table;
    zT_1139 = node_idx;
    zT_1140 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1138, zT_1139, zT_1140);
    return base_type_id;
    z_bb_151:
    goto z_bb_149;
    z_bb_152:
    if ((int)(fi < fields_count)) goto z_bb_153; else goto z_bb_154;
    z_bb_153:
    zT_1171 = self->registry;
    zT_1172 = zT_1171->fe_items;
    zT_1173 = fields_start + fi;
    zT_1174 = zT_1172[zT_1173];
    fe = zT_1174;
    zT_1175 = fe.name_id;
    if ((int)(zT_1175 == field_name_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_154:
    zT_1216 = "NF\n";
    zT_1218 = 3;
    zT_1217.ptr = zT_1216;
    zT_1217.len = zT_1218;
    fnf2 = zT_1217;
    zT_1219 = fnf2;
    zF_48AC7B3A_markerWrite(zT_1219);
    zT_1221 = "FF2:N";
    zT_1223 = 5;
    zT_1222.ptr = zT_1221;
    zT_1222.len = zT_1223;
    ff2n_m = zT_1222;
    zT_1224 = ff2n_m;
    zT_1225 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1224, zT_1225);
    zT_1227 = "FF2:F";
    zT_1229 = 5;
    zT_1228.ptr = zT_1227;
    zT_1228.len = zT_1229;
    ff2f_m = zT_1228;
    zT_1230 = ff2f_m;
    zT_1231 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_1230, zT_1231);
    zT_1233 = "FF2:B";
    zT_1235 = 5;
    zT_1234.ptr = zT_1233;
    zT_1234.len = zT_1235;
    ff2b_m = zT_1234;
    zT_1236 = ff2b_m;
    zT_1237 = base_type_id;
    zF_C914CB83_markerWriteInt(zT_1236, zT_1237);
    zT_1238 = self->type_table;
    zT_1239 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1238, zT_1239, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_155:
    goto z_bb_152;
    z_bb_156:
    zT_1178 = fe.type_id;
    result = zT_1178;
    zT_1180 = self->registry;
    zT_1181 = zT_1180->types_items;
    zT_1182 = (unsigned int)result;
    zT_1183 = zT_1181[zT_1182];
    rt = zT_1183;
    zT_1184 = rt.kind;
    if ((int)(zT_1184 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_1212 = 1;
    zT_1214 = fi + (unsigned int)((unsigned int)zT_1212);
    fi = zT_1214;
    goto z_bb_155;
    z_bb_158:
    zT_1190 = self->registry;
    zT_1191 = zT_1190->array_items;
    zT_1192 = rt.payload_idx;
    zT_1193 = (unsigned int)zT_1192;
    zT_1194 = zT_1191[zT_1193];
    zT_1195 = zT_1194.elem;
    elem = zT_1195;
    zT_1196 = self->registry;
    zT_1197 = elem;
    zT_1201 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1196, zT_1197, (int)(0));
    result = zT_1201;
    goto z_bb_159;
    z_bb_159:
    zT_1203 = "FF:R";
    zT_1205 = 4;
    zT_1204.ptr = zT_1203;
    zT_1204.len = zT_1205;
    ff_m = zT_1204;
    zT_1206 = ff_m;
    zT_1207 = result;
    zF_C914CB83_markerWriteInt(zT_1206, zT_1207);
    zT_1208 = self->type_table;
    zT_1209 = node_idx;
    zT_1210 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_1208, zT_1209, zT_1210);
    return result;
}

/* semanticAnalyzerPackedGateGrow */
void zF_151B0DD7_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_9154F007_EU_232 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->packed_gate_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_gate_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_gate_items = ndst;
    self->packed_gate_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->packed_gate_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_gate_items;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerPackedGateMark */
void zF_E3B2C29D_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->packed_gate_len;
    zT_3 = self->packed_gate_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_151B0DD7_semanticAnalyzerPac(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->packed_gate_items;
    zT_7 = self->packed_gate_len;
    zT_6[zT_7] = node_idx;
    zT_8 = self->packed_gate_len;
    self->packed_gate_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedGateSeen */
int zF_5BBD6EB3_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_12;
    unsigned int gi;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    gi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_gate_len;
    if ((int)(gi < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_items;
    zT_8 = zT_7[gi];
    if ((int)(zT_8 == node_idx)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_12 = gi + (unsigned int)(1);
    gi = zT_12;
    goto z_bb_1;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    goto z_bb_4;
}

/* semanticAnalyzerPackedStructCacheGrow */
void zF_86D8CE03_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_9154F007_EU_232 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_9154F007_EU_232 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int* zT_58;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    unsigned char* raw2;
    unsigned int* ndst2;
    unsigned int ci2;
    zT_2 = self->packed_struct_cache_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_cache_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_struct_cache_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_struct_tids = ndst;
    zT_37 = self->expected_type_stack_alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_13; else goto z_bb_14;
    z_bb_9:
    zT_30 = self->packed_struct_cache_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
    z_bb_13:
    pal_trap();
    z_bb_14:
    zT_46 = zT_44.data.payload;
    goto z_bb_15;
    z_bb_15:
    raw2 = zT_46;
    zT_49 = (unsigned int*)raw2;
    ndst2 = zT_49;
    zT_50 = self->packed_struct_cache_len;
    if ((int)(zT_50 > (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    ci2 = zT_55;
    goto z_bb_18;
    z_bb_17:
    self->packed_struct_decl_nodes = ndst2;
    self->packed_struct_cache_cap = new_cap;
    return;
    z_bb_18:
    zT_56 = self->packed_struct_cache_len;
    if ((int)(ci2 < zT_56)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_58 = self->packed_struct_decl_nodes;
    zT_59 = zT_58[ci2];
    ndst2[ci2] = zT_59;
    goto z_bb_21;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_61 = ci2 + (unsigned int)(1);
    ci2 = zT_61;
    goto z_bb_18;
}

/* semanticAnalyzerPackedStructCacheAppend */
void zF_2C47D4E0_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_3 = self->packed_struct_cache_len;
    zT_4 = self->packed_struct_cache_cap;
    if ((int)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_86D8CE03_semanticAnalyzerPac(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = self->packed_struct_cache_len;
    zT_7[zT_8] = struct_tid;
    zT_9 = self->packed_struct_decl_nodes;
    zT_10 = self->packed_struct_cache_len;
    zT_9[zT_10] = decl_node;
    zT_11 = self->packed_struct_cache_len;
    self->packed_struct_cache_len = (unsigned int)(zT_11 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCheckedStructTidsGrow */
void zF_055533B0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_9154F007_EU_232 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->checked_struct_tids_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->checked_struct_tids_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->checked_struct_tids_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->checked_struct_tids = ndst;
    self->checked_struct_tids_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->checked_struct_tids_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->checked_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerCheckedStructTidsAppend */
void zF_B5A1E8BB_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->checked_struct_tids_len;
    zT_3 = self->checked_struct_tids_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_055533B0_semanticAnalyzerChe(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->checked_struct_tids;
    zT_7 = self->checked_struct_tids_len;
    zT_6[zT_7] = struct_tid;
    zT_8 = self->checked_struct_tids_len;
    self->checked_struct_tids_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedFieldTypeAllowed */
int zF_E42B9323_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, int allow_packed_struct_type) {
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    int zT_31;
    unsigned char zT_32;
    zT_33EF6BFB_TypeKind zT_38;
    zT_338B7C76_TypeRegistry* zT_43;
    unsigned int zT_44;
    int zT_46 = 0;
    zT_338B7C76_TypeRegistry* zT_50;
    unsigned int zT_51;
    unsigned int zT_53 = 0;
    int zT_56;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    zT_338B7C76_TypeRegistry* zT_62;
    unsigned int zT_63;
    int zT_65 = 0;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    int zT_72 = 0;
    zT_D155D06D_Type ty;
    unsigned int ebt;
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ty = zT_12;
    zT_13 = ty.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_19 = ty.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    if (allow_packed_struct_type) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = ty.kind;
    zT_25 = zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_9;
    z_bb_8:
    zT_25 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_25) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = ty.flags;
    zT_31 = (unsigned char)(zT_32 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_31 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_31) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    zT_38 = ty.kind;
    if ((int)(zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_43 = self->registry;
    zT_44 = tid;
    zT_46 = zF_A3BA89EA_typeRegistryEnumHas(zT_43, zT_44);
    if ((int)(!zT_46)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = self->registry;
    zT_70 = tid;
    zT_72 = zF_3290E9C4_typeRegistryIsInteg(zT_69, zT_70);
    return zT_72;
    z_bb_17:
    return (int)(0);
    z_bb_18:
    zT_50 = self->registry;
    zT_51 = tid;
    zT_53 = zF_014D7530_typeRegistryEnumBac(zT_50, zT_51);
    ebt = zT_53;
    if ((int)(ebt == (unsigned int)(18))) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_58 = self->registry;
    zT_59 = zT_58->types_len;
    zT_56 = (unsigned int)((unsigned int)ebt) >= zT_59;
    goto z_bb_21;
    z_bb_20:
    zT_56 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_56) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (int)(0);
    z_bb_23:
    zT_62 = self->registry;
    zT_63 = ebt;
    zT_65 = zF_B664AC19_typeRegistryIsUnsig(zT_62, zT_63);
    if ((int)(!zT_65)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (int)(0);
    z_bb_25:
    return (int)(1);
}

/* semanticAnalyzerGatePackedFields */
void zF_C26EF425_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_13;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    int zT_20 = 0;
    zT_38C12417_SemanticAnalyzer* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int* zT_38;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_47;
    unsigned char zT_49;
    unsigned char zT_51;
    zT_ABC1EBBE_TypeResolveEnv zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_3D7259E2_SymbolRegistry* zT_58;
    zT_D3EB6303_StringInterner* zT_59;
    zT_ABC1EBBE_TypeResolveEnv* zT_61;
    unsigned int zT_62;
    unsigned int zT_66 = 0;
    int zT_69;
    unsigned char zT_72;
    zT_38C12417_SemanticAnalyzer* zT_73;
    unsigned int zT_74;
    int zT_77 = 0;
    zT_338B7C76_TypeRegistry* zT_78;
    unsigned int zT_79;
    unsigned char zT_81 = 0;
    unsigned char zT_84;
    unsigned char zT_85;
    unsigned int zT_89;
    unsigned int zT_91;
    unsigned int zT_93;
    char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_F85C5DED_DiagnosticCollector* zT_100;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_111 = 0;
    char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_F85C5DED_DiagnosticCollector* zT_116;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_127 = 0;
    unsigned int zT_129;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u pw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pg_msg;
    zT_4 = self->store;
    zT_5 = struct_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((int)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = node.flags;
    if ((int)((unsigned char)(zT_13 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = self;
    zT_19 = struct_node_idx;
    zT_20 = zF_5BBD6EB3_semanticAnalyzerPac(zT_18, zT_19);
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_21 = self;
    zT_22 = struct_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_21, zT_22);
    zT_24 = self->store;
    zT_25 = struct_node_idx;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    children = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = children.len;
    if ((int)(ci < zT_32)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self->store;
    zT_38 = children.ptr;
    zT_36 = zT_38[ci];
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    fd = zT_40;
    zT_41 = fd.kind;
    if ((int)(zT_41 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_129 = ci + (unsigned int)(1);
    ci = zT_129;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_47 = fd.child_0;
    type_node = zT_47;
    zT_49 = 0;
    gate_state = zT_49;
    zT_51 = 0;
    gate_wide = zT_51;
    if ((int)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_56 = self->store;
    zT_55.store = zT_56;
    zT_57 = self->registry;
    zT_55.typereg = zT_57;
    zT_58 = self->symbols;
    zT_55.symbol_reg = zT_58;
    zT_59 = self->interner;
    zT_55.interner = zT_59;
    zT_55.module_id = module_id;
    tre_env = zT_55;
    zT_61 = &tre_env;
    zT_62 = type_node;
    zT_66 = zF_F2107C15_resolveTypeExprFull(zT_61, zT_62, (unsigned int)(0));
    ft = zT_66;
    if ((int)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((int)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_69 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_69 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_69) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_72 = 1;
    gate_state = zT_72;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_73 = self;
    zT_74 = ft;
    zT_77 = zF_E42B9323_semanticAnalyzerPac(zT_73, zT_74, (int)(1));
    if (zT_77) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_78 = self->registry;
    zT_79 = ft;
    zT_81 = zF_655972D5_typeRegistryIntWidt(zT_78, zT_79);
    if ((int)(zT_81 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_84 = 1;
    gate_wide = zT_84;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_85 = 1;
    gate_state = zT_85;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_89 = fd.span_start;
    fsp = zT_89;
    zT_91 = fd.span_len;
    zT_93 = fsp + (unsigned int)((unsigned int)zT_91);
    fep = zT_93;
    if ((int)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_97 = "packed struct field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_99 = 95;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    pw_msg = zT_98;
    zT_100 = self->diag;
    zT_103 = self->source_file_id;
    zT_104 = fsp;
    zT_105 = fep;
    zT_106 = pw_msg;
    zT_111 = zF_C82559AC_diagnosticCollector(zT_100, (unsigned char)(0), (unsigned short)(3000), zT_103, zT_104, zT_105, zT_106);
    (void)zT_111;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_113 = "packed struct fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed struct";
    zT_115 = 111;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    pg_msg = zT_114;
    zT_116 = self->diag;
    zT_119 = self->source_file_id;
    zT_120 = fsp;
    zT_121 = fep;
    zT_122 = pg_msg;
    zT_127 = zF_C82559AC_diagnosticCollector(zT_116, (unsigned char)(0), (unsigned short)(3000), zT_119, zT_120, zT_121, zT_122);
    (void)zT_127;
    goto z_bb_29;
}

/* semanticAnalyzerMaybeGateAliasDecl */
void zF_FC6E31C6_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned int zT_11;
    unsigned char zT_13;
    zT_8143F551_AstKind zT_14;
    zT_8143F551_AstKind zT_19;
    unsigned char zT_24;
    unsigned char zT_29;
    zT_8143F551_AstKind zT_30;
    int zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_44 = {0};
    zT_8143F551_AstKind zT_45;
    unsigned int zT_50;
    zT_8143F551_AstKind zT_51;
    int zT_56;
    unsigned char zT_57;
    unsigned int zT_62;
    unsigned char zT_63;
    zT_38C12417_SemanticAnalyzer* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_38C12417_SemanticAnalyzer* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = decl_node;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    dnode = zT_9;
    zT_11 = 0;
    target = zT_11;
    zT_13 = 0;
    is_union = zT_13;
    zT_14 = dnode.kind;
    if ((int)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_19 = dnode.kind;
    if ((int)(zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_24 = dnode.flags;
    if ((int)((unsigned char)(zT_24 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_30 = dnode.kind;
    if ((int)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_29 = 1;
    is_union = zT_29;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_36 = dnode.child_1;
    zT_35 = zT_36 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_35 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_35) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_40 = self->store;
    zT_41 = dnode.child_1;
    zT_44 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    inn = zT_44;
    zT_45 = inn.kind;
    if ((int)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_50 = dnode.child_1;
    target = zT_50;
    goto z_bb_17;
    z_bb_17:
    zT_51 = inn.kind;
    if ((int)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_57 = inn.flags;
    zT_56 = (unsigned char)(zT_57 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_56 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_56) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_62 = dnode.child_1;
    target = zT_62;
    zT_63 = 1;
    is_union = zT_63;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((int)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_68 = self;
    zT_69 = target;
    zT_70 = module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_68, zT_69, zT_70);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_71 = self;
    zT_72 = target;
    zT_73 = module_id;
    zF_F705063A_semanticAnalyzerGat(zT_71, zT_72, zT_73);
    goto z_bb_26;
}

/* semanticAnalyzerGateModulePackedDecl */
void zF_6A91A8CC_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned char zT_12;
    zT_8143F551_AstKind zT_13;
    zT_8143F551_AstKind zT_18;
    unsigned char zT_23;
    unsigned char zT_28;
    zT_8143F551_AstKind zT_29;
    int zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    unsigned int zT_49;
    zT_8143F551_AstKind zT_50;
    int zT_55;
    unsigned char zT_56;
    unsigned int zT_61;
    unsigned char zT_62;
    zT_38C12417_SemanticAnalyzer* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_38C12417_SemanticAnalyzer* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    target = zT_10;
    zT_12 = 0;
    is_union = zT_12;
    zT_13 = dnode.kind;
    if ((int)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_18 = dnode.kind;
    if ((int)(zT_18 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_23 = dnode.flags;
    if ((int)((unsigned char)(zT_23 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_29 = dnode.kind;
    if ((int)(zT_29 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_28 = 1;
    is_union = zT_28;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_35 = dnode.child_1;
    zT_34 = zT_35 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_34 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_34) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_39 = self->store;
    zT_40 = dnode.child_1;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_39, zT_40);
    inn = zT_43;
    zT_44 = inn.kind;
    if ((int)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_49 = dnode.child_1;
    target = zT_49;
    goto z_bb_17;
    z_bb_17:
    zT_50 = inn.kind;
    if ((int)(zT_50 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_56 = inn.flags;
    zT_55 = (unsigned char)(zT_56 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_55 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_55) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_61 = dnode.child_1;
    target = zT_61;
    zT_62 = 1;
    is_union = zT_62;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((int)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_67 = self;
    zT_68 = target;
    zT_69 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_67, zT_68, zT_69);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_71 = self;
    zT_72 = target;
    zT_73 = self->module_id;
    zF_F705063A_semanticAnalyzerGat(zT_71, zT_72, zT_73);
    goto z_bb_26;
}

/* semanticAnalyzerGatePackedUnionMembers */
void zF_F705063A_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int union_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_13;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    int zT_20 = 0;
    zT_38C12417_SemanticAnalyzer* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int* zT_38;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_47;
    unsigned char zT_49;
    unsigned char zT_51;
    zT_ABC1EBBE_TypeResolveEnv zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_3D7259E2_SymbolRegistry* zT_58;
    zT_D3EB6303_StringInterner* zT_59;
    zT_ABC1EBBE_TypeResolveEnv* zT_61;
    unsigned int zT_62;
    unsigned int zT_66 = 0;
    int zT_69;
    unsigned char zT_72;
    zT_38C12417_SemanticAnalyzer* zT_73;
    unsigned int zT_74;
    int zT_77 = 0;
    zT_338B7C76_TypeRegistry* zT_78;
    unsigned int zT_79;
    unsigned char zT_81 = 0;
    unsigned char zT_84;
    unsigned char zT_85;
    unsigned int zT_89;
    unsigned int zT_91;
    unsigned int zT_93;
    char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_F85C5DED_DiagnosticCollector* zT_100;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_111 = 0;
    char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_F85C5DED_DiagnosticCollector* zT_116;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_127 = 0;
    unsigned int zT_129;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u puw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pgu_msg;
    zT_4 = self->store;
    zT_5 = union_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((int)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = node.flags;
    if ((int)((unsigned char)(zT_13 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = self;
    zT_19 = union_node_idx;
    zT_20 = zF_5BBD6EB3_semanticAnalyzerPac(zT_18, zT_19);
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_21 = self;
    zT_22 = union_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_21, zT_22);
    zT_24 = self->store;
    zT_25 = union_node_idx;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    children = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = children.len;
    if ((int)(ci < zT_32)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self->store;
    zT_38 = children.ptr;
    zT_36 = zT_38[ci];
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    fd = zT_40;
    zT_41 = fd.kind;
    if ((int)(zT_41 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_129 = ci + (unsigned int)(1);
    ci = zT_129;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_47 = fd.child_0;
    type_node = zT_47;
    zT_49 = 0;
    gate_state = zT_49;
    zT_51 = 0;
    gate_wide = zT_51;
    if ((int)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_56 = self->store;
    zT_55.store = zT_56;
    zT_57 = self->registry;
    zT_55.typereg = zT_57;
    zT_58 = self->symbols;
    zT_55.symbol_reg = zT_58;
    zT_59 = self->interner;
    zT_55.interner = zT_59;
    zT_55.module_id = module_id;
    tre_env = zT_55;
    zT_61 = &tre_env;
    zT_62 = type_node;
    zT_66 = zF_F2107C15_resolveTypeExprFull(zT_61, zT_62, (unsigned int)(0));
    ft = zT_66;
    if ((int)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((int)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_69 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_69 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_69) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_72 = 1;
    gate_state = zT_72;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_73 = self;
    zT_74 = ft;
    zT_77 = zF_E42B9323_semanticAnalyzerPac(zT_73, zT_74, (int)(1));
    if (zT_77) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_78 = self->registry;
    zT_79 = ft;
    zT_81 = zF_655972D5_typeRegistryIntWidt(zT_78, zT_79);
    if ((int)(zT_81 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_84 = 1;
    gate_wide = zT_84;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_85 = 1;
    gate_state = zT_85;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_89 = fd.span_start;
    fsp = zT_89;
    zT_91 = fd.span_len;
    zT_93 = fsp + (unsigned int)((unsigned int)zT_91);
    fep = zT_93;
    if ((int)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_97 = "packed union field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_99 = 94;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    puw_msg = zT_98;
    zT_100 = self->diag;
    zT_103 = self->source_file_id;
    zT_104 = fsp;
    zT_105 = fep;
    zT_106 = puw_msg;
    zT_111 = zF_C82559AC_diagnosticCollector(zT_100, (unsigned char)(0), (unsigned short)(3000), zT_103, zT_104, zT_105, zT_106);
    (void)zT_111;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_113 = "packed union fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed union";
    zT_115 = 109;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    pgu_msg = zT_114;
    zT_116 = self->diag;
    zT_119 = self->source_file_id;
    zT_120 = fsp;
    zT_121 = fep;
    zT_122 = pgu_msg;
    zT_127 = zF_C82559AC_diagnosticCollector(zT_116, (unsigned char)(0), (unsigned short)(3000), zT_119, zT_120, zT_121, zT_122);
    (void)zT_127;
    goto z_bb_29;
}

/* semanticAnalyzerGateEnumModuleDecl */
void zF_4E74AE9D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    zT_8143F551_AstKind zT_15;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_8143F551_AstKind zT_26;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_46;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    unsigned int zT_50 = 0;
    unsigned int zT_51;
    unsigned int zT_55;
    zT_79FAE712_u64 zT_60;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_79FAE712_u64 zT_62;
    zT_BAEE192E_Opt_10 zT_64 = {0};
    unsigned char zT_65;
    zT_38C12417_SemanticAnalyzer* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    unsigned int backing_node;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    unsigned int tid;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    enum_node = zT_10;
    zT_12 = 0;
    enum_name_id = zT_12;
    zT_14 = 0;
    backing_node = zT_14;
    zT_15 = dnode.kind;
    if ((int)(zT_15 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21 = dnode.child_1;
    zT_20 = zT_21 != (unsigned int)(0);
    goto z_bb_5;
    z_bb_4:
    zT_20 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_20) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    enum_node = decl_node;
    zT_24 = dnode.child_0;
    enum_name_id = zT_24;
    zT_25 = dnode.child_1;
    backing_node = zT_25;
    goto z_bb_7;
    z_bb_7:
    if ((int)(enum_node == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_8:
    zT_26 = dnode.kind;
    if ((int)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = dnode.child_1;
    zT_31 = zT_32 != (unsigned int)(0);
    goto z_bb_11;
    z_bb_10:
    zT_31 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_31) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_36 = self->store;
    zT_37 = dnode.child_1;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    inn = zT_40;
    zT_41 = inn.kind;
    if ((int)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    goto z_bb_7;
    z_bb_14:
    zT_46 = dnode.child_1;
    enum_node = zT_46;
    zT_47 = self->store;
    zT_48 = decl_node;
    zT_50 = zF_8BA26B9E_astStoreNodePayload(zT_47, zT_48);
    enum_name_id = zT_50;
    zT_51 = inn.child_0;
    backing_node = zT_51;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    return;
    z_bb_17:
    zT_55 = self->module_id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_55) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)enum_name_id);
    key = zT_60;
    zT_61 = self->registry;
    zT_62 = key;
    zT_64 = zF_0EB68360_nameCacheGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    tid = zT_64.value;
    zT_67 = self;
    zT_68 = tid;
    zT_69 = enum_node;
    zT_70 = backing_node;
    zF_5EF7F98D_semanticAnalyzerGat(zT_67, zT_68, zT_69, zT_70);
    goto z_bb_19;
    z_bb_19:
    return;
}

/* semanticAnalyzerGateEnumTypeDecl */
void zF_5EF7F98D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, unsigned int enum_node, unsigned int backing_node) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_457ECFEE_EnumPayload* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_457ECFEE_EnumPayload zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_36 = {0};
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    zT_ABC1EBBE_TypeResolveEnv zT_44;
    zT_6B0A7D14_AstStore* zT_45;
    zT_338B7C76_TypeRegistry* zT_46;
    zT_3D7259E2_SymbolRegistry* zT_47;
    zT_D3EB6303_StringInterner* zT_48;
    unsigned int zT_49;
    zT_ABC1EBBE_TypeResolveEnv* zT_51;
    unsigned int zT_52;
    unsigned int zT_56 = 0;
    int zT_59;
    char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_77 = 0;
    zT_338B7C76_TypeRegistry* zT_79;
    unsigned int zT_80;
    zT_338B7C76_TypeRegistry* zT_83;
    zT_D155D06D_Type* zT_84;
    unsigned int zT_85;
    zT_D155D06D_Type zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_F85C5DED_DiagnosticCollector* zT_96;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_107 = 0;
    zT_338B7C76_TypeRegistry* zT_108;
    unsigned int zT_109;
    int zT_111 = 0;
    zT_338B7C76_TypeRegistry* zT_113;
    unsigned int zT_114;
    int zT_116 = 0;
    char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_F85C5DED_DiagnosticCollector* zT_121;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_132 = 0;
    char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    zT_F85C5DED_DiagnosticCollector* zT_137;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_148 = 0;
    zT_338B7C76_TypeRegistry* zT_150;
    unsigned int zT_151;
    unsigned char zT_153 = 0;
    unsigned int zT_154;
    zT_79FAE712_u64 zT_156;
    zT_79FAE712_u64 zT_163;
    zT_338B7C76_TypeRegistry* zT_165;
    zT_457ECFEE_EnumPayload* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    zT_457ECFEE_EnumPayload zT_169;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned short zT_174;
    unsigned int zT_175;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_180 = {0};
    unsigned int zT_182;
    int zT_184;
    unsigned int zT_185;
    zT_79FAE712_u64 zT_187;
    int zT_189;
    unsigned int zT_191;
    int zT_193;
    zT_6B0A7D14_AstStore* zT_196;
    unsigned int zT_197;
    unsigned int* zT_199;
    zT_22A7C88B_AstNode zT_201 = {0};
    zT_8143F551_AstKind zT_202;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_D96DCDF2_EnumMember* zT_209;
    unsigned int zT_210;
    zT_D96DCDF2_EnumMember zT_211;
    zT_C69B2266_i64 zT_212;
    zT_79FAE712_u64 zT_214;
    unsigned int zT_217;
    unsigned int zT_219;
    unsigned int zT_221;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_F85C5DED_DiagnosticCollector* zT_226;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_237 = 0;
    int zT_238;
    int zT_240;
    unsigned int zT_241;
    unsigned int zT_245;
    unsigned int zT_247;
    unsigned int zT_249;
    char* zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_253;
    zT_F85C5DED_DiagnosticCollector* zT_254;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_265 = 0;
    int zT_266;
    unsigned int zT_268;
    unsigned int zT_270;
    zT_D155D06D_Type ety;
    unsigned int check_btid;
    zT_22A7C88B_AstNode bnode;
    unsigned int bsp;
    unsigned int bep;
    zT_ABC1EBBE_TypeResolveEnv tre_env2;
    unsigned int bt;
    unsigned int nbits;
    zT_79FAE712_u64 maxv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bg_msg;
    zT_D155D06D_Type bty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bb_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bi_msg;
    zT_457ECFEE_EnumPayload ep2;
    unsigned int mstart2;
    unsigned int mcount2;
    zT_3CB0179A_Slice_zT_05F374B1_u children2;
    unsigned int fcount2;
    unsigned int ci2;
    zT_79FAE712_u64 prev_vu;
    int have_prev;
    zT_22A7C88B_AstNode fd2;
    zT_C69B2266_i64 mv;
    zT_79FAE712_u64 mvu;
    unsigned int msp;
    unsigned int mep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mv_msg;
    zT_5 = self->registry;
    zT_6 = zT_5->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ety = zT_12;
    zT_13 = ety.kind;
    if ((int)(zT_13 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = ety.payload_idx;
    zT_20 = self->registry;
    zT_21 = zT_20->en_len;
    if ((int)((unsigned int)((unsigned int)zT_18) >= zT_21)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_24 = self->registry;
    zT_25 = zT_24->en_items;
    zT_26 = ety.payload_idx;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_25[zT_27];
    zT_29 = zT_28.backing_type;
    check_btid = zT_29;
    if ((int)(backing_node != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_33 = self->store;
    zT_34 = backing_node;
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    bnode = zT_36;
    zT_38 = bnode.span_start;
    bsp = zT_38;
    zT_40 = bnode.span_len;
    zT_42 = bsp + (unsigned int)((unsigned int)zT_40);
    bep = zT_42;
    zT_45 = self->store;
    zT_44.store = zT_45;
    zT_46 = self->registry;
    zT_44.typereg = zT_46;
    zT_47 = self->symbols;
    zT_44.symbol_reg = zT_47;
    zT_48 = self->interner;
    zT_44.interner = zT_48;
    zT_49 = self->module_id;
    zT_44.module_id = zT_49;
    tre_env2 = zT_44;
    zT_51 = &tre_env2;
    zT_52 = backing_node;
    zT_56 = zF_F2107C15_resolveTypeExprFull(zT_51, zT_52, (unsigned int)(0));
    bt = zT_56;
    if ((int)(bt == (unsigned int)(18))) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    zT_150 = self->registry;
    zT_151 = check_btid;
    zT_153 = zF_655972D5_typeRegistryIntWidt(zT_150, zT_151);
    zT_154 = (unsigned int)zT_153;
    nbits = zT_154;
    zT_156 = 18446744073709551615ULL;
    maxv = zT_156;
    if ((int)(nbits < (unsigned int)(64))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    zT_59 = bt == (unsigned int)(1);
    goto z_bb_11;
    z_bb_10:
    zT_59 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_59) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63 = "invalid enum backing type; enum(uN) requires an unsigned integer type name (u1..u64)";
    zT_65 = 84;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    bg_msg = zT_64;
    zT_66 = self->diag;
    zT_69 = self->source_file_id;
    zT_70 = bsp;
    zT_71 = bep;
    zT_72 = bg_msg;
    zT_77 = zF_C82559AC_diagnosticCollector(zT_66, (unsigned char)(0), (unsigned short)(3000), zT_69, zT_70, zT_71, zT_72);
    (void)zT_77;
    return;
    z_bb_13:
    zT_79 = self->registry;
    zT_80 = zT_79->types_len;
    if ((int)((unsigned int)((unsigned int)bt) < zT_80)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_83 = self->registry;
    zT_84 = zT_83->types_items;
    zT_85 = (unsigned int)bt;
    zT_86 = zT_84[zT_85];
    bty = zT_86;
    zT_87 = bty.kind;
    if ((int)(zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_93 = "bool is not a valid enum backing; use an unsigned integer type (uN)";
    zT_95 = 67;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    bb_msg = zT_94;
    zT_96 = self->diag;
    zT_99 = self->source_file_id;
    zT_100 = bsp;
    zT_101 = bep;
    zT_102 = bb_msg;
    zT_107 = zF_C82559AC_diagnosticCollector(zT_96, (unsigned char)(0), (unsigned short)(3000), zT_99, zT_100, zT_101, zT_102);
    (void)zT_107;
    return;
    z_bb_17:
    zT_108 = self->registry;
    zT_109 = bt;
    zT_111 = zF_B664AC19_typeRegistryIsUnsig(zT_108, zT_109);
    if ((int)(!zT_111)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_113 = self->registry;
    zT_114 = bt;
    zT_116 = zF_01ED6537_typeRegistryIntIsSi(zT_113, zT_114);
    if (zT_116) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    check_btid = bt;
    goto z_bb_15;
    z_bb_20:
    zT_118 = "enum(iN) signed backings are not supported; use an unsigned backing (enum(uN))";
    zT_120 = 78;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    bs_msg = zT_119;
    zT_121 = self->diag;
    zT_124 = self->source_file_id;
    zT_125 = bsp;
    zT_126 = bep;
    zT_127 = bs_msg;
    zT_132 = zF_C82559AC_diagnosticCollector(zT_121, (unsigned char)(0), (unsigned short)(3000), zT_124, zT_125, zT_126, zT_127);
    (void)zT_132;
    goto z_bb_21;
    z_bb_21:
    return;
    z_bb_22:
    zT_134 = "invalid enum backing type; enum(uN) requires an unsigned integer type (uN)";
    zT_136 = 74;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    bi_msg = zT_135;
    zT_137 = self->diag;
    zT_140 = self->source_file_id;
    zT_141 = bsp;
    zT_142 = bep;
    zT_143 = bi_msg;
    zT_148 = zF_C82559AC_diagnosticCollector(zT_137, (unsigned char)(0), (unsigned short)(3000), zT_140, zT_141, zT_142, zT_143);
    (void)zT_148;
    goto z_bb_21;
    z_bb_23:
    zT_163 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)nbits)) - (zT_79FAE712_u64)(1);
    maxv = zT_163;
    goto z_bb_24;
    z_bb_24:
    zT_165 = self->registry;
    zT_166 = zT_165->en_items;
    zT_167 = ety.payload_idx;
    zT_168 = (unsigned int)zT_167;
    zT_169 = zT_166[zT_168];
    ep2 = zT_169;
    zT_171 = ep2.members_start;
    zT_172 = (unsigned int)zT_171;
    mstart2 = zT_172;
    zT_174 = ep2.members_count;
    zT_175 = (unsigned int)zT_174;
    mcount2 = zT_175;
    zT_177 = self->store;
    zT_178 = enum_node;
    zT_180 = zF_850FDF81_astStoreNodeExtraCh(zT_177, zT_178);
    children2 = zT_180;
    zT_182 = 0;
    fcount2 = zT_182;
    zT_184 = 0;
    zT_185 = (unsigned int)zT_184;
    ci2 = zT_185;
    zT_187 = 0;
    prev_vu = zT_187;
    zT_189 = 0;
    have_prev = zT_189;
    goto z_bb_25;
    z_bb_25:
    zT_191 = children2.len;
    if ((int)(ci2 < zT_191)) goto z_bb_29; else goto z_bb_30;
    z_bb_26:
    zT_196 = self->store;
    zT_199 = children2.ptr;
    zT_197 = zT_199[ci2];
    zT_201 = zF_FCDD1D35_astStoreNodeAt(zT_196, zT_197);
    fd2 = zT_201;
    zT_202 = fd2.kind;
    if ((int)(zT_202 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return;
    z_bb_28:
    zT_270 = ci2 + (unsigned int)(1);
    ci2 = zT_270;
    goto z_bb_25;
    z_bb_29:
    zT_193 = fcount2 < mcount2;
    goto z_bb_31;
    z_bb_30:
    zT_193 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_193) goto z_bb_26; else goto z_bb_27;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_208 = self->registry;
    zT_209 = zT_208->em_items;
    zT_210 = mstart2 + fcount2;
    zT_211 = zT_209[zT_210];
    zT_212 = zT_211.value;
    mv = zT_212;
    zT_214 = (zT_79FAE712_u64)mv;
    mvu = zT_214;
    if ((int)(mvu > maxv)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_217 = fd2.span_start;
    msp = zT_217;
    zT_219 = fd2.span_len;
    zT_221 = msp + (unsigned int)((unsigned int)zT_219);
    mep = zT_221;
    zT_223 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_225 = 91;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    mv_msg = zT_224;
    zT_226 = self->diag;
    zT_229 = self->source_file_id;
    zT_230 = msp;
    zT_231 = mep;
    zT_232 = mv_msg;
    zT_237 = zF_C82559AC_diagnosticCollector(zT_226, (unsigned char)(0), (unsigned short)(3000), zT_229, zT_230, zT_231, zT_232);
    (void)zT_237;
    return;
    z_bb_35:
    if (have_prev) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_238 = prev_vu == maxv;
    goto z_bb_38;
    z_bb_37:
    zT_238 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_238) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_241 = fd2.child_1;
    zT_240 = zT_241 == (unsigned int)(0);
    goto z_bb_41;
    z_bb_40:
    zT_240 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_240) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_245 = fd2.span_start;
    msp = zT_245;
    zT_247 = fd2.span_len;
    zT_249 = msp + (unsigned int)((unsigned int)zT_247);
    mep = zT_249;
    zT_251 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_253 = 91;
    zT_252.ptr = zT_251;
    zT_252.len = zT_253;
    mv_msg = zT_252;
    zT_254 = self->diag;
    zT_257 = self->source_file_id;
    zT_258 = msp;
    zT_259 = mep;
    zT_260 = mv_msg;
    zT_265 = zF_C82559AC_diagnosticCollector(zT_254, (unsigned char)(0), (unsigned short)(3000), zT_257, zT_258, zT_259, zT_260);
    (void)zT_265;
    return;
    z_bb_43:
    prev_vu = mvu;
    zT_266 = 1;
    have_prev = zT_266;
    zT_268 = fcount2 + (unsigned int)(1);
    fcount2 = zT_268;
    goto z_bb_28;
}

/* semanticAnalyzerPackedStructDeclForType */
unsigned int zF_1BB4D489_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_42;
    unsigned int zT_43;
    zT_3D7259E2_SymbolRegistry* zT_44;
    unsigned int zT_45;
    zT_3D7259E2_SymbolRegistry* zT_48;
    zT_060CD1EB_SymbolTable* zT_49;
    zT_060CD1EB_SymbolTable zT_50;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_3A105EF1_Symbol* zT_57;
    zT_3A105EF1_Symbol zT_58;
    zT_3C598AEF_SymbolKind zT_59;
    unsigned int zT_64;
    int zT_66;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    zT_22A7C88B_AstNode zT_75 = {0};
    unsigned int zT_77;
    zT_8143F551_AstKind zT_78;
    unsigned int zT_83;
    zT_8143F551_AstKind zT_84;
    int zT_89;
    unsigned int zT_90;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_99;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_109;
    zT_22A7C88B_AstNode zT_111 = {0};
    unsigned char zT_112;
    zT_38C12417_SemanticAnalyzer* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned int zT_123;
    zT_38C12417_SemanticAnalyzer* zT_124;
    unsigned int zT_125;
    unsigned int hc;
    unsigned int cc;
    zT_D155D06D_Type sty;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol s;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    zT_22A7C88B_AstNode inn;
    zT_22A7C88B_AstNode tnode;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    hc = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_struct_cache_len;
    if ((int)(hc < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = zT_7[hc];
    if ((int)(zT_8 == struct_tid)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    cc = zT_16;
    goto z_bb_7;
    z_bb_4:
    zT_13 = hc + (unsigned int)(1);
    hc = zT_13;
    goto z_bb_1;
    z_bb_5:
    zT_10 = self->packed_struct_decl_nodes;
    zT_11 = zT_10[hc];
    return zT_11;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_17 = self->checked_struct_tids_len;
    if ((int)(cc < zT_17)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_19 = self->checked_struct_tids;
    zT_20 = zT_19[cc];
    if ((int)(zT_20 == struct_tid)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_26 = self->registry;
    zT_27 = zT_26->types_len;
    if ((int)((unsigned int)((unsigned int)struct_tid) >= zT_27)) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_24 = cc + (unsigned int)(1);
    cc = zT_24;
    goto z_bb_7;
    z_bb_11:
    return (unsigned int)(0);
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    return (unsigned int)(0);
    z_bb_14:
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)struct_tid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_35 = sty.kind;
    if ((int)(zT_35 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned int)(0);
    z_bb_16:
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ti = zT_43;
    goto z_bb_17;
    z_bb_17:
    zT_44 = self->symbols;
    zT_45 = zT_44->tables_len;
    if ((int)(ti < zT_45)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_48 = self->symbols;
    zT_49 = zT_48->tables_items;
    zT_50 = zT_49[ti];
    table = zT_50;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    si = zT_53;
    goto z_bb_21;
    z_bb_19:
    zT_124 = self;
    zT_125 = struct_tid;
    zF_B5A1E8BB_semanticAnalyzerChe(zT_124, zT_125);
    return (unsigned int)(0);
    z_bb_20:
    zT_123 = ti + (unsigned int)(1);
    ti = zT_123;
    goto z_bb_17;
    z_bb_21:
    zT_54 = table.len;
    if ((int)(si < zT_54)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_57 = table.items;
    zT_58 = zT_57[si];
    s = zT_58;
    zT_59 = s.kind;
    if ((int)(zT_59 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_121 = si + (unsigned int)(1);
    si = zT_121;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_64 = s.type_id;
    if ((int)(zT_64 != struct_tid)) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_67 = s.decl_node;
    zT_66 = zT_67 == (unsigned int)(0);
    goto z_bb_29;
    z_bb_28:
    zT_66 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_66) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    goto z_bb_24;
    z_bb_31:
    zT_71 = self->store;
    zT_72 = s.decl_node;
    zT_75 = zF_FCDD1D35_astStoreNodeAt(zT_71, zT_72);
    dnode = zT_75;
    zT_77 = 0;
    target = zT_77;
    zT_78 = dnode.kind;
    if ((int)(zT_78 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_83 = s.decl_node;
    target = zT_83;
    goto z_bb_33;
    z_bb_33:
    if ((int)(target == (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_34:
    zT_84 = dnode.kind;
    if ((int)(zT_84 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_90 = dnode.child_1;
    zT_89 = zT_90 != (unsigned int)(0);
    goto z_bb_37;
    z_bb_36:
    zT_89 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_89) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_94 = self->store;
    zT_95 = dnode.child_1;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    inn = zT_98;
    zT_99 = inn.kind;
    if ((int)(zT_99 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_33;
    z_bb_40:
    zT_104 = dnode.child_1;
    target = zT_104;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    goto z_bb_24;
    z_bb_43:
    zT_108 = self->store;
    zT_109 = target;
    zT_111 = zF_FCDD1D35_astStoreNodeAt(zT_108, zT_109);
    tnode = zT_111;
    zT_112 = tnode.flags;
    if ((int)((unsigned char)(zT_112 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_117 = self;
    zT_118 = struct_tid;
    zT_119 = target;
    zF_2C47D4E0_semanticAnalyzerPac(zT_117, zT_118, zT_119);
    return target;
    z_bb_45:
    goto z_bb_24;
}

/* semanticAnalyzerResolveArithmetic */
unsigned int zF_44006DDD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    zT_38C12417_SemanticAnalyzer* zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    int zT_20;
    int zT_28;
    zT_338B7C76_TypeRegistry* zT_34;
    unsigned int zT_35;
    int zT_37 = 0;
    int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    int zT_42 = 0;
    zT_338B7C76_TypeRegistry* zT_44;
    unsigned int zT_45;
    int zT_47 = 0;
    int zT_48;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_53;
    int zT_55 = 0;
    int zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    int zT_60 = 0;
    int zT_61;
    int zT_66;
    zT_338B7C76_TypeRegistry* zT_67;
    unsigned int zT_68;
    int zT_70 = 0;
    int zT_71;
    int zT_74;
    int zT_79;
    int zT_80;
    int zT_84;
    zT_338B7C76_TypeRegistry* zT_85;
    unsigned int zT_86;
    int zT_88 = 0;
    int zT_91;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    int zT_95 = 0;
    zT_338B7C76_TypeRegistry* zT_96;
    unsigned int zT_97;
    int zT_99 = 0;
    int zT_101;
    zT_338B7C76_TypeRegistry* zT_102;
    unsigned int zT_103;
    int zT_105 = 0;
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int zT_110;
    int zT_112 = 0;
    int zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    unsigned int zT_115;
    int zT_117 = 0;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    unsigned char zT_122 = 0;
    zT_338B7C76_TypeRegistry* zT_124;
    unsigned int zT_125;
    unsigned char zT_127 = 0;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D155D06D_Type* zT_131;
    unsigned int zT_132;
    zT_D155D06D_Type zT_133;
    unsigned int zT_134;
    zT_338B7C76_TypeRegistry* zT_136;
    zT_D155D06D_Type* zT_137;
    unsigned int zT_138;
    zT_D155D06D_Type zT_139;
    unsigned int zT_140;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    int lhs_ptr;
    int rhs_uint;
    int rhs_ptr;
    unsigned char lw;
    unsigned char rw;
    unsigned int ls;
    unsigned int rs;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    lhs = zT_12;
    zT_14 = self;
    zT_15 = node.child_1;
    zT_17 = zF_54F95822_semanticAnalyzerRes(zT_14, zT_15);
    rhs = zT_17;
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_20 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_20 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_20) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_28 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_8;
    z_bb_7:
    zT_28 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_28) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_34 = self->registry;
    zT_35 = lhs;
    zT_37 = zF_AD61DB1B_typeRegistryIsPoint(zT_34, zT_35);
    if (zT_37) goto z_bb_12; else goto z_bb_11;
    z_bb_10:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_39 = self->registry;
    zT_40 = lhs;
    zT_42 = zF_0F4CC580_typeRegistryIsSlice(zT_39, zT_40);
    zT_38 = zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 1;
    goto z_bb_13;
    z_bb_13:
    lhs_ptr = zT_38;
    zT_44 = self->registry;
    zT_45 = rhs;
    zT_47 = zF_B664AC19_typeRegistryIsUnsig(zT_44, zT_45);
    if (zT_47) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_48 = rhs == (unsigned int)(19);
    goto z_bb_16;
    z_bb_15:
    zT_48 = 1;
    goto z_bb_16;
    z_bb_16:
    rhs_uint = zT_48;
    zT_52 = self->registry;
    zT_53 = rhs;
    zT_55 = zF_AD61DB1B_typeRegistryIsPoint(zT_52, zT_53);
    if (zT_55) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_57 = self->registry;
    zT_58 = rhs;
    zT_60 = zF_0F4CC580_typeRegistryIsSlice(zT_57, zT_58);
    zT_56 = zT_60;
    goto z_bb_19;
    z_bb_18:
    zT_56 = 1;
    goto z_bb_19;
    z_bb_19:
    rhs_ptr = zT_56;
    if (lhs_ptr) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = rhs_uint;
    goto z_bb_22;
    z_bb_21:
    zT_61 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_61) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return lhs;
    z_bb_24:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_67 = self->registry;
    zT_68 = lhs;
    zT_70 = zF_B664AC19_typeRegistryIsUnsig(zT_67, zT_68);
    if (zT_70) goto z_bb_29; else goto z_bb_28;
    z_bb_26:
    zT_66 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_66) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_71 = lhs == (unsigned int)(19);
    goto z_bb_30;
    z_bb_29:
    zT_71 = 1;
    goto z_bb_30;
    z_bb_30:
    zT_66 = zT_71;
    goto z_bb_27;
    z_bb_31:
    zT_74 = rhs_ptr;
    goto z_bb_33;
    z_bb_32:
    zT_74 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_74) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return rhs;
    z_bb_35:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_79 = lhs_ptr;
    goto z_bb_38;
    z_bb_37:
    zT_79 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_79) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_80 = rhs_ptr;
    goto z_bb_41;
    z_bb_40:
    zT_80 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_80) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (unsigned int)(12);
    z_bb_43:
    goto z_bb_10;
    z_bb_44:
    zT_85 = self->registry;
    zT_86 = rhs;
    zT_88 = zF_3087E0A5_typeRegistryIsNumer(zT_85, zT_86);
    zT_84 = zT_88;
    goto z_bb_46;
    z_bb_45:
    zT_84 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_84) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return rhs;
    z_bb_48:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_92 = self->registry;
    zT_93 = lhs;
    zT_95 = zF_3087E0A5_typeRegistryIsNumer(zT_92, zT_93);
    zT_91 = zT_95;
    goto z_bb_51;
    z_bb_50:
    zT_91 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_91) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    return lhs;
    z_bb_53:
    zT_96 = self->registry;
    zT_97 = lhs;
    zT_99 = zF_3087E0A5_typeRegistryIsNumer(zT_96, zT_97);
    if ((int)(!zT_99)) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_102 = self->registry;
    zT_103 = rhs;
    zT_105 = zF_3087E0A5_typeRegistryIsNumer(zT_102, zT_103);
    zT_101 = !zT_105;
    goto z_bb_56;
    z_bb_55:
    zT_101 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_101) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned int)(1);
    z_bb_58:
    if ((int)(lhs == rhs)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return lhs;
    z_bb_60:
    zT_109 = self->registry;
    zT_110 = lhs;
    zT_112 = zF_3290E9C4_typeRegistryIsInteg(zT_109, zT_110);
    if (zT_112) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_114 = self->registry;
    zT_115 = rhs;
    zT_117 = zF_3290E9C4_typeRegistryIsInteg(zT_114, zT_115);
    zT_113 = zT_117;
    goto z_bb_63;
    z_bb_62:
    zT_113 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_113) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_119 = self->registry;
    zT_120 = lhs;
    zT_122 = zF_655972D5_typeRegistryIntWidt(zT_119, zT_120);
    lw = zT_122;
    zT_124 = self->registry;
    zT_125 = rhs;
    zT_127 = zF_655972D5_typeRegistryIntWidt(zT_124, zT_125);
    rw = zT_127;
    if ((int)(lw >= rw)) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    zT_130 = self->registry;
    zT_131 = zT_130->types_items;
    zT_132 = (unsigned int)lhs;
    zT_133 = zT_131[zT_132];
    zT_134 = zT_133.size;
    ls = zT_134;
    zT_136 = self->registry;
    zT_137 = zT_136->types_items;
    zT_138 = (unsigned int)rhs;
    zT_139 = zT_137[zT_138];
    zT_140 = zT_139.size;
    rs = zT_140;
    if ((int)(ls >= rs)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    return lhs;
    z_bb_67:
    return rhs;
    z_bb_68:
    return lhs;
    z_bb_69:
    return rhs;
}

/* semanticAnalyzerResolveBitwise */
unsigned int zF_733BCA9C_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    int zT_19;
    int zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    int zT_29 = 0;
    int zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    int zT_36 = 0;
    int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    int zT_42 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    lhs = zT_11;
    zT_13 = self;
    zT_14 = node.child_1;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    rhs = zT_16;
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_19 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_19 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_26 = self->registry;
    zT_27 = rhs;
    zT_29 = zF_3290E9C4_typeRegistryIsInteg(zT_26, zT_27);
    zT_25 = zT_29;
    goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_25) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return rhs;
    z_bb_10:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->registry;
    zT_34 = lhs;
    zT_36 = zF_3290E9C4_typeRegistryIsInteg(zT_33, zT_34);
    zT_32 = zT_36;
    goto z_bb_13;
    z_bb_12:
    zT_32 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_32) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return lhs;
    z_bb_15:
    if ((int)(lhs != rhs)) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_39 = self->registry;
    zT_40 = lhs;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_39, zT_40);
    zT_38 = !zT_42;
    goto z_bb_18;
    z_bb_17:
    zT_38 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_38) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned int)(1);
    z_bb_20:
    return lhs;
}

/* semanticAnalyzerResolveComparison */
unsigned int zF_EB621FF0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_24 = {0};
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    int zT_37;
    zT_8143F551_AstKind zT_38;
    unsigned char zT_43;
    zT_8143F551_AstKind zT_47;
    int zT_52;
    zT_8143F551_AstKind zT_53;
    unsigned char zT_58;
    int zT_63;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int zT_67;
    unsigned int zT_69 = 0;
    int zT_71;
    unsigned int zT_72;
    int zT_73;
    int zT_75;
    int zT_78;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_D155D06D_Type* zT_82;
    unsigned int zT_83;
    zT_D155D06D_Type zT_84;
    zT_33EF6BFB_TypeKind zT_85;
    zT_8143F551_AstKind zT_86;
    int zT_91;
    int zT_96;
    zT_8143F551_AstKind zT_97;
    int zT_102;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_108;
    zT_38C12417_SemanticAnalyzer* zT_109;
    unsigned int zT_110;
    unsigned int zT_112 = 0;
    zT_38C12417_SemanticAnalyzer* zT_113;
    zT_38C12417_SemanticAnalyzer* zT_114;
    unsigned int zT_115;
    unsigned int zT_117 = 0;
    int zT_120;
    zT_38C12417_SemanticAnalyzer* zT_123;
    unsigned int zT_124;
    unsigned int zT_126 = 0;
    int zT_128;
    unsigned int zT_129;
    int zT_130;
    int zT_132;
    int zT_135;
    zT_338B7C76_TypeRegistry* zT_138;
    zT_D155D06D_Type* zT_139;
    unsigned int zT_140;
    zT_D155D06D_Type zT_141;
    zT_33EF6BFB_TypeKind zT_142;
    zT_8143F551_AstKind zT_143;
    int zT_148;
    int zT_153;
    zT_8143F551_AstKind zT_154;
    int zT_159;
    zT_38C12417_SemanticAnalyzer* zT_164;
    unsigned int zT_165;
    zT_38C12417_SemanticAnalyzer* zT_166;
    unsigned int zT_167;
    unsigned int zT_169 = 0;
    zT_38C12417_SemanticAnalyzer* zT_170;
    zT_38C12417_SemanticAnalyzer* zT_171;
    unsigned int zT_172;
    unsigned int zT_174 = 0;
    zT_38C12417_SemanticAnalyzer* zT_175;
    unsigned int zT_176;
    unsigned int zT_178 = 0;
    zT_38C12417_SemanticAnalyzer* zT_179;
    unsigned int zT_180;
    unsigned int zT_182 = 0;
    int zT_185;
    char* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    unsigned int zT_198;
    int zT_200 = 0;
    char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    int zT_209;
    zT_338B7C76_TypeRegistry* zT_210;
    unsigned int zT_211;
    int zT_213 = 0;
    char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    zT_338B7C76_TypeRegistry* zT_221;
    unsigned int zT_222;
    int zT_224 = 0;
    int zT_225;
    char* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    int zT_237;
    zT_338B7C76_TypeRegistry* zT_242;
    unsigned int zT_243;
    int zT_245 = 0;
    int zT_246;
    zT_338B7C76_TypeRegistry* zT_250;
    unsigned int zT_251;
    int zT_253 = 0;
    int zT_254;
    zT_338B7C76_TypeRegistry* zT_258;
    unsigned int zT_259;
    int zT_261 = 0;
    int zT_262;
    zT_338B7C76_TypeRegistry* zT_263;
    unsigned int zT_264;
    int zT_266 = 0;
    char* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    char* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned int zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    zT_338B7C76_TypeRegistry* zT_282;
    unsigned int zT_283;
    int zT_285 = 0;
    char* zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    char* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned int zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_298;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    int zT_304;
    unsigned char* zT_305;
    unsigned int zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308 = 0;
    unsigned int zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    unsigned char* zT_317;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    char* zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_326;
    unsigned int zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    int zT_332;
    unsigned char* zT_333;
    unsigned int zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    unsigned int zT_336 = 0;
    unsigned int zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned char* zT_345;
    unsigned int zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    char* zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned int zT_351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_352;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_354;
    unsigned int zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    int zT_361;
    unsigned char* zT_362;
    unsigned int zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    unsigned int zT_365 = 0;
    unsigned int zT_369;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_370;
    unsigned char* zT_374;
    unsigned int zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    char* zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned int zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_22A7C88B_AstNode c0n;
    zT_22A7C88B_AstNode c1n;
    unsigned char c0_lit;
    unsigned char c1_lit;
    unsigned int peerk;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp0;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp2;
    int lhs_num;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp3;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp4;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_lb;
    unsigned int cpv_ll;
    unsigned int cpv_ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_rh;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_rb;
    unsigned int cpv_rl;
    unsigned int cpv_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_ih;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_ib;
    unsigned int cpv_il;
    unsigned int cpv_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp5;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp6;
    zT_4 = "CPE";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    cpe = zT_5;
    zT_7 = cpe;
    zF_48AC7B3A_markerWrite(zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    lhs = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    rhs = zT_18;
    zT_20 = self->store;
    zT_21 = node.child_0;
    zT_24 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    c0n = zT_24;
    zT_26 = self->store;
    zT_27 = node.child_1;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    c1n = zT_30;
    zT_32 = c0n.kind;
    if ((int)(zT_32 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_38 = c0n.kind;
    zT_37 = zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_3;
    z_bb_2:
    zT_37 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_37) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_43 = 1;
    goto z_bb_6;
    z_bb_5:
    zT_43 = 0;
    goto z_bb_6;
    z_bb_6:
    c0_lit = zT_43;
    zT_47 = c1n.kind;
    if ((int)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_53 = c1n.kind;
    zT_52 = zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_9;
    z_bb_8:
    zT_52 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_52) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_58 = 1;
    goto z_bb_12;
    z_bb_11:
    zT_58 = 0;
    goto z_bb_12;
    z_bb_12:
    c1_lit = zT_58;
    if ((int)(c0_lit == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_63 = c1_lit != (unsigned char)(0);
    goto z_bb_15;
    z_bb_14:
    zT_63 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_63) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_66 = self;
    zT_67 = node.child_0;
    zT_69 = zF_54F95822_semanticAnalyzerRes(zT_66, zT_67);
    lhs = zT_69;
    zT_71 = 0;
    zT_72 = (unsigned int)zT_71;
    peerk = zT_72;
    zT_73 = 0;
    if ((int)(lhs != (unsigned int)zT_73)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_66; else goto z_bb_65;
    z_bb_18:
    if ((int)(c0_lit != (unsigned char)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_19:
    zT_75 = lhs != (unsigned int)(1);
    goto z_bb_21;
    z_bb_20:
    zT_75 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_75) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_78 = lhs != (unsigned int)(18);
    goto z_bb_24;
    z_bb_23:
    zT_78 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_78) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_81 = self->registry;
    zT_82 = zT_81->types_items;
    zT_83 = (unsigned int)lhs;
    zT_84 = zT_82[zT_83];
    zT_85 = zT_84.kind;
    peerk = zT_85;
    goto z_bb_26;
    z_bb_26:
    zT_86 = c1n.kind;
    if ((int)(zT_86 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_91 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_29;
    z_bb_28:
    zT_91 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_91) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_97 = c1n.kind;
    if ((int)(zT_97 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_96 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_96) goto z_bb_36; else goto z_bb_38;
    z_bb_33:
    zT_102 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_35;
    z_bb_34:
    zT_102 = 0;
    goto z_bb_35;
    z_bb_35:
    zT_96 = zT_102;
    goto z_bb_32;
    z_bb_36:
    zT_107 = self;
    zT_108 = lhs;
    zF_9665A229_pushExpectedType(zT_107, zT_108);
    zT_109 = self;
    zT_110 = node.child_1;
    zT_112 = zF_54F95822_semanticAnalyzerRes(zT_109, zT_110);
    rhs = zT_112;
    zT_113 = self;
    zF_BC478E78_popExpectedType(zT_113);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_17;
    z_bb_38:
    zT_114 = self;
    zT_115 = node.child_1;
    zT_117 = zF_54F95822_semanticAnalyzerRes(zT_114, zT_115);
    rhs = zT_117;
    goto z_bb_37;
    z_bb_39:
    zT_120 = c1_lit == (unsigned char)(0);
    goto z_bb_41;
    z_bb_40:
    zT_120 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_120) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_123 = self;
    zT_124 = node.child_1;
    zT_126 = zF_54F95822_semanticAnalyzerRes(zT_123, zT_124);
    rhs = zT_126;
    zT_128 = 0;
    zT_129 = (unsigned int)zT_128;
    peerk = zT_129;
    zT_130 = 0;
    if ((int)(rhs != (unsigned int)zT_130)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_17;
    z_bb_44:
    zT_175 = self;
    zT_176 = node.child_0;
    zT_178 = zF_54F95822_semanticAnalyzerRes(zT_175, zT_176);
    lhs = zT_178;
    zT_179 = self;
    zT_180 = node.child_1;
    zT_182 = zF_54F95822_semanticAnalyzerRes(zT_179, zT_180);
    rhs = zT_182;
    goto z_bb_43;
    z_bb_45:
    zT_132 = rhs != (unsigned int)(1);
    goto z_bb_47;
    z_bb_46:
    zT_132 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_132) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_135 = rhs != (unsigned int)(18);
    goto z_bb_50;
    z_bb_49:
    zT_135 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_135) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_138 = self->registry;
    zT_139 = zT_138->types_items;
    zT_140 = (unsigned int)rhs;
    zT_141 = zT_139[zT_140];
    zT_142 = zT_141.kind;
    peerk = zT_142;
    goto z_bb_52;
    z_bb_52:
    zT_143 = c0n.kind;
    if ((int)(zT_143 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_148 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_55;
    z_bb_54:
    zT_148 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_148) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_154 = c0n.kind;
    if ((int)(zT_154 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_153 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_153) goto z_bb_62; else goto z_bb_64;
    z_bb_59:
    zT_159 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_61;
    z_bb_60:
    zT_159 = 0;
    goto z_bb_61;
    z_bb_61:
    zT_153 = zT_159;
    goto z_bb_58;
    z_bb_62:
    zT_164 = self;
    zT_165 = rhs;
    zF_9665A229_pushExpectedType(zT_164, zT_165);
    zT_166 = self;
    zT_167 = node.child_0;
    zT_169 = zF_54F95822_semanticAnalyzerRes(zT_166, zT_167);
    lhs = zT_169;
    zT_170 = self;
    zF_BC478E78_popExpectedType(zT_170);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_43;
    z_bb_64:
    zT_171 = self;
    zT_172 = node.child_0;
    zT_174 = zF_54F95822_semanticAnalyzerRes(zT_171, zT_172);
    lhs = zT_174;
    goto z_bb_63;
    z_bb_65:
    zT_185 = rhs == (unsigned int)(0);
    goto z_bb_67;
    z_bb_66:
    zT_185 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_185) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_189 = "CP0";
    zT_191 = 3;
    zT_190.ptr = zT_189;
    zT_190.len = zT_191;
    cp0 = zT_190;
    zT_192 = cp0;
    zF_48AC7B3A_markerWrite(zT_192);
    return (unsigned int)(1);
    z_bb_69:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_197 = self->registry;
    zT_198 = rhs;
    zT_200 = zF_3087E0A5_typeRegistryIsNumer(zT_197, zT_198);
    zT_196 = zT_200;
    goto z_bb_72;
    z_bb_71:
    zT_196 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_196) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_202 = "CPB";
    zT_204 = 3;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    cp1 = zT_203;
    zT_205 = cp1;
    zF_48AC7B3A_markerWrite(zT_205);
    return (unsigned int)(2);
    z_bb_74:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_210 = self->registry;
    zT_211 = lhs;
    zT_213 = zF_3087E0A5_typeRegistryIsNumer(zT_210, zT_211);
    zT_209 = zT_213;
    goto z_bb_77;
    z_bb_76:
    zT_209 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_209) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_215 = "CPB";
    zT_217 = 3;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    cp2 = zT_216;
    zT_218 = cp2;
    zF_48AC7B3A_markerWrite(zT_218);
    return (unsigned int)(2);
    z_bb_79:
    zT_221 = self->registry;
    zT_222 = lhs;
    zT_224 = zF_3087E0A5_typeRegistryIsNumer(zT_221, zT_222);
    lhs_num = zT_224;
    if (lhs_num) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_225 = lhs == rhs;
    goto z_bb_82;
    z_bb_81:
    zT_225 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_225) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_228 = "CPB";
    zT_230 = 3;
    zT_229.ptr = zT_228;
    zT_229.len = zT_230;
    cp3 = zT_229;
    zT_231 = cp3;
    zF_48AC7B3A_markerWrite(zT_231);
    return (unsigned int)(2);
    z_bb_84:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_237 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_87;
    z_bb_86:
    zT_237 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_237) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_242 = self->registry;
    zT_243 = lhs;
    zT_245 = zF_DA6AF452_typeRegistryIsOptio(zT_242, zT_243);
    if (zT_245) goto z_bb_90; else goto z_bb_91;
    z_bb_89:
    if ((int)(lhs == rhs)) goto z_bb_105; else goto z_bb_106;
    z_bb_90:
    zT_246 = rhs == (unsigned int)(17);
    goto z_bb_92;
    z_bb_91:
    zT_246 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_246) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned int)(2);
    z_bb_94:
    zT_250 = self->registry;
    zT_251 = rhs;
    zT_253 = zF_DA6AF452_typeRegistryIsOptio(zT_250, zT_251);
    if (zT_253) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_254 = lhs == (unsigned int)(17);
    goto z_bb_97;
    z_bb_96:
    zT_254 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_254) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    return (unsigned int)(2);
    z_bb_99:
    zT_258 = self->registry;
    zT_259 = lhs;
    zT_261 = zF_B8767394_typeRegistryIsError(zT_258, zT_259);
    if (zT_261) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_263 = self->registry;
    zT_264 = rhs;
    zT_266 = zF_B8767394_typeRegistryIsError(zT_263, zT_264);
    zT_262 = zT_266;
    goto z_bb_102;
    z_bb_101:
    zT_262 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_262) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_268 = "CPB";
    zT_270 = 3;
    zT_269.ptr = zT_268;
    zT_269.len = zT_270;
    cp4 = zT_269;
    zT_271 = cp4;
    zF_48AC7B3A_markerWrite(zT_271);
    return (unsigned int)(2);
    z_bb_104:
    goto z_bb_89;
    z_bb_105:
    if ((int)(lhs == (unsigned int)(2))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_293 = "CPVl";
    zT_295 = 4;
    zT_294.ptr = zT_293;
    zT_294.len = zT_295;
    cpv = zT_294;
    zT_296 = cpv;
    zF_48AC7B3A_markerWrite(zT_296);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_298[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_lb[_i] = zT_298[_i];
        _i++;
    }
}
    zT_300 = lhs;
    zT_304 = 0;
    zT_305 = (unsigned char*)((unsigned char*)cpv_lb) + zT_304;
    zT_306 = (unsigned int)(10) - zT_304;
    zT_307.ptr = zT_305;
    zT_307.len = zT_306;
    zT_301 = zT_307;
    zT_308 = zF_A7504564_itoa(zT_300, zT_301);
    cpv_ll = zT_308;
    zT_312 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_ll);
    cpv_ls = zT_312;
    zT_317 = (unsigned char*)((unsigned char*)cpv_lb) + cpv_ls;
    zT_318 = (unsigned int)(9) - cpv_ls;
    zT_319.ptr = zT_317;
    zT_319.len = zT_318;
    zT_313 = zT_319;
    zF_48AC7B3A_markerWrite(zT_313);
    zT_321 = "r";
    zT_323 = 1;
    zT_322.ptr = zT_321;
    zT_322.len = zT_323;
    cpv_rh = zT_322;
    zT_324 = cpv_rh;
    zF_48AC7B3A_markerWrite(zT_324);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_326[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_rb[_i] = zT_326[_i];
        _i++;
    }
}
    zT_328 = rhs;
    zT_332 = 0;
    zT_333 = (unsigned char*)((unsigned char*)cpv_rb) + zT_332;
    zT_334 = (unsigned int)(10) - zT_332;
    zT_335.ptr = zT_333;
    zT_335.len = zT_334;
    zT_329 = zT_335;
    zT_336 = zF_A7504564_itoa(zT_328, zT_329);
    cpv_rl = zT_336;
    zT_340 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_rl);
    cpv_rs = zT_340;
    zT_345 = (unsigned char*)((unsigned char*)cpv_rb) + cpv_rs;
    zT_346 = (unsigned int)(9) - cpv_rs;
    zT_347.ptr = zT_345;
    zT_347.len = zT_346;
    zT_341 = zT_347;
    zF_48AC7B3A_markerWrite(zT_341);
    zT_349 = "n";
    zT_351 = 1;
    zT_350.ptr = zT_349;
    zT_350.len = zT_351;
    cpv_ih = zT_350;
    zT_352 = cpv_ih;
    zF_48AC7B3A_markerWrite(zT_352);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_354[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_ib[_i] = zT_354[_i];
        _i++;
    }
}
    zT_356 = node.child_0;
    zT_361 = 0;
    zT_362 = (unsigned char*)((unsigned char*)cpv_ib) + zT_361;
    zT_363 = (unsigned int)(10) - zT_361;
    zT_364.ptr = zT_362;
    zT_364.len = zT_363;
    zT_357 = zT_364;
    zT_365 = zF_A7504564_itoa(zT_356, zT_357);
    cpv_il = zT_365;
    zT_369 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_il);
    cpv_is = zT_369;
    zT_374 = (unsigned char*)((unsigned char*)cpv_ib) + cpv_is;
    zT_375 = (unsigned int)(9) - cpv_is;
    zT_376.ptr = zT_374;
    zT_376.len = zT_375;
    zT_370 = zT_376;
    zF_48AC7B3A_markerWrite(zT_370);
    zT_378 = "\n";
    zT_380 = 1;
    zT_379.ptr = zT_378;
    zT_379.len = zT_380;
    cpv_nl = zT_379;
    zT_381 = cpv_nl;
    zF_48AC7B3A_markerWrite(zT_381);
    return (unsigned int)(1);
    z_bb_107:
    zT_277 = "CPB";
    zT_279 = 3;
    zT_278.ptr = zT_277;
    zT_278.len = zT_279;
    cp5 = zT_278;
    zT_280 = cp5;
    zF_48AC7B3A_markerWrite(zT_280);
    return (unsigned int)(2);
    z_bb_108:
    zT_282 = self->registry;
    zT_283 = lhs;
    zT_285 = zF_AD61DB1B_typeRegistryIsPoint(zT_282, zT_283);
    if (zT_285) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_287 = "CPB";
    zT_289 = 3;
    zT_288.ptr = zT_287;
    zT_288.len = zT_289;
    cp6 = zT_288;
    zT_290 = cp6;
    zF_48AC7B3A_markerWrite(zT_290);
    return (unsigned int)(2);
    z_bb_110:
    goto z_bb_106;
}

/* semanticAnalyzerResolveLogical */
unsigned int zF_6F2B8B98_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    int zT_24;
    char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u loe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo2;
    zT_3 = "LOE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    loe = zT_4;
    zT_6 = loe;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_18 = self;
    zT_19 = node.child_1;
    zT_21 = zF_54F95822_semanticAnalyzerRes(zT_18, zT_19);
    rhs = zT_21;
    if ((int)(lhs == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_24 = rhs == (unsigned int)(2);
    goto z_bb_3;
    z_bb_2:
    zT_24 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_24) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_28 = "LOB";
    zT_30 = 3;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    lo1 = zT_29;
    zT_31 = lo1;
    zF_48AC7B3A_markerWrite(zT_31);
    return (unsigned int)(2);
    z_bb_5:
    zT_34 = "LOV";
    zT_36 = 3;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    lo2 = zT_35;
    zT_37 = lo2;
    zF_48AC7B3A_markerWrite(zT_37);
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveNegate */
unsigned int zF_09421FDF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    int zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((int)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3087E0A5_typeRegistryIsNumer(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveBitNot */
unsigned int zF_6B59E8AD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    int zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((int)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3290E9C4_typeRegistryIsInteg(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerVolatileDrop */
int zF_57090266_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    int zT_5;
    int zT_11;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    unsigned char zT_37;
    zT_33EF6BFB_TypeKind zT_43;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_112BF819_PtrPayload* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_112BF819_PtrPayload zT_53;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_D155D06D_Type* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_D155D06D_Type zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_E834303C_ArrayPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_E834303C_ArrayPayload zT_76;
    unsigned int zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_112BF819_PtrPayload* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_112BF819_PtrPayload zT_88;
    unsigned char zT_89;
    unsigned int zT_95;
    unsigned int zT_96;
    int zT_98;
    unsigned int zT_99;
    zT_33EF6BFB_TypeKind zT_102;
    zT_338B7C76_TypeRegistry* zT_108;
    zT_112BF819_PtrPayload* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_112BF819_PtrPayload zT_112;
    unsigned char zT_113;
    unsigned int zT_119;
    zT_33EF6BFB_TypeKind zT_121;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_0BB2A741_SlicePayload* zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    zT_0BB2A741_SlicePayload zT_131;
    unsigned char zT_132;
    unsigned int zT_138;
    int zT_140;
    int zT_143;
    unsigned int zT_144;
    int zT_147;
    int zT_150;
    unsigned int zT_151;
    zT_33EF6BFB_TypeKind zT_154;
    zT_338B7C76_TypeRegistry* zT_160;
    zT_0B10E8E9_OptionalPayload* zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    zT_0B10E8E9_OptionalPayload zT_164;
    zT_38C12417_SemanticAnalyzer* zT_165;
    unsigned int zT_166;
    unsigned int zT_168;
    zT_33EF6BFB_TypeKind zT_171;
    zT_338B7C76_TypeRegistry* zT_177;
    zT_112BF819_PtrPayload* zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_112BF819_PtrPayload zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    zT_338B7C76_TypeRegistry* zT_188;
    zT_112BF819_PtrPayload* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_112BF819_PtrPayload zT_192;
    unsigned char zT_193;
    unsigned int zT_199;
    unsigned int zT_200;
    zT_33EF6BFB_TypeKind zT_202;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_112BF819_PtrPayload* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_112BF819_PtrPayload zT_212;
    unsigned char zT_213;
    unsigned int zT_219;
    unsigned int zT_220;
    int zT_222;
    unsigned int zT_223;
    zT_33EF6BFB_TypeKind zT_226;
    zT_338B7C76_TypeRegistry* zT_232;
    zT_0B10E8E9_OptionalPayload* zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    zT_0B10E8E9_OptionalPayload zT_236;
    zT_38C12417_SemanticAnalyzer* zT_237;
    unsigned int zT_238;
    unsigned int zT_240;
    zT_33EF6BFB_TypeKind zT_243;
    zT_338B7C76_TypeRegistry* zT_249;
    zT_0BB2A741_SlicePayload* zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    zT_0BB2A741_SlicePayload zT_253;
    zT_33EF6BFB_TypeKind zT_254;
    zT_338B7C76_TypeRegistry* zT_260;
    zT_0BB2A741_SlicePayload* zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_0BB2A741_SlicePayload zT_264;
    unsigned char zT_265;
    unsigned int zT_271;
    unsigned int zT_272;
    zT_33EF6BFB_TypeKind zT_274;
    zT_338B7C76_TypeRegistry* zT_280;
    zT_112BF819_PtrPayload* zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    zT_112BF819_PtrPayload zT_284;
    unsigned char zT_285;
    unsigned int zT_291;
    unsigned int zT_292;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    zT_112BF819_PtrPayload sp;
    unsigned int sp_base_eff;
    zT_D155D06D_Type sp_pointee;
    zT_112BF819_PtrPayload dp;
    zT_112BF819_PtrPayload dp2;
    zT_0BB2A741_SlicePayload ds;
    zT_0B10E8E9_OptionalPayload opt;
    zT_112BF819_PtrPayload sp2;
    zT_112BF819_PtrPayload dp3;
    zT_112BF819_PtrPayload dp4;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_0BB2A741_SlicePayload ss;
    zT_0BB2A741_SlicePayload ds2;
    zT_112BF819_PtrPayload dp5;
    z_bb_0:
    if ((int)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    if ((int)(src_type == dst_type)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_18 = self->registry;
    zT_19 = zT_18->types_len;
    if ((int)((unsigned int)((unsigned int)src_type) >= zT_19)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    if ((int)((unsigned int)((unsigned int)dst_type) >= zT_24)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(0);
    z_bb_16:
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)src_type;
    zT_31 = zT_29[zT_30];
    s = zT_31;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)dst_type;
    zT_36 = zT_34[zT_35];
    d = zT_36;
    zT_37 = s.flags;
    if ((int)((unsigned char)(zT_37 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(0);
    z_bb_18:
    zT_43 = s.kind;
    if ((int)(zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_49 = self->registry;
    zT_50 = zT_49->ptr_items;
    zT_51 = s.payload_idx;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_50[zT_52];
    sp = zT_53;
    zT_55 = sp.base;
    sp_base_eff = zT_55;
    zT_56 = sp.base;
    zT_58 = self->registry;
    zT_59 = zT_58->types_len;
    if ((int)((unsigned int)((unsigned int)zT_56) < zT_59)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_171 = s.kind;
    if ((int)(zT_171 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_54; else goto z_bb_55;
    z_bb_21:
    zT_62 = self->registry;
    zT_63 = zT_62->types_items;
    zT_64 = sp.base;
    zT_65 = (unsigned int)zT_64;
    zT_66 = zT_63[zT_65];
    sp_pointee = zT_66;
    zT_67 = sp_pointee.kind;
    if ((int)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_78 = d.kind;
    if ((int)(zT_78 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_72 = self->registry;
    zT_73 = zT_72->array_items;
    zT_74 = sp_pointee.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    zT_77 = zT_76.elem;
    sp_base_eff = zT_77;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_84 = self->registry;
    zT_85 = zT_84->ptr_items;
    zT_86 = d.payload_idx;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zT_85[zT_87];
    dp = zT_88;
    zT_89 = d.flags;
    if ((int)((unsigned char)(zT_89 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_102 = d.kind;
    if ((int)(zT_102 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return (int)(0);
    z_bb_28:
    zT_95 = sp.base;
    zT_96 = dp.base;
    if ((int)(zT_95 == zT_96)) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_99 = dp.base;
    zT_98 = zT_99 == (unsigned int)(1);
    goto z_bb_31;
    z_bb_30:
    zT_98 = 1;
    goto z_bb_31;
    z_bb_31:
    return zT_98;
    z_bb_32:
    zT_108 = self->registry;
    zT_109 = zT_108->ptr_items;
    zT_110 = d.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    dp2 = zT_112;
    zT_113 = d.flags;
    if ((int)((unsigned char)(zT_113 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_121 = d.kind;
    if ((int)(zT_121 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    return (int)(0);
    z_bb_35:
    zT_119 = dp2.base;
    return (int)(sp_base_eff == zT_119);
    z_bb_36:
    zT_127 = self->registry;
    zT_128 = zT_127->slice_items;
    zT_129 = d.payload_idx;
    zT_130 = (unsigned int)zT_129;
    zT_131 = zT_128[zT_130];
    ds = zT_131;
    zT_132 = d.flags;
    if ((int)((unsigned char)(zT_132 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_154 = d.kind;
    if ((int)(zT_154 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_52; else goto z_bb_53;
    z_bb_38:
    return (int)(0);
    z_bb_39:
    zT_138 = ds.elem;
    if ((int)(sp_base_eff == zT_138)) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    if ((int)(sp_base_eff == (unsigned int)(14))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_140 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_140) goto z_bb_47; else goto z_bb_46;
    z_bb_43:
    zT_144 = ds.elem;
    zT_143 = zT_144 == (unsigned int)(8);
    goto z_bb_45;
    z_bb_44:
    zT_143 = 0;
    goto z_bb_45;
    z_bb_45:
    zT_140 = zT_143;
    goto z_bb_42;
    z_bb_46:
    if ((int)(sp_base_eff == (unsigned int)(8))) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    zT_147 = 1;
    goto z_bb_48;
    z_bb_48:
    return zT_147;
    z_bb_49:
    zT_151 = ds.elem;
    zT_150 = zT_151 == (unsigned int)(14);
    goto z_bb_51;
    z_bb_50:
    zT_150 = 0;
    goto z_bb_51;
    z_bb_51:
    zT_147 = zT_150;
    goto z_bb_48;
    z_bb_52:
    zT_160 = self->registry;
    zT_161 = zT_160->opt_items;
    zT_162 = d.payload_idx;
    zT_163 = (unsigned int)zT_162;
    zT_164 = zT_161[zT_163];
    opt = zT_164;
    zT_165 = self;
    zT_166 = src_type;
    zT_168 = opt.payload;
    self = zT_165;
    src_type = zT_166;
    dst_type = zT_168;
    goto z_bb_0;
    z_bb_53:
    return (int)(0);
    z_bb_54:
    zT_177 = self->registry;
    zT_178 = zT_177->ptr_items;
    zT_179 = s.payload_idx;
    zT_180 = (unsigned int)zT_179;
    zT_181 = zT_178[zT_180];
    sp2 = zT_181;
    zT_182 = d.kind;
    if ((int)(zT_182 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    zT_243 = s.kind;
    if ((int)(zT_243 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_69; else goto z_bb_70;
    z_bb_56:
    zT_188 = self->registry;
    zT_189 = zT_188->ptr_items;
    zT_190 = d.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    dp3 = zT_192;
    zT_193 = d.flags;
    if ((int)((unsigned char)(zT_193 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    zT_202 = d.kind;
    if ((int)(zT_202 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_60; else goto z_bb_61;
    z_bb_58:
    return (int)(0);
    z_bb_59:
    zT_199 = sp2.base;
    zT_200 = dp3.base;
    return (int)(zT_199 == zT_200);
    z_bb_60:
    zT_208 = self->registry;
    zT_209 = zT_208->ptr_items;
    zT_210 = d.payload_idx;
    zT_211 = (unsigned int)zT_210;
    zT_212 = zT_209[zT_211];
    dp4 = zT_212;
    zT_213 = d.flags;
    if ((int)((unsigned char)(zT_213 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_226 = d.kind;
    if ((int)(zT_226 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_67; else goto z_bb_68;
    z_bb_62:
    return (int)(0);
    z_bb_63:
    zT_219 = sp2.base;
    zT_220 = dp4.base;
    if ((int)(zT_219 == zT_220)) goto z_bb_65; else goto z_bb_64;
    z_bb_64:
    zT_223 = dp4.base;
    zT_222 = zT_223 == (unsigned int)(1);
    goto z_bb_66;
    z_bb_65:
    zT_222 = 1;
    goto z_bb_66;
    z_bb_66:
    return zT_222;
    z_bb_67:
    zT_232 = self->registry;
    zT_233 = zT_232->opt_items;
    zT_234 = d.payload_idx;
    zT_235 = (unsigned int)zT_234;
    zT_236 = zT_233[zT_235];
    opt2 = zT_236;
    zT_237 = self;
    zT_238 = src_type;
    zT_240 = opt2.payload;
    self = zT_237;
    src_type = zT_238;
    dst_type = zT_240;
    goto z_bb_0;
    z_bb_68:
    return (int)(0);
    z_bb_69:
    zT_249 = self->registry;
    zT_250 = zT_249->slice_items;
    zT_251 = s.payload_idx;
    zT_252 = (unsigned int)zT_251;
    zT_253 = zT_250[zT_252];
    ss = zT_253;
    zT_254 = d.kind;
    if ((int)(zT_254 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    return (int)(0);
    z_bb_71:
    zT_260 = self->registry;
    zT_261 = zT_260->slice_items;
    zT_262 = d.payload_idx;
    zT_263 = (unsigned int)zT_262;
    zT_264 = zT_261[zT_263];
    ds2 = zT_264;
    zT_265 = d.flags;
    if ((int)((unsigned char)(zT_265 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    zT_274 = d.kind;
    if ((int)(zT_274 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return (int)(0);
    z_bb_74:
    zT_271 = ss.elem;
    zT_272 = ds2.elem;
    return (int)(zT_271 == zT_272);
    z_bb_75:
    zT_280 = self->registry;
    zT_281 = zT_280->ptr_items;
    zT_282 = d.payload_idx;
    zT_283 = (unsigned int)zT_282;
    zT_284 = zT_281[zT_283];
    dp5 = zT_284;
    zT_285 = d.flags;
    if ((int)((unsigned char)(zT_285 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    return (int)(0);
    z_bb_77:
    return (int)(0);
    z_bb_78:
    zT_291 = ss.elem;
    zT_292 = dp5.base;
    return (int)(zT_291 == zT_292);
}

/* semanticAnalyzerMaybeDiagVolatileDrop */
int zF_86AAA417_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int span_node, unsigned int src_type, unsigned int dst_type) {
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7 = 0;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_F85C5DED_DiagnosticCollector* zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_35 = 0;
    zT_22A7C88B_AstNode vdrop_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdrop_msg;
    zT_4 = self;
    zT_5 = src_type;
    zT_6 = dst_type;
    zT_7 = zF_57090266_semanticAnalyzerVol(zT_4, zT_5, zT_6);
    if ((int)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_11 = self->store;
    zT_12 = span_node;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    vdrop_node = zT_14;
    zT_16 = "cannot implicitly discard 'volatile' qualifier; use @volatileCast to remove it";
    zT_18 = 78;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    vdrop_msg = zT_17;
    zT_19 = self->diag;
    zT_22 = self->source_file_id;
    zT_23 = vdrop_node.span_start;
    zT_31 = vdrop_node.span_start;
    zT_32 = vdrop_node.span_len;
    zT_25 = vdrop_msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_19, (unsigned char)(0), (unsigned short)(3000), zT_22, zT_23, (unsigned int)(zT_31 + (unsigned int)((unsigned int)zT_32)), zT_25);
    (void)zT_35;
    return (int)(1);
}

/* semanticAnalyzerPtrCastDropsVolatile */
int zF_5F2042EA_semanticAnalyzerPtr(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    int zT_5;
    int zT_11;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    zT_33EF6BFB_TypeKind zT_37;
    int zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_33EF6BFB_TypeKind zT_50;
    int zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char zT_63;
    unsigned char zT_69;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    if ((int)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    if ((int)(src_type == dst_type)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_18 = self->registry;
    zT_19 = zT_18->types_len;
    if ((int)((unsigned int)((unsigned int)src_type) >= zT_19)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    if ((int)((unsigned int)((unsigned int)dst_type) >= zT_24)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(0);
    z_bb_16:
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)src_type;
    zT_31 = zT_29[zT_30];
    s = zT_31;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)dst_type;
    zT_36 = zT_34[zT_35];
    d = zT_36;
    zT_37 = s.kind;
    if ((int)(zT_37 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_43 = s.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_19;
    z_bb_18:
    zT_42 = 1;
    goto z_bb_19;
    z_bb_19:
    if ((int)(!zT_42)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (int)(0);
    z_bb_21:
    zT_50 = d.kind;
    if ((int)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_56 = d.kind;
    zT_55 = zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_24;
    z_bb_23:
    zT_55 = 1;
    goto z_bb_24;
    z_bb_24:
    if ((int)(!zT_55)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(0);
    z_bb_26:
    zT_63 = s.flags;
    if ((int)((unsigned char)(zT_63 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(0);
    z_bb_28:
    zT_69 = d.flags;
    return (int)((unsigned char)(zT_69 & (unsigned char)(2)) == (unsigned char)(0));
}

/* semanticAnalyzerVolatileCastValid */
int zF_EC29CB82_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    int zT_5;
    int zT_11;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_D155D06D_Type* zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type zT_29;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    zT_33EF6BFB_TypeKind zT_48;
    int zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    unsigned char zT_61;
    unsigned char zT_67;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_112BF819_PtrPayload* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_112BF819_PtrPayload zT_78;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_112BF819_PtrPayload* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_112BF819_PtrPayload zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload dp;
    if ((int)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    if ((int)((unsigned int)((unsigned int)src_type) >= zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_21 = self->registry;
    zT_22 = zT_21->types_len;
    if ((int)((unsigned int)((unsigned int)dst_type) >= zT_22)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_26 = self->registry;
    zT_27 = zT_26->types_items;
    zT_28 = (unsigned int)src_type;
    zT_29 = zT_27[zT_28];
    s = zT_29;
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)dst_type;
    zT_34 = zT_32[zT_33];
    d = zT_34;
    zT_35 = s.kind;
    if ((int)(zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_41 = s.kind;
    zT_40 = zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_17;
    z_bb_16:
    zT_40 = 1;
    goto z_bb_17;
    z_bb_17:
    if ((int)(!zT_40)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (int)(0);
    z_bb_19:
    zT_48 = d.kind;
    if ((int)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_54 = d.kind;
    zT_53 = zT_54 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_22;
    z_bb_21:
    zT_53 = 1;
    goto z_bb_22;
    z_bb_22:
    if ((int)(!zT_53)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(0);
    z_bb_24:
    zT_61 = s.flags;
    if ((int)((unsigned char)(zT_61 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(0);
    z_bb_26:
    zT_67 = d.flags;
    if ((int)((unsigned char)(zT_67 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(0);
    z_bb_28:
    zT_74 = self->registry;
    zT_75 = zT_74->ptr_items;
    zT_76 = s.payload_idx;
    zT_77 = (unsigned int)zT_76;
    zT_78 = zT_75[zT_77];
    sp = zT_78;
    zT_80 = self->registry;
    zT_81 = zT_80->ptr_items;
    zT_82 = d.payload_idx;
    zT_83 = (unsigned int)zT_82;
    zT_84 = zT_81[zT_83];
    dp = zT_84;
    zT_85 = sp.base;
    zT_86 = dp.base;
    return (int)(zT_85 == zT_86);
}

/* tryRecordCoercion */
void zF_DF7434EB_tryRecordCoercion(zT_38C12417_SemanticAnalyzer* self, unsigned int src_node, unsigned int src_type, unsigned int dst_type) {
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_338B7C76_TypeRegistry* zT_23;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_33EF6BFB_TypeKind zT_38;
    char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_33EF6BFB_TypeKind zT_46;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_52 = {0};
    char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_8143F551_AstKind zT_59;
    int zT_63;
    zT_38C12417_SemanticAnalyzer* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    int zT_69 = 0;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    int zT_74 = 0;
    char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_0FB7FB13_CoercionKind zT_88 = 0;
    char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    int zT_100;
    int zT_103;
    zT_338B7C76_TypeRegistry* zT_104;
    unsigned int zT_105;
    int zT_107 = 0;
    zT_66E7D2EF_CoercionTable* zT_108;
    unsigned int zT_109;
    zT_0FB7FB13_CoercionKind zT_110;
    unsigned int zT_111;
    char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dm;
    zT_D155D06D_Type src_t;
    zT_D155D06D_Type dst_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_skm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dkm;
    zT_22A7C88B_AstNode snode;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs1_m;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u cka_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_km;
    zT_5 = "COE:N";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    coe_nm = zT_6;
    zT_8 = coe_nm;
    zT_9 = src_node;
    zF_C914CB83_markerWriteInt(zT_8, zT_9);
    zT_11 = "COE:S";
    zT_13 = 5;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    coe_sm = zT_12;
    zT_14 = coe_sm;
    zT_15 = src_type;
    zF_C914CB83_markerWriteInt(zT_14, zT_15);
    zT_17 = "COE:D";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    coe_dm = zT_18;
    zT_20 = coe_dm;
    zT_21 = dst_type;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = self->registry;
    zT_24 = zT_23->types_items;
    zT_25 = (unsigned int)src_type;
    zT_26 = zT_24[zT_25];
    src_t = zT_26;
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)dst_type;
    zT_31 = zT_29[zT_30];
    dst_t = zT_31;
    zT_33 = "COE:SK";
    zT_35 = 6;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    coe_skm = zT_34;
    zT_36 = coe_skm;
    zT_38 = src_t.kind;
    zF_C914CB83_markerWriteInt(zT_36, (unsigned int)((unsigned int)zT_38));
    zT_41 = "COE:DK";
    zT_43 = 6;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    coe_dkm = zT_42;
    zT_44 = coe_dkm;
    zT_46 = dst_t.kind;
    zF_C914CB83_markerWriteInt(zT_44, (unsigned int)((unsigned int)zT_46));
    zT_49 = self->store;
    zT_50 = src_node;
    zT_52 = zF_FCDD1D35_astStoreNodeAt(zT_49, zT_50);
    snode = zT_52;
    zT_54 = "COE:NK";
    zT_56 = 6;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    coe_nkm = zT_55;
    zT_57 = coe_nkm;
    zT_59 = snode.kind;
    zF_C914CB83_markerWriteInt(zT_57, (unsigned int)((unsigned int)zT_59));
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_63 = src_type == dst_type;
    goto z_bb_3;
    z_bb_2:
    zT_63 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_63) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_65 = self;
    zT_66 = src_node;
    zT_67 = src_type;
    zT_68 = dst_type;
    zT_69 = zF_86AAA417_semanticAnalyzerMay(zT_65, zT_66, zT_67, zT_68);
    if (zT_69) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    zT_70 = self->registry;
    zT_71 = src_type;
    zT_72 = dst_type;
    zT_74 = zF_683AEB7F_typeRegistryIsAssig(zT_70, zT_71, zT_72);
    if ((int)(!zT_74)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    if ((int)(src_type == (unsigned int)(17))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_79 = "CS1\n";
    zT_81 = 4;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    cs1_m = zT_80;
    zT_82 = cs1_m;
    zF_48AC7B3A_markerWrite(zT_82);
    goto z_bb_11;
    z_bb_11:
    zT_84 = self->registry;
    zT_85 = src_type;
    zT_86 = dst_type;
    zT_88 = zF_713658BF_classifyCoercion(zT_84, zT_85, zT_86);
    ck = zT_88;
    zT_90 = "CCK:ca";
    zT_92 = 6;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    cka_m = zT_91;
    zT_93 = cka_m;
    zF_C914CB83_markerWriteInt(zT_93, (unsigned int)((unsigned int)ck));
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    if ((int)(src_type == (unsigned int)(17))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_100 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_100) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_104 = self->registry;
    zT_105 = dst_type;
    zT_107 = zF_AD61DB1B_typeRegistryIsPoint(zT_104, zT_105);
    zT_103 = zT_107;
    goto z_bb_17;
    z_bb_16:
    zT_103 = 0;
    goto z_bb_17;
    z_bb_17:
    zT_100 = zT_103;
    goto z_bb_14;
    z_bb_18:
    zT_108 = self->coercion_table;
    zT_109 = src_node;
    zT_110 = ck;
    zT_111 = dst_type;
    zF_D21AE60A_coercionTableAdd(zT_108, zT_109, zT_110, zT_111);
    zT_114 = "COR:N";
    zT_116 = 5;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    cor_nm = zT_115;
    zT_117 = cor_nm;
    zT_118 = src_node;
    zF_C914CB83_markerWriteInt(zT_117, zT_118);
    zT_120 = "COR:K";
    zT_122 = 5;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    cor_km = zT_121;
    zT_123 = cor_km;
    zF_C914CB83_markerWriteInt(zT_123, (unsigned int)((unsigned int)ck));
    goto z_bb_19;
    z_bb_19:
    return;
}

/* errLitSrcType */
unsigned int zF_FFC95E09_errLitSrcType(zT_38C12417_SemanticAnalyzer* self, unsigned int child_0, unsigned int target_ty, unsigned int ret_val) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_D155D06D_Type* zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_42C2D6BF_EUPayload* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_42C2D6BF_EUPayload zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode rn;
    zT_D155D06D_Type frt;
    zT_5 = self->store;
    zT_6 = child_0;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    rn = zT_8;
    zT_9 = rn.kind;
    if ((int)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = self->registry;
    zT_16 = zT_15->types_items;
    zT_17 = (unsigned int)target_ty;
    zT_18 = zT_16[zT_17];
    frt = zT_18;
    zT_19 = frt.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return ret_val;
    z_bb_3:
    zT_24 = self->registry;
    zT_25 = zT_24->eu_items;
    zT_26 = frt.payload_idx;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_25[zT_27];
    zT_29 = zT_28.error_set;
    return zT_29;
    z_bb_4:
    goto z_bb_2;
}

/* resolveReturnStmt */
void zF_F231D87F_resolveReturnStmt(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    int zT_13 = 0;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_19;
    char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_F85C5DED_DiagnosticCollector* zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_35 = 0;
    unsigned int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    zT_38C12417_SemanticAnalyzer* zT_47;
    unsigned int zT_48;
    int zT_51;
    unsigned int zT_52;
    char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_38C12417_SemanticAnalyzer* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    zT_38C12417_SemanticAnalyzer* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_86 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int brsp;
    unsigned int brep;
    zT_8F083A69_Slice_zT_0B42B2F8_u br_msg;
    unsigned int ret_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_fm;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((int)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_11 = self->current_fn_return;
    zT_13 = zF_15CE7BE8_fnReturnRequiresVal(zT_10, zT_11);
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_36 = node.child_0;
    if ((int)(zT_36 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = node.span_start;
    brsp = zT_15;
    zT_17 = node.span_len;
    zT_19 = brsp + (unsigned int)((unsigned int)zT_17);
    brep = zT_19;
    zT_21 = "return with no value in function returning non-void";
    zT_23 = 51;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    br_msg = zT_22;
    zT_24 = self->diag;
    zT_27 = self->source_file_id;
    zT_28 = brsp;
    zT_29 = brep;
    zT_30 = br_msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_24, (unsigned char)(0), (unsigned short)(3003), zT_27, zT_28, zT_29, zT_30);
    (void)zT_35;
    goto z_bb_4;
    z_bb_4:
    return;
    z_bb_5:
    zT_39 = self;
    zT_40 = self->current_fn_return;
    zF_9665A229_pushExpectedType(zT_39, zT_40);
    zT_43 = self;
    zT_44 = node.child_0;
    zT_46 = zF_54F95822_semanticAnalyzerRes(zT_43, zT_44);
    ret_val = zT_46;
    zT_47 = self;
    zF_BC478E78_popExpectedType(zT_47);
    zT_48 = self->current_fn_return;
    if ((int)(zT_48 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_52 = self->current_fn_return;
    zT_51 = zT_52 != (unsigned int)(1);
    goto z_bb_9;
    z_bb_8:
    zT_51 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_51) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_56 = "T2F:C";
    zT_58 = 5;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    t2f_nm = zT_57;
    zT_59 = t2f_nm;
    zT_60 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_59, zT_60);
    zT_63 = "T2F:R";
    zT_65 = 5;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    t2f_rm = zT_64;
    zT_66 = t2f_rm;
    zT_67 = ret_val;
    zF_C914CB83_markerWriteInt(zT_66, zT_67);
    zT_69 = "T2F:F";
    zT_71 = 5;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    t2f_fm = zT_70;
    zT_72 = t2f_fm;
    zT_73 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_72, zT_73);
    zT_75 = self;
    zT_76 = node.child_0;
    zT_80 = self;
    zT_81 = node.child_0;
    zT_82 = self->current_fn_return;
    zT_83 = ret_val;
    zT_86 = zF_FFC95E09_errLitSrcType(zT_80, zT_81, zT_82, zT_83);
    zT_77 = zT_86;
    zT_78 = self->current_fn_return;
    zF_DF7434EB_tryRecordCoercion(zT_75, zT_76, zT_77, zT_78);
    goto z_bb_11;
    z_bb_11:
    goto z_bb_6;
}

/* semanticAnalyzerResolveFnCall */
unsigned int zF_87E78775_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    unsigned int zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_8143F551_AstKind zT_23;
    zT_3D7259E2_SymbolRegistry* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int zT_38 = 0;
    zT_50791B23_Opt_842 zT_39 = {0};
    unsigned char zT_40;
    char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_8EED1867_ResolvedTypeTable* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_3C598AEF_SymbolKind zT_57;
    int zT_62;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode zT_71 = {0};
    zT_8143F551_AstKind zT_72;
    zT_6B0A7D14_AstStore* zT_78;
    zT_623E1332_anon_217967 zT_79;
    zT_243D6A41_FnProto* zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_85 = 0;
    unsigned int zT_86;
    zT_243D6A41_FnProto zT_87;
    unsigned int zT_88;
    zT_8EED1867_ResolvedTypeTable* zT_92;
    unsigned int zT_93;
    zT_BAEE192E_Opt_10 zT_96 = {0};
    unsigned char zT_98;
    unsigned int zT_99;
    char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    unsigned char zT_108;
    char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_ABC1EBBE_TypeResolveEnv zT_117;
    zT_6B0A7D14_AstStore* zT_118;
    zT_338B7C76_TypeRegistry* zT_119;
    zT_3D7259E2_SymbolRegistry* zT_120;
    zT_D3EB6303_StringInterner* zT_121;
    unsigned int zT_122;
    zT_ABC1EBBE_TypeResolveEnv* zT_124;
    unsigned int zT_125;
    unsigned int zT_130 = 0;
    char* zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    char* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_167 = {0};
    unsigned char zT_169;
    unsigned short zT_171;
    unsigned int zT_173;
    int zT_174;
    zT_8EED1867_ResolvedTypeTable* zT_177;
    unsigned int zT_178;
    zT_BAEE192E_Opt_10 zT_180 = {0};
    unsigned char zT_181;
    char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_D155D06D_Type* zT_190;
    unsigned int zT_191;
    zT_D155D06D_Type zT_192;
    zT_33EF6BFB_TypeKind zT_193;
    zT_338B7C76_TypeRegistry* zT_199;
    zT_0317B1D5_FnPayload* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    zT_0317B1D5_FnPayload zT_203;
    unsigned short zT_204;
    unsigned int zT_205;
    unsigned char zT_206;
    int zT_208;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_214;
    int zT_217;
    unsigned int zT_225;
    unsigned int zT_226;
    zT_21D3708C_U32ToU32Map* zT_227;
    unsigned int zT_228;
    zT_BAEE192E_Opt_10 zT_230 = {0};
    unsigned char zT_231;
    zT_338B7C76_TypeRegistry* zT_233;
    unsigned int* zT_234;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_21D3708C_U32ToU32Map* zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned int* zT_242;
    zT_38C12417_SemanticAnalyzer* zT_244;
    unsigned int zT_245;
    zT_38C12417_SemanticAnalyzer* zT_247;
    unsigned int zT_248;
    unsigned int* zT_249;
    unsigned int zT_251 = 0;
    zT_38C12417_SemanticAnalyzer* zT_252;
    int zT_255;
    zT_38C12417_SemanticAnalyzer* zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned int* zT_262;
    zT_38C12417_SemanticAnalyzer* zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int* zT_268;
    unsigned int zT_270 = 0;
    int zT_271;
    unsigned int zT_272;
    zT_8EED1867_ResolvedTypeTable* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    zT_38C12417_SemanticAnalyzer* zT_278;
    unsigned int zT_279;
    unsigned int zT_281 = 0;
    char* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    zT_338B7C76_TypeRegistry* zT_291;
    zT_D155D06D_Type* zT_292;
    unsigned int zT_293;
    zT_D155D06D_Type zT_294;
    zT_33EF6BFB_TypeKind zT_295;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_112BF819_PtrPayload* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_112BF819_PtrPayload zT_305;
    zT_338B7C76_TypeRegistry* zT_307;
    zT_D155D06D_Type* zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    zT_D155D06D_Type zT_311;
    zT_33EF6BFB_TypeKind zT_312;
    unsigned int zT_317;
    zT_338B7C76_TypeRegistry* zT_318;
    zT_D155D06D_Type* zT_319;
    unsigned int zT_320;
    zT_D155D06D_Type zT_321;
    zT_33EF6BFB_TypeKind zT_322;
    char* zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    unsigned int zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    char* zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    unsigned int zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    unsigned int zT_338;
    char* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    zT_33EF6BFB_TypeKind zT_345;
    zT_6B0A7D14_AstStore* zT_348;
    unsigned int zT_349;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_351 = {0};
    unsigned int zT_353;
    unsigned int zT_355;
    zT_38C12417_SemanticAnalyzer* zT_357;
    zT_38C12417_SemanticAnalyzer* zT_360;
    unsigned int zT_361;
    unsigned int* zT_362;
    unsigned int zT_364 = 0;
    zT_38C12417_SemanticAnalyzer* zT_365;
    unsigned int zT_367;
    char* zT_370;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    unsigned int zT_372;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_373;
    zT_338B7C76_TypeRegistry* zT_375;
    zT_0317B1D5_FnPayload* zT_376;
    unsigned int zT_377;
    unsigned int zT_378;
    zT_0317B1D5_FnPayload zT_379;
    char* zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_382;
    unsigned int zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    unsigned short zT_386;
    unsigned int zT_387;
    unsigned int zT_389;
    unsigned int zT_390;
    char* zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_394;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_395;
    zT_6B0A7D14_AstStore* zT_397;
    unsigned int zT_398;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_400 = {0};
    char* zT_402;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    unsigned int zT_404;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405;
    unsigned char zT_407;
    unsigned char zT_408;
    unsigned char zT_413;
    unsigned int zT_418;
    unsigned int zT_420;
    unsigned int zT_422;
    unsigned int zT_424;
    int zT_426;
    unsigned int zT_427;
    char* zT_429;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_430;
    unsigned int zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_432;
    char* zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned int zT_436;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437;
    zT_338B7C76_TypeRegistry* zT_439;
    unsigned int zT_440;
    char* zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_444;
    unsigned int zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    char* zT_451;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_452;
    unsigned int zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_454;
    zT_338B7C76_TypeRegistry* zT_456;
    unsigned int* zT_457;
    unsigned int zT_458;
    unsigned int zT_459;
    zT_21D3708C_U32ToU32Map* zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    unsigned int* zT_464;
    char* zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    unsigned int zT_469;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_470;
    char* zT_474;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_475;
    unsigned int zT_476;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_477;
    unsigned int zT_478;
    char* zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned int zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484;
    unsigned int* zT_485;
    char* zT_488;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_489;
    unsigned int zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    zT_38C12417_SemanticAnalyzer* zT_492;
    unsigned int zT_493;
    zT_38C12417_SemanticAnalyzer* zT_495;
    unsigned int zT_496;
    unsigned int* zT_497;
    unsigned int zT_499 = 0;
    zT_38C12417_SemanticAnalyzer* zT_500;
    zT_21D3708C_U32ToU32Map* zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    unsigned int* zT_509;
    zT_21D3708C_U32ToU32Map* zT_515;
    unsigned int zT_516;
    unsigned int zT_517;
    unsigned int* zT_519;
    zT_38C12417_SemanticAnalyzer* zT_521;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    unsigned int* zT_525;
    zT_38C12417_SemanticAnalyzer* zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    unsigned int zT_530;
    unsigned int* zT_531;
    unsigned int zT_533 = 0;
    int zT_534;
    unsigned int zT_535;
    unsigned int zT_540;
    zT_38C12417_SemanticAnalyzer* zT_542;
    zT_38C12417_SemanticAnalyzer* zT_546;
    unsigned int zT_547;
    unsigned int* zT_548;
    unsigned int zT_550 = 0;
    zT_38C12417_SemanticAnalyzer* zT_551;
    zT_21D3708C_U32ToU32Map* zT_554;
    unsigned int zT_555;
    unsigned int zT_556;
    unsigned int* zT_558;
    int zT_560;
    unsigned int zT_561;
    char* zT_563;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_564;
    unsigned int zT_565;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_566;
    unsigned int zT_567;
    unsigned int zT_569;
    zT_8F083A69_Slice_zT_0B42B2F8_u fne;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee_node;
    unsigned int direct_ret;
    unsigned int decl_cap;
    zT_50791B23_Opt_842 sym;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u xf;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_22A7C88B_AstNode dn;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 rt;
    unsigned int rnt_val;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u brnt_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfnr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u drfb_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_fc;
    unsigned int fc_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1r_m;
    zT_3CB0179A_Slice_zT_05F374B1_u args;
    unsigned char has_params;
    unsigned short pcount;
    unsigned int pstart;
    unsigned int callee_type;
    zT_BAEE192E_Opt_10 ft;
    unsigned int ai;
    unsigned int ftid;
    zT_8F083A69_Slice_zT_0B42B2F8_u sfm;
    zT_D155D06D_Type ft_ty;
    zT_0317B1D5_FnPayload ftp;
    unsigned int expected;
    unsigned int cpp_key;
    unsigned int dxc_at;
    unsigned int cpp_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn2;
    zT_D155D06D_Type callee_ty;
    zT_112BF819_PtrPayload cptr_pp;
    zT_D155D06D_Type cptr_pointee;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ck_m;
    zT_3CB0179A_Slice_zT_05F374B1_u fn3_args;
    unsigned int fn3_i;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4a;
    zT_0317B1D5_FnPayload fnp;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4b;
    unsigned int pcount_1;
    unsigned int pstart_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4c;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4d;
    unsigned char is_var;
    unsigned int fixed;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4e;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4y_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4f;
    unsigned int param_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_am;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4g;
    unsigned int arg_type;
    unsigned int vi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4_rm;
    unsigned int varg_type;
    zT_3 = "FNE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fne = zT_4;
    zT_6 = fne;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    callee_node = zT_17;
    zT_19 = 0;
    direct_ret = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    decl_cap = zT_22;
    zT_23 = callee_node.kind;
    if ((int)(zT_23 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_29 = self->symbols;
    zT_30 = self->module_id;
    zT_34 = self->store;
    zT_35 = node.child_0;
    zT_38 = zF_53458827_astStoreIdentifier(zT_34, zT_35);
    zT_31 = zT_38;
    zT_39 = zF_A398987E_symbolRegistryQuali(zT_29, zT_30, zT_31);
    sym = zT_39;
    zT_40 = sym.has_value;
    if (zT_40) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    if ((int)(direct_ret != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    s = sym.value;
    zT_43 = "XF\n";
    zT_45 = 3;
    zT_44.ptr = zT_43;
    zT_44.len = zT_45;
    xf = zT_44;
    zT_46 = xf;
    zF_48AC7B3A_markerWrite(zT_46);
    zT_47 = s->decl_node;
    decl_cap = zT_47;
    zT_48 = s->type_id;
    if ((int)(zT_48 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_146 = "xS\n";
    zT_148 = 3;
    zT_147.ptr = zT_146;
    zT_147.len = zT_148;
    xs = zT_147;
    zT_149 = xs;
    zF_48AC7B3A_markerWrite(zT_149);
    goto z_bb_4;
    z_bb_6:
    zT_51 = self->type_table;
    zT_52 = node.child_0;
    zT_53 = s->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_51, zT_52, zT_53);
    goto z_bb_7;
    z_bb_7:
    zT_57 = s->kind;
    if ((int)(zT_57 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_63 = s->decl_node;
    zT_62 = zT_63 != (unsigned int)(0);
    goto z_bb_10;
    z_bb_9:
    zT_62 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_62) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_67 = self->store;
    zT_68 = s->decl_node;
    zT_71 = zF_FCDD1D35_astStoreNodeAt(zT_67, zT_68);
    dn = zT_71;
    zT_72 = dn.kind;
    if ((int)(zT_72 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_4;
    z_bb_13:
    zT_78 = self->store;
    zT_79 = zT_78->fn_protos;
    zT_80 = zT_79.items;
    zT_81 = self->store;
    zT_82 = s->decl_node;
    zT_85 = zF_8BA26B9E_astStoreNodePayload(zT_81, zT_82);
    zT_86 = (unsigned int)zT_85;
    zT_87 = zT_80[zT_86];
    proto = zT_87;
    zT_88 = proto.return_type_node;
    if ((int)(zT_88 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_92 = self->type_table;
    zT_93 = proto.return_type_node;
    zT_96 = zF_999DCF51_resolvedTypeTableGe(zT_92, zT_93);
    rt = zT_96;
    zT_98 = rt.has_value;
    if (zT_98) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    t = rt.value;
    zT_99 = t;
    goto z_bb_19;
    z_bb_18:
    zT_99 = 0;
    goto z_bb_19;
    z_bb_19:
    rnt_val = zT_99;
    zT_103 = "BR:rnt";
    zT_105 = 6;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    brnt_m = zT_104;
    zT_106 = brnt_m;
    zT_107 = rnt_val;
    zF_C914CB83_markerWriteInt(zT_106, zT_107);
    zT_108 = rt.has_value;
    if (zT_108) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    t = rt.value;
    direct_ret = t;
    goto z_bb_21;
    z_bb_21:
    zT_140 = "BR:fnr";
    zT_142 = 6;
    zT_141.ptr = zT_140;
    zT_141.len = zT_142;
    brfnr_m = zT_141;
    zT_143 = brfnr_m;
    zT_144 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_143, zT_144);
    goto z_bb_16;
    z_bb_22:
    zT_111 = "DRETFB:n";
    zT_113 = 8;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    drfb_m = zT_112;
    zT_114 = drfb_m;
    zT_115 = node_idx;
    zF_C914CB83_markerWriteInt(zT_114, zT_115);
    zT_118 = self->store;
    zT_117.store = zT_118;
    zT_119 = self->registry;
    zT_117.typereg = zT_119;
    zT_120 = self->symbols;
    zT_117.symbol_reg = zT_120;
    zT_121 = self->interner;
    zT_117.interner = zT_121;
    zT_122 = s->module_id;
    zT_117.module_id = zT_122;
    tre_env_fc = zT_117;
    zT_124 = &tre_env_fc;
    zT_125 = proto.return_type_node;
    zT_130 = zF_F2107C15_resolveTypeExprFull(zT_124, zT_125, (unsigned int)(0));
    fc_rt = zT_130;
    zT_132 = "BR:fc";
    zT_134 = 5;
    zT_133.ptr = zT_132;
    zT_133.len = zT_134;
    brfc_m = zT_133;
    zT_135 = brfc_m;
    zT_136 = fc_rt;
    zF_C914CB83_markerWriteInt(zT_135, zT_136);
    if ((int)(fc_rt != (unsigned int)(18))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    direct_ret = fc_rt;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_153 = "FN1\n";
    zT_155 = 4;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    fn1 = zT_154;
    zT_156 = fn1;
    zF_48AC7B3A_markerWrite(zT_156);
    zT_158 = "FN1:R";
    zT_160 = 5;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    fn1r_m = zT_159;
    zT_161 = fn1r_m;
    zT_162 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_161, zT_162);
    zT_164 = self->store;
    zT_165 = node_idx;
    zT_167 = zF_850FDF81_astStoreNodeExtraCh(zT_164, zT_165);
    args = zT_167;
    zT_169 = 0;
    has_params = zT_169;
    zT_171 = 0;
    pcount = zT_171;
    zT_173 = 0;
    pstart = zT_173;
    zT_174 = 0;
    if ((int)(decl_cap != (unsigned int)zT_174)) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_278 = self;
    zT_279 = node.child_0;
    zT_281 = zF_54F95822_semanticAnalyzerRes(zT_278, zT_279);
    callee_type = zT_281;
    if ((int)(callee_type == (unsigned int)(0))) goto z_bb_50; else goto z_bb_51;
    z_bb_27:
    zT_177 = self->type_table;
    zT_178 = decl_cap;
    zT_180 = zF_999DCF51_resolvedTypeTableGe(zT_177, zT_178);
    ft = zT_180;
    zT_181 = ft.has_value;
    if (zT_181) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_208 = 0;
    zT_209 = (unsigned int)zT_208;
    ai = zT_209;
    goto z_bb_33;
    z_bb_29:
    ftid = ft.value;
    zT_184 = "SF:H\n";
    zT_186 = 5;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    sfm = zT_185;
    zT_187 = sfm;
    zF_48AC7B3A_markerWrite(zT_187);
    zT_189 = self->registry;
    zT_190 = zT_189->types_items;
    zT_191 = (unsigned int)ftid;
    zT_192 = zT_190[zT_191];
    ft_ty = zT_192;
    zT_193 = ft_ty.kind;
    if ((int)(zT_193 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_199 = self->registry;
    zT_200 = zT_199->fn_items;
    zT_201 = ft_ty.payload_idx;
    zT_202 = (unsigned int)zT_201;
    zT_203 = zT_200[zT_202];
    ftp = zT_203;
    zT_204 = ftp.params_count;
    pcount = zT_204;
    zT_205 = ftp.params_start;
    pstart = zT_205;
    zT_206 = 1;
    has_params = zT_206;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_211 = args.len;
    if ((int)(ai < zT_211)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_214 = 0;
    expected = zT_214;
    if ((int)(has_params != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_273 = self->type_table;
    zT_274 = node_idx;
    zT_275 = direct_ret;
    zF_19B4A07D_resolvedTypeTableSe(zT_273, zT_274, zT_275);
    return direct_ret;
    z_bb_36:
    zT_271 = 1;
    zT_272 = ai + zT_271;
    ai = zT_272;
    goto z_bb_33;
    z_bb_37:
    zT_217 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_39;
    z_bb_38:
    zT_217 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_217) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_225 = (unsigned int)((unsigned int)((unsigned int)decl_cap) << (unsigned int)(16)) | (unsigned int)((unsigned int)ai);
    cpp_key = zT_225;
    zT_226 = 18;
    expected = zT_226;
    zT_227 = self->call_param_map;
    zT_228 = cpp_key;
    zT_230 = zF_F3EE5998_u32ToU32MapGet(zT_227, zT_228);
    zT_231 = zT_230.has_value;
    if (zT_231) goto z_bb_42; else goto z_bb_44;
    z_bb_41:
    zT_244 = self;
    zT_245 = expected;
    zF_9665A229_pushExpectedType(zT_244, zT_245);
    zT_247 = self;
    zT_249 = args.ptr;
    zT_248 = zT_249[ai];
    zT_251 = zF_54F95822_semanticAnalyzerRes(zT_247, zT_248);
    dxc_at = zT_251;
    zT_252 = self;
    zF_BC478E78_popExpectedType(zT_252);
    if ((int)(has_params != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_42:
    cpp_v = zT_230.value;
    expected = cpp_v;
    goto z_bb_43;
    z_bb_43:
    zT_238 = self->call_arg_types;
    zT_242 = args.ptr;
    zT_239 = zT_242[ai];
    zT_240 = expected;
    zF_26476265_u32ToU32MapPut(zT_238, zT_239, zT_240);
    goto z_bb_41;
    z_bb_44:
    zT_233 = self->registry;
    zT_234 = zT_233->xt_items;
    zT_236 = (unsigned int)((unsigned int)pstart) + ai;
    zT_237 = zT_234[zT_236];
    expected = zT_237;
    goto z_bb_43;
    z_bb_45:
    zT_255 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_47;
    z_bb_46:
    zT_255 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_255) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_258 = self;
    zT_262 = args.ptr;
    zT_259 = zT_262[ai];
    zT_264 = self;
    zT_268 = args.ptr;
    zT_265 = zT_268[ai];
    zT_266 = expected;
    zT_267 = dxc_at;
    zT_270 = zF_FFC95E09_errLitSrcType(zT_264, zT_265, zT_266, zT_267);
    zT_260 = zT_270;
    zT_261 = expected;
    zF_DF7434EB_tryRecordCoercion(zT_258, zT_259, zT_260, zT_261);
    goto z_bb_49;
    z_bb_49:
    goto z_bb_36;
    z_bb_50:
    zT_285 = "FN2\n";
    zT_287 = 4;
    zT_286.ptr = zT_285;
    zT_286.len = zT_287;
    fn2 = zT_286;
    zT_288 = fn2;
    zF_48AC7B3A_markerWrite(zT_288);
    return (unsigned int)(1);
    z_bb_51:
    zT_291 = self->registry;
    zT_292 = zT_291->types_items;
    zT_293 = (unsigned int)callee_type;
    zT_294 = zT_292[zT_293];
    callee_ty = zT_294;
    zT_295 = callee_ty.kind;
    if ((int)(zT_295 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_301 = self->registry;
    zT_302 = zT_301->ptr_items;
    zT_303 = callee_ty.payload_idx;
    zT_304 = (unsigned int)zT_303;
    zT_305 = zT_302[zT_304];
    cptr_pp = zT_305;
    zT_307 = self->registry;
    zT_308 = zT_307->types_items;
    zT_309 = cptr_pp.base;
    zT_310 = (unsigned int)zT_309;
    zT_311 = zT_308[zT_310];
    cptr_pointee = zT_311;
    zT_312 = cptr_pointee.kind;
    if ((int)(zT_312 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_322 = callee_ty.kind;
    if ((int)(zT_322 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    zT_317 = cptr_pp.base;
    callee_type = zT_317;
    zT_318 = self->registry;
    zT_319 = zT_318->types_items;
    zT_320 = (unsigned int)callee_type;
    zT_321 = zT_319[zT_320];
    callee_ty = zT_321;
    goto z_bb_55;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_328 = "FN3:N";
    zT_330 = 5;
    zT_329.ptr = zT_328;
    zT_329.len = zT_330;
    fn3 = zT_329;
    zT_331 = fn3;
    zT_332 = node_idx;
    zF_C914CB83_markerWriteInt(zT_331, zT_332);
    zT_334 = "FN3:T";
    zT_336 = 5;
    zT_335.ptr = zT_334;
    zT_335.len = zT_336;
    fn3_ct_m = zT_335;
    zT_337 = fn3_ct_m;
    zT_338 = callee_type;
    zF_C914CB83_markerWriteInt(zT_337, zT_338);
    zT_340 = "FN3:K";
    zT_342 = 5;
    zT_341.ptr = zT_340;
    zT_341.len = zT_342;
    fn3_ck_m = zT_341;
    zT_343 = fn3_ck_m;
    zT_345 = callee_ty.kind;
    zF_C914CB83_markerWriteInt(zT_343, (unsigned int)((unsigned int)zT_345));
    zT_348 = self->store;
    zT_349 = node_idx;
    zT_351 = zF_850FDF81_astStoreNodeExtraCh(zT_348, zT_349);
    fn3_args = zT_351;
    zT_353 = 0;
    fn3_i = zT_353;
    goto z_bb_58;
    z_bb_57:
    zT_370 = "FN4a\n";
    zT_372 = 5;
    zT_371.ptr = zT_370;
    zT_371.len = zT_372;
    fn4a = zT_371;
    zT_373 = fn4a;
    zF_48AC7B3A_markerWrite(zT_373);
    zT_375 = self->registry;
    zT_376 = zT_375->fn_items;
    zT_377 = callee_ty.payload_idx;
    zT_378 = (unsigned int)zT_377;
    zT_379 = zT_376[zT_378];
    fnp = zT_379;
    zT_381 = "FN4b\n";
    zT_383 = 5;
    zT_382.ptr = zT_381;
    zT_382.len = zT_383;
    fn4b = zT_382;
    zT_384 = fn4b;
    zF_48AC7B3A_markerWrite(zT_384);
    zT_386 = fnp.params_count;
    zT_387 = (unsigned int)zT_386;
    pcount_1 = zT_387;
    zT_389 = fnp.params_start;
    zT_390 = (unsigned int)zT_389;
    pstart_2 = zT_390;
    zT_392 = "FN4c\n";
    zT_394 = 5;
    zT_393.ptr = zT_392;
    zT_393.len = zT_394;
    fn4c = zT_393;
    zT_395 = fn4c;
    zF_48AC7B3A_markerWrite(zT_395);
    zT_397 = self->store;
    zT_398 = node_idx;
    zT_400 = zF_850FDF81_astStoreNodeExtraCh(zT_397, zT_398);
    args = zT_400;
    zT_402 = "FN4d\n";
    zT_404 = 5;
    zT_403.ptr = zT_402;
    zT_403.len = zT_404;
    fn4d = zT_403;
    zT_405 = fn4d;
    zF_48AC7B3A_markerWrite(zT_405);
    zT_407 = 0;
    is_var = zT_407;
    zT_408 = fnp.flags_packed;
    if ((int)((unsigned char)(zT_408 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_58:
    zT_355 = fn3_args.len;
    if ((int)(fn3_i < zT_355)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_357 = self;
    zF_9665A229_pushExpectedType(zT_357, (unsigned int)(0));
    zT_360 = self;
    zT_362 = fn3_args.ptr;
    zT_361 = zT_362[fn3_i];
    zT_364 = zF_54F95822_semanticAnalyzerRes(zT_360, zT_361);
    (void)zT_364;
    zT_365 = self;
    zF_BC478E78_popExpectedType(zT_365);
    goto z_bb_61;
    z_bb_60:
    return (unsigned int)(1);
    z_bb_61:
    zT_367 = fn3_i + (unsigned int)(1);
    fn3_i = zT_367;
    goto z_bb_58;
    z_bb_62:
    zT_413 = 1;
    is_var = zT_413;
    goto z_bb_63;
    z_bb_63:
    fixed = pcount_1;
    if ((int)(is_var != (unsigned char)(0))) goto z_bb_64; else goto z_bb_66;
    z_bb_64:
    zT_418 = args.len;
    if ((int)(zT_418 < fixed)) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    zT_426 = 0;
    zT_427 = (unsigned int)zT_426;
    ai = zT_427;
    zT_429 = "FN4e\n";
    zT_431 = 5;
    zT_430.ptr = zT_429;
    zT_430.len = zT_431;
    fn4e = zT_430;
    zT_432 = fn4e;
    zF_48AC7B3A_markerWrite(zT_432);
    zT_434 = "FN4x:X";
    zT_436 = 6;
    zT_435.ptr = zT_434;
    zT_435.len = zT_436;
    fn4x_m = zT_435;
    zT_437 = fn4x_m;
    zT_439 = self->registry;
    zT_440 = zT_439->xt_len;
    zF_C914CB83_markerWriteInt(zT_437, (unsigned int)((unsigned int)zT_440));
    zT_443 = "FN4y:P";
    zT_445 = 6;
    zT_444.ptr = zT_443;
    zT_444.len = zT_445;
    fn4y_m = zT_444;
    zT_446 = fn4y_m;
    zF_C914CB83_markerWriteInt(zT_446, (unsigned int)((unsigned int)pstart_2));
    goto z_bb_71;
    z_bb_66:
    zT_422 = args.len;
    if ((int)(zT_422 != pcount_1)) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    zT_420 = fnp.return_type;
    return zT_420;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_424 = fnp.return_type;
    return zT_424;
    z_bb_70:
    goto z_bb_65;
    z_bb_71:
    if ((int)(ai < fixed)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_451 = "FN4f\n";
    zT_453 = 5;
    zT_452.ptr = zT_451;
    zT_452.len = zT_453;
    fn4f = zT_452;
    zT_454 = fn4f;
    zF_48AC7B3A_markerWrite(zT_454);
    zT_456 = self->registry;
    zT_457 = zT_456->xt_items;
    zT_458 = pstart_2 + ai;
    zT_459 = zT_457[zT_458];
    param_type = zT_459;
    zT_460 = self->call_arg_types;
    zT_464 = args.ptr;
    zT_461 = zT_464[ai];
    zT_462 = param_type;
    zF_26476265_u32ToU32MapPut(zT_460, zT_461, zT_462);
    zT_467 = "PTM:A";
    zT_469 = 5;
    zT_468.ptr = zT_467;
    zT_468.len = zT_469;
    ptm_am = zT_468;
    zT_470 = ptm_am;
    zF_C914CB83_markerWriteInt(zT_470, (unsigned int)((unsigned int)ai));
    zT_474 = "PTM:T";
    zT_476 = 5;
    zT_475.ptr = zT_474;
    zT_475.len = zT_476;
    ptm_tm = zT_475;
    zT_477 = ptm_tm;
    zT_478 = param_type;
    zF_C914CB83_markerWriteInt(zT_477, zT_478);
    zT_480 = "PTM:N";
    zT_482 = 5;
    zT_481.ptr = zT_480;
    zT_481.len = zT_482;
    ptm_nm = zT_481;
    zT_483 = ptm_nm;
    zT_485 = args.ptr;
    zT_484 = zT_485[ai];
    zF_C914CB83_markerWriteInt(zT_483, zT_484);
    zT_488 = "FN4g\n";
    zT_490 = 5;
    zT_489.ptr = zT_488;
    zT_489.len = zT_490;
    fn4g = zT_489;
    zT_491 = fn4g;
    zF_48AC7B3A_markerWrite(zT_491);
    zT_492 = self;
    zT_493 = param_type;
    zF_9665A229_pushExpectedType(zT_492, zT_493);
    zT_495 = self;
    zT_497 = args.ptr;
    zT_496 = zT_497[ai];
    zT_499 = zF_54F95822_semanticAnalyzerRes(zT_495, zT_496);
    arg_type = zT_499;
    zT_500 = self;
    zF_BC478E78_popExpectedType(zT_500);
    if ((int)(param_type == (unsigned int)(18))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    if ((int)(is_var != (unsigned char)(0))) goto z_bb_83; else goto z_bb_84;
    z_bb_74:
    zT_534 = 1;
    zT_535 = ai + zT_534;
    ai = zT_535;
    goto z_bb_71;
    z_bb_75:
    if ((int)(arg_type != (unsigned int)(18))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    if ((int)(param_type == (unsigned int)(1))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_505 = self->call_arg_types;
    zT_509 = args.ptr;
    zT_506 = zT_509[ai];
    zT_507 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_505, zT_506, zT_507);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
    z_bb_79:
    if ((int)(arg_type != (unsigned int)(18))) goto z_bb_81; else goto z_bb_82;
    z_bb_80:
    zT_521 = self;
    zT_525 = args.ptr;
    zT_522 = zT_525[ai];
    zT_527 = self;
    zT_531 = args.ptr;
    zT_528 = zT_531[ai];
    zT_529 = param_type;
    zT_530 = arg_type;
    zT_533 = zF_FFC95E09_errLitSrcType(zT_527, zT_528, zT_529, zT_530);
    zT_523 = zT_533;
    zT_524 = param_type;
    zF_DF7434EB_tryRecordCoercion(zT_521, zT_522, zT_523, zT_524);
    goto z_bb_74;
    z_bb_81:
    zT_515 = self->call_arg_types;
    zT_519 = args.ptr;
    zT_516 = zT_519[ai];
    zT_517 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_515, zT_516, zT_517);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_80;
    z_bb_83:
    vi = fixed;
    goto z_bb_85;
    z_bb_84:
    zT_563 = "FN4:R";
    zT_565 = 5;
    zT_564.ptr = zT_563;
    zT_564.len = zT_565;
    fn4_rm = zT_564;
    zT_566 = fn4_rm;
    zT_567 = fnp.return_type;
    zF_C914CB83_markerWriteInt(zT_566, zT_567);
    zT_569 = fnp.return_type;
    return zT_569;
    z_bb_85:
    zT_540 = args.len;
    if ((int)(vi < zT_540)) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_542 = self;
    zF_9665A229_pushExpectedType(zT_542, (unsigned int)(0));
    zT_546 = self;
    zT_548 = args.ptr;
    zT_547 = zT_548[vi];
    zT_550 = zF_54F95822_semanticAnalyzerRes(zT_546, zT_547);
    varg_type = zT_550;
    zT_551 = self;
    zF_BC478E78_popExpectedType(zT_551);
    if ((int)(varg_type != (unsigned int)(18))) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    goto z_bb_84;
    z_bb_88:
    zT_560 = 1;
    zT_561 = vi + zT_560;
    vi = zT_561;
    goto z_bb_85;
    z_bb_89:
    zT_554 = self->call_arg_types;
    zT_558 = args.ptr;
    zT_555 = zT_558[vi];
    zT_556 = varg_type;
    zF_26476265_u32ToU32MapPut(zT_554, zT_555, zT_556);
    goto z_bb_90;
    z_bb_90:
    goto z_bb_88;
}

/* semanticAnalyzerResolveTryExpr */
unsigned int zF_B78F27CD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_42C2D6BF_EUPayload* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_42C2D6BF_EUPayload zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    zT_42C2D6BF_EUPayload eu;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((int)(zT_23 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(1);
    z_bb_7:
    zT_30 = self->registry;
    zT_31 = zT_30->eu_items;
    zT_32 = ty.payload_idx;
    zT_33 = (unsigned int)zT_32;
    zT_34 = zT_31[zT_33];
    eu = zT_34;
    zT_35 = eu.payload;
    return zT_35;
}

/* semanticAnalyzerResolveOrelseExpr */
unsigned int zF_B36961FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_28;
    unsigned int zT_29;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    zT_D155D06D_Type zT_45;
    zT_33EF6BFB_TypeKind zT_47;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_0B10E8E9_OptionalPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_0B10E8E9_OptionalPayload zT_57;
    unsigned int zT_58;
    zT_338B7C76_TypeRegistry* zT_60;
    unsigned int zT_61;
    unsigned int zT_63 = 0;
    zT_66E7D2EF_CoercionTable* zT_64;
    unsigned int zT_65;
    unsigned int zT_67;
    zT_33EF6BFB_TypeKind zT_74;
    zT_33EF6BFB_TypeKind zT_79;
    int zT_84;
    zT_33EF6BFB_TypeKind zT_85;
    int zT_90;
    char* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_97;
    zT_F85C5DED_DiagnosticCollector* zT_98;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_117 = 0;
    zT_338B7C76_TypeRegistry* zT_120;
    zT_0B10E8E9_OptionalPayload* zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    zT_0B10E8E9_OptionalPayload zT_124;
    zT_66E7D2EF_CoercionTable* zT_125;
    unsigned int zT_126;
    unsigned int zT_128;
    unsigned int zT_135;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned int zT_139;
    zT_38C12417_SemanticAnalyzer* zT_142;
    unsigned int zT_143;
    unsigned int zT_145 = 0;
    zT_38C12417_SemanticAnalyzer* zT_146;
    int zT_149;
    zT_38C12417_SemanticAnalyzer* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_158;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    unsigned int expected;
    zT_D155D06D_Type oe_et;
    unsigned int payload_type;
    zT_0B10E8E9_OptionalPayload oe_opt;
    unsigned int opt_target;
    zT_0B10E8E9_OptionalPayload opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u oe_msg;
    unsigned int rhs_result;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((int)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_29 = self->expected_type_stack_len;
    zT_28 = zT_29 > (unsigned int)(0);
    goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_28) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = self->expected_type_stack_items;
    zT_34 = self->expected_type_stack_len;
    zT_37 = (unsigned int)(unsigned int)(zT_34 - (unsigned int)(1));
    zT_38 = zT_33[zT_37];
    expected = zT_38;
    if ((int)(expected != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_74 = ty.kind;
    if ((int)(zT_74 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_11:
    zT_42 = self->registry;
    zT_43 = zT_42->types_items;
    zT_44 = (unsigned int)expected;
    zT_45 = zT_43[zT_44];
    oe_et = zT_45;
    payload_type = expected;
    zT_47 = oe_et.kind;
    if ((int)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_53 = self->registry;
    zT_54 = zT_53->opt_items;
    zT_55 = oe_et.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    oe_opt = zT_57;
    zT_58 = oe_opt.payload;
    payload_type = zT_58;
    goto z_bb_14;
    z_bb_14:
    zT_60 = self->registry;
    zT_61 = payload_type;
    zT_63 = zF_74A7234F_typeRegistryGetOrCr(zT_60, zT_61);
    opt_target = zT_63;
    zT_64 = self->coercion_table;
    zT_65 = node.child_0;
    zT_67 = opt_target;
    zF_D21AE60A_coercionTableAdd(zT_64, zT_65, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional_null), zT_67);
    return payload_type;
    z_bb_15:
    zT_79 = ty.kind;
    if ((int)(zT_79 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_18; else goto z_bb_17;
    z_bb_16:
    zT_120 = self->registry;
    zT_121 = zT_120->opt_items;
    zT_122 = ty.payload_idx;
    zT_123 = (unsigned int)zT_122;
    zT_124 = zT_121[zT_123];
    opt = zT_124;
    zT_125 = self->coercion_table;
    zT_126 = node.child_0;
    zT_128 = opt.payload;
    zF_D21AE60A_coercionTableAdd(zT_125, zT_126, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_128);
    zT_135 = node.child_1;
    if ((int)(zT_135 != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_17:
    zT_85 = ty.kind;
    zT_84 = zT_85 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_19;
    z_bb_18:
    zT_84 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_84) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_90 = inner == (unsigned int)(3);
    goto z_bb_22;
    z_bb_21:
    zT_90 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_90) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned int)(1);
    z_bb_24:
    zT_95 = "orelse requires an optional operand; use 'catch' for error unions";
    zT_97 = 65;
    zT_96.ptr = zT_95;
    zT_96.len = zT_97;
    oe_msg = zT_96;
    zT_98 = self->diag;
    zT_101 = self->source_file_id;
    zT_102 = node.span_start;
    zT_113 = node.span_start;
    zT_114 = node.span_len;
    zT_104 = oe_msg;
    zT_117 = zF_C82559AC_diagnosticCollector(zT_98, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3016_ORELSE_REQUIRES_OPTIONAL)), zT_101, zT_102, (unsigned int)(zT_113 + (unsigned int)((unsigned int)zT_114)), zT_104);
    (void)zT_117;
    return (unsigned int)(18);
    z_bb_25:
    zT_138 = self;
    zT_139 = opt.payload;
    zF_9665A229_pushExpectedType(zT_138, zT_139);
    zT_142 = self;
    zT_143 = node.child_1;
    zT_145 = zF_54F95822_semanticAnalyzerRes(zT_142, zT_143);
    rhs_result = zT_145;
    zT_146 = self;
    zF_BC478E78_popExpectedType(zT_146);
    if ((int)(rhs_result != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_158 = opt.payload;
    return zT_158;
    z_bb_27:
    zT_149 = rhs_result != (unsigned int)(1);
    goto z_bb_29;
    z_bb_28:
    zT_149 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_149) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_152 = self;
    zT_153 = node.child_1;
    zT_154 = rhs_result;
    zT_155 = opt.payload;
    zF_DF7434EB_tryRecordCoercion(zT_152, zT_153, zT_154, zT_155);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_26;
}

/* semanticAnalyzerResolveIfExpr */
unsigned int zF_8B8EE70D_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    unsigned int zT_14;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8EED1867_ResolvedTypeTable* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    zT_8EED1867_ResolvedTypeTable* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    zT_8EED1867_ResolvedTypeTable* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    zT_8EED1867_ResolvedTypeTable* zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    int zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    unsigned int zT_115;
    int zT_117 = 0;
    char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    char* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129;
    char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_66E7D2EF_CoercionTable* zT_135;
    unsigned int zT_136;
    unsigned int zT_138;
    zT_8EED1867_ResolvedTypeTable* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    int zT_150;
    zT_338B7C76_TypeRegistry* zT_151;
    unsigned int zT_152;
    int zT_154 = 0;
    char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    zT_66E7D2EF_CoercionTable* zT_172;
    unsigned int zT_173;
    unsigned int zT_175;
    zT_8EED1867_ResolvedTypeTable* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    char* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    zT_8EED1867_ResolvedTypeTable* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    char* zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned int zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    unsigned int zT_221;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    zT_8EED1867_ResolvedTypeTable* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    char* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    char* zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    zT_8EED1867_ResolvedTypeTable* zT_242;
    unsigned int zT_243;
    zT_22A7C88B_AstNode node;
    unsigned int then_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_nl;
    unsigned int else_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u siffm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sifftm;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_7, zT_8);
    zT_10 = self;
    zT_11 = node.child_1;
    zT_13 = zF_54F95822_semanticAnalyzerRes(zT_10, zT_11);
    then_type = zT_13;
    zT_14 = node.child_2;
    if ((int)(zT_14 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = "SIF:0N";
    zT_20 = 6;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    sif_m = zT_19;
    zT_21 = sif_m;
    zT_22 = node_idx;
    zF_C914CB83_markerWriteInt(zT_21, zT_22);
    zT_24 = "T";
    zT_26 = 1;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    sif_tm = zT_25;
    zT_27 = sif_tm;
    zT_28 = then_type;
    zF_C914CB83_markerWriteInt(zT_27, zT_28);
    zT_30 = " ";
    zT_32 = 1;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    sif_nl = zT_31;
    zT_33 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_34 = self->type_table;
    zT_35 = node_idx;
    zT_36 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_34, zT_35, zT_36);
    return then_type;
    z_bb_2:
    zT_39 = self;
    zT_40 = node.child_2;
    zT_42 = zF_54F95822_semanticAnalyzerRes(zT_39, zT_40);
    else_type = zT_42;
    if ((int)(then_type == else_type)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_45 = "SIF:1N";
    zT_47 = 6;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    sif_m = zT_46;
    zT_48 = sif_m;
    zT_49 = node_idx;
    zF_C914CB83_markerWriteInt(zT_48, zT_49);
    zT_51 = "T";
    zT_53 = 1;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    sif_tm = zT_52;
    zT_54 = sif_tm;
    zT_55 = then_type;
    zF_C914CB83_markerWriteInt(zT_54, zT_55);
    zT_57 = " ";
    zT_59 = 1;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    sif_nl = zT_58;
    zT_60 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_60);
    zT_61 = self->type_table;
    zT_62 = node_idx;
    zT_63 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_61, zT_62, zT_63);
    return then_type;
    z_bb_4:
    if ((int)(then_type == (unsigned int)(3))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_68 = "SIF:2N";
    zT_70 = 6;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    sif2m = zT_69;
    zT_71 = sif2m;
    zT_72 = node_idx;
    zF_C914CB83_markerWriteInt(zT_71, zT_72);
    zT_74 = "T";
    zT_76 = 1;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    sif2tm = zT_75;
    zT_77 = sif2tm;
    zT_78 = else_type;
    zF_C914CB83_markerWriteInt(zT_77, zT_78);
    zT_80 = " ";
    zT_82 = 1;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    sif2nl = zT_81;
    zT_83 = sif2nl;
    zF_48AC7B3A_markerWrite(zT_83);
    zT_84 = self->type_table;
    zT_85 = node_idx;
    zT_86 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_84, zT_85, zT_86);
    return else_type;
    z_bb_6:
    if ((int)(else_type == (unsigned int)(3))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_91 = "SIF:3N";
    zT_93 = 6;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    sif3m = zT_92;
    zT_94 = sif3m;
    zT_95 = node_idx;
    zF_C914CB83_markerWriteInt(zT_94, zT_95);
    zT_97 = "T";
    zT_99 = 1;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    sif3tm = zT_98;
    zT_100 = sif3tm;
    zT_101 = then_type;
    zF_C914CB83_markerWriteInt(zT_100, zT_101);
    zT_103 = " ";
    zT_105 = 1;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    sif3nl = zT_104;
    zT_106 = sif3nl;
    zF_48AC7B3A_markerWrite(zT_106);
    zT_107 = self->type_table;
    zT_108 = node_idx;
    zT_109 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_107, zT_108, zT_109);
    return then_type;
    z_bb_8:
    if ((int)(then_type == (unsigned int)(19))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_114 = self->registry;
    zT_115 = else_type;
    zT_117 = zF_3087E0A5_typeRegistryIsNumer(zT_114, zT_115);
    zT_113 = zT_117;
    goto z_bb_11;
    z_bb_10:
    zT_113 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_113) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_119 = "SIF:4N";
    zT_121 = 6;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    sif4m = zT_120;
    zT_122 = sif4m;
    zT_123 = node_idx;
    zF_C914CB83_markerWriteInt(zT_122, zT_123);
    zT_125 = "T";
    zT_127 = 1;
    zT_126.ptr = zT_125;
    zT_126.len = zT_127;
    sif4tm = zT_126;
    zT_128 = sif4tm;
    zT_129 = else_type;
    zF_C914CB83_markerWriteInt(zT_128, zT_129);
    zT_131 = " ";
    zT_133 = 1;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    sif4nl = zT_132;
    zT_134 = sif4nl;
    zF_48AC7B3A_markerWrite(zT_134);
    zT_135 = self->coercion_table;
    zT_136 = node.child_1;
    zT_138 = else_type;
    zF_D21AE60A_coercionTableAdd(zT_135, zT_136, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_138);
    zT_144 = self->type_table;
    zT_145 = node_idx;
    zT_146 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_144, zT_145, zT_146);
    return else_type;
    z_bb_13:
    if ((int)(else_type == (unsigned int)(19))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_151 = self->registry;
    zT_152 = then_type;
    zT_154 = zF_3087E0A5_typeRegistryIsNumer(zT_151, zT_152);
    zT_150 = zT_154;
    goto z_bb_16;
    z_bb_15:
    zT_150 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_150) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_156 = "SIF:5N";
    zT_158 = 6;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    sif5m = zT_157;
    zT_159 = sif5m;
    zT_160 = node_idx;
    zF_C914CB83_markerWriteInt(zT_159, zT_160);
    zT_162 = "T";
    zT_164 = 1;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    sif5tm = zT_163;
    zT_165 = sif5tm;
    zT_166 = then_type;
    zF_C914CB83_markerWriteInt(zT_165, zT_166);
    zT_168 = " ";
    zT_170 = 1;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    sif5nl = zT_169;
    zT_171 = sif5nl;
    zF_48AC7B3A_markerWrite(zT_171);
    zT_172 = self->coercion_table;
    zT_173 = node.child_2;
    zT_175 = then_type;
    zF_D21AE60A_coercionTableAdd(zT_172, zT_173, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_175);
    zT_181 = self->type_table;
    zT_182 = node_idx;
    zT_183 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_181, zT_182, zT_183);
    return then_type;
    z_bb_18:
    if ((int)(then_type == (unsigned int)(1))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_188 = "SIF:6N";
    zT_190 = 6;
    zT_189.ptr = zT_188;
    zT_189.len = zT_190;
    sif6m = zT_189;
    zT_191 = sif6m;
    zT_192 = node_idx;
    zF_C914CB83_markerWriteInt(zT_191, zT_192);
    zT_194 = "T";
    zT_196 = 1;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    sif6tm = zT_195;
    zT_197 = sif6tm;
    zT_198 = else_type;
    zF_C914CB83_markerWriteInt(zT_197, zT_198);
    zT_200 = " ";
    zT_202 = 1;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    sif6nl = zT_201;
    zT_203 = sif6nl;
    zF_48AC7B3A_markerWrite(zT_203);
    zT_204 = self->type_table;
    zT_205 = node_idx;
    zT_206 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_204, zT_205, zT_206);
    return else_type;
    z_bb_20:
    if ((int)(else_type == (unsigned int)(1))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_211 = "SIF:7N";
    zT_213 = 6;
    zT_212.ptr = zT_211;
    zT_212.len = zT_213;
    sif7m = zT_212;
    zT_214 = sif7m;
    zT_215 = node_idx;
    zF_C914CB83_markerWriteInt(zT_214, zT_215);
    zT_217 = "T";
    zT_219 = 1;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    sif7tm = zT_218;
    zT_220 = sif7tm;
    zT_221 = then_type;
    zF_C914CB83_markerWriteInt(zT_220, zT_221);
    zT_223 = " ";
    zT_225 = 1;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    sif7nl = zT_224;
    zT_226 = sif7nl;
    zF_48AC7B3A_markerWrite(zT_226);
    zT_227 = self->type_table;
    zT_228 = node_idx;
    zT_229 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_227, zT_228, zT_229);
    return then_type;
    z_bb_22:
    zT_232 = "SIF:FN";
    zT_234 = 6;
    zT_233.ptr = zT_232;
    zT_233.len = zT_234;
    siffm = zT_233;
    zT_235 = siffm;
    zT_236 = node_idx;
    zF_C914CB83_markerWriteInt(zT_235, zT_236);
    zT_238 = "\n";
    zT_240 = 1;
    zT_239.ptr = zT_238;
    zT_239.len = zT_240;
    sifftm = zT_239;
    zT_241 = sifftm;
    zF_48AC7B3A_markerWrite(zT_241);
    zT_242 = self->type_table;
    zT_243 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_242, zT_243, (unsigned int)(1));
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveEnumLiteral */
unsigned int zF_8C008E53_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_54FF90FA_TaggedUnionPayload* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_54FF90FA_TaggedUnionPayload zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned short zT_41;
    unsigned int zT_42;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_2DF01B61_FieldEntry* zT_45;
    zT_2DF01B61_FieldEntry zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    int zT_69;
    unsigned int zT_70;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_2DF01B61_FieldEntry* zT_74;
    unsigned int zT_75;
    zT_2DF01B61_FieldEntry zT_76;
    char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_83;
    unsigned int zT_85;
    char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_21D3708C_U32ToU32Map* zT_93;
    unsigned int zT_94;
    zT_21D3708C_U32ToU32Map* zT_96;
    unsigned int zT_97;
    zT_8EED1867_ResolvedTypeTable* zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_106;
    int zT_107;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_457ECFEE_EnumPayload* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_457ECFEE_EnumPayload zT_119;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned short zT_124;
    unsigned int zT_125;
    int zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_131;
    zT_D96DCDF2_EnumMember* zT_132;
    unsigned int zT_133;
    zT_D96DCDF2_EnumMember zT_134;
    unsigned int zT_135;
    zT_21D3708C_U32ToU32Map* zT_137;
    unsigned int zT_138;
    zT_C69B2266_i64 zT_141;
    zT_8EED1867_ResolvedTypeTable* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_148;
    int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    int zT_152;
    unsigned int* zT_155;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_338B7C76_TypeRegistry* zT_164;
    zT_D155D06D_Type* zT_165;
    unsigned int zT_166;
    zT_D155D06D_Type zT_167;
    zT_33EF6BFB_TypeKind zT_168;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_54FF90FA_TaggedUnionPayload* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    zT_54FF90FA_TaggedUnionPayload zT_178;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned short zT_183;
    unsigned int zT_184;
    int zT_186;
    unsigned int zT_187;
    zT_338B7C76_TypeRegistry* zT_190;
    zT_2DF01B61_FieldEntry* zT_191;
    unsigned int zT_192;
    zT_2DF01B61_FieldEntry zT_193;
    unsigned int zT_194;
    unsigned int zT_196;
    zT_21D3708C_U32ToU32Map* zT_199;
    unsigned int zT_200;
    zT_8EED1867_ResolvedTypeTable* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_213;
    char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_F85C5DED_DiagnosticCollector* zT_218;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_232 = 0;
    int zT_234;
    unsigned int zT_235;
    unsigned int zT_237;
    unsigned int zT_239;
    unsigned int zT_241;
    char* zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned int zT_245;
    zT_F85C5DED_DiagnosticCollector* zT_246;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_260 = 0;
    char* zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    unsigned int zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8EED1867_ResolvedTypeTable* zT_268;
    unsigned int zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u el;
    zT_22A7C88B_AstNode node;
    unsigned int n;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int f0;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elc_m;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u elv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elm_m;
    zT_457ECFEE_EnumPayload enp;
    unsigned int estart;
    unsigned int ecount;
    unsigned int emi;
    zT_D96DCDF2_EnumMember member;
    unsigned int top;
    zT_D155D06D_Type top_ty;
    unsigned int fstart2;
    unsigned int fcount2;
    unsigned int fi2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u elr_msg;
    zT_3 = "eL\n";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    el = zT_4;
    zT_6 = el;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node_idx;
    zT_16 = zF_53458827_astStoreIdentifier(zT_13, zT_14);
    n = zT_16;
    zT_17 = self->current_switch_cond_tu;
    if ((int)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = self->current_switch_cond_tu;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    tu_ty = zT_25;
    zT_26 = tu_ty.kind;
    if ((int)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_151 = self->expected_type_stack_len;
    zT_152 = 0;
    if ((int)(zT_151 > (unsigned int)zT_152)) goto z_bb_19; else goto z_bb_20;
    z_bb_3:
    zT_32 = self->registry;
    zT_33 = zT_32->tu_items;
    zT_34 = tu_ty.payload_idx;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zT_33[zT_35];
    tp = zT_36;
    zT_38 = tp.fields_start;
    zT_39 = (unsigned int)zT_38;
    fstart = zT_39;
    zT_41 = tp.fields_count;
    zT_42 = (unsigned int)zT_41;
    fcount = zT_42;
    zT_44 = self->registry;
    zT_45 = zT_44->fe_items;
    zT_46 = zT_45[fstart];
    zT_47 = zT_46.name_id;
    zT_48 = (unsigned int)zT_47;
    f0 = zT_48;
    zT_50 = "EL:N";
    zT_52 = 4;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    eln_m = zT_51;
    zT_53 = eln_m;
    zT_54 = n;
    zF_C914CB83_markerWriteInt(zT_53, zT_54);
    zT_56 = "EL:F";
    zT_58 = 4;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    elf_m = zT_57;
    zT_59 = elf_m;
    zT_60 = f0;
    zF_C914CB83_markerWriteInt(zT_59, zT_60);
    zT_62 = "EL:C";
    zT_64 = 4;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    elc_m = zT_63;
    zT_65 = elc_m;
    zF_C914CB83_markerWriteInt(zT_65, (unsigned int)((unsigned int)fcount));
    zT_69 = 0;
    zT_70 = (unsigned int)zT_69;
    fi = zT_70;
    goto z_bb_5;
    z_bb_4:
    zT_109 = tu_ty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_5:
    if ((int)(fi < fcount)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_73 = self->registry;
    zT_74 = zT_73->fe_items;
    zT_75 = fstart + fi;
    zT_76 = zT_74[zT_75];
    fe = zT_76;
    zT_78 = "EL:V";
    zT_80 = 4;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    elv_m = zT_79;
    zT_81 = elv_m;
    zT_83 = fe.name_id;
    zF_C914CB83_markerWriteInt(zT_81, (unsigned int)((unsigned int)zT_83));
    zT_85 = fe.name_id;
    if ((int)(zT_85 == n)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_107 = 1;
    zT_108 = fi + zT_107;
    fi = zT_108;
    goto z_bb_5;
    z_bb_9:
    zT_88 = "EL:M";
    zT_90 = 4;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    elm_m = zT_89;
    zT_91 = elm_m;
    zT_93 = self->enum_value_table;
    zT_94 = zT_93->count;
    zF_C914CB83_markerWriteInt(zT_91, (unsigned int)((unsigned int)zT_94));
    zT_96 = self->enum_value_table;
    zT_97 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_96, zT_97, (unsigned int)((unsigned int)fi));
    zT_101 = self->type_table;
    zT_102 = node_idx;
    zT_103 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_101, zT_102, zT_103);
    zT_106 = self->current_switch_cond_tu;
    return zT_106;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_115 = self->registry;
    zT_116 = zT_115->en_items;
    zT_117 = tu_ty.payload_idx;
    zT_118 = (unsigned int)zT_117;
    zT_119 = zT_116[zT_118];
    enp = zT_119;
    zT_121 = enp.members_start;
    zT_122 = (unsigned int)zT_121;
    estart = zT_122;
    zT_124 = enp.members_count;
    zT_125 = (unsigned int)zT_124;
    ecount = zT_125;
    zT_127 = 0;
    zT_128 = (unsigned int)zT_127;
    emi = zT_128;
    goto z_bb_13;
    z_bb_12:
    goto z_bb_2;
    z_bb_13:
    if ((int)(emi < ecount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_131 = self->registry;
    zT_132 = zT_131->em_items;
    zT_133 = estart + emi;
    zT_134 = zT_132[zT_133];
    member = zT_134;
    zT_135 = member.name_id;
    if ((int)(zT_135 == n)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_149 = 1;
    zT_150 = emi + zT_149;
    emi = zT_150;
    goto z_bb_13;
    z_bb_17:
    zT_137 = self->enum_value_table;
    zT_138 = node_idx;
    zT_141 = member.value;
    zF_26476265_u32ToU32MapPut(zT_137, zT_138, (unsigned int)((unsigned int)zT_141));
    zT_143 = self->type_table;
    zT_144 = node_idx;
    zT_145 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_143, zT_144, zT_145);
    zT_148 = self->current_switch_cond_tu;
    return zT_148;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_155 = self->expected_type_stack_items;
    zT_156 = self->expected_type_stack_len;
    zT_157 = 1;
    zT_159 = (unsigned int)(unsigned int)(zT_156 - zT_157);
    zT_160 = zT_155[zT_159];
    top = zT_160;
    if ((int)(top != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_263 = "ELV:N";
    zT_265 = 5;
    zT_264.ptr = zT_263;
    zT_264.len = zT_265;
    elv_m = zT_264;
    zT_266 = elv_m;
    zT_267 = n;
    zF_C914CB83_markerWriteInt(zT_266, zT_267);
    zT_268 = self->type_table;
    zT_269 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_268, zT_269, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_21:
    zT_164 = self->registry;
    zT_165 = zT_164->types_items;
    zT_166 = (unsigned int)top;
    zT_167 = zT_165[zT_166];
    top_ty = zT_167;
    zT_168 = top_ty.kind;
    if ((int)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_174 = self->registry;
    zT_175 = zT_174->tu_items;
    zT_176 = top_ty.payload_idx;
    zT_177 = (unsigned int)zT_176;
    zT_178 = zT_175[zT_177];
    tp = zT_178;
    zT_180 = tp.fields_start;
    zT_181 = (unsigned int)zT_180;
    fstart2 = zT_181;
    zT_183 = tp.fields_count;
    zT_184 = (unsigned int)zT_183;
    fcount2 = zT_184;
    zT_186 = 0;
    zT_187 = (unsigned int)zT_186;
    fi2 = zT_187;
    goto z_bb_25;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    if ((int)(fi2 < fcount2)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_190 = self->registry;
    zT_191 = zT_190->fe_items;
    zT_192 = fstart2 + fi2;
    zT_193 = zT_191[zT_192];
    fe = zT_193;
    zT_194 = fe.name_id;
    if ((int)(zT_194 == n)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_237 = node.span_start;
    sp = zT_237;
    zT_239 = node.span_len;
    zT_241 = sp + (unsigned int)((unsigned int)zT_239);
    ep = zT_241;
    zT_243 = "unknown enum literal member";
    zT_245 = 27;
    zT_244.ptr = zT_243;
    zT_244.len = zT_245;
    elu_msg = zT_244;
    zT_246 = self->diag;
    zT_249 = self->source_file_id;
    zT_250 = sp;
    zT_251 = ep;
    zT_252 = elu_msg;
    zT_260 = zF_C82559AC_diagnosticCollector(zT_246, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3009_UNKNOWN_ENUM_LITERAL_MEMBER)), zT_249, zT_250, zT_251, zT_252);
    (void)zT_260;
    return (unsigned int)(1);
    z_bb_28:
    zT_234 = 1;
    zT_235 = fi2 + zT_234;
    fi2 = zT_235;
    goto z_bb_25;
    z_bb_29:
    zT_196 = fe.type_id;
    if ((int)(zT_196 == (unsigned int)(1))) goto z_bb_31; else goto z_bb_33;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_199 = self->enum_value_table;
    zT_200 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_199, zT_200, (unsigned int)((unsigned int)fi2));
    zT_204 = self->type_table;
    zT_205 = node_idx;
    zT_206 = top;
    zF_19B4A07D_resolvedTypeTableSe(zT_204, zT_205, zT_206);
    return top;
    goto z_bb_30;
    z_bb_33:
    zT_209 = node.span_start;
    sp = zT_209;
    zT_211 = node.span_len;
    zT_213 = sp + (unsigned int)((unsigned int)zT_211);
    ep = zT_213;
    zT_215 = "enum literal member requires payload";
    zT_217 = 36;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    elr_msg = zT_216;
    zT_218 = self->diag;
    zT_221 = self->source_file_id;
    zT_222 = sp;
    zT_223 = ep;
    zT_224 = elr_msg;
    zT_232 = zF_C82559AC_diagnosticCollector(zT_218, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3008_ENUM_LITERAL_REQUIRES_PAYLOAD)), zT_221, zT_222, zT_223, zT_224);
    (void)zT_232;
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveStructInit */
unsigned int zF_AD7EF126_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_38C12417_SemanticAnalyzer* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19 = 0;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_D155D06D_Type* zT_25;
    unsigned int zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    zT_338B7C76_TypeRegistry* zT_34;
    zT_54FF90FA_TaggedUnionPayload* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_54FF90FA_TaggedUnionPayload zT_38;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned short zT_43;
    unsigned int zT_44;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_49 = {0};
    int zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int* zT_60;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    unsigned int* zT_67;
    unsigned int zT_69 = 0;
    int zT_73;
    unsigned int zT_74;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_2DF01B61_FieldEntry* zT_77;
    unsigned int zT_78;
    zT_2DF01B61_FieldEntry zT_79;
    unsigned int zT_80;
    unsigned int zT_82;
    zT_338B7C76_TypeRegistry* zT_86;
    zT_2DF01B61_FieldEntry* zT_87;
    unsigned int zT_88;
    zT_2DF01B61_FieldEntry zT_89;
    unsigned int zT_90;
    zT_38C12417_SemanticAnalyzer* zT_91;
    unsigned int zT_92;
    zT_38C12417_SemanticAnalyzer* zT_94;
    unsigned int zT_95;
    unsigned int zT_97 = 0;
    zT_38C12417_SemanticAnalyzer* zT_98;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    int zT_104;
    unsigned int zT_105;
    int zT_106;
    unsigned int zT_107;
    zT_8EED1867_ResolvedTypeTable* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_33EF6BFB_TypeKind zT_112;
    zT_338B7C76_TypeRegistry* zT_118;
    zT_406493CE_StructPayload* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_406493CE_StructPayload zT_122;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned short zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_130;
    unsigned int zT_131;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_133 = {0};
    int zT_135;
    unsigned int zT_136;
    unsigned int zT_138;
    zT_6B0A7D14_AstStore* zT_141;
    unsigned int zT_142;
    unsigned int* zT_144;
    zT_22A7C88B_AstNode zT_146 = {0};
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    unsigned int* zT_151;
    unsigned int zT_153 = 0;
    int zT_157;
    unsigned int zT_158;
    zT_338B7C76_TypeRegistry* zT_160;
    zT_2DF01B61_FieldEntry* zT_161;
    unsigned int zT_162;
    zT_2DF01B61_FieldEntry zT_163;
    unsigned int zT_164;
    unsigned int zT_166;
    zT_338B7C76_TypeRegistry* zT_170;
    zT_2DF01B61_FieldEntry* zT_171;
    unsigned int zT_172;
    zT_2DF01B61_FieldEntry zT_173;
    unsigned int zT_174;
    zT_38C12417_SemanticAnalyzer* zT_175;
    unsigned int zT_176;
    zT_38C12417_SemanticAnalyzer* zT_178;
    unsigned int zT_179;
    unsigned int zT_181 = 0;
    zT_38C12417_SemanticAnalyzer* zT_182;
    zT_38C12417_SemanticAnalyzer* zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    int zT_188;
    unsigned int zT_189;
    int zT_190;
    unsigned int zT_191;
    zT_8EED1867_ResolvedTypeTable* zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_33EF6BFB_TypeKind zT_196;
    int zT_201;
    zT_33EF6BFB_TypeKind zT_202;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_AF9231A2_UnionPayload* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_AF9231A2_UnionPayload zT_212;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned short zT_217;
    unsigned int zT_218;
    zT_6B0A7D14_AstStore* zT_220;
    unsigned int zT_221;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_223 = {0};
    int zT_225;
    unsigned int zT_226;
    unsigned int zT_228;
    zT_6B0A7D14_AstStore* zT_231;
    unsigned int zT_232;
    unsigned int* zT_234;
    zT_22A7C88B_AstNode zT_236 = {0};
    zT_6B0A7D14_AstStore* zT_238;
    unsigned int zT_239;
    unsigned int* zT_241;
    unsigned int zT_243 = 0;
    int zT_247;
    unsigned int zT_248;
    zT_338B7C76_TypeRegistry* zT_250;
    zT_2DF01B61_FieldEntry* zT_251;
    unsigned int zT_252;
    zT_2DF01B61_FieldEntry zT_253;
    unsigned int zT_254;
    unsigned int zT_256;
    zT_338B7C76_TypeRegistry* zT_260;
    zT_2DF01B61_FieldEntry* zT_261;
    unsigned int zT_262;
    zT_2DF01B61_FieldEntry zT_263;
    unsigned int zT_264;
    zT_38C12417_SemanticAnalyzer* zT_265;
    unsigned int zT_266;
    zT_38C12417_SemanticAnalyzer* zT_268;
    unsigned int zT_269;
    unsigned int zT_271 = 0;
    zT_38C12417_SemanticAnalyzer* zT_272;
    zT_38C12417_SemanticAnalyzer* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    int zT_278;
    unsigned int zT_279;
    int zT_280;
    unsigned int zT_281;
    zT_8EED1867_ResolvedTypeTable* zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    zT_22A7C88B_AstNode node;
    unsigned int target_type;
    zT_D155D06D_Type tgt;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    zT_3CB0179A_Slice_zT_05F374B1_u field_inits;
    unsigned int fii;
    zT_22A7C88B_AstNode fi_node;
    unsigned int fname_id;
    unsigned int fi;
    unsigned int field_type;
    unsigned int init_type;
    zT_406493CE_StructPayload sp;
    zT_AF9231A2_UnionPayload up;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = 0;
    target_type = zT_8;
    zT_9 = node.child_0;
    if ((int)(zT_9 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = node.child_0;
    zT_15 = zF_54F95822_semanticAnalyzerRes(zT_12, zT_13);
    target_type = zT_15;
    goto z_bb_2;
    z_bb_2:
    if ((int)(target_type == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = self;
    zT_19 = zF_4DE7C2BC_topExpectedType(zT_18);
    target_type = zT_19;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target_type == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(1);
    z_bb_6:
    zT_24 = self->registry;
    zT_25 = zT_24->types_items;
    zT_26 = (unsigned int)target_type;
    zT_27 = zT_25[zT_26];
    tgt = zT_27;
    zT_28 = tgt.kind;
    if ((int)(zT_28 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = self->registry;
    zT_35 = zT_34->tu_items;
    zT_36 = tgt.payload_idx;
    zT_37 = (unsigned int)zT_36;
    zT_38 = zT_35[zT_37];
    tp = zT_38;
    zT_40 = tp.fields_start;
    zT_41 = (unsigned int)zT_40;
    fstart = zT_41;
    zT_43 = tp.fields_count;
    zT_44 = (unsigned int)zT_43;
    fcount = zT_44;
    zT_46 = self->store;
    zT_47 = node_idx;
    zT_49 = zF_850FDF81_astStoreNodeExtraCh(zT_46, zT_47);
    field_inits = zT_49;
    zT_51 = 0;
    zT_52 = (unsigned int)zT_51;
    fii = zT_52;
    goto z_bb_9;
    z_bb_8:
    zT_112 = tgt.kind;
    if ((int)(zT_112 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    zT_54 = field_inits.len;
    if ((int)(fii < zT_54)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_57 = self->store;
    zT_60 = field_inits.ptr;
    zT_58 = zT_60[fii];
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_57, zT_58);
    fi_node = zT_62;
    zT_64 = self->store;
    zT_67 = field_inits.ptr;
    zT_65 = zT_67[fii];
    zT_69 = zF_8BA26B9E_astStoreNodePayload(zT_64, zT_65);
    fname_id = zT_69;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_108 = self->type_table;
    zT_109 = node_idx;
    zT_110 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_108, zT_109, zT_110);
    return target_type;
    z_bb_12:
    zT_106 = 1;
    zT_107 = fii + zT_106;
    fii = zT_107;
    goto z_bb_9;
    z_bb_13:
    zT_73 = 0;
    zT_74 = (unsigned int)zT_73;
    fi = zT_74;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((int)(fi < fcount)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_76 = self->registry;
    zT_77 = zT_76->fe_items;
    zT_78 = fstart + fi;
    zT_79 = zT_77[zT_78];
    zT_80 = zT_79.name_id;
    if ((int)(zT_80 == fname_id)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_104 = 1;
    zT_105 = fi + zT_104;
    fi = zT_105;
    goto z_bb_15;
    z_bb_19:
    zT_82 = fi_node.child_0;
    if ((int)(zT_82 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_86 = self->registry;
    zT_87 = zT_86->fe_items;
    zT_88 = fstart + fi;
    zT_89 = zT_87[zT_88];
    zT_90 = zT_89.type_id;
    field_type = zT_90;
    zT_91 = self;
    zT_92 = field_type;
    zF_9665A229_pushExpectedType(zT_91, zT_92);
    zT_94 = self;
    zT_95 = fi_node.child_0;
    zT_97 = zF_54F95822_semanticAnalyzerRes(zT_94, zT_95);
    init_type = zT_97;
    zT_98 = self;
    zF_BC478E78_popExpectedType(zT_98);
    zT_99 = self;
    zT_100 = fi_node.child_0;
    zT_101 = init_type;
    zT_102 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_99, zT_100, zT_101, zT_102);
    goto z_bb_22;
    z_bb_22:
    goto z_bb_17;
    z_bb_23:
    zT_118 = self->registry;
    zT_119 = zT_118->st_items;
    zT_120 = tgt.payload_idx;
    zT_121 = (unsigned int)zT_120;
    zT_122 = zT_119[zT_121];
    sp = zT_122;
    zT_124 = sp.fields_start;
    zT_125 = (unsigned int)zT_124;
    fstart = zT_125;
    zT_127 = sp.fields_count;
    zT_128 = (unsigned int)zT_127;
    fcount = zT_128;
    zT_130 = self->store;
    zT_131 = node_idx;
    zT_133 = zF_850FDF81_astStoreNodeExtraCh(zT_130, zT_131);
    field_inits = zT_133;
    zT_135 = 0;
    zT_136 = (unsigned int)zT_135;
    fii = zT_136;
    goto z_bb_25;
    z_bb_24:
    zT_196 = tgt.kind;
    if ((int)(zT_196 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_40; else goto z_bb_39;
    z_bb_25:
    zT_138 = field_inits.len;
    if ((int)(fii < zT_138)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_141 = self->store;
    zT_144 = field_inits.ptr;
    zT_142 = zT_144[fii];
    zT_146 = zF_FCDD1D35_astStoreNodeAt(zT_141, zT_142);
    fi_node = zT_146;
    zT_148 = self->store;
    zT_151 = field_inits.ptr;
    zT_149 = zT_151[fii];
    zT_153 = zF_8BA26B9E_astStoreNodePayload(zT_148, zT_149);
    fname_id = zT_153;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_192 = self->type_table;
    zT_193 = node_idx;
    zT_194 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_192, zT_193, zT_194);
    return target_type;
    z_bb_28:
    zT_190 = 1;
    zT_191 = fii + zT_190;
    fii = zT_191;
    goto z_bb_25;
    z_bb_29:
    zT_157 = 0;
    zT_158 = (unsigned int)zT_157;
    fi = zT_158;
    goto z_bb_31;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    if ((int)(fi < fcount)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_160 = self->registry;
    zT_161 = zT_160->fe_items;
    zT_162 = fstart + fi;
    zT_163 = zT_161[zT_162];
    zT_164 = zT_163.name_id;
    if ((int)(zT_164 == fname_id)) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_188 = 1;
    zT_189 = fi + zT_188;
    fi = zT_189;
    goto z_bb_31;
    z_bb_35:
    zT_166 = fi_node.child_0;
    if ((int)(zT_166 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_170 = self->registry;
    zT_171 = zT_170->fe_items;
    zT_172 = fstart + fi;
    zT_173 = zT_171[zT_172];
    zT_174 = zT_173.type_id;
    field_type = zT_174;
    zT_175 = self;
    zT_176 = field_type;
    zF_9665A229_pushExpectedType(zT_175, zT_176);
    zT_178 = self;
    zT_179 = fi_node.child_0;
    zT_181 = zF_54F95822_semanticAnalyzerRes(zT_178, zT_179);
    init_type = zT_181;
    zT_182 = self;
    zF_BC478E78_popExpectedType(zT_182);
    zT_183 = self;
    zT_184 = fi_node.child_0;
    zT_185 = init_type;
    zT_186 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_183, zT_184, zT_185, zT_186);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_33;
    z_bb_39:
    zT_202 = tgt.kind;
    zT_201 = zT_202 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_41;
    z_bb_40:
    zT_201 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_201) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_208 = self->registry;
    zT_209 = zT_208->un_items;
    zT_210 = tgt.payload_idx;
    zT_211 = (unsigned int)zT_210;
    zT_212 = zT_209[zT_211];
    up = zT_212;
    zT_214 = up.fields_start;
    zT_215 = (unsigned int)zT_214;
    fstart = zT_215;
    zT_217 = up.fields_count;
    zT_218 = (unsigned int)zT_217;
    fcount = zT_218;
    zT_220 = self->store;
    zT_221 = node_idx;
    zT_223 = zF_850FDF81_astStoreNodeExtraCh(zT_220, zT_221);
    field_inits = zT_223;
    zT_225 = 0;
    zT_226 = (unsigned int)zT_225;
    fii = zT_226;
    goto z_bb_44;
    z_bb_43:
    return (unsigned int)(1);
    z_bb_44:
    zT_228 = field_inits.len;
    if ((int)(fii < zT_228)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_231 = self->store;
    zT_234 = field_inits.ptr;
    zT_232 = zT_234[fii];
    zT_236 = zF_FCDD1D35_astStoreNodeAt(zT_231, zT_232);
    fi_node = zT_236;
    zT_238 = self->store;
    zT_241 = field_inits.ptr;
    zT_239 = zT_241[fii];
    zT_243 = zF_8BA26B9E_astStoreNodePayload(zT_238, zT_239);
    fname_id = zT_243;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    zT_282 = self->type_table;
    zT_283 = node_idx;
    zT_284 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_282, zT_283, zT_284);
    return target_type;
    z_bb_47:
    zT_280 = 1;
    zT_281 = fii + zT_280;
    fii = zT_281;
    goto z_bb_44;
    z_bb_48:
    zT_247 = 0;
    zT_248 = (unsigned int)zT_247;
    fi = zT_248;
    goto z_bb_50;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    if ((int)(fi < fcount)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_250 = self->registry;
    zT_251 = zT_250->fe_items;
    zT_252 = fstart + fi;
    zT_253 = zT_251[zT_252];
    zT_254 = zT_253.name_id;
    if ((int)(zT_254 == fname_id)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_278 = 1;
    zT_279 = fi + zT_278;
    fi = zT_279;
    goto z_bb_50;
    z_bb_54:
    zT_256 = fi_node.child_0;
    if ((int)(zT_256 != (unsigned int)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_260 = self->registry;
    zT_261 = zT_260->fe_items;
    zT_262 = fstart + fi;
    zT_263 = zT_261[zT_262];
    zT_264 = zT_263.type_id;
    field_type = zT_264;
    zT_265 = self;
    zT_266 = field_type;
    zF_9665A229_pushExpectedType(zT_265, zT_266);
    zT_268 = self;
    zT_269 = fi_node.child_0;
    zT_271 = zF_54F95822_semanticAnalyzerRes(zT_268, zT_269);
    init_type = zT_271;
    zT_272 = self;
    zF_BC478E78_popExpectedType(zT_272);
    zT_273 = self;
    zT_274 = fi_node.child_0;
    zT_275 = init_type;
    zT_276 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_273, zT_274, zT_275, zT_276);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_52;
}

/* semanticAnalyzerResolveAssign */
unsigned int zF_C0551BB8_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_22A7C88B_AstNode zT_25 = {0};
    zT_8143F551_AstKind zT_26;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_39 = 0;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_43 = 0;
    zT_38C12417_SemanticAnalyzer* zT_45;
    unsigned int zT_46;
    unsigned int zT_48 = 0;
    zT_38C12417_SemanticAnalyzer* zT_50;
    unsigned int zT_51;
    zT_38C12417_SemanticAnalyzer* zT_53;
    unsigned int zT_54;
    unsigned int zT_56 = 0;
    zT_38C12417_SemanticAnalyzer* zT_57;
    int zT_60;
    char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_38C12417_SemanticAnalyzer* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_75 = 0;
    zT_38C12417_SemanticAnalyzer* zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    int zT_81 = 0;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    int zT_87 = 0;
    zT_38C12417_SemanticAnalyzer* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_106;
    unsigned int zT_108;
    unsigned int zT_110;
    char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_D155D06D_Type* zT_117;
    unsigned int zT_118;
    zT_D155D06D_Type zT_119;
    zT_33EF6BFB_TypeKind zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type* zT_123;
    unsigned int zT_124;
    zT_D155D06D_Type zT_125;
    zT_33EF6BFB_TypeKind zT_126;
    int zT_128;
    unsigned char zT_129;
    zT_38C12417_SemanticAnalyzer* zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    int zT_133 = 0;
    int zT_134;
    unsigned char zT_135;
    int zT_140;
    zT_338B7C76_TypeRegistry* zT_146;
    zT_42C2D6BF_EUPayload* zT_147;
    zT_338B7C76_TypeRegistry* zT_148;
    zT_D155D06D_Type* zT_149;
    unsigned int zT_150;
    zT_D155D06D_Type zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    zT_42C2D6BF_EUPayload zT_154;
    zT_338B7C76_TypeRegistry* zT_156;
    zT_42C2D6BF_EUPayload* zT_157;
    zT_338B7C76_TypeRegistry* zT_158;
    zT_D155D06D_Type* zT_159;
    unsigned int zT_160;
    zT_D155D06D_Type zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    zT_42C2D6BF_EUPayload zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    int zT_168;
    unsigned char zT_169;
    zT_F85C5DED_DiagnosticCollector* zT_171;
    unsigned char zT_172;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_181 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_182;
    unsigned int zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    zT_33EF6BFB_TypeKind zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    zT_33EF6BFB_TypeKind zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u ase;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    zT_22A7C88B_AstNode lhs_node;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u us_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0;
    unsigned int eff_src;
    zT_8F083A69_Slice_zT_0B42B2F8_u as1;
    zT_8F083A69_Slice_zT_0B42B2F8_u as2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u tma_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_3 = "ASE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ase = zT_4;
    zT_6 = ase;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_17 = node.child_0;
    if ((int)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->store;
    zT_22 = node.child_0;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    lhs_node = zT_25;
    zT_26 = lhs_node.kind;
    if ((int)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_50 = self;
    zT_51 = lhs;
    zF_9665A229_pushExpectedType(zT_50, zT_51);
    zT_53 = self;
    zT_54 = node.child_1;
    zT_56 = zF_54F95822_semanticAnalyzerRes(zT_53, zT_54);
    rhs = zT_56;
    zT_57 = self;
    zF_BC478E78_popExpectedType(zT_57);
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_8; else goto z_bb_7;
    z_bb_3:
    zT_32 = "_";
    zT_34 = 1;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    us_str = zT_33;
    zT_35 = self->store;
    zT_36 = node.child_0;
    zT_39 = zF_53458827_astStoreIdentifier(zT_35, zT_36);
    zT_40 = self->interner;
    zT_41 = us_str;
    zT_43 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    if ((int)(zT_39 == zT_43)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_45 = self;
    zT_46 = node.child_1;
    zT_48 = zF_54F95822_semanticAnalyzerRes(zT_45, zT_46);
    (void)zT_48;
    return (unsigned int)(1);
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_60 = rhs == (unsigned int)(0);
    goto z_bb_9;
    z_bb_8:
    zT_60 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_60) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_64 = "AS0";
    zT_66 = 3;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    as0 = zT_65;
    zT_67 = as0;
    zF_48AC7B3A_markerWrite(zT_67);
    return (unsigned int)(1);
    z_bb_11:
    zT_70 = self;
    zT_71 = node.child_1;
    zT_72 = lhs;
    zT_73 = rhs;
    zT_75 = zF_FFC95E09_errLitSrcType(zT_70, zT_71, zT_72, zT_73);
    eff_src = zT_75;
    zT_76 = self;
    zT_77 = node.child_1;
    zT_78 = eff_src;
    zT_79 = lhs;
    zT_81 = zF_86AAA417_semanticAnalyzerMay(zT_76, zT_77, zT_78, zT_79);
    if (zT_81) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_83 = self->registry;
    zT_84 = eff_src;
    zT_85 = lhs;
    zT_87 = zF_683AEB7F_typeRegistryIsAssig(zT_83, zT_84, zT_85);
    if (zT_87) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_88 = self;
    zT_89 = node.child_1;
    zT_90 = eff_src;
    zT_91 = lhs;
    zF_DF7434EB_tryRecordCoercion(zT_88, zT_89, zT_90, zT_91);
    zT_94 = "AS1";
    zT_96 = 3;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    as1 = zT_95;
    zT_97 = as1;
    zF_48AC7B3A_markerWrite(zT_97);
    return lhs;
    z_bb_15:
    zT_99 = "AS2";
    zT_101 = 3;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    as2 = zT_100;
    zT_102 = as2;
    zF_48AC7B3A_markerWrite(zT_102);
    if ((int)(lhs != (unsigned int)(1))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_106 = node.span_start;
    sp = zT_106;
    zT_108 = node.span_len;
    zT_110 = sp + (unsigned int)((unsigned int)zT_108);
    ep = zT_110;
    zT_112 = "type mismatch in assignment — internal type representations differ; generated code may be incorrect";
    zT_114 = 101;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    tma_msg = zT_113;
    zT_116 = self->registry;
    zT_117 = zT_116->types_items;
    zT_118 = (unsigned int)eff_src;
    zT_119 = zT_117[zT_118];
    zT_120 = zT_119.kind;
    sk = zT_120;
    zT_122 = self->registry;
    zT_123 = zT_122->types_items;
    zT_124 = (unsigned int)lhs;
    zT_125 = zT_123[zT_124];
    zT_126 = zT_125.kind;
    tk = zT_126;
    zT_128 = 1;
    zT_129 = (unsigned char)zT_128;
    level = zT_129;
    zT_130 = self;
    zT_131 = eff_src;
    zT_132 = lhs;
    zT_133 = zF_148F8E19_semanticAnalyzerFnP(zT_130, zT_131, zT_132);
    if (zT_133) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    return (unsigned int)(1);
    z_bb_18:
    zT_134 = 0;
    zT_135 = (unsigned char)zT_134;
    level = zT_135;
    goto z_bb_19;
    z_bb_19:
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_140 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_22;
    z_bb_21:
    zT_140 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_140) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_146 = self->registry;
    zT_147 = zT_146->eu_items;
    zT_148 = self->registry;
    zT_149 = zT_148->types_items;
    zT_150 = (unsigned int)eff_src;
    zT_151 = zT_149[zT_150];
    zT_152 = zT_151.payload_idx;
    zT_153 = (unsigned int)zT_152;
    zT_154 = zT_147[zT_153];
    eu_src = zT_154;
    zT_156 = self->registry;
    zT_157 = zT_156->eu_items;
    zT_158 = self->registry;
    zT_159 = zT_158->types_items;
    zT_160 = (unsigned int)lhs;
    zT_161 = zT_159[zT_160];
    zT_162 = zT_161.payload_idx;
    zT_163 = (unsigned int)zT_162;
    zT_164 = zT_157[zT_163];
    eu_tgt = zT_164;
    zT_165 = eu_src.error_set;
    zT_166 = eu_tgt.error_set;
    if ((int)(zT_165 == zT_166)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    zT_171 = self->diag;
    zT_172 = level;
    zT_174 = self->source_file_id;
    zT_175 = sp;
    zT_176 = ep;
    zT_177 = tma_msg;
    zT_181 = zF_C82559AC_diagnosticCollector(zT_171, zT_172, (unsigned short)(3000), zT_174, zT_175, zT_176, zT_177);
    di = zT_181;
    zT_182 = self->diag;
    zT_183 = di;
    zT_186 = sk;
    zT_187 = zF_C14453DE_typeKindSrcStr(zT_186);
    zT_184 = zT_187;
    zF_426E1F18_diagnosticCollector(zT_182, zT_183, zT_184);
    (void)self;
    zT_188 = self->diag;
    zT_189 = di;
    zT_192 = tk;
    zT_193 = zF_CC479241_typeKindTgtStr(zT_192);
    zT_190 = zT_193;
    zF_426E1F18_diagnosticCollector(zT_188, zT_189, zT_190);
    (void)self;
    goto z_bb_17;
    z_bb_25:
    zT_168 = 0;
    zT_169 = (unsigned char)zT_168;
    level = zT_169;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
}

/* semanticAnalyzerResolveSwitchExpr */
unsigned int zF_2DB4F186_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_8143F551_AstKind zT_29;
    zT_79FAE712_u64 zT_32 = 0;
    char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_55;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    int zT_61;
    unsigned char* zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65 = 0;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zT_8EED1867_ResolvedTypeTable* zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    zT_38C12417_SemanticAnalyzer* zT_92;
    unsigned int zT_93;
    unsigned int zT_95 = 0;
    unsigned int zT_98;
    int zT_101;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D155D06D_Type* zT_106;
    unsigned int zT_107;
    zT_D155D06D_Type zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_114;
    zT_33EF6BFB_TypeKind zT_115;
    char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    zT_33EF6BFB_TypeKind zT_141;
    zT_338B7C76_TypeRegistry* zT_147;
    zT_42C2D6BF_EUPayload* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_42C2D6BF_EUPayload zT_151;
    unsigned int zT_152;
    char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    zT_6B0A7D14_AstStore* zT_165;
    unsigned int zT_166;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_168 = {0};
    unsigned int zT_170;
    char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_179;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    int zT_185;
    unsigned char* zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189 = 0;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned char* zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    zT_8EED1867_ResolvedTypeTable* zT_207;
    unsigned int zT_208;
    unsigned int zT_212;
    unsigned int zT_217;
    unsigned int zT_219;
    int zT_221;
    unsigned char zT_222;
    int zT_224;
    unsigned int zT_225;
    unsigned int zT_227;
    unsigned int zT_229;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    unsigned int* zT_235;
    zT_22A7C88B_AstNode zT_237 = {0};
    unsigned char zT_238;
    int zT_243;
    unsigned char zT_244;
    unsigned char zT_245;
    int zT_250;
    unsigned char zT_251;
    char* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_259;
    zT_F85C5DED_DiagnosticCollector* zT_260;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_271 = 0;
    unsigned int zT_274;
    zT_6B0A7D14_AstStore* zT_276;
    unsigned int zT_277;
    unsigned int* zT_279;
    char* zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287;
    char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    zT_6B0A7D14_AstStore* zT_294;
    unsigned int zT_295;
    zT_8143F551_AstKind zT_296;
    unsigned int* zT_298;
    zT_79FAE712_u64 zT_301 = 0;
    unsigned int zT_305;
    int zT_308;
    zT_6B0A7D14_AstStore* zT_309;
    unsigned int zT_310;
    unsigned int* zT_312;
    unsigned int zT_314 = 0;
    zT_6B0A7D14_AstStore* zT_318;
    unsigned int zT_319;
    unsigned int* zT_321;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_323 = {0};
    int zT_325;
    unsigned int zT_326;
    unsigned int zT_328;
    zT_6B0A7D14_AstStore* zT_331;
    unsigned int zT_332;
    unsigned int* zT_334;
    zT_22A7C88B_AstNode zT_336 = {0};
    zT_8143F551_AstKind zT_338;
    unsigned int zT_339;
    char* zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned int zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned int zT_345;
    zT_8143F551_AstKind zT_346;
    zT_38C12417_SemanticAnalyzer* zT_351;
    unsigned int* zT_353;
    unsigned int zT_354;
    unsigned int zT_356 = 0;
    zT_8143F551_AstKind zT_357;
    zT_38C12417_SemanticAnalyzer* zT_362;
    unsigned int* zT_364;
    unsigned int zT_365;
    unsigned int zT_367 = 0;
    int zT_368;
    unsigned int zT_369;
    unsigned char zT_370;
    unsigned int zT_376;
    char* zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned int zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    unsigned int zT_382;
    char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned int zT_390;
    unsigned int zT_393;
    zT_21D3708C_U32ToU32Map* zT_397;
    unsigned int zT_398;
    unsigned int* zT_400;
    int zT_401;
    zT_BAEE192E_Opt_10 zT_403 = {0};
    unsigned char zT_404;
    zT_338B7C76_TypeRegistry* zT_407;
    zT_D155D06D_Type* zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    zT_D155D06D_Type zT_411;
    zT_33EF6BFB_TypeKind zT_412;
    zT_338B7C76_TypeRegistry* zT_418;
    zT_54FF90FA_TaggedUnionPayload* zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    zT_54FF90FA_TaggedUnionPayload zT_422;
    zT_338B7C76_TypeRegistry* zT_424;
    zT_2DF01B61_FieldEntry* zT_425;
    unsigned int zT_426;
    unsigned int zT_429;
    zT_2DF01B61_FieldEntry zT_430;
    char* zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned int zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned int zT_436;
    char* zT_438;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_439;
    unsigned int zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_441;
    unsigned int zT_442;
    char* zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    unsigned int zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_448;
    zT_33EF6BFB_TypeKind zT_450;
    unsigned int zT_452;
    unsigned int zT_453;
    zT_38C12417_SemanticAnalyzer* zT_455;
    unsigned int* zT_456;
    unsigned int zT_457;
    unsigned int zT_458;
    unsigned int* zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    char* zT_465;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_466;
    unsigned int zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    unsigned int zT_469;
    char* zT_471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_472;
    unsigned int zT_473;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_474;
    unsigned int zT_475;
    char* zT_478;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_479;
    unsigned int zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned int zT_482;
    zT_38C12417_SemanticAnalyzer* zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    int zT_489;
    zT_6B0A7D14_AstStore* zT_490;
    unsigned int zT_491;
    unsigned int* zT_493;
    unsigned int zT_495 = 0;
    zT_6B0A7D14_AstStore* zT_499;
    unsigned int zT_500;
    unsigned int* zT_502;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_504 = {0};
    int zT_506;
    unsigned int zT_507;
    unsigned int zT_509;
    zT_6B0A7D14_AstStore* zT_512;
    unsigned int zT_513;
    unsigned int* zT_515;
    zT_22A7C88B_AstNode zT_517 = {0};
    zT_8143F551_AstKind zT_518;
    zT_38C12417_SemanticAnalyzer* zT_523;
    unsigned int zT_524;
    zT_38C12417_SemanticAnalyzer* zT_525;
    unsigned int* zT_527;
    unsigned int zT_528;
    unsigned int zT_530 = 0;
    zT_38C12417_SemanticAnalyzer* zT_531;
    int zT_532;
    unsigned int zT_533;
    unsigned int zT_535;
    unsigned int zT_537;
    zT_6B0A7D14_AstStore* zT_541;
    unsigned int zT_542;
    zT_22A7C88B_AstNode zT_544 = {0};
    zT_8143F551_AstKind zT_545;
    unsigned int zT_546;
    char* zT_548;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_549;
    unsigned int zT_550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_551;
    unsigned int zT_552;
    char* zT_554;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_555;
    unsigned int zT_556;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_557;
    unsigned int zT_558;
    unsigned int zT_560;
    zT_38C12417_SemanticAnalyzer* zT_562;
    unsigned int zT_563;
    unsigned int zT_565 = 0;
    unsigned int zT_566;
    unsigned int zT_568;
    unsigned int* zT_572;
    unsigned int zT_573;
    unsigned int zT_574;
    zT_38C12417_SemanticAnalyzer* zT_577;
    unsigned int zT_578;
    char* zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned int zT_582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_583;
    unsigned int zT_584;
    char* zT_587;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_588;
    unsigned int zT_589;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_590;
    unsigned int zT_591;
    char* zT_593;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_594;
    unsigned int zT_595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_596;
    unsigned int zT_597;
    char* zT_600;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    unsigned int zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    char* zT_607;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_608;
    unsigned int zT_609;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_610;
    unsigned int zT_611;
    unsigned int zT_616;
    zT_338B7C76_TypeRegistry* zT_618;
    unsigned int zT_619;
    unsigned int zT_620;
    zT_0FB7FB13_CoercionKind zT_622 = 0;
    zT_38C12417_SemanticAnalyzer* zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    unsigned int zT_630;
    zT_338B7C76_TypeRegistry* zT_632;
    unsigned int zT_633;
    unsigned int zT_634;
    zT_0FB7FB13_CoercionKind zT_636 = 0;
    zT_38C12417_SemanticAnalyzer* zT_641;
    unsigned int zT_642;
    unsigned int zT_643;
    unsigned int zT_644;
    unsigned int zT_645;
    unsigned int zT_647;
    zT_338B7C76_TypeRegistry* zT_648;
    unsigned int zT_649;
    int zT_651 = 0;
    unsigned int zT_652;
    int zT_655;
    char* zT_659;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_660;
    unsigned int zT_661;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_662;
    char* zT_666;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_667;
    unsigned int zT_668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_669;
    unsigned int zT_670;
    char* zT_672;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_673;
    unsigned int zT_674;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_675;
    unsigned int zT_676;
    char* zT_678;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_679;
    unsigned int zT_680;
    zT_338B7C76_TypeRegistry* zT_682;
    zT_D155D06D_Type* zT_683;
    unsigned int zT_684;
    zT_D155D06D_Type zT_685;
    zT_33EF6BFB_TypeKind zT_686;
    unsigned int zT_687;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_688;
    unsigned int zT_689;
    char* zT_691;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_692;
    unsigned int zT_693;
    zT_338B7C76_TypeRegistry* zT_695;
    zT_D155D06D_Type* zT_696;
    unsigned int zT_697;
    zT_D155D06D_Type zT_698;
    zT_33EF6BFB_TypeKind zT_699;
    unsigned int zT_700;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_701;
    unsigned int zT_702;
    char* zT_704;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705;
    unsigned int zT_706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_707;
    unsigned int zT_708;
    char* zT_711;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_712;
    unsigned int zT_713;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_714;
    unsigned int zT_715;
    char* zT_718;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_719;
    unsigned int zT_720;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_721;
    unsigned char zT_723;
    char* zT_726;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_727;
    unsigned int zT_728;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_729;
    unsigned int zT_732;
    char* zT_735;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_736;
    unsigned int zT_737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_738;
    unsigned int zT_739;
    zT_8EED1867_ResolvedTypeTable* zT_740;
    unsigned int zT_741;
    int zT_745;
    unsigned int zT_746;
    unsigned int zT_752;
    zT_8EED1867_ResolvedTypeTable* zT_753;
    unsigned int zT_754;
    unsigned int zT_755;
    char* zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    unsigned int zT_760;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_761;
    unsigned int zT_762;
    char* zT_764;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_765;
    unsigned int zT_766;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_767;
    unsigned int zT_768;
    unsigned int zT_769;
    zT_8F083A69_Slice_zT_0B42B2F8_u se;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swi_dm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_m;
    zT_5A26C2ED_Arr_unsigned_char_1 sep_b;
    unsigned int sep_l;
    unsigned int sep_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_nl;
    unsigned int cond_type;
    unsigned int cond_es;
    zT_D155D06D_Type cond_ty;
    zT_3CB0179A_Slice_zT_05F374B1_u prongs;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_nl;
    zT_42C2D6BF_EUPayload cond_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pr0_b;
    unsigned int pr0_l;
    unsigned int pr0_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_nl;
    unsigned int unified;
    unsigned int unified_node;
    unsigned char has_else;
    unsigned int i;
    unsigned int sw_base;
    zT_22A7C88B_AstNode prong;
    zT_8F083A69_Slice_zT_0B42B2F8_u swec_msg;
    unsigned int pct;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppt_m;
    zT_3CB0179A_Slice_zT_05F374B1_u case_ec;
    unsigned int ci;
    zT_22A7C88B_AstNode case_node;
    unsigned int cc_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_m;
    unsigned int cap_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_lm;
    zT_BAEE192E_Opt_10 ev;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_rm;
    unsigned int idx;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_tm;
    zT_3CB0179A_Slice_zT_05F374B1_u es_case_ec;
    unsigned int es_ci;
    unsigned int pbd_b0;
    unsigned int pbd_k0;
    zT_22A7C88B_AstNode es_case_node;
    zT_22A7C88B_AstNode pbd_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_km;
    unsigned int saved_tu;
    unsigned int bt;
    unsigned int wi;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_fm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_tm;
    unsigned int unum;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_um;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_tk_m;
    unsigned int mix_tk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_uk_m;
    unsigned int mix_uk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_cd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_b_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_ni_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_tm;
    zT_2 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_2 + (unsigned int)(1));
    zT_6 = "SE";
    zT_8 = 2;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    se = zT_7;
    zT_9 = se;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    node = zT_14;
    zT_16 = "SWI:n";
    zT_18 = 5;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    swu_im = zT_17;
    zT_19 = swu_im;
    zT_20 = node_idx;
    zF_C914CB83_markerWriteInt(zT_19, zT_20);
    zT_22 = "SWI:p";
    zT_24 = 5;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    swu_pm = zT_23;
    zT_25 = swu_pm;
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_29 = node.kind;
    zT_32 = zF_0E4E10C6_astStoreNodePayload(zT_27, zT_28, zT_29);
    zF_C914CB83_markerWriteInt(zT_25, (unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_32 & (zT_79FAE712_u64)(4294967295u))));
    zT_37 = "SWI:d";
    zT_39 = 5;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    swi_dm = zT_38;
    zT_40 = swi_dm;
    zT_41 = self->switch_depth;
    zF_C914CB83_markerWriteInt(zT_40, zT_41);
    zT_43 = self->store;
    zT_44 = node_idx;
    zT_46 = zF_8BA26B9E_astStoreNodePayload(zT_43, zT_44);
    if ((int)(zT_46 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_50 = "P0: n";
    zT_52 = 5;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    sep_m = zT_51;
    zT_53 = sep_m;
    zF_48AC7B3A_markerWrite(zT_53);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_55[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        sep_b[_i] = zT_55[_i];
        _i++;
    }
}
    zT_57 = node_idx;
    zT_61 = 0;
    zT_62 = (unsigned char*)((unsigned char*)sep_b) + zT_61;
    zT_63 = (unsigned int)(10) - zT_61;
    zT_64.ptr = zT_62;
    zT_64.len = zT_63;
    zT_58 = zT_64;
    zT_65 = zF_A7504564_itoa(zT_57, zT_58);
    sep_l = zT_65;
    zT_69 = (unsigned int)(9) - (unsigned int)((unsigned int)sep_l);
    sep_s = zT_69;
    zT_74 = (unsigned char*)((unsigned char*)sep_b) + sep_s;
    zT_75 = (unsigned int)(9) - sep_s;
    zT_76.ptr = zT_74;
    zT_76.len = zT_75;
    zT_70 = zT_76;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_78 = "\n";
    zT_80 = 1;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    sep_nl = zT_79;
    zT_81 = sep_nl;
    zF_48AC7B3A_markerWrite(zT_81);
    zT_82 = self->type_table;
    zT_83 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_82, zT_83, (unsigned int)(1));
    zT_87 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_87 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_2:
    zT_92 = self;
    zT_93 = node.child_0;
    zT_95 = zF_54F95822_semanticAnalyzerRes(zT_92, zT_93);
    cond_type = zT_95;
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_98 = 0;
    cond_es = zT_98;
    if ((int)(cond_type != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_101 = cond_type != (unsigned int)(1);
    goto z_bb_5;
    z_bb_4:
    zT_101 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_101) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_105 = self->registry;
    zT_106 = zT_105->types_items;
    zT_107 = (unsigned int)cond_type;
    zT_108 = zT_106[zT_107];
    cond_ty = zT_108;
    zT_109 = cond_ty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_9; else goto z_bb_8;
    z_bb_7:
    zT_165 = self->store;
    zT_166 = node_idx;
    zT_168 = zF_850FDF81_astStoreNodeExtraCh(zT_165, zT_166);
    prongs = zT_168;
    zT_170 = prongs.len;
    if ((int)(zT_170 == (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_8:
    zT_115 = cond_ty.kind;
    zT_114 = zT_115 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_10;
    z_bb_9:
    zT_114 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_114) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    self->current_switch_cond_tu = cond_type;
    zT_121 = "Z";
    zT_123 = 1;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    rs = zT_122;
    zT_124 = rs;
    zF_48AC7B3A_markerWrite(zT_124);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_7;
    z_bb_13:
    zT_125 = cond_ty.kind;
    if ((int)(zT_125 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cond_es = cond_type;
    zT_131 = "SWES:e";
    zT_133 = 6;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    swes_m = zT_132;
    zT_134 = swes_m;
    zT_135 = cond_es;
    zF_C914CB83_markerWriteInt(zT_134, zT_135);
    zT_137 = "\n";
    zT_139 = 1;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    swes_nl = zT_138;
    zT_140 = swes_nl;
    zF_48AC7B3A_markerWrite(zT_140);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_141 = cond_ty.kind;
    if ((int)(zT_141 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_147 = self->registry;
    zT_148 = zT_147->eu_items;
    zT_149 = cond_ty.payload_idx;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zT_148[zT_150];
    cond_eu = zT_151;
    zT_152 = cond_eu.error_set;
    cond_es = zT_152;
    zT_154 = "SWEU:e";
    zT_156 = 6;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    sweu_m = zT_155;
    zT_157 = sweu_m;
    zT_158 = cond_es;
    zF_C914CB83_markerWriteInt(zT_157, zT_158);
    zT_160 = "\n";
    zT_162 = 1;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    sweu_nl = zT_161;
    zT_163 = sweu_nl;
    zF_48AC7B3A_markerWrite(zT_163);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_174 = "PL0:n";
    zT_176 = 5;
    zT_175.ptr = zT_174;
    zT_175.len = zT_176;
    pr0_m = zT_175;
    zT_177 = pr0_m;
    zF_48AC7B3A_markerWrite(zT_177);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_179[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pr0_b[_i] = zT_179[_i];
        _i++;
    }
}
    zT_181 = node_idx;
    zT_185 = 0;
    zT_186 = (unsigned char*)((unsigned char*)pr0_b) + zT_185;
    zT_187 = (unsigned int)(10) - zT_185;
    zT_188.ptr = zT_186;
    zT_188.len = zT_187;
    zT_182 = zT_188;
    zT_189 = zF_A7504564_itoa(zT_181, zT_182);
    pr0_l = zT_189;
    zT_193 = (unsigned int)(9) - (unsigned int)((unsigned int)pr0_l);
    pr0_s = zT_193;
    zT_198 = (unsigned char*)((unsigned char*)pr0_b) + pr0_s;
    zT_199 = (unsigned int)(9) - pr0_s;
    zT_200.ptr = zT_198;
    zT_200.len = zT_199;
    zT_194 = zT_200;
    zF_48AC7B3A_markerWrite(zT_194);
    zT_202 = "\n";
    zT_204 = 1;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    pr0_nl = zT_203;
    zT_205 = pr0_nl;
    zF_48AC7B3A_markerWrite(zT_205);
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_207 = self->type_table;
    zT_208 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_207, zT_208, (unsigned int)(1));
    zT_212 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_212 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_20:
    zT_217 = 0;
    unified = zT_217;
    zT_219 = 0;
    unified_node = zT_219;
    zT_221 = 0;
    zT_222 = (unsigned char)zT_221;
    has_else = zT_222;
    zT_224 = 0;
    zT_225 = (unsigned int)zT_224;
    i = zT_225;
    zT_227 = self->stmt_work_len;
    sw_base = zT_227;
    goto z_bb_21;
    z_bb_21:
    zT_229 = prongs.len;
    if ((int)(i < zT_229)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_232 = self->store;
    zT_235 = prongs.ptr;
    zT_233 = zT_235[i];
    zT_237 = zF_FCDD1D35_astStoreNodeAt(zT_232, zT_233);
    prong = zT_237;
    zT_238 = prong.flags;
    if ((int)((unsigned char)(zT_238 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    self->current_switch_cond_tu = (unsigned int)(0);
    if ((int)(has_else == (unsigned char)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_24:
    zT_745 = 1;
    zT_746 = i + zT_745;
    i = zT_746;
    goto z_bb_21;
    z_bb_25:
    zT_243 = 1;
    zT_244 = (unsigned char)zT_243;
    has_else = zT_244;
    goto z_bb_26;
    z_bb_26:
    zT_245 = prong.flags;
    if ((int)((unsigned char)(zT_245 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_251 = prong.flags;
    zT_250 = (unsigned char)(zT_251 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_29;
    z_bb_28:
    zT_250 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_250) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_257 = "switch else-prong capture (else => |capture|) is not supported";
    zT_259 = 62;
    zT_258.ptr = zT_257;
    zT_258.len = zT_259;
    swec_msg = zT_258;
    zT_260 = self->diag;
    zT_263 = self->source_file_id;
    zT_264 = node_idx;
    zT_265 = node_idx;
    zT_266 = swec_msg;
    zT_271 = zF_C82559AC_diagnosticCollector(zT_260, (unsigned char)(0), (unsigned short)(3001), zT_263, zT_264, zT_265, zT_266);
    (void)zT_271;
    return (unsigned int)(1);
    z_bb_31:
    zT_274 = self->current_switch_cond_tu;
    pct = zT_274;
    zT_276 = self->store;
    zT_279 = prongs.ptr;
    zT_277 = zT_279[i];
    (void)zF_8BA26B9E_astStoreNodePayload(zT_276, zT_277);
    zT_283 = "PCT:C";
    zT_285 = 5;
    zT_284.ptr = zT_283;
    zT_284.len = zT_285;
    pct_m2 = zT_284;
    zT_286 = pct_m2;
    zT_287 = pct;
    zF_C914CB83_markerWriteInt(zT_286, zT_287);
    zT_289 = "PCT:P";
    zT_291 = 5;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    ppt_m = zT_290;
    zT_292 = ppt_m;
    zT_294 = self->store;
    zT_298 = prongs.ptr;
    zT_295 = zT_298[i];
    zT_296 = prong.kind;
    zT_301 = zF_0E4E10C6_astStoreNodePayload(zT_294, zT_295, zT_296);
    zF_C914CB83_markerWriteInt(zT_292, (unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_301 & (zT_79FAE712_u64)(4294967295u))));
    zT_305 = self->current_switch_cond_tu;
    if ((int)(zT_305 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_309 = self->store;
    zT_312 = prongs.ptr;
    zT_310 = zT_312[i];
    zT_314 = zF_8BA26B9E_astStoreNodePayload(zT_309, zT_310);
    zT_308 = zT_314 != (unsigned int)(0);
    goto z_bb_34;
    z_bb_33:
    zT_308 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_308) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_318 = self->store;
    zT_321 = prongs.ptr;
    zT_319 = zT_321[i];
    zT_323 = zF_850FDF81_astStoreNodeExtraCh(zT_318, zT_319);
    case_ec = zT_323;
    zT_325 = 0;
    zT_326 = (unsigned int)zT_325;
    ci = zT_326;
    goto z_bb_37;
    z_bb_36:
    if ((int)(cond_es != (unsigned int)(0))) goto z_bb_57; else goto z_bb_58;
    z_bb_37:
    zT_328 = case_ec.len;
    if ((int)(ci < zT_328)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_331 = self->store;
    zT_334 = case_ec.ptr;
    zT_332 = zT_334[ci];
    zT_336 = zF_FCDD1D35_astStoreNodeAt(zT_331, zT_332);
    case_node = zT_336;
    zT_338 = case_node.kind;
    zT_339 = (unsigned int)zT_338;
    cc_val = zT_339;
    zT_341 = "CC:K";
    zT_343 = 4;
    zT_342.ptr = zT_341;
    zT_342.len = zT_343;
    cc_m = zT_342;
    zT_344 = cc_m;
    zT_345 = cc_val;
    zF_C914CB83_markerWriteInt(zT_344, zT_345);
    zT_346 = case_node.kind;
    if ((int)(zT_346 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_41; else goto z_bb_43;
    z_bb_39:
    zT_370 = prong.flags;
    if ((int)((unsigned char)(zT_370 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_40:
    zT_368 = 1;
    zT_369 = ci + zT_368;
    ci = zT_369;
    goto z_bb_37;
    z_bb_41:
    zT_351 = self;
    zT_353 = case_ec.ptr;
    zT_354 = zT_353[ci];
    zT_356 = zF_8C008E53_semanticAnalyzerRes(zT_351, (unsigned int)((unsigned int)zT_354));
    (void)zT_356;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_357 = case_node.kind;
    if ((int)(zT_357 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_362 = self;
    zT_364 = case_ec.ptr;
    zT_365 = zT_364[ci];
    zT_367 = zF_8C008E53_semanticAnalyzerRes(zT_362, (unsigned int)((unsigned int)zT_365));
    (void)zT_367;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_376 = prong.child_1;
    cap_name = zT_376;
    zT_378 = "SCE:p";
    zT_380 = 5;
    zT_379.ptr = zT_378;
    zT_379.len = zT_380;
    sce_pm = zT_379;
    zT_381 = sce_pm;
    zT_382 = cap_name;
    zF_C914CB83_markerWriteInt(zT_381, zT_382);
    zT_384 = "SCE:l";
    zT_386 = 5;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    sce_lm = zT_385;
    zT_387 = sce_lm;
    zT_390 = case_ec.len;
    zF_C914CB83_markerWriteInt(zT_387, (unsigned int)((unsigned int)zT_390));
    zT_393 = case_ec.len;
    if ((int)(zT_393 > (unsigned int)(0))) goto z_bb_48; else goto z_bb_50;
    z_bb_47:
    goto z_bb_36;
    z_bb_48:
    zT_397 = self->enum_value_table;
    zT_400 = case_ec.ptr;
    zT_401 = 0;
    zT_398 = zT_400[zT_401];
    zT_403 = zF_F3EE5998_u32ToU32MapGet(zT_397, zT_398);
    ev = zT_403;
    zT_404 = ev.has_value;
    if (zT_404) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_478 = "SCE:R";
    zT_480 = 5;
    zT_479.ptr = zT_478;
    zT_479.len = zT_480;
    sce_rm = zT_479;
    zT_481 = sce_rm;
    zT_482 = cap_name;
    zF_C914CB83_markerWriteInt(zT_481, zT_482);
    zT_483 = self;
    zT_484 = cap_name;
    zT_485 = self->current_switch_cond_tu;
    zF_7BD72017_registerLocalDecl(zT_483, zT_484, zT_485);
    goto z_bb_49;
    z_bb_51:
    idx = ev.value;
    zT_407 = self->registry;
    zT_408 = zT_407->types_items;
    zT_409 = self->current_switch_cond_tu;
    zT_410 = (unsigned int)zT_409;
    zT_411 = zT_408[zT_410];
    tu_ty = zT_411;
    zT_412 = tu_ty.kind;
    if ((int)(zT_412 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_418 = self->registry;
    zT_419 = zT_418->tu_items;
    zT_420 = tu_ty.payload_idx;
    zT_421 = (unsigned int)zT_420;
    zT_422 = zT_419[zT_421];
    tp = zT_422;
    zT_424 = self->registry;
    zT_425 = zT_424->fe_items;
    zT_426 = tp.fields_start;
    zT_429 = (unsigned int)((unsigned int)zT_426) + (unsigned int)((unsigned int)idx);
    zT_430 = zT_425[zT_429];
    fe = zT_430;
    zT_432 = "SCFE:n";
    zT_434 = 6;
    zT_433.ptr = zT_432;
    zT_433.len = zT_434;
    scfe_nm = zT_433;
    zT_435 = scfe_nm;
    zT_436 = cap_name;
    zF_C914CB83_markerWriteInt(zT_435, zT_436);
    zT_438 = "SCFE:t";
    zT_440 = 6;
    zT_439.ptr = zT_438;
    zT_439.len = zT_440;
    scfe_tm = zT_439;
    zT_441 = scfe_tm;
    zT_442 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_441, zT_442);
    zT_445 = "SCFE:k";
    zT_447 = 6;
    zT_446.ptr = zT_445;
    zT_446.len = zT_447;
    scfe_km = zT_446;
    zT_448 = scfe_km;
    zT_450 = tu_ty.kind;
    zF_C914CB83_markerWriteInt(zT_448, (unsigned int)((unsigned int)zT_450));
    zT_452 = self->local_decl_count;
    zT_453 = self->local_decl_cap;
    if ((int)(zT_452 >= zT_453)) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_455 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_455);
    goto z_bb_56;
    z_bb_56:
    zT_456 = self->local_decl_names;
    zT_457 = self->local_decl_count;
    zT_456[zT_457] = cap_name;
    zT_458 = fe.type_id;
    zT_459 = self->local_decl_types;
    zT_460 = self->local_decl_count;
    zT_459[zT_460] = zT_458;
    zT_461 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_461 + (unsigned int)(1));
    zT_465 = "SCAX:N";
    zT_467 = 6;
    zT_466.ptr = zT_465;
    zT_466.len = zT_467;
    scax_m = zT_466;
    zT_468 = scax_m;
    zT_469 = cap_name;
    zF_C914CB83_markerWriteInt(zT_468, zT_469);
    zT_471 = "SCAX:T";
    zT_473 = 6;
    zT_472.ptr = zT_471;
    zT_472.len = zT_473;
    scax_tm = zT_472;
    zT_474 = scax_tm;
    zT_475 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_474, zT_475);
    goto z_bb_54;
    z_bb_57:
    zT_490 = self->store;
    zT_493 = prongs.ptr;
    zT_491 = zT_493[i];
    zT_495 = zF_8BA26B9E_astStoreNodePayload(zT_490, zT_491);
    zT_489 = zT_495 != (unsigned int)(0);
    goto z_bb_59;
    z_bb_58:
    zT_489 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_489) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_499 = self->store;
    zT_502 = prongs.ptr;
    zT_500 = zT_502[i];
    zT_504 = zF_850FDF81_astStoreNodeExtraCh(zT_499, zT_500);
    es_case_ec = zT_504;
    zT_506 = 0;
    zT_507 = (unsigned int)zT_506;
    es_ci = zT_507;
    goto z_bb_62;
    z_bb_61:
    zT_535 = prong.child_0;
    pbd_b0 = zT_535;
    zT_537 = 0;
    pbd_k0 = zT_537;
    if ((int)(pbd_b0 != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_62:
    zT_509 = es_case_ec.len;
    if ((int)(es_ci < zT_509)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_512 = self->store;
    zT_515 = es_case_ec.ptr;
    zT_513 = zT_515[es_ci];
    zT_517 = zF_FCDD1D35_astStoreNodeAt(zT_512, zT_513);
    es_case_node = zT_517;
    zT_518 = es_case_node.kind;
    if ((int)(zT_518 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_532 = 1;
    zT_533 = es_ci + zT_532;
    es_ci = zT_533;
    goto z_bb_62;
    z_bb_66:
    zT_523 = self;
    zT_524 = cond_es;
    zF_9665A229_pushExpectedType(zT_523, zT_524);
    zT_525 = self;
    zT_527 = es_case_ec.ptr;
    zT_528 = zT_527[es_ci];
    zT_530 = zF_54F95822_semanticAnalyzerRes(zT_525, (unsigned int)((unsigned int)zT_528));
    (void)zT_530;
    zT_531 = self;
    zF_BC478E78_popExpectedType(zT_531);
    goto z_bb_67;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_541 = self->store;
    zT_542 = pbd_b0;
    zT_544 = zF_FCDD1D35_astStoreNodeAt(zT_541, zT_542);
    pbd_n = zT_544;
    zT_545 = pbd_n.kind;
    zT_546 = (unsigned int)zT_545;
    pbd_k0 = zT_546;
    goto z_bb_69;
    z_bb_69:
    zT_548 = "PBD:N";
    zT_550 = 5;
    zT_549.ptr = zT_548;
    zT_549.len = zT_550;
    pbd_nm = zT_549;
    zT_551 = pbd_nm;
    zT_552 = pbd_b0;
    zF_C914CB83_markerWriteInt(zT_551, zT_552);
    zT_554 = "PBD:K";
    zT_556 = 5;
    zT_555.ptr = zT_554;
    zT_555.len = zT_556;
    pbd_km = zT_555;
    zT_557 = pbd_km;
    zT_558 = pbd_k0;
    zF_C914CB83_markerWriteInt(zT_557, zT_558);
    zT_560 = self->current_switch_cond_tu;
    saved_tu = zT_560;
    zT_562 = self;
    zT_563 = prong.child_0;
    zT_565 = zF_54F95822_semanticAnalyzerRes(zT_562, zT_563);
    bt = zT_565;
    self->current_switch_cond_tu = saved_tu;
    goto z_bb_70;
    z_bb_70:
    zT_566 = self->stmt_work_len;
    if ((int)(zT_566 > sw_base)) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_568 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_568 - (unsigned int)(1));
    zT_572 = self->stmt_work_items;
    zT_573 = self->stmt_work_len;
    zT_574 = zT_572[zT_573];
    wi = zT_574;
    if ((int)(wi != (unsigned int)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_580 = "PCT:n";
    zT_582 = 5;
    zT_581.ptr = zT_580;
    zT_581.len = zT_582;
    pct_m = zT_581;
    zT_583 = pct_m;
    zT_584 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_583, zT_584);
    zT_587 = "PCT:b";
    zT_589 = 5;
    zT_588.ptr = zT_587;
    zT_588.len = zT_589;
    pct_bm = zT_588;
    zT_590 = pct_bm;
    zT_591 = bt;
    zF_C914CB83_markerWriteInt(zT_590, zT_591);
    zT_593 = "PCT:f";
    zT_595 = 5;
    zT_594.ptr = zT_593;
    zT_594.len = zT_595;
    pct_fm = zT_594;
    zT_596 = pct_fm;
    zT_597 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_596, zT_597);
    zT_600 = "SWPB:i";
    zT_602 = 6;
    zT_601.ptr = zT_600;
    zT_601.len = zT_602;
    swpb_im = zT_601;
    zT_603 = swpb_im;
    zF_C914CB83_markerWriteInt(zT_603, (unsigned int)((unsigned int)i));
    zT_607 = "SWPB:t";
    zT_609 = 6;
    zT_608.ptr = zT_607;
    zT_608.len = zT_609;
    swpb_tm = zT_608;
    zT_610 = swpb_tm;
    zT_611 = bt;
    zF_C914CB83_markerWriteInt(zT_610, zT_611);
    if ((int)(bt == (unsigned int)(3))) goto z_bb_76; else goto z_bb_78;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    zT_577 = self;
    zT_578 = wi;
    zF_10A0DC35_semanticAnalyzerRes(zT_577, zT_578);
    goto z_bb_75;
    z_bb_75:
    goto z_bb_73;
    z_bb_76:
    goto z_bb_77;
    z_bb_77:
    goto z_bb_24;
    z_bb_78:
    if ((int)(unified == (unsigned int)(0))) goto z_bb_79; else goto z_bb_81;
    z_bb_79:
    unified = bt;
    zT_616 = prong.child_0;
    unified_node = zT_616;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_77;
    z_bb_81:
    if ((int)(bt == unified)) goto z_bb_82; else goto z_bb_84;
    z_bb_82:
    goto z_bb_83;
    z_bb_83:
    goto z_bb_80;
    z_bb_84:
    zT_618 = self->registry;
    zT_619 = bt;
    zT_620 = unified;
    zT_622 = zF_713658BF_classifyCoercion(zT_618, zT_619, zT_620);
    if ((int)(zT_622 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_85; else goto z_bb_87;
    z_bb_85:
    zT_627 = self;
    zT_628 = prong.child_0;
    zT_629 = bt;
    zT_630 = unified;
    zF_DF7434EB_tryRecordCoercion(zT_627, zT_628, zT_629, zT_630);
    goto z_bb_86;
    z_bb_86:
    goto z_bb_83;
    z_bb_87:
    zT_632 = self->registry;
    zT_633 = unified;
    zT_634 = bt;
    zT_636 = zF_713658BF_classifyCoercion(zT_632, zT_633, zT_634);
    if ((int)(zT_636 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    zT_641 = self;
    zT_642 = unified_node;
    zT_643 = unified;
    zT_644 = bt;
    zF_DF7434EB_tryRecordCoercion(zT_641, zT_642, zT_643, zT_644);
    unified = bt;
    zT_645 = prong.child_0;
    unified_node = zT_645;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_86;
    z_bb_90:
    zT_647 = 0;
    unum = zT_647;
    zT_648 = self->registry;
    zT_649 = bt;
    zT_651 = zF_3087E0A5_typeRegistryIsNumer(zT_648, zT_649);
    if (zT_651) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_652 = 1;
    unum = zT_652;
    goto z_bb_92;
    z_bb_92:
    if ((int)(unified == (unsigned int)(19))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_655 = unum != (unsigned int)(0);
    goto z_bb_95;
    z_bb_94:
    zT_655 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_655) goto z_bb_96; else goto z_bb_98;
    z_bb_96:
    unified = bt;
    goto z_bb_97;
    z_bb_97:
    goto z_bb_89;
    z_bb_98:
    zT_659 = "MIX:P";
    zT_661 = 5;
    zT_660.ptr = zT_659;
    zT_660.len = zT_661;
    mix_pm = zT_660;
    zT_662 = mix_pm;
    zF_C914CB83_markerWriteInt(zT_662, (unsigned int)((unsigned int)i));
    zT_666 = "MIX:U";
    zT_668 = 5;
    zT_667.ptr = zT_666;
    zT_667.len = zT_668;
    mix_um = zT_667;
    zT_669 = mix_um;
    zT_670 = unified;
    zF_C914CB83_markerWriteInt(zT_669, zT_670);
    zT_672 = "MIX:B";
    zT_674 = 5;
    zT_673.ptr = zT_672;
    zT_673.len = zT_674;
    mix_bm = zT_673;
    zT_675 = mix_bm;
    zT_676 = bt;
    zF_C914CB83_markerWriteInt(zT_675, zT_676);
    zT_678 = "MIX:tk";
    zT_680 = 6;
    zT_679.ptr = zT_678;
    zT_679.len = zT_680;
    mix_tk_m = zT_679;
    zT_682 = self->registry;
    zT_683 = zT_682->types_items;
    zT_684 = (unsigned int)bt;
    zT_685 = zT_683[zT_684];
    zT_686 = zT_685.kind;
    zT_687 = (unsigned int)zT_686;
    mix_tk_v = zT_687;
    zT_688 = mix_tk_m;
    zT_689 = mix_tk_v;
    zF_C914CB83_markerWriteInt(zT_688, zT_689);
    zT_691 = "MIX:uk";
    zT_693 = 6;
    zT_692.ptr = zT_691;
    zT_692.len = zT_693;
    mix_uk_m = zT_692;
    zT_695 = self->registry;
    zT_696 = zT_695->types_items;
    zT_697 = (unsigned int)unified;
    zT_698 = zT_696[zT_697];
    zT_699 = zT_698.kind;
    zT_700 = (unsigned int)zT_699;
    mix_uk_v = zT_700;
    zT_701 = mix_uk_m;
    zT_702 = mix_uk_v;
    zF_C914CB83_markerWriteInt(zT_701, zT_702);
    zT_704 = "MIX:cd";
    zT_706 = 6;
    zT_705.ptr = zT_704;
    zT_705.len = zT_706;
    mix_cd_m = zT_705;
    zT_707 = mix_cd_m;
    zT_708 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_707, zT_708);
    zT_711 = "MIX:b";
    zT_713 = 5;
    zT_712.ptr = zT_711;
    zT_712.len = zT_713;
    mix_b_m = zT_712;
    zT_714 = mix_b_m;
    zT_715 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_714, zT_715);
    zT_718 = "MIX:pf";
    zT_720 = 6;
    zT_719.ptr = zT_718;
    zT_719.len = zT_720;
    mix_pf_m = zT_719;
    zT_721 = mix_pf_m;
    zT_723 = prong.flags;
    zF_C914CB83_markerWriteInt(zT_721, (unsigned int)((unsigned int)zT_723));
    zT_726 = "MIX:pn";
    zT_728 = 6;
    zT_727.ptr = zT_726;
    zT_727.len = zT_728;
    mix_pn_m = zT_727;
    zT_729 = mix_pn_m;
    zT_732 = prongs.len;
    zF_C914CB83_markerWriteInt(zT_729, (unsigned int)((unsigned int)zT_732));
    zT_735 = "MIX:ni";
    zT_737 = 6;
    zT_736.ptr = zT_735;
    zT_736.len = zT_737;
    mix_ni_m = zT_736;
    zT_738 = mix_ni_m;
    zT_739 = node_idx;
    zF_C914CB83_markerWriteInt(zT_738, zT_739);
    zT_740 = self->type_table;
    zT_741 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_740, zT_741, (unsigned int)(1));
    goto z_bb_24;
    z_bb_99:
    goto z_bb_100;
    z_bb_100:
    if ((int)(unified == (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_752 = 1;
    unified = zT_752;
    goto z_bb_102;
    z_bb_102:
    zT_753 = self->type_table;
    zT_754 = node_idx;
    zT_755 = unified;
    zF_19B4A07D_resolvedTypeTableSe(zT_753, zT_754, zT_755);
    zT_758 = "SWU:n";
    zT_760 = 5;
    zT_759.ptr = zT_758;
    zT_759.len = zT_760;
    swu_m = zT_759;
    zT_761 = swu_m;
    zT_762 = node_idx;
    zF_C914CB83_markerWriteInt(zT_761, zT_762);
    zT_764 = "SWU:t";
    zT_766 = 5;
    zT_765.ptr = zT_764;
    zT_765.len = zT_766;
    swu_tm = zT_765;
    zT_767 = swu_tm;
    zT_768 = unified;
    zF_C914CB83_markerWriteInt(zT_767, zT_768);
    zT_769 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_769 - (unsigned int)(1));
    return unified;
}

/* semanticAnalyzerResolveExpr */
unsigned int zF_54F95822_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    unsigned int zT_12;
    zT_8143F551_AstKind zT_13;
    char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8143F551_AstKind zT_29;
    unsigned int zT_34;
    zT_8143F551_AstKind zT_35;
    unsigned int zT_40;
    zT_8143F551_AstKind zT_41;
    unsigned int zT_46;
    zT_8143F551_AstKind zT_47;
    unsigned int zT_52;
    zT_8143F551_AstKind zT_53;
    unsigned int zT_58;
    zT_8143F551_AstKind zT_59;
    unsigned int zT_64;
    zT_8143F551_AstKind zT_65;
    unsigned int zT_70;
    zT_8143F551_AstKind zT_71;
    zT_338B7C76_TypeRegistry* zT_76;
    unsigned int zT_82 = 0;
    zT_8143F551_AstKind zT_83;
    zT_38C12417_SemanticAnalyzer* zT_88;
    unsigned int zT_89;
    unsigned int zT_90 = 0;
    zT_8143F551_AstKind zT_91;
    unsigned int zT_96;
    int zT_97;
    unsigned int* zT_100;
    unsigned int zT_101;
    int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    int zT_105;
    int zT_108;
    unsigned int zT_109;
    zT_338B7C76_TypeRegistry* zT_111;
    zT_D155D06D_Type* zT_112;
    unsigned int zT_113;
    zT_D155D06D_Type zT_114;
    zT_33EF6BFB_TypeKind zT_116;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_0B10E8E9_OptionalPayload* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_0B10E8E9_OptionalPayload zT_126;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_128;
    zT_D155D06D_Type* zT_129;
    unsigned int zT_130;
    zT_D155D06D_Type zT_131;
    zT_33EF6BFB_TypeKind zT_132;
    zT_33EF6BFB_TypeKind zT_137;
    zT_338B7C76_TypeRegistry* zT_142;
    zT_42C2D6BF_EUPayload* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_42C2D6BF_EUPayload zT_146;
    unsigned int zT_147;
    int zT_148;
    zT_6B0A7D14_AstStore* zT_151;
    unsigned int zT_152;
    unsigned int zT_154 = 0;
    zT_338B7C76_TypeRegistry* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_160 = 0;
    zT_21D3708C_U32ToU32Map* zT_164;
    unsigned int zT_165;
    unsigned int zT_167 = 0;
    zT_21D3708C_U32ToU32Map* zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    zT_8EED1867_ResolvedTypeTable* zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_177;
    unsigned int zT_179;
    unsigned int zT_181;
    char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    zT_F85C5DED_DiagnosticCollector* zT_186;
    unsigned int zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_200 = 0;
    unsigned int zT_201;
    zT_33EF6BFB_TypeKind zT_202;
    zT_8EED1867_ResolvedTypeTable* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    zT_8143F551_AstKind zT_214;
    zT_38C12417_SemanticAnalyzer* zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_6B0A7D14_AstStore* zT_224;
    unsigned int zT_225;
    unsigned int zT_227 = 0;
    unsigned int zT_228 = 0;
    zT_8143F551_AstKind zT_229;
    zT_38C12417_SemanticAnalyzer* zT_234;
    unsigned int zT_235;
    unsigned int zT_236 = 0;
    char* zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    zT_8143F551_AstKind zT_243;
    zT_38C12417_SemanticAnalyzer* zT_248;
    unsigned int zT_249;
    unsigned int zT_250 = 0;
    zT_8143F551_AstKind zT_251;
    zT_38C12417_SemanticAnalyzer* zT_256;
    unsigned int zT_257;
    unsigned int zT_258 = 0;
    zT_8143F551_AstKind zT_259;
    zT_38C12417_SemanticAnalyzer* zT_265;
    unsigned int zT_266;
    unsigned int zT_268 = 0;
    int zT_271;
    zT_338B7C76_TypeRegistry* zT_275;
    zT_D155D06D_Type* zT_276;
    unsigned int zT_277;
    zT_D155D06D_Type zT_278;
    zT_33EF6BFB_TypeKind zT_279;
    int zT_284;
    zT_33EF6BFB_TypeKind zT_285;
    zT_338B7C76_TypeRegistry* zT_291;
    zT_112BF819_PtrPayload* zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    zT_112BF819_PtrPayload zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    zT_8143F551_AstKind zT_298;
    zT_38C12417_SemanticAnalyzer* zT_304;
    unsigned int zT_305;
    unsigned int zT_307 = 0;
    int zT_310;
    zT_6B0A7D14_AstStore* zT_314;
    unsigned int zT_315;
    zT_22A7C88B_AstNode zT_318 = {0};
    zT_8143F551_AstKind zT_319;
    zT_38C12417_SemanticAnalyzer* zT_325;
    unsigned int zT_326;
    unsigned int zT_328 = 0;
    int zT_332;
    zT_338B7C76_TypeRegistry* zT_336;
    zT_D155D06D_Type* zT_337;
    unsigned int zT_338;
    zT_D155D06D_Type zT_339;
    zT_33EF6BFB_TypeKind zT_340;
    int zT_345;
    zT_33EF6BFB_TypeKind zT_346;
    zT_338B7C76_TypeRegistry* zT_351;
    zT_112BF819_PtrPayload* zT_352;
    unsigned int zT_353;
    unsigned int zT_354;
    zT_112BF819_PtrPayload zT_355;
    unsigned int zT_356;
    zT_338B7C76_TypeRegistry* zT_357;
    zT_D155D06D_Type* zT_358;
    unsigned int zT_359;
    zT_D155D06D_Type zT_360;
    zT_33EF6BFB_TypeKind zT_361;
    zT_38C12417_SemanticAnalyzer* zT_367;
    unsigned int zT_368;
    unsigned int zT_369 = 0;
    unsigned int zT_373;
    unsigned int zT_375;
    unsigned int zT_377;
    char* zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380;
    unsigned int zT_381;
    zT_F85C5DED_DiagnosticCollector* zT_382;
    unsigned int zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_388;
    unsigned int zT_393 = 0;
    zT_33EF6BFB_TypeKind zT_394;
    unsigned int zT_400;
    unsigned int zT_402;
    unsigned int zT_404;
    char* zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    unsigned int zT_408;
    zT_F85C5DED_DiagnosticCollector* zT_409;
    unsigned int zT_412;
    unsigned int zT_413;
    unsigned int zT_414;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_415;
    unsigned int zT_420 = 0;
    zT_338B7C76_TypeRegistry* zT_421;
    unsigned int zT_422;
    unsigned int zT_426 = 0;
    unsigned int zT_427;
    zT_8143F551_AstKind zT_428;
    zT_38C12417_SemanticAnalyzer* zT_433;
    unsigned int zT_434;
    unsigned int zT_435 = 0;
    zT_8143F551_AstKind zT_436;
    int zT_441;
    zT_38C12417_SemanticAnalyzer* zT_442;
    unsigned int zT_443;
    int zT_445 = 0;
    char* zT_448;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_449;
    unsigned int zT_450;
    zT_F85C5DED_DiagnosticCollector* zT_451;
    unsigned int zT_454;
    unsigned int zT_455;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_457;
    unsigned int zT_463;
    unsigned int zT_464;
    unsigned int zT_467 = 0;
    unsigned int zT_468;
    zT_8143F551_AstKind zT_469;
    zT_6B0A7D14_AstStore* zT_475;
    unsigned int zT_476;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_478 = {0};
    unsigned int zT_479;
    unsigned int zT_480;
    int zT_482;
    unsigned int zT_483;
    unsigned int zT_484;
    int zT_486;
    unsigned int zT_487;
    unsigned int zT_488;
    int zT_490;
    unsigned int zT_491;
    unsigned int zT_492;
    int zT_494;
    unsigned int zT_495;
    unsigned int zT_496;
    unsigned int zT_499;
    zT_ABC1EBBE_TypeResolveEnv zT_503;
    zT_6B0A7D14_AstStore* zT_504;
    zT_338B7C76_TypeRegistry* zT_505;
    zT_3D7259E2_SymbolRegistry* zT_506;
    zT_D3EB6303_StringInterner* zT_507;
    unsigned int zT_508;
    zT_ABC1EBBE_TypeResolveEnv* zT_509;
    unsigned int zT_510;
    unsigned int* zT_513;
    unsigned int zT_514;
    unsigned int zT_517 = 0;
    unsigned int zT_518;
    unsigned int zT_519;
    unsigned int zT_520;
    int zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    unsigned int zT_527;
    zT_38C12417_SemanticAnalyzer* zT_530;
    unsigned int zT_531;
    unsigned int* zT_532;
    unsigned int zT_533;
    unsigned int zT_535 = 0;
    unsigned int zT_536;
    unsigned int zT_537;
    unsigned int zT_538;
    unsigned int zT_542;
    unsigned int zT_544;
    zT_38C12417_SemanticAnalyzer* zT_547;
    unsigned int zT_548;
    unsigned int* zT_549;
    unsigned int zT_550;
    unsigned int zT_552 = 0;
    zT_38C12417_SemanticAnalyzer* zT_554;
    unsigned int zT_555 = 0;
    int zT_558;
    zT_338B7C76_TypeRegistry* zT_562;
    zT_D155D06D_Type* zT_563;
    unsigned int zT_564;
    zT_D155D06D_Type zT_565;
    zT_33EF6BFB_TypeKind zT_566;
    int zT_571;
    zT_33EF6BFB_TypeKind zT_572;
    char* zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned int zT_582;
    zT_F85C5DED_DiagnosticCollector* zT_583;
    unsigned int zT_586;
    unsigned int zT_587;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_589;
    unsigned int zT_598;
    unsigned int zT_599;
    unsigned int zT_602 = 0;
    unsigned int zT_603;
    unsigned int zT_604;
    unsigned int zT_608;
    unsigned int zT_610;
    zT_ABC1EBBE_TypeResolveEnv zT_614;
    zT_6B0A7D14_AstStore* zT_615;
    zT_338B7C76_TypeRegistry* zT_616;
    zT_3D7259E2_SymbolRegistry* zT_617;
    zT_D3EB6303_StringInterner* zT_618;
    unsigned int zT_619;
    zT_ABC1EBBE_TypeResolveEnv* zT_621;
    unsigned int zT_622;
    unsigned int* zT_625;
    unsigned int zT_626;
    unsigned int zT_629 = 0;
    zT_38C12417_SemanticAnalyzer* zT_632;
    unsigned int zT_633;
    unsigned int* zT_634;
    unsigned int zT_635;
    unsigned int zT_637 = 0;
    zT_338B7C76_TypeRegistry* zT_638;
    unsigned int zT_639;
    unsigned int zT_643 = 0;
    unsigned int zT_644;
    unsigned int zT_645;
    unsigned int zT_649;
    unsigned int zT_651;
    zT_ABC1EBBE_TypeResolveEnv zT_655;
    zT_6B0A7D14_AstStore* zT_656;
    zT_338B7C76_TypeRegistry* zT_657;
    zT_3D7259E2_SymbolRegistry* zT_658;
    zT_D3EB6303_StringInterner* zT_659;
    unsigned int zT_660;
    zT_ABC1EBBE_TypeResolveEnv* zT_662;
    unsigned int zT_663;
    unsigned int* zT_666;
    unsigned int zT_667;
    unsigned int zT_670 = 0;
    zT_38C12417_SemanticAnalyzer* zT_674;
    unsigned int zT_675;
    unsigned int* zT_676;
    unsigned int zT_677;
    unsigned int zT_679 = 0;
    unsigned char zT_681;
    int zT_684;
    zT_338B7C76_TypeRegistry* zT_685;
    unsigned int zT_686;
    int zT_688 = 0;
    int zT_689;
    zT_338B7C76_TypeRegistry* zT_690;
    unsigned int zT_691;
    int zT_693 = 0;
    zT_338B7C76_TypeRegistry* zT_695;
    zT_D155D06D_Type* zT_696;
    unsigned int zT_697;
    zT_D155D06D_Type zT_698;
    zT_338B7C76_TypeRegistry* zT_700;
    zT_D155D06D_Type* zT_701;
    unsigned int zT_702;
    zT_D155D06D_Type zT_703;
    unsigned char zT_704;
    int zT_707;
    unsigned char zT_708;
    int zT_711;
    unsigned int zT_712;
    unsigned int zT_713;
    unsigned char zT_715;
    char* zT_719;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_720;
    unsigned int zT_721;
    zT_F85C5DED_DiagnosticCollector* zT_722;
    unsigned int zT_725;
    unsigned int zT_726;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_728;
    unsigned int zT_737;
    unsigned int zT_738;
    unsigned int zT_741 = 0;
    unsigned int zT_742;
    unsigned int zT_743;
    unsigned int zT_745;
    unsigned int zT_746;
    unsigned int zT_747;
    unsigned int zT_750;
    zT_38C12417_SemanticAnalyzer* zT_753;
    unsigned int zT_754;
    unsigned int* zT_755;
    unsigned int zT_756;
    unsigned int zT_758 = 0;
    unsigned int zT_759;
    unsigned int zT_760;
    unsigned int zT_761;
    unsigned int zT_764;
    zT_38C12417_SemanticAnalyzer* zT_767;
    unsigned int zT_768;
    unsigned int* zT_769;
    unsigned int zT_770;
    unsigned int zT_772 = 0;
    unsigned int zT_773;
    unsigned int zT_774;
    unsigned int zT_775;
    int zT_777;
    unsigned int zT_778;
    unsigned int zT_779;
    unsigned int zT_782;
    zT_38C12417_SemanticAnalyzer* zT_785;
    unsigned int zT_786;
    unsigned int* zT_787;
    unsigned int zT_788;
    unsigned int zT_790 = 0;
    unsigned int zT_791;
    unsigned int zT_792;
    unsigned int zT_793;
    int zT_795;
    unsigned int zT_796;
    unsigned int zT_797;
    unsigned int zT_800;
    zT_38C12417_SemanticAnalyzer* zT_803;
    unsigned int zT_804;
    unsigned int* zT_805;
    unsigned int zT_806;
    unsigned int zT_808 = 0;
    zT_38C12417_SemanticAnalyzer* zT_809;
    unsigned int zT_810;
    unsigned int* zT_811;
    unsigned int zT_812;
    unsigned int zT_814 = 0;
    unsigned int zT_816;
    zT_38C12417_SemanticAnalyzer* zT_819;
    unsigned int zT_820;
    unsigned int* zT_821;
    unsigned int zT_822;
    unsigned int zT_824 = 0;
    unsigned int zT_825;
    unsigned int zT_826;
    unsigned int zT_827;
    unsigned int zT_829;
    unsigned int zT_830;
    unsigned int zT_831;
    unsigned int zT_833;
    unsigned int zT_834;
    unsigned int zT_835;
    int zT_837;
    unsigned int zT_838;
    unsigned int zT_839;
    unsigned int zT_842;
    zT_38C12417_SemanticAnalyzer* zT_845;
    unsigned int zT_846;
    unsigned int* zT_847;
    unsigned int zT_848;
    unsigned int zT_850 = 0;
    zT_38C12417_SemanticAnalyzer* zT_851;
    unsigned int zT_852;
    unsigned int* zT_853;
    unsigned int zT_854;
    unsigned int zT_856 = 0;
    unsigned int zT_858;
    zT_38C12417_SemanticAnalyzer* zT_861;
    unsigned int zT_862;
    unsigned int* zT_863;
    unsigned int zT_864;
    unsigned int zT_866 = 0;
    unsigned int zT_867;
    unsigned int zT_868;
    unsigned int zT_869;
    unsigned int zT_872;
    zT_38C12417_SemanticAnalyzer* zT_875;
    unsigned int zT_876;
    unsigned int* zT_877;
    unsigned int zT_878;
    unsigned int zT_880 = 0;
    int zT_882;
    zT_6B0A7D14_AstStore* zT_883;
    zT_3D7259E2_SymbolRegistry* zT_884;
    unsigned int zT_885;
    unsigned int zT_886;
    unsigned int* zT_890;
    unsigned int zT_891;
    zT_BBEE1AC1_Opt_11 zT_893 = {0};
    unsigned char zT_894;
    unsigned int zT_899;
    unsigned int zT_903;
    zT_A4CE86B7_U64ToU32Map* zT_904;
    unsigned int zT_905;
    unsigned int zT_906;
    int zT_908 = 0;
    int zT_909;
    char* zT_912;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_913;
    unsigned int zT_914;
    zT_F85C5DED_DiagnosticCollector* zT_915;
    unsigned int zT_918;
    unsigned int zT_919;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_921;
    unsigned int zT_930;
    unsigned int zT_931;
    unsigned int zT_934 = 0;
    unsigned int zT_935;
    unsigned int zT_936;
    unsigned int zT_937;
    unsigned int zT_940;
    zT_38C12417_SemanticAnalyzer* zT_943;
    unsigned int zT_944;
    unsigned int* zT_945;
    unsigned int zT_946;
    unsigned int zT_948 = 0;
    zT_38C12417_SemanticAnalyzer* zT_949;
    unsigned int zT_950;
    unsigned int* zT_951;
    unsigned int zT_952;
    unsigned int zT_954 = 0;
    zT_38C12417_SemanticAnalyzer* zT_955;
    unsigned int zT_956;
    unsigned int* zT_957;
    unsigned int zT_958;
    unsigned int zT_960 = 0;
    zT_38C12417_SemanticAnalyzer* zT_961;
    unsigned int zT_962;
    unsigned int* zT_963;
    unsigned int zT_964;
    unsigned int zT_966 = 0;
    zT_38C12417_SemanticAnalyzer* zT_967;
    unsigned int zT_968;
    zT_338B7C76_TypeRegistry* zT_969;
    unsigned int zT_975 = 0;
    unsigned int zT_976;
    unsigned int zT_977;
    unsigned int zT_980;
    zT_38C12417_SemanticAnalyzer* zT_983;
    unsigned int zT_984;
    unsigned int* zT_985;
    unsigned int zT_986;
    unsigned int zT_988 = 0;
    zT_38C12417_SemanticAnalyzer* zT_989;
    unsigned int zT_990;
    unsigned int* zT_991;
    unsigned int zT_992;
    unsigned int zT_994 = 0;
    zT_38C12417_SemanticAnalyzer* zT_995;
    unsigned int zT_996;
    zT_338B7C76_TypeRegistry* zT_997;
    unsigned int zT_998;
    zT_338B7C76_TypeRegistry* zT_1000;
    unsigned int zT_1006 = 0;
    unsigned int zT_1007 = 0;
    unsigned int zT_1008;
    unsigned int zT_1009;
    unsigned int zT_1012;
    zT_38C12417_SemanticAnalyzer* zT_1015;
    unsigned int zT_1016;
    unsigned int* zT_1017;
    unsigned int zT_1018;
    unsigned int zT_1020 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1021;
    unsigned int zT_1022;
    zT_38C12417_SemanticAnalyzer* zT_1023;
    unsigned int zT_1024;
    zT_338B7C76_TypeRegistry* zT_1025;
    unsigned int zT_1031 = 0;
    unsigned int zT_1032;
    unsigned int zT_1033;
    int zT_1035;
    unsigned int zT_1037;
    char* zT_1041;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1042;
    unsigned int zT_1043;
    zT_F85C5DED_DiagnosticCollector* zT_1044;
    unsigned int zT_1047;
    unsigned int zT_1048;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1050;
    unsigned int zT_1059;
    unsigned int zT_1060;
    unsigned int zT_1063 = 0;
    unsigned int zT_1065;
    zT_38C12417_SemanticAnalyzer* zT_1068;
    unsigned int zT_1069;
    unsigned int* zT_1070;
    unsigned int zT_1071;
    unsigned int zT_1073 = 0;
    unsigned int zT_1074;
    unsigned int zT_1076;
    zT_38C12417_SemanticAnalyzer* zT_1079;
    unsigned int zT_1080;
    int zT_1082 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1084;
    unsigned int zT_1085;
    unsigned int* zT_1086;
    unsigned int zT_1087;
    unsigned int zT_1089 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_1091;
    zT_6B0A7D14_AstStore* zT_1092;
    zT_338B7C76_TypeRegistry* zT_1093;
    zT_3D7259E2_SymbolRegistry* zT_1094;
    zT_D3EB6303_StringInterner* zT_1095;
    unsigned int zT_1096;
    zT_ABC1EBBE_TypeResolveEnv* zT_1097;
    unsigned int zT_1098;
    unsigned int* zT_1101;
    unsigned int zT_1102;
    unsigned int zT_1105 = 0;
    unsigned int zT_1106;
    unsigned int zT_1107;
    int zT_1109;
    int zT_1112;
    zT_38C12417_SemanticAnalyzer* zT_1115;
    unsigned int zT_1116;
    unsigned int zT_1117;
    int zT_1118 = 0;
    char* zT_1120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1121;
    unsigned int zT_1122;
    zT_F85C5DED_DiagnosticCollector* zT_1123;
    unsigned int zT_1126;
    unsigned int zT_1127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1129;
    unsigned int zT_1135;
    unsigned int zT_1136;
    unsigned int zT_1139 = 0;
    unsigned int zT_1140;
    unsigned int zT_1141;
    int zT_1143;
    int zT_1146;
    zT_38C12417_SemanticAnalyzer* zT_1149;
    unsigned int zT_1150;
    unsigned int zT_1151;
    int zT_1152 = 0;
    char* zT_1155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1156;
    unsigned int zT_1157;
    zT_F85C5DED_DiagnosticCollector* zT_1158;
    unsigned int zT_1161;
    unsigned int zT_1162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1164;
    unsigned int zT_1170;
    unsigned int zT_1171;
    unsigned int zT_1174 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1175;
    unsigned int zT_1176;
    unsigned int* zT_1177;
    int zT_1178;
    unsigned int zT_1180 = 0;
    unsigned int zT_1181;
    unsigned int zT_1182;
    int zT_1184;
    unsigned int zT_1186;
    zT_38C12417_SemanticAnalyzer* zT_1190;
    unsigned int zT_1191;
    unsigned int* zT_1192;
    unsigned int zT_1193;
    unsigned int zT_1195 = 0;
    zT_338B7C76_TypeRegistry* zT_1200;
    zT_D155D06D_Type* zT_1201;
    unsigned int zT_1202;
    zT_D155D06D_Type zT_1203;
    zT_33EF6BFB_TypeKind zT_1204;
    zT_338B7C76_TypeRegistry* zT_1210;
    unsigned int zT_1211;
    unsigned int zT_1213 = 0;
    int zT_1216;
    zT_338B7C76_TypeRegistry* zT_1218;
    unsigned int zT_1219;
    zT_338B7C76_TypeRegistry* zT_1221;
    unsigned int zT_1222;
    int zT_1224 = 0;
    int zT_1225;
    zT_338B7C76_TypeRegistry* zT_1226;
    unsigned int zT_1227;
    int zT_1229 = 0;
    unsigned int zT_1231;
    zT_38C12417_SemanticAnalyzer* zT_1234;
    unsigned int zT_1235;
    unsigned int* zT_1236;
    int zT_1237;
    unsigned int zT_1239 = 0;
    unsigned int zT_1240;
    zT_8143F551_AstKind zT_1241;
    zT_38C12417_SemanticAnalyzer* zT_1246;
    unsigned int zT_1247;
    unsigned int zT_1249 = 0;
    unsigned int zT_1250;
    zT_8143F551_AstKind zT_1251;
    int zT_1256;
    zT_8143F551_AstKind zT_1257;
    zT_38C12417_SemanticAnalyzer* zT_1262;
    unsigned int zT_1263;
    unsigned int zT_1264 = 0;
    zT_8143F551_AstKind zT_1265;
    zT_38C12417_SemanticAnalyzer* zT_1270;
    unsigned int zT_1271;
    unsigned int zT_1272 = 0;
    zT_8143F551_AstKind zT_1273;
    zT_38C12417_SemanticAnalyzer* zT_1278;
    unsigned int zT_1279;
    unsigned int zT_1280 = 0;
    zT_8143F551_AstKind zT_1281;
    int zT_1287;
    unsigned int zT_1288;
    zT_38C12417_SemanticAnalyzer* zT_1289;
    unsigned int zT_1290;
    unsigned int zT_1292 = 0;
    zT_338B7C76_TypeRegistry* zT_1296;
    zT_D155D06D_Type* zT_1297;
    unsigned int zT_1298;
    zT_D155D06D_Type zT_1299;
    zT_33EF6BFB_TypeKind zT_1300;
    zT_338B7C76_TypeRegistry* zT_1305;
    zT_42C2D6BF_EUPayload* zT_1306;
    unsigned int zT_1307;
    unsigned int zT_1308;
    zT_42C2D6BF_EUPayload zT_1309;
    unsigned int zT_1310;
    zT_338B7C76_TypeRegistry* zT_1311;
    zT_42C2D6BF_EUPayload* zT_1312;
    unsigned int zT_1313;
    unsigned int zT_1314;
    zT_42C2D6BF_EUPayload zT_1315;
    unsigned int zT_1316;
    zT_66E7D2EF_CoercionTable* zT_1317;
    unsigned int zT_1318;
    unsigned int zT_1320;
    unsigned int zT_1326;
    int zT_1327;
    zT_6B0A7D14_AstStore* zT_1330;
    unsigned int zT_1331;
    unsigned int zT_1335;
    unsigned int zT_1336;
    zT_38C12417_SemanticAnalyzer* zT_1338;
    zT_6B0A7D14_AstStore* zT_1339;
    unsigned int zT_1340;
    unsigned int zT_1343 = 0;
    unsigned int* zT_1344;
    unsigned int zT_1345;
    int zT_1346;
    unsigned int zT_1348;
    unsigned int* zT_1350;
    unsigned int zT_1351;
    unsigned int zT_1352;
    unsigned int zT_1355;
    int zT_1358;
    zT_6B0A7D14_AstStore* zT_1361;
    unsigned int zT_1362;
    zT_22A7C88B_AstNode zT_1365 = {0};
    zT_8143F551_AstKind zT_1366;
    zT_38C12417_SemanticAnalyzer* zT_1371;
    unsigned int zT_1372;
    zT_38C12417_SemanticAnalyzer* zT_1373;
    unsigned int zT_1374;
    unsigned int zT_1376 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1377;
    zT_38C12417_SemanticAnalyzer* zT_1378;
    unsigned int zT_1379;
    zT_8143F551_AstKind zT_1381;
    zT_38C12417_SemanticAnalyzer* zT_1386;
    unsigned int zT_1387;
    unsigned int zT_1388 = 0;
    zT_8143F551_AstKind zT_1389;
    int zT_1394;
    zT_8143F551_AstKind zT_1395;
    unsigned int zT_1400;
    zT_8143F551_AstKind zT_1401;
    int zT_1406;
    zT_8143F551_AstKind zT_1407;
    int zT_1412;
    zT_8143F551_AstKind zT_1413;
    int zT_1418;
    zT_8143F551_AstKind zT_1419;
    zT_38C12417_SemanticAnalyzer* zT_1424;
    unsigned int zT_1425;
    unsigned int zT_1426;
    zT_8143F551_AstKind zT_1427;
    zT_38C12417_SemanticAnalyzer* zT_1432;
    unsigned int zT_1433;
    unsigned int zT_1434 = 0;
    zT_8143F551_AstKind zT_1435;
    zT_38C12417_SemanticAnalyzer* zT_1440;
    unsigned int zT_1441;
    unsigned int zT_1442;
    zT_38C12417_SemanticAnalyzer* zT_1445;
    unsigned int zT_1446;
    unsigned int zT_1448;
    zT_38C12417_SemanticAnalyzer* zT_1451;
    unsigned int zT_1452;
    unsigned int zT_1454;
    zT_8143F551_AstKind zT_1455;
    zT_38C12417_SemanticAnalyzer* zT_1460;
    unsigned int zT_1461;
    unsigned int zT_1462;
    int zT_1463;
    zT_38C12417_SemanticAnalyzer* zT_1465;
    unsigned int zT_1466;
    unsigned int zT_1468;
    zT_8143F551_AstKind zT_1469;
    zT_38C12417_SemanticAnalyzer* zT_1474;
    unsigned int zT_1475;
    unsigned int zT_1476;
    int zT_1477;
    zT_38C12417_SemanticAnalyzer* zT_1479;
    unsigned int zT_1480;
    unsigned int zT_1482;
    zT_8143F551_AstKind zT_1483;
    zT_38C12417_SemanticAnalyzer* zT_1488;
    unsigned int zT_1489;
    unsigned int zT_1490 = 0;
    zT_8143F551_AstKind zT_1491;
    zT_38C12417_SemanticAnalyzer* zT_1496;
    unsigned int zT_1497;
    unsigned int zT_1498 = 0;
    zT_8143F551_AstKind zT_1499;
    zT_38C12417_SemanticAnalyzer* zT_1504;
    unsigned int zT_1505;
    unsigned int zT_1506 = 0;
    zT_8143F551_AstKind zT_1507;
    char* zT_1513;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1514;
    unsigned int zT_1515;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1516;
    unsigned int zT_1517;
    zT_38C12417_SemanticAnalyzer* zT_1518;
    unsigned int zT_1519;
    unsigned int zT_1520 = 0;
    zT_8143F551_AstKind zT_1521;
    int zT_1526;
    zT_8143F551_AstKind zT_1527;
    int zT_1532;
    zT_8143F551_AstKind zT_1533;
    int zT_1538;
    zT_8143F551_AstKind zT_1539;
    int zT_1544;
    zT_8143F551_AstKind zT_1545;
    int zT_1550;
    zT_8143F551_AstKind zT_1551;
    int zT_1556;
    zT_8143F551_AstKind zT_1557;
    int zT_1562;
    zT_8143F551_AstKind zT_1563;
    int zT_1568;
    zT_8143F551_AstKind zT_1569;
    int zT_1574;
    zT_8143F551_AstKind zT_1575;
    int zT_1580;
    zT_8143F551_AstKind zT_1581;
    zT_8143F551_AstKind zT_1586;
    zT_38C12417_SemanticAnalyzer* zT_1591;
    unsigned int zT_1592;
    unsigned int zT_1593;
    unsigned int zT_1595;
    zT_8143F551_AstKind zT_1596;
    zT_38C12417_SemanticAnalyzer* zT_1601;
    unsigned int zT_1602;
    unsigned int zT_1604 = 0;
    zT_8143F551_AstKind zT_1605;
    zT_38C12417_SemanticAnalyzer* zT_1610;
    unsigned int zT_1611;
    unsigned int zT_1612;
    zT_8143F551_AstKind zT_1613;
    zT_38C12417_SemanticAnalyzer* zT_1618;
    unsigned int zT_1619;
    unsigned int zT_1621 = 0;
    zT_8143F551_AstKind zT_1622;
    unsigned int zT_1627;
    zT_8143F551_AstKind zT_1628;
    char* zT_1634;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1635;
    unsigned int zT_1636;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1637;
    unsigned int zT_1638;
    zT_6B0A7D14_AstStore* zT_1640;
    unsigned int zT_1641;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1643 = {0};
    char* zT_1645;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1646;
    unsigned int zT_1647;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1648;
    unsigned int zT_1651;
    unsigned int zT_1654;
    int zT_1658;
    unsigned int zT_1659;
    unsigned int zT_1661;
    char* zT_1666;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1667;
    unsigned int zT_1668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1669;
    char* zT_1673;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1674;
    unsigned int zT_1675;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1676;
    unsigned int zT_1677;
    unsigned int* zT_1678;
    zT_38C12417_SemanticAnalyzer* zT_1680;
    unsigned int zT_1681;
    unsigned int* zT_1682;
    int zT_1684;
    unsigned int zT_1685;
    unsigned int* zT_1687;
    unsigned int zT_1689;
    unsigned int zT_1691;
    unsigned int zT_1692;
    zT_38C12417_SemanticAnalyzer* zT_1693;
    unsigned int zT_1694;
    unsigned int zT_1695 = 0;
    unsigned int zT_1696;
    zT_8143F551_AstKind zT_1697;
    int zT_1702;
    zT_8143F551_AstKind zT_1703;
    int zT_1708;
    zT_8143F551_AstKind zT_1709;
    int zT_1714;
    zT_8143F551_AstKind zT_1715;
    int zT_1720;
    zT_8143F551_AstKind zT_1721;
    int zT_1726;
    zT_8143F551_AstKind zT_1727;
    int zT_1732;
    zT_8143F551_AstKind zT_1733;
    int zT_1738;
    zT_8143F551_AstKind zT_1739;
    int zT_1744;
    zT_8143F551_AstKind zT_1745;
    int zT_1750;
    zT_8143F551_AstKind zT_1751;
    int zT_1756;
    zT_8143F551_AstKind zT_1757;
    zT_38C12417_SemanticAnalyzer* zT_1762;
    unsigned int zT_1763;
    zT_8143F551_AstKind zT_1764;
    unsigned int zT_1766 = 0;
    zT_8143F551_AstKind zT_1767;
    int zT_1772;
    zT_8143F551_AstKind zT_1773;
    int zT_1778;
    zT_8143F551_AstKind zT_1779;
    int zT_1784;
    zT_8143F551_AstKind zT_1785;
    int zT_1790;
    zT_8143F551_AstKind zT_1791;
    int zT_1796;
    zT_8143F551_AstKind zT_1797;
    zT_38C12417_SemanticAnalyzer* zT_1802;
    unsigned int zT_1803;
    unsigned int zT_1804 = 0;
    zT_8143F551_AstKind zT_1805;
    int zT_1810;
    zT_8143F551_AstKind zT_1811;
    zT_38C12417_SemanticAnalyzer* zT_1816;
    unsigned int zT_1817;
    unsigned int zT_1818 = 0;
    zT_8143F551_AstKind zT_1819;
    int zT_1824;
    zT_8143F551_AstKind zT_1825;
    int zT_1830;
    zT_8143F551_AstKind zT_1831;
    int zT_1836;
    zT_8143F551_AstKind zT_1837;
    int zT_1842;
    zT_8143F551_AstKind zT_1843;
    int zT_1848;
    zT_8143F551_AstKind zT_1849;
    zT_38C12417_SemanticAnalyzer* zT_1854;
    unsigned int zT_1855;
    zT_8143F551_AstKind zT_1856;
    unsigned int zT_1858 = 0;
    zT_8143F551_AstKind zT_1859;
    int zT_1864;
    zT_8143F551_AstKind zT_1865;
    int zT_1870;
    zT_8143F551_AstKind zT_1871;
    int zT_1876;
    zT_8143F551_AstKind zT_1877;
    int zT_1882;
    zT_8143F551_AstKind zT_1883;
    int zT_1888;
    zT_8143F551_AstKind zT_1889;
    int zT_1894;
    zT_8143F551_AstKind zT_1895;
    int zT_1900;
    zT_8143F551_AstKind zT_1901;
    int zT_1906;
    zT_8143F551_AstKind zT_1907;
    int zT_1912;
    zT_8143F551_AstKind zT_1913;
    int zT_1918;
    zT_8143F551_AstKind zT_1919;
    int zT_1924;
    zT_8143F551_AstKind zT_1925;
    int zT_1930;
    zT_8143F551_AstKind zT_1931;
    int zT_1936;
    zT_8143F551_AstKind zT_1937;
    int zT_1942;
    zT_8143F551_AstKind zT_1943;
    int zT_1948;
    zT_8143F551_AstKind zT_1949;
    int zT_1954;
    zT_8143F551_AstKind zT_1955;
    int zT_1960;
    zT_8143F551_AstKind zT_1961;
    zT_38C12417_SemanticAnalyzer* zT_1966;
    unsigned int zT_1967;
    unsigned int zT_1968 = 0;
    zT_8143F551_AstKind zT_1969;
    int zT_1974;
    zT_8143F551_AstKind zT_1975;
    zT_8EED1867_ResolvedTypeTable* zT_1980;
    unsigned int zT_1981;
    char* zT_1987;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1988;
    unsigned int zT_1989;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1990;
    unsigned int zT_1991;
    zT_8143F551_AstKind zT_1993;
    unsigned int zT_1994;
    char* zT_1996;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1997;
    unsigned int zT_1998;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1999;
    unsigned int zT_2000;
    char* zT_2002;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2003;
    unsigned int zT_2004;
    zT_F85C5DED_DiagnosticCollector* zT_2005;
    unsigned int zT_2008;
    unsigned int zT_2009;
    unsigned int zT_2010;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2011;
    unsigned int zT_2016 = 0;
    char* zT_2019;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2020;
    unsigned int zT_2021;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2022;
    unsigned int zT_2023;
    zT_8143F551_AstKind zT_2025;
    unsigned int zT_2026;
    char* zT_2028;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2029;
    unsigned int zT_2030;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2031;
    unsigned int zT_2032;
    char* zT_2034;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2035;
    unsigned int zT_2036;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2037;
    unsigned int zT_2038;
    char* zT_2040;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2041;
    unsigned int zT_2042;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2043;
    unsigned int zT_2044;
    zT_8143F551_AstKind zT_2046;
    unsigned int zT_2047;
    char* zT_2049;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2050;
    unsigned int zT_2051;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2052;
    unsigned int zT_2053;
    char* zT_2055;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2056;
    unsigned int zT_2057;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2058;
    unsigned int zT_2059;
    zT_8EED1867_ResolvedTypeTable* zT_2060;
    unsigned int zT_2061;
    unsigned int zT_2062;
    char* zT_2065;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2066;
    unsigned int zT_2067;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2068;
    unsigned int zT_2069;
    char* zT_2071;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2072;
    unsigned int zT_2073;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2074;
    unsigned int zT_2075;
    unsigned int result;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rx_sw_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rxs_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_m;
    unsigned int stx_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_nm;
    unsigned int a4_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_rm;
    unsigned int top;
    unsigned int es;
    zT_D155D06D_Type tty;
    unsigned int eff_top;
    unsigned int opt_pay;
    unsigned int name_id;
    unsigned int ord;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u fad;
    unsigned int base;
    zT_D155D06D_Type bt;
    zT_112BF819_PtrPayload pp;
    zT_22A7C88B_AstNode base_node;
    unsigned int fa_base_t;
    unsigned int st;
    zT_D155D06D_Type st_ty;
    unsigned int sd;
    unsigned int aps;
    unsigned int ape;
    zT_8F083A69_Slice_zT_0B42B2F8_u aof_msg;
    unsigned int apu_s;
    unsigned int apu_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u aou_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ub_msg;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    zT_ABC1EBBE_TypeResolveEnv so_env;
    unsigned int pfi_res;
    unsigned int pfi_top;
    zT_D155D06D_Type pfi_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_msg;
    unsigned int fpp_res;
    zT_ABC1EBBE_TypeResolveEnv fpp_env;
    unsigned int fpp_outer;
    unsigned int bc_res;
    zT_ABC1EBBE_TypeResolveEnv bc_env;
    unsigned int bc_dst;
    unsigned int bc_src;
    unsigned char bc_ok;
    zT_D155D06D_Type bc_dty;
    zT_D155D06D_Type bc_sty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_msg;
    int afs_susp;
    zT_79FAE712_u64 afs_k;
    unsigned int afs_mid;
    unsigned int afs_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u e3046;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc3049;
    unsigned int tv_src;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcq_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcc_msg;
    unsigned int e2i_arg;
    unsigned int e2i_res;
    zT_D155D06D_Type e2i_ty;
    unsigned int e2i_bt;
    unsigned int catch_es;
    zT_D155D06D_Type clt;
    zT_22A7C88B_AstNode child1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ai_dbg;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_m;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm2;
    unsigned int last_child;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_m;
    unsigned int st_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u unr_msg;
    zT_3 = 0;
    result = zT_3;
    zT_4 = 0;
    result = zT_4;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return result;
    z_bb_2:
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_12 = 1;
    result = zT_12;
    zT_13 = node.kind;
    if ((int)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = "RXS";
    zT_21 = 3;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    rx_sw_m = zT_20;
    zT_22 = rx_sw_m;
    zF_48AC7B3A_markerWrite(zT_22);
    zT_24 = "RXS:n";
    zT_26 = 5;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    rxs_nm = zT_25;
    zT_27 = rxs_nm;
    zT_28 = node_idx;
    zF_C914CB83_markerWriteInt(zT_27, zT_28);
    goto z_bb_4;
    z_bb_4:
    zT_29 = node.kind;
    if ((int)(zT_29 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_34 = 19;
    result = zT_34;
    goto z_bb_6;
    z_bb_6:
    zT_2019 = "STX:n";
    zT_2021 = 5;
    zT_2020.ptr = zT_2019;
    zT_2020.len = zT_2021;
    stx_m = zT_2020;
    zT_2022 = stx_m;
    zT_2023 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2022, zT_2023);
    zT_2025 = node.kind;
    zT_2026 = (unsigned int)zT_2025;
    stx_kv = zT_2026;
    zT_2028 = "STX:k";
    zT_2030 = 5;
    zT_2029.ptr = zT_2028;
    zT_2029.len = zT_2030;
    stx_km = zT_2029;
    zT_2031 = stx_km;
    zT_2032 = stx_kv;
    zF_C914CB83_markerWriteInt(zT_2031, zT_2032);
    zT_2034 = "STX:r";
    zT_2036 = 5;
    zT_2035.ptr = zT_2034;
    zT_2035.len = zT_2036;
    stx_rm = zT_2035;
    zT_2037 = stx_rm;
    zT_2038 = result;
    zF_C914CB83_markerWriteInt(zT_2037, zT_2038);
    zT_2040 = "A4:N";
    zT_2042 = 4;
    zT_2041.ptr = zT_2040;
    zT_2041.len = zT_2042;
    a4_nm = zT_2041;
    zT_2043 = a4_nm;
    zT_2044 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2043, zT_2044);
    zT_2046 = node.kind;
    zT_2047 = (unsigned int)zT_2046;
    a4_kv = zT_2047;
    zT_2049 = "A4:K";
    zT_2051 = 4;
    zT_2050.ptr = zT_2049;
    zT_2050.len = zT_2051;
    a4_km = zT_2050;
    zT_2052 = a4_km;
    zT_2053 = a4_kv;
    zF_C914CB83_markerWriteInt(zT_2052, zT_2053);
    zT_2055 = "A4:R";
    zT_2057 = 4;
    zT_2056.ptr = zT_2055;
    zT_2056.len = zT_2057;
    a4_rm = zT_2056;
    zT_2058 = a4_rm;
    zT_2059 = result;
    zF_C914CB83_markerWriteInt(zT_2058, zT_2059);
    zT_2060 = self->type_table;
    zT_2061 = node_idx;
    zT_2062 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_2060, zT_2061, zT_2062);
    zT_2065 = "STB:N";
    zT_2067 = 5;
    zT_2066.ptr = zT_2065;
    zT_2066.len = zT_2067;
    stb_nm = zT_2066;
    zT_2068 = stb_nm;
    zT_2069 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2068, zT_2069);
    zT_2071 = "STB:R";
    zT_2073 = 5;
    zT_2072.ptr = zT_2071;
    zT_2072.len = zT_2073;
    stb_rm = zT_2072;
    zT_2074 = stb_rm;
    zT_2075 = result;
    zF_C914CB83_markerWriteInt(zT_2074, zT_2075);
    return result;
    z_bb_7:
    zT_35 = node.kind;
    if ((int)(zT_35 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_40 = 16;
    result = zT_40;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_41 = node.kind;
    if ((int)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_46 = 8;
    result = zT_46;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_47 = node.kind;
    if ((int)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_52 = 2;
    result = zT_52;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_53 = node.kind;
    if ((int)(zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_58 = 17;
    result = zT_58;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_59 = node.kind;
    if ((int)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_64 = 18;
    result = zT_64;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_65 = node.kind;
    if ((int)(zT_65 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_unreachable_expr))) goto z_bb_23; else goto z_bb_25;
    z_bb_23:
    zT_70 = 3;
    result = zT_70;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_71 = node.kind;
    if ((int)(zT_71 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_76 = self->registry;
    zT_82 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_76, (unsigned int)(14), (int)(1));
    result = zT_82;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_83 = node.kind;
    if ((int)(zT_83 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    zT_88 = self;
    zT_89 = node_idx;
    zT_90 = zF_8C008E53_semanticAnalyzerRes(zT_88, zT_89);
    result = zT_90;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_91 = node.kind;
    if ((int)(zT_91 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_96 = self->expected_type_stack_len;
    zT_97 = 0;
    if ((int)(zT_96 > (unsigned int)zT_97)) goto z_bb_35; else goto z_bb_37;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_214 = node.kind;
    if ((int)(zT_214 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_57; else goto z_bb_59;
    z_bb_35:
    zT_100 = self->expected_type_stack_items;
    zT_101 = self->expected_type_stack_len;
    zT_102 = 1;
    zT_103 = zT_101 - zT_102;
    zT_104 = zT_100[zT_103];
    top = zT_104;
    zT_105 = 0;
    if ((int)(top != (unsigned int)zT_105)) goto z_bb_38; else goto z_bb_40;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_213 = 1;
    result = zT_213;
    goto z_bb_36;
    z_bb_38:
    zT_108 = 0;
    zT_109 = (unsigned int)zT_108;
    es = zT_109;
    zT_111 = self->registry;
    zT_112 = zT_111->types_items;
    zT_113 = (unsigned int)top;
    zT_114 = zT_112[zT_113];
    tty = zT_114;
    eff_top = top;
    zT_116 = tty.kind;
    if ((int)(zT_116 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_212 = 1;
    result = zT_212;
    goto z_bb_39;
    z_bb_41:
    zT_122 = self->registry;
    zT_123 = zT_122->opt_items;
    zT_124 = tty.payload_idx;
    zT_125 = (unsigned int)zT_124;
    zT_126 = zT_123[zT_125];
    zT_127 = zT_126.payload;
    opt_pay = zT_127;
    zT_128 = self->registry;
    zT_129 = zT_128->types_items;
    zT_130 = (unsigned int)opt_pay;
    zT_131 = zT_129[zT_130];
    tty = zT_131;
    eff_top = opt_pay;
    goto z_bb_42;
    z_bb_42:
    zT_132 = tty.kind;
    if ((int)(zT_132 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_43; else goto z_bb_45;
    z_bb_43:
    es = eff_top;
    goto z_bb_44;
    z_bb_44:
    zT_148 = 0;
    if ((int)(es != (unsigned int)zT_148)) goto z_bb_48; else goto z_bb_50;
    z_bb_45:
    zT_137 = tty.kind;
    if ((int)(zT_137 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_142 = self->registry;
    zT_143 = zT_142->eu_items;
    zT_144 = tty.payload_idx;
    zT_145 = (unsigned int)zT_144;
    zT_146 = zT_143[zT_145];
    zT_147 = zT_146.error_set;
    es = zT_147;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_151 = self->store;
    zT_152 = node_idx;
    zT_154 = zF_8BA26B9E_astStoreNodePayload(zT_151, zT_152);
    name_id = zT_154;
    zT_156 = self->registry;
    zT_157 = es;
    zT_158 = name_id;
    zT_160 = zF_D2ECD176_typeRegistryErrorSe(zT_156, zT_157, zT_158);
    ord = zT_160;
    if ((int)(ord != (unsigned int)(4294967295u))) goto z_bb_51; else goto z_bb_53;
    z_bb_49:
    goto z_bb_39;
    z_bb_50:
    zT_202 = tty.kind;
    if ((int)(zT_202 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_54; else goto z_bb_56;
    z_bb_51:
    zT_164 = self->error_code_registry;
    zT_165 = name_id;
    zT_167 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_164, zT_165);
    reg_code = zT_167;
    zT_168 = self->enum_value_table;
    zT_169 = node_idx;
    zT_170 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_168, zT_169, zT_170);
    zT_172 = self->type_table;
    zT_173 = node_idx;
    zT_174 = es;
    zF_19B4A07D_resolvedTypeTableSe(zT_172, zT_173, zT_174);
    result = es;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_177 = node.span_start;
    sp = zT_177;
    zT_179 = node.span_len;
    zT_181 = sp + (unsigned int)((unsigned int)zT_179);
    ep = zT_181;
    zT_183 = "error literal not found in error set";
    zT_185 = 36;
    zT_184.ptr = zT_183;
    zT_184.len = zT_185;
    eln_msg = zT_184;
    zT_186 = self->diag;
    zT_189 = self->source_file_id;
    zT_190 = sp;
    zT_191 = ep;
    zT_192 = eln_msg;
    zT_200 = zF_C82559AC_diagnosticCollector(zT_186, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3011_ERROR_LITERAL_NOT_IN_SET)), zT_189, zT_190, zT_191, zT_192);
    (void)zT_200;
    zT_201 = 1;
    result = zT_201;
    goto z_bb_52;
    z_bb_54:
    zT_207 = self->type_table;
    zT_208 = node_idx;
    zT_209 = eff_top;
    zF_19B4A07D_resolvedTypeTableSe(zT_207, zT_208, zT_209);
    result = eff_top;
    goto z_bb_55;
    z_bb_55:
    goto z_bb_49;
    z_bb_56:
    zT_211 = 1;
    result = zT_211;
    goto z_bb_55;
    z_bb_57:
    zT_219 = self;
    zT_220 = self->module_id;
    zT_224 = self->store;
    zT_225 = node_idx;
    zT_227 = zF_53458827_astStoreIdentifier(zT_224, zT_225);
    zT_221 = zT_227;
    zT_222 = node_idx;
    zT_228 = zF_9F1ECA79_semanticAnalyzerRes(zT_219, zT_220, zT_221, zT_222);
    result = zT_228;
    goto z_bb_58;
    z_bb_58:
    goto z_bb_33;
    z_bb_59:
    zT_229 = node.kind;
    if ((int)(zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_60; else goto z_bb_62;
    z_bb_60:
    zT_234 = self;
    zT_235 = node_idx;
    zT_236 = zF_DDD991E1_semanticAnalyzerRes(zT_234, zT_235);
    result = zT_236;
    zT_238 = "FAD:R";
    zT_240 = 5;
    zT_239.ptr = zT_238;
    zT_239.len = zT_240;
    fad = zT_239;
    zT_241 = fad;
    zT_242 = result;
    zF_C914CB83_markerWriteInt(zT_241, zT_242);
    goto z_bb_61;
    z_bb_61:
    goto z_bb_58;
    z_bb_62:
    zT_243 = node.kind;
    if ((int)(zT_243 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_63; else goto z_bb_65;
    z_bb_63:
    zT_248 = self;
    zT_249 = node_idx;
    zT_250 = zF_1926BC05_semanticAnalyzerRes(zT_248, zT_249);
    result = zT_250;
    goto z_bb_64;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_251 = node.kind;
    if ((int)(zT_251 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_66; else goto z_bb_68;
    z_bb_66:
    zT_256 = self;
    zT_257 = node_idx;
    zT_258 = zF_F902E73E_semanticAnalyzerRes(zT_256, zT_257);
    result = zT_258;
    goto z_bb_67;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_259 = node.kind;
    if ((int)(zT_259 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    zT_265 = self;
    zT_266 = node.child_0;
    zT_268 = zF_54F95822_semanticAnalyzerRes(zT_265, zT_266);
    base = zT_268;
    if ((int)(base != (unsigned int)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_70:
    goto z_bb_67;
    z_bb_71:
    zT_298 = node.kind;
    if ((int)(zT_298 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_84; else goto z_bb_86;
    z_bb_72:
    zT_271 = base != (unsigned int)(1);
    goto z_bb_74;
    z_bb_73:
    zT_271 = 0;
    goto z_bb_74;
    z_bb_74:
    if (zT_271) goto z_bb_75; else goto z_bb_77;
    z_bb_75:
    zT_275 = self->registry;
    zT_276 = zT_275->types_items;
    zT_277 = (unsigned int)base;
    zT_278 = zT_276[zT_277];
    bt = zT_278;
    zT_279 = bt.kind;
    if ((int)(zT_279 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_79; else goto z_bb_78;
    z_bb_76:
    goto z_bb_70;
    z_bb_77:
    zT_297 = 1;
    result = zT_297;
    goto z_bb_76;
    z_bb_78:
    zT_285 = bt.kind;
    zT_284 = zT_285 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_80;
    z_bb_79:
    zT_284 = 1;
    goto z_bb_80;
    z_bb_80:
    if (zT_284) goto z_bb_81; else goto z_bb_83;
    z_bb_81:
    zT_291 = self->registry;
    zT_292 = zT_291->ptr_items;
    zT_293 = bt.payload_idx;
    zT_294 = (unsigned int)zT_293;
    zT_295 = zT_292[zT_294];
    pp = zT_295;
    zT_296 = pp.base;
    result = zT_296;
    goto z_bb_82;
    z_bb_82:
    goto z_bb_76;
    z_bb_83:
    result = base;
    goto z_bb_82;
    z_bb_84:
    zT_304 = self;
    zT_305 = node.child_0;
    zT_307 = zF_54F95822_semanticAnalyzerRes(zT_304, zT_305);
    base = zT_307;
    if ((int)(base != (unsigned int)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    goto z_bb_70;
    z_bb_86:
    zT_428 = node.kind;
    if ((int)(zT_428 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_111; else goto z_bb_113;
    z_bb_87:
    zT_310 = base != (unsigned int)(1);
    goto z_bb_89;
    z_bb_88:
    zT_310 = 0;
    goto z_bb_89;
    z_bb_89:
    if (zT_310) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    zT_314 = self->store;
    zT_315 = node.child_0;
    zT_318 = zF_FCDD1D35_astStoreNodeAt(zT_314, zT_315);
    base_node = zT_318;
    zT_319 = base_node.kind;
    if ((int)(zT_319 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_93; else goto z_bb_94;
    z_bb_91:
    goto z_bb_85;
    z_bb_92:
    zT_427 = 1;
    result = zT_427;
    goto z_bb_91;
    z_bb_93:
    zT_325 = self;
    zT_326 = base_node.child_0;
    zT_328 = zF_54F95822_semanticAnalyzerRes(zT_325, zT_326);
    fa_base_t = zT_328;
    st = fa_base_t;
    if ((int)(fa_base_t != (unsigned int)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    zT_421 = self->registry;
    zT_422 = base;
    zT_426 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_421, zT_422, (int)(0));
    result = zT_426;
    goto z_bb_91;
    z_bb_95:
    zT_332 = fa_base_t != (unsigned int)(1);
    goto z_bb_97;
    z_bb_96:
    zT_332 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_332) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_336 = self->registry;
    zT_337 = zT_336->types_items;
    zT_338 = (unsigned int)st;
    zT_339 = zT_337[zT_338];
    st_ty = zT_339;
    zT_340 = st_ty.kind;
    if ((int)(zT_340 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_101; else goto z_bb_100;
    z_bb_99:
    goto z_bb_94;
    z_bb_100:
    zT_346 = st_ty.kind;
    zT_345 = zT_346 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_102;
    z_bb_101:
    zT_345 = 1;
    goto z_bb_102;
    z_bb_102:
    if (zT_345) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_351 = self->registry;
    zT_352 = zT_351->ptr_items;
    zT_353 = st_ty.payload_idx;
    zT_354 = (unsigned int)zT_353;
    zT_355 = zT_352[zT_354];
    zT_356 = zT_355.base;
    st = zT_356;
    zT_357 = self->registry;
    zT_358 = zT_357->types_items;
    zT_359 = (unsigned int)st;
    zT_360 = zT_358[zT_359];
    st_ty = zT_360;
    goto z_bb_104;
    z_bb_104:
    zT_361 = st_ty.kind;
    if ((int)(zT_361 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_367 = self;
    zT_368 = st;
    zT_369 = zF_1BB4D489_semanticAnalyzerPac(zT_367, zT_368);
    sd = zT_369;
    if ((int)(sd != (unsigned int)(0))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_394 = st_ty.kind;
    if ((int)(zT_394 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_109; else goto z_bb_110;
    z_bb_107:
    zT_373 = node.span_start;
    aps = zT_373;
    zT_375 = node.span_len;
    zT_377 = aps + (unsigned int)((unsigned int)zT_375);
    ape = zT_377;
    zT_379 = "cannot take the address of a field of a packed struct; packed fields have no address";
    zT_381 = 84;
    zT_380.ptr = zT_379;
    zT_380.len = zT_381;
    aof_msg = zT_380;
    zT_382 = self->diag;
    zT_385 = self->source_file_id;
    zT_386 = aps;
    zT_387 = ape;
    zT_388 = aof_msg;
    zT_393 = zF_C82559AC_diagnosticCollector(zT_382, (unsigned char)(0), (unsigned short)(3000), zT_385, zT_386, zT_387, zT_388);
    (void)zT_393;
    goto z_bb_108;
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_400 = node.span_start;
    apu_s = zT_400;
    zT_402 = node.span_len;
    zT_404 = apu_s + (unsigned int)((unsigned int)zT_402);
    apu_e = zT_404;
    zT_406 = "cannot take the address of a field of a packed union; packed fields have no address";
    zT_408 = 83;
    zT_407.ptr = zT_406;
    zT_407.len = zT_408;
    aou_msg = zT_407;
    zT_409 = self->diag;
    zT_412 = self->source_file_id;
    zT_413 = apu_s;
    zT_414 = apu_e;
    zT_415 = aou_msg;
    zT_420 = zF_C82559AC_diagnosticCollector(zT_409, (unsigned char)(0), (unsigned short)(3000), zT_412, zT_413, zT_414, zT_415);
    (void)zT_420;
    goto z_bb_110;
    z_bb_110:
    goto z_bb_99;
    z_bb_111:
    zT_433 = self;
    zT_434 = node_idx;
    zT_435 = zF_87E78775_semanticAnalyzerRes(zT_433, zT_434);
    result = zT_435;
    goto z_bb_112;
    z_bb_112:
    goto z_bb_85;
    z_bb_113:
    zT_436 = node.kind;
    if ((int)(zT_436 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_442 = self;
    zT_443 = node.child_0;
    zT_445 = zF_CAF1FD28_semanticAnalyzerIsB(zT_442, zT_443);
    zT_441 = !zT_445;
    goto z_bb_116;
    z_bb_115:
    zT_441 = 0;
    goto z_bb_116;
    z_bb_116:
    if (zT_441) goto z_bb_117; else goto z_bb_119;
    z_bb_117:
    zT_448 = "unsupported builtin function";
    zT_450 = 28;
    zT_449.ptr = zT_448;
    zT_449.len = zT_450;
    ub_msg = zT_449;
    zT_451 = self->diag;
    zT_454 = self->source_file_id;
    zT_455 = node.span_start;
    zT_463 = node.span_start;
    zT_464 = node.span_len;
    zT_457 = ub_msg;
    zT_467 = zF_C82559AC_diagnosticCollector(zT_451, (unsigned char)(0), (unsigned short)(3000), zT_454, zT_455, (unsigned int)(zT_463 + (unsigned int)((unsigned int)zT_464)), zT_457);
    (void)zT_467;
    zT_468 = 1;
    result = zT_468;
    goto z_bb_118;
    z_bb_118:
    goto z_bb_112;
    z_bb_119:
    zT_469 = node.kind;
    if ((int)(zT_469 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_120; else goto z_bb_122;
    z_bb_120:
    zT_475 = self->store;
    zT_476 = node_idx;
    zT_478 = zF_850FDF81_astStoreNodeExtraCh(zT_475, zT_476);
    ec = zT_478;
    zT_479 = node.child_0;
    zT_480 = self->size_of_name_id;
    if ((int)(zT_479 == zT_480)) goto z_bb_124; else goto z_bb_123;
    z_bb_121:
    goto z_bb_118;
    z_bb_122:
    zT_1241 = node.kind;
    if ((int)(zT_1241 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_329; else goto z_bb_331;
    z_bb_123:
    zT_483 = node.child_0;
    zT_484 = self->align_of_name_id;
    zT_482 = zT_483 == zT_484;
    goto z_bb_125;
    z_bb_124:
    zT_482 = 1;
    goto z_bb_125;
    z_bb_125:
    if (zT_482) goto z_bb_127; else goto z_bb_126;
    z_bb_126:
    zT_487 = node.child_0;
    zT_488 = self->offset_of_name_id;
    zT_486 = zT_487 == zT_488;
    goto z_bb_128;
    z_bb_127:
    zT_486 = 1;
    goto z_bb_128;
    z_bb_128:
    if (zT_486) goto z_bb_130; else goto z_bb_129;
    z_bb_129:
    zT_491 = node.child_0;
    zT_492 = self->bit_size_of_name_id;
    zT_490 = zT_491 == zT_492;
    goto z_bb_131;
    z_bb_130:
    zT_490 = 1;
    goto z_bb_131;
    z_bb_131:
    if (zT_490) goto z_bb_133; else goto z_bb_132;
    z_bb_132:
    zT_495 = node.child_0;
    zT_496 = self->bit_offset_of_name_id;
    zT_494 = zT_495 == zT_496;
    goto z_bb_134;
    z_bb_133:
    zT_494 = 1;
    goto z_bb_134;
    z_bb_134:
    if (zT_494) goto z_bb_135; else goto z_bb_137;
    z_bb_135:
    zT_499 = ec.len;
    if ((int)(zT_499 >= (unsigned int)(1))) goto z_bb_138; else goto z_bb_139;
    z_bb_136:
    goto z_bb_121;
    z_bb_137:
    zT_519 = node.child_0;
    zT_520 = self->ptrtoint_name_id;
    if ((int)(zT_519 == zT_520)) goto z_bb_141; else goto z_bb_140;
    z_bb_138:
    zT_504 = self->store;
    zT_503.store = zT_504;
    zT_505 = self->registry;
    zT_503.typereg = zT_505;
    zT_506 = self->symbols;
    zT_503.symbol_reg = zT_506;
    zT_507 = self->interner;
    zT_503.interner = zT_507;
    zT_508 = self->module_id;
    zT_503.module_id = zT_508;
    so_env = zT_503;
    zT_509 = &so_env;
    zT_513 = ec.ptr;
    zT_514 = 0;
    zT_510 = zT_513[zT_514];
    zT_517 = zF_F2107C15_resolveTypeExprFull(zT_509, zT_510, (unsigned int)(0));
    (void)zT_517;
    goto z_bb_139;
    z_bb_139:
    zT_518 = 19;
    result = zT_518;
    goto z_bb_136;
    z_bb_140:
    zT_523 = node.child_0;
    zT_524 = self->int_from_ptr_name_id;
    zT_522 = zT_523 == zT_524;
    goto z_bb_142;
    z_bb_141:
    zT_522 = 1;
    goto z_bb_142;
    z_bb_142:
    if (zT_522) goto z_bb_143; else goto z_bb_145;
    z_bb_143:
    zT_527 = ec.len;
    if ((int)(zT_527 >= (unsigned int)(1))) goto z_bb_146; else goto z_bb_147;
    z_bb_144:
    goto z_bb_136;
    z_bb_145:
    zT_537 = node.child_0;
    zT_538 = self->ptr_from_int_name_id;
    if ((int)(zT_537 == zT_538)) goto z_bb_148; else goto z_bb_150;
    z_bb_146:
    zT_530 = self;
    zT_532 = ec.ptr;
    zT_533 = 0;
    zT_531 = zT_532[zT_533];
    zT_535 = zF_54F95822_semanticAnalyzerRes(zT_530, zT_531);
    (void)zT_535;
    goto z_bb_147;
    z_bb_147:
    zT_536 = 13;
    result = zT_536;
    goto z_bb_144;
    z_bb_148:
    zT_542 = 1;
    pfi_res = zT_542;
    zT_544 = ec.len;
    if ((int)(zT_544 >= (unsigned int)(1))) goto z_bb_151; else goto z_bb_152;
    z_bb_149:
    goto z_bb_144;
    z_bb_150:
    zT_603 = node.child_0;
    zT_604 = self->field_parent_ptr_name_id;
    if ((int)(zT_603 == zT_604)) goto z_bb_165; else goto z_bb_167;
    z_bb_151:
    zT_547 = self;
    zT_549 = ec.ptr;
    zT_550 = 0;
    zT_548 = zT_549[zT_550];
    zT_552 = zF_54F95822_semanticAnalyzerRes(zT_547, zT_548);
    (void)zT_552;
    zT_554 = self;
    zT_555 = zF_4DE7C2BC_topExpectedType(zT_554);
    pfi_top = zT_555;
    if ((int)(pfi_top != (unsigned int)(0))) goto z_bb_153; else goto z_bb_154;
    z_bb_152:
    if ((int)(pfi_res == (unsigned int)(1))) goto z_bb_163; else goto z_bb_164;
    z_bb_153:
    zT_558 = pfi_top != (unsigned int)(18);
    goto z_bb_155;
    z_bb_154:
    zT_558 = 0;
    goto z_bb_155;
    z_bb_155:
    if (zT_558) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_562 = self->registry;
    zT_563 = zT_562->types_items;
    zT_564 = (unsigned int)pfi_top;
    zT_565 = zT_563[zT_564];
    pfi_ty = zT_565;
    zT_566 = pfi_ty.kind;
    if ((int)(zT_566 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_159; else goto z_bb_158;
    z_bb_157:
    goto z_bb_152;
    z_bb_158:
    zT_572 = pfi_ty.kind;
    zT_571 = zT_572 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_160;
    z_bb_159:
    zT_571 = 1;
    goto z_bb_160;
    z_bb_160:
    if (zT_571) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    pfi_res = pfi_top;
    goto z_bb_162;
    z_bb_162:
    goto z_bb_157;
    z_bb_163:
    zT_580 = "cannot infer pointer type for @ptrFromInt; annotate the target variable type";
    zT_582 = 76;
    zT_581.ptr = zT_580;
    zT_581.len = zT_582;
    pfi_msg = zT_581;
    zT_583 = self->diag;
    zT_586 = self->source_file_id;
    zT_587 = node.span_start;
    zT_598 = node.span_start;
    zT_599 = node.span_len;
    zT_589 = pfi_msg;
    zT_602 = zF_C82559AC_diagnosticCollector(zT_583, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_586, zT_587, (unsigned int)(zT_598 + (unsigned int)((unsigned int)zT_599)), zT_589);
    (void)zT_602;
    goto z_bb_164;
    z_bb_164:
    result = pfi_res;
    goto z_bb_149;
    z_bb_165:
    zT_608 = 1;
    fpp_res = zT_608;
    zT_610 = ec.len;
    if ((int)(zT_610 >= (unsigned int)(3))) goto z_bb_168; else goto z_bb_169;
    z_bb_166:
    goto z_bb_149;
    z_bb_167:
    zT_644 = node.child_0;
    zT_645 = self->bitcast_name_id;
    if ((int)(zT_644 == zT_645)) goto z_bb_172; else goto z_bb_174;
    z_bb_168:
    zT_615 = self->store;
    zT_614.store = zT_615;
    zT_616 = self->registry;
    zT_614.typereg = zT_616;
    zT_617 = self->symbols;
    zT_614.symbol_reg = zT_617;
    zT_618 = self->interner;
    zT_614.interner = zT_618;
    zT_619 = self->module_id;
    zT_614.module_id = zT_619;
    fpp_env = zT_614;
    zT_621 = &fpp_env;
    zT_625 = ec.ptr;
    zT_626 = 0;
    zT_622 = zT_625[zT_626];
    zT_629 = zF_F2107C15_resolveTypeExprFull(zT_621, zT_622, (unsigned int)(0));
    fpp_outer = zT_629;
    if ((int)(fpp_outer != (unsigned int)(18))) goto z_bb_170; else goto z_bb_171;
    z_bb_169:
    result = fpp_res;
    goto z_bb_166;
    z_bb_170:
    zT_632 = self;
    zT_634 = ec.ptr;
    zT_635 = 2;
    zT_633 = zT_634[zT_635];
    zT_637 = zF_54F95822_semanticAnalyzerRes(zT_632, zT_633);
    (void)zT_637;
    zT_638 = self->registry;
    zT_639 = fpp_outer;
    zT_643 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_638, zT_639, (int)(0));
    fpp_res = zT_643;
    goto z_bb_171;
    z_bb_171:
    goto z_bb_169;
    z_bb_172:
    zT_649 = 1;
    bc_res = zT_649;
    zT_651 = ec.len;
    if ((int)(zT_651 >= (unsigned int)(2))) goto z_bb_175; else goto z_bb_176;
    z_bb_173:
    goto z_bb_166;
    z_bb_174:
    zT_742 = node.child_0;
    zT_743 = self->getchar_name_id;
    if ((int)(zT_742 == zT_743)) goto z_bb_197; else goto z_bb_199;
    z_bb_175:
    zT_656 = self->store;
    zT_655.store = zT_656;
    zT_657 = self->registry;
    zT_655.typereg = zT_657;
    zT_658 = self->symbols;
    zT_655.symbol_reg = zT_658;
    zT_659 = self->interner;
    zT_655.interner = zT_659;
    zT_660 = self->module_id;
    zT_655.module_id = zT_660;
    bc_env = zT_655;
    zT_662 = &bc_env;
    zT_666 = ec.ptr;
    zT_667 = 0;
    zT_663 = zT_666[zT_667];
    zT_670 = zF_F2107C15_resolveTypeExprFull(zT_662, zT_663, (unsigned int)(0));
    bc_dst = zT_670;
    if ((int)(bc_dst != (unsigned int)(18))) goto z_bb_177; else goto z_bb_178;
    z_bb_176:
    result = bc_res;
    goto z_bb_173;
    z_bb_177:
    zT_674 = self;
    zT_676 = ec.ptr;
    zT_677 = 1;
    zT_675 = zT_676[zT_677];
    zT_679 = zF_54F95822_semanticAnalyzerRes(zT_674, zT_675);
    bc_src = zT_679;
    zT_681 = 0;
    bc_ok = zT_681;
    if ((int)(bc_src != (unsigned int)(18))) goto z_bb_179; else goto z_bb_180;
    z_bb_178:
    goto z_bb_176;
    z_bb_179:
    zT_685 = self->registry;
    zT_686 = bc_dst;
    zT_688 = zF_3290E9C4_typeRegistryIsInteg(zT_685, zT_686);
    zT_684 = zT_688;
    goto z_bb_181;
    z_bb_180:
    zT_684 = 0;
    goto z_bb_181;
    z_bb_181:
    if (zT_684) goto z_bb_182; else goto z_bb_183;
    z_bb_182:
    zT_690 = self->registry;
    zT_691 = bc_src;
    zT_693 = zF_3290E9C4_typeRegistryIsInteg(zT_690, zT_691);
    zT_689 = zT_693;
    goto z_bb_184;
    z_bb_183:
    zT_689 = 0;
    goto z_bb_184;
    z_bb_184:
    if (zT_689) goto z_bb_185; else goto z_bb_186;
    z_bb_185:
    zT_695 = self->registry;
    zT_696 = zT_695->types_items;
    zT_697 = (unsigned int)bc_dst;
    zT_698 = zT_696[zT_697];
    bc_dty = zT_698;
    zT_700 = self->registry;
    zT_701 = zT_700->types_items;
    zT_702 = (unsigned int)bc_src;
    zT_703 = zT_701[zT_702];
    bc_sty = zT_703;
    zT_704 = bc_dty.state;
    if ((int)(zT_704 == (unsigned char)(2))) goto z_bb_187; else goto z_bb_188;
    z_bb_186:
    bc_res = bc_dst;
    if ((int)(bc_ok == (unsigned char)(0))) goto z_bb_195; else goto z_bb_196;
    z_bb_187:
    zT_708 = bc_sty.state;
    zT_707 = zT_708 == (unsigned char)(2);
    goto z_bb_189;
    z_bb_188:
    zT_707 = 0;
    goto z_bb_189;
    z_bb_189:
    if (zT_707) goto z_bb_190; else goto z_bb_191;
    z_bb_190:
    zT_712 = bc_dty.size;
    zT_713 = bc_sty.size;
    zT_711 = zT_712 == zT_713;
    goto z_bb_192;
    z_bb_191:
    zT_711 = 0;
    goto z_bb_192;
    z_bb_192:
    if (zT_711) goto z_bb_193; else goto z_bb_194;
    z_bb_193:
    zT_715 = 1;
    bc_ok = zT_715;
    goto z_bb_194;
    z_bb_194:
    goto z_bb_186;
    z_bb_195:
    zT_719 = "@bitCast requires same-size integer source and destination types";
    zT_721 = 64;
    zT_720.ptr = zT_719;
    zT_720.len = zT_721;
    bc_msg = zT_720;
    zT_722 = self->diag;
    zT_725 = self->source_file_id;
    zT_726 = node.span_start;
    zT_737 = node.span_start;
    zT_738 = node.span_len;
    zT_728 = bc_msg;
    zT_741 = zF_C82559AC_diagnosticCollector(zT_722, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_725, zT_726, (unsigned int)(zT_737 + (unsigned int)((unsigned int)zT_738)), zT_728);
    (void)zT_741;
    goto z_bb_196;
    z_bb_196:
    goto z_bb_178;
    z_bb_197:
    zT_745 = 8;
    result = zT_745;
    goto z_bb_198;
    z_bb_198:
    goto z_bb_173;
    z_bb_199:
    zT_746 = node.child_0;
    zT_747 = self->exit_name_id;
    if ((int)(zT_746 == zT_747)) goto z_bb_200; else goto z_bb_202;
    z_bb_200:
    zT_750 = ec.len;
    if ((int)(zT_750 >= (unsigned int)(1))) goto z_bb_203; else goto z_bb_204;
    z_bb_201:
    goto z_bb_198;
    z_bb_202:
    zT_760 = node.child_0;
    zT_761 = self->panic_name_id;
    if ((int)(zT_760 == zT_761)) goto z_bb_205; else goto z_bb_207;
    z_bb_203:
    zT_753 = self;
    zT_755 = ec.ptr;
    zT_756 = 0;
    zT_754 = zT_755[zT_756];
    zT_758 = zF_54F95822_semanticAnalyzerRes(zT_753, zT_754);
    (void)zT_758;
    goto z_bb_204;
    z_bb_204:
    zT_759 = 3;
    result = zT_759;
    goto z_bb_201;
    z_bb_205:
    zT_764 = ec.len;
    if ((int)(zT_764 >= (unsigned int)(1))) goto z_bb_208; else goto z_bb_209;
    z_bb_206:
    goto z_bb_201;
    z_bb_207:
    zT_774 = node.child_0;
    zT_775 = self->putchar_name_id;
    if ((int)(zT_774 == zT_775)) goto z_bb_211; else goto z_bb_210;
    z_bb_208:
    zT_767 = self;
    zT_769 = ec.ptr;
    zT_770 = 0;
    zT_768 = zT_769[zT_770];
    zT_772 = zF_54F95822_semanticAnalyzerRes(zT_767, zT_768);
    (void)zT_772;
    goto z_bb_209;
    z_bb_209:
    zT_773 = 3;
    result = zT_773;
    goto z_bb_206;
    z_bb_210:
    zT_778 = node.child_0;
    zT_779 = self->sleep_ms_name_id;
    zT_777 = zT_778 == zT_779;
    goto z_bb_212;
    z_bb_211:
    zT_777 = 1;
    goto z_bb_212;
    z_bb_212:
    if (zT_777) goto z_bb_213; else goto z_bb_215;
    z_bb_213:
    zT_782 = ec.len;
    if ((int)(zT_782 >= (unsigned int)(1))) goto z_bb_216; else goto z_bb_217;
    z_bb_214:
    goto z_bb_206;
    z_bb_215:
    zT_792 = node.child_0;
    zT_793 = self->stdout_write_name_id;
    if ((int)(zT_792 == zT_793)) goto z_bb_219; else goto z_bb_218;
    z_bb_216:
    zT_785 = self;
    zT_787 = ec.ptr;
    zT_788 = 0;
    zT_786 = zT_787[zT_788];
    zT_790 = zF_54F95822_semanticAnalyzerRes(zT_785, zT_786);
    (void)zT_790;
    goto z_bb_217;
    z_bb_217:
    zT_791 = 1;
    result = zT_791;
    goto z_bb_214;
    z_bb_218:
    zT_796 = node.child_0;
    zT_797 = self->stderr_write_name_id;
    zT_795 = zT_796 == zT_797;
    goto z_bb_220;
    z_bb_219:
    zT_795 = 1;
    goto z_bb_220;
    z_bb_220:
    if (zT_795) goto z_bb_221; else goto z_bb_223;
    z_bb_221:
    zT_800 = ec.len;
    if ((int)(zT_800 >= (unsigned int)(2))) goto z_bb_224; else goto z_bb_226;
    z_bb_222:
    goto z_bb_214;
    z_bb_223:
    zT_826 = node.child_0;
    zT_827 = self->is_windows_name_id;
    if ((int)(zT_826 == zT_827)) goto z_bb_229; else goto z_bb_231;
    z_bb_224:
    zT_803 = self;
    zT_805 = ec.ptr;
    zT_806 = 0;
    zT_804 = zT_805[zT_806];
    zT_808 = zF_54F95822_semanticAnalyzerRes(zT_803, zT_804);
    (void)zT_808;
    zT_809 = self;
    zT_811 = ec.ptr;
    zT_812 = 1;
    zT_810 = zT_811[zT_812];
    zT_814 = zF_54F95822_semanticAnalyzerRes(zT_809, zT_810);
    (void)zT_814;
    goto z_bb_225;
    z_bb_225:
    zT_825 = 1;
    result = zT_825;
    goto z_bb_222;
    z_bb_226:
    zT_816 = ec.len;
    if ((int)(zT_816 >= (unsigned int)(1))) goto z_bb_227; else goto z_bb_228;
    z_bb_227:
    zT_819 = self;
    zT_821 = ec.ptr;
    zT_822 = 0;
    zT_820 = zT_821[zT_822];
    zT_824 = zF_54F95822_semanticAnalyzerRes(zT_819, zT_820);
    (void)zT_824;
    goto z_bb_228;
    z_bb_228:
    goto z_bb_225;
    z_bb_229:
    zT_829 = 2;
    result = zT_829;
    goto z_bb_230;
    z_bb_230:
    goto z_bb_222;
    z_bb_231:
    zT_830 = node.child_0;
    zT_831 = self->console_clear_name_id;
    if ((int)(zT_830 == zT_831)) goto z_bb_232; else goto z_bb_234;
    z_bb_232:
    zT_833 = 1;
    result = zT_833;
    goto z_bb_233;
    z_bb_233:
    goto z_bb_230;
    z_bb_234:
    zT_834 = node.child_0;
    zT_835 = self->console_gotoxy_name_id;
    if ((int)(zT_834 == zT_835)) goto z_bb_236; else goto z_bb_235;
    z_bb_235:
    zT_838 = node.child_0;
    zT_839 = self->console_set_color_name_id;
    zT_837 = zT_838 == zT_839;
    goto z_bb_237;
    z_bb_236:
    zT_837 = 1;
    goto z_bb_237;
    z_bb_237:
    if (zT_837) goto z_bb_238; else goto z_bb_240;
    z_bb_238:
    zT_842 = ec.len;
    if ((int)(zT_842 >= (unsigned int)(2))) goto z_bb_241; else goto z_bb_243;
    z_bb_239:
    goto z_bb_233;
    z_bb_240:
    zT_868 = node.child_0;
    zT_869 = self->async_frame_size_name_id;
    if ((int)(zT_868 == zT_869)) goto z_bb_246; else goto z_bb_248;
    z_bb_241:
    zT_845 = self;
    zT_847 = ec.ptr;
    zT_848 = 0;
    zT_846 = zT_847[zT_848];
    zT_850 = zF_54F95822_semanticAnalyzerRes(zT_845, zT_846);
    (void)zT_850;
    zT_851 = self;
    zT_853 = ec.ptr;
    zT_854 = 1;
    zT_852 = zT_853[zT_854];
    zT_856 = zF_54F95822_semanticAnalyzerRes(zT_851, zT_852);
    (void)zT_856;
    goto z_bb_242;
    z_bb_242:
    zT_867 = 1;
    result = zT_867;
    goto z_bb_239;
    z_bb_243:
    zT_858 = ec.len;
    if ((int)(zT_858 >= (unsigned int)(1))) goto z_bb_244; else goto z_bb_245;
    z_bb_244:
    zT_861 = self;
    zT_863 = ec.ptr;
    zT_864 = 0;
    zT_862 = zT_863[zT_864];
    zT_866 = zF_54F95822_semanticAnalyzerRes(zT_861, zT_862);
    (void)zT_866;
    goto z_bb_245;
    z_bb_245:
    goto z_bb_242;
    z_bb_246:
    zT_872 = ec.len;
    if ((int)(zT_872 >= (unsigned int)(1))) goto z_bb_249; else goto z_bb_250;
    z_bb_247:
    goto z_bb_239;
    z_bb_248:
    zT_936 = node.child_0;
    zT_937 = self->async_init_name_id;
    if ((int)(zT_936 == zT_937)) goto z_bb_257; else goto z_bb_259;
    z_bb_249:
    zT_875 = self;
    zT_877 = ec.ptr;
    zT_878 = 0;
    zT_876 = zT_877[zT_878];
    zT_880 = zF_54F95822_semanticAnalyzerRes(zT_875, zT_876);
    (void)zT_880;
    zT_882 = 0;
    afs_susp = zT_882;
    zT_883 = self->store;
    zT_884 = self->symbols;
    zT_885 = self->module_id;
    zT_890 = ec.ptr;
    zT_891 = 0;
    zT_886 = zT_890[zT_891];
    zT_893 = zF_860C82EC_resolveCalleeKey(zT_883, zT_884, zT_885, zT_886);
    zT_894 = zT_893.has_value;
    if (zT_894) goto z_bb_251; else goto z_bb_252;
    z_bb_250:
    zT_935 = 19;
    result = zT_935;
    goto z_bb_247;
    z_bb_251:
    afs_k = zT_893.value;
    zT_899 = (unsigned int)(zT_79FAE712_u64)(afs_k >> (zT_79FAE712_u64)(32));
    afs_mid = zT_899;
    zT_903 = (unsigned int)(zT_79FAE712_u64)(afs_k & (zT_79FAE712_u64)(4294967295u));
    afs_nid = zT_903;
    zT_904 = self->suspending_fns;
    zT_905 = afs_mid;
    zT_906 = afs_nid;
    zT_908 = zF_7C7E43BF_asyncIsSuspending(zT_904, zT_905, zT_906);
    if (zT_908) goto z_bb_253; else goto z_bb_254;
    z_bb_252:
    if ((int)(!afs_susp)) goto z_bb_255; else goto z_bb_256;
    z_bb_253:
    zT_909 = 1;
    afs_susp = zT_909;
    goto z_bb_254;
    z_bb_254:
    goto z_bb_252;
    z_bb_255:
    zT_912 = "@asyncFrameSize argument must be a known suspending function";
    zT_914 = 60;
    zT_913.ptr = zT_912;
    zT_913.len = zT_914;
    e3046 = zT_913;
    zT_915 = self->diag;
    zT_918 = self->source_file_id;
    zT_919 = node.span_start;
    zT_930 = node.span_start;
    zT_931 = node.span_len;
    zT_921 = e3046;
    zT_934 = zF_C82559AC_diagnosticCollector(zT_915, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3046_ASYNC_FRAME_SIZE_INVALID)), zT_918, zT_919, (unsigned int)(zT_930 + (unsigned int)((unsigned int)zT_931)), zT_921);
    (void)zT_934;
    goto z_bb_256;
    z_bb_256:
    goto z_bb_250;
    z_bb_257:
    zT_940 = ec.len;
    if ((int)(zT_940 >= (unsigned int)(4))) goto z_bb_260; else goto z_bb_261;
    z_bb_258:
    goto z_bb_247;
    z_bb_259:
    zT_976 = node.child_0;
    zT_977 = self->async_resume_name_id;
    if ((int)(zT_976 == zT_977)) goto z_bb_262; else goto z_bb_264;
    z_bb_260:
    zT_943 = self;
    zT_945 = ec.ptr;
    zT_946 = 0;
    zT_944 = zT_945[zT_946];
    zT_948 = zF_54F95822_semanticAnalyzerRes(zT_943, zT_944);
    (void)zT_948;
    zT_949 = self;
    zT_951 = ec.ptr;
    zT_952 = 1;
    zT_950 = zT_951[zT_952];
    zT_954 = zF_54F95822_semanticAnalyzerRes(zT_949, zT_950);
    (void)zT_954;
    zT_955 = self;
    zT_957 = ec.ptr;
    zT_958 = 2;
    zT_956 = zT_957[zT_958];
    zT_960 = zF_54F95822_semanticAnalyzerRes(zT_955, zT_956);
    (void)zT_960;
    zT_961 = self;
    zT_963 = ec.ptr;
    zT_964 = 3;
    zT_962 = zT_963[zT_964];
    zT_966 = zF_54F95822_semanticAnalyzerRes(zT_961, zT_962);
    (void)zT_966;
    goto z_bb_261;
    z_bb_261:
    zT_967 = self;
    zT_968 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_967, zT_968);
    zT_969 = self->registry;
    zT_975 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_969, (unsigned int)(1), (int)(0));
    result = zT_975;
    goto z_bb_258;
    z_bb_262:
    zT_980 = ec.len;
    if ((int)(zT_980 >= (unsigned int)(2))) goto z_bb_265; else goto z_bb_266;
    z_bb_263:
    goto z_bb_258;
    z_bb_264:
    zT_1008 = node.child_0;
    zT_1009 = self->async_suspend_name_id;
    if ((int)(zT_1008 == zT_1009)) goto z_bb_267; else goto z_bb_269;
    z_bb_265:
    zT_983 = self;
    zT_985 = ec.ptr;
    zT_986 = 0;
    zT_984 = zT_985[zT_986];
    zT_988 = zF_54F95822_semanticAnalyzerRes(zT_983, zT_984);
    (void)zT_988;
    zT_989 = self;
    zT_991 = ec.ptr;
    zT_992 = 1;
    zT_990 = zT_991[zT_992];
    zT_994 = zF_54F95822_semanticAnalyzerRes(zT_989, zT_990);
    (void)zT_994;
    goto z_bb_266;
    z_bb_266:
    zT_995 = self;
    zT_996 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_995, zT_996);
    zT_997 = self->registry;
    zT_1000 = self->registry;
    zT_1006 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1000, (unsigned int)(1), (int)(0));
    zT_998 = zT_1006;
    zT_1007 = zF_74A7234F_typeRegistryGetOrCr(zT_997, zT_998);
    result = zT_1007;
    goto z_bb_263;
    z_bb_267:
    zT_1012 = ec.len;
    if ((int)(zT_1012 >= (unsigned int)(1))) goto z_bb_270; else goto z_bb_271;
    z_bb_268:
    goto z_bb_263;
    z_bb_269:
    zT_1032 = node.child_0;
    zT_1033 = self->ptrcast_name_id;
    if ((int)(zT_1032 == zT_1033)) goto z_bb_272; else goto z_bb_273;
    z_bb_270:
    zT_1015 = self;
    zT_1017 = ec.ptr;
    zT_1018 = 0;
    zT_1016 = zT_1017[zT_1018];
    zT_1020 = zF_54F95822_semanticAnalyzerRes(zT_1015, zT_1016);
    (void)zT_1020;
    goto z_bb_271;
    z_bb_271:
    zT_1021 = self;
    zT_1022 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1021, zT_1022);
    zT_1023 = self;
    zT_1024 = node_idx;
    zF_D4D0798B_semanticAnalyzerDia(zT_1023, zT_1024);
    zT_1025 = self->registry;
    zT_1031 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1025, (unsigned int)(1), (int)(0));
    result = zT_1031;
    goto z_bb_268;
    z_bb_272:
    zT_1037 = ec.len;
    zT_1035 = zT_1037 != (unsigned int)(2);
    goto z_bb_274;
    z_bb_273:
    zT_1035 = 0;
    goto z_bb_274;
    z_bb_274:
    if (zT_1035) goto z_bb_275; else goto z_bb_277;
    z_bb_275:
    zT_1041 = "@ptrCast requires exactly two arguments: @ptrCast(T, expr)";
    zT_1043 = 58;
    zT_1042.ptr = zT_1041;
    zT_1042.len = zT_1043;
    pc3049 = zT_1042;
    zT_1044 = self->diag;
    zT_1047 = self->source_file_id;
    zT_1048 = node.span_start;
    zT_1059 = node.span_start;
    zT_1060 = node.span_len;
    zT_1050 = pc3049;
    zT_1063 = zF_C82559AC_diagnosticCollector(zT_1044, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3049_PTRCAST_REQUIRES_TWO_ARGS)), zT_1047, zT_1048, (unsigned int)(zT_1059 + (unsigned int)((unsigned int)zT_1060)), zT_1050);
    (void)zT_1063;
    zT_1065 = ec.len;
    if ((int)(zT_1065 >= (unsigned int)(1))) goto z_bb_278; else goto z_bb_279;
    z_bb_276:
    goto z_bb_268;
    z_bb_277:
    zT_1076 = ec.len;
    if ((int)(zT_1076 >= (unsigned int)(2))) goto z_bb_280; else goto z_bb_282;
    z_bb_278:
    zT_1068 = self;
    zT_1070 = ec.ptr;
    zT_1071 = 0;
    zT_1069 = zT_1070[zT_1071];
    zT_1073 = zF_54F95822_semanticAnalyzerRes(zT_1068, zT_1069);
    (void)zT_1073;
    goto z_bb_279;
    z_bb_279:
    zT_1074 = 18;
    result = zT_1074;
    goto z_bb_276;
    z_bb_280:
    zT_1079 = self;
    zT_1080 = node.child_0;
    zT_1082 = zF_3757023F_semanticAnalyzerIsT(zT_1079, zT_1080);
    if (zT_1082) goto z_bb_283; else goto z_bb_285;
    z_bb_281:
    goto z_bb_276;
    z_bb_282:
    zT_1181 = node.child_0;
    zT_1182 = self->enumtoint_name_id;
    if ((int)(zT_1181 == zT_1182)) goto z_bb_306; else goto z_bb_307;
    z_bb_283:
    zT_1084 = self;
    zT_1086 = ec.ptr;
    zT_1087 = 1;
    zT_1085 = zT_1086[zT_1087];
    zT_1089 = zF_54F95822_semanticAnalyzerRes(zT_1084, zT_1085);
    tv_src = zT_1089;
    zT_1092 = self->store;
    zT_1091.store = zT_1092;
    zT_1093 = self->registry;
    zT_1091.typereg = zT_1093;
    zT_1094 = self->symbols;
    zT_1091.symbol_reg = zT_1094;
    zT_1095 = self->interner;
    zT_1091.interner = zT_1095;
    zT_1096 = self->module_id;
    zT_1091.module_id = zT_1096;
    tre_env = zT_1091;
    zT_1097 = &tre_env;
    zT_1101 = ec.ptr;
    zT_1102 = 0;
    zT_1098 = zT_1101[zT_1102];
    zT_1105 = zF_F2107C15_resolveTypeExprFull(zT_1097, zT_1098, (unsigned int)(0));
    result = zT_1105;
    zT_1106 = node.child_0;
    zT_1107 = self->ptrcast_name_id;
    if ((int)(zT_1106 == zT_1107)) goto z_bb_286; else goto z_bb_287;
    z_bb_284:
    goto z_bb_281;
    z_bb_285:
    zT_1175 = self;
    zT_1177 = ec.ptr;
    zT_1178 = 0;
    zT_1176 = zT_1177[zT_1178];
    zT_1180 = zF_54F95822_semanticAnalyzerRes(zT_1175, zT_1176);
    result = zT_1180;
    goto z_bb_284;
    z_bb_286:
    zT_1109 = tv_src != (unsigned int)(18);
    goto z_bb_288;
    z_bb_287:
    zT_1109 = 0;
    goto z_bb_288;
    z_bb_288:
    if (zT_1109) goto z_bb_289; else goto z_bb_290;
    z_bb_289:
    zT_1112 = result != (unsigned int)(18);
    goto z_bb_291;
    z_bb_290:
    zT_1112 = 0;
    goto z_bb_291;
    z_bb_291:
    if (zT_1112) goto z_bb_292; else goto z_bb_293;
    z_bb_292:
    zT_1115 = self;
    zT_1116 = tv_src;
    zT_1117 = result;
    zT_1118 = zF_5F2042EA_semanticAnalyzerPtr(zT_1115, zT_1116, zT_1117);
    if (zT_1118) goto z_bb_294; else goto z_bb_295;
    z_bb_293:
    zT_1140 = node.child_0;
    zT_1141 = self->volatilecast_name_id;
    if ((int)(zT_1140 == zT_1141)) goto z_bb_296; else goto z_bb_297;
    z_bb_294:
    zT_1120 = "@ptrCast cannot discard the 'volatile' qualifier; use @volatileCast to remove it";
    zT_1122 = 80;
    zT_1121.ptr = zT_1120;
    zT_1121.len = zT_1122;
    pcq_msg = zT_1121;
    zT_1123 = self->diag;
    zT_1126 = self->source_file_id;
    zT_1127 = node.span_start;
    zT_1135 = node.span_start;
    zT_1136 = node.span_len;
    zT_1129 = pcq_msg;
    zT_1139 = zF_C82559AC_diagnosticCollector(zT_1123, (unsigned char)(0), (unsigned short)(3000), zT_1126, zT_1127, (unsigned int)(zT_1135 + (unsigned int)((unsigned int)zT_1136)), zT_1129);
    (void)zT_1139;
    goto z_bb_295;
    z_bb_295:
    goto z_bb_293;
    z_bb_296:
    zT_1143 = tv_src != (unsigned int)(18);
    goto z_bb_298;
    z_bb_297:
    zT_1143 = 0;
    goto z_bb_298;
    z_bb_298:
    if (zT_1143) goto z_bb_299; else goto z_bb_300;
    z_bb_299:
    zT_1146 = result != (unsigned int)(18);
    goto z_bb_301;
    z_bb_300:
    zT_1146 = 0;
    goto z_bb_301;
    z_bb_301:
    if (zT_1146) goto z_bb_302; else goto z_bb_303;
    z_bb_302:
    zT_1149 = self;
    zT_1150 = tv_src;
    zT_1151 = result;
    zT_1152 = zF_EC29CB82_semanticAnalyzerVol(zT_1149, zT_1150, zT_1151);
    if ((int)(!zT_1152)) goto z_bb_304; else goto z_bb_305;
    z_bb_303:
    goto z_bb_284;
    z_bb_304:
    zT_1155 = "@volatileCast requires a volatile pointer source and a destination with the same base type";
    zT_1157 = 90;
    zT_1156.ptr = zT_1155;
    zT_1156.len = zT_1157;
    vcc_msg = zT_1156;
    zT_1158 = self->diag;
    zT_1161 = self->source_file_id;
    zT_1162 = node.span_start;
    zT_1170 = node.span_start;
    zT_1171 = node.span_len;
    zT_1164 = vcc_msg;
    zT_1174 = zF_C82559AC_diagnosticCollector(zT_1158, (unsigned char)(0), (unsigned short)(3000), zT_1161, zT_1162, (unsigned int)(zT_1170 + (unsigned int)((unsigned int)zT_1171)), zT_1164);
    (void)zT_1174;
    goto z_bb_305;
    z_bb_305:
    goto z_bb_303;
    z_bb_306:
    zT_1186 = ec.len;
    zT_1184 = zT_1186 >= (unsigned int)(1);
    goto z_bb_308;
    z_bb_307:
    zT_1184 = 0;
    goto z_bb_308;
    z_bb_308:
    if (zT_1184) goto z_bb_309; else goto z_bb_311;
    z_bb_309:
    zT_1190 = self;
    zT_1192 = ec.ptr;
    zT_1193 = 0;
    zT_1191 = zT_1192[zT_1193];
    zT_1195 = zF_54F95822_semanticAnalyzerRes(zT_1190, zT_1191);
    e2i_arg = zT_1195;
    e2i_res = e2i_arg;
    if ((int)(e2i_arg != (unsigned int)(18))) goto z_bb_312; else goto z_bb_313;
    z_bb_310:
    goto z_bb_281;
    z_bb_311:
    zT_1231 = ec.len;
    if ((int)(zT_1231 >= (unsigned int)(1))) goto z_bb_326; else goto z_bb_328;
    z_bb_312:
    zT_1200 = self->registry;
    zT_1201 = zT_1200->types_items;
    zT_1202 = (unsigned int)e2i_arg;
    zT_1203 = zT_1201[zT_1202];
    e2i_ty = zT_1203;
    zT_1204 = e2i_ty.kind;
    if ((int)(zT_1204 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_314; else goto z_bb_315;
    z_bb_313:
    result = e2i_res;
    goto z_bb_310;
    z_bb_314:
    zT_1210 = self->registry;
    zT_1211 = e2i_arg;
    zT_1213 = zF_014D7530_typeRegistryEnumBac(zT_1210, zT_1211);
    e2i_bt = zT_1213;
    if ((int)(e2i_bt != (unsigned int)(18))) goto z_bb_316; else goto z_bb_317;
    z_bb_315:
    goto z_bb_313;
    z_bb_316:
    zT_1218 = self->registry;
    zT_1219 = zT_1218->types_len;
    zT_1216 = (unsigned int)((unsigned int)e2i_bt) < zT_1219;
    goto z_bb_318;
    z_bb_317:
    zT_1216 = 0;
    goto z_bb_318;
    z_bb_318:
    if (zT_1216) goto z_bb_319; else goto z_bb_320;
    z_bb_319:
    zT_1221 = self->registry;
    zT_1222 = e2i_arg;
    zT_1224 = zF_A3BA89EA_typeRegistryEnumHas(zT_1221, zT_1222);
    if (zT_1224) goto z_bb_321; else goto z_bb_322;
    z_bb_320:
    goto z_bb_315;
    z_bb_321:
    zT_1226 = self->registry;
    zT_1227 = e2i_bt;
    zT_1229 = zF_B664AC19_typeRegistryIsUnsig(zT_1226, zT_1227);
    zT_1225 = zT_1229;
    goto z_bb_323;
    z_bb_322:
    zT_1225 = 0;
    goto z_bb_323;
    z_bb_323:
    if (zT_1225) goto z_bb_324; else goto z_bb_325;
    z_bb_324:
    e2i_res = e2i_bt;
    goto z_bb_325;
    z_bb_325:
    goto z_bb_320;
    z_bb_326:
    zT_1234 = self;
    zT_1236 = ec.ptr;
    zT_1237 = 0;
    zT_1235 = zT_1236[zT_1237];
    zT_1239 = zF_54F95822_semanticAnalyzerRes(zT_1234, zT_1235);
    result = zT_1239;
    goto z_bb_327;
    z_bb_327:
    goto z_bb_310;
    z_bb_328:
    zT_1240 = 1;
    result = zT_1240;
    goto z_bb_327;
    z_bb_329:
    zT_1246 = self;
    zT_1247 = node.child_0;
    zT_1249 = zF_54F95822_semanticAnalyzerRes(zT_1246, zT_1247);
    (void)zT_1249;
    zT_1250 = 2;
    result = zT_1250;
    goto z_bb_330;
    z_bb_330:
    goto z_bb_121;
    z_bb_331:
    zT_1251 = node.kind;
    if ((int)(zT_1251 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_333; else goto z_bb_332;
    z_bb_332:
    zT_1257 = node.kind;
    zT_1256 = zT_1257 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_negate);
    goto z_bb_334;
    z_bb_333:
    zT_1256 = 1;
    goto z_bb_334;
    z_bb_334:
    if (zT_1256) goto z_bb_335; else goto z_bb_337;
    z_bb_335:
    zT_1262 = self;
    zT_1263 = node_idx;
    zT_1264 = zF_09421FDF_semanticAnalyzerRes(zT_1262, zT_1263);
    result = zT_1264;
    goto z_bb_336;
    z_bb_336:
    goto z_bb_330;
    z_bb_337:
    zT_1265 = node.kind;
    if ((int)(zT_1265 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_338; else goto z_bb_340;
    z_bb_338:
    zT_1270 = self;
    zT_1271 = node_idx;
    zT_1272 = zF_6B59E8AD_semanticAnalyzerRes(zT_1270, zT_1271);
    result = zT_1272;
    goto z_bb_339;
    z_bb_339:
    goto z_bb_336;
    z_bb_340:
    zT_1273 = node.kind;
    if ((int)(zT_1273 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_341; else goto z_bb_343;
    z_bb_341:
    zT_1278 = self;
    zT_1279 = node_idx;
    zT_1280 = zF_B78F27CD_semanticAnalyzerRes(zT_1278, zT_1279);
    result = zT_1280;
    goto z_bb_342;
    z_bb_342:
    goto z_bb_339;
    z_bb_343:
    zT_1281 = node.kind;
    if ((int)(zT_1281 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_344; else goto z_bb_346;
    z_bb_344:
    zT_1287 = 0;
    zT_1288 = (unsigned int)zT_1287;
    catch_es = zT_1288;
    zT_1289 = self;
    zT_1290 = node.child_0;
    zT_1292 = zF_54F95822_semanticAnalyzerRes(zT_1289, zT_1290);
    result = zT_1292;
    if ((int)(result != (unsigned int)(18))) goto z_bb_347; else goto z_bb_348;
    z_bb_345:
    goto z_bb_342;
    z_bb_346:
    zT_1381 = node.kind;
    if ((int)(zT_1381 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_364; else goto z_bb_366;
    z_bb_347:
    zT_1296 = self->registry;
    zT_1297 = zT_1296->types_items;
    zT_1298 = (unsigned int)result;
    zT_1299 = zT_1297[zT_1298];
    clt = zT_1299;
    zT_1300 = clt.kind;
    if ((int)(zT_1300 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_349; else goto z_bb_350;
    z_bb_348:
    zT_1326 = node.child_2;
    zT_1327 = 0;
    if ((int)(zT_1326 != (unsigned int)zT_1327)) goto z_bb_351; else goto z_bb_352;
    z_bb_349:
    zT_1305 = self->registry;
    zT_1306 = zT_1305->eu_items;
    zT_1307 = clt.payload_idx;
    zT_1308 = (unsigned int)zT_1307;
    zT_1309 = zT_1306[zT_1308];
    zT_1310 = zT_1309.error_set;
    catch_es = zT_1310;
    zT_1311 = self->registry;
    zT_1312 = zT_1311->eu_items;
    zT_1313 = clt.payload_idx;
    zT_1314 = (unsigned int)zT_1313;
    zT_1315 = zT_1312[zT_1314];
    zT_1316 = zT_1315.payload;
    result = zT_1316;
    zT_1317 = self->coercion_table;
    zT_1318 = node.child_0;
    zT_1320 = result;
    zF_D21AE60A_coercionTableAdd(zT_1317, zT_1318, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_1320);
    goto z_bb_350;
    z_bb_350:
    goto z_bb_348;
    z_bb_351:
    zT_1330 = self->store;
    zT_1331 = node.child_2;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_1330, zT_1331);
    zT_1335 = self->local_decl_count;
    zT_1336 = self->local_decl_cap;
    if ((int)(zT_1335 >= zT_1336)) goto z_bb_353; else goto z_bb_354;
    z_bb_352:
    zT_1355 = node.child_1;
    if ((int)(zT_1355 != (unsigned int)(0))) goto z_bb_358; else goto z_bb_359;
    z_bb_353:
    zT_1338 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_1338);
    goto z_bb_354;
    z_bb_354:
    zT_1339 = self->store;
    zT_1340 = node.child_2;
    zT_1343 = zF_8BA26B9E_astStoreNodePayload(zT_1339, zT_1340);
    zT_1344 = self->local_decl_names;
    zT_1345 = self->local_decl_count;
    zT_1344[zT_1345] = zT_1343;
    zT_1346 = 0;
    if ((int)(catch_es != (unsigned int)zT_1346)) goto z_bb_355; else goto z_bb_356;
    z_bb_355:
    zT_1348 = catch_es;
    goto z_bb_357;
    z_bb_356:
    zT_1348 = 6;
    goto z_bb_357;
    z_bb_357:
    zT_1350 = self->local_decl_types;
    zT_1351 = self->local_decl_count;
    zT_1350[zT_1351] = zT_1348;
    zT_1352 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_1352 + (unsigned int)(1));
    goto z_bb_352;
    z_bb_358:
    zT_1358 = 0;
    if ((int)(catch_es != (unsigned int)zT_1358)) goto z_bb_360; else goto z_bb_361;
    z_bb_359:
    goto z_bb_345;
    z_bb_360:
    zT_1361 = self->store;
    zT_1362 = node.child_1;
    zT_1365 = zF_FCDD1D35_astStoreNodeAt(zT_1361, zT_1362);
    child1 = zT_1365;
    zT_1366 = child1.kind;
    if ((int)(zT_1366 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_362; else goto z_bb_363;
    z_bb_361:
    zT_1378 = self;
    zT_1379 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1378, zT_1379);
    goto z_bb_359;
    z_bb_362:
    zT_1371 = self;
    zT_1372 = catch_es;
    zF_9665A229_pushExpectedType(zT_1371, zT_1372);
    zT_1373 = self;
    zT_1374 = node.child_1;
    zT_1376 = zF_54F95822_semanticAnalyzerRes(zT_1373, zT_1374);
    (void)zT_1376;
    zT_1377 = self;
    zF_BC478E78_popExpectedType(zT_1377);
    goto z_bb_363;
    z_bb_363:
    goto z_bb_361;
    z_bb_364:
    zT_1386 = self;
    zT_1387 = node_idx;
    zT_1388 = zF_B36961FA_semanticAnalyzerRes(zT_1386, zT_1387);
    result = zT_1388;
    goto z_bb_365;
    z_bb_365:
    goto z_bb_345;
    z_bb_366:
    zT_1389 = node.kind;
    if ((int)(zT_1389 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_368; else goto z_bb_367;
    z_bb_367:
    zT_1395 = node.kind;
    zT_1394 = zT_1395 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt);
    goto z_bb_369;
    z_bb_368:
    zT_1394 = 1;
    goto z_bb_369;
    z_bb_369:
    if (zT_1394) goto z_bb_370; else goto z_bb_372;
    z_bb_370:
    zT_1400 = 1;
    result = zT_1400;
    goto z_bb_371;
    z_bb_371:
    goto z_bb_365;
    z_bb_372:
    zT_1401 = node.kind;
    if ((int)(zT_1401 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_374; else goto z_bb_373;
    z_bb_373:
    zT_1407 = node.kind;
    zT_1406 = zT_1407 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt);
    goto z_bb_375;
    z_bb_374:
    zT_1406 = 1;
    goto z_bb_375;
    z_bb_375:
    if (zT_1406) goto z_bb_377; else goto z_bb_376;
    z_bb_376:
    zT_1413 = node.kind;
    zT_1412 = zT_1413 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_378;
    z_bb_377:
    zT_1412 = 1;
    goto z_bb_378;
    z_bb_378:
    if (zT_1412) goto z_bb_380; else goto z_bb_379;
    z_bb_379:
    zT_1419 = node.kind;
    zT_1418 = zT_1419 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt);
    goto z_bb_381;
    z_bb_380:
    zT_1418 = 1;
    goto z_bb_381;
    z_bb_381:
    if (zT_1418) goto z_bb_382; else goto z_bb_384;
    z_bb_382:
    zT_1424 = self;
    zT_1425 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_1424, zT_1425);
    zT_1426 = 1;
    result = zT_1426;
    goto z_bb_383;
    z_bb_383:
    goto z_bb_371;
    z_bb_384:
    zT_1427 = node.kind;
    if ((int)(zT_1427 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_385; else goto z_bb_387;
    z_bb_385:
    zT_1432 = self;
    zT_1433 = node_idx;
    zT_1434 = zF_8B8EE70D_semanticAnalyzerRes(zT_1432, zT_1433);
    result = zT_1434;
    goto z_bb_386;
    z_bb_386:
    goto z_bb_383;
    z_bb_387:
    zT_1435 = node.kind;
    if ((int)(zT_1435 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_388; else goto z_bb_390;
    z_bb_388:
    zT_1440 = self;
    zT_1441 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_1440, zT_1441);
    zT_1442 = node.child_2;
    if ((int)(zT_1442 != (unsigned int)(0))) goto z_bb_391; else goto z_bb_392;
    z_bb_389:
    goto z_bb_386;
    z_bb_390:
    zT_1455 = node.kind;
    if ((int)(zT_1455 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_395; else goto z_bb_397;
    z_bb_391:
    zT_1445 = self;
    zT_1446 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_1445, zT_1446);
    goto z_bb_392;
    z_bb_392:
    zT_1448 = node.child_1;
    if ((int)(zT_1448 != (unsigned int)(0))) goto z_bb_393; else goto z_bb_394;
    z_bb_393:
    zT_1451 = self;
    zT_1452 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1451, zT_1452);
    goto z_bb_394;
    z_bb_394:
    zT_1454 = 1;
    result = zT_1454;
    goto z_bb_389;
    z_bb_395:
    zT_1460 = self;
    zT_1461 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_1460, zT_1461);
    zT_1462 = node.child_1;
    zT_1463 = 0;
    if ((int)(zT_1462 != (unsigned int)zT_1463)) goto z_bb_398; else goto z_bb_399;
    z_bb_396:
    goto z_bb_389;
    z_bb_397:
    zT_1469 = node.kind;
    if ((int)(zT_1469 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_400; else goto z_bb_402;
    z_bb_398:
    zT_1465 = self;
    zT_1466 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1465, zT_1466);
    goto z_bb_399;
    z_bb_399:
    zT_1468 = 1;
    result = zT_1468;
    goto z_bb_396;
    z_bb_400:
    zT_1474 = self;
    zT_1475 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_1474, zT_1475);
    zT_1476 = node.child_1;
    zT_1477 = 0;
    if ((int)(zT_1476 != (unsigned int)zT_1477)) goto z_bb_403; else goto z_bb_404;
    z_bb_401:
    goto z_bb_396;
    z_bb_402:
    zT_1483 = node.kind;
    if ((int)(zT_1483 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_405; else goto z_bb_407;
    z_bb_403:
    zT_1479 = self;
    zT_1480 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1479, zT_1480);
    goto z_bb_404;
    z_bb_404:
    zT_1482 = 1;
    result = zT_1482;
    goto z_bb_401;
    z_bb_405:
    zT_1488 = self;
    zT_1489 = node_idx;
    zT_1490 = zF_2DB4F186_semanticAnalyzerRes(zT_1488, zT_1489);
    result = zT_1490;
    goto z_bb_406;
    z_bb_406:
    goto z_bb_401;
    z_bb_407:
    zT_1491 = node.kind;
    if ((int)(zT_1491 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_408; else goto z_bb_410;
    z_bb_408:
    zT_1496 = self;
    zT_1497 = node_idx;
    zT_1498 = zF_227D2404_semanticAnalyzerRes(zT_1496, zT_1497);
    result = zT_1498;
    goto z_bb_409;
    z_bb_409:
    goto z_bb_406;
    z_bb_410:
    zT_1499 = node.kind;
    if ((int)(zT_1499 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_411; else goto z_bb_413;
    z_bb_411:
    zT_1504 = self;
    zT_1505 = node_idx;
    zT_1506 = zF_AD7EF126_semanticAnalyzerRes(zT_1504, zT_1505);
    result = zT_1506;
    goto z_bb_412;
    z_bb_412:
    goto z_bb_409;
    z_bb_413:
    zT_1507 = node.kind;
    if ((int)(zT_1507 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_414; else goto z_bb_416;
    z_bb_414:
    zT_1513 = "AW:R";
    zT_1515 = 4;
    zT_1514.ptr = zT_1513;
    zT_1514.len = zT_1515;
    ai_dbg = zT_1514;
    zT_1516 = ai_dbg;
    zT_1517 = result;
    zF_C914CB83_markerWriteInt(zT_1516, zT_1517);
    zT_1518 = self;
    zT_1519 = node_idx;
    zT_1520 = zF_F3DAABE0_semanticAnalyzerRes(zT_1518, zT_1519);
    result = zT_1520;
    goto z_bb_415;
    z_bb_415:
    goto z_bb_412;
    z_bb_416:
    zT_1521 = node.kind;
    if ((int)(zT_1521 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_418; else goto z_bb_417;
    z_bb_417:
    zT_1527 = node.kind;
    zT_1526 = zT_1527 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_419;
    z_bb_418:
    zT_1526 = 1;
    goto z_bb_419;
    z_bb_419:
    if (zT_1526) goto z_bb_421; else goto z_bb_420;
    z_bb_420:
    zT_1533 = node.kind;
    zT_1532 = zT_1533 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_422;
    z_bb_421:
    zT_1532 = 1;
    goto z_bb_422;
    z_bb_422:
    if (zT_1532) goto z_bb_424; else goto z_bb_423;
    z_bb_423:
    zT_1539 = node.kind;
    zT_1538 = zT_1539 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_425;
    z_bb_424:
    zT_1538 = 1;
    goto z_bb_425;
    z_bb_425:
    if (zT_1538) goto z_bb_427; else goto z_bb_426;
    z_bb_426:
    zT_1545 = node.kind;
    zT_1544 = zT_1545 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_428;
    z_bb_427:
    zT_1544 = 1;
    goto z_bb_428;
    z_bb_428:
    if (zT_1544) goto z_bb_430; else goto z_bb_429;
    z_bb_429:
    zT_1551 = node.kind;
    zT_1550 = zT_1551 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_431;
    z_bb_430:
    zT_1550 = 1;
    goto z_bb_431;
    z_bb_431:
    if (zT_1550) goto z_bb_433; else goto z_bb_432;
    z_bb_432:
    zT_1557 = node.kind;
    zT_1556 = zT_1557 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_434;
    z_bb_433:
    zT_1556 = 1;
    goto z_bb_434;
    z_bb_434:
    if (zT_1556) goto z_bb_436; else goto z_bb_435;
    z_bb_435:
    zT_1563 = node.kind;
    zT_1562 = zT_1563 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl);
    goto z_bb_437;
    z_bb_436:
    zT_1562 = 1;
    goto z_bb_437;
    z_bb_437:
    if (zT_1562) goto z_bb_439; else goto z_bb_438;
    z_bb_438:
    zT_1569 = node.kind;
    zT_1568 = zT_1569 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_440;
    z_bb_439:
    zT_1568 = 1;
    goto z_bb_440;
    z_bb_440:
    if (zT_1568) goto z_bb_442; else goto z_bb_441;
    z_bb_441:
    zT_1575 = node.kind;
    zT_1574 = zT_1575 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_443;
    z_bb_442:
    zT_1574 = 1;
    goto z_bb_443;
    z_bb_443:
    if (zT_1574) goto z_bb_445; else goto z_bb_444;
    z_bb_444:
    zT_1581 = node.kind;
    zT_1580 = zT_1581 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_446;
    z_bb_445:
    zT_1580 = 1;
    goto z_bb_446;
    z_bb_446:
    if (zT_1580) goto z_bb_447; else goto z_bb_449;
    z_bb_447:
    zT_1586 = node.kind;
    if ((int)(zT_1586 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_450; else goto z_bb_451;
    z_bb_448:
    goto z_bb_415;
    z_bb_449:
    zT_1596 = node.kind;
    if ((int)(zT_1596 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_452; else goto z_bb_454;
    z_bb_450:
    zT_1591 = self;
    zT_1592 = node_idx;
    zT_1593 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_1591, zT_1592, zT_1593);
    goto z_bb_451;
    z_bb_451:
    zT_1595 = 20;
    result = zT_1595;
    goto z_bb_448;
    z_bb_452:
    zT_1601 = self;
    zT_1602 = node.child_0;
    zT_1604 = zF_54F95822_semanticAnalyzerRes(zT_1601, zT_1602);
    result = zT_1604;
    goto z_bb_453;
    z_bb_453:
    goto z_bb_448;
    z_bb_454:
    zT_1605 = node.kind;
    if ((int)(zT_1605 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_455; else goto z_bb_457;
    z_bb_455:
    zT_1610 = self;
    zT_1611 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_1610, zT_1611);
    zT_1612 = 3;
    result = zT_1612;
    goto z_bb_456;
    z_bb_456:
    goto z_bb_453;
    z_bb_457:
    zT_1613 = node.kind;
    if ((int)(zT_1613 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_458; else goto z_bb_460;
    z_bb_458:
    zT_1618 = self;
    zT_1619 = node.child_0;
    zT_1621 = zF_54F95822_semanticAnalyzerRes(zT_1618, zT_1619);
    result = zT_1621;
    goto z_bb_459;
    z_bb_459:
    goto z_bb_456;
    z_bb_460:
    zT_1622 = node.kind;
    if ((int)(zT_1622 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_461; else goto z_bb_463;
    z_bb_461:
    zT_1627 = 1;
    result = zT_1627;
    goto z_bb_462;
    z_bb_462:
    goto z_bb_459;
    z_bb_463:
    zT_1628 = node.kind;
    if ((int)(zT_1628 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_464; else goto z_bb_466;
    z_bb_464:
    zT_1634 = "EBLK:N";
    zT_1636 = 6;
    zT_1635.ptr = zT_1634;
    zT_1635.len = zT_1636;
    eblk_m = zT_1635;
    zT_1637 = eblk_m;
    zT_1638 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1637, zT_1638);
    zT_1640 = self->store;
    zT_1641 = node_idx;
    zT_1643 = zF_850FDF81_astStoreNodeExtraCh(zT_1640, zT_1641);
    children = zT_1643;
    zT_1645 = "EBLK:C";
    zT_1647 = 6;
    zT_1646.ptr = zT_1645;
    zT_1646.len = zT_1647;
    eblk_cm = zT_1646;
    zT_1648 = eblk_cm;
    zT_1651 = children.len;
    zF_C914CB83_markerWriteInt(zT_1648, (unsigned int)((unsigned int)zT_1651));
    zT_1654 = children.len;
    if ((int)(zT_1654 > (unsigned int)(0))) goto z_bb_467; else goto z_bb_469;
    z_bb_465:
    goto z_bb_462;
    z_bb_466:
    zT_1697 = node.kind;
    if ((int)(zT_1697 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_475; else goto z_bb_474;
    z_bb_467:
    zT_1658 = 0;
    zT_1659 = (unsigned int)zT_1658;
    si = zT_1659;
    goto z_bb_470;
    z_bb_468:
    goto z_bb_465;
    z_bb_469:
    zT_1696 = 1;
    result = zT_1696;
    goto z_bb_468;
    z_bb_470:
    zT_1661 = children.len;
    if ((int)(si < (unsigned int)(zT_1661 - (unsigned int)(1)))) goto z_bb_471; else goto z_bb_472;
    z_bb_471:
    zT_1666 = "EBLK:S";
    zT_1668 = 6;
    zT_1667.ptr = zT_1666;
    zT_1667.len = zT_1668;
    eblk_sm = zT_1667;
    zT_1669 = eblk_sm;
    zF_C914CB83_markerWriteInt(zT_1669, (unsigned int)((unsigned int)si));
    zT_1673 = "EBLK:D";
    zT_1675 = 6;
    zT_1674.ptr = zT_1673;
    zT_1674.len = zT_1675;
    eblk_cm2 = zT_1674;
    zT_1676 = eblk_cm2;
    zT_1678 = children.ptr;
    zT_1677 = zT_1678[si];
    zF_C914CB83_markerWriteInt(zT_1676, zT_1677);
    zT_1680 = self;
    zT_1682 = children.ptr;
    zT_1681 = zT_1682[si];
    zF_10A0DC35_semanticAnalyzerRes(zT_1680, zT_1681);
    goto z_bb_473;
    z_bb_472:
    zT_1687 = children.ptr;
    zT_1689 = children.len;
    zT_1691 = zT_1689 - (unsigned int)(1);
    zT_1692 = zT_1687[zT_1691];
    last_child = zT_1692;
    zT_1693 = self;
    zT_1694 = last_child;
    zT_1695 = zF_54F95822_semanticAnalyzerRes(zT_1693, zT_1694);
    result = zT_1695;
    goto z_bb_468;
    z_bb_473:
    zT_1684 = 1;
    zT_1685 = si + zT_1684;
    si = zT_1685;
    goto z_bb_470;
    z_bb_474:
    zT_1703 = node.kind;
    zT_1702 = zT_1703 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_476;
    z_bb_475:
    zT_1702 = 1;
    goto z_bb_476;
    z_bb_476:
    if (zT_1702) goto z_bb_478; else goto z_bb_477;
    z_bb_477:
    zT_1709 = node.kind;
    zT_1708 = zT_1709 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_479;
    z_bb_478:
    zT_1708 = 1;
    goto z_bb_479;
    z_bb_479:
    if (zT_1708) goto z_bb_481; else goto z_bb_480;
    z_bb_480:
    zT_1715 = node.kind;
    zT_1714 = zT_1715 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_482;
    z_bb_481:
    zT_1714 = 1;
    goto z_bb_482;
    z_bb_482:
    if (zT_1714) goto z_bb_484; else goto z_bb_483;
    z_bb_483:
    zT_1721 = node.kind;
    zT_1720 = zT_1721 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_485;
    z_bb_484:
    zT_1720 = 1;
    goto z_bb_485;
    z_bb_485:
    if (zT_1720) goto z_bb_487; else goto z_bb_486;
    z_bb_486:
    zT_1727 = node.kind;
    zT_1726 = zT_1727 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add);
    goto z_bb_488;
    z_bb_487:
    zT_1726 = 1;
    goto z_bb_488;
    z_bb_488:
    if (zT_1726) goto z_bb_490; else goto z_bb_489;
    z_bb_489:
    zT_1733 = node.kind;
    zT_1732 = zT_1733 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub);
    goto z_bb_491;
    z_bb_490:
    zT_1732 = 1;
    goto z_bb_491;
    z_bb_491:
    if (zT_1732) goto z_bb_493; else goto z_bb_492;
    z_bb_492:
    zT_1739 = node.kind;
    zT_1738 = zT_1739 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul);
    goto z_bb_494;
    z_bb_493:
    zT_1738 = 1;
    goto z_bb_494;
    z_bb_494:
    if (zT_1738) goto z_bb_496; else goto z_bb_495;
    z_bb_495:
    zT_1745 = node.kind;
    zT_1744 = zT_1745 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add);
    goto z_bb_497;
    z_bb_496:
    zT_1744 = 1;
    goto z_bb_497;
    z_bb_497:
    if (zT_1744) goto z_bb_499; else goto z_bb_498;
    z_bb_498:
    zT_1751 = node.kind;
    zT_1750 = zT_1751 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub);
    goto z_bb_500;
    z_bb_499:
    zT_1750 = 1;
    goto z_bb_500;
    z_bb_500:
    if (zT_1750) goto z_bb_502; else goto z_bb_501;
    z_bb_501:
    zT_1757 = node.kind;
    zT_1756 = zT_1757 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul);
    goto z_bb_503;
    z_bb_502:
    zT_1756 = 1;
    goto z_bb_503;
    z_bb_503:
    if (zT_1756) goto z_bb_504; else goto z_bb_506;
    z_bb_504:
    zT_1762 = self;
    zT_1763 = node_idx;
    zT_1764 = node.kind;
    zT_1766 = zF_44006DDD_semanticAnalyzerRes(zT_1762, zT_1763, zT_1764);
    result = zT_1766;
    goto z_bb_505;
    z_bb_505:
    goto z_bb_465;
    z_bb_506:
    zT_1767 = node.kind;
    if ((int)(zT_1767 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_508; else goto z_bb_507;
    z_bb_507:
    zT_1773 = node.kind;
    zT_1772 = zT_1773 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_509;
    z_bb_508:
    zT_1772 = 1;
    goto z_bb_509;
    z_bb_509:
    if (zT_1772) goto z_bb_511; else goto z_bb_510;
    z_bb_510:
    zT_1779 = node.kind;
    zT_1778 = zT_1779 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_512;
    z_bb_511:
    zT_1778 = 1;
    goto z_bb_512;
    z_bb_512:
    if (zT_1778) goto z_bb_514; else goto z_bb_513;
    z_bb_513:
    zT_1785 = node.kind;
    zT_1784 = zT_1785 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_515;
    z_bb_514:
    zT_1784 = 1;
    goto z_bb_515;
    z_bb_515:
    if (zT_1784) goto z_bb_517; else goto z_bb_516;
    z_bb_516:
    zT_1791 = node.kind;
    zT_1790 = zT_1791 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_518;
    z_bb_517:
    zT_1790 = 1;
    goto z_bb_518;
    z_bb_518:
    if (zT_1790) goto z_bb_520; else goto z_bb_519;
    z_bb_519:
    zT_1797 = node.kind;
    zT_1796 = zT_1797 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl);
    goto z_bb_521;
    z_bb_520:
    zT_1796 = 1;
    goto z_bb_521;
    z_bb_521:
    if (zT_1796) goto z_bb_522; else goto z_bb_524;
    z_bb_522:
    zT_1802 = self;
    zT_1803 = node_idx;
    zT_1804 = zF_733BCA9C_semanticAnalyzerRes(zT_1802, zT_1803);
    result = zT_1804;
    goto z_bb_523;
    z_bb_523:
    goto z_bb_505;
    z_bb_524:
    zT_1805 = node.kind;
    if ((int)(zT_1805 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_526; else goto z_bb_525;
    z_bb_525:
    zT_1811 = node.kind;
    zT_1810 = zT_1811 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_527;
    z_bb_526:
    zT_1810 = 1;
    goto z_bb_527;
    z_bb_527:
    if (zT_1810) goto z_bb_528; else goto z_bb_530;
    z_bb_528:
    zT_1816 = self;
    zT_1817 = node_idx;
    zT_1818 = zF_6F2B8B98_semanticAnalyzerRes(zT_1816, zT_1817);
    result = zT_1818;
    goto z_bb_529;
    z_bb_529:
    goto z_bb_523;
    z_bb_530:
    zT_1819 = node.kind;
    if ((int)(zT_1819 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_532; else goto z_bb_531;
    z_bb_531:
    zT_1825 = node.kind;
    zT_1824 = zT_1825 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_533;
    z_bb_532:
    zT_1824 = 1;
    goto z_bb_533;
    z_bb_533:
    if (zT_1824) goto z_bb_535; else goto z_bb_534;
    z_bb_534:
    zT_1831 = node.kind;
    zT_1830 = zT_1831 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_536;
    z_bb_535:
    zT_1830 = 1;
    goto z_bb_536;
    z_bb_536:
    if (zT_1830) goto z_bb_538; else goto z_bb_537;
    z_bb_537:
    zT_1837 = node.kind;
    zT_1836 = zT_1837 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_539;
    z_bb_538:
    zT_1836 = 1;
    goto z_bb_539;
    z_bb_539:
    if (zT_1836) goto z_bb_541; else goto z_bb_540;
    z_bb_540:
    zT_1843 = node.kind;
    zT_1842 = zT_1843 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_542;
    z_bb_541:
    zT_1842 = 1;
    goto z_bb_542;
    z_bb_542:
    if (zT_1842) goto z_bb_544; else goto z_bb_543;
    z_bb_543:
    zT_1849 = node.kind;
    zT_1848 = zT_1849 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_545;
    z_bb_544:
    zT_1848 = 1;
    goto z_bb_545;
    z_bb_545:
    if (zT_1848) goto z_bb_546; else goto z_bb_548;
    z_bb_546:
    zT_1854 = self;
    zT_1855 = node_idx;
    zT_1856 = node.kind;
    zT_1858 = zF_EB621FF0_semanticAnalyzerRes(zT_1854, zT_1855, zT_1856);
    result = zT_1858;
    goto z_bb_547;
    z_bb_547:
    goto z_bb_529;
    z_bb_548:
    zT_1859 = node.kind;
    if ((int)(zT_1859 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_550; else goto z_bb_549;
    z_bb_549:
    zT_1865 = node.kind;
    zT_1864 = zT_1865 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_551;
    z_bb_550:
    zT_1864 = 1;
    goto z_bb_551;
    z_bb_551:
    if (zT_1864) goto z_bb_553; else goto z_bb_552;
    z_bb_552:
    zT_1871 = node.kind;
    zT_1870 = zT_1871 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_554;
    z_bb_553:
    zT_1870 = 1;
    goto z_bb_554;
    z_bb_554:
    if (zT_1870) goto z_bb_556; else goto z_bb_555;
    z_bb_555:
    zT_1877 = node.kind;
    zT_1876 = zT_1877 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_557;
    z_bb_556:
    zT_1876 = 1;
    goto z_bb_557;
    z_bb_557:
    if (zT_1876) goto z_bb_559; else goto z_bb_558;
    z_bb_558:
    zT_1883 = node.kind;
    zT_1882 = zT_1883 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_560;
    z_bb_559:
    zT_1882 = 1;
    goto z_bb_560;
    z_bb_560:
    if (zT_1882) goto z_bb_562; else goto z_bb_561;
    z_bb_561:
    zT_1889 = node.kind;
    zT_1888 = zT_1889 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_563;
    z_bb_562:
    zT_1888 = 1;
    goto z_bb_563;
    z_bb_563:
    if (zT_1888) goto z_bb_565; else goto z_bb_564;
    z_bb_564:
    zT_1895 = node.kind;
    zT_1894 = zT_1895 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_566;
    z_bb_565:
    zT_1894 = 1;
    goto z_bb_566;
    z_bb_566:
    if (zT_1894) goto z_bb_568; else goto z_bb_567;
    z_bb_567:
    zT_1901 = node.kind;
    zT_1900 = zT_1901 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_569;
    z_bb_568:
    zT_1900 = 1;
    goto z_bb_569;
    z_bb_569:
    if (zT_1900) goto z_bb_571; else goto z_bb_570;
    z_bb_570:
    zT_1907 = node.kind;
    zT_1906 = zT_1907 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_572;
    z_bb_571:
    zT_1906 = 1;
    goto z_bb_572;
    z_bb_572:
    if (zT_1906) goto z_bb_574; else goto z_bb_573;
    z_bb_573:
    zT_1913 = node.kind;
    zT_1912 = zT_1913 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_575;
    z_bb_574:
    zT_1912 = 1;
    goto z_bb_575;
    z_bb_575:
    if (zT_1912) goto z_bb_577; else goto z_bb_576;
    z_bb_576:
    zT_1919 = node.kind;
    zT_1918 = zT_1919 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_578;
    z_bb_577:
    zT_1918 = 1;
    goto z_bb_578;
    z_bb_578:
    if (zT_1918) goto z_bb_580; else goto z_bb_579;
    z_bb_579:
    zT_1925 = node.kind;
    zT_1924 = zT_1925 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_581;
    z_bb_580:
    zT_1924 = 1;
    goto z_bb_581;
    z_bb_581:
    if (zT_1924) goto z_bb_583; else goto z_bb_582;
    z_bb_582:
    zT_1931 = node.kind;
    zT_1930 = zT_1931 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_584;
    z_bb_583:
    zT_1930 = 1;
    goto z_bb_584;
    z_bb_584:
    if (zT_1930) goto z_bb_586; else goto z_bb_585;
    z_bb_585:
    zT_1937 = node.kind;
    zT_1936 = zT_1937 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_587;
    z_bb_586:
    zT_1936 = 1;
    goto z_bb_587;
    z_bb_587:
    if (zT_1936) goto z_bb_589; else goto z_bb_588;
    z_bb_588:
    zT_1943 = node.kind;
    zT_1942 = zT_1943 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_590;
    z_bb_589:
    zT_1942 = 1;
    goto z_bb_590;
    z_bb_590:
    if (zT_1942) goto z_bb_592; else goto z_bb_591;
    z_bb_591:
    zT_1949 = node.kind;
    zT_1948 = zT_1949 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_593;
    z_bb_592:
    zT_1948 = 1;
    goto z_bb_593;
    z_bb_593:
    if (zT_1948) goto z_bb_595; else goto z_bb_594;
    z_bb_594:
    zT_1955 = node.kind;
    zT_1954 = zT_1955 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_596;
    z_bb_595:
    zT_1954 = 1;
    goto z_bb_596;
    z_bb_596:
    if (zT_1954) goto z_bb_598; else goto z_bb_597;
    z_bb_597:
    zT_1961 = node.kind;
    zT_1960 = zT_1961 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_599;
    z_bb_598:
    zT_1960 = 1;
    goto z_bb_599;
    z_bb_599:
    if (zT_1960) goto z_bb_600; else goto z_bb_602;
    z_bb_600:
    zT_1966 = self;
    zT_1967 = node_idx;
    zT_1968 = zF_C0551BB8_semanticAnalyzerRes(zT_1966, zT_1967);
    result = zT_1968;
    goto z_bb_601;
    z_bb_601:
    goto z_bb_547;
    z_bb_602:
    zT_1969 = node.kind;
    if ((int)(zT_1969 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_604; else goto z_bb_603;
    z_bb_603:
    zT_1975 = node.kind;
    zT_1974 = zT_1975 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_605;
    z_bb_604:
    zT_1974 = 1;
    goto z_bb_605;
    z_bb_605:
    if (zT_1974) goto z_bb_606; else goto z_bb_608;
    z_bb_606:
    zT_1980 = self->type_table;
    zT_1981 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1980, zT_1981, (unsigned int)(10));
    return (unsigned int)(10);
    goto z_bb_601;
    z_bb_608:
    zT_1987 = "ST:N";
    zT_1989 = 4;
    zT_1988.ptr = zT_1987;
    zT_1988.len = zT_1989;
    st_m = zT_1988;
    zT_1990 = st_m;
    zT_1991 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1990, zT_1991);
    zT_1993 = node.kind;
    zT_1994 = (unsigned int)zT_1993;
    st_kv = zT_1994;
    zT_1996 = "ST:K";
    zT_1998 = 4;
    zT_1997.ptr = zT_1996;
    zT_1997.len = zT_1998;
    st_km = zT_1997;
    zT_1999 = st_km;
    zT_2000 = st_kv;
    zF_C914CB83_markerWriteInt(zT_1999, zT_2000);
    zT_2002 = "internal error: unhandled node kind in type resolution";
    zT_2004 = 54;
    zT_2003.ptr = zT_2002;
    zT_2003.len = zT_2004;
    unr_msg = zT_2003;
    zT_2005 = self->diag;
    zT_2008 = self->source_file_id;
    zT_2009 = node_idx;
    zT_2010 = node_idx;
    zT_2011 = unr_msg;
    zT_2016 = zF_C82559AC_diagnosticCollector(zT_2005, (unsigned char)(0), (unsigned short)(3020), zT_2008, zT_2009, zT_2010, zT_2011);
    (void)zT_2016;
    return (unsigned int)(1);
}

/* semanticAnalyzerFnPtrConvMismatch */
int zF_148F8E19_semanticAnalyzerFnP(zT_38C12417_SemanticAnalyzer* self, unsigned int src, unsigned int tgt) {
    zT_338B7C76_TypeRegistry* zT_6;
    unsigned int zT_7;
    int zT_9;
    zT_338B7C76_TypeRegistry* zT_11;
    unsigned int zT_12;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_D155D06D_Type* zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_112BF819_PtrPayload* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_112BF819_PtrPayload zT_31;
    unsigned int zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    zT_338B7C76_TypeRegistry* zT_38;
    zT_D155D06D_Type* zT_39;
    unsigned int zT_40;
    zT_D155D06D_Type zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_112BF819_PtrPayload* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_112BF819_PtrPayload zT_51;
    unsigned int zT_52;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_D155D06D_Type* zT_54;
    unsigned int zT_55;
    zT_D155D06D_Type zT_56;
    zT_33EF6BFB_TypeKind zT_57;
    int zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_0317B1D5_FnPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_0317B1D5_FnPayload zT_74;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_0317B1D5_FnPayload* zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_0317B1D5_FnPayload zT_80;
    unsigned char zT_81;
    unsigned char zT_84;
    unsigned int s;
    unsigned int t;
    zT_D155D06D_Type st;
    zT_D155D06D_Type tt;
    zT_0317B1D5_FnPayload sfp;
    zT_0317B1D5_FnPayload tfp;
    if ((int)(src == tgt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_len;
    if ((int)((unsigned int)((unsigned int)src) >= zT_7)) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_11 = self->registry;
    zT_12 = zT_11->types_len;
    zT_9 = (unsigned int)((unsigned int)tgt) >= zT_12;
    goto z_bb_5;
    z_bb_4:
    zT_9 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_9) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (int)(0);
    z_bb_7:
    s = src;
    t = tgt;
    zT_18 = self->registry;
    zT_19 = zT_18->types_items;
    zT_20 = (unsigned int)s;
    zT_21 = zT_19[zT_20];
    st = zT_21;
    zT_22 = st.kind;
    if ((int)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_27 = self->registry;
    zT_28 = zT_27->ptr_items;
    zT_29 = st.payload_idx;
    zT_30 = (unsigned int)zT_29;
    zT_31 = zT_28[zT_30];
    zT_32 = zT_31.base;
    s = zT_32;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)s;
    zT_36 = zT_34[zT_35];
    st = zT_36;
    goto z_bb_9;
    z_bb_9:
    zT_38 = self->registry;
    zT_39 = zT_38->types_items;
    zT_40 = (unsigned int)t;
    zT_41 = zT_39[zT_40];
    tt = zT_41;
    zT_42 = tt.kind;
    if ((int)(zT_42 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_47 = self->registry;
    zT_48 = zT_47->ptr_items;
    zT_49 = tt.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    zT_52 = zT_51.base;
    t = zT_52;
    zT_53 = self->registry;
    zT_54 = zT_53->types_items;
    zT_55 = (unsigned int)t;
    zT_56 = zT_54[zT_55];
    tt = zT_56;
    goto z_bb_11;
    z_bb_11:
    zT_57 = st.kind;
    if ((int)(zT_57 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_63 = tt.kind;
    zT_62 = zT_63 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_14;
    z_bb_13:
    zT_62 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_62) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(0);
    z_bb_16:
    zT_70 = self->registry;
    zT_71 = zT_70->fn_items;
    zT_72 = st.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    sfp = zT_74;
    zT_76 = self->registry;
    zT_77 = zT_76->fn_items;
    zT_78 = tt.payload_idx;
    zT_79 = (unsigned int)zT_78;
    zT_80 = zT_77[zT_79];
    tfp = zT_80;
    zT_81 = sfp.flags_packed;
    zT_84 = tfp.flags_packed;
    return (int)((unsigned char)(zT_81 & (unsigned char)(2)) != (unsigned char)(zT_84 & (unsigned char)(2)));
}

/* semanticAnalyzerResolveFnBody */
void zF_406A2501_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int fn_decl_node) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    zT_8143F551_AstKind zT_13;
    zT_6B0A7D14_AstStore* zT_19;
    zT_623E1332_anon_217967 zT_21;
    zT_243D6A41_FnProto* zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    zT_243D6A41_FnProto zT_28;
    zT_8EED1867_ResolvedTypeTable* zT_30;
    unsigned int zT_31;
    zT_BAEE192E_Opt_10 zT_33 = {0};
    unsigned char zT_34;
    zT_338B7C76_TypeRegistry* zT_37;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_41;
    zT_D155D06D_Type* zT_42;
    unsigned int zT_43;
    zT_D155D06D_Type zT_44;
    zT_33EF6BFB_TypeKind zT_45;
    zT_338B7C76_TypeRegistry* zT_51;
    zT_0317B1D5_FnPayload* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_0317B1D5_FnPayload zT_55;
    unsigned char zT_56;
    int zT_61;
    unsigned char zT_62;
    char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_F85C5DED_DiagnosticCollector* zT_71;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_90 = 0;
    unsigned int zT_91;
    unsigned short zT_94;
    unsigned int zT_98;
    unsigned short zT_102;
    zT_79FAE712_u64 zT_104;
    zT_6B0A7D14_AstStore* zT_106;
    zT_79FAE712_u64 zT_107;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_108 = {0};
    unsigned int zT_110;
    unsigned int zT_112;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    unsigned int* zT_117;
    zT_22A7C88B_AstNode zT_119 = {0};
    unsigned int zT_120;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_38C12417_SemanticAnalyzer* zT_126;
    zT_6B0A7D14_AstStore* zT_127;
    unsigned int zT_128;
    unsigned int* zT_129;
    unsigned int zT_131 = 0;
    unsigned int* zT_132;
    unsigned int zT_133;
    char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    unsigned int* zT_142;
    unsigned int zT_144 = 0;
    char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8EED1867_ResolvedTypeTable* zT_153;
    unsigned int zT_154;
    zT_BAEE192E_Opt_10 zT_157 = {0};
    unsigned char zT_158;
    char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    unsigned int* zT_166;
    unsigned int zT_167;
    char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    unsigned int* zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_180;
    zT_8EED1867_ResolvedTypeTable* zT_182;
    unsigned int zT_183;
    zT_BAEE192E_Opt_10 zT_186 = {0};
    unsigned char zT_187;
    unsigned int zT_189;
    zT_38C12417_SemanticAnalyzer* zT_190;
    unsigned int zT_191;
    zT_38C12417_SemanticAnalyzer* zT_194;
    unsigned int zT_195;
    int zT_197 = 0;
    int zT_198;
    zT_38C12417_SemanticAnalyzer* zT_199;
    unsigned int zT_200;
    int zT_202 = 0;
    unsigned int zT_205;
    unsigned int zT_207;
    unsigned int zT_209;
    char* zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned int zT_213;
    zT_F85C5DED_DiagnosticCollector* zT_214;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    unsigned int zT_225 = 0;
    zT_21D3708C_U32ToU32Map* zT_227;
    unsigned int zT_228;
    zT_21D3708C_U32ToU32Map* zT_230;
    unsigned int zT_231;
    char* zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    char* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u fb;
    zT_22A7C88B_AstNode decl;
    zT_6B0A7D14_AstStore* store;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 vsc_tt;
    unsigned int vsc_tid;
    zT_D155D06D_Type vsc_ty;
    zT_0317B1D5_FnPayload vsc_fp;
    zT_8F083A69_Slice_zT_0B42B2F8_u vs_msg;
    zT_79FAE712_u64 p_payload;
    zT_3CB0179A_Slice_zT_05F374B1_u pnodes;
    unsigned int pi;
    zT_BAEE192E_Opt_10 fn_rt;
    zT_22A7C88B_AstNode pnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rta_m;
    zT_BAEE192E_Opt_10 rt;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u rth_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtm2;
    unsigned int frt;
    unsigned int mrsp;
    unsigned int mrep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr_msg;
    unsigned int evcap;
    unsigned int evcnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u vm;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcm;
    zT_3 = "FB";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fb = zT_4;
    zT_6 = fb;
    zF_48AC7B3A_markerWrite(zT_6);
    self->local_decl_count = (unsigned int)(0);
    zT_9 = self->store;
    zT_10 = fn_decl_node;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    decl = zT_12;
    zT_13 = decl.kind;
    if ((int)(zT_13 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_19 = self->store;
    store = zT_19;
    zT_21 = store->fn_protos;
    zT_22 = zT_21.items;
    zT_23 = self->store;
    zT_24 = fn_decl_node;
    zT_26 = zF_8BA26B9E_astStoreNodePayload(zT_23, zT_24);
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_22[zT_27];
    proto = zT_28;
    zT_30 = self->type_table;
    zT_31 = fn_decl_node;
    zT_33 = zF_999DCF51_resolvedTypeTableGe(zT_30, zT_31);
    vsc_tt = zT_33;
    zT_34 = vsc_tt.has_value;
    if (zT_34) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    vsc_tid = vsc_tt.value;
    zT_37 = self->registry;
    zT_38 = zT_37->types_len;
    if ((int)((unsigned int)((unsigned int)vsc_tid) < zT_38)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_91 = decl.child_0;
    if ((int)(zT_91 == (unsigned int)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_5:
    zT_41 = self->registry;
    zT_42 = zT_41->types_items;
    zT_43 = (unsigned int)vsc_tid;
    zT_44 = zT_42[zT_43];
    vsc_ty = zT_44;
    zT_45 = vsc_ty.kind;
    if ((int)(zT_45 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_51 = self->registry;
    zT_52 = zT_51->fn_items;
    zT_53 = vsc_ty.payload_idx;
    zT_54 = (unsigned int)zT_53;
    zT_55 = zT_52[zT_54];
    vsc_fp = zT_55;
    zT_56 = vsc_fp.flags_packed;
    if ((int)((unsigned char)(zT_56 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_62 = vsc_fp.flags_packed;
    zT_61 = (unsigned char)(zT_62 & (unsigned char)(2)) != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_61 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_61) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_68 = "variadic functions cannot use the stdcall calling convention";
    zT_70 = 60;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    vs_msg = zT_69;
    zT_71 = self->diag;
    zT_74 = self->source_file_id;
    zT_75 = decl.span_start;
    zT_86 = decl.span_start;
    zT_87 = decl.span_len;
    zT_77 = vs_msg;
    zT_90 = zF_C82559AC_diagnosticCollector(zT_71, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3012_VARARGS_INVALID)), zT_74, zT_75, (unsigned int)(zT_86 + (unsigned int)((unsigned int)zT_87)), zT_77);
    (void)zT_90;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    return;
    z_bb_15:
    zT_94 = proto.params_count;
    if ((int)(zT_94 > (unsigned short)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_98 = proto.params_start;
    zT_102 = proto.params_count;
    zT_104 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_98) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_102);
    p_payload = zT_104;
    zT_106 = store;
    zT_107 = p_payload;
    zT_108 = zF_3EAD7B21_astStoreGetExtraChi(zT_106, zT_107);
    pnodes = zT_108;
    zT_110 = 0;
    pi = zT_110;
    goto z_bb_18;
    z_bb_17:
    zT_182 = self->type_table;
    zT_183 = proto.return_type_node;
    zT_186 = zF_999DCF51_resolvedTypeTableGe(zT_182, zT_183);
    fn_rt = zT_186;
    zT_187 = fn_rt.has_value;
    if (zT_187) goto z_bb_29; else goto z_bb_30;
    z_bb_18:
    zT_112 = pnodes.len;
    if ((int)(pi < zT_112)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_115 = store;
    zT_117 = pnodes.ptr;
    zT_116 = zT_117[pi];
    zT_119 = zF_FCDD1D35_astStoreNodeAt(zT_115, zT_116);
    pnode = zT_119;
    zT_120 = pnode.child_0;
    if ((int)(zT_120 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_180 = pi + (unsigned int)(1);
    pi = zT_180;
    goto z_bb_18;
    z_bb_22:
    zT_123 = self->local_decl_count;
    zT_124 = self->local_decl_cap;
    if ((int)(zT_123 >= zT_124)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_126 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_126);
    goto z_bb_25;
    z_bb_25:
    zT_127 = store;
    zT_129 = pnodes.ptr;
    zT_128 = zT_129[pi];
    zT_131 = zF_8BA26B9E_astStoreNodePayload(zT_127, zT_128);
    zT_132 = self->local_decl_names;
    zT_133 = self->local_decl_count;
    zT_132[zT_133] = zT_131;
    zT_135 = "RT:P";
    zT_137 = 4;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    rtp_m = zT_136;
    zT_138 = rtp_m;
    zT_140 = store;
    zT_142 = pnodes.ptr;
    zT_141 = zT_142[pi];
    zT_144 = zF_8BA26B9E_astStoreNodePayload(zT_140, zT_141);
    zT_139 = zT_144;
    zF_C914CB83_markerWriteInt(zT_138, zT_139);
    zT_146 = "RT:A";
    zT_148 = 4;
    zT_147.ptr = zT_146;
    zT_147.len = zT_148;
    rta_m = zT_147;
    zT_149 = rta_m;
    zT_150 = pnode.child_0;
    zF_C914CB83_markerWriteInt(zT_149, zT_150);
    zT_153 = self->type_table;
    zT_154 = pnode.child_0;
    zT_157 = zF_999DCF51_resolvedTypeTableGe(zT_153, zT_154);
    rt = zT_157;
    zT_158 = rt.has_value;
    if (zT_158) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    t = rt.value;
    zT_161 = "RT:T";
    zT_163 = 4;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    rth_m = zT_162;
    zT_164 = rth_m;
    zT_165 = t;
    zF_C914CB83_markerWriteInt(zT_164, zT_165);
    zT_166 = self->local_decl_types;
    zT_167 = self->local_decl_count;
    zT_166[zT_167] = t;
    goto z_bb_27;
    z_bb_27:
    zT_176 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_176 + (unsigned int)(1));
    goto z_bb_23;
    z_bb_28:
    zT_169 = "RT:M\n";
    zT_171 = 5;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    rtm2 = zT_170;
    zT_172 = rtm2;
    zF_48AC7B3A_markerWrite(zT_172);
    zT_173 = 18;
    zT_174 = self->local_decl_types;
    zT_175 = self->local_decl_count;
    zT_174[zT_175] = zT_173;
    goto z_bb_27;
    z_bb_29:
    frt = fn_rt.value;
    self->current_fn_return = frt;
    goto z_bb_30;
    z_bb_30:
    zT_189 = proto.name_id;
    self->current_fn_name = zT_189;
    zT_190 = self;
    zT_191 = decl.child_0;
    zF_979B6CFF_semanticAnalyzerRes(zT_190, zT_191);
    self->current_fn_name = (unsigned int)(0);
    zT_194 = self;
    zT_195 = self->current_fn_return;
    zT_197 = zF_15CE7BE8_fnReturnRequiresVal(zT_194, zT_195);
    if (zT_197) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_199 = self;
    zT_200 = decl.child_0;
    zT_202 = zF_AA164297_astTerminates(zT_199, zT_200);
    zT_198 = !zT_202;
    goto z_bb_33;
    z_bb_32:
    zT_198 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_198) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_205 = decl.span_start;
    mrsp = zT_205;
    zT_207 = decl.span_len;
    zT_209 = mrsp + (unsigned int)((unsigned int)zT_207);
    mrep = zT_209;
    zT_211 = "missing return: not all control paths return a value";
    zT_213 = 52;
    zT_212.ptr = zT_211;
    zT_212.len = zT_213;
    mr_msg = zT_212;
    zT_214 = self->diag;
    zT_217 = self->source_file_id;
    zT_218 = mrsp;
    zT_219 = mrep;
    zT_220 = mr_msg;
    zT_225 = zF_C82559AC_diagnosticCollector(zT_214, (unsigned char)(0), (unsigned short)(3003), zT_217, zT_218, zT_219, zT_220);
    (void)zT_225;
    goto z_bb_35;
    z_bb_35:
    zT_227 = self->enum_value_table;
    zT_228 = zT_227->capacity;
    evcap = zT_228;
    zT_230 = self->enum_value_table;
    zT_231 = zT_230->count;
    evcnt = zT_231;
    zT_233 = "EVC:N";
    zT_235 = 5;
    zT_234.ptr = zT_233;
    zT_234.len = zT_235;
    vm = zT_234;
    zT_236 = vm;
    zF_C914CB83_markerWriteInt(zT_236, (unsigned int)((unsigned int)evcnt));
    zT_240 = "EVC:C";
    zT_242 = 5;
    zT_241.ptr = zT_240;
    zT_241.len = zT_242;
    vcm = zT_241;
    zT_243 = vcm;
    zF_C914CB83_markerWriteInt(zT_243, (unsigned int)((unsigned int)evcap));
    return;
}

/* fnReturnRequiresValue */
int zF_15CE7BE8_fnReturnRequiresVal(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    int zT_4;
    int zT_7;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_D155D06D_Type* zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_42C2D6BF_EUPayload* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_42C2D6BF_EUPayload zT_31;
    unsigned int zT_32;
    zT_33EF6BFB_TypeKind zT_36;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_0B10E8E9_OptionalPayload* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_0B10E8E9_OptionalPayload zT_46;
    unsigned int zT_47;
    zT_D155D06D_Type t;
    zT_42C2D6BF_EUPayload eu;
    zT_0B10E8E9_OptionalPayload op;
    if ((int)(ty == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = ty == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = ty == (unsigned int)(3);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_7) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_12 = self->registry;
    zT_13 = zT_12->types_len;
    if ((int)((unsigned int)((unsigned int)ty) >= zT_13)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_17 = self->registry;
    zT_18 = zT_17->types_items;
    zT_19 = (unsigned int)ty;
    zT_20 = zT_18[zT_19];
    t = zT_20;
    zT_21 = t.kind;
    if ((int)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_27 = self->registry;
    zT_28 = zT_27->eu_items;
    zT_29 = t.payload_idx;
    zT_30 = (unsigned int)zT_29;
    zT_31 = zT_28[zT_30];
    eu = zT_31;
    zT_32 = eu.payload;
    if ((int)(zT_32 == (unsigned int)(1))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_36 = t.kind;
    if ((int)(zT_36 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_42 = self->registry;
    zT_43 = zT_42->opt_items;
    zT_44 = t.payload_idx;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zT_43[zT_45];
    op = zT_46;
    zT_47 = op.payload;
    if ((int)(zT_47 == (unsigned int)(1))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    return (int)(1);
    z_bb_17:
    return (int)(0);
    z_bb_18:
    goto z_bb_16;
}

/* astTerminates */
int zF_AA164297_astTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_8EED1867_ResolvedTypeTable* zT_16;
    unsigned int zT_17;
    zT_BAEE192E_Opt_10 zT_19 = {0};
    unsigned char zT_20;
    zT_8143F551_AstKind zT_25;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_34 = {0};
    unsigned int zT_36;
    unsigned int zT_38;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_44 = 0;
    int zT_46;
    unsigned int zT_47;
    zT_8143F551_AstKind zT_49;
    int zT_54;
    zT_8143F551_AstKind zT_55;
    unsigned int zT_60;
    zT_38C12417_SemanticAnalyzer* zT_64;
    unsigned int zT_65;
    int zT_67 = 0;
    int zT_68;
    zT_38C12417_SemanticAnalyzer* zT_69;
    unsigned int zT_70;
    int zT_72 = 0;
    zT_8143F551_AstKind zT_73;
    unsigned int zT_78;
    zT_38C12417_SemanticAnalyzer* zT_82;
    unsigned int zT_84;
    zT_8143F551_AstKind zT_86;
    zT_38C12417_SemanticAnalyzer* zT_91;
    unsigned int zT_92;
    int zT_93 = 0;
    zT_8143F551_AstKind zT_94;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    int zT_101 = 0;
    zT_8143F551_AstKind zT_102;
    unsigned int zT_107;
    zT_38C12417_SemanticAnalyzer* zT_111;
    unsigned int zT_113;
    zT_8143F551_AstKind zT_115;
    int zT_120;
    zT_8143F551_AstKind zT_121;
    int zT_126;
    zT_8143F551_AstKind zT_127;
    int zT_132;
    zT_8143F551_AstKind zT_133;
    int zT_138;
    zT_8143F551_AstKind zT_139;
    int zT_144;
    zT_8143F551_AstKind zT_145;
    int zT_150;
    zT_8143F551_AstKind zT_151;
    int zT_156;
    zT_8143F551_AstKind zT_157;
    int zT_162;
    zT_8143F551_AstKind zT_163;
    int zT_168;
    zT_8143F551_AstKind zT_169;
    int zT_174;
    zT_8143F551_AstKind zT_175;
    int zT_180;
    zT_8143F551_AstKind zT_181;
    int zT_186;
    zT_8143F551_AstKind zT_187;
    int zT_192;
    zT_8143F551_AstKind zT_193;
    int zT_198;
    zT_8143F551_AstKind zT_199;
    int zT_204;
    zT_8143F551_AstKind zT_205;
    int zT_210;
    zT_8143F551_AstKind zT_211;
    int zT_216;
    zT_8143F551_AstKind zT_217;
    unsigned int zT_222;
    zT_38C12417_SemanticAnalyzer* zT_226;
    unsigned int zT_228;
    zT_22A7C88B_AstNode node;
    unsigned int t;
    zT_3CB0179A_Slice_zT_05F374B1_u ch;
    unsigned int bi;
    z_bb_0:
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((int)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_16 = self->type_table;
    zT_17 = node_idx;
    zT_19 = zF_999DCF51_resolvedTypeTableGe(zT_16, zT_17);
    zT_20 = zT_19.has_value;
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    t = zT_19.value;
    if ((int)(t == (unsigned int)(3))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_25 = node.kind;
    if ((int)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_31 = self->store;
    zT_32 = node_idx;
    zT_34 = zF_850FDF81_astStoreNodeExtraCh(zT_31, zT_32);
    ch = zT_34;
    zT_36 = 0;
    bi = zT_36;
    goto z_bb_11;
    z_bb_10:
    zT_49 = node.kind;
    if ((int)(zT_49 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    zT_38 = ch.len;
    if ((int)(bi < zT_38)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_40 = self;
    zT_42 = ch.ptr;
    zT_41 = zT_42[bi];
    zT_44 = zF_AA164297_astTerminates(zT_40, zT_41);
    if (zT_44) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_46 = 1;
    zT_47 = bi + zT_46;
    bi = zT_47;
    goto z_bb_11;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_55 = node.kind;
    zT_54 = zT_55 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr);
    goto z_bb_19;
    z_bb_18:
    zT_54 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_54) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_60 = node.child_2;
    if ((int)(zT_60 == (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_73 = node.kind;
    if ((int)(zT_73 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_27; else goto z_bb_28;
    z_bb_22:
    return (int)(0);
    z_bb_23:
    zT_64 = self;
    zT_65 = node.child_1;
    zT_67 = zF_AA164297_astTerminates(zT_64, zT_65);
    if (zT_67) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_69 = self;
    zT_70 = node.child_2;
    zT_72 = zF_AA164297_astTerminates(zT_69, zT_70);
    zT_68 = zT_72;
    goto z_bb_26;
    z_bb_25:
    zT_68 = 0;
    goto z_bb_26;
    z_bb_26:
    return zT_68;
    z_bb_27:
    zT_78 = node.child_0;
    if ((int)(zT_78 == (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_86 = node.kind;
    if ((int)(zT_86 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return (int)(0);
    z_bb_30:
    zT_82 = self;
    zT_84 = node.child_0;
    self = zT_82;
    node_idx = zT_84;
    goto z_bb_0;
    z_bb_31:
    zT_91 = self;
    zT_92 = node_idx;
    zT_93 = zF_A3A1FD27_astSwitchTerminates(zT_91, zT_92);
    return zT_93;
    z_bb_32:
    zT_94 = node.kind;
    if ((int)(zT_94 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_99 = self;
    zT_100 = node_idx;
    zT_101 = zF_FB2132D0_astWhileTerminates(zT_99, zT_100);
    return zT_101;
    z_bb_34:
    zT_102 = node.kind;
    if ((int)(zT_102 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_107 = node.child_1;
    if ((int)(zT_107 == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_115 = node.kind;
    if ((int)(zT_115 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_40; else goto z_bb_39;
    z_bb_37:
    return (int)(0);
    z_bb_38:
    zT_111 = self;
    zT_113 = node.child_1;
    self = zT_111;
    node_idx = zT_113;
    goto z_bb_0;
    z_bb_39:
    zT_121 = node.kind;
    zT_120 = zT_121 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_41;
    z_bb_40:
    zT_120 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_120) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_127 = node.kind;
    zT_126 = zT_127 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_44;
    z_bb_43:
    zT_126 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_126) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_133 = node.kind;
    zT_132 = zT_133 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_47;
    z_bb_46:
    zT_132 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_132) goto z_bb_49; else goto z_bb_48;
    z_bb_48:
    zT_139 = node.kind;
    zT_138 = zT_139 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_50;
    z_bb_49:
    zT_138 = 1;
    goto z_bb_50;
    z_bb_50:
    if (zT_138) goto z_bb_52; else goto z_bb_51;
    z_bb_51:
    zT_145 = node.kind;
    zT_144 = zT_145 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_53;
    z_bb_52:
    zT_144 = 1;
    goto z_bb_53;
    z_bb_53:
    if (zT_144) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_151 = node.kind;
    zT_150 = zT_151 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_56;
    z_bb_55:
    zT_150 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_150) goto z_bb_58; else goto z_bb_57;
    z_bb_57:
    zT_157 = node.kind;
    zT_156 = zT_157 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_59;
    z_bb_58:
    zT_156 = 1;
    goto z_bb_59;
    z_bb_59:
    if (zT_156) goto z_bb_61; else goto z_bb_60;
    z_bb_60:
    zT_163 = node.kind;
    zT_162 = zT_163 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_62;
    z_bb_61:
    zT_162 = 1;
    goto z_bb_62;
    z_bb_62:
    if (zT_162) goto z_bb_64; else goto z_bb_63;
    z_bb_63:
    zT_169 = node.kind;
    zT_168 = zT_169 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_65;
    z_bb_64:
    zT_168 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_168) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_175 = node.kind;
    zT_174 = zT_175 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_68;
    z_bb_67:
    zT_174 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_174) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_181 = node.kind;
    zT_180 = zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_71;
    z_bb_70:
    zT_180 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_180) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_187 = node.kind;
    zT_186 = zT_187 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_74;
    z_bb_73:
    zT_186 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_186) goto z_bb_76; else goto z_bb_75;
    z_bb_75:
    zT_193 = node.kind;
    zT_192 = zT_193 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_77;
    z_bb_76:
    zT_192 = 1;
    goto z_bb_77;
    z_bb_77:
    if (zT_192) goto z_bb_79; else goto z_bb_78;
    z_bb_78:
    zT_199 = node.kind;
    zT_198 = zT_199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_80;
    z_bb_79:
    zT_198 = 1;
    goto z_bb_80;
    z_bb_80:
    if (zT_198) goto z_bb_82; else goto z_bb_81;
    z_bb_81:
    zT_205 = node.kind;
    zT_204 = zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_83;
    z_bb_82:
    zT_204 = 1;
    goto z_bb_83;
    z_bb_83:
    if (zT_204) goto z_bb_85; else goto z_bb_84;
    z_bb_84:
    zT_211 = node.kind;
    zT_210 = zT_211 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_86;
    z_bb_85:
    zT_210 = 1;
    goto z_bb_86;
    z_bb_86:
    if (zT_210) goto z_bb_88; else goto z_bb_87;
    z_bb_87:
    zT_217 = node.kind;
    zT_216 = zT_217 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_89;
    z_bb_88:
    zT_216 = 1;
    goto z_bb_89;
    z_bb_89:
    if (zT_216) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_222 = node.child_1;
    if ((int)(zT_222 == (unsigned int)(0))) goto z_bb_92; else goto z_bb_93;
    z_bb_91:
    return (int)(0);
    z_bb_92:
    return (int)(0);
    z_bb_93:
    zT_226 = self;
    zT_228 = node.child_1;
    self = zT_226;
    node_idx = zT_228;
    goto z_bb_0;
}

/* astSwitchTerminates */
int zF_A3A1FD27_astSwitchTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_11 = {0};
    unsigned int zT_13;
    int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int* zT_28;
    zT_22A7C88B_AstNode zT_30 = {0};
    unsigned char zT_31;
    int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_37;
    unsigned int zT_38;
    int zT_40 = 0;
    int zT_43;
    unsigned int zT_44;
    zT_38C12417_SemanticAnalyzer* zT_46;
    unsigned int zT_47;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_48;
    int zT_50 = 0;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u prongs;
    int has_else;
    unsigned int pi;
    zT_22A7C88B_AstNode pr;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_850FDF81_astStoreNodeExtraCh(zT_8, zT_9);
    prongs = zT_11;
    zT_13 = prongs.len;
    if ((int)(zT_13 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_18 = 0;
    has_else = zT_18;
    zT_20 = 0;
    pi = zT_20;
    goto z_bb_3;
    z_bb_3:
    zT_22 = prongs.len;
    if ((int)(pi < zT_22)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_25 = self->store;
    zT_28 = prongs.ptr;
    zT_26 = zT_28[pi];
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_25, zT_26);
    pr = zT_30;
    zT_31 = pr.flags;
    if ((int)((unsigned char)(zT_31 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    if (has_else) goto z_bb_11; else goto z_bb_12;
    z_bb_6:
    zT_43 = 1;
    zT_44 = pi + zT_43;
    pi = zT_44;
    goto z_bb_3;
    z_bb_7:
    zT_36 = 1;
    has_else = zT_36;
    goto z_bb_8;
    z_bb_8:
    zT_37 = self;
    zT_38 = pr.child_0;
    zT_40 = zF_AA164297_astTerminates(zT_37, zT_38);
    if ((int)(!zT_40)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    goto z_bb_6;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_46 = self;
    zT_47 = node.child_0;
    zT_48 = prongs;
    zT_50 = zF_DCF9800F_astSwitchExhaustive(zT_46, zT_47, zT_48);
    return zT_50;
}

/* astSwitchExhaustive */
int zF_DCF9800F_astSwitchExhaustive(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_idx, zT_3CB0179A_Slice_zT_05F374B1_u prongs) {
    zT_8EED1867_ResolvedTypeTable* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    unsigned int zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_457ECFEE_EnumPayload* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_457ECFEE_EnumPayload zT_36;
    unsigned short zT_37;
    unsigned int zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_54FF90FA_TaggedUnionPayload* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_54FF90FA_TaggedUnionPayload zT_48;
    unsigned short zT_49;
    unsigned int zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    zT_338B7C76_TypeRegistry* zT_56;
    zT_0B73C507_ErrorSetPayload* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    zT_0B73C507_ErrorSetPayload zT_60;
    unsigned short zT_61;
    unsigned int zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    unsigned int zT_68;
    unsigned int zT_71;
    unsigned int zT_73;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int* zT_81;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_83 = {0};
    unsigned int zT_85;
    unsigned int zT_87;
    int zT_88;
    unsigned int zT_89;
    unsigned int ct;
    zT_D155D06D_Type ty;
    unsigned int member_count;
    unsigned int covered;
    unsigned int pi;
    zT_3CB0179A_Slice_zT_05F374B1_u items;
    zT_4 = self->type_table;
    zT_5 = cond_idx;
    zT_7 = zF_999DCF51_resolvedTypeTableGe(zT_4, zT_5);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_9 = zT_7.value;
    goto z_bb_3;
    z_bb_3:
    ct = zT_9;
    if ((int)(ct == (unsigned int)(0))) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    zT_14 = (unsigned int)((unsigned int)ct) >= zT_17;
    goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_14) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = (unsigned int)ct;
    zT_24 = zT_22[zT_23];
    ty = zT_24;
    zT_26 = 0;
    member_count = zT_26;
    zT_27 = ty.kind;
    if ((int)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_32 = self->registry;
    zT_33 = zT_32->en_items;
    zT_34 = ty.payload_idx;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zT_33[zT_35];
    zT_37 = zT_36.members_count;
    zT_38 = (unsigned int)zT_37;
    member_count = zT_38;
    goto z_bb_10;
    z_bb_10:
    zT_71 = 0;
    covered = zT_71;
    zT_73 = 0;
    pi = zT_73;
    goto z_bb_21;
    z_bb_11:
    zT_39 = ty.kind;
    if ((int)(zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_44 = self->registry;
    zT_45 = zT_44->tu_items;
    zT_46 = ty.payload_idx;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zT_45[zT_47];
    zT_49 = zT_48.fields_count;
    zT_50 = (unsigned int)zT_49;
    member_count = zT_50;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_51 = ty.kind;
    if ((int)(zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_56 = self->registry;
    zT_57 = zT_56->es_items;
    zT_58 = ty.payload_idx;
    zT_59 = (unsigned int)zT_58;
    zT_60 = zT_57[zT_59];
    zT_61 = zT_60.tags_count;
    zT_62 = (unsigned int)zT_61;
    member_count = zT_62;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_63 = ty.kind;
    if ((int)(zT_63 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_68 = 2;
    member_count = zT_68;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    return (int)(0);
    z_bb_21:
    zT_75 = prongs.len;
    if ((int)(pi < zT_75)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_78 = self->store;
    zT_81 = prongs.ptr;
    zT_79 = zT_81[pi];
    zT_83 = zF_850FDF81_astStoreNodeExtraCh(zT_78, zT_79);
    items = zT_83;
    zT_85 = items.len;
    zT_87 = covered + (unsigned int)((unsigned int)zT_85);
    covered = zT_87;
    goto z_bb_24;
    z_bb_23:
    return (int)(covered >= member_count);
    z_bb_24:
    zT_88 = 1;
    zT_89 = pi + zT_88;
    pi = zT_89;
    goto z_bb_21;
}

/* astWhileTerminates */
int zF_FB2132D0_astWhileTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_20 = {0};
    zT_8143F551_AstKind zT_21;
    unsigned char zT_27;
    zT_38C12417_SemanticAnalyzer* zT_33;
    unsigned int zT_34;
    int zT_36 = 0;
    zT_38C12417_SemanticAnalyzer* zT_38;
    unsigned int zT_39;
    int zT_41 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode cond;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((int)(zT_7 == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = node.child_1;
    zT_10 = zT_11 == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_10 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    zT_16 = self->store;
    zT_17 = node.child_0;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    cond = zT_20;
    zT_21 = cond.kind;
    if ((int)(zT_21 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (int)(0);
    z_bb_7:
    zT_27 = cond.flags;
    if ((int)((unsigned char)(zT_27 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (int)(0);
    z_bb_9:
    zT_33 = self;
    zT_34 = node.child_1;
    zT_36 = zF_B5177CCC_astSubtreeHasBreak(zT_33, zT_34);
    if (zT_36) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (int)(0);
    z_bb_11:
    zT_38 = self;
    zT_39 = node.child_1;
    zT_41 = zF_AA164297_astTerminates(zT_38, zT_39);
    return zT_41;
}

/* astSubtreeHasBreak */
int zF_B5177CCC_astSubtreeHasBreak(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned int zT_16;
    int zT_19;
    zT_8143F551_AstKind zT_20;
    int zT_24 = 0;
    int zT_25;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    int zT_29 = 0;
    unsigned int zT_31;
    int zT_34;
    zT_8143F551_AstKind zT_35;
    int zT_39 = 0;
    int zT_40;
    zT_38C12417_SemanticAnalyzer* zT_41;
    unsigned int zT_42;
    int zT_44 = 0;
    unsigned int zT_46;
    int zT_49;
    zT_8143F551_AstKind zT_50;
    int zT_54 = 0;
    int zT_55;
    zT_38C12417_SemanticAnalyzer* zT_56;
    unsigned int zT_57;
    int zT_59 = 0;
    zT_8143F551_AstKind zT_61;
    int zT_63 = 0;
    int zT_64;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    unsigned int zT_68 = 0;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_75 = {0};
    unsigned int zT_77;
    unsigned int zT_79;
    zT_38C12417_SemanticAnalyzer* zT_81;
    unsigned int zT_82;
    unsigned int* zT_83;
    int zT_85 = 0;
    int zT_87;
    unsigned int zT_88;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int ei;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((int)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_16 = node.child_0;
    if ((int)(zT_16 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = node.kind;
    zT_24 = zF_C395F6FD_nodeChildIsNode(zT_20, (unsigned char)(0));
    zT_19 = zT_24;
    goto z_bb_7;
    z_bb_6:
    zT_19 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_19) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = self;
    zT_27 = node.child_0;
    zT_29 = zF_B5177CCC_astSubtreeHasBreak(zT_26, zT_27);
    zT_25 = zT_29;
    goto z_bb_10;
    z_bb_9:
    zT_25 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_25) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_31 = node.child_1;
    if ((int)(zT_31 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = node.kind;
    zT_39 = zF_C395F6FD_nodeChildIsNode(zT_35, (unsigned char)(1));
    zT_34 = zT_39;
    goto z_bb_15;
    z_bb_14:
    zT_34 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_34) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_41 = self;
    zT_42 = node.child_1;
    zT_44 = zF_B5177CCC_astSubtreeHasBreak(zT_41, zT_42);
    zT_40 = zT_44;
    goto z_bb_18;
    z_bb_17:
    zT_40 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_40) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    zT_46 = node.child_2;
    if ((int)(zT_46 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_50 = node.kind;
    zT_54 = zF_C395F6FD_nodeChildIsNode(zT_50, (unsigned char)(2));
    zT_49 = zT_54;
    goto z_bb_23;
    z_bb_22:
    zT_49 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_49) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_56 = self;
    zT_57 = node.child_2;
    zT_59 = zF_B5177CCC_astSubtreeHasBreak(zT_56, zT_57);
    zT_55 = zT_59;
    goto z_bb_26;
    z_bb_25:
    zT_55 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_55) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(1);
    z_bb_28:
    zT_61 = node.kind;
    zT_63 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_61);
    if (zT_63) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_65 = self->store;
    zT_66 = node_idx;
    zT_68 = zF_8BA26B9E_astStoreNodePayload(zT_65, zT_66);
    zT_64 = zT_68 != (unsigned int)(0);
    goto z_bb_31;
    z_bb_30:
    zT_64 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_64) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_72 = self->store;
    zT_73 = node_idx;
    zT_75 = zF_850FDF81_astStoreNodeExtraCh(zT_72, zT_73);
    ec = zT_75;
    zT_77 = 0;
    ei = zT_77;
    goto z_bb_34;
    z_bb_33:
    return (int)(0);
    z_bb_34:
    zT_79 = ec.len;
    if ((int)(ei < zT_79)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_81 = self;
    zT_83 = ec.ptr;
    zT_82 = zT_83[ei];
    zT_85 = zF_B5177CCC_astSubtreeHasBreak(zT_81, zT_82);
    if (zT_85) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_87 = 1;
    zT_88 = ei + zT_87;
    ei = zT_88;
    goto z_bb_34;
    z_bb_38:
    return (int)(1);
    z_bb_39:
    goto z_bb_37;
}

/* semanticAnalyzerStmtWorkPush */
void zF_7AB741D8_semanticAnalyzerStm(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_9154F007_EU_232 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->stmt_work_len;
    zT_3 = self->stmt_work_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->stmt_work_cap;
    if ((int)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->stmt_work_items;
    zT_38 = self->stmt_work_len;
    zT_37[zT_38] = node_idx;
    zT_39 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->stmt_work_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->stmt_work_len;
    if ((int)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->stmt_work_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->stmt_work_items = ndst;
    self->stmt_work_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* pushExpectedType */
void zF_9665A229_pushExpectedType(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_9154F007_EU_232 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->expected_type_stack_len;
    zT_3 = self->expected_type_stack_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->expected_type_stack_cap;
    if ((int)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->expected_type_stack_items;
    zT_38 = self->expected_type_stack_len;
    zT_37[zT_38] = ty;
    zT_39 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->expected_type_stack_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->expected_type_stack_len;
    if ((int)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->expected_type_stack_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->expected_type_stack_items = ndst;
    self->expected_type_stack_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* popExpectedType */
void zF_BC478E78_popExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int zT_4;
    zT_1 = self->expected_type_stack_len;
    if ((int)(zT_1 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_4 - (unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    return;
}

/* topExpectedType */
unsigned int zF_4DE7C2BC_topExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_1 = self->expected_type_stack_len;
    if ((int)(zT_1 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_5 = self->expected_type_stack_items;
    zT_6 = self->expected_type_stack_len;
    zT_8 = zT_6 - (unsigned int)(1);
    zT_9 = zT_5[zT_8];
    return zT_9;
}

/* semanticAnalyzerResolveIfHeader */
void zF_0324C9A3_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_39 = 0;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_939EE900_Arr_unsigned_int_1 zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    int zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    int zT_59;
    zT_22A7C88B_AstNode zT_61 = {0};
    zT_8143F551_AstKind zT_62;
    unsigned int zT_63;
    int zT_64;
    char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    int zT_77;
    char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    int zT_85;
    char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_939EE900_Arr_unsigned_int_1 zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_6B0A7D14_AstStore* zT_102;
    unsigned int zT_103;
    zT_22A7C88B_AstNode zT_106 = {0};
    zT_8143F551_AstKind zT_107;
    unsigned int zT_108;
    int zT_109;
    char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    int zT_116;
    zT_22A7C88B_AstNode node;
    unsigned int icond_t;
    unsigned int icap_idx;
    zT_22A7C88B_AstNode icap_node;
    zT_939EE900_Arr_unsigned_int_1 ifs_b;
    zT_939EE900_Arr_unsigned_int_1 ifs_k;
    zT_22A7C88B_AstNode ifs_cn;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_cm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_c2m;
    zT_939EE900_Arr_unsigned_int_1 ifs_k2;
    zT_22A7C88B_AstNode ifs_cn2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_k2m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    icond_t = zT_11;
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    icap_idx = zT_22;
    zT_24 = self->store;
    zT_25 = icap_idx;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    icap_node = zT_27;
    zT_28 = icap_node.kind;
    if ((int)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_45 = node.child_1;
    zT_46 = 0;
    zT_44[zT_46] = zT_45;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_b[_i] = zT_44[_i];
        _i++;
    }
}
    zT_49 = 0;
    zT_50 = 0;
    zT_48[zT_50] = zT_49;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k[_i] = zT_48[_i];
        _i++;
    }
}
    zT_51 = 0;
    zT_52 = ifs_b[zT_51];
    if ((int)(zT_52 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_33 = self;
    zT_36 = self->store;
    zT_37 = icap_idx;
    zT_39 = zF_8BA26B9E_astStoreNodePayload(zT_36, zT_37);
    zT_34 = zT_39;
    zT_40 = self;
    zT_41 = icond_t;
    zT_42 = zF_3E251D67_semanticAnalyzerCap(zT_40, zT_41);
    zT_35 = zT_42;
    zF_7BD72017_registerLocalDecl(zT_33, zT_34, zT_35);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_56 = self->store;
    zT_59 = 0;
    zT_57 = ifs_b[zT_59];
    zT_61 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    ifs_cn = zT_61;
    zT_62 = ifs_cn.kind;
    zT_63 = (unsigned int)zT_62;
    zT_64 = 0;
    ifs_k[zT_64] = zT_63;
    goto z_bb_6;
    z_bb_6:
    zT_66 = "IFST:N";
    zT_68 = 6;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    ifst_nm = zT_67;
    zT_69 = ifst_nm;
    zT_70 = node_idx;
    zF_C914CB83_markerWriteInt(zT_69, zT_70);
    zT_72 = "IFST:C";
    zT_74 = 6;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    ifst_cm = zT_73;
    zT_75 = ifst_cm;
    zT_77 = 0;
    zT_76 = ifs_b[zT_77];
    zF_C914CB83_markerWriteInt(zT_75, zT_76);
    zT_80 = "IFST:K";
    zT_82 = 6;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    ifst_km = zT_81;
    zT_83 = ifst_km;
    zT_85 = 0;
    zT_84 = ifs_k[zT_85];
    zF_C914CB83_markerWriteInt(zT_83, zT_84);
    zT_88 = "IFST:2";
    zT_90 = 6;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    ifst_c2m = zT_89;
    zT_91 = ifst_c2m;
    zT_92 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_91, zT_92);
    zT_96 = 0;
    zT_97 = 0;
    zT_95[zT_97] = zT_96;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k2[_i] = zT_95[_i];
        _i++;
    }
}
    zT_98 = node.child_2;
    if ((int)(zT_98 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_102 = self->store;
    zT_103 = node.child_2;
    zT_106 = zF_FCDD1D35_astStoreNodeAt(zT_102, zT_103);
    ifs_cn2 = zT_106;
    zT_107 = ifs_cn2.kind;
    zT_108 = (unsigned int)zT_107;
    zT_109 = 0;
    ifs_k2[zT_109] = zT_108;
    goto z_bb_8;
    z_bb_8:
    zT_111 = "IFST:K2";
    zT_113 = 7;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    ifst_k2m = zT_112;
    zT_114 = ifst_k2m;
    zT_116 = 0;
    zT_115 = ifs_k2[zT_116];
    zF_C914CB83_markerWriteInt(zT_114, zT_115);
    return;
}

/* semanticAnalyzerResolveForHeader */
void zF_8CE01C41_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    unsigned int zT_10 = 0;
    char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_8143F551_AstKind zT_30;
    zT_8EED1867_ResolvedTypeTable* zT_33;
    unsigned int zT_34;
    zT_BAEE192E_Opt_10 zT_37 = {0};
    unsigned char zT_38;
    char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_D155D06D_Type* zT_48;
    unsigned int zT_49;
    zT_D155D06D_Type zT_50;
    zT_939EE900_Arr_unsigned_int_1 zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    zT_338B7C76_TypeRegistry* zT_60;
    zT_0BB2A741_SlicePayload* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    zT_0BB2A741_SlicePayload zT_64;
    unsigned int zT_65;
    int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_E834303C_ArrayPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_E834303C_ArrayPayload zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_8143F551_AstKind zT_79;
    int zT_84;
    zT_8143F551_AstKind zT_85;
    int zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    int zT_97;
    int zT_98;
    unsigned int zT_99;
    char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_109;
    unsigned int zT_111 = 0;
    char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    int zT_118;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_38C12417_SemanticAnalyzer* zT_123;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int zT_125;
    unsigned int zT_127 = 0;
    unsigned int* zT_128;
    unsigned int zT_129;
    int zT_130;
    unsigned int zT_131;
    unsigned int* zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_146 = 0;
    char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    int zT_153;
    char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_38C12417_SemanticAnalyzer* zT_166;
    unsigned int zT_167;
    unsigned int* zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned int* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_c_m;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_ck_m;
    zT_BAEE192E_Opt_10 it_tid;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_tid_m;
    zT_D155D06D_Type ty;
    zT_939EE900_Arr_unsigned_int_1 elem_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u a5_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_p_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_e_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u f2_m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node.child_0;
    zT_10 = zF_54F95822_semanticAnalyzerRes(zT_7, zT_8);
    (void)zT_10;
    zT_12 = "FS:C";
    zT_14 = 4;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    fs_c_m = zT_13;
    zT_15 = fs_c_m;
    zT_16 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_19 = self->store;
    zT_20 = node.child_0;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    cnode = zT_23;
    zT_25 = "FS:CK";
    zT_27 = 5;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    fs_ck_m = zT_26;
    zT_28 = fs_ck_m;
    zT_30 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_28, (unsigned int)((unsigned int)zT_30));
    zT_33 = self->type_table;
    zT_34 = node.child_0;
    zT_37 = zF_999DCF51_resolvedTypeTableGe(zT_33, zT_34);
    it_tid = zT_37;
    zT_38 = it_tid.has_value;
    if (zT_38) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    tid = it_tid.value;
    zT_41 = "FS:T";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    fs_tid_m = zT_42;
    zT_44 = fs_tid_m;
    zT_45 = tid;
    zF_C914CB83_markerWriteInt(zT_44, zT_45);
    zT_47 = self->registry;
    zT_48 = zT_47->types_items;
    zT_49 = (unsigned int)tid;
    zT_50 = zT_48[zT_49];
    ty = zT_50;
    zT_53 = 18;
    zT_54 = 0;
    zT_52[zT_54] = zT_53;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        elem_box[_i] = zT_52[_i];
        _i++;
    }
}
    zT_55 = ty.kind;
    if ((int)(zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_160 = node.child_2;
    if ((int)(zT_160 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_3:
    zT_156 = "FS:M\n";
    zT_158 = 5;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    a5_m = zT_157;
    zT_159 = a5_m;
    zF_48AC7B3A_markerWrite(zT_159);
    goto z_bb_2;
    z_bb_4:
    zT_60 = self->registry;
    zT_61 = zT_60->slice_items;
    zT_62 = ty.payload_idx;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zT_61[zT_63];
    zT_65 = zT_64.elem;
    zT_66 = 0;
    elem_box[zT_66] = zT_65;
    goto z_bb_5;
    z_bb_5:
    zT_91 = self->store;
    zT_92 = node_idx;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    if ((int)(zT_94 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_6:
    zT_67 = ty.kind;
    if ((int)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_72 = self->registry;
    zT_73 = zT_72->array_items;
    zT_74 = ty.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    zT_77 = zT_76.elem;
    zT_78 = 0;
    elem_box[zT_78] = zT_77;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_79 = cnode.kind;
    if ((int)(zT_79 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_85 = cnode.kind;
    zT_84 = zT_85 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_12;
    z_bb_11:
    zT_84 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_84) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_90 = 0;
    elem_box[zT_90] = tid;
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    zT_98 = 0;
    zT_99 = elem_box[zT_98];
    zT_97 = zT_99 != (unsigned int)(18);
    goto z_bb_17;
    z_bb_16:
    zT_97 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_97) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_103 = "FS:P";
    zT_105 = 4;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    fs_p_m = zT_104;
    zT_106 = fs_p_m;
    zT_108 = self->store;
    zT_109 = node_idx;
    zT_111 = zF_8BA26B9E_astStoreNodePayload(zT_108, zT_109);
    zT_107 = zT_111;
    zF_C914CB83_markerWriteInt(zT_106, zT_107);
    zT_113 = "FS:E";
    zT_115 = 4;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    fs_e_m = zT_114;
    zT_116 = fs_e_m;
    zT_118 = 0;
    zT_117 = elem_box[zT_118];
    zF_C914CB83_markerWriteInt(zT_116, zT_117);
    zT_120 = self->local_decl_count;
    zT_121 = self->local_decl_cap;
    if ((int)(zT_120 >= zT_121)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_123 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_123);
    goto z_bb_21;
    z_bb_21:
    zT_124 = self->store;
    zT_125 = node_idx;
    zT_127 = zF_8BA26B9E_astStoreNodePayload(zT_124, zT_125);
    zT_128 = self->local_decl_names;
    zT_129 = self->local_decl_count;
    zT_128[zT_129] = zT_127;
    zT_130 = 0;
    zT_131 = elem_box[zT_130];
    zT_132 = self->local_decl_types;
    zT_133 = self->local_decl_count;
    zT_132[zT_133] = zT_131;
    zT_134 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_134 + (unsigned int)(1));
    zT_138 = "D4F:N";
    zT_140 = 5;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    d4f_n = zT_139;
    zT_141 = d4f_n;
    zT_143 = self->store;
    zT_144 = node_idx;
    zT_146 = zF_8BA26B9E_astStoreNodePayload(zT_143, zT_144);
    zT_142 = zT_146;
    zF_C914CB83_markerWriteInt(zT_141, zT_142);
    zT_148 = "D4F:T";
    zT_150 = 5;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    d4f_t = zT_149;
    zT_151 = d4f_t;
    zT_153 = 0;
    zT_152 = elem_box[zT_153];
    zF_C914CB83_markerWriteInt(zT_151, zT_152);
    goto z_bb_19;
    z_bb_22:
    zT_163 = self->local_decl_count;
    zT_164 = self->local_decl_cap;
    if ((int)(zT_163 >= zT_164)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    return;
    z_bb_24:
    zT_166 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_166);
    goto z_bb_25;
    z_bb_25:
    zT_167 = node.child_2;
    zT_168 = self->local_decl_names;
    zT_169 = self->local_decl_count;
    zT_168[zT_169] = zT_167;
    zT_170 = 13;
    zT_171 = self->local_decl_types;
    zT_172 = self->local_decl_count;
    zT_171[zT_172] = zT_170;
    zT_173 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_173 + (unsigned int)(1));
    zT_177 = "FIX2:LN";
    zT_179 = 7;
    zT_178.ptr = zT_177;
    zT_178.len = zT_179;
    f2_m = zT_178;
    zT_180 = f2_m;
    zT_181 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_180, zT_181);
    goto z_bb_23;
}

/* semanticAnalyzerResolveWhileHeader */
void zF_10900223_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_15 = {0};
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_38C12417_SemanticAnalyzer* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_62 = 0;
    zT_38C12417_SemanticAnalyzer* zT_63;
    unsigned int zT_64;
    unsigned int zT_65 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode ws_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_km;
    unsigned int wcond_t;
    unsigned int wcap_idx;
    zT_22A7C88B_AstNode wcap_node;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_1;
    if ((int)(zT_7 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self->store;
    zT_12 = node.child_1;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    ws_node = zT_15;
    zT_17 = "WST:N";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    wst_nm = zT_18;
    zT_20 = wst_nm;
    zT_21 = node_idx;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = "WST:K";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    wst_km = zT_24;
    zT_26 = wst_km;
    zT_28 = ws_node.kind;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    goto z_bb_2;
    z_bb_2:
    zT_31 = self;
    zT_32 = node.child_0;
    zT_34 = zF_54F95822_semanticAnalyzerRes(zT_31, zT_32);
    wcond_t = zT_34;
    zT_35 = self->store;
    zT_36 = node_idx;
    zT_38 = zF_8BA26B9E_astStoreNodePayload(zT_35, zT_36);
    if ((int)(zT_38 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_42 = self->store;
    zT_43 = node_idx;
    zT_45 = zF_8BA26B9E_astStoreNodePayload(zT_42, zT_43);
    wcap_idx = zT_45;
    zT_47 = self->store;
    zT_48 = wcap_idx;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    wcap_node = zT_50;
    zT_51 = wcap_node.kind;
    if ((int)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return;
    z_bb_5:
    zT_56 = self;
    zT_59 = self->store;
    zT_60 = wcap_idx;
    zT_62 = zF_8BA26B9E_astStoreNodePayload(zT_59, zT_60);
    zT_57 = zT_62;
    zT_63 = self;
    zT_64 = wcond_t;
    zT_65 = zF_3E251D67_semanticAnalyzerCap(zT_63, zT_64);
    zT_58 = zT_65;
    zF_7BD72017_registerLocalDecl(zT_56, zT_57, zT_58);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* semanticAnalyzerResolveStmtIter */
void zF_10A0DC35_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int root_node) {
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_21 = {0};
    char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_28;
    char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_8143F551_AstKind zT_36;
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_47 = {0};
    char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_61;
    unsigned int zT_65;
    unsigned int* zT_69;
    unsigned int zT_71;
    unsigned int zT_72;
    char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_99;
    char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_108;
    unsigned int zT_110;
    char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_8143F551_AstKind zT_116;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_124 = 0;
    char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    unsigned int zT_141;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    zT_22A7C88B_AstNode zT_149 = {0};
    char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_8143F551_AstKind zT_156;
    char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    unsigned int zT_167 = 0;
    char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_174;
    unsigned int zT_178;
    unsigned int zT_179;
    zT_6B0A7D14_AstStore* zT_183;
    unsigned int zT_184;
    zT_22A7C88B_AstNode zT_187 = {0};
    zT_8143F551_AstKind zT_188;
    zT_38C12417_SemanticAnalyzer* zT_193;
    unsigned int zT_194;
    unsigned int zT_196 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_200;
    zT_6B0A7D14_AstStore* zT_201;
    zT_338B7C76_TypeRegistry* zT_202;
    zT_3D7259E2_SymbolRegistry* zT_203;
    zT_D3EB6303_StringInterner* zT_204;
    unsigned int zT_205;
    zT_ABC1EBBE_TypeResolveEnv* zT_207;
    unsigned int zT_208;
    unsigned int zT_213 = 0;
    char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_F85C5DED_DiagnosticCollector* zT_220;
    unsigned int zT_223;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_236 = 0;
    unsigned int zT_237;
    zT_8EED1867_ResolvedTypeTable* zT_239;
    unsigned int zT_240;
    zT_BAEE192E_Opt_10 zT_243 = {0};
    unsigned char zT_244;
    zT_ABC1EBBE_TypeResolveEnv zT_247;
    zT_6B0A7D14_AstStore* zT_248;
    zT_338B7C76_TypeRegistry* zT_249;
    zT_3D7259E2_SymbolRegistry* zT_250;
    zT_D3EB6303_StringInterner* zT_251;
    unsigned int zT_252;
    zT_ABC1EBBE_TypeResolveEnv* zT_253;
    unsigned int zT_254;
    unsigned int zT_259 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    char* zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_276;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    int zT_283;
    unsigned char* zT_284;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287 = 0;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned char* zT_296;
    unsigned int zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    char* zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    unsigned int zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_305;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    int zT_311;
    unsigned char* zT_312;
    unsigned int zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    unsigned int zT_315 = 0;
    unsigned int zT_319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    unsigned char* zT_324;
    unsigned int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    char* zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    unsigned int zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    int zT_335;
    unsigned int zT_340;
    unsigned int zT_342;
    unsigned int zT_344;
    char* zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    unsigned int zT_348;
    zT_F85C5DED_DiagnosticCollector* zT_349;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned int zT_354;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_355;
    unsigned int zT_363 = 0;
    unsigned int zT_364;
    zT_6B0A7D14_AstStore* zT_368;
    unsigned int zT_369;
    zT_22A7C88B_AstNode zT_372 = {0};
    char* zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    unsigned int zT_376;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_377;
    zT_8143F551_AstKind zT_379;
    unsigned int zT_385;
    zT_38C12417_SemanticAnalyzer* zT_387;
    unsigned int zT_388;
    zT_38C12417_SemanticAnalyzer* zT_390;
    unsigned int zT_391;
    unsigned int zT_393 = 0;
    zT_38C12417_SemanticAnalyzer* zT_394;
    int zT_398;
    zT_8143F551_AstKind zT_399;
    zT_6B0A7D14_AstStore* zT_405;
    unsigned int zT_406;
    unsigned int zT_409 = 0;
    int zT_411;
    unsigned int zT_412;
    zT_338B7C76_TypeRegistry* zT_413;
    unsigned int zT_414;
    zT_338B7C76_TypeRegistry* zT_416;
    zT_D155D06D_Type* zT_417;
    zT_D155D06D_Type zT_418;
    zT_33EF6BFB_TypeKind zT_419;
    zT_338B7C76_TypeRegistry* zT_425;
    unsigned int zT_427;
    unsigned int zT_430 = 0;
    unsigned int zT_434;
    zT_21D3708C_U32ToU32Map* zT_436;
    unsigned int zT_437;
    unsigned int zT_439 = 0;
    zT_21D3708C_U32ToU32Map* zT_440;
    unsigned int zT_441;
    unsigned int zT_442;
    zT_8EED1867_ResolvedTypeTable* zT_445;
    unsigned int zT_446;
    unsigned int zT_447;
    int zT_450;
    unsigned int zT_451;
    int zT_455;
    zT_8143F551_AstKind zT_456;
    unsigned int zT_462;
    unsigned int zT_464;
    unsigned int zT_466;
    char* zT_468;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_469;
    unsigned int zT_470;
    zT_F85C5DED_DiagnosticCollector* zT_471;
    unsigned int zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_477;
    unsigned int zT_485 = 0;
    int zT_489;
    char* zT_494;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_495;
    unsigned int zT_496;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_497;
    zT_38C12417_SemanticAnalyzer* zT_499;
    unsigned int zT_500;
    unsigned int zT_501;
    unsigned int zT_502;
    unsigned int zT_504 = 0;
    zT_38C12417_SemanticAnalyzer* zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    unsigned int zT_508;
    int zT_510 = 0;
    zT_338B7C76_TypeRegistry* zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    zT_0FB7FB13_CoercionKind zT_516 = 0;
    char* zT_518;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_519;
    unsigned int zT_520;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_521;
    int zT_528;
    zT_338B7C76_TypeRegistry* zT_529;
    unsigned int zT_530;
    unsigned int zT_531;
    int zT_533 = 0;
    zT_66E7D2EF_CoercionTable* zT_534;
    unsigned int zT_535;
    zT_0FB7FB13_CoercionKind zT_536;
    unsigned int zT_537;
    int zT_542;
    zT_338B7C76_TypeRegistry* zT_543;
    unsigned int zT_544;
    unsigned int zT_545;
    int zT_547 = 0;
    unsigned int zT_550;
    unsigned int zT_552;
    unsigned int zT_554;
    char* zT_556;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_557;
    unsigned int zT_558;
    zT_338B7C76_TypeRegistry* zT_560;
    zT_D155D06D_Type* zT_561;
    unsigned int zT_562;
    zT_D155D06D_Type zT_563;
    zT_33EF6BFB_TypeKind zT_564;
    zT_338B7C76_TypeRegistry* zT_566;
    zT_D155D06D_Type* zT_567;
    unsigned int zT_568;
    zT_D155D06D_Type zT_569;
    zT_33EF6BFB_TypeKind zT_570;
    int zT_572;
    unsigned char zT_573;
    zT_38C12417_SemanticAnalyzer* zT_574;
    unsigned int zT_575;
    unsigned int zT_576;
    int zT_577 = 0;
    int zT_578;
    unsigned char zT_579;
    int zT_584;
    zT_338B7C76_TypeRegistry* zT_590;
    zT_42C2D6BF_EUPayload* zT_591;
    zT_338B7C76_TypeRegistry* zT_592;
    zT_D155D06D_Type* zT_593;
    unsigned int zT_594;
    zT_D155D06D_Type zT_595;
    unsigned int zT_596;
    unsigned int zT_597;
    zT_42C2D6BF_EUPayload zT_598;
    zT_338B7C76_TypeRegistry* zT_600;
    zT_42C2D6BF_EUPayload* zT_601;
    zT_338B7C76_TypeRegistry* zT_602;
    zT_D155D06D_Type* zT_603;
    unsigned int zT_604;
    zT_D155D06D_Type zT_605;
    unsigned int zT_606;
    unsigned int zT_607;
    zT_42C2D6BF_EUPayload zT_608;
    unsigned int zT_609;
    unsigned int zT_610;
    int zT_612;
    unsigned char zT_613;
    zT_F85C5DED_DiagnosticCollector* zT_615;
    unsigned char zT_616;
    unsigned int zT_618;
    unsigned int zT_619;
    unsigned int zT_620;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_621;
    unsigned int zT_625 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_626;
    unsigned int zT_627;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_628;
    zT_33EF6BFB_TypeKind zT_630;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_631 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_632;
    unsigned int zT_633;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_634;
    zT_33EF6BFB_TypeKind zT_636;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_637 = {0};
    char* zT_644;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_645;
    unsigned int zT_646;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_647;
    char* zT_649;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_650;
    unsigned int zT_651;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_652;
    unsigned int zT_654;
    unsigned int zT_656;
    unsigned int zT_658;
    char* zT_660;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_661;
    unsigned int zT_662;
    zT_F85C5DED_DiagnosticCollector* zT_663;
    unsigned int zT_666;
    unsigned int zT_667;
    unsigned int zT_668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_669;
    unsigned int zT_674 = 0;
    zT_66E7D2EF_CoercionTable* zT_676;
    unsigned int zT_677;
    zT_5CC037A7_Opt_194 zT_680 = {0};
    unsigned char zT_681;
    zT_8EED1867_ResolvedTypeTable* zT_683;
    unsigned int zT_684;
    unsigned int zT_685;
    unsigned int zT_688;
    unsigned int zT_689;
    zT_38C12417_SemanticAnalyzer* zT_691;
    zT_6B0A7D14_AstStore* zT_695;
    unsigned int zT_696;
    unsigned int zT_698 = 0;
    unsigned int* zT_699;
    unsigned int zT_700;
    unsigned int* zT_701;
    unsigned int zT_702;
    unsigned int zT_703;
    unsigned int zT_707;
    zT_6B0A7D14_AstStore* zT_711;
    unsigned int zT_712;
    unsigned int zT_714 = 0;
    zT_79FAE712_u64 zT_716;
    zT_338B7C76_TypeRegistry* zT_717;
    zT_79FAE712_u64 zT_718;
    unsigned int zT_719;
    char* zT_722;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_723;
    unsigned int zT_724;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_725;
    unsigned int zT_726;
    zT_6B0A7D14_AstStore* zT_727;
    unsigned int zT_728;
    unsigned int zT_730 = 0;
    char* zT_732;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_733;
    unsigned int zT_734;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    unsigned int zT_736;
    zT_8143F551_AstKind zT_737;
    zT_38C12417_SemanticAnalyzer* zT_742;
    unsigned int zT_743;
    unsigned int zT_744;
    zT_38C12417_SemanticAnalyzer* zT_747;
    unsigned int zT_748;
    unsigned int zT_750;
    zT_38C12417_SemanticAnalyzer* zT_753;
    unsigned int zT_754;
    zT_8143F551_AstKind zT_756;
    zT_38C12417_SemanticAnalyzer* zT_761;
    unsigned int zT_762;
    unsigned int zT_763;
    zT_38C12417_SemanticAnalyzer* zT_766;
    unsigned int zT_767;
    zT_8143F551_AstKind zT_769;
    zT_38C12417_SemanticAnalyzer* zT_774;
    unsigned int zT_775;
    unsigned int zT_776;
    zT_38C12417_SemanticAnalyzer* zT_779;
    unsigned int zT_780;
    zT_8143F551_AstKind zT_782;
    zT_38C12417_SemanticAnalyzer* zT_787;
    unsigned int zT_788;
    zT_8143F551_AstKind zT_789;
    int zT_794;
    zT_8143F551_AstKind zT_795;
    int zT_800;
    zT_8143F551_AstKind zT_801;
    int zT_806;
    zT_8143F551_AstKind zT_807;
    int zT_812;
    zT_8143F551_AstKind zT_813;
    int zT_818;
    zT_8143F551_AstKind zT_819;
    int zT_824;
    zT_8143F551_AstKind zT_825;
    int zT_830;
    zT_8143F551_AstKind zT_831;
    int zT_836;
    zT_8143F551_AstKind zT_837;
    int zT_842;
    zT_8143F551_AstKind zT_843;
    int zT_848;
    zT_8143F551_AstKind zT_849;
    int zT_854;
    zT_8143F551_AstKind zT_855;
    int zT_860;
    zT_8143F551_AstKind zT_861;
    int zT_866;
    zT_8143F551_AstKind zT_867;
    int zT_872;
    zT_8143F551_AstKind zT_873;
    int zT_878;
    zT_8143F551_AstKind zT_879;
    int zT_884;
    zT_8143F551_AstKind zT_885;
    int zT_890;
    zT_8143F551_AstKind zT_891;
    zT_38C12417_SemanticAnalyzer* zT_896;
    unsigned int zT_897;
    unsigned int zT_898 = 0;
    zT_8143F551_AstKind zT_899;
    unsigned int zT_904;
    zT_38C12417_SemanticAnalyzer* zT_907;
    unsigned int zT_908;
    zT_8143F551_AstKind zT_910;
    int zT_915;
    zT_8143F551_AstKind zT_916;
    unsigned int zT_921;
    unsigned int zT_924;
    zT_38C12417_SemanticAnalyzer* zT_927;
    unsigned int zT_928;
    unsigned int zT_930;
    zT_8143F551_AstKind zT_933;
    zT_8143F551_AstKind zT_938;
    char* zT_944;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_945;
    unsigned int zT_946;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_947;
    unsigned int zT_948;
    char* zT_950;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_951;
    unsigned int zT_952;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_953;
    zT_8143F551_AstKind zT_955;
    unsigned int zT_957;
    char* zT_961;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_962;
    unsigned int zT_963;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_964;
    unsigned int zT_965;
    zT_38C12417_SemanticAnalyzer* zT_968;
    unsigned int zT_969;
    unsigned int zT_970 = 0;
    int zT_973;
    zT_338B7C76_TypeRegistry* zT_975;
    unsigned int zT_976;
    int zT_978;
    zT_338B7C76_TypeRegistry* zT_979;
    zT_D155D06D_Type* zT_980;
    unsigned int zT_981;
    zT_D155D06D_Type zT_982;
    zT_33EF6BFB_TypeKind zT_983;
    unsigned int zT_989;
    unsigned int zT_991;
    unsigned int zT_993;
    char* zT_995;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_996;
    unsigned int zT_997;
    zT_F85C5DED_DiagnosticCollector* zT_998;
    unsigned int zT_1001;
    unsigned int zT_1002;
    unsigned int zT_1003;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1004;
    unsigned int zT_1012 = 0;
    unsigned int zT_1013;
    zT_6B0A7D14_AstStore* zT_1017;
    unsigned int zT_1018;
    zT_22A7C88B_AstNode zT_1021 = {0};
    zT_8143F551_AstKind zT_1022;
    unsigned int zT_1027;
    zT_6B0A7D14_AstStore* zT_1031;
    unsigned int zT_1032;
    zT_22A7C88B_AstNode zT_1035 = {0};
    zT_8143F551_AstKind zT_1036;
    unsigned int sp_base;
    unsigned int node_idx;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u spk_m;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_cm;
    unsigned int i;
    unsigned int ci;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_nm;
    zT_8143F551_AstKind cnode_k;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u bcej;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd2_m;
    unsigned int decl_type;
    zT_22A7C88B_AstNode inode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10k_m;
    zT_22A7C88B_AstNode ann;
    zT_BAEE192E_Opt_10 rt;
    zT_ABC1EBBE_TypeResolveEnv cd_env;
    unsigned int cd_full;
    zT_8F083A69_Slice_zT_0B42B2F8_u ut_msg;
    unsigned int t;
    zT_ABC1EBBE_TypeResolveEnv tre_env_vd;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1m;
    zT_5A26C2ED_Arr_unsigned_char_1 b1nb;
    unsigned int b1nl;
    unsigned int b1ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1c;
    zT_5A26C2ED_Arr_unsigned_char_1 b1tb;
    unsigned int b1tl;
    unsigned int b1ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1nl2;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui_msg;
    zT_22A7C88B_AstNode init_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ik_m;
    unsigned int vd_exp;
    unsigned int it;
    unsigned int name_id;
    unsigned int ei;
    unsigned int ord;
    unsigned int es_type_id;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs4_m;
    unsigned int it_eff;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u ckv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmd_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdag_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vfvd_m;
    unsigned int vsp;
    unsigned int vep;
    zT_8F083A69_Slice_zT_0B42B2F8_u vv_msg;
    zT_5CC037A7_Opt_194 ct_entry;
    zT_79FAE712_u64 ck_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u regcp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u regct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_c0m;
    unsigned int els_r;
    unsigned int eisp;
    unsigned int eiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ei_msg;
    zT_22A7C88B_AstNode nc;
    zT_3 = self->stmt_work_len;
    sp_base = zT_3;
    zT_4 = self;
    zT_5 = root_node;
    zF_7AB741D8_semanticAnalyzerStm(zT_4, zT_5);
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->stmt_work_len;
    if ((int)(zT_6 > sp_base)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_8 - (unsigned int)(1));
    zT_12 = self->stmt_work_items;
    zT_13 = self->stmt_work_len;
    zT_14 = zT_12[zT_13];
    node_idx = zT_14;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_18 = self->store;
    zT_19 = node_idx;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    node = zT_21;
    zT_23 = "SP:n";
    zT_25 = 4;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    sp_m = zT_24;
    zT_26 = sp_m;
    zT_28 = self->stmt_work_len;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    zT_31 = "SP:K";
    zT_33 = 4;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    spk_m = zT_32;
    zT_34 = spk_m;
    zT_36 = node.kind;
    zF_C914CB83_markerWriteInt(zT_34, (unsigned int)((unsigned int)zT_36));
    zT_38 = node.kind;
    if ((int)(zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_44 = self->store;
    zT_45 = node_idx;
    zT_47 = zF_850FDF81_astStoreNodeExtraCh(zT_44, zT_45);
    children = zT_47;
    zT_49 = "BLK:N";
    zT_51 = 5;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    blk_nm = zT_50;
    zT_52 = blk_nm;
    zT_53 = node_idx;
    zF_C914CB83_markerWriteInt(zT_52, zT_53);
    zT_55 = "BLK:C";
    zT_57 = 5;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    blk_cm = zT_56;
    zT_58 = blk_cm;
    zT_61 = children.len;
    zF_C914CB83_markerWriteInt(zT_58, (unsigned int)((unsigned int)zT_61));
    zT_65 = children.len;
    i = zT_65;
    goto z_bb_10;
    z_bb_8:
    zT_1013 = node.child_0;
    if ((int)(zT_1013 != (unsigned int)(0))) goto z_bb_208; else goto z_bb_209;
    z_bb_9:
    zT_116 = node.kind;
    if ((int)(zT_116 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_14; else goto z_bb_16;
    z_bb_10:
    if ((int)(i > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_69 = children.ptr;
    zT_71 = i - (unsigned int)(1);
    zT_72 = zT_69[zT_71];
    ci = zT_72;
    zT_74 = "BCK:B";
    zT_76 = 5;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    bc_m = zT_75;
    zT_77 = bc_m;
    zT_78 = node_idx;
    zF_C914CB83_markerWriteInt(zT_77, zT_78);
    zT_80 = "BCK:I";
    zT_82 = 5;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    bc_im = zT_81;
    zT_83 = bc_im;
    zF_C914CB83_markerWriteInt(zT_83, (unsigned int)((unsigned int)(unsigned int)(i - (unsigned int)(1))));
    zT_89 = "BCK:N";
    zT_91 = 5;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    bc_nm = zT_90;
    zT_92 = bc_nm;
    zT_93 = ci;
    zF_C914CB83_markerWriteInt(zT_92, zT_93);
    zT_95 = self->store;
    zT_96 = ci;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_95, zT_96);
    zT_99 = zT_98.kind;
    cnode_k = zT_99;
    zT_101 = "BCK:K";
    zT_103 = 5;
    zT_102.ptr = zT_101;
    zT_102.len = zT_103;
    bc_km = zT_102;
    zT_104 = bc_km;
    zF_C914CB83_markerWriteInt(zT_104, (unsigned int)((unsigned int)cnode_k));
    zT_107 = self;
    zT_108 = ci;
    zF_7AB741D8_semanticAnalyzerStm(zT_107, zT_108);
    goto z_bb_13;
    z_bb_12:
    zT_112 = "]\n";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    bcej = zT_113;
    zT_115 = bcej;
    zF_48AC7B3A_markerWrite(zT_115);
    goto z_bb_8;
    z_bb_13:
    zT_110 = i - (unsigned int)(1);
    i = zT_110;
    goto z_bb_10;
    z_bb_14:
    zT_121 = self->store;
    zT_122 = node_idx;
    zT_124 = zF_8BA26B9E_astStoreNodePayload(zT_121, zT_122);
    if ((int)(zT_124 == (unsigned int)(55))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_737 = node.kind;
    if ((int)(zT_737 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_105; else goto z_bb_107;
    z_bb_17:
    zT_128 = "D10:C0";
    zT_130 = 6;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    d10n_m = zT_129;
    zT_131 = d10n_m;
    zT_132 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_131, zT_132);
    zT_135 = "D10:C1";
    zT_137 = 6;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    d10c_m = zT_136;
    zT_138 = d10c_m;
    zT_139 = node.child_1;
    zF_C914CB83_markerWriteInt(zT_138, zT_139);
    zT_141 = node.child_1;
    if ((int)(zT_141 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_159 = "VD:N";
    zT_161 = 4;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    vd_m = zT_160;
    zT_162 = vd_m;
    zT_164 = self->store;
    zT_165 = node_idx;
    zT_167 = zF_8BA26B9E_astStoreNodePayload(zT_164, zT_165);
    zT_163 = zT_167;
    zF_C914CB83_markerWriteInt(zT_162, zT_163);
    zT_169 = "VD:C";
    zT_171 = 4;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    vd2_m = zT_170;
    zT_172 = vd2_m;
    zT_174 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_172, (unsigned int)((unsigned int)zT_174));
    zT_178 = 18;
    decl_type = zT_178;
    zT_179 = node.child_0;
    if ((int)(zT_179 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_145 = self->store;
    zT_146 = node.child_1;
    zT_149 = zF_FCDD1D35_astStoreNodeAt(zT_145, zT_146);
    inode = zT_149;
    zT_151 = "D10:IK";
    zT_153 = 6;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    d10k_m = zT_152;
    zT_154 = d10k_m;
    zT_156 = inode.kind;
    zF_C914CB83_markerWriteInt(zT_154, (unsigned int)((unsigned int)zT_156));
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_183 = self->store;
    zT_184 = node.child_0;
    zT_187 = zF_FCDD1D35_astStoreNodeAt(zT_183, zT_184);
    ann = zT_187;
    zT_188 = ann.kind;
    if ((int)(zT_188 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_35; else goto z_bb_36;
    z_bb_23:
    zT_193 = self;
    zT_194 = node.child_0;
    zT_196 = zF_54F95822_semanticAnalyzerRes(zT_193, zT_194);
    decl_type = zT_196;
    if ((int)(decl_type == (unsigned int)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_239 = self->type_table;
    zT_240 = node.child_0;
    zT_243 = zF_999DCF51_resolvedTypeTableGe(zT_239, zT_240);
    rt = zT_243;
    zT_244 = rt.has_value;
    if (zT_244) goto z_bb_30; else goto z_bb_32;
    z_bb_26:
    zT_201 = self->store;
    zT_200.store = zT_201;
    zT_202 = self->registry;
    zT_200.typereg = zT_202;
    zT_203 = self->symbols;
    zT_200.symbol_reg = zT_203;
    zT_204 = self->interner;
    zT_200.interner = zT_204;
    zT_205 = self->module_id;
    zT_200.module_id = zT_205;
    cd_env = zT_200;
    zT_207 = &cd_env;
    zT_208 = node.child_0;
    zT_213 = zF_F2107C15_resolveTypeExprFull(zT_207, zT_208, (unsigned int)(0));
    cd_full = zT_213;
    if ((int)(cd_full == (unsigned int)(18))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_217 = "unknown type in variable declaration";
    zT_219 = 36;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    ut_msg = zT_218;
    zT_220 = self->diag;
    zT_223 = self->source_file_id;
    zT_224 = ann.span_start;
    zT_232 = ann.span_start;
    zT_233 = ann.span_len;
    zT_226 = ut_msg;
    zT_236 = zF_C82559AC_diagnosticCollector(zT_220, (unsigned char)(0), (unsigned short)(3000), zT_223, zT_224, (unsigned int)(zT_232 + (unsigned int)((unsigned int)zT_233)), zT_226);
    (void)zT_236;
    zT_237 = 18;
    decl_type = zT_237;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    t = rt.value;
    decl_type = t;
    goto z_bb_31;
    z_bb_31:
    goto z_bb_24;
    z_bb_32:
    zT_248 = self->store;
    zT_247.store = zT_248;
    zT_249 = self->registry;
    zT_247.typereg = zT_249;
    zT_250 = self->symbols;
    zT_247.symbol_reg = zT_250;
    zT_251 = self->interner;
    zT_247.interner = zT_251;
    zT_252 = self->module_id;
    zT_247.module_id = zT_252;
    tre_env_vd = zT_247;
    zT_253 = &tre_env_vd;
    zT_254 = node.child_0;
    zT_259 = zF_F2107C15_resolveTypeExprFull(zT_253, zT_254, (unsigned int)(0));
    decl_type = zT_259;
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_262 = self->type_table;
    zT_263 = node.child_0;
    zT_264 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_262, zT_263, zT_264);
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_271 = "VRT:";
    zT_273 = 4;
    zT_272.ptr = zT_271;
    zT_272.len = zT_273;
    b1m = zT_272;
    zT_274 = b1m;
    zF_48AC7B3A_markerWrite(zT_274);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_276[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1nb[_i] = zT_276[_i];
        _i++;
    }
}
    zT_278 = node.child_0;
    zT_283 = 0;
    zT_284 = (unsigned char*)((unsigned char*)b1nb) + zT_283;
    zT_285 = (unsigned int)(10) - zT_283;
    zT_286.ptr = zT_284;
    zT_286.len = zT_285;
    zT_279 = zT_286;
    zT_287 = zF_A7504564_itoa(zT_278, zT_279);
    b1nl = zT_287;
    zT_291 = (unsigned int)(9) - (unsigned int)((unsigned int)b1nl);
    b1ns = zT_291;
    zT_296 = (unsigned char*)((unsigned char*)b1nb) + b1ns;
    zT_297 = (unsigned int)(9) - b1ns;
    zT_298.ptr = zT_296;
    zT_298.len = zT_297;
    zT_292 = zT_298;
    zF_48AC7B3A_markerWrite(zT_292);
    zT_300 = ":";
    zT_302 = 1;
    zT_301.ptr = zT_300;
    zT_301.len = zT_302;
    b1c = zT_301;
    zT_303 = b1c;
    zF_48AC7B3A_markerWrite(zT_303);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_305[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1tb[_i] = zT_305[_i];
        _i++;
    }
}
    zT_307 = decl_type;
    zT_311 = 0;
    zT_312 = (unsigned char*)((unsigned char*)b1tb) + zT_311;
    zT_313 = (unsigned int)(10) - zT_311;
    zT_314.ptr = zT_312;
    zT_314.len = zT_313;
    zT_308 = zT_314;
    zT_315 = zF_A7504564_itoa(zT_307, zT_308);
    b1tl = zT_315;
    zT_319 = (unsigned int)(9) - (unsigned int)((unsigned int)b1tl);
    b1ts = zT_319;
    zT_324 = (unsigned char*)((unsigned char*)b1tb) + b1ts;
    zT_325 = (unsigned int)(9) - b1ts;
    zT_326.ptr = zT_324;
    zT_326.len = zT_325;
    zT_320 = zT_326;
    zF_48AC7B3A_markerWrite(zT_320);
    zT_328 = "\n";
    zT_330 = 1;
    zT_329.ptr = zT_328;
    zT_329.len = zT_330;
    b1nl2 = zT_329;
    zT_331 = b1nl2;
    zF_48AC7B3A_markerWrite(zT_331);
    goto z_bb_36;
    z_bb_36:
    zT_332 = node.child_1;
    if ((int)(zT_332 == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_335 = decl_type != (unsigned int)(18);
    goto z_bb_39;
    z_bb_38:
    zT_335 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_335) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_340 = node.span_start;
    uisp = zT_340;
    zT_342 = node.span_len;
    zT_344 = uisp + (unsigned int)((unsigned int)zT_342);
    uiep = zT_344;
    zT_346 = "variable must be initialized; use '= undefined' to opt out";
    zT_348 = 58;
    zT_347.ptr = zT_346;
    zT_347.len = zT_348;
    ui_msg = zT_347;
    zT_349 = self->diag;
    zT_352 = self->source_file_id;
    zT_353 = uisp;
    zT_354 = uiep;
    zT_355 = ui_msg;
    zT_363 = zF_C82559AC_diagnosticCollector(zT_349, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3014_USE_OF_UNDEFINED_VARIABLE)), zT_352, zT_353, zT_354, zT_355);
    (void)zT_363;
    goto z_bb_41;
    z_bb_41:
    zT_364 = node.child_1;
    if ((int)(zT_364 != (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_368 = self->store;
    zT_369 = node.child_1;
    zT_372 = zF_FCDD1D35_astStoreNodeAt(zT_368, zT_369);
    init_node = zT_372;
    zT_374 = "I:K";
    zT_376 = 3;
    zT_375.ptr = zT_374;
    zT_375.len = zT_376;
    ik_m = zT_375;
    zT_377 = ik_m;
    zT_379 = init_node.kind;
    zF_C914CB83_markerWriteInt(zT_377, (unsigned int)((unsigned int)zT_379));
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    zT_688 = self->local_decl_count;
    zT_689 = self->local_decl_cap;
    if ((int)(zT_688 >= zT_689)) goto z_bb_101; else goto z_bb_102;
    z_bb_44:
    zT_385 = decl_type;
    goto z_bb_46;
    z_bb_45:
    zT_385 = 0;
    goto z_bb_46;
    z_bb_46:
    vd_exp = zT_385;
    zT_387 = self;
    zT_388 = vd_exp;
    zF_9665A229_pushExpectedType(zT_387, zT_388);
    zT_390 = self;
    zT_391 = node.child_1;
    zT_393 = zF_54F95822_semanticAnalyzerRes(zT_390, zT_391);
    it = zT_393;
    zT_394 = self;
    zF_BC478E78_popExpectedType(zT_394);
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_399 = init_node.kind;
    zT_398 = zT_399 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal);
    goto z_bb_49;
    z_bb_48:
    zT_398 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_398) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_405 = self->store;
    zT_406 = node.child_1;
    zT_409 = zF_8BA26B9E_astStoreNodePayload(zT_405, zT_406);
    name_id = zT_409;
    zT_411 = 0;
    zT_412 = (unsigned int)zT_411;
    ei = zT_412;
    goto z_bb_52;
    z_bb_51:
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_60; else goto z_bb_61;
    z_bb_52:
    zT_413 = self->registry;
    zT_414 = zT_413->types_len;
    if ((int)(ei < zT_414)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_416 = self->registry;
    zT_417 = zT_416->types_items;
    zT_418 = zT_417[ei];
    zT_419 = zT_418.kind;
    if ((int)(zT_419 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_450 = 1;
    zT_451 = ei + zT_450;
    ei = zT_451;
    goto z_bb_52;
    z_bb_56:
    zT_425 = self->registry;
    zT_427 = name_id;
    zT_430 = zF_D2ECD176_typeRegistryErrorSe(zT_425, (unsigned int)((unsigned int)ei), zT_427);
    ord = zT_430;
    if ((int)(ord != (unsigned int)(4294967295u))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    goto z_bb_55;
    z_bb_58:
    zT_434 = (unsigned int)ei;
    es_type_id = zT_434;
    zT_436 = self->error_code_registry;
    zT_437 = name_id;
    zT_439 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_436, zT_437);
    reg_code = zT_439;
    zT_440 = self->enum_value_table;
    zT_441 = node.child_1;
    zT_442 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_440, zT_441, zT_442);
    zT_445 = self->type_table;
    zT_446 = node.child_1;
    zT_447 = es_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_445, zT_446, zT_447);
    it = es_type_id;
    goto z_bb_54;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    zT_456 = init_node.kind;
    zT_455 = zT_456 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_62;
    z_bb_61:
    zT_455 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_455) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_462 = init_node.span_start;
    sp = zT_462;
    zT_464 = init_node.span_len;
    zT_466 = sp + (unsigned int)((unsigned int)zT_464);
    ep = zT_466;
    zT_468 = "unable to infer type of enum literal without context";
    zT_470 = 52;
    zT_469.ptr = zT_468;
    zT_469.len = zT_470;
    elu_msg = zT_469;
    zT_471 = self->diag;
    zT_474 = self->source_file_id;
    zT_475 = sp;
    zT_476 = ep;
    zT_477 = elu_msg;
    zT_485 = zF_C82559AC_diagnosticCollector(zT_471, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3010_CANNOT_INFER_ENUM_LITERAL_TYPE)), zT_474, zT_475, zT_476, zT_477);
    (void)zT_485;
    goto z_bb_64;
    z_bb_64:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_489 = it != decl_type;
    goto z_bb_67;
    z_bb_66:
    zT_489 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_489) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    if ((int)(it == (unsigned int)(17))) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_95; else goto z_bb_96;
    z_bb_70:
    zT_494 = "CS4\n";
    zT_496 = 4;
    zT_495.ptr = zT_494;
    zT_495.len = zT_496;
    cs4_m = zT_495;
    zT_497 = cs4_m;
    zF_48AC7B3A_markerWrite(zT_497);
    goto z_bb_71;
    z_bb_71:
    zT_499 = self;
    zT_500 = node.child_1;
    zT_501 = decl_type;
    zT_502 = it;
    zT_504 = zF_FFC95E09_errLitSrcType(zT_499, zT_500, zT_501, zT_502);
    it_eff = zT_504;
    zT_505 = self;
    zT_506 = node.child_1;
    zT_507 = it_eff;
    zT_508 = decl_type;
    zT_510 = zF_86AAA417_semanticAnalyzerMay(zT_505, zT_506, zT_507, zT_508);
    if (zT_510) goto z_bb_72; else goto z_bb_74;
    z_bb_72:
    goto z_bb_73;
    z_bb_73:
    goto z_bb_69;
    z_bb_74:
    zT_512 = self->registry;
    zT_513 = it_eff;
    zT_514 = decl_type;
    zT_516 = zF_713658BF_classifyCoercion(zT_512, zT_513, zT_514);
    ck = zT_516;
    zT_518 = "CCK:vr";
    zT_520 = 6;
    zT_519.ptr = zT_518;
    zT_519.len = zT_520;
    ckv_m = zT_519;
    zT_521 = ckv_m;
    zF_C914CB83_markerWriteInt(zT_521, (unsigned int)((unsigned int)ck));
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_529 = self->registry;
    zT_530 = it_eff;
    zT_531 = decl_type;
    zT_533 = zF_683AEB7F_typeRegistryIsAssig(zT_529, zT_530, zT_531);
    zT_528 = zT_533;
    goto z_bb_77;
    z_bb_76:
    zT_528 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_528) goto z_bb_78; else goto z_bb_80;
    z_bb_78:
    zT_534 = self->coercion_table;
    zT_535 = node.child_1;
    zT_536 = ck;
    zT_537 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_534, zT_535, zT_536, zT_537);
    goto z_bb_79;
    z_bb_79:
    goto z_bb_73;
    z_bb_80:
    if ((int)(it != (unsigned int)(18))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_543 = self->registry;
    zT_544 = it;
    zT_545 = decl_type;
    zT_547 = zF_683AEB7F_typeRegistryIsAssig(zT_543, zT_544, zT_545);
    zT_542 = !zT_547;
    goto z_bb_83;
    z_bb_82:
    zT_542 = 0;
    goto z_bb_83;
    z_bb_83:
    if (zT_542) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_550 = node.span_start;
    sp = zT_550;
    zT_552 = node.span_len;
    zT_554 = sp + (unsigned int)((unsigned int)zT_552);
    ep = zT_554;
    zT_556 = "type mismatch in variable declaration — initialization type may not be compatible with declared type";
    zT_558 = 102;
    zT_557.ptr = zT_556;
    zT_557.len = zT_558;
    tmd_msg = zT_557;
    zT_560 = self->registry;
    zT_561 = zT_560->types_items;
    zT_562 = (unsigned int)it;
    zT_563 = zT_561[zT_562];
    zT_564 = zT_563.kind;
    sk = zT_564;
    zT_566 = self->registry;
    zT_567 = zT_566->types_items;
    zT_568 = (unsigned int)decl_type;
    zT_569 = zT_567[zT_568];
    zT_570 = zT_569.kind;
    tk = zT_570;
    zT_572 = 1;
    zT_573 = (unsigned char)zT_572;
    level = zT_573;
    zT_574 = self;
    zT_575 = it;
    zT_576 = decl_type;
    zT_577 = zF_148F8E19_semanticAnalyzerFnP(zT_574, zT_575, zT_576);
    if (zT_577) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    goto z_bb_79;
    z_bb_86:
    zT_578 = 0;
    zT_579 = (unsigned char)zT_578;
    level = zT_579;
    goto z_bb_87;
    z_bb_87:
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_584 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_90;
    z_bb_89:
    zT_584 = 0;
    goto z_bb_90;
    z_bb_90:
    if (zT_584) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_590 = self->registry;
    zT_591 = zT_590->eu_items;
    zT_592 = self->registry;
    zT_593 = zT_592->types_items;
    zT_594 = (unsigned int)it;
    zT_595 = zT_593[zT_594];
    zT_596 = zT_595.payload_idx;
    zT_597 = (unsigned int)zT_596;
    zT_598 = zT_591[zT_597];
    eu_src = zT_598;
    zT_600 = self->registry;
    zT_601 = zT_600->eu_items;
    zT_602 = self->registry;
    zT_603 = zT_602->types_items;
    zT_604 = (unsigned int)decl_type;
    zT_605 = zT_603[zT_604];
    zT_606 = zT_605.payload_idx;
    zT_607 = (unsigned int)zT_606;
    zT_608 = zT_601[zT_607];
    eu_tgt = zT_608;
    zT_609 = eu_src.error_set;
    zT_610 = eu_tgt.error_set;
    if ((int)(zT_609 == zT_610)) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_615 = self->diag;
    zT_616 = level;
    zT_618 = self->source_file_id;
    zT_619 = sp;
    zT_620 = ep;
    zT_621 = tmd_msg;
    zT_625 = zF_C82559AC_diagnosticCollector(zT_615, zT_616, (unsigned short)(3000), zT_618, zT_619, zT_620, zT_621);
    di = zT_625;
    zT_626 = self->diag;
    zT_627 = di;
    zT_630 = sk;
    zT_631 = zF_C14453DE_typeKindSrcStr(zT_630);
    zT_628 = zT_631;
    zF_426E1F18_diagnosticCollector(zT_626, zT_627, zT_628);
    (void)self;
    zT_632 = self->diag;
    zT_633 = di;
    zT_636 = tk;
    zT_637 = zF_CC479241_typeKindTgtStr(zT_636);
    zT_634 = zT_637;
    zF_426E1F18_diagnosticCollector(zT_632, zT_633, zT_634);
    (void)self;
    goto z_bb_85;
    z_bb_93:
    zT_612 = 0;
    zT_613 = (unsigned char)zT_612;
    level = zT_613;
    goto z_bb_94;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    decl_type = it;
    goto z_bb_96;
    z_bb_96:
    if ((int)(decl_type == (unsigned int)(1))) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_644 = "VDIAG:void_var\n";
    zT_646 = 15;
    zT_645.ptr = zT_644;
    zT_645.len = zT_646;
    vdag_m = zT_645;
    zT_647 = vdag_m;
    zF_48AC7B3A_markerWrite(zT_647);
    zT_649 = "VFLOW:vdag\n";
    zT_651 = 11;
    zT_650.ptr = zT_649;
    zT_650.len = zT_651;
    vfvd_m = zT_650;
    zT_652 = vfvd_m;
    zF_48AC7B3A_markerWrite(zT_652);
    zT_654 = node.span_start;
    vsp = zT_654;
    zT_656 = node.span_len;
    zT_658 = vsp + (unsigned int)((unsigned int)zT_656);
    vep = zT_658;
    zT_660 = "cannot declare variable of type void";
    zT_662 = 36;
    zT_661.ptr = zT_660;
    zT_661.len = zT_662;
    vv_msg = zT_661;
    zT_663 = self->diag;
    zT_666 = self->source_file_id;
    zT_667 = vsp;
    zT_668 = vep;
    zT_669 = vv_msg;
    zT_674 = zF_C82559AC_diagnosticCollector(zT_663, (unsigned char)(0), (unsigned short)(3000), zT_666, zT_667, zT_668, zT_669);
    (void)zT_674;
    goto z_bb_98;
    z_bb_98:
    zT_676 = self->coercion_table;
    zT_677 = node.child_1;
    zT_680 = zF_46B66789_coercionTableGet(zT_676, zT_677);
    ct_entry = zT_680;
    zT_681 = ct_entry.has_value;
    if ((int)(!zT_681)) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_683 = self->type_table;
    zT_684 = node.child_1;
    zT_685 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_683, zT_684, zT_685);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_43;
    z_bb_101:
    zT_691 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_691);
    goto z_bb_102;
    z_bb_102:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_695 = self->store;
    zT_696 = node_idx;
    zT_698 = zF_8BA26B9E_astStoreNodePayload(zT_695, zT_696);
    zT_699 = self->local_decl_names;
    zT_700 = self->local_decl_count;
    zT_699[zT_700] = zT_698;
    zT_701 = self->local_decl_types;
    zT_702 = self->local_decl_count;
    zT_701[zT_702] = decl_type;
    zT_703 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_703 + (unsigned int)(1));
    zT_707 = self->module_id;
    zT_711 = self->store;
    zT_712 = node_idx;
    zT_714 = zF_8BA26B9E_astStoreNodePayload(zT_711, zT_712);
    zT_716 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_707) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_714);
    ck_1 = zT_716;
    zT_717 = self->registry;
    zT_718 = ck_1;
    zT_719 = decl_type;
    zF_5E95558D_nameCachePut(zT_717, zT_718, zT_719);
    zT_722 = "REG:cp";
    zT_724 = 6;
    zT_723.ptr = zT_722;
    zT_723.len = zT_724;
    regcp_m = zT_723;
    zT_725 = regcp_m;
    zT_727 = self->store;
    zT_728 = node_idx;
    zT_730 = zF_8BA26B9E_astStoreNodePayload(zT_727, zT_728);
    zT_726 = zT_730;
    zF_C914CB83_markerWriteInt(zT_725, zT_726);
    zT_732 = "REG:ct";
    zT_734 = 6;
    zT_733.ptr = zT_732;
    zT_733.len = zT_734;
    regct_m = zT_733;
    zT_735 = regct_m;
    zT_736 = decl_type;
    zF_C914CB83_markerWriteInt(zT_735, zT_736);
    goto z_bb_104;
    z_bb_104:
    goto z_bb_15;
    z_bb_105:
    zT_742 = self;
    zT_743 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_742, zT_743);
    zT_744 = node.child_2;
    if ((int)(zT_744 != (unsigned int)(0))) goto z_bb_108; else goto z_bb_109;
    z_bb_106:
    goto z_bb_15;
    z_bb_107:
    zT_756 = node.kind;
    if ((int)(zT_756 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_112; else goto z_bb_114;
    z_bb_108:
    zT_747 = self;
    zT_748 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_747, zT_748);
    goto z_bb_109;
    z_bb_109:
    zT_750 = node.child_1;
    if ((int)(zT_750 != (unsigned int)(0))) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_753 = self;
    zT_754 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_753, zT_754);
    goto z_bb_111;
    z_bb_111:
    goto z_bb_106;
    z_bb_112:
    zT_761 = self;
    zT_762 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_761, zT_762);
    zT_763 = node.child_1;
    if ((int)(zT_763 != (unsigned int)(0))) goto z_bb_115; else goto z_bb_116;
    z_bb_113:
    goto z_bb_106;
    z_bb_114:
    zT_769 = node.kind;
    if ((int)(zT_769 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_117; else goto z_bb_119;
    z_bb_115:
    zT_766 = self;
    zT_767 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_766, zT_767);
    goto z_bb_116;
    z_bb_116:
    goto z_bb_113;
    z_bb_117:
    zT_774 = self;
    zT_775 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_774, zT_775);
    zT_776 = node.child_1;
    if ((int)(zT_776 != (unsigned int)(0))) goto z_bb_120; else goto z_bb_121;
    z_bb_118:
    goto z_bb_113;
    z_bb_119:
    zT_782 = node.kind;
    if ((int)(zT_782 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_122; else goto z_bb_124;
    z_bb_120:
    zT_779 = self;
    zT_780 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_779, zT_780);
    goto z_bb_121;
    z_bb_121:
    goto z_bb_118;
    z_bb_122:
    zT_787 = self;
    zT_788 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_787, zT_788);
    goto z_bb_123;
    z_bb_123:
    goto z_bb_118;
    z_bb_124:
    zT_789 = node.kind;
    if ((int)(zT_789 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_126; else goto z_bb_125;
    z_bb_125:
    zT_795 = node.kind;
    zT_794 = zT_795 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_127;
    z_bb_126:
    zT_794 = 1;
    goto z_bb_127;
    z_bb_127:
    if (zT_794) goto z_bb_129; else goto z_bb_128;
    z_bb_128:
    zT_801 = node.kind;
    zT_800 = zT_801 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_130;
    z_bb_129:
    zT_800 = 1;
    goto z_bb_130;
    z_bb_130:
    if (zT_800) goto z_bb_132; else goto z_bb_131;
    z_bb_131:
    zT_807 = node.kind;
    zT_806 = zT_807 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_133;
    z_bb_132:
    zT_806 = 1;
    goto z_bb_133;
    z_bb_133:
    if (zT_806) goto z_bb_135; else goto z_bb_134;
    z_bb_134:
    zT_813 = node.kind;
    zT_812 = zT_813 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_136;
    z_bb_135:
    zT_812 = 1;
    goto z_bb_136;
    z_bb_136:
    if (zT_812) goto z_bb_138; else goto z_bb_137;
    z_bb_137:
    zT_819 = node.kind;
    zT_818 = zT_819 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_139;
    z_bb_138:
    zT_818 = 1;
    goto z_bb_139;
    z_bb_139:
    if (zT_818) goto z_bb_141; else goto z_bb_140;
    z_bb_140:
    zT_825 = node.kind;
    zT_824 = zT_825 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_142;
    z_bb_141:
    zT_824 = 1;
    goto z_bb_142;
    z_bb_142:
    if (zT_824) goto z_bb_144; else goto z_bb_143;
    z_bb_143:
    zT_831 = node.kind;
    zT_830 = zT_831 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_145;
    z_bb_144:
    zT_830 = 1;
    goto z_bb_145;
    z_bb_145:
    if (zT_830) goto z_bb_147; else goto z_bb_146;
    z_bb_146:
    zT_837 = node.kind;
    zT_836 = zT_837 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_148;
    z_bb_147:
    zT_836 = 1;
    goto z_bb_148;
    z_bb_148:
    if (zT_836) goto z_bb_150; else goto z_bb_149;
    z_bb_149:
    zT_843 = node.kind;
    zT_842 = zT_843 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_151;
    z_bb_150:
    zT_842 = 1;
    goto z_bb_151;
    z_bb_151:
    if (zT_842) goto z_bb_153; else goto z_bb_152;
    z_bb_152:
    zT_849 = node.kind;
    zT_848 = zT_849 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_154;
    z_bb_153:
    zT_848 = 1;
    goto z_bb_154;
    z_bb_154:
    if (zT_848) goto z_bb_156; else goto z_bb_155;
    z_bb_155:
    zT_855 = node.kind;
    zT_854 = zT_855 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_157;
    z_bb_156:
    zT_854 = 1;
    goto z_bb_157;
    z_bb_157:
    if (zT_854) goto z_bb_159; else goto z_bb_158;
    z_bb_158:
    zT_861 = node.kind;
    zT_860 = zT_861 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_160;
    z_bb_159:
    zT_860 = 1;
    goto z_bb_160;
    z_bb_160:
    if (zT_860) goto z_bb_162; else goto z_bb_161;
    z_bb_161:
    zT_867 = node.kind;
    zT_866 = zT_867 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_163;
    z_bb_162:
    zT_866 = 1;
    goto z_bb_163;
    z_bb_163:
    if (zT_866) goto z_bb_165; else goto z_bb_164;
    z_bb_164:
    zT_873 = node.kind;
    zT_872 = zT_873 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_166;
    z_bb_165:
    zT_872 = 1;
    goto z_bb_166;
    z_bb_166:
    if (zT_872) goto z_bb_168; else goto z_bb_167;
    z_bb_167:
    zT_879 = node.kind;
    zT_878 = zT_879 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_169;
    z_bb_168:
    zT_878 = 1;
    goto z_bb_169;
    z_bb_169:
    if (zT_878) goto z_bb_171; else goto z_bb_170;
    z_bb_170:
    zT_885 = node.kind;
    zT_884 = zT_885 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_172;
    z_bb_171:
    zT_884 = 1;
    goto z_bb_172;
    z_bb_172:
    if (zT_884) goto z_bb_174; else goto z_bb_173;
    z_bb_173:
    zT_891 = node.kind;
    zT_890 = zT_891 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_175;
    z_bb_174:
    zT_890 = 1;
    goto z_bb_175;
    z_bb_175:
    if (zT_890) goto z_bb_176; else goto z_bb_178;
    z_bb_176:
    zT_896 = self;
    zT_897 = node_idx;
    zT_898 = zF_54F95822_semanticAnalyzerRes(zT_896, zT_897);
    (void)zT_898;
    goto z_bb_177;
    z_bb_177:
    goto z_bb_123;
    z_bb_178:
    zT_899 = node.kind;
    if ((int)(zT_899 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_179; else goto z_bb_181;
    z_bb_179:
    zT_904 = node.child_0;
    if ((int)(zT_904 != (unsigned int)(0))) goto z_bb_182; else goto z_bb_183;
    z_bb_180:
    goto z_bb_177;
    z_bb_181:
    zT_910 = node.kind;
    if ((int)(zT_910 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_185; else goto z_bb_184;
    z_bb_182:
    zT_907 = self;
    zT_908 = node.child_0;
    zF_7AB741D8_semanticAnalyzerStm(zT_907, zT_908);
    goto z_bb_183;
    z_bb_183:
    goto z_bb_180;
    z_bb_184:
    zT_916 = node.kind;
    zT_915 = zT_916 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_186;
    z_bb_185:
    zT_915 = 1;
    goto z_bb_186;
    z_bb_186:
    if (zT_915) goto z_bb_187; else goto z_bb_189;
    z_bb_187:
    zT_921 = node.child_0;
    if ((int)(zT_921 != (unsigned int)(0))) goto z_bb_190; else goto z_bb_191;
    z_bb_188:
    goto z_bb_180;
    z_bb_189:
    zT_933 = node.kind;
    if ((int)(zT_933 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_192; else goto z_bb_194;
    z_bb_190:
    zT_924 = self->defer_depth;
    self->defer_depth = (unsigned int)(zT_924 + (unsigned int)(1));
    zT_927 = self;
    zT_928 = node.child_0;
    zF_10A0DC35_semanticAnalyzerRes(zT_927, zT_928);
    zT_930 = self->defer_depth;
    self->defer_depth = (unsigned int)(zT_930 - (unsigned int)(1));
    goto z_bb_191;
    z_bb_191:
    goto z_bb_188;
    z_bb_192:
    goto z_bb_193;
    z_bb_193:
    goto z_bb_188;
    z_bb_194:
    zT_938 = node.kind;
    if ((int)(zT_938 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt))) goto z_bb_195; else goto z_bb_197;
    z_bb_195:
    goto z_bb_196;
    z_bb_196:
    goto z_bb_193;
    z_bb_197:
    zT_944 = "ELS:n";
    zT_946 = 5;
    zT_945.ptr = zT_944;
    zT_945.len = zT_946;
    els_nm = zT_945;
    zT_947 = els_nm;
    zT_948 = node_idx;
    zF_C914CB83_markerWriteInt(zT_947, zT_948);
    zT_950 = "ELS:k";
    zT_952 = 5;
    zT_951.ptr = zT_950;
    zT_951.len = zT_952;
    els_km = zT_951;
    zT_953 = els_km;
    zT_955 = node.kind;
    zF_C914CB83_markerWriteInt(zT_953, (unsigned int)((unsigned int)zT_955));
    zT_957 = node.child_0;
    if ((int)(zT_957 != (unsigned int)(0))) goto z_bb_198; else goto z_bb_199;
    z_bb_198:
    zT_961 = "ELS:c";
    zT_963 = 5;
    zT_962.ptr = zT_961;
    zT_962.len = zT_963;
    els_c0m = zT_962;
    zT_964 = els_c0m;
    zT_965 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_964, zT_965);
    goto z_bb_199;
    z_bb_199:
    zT_968 = self;
    zT_969 = node_idx;
    zT_970 = zF_54F95822_semanticAnalyzerRes(zT_968, zT_969);
    els_r = zT_970;
    if ((int)(els_r != (unsigned int)(0))) goto z_bb_200; else goto z_bb_201;
    z_bb_200:
    zT_975 = self->registry;
    zT_976 = zT_975->types_len;
    zT_973 = (unsigned int)((unsigned int)els_r) < zT_976;
    goto z_bb_202;
    z_bb_201:
    zT_973 = 0;
    goto z_bb_202;
    z_bb_202:
    if (zT_973) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    zT_979 = self->registry;
    zT_980 = zT_979->types_items;
    zT_981 = (unsigned int)els_r;
    zT_982 = zT_980[zT_981];
    zT_983 = zT_982.kind;
    zT_978 = zT_983 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_205;
    z_bb_204:
    zT_978 = 0;
    goto z_bb_205;
    z_bb_205:
    if (zT_978) goto z_bb_206; else goto z_bb_207;
    z_bb_206:
    zT_989 = node.span_start;
    eisp = zT_989;
    zT_991 = node.span_len;
    zT_993 = eisp + (unsigned int)((unsigned int)zT_991);
    eiep = zT_993;
    zT_995 = "error union result is ignored; use 'try', 'catch', or assign the result";
    zT_997 = 71;
    zT_996.ptr = zT_995;
    zT_996.len = zT_997;
    ei_msg = zT_996;
    zT_998 = self->diag;
    zT_1001 = self->source_file_id;
    zT_1002 = eisp;
    zT_1003 = eiep;
    zT_1004 = ei_msg;
    zT_1012 = zF_C82559AC_diagnosticCollector(zT_998, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3015_ERROR_IGNORED)), zT_1001, zT_1002, zT_1003, zT_1004);
    (void)zT_1012;
    goto z_bb_207;
    z_bb_207:
    goto z_bb_196;
    z_bb_208:
    zT_1017 = self->store;
    zT_1018 = node.child_0;
    zT_1021 = zF_FCDD1D35_astStoreNodeAt(zT_1017, zT_1018);
    nc = zT_1021;
    zT_1022 = nc.kind;
    if ((int)(zT_1022 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_210; else goto z_bb_211;
    z_bb_209:
    zT_1027 = node.child_1;
    if ((int)(zT_1027 != (unsigned int)(0))) goto z_bb_212; else goto z_bb_213;
    z_bb_210:
    goto z_bb_4;
    z_bb_211:
    goto z_bb_209;
    z_bb_212:
    zT_1031 = self->store;
    zT_1032 = node.child_1;
    zT_1035 = zF_FCDD1D35_astStoreNodeAt(zT_1031, zT_1032);
    nc = zT_1035;
    zT_1036 = nc.kind;
    if ((int)(zT_1036 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_214; else goto z_bb_215;
    z_bb_213:
    goto z_bb_4;
    z_bb_214:
    goto z_bb_4;
    z_bb_215:
    goto z_bb_213;
}

/* semaTraceStep */
unsigned int zF_DE5079F2_semaTraceStep(zT_38C12417_SemanticAnalyzer* self, unsigned int* cur_name, unsigned char* done) {
    zT_3D7259E2_SymbolRegistry* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_50791B23_Opt_842 zT_10 = {0};
    unsigned char zT_11;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    zT_8143F551_AstKind zT_24;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_49;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    zT_22A7C88B_AstNode zT_59 = {0};
    zT_8143F551_AstKind zT_60;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_72 = 0;
    zT_50791B23_Opt_842 ss;
    zT_3A105EF1_Symbol* s;
    zT_22A7C88B_AstNode dn;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode c0;
    unsigned int nn;
    zT_4 = self->symbols;
    zT_5 = self->module_id;
    zT_6 = *cur_name;
    zT_10 = zF_A398987E_symbolRegistryQuali(zT_4, zT_5, zT_6);
    ss = zT_10;
    zT_11 = ss.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s = ss.value;
    zT_13 = s->decl_node;
    if ((int)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_3:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_4:
    zT_19 = self->store;
    zT_20 = s->decl_node;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    dn = zT_23;
    zT_24 = dn.kind;
    if ((int)(zT_24 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_6:
    zT_31 = dn.child_1;
    if ((int)(zT_31 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_8:
    zT_37 = self->store;
    zT_38 = dn.child_1;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_37, zT_38);
    init = zT_41;
    zT_42 = init.kind;
    if ((int)(zT_42 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_10:
    zT_49 = init.child_0;
    if ((int)(zT_49 == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_12:
    zT_55 = self->store;
    zT_56 = init.child_0;
    zT_59 = zF_FCDD1D35_astStoreNodeAt(zT_55, zT_56);
    c0 = zT_59;
    zT_60 = c0.kind;
    if ((int)(zT_60 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_14:
    zT_68 = self->store;
    zT_69 = init.child_0;
    zT_72 = zF_53458827_astStoreIdentifier(zT_68, zT_69);
    nn = zT_72;
    *cur_name = nn;
    return nn;
}

/* semanticAnalyzerResolveIndexAccess */
unsigned int zF_1926BC05_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    unsigned int zT_14;
    zT_38C12417_SemanticAnalyzer* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    zT_38C12417_SemanticAnalyzer* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_28 = {0};
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8143F551_AstKind zT_35;
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_47 = 0;
    char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned char zT_60;
    int zT_63;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int* zT_67;
    unsigned char* zT_68;
    unsigned int zT_71 = 0;
    unsigned int zT_73;
    char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8EED1867_ResolvedTypeTable* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    unsigned int zT_100;
    int zT_103;
    unsigned int zT_104;
    zT_8EED1867_ResolvedTypeTable* zT_107;
    unsigned int zT_108;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_D155D06D_Type* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_D155D06D_Type zT_118;
    zT_338B7C76_TypeRegistry* zT_120;
    unsigned int zT_121;
    unsigned int zT_124 = 0;
    char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    zT_33EF6BFB_TypeKind zT_133;
    zT_338B7C76_TypeRegistry* zT_139;
    zT_666DC2E1_TuplePayload* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_666DC2E1_TuplePayload zT_143;
    zT_338B7C76_TypeRegistry* zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixa_m;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_22A7C88B_AstNode c0_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u c0k_m;
    unsigned int c0_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ste_m;
    unsigned int src_cur_name;
    unsigned int src_depth;
    unsigned int src_name;
    unsigned char src_done;
    zT_8F083A69_Slice_zT_0B42B2F8_u ix_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_s;
    zT_D155D06D_Type bt;
    unsigned int ix_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixr_m;
    unsigned int ret;
    zT_666DC2E1_TuplePayload tp;
    unsigned int r4;
    zT_3 = "IXA:N";
    zT_5 = 5;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ixa_m = zT_4;
    zT_6 = ixa_m;
    zT_7 = node_idx;
    zF_C914CB83_markerWriteInt(zT_6, zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = self->_stub_0;
    saved = zT_14;
    zT_15 = self;
    zT_16 = node.child_1;
    zT_18 = zF_54F95822_semanticAnalyzerRes(zT_15, zT_16);
    (void)zT_18;
    zT_19 = self;
    zT_20 = node.child_0;
    zT_22 = zF_54F95822_semanticAnalyzerRes(zT_19, zT_20);
    self->_stub_0 = zT_22;
    zT_24 = self->store;
    zT_25 = node.child_0;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    c0_node = zT_28;
    zT_30 = "C0K:K";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    c0k_m = zT_31;
    zT_33 = c0k_m;
    zT_35 = c0_node.kind;
    zF_C914CB83_markerWriteInt(zT_33, (unsigned int)((unsigned int)zT_35));
    zT_37 = c0_node.kind;
    if ((int)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_43 = self->store;
    zT_44 = node.child_0;
    zT_47 = zF_53458827_astStoreIdentifier(zT_43, zT_44);
    c0_name_id = zT_47;
    zT_49 = "STE:N";
    zT_51 = 5;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    ste_m = zT_50;
    zT_52 = ste_m;
    zT_53 = node_idx;
    zF_C914CB83_markerWriteInt(zT_52, zT_53);
    src_cur_name = c0_name_id;
    zT_56 = 0;
    src_depth = zT_56;
    zT_58 = 0;
    src_name = zT_58;
    zT_60 = 0;
    src_done = zT_60;
    goto z_bb_3;
    z_bb_2:
    zT_94 = "IX:T";
    zT_96 = 4;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    ix_m = zT_95;
    zT_97 = ix_m;
    zT_98 = self->_stub_0;
    zF_C914CB83_markerWriteInt(zT_97, zT_98);
    zT_100 = self->_stub_0;
    if ((int)(zT_100 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_12;
    z_bb_3:
    if ((int)(src_done == (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_66 = self;
    zT_67 = &src_cur_name;
    zT_68 = &src_done;
    zT_71 = zF_DE5079F2_semaTraceStep(zT_66, zT_67, zT_68);
    src_name = zT_71;
    goto z_bb_6;
    z_bb_5:
    if ((int)(src_name != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_6:
    zT_73 = src_depth + (unsigned int)(1);
    src_depth = zT_73;
    goto z_bb_3;
    z_bb_7:
    zT_63 = src_depth < (unsigned int)(3);
    goto z_bb_9;
    z_bb_8:
    zT_63 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_63) goto z_bb_4; else goto z_bb_5;
    z_bb_10:
    zT_77 = "SRC:N";
    zT_79 = 5;
    zT_78.ptr = zT_77;
    zT_78.len = zT_79;
    srs_n = zT_78;
    zT_80 = srs_n;
    zT_81 = node_idx;
    zF_C914CB83_markerWriteInt(zT_80, zT_81);
    zT_83 = "SRC:S";
    zT_85 = 5;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    srs_s = zT_84;
    zT_86 = srs_s;
    zT_87 = src_name;
    zF_C914CB83_markerWriteInt(zT_86, zT_87);
    zT_88 = self->type_table;
    zT_89 = node.child_0;
    zT_90 = src_name;
    zF_D976B454_resolvedSourceTable(zT_88, zT_89, zT_90);
    (void)self;
    goto z_bb_11;
    z_bb_11:
    goto z_bb_2;
    z_bb_12:
    zT_104 = self->_stub_0;
    zT_103 = zT_104 == (unsigned int)(1);
    goto z_bb_14;
    z_bb_13:
    zT_103 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_103) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    self->_stub_0 = saved;
    zT_107 = self->type_table;
    zT_108 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_107, zT_108, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_16:
    zT_114 = self->registry;
    zT_115 = zT_114->types_items;
    zT_116 = self->_stub_0;
    zT_117 = (unsigned int)zT_116;
    zT_118 = zT_115[zT_117];
    bt = zT_118;
    zT_120 = self->registry;
    zT_121 = self->_stub_0;
    zT_124 = zF_E02A7BC0_typeRegistryIndexed(zT_120, zT_121);
    ix_elem = zT_124;
    if ((int)(ix_elem != (unsigned int)(18))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_128 = "IX:R";
    zT_130 = 4;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    ixr_m = zT_129;
    zT_131 = ixr_m;
    zT_132 = ix_elem;
    zF_C914CB83_markerWriteInt(zT_131, zT_132);
    self->_stub_0 = saved;
    return ix_elem;
    z_bb_18:
    zT_157 = self->_stub_0;
    ret = zT_157;
    self->_stub_0 = saved;
    return ret;
    z_bb_19:
    zT_133 = bt.kind;
    if ((int)(zT_133 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_139 = self->registry;
    zT_140 = zT_139->tup_items;
    zT_141 = bt.payload_idx;
    zT_142 = (unsigned int)zT_141;
    zT_143 = zT_140[zT_142];
    tp = zT_143;
    zT_145 = self->registry;
    zT_146 = zT_145->xt_items;
    zT_147 = tp.elems_start;
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_146[zT_148];
    r4 = zT_149;
    zT_151 = "IX:R";
    zT_153 = 4;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    ixr_m = zT_152;
    zT_154 = ixr_m;
    zT_155 = r4;
    zF_C914CB83_markerWriteInt(zT_154, zT_155);
    self->_stub_0 = saved;
    return r4;
    z_bb_21:
    goto z_bb_18;
}

/* semanticAnalyzerResolveSliceExpr */
unsigned int zF_F902E73E_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    unsigned int zT_13;
    zT_38C12417_SemanticAnalyzer* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    unsigned int zT_20;
    zT_38C12417_SemanticAnalyzer* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    int zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_D155D06D_Type zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    int zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    int zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    int zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_80 = 0;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_88 = 0;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_97;
    zT_33EF6BFB_TypeKind zT_98;
    int zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    int zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    int zT_115;
    zT_33EF6BFB_TypeKind zT_116;
    unsigned char zT_121;
    int zT_126;
    zT_338B7C76_TypeRegistry* zT_128;
    unsigned int zT_129;
    int zT_130;
    unsigned int zT_133 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_D155D06D_Type bt;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl_msg;
    unsigned int ix_elem2;
    int se_is_const;
    unsigned int ret;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    self->_stub_0 = zT_12;
    zT_13 = node.child_1;
    if ((int)(zT_13 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self;
    zT_17 = node.child_1;
    zT_19 = zF_54F95822_semanticAnalyzerRes(zT_16, zT_17);
    (void)zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_20 = node.child_2;
    if ((int)(zT_20 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_23 = self;
    zT_24 = node.child_2;
    zT_26 = zF_54F95822_semanticAnalyzerRes(zT_23, zT_24);
    (void)zT_26;
    goto z_bb_4;
    z_bb_4:
    zT_27 = self->_stub_0;
    if ((int)(zT_27 == (unsigned int)(0))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_31 = self->_stub_0;
    zT_30 = zT_31 == (unsigned int)(1);
    goto z_bb_7;
    z_bb_6:
    zT_30 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_9:
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_38 = self->_stub_0;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    bt = zT_40;
    zT_41 = bt.kind;
    if ((int)(zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_47 = bt.kind;
    zT_46 = zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_12;
    z_bb_11:
    zT_46 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_46) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_53 = bt.kind;
    zT_52 = zT_53 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_15;
    z_bb_14:
    zT_52 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_52) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_59 = bt.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_18;
    z_bb_17:
    zT_58 = 1;
    goto z_bb_18;
    z_bb_18:
    if ((int)(!zT_58)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_66 = "cannot slice base type: expected array, slice, or many-pointer";
    zT_68 = 62;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    sl_msg = zT_67;
    zT_69 = self->diag;
    zT_72 = self->source_file_id;
    zT_73 = node_idx;
    zT_74 = node_idx;
    zT_75 = sl_msg;
    zT_80 = zF_C82559AC_diagnosticCollector(zT_69, (unsigned char)(0), (unsigned short)(2000), zT_72, zT_73, zT_74, zT_75);
    (void)zT_80;
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_20:
    self->_stub_1 = (unsigned int)(1);
    zT_84 = self->registry;
    zT_85 = self->_stub_0;
    zT_88 = zF_E02A7BC0_typeRegistryIndexed(zT_84, zT_85);
    ix_elem2 = zT_88;
    if ((int)(ix_elem2 != (unsigned int)(18))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    self->_stub_1 = ix_elem2;
    goto z_bb_22;
    z_bb_22:
    zT_92 = self->_stub_1;
    if ((int)(zT_92 == (unsigned int)(1))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_91 = self->_stub_0;
    self->_stub_1 = zT_91;
    goto z_bb_22;
    z_bb_24:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_25:
    zT_97 = 0;
    se_is_const = zT_97;
    zT_98 = bt.kind;
    if ((int)(zT_98 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_104 = bt.kind;
    zT_103 = zT_104 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_28;
    z_bb_27:
    zT_103 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_103) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_110 = bt.kind;
    zT_109 = zT_110 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_31;
    z_bb_30:
    zT_109 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_109) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_116 = bt.kind;
    zT_115 = zT_116 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_34;
    z_bb_33:
    zT_115 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_115) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_121 = bt.flags;
    if ((int)((unsigned char)(zT_121 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_128 = self->registry;
    zT_129 = self->_stub_1;
    zT_130 = se_is_const;
    zT_133 = zF_8FC81A87_typeRegistryGetOrCr(zT_128, zT_129, zT_130);
    ret = zT_133;
    self->_stub_0 = saved;
    return ret;
    z_bb_37:
    zT_126 = 1;
    se_is_const = zT_126;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_36;
}

/* semanticAnalyzerResolveTupleLiteral */
unsigned int zF_227D2404_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_13 = {0};
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned int* zT_31;
    unsigned int zT_33 = 0;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    unsigned int zT_43;
    zT_338B7C76_TypeRegistry* zT_44;
    unsigned int zT_45;
    unsigned int zT_49;
    unsigned int zT_51 = 0;
    unsigned int saved;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int start;
    unsigned int i;
    zT_3 = self->store;
    zT_4 = node_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_850FDF81_astStoreNodeExtraCh(zT_10, zT_11);
    ec = zT_13;
    zT_15 = ec.len;
    if ((int)(zT_15 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_2:
    zT_20 = self->registry;
    zT_21 = zT_20->xt_len;
    zT_22 = (unsigned int)zT_21;
    start = zT_22;
    zT_24 = 0;
    zT_25 = (unsigned int)zT_24;
    i = zT_25;
    goto z_bb_3;
    z_bb_3:
    zT_27 = ec.len;
    if ((int)(i < zT_27)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_29 = self;
    zT_31 = ec.ptr;
    zT_30 = zT_31[i];
    zT_33 = zF_54F95822_semanticAnalyzerRes(zT_29, zT_30);
    self->_stub_0 = zT_33;
    zT_34 = self->_stub_0;
    if ((int)(zT_34 == (unsigned int)(1))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    self->_stub_0 = saved;
    zT_44 = self->registry;
    zT_45 = start;
    zT_49 = ec.len;
    zT_51 = zF_9996320F_typeRegistryGetOrCr(zT_44, zT_45, (unsigned short)((unsigned short)zT_49));
    return zT_51;
    z_bb_6:
    zT_43 = i + (unsigned int)(1);
    i = zT_43;
    goto z_bb_3;
    z_bb_7:
    self->_stub_0 = (unsigned int)(6);
    goto z_bb_8;
    z_bb_8:
    zT_38 = self->registry;
    zT_39 = self->_stub_0;
    zF_4C03AE3D_xtAppend(zT_38, zT_39);
    goto z_bb_6;
}

/* semanticAnalyzerResolveArrayInit */
unsigned int zF_F3DAABE0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_44 = {0};
    int zT_46;
    zT_8143F551_AstKind zT_47;
    int zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    zT_22A7C88B_AstNode zT_61 = {0};
    zT_8143F551_AstKind zT_62;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_72 = 0;
    zT_D3EB6303_StringInterner* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77 = {0};
    unsigned int zT_79;
    int zT_82;
    unsigned char* zT_83;
    int zT_84;
    unsigned char zT_85;
    int zT_88;
    int zT_89;
    unsigned int zT_90;
    zT_ABC1EBBE_TypeResolveEnv zT_94;
    zT_6B0A7D14_AstStore* zT_95;
    zT_338B7C76_TypeRegistry* zT_96;
    zT_3D7259E2_SymbolRegistry* zT_97;
    zT_D3EB6303_StringInterner* zT_98;
    unsigned int zT_99;
    zT_ABC1EBBE_TypeResolveEnv* zT_101;
    unsigned int zT_102;
    unsigned int zT_107 = 0;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_115 = {0};
    unsigned int zT_117;
    unsigned int zT_126;
    unsigned int zT_128;
    unsigned int zT_130;
    zT_6B0A7D14_AstStore* zT_133;
    unsigned int zT_134;
    unsigned int* zT_136;
    zT_22A7C88B_AstNode zT_138 = {0};
    unsigned int zT_141;
    zT_8143F551_AstKind zT_142;
    unsigned int zT_147;
    zT_8143F551_AstKind zT_148;
    unsigned int zT_153;
    zT_38C12417_SemanticAnalyzer* zT_154;
    unsigned int zT_155;
    unsigned int* zT_156;
    unsigned int zT_158 = 0;
    unsigned int zT_165;
    zT_338B7C76_TypeRegistry* zT_172;
    unsigned int zT_173;
    unsigned int zT_177;
    unsigned int zT_179 = 0;
    zT_338B7C76_TypeRegistry* zT_181;
    unsigned int zT_182;
    unsigned int zT_186;
    unsigned int zT_188 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    unsigned int annot_tid;
    unsigned int annot_elem_tid;
    zT_BAEE192E_Opt_10 rt;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int t;
    zT_D155D06D_Type tt;
    zT_22A7C88B_AstNode annot_node;
    int inferred_len;
    zT_22A7C88B_AstNode sz_node;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int et;
    unsigned int arr_elem_tid;
    unsigned int aei;
    zT_22A7C88B_AstNode el;
    unsigned int el_tid;
    unsigned int arr_tid;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_11 = 18;
    annot_tid = zT_11;
    zT_14 = 18;
    annot_elem_tid = zT_14;
    zT_15 = node.child_0;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->type_table;
    zT_20 = node.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_112 = self->store;
    zT_113 = node_idx;
    zT_115 = zF_850FDF81_astStoreNodeExtraCh(zT_112, zT_113);
    ec = zT_115;
    zT_117 = ec.len;
    if ((int)(zT_117 == (unsigned int)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_3:
    t = rt.value;
    zT_27 = self->registry;
    zT_28 = zT_27->types_items;
    zT_29 = (unsigned int)t;
    zT_30 = zT_28[zT_29];
    tt = zT_30;
    zT_31 = tt.kind;
    if ((int)(zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((int)(annot_tid == (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    annot_tid = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_40 = self->store;
    zT_41 = node.child_0;
    zT_44 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    annot_node = zT_44;
    zT_46 = 0;
    inferred_len = zT_46;
    zT_47 = annot_node.kind;
    if ((int)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_2;
    z_bb_9:
    zT_53 = annot_node.child_1;
    zT_52 = zT_53 != (unsigned int)(0);
    goto z_bb_11;
    z_bb_10:
    zT_52 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_52) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_57 = self->store;
    zT_58 = annot_node.child_1;
    zT_61 = zF_FCDD1D35_astStoreNodeAt(zT_57, zT_58);
    sz_node = zT_61;
    zT_62 = sz_node.kind;
    if ((int)(zT_62 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    if (inferred_len) goto z_bb_21; else goto z_bb_22;
    z_bb_14:
    zT_68 = self->store;
    zT_69 = annot_node.child_1;
    zT_72 = zF_53458827_astStoreIdentifier(zT_68, zT_69);
    sz_name = zT_72;
    zT_74 = self->interner;
    zT_75 = sz_name;
    zT_77 = zF_9134020D_stringInternerGet(zT_74, zT_75);
    sz_text = zT_77;
    zT_79 = sz_text.len;
    if ((int)(zT_79 == (unsigned int)(1))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_83 = sz_text.ptr;
    zT_84 = 0;
    zT_85 = zT_83[zT_84];
    zT_82 = zT_85 == (unsigned char)(95);
    goto z_bb_18;
    z_bb_17:
    zT_82 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_82) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_88 = 1;
    inferred_len = zT_88;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
    z_bb_21:
    zT_90 = annot_node.child_0;
    zT_89 = zT_90 != (unsigned int)(0);
    goto z_bb_23;
    z_bb_22:
    zT_89 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_89) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_95 = self->store;
    zT_94.store = zT_95;
    zT_96 = self->registry;
    zT_94.typereg = zT_96;
    zT_97 = self->symbols;
    zT_94.symbol_reg = zT_97;
    zT_98 = self->interner;
    zT_94.interner = zT_98;
    zT_99 = self->module_id;
    zT_94.module_id = zT_99;
    tre_env = zT_94;
    zT_101 = &tre_env;
    zT_102 = annot_node.child_0;
    zT_107 = zF_F2107C15_resolveTypeExprFull(zT_101, zT_102, (unsigned int)(0));
    et = zT_107;
    if ((int)(et != (unsigned int)(18))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_8;
    z_bb_26:
    annot_elem_tid = et;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    self->_stub_0 = saved;
    if ((int)(annot_tid != (unsigned int)(18))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_126 = 1;
    arr_elem_tid = zT_126;
    zT_128 = 0;
    aei = zT_128;
    goto z_bb_32;
    z_bb_30:
    return annot_tid;
    z_bb_31:
    return (unsigned int)(1);
    z_bb_32:
    zT_130 = ec.len;
    if ((int)(aei < zT_130)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_133 = self->store;
    zT_136 = ec.ptr;
    zT_134 = zT_136[aei];
    zT_138 = zF_FCDD1D35_astStoreNodeAt(zT_133, zT_134);
    el = zT_138;
    zT_141 = 1;
    el_tid = zT_141;
    zT_142 = el.kind;
    if ((int)(zT_142 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_36; else goto z_bb_38;
    z_bb_34:
    if ((int)(annot_tid != (unsigned int)(18))) goto z_bb_46; else goto z_bb_47;
    z_bb_35:
    zT_165 = aei + (unsigned int)(1);
    aei = zT_165;
    goto z_bb_32;
    z_bb_36:
    zT_147 = 8;
    el_tid = zT_147;
    goto z_bb_37;
    z_bb_37:
    if ((int)(el_tid == (unsigned int)(1))) goto z_bb_42; else goto z_bb_43;
    z_bb_38:
    zT_148 = el.kind;
    if ((int)(zT_148 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_153 = 10;
    el_tid = zT_153;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_154 = self;
    zT_156 = ec.ptr;
    zT_155 = zT_156[aei];
    zT_158 = zF_54F95822_semanticAnalyzerRes(zT_154, zT_155);
    el_tid = zT_158;
    goto z_bb_40;
    z_bb_42:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_43:
    if ((int)(aei == (unsigned int)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    arr_elem_tid = el_tid;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_35;
    z_bb_46:
    self->_stub_0 = saved;
    return annot_tid;
    z_bb_47:
    if ((int)(annot_elem_tid != (unsigned int)(18))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    self->_stub_0 = saved;
    zT_172 = self->registry;
    zT_173 = annot_elem_tid;
    zT_177 = ec.len;
    zT_179 = zF_BA693C74_typeRegistryGetOrCr(zT_172, zT_173, (unsigned int)((unsigned int)zT_177));
    return zT_179;
    z_bb_49:
    zT_181 = self->registry;
    zT_182 = arr_elem_tid;
    zT_186 = ec.len;
    zT_188 = zF_BA693C74_typeRegistryGetOrCr(zT_181, zT_182, (unsigned int)((unsigned int)zT_186));
    arr_tid = zT_188;
    self->_stub_0 = saved;
    return arr_tid;
}

/* semanticAnalyzerResolveStmt */
void zF_979B6CFF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_38C12417_SemanticAnalyzer* zT_2;
    unsigned int zT_3;
    zT_2 = self;
    zT_3 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_2, zT_3);
    return;
}

/* semanticAnalyzerResolveModuleVarDecl */
unsigned int zF_CC4377FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_38C12417_SemanticAnalyzer* zT_33;
    int zT_37;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_38C12417_SemanticAnalyzer* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    int zT_51 = 0;
    zT_338B7C76_TypeRegistry* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_0FB7FB13_CoercionKind zT_57 = 0;
    zT_66E7D2EF_CoercionTable* zT_62;
    unsigned int zT_63;
    zT_0FB7FB13_CoercionKind zT_64;
    unsigned int zT_65;
    zT_22A7C88B_AstNode decl;
    unsigned int decl_type;
    zT_BAEE192E_Opt_10 rt;
    unsigned int it;
    unsigned int t;
    unsigned int it_eff;
    zT_0FB7FB13_CoercionKind ck;
    zT_3 = self->store;
    zT_4 = decl_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    decl = zT_6;
    zT_7 = decl.child_1;
    if ((int)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_14 = 18;
    decl_type = zT_14;
    zT_15 = decl.child_0;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = self->type_table;
    zT_20 = decl.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_26 = self;
    zT_27 = decl_type;
    zF_9665A229_pushExpectedType(zT_26, zT_27);
    zT_29 = self;
    zT_30 = decl.child_1;
    zT_32 = zF_54F95822_semanticAnalyzerRes(zT_29, zT_30);
    it = zT_32;
    zT_33 = self;
    zF_BC478E78_popExpectedType(zT_33);
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    t = rt.value;
    decl_type = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_37 = it != decl_type;
    goto z_bb_9;
    z_bb_8:
    zT_37 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_37) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_40 = self;
    zT_41 = decl.child_1;
    zT_42 = decl_type;
    zT_43 = it;
    zT_45 = zF_FFC95E09_errLitSrcType(zT_40, zT_41, zT_42, zT_43);
    it_eff = zT_45;
    zT_46 = self;
    zT_47 = decl.child_1;
    zT_48 = it_eff;
    zT_49 = decl_type;
    zT_51 = zF_86AAA417_semanticAnalyzerMay(zT_46, zT_47, zT_48, zT_49);
    if (zT_51) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return it;
    z_bb_12:
    return it;
    z_bb_13:
    zT_53 = self->registry;
    zT_54 = it_eff;
    zT_55 = decl_type;
    zT_57 = zF_713658BF_classifyCoercion(zT_53, zT_54, zT_55);
    ck = zT_57;
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_62 = self->coercion_table;
    zT_63 = decl.child_1;
    zT_64 = ck;
    zT_65 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_62, zT_63, zT_64, zT_65);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_11;
}

/* EOF */
