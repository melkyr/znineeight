#include "semantic_analyzer_4DBE89E5.h"
/* semanticAnalyzerInit */
zT_38C12417_SemanticAnalyzer zF_84ADA681_semanticAnalyzerIni(zT_3E40CD83_Sand* alloc, zT_8EED1867_ResolvedTypeTable* type_table, zT_F85C5DED_DiagnosticCollector* diag, zT_338B7C76_TypeRegistry* registry, zT_3D7259E2_SymbolRegistry* symbols, zT_6B0A7D14_AstStore* store, unsigned int module_id, unsigned int source_file_id, zT_66E7D2EF_CoercionTable* coercion_tab, zT_21D3708C_U32ToU32Map* enum_val_tab, zT_21D3708C_U32ToU32Map* error_code_reg, zT_D3EB6303_StringInterner* interner, zT_21D3708C_U32ToU32Map* cal_typs, zT_21D3708C_U32ToU32Map* cp_map, zT_072B53A6_ModuleRegistry* module_reg) {
    char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_D3EB6303_StringInterner* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22 = 0;
    char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_D3EB6303_StringInterner* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30 = 0;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_D3EB6303_StringInterner* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38 = 0;
    char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_D3EB6303_StringInterner* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46 = 0;
    char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    zT_D3EB6303_StringInterner* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54 = 0;
    char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_D3EB6303_StringInterner* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62 = 0;
    char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_D3EB6303_StringInterner* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70 = 0;
    char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_D3EB6303_StringInterner* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78 = 0;
    char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_D3EB6303_StringInterner* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86 = 0;
    char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_D3EB6303_StringInterner* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94 = 0;
    char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_D3EB6303_StringInterner* zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int zT_102 = 0;
    char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_D3EB6303_StringInterner* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110 = 0;
    char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_D3EB6303_StringInterner* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118 = 0;
    char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_D3EB6303_StringInterner* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126 = 0;
    char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_D3EB6303_StringInterner* zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134 = 0;
    char* zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    zT_D3EB6303_StringInterner* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142 = 0;
    char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_D3EB6303_StringInterner* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150 = 0;
    char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_D3EB6303_StringInterner* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158 = 0;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_D3EB6303_StringInterner* zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166 = 0;
    char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_D3EB6303_StringInterner* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174 = 0;
    char* zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    zT_D3EB6303_StringInterner* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182 = 0;
    char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_D3EB6303_StringInterner* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190 = 0;
    char* zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    zT_D3EB6303_StringInterner* zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198 = 0;
    char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_D3EB6303_StringInterner* zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_206 = 0;
    char* zT_208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_209;
    unsigned int zT_210;
    zT_D3EB6303_StringInterner* zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_213;
    unsigned int zT_214 = 0;
    char* zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_218;
    zT_D3EB6303_StringInterner* zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned int zT_222 = 0;
    char* zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned int zT_226;
    zT_D3EB6303_StringInterner* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_230 = 0;
    char* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    zT_D3EB6303_StringInterner* zT_236;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237;
    unsigned int zT_238 = 0;
    char* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    zT_D3EB6303_StringInterner* zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    unsigned int zT_246 = 0;
    zT_38C12417_SemanticAnalyzer zT_247;
    int zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    int zT_258;
    int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    int zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    int zT_265;
    int zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_text;
    unsigned int und_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_text;
    unsigned int pc_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pti_s;
    unsigned int ptin_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u itp_s;
    unsigned int itp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifp_s;
    unsigned int ifp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_s;
    unsigned int pfi_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpp_s;
    unsigned int fpp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_s;
    unsigned int bc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_s;
    unsigned int ic_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_s;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u if_s;
    unsigned int if_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ie_s;
    unsigned int ie_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u e2i_s;
    unsigned int e2i_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u as_s;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u so_s;
    unsigned int so_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ao_s;
    unsigned int ao_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u oo_s;
    unsigned int oo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bso_s;
    unsigned int bso_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u boo_s;
    unsigned int boo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc2_s;
    unsigned int pc2_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sow_s;
    unsigned int sow_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sew_s;
    unsigned int sew_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u gc_s;
    unsigned int gc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ex_s;
    unsigned int ex_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm_s;
    unsigned int sm_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u iw_s;
    unsigned int iw_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_s;
    unsigned int cc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cg_s;
    unsigned int cg_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u csc_s;
    unsigned int csc_id;
    zT_16 = "_";
    zT_18 = 1;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    und_text = zT_17;
    zT_20 = interner;
    zT_21 = und_text;
    zT_22 = zF_50C274AF_stringInternerInter(zT_20, zT_21);
    und_name_id = zT_22;
    zT_24 = "@ptrCast";
    zT_26 = 8;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    pc_text = zT_25;
    zT_28 = interner;
    zT_29 = pc_text;
    zT_30 = zF_50C274AF_stringInternerInter(zT_28, zT_29);
    pc_name_id = zT_30;
    zT_32 = "@ptrToInt";
    zT_34 = 9;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    pti_s = zT_33;
    zT_36 = interner;
    zT_37 = pti_s;
    zT_38 = zF_50C274AF_stringInternerInter(zT_36, zT_37);
    ptin_id = zT_38;
    zT_40 = "@intToPtr";
    zT_42 = 9;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    itp_s = zT_41;
    zT_44 = interner;
    zT_45 = itp_s;
    zT_46 = zF_50C274AF_stringInternerInter(zT_44, zT_45);
    itp_id = zT_46;
    zT_48 = "@intFromPtr";
    zT_50 = 11;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    ifp_s = zT_49;
    zT_52 = interner;
    zT_53 = ifp_s;
    zT_54 = zF_50C274AF_stringInternerInter(zT_52, zT_53);
    ifp_id = zT_54;
    zT_56 = "@ptrFromInt";
    zT_58 = 11;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    pfi_s = zT_57;
    zT_60 = interner;
    zT_61 = pfi_s;
    zT_62 = zF_50C274AF_stringInternerInter(zT_60, zT_61);
    pfi_id = zT_62;
    zT_64 = "@fieldParentPtr";
    zT_66 = 15;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    fpp_s = zT_65;
    zT_68 = interner;
    zT_69 = fpp_s;
    zT_70 = zF_50C274AF_stringInternerInter(zT_68, zT_69);
    fpp_id = zT_70;
    zT_72 = "@bitCast";
    zT_74 = 8;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    bc_s = zT_73;
    zT_76 = interner;
    zT_77 = bc_s;
    zT_78 = zF_50C274AF_stringInternerInter(zT_76, zT_77);
    bc_id = zT_78;
    zT_80 = "@intCast";
    zT_82 = 8;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    ic_s = zT_81;
    zT_84 = interner;
    zT_85 = ic_s;
    zT_86 = zF_50C274AF_stringInternerInter(zT_84, zT_85);
    ic_id = zT_86;
    zT_88 = "@floatCast";
    zT_90 = 10;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    fc_s = zT_89;
    zT_92 = interner;
    zT_93 = fc_s;
    zT_94 = zF_50C274AF_stringInternerInter(zT_92, zT_93);
    fc_id = zT_94;
    zT_96 = "@intToFloat";
    zT_98 = 11;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    if_s = zT_97;
    zT_100 = interner;
    zT_101 = if_s;
    zT_102 = zF_50C274AF_stringInternerInter(zT_100, zT_101);
    if_id = zT_102;
    zT_104 = "@intToEnum";
    zT_106 = 10;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    ie_s = zT_105;
    zT_108 = interner;
    zT_109 = ie_s;
    zT_110 = zF_50C274AF_stringInternerInter(zT_108, zT_109);
    ie_id = zT_110;
    zT_112 = "@enumToInt";
    zT_114 = 10;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    e2i_s = zT_113;
    zT_116 = interner;
    zT_117 = e2i_s;
    zT_118 = zF_50C274AF_stringInternerInter(zT_116, zT_117);
    e2i_id = zT_118;
    zT_120 = "@as";
    zT_122 = 3;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    as_s = zT_121;
    zT_124 = interner;
    zT_125 = as_s;
    zT_126 = zF_50C274AF_stringInternerInter(zT_124, zT_125);
    as_id = zT_126;
    zT_128 = "@sizeOf";
    zT_130 = 7;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    so_s = zT_129;
    zT_132 = interner;
    zT_133 = so_s;
    zT_134 = zF_50C274AF_stringInternerInter(zT_132, zT_133);
    so_id = zT_134;
    zT_136 = "@alignOf";
    zT_138 = 8;
    zT_137.ptr = zT_136;
    zT_137.len = zT_138;
    ao_s = zT_137;
    zT_140 = interner;
    zT_141 = ao_s;
    zT_142 = zF_50C274AF_stringInternerInter(zT_140, zT_141);
    ao_id = zT_142;
    zT_144 = "@offsetOf";
    zT_146 = 9;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    oo_s = zT_145;
    zT_148 = interner;
    zT_149 = oo_s;
    zT_150 = zF_50C274AF_stringInternerInter(zT_148, zT_149);
    oo_id = zT_150;
    zT_152 = "@bitSizeOf";
    zT_154 = 10;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    bso_s = zT_153;
    zT_156 = interner;
    zT_157 = bso_s;
    zT_158 = zF_50C274AF_stringInternerInter(zT_156, zT_157);
    bso_id = zT_158;
    zT_160 = "@bitOffsetOf";
    zT_162 = 12;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    boo_s = zT_161;
    zT_164 = interner;
    zT_165 = boo_s;
    zT_166 = zF_50C274AF_stringInternerInter(zT_164, zT_165);
    boo_id = zT_166;
    zT_168 = "@putChar";
    zT_170 = 8;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    pc2_s = zT_169;
    zT_172 = interner;
    zT_173 = pc2_s;
    zT_174 = zF_50C274AF_stringInternerInter(zT_172, zT_173);
    pc2_id = zT_174;
    zT_176 = "@stdoutWrite";
    zT_178 = 12;
    zT_177.ptr = zT_176;
    zT_177.len = zT_178;
    sow_s = zT_177;
    zT_180 = interner;
    zT_181 = sow_s;
    zT_182 = zF_50C274AF_stringInternerInter(zT_180, zT_181);
    sow_id = zT_182;
    zT_184 = "@stderrWrite";
    zT_186 = 12;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    sew_s = zT_185;
    zT_188 = interner;
    zT_189 = sew_s;
    zT_190 = zF_50C274AF_stringInternerInter(zT_188, zT_189);
    sew_id = zT_190;
    zT_192 = "@getChar";
    zT_194 = 8;
    zT_193.ptr = zT_192;
    zT_193.len = zT_194;
    gc_s = zT_193;
    zT_196 = interner;
    zT_197 = gc_s;
    zT_198 = zF_50C274AF_stringInternerInter(zT_196, zT_197);
    gc_id = zT_198;
    zT_200 = "@exit";
    zT_202 = 5;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    ex_s = zT_201;
    zT_204 = interner;
    zT_205 = ex_s;
    zT_206 = zF_50C274AF_stringInternerInter(zT_204, zT_205);
    ex_id = zT_206;
    zT_208 = "@sleepMs";
    zT_210 = 8;
    zT_209.ptr = zT_208;
    zT_209.len = zT_210;
    sm_s = zT_209;
    zT_212 = interner;
    zT_213 = sm_s;
    zT_214 = zF_50C274AF_stringInternerInter(zT_212, zT_213);
    sm_id = zT_214;
    zT_216 = "@isWindows";
    zT_218 = 10;
    zT_217.ptr = zT_216;
    zT_217.len = zT_218;
    iw_s = zT_217;
    zT_220 = interner;
    zT_221 = iw_s;
    zT_222 = zF_50C274AF_stringInternerInter(zT_220, zT_221);
    iw_id = zT_222;
    zT_224 = "@consoleClear";
    zT_226 = 13;
    zT_225.ptr = zT_224;
    zT_225.len = zT_226;
    cc_s = zT_225;
    zT_228 = interner;
    zT_229 = cc_s;
    zT_230 = zF_50C274AF_stringInternerInter(zT_228, zT_229);
    cc_id = zT_230;
    zT_232 = "@consoleGotoxy";
    zT_234 = 14;
    zT_233.ptr = zT_232;
    zT_233.len = zT_234;
    cg_s = zT_233;
    zT_236 = interner;
    zT_237 = cg_s;
    zT_238 = zF_50C274AF_stringInternerInter(zT_236, zT_237);
    cg_id = zT_238;
    zT_240 = "@consoleSetColor";
    zT_242 = 16;
    zT_241.ptr = zT_240;
    zT_241.len = zT_242;
    csc_s = zT_241;
    zT_244 = interner;
    zT_245 = csc_s;
    zT_246 = zF_50C274AF_stringInternerInter(zT_244, zT_245);
    csc_id = zT_246;
    zT_247.type_table = type_table;
    zT_247.diag = diag;
    zT_247.registry = registry;
    zT_247.symbols = symbols;
    zT_247.store = store;
    zT_247.module_id = module_id;
    zT_247.source_file_id = source_file_id;
    zT_248 = 0;
    zT_247.expected_type_stack_items = (unsigned int*)zT_248;
    zT_249 = 0;
    zT_247.expected_type_stack_len = zT_249;
    zT_250 = 0;
    zT_247.expected_type_stack_cap = zT_250;
    zT_247.expected_type_stack_alloc = alloc;
    zT_251 = 0;
    zT_247.stmt_work_items = (unsigned int*)zT_251;
    zT_252 = 0;
    zT_247.stmt_work_len = zT_252;
    zT_253 = 0;
    zT_247.stmt_work_cap = zT_253;
    zT_254 = 0;
    zT_247.current_fn_return = zT_254;
    zT_255 = 0;
    zT_247.current_fn_name = zT_255;
    zT_247.coercion_table = coercion_tab;
    zT_247.enum_value_table = enum_val_tab;
    zT_247.error_code_registry = error_code_reg;
    zT_256 = 0;
    zT_247.current_switch_cond_tu = zT_256;
    zT_257 = 0;
    zT_247.switch_depth = zT_257;
    zT_258 = 0;
    zT_247.local_decl_names = (unsigned int*)zT_258;
    zT_259 = 0;
    zT_247.local_decl_types = (unsigned int*)zT_259;
    zT_260 = 0;
    zT_247.local_decl_count = zT_260;
    zT_261 = 0;
    zT_247.local_decl_cap = zT_261;
    zT_262 = 0;
    zT_247.packed_gate_items = (unsigned int*)zT_262;
    zT_263 = 0;
    zT_247.packed_gate_len = zT_263;
    zT_264 = 0;
    zT_247.packed_gate_cap = zT_264;
    zT_265 = 0;
    zT_247.packed_struct_tids = (unsigned int*)zT_265;
    zT_266 = 0;
    zT_247.packed_struct_decl_nodes = (unsigned int*)zT_266;
    zT_267 = 0;
    zT_247.packed_struct_cache_len = zT_267;
    zT_268 = 0;
    zT_247.packed_struct_cache_cap = zT_268;
    zT_269 = 0;
    zT_247.checked_struct_tids = (unsigned int*)zT_269;
    zT_270 = 0;
    zT_247.checked_struct_tids_len = zT_270;
    zT_271 = 0;
    zT_247.checked_struct_tids_cap = zT_271;
    zT_247._stub_0 = und_name_id;
    zT_272 = 0;
    zT_247._stub_1 = zT_272;
    zT_247.call_arg_types = cal_typs;
    zT_247.call_param_map = cp_map;
    zT_247.interner = interner;
    zT_247.ptrcast_name_id = pc_name_id;
    zT_247.ptrtoint_name_id = ptin_id;
    zT_247.inttoptr_name_id = itp_id;
    zT_247.int_from_ptr_name_id = ifp_id;
    zT_247.ptr_from_int_name_id = pfi_id;
    zT_247.field_parent_ptr_name_id = fpp_id;
    zT_247.bitcast_name_id = bc_id;
    zT_247.intcast_name_id = ic_id;
    zT_247.floatcast_name_id = fc_id;
    zT_247.inttofloat_name_id = if_id;
    zT_247.inttoenum_name_id = ie_id;
    zT_247.enumtoint_name_id = e2i_id;
    zT_247.as_name_id = as_id;
    zT_247.size_of_name_id = so_id;
    zT_247.align_of_name_id = ao_id;
    zT_247.offset_of_name_id = oo_id;
    zT_247.bit_size_of_name_id = bso_id;
    zT_247.bit_offset_of_name_id = boo_id;
    zT_247.putchar_name_id = pc2_id;
    zT_247.stdout_write_name_id = sow_id;
    zT_247.stderr_write_name_id = sew_id;
    zT_247.getchar_name_id = gc_id;
    zT_247.exit_name_id = ex_id;
    zT_247.sleep_ms_name_id = sm_id;
    zT_247.is_windows_name_id = iw_id;
    zT_247.console_clear_name_id = cc_id;
    zT_247.console_gotoxy_name_id = cg_id;
    zT_247.console_set_color_name_id = csc_id;
    zT_247.module_reg = module_reg;
    return zT_247;
}

/* semanticAnalyzerIsTypeValueCast */
int zF_3757023F_semanticAnalyzerIsT(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_2 = self->ptrcast_name_id;
    if ((int)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_5 = self->inttoptr_name_id;
    if ((int)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_8 = self->intcast_name_id;
    if ((int)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_11 = self->floatcast_name_id;
    if ((int)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    zT_14 = self->inttofloat_name_id;
    if ((int)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    zT_17 = self->inttoenum_name_id;
    if ((int)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_20 = self->as_name_id;
    if ((int)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    return (int)(0);
}

/* semanticAnalyzerBuiltinNameEq */
int zF_2ACB4E23_semanticAnalyzerBui(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, zT_8F083A69_Slice_zT_0B42B2F8_u lit) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_20;
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned char zT_23;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    unsigned int ci;
    zT_4 = self->interner;
    zT_5 = name_id;
    zT_7 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    nm = zT_7;
    zT_9 = nm.len;
    zT_11 = lit.len;
    if ((int)(zT_9 != zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    ci = zT_16;
    goto z_bb_3;
    z_bb_3:
    zT_18 = nm.len;
    if ((int)(ci < zT_18)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = nm.ptr;
    zT_21 = zT_20[ci];
    zT_22 = lit.ptr;
    zT_23 = zT_22[ci];
    if ((int)(zT_21 != zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_27 = ci + (unsigned int)(1);
    ci = zT_27;
    goto z_bb_3;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    goto z_bb_6;
}

/* semanticAnalyzerIsBuiltinSupported */
int zF_CAF1FD28_semanticAnalyzerIsB(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_44;
    unsigned int zT_47;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_59;
    unsigned int zT_62;
    unsigned int zT_65;
    unsigned int zT_68;
    unsigned int zT_71;
    unsigned int zT_74;
    unsigned int zT_77;
    unsigned int zT_80;
    char* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zT_38C12417_SemanticAnalyzer* zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    int zT_90 = 0;
    char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_38C12417_SemanticAnalyzer* zT_96;
    unsigned int zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    int zT_99 = 0;
    char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    zT_38C12417_SemanticAnalyzer* zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    int zT_108 = 0;
    char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_38C12417_SemanticAnalyzer* zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    int zT_117 = 0;
    char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_38C12417_SemanticAnalyzer* zT_123;
    unsigned int zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    int zT_126 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_e2i;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cvs;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cva;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cve;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_pan;
    zT_2 = self->ptrcast_name_id;
    if ((int)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_5 = self->ptrtoint_name_id;
    if ((int)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_8 = self->inttoptr_name_id;
    if ((int)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_11 = self->int_from_ptr_name_id;
    if ((int)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    zT_14 = self->ptr_from_int_name_id;
    if ((int)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    zT_17 = self->field_parent_ptr_name_id;
    if ((int)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_20 = self->bitcast_name_id;
    if ((int)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    zT_23 = self->intcast_name_id;
    if ((int)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    zT_26 = self->floatcast_name_id;
    if ((int)(name_id == zT_26)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    zT_29 = self->inttofloat_name_id;
    if ((int)(name_id == zT_29)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    zT_32 = self->inttoenum_name_id;
    if ((int)(name_id == zT_32)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(1);
    z_bb_22:
    zT_35 = self->as_name_id;
    if ((int)(name_id == zT_35)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(1);
    z_bb_24:
    zT_38 = self->size_of_name_id;
    if ((int)(name_id == zT_38)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(1);
    z_bb_26:
    zT_41 = self->align_of_name_id;
    if ((int)(name_id == zT_41)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(1);
    z_bb_28:
    zT_44 = self->offset_of_name_id;
    if ((int)(name_id == zT_44)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (int)(1);
    z_bb_30:
    zT_47 = self->bit_size_of_name_id;
    if ((int)(name_id == zT_47)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return (int)(1);
    z_bb_32:
    zT_50 = self->bit_offset_of_name_id;
    if ((int)(name_id == zT_50)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (int)(1);
    z_bb_34:
    zT_53 = self->putchar_name_id;
    if ((int)(name_id == zT_53)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (int)(1);
    z_bb_36:
    zT_56 = self->stdout_write_name_id;
    if ((int)(name_id == zT_56)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (int)(1);
    z_bb_38:
    zT_59 = self->stderr_write_name_id;
    if ((int)(name_id == zT_59)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (int)(1);
    z_bb_40:
    zT_62 = self->getchar_name_id;
    if ((int)(name_id == zT_62)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (int)(1);
    z_bb_42:
    zT_65 = self->exit_name_id;
    if ((int)(name_id == zT_65)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return (int)(1);
    z_bb_44:
    zT_68 = self->sleep_ms_name_id;
    if ((int)(name_id == zT_68)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (int)(1);
    z_bb_46:
    zT_71 = self->is_windows_name_id;
    if ((int)(name_id == zT_71)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (int)(1);
    z_bb_48:
    zT_74 = self->console_clear_name_id;
    if ((int)(name_id == zT_74)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return (int)(1);
    z_bb_50:
    zT_77 = self->console_gotoxy_name_id;
    if ((int)(name_id == zT_77)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (int)(1);
    z_bb_52:
    zT_80 = self->console_set_color_name_id;
    if ((int)(name_id == zT_80)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return (int)(1);
    z_bb_54:
    zT_84 = "@enumToInt";
    zT_86 = 10;
    zT_85.ptr = zT_84;
    zT_85.len = zT_86;
    l_e2i = zT_85;
    zT_87 = self;
    zT_88 = name_id;
    zT_89 = l_e2i;
    zT_90 = zF_2ACB4E23_semanticAnalyzerBui(zT_87, zT_88, zT_89);
    if (zT_90) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (int)(1);
    z_bb_56:
    zT_93 = "@cVaStart";
    zT_95 = 9;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    l_cvs = zT_94;
    zT_96 = self;
    zT_97 = name_id;
    zT_98 = l_cvs;
    zT_99 = zF_2ACB4E23_semanticAnalyzerBui(zT_96, zT_97, zT_98);
    if (zT_99) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (int)(1);
    z_bb_58:
    zT_102 = "@cVaArg";
    zT_104 = 7;
    zT_103.ptr = zT_102;
    zT_103.len = zT_104;
    l_cva = zT_103;
    zT_105 = self;
    zT_106 = name_id;
    zT_107 = l_cva;
    zT_108 = zF_2ACB4E23_semanticAnalyzerBui(zT_105, zT_106, zT_107);
    if (zT_108) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (int)(1);
    z_bb_60:
    zT_111 = "@cVaEnd";
    zT_113 = 7;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    l_cve = zT_112;
    zT_114 = self;
    zT_115 = name_id;
    zT_116 = l_cve;
    zT_117 = zF_2ACB4E23_semanticAnalyzerBui(zT_114, zT_115, zT_116);
    if (zT_117) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (int)(1);
    z_bb_62:
    zT_120 = "@panic";
    zT_122 = 6;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    l_pan = zT_121;
    zT_123 = self;
    zT_124 = name_id;
    zT_125 = l_pan;
    zT_126 = zF_2ACB4E23_semanticAnalyzerBui(zT_123, zT_124, zT_125);
    if (zT_126) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (int)(1);
    z_bb_64:
    return (int)(0);
}

/* semanticAnalyzerGrowLocalDecls */
void zF_156C79D0_semanticAnalyzerGro(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_0F51E4CA_EU_222 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    zT_3E40CD83_Sand* zT_23;
    zT_0F51E4CA_EU_222 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int* zT_35;
    unsigned int* zT_37;
    unsigned int zT_38;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw_names;
    unsigned char* raw_types;
    unsigned int* ndst;
    unsigned int* tdst;
    unsigned int ci;
    zT_2 = self->local_decl_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->local_decl_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_names = zT_20;
    zT_23 = self->expected_type_stack_alloc;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    z_bb_8:
    zT_32 = zT_30.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_types = zT_32;
    zT_35 = (unsigned int*)raw_names;
    ndst = zT_35;
    zT_37 = (unsigned int*)raw_types;
    tdst = zT_37;
    zT_38 = self->local_decl_count;
    if ((int)(zT_38 > (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    goto z_bb_12;
    z_bb_11:
    self->local_decl_names = ndst;
    self->local_decl_types = tdst;
    self->local_decl_cap = new_cap;
    return;
    z_bb_12:
    zT_44 = self->local_decl_count;
    if ((int)(ci < zT_44)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = self->local_decl_names;
    zT_47 = zT_46[ci];
    ndst[ci] = zT_47;
    zT_48 = self->local_decl_types;
    zT_49 = zT_48[ci];
    tdst[ci] = zT_49;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_50 = 1;
    zT_51 = ci + zT_50;
    ci = zT_51;
    goto z_bb_12;
}

/* registerLocalDecl */
void zF_7BD72017_registerLocalDecl(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    char* zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_tm;
    zT_3 = self->local_decl_count;
    zT_4 = self->local_decl_cap;
    if ((int)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_8 = "SCT:n";
    zT_10 = 5;
    zT_9.ptr = zT_8;
    zT_9.len = zT_10;
    sct_nm = zT_9;
    zT_11 = sct_nm;
    zT_12 = name_id;
    zF_C914CB83_markerWriteInt(zT_11, zT_12);
    zT_14 = "SCT:t";
    zT_16 = 5;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    sct_tm = zT_15;
    zT_17 = sct_tm;
    zT_18 = type_id;
    zF_C914CB83_markerWriteInt(zT_17, zT_18);
    zT_19 = self->local_decl_names;
    zT_20 = self->local_decl_count;
    zT_19[zT_20] = name_id;
    zT_21 = self->local_decl_types;
    zT_22 = self->local_decl_count;
    zT_21[zT_22] = type_id;
    zT_23 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_23 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCaptureType */
unsigned int zF_3E251D67_semanticAnalyzerCap(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_type) {
    zT_338B7C76_TypeRegistry* zT_6;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_0B10E8E9_OptionalPayload* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_0B10E8E9_OptionalPayload zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type capt_ty;
    if ((int)(cond_type == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_items;
    zT_8 = (unsigned int)cond_type;
    zT_9 = zT_7[zT_8];
    capt_ty = zT_9;
    zT_10 = capt_ty.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self->registry;
    zT_16 = zT_15->opt_items;
    zT_17 = capt_ty.payload_idx;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zT_16[zT_18];
    zT_20 = zT_19.payload;
    return zT_20;
    z_bb_4:
    return cond_type;
}

/* semanticAnalyzerResolveIdent */
unsigned int zF_9F1ECA79_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int module_id, unsigned int name_id, unsigned int node_idx) {
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int* zT_27;
    unsigned int zT_28;
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_79FAE712_u64 zT_63;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned int zT_70;
    zT_79FAE712_u64 zT_75;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_79FAE712_u64 zT_78;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    zT_3D7259E2_SymbolRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_E282FB55_Opt_808 zT_87 = {0};
    unsigned char zT_88;
    char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_3C598AEF_SymbolKind zT_95;
    zT_38C12417_SemanticAnalyzer* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_105;
    char* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    unsigned char zT_114;
    char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned char zT_121;
    char* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_134;
    char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    unsigned char zT_150;
    char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned char zT_165;
    char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    char* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_185;
    unsigned int zT_187;
    char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    unsigned int* zT_196;
    unsigned int zT_197;
    char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    unsigned int* zT_205;
    unsigned int zT_206;
    unsigned int zT_208;
    unsigned int zT_210;
    char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_218;
    unsigned int* zT_219;
    unsigned int zT_220;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    int zT_230;
    zT_D3EB6303_StringInterner* zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    zT_6B0A7D14_AstStore* zT_240;
    unsigned int zT_241;
    zT_22A7C88B_AstNode zT_243 = {0};
    char* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    zT_8143F551_AstKind zT_250;
    zT_8EED1867_ResolvedTypeTable* zT_253;
    unsigned int zT_254;
    zT_BAEE192E_Opt_10 zT_256 = {0};
    unsigned char zT_257;
    char* zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned int zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    char* zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    char* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_284;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    int zT_290;
    unsigned char* zT_291;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned int zT_294 = 0;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned char* zT_303;
    unsigned int zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    char* zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    unsigned int zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u ide;
    zT_8F083A69_Slice_zT_0B42B2F8_u sem_m;
    unsigned int li;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 ncg;
    zT_79FAE712_u64 mkey;
    zT_BAEE192E_Opt_10 ncgm;
    zT_E282FB55_Opt_808 sym;
    unsigned int lcl_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u id1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lt_m;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u id2;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_talias;
    unsigned int ctm;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_sv;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_tm;
    unsigned int nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_ntm;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u id3;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8l_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8i_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cname;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8k_m;
    zT_BAEE192E_Opt_10 rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8nl2;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8z_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u idm;
    zT_5A26C2ED_Arr_unsigned_char_1 idnb;
    unsigned int idnl;
    unsigned int idns;
    zT_8F083A69_Slice_zT_0B42B2F8_u idc;
    zT_5 = "IDE\n";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    ide = zT_6;
    zT_8 = ide;
    zF_48AC7B3A_markerWrite(zT_8);
    if ((int)(name_id == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = "SEM:vi";
    zT_14 = 6;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    sem_m = zT_13;
    zT_15 = sem_m;
    zT_16 = module_id;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_18 = self->local_decl_count;
    li = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((int)(li > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = li - (unsigned int)(1);
    li = zT_22;
    zT_23 = self->local_decl_names;
    zT_24 = zT_23[li];
    if ((int)(zT_24 == name_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_63 = (zT_79FAE712_u64)name_id;
    key = zT_63;
    zT_65 = self->registry;
    zT_66 = key;
    zT_68 = zF_0EB68360_nameCacheGet(zT_65, zT_66);
    ncg = zT_68;
    zT_70 = self->module_id;
    zT_75 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_70) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    mkey = zT_75;
    zT_77 = self->registry;
    zT_78 = mkey;
    zT_80 = zF_0EB68360_nameCacheGet(zT_77, zT_78);
    ncgm = zT_80;
    zT_82 = self->symbols;
    zT_83 = self->module_id;
    zT_84 = name_id;
    zT_87 = zF_A398987E_symbolRegistryQuali(zT_82, zT_83, zT_84);
    sym = zT_87;
    zT_88 = sym.has_value;
    if (zT_88) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_27 = self->local_decl_types;
    zT_28 = zT_27[li];
    lcl_t = zT_28;
    zT_30 = "D7:Yn";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    d7m = zT_31;
    zT_33 = d7m;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_35 = "D7:n";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    d7n_m = zT_36;
    zT_38 = d7n_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_41 = "D7:t";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    d7tm = zT_42;
    zT_44 = d7tm;
    zF_48AC7B3A_markerWrite(zT_44);
    zT_46 = "D7";
    zT_48 = 2;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    d7t_m = zT_47;
    zT_49 = d7t_m;
    zT_50 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_49, zT_50);
    zT_52 = "L\n";
    zT_54 = 2;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    id1 = zT_53;
    zT_55 = id1;
    zF_48AC7B3A_markerWrite(zT_55);
    zT_57 = "L:t";
    zT_59 = 3;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    lt_m = zT_58;
    zT_60 = lt_m;
    zT_61 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_60, zT_61);
    return lcl_t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    s = sym.value;
    zT_91 = "S\n";
    zT_93 = 2;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    id2 = zT_92;
    zT_94 = id2;
    zF_48AC7B3A_markerWrite(zT_94);
    zT_95 = s->kind;
    if ((int)(zT_95 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_165 = ncg.has_value;
    if (zT_165) goto z_bb_23; else goto z_bb_24;
    z_bb_11:
    zT_100 = self;
    zT_101 = s->decl_node;
    zT_102 = s->module_id;
    zF_FC6E31C6_semanticAnalyzerMay(zT_100, zT_101, zT_102);
    zT_105 = s->type_id;
    if ((int)(zT_105 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_134 = s->type_id;
    if ((int)(zT_134 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    zT_109 = "TAL\n";
    zT_111 = 4;
    zT_110.ptr = zT_109;
    zT_110.len = zT_111;
    rdt_talias = zT_110;
    zT_112 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_112);
    zT_113 = s->type_id;
    return zT_113;
    z_bb_14:
    zT_114 = ncgm.has_value;
    if (zT_114) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    ctm = ncgm.value;
    zT_117 = "TAL\n";
    zT_119 = 4;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    rdt_talias = zT_118;
    zT_120 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_120);
    return ctm;
    z_bb_16:
    zT_121 = ncg.has_value;
    if (zT_121) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    ct = ncg.value;
    zT_124 = "TAL\n";
    zT_126 = 4;
    zT_125.ptr = zT_124;
    zT_125.len = zT_126;
    rdt_talias = zT_125;
    zT_127 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_127);
    return ct;
    z_bb_18:
    zT_129 = "SVO\n";
    zT_131 = 4;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    rdt_sv = zT_130;
    zT_132 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_132);
    return (unsigned int)(1);
    z_bb_19:
    zT_138 = "STY:N";
    zT_140 = 5;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    rdt_nm = zT_139;
    zT_141 = rdt_nm;
    zT_142 = name_id;
    zF_C914CB83_markerWriteInt(zT_141, zT_142);
    zT_144 = "STY:T";
    zT_146 = 5;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    rdt_tm = zT_145;
    zT_147 = rdt_tm;
    zT_148 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_147, zT_148);
    zT_150 = ncg.has_value;
    if (zT_150) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_160 = "SVO\n";
    zT_162 = 4;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    rdt_sv = zT_161;
    zT_163 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_163);
    return (unsigned int)(1);
    z_bb_21:
    nt = ncg.value;
    zT_153 = "STY:C";
    zT_155 = 5;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    rdt_ntm = zT_154;
    zT_156 = rdt_ntm;
    zT_157 = nt;
    zF_C914CB83_markerWriteInt(zT_156, zT_157);
    goto z_bb_22;
    z_bb_22:
    zT_158 = s->type_id;
    return zT_158;
    z_bb_23:
    t = ncg.value;
    zT_168 = "C2:T";
    zT_170 = 4;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    id3 = zT_169;
    zT_171 = id3;
    zT_172 = t;
    zF_C914CB83_markerWriteInt(zT_171, zT_172);
    return t;
    z_bb_24:
    zT_174 = "D8:Nn";
    zT_176 = 5;
    zT_175.ptr = zT_174;
    zT_175.len = zT_176;
    d8n_m = zT_175;
    zT_177 = d8n_m;
    zT_178 = name_id;
    zF_C914CB83_markerWriteInt(zT_177, zT_178);
    zT_180 = "D8:C";
    zT_182 = 4;
    zT_181.ptr = zT_180;
    zT_181.len = zT_182;
    d8c_m = zT_181;
    zT_183 = d8c_m;
    zT_185 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_183, (unsigned int)((unsigned int)zT_185));
    zT_187 = self->local_decl_count;
    if ((int)(zT_187 > (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_191 = "D8:F";
    zT_193 = 4;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    d8f_m = zT_192;
    zT_194 = d8f_m;
    zT_196 = self->local_decl_names;
    zT_197 = 0;
    zT_195 = zT_196[zT_197];
    zF_C914CB83_markerWriteInt(zT_194, zT_195);
    zT_200 = "D8:L";
    zT_202 = 4;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    d8l_m = zT_201;
    zT_203 = d8l_m;
    zT_205 = self->local_decl_names;
    zT_206 = self->local_decl_count;
    zT_208 = zT_206 - (unsigned int)(1);
    zT_204 = zT_205[zT_208];
    zF_C914CB83_markerWriteInt(zT_203, zT_204);
    goto z_bb_26;
    z_bb_26:
    zT_210 = self->local_decl_count;
    if ((int)(zT_210 > (unsigned int)(4))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_214 = "D8:X";
    zT_216 = 4;
    zT_215.ptr = zT_214;
    zT_215.len = zT_216;
    d8x_m = zT_215;
    zT_217 = d8x_m;
    zT_219 = self->local_decl_names;
    zT_220 = 4;
    zT_218 = zT_219[zT_220];
    zF_C914CB83_markerWriteInt(zT_217, zT_218);
    goto z_bb_28;
    z_bb_28:
    zT_223 = "D8:I";
    zT_225 = 4;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    d8i_m = zT_224;
    zT_226 = d8i_m;
    zT_227 = node_idx;
    zF_C914CB83_markerWriteInt(zT_226, zT_227);
    if ((int)(node_idx >= (unsigned int)(450))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_230 = node_idx <= (unsigned int)(660);
    goto z_bb_31;
    z_bb_30:
    zT_230 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_230) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_234 = self->interner;
    zT_235 = name_id;
    zT_237 = zF_9134020D_stringInternerGet(zT_234, zT_235);
    cname = zT_237;
    zT_238 = cname;
    zF_48AC7B3A_markerWrite(zT_238);
    zT_240 = self->store;
    zT_241 = node_idx;
    zT_243 = zF_FCDD1D35_astStoreNodeAt(zT_240, zT_241);
    cnode = zT_243;
    zT_245 = "D8";
    zT_247 = 2;
    zT_246.ptr = zT_245;
    zT_246.len = zT_247;
    d8k_m = zT_246;
    zT_248 = d8k_m;
    zT_250 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_248, (unsigned int)((unsigned int)zT_250));
    zT_253 = self->type_table;
    zT_254 = node_idx;
    zT_256 = zF_999DCF51_resolvedTypeTableGe(zT_253, zT_254);
    rt = zT_256;
    zT_257 = rt.has_value;
    if (zT_257) goto z_bb_34; else goto z_bb_36;
    z_bb_33:
    zT_275 = self->_stub_0;
    if ((int)(name_id == zT_275)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    t = rt.value;
    zT_260 = "D8:T";
    zT_262 = 4;
    zT_261.ptr = zT_260;
    zT_261.len = zT_262;
    d8t_m = zT_261;
    zT_263 = d8t_m;
    zT_264 = t;
    zF_C914CB83_markerWriteInt(zT_263, zT_264);
    goto z_bb_35;
    z_bb_35:
    zT_271 = "\n";
    zT_273 = 1;
    zT_272.ptr = zT_271;
    zT_272.len = zT_273;
    d8nl2 = zT_272;
    zT_274 = d8nl2;
    zF_48AC7B3A_markerWrite(zT_274);
    goto z_bb_33;
    z_bb_36:
    zT_266 = "D8:Z\n";
    zT_268 = 5;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    d8z_m = zT_267;
    zT_269 = d8z_m;
    zF_48AC7B3A_markerWrite(zT_269);
    goto z_bb_35;
    z_bb_37:
    return (unsigned int)(18);
    z_bb_38:
    zT_279 = "IDT:";
    zT_281 = 4;
    zT_280.ptr = zT_279;
    zT_280.len = zT_281;
    idm = zT_280;
    zT_282 = idm;
    zF_48AC7B3A_markerWrite(zT_282);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_284[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        idnb[_i] = zT_284[_i];
        _i++;
    }
}
    zT_286 = name_id;
    zT_290 = 0;
    zT_291 = (unsigned char*)((unsigned char*)idnb) + zT_290;
    zT_292 = (unsigned int)(10) - zT_290;
    zT_293.ptr = zT_291;
    zT_293.len = zT_292;
    zT_287 = zT_293;
    zT_294 = zF_A7504564_itoa(zT_286, zT_287);
    idnl = zT_294;
    zT_298 = (unsigned int)(9) - (unsigned int)((unsigned int)idnl);
    idns = zT_298;
    zT_303 = (unsigned char*)((unsigned char*)idnb) + idns;
    zT_304 = (unsigned int)(9) - idns;
    zT_305.ptr = zT_303;
    zT_305.len = zT_304;
    zT_299 = zT_305;
    zF_48AC7B3A_markerWrite(zT_299);
    zT_307 = ":VOID\n";
    zT_309 = 6;
    zT_308.ptr = zT_307;
    zT_308.len = zT_309;
    idc = zT_308;
    zT_310 = idc;
    zF_48AC7B3A_markerWrite(zT_310);
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveFieldAccess */
unsigned int zF_DDD991E1_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8143F551_AstKind zT_29;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8143F551_AstKind zT_37;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_49;
    unsigned int zT_52 = 0;
    zT_3D7259E2_SymbolRegistry* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_E282FB55_Opt_808 zT_59 = {0};
    unsigned char zT_60;
    zT_3C598AEF_SymbolKind zT_62;
    unsigned int zT_68;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_D155D06D_Type* zT_73;
    unsigned int zT_74;
    zT_D155D06D_Type zT_75;
    zT_33EF6BFB_TypeKind zT_76;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_54FF90FA_TaggedUnionPayload* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_54FF90FA_TaggedUnionPayload zT_86;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned short zT_91;
    unsigned int zT_92;
    int zT_94;
    unsigned int zT_95;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_2DF01B61_FieldEntry* zT_98;
    unsigned int zT_99;
    zT_2DF01B61_FieldEntry zT_100;
    unsigned int zT_101;
    zT_8EED1867_ResolvedTypeTable* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    int zT_107;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_457ECFEE_EnumPayload* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_457ECFEE_EnumPayload zT_119;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned short zT_124;
    unsigned int zT_125;
    int zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D96DCDF2_EnumMember* zT_131;
    unsigned int zT_132;
    zT_D96DCDF2_EnumMember zT_133;
    unsigned int zT_134;
    zT_8EED1867_ResolvedTypeTable* zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    int zT_140;
    unsigned int zT_141;
    zT_33EF6BFB_TypeKind zT_142;
    zT_338B7C76_TypeRegistry* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_152 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_3C598AEF_SymbolKind zT_159;
    unsigned int zT_165;
    zT_3D7259E2_SymbolRegistry* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_E282FB55_Opt_808 zT_171 = {0};
    unsigned char zT_172;
    char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned short zT_180;
    char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    zT_3C598AEF_SymbolKind zT_188;
    char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    char* zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    unsigned short zT_203;
    zT_3C598AEF_SymbolKind zT_208;
    zT_8EED1867_ResolvedTypeTable* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int zT_218;
    unsigned int zT_219;
    zT_8EED1867_ResolvedTypeTable* zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    unsigned int zT_227;
    zT_3C598AEF_SymbolKind zT_228;
    int zT_233;
    unsigned int zT_234;
    char* zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    zT_6B0A7D14_AstStore* zT_243;
    unsigned int zT_244;
    zT_22A7C88B_AstNode zT_247 = {0};
    zT_8143F551_AstKind zT_248;
    zT_6B0A7D14_AstStore* zT_254;
    zT_4A837C97_anon_184529 zT_255;
    zT_243D6A41_FnProto* zT_256;
    zT_6B0A7D14_AstStore* zT_257;
    unsigned int zT_258;
    unsigned int zT_261 = 0;
    unsigned int zT_262;
    zT_243D6A41_FnProto zT_263;
    char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned int zT_269;
    unsigned int zT_271;
    zT_8EED1867_ResolvedTypeTable* zT_275;
    unsigned int zT_276;
    zT_BAEE192E_Opt_10 zT_279 = {0};
    unsigned char zT_281;
    unsigned int zT_282;
    char* zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned int zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    unsigned int zT_290;
    unsigned char zT_291;
    zT_338B7C76_TypeRegistry* zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_299;
    unsigned short zT_300;
    unsigned int zT_301;
    unsigned int zT_309 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    zT_ABC1EBBE_TypeResolveEnv zT_315;
    zT_6B0A7D14_AstStore* zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    zT_3D7259E2_SymbolRegistry* zT_318;
    zT_D3EB6303_StringInterner* zT_319;
    unsigned int zT_320;
    zT_ABC1EBBE_TypeResolveEnv* zT_322;
    unsigned int zT_323;
    unsigned int zT_328 = 0;
    char* zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    char* zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned int zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned int zT_341;
    zT_8EED1867_ResolvedTypeTable* zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    zT_338B7C76_TypeRegistry* zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    unsigned int zT_355;
    unsigned short zT_356;
    unsigned int zT_357;
    unsigned int zT_365 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    char* zT_371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_372;
    unsigned int zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_374;
    zT_338B7C76_TypeRegistry* zT_376;
    unsigned int zT_377;
    unsigned int zT_378;
    unsigned int zT_381;
    unsigned short zT_382;
    unsigned int zT_392 = 0;
    char* zT_394;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_395;
    unsigned int zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397;
    unsigned int zT_398;
    zT_8EED1867_ResolvedTypeTable* zT_399;
    unsigned int zT_400;
    unsigned int zT_401;
    char* zT_404;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405;
    unsigned int zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    unsigned int zT_408;
    zT_8EED1867_ResolvedTypeTable* zT_409;
    unsigned int zT_410;
    unsigned int zT_418;
    unsigned int zT_420;
    unsigned int zT_422;
    zT_D3EB6303_StringInterner* zT_424;
    unsigned int zT_425;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_427 = {0};
    char* zT_429;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_430;
    unsigned int zT_431;
    char* zT_433;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    unsigned int zT_435;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_437;
    unsigned int zT_438;
    unsigned int zT_439;
    unsigned int zT_440;
    zT_D3EB6303_StringInterner* zT_442;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_443;
    int zT_446;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_449 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_450;
    unsigned int zT_453;
    unsigned int zT_454;
    unsigned int zT_455;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_456;
    unsigned int zT_464 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_465;
    unsigned int zT_466;
    zT_8143F551_AstKind zT_471;
    zT_6B0A7D14_AstStore* zT_477;
    unsigned int zT_478;
    unsigned int zT_481 = 0;
    zT_072B53A6_ModuleRegistry* zT_483;
    unsigned int zT_484;
    zT_BAEE192E_Opt_10 zT_486 = {0};
    unsigned char zT_487;
    zT_3D7259E2_SymbolRegistry* zT_490;
    unsigned int zT_491;
    unsigned int zT_492;
    zT_E282FB55_Opt_808 zT_494 = {0};
    unsigned char zT_495;
    unsigned short zT_497;
    zT_3C598AEF_SymbolKind zT_502;
    zT_8EED1867_ResolvedTypeTable* zT_507;
    unsigned int zT_508;
    unsigned int zT_509;
    unsigned int zT_512;
    unsigned int zT_513;
    zT_8EED1867_ResolvedTypeTable* zT_516;
    unsigned int zT_517;
    unsigned int zT_518;
    unsigned int zT_521;
    zT_38C12417_SemanticAnalyzer* zT_523;
    unsigned int zT_524;
    unsigned int zT_526 = 0;
    char* zT_530;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_531;
    unsigned int zT_532;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_533;
    zT_8EED1867_ResolvedTypeTable* zT_534;
    unsigned int zT_535;
    zT_338B7C76_TypeRegistry* zT_541;
    zT_D155D06D_Type* zT_542;
    unsigned int zT_543;
    zT_D155D06D_Type zT_544;
    int zT_546;
    unsigned int zT_547;
    int zT_549;
    unsigned int zT_550;
    zT_33EF6BFB_TypeKind zT_551;
    int zT_556;
    zT_33EF6BFB_TypeKind zT_557;
    zT_33EF6BFB_TypeKind zT_563;
    zT_338B7C76_TypeRegistry* zT_564;
    zT_112BF819_PtrPayload* zT_565;
    unsigned int zT_566;
    unsigned int zT_567;
    zT_112BF819_PtrPayload zT_568;
    unsigned int zT_569;
    zT_338B7C76_TypeRegistry* zT_570;
    zT_D155D06D_Type* zT_571;
    unsigned int zT_572;
    zT_D155D06D_Type zT_573;
    char* zT_575;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_576;
    unsigned int zT_577;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_578;
    char* zT_582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_583;
    unsigned int zT_584;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_585;
    zT_33EF6BFB_TypeKind zT_587;
    char* zT_590;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_591;
    unsigned int zT_592;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_593;
    zT_33EF6BFB_TypeKind zT_594;
    unsigned int zT_600;
    unsigned int zT_602;
    unsigned int zT_604;
    char* zT_606;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_607;
    unsigned int zT_608;
    zT_F85C5DED_DiagnosticCollector* zT_609;
    unsigned int zT_612;
    unsigned int zT_613;
    unsigned int zT_614;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_615;
    unsigned int zT_620 = 0;
    zT_33EF6BFB_TypeKind zT_622;
    unsigned int zT_628;
    unsigned int zT_630;
    unsigned int zT_632;
    char* zT_634;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_635;
    unsigned int zT_636;
    zT_F85C5DED_DiagnosticCollector* zT_637;
    unsigned int zT_640;
    unsigned int zT_641;
    unsigned int zT_642;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_643;
    unsigned int zT_648 = 0;
    zT_33EF6BFB_TypeKind zT_650;
    zT_338B7C76_TypeRegistry* zT_656;
    zT_406493CE_StructPayload* zT_657;
    unsigned int zT_658;
    unsigned int zT_659;
    zT_406493CE_StructPayload zT_660;
    unsigned int zT_661;
    unsigned int zT_662;
    unsigned short zT_663;
    unsigned int zT_664;
    zT_33EF6BFB_TypeKind zT_665;
    int zT_670;
    zT_33EF6BFB_TypeKind zT_671;
    zT_338B7C76_TypeRegistry* zT_677;
    zT_AF9231A2_UnionPayload* zT_678;
    unsigned int zT_679;
    unsigned int zT_680;
    zT_AF9231A2_UnionPayload zT_681;
    unsigned int zT_682;
    unsigned int zT_683;
    unsigned short zT_684;
    unsigned int zT_685;
    zT_33EF6BFB_TypeKind zT_686;
    zT_338B7C76_TypeRegistry* zT_692;
    zT_54FF90FA_TaggedUnionPayload* zT_693;
    unsigned int zT_694;
    unsigned int zT_695;
    zT_54FF90FA_TaggedUnionPayload zT_696;
    char* zT_698;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_699;
    unsigned int zT_700;
    zT_D3EB6303_StringInterner* zT_702;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_703;
    unsigned int zT_705 = 0;
    char* zT_708;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    unsigned int zT_710;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_711;
    zT_8EED1867_ResolvedTypeTable* zT_712;
    unsigned int zT_713;
    unsigned int zT_714;
    unsigned int zT_717;
    char* zT_719;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_720;
    unsigned int zT_721;
    zT_D3EB6303_StringInterner* zT_723;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_724;
    unsigned int zT_726 = 0;
    unsigned short zT_729;
    unsigned int zT_730;
    int zT_732;
    unsigned int zT_733;
    zT_338B7C76_TypeRegistry* zT_736;
    zT_2DF01B61_FieldEntry* zT_737;
    unsigned int zT_738;
    unsigned int zT_740;
    zT_2DF01B61_FieldEntry zT_741;
    unsigned int zT_742;
    unsigned int zT_746;
    zT_338B7C76_TypeRegistry* zT_748;
    zT_D155D06D_Type* zT_749;
    unsigned int zT_750;
    zT_D155D06D_Type zT_751;
    zT_33EF6BFB_TypeKind zT_752;
    zT_338B7C76_TypeRegistry* zT_758;
    zT_E834303C_ArrayPayload* zT_759;
    unsigned int zT_760;
    unsigned int zT_761;
    zT_E834303C_ArrayPayload zT_762;
    unsigned int zT_763;
    zT_338B7C76_TypeRegistry* zT_764;
    unsigned int zT_765;
    unsigned int zT_769 = 0;
    char* zT_771;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_772;
    unsigned int zT_773;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_774;
    zT_8EED1867_ResolvedTypeTable* zT_775;
    unsigned int zT_776;
    unsigned int zT_777;
    int zT_779;
    unsigned int zT_780;
    unsigned int zT_781;
    unsigned int zT_782;
    unsigned short zT_783;
    unsigned int zT_784;
    zT_33EF6BFB_TypeKind zT_785;
    char* zT_791;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_792;
    unsigned int zT_793;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_794;
    zT_3D7259E2_SymbolRegistry* zT_796;
    unsigned int zT_797;
    unsigned int zT_798;
    zT_E282FB55_Opt_808 zT_801 = {0};
    unsigned char zT_802;
    unsigned int zT_804;
    char* zT_808;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_809;
    unsigned int zT_810;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_811;
    zT_8EED1867_ResolvedTypeTable* zT_812;
    unsigned int zT_813;
    unsigned int zT_814;
    unsigned int zT_817;
    zT_3C598AEF_SymbolKind zT_818;
    zT_8EED1867_ResolvedTypeTable* zT_824;
    unsigned int zT_825;
    zT_BAEE192E_Opt_10 zT_828 = {0};
    unsigned char zT_829;
    char* zT_832;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_833;
    unsigned int zT_834;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_835;
    zT_8EED1867_ResolvedTypeTable* zT_836;
    unsigned int zT_837;
    unsigned int zT_838;
    char* zT_841;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_842;
    unsigned int zT_843;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_844;
    zT_6B0A7D14_AstStore* zT_846;
    unsigned int zT_847;
    zT_22A7C88B_AstNode zT_850 = {0};
    zT_8143F551_AstKind zT_851;
    zT_6B0A7D14_AstStore* zT_857;
    zT_4A837C97_anon_184529 zT_858;
    zT_243D6A41_FnProto* zT_859;
    zT_6B0A7D14_AstStore* zT_860;
    unsigned int zT_861;
    unsigned int zT_864 = 0;
    unsigned int zT_865;
    zT_243D6A41_FnProto zT_866;
    char* zT_868;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_869;
    unsigned int zT_870;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_871;
    unsigned int zT_873;
    unsigned int zT_875;
    zT_8EED1867_ResolvedTypeTable* zT_879;
    unsigned int zT_880;
    zT_BAEE192E_Opt_10 zT_883 = {0};
    unsigned char zT_884;
    zT_338B7C76_TypeRegistry* zT_887;
    unsigned int zT_888;
    unsigned int zT_889;
    unsigned int zT_892;
    unsigned short zT_893;
    unsigned int zT_894;
    unsigned int zT_902 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_903;
    unsigned int zT_904;
    unsigned int zT_905;
    zT_ABC1EBBE_TypeResolveEnv zT_908;
    zT_6B0A7D14_AstStore* zT_909;
    zT_338B7C76_TypeRegistry* zT_910;
    zT_3D7259E2_SymbolRegistry* zT_911;
    zT_D3EB6303_StringInterner* zT_912;
    unsigned int zT_913;
    zT_ABC1EBBE_TypeResolveEnv* zT_915;
    unsigned int zT_916;
    unsigned int zT_921 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_924;
    unsigned int zT_925;
    unsigned int zT_926;
    zT_338B7C76_TypeRegistry* zT_930;
    unsigned int zT_931;
    unsigned int zT_932;
    unsigned int zT_935;
    unsigned short zT_936;
    unsigned int zT_937;
    unsigned int zT_945 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_946;
    unsigned int zT_947;
    unsigned int zT_948;
    zT_338B7C76_TypeRegistry* zT_951;
    unsigned int zT_952;
    unsigned int zT_953;
    unsigned int zT_956;
    unsigned short zT_957;
    unsigned int zT_967 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_968;
    unsigned int zT_969;
    unsigned int zT_970;
    char* zT_973;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_974;
    unsigned int zT_975;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_976;
    zT_3C598AEF_SymbolKind zT_978;
    char* zT_981;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_982;
    unsigned int zT_983;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_984;
    zT_8EED1867_ResolvedTypeTable* zT_985;
    unsigned int zT_986;
    zT_33EF6BFB_TypeKind zT_991;
    zT_338B7C76_TypeRegistry* zT_997;
    zT_0BB2A741_SlicePayload* zT_998;
    unsigned int zT_999;
    unsigned int zT_1000;
    zT_0BB2A741_SlicePayload zT_1001;
    char* zT_1003;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1004;
    unsigned int zT_1005;
    zT_D3EB6303_StringInterner* zT_1007;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1008;
    unsigned int zT_1010 = 0;
    char* zT_1013;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1014;
    unsigned int zT_1015;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1016;
    zT_8EED1867_ResolvedTypeTable* zT_1017;
    unsigned int zT_1018;
    char* zT_1024;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1025;
    unsigned int zT_1026;
    zT_D3EB6303_StringInterner* zT_1028;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1029;
    unsigned int zT_1031 = 0;
    zT_338B7C76_TypeRegistry* zT_1034;
    unsigned int zT_1035;
    unsigned int zT_1040 = 0;
    char* zT_1042;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1043;
    unsigned int zT_1044;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1045;
    zT_8EED1867_ResolvedTypeTable* zT_1046;
    unsigned int zT_1047;
    unsigned int zT_1048;
    zT_33EF6BFB_TypeKind zT_1050;
    char* zT_1056;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1057;
    unsigned int zT_1058;
    zT_D3EB6303_StringInterner* zT_1060;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1061;
    unsigned int zT_1063 = 0;
    char* zT_1066;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1067;
    unsigned int zT_1068;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1069;
    zT_8EED1867_ResolvedTypeTable* zT_1070;
    unsigned int zT_1071;
    zT_33EF6BFB_TypeKind zT_1076;
    zT_338B7C76_TypeRegistry* zT_1082;
    unsigned int zT_1083;
    unsigned int zT_1084;
    unsigned int zT_1086 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_1089;
    unsigned int zT_1090;
    unsigned int zT_1091;
    zT_8EED1867_ResolvedTypeTable* zT_1093;
    unsigned int zT_1094;
    zT_33EF6BFB_TypeKind zT_1099;
    zT_338B7C76_TypeRegistry* zT_1105;
    zT_457ECFEE_EnumPayload* zT_1106;
    unsigned int zT_1107;
    unsigned int zT_1108;
    zT_457ECFEE_EnumPayload zT_1109;
    unsigned int zT_1111;
    unsigned int zT_1112;
    unsigned short zT_1114;
    unsigned int zT_1115;
    int zT_1117;
    unsigned int zT_1118;
    zT_338B7C76_TypeRegistry* zT_1120;
    zT_D96DCDF2_EnumMember* zT_1121;
    unsigned int zT_1122;
    zT_D96DCDF2_EnumMember zT_1123;
    unsigned int zT_1124;
    zT_8EED1867_ResolvedTypeTable* zT_1126;
    unsigned int zT_1127;
    unsigned int zT_1128;
    int zT_1130;
    unsigned int zT_1131;
    char* zT_1133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1134;
    unsigned int zT_1135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1136;
    zT_8EED1867_ResolvedTypeTable* zT_1137;
    unsigned int zT_1138;
    char* zT_1144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1145;
    unsigned int zT_1146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1147;
    zT_8EED1867_ResolvedTypeTable* zT_1148;
    unsigned int zT_1149;
    int zT_1155;
    unsigned int zT_1156;
    zT_338B7C76_TypeRegistry* zT_1159;
    zT_2DF01B61_FieldEntry* zT_1160;
    unsigned int zT_1161;
    zT_2DF01B61_FieldEntry zT_1162;
    unsigned int zT_1163;
    unsigned int zT_1166;
    zT_338B7C76_TypeRegistry* zT_1168;
    zT_D155D06D_Type* zT_1169;
    unsigned int zT_1170;
    zT_D155D06D_Type zT_1171;
    zT_33EF6BFB_TypeKind zT_1172;
    zT_338B7C76_TypeRegistry* zT_1178;
    zT_E834303C_ArrayPayload* zT_1179;
    unsigned int zT_1180;
    unsigned int zT_1181;
    zT_E834303C_ArrayPayload zT_1182;
    unsigned int zT_1183;
    zT_338B7C76_TypeRegistry* zT_1184;
    unsigned int zT_1185;
    unsigned int zT_1189 = 0;
    char* zT_1191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1192;
    unsigned int zT_1193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1194;
    unsigned int zT_1195;
    zT_8EED1867_ResolvedTypeTable* zT_1196;
    unsigned int zT_1197;
    unsigned int zT_1198;
    int zT_1200;
    unsigned int zT_1202;
    char* zT_1204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1205;
    unsigned int zT_1206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1207;
    char* zT_1209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1210;
    unsigned int zT_1211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1212;
    unsigned int zT_1213;
    char* zT_1215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1216;
    unsigned int zT_1217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1218;
    unsigned int zT_1219;
    char* zT_1221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1222;
    unsigned int zT_1223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1224;
    unsigned int zT_1225;
    zT_8EED1867_ResolvedTypeTable* zT_1226;
    unsigned int zT_1227;
    zT_8F083A69_Slice_zT_0B42B2F8_u fae;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode base_node;
    unsigned int field_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_bkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_fnm;
    unsigned int base_rt;
    unsigned int base_ident_id;
    zT_E282FB55_Opt_808 sym;
    unsigned int base_type_id;
    zT_3A105EF1_Symbol* s;
    unsigned int alias_type_id;
    zT_D155D06D_Type aty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int fi;
    zT_457ECFEE_EnumPayload ep;
    unsigned int estart;
    unsigned int ecount;
    unsigned int ei;
    unsigned int es_mi;
    unsigned int target_mod;
    zT_E282FB55_Opt_808 field_sym;
    zT_3A105EF1_Symbol* fs;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1kl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1tl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1v_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fx;
    zT_22A7C88B_AstNode fn_dn;
    zT_243D6A41_FnProto proto;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre1_m;
    zT_BAEE192E_Opt_10 rtt;
    unsigned int rtt_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre3_m;
    unsigned int fn_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre4_m;
    unsigned int rv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre2_m;
    unsigned int rtv;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int resolved_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr1_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr2_m;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u uinm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uiparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u uimsg;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fa1;
    zT_D155D06D_Type base_ty;
    unsigned int fields_start;
    unsigned int fields_count;
    zT_33EF6BFB_TypeKind pre_kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_ok_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_dk_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_nl;
    unsigned int sp;
    unsigned int ep_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u opt_msg;
    unsigned int ep_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u eu_msg;
    zT_406493CE_StructPayload sp_3;
    zT_AF9231A2_UnionPayload up;
    zT_8F083A69_Slice_zT_0B42B2F8_u tag_s;
    unsigned int tag_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ft_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u payload_s;
    unsigned int payload_id;
    unsigned int fpe_count;
    unsigned int fpei;
    zT_2DF01B61_FieldEntry fpe;
    unsigned int payload_res;
    zT_D155D06D_Type payload_rt;
    unsigned int payload_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpe_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfa;
    zT_E282FB55_Opt_808 mod_field_sym;
    zT_3A105EF1_Symbol* mfs;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf3;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf1;
    zT_BAEE192E_Opt_10 fn_tid_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf2_m;
    unsigned int fn_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u mff;
    zT_22A7C88B_AstNode dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfp_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_b;
    unsigned int resolved_rt_b;
    zT_0BB2A741_SlicePayload sp_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u len_s;
    unsigned int len_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsl;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptr_s;
    unsigned int ptr_id;
    unsigned int pty;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u faa_m;
    unsigned int es_mi2;
    zT_457ECFEE_EnumPayload ep3;
    unsigned int estart3;
    unsigned int ecount3;
    unsigned int ei3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2b_m;
    unsigned int result;
    zT_D155D06D_Type rt;
    unsigned int elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_3 = "FAE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fae = zT_4;
    zT_6 = fae;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    base_node = zT_17;
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    field_name_id = zT_22;
    zT_24 = "PFA:BK";
    zT_26 = 6;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    pfa_bkm = zT_25;
    zT_27 = pfa_bkm;
    zT_29 = base_node.kind;
    zF_C914CB83_markerWriteInt(zT_27, (unsigned int)((unsigned int)zT_29));
    zT_32 = "PFA:FN";
    zT_34 = 6;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    pfa_fnm = zT_33;
    zT_35 = pfa_fnm;
    zT_36 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_35, zT_36);
    zT_37 = base_node.kind;
    if ((int)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_43 = self;
    zT_44 = node.child_0;
    zT_46 = zF_54F95822_semanticAnalyzerRes(zT_43, zT_44);
    base_rt = zT_46;
    zT_48 = self->store;
    zT_49 = node.child_0;
    zT_52 = zF_53458827_astStoreIdentifier(zT_48, zT_49);
    base_ident_id = zT_52;
    zT_54 = self->symbols;
    zT_55 = self->module_id;
    zT_56 = base_ident_id;
    zT_59 = zF_A398987E_symbolRegistryQuali(zT_54, zT_55, zT_56);
    sym = zT_59;
    zT_60 = sym.has_value;
    if (zT_60) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_523 = self;
    zT_524 = node.child_0;
    zT_526 = zF_54F95822_semanticAnalyzerRes(zT_523, zT_524);
    base_type_id = zT_526;
    if ((int)(base_type_id == (unsigned int)(1))) goto z_bb_71; else goto z_bb_72;
    z_bb_3:
    zT_471 = base_node.kind;
    if ((int)(zT_471 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_59; else goto z_bb_60;
    z_bb_4:
    s = sym.value;
    zT_62 = s->kind;
    if ((int)(zT_62 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    if ((int)(base_rt == (unsigned int)(1))) goto z_bb_57; else goto z_bb_58;
    z_bb_7:
    zT_68 = s->type_id;
    alias_type_id = zT_68;
    if ((int)(alias_type_id != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_159 = s->kind;
    if ((int)(zT_159 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_31; else goto z_bb_32;
    z_bb_9:
    zT_72 = self->registry;
    zT_73 = zT_72->types_items;
    zT_74 = (unsigned int)alias_type_id;
    zT_75 = zT_73[zT_74];
    aty = zT_75;
    zT_76 = aty.kind;
    if ((int)(zT_76 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_82 = self->registry;
    zT_83 = zT_82->tu_items;
    zT_84 = aty.payload_idx;
    zT_85 = (unsigned int)zT_84;
    zT_86 = zT_83[zT_85];
    tp = zT_86;
    zT_88 = tp.fields_start;
    zT_89 = (unsigned int)zT_88;
    fstart = zT_89;
    zT_91 = tp.fields_count;
    zT_92 = (unsigned int)zT_91;
    fcount = zT_92;
    zT_94 = 0;
    zT_95 = (unsigned int)zT_94;
    fi = zT_95;
    goto z_bb_13;
    z_bb_12:
    zT_109 = aty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    if ((int)(fi < fcount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_97 = self->registry;
    zT_98 = zT_97->fe_items;
    zT_99 = fstart + fi;
    zT_100 = zT_98[zT_99];
    zT_101 = zT_100.name_id;
    if ((int)(zT_101 == field_name_id)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_107 = 1;
    zT_108 = fi + zT_107;
    fi = zT_108;
    goto z_bb_13;
    z_bb_17:
    zT_103 = self->type_table;
    zT_104 = node_idx;
    zT_105 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_103, zT_104, zT_105);
    return alias_type_id;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_115 = self->registry;
    zT_116 = zT_115->en_items;
    zT_117 = aty.payload_idx;
    zT_118 = (unsigned int)zT_117;
    zT_119 = zT_116[zT_118];
    ep = zT_119;
    zT_121 = ep.members_start;
    zT_122 = (unsigned int)zT_121;
    estart = zT_122;
    zT_124 = ep.members_count;
    zT_125 = (unsigned int)zT_124;
    ecount = zT_125;
    zT_127 = 0;
    zT_128 = (unsigned int)zT_127;
    ei = zT_128;
    goto z_bb_21;
    z_bb_20:
    zT_142 = aty.kind;
    if ((int)(zT_142 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    if ((int)(ei < ecount)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_130 = self->registry;
    zT_131 = zT_130->em_items;
    zT_132 = estart + ei;
    zT_133 = zT_131[zT_132];
    zT_134 = zT_133.name_id;
    if ((int)(zT_134 == field_name_id)) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_140 = 1;
    zT_141 = ei + zT_140;
    ei = zT_141;
    goto z_bb_21;
    z_bb_25:
    zT_136 = self->type_table;
    zT_137 = node_idx;
    zT_138 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_136, zT_137, zT_138);
    return alias_type_id;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_148 = self->registry;
    zT_149 = alias_type_id;
    zT_150 = field_name_id;
    zT_152 = zF_D2ECD176_typeRegistryErrorSe(zT_148, zT_149, zT_150);
    es_mi = zT_152;
    if ((int)(es_mi != (unsigned int)(4294967295u))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    zT_155 = self->type_table;
    zT_156 = node_idx;
    zT_157 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_155, zT_156, zT_157);
    return alias_type_id;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_165 = s->module_id;
    target_mod = zT_165;
    zT_167 = self->symbols;
    zT_168 = target_mod;
    zT_169 = field_name_id;
    zT_171 = zF_A398987E_symbolRegistryQuali(zT_167, zT_168, zT_169);
    field_sym = zT_171;
    zT_172 = field_sym.has_value;
    if (zT_172) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_5;
    z_bb_33:
    fs = field_sym.value;
    zT_175 = "Q1:FL";
    zT_177 = 5;
    zT_176.ptr = zT_175;
    zT_176.len = zT_177;
    q1fl_m = zT_176;
    zT_178 = q1fl_m;
    zT_180 = fs->flags;
    zF_C914CB83_markerWriteInt(zT_178, (unsigned int)((unsigned int)zT_180));
    zT_183 = "Q1:KL";
    zT_185 = 5;
    zT_184.ptr = zT_183;
    zT_184.len = zT_185;
    q1kl_m = zT_184;
    zT_186 = q1kl_m;
    zT_188 = fs->kind;
    zF_C914CB83_markerWriteInt(zT_186, (unsigned int)((unsigned int)zT_188));
    zT_191 = "Q1:TL";
    zT_193 = 5;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    q1tl_m = zT_192;
    zT_194 = q1tl_m;
    zT_195 = fs->type_id;
    zF_C914CB83_markerWriteInt(zT_194, zT_195);
    zT_198 = "Q1:FN";
    zT_200 = 5;
    zT_199.ptr = zT_198;
    zT_199.len = zT_200;
    q1fn_m = zT_199;
    zT_201 = q1fn_m;
    zT_202 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_201, zT_202);
    zT_203 = fs->flags;
    if ((int)((unsigned short)(zT_203 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_404 = "Q1VF:FN";
    zT_406 = 7;
    zT_405.ptr = zT_404;
    zT_405.len = zT_406;
    q1v_m = zT_405;
    zT_407 = q1v_m;
    zT_408 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_407, zT_408);
    zT_409 = self->type_table;
    zT_410 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_409, zT_410, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_35:
    zT_208 = fs->kind;
    if ((int)(zT_208 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_228 = fs->kind;
    if ((int)(zT_228 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_41; else goto z_bb_42;
    z_bb_37:
    zT_213 = self->type_table;
    zT_214 = node_idx;
    zT_215 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_213, zT_214, zT_215);
    zT_218 = fs->type_id;
    return zT_218;
    z_bb_38:
    zT_219 = fs->type_id;
    if ((int)(zT_219 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_222 = self->type_table;
    zT_223 = node_idx;
    zT_224 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_222, zT_223, zT_224);
    zT_227 = fs->type_id;
    return zT_227;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_234 = fs->decl_node;
    zT_233 = zT_234 != (unsigned int)(0);
    goto z_bb_43;
    z_bb_42:
    zT_233 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_233) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_238 = "Q1FX\n";
    zT_240 = 5;
    zT_239.ptr = zT_238;
    zT_239.len = zT_240;
    q1fx = zT_239;
    zT_241 = q1fx;
    zF_48AC7B3A_markerWrite(zT_241);
    zT_243 = self->store;
    zT_244 = fs->decl_node;
    zT_247 = zF_FCDD1D35_astStoreNodeAt(zT_243, zT_244);
    fn_dn = zT_247;
    zT_248 = fn_dn.kind;
    if ((int)(zT_248 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_34;
    z_bb_46:
    zT_254 = self->store;
    zT_255 = zT_254->fn_protos;
    zT_256 = zT_255.items;
    zT_257 = self->store;
    zT_258 = fs->decl_node;
    zT_261 = zF_8BA26B9E_astStoreNodePayload(zT_257, zT_258);
    zT_262 = (unsigned int)zT_261;
    zT_263 = zT_256[zT_262];
    proto = zT_263;
    zT_265 = "BR:x";
    zT_267 = 4;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    bre1_m = zT_266;
    zT_268 = bre1_m;
    zT_269 = proto.name_id;
    zF_C914CB83_markerWriteInt(zT_268, zT_269);
    zT_271 = proto.return_type_node;
    if ((int)(zT_271 != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_275 = self->type_table;
    zT_276 = proto.return_type_node;
    zT_279 = zF_999DCF51_resolvedTypeTableGe(zT_275, zT_276);
    rtt = zT_279;
    zT_281 = rtt.has_value;
    if (zT_281) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    zT_371 = "BR:dv\n";
    zT_373 = 6;
    zT_372.ptr = zT_371;
    zT_372.len = zT_373;
    bre3_m = zT_372;
    zT_374 = bre3_m;
    zF_48AC7B3A_markerWrite(zT_374);
    zT_376 = self->registry;
    zT_377 = proto.name_id;
    zT_378 = fs->module_id;
    zT_381 = proto.params_start;
    zT_382 = proto.params_count;
    zT_392 = zF_474336D7_typeRegistryGetOrCr(zT_376, zT_377, zT_378, (unsigned char)(0), (unsigned char)(0), zT_381, zT_382, (unsigned int)(1));
    fn_ty = zT_392;
    zT_394 = "BR:ft";
    zT_396 = 5;
    zT_395.ptr = zT_394;
    zT_395.len = zT_396;
    bre4_m = zT_395;
    zT_397 = bre4_m;
    zT_398 = fn_ty;
    zF_C914CB83_markerWriteInt(zT_397, zT_398);
    zT_399 = self->type_table;
    zT_400 = node_idx;
    zT_401 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_399, zT_400, zT_401);
    return fn_ty;
    z_bb_50:
    rv = rtt.value;
    zT_282 = rv;
    goto z_bb_52;
    z_bb_51:
    zT_282 = 0;
    goto z_bb_52;
    z_bb_52:
    rtt_val = zT_282;
    zT_286 = "BR:rt";
    zT_288 = 5;
    zT_287.ptr = zT_286;
    zT_287.len = zT_288;
    bre2_m = zT_287;
    zT_289 = bre2_m;
    zT_290 = rtt_val;
    zF_C914CB83_markerWriteInt(zT_289, zT_290);
    zT_291 = rtt.has_value;
    if (zT_291) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    rtv = rtt.value;
    zT_294 = self->registry;
    zT_295 = proto.name_id;
    zT_296 = fs->module_id;
    zT_299 = proto.params_start;
    zT_300 = proto.params_count;
    zT_301 = rtv;
    zT_309 = zF_474336D7_typeRegistryGetOrCr(zT_294, zT_295, zT_296, (unsigned char)(0), (unsigned char)(0), zT_299, zT_300, zT_301);
    fn_ty = zT_309;
    zT_310 = self->type_table;
    zT_311 = node_idx;
    zT_312 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_310, zT_311, zT_312);
    return fn_ty;
    z_bb_54:
    zT_316 = self->store;
    zT_315.store = zT_316;
    zT_317 = self->registry;
    zT_315.typereg = zT_317;
    zT_318 = self->symbols;
    zT_315.symbol_reg = zT_318;
    zT_319 = self->interner;
    zT_315.interner = zT_319;
    zT_320 = fs->module_id;
    zT_315.module_id = zT_320;
    tre_env = zT_315;
    zT_322 = &tre_env;
    zT_323 = proto.return_type_node;
    zT_328 = zF_F2107C15_resolveTypeExprFull(zT_322, zT_323, (unsigned int)(0));
    resolved_rt = zT_328;
    zT_330 = "BR:treN";
    zT_332 = 7;
    zT_331.ptr = zT_330;
    zT_331.len = zT_332;
    brr1_m = zT_331;
    zT_333 = brr1_m;
    zT_334 = proto.return_type_node;
    zF_C914CB83_markerWriteInt(zT_333, zT_334);
    zT_337 = "BR:treT";
    zT_339 = 7;
    zT_338.ptr = zT_337;
    zT_338.len = zT_339;
    brr2_m = zT_338;
    zT_340 = brr2_m;
    zT_341 = resolved_rt;
    zF_C914CB83_markerWriteInt(zT_340, zT_341);
    if ((int)(resolved_rt != (unsigned int)(18))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_344 = self->type_table;
    zT_345 = proto.return_type_node;
    zT_346 = resolved_rt;
    zF_19B4A07D_resolvedTypeTableSe(zT_344, zT_345, zT_346);
    zT_350 = self->registry;
    zT_351 = proto.name_id;
    zT_352 = fs->module_id;
    zT_355 = proto.params_start;
    zT_356 = proto.params_count;
    zT_357 = resolved_rt;
    zT_365 = zF_474336D7_typeRegistryGetOrCr(zT_350, zT_351, zT_352, (unsigned char)(0), (unsigned char)(0), zT_355, zT_356, zT_357);
    fn_ty = zT_365;
    zT_366 = self->type_table;
    zT_367 = node_idx;
    zT_368 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_366, zT_367, zT_368);
    return fn_ty;
    z_bb_56:
    goto z_bb_49;
    z_bb_57:
    zT_418 = base_node.span_start;
    uisp = zT_418;
    zT_420 = base_node.span_len;
    zT_422 = uisp + (unsigned int)((unsigned int)zT_420);
    uiep = zT_422;
    zT_424 = self->interner;
    zT_425 = base_ident_id;
    zT_427 = zF_9134020D_stringInternerGet(zT_424, zT_425);
    uinm = zT_427;
    zT_429 = "identifier '";
    zT_431 = 12;
    zT_430.ptr = zT_429;
    zT_430.len = zT_431;
    ui1 = zT_430;
    zT_433 = "' is not declared or imported in this module";
    zT_435 = 44;
    zT_434.ptr = zT_433;
    zT_434.len = zT_435;
    ui2 = zT_434;
    zT_438 = 0;
    zT_437[zT_438] = ui1;
    zT_439 = 1;
    zT_437[zT_439] = uinm;
    zT_440 = 2;
    zT_437[zT_440] = ui2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uiparts[_i] = zT_437[_i];
        _i++;
    }
}
    zT_442 = self->interner;
    zT_446 = 0;
    zT_447 = uiparts + zT_446;
    zT_443 = zT_447;
    zT_449 = zF_8C4BFF7C_diagnosticBuilderMa(zT_442, zT_443, (unsigned int)(3));
    uimsg = zT_449;
    zT_450 = self->diag;
    zT_453 = self->source_file_id;
    zT_454 = uisp;
    zT_455 = uiep;
    zT_456 = uimsg;
    zT_464 = zF_C82559AC_diagnosticCollector(zT_450, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3001_UNDEFINED_SYMBOL)), zT_453, zT_454, zT_455, zT_456);
    (void)zT_464;
    zT_465 = self->type_table;
    zT_466 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_465, zT_466, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_58:
    goto z_bb_5;
    z_bb_59:
    zT_477 = self->store;
    zT_478 = node.child_0;
    zT_481 = zF_8BA26B9E_astStoreNodePayload(zT_477, zT_478);
    path_id = zT_481;
    zT_483 = self->module_reg;
    zT_484 = path_id;
    zT_486 = zF_A258E183_moduleRegistryPathT(zT_483, zT_484);
    target = zT_486;
    zT_487 = target.has_value;
    if (zT_487) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_2;
    z_bb_61:
    mtid = target.value;
    zT_490 = self->symbols;
    zT_491 = mtid;
    zT_492 = field_name_id;
    zT_494 = zF_A398987E_symbolRegistryQuali(zT_490, zT_491, zT_492);
    field_sym = zT_494;
    zT_495 = field_sym.has_value;
    if (zT_495) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    fs = field_sym.value;
    zT_497 = fs->flags;
    if ((int)((unsigned short)(zT_497 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    zT_502 = fs->kind;
    if ((int)(zT_502 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_507 = self->type_table;
    zT_508 = node_idx;
    zT_509 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_507, zT_508, zT_509);
    zT_512 = fs->type_id;
    return zT_512;
    z_bb_68:
    zT_513 = fs->type_id;
    if ((int)(zT_513 != (unsigned int)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_516 = self->type_table;
    zT_517 = node_idx;
    zT_518 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_516, zT_517, zT_518);
    zT_521 = fs->type_id;
    return zT_521;
    z_bb_70:
    goto z_bb_66;
    z_bb_71:
    zT_530 = "FB\n";
    zT_532 = 3;
    zT_531.ptr = zT_530;
    zT_531.len = zT_532;
    fa1 = zT_531;
    zT_533 = fa1;
    zF_48AC7B3A_markerWrite(zT_533);
    zT_534 = self->type_table;
    zT_535 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_534, zT_535, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_72:
    zT_541 = self->registry;
    zT_542 = zT_541->types_items;
    zT_543 = (unsigned int)base_type_id;
    zT_544 = zT_542[zT_543];
    base_ty = zT_544;
    zT_546 = 0;
    zT_547 = (unsigned int)zT_546;
    fields_start = zT_547;
    zT_549 = 0;
    zT_550 = (unsigned int)zT_549;
    fields_count = zT_550;
    zT_551 = base_ty.kind;
    if ((int)(zT_551 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_557 = base_ty.kind;
    zT_556 = zT_557 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_75;
    z_bb_74:
    zT_556 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_556) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_563 = base_ty.kind;
    pre_kind = zT_563;
    zT_564 = self->registry;
    zT_565 = zT_564->ptr_items;
    zT_566 = base_ty.payload_idx;
    zT_567 = (unsigned int)zT_566;
    zT_568 = zT_565[zT_567];
    zT_569 = zT_568.base;
    base_type_id = zT_569;
    zT_570 = self->registry;
    zT_571 = zT_570->types_items;
    zT_572 = (unsigned int)base_type_id;
    zT_573 = zT_571[zT_572];
    base_ty = zT_573;
    zT_575 = "FAPR:OK";
    zT_577 = 7;
    zT_576.ptr = zT_575;
    zT_576.len = zT_577;
    fapr_ok_m = zT_576;
    zT_578 = fapr_ok_m;
    zF_C914CB83_markerWriteInt(zT_578, (unsigned int)((unsigned int)pre_kind));
    zT_582 = "FAPR:DK";
    zT_584 = 7;
    zT_583.ptr = zT_582;
    zT_583.len = zT_584;
    fapr_dk_m = zT_583;
    zT_585 = fapr_dk_m;
    zT_587 = base_ty.kind;
    zF_C914CB83_markerWriteInt(zT_585, (unsigned int)((unsigned int)zT_587));
    zT_590 = "\n";
    zT_592 = 1;
    zT_591.ptr = zT_590;
    zT_591.len = zT_592;
    fapr_nl = zT_591;
    zT_593 = fapr_nl;
    zF_48AC7B3A_markerWrite(zT_593);
    goto z_bb_77;
    z_bb_77:
    zT_594 = base_ty.kind;
    if ((int)(zT_594 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_600 = node.span_start;
    sp = zT_600;
    zT_602 = node.span_len;
    zT_604 = sp + (unsigned int)((unsigned int)zT_602);
    ep_1 = zT_604;
    zT_606 = "cannot access field on optional type; use .? to unwrap first";
    zT_608 = 60;
    zT_607.ptr = zT_606;
    zT_607.len = zT_608;
    opt_msg = zT_607;
    zT_609 = self->diag;
    zT_612 = self->source_file_id;
    zT_613 = sp;
    zT_614 = ep_1;
    zT_615 = opt_msg;
    zT_620 = zF_C82559AC_diagnosticCollector(zT_609, (unsigned char)(0), (unsigned short)(3000), zT_612, zT_613, zT_614, zT_615);
    (void)zT_620;
    return (unsigned int)(1);
    z_bb_79:
    zT_622 = base_ty.kind;
    if ((int)(zT_622 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_628 = node.span_start;
    sp = zT_628;
    zT_630 = node.span_len;
    zT_632 = sp + (unsigned int)((unsigned int)zT_630);
    ep_2 = zT_632;
    zT_634 = "cannot access field on error-union type; handle the error first";
    zT_636 = 63;
    zT_635.ptr = zT_634;
    zT_635.len = zT_636;
    eu_msg = zT_635;
    zT_637 = self->diag;
    zT_640 = self->source_file_id;
    zT_641 = sp;
    zT_642 = ep_2;
    zT_643 = eu_msg;
    zT_648 = zF_C82559AC_diagnosticCollector(zT_637, (unsigned char)(0), (unsigned short)(3000), zT_640, zT_641, zT_642, zT_643);
    (void)zT_648;
    return (unsigned int)(1);
    z_bb_81:
    zT_650 = base_ty.kind;
    if ((int)(zT_650 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_82; else goto z_bb_84;
    z_bb_82:
    zT_656 = self->registry;
    zT_657 = zT_656->st_items;
    zT_658 = base_ty.payload_idx;
    zT_659 = (unsigned int)zT_658;
    zT_660 = zT_657[zT_659];
    sp_3 = zT_660;
    zT_661 = sp_3.fields_start;
    zT_662 = (unsigned int)zT_661;
    fields_start = zT_662;
    zT_663 = sp_3.fields_count;
    zT_664 = (unsigned int)zT_663;
    fields_count = zT_664;
    goto z_bb_83;
    z_bb_83:
    zT_1155 = 0;
    zT_1156 = (unsigned int)zT_1155;
    fi = zT_1156;
    goto z_bb_152;
    z_bb_84:
    zT_665 = base_ty.kind;
    if ((int)(zT_665 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_671 = base_ty.kind;
    zT_670 = zT_671 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_87;
    z_bb_86:
    zT_670 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_670) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    zT_677 = self->registry;
    zT_678 = zT_677->un_items;
    zT_679 = base_ty.payload_idx;
    zT_680 = (unsigned int)zT_679;
    zT_681 = zT_678[zT_680];
    up = zT_681;
    zT_682 = up.fields_start;
    zT_683 = (unsigned int)zT_682;
    fields_start = zT_683;
    zT_684 = up.fields_count;
    zT_685 = (unsigned int)zT_684;
    fields_count = zT_685;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_83;
    z_bb_90:
    zT_686 = base_ty.kind;
    if ((int)(zT_686 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_692 = self->registry;
    zT_693 = zT_692->tu_items;
    zT_694 = base_ty.payload_idx;
    zT_695 = (unsigned int)zT_694;
    zT_696 = zT_693[zT_695];
    tp = zT_696;
    zT_698 = "tag";
    zT_700 = 3;
    zT_699.ptr = zT_698;
    zT_699.len = zT_700;
    tag_s = zT_699;
    zT_702 = self->interner;
    zT_703 = tag_s;
    zT_705 = zF_50C274AF_stringInternerInter(zT_702, zT_703);
    tag_id = zT_705;
    if ((int)(field_name_id == tag_id)) goto z_bb_94; else goto z_bb_95;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_785 = base_ty.kind;
    if ((int)(zT_785 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_106; else goto z_bb_108;
    z_bb_94:
    zT_708 = "FT:TAG\n";
    zT_710 = 7;
    zT_709.ptr = zT_708;
    zT_709.len = zT_710;
    ft_m = zT_709;
    zT_711 = ft_m;
    zF_48AC7B3A_markerWrite(zT_711);
    zT_712 = self->type_table;
    zT_713 = node_idx;
    zT_714 = tp.tag_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_712, zT_713, zT_714);
    zT_717 = tp.tag_type;
    return zT_717;
    z_bb_95:
    zT_719 = "payload";
    zT_721 = 7;
    zT_720.ptr = zT_719;
    zT_720.len = zT_721;
    payload_s = zT_720;
    zT_723 = self->interner;
    zT_724 = payload_s;
    zT_726 = zF_50C274AF_stringInternerInter(zT_723, zT_724);
    payload_id = zT_726;
    if ((int)(field_name_id == payload_id)) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_729 = tp.fields_count;
    zT_730 = (unsigned int)zT_729;
    fpe_count = zT_730;
    zT_732 = 0;
    zT_733 = (unsigned int)zT_732;
    fpei = zT_733;
    goto z_bb_98;
    z_bb_97:
    zT_781 = tp.fields_start;
    zT_782 = (unsigned int)zT_781;
    fields_start = zT_782;
    zT_783 = tp.fields_count;
    zT_784 = (unsigned int)zT_783;
    fields_count = zT_784;
    goto z_bb_92;
    z_bb_98:
    if ((int)(fpei < fpe_count)) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_736 = self->registry;
    zT_737 = zT_736->fe_items;
    zT_738 = tp.fields_start;
    zT_740 = (unsigned int)((unsigned int)zT_738) + fpei;
    zT_741 = zT_737[zT_740];
    fpe = zT_741;
    zT_742 = fpe.type_id;
    if ((int)(zT_742 != (unsigned int)(1))) goto z_bb_102; else goto z_bb_103;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_779 = 1;
    zT_780 = fpei + zT_779;
    fpei = zT_780;
    goto z_bb_98;
    z_bb_102:
    zT_746 = fpe.type_id;
    payload_res = zT_746;
    zT_748 = self->registry;
    zT_749 = zT_748->types_items;
    zT_750 = (unsigned int)payload_res;
    zT_751 = zT_749[zT_750];
    payload_rt = zT_751;
    zT_752 = payload_rt.kind;
    if ((int)(zT_752 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_104; else goto z_bb_105;
    z_bb_103:
    goto z_bb_101;
    z_bb_104:
    zT_758 = self->registry;
    zT_759 = zT_758->array_items;
    zT_760 = payload_rt.payload_idx;
    zT_761 = (unsigned int)zT_760;
    zT_762 = zT_759[zT_761];
    zT_763 = zT_762.elem;
    payload_elem = zT_763;
    zT_764 = self->registry;
    zT_765 = payload_elem;
    zT_769 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_764, zT_765, (int)(0));
    payload_res = zT_769;
    goto z_bb_105;
    z_bb_105:
    zT_771 = "FP:PAYLOAD\n";
    zT_773 = 11;
    zT_772.ptr = zT_771;
    zT_772.len = zT_773;
    fpe_m = zT_772;
    zT_774 = fpe_m;
    zF_48AC7B3A_markerWrite(zT_774);
    zT_775 = self->type_table;
    zT_776 = node_idx;
    zT_777 = payload_res;
    zF_19B4A07D_resolvedTypeTableSe(zT_775, zT_776, zT_777);
    return payload_res;
    z_bb_106:
    zT_791 = "MFA\n";
    zT_793 = 4;
    zT_792.ptr = zT_791;
    zT_792.len = zT_793;
    mfa = zT_792;
    zT_794 = mfa;
    zF_48AC7B3A_markerWrite(zT_794);
    zT_796 = self->symbols;
    zT_797 = base_ty.module_id;
    zT_798 = field_name_id;
    zT_801 = zF_A398987E_symbolRegistryQuali(zT_796, zT_797, zT_798);
    mod_field_sym = zT_801;
    zT_802 = mod_field_sym.has_value;
    if (zT_802) goto z_bb_109; else goto z_bb_111;
    z_bb_107:
    goto z_bb_92;
    z_bb_108:
    zT_991 = base_ty.kind;
    if ((int)(zT_991 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_126; else goto z_bb_128;
    z_bb_109:
    mfs = mod_field_sym.value;
    zT_804 = mfs->type_id;
    if ((int)(zT_804 != (unsigned int)(0))) goto z_bb_112; else goto z_bb_113;
    z_bb_110:
    zT_985 = self->type_table;
    zT_986 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_985, zT_986, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_111:
    zT_981 = "MF3\n";
    zT_983 = 4;
    zT_982.ptr = zT_981;
    zT_982.len = zT_983;
    mf3 = zT_982;
    zT_984 = mf3;
    zF_48AC7B3A_markerWrite(zT_984);
    goto z_bb_110;
    z_bb_112:
    zT_808 = "MF1\n";
    zT_810 = 4;
    zT_809.ptr = zT_808;
    zT_809.len = zT_810;
    mf1 = zT_809;
    zT_811 = mf1;
    zF_48AC7B3A_markerWrite(zT_811);
    zT_812 = self->type_table;
    zT_813 = node_idx;
    zT_814 = mfs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_812, zT_813, zT_814);
    zT_817 = mfs->type_id;
    return zT_817;
    z_bb_113:
    zT_818 = mfs->kind;
    if ((int)(zT_818 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_824 = self->type_table;
    zT_825 = mfs->decl_node;
    zT_828 = zF_999DCF51_resolvedTypeTableGe(zT_824, zT_825);
    fn_tid_opt = zT_828;
    zT_829 = fn_tid_opt.has_value;
    if (zT_829) goto z_bb_116; else goto z_bb_117;
    z_bb_115:
    zT_973 = "MF2";
    zT_975 = 3;
    zT_974.ptr = zT_973;
    zT_974.len = zT_975;
    mf2_m = zT_974;
    zT_976 = mf2_m;
    zT_978 = mfs->kind;
    zF_C914CB83_markerWriteInt(zT_976, (unsigned int)((unsigned int)zT_978));
    goto z_bb_110;
    z_bb_116:
    fn_tid = fn_tid_opt.value;
    zT_832 = "MF1\n";
    zT_834 = 4;
    zT_833.ptr = zT_832;
    zT_833.len = zT_834;
    mf1 = zT_833;
    zT_835 = mf1;
    zF_48AC7B3A_markerWrite(zT_835);
    zT_836 = self->type_table;
    zT_837 = node_idx;
    zT_838 = fn_tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_836, zT_837, zT_838);
    return fn_tid;
    z_bb_117:
    zT_841 = "MFF\n";
    zT_843 = 4;
    zT_842.ptr = zT_841;
    zT_842.len = zT_843;
    mff = zT_842;
    zT_844 = mff;
    zF_48AC7B3A_markerWrite(zT_844);
    zT_846 = self->store;
    zT_847 = mfs->decl_node;
    zT_850 = zF_FCDD1D35_astStoreNodeAt(zT_846, zT_847);
    dn = zT_850;
    zT_851 = dn.kind;
    if ((int)(zT_851 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_857 = self->store;
    zT_858 = zT_857->fn_protos;
    zT_859 = zT_858.items;
    zT_860 = self->store;
    zT_861 = mfs->decl_node;
    zT_864 = zF_8BA26B9E_astStoreNodePayload(zT_860, zT_861);
    zT_865 = (unsigned int)zT_864;
    zT_866 = zT_859[zT_865];
    proto = zT_866;
    zT_868 = "MFP";
    zT_870 = 3;
    zT_869.ptr = zT_868;
    zT_869.len = zT_870;
    mfp_m = zT_869;
    zT_871 = mfp_m;
    zT_873 = proto.params_start;
    zF_C914CB83_markerWriteInt(zT_871, (unsigned int)((unsigned int)zT_873));
    zT_875 = proto.return_type_node;
    if ((int)(zT_875 != (unsigned int)(0))) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    goto z_bb_115;
    z_bb_120:
    zT_879 = self->type_table;
    zT_880 = proto.return_type_node;
    zT_883 = zF_999DCF51_resolvedTypeTableGe(zT_879, zT_880);
    rtt = zT_883;
    zT_884 = rtt.has_value;
    if (zT_884) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_951 = self->registry;
    zT_952 = proto.name_id;
    zT_953 = mfs->module_id;
    zT_956 = proto.params_start;
    zT_957 = proto.params_count;
    zT_967 = zF_474336D7_typeRegistryGetOrCr(zT_951, zT_952, zT_953, (unsigned char)(0), (unsigned char)(0), zT_956, zT_957, (unsigned int)(1));
    fn_ty = zT_967;
    zT_968 = self->type_table;
    zT_969 = node_idx;
    zT_970 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_968, zT_969, zT_970);
    return fn_ty;
    z_bb_122:
    rtv = rtt.value;
    zT_887 = self->registry;
    zT_888 = proto.name_id;
    zT_889 = mfs->module_id;
    zT_892 = proto.params_start;
    zT_893 = proto.params_count;
    zT_894 = rtv;
    zT_902 = zF_474336D7_typeRegistryGetOrCr(zT_887, zT_888, zT_889, (unsigned char)(0), (unsigned char)(0), zT_892, zT_893, zT_894);
    fn_ty = zT_902;
    zT_903 = self->type_table;
    zT_904 = node_idx;
    zT_905 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_903, zT_904, zT_905);
    return fn_ty;
    z_bb_123:
    zT_909 = self->store;
    zT_908.store = zT_909;
    zT_910 = self->registry;
    zT_908.typereg = zT_910;
    zT_911 = self->symbols;
    zT_908.symbol_reg = zT_911;
    zT_912 = self->interner;
    zT_908.interner = zT_912;
    zT_913 = mfs->module_id;
    zT_908.module_id = zT_913;
    tre_env_b = zT_908;
    zT_915 = &tre_env_b;
    zT_916 = proto.return_type_node;
    zT_921 = zF_F2107C15_resolveTypeExprFull(zT_915, zT_916, (unsigned int)(0));
    resolved_rt_b = zT_921;
    if ((int)(resolved_rt_b != (unsigned int)(18))) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    zT_924 = self->type_table;
    zT_925 = proto.return_type_node;
    zT_926 = resolved_rt_b;
    zF_19B4A07D_resolvedTypeTableSe(zT_924, zT_925, zT_926);
    zT_930 = self->registry;
    zT_931 = proto.name_id;
    zT_932 = mfs->module_id;
    zT_935 = proto.params_start;
    zT_936 = proto.params_count;
    zT_937 = resolved_rt_b;
    zT_945 = zF_474336D7_typeRegistryGetOrCr(zT_930, zT_931, zT_932, (unsigned char)(0), (unsigned char)(0), zT_935, zT_936, zT_937);
    fn_ty = zT_945;
    zT_946 = self->type_table;
    zT_947 = node_idx;
    zT_948 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_946, zT_947, zT_948);
    return fn_ty;
    z_bb_125:
    goto z_bb_121;
    z_bb_126:
    zT_997 = self->registry;
    zT_998 = zT_997->slice_items;
    zT_999 = base_ty.payload_idx;
    zT_1000 = (unsigned int)zT_999;
    zT_1001 = zT_998[zT_1000];
    sp_4 = zT_1001;
    zT_1003 = "len";
    zT_1005 = 3;
    zT_1004.ptr = zT_1003;
    zT_1004.len = zT_1005;
    len_s = zT_1004;
    zT_1007 = self->interner;
    zT_1008 = len_s;
    zT_1010 = zF_50C274AF_stringInternerInter(zT_1007, zT_1008);
    len_id = zT_1010;
    if ((int)(field_name_id == len_id)) goto z_bb_129; else goto z_bb_130;
    z_bb_127:
    goto z_bb_107;
    z_bb_128:
    zT_1050 = base_ty.kind;
    if ((int)(zT_1050 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_133; else goto z_bb_135;
    z_bb_129:
    zT_1013 = "FSL:USIZE\n";
    zT_1015 = 10;
    zT_1014.ptr = zT_1013;
    zT_1014.len = zT_1015;
    fsl = zT_1014;
    zT_1016 = fsl;
    zF_48AC7B3A_markerWrite(zT_1016);
    zT_1017 = self->type_table;
    zT_1018 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1017, zT_1018, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_130:
    zT_1024 = "ptr";
    zT_1026 = 3;
    zT_1025.ptr = zT_1024;
    zT_1025.len = zT_1026;
    ptr_s = zT_1025;
    zT_1028 = self->interner;
    zT_1029 = ptr_s;
    zT_1031 = zF_50C274AF_stringInternerInter(zT_1028, zT_1029);
    ptr_id = zT_1031;
    if ((int)(field_name_id == ptr_id)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_1034 = self->registry;
    zT_1035 = sp_4.elem;
    zT_1040 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1034, zT_1035, (int)(0));
    pty = zT_1040;
    zT_1042 = "FSP:PTR\n";
    zT_1044 = 8;
    zT_1043.ptr = zT_1042;
    zT_1043.len = zT_1044;
    fsp = zT_1043;
    zT_1045 = fsp;
    zF_48AC7B3A_markerWrite(zT_1045);
    zT_1046 = self->type_table;
    zT_1047 = node_idx;
    zT_1048 = pty;
    zF_19B4A07D_resolvedTypeTableSe(zT_1046, zT_1047, zT_1048);
    return pty;
    z_bb_132:
    goto z_bb_127;
    z_bb_133:
    zT_1056 = "len";
    zT_1058 = 3;
    zT_1057.ptr = zT_1056;
    zT_1057.len = zT_1058;
    len_s = zT_1057;
    zT_1060 = self->interner;
    zT_1061 = len_s;
    zT_1063 = zF_50C274AF_stringInternerInter(zT_1060, zT_1061);
    len_id = zT_1063;
    if ((int)(field_name_id == len_id)) goto z_bb_136; else goto z_bb_137;
    z_bb_134:
    goto z_bb_127;
    z_bb_135:
    zT_1076 = base_ty.kind;
    if ((int)(zT_1076 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_138; else goto z_bb_140;
    z_bb_136:
    zT_1066 = "FAA:USIZE\n";
    zT_1068 = 10;
    zT_1067.ptr = zT_1066;
    zT_1067.len = zT_1068;
    faa_m = zT_1067;
    zT_1069 = faa_m;
    zF_48AC7B3A_markerWrite(zT_1069);
    zT_1070 = self->type_table;
    zT_1071 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1070, zT_1071, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_1082 = self->registry;
    zT_1083 = base_type_id;
    zT_1084 = field_name_id;
    zT_1086 = zF_D2ECD176_typeRegistryErrorSe(zT_1082, zT_1083, zT_1084);
    es_mi2 = zT_1086;
    if ((int)(es_mi2 != (unsigned int)(4294967295u))) goto z_bb_141; else goto z_bb_142;
    z_bb_139:
    goto z_bb_134;
    z_bb_140:
    zT_1099 = base_ty.kind;
    if ((int)(zT_1099 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_143; else goto z_bb_145;
    z_bb_141:
    zT_1089 = self->type_table;
    zT_1090 = node_idx;
    zT_1091 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1089, zT_1090, zT_1091);
    return base_type_id;
    z_bb_142:
    zT_1093 = self->type_table;
    zT_1094 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1093, zT_1094, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_143:
    zT_1105 = self->registry;
    zT_1106 = zT_1105->en_items;
    zT_1107 = base_ty.payload_idx;
    zT_1108 = (unsigned int)zT_1107;
    zT_1109 = zT_1106[zT_1108];
    ep3 = zT_1109;
    zT_1111 = ep3.members_start;
    zT_1112 = (unsigned int)zT_1111;
    estart3 = zT_1112;
    zT_1114 = ep3.members_count;
    zT_1115 = (unsigned int)zT_1114;
    ecount3 = zT_1115;
    zT_1117 = 0;
    zT_1118 = (unsigned int)zT_1117;
    ei3 = zT_1118;
    goto z_bb_146;
    goto z_bb_139;
    z_bb_145:
    zT_1144 = "FF\n";
    zT_1146 = 3;
    zT_1145.ptr = zT_1144;
    zT_1145.len = zT_1146;
    fnf = zT_1145;
    zT_1147 = fnf;
    zF_48AC7B3A_markerWrite(zT_1147);
    zT_1148 = self->type_table;
    zT_1149 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1148, zT_1149, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_146:
    if ((int)(ei3 < ecount3)) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_1120 = self->registry;
    zT_1121 = zT_1120->em_items;
    zT_1122 = estart3 + ei3;
    zT_1123 = zT_1121[zT_1122];
    zT_1124 = zT_1123.name_id;
    if ((int)(zT_1124 == field_name_id)) goto z_bb_150; else goto z_bb_151;
    z_bb_148:
    zT_1133 = "FF\n";
    zT_1135 = 3;
    zT_1134.ptr = zT_1133;
    zT_1134.len = zT_1135;
    fnf = zT_1134;
    zT_1136 = fnf;
    zF_48AC7B3A_markerWrite(zT_1136);
    zT_1137 = self->type_table;
    zT_1138 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1137, zT_1138, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_149:
    zT_1130 = 1;
    zT_1131 = ei3 + zT_1130;
    ei3 = zT_1131;
    goto z_bb_146;
    z_bb_150:
    zT_1126 = self->type_table;
    zT_1127 = node_idx;
    zT_1128 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1126, zT_1127, zT_1128);
    return base_type_id;
    z_bb_151:
    goto z_bb_149;
    z_bb_152:
    if ((int)(fi < fields_count)) goto z_bb_153; else goto z_bb_154;
    z_bb_153:
    zT_1159 = self->registry;
    zT_1160 = zT_1159->fe_items;
    zT_1161 = fields_start + fi;
    zT_1162 = zT_1160[zT_1161];
    fe = zT_1162;
    zT_1163 = fe.name_id;
    if ((int)(zT_1163 == field_name_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_154:
    zT_1204 = "NF\n";
    zT_1206 = 3;
    zT_1205.ptr = zT_1204;
    zT_1205.len = zT_1206;
    fnf2 = zT_1205;
    zT_1207 = fnf2;
    zF_48AC7B3A_markerWrite(zT_1207);
    zT_1209 = "FF2:N";
    zT_1211 = 5;
    zT_1210.ptr = zT_1209;
    zT_1210.len = zT_1211;
    ff2n_m = zT_1210;
    zT_1212 = ff2n_m;
    zT_1213 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1212, zT_1213);
    zT_1215 = "FF2:F";
    zT_1217 = 5;
    zT_1216.ptr = zT_1215;
    zT_1216.len = zT_1217;
    ff2f_m = zT_1216;
    zT_1218 = ff2f_m;
    zT_1219 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_1218, zT_1219);
    zT_1221 = "FF2:B";
    zT_1223 = 5;
    zT_1222.ptr = zT_1221;
    zT_1222.len = zT_1223;
    ff2b_m = zT_1222;
    zT_1224 = ff2b_m;
    zT_1225 = base_type_id;
    zF_C914CB83_markerWriteInt(zT_1224, zT_1225);
    zT_1226 = self->type_table;
    zT_1227 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1226, zT_1227, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_155:
    goto z_bb_152;
    z_bb_156:
    zT_1166 = fe.type_id;
    result = zT_1166;
    zT_1168 = self->registry;
    zT_1169 = zT_1168->types_items;
    zT_1170 = (unsigned int)result;
    zT_1171 = zT_1169[zT_1170];
    rt = zT_1171;
    zT_1172 = rt.kind;
    if ((int)(zT_1172 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_1200 = 1;
    zT_1202 = fi + (unsigned int)((unsigned int)zT_1200);
    fi = zT_1202;
    goto z_bb_155;
    z_bb_158:
    zT_1178 = self->registry;
    zT_1179 = zT_1178->array_items;
    zT_1180 = rt.payload_idx;
    zT_1181 = (unsigned int)zT_1180;
    zT_1182 = zT_1179[zT_1181];
    zT_1183 = zT_1182.elem;
    elem = zT_1183;
    zT_1184 = self->registry;
    zT_1185 = elem;
    zT_1189 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1184, zT_1185, (int)(0));
    result = zT_1189;
    goto z_bb_159;
    z_bb_159:
    zT_1191 = "FF:R";
    zT_1193 = 4;
    zT_1192.ptr = zT_1191;
    zT_1192.len = zT_1193;
    ff_m = zT_1192;
    zT_1194 = ff_m;
    zT_1195 = result;
    zF_C914CB83_markerWriteInt(zT_1194, zT_1195);
    zT_1196 = self->type_table;
    zT_1197 = node_idx;
    zT_1198 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_1196, zT_1197, zT_1198);
    return result;
}

/* semanticAnalyzerPackedGateGrow */
void zF_151B0DD7_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_0F51E4CA_EU_222 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->packed_gate_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_gate_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_gate_items = ndst;
    self->packed_gate_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->packed_gate_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_gate_items;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerPackedGateMark */
void zF_E3B2C29D_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->packed_gate_len;
    zT_3 = self->packed_gate_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_151B0DD7_semanticAnalyzerPac(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->packed_gate_items;
    zT_7 = self->packed_gate_len;
    zT_6[zT_7] = node_idx;
    zT_8 = self->packed_gate_len;
    self->packed_gate_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedGateSeen */
int zF_5BBD6EB3_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_12;
    unsigned int gi;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    gi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_gate_len;
    if ((int)(gi < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_items;
    zT_8 = zT_7[gi];
    if ((int)(zT_8 == node_idx)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_12 = gi + (unsigned int)(1);
    gi = zT_12;
    goto z_bb_1;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    goto z_bb_4;
}

/* semanticAnalyzerPackedStructCacheGrow */
void zF_86D8CE03_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_0F51E4CA_EU_222 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_0F51E4CA_EU_222 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int* zT_58;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    unsigned char* raw2;
    unsigned int* ndst2;
    unsigned int ci2;
    zT_2 = self->packed_struct_cache_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_cache_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_struct_cache_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_struct_tids = ndst;
    zT_37 = self->expected_type_stack_alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_13; else goto z_bb_14;
    z_bb_9:
    zT_30 = self->packed_struct_cache_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
    z_bb_13:
    z_bb_14:
    zT_46 = zT_44.data.payload;
    goto z_bb_15;
    z_bb_15:
    raw2 = zT_46;
    zT_49 = (unsigned int*)raw2;
    ndst2 = zT_49;
    zT_50 = self->packed_struct_cache_len;
    if ((int)(zT_50 > (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    ci2 = zT_55;
    goto z_bb_18;
    z_bb_17:
    self->packed_struct_decl_nodes = ndst2;
    self->packed_struct_cache_cap = new_cap;
    return;
    z_bb_18:
    zT_56 = self->packed_struct_cache_len;
    if ((int)(ci2 < zT_56)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_58 = self->packed_struct_decl_nodes;
    zT_59 = zT_58[ci2];
    ndst2[ci2] = zT_59;
    goto z_bb_21;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_61 = ci2 + (unsigned int)(1);
    ci2 = zT_61;
    goto z_bb_18;
}

/* semanticAnalyzerPackedStructCacheAppend */
void zF_2C47D4E0_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_3 = self->packed_struct_cache_len;
    zT_4 = self->packed_struct_cache_cap;
    if ((int)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_86D8CE03_semanticAnalyzerPac(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = self->packed_struct_cache_len;
    zT_7[zT_8] = struct_tid;
    zT_9 = self->packed_struct_decl_nodes;
    zT_10 = self->packed_struct_cache_len;
    zT_9[zT_10] = decl_node;
    zT_11 = self->packed_struct_cache_len;
    self->packed_struct_cache_len = (unsigned int)(zT_11 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCheckedStructTidsGrow */
void zF_055533B0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_0F51E4CA_EU_222 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->checked_struct_tids_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->checked_struct_tids_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->checked_struct_tids_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->checked_struct_tids = ndst;
    self->checked_struct_tids_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->checked_struct_tids_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->checked_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerCheckedStructTidsAppend */
void zF_B5A1E8BB_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->checked_struct_tids_len;
    zT_3 = self->checked_struct_tids_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_055533B0_semanticAnalyzerChe(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->checked_struct_tids;
    zT_7 = self->checked_struct_tids_len;
    zT_6[zT_7] = struct_tid;
    zT_8 = self->checked_struct_tids_len;
    self->checked_struct_tids_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedFieldTypeAllowed */
int zF_E42B9323_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, int allow_packed_struct_type) {
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    int zT_31;
    unsigned char zT_32;
    zT_33EF6BFB_TypeKind zT_38;
    zT_338B7C76_TypeRegistry* zT_43;
    unsigned int zT_44;
    int zT_46 = 0;
    zT_338B7C76_TypeRegistry* zT_50;
    unsigned int zT_51;
    unsigned int zT_53 = 0;
    int zT_56;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    zT_338B7C76_TypeRegistry* zT_62;
    unsigned int zT_63;
    int zT_65 = 0;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    int zT_72 = 0;
    zT_D155D06D_Type ty;
    unsigned int ebt;
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ty = zT_12;
    zT_13 = ty.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_19 = ty.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    if (allow_packed_struct_type) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = ty.kind;
    zT_25 = zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_9;
    z_bb_8:
    zT_25 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_25) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = ty.flags;
    zT_31 = (unsigned char)(zT_32 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_31 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_31) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    zT_38 = ty.kind;
    if ((int)(zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_43 = self->registry;
    zT_44 = tid;
    zT_46 = zF_A3BA89EA_typeRegistryEnumHas(zT_43, zT_44);
    if ((int)(!zT_46)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = self->registry;
    zT_70 = tid;
    zT_72 = zF_3290E9C4_typeRegistryIsInteg(zT_69, zT_70);
    return zT_72;
    z_bb_17:
    return (int)(0);
    z_bb_18:
    zT_50 = self->registry;
    zT_51 = tid;
    zT_53 = zF_014D7530_typeRegistryEnumBac(zT_50, zT_51);
    ebt = zT_53;
    if ((int)(ebt == (unsigned int)(18))) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_58 = self->registry;
    zT_59 = zT_58->types_len;
    zT_56 = (unsigned int)((unsigned int)ebt) >= zT_59;
    goto z_bb_21;
    z_bb_20:
    zT_56 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_56) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (int)(0);
    z_bb_23:
    zT_62 = self->registry;
    zT_63 = ebt;
    zT_65 = zF_B664AC19_typeRegistryIsUnsig(zT_62, zT_63);
    if ((int)(!zT_65)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (int)(0);
    z_bb_25:
    return (int)(1);
}

/* semanticAnalyzerGatePackedFields */
void zF_C26EF425_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_13;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    int zT_20 = 0;
    zT_38C12417_SemanticAnalyzer* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int* zT_38;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_47;
    unsigned char zT_49;
    unsigned char zT_51;
    zT_ABC1EBBE_TypeResolveEnv zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_3D7259E2_SymbolRegistry* zT_58;
    zT_D3EB6303_StringInterner* zT_59;
    zT_ABC1EBBE_TypeResolveEnv* zT_61;
    unsigned int zT_62;
    unsigned int zT_66 = 0;
    int zT_69;
    unsigned char zT_72;
    zT_38C12417_SemanticAnalyzer* zT_73;
    unsigned int zT_74;
    int zT_77 = 0;
    zT_338B7C76_TypeRegistry* zT_78;
    unsigned int zT_79;
    unsigned char zT_81 = 0;
    unsigned char zT_84;
    unsigned char zT_85;
    unsigned int zT_89;
    unsigned int zT_91;
    unsigned int zT_93;
    char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_F85C5DED_DiagnosticCollector* zT_100;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_111 = 0;
    char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_F85C5DED_DiagnosticCollector* zT_116;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_127 = 0;
    unsigned int zT_129;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u pw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pg_msg;
    zT_4 = self->store;
    zT_5 = struct_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((int)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = node.flags;
    if ((int)((unsigned char)(zT_13 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = self;
    zT_19 = struct_node_idx;
    zT_20 = zF_5BBD6EB3_semanticAnalyzerPac(zT_18, zT_19);
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_21 = self;
    zT_22 = struct_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_21, zT_22);
    zT_24 = self->store;
    zT_25 = struct_node_idx;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    children = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = children.len;
    if ((int)(ci < zT_32)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self->store;
    zT_38 = children.ptr;
    zT_36 = zT_38[ci];
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    fd = zT_40;
    zT_41 = fd.kind;
    if ((int)(zT_41 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_129 = ci + (unsigned int)(1);
    ci = zT_129;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_47 = fd.child_0;
    type_node = zT_47;
    zT_49 = 0;
    gate_state = zT_49;
    zT_51 = 0;
    gate_wide = zT_51;
    if ((int)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_56 = self->store;
    zT_55.store = zT_56;
    zT_57 = self->registry;
    zT_55.typereg = zT_57;
    zT_58 = self->symbols;
    zT_55.symbol_reg = zT_58;
    zT_59 = self->interner;
    zT_55.interner = zT_59;
    zT_55.module_id = module_id;
    tre_env = zT_55;
    zT_61 = &tre_env;
    zT_62 = type_node;
    zT_66 = zF_F2107C15_resolveTypeExprFull(zT_61, zT_62, (unsigned int)(0));
    ft = zT_66;
    if ((int)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((int)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_69 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_69 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_69) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_72 = 1;
    gate_state = zT_72;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_73 = self;
    zT_74 = ft;
    zT_77 = zF_E42B9323_semanticAnalyzerPac(zT_73, zT_74, (int)(1));
    if (zT_77) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_78 = self->registry;
    zT_79 = ft;
    zT_81 = zF_655972D5_typeRegistryIntWidt(zT_78, zT_79);
    if ((int)(zT_81 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_84 = 1;
    gate_wide = zT_84;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_85 = 1;
    gate_state = zT_85;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_89 = fd.span_start;
    fsp = zT_89;
    zT_91 = fd.span_len;
    zT_93 = fsp + (unsigned int)((unsigned int)zT_91);
    fep = zT_93;
    if ((int)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_97 = "packed struct field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_99 = 95;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    pw_msg = zT_98;
    zT_100 = self->diag;
    zT_103 = self->source_file_id;
    zT_104 = fsp;
    zT_105 = fep;
    zT_106 = pw_msg;
    zT_111 = zF_C82559AC_diagnosticCollector(zT_100, (unsigned char)(0), (unsigned short)(3000), zT_103, zT_104, zT_105, zT_106);
    (void)zT_111;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_113 = "packed struct fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed struct";
    zT_115 = 111;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    pg_msg = zT_114;
    zT_116 = self->diag;
    zT_119 = self->source_file_id;
    zT_120 = fsp;
    zT_121 = fep;
    zT_122 = pg_msg;
    zT_127 = zF_C82559AC_diagnosticCollector(zT_116, (unsigned char)(0), (unsigned short)(3000), zT_119, zT_120, zT_121, zT_122);
    (void)zT_127;
    goto z_bb_29;
}

/* semanticAnalyzerMaybeGateAliasDecl */
void zF_FC6E31C6_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned int zT_11;
    unsigned char zT_13;
    zT_8143F551_AstKind zT_14;
    zT_8143F551_AstKind zT_19;
    unsigned char zT_24;
    unsigned char zT_29;
    zT_8143F551_AstKind zT_30;
    int zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_44 = {0};
    zT_8143F551_AstKind zT_45;
    unsigned int zT_50;
    zT_8143F551_AstKind zT_51;
    int zT_56;
    unsigned char zT_57;
    unsigned int zT_62;
    unsigned char zT_63;
    zT_38C12417_SemanticAnalyzer* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_38C12417_SemanticAnalyzer* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = decl_node;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    dnode = zT_9;
    zT_11 = 0;
    target = zT_11;
    zT_13 = 0;
    is_union = zT_13;
    zT_14 = dnode.kind;
    if ((int)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_19 = dnode.kind;
    if ((int)(zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_24 = dnode.flags;
    if ((int)((unsigned char)(zT_24 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_30 = dnode.kind;
    if ((int)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_29 = 1;
    is_union = zT_29;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_36 = dnode.child_1;
    zT_35 = zT_36 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_35 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_35) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_40 = self->store;
    zT_41 = dnode.child_1;
    zT_44 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    inn = zT_44;
    zT_45 = inn.kind;
    if ((int)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_50 = dnode.child_1;
    target = zT_50;
    goto z_bb_17;
    z_bb_17:
    zT_51 = inn.kind;
    if ((int)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_57 = inn.flags;
    zT_56 = (unsigned char)(zT_57 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_56 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_56) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_62 = dnode.child_1;
    target = zT_62;
    zT_63 = 1;
    is_union = zT_63;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((int)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_68 = self;
    zT_69 = target;
    zT_70 = module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_68, zT_69, zT_70);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_71 = self;
    zT_72 = target;
    zT_73 = module_id;
    zF_F705063A_semanticAnalyzerGat(zT_71, zT_72, zT_73);
    goto z_bb_26;
}

/* semanticAnalyzerGateModulePackedDecl */
void zF_6A91A8CC_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned char zT_12;
    zT_8143F551_AstKind zT_13;
    zT_8143F551_AstKind zT_18;
    unsigned char zT_23;
    unsigned char zT_28;
    zT_8143F551_AstKind zT_29;
    int zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    unsigned int zT_49;
    zT_8143F551_AstKind zT_50;
    int zT_55;
    unsigned char zT_56;
    unsigned int zT_61;
    unsigned char zT_62;
    zT_38C12417_SemanticAnalyzer* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_38C12417_SemanticAnalyzer* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    target = zT_10;
    zT_12 = 0;
    is_union = zT_12;
    zT_13 = dnode.kind;
    if ((int)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_18 = dnode.kind;
    if ((int)(zT_18 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_23 = dnode.flags;
    if ((int)((unsigned char)(zT_23 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_29 = dnode.kind;
    if ((int)(zT_29 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_28 = 1;
    is_union = zT_28;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_35 = dnode.child_1;
    zT_34 = zT_35 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_34 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_34) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_39 = self->store;
    zT_40 = dnode.child_1;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_39, zT_40);
    inn = zT_43;
    zT_44 = inn.kind;
    if ((int)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_49 = dnode.child_1;
    target = zT_49;
    goto z_bb_17;
    z_bb_17:
    zT_50 = inn.kind;
    if ((int)(zT_50 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_56 = inn.flags;
    zT_55 = (unsigned char)(zT_56 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_55 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_55) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_61 = dnode.child_1;
    target = zT_61;
    zT_62 = 1;
    is_union = zT_62;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((int)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_67 = self;
    zT_68 = target;
    zT_69 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_67, zT_68, zT_69);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_71 = self;
    zT_72 = target;
    zT_73 = self->module_id;
    zF_F705063A_semanticAnalyzerGat(zT_71, zT_72, zT_73);
    goto z_bb_26;
}

/* semanticAnalyzerGatePackedUnionMembers */
void zF_F705063A_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int union_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_13;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    int zT_20 = 0;
    zT_38C12417_SemanticAnalyzer* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int* zT_38;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_47;
    unsigned char zT_49;
    unsigned char zT_51;
    zT_ABC1EBBE_TypeResolveEnv zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_3D7259E2_SymbolRegistry* zT_58;
    zT_D3EB6303_StringInterner* zT_59;
    zT_ABC1EBBE_TypeResolveEnv* zT_61;
    unsigned int zT_62;
    unsigned int zT_66 = 0;
    int zT_69;
    unsigned char zT_72;
    zT_38C12417_SemanticAnalyzer* zT_73;
    unsigned int zT_74;
    int zT_77 = 0;
    zT_338B7C76_TypeRegistry* zT_78;
    unsigned int zT_79;
    unsigned char zT_81 = 0;
    unsigned char zT_84;
    unsigned char zT_85;
    unsigned int zT_89;
    unsigned int zT_91;
    unsigned int zT_93;
    char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_F85C5DED_DiagnosticCollector* zT_100;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_111 = 0;
    char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_F85C5DED_DiagnosticCollector* zT_116;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_127 = 0;
    unsigned int zT_129;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u puw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pgu_msg;
    zT_4 = self->store;
    zT_5 = union_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((int)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = node.flags;
    if ((int)((unsigned char)(zT_13 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = self;
    zT_19 = union_node_idx;
    zT_20 = zF_5BBD6EB3_semanticAnalyzerPac(zT_18, zT_19);
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_21 = self;
    zT_22 = union_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_21, zT_22);
    zT_24 = self->store;
    zT_25 = union_node_idx;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    children = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = children.len;
    if ((int)(ci < zT_32)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self->store;
    zT_38 = children.ptr;
    zT_36 = zT_38[ci];
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    fd = zT_40;
    zT_41 = fd.kind;
    if ((int)(zT_41 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_129 = ci + (unsigned int)(1);
    ci = zT_129;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_47 = fd.child_0;
    type_node = zT_47;
    zT_49 = 0;
    gate_state = zT_49;
    zT_51 = 0;
    gate_wide = zT_51;
    if ((int)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_56 = self->store;
    zT_55.store = zT_56;
    zT_57 = self->registry;
    zT_55.typereg = zT_57;
    zT_58 = self->symbols;
    zT_55.symbol_reg = zT_58;
    zT_59 = self->interner;
    zT_55.interner = zT_59;
    zT_55.module_id = module_id;
    tre_env = zT_55;
    zT_61 = &tre_env;
    zT_62 = type_node;
    zT_66 = zF_F2107C15_resolveTypeExprFull(zT_61, zT_62, (unsigned int)(0));
    ft = zT_66;
    if ((int)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((int)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_69 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_69 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_69) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_72 = 1;
    gate_state = zT_72;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_73 = self;
    zT_74 = ft;
    zT_77 = zF_E42B9323_semanticAnalyzerPac(zT_73, zT_74, (int)(1));
    if (zT_77) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_78 = self->registry;
    zT_79 = ft;
    zT_81 = zF_655972D5_typeRegistryIntWidt(zT_78, zT_79);
    if ((int)(zT_81 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_84 = 1;
    gate_wide = zT_84;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_85 = 1;
    gate_state = zT_85;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_89 = fd.span_start;
    fsp = zT_89;
    zT_91 = fd.span_len;
    zT_93 = fsp + (unsigned int)((unsigned int)zT_91);
    fep = zT_93;
    if ((int)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_97 = "packed union field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_99 = 94;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    puw_msg = zT_98;
    zT_100 = self->diag;
    zT_103 = self->source_file_id;
    zT_104 = fsp;
    zT_105 = fep;
    zT_106 = puw_msg;
    zT_111 = zF_C82559AC_diagnosticCollector(zT_100, (unsigned char)(0), (unsigned short)(3000), zT_103, zT_104, zT_105, zT_106);
    (void)zT_111;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_113 = "packed union fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed union";
    zT_115 = 109;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    pgu_msg = zT_114;
    zT_116 = self->diag;
    zT_119 = self->source_file_id;
    zT_120 = fsp;
    zT_121 = fep;
    zT_122 = pgu_msg;
    zT_127 = zF_C82559AC_diagnosticCollector(zT_116, (unsigned char)(0), (unsigned short)(3000), zT_119, zT_120, zT_121, zT_122);
    (void)zT_127;
    goto z_bb_29;
}

/* semanticAnalyzerGateEnumModuleDecl */
void zF_4E74AE9D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    zT_8143F551_AstKind zT_15;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_8143F551_AstKind zT_26;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_46;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    unsigned int zT_50 = 0;
    unsigned int zT_51;
    unsigned int zT_55;
    zT_79FAE712_u64 zT_60;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_79FAE712_u64 zT_62;
    zT_BAEE192E_Opt_10 zT_64 = {0};
    unsigned char zT_65;
    zT_38C12417_SemanticAnalyzer* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    unsigned int backing_node;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    unsigned int tid;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    enum_node = zT_10;
    zT_12 = 0;
    enum_name_id = zT_12;
    zT_14 = 0;
    backing_node = zT_14;
    zT_15 = dnode.kind;
    if ((int)(zT_15 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21 = dnode.child_1;
    zT_20 = zT_21 != (unsigned int)(0);
    goto z_bb_5;
    z_bb_4:
    zT_20 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_20) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    enum_node = decl_node;
    zT_24 = dnode.child_0;
    enum_name_id = zT_24;
    zT_25 = dnode.child_1;
    backing_node = zT_25;
    goto z_bb_7;
    z_bb_7:
    if ((int)(enum_node == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_8:
    zT_26 = dnode.kind;
    if ((int)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = dnode.child_1;
    zT_31 = zT_32 != (unsigned int)(0);
    goto z_bb_11;
    z_bb_10:
    zT_31 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_31) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_36 = self->store;
    zT_37 = dnode.child_1;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    inn = zT_40;
    zT_41 = inn.kind;
    if ((int)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    goto z_bb_7;
    z_bb_14:
    zT_46 = dnode.child_1;
    enum_node = zT_46;
    zT_47 = self->store;
    zT_48 = decl_node;
    zT_50 = zF_8BA26B9E_astStoreNodePayload(zT_47, zT_48);
    enum_name_id = zT_50;
    zT_51 = inn.child_0;
    backing_node = zT_51;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    return;
    z_bb_17:
    zT_55 = self->module_id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_55) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)enum_name_id);
    key = zT_60;
    zT_61 = self->registry;
    zT_62 = key;
    zT_64 = zF_0EB68360_nameCacheGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    tid = zT_64.value;
    zT_67 = self;
    zT_68 = tid;
    zT_69 = enum_node;
    zT_70 = backing_node;
    zF_5EF7F98D_semanticAnalyzerGat(zT_67, zT_68, zT_69, zT_70);
    goto z_bb_19;
    z_bb_19:
    return;
}

/* semanticAnalyzerGateEnumTypeDecl */
void zF_5EF7F98D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, unsigned int enum_node, unsigned int backing_node) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_457ECFEE_EnumPayload* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_457ECFEE_EnumPayload zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_36 = {0};
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    zT_ABC1EBBE_TypeResolveEnv zT_44;
    zT_6B0A7D14_AstStore* zT_45;
    zT_338B7C76_TypeRegistry* zT_46;
    zT_3D7259E2_SymbolRegistry* zT_47;
    zT_D3EB6303_StringInterner* zT_48;
    unsigned int zT_49;
    zT_ABC1EBBE_TypeResolveEnv* zT_51;
    unsigned int zT_52;
    unsigned int zT_56 = 0;
    int zT_59;
    char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_77 = 0;
    zT_338B7C76_TypeRegistry* zT_79;
    unsigned int zT_80;
    zT_338B7C76_TypeRegistry* zT_83;
    zT_D155D06D_Type* zT_84;
    unsigned int zT_85;
    zT_D155D06D_Type zT_86;
    zT_33EF6BFB_TypeKind zT_87;
    char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    zT_F85C5DED_DiagnosticCollector* zT_96;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_107 = 0;
    zT_338B7C76_TypeRegistry* zT_108;
    unsigned int zT_109;
    int zT_111 = 0;
    zT_338B7C76_TypeRegistry* zT_113;
    unsigned int zT_114;
    int zT_116 = 0;
    char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    zT_F85C5DED_DiagnosticCollector* zT_121;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_132 = 0;
    char* zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    zT_F85C5DED_DiagnosticCollector* zT_137;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_148 = 0;
    zT_338B7C76_TypeRegistry* zT_150;
    unsigned int zT_151;
    unsigned char zT_153 = 0;
    unsigned int zT_154;
    zT_79FAE712_u64 zT_156;
    zT_79FAE712_u64 zT_163;
    zT_338B7C76_TypeRegistry* zT_165;
    zT_457ECFEE_EnumPayload* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    zT_457ECFEE_EnumPayload zT_169;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned short zT_174;
    unsigned int zT_175;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_180 = {0};
    unsigned int zT_182;
    int zT_184;
    unsigned int zT_185;
    zT_79FAE712_u64 zT_187;
    int zT_189;
    unsigned int zT_191;
    int zT_193;
    zT_6B0A7D14_AstStore* zT_196;
    unsigned int zT_197;
    unsigned int* zT_199;
    zT_22A7C88B_AstNode zT_201 = {0};
    zT_8143F551_AstKind zT_202;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_D96DCDF2_EnumMember* zT_209;
    unsigned int zT_210;
    zT_D96DCDF2_EnumMember zT_211;
    zT_C69B2266_i64 zT_212;
    zT_79FAE712_u64 zT_214;
    unsigned int zT_217;
    unsigned int zT_219;
    unsigned int zT_221;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_F85C5DED_DiagnosticCollector* zT_226;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_237 = 0;
    int zT_238;
    int zT_240;
    unsigned int zT_241;
    unsigned int zT_245;
    unsigned int zT_247;
    unsigned int zT_249;
    char* zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_253;
    zT_F85C5DED_DiagnosticCollector* zT_254;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    unsigned int zT_265 = 0;
    int zT_266;
    unsigned int zT_268;
    unsigned int zT_270;
    zT_D155D06D_Type ety;
    unsigned int check_btid;
    zT_22A7C88B_AstNode bnode;
    unsigned int bsp;
    unsigned int bep;
    zT_ABC1EBBE_TypeResolveEnv tre_env2;
    unsigned int bt;
    unsigned int nbits;
    zT_79FAE712_u64 maxv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bg_msg;
    zT_D155D06D_Type bty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bb_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bi_msg;
    zT_457ECFEE_EnumPayload ep2;
    unsigned int mstart2;
    unsigned int mcount2;
    zT_3CB0179A_Slice_zT_05F374B1_u children2;
    unsigned int fcount2;
    unsigned int ci2;
    zT_79FAE712_u64 prev_vu;
    int have_prev;
    zT_22A7C88B_AstNode fd2;
    zT_C69B2266_i64 mv;
    zT_79FAE712_u64 mvu;
    unsigned int msp;
    unsigned int mep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mv_msg;
    zT_5 = self->registry;
    zT_6 = zT_5->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ety = zT_12;
    zT_13 = ety.kind;
    if ((int)(zT_13 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = ety.payload_idx;
    zT_20 = self->registry;
    zT_21 = zT_20->en_len;
    if ((int)((unsigned int)((unsigned int)zT_18) >= zT_21)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_24 = self->registry;
    zT_25 = zT_24->en_items;
    zT_26 = ety.payload_idx;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_25[zT_27];
    zT_29 = zT_28.backing_type;
    check_btid = zT_29;
    if ((int)(backing_node != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_33 = self->store;
    zT_34 = backing_node;
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    bnode = zT_36;
    zT_38 = bnode.span_start;
    bsp = zT_38;
    zT_40 = bnode.span_len;
    zT_42 = bsp + (unsigned int)((unsigned int)zT_40);
    bep = zT_42;
    zT_45 = self->store;
    zT_44.store = zT_45;
    zT_46 = self->registry;
    zT_44.typereg = zT_46;
    zT_47 = self->symbols;
    zT_44.symbol_reg = zT_47;
    zT_48 = self->interner;
    zT_44.interner = zT_48;
    zT_49 = self->module_id;
    zT_44.module_id = zT_49;
    tre_env2 = zT_44;
    zT_51 = &tre_env2;
    zT_52 = backing_node;
    zT_56 = zF_F2107C15_resolveTypeExprFull(zT_51, zT_52, (unsigned int)(0));
    bt = zT_56;
    if ((int)(bt == (unsigned int)(18))) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    zT_150 = self->registry;
    zT_151 = check_btid;
    zT_153 = zF_655972D5_typeRegistryIntWidt(zT_150, zT_151);
    zT_154 = (unsigned int)zT_153;
    nbits = zT_154;
    zT_156 = 18446744073709551615ULL;
    maxv = zT_156;
    if ((int)(nbits < (unsigned int)(64))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    zT_59 = bt == (unsigned int)(1);
    goto z_bb_11;
    z_bb_10:
    zT_59 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_59) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63 = "invalid enum backing type; enum(uN) requires an unsigned integer type name (u1..u64)";
    zT_65 = 84;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    bg_msg = zT_64;
    zT_66 = self->diag;
    zT_69 = self->source_file_id;
    zT_70 = bsp;
    zT_71 = bep;
    zT_72 = bg_msg;
    zT_77 = zF_C82559AC_diagnosticCollector(zT_66, (unsigned char)(0), (unsigned short)(3000), zT_69, zT_70, zT_71, zT_72);
    (void)zT_77;
    return;
    z_bb_13:
    zT_79 = self->registry;
    zT_80 = zT_79->types_len;
    if ((int)((unsigned int)((unsigned int)bt) < zT_80)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_83 = self->registry;
    zT_84 = zT_83->types_items;
    zT_85 = (unsigned int)bt;
    zT_86 = zT_84[zT_85];
    bty = zT_86;
    zT_87 = bty.kind;
    if ((int)(zT_87 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_93 = "bool is not a valid enum backing; use an unsigned integer type (uN)";
    zT_95 = 67;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    bb_msg = zT_94;
    zT_96 = self->diag;
    zT_99 = self->source_file_id;
    zT_100 = bsp;
    zT_101 = bep;
    zT_102 = bb_msg;
    zT_107 = zF_C82559AC_diagnosticCollector(zT_96, (unsigned char)(0), (unsigned short)(3000), zT_99, zT_100, zT_101, zT_102);
    (void)zT_107;
    return;
    z_bb_17:
    zT_108 = self->registry;
    zT_109 = bt;
    zT_111 = zF_B664AC19_typeRegistryIsUnsig(zT_108, zT_109);
    if ((int)(!zT_111)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_113 = self->registry;
    zT_114 = bt;
    zT_116 = zF_01ED6537_typeRegistryIntIsSi(zT_113, zT_114);
    if (zT_116) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    check_btid = bt;
    goto z_bb_15;
    z_bb_20:
    zT_118 = "enum(iN) signed backings are not supported; use an unsigned backing (enum(uN))";
    zT_120 = 78;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    bs_msg = zT_119;
    zT_121 = self->diag;
    zT_124 = self->source_file_id;
    zT_125 = bsp;
    zT_126 = bep;
    zT_127 = bs_msg;
    zT_132 = zF_C82559AC_diagnosticCollector(zT_121, (unsigned char)(0), (unsigned short)(3000), zT_124, zT_125, zT_126, zT_127);
    (void)zT_132;
    goto z_bb_21;
    z_bb_21:
    return;
    z_bb_22:
    zT_134 = "invalid enum backing type; enum(uN) requires an unsigned integer type (uN)";
    zT_136 = 74;
    zT_135.ptr = zT_134;
    zT_135.len = zT_136;
    bi_msg = zT_135;
    zT_137 = self->diag;
    zT_140 = self->source_file_id;
    zT_141 = bsp;
    zT_142 = bep;
    zT_143 = bi_msg;
    zT_148 = zF_C82559AC_diagnosticCollector(zT_137, (unsigned char)(0), (unsigned short)(3000), zT_140, zT_141, zT_142, zT_143);
    (void)zT_148;
    goto z_bb_21;
    z_bb_23:
    zT_163 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)nbits)) - (zT_79FAE712_u64)(1);
    maxv = zT_163;
    goto z_bb_24;
    z_bb_24:
    zT_165 = self->registry;
    zT_166 = zT_165->en_items;
    zT_167 = ety.payload_idx;
    zT_168 = (unsigned int)zT_167;
    zT_169 = zT_166[zT_168];
    ep2 = zT_169;
    zT_171 = ep2.members_start;
    zT_172 = (unsigned int)zT_171;
    mstart2 = zT_172;
    zT_174 = ep2.members_count;
    zT_175 = (unsigned int)zT_174;
    mcount2 = zT_175;
    zT_177 = self->store;
    zT_178 = enum_node;
    zT_180 = zF_850FDF81_astStoreNodeExtraCh(zT_177, zT_178);
    children2 = zT_180;
    zT_182 = 0;
    fcount2 = zT_182;
    zT_184 = 0;
    zT_185 = (unsigned int)zT_184;
    ci2 = zT_185;
    zT_187 = 0;
    prev_vu = zT_187;
    zT_189 = 0;
    have_prev = zT_189;
    goto z_bb_25;
    z_bb_25:
    zT_191 = children2.len;
    if ((int)(ci2 < zT_191)) goto z_bb_29; else goto z_bb_30;
    z_bb_26:
    zT_196 = self->store;
    zT_199 = children2.ptr;
    zT_197 = zT_199[ci2];
    zT_201 = zF_FCDD1D35_astStoreNodeAt(zT_196, zT_197);
    fd2 = zT_201;
    zT_202 = fd2.kind;
    if ((int)(zT_202 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return;
    z_bb_28:
    zT_270 = ci2 + (unsigned int)(1);
    ci2 = zT_270;
    goto z_bb_25;
    z_bb_29:
    zT_193 = fcount2 < mcount2;
    goto z_bb_31;
    z_bb_30:
    zT_193 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_193) goto z_bb_26; else goto z_bb_27;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_208 = self->registry;
    zT_209 = zT_208->em_items;
    zT_210 = mstart2 + fcount2;
    zT_211 = zT_209[zT_210];
    zT_212 = zT_211.value;
    mv = zT_212;
    zT_214 = (zT_79FAE712_u64)mv;
    mvu = zT_214;
    if ((int)(mvu > maxv)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_217 = fd2.span_start;
    msp = zT_217;
    zT_219 = fd2.span_len;
    zT_221 = msp + (unsigned int)((unsigned int)zT_219);
    mep = zT_221;
    zT_223 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_225 = 91;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    mv_msg = zT_224;
    zT_226 = self->diag;
    zT_229 = self->source_file_id;
    zT_230 = msp;
    zT_231 = mep;
    zT_232 = mv_msg;
    zT_237 = zF_C82559AC_diagnosticCollector(zT_226, (unsigned char)(0), (unsigned short)(3000), zT_229, zT_230, zT_231, zT_232);
    (void)zT_237;
    return;
    z_bb_35:
    if (have_prev) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_238 = prev_vu == maxv;
    goto z_bb_38;
    z_bb_37:
    zT_238 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_238) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_241 = fd2.child_1;
    zT_240 = zT_241 == (unsigned int)(0);
    goto z_bb_41;
    z_bb_40:
    zT_240 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_240) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_245 = fd2.span_start;
    msp = zT_245;
    zT_247 = fd2.span_len;
    zT_249 = msp + (unsigned int)((unsigned int)zT_247);
    mep = zT_249;
    zT_251 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_253 = 91;
    zT_252.ptr = zT_251;
    zT_252.len = zT_253;
    mv_msg = zT_252;
    zT_254 = self->diag;
    zT_257 = self->source_file_id;
    zT_258 = msp;
    zT_259 = mep;
    zT_260 = mv_msg;
    zT_265 = zF_C82559AC_diagnosticCollector(zT_254, (unsigned char)(0), (unsigned short)(3000), zT_257, zT_258, zT_259, zT_260);
    (void)zT_265;
    return;
    z_bb_43:
    prev_vu = mvu;
    zT_266 = 1;
    have_prev = zT_266;
    zT_268 = fcount2 + (unsigned int)(1);
    fcount2 = zT_268;
    goto z_bb_28;
}

/* semanticAnalyzerPackedStructDeclForType */
unsigned int zF_1BB4D489_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_42;
    unsigned int zT_43;
    zT_3D7259E2_SymbolRegistry* zT_44;
    unsigned int zT_45;
    zT_3D7259E2_SymbolRegistry* zT_48;
    zT_060CD1EB_SymbolTable* zT_49;
    zT_060CD1EB_SymbolTable zT_50;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_3A105EF1_Symbol* zT_57;
    zT_3A105EF1_Symbol zT_58;
    zT_3C598AEF_SymbolKind zT_59;
    unsigned int zT_64;
    int zT_66;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    zT_22A7C88B_AstNode zT_75 = {0};
    unsigned int zT_77;
    zT_8143F551_AstKind zT_78;
    unsigned int zT_83;
    zT_8143F551_AstKind zT_84;
    int zT_89;
    unsigned int zT_90;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_99;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_109;
    zT_22A7C88B_AstNode zT_111 = {0};
    unsigned char zT_112;
    zT_38C12417_SemanticAnalyzer* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned int zT_123;
    zT_38C12417_SemanticAnalyzer* zT_124;
    unsigned int zT_125;
    unsigned int hc;
    unsigned int cc;
    zT_D155D06D_Type sty;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol s;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    zT_22A7C88B_AstNode inn;
    zT_22A7C88B_AstNode tnode;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    hc = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_struct_cache_len;
    if ((int)(hc < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = zT_7[hc];
    if ((int)(zT_8 == struct_tid)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    cc = zT_16;
    goto z_bb_7;
    z_bb_4:
    zT_13 = hc + (unsigned int)(1);
    hc = zT_13;
    goto z_bb_1;
    z_bb_5:
    zT_10 = self->packed_struct_decl_nodes;
    zT_11 = zT_10[hc];
    return zT_11;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_17 = self->checked_struct_tids_len;
    if ((int)(cc < zT_17)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_19 = self->checked_struct_tids;
    zT_20 = zT_19[cc];
    if ((int)(zT_20 == struct_tid)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_26 = self->registry;
    zT_27 = zT_26->types_len;
    if ((int)((unsigned int)((unsigned int)struct_tid) >= zT_27)) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_24 = cc + (unsigned int)(1);
    cc = zT_24;
    goto z_bb_7;
    z_bb_11:
    return (unsigned int)(0);
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    return (unsigned int)(0);
    z_bb_14:
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)struct_tid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_35 = sty.kind;
    if ((int)(zT_35 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned int)(0);
    z_bb_16:
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ti = zT_43;
    goto z_bb_17;
    z_bb_17:
    zT_44 = self->symbols;
    zT_45 = zT_44->tables_len;
    if ((int)(ti < zT_45)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_48 = self->symbols;
    zT_49 = zT_48->tables_items;
    zT_50 = zT_49[ti];
    table = zT_50;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    si = zT_53;
    goto z_bb_21;
    z_bb_19:
    zT_124 = self;
    zT_125 = struct_tid;
    zF_B5A1E8BB_semanticAnalyzerChe(zT_124, zT_125);
    return (unsigned int)(0);
    z_bb_20:
    zT_123 = ti + (unsigned int)(1);
    ti = zT_123;
    goto z_bb_17;
    z_bb_21:
    zT_54 = table.len;
    if ((int)(si < zT_54)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_57 = table.items;
    zT_58 = zT_57[si];
    s = zT_58;
    zT_59 = s.kind;
    if ((int)(zT_59 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_121 = si + (unsigned int)(1);
    si = zT_121;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_64 = s.type_id;
    if ((int)(zT_64 != struct_tid)) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_67 = s.decl_node;
    zT_66 = zT_67 == (unsigned int)(0);
    goto z_bb_29;
    z_bb_28:
    zT_66 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_66) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    goto z_bb_24;
    z_bb_31:
    zT_71 = self->store;
    zT_72 = s.decl_node;
    zT_75 = zF_FCDD1D35_astStoreNodeAt(zT_71, zT_72);
    dnode = zT_75;
    zT_77 = 0;
    target = zT_77;
    zT_78 = dnode.kind;
    if ((int)(zT_78 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_83 = s.decl_node;
    target = zT_83;
    goto z_bb_33;
    z_bb_33:
    if ((int)(target == (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_34:
    zT_84 = dnode.kind;
    if ((int)(zT_84 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_90 = dnode.child_1;
    zT_89 = zT_90 != (unsigned int)(0);
    goto z_bb_37;
    z_bb_36:
    zT_89 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_89) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_94 = self->store;
    zT_95 = dnode.child_1;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    inn = zT_98;
    zT_99 = inn.kind;
    if ((int)(zT_99 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_33;
    z_bb_40:
    zT_104 = dnode.child_1;
    target = zT_104;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    goto z_bb_24;
    z_bb_43:
    zT_108 = self->store;
    zT_109 = target;
    zT_111 = zF_FCDD1D35_astStoreNodeAt(zT_108, zT_109);
    tnode = zT_111;
    zT_112 = tnode.flags;
    if ((int)((unsigned char)(zT_112 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_117 = self;
    zT_118 = struct_tid;
    zT_119 = target;
    zF_2C47D4E0_semanticAnalyzerPac(zT_117, zT_118, zT_119);
    return target;
    z_bb_45:
    goto z_bb_24;
}

/* semanticAnalyzerResolveArithmetic */
unsigned int zF_44006DDD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    zT_38C12417_SemanticAnalyzer* zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    int zT_20;
    int zT_28;
    zT_338B7C76_TypeRegistry* zT_34;
    unsigned int zT_35;
    int zT_37 = 0;
    int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    int zT_42 = 0;
    zT_338B7C76_TypeRegistry* zT_44;
    unsigned int zT_45;
    int zT_47 = 0;
    int zT_48;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_53;
    int zT_55 = 0;
    int zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    int zT_60 = 0;
    int zT_61;
    int zT_66;
    zT_338B7C76_TypeRegistry* zT_67;
    unsigned int zT_68;
    int zT_70 = 0;
    int zT_71;
    int zT_74;
    int zT_79;
    int zT_80;
    int zT_84;
    zT_338B7C76_TypeRegistry* zT_85;
    unsigned int zT_86;
    int zT_88 = 0;
    int zT_91;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    int zT_95 = 0;
    zT_338B7C76_TypeRegistry* zT_96;
    unsigned int zT_97;
    int zT_99 = 0;
    int zT_101;
    zT_338B7C76_TypeRegistry* zT_102;
    unsigned int zT_103;
    int zT_105 = 0;
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int zT_110;
    int zT_112 = 0;
    int zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    unsigned int zT_115;
    int zT_117 = 0;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    unsigned char zT_122 = 0;
    zT_338B7C76_TypeRegistry* zT_124;
    unsigned int zT_125;
    unsigned char zT_127 = 0;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D155D06D_Type* zT_131;
    unsigned int zT_132;
    zT_D155D06D_Type zT_133;
    unsigned int zT_134;
    zT_338B7C76_TypeRegistry* zT_136;
    zT_D155D06D_Type* zT_137;
    unsigned int zT_138;
    zT_D155D06D_Type zT_139;
    unsigned int zT_140;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    int lhs_ptr;
    int rhs_uint;
    int rhs_ptr;
    unsigned char lw;
    unsigned char rw;
    unsigned int ls;
    unsigned int rs;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    lhs = zT_12;
    zT_14 = self;
    zT_15 = node.child_1;
    zT_17 = zF_54F95822_semanticAnalyzerRes(zT_14, zT_15);
    rhs = zT_17;
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_20 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_20 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_20) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_28 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_8;
    z_bb_7:
    zT_28 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_28) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_34 = self->registry;
    zT_35 = lhs;
    zT_37 = zF_AD61DB1B_typeRegistryIsPoint(zT_34, zT_35);
    if (zT_37) goto z_bb_12; else goto z_bb_11;
    z_bb_10:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_39 = self->registry;
    zT_40 = lhs;
    zT_42 = zF_0F4CC580_typeRegistryIsSlice(zT_39, zT_40);
    zT_38 = zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 1;
    goto z_bb_13;
    z_bb_13:
    lhs_ptr = zT_38;
    zT_44 = self->registry;
    zT_45 = rhs;
    zT_47 = zF_B664AC19_typeRegistryIsUnsig(zT_44, zT_45);
    if (zT_47) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_48 = rhs == (unsigned int)(19);
    goto z_bb_16;
    z_bb_15:
    zT_48 = 1;
    goto z_bb_16;
    z_bb_16:
    rhs_uint = zT_48;
    zT_52 = self->registry;
    zT_53 = rhs;
    zT_55 = zF_AD61DB1B_typeRegistryIsPoint(zT_52, zT_53);
    if (zT_55) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_57 = self->registry;
    zT_58 = rhs;
    zT_60 = zF_0F4CC580_typeRegistryIsSlice(zT_57, zT_58);
    zT_56 = zT_60;
    goto z_bb_19;
    z_bb_18:
    zT_56 = 1;
    goto z_bb_19;
    z_bb_19:
    rhs_ptr = zT_56;
    if (lhs_ptr) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = rhs_uint;
    goto z_bb_22;
    z_bb_21:
    zT_61 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_61) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return lhs;
    z_bb_24:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_67 = self->registry;
    zT_68 = lhs;
    zT_70 = zF_B664AC19_typeRegistryIsUnsig(zT_67, zT_68);
    if (zT_70) goto z_bb_29; else goto z_bb_28;
    z_bb_26:
    zT_66 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_66) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_71 = lhs == (unsigned int)(19);
    goto z_bb_30;
    z_bb_29:
    zT_71 = 1;
    goto z_bb_30;
    z_bb_30:
    zT_66 = zT_71;
    goto z_bb_27;
    z_bb_31:
    zT_74 = rhs_ptr;
    goto z_bb_33;
    z_bb_32:
    zT_74 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_74) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return rhs;
    z_bb_35:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_79 = lhs_ptr;
    goto z_bb_38;
    z_bb_37:
    zT_79 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_79) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_80 = rhs_ptr;
    goto z_bb_41;
    z_bb_40:
    zT_80 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_80) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (unsigned int)(12);
    z_bb_43:
    goto z_bb_10;
    z_bb_44:
    zT_85 = self->registry;
    zT_86 = rhs;
    zT_88 = zF_3087E0A5_typeRegistryIsNumer(zT_85, zT_86);
    zT_84 = zT_88;
    goto z_bb_46;
    z_bb_45:
    zT_84 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_84) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return rhs;
    z_bb_48:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_92 = self->registry;
    zT_93 = lhs;
    zT_95 = zF_3087E0A5_typeRegistryIsNumer(zT_92, zT_93);
    zT_91 = zT_95;
    goto z_bb_51;
    z_bb_50:
    zT_91 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_91) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    return lhs;
    z_bb_53:
    zT_96 = self->registry;
    zT_97 = lhs;
    zT_99 = zF_3087E0A5_typeRegistryIsNumer(zT_96, zT_97);
    if ((int)(!zT_99)) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_102 = self->registry;
    zT_103 = rhs;
    zT_105 = zF_3087E0A5_typeRegistryIsNumer(zT_102, zT_103);
    zT_101 = !zT_105;
    goto z_bb_56;
    z_bb_55:
    zT_101 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_101) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned int)(1);
    z_bb_58:
    if ((int)(lhs == rhs)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return lhs;
    z_bb_60:
    zT_109 = self->registry;
    zT_110 = lhs;
    zT_112 = zF_3290E9C4_typeRegistryIsInteg(zT_109, zT_110);
    if (zT_112) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_114 = self->registry;
    zT_115 = rhs;
    zT_117 = zF_3290E9C4_typeRegistryIsInteg(zT_114, zT_115);
    zT_113 = zT_117;
    goto z_bb_63;
    z_bb_62:
    zT_113 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_113) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_119 = self->registry;
    zT_120 = lhs;
    zT_122 = zF_655972D5_typeRegistryIntWidt(zT_119, zT_120);
    lw = zT_122;
    zT_124 = self->registry;
    zT_125 = rhs;
    zT_127 = zF_655972D5_typeRegistryIntWidt(zT_124, zT_125);
    rw = zT_127;
    if ((int)(lw >= rw)) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    zT_130 = self->registry;
    zT_131 = zT_130->types_items;
    zT_132 = (unsigned int)lhs;
    zT_133 = zT_131[zT_132];
    zT_134 = zT_133.size;
    ls = zT_134;
    zT_136 = self->registry;
    zT_137 = zT_136->types_items;
    zT_138 = (unsigned int)rhs;
    zT_139 = zT_137[zT_138];
    zT_140 = zT_139.size;
    rs = zT_140;
    if ((int)(ls >= rs)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    return lhs;
    z_bb_67:
    return rhs;
    z_bb_68:
    return lhs;
    z_bb_69:
    return rhs;
}

/* semanticAnalyzerResolveBitwise */
unsigned int zF_733BCA9C_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    int zT_19;
    int zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    int zT_29 = 0;
    int zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    int zT_36 = 0;
    int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    int zT_42 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    lhs = zT_11;
    zT_13 = self;
    zT_14 = node.child_1;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    rhs = zT_16;
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_19 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_19 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_26 = self->registry;
    zT_27 = rhs;
    zT_29 = zF_3290E9C4_typeRegistryIsInteg(zT_26, zT_27);
    zT_25 = zT_29;
    goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_25) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return rhs;
    z_bb_10:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->registry;
    zT_34 = lhs;
    zT_36 = zF_3290E9C4_typeRegistryIsInteg(zT_33, zT_34);
    zT_32 = zT_36;
    goto z_bb_13;
    z_bb_12:
    zT_32 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_32) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return lhs;
    z_bb_15:
    if ((int)(lhs != rhs)) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_39 = self->registry;
    zT_40 = lhs;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_39, zT_40);
    zT_38 = !zT_42;
    goto z_bb_18;
    z_bb_17:
    zT_38 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_38) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned int)(1);
    z_bb_20:
    return lhs;
}

/* semanticAnalyzerResolveComparison */
unsigned int zF_EB621FF0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_24 = {0};
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    int zT_37;
    zT_8143F551_AstKind zT_38;
    unsigned char zT_43;
    zT_8143F551_AstKind zT_47;
    int zT_52;
    zT_8143F551_AstKind zT_53;
    unsigned char zT_58;
    int zT_63;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int zT_67;
    unsigned int zT_69 = 0;
    int zT_71;
    unsigned int zT_72;
    int zT_73;
    int zT_75;
    int zT_78;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_D155D06D_Type* zT_82;
    unsigned int zT_83;
    zT_D155D06D_Type zT_84;
    zT_33EF6BFB_TypeKind zT_85;
    zT_8143F551_AstKind zT_86;
    int zT_91;
    int zT_96;
    zT_8143F551_AstKind zT_97;
    int zT_102;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_108;
    zT_38C12417_SemanticAnalyzer* zT_109;
    unsigned int zT_110;
    unsigned int zT_112 = 0;
    zT_38C12417_SemanticAnalyzer* zT_113;
    zT_38C12417_SemanticAnalyzer* zT_114;
    unsigned int zT_115;
    unsigned int zT_117 = 0;
    int zT_120;
    zT_38C12417_SemanticAnalyzer* zT_123;
    unsigned int zT_124;
    unsigned int zT_126 = 0;
    int zT_128;
    unsigned int zT_129;
    int zT_130;
    int zT_132;
    int zT_135;
    zT_338B7C76_TypeRegistry* zT_138;
    zT_D155D06D_Type* zT_139;
    unsigned int zT_140;
    zT_D155D06D_Type zT_141;
    zT_33EF6BFB_TypeKind zT_142;
    zT_8143F551_AstKind zT_143;
    int zT_148;
    int zT_153;
    zT_8143F551_AstKind zT_154;
    int zT_159;
    zT_38C12417_SemanticAnalyzer* zT_164;
    unsigned int zT_165;
    zT_38C12417_SemanticAnalyzer* zT_166;
    unsigned int zT_167;
    unsigned int zT_169 = 0;
    zT_38C12417_SemanticAnalyzer* zT_170;
    zT_38C12417_SemanticAnalyzer* zT_171;
    unsigned int zT_172;
    unsigned int zT_174 = 0;
    zT_38C12417_SemanticAnalyzer* zT_175;
    unsigned int zT_176;
    unsigned int zT_178 = 0;
    zT_38C12417_SemanticAnalyzer* zT_179;
    unsigned int zT_180;
    unsigned int zT_182 = 0;
    int zT_185;
    char* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    int zT_196;
    zT_338B7C76_TypeRegistry* zT_197;
    unsigned int zT_198;
    int zT_200 = 0;
    char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    int zT_209;
    zT_338B7C76_TypeRegistry* zT_210;
    unsigned int zT_211;
    int zT_213 = 0;
    char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    zT_338B7C76_TypeRegistry* zT_221;
    unsigned int zT_222;
    int zT_224 = 0;
    int zT_225;
    char* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned int zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    int zT_237;
    zT_338B7C76_TypeRegistry* zT_242;
    unsigned int zT_243;
    int zT_245 = 0;
    int zT_246;
    zT_338B7C76_TypeRegistry* zT_250;
    unsigned int zT_251;
    int zT_253 = 0;
    int zT_254;
    zT_338B7C76_TypeRegistry* zT_258;
    unsigned int zT_259;
    int zT_261 = 0;
    int zT_262;
    zT_338B7C76_TypeRegistry* zT_263;
    unsigned int zT_264;
    int zT_266 = 0;
    char* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    char* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned int zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    zT_338B7C76_TypeRegistry* zT_282;
    unsigned int zT_283;
    int zT_285 = 0;
    char* zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    unsigned int zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    char* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned int zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_298;
    unsigned int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    int zT_304;
    unsigned char* zT_305;
    unsigned int zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308 = 0;
    unsigned int zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    unsigned char* zT_317;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    char* zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_326;
    unsigned int zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    int zT_332;
    unsigned char* zT_333;
    unsigned int zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    unsigned int zT_336 = 0;
    unsigned int zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned char* zT_345;
    unsigned int zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    char* zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned int zT_351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_352;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_354;
    unsigned int zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    int zT_361;
    unsigned char* zT_362;
    unsigned int zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    unsigned int zT_365 = 0;
    unsigned int zT_369;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_370;
    unsigned char* zT_374;
    unsigned int zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    char* zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned int zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_22A7C88B_AstNode c0n;
    zT_22A7C88B_AstNode c1n;
    unsigned char c0_lit;
    unsigned char c1_lit;
    unsigned int peerk;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp0;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp2;
    int lhs_num;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp3;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp4;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_lb;
    unsigned int cpv_ll;
    unsigned int cpv_ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_rh;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_rb;
    unsigned int cpv_rl;
    unsigned int cpv_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_ih;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_ib;
    unsigned int cpv_il;
    unsigned int cpv_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp5;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp6;
    zT_4 = "CPE";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    cpe = zT_5;
    zT_7 = cpe;
    zF_48AC7B3A_markerWrite(zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    lhs = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    rhs = zT_18;
    zT_20 = self->store;
    zT_21 = node.child_0;
    zT_24 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    c0n = zT_24;
    zT_26 = self->store;
    zT_27 = node.child_1;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    c1n = zT_30;
    zT_32 = c0n.kind;
    if ((int)(zT_32 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_38 = c0n.kind;
    zT_37 = zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_3;
    z_bb_2:
    zT_37 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_37) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_43 = 1;
    goto z_bb_6;
    z_bb_5:
    zT_43 = 0;
    goto z_bb_6;
    z_bb_6:
    c0_lit = zT_43;
    zT_47 = c1n.kind;
    if ((int)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_53 = c1n.kind;
    zT_52 = zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_9;
    z_bb_8:
    zT_52 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_52) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_58 = 1;
    goto z_bb_12;
    z_bb_11:
    zT_58 = 0;
    goto z_bb_12;
    z_bb_12:
    c1_lit = zT_58;
    if ((int)(c0_lit == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_63 = c1_lit != (unsigned char)(0);
    goto z_bb_15;
    z_bb_14:
    zT_63 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_63) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_66 = self;
    zT_67 = node.child_0;
    zT_69 = zF_54F95822_semanticAnalyzerRes(zT_66, zT_67);
    lhs = zT_69;
    zT_71 = 0;
    zT_72 = (unsigned int)zT_71;
    peerk = zT_72;
    zT_73 = 0;
    if ((int)(lhs != (unsigned int)zT_73)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_66; else goto z_bb_65;
    z_bb_18:
    if ((int)(c0_lit != (unsigned char)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_19:
    zT_75 = lhs != (unsigned int)(1);
    goto z_bb_21;
    z_bb_20:
    zT_75 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_75) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_78 = lhs != (unsigned int)(18);
    goto z_bb_24;
    z_bb_23:
    zT_78 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_78) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_81 = self->registry;
    zT_82 = zT_81->types_items;
    zT_83 = (unsigned int)lhs;
    zT_84 = zT_82[zT_83];
    zT_85 = zT_84.kind;
    peerk = zT_85;
    goto z_bb_26;
    z_bb_26:
    zT_86 = c1n.kind;
    if ((int)(zT_86 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_91 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_29;
    z_bb_28:
    zT_91 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_91) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_97 = c1n.kind;
    if ((int)(zT_97 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_96 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_96) goto z_bb_36; else goto z_bb_38;
    z_bb_33:
    zT_102 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_35;
    z_bb_34:
    zT_102 = 0;
    goto z_bb_35;
    z_bb_35:
    zT_96 = zT_102;
    goto z_bb_32;
    z_bb_36:
    zT_107 = self;
    zT_108 = lhs;
    zF_9665A229_pushExpectedType(zT_107, zT_108);
    zT_109 = self;
    zT_110 = node.child_1;
    zT_112 = zF_54F95822_semanticAnalyzerRes(zT_109, zT_110);
    rhs = zT_112;
    zT_113 = self;
    zF_BC478E78_popExpectedType(zT_113);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_17;
    z_bb_38:
    zT_114 = self;
    zT_115 = node.child_1;
    zT_117 = zF_54F95822_semanticAnalyzerRes(zT_114, zT_115);
    rhs = zT_117;
    goto z_bb_37;
    z_bb_39:
    zT_120 = c1_lit == (unsigned char)(0);
    goto z_bb_41;
    z_bb_40:
    zT_120 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_120) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_123 = self;
    zT_124 = node.child_1;
    zT_126 = zF_54F95822_semanticAnalyzerRes(zT_123, zT_124);
    rhs = zT_126;
    zT_128 = 0;
    zT_129 = (unsigned int)zT_128;
    peerk = zT_129;
    zT_130 = 0;
    if ((int)(rhs != (unsigned int)zT_130)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_17;
    z_bb_44:
    zT_175 = self;
    zT_176 = node.child_0;
    zT_178 = zF_54F95822_semanticAnalyzerRes(zT_175, zT_176);
    lhs = zT_178;
    zT_179 = self;
    zT_180 = node.child_1;
    zT_182 = zF_54F95822_semanticAnalyzerRes(zT_179, zT_180);
    rhs = zT_182;
    goto z_bb_43;
    z_bb_45:
    zT_132 = rhs != (unsigned int)(1);
    goto z_bb_47;
    z_bb_46:
    zT_132 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_132) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_135 = rhs != (unsigned int)(18);
    goto z_bb_50;
    z_bb_49:
    zT_135 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_135) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_138 = self->registry;
    zT_139 = zT_138->types_items;
    zT_140 = (unsigned int)rhs;
    zT_141 = zT_139[zT_140];
    zT_142 = zT_141.kind;
    peerk = zT_142;
    goto z_bb_52;
    z_bb_52:
    zT_143 = c0n.kind;
    if ((int)(zT_143 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_148 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_55;
    z_bb_54:
    zT_148 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_148) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_154 = c0n.kind;
    if ((int)(zT_154 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_153 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_153) goto z_bb_62; else goto z_bb_64;
    z_bb_59:
    zT_159 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_61;
    z_bb_60:
    zT_159 = 0;
    goto z_bb_61;
    z_bb_61:
    zT_153 = zT_159;
    goto z_bb_58;
    z_bb_62:
    zT_164 = self;
    zT_165 = rhs;
    zF_9665A229_pushExpectedType(zT_164, zT_165);
    zT_166 = self;
    zT_167 = node.child_0;
    zT_169 = zF_54F95822_semanticAnalyzerRes(zT_166, zT_167);
    lhs = zT_169;
    zT_170 = self;
    zF_BC478E78_popExpectedType(zT_170);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_43;
    z_bb_64:
    zT_171 = self;
    zT_172 = node.child_0;
    zT_174 = zF_54F95822_semanticAnalyzerRes(zT_171, zT_172);
    lhs = zT_174;
    goto z_bb_63;
    z_bb_65:
    zT_185 = rhs == (unsigned int)(0);
    goto z_bb_67;
    z_bb_66:
    zT_185 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_185) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_189 = "CP0";
    zT_191 = 3;
    zT_190.ptr = zT_189;
    zT_190.len = zT_191;
    cp0 = zT_190;
    zT_192 = cp0;
    zF_48AC7B3A_markerWrite(zT_192);
    return (unsigned int)(1);
    z_bb_69:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_197 = self->registry;
    zT_198 = rhs;
    zT_200 = zF_3087E0A5_typeRegistryIsNumer(zT_197, zT_198);
    zT_196 = zT_200;
    goto z_bb_72;
    z_bb_71:
    zT_196 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_196) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_202 = "CPB";
    zT_204 = 3;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    cp1 = zT_203;
    zT_205 = cp1;
    zF_48AC7B3A_markerWrite(zT_205);
    return (unsigned int)(2);
    z_bb_74:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_210 = self->registry;
    zT_211 = lhs;
    zT_213 = zF_3087E0A5_typeRegistryIsNumer(zT_210, zT_211);
    zT_209 = zT_213;
    goto z_bb_77;
    z_bb_76:
    zT_209 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_209) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_215 = "CPB";
    zT_217 = 3;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    cp2 = zT_216;
    zT_218 = cp2;
    zF_48AC7B3A_markerWrite(zT_218);
    return (unsigned int)(2);
    z_bb_79:
    zT_221 = self->registry;
    zT_222 = lhs;
    zT_224 = zF_3087E0A5_typeRegistryIsNumer(zT_221, zT_222);
    lhs_num = zT_224;
    if (lhs_num) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_225 = lhs == rhs;
    goto z_bb_82;
    z_bb_81:
    zT_225 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_225) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_228 = "CPB";
    zT_230 = 3;
    zT_229.ptr = zT_228;
    zT_229.len = zT_230;
    cp3 = zT_229;
    zT_231 = cp3;
    zF_48AC7B3A_markerWrite(zT_231);
    return (unsigned int)(2);
    z_bb_84:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_237 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_87;
    z_bb_86:
    zT_237 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_237) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_242 = self->registry;
    zT_243 = lhs;
    zT_245 = zF_DA6AF452_typeRegistryIsOptio(zT_242, zT_243);
    if (zT_245) goto z_bb_90; else goto z_bb_91;
    z_bb_89:
    if ((int)(lhs == rhs)) goto z_bb_105; else goto z_bb_106;
    z_bb_90:
    zT_246 = rhs == (unsigned int)(17);
    goto z_bb_92;
    z_bb_91:
    zT_246 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_246) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned int)(2);
    z_bb_94:
    zT_250 = self->registry;
    zT_251 = rhs;
    zT_253 = zF_DA6AF452_typeRegistryIsOptio(zT_250, zT_251);
    if (zT_253) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_254 = lhs == (unsigned int)(17);
    goto z_bb_97;
    z_bb_96:
    zT_254 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_254) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    return (unsigned int)(2);
    z_bb_99:
    zT_258 = self->registry;
    zT_259 = lhs;
    zT_261 = zF_B8767394_typeRegistryIsError(zT_258, zT_259);
    if (zT_261) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_263 = self->registry;
    zT_264 = rhs;
    zT_266 = zF_B8767394_typeRegistryIsError(zT_263, zT_264);
    zT_262 = zT_266;
    goto z_bb_102;
    z_bb_101:
    zT_262 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_262) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_268 = "CPB";
    zT_270 = 3;
    zT_269.ptr = zT_268;
    zT_269.len = zT_270;
    cp4 = zT_269;
    zT_271 = cp4;
    zF_48AC7B3A_markerWrite(zT_271);
    return (unsigned int)(2);
    z_bb_104:
    goto z_bb_89;
    z_bb_105:
    if ((int)(lhs == (unsigned int)(2))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_293 = "CPVl";
    zT_295 = 4;
    zT_294.ptr = zT_293;
    zT_294.len = zT_295;
    cpv = zT_294;
    zT_296 = cpv;
    zF_48AC7B3A_markerWrite(zT_296);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_298[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_lb[_i] = zT_298[_i];
        _i++;
    }
}
    zT_300 = lhs;
    zT_304 = 0;
    zT_305 = (unsigned char*)((unsigned char*)cpv_lb) + zT_304;
    zT_306 = (unsigned int)(10) - zT_304;
    zT_307.ptr = zT_305;
    zT_307.len = zT_306;
    zT_301 = zT_307;
    zT_308 = zF_A7504564_itoa(zT_300, zT_301);
    cpv_ll = zT_308;
    zT_312 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_ll);
    cpv_ls = zT_312;
    zT_317 = (unsigned char*)((unsigned char*)cpv_lb) + cpv_ls;
    zT_318 = (unsigned int)(9) - cpv_ls;
    zT_319.ptr = zT_317;
    zT_319.len = zT_318;
    zT_313 = zT_319;
    zF_48AC7B3A_markerWrite(zT_313);
    zT_321 = "r";
    zT_323 = 1;
    zT_322.ptr = zT_321;
    zT_322.len = zT_323;
    cpv_rh = zT_322;
    zT_324 = cpv_rh;
    zF_48AC7B3A_markerWrite(zT_324);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_326[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_rb[_i] = zT_326[_i];
        _i++;
    }
}
    zT_328 = rhs;
    zT_332 = 0;
    zT_333 = (unsigned char*)((unsigned char*)cpv_rb) + zT_332;
    zT_334 = (unsigned int)(10) - zT_332;
    zT_335.ptr = zT_333;
    zT_335.len = zT_334;
    zT_329 = zT_335;
    zT_336 = zF_A7504564_itoa(zT_328, zT_329);
    cpv_rl = zT_336;
    zT_340 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_rl);
    cpv_rs = zT_340;
    zT_345 = (unsigned char*)((unsigned char*)cpv_rb) + cpv_rs;
    zT_346 = (unsigned int)(9) - cpv_rs;
    zT_347.ptr = zT_345;
    zT_347.len = zT_346;
    zT_341 = zT_347;
    zF_48AC7B3A_markerWrite(zT_341);
    zT_349 = "n";
    zT_351 = 1;
    zT_350.ptr = zT_349;
    zT_350.len = zT_351;
    cpv_ih = zT_350;
    zT_352 = cpv_ih;
    zF_48AC7B3A_markerWrite(zT_352);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_354[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_ib[_i] = zT_354[_i];
        _i++;
    }
}
    zT_356 = node.child_0;
    zT_361 = 0;
    zT_362 = (unsigned char*)((unsigned char*)cpv_ib) + zT_361;
    zT_363 = (unsigned int)(10) - zT_361;
    zT_364.ptr = zT_362;
    zT_364.len = zT_363;
    zT_357 = zT_364;
    zT_365 = zF_A7504564_itoa(zT_356, zT_357);
    cpv_il = zT_365;
    zT_369 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_il);
    cpv_is = zT_369;
    zT_374 = (unsigned char*)((unsigned char*)cpv_ib) + cpv_is;
    zT_375 = (unsigned int)(9) - cpv_is;
    zT_376.ptr = zT_374;
    zT_376.len = zT_375;
    zT_370 = zT_376;
    zF_48AC7B3A_markerWrite(zT_370);
    zT_378 = "\n";
    zT_380 = 1;
    zT_379.ptr = zT_378;
    zT_379.len = zT_380;
    cpv_nl = zT_379;
    zT_381 = cpv_nl;
    zF_48AC7B3A_markerWrite(zT_381);
    return (unsigned int)(1);
    z_bb_107:
    zT_277 = "CPB";
    zT_279 = 3;
    zT_278.ptr = zT_277;
    zT_278.len = zT_279;
    cp5 = zT_278;
    zT_280 = cp5;
    zF_48AC7B3A_markerWrite(zT_280);
    return (unsigned int)(2);
    z_bb_108:
    zT_282 = self->registry;
    zT_283 = lhs;
    zT_285 = zF_AD61DB1B_typeRegistryIsPoint(zT_282, zT_283);
    if (zT_285) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_287 = "CPB";
    zT_289 = 3;
    zT_288.ptr = zT_287;
    zT_288.len = zT_289;
    cp6 = zT_288;
    zT_290 = cp6;
    zF_48AC7B3A_markerWrite(zT_290);
    return (unsigned int)(2);
    z_bb_110:
    goto z_bb_106;
}

/* semanticAnalyzerResolveLogical */
unsigned int zF_6F2B8B98_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    int zT_24;
    char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u loe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo2;
    zT_3 = "LOE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    loe = zT_4;
    zT_6 = loe;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_18 = self;
    zT_19 = node.child_1;
    zT_21 = zF_54F95822_semanticAnalyzerRes(zT_18, zT_19);
    rhs = zT_21;
    if ((int)(lhs == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_24 = rhs == (unsigned int)(2);
    goto z_bb_3;
    z_bb_2:
    zT_24 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_24) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_28 = "LOB";
    zT_30 = 3;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    lo1 = zT_29;
    zT_31 = lo1;
    zF_48AC7B3A_markerWrite(zT_31);
    return (unsigned int)(2);
    z_bb_5:
    zT_34 = "LOV";
    zT_36 = 3;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    lo2 = zT_35;
    zT_37 = lo2;
    zF_48AC7B3A_markerWrite(zT_37);
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveNegate */
unsigned int zF_09421FDF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    int zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((int)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3087E0A5_typeRegistryIsNumer(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveBitNot */
unsigned int zF_6B59E8AD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    int zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((int)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3290E9C4_typeRegistryIsInteg(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* tryRecordCoercion */
void zF_DF7434EB_tryRecordCoercion(zT_38C12417_SemanticAnalyzer* self, unsigned int src_node, unsigned int src_type, unsigned int dst_type) {
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_338B7C76_TypeRegistry* zT_23;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_33EF6BFB_TypeKind zT_38;
    char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_33EF6BFB_TypeKind zT_46;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_52 = {0};
    char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_8143F551_AstKind zT_59;
    int zT_63;
    zT_338B7C76_TypeRegistry* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    int zT_69 = 0;
    char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    zT_338B7C76_TypeRegistry* zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    zT_0FB7FB13_CoercionKind zT_83 = 0;
    char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    int zT_95;
    int zT_98;
    zT_338B7C76_TypeRegistry* zT_99;
    unsigned int zT_100;
    int zT_102 = 0;
    zT_66E7D2EF_CoercionTable* zT_103;
    unsigned int zT_104;
    zT_0FB7FB13_CoercionKind zT_105;
    unsigned int zT_106;
    char* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dm;
    zT_D155D06D_Type src_t;
    zT_D155D06D_Type dst_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_skm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dkm;
    zT_22A7C88B_AstNode snode;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs1_m;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u cka_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_km;
    zT_5 = "COE:N";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    coe_nm = zT_6;
    zT_8 = coe_nm;
    zT_9 = src_node;
    zF_C914CB83_markerWriteInt(zT_8, zT_9);
    zT_11 = "COE:S";
    zT_13 = 5;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    coe_sm = zT_12;
    zT_14 = coe_sm;
    zT_15 = src_type;
    zF_C914CB83_markerWriteInt(zT_14, zT_15);
    zT_17 = "COE:D";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    coe_dm = zT_18;
    zT_20 = coe_dm;
    zT_21 = dst_type;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = self->registry;
    zT_24 = zT_23->types_items;
    zT_25 = (unsigned int)src_type;
    zT_26 = zT_24[zT_25];
    src_t = zT_26;
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)dst_type;
    zT_31 = zT_29[zT_30];
    dst_t = zT_31;
    zT_33 = "COE:SK";
    zT_35 = 6;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    coe_skm = zT_34;
    zT_36 = coe_skm;
    zT_38 = src_t.kind;
    zF_C914CB83_markerWriteInt(zT_36, (unsigned int)((unsigned int)zT_38));
    zT_41 = "COE:DK";
    zT_43 = 6;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    coe_dkm = zT_42;
    zT_44 = coe_dkm;
    zT_46 = dst_t.kind;
    zF_C914CB83_markerWriteInt(zT_44, (unsigned int)((unsigned int)zT_46));
    zT_49 = self->store;
    zT_50 = src_node;
    zT_52 = zF_FCDD1D35_astStoreNodeAt(zT_49, zT_50);
    snode = zT_52;
    zT_54 = "COE:NK";
    zT_56 = 6;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    coe_nkm = zT_55;
    zT_57 = coe_nkm;
    zT_59 = snode.kind;
    zF_C914CB83_markerWriteInt(zT_57, (unsigned int)((unsigned int)zT_59));
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_63 = src_type == dst_type;
    goto z_bb_3;
    z_bb_2:
    zT_63 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_63) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_65 = self->registry;
    zT_66 = src_type;
    zT_67 = dst_type;
    zT_69 = zF_683AEB7F_typeRegistryIsAssig(zT_65, zT_66, zT_67);
    if ((int)(!zT_69)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    if ((int)(src_type == (unsigned int)(17))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_74 = "CS1\n";
    zT_76 = 4;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    cs1_m = zT_75;
    zT_77 = cs1_m;
    zF_48AC7B3A_markerWrite(zT_77);
    goto z_bb_9;
    z_bb_9:
    zT_79 = self->registry;
    zT_80 = src_type;
    zT_81 = dst_type;
    zT_83 = zF_713658BF_classifyCoercion(zT_79, zT_80, zT_81);
    ck = zT_83;
    zT_85 = "CCK:ca";
    zT_87 = 6;
    zT_86.ptr = zT_85;
    zT_86.len = zT_87;
    cka_m = zT_86;
    zT_88 = cka_m;
    zF_C914CB83_markerWriteInt(zT_88, (unsigned int)((unsigned int)ck));
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    if ((int)(src_type == (unsigned int)(17))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_95 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_95) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_99 = self->registry;
    zT_100 = dst_type;
    zT_102 = zF_AD61DB1B_typeRegistryIsPoint(zT_99, zT_100);
    zT_98 = zT_102;
    goto z_bb_15;
    z_bb_14:
    zT_98 = 0;
    goto z_bb_15;
    z_bb_15:
    zT_95 = zT_98;
    goto z_bb_12;
    z_bb_16:
    zT_103 = self->coercion_table;
    zT_104 = src_node;
    zT_105 = ck;
    zT_106 = dst_type;
    zF_D21AE60A_coercionTableAdd(zT_103, zT_104, zT_105, zT_106);
    zT_109 = "COR:N";
    zT_111 = 5;
    zT_110.ptr = zT_109;
    zT_110.len = zT_111;
    cor_nm = zT_110;
    zT_112 = cor_nm;
    zT_113 = src_node;
    zF_C914CB83_markerWriteInt(zT_112, zT_113);
    zT_115 = "COR:K";
    zT_117 = 5;
    zT_116.ptr = zT_115;
    zT_116.len = zT_117;
    cor_km = zT_116;
    zT_118 = cor_km;
    zF_C914CB83_markerWriteInt(zT_118, (unsigned int)((unsigned int)ck));
    goto z_bb_17;
    z_bb_17:
    return;
}

/* errLitSrcType */
unsigned int zF_FFC95E09_errLitSrcType(zT_38C12417_SemanticAnalyzer* self, unsigned int child_0, unsigned int target_ty, unsigned int ret_val) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_D155D06D_Type* zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_42C2D6BF_EUPayload* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_42C2D6BF_EUPayload zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode rn;
    zT_D155D06D_Type frt;
    zT_5 = self->store;
    zT_6 = child_0;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    rn = zT_8;
    zT_9 = rn.kind;
    if ((int)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = self->registry;
    zT_16 = zT_15->types_items;
    zT_17 = (unsigned int)target_ty;
    zT_18 = zT_16[zT_17];
    frt = zT_18;
    zT_19 = frt.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return ret_val;
    z_bb_3:
    zT_24 = self->registry;
    zT_25 = zT_24->eu_items;
    zT_26 = frt.payload_idx;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_25[zT_27];
    zT_29 = zT_28.error_set;
    return zT_29;
    z_bb_4:
    goto z_bb_2;
}

/* resolveReturnStmt */
void zF_F231D87F_resolveReturnStmt(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    zT_38C12417_SemanticAnalyzer* zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    int zT_22;
    unsigned int zT_23;
    char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_38C12417_SemanticAnalyzer* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_38C12417_SemanticAnalyzer* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_57 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int ret_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_fm;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((int)(zT_7 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_11 = self->current_fn_return;
    zF_9665A229_pushExpectedType(zT_10, zT_11);
    zT_14 = self;
    zT_15 = node.child_0;
    zT_17 = zF_54F95822_semanticAnalyzerRes(zT_14, zT_15);
    ret_val = zT_17;
    zT_18 = self;
    zF_BC478E78_popExpectedType(zT_18);
    zT_19 = self->current_fn_return;
    if ((int)(zT_19 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    zT_23 = self->current_fn_return;
    zT_22 = zT_23 != (unsigned int)(1);
    goto z_bb_5;
    z_bb_4:
    zT_22 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_22) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_27 = "T2F:C";
    zT_29 = 5;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    t2f_nm = zT_28;
    zT_30 = t2f_nm;
    zT_31 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_30, zT_31);
    zT_34 = "T2F:R";
    zT_36 = 5;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    t2f_rm = zT_35;
    zT_37 = t2f_rm;
    zT_38 = ret_val;
    zF_C914CB83_markerWriteInt(zT_37, zT_38);
    zT_40 = "T2F:F";
    zT_42 = 5;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    t2f_fm = zT_41;
    zT_43 = t2f_fm;
    zT_44 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_43, zT_44);
    zT_46 = self;
    zT_47 = node.child_0;
    zT_51 = self;
    zT_52 = node.child_0;
    zT_53 = self->current_fn_return;
    zT_54 = ret_val;
    zT_57 = zF_FFC95E09_errLitSrcType(zT_51, zT_52, zT_53, zT_54);
    zT_48 = zT_57;
    zT_49 = self->current_fn_return;
    zF_DF7434EB_tryRecordCoercion(zT_46, zT_47, zT_48, zT_49);
    goto z_bb_7;
    z_bb_7:
    goto z_bb_2;
}

/* semanticAnalyzerResolveFnCall */
unsigned int zF_87E78775_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    unsigned int zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_8143F551_AstKind zT_23;
    zT_3D7259E2_SymbolRegistry* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int zT_38 = 0;
    zT_E282FB55_Opt_808 zT_39 = {0};
    unsigned char zT_40;
    char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_8EED1867_ResolvedTypeTable* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_3C598AEF_SymbolKind zT_57;
    int zT_62;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode zT_71 = {0};
    zT_8143F551_AstKind zT_72;
    zT_6B0A7D14_AstStore* zT_78;
    zT_4A837C97_anon_184529 zT_79;
    zT_243D6A41_FnProto* zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_85 = 0;
    unsigned int zT_86;
    zT_243D6A41_FnProto zT_87;
    unsigned int zT_88;
    zT_8EED1867_ResolvedTypeTable* zT_92;
    unsigned int zT_93;
    zT_BAEE192E_Opt_10 zT_96 = {0};
    unsigned char zT_98;
    unsigned int zT_99;
    char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    unsigned char zT_108;
    char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_ABC1EBBE_TypeResolveEnv zT_117;
    zT_6B0A7D14_AstStore* zT_118;
    zT_338B7C76_TypeRegistry* zT_119;
    zT_3D7259E2_SymbolRegistry* zT_120;
    zT_D3EB6303_StringInterner* zT_121;
    unsigned int zT_122;
    zT_ABC1EBBE_TypeResolveEnv* zT_124;
    unsigned int zT_125;
    unsigned int zT_130 = 0;
    char* zT_132;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_133;
    unsigned int zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    unsigned int zT_136;
    char* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143;
    unsigned int zT_144;
    char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_167 = {0};
    unsigned char zT_169;
    unsigned short zT_171;
    unsigned int zT_173;
    int zT_174;
    zT_8EED1867_ResolvedTypeTable* zT_177;
    unsigned int zT_178;
    zT_BAEE192E_Opt_10 zT_180 = {0};
    unsigned char zT_181;
    char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    zT_338B7C76_TypeRegistry* zT_189;
    zT_D155D06D_Type* zT_190;
    unsigned int zT_191;
    zT_D155D06D_Type zT_192;
    zT_33EF6BFB_TypeKind zT_193;
    zT_338B7C76_TypeRegistry* zT_199;
    zT_0317B1D5_FnPayload* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    zT_0317B1D5_FnPayload zT_203;
    unsigned short zT_204;
    unsigned int zT_205;
    unsigned char zT_206;
    int zT_208;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_214;
    int zT_217;
    unsigned int zT_225;
    unsigned int zT_226;
    zT_21D3708C_U32ToU32Map* zT_227;
    unsigned int zT_228;
    zT_BAEE192E_Opt_10 zT_230 = {0};
    unsigned char zT_231;
    zT_338B7C76_TypeRegistry* zT_233;
    unsigned int* zT_234;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_21D3708C_U32ToU32Map* zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned int* zT_242;
    zT_38C12417_SemanticAnalyzer* zT_244;
    unsigned int zT_245;
    zT_38C12417_SemanticAnalyzer* zT_247;
    unsigned int zT_248;
    unsigned int* zT_249;
    unsigned int zT_251 = 0;
    zT_38C12417_SemanticAnalyzer* zT_252;
    int zT_255;
    zT_38C12417_SemanticAnalyzer* zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    unsigned int zT_261;
    unsigned int* zT_262;
    zT_38C12417_SemanticAnalyzer* zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int* zT_268;
    unsigned int zT_270 = 0;
    int zT_271;
    unsigned int zT_272;
    zT_8EED1867_ResolvedTypeTable* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    zT_38C12417_SemanticAnalyzer* zT_278;
    unsigned int zT_279;
    unsigned int zT_281 = 0;
    char* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    zT_338B7C76_TypeRegistry* zT_291;
    zT_D155D06D_Type* zT_292;
    unsigned int zT_293;
    zT_D155D06D_Type zT_294;
    zT_33EF6BFB_TypeKind zT_295;
    zT_338B7C76_TypeRegistry* zT_301;
    zT_112BF819_PtrPayload* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_112BF819_PtrPayload zT_305;
    zT_338B7C76_TypeRegistry* zT_307;
    zT_D155D06D_Type* zT_308;
    unsigned int zT_309;
    unsigned int zT_310;
    zT_D155D06D_Type zT_311;
    zT_33EF6BFB_TypeKind zT_312;
    unsigned int zT_317;
    zT_338B7C76_TypeRegistry* zT_318;
    zT_D155D06D_Type* zT_319;
    unsigned int zT_320;
    zT_D155D06D_Type zT_321;
    zT_33EF6BFB_TypeKind zT_322;
    char* zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    unsigned int zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    char* zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    unsigned int zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    unsigned int zT_338;
    char* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    zT_33EF6BFB_TypeKind zT_345;
    zT_6B0A7D14_AstStore* zT_348;
    unsigned int zT_349;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_351 = {0};
    unsigned int zT_353;
    unsigned int zT_355;
    zT_38C12417_SemanticAnalyzer* zT_357;
    zT_38C12417_SemanticAnalyzer* zT_360;
    unsigned int zT_361;
    unsigned int* zT_362;
    unsigned int zT_364 = 0;
    zT_38C12417_SemanticAnalyzer* zT_365;
    unsigned int zT_367;
    char* zT_370;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    unsigned int zT_372;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_373;
    zT_338B7C76_TypeRegistry* zT_375;
    zT_0317B1D5_FnPayload* zT_376;
    unsigned int zT_377;
    unsigned int zT_378;
    zT_0317B1D5_FnPayload zT_379;
    char* zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_382;
    unsigned int zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    unsigned short zT_386;
    unsigned int zT_387;
    unsigned int zT_389;
    unsigned int zT_390;
    char* zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_394;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_395;
    zT_6B0A7D14_AstStore* zT_397;
    unsigned int zT_398;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_400 = {0};
    char* zT_402;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    unsigned int zT_404;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405;
    unsigned char zT_407;
    unsigned char zT_408;
    unsigned char zT_413;
    unsigned int zT_418;
    unsigned int zT_420;
    unsigned int zT_422;
    unsigned int zT_424;
    int zT_426;
    unsigned int zT_427;
    char* zT_429;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_430;
    unsigned int zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_432;
    char* zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned int zT_436;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437;
    zT_338B7C76_TypeRegistry* zT_439;
    unsigned int zT_440;
    char* zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_444;
    unsigned int zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    char* zT_451;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_452;
    unsigned int zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_454;
    zT_338B7C76_TypeRegistry* zT_456;
    unsigned int* zT_457;
    unsigned int zT_458;
    unsigned int zT_459;
    zT_21D3708C_U32ToU32Map* zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    unsigned int* zT_464;
    char* zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    unsigned int zT_469;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_470;
    char* zT_474;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_475;
    unsigned int zT_476;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_477;
    unsigned int zT_478;
    char* zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned int zT_482;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_483;
    unsigned int zT_484;
    unsigned int* zT_485;
    char* zT_488;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_489;
    unsigned int zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_491;
    zT_38C12417_SemanticAnalyzer* zT_492;
    unsigned int zT_493;
    zT_38C12417_SemanticAnalyzer* zT_495;
    unsigned int zT_496;
    unsigned int* zT_497;
    unsigned int zT_499 = 0;
    zT_38C12417_SemanticAnalyzer* zT_500;
    zT_21D3708C_U32ToU32Map* zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    unsigned int* zT_509;
    zT_21D3708C_U32ToU32Map* zT_515;
    unsigned int zT_516;
    unsigned int zT_517;
    unsigned int* zT_519;
    zT_38C12417_SemanticAnalyzer* zT_521;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    unsigned int* zT_525;
    zT_38C12417_SemanticAnalyzer* zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    unsigned int zT_530;
    unsigned int* zT_531;
    unsigned int zT_533 = 0;
    int zT_534;
    unsigned int zT_535;
    unsigned int zT_540;
    zT_38C12417_SemanticAnalyzer* zT_542;
    zT_38C12417_SemanticAnalyzer* zT_546;
    unsigned int zT_547;
    unsigned int* zT_548;
    unsigned int zT_550 = 0;
    zT_38C12417_SemanticAnalyzer* zT_551;
    zT_21D3708C_U32ToU32Map* zT_554;
    unsigned int zT_555;
    unsigned int zT_556;
    unsigned int* zT_558;
    int zT_560;
    unsigned int zT_561;
    char* zT_563;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_564;
    unsigned int zT_565;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_566;
    unsigned int zT_567;
    unsigned int zT_569;
    zT_8F083A69_Slice_zT_0B42B2F8_u fne;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee_node;
    unsigned int direct_ret;
    unsigned int decl_cap;
    zT_E282FB55_Opt_808 sym;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u xf;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_22A7C88B_AstNode dn;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 rt;
    unsigned int rnt_val;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u brnt_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfnr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u drfb_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_fc;
    unsigned int fc_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1r_m;
    zT_3CB0179A_Slice_zT_05F374B1_u args;
    unsigned char has_params;
    unsigned short pcount;
    unsigned int pstart;
    unsigned int callee_type;
    zT_BAEE192E_Opt_10 ft;
    unsigned int ai;
    unsigned int ftid;
    zT_8F083A69_Slice_zT_0B42B2F8_u sfm;
    zT_D155D06D_Type ft_ty;
    zT_0317B1D5_FnPayload ftp;
    unsigned int expected;
    unsigned int cpp_key;
    unsigned int dxc_at;
    unsigned int cpp_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn2;
    zT_D155D06D_Type callee_ty;
    zT_112BF819_PtrPayload cptr_pp;
    zT_D155D06D_Type cptr_pointee;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ck_m;
    zT_3CB0179A_Slice_zT_05F374B1_u fn3_args;
    unsigned int fn3_i;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4a;
    zT_0317B1D5_FnPayload fnp;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4b;
    unsigned int pcount_1;
    unsigned int pstart_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4c;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4d;
    unsigned char is_var;
    unsigned int fixed;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4e;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4y_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4f;
    unsigned int param_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_am;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4g;
    unsigned int arg_type;
    unsigned int vi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4_rm;
    unsigned int varg_type;
    zT_3 = "FNE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fne = zT_4;
    zT_6 = fne;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    callee_node = zT_17;
    zT_19 = 0;
    direct_ret = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    decl_cap = zT_22;
    zT_23 = callee_node.kind;
    if ((int)(zT_23 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_29 = self->symbols;
    zT_30 = self->module_id;
    zT_34 = self->store;
    zT_35 = node.child_0;
    zT_38 = zF_53458827_astStoreIdentifier(zT_34, zT_35);
    zT_31 = zT_38;
    zT_39 = zF_A398987E_symbolRegistryQuali(zT_29, zT_30, zT_31);
    sym = zT_39;
    zT_40 = sym.has_value;
    if (zT_40) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    if ((int)(direct_ret != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    s = sym.value;
    zT_43 = "XF\n";
    zT_45 = 3;
    zT_44.ptr = zT_43;
    zT_44.len = zT_45;
    xf = zT_44;
    zT_46 = xf;
    zF_48AC7B3A_markerWrite(zT_46);
    zT_47 = s->decl_node;
    decl_cap = zT_47;
    zT_48 = s->type_id;
    if ((int)(zT_48 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_146 = "xS\n";
    zT_148 = 3;
    zT_147.ptr = zT_146;
    zT_147.len = zT_148;
    xs = zT_147;
    zT_149 = xs;
    zF_48AC7B3A_markerWrite(zT_149);
    goto z_bb_4;
    z_bb_6:
    zT_51 = self->type_table;
    zT_52 = node.child_0;
    zT_53 = s->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_51, zT_52, zT_53);
    goto z_bb_7;
    z_bb_7:
    zT_57 = s->kind;
    if ((int)(zT_57 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_63 = s->decl_node;
    zT_62 = zT_63 != (unsigned int)(0);
    goto z_bb_10;
    z_bb_9:
    zT_62 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_62) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_67 = self->store;
    zT_68 = s->decl_node;
    zT_71 = zF_FCDD1D35_astStoreNodeAt(zT_67, zT_68);
    dn = zT_71;
    zT_72 = dn.kind;
    if ((int)(zT_72 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_4;
    z_bb_13:
    zT_78 = self->store;
    zT_79 = zT_78->fn_protos;
    zT_80 = zT_79.items;
    zT_81 = self->store;
    zT_82 = s->decl_node;
    zT_85 = zF_8BA26B9E_astStoreNodePayload(zT_81, zT_82);
    zT_86 = (unsigned int)zT_85;
    zT_87 = zT_80[zT_86];
    proto = zT_87;
    zT_88 = proto.return_type_node;
    if ((int)(zT_88 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_92 = self->type_table;
    zT_93 = proto.return_type_node;
    zT_96 = zF_999DCF51_resolvedTypeTableGe(zT_92, zT_93);
    rt = zT_96;
    zT_98 = rt.has_value;
    if (zT_98) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    t = rt.value;
    zT_99 = t;
    goto z_bb_19;
    z_bb_18:
    zT_99 = 0;
    goto z_bb_19;
    z_bb_19:
    rnt_val = zT_99;
    zT_103 = "BR:rnt";
    zT_105 = 6;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    brnt_m = zT_104;
    zT_106 = brnt_m;
    zT_107 = rnt_val;
    zF_C914CB83_markerWriteInt(zT_106, zT_107);
    zT_108 = rt.has_value;
    if (zT_108) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    t = rt.value;
    direct_ret = t;
    goto z_bb_21;
    z_bb_21:
    zT_140 = "BR:fnr";
    zT_142 = 6;
    zT_141.ptr = zT_140;
    zT_141.len = zT_142;
    brfnr_m = zT_141;
    zT_143 = brfnr_m;
    zT_144 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_143, zT_144);
    goto z_bb_16;
    z_bb_22:
    zT_111 = "DRETFB:n";
    zT_113 = 8;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    drfb_m = zT_112;
    zT_114 = drfb_m;
    zT_115 = node_idx;
    zF_C914CB83_markerWriteInt(zT_114, zT_115);
    zT_118 = self->store;
    zT_117.store = zT_118;
    zT_119 = self->registry;
    zT_117.typereg = zT_119;
    zT_120 = self->symbols;
    zT_117.symbol_reg = zT_120;
    zT_121 = self->interner;
    zT_117.interner = zT_121;
    zT_122 = s->module_id;
    zT_117.module_id = zT_122;
    tre_env_fc = zT_117;
    zT_124 = &tre_env_fc;
    zT_125 = proto.return_type_node;
    zT_130 = zF_F2107C15_resolveTypeExprFull(zT_124, zT_125, (unsigned int)(0));
    fc_rt = zT_130;
    zT_132 = "BR:fc";
    zT_134 = 5;
    zT_133.ptr = zT_132;
    zT_133.len = zT_134;
    brfc_m = zT_133;
    zT_135 = brfc_m;
    zT_136 = fc_rt;
    zF_C914CB83_markerWriteInt(zT_135, zT_136);
    if ((int)(fc_rt != (unsigned int)(18))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    direct_ret = fc_rt;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_153 = "FN1\n";
    zT_155 = 4;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    fn1 = zT_154;
    zT_156 = fn1;
    zF_48AC7B3A_markerWrite(zT_156);
    zT_158 = "FN1:R";
    zT_160 = 5;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    fn1r_m = zT_159;
    zT_161 = fn1r_m;
    zT_162 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_161, zT_162);
    zT_164 = self->store;
    zT_165 = node_idx;
    zT_167 = zF_850FDF81_astStoreNodeExtraCh(zT_164, zT_165);
    args = zT_167;
    zT_169 = 0;
    has_params = zT_169;
    zT_171 = 0;
    pcount = zT_171;
    zT_173 = 0;
    pstart = zT_173;
    zT_174 = 0;
    if ((int)(decl_cap != (unsigned int)zT_174)) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_278 = self;
    zT_279 = node.child_0;
    zT_281 = zF_54F95822_semanticAnalyzerRes(zT_278, zT_279);
    callee_type = zT_281;
    if ((int)(callee_type == (unsigned int)(0))) goto z_bb_50; else goto z_bb_51;
    z_bb_27:
    zT_177 = self->type_table;
    zT_178 = decl_cap;
    zT_180 = zF_999DCF51_resolvedTypeTableGe(zT_177, zT_178);
    ft = zT_180;
    zT_181 = ft.has_value;
    if (zT_181) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_208 = 0;
    zT_209 = (unsigned int)zT_208;
    ai = zT_209;
    goto z_bb_33;
    z_bb_29:
    ftid = ft.value;
    zT_184 = "SF:H\n";
    zT_186 = 5;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    sfm = zT_185;
    zT_187 = sfm;
    zF_48AC7B3A_markerWrite(zT_187);
    zT_189 = self->registry;
    zT_190 = zT_189->types_items;
    zT_191 = (unsigned int)ftid;
    zT_192 = zT_190[zT_191];
    ft_ty = zT_192;
    zT_193 = ft_ty.kind;
    if ((int)(zT_193 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_199 = self->registry;
    zT_200 = zT_199->fn_items;
    zT_201 = ft_ty.payload_idx;
    zT_202 = (unsigned int)zT_201;
    zT_203 = zT_200[zT_202];
    ftp = zT_203;
    zT_204 = ftp.params_count;
    pcount = zT_204;
    zT_205 = ftp.params_start;
    pstart = zT_205;
    zT_206 = 1;
    has_params = zT_206;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_211 = args.len;
    if ((int)(ai < zT_211)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_214 = 0;
    expected = zT_214;
    if ((int)(has_params != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_273 = self->type_table;
    zT_274 = node_idx;
    zT_275 = direct_ret;
    zF_19B4A07D_resolvedTypeTableSe(zT_273, zT_274, zT_275);
    return direct_ret;
    z_bb_36:
    zT_271 = 1;
    zT_272 = ai + zT_271;
    ai = zT_272;
    goto z_bb_33;
    z_bb_37:
    zT_217 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_39;
    z_bb_38:
    zT_217 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_217) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_225 = (unsigned int)((unsigned int)((unsigned int)decl_cap) << (unsigned int)(16)) | (unsigned int)((unsigned int)ai);
    cpp_key = zT_225;
    zT_226 = 18;
    expected = zT_226;
    zT_227 = self->call_param_map;
    zT_228 = cpp_key;
    zT_230 = zF_F3EE5998_u32ToU32MapGet(zT_227, zT_228);
    zT_231 = zT_230.has_value;
    if (zT_231) goto z_bb_42; else goto z_bb_44;
    z_bb_41:
    zT_244 = self;
    zT_245 = expected;
    zF_9665A229_pushExpectedType(zT_244, zT_245);
    zT_247 = self;
    zT_249 = args.ptr;
    zT_248 = zT_249[ai];
    zT_251 = zF_54F95822_semanticAnalyzerRes(zT_247, zT_248);
    dxc_at = zT_251;
    zT_252 = self;
    zF_BC478E78_popExpectedType(zT_252);
    if ((int)(has_params != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_42:
    cpp_v = zT_230.value;
    expected = cpp_v;
    goto z_bb_43;
    z_bb_43:
    zT_238 = self->call_arg_types;
    zT_242 = args.ptr;
    zT_239 = zT_242[ai];
    zT_240 = expected;
    zF_26476265_u32ToU32MapPut(zT_238, zT_239, zT_240);
    goto z_bb_41;
    z_bb_44:
    zT_233 = self->registry;
    zT_234 = zT_233->xt_items;
    zT_236 = (unsigned int)((unsigned int)pstart) + ai;
    zT_237 = zT_234[zT_236];
    expected = zT_237;
    goto z_bb_43;
    z_bb_45:
    zT_255 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_47;
    z_bb_46:
    zT_255 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_255) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_258 = self;
    zT_262 = args.ptr;
    zT_259 = zT_262[ai];
    zT_264 = self;
    zT_268 = args.ptr;
    zT_265 = zT_268[ai];
    zT_266 = expected;
    zT_267 = dxc_at;
    zT_270 = zF_FFC95E09_errLitSrcType(zT_264, zT_265, zT_266, zT_267);
    zT_260 = zT_270;
    zT_261 = expected;
    zF_DF7434EB_tryRecordCoercion(zT_258, zT_259, zT_260, zT_261);
    goto z_bb_49;
    z_bb_49:
    goto z_bb_36;
    z_bb_50:
    zT_285 = "FN2\n";
    zT_287 = 4;
    zT_286.ptr = zT_285;
    zT_286.len = zT_287;
    fn2 = zT_286;
    zT_288 = fn2;
    zF_48AC7B3A_markerWrite(zT_288);
    return (unsigned int)(1);
    z_bb_51:
    zT_291 = self->registry;
    zT_292 = zT_291->types_items;
    zT_293 = (unsigned int)callee_type;
    zT_294 = zT_292[zT_293];
    callee_ty = zT_294;
    zT_295 = callee_ty.kind;
    if ((int)(zT_295 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_301 = self->registry;
    zT_302 = zT_301->ptr_items;
    zT_303 = callee_ty.payload_idx;
    zT_304 = (unsigned int)zT_303;
    zT_305 = zT_302[zT_304];
    cptr_pp = zT_305;
    zT_307 = self->registry;
    zT_308 = zT_307->types_items;
    zT_309 = cptr_pp.base;
    zT_310 = (unsigned int)zT_309;
    zT_311 = zT_308[zT_310];
    cptr_pointee = zT_311;
    zT_312 = cptr_pointee.kind;
    if ((int)(zT_312 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_322 = callee_ty.kind;
    if ((int)(zT_322 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    zT_317 = cptr_pp.base;
    callee_type = zT_317;
    zT_318 = self->registry;
    zT_319 = zT_318->types_items;
    zT_320 = (unsigned int)callee_type;
    zT_321 = zT_319[zT_320];
    callee_ty = zT_321;
    goto z_bb_55;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_328 = "FN3:N";
    zT_330 = 5;
    zT_329.ptr = zT_328;
    zT_329.len = zT_330;
    fn3 = zT_329;
    zT_331 = fn3;
    zT_332 = node_idx;
    zF_C914CB83_markerWriteInt(zT_331, zT_332);
    zT_334 = "FN3:T";
    zT_336 = 5;
    zT_335.ptr = zT_334;
    zT_335.len = zT_336;
    fn3_ct_m = zT_335;
    zT_337 = fn3_ct_m;
    zT_338 = callee_type;
    zF_C914CB83_markerWriteInt(zT_337, zT_338);
    zT_340 = "FN3:K";
    zT_342 = 5;
    zT_341.ptr = zT_340;
    zT_341.len = zT_342;
    fn3_ck_m = zT_341;
    zT_343 = fn3_ck_m;
    zT_345 = callee_ty.kind;
    zF_C914CB83_markerWriteInt(zT_343, (unsigned int)((unsigned int)zT_345));
    zT_348 = self->store;
    zT_349 = node_idx;
    zT_351 = zF_850FDF81_astStoreNodeExtraCh(zT_348, zT_349);
    fn3_args = zT_351;
    zT_353 = 0;
    fn3_i = zT_353;
    goto z_bb_58;
    z_bb_57:
    zT_370 = "FN4a\n";
    zT_372 = 5;
    zT_371.ptr = zT_370;
    zT_371.len = zT_372;
    fn4a = zT_371;
    zT_373 = fn4a;
    zF_48AC7B3A_markerWrite(zT_373);
    zT_375 = self->registry;
    zT_376 = zT_375->fn_items;
    zT_377 = callee_ty.payload_idx;
    zT_378 = (unsigned int)zT_377;
    zT_379 = zT_376[zT_378];
    fnp = zT_379;
    zT_381 = "FN4b\n";
    zT_383 = 5;
    zT_382.ptr = zT_381;
    zT_382.len = zT_383;
    fn4b = zT_382;
    zT_384 = fn4b;
    zF_48AC7B3A_markerWrite(zT_384);
    zT_386 = fnp.params_count;
    zT_387 = (unsigned int)zT_386;
    pcount_1 = zT_387;
    zT_389 = fnp.params_start;
    zT_390 = (unsigned int)zT_389;
    pstart_2 = zT_390;
    zT_392 = "FN4c\n";
    zT_394 = 5;
    zT_393.ptr = zT_392;
    zT_393.len = zT_394;
    fn4c = zT_393;
    zT_395 = fn4c;
    zF_48AC7B3A_markerWrite(zT_395);
    zT_397 = self->store;
    zT_398 = node_idx;
    zT_400 = zF_850FDF81_astStoreNodeExtraCh(zT_397, zT_398);
    args = zT_400;
    zT_402 = "FN4d\n";
    zT_404 = 5;
    zT_403.ptr = zT_402;
    zT_403.len = zT_404;
    fn4d = zT_403;
    zT_405 = fn4d;
    zF_48AC7B3A_markerWrite(zT_405);
    zT_407 = 0;
    is_var = zT_407;
    zT_408 = fnp.flags_packed;
    if ((int)((unsigned char)(zT_408 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_58:
    zT_355 = fn3_args.len;
    if ((int)(fn3_i < zT_355)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_357 = self;
    zF_9665A229_pushExpectedType(zT_357, (unsigned int)(0));
    zT_360 = self;
    zT_362 = fn3_args.ptr;
    zT_361 = zT_362[fn3_i];
    zT_364 = zF_54F95822_semanticAnalyzerRes(zT_360, zT_361);
    (void)zT_364;
    zT_365 = self;
    zF_BC478E78_popExpectedType(zT_365);
    goto z_bb_61;
    z_bb_60:
    return (unsigned int)(1);
    z_bb_61:
    zT_367 = fn3_i + (unsigned int)(1);
    fn3_i = zT_367;
    goto z_bb_58;
    z_bb_62:
    zT_413 = 1;
    is_var = zT_413;
    goto z_bb_63;
    z_bb_63:
    fixed = pcount_1;
    if ((int)(is_var != (unsigned char)(0))) goto z_bb_64; else goto z_bb_66;
    z_bb_64:
    zT_418 = args.len;
    if ((int)(zT_418 < fixed)) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    zT_426 = 0;
    zT_427 = (unsigned int)zT_426;
    ai = zT_427;
    zT_429 = "FN4e\n";
    zT_431 = 5;
    zT_430.ptr = zT_429;
    zT_430.len = zT_431;
    fn4e = zT_430;
    zT_432 = fn4e;
    zF_48AC7B3A_markerWrite(zT_432);
    zT_434 = "FN4x:X";
    zT_436 = 6;
    zT_435.ptr = zT_434;
    zT_435.len = zT_436;
    fn4x_m = zT_435;
    zT_437 = fn4x_m;
    zT_439 = self->registry;
    zT_440 = zT_439->xt_len;
    zF_C914CB83_markerWriteInt(zT_437, (unsigned int)((unsigned int)zT_440));
    zT_443 = "FN4y:P";
    zT_445 = 6;
    zT_444.ptr = zT_443;
    zT_444.len = zT_445;
    fn4y_m = zT_444;
    zT_446 = fn4y_m;
    zF_C914CB83_markerWriteInt(zT_446, (unsigned int)((unsigned int)pstart_2));
    goto z_bb_71;
    z_bb_66:
    zT_422 = args.len;
    if ((int)(zT_422 != pcount_1)) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    zT_420 = fnp.return_type;
    return zT_420;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_424 = fnp.return_type;
    return zT_424;
    z_bb_70:
    goto z_bb_65;
    z_bb_71:
    if ((int)(ai < fixed)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_451 = "FN4f\n";
    zT_453 = 5;
    zT_452.ptr = zT_451;
    zT_452.len = zT_453;
    fn4f = zT_452;
    zT_454 = fn4f;
    zF_48AC7B3A_markerWrite(zT_454);
    zT_456 = self->registry;
    zT_457 = zT_456->xt_items;
    zT_458 = pstart_2 + ai;
    zT_459 = zT_457[zT_458];
    param_type = zT_459;
    zT_460 = self->call_arg_types;
    zT_464 = args.ptr;
    zT_461 = zT_464[ai];
    zT_462 = param_type;
    zF_26476265_u32ToU32MapPut(zT_460, zT_461, zT_462);
    zT_467 = "PTM:A";
    zT_469 = 5;
    zT_468.ptr = zT_467;
    zT_468.len = zT_469;
    ptm_am = zT_468;
    zT_470 = ptm_am;
    zF_C914CB83_markerWriteInt(zT_470, (unsigned int)((unsigned int)ai));
    zT_474 = "PTM:T";
    zT_476 = 5;
    zT_475.ptr = zT_474;
    zT_475.len = zT_476;
    ptm_tm = zT_475;
    zT_477 = ptm_tm;
    zT_478 = param_type;
    zF_C914CB83_markerWriteInt(zT_477, zT_478);
    zT_480 = "PTM:N";
    zT_482 = 5;
    zT_481.ptr = zT_480;
    zT_481.len = zT_482;
    ptm_nm = zT_481;
    zT_483 = ptm_nm;
    zT_485 = args.ptr;
    zT_484 = zT_485[ai];
    zF_C914CB83_markerWriteInt(zT_483, zT_484);
    zT_488 = "FN4g\n";
    zT_490 = 5;
    zT_489.ptr = zT_488;
    zT_489.len = zT_490;
    fn4g = zT_489;
    zT_491 = fn4g;
    zF_48AC7B3A_markerWrite(zT_491);
    zT_492 = self;
    zT_493 = param_type;
    zF_9665A229_pushExpectedType(zT_492, zT_493);
    zT_495 = self;
    zT_497 = args.ptr;
    zT_496 = zT_497[ai];
    zT_499 = zF_54F95822_semanticAnalyzerRes(zT_495, zT_496);
    arg_type = zT_499;
    zT_500 = self;
    zF_BC478E78_popExpectedType(zT_500);
    if ((int)(param_type == (unsigned int)(18))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    if ((int)(is_var != (unsigned char)(0))) goto z_bb_83; else goto z_bb_84;
    z_bb_74:
    zT_534 = 1;
    zT_535 = ai + zT_534;
    ai = zT_535;
    goto z_bb_71;
    z_bb_75:
    if ((int)(arg_type != (unsigned int)(18))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    if ((int)(param_type == (unsigned int)(1))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_505 = self->call_arg_types;
    zT_509 = args.ptr;
    zT_506 = zT_509[ai];
    zT_507 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_505, zT_506, zT_507);
    goto z_bb_78;
    z_bb_78:
    goto z_bb_76;
    z_bb_79:
    if ((int)(arg_type != (unsigned int)(18))) goto z_bb_81; else goto z_bb_82;
    z_bb_80:
    zT_521 = self;
    zT_525 = args.ptr;
    zT_522 = zT_525[ai];
    zT_527 = self;
    zT_531 = args.ptr;
    zT_528 = zT_531[ai];
    zT_529 = param_type;
    zT_530 = arg_type;
    zT_533 = zF_FFC95E09_errLitSrcType(zT_527, zT_528, zT_529, zT_530);
    zT_523 = zT_533;
    zT_524 = param_type;
    zF_DF7434EB_tryRecordCoercion(zT_521, zT_522, zT_523, zT_524);
    goto z_bb_74;
    z_bb_81:
    zT_515 = self->call_arg_types;
    zT_519 = args.ptr;
    zT_516 = zT_519[ai];
    zT_517 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_515, zT_516, zT_517);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_80;
    z_bb_83:
    vi = fixed;
    goto z_bb_85;
    z_bb_84:
    zT_563 = "FN4:R";
    zT_565 = 5;
    zT_564.ptr = zT_563;
    zT_564.len = zT_565;
    fn4_rm = zT_564;
    zT_566 = fn4_rm;
    zT_567 = fnp.return_type;
    zF_C914CB83_markerWriteInt(zT_566, zT_567);
    zT_569 = fnp.return_type;
    return zT_569;
    z_bb_85:
    zT_540 = args.len;
    if ((int)(vi < zT_540)) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_542 = self;
    zF_9665A229_pushExpectedType(zT_542, (unsigned int)(0));
    zT_546 = self;
    zT_548 = args.ptr;
    zT_547 = zT_548[vi];
    zT_550 = zF_54F95822_semanticAnalyzerRes(zT_546, zT_547);
    varg_type = zT_550;
    zT_551 = self;
    zF_BC478E78_popExpectedType(zT_551);
    if ((int)(varg_type != (unsigned int)(18))) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    goto z_bb_84;
    z_bb_88:
    zT_560 = 1;
    zT_561 = vi + zT_560;
    vi = zT_561;
    goto z_bb_85;
    z_bb_89:
    zT_554 = self->call_arg_types;
    zT_558 = args.ptr;
    zT_555 = zT_558[vi];
    zT_556 = varg_type;
    zF_26476265_u32ToU32MapPut(zT_554, zT_555, zT_556);
    goto z_bb_90;
    z_bb_90:
    goto z_bb_88;
}

/* semanticAnalyzerResolveTryExpr */
unsigned int zF_B78F27CD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_42C2D6BF_EUPayload* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_42C2D6BF_EUPayload zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    zT_42C2D6BF_EUPayload eu;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((int)(zT_23 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(1);
    z_bb_7:
    zT_30 = self->registry;
    zT_31 = zT_30->eu_items;
    zT_32 = ty.payload_idx;
    zT_33 = (unsigned int)zT_32;
    zT_34 = zT_31[zT_33];
    eu = zT_34;
    zT_35 = eu.payload;
    return zT_35;
}

/* semanticAnalyzerResolveOrelseExpr */
unsigned int zF_B36961FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_28;
    unsigned int zT_29;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    zT_D155D06D_Type zT_45;
    zT_33EF6BFB_TypeKind zT_47;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_0B10E8E9_OptionalPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_0B10E8E9_OptionalPayload zT_57;
    unsigned int zT_58;
    zT_338B7C76_TypeRegistry* zT_60;
    unsigned int zT_61;
    unsigned int zT_63 = 0;
    zT_66E7D2EF_CoercionTable* zT_64;
    unsigned int zT_65;
    unsigned int zT_67;
    zT_33EF6BFB_TypeKind zT_74;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_0B10E8E9_OptionalPayload* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_0B10E8E9_OptionalPayload zT_85;
    zT_66E7D2EF_CoercionTable* zT_86;
    unsigned int zT_87;
    unsigned int zT_89;
    unsigned int zT_96;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    zT_38C12417_SemanticAnalyzer* zT_103;
    unsigned int zT_104;
    unsigned int zT_106 = 0;
    zT_38C12417_SemanticAnalyzer* zT_107;
    int zT_110;
    zT_38C12417_SemanticAnalyzer* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_119;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    unsigned int expected;
    zT_D155D06D_Type oe_et;
    unsigned int payload_type;
    zT_0B10E8E9_OptionalPayload oe_opt;
    unsigned int opt_target;
    zT_0B10E8E9_OptionalPayload opt;
    unsigned int rhs_result;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((int)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_29 = self->expected_type_stack_len;
    zT_28 = zT_29 > (unsigned int)(0);
    goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_28) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = self->expected_type_stack_items;
    zT_34 = self->expected_type_stack_len;
    zT_37 = (unsigned int)(unsigned int)(zT_34 - (unsigned int)(1));
    zT_38 = zT_33[zT_37];
    expected = zT_38;
    if ((int)(expected != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_74 = ty.kind;
    if ((int)(zT_74 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_11:
    zT_42 = self->registry;
    zT_43 = zT_42->types_items;
    zT_44 = (unsigned int)expected;
    zT_45 = zT_43[zT_44];
    oe_et = zT_45;
    payload_type = expected;
    zT_47 = oe_et.kind;
    if ((int)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_53 = self->registry;
    zT_54 = zT_53->opt_items;
    zT_55 = oe_et.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    oe_opt = zT_57;
    zT_58 = oe_opt.payload;
    payload_type = zT_58;
    goto z_bb_14;
    z_bb_14:
    zT_60 = self->registry;
    zT_61 = payload_type;
    zT_63 = zF_74A7234F_typeRegistryGetOrCr(zT_60, zT_61);
    opt_target = zT_63;
    zT_64 = self->coercion_table;
    zT_65 = node.child_0;
    zT_67 = opt_target;
    zF_D21AE60A_coercionTableAdd(zT_64, zT_65, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional_null), zT_67);
    return payload_type;
    z_bb_15:
    return (unsigned int)(1);
    z_bb_16:
    zT_81 = self->registry;
    zT_82 = zT_81->opt_items;
    zT_83 = ty.payload_idx;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zT_82[zT_84];
    opt = zT_85;
    zT_86 = self->coercion_table;
    zT_87 = node.child_0;
    zT_89 = opt.payload;
    zF_D21AE60A_coercionTableAdd(zT_86, zT_87, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_89);
    zT_96 = node.child_1;
    if ((int)(zT_96 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_99 = self;
    zT_100 = opt.payload;
    zF_9665A229_pushExpectedType(zT_99, zT_100);
    zT_103 = self;
    zT_104 = node.child_1;
    zT_106 = zF_54F95822_semanticAnalyzerRes(zT_103, zT_104);
    rhs_result = zT_106;
    zT_107 = self;
    zF_BC478E78_popExpectedType(zT_107);
    if ((int)(rhs_result != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_119 = opt.payload;
    return zT_119;
    z_bb_19:
    zT_110 = rhs_result != (unsigned int)(1);
    goto z_bb_21;
    z_bb_20:
    zT_110 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_110) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_113 = self;
    zT_114 = node.child_1;
    zT_115 = rhs_result;
    zT_116 = opt.payload;
    zF_DF7434EB_tryRecordCoercion(zT_113, zT_114, zT_115, zT_116);
    goto z_bb_23;
    z_bb_23:
    goto z_bb_18;
}

/* semanticAnalyzerResolveIfExpr */
unsigned int zF_8B8EE70D_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    unsigned int zT_14;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8EED1867_ResolvedTypeTable* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    zT_8EED1867_ResolvedTypeTable* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    zT_8EED1867_ResolvedTypeTable* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    zT_8EED1867_ResolvedTypeTable* zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    int zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    unsigned int zT_115;
    int zT_117 = 0;
    char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    char* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129;
    char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_66E7D2EF_CoercionTable* zT_135;
    unsigned int zT_136;
    unsigned int zT_138;
    zT_8EED1867_ResolvedTypeTable* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    int zT_150;
    zT_338B7C76_TypeRegistry* zT_151;
    unsigned int zT_152;
    int zT_154 = 0;
    char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    zT_66E7D2EF_CoercionTable* zT_172;
    unsigned int zT_173;
    unsigned int zT_175;
    zT_8EED1867_ResolvedTypeTable* zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    char* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    zT_8EED1867_ResolvedTypeTable* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    char* zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned int zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    unsigned int zT_221;
    char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    zT_8EED1867_ResolvedTypeTable* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    char* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236;
    char* zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    zT_8EED1867_ResolvedTypeTable* zT_242;
    unsigned int zT_243;
    zT_22A7C88B_AstNode node;
    unsigned int then_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_nl;
    unsigned int else_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u siffm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sifftm;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_7, zT_8);
    zT_10 = self;
    zT_11 = node.child_1;
    zT_13 = zF_54F95822_semanticAnalyzerRes(zT_10, zT_11);
    then_type = zT_13;
    zT_14 = node.child_2;
    if ((int)(zT_14 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = "SIF:0N";
    zT_20 = 6;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    sif_m = zT_19;
    zT_21 = sif_m;
    zT_22 = node_idx;
    zF_C914CB83_markerWriteInt(zT_21, zT_22);
    zT_24 = "T";
    zT_26 = 1;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    sif_tm = zT_25;
    zT_27 = sif_tm;
    zT_28 = then_type;
    zF_C914CB83_markerWriteInt(zT_27, zT_28);
    zT_30 = " ";
    zT_32 = 1;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    sif_nl = zT_31;
    zT_33 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_34 = self->type_table;
    zT_35 = node_idx;
    zT_36 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_34, zT_35, zT_36);
    return then_type;
    z_bb_2:
    zT_39 = self;
    zT_40 = node.child_2;
    zT_42 = zF_54F95822_semanticAnalyzerRes(zT_39, zT_40);
    else_type = zT_42;
    if ((int)(then_type == else_type)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_45 = "SIF:1N";
    zT_47 = 6;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    sif_m = zT_46;
    zT_48 = sif_m;
    zT_49 = node_idx;
    zF_C914CB83_markerWriteInt(zT_48, zT_49);
    zT_51 = "T";
    zT_53 = 1;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    sif_tm = zT_52;
    zT_54 = sif_tm;
    zT_55 = then_type;
    zF_C914CB83_markerWriteInt(zT_54, zT_55);
    zT_57 = " ";
    zT_59 = 1;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    sif_nl = zT_58;
    zT_60 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_60);
    zT_61 = self->type_table;
    zT_62 = node_idx;
    zT_63 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_61, zT_62, zT_63);
    return then_type;
    z_bb_4:
    if ((int)(then_type == (unsigned int)(3))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_68 = "SIF:2N";
    zT_70 = 6;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    sif2m = zT_69;
    zT_71 = sif2m;
    zT_72 = node_idx;
    zF_C914CB83_markerWriteInt(zT_71, zT_72);
    zT_74 = "T";
    zT_76 = 1;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    sif2tm = zT_75;
    zT_77 = sif2tm;
    zT_78 = else_type;
    zF_C914CB83_markerWriteInt(zT_77, zT_78);
    zT_80 = " ";
    zT_82 = 1;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    sif2nl = zT_81;
    zT_83 = sif2nl;
    zF_48AC7B3A_markerWrite(zT_83);
    zT_84 = self->type_table;
    zT_85 = node_idx;
    zT_86 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_84, zT_85, zT_86);
    return else_type;
    z_bb_6:
    if ((int)(else_type == (unsigned int)(3))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_91 = "SIF:3N";
    zT_93 = 6;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    sif3m = zT_92;
    zT_94 = sif3m;
    zT_95 = node_idx;
    zF_C914CB83_markerWriteInt(zT_94, zT_95);
    zT_97 = "T";
    zT_99 = 1;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    sif3tm = zT_98;
    zT_100 = sif3tm;
    zT_101 = then_type;
    zF_C914CB83_markerWriteInt(zT_100, zT_101);
    zT_103 = " ";
    zT_105 = 1;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    sif3nl = zT_104;
    zT_106 = sif3nl;
    zF_48AC7B3A_markerWrite(zT_106);
    zT_107 = self->type_table;
    zT_108 = node_idx;
    zT_109 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_107, zT_108, zT_109);
    return then_type;
    z_bb_8:
    if ((int)(then_type == (unsigned int)(19))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_114 = self->registry;
    zT_115 = else_type;
    zT_117 = zF_3087E0A5_typeRegistryIsNumer(zT_114, zT_115);
    zT_113 = zT_117;
    goto z_bb_11;
    z_bb_10:
    zT_113 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_113) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_119 = "SIF:4N";
    zT_121 = 6;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    sif4m = zT_120;
    zT_122 = sif4m;
    zT_123 = node_idx;
    zF_C914CB83_markerWriteInt(zT_122, zT_123);
    zT_125 = "T";
    zT_127 = 1;
    zT_126.ptr = zT_125;
    zT_126.len = zT_127;
    sif4tm = zT_126;
    zT_128 = sif4tm;
    zT_129 = else_type;
    zF_C914CB83_markerWriteInt(zT_128, zT_129);
    zT_131 = " ";
    zT_133 = 1;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    sif4nl = zT_132;
    zT_134 = sif4nl;
    zF_48AC7B3A_markerWrite(zT_134);
    zT_135 = self->coercion_table;
    zT_136 = node.child_1;
    zT_138 = else_type;
    zF_D21AE60A_coercionTableAdd(zT_135, zT_136, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_138);
    zT_144 = self->type_table;
    zT_145 = node_idx;
    zT_146 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_144, zT_145, zT_146);
    return else_type;
    z_bb_13:
    if ((int)(else_type == (unsigned int)(19))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_151 = self->registry;
    zT_152 = then_type;
    zT_154 = zF_3087E0A5_typeRegistryIsNumer(zT_151, zT_152);
    zT_150 = zT_154;
    goto z_bb_16;
    z_bb_15:
    zT_150 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_150) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_156 = "SIF:5N";
    zT_158 = 6;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    sif5m = zT_157;
    zT_159 = sif5m;
    zT_160 = node_idx;
    zF_C914CB83_markerWriteInt(zT_159, zT_160);
    zT_162 = "T";
    zT_164 = 1;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    sif5tm = zT_163;
    zT_165 = sif5tm;
    zT_166 = then_type;
    zF_C914CB83_markerWriteInt(zT_165, zT_166);
    zT_168 = " ";
    zT_170 = 1;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    sif5nl = zT_169;
    zT_171 = sif5nl;
    zF_48AC7B3A_markerWrite(zT_171);
    zT_172 = self->coercion_table;
    zT_173 = node.child_2;
    zT_175 = then_type;
    zF_D21AE60A_coercionTableAdd(zT_172, zT_173, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_175);
    zT_181 = self->type_table;
    zT_182 = node_idx;
    zT_183 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_181, zT_182, zT_183);
    return then_type;
    z_bb_18:
    if ((int)(then_type == (unsigned int)(1))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_188 = "SIF:6N";
    zT_190 = 6;
    zT_189.ptr = zT_188;
    zT_189.len = zT_190;
    sif6m = zT_189;
    zT_191 = sif6m;
    zT_192 = node_idx;
    zF_C914CB83_markerWriteInt(zT_191, zT_192);
    zT_194 = "T";
    zT_196 = 1;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    sif6tm = zT_195;
    zT_197 = sif6tm;
    zT_198 = else_type;
    zF_C914CB83_markerWriteInt(zT_197, zT_198);
    zT_200 = " ";
    zT_202 = 1;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    sif6nl = zT_201;
    zT_203 = sif6nl;
    zF_48AC7B3A_markerWrite(zT_203);
    zT_204 = self->type_table;
    zT_205 = node_idx;
    zT_206 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_204, zT_205, zT_206);
    return else_type;
    z_bb_20:
    if ((int)(else_type == (unsigned int)(1))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_211 = "SIF:7N";
    zT_213 = 6;
    zT_212.ptr = zT_211;
    zT_212.len = zT_213;
    sif7m = zT_212;
    zT_214 = sif7m;
    zT_215 = node_idx;
    zF_C914CB83_markerWriteInt(zT_214, zT_215);
    zT_217 = "T";
    zT_219 = 1;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    sif7tm = zT_218;
    zT_220 = sif7tm;
    zT_221 = then_type;
    zF_C914CB83_markerWriteInt(zT_220, zT_221);
    zT_223 = " ";
    zT_225 = 1;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    sif7nl = zT_224;
    zT_226 = sif7nl;
    zF_48AC7B3A_markerWrite(zT_226);
    zT_227 = self->type_table;
    zT_228 = node_idx;
    zT_229 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_227, zT_228, zT_229);
    return then_type;
    z_bb_22:
    zT_232 = "SIF:FN";
    zT_234 = 6;
    zT_233.ptr = zT_232;
    zT_233.len = zT_234;
    siffm = zT_233;
    zT_235 = siffm;
    zT_236 = node_idx;
    zF_C914CB83_markerWriteInt(zT_235, zT_236);
    zT_238 = "\n";
    zT_240 = 1;
    zT_239.ptr = zT_238;
    zT_239.len = zT_240;
    sifftm = zT_239;
    zT_241 = sifftm;
    zF_48AC7B3A_markerWrite(zT_241);
    zT_242 = self->type_table;
    zT_243 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_242, zT_243, (unsigned int)(1));
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveEnumLiteral */
unsigned int zF_8C008E53_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_54FF90FA_TaggedUnionPayload* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_54FF90FA_TaggedUnionPayload zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned short zT_41;
    unsigned int zT_42;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_2DF01B61_FieldEntry* zT_45;
    zT_2DF01B61_FieldEntry zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    int zT_69;
    unsigned int zT_70;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_2DF01B61_FieldEntry* zT_74;
    unsigned int zT_75;
    zT_2DF01B61_FieldEntry zT_76;
    char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_83;
    unsigned int zT_85;
    char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_21D3708C_U32ToU32Map* zT_93;
    unsigned int zT_94;
    zT_21D3708C_U32ToU32Map* zT_96;
    unsigned int zT_97;
    zT_8EED1867_ResolvedTypeTable* zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_106;
    int zT_107;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_457ECFEE_EnumPayload* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_457ECFEE_EnumPayload zT_119;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned short zT_124;
    unsigned int zT_125;
    int zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_131;
    zT_D96DCDF2_EnumMember* zT_132;
    unsigned int zT_133;
    zT_D96DCDF2_EnumMember zT_134;
    unsigned int zT_135;
    zT_21D3708C_U32ToU32Map* zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    zT_C69B2266_i64 zT_141;
    zT_8EED1867_ResolvedTypeTable* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_148;
    int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    int zT_152;
    unsigned int* zT_155;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_338B7C76_TypeRegistry* zT_164;
    zT_D155D06D_Type* zT_165;
    unsigned int zT_166;
    zT_D155D06D_Type zT_167;
    zT_33EF6BFB_TypeKind zT_168;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_54FF90FA_TaggedUnionPayload* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    zT_54FF90FA_TaggedUnionPayload zT_178;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned short zT_183;
    unsigned int zT_184;
    int zT_186;
    unsigned int zT_187;
    zT_338B7C76_TypeRegistry* zT_190;
    zT_2DF01B61_FieldEntry* zT_191;
    unsigned int zT_192;
    zT_2DF01B61_FieldEntry zT_193;
    unsigned int zT_194;
    unsigned int zT_196;
    zT_21D3708C_U32ToU32Map* zT_199;
    unsigned int zT_200;
    zT_8EED1867_ResolvedTypeTable* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_213;
    char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_F85C5DED_DiagnosticCollector* zT_218;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_232 = 0;
    int zT_234;
    unsigned int zT_235;
    unsigned int zT_237;
    unsigned int zT_239;
    unsigned int zT_241;
    char* zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned int zT_245;
    zT_F85C5DED_DiagnosticCollector* zT_246;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_260 = 0;
    char* zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    unsigned int zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8EED1867_ResolvedTypeTable* zT_268;
    unsigned int zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u el;
    zT_22A7C88B_AstNode node;
    unsigned int n;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int f0;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elc_m;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u elv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elm_m;
    zT_457ECFEE_EnumPayload enp;
    unsigned int estart;
    unsigned int ecount;
    unsigned int emi;
    zT_D96DCDF2_EnumMember member;
    unsigned int top;
    zT_D155D06D_Type top_ty;
    unsigned int fstart2;
    unsigned int fcount2;
    unsigned int fi2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u elr_msg;
    zT_3 = "eL\n";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    el = zT_4;
    zT_6 = el;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node_idx;
    zT_16 = zF_53458827_astStoreIdentifier(zT_13, zT_14);
    n = zT_16;
    zT_17 = self->current_switch_cond_tu;
    if ((int)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = self->current_switch_cond_tu;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    tu_ty = zT_25;
    zT_26 = tu_ty.kind;
    if ((int)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_151 = self->expected_type_stack_len;
    zT_152 = 0;
    if ((int)(zT_151 > (unsigned int)zT_152)) goto z_bb_19; else goto z_bb_20;
    z_bb_3:
    zT_32 = self->registry;
    zT_33 = zT_32->tu_items;
    zT_34 = tu_ty.payload_idx;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zT_33[zT_35];
    tp = zT_36;
    zT_38 = tp.fields_start;
    zT_39 = (unsigned int)zT_38;
    fstart = zT_39;
    zT_41 = tp.fields_count;
    zT_42 = (unsigned int)zT_41;
    fcount = zT_42;
    zT_44 = self->registry;
    zT_45 = zT_44->fe_items;
    zT_46 = zT_45[fstart];
    zT_47 = zT_46.name_id;
    zT_48 = (unsigned int)zT_47;
    f0 = zT_48;
    zT_50 = "EL:N";
    zT_52 = 4;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    eln_m = zT_51;
    zT_53 = eln_m;
    zT_54 = n;
    zF_C914CB83_markerWriteInt(zT_53, zT_54);
    zT_56 = "EL:F";
    zT_58 = 4;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    elf_m = zT_57;
    zT_59 = elf_m;
    zT_60 = f0;
    zF_C914CB83_markerWriteInt(zT_59, zT_60);
    zT_62 = "EL:C";
    zT_64 = 4;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    elc_m = zT_63;
    zT_65 = elc_m;
    zF_C914CB83_markerWriteInt(zT_65, (unsigned int)((unsigned int)fcount));
    zT_69 = 0;
    zT_70 = (unsigned int)zT_69;
    fi = zT_70;
    goto z_bb_5;
    z_bb_4:
    zT_109 = tu_ty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_5:
    if ((int)(fi < fcount)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_73 = self->registry;
    zT_74 = zT_73->fe_items;
    zT_75 = fstart + fi;
    zT_76 = zT_74[zT_75];
    fe = zT_76;
    zT_78 = "EL:V";
    zT_80 = 4;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    elv_m = zT_79;
    zT_81 = elv_m;
    zT_83 = fe.name_id;
    zF_C914CB83_markerWriteInt(zT_81, (unsigned int)((unsigned int)zT_83));
    zT_85 = fe.name_id;
    if ((int)(zT_85 == n)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_107 = 1;
    zT_108 = fi + zT_107;
    fi = zT_108;
    goto z_bb_5;
    z_bb_9:
    zT_88 = "EL:M";
    zT_90 = 4;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    elm_m = zT_89;
    zT_91 = elm_m;
    zT_93 = self->enum_value_table;
    zT_94 = zT_93->count;
    zF_C914CB83_markerWriteInt(zT_91, (unsigned int)((unsigned int)zT_94));
    zT_96 = self->enum_value_table;
    zT_97 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_96, zT_97, (unsigned int)((unsigned int)fi));
    zT_101 = self->type_table;
    zT_102 = node_idx;
    zT_103 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_101, zT_102, zT_103);
    zT_106 = self->current_switch_cond_tu;
    return zT_106;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_115 = self->registry;
    zT_116 = zT_115->en_items;
    zT_117 = tu_ty.payload_idx;
    zT_118 = (unsigned int)zT_117;
    zT_119 = zT_116[zT_118];
    enp = zT_119;
    zT_121 = enp.members_start;
    zT_122 = (unsigned int)zT_121;
    estart = zT_122;
    zT_124 = enp.members_count;
    zT_125 = (unsigned int)zT_124;
    ecount = zT_125;
    zT_127 = 0;
    zT_128 = (unsigned int)zT_127;
    emi = zT_128;
    goto z_bb_13;
    z_bb_12:
    goto z_bb_2;
    z_bb_13:
    if ((int)(emi < ecount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_131 = self->registry;
    zT_132 = zT_131->em_items;
    zT_133 = estart + emi;
    zT_134 = zT_132[zT_133];
    member = zT_134;
    zT_135 = member.name_id;
    if ((int)(zT_135 == n)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_149 = 1;
    zT_150 = emi + zT_149;
    emi = zT_150;
    goto z_bb_13;
    z_bb_17:
    zT_137 = self->enum_value_table;
    zT_138 = node_idx;
    zT_141 = member.value;
    zT_139 = __bootstrap_u32_from_i64(zT_141);
    zF_26476265_u32ToU32MapPut(zT_137, zT_138, zT_139);
    zT_143 = self->type_table;
    zT_144 = node_idx;
    zT_145 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_143, zT_144, zT_145);
    zT_148 = self->current_switch_cond_tu;
    return zT_148;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_155 = self->expected_type_stack_items;
    zT_156 = self->expected_type_stack_len;
    zT_157 = 1;
    zT_159 = (unsigned int)(unsigned int)(zT_156 - zT_157);
    zT_160 = zT_155[zT_159];
    top = zT_160;
    if ((int)(top != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_263 = "ELV:N";
    zT_265 = 5;
    zT_264.ptr = zT_263;
    zT_264.len = zT_265;
    elv_m = zT_264;
    zT_266 = elv_m;
    zT_267 = n;
    zF_C914CB83_markerWriteInt(zT_266, zT_267);
    zT_268 = self->type_table;
    zT_269 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_268, zT_269, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_21:
    zT_164 = self->registry;
    zT_165 = zT_164->types_items;
    zT_166 = (unsigned int)top;
    zT_167 = zT_165[zT_166];
    top_ty = zT_167;
    zT_168 = top_ty.kind;
    if ((int)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_174 = self->registry;
    zT_175 = zT_174->tu_items;
    zT_176 = top_ty.payload_idx;
    zT_177 = (unsigned int)zT_176;
    zT_178 = zT_175[zT_177];
    tp = zT_178;
    zT_180 = tp.fields_start;
    zT_181 = (unsigned int)zT_180;
    fstart2 = zT_181;
    zT_183 = tp.fields_count;
    zT_184 = (unsigned int)zT_183;
    fcount2 = zT_184;
    zT_186 = 0;
    zT_187 = (unsigned int)zT_186;
    fi2 = zT_187;
    goto z_bb_25;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    if ((int)(fi2 < fcount2)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_190 = self->registry;
    zT_191 = zT_190->fe_items;
    zT_192 = fstart2 + fi2;
    zT_193 = zT_191[zT_192];
    fe = zT_193;
    zT_194 = fe.name_id;
    if ((int)(zT_194 == n)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_237 = node.span_start;
    sp = zT_237;
    zT_239 = node.span_len;
    zT_241 = sp + (unsigned int)((unsigned int)zT_239);
    ep = zT_241;
    zT_243 = "unknown enum literal member";
    zT_245 = 27;
    zT_244.ptr = zT_243;
    zT_244.len = zT_245;
    elu_msg = zT_244;
    zT_246 = self->diag;
    zT_249 = self->source_file_id;
    zT_250 = sp;
    zT_251 = ep;
    zT_252 = elu_msg;
    zT_260 = zF_C82559AC_diagnosticCollector(zT_246, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3009_UNKNOWN_ENUM_LITERAL_MEMBER)), zT_249, zT_250, zT_251, zT_252);
    (void)zT_260;
    return (unsigned int)(1);
    z_bb_28:
    zT_234 = 1;
    zT_235 = fi2 + zT_234;
    fi2 = zT_235;
    goto z_bb_25;
    z_bb_29:
    zT_196 = fe.type_id;
    if ((int)(zT_196 == (unsigned int)(1))) goto z_bb_31; else goto z_bb_33;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_199 = self->enum_value_table;
    zT_200 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_199, zT_200, (unsigned int)((unsigned int)fi2));
    zT_204 = self->type_table;
    zT_205 = node_idx;
    zT_206 = top;
    zF_19B4A07D_resolvedTypeTableSe(zT_204, zT_205, zT_206);
    return top;
    goto z_bb_30;
    z_bb_33:
    zT_209 = node.span_start;
    sp = zT_209;
    zT_211 = node.span_len;
    zT_213 = sp + (unsigned int)((unsigned int)zT_211);
    ep = zT_213;
    zT_215 = "enum literal member requires payload";
    zT_217 = 36;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    elr_msg = zT_216;
    zT_218 = self->diag;
    zT_221 = self->source_file_id;
    zT_222 = sp;
    zT_223 = ep;
    zT_224 = elr_msg;
    zT_232 = zF_C82559AC_diagnosticCollector(zT_218, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3008_ENUM_LITERAL_REQUIRES_PAYLOAD)), zT_221, zT_222, zT_223, zT_224);
    (void)zT_232;
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveStructInit */
unsigned int zF_AD7EF126_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_38C12417_SemanticAnalyzer* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19 = 0;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_D155D06D_Type* zT_25;
    unsigned int zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    zT_338B7C76_TypeRegistry* zT_34;
    zT_54FF90FA_TaggedUnionPayload* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_54FF90FA_TaggedUnionPayload zT_38;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned short zT_43;
    unsigned int zT_44;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_49 = {0};
    int zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int* zT_60;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    unsigned int* zT_67;
    unsigned int zT_69 = 0;
    int zT_73;
    unsigned int zT_74;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_2DF01B61_FieldEntry* zT_77;
    unsigned int zT_78;
    zT_2DF01B61_FieldEntry zT_79;
    unsigned int zT_80;
    unsigned int zT_82;
    zT_338B7C76_TypeRegistry* zT_86;
    zT_2DF01B61_FieldEntry* zT_87;
    unsigned int zT_88;
    zT_2DF01B61_FieldEntry zT_89;
    unsigned int zT_90;
    zT_38C12417_SemanticAnalyzer* zT_91;
    unsigned int zT_92;
    zT_38C12417_SemanticAnalyzer* zT_94;
    unsigned int zT_95;
    unsigned int zT_97 = 0;
    zT_38C12417_SemanticAnalyzer* zT_98;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    int zT_104;
    unsigned int zT_105;
    int zT_106;
    unsigned int zT_107;
    zT_8EED1867_ResolvedTypeTable* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_33EF6BFB_TypeKind zT_112;
    zT_338B7C76_TypeRegistry* zT_118;
    zT_406493CE_StructPayload* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_406493CE_StructPayload zT_122;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned short zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_130;
    unsigned int zT_131;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_133 = {0};
    int zT_135;
    unsigned int zT_136;
    unsigned int zT_138;
    zT_6B0A7D14_AstStore* zT_141;
    unsigned int zT_142;
    unsigned int* zT_144;
    zT_22A7C88B_AstNode zT_146 = {0};
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    unsigned int* zT_151;
    unsigned int zT_153 = 0;
    int zT_157;
    unsigned int zT_158;
    zT_338B7C76_TypeRegistry* zT_160;
    zT_2DF01B61_FieldEntry* zT_161;
    unsigned int zT_162;
    zT_2DF01B61_FieldEntry zT_163;
    unsigned int zT_164;
    unsigned int zT_166;
    zT_338B7C76_TypeRegistry* zT_170;
    zT_2DF01B61_FieldEntry* zT_171;
    unsigned int zT_172;
    zT_2DF01B61_FieldEntry zT_173;
    unsigned int zT_174;
    zT_38C12417_SemanticAnalyzer* zT_175;
    unsigned int zT_176;
    zT_38C12417_SemanticAnalyzer* zT_178;
    unsigned int zT_179;
    unsigned int zT_181 = 0;
    zT_38C12417_SemanticAnalyzer* zT_182;
    zT_38C12417_SemanticAnalyzer* zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    int zT_188;
    unsigned int zT_189;
    int zT_190;
    unsigned int zT_191;
    zT_8EED1867_ResolvedTypeTable* zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_33EF6BFB_TypeKind zT_196;
    int zT_201;
    zT_33EF6BFB_TypeKind zT_202;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_AF9231A2_UnionPayload* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_AF9231A2_UnionPayload zT_212;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned short zT_217;
    unsigned int zT_218;
    zT_6B0A7D14_AstStore* zT_220;
    unsigned int zT_221;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_223 = {0};
    int zT_225;
    unsigned int zT_226;
    unsigned int zT_228;
    zT_6B0A7D14_AstStore* zT_231;
    unsigned int zT_232;
    unsigned int* zT_234;
    zT_22A7C88B_AstNode zT_236 = {0};
    zT_6B0A7D14_AstStore* zT_238;
    unsigned int zT_239;
    unsigned int* zT_241;
    unsigned int zT_243 = 0;
    int zT_247;
    unsigned int zT_248;
    zT_338B7C76_TypeRegistry* zT_250;
    zT_2DF01B61_FieldEntry* zT_251;
    unsigned int zT_252;
    zT_2DF01B61_FieldEntry zT_253;
    unsigned int zT_254;
    unsigned int zT_256;
    zT_338B7C76_TypeRegistry* zT_260;
    zT_2DF01B61_FieldEntry* zT_261;
    unsigned int zT_262;
    zT_2DF01B61_FieldEntry zT_263;
    unsigned int zT_264;
    zT_38C12417_SemanticAnalyzer* zT_265;
    unsigned int zT_266;
    zT_38C12417_SemanticAnalyzer* zT_268;
    unsigned int zT_269;
    unsigned int zT_271 = 0;
    zT_38C12417_SemanticAnalyzer* zT_272;
    zT_38C12417_SemanticAnalyzer* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    int zT_278;
    unsigned int zT_279;
    int zT_280;
    unsigned int zT_281;
    zT_8EED1867_ResolvedTypeTable* zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    zT_22A7C88B_AstNode node;
    unsigned int target_type;
    zT_D155D06D_Type tgt;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    zT_3CB0179A_Slice_zT_05F374B1_u field_inits;
    unsigned int fii;
    zT_22A7C88B_AstNode fi_node;
    unsigned int fname_id;
    unsigned int fi;
    unsigned int field_type;
    unsigned int init_type;
    zT_406493CE_StructPayload sp;
    zT_AF9231A2_UnionPayload up;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = 0;
    target_type = zT_8;
    zT_9 = node.child_0;
    if ((int)(zT_9 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = node.child_0;
    zT_15 = zF_54F95822_semanticAnalyzerRes(zT_12, zT_13);
    target_type = zT_15;
    goto z_bb_2;
    z_bb_2:
    if ((int)(target_type == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = self;
    zT_19 = zF_4DE7C2BC_topExpectedType(zT_18);
    target_type = zT_19;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target_type == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(1);
    z_bb_6:
    zT_24 = self->registry;
    zT_25 = zT_24->types_items;
    zT_26 = (unsigned int)target_type;
    zT_27 = zT_25[zT_26];
    tgt = zT_27;
    zT_28 = tgt.kind;
    if ((int)(zT_28 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = self->registry;
    zT_35 = zT_34->tu_items;
    zT_36 = tgt.payload_idx;
    zT_37 = (unsigned int)zT_36;
    zT_38 = zT_35[zT_37];
    tp = zT_38;
    zT_40 = tp.fields_start;
    zT_41 = (unsigned int)zT_40;
    fstart = zT_41;
    zT_43 = tp.fields_count;
    zT_44 = (unsigned int)zT_43;
    fcount = zT_44;
    zT_46 = self->store;
    zT_47 = node_idx;
    zT_49 = zF_850FDF81_astStoreNodeExtraCh(zT_46, zT_47);
    field_inits = zT_49;
    zT_51 = 0;
    zT_52 = (unsigned int)zT_51;
    fii = zT_52;
    goto z_bb_9;
    z_bb_8:
    zT_112 = tgt.kind;
    if ((int)(zT_112 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    zT_54 = field_inits.len;
    if ((int)(fii < zT_54)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_57 = self->store;
    zT_60 = field_inits.ptr;
    zT_58 = zT_60[fii];
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_57, zT_58);
    fi_node = zT_62;
    zT_64 = self->store;
    zT_67 = field_inits.ptr;
    zT_65 = zT_67[fii];
    zT_69 = zF_8BA26B9E_astStoreNodePayload(zT_64, zT_65);
    fname_id = zT_69;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_108 = self->type_table;
    zT_109 = node_idx;
    zT_110 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_108, zT_109, zT_110);
    return target_type;
    z_bb_12:
    zT_106 = 1;
    zT_107 = fii + zT_106;
    fii = zT_107;
    goto z_bb_9;
    z_bb_13:
    zT_73 = 0;
    zT_74 = (unsigned int)zT_73;
    fi = zT_74;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((int)(fi < fcount)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_76 = self->registry;
    zT_77 = zT_76->fe_items;
    zT_78 = fstart + fi;
    zT_79 = zT_77[zT_78];
    zT_80 = zT_79.name_id;
    if ((int)(zT_80 == fname_id)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_104 = 1;
    zT_105 = fi + zT_104;
    fi = zT_105;
    goto z_bb_15;
    z_bb_19:
    zT_82 = fi_node.child_0;
    if ((int)(zT_82 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_86 = self->registry;
    zT_87 = zT_86->fe_items;
    zT_88 = fstart + fi;
    zT_89 = zT_87[zT_88];
    zT_90 = zT_89.type_id;
    field_type = zT_90;
    zT_91 = self;
    zT_92 = field_type;
    zF_9665A229_pushExpectedType(zT_91, zT_92);
    zT_94 = self;
    zT_95 = fi_node.child_0;
    zT_97 = zF_54F95822_semanticAnalyzerRes(zT_94, zT_95);
    init_type = zT_97;
    zT_98 = self;
    zF_BC478E78_popExpectedType(zT_98);
    zT_99 = self;
    zT_100 = fi_node.child_0;
    zT_101 = init_type;
    zT_102 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_99, zT_100, zT_101, zT_102);
    goto z_bb_22;
    z_bb_22:
    goto z_bb_17;
    z_bb_23:
    zT_118 = self->registry;
    zT_119 = zT_118->st_items;
    zT_120 = tgt.payload_idx;
    zT_121 = (unsigned int)zT_120;
    zT_122 = zT_119[zT_121];
    sp = zT_122;
    zT_124 = sp.fields_start;
    zT_125 = (unsigned int)zT_124;
    fstart = zT_125;
    zT_127 = sp.fields_count;
    zT_128 = (unsigned int)zT_127;
    fcount = zT_128;
    zT_130 = self->store;
    zT_131 = node_idx;
    zT_133 = zF_850FDF81_astStoreNodeExtraCh(zT_130, zT_131);
    field_inits = zT_133;
    zT_135 = 0;
    zT_136 = (unsigned int)zT_135;
    fii = zT_136;
    goto z_bb_25;
    z_bb_24:
    zT_196 = tgt.kind;
    if ((int)(zT_196 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_40; else goto z_bb_39;
    z_bb_25:
    zT_138 = field_inits.len;
    if ((int)(fii < zT_138)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_141 = self->store;
    zT_144 = field_inits.ptr;
    zT_142 = zT_144[fii];
    zT_146 = zF_FCDD1D35_astStoreNodeAt(zT_141, zT_142);
    fi_node = zT_146;
    zT_148 = self->store;
    zT_151 = field_inits.ptr;
    zT_149 = zT_151[fii];
    zT_153 = zF_8BA26B9E_astStoreNodePayload(zT_148, zT_149);
    fname_id = zT_153;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_192 = self->type_table;
    zT_193 = node_idx;
    zT_194 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_192, zT_193, zT_194);
    return target_type;
    z_bb_28:
    zT_190 = 1;
    zT_191 = fii + zT_190;
    fii = zT_191;
    goto z_bb_25;
    z_bb_29:
    zT_157 = 0;
    zT_158 = (unsigned int)zT_157;
    fi = zT_158;
    goto z_bb_31;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    if ((int)(fi < fcount)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_160 = self->registry;
    zT_161 = zT_160->fe_items;
    zT_162 = fstart + fi;
    zT_163 = zT_161[zT_162];
    zT_164 = zT_163.name_id;
    if ((int)(zT_164 == fname_id)) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_188 = 1;
    zT_189 = fi + zT_188;
    fi = zT_189;
    goto z_bb_31;
    z_bb_35:
    zT_166 = fi_node.child_0;
    if ((int)(zT_166 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_170 = self->registry;
    zT_171 = zT_170->fe_items;
    zT_172 = fstart + fi;
    zT_173 = zT_171[zT_172];
    zT_174 = zT_173.type_id;
    field_type = zT_174;
    zT_175 = self;
    zT_176 = field_type;
    zF_9665A229_pushExpectedType(zT_175, zT_176);
    zT_178 = self;
    zT_179 = fi_node.child_0;
    zT_181 = zF_54F95822_semanticAnalyzerRes(zT_178, zT_179);
    init_type = zT_181;
    zT_182 = self;
    zF_BC478E78_popExpectedType(zT_182);
    zT_183 = self;
    zT_184 = fi_node.child_0;
    zT_185 = init_type;
    zT_186 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_183, zT_184, zT_185, zT_186);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_33;
    z_bb_39:
    zT_202 = tgt.kind;
    zT_201 = zT_202 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_41;
    z_bb_40:
    zT_201 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_201) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_208 = self->registry;
    zT_209 = zT_208->un_items;
    zT_210 = tgt.payload_idx;
    zT_211 = (unsigned int)zT_210;
    zT_212 = zT_209[zT_211];
    up = zT_212;
    zT_214 = up.fields_start;
    zT_215 = (unsigned int)zT_214;
    fstart = zT_215;
    zT_217 = up.fields_count;
    zT_218 = (unsigned int)zT_217;
    fcount = zT_218;
    zT_220 = self->store;
    zT_221 = node_idx;
    zT_223 = zF_850FDF81_astStoreNodeExtraCh(zT_220, zT_221);
    field_inits = zT_223;
    zT_225 = 0;
    zT_226 = (unsigned int)zT_225;
    fii = zT_226;
    goto z_bb_44;
    z_bb_43:
    return (unsigned int)(1);
    z_bb_44:
    zT_228 = field_inits.len;
    if ((int)(fii < zT_228)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_231 = self->store;
    zT_234 = field_inits.ptr;
    zT_232 = zT_234[fii];
    zT_236 = zF_FCDD1D35_astStoreNodeAt(zT_231, zT_232);
    fi_node = zT_236;
    zT_238 = self->store;
    zT_241 = field_inits.ptr;
    zT_239 = zT_241[fii];
    zT_243 = zF_8BA26B9E_astStoreNodePayload(zT_238, zT_239);
    fname_id = zT_243;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    zT_282 = self->type_table;
    zT_283 = node_idx;
    zT_284 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_282, zT_283, zT_284);
    return target_type;
    z_bb_47:
    zT_280 = 1;
    zT_281 = fii + zT_280;
    fii = zT_281;
    goto z_bb_44;
    z_bb_48:
    zT_247 = 0;
    zT_248 = (unsigned int)zT_247;
    fi = zT_248;
    goto z_bb_50;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    if ((int)(fi < fcount)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_250 = self->registry;
    zT_251 = zT_250->fe_items;
    zT_252 = fstart + fi;
    zT_253 = zT_251[zT_252];
    zT_254 = zT_253.name_id;
    if ((int)(zT_254 == fname_id)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_278 = 1;
    zT_279 = fi + zT_278;
    fi = zT_279;
    goto z_bb_50;
    z_bb_54:
    zT_256 = fi_node.child_0;
    if ((int)(zT_256 != (unsigned int)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_260 = self->registry;
    zT_261 = zT_260->fe_items;
    zT_262 = fstart + fi;
    zT_263 = zT_261[zT_262];
    zT_264 = zT_263.type_id;
    field_type = zT_264;
    zT_265 = self;
    zT_266 = field_type;
    zF_9665A229_pushExpectedType(zT_265, zT_266);
    zT_268 = self;
    zT_269 = fi_node.child_0;
    zT_271 = zF_54F95822_semanticAnalyzerRes(zT_268, zT_269);
    init_type = zT_271;
    zT_272 = self;
    zF_BC478E78_popExpectedType(zT_272);
    zT_273 = self;
    zT_274 = fi_node.child_0;
    zT_275 = init_type;
    zT_276 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_273, zT_274, zT_275, zT_276);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_52;
}

/* semanticAnalyzerResolveAssign */
unsigned int zF_C0551BB8_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_22A7C88B_AstNode zT_25 = {0};
    zT_8143F551_AstKind zT_26;
    char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_39 = 0;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_43 = 0;
    zT_38C12417_SemanticAnalyzer* zT_45;
    unsigned int zT_46;
    unsigned int zT_48 = 0;
    zT_38C12417_SemanticAnalyzer* zT_50;
    unsigned int zT_51;
    zT_38C12417_SemanticAnalyzer* zT_53;
    unsigned int zT_54;
    unsigned int zT_56 = 0;
    zT_38C12417_SemanticAnalyzer* zT_57;
    int zT_60;
    char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_38C12417_SemanticAnalyzer* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_75 = 0;
    zT_338B7C76_TypeRegistry* zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    int zT_80 = 0;
    zT_38C12417_SemanticAnalyzer* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_99;
    unsigned int zT_101;
    unsigned int zT_103;
    char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_338B7C76_TypeRegistry* zT_109;
    zT_D155D06D_Type* zT_110;
    unsigned int zT_111;
    zT_D155D06D_Type zT_112;
    zT_33EF6BFB_TypeKind zT_113;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_D155D06D_Type* zT_116;
    unsigned int zT_117;
    zT_D155D06D_Type zT_118;
    zT_33EF6BFB_TypeKind zT_119;
    int zT_121;
    unsigned char zT_122;
    int zT_127;
    zT_338B7C76_TypeRegistry* zT_133;
    zT_42C2D6BF_EUPayload* zT_134;
    zT_338B7C76_TypeRegistry* zT_135;
    zT_D155D06D_Type* zT_136;
    unsigned int zT_137;
    zT_D155D06D_Type zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_42C2D6BF_EUPayload zT_141;
    zT_338B7C76_TypeRegistry* zT_143;
    zT_42C2D6BF_EUPayload* zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_D155D06D_Type* zT_146;
    unsigned int zT_147;
    zT_D155D06D_Type zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_42C2D6BF_EUPayload zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    int zT_155;
    unsigned char zT_156;
    zT_F85C5DED_DiagnosticCollector* zT_158;
    unsigned char zT_159;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_168 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    zT_33EF6BFB_TypeKind zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    zT_33EF6BFB_TypeKind zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u ase;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    zT_22A7C88B_AstNode lhs_node;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u us_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0;
    unsigned int eff_src;
    zT_8F083A69_Slice_zT_0B42B2F8_u as1;
    zT_8F083A69_Slice_zT_0B42B2F8_u as2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u tma_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_3 = "ASE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ase = zT_4;
    zT_6 = ase;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_17 = node.child_0;
    if ((int)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->store;
    zT_22 = node.child_0;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    lhs_node = zT_25;
    zT_26 = lhs_node.kind;
    if ((int)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_50 = self;
    zT_51 = lhs;
    zF_9665A229_pushExpectedType(zT_50, zT_51);
    zT_53 = self;
    zT_54 = node.child_1;
    zT_56 = zF_54F95822_semanticAnalyzerRes(zT_53, zT_54);
    rhs = zT_56;
    zT_57 = self;
    zF_BC478E78_popExpectedType(zT_57);
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_8; else goto z_bb_7;
    z_bb_3:
    zT_32 = "_";
    zT_34 = 1;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    us_str = zT_33;
    zT_35 = self->store;
    zT_36 = node.child_0;
    zT_39 = zF_53458827_astStoreIdentifier(zT_35, zT_36);
    zT_40 = self->interner;
    zT_41 = us_str;
    zT_43 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    if ((int)(zT_39 == zT_43)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_45 = self;
    zT_46 = node.child_1;
    zT_48 = zF_54F95822_semanticAnalyzerRes(zT_45, zT_46);
    (void)zT_48;
    return (unsigned int)(1);
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_60 = rhs == (unsigned int)(0);
    goto z_bb_9;
    z_bb_8:
    zT_60 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_60) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_64 = "AS0";
    zT_66 = 3;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    as0 = zT_65;
    zT_67 = as0;
    zF_48AC7B3A_markerWrite(zT_67);
    return (unsigned int)(1);
    z_bb_11:
    zT_70 = self;
    zT_71 = node.child_1;
    zT_72 = lhs;
    zT_73 = rhs;
    zT_75 = zF_FFC95E09_errLitSrcType(zT_70, zT_71, zT_72, zT_73);
    eff_src = zT_75;
    zT_76 = self->registry;
    zT_77 = eff_src;
    zT_78 = lhs;
    zT_80 = zF_683AEB7F_typeRegistryIsAssig(zT_76, zT_77, zT_78);
    if (zT_80) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_81 = self;
    zT_82 = node.child_1;
    zT_83 = eff_src;
    zT_84 = lhs;
    zF_DF7434EB_tryRecordCoercion(zT_81, zT_82, zT_83, zT_84);
    zT_87 = "AS1";
    zT_89 = 3;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    as1 = zT_88;
    zT_90 = as1;
    zF_48AC7B3A_markerWrite(zT_90);
    return lhs;
    z_bb_13:
    zT_92 = "AS2";
    zT_94 = 3;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    as2 = zT_93;
    zT_95 = as2;
    zF_48AC7B3A_markerWrite(zT_95);
    if ((int)(lhs != (unsigned int)(1))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_99 = node.span_start;
    sp = zT_99;
    zT_101 = node.span_len;
    zT_103 = sp + (unsigned int)((unsigned int)zT_101);
    ep = zT_103;
    zT_105 = "type mismatch in assignment — internal type representations differ; generated code may be incorrect";
    zT_107 = 101;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    tma_msg = zT_106;
    zT_109 = self->registry;
    zT_110 = zT_109->types_items;
    zT_111 = (unsigned int)eff_src;
    zT_112 = zT_110[zT_111];
    zT_113 = zT_112.kind;
    sk = zT_113;
    zT_115 = self->registry;
    zT_116 = zT_115->types_items;
    zT_117 = (unsigned int)lhs;
    zT_118 = zT_116[zT_117];
    zT_119 = zT_118.kind;
    tk = zT_119;
    zT_121 = 1;
    zT_122 = (unsigned char)zT_121;
    level = zT_122;
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    return (unsigned int)(1);
    z_bb_16:
    zT_127 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_18;
    z_bb_17:
    zT_127 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_127) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_133 = self->registry;
    zT_134 = zT_133->eu_items;
    zT_135 = self->registry;
    zT_136 = zT_135->types_items;
    zT_137 = (unsigned int)eff_src;
    zT_138 = zT_136[zT_137];
    zT_139 = zT_138.payload_idx;
    zT_140 = (unsigned int)zT_139;
    zT_141 = zT_134[zT_140];
    eu_src = zT_141;
    zT_143 = self->registry;
    zT_144 = zT_143->eu_items;
    zT_145 = self->registry;
    zT_146 = zT_145->types_items;
    zT_147 = (unsigned int)lhs;
    zT_148 = zT_146[zT_147];
    zT_149 = zT_148.payload_idx;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zT_144[zT_150];
    eu_tgt = zT_151;
    zT_152 = eu_src.error_set;
    zT_153 = eu_tgt.error_set;
    if ((int)(zT_152 == zT_153)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_158 = self->diag;
    zT_159 = level;
    zT_161 = self->source_file_id;
    zT_162 = sp;
    zT_163 = ep;
    zT_164 = tma_msg;
    zT_168 = zF_C82559AC_diagnosticCollector(zT_158, zT_159, (unsigned short)(3000), zT_161, zT_162, zT_163, zT_164);
    di = zT_168;
    zT_169 = self->diag;
    zT_170 = di;
    zT_173 = sk;
    zT_174 = zF_C14453DE_typeKindSrcStr(zT_173);
    zT_171 = zT_174;
    zF_426E1F18_diagnosticCollector(zT_169, zT_170, zT_171);
    (void)self;
    zT_175 = self->diag;
    zT_176 = di;
    zT_179 = tk;
    zT_180 = zF_CC479241_typeKindTgtStr(zT_179);
    zT_177 = zT_180;
    zF_426E1F18_diagnosticCollector(zT_175, zT_176, zT_177);
    (void)self;
    goto z_bb_15;
    z_bb_21:
    zT_155 = 0;
    zT_156 = (unsigned char)zT_155;
    level = zT_156;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_20;
}

/* semanticAnalyzerResolveSwitchExpr */
unsigned int zF_2DB4F186_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_8143F551_AstKind zT_29;
    zT_79FAE712_u64 zT_32 = 0;
    zT_79FAE712_u64 zT_34;
    char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_55;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    int zT_61;
    unsigned char* zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65 = 0;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zT_8EED1867_ResolvedTypeTable* zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    zT_38C12417_SemanticAnalyzer* zT_92;
    unsigned int zT_93;
    unsigned int zT_95 = 0;
    unsigned int zT_98;
    int zT_101;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D155D06D_Type* zT_106;
    unsigned int zT_107;
    zT_D155D06D_Type zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_114;
    zT_33EF6BFB_TypeKind zT_115;
    char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    zT_33EF6BFB_TypeKind zT_141;
    zT_338B7C76_TypeRegistry* zT_147;
    zT_42C2D6BF_EUPayload* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_42C2D6BF_EUPayload zT_151;
    unsigned int zT_152;
    char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    zT_6B0A7D14_AstStore* zT_165;
    unsigned int zT_166;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_168 = {0};
    unsigned int zT_170;
    char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_179;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    int zT_185;
    unsigned char* zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189 = 0;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned char* zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    zT_8EED1867_ResolvedTypeTable* zT_207;
    unsigned int zT_208;
    unsigned int zT_212;
    unsigned int zT_217;
    unsigned int zT_219;
    int zT_221;
    unsigned char zT_222;
    int zT_224;
    unsigned int zT_225;
    unsigned int zT_227;
    unsigned int zT_229;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    unsigned int* zT_235;
    zT_22A7C88B_AstNode zT_237 = {0};
    unsigned char zT_238;
    int zT_243;
    unsigned char zT_244;
    unsigned char zT_245;
    int zT_250;
    unsigned char zT_251;
    char* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_259;
    zT_F85C5DED_DiagnosticCollector* zT_260;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_271 = 0;
    unsigned int zT_274;
    zT_6B0A7D14_AstStore* zT_276;
    unsigned int zT_277;
    unsigned int* zT_279;
    char* zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287;
    char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned int zT_293;
    zT_6B0A7D14_AstStore* zT_294;
    unsigned int zT_295;
    zT_8143F551_AstKind zT_296;
    unsigned int* zT_298;
    zT_79FAE712_u64 zT_301 = 0;
    zT_79FAE712_u64 zT_303;
    unsigned int zT_305;
    int zT_308;
    zT_6B0A7D14_AstStore* zT_309;
    unsigned int zT_310;
    unsigned int* zT_312;
    unsigned int zT_314 = 0;
    zT_6B0A7D14_AstStore* zT_318;
    unsigned int zT_319;
    unsigned int* zT_321;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_323 = {0};
    int zT_325;
    unsigned int zT_326;
    unsigned int zT_328;
    zT_6B0A7D14_AstStore* zT_331;
    unsigned int zT_332;
    unsigned int* zT_334;
    zT_22A7C88B_AstNode zT_336 = {0};
    zT_8143F551_AstKind zT_338;
    unsigned int zT_339;
    char* zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned int zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned int zT_345;
    zT_8143F551_AstKind zT_346;
    zT_38C12417_SemanticAnalyzer* zT_351;
    unsigned int* zT_353;
    unsigned int zT_354;
    unsigned int zT_356 = 0;
    zT_8143F551_AstKind zT_357;
    zT_38C12417_SemanticAnalyzer* zT_362;
    unsigned int* zT_364;
    unsigned int zT_365;
    unsigned int zT_367 = 0;
    int zT_368;
    unsigned int zT_369;
    unsigned char zT_370;
    unsigned int zT_376;
    char* zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned int zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    unsigned int zT_382;
    char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned int zT_390;
    unsigned int zT_393;
    zT_21D3708C_U32ToU32Map* zT_397;
    unsigned int zT_398;
    unsigned int* zT_400;
    int zT_401;
    zT_BAEE192E_Opt_10 zT_403 = {0};
    unsigned char zT_404;
    zT_338B7C76_TypeRegistry* zT_407;
    zT_D155D06D_Type* zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    zT_D155D06D_Type zT_411;
    zT_33EF6BFB_TypeKind zT_412;
    zT_338B7C76_TypeRegistry* zT_418;
    zT_54FF90FA_TaggedUnionPayload* zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    zT_54FF90FA_TaggedUnionPayload zT_422;
    zT_338B7C76_TypeRegistry* zT_424;
    zT_2DF01B61_FieldEntry* zT_425;
    unsigned int zT_426;
    unsigned int zT_429;
    zT_2DF01B61_FieldEntry zT_430;
    char* zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned int zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned int zT_436;
    char* zT_438;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_439;
    unsigned int zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_441;
    unsigned int zT_442;
    char* zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    unsigned int zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_448;
    zT_33EF6BFB_TypeKind zT_450;
    unsigned int zT_452;
    unsigned int zT_453;
    zT_38C12417_SemanticAnalyzer* zT_455;
    unsigned int* zT_456;
    unsigned int zT_457;
    unsigned int zT_458;
    unsigned int* zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    char* zT_465;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_466;
    unsigned int zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    unsigned int zT_469;
    char* zT_471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_472;
    unsigned int zT_473;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_474;
    unsigned int zT_475;
    char* zT_478;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_479;
    unsigned int zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned int zT_482;
    zT_38C12417_SemanticAnalyzer* zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    int zT_489;
    zT_6B0A7D14_AstStore* zT_490;
    unsigned int zT_491;
    unsigned int* zT_493;
    unsigned int zT_495 = 0;
    zT_6B0A7D14_AstStore* zT_499;
    unsigned int zT_500;
    unsigned int* zT_502;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_504 = {0};
    int zT_506;
    unsigned int zT_507;
    unsigned int zT_509;
    zT_6B0A7D14_AstStore* zT_512;
    unsigned int zT_513;
    unsigned int* zT_515;
    zT_22A7C88B_AstNode zT_517 = {0};
    zT_8143F551_AstKind zT_518;
    zT_38C12417_SemanticAnalyzer* zT_523;
    unsigned int zT_524;
    zT_38C12417_SemanticAnalyzer* zT_525;
    unsigned int* zT_527;
    unsigned int zT_528;
    unsigned int zT_530 = 0;
    zT_38C12417_SemanticAnalyzer* zT_531;
    int zT_532;
    unsigned int zT_533;
    unsigned int zT_535;
    unsigned int zT_537;
    zT_6B0A7D14_AstStore* zT_541;
    unsigned int zT_542;
    zT_22A7C88B_AstNode zT_544 = {0};
    zT_8143F551_AstKind zT_545;
    unsigned int zT_546;
    char* zT_548;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_549;
    unsigned int zT_550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_551;
    unsigned int zT_552;
    char* zT_554;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_555;
    unsigned int zT_556;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_557;
    unsigned int zT_558;
    unsigned int zT_560;
    zT_38C12417_SemanticAnalyzer* zT_562;
    unsigned int zT_563;
    unsigned int zT_565 = 0;
    unsigned int zT_566;
    unsigned int zT_568;
    unsigned int* zT_572;
    unsigned int zT_573;
    unsigned int zT_574;
    zT_38C12417_SemanticAnalyzer* zT_577;
    unsigned int zT_578;
    char* zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned int zT_582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_583;
    unsigned int zT_584;
    char* zT_587;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_588;
    unsigned int zT_589;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_590;
    unsigned int zT_591;
    char* zT_593;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_594;
    unsigned int zT_595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_596;
    unsigned int zT_597;
    char* zT_600;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    unsigned int zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    char* zT_607;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_608;
    unsigned int zT_609;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_610;
    unsigned int zT_611;
    unsigned int zT_616;
    zT_338B7C76_TypeRegistry* zT_618;
    unsigned int zT_619;
    unsigned int zT_620;
    zT_0FB7FB13_CoercionKind zT_622 = 0;
    zT_38C12417_SemanticAnalyzer* zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    unsigned int zT_630;
    zT_338B7C76_TypeRegistry* zT_632;
    unsigned int zT_633;
    unsigned int zT_634;
    zT_0FB7FB13_CoercionKind zT_636 = 0;
    zT_38C12417_SemanticAnalyzer* zT_641;
    unsigned int zT_642;
    unsigned int zT_643;
    unsigned int zT_644;
    unsigned int zT_645;
    unsigned int zT_647;
    zT_338B7C76_TypeRegistry* zT_648;
    unsigned int zT_649;
    int zT_651 = 0;
    unsigned int zT_652;
    int zT_655;
    char* zT_659;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_660;
    unsigned int zT_661;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_662;
    char* zT_666;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_667;
    unsigned int zT_668;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_669;
    unsigned int zT_670;
    char* zT_672;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_673;
    unsigned int zT_674;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_675;
    unsigned int zT_676;
    char* zT_678;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_679;
    unsigned int zT_680;
    zT_338B7C76_TypeRegistry* zT_682;
    zT_D155D06D_Type* zT_683;
    unsigned int zT_684;
    zT_D155D06D_Type zT_685;
    zT_33EF6BFB_TypeKind zT_686;
    unsigned int zT_687;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_688;
    unsigned int zT_689;
    char* zT_691;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_692;
    unsigned int zT_693;
    zT_338B7C76_TypeRegistry* zT_695;
    zT_D155D06D_Type* zT_696;
    unsigned int zT_697;
    zT_D155D06D_Type zT_698;
    zT_33EF6BFB_TypeKind zT_699;
    unsigned int zT_700;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_701;
    unsigned int zT_702;
    char* zT_704;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_705;
    unsigned int zT_706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_707;
    unsigned int zT_708;
    char* zT_711;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_712;
    unsigned int zT_713;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_714;
    unsigned int zT_715;
    char* zT_718;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_719;
    unsigned int zT_720;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_721;
    unsigned char zT_723;
    char* zT_726;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_727;
    unsigned int zT_728;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_729;
    unsigned int zT_732;
    char* zT_735;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_736;
    unsigned int zT_737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_738;
    unsigned int zT_739;
    zT_8EED1867_ResolvedTypeTable* zT_740;
    unsigned int zT_741;
    int zT_745;
    unsigned int zT_746;
    unsigned int zT_752;
    zT_8EED1867_ResolvedTypeTable* zT_753;
    unsigned int zT_754;
    unsigned int zT_755;
    char* zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    unsigned int zT_760;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_761;
    unsigned int zT_762;
    char* zT_764;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_765;
    unsigned int zT_766;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_767;
    unsigned int zT_768;
    unsigned int zT_769;
    zT_8F083A69_Slice_zT_0B42B2F8_u se;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swi_dm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_m;
    zT_5A26C2ED_Arr_unsigned_char_1 sep_b;
    unsigned int sep_l;
    unsigned int sep_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_nl;
    unsigned int cond_type;
    unsigned int cond_es;
    zT_D155D06D_Type cond_ty;
    zT_3CB0179A_Slice_zT_05F374B1_u prongs;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_nl;
    zT_42C2D6BF_EUPayload cond_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pr0_b;
    unsigned int pr0_l;
    unsigned int pr0_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_nl;
    unsigned int unified;
    unsigned int unified_node;
    unsigned char has_else;
    unsigned int i;
    unsigned int sw_base;
    zT_22A7C88B_AstNode prong;
    zT_8F083A69_Slice_zT_0B42B2F8_u swec_msg;
    unsigned int pct;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppt_m;
    zT_3CB0179A_Slice_zT_05F374B1_u case_ec;
    unsigned int ci;
    zT_22A7C88B_AstNode case_node;
    unsigned int cc_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_m;
    unsigned int cap_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_lm;
    zT_BAEE192E_Opt_10 ev;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_rm;
    unsigned int idx;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_tm;
    zT_3CB0179A_Slice_zT_05F374B1_u es_case_ec;
    unsigned int es_ci;
    unsigned int pbd_b0;
    unsigned int pbd_k0;
    zT_22A7C88B_AstNode es_case_node;
    zT_22A7C88B_AstNode pbd_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_km;
    unsigned int saved_tu;
    unsigned int bt;
    unsigned int wi;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_fm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_tm;
    unsigned int unum;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_um;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_tk_m;
    unsigned int mix_tk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_uk_m;
    unsigned int mix_uk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_cd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_b_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_ni_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_tm;
    zT_2 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_2 + (unsigned int)(1));
    zT_6 = "SE";
    zT_8 = 2;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    se = zT_7;
    zT_9 = se;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    node = zT_14;
    zT_16 = "SWI:n";
    zT_18 = 5;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    swu_im = zT_17;
    zT_19 = swu_im;
    zT_20 = node_idx;
    zF_C914CB83_markerWriteInt(zT_19, zT_20);
    zT_22 = "SWI:p";
    zT_24 = 5;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    swu_pm = zT_23;
    zT_25 = swu_pm;
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_29 = node.kind;
    zT_32 = zF_0E4E10C6_astStoreNodePayload(zT_27, zT_28, zT_29);
    zT_34 = zT_32 & (zT_79FAE712_u64)(4294967295u);
    zT_26 = __bootstrap_u32_from_u64(zT_34);
    zF_C914CB83_markerWriteInt(zT_25, zT_26);
    zT_37 = "SWI:d";
    zT_39 = 5;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    swi_dm = zT_38;
    zT_40 = swi_dm;
    zT_41 = self->switch_depth;
    zF_C914CB83_markerWriteInt(zT_40, zT_41);
    zT_43 = self->store;
    zT_44 = node_idx;
    zT_46 = zF_8BA26B9E_astStoreNodePayload(zT_43, zT_44);
    if ((int)(zT_46 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_50 = "P0: n";
    zT_52 = 5;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    sep_m = zT_51;
    zT_53 = sep_m;
    zF_48AC7B3A_markerWrite(zT_53);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_55[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        sep_b[_i] = zT_55[_i];
        _i++;
    }
}
    zT_57 = node_idx;
    zT_61 = 0;
    zT_62 = (unsigned char*)((unsigned char*)sep_b) + zT_61;
    zT_63 = (unsigned int)(10) - zT_61;
    zT_64.ptr = zT_62;
    zT_64.len = zT_63;
    zT_58 = zT_64;
    zT_65 = zF_A7504564_itoa(zT_57, zT_58);
    sep_l = zT_65;
    zT_69 = (unsigned int)(9) - (unsigned int)((unsigned int)sep_l);
    sep_s = zT_69;
    zT_74 = (unsigned char*)((unsigned char*)sep_b) + sep_s;
    zT_75 = (unsigned int)(9) - sep_s;
    zT_76.ptr = zT_74;
    zT_76.len = zT_75;
    zT_70 = zT_76;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_78 = "\n";
    zT_80 = 1;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    sep_nl = zT_79;
    zT_81 = sep_nl;
    zF_48AC7B3A_markerWrite(zT_81);
    zT_82 = self->type_table;
    zT_83 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_82, zT_83, (unsigned int)(1));
    zT_87 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_87 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_2:
    zT_92 = self;
    zT_93 = node.child_0;
    zT_95 = zF_54F95822_semanticAnalyzerRes(zT_92, zT_93);
    cond_type = zT_95;
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_98 = 0;
    cond_es = zT_98;
    if ((int)(cond_type != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_101 = cond_type != (unsigned int)(1);
    goto z_bb_5;
    z_bb_4:
    zT_101 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_101) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_105 = self->registry;
    zT_106 = zT_105->types_items;
    zT_107 = (unsigned int)cond_type;
    zT_108 = zT_106[zT_107];
    cond_ty = zT_108;
    zT_109 = cond_ty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_9; else goto z_bb_8;
    z_bb_7:
    zT_165 = self->store;
    zT_166 = node_idx;
    zT_168 = zF_850FDF81_astStoreNodeExtraCh(zT_165, zT_166);
    prongs = zT_168;
    zT_170 = prongs.len;
    if ((int)(zT_170 == (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_8:
    zT_115 = cond_ty.kind;
    zT_114 = zT_115 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_10;
    z_bb_9:
    zT_114 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_114) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    self->current_switch_cond_tu = cond_type;
    zT_121 = "Z";
    zT_123 = 1;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    rs = zT_122;
    zT_124 = rs;
    zF_48AC7B3A_markerWrite(zT_124);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_7;
    z_bb_13:
    zT_125 = cond_ty.kind;
    if ((int)(zT_125 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cond_es = cond_type;
    zT_131 = "SWES:e";
    zT_133 = 6;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    swes_m = zT_132;
    zT_134 = swes_m;
    zT_135 = cond_es;
    zF_C914CB83_markerWriteInt(zT_134, zT_135);
    zT_137 = "\n";
    zT_139 = 1;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    swes_nl = zT_138;
    zT_140 = swes_nl;
    zF_48AC7B3A_markerWrite(zT_140);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_141 = cond_ty.kind;
    if ((int)(zT_141 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_147 = self->registry;
    zT_148 = zT_147->eu_items;
    zT_149 = cond_ty.payload_idx;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zT_148[zT_150];
    cond_eu = zT_151;
    zT_152 = cond_eu.error_set;
    cond_es = zT_152;
    zT_154 = "SWEU:e";
    zT_156 = 6;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    sweu_m = zT_155;
    zT_157 = sweu_m;
    zT_158 = cond_es;
    zF_C914CB83_markerWriteInt(zT_157, zT_158);
    zT_160 = "\n";
    zT_162 = 1;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    sweu_nl = zT_161;
    zT_163 = sweu_nl;
    zF_48AC7B3A_markerWrite(zT_163);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_174 = "PL0:n";
    zT_176 = 5;
    zT_175.ptr = zT_174;
    zT_175.len = zT_176;
    pr0_m = zT_175;
    zT_177 = pr0_m;
    zF_48AC7B3A_markerWrite(zT_177);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_179[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pr0_b[_i] = zT_179[_i];
        _i++;
    }
}
    zT_181 = node_idx;
    zT_185 = 0;
    zT_186 = (unsigned char*)((unsigned char*)pr0_b) + zT_185;
    zT_187 = (unsigned int)(10) - zT_185;
    zT_188.ptr = zT_186;
    zT_188.len = zT_187;
    zT_182 = zT_188;
    zT_189 = zF_A7504564_itoa(zT_181, zT_182);
    pr0_l = zT_189;
    zT_193 = (unsigned int)(9) - (unsigned int)((unsigned int)pr0_l);
    pr0_s = zT_193;
    zT_198 = (unsigned char*)((unsigned char*)pr0_b) + pr0_s;
    zT_199 = (unsigned int)(9) - pr0_s;
    zT_200.ptr = zT_198;
    zT_200.len = zT_199;
    zT_194 = zT_200;
    zF_48AC7B3A_markerWrite(zT_194);
    zT_202 = "\n";
    zT_204 = 1;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    pr0_nl = zT_203;
    zT_205 = pr0_nl;
    zF_48AC7B3A_markerWrite(zT_205);
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_207 = self->type_table;
    zT_208 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_207, zT_208, (unsigned int)(1));
    zT_212 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_212 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_20:
    zT_217 = 0;
    unified = zT_217;
    zT_219 = 0;
    unified_node = zT_219;
    zT_221 = 0;
    zT_222 = (unsigned char)zT_221;
    has_else = zT_222;
    zT_224 = 0;
    zT_225 = (unsigned int)zT_224;
    i = zT_225;
    zT_227 = self->stmt_work_len;
    sw_base = zT_227;
    goto z_bb_21;
    z_bb_21:
    zT_229 = prongs.len;
    if ((int)(i < zT_229)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_232 = self->store;
    zT_235 = prongs.ptr;
    zT_233 = zT_235[i];
    zT_237 = zF_FCDD1D35_astStoreNodeAt(zT_232, zT_233);
    prong = zT_237;
    zT_238 = prong.flags;
    if ((int)((unsigned char)(zT_238 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    self->current_switch_cond_tu = (unsigned int)(0);
    if ((int)(has_else == (unsigned char)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_24:
    zT_745 = 1;
    zT_746 = i + zT_745;
    i = zT_746;
    goto z_bb_21;
    z_bb_25:
    zT_243 = 1;
    zT_244 = (unsigned char)zT_243;
    has_else = zT_244;
    goto z_bb_26;
    z_bb_26:
    zT_245 = prong.flags;
    if ((int)((unsigned char)(zT_245 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_251 = prong.flags;
    zT_250 = (unsigned char)(zT_251 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_29;
    z_bb_28:
    zT_250 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_250) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_257 = "switch else-prong capture (else => |capture|) is not supported";
    zT_259 = 62;
    zT_258.ptr = zT_257;
    zT_258.len = zT_259;
    swec_msg = zT_258;
    zT_260 = self->diag;
    zT_263 = self->source_file_id;
    zT_264 = node_idx;
    zT_265 = node_idx;
    zT_266 = swec_msg;
    zT_271 = zF_C82559AC_diagnosticCollector(zT_260, (unsigned char)(0), (unsigned short)(3001), zT_263, zT_264, zT_265, zT_266);
    (void)zT_271;
    return (unsigned int)(1);
    z_bb_31:
    zT_274 = self->current_switch_cond_tu;
    pct = zT_274;
    zT_276 = self->store;
    zT_279 = prongs.ptr;
    zT_277 = zT_279[i];
    (void)zF_8BA26B9E_astStoreNodePayload(zT_276, zT_277);
    zT_283 = "PCT:C";
    zT_285 = 5;
    zT_284.ptr = zT_283;
    zT_284.len = zT_285;
    pct_m2 = zT_284;
    zT_286 = pct_m2;
    zT_287 = pct;
    zF_C914CB83_markerWriteInt(zT_286, zT_287);
    zT_289 = "PCT:P";
    zT_291 = 5;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    ppt_m = zT_290;
    zT_292 = ppt_m;
    zT_294 = self->store;
    zT_298 = prongs.ptr;
    zT_295 = zT_298[i];
    zT_296 = prong.kind;
    zT_301 = zF_0E4E10C6_astStoreNodePayload(zT_294, zT_295, zT_296);
    zT_303 = zT_301 & (zT_79FAE712_u64)(4294967295u);
    zT_293 = __bootstrap_u32_from_u64(zT_303);
    zF_C914CB83_markerWriteInt(zT_292, zT_293);
    zT_305 = self->current_switch_cond_tu;
    if ((int)(zT_305 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_309 = self->store;
    zT_312 = prongs.ptr;
    zT_310 = zT_312[i];
    zT_314 = zF_8BA26B9E_astStoreNodePayload(zT_309, zT_310);
    zT_308 = zT_314 != (unsigned int)(0);
    goto z_bb_34;
    z_bb_33:
    zT_308 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_308) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_318 = self->store;
    zT_321 = prongs.ptr;
    zT_319 = zT_321[i];
    zT_323 = zF_850FDF81_astStoreNodeExtraCh(zT_318, zT_319);
    case_ec = zT_323;
    zT_325 = 0;
    zT_326 = (unsigned int)zT_325;
    ci = zT_326;
    goto z_bb_37;
    z_bb_36:
    if ((int)(cond_es != (unsigned int)(0))) goto z_bb_57; else goto z_bb_58;
    z_bb_37:
    zT_328 = case_ec.len;
    if ((int)(ci < zT_328)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_331 = self->store;
    zT_334 = case_ec.ptr;
    zT_332 = zT_334[ci];
    zT_336 = zF_FCDD1D35_astStoreNodeAt(zT_331, zT_332);
    case_node = zT_336;
    zT_338 = case_node.kind;
    zT_339 = (unsigned int)zT_338;
    cc_val = zT_339;
    zT_341 = "CC:K";
    zT_343 = 4;
    zT_342.ptr = zT_341;
    zT_342.len = zT_343;
    cc_m = zT_342;
    zT_344 = cc_m;
    zT_345 = cc_val;
    zF_C914CB83_markerWriteInt(zT_344, zT_345);
    zT_346 = case_node.kind;
    if ((int)(zT_346 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_41; else goto z_bb_43;
    z_bb_39:
    zT_370 = prong.flags;
    if ((int)((unsigned char)(zT_370 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_40:
    zT_368 = 1;
    zT_369 = ci + zT_368;
    ci = zT_369;
    goto z_bb_37;
    z_bb_41:
    zT_351 = self;
    zT_353 = case_ec.ptr;
    zT_354 = zT_353[ci];
    zT_356 = zF_8C008E53_semanticAnalyzerRes(zT_351, (unsigned int)((unsigned int)zT_354));
    (void)zT_356;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_357 = case_node.kind;
    if ((int)(zT_357 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_362 = self;
    zT_364 = case_ec.ptr;
    zT_365 = zT_364[ci];
    zT_367 = zF_8C008E53_semanticAnalyzerRes(zT_362, (unsigned int)((unsigned int)zT_365));
    (void)zT_367;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_376 = prong.child_1;
    cap_name = zT_376;
    zT_378 = "SCE:p";
    zT_380 = 5;
    zT_379.ptr = zT_378;
    zT_379.len = zT_380;
    sce_pm = zT_379;
    zT_381 = sce_pm;
    zT_382 = cap_name;
    zF_C914CB83_markerWriteInt(zT_381, zT_382);
    zT_384 = "SCE:l";
    zT_386 = 5;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    sce_lm = zT_385;
    zT_387 = sce_lm;
    zT_390 = case_ec.len;
    zF_C914CB83_markerWriteInt(zT_387, (unsigned int)((unsigned int)zT_390));
    zT_393 = case_ec.len;
    if ((int)(zT_393 > (unsigned int)(0))) goto z_bb_48; else goto z_bb_50;
    z_bb_47:
    goto z_bb_36;
    z_bb_48:
    zT_397 = self->enum_value_table;
    zT_400 = case_ec.ptr;
    zT_401 = 0;
    zT_398 = zT_400[zT_401];
    zT_403 = zF_F3EE5998_u32ToU32MapGet(zT_397, zT_398);
    ev = zT_403;
    zT_404 = ev.has_value;
    if (zT_404) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_478 = "SCE:R";
    zT_480 = 5;
    zT_479.ptr = zT_478;
    zT_479.len = zT_480;
    sce_rm = zT_479;
    zT_481 = sce_rm;
    zT_482 = cap_name;
    zF_C914CB83_markerWriteInt(zT_481, zT_482);
    zT_483 = self;
    zT_484 = cap_name;
    zT_485 = self->current_switch_cond_tu;
    zF_7BD72017_registerLocalDecl(zT_483, zT_484, zT_485);
    goto z_bb_49;
    z_bb_51:
    idx = ev.value;
    zT_407 = self->registry;
    zT_408 = zT_407->types_items;
    zT_409 = self->current_switch_cond_tu;
    zT_410 = (unsigned int)zT_409;
    zT_411 = zT_408[zT_410];
    tu_ty = zT_411;
    zT_412 = tu_ty.kind;
    if ((int)(zT_412 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_418 = self->registry;
    zT_419 = zT_418->tu_items;
    zT_420 = tu_ty.payload_idx;
    zT_421 = (unsigned int)zT_420;
    zT_422 = zT_419[zT_421];
    tp = zT_422;
    zT_424 = self->registry;
    zT_425 = zT_424->fe_items;
    zT_426 = tp.fields_start;
    zT_429 = (unsigned int)((unsigned int)zT_426) + (unsigned int)((unsigned int)idx);
    zT_430 = zT_425[zT_429];
    fe = zT_430;
    zT_432 = "SCFE:n";
    zT_434 = 6;
    zT_433.ptr = zT_432;
    zT_433.len = zT_434;
    scfe_nm = zT_433;
    zT_435 = scfe_nm;
    zT_436 = cap_name;
    zF_C914CB83_markerWriteInt(zT_435, zT_436);
    zT_438 = "SCFE:t";
    zT_440 = 6;
    zT_439.ptr = zT_438;
    zT_439.len = zT_440;
    scfe_tm = zT_439;
    zT_441 = scfe_tm;
    zT_442 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_441, zT_442);
    zT_445 = "SCFE:k";
    zT_447 = 6;
    zT_446.ptr = zT_445;
    zT_446.len = zT_447;
    scfe_km = zT_446;
    zT_448 = scfe_km;
    zT_450 = tu_ty.kind;
    zF_C914CB83_markerWriteInt(zT_448, (unsigned int)((unsigned int)zT_450));
    zT_452 = self->local_decl_count;
    zT_453 = self->local_decl_cap;
    if ((int)(zT_452 >= zT_453)) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_455 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_455);
    goto z_bb_56;
    z_bb_56:
    zT_456 = self->local_decl_names;
    zT_457 = self->local_decl_count;
    zT_456[zT_457] = cap_name;
    zT_458 = fe.type_id;
    zT_459 = self->local_decl_types;
    zT_460 = self->local_decl_count;
    zT_459[zT_460] = zT_458;
    zT_461 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_461 + (unsigned int)(1));
    zT_465 = "SCAX:N";
    zT_467 = 6;
    zT_466.ptr = zT_465;
    zT_466.len = zT_467;
    scax_m = zT_466;
    zT_468 = scax_m;
    zT_469 = cap_name;
    zF_C914CB83_markerWriteInt(zT_468, zT_469);
    zT_471 = "SCAX:T";
    zT_473 = 6;
    zT_472.ptr = zT_471;
    zT_472.len = zT_473;
    scax_tm = zT_472;
    zT_474 = scax_tm;
    zT_475 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_474, zT_475);
    goto z_bb_54;
    z_bb_57:
    zT_490 = self->store;
    zT_493 = prongs.ptr;
    zT_491 = zT_493[i];
    zT_495 = zF_8BA26B9E_astStoreNodePayload(zT_490, zT_491);
    zT_489 = zT_495 != (unsigned int)(0);
    goto z_bb_59;
    z_bb_58:
    zT_489 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_489) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_499 = self->store;
    zT_502 = prongs.ptr;
    zT_500 = zT_502[i];
    zT_504 = zF_850FDF81_astStoreNodeExtraCh(zT_499, zT_500);
    es_case_ec = zT_504;
    zT_506 = 0;
    zT_507 = (unsigned int)zT_506;
    es_ci = zT_507;
    goto z_bb_62;
    z_bb_61:
    zT_535 = prong.child_0;
    pbd_b0 = zT_535;
    zT_537 = 0;
    pbd_k0 = zT_537;
    if ((int)(pbd_b0 != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_62:
    zT_509 = es_case_ec.len;
    if ((int)(es_ci < zT_509)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_512 = self->store;
    zT_515 = es_case_ec.ptr;
    zT_513 = zT_515[es_ci];
    zT_517 = zF_FCDD1D35_astStoreNodeAt(zT_512, zT_513);
    es_case_node = zT_517;
    zT_518 = es_case_node.kind;
    if ((int)(zT_518 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_532 = 1;
    zT_533 = es_ci + zT_532;
    es_ci = zT_533;
    goto z_bb_62;
    z_bb_66:
    zT_523 = self;
    zT_524 = cond_es;
    zF_9665A229_pushExpectedType(zT_523, zT_524);
    zT_525 = self;
    zT_527 = es_case_ec.ptr;
    zT_528 = zT_527[es_ci];
    zT_530 = zF_54F95822_semanticAnalyzerRes(zT_525, (unsigned int)((unsigned int)zT_528));
    (void)zT_530;
    zT_531 = self;
    zF_BC478E78_popExpectedType(zT_531);
    goto z_bb_67;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_541 = self->store;
    zT_542 = pbd_b0;
    zT_544 = zF_FCDD1D35_astStoreNodeAt(zT_541, zT_542);
    pbd_n = zT_544;
    zT_545 = pbd_n.kind;
    zT_546 = (unsigned int)zT_545;
    pbd_k0 = zT_546;
    goto z_bb_69;
    z_bb_69:
    zT_548 = "PBD:N";
    zT_550 = 5;
    zT_549.ptr = zT_548;
    zT_549.len = zT_550;
    pbd_nm = zT_549;
    zT_551 = pbd_nm;
    zT_552 = pbd_b0;
    zF_C914CB83_markerWriteInt(zT_551, zT_552);
    zT_554 = "PBD:K";
    zT_556 = 5;
    zT_555.ptr = zT_554;
    zT_555.len = zT_556;
    pbd_km = zT_555;
    zT_557 = pbd_km;
    zT_558 = pbd_k0;
    zF_C914CB83_markerWriteInt(zT_557, zT_558);
    zT_560 = self->current_switch_cond_tu;
    saved_tu = zT_560;
    zT_562 = self;
    zT_563 = prong.child_0;
    zT_565 = zF_54F95822_semanticAnalyzerRes(zT_562, zT_563);
    bt = zT_565;
    self->current_switch_cond_tu = saved_tu;
    goto z_bb_70;
    z_bb_70:
    zT_566 = self->stmt_work_len;
    if ((int)(zT_566 > sw_base)) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_568 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_568 - (unsigned int)(1));
    zT_572 = self->stmt_work_items;
    zT_573 = self->stmt_work_len;
    zT_574 = zT_572[zT_573];
    wi = zT_574;
    if ((int)(wi != (unsigned int)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_580 = "PCT:n";
    zT_582 = 5;
    zT_581.ptr = zT_580;
    zT_581.len = zT_582;
    pct_m = zT_581;
    zT_583 = pct_m;
    zT_584 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_583, zT_584);
    zT_587 = "PCT:b";
    zT_589 = 5;
    zT_588.ptr = zT_587;
    zT_588.len = zT_589;
    pct_bm = zT_588;
    zT_590 = pct_bm;
    zT_591 = bt;
    zF_C914CB83_markerWriteInt(zT_590, zT_591);
    zT_593 = "PCT:f";
    zT_595 = 5;
    zT_594.ptr = zT_593;
    zT_594.len = zT_595;
    pct_fm = zT_594;
    zT_596 = pct_fm;
    zT_597 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_596, zT_597);
    zT_600 = "SWPB:i";
    zT_602 = 6;
    zT_601.ptr = zT_600;
    zT_601.len = zT_602;
    swpb_im = zT_601;
    zT_603 = swpb_im;
    zF_C914CB83_markerWriteInt(zT_603, (unsigned int)((unsigned int)i));
    zT_607 = "SWPB:t";
    zT_609 = 6;
    zT_608.ptr = zT_607;
    zT_608.len = zT_609;
    swpb_tm = zT_608;
    zT_610 = swpb_tm;
    zT_611 = bt;
    zF_C914CB83_markerWriteInt(zT_610, zT_611);
    if ((int)(bt == (unsigned int)(3))) goto z_bb_76; else goto z_bb_78;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    zT_577 = self;
    zT_578 = wi;
    zF_10A0DC35_semanticAnalyzerRes(zT_577, zT_578);
    goto z_bb_75;
    z_bb_75:
    goto z_bb_73;
    z_bb_76:
    goto z_bb_77;
    z_bb_77:
    goto z_bb_24;
    z_bb_78:
    if ((int)(unified == (unsigned int)(0))) goto z_bb_79; else goto z_bb_81;
    z_bb_79:
    unified = bt;
    zT_616 = prong.child_0;
    unified_node = zT_616;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_77;
    z_bb_81:
    if ((int)(bt == unified)) goto z_bb_82; else goto z_bb_84;
    z_bb_82:
    goto z_bb_83;
    z_bb_83:
    goto z_bb_80;
    z_bb_84:
    zT_618 = self->registry;
    zT_619 = bt;
    zT_620 = unified;
    zT_622 = zF_713658BF_classifyCoercion(zT_618, zT_619, zT_620);
    if ((int)(zT_622 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_85; else goto z_bb_87;
    z_bb_85:
    zT_627 = self;
    zT_628 = prong.child_0;
    zT_629 = bt;
    zT_630 = unified;
    zF_DF7434EB_tryRecordCoercion(zT_627, zT_628, zT_629, zT_630);
    goto z_bb_86;
    z_bb_86:
    goto z_bb_83;
    z_bb_87:
    zT_632 = self->registry;
    zT_633 = unified;
    zT_634 = bt;
    zT_636 = zF_713658BF_classifyCoercion(zT_632, zT_633, zT_634);
    if ((int)(zT_636 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    zT_641 = self;
    zT_642 = unified_node;
    zT_643 = unified;
    zT_644 = bt;
    zF_DF7434EB_tryRecordCoercion(zT_641, zT_642, zT_643, zT_644);
    unified = bt;
    zT_645 = prong.child_0;
    unified_node = zT_645;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_86;
    z_bb_90:
    zT_647 = 0;
    unum = zT_647;
    zT_648 = self->registry;
    zT_649 = bt;
    zT_651 = zF_3087E0A5_typeRegistryIsNumer(zT_648, zT_649);
    if (zT_651) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_652 = 1;
    unum = zT_652;
    goto z_bb_92;
    z_bb_92:
    if ((int)(unified == (unsigned int)(19))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_655 = unum != (unsigned int)(0);
    goto z_bb_95;
    z_bb_94:
    zT_655 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_655) goto z_bb_96; else goto z_bb_98;
    z_bb_96:
    unified = bt;
    goto z_bb_97;
    z_bb_97:
    goto z_bb_89;
    z_bb_98:
    zT_659 = "MIX:P";
    zT_661 = 5;
    zT_660.ptr = zT_659;
    zT_660.len = zT_661;
    mix_pm = zT_660;
    zT_662 = mix_pm;
    zF_C914CB83_markerWriteInt(zT_662, (unsigned int)((unsigned int)i));
    zT_666 = "MIX:U";
    zT_668 = 5;
    zT_667.ptr = zT_666;
    zT_667.len = zT_668;
    mix_um = zT_667;
    zT_669 = mix_um;
    zT_670 = unified;
    zF_C914CB83_markerWriteInt(zT_669, zT_670);
    zT_672 = "MIX:B";
    zT_674 = 5;
    zT_673.ptr = zT_672;
    zT_673.len = zT_674;
    mix_bm = zT_673;
    zT_675 = mix_bm;
    zT_676 = bt;
    zF_C914CB83_markerWriteInt(zT_675, zT_676);
    zT_678 = "MIX:tk";
    zT_680 = 6;
    zT_679.ptr = zT_678;
    zT_679.len = zT_680;
    mix_tk_m = zT_679;
    zT_682 = self->registry;
    zT_683 = zT_682->types_items;
    zT_684 = (unsigned int)bt;
    zT_685 = zT_683[zT_684];
    zT_686 = zT_685.kind;
    zT_687 = (unsigned int)zT_686;
    mix_tk_v = zT_687;
    zT_688 = mix_tk_m;
    zT_689 = mix_tk_v;
    zF_C914CB83_markerWriteInt(zT_688, zT_689);
    zT_691 = "MIX:uk";
    zT_693 = 6;
    zT_692.ptr = zT_691;
    zT_692.len = zT_693;
    mix_uk_m = zT_692;
    zT_695 = self->registry;
    zT_696 = zT_695->types_items;
    zT_697 = (unsigned int)unified;
    zT_698 = zT_696[zT_697];
    zT_699 = zT_698.kind;
    zT_700 = (unsigned int)zT_699;
    mix_uk_v = zT_700;
    zT_701 = mix_uk_m;
    zT_702 = mix_uk_v;
    zF_C914CB83_markerWriteInt(zT_701, zT_702);
    zT_704 = "MIX:cd";
    zT_706 = 6;
    zT_705.ptr = zT_704;
    zT_705.len = zT_706;
    mix_cd_m = zT_705;
    zT_707 = mix_cd_m;
    zT_708 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_707, zT_708);
    zT_711 = "MIX:b";
    zT_713 = 5;
    zT_712.ptr = zT_711;
    zT_712.len = zT_713;
    mix_b_m = zT_712;
    zT_714 = mix_b_m;
    zT_715 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_714, zT_715);
    zT_718 = "MIX:pf";
    zT_720 = 6;
    zT_719.ptr = zT_718;
    zT_719.len = zT_720;
    mix_pf_m = zT_719;
    zT_721 = mix_pf_m;
    zT_723 = prong.flags;
    zF_C914CB83_markerWriteInt(zT_721, (unsigned int)((unsigned int)zT_723));
    zT_726 = "MIX:pn";
    zT_728 = 6;
    zT_727.ptr = zT_726;
    zT_727.len = zT_728;
    mix_pn_m = zT_727;
    zT_729 = mix_pn_m;
    zT_732 = prongs.len;
    zF_C914CB83_markerWriteInt(zT_729, (unsigned int)((unsigned int)zT_732));
    zT_735 = "MIX:ni";
    zT_737 = 6;
    zT_736.ptr = zT_735;
    zT_736.len = zT_737;
    mix_ni_m = zT_736;
    zT_738 = mix_ni_m;
    zT_739 = node_idx;
    zF_C914CB83_markerWriteInt(zT_738, zT_739);
    zT_740 = self->type_table;
    zT_741 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_740, zT_741, (unsigned int)(1));
    goto z_bb_24;
    z_bb_99:
    goto z_bb_100;
    z_bb_100:
    if ((int)(unified == (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_752 = 1;
    unified = zT_752;
    goto z_bb_102;
    z_bb_102:
    zT_753 = self->type_table;
    zT_754 = node_idx;
    zT_755 = unified;
    zF_19B4A07D_resolvedTypeTableSe(zT_753, zT_754, zT_755);
    zT_758 = "SWU:n";
    zT_760 = 5;
    zT_759.ptr = zT_758;
    zT_759.len = zT_760;
    swu_m = zT_759;
    zT_761 = swu_m;
    zT_762 = node_idx;
    zF_C914CB83_markerWriteInt(zT_761, zT_762);
    zT_764 = "SWU:t";
    zT_766 = 5;
    zT_765.ptr = zT_764;
    zT_765.len = zT_766;
    swu_tm = zT_765;
    zT_767 = swu_tm;
    zT_768 = unified;
    zF_C914CB83_markerWriteInt(zT_767, zT_768);
    zT_769 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_769 - (unsigned int)(1));
    return unified;
}

/* semanticAnalyzerResolveExpr */
unsigned int zF_54F95822_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_3;
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    unsigned int zT_11;
    zT_8143F551_AstKind zT_12;
    char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8143F551_AstKind zT_28;
    unsigned int zT_33;
    zT_8143F551_AstKind zT_34;
    unsigned int zT_39;
    zT_8143F551_AstKind zT_40;
    unsigned int zT_45;
    zT_8143F551_AstKind zT_46;
    unsigned int zT_51;
    zT_8143F551_AstKind zT_52;
    unsigned int zT_57;
    zT_8143F551_AstKind zT_58;
    unsigned int zT_63;
    zT_8143F551_AstKind zT_64;
    unsigned int zT_69;
    zT_8143F551_AstKind zT_70;
    zT_338B7C76_TypeRegistry* zT_75;
    unsigned int zT_81 = 0;
    zT_8143F551_AstKind zT_82;
    zT_38C12417_SemanticAnalyzer* zT_87;
    unsigned int zT_88;
    unsigned int zT_89 = 0;
    zT_8143F551_AstKind zT_90;
    unsigned int zT_95;
    int zT_96;
    unsigned int* zT_99;
    unsigned int zT_100;
    int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    int zT_104;
    int zT_107;
    unsigned int zT_108;
    zT_338B7C76_TypeRegistry* zT_110;
    zT_D155D06D_Type* zT_111;
    unsigned int zT_112;
    zT_D155D06D_Type zT_113;
    zT_33EF6BFB_TypeKind zT_115;
    zT_338B7C76_TypeRegistry* zT_121;
    zT_0B10E8E9_OptionalPayload* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_0B10E8E9_OptionalPayload zT_125;
    unsigned int zT_126;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_D155D06D_Type* zT_128;
    unsigned int zT_129;
    zT_D155D06D_Type zT_130;
    zT_33EF6BFB_TypeKind zT_131;
    zT_33EF6BFB_TypeKind zT_136;
    zT_338B7C76_TypeRegistry* zT_141;
    zT_42C2D6BF_EUPayload* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    zT_42C2D6BF_EUPayload zT_145;
    unsigned int zT_146;
    int zT_147;
    zT_6B0A7D14_AstStore* zT_150;
    unsigned int zT_151;
    unsigned int zT_153 = 0;
    zT_338B7C76_TypeRegistry* zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_159 = 0;
    zT_21D3708C_U32ToU32Map* zT_163;
    unsigned int zT_164;
    unsigned int zT_166 = 0;
    zT_21D3708C_U32ToU32Map* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_8EED1867_ResolvedTypeTable* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_176;
    unsigned int zT_178;
    unsigned int zT_180;
    char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    zT_F85C5DED_DiagnosticCollector* zT_185;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_199 = 0;
    unsigned int zT_200;
    zT_33EF6BFB_TypeKind zT_201;
    zT_8EED1867_ResolvedTypeTable* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    zT_8143F551_AstKind zT_213;
    zT_38C12417_SemanticAnalyzer* zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    zT_6B0A7D14_AstStore* zT_223;
    unsigned int zT_224;
    unsigned int zT_226 = 0;
    unsigned int zT_227 = 0;
    zT_8143F551_AstKind zT_228;
    zT_38C12417_SemanticAnalyzer* zT_233;
    unsigned int zT_234;
    unsigned int zT_235 = 0;
    char* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_240;
    unsigned int zT_241;
    zT_8143F551_AstKind zT_242;
    zT_38C12417_SemanticAnalyzer* zT_247;
    unsigned int zT_248;
    unsigned int zT_249 = 0;
    zT_8143F551_AstKind zT_250;
    zT_38C12417_SemanticAnalyzer* zT_255;
    unsigned int zT_256;
    unsigned int zT_257 = 0;
    zT_8143F551_AstKind zT_258;
    zT_38C12417_SemanticAnalyzer* zT_264;
    unsigned int zT_265;
    unsigned int zT_267 = 0;
    int zT_270;
    zT_338B7C76_TypeRegistry* zT_274;
    zT_D155D06D_Type* zT_275;
    unsigned int zT_276;
    zT_D155D06D_Type zT_277;
    zT_33EF6BFB_TypeKind zT_278;
    int zT_283;
    zT_33EF6BFB_TypeKind zT_284;
    zT_338B7C76_TypeRegistry* zT_290;
    zT_112BF819_PtrPayload* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    zT_112BF819_PtrPayload zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    zT_8143F551_AstKind zT_297;
    zT_38C12417_SemanticAnalyzer* zT_303;
    unsigned int zT_304;
    unsigned int zT_306 = 0;
    int zT_309;
    zT_6B0A7D14_AstStore* zT_313;
    unsigned int zT_314;
    zT_22A7C88B_AstNode zT_317 = {0};
    zT_8143F551_AstKind zT_318;
    zT_38C12417_SemanticAnalyzer* zT_324;
    unsigned int zT_325;
    unsigned int zT_327 = 0;
    int zT_331;
    zT_338B7C76_TypeRegistry* zT_335;
    zT_D155D06D_Type* zT_336;
    unsigned int zT_337;
    zT_D155D06D_Type zT_338;
    zT_33EF6BFB_TypeKind zT_339;
    int zT_344;
    zT_33EF6BFB_TypeKind zT_345;
    zT_338B7C76_TypeRegistry* zT_350;
    zT_112BF819_PtrPayload* zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    zT_112BF819_PtrPayload zT_354;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_356;
    zT_D155D06D_Type* zT_357;
    unsigned int zT_358;
    zT_D155D06D_Type zT_359;
    zT_33EF6BFB_TypeKind zT_360;
    zT_38C12417_SemanticAnalyzer* zT_366;
    unsigned int zT_367;
    unsigned int zT_368 = 0;
    unsigned int zT_372;
    unsigned int zT_374;
    unsigned int zT_376;
    char* zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned int zT_380;
    zT_F85C5DED_DiagnosticCollector* zT_381;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned int zT_392 = 0;
    zT_33EF6BFB_TypeKind zT_393;
    unsigned int zT_399;
    unsigned int zT_401;
    unsigned int zT_403;
    char* zT_405;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_406;
    unsigned int zT_407;
    zT_F85C5DED_DiagnosticCollector* zT_408;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_414;
    unsigned int zT_419 = 0;
    zT_338B7C76_TypeRegistry* zT_420;
    unsigned int zT_421;
    unsigned int zT_425 = 0;
    unsigned int zT_426;
    zT_8143F551_AstKind zT_427;
    zT_38C12417_SemanticAnalyzer* zT_432;
    unsigned int zT_433;
    unsigned int zT_434 = 0;
    zT_8143F551_AstKind zT_435;
    int zT_440;
    zT_38C12417_SemanticAnalyzer* zT_441;
    unsigned int zT_442;
    int zT_444 = 0;
    char* zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_448;
    unsigned int zT_449;
    zT_F85C5DED_DiagnosticCollector* zT_450;
    unsigned int zT_453;
    unsigned int zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_456;
    unsigned int zT_462;
    unsigned int zT_463;
    unsigned int zT_466 = 0;
    unsigned int zT_467;
    zT_8143F551_AstKind zT_468;
    zT_6B0A7D14_AstStore* zT_474;
    unsigned int zT_475;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_477 = {0};
    unsigned int zT_478;
    unsigned int zT_479;
    int zT_481;
    unsigned int zT_482;
    unsigned int zT_483;
    int zT_485;
    unsigned int zT_486;
    unsigned int zT_487;
    int zT_489;
    unsigned int zT_490;
    unsigned int zT_491;
    int zT_493;
    unsigned int zT_494;
    unsigned int zT_495;
    unsigned int zT_498;
    zT_ABC1EBBE_TypeResolveEnv zT_502;
    zT_6B0A7D14_AstStore* zT_503;
    zT_338B7C76_TypeRegistry* zT_504;
    zT_3D7259E2_SymbolRegistry* zT_505;
    zT_D3EB6303_StringInterner* zT_506;
    unsigned int zT_507;
    zT_ABC1EBBE_TypeResolveEnv* zT_508;
    unsigned int zT_509;
    unsigned int* zT_512;
    unsigned int zT_513;
    unsigned int zT_516 = 0;
    unsigned int zT_517;
    unsigned int zT_518;
    unsigned int zT_519;
    int zT_521;
    unsigned int zT_522;
    unsigned int zT_523;
    unsigned int zT_526;
    zT_38C12417_SemanticAnalyzer* zT_529;
    unsigned int zT_530;
    unsigned int* zT_531;
    unsigned int zT_532;
    unsigned int zT_534 = 0;
    unsigned int zT_535;
    unsigned int zT_536;
    unsigned int zT_537;
    unsigned int zT_541;
    unsigned int zT_543;
    zT_38C12417_SemanticAnalyzer* zT_546;
    unsigned int zT_547;
    unsigned int* zT_548;
    unsigned int zT_549;
    unsigned int zT_551 = 0;
    zT_38C12417_SemanticAnalyzer* zT_553;
    unsigned int zT_554 = 0;
    int zT_557;
    zT_338B7C76_TypeRegistry* zT_561;
    zT_D155D06D_Type* zT_562;
    unsigned int zT_563;
    zT_D155D06D_Type zT_564;
    zT_33EF6BFB_TypeKind zT_565;
    int zT_570;
    zT_33EF6BFB_TypeKind zT_571;
    char* zT_579;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_580;
    unsigned int zT_581;
    zT_F85C5DED_DiagnosticCollector* zT_582;
    unsigned int zT_585;
    unsigned int zT_586;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_588;
    unsigned int zT_597;
    unsigned int zT_598;
    unsigned int zT_601 = 0;
    unsigned int zT_602;
    unsigned int zT_603;
    unsigned int zT_607;
    unsigned int zT_609;
    zT_ABC1EBBE_TypeResolveEnv zT_613;
    zT_6B0A7D14_AstStore* zT_614;
    zT_338B7C76_TypeRegistry* zT_615;
    zT_3D7259E2_SymbolRegistry* zT_616;
    zT_D3EB6303_StringInterner* zT_617;
    unsigned int zT_618;
    zT_ABC1EBBE_TypeResolveEnv* zT_620;
    unsigned int zT_621;
    unsigned int* zT_624;
    unsigned int zT_625;
    unsigned int zT_628 = 0;
    zT_38C12417_SemanticAnalyzer* zT_631;
    unsigned int zT_632;
    unsigned int* zT_633;
    unsigned int zT_634;
    unsigned int zT_636 = 0;
    zT_338B7C76_TypeRegistry* zT_637;
    unsigned int zT_638;
    unsigned int zT_642 = 0;
    unsigned int zT_643;
    unsigned int zT_644;
    unsigned int zT_648;
    unsigned int zT_650;
    zT_ABC1EBBE_TypeResolveEnv zT_654;
    zT_6B0A7D14_AstStore* zT_655;
    zT_338B7C76_TypeRegistry* zT_656;
    zT_3D7259E2_SymbolRegistry* zT_657;
    zT_D3EB6303_StringInterner* zT_658;
    unsigned int zT_659;
    zT_ABC1EBBE_TypeResolveEnv* zT_661;
    unsigned int zT_662;
    unsigned int* zT_665;
    unsigned int zT_666;
    unsigned int zT_669 = 0;
    zT_38C12417_SemanticAnalyzer* zT_673;
    unsigned int zT_674;
    unsigned int* zT_675;
    unsigned int zT_676;
    unsigned int zT_678 = 0;
    unsigned char zT_680;
    int zT_683;
    zT_338B7C76_TypeRegistry* zT_684;
    unsigned int zT_685;
    int zT_687 = 0;
    int zT_688;
    zT_338B7C76_TypeRegistry* zT_689;
    unsigned int zT_690;
    int zT_692 = 0;
    zT_338B7C76_TypeRegistry* zT_694;
    zT_D155D06D_Type* zT_695;
    unsigned int zT_696;
    zT_D155D06D_Type zT_697;
    zT_338B7C76_TypeRegistry* zT_699;
    zT_D155D06D_Type* zT_700;
    unsigned int zT_701;
    zT_D155D06D_Type zT_702;
    unsigned char zT_703;
    int zT_706;
    unsigned char zT_707;
    int zT_710;
    unsigned int zT_711;
    unsigned int zT_712;
    unsigned char zT_714;
    char* zT_718;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_719;
    unsigned int zT_720;
    zT_F85C5DED_DiagnosticCollector* zT_721;
    unsigned int zT_724;
    unsigned int zT_725;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_727;
    unsigned int zT_736;
    unsigned int zT_737;
    unsigned int zT_740 = 0;
    unsigned int zT_741;
    unsigned int zT_742;
    unsigned int zT_744;
    unsigned int zT_745;
    unsigned int zT_746;
    unsigned int zT_749;
    zT_38C12417_SemanticAnalyzer* zT_752;
    unsigned int zT_753;
    unsigned int* zT_754;
    unsigned int zT_755;
    unsigned int zT_757 = 0;
    unsigned int zT_758;
    unsigned int zT_759;
    unsigned int zT_760;
    int zT_762;
    unsigned int zT_763;
    unsigned int zT_764;
    unsigned int zT_767;
    zT_38C12417_SemanticAnalyzer* zT_770;
    unsigned int zT_771;
    unsigned int* zT_772;
    unsigned int zT_773;
    unsigned int zT_775 = 0;
    unsigned int zT_776;
    unsigned int zT_777;
    unsigned int zT_778;
    int zT_780;
    unsigned int zT_781;
    unsigned int zT_782;
    unsigned int zT_785;
    zT_38C12417_SemanticAnalyzer* zT_788;
    unsigned int zT_789;
    unsigned int* zT_790;
    unsigned int zT_791;
    unsigned int zT_793 = 0;
    zT_38C12417_SemanticAnalyzer* zT_794;
    unsigned int zT_795;
    unsigned int* zT_796;
    unsigned int zT_797;
    unsigned int zT_799 = 0;
    unsigned int zT_801;
    zT_38C12417_SemanticAnalyzer* zT_804;
    unsigned int zT_805;
    unsigned int* zT_806;
    unsigned int zT_807;
    unsigned int zT_809 = 0;
    unsigned int zT_810;
    unsigned int zT_811;
    unsigned int zT_812;
    unsigned int zT_814;
    unsigned int zT_815;
    unsigned int zT_816;
    unsigned int zT_818;
    unsigned int zT_819;
    unsigned int zT_820;
    int zT_822;
    unsigned int zT_823;
    unsigned int zT_824;
    unsigned int zT_827;
    zT_38C12417_SemanticAnalyzer* zT_830;
    unsigned int zT_831;
    unsigned int* zT_832;
    unsigned int zT_833;
    unsigned int zT_835 = 0;
    zT_38C12417_SemanticAnalyzer* zT_836;
    unsigned int zT_837;
    unsigned int* zT_838;
    unsigned int zT_839;
    unsigned int zT_841 = 0;
    unsigned int zT_843;
    zT_38C12417_SemanticAnalyzer* zT_846;
    unsigned int zT_847;
    unsigned int* zT_848;
    unsigned int zT_849;
    unsigned int zT_851 = 0;
    unsigned int zT_852;
    unsigned int zT_854;
    zT_38C12417_SemanticAnalyzer* zT_857;
    unsigned int zT_858;
    int zT_860 = 0;
    zT_38C12417_SemanticAnalyzer* zT_861;
    unsigned int zT_862;
    unsigned int* zT_863;
    unsigned int zT_864;
    unsigned int zT_866 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_868;
    zT_6B0A7D14_AstStore* zT_869;
    zT_338B7C76_TypeRegistry* zT_870;
    zT_3D7259E2_SymbolRegistry* zT_871;
    zT_D3EB6303_StringInterner* zT_872;
    unsigned int zT_873;
    zT_ABC1EBBE_TypeResolveEnv* zT_874;
    unsigned int zT_875;
    unsigned int* zT_878;
    unsigned int zT_879;
    unsigned int zT_882 = 0;
    zT_38C12417_SemanticAnalyzer* zT_883;
    unsigned int zT_884;
    unsigned int* zT_885;
    int zT_886;
    unsigned int zT_888 = 0;
    unsigned int zT_889;
    unsigned int zT_890;
    int zT_892;
    unsigned int zT_894;
    zT_38C12417_SemanticAnalyzer* zT_898;
    unsigned int zT_899;
    unsigned int* zT_900;
    unsigned int zT_901;
    unsigned int zT_903 = 0;
    zT_338B7C76_TypeRegistry* zT_908;
    zT_D155D06D_Type* zT_909;
    unsigned int zT_910;
    zT_D155D06D_Type zT_911;
    zT_33EF6BFB_TypeKind zT_912;
    zT_338B7C76_TypeRegistry* zT_918;
    unsigned int zT_919;
    unsigned int zT_921 = 0;
    int zT_924;
    zT_338B7C76_TypeRegistry* zT_926;
    unsigned int zT_927;
    zT_338B7C76_TypeRegistry* zT_929;
    unsigned int zT_930;
    int zT_932 = 0;
    int zT_933;
    zT_338B7C76_TypeRegistry* zT_934;
    unsigned int zT_935;
    int zT_937 = 0;
    unsigned int zT_939;
    zT_38C12417_SemanticAnalyzer* zT_942;
    unsigned int zT_943;
    unsigned int* zT_944;
    int zT_945;
    unsigned int zT_947 = 0;
    unsigned int zT_948;
    zT_8143F551_AstKind zT_949;
    zT_38C12417_SemanticAnalyzer* zT_954;
    unsigned int zT_955;
    unsigned int zT_957 = 0;
    unsigned int zT_958;
    zT_8143F551_AstKind zT_959;
    int zT_964;
    zT_8143F551_AstKind zT_965;
    zT_38C12417_SemanticAnalyzer* zT_970;
    unsigned int zT_971;
    unsigned int zT_972 = 0;
    zT_8143F551_AstKind zT_973;
    zT_38C12417_SemanticAnalyzer* zT_978;
    unsigned int zT_979;
    unsigned int zT_980 = 0;
    zT_8143F551_AstKind zT_981;
    zT_38C12417_SemanticAnalyzer* zT_986;
    unsigned int zT_987;
    unsigned int zT_988 = 0;
    zT_8143F551_AstKind zT_989;
    int zT_995;
    unsigned int zT_996;
    zT_38C12417_SemanticAnalyzer* zT_997;
    unsigned int zT_998;
    unsigned int zT_1000 = 0;
    zT_338B7C76_TypeRegistry* zT_1004;
    zT_D155D06D_Type* zT_1005;
    unsigned int zT_1006;
    zT_D155D06D_Type zT_1007;
    zT_33EF6BFB_TypeKind zT_1008;
    zT_338B7C76_TypeRegistry* zT_1013;
    zT_42C2D6BF_EUPayload* zT_1014;
    unsigned int zT_1015;
    unsigned int zT_1016;
    zT_42C2D6BF_EUPayload zT_1017;
    unsigned int zT_1018;
    zT_338B7C76_TypeRegistry* zT_1019;
    zT_42C2D6BF_EUPayload* zT_1020;
    unsigned int zT_1021;
    unsigned int zT_1022;
    zT_42C2D6BF_EUPayload zT_1023;
    unsigned int zT_1024;
    zT_66E7D2EF_CoercionTable* zT_1025;
    unsigned int zT_1026;
    unsigned int zT_1028;
    unsigned int zT_1034;
    int zT_1035;
    zT_6B0A7D14_AstStore* zT_1038;
    unsigned int zT_1039;
    unsigned int zT_1043;
    unsigned int zT_1044;
    zT_38C12417_SemanticAnalyzer* zT_1046;
    zT_6B0A7D14_AstStore* zT_1047;
    unsigned int zT_1048;
    unsigned int zT_1051 = 0;
    unsigned int* zT_1052;
    unsigned int zT_1053;
    int zT_1054;
    unsigned int zT_1056;
    unsigned int* zT_1058;
    unsigned int zT_1059;
    unsigned int zT_1060;
    unsigned int zT_1063;
    int zT_1066;
    zT_6B0A7D14_AstStore* zT_1069;
    unsigned int zT_1070;
    zT_22A7C88B_AstNode zT_1073 = {0};
    zT_8143F551_AstKind zT_1074;
    zT_38C12417_SemanticAnalyzer* zT_1079;
    unsigned int zT_1080;
    zT_38C12417_SemanticAnalyzer* zT_1081;
    unsigned int zT_1082;
    unsigned int zT_1084 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1085;
    zT_38C12417_SemanticAnalyzer* zT_1086;
    unsigned int zT_1087;
    zT_8143F551_AstKind zT_1089;
    zT_38C12417_SemanticAnalyzer* zT_1094;
    unsigned int zT_1095;
    unsigned int zT_1096 = 0;
    zT_8143F551_AstKind zT_1097;
    int zT_1102;
    zT_8143F551_AstKind zT_1103;
    unsigned int zT_1108;
    zT_8143F551_AstKind zT_1109;
    int zT_1114;
    zT_8143F551_AstKind zT_1115;
    int zT_1120;
    zT_8143F551_AstKind zT_1121;
    int zT_1126;
    zT_8143F551_AstKind zT_1127;
    zT_38C12417_SemanticAnalyzer* zT_1132;
    unsigned int zT_1133;
    unsigned int zT_1134;
    zT_8143F551_AstKind zT_1135;
    zT_38C12417_SemanticAnalyzer* zT_1140;
    unsigned int zT_1141;
    unsigned int zT_1142 = 0;
    zT_8143F551_AstKind zT_1143;
    zT_38C12417_SemanticAnalyzer* zT_1148;
    unsigned int zT_1149;
    unsigned int zT_1150;
    zT_38C12417_SemanticAnalyzer* zT_1153;
    unsigned int zT_1154;
    unsigned int zT_1156;
    zT_38C12417_SemanticAnalyzer* zT_1159;
    unsigned int zT_1160;
    unsigned int zT_1162;
    zT_8143F551_AstKind zT_1163;
    zT_38C12417_SemanticAnalyzer* zT_1168;
    unsigned int zT_1169;
    unsigned int zT_1170;
    int zT_1171;
    zT_38C12417_SemanticAnalyzer* zT_1173;
    unsigned int zT_1174;
    unsigned int zT_1176;
    zT_8143F551_AstKind zT_1177;
    zT_38C12417_SemanticAnalyzer* zT_1182;
    unsigned int zT_1183;
    unsigned int zT_1184;
    int zT_1185;
    zT_38C12417_SemanticAnalyzer* zT_1187;
    unsigned int zT_1188;
    unsigned int zT_1190;
    zT_8143F551_AstKind zT_1191;
    zT_38C12417_SemanticAnalyzer* zT_1196;
    unsigned int zT_1197;
    unsigned int zT_1198 = 0;
    zT_8143F551_AstKind zT_1199;
    zT_38C12417_SemanticAnalyzer* zT_1204;
    unsigned int zT_1205;
    unsigned int zT_1206 = 0;
    zT_8143F551_AstKind zT_1207;
    zT_38C12417_SemanticAnalyzer* zT_1212;
    unsigned int zT_1213;
    unsigned int zT_1214 = 0;
    zT_8143F551_AstKind zT_1215;
    char* zT_1221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1222;
    unsigned int zT_1223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1224;
    unsigned int zT_1225;
    zT_38C12417_SemanticAnalyzer* zT_1226;
    unsigned int zT_1227;
    unsigned int zT_1228 = 0;
    zT_8143F551_AstKind zT_1229;
    int zT_1234;
    zT_8143F551_AstKind zT_1235;
    int zT_1240;
    zT_8143F551_AstKind zT_1241;
    int zT_1246;
    zT_8143F551_AstKind zT_1247;
    int zT_1252;
    zT_8143F551_AstKind zT_1253;
    int zT_1258;
    zT_8143F551_AstKind zT_1259;
    int zT_1264;
    zT_8143F551_AstKind zT_1265;
    int zT_1270;
    zT_8143F551_AstKind zT_1271;
    int zT_1276;
    zT_8143F551_AstKind zT_1277;
    int zT_1282;
    zT_8143F551_AstKind zT_1283;
    int zT_1288;
    zT_8143F551_AstKind zT_1289;
    zT_8143F551_AstKind zT_1294;
    zT_38C12417_SemanticAnalyzer* zT_1299;
    unsigned int zT_1300;
    unsigned int zT_1301;
    unsigned int zT_1303;
    zT_8143F551_AstKind zT_1304;
    zT_38C12417_SemanticAnalyzer* zT_1309;
    unsigned int zT_1310;
    unsigned int zT_1312 = 0;
    zT_8143F551_AstKind zT_1313;
    zT_38C12417_SemanticAnalyzer* zT_1318;
    unsigned int zT_1319;
    unsigned int zT_1320;
    zT_8143F551_AstKind zT_1321;
    zT_38C12417_SemanticAnalyzer* zT_1326;
    unsigned int zT_1327;
    unsigned int zT_1329 = 0;
    zT_8143F551_AstKind zT_1330;
    unsigned int zT_1335;
    zT_8143F551_AstKind zT_1336;
    char* zT_1342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1343;
    unsigned int zT_1344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1345;
    unsigned int zT_1346;
    zT_6B0A7D14_AstStore* zT_1348;
    unsigned int zT_1349;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1351 = {0};
    char* zT_1353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1354;
    unsigned int zT_1355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1356;
    unsigned int zT_1359;
    unsigned int zT_1362;
    int zT_1366;
    unsigned int zT_1367;
    unsigned int zT_1369;
    char* zT_1374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1375;
    unsigned int zT_1376;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1377;
    char* zT_1381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1382;
    unsigned int zT_1383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1384;
    unsigned int zT_1385;
    unsigned int* zT_1386;
    zT_38C12417_SemanticAnalyzer* zT_1388;
    unsigned int zT_1389;
    unsigned int* zT_1390;
    int zT_1392;
    unsigned int zT_1393;
    unsigned int* zT_1395;
    unsigned int zT_1397;
    unsigned int zT_1399;
    unsigned int zT_1400;
    zT_38C12417_SemanticAnalyzer* zT_1401;
    unsigned int zT_1402;
    unsigned int zT_1403 = 0;
    unsigned int zT_1404;
    zT_8143F551_AstKind zT_1405;
    int zT_1410;
    zT_8143F551_AstKind zT_1411;
    int zT_1416;
    zT_8143F551_AstKind zT_1417;
    int zT_1422;
    zT_8143F551_AstKind zT_1423;
    int zT_1428;
    zT_8143F551_AstKind zT_1429;
    int zT_1434;
    zT_8143F551_AstKind zT_1435;
    int zT_1440;
    zT_8143F551_AstKind zT_1441;
    int zT_1446;
    zT_8143F551_AstKind zT_1447;
    int zT_1452;
    zT_8143F551_AstKind zT_1453;
    int zT_1458;
    zT_8143F551_AstKind zT_1459;
    int zT_1464;
    zT_8143F551_AstKind zT_1465;
    zT_38C12417_SemanticAnalyzer* zT_1470;
    unsigned int zT_1471;
    zT_8143F551_AstKind zT_1472;
    unsigned int zT_1474 = 0;
    zT_8143F551_AstKind zT_1475;
    int zT_1480;
    zT_8143F551_AstKind zT_1481;
    int zT_1486;
    zT_8143F551_AstKind zT_1487;
    int zT_1492;
    zT_8143F551_AstKind zT_1493;
    int zT_1498;
    zT_8143F551_AstKind zT_1499;
    int zT_1504;
    zT_8143F551_AstKind zT_1505;
    zT_38C12417_SemanticAnalyzer* zT_1510;
    unsigned int zT_1511;
    unsigned int zT_1512 = 0;
    zT_8143F551_AstKind zT_1513;
    int zT_1518;
    zT_8143F551_AstKind zT_1519;
    zT_38C12417_SemanticAnalyzer* zT_1524;
    unsigned int zT_1525;
    unsigned int zT_1526 = 0;
    zT_8143F551_AstKind zT_1527;
    int zT_1532;
    zT_8143F551_AstKind zT_1533;
    int zT_1538;
    zT_8143F551_AstKind zT_1539;
    int zT_1544;
    zT_8143F551_AstKind zT_1545;
    int zT_1550;
    zT_8143F551_AstKind zT_1551;
    int zT_1556;
    zT_8143F551_AstKind zT_1557;
    zT_38C12417_SemanticAnalyzer* zT_1562;
    unsigned int zT_1563;
    zT_8143F551_AstKind zT_1564;
    unsigned int zT_1566 = 0;
    zT_8143F551_AstKind zT_1567;
    int zT_1572;
    zT_8143F551_AstKind zT_1573;
    int zT_1578;
    zT_8143F551_AstKind zT_1579;
    int zT_1584;
    zT_8143F551_AstKind zT_1585;
    int zT_1590;
    zT_8143F551_AstKind zT_1591;
    int zT_1596;
    zT_8143F551_AstKind zT_1597;
    int zT_1602;
    zT_8143F551_AstKind zT_1603;
    int zT_1608;
    zT_8143F551_AstKind zT_1609;
    int zT_1614;
    zT_8143F551_AstKind zT_1615;
    int zT_1620;
    zT_8143F551_AstKind zT_1621;
    int zT_1626;
    zT_8143F551_AstKind zT_1627;
    int zT_1632;
    zT_8143F551_AstKind zT_1633;
    int zT_1638;
    zT_8143F551_AstKind zT_1639;
    int zT_1644;
    zT_8143F551_AstKind zT_1645;
    int zT_1650;
    zT_8143F551_AstKind zT_1651;
    int zT_1656;
    zT_8143F551_AstKind zT_1657;
    int zT_1662;
    zT_8143F551_AstKind zT_1663;
    int zT_1668;
    zT_8143F551_AstKind zT_1669;
    zT_38C12417_SemanticAnalyzer* zT_1674;
    unsigned int zT_1675;
    unsigned int zT_1676 = 0;
    zT_8143F551_AstKind zT_1677;
    int zT_1682;
    zT_8143F551_AstKind zT_1683;
    zT_8EED1867_ResolvedTypeTable* zT_1688;
    unsigned int zT_1689;
    char* zT_1695;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1696;
    unsigned int zT_1697;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1698;
    unsigned int zT_1699;
    zT_8143F551_AstKind zT_1701;
    unsigned int zT_1702;
    char* zT_1704;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1705;
    unsigned int zT_1706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1707;
    unsigned int zT_1708;
    char* zT_1710;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1711;
    unsigned int zT_1712;
    zT_F85C5DED_DiagnosticCollector* zT_1713;
    unsigned int zT_1716;
    unsigned int zT_1717;
    unsigned int zT_1718;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1719;
    unsigned int zT_1724 = 0;
    char* zT_1727;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1728;
    unsigned int zT_1729;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1730;
    unsigned int zT_1731;
    zT_8143F551_AstKind zT_1733;
    unsigned int zT_1734;
    char* zT_1736;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1737;
    unsigned int zT_1738;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1739;
    unsigned int zT_1740;
    char* zT_1742;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1743;
    unsigned int zT_1744;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1745;
    unsigned int zT_1746;
    char* zT_1748;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1749;
    unsigned int zT_1750;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1751;
    unsigned int zT_1752;
    zT_8143F551_AstKind zT_1754;
    unsigned int zT_1755;
    char* zT_1757;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1758;
    unsigned int zT_1759;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1760;
    unsigned int zT_1761;
    char* zT_1763;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1764;
    unsigned int zT_1765;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1766;
    unsigned int zT_1767;
    zT_8EED1867_ResolvedTypeTable* zT_1768;
    unsigned int zT_1769;
    unsigned int zT_1770;
    char* zT_1773;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1774;
    unsigned int zT_1775;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1776;
    unsigned int zT_1777;
    char* zT_1779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1780;
    unsigned int zT_1781;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1782;
    unsigned int zT_1783;
    unsigned int result;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rx_sw_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rxs_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_m;
    unsigned int stx_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_nm;
    unsigned int a4_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_rm;
    unsigned int top;
    unsigned int es;
    zT_D155D06D_Type tty;
    unsigned int eff_top;
    unsigned int opt_pay;
    unsigned int name_id;
    unsigned int ord;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u fad;
    unsigned int base;
    zT_D155D06D_Type bt;
    zT_112BF819_PtrPayload pp;
    zT_22A7C88B_AstNode base_node;
    unsigned int fa_base_t;
    unsigned int st;
    zT_D155D06D_Type st_ty;
    unsigned int sd;
    unsigned int aps;
    unsigned int ape;
    zT_8F083A69_Slice_zT_0B42B2F8_u aof_msg;
    unsigned int apu_s;
    unsigned int apu_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u aou_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ub_msg;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    zT_ABC1EBBE_TypeResolveEnv so_env;
    unsigned int pfi_res;
    unsigned int pfi_top;
    zT_D155D06D_Type pfi_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_msg;
    unsigned int fpp_res;
    zT_ABC1EBBE_TypeResolveEnv fpp_env;
    unsigned int fpp_outer;
    unsigned int bc_res;
    zT_ABC1EBBE_TypeResolveEnv bc_env;
    unsigned int bc_dst;
    unsigned int bc_src;
    unsigned char bc_ok;
    zT_D155D06D_Type bc_dty;
    zT_D155D06D_Type bc_sty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_msg;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int e2i_arg;
    unsigned int e2i_res;
    zT_D155D06D_Type e2i_ty;
    unsigned int e2i_bt;
    unsigned int catch_es;
    zT_D155D06D_Type clt;
    zT_22A7C88B_AstNode child1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ai_dbg;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_m;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm2;
    unsigned int last_child;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_m;
    unsigned int st_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u unr_msg;
    zT_3 = 0;
    result = zT_3;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return result;
    z_bb_2:
    zT_7 = self->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = 1;
    result = zT_11;
    zT_12 = node.kind;
    if ((int)(zT_12 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = "RXS";
    zT_20 = 3;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rx_sw_m = zT_19;
    zT_21 = rx_sw_m;
    zF_48AC7B3A_markerWrite(zT_21);
    zT_23 = "RXS:n";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    rxs_nm = zT_24;
    zT_26 = rxs_nm;
    zT_27 = node_idx;
    zF_C914CB83_markerWriteInt(zT_26, zT_27);
    goto z_bb_4;
    z_bb_4:
    zT_28 = node.kind;
    if ((int)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_33 = 19;
    result = zT_33;
    goto z_bb_6;
    z_bb_6:
    zT_1727 = "STX:n";
    zT_1729 = 5;
    zT_1728.ptr = zT_1727;
    zT_1728.len = zT_1729;
    stx_m = zT_1728;
    zT_1730 = stx_m;
    zT_1731 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1730, zT_1731);
    zT_1733 = node.kind;
    zT_1734 = (unsigned int)zT_1733;
    stx_kv = zT_1734;
    zT_1736 = "STX:k";
    zT_1738 = 5;
    zT_1737.ptr = zT_1736;
    zT_1737.len = zT_1738;
    stx_km = zT_1737;
    zT_1739 = stx_km;
    zT_1740 = stx_kv;
    zF_C914CB83_markerWriteInt(zT_1739, zT_1740);
    zT_1742 = "STX:r";
    zT_1744 = 5;
    zT_1743.ptr = zT_1742;
    zT_1743.len = zT_1744;
    stx_rm = zT_1743;
    zT_1745 = stx_rm;
    zT_1746 = result;
    zF_C914CB83_markerWriteInt(zT_1745, zT_1746);
    zT_1748 = "A4:N";
    zT_1750 = 4;
    zT_1749.ptr = zT_1748;
    zT_1749.len = zT_1750;
    a4_nm = zT_1749;
    zT_1751 = a4_nm;
    zT_1752 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1751, zT_1752);
    zT_1754 = node.kind;
    zT_1755 = (unsigned int)zT_1754;
    a4_kv = zT_1755;
    zT_1757 = "A4:K";
    zT_1759 = 4;
    zT_1758.ptr = zT_1757;
    zT_1758.len = zT_1759;
    a4_km = zT_1758;
    zT_1760 = a4_km;
    zT_1761 = a4_kv;
    zF_C914CB83_markerWriteInt(zT_1760, zT_1761);
    zT_1763 = "A4:R";
    zT_1765 = 4;
    zT_1764.ptr = zT_1763;
    zT_1764.len = zT_1765;
    a4_rm = zT_1764;
    zT_1766 = a4_rm;
    zT_1767 = result;
    zF_C914CB83_markerWriteInt(zT_1766, zT_1767);
    zT_1768 = self->type_table;
    zT_1769 = node_idx;
    zT_1770 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_1768, zT_1769, zT_1770);
    zT_1773 = "STB:N";
    zT_1775 = 5;
    zT_1774.ptr = zT_1773;
    zT_1774.len = zT_1775;
    stb_nm = zT_1774;
    zT_1776 = stb_nm;
    zT_1777 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1776, zT_1777);
    zT_1779 = "STB:R";
    zT_1781 = 5;
    zT_1780.ptr = zT_1779;
    zT_1780.len = zT_1781;
    stb_rm = zT_1780;
    zT_1782 = stb_rm;
    zT_1783 = result;
    zF_C914CB83_markerWriteInt(zT_1782, zT_1783);
    return result;
    z_bb_7:
    zT_34 = node.kind;
    if ((int)(zT_34 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_39 = 16;
    result = zT_39;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_40 = node.kind;
    if ((int)(zT_40 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_45 = 8;
    result = zT_45;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_46 = node.kind;
    if ((int)(zT_46 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_51 = 2;
    result = zT_51;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_52 = node.kind;
    if ((int)(zT_52 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_57 = 17;
    result = zT_57;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_58 = node.kind;
    if ((int)(zT_58 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_63 = 18;
    result = zT_63;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_64 = node.kind;
    if ((int)(zT_64 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_unreachable_expr))) goto z_bb_23; else goto z_bb_25;
    z_bb_23:
    zT_69 = 3;
    result = zT_69;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_70 = node.kind;
    if ((int)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_75 = self->registry;
    zT_81 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_75, (unsigned int)(14), (int)(1));
    result = zT_81;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_82 = node.kind;
    if ((int)(zT_82 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    zT_87 = self;
    zT_88 = node_idx;
    zT_89 = zF_8C008E53_semanticAnalyzerRes(zT_87, zT_88);
    result = zT_89;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_90 = node.kind;
    if ((int)(zT_90 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_95 = self->expected_type_stack_len;
    zT_96 = 0;
    if ((int)(zT_95 > (unsigned int)zT_96)) goto z_bb_35; else goto z_bb_37;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_213 = node.kind;
    if ((int)(zT_213 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_57; else goto z_bb_59;
    z_bb_35:
    zT_99 = self->expected_type_stack_items;
    zT_100 = self->expected_type_stack_len;
    zT_101 = 1;
    zT_102 = zT_100 - zT_101;
    zT_103 = zT_99[zT_102];
    top = zT_103;
    zT_104 = 0;
    if ((int)(top != (unsigned int)zT_104)) goto z_bb_38; else goto z_bb_40;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_212 = 1;
    result = zT_212;
    goto z_bb_36;
    z_bb_38:
    zT_107 = 0;
    zT_108 = (unsigned int)zT_107;
    es = zT_108;
    zT_110 = self->registry;
    zT_111 = zT_110->types_items;
    zT_112 = (unsigned int)top;
    zT_113 = zT_111[zT_112];
    tty = zT_113;
    eff_top = top;
    zT_115 = tty.kind;
    if ((int)(zT_115 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_211 = 1;
    result = zT_211;
    goto z_bb_39;
    z_bb_41:
    zT_121 = self->registry;
    zT_122 = zT_121->opt_items;
    zT_123 = tty.payload_idx;
    zT_124 = (unsigned int)zT_123;
    zT_125 = zT_122[zT_124];
    zT_126 = zT_125.payload;
    opt_pay = zT_126;
    zT_127 = self->registry;
    zT_128 = zT_127->types_items;
    zT_129 = (unsigned int)opt_pay;
    zT_130 = zT_128[zT_129];
    tty = zT_130;
    eff_top = opt_pay;
    goto z_bb_42;
    z_bb_42:
    zT_131 = tty.kind;
    if ((int)(zT_131 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_43; else goto z_bb_45;
    z_bb_43:
    es = eff_top;
    goto z_bb_44;
    z_bb_44:
    zT_147 = 0;
    if ((int)(es != (unsigned int)zT_147)) goto z_bb_48; else goto z_bb_50;
    z_bb_45:
    zT_136 = tty.kind;
    if ((int)(zT_136 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_141 = self->registry;
    zT_142 = zT_141->eu_items;
    zT_143 = tty.payload_idx;
    zT_144 = (unsigned int)zT_143;
    zT_145 = zT_142[zT_144];
    zT_146 = zT_145.error_set;
    es = zT_146;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_150 = self->store;
    zT_151 = node_idx;
    zT_153 = zF_8BA26B9E_astStoreNodePayload(zT_150, zT_151);
    name_id = zT_153;
    zT_155 = self->registry;
    zT_156 = es;
    zT_157 = name_id;
    zT_159 = zF_D2ECD176_typeRegistryErrorSe(zT_155, zT_156, zT_157);
    ord = zT_159;
    if ((int)(ord != (unsigned int)(4294967295u))) goto z_bb_51; else goto z_bb_53;
    z_bb_49:
    goto z_bb_39;
    z_bb_50:
    zT_201 = tty.kind;
    if ((int)(zT_201 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_54; else goto z_bb_56;
    z_bb_51:
    zT_163 = self->error_code_registry;
    zT_164 = name_id;
    zT_166 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_163, zT_164);
    reg_code = zT_166;
    zT_167 = self->enum_value_table;
    zT_168 = node_idx;
    zT_169 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_167, zT_168, zT_169);
    zT_171 = self->type_table;
    zT_172 = node_idx;
    zT_173 = es;
    zF_19B4A07D_resolvedTypeTableSe(zT_171, zT_172, zT_173);
    result = es;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_176 = node.span_start;
    sp = zT_176;
    zT_178 = node.span_len;
    zT_180 = sp + (unsigned int)((unsigned int)zT_178);
    ep = zT_180;
    zT_182 = "error literal not found in error set";
    zT_184 = 36;
    zT_183.ptr = zT_182;
    zT_183.len = zT_184;
    eln_msg = zT_183;
    zT_185 = self->diag;
    zT_188 = self->source_file_id;
    zT_189 = sp;
    zT_190 = ep;
    zT_191 = eln_msg;
    zT_199 = zF_C82559AC_diagnosticCollector(zT_185, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3011_ERROR_LITERAL_NOT_IN_SET)), zT_188, zT_189, zT_190, zT_191);
    (void)zT_199;
    zT_200 = 1;
    result = zT_200;
    goto z_bb_52;
    z_bb_54:
    zT_206 = self->type_table;
    zT_207 = node_idx;
    zT_208 = eff_top;
    zF_19B4A07D_resolvedTypeTableSe(zT_206, zT_207, zT_208);
    result = eff_top;
    goto z_bb_55;
    z_bb_55:
    goto z_bb_49;
    z_bb_56:
    zT_210 = 1;
    result = zT_210;
    goto z_bb_55;
    z_bb_57:
    zT_218 = self;
    zT_219 = self->module_id;
    zT_223 = self->store;
    zT_224 = node_idx;
    zT_226 = zF_53458827_astStoreIdentifier(zT_223, zT_224);
    zT_220 = zT_226;
    zT_221 = node_idx;
    zT_227 = zF_9F1ECA79_semanticAnalyzerRes(zT_218, zT_219, zT_220, zT_221);
    result = zT_227;
    goto z_bb_58;
    z_bb_58:
    goto z_bb_33;
    z_bb_59:
    zT_228 = node.kind;
    if ((int)(zT_228 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_60; else goto z_bb_62;
    z_bb_60:
    zT_233 = self;
    zT_234 = node_idx;
    zT_235 = zF_DDD991E1_semanticAnalyzerRes(zT_233, zT_234);
    result = zT_235;
    zT_237 = "FAD:R";
    zT_239 = 5;
    zT_238.ptr = zT_237;
    zT_238.len = zT_239;
    fad = zT_238;
    zT_240 = fad;
    zT_241 = result;
    zF_C914CB83_markerWriteInt(zT_240, zT_241);
    goto z_bb_61;
    z_bb_61:
    goto z_bb_58;
    z_bb_62:
    zT_242 = node.kind;
    if ((int)(zT_242 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_63; else goto z_bb_65;
    z_bb_63:
    zT_247 = self;
    zT_248 = node_idx;
    zT_249 = zF_1926BC05_semanticAnalyzerRes(zT_247, zT_248);
    result = zT_249;
    goto z_bb_64;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_250 = node.kind;
    if ((int)(zT_250 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_66; else goto z_bb_68;
    z_bb_66:
    zT_255 = self;
    zT_256 = node_idx;
    zT_257 = zF_F902E73E_semanticAnalyzerRes(zT_255, zT_256);
    result = zT_257;
    goto z_bb_67;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_258 = node.kind;
    if ((int)(zT_258 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    zT_264 = self;
    zT_265 = node.child_0;
    zT_267 = zF_54F95822_semanticAnalyzerRes(zT_264, zT_265);
    base = zT_267;
    if ((int)(base != (unsigned int)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_70:
    goto z_bb_67;
    z_bb_71:
    zT_297 = node.kind;
    if ((int)(zT_297 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_84; else goto z_bb_86;
    z_bb_72:
    zT_270 = base != (unsigned int)(1);
    goto z_bb_74;
    z_bb_73:
    zT_270 = 0;
    goto z_bb_74;
    z_bb_74:
    if (zT_270) goto z_bb_75; else goto z_bb_77;
    z_bb_75:
    zT_274 = self->registry;
    zT_275 = zT_274->types_items;
    zT_276 = (unsigned int)base;
    zT_277 = zT_275[zT_276];
    bt = zT_277;
    zT_278 = bt.kind;
    if ((int)(zT_278 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_79; else goto z_bb_78;
    z_bb_76:
    goto z_bb_70;
    z_bb_77:
    zT_296 = 1;
    result = zT_296;
    goto z_bb_76;
    z_bb_78:
    zT_284 = bt.kind;
    zT_283 = zT_284 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_80;
    z_bb_79:
    zT_283 = 1;
    goto z_bb_80;
    z_bb_80:
    if (zT_283) goto z_bb_81; else goto z_bb_83;
    z_bb_81:
    zT_290 = self->registry;
    zT_291 = zT_290->ptr_items;
    zT_292 = bt.payload_idx;
    zT_293 = (unsigned int)zT_292;
    zT_294 = zT_291[zT_293];
    pp = zT_294;
    zT_295 = pp.base;
    result = zT_295;
    goto z_bb_82;
    z_bb_82:
    goto z_bb_76;
    z_bb_83:
    result = base;
    goto z_bb_82;
    z_bb_84:
    zT_303 = self;
    zT_304 = node.child_0;
    zT_306 = zF_54F95822_semanticAnalyzerRes(zT_303, zT_304);
    base = zT_306;
    if ((int)(base != (unsigned int)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    goto z_bb_70;
    z_bb_86:
    zT_427 = node.kind;
    if ((int)(zT_427 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_111; else goto z_bb_113;
    z_bb_87:
    zT_309 = base != (unsigned int)(1);
    goto z_bb_89;
    z_bb_88:
    zT_309 = 0;
    goto z_bb_89;
    z_bb_89:
    if (zT_309) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    zT_313 = self->store;
    zT_314 = node.child_0;
    zT_317 = zF_FCDD1D35_astStoreNodeAt(zT_313, zT_314);
    base_node = zT_317;
    zT_318 = base_node.kind;
    if ((int)(zT_318 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_93; else goto z_bb_94;
    z_bb_91:
    goto z_bb_85;
    z_bb_92:
    zT_426 = 1;
    result = zT_426;
    goto z_bb_91;
    z_bb_93:
    zT_324 = self;
    zT_325 = base_node.child_0;
    zT_327 = zF_54F95822_semanticAnalyzerRes(zT_324, zT_325);
    fa_base_t = zT_327;
    st = fa_base_t;
    if ((int)(fa_base_t != (unsigned int)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    zT_420 = self->registry;
    zT_421 = base;
    zT_425 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_420, zT_421, (int)(0));
    result = zT_425;
    goto z_bb_91;
    z_bb_95:
    zT_331 = fa_base_t != (unsigned int)(1);
    goto z_bb_97;
    z_bb_96:
    zT_331 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_331) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_335 = self->registry;
    zT_336 = zT_335->types_items;
    zT_337 = (unsigned int)st;
    zT_338 = zT_336[zT_337];
    st_ty = zT_338;
    zT_339 = st_ty.kind;
    if ((int)(zT_339 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_101; else goto z_bb_100;
    z_bb_99:
    goto z_bb_94;
    z_bb_100:
    zT_345 = st_ty.kind;
    zT_344 = zT_345 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_102;
    z_bb_101:
    zT_344 = 1;
    goto z_bb_102;
    z_bb_102:
    if (zT_344) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_350 = self->registry;
    zT_351 = zT_350->ptr_items;
    zT_352 = st_ty.payload_idx;
    zT_353 = (unsigned int)zT_352;
    zT_354 = zT_351[zT_353];
    zT_355 = zT_354.base;
    st = zT_355;
    zT_356 = self->registry;
    zT_357 = zT_356->types_items;
    zT_358 = (unsigned int)st;
    zT_359 = zT_357[zT_358];
    st_ty = zT_359;
    goto z_bb_104;
    z_bb_104:
    zT_360 = st_ty.kind;
    if ((int)(zT_360 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_366 = self;
    zT_367 = st;
    zT_368 = zF_1BB4D489_semanticAnalyzerPac(zT_366, zT_367);
    sd = zT_368;
    if ((int)(sd != (unsigned int)(0))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_393 = st_ty.kind;
    if ((int)(zT_393 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_109; else goto z_bb_110;
    z_bb_107:
    zT_372 = node.span_start;
    aps = zT_372;
    zT_374 = node.span_len;
    zT_376 = aps + (unsigned int)((unsigned int)zT_374);
    ape = zT_376;
    zT_378 = "cannot take the address of a field of a packed struct; packed fields have no address";
    zT_380 = 84;
    zT_379.ptr = zT_378;
    zT_379.len = zT_380;
    aof_msg = zT_379;
    zT_381 = self->diag;
    zT_384 = self->source_file_id;
    zT_385 = aps;
    zT_386 = ape;
    zT_387 = aof_msg;
    zT_392 = zF_C82559AC_diagnosticCollector(zT_381, (unsigned char)(0), (unsigned short)(3000), zT_384, zT_385, zT_386, zT_387);
    (void)zT_392;
    goto z_bb_108;
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_399 = node.span_start;
    apu_s = zT_399;
    zT_401 = node.span_len;
    zT_403 = apu_s + (unsigned int)((unsigned int)zT_401);
    apu_e = zT_403;
    zT_405 = "cannot take the address of a field of a packed union; packed fields have no address";
    zT_407 = 83;
    zT_406.ptr = zT_405;
    zT_406.len = zT_407;
    aou_msg = zT_406;
    zT_408 = self->diag;
    zT_411 = self->source_file_id;
    zT_412 = apu_s;
    zT_413 = apu_e;
    zT_414 = aou_msg;
    zT_419 = zF_C82559AC_diagnosticCollector(zT_408, (unsigned char)(0), (unsigned short)(3000), zT_411, zT_412, zT_413, zT_414);
    (void)zT_419;
    goto z_bb_110;
    z_bb_110:
    goto z_bb_99;
    z_bb_111:
    zT_432 = self;
    zT_433 = node_idx;
    zT_434 = zF_87E78775_semanticAnalyzerRes(zT_432, zT_433);
    result = zT_434;
    goto z_bb_112;
    z_bb_112:
    goto z_bb_85;
    z_bb_113:
    zT_435 = node.kind;
    if ((int)(zT_435 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_441 = self;
    zT_442 = node.child_0;
    zT_444 = zF_CAF1FD28_semanticAnalyzerIsB(zT_441, zT_442);
    zT_440 = !zT_444;
    goto z_bb_116;
    z_bb_115:
    zT_440 = 0;
    goto z_bb_116;
    z_bb_116:
    if (zT_440) goto z_bb_117; else goto z_bb_119;
    z_bb_117:
    zT_447 = "unsupported builtin function";
    zT_449 = 28;
    zT_448.ptr = zT_447;
    zT_448.len = zT_449;
    ub_msg = zT_448;
    zT_450 = self->diag;
    zT_453 = self->source_file_id;
    zT_454 = node.span_start;
    zT_462 = node.span_start;
    zT_463 = node.span_len;
    zT_456 = ub_msg;
    zT_466 = zF_C82559AC_diagnosticCollector(zT_450, (unsigned char)(0), (unsigned short)(3000), zT_453, zT_454, (unsigned int)(zT_462 + (unsigned int)((unsigned int)zT_463)), zT_456);
    (void)zT_466;
    zT_467 = 1;
    result = zT_467;
    goto z_bb_118;
    z_bb_118:
    goto z_bb_112;
    z_bb_119:
    zT_468 = node.kind;
    if ((int)(zT_468 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_120; else goto z_bb_122;
    z_bb_120:
    zT_474 = self->store;
    zT_475 = node_idx;
    zT_477 = zF_850FDF81_astStoreNodeExtraCh(zT_474, zT_475);
    ec = zT_477;
    zT_478 = node.child_0;
    zT_479 = self->size_of_name_id;
    if ((int)(zT_478 == zT_479)) goto z_bb_124; else goto z_bb_123;
    z_bb_121:
    goto z_bb_118;
    z_bb_122:
    zT_949 = node.kind;
    if ((int)(zT_949 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_270; else goto z_bb_272;
    z_bb_123:
    zT_482 = node.child_0;
    zT_483 = self->align_of_name_id;
    zT_481 = zT_482 == zT_483;
    goto z_bb_125;
    z_bb_124:
    zT_481 = 1;
    goto z_bb_125;
    z_bb_125:
    if (zT_481) goto z_bb_127; else goto z_bb_126;
    z_bb_126:
    zT_486 = node.child_0;
    zT_487 = self->offset_of_name_id;
    zT_485 = zT_486 == zT_487;
    goto z_bb_128;
    z_bb_127:
    zT_485 = 1;
    goto z_bb_128;
    z_bb_128:
    if (zT_485) goto z_bb_130; else goto z_bb_129;
    z_bb_129:
    zT_490 = node.child_0;
    zT_491 = self->bit_size_of_name_id;
    zT_489 = zT_490 == zT_491;
    goto z_bb_131;
    z_bb_130:
    zT_489 = 1;
    goto z_bb_131;
    z_bb_131:
    if (zT_489) goto z_bb_133; else goto z_bb_132;
    z_bb_132:
    zT_494 = node.child_0;
    zT_495 = self->bit_offset_of_name_id;
    zT_493 = zT_494 == zT_495;
    goto z_bb_134;
    z_bb_133:
    zT_493 = 1;
    goto z_bb_134;
    z_bb_134:
    if (zT_493) goto z_bb_135; else goto z_bb_137;
    z_bb_135:
    zT_498 = ec.len;
    if ((int)(zT_498 >= (unsigned int)(1))) goto z_bb_138; else goto z_bb_139;
    z_bb_136:
    goto z_bb_121;
    z_bb_137:
    zT_518 = node.child_0;
    zT_519 = self->ptrtoint_name_id;
    if ((int)(zT_518 == zT_519)) goto z_bb_141; else goto z_bb_140;
    z_bb_138:
    zT_503 = self->store;
    zT_502.store = zT_503;
    zT_504 = self->registry;
    zT_502.typereg = zT_504;
    zT_505 = self->symbols;
    zT_502.symbol_reg = zT_505;
    zT_506 = self->interner;
    zT_502.interner = zT_506;
    zT_507 = self->module_id;
    zT_502.module_id = zT_507;
    so_env = zT_502;
    zT_508 = &so_env;
    zT_512 = ec.ptr;
    zT_513 = 0;
    zT_509 = zT_512[zT_513];
    zT_516 = zF_F2107C15_resolveTypeExprFull(zT_508, zT_509, (unsigned int)(0));
    (void)zT_516;
    goto z_bb_139;
    z_bb_139:
    zT_517 = 19;
    result = zT_517;
    goto z_bb_136;
    z_bb_140:
    zT_522 = node.child_0;
    zT_523 = self->int_from_ptr_name_id;
    zT_521 = zT_522 == zT_523;
    goto z_bb_142;
    z_bb_141:
    zT_521 = 1;
    goto z_bb_142;
    z_bb_142:
    if (zT_521) goto z_bb_143; else goto z_bb_145;
    z_bb_143:
    zT_526 = ec.len;
    if ((int)(zT_526 >= (unsigned int)(1))) goto z_bb_146; else goto z_bb_147;
    z_bb_144:
    goto z_bb_136;
    z_bb_145:
    zT_536 = node.child_0;
    zT_537 = self->ptr_from_int_name_id;
    if ((int)(zT_536 == zT_537)) goto z_bb_148; else goto z_bb_150;
    z_bb_146:
    zT_529 = self;
    zT_531 = ec.ptr;
    zT_532 = 0;
    zT_530 = zT_531[zT_532];
    zT_534 = zF_54F95822_semanticAnalyzerRes(zT_529, zT_530);
    (void)zT_534;
    goto z_bb_147;
    z_bb_147:
    zT_535 = 13;
    result = zT_535;
    goto z_bb_144;
    z_bb_148:
    zT_541 = 1;
    pfi_res = zT_541;
    zT_543 = ec.len;
    if ((int)(zT_543 >= (unsigned int)(1))) goto z_bb_151; else goto z_bb_152;
    z_bb_149:
    goto z_bb_144;
    z_bb_150:
    zT_602 = node.child_0;
    zT_603 = self->field_parent_ptr_name_id;
    if ((int)(zT_602 == zT_603)) goto z_bb_165; else goto z_bb_167;
    z_bb_151:
    zT_546 = self;
    zT_548 = ec.ptr;
    zT_549 = 0;
    zT_547 = zT_548[zT_549];
    zT_551 = zF_54F95822_semanticAnalyzerRes(zT_546, zT_547);
    (void)zT_551;
    zT_553 = self;
    zT_554 = zF_4DE7C2BC_topExpectedType(zT_553);
    pfi_top = zT_554;
    if ((int)(pfi_top != (unsigned int)(0))) goto z_bb_153; else goto z_bb_154;
    z_bb_152:
    if ((int)(pfi_res == (unsigned int)(1))) goto z_bb_163; else goto z_bb_164;
    z_bb_153:
    zT_557 = pfi_top != (unsigned int)(18);
    goto z_bb_155;
    z_bb_154:
    zT_557 = 0;
    goto z_bb_155;
    z_bb_155:
    if (zT_557) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_561 = self->registry;
    zT_562 = zT_561->types_items;
    zT_563 = (unsigned int)pfi_top;
    zT_564 = zT_562[zT_563];
    pfi_ty = zT_564;
    zT_565 = pfi_ty.kind;
    if ((int)(zT_565 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_159; else goto z_bb_158;
    z_bb_157:
    goto z_bb_152;
    z_bb_158:
    zT_571 = pfi_ty.kind;
    zT_570 = zT_571 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_160;
    z_bb_159:
    zT_570 = 1;
    goto z_bb_160;
    z_bb_160:
    if (zT_570) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    pfi_res = pfi_top;
    goto z_bb_162;
    z_bb_162:
    goto z_bb_157;
    z_bb_163:
    zT_579 = "cannot infer pointer type for @ptrFromInt; annotate the target variable type";
    zT_581 = 76;
    zT_580.ptr = zT_579;
    zT_580.len = zT_581;
    pfi_msg = zT_580;
    zT_582 = self->diag;
    zT_585 = self->source_file_id;
    zT_586 = node.span_start;
    zT_597 = node.span_start;
    zT_598 = node.span_len;
    zT_588 = pfi_msg;
    zT_601 = zF_C82559AC_diagnosticCollector(zT_582, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_585, zT_586, (unsigned int)(zT_597 + (unsigned int)((unsigned int)zT_598)), zT_588);
    (void)zT_601;
    goto z_bb_164;
    z_bb_164:
    result = pfi_res;
    goto z_bb_149;
    z_bb_165:
    zT_607 = 1;
    fpp_res = zT_607;
    zT_609 = ec.len;
    if ((int)(zT_609 >= (unsigned int)(3))) goto z_bb_168; else goto z_bb_169;
    z_bb_166:
    goto z_bb_149;
    z_bb_167:
    zT_643 = node.child_0;
    zT_644 = self->bitcast_name_id;
    if ((int)(zT_643 == zT_644)) goto z_bb_172; else goto z_bb_174;
    z_bb_168:
    zT_614 = self->store;
    zT_613.store = zT_614;
    zT_615 = self->registry;
    zT_613.typereg = zT_615;
    zT_616 = self->symbols;
    zT_613.symbol_reg = zT_616;
    zT_617 = self->interner;
    zT_613.interner = zT_617;
    zT_618 = self->module_id;
    zT_613.module_id = zT_618;
    fpp_env = zT_613;
    zT_620 = &fpp_env;
    zT_624 = ec.ptr;
    zT_625 = 0;
    zT_621 = zT_624[zT_625];
    zT_628 = zF_F2107C15_resolveTypeExprFull(zT_620, zT_621, (unsigned int)(0));
    fpp_outer = zT_628;
    if ((int)(fpp_outer != (unsigned int)(18))) goto z_bb_170; else goto z_bb_171;
    z_bb_169:
    result = fpp_res;
    goto z_bb_166;
    z_bb_170:
    zT_631 = self;
    zT_633 = ec.ptr;
    zT_634 = 2;
    zT_632 = zT_633[zT_634];
    zT_636 = zF_54F95822_semanticAnalyzerRes(zT_631, zT_632);
    (void)zT_636;
    zT_637 = self->registry;
    zT_638 = fpp_outer;
    zT_642 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_637, zT_638, (int)(0));
    fpp_res = zT_642;
    goto z_bb_171;
    z_bb_171:
    goto z_bb_169;
    z_bb_172:
    zT_648 = 1;
    bc_res = zT_648;
    zT_650 = ec.len;
    if ((int)(zT_650 >= (unsigned int)(2))) goto z_bb_175; else goto z_bb_176;
    z_bb_173:
    goto z_bb_166;
    z_bb_174:
    zT_741 = node.child_0;
    zT_742 = self->getchar_name_id;
    if ((int)(zT_741 == zT_742)) goto z_bb_197; else goto z_bb_199;
    z_bb_175:
    zT_655 = self->store;
    zT_654.store = zT_655;
    zT_656 = self->registry;
    zT_654.typereg = zT_656;
    zT_657 = self->symbols;
    zT_654.symbol_reg = zT_657;
    zT_658 = self->interner;
    zT_654.interner = zT_658;
    zT_659 = self->module_id;
    zT_654.module_id = zT_659;
    bc_env = zT_654;
    zT_661 = &bc_env;
    zT_665 = ec.ptr;
    zT_666 = 0;
    zT_662 = zT_665[zT_666];
    zT_669 = zF_F2107C15_resolveTypeExprFull(zT_661, zT_662, (unsigned int)(0));
    bc_dst = zT_669;
    if ((int)(bc_dst != (unsigned int)(18))) goto z_bb_177; else goto z_bb_178;
    z_bb_176:
    result = bc_res;
    goto z_bb_173;
    z_bb_177:
    zT_673 = self;
    zT_675 = ec.ptr;
    zT_676 = 1;
    zT_674 = zT_675[zT_676];
    zT_678 = zF_54F95822_semanticAnalyzerRes(zT_673, zT_674);
    bc_src = zT_678;
    zT_680 = 0;
    bc_ok = zT_680;
    if ((int)(bc_src != (unsigned int)(18))) goto z_bb_179; else goto z_bb_180;
    z_bb_178:
    goto z_bb_176;
    z_bb_179:
    zT_684 = self->registry;
    zT_685 = bc_dst;
    zT_687 = zF_3290E9C4_typeRegistryIsInteg(zT_684, zT_685);
    zT_683 = zT_687;
    goto z_bb_181;
    z_bb_180:
    zT_683 = 0;
    goto z_bb_181;
    z_bb_181:
    if (zT_683) goto z_bb_182; else goto z_bb_183;
    z_bb_182:
    zT_689 = self->registry;
    zT_690 = bc_src;
    zT_692 = zF_3290E9C4_typeRegistryIsInteg(zT_689, zT_690);
    zT_688 = zT_692;
    goto z_bb_184;
    z_bb_183:
    zT_688 = 0;
    goto z_bb_184;
    z_bb_184:
    if (zT_688) goto z_bb_185; else goto z_bb_186;
    z_bb_185:
    zT_694 = self->registry;
    zT_695 = zT_694->types_items;
    zT_696 = (unsigned int)bc_dst;
    zT_697 = zT_695[zT_696];
    bc_dty = zT_697;
    zT_699 = self->registry;
    zT_700 = zT_699->types_items;
    zT_701 = (unsigned int)bc_src;
    zT_702 = zT_700[zT_701];
    bc_sty = zT_702;
    zT_703 = bc_dty.state;
    if ((int)(zT_703 == (unsigned char)(2))) goto z_bb_187; else goto z_bb_188;
    z_bb_186:
    bc_res = bc_dst;
    if ((int)(bc_ok == (unsigned char)(0))) goto z_bb_195; else goto z_bb_196;
    z_bb_187:
    zT_707 = bc_sty.state;
    zT_706 = zT_707 == (unsigned char)(2);
    goto z_bb_189;
    z_bb_188:
    zT_706 = 0;
    goto z_bb_189;
    z_bb_189:
    if (zT_706) goto z_bb_190; else goto z_bb_191;
    z_bb_190:
    zT_711 = bc_dty.size;
    zT_712 = bc_sty.size;
    zT_710 = zT_711 == zT_712;
    goto z_bb_192;
    z_bb_191:
    zT_710 = 0;
    goto z_bb_192;
    z_bb_192:
    if (zT_710) goto z_bb_193; else goto z_bb_194;
    z_bb_193:
    zT_714 = 1;
    bc_ok = zT_714;
    goto z_bb_194;
    z_bb_194:
    goto z_bb_186;
    z_bb_195:
    zT_718 = "@bitCast requires same-size integer source and destination types";
    zT_720 = 64;
    zT_719.ptr = zT_718;
    zT_719.len = zT_720;
    bc_msg = zT_719;
    zT_721 = self->diag;
    zT_724 = self->source_file_id;
    zT_725 = node.span_start;
    zT_736 = node.span_start;
    zT_737 = node.span_len;
    zT_727 = bc_msg;
    zT_740 = zF_C82559AC_diagnosticCollector(zT_721, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_724, zT_725, (unsigned int)(zT_736 + (unsigned int)((unsigned int)zT_737)), zT_727);
    (void)zT_740;
    goto z_bb_196;
    z_bb_196:
    goto z_bb_178;
    z_bb_197:
    zT_744 = 8;
    result = zT_744;
    goto z_bb_198;
    z_bb_198:
    goto z_bb_173;
    z_bb_199:
    zT_745 = node.child_0;
    zT_746 = self->exit_name_id;
    if ((int)(zT_745 == zT_746)) goto z_bb_200; else goto z_bb_202;
    z_bb_200:
    zT_749 = ec.len;
    if ((int)(zT_749 >= (unsigned int)(1))) goto z_bb_203; else goto z_bb_204;
    z_bb_201:
    goto z_bb_198;
    z_bb_202:
    zT_759 = node.child_0;
    zT_760 = self->putchar_name_id;
    if ((int)(zT_759 == zT_760)) goto z_bb_206; else goto z_bb_205;
    z_bb_203:
    zT_752 = self;
    zT_754 = ec.ptr;
    zT_755 = 0;
    zT_753 = zT_754[zT_755];
    zT_757 = zF_54F95822_semanticAnalyzerRes(zT_752, zT_753);
    (void)zT_757;
    goto z_bb_204;
    z_bb_204:
    zT_758 = 3;
    result = zT_758;
    goto z_bb_201;
    z_bb_205:
    zT_763 = node.child_0;
    zT_764 = self->sleep_ms_name_id;
    zT_762 = zT_763 == zT_764;
    goto z_bb_207;
    z_bb_206:
    zT_762 = 1;
    goto z_bb_207;
    z_bb_207:
    if (zT_762) goto z_bb_208; else goto z_bb_210;
    z_bb_208:
    zT_767 = ec.len;
    if ((int)(zT_767 >= (unsigned int)(1))) goto z_bb_211; else goto z_bb_212;
    z_bb_209:
    goto z_bb_201;
    z_bb_210:
    zT_777 = node.child_0;
    zT_778 = self->stdout_write_name_id;
    if ((int)(zT_777 == zT_778)) goto z_bb_214; else goto z_bb_213;
    z_bb_211:
    zT_770 = self;
    zT_772 = ec.ptr;
    zT_773 = 0;
    zT_771 = zT_772[zT_773];
    zT_775 = zF_54F95822_semanticAnalyzerRes(zT_770, zT_771);
    (void)zT_775;
    goto z_bb_212;
    z_bb_212:
    zT_776 = 1;
    result = zT_776;
    goto z_bb_209;
    z_bb_213:
    zT_781 = node.child_0;
    zT_782 = self->stderr_write_name_id;
    zT_780 = zT_781 == zT_782;
    goto z_bb_215;
    z_bb_214:
    zT_780 = 1;
    goto z_bb_215;
    z_bb_215:
    if (zT_780) goto z_bb_216; else goto z_bb_218;
    z_bb_216:
    zT_785 = ec.len;
    if ((int)(zT_785 >= (unsigned int)(2))) goto z_bb_219; else goto z_bb_221;
    z_bb_217:
    goto z_bb_209;
    z_bb_218:
    zT_811 = node.child_0;
    zT_812 = self->is_windows_name_id;
    if ((int)(zT_811 == zT_812)) goto z_bb_224; else goto z_bb_226;
    z_bb_219:
    zT_788 = self;
    zT_790 = ec.ptr;
    zT_791 = 0;
    zT_789 = zT_790[zT_791];
    zT_793 = zF_54F95822_semanticAnalyzerRes(zT_788, zT_789);
    (void)zT_793;
    zT_794 = self;
    zT_796 = ec.ptr;
    zT_797 = 1;
    zT_795 = zT_796[zT_797];
    zT_799 = zF_54F95822_semanticAnalyzerRes(zT_794, zT_795);
    (void)zT_799;
    goto z_bb_220;
    z_bb_220:
    zT_810 = 1;
    result = zT_810;
    goto z_bb_217;
    z_bb_221:
    zT_801 = ec.len;
    if ((int)(zT_801 >= (unsigned int)(1))) goto z_bb_222; else goto z_bb_223;
    z_bb_222:
    zT_804 = self;
    zT_806 = ec.ptr;
    zT_807 = 0;
    zT_805 = zT_806[zT_807];
    zT_809 = zF_54F95822_semanticAnalyzerRes(zT_804, zT_805);
    (void)zT_809;
    goto z_bb_223;
    z_bb_223:
    goto z_bb_220;
    z_bb_224:
    zT_814 = 2;
    result = zT_814;
    goto z_bb_225;
    z_bb_225:
    goto z_bb_217;
    z_bb_226:
    zT_815 = node.child_0;
    zT_816 = self->console_clear_name_id;
    if ((int)(zT_815 == zT_816)) goto z_bb_227; else goto z_bb_229;
    z_bb_227:
    zT_818 = 1;
    result = zT_818;
    goto z_bb_228;
    z_bb_228:
    goto z_bb_225;
    z_bb_229:
    zT_819 = node.child_0;
    zT_820 = self->console_gotoxy_name_id;
    if ((int)(zT_819 == zT_820)) goto z_bb_231; else goto z_bb_230;
    z_bb_230:
    zT_823 = node.child_0;
    zT_824 = self->console_set_color_name_id;
    zT_822 = zT_823 == zT_824;
    goto z_bb_232;
    z_bb_231:
    zT_822 = 1;
    goto z_bb_232;
    z_bb_232:
    if (zT_822) goto z_bb_233; else goto z_bb_235;
    z_bb_233:
    zT_827 = ec.len;
    if ((int)(zT_827 >= (unsigned int)(2))) goto z_bb_236; else goto z_bb_238;
    z_bb_234:
    goto z_bb_228;
    z_bb_235:
    zT_854 = ec.len;
    if ((int)(zT_854 >= (unsigned int)(2))) goto z_bb_241; else goto z_bb_243;
    z_bb_236:
    zT_830 = self;
    zT_832 = ec.ptr;
    zT_833 = 0;
    zT_831 = zT_832[zT_833];
    zT_835 = zF_54F95822_semanticAnalyzerRes(zT_830, zT_831);
    (void)zT_835;
    zT_836 = self;
    zT_838 = ec.ptr;
    zT_839 = 1;
    zT_837 = zT_838[zT_839];
    zT_841 = zF_54F95822_semanticAnalyzerRes(zT_836, zT_837);
    (void)zT_841;
    goto z_bb_237;
    z_bb_237:
    zT_852 = 1;
    result = zT_852;
    goto z_bb_234;
    z_bb_238:
    zT_843 = ec.len;
    if ((int)(zT_843 >= (unsigned int)(1))) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    zT_846 = self;
    zT_848 = ec.ptr;
    zT_849 = 0;
    zT_847 = zT_848[zT_849];
    zT_851 = zF_54F95822_semanticAnalyzerRes(zT_846, zT_847);
    (void)zT_851;
    goto z_bb_240;
    z_bb_240:
    goto z_bb_237;
    z_bb_241:
    zT_857 = self;
    zT_858 = node.child_0;
    zT_860 = zF_3757023F_semanticAnalyzerIsT(zT_857, zT_858);
    if (zT_860) goto z_bb_244; else goto z_bb_246;
    z_bb_242:
    goto z_bb_234;
    z_bb_243:
    zT_889 = node.child_0;
    zT_890 = self->enumtoint_name_id;
    if ((int)(zT_889 == zT_890)) goto z_bb_247; else goto z_bb_248;
    z_bb_244:
    zT_861 = self;
    zT_863 = ec.ptr;
    zT_864 = 1;
    zT_862 = zT_863[zT_864];
    zT_866 = zF_54F95822_semanticAnalyzerRes(zT_861, zT_862);
    (void)zT_866;
    zT_869 = self->store;
    zT_868.store = zT_869;
    zT_870 = self->registry;
    zT_868.typereg = zT_870;
    zT_871 = self->symbols;
    zT_868.symbol_reg = zT_871;
    zT_872 = self->interner;
    zT_868.interner = zT_872;
    zT_873 = self->module_id;
    zT_868.module_id = zT_873;
    tre_env = zT_868;
    zT_874 = &tre_env;
    zT_878 = ec.ptr;
    zT_879 = 0;
    zT_875 = zT_878[zT_879];
    zT_882 = zF_F2107C15_resolveTypeExprFull(zT_874, zT_875, (unsigned int)(0));
    result = zT_882;
    goto z_bb_245;
    z_bb_245:
    goto z_bb_242;
    z_bb_246:
    zT_883 = self;
    zT_885 = ec.ptr;
    zT_886 = 0;
    zT_884 = zT_885[zT_886];
    zT_888 = zF_54F95822_semanticAnalyzerRes(zT_883, zT_884);
    result = zT_888;
    goto z_bb_245;
    z_bb_247:
    zT_894 = ec.len;
    zT_892 = zT_894 >= (unsigned int)(1);
    goto z_bb_249;
    z_bb_248:
    zT_892 = 0;
    goto z_bb_249;
    z_bb_249:
    if (zT_892) goto z_bb_250; else goto z_bb_252;
    z_bb_250:
    zT_898 = self;
    zT_900 = ec.ptr;
    zT_901 = 0;
    zT_899 = zT_900[zT_901];
    zT_903 = zF_54F95822_semanticAnalyzerRes(zT_898, zT_899);
    e2i_arg = zT_903;
    e2i_res = e2i_arg;
    if ((int)(e2i_arg != (unsigned int)(18))) goto z_bb_253; else goto z_bb_254;
    z_bb_251:
    goto z_bb_242;
    z_bb_252:
    zT_939 = ec.len;
    if ((int)(zT_939 >= (unsigned int)(1))) goto z_bb_267; else goto z_bb_269;
    z_bb_253:
    zT_908 = self->registry;
    zT_909 = zT_908->types_items;
    zT_910 = (unsigned int)e2i_arg;
    zT_911 = zT_909[zT_910];
    e2i_ty = zT_911;
    zT_912 = e2i_ty.kind;
    if ((int)(zT_912 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_255; else goto z_bb_256;
    z_bb_254:
    result = e2i_res;
    goto z_bb_251;
    z_bb_255:
    zT_918 = self->registry;
    zT_919 = e2i_arg;
    zT_921 = zF_014D7530_typeRegistryEnumBac(zT_918, zT_919);
    e2i_bt = zT_921;
    if ((int)(e2i_bt != (unsigned int)(18))) goto z_bb_257; else goto z_bb_258;
    z_bb_256:
    goto z_bb_254;
    z_bb_257:
    zT_926 = self->registry;
    zT_927 = zT_926->types_len;
    zT_924 = (unsigned int)((unsigned int)e2i_bt) < zT_927;
    goto z_bb_259;
    z_bb_258:
    zT_924 = 0;
    goto z_bb_259;
    z_bb_259:
    if (zT_924) goto z_bb_260; else goto z_bb_261;
    z_bb_260:
    zT_929 = self->registry;
    zT_930 = e2i_arg;
    zT_932 = zF_A3BA89EA_typeRegistryEnumHas(zT_929, zT_930);
    if (zT_932) goto z_bb_262; else goto z_bb_263;
    z_bb_261:
    goto z_bb_256;
    z_bb_262:
    zT_934 = self->registry;
    zT_935 = e2i_bt;
    zT_937 = zF_B664AC19_typeRegistryIsUnsig(zT_934, zT_935);
    zT_933 = zT_937;
    goto z_bb_264;
    z_bb_263:
    zT_933 = 0;
    goto z_bb_264;
    z_bb_264:
    if (zT_933) goto z_bb_265; else goto z_bb_266;
    z_bb_265:
    e2i_res = e2i_bt;
    goto z_bb_266;
    z_bb_266:
    goto z_bb_261;
    z_bb_267:
    zT_942 = self;
    zT_944 = ec.ptr;
    zT_945 = 0;
    zT_943 = zT_944[zT_945];
    zT_947 = zF_54F95822_semanticAnalyzerRes(zT_942, zT_943);
    result = zT_947;
    goto z_bb_268;
    z_bb_268:
    goto z_bb_251;
    z_bb_269:
    zT_948 = 1;
    result = zT_948;
    goto z_bb_268;
    z_bb_270:
    zT_954 = self;
    zT_955 = node.child_0;
    zT_957 = zF_54F95822_semanticAnalyzerRes(zT_954, zT_955);
    (void)zT_957;
    zT_958 = 2;
    result = zT_958;
    goto z_bb_271;
    z_bb_271:
    goto z_bb_121;
    z_bb_272:
    zT_959 = node.kind;
    if ((int)(zT_959 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_274; else goto z_bb_273;
    z_bb_273:
    zT_965 = node.kind;
    zT_964 = zT_965 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_negate);
    goto z_bb_275;
    z_bb_274:
    zT_964 = 1;
    goto z_bb_275;
    z_bb_275:
    if (zT_964) goto z_bb_276; else goto z_bb_278;
    z_bb_276:
    zT_970 = self;
    zT_971 = node_idx;
    zT_972 = zF_09421FDF_semanticAnalyzerRes(zT_970, zT_971);
    result = zT_972;
    goto z_bb_277;
    z_bb_277:
    goto z_bb_271;
    z_bb_278:
    zT_973 = node.kind;
    if ((int)(zT_973 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_279; else goto z_bb_281;
    z_bb_279:
    zT_978 = self;
    zT_979 = node_idx;
    zT_980 = zF_6B59E8AD_semanticAnalyzerRes(zT_978, zT_979);
    result = zT_980;
    goto z_bb_280;
    z_bb_280:
    goto z_bb_277;
    z_bb_281:
    zT_981 = node.kind;
    if ((int)(zT_981 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_282; else goto z_bb_284;
    z_bb_282:
    zT_986 = self;
    zT_987 = node_idx;
    zT_988 = zF_B78F27CD_semanticAnalyzerRes(zT_986, zT_987);
    result = zT_988;
    goto z_bb_283;
    z_bb_283:
    goto z_bb_280;
    z_bb_284:
    zT_989 = node.kind;
    if ((int)(zT_989 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_285; else goto z_bb_287;
    z_bb_285:
    zT_995 = 0;
    zT_996 = (unsigned int)zT_995;
    catch_es = zT_996;
    zT_997 = self;
    zT_998 = node.child_0;
    zT_1000 = zF_54F95822_semanticAnalyzerRes(zT_997, zT_998);
    result = zT_1000;
    if ((int)(result != (unsigned int)(18))) goto z_bb_288; else goto z_bb_289;
    z_bb_286:
    goto z_bb_283;
    z_bb_287:
    zT_1089 = node.kind;
    if ((int)(zT_1089 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_305; else goto z_bb_307;
    z_bb_288:
    zT_1004 = self->registry;
    zT_1005 = zT_1004->types_items;
    zT_1006 = (unsigned int)result;
    zT_1007 = zT_1005[zT_1006];
    clt = zT_1007;
    zT_1008 = clt.kind;
    if ((int)(zT_1008 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_290; else goto z_bb_291;
    z_bb_289:
    zT_1034 = node.child_2;
    zT_1035 = 0;
    if ((int)(zT_1034 != (unsigned int)zT_1035)) goto z_bb_292; else goto z_bb_293;
    z_bb_290:
    zT_1013 = self->registry;
    zT_1014 = zT_1013->eu_items;
    zT_1015 = clt.payload_idx;
    zT_1016 = (unsigned int)zT_1015;
    zT_1017 = zT_1014[zT_1016];
    zT_1018 = zT_1017.error_set;
    catch_es = zT_1018;
    zT_1019 = self->registry;
    zT_1020 = zT_1019->eu_items;
    zT_1021 = clt.payload_idx;
    zT_1022 = (unsigned int)zT_1021;
    zT_1023 = zT_1020[zT_1022];
    zT_1024 = zT_1023.payload;
    result = zT_1024;
    zT_1025 = self->coercion_table;
    zT_1026 = node.child_0;
    zT_1028 = result;
    zF_D21AE60A_coercionTableAdd(zT_1025, zT_1026, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_1028);
    goto z_bb_291;
    z_bb_291:
    goto z_bb_289;
    z_bb_292:
    zT_1038 = self->store;
    zT_1039 = node.child_2;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_1038, zT_1039);
    zT_1043 = self->local_decl_count;
    zT_1044 = self->local_decl_cap;
    if ((int)(zT_1043 >= zT_1044)) goto z_bb_294; else goto z_bb_295;
    z_bb_293:
    zT_1063 = node.child_1;
    if ((int)(zT_1063 != (unsigned int)(0))) goto z_bb_299; else goto z_bb_300;
    z_bb_294:
    zT_1046 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_1046);
    goto z_bb_295;
    z_bb_295:
    zT_1047 = self->store;
    zT_1048 = node.child_2;
    zT_1051 = zF_8BA26B9E_astStoreNodePayload(zT_1047, zT_1048);
    zT_1052 = self->local_decl_names;
    zT_1053 = self->local_decl_count;
    zT_1052[zT_1053] = zT_1051;
    zT_1054 = 0;
    if ((int)(catch_es != (unsigned int)zT_1054)) goto z_bb_296; else goto z_bb_297;
    z_bb_296:
    zT_1056 = catch_es;
    goto z_bb_298;
    z_bb_297:
    zT_1056 = 6;
    goto z_bb_298;
    z_bb_298:
    zT_1058 = self->local_decl_types;
    zT_1059 = self->local_decl_count;
    zT_1058[zT_1059] = zT_1056;
    zT_1060 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_1060 + (unsigned int)(1));
    goto z_bb_293;
    z_bb_299:
    zT_1066 = 0;
    if ((int)(catch_es != (unsigned int)zT_1066)) goto z_bb_301; else goto z_bb_302;
    z_bb_300:
    goto z_bb_286;
    z_bb_301:
    zT_1069 = self->store;
    zT_1070 = node.child_1;
    zT_1073 = zF_FCDD1D35_astStoreNodeAt(zT_1069, zT_1070);
    child1 = zT_1073;
    zT_1074 = child1.kind;
    if ((int)(zT_1074 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_303; else goto z_bb_304;
    z_bb_302:
    zT_1086 = self;
    zT_1087 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1086, zT_1087);
    goto z_bb_300;
    z_bb_303:
    zT_1079 = self;
    zT_1080 = catch_es;
    zF_9665A229_pushExpectedType(zT_1079, zT_1080);
    zT_1081 = self;
    zT_1082 = node.child_1;
    zT_1084 = zF_54F95822_semanticAnalyzerRes(zT_1081, zT_1082);
    (void)zT_1084;
    zT_1085 = self;
    zF_BC478E78_popExpectedType(zT_1085);
    goto z_bb_304;
    z_bb_304:
    goto z_bb_302;
    z_bb_305:
    zT_1094 = self;
    zT_1095 = node_idx;
    zT_1096 = zF_B36961FA_semanticAnalyzerRes(zT_1094, zT_1095);
    result = zT_1096;
    goto z_bb_306;
    z_bb_306:
    goto z_bb_286;
    z_bb_307:
    zT_1097 = node.kind;
    if ((int)(zT_1097 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_309; else goto z_bb_308;
    z_bb_308:
    zT_1103 = node.kind;
    zT_1102 = zT_1103 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt);
    goto z_bb_310;
    z_bb_309:
    zT_1102 = 1;
    goto z_bb_310;
    z_bb_310:
    if (zT_1102) goto z_bb_311; else goto z_bb_313;
    z_bb_311:
    zT_1108 = 1;
    result = zT_1108;
    goto z_bb_312;
    z_bb_312:
    goto z_bb_306;
    z_bb_313:
    zT_1109 = node.kind;
    if ((int)(zT_1109 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_315; else goto z_bb_314;
    z_bb_314:
    zT_1115 = node.kind;
    zT_1114 = zT_1115 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt);
    goto z_bb_316;
    z_bb_315:
    zT_1114 = 1;
    goto z_bb_316;
    z_bb_316:
    if (zT_1114) goto z_bb_318; else goto z_bb_317;
    z_bb_317:
    zT_1121 = node.kind;
    zT_1120 = zT_1121 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_319;
    z_bb_318:
    zT_1120 = 1;
    goto z_bb_319;
    z_bb_319:
    if (zT_1120) goto z_bb_321; else goto z_bb_320;
    z_bb_320:
    zT_1127 = node.kind;
    zT_1126 = zT_1127 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt);
    goto z_bb_322;
    z_bb_321:
    zT_1126 = 1;
    goto z_bb_322;
    z_bb_322:
    if (zT_1126) goto z_bb_323; else goto z_bb_325;
    z_bb_323:
    zT_1132 = self;
    zT_1133 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_1132, zT_1133);
    zT_1134 = 1;
    result = zT_1134;
    goto z_bb_324;
    z_bb_324:
    goto z_bb_312;
    z_bb_325:
    zT_1135 = node.kind;
    if ((int)(zT_1135 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_326; else goto z_bb_328;
    z_bb_326:
    zT_1140 = self;
    zT_1141 = node_idx;
    zT_1142 = zF_8B8EE70D_semanticAnalyzerRes(zT_1140, zT_1141);
    result = zT_1142;
    goto z_bb_327;
    z_bb_327:
    goto z_bb_324;
    z_bb_328:
    zT_1143 = node.kind;
    if ((int)(zT_1143 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_329; else goto z_bb_331;
    z_bb_329:
    zT_1148 = self;
    zT_1149 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_1148, zT_1149);
    zT_1150 = node.child_2;
    if ((int)(zT_1150 != (unsigned int)(0))) goto z_bb_332; else goto z_bb_333;
    z_bb_330:
    goto z_bb_327;
    z_bb_331:
    zT_1163 = node.kind;
    if ((int)(zT_1163 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_336; else goto z_bb_338;
    z_bb_332:
    zT_1153 = self;
    zT_1154 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_1153, zT_1154);
    goto z_bb_333;
    z_bb_333:
    zT_1156 = node.child_1;
    if ((int)(zT_1156 != (unsigned int)(0))) goto z_bb_334; else goto z_bb_335;
    z_bb_334:
    zT_1159 = self;
    zT_1160 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1159, zT_1160);
    goto z_bb_335;
    z_bb_335:
    zT_1162 = 1;
    result = zT_1162;
    goto z_bb_330;
    z_bb_336:
    zT_1168 = self;
    zT_1169 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_1168, zT_1169);
    zT_1170 = node.child_1;
    zT_1171 = 0;
    if ((int)(zT_1170 != (unsigned int)zT_1171)) goto z_bb_339; else goto z_bb_340;
    z_bb_337:
    goto z_bb_330;
    z_bb_338:
    zT_1177 = node.kind;
    if ((int)(zT_1177 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_341; else goto z_bb_343;
    z_bb_339:
    zT_1173 = self;
    zT_1174 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1173, zT_1174);
    goto z_bb_340;
    z_bb_340:
    zT_1176 = 1;
    result = zT_1176;
    goto z_bb_337;
    z_bb_341:
    zT_1182 = self;
    zT_1183 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_1182, zT_1183);
    zT_1184 = node.child_1;
    zT_1185 = 0;
    if ((int)(zT_1184 != (unsigned int)zT_1185)) goto z_bb_344; else goto z_bb_345;
    z_bb_342:
    goto z_bb_337;
    z_bb_343:
    zT_1191 = node.kind;
    if ((int)(zT_1191 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_346; else goto z_bb_348;
    z_bb_344:
    zT_1187 = self;
    zT_1188 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1187, zT_1188);
    goto z_bb_345;
    z_bb_345:
    zT_1190 = 1;
    result = zT_1190;
    goto z_bb_342;
    z_bb_346:
    zT_1196 = self;
    zT_1197 = node_idx;
    zT_1198 = zF_2DB4F186_semanticAnalyzerRes(zT_1196, zT_1197);
    result = zT_1198;
    goto z_bb_347;
    z_bb_347:
    goto z_bb_342;
    z_bb_348:
    zT_1199 = node.kind;
    if ((int)(zT_1199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_349; else goto z_bb_351;
    z_bb_349:
    zT_1204 = self;
    zT_1205 = node_idx;
    zT_1206 = zF_227D2404_semanticAnalyzerRes(zT_1204, zT_1205);
    result = zT_1206;
    goto z_bb_350;
    z_bb_350:
    goto z_bb_347;
    z_bb_351:
    zT_1207 = node.kind;
    if ((int)(zT_1207 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_352; else goto z_bb_354;
    z_bb_352:
    zT_1212 = self;
    zT_1213 = node_idx;
    zT_1214 = zF_AD7EF126_semanticAnalyzerRes(zT_1212, zT_1213);
    result = zT_1214;
    goto z_bb_353;
    z_bb_353:
    goto z_bb_350;
    z_bb_354:
    zT_1215 = node.kind;
    if ((int)(zT_1215 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_355; else goto z_bb_357;
    z_bb_355:
    zT_1221 = "AW:R";
    zT_1223 = 4;
    zT_1222.ptr = zT_1221;
    zT_1222.len = zT_1223;
    ai_dbg = zT_1222;
    zT_1224 = ai_dbg;
    zT_1225 = result;
    zF_C914CB83_markerWriteInt(zT_1224, zT_1225);
    zT_1226 = self;
    zT_1227 = node_idx;
    zT_1228 = zF_F3DAABE0_semanticAnalyzerRes(zT_1226, zT_1227);
    result = zT_1228;
    goto z_bb_356;
    z_bb_356:
    goto z_bb_353;
    z_bb_357:
    zT_1229 = node.kind;
    if ((int)(zT_1229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_359; else goto z_bb_358;
    z_bb_358:
    zT_1235 = node.kind;
    zT_1234 = zT_1235 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_360;
    z_bb_359:
    zT_1234 = 1;
    goto z_bb_360;
    z_bb_360:
    if (zT_1234) goto z_bb_362; else goto z_bb_361;
    z_bb_361:
    zT_1241 = node.kind;
    zT_1240 = zT_1241 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_363;
    z_bb_362:
    zT_1240 = 1;
    goto z_bb_363;
    z_bb_363:
    if (zT_1240) goto z_bb_365; else goto z_bb_364;
    z_bb_364:
    zT_1247 = node.kind;
    zT_1246 = zT_1247 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_366;
    z_bb_365:
    zT_1246 = 1;
    goto z_bb_366;
    z_bb_366:
    if (zT_1246) goto z_bb_368; else goto z_bb_367;
    z_bb_367:
    zT_1253 = node.kind;
    zT_1252 = zT_1253 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_369;
    z_bb_368:
    zT_1252 = 1;
    goto z_bb_369;
    z_bb_369:
    if (zT_1252) goto z_bb_371; else goto z_bb_370;
    z_bb_370:
    zT_1259 = node.kind;
    zT_1258 = zT_1259 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_372;
    z_bb_371:
    zT_1258 = 1;
    goto z_bb_372;
    z_bb_372:
    if (zT_1258) goto z_bb_374; else goto z_bb_373;
    z_bb_373:
    zT_1265 = node.kind;
    zT_1264 = zT_1265 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_375;
    z_bb_374:
    zT_1264 = 1;
    goto z_bb_375;
    z_bb_375:
    if (zT_1264) goto z_bb_377; else goto z_bb_376;
    z_bb_376:
    zT_1271 = node.kind;
    zT_1270 = zT_1271 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl);
    goto z_bb_378;
    z_bb_377:
    zT_1270 = 1;
    goto z_bb_378;
    z_bb_378:
    if (zT_1270) goto z_bb_380; else goto z_bb_379;
    z_bb_379:
    zT_1277 = node.kind;
    zT_1276 = zT_1277 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_381;
    z_bb_380:
    zT_1276 = 1;
    goto z_bb_381;
    z_bb_381:
    if (zT_1276) goto z_bb_383; else goto z_bb_382;
    z_bb_382:
    zT_1283 = node.kind;
    zT_1282 = zT_1283 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_384;
    z_bb_383:
    zT_1282 = 1;
    goto z_bb_384;
    z_bb_384:
    if (zT_1282) goto z_bb_386; else goto z_bb_385;
    z_bb_385:
    zT_1289 = node.kind;
    zT_1288 = zT_1289 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_387;
    z_bb_386:
    zT_1288 = 1;
    goto z_bb_387;
    z_bb_387:
    if (zT_1288) goto z_bb_388; else goto z_bb_390;
    z_bb_388:
    zT_1294 = node.kind;
    if ((int)(zT_1294 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_391; else goto z_bb_392;
    z_bb_389:
    goto z_bb_356;
    z_bb_390:
    zT_1304 = node.kind;
    if ((int)(zT_1304 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_393; else goto z_bb_395;
    z_bb_391:
    zT_1299 = self;
    zT_1300 = node_idx;
    zT_1301 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_1299, zT_1300, zT_1301);
    goto z_bb_392;
    z_bb_392:
    zT_1303 = 20;
    result = zT_1303;
    goto z_bb_389;
    z_bb_393:
    zT_1309 = self;
    zT_1310 = node.child_0;
    zT_1312 = zF_54F95822_semanticAnalyzerRes(zT_1309, zT_1310);
    result = zT_1312;
    goto z_bb_394;
    z_bb_394:
    goto z_bb_389;
    z_bb_395:
    zT_1313 = node.kind;
    if ((int)(zT_1313 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_396; else goto z_bb_398;
    z_bb_396:
    zT_1318 = self;
    zT_1319 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_1318, zT_1319);
    zT_1320 = 3;
    result = zT_1320;
    goto z_bb_397;
    z_bb_397:
    goto z_bb_394;
    z_bb_398:
    zT_1321 = node.kind;
    if ((int)(zT_1321 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_399; else goto z_bb_401;
    z_bb_399:
    zT_1326 = self;
    zT_1327 = node.child_0;
    zT_1329 = zF_54F95822_semanticAnalyzerRes(zT_1326, zT_1327);
    result = zT_1329;
    goto z_bb_400;
    z_bb_400:
    goto z_bb_397;
    z_bb_401:
    zT_1330 = node.kind;
    if ((int)(zT_1330 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_402; else goto z_bb_404;
    z_bb_402:
    zT_1335 = 1;
    result = zT_1335;
    goto z_bb_403;
    z_bb_403:
    goto z_bb_400;
    z_bb_404:
    zT_1336 = node.kind;
    if ((int)(zT_1336 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_405; else goto z_bb_407;
    z_bb_405:
    zT_1342 = "EBLK:N";
    zT_1344 = 6;
    zT_1343.ptr = zT_1342;
    zT_1343.len = zT_1344;
    eblk_m = zT_1343;
    zT_1345 = eblk_m;
    zT_1346 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1345, zT_1346);
    zT_1348 = self->store;
    zT_1349 = node_idx;
    zT_1351 = zF_850FDF81_astStoreNodeExtraCh(zT_1348, zT_1349);
    children = zT_1351;
    zT_1353 = "EBLK:C";
    zT_1355 = 6;
    zT_1354.ptr = zT_1353;
    zT_1354.len = zT_1355;
    eblk_cm = zT_1354;
    zT_1356 = eblk_cm;
    zT_1359 = children.len;
    zF_C914CB83_markerWriteInt(zT_1356, (unsigned int)((unsigned int)zT_1359));
    zT_1362 = children.len;
    if ((int)(zT_1362 > (unsigned int)(0))) goto z_bb_408; else goto z_bb_410;
    z_bb_406:
    goto z_bb_403;
    z_bb_407:
    zT_1405 = node.kind;
    if ((int)(zT_1405 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_416; else goto z_bb_415;
    z_bb_408:
    zT_1366 = 0;
    zT_1367 = (unsigned int)zT_1366;
    si = zT_1367;
    goto z_bb_411;
    z_bb_409:
    goto z_bb_406;
    z_bb_410:
    zT_1404 = 1;
    result = zT_1404;
    goto z_bb_409;
    z_bb_411:
    zT_1369 = children.len;
    if ((int)(si < (unsigned int)(zT_1369 - (unsigned int)(1)))) goto z_bb_412; else goto z_bb_413;
    z_bb_412:
    zT_1374 = "EBLK:S";
    zT_1376 = 6;
    zT_1375.ptr = zT_1374;
    zT_1375.len = zT_1376;
    eblk_sm = zT_1375;
    zT_1377 = eblk_sm;
    zF_C914CB83_markerWriteInt(zT_1377, (unsigned int)((unsigned int)si));
    zT_1381 = "EBLK:D";
    zT_1383 = 6;
    zT_1382.ptr = zT_1381;
    zT_1382.len = zT_1383;
    eblk_cm2 = zT_1382;
    zT_1384 = eblk_cm2;
    zT_1386 = children.ptr;
    zT_1385 = zT_1386[si];
    zF_C914CB83_markerWriteInt(zT_1384, zT_1385);
    zT_1388 = self;
    zT_1390 = children.ptr;
    zT_1389 = zT_1390[si];
    zF_10A0DC35_semanticAnalyzerRes(zT_1388, zT_1389);
    goto z_bb_414;
    z_bb_413:
    zT_1395 = children.ptr;
    zT_1397 = children.len;
    zT_1399 = zT_1397 - (unsigned int)(1);
    zT_1400 = zT_1395[zT_1399];
    last_child = zT_1400;
    zT_1401 = self;
    zT_1402 = last_child;
    zT_1403 = zF_54F95822_semanticAnalyzerRes(zT_1401, zT_1402);
    result = zT_1403;
    goto z_bb_409;
    z_bb_414:
    zT_1392 = 1;
    zT_1393 = si + zT_1392;
    si = zT_1393;
    goto z_bb_411;
    z_bb_415:
    zT_1411 = node.kind;
    zT_1410 = zT_1411 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_417;
    z_bb_416:
    zT_1410 = 1;
    goto z_bb_417;
    z_bb_417:
    if (zT_1410) goto z_bb_419; else goto z_bb_418;
    z_bb_418:
    zT_1417 = node.kind;
    zT_1416 = zT_1417 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_420;
    z_bb_419:
    zT_1416 = 1;
    goto z_bb_420;
    z_bb_420:
    if (zT_1416) goto z_bb_422; else goto z_bb_421;
    z_bb_421:
    zT_1423 = node.kind;
    zT_1422 = zT_1423 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_423;
    z_bb_422:
    zT_1422 = 1;
    goto z_bb_423;
    z_bb_423:
    if (zT_1422) goto z_bb_425; else goto z_bb_424;
    z_bb_424:
    zT_1429 = node.kind;
    zT_1428 = zT_1429 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_426;
    z_bb_425:
    zT_1428 = 1;
    goto z_bb_426;
    z_bb_426:
    if (zT_1428) goto z_bb_428; else goto z_bb_427;
    z_bb_427:
    zT_1435 = node.kind;
    zT_1434 = zT_1435 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add);
    goto z_bb_429;
    z_bb_428:
    zT_1434 = 1;
    goto z_bb_429;
    z_bb_429:
    if (zT_1434) goto z_bb_431; else goto z_bb_430;
    z_bb_430:
    zT_1441 = node.kind;
    zT_1440 = zT_1441 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub);
    goto z_bb_432;
    z_bb_431:
    zT_1440 = 1;
    goto z_bb_432;
    z_bb_432:
    if (zT_1440) goto z_bb_434; else goto z_bb_433;
    z_bb_433:
    zT_1447 = node.kind;
    zT_1446 = zT_1447 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul);
    goto z_bb_435;
    z_bb_434:
    zT_1446 = 1;
    goto z_bb_435;
    z_bb_435:
    if (zT_1446) goto z_bb_437; else goto z_bb_436;
    z_bb_436:
    zT_1453 = node.kind;
    zT_1452 = zT_1453 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add);
    goto z_bb_438;
    z_bb_437:
    zT_1452 = 1;
    goto z_bb_438;
    z_bb_438:
    if (zT_1452) goto z_bb_440; else goto z_bb_439;
    z_bb_439:
    zT_1459 = node.kind;
    zT_1458 = zT_1459 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub);
    goto z_bb_441;
    z_bb_440:
    zT_1458 = 1;
    goto z_bb_441;
    z_bb_441:
    if (zT_1458) goto z_bb_443; else goto z_bb_442;
    z_bb_442:
    zT_1465 = node.kind;
    zT_1464 = zT_1465 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul);
    goto z_bb_444;
    z_bb_443:
    zT_1464 = 1;
    goto z_bb_444;
    z_bb_444:
    if (zT_1464) goto z_bb_445; else goto z_bb_447;
    z_bb_445:
    zT_1470 = self;
    zT_1471 = node_idx;
    zT_1472 = node.kind;
    zT_1474 = zF_44006DDD_semanticAnalyzerRes(zT_1470, zT_1471, zT_1472);
    result = zT_1474;
    goto z_bb_446;
    z_bb_446:
    goto z_bb_406;
    z_bb_447:
    zT_1475 = node.kind;
    if ((int)(zT_1475 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_449; else goto z_bb_448;
    z_bb_448:
    zT_1481 = node.kind;
    zT_1480 = zT_1481 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_450;
    z_bb_449:
    zT_1480 = 1;
    goto z_bb_450;
    z_bb_450:
    if (zT_1480) goto z_bb_452; else goto z_bb_451;
    z_bb_451:
    zT_1487 = node.kind;
    zT_1486 = zT_1487 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_453;
    z_bb_452:
    zT_1486 = 1;
    goto z_bb_453;
    z_bb_453:
    if (zT_1486) goto z_bb_455; else goto z_bb_454;
    z_bb_454:
    zT_1493 = node.kind;
    zT_1492 = zT_1493 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_456;
    z_bb_455:
    zT_1492 = 1;
    goto z_bb_456;
    z_bb_456:
    if (zT_1492) goto z_bb_458; else goto z_bb_457;
    z_bb_457:
    zT_1499 = node.kind;
    zT_1498 = zT_1499 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_459;
    z_bb_458:
    zT_1498 = 1;
    goto z_bb_459;
    z_bb_459:
    if (zT_1498) goto z_bb_461; else goto z_bb_460;
    z_bb_460:
    zT_1505 = node.kind;
    zT_1504 = zT_1505 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl);
    goto z_bb_462;
    z_bb_461:
    zT_1504 = 1;
    goto z_bb_462;
    z_bb_462:
    if (zT_1504) goto z_bb_463; else goto z_bb_465;
    z_bb_463:
    zT_1510 = self;
    zT_1511 = node_idx;
    zT_1512 = zF_733BCA9C_semanticAnalyzerRes(zT_1510, zT_1511);
    result = zT_1512;
    goto z_bb_464;
    z_bb_464:
    goto z_bb_446;
    z_bb_465:
    zT_1513 = node.kind;
    if ((int)(zT_1513 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_467; else goto z_bb_466;
    z_bb_466:
    zT_1519 = node.kind;
    zT_1518 = zT_1519 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_468;
    z_bb_467:
    zT_1518 = 1;
    goto z_bb_468;
    z_bb_468:
    if (zT_1518) goto z_bb_469; else goto z_bb_471;
    z_bb_469:
    zT_1524 = self;
    zT_1525 = node_idx;
    zT_1526 = zF_6F2B8B98_semanticAnalyzerRes(zT_1524, zT_1525);
    result = zT_1526;
    goto z_bb_470;
    z_bb_470:
    goto z_bb_464;
    z_bb_471:
    zT_1527 = node.kind;
    if ((int)(zT_1527 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_473; else goto z_bb_472;
    z_bb_472:
    zT_1533 = node.kind;
    zT_1532 = zT_1533 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_474;
    z_bb_473:
    zT_1532 = 1;
    goto z_bb_474;
    z_bb_474:
    if (zT_1532) goto z_bb_476; else goto z_bb_475;
    z_bb_475:
    zT_1539 = node.kind;
    zT_1538 = zT_1539 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_477;
    z_bb_476:
    zT_1538 = 1;
    goto z_bb_477;
    z_bb_477:
    if (zT_1538) goto z_bb_479; else goto z_bb_478;
    z_bb_478:
    zT_1545 = node.kind;
    zT_1544 = zT_1545 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_480;
    z_bb_479:
    zT_1544 = 1;
    goto z_bb_480;
    z_bb_480:
    if (zT_1544) goto z_bb_482; else goto z_bb_481;
    z_bb_481:
    zT_1551 = node.kind;
    zT_1550 = zT_1551 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_483;
    z_bb_482:
    zT_1550 = 1;
    goto z_bb_483;
    z_bb_483:
    if (zT_1550) goto z_bb_485; else goto z_bb_484;
    z_bb_484:
    zT_1557 = node.kind;
    zT_1556 = zT_1557 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_486;
    z_bb_485:
    zT_1556 = 1;
    goto z_bb_486;
    z_bb_486:
    if (zT_1556) goto z_bb_487; else goto z_bb_489;
    z_bb_487:
    zT_1562 = self;
    zT_1563 = node_idx;
    zT_1564 = node.kind;
    zT_1566 = zF_EB621FF0_semanticAnalyzerRes(zT_1562, zT_1563, zT_1564);
    result = zT_1566;
    goto z_bb_488;
    z_bb_488:
    goto z_bb_470;
    z_bb_489:
    zT_1567 = node.kind;
    if ((int)(zT_1567 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_491; else goto z_bb_490;
    z_bb_490:
    zT_1573 = node.kind;
    zT_1572 = zT_1573 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_492;
    z_bb_491:
    zT_1572 = 1;
    goto z_bb_492;
    z_bb_492:
    if (zT_1572) goto z_bb_494; else goto z_bb_493;
    z_bb_493:
    zT_1579 = node.kind;
    zT_1578 = zT_1579 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_495;
    z_bb_494:
    zT_1578 = 1;
    goto z_bb_495;
    z_bb_495:
    if (zT_1578) goto z_bb_497; else goto z_bb_496;
    z_bb_496:
    zT_1585 = node.kind;
    zT_1584 = zT_1585 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_498;
    z_bb_497:
    zT_1584 = 1;
    goto z_bb_498;
    z_bb_498:
    if (zT_1584) goto z_bb_500; else goto z_bb_499;
    z_bb_499:
    zT_1591 = node.kind;
    zT_1590 = zT_1591 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_501;
    z_bb_500:
    zT_1590 = 1;
    goto z_bb_501;
    z_bb_501:
    if (zT_1590) goto z_bb_503; else goto z_bb_502;
    z_bb_502:
    zT_1597 = node.kind;
    zT_1596 = zT_1597 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_504;
    z_bb_503:
    zT_1596 = 1;
    goto z_bb_504;
    z_bb_504:
    if (zT_1596) goto z_bb_506; else goto z_bb_505;
    z_bb_505:
    zT_1603 = node.kind;
    zT_1602 = zT_1603 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_507;
    z_bb_506:
    zT_1602 = 1;
    goto z_bb_507;
    z_bb_507:
    if (zT_1602) goto z_bb_509; else goto z_bb_508;
    z_bb_508:
    zT_1609 = node.kind;
    zT_1608 = zT_1609 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_510;
    z_bb_509:
    zT_1608 = 1;
    goto z_bb_510;
    z_bb_510:
    if (zT_1608) goto z_bb_512; else goto z_bb_511;
    z_bb_511:
    zT_1615 = node.kind;
    zT_1614 = zT_1615 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_513;
    z_bb_512:
    zT_1614 = 1;
    goto z_bb_513;
    z_bb_513:
    if (zT_1614) goto z_bb_515; else goto z_bb_514;
    z_bb_514:
    zT_1621 = node.kind;
    zT_1620 = zT_1621 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_516;
    z_bb_515:
    zT_1620 = 1;
    goto z_bb_516;
    z_bb_516:
    if (zT_1620) goto z_bb_518; else goto z_bb_517;
    z_bb_517:
    zT_1627 = node.kind;
    zT_1626 = zT_1627 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_519;
    z_bb_518:
    zT_1626 = 1;
    goto z_bb_519;
    z_bb_519:
    if (zT_1626) goto z_bb_521; else goto z_bb_520;
    z_bb_520:
    zT_1633 = node.kind;
    zT_1632 = zT_1633 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_522;
    z_bb_521:
    zT_1632 = 1;
    goto z_bb_522;
    z_bb_522:
    if (zT_1632) goto z_bb_524; else goto z_bb_523;
    z_bb_523:
    zT_1639 = node.kind;
    zT_1638 = zT_1639 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_525;
    z_bb_524:
    zT_1638 = 1;
    goto z_bb_525;
    z_bb_525:
    if (zT_1638) goto z_bb_527; else goto z_bb_526;
    z_bb_526:
    zT_1645 = node.kind;
    zT_1644 = zT_1645 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_528;
    z_bb_527:
    zT_1644 = 1;
    goto z_bb_528;
    z_bb_528:
    if (zT_1644) goto z_bb_530; else goto z_bb_529;
    z_bb_529:
    zT_1651 = node.kind;
    zT_1650 = zT_1651 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_531;
    z_bb_530:
    zT_1650 = 1;
    goto z_bb_531;
    z_bb_531:
    if (zT_1650) goto z_bb_533; else goto z_bb_532;
    z_bb_532:
    zT_1657 = node.kind;
    zT_1656 = zT_1657 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_534;
    z_bb_533:
    zT_1656 = 1;
    goto z_bb_534;
    z_bb_534:
    if (zT_1656) goto z_bb_536; else goto z_bb_535;
    z_bb_535:
    zT_1663 = node.kind;
    zT_1662 = zT_1663 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_537;
    z_bb_536:
    zT_1662 = 1;
    goto z_bb_537;
    z_bb_537:
    if (zT_1662) goto z_bb_539; else goto z_bb_538;
    z_bb_538:
    zT_1669 = node.kind;
    zT_1668 = zT_1669 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_540;
    z_bb_539:
    zT_1668 = 1;
    goto z_bb_540;
    z_bb_540:
    if (zT_1668) goto z_bb_541; else goto z_bb_543;
    z_bb_541:
    zT_1674 = self;
    zT_1675 = node_idx;
    zT_1676 = zF_C0551BB8_semanticAnalyzerRes(zT_1674, zT_1675);
    result = zT_1676;
    goto z_bb_542;
    z_bb_542:
    goto z_bb_488;
    z_bb_543:
    zT_1677 = node.kind;
    if ((int)(zT_1677 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_545; else goto z_bb_544;
    z_bb_544:
    zT_1683 = node.kind;
    zT_1682 = zT_1683 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_546;
    z_bb_545:
    zT_1682 = 1;
    goto z_bb_546;
    z_bb_546:
    if (zT_1682) goto z_bb_547; else goto z_bb_549;
    z_bb_547:
    zT_1688 = self->type_table;
    zT_1689 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1688, zT_1689, (unsigned int)(10));
    return (unsigned int)(10);
    goto z_bb_542;
    z_bb_549:
    zT_1695 = "ST:N";
    zT_1697 = 4;
    zT_1696.ptr = zT_1695;
    zT_1696.len = zT_1697;
    st_m = zT_1696;
    zT_1698 = st_m;
    zT_1699 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1698, zT_1699);
    zT_1701 = node.kind;
    zT_1702 = (unsigned int)zT_1701;
    st_kv = zT_1702;
    zT_1704 = "ST:K";
    zT_1706 = 4;
    zT_1705.ptr = zT_1704;
    zT_1705.len = zT_1706;
    st_km = zT_1705;
    zT_1707 = st_km;
    zT_1708 = st_kv;
    zF_C914CB83_markerWriteInt(zT_1707, zT_1708);
    zT_1710 = "internal error: unhandled node kind in type resolution";
    zT_1712 = 54;
    zT_1711.ptr = zT_1710;
    zT_1711.len = zT_1712;
    unr_msg = zT_1711;
    zT_1713 = self->diag;
    zT_1716 = self->source_file_id;
    zT_1717 = node_idx;
    zT_1718 = node_idx;
    zT_1719 = unr_msg;
    zT_1724 = zF_C82559AC_diagnosticCollector(zT_1713, (unsigned char)(0), (unsigned short)(3020), zT_1716, zT_1717, zT_1718, zT_1719);
    (void)zT_1724;
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveFnBody */
void zF_406A2501_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int fn_decl_node) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    zT_8143F551_AstKind zT_13;
    zT_6B0A7D14_AstStore* zT_19;
    zT_4A837C97_anon_184529 zT_21;
    zT_243D6A41_FnProto* zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    zT_243D6A41_FnProto zT_28;
    unsigned int zT_29;
    unsigned short zT_32;
    unsigned int zT_36;
    unsigned short zT_40;
    zT_79FAE712_u64 zT_42;
    zT_6B0A7D14_AstStore* zT_44;
    zT_79FAE712_u64 zT_45;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_46 = {0};
    unsigned int zT_48;
    unsigned int zT_50;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int* zT_55;
    zT_22A7C88B_AstNode zT_57 = {0};
    unsigned int zT_58;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_38C12417_SemanticAnalyzer* zT_64;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    unsigned int* zT_67;
    unsigned int zT_69 = 0;
    unsigned int* zT_70;
    unsigned int zT_71;
    char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int* zT_80;
    unsigned int zT_82 = 0;
    char* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8EED1867_ResolvedTypeTable* zT_91;
    unsigned int zT_92;
    zT_BAEE192E_Opt_10 zT_95 = {0};
    unsigned char zT_96;
    char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    unsigned int* zT_104;
    unsigned int zT_105;
    char* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    unsigned int* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_118;
    zT_8EED1867_ResolvedTypeTable* zT_120;
    unsigned int zT_121;
    zT_BAEE192E_Opt_10 zT_124 = {0};
    unsigned char zT_125;
    zT_38C12417_SemanticAnalyzer* zT_127;
    unsigned int zT_128;
    zT_21D3708C_U32ToU32Map* zT_131;
    unsigned int zT_132;
    zT_21D3708C_U32ToU32Map* zT_134;
    unsigned int zT_135;
    char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u fb;
    zT_22A7C88B_AstNode decl;
    zT_6B0A7D14_AstStore* store;
    zT_243D6A41_FnProto proto;
    zT_79FAE712_u64 p_payload;
    zT_3CB0179A_Slice_zT_05F374B1_u pnodes;
    unsigned int pi;
    zT_BAEE192E_Opt_10 fn_rt;
    zT_22A7C88B_AstNode pnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rta_m;
    zT_BAEE192E_Opt_10 rt;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u rth_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtm2;
    unsigned int frt;
    unsigned int evcap;
    unsigned int evcnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u vm;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcm;
    zT_3 = "FB";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fb = zT_4;
    zT_6 = fb;
    zF_48AC7B3A_markerWrite(zT_6);
    self->local_decl_count = (unsigned int)(0);
    zT_9 = self->store;
    zT_10 = fn_decl_node;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    decl = zT_12;
    zT_13 = decl.kind;
    if ((int)(zT_13 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_19 = self->store;
    store = zT_19;
    zT_21 = store->fn_protos;
    zT_22 = zT_21.items;
    zT_23 = self->store;
    zT_24 = fn_decl_node;
    zT_26 = zF_8BA26B9E_astStoreNodePayload(zT_23, zT_24);
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_22[zT_27];
    proto = zT_28;
    zT_29 = decl.child_0;
    if ((int)(zT_29 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_32 = proto.params_count;
    if ((int)(zT_32 > (unsigned short)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_36 = proto.params_start;
    zT_40 = proto.params_count;
    zT_42 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_36) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_40);
    p_payload = zT_42;
    zT_44 = store;
    zT_45 = p_payload;
    zT_46 = zF_3EAD7B21_astStoreGetExtraChi(zT_44, zT_45);
    pnodes = zT_46;
    zT_48 = 0;
    pi = zT_48;
    goto z_bb_7;
    z_bb_6:
    zT_120 = self->type_table;
    zT_121 = proto.return_type_node;
    zT_124 = zF_999DCF51_resolvedTypeTableGe(zT_120, zT_121);
    fn_rt = zT_124;
    zT_125 = fn_rt.has_value;
    if (zT_125) goto z_bb_18; else goto z_bb_19;
    z_bb_7:
    zT_50 = pnodes.len;
    if ((int)(pi < zT_50)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_53 = store;
    zT_55 = pnodes.ptr;
    zT_54 = zT_55[pi];
    zT_57 = zF_FCDD1D35_astStoreNodeAt(zT_53, zT_54);
    pnode = zT_57;
    zT_58 = pnode.child_0;
    if ((int)(zT_58 != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_118 = pi + (unsigned int)(1);
    pi = zT_118;
    goto z_bb_7;
    z_bb_11:
    zT_61 = self->local_decl_count;
    zT_62 = self->local_decl_cap;
    if ((int)(zT_61 >= zT_62)) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_64 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_64);
    goto z_bb_14;
    z_bb_14:
    zT_65 = store;
    zT_67 = pnodes.ptr;
    zT_66 = zT_67[pi];
    zT_69 = zF_8BA26B9E_astStoreNodePayload(zT_65, zT_66);
    zT_70 = self->local_decl_names;
    zT_71 = self->local_decl_count;
    zT_70[zT_71] = zT_69;
    zT_73 = "RT:P";
    zT_75 = 4;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    rtp_m = zT_74;
    zT_76 = rtp_m;
    zT_78 = store;
    zT_80 = pnodes.ptr;
    zT_79 = zT_80[pi];
    zT_82 = zF_8BA26B9E_astStoreNodePayload(zT_78, zT_79);
    zT_77 = zT_82;
    zF_C914CB83_markerWriteInt(zT_76, zT_77);
    zT_84 = "RT:A";
    zT_86 = 4;
    zT_85.ptr = zT_84;
    zT_85.len = zT_86;
    rta_m = zT_85;
    zT_87 = rta_m;
    zT_88 = pnode.child_0;
    zF_C914CB83_markerWriteInt(zT_87, zT_88);
    zT_91 = self->type_table;
    zT_92 = pnode.child_0;
    zT_95 = zF_999DCF51_resolvedTypeTableGe(zT_91, zT_92);
    rt = zT_95;
    zT_96 = rt.has_value;
    if (zT_96) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    t = rt.value;
    zT_99 = "RT:T";
    zT_101 = 4;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    rth_m = zT_100;
    zT_102 = rth_m;
    zT_103 = t;
    zF_C914CB83_markerWriteInt(zT_102, zT_103);
    zT_104 = self->local_decl_types;
    zT_105 = self->local_decl_count;
    zT_104[zT_105] = t;
    goto z_bb_16;
    z_bb_16:
    zT_114 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_114 + (unsigned int)(1));
    goto z_bb_12;
    z_bb_17:
    zT_107 = "RT:M\n";
    zT_109 = 5;
    zT_108.ptr = zT_107;
    zT_108.len = zT_109;
    rtm2 = zT_108;
    zT_110 = rtm2;
    zF_48AC7B3A_markerWrite(zT_110);
    zT_111 = 18;
    zT_112 = self->local_decl_types;
    zT_113 = self->local_decl_count;
    zT_112[zT_113] = zT_111;
    goto z_bb_16;
    z_bb_18:
    frt = fn_rt.value;
    self->current_fn_return = frt;
    goto z_bb_19;
    z_bb_19:
    zT_127 = self;
    zT_128 = decl.child_0;
    zF_979B6CFF_semanticAnalyzerRes(zT_127, zT_128);
    zT_131 = self->enum_value_table;
    zT_132 = zT_131->capacity;
    evcap = zT_132;
    zT_134 = self->enum_value_table;
    zT_135 = zT_134->count;
    evcnt = zT_135;
    zT_137 = "EVC:N";
    zT_139 = 5;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    vm = zT_138;
    zT_140 = vm;
    zF_C914CB83_markerWriteInt(zT_140, (unsigned int)((unsigned int)evcnt));
    zT_144 = "EVC:C";
    zT_146 = 5;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    vcm = zT_145;
    zT_147 = vcm;
    zF_C914CB83_markerWriteInt(zT_147, (unsigned int)((unsigned int)evcap));
    return;
}

/* semanticAnalyzerStmtWorkPush */
void zF_7AB741D8_semanticAnalyzerStm(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_0F51E4CA_EU_222 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->stmt_work_len;
    zT_3 = self->stmt_work_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->stmt_work_cap;
    if ((int)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->stmt_work_items;
    zT_38 = self->stmt_work_len;
    zT_37[zT_38] = node_idx;
    zT_39 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->stmt_work_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->stmt_work_len;
    if ((int)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->stmt_work_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->stmt_work_items = ndst;
    self->stmt_work_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* pushExpectedType */
void zF_9665A229_pushExpectedType(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_0F51E4CA_EU_222 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->expected_type_stack_len;
    zT_3 = self->expected_type_stack_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->expected_type_stack_cap;
    if ((int)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->expected_type_stack_items;
    zT_38 = self->expected_type_stack_len;
    zT_37[zT_38] = ty;
    zT_39 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->expected_type_stack_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->expected_type_stack_len;
    if ((int)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->expected_type_stack_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->expected_type_stack_items = ndst;
    self->expected_type_stack_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* popExpectedType */
void zF_BC478E78_popExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int zT_4;
    zT_1 = self->expected_type_stack_len;
    if ((int)(zT_1 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_4 - (unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    return;
}

/* topExpectedType */
unsigned int zF_4DE7C2BC_topExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_1 = self->expected_type_stack_len;
    if ((int)(zT_1 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_5 = self->expected_type_stack_items;
    zT_6 = self->expected_type_stack_len;
    zT_8 = zT_6 - (unsigned int)(1);
    zT_9 = zT_5[zT_8];
    return zT_9;
}

/* semanticAnalyzerResolveIfHeader */
void zF_0324C9A3_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_39 = 0;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_939EE900_Arr_unsigned_int_1 zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    int zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    int zT_59;
    zT_22A7C88B_AstNode zT_61 = {0};
    zT_8143F551_AstKind zT_62;
    unsigned int zT_63;
    int zT_64;
    char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    int zT_77;
    char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    int zT_85;
    char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_939EE900_Arr_unsigned_int_1 zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_6B0A7D14_AstStore* zT_102;
    unsigned int zT_103;
    zT_22A7C88B_AstNode zT_106 = {0};
    zT_8143F551_AstKind zT_107;
    unsigned int zT_108;
    int zT_109;
    char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    int zT_116;
    zT_22A7C88B_AstNode node;
    unsigned int icond_t;
    unsigned int icap_idx;
    zT_22A7C88B_AstNode icap_node;
    zT_939EE900_Arr_unsigned_int_1 ifs_b;
    zT_939EE900_Arr_unsigned_int_1 ifs_k;
    zT_22A7C88B_AstNode ifs_cn;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_cm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_c2m;
    zT_939EE900_Arr_unsigned_int_1 ifs_k2;
    zT_22A7C88B_AstNode ifs_cn2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_k2m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    icond_t = zT_11;
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    icap_idx = zT_22;
    zT_24 = self->store;
    zT_25 = icap_idx;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    icap_node = zT_27;
    zT_28 = icap_node.kind;
    if ((int)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_45 = node.child_1;
    zT_46 = 0;
    zT_44[zT_46] = zT_45;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_b[_i] = zT_44[_i];
        _i++;
    }
}
    zT_49 = 0;
    zT_50 = 0;
    zT_48[zT_50] = zT_49;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k[_i] = zT_48[_i];
        _i++;
    }
}
    zT_51 = 0;
    zT_52 = ifs_b[zT_51];
    if ((int)(zT_52 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_33 = self;
    zT_36 = self->store;
    zT_37 = icap_idx;
    zT_39 = zF_8BA26B9E_astStoreNodePayload(zT_36, zT_37);
    zT_34 = zT_39;
    zT_40 = self;
    zT_41 = icond_t;
    zT_42 = zF_3E251D67_semanticAnalyzerCap(zT_40, zT_41);
    zT_35 = zT_42;
    zF_7BD72017_registerLocalDecl(zT_33, zT_34, zT_35);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_56 = self->store;
    zT_59 = 0;
    zT_57 = ifs_b[zT_59];
    zT_61 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    ifs_cn = zT_61;
    zT_62 = ifs_cn.kind;
    zT_63 = (unsigned int)zT_62;
    zT_64 = 0;
    ifs_k[zT_64] = zT_63;
    goto z_bb_6;
    z_bb_6:
    zT_66 = "IFST:N";
    zT_68 = 6;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    ifst_nm = zT_67;
    zT_69 = ifst_nm;
    zT_70 = node_idx;
    zF_C914CB83_markerWriteInt(zT_69, zT_70);
    zT_72 = "IFST:C";
    zT_74 = 6;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    ifst_cm = zT_73;
    zT_75 = ifst_cm;
    zT_77 = 0;
    zT_76 = ifs_b[zT_77];
    zF_C914CB83_markerWriteInt(zT_75, zT_76);
    zT_80 = "IFST:K";
    zT_82 = 6;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    ifst_km = zT_81;
    zT_83 = ifst_km;
    zT_85 = 0;
    zT_84 = ifs_k[zT_85];
    zF_C914CB83_markerWriteInt(zT_83, zT_84);
    zT_88 = "IFST:2";
    zT_90 = 6;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    ifst_c2m = zT_89;
    zT_91 = ifst_c2m;
    zT_92 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_91, zT_92);
    zT_96 = 0;
    zT_97 = 0;
    zT_95[zT_97] = zT_96;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k2[_i] = zT_95[_i];
        _i++;
    }
}
    zT_98 = node.child_2;
    if ((int)(zT_98 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_102 = self->store;
    zT_103 = node.child_2;
    zT_106 = zF_FCDD1D35_astStoreNodeAt(zT_102, zT_103);
    ifs_cn2 = zT_106;
    zT_107 = ifs_cn2.kind;
    zT_108 = (unsigned int)zT_107;
    zT_109 = 0;
    ifs_k2[zT_109] = zT_108;
    goto z_bb_8;
    z_bb_8:
    zT_111 = "IFST:K2";
    zT_113 = 7;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    ifst_k2m = zT_112;
    zT_114 = ifst_k2m;
    zT_116 = 0;
    zT_115 = ifs_k2[zT_116];
    zF_C914CB83_markerWriteInt(zT_114, zT_115);
    return;
}

/* semanticAnalyzerResolveForHeader */
void zF_8CE01C41_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    unsigned int zT_10 = 0;
    char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_8143F551_AstKind zT_30;
    zT_8EED1867_ResolvedTypeTable* zT_33;
    unsigned int zT_34;
    zT_BAEE192E_Opt_10 zT_37 = {0};
    unsigned char zT_38;
    char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_D155D06D_Type* zT_48;
    unsigned int zT_49;
    zT_D155D06D_Type zT_50;
    zT_939EE900_Arr_unsigned_int_1 zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    zT_338B7C76_TypeRegistry* zT_60;
    zT_0BB2A741_SlicePayload* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    zT_0BB2A741_SlicePayload zT_64;
    unsigned int zT_65;
    int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_E834303C_ArrayPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_E834303C_ArrayPayload zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_8143F551_AstKind zT_79;
    int zT_84;
    zT_8143F551_AstKind zT_85;
    int zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    int zT_97;
    int zT_98;
    unsigned int zT_99;
    char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_109;
    unsigned int zT_111 = 0;
    char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    int zT_118;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_38C12417_SemanticAnalyzer* zT_123;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int zT_125;
    unsigned int zT_127 = 0;
    unsigned int* zT_128;
    unsigned int zT_129;
    int zT_130;
    unsigned int zT_131;
    unsigned int* zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_146 = 0;
    char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    int zT_153;
    char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_38C12417_SemanticAnalyzer* zT_166;
    unsigned int zT_167;
    unsigned int* zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned int* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_c_m;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_ck_m;
    zT_BAEE192E_Opt_10 it_tid;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_tid_m;
    zT_D155D06D_Type ty;
    zT_939EE900_Arr_unsigned_int_1 elem_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u a5_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_p_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_e_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u f2_m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node.child_0;
    zT_10 = zF_54F95822_semanticAnalyzerRes(zT_7, zT_8);
    (void)zT_10;
    zT_12 = "FS:C";
    zT_14 = 4;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    fs_c_m = zT_13;
    zT_15 = fs_c_m;
    zT_16 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_19 = self->store;
    zT_20 = node.child_0;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    cnode = zT_23;
    zT_25 = "FS:CK";
    zT_27 = 5;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    fs_ck_m = zT_26;
    zT_28 = fs_ck_m;
    zT_30 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_28, (unsigned int)((unsigned int)zT_30));
    zT_33 = self->type_table;
    zT_34 = node.child_0;
    zT_37 = zF_999DCF51_resolvedTypeTableGe(zT_33, zT_34);
    it_tid = zT_37;
    zT_38 = it_tid.has_value;
    if (zT_38) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    tid = it_tid.value;
    zT_41 = "FS:T";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    fs_tid_m = zT_42;
    zT_44 = fs_tid_m;
    zT_45 = tid;
    zF_C914CB83_markerWriteInt(zT_44, zT_45);
    zT_47 = self->registry;
    zT_48 = zT_47->types_items;
    zT_49 = (unsigned int)tid;
    zT_50 = zT_48[zT_49];
    ty = zT_50;
    zT_53 = 18;
    zT_54 = 0;
    zT_52[zT_54] = zT_53;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        elem_box[_i] = zT_52[_i];
        _i++;
    }
}
    zT_55 = ty.kind;
    if ((int)(zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_160 = node.child_2;
    if ((int)(zT_160 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_3:
    zT_156 = "FS:M\n";
    zT_158 = 5;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    a5_m = zT_157;
    zT_159 = a5_m;
    zF_48AC7B3A_markerWrite(zT_159);
    goto z_bb_2;
    z_bb_4:
    zT_60 = self->registry;
    zT_61 = zT_60->slice_items;
    zT_62 = ty.payload_idx;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zT_61[zT_63];
    zT_65 = zT_64.elem;
    zT_66 = 0;
    elem_box[zT_66] = zT_65;
    goto z_bb_5;
    z_bb_5:
    zT_91 = self->store;
    zT_92 = node_idx;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    if ((int)(zT_94 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_6:
    zT_67 = ty.kind;
    if ((int)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_72 = self->registry;
    zT_73 = zT_72->array_items;
    zT_74 = ty.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    zT_77 = zT_76.elem;
    zT_78 = 0;
    elem_box[zT_78] = zT_77;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_79 = cnode.kind;
    if ((int)(zT_79 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_85 = cnode.kind;
    zT_84 = zT_85 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_12;
    z_bb_11:
    zT_84 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_84) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_90 = 0;
    elem_box[zT_90] = tid;
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    zT_98 = 0;
    zT_99 = elem_box[zT_98];
    zT_97 = zT_99 != (unsigned int)(18);
    goto z_bb_17;
    z_bb_16:
    zT_97 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_97) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_103 = "FS:P";
    zT_105 = 4;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    fs_p_m = zT_104;
    zT_106 = fs_p_m;
    zT_108 = self->store;
    zT_109 = node_idx;
    zT_111 = zF_8BA26B9E_astStoreNodePayload(zT_108, zT_109);
    zT_107 = zT_111;
    zF_C914CB83_markerWriteInt(zT_106, zT_107);
    zT_113 = "FS:E";
    zT_115 = 4;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    fs_e_m = zT_114;
    zT_116 = fs_e_m;
    zT_118 = 0;
    zT_117 = elem_box[zT_118];
    zF_C914CB83_markerWriteInt(zT_116, zT_117);
    zT_120 = self->local_decl_count;
    zT_121 = self->local_decl_cap;
    if ((int)(zT_120 >= zT_121)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_123 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_123);
    goto z_bb_21;
    z_bb_21:
    zT_124 = self->store;
    zT_125 = node_idx;
    zT_127 = zF_8BA26B9E_astStoreNodePayload(zT_124, zT_125);
    zT_128 = self->local_decl_names;
    zT_129 = self->local_decl_count;
    zT_128[zT_129] = zT_127;
    zT_130 = 0;
    zT_131 = elem_box[zT_130];
    zT_132 = self->local_decl_types;
    zT_133 = self->local_decl_count;
    zT_132[zT_133] = zT_131;
    zT_134 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_134 + (unsigned int)(1));
    zT_138 = "D4F:N";
    zT_140 = 5;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    d4f_n = zT_139;
    zT_141 = d4f_n;
    zT_143 = self->store;
    zT_144 = node_idx;
    zT_146 = zF_8BA26B9E_astStoreNodePayload(zT_143, zT_144);
    zT_142 = zT_146;
    zF_C914CB83_markerWriteInt(zT_141, zT_142);
    zT_148 = "D4F:T";
    zT_150 = 5;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    d4f_t = zT_149;
    zT_151 = d4f_t;
    zT_153 = 0;
    zT_152 = elem_box[zT_153];
    zF_C914CB83_markerWriteInt(zT_151, zT_152);
    goto z_bb_19;
    z_bb_22:
    zT_163 = self->local_decl_count;
    zT_164 = self->local_decl_cap;
    if ((int)(zT_163 >= zT_164)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    return;
    z_bb_24:
    zT_166 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_166);
    goto z_bb_25;
    z_bb_25:
    zT_167 = node.child_2;
    zT_168 = self->local_decl_names;
    zT_169 = self->local_decl_count;
    zT_168[zT_169] = zT_167;
    zT_170 = 13;
    zT_171 = self->local_decl_types;
    zT_172 = self->local_decl_count;
    zT_171[zT_172] = zT_170;
    zT_173 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_173 + (unsigned int)(1));
    zT_177 = "FIX2:LN";
    zT_179 = 7;
    zT_178.ptr = zT_177;
    zT_178.len = zT_179;
    f2_m = zT_178;
    zT_180 = f2_m;
    zT_181 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_180, zT_181);
    goto z_bb_23;
}

/* semanticAnalyzerResolveWhileHeader */
void zF_10900223_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_15 = {0};
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_38C12417_SemanticAnalyzer* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_62 = 0;
    zT_38C12417_SemanticAnalyzer* zT_63;
    unsigned int zT_64;
    unsigned int zT_65 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode ws_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_km;
    unsigned int wcond_t;
    unsigned int wcap_idx;
    zT_22A7C88B_AstNode wcap_node;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_1;
    if ((int)(zT_7 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self->store;
    zT_12 = node.child_1;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    ws_node = zT_15;
    zT_17 = "WST:N";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    wst_nm = zT_18;
    zT_20 = wst_nm;
    zT_21 = node_idx;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = "WST:K";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    wst_km = zT_24;
    zT_26 = wst_km;
    zT_28 = ws_node.kind;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    goto z_bb_2;
    z_bb_2:
    zT_31 = self;
    zT_32 = node.child_0;
    zT_34 = zF_54F95822_semanticAnalyzerRes(zT_31, zT_32);
    wcond_t = zT_34;
    zT_35 = self->store;
    zT_36 = node_idx;
    zT_38 = zF_8BA26B9E_astStoreNodePayload(zT_35, zT_36);
    if ((int)(zT_38 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_42 = self->store;
    zT_43 = node_idx;
    zT_45 = zF_8BA26B9E_astStoreNodePayload(zT_42, zT_43);
    wcap_idx = zT_45;
    zT_47 = self->store;
    zT_48 = wcap_idx;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    wcap_node = zT_50;
    zT_51 = wcap_node.kind;
    if ((int)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return;
    z_bb_5:
    zT_56 = self;
    zT_59 = self->store;
    zT_60 = wcap_idx;
    zT_62 = zF_8BA26B9E_astStoreNodePayload(zT_59, zT_60);
    zT_57 = zT_62;
    zT_63 = self;
    zT_64 = wcond_t;
    zT_65 = zF_3E251D67_semanticAnalyzerCap(zT_63, zT_64);
    zT_58 = zT_65;
    zF_7BD72017_registerLocalDecl(zT_56, zT_57, zT_58);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* semanticAnalyzerResolveStmtIter */
void zF_10A0DC35_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int root_node) {
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_21 = {0};
    char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_28;
    char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_8143F551_AstKind zT_36;
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_47 = {0};
    char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_61;
    unsigned int zT_65;
    unsigned int* zT_69;
    unsigned int zT_71;
    unsigned int zT_72;
    char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_99;
    char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_108;
    unsigned int zT_110;
    char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_8143F551_AstKind zT_116;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_124 = 0;
    char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    unsigned int zT_141;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    zT_22A7C88B_AstNode zT_149 = {0};
    char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_8143F551_AstKind zT_156;
    char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    unsigned int zT_167 = 0;
    char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_174;
    unsigned int zT_178;
    unsigned int zT_179;
    zT_6B0A7D14_AstStore* zT_183;
    unsigned int zT_184;
    zT_22A7C88B_AstNode zT_187 = {0};
    zT_8143F551_AstKind zT_188;
    zT_38C12417_SemanticAnalyzer* zT_193;
    unsigned int zT_194;
    unsigned int zT_196 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_200;
    zT_6B0A7D14_AstStore* zT_201;
    zT_338B7C76_TypeRegistry* zT_202;
    zT_3D7259E2_SymbolRegistry* zT_203;
    zT_D3EB6303_StringInterner* zT_204;
    unsigned int zT_205;
    zT_ABC1EBBE_TypeResolveEnv* zT_207;
    unsigned int zT_208;
    unsigned int zT_213 = 0;
    char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_F85C5DED_DiagnosticCollector* zT_220;
    unsigned int zT_223;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_236 = 0;
    unsigned int zT_237;
    zT_8EED1867_ResolvedTypeTable* zT_239;
    unsigned int zT_240;
    zT_BAEE192E_Opt_10 zT_243 = {0};
    unsigned char zT_244;
    zT_ABC1EBBE_TypeResolveEnv zT_247;
    zT_6B0A7D14_AstStore* zT_248;
    zT_338B7C76_TypeRegistry* zT_249;
    zT_3D7259E2_SymbolRegistry* zT_250;
    zT_D3EB6303_StringInterner* zT_251;
    unsigned int zT_252;
    zT_ABC1EBBE_TypeResolveEnv* zT_253;
    unsigned int zT_254;
    unsigned int zT_259 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    char* zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_276;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    int zT_283;
    unsigned char* zT_284;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287 = 0;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned char* zT_296;
    unsigned int zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    char* zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    unsigned int zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_305;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    int zT_311;
    unsigned char* zT_312;
    unsigned int zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    unsigned int zT_315 = 0;
    unsigned int zT_319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    unsigned char* zT_324;
    unsigned int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    char* zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    unsigned int zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    zT_6B0A7D14_AstStore* zT_336;
    unsigned int zT_337;
    zT_22A7C88B_AstNode zT_340 = {0};
    char* zT_342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    unsigned int zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    zT_8143F551_AstKind zT_347;
    unsigned int zT_353;
    zT_38C12417_SemanticAnalyzer* zT_355;
    unsigned int zT_356;
    zT_38C12417_SemanticAnalyzer* zT_358;
    unsigned int zT_359;
    unsigned int zT_361 = 0;
    zT_38C12417_SemanticAnalyzer* zT_362;
    int zT_366;
    zT_8143F551_AstKind zT_367;
    zT_6B0A7D14_AstStore* zT_373;
    unsigned int zT_374;
    unsigned int zT_377 = 0;
    int zT_379;
    unsigned int zT_380;
    zT_338B7C76_TypeRegistry* zT_381;
    unsigned int zT_382;
    zT_338B7C76_TypeRegistry* zT_384;
    zT_D155D06D_Type* zT_385;
    zT_D155D06D_Type zT_386;
    zT_33EF6BFB_TypeKind zT_387;
    zT_338B7C76_TypeRegistry* zT_393;
    unsigned int zT_395;
    unsigned int zT_398 = 0;
    unsigned int zT_402;
    zT_21D3708C_U32ToU32Map* zT_404;
    unsigned int zT_405;
    unsigned int zT_407 = 0;
    zT_21D3708C_U32ToU32Map* zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    zT_8EED1867_ResolvedTypeTable* zT_413;
    unsigned int zT_414;
    unsigned int zT_415;
    int zT_418;
    unsigned int zT_419;
    int zT_423;
    zT_8143F551_AstKind zT_424;
    unsigned int zT_430;
    unsigned int zT_432;
    unsigned int zT_434;
    char* zT_436;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437;
    unsigned int zT_438;
    zT_F85C5DED_DiagnosticCollector* zT_439;
    unsigned int zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_445;
    unsigned int zT_453 = 0;
    int zT_457;
    char* zT_462;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_463;
    unsigned int zT_464;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_465;
    zT_338B7C76_TypeRegistry* zT_467;
    unsigned int zT_468;
    unsigned int zT_469;
    zT_38C12417_SemanticAnalyzer* zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    unsigned int zT_476 = 0;
    zT_0FB7FB13_CoercionKind zT_477 = 0;
    char* zT_479;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_480;
    unsigned int zT_481;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_482;
    zT_66E7D2EF_CoercionTable* zT_489;
    unsigned int zT_490;
    zT_0FB7FB13_CoercionKind zT_491;
    unsigned int zT_492;
    int zT_497;
    zT_338B7C76_TypeRegistry* zT_498;
    unsigned int zT_499;
    unsigned int zT_500;
    int zT_502 = 0;
    unsigned int zT_505;
    unsigned int zT_507;
    unsigned int zT_509;
    char* zT_511;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_512;
    unsigned int zT_513;
    zT_338B7C76_TypeRegistry* zT_515;
    zT_D155D06D_Type* zT_516;
    unsigned int zT_517;
    zT_D155D06D_Type zT_518;
    zT_33EF6BFB_TypeKind zT_519;
    zT_338B7C76_TypeRegistry* zT_521;
    zT_D155D06D_Type* zT_522;
    unsigned int zT_523;
    zT_D155D06D_Type zT_524;
    zT_33EF6BFB_TypeKind zT_525;
    int zT_527;
    unsigned char zT_528;
    int zT_533;
    zT_338B7C76_TypeRegistry* zT_539;
    zT_42C2D6BF_EUPayload* zT_540;
    zT_338B7C76_TypeRegistry* zT_541;
    zT_D155D06D_Type* zT_542;
    unsigned int zT_543;
    zT_D155D06D_Type zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    zT_42C2D6BF_EUPayload zT_547;
    zT_338B7C76_TypeRegistry* zT_549;
    zT_42C2D6BF_EUPayload* zT_550;
    zT_338B7C76_TypeRegistry* zT_551;
    zT_D155D06D_Type* zT_552;
    unsigned int zT_553;
    zT_D155D06D_Type zT_554;
    unsigned int zT_555;
    unsigned int zT_556;
    zT_42C2D6BF_EUPayload zT_557;
    unsigned int zT_558;
    unsigned int zT_559;
    int zT_561;
    unsigned char zT_562;
    zT_F85C5DED_DiagnosticCollector* zT_564;
    unsigned char zT_565;
    unsigned int zT_567;
    unsigned int zT_568;
    unsigned int zT_569;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_570;
    unsigned int zT_574 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_575;
    unsigned int zT_576;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_577;
    zT_33EF6BFB_TypeKind zT_579;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_580 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_581;
    unsigned int zT_582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_583;
    zT_33EF6BFB_TypeKind zT_585;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_586 = {0};
    char* zT_593;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_594;
    unsigned int zT_595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_596;
    char* zT_598;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_599;
    unsigned int zT_600;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    unsigned int zT_603;
    unsigned int zT_605;
    unsigned int zT_607;
    char* zT_609;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_610;
    unsigned int zT_611;
    zT_F85C5DED_DiagnosticCollector* zT_612;
    unsigned int zT_615;
    unsigned int zT_616;
    unsigned int zT_617;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_618;
    unsigned int zT_623 = 0;
    zT_66E7D2EF_CoercionTable* zT_625;
    unsigned int zT_626;
    zT_4EBDE306_Opt_184 zT_629 = {0};
    unsigned char zT_630;
    zT_8EED1867_ResolvedTypeTable* zT_632;
    unsigned int zT_633;
    unsigned int zT_634;
    unsigned int zT_637;
    unsigned int zT_638;
    zT_38C12417_SemanticAnalyzer* zT_640;
    zT_6B0A7D14_AstStore* zT_644;
    unsigned int zT_645;
    unsigned int zT_647 = 0;
    unsigned int* zT_648;
    unsigned int zT_649;
    unsigned int* zT_650;
    unsigned int zT_651;
    unsigned int zT_652;
    unsigned int zT_656;
    zT_6B0A7D14_AstStore* zT_660;
    unsigned int zT_661;
    unsigned int zT_663 = 0;
    zT_79FAE712_u64 zT_665;
    zT_338B7C76_TypeRegistry* zT_666;
    zT_79FAE712_u64 zT_667;
    unsigned int zT_668;
    char* zT_671;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_672;
    unsigned int zT_673;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_674;
    unsigned int zT_675;
    zT_6B0A7D14_AstStore* zT_676;
    unsigned int zT_677;
    unsigned int zT_679 = 0;
    char* zT_681;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_682;
    unsigned int zT_683;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_684;
    unsigned int zT_685;
    zT_8143F551_AstKind zT_686;
    zT_38C12417_SemanticAnalyzer* zT_691;
    unsigned int zT_692;
    unsigned int zT_693;
    zT_38C12417_SemanticAnalyzer* zT_696;
    unsigned int zT_697;
    unsigned int zT_699;
    zT_38C12417_SemanticAnalyzer* zT_702;
    unsigned int zT_703;
    zT_8143F551_AstKind zT_705;
    zT_38C12417_SemanticAnalyzer* zT_710;
    unsigned int zT_711;
    unsigned int zT_712;
    zT_38C12417_SemanticAnalyzer* zT_715;
    unsigned int zT_716;
    zT_8143F551_AstKind zT_718;
    zT_38C12417_SemanticAnalyzer* zT_723;
    unsigned int zT_724;
    unsigned int zT_725;
    zT_38C12417_SemanticAnalyzer* zT_728;
    unsigned int zT_729;
    zT_8143F551_AstKind zT_731;
    zT_38C12417_SemanticAnalyzer* zT_736;
    unsigned int zT_737;
    zT_8143F551_AstKind zT_738;
    int zT_743;
    zT_8143F551_AstKind zT_744;
    int zT_749;
    zT_8143F551_AstKind zT_750;
    int zT_755;
    zT_8143F551_AstKind zT_756;
    int zT_761;
    zT_8143F551_AstKind zT_762;
    int zT_767;
    zT_8143F551_AstKind zT_768;
    int zT_773;
    zT_8143F551_AstKind zT_774;
    int zT_779;
    zT_8143F551_AstKind zT_780;
    int zT_785;
    zT_8143F551_AstKind zT_786;
    int zT_791;
    zT_8143F551_AstKind zT_792;
    int zT_797;
    zT_8143F551_AstKind zT_798;
    int zT_803;
    zT_8143F551_AstKind zT_804;
    int zT_809;
    zT_8143F551_AstKind zT_810;
    int zT_815;
    zT_8143F551_AstKind zT_816;
    int zT_821;
    zT_8143F551_AstKind zT_822;
    int zT_827;
    zT_8143F551_AstKind zT_828;
    int zT_833;
    zT_8143F551_AstKind zT_834;
    int zT_839;
    zT_8143F551_AstKind zT_840;
    zT_38C12417_SemanticAnalyzer* zT_845;
    unsigned int zT_846;
    unsigned int zT_847 = 0;
    zT_8143F551_AstKind zT_848;
    unsigned int zT_853;
    zT_38C12417_SemanticAnalyzer* zT_856;
    unsigned int zT_857;
    zT_8143F551_AstKind zT_859;
    int zT_864;
    zT_8143F551_AstKind zT_865;
    unsigned int zT_870;
    zT_38C12417_SemanticAnalyzer* zT_873;
    unsigned int zT_874;
    zT_8143F551_AstKind zT_876;
    zT_8143F551_AstKind zT_881;
    char* zT_887;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_888;
    unsigned int zT_889;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_890;
    unsigned int zT_891;
    char* zT_893;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_894;
    unsigned int zT_895;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_896;
    zT_8143F551_AstKind zT_898;
    unsigned int zT_900;
    char* zT_904;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_905;
    unsigned int zT_906;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_907;
    unsigned int zT_908;
    zT_38C12417_SemanticAnalyzer* zT_910;
    unsigned int zT_911;
    unsigned int zT_912 = 0;
    unsigned int zT_913;
    zT_6B0A7D14_AstStore* zT_917;
    unsigned int zT_918;
    zT_22A7C88B_AstNode zT_921 = {0};
    zT_8143F551_AstKind zT_922;
    unsigned int zT_927;
    zT_6B0A7D14_AstStore* zT_931;
    unsigned int zT_932;
    zT_22A7C88B_AstNode zT_935 = {0};
    zT_8143F551_AstKind zT_936;
    unsigned int sp_base;
    unsigned int node_idx;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u spk_m;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_cm;
    unsigned int i;
    unsigned int ci;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_nm;
    zT_8143F551_AstKind cnode_k;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u bcej;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd2_m;
    unsigned int decl_type;
    zT_22A7C88B_AstNode inode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10k_m;
    zT_22A7C88B_AstNode ann;
    zT_BAEE192E_Opt_10 rt;
    zT_ABC1EBBE_TypeResolveEnv cd_env;
    unsigned int cd_full;
    zT_8F083A69_Slice_zT_0B42B2F8_u ut_msg;
    unsigned int t;
    zT_ABC1EBBE_TypeResolveEnv tre_env_vd;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1m;
    zT_5A26C2ED_Arr_unsigned_char_1 b1nb;
    unsigned int b1nl;
    unsigned int b1ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1c;
    zT_5A26C2ED_Arr_unsigned_char_1 b1tb;
    unsigned int b1tl;
    unsigned int b1ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1nl2;
    zT_22A7C88B_AstNode init_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ik_m;
    unsigned int vd_exp;
    unsigned int it;
    unsigned int name_id;
    unsigned int ei;
    unsigned int ord;
    unsigned int es_type_id;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs4_m;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u ckv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmd_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdag_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vfvd_m;
    unsigned int vsp;
    unsigned int vep;
    zT_8F083A69_Slice_zT_0B42B2F8_u vv_msg;
    zT_4EBDE306_Opt_184 ct_entry;
    zT_79FAE712_u64 ck_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u regcp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u regct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_c0m;
    zT_22A7C88B_AstNode nc;
    zT_3 = self->stmt_work_len;
    sp_base = zT_3;
    zT_4 = self;
    zT_5 = root_node;
    zF_7AB741D8_semanticAnalyzerStm(zT_4, zT_5);
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->stmt_work_len;
    if ((int)(zT_6 > sp_base)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_8 - (unsigned int)(1));
    zT_12 = self->stmt_work_items;
    zT_13 = self->stmt_work_len;
    zT_14 = zT_12[zT_13];
    node_idx = zT_14;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_18 = self->store;
    zT_19 = node_idx;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    node = zT_21;
    zT_23 = "SP:n";
    zT_25 = 4;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    sp_m = zT_24;
    zT_26 = sp_m;
    zT_28 = self->stmt_work_len;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    zT_31 = "SP:K";
    zT_33 = 4;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    spk_m = zT_32;
    zT_34 = spk_m;
    zT_36 = node.kind;
    zF_C914CB83_markerWriteInt(zT_34, (unsigned int)((unsigned int)zT_36));
    zT_38 = node.kind;
    if ((int)(zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_44 = self->store;
    zT_45 = node_idx;
    zT_47 = zF_850FDF81_astStoreNodeExtraCh(zT_44, zT_45);
    children = zT_47;
    zT_49 = "BLK:N";
    zT_51 = 5;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    blk_nm = zT_50;
    zT_52 = blk_nm;
    zT_53 = node_idx;
    zF_C914CB83_markerWriteInt(zT_52, zT_53);
    zT_55 = "BLK:C";
    zT_57 = 5;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    blk_cm = zT_56;
    zT_58 = blk_cm;
    zT_61 = children.len;
    zF_C914CB83_markerWriteInt(zT_58, (unsigned int)((unsigned int)zT_61));
    zT_65 = children.len;
    i = zT_65;
    goto z_bb_10;
    z_bb_8:
    zT_913 = node.child_0;
    if ((int)(zT_913 != (unsigned int)(0))) goto z_bb_187; else goto z_bb_188;
    z_bb_9:
    zT_116 = node.kind;
    if ((int)(zT_116 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_14; else goto z_bb_16;
    z_bb_10:
    if ((int)(i > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_69 = children.ptr;
    zT_71 = i - (unsigned int)(1);
    zT_72 = zT_69[zT_71];
    ci = zT_72;
    zT_74 = "BCK:B";
    zT_76 = 5;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    bc_m = zT_75;
    zT_77 = bc_m;
    zT_78 = node_idx;
    zF_C914CB83_markerWriteInt(zT_77, zT_78);
    zT_80 = "BCK:I";
    zT_82 = 5;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    bc_im = zT_81;
    zT_83 = bc_im;
    zF_C914CB83_markerWriteInt(zT_83, (unsigned int)((unsigned int)(unsigned int)(i - (unsigned int)(1))));
    zT_89 = "BCK:N";
    zT_91 = 5;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    bc_nm = zT_90;
    zT_92 = bc_nm;
    zT_93 = ci;
    zF_C914CB83_markerWriteInt(zT_92, zT_93);
    zT_95 = self->store;
    zT_96 = ci;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_95, zT_96);
    zT_99 = zT_98.kind;
    cnode_k = zT_99;
    zT_101 = "BCK:K";
    zT_103 = 5;
    zT_102.ptr = zT_101;
    zT_102.len = zT_103;
    bc_km = zT_102;
    zT_104 = bc_km;
    zF_C914CB83_markerWriteInt(zT_104, (unsigned int)((unsigned int)cnode_k));
    zT_107 = self;
    zT_108 = ci;
    zF_7AB741D8_semanticAnalyzerStm(zT_107, zT_108);
    goto z_bb_13;
    z_bb_12:
    zT_112 = "]\n";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    bcej = zT_113;
    zT_115 = bcej;
    zF_48AC7B3A_markerWrite(zT_115);
    goto z_bb_8;
    z_bb_13:
    zT_110 = i - (unsigned int)(1);
    i = zT_110;
    goto z_bb_10;
    z_bb_14:
    zT_121 = self->store;
    zT_122 = node_idx;
    zT_124 = zF_8BA26B9E_astStoreNodePayload(zT_121, zT_122);
    if ((int)(zT_124 == (unsigned int)(55))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_686 = node.kind;
    if ((int)(zT_686 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_92; else goto z_bb_94;
    z_bb_17:
    zT_128 = "D10:C0";
    zT_130 = 6;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    d10n_m = zT_129;
    zT_131 = d10n_m;
    zT_132 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_131, zT_132);
    zT_135 = "D10:C1";
    zT_137 = 6;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    d10c_m = zT_136;
    zT_138 = d10c_m;
    zT_139 = node.child_1;
    zF_C914CB83_markerWriteInt(zT_138, zT_139);
    zT_141 = node.child_1;
    if ((int)(zT_141 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_159 = "VD:N";
    zT_161 = 4;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    vd_m = zT_160;
    zT_162 = vd_m;
    zT_164 = self->store;
    zT_165 = node_idx;
    zT_167 = zF_8BA26B9E_astStoreNodePayload(zT_164, zT_165);
    zT_163 = zT_167;
    zF_C914CB83_markerWriteInt(zT_162, zT_163);
    zT_169 = "VD:C";
    zT_171 = 4;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    vd2_m = zT_170;
    zT_172 = vd2_m;
    zT_174 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_172, (unsigned int)((unsigned int)zT_174));
    zT_178 = 18;
    decl_type = zT_178;
    zT_179 = node.child_0;
    if ((int)(zT_179 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_145 = self->store;
    zT_146 = node.child_1;
    zT_149 = zF_FCDD1D35_astStoreNodeAt(zT_145, zT_146);
    inode = zT_149;
    zT_151 = "D10:IK";
    zT_153 = 6;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    d10k_m = zT_152;
    zT_154 = d10k_m;
    zT_156 = inode.kind;
    zF_C914CB83_markerWriteInt(zT_154, (unsigned int)((unsigned int)zT_156));
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_183 = self->store;
    zT_184 = node.child_0;
    zT_187 = zF_FCDD1D35_astStoreNodeAt(zT_183, zT_184);
    ann = zT_187;
    zT_188 = ann.kind;
    if ((int)(zT_188 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_35; else goto z_bb_36;
    z_bb_23:
    zT_193 = self;
    zT_194 = node.child_0;
    zT_196 = zF_54F95822_semanticAnalyzerRes(zT_193, zT_194);
    decl_type = zT_196;
    if ((int)(decl_type == (unsigned int)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_239 = self->type_table;
    zT_240 = node.child_0;
    zT_243 = zF_999DCF51_resolvedTypeTableGe(zT_239, zT_240);
    rt = zT_243;
    zT_244 = rt.has_value;
    if (zT_244) goto z_bb_30; else goto z_bb_32;
    z_bb_26:
    zT_201 = self->store;
    zT_200.store = zT_201;
    zT_202 = self->registry;
    zT_200.typereg = zT_202;
    zT_203 = self->symbols;
    zT_200.symbol_reg = zT_203;
    zT_204 = self->interner;
    zT_200.interner = zT_204;
    zT_205 = self->module_id;
    zT_200.module_id = zT_205;
    cd_env = zT_200;
    zT_207 = &cd_env;
    zT_208 = node.child_0;
    zT_213 = zF_F2107C15_resolveTypeExprFull(zT_207, zT_208, (unsigned int)(0));
    cd_full = zT_213;
    if ((int)(cd_full == (unsigned int)(18))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_217 = "unknown type in variable declaration";
    zT_219 = 36;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    ut_msg = zT_218;
    zT_220 = self->diag;
    zT_223 = self->source_file_id;
    zT_224 = ann.span_start;
    zT_232 = ann.span_start;
    zT_233 = ann.span_len;
    zT_226 = ut_msg;
    zT_236 = zF_C82559AC_diagnosticCollector(zT_220, (unsigned char)(0), (unsigned short)(3000), zT_223, zT_224, (unsigned int)(zT_232 + (unsigned int)((unsigned int)zT_233)), zT_226);
    (void)zT_236;
    zT_237 = 18;
    decl_type = zT_237;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    t = rt.value;
    decl_type = t;
    goto z_bb_31;
    z_bb_31:
    goto z_bb_24;
    z_bb_32:
    zT_248 = self->store;
    zT_247.store = zT_248;
    zT_249 = self->registry;
    zT_247.typereg = zT_249;
    zT_250 = self->symbols;
    zT_247.symbol_reg = zT_250;
    zT_251 = self->interner;
    zT_247.interner = zT_251;
    zT_252 = self->module_id;
    zT_247.module_id = zT_252;
    tre_env_vd = zT_247;
    zT_253 = &tre_env_vd;
    zT_254 = node.child_0;
    zT_259 = zF_F2107C15_resolveTypeExprFull(zT_253, zT_254, (unsigned int)(0));
    decl_type = zT_259;
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_262 = self->type_table;
    zT_263 = node.child_0;
    zT_264 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_262, zT_263, zT_264);
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_271 = "VRT:";
    zT_273 = 4;
    zT_272.ptr = zT_271;
    zT_272.len = zT_273;
    b1m = zT_272;
    zT_274 = b1m;
    zF_48AC7B3A_markerWrite(zT_274);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_276[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1nb[_i] = zT_276[_i];
        _i++;
    }
}
    zT_278 = node.child_0;
    zT_283 = 0;
    zT_284 = (unsigned char*)((unsigned char*)b1nb) + zT_283;
    zT_285 = (unsigned int)(10) - zT_283;
    zT_286.ptr = zT_284;
    zT_286.len = zT_285;
    zT_279 = zT_286;
    zT_287 = zF_A7504564_itoa(zT_278, zT_279);
    b1nl = zT_287;
    zT_291 = (unsigned int)(9) - (unsigned int)((unsigned int)b1nl);
    b1ns = zT_291;
    zT_296 = (unsigned char*)((unsigned char*)b1nb) + b1ns;
    zT_297 = (unsigned int)(9) - b1ns;
    zT_298.ptr = zT_296;
    zT_298.len = zT_297;
    zT_292 = zT_298;
    zF_48AC7B3A_markerWrite(zT_292);
    zT_300 = ":";
    zT_302 = 1;
    zT_301.ptr = zT_300;
    zT_301.len = zT_302;
    b1c = zT_301;
    zT_303 = b1c;
    zF_48AC7B3A_markerWrite(zT_303);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_305[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1tb[_i] = zT_305[_i];
        _i++;
    }
}
    zT_307 = decl_type;
    zT_311 = 0;
    zT_312 = (unsigned char*)((unsigned char*)b1tb) + zT_311;
    zT_313 = (unsigned int)(10) - zT_311;
    zT_314.ptr = zT_312;
    zT_314.len = zT_313;
    zT_308 = zT_314;
    zT_315 = zF_A7504564_itoa(zT_307, zT_308);
    b1tl = zT_315;
    zT_319 = (unsigned int)(9) - (unsigned int)((unsigned int)b1tl);
    b1ts = zT_319;
    zT_324 = (unsigned char*)((unsigned char*)b1tb) + b1ts;
    zT_325 = (unsigned int)(9) - b1ts;
    zT_326.ptr = zT_324;
    zT_326.len = zT_325;
    zT_320 = zT_326;
    zF_48AC7B3A_markerWrite(zT_320);
    zT_328 = "\n";
    zT_330 = 1;
    zT_329.ptr = zT_328;
    zT_329.len = zT_330;
    b1nl2 = zT_329;
    zT_331 = b1nl2;
    zF_48AC7B3A_markerWrite(zT_331);
    goto z_bb_36;
    z_bb_36:
    zT_332 = node.child_1;
    if ((int)(zT_332 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_336 = self->store;
    zT_337 = node.child_1;
    zT_340 = zF_FCDD1D35_astStoreNodeAt(zT_336, zT_337);
    init_node = zT_340;
    zT_342 = "I:K";
    zT_344 = 3;
    zT_343.ptr = zT_342;
    zT_343.len = zT_344;
    ik_m = zT_343;
    zT_345 = ik_m;
    zT_347 = init_node.kind;
    zF_C914CB83_markerWriteInt(zT_345, (unsigned int)((unsigned int)zT_347));
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_637 = self->local_decl_count;
    zT_638 = self->local_decl_cap;
    if ((int)(zT_637 >= zT_638)) goto z_bb_88; else goto z_bb_89;
    z_bb_39:
    zT_353 = decl_type;
    goto z_bb_41;
    z_bb_40:
    zT_353 = 0;
    goto z_bb_41;
    z_bb_41:
    vd_exp = zT_353;
    zT_355 = self;
    zT_356 = vd_exp;
    zF_9665A229_pushExpectedType(zT_355, zT_356);
    zT_358 = self;
    zT_359 = node.child_1;
    zT_361 = zF_54F95822_semanticAnalyzerRes(zT_358, zT_359);
    it = zT_361;
    zT_362 = self;
    zF_BC478E78_popExpectedType(zT_362);
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_367 = init_node.kind;
    zT_366 = zT_367 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal);
    goto z_bb_44;
    z_bb_43:
    zT_366 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_366) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_373 = self->store;
    zT_374 = node.child_1;
    zT_377 = zF_8BA26B9E_astStoreNodePayload(zT_373, zT_374);
    name_id = zT_377;
    zT_379 = 0;
    zT_380 = (unsigned int)zT_379;
    ei = zT_380;
    goto z_bb_47;
    z_bb_46:
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_55; else goto z_bb_56;
    z_bb_47:
    zT_381 = self->registry;
    zT_382 = zT_381->types_len;
    if ((int)(ei < zT_382)) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_384 = self->registry;
    zT_385 = zT_384->types_items;
    zT_386 = zT_385[ei];
    zT_387 = zT_386.kind;
    if ((int)(zT_387 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_418 = 1;
    zT_419 = ei + zT_418;
    ei = zT_419;
    goto z_bb_47;
    z_bb_51:
    zT_393 = self->registry;
    zT_395 = name_id;
    zT_398 = zF_D2ECD176_typeRegistryErrorSe(zT_393, (unsigned int)((unsigned int)ei), zT_395);
    ord = zT_398;
    if ((int)(ord != (unsigned int)(4294967295u))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    zT_402 = (unsigned int)ei;
    es_type_id = zT_402;
    zT_404 = self->error_code_registry;
    zT_405 = name_id;
    zT_407 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_404, zT_405);
    reg_code = zT_407;
    zT_408 = self->enum_value_table;
    zT_409 = node.child_1;
    zT_410 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_408, zT_409, zT_410);
    zT_413 = self->type_table;
    zT_414 = node.child_1;
    zT_415 = es_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_413, zT_414, zT_415);
    it = es_type_id;
    goto z_bb_49;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_424 = init_node.kind;
    zT_423 = zT_424 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_57;
    z_bb_56:
    zT_423 = 0;
    goto z_bb_57;
    z_bb_57:
    if (zT_423) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_430 = init_node.span_start;
    sp = zT_430;
    zT_432 = init_node.span_len;
    zT_434 = sp + (unsigned int)((unsigned int)zT_432);
    ep = zT_434;
    zT_436 = "unable to infer type of enum literal without context";
    zT_438 = 52;
    zT_437.ptr = zT_436;
    zT_437.len = zT_438;
    elu_msg = zT_437;
    zT_439 = self->diag;
    zT_442 = self->source_file_id;
    zT_443 = sp;
    zT_444 = ep;
    zT_445 = elu_msg;
    zT_453 = zF_C82559AC_diagnosticCollector(zT_439, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3010_CANNOT_INFER_ENUM_LITERAL_TYPE)), zT_442, zT_443, zT_444, zT_445);
    (void)zT_453;
    goto z_bb_59;
    z_bb_59:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_457 = it != decl_type;
    goto z_bb_62;
    z_bb_61:
    zT_457 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_457) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    if ((int)(it == (unsigned int)(17))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_82; else goto z_bb_83;
    z_bb_65:
    zT_462 = "CS4\n";
    zT_464 = 4;
    zT_463.ptr = zT_462;
    zT_463.len = zT_464;
    cs4_m = zT_463;
    zT_465 = cs4_m;
    zF_48AC7B3A_markerWrite(zT_465);
    goto z_bb_66;
    z_bb_66:
    zT_467 = self->registry;
    zT_471 = self;
    zT_472 = node.child_1;
    zT_473 = decl_type;
    zT_474 = it;
    zT_476 = zF_FFC95E09_errLitSrcType(zT_471, zT_472, zT_473, zT_474);
    zT_468 = zT_476;
    zT_469 = decl_type;
    zT_477 = zF_713658BF_classifyCoercion(zT_467, zT_468, zT_469);
    ck = zT_477;
    zT_479 = "CCK:vr";
    zT_481 = 6;
    zT_480.ptr = zT_479;
    zT_480.len = zT_481;
    ckv_m = zT_480;
    zT_482 = ckv_m;
    zF_C914CB83_markerWriteInt(zT_482, (unsigned int)((unsigned int)ck));
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_67; else goto z_bb_69;
    z_bb_67:
    zT_489 = self->coercion_table;
    zT_490 = node.child_1;
    zT_491 = ck;
    zT_492 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_489, zT_490, zT_491, zT_492);
    goto z_bb_68;
    z_bb_68:
    goto z_bb_64;
    z_bb_69:
    if ((int)(it != (unsigned int)(18))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_498 = self->registry;
    zT_499 = it;
    zT_500 = decl_type;
    zT_502 = zF_683AEB7F_typeRegistryIsAssig(zT_498, zT_499, zT_500);
    zT_497 = !zT_502;
    goto z_bb_72;
    z_bb_71:
    zT_497 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_497) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_505 = node.span_start;
    sp = zT_505;
    zT_507 = node.span_len;
    zT_509 = sp + (unsigned int)((unsigned int)zT_507);
    ep = zT_509;
    zT_511 = "type mismatch in variable declaration — initialization type may not be compatible with declared type";
    zT_513 = 102;
    zT_512.ptr = zT_511;
    zT_512.len = zT_513;
    tmd_msg = zT_512;
    zT_515 = self->registry;
    zT_516 = zT_515->types_items;
    zT_517 = (unsigned int)it;
    zT_518 = zT_516[zT_517];
    zT_519 = zT_518.kind;
    sk = zT_519;
    zT_521 = self->registry;
    zT_522 = zT_521->types_items;
    zT_523 = (unsigned int)decl_type;
    zT_524 = zT_522[zT_523];
    zT_525 = zT_524.kind;
    tk = zT_525;
    zT_527 = 1;
    zT_528 = (unsigned char)zT_527;
    level = zT_528;
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    goto z_bb_68;
    z_bb_75:
    zT_533 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_77;
    z_bb_76:
    zT_533 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_533) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_539 = self->registry;
    zT_540 = zT_539->eu_items;
    zT_541 = self->registry;
    zT_542 = zT_541->types_items;
    zT_543 = (unsigned int)it;
    zT_544 = zT_542[zT_543];
    zT_545 = zT_544.payload_idx;
    zT_546 = (unsigned int)zT_545;
    zT_547 = zT_540[zT_546];
    eu_src = zT_547;
    zT_549 = self->registry;
    zT_550 = zT_549->eu_items;
    zT_551 = self->registry;
    zT_552 = zT_551->types_items;
    zT_553 = (unsigned int)decl_type;
    zT_554 = zT_552[zT_553];
    zT_555 = zT_554.payload_idx;
    zT_556 = (unsigned int)zT_555;
    zT_557 = zT_550[zT_556];
    eu_tgt = zT_557;
    zT_558 = eu_src.error_set;
    zT_559 = eu_tgt.error_set;
    if ((int)(zT_558 == zT_559)) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_564 = self->diag;
    zT_565 = level;
    zT_567 = self->source_file_id;
    zT_568 = sp;
    zT_569 = ep;
    zT_570 = tmd_msg;
    zT_574 = zF_C82559AC_diagnosticCollector(zT_564, zT_565, (unsigned short)(3000), zT_567, zT_568, zT_569, zT_570);
    di = zT_574;
    zT_575 = self->diag;
    zT_576 = di;
    zT_579 = sk;
    zT_580 = zF_C14453DE_typeKindSrcStr(zT_579);
    zT_577 = zT_580;
    zF_426E1F18_diagnosticCollector(zT_575, zT_576, zT_577);
    (void)self;
    zT_581 = self->diag;
    zT_582 = di;
    zT_585 = tk;
    zT_586 = zF_CC479241_typeKindTgtStr(zT_585);
    zT_583 = zT_586;
    zF_426E1F18_diagnosticCollector(zT_581, zT_582, zT_583);
    (void)self;
    goto z_bb_74;
    z_bb_80:
    zT_561 = 0;
    zT_562 = (unsigned char)zT_561;
    level = zT_562;
    goto z_bb_81;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    decl_type = it;
    goto z_bb_83;
    z_bb_83:
    if ((int)(decl_type == (unsigned int)(1))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_593 = "VDIAG:void_var\n";
    zT_595 = 15;
    zT_594.ptr = zT_593;
    zT_594.len = zT_595;
    vdag_m = zT_594;
    zT_596 = vdag_m;
    zF_48AC7B3A_markerWrite(zT_596);
    zT_598 = "VFLOW:vdag\n";
    zT_600 = 11;
    zT_599.ptr = zT_598;
    zT_599.len = zT_600;
    vfvd_m = zT_599;
    zT_601 = vfvd_m;
    zF_48AC7B3A_markerWrite(zT_601);
    zT_603 = node.span_start;
    vsp = zT_603;
    zT_605 = node.span_len;
    zT_607 = vsp + (unsigned int)((unsigned int)zT_605);
    vep = zT_607;
    zT_609 = "cannot declare variable of type void";
    zT_611 = 36;
    zT_610.ptr = zT_609;
    zT_610.len = zT_611;
    vv_msg = zT_610;
    zT_612 = self->diag;
    zT_615 = self->source_file_id;
    zT_616 = vsp;
    zT_617 = vep;
    zT_618 = vv_msg;
    zT_623 = zF_C82559AC_diagnosticCollector(zT_612, (unsigned char)(0), (unsigned short)(3000), zT_615, zT_616, zT_617, zT_618);
    (void)zT_623;
    goto z_bb_85;
    z_bb_85:
    zT_625 = self->coercion_table;
    zT_626 = node.child_1;
    zT_629 = zF_46B66789_coercionTableGet(zT_625, zT_626);
    ct_entry = zT_629;
    zT_630 = ct_entry.has_value;
    if ((int)(!zT_630)) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_632 = self->type_table;
    zT_633 = node.child_1;
    zT_634 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_632, zT_633, zT_634);
    goto z_bb_87;
    z_bb_87:
    goto z_bb_38;
    z_bb_88:
    zT_640 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_640);
    goto z_bb_89;
    z_bb_89:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_644 = self->store;
    zT_645 = node_idx;
    zT_647 = zF_8BA26B9E_astStoreNodePayload(zT_644, zT_645);
    zT_648 = self->local_decl_names;
    zT_649 = self->local_decl_count;
    zT_648[zT_649] = zT_647;
    zT_650 = self->local_decl_types;
    zT_651 = self->local_decl_count;
    zT_650[zT_651] = decl_type;
    zT_652 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_652 + (unsigned int)(1));
    zT_656 = self->module_id;
    zT_660 = self->store;
    zT_661 = node_idx;
    zT_663 = zF_8BA26B9E_astStoreNodePayload(zT_660, zT_661);
    zT_665 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_656) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_663);
    ck_1 = zT_665;
    zT_666 = self->registry;
    zT_667 = ck_1;
    zT_668 = decl_type;
    zF_5E95558D_nameCachePut(zT_666, zT_667, zT_668);
    zT_671 = "REG:cp";
    zT_673 = 6;
    zT_672.ptr = zT_671;
    zT_672.len = zT_673;
    regcp_m = zT_672;
    zT_674 = regcp_m;
    zT_676 = self->store;
    zT_677 = node_idx;
    zT_679 = zF_8BA26B9E_astStoreNodePayload(zT_676, zT_677);
    zT_675 = zT_679;
    zF_C914CB83_markerWriteInt(zT_674, zT_675);
    zT_681 = "REG:ct";
    zT_683 = 6;
    zT_682.ptr = zT_681;
    zT_682.len = zT_683;
    regct_m = zT_682;
    zT_684 = regct_m;
    zT_685 = decl_type;
    zF_C914CB83_markerWriteInt(zT_684, zT_685);
    goto z_bb_91;
    z_bb_91:
    goto z_bb_15;
    z_bb_92:
    zT_691 = self;
    zT_692 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_691, zT_692);
    zT_693 = node.child_2;
    if ((int)(zT_693 != (unsigned int)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_93:
    goto z_bb_15;
    z_bb_94:
    zT_705 = node.kind;
    if ((int)(zT_705 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_99; else goto z_bb_101;
    z_bb_95:
    zT_696 = self;
    zT_697 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_696, zT_697);
    goto z_bb_96;
    z_bb_96:
    zT_699 = node.child_1;
    if ((int)(zT_699 != (unsigned int)(0))) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_702 = self;
    zT_703 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_702, zT_703);
    goto z_bb_98;
    z_bb_98:
    goto z_bb_93;
    z_bb_99:
    zT_710 = self;
    zT_711 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_710, zT_711);
    zT_712 = node.child_1;
    if ((int)(zT_712 != (unsigned int)(0))) goto z_bb_102; else goto z_bb_103;
    z_bb_100:
    goto z_bb_93;
    z_bb_101:
    zT_718 = node.kind;
    if ((int)(zT_718 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_104; else goto z_bb_106;
    z_bb_102:
    zT_715 = self;
    zT_716 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_715, zT_716);
    goto z_bb_103;
    z_bb_103:
    goto z_bb_100;
    z_bb_104:
    zT_723 = self;
    zT_724 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_723, zT_724);
    zT_725 = node.child_1;
    if ((int)(zT_725 != (unsigned int)(0))) goto z_bb_107; else goto z_bb_108;
    z_bb_105:
    goto z_bb_100;
    z_bb_106:
    zT_731 = node.kind;
    if ((int)(zT_731 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_109; else goto z_bb_111;
    z_bb_107:
    zT_728 = self;
    zT_729 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_728, zT_729);
    goto z_bb_108;
    z_bb_108:
    goto z_bb_105;
    z_bb_109:
    zT_736 = self;
    zT_737 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_736, zT_737);
    goto z_bb_110;
    z_bb_110:
    goto z_bb_105;
    z_bb_111:
    zT_738 = node.kind;
    if ((int)(zT_738 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_113; else goto z_bb_112;
    z_bb_112:
    zT_744 = node.kind;
    zT_743 = zT_744 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_114;
    z_bb_113:
    zT_743 = 1;
    goto z_bb_114;
    z_bb_114:
    if (zT_743) goto z_bb_116; else goto z_bb_115;
    z_bb_115:
    zT_750 = node.kind;
    zT_749 = zT_750 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_117;
    z_bb_116:
    zT_749 = 1;
    goto z_bb_117;
    z_bb_117:
    if (zT_749) goto z_bb_119; else goto z_bb_118;
    z_bb_118:
    zT_756 = node.kind;
    zT_755 = zT_756 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_120;
    z_bb_119:
    zT_755 = 1;
    goto z_bb_120;
    z_bb_120:
    if (zT_755) goto z_bb_122; else goto z_bb_121;
    z_bb_121:
    zT_762 = node.kind;
    zT_761 = zT_762 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_123;
    z_bb_122:
    zT_761 = 1;
    goto z_bb_123;
    z_bb_123:
    if (zT_761) goto z_bb_125; else goto z_bb_124;
    z_bb_124:
    zT_768 = node.kind;
    zT_767 = zT_768 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_126;
    z_bb_125:
    zT_767 = 1;
    goto z_bb_126;
    z_bb_126:
    if (zT_767) goto z_bb_128; else goto z_bb_127;
    z_bb_127:
    zT_774 = node.kind;
    zT_773 = zT_774 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_129;
    z_bb_128:
    zT_773 = 1;
    goto z_bb_129;
    z_bb_129:
    if (zT_773) goto z_bb_131; else goto z_bb_130;
    z_bb_130:
    zT_780 = node.kind;
    zT_779 = zT_780 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_132;
    z_bb_131:
    zT_779 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_779) goto z_bb_134; else goto z_bb_133;
    z_bb_133:
    zT_786 = node.kind;
    zT_785 = zT_786 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_135;
    z_bb_134:
    zT_785 = 1;
    goto z_bb_135;
    z_bb_135:
    if (zT_785) goto z_bb_137; else goto z_bb_136;
    z_bb_136:
    zT_792 = node.kind;
    zT_791 = zT_792 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_138;
    z_bb_137:
    zT_791 = 1;
    goto z_bb_138;
    z_bb_138:
    if (zT_791) goto z_bb_140; else goto z_bb_139;
    z_bb_139:
    zT_798 = node.kind;
    zT_797 = zT_798 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_141;
    z_bb_140:
    zT_797 = 1;
    goto z_bb_141;
    z_bb_141:
    if (zT_797) goto z_bb_143; else goto z_bb_142;
    z_bb_142:
    zT_804 = node.kind;
    zT_803 = zT_804 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_144;
    z_bb_143:
    zT_803 = 1;
    goto z_bb_144;
    z_bb_144:
    if (zT_803) goto z_bb_146; else goto z_bb_145;
    z_bb_145:
    zT_810 = node.kind;
    zT_809 = zT_810 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_147;
    z_bb_146:
    zT_809 = 1;
    goto z_bb_147;
    z_bb_147:
    if (zT_809) goto z_bb_149; else goto z_bb_148;
    z_bb_148:
    zT_816 = node.kind;
    zT_815 = zT_816 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_150;
    z_bb_149:
    zT_815 = 1;
    goto z_bb_150;
    z_bb_150:
    if (zT_815) goto z_bb_152; else goto z_bb_151;
    z_bb_151:
    zT_822 = node.kind;
    zT_821 = zT_822 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_153;
    z_bb_152:
    zT_821 = 1;
    goto z_bb_153;
    z_bb_153:
    if (zT_821) goto z_bb_155; else goto z_bb_154;
    z_bb_154:
    zT_828 = node.kind;
    zT_827 = zT_828 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_156;
    z_bb_155:
    zT_827 = 1;
    goto z_bb_156;
    z_bb_156:
    if (zT_827) goto z_bb_158; else goto z_bb_157;
    z_bb_157:
    zT_834 = node.kind;
    zT_833 = zT_834 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_159;
    z_bb_158:
    zT_833 = 1;
    goto z_bb_159;
    z_bb_159:
    if (zT_833) goto z_bb_161; else goto z_bb_160;
    z_bb_160:
    zT_840 = node.kind;
    zT_839 = zT_840 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_162;
    z_bb_161:
    zT_839 = 1;
    goto z_bb_162;
    z_bb_162:
    if (zT_839) goto z_bb_163; else goto z_bb_165;
    z_bb_163:
    zT_845 = self;
    zT_846 = node_idx;
    zT_847 = zF_54F95822_semanticAnalyzerRes(zT_845, zT_846);
    (void)zT_847;
    goto z_bb_164;
    z_bb_164:
    goto z_bb_110;
    z_bb_165:
    zT_848 = node.kind;
    if ((int)(zT_848 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_166; else goto z_bb_168;
    z_bb_166:
    zT_853 = node.child_0;
    if ((int)(zT_853 != (unsigned int)(0))) goto z_bb_169; else goto z_bb_170;
    z_bb_167:
    goto z_bb_164;
    z_bb_168:
    zT_859 = node.kind;
    if ((int)(zT_859 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_172; else goto z_bb_171;
    z_bb_169:
    zT_856 = self;
    zT_857 = node.child_0;
    zF_7AB741D8_semanticAnalyzerStm(zT_856, zT_857);
    goto z_bb_170;
    z_bb_170:
    goto z_bb_167;
    z_bb_171:
    zT_865 = node.kind;
    zT_864 = zT_865 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_173;
    z_bb_172:
    zT_864 = 1;
    goto z_bb_173;
    z_bb_173:
    if (zT_864) goto z_bb_174; else goto z_bb_176;
    z_bb_174:
    zT_870 = node.child_0;
    if ((int)(zT_870 != (unsigned int)(0))) goto z_bb_177; else goto z_bb_178;
    z_bb_175:
    goto z_bb_167;
    z_bb_176:
    zT_876 = node.kind;
    if ((int)(zT_876 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_179; else goto z_bb_181;
    z_bb_177:
    zT_873 = self;
    zT_874 = node.child_0;
    zF_7AB741D8_semanticAnalyzerStm(zT_873, zT_874);
    goto z_bb_178;
    z_bb_178:
    goto z_bb_175;
    z_bb_179:
    goto z_bb_180;
    z_bb_180:
    goto z_bb_175;
    z_bb_181:
    zT_881 = node.kind;
    if ((int)(zT_881 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt))) goto z_bb_182; else goto z_bb_184;
    z_bb_182:
    goto z_bb_183;
    z_bb_183:
    goto z_bb_180;
    z_bb_184:
    zT_887 = "ELS:n";
    zT_889 = 5;
    zT_888.ptr = zT_887;
    zT_888.len = zT_889;
    els_nm = zT_888;
    zT_890 = els_nm;
    zT_891 = node_idx;
    zF_C914CB83_markerWriteInt(zT_890, zT_891);
    zT_893 = "ELS:k";
    zT_895 = 5;
    zT_894.ptr = zT_893;
    zT_894.len = zT_895;
    els_km = zT_894;
    zT_896 = els_km;
    zT_898 = node.kind;
    zF_C914CB83_markerWriteInt(zT_896, (unsigned int)((unsigned int)zT_898));
    zT_900 = node.child_0;
    if ((int)(zT_900 != (unsigned int)(0))) goto z_bb_185; else goto z_bb_186;
    z_bb_185:
    zT_904 = "ELS:c";
    zT_906 = 5;
    zT_905.ptr = zT_904;
    zT_905.len = zT_906;
    els_c0m = zT_905;
    zT_907 = els_c0m;
    zT_908 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_907, zT_908);
    goto z_bb_186;
    z_bb_186:
    zT_910 = self;
    zT_911 = node_idx;
    zT_912 = zF_54F95822_semanticAnalyzerRes(zT_910, zT_911);
    (void)zT_912;
    goto z_bb_183;
    z_bb_187:
    zT_917 = self->store;
    zT_918 = node.child_0;
    zT_921 = zF_FCDD1D35_astStoreNodeAt(zT_917, zT_918);
    nc = zT_921;
    zT_922 = nc.kind;
    if ((int)(zT_922 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_189; else goto z_bb_190;
    z_bb_188:
    zT_927 = node.child_1;
    if ((int)(zT_927 != (unsigned int)(0))) goto z_bb_191; else goto z_bb_192;
    z_bb_189:
    goto z_bb_4;
    z_bb_190:
    goto z_bb_188;
    z_bb_191:
    zT_931 = self->store;
    zT_932 = node.child_1;
    zT_935 = zF_FCDD1D35_astStoreNodeAt(zT_931, zT_932);
    nc = zT_935;
    zT_936 = nc.kind;
    if ((int)(zT_936 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_193; else goto z_bb_194;
    z_bb_192:
    goto z_bb_4;
    z_bb_193:
    goto z_bb_4;
    z_bb_194:
    goto z_bb_192;
}

/* semaTraceStep */
unsigned int zF_DE5079F2_semaTraceStep(zT_38C12417_SemanticAnalyzer* self, unsigned int* cur_name, unsigned char* done) {
    zT_3D7259E2_SymbolRegistry* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_E282FB55_Opt_808 zT_10 = {0};
    unsigned char zT_11;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    zT_8143F551_AstKind zT_24;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_49;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    zT_22A7C88B_AstNode zT_59 = {0};
    zT_8143F551_AstKind zT_60;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_72 = 0;
    zT_E282FB55_Opt_808 ss;
    zT_3A105EF1_Symbol* s;
    zT_22A7C88B_AstNode dn;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode c0;
    unsigned int nn;
    zT_4 = self->symbols;
    zT_5 = self->module_id;
    zT_6 = *cur_name;
    zT_10 = zF_A398987E_symbolRegistryQuali(zT_4, zT_5, zT_6);
    ss = zT_10;
    zT_11 = ss.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s = ss.value;
    zT_13 = s->decl_node;
    if ((int)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_3:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_4:
    zT_19 = self->store;
    zT_20 = s->decl_node;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    dn = zT_23;
    zT_24 = dn.kind;
    if ((int)(zT_24 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_6:
    zT_31 = dn.child_1;
    if ((int)(zT_31 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_8:
    zT_37 = self->store;
    zT_38 = dn.child_1;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_37, zT_38);
    init = zT_41;
    zT_42 = init.kind;
    if ((int)(zT_42 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_10:
    zT_49 = init.child_0;
    if ((int)(zT_49 == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_12:
    zT_55 = self->store;
    zT_56 = init.child_0;
    zT_59 = zF_FCDD1D35_astStoreNodeAt(zT_55, zT_56);
    c0 = zT_59;
    zT_60 = c0.kind;
    if ((int)(zT_60 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_14:
    zT_68 = self->store;
    zT_69 = init.child_0;
    zT_72 = zF_53458827_astStoreIdentifier(zT_68, zT_69);
    nn = zT_72;
    *cur_name = nn;
    return nn;
}

/* semanticAnalyzerResolveIndexAccess */
unsigned int zF_1926BC05_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    unsigned int zT_14;
    zT_38C12417_SemanticAnalyzer* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    zT_38C12417_SemanticAnalyzer* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_28 = {0};
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8143F551_AstKind zT_35;
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_47 = 0;
    char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned char zT_60;
    int zT_63;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int* zT_67;
    unsigned char* zT_68;
    unsigned int zT_71 = 0;
    unsigned int zT_73;
    char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8EED1867_ResolvedTypeTable* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    unsigned int zT_100;
    int zT_103;
    unsigned int zT_104;
    zT_8EED1867_ResolvedTypeTable* zT_107;
    unsigned int zT_108;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_D155D06D_Type* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_D155D06D_Type zT_118;
    zT_338B7C76_TypeRegistry* zT_120;
    unsigned int zT_121;
    unsigned int zT_124 = 0;
    char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    zT_33EF6BFB_TypeKind zT_133;
    zT_338B7C76_TypeRegistry* zT_139;
    zT_666DC2E1_TuplePayload* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_666DC2E1_TuplePayload zT_143;
    zT_338B7C76_TypeRegistry* zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixa_m;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_22A7C88B_AstNode c0_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u c0k_m;
    unsigned int c0_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ste_m;
    unsigned int src_cur_name;
    unsigned int src_depth;
    unsigned int src_name;
    unsigned char src_done;
    zT_8F083A69_Slice_zT_0B42B2F8_u ix_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_s;
    zT_D155D06D_Type bt;
    unsigned int ix_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixr_m;
    unsigned int ret;
    zT_666DC2E1_TuplePayload tp;
    unsigned int r4;
    zT_3 = "IXA:N";
    zT_5 = 5;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ixa_m = zT_4;
    zT_6 = ixa_m;
    zT_7 = node_idx;
    zF_C914CB83_markerWriteInt(zT_6, zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = self->_stub_0;
    saved = zT_14;
    zT_15 = self;
    zT_16 = node.child_1;
    zT_18 = zF_54F95822_semanticAnalyzerRes(zT_15, zT_16);
    (void)zT_18;
    zT_19 = self;
    zT_20 = node.child_0;
    zT_22 = zF_54F95822_semanticAnalyzerRes(zT_19, zT_20);
    self->_stub_0 = zT_22;
    zT_24 = self->store;
    zT_25 = node.child_0;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    c0_node = zT_28;
    zT_30 = "C0K:K";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    c0k_m = zT_31;
    zT_33 = c0k_m;
    zT_35 = c0_node.kind;
    zF_C914CB83_markerWriteInt(zT_33, (unsigned int)((unsigned int)zT_35));
    zT_37 = c0_node.kind;
    if ((int)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_43 = self->store;
    zT_44 = node.child_0;
    zT_47 = zF_53458827_astStoreIdentifier(zT_43, zT_44);
    c0_name_id = zT_47;
    zT_49 = "STE:N";
    zT_51 = 5;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    ste_m = zT_50;
    zT_52 = ste_m;
    zT_53 = node_idx;
    zF_C914CB83_markerWriteInt(zT_52, zT_53);
    src_cur_name = c0_name_id;
    zT_56 = 0;
    src_depth = zT_56;
    zT_58 = 0;
    src_name = zT_58;
    zT_60 = 0;
    src_done = zT_60;
    goto z_bb_3;
    z_bb_2:
    zT_94 = "IX:T";
    zT_96 = 4;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    ix_m = zT_95;
    zT_97 = ix_m;
    zT_98 = self->_stub_0;
    zF_C914CB83_markerWriteInt(zT_97, zT_98);
    zT_100 = self->_stub_0;
    if ((int)(zT_100 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_12;
    z_bb_3:
    if ((int)(src_done == (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_66 = self;
    zT_67 = &src_cur_name;
    zT_68 = &src_done;
    zT_71 = zF_DE5079F2_semaTraceStep(zT_66, zT_67, zT_68);
    src_name = zT_71;
    goto z_bb_6;
    z_bb_5:
    if ((int)(src_name != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_6:
    zT_73 = src_depth + (unsigned int)(1);
    src_depth = zT_73;
    goto z_bb_3;
    z_bb_7:
    zT_63 = src_depth < (unsigned int)(3);
    goto z_bb_9;
    z_bb_8:
    zT_63 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_63) goto z_bb_4; else goto z_bb_5;
    z_bb_10:
    zT_77 = "SRC:N";
    zT_79 = 5;
    zT_78.ptr = zT_77;
    zT_78.len = zT_79;
    srs_n = zT_78;
    zT_80 = srs_n;
    zT_81 = node_idx;
    zF_C914CB83_markerWriteInt(zT_80, zT_81);
    zT_83 = "SRC:S";
    zT_85 = 5;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    srs_s = zT_84;
    zT_86 = srs_s;
    zT_87 = src_name;
    zF_C914CB83_markerWriteInt(zT_86, zT_87);
    zT_88 = self->type_table;
    zT_89 = node.child_0;
    zT_90 = src_name;
    zF_D976B454_resolvedSourceTable(zT_88, zT_89, zT_90);
    (void)self;
    goto z_bb_11;
    z_bb_11:
    goto z_bb_2;
    z_bb_12:
    zT_104 = self->_stub_0;
    zT_103 = zT_104 == (unsigned int)(1);
    goto z_bb_14;
    z_bb_13:
    zT_103 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_103) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    self->_stub_0 = saved;
    zT_107 = self->type_table;
    zT_108 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_107, zT_108, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_16:
    zT_114 = self->registry;
    zT_115 = zT_114->types_items;
    zT_116 = self->_stub_0;
    zT_117 = (unsigned int)zT_116;
    zT_118 = zT_115[zT_117];
    bt = zT_118;
    zT_120 = self->registry;
    zT_121 = self->_stub_0;
    zT_124 = zF_E02A7BC0_typeRegistryIndexed(zT_120, zT_121);
    ix_elem = zT_124;
    if ((int)(ix_elem != (unsigned int)(18))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_128 = "IX:R";
    zT_130 = 4;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    ixr_m = zT_129;
    zT_131 = ixr_m;
    zT_132 = ix_elem;
    zF_C914CB83_markerWriteInt(zT_131, zT_132);
    self->_stub_0 = saved;
    return ix_elem;
    z_bb_18:
    zT_157 = self->_stub_0;
    ret = zT_157;
    self->_stub_0 = saved;
    return ret;
    z_bb_19:
    zT_133 = bt.kind;
    if ((int)(zT_133 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_139 = self->registry;
    zT_140 = zT_139->tup_items;
    zT_141 = bt.payload_idx;
    zT_142 = (unsigned int)zT_141;
    zT_143 = zT_140[zT_142];
    tp = zT_143;
    zT_145 = self->registry;
    zT_146 = zT_145->xt_items;
    zT_147 = tp.elems_start;
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_146[zT_148];
    r4 = zT_149;
    zT_151 = "IX:R";
    zT_153 = 4;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    ixr_m = zT_152;
    zT_154 = ixr_m;
    zT_155 = r4;
    zF_C914CB83_markerWriteInt(zT_154, zT_155);
    self->_stub_0 = saved;
    return r4;
    z_bb_21:
    goto z_bb_18;
}

/* semanticAnalyzerResolveSliceExpr */
unsigned int zF_F902E73E_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    unsigned int zT_13;
    zT_38C12417_SemanticAnalyzer* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    unsigned int zT_20;
    zT_38C12417_SemanticAnalyzer* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    int zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_D155D06D_Type zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    int zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    int zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    int zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_80 = 0;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_88 = 0;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_97;
    zT_33EF6BFB_TypeKind zT_98;
    int zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    int zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    int zT_115;
    zT_33EF6BFB_TypeKind zT_116;
    unsigned char zT_121;
    int zT_126;
    zT_338B7C76_TypeRegistry* zT_128;
    unsigned int zT_129;
    int zT_130;
    unsigned int zT_133 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_D155D06D_Type bt;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl_msg;
    unsigned int ix_elem2;
    int se_is_const;
    unsigned int ret;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    self->_stub_0 = zT_12;
    zT_13 = node.child_1;
    if ((int)(zT_13 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self;
    zT_17 = node.child_1;
    zT_19 = zF_54F95822_semanticAnalyzerRes(zT_16, zT_17);
    (void)zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_20 = node.child_2;
    if ((int)(zT_20 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_23 = self;
    zT_24 = node.child_2;
    zT_26 = zF_54F95822_semanticAnalyzerRes(zT_23, zT_24);
    (void)zT_26;
    goto z_bb_4;
    z_bb_4:
    zT_27 = self->_stub_0;
    if ((int)(zT_27 == (unsigned int)(0))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_31 = self->_stub_0;
    zT_30 = zT_31 == (unsigned int)(1);
    goto z_bb_7;
    z_bb_6:
    zT_30 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_9:
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_38 = self->_stub_0;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    bt = zT_40;
    zT_41 = bt.kind;
    if ((int)(zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_47 = bt.kind;
    zT_46 = zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_12;
    z_bb_11:
    zT_46 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_46) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_53 = bt.kind;
    zT_52 = zT_53 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_15;
    z_bb_14:
    zT_52 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_52) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_59 = bt.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_18;
    z_bb_17:
    zT_58 = 1;
    goto z_bb_18;
    z_bb_18:
    if ((int)(!zT_58)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_66 = "cannot slice base type: expected array, slice, or many-pointer";
    zT_68 = 62;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    sl_msg = zT_67;
    zT_69 = self->diag;
    zT_72 = self->source_file_id;
    zT_73 = node_idx;
    zT_74 = node_idx;
    zT_75 = sl_msg;
    zT_80 = zF_C82559AC_diagnosticCollector(zT_69, (unsigned char)(0), (unsigned short)(2000), zT_72, zT_73, zT_74, zT_75);
    (void)zT_80;
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_20:
    self->_stub_1 = (unsigned int)(1);
    zT_84 = self->registry;
    zT_85 = self->_stub_0;
    zT_88 = zF_E02A7BC0_typeRegistryIndexed(zT_84, zT_85);
    ix_elem2 = zT_88;
    if ((int)(ix_elem2 != (unsigned int)(18))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    self->_stub_1 = ix_elem2;
    goto z_bb_22;
    z_bb_22:
    zT_92 = self->_stub_1;
    if ((int)(zT_92 == (unsigned int)(1))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_91 = self->_stub_0;
    self->_stub_1 = zT_91;
    goto z_bb_22;
    z_bb_24:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_25:
    zT_97 = 0;
    se_is_const = zT_97;
    zT_98 = bt.kind;
    if ((int)(zT_98 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_104 = bt.kind;
    zT_103 = zT_104 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_28;
    z_bb_27:
    zT_103 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_103) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_110 = bt.kind;
    zT_109 = zT_110 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_31;
    z_bb_30:
    zT_109 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_109) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_116 = bt.kind;
    zT_115 = zT_116 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_34;
    z_bb_33:
    zT_115 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_115) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_121 = bt.flags;
    if ((int)((unsigned char)(zT_121 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_128 = self->registry;
    zT_129 = self->_stub_1;
    zT_130 = se_is_const;
    zT_133 = zF_8FC81A87_typeRegistryGetOrCr(zT_128, zT_129, zT_130);
    ret = zT_133;
    self->_stub_0 = saved;
    return ret;
    z_bb_37:
    zT_126 = 1;
    se_is_const = zT_126;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_36;
}

/* semanticAnalyzerResolveTupleLiteral */
unsigned int zF_227D2404_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_13 = {0};
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned int* zT_31;
    unsigned int zT_33 = 0;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    unsigned int zT_43;
    zT_338B7C76_TypeRegistry* zT_44;
    unsigned int zT_45;
    unsigned short zT_46;
    unsigned int zT_49;
    unsigned int zT_51 = 0;
    unsigned int saved;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int start;
    unsigned int i;
    zT_3 = self->store;
    zT_4 = node_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_850FDF81_astStoreNodeExtraCh(zT_10, zT_11);
    ec = zT_13;
    zT_15 = ec.len;
    if ((int)(zT_15 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_2:
    zT_20 = self->registry;
    zT_21 = zT_20->xt_len;
    zT_22 = (unsigned int)zT_21;
    start = zT_22;
    zT_24 = 0;
    zT_25 = (unsigned int)zT_24;
    i = zT_25;
    goto z_bb_3;
    z_bb_3:
    zT_27 = ec.len;
    if ((int)(i < zT_27)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_29 = self;
    zT_31 = ec.ptr;
    zT_30 = zT_31[i];
    zT_33 = zF_54F95822_semanticAnalyzerRes(zT_29, zT_30);
    self->_stub_0 = zT_33;
    zT_34 = self->_stub_0;
    if ((int)(zT_34 == (unsigned int)(1))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    self->_stub_0 = saved;
    zT_44 = self->registry;
    zT_45 = start;
    zT_49 = ec.len;
    zT_46 = (unsigned short)zT_49;
    zT_51 = zF_9996320F_typeRegistryGetOrCr(zT_44, zT_45, zT_46);
    return zT_51;
    z_bb_6:
    zT_43 = i + (unsigned int)(1);
    i = zT_43;
    goto z_bb_3;
    z_bb_7:
    self->_stub_0 = (unsigned int)(6);
    goto z_bb_8;
    z_bb_8:
    zT_38 = self->registry;
    zT_39 = self->_stub_0;
    zF_4C03AE3D_xtAppend(zT_38, zT_39);
    goto z_bb_6;
}

/* semanticAnalyzerResolveArrayInit */
unsigned int zF_F3DAABE0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_8EED1867_ResolvedTypeTable* zT_16;
    unsigned int zT_17;
    zT_BAEE192E_Opt_10 zT_20 = {0};
    unsigned char zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_D155D06D_Type* zT_25;
    unsigned int zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_37 = {0};
    unsigned int zT_39;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    unsigned int* zT_58;
    zT_22A7C88B_AstNode zT_60 = {0};
    unsigned int zT_63;
    zT_8143F551_AstKind zT_64;
    unsigned int zT_69;
    zT_8143F551_AstKind zT_70;
    unsigned int zT_75;
    zT_38C12417_SemanticAnalyzer* zT_76;
    unsigned int zT_77;
    unsigned int* zT_78;
    unsigned int zT_80 = 0;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    unsigned int zT_97;
    unsigned int zT_99 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    unsigned int annot_tid;
    zT_BAEE192E_Opt_10 rt;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int t;
    zT_D155D06D_Type tt;
    unsigned int arr_elem_tid;
    unsigned int aei;
    zT_22A7C88B_AstNode el;
    unsigned int el_tid;
    unsigned int arr_tid;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_11 = 18;
    annot_tid = zT_11;
    zT_12 = node.child_0;
    if ((int)(zT_12 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self->type_table;
    zT_17 = node.child_0;
    zT_20 = zF_999DCF51_resolvedTypeTableGe(zT_16, zT_17);
    rt = zT_20;
    zT_21 = rt.has_value;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_34 = self->store;
    zT_35 = node_idx;
    zT_37 = zF_850FDF81_astStoreNodeExtraCh(zT_34, zT_35);
    ec = zT_37;
    zT_39 = ec.len;
    if ((int)(zT_39 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    t = rt.value;
    zT_24 = self->registry;
    zT_25 = zT_24->types_items;
    zT_26 = (unsigned int)t;
    zT_27 = zT_25[zT_26];
    tt = zT_27;
    zT_28 = tt.kind;
    if ((int)(zT_28 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    annot_tid = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    self->_stub_0 = saved;
    if ((int)(annot_tid != (unsigned int)(18))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_48 = 1;
    arr_elem_tid = zT_48;
    zT_50 = 0;
    aei = zT_50;
    goto z_bb_11;
    z_bb_9:
    return annot_tid;
    z_bb_10:
    return (unsigned int)(1);
    z_bb_11:
    zT_52 = ec.len;
    if ((int)(aei < zT_52)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_55 = self->store;
    zT_58 = ec.ptr;
    zT_56 = zT_58[aei];
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_55, zT_56);
    el = zT_60;
    zT_63 = 1;
    el_tid = zT_63;
    zT_64 = el.kind;
    if ((int)(zT_64 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_15; else goto z_bb_17;
    z_bb_13:
    if ((int)(annot_tid != (unsigned int)(18))) goto z_bb_25; else goto z_bb_26;
    z_bb_14:
    zT_87 = aei + (unsigned int)(1);
    aei = zT_87;
    goto z_bb_11;
    z_bb_15:
    zT_69 = 8;
    el_tid = zT_69;
    goto z_bb_16;
    z_bb_16:
    if ((int)(el_tid == (unsigned int)(1))) goto z_bb_21; else goto z_bb_22;
    z_bb_17:
    zT_70 = el.kind;
    if ((int)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_75 = 10;
    el_tid = zT_75;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_76 = self;
    zT_78 = ec.ptr;
    zT_77 = zT_78[aei];
    zT_80 = zF_54F95822_semanticAnalyzerRes(zT_76, zT_77);
    el_tid = zT_80;
    goto z_bb_19;
    z_bb_21:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_22:
    if ((int)(aei == (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    arr_elem_tid = el_tid;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_14;
    z_bb_25:
    self->_stub_0 = saved;
    return annot_tid;
    z_bb_26:
    zT_92 = self->registry;
    zT_93 = arr_elem_tid;
    zT_97 = ec.len;
    zT_99 = zF_BA693C74_typeRegistryGetOrCr(zT_92, zT_93, (unsigned int)((unsigned int)zT_97));
    arr_tid = zT_99;
    self->_stub_0 = saved;
    return arr_tid;
}

/* semanticAnalyzerResolveStmt */
void zF_979B6CFF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_38C12417_SemanticAnalyzer* zT_2;
    unsigned int zT_3;
    zT_2 = self;
    zT_3 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_2, zT_3);
    return;
}

/* semanticAnalyzerResolveModuleVarDecl */
unsigned int zF_CC4377FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_38C12417_SemanticAnalyzer* zT_33;
    int zT_37;
    zT_338B7C76_TypeRegistry* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_38C12417_SemanticAnalyzer* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    unsigned int zT_49 = 0;
    zT_0FB7FB13_CoercionKind zT_50 = 0;
    zT_66E7D2EF_CoercionTable* zT_55;
    unsigned int zT_56;
    zT_0FB7FB13_CoercionKind zT_57;
    unsigned int zT_58;
    zT_22A7C88B_AstNode decl;
    unsigned int decl_type;
    zT_BAEE192E_Opt_10 rt;
    unsigned int it;
    unsigned int t;
    zT_0FB7FB13_CoercionKind ck;
    zT_3 = self->store;
    zT_4 = decl_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    decl = zT_6;
    zT_7 = decl.child_1;
    if ((int)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_14 = 18;
    decl_type = zT_14;
    zT_15 = decl.child_0;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = self->type_table;
    zT_20 = decl.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_26 = self;
    zT_27 = decl_type;
    zF_9665A229_pushExpectedType(zT_26, zT_27);
    zT_29 = self;
    zT_30 = decl.child_1;
    zT_32 = zF_54F95822_semanticAnalyzerRes(zT_29, zT_30);
    it = zT_32;
    zT_33 = self;
    zF_BC478E78_popExpectedType(zT_33);
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    t = rt.value;
    decl_type = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_37 = it != decl_type;
    goto z_bb_9;
    z_bb_8:
    zT_37 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_37) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_40 = self->registry;
    zT_44 = self;
    zT_45 = decl.child_1;
    zT_46 = decl_type;
    zT_47 = it;
    zT_49 = zF_FFC95E09_errLitSrcType(zT_44, zT_45, zT_46, zT_47);
    zT_41 = zT_49;
    zT_42 = decl_type;
    zT_50 = zF_713658BF_classifyCoercion(zT_40, zT_41, zT_42);
    ck = zT_50;
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return it;
    z_bb_12:
    zT_55 = self->coercion_table;
    zT_56 = decl.child_1;
    zT_57 = ck;
    zT_58 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_55, zT_56, zT_57, zT_58);
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
}

/* EOF */
