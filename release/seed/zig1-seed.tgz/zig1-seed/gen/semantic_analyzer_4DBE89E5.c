#include "semantic_analyzer_4DBE89E5.h"
/* semanticAnalyzerInit */
zT_38C12417_SemanticAnalyzer zF_84ADA681_semanticAnalyzerIni(zT_3E40CD83_Sand* alloc, zT_8EED1867_ResolvedTypeTable* type_table, zT_F85C5DED_DiagnosticCollector* diag, zT_338B7C76_TypeRegistry* registry, zT_3D7259E2_SymbolRegistry* symbols, zT_6B0A7D14_AstStore* store, unsigned int module_id, unsigned int source_file_id, zT_66E7D2EF_CoercionTable* coercion_tab, zT_21D3708C_U32ToU32Map* enum_val_tab, zT_21D3708C_U32ToU32Map* error_code_reg, zT_D3EB6303_StringInterner* interner, zT_21D3708C_U32ToU32Map* cal_typs, zT_21D3708C_U32ToU32Map* cp_map, zT_072B53A6_ModuleRegistry* module_reg, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_D3EB6303_StringInterner* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23 = 0;
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31 = 0;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39 = 0;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_D3EB6303_StringInterner* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_D3EB6303_StringInterner* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63 = 0;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71 = 0;
    unsigned char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_D3EB6303_StringInterner* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79 = 0;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_D3EB6303_StringInterner* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_D3EB6303_StringInterner* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95 = 0;
    unsigned char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_D3EB6303_StringInterner* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103 = 0;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_D3EB6303_StringInterner* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111 = 0;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_D3EB6303_StringInterner* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119 = 0;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_D3EB6303_StringInterner* zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_127 = 0;
    unsigned char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_D3EB6303_StringInterner* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135 = 0;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_D3EB6303_StringInterner* zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_142;
    unsigned int zT_143 = 0;
    unsigned char* zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    zT_D3EB6303_StringInterner* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151 = 0;
    unsigned char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_D3EB6303_StringInterner* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159 = 0;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_D3EB6303_StringInterner* zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167 = 0;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_D3EB6303_StringInterner* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175 = 0;
    unsigned char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_D3EB6303_StringInterner* zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183 = 0;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_D3EB6303_StringInterner* zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    unsigned int zT_191 = 0;
    unsigned char* zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    zT_D3EB6303_StringInterner* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199 = 0;
    unsigned char* zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_203;
    zT_D3EB6303_StringInterner* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207 = 0;
    unsigned char* zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    zT_D3EB6303_StringInterner* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215 = 0;
    unsigned char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_D3EB6303_StringInterner* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned int zT_223 = 0;
    unsigned char* zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_D3EB6303_StringInterner* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    unsigned int zT_231 = 0;
    unsigned char* zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    zT_D3EB6303_StringInterner* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239 = 0;
    unsigned char* zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243;
    zT_D3EB6303_StringInterner* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247 = 0;
    unsigned char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_D3EB6303_StringInterner* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255 = 0;
    unsigned char* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_259;
    zT_D3EB6303_StringInterner* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263 = 0;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_D3EB6303_StringInterner* zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned int zT_271 = 0;
    unsigned char* zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_D3EB6303_StringInterner* zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned int zT_279 = 0;
    unsigned char* zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    zT_D3EB6303_StringInterner* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287 = 0;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_D3EB6303_StringInterner* zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned int zT_295 = 0;
    zT_38C12417_SemanticAnalyzer zT_296;
    int zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    int zT_308;
    int zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    zT_3E40CD83_Sand* zT_312;
    zT_E2DF2801_LocalConstScope zT_313 = {0};
    int zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    int zT_317;
    int zT_318;
    unsigned int zT_319;
    unsigned int zT_320;
    int zT_321;
    unsigned int zT_322;
    unsigned int zT_323;
    unsigned int zT_324;
    int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_text;
    unsigned int und_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_text;
    unsigned int pc_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pti_s;
    unsigned int ptin_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u itp_s;
    unsigned int itp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifp_s;
    unsigned int ifp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_s;
    unsigned int pfi_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpp_s;
    unsigned int fpp_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u vc_s;
    unsigned int vc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_s;
    unsigned int bc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_s;
    unsigned int ic_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_s;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u if_s;
    unsigned int if_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ie_s;
    unsigned int ie_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u e2i_s;
    unsigned int e2i_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u as_s;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u so_s;
    unsigned int so_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ao_s;
    unsigned int ao_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u oo_s;
    unsigned int oo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u bso_s;
    unsigned int bso_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u boo_s;
    unsigned int boo_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc2_s;
    unsigned int pc2_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sow_s;
    unsigned int sow_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sew_s;
    unsigned int sew_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u gc_s;
    unsigned int gc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ex_s;
    unsigned int ex_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pn_s;
    unsigned int pn_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm_s;
    unsigned int sm_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u iw_s;
    unsigned int iw_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_s;
    unsigned int cc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u cg_s;
    unsigned int cg_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u csc_s;
    unsigned int csc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u afs_s;
    unsigned int afs_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ain_s;
    unsigned int ain_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ars_s;
    unsigned int ars_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u asu_s;
    unsigned int asu_id;
    zT_17 = "_";
    zT_19 = 1;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    und_text = zT_18;
    zT_21 = interner;
    zT_22 = und_text;
    zT_23 = zF_50C274AF_stringInternerInter(zT_21, zT_22);
    und_name_id = zT_23;
    zT_25 = "@ptrCast";
    zT_27 = 8;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    pc_text = zT_26;
    zT_29 = interner;
    zT_30 = pc_text;
    zT_31 = zF_50C274AF_stringInternerInter(zT_29, zT_30);
    pc_name_id = zT_31;
    zT_33 = "@ptrToInt";
    zT_35 = 9;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    pti_s = zT_34;
    zT_37 = interner;
    zT_38 = pti_s;
    zT_39 = zF_50C274AF_stringInternerInter(zT_37, zT_38);
    ptin_id = zT_39;
    zT_41 = "@intToPtr";
    zT_43 = 9;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    itp_s = zT_42;
    zT_45 = interner;
    zT_46 = itp_s;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    itp_id = zT_47;
    zT_49 = "@intFromPtr";
    zT_51 = 11;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    ifp_s = zT_50;
    zT_53 = interner;
    zT_54 = ifp_s;
    zT_55 = zF_50C274AF_stringInternerInter(zT_53, zT_54);
    ifp_id = zT_55;
    zT_57 = "@ptrFromInt";
    zT_59 = 11;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    pfi_s = zT_58;
    zT_61 = interner;
    zT_62 = pfi_s;
    zT_63 = zF_50C274AF_stringInternerInter(zT_61, zT_62);
    pfi_id = zT_63;
    zT_65 = "@fieldParentPtr";
    zT_67 = 15;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    fpp_s = zT_66;
    zT_69 = interner;
    zT_70 = fpp_s;
    zT_71 = zF_50C274AF_stringInternerInter(zT_69, zT_70);
    fpp_id = zT_71;
    zT_73 = "@volatileCast";
    zT_75 = 13;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    vc_s = zT_74;
    zT_77 = interner;
    zT_78 = vc_s;
    zT_79 = zF_50C274AF_stringInternerInter(zT_77, zT_78);
    vc_id = zT_79;
    zT_81 = "@bitCast";
    zT_83 = 8;
    zT_82.ptr = zT_81;
    zT_82.len = zT_83;
    bc_s = zT_82;
    zT_85 = interner;
    zT_86 = bc_s;
    zT_87 = zF_50C274AF_stringInternerInter(zT_85, zT_86);
    bc_id = zT_87;
    zT_89 = "@intCast";
    zT_91 = 8;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    ic_s = zT_90;
    zT_93 = interner;
    zT_94 = ic_s;
    zT_95 = zF_50C274AF_stringInternerInter(zT_93, zT_94);
    ic_id = zT_95;
    zT_97 = "@floatCast";
    zT_99 = 10;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    fc_s = zT_98;
    zT_101 = interner;
    zT_102 = fc_s;
    zT_103 = zF_50C274AF_stringInternerInter(zT_101, zT_102);
    fc_id = zT_103;
    zT_105 = "@intToFloat";
    zT_107 = 11;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    if_s = zT_106;
    zT_109 = interner;
    zT_110 = if_s;
    zT_111 = zF_50C274AF_stringInternerInter(zT_109, zT_110);
    if_id = zT_111;
    zT_113 = "@intToEnum";
    zT_115 = 10;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    ie_s = zT_114;
    zT_117 = interner;
    zT_118 = ie_s;
    zT_119 = zF_50C274AF_stringInternerInter(zT_117, zT_118);
    ie_id = zT_119;
    zT_121 = "@enumToInt";
    zT_123 = 10;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    e2i_s = zT_122;
    zT_125 = interner;
    zT_126 = e2i_s;
    zT_127 = zF_50C274AF_stringInternerInter(zT_125, zT_126);
    e2i_id = zT_127;
    zT_129 = "@as";
    zT_131 = 3;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    as_s = zT_130;
    zT_133 = interner;
    zT_134 = as_s;
    zT_135 = zF_50C274AF_stringInternerInter(zT_133, zT_134);
    as_id = zT_135;
    zT_137 = "@sizeOf";
    zT_139 = 7;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    so_s = zT_138;
    zT_141 = interner;
    zT_142 = so_s;
    zT_143 = zF_50C274AF_stringInternerInter(zT_141, zT_142);
    so_id = zT_143;
    zT_145 = "@alignOf";
    zT_147 = 8;
    zT_146.ptr = zT_145;
    zT_146.len = zT_147;
    ao_s = zT_146;
    zT_149 = interner;
    zT_150 = ao_s;
    zT_151 = zF_50C274AF_stringInternerInter(zT_149, zT_150);
    ao_id = zT_151;
    zT_153 = "@offsetOf";
    zT_155 = 9;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    oo_s = zT_154;
    zT_157 = interner;
    zT_158 = oo_s;
    zT_159 = zF_50C274AF_stringInternerInter(zT_157, zT_158);
    oo_id = zT_159;
    zT_161 = "@bitSizeOf";
    zT_163 = 10;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    bso_s = zT_162;
    zT_165 = interner;
    zT_166 = bso_s;
    zT_167 = zF_50C274AF_stringInternerInter(zT_165, zT_166);
    bso_id = zT_167;
    zT_169 = "@bitOffsetOf";
    zT_171 = 12;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    boo_s = zT_170;
    zT_173 = interner;
    zT_174 = boo_s;
    zT_175 = zF_50C274AF_stringInternerInter(zT_173, zT_174);
    boo_id = zT_175;
    zT_177 = "@putChar";
    zT_179 = 8;
    zT_178.ptr = zT_177;
    zT_178.len = zT_179;
    pc2_s = zT_178;
    zT_181 = interner;
    zT_182 = pc2_s;
    zT_183 = zF_50C274AF_stringInternerInter(zT_181, zT_182);
    pc2_id = zT_183;
    zT_185 = "@stdoutWrite";
    zT_187 = 12;
    zT_186.ptr = zT_185;
    zT_186.len = zT_187;
    sow_s = zT_186;
    zT_189 = interner;
    zT_190 = sow_s;
    zT_191 = zF_50C274AF_stringInternerInter(zT_189, zT_190);
    sow_id = zT_191;
    zT_193 = "@stderrWrite";
    zT_195 = 12;
    zT_194.ptr = zT_193;
    zT_194.len = zT_195;
    sew_s = zT_194;
    zT_197 = interner;
    zT_198 = sew_s;
    zT_199 = zF_50C274AF_stringInternerInter(zT_197, zT_198);
    sew_id = zT_199;
    zT_201 = "@getChar";
    zT_203 = 8;
    zT_202.ptr = zT_201;
    zT_202.len = zT_203;
    gc_s = zT_202;
    zT_205 = interner;
    zT_206 = gc_s;
    zT_207 = zF_50C274AF_stringInternerInter(zT_205, zT_206);
    gc_id = zT_207;
    zT_209 = "@exit";
    zT_211 = 5;
    zT_210.ptr = zT_209;
    zT_210.len = zT_211;
    ex_s = zT_210;
    zT_213 = interner;
    zT_214 = ex_s;
    zT_215 = zF_50C274AF_stringInternerInter(zT_213, zT_214);
    ex_id = zT_215;
    zT_217 = "@panic";
    zT_219 = 6;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    pn_s = zT_218;
    zT_221 = interner;
    zT_222 = pn_s;
    zT_223 = zF_50C274AF_stringInternerInter(zT_221, zT_222);
    pn_id = zT_223;
    zT_225 = "@sleepMs";
    zT_227 = 8;
    zT_226.ptr = zT_225;
    zT_226.len = zT_227;
    sm_s = zT_226;
    zT_229 = interner;
    zT_230 = sm_s;
    zT_231 = zF_50C274AF_stringInternerInter(zT_229, zT_230);
    sm_id = zT_231;
    zT_233 = "@isWindows";
    zT_235 = 10;
    zT_234.ptr = zT_233;
    zT_234.len = zT_235;
    iw_s = zT_234;
    zT_237 = interner;
    zT_238 = iw_s;
    zT_239 = zF_50C274AF_stringInternerInter(zT_237, zT_238);
    iw_id = zT_239;
    zT_241 = "@consoleClear";
    zT_243 = 13;
    zT_242.ptr = zT_241;
    zT_242.len = zT_243;
    cc_s = zT_242;
    zT_245 = interner;
    zT_246 = cc_s;
    zT_247 = zF_50C274AF_stringInternerInter(zT_245, zT_246);
    cc_id = zT_247;
    zT_249 = "@consoleGotoxy";
    zT_251 = 14;
    zT_250.ptr = zT_249;
    zT_250.len = zT_251;
    cg_s = zT_250;
    zT_253 = interner;
    zT_254 = cg_s;
    zT_255 = zF_50C274AF_stringInternerInter(zT_253, zT_254);
    cg_id = zT_255;
    zT_257 = "@consoleSetColor";
    zT_259 = 16;
    zT_258.ptr = zT_257;
    zT_258.len = zT_259;
    csc_s = zT_258;
    zT_261 = interner;
    zT_262 = csc_s;
    zT_263 = zF_50C274AF_stringInternerInter(zT_261, zT_262);
    csc_id = zT_263;
    zT_265 = "@asyncFrameSize";
    zT_267 = 15;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    afs_s = zT_266;
    zT_269 = interner;
    zT_270 = afs_s;
    zT_271 = zF_50C274AF_stringInternerInter(zT_269, zT_270);
    afs_id = zT_271;
    zT_273 = "@asyncInit";
    zT_275 = 10;
    zT_274.ptr = zT_273;
    zT_274.len = zT_275;
    ain_s = zT_274;
    zT_277 = interner;
    zT_278 = ain_s;
    zT_279 = zF_50C274AF_stringInternerInter(zT_277, zT_278);
    ain_id = zT_279;
    zT_281 = "@asyncResume";
    zT_283 = 12;
    zT_282.ptr = zT_281;
    zT_282.len = zT_283;
    ars_s = zT_282;
    zT_285 = interner;
    zT_286 = ars_s;
    zT_287 = zF_50C274AF_stringInternerInter(zT_285, zT_286);
    ars_id = zT_287;
    zT_289 = "@asyncSuspend";
    zT_291 = 13;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    asu_s = zT_290;
    zT_293 = interner;
    zT_294 = asu_s;
    zT_295 = zF_50C274AF_stringInternerInter(zT_293, zT_294);
    asu_id = zT_295;
    zT_296.type_table = type_table;
    zT_296.diag = diag;
    zT_296.registry = registry;
    zT_296.symbols = symbols;
    zT_296.store = store;
    zT_296.module_id = module_id;
    zT_296.source_file_id = source_file_id;
    zT_297 = 0;
    zT_296.expected_type_stack_items = (unsigned int*)zT_297;
    zT_298 = 0;
    zT_296.expected_type_stack_len = zT_298;
    zT_299 = 0;
    zT_296.expected_type_stack_cap = zT_299;
    zT_296.expected_type_stack_alloc = alloc;
    zT_300 = 0;
    zT_296.stmt_work_items = (unsigned int*)zT_300;
    zT_301 = 0;
    zT_296.stmt_work_len = zT_301;
    zT_302 = 0;
    zT_296.stmt_work_cap = zT_302;
    zT_303 = 0;
    zT_296.current_fn_return = zT_303;
    zT_304 = 0;
    zT_296.current_fn_name = zT_304;
    zT_296.coercion_table = coercion_tab;
    zT_296.enum_value_table = enum_val_tab;
    zT_296.error_code_registry = error_code_reg;
    zT_305 = 0;
    zT_296.current_switch_cond_tu = zT_305;
    zT_306 = 0;
    zT_296.switch_depth = zT_306;
    zT_307 = 0;
    zT_296.defer_depth = zT_307;
    zT_308 = 0;
    zT_296.local_decl_names = (unsigned int*)zT_308;
    zT_309 = 0;
    zT_296.local_decl_types = (unsigned int*)zT_309;
    zT_310 = 0;
    zT_296.local_decl_count = zT_310;
    zT_311 = 0;
    zT_296.local_decl_cap = zT_311;
    zT_312 = alloc;
    zT_313 = zF_F5EBC2FF_localConstScopeInit(zT_312);
    zT_296.local_consts = zT_313;
    zT_314 = 0;
    zT_296.packed_gate_items = (unsigned int*)zT_314;
    zT_315 = 0;
    zT_296.packed_gate_len = zT_315;
    zT_316 = 0;
    zT_296.packed_gate_cap = zT_316;
    zT_317 = 0;
    zT_296.packed_struct_tids = (unsigned int*)zT_317;
    zT_318 = 0;
    zT_296.packed_struct_decl_nodes = (unsigned int*)zT_318;
    zT_319 = 0;
    zT_296.packed_struct_cache_len = zT_319;
    zT_320 = 0;
    zT_296.packed_struct_cache_cap = zT_320;
    zT_321 = 0;
    zT_296.checked_struct_tids = (unsigned int*)zT_321;
    zT_322 = 0;
    zT_296.checked_struct_tids_len = zT_322;
    zT_323 = 0;
    zT_296.checked_struct_tids_cap = zT_323;
    zT_296._stub_0 = und_name_id;
    zT_324 = 0;
    zT_296._stub_1 = zT_324;
    zT_296.call_arg_types = cal_typs;
    zT_296.call_param_map = cp_map;
    zT_296.interner = interner;
    zT_296.ptrcast_name_id = pc_name_id;
    zT_296.volatilecast_name_id = vc_id;
    zT_296.ptrtoint_name_id = ptin_id;
    zT_296.inttoptr_name_id = itp_id;
    zT_296.int_from_ptr_name_id = ifp_id;
    zT_296.ptr_from_int_name_id = pfi_id;
    zT_296.field_parent_ptr_name_id = fpp_id;
    zT_296.bitcast_name_id = bc_id;
    zT_296.intcast_name_id = ic_id;
    zT_296.floatcast_name_id = fc_id;
    zT_296.inttofloat_name_id = if_id;
    zT_296.inttoenum_name_id = ie_id;
    zT_296.enumtoint_name_id = e2i_id;
    zT_296.as_name_id = as_id;
    zT_296.size_of_name_id = so_id;
    zT_296.align_of_name_id = ao_id;
    zT_296.offset_of_name_id = oo_id;
    zT_296.bit_size_of_name_id = bso_id;
    zT_296.bit_offset_of_name_id = boo_id;
    zT_296.putchar_name_id = pc2_id;
    zT_296.stdout_write_name_id = sow_id;
    zT_296.stderr_write_name_id = sew_id;
    zT_296.getchar_name_id = gc_id;
    zT_296.exit_name_id = ex_id;
    zT_296.panic_name_id = pn_id;
    zT_296.sleep_ms_name_id = sm_id;
    zT_296.is_windows_name_id = iw_id;
    zT_296.console_clear_name_id = cc_id;
    zT_296.console_gotoxy_name_id = cg_id;
    zT_296.console_set_color_name_id = csc_id;
    zT_296.async_frame_size_name_id = afs_id;
    zT_296.async_init_name_id = ain_id;
    zT_296.async_resume_name_id = ars_id;
    zT_296.async_suspend_name_id = asu_id;
    zT_325 = 1;
    zT_296.async_analysis_ready = zT_325;
    zT_296.module_reg = module_reg;
    zT_296.suspending_fns = suspending_fns;
    return zT_296;
}

/* semanticAnalyzerIsTypeValueCast */
int zF_3757023F_semanticAnalyzerIsT(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    zT_2 = self->ptrcast_name_id;
    if ((int)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_5 = self->volatilecast_name_id;
    if ((int)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_8 = self->inttoptr_name_id;
    if ((int)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_11 = self->intcast_name_id;
    if ((int)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    zT_14 = self->floatcast_name_id;
    if ((int)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    zT_17 = self->inttofloat_name_id;
    if ((int)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_20 = self->inttoenum_name_id;
    if ((int)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    zT_23 = self->as_name_id;
    if ((int)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    return (int)(0);
}

/* semanticAnalyzerBuiltinNameEq */
int zF_2ACB4E23_semanticAnalyzerBui(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, zT_8F083A69_Slice_zT_0B42B2F8_u lit) {
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char* zT_20;
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned char zT_23;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    unsigned int ci;
    zT_4 = self->interner;
    zT_5 = name_id;
    zT_7 = zF_9134020D_stringInternerGet(zT_4, zT_5);
    nm = zT_7;
    zT_9 = nm.len;
    zT_11 = lit.len;
    if ((int)(zT_9 != zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    ci = zT_16;
    goto z_bb_3;
    z_bb_3:
    zT_18 = nm.len;
    if ((int)(ci < zT_18)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = nm.ptr;
    zT_21 = zT_20[ci];
    zT_22 = lit.ptr;
    zT_23 = zT_22[ci];
    if ((int)(zT_21 != zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_27 = ci + (unsigned int)(1);
    ci = zT_27;
    goto z_bb_3;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    goto z_bb_6;
}

/* semanticAnalyzerIsBuiltinSupported */
int zF_CAF1FD28_semanticAnalyzerIsB(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned int zT_38;
    unsigned int zT_41;
    unsigned int zT_44;
    unsigned int zT_47;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_59;
    unsigned int zT_62;
    unsigned int zT_65;
    unsigned int zT_68;
    unsigned int zT_71;
    unsigned int zT_74;
    unsigned int zT_77;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned int zT_86;
    unsigned int zT_89;
    unsigned int zT_92;
    unsigned int zT_95;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_38C12417_SemanticAnalyzer* zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    int zT_105 = 0;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_38C12417_SemanticAnalyzer* zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    int zT_114 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_38C12417_SemanticAnalyzer* zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    int zT_123 = 0;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_38C12417_SemanticAnalyzer* zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    int zT_132 = 0;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    int zT_141 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_e2i;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cvs;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cva;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_cve;
    zT_8F083A69_Slice_zT_0B42B2F8_u l_pan;
    zT_2 = self->ptrcast_name_id;
    if ((int)(name_id == zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_5 = self->volatilecast_name_id;
    if ((int)(name_id == zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_8 = self->ptrtoint_name_id;
    if ((int)(name_id == zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    zT_11 = self->inttoptr_name_id;
    if ((int)(name_id == zT_11)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    zT_14 = self->int_from_ptr_name_id;
    if ((int)(name_id == zT_14)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(1);
    z_bb_10:
    zT_17 = self->ptr_from_int_name_id;
    if ((int)(name_id == zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_20 = self->field_parent_ptr_name_id;
    if ((int)(name_id == zT_20)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    zT_23 = self->bitcast_name_id;
    if ((int)(name_id == zT_23)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    zT_26 = self->intcast_name_id;
    if ((int)(name_id == zT_26)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(1);
    z_bb_18:
    zT_29 = self->floatcast_name_id;
    if ((int)(name_id == zT_29)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    zT_32 = self->inttofloat_name_id;
    if ((int)(name_id == zT_32)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (int)(1);
    z_bb_22:
    zT_35 = self->inttoenum_name_id;
    if ((int)(name_id == zT_35)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(1);
    z_bb_24:
    zT_38 = self->as_name_id;
    if ((int)(name_id == zT_38)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(1);
    z_bb_26:
    zT_41 = self->size_of_name_id;
    if ((int)(name_id == zT_41)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(1);
    z_bb_28:
    zT_44 = self->align_of_name_id;
    if ((int)(name_id == zT_44)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return (int)(1);
    z_bb_30:
    zT_47 = self->offset_of_name_id;
    if ((int)(name_id == zT_47)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    return (int)(1);
    z_bb_32:
    zT_50 = self->bit_size_of_name_id;
    if ((int)(name_id == zT_50)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    return (int)(1);
    z_bb_34:
    zT_53 = self->bit_offset_of_name_id;
    if ((int)(name_id == zT_53)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (int)(1);
    z_bb_36:
    zT_56 = self->putchar_name_id;
    if ((int)(name_id == zT_56)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (int)(1);
    z_bb_38:
    zT_59 = self->stdout_write_name_id;
    if ((int)(name_id == zT_59)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    return (int)(1);
    z_bb_40:
    zT_62 = self->stderr_write_name_id;
    if ((int)(name_id == zT_62)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    return (int)(1);
    z_bb_42:
    zT_65 = self->getchar_name_id;
    if ((int)(name_id == zT_65)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    return (int)(1);
    z_bb_44:
    zT_68 = self->exit_name_id;
    if ((int)(name_id == zT_68)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    return (int)(1);
    z_bb_46:
    zT_71 = self->sleep_ms_name_id;
    if ((int)(name_id == zT_71)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (int)(1);
    z_bb_48:
    zT_74 = self->is_windows_name_id;
    if ((int)(name_id == zT_74)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    return (int)(1);
    z_bb_50:
    zT_77 = self->console_clear_name_id;
    if ((int)(name_id == zT_77)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (int)(1);
    z_bb_52:
    zT_80 = self->console_gotoxy_name_id;
    if ((int)(name_id == zT_80)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return (int)(1);
    z_bb_54:
    zT_83 = self->console_set_color_name_id;
    if ((int)(name_id == zT_83)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (int)(1);
    z_bb_56:
    zT_86 = self->async_frame_size_name_id;
    if ((int)(name_id == zT_86)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (int)(1);
    z_bb_58:
    zT_89 = self->async_init_name_id;
    if ((int)(name_id == zT_89)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (int)(1);
    z_bb_60:
    zT_92 = self->async_resume_name_id;
    if ((int)(name_id == zT_92)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (int)(1);
    z_bb_62:
    zT_95 = self->async_suspend_name_id;
    if ((int)(name_id == zT_95)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (int)(1);
    z_bb_64:
    zT_99 = "@enumToInt";
    zT_101 = 10;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    l_e2i = zT_100;
    zT_102 = self;
    zT_103 = name_id;
    zT_104 = l_e2i;
    zT_105 = zF_2ACB4E23_semanticAnalyzerBui(zT_102, zT_103, zT_104);
    if (zT_105) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    return (int)(1);
    z_bb_66:
    zT_108 = "@cVaStart";
    zT_110 = 9;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    l_cvs = zT_109;
    zT_111 = self;
    zT_112 = name_id;
    zT_113 = l_cvs;
    zT_114 = zF_2ACB4E23_semanticAnalyzerBui(zT_111, zT_112, zT_113);
    if (zT_114) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    return (int)(1);
    z_bb_68:
    zT_117 = "@cVaArg";
    zT_119 = 7;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    l_cva = zT_118;
    zT_120 = self;
    zT_121 = name_id;
    zT_122 = l_cva;
    zT_123 = zF_2ACB4E23_semanticAnalyzerBui(zT_120, zT_121, zT_122);
    if (zT_123) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    return (int)(1);
    z_bb_70:
    zT_126 = "@cVaEnd";
    zT_128 = 7;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    l_cve = zT_127;
    zT_129 = self;
    zT_130 = name_id;
    zT_131 = l_cve;
    zT_132 = zF_2ACB4E23_semanticAnalyzerBui(zT_129, zT_130, zT_131);
    if (zT_132) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    return (int)(1);
    z_bb_72:
    zT_135 = "@panic";
    zT_137 = 6;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    l_pan = zT_136;
    zT_138 = self;
    zT_139 = name_id;
    zT_140 = l_pan;
    zT_141 = zF_2ACB4E23_semanticAnalyzerBui(zT_138, zT_139, zT_140);
    if (zT_141) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    return (int)(1);
    z_bb_74:
    return (int)(0);
}

/* semanticAnalyzerDiagAsyncOutsideSuspending */
void zF_D4D0798B_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    int zT_2;
    zT_A4CE86B7_U64ToU32Map* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_10 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    zT_22A7C88B_AstNode zT_15 = {0};
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_F85C5DED_DiagnosticCollector* zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_39 = 0;
    zT_22A7C88B_AstNode a318_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u e318;
    zT_2 = self->async_analysis_ready;
    if ((int)(!zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = self->suspending_fns;
    zT_5 = self->module_id;
    zT_6 = self->current_fn_name;
    zT_10 = zF_7C7E43BF_asyncIsSuspending(zT_4, zT_5, zT_6);
    if (zT_10) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_12, zT_13);
    a318_node = zT_15;
    zT_17 = "@asyncSuspend used outside a suspending function";
    zT_19 = 48;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    e318 = zT_18;
    zT_20 = self->diag;
    zT_23 = self->source_file_id;
    zT_24 = a318_node.span_start;
    zT_35 = a318_node.span_start;
    zT_36 = a318_node.span_len;
    zT_26 = e318;
    zT_39 = zF_C82559AC_diagnosticCollector(zT_20, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3018_ASYNC_SUSPEND_OUTSIDE_SUSPENDING)), zT_23, zT_24, (unsigned int)(zT_35 + (unsigned int)((unsigned int)zT_36)), zT_26);
    (void)zT_39;
    return;
}

/* semanticAnalyzerDiagAsyncBuiltinInDefer */
void zF_2EC0CDC8_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_33 = 0;
    zT_22A7C88B_AstNode a319_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u e319;
    zT_2 = self->defer_depth;
    if ((int)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    a319_node = zT_9;
    zT_11 = "@async builtin used inside a defer/errdefer body";
    zT_13 = 48;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    e319 = zT_12;
    zT_14 = self->diag;
    zT_17 = self->source_file_id;
    zT_18 = a319_node.span_start;
    zT_29 = a319_node.span_start;
    zT_30 = a319_node.span_len;
    zT_20 = e319;
    zT_33 = zF_C82559AC_diagnosticCollector(zT_14, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3019_ASYNC_BUILTIN_IN_DEFER)), zT_17, zT_18, (unsigned int)(zT_29 + (unsigned int)((unsigned int)zT_30)), zT_20);
    (void)zT_33;
    return;
}

/* semanticAnalyzerGrowLocalDecls */
void zF_156C79D0_semanticAnalyzerGro(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_C6536882_EU_532 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    zT_3E40CD83_Sand* zT_23;
    zT_C6536882_EU_532 zT_30 = {0};
    unsigned char zT_31;
    unsigned char* zT_32;
    unsigned int* zT_35;
    unsigned int* zT_37;
    unsigned int zT_38;
    int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int new_cap;
    unsigned char* raw_names;
    unsigned char* raw_types;
    unsigned int* ndst;
    unsigned int* tdst;
    unsigned int ci;
    zT_2 = self->local_decl_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->local_decl_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_names = zT_20;
    zT_23 = self->expected_type_stack_alloc;
    zT_30 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_31 = zT_30.is_error;
    if (zT_31) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_32 = zT_30.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_types = zT_32;
    zT_35 = (unsigned int*)raw_names;
    ndst = zT_35;
    zT_37 = (unsigned int*)raw_types;
    tdst = zT_37;
    zT_38 = self->local_decl_count;
    if ((int)(zT_38 > (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ci = zT_43;
    goto z_bb_12;
    z_bb_11:
    self->local_decl_names = ndst;
    self->local_decl_types = tdst;
    self->local_decl_cap = new_cap;
    return;
    z_bb_12:
    zT_44 = self->local_decl_count;
    if ((int)(ci < zT_44)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = self->local_decl_names;
    zT_47 = zT_46[ci];
    ndst[ci] = zT_47;
    zT_48 = self->local_decl_types;
    zT_49 = zT_48[ci];
    tdst[ci] = zT_49;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_50 = 1;
    zT_51 = ci + zT_50;
    ci = zT_51;
    goto z_bb_12;
}

/* registerLocalDecl */
void zF_7BD72017_registerLocalDecl(zT_38C12417_SemanticAnalyzer* self, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    unsigned char* zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sct_tm;
    zT_3 = self->local_decl_count;
    zT_4 = self->local_decl_cap;
    if ((int)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_8 = "SCT:n";
    zT_10 = 5;
    zT_9.ptr = zT_8;
    zT_9.len = zT_10;
    sct_nm = zT_9;
    zT_11 = sct_nm;
    zT_12 = name_id;
    zF_C914CB83_markerWriteInt(zT_11, zT_12);
    zT_14 = "SCT:t";
    zT_16 = 5;
    zT_15.ptr = zT_14;
    zT_15.len = zT_16;
    sct_tm = zT_15;
    zT_17 = sct_tm;
    zT_18 = type_id;
    zF_C914CB83_markerWriteInt(zT_17, zT_18);
    zT_19 = self->local_decl_names;
    zT_20 = self->local_decl_count;
    zT_19[zT_20] = name_id;
    zT_21 = self->local_decl_types;
    zT_22 = self->local_decl_count;
    zT_21[zT_22] = type_id;
    zT_23 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_23 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCaptureType */
unsigned int zF_3E251D67_semanticAnalyzerCap(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_type) {
    zT_338B7C76_TypeRegistry* zT_6;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_0B10E8E9_OptionalPayload* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_0B10E8E9_OptionalPayload zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type capt_ty;
    if ((int)(cond_type == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_items;
    zT_8 = (unsigned int)cond_type;
    zT_9 = zT_7[zT_8];
    capt_ty = zT_9;
    zT_10 = capt_ty.kind;
    if ((int)(zT_10 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = self->registry;
    zT_16 = zT_15->opt_items;
    zT_17 = capt_ty.payload_idx;
    zT_18 = (unsigned int)zT_17;
    zT_19 = zT_16[zT_18];
    zT_20 = zT_19.payload;
    return zT_20;
    z_bb_4:
    return cond_type;
}

/* semanticAnalyzerResolveIdent */
unsigned int zF_9F1ECA79_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int module_id, unsigned int name_id, unsigned int node_idx) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int* zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_79FAE712_u64 zT_63;
    zT_338B7C76_TypeRegistry* zT_65;
    zT_79FAE712_u64 zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned int zT_70;
    zT_79FAE712_u64 zT_75;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_79FAE712_u64 zT_78;
    zT_BAEE192E_Opt_10 zT_80 = {0};
    zT_3D7259E2_SymbolRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_5979294E_Opt_849 zT_87 = {0};
    unsigned char zT_88;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_3C598AEF_SymbolKind zT_95;
    zT_38C12417_SemanticAnalyzer* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_105;
    unsigned char* zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    unsigned char zT_114;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned char zT_121;
    unsigned char* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned char* zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned int zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_134;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    unsigned char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    unsigned char zT_150;
    unsigned char* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned char zT_165;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    unsigned char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    unsigned char* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_185;
    unsigned int zT_187;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    unsigned int* zT_196;
    unsigned int zT_197;
    unsigned char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    unsigned int* zT_205;
    unsigned int zT_206;
    unsigned int zT_208;
    unsigned int zT_210;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_218;
    unsigned int* zT_219;
    unsigned int zT_220;
    unsigned char* zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    int zT_230;
    zT_D3EB6303_StringInterner* zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_237 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    zT_6B0A7D14_AstStore* zT_240;
    unsigned int zT_241;
    zT_22A7C88B_AstNode zT_243 = {0};
    unsigned char* zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned int zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    zT_8143F551_AstKind zT_250;
    zT_8EED1867_ResolvedTypeTable* zT_253;
    unsigned int zT_254;
    zT_BAEE192E_Opt_10 zT_256 = {0};
    unsigned char zT_257;
    unsigned char* zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned int zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    unsigned char* zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned char* zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    unsigned char* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_284;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    int zT_290;
    unsigned char* zT_291;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned int zT_294 = 0;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned char* zT_303;
    unsigned int zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    unsigned char* zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    unsigned int zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u ide;
    zT_8F083A69_Slice_zT_0B42B2F8_u sem_m;
    unsigned int li;
    zT_79FAE712_u64 key;
    zT_BAEE192E_Opt_10 ncg;
    zT_79FAE712_u64 mkey;
    zT_BAEE192E_Opt_10 ncgm;
    zT_5979294E_Opt_849 sym;
    unsigned int lcl_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u d7t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u id1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lt_m;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u id2;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_talias;
    unsigned int ctm;
    unsigned int ct;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_sv;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_tm;
    unsigned int nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u rdt_ntm;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u id3;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8l_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8i_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cname;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8k_m;
    zT_BAEE192E_Opt_10 rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8t_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8nl2;
    zT_8F083A69_Slice_zT_0B42B2F8_u d8z_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u idm;
    zT_5A26C2ED_Arr_unsigned_char_1 idnb;
    unsigned int idnl;
    unsigned int idns;
    zT_8F083A69_Slice_zT_0B42B2F8_u idc;
    zT_5 = "IDE\n";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    ide = zT_6;
    zT_8 = ide;
    zF_48AC7B3A_markerWrite(zT_8);
    if ((int)(name_id == (unsigned int)(1))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = "SEM:vi";
    zT_14 = 6;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    sem_m = zT_13;
    zT_15 = sem_m;
    zT_16 = module_id;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    goto z_bb_2;
    z_bb_2:
    zT_18 = self->local_decl_count;
    li = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((int)(li > (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = li - (unsigned int)(1);
    li = zT_22;
    zT_23 = self->local_decl_names;
    zT_24 = zT_23[li];
    if ((int)(zT_24 == name_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_63 = (zT_79FAE712_u64)name_id;
    key = zT_63;
    zT_65 = self->registry;
    zT_66 = key;
    zT_68 = zF_0EB68360_nameCacheGet(zT_65, zT_66);
    ncg = zT_68;
    zT_70 = self->module_id;
    zT_75 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_70) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    mkey = zT_75;
    zT_77 = self->registry;
    zT_78 = mkey;
    zT_80 = zF_0EB68360_nameCacheGet(zT_77, zT_78);
    ncgm = zT_80;
    zT_82 = self->symbols;
    zT_83 = self->module_id;
    zT_84 = name_id;
    zT_87 = zF_A398987E_symbolRegistryQuali(zT_82, zT_83, zT_84);
    sym = zT_87;
    zT_88 = sym.has_value;
    if (zT_88) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_27 = self->local_decl_types;
    zT_28 = zT_27[li];
    lcl_t = zT_28;
    zT_30 = "D7:Yn";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    d7m = zT_31;
    zT_33 = d7m;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_35 = "D7:n";
    zT_37 = 4;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    d7n_m = zT_36;
    zT_38 = d7n_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_41 = "D7:t";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    d7tm = zT_42;
    zT_44 = d7tm;
    zF_48AC7B3A_markerWrite(zT_44);
    zT_46 = "D7";
    zT_48 = 2;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    d7t_m = zT_47;
    zT_49 = d7t_m;
    zT_50 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_49, zT_50);
    zT_52 = "L\n";
    zT_54 = 2;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    id1 = zT_53;
    zT_55 = id1;
    zF_48AC7B3A_markerWrite(zT_55);
    zT_57 = "L:t";
    zT_59 = 3;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    lt_m = zT_58;
    zT_60 = lt_m;
    zT_61 = lcl_t;
    zF_C914CB83_markerWriteInt(zT_60, zT_61);
    return lcl_t;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    s = sym.value;
    zT_91 = "S\n";
    zT_93 = 2;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    id2 = zT_92;
    zT_94 = id2;
    zF_48AC7B3A_markerWrite(zT_94);
    zT_95 = s->kind;
    if ((int)(zT_95 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_165 = ncg.has_value;
    if (zT_165) goto z_bb_23; else goto z_bb_24;
    z_bb_11:
    zT_100 = self;
    zT_101 = s->decl_node;
    zT_102 = s->module_id;
    zF_FC6E31C6_semanticAnalyzerMay(zT_100, zT_101, zT_102);
    zT_105 = s->type_id;
    if ((int)(zT_105 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_134 = s->type_id;
    if ((int)(zT_134 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    zT_109 = "TAL\n";
    zT_111 = 4;
    zT_110.ptr = zT_109;
    zT_110.len = zT_111;
    rdt_talias = zT_110;
    zT_112 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_112);
    zT_113 = s->type_id;
    return zT_113;
    z_bb_14:
    zT_114 = ncgm.has_value;
    if (zT_114) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    ctm = ncgm.value;
    zT_117 = "TAL\n";
    zT_119 = 4;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    rdt_talias = zT_118;
    zT_120 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_120);
    return ctm;
    z_bb_16:
    zT_121 = ncg.has_value;
    if (zT_121) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    ct = ncg.value;
    zT_124 = "TAL\n";
    zT_126 = 4;
    zT_125.ptr = zT_124;
    zT_125.len = zT_126;
    rdt_talias = zT_125;
    zT_127 = rdt_talias;
    zF_48AC7B3A_markerWrite(zT_127);
    return ct;
    z_bb_18:
    zT_129 = "SVO\n";
    zT_131 = 4;
    zT_130.ptr = zT_129;
    zT_130.len = zT_131;
    rdt_sv = zT_130;
    zT_132 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_132);
    return (unsigned int)(1);
    z_bb_19:
    zT_138 = "STY:N";
    zT_140 = 5;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    rdt_nm = zT_139;
    zT_141 = rdt_nm;
    zT_142 = name_id;
    zF_C914CB83_markerWriteInt(zT_141, zT_142);
    zT_144 = "STY:T";
    zT_146 = 5;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    rdt_tm = zT_145;
    zT_147 = rdt_tm;
    zT_148 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_147, zT_148);
    zT_150 = ncg.has_value;
    if (zT_150) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_160 = "SVO\n";
    zT_162 = 4;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    rdt_sv = zT_161;
    zT_163 = rdt_sv;
    zF_48AC7B3A_markerWrite(zT_163);
    return (unsigned int)(1);
    z_bb_21:
    nt = ncg.value;
    zT_153 = "STY:C";
    zT_155 = 5;
    zT_154.ptr = zT_153;
    zT_154.len = zT_155;
    rdt_ntm = zT_154;
    zT_156 = rdt_ntm;
    zT_157 = nt;
    zF_C914CB83_markerWriteInt(zT_156, zT_157);
    goto z_bb_22;
    z_bb_22:
    zT_158 = s->type_id;
    return zT_158;
    z_bb_23:
    t = ncg.value;
    zT_168 = "C2:T";
    zT_170 = 4;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    id3 = zT_169;
    zT_171 = id3;
    zT_172 = t;
    zF_C914CB83_markerWriteInt(zT_171, zT_172);
    return t;
    z_bb_24:
    zT_174 = "D8:Nn";
    zT_176 = 5;
    zT_175.ptr = zT_174;
    zT_175.len = zT_176;
    d8n_m = zT_175;
    zT_177 = d8n_m;
    zT_178 = name_id;
    zF_C914CB83_markerWriteInt(zT_177, zT_178);
    zT_180 = "D8:C";
    zT_182 = 4;
    zT_181.ptr = zT_180;
    zT_181.len = zT_182;
    d8c_m = zT_181;
    zT_183 = d8c_m;
    zT_185 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_183, (unsigned int)((unsigned int)zT_185));
    zT_187 = self->local_decl_count;
    if ((int)(zT_187 > (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_191 = "D8:F";
    zT_193 = 4;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    d8f_m = zT_192;
    zT_194 = d8f_m;
    zT_196 = self->local_decl_names;
    zT_197 = 0;
    zT_195 = zT_196[zT_197];
    zF_C914CB83_markerWriteInt(zT_194, zT_195);
    zT_200 = "D8:L";
    zT_202 = 4;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    d8l_m = zT_201;
    zT_203 = d8l_m;
    zT_205 = self->local_decl_names;
    zT_206 = self->local_decl_count;
    zT_208 = zT_206 - (unsigned int)(1);
    zT_204 = zT_205[zT_208];
    zF_C914CB83_markerWriteInt(zT_203, zT_204);
    goto z_bb_26;
    z_bb_26:
    zT_210 = self->local_decl_count;
    if ((int)(zT_210 > (unsigned int)(4))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_214 = "D8:X";
    zT_216 = 4;
    zT_215.ptr = zT_214;
    zT_215.len = zT_216;
    d8x_m = zT_215;
    zT_217 = d8x_m;
    zT_219 = self->local_decl_names;
    zT_220 = 4;
    zT_218 = zT_219[zT_220];
    zF_C914CB83_markerWriteInt(zT_217, zT_218);
    goto z_bb_28;
    z_bb_28:
    zT_223 = "D8:I";
    zT_225 = 4;
    zT_224.ptr = zT_223;
    zT_224.len = zT_225;
    d8i_m = zT_224;
    zT_226 = d8i_m;
    zT_227 = node_idx;
    zF_C914CB83_markerWriteInt(zT_226, zT_227);
    if ((int)(node_idx >= (unsigned int)(450))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_230 = node_idx <= (unsigned int)(660);
    goto z_bb_31;
    z_bb_30:
    zT_230 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_230) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_234 = self->interner;
    zT_235 = name_id;
    zT_237 = zF_9134020D_stringInternerGet(zT_234, zT_235);
    cname = zT_237;
    zT_238 = cname;
    zF_48AC7B3A_markerWrite(zT_238);
    zT_240 = self->store;
    zT_241 = node_idx;
    zT_243 = zF_FCDD1D35_astStoreNodeAt(zT_240, zT_241);
    cnode = zT_243;
    zT_245 = "D8";
    zT_247 = 2;
    zT_246.ptr = zT_245;
    zT_246.len = zT_247;
    d8k_m = zT_246;
    zT_248 = d8k_m;
    zT_250 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_248, (unsigned int)((unsigned int)zT_250));
    zT_253 = self->type_table;
    zT_254 = node_idx;
    zT_256 = zF_999DCF51_resolvedTypeTableGe(zT_253, zT_254);
    rt = zT_256;
    zT_257 = rt.has_value;
    if (zT_257) goto z_bb_34; else goto z_bb_36;
    z_bb_33:
    zT_275 = self->_stub_0;
    if ((int)(name_id == zT_275)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    t = rt.value;
    zT_260 = "D8:T";
    zT_262 = 4;
    zT_261.ptr = zT_260;
    zT_261.len = zT_262;
    d8t_m = zT_261;
    zT_263 = d8t_m;
    zT_264 = t;
    zF_C914CB83_markerWriteInt(zT_263, zT_264);
    goto z_bb_35;
    z_bb_35:
    zT_271 = "\n";
    zT_273 = 1;
    zT_272.ptr = zT_271;
    zT_272.len = zT_273;
    d8nl2 = zT_272;
    zT_274 = d8nl2;
    zF_48AC7B3A_markerWrite(zT_274);
    goto z_bb_33;
    z_bb_36:
    zT_266 = "D8:Z\n";
    zT_268 = 5;
    zT_267.ptr = zT_266;
    zT_267.len = zT_268;
    d8z_m = zT_267;
    zT_269 = d8z_m;
    zF_48AC7B3A_markerWrite(zT_269);
    goto z_bb_35;
    z_bb_37:
    return (unsigned int)(18);
    z_bb_38:
    zT_279 = "IDT:";
    zT_281 = 4;
    zT_280.ptr = zT_279;
    zT_280.len = zT_281;
    idm = zT_280;
    zT_282 = idm;
    zF_48AC7B3A_markerWrite(zT_282);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_284[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        idnb[_i] = zT_284[_i];
        _i++;
    }
}
    zT_286 = name_id;
    zT_290 = 0;
    zT_291 = (unsigned char*)((unsigned char*)idnb) + zT_290;
    zT_292 = (unsigned int)(10) - zT_290;
    zT_293.ptr = zT_291;
    zT_293.len = zT_292;
    zT_287 = zT_293;
    zT_294 = zF_A7504564_itoa(zT_286, zT_287);
    idnl = zT_294;
    zT_298 = (unsigned int)(9) - (unsigned int)((unsigned int)idnl);
    idns = zT_298;
    zT_303 = (unsigned char*)((unsigned char*)idnb) + idns;
    zT_304 = (unsigned int)(9) - idns;
    zT_305.ptr = zT_303;
    zT_305.len = zT_304;
    zT_299 = zT_305;
    zF_48AC7B3A_markerWrite(zT_299);
    zT_307 = ":VOID\n";
    zT_309 = 6;
    zT_308.ptr = zT_307;
    zT_308.len = zT_309;
    idc = zT_308;
    zT_310 = idc;
    zF_48AC7B3A_markerWrite(zT_310);
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveFieldAccess */
unsigned int zF_DDD991E1_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8143F551_AstKind zT_29;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8143F551_AstKind zT_37;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    zT_6B0A7D14_AstStore* zT_48;
    unsigned int zT_49;
    unsigned int zT_52 = 0;
    zT_3D7259E2_SymbolRegistry* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_5979294E_Opt_849 zT_59 = {0};
    unsigned char zT_60;
    zT_3C598AEF_SymbolKind zT_62;
    unsigned int zT_68;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_D155D06D_Type* zT_73;
    unsigned int zT_74;
    zT_D155D06D_Type zT_75;
    zT_33EF6BFB_TypeKind zT_76;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_54FF90FA_TaggedUnionPayload* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_54FF90FA_TaggedUnionPayload zT_86;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned short zT_91;
    unsigned int zT_92;
    int zT_94;
    unsigned int zT_95;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_2DF01B61_FieldEntry* zT_98;
    unsigned int zT_99;
    zT_2DF01B61_FieldEntry zT_100;
    unsigned int zT_101;
    zT_8EED1867_ResolvedTypeTable* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    int zT_107;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_457ECFEE_EnumPayload* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_457ECFEE_EnumPayload zT_119;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned short zT_124;
    unsigned int zT_125;
    int zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D96DCDF2_EnumMember* zT_131;
    unsigned int zT_132;
    zT_D96DCDF2_EnumMember zT_133;
    unsigned int zT_134;
    zT_8EED1867_ResolvedTypeTable* zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    int zT_140;
    unsigned int zT_141;
    zT_33EF6BFB_TypeKind zT_142;
    zT_338B7C76_TypeRegistry* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_152 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_3C598AEF_SymbolKind zT_159;
    unsigned int zT_165;
    zT_3D7259E2_SymbolRegistry* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_5979294E_Opt_849 zT_171 = {0};
    unsigned char zT_172;
    unsigned char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned short zT_180;
    unsigned char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    zT_3C598AEF_SymbolKind zT_188;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    unsigned char* zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    unsigned short zT_203;
    zT_3C598AEF_SymbolKind zT_208;
    zT_8EED1867_ResolvedTypeTable* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int zT_218;
    unsigned int zT_219;
    zT_8EED1867_ResolvedTypeTable* zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    unsigned int zT_227;
    zT_3C598AEF_SymbolKind zT_228;
    int zT_233;
    unsigned int zT_234;
    unsigned char* zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    zT_6B0A7D14_AstStore* zT_243;
    unsigned int zT_244;
    zT_22A7C88B_AstNode zT_247 = {0};
    zT_8143F551_AstKind zT_248;
    zT_6B0A7D14_AstStore* zT_254;
    zT_4A7609CD_anon_224403 zT_255;
    zT_243D6A41_FnProto* zT_256;
    zT_6B0A7D14_AstStore* zT_257;
    unsigned int zT_258;
    unsigned int zT_261 = 0;
    unsigned int zT_262;
    zT_243D6A41_FnProto zT_263;
    unsigned char* zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned int zT_269;
    unsigned int zT_271;
    zT_8EED1867_ResolvedTypeTable* zT_275;
    unsigned int zT_276;
    zT_BAEE192E_Opt_10 zT_279 = {0};
    unsigned char zT_281;
    unsigned int zT_282;
    unsigned char* zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned int zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    unsigned int zT_290;
    unsigned char zT_291;
    zT_338B7C76_TypeRegistry* zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    unsigned int zT_299;
    unsigned short zT_300;
    unsigned int zT_301;
    unsigned char zT_302;
    unsigned int zT_311 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_ABC1EBBE_TypeResolveEnv zT_317;
    zT_6B0A7D14_AstStore* zT_318;
    zT_338B7C76_TypeRegistry* zT_319;
    zT_3D7259E2_SymbolRegistry* zT_320;
    zT_D3EB6303_StringInterner* zT_321;
    unsigned int zT_322;
    zT_F85C5DED_DiagnosticCollector* zT_323;
    zT_7334F4FE_Opt_225 zT_324;
    zT_F6B96876_Opt_395 zT_325 = {0};
    unsigned int zT_326;
    zT_ABC1EBBE_TypeResolveEnv* zT_328;
    unsigned int zT_329;
    unsigned int zT_334 = 0;
    unsigned char* zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    unsigned int zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    unsigned int zT_340;
    unsigned char* zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned int zT_345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    unsigned int zT_347;
    zT_8EED1867_ResolvedTypeTable* zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    zT_338B7C76_TypeRegistry* zT_356;
    unsigned int zT_357;
    unsigned int zT_358;
    unsigned int zT_361;
    unsigned short zT_362;
    unsigned int zT_363;
    unsigned char zT_364;
    unsigned int zT_373 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_374;
    unsigned int zT_375;
    unsigned int zT_376;
    unsigned char* zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380;
    unsigned int zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_382;
    zT_338B7C76_TypeRegistry* zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    unsigned int zT_389;
    unsigned short zT_390;
    unsigned char zT_392;
    unsigned int zT_402 = 0;
    unsigned char* zT_404;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405;
    unsigned int zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    unsigned int zT_408;
    zT_8EED1867_ResolvedTypeTable* zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned char* zT_414;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_415;
    unsigned int zT_416;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_417;
    unsigned int zT_418;
    zT_8EED1867_ResolvedTypeTable* zT_419;
    unsigned int zT_420;
    unsigned int zT_428;
    unsigned int zT_430;
    unsigned int zT_432;
    zT_D3EB6303_StringInterner* zT_434;
    unsigned int zT_435;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_437 = {0};
    unsigned char* zT_439;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_440;
    unsigned int zT_441;
    unsigned char* zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_444;
    unsigned int zT_445;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_447;
    unsigned int zT_448;
    unsigned int zT_449;
    unsigned int zT_450;
    zT_D3EB6303_StringInterner* zT_452;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_453;
    int zT_456;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_460;
    unsigned int zT_463;
    unsigned int zT_464;
    unsigned int zT_465;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_466;
    unsigned int zT_474 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_475;
    unsigned int zT_476;
    zT_8143F551_AstKind zT_481;
    zT_6B0A7D14_AstStore* zT_487;
    unsigned int zT_488;
    unsigned int zT_491 = 0;
    zT_072B53A6_ModuleRegistry* zT_493;
    unsigned int zT_494;
    zT_BAEE192E_Opt_10 zT_496 = {0};
    unsigned char zT_497;
    zT_3D7259E2_SymbolRegistry* zT_500;
    unsigned int zT_501;
    unsigned int zT_502;
    zT_5979294E_Opt_849 zT_504 = {0};
    unsigned char zT_505;
    unsigned short zT_507;
    zT_3C598AEF_SymbolKind zT_512;
    zT_8EED1867_ResolvedTypeTable* zT_517;
    unsigned int zT_518;
    unsigned int zT_519;
    unsigned int zT_522;
    unsigned int zT_523;
    zT_8EED1867_ResolvedTypeTable* zT_526;
    unsigned int zT_527;
    unsigned int zT_528;
    unsigned int zT_531;
    zT_38C12417_SemanticAnalyzer* zT_533;
    unsigned int zT_534;
    unsigned int zT_536 = 0;
    unsigned char* zT_540;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_541;
    unsigned int zT_542;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_543;
    zT_8EED1867_ResolvedTypeTable* zT_544;
    unsigned int zT_545;
    zT_338B7C76_TypeRegistry* zT_551;
    zT_D155D06D_Type* zT_552;
    unsigned int zT_553;
    zT_D155D06D_Type zT_554;
    int zT_556;
    unsigned int zT_557;
    int zT_559;
    unsigned int zT_560;
    zT_33EF6BFB_TypeKind zT_561;
    int zT_566;
    zT_33EF6BFB_TypeKind zT_567;
    zT_33EF6BFB_TypeKind zT_573;
    zT_338B7C76_TypeRegistry* zT_574;
    zT_112BF819_PtrPayload* zT_575;
    unsigned int zT_576;
    unsigned int zT_577;
    zT_112BF819_PtrPayload zT_578;
    unsigned int zT_579;
    zT_338B7C76_TypeRegistry* zT_580;
    zT_D155D06D_Type* zT_581;
    unsigned int zT_582;
    zT_D155D06D_Type zT_583;
    unsigned char* zT_585;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_586;
    unsigned int zT_587;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_588;
    unsigned char* zT_592;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_593;
    unsigned int zT_594;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_595;
    zT_33EF6BFB_TypeKind zT_597;
    unsigned char* zT_600;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    unsigned int zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    zT_33EF6BFB_TypeKind zT_604;
    unsigned int zT_610;
    unsigned int zT_612;
    unsigned int zT_614;
    unsigned char* zT_616;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_617;
    unsigned int zT_618;
    zT_F85C5DED_DiagnosticCollector* zT_619;
    unsigned int zT_622;
    unsigned int zT_623;
    unsigned int zT_624;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_625;
    unsigned int zT_630 = 0;
    zT_33EF6BFB_TypeKind zT_632;
    unsigned int zT_638;
    unsigned int zT_640;
    unsigned int zT_642;
    unsigned char* zT_644;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_645;
    unsigned int zT_646;
    zT_F85C5DED_DiagnosticCollector* zT_647;
    unsigned int zT_650;
    unsigned int zT_651;
    unsigned int zT_652;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_653;
    unsigned int zT_658 = 0;
    zT_33EF6BFB_TypeKind zT_660;
    zT_338B7C76_TypeRegistry* zT_666;
    zT_406493CE_StructPayload* zT_667;
    unsigned int zT_668;
    unsigned int zT_669;
    zT_406493CE_StructPayload zT_670;
    unsigned int zT_671;
    unsigned int zT_672;
    unsigned short zT_673;
    unsigned int zT_674;
    zT_33EF6BFB_TypeKind zT_675;
    int zT_680;
    zT_33EF6BFB_TypeKind zT_681;
    zT_338B7C76_TypeRegistry* zT_687;
    zT_AF9231A2_UnionPayload* zT_688;
    unsigned int zT_689;
    unsigned int zT_690;
    zT_AF9231A2_UnionPayload zT_691;
    unsigned int zT_692;
    unsigned int zT_693;
    unsigned short zT_694;
    unsigned int zT_695;
    zT_33EF6BFB_TypeKind zT_696;
    zT_338B7C76_TypeRegistry* zT_702;
    zT_54FF90FA_TaggedUnionPayload* zT_703;
    unsigned int zT_704;
    unsigned int zT_705;
    zT_54FF90FA_TaggedUnionPayload zT_706;
    unsigned char* zT_708;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    unsigned int zT_710;
    zT_D3EB6303_StringInterner* zT_712;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_713;
    unsigned int zT_715 = 0;
    unsigned char* zT_718;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_719;
    unsigned int zT_720;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_721;
    zT_8EED1867_ResolvedTypeTable* zT_722;
    unsigned int zT_723;
    unsigned int zT_724;
    unsigned int zT_727;
    unsigned char* zT_729;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_730;
    unsigned int zT_731;
    zT_D3EB6303_StringInterner* zT_733;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_734;
    unsigned int zT_736 = 0;
    unsigned short zT_739;
    unsigned int zT_740;
    int zT_742;
    unsigned int zT_743;
    zT_338B7C76_TypeRegistry* zT_746;
    zT_2DF01B61_FieldEntry* zT_747;
    unsigned int zT_748;
    unsigned int zT_750;
    zT_2DF01B61_FieldEntry zT_751;
    unsigned int zT_752;
    unsigned int zT_756;
    zT_338B7C76_TypeRegistry* zT_758;
    zT_D155D06D_Type* zT_759;
    unsigned int zT_760;
    zT_D155D06D_Type zT_761;
    zT_33EF6BFB_TypeKind zT_762;
    zT_338B7C76_TypeRegistry* zT_768;
    zT_E834303C_ArrayPayload* zT_769;
    unsigned int zT_770;
    unsigned int zT_771;
    zT_E834303C_ArrayPayload zT_772;
    unsigned int zT_773;
    zT_338B7C76_TypeRegistry* zT_774;
    unsigned int zT_775;
    unsigned int zT_779 = 0;
    unsigned char* zT_781;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_782;
    unsigned int zT_783;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_784;
    zT_8EED1867_ResolvedTypeTable* zT_785;
    unsigned int zT_786;
    unsigned int zT_787;
    int zT_789;
    unsigned int zT_790;
    unsigned int zT_791;
    unsigned int zT_792;
    unsigned short zT_793;
    unsigned int zT_794;
    zT_33EF6BFB_TypeKind zT_795;
    unsigned char* zT_801;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_802;
    unsigned int zT_803;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_804;
    zT_3D7259E2_SymbolRegistry* zT_806;
    unsigned int zT_807;
    unsigned int zT_808;
    zT_5979294E_Opt_849 zT_811 = {0};
    unsigned char zT_812;
    unsigned int zT_814;
    unsigned char* zT_818;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_819;
    unsigned int zT_820;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_821;
    zT_8EED1867_ResolvedTypeTable* zT_822;
    unsigned int zT_823;
    unsigned int zT_824;
    unsigned int zT_827;
    zT_3C598AEF_SymbolKind zT_828;
    zT_8EED1867_ResolvedTypeTable* zT_834;
    unsigned int zT_835;
    zT_BAEE192E_Opt_10 zT_838 = {0};
    unsigned char zT_839;
    unsigned char* zT_842;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_843;
    unsigned int zT_844;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_845;
    zT_8EED1867_ResolvedTypeTable* zT_846;
    unsigned int zT_847;
    unsigned int zT_848;
    unsigned char* zT_851;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_852;
    unsigned int zT_853;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_854;
    zT_6B0A7D14_AstStore* zT_856;
    unsigned int zT_857;
    zT_22A7C88B_AstNode zT_860 = {0};
    zT_8143F551_AstKind zT_861;
    zT_6B0A7D14_AstStore* zT_867;
    zT_4A7609CD_anon_224403 zT_868;
    zT_243D6A41_FnProto* zT_869;
    zT_6B0A7D14_AstStore* zT_870;
    unsigned int zT_871;
    unsigned int zT_874 = 0;
    unsigned int zT_875;
    zT_243D6A41_FnProto zT_876;
    unsigned char* zT_878;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_879;
    unsigned int zT_880;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_881;
    unsigned int zT_883;
    unsigned int zT_885;
    zT_8EED1867_ResolvedTypeTable* zT_889;
    unsigned int zT_890;
    zT_BAEE192E_Opt_10 zT_893 = {0};
    unsigned char zT_894;
    zT_338B7C76_TypeRegistry* zT_897;
    unsigned int zT_898;
    unsigned int zT_899;
    unsigned int zT_902;
    unsigned short zT_903;
    unsigned int zT_904;
    unsigned char zT_905;
    unsigned int zT_914 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_915;
    unsigned int zT_916;
    unsigned int zT_917;
    zT_ABC1EBBE_TypeResolveEnv zT_920;
    zT_6B0A7D14_AstStore* zT_921;
    zT_338B7C76_TypeRegistry* zT_922;
    zT_3D7259E2_SymbolRegistry* zT_923;
    zT_D3EB6303_StringInterner* zT_924;
    unsigned int zT_925;
    zT_F85C5DED_DiagnosticCollector* zT_926;
    zT_7334F4FE_Opt_225 zT_927;
    zT_F6B96876_Opt_395 zT_928 = {0};
    unsigned int zT_929;
    zT_ABC1EBBE_TypeResolveEnv* zT_931;
    unsigned int zT_932;
    unsigned int zT_937 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_940;
    unsigned int zT_941;
    unsigned int zT_942;
    zT_338B7C76_TypeRegistry* zT_946;
    unsigned int zT_947;
    unsigned int zT_948;
    unsigned int zT_951;
    unsigned short zT_952;
    unsigned int zT_953;
    unsigned char zT_954;
    unsigned int zT_963 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_964;
    unsigned int zT_965;
    unsigned int zT_966;
    zT_338B7C76_TypeRegistry* zT_969;
    unsigned int zT_970;
    unsigned int zT_971;
    unsigned int zT_974;
    unsigned short zT_975;
    unsigned char zT_977;
    unsigned int zT_987 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_988;
    unsigned int zT_989;
    unsigned int zT_990;
    unsigned char* zT_993;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_994;
    unsigned int zT_995;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_996;
    zT_3C598AEF_SymbolKind zT_998;
    unsigned char* zT_1001;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1002;
    unsigned int zT_1003;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1004;
    zT_8EED1867_ResolvedTypeTable* zT_1005;
    unsigned int zT_1006;
    zT_33EF6BFB_TypeKind zT_1011;
    zT_338B7C76_TypeRegistry* zT_1017;
    zT_0BB2A741_SlicePayload* zT_1018;
    unsigned int zT_1019;
    unsigned int zT_1020;
    zT_0BB2A741_SlicePayload zT_1021;
    unsigned char* zT_1023;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1024;
    unsigned int zT_1025;
    zT_D3EB6303_StringInterner* zT_1027;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1028;
    unsigned int zT_1030 = 0;
    unsigned char* zT_1033;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1034;
    unsigned int zT_1035;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1036;
    zT_8EED1867_ResolvedTypeTable* zT_1037;
    unsigned int zT_1038;
    unsigned char* zT_1044;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1045;
    unsigned int zT_1046;
    zT_D3EB6303_StringInterner* zT_1048;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1049;
    unsigned int zT_1051 = 0;
    zT_338B7C76_TypeRegistry* zT_1054;
    unsigned int zT_1055;
    unsigned char zT_1059;
    unsigned int zT_1064 = 0;
    unsigned char* zT_1066;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1067;
    unsigned int zT_1068;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1069;
    zT_8EED1867_ResolvedTypeTable* zT_1070;
    unsigned int zT_1071;
    unsigned int zT_1072;
    zT_33EF6BFB_TypeKind zT_1074;
    unsigned char* zT_1080;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1081;
    unsigned int zT_1082;
    zT_D3EB6303_StringInterner* zT_1084;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1085;
    unsigned int zT_1087 = 0;
    unsigned char* zT_1090;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1091;
    unsigned int zT_1092;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1093;
    zT_8EED1867_ResolvedTypeTable* zT_1094;
    unsigned int zT_1095;
    zT_33EF6BFB_TypeKind zT_1100;
    zT_338B7C76_TypeRegistry* zT_1106;
    unsigned int zT_1107;
    unsigned int zT_1108;
    unsigned int zT_1110 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_1113;
    unsigned int zT_1114;
    unsigned int zT_1115;
    zT_8EED1867_ResolvedTypeTable* zT_1117;
    unsigned int zT_1118;
    zT_33EF6BFB_TypeKind zT_1123;
    zT_338B7C76_TypeRegistry* zT_1129;
    zT_457ECFEE_EnumPayload* zT_1130;
    unsigned int zT_1131;
    unsigned int zT_1132;
    zT_457ECFEE_EnumPayload zT_1133;
    unsigned int zT_1135;
    unsigned int zT_1136;
    unsigned short zT_1138;
    unsigned int zT_1139;
    int zT_1141;
    unsigned int zT_1142;
    zT_338B7C76_TypeRegistry* zT_1144;
    zT_D96DCDF2_EnumMember* zT_1145;
    unsigned int zT_1146;
    zT_D96DCDF2_EnumMember zT_1147;
    unsigned int zT_1148;
    zT_8EED1867_ResolvedTypeTable* zT_1150;
    unsigned int zT_1151;
    unsigned int zT_1152;
    int zT_1154;
    unsigned int zT_1155;
    unsigned char* zT_1157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1158;
    unsigned int zT_1159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1160;
    zT_8EED1867_ResolvedTypeTable* zT_1161;
    unsigned int zT_1162;
    unsigned char* zT_1168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1169;
    unsigned int zT_1170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1171;
    zT_8EED1867_ResolvedTypeTable* zT_1172;
    unsigned int zT_1173;
    int zT_1179;
    unsigned int zT_1180;
    zT_338B7C76_TypeRegistry* zT_1183;
    zT_2DF01B61_FieldEntry* zT_1184;
    unsigned int zT_1185;
    zT_2DF01B61_FieldEntry zT_1186;
    unsigned int zT_1187;
    unsigned int zT_1190;
    zT_338B7C76_TypeRegistry* zT_1192;
    zT_D155D06D_Type* zT_1193;
    unsigned int zT_1194;
    zT_D155D06D_Type zT_1195;
    zT_33EF6BFB_TypeKind zT_1196;
    zT_338B7C76_TypeRegistry* zT_1202;
    zT_E834303C_ArrayPayload* zT_1203;
    unsigned int zT_1204;
    unsigned int zT_1205;
    zT_E834303C_ArrayPayload zT_1206;
    unsigned int zT_1207;
    zT_338B7C76_TypeRegistry* zT_1208;
    unsigned int zT_1209;
    unsigned int zT_1213 = 0;
    unsigned char* zT_1215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1216;
    unsigned int zT_1217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1218;
    unsigned int zT_1219;
    zT_8EED1867_ResolvedTypeTable* zT_1220;
    unsigned int zT_1221;
    unsigned int zT_1222;
    int zT_1224;
    unsigned int zT_1226;
    unsigned char* zT_1228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1229;
    unsigned int zT_1230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1231;
    unsigned char* zT_1233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1234;
    unsigned int zT_1235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1236;
    unsigned int zT_1237;
    unsigned char* zT_1239;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1240;
    unsigned int zT_1241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1242;
    unsigned int zT_1243;
    unsigned char* zT_1245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1246;
    unsigned int zT_1247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1248;
    unsigned int zT_1249;
    zT_8EED1867_ResolvedTypeTable* zT_1250;
    unsigned int zT_1251;
    zT_8F083A69_Slice_zT_0B42B2F8_u fae;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode base_node;
    unsigned int field_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_bkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfa_fnm;
    unsigned int base_rt;
    unsigned int base_ident_id;
    zT_5979294E_Opt_849 sym;
    unsigned int base_type_id;
    zT_3A105EF1_Symbol* s;
    unsigned int alias_type_id;
    zT_D155D06D_Type aty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int fi;
    zT_457ECFEE_EnumPayload ep;
    unsigned int estart;
    unsigned int ecount;
    unsigned int ei;
    unsigned int es_mi;
    unsigned int target_mod;
    zT_5979294E_Opt_849 field_sym;
    zT_3A105EF1_Symbol* fs;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1kl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1tl_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1v_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u q1fx;
    zT_22A7C88B_AstNode fn_dn;
    zT_243D6A41_FnProto proto;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre1_m;
    zT_BAEE192E_Opt_10 rtt;
    unsigned int rtt_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre3_m;
    unsigned int fn_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre4_m;
    unsigned int rv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bre2_m;
    unsigned int rtv;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int resolved_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr1_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brr2_m;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u uinm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uiparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u uimsg;
    unsigned int path_id;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fa1;
    zT_D155D06D_Type base_ty;
    unsigned int fields_start;
    unsigned int fields_count;
    zT_33EF6BFB_TypeKind pre_kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_ok_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_dk_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fapr_nl;
    unsigned int sp;
    unsigned int ep_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u opt_msg;
    unsigned int ep_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u eu_msg;
    zT_406493CE_StructPayload sp_3;
    zT_AF9231A2_UnionPayload up;
    zT_8F083A69_Slice_zT_0B42B2F8_u tag_s;
    unsigned int tag_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ft_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u payload_s;
    unsigned int payload_id;
    unsigned int fpe_count;
    unsigned int fpei;
    zT_2DF01B61_FieldEntry fpe;
    unsigned int payload_res;
    zT_D155D06D_Type payload_rt;
    unsigned int payload_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u fpe_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfa;
    zT_5979294E_Opt_849 mod_field_sym;
    zT_3A105EF1_Symbol* mfs;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf3;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf1;
    zT_BAEE192E_Opt_10 fn_tid_opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf2_m;
    unsigned int fn_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u mff;
    zT_22A7C88B_AstNode dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u mfp_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_b;
    unsigned int resolved_rt_b;
    zT_0BB2A741_SlicePayload sp_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u len_s;
    unsigned int len_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsl;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptr_s;
    unsigned int ptr_id;
    unsigned int pty;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u faa_m;
    unsigned int es_mi2;
    zT_457ECFEE_EnumPayload ep3;
    unsigned int estart3;
    unsigned int ecount3;
    unsigned int ei3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnf2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2f_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2b_m;
    unsigned int result;
    zT_D155D06D_Type rt;
    unsigned int elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_3 = "FAE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fae = zT_4;
    zT_6 = fae;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    base_node = zT_17;
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    field_name_id = zT_22;
    zT_24 = "PFA:BK";
    zT_26 = 6;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    pfa_bkm = zT_25;
    zT_27 = pfa_bkm;
    zT_29 = base_node.kind;
    zF_C914CB83_markerWriteInt(zT_27, (unsigned int)((unsigned int)zT_29));
    zT_32 = "PFA:FN";
    zT_34 = 6;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    pfa_fnm = zT_33;
    zT_35 = pfa_fnm;
    zT_36 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_35, zT_36);
    zT_37 = base_node.kind;
    if ((int)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_43 = self;
    zT_44 = node.child_0;
    zT_46 = zF_54F95822_semanticAnalyzerRes(zT_43, zT_44);
    base_rt = zT_46;
    zT_48 = self->store;
    zT_49 = node.child_0;
    zT_52 = zF_53458827_astStoreIdentifier(zT_48, zT_49);
    base_ident_id = zT_52;
    zT_54 = self->symbols;
    zT_55 = self->module_id;
    zT_56 = base_ident_id;
    zT_59 = zF_A398987E_symbolRegistryQuali(zT_54, zT_55, zT_56);
    sym = zT_59;
    zT_60 = sym.has_value;
    if (zT_60) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_533 = self;
    zT_534 = node.child_0;
    zT_536 = zF_54F95822_semanticAnalyzerRes(zT_533, zT_534);
    base_type_id = zT_536;
    if ((int)(base_type_id == (unsigned int)(1))) goto z_bb_71; else goto z_bb_72;
    z_bb_3:
    zT_481 = base_node.kind;
    if ((int)(zT_481 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_59; else goto z_bb_60;
    z_bb_4:
    s = sym.value;
    zT_62 = s->kind;
    if ((int)(zT_62 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    if ((int)(base_rt == (unsigned int)(1))) goto z_bb_57; else goto z_bb_58;
    z_bb_7:
    zT_68 = s->type_id;
    alias_type_id = zT_68;
    if ((int)(alias_type_id != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_159 = s->kind;
    if ((int)(zT_159 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_31; else goto z_bb_32;
    z_bb_9:
    zT_72 = self->registry;
    zT_73 = zT_72->types_items;
    zT_74 = (unsigned int)alias_type_id;
    zT_75 = zT_73[zT_74];
    aty = zT_75;
    zT_76 = aty.kind;
    if ((int)(zT_76 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_82 = self->registry;
    zT_83 = zT_82->tu_items;
    zT_84 = aty.payload_idx;
    zT_85 = (unsigned int)zT_84;
    zT_86 = zT_83[zT_85];
    tp = zT_86;
    zT_88 = tp.fields_start;
    zT_89 = (unsigned int)zT_88;
    fstart = zT_89;
    zT_91 = tp.fields_count;
    zT_92 = (unsigned int)zT_91;
    fcount = zT_92;
    zT_94 = 0;
    zT_95 = (unsigned int)zT_94;
    fi = zT_95;
    goto z_bb_13;
    z_bb_12:
    zT_109 = aty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_13:
    if ((int)(fi < fcount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_97 = self->registry;
    zT_98 = zT_97->fe_items;
    zT_99 = fstart + fi;
    zT_100 = zT_98[zT_99];
    zT_101 = zT_100.name_id;
    if ((int)(zT_101 == field_name_id)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_107 = 1;
    zT_108 = fi + zT_107;
    fi = zT_108;
    goto z_bb_13;
    z_bb_17:
    zT_103 = self->type_table;
    zT_104 = node_idx;
    zT_105 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_103, zT_104, zT_105);
    return alias_type_id;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_115 = self->registry;
    zT_116 = zT_115->en_items;
    zT_117 = aty.payload_idx;
    zT_118 = (unsigned int)zT_117;
    zT_119 = zT_116[zT_118];
    ep = zT_119;
    zT_121 = ep.members_start;
    zT_122 = (unsigned int)zT_121;
    estart = zT_122;
    zT_124 = ep.members_count;
    zT_125 = (unsigned int)zT_124;
    ecount = zT_125;
    zT_127 = 0;
    zT_128 = (unsigned int)zT_127;
    ei = zT_128;
    goto z_bb_21;
    z_bb_20:
    zT_142 = aty.kind;
    if ((int)(zT_142 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_21:
    if ((int)(ei < ecount)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_130 = self->registry;
    zT_131 = zT_130->em_items;
    zT_132 = estart + ei;
    zT_133 = zT_131[zT_132];
    zT_134 = zT_133.name_id;
    if ((int)(zT_134 == field_name_id)) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_140 = 1;
    zT_141 = ei + zT_140;
    ei = zT_141;
    goto z_bb_21;
    z_bb_25:
    zT_136 = self->type_table;
    zT_137 = node_idx;
    zT_138 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_136, zT_137, zT_138);
    return alias_type_id;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_148 = self->registry;
    zT_149 = alias_type_id;
    zT_150 = field_name_id;
    zT_152 = zF_D2ECD176_typeRegistryErrorSe(zT_148, zT_149, zT_150);
    es_mi = zT_152;
    if ((int)(es_mi != (unsigned int)(4294967295u))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    zT_155 = self->type_table;
    zT_156 = node_idx;
    zT_157 = alias_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_155, zT_156, zT_157);
    return alias_type_id;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_165 = s->module_id;
    target_mod = zT_165;
    zT_167 = self->symbols;
    zT_168 = target_mod;
    zT_169 = field_name_id;
    zT_171 = zF_A398987E_symbolRegistryQuali(zT_167, zT_168, zT_169);
    field_sym = zT_171;
    zT_172 = field_sym.has_value;
    if (zT_172) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_5;
    z_bb_33:
    fs = field_sym.value;
    zT_175 = "Q1:FL";
    zT_177 = 5;
    zT_176.ptr = zT_175;
    zT_176.len = zT_177;
    q1fl_m = zT_176;
    zT_178 = q1fl_m;
    zT_180 = fs->flags;
    zF_C914CB83_markerWriteInt(zT_178, (unsigned int)((unsigned int)zT_180));
    zT_183 = "Q1:KL";
    zT_185 = 5;
    zT_184.ptr = zT_183;
    zT_184.len = zT_185;
    q1kl_m = zT_184;
    zT_186 = q1kl_m;
    zT_188 = fs->kind;
    zF_C914CB83_markerWriteInt(zT_186, (unsigned int)((unsigned int)zT_188));
    zT_191 = "Q1:TL";
    zT_193 = 5;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    q1tl_m = zT_192;
    zT_194 = q1tl_m;
    zT_195 = fs->type_id;
    zF_C914CB83_markerWriteInt(zT_194, zT_195);
    zT_198 = "Q1:FN";
    zT_200 = 5;
    zT_199.ptr = zT_198;
    zT_199.len = zT_200;
    q1fn_m = zT_199;
    zT_201 = q1fn_m;
    zT_202 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_201, zT_202);
    zT_203 = fs->flags;
    if ((int)((unsigned short)(zT_203 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_414 = "Q1VF:FN";
    zT_416 = 7;
    zT_415.ptr = zT_414;
    zT_415.len = zT_416;
    q1v_m = zT_415;
    zT_417 = q1v_m;
    zT_418 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_417, zT_418);
    zT_419 = self->type_table;
    zT_420 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_419, zT_420, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_35:
    zT_208 = fs->kind;
    if ((int)(zT_208 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_228 = fs->kind;
    if ((int)(zT_228 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_41; else goto z_bb_42;
    z_bb_37:
    zT_213 = self->type_table;
    zT_214 = node_idx;
    zT_215 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_213, zT_214, zT_215);
    zT_218 = fs->type_id;
    return zT_218;
    z_bb_38:
    zT_219 = fs->type_id;
    if ((int)(zT_219 != (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_222 = self->type_table;
    zT_223 = node_idx;
    zT_224 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_222, zT_223, zT_224);
    zT_227 = fs->type_id;
    return zT_227;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_234 = fs->decl_node;
    zT_233 = zT_234 != (unsigned int)(0);
    goto z_bb_43;
    z_bb_42:
    zT_233 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_233) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_238 = "Q1FX\n";
    zT_240 = 5;
    zT_239.ptr = zT_238;
    zT_239.len = zT_240;
    q1fx = zT_239;
    zT_241 = q1fx;
    zF_48AC7B3A_markerWrite(zT_241);
    zT_243 = self->store;
    zT_244 = fs->decl_node;
    zT_247 = zF_FCDD1D35_astStoreNodeAt(zT_243, zT_244);
    fn_dn = zT_247;
    zT_248 = fn_dn.kind;
    if ((int)(zT_248 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_34;
    z_bb_46:
    zT_254 = self->store;
    zT_255 = zT_254->fn_protos;
    zT_256 = zT_255.items;
    zT_257 = self->store;
    zT_258 = fs->decl_node;
    zT_261 = zF_8BA26B9E_astStoreNodePayload(zT_257, zT_258);
    zT_262 = (unsigned int)zT_261;
    zT_263 = zT_256[zT_262];
    proto = zT_263;
    zT_265 = "BR:x";
    zT_267 = 4;
    zT_266.ptr = zT_265;
    zT_266.len = zT_267;
    bre1_m = zT_266;
    zT_268 = bre1_m;
    zT_269 = proto.name_id;
    zF_C914CB83_markerWriteInt(zT_268, zT_269);
    zT_271 = proto.return_type_node;
    if ((int)(zT_271 != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_275 = self->type_table;
    zT_276 = proto.return_type_node;
    zT_279 = zF_999DCF51_resolvedTypeTableGe(zT_275, zT_276);
    rtt = zT_279;
    zT_281 = rtt.has_value;
    if (zT_281) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    zT_379 = "BR:dv\n";
    zT_381 = 6;
    zT_380.ptr = zT_379;
    zT_380.len = zT_381;
    bre3_m = zT_380;
    zT_382 = bre3_m;
    zF_48AC7B3A_markerWrite(zT_382);
    zT_384 = self->registry;
    zT_385 = proto.name_id;
    zT_386 = fs->module_id;
    zT_389 = proto.params_start;
    zT_390 = proto.params_count;
    zT_392 = proto.call_conv;
    zT_402 = zF_474336D7_typeRegistryGetOrCr(zT_384, zT_385, zT_386, (unsigned char)(0), (unsigned char)(0), zT_389, zT_390, (unsigned int)(1), zT_392);
    fn_ty = zT_402;
    zT_404 = "BR:ft";
    zT_406 = 5;
    zT_405.ptr = zT_404;
    zT_405.len = zT_406;
    bre4_m = zT_405;
    zT_407 = bre4_m;
    zT_408 = fn_ty;
    zF_C914CB83_markerWriteInt(zT_407, zT_408);
    zT_409 = self->type_table;
    zT_410 = node_idx;
    zT_411 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_409, zT_410, zT_411);
    return fn_ty;
    z_bb_50:
    rv = rtt.value;
    zT_282 = rv;
    goto z_bb_52;
    z_bb_51:
    zT_282 = 0;
    goto z_bb_52;
    z_bb_52:
    rtt_val = zT_282;
    zT_286 = "BR:rt";
    zT_288 = 5;
    zT_287.ptr = zT_286;
    zT_287.len = zT_288;
    bre2_m = zT_287;
    zT_289 = bre2_m;
    zT_290 = rtt_val;
    zF_C914CB83_markerWriteInt(zT_289, zT_290);
    zT_291 = rtt.has_value;
    if (zT_291) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    rtv = rtt.value;
    zT_294 = self->registry;
    zT_295 = proto.name_id;
    zT_296 = fs->module_id;
    zT_299 = proto.params_start;
    zT_300 = proto.params_count;
    zT_301 = rtv;
    zT_302 = proto.call_conv;
    zT_311 = zF_474336D7_typeRegistryGetOrCr(zT_294, zT_295, zT_296, (unsigned char)(0), (unsigned char)(0), zT_299, zT_300, zT_301, zT_302);
    fn_ty = zT_311;
    zT_312 = self->type_table;
    zT_313 = node_idx;
    zT_314 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_312, zT_313, zT_314);
    return fn_ty;
    z_bb_54:
    zT_318 = self->store;
    zT_317.store = zT_318;
    zT_319 = self->registry;
    zT_317.typereg = zT_319;
    zT_320 = self->symbols;
    zT_317.symbol_reg = zT_320;
    zT_321 = self->interner;
    zT_317.interner = zT_321;
    zT_322 = fs->module_id;
    zT_317.module_id = zT_322;
    zT_323 = self->diag;
    zT_324.has_value = 1;
    zT_324.value = zT_323;
    zT_317.diag = zT_324;
    zT_325.has_value = 0;
    zT_317.local_consts = zT_325;
    zT_326 = self->source_file_id;
    zT_317.source_file_id = zT_326;
    tre_env = zT_317;
    zT_328 = &tre_env;
    zT_329 = proto.return_type_node;
    zT_334 = zF_F2107C15_resolveTypeExprFull(zT_328, zT_329, (unsigned int)(0));
    resolved_rt = zT_334;
    zT_336 = "BR:treN";
    zT_338 = 7;
    zT_337.ptr = zT_336;
    zT_337.len = zT_338;
    brr1_m = zT_337;
    zT_339 = brr1_m;
    zT_340 = proto.return_type_node;
    zF_C914CB83_markerWriteInt(zT_339, zT_340);
    zT_343 = "BR:treT";
    zT_345 = 7;
    zT_344.ptr = zT_343;
    zT_344.len = zT_345;
    brr2_m = zT_344;
    zT_346 = brr2_m;
    zT_347 = resolved_rt;
    zF_C914CB83_markerWriteInt(zT_346, zT_347);
    if ((int)(resolved_rt != (unsigned int)(18))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_350 = self->type_table;
    zT_351 = proto.return_type_node;
    zT_352 = resolved_rt;
    zF_19B4A07D_resolvedTypeTableSe(zT_350, zT_351, zT_352);
    zT_356 = self->registry;
    zT_357 = proto.name_id;
    zT_358 = fs->module_id;
    zT_361 = proto.params_start;
    zT_362 = proto.params_count;
    zT_363 = resolved_rt;
    zT_364 = proto.call_conv;
    zT_373 = zF_474336D7_typeRegistryGetOrCr(zT_356, zT_357, zT_358, (unsigned char)(0), (unsigned char)(0), zT_361, zT_362, zT_363, zT_364);
    fn_ty = zT_373;
    zT_374 = self->type_table;
    zT_375 = node_idx;
    zT_376 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_374, zT_375, zT_376);
    return fn_ty;
    z_bb_56:
    goto z_bb_49;
    z_bb_57:
    zT_428 = base_node.span_start;
    uisp = zT_428;
    zT_430 = base_node.span_len;
    zT_432 = uisp + (unsigned int)((unsigned int)zT_430);
    uiep = zT_432;
    zT_434 = self->interner;
    zT_435 = base_ident_id;
    zT_437 = zF_9134020D_stringInternerGet(zT_434, zT_435);
    uinm = zT_437;
    zT_439 = "identifier '";
    zT_441 = 12;
    zT_440.ptr = zT_439;
    zT_440.len = zT_441;
    ui1 = zT_440;
    zT_443 = "' is not declared or imported in this module";
    zT_445 = 44;
    zT_444.ptr = zT_443;
    zT_444.len = zT_445;
    ui2 = zT_444;
    zT_448 = 0;
    zT_447[zT_448] = ui1;
    zT_449 = 1;
    zT_447[zT_449] = uinm;
    zT_450 = 2;
    zT_447[zT_450] = ui2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uiparts[_i] = zT_447[_i];
        _i++;
    }
}
    zT_452 = self->interner;
    zT_456 = 0;
    zT_457 = uiparts + zT_456;
    zT_453 = zT_457;
    zT_459 = zF_8C4BFF7C_diagnosticBuilderMa(zT_452, zT_453, (unsigned int)(3));
    uimsg = zT_459;
    zT_460 = self->diag;
    zT_463 = self->source_file_id;
    zT_464 = uisp;
    zT_465 = uiep;
    zT_466 = uimsg;
    zT_474 = zF_C82559AC_diagnosticCollector(zT_460, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3001_UNDEFINED_SYMBOL)), zT_463, zT_464, zT_465, zT_466);
    (void)zT_474;
    zT_475 = self->type_table;
    zT_476 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_475, zT_476, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_58:
    goto z_bb_5;
    z_bb_59:
    zT_487 = self->store;
    zT_488 = node.child_0;
    zT_491 = zF_8BA26B9E_astStoreNodePayload(zT_487, zT_488);
    path_id = zT_491;
    zT_493 = self->module_reg;
    zT_494 = path_id;
    zT_496 = zF_A258E183_moduleRegistryPathT(zT_493, zT_494);
    target = zT_496;
    zT_497 = target.has_value;
    if (zT_497) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_2;
    z_bb_61:
    mtid = target.value;
    zT_500 = self->symbols;
    zT_501 = mtid;
    zT_502 = field_name_id;
    zT_504 = zF_A398987E_symbolRegistryQuali(zT_500, zT_501, zT_502);
    field_sym = zT_504;
    zT_505 = field_sym.has_value;
    if (zT_505) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    fs = field_sym.value;
    zT_507 = fs->flags;
    if ((int)((unsigned short)(zT_507 & (unsigned short)(2)) != (unsigned short)(0))) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    zT_512 = fs->kind;
    if ((int)(zT_512 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_517 = self->type_table;
    zT_518 = node_idx;
    zT_519 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_517, zT_518, zT_519);
    zT_522 = fs->type_id;
    return zT_522;
    z_bb_68:
    zT_523 = fs->type_id;
    if ((int)(zT_523 != (unsigned int)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_526 = self->type_table;
    zT_527 = node_idx;
    zT_528 = fs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_526, zT_527, zT_528);
    zT_531 = fs->type_id;
    return zT_531;
    z_bb_70:
    goto z_bb_66;
    z_bb_71:
    zT_540 = "FB\n";
    zT_542 = 3;
    zT_541.ptr = zT_540;
    zT_541.len = zT_542;
    fa1 = zT_541;
    zT_543 = fa1;
    zF_48AC7B3A_markerWrite(zT_543);
    zT_544 = self->type_table;
    zT_545 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_544, zT_545, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_72:
    zT_551 = self->registry;
    zT_552 = zT_551->types_items;
    zT_553 = (unsigned int)base_type_id;
    zT_554 = zT_552[zT_553];
    base_ty = zT_554;
    zT_556 = 0;
    zT_557 = (unsigned int)zT_556;
    fields_start = zT_557;
    zT_559 = 0;
    zT_560 = (unsigned int)zT_559;
    fields_count = zT_560;
    zT_561 = base_ty.kind;
    if ((int)(zT_561 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_567 = base_ty.kind;
    zT_566 = zT_567 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_75;
    z_bb_74:
    zT_566 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_566) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_573 = base_ty.kind;
    pre_kind = zT_573;
    zT_574 = self->registry;
    zT_575 = zT_574->ptr_items;
    zT_576 = base_ty.payload_idx;
    zT_577 = (unsigned int)zT_576;
    zT_578 = zT_575[zT_577];
    zT_579 = zT_578.base;
    base_type_id = zT_579;
    zT_580 = self->registry;
    zT_581 = zT_580->types_items;
    zT_582 = (unsigned int)base_type_id;
    zT_583 = zT_581[zT_582];
    base_ty = zT_583;
    zT_585 = "FAPR:OK";
    zT_587 = 7;
    zT_586.ptr = zT_585;
    zT_586.len = zT_587;
    fapr_ok_m = zT_586;
    zT_588 = fapr_ok_m;
    zF_C914CB83_markerWriteInt(zT_588, (unsigned int)((unsigned int)pre_kind));
    zT_592 = "FAPR:DK";
    zT_594 = 7;
    zT_593.ptr = zT_592;
    zT_593.len = zT_594;
    fapr_dk_m = zT_593;
    zT_595 = fapr_dk_m;
    zT_597 = base_ty.kind;
    zF_C914CB83_markerWriteInt(zT_595, (unsigned int)((unsigned int)zT_597));
    zT_600 = "\n";
    zT_602 = 1;
    zT_601.ptr = zT_600;
    zT_601.len = zT_602;
    fapr_nl = zT_601;
    zT_603 = fapr_nl;
    zF_48AC7B3A_markerWrite(zT_603);
    goto z_bb_77;
    z_bb_77:
    zT_604 = base_ty.kind;
    if ((int)(zT_604 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_610 = node.span_start;
    sp = zT_610;
    zT_612 = node.span_len;
    zT_614 = sp + (unsigned int)((unsigned int)zT_612);
    ep_1 = zT_614;
    zT_616 = "cannot access field on optional type; use .? to unwrap first";
    zT_618 = 60;
    zT_617.ptr = zT_616;
    zT_617.len = zT_618;
    opt_msg = zT_617;
    zT_619 = self->diag;
    zT_622 = self->source_file_id;
    zT_623 = sp;
    zT_624 = ep_1;
    zT_625 = opt_msg;
    zT_630 = zF_C82559AC_diagnosticCollector(zT_619, (unsigned char)(0), (unsigned short)(3000), zT_622, zT_623, zT_624, zT_625);
    (void)zT_630;
    return (unsigned int)(1);
    z_bb_79:
    zT_632 = base_ty.kind;
    if ((int)(zT_632 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_638 = node.span_start;
    sp = zT_638;
    zT_640 = node.span_len;
    zT_642 = sp + (unsigned int)((unsigned int)zT_640);
    ep_2 = zT_642;
    zT_644 = "cannot access field on error-union type; handle the error first";
    zT_646 = 63;
    zT_645.ptr = zT_644;
    zT_645.len = zT_646;
    eu_msg = zT_645;
    zT_647 = self->diag;
    zT_650 = self->source_file_id;
    zT_651 = sp;
    zT_652 = ep_2;
    zT_653 = eu_msg;
    zT_658 = zF_C82559AC_diagnosticCollector(zT_647, (unsigned char)(0), (unsigned short)(3000), zT_650, zT_651, zT_652, zT_653);
    (void)zT_658;
    return (unsigned int)(1);
    z_bb_81:
    zT_660 = base_ty.kind;
    if ((int)(zT_660 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_82; else goto z_bb_84;
    z_bb_82:
    zT_666 = self->registry;
    zT_667 = zT_666->st_items;
    zT_668 = base_ty.payload_idx;
    zT_669 = (unsigned int)zT_668;
    zT_670 = zT_667[zT_669];
    sp_3 = zT_670;
    zT_671 = sp_3.fields_start;
    zT_672 = (unsigned int)zT_671;
    fields_start = zT_672;
    zT_673 = sp_3.fields_count;
    zT_674 = (unsigned int)zT_673;
    fields_count = zT_674;
    goto z_bb_83;
    z_bb_83:
    zT_1179 = 0;
    zT_1180 = (unsigned int)zT_1179;
    fi = zT_1180;
    goto z_bb_152;
    z_bb_84:
    zT_675 = base_ty.kind;
    if ((int)(zT_675 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_681 = base_ty.kind;
    zT_680 = zT_681 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_87;
    z_bb_86:
    zT_680 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_680) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    zT_687 = self->registry;
    zT_688 = zT_687->un_items;
    zT_689 = base_ty.payload_idx;
    zT_690 = (unsigned int)zT_689;
    zT_691 = zT_688[zT_690];
    up = zT_691;
    zT_692 = up.fields_start;
    zT_693 = (unsigned int)zT_692;
    fields_start = zT_693;
    zT_694 = up.fields_count;
    zT_695 = (unsigned int)zT_694;
    fields_count = zT_695;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_83;
    z_bb_90:
    zT_696 = base_ty.kind;
    if ((int)(zT_696 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_702 = self->registry;
    zT_703 = zT_702->tu_items;
    zT_704 = base_ty.payload_idx;
    zT_705 = (unsigned int)zT_704;
    zT_706 = zT_703[zT_705];
    tp = zT_706;
    zT_708 = "tag";
    zT_710 = 3;
    zT_709.ptr = zT_708;
    zT_709.len = zT_710;
    tag_s = zT_709;
    zT_712 = self->interner;
    zT_713 = tag_s;
    zT_715 = zF_50C274AF_stringInternerInter(zT_712, zT_713);
    tag_id = zT_715;
    if ((int)(field_name_id == tag_id)) goto z_bb_94; else goto z_bb_95;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_795 = base_ty.kind;
    if ((int)(zT_795 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_106; else goto z_bb_108;
    z_bb_94:
    zT_718 = "FT:TAG\n";
    zT_720 = 7;
    zT_719.ptr = zT_718;
    zT_719.len = zT_720;
    ft_m = zT_719;
    zT_721 = ft_m;
    zF_48AC7B3A_markerWrite(zT_721);
    zT_722 = self->type_table;
    zT_723 = node_idx;
    zT_724 = tp.tag_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_722, zT_723, zT_724);
    zT_727 = tp.tag_type;
    return zT_727;
    z_bb_95:
    zT_729 = "payload";
    zT_731 = 7;
    zT_730.ptr = zT_729;
    zT_730.len = zT_731;
    payload_s = zT_730;
    zT_733 = self->interner;
    zT_734 = payload_s;
    zT_736 = zF_50C274AF_stringInternerInter(zT_733, zT_734);
    payload_id = zT_736;
    if ((int)(field_name_id == payload_id)) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_739 = tp.fields_count;
    zT_740 = (unsigned int)zT_739;
    fpe_count = zT_740;
    zT_742 = 0;
    zT_743 = (unsigned int)zT_742;
    fpei = zT_743;
    goto z_bb_98;
    z_bb_97:
    zT_791 = tp.fields_start;
    zT_792 = (unsigned int)zT_791;
    fields_start = zT_792;
    zT_793 = tp.fields_count;
    zT_794 = (unsigned int)zT_793;
    fields_count = zT_794;
    goto z_bb_92;
    z_bb_98:
    if ((int)(fpei < fpe_count)) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_746 = self->registry;
    zT_747 = zT_746->fe_items;
    zT_748 = tp.fields_start;
    zT_750 = (unsigned int)((unsigned int)zT_748) + fpei;
    zT_751 = zT_747[zT_750];
    fpe = zT_751;
    zT_752 = fpe.type_id;
    if ((int)(zT_752 != (unsigned int)(1))) goto z_bb_102; else goto z_bb_103;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_789 = 1;
    zT_790 = fpei + zT_789;
    fpei = zT_790;
    goto z_bb_98;
    z_bb_102:
    zT_756 = fpe.type_id;
    payload_res = zT_756;
    zT_758 = self->registry;
    zT_759 = zT_758->types_items;
    zT_760 = (unsigned int)payload_res;
    zT_761 = zT_759[zT_760];
    payload_rt = zT_761;
    zT_762 = payload_rt.kind;
    if ((int)(zT_762 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_104; else goto z_bb_105;
    z_bb_103:
    goto z_bb_101;
    z_bb_104:
    zT_768 = self->registry;
    zT_769 = zT_768->array_items;
    zT_770 = payload_rt.payload_idx;
    zT_771 = (unsigned int)zT_770;
    zT_772 = zT_769[zT_771];
    zT_773 = zT_772.elem;
    payload_elem = zT_773;
    zT_774 = self->registry;
    zT_775 = payload_elem;
    zT_779 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_774, zT_775, (int)(0));
    payload_res = zT_779;
    goto z_bb_105;
    z_bb_105:
    zT_781 = "FP:PAYLOAD\n";
    zT_783 = 11;
    zT_782.ptr = zT_781;
    zT_782.len = zT_783;
    fpe_m = zT_782;
    zT_784 = fpe_m;
    zF_48AC7B3A_markerWrite(zT_784);
    zT_785 = self->type_table;
    zT_786 = node_idx;
    zT_787 = payload_res;
    zF_19B4A07D_resolvedTypeTableSe(zT_785, zT_786, zT_787);
    return payload_res;
    z_bb_106:
    zT_801 = "MFA\n";
    zT_803 = 4;
    zT_802.ptr = zT_801;
    zT_802.len = zT_803;
    mfa = zT_802;
    zT_804 = mfa;
    zF_48AC7B3A_markerWrite(zT_804);
    zT_806 = self->symbols;
    zT_807 = base_ty.module_id;
    zT_808 = field_name_id;
    zT_811 = zF_A398987E_symbolRegistryQuali(zT_806, zT_807, zT_808);
    mod_field_sym = zT_811;
    zT_812 = mod_field_sym.has_value;
    if (zT_812) goto z_bb_109; else goto z_bb_111;
    z_bb_107:
    goto z_bb_92;
    z_bb_108:
    zT_1011 = base_ty.kind;
    if ((int)(zT_1011 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_126; else goto z_bb_128;
    z_bb_109:
    mfs = mod_field_sym.value;
    zT_814 = mfs->type_id;
    if ((int)(zT_814 != (unsigned int)(0))) goto z_bb_112; else goto z_bb_113;
    z_bb_110:
    zT_1005 = self->type_table;
    zT_1006 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1005, zT_1006, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_111:
    zT_1001 = "MF3\n";
    zT_1003 = 4;
    zT_1002.ptr = zT_1001;
    zT_1002.len = zT_1003;
    mf3 = zT_1002;
    zT_1004 = mf3;
    zF_48AC7B3A_markerWrite(zT_1004);
    goto z_bb_110;
    z_bb_112:
    zT_818 = "MF1\n";
    zT_820 = 4;
    zT_819.ptr = zT_818;
    zT_819.len = zT_820;
    mf1 = zT_819;
    zT_821 = mf1;
    zF_48AC7B3A_markerWrite(zT_821);
    zT_822 = self->type_table;
    zT_823 = node_idx;
    zT_824 = mfs->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_822, zT_823, zT_824);
    zT_827 = mfs->type_id;
    return zT_827;
    z_bb_113:
    zT_828 = mfs->kind;
    if ((int)(zT_828 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_834 = self->type_table;
    zT_835 = mfs->decl_node;
    zT_838 = zF_999DCF51_resolvedTypeTableGe(zT_834, zT_835);
    fn_tid_opt = zT_838;
    zT_839 = fn_tid_opt.has_value;
    if (zT_839) goto z_bb_116; else goto z_bb_117;
    z_bb_115:
    zT_993 = "MF2";
    zT_995 = 3;
    zT_994.ptr = zT_993;
    zT_994.len = zT_995;
    mf2_m = zT_994;
    zT_996 = mf2_m;
    zT_998 = mfs->kind;
    zF_C914CB83_markerWriteInt(zT_996, (unsigned int)((unsigned int)zT_998));
    goto z_bb_110;
    z_bb_116:
    fn_tid = fn_tid_opt.value;
    zT_842 = "MF1\n";
    zT_844 = 4;
    zT_843.ptr = zT_842;
    zT_843.len = zT_844;
    mf1 = zT_843;
    zT_845 = mf1;
    zF_48AC7B3A_markerWrite(zT_845);
    zT_846 = self->type_table;
    zT_847 = node_idx;
    zT_848 = fn_tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_846, zT_847, zT_848);
    return fn_tid;
    z_bb_117:
    zT_851 = "MFF\n";
    zT_853 = 4;
    zT_852.ptr = zT_851;
    zT_852.len = zT_853;
    mff = zT_852;
    zT_854 = mff;
    zF_48AC7B3A_markerWrite(zT_854);
    zT_856 = self->store;
    zT_857 = mfs->decl_node;
    zT_860 = zF_FCDD1D35_astStoreNodeAt(zT_856, zT_857);
    dn = zT_860;
    zT_861 = dn.kind;
    if ((int)(zT_861 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_867 = self->store;
    zT_868 = zT_867->fn_protos;
    zT_869 = zT_868.items;
    zT_870 = self->store;
    zT_871 = mfs->decl_node;
    zT_874 = zF_8BA26B9E_astStoreNodePayload(zT_870, zT_871);
    zT_875 = (unsigned int)zT_874;
    zT_876 = zT_869[zT_875];
    proto = zT_876;
    zT_878 = "MFP";
    zT_880 = 3;
    zT_879.ptr = zT_878;
    zT_879.len = zT_880;
    mfp_m = zT_879;
    zT_881 = mfp_m;
    zT_883 = proto.params_start;
    zF_C914CB83_markerWriteInt(zT_881, (unsigned int)((unsigned int)zT_883));
    zT_885 = proto.return_type_node;
    if ((int)(zT_885 != (unsigned int)(0))) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    goto z_bb_115;
    z_bb_120:
    zT_889 = self->type_table;
    zT_890 = proto.return_type_node;
    zT_893 = zF_999DCF51_resolvedTypeTableGe(zT_889, zT_890);
    rtt = zT_893;
    zT_894 = rtt.has_value;
    if (zT_894) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_969 = self->registry;
    zT_970 = proto.name_id;
    zT_971 = mfs->module_id;
    zT_974 = proto.params_start;
    zT_975 = proto.params_count;
    zT_977 = proto.call_conv;
    zT_987 = zF_474336D7_typeRegistryGetOrCr(zT_969, zT_970, zT_971, (unsigned char)(0), (unsigned char)(0), zT_974, zT_975, (unsigned int)(1), zT_977);
    fn_ty = zT_987;
    zT_988 = self->type_table;
    zT_989 = node_idx;
    zT_990 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_988, zT_989, zT_990);
    return fn_ty;
    z_bb_122:
    rtv = rtt.value;
    zT_897 = self->registry;
    zT_898 = proto.name_id;
    zT_899 = mfs->module_id;
    zT_902 = proto.params_start;
    zT_903 = proto.params_count;
    zT_904 = rtv;
    zT_905 = proto.call_conv;
    zT_914 = zF_474336D7_typeRegistryGetOrCr(zT_897, zT_898, zT_899, (unsigned char)(0), (unsigned char)(0), zT_902, zT_903, zT_904, zT_905);
    fn_ty = zT_914;
    zT_915 = self->type_table;
    zT_916 = node_idx;
    zT_917 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_915, zT_916, zT_917);
    return fn_ty;
    z_bb_123:
    zT_921 = self->store;
    zT_920.store = zT_921;
    zT_922 = self->registry;
    zT_920.typereg = zT_922;
    zT_923 = self->symbols;
    zT_920.symbol_reg = zT_923;
    zT_924 = self->interner;
    zT_920.interner = zT_924;
    zT_925 = mfs->module_id;
    zT_920.module_id = zT_925;
    zT_926 = self->diag;
    zT_927.has_value = 1;
    zT_927.value = zT_926;
    zT_920.diag = zT_927;
    zT_928.has_value = 0;
    zT_920.local_consts = zT_928;
    zT_929 = self->source_file_id;
    zT_920.source_file_id = zT_929;
    tre_env_b = zT_920;
    zT_931 = &tre_env_b;
    zT_932 = proto.return_type_node;
    zT_937 = zF_F2107C15_resolveTypeExprFull(zT_931, zT_932, (unsigned int)(0));
    resolved_rt_b = zT_937;
    if ((int)(resolved_rt_b != (unsigned int)(18))) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    zT_940 = self->type_table;
    zT_941 = proto.return_type_node;
    zT_942 = resolved_rt_b;
    zF_19B4A07D_resolvedTypeTableSe(zT_940, zT_941, zT_942);
    zT_946 = self->registry;
    zT_947 = proto.name_id;
    zT_948 = mfs->module_id;
    zT_951 = proto.params_start;
    zT_952 = proto.params_count;
    zT_953 = resolved_rt_b;
    zT_954 = proto.call_conv;
    zT_963 = zF_474336D7_typeRegistryGetOrCr(zT_946, zT_947, zT_948, (unsigned char)(0), (unsigned char)(0), zT_951, zT_952, zT_953, zT_954);
    fn_ty = zT_963;
    zT_964 = self->type_table;
    zT_965 = node_idx;
    zT_966 = fn_ty;
    zF_19B4A07D_resolvedTypeTableSe(zT_964, zT_965, zT_966);
    return fn_ty;
    z_bb_125:
    goto z_bb_121;
    z_bb_126:
    zT_1017 = self->registry;
    zT_1018 = zT_1017->slice_items;
    zT_1019 = base_ty.payload_idx;
    zT_1020 = (unsigned int)zT_1019;
    zT_1021 = zT_1018[zT_1020];
    sp_4 = zT_1021;
    zT_1023 = "len";
    zT_1025 = 3;
    zT_1024.ptr = zT_1023;
    zT_1024.len = zT_1025;
    len_s = zT_1024;
    zT_1027 = self->interner;
    zT_1028 = len_s;
    zT_1030 = zF_50C274AF_stringInternerInter(zT_1027, zT_1028);
    len_id = zT_1030;
    if ((int)(field_name_id == len_id)) goto z_bb_129; else goto z_bb_130;
    z_bb_127:
    goto z_bb_107;
    z_bb_128:
    zT_1074 = base_ty.kind;
    if ((int)(zT_1074 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_133; else goto z_bb_135;
    z_bb_129:
    zT_1033 = "FSL:USIZE\n";
    zT_1035 = 10;
    zT_1034.ptr = zT_1033;
    zT_1034.len = zT_1035;
    fsl = zT_1034;
    zT_1036 = fsl;
    zF_48AC7B3A_markerWrite(zT_1036);
    zT_1037 = self->type_table;
    zT_1038 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1037, zT_1038, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_130:
    zT_1044 = "ptr";
    zT_1046 = 3;
    zT_1045.ptr = zT_1044;
    zT_1045.len = zT_1046;
    ptr_s = zT_1045;
    zT_1048 = self->interner;
    zT_1049 = ptr_s;
    zT_1051 = zF_50C274AF_stringInternerInter(zT_1048, zT_1049);
    ptr_id = zT_1051;
    if ((int)(field_name_id == ptr_id)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_1054 = self->registry;
    zT_1055 = sp_4.elem;
    zT_1059 = base_ty.flags;
    zT_1064 = zF_402D622A_typeRegistryGetOrCr(zT_1054, zT_1055, (int)((unsigned char)(zT_1059 & (unsigned char)(1)) != (unsigned char)(0)));
    pty = zT_1064;
    zT_1066 = "FSP:PTR\n";
    zT_1068 = 8;
    zT_1067.ptr = zT_1066;
    zT_1067.len = zT_1068;
    fsp = zT_1067;
    zT_1069 = fsp;
    zF_48AC7B3A_markerWrite(zT_1069);
    zT_1070 = self->type_table;
    zT_1071 = node_idx;
    zT_1072 = pty;
    zF_19B4A07D_resolvedTypeTableSe(zT_1070, zT_1071, zT_1072);
    return pty;
    z_bb_132:
    goto z_bb_127;
    z_bb_133:
    zT_1080 = "len";
    zT_1082 = 3;
    zT_1081.ptr = zT_1080;
    zT_1081.len = zT_1082;
    len_s = zT_1081;
    zT_1084 = self->interner;
    zT_1085 = len_s;
    zT_1087 = zF_50C274AF_stringInternerInter(zT_1084, zT_1085);
    len_id = zT_1087;
    if ((int)(field_name_id == len_id)) goto z_bb_136; else goto z_bb_137;
    z_bb_134:
    goto z_bb_127;
    z_bb_135:
    zT_1100 = base_ty.kind;
    if ((int)(zT_1100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_138; else goto z_bb_140;
    z_bb_136:
    zT_1090 = "FAA:USIZE\n";
    zT_1092 = 10;
    zT_1091.ptr = zT_1090;
    zT_1091.len = zT_1092;
    faa_m = zT_1091;
    zT_1093 = faa_m;
    zF_48AC7B3A_markerWrite(zT_1093);
    zT_1094 = self->type_table;
    zT_1095 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1094, zT_1095, (unsigned int)(13));
    return (unsigned int)(13);
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_1106 = self->registry;
    zT_1107 = base_type_id;
    zT_1108 = field_name_id;
    zT_1110 = zF_D2ECD176_typeRegistryErrorSe(zT_1106, zT_1107, zT_1108);
    es_mi2 = zT_1110;
    if ((int)(es_mi2 != (unsigned int)(4294967295u))) goto z_bb_141; else goto z_bb_142;
    z_bb_139:
    goto z_bb_134;
    z_bb_140:
    zT_1123 = base_ty.kind;
    if ((int)(zT_1123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_143; else goto z_bb_145;
    z_bb_141:
    zT_1113 = self->type_table;
    zT_1114 = node_idx;
    zT_1115 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1113, zT_1114, zT_1115);
    return base_type_id;
    z_bb_142:
    zT_1117 = self->type_table;
    zT_1118 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1117, zT_1118, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_143:
    zT_1129 = self->registry;
    zT_1130 = zT_1129->en_items;
    zT_1131 = base_ty.payload_idx;
    zT_1132 = (unsigned int)zT_1131;
    zT_1133 = zT_1130[zT_1132];
    ep3 = zT_1133;
    zT_1135 = ep3.members_start;
    zT_1136 = (unsigned int)zT_1135;
    estart3 = zT_1136;
    zT_1138 = ep3.members_count;
    zT_1139 = (unsigned int)zT_1138;
    ecount3 = zT_1139;
    zT_1141 = 0;
    zT_1142 = (unsigned int)zT_1141;
    ei3 = zT_1142;
    goto z_bb_146;
    goto z_bb_139;
    z_bb_145:
    zT_1168 = "FF\n";
    zT_1170 = 3;
    zT_1169.ptr = zT_1168;
    zT_1169.len = zT_1170;
    fnf = zT_1169;
    zT_1171 = fnf;
    zF_48AC7B3A_markerWrite(zT_1171);
    zT_1172 = self->type_table;
    zT_1173 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1172, zT_1173, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_146:
    if ((int)(ei3 < ecount3)) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_1144 = self->registry;
    zT_1145 = zT_1144->em_items;
    zT_1146 = estart3 + ei3;
    zT_1147 = zT_1145[zT_1146];
    zT_1148 = zT_1147.name_id;
    if ((int)(zT_1148 == field_name_id)) goto z_bb_150; else goto z_bb_151;
    z_bb_148:
    zT_1157 = "FF\n";
    zT_1159 = 3;
    zT_1158.ptr = zT_1157;
    zT_1158.len = zT_1159;
    fnf = zT_1158;
    zT_1160 = fnf;
    zF_48AC7B3A_markerWrite(zT_1160);
    zT_1161 = self->type_table;
    zT_1162 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1161, zT_1162, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_149:
    zT_1154 = 1;
    zT_1155 = ei3 + zT_1154;
    ei3 = zT_1155;
    goto z_bb_146;
    z_bb_150:
    zT_1150 = self->type_table;
    zT_1151 = node_idx;
    zT_1152 = base_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_1150, zT_1151, zT_1152);
    return base_type_id;
    z_bb_151:
    goto z_bb_149;
    z_bb_152:
    if ((int)(fi < fields_count)) goto z_bb_153; else goto z_bb_154;
    z_bb_153:
    zT_1183 = self->registry;
    zT_1184 = zT_1183->fe_items;
    zT_1185 = fields_start + fi;
    zT_1186 = zT_1184[zT_1185];
    fe = zT_1186;
    zT_1187 = fe.name_id;
    if ((int)(zT_1187 == field_name_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_154:
    zT_1228 = "NF\n";
    zT_1230 = 3;
    zT_1229.ptr = zT_1228;
    zT_1229.len = zT_1230;
    fnf2 = zT_1229;
    zT_1231 = fnf2;
    zF_48AC7B3A_markerWrite(zT_1231);
    zT_1233 = "FF2:N";
    zT_1235 = 5;
    zT_1234.ptr = zT_1233;
    zT_1234.len = zT_1235;
    ff2n_m = zT_1234;
    zT_1236 = ff2n_m;
    zT_1237 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1236, zT_1237);
    zT_1239 = "FF2:F";
    zT_1241 = 5;
    zT_1240.ptr = zT_1239;
    zT_1240.len = zT_1241;
    ff2f_m = zT_1240;
    zT_1242 = ff2f_m;
    zT_1243 = field_name_id;
    zF_C914CB83_markerWriteInt(zT_1242, zT_1243);
    zT_1245 = "FF2:B";
    zT_1247 = 5;
    zT_1246.ptr = zT_1245;
    zT_1246.len = zT_1247;
    ff2b_m = zT_1246;
    zT_1248 = ff2b_m;
    zT_1249 = base_type_id;
    zF_C914CB83_markerWriteInt(zT_1248, zT_1249);
    zT_1250 = self->type_table;
    zT_1251 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_1250, zT_1251, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_155:
    goto z_bb_152;
    z_bb_156:
    zT_1190 = fe.type_id;
    result = zT_1190;
    zT_1192 = self->registry;
    zT_1193 = zT_1192->types_items;
    zT_1194 = (unsigned int)result;
    zT_1195 = zT_1193[zT_1194];
    rt = zT_1195;
    zT_1196 = rt.kind;
    if ((int)(zT_1196 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    zT_1224 = 1;
    zT_1226 = fi + (unsigned int)((unsigned int)zT_1224);
    fi = zT_1226;
    goto z_bb_155;
    z_bb_158:
    zT_1202 = self->registry;
    zT_1203 = zT_1202->array_items;
    zT_1204 = rt.payload_idx;
    zT_1205 = (unsigned int)zT_1204;
    zT_1206 = zT_1203[zT_1205];
    zT_1207 = zT_1206.elem;
    elem = zT_1207;
    zT_1208 = self->registry;
    zT_1209 = elem;
    zT_1213 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1208, zT_1209, (int)(0));
    result = zT_1213;
    goto z_bb_159;
    z_bb_159:
    zT_1215 = "FF:R";
    zT_1217 = 4;
    zT_1216.ptr = zT_1215;
    zT_1216.len = zT_1217;
    ff_m = zT_1216;
    zT_1218 = ff_m;
    zT_1219 = result;
    zF_C914CB83_markerWriteInt(zT_1218, zT_1219);
    zT_1220 = self->type_table;
    zT_1221 = node_idx;
    zT_1222 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_1220, zT_1221, zT_1222);
    return result;
}

/* semanticAnalyzerPackedGateGrow */
void zF_151B0DD7_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_C6536882_EU_532 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->packed_gate_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_gate_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_gate_items = ndst;
    self->packed_gate_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->packed_gate_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_gate_items;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerPackedGateMark */
void zF_E3B2C29D_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->packed_gate_len;
    zT_3 = self->packed_gate_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_151B0DD7_semanticAnalyzerPac(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->packed_gate_items;
    zT_7 = self->packed_gate_len;
    zT_6[zT_7] = node_idx;
    zT_8 = self->packed_gate_len;
    self->packed_gate_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedGateSeen */
int zF_5BBD6EB3_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_12;
    unsigned int gi;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    gi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_gate_len;
    if ((int)(gi < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_gate_items;
    zT_8 = zT_7[gi];
    if ((int)(zT_8 == node_idx)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_12 = gi + (unsigned int)(1);
    gi = zT_12;
    goto z_bb_1;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    goto z_bb_4;
}

/* semanticAnalyzerPackedStructCacheGrow */
void zF_86D8CE03_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_C6536882_EU_532 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_C6536882_EU_532 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int* zT_58;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    unsigned char* raw2;
    unsigned int* ndst2;
    unsigned int ci2;
    zT_2 = self->packed_struct_cache_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_cache_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->packed_struct_cache_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->packed_struct_tids = ndst;
    zT_37 = self->expected_type_stack_alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_13; else goto z_bb_14;
    z_bb_9:
    zT_30 = self->packed_struct_cache_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->packed_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
    z_bb_13:
    pal_trap();
    z_bb_14:
    zT_46 = zT_44.data.payload;
    goto z_bb_15;
    z_bb_15:
    raw2 = zT_46;
    zT_49 = (unsigned int*)raw2;
    ndst2 = zT_49;
    zT_50 = self->packed_struct_cache_len;
    if ((int)(zT_50 > (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_54 = 0;
    zT_55 = (unsigned int)zT_54;
    ci2 = zT_55;
    goto z_bb_18;
    z_bb_17:
    self->packed_struct_decl_nodes = ndst2;
    self->packed_struct_cache_cap = new_cap;
    return;
    z_bb_18:
    zT_56 = self->packed_struct_cache_len;
    if ((int)(ci2 < zT_56)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_58 = self->packed_struct_decl_nodes;
    zT_59 = zT_58[ci2];
    ndst2[ci2] = zT_59;
    goto z_bb_21;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_61 = ci2 + (unsigned int)(1);
    ci2 = zT_61;
    goto z_bb_18;
}

/* semanticAnalyzerPackedStructCacheAppend */
void zF_2C47D4E0_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_38C12417_SemanticAnalyzer* zT_6;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_3 = self->packed_struct_cache_len;
    zT_4 = self->packed_struct_cache_cap;
    if ((int)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self;
    zF_86D8CE03_semanticAnalyzerPac(zT_6);
    goto z_bb_2;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = self->packed_struct_cache_len;
    zT_7[zT_8] = struct_tid;
    zT_9 = self->packed_struct_decl_nodes;
    zT_10 = self->packed_struct_cache_len;
    zT_9[zT_10] = decl_node;
    zT_11 = self->packed_struct_cache_len;
    self->packed_struct_cache_len = (unsigned int)(zT_11 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerCheckedStructTidsGrow */
void zF_055533B0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_3E40CD83_Sand* zT_11;
    zT_C6536882_EU_532 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->checked_struct_tids_cap;
    if ((int)(zT_2 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_7 = self->checked_struct_tids_cap;
    zT_5 = zT_7 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_5;
    zT_11 = self->expected_type_stack_alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw = zT_20;
    zT_23 = (unsigned int*)raw;
    ndst = zT_23;
    zT_24 = self->checked_struct_tids_len;
    if ((int)(zT_24 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ci = zT_29;
    goto z_bb_9;
    z_bb_8:
    self->checked_struct_tids = ndst;
    self->checked_struct_tids_cap = new_cap;
    return;
    z_bb_9:
    zT_30 = self->checked_struct_tids_len;
    if ((int)(ci < zT_30)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = self->checked_struct_tids;
    zT_33 = zT_32[ci];
    ndst[ci] = zT_33;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_35 = ci + (unsigned int)(1);
    ci = zT_35;
    goto z_bb_9;
}

/* semanticAnalyzerCheckedStructTidsAppend */
void zF_B5A1E8BB_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    unsigned int zT_2;
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_2 = self->checked_struct_tids_len;
    zT_3 = self->checked_struct_tids_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = self;
    zF_055533B0_semanticAnalyzerChe(zT_5);
    goto z_bb_2;
    z_bb_2:
    zT_6 = self->checked_struct_tids;
    zT_7 = self->checked_struct_tids_len;
    zT_6[zT_7] = struct_tid;
    zT_8 = self->checked_struct_tids_len;
    self->checked_struct_tids_len = (unsigned int)(zT_8 + (unsigned int)(1));
    return;
}

/* semanticAnalyzerPackedFieldTypeAllowed */
int zF_E42B9323_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, int allow_packed_struct_type) {
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_19;
    int zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    int zT_31;
    unsigned char zT_32;
    zT_33EF6BFB_TypeKind zT_38;
    zT_338B7C76_TypeRegistry* zT_43;
    unsigned int zT_44;
    int zT_46 = 0;
    zT_338B7C76_TypeRegistry* zT_50;
    unsigned int zT_51;
    unsigned int zT_53 = 0;
    int zT_56;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    zT_338B7C76_TypeRegistry* zT_62;
    unsigned int zT_63;
    int zT_65 = 0;
    zT_338B7C76_TypeRegistry* zT_69;
    unsigned int zT_70;
    int zT_72 = 0;
    zT_D155D06D_Type ty;
    unsigned int ebt;
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ty = zT_12;
    zT_13 = ty.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_19 = ty.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (int)(0);
    z_bb_6:
    if (allow_packed_struct_type) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = ty.kind;
    zT_25 = zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_9;
    z_bb_8:
    zT_25 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_25) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = ty.flags;
    zT_31 = (unsigned char)(zT_32 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_12;
    z_bb_11:
    zT_31 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_31) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(1);
    z_bb_14:
    zT_38 = ty.kind;
    if ((int)(zT_38 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_43 = self->registry;
    zT_44 = tid;
    zT_46 = zF_A3BA89EA_typeRegistryEnumHas(zT_43, zT_44);
    if ((int)(!zT_46)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_69 = self->registry;
    zT_70 = tid;
    zT_72 = zF_3290E9C4_typeRegistryIsInteg(zT_69, zT_70);
    return zT_72;
    z_bb_17:
    return (int)(0);
    z_bb_18:
    zT_50 = self->registry;
    zT_51 = tid;
    zT_53 = zF_014D7530_typeRegistryEnumBac(zT_50, zT_51);
    ebt = zT_53;
    if ((int)(ebt == (unsigned int)(18))) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_58 = self->registry;
    zT_59 = zT_58->types_len;
    zT_56 = (unsigned int)((unsigned int)ebt) >= zT_59;
    goto z_bb_21;
    z_bb_20:
    zT_56 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_56) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (int)(0);
    z_bb_23:
    zT_62 = self->registry;
    zT_63 = ebt;
    zT_65 = zF_B664AC19_typeRegistryIsUnsig(zT_62, zT_63);
    if ((int)(!zT_65)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (int)(0);
    z_bb_25:
    return (int)(1);
}

/* semanticAnalyzerGatePackedFields */
void zF_C26EF425_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_13;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    int zT_20 = 0;
    zT_38C12417_SemanticAnalyzer* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int* zT_38;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_47;
    unsigned char zT_49;
    unsigned char zT_51;
    zT_ABC1EBBE_TypeResolveEnv zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_3D7259E2_SymbolRegistry* zT_58;
    zT_D3EB6303_StringInterner* zT_59;
    zT_F85C5DED_DiagnosticCollector* zT_60;
    zT_7334F4FE_Opt_225 zT_61;
    zT_F6B96876_Opt_395 zT_62 = {0};
    unsigned int zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    unsigned int zT_66;
    unsigned int zT_70 = 0;
    int zT_73;
    unsigned char zT_76;
    zT_38C12417_SemanticAnalyzer* zT_77;
    unsigned int zT_78;
    int zT_81 = 0;
    zT_338B7C76_TypeRegistry* zT_82;
    unsigned int zT_83;
    unsigned char zT_85 = 0;
    unsigned char zT_88;
    unsigned char zT_89;
    unsigned int zT_93;
    unsigned int zT_95;
    unsigned int zT_97;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_F85C5DED_DiagnosticCollector* zT_104;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_115 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_F85C5DED_DiagnosticCollector* zT_120;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_131 = 0;
    unsigned int zT_133;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u pw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pg_msg;
    zT_4 = self->store;
    zT_5 = struct_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((int)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = node.flags;
    if ((int)((unsigned char)(zT_13 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = self;
    zT_19 = struct_node_idx;
    zT_20 = zF_5BBD6EB3_semanticAnalyzerPac(zT_18, zT_19);
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_21 = self;
    zT_22 = struct_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_21, zT_22);
    zT_24 = self->store;
    zT_25 = struct_node_idx;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    children = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = children.len;
    if ((int)(ci < zT_32)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self->store;
    zT_38 = children.ptr;
    zT_36 = zT_38[ci];
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    fd = zT_40;
    zT_41 = fd.kind;
    if ((int)(zT_41 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_133 = ci + (unsigned int)(1);
    ci = zT_133;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_47 = fd.child_0;
    type_node = zT_47;
    zT_49 = 0;
    gate_state = zT_49;
    zT_51 = 0;
    gate_wide = zT_51;
    if ((int)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_56 = self->store;
    zT_55.store = zT_56;
    zT_57 = self->registry;
    zT_55.typereg = zT_57;
    zT_58 = self->symbols;
    zT_55.symbol_reg = zT_58;
    zT_59 = self->interner;
    zT_55.interner = zT_59;
    zT_55.module_id = module_id;
    zT_60 = self->diag;
    zT_61.has_value = 1;
    zT_61.value = zT_60;
    zT_55.diag = zT_61;
    zT_62.has_value = 0;
    zT_55.local_consts = zT_62;
    zT_63 = self->source_file_id;
    zT_55.source_file_id = zT_63;
    tre_env = zT_55;
    zT_65 = &tre_env;
    zT_66 = type_node;
    zT_70 = zF_F2107C15_resolveTypeExprFull(zT_65, zT_66, (unsigned int)(0));
    ft = zT_70;
    if ((int)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((int)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_73 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_73 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_73) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_76 = 1;
    gate_state = zT_76;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_77 = self;
    zT_78 = ft;
    zT_81 = zF_E42B9323_semanticAnalyzerPac(zT_77, zT_78, (int)(1));
    if (zT_81) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_82 = self->registry;
    zT_83 = ft;
    zT_85 = zF_655972D5_typeRegistryIntWidt(zT_82, zT_83);
    if ((int)(zT_85 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_88 = 1;
    gate_wide = zT_88;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_89 = 1;
    gate_state = zT_89;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_93 = fd.span_start;
    fsp = zT_93;
    zT_95 = fd.span_len;
    zT_97 = fsp + (unsigned int)((unsigned int)zT_95);
    fep = zT_97;
    if ((int)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_101 = "packed struct field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_103 = 95;
    zT_102.ptr = zT_101;
    zT_102.len = zT_103;
    pw_msg = zT_102;
    zT_104 = self->diag;
    zT_107 = self->source_file_id;
    zT_108 = fsp;
    zT_109 = fep;
    zT_110 = pw_msg;
    zT_115 = zF_C82559AC_diagnosticCollector(zT_104, (unsigned char)(0), (unsigned short)(3000), zT_107, zT_108, zT_109, zT_110);
    (void)zT_115;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_117 = "packed struct fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed struct";
    zT_119 = 111;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    pg_msg = zT_118;
    zT_120 = self->diag;
    zT_123 = self->source_file_id;
    zT_124 = fsp;
    zT_125 = fep;
    zT_126 = pg_msg;
    zT_131 = zF_C82559AC_diagnosticCollector(zT_120, (unsigned char)(0), (unsigned short)(3000), zT_123, zT_124, zT_125, zT_126);
    (void)zT_131;
    goto z_bb_29;
}

/* semanticAnalyzerMaybeGateAliasDecl */
void zF_FC6E31C6_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned int zT_11;
    unsigned char zT_13;
    zT_8143F551_AstKind zT_14;
    zT_8143F551_AstKind zT_19;
    unsigned char zT_24;
    unsigned char zT_29;
    zT_8143F551_AstKind zT_30;
    int zT_35;
    unsigned int zT_36;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_44 = {0};
    zT_8143F551_AstKind zT_45;
    unsigned int zT_50;
    zT_8143F551_AstKind zT_51;
    int zT_56;
    unsigned char zT_57;
    unsigned int zT_62;
    unsigned char zT_63;
    zT_38C12417_SemanticAnalyzer* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_38C12417_SemanticAnalyzer* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = self->store;
    zT_7 = decl_node;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    dnode = zT_9;
    zT_11 = 0;
    target = zT_11;
    zT_13 = 0;
    is_union = zT_13;
    zT_14 = dnode.kind;
    if ((int)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_19 = dnode.kind;
    if ((int)(zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_24 = dnode.flags;
    if ((int)((unsigned char)(zT_24 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_30 = dnode.kind;
    if ((int)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_29 = 1;
    is_union = zT_29;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_36 = dnode.child_1;
    zT_35 = zT_36 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_35 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_35) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_40 = self->store;
    zT_41 = dnode.child_1;
    zT_44 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    inn = zT_44;
    zT_45 = inn.kind;
    if ((int)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_50 = dnode.child_1;
    target = zT_50;
    goto z_bb_17;
    z_bb_17:
    zT_51 = inn.kind;
    if ((int)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_57 = inn.flags;
    zT_56 = (unsigned char)(zT_57 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_56 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_56) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_62 = dnode.child_1;
    target = zT_62;
    zT_63 = 1;
    is_union = zT_63;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((int)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_68 = self;
    zT_69 = target;
    zT_70 = module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_68, zT_69, zT_70);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_71 = self;
    zT_72 = target;
    zT_73 = module_id;
    zF_F705063A_semanticAnalyzerGat(zT_71, zT_72, zT_73);
    goto z_bb_26;
}

/* semanticAnalyzerGateModulePackedDecl */
void zF_6A91A8CC_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned char zT_12;
    zT_8143F551_AstKind zT_13;
    zT_8143F551_AstKind zT_18;
    unsigned char zT_23;
    unsigned char zT_28;
    zT_8143F551_AstKind zT_29;
    int zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_39;
    unsigned int zT_40;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    unsigned int zT_49;
    zT_8143F551_AstKind zT_50;
    int zT_55;
    unsigned char zT_56;
    unsigned int zT_61;
    unsigned char zT_62;
    zT_38C12417_SemanticAnalyzer* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_38C12417_SemanticAnalyzer* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    unsigned char is_union;
    zT_22A7C88B_AstNode inn;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    target = zT_10;
    zT_12 = 0;
    is_union = zT_12;
    zT_13 = dnode.kind;
    if ((int)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    target = decl_node;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_5:
    zT_18 = dnode.kind;
    if ((int)(zT_18 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_23 = dnode.flags;
    if ((int)((unsigned char)(zT_23 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_29 = dnode.kind;
    if ((int)(zT_29 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    target = decl_node;
    zT_28 = 1;
    is_union = zT_28;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_35 = dnode.child_1;
    zT_34 = zT_35 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_34 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_34) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_39 = self->store;
    zT_40 = dnode.child_1;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_39, zT_40);
    inn = zT_43;
    zT_44 = inn.kind;
    if ((int)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_49 = dnode.child_1;
    target = zT_49;
    goto z_bb_17;
    z_bb_17:
    zT_50 = inn.kind;
    if ((int)(zT_50 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_56 = inn.flags;
    zT_55 = (unsigned char)(zT_56 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_20;
    z_bb_19:
    zT_55 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_55) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_61 = dnode.child_1;
    target = zT_61;
    zT_62 = 1;
    is_union = zT_62;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_15;
    z_bb_23:
    if ((int)(is_union == (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    return;
    z_bb_25:
    zT_67 = self;
    zT_68 = target;
    zT_69 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_67, zT_68, zT_69);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_71 = self;
    zT_72 = target;
    zT_73 = self->module_id;
    zF_F705063A_semanticAnalyzerGat(zT_71, zT_72, zT_73);
    goto z_bb_26;
}

/* semanticAnalyzerGatePackedUnionMembers */
void zF_F705063A_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int union_node_idx, unsigned int module_id) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_8143F551_AstKind zT_8;
    unsigned char zT_13;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    int zT_20 = 0;
    zT_38C12417_SemanticAnalyzer* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_27 = {0};
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int* zT_38;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_47;
    unsigned char zT_49;
    unsigned char zT_51;
    zT_ABC1EBBE_TypeResolveEnv zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    zT_3D7259E2_SymbolRegistry* zT_58;
    zT_D3EB6303_StringInterner* zT_59;
    zT_F85C5DED_DiagnosticCollector* zT_60;
    zT_7334F4FE_Opt_225 zT_61;
    zT_F6B96876_Opt_395 zT_62 = {0};
    unsigned int zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    unsigned int zT_66;
    unsigned int zT_70 = 0;
    int zT_73;
    unsigned char zT_76;
    zT_38C12417_SemanticAnalyzer* zT_77;
    unsigned int zT_78;
    int zT_81 = 0;
    zT_338B7C76_TypeRegistry* zT_82;
    unsigned int zT_83;
    unsigned char zT_85 = 0;
    unsigned char zT_88;
    unsigned char zT_89;
    unsigned int zT_93;
    unsigned int zT_95;
    unsigned int zT_97;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_F85C5DED_DiagnosticCollector* zT_104;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_115 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_F85C5DED_DiagnosticCollector* zT_120;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_126;
    unsigned int zT_131 = 0;
    unsigned int zT_133;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    unsigned int ci;
    zT_22A7C88B_AstNode fd;
    unsigned int type_node;
    unsigned char gate_state;
    unsigned char gate_wide;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int ft;
    unsigned int fsp;
    unsigned int fep;
    zT_8F083A69_Slice_zT_0B42B2F8_u puw_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u pgu_msg;
    zT_4 = self->store;
    zT_5 = union_node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.kind;
    if ((int)(zT_8 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = node.flags;
    if ((int)((unsigned char)(zT_13 & (unsigned char)(16)) == (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = self;
    zT_19 = union_node_idx;
    zT_20 = zF_5BBD6EB3_semanticAnalyzerPac(zT_18, zT_19);
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_21 = self;
    zT_22 = union_node_idx;
    zF_E3B2C29D_semanticAnalyzerPac(zT_21, zT_22);
    zT_24 = self->store;
    zT_25 = union_node_idx;
    zT_27 = zF_850FDF81_astStoreNodeExtraCh(zT_24, zT_25);
    children = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_7;
    z_bb_7:
    zT_32 = children.len;
    if ((int)(ci < zT_32)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self->store;
    zT_38 = children.ptr;
    zT_36 = zT_38[ci];
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_35, zT_36);
    fd = zT_40;
    zT_41 = fd.kind;
    if ((int)(zT_41 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_133 = ci + (unsigned int)(1);
    ci = zT_133;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_47 = fd.child_0;
    type_node = zT_47;
    zT_49 = 0;
    gate_state = zT_49;
    zT_51 = 0;
    gate_wide = zT_51;
    if ((int)(type_node != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_56 = self->store;
    zT_55.store = zT_56;
    zT_57 = self->registry;
    zT_55.typereg = zT_57;
    zT_58 = self->symbols;
    zT_55.symbol_reg = zT_58;
    zT_59 = self->interner;
    zT_55.interner = zT_59;
    zT_55.module_id = module_id;
    zT_60 = self->diag;
    zT_61.has_value = 1;
    zT_61.value = zT_60;
    zT_55.diag = zT_61;
    zT_62.has_value = 0;
    zT_55.local_consts = zT_62;
    zT_63 = self->source_file_id;
    zT_55.source_file_id = zT_63;
    tre_env = zT_55;
    zT_65 = &tre_env;
    zT_66 = type_node;
    zT_70 = zF_F2107C15_resolveTypeExprFull(zT_65, zT_66, (unsigned int)(0));
    ft = zT_70;
    if ((int)(ft == (unsigned int)(18))) goto z_bb_16; else goto z_bb_15;
    z_bb_14:
    if ((int)(gate_state == (unsigned char)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_15:
    zT_73 = ft == (unsigned int)(1);
    goto z_bb_17;
    z_bb_16:
    zT_73 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_73) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_76 = 1;
    gate_state = zT_76;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_77 = self;
    zT_78 = ft;
    zT_81 = zF_E42B9323_semanticAnalyzerPac(zT_77, zT_78, (int)(1));
    if (zT_81) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_82 = self->registry;
    zT_83 = ft;
    zT_85 = zF_655972D5_typeRegistryIntWidt(zT_82, zT_83);
    if ((int)(zT_85 > (unsigned char)(31))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_88 = 1;
    gate_wide = zT_88;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_89 = 1;
    gate_state = zT_89;
    goto z_bb_24;
    z_bb_26:
    goto z_bb_10;
    z_bb_27:
    zT_93 = fd.span_start;
    fsp = zT_93;
    zT_95 = fd.span_len;
    zT_97 = fsp + (unsigned int)((unsigned int)zT_95);
    fep = zT_97;
    if ((int)(gate_wide == (unsigned char)(1))) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_101 = "packed union field width must be <= 31 bits (u32/i64 etc. packed fields are not supported yet)";
    zT_103 = 94;
    zT_102.ptr = zT_101;
    zT_102.len = zT_103;
    puw_msg = zT_102;
    zT_104 = self->diag;
    zT_107 = self->source_file_id;
    zT_108 = fsp;
    zT_109 = fep;
    zT_110 = puw_msg;
    zT_115 = zF_C82559AC_diagnosticCollector(zT_104, (unsigned char)(0), (unsigned short)(3000), zT_107, zT_108, zT_109, zT_110);
    (void)zT_115;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_117 = "packed union fields must be bool or an integer type (uN/iN); this field type is not allowed in a packed union";
    zT_119 = 109;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    pgu_msg = zT_118;
    zT_120 = self->diag;
    zT_123 = self->source_file_id;
    zT_124 = fsp;
    zT_125 = fep;
    zT_126 = pgu_msg;
    zT_131 = zF_C82559AC_diagnosticCollector(zT_120, (unsigned char)(0), (unsigned short)(3000), zT_123, zT_124, zT_125, zT_126);
    (void)zT_131;
    goto z_bb_29;
}

/* semanticAnalyzerGateEnumModuleDecl */
void zF_4E74AE9D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_node) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    zT_8143F551_AstKind zT_15;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_8143F551_AstKind zT_26;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_40 = {0};
    zT_8143F551_AstKind zT_41;
    unsigned int zT_46;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    unsigned int zT_50 = 0;
    unsigned int zT_51;
    unsigned int zT_55;
    zT_79FAE712_u64 zT_60;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_79FAE712_u64 zT_62;
    zT_BAEE192E_Opt_10 zT_64 = {0};
    unsigned char zT_65;
    zT_38C12417_SemanticAnalyzer* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    unsigned int backing_node;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    unsigned int tid;
    if ((int)(decl_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->store;
    zT_6 = decl_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    dnode = zT_8;
    zT_10 = 0;
    enum_node = zT_10;
    zT_12 = 0;
    enum_name_id = zT_12;
    zT_14 = 0;
    backing_node = zT_14;
    zT_15 = dnode.kind;
    if ((int)(zT_15 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21 = dnode.child_1;
    zT_20 = zT_21 != (unsigned int)(0);
    goto z_bb_5;
    z_bb_4:
    zT_20 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_20) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    enum_node = decl_node;
    zT_24 = dnode.child_0;
    enum_name_id = zT_24;
    zT_25 = dnode.child_1;
    backing_node = zT_25;
    goto z_bb_7;
    z_bb_7:
    if ((int)(enum_node == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_8:
    zT_26 = dnode.kind;
    if ((int)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_32 = dnode.child_1;
    zT_31 = zT_32 != (unsigned int)(0);
    goto z_bb_11;
    z_bb_10:
    zT_31 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_31) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_36 = self->store;
    zT_37 = dnode.child_1;
    zT_40 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    inn = zT_40;
    zT_41 = inn.kind;
    if ((int)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    goto z_bb_7;
    z_bb_14:
    zT_46 = dnode.child_1;
    enum_node = zT_46;
    zT_47 = self->store;
    zT_48 = decl_node;
    zT_50 = zF_8BA26B9E_astStoreNodePayload(zT_47, zT_48);
    enum_name_id = zT_50;
    zT_51 = inn.child_0;
    backing_node = zT_51;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    return;
    z_bb_17:
    zT_55 = self->module_id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_55) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)enum_name_id);
    key = zT_60;
    zT_61 = self->registry;
    zT_62 = key;
    zT_64 = zF_0EB68360_nameCacheGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    tid = zT_64.value;
    zT_67 = self;
    zT_68 = tid;
    zT_69 = enum_node;
    zT_70 = backing_node;
    zF_5EF7F98D_semanticAnalyzerGat(zT_67, zT_68, zT_69, zT_70);
    goto z_bb_19;
    z_bb_19:
    return;
}

/* semanticAnalyzerGateEnumTypeDecl */
void zF_5EF7F98D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer* self, unsigned int tid, unsigned int enum_node, unsigned int backing_node) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_457ECFEE_EnumPayload* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_457ECFEE_EnumPayload zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_36 = {0};
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    zT_ABC1EBBE_TypeResolveEnv zT_44;
    zT_6B0A7D14_AstStore* zT_45;
    zT_338B7C76_TypeRegistry* zT_46;
    zT_3D7259E2_SymbolRegistry* zT_47;
    zT_D3EB6303_StringInterner* zT_48;
    unsigned int zT_49;
    zT_F85C5DED_DiagnosticCollector* zT_50;
    zT_7334F4FE_Opt_225 zT_51;
    zT_F6B96876_Opt_395 zT_52 = {0};
    unsigned int zT_53;
    zT_ABC1EBBE_TypeResolveEnv* zT_55;
    unsigned int zT_56;
    unsigned int zT_60 = 0;
    int zT_63;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_F85C5DED_DiagnosticCollector* zT_70;
    unsigned int zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_81 = 0;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_D155D06D_Type* zT_88;
    unsigned int zT_89;
    zT_D155D06D_Type zT_90;
    zT_33EF6BFB_TypeKind zT_91;
    unsigned char* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_99;
    zT_F85C5DED_DiagnosticCollector* zT_100;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_111 = 0;
    zT_338B7C76_TypeRegistry* zT_112;
    unsigned int zT_113;
    int zT_115 = 0;
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int zT_118;
    int zT_120 = 0;
    unsigned char* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    zT_F85C5DED_DiagnosticCollector* zT_125;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_136 = 0;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_F85C5DED_DiagnosticCollector* zT_141;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_152 = 0;
    zT_338B7C76_TypeRegistry* zT_154;
    unsigned int zT_155;
    unsigned char zT_157 = 0;
    unsigned int zT_158;
    zT_79FAE712_u64 zT_160;
    zT_79FAE712_u64 zT_167;
    zT_338B7C76_TypeRegistry* zT_169;
    zT_457ECFEE_EnumPayload* zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    zT_457ECFEE_EnumPayload zT_173;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned short zT_178;
    unsigned int zT_179;
    zT_6B0A7D14_AstStore* zT_181;
    unsigned int zT_182;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_184 = {0};
    unsigned int zT_186;
    int zT_188;
    unsigned int zT_189;
    zT_79FAE712_u64 zT_191;
    int zT_193;
    unsigned int zT_195;
    int zT_197;
    zT_6B0A7D14_AstStore* zT_200;
    unsigned int zT_201;
    unsigned int* zT_203;
    zT_22A7C88B_AstNode zT_205 = {0};
    zT_8143F551_AstKind zT_206;
    zT_338B7C76_TypeRegistry* zT_212;
    zT_D96DCDF2_EnumMember* zT_213;
    unsigned int zT_214;
    zT_D96DCDF2_EnumMember zT_215;
    zT_C69B2266_i64 zT_216;
    zT_79FAE712_u64 zT_218;
    unsigned int zT_221;
    unsigned int zT_223;
    unsigned int zT_225;
    unsigned char* zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    unsigned int zT_229;
    zT_F85C5DED_DiagnosticCollector* zT_230;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_241 = 0;
    int zT_242;
    int zT_244;
    unsigned int zT_245;
    unsigned int zT_249;
    unsigned int zT_251;
    unsigned int zT_253;
    unsigned char* zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    zT_F85C5DED_DiagnosticCollector* zT_258;
    unsigned int zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    unsigned int zT_269 = 0;
    int zT_270;
    unsigned int zT_272;
    unsigned int zT_274;
    zT_D155D06D_Type ety;
    unsigned int check_btid;
    zT_22A7C88B_AstNode bnode;
    unsigned int bsp;
    unsigned int bep;
    zT_ABC1EBBE_TypeResolveEnv tre_env2;
    unsigned int bt;
    unsigned int nbits;
    zT_79FAE712_u64 maxv;
    zT_8F083A69_Slice_zT_0B42B2F8_u bg_msg;
    zT_D155D06D_Type bty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bb_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bs_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u bi_msg;
    zT_457ECFEE_EnumPayload ep2;
    unsigned int mstart2;
    unsigned int mcount2;
    zT_3CB0179A_Slice_zT_05F374B1_u children2;
    unsigned int fcount2;
    unsigned int ci2;
    zT_79FAE712_u64 prev_vu;
    int have_prev;
    zT_22A7C88B_AstNode fd2;
    zT_C69B2266_i64 mv;
    zT_79FAE712_u64 mvu;
    unsigned int msp;
    unsigned int mep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mv_msg;
    zT_5 = self->registry;
    zT_6 = zT_5->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = self->registry;
    zT_10 = zT_9->types_items;
    zT_11 = (unsigned int)tid;
    zT_12 = zT_10[zT_11];
    ety = zT_12;
    zT_13 = ety.kind;
    if ((int)(zT_13 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = ety.payload_idx;
    zT_20 = self->registry;
    zT_21 = zT_20->en_len;
    if ((int)((unsigned int)((unsigned int)zT_18) >= zT_21)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_24 = self->registry;
    zT_25 = zT_24->en_items;
    zT_26 = ety.payload_idx;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_25[zT_27];
    zT_29 = zT_28.backing_type;
    check_btid = zT_29;
    if ((int)(backing_node != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_33 = self->store;
    zT_34 = backing_node;
    zT_36 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    bnode = zT_36;
    zT_38 = bnode.span_start;
    bsp = zT_38;
    zT_40 = bnode.span_len;
    zT_42 = bsp + (unsigned int)((unsigned int)zT_40);
    bep = zT_42;
    zT_45 = self->store;
    zT_44.store = zT_45;
    zT_46 = self->registry;
    zT_44.typereg = zT_46;
    zT_47 = self->symbols;
    zT_44.symbol_reg = zT_47;
    zT_48 = self->interner;
    zT_44.interner = zT_48;
    zT_49 = self->module_id;
    zT_44.module_id = zT_49;
    zT_50 = self->diag;
    zT_51.has_value = 1;
    zT_51.value = zT_50;
    zT_44.diag = zT_51;
    zT_52.has_value = 0;
    zT_44.local_consts = zT_52;
    zT_53 = self->source_file_id;
    zT_44.source_file_id = zT_53;
    tre_env2 = zT_44;
    zT_55 = &tre_env2;
    zT_56 = backing_node;
    zT_60 = zF_F2107C15_resolveTypeExprFull(zT_55, zT_56, (unsigned int)(0));
    bt = zT_60;
    if ((int)(bt == (unsigned int)(18))) goto z_bb_10; else goto z_bb_9;
    z_bb_8:
    zT_154 = self->registry;
    zT_155 = check_btid;
    zT_157 = zF_655972D5_typeRegistryIntWidt(zT_154, zT_155);
    zT_158 = (unsigned int)zT_157;
    nbits = zT_158;
    zT_160 = 18446744073709551615ULL;
    maxv = zT_160;
    if ((int)(nbits < (unsigned int)(64))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    zT_63 = bt == (unsigned int)(1);
    goto z_bb_11;
    z_bb_10:
    zT_63 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_63) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_67 = "invalid enum backing type; enum(uN) requires an unsigned integer type name (u1..u64)";
    zT_69 = 84;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    bg_msg = zT_68;
    zT_70 = self->diag;
    zT_73 = self->source_file_id;
    zT_74 = bsp;
    zT_75 = bep;
    zT_76 = bg_msg;
    zT_81 = zF_C82559AC_diagnosticCollector(zT_70, (unsigned char)(0), (unsigned short)(3000), zT_73, zT_74, zT_75, zT_76);
    (void)zT_81;
    return;
    z_bb_13:
    zT_83 = self->registry;
    zT_84 = zT_83->types_len;
    if ((int)((unsigned int)((unsigned int)bt) < zT_84)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_87 = self->registry;
    zT_88 = zT_87->types_items;
    zT_89 = (unsigned int)bt;
    zT_90 = zT_88[zT_89];
    bty = zT_90;
    zT_91 = bty.kind;
    if ((int)(zT_91 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_97 = "bool is not a valid enum backing; use an unsigned integer type (uN)";
    zT_99 = 67;
    zT_98.ptr = zT_97;
    zT_98.len = zT_99;
    bb_msg = zT_98;
    zT_100 = self->diag;
    zT_103 = self->source_file_id;
    zT_104 = bsp;
    zT_105 = bep;
    zT_106 = bb_msg;
    zT_111 = zF_C82559AC_diagnosticCollector(zT_100, (unsigned char)(0), (unsigned short)(3000), zT_103, zT_104, zT_105, zT_106);
    (void)zT_111;
    return;
    z_bb_17:
    zT_112 = self->registry;
    zT_113 = bt;
    zT_115 = zF_B664AC19_typeRegistryIsUnsig(zT_112, zT_113);
    if ((int)(!zT_115)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_117 = self->registry;
    zT_118 = bt;
    zT_120 = zF_01ED6537_typeRegistryIntIsSi(zT_117, zT_118);
    if (zT_120) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    check_btid = bt;
    goto z_bb_15;
    z_bb_20:
    zT_122 = "enum(iN) signed backings are not supported; use an unsigned backing (enum(uN))";
    zT_124 = 78;
    zT_123.ptr = zT_122;
    zT_123.len = zT_124;
    bs_msg = zT_123;
    zT_125 = self->diag;
    zT_128 = self->source_file_id;
    zT_129 = bsp;
    zT_130 = bep;
    zT_131 = bs_msg;
    zT_136 = zF_C82559AC_diagnosticCollector(zT_125, (unsigned char)(0), (unsigned short)(3000), zT_128, zT_129, zT_130, zT_131);
    (void)zT_136;
    goto z_bb_21;
    z_bb_21:
    return;
    z_bb_22:
    zT_138 = "invalid enum backing type; enum(uN) requires an unsigned integer type (uN)";
    zT_140 = 74;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    bi_msg = zT_139;
    zT_141 = self->diag;
    zT_144 = self->source_file_id;
    zT_145 = bsp;
    zT_146 = bep;
    zT_147 = bi_msg;
    zT_152 = zF_C82559AC_diagnosticCollector(zT_141, (unsigned char)(0), (unsigned short)(3000), zT_144, zT_145, zT_146, zT_147);
    (void)zT_152;
    goto z_bb_21;
    z_bb_23:
    zT_167 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)nbits)) - (zT_79FAE712_u64)(1);
    maxv = zT_167;
    goto z_bb_24;
    z_bb_24:
    zT_169 = self->registry;
    zT_170 = zT_169->en_items;
    zT_171 = ety.payload_idx;
    zT_172 = (unsigned int)zT_171;
    zT_173 = zT_170[zT_172];
    ep2 = zT_173;
    zT_175 = ep2.members_start;
    zT_176 = (unsigned int)zT_175;
    mstart2 = zT_176;
    zT_178 = ep2.members_count;
    zT_179 = (unsigned int)zT_178;
    mcount2 = zT_179;
    zT_181 = self->store;
    zT_182 = enum_node;
    zT_184 = zF_850FDF81_astStoreNodeExtraCh(zT_181, zT_182);
    children2 = zT_184;
    zT_186 = 0;
    fcount2 = zT_186;
    zT_188 = 0;
    zT_189 = (unsigned int)zT_188;
    ci2 = zT_189;
    zT_191 = 0;
    prev_vu = zT_191;
    zT_193 = 0;
    have_prev = zT_193;
    goto z_bb_25;
    z_bb_25:
    zT_195 = children2.len;
    if ((int)(ci2 < zT_195)) goto z_bb_29; else goto z_bb_30;
    z_bb_26:
    zT_200 = self->store;
    zT_203 = children2.ptr;
    zT_201 = zT_203[ci2];
    zT_205 = zF_FCDD1D35_astStoreNodeAt(zT_200, zT_201);
    fd2 = zT_205;
    zT_206 = fd2.kind;
    if ((int)(zT_206 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return;
    z_bb_28:
    zT_274 = ci2 + (unsigned int)(1);
    ci2 = zT_274;
    goto z_bb_25;
    z_bb_29:
    zT_197 = fcount2 < mcount2;
    goto z_bb_31;
    z_bb_30:
    zT_197 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_197) goto z_bb_26; else goto z_bb_27;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_212 = self->registry;
    zT_213 = zT_212->em_items;
    zT_214 = mstart2 + fcount2;
    zT_215 = zT_213[zT_214];
    zT_216 = zT_215.value;
    mv = zT_216;
    zT_218 = (zT_79FAE712_u64)mv;
    mvu = zT_218;
    if ((int)(mvu > maxv)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_221 = fd2.span_start;
    msp = zT_221;
    zT_223 = fd2.span_len;
    zT_225 = msp + (unsigned int)((unsigned int)zT_223);
    mep = zT_225;
    zT_227 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_229 = 91;
    zT_228.ptr = zT_227;
    zT_228.len = zT_229;
    mv_msg = zT_228;
    zT_230 = self->diag;
    zT_233 = self->source_file_id;
    zT_234 = msp;
    zT_235 = mep;
    zT_236 = mv_msg;
    zT_241 = zF_C82559AC_diagnosticCollector(zT_230, (unsigned char)(0), (unsigned short)(3000), zT_233, zT_234, zT_235, zT_236);
    (void)zT_241;
    return;
    z_bb_35:
    if (have_prev) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_242 = prev_vu == maxv;
    goto z_bb_38;
    z_bb_37:
    zT_242 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_242) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_245 = fd2.child_1;
    zT_244 = zT_245 == (unsigned int)(0);
    goto z_bb_41;
    z_bb_40:
    zT_244 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_244) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_249 = fd2.span_start;
    msp = zT_249;
    zT_251 = fd2.span_len;
    zT_253 = msp + (unsigned int)((unsigned int)zT_251);
    mep = zT_253;
    zT_255 = "enum tag value does not fit the enum backing width (must fit 2^N - 1); no silent truncation";
    zT_257 = 91;
    zT_256.ptr = zT_255;
    zT_256.len = zT_257;
    mv_msg = zT_256;
    zT_258 = self->diag;
    zT_261 = self->source_file_id;
    zT_262 = msp;
    zT_263 = mep;
    zT_264 = mv_msg;
    zT_269 = zF_C82559AC_diagnosticCollector(zT_258, (unsigned char)(0), (unsigned short)(3000), zT_261, zT_262, zT_263, zT_264);
    (void)zT_269;
    return;
    z_bb_43:
    prev_vu = mvu;
    zT_270 = 1;
    have_prev = zT_270;
    zT_272 = fcount2 + (unsigned int)(1);
    fcount2 = zT_272;
    goto z_bb_28;
}

/* semanticAnalyzerPackedStructDeclForType */
unsigned int zF_1BB4D489_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer* self, unsigned int struct_tid) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_42;
    unsigned int zT_43;
    zT_3D7259E2_SymbolRegistry* zT_44;
    unsigned int zT_45;
    zT_3D7259E2_SymbolRegistry* zT_48;
    zT_060CD1EB_SymbolTable* zT_49;
    zT_060CD1EB_SymbolTable zT_50;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_3A105EF1_Symbol* zT_57;
    zT_3A105EF1_Symbol zT_58;
    zT_3C598AEF_SymbolKind zT_59;
    unsigned int zT_64;
    int zT_66;
    unsigned int zT_67;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    zT_22A7C88B_AstNode zT_75 = {0};
    unsigned int zT_77;
    zT_8143F551_AstKind zT_78;
    unsigned int zT_83;
    zT_8143F551_AstKind zT_84;
    int zT_89;
    unsigned int zT_90;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_99;
    unsigned int zT_104;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_109;
    zT_22A7C88B_AstNode zT_111 = {0};
    unsigned char zT_112;
    zT_38C12417_SemanticAnalyzer* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned int zT_123;
    zT_38C12417_SemanticAnalyzer* zT_124;
    unsigned int zT_125;
    unsigned int hc;
    unsigned int cc;
    zT_D155D06D_Type sty;
    unsigned int ti;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_3A105EF1_Symbol s;
    zT_22A7C88B_AstNode dnode;
    unsigned int target;
    zT_22A7C88B_AstNode inn;
    zT_22A7C88B_AstNode tnode;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    hc = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->packed_struct_cache_len;
    if ((int)(hc < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->packed_struct_tids;
    zT_8 = zT_7[hc];
    if ((int)(zT_8 == struct_tid)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    cc = zT_16;
    goto z_bb_7;
    z_bb_4:
    zT_13 = hc + (unsigned int)(1);
    hc = zT_13;
    goto z_bb_1;
    z_bb_5:
    zT_10 = self->packed_struct_decl_nodes;
    zT_11 = zT_10[hc];
    return zT_11;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_17 = self->checked_struct_tids_len;
    if ((int)(cc < zT_17)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_19 = self->checked_struct_tids;
    zT_20 = zT_19[cc];
    if ((int)(zT_20 == struct_tid)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    zT_26 = self->registry;
    zT_27 = zT_26->types_len;
    if ((int)((unsigned int)((unsigned int)struct_tid) >= zT_27)) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_24 = cc + (unsigned int)(1);
    cc = zT_24;
    goto z_bb_7;
    z_bb_11:
    return (unsigned int)(0);
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    return (unsigned int)(0);
    z_bb_14:
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)struct_tid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_35 = sty.kind;
    if ((int)(zT_35 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned int)(0);
    z_bb_16:
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ti = zT_43;
    goto z_bb_17;
    z_bb_17:
    zT_44 = self->symbols;
    zT_45 = zT_44->tables_len;
    if ((int)(ti < zT_45)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_48 = self->symbols;
    zT_49 = zT_48->tables_items;
    zT_50 = zT_49[ti];
    table = zT_50;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    si = zT_53;
    goto z_bb_21;
    z_bb_19:
    zT_124 = self;
    zT_125 = struct_tid;
    zF_B5A1E8BB_semanticAnalyzerChe(zT_124, zT_125);
    return (unsigned int)(0);
    z_bb_20:
    zT_123 = ti + (unsigned int)(1);
    ti = zT_123;
    goto z_bb_17;
    z_bb_21:
    zT_54 = table.len;
    if ((int)(si < zT_54)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_57 = table.items;
    zT_58 = zT_57[si];
    s = zT_58;
    zT_59 = s.kind;
    if ((int)(zT_59 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_121 = si + (unsigned int)(1);
    si = zT_121;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_64 = s.type_id;
    if ((int)(zT_64 != struct_tid)) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_67 = s.decl_node;
    zT_66 = zT_67 == (unsigned int)(0);
    goto z_bb_29;
    z_bb_28:
    zT_66 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_66) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    goto z_bb_24;
    z_bb_31:
    zT_71 = self->store;
    zT_72 = s.decl_node;
    zT_75 = zF_FCDD1D35_astStoreNodeAt(zT_71, zT_72);
    dnode = zT_75;
    zT_77 = 0;
    target = zT_77;
    zT_78 = dnode.kind;
    if ((int)(zT_78 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_83 = s.decl_node;
    target = zT_83;
    goto z_bb_33;
    z_bb_33:
    if ((int)(target == (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_34:
    zT_84 = dnode.kind;
    if ((int)(zT_84 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_90 = dnode.child_1;
    zT_89 = zT_90 != (unsigned int)(0);
    goto z_bb_37;
    z_bb_36:
    zT_89 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_89) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_94 = self->store;
    zT_95 = dnode.child_1;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    inn = zT_98;
    zT_99 = inn.kind;
    if ((int)(zT_99 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_33;
    z_bb_40:
    zT_104 = dnode.child_1;
    target = zT_104;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    goto z_bb_24;
    z_bb_43:
    zT_108 = self->store;
    zT_109 = target;
    zT_111 = zF_FCDD1D35_astStoreNodeAt(zT_108, zT_109);
    tnode = zT_111;
    zT_112 = tnode.flags;
    if ((int)((unsigned char)(zT_112 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_117 = self;
    zT_118 = struct_tid;
    zT_119 = target;
    zF_2C47D4E0_semanticAnalyzerPac(zT_117, zT_118, zT_119);
    return target;
    z_bb_45:
    goto z_bb_24;
}

/* semanticAnalyzerResolveArithmetic */
unsigned int zF_44006DDD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    zT_38C12417_SemanticAnalyzer* zT_14;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    int zT_20;
    int zT_28;
    zT_338B7C76_TypeRegistry* zT_34;
    unsigned int zT_35;
    int zT_37 = 0;
    int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    int zT_42 = 0;
    zT_338B7C76_TypeRegistry* zT_44;
    unsigned int zT_45;
    int zT_47 = 0;
    int zT_48;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_53;
    int zT_55 = 0;
    int zT_56;
    zT_338B7C76_TypeRegistry* zT_57;
    unsigned int zT_58;
    int zT_60 = 0;
    int zT_61;
    int zT_66;
    zT_338B7C76_TypeRegistry* zT_67;
    unsigned int zT_68;
    int zT_70 = 0;
    int zT_71;
    int zT_74;
    int zT_79;
    int zT_80;
    int zT_84;
    zT_338B7C76_TypeRegistry* zT_85;
    unsigned int zT_86;
    int zT_88 = 0;
    int zT_91;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    int zT_95 = 0;
    zT_338B7C76_TypeRegistry* zT_96;
    unsigned int zT_97;
    int zT_99 = 0;
    int zT_101;
    zT_338B7C76_TypeRegistry* zT_102;
    unsigned int zT_103;
    int zT_105 = 0;
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int zT_110;
    int zT_112 = 0;
    int zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    unsigned int zT_115;
    int zT_117 = 0;
    zT_338B7C76_TypeRegistry* zT_119;
    unsigned int zT_120;
    unsigned char zT_122 = 0;
    zT_338B7C76_TypeRegistry* zT_124;
    unsigned int zT_125;
    unsigned char zT_127 = 0;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_D155D06D_Type* zT_131;
    unsigned int zT_132;
    zT_D155D06D_Type zT_133;
    unsigned int zT_134;
    zT_338B7C76_TypeRegistry* zT_136;
    zT_D155D06D_Type* zT_137;
    unsigned int zT_138;
    zT_D155D06D_Type zT_139;
    unsigned int zT_140;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    int lhs_ptr;
    int rhs_uint;
    int rhs_ptr;
    unsigned char lw;
    unsigned char rw;
    unsigned int ls;
    unsigned int rs;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    lhs = zT_12;
    zT_14 = self;
    zT_15 = node.child_1;
    zT_17 = zF_54F95822_semanticAnalyzerRes(zT_14, zT_15);
    rhs = zT_17;
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_20 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_20 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_20) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_28 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_8;
    z_bb_7:
    zT_28 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_28) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_34 = self->registry;
    zT_35 = lhs;
    zT_37 = zF_AD61DB1B_typeRegistryIsPoint(zT_34, zT_35);
    if (zT_37) goto z_bb_12; else goto z_bb_11;
    z_bb_10:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_39 = self->registry;
    zT_40 = lhs;
    zT_42 = zF_0F4CC580_typeRegistryIsSlice(zT_39, zT_40);
    zT_38 = zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 1;
    goto z_bb_13;
    z_bb_13:
    lhs_ptr = zT_38;
    zT_44 = self->registry;
    zT_45 = rhs;
    zT_47 = zF_B664AC19_typeRegistryIsUnsig(zT_44, zT_45);
    if (zT_47) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_48 = rhs == (unsigned int)(19);
    goto z_bb_16;
    z_bb_15:
    zT_48 = 1;
    goto z_bb_16;
    z_bb_16:
    rhs_uint = zT_48;
    zT_52 = self->registry;
    zT_53 = rhs;
    zT_55 = zF_AD61DB1B_typeRegistryIsPoint(zT_52, zT_53);
    if (zT_55) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_57 = self->registry;
    zT_58 = rhs;
    zT_60 = zF_0F4CC580_typeRegistryIsSlice(zT_57, zT_58);
    zT_56 = zT_60;
    goto z_bb_19;
    z_bb_18:
    zT_56 = 1;
    goto z_bb_19;
    z_bb_19:
    rhs_ptr = zT_56;
    if (lhs_ptr) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = rhs_uint;
    goto z_bb_22;
    z_bb_21:
    zT_61 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_61) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return lhs;
    z_bb_24:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_67 = self->registry;
    zT_68 = lhs;
    zT_70 = zF_B664AC19_typeRegistryIsUnsig(zT_67, zT_68);
    if (zT_70) goto z_bb_29; else goto z_bb_28;
    z_bb_26:
    zT_66 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_66) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_71 = lhs == (unsigned int)(19);
    goto z_bb_30;
    z_bb_29:
    zT_71 = 1;
    goto z_bb_30;
    z_bb_30:
    zT_66 = zT_71;
    goto z_bb_27;
    z_bb_31:
    zT_74 = rhs_ptr;
    goto z_bb_33;
    z_bb_32:
    zT_74 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_74) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return rhs;
    z_bb_35:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_79 = lhs_ptr;
    goto z_bb_38;
    z_bb_37:
    zT_79 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_79) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_80 = rhs_ptr;
    goto z_bb_41;
    z_bb_40:
    zT_80 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_80) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (unsigned int)(12);
    z_bb_43:
    goto z_bb_10;
    z_bb_44:
    zT_85 = self->registry;
    zT_86 = rhs;
    zT_88 = zF_3087E0A5_typeRegistryIsNumer(zT_85, zT_86);
    zT_84 = zT_88;
    goto z_bb_46;
    z_bb_45:
    zT_84 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_84) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return rhs;
    z_bb_48:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_92 = self->registry;
    zT_93 = lhs;
    zT_95 = zF_3087E0A5_typeRegistryIsNumer(zT_92, zT_93);
    zT_91 = zT_95;
    goto z_bb_51;
    z_bb_50:
    zT_91 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_91) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    return lhs;
    z_bb_53:
    zT_96 = self->registry;
    zT_97 = lhs;
    zT_99 = zF_3087E0A5_typeRegistryIsNumer(zT_96, zT_97);
    if ((int)(!zT_99)) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_102 = self->registry;
    zT_103 = rhs;
    zT_105 = zF_3087E0A5_typeRegistryIsNumer(zT_102, zT_103);
    zT_101 = !zT_105;
    goto z_bb_56;
    z_bb_55:
    zT_101 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_101) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (unsigned int)(1);
    z_bb_58:
    if ((int)(lhs == rhs)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return lhs;
    z_bb_60:
    zT_109 = self->registry;
    zT_110 = lhs;
    zT_112 = zF_3290E9C4_typeRegistryIsInteg(zT_109, zT_110);
    if (zT_112) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_114 = self->registry;
    zT_115 = rhs;
    zT_117 = zF_3290E9C4_typeRegistryIsInteg(zT_114, zT_115);
    zT_113 = zT_117;
    goto z_bb_63;
    z_bb_62:
    zT_113 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_113) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_119 = self->registry;
    zT_120 = lhs;
    zT_122 = zF_655972D5_typeRegistryIntWidt(zT_119, zT_120);
    lw = zT_122;
    zT_124 = self->registry;
    zT_125 = rhs;
    zT_127 = zF_655972D5_typeRegistryIntWidt(zT_124, zT_125);
    rw = zT_127;
    if ((int)(lw >= rw)) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    zT_130 = self->registry;
    zT_131 = zT_130->types_items;
    zT_132 = (unsigned int)lhs;
    zT_133 = zT_131[zT_132];
    zT_134 = zT_133.size;
    ls = zT_134;
    zT_136 = self->registry;
    zT_137 = zT_136->types_items;
    zT_138 = (unsigned int)rhs;
    zT_139 = zT_137[zT_138];
    zT_140 = zT_139.size;
    rs = zT_140;
    if ((int)(ls >= rs)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    return lhs;
    z_bb_67:
    return rhs;
    z_bb_68:
    return lhs;
    z_bb_69:
    return rhs;
}

/* semanticAnalyzerResolveBitwise */
unsigned int zF_733BCA9C_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    int zT_19;
    int zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    unsigned int zT_27;
    int zT_29 = 0;
    int zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    int zT_36 = 0;
    int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    int zT_42 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    lhs = zT_11;
    zT_13 = self;
    zT_14 = node.child_1;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    rhs = zT_16;
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_19 = rhs == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_19 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_26 = self->registry;
    zT_27 = rhs;
    zT_29 = zF_3290E9C4_typeRegistryIsInteg(zT_26, zT_27);
    zT_25 = zT_29;
    goto z_bb_8;
    z_bb_7:
    zT_25 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_25) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return rhs;
    z_bb_10:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->registry;
    zT_34 = lhs;
    zT_36 = zF_3290E9C4_typeRegistryIsInteg(zT_33, zT_34);
    zT_32 = zT_36;
    goto z_bb_13;
    z_bb_12:
    zT_32 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_32) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return lhs;
    z_bb_15:
    if ((int)(lhs != rhs)) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_39 = self->registry;
    zT_40 = lhs;
    zT_42 = zF_3290E9C4_typeRegistryIsInteg(zT_39, zT_40);
    zT_38 = !zT_42;
    goto z_bb_18;
    z_bb_17:
    zT_38 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_38) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned int)(1);
    z_bb_20:
    return lhs;
}

/* semanticAnalyzerResolveComparison */
unsigned int zF_EB621FF0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx, zT_8143F551_AstKind op_kind) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_24 = {0};
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_32;
    int zT_37;
    zT_8143F551_AstKind zT_38;
    unsigned char zT_43;
    zT_8143F551_AstKind zT_47;
    int zT_52;
    zT_8143F551_AstKind zT_53;
    unsigned char zT_58;
    int zT_63;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int zT_67;
    unsigned int zT_69 = 0;
    int zT_71;
    unsigned int zT_72;
    int zT_73;
    int zT_75;
    int zT_78;
    zT_338B7C76_TypeRegistry* zT_81;
    zT_D155D06D_Type* zT_82;
    unsigned int zT_83;
    zT_D155D06D_Type zT_84;
    zT_33EF6BFB_TypeKind zT_85;
    unsigned int zT_86;
    zT_8143F551_AstKind zT_87;
    int zT_92;
    int zT_97;
    zT_8143F551_AstKind zT_98;
    int zT_103;
    zT_38C12417_SemanticAnalyzer* zT_108;
    unsigned int zT_109;
    zT_38C12417_SemanticAnalyzer* zT_110;
    unsigned int zT_111;
    unsigned int zT_113 = 0;
    zT_38C12417_SemanticAnalyzer* zT_114;
    zT_38C12417_SemanticAnalyzer* zT_115;
    unsigned int zT_116;
    unsigned int zT_118 = 0;
    int zT_121;
    zT_38C12417_SemanticAnalyzer* zT_124;
    unsigned int zT_125;
    unsigned int zT_127 = 0;
    int zT_129;
    unsigned int zT_130;
    int zT_131;
    int zT_133;
    int zT_136;
    zT_338B7C76_TypeRegistry* zT_139;
    zT_D155D06D_Type* zT_140;
    unsigned int zT_141;
    zT_D155D06D_Type zT_142;
    zT_33EF6BFB_TypeKind zT_143;
    unsigned int zT_144;
    zT_8143F551_AstKind zT_145;
    int zT_150;
    int zT_155;
    zT_8143F551_AstKind zT_156;
    int zT_161;
    zT_38C12417_SemanticAnalyzer* zT_166;
    unsigned int zT_167;
    zT_38C12417_SemanticAnalyzer* zT_168;
    unsigned int zT_169;
    unsigned int zT_171 = 0;
    zT_38C12417_SemanticAnalyzer* zT_172;
    zT_38C12417_SemanticAnalyzer* zT_173;
    unsigned int zT_174;
    unsigned int zT_176 = 0;
    zT_38C12417_SemanticAnalyzer* zT_177;
    unsigned int zT_178;
    unsigned int zT_180 = 0;
    zT_38C12417_SemanticAnalyzer* zT_181;
    unsigned int zT_182;
    unsigned int zT_184 = 0;
    int zT_187;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    int zT_198;
    zT_338B7C76_TypeRegistry* zT_199;
    unsigned int zT_200;
    int zT_202 = 0;
    unsigned char* zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    int zT_211;
    zT_338B7C76_TypeRegistry* zT_212;
    unsigned int zT_213;
    int zT_215 = 0;
    unsigned char* zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned int zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    zT_338B7C76_TypeRegistry* zT_223;
    unsigned int zT_224;
    int zT_226 = 0;
    int zT_227;
    unsigned char* zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    int zT_239;
    zT_338B7C76_TypeRegistry* zT_244;
    unsigned int zT_245;
    int zT_247 = 0;
    int zT_248;
    zT_338B7C76_TypeRegistry* zT_252;
    unsigned int zT_253;
    int zT_255 = 0;
    int zT_256;
    zT_338B7C76_TypeRegistry* zT_260;
    unsigned int zT_261;
    int zT_263 = 0;
    int zT_264;
    zT_338B7C76_TypeRegistry* zT_265;
    unsigned int zT_266;
    int zT_268 = 0;
    unsigned char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned char* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    zT_338B7C76_TypeRegistry* zT_284;
    unsigned int zT_285;
    int zT_287 = 0;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    zT_338B7C76_TypeRegistry* zT_295;
    zT_D155D06D_Type* zT_296;
    unsigned int zT_297;
    zT_D155D06D_Type zT_298;
    zT_33EF6BFB_TypeKind zT_299;
    unsigned char* zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    unsigned char* zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    unsigned int zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_316;
    unsigned int zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    int zT_322;
    unsigned char* zT_323;
    unsigned int zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_326 = 0;
    unsigned int zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned char* zT_335;
    unsigned int zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    unsigned char* zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned int zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_344;
    unsigned int zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    int zT_350;
    unsigned char* zT_351;
    unsigned int zT_352;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_353;
    unsigned int zT_354 = 0;
    unsigned int zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    unsigned char* zT_363;
    unsigned int zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    unsigned char* zT_367;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    unsigned int zT_369;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_370;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_372;
    unsigned int zT_374;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    int zT_379;
    unsigned char* zT_380;
    unsigned int zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_382;
    unsigned int zT_383 = 0;
    unsigned int zT_387;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_388;
    unsigned char* zT_392;
    unsigned int zT_393;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_394;
    unsigned char* zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397;
    unsigned int zT_398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_399;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_22A7C88B_AstNode c0n;
    zT_22A7C88B_AstNode c1n;
    unsigned char c0_lit;
    unsigned char c1_lit;
    unsigned int peerk;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp0;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp2;
    int lhs_num;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp3;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp4;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_lb;
    unsigned int cpv_ll;
    unsigned int cpv_ls;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_rh;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_rb;
    unsigned int cpv_rl;
    unsigned int cpv_rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_ih;
    zT_5A26C2ED_Arr_unsigned_char_1 cpv_ib;
    unsigned int cpv_il;
    unsigned int cpv_is;
    zT_8F083A69_Slice_zT_0B42B2F8_u cpv_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp5;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp6;
    zT_33EF6BFB_TypeKind lk;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp7;
    zT_4 = "CPE";
    zT_6 = 3;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    cpe = zT_5;
    zT_7 = cpe;
    zF_48AC7B3A_markerWrite(zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    lhs = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    rhs = zT_18;
    zT_20 = self->store;
    zT_21 = node.child_0;
    zT_24 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    c0n = zT_24;
    zT_26 = self->store;
    zT_27 = node.child_1;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    c1n = zT_30;
    zT_32 = c0n.kind;
    if ((int)(zT_32 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_38 = c0n.kind;
    zT_37 = zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_3;
    z_bb_2:
    zT_37 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_37) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_43 = 1;
    goto z_bb_6;
    z_bb_5:
    zT_43 = 0;
    goto z_bb_6;
    z_bb_6:
    c0_lit = zT_43;
    zT_47 = c1n.kind;
    if ((int)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_53 = c1n.kind;
    zT_52 = zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_9;
    z_bb_8:
    zT_52 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_52) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_58 = 1;
    goto z_bb_12;
    z_bb_11:
    zT_58 = 0;
    goto z_bb_12;
    z_bb_12:
    c1_lit = zT_58;
    if ((int)(c0_lit == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_63 = c1_lit != (unsigned char)(0);
    goto z_bb_15;
    z_bb_14:
    zT_63 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_63) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_66 = self;
    zT_67 = node.child_0;
    zT_69 = zF_54F95822_semanticAnalyzerRes(zT_66, zT_67);
    lhs = zT_69;
    zT_71 = 0;
    zT_72 = (unsigned int)zT_71;
    peerk = zT_72;
    zT_73 = 0;
    if ((int)(lhs != (unsigned int)zT_73)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_66; else goto z_bb_65;
    z_bb_18:
    if ((int)(c0_lit != (unsigned char)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_19:
    zT_75 = lhs != (unsigned int)(1);
    goto z_bb_21;
    z_bb_20:
    zT_75 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_75) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_78 = lhs != (unsigned int)(18);
    goto z_bb_24;
    z_bb_23:
    zT_78 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_78) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_81 = self->registry;
    zT_82 = zT_81->types_items;
    zT_83 = (unsigned int)lhs;
    zT_84 = zT_82[zT_83];
    zT_85 = zT_84.kind;
    zT_86 = (unsigned int)zT_85;
    peerk = zT_86;
    goto z_bb_26;
    z_bb_26:
    zT_87 = c1n.kind;
    if ((int)(zT_87 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_92 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_29;
    z_bb_28:
    zT_92 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_92) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_98 = c1n.kind;
    if ((int)(zT_98 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_97 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_97) goto z_bb_36; else goto z_bb_38;
    z_bb_33:
    zT_103 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_35;
    z_bb_34:
    zT_103 = 0;
    goto z_bb_35;
    z_bb_35:
    zT_97 = zT_103;
    goto z_bb_32;
    z_bb_36:
    zT_108 = self;
    zT_109 = lhs;
    zF_9665A229_pushExpectedType(zT_108, zT_109);
    zT_110 = self;
    zT_111 = node.child_1;
    zT_113 = zF_54F95822_semanticAnalyzerRes(zT_110, zT_111);
    rhs = zT_113;
    zT_114 = self;
    zF_BC478E78_popExpectedType(zT_114);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_17;
    z_bb_38:
    zT_115 = self;
    zT_116 = node.child_1;
    zT_118 = zF_54F95822_semanticAnalyzerRes(zT_115, zT_116);
    rhs = zT_118;
    goto z_bb_37;
    z_bb_39:
    zT_121 = c1_lit == (unsigned char)(0);
    goto z_bb_41;
    z_bb_40:
    zT_121 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_121) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_124 = self;
    zT_125 = node.child_1;
    zT_127 = zF_54F95822_semanticAnalyzerRes(zT_124, zT_125);
    rhs = zT_127;
    zT_129 = 0;
    zT_130 = (unsigned int)zT_129;
    peerk = zT_130;
    zT_131 = 0;
    if ((int)(rhs != (unsigned int)zT_131)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_17;
    z_bb_44:
    zT_177 = self;
    zT_178 = node.child_0;
    zT_180 = zF_54F95822_semanticAnalyzerRes(zT_177, zT_178);
    lhs = zT_180;
    zT_181 = self;
    zT_182 = node.child_1;
    zT_184 = zF_54F95822_semanticAnalyzerRes(zT_181, zT_182);
    rhs = zT_184;
    goto z_bb_43;
    z_bb_45:
    zT_133 = rhs != (unsigned int)(1);
    goto z_bb_47;
    z_bb_46:
    zT_133 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_133) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_136 = rhs != (unsigned int)(18);
    goto z_bb_50;
    z_bb_49:
    zT_136 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_136) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_139 = self->registry;
    zT_140 = zT_139->types_items;
    zT_141 = (unsigned int)rhs;
    zT_142 = zT_140[zT_141];
    zT_143 = zT_142.kind;
    zT_144 = (unsigned int)zT_143;
    peerk = zT_144;
    goto z_bb_52;
    z_bb_52:
    zT_145 = c0n.kind;
    if ((int)(zT_145 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_150 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_55;
    z_bb_54:
    zT_150 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_150) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_156 = c0n.kind;
    if ((int)(zT_156 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_155 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_155) goto z_bb_62; else goto z_bb_64;
    z_bb_59:
    zT_161 = peerk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_61;
    z_bb_60:
    zT_161 = 0;
    goto z_bb_61;
    z_bb_61:
    zT_155 = zT_161;
    goto z_bb_58;
    z_bb_62:
    zT_166 = self;
    zT_167 = rhs;
    zF_9665A229_pushExpectedType(zT_166, zT_167);
    zT_168 = self;
    zT_169 = node.child_0;
    zT_171 = zF_54F95822_semanticAnalyzerRes(zT_168, zT_169);
    lhs = zT_171;
    zT_172 = self;
    zF_BC478E78_popExpectedType(zT_172);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_43;
    z_bb_64:
    zT_173 = self;
    zT_174 = node.child_0;
    zT_176 = zF_54F95822_semanticAnalyzerRes(zT_173, zT_174);
    lhs = zT_176;
    goto z_bb_63;
    z_bb_65:
    zT_187 = rhs == (unsigned int)(0);
    goto z_bb_67;
    z_bb_66:
    zT_187 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_187) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_191 = "CP0";
    zT_193 = 3;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    cp0 = zT_192;
    zT_194 = cp0;
    zF_48AC7B3A_markerWrite(zT_194);
    return (unsigned int)(1);
    z_bb_69:
    if ((int)(lhs == (unsigned int)(19))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_199 = self->registry;
    zT_200 = rhs;
    zT_202 = zF_3087E0A5_typeRegistryIsNumer(zT_199, zT_200);
    zT_198 = zT_202;
    goto z_bb_72;
    z_bb_71:
    zT_198 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_198) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_204 = "CPB";
    zT_206 = 3;
    zT_205.ptr = zT_204;
    zT_205.len = zT_206;
    cp1 = zT_205;
    zT_207 = cp1;
    zF_48AC7B3A_markerWrite(zT_207);
    return (unsigned int)(2);
    z_bb_74:
    if ((int)(rhs == (unsigned int)(19))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_212 = self->registry;
    zT_213 = lhs;
    zT_215 = zF_3087E0A5_typeRegistryIsNumer(zT_212, zT_213);
    zT_211 = zT_215;
    goto z_bb_77;
    z_bb_76:
    zT_211 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_211) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_217 = "CPB";
    zT_219 = 3;
    zT_218.ptr = zT_217;
    zT_218.len = zT_219;
    cp2 = zT_218;
    zT_220 = cp2;
    zF_48AC7B3A_markerWrite(zT_220);
    return (unsigned int)(2);
    z_bb_79:
    zT_223 = self->registry;
    zT_224 = lhs;
    zT_226 = zF_3087E0A5_typeRegistryIsNumer(zT_223, zT_224);
    lhs_num = zT_226;
    if (lhs_num) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_227 = lhs == rhs;
    goto z_bb_82;
    z_bb_81:
    zT_227 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_227) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_230 = "CPB";
    zT_232 = 3;
    zT_231.ptr = zT_230;
    zT_231.len = zT_232;
    cp3 = zT_231;
    zT_233 = cp3;
    zF_48AC7B3A_markerWrite(zT_233);
    return (unsigned int)(2);
    z_bb_84:
    if ((int)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_239 = op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_87;
    z_bb_86:
    zT_239 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_239) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_244 = self->registry;
    zT_245 = lhs;
    zT_247 = zF_DA6AF452_typeRegistryIsOptio(zT_244, zT_245);
    if (zT_247) goto z_bb_90; else goto z_bb_91;
    z_bb_89:
    if ((int)(lhs == rhs)) goto z_bb_105; else goto z_bb_106;
    z_bb_90:
    zT_248 = rhs == (unsigned int)(17);
    goto z_bb_92;
    z_bb_91:
    zT_248 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_248) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned int)(2);
    z_bb_94:
    zT_252 = self->registry;
    zT_253 = rhs;
    zT_255 = zF_DA6AF452_typeRegistryIsOptio(zT_252, zT_253);
    if (zT_255) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_256 = lhs == (unsigned int)(17);
    goto z_bb_97;
    z_bb_96:
    zT_256 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_256) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    return (unsigned int)(2);
    z_bb_99:
    zT_260 = self->registry;
    zT_261 = lhs;
    zT_263 = zF_B8767394_typeRegistryIsError(zT_260, zT_261);
    if (zT_263) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_265 = self->registry;
    zT_266 = rhs;
    zT_268 = zF_B8767394_typeRegistryIsError(zT_265, zT_266);
    zT_264 = zT_268;
    goto z_bb_102;
    z_bb_101:
    zT_264 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_264) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_270 = "CPB";
    zT_272 = 3;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    cp4 = zT_271;
    zT_273 = cp4;
    zF_48AC7B3A_markerWrite(zT_273);
    return (unsigned int)(2);
    z_bb_104:
    goto z_bb_89;
    z_bb_105:
    if ((int)(lhs == (unsigned int)(2))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_311 = "CPVl";
    zT_313 = 4;
    zT_312.ptr = zT_311;
    zT_312.len = zT_313;
    cpv = zT_312;
    zT_314 = cpv;
    zF_48AC7B3A_markerWrite(zT_314);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_316[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_lb[_i] = zT_316[_i];
        _i++;
    }
}
    zT_318 = lhs;
    zT_322 = 0;
    zT_323 = (unsigned char*)((unsigned char*)cpv_lb) + zT_322;
    zT_324 = (unsigned int)(10) - zT_322;
    zT_325.ptr = zT_323;
    zT_325.len = zT_324;
    zT_319 = zT_325;
    zT_326 = zF_A7504564_itoa(zT_318, zT_319);
    cpv_ll = zT_326;
    zT_330 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_ll);
    cpv_ls = zT_330;
    zT_335 = (unsigned char*)((unsigned char*)cpv_lb) + cpv_ls;
    zT_336 = (unsigned int)(9) - cpv_ls;
    zT_337.ptr = zT_335;
    zT_337.len = zT_336;
    zT_331 = zT_337;
    zF_48AC7B3A_markerWrite(zT_331);
    zT_339 = "r";
    zT_341 = 1;
    zT_340.ptr = zT_339;
    zT_340.len = zT_341;
    cpv_rh = zT_340;
    zT_342 = cpv_rh;
    zF_48AC7B3A_markerWrite(zT_342);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_344[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_rb[_i] = zT_344[_i];
        _i++;
    }
}
    zT_346 = rhs;
    zT_350 = 0;
    zT_351 = (unsigned char*)((unsigned char*)cpv_rb) + zT_350;
    zT_352 = (unsigned int)(10) - zT_350;
    zT_353.ptr = zT_351;
    zT_353.len = zT_352;
    zT_347 = zT_353;
    zT_354 = zF_A7504564_itoa(zT_346, zT_347);
    cpv_rl = zT_354;
    zT_358 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_rl);
    cpv_rs = zT_358;
    zT_363 = (unsigned char*)((unsigned char*)cpv_rb) + cpv_rs;
    zT_364 = (unsigned int)(9) - cpv_rs;
    zT_365.ptr = zT_363;
    zT_365.len = zT_364;
    zT_359 = zT_365;
    zF_48AC7B3A_markerWrite(zT_359);
    zT_367 = "n";
    zT_369 = 1;
    zT_368.ptr = zT_367;
    zT_368.len = zT_369;
    cpv_ih = zT_368;
    zT_370 = cpv_ih;
    zF_48AC7B3A_markerWrite(zT_370);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_372[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        cpv_ib[_i] = zT_372[_i];
        _i++;
    }
}
    zT_374 = node.child_0;
    zT_379 = 0;
    zT_380 = (unsigned char*)((unsigned char*)cpv_ib) + zT_379;
    zT_381 = (unsigned int)(10) - zT_379;
    zT_382.ptr = zT_380;
    zT_382.len = zT_381;
    zT_375 = zT_382;
    zT_383 = zF_A7504564_itoa(zT_374, zT_375);
    cpv_il = zT_383;
    zT_387 = (unsigned int)(9) - (unsigned int)((unsigned int)cpv_il);
    cpv_is = zT_387;
    zT_392 = (unsigned char*)((unsigned char*)cpv_ib) + cpv_is;
    zT_393 = (unsigned int)(9) - cpv_is;
    zT_394.ptr = zT_392;
    zT_394.len = zT_393;
    zT_388 = zT_394;
    zF_48AC7B3A_markerWrite(zT_388);
    zT_396 = "\n";
    zT_398 = 1;
    zT_397.ptr = zT_396;
    zT_397.len = zT_398;
    cpv_nl = zT_397;
    zT_399 = cpv_nl;
    zF_48AC7B3A_markerWrite(zT_399);
    return (unsigned int)(1);
    z_bb_107:
    zT_279 = "CPB";
    zT_281 = 3;
    zT_280.ptr = zT_279;
    zT_280.len = zT_281;
    cp5 = zT_280;
    zT_282 = cp5;
    zF_48AC7B3A_markerWrite(zT_282);
    return (unsigned int)(2);
    z_bb_108:
    zT_284 = self->registry;
    zT_285 = lhs;
    zT_287 = zF_AD61DB1B_typeRegistryIsPoint(zT_284, zT_285);
    if (zT_287) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_289 = "CPB";
    zT_291 = 3;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    cp6 = zT_290;
    zT_292 = cp6;
    zF_48AC7B3A_markerWrite(zT_292);
    return (unsigned int)(2);
    z_bb_110:
    zT_295 = self->registry;
    zT_296 = zT_295->types_items;
    zT_297 = (unsigned int)lhs;
    zT_298 = zT_296[zT_297];
    zT_299 = zT_298.kind;
    lk = zT_299;
    if ((int)(lk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_305 = "CPB";
    zT_307 = 3;
    zT_306.ptr = zT_305;
    zT_306.len = zT_307;
    cp7 = zT_306;
    zT_308 = cp7;
    zF_48AC7B3A_markerWrite(zT_308);
    return (unsigned int)(2);
    z_bb_112:
    goto z_bb_106;
}

/* semanticAnalyzerResolveLogical */
unsigned int zF_6F2B8B98_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    int zT_24;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u loe;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo1;
    zT_8F083A69_Slice_zT_0B42B2F8_u lo2;
    zT_3 = "LOE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    loe = zT_4;
    zT_6 = loe;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_18 = self;
    zT_19 = node.child_1;
    zT_21 = zF_54F95822_semanticAnalyzerRes(zT_18, zT_19);
    rhs = zT_21;
    if ((int)(lhs == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_24 = rhs == (unsigned int)(2);
    goto z_bb_3;
    z_bb_2:
    zT_24 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_24) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_28 = "LOB";
    zT_30 = 3;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    lo1 = zT_29;
    zT_31 = lo1;
    zF_48AC7B3A_markerWrite(zT_31);
    return (unsigned int)(2);
    z_bb_5:
    zT_34 = "LOV";
    zT_36 = 3;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    lo2 = zT_35;
    zT_37 = lo2;
    zF_48AC7B3A_markerWrite(zT_37);
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveNegate */
unsigned int zF_09421FDF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    int zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((int)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3087E0A5_typeRegistryIsNumer(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveBitNot */
unsigned int zF_6B59E8AD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    int zT_21 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(1);
    z_bb_2:
    if ((int)(inner == (unsigned int)(19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(19);
    z_bb_4:
    zT_18 = self->registry;
    zT_19 = inner;
    zT_21 = zF_3290E9C4_typeRegistryIsInteg(zT_18, zT_19);
    if (zT_21) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return inner;
    z_bb_6:
    return (unsigned int)(1);
}

/* semanticAnalyzerVolatileDrop */
int zF_57090266_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    int zT_5;
    int zT_11;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    unsigned char zT_37;
    zT_33EF6BFB_TypeKind zT_43;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_112BF819_PtrPayload* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_112BF819_PtrPayload zT_53;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_338B7C76_TypeRegistry* zT_58;
    unsigned int zT_59;
    zT_338B7C76_TypeRegistry* zT_62;
    zT_D155D06D_Type* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_D155D06D_Type zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_E834303C_ArrayPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_E834303C_ArrayPayload zT_76;
    unsigned int zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_112BF819_PtrPayload* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_112BF819_PtrPayload zT_88;
    unsigned char zT_89;
    unsigned int zT_95;
    unsigned int zT_96;
    int zT_98;
    unsigned int zT_99;
    zT_33EF6BFB_TypeKind zT_102;
    zT_338B7C76_TypeRegistry* zT_108;
    zT_112BF819_PtrPayload* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_112BF819_PtrPayload zT_112;
    unsigned char zT_113;
    unsigned int zT_119;
    zT_33EF6BFB_TypeKind zT_121;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_0BB2A741_SlicePayload* zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    zT_0BB2A741_SlicePayload zT_131;
    unsigned char zT_132;
    unsigned int zT_138;
    int zT_140;
    int zT_143;
    unsigned int zT_144;
    int zT_147;
    int zT_150;
    unsigned int zT_151;
    zT_33EF6BFB_TypeKind zT_154;
    zT_338B7C76_TypeRegistry* zT_160;
    zT_0B10E8E9_OptionalPayload* zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    zT_0B10E8E9_OptionalPayload zT_164;
    zT_38C12417_SemanticAnalyzer* zT_165;
    unsigned int zT_166;
    unsigned int zT_168;
    zT_33EF6BFB_TypeKind zT_171;
    zT_338B7C76_TypeRegistry* zT_177;
    zT_112BF819_PtrPayload* zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_112BF819_PtrPayload zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    zT_338B7C76_TypeRegistry* zT_188;
    zT_112BF819_PtrPayload* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_112BF819_PtrPayload zT_192;
    unsigned char zT_193;
    unsigned int zT_199;
    unsigned int zT_200;
    zT_33EF6BFB_TypeKind zT_202;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_112BF819_PtrPayload* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_112BF819_PtrPayload zT_212;
    unsigned char zT_213;
    unsigned int zT_219;
    unsigned int zT_220;
    int zT_222;
    unsigned int zT_223;
    zT_33EF6BFB_TypeKind zT_226;
    zT_338B7C76_TypeRegistry* zT_232;
    zT_0B10E8E9_OptionalPayload* zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    zT_0B10E8E9_OptionalPayload zT_236;
    zT_38C12417_SemanticAnalyzer* zT_237;
    unsigned int zT_238;
    unsigned int zT_240;
    zT_33EF6BFB_TypeKind zT_243;
    zT_338B7C76_TypeRegistry* zT_249;
    zT_0BB2A741_SlicePayload* zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    zT_0BB2A741_SlicePayload zT_253;
    zT_33EF6BFB_TypeKind zT_254;
    zT_338B7C76_TypeRegistry* zT_260;
    zT_0BB2A741_SlicePayload* zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_0BB2A741_SlicePayload zT_264;
    unsigned char zT_265;
    unsigned int zT_271;
    unsigned int zT_272;
    zT_33EF6BFB_TypeKind zT_274;
    zT_338B7C76_TypeRegistry* zT_280;
    zT_112BF819_PtrPayload* zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    zT_112BF819_PtrPayload zT_284;
    unsigned char zT_285;
    unsigned int zT_291;
    unsigned int zT_292;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    zT_112BF819_PtrPayload sp;
    unsigned int sp_base_eff;
    zT_D155D06D_Type sp_pointee;
    zT_112BF819_PtrPayload dp;
    zT_112BF819_PtrPayload dp2;
    zT_0BB2A741_SlicePayload ds;
    zT_0B10E8E9_OptionalPayload opt;
    zT_112BF819_PtrPayload sp2;
    zT_112BF819_PtrPayload dp3;
    zT_112BF819_PtrPayload dp4;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_0BB2A741_SlicePayload ss;
    zT_0BB2A741_SlicePayload ds2;
    zT_112BF819_PtrPayload dp5;
    z_bb_0:
    if ((int)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    if ((int)(src_type == dst_type)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_18 = self->registry;
    zT_19 = zT_18->types_len;
    if ((int)((unsigned int)((unsigned int)src_type) >= zT_19)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    if ((int)((unsigned int)((unsigned int)dst_type) >= zT_24)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(0);
    z_bb_16:
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)src_type;
    zT_31 = zT_29[zT_30];
    s = zT_31;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)dst_type;
    zT_36 = zT_34[zT_35];
    d = zT_36;
    zT_37 = s.flags;
    if ((int)((unsigned char)(zT_37 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (int)(0);
    z_bb_18:
    zT_43 = s.kind;
    if ((int)(zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_49 = self->registry;
    zT_50 = zT_49->ptr_items;
    zT_51 = s.payload_idx;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_50[zT_52];
    sp = zT_53;
    zT_55 = sp.base;
    sp_base_eff = zT_55;
    zT_56 = sp.base;
    zT_58 = self->registry;
    zT_59 = zT_58->types_len;
    if ((int)((unsigned int)((unsigned int)zT_56) < zT_59)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_171 = s.kind;
    if ((int)(zT_171 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_54; else goto z_bb_55;
    z_bb_21:
    zT_62 = self->registry;
    zT_63 = zT_62->types_items;
    zT_64 = sp.base;
    zT_65 = (unsigned int)zT_64;
    zT_66 = zT_63[zT_65];
    sp_pointee = zT_66;
    zT_67 = sp_pointee.kind;
    if ((int)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_78 = d.kind;
    if ((int)(zT_78 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    zT_72 = self->registry;
    zT_73 = zT_72->array_items;
    zT_74 = sp_pointee.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    zT_77 = zT_76.elem;
    sp_base_eff = zT_77;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_84 = self->registry;
    zT_85 = zT_84->ptr_items;
    zT_86 = d.payload_idx;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zT_85[zT_87];
    dp = zT_88;
    zT_89 = d.flags;
    if ((int)((unsigned char)(zT_89 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_102 = d.kind;
    if ((int)(zT_102 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_32; else goto z_bb_33;
    z_bb_27:
    return (int)(0);
    z_bb_28:
    zT_95 = sp.base;
    zT_96 = dp.base;
    if ((int)(zT_95 == zT_96)) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_99 = dp.base;
    zT_98 = zT_99 == (unsigned int)(1);
    goto z_bb_31;
    z_bb_30:
    zT_98 = 1;
    goto z_bb_31;
    z_bb_31:
    return zT_98;
    z_bb_32:
    zT_108 = self->registry;
    zT_109 = zT_108->ptr_items;
    zT_110 = d.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    dp2 = zT_112;
    zT_113 = d.flags;
    if ((int)((unsigned char)(zT_113 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_121 = d.kind;
    if ((int)(zT_121 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    return (int)(0);
    z_bb_35:
    zT_119 = dp2.base;
    return (int)(sp_base_eff == zT_119);
    z_bb_36:
    zT_127 = self->registry;
    zT_128 = zT_127->slice_items;
    zT_129 = d.payload_idx;
    zT_130 = (unsigned int)zT_129;
    zT_131 = zT_128[zT_130];
    ds = zT_131;
    zT_132 = d.flags;
    if ((int)((unsigned char)(zT_132 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_154 = d.kind;
    if ((int)(zT_154 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_52; else goto z_bb_53;
    z_bb_38:
    return (int)(0);
    z_bb_39:
    zT_138 = ds.elem;
    if ((int)(sp_base_eff == zT_138)) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    if ((int)(sp_base_eff == (unsigned int)(14))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_140 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_140) goto z_bb_47; else goto z_bb_46;
    z_bb_43:
    zT_144 = ds.elem;
    zT_143 = zT_144 == (unsigned int)(8);
    goto z_bb_45;
    z_bb_44:
    zT_143 = 0;
    goto z_bb_45;
    z_bb_45:
    zT_140 = zT_143;
    goto z_bb_42;
    z_bb_46:
    if ((int)(sp_base_eff == (unsigned int)(8))) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    zT_147 = 1;
    goto z_bb_48;
    z_bb_48:
    return zT_147;
    z_bb_49:
    zT_151 = ds.elem;
    zT_150 = zT_151 == (unsigned int)(14);
    goto z_bb_51;
    z_bb_50:
    zT_150 = 0;
    goto z_bb_51;
    z_bb_51:
    zT_147 = zT_150;
    goto z_bb_48;
    z_bb_52:
    zT_160 = self->registry;
    zT_161 = zT_160->opt_items;
    zT_162 = d.payload_idx;
    zT_163 = (unsigned int)zT_162;
    zT_164 = zT_161[zT_163];
    opt = zT_164;
    zT_165 = self;
    zT_166 = src_type;
    zT_168 = opt.payload;
    self = zT_165;
    src_type = zT_166;
    dst_type = zT_168;
    goto z_bb_0;
    z_bb_53:
    return (int)(0);
    z_bb_54:
    zT_177 = self->registry;
    zT_178 = zT_177->ptr_items;
    zT_179 = s.payload_idx;
    zT_180 = (unsigned int)zT_179;
    zT_181 = zT_178[zT_180];
    sp2 = zT_181;
    zT_182 = d.kind;
    if ((int)(zT_182 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    zT_243 = s.kind;
    if ((int)(zT_243 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_69; else goto z_bb_70;
    z_bb_56:
    zT_188 = self->registry;
    zT_189 = zT_188->ptr_items;
    zT_190 = d.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    dp3 = zT_192;
    zT_193 = d.flags;
    if ((int)((unsigned char)(zT_193 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    zT_202 = d.kind;
    if ((int)(zT_202 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_60; else goto z_bb_61;
    z_bb_58:
    return (int)(0);
    z_bb_59:
    zT_199 = sp2.base;
    zT_200 = dp3.base;
    return (int)(zT_199 == zT_200);
    z_bb_60:
    zT_208 = self->registry;
    zT_209 = zT_208->ptr_items;
    zT_210 = d.payload_idx;
    zT_211 = (unsigned int)zT_210;
    zT_212 = zT_209[zT_211];
    dp4 = zT_212;
    zT_213 = d.flags;
    if ((int)((unsigned char)(zT_213 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    zT_226 = d.kind;
    if ((int)(zT_226 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_67; else goto z_bb_68;
    z_bb_62:
    return (int)(0);
    z_bb_63:
    zT_219 = sp2.base;
    zT_220 = dp4.base;
    if ((int)(zT_219 == zT_220)) goto z_bb_65; else goto z_bb_64;
    z_bb_64:
    zT_223 = dp4.base;
    zT_222 = zT_223 == (unsigned int)(1);
    goto z_bb_66;
    z_bb_65:
    zT_222 = 1;
    goto z_bb_66;
    z_bb_66:
    return zT_222;
    z_bb_67:
    zT_232 = self->registry;
    zT_233 = zT_232->opt_items;
    zT_234 = d.payload_idx;
    zT_235 = (unsigned int)zT_234;
    zT_236 = zT_233[zT_235];
    opt2 = zT_236;
    zT_237 = self;
    zT_238 = src_type;
    zT_240 = opt2.payload;
    self = zT_237;
    src_type = zT_238;
    dst_type = zT_240;
    goto z_bb_0;
    z_bb_68:
    return (int)(0);
    z_bb_69:
    zT_249 = self->registry;
    zT_250 = zT_249->slice_items;
    zT_251 = s.payload_idx;
    zT_252 = (unsigned int)zT_251;
    zT_253 = zT_250[zT_252];
    ss = zT_253;
    zT_254 = d.kind;
    if ((int)(zT_254 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_71; else goto z_bb_72;
    z_bb_70:
    return (int)(0);
    z_bb_71:
    zT_260 = self->registry;
    zT_261 = zT_260->slice_items;
    zT_262 = d.payload_idx;
    zT_263 = (unsigned int)zT_262;
    zT_264 = zT_261[zT_263];
    ds2 = zT_264;
    zT_265 = d.flags;
    if ((int)((unsigned char)(zT_265 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    zT_274 = d.kind;
    if ((int)(zT_274 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    return (int)(0);
    z_bb_74:
    zT_271 = ss.elem;
    zT_272 = ds2.elem;
    return (int)(zT_271 == zT_272);
    z_bb_75:
    zT_280 = self->registry;
    zT_281 = zT_280->ptr_items;
    zT_282 = d.payload_idx;
    zT_283 = (unsigned int)zT_282;
    zT_284 = zT_281[zT_283];
    dp5 = zT_284;
    zT_285 = d.flags;
    if ((int)((unsigned char)(zT_285 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    return (int)(0);
    z_bb_77:
    return (int)(0);
    z_bb_78:
    zT_291 = ss.elem;
    zT_292 = dp5.base;
    return (int)(zT_291 == zT_292);
}

/* semanticAnalyzerMaybeDiagVolatileDrop */
int zF_86AAA417_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer* self, unsigned int span_node, unsigned int src_type, unsigned int dst_type) {
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7 = 0;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_F85C5DED_DiagnosticCollector* zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_35 = 0;
    zT_22A7C88B_AstNode vdrop_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdrop_msg;
    zT_4 = self;
    zT_5 = src_type;
    zT_6 = dst_type;
    zT_7 = zF_57090266_semanticAnalyzerVol(zT_4, zT_5, zT_6);
    if ((int)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_11 = self->store;
    zT_12 = span_node;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    vdrop_node = zT_14;
    zT_16 = "cannot implicitly discard 'volatile' qualifier; use @volatileCast to remove it";
    zT_18 = 78;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    vdrop_msg = zT_17;
    zT_19 = self->diag;
    zT_22 = self->source_file_id;
    zT_23 = vdrop_node.span_start;
    zT_31 = vdrop_node.span_start;
    zT_32 = vdrop_node.span_len;
    zT_25 = vdrop_msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_19, (unsigned char)(0), (unsigned short)(3000), zT_22, zT_23, (unsigned int)(zT_31 + (unsigned int)((unsigned int)zT_32)), zT_25);
    (void)zT_35;
    return (int)(1);
}

/* semanticAnalyzerPtrCastDropsVolatile */
int zF_5F2042EA_semanticAnalyzerPtr(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    int zT_5;
    int zT_11;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    zT_33EF6BFB_TypeKind zT_37;
    int zT_42;
    zT_33EF6BFB_TypeKind zT_43;
    zT_33EF6BFB_TypeKind zT_50;
    int zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char zT_63;
    unsigned char zT_69;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    if ((int)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    if ((int)(src_type == dst_type)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_18 = self->registry;
    zT_19 = zT_18->types_len;
    if ((int)((unsigned int)((unsigned int)src_type) >= zT_19)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_23 = self->registry;
    zT_24 = zT_23->types_len;
    if ((int)((unsigned int)((unsigned int)dst_type) >= zT_24)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(0);
    z_bb_16:
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)src_type;
    zT_31 = zT_29[zT_30];
    s = zT_31;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)dst_type;
    zT_36 = zT_34[zT_35];
    d = zT_36;
    zT_37 = s.kind;
    if ((int)(zT_37 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_43 = s.kind;
    zT_42 = zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_19;
    z_bb_18:
    zT_42 = 1;
    goto z_bb_19;
    z_bb_19:
    if ((int)(!zT_42)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (int)(0);
    z_bb_21:
    zT_50 = d.kind;
    if ((int)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_56 = d.kind;
    zT_55 = zT_56 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_24;
    z_bb_23:
    zT_55 = 1;
    goto z_bb_24;
    z_bb_24:
    if ((int)(!zT_55)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(0);
    z_bb_26:
    zT_63 = s.flags;
    if ((int)((unsigned char)(zT_63 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(0);
    z_bb_28:
    zT_69 = d.flags;
    return (int)((unsigned char)(zT_69 & (unsigned char)(2)) == (unsigned char)(0));
}

/* semanticAnalyzerVolatileCastValid */
int zF_EC29CB82_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer* self, unsigned int src_type, unsigned int dst_type) {
    int zT_5;
    int zT_11;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_D155D06D_Type* zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type zT_29;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_33EF6BFB_TypeKind zT_35;
    int zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    zT_33EF6BFB_TypeKind zT_48;
    int zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    unsigned char zT_61;
    unsigned char zT_67;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_112BF819_PtrPayload* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_112BF819_PtrPayload zT_78;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_112BF819_PtrPayload* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_112BF819_PtrPayload zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_D155D06D_Type s;
    zT_D155D06D_Type d;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload dp;
    if ((int)(src_type == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = dst_type == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_11 = dst_type == (unsigned int)(18);
    goto z_bb_8;
    z_bb_7:
    zT_11 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_11) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    if ((int)((unsigned int)((unsigned int)src_type) >= zT_17)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(0);
    z_bb_12:
    zT_21 = self->registry;
    zT_22 = zT_21->types_len;
    if ((int)((unsigned int)((unsigned int)dst_type) >= zT_22)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_26 = self->registry;
    zT_27 = zT_26->types_items;
    zT_28 = (unsigned int)src_type;
    zT_29 = zT_27[zT_28];
    s = zT_29;
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)dst_type;
    zT_34 = zT_32[zT_33];
    d = zT_34;
    zT_35 = s.kind;
    if ((int)(zT_35 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_41 = s.kind;
    zT_40 = zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_17;
    z_bb_16:
    zT_40 = 1;
    goto z_bb_17;
    z_bb_17:
    if ((int)(!zT_40)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    return (int)(0);
    z_bb_19:
    zT_48 = d.kind;
    if ((int)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_54 = d.kind;
    zT_53 = zT_54 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_22;
    z_bb_21:
    zT_53 = 1;
    goto z_bb_22;
    z_bb_22:
    if ((int)(!zT_53)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (int)(0);
    z_bb_24:
    zT_61 = s.flags;
    if ((int)((unsigned char)(zT_61 & (unsigned char)(2)) == (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (int)(0);
    z_bb_26:
    zT_67 = d.flags;
    if ((int)((unsigned char)(zT_67 & (unsigned char)(2)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(0);
    z_bb_28:
    zT_74 = self->registry;
    zT_75 = zT_74->ptr_items;
    zT_76 = s.payload_idx;
    zT_77 = (unsigned int)zT_76;
    zT_78 = zT_75[zT_77];
    sp = zT_78;
    zT_80 = self->registry;
    zT_81 = zT_80->ptr_items;
    zT_82 = d.payload_idx;
    zT_83 = (unsigned int)zT_82;
    zT_84 = zT_81[zT_83];
    dp = zT_84;
    zT_85 = sp.base;
    zT_86 = dp.base;
    return (int)(zT_85 == zT_86);
}

/* tryRecordCoercion */
void zF_DF7434EB_tryRecordCoercion(zT_38C12417_SemanticAnalyzer* self, unsigned int src_node, unsigned int src_type, unsigned int dst_type) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_338B7C76_TypeRegistry* zT_23;
    zT_D155D06D_Type* zT_24;
    unsigned int zT_25;
    zT_D155D06D_Type zT_26;
    zT_338B7C76_TypeRegistry* zT_28;
    zT_D155D06D_Type* zT_29;
    unsigned int zT_30;
    zT_D155D06D_Type zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_33EF6BFB_TypeKind zT_38;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_33EF6BFB_TypeKind zT_46;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    zT_22A7C88B_AstNode zT_52 = {0};
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_8143F551_AstKind zT_59;
    int zT_63;
    zT_38C12417_SemanticAnalyzer* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    int zT_69 = 0;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    int zT_74 = 0;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_0FB7FB13_CoercionKind zT_88 = 0;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    int zT_100;
    int zT_103;
    zT_338B7C76_TypeRegistry* zT_104;
    unsigned int zT_105;
    int zT_107 = 0;
    zT_66E7D2EF_CoercionTable* zT_108;
    unsigned int zT_109;
    zT_0FB7FB13_CoercionKind zT_110;
    unsigned int zT_111;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    unsigned char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dm;
    zT_D155D06D_Type src_t;
    zT_D155D06D_Type dst_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_skm;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_dkm;
    zT_22A7C88B_AstNode snode;
    zT_8F083A69_Slice_zT_0B42B2F8_u coe_nkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs1_m;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u cka_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u cor_km;
    zT_5 = "COE:N";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    coe_nm = zT_6;
    zT_8 = coe_nm;
    zT_9 = src_node;
    zF_C914CB83_markerWriteInt(zT_8, zT_9);
    zT_11 = "COE:S";
    zT_13 = 5;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    coe_sm = zT_12;
    zT_14 = coe_sm;
    zT_15 = src_type;
    zF_C914CB83_markerWriteInt(zT_14, zT_15);
    zT_17 = "COE:D";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    coe_dm = zT_18;
    zT_20 = coe_dm;
    zT_21 = dst_type;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = self->registry;
    zT_24 = zT_23->types_items;
    zT_25 = (unsigned int)src_type;
    zT_26 = zT_24[zT_25];
    src_t = zT_26;
    zT_28 = self->registry;
    zT_29 = zT_28->types_items;
    zT_30 = (unsigned int)dst_type;
    zT_31 = zT_29[zT_30];
    dst_t = zT_31;
    zT_33 = "COE:SK";
    zT_35 = 6;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    coe_skm = zT_34;
    zT_36 = coe_skm;
    zT_38 = src_t.kind;
    zF_C914CB83_markerWriteInt(zT_36, (unsigned int)((unsigned int)zT_38));
    zT_41 = "COE:DK";
    zT_43 = 6;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    coe_dkm = zT_42;
    zT_44 = coe_dkm;
    zT_46 = dst_t.kind;
    zF_C914CB83_markerWriteInt(zT_44, (unsigned int)((unsigned int)zT_46));
    zT_49 = self->store;
    zT_50 = src_node;
    zT_52 = zF_FCDD1D35_astStoreNodeAt(zT_49, zT_50);
    snode = zT_52;
    zT_54 = "COE:NK";
    zT_56 = 6;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    coe_nkm = zT_55;
    zT_57 = coe_nkm;
    zT_59 = snode.kind;
    zF_C914CB83_markerWriteInt(zT_57, (unsigned int)((unsigned int)zT_59));
    if ((int)(src_type == (unsigned int)(18))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_63 = src_type == dst_type;
    goto z_bb_3;
    z_bb_2:
    zT_63 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_63) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_65 = self;
    zT_66 = src_node;
    zT_67 = src_type;
    zT_68 = dst_type;
    zT_69 = zF_86AAA417_semanticAnalyzerMay(zT_65, zT_66, zT_67, zT_68);
    if (zT_69) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    zT_70 = self->registry;
    zT_71 = src_type;
    zT_72 = dst_type;
    zT_74 = zF_683AEB7F_typeRegistryIsAssig(zT_70, zT_71, zT_72);
    if ((int)(!zT_74)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    if ((int)(src_type == (unsigned int)(17))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_79 = "CS1\n";
    zT_81 = 4;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    cs1_m = zT_80;
    zT_82 = cs1_m;
    zF_48AC7B3A_markerWrite(zT_82);
    goto z_bb_11;
    z_bb_11:
    zT_84 = self->registry;
    zT_85 = src_type;
    zT_86 = dst_type;
    zT_88 = zF_713658BF_classifyCoercion(zT_84, zT_85, zT_86);
    ck = zT_88;
    zT_90 = "CCK:ca";
    zT_92 = 6;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    cka_m = zT_91;
    zT_93 = cka_m;
    zF_C914CB83_markerWriteInt(zT_93, (unsigned int)((unsigned int)ck));
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    if ((int)(src_type == (unsigned int)(17))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_100 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_100) goto z_bb_18; else goto z_bb_19;
    z_bb_15:
    zT_104 = self->registry;
    zT_105 = dst_type;
    zT_107 = zF_AD61DB1B_typeRegistryIsPoint(zT_104, zT_105);
    zT_103 = zT_107;
    goto z_bb_17;
    z_bb_16:
    zT_103 = 0;
    goto z_bb_17;
    z_bb_17:
    zT_100 = zT_103;
    goto z_bb_14;
    z_bb_18:
    zT_108 = self->coercion_table;
    zT_109 = src_node;
    zT_110 = ck;
    zT_111 = dst_type;
    zF_D21AE60A_coercionTableAdd(zT_108, zT_109, zT_110, zT_111);
    zT_114 = "COR:N";
    zT_116 = 5;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    cor_nm = zT_115;
    zT_117 = cor_nm;
    zT_118 = src_node;
    zF_C914CB83_markerWriteInt(zT_117, zT_118);
    zT_120 = "COR:K";
    zT_122 = 5;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    cor_km = zT_121;
    zT_123 = cor_km;
    zF_C914CB83_markerWriteInt(zT_123, (unsigned int)((unsigned int)ck));
    goto z_bb_19;
    z_bb_19:
    return;
}

/* isStringLiteralSliceCoercion */
int zF_71304A07_isStringLiteralSlic(zT_0FB7FB13_CoercionKind k) {
    int zT_5;
    if ((int)(k == (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_string_to_slice))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = k == (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_5;
}

/* errLitSrcType */
unsigned int zF_FFC95E09_errLitSrcType(zT_38C12417_SemanticAnalyzer* self, unsigned int child_0, unsigned int target_ty, unsigned int ret_val) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_8143F551_AstKind zT_9;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_D155D06D_Type* zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type zT_18;
    zT_33EF6BFB_TypeKind zT_19;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_42C2D6BF_EUPayload* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_42C2D6BF_EUPayload zT_28;
    unsigned int zT_29;
    zT_22A7C88B_AstNode rn;
    zT_D155D06D_Type frt;
    zT_5 = self->store;
    zT_6 = child_0;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    rn = zT_8;
    zT_9 = rn.kind;
    if ((int)(zT_9 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = self->registry;
    zT_16 = zT_15->types_items;
    zT_17 = (unsigned int)target_ty;
    zT_18 = zT_16[zT_17];
    frt = zT_18;
    zT_19 = frt.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return ret_val;
    z_bb_3:
    zT_24 = self->registry;
    zT_25 = zT_24->eu_items;
    zT_26 = frt.payload_idx;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_25[zT_27];
    zT_29 = zT_28.error_set;
    return zT_29;
    z_bb_4:
    goto z_bb_2;
}

/* resolveReturnStmt */
void zF_F231D87F_resolveReturnStmt(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    int zT_13 = 0;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_F85C5DED_DiagnosticCollector* zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_35 = 0;
    unsigned int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    zT_38C12417_SemanticAnalyzer* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    zT_38C12417_SemanticAnalyzer* zT_47;
    unsigned int zT_48;
    int zT_51;
    unsigned int zT_52;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_38C12417_SemanticAnalyzer* zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_82 = 0;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    int zT_88 = 0;
    int zT_90;
    zT_38C12417_SemanticAnalyzer* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    int zT_97 = 0;
    unsigned int zT_99;
    unsigned int zT_101;
    unsigned int zT_103;
    unsigned char* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_F85C5DED_DiagnosticCollector* zT_109;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_120 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_33EF6BFB_TypeKind zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_D155D06D_Type* zT_127;
    unsigned int zT_128;
    zT_D155D06D_Type zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_33EF6BFB_TypeKind zT_136;
    zT_338B7C76_TypeRegistry* zT_137;
    zT_D155D06D_Type* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    zT_D155D06D_Type zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_143 = {0};
    zT_38C12417_SemanticAnalyzer* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_22A7C88B_AstNode node;
    unsigned int brsp;
    unsigned int brep;
    zT_8F083A69_Slice_zT_0B42B2F8_u br_msg;
    unsigned int ret_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2f_fm;
    unsigned int ret_eff;
    unsigned int rsp;
    unsigned int rep;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtm_msg;
    unsigned int rdi;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((int)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zT_11 = self->current_fn_return;
    zT_13 = zF_15CE7BE8_fnReturnRequiresVal(zT_10, zT_11);
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_36 = node.child_0;
    if ((int)(zT_36 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_15 = node.span_start;
    brsp = zT_15;
    zT_17 = node.span_len;
    zT_19 = brsp + (unsigned int)((unsigned int)zT_17);
    brep = zT_19;
    zT_21 = "return with no value in function returning non-void";
    zT_23 = 51;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    br_msg = zT_22;
    zT_24 = self->diag;
    zT_27 = self->source_file_id;
    zT_28 = brsp;
    zT_29 = brep;
    zT_30 = br_msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_24, (unsigned char)(0), (unsigned short)(3003), zT_27, zT_28, zT_29, zT_30);
    (void)zT_35;
    goto z_bb_4;
    z_bb_4:
    return;
    z_bb_5:
    zT_39 = self;
    zT_40 = self->current_fn_return;
    zF_9665A229_pushExpectedType(zT_39, zT_40);
    zT_43 = self;
    zT_44 = node.child_0;
    zT_46 = zF_54F95822_semanticAnalyzerRes(zT_43, zT_44);
    ret_val = zT_46;
    zT_47 = self;
    zF_BC478E78_popExpectedType(zT_47);
    zT_48 = self->current_fn_return;
    if ((int)(zT_48 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return;
    z_bb_7:
    zT_52 = self->current_fn_return;
    zT_51 = zT_52 != (unsigned int)(1);
    goto z_bb_9;
    z_bb_8:
    zT_51 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_51) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_56 = "T2F:C";
    zT_58 = 5;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    t2f_nm = zT_57;
    zT_59 = t2f_nm;
    zT_60 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_59, zT_60);
    zT_63 = "T2F:R";
    zT_65 = 5;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    t2f_rm = zT_64;
    zT_66 = t2f_rm;
    zT_67 = ret_val;
    zF_C914CB83_markerWriteInt(zT_66, zT_67);
    zT_69 = "T2F:F";
    zT_71 = 5;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    t2f_fm = zT_70;
    zT_72 = t2f_fm;
    zT_73 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_72, zT_73);
    zT_76 = self;
    zT_77 = node.child_0;
    zT_78 = self->current_fn_return;
    zT_79 = ret_val;
    zT_82 = zF_FFC95E09_errLitSrcType(zT_76, zT_77, zT_78, zT_79);
    ret_eff = zT_82;
    zT_83 = self->registry;
    zT_84 = ret_eff;
    zT_85 = self->current_fn_return;
    zT_88 = zF_683AEB7F_typeRegistryIsAssig(zT_83, zT_84, zT_85);
    if ((int)(!zT_88)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    goto z_bb_6;
    z_bb_12:
    zT_91 = self;
    zT_92 = ret_eff;
    zT_93 = self->current_fn_return;
    zT_97 = zF_D728034A_isBShapeMismatch(zT_91, zT_92, zT_93, (int)(0));
    zT_90 = zT_97;
    goto z_bb_14;
    z_bb_13:
    zT_90 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_90) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_99 = node.span_start;
    rsp = zT_99;
    zT_101 = node.span_len;
    zT_103 = rsp + (unsigned int)((unsigned int)zT_101);
    rep = zT_103;
    zT_105 = "type mismatch in return statement — value type may not be compatible with the function return type";
    zT_107 = 100;
    zT_106.ptr = zT_105;
    zT_106.len = zT_107;
    rtm_msg = zT_106;
    zT_109 = self->diag;
    zT_112 = self->source_file_id;
    zT_113 = rsp;
    zT_114 = rep;
    zT_115 = rtm_msg;
    zT_120 = zF_C82559AC_diagnosticCollector(zT_109, (unsigned char)(0), (unsigned short)(3000), zT_112, zT_113, zT_114, zT_115);
    rdi = zT_120;
    zT_121 = self->diag;
    zT_122 = rdi;
    zT_126 = self->registry;
    zT_127 = zT_126->types_items;
    zT_128 = (unsigned int)ret_eff;
    zT_129 = zT_127[zT_128];
    zT_125 = zT_129.kind;
    zT_131 = zF_C14453DE_typeKindSrcStr(zT_125);
    zT_123 = zT_131;
    zF_426E1F18_diagnosticCollector(zT_121, zT_122, zT_123);
    (void)self;
    zT_132 = self->diag;
    zT_133 = rdi;
    zT_137 = self->registry;
    zT_138 = zT_137->types_items;
    zT_139 = self->current_fn_return;
    zT_140 = (unsigned int)zT_139;
    zT_141 = zT_138[zT_140];
    zT_136 = zT_141.kind;
    zT_143 = zF_CC479241_typeKindTgtStr(zT_136);
    zT_134 = zT_143;
    zF_426E1F18_diagnosticCollector(zT_132, zT_133, zT_134);
    (void)self;
    goto z_bb_16;
    z_bb_16:
    zT_144 = self;
    zT_145 = node.child_0;
    zT_146 = ret_eff;
    zT_147 = self->current_fn_return;
    zF_DF7434EB_tryRecordCoercion(zT_144, zT_145, zT_146, zT_147);
    goto z_bb_11;
}

/* semanticAnalyzerResolveFnCall */
unsigned int zF_87E78775_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_17 = {0};
    unsigned int zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_8143F551_AstKind zT_23;
    zT_3D7259E2_SymbolRegistry* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int zT_38 = 0;
    zT_5979294E_Opt_849 zT_39 = {0};
    unsigned char zT_40;
    unsigned char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_8EED1867_ResolvedTypeTable* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_3C598AEF_SymbolKind zT_57;
    int zT_62;
    unsigned int zT_63;
    zT_6B0A7D14_AstStore* zT_67;
    unsigned int zT_68;
    zT_22A7C88B_AstNode zT_71 = {0};
    zT_8143F551_AstKind zT_72;
    zT_6B0A7D14_AstStore* zT_78;
    zT_4A7609CD_anon_224403 zT_79;
    zT_243D6A41_FnProto* zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_85 = 0;
    unsigned int zT_86;
    zT_243D6A41_FnProto zT_87;
    unsigned int zT_88;
    zT_8EED1867_ResolvedTypeTable* zT_92;
    unsigned int zT_93;
    zT_BAEE192E_Opt_10 zT_96 = {0};
    unsigned char zT_98;
    unsigned int zT_99;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    unsigned char zT_108;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_ABC1EBBE_TypeResolveEnv zT_117;
    zT_6B0A7D14_AstStore* zT_118;
    zT_338B7C76_TypeRegistry* zT_119;
    zT_3D7259E2_SymbolRegistry* zT_120;
    zT_D3EB6303_StringInterner* zT_121;
    unsigned int zT_122;
    zT_F85C5DED_DiagnosticCollector* zT_123;
    zT_7334F4FE_Opt_225 zT_124;
    zT_F6B96876_Opt_395 zT_125 = {0};
    unsigned int zT_126;
    zT_ABC1EBBE_TypeResolveEnv* zT_128;
    unsigned int zT_129;
    unsigned int zT_134 = 0;
    unsigned char* zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    unsigned char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    unsigned char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned char* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    zT_6B0A7D14_AstStore* zT_168;
    unsigned int zT_169;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_171 = {0};
    unsigned char zT_173;
    unsigned short zT_175;
    unsigned int zT_177;
    int zT_178;
    zT_8EED1867_ResolvedTypeTable* zT_181;
    unsigned int zT_182;
    zT_BAEE192E_Opt_10 zT_184 = {0};
    unsigned char zT_185;
    unsigned char* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    zT_338B7C76_TypeRegistry* zT_193;
    zT_D155D06D_Type* zT_194;
    unsigned int zT_195;
    zT_D155D06D_Type zT_196;
    zT_33EF6BFB_TypeKind zT_197;
    zT_338B7C76_TypeRegistry* zT_203;
    zT_0317B1D5_FnPayload* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    zT_0317B1D5_FnPayload zT_207;
    unsigned short zT_208;
    unsigned int zT_209;
    unsigned char zT_210;
    int zT_212;
    unsigned int zT_213;
    unsigned int zT_215;
    unsigned int zT_218;
    int zT_221;
    unsigned int zT_229;
    unsigned int zT_230;
    zT_21D3708C_U32ToU32Map* zT_231;
    unsigned int zT_232;
    zT_BAEE192E_Opt_10 zT_234 = {0};
    unsigned char zT_235;
    zT_338B7C76_TypeRegistry* zT_237;
    unsigned int* zT_238;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_21D3708C_U32ToU32Map* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    unsigned int* zT_246;
    zT_38C12417_SemanticAnalyzer* zT_248;
    unsigned int zT_249;
    zT_38C12417_SemanticAnalyzer* zT_251;
    unsigned int zT_252;
    unsigned int* zT_253;
    unsigned int zT_255 = 0;
    zT_38C12417_SemanticAnalyzer* zT_256;
    int zT_259;
    zT_38C12417_SemanticAnalyzer* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned int* zT_267;
    unsigned int zT_269 = 0;
    zT_338B7C76_TypeRegistry* zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    int zT_274 = 0;
    int zT_276;
    zT_38C12417_SemanticAnalyzer* zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    int zT_282 = 0;
    zT_6B0A7D14_AstStore* zT_284;
    unsigned int zT_285;
    unsigned int* zT_287;
    zT_22A7C88B_AstNode zT_289 = {0};
    unsigned int zT_291;
    unsigned int zT_293;
    unsigned int zT_295;
    unsigned char* zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    unsigned int zT_299;
    zT_F85C5DED_DiagnosticCollector* zT_301;
    unsigned int zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_312 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_313;
    unsigned int zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    zT_33EF6BFB_TypeKind zT_317;
    zT_338B7C76_TypeRegistry* zT_318;
    zT_D155D06D_Type* zT_319;
    unsigned int zT_320;
    zT_D155D06D_Type zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_324;
    unsigned int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    zT_33EF6BFB_TypeKind zT_328;
    zT_338B7C76_TypeRegistry* zT_329;
    zT_D155D06D_Type* zT_330;
    unsigned int zT_331;
    zT_D155D06D_Type zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334 = {0};
    zT_38C12417_SemanticAnalyzer* zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    unsigned int* zT_339;
    int zT_341;
    unsigned int zT_342;
    zT_8EED1867_ResolvedTypeTable* zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    zT_38C12417_SemanticAnalyzer* zT_348;
    unsigned int zT_349;
    unsigned int zT_351 = 0;
    unsigned char* zT_355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    unsigned int zT_357;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_358;
    zT_338B7C76_TypeRegistry* zT_361;
    zT_D155D06D_Type* zT_362;
    unsigned int zT_363;
    zT_D155D06D_Type zT_364;
    zT_33EF6BFB_TypeKind zT_365;
    zT_338B7C76_TypeRegistry* zT_371;
    zT_112BF819_PtrPayload* zT_372;
    unsigned int zT_373;
    unsigned int zT_374;
    zT_112BF819_PtrPayload zT_375;
    zT_338B7C76_TypeRegistry* zT_377;
    zT_D155D06D_Type* zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    zT_D155D06D_Type zT_381;
    zT_33EF6BFB_TypeKind zT_382;
    unsigned int zT_387;
    zT_338B7C76_TypeRegistry* zT_388;
    zT_D155D06D_Type* zT_389;
    unsigned int zT_390;
    zT_D155D06D_Type zT_391;
    zT_33EF6BFB_TypeKind zT_392;
    unsigned char* zT_398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_399;
    unsigned int zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_401;
    unsigned int zT_402;
    unsigned char* zT_404;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405;
    unsigned int zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    unsigned int zT_408;
    unsigned char* zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_412;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_413;
    zT_33EF6BFB_TypeKind zT_415;
    zT_6B0A7D14_AstStore* zT_418;
    unsigned int zT_419;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_421 = {0};
    unsigned int zT_423;
    unsigned int zT_425;
    zT_38C12417_SemanticAnalyzer* zT_427;
    zT_38C12417_SemanticAnalyzer* zT_430;
    unsigned int zT_431;
    unsigned int* zT_432;
    unsigned int zT_434 = 0;
    zT_38C12417_SemanticAnalyzer* zT_435;
    unsigned int zT_437;
    unsigned char* zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_441;
    unsigned int zT_442;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_443;
    zT_338B7C76_TypeRegistry* zT_445;
    zT_0317B1D5_FnPayload* zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    zT_0317B1D5_FnPayload zT_449;
    unsigned char* zT_451;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_452;
    unsigned int zT_453;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_454;
    unsigned short zT_456;
    unsigned int zT_457;
    unsigned int zT_459;
    unsigned int zT_460;
    unsigned char* zT_462;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_463;
    unsigned int zT_464;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_465;
    zT_6B0A7D14_AstStore* zT_467;
    unsigned int zT_468;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_470 = {0};
    unsigned char* zT_472;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_473;
    unsigned int zT_474;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_475;
    unsigned char zT_477;
    unsigned char zT_478;
    unsigned char zT_483;
    unsigned int zT_488;
    unsigned int zT_490;
    unsigned int zT_492;
    unsigned int zT_494;
    int zT_496;
    unsigned int zT_497;
    unsigned char* zT_499;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_500;
    unsigned int zT_501;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_502;
    unsigned char* zT_504;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_505;
    unsigned int zT_506;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_507;
    zT_338B7C76_TypeRegistry* zT_509;
    unsigned int zT_510;
    unsigned char* zT_513;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_514;
    unsigned int zT_515;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_516;
    unsigned char* zT_521;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_522;
    unsigned int zT_523;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_524;
    zT_338B7C76_TypeRegistry* zT_526;
    unsigned int* zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    zT_21D3708C_U32ToU32Map* zT_530;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned int* zT_534;
    unsigned char* zT_537;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_538;
    unsigned int zT_539;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_540;
    unsigned char* zT_544;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_545;
    unsigned int zT_546;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_547;
    unsigned int zT_548;
    unsigned char* zT_550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_551;
    unsigned int zT_552;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_553;
    unsigned int zT_554;
    unsigned int* zT_555;
    unsigned char* zT_558;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_559;
    unsigned int zT_560;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_561;
    zT_38C12417_SemanticAnalyzer* zT_562;
    unsigned int zT_563;
    zT_38C12417_SemanticAnalyzer* zT_565;
    unsigned int zT_566;
    unsigned int* zT_567;
    unsigned int zT_569 = 0;
    zT_38C12417_SemanticAnalyzer* zT_570;
    zT_21D3708C_U32ToU32Map* zT_575;
    unsigned int zT_576;
    unsigned int zT_577;
    unsigned int* zT_579;
    zT_21D3708C_U32ToU32Map* zT_585;
    unsigned int zT_586;
    unsigned int zT_587;
    unsigned int* zT_589;
    zT_38C12417_SemanticAnalyzer* zT_592;
    unsigned int zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    unsigned int* zT_596;
    unsigned int zT_598 = 0;
    zT_338B7C76_TypeRegistry* zT_599;
    unsigned int zT_600;
    unsigned int zT_601;
    int zT_603 = 0;
    int zT_605;
    zT_38C12417_SemanticAnalyzer* zT_606;
    unsigned int zT_607;
    unsigned int zT_608;
    int zT_611 = 0;
    zT_6B0A7D14_AstStore* zT_613;
    unsigned int zT_614;
    unsigned int* zT_616;
    zT_22A7C88B_AstNode zT_618 = {0};
    unsigned int zT_620;
    unsigned int zT_622;
    unsigned int zT_624;
    unsigned char* zT_626;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_627;
    unsigned int zT_628;
    zT_F85C5DED_DiagnosticCollector* zT_630;
    unsigned int zT_633;
    unsigned int zT_634;
    unsigned int zT_635;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_636;
    unsigned int zT_641 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_642;
    unsigned int zT_643;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_644;
    zT_33EF6BFB_TypeKind zT_646;
    zT_338B7C76_TypeRegistry* zT_647;
    zT_D155D06D_Type* zT_648;
    unsigned int zT_649;
    zT_D155D06D_Type zT_650;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_652 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_653;
    unsigned int zT_654;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_655;
    zT_33EF6BFB_TypeKind zT_657;
    zT_338B7C76_TypeRegistry* zT_658;
    zT_D155D06D_Type* zT_659;
    unsigned int zT_660;
    zT_D155D06D_Type zT_661;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_663 = {0};
    zT_38C12417_SemanticAnalyzer* zT_664;
    unsigned int zT_665;
    unsigned int zT_666;
    unsigned int zT_667;
    unsigned int* zT_668;
    int zT_670;
    unsigned int zT_671;
    unsigned int zT_676;
    zT_38C12417_SemanticAnalyzer* zT_678;
    zT_38C12417_SemanticAnalyzer* zT_682;
    unsigned int zT_683;
    unsigned int* zT_684;
    unsigned int zT_686 = 0;
    zT_38C12417_SemanticAnalyzer* zT_687;
    zT_21D3708C_U32ToU32Map* zT_690;
    unsigned int zT_691;
    unsigned int zT_692;
    unsigned int* zT_694;
    int zT_696;
    unsigned int zT_697;
    unsigned char* zT_699;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_700;
    unsigned int zT_701;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_702;
    unsigned int zT_703;
    unsigned int zT_705;
    zT_8F083A69_Slice_zT_0B42B2F8_u fne;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode callee_node;
    unsigned int direct_ret;
    unsigned int decl_cap;
    zT_5979294E_Opt_849 sym;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u xf;
    zT_8F083A69_Slice_zT_0B42B2F8_u xs;
    zT_22A7C88B_AstNode dn;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 rt;
    unsigned int rnt_val;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u brnt_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfnr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u drfb_m;
    zT_ABC1EBBE_TypeResolveEnv tre_env_fc;
    unsigned int fc_rt;
    zT_8F083A69_Slice_zT_0B42B2F8_u brfc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn1r_m;
    zT_3CB0179A_Slice_zT_05F374B1_u args;
    unsigned char has_params;
    unsigned short pcount;
    unsigned int pstart;
    unsigned int callee_type;
    zT_BAEE192E_Opt_10 ft;
    unsigned int ai;
    unsigned int ftid;
    zT_8F083A69_Slice_zT_0B42B2F8_u sfm;
    zT_D155D06D_Type ft_ty;
    zT_0317B1D5_FnPayload ftp;
    unsigned int expected;
    unsigned int cpp_key;
    unsigned int dxc_at;
    unsigned int cpp_v;
    unsigned int carg_eff;
    zT_22A7C88B_AstNode argn;
    unsigned int csp;
    unsigned int cep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ctm_msg;
    unsigned int cdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn2;
    zT_D155D06D_Type callee_ty;
    zT_112BF819_PtrPayload cptr_pp;
    zT_D155D06D_Type cptr_pointee;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn3_ck_m;
    zT_3CB0179A_Slice_zT_05F374B1_u fn3_args;
    unsigned int fn3_i;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4a;
    zT_0317B1D5_FnPayload fnp;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4b;
    unsigned int pcount_1;
    unsigned int pstart_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4c;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4d;
    unsigned char is_var;
    unsigned int fixed;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4e;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4x_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4y_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4f;
    unsigned int param_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_am;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4g;
    unsigned int arg_type;
    unsigned int vi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fn4_rm;
    unsigned int varg_type;
    zT_3 = "FNE\n";
    zT_5 = 4;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fne = zT_4;
    zT_6 = fne;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node.child_0;
    zT_17 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    callee_node = zT_17;
    zT_19 = 0;
    direct_ret = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    decl_cap = zT_22;
    zT_23 = callee_node.kind;
    if ((int)(zT_23 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_29 = self->symbols;
    zT_30 = self->module_id;
    zT_34 = self->store;
    zT_35 = node.child_0;
    zT_38 = zF_53458827_astStoreIdentifier(zT_34, zT_35);
    zT_31 = zT_38;
    zT_39 = zF_A398987E_symbolRegistryQuali(zT_29, zT_30, zT_31);
    sym = zT_39;
    zT_40 = sym.has_value;
    if (zT_40) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    if ((int)(direct_ret != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    s = sym.value;
    zT_43 = "XF\n";
    zT_45 = 3;
    zT_44.ptr = zT_43;
    zT_44.len = zT_45;
    xf = zT_44;
    zT_46 = xf;
    zF_48AC7B3A_markerWrite(zT_46);
    zT_47 = s->decl_node;
    decl_cap = zT_47;
    zT_48 = s->type_id;
    if ((int)(zT_48 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_150 = "xS\n";
    zT_152 = 3;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    xs = zT_151;
    zT_153 = xs;
    zF_48AC7B3A_markerWrite(zT_153);
    goto z_bb_4;
    z_bb_6:
    zT_51 = self->type_table;
    zT_52 = node.child_0;
    zT_53 = s->type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_51, zT_52, zT_53);
    goto z_bb_7;
    z_bb_7:
    zT_57 = s->kind;
    if ((int)(zT_57 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_function))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_63 = s->decl_node;
    zT_62 = zT_63 != (unsigned int)(0);
    goto z_bb_10;
    z_bb_9:
    zT_62 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_62) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_67 = self->store;
    zT_68 = s->decl_node;
    zT_71 = zF_FCDD1D35_astStoreNodeAt(zT_67, zT_68);
    dn = zT_71;
    zT_72 = dn.kind;
    if ((int)(zT_72 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_4;
    z_bb_13:
    zT_78 = self->store;
    zT_79 = zT_78->fn_protos;
    zT_80 = zT_79.items;
    zT_81 = self->store;
    zT_82 = s->decl_node;
    zT_85 = zF_8BA26B9E_astStoreNodePayload(zT_81, zT_82);
    zT_86 = (unsigned int)zT_85;
    zT_87 = zT_80[zT_86];
    proto = zT_87;
    zT_88 = proto.return_type_node;
    if ((int)(zT_88 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_92 = self->type_table;
    zT_93 = proto.return_type_node;
    zT_96 = zF_999DCF51_resolvedTypeTableGe(zT_92, zT_93);
    rt = zT_96;
    zT_98 = rt.has_value;
    if (zT_98) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    t = rt.value;
    zT_99 = t;
    goto z_bb_19;
    z_bb_18:
    zT_99 = 0;
    goto z_bb_19;
    z_bb_19:
    rnt_val = zT_99;
    zT_103 = "BR:rnt";
    zT_105 = 6;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    brnt_m = zT_104;
    zT_106 = brnt_m;
    zT_107 = rnt_val;
    zF_C914CB83_markerWriteInt(zT_106, zT_107);
    zT_108 = rt.has_value;
    if (zT_108) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    t = rt.value;
    direct_ret = t;
    goto z_bb_21;
    z_bb_21:
    zT_144 = "BR:fnr";
    zT_146 = 6;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    brfnr_m = zT_145;
    zT_147 = brfnr_m;
    zT_148 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_147, zT_148);
    goto z_bb_16;
    z_bb_22:
    zT_111 = "DRETFB:n";
    zT_113 = 8;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    drfb_m = zT_112;
    zT_114 = drfb_m;
    zT_115 = node_idx;
    zF_C914CB83_markerWriteInt(zT_114, zT_115);
    zT_118 = self->store;
    zT_117.store = zT_118;
    zT_119 = self->registry;
    zT_117.typereg = zT_119;
    zT_120 = self->symbols;
    zT_117.symbol_reg = zT_120;
    zT_121 = self->interner;
    zT_117.interner = zT_121;
    zT_122 = s->module_id;
    zT_117.module_id = zT_122;
    zT_123 = self->diag;
    zT_124.has_value = 1;
    zT_124.value = zT_123;
    zT_117.diag = zT_124;
    zT_125.has_value = 0;
    zT_117.local_consts = zT_125;
    zT_126 = self->source_file_id;
    zT_117.source_file_id = zT_126;
    tre_env_fc = zT_117;
    zT_128 = &tre_env_fc;
    zT_129 = proto.return_type_node;
    zT_134 = zF_F2107C15_resolveTypeExprFull(zT_128, zT_129, (unsigned int)(0));
    fc_rt = zT_134;
    zT_136 = "BR:fc";
    zT_138 = 5;
    zT_137.ptr = zT_136;
    zT_137.len = zT_138;
    brfc_m = zT_137;
    zT_139 = brfc_m;
    zT_140 = fc_rt;
    zF_C914CB83_markerWriteInt(zT_139, zT_140);
    if ((int)(fc_rt != (unsigned int)(18))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    direct_ret = fc_rt;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_157 = "FN1\n";
    zT_159 = 4;
    zT_158.ptr = zT_157;
    zT_158.len = zT_159;
    fn1 = zT_158;
    zT_160 = fn1;
    zF_48AC7B3A_markerWrite(zT_160);
    zT_162 = "FN1:R";
    zT_164 = 5;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    fn1r_m = zT_163;
    zT_165 = fn1r_m;
    zT_166 = direct_ret;
    zF_C914CB83_markerWriteInt(zT_165, zT_166);
    zT_168 = self->store;
    zT_169 = node_idx;
    zT_171 = zF_850FDF81_astStoreNodeExtraCh(zT_168, zT_169);
    args = zT_171;
    zT_173 = 0;
    has_params = zT_173;
    zT_175 = 0;
    pcount = zT_175;
    zT_177 = 0;
    pstart = zT_177;
    zT_178 = 0;
    if ((int)(decl_cap != (unsigned int)zT_178)) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_348 = self;
    zT_349 = node.child_0;
    zT_351 = zF_54F95822_semanticAnalyzerRes(zT_348, zT_349);
    callee_type = zT_351;
    if ((int)(callee_type == (unsigned int)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_27:
    zT_181 = self->type_table;
    zT_182 = decl_cap;
    zT_184 = zF_999DCF51_resolvedTypeTableGe(zT_181, zT_182);
    ft = zT_184;
    zT_185 = ft.has_value;
    if (zT_185) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_212 = 0;
    zT_213 = (unsigned int)zT_212;
    ai = zT_213;
    goto z_bb_33;
    z_bb_29:
    ftid = ft.value;
    zT_188 = "SF:H\n";
    zT_190 = 5;
    zT_189.ptr = zT_188;
    zT_189.len = zT_190;
    sfm = zT_189;
    zT_191 = sfm;
    zF_48AC7B3A_markerWrite(zT_191);
    zT_193 = self->registry;
    zT_194 = zT_193->types_items;
    zT_195 = (unsigned int)ftid;
    zT_196 = zT_194[zT_195];
    ft_ty = zT_196;
    zT_197 = ft_ty.kind;
    if ((int)(zT_197 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_203 = self->registry;
    zT_204 = zT_203->fn_items;
    zT_205 = ft_ty.payload_idx;
    zT_206 = (unsigned int)zT_205;
    zT_207 = zT_204[zT_206];
    ftp = zT_207;
    zT_208 = ftp.params_count;
    pcount = zT_208;
    zT_209 = ftp.params_start;
    pstart = zT_209;
    zT_210 = 1;
    has_params = zT_210;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_215 = args.len;
    if ((int)(ai < zT_215)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_218 = 0;
    expected = zT_218;
    if ((int)(has_params != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_343 = self->type_table;
    zT_344 = node_idx;
    zT_345 = direct_ret;
    zF_19B4A07D_resolvedTypeTableSe(zT_343, zT_344, zT_345);
    return direct_ret;
    z_bb_36:
    zT_341 = 1;
    zT_342 = ai + zT_341;
    ai = zT_342;
    goto z_bb_33;
    z_bb_37:
    zT_221 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_39;
    z_bb_38:
    zT_221 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_221) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_229 = (unsigned int)((unsigned int)((unsigned int)decl_cap) << (unsigned int)(16)) | (unsigned int)((unsigned int)ai);
    cpp_key = zT_229;
    zT_230 = 18;
    expected = zT_230;
    zT_231 = self->call_param_map;
    zT_232 = cpp_key;
    zT_234 = zF_F3EE5998_u32ToU32MapGet(zT_231, zT_232);
    zT_235 = zT_234.has_value;
    if (zT_235) goto z_bb_42; else goto z_bb_44;
    z_bb_41:
    zT_248 = self;
    zT_249 = expected;
    zF_9665A229_pushExpectedType(zT_248, zT_249);
    zT_251 = self;
    zT_253 = args.ptr;
    zT_252 = zT_253[ai];
    zT_255 = zF_54F95822_semanticAnalyzerRes(zT_251, zT_252);
    dxc_at = zT_255;
    zT_256 = self;
    zF_BC478E78_popExpectedType(zT_256);
    if ((int)(has_params != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_42:
    cpp_v = zT_234.value;
    expected = cpp_v;
    goto z_bb_43;
    z_bb_43:
    zT_242 = self->call_arg_types;
    zT_246 = args.ptr;
    zT_243 = zT_246[ai];
    zT_244 = expected;
    zF_26476265_u32ToU32MapPut(zT_242, zT_243, zT_244);
    goto z_bb_41;
    z_bb_44:
    zT_237 = self->registry;
    zT_238 = zT_237->xt_items;
    zT_240 = (unsigned int)((unsigned int)pstart) + ai;
    zT_241 = zT_238[zT_240];
    expected = zT_241;
    goto z_bb_43;
    z_bb_45:
    zT_259 = ai < (unsigned int)((unsigned int)pcount);
    goto z_bb_47;
    z_bb_46:
    zT_259 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_259) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_263 = self;
    zT_267 = args.ptr;
    zT_264 = zT_267[ai];
    zT_265 = expected;
    zT_266 = dxc_at;
    zT_269 = zF_FFC95E09_errLitSrcType(zT_263, zT_264, zT_265, zT_266);
    carg_eff = zT_269;
    zT_270 = self->registry;
    zT_271 = carg_eff;
    zT_272 = expected;
    zT_274 = zF_683AEB7F_typeRegistryIsAssig(zT_270, zT_271, zT_272);
    if ((int)(!zT_274)) goto z_bb_50; else goto z_bb_51;
    z_bb_49:
    goto z_bb_36;
    z_bb_50:
    zT_277 = self;
    zT_278 = carg_eff;
    zT_279 = expected;
    zT_282 = zF_D728034A_isBShapeMismatch(zT_277, zT_278, zT_279, (int)(0));
    zT_276 = zT_282;
    goto z_bb_52;
    z_bb_51:
    zT_276 = 0;
    goto z_bb_52;
    z_bb_52:
    if (zT_276) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_284 = self->store;
    zT_287 = args.ptr;
    zT_285 = zT_287[ai];
    zT_289 = zF_FCDD1D35_astStoreNodeAt(zT_284, zT_285);
    argn = zT_289;
    zT_291 = argn.span_start;
    csp = zT_291;
    zT_293 = argn.span_len;
    zT_295 = csp + (unsigned int)((unsigned int)zT_293);
    cep = zT_295;
    zT_297 = "type mismatch in function argument — argument type may not be compatible with the parameter type";
    zT_299 = 98;
    zT_298.ptr = zT_297;
    zT_298.len = zT_299;
    ctm_msg = zT_298;
    zT_301 = self->diag;
    zT_304 = self->source_file_id;
    zT_305 = csp;
    zT_306 = cep;
    zT_307 = ctm_msg;
    zT_312 = zF_C82559AC_diagnosticCollector(zT_301, (unsigned char)(0), (unsigned short)(3000), zT_304, zT_305, zT_306, zT_307);
    cdi = zT_312;
    zT_313 = self->diag;
    zT_314 = cdi;
    zT_318 = self->registry;
    zT_319 = zT_318->types_items;
    zT_320 = (unsigned int)carg_eff;
    zT_321 = zT_319[zT_320];
    zT_317 = zT_321.kind;
    zT_323 = zF_C14453DE_typeKindSrcStr(zT_317);
    zT_315 = zT_323;
    zF_426E1F18_diagnosticCollector(zT_313, zT_314, zT_315);
    (void)self;
    zT_324 = self->diag;
    zT_325 = cdi;
    zT_329 = self->registry;
    zT_330 = zT_329->types_items;
    zT_331 = (unsigned int)expected;
    zT_332 = zT_330[zT_331];
    zT_328 = zT_332.kind;
    zT_334 = zF_CC479241_typeKindTgtStr(zT_328);
    zT_326 = zT_334;
    zF_426E1F18_diagnosticCollector(zT_324, zT_325, zT_326);
    (void)self;
    goto z_bb_54;
    z_bb_54:
    zT_335 = self;
    zT_339 = args.ptr;
    zT_336 = zT_339[ai];
    zT_337 = carg_eff;
    zT_338 = expected;
    zF_DF7434EB_tryRecordCoercion(zT_335, zT_336, zT_337, zT_338);
    goto z_bb_49;
    z_bb_55:
    zT_355 = "FN2\n";
    zT_357 = 4;
    zT_356.ptr = zT_355;
    zT_356.len = zT_357;
    fn2 = zT_356;
    zT_358 = fn2;
    zF_48AC7B3A_markerWrite(zT_358);
    return (unsigned int)(1);
    z_bb_56:
    zT_361 = self->registry;
    zT_362 = zT_361->types_items;
    zT_363 = (unsigned int)callee_type;
    zT_364 = zT_362[zT_363];
    callee_ty = zT_364;
    zT_365 = callee_ty.kind;
    if ((int)(zT_365 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_371 = self->registry;
    zT_372 = zT_371->ptr_items;
    zT_373 = callee_ty.payload_idx;
    zT_374 = (unsigned int)zT_373;
    zT_375 = zT_372[zT_374];
    cptr_pp = zT_375;
    zT_377 = self->registry;
    zT_378 = zT_377->types_items;
    zT_379 = cptr_pp.base;
    zT_380 = (unsigned int)zT_379;
    zT_381 = zT_378[zT_380];
    cptr_pointee = zT_381;
    zT_382 = cptr_pointee.kind;
    if ((int)(zT_382 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    zT_392 = callee_ty.kind;
    if ((int)(zT_392 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    zT_387 = cptr_pp.base;
    callee_type = zT_387;
    zT_388 = self->registry;
    zT_389 = zT_388->types_items;
    zT_390 = (unsigned int)callee_type;
    zT_391 = zT_389[zT_390];
    callee_ty = zT_391;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    zT_398 = "FN3:N";
    zT_400 = 5;
    zT_399.ptr = zT_398;
    zT_399.len = zT_400;
    fn3 = zT_399;
    zT_401 = fn3;
    zT_402 = node_idx;
    zF_C914CB83_markerWriteInt(zT_401, zT_402);
    zT_404 = "FN3:T";
    zT_406 = 5;
    zT_405.ptr = zT_404;
    zT_405.len = zT_406;
    fn3_ct_m = zT_405;
    zT_407 = fn3_ct_m;
    zT_408 = callee_type;
    zF_C914CB83_markerWriteInt(zT_407, zT_408);
    zT_410 = "FN3:K";
    zT_412 = 5;
    zT_411.ptr = zT_410;
    zT_411.len = zT_412;
    fn3_ck_m = zT_411;
    zT_413 = fn3_ck_m;
    zT_415 = callee_ty.kind;
    zF_C914CB83_markerWriteInt(zT_413, (unsigned int)((unsigned int)zT_415));
    zT_418 = self->store;
    zT_419 = node_idx;
    zT_421 = zF_850FDF81_astStoreNodeExtraCh(zT_418, zT_419);
    fn3_args = zT_421;
    zT_423 = 0;
    fn3_i = zT_423;
    goto z_bb_63;
    z_bb_62:
    zT_440 = "FN4a\n";
    zT_442 = 5;
    zT_441.ptr = zT_440;
    zT_441.len = zT_442;
    fn4a = zT_441;
    zT_443 = fn4a;
    zF_48AC7B3A_markerWrite(zT_443);
    zT_445 = self->registry;
    zT_446 = zT_445->fn_items;
    zT_447 = callee_ty.payload_idx;
    zT_448 = (unsigned int)zT_447;
    zT_449 = zT_446[zT_448];
    fnp = zT_449;
    zT_451 = "FN4b\n";
    zT_453 = 5;
    zT_452.ptr = zT_451;
    zT_452.len = zT_453;
    fn4b = zT_452;
    zT_454 = fn4b;
    zF_48AC7B3A_markerWrite(zT_454);
    zT_456 = fnp.params_count;
    zT_457 = (unsigned int)zT_456;
    pcount_1 = zT_457;
    zT_459 = fnp.params_start;
    zT_460 = (unsigned int)zT_459;
    pstart_2 = zT_460;
    zT_462 = "FN4c\n";
    zT_464 = 5;
    zT_463.ptr = zT_462;
    zT_463.len = zT_464;
    fn4c = zT_463;
    zT_465 = fn4c;
    zF_48AC7B3A_markerWrite(zT_465);
    zT_467 = self->store;
    zT_468 = node_idx;
    zT_470 = zF_850FDF81_astStoreNodeExtraCh(zT_467, zT_468);
    args = zT_470;
    zT_472 = "FN4d\n";
    zT_474 = 5;
    zT_473.ptr = zT_472;
    zT_473.len = zT_474;
    fn4d = zT_473;
    zT_475 = fn4d;
    zF_48AC7B3A_markerWrite(zT_475);
    zT_477 = 0;
    is_var = zT_477;
    zT_478 = fnp.flags_packed;
    if ((int)((unsigned char)(zT_478 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_63:
    zT_425 = fn3_args.len;
    if ((int)(fn3_i < zT_425)) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_427 = self;
    zF_9665A229_pushExpectedType(zT_427, (unsigned int)(0));
    zT_430 = self;
    zT_432 = fn3_args.ptr;
    zT_431 = zT_432[fn3_i];
    zT_434 = zF_54F95822_semanticAnalyzerRes(zT_430, zT_431);
    (void)zT_434;
    zT_435 = self;
    zF_BC478E78_popExpectedType(zT_435);
    goto z_bb_66;
    z_bb_65:
    return (unsigned int)(1);
    z_bb_66:
    zT_437 = fn3_i + (unsigned int)(1);
    fn3_i = zT_437;
    goto z_bb_63;
    z_bb_67:
    zT_483 = 1;
    is_var = zT_483;
    goto z_bb_68;
    z_bb_68:
    fixed = pcount_1;
    if ((int)(is_var != (unsigned char)(0))) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    zT_488 = args.len;
    if ((int)(zT_488 < fixed)) goto z_bb_72; else goto z_bb_73;
    z_bb_70:
    zT_496 = 0;
    zT_497 = (unsigned int)zT_496;
    ai = zT_497;
    zT_499 = "FN4e\n";
    zT_501 = 5;
    zT_500.ptr = zT_499;
    zT_500.len = zT_501;
    fn4e = zT_500;
    zT_502 = fn4e;
    zF_48AC7B3A_markerWrite(zT_502);
    zT_504 = "FN4x:X";
    zT_506 = 6;
    zT_505.ptr = zT_504;
    zT_505.len = zT_506;
    fn4x_m = zT_505;
    zT_507 = fn4x_m;
    zT_509 = self->registry;
    zT_510 = zT_509->xt_len;
    zF_C914CB83_markerWriteInt(zT_507, (unsigned int)((unsigned int)zT_510));
    zT_513 = "FN4y:P";
    zT_515 = 6;
    zT_514.ptr = zT_513;
    zT_514.len = zT_515;
    fn4y_m = zT_514;
    zT_516 = fn4y_m;
    zF_C914CB83_markerWriteInt(zT_516, (unsigned int)((unsigned int)pstart_2));
    goto z_bb_76;
    z_bb_71:
    zT_492 = args.len;
    if ((int)(zT_492 != pcount_1)) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_490 = fnp.return_type;
    return zT_490;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    zT_494 = fnp.return_type;
    return zT_494;
    z_bb_75:
    goto z_bb_70;
    z_bb_76:
    if ((int)(ai < fixed)) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_521 = "FN4f\n";
    zT_523 = 5;
    zT_522.ptr = zT_521;
    zT_522.len = zT_523;
    fn4f = zT_522;
    zT_524 = fn4f;
    zF_48AC7B3A_markerWrite(zT_524);
    zT_526 = self->registry;
    zT_527 = zT_526->xt_items;
    zT_528 = pstart_2 + ai;
    zT_529 = zT_527[zT_528];
    param_type = zT_529;
    zT_530 = self->call_arg_types;
    zT_534 = args.ptr;
    zT_531 = zT_534[ai];
    zT_532 = param_type;
    zF_26476265_u32ToU32MapPut(zT_530, zT_531, zT_532);
    zT_537 = "PTM:A";
    zT_539 = 5;
    zT_538.ptr = zT_537;
    zT_538.len = zT_539;
    ptm_am = zT_538;
    zT_540 = ptm_am;
    zF_C914CB83_markerWriteInt(zT_540, (unsigned int)((unsigned int)ai));
    zT_544 = "PTM:T";
    zT_546 = 5;
    zT_545.ptr = zT_544;
    zT_545.len = zT_546;
    ptm_tm = zT_545;
    zT_547 = ptm_tm;
    zT_548 = param_type;
    zF_C914CB83_markerWriteInt(zT_547, zT_548);
    zT_550 = "PTM:N";
    zT_552 = 5;
    zT_551.ptr = zT_550;
    zT_551.len = zT_552;
    ptm_nm = zT_551;
    zT_553 = ptm_nm;
    zT_555 = args.ptr;
    zT_554 = zT_555[ai];
    zF_C914CB83_markerWriteInt(zT_553, zT_554);
    zT_558 = "FN4g\n";
    zT_560 = 5;
    zT_559.ptr = zT_558;
    zT_559.len = zT_560;
    fn4g = zT_559;
    zT_561 = fn4g;
    zF_48AC7B3A_markerWrite(zT_561);
    zT_562 = self;
    zT_563 = param_type;
    zF_9665A229_pushExpectedType(zT_562, zT_563);
    zT_565 = self;
    zT_567 = args.ptr;
    zT_566 = zT_567[ai];
    zT_569 = zF_54F95822_semanticAnalyzerRes(zT_565, zT_566);
    arg_type = zT_569;
    zT_570 = self;
    zF_BC478E78_popExpectedType(zT_570);
    if ((int)(param_type == (unsigned int)(18))) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    if ((int)(is_var != (unsigned char)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_79:
    zT_670 = 1;
    zT_671 = ai + zT_670;
    ai = zT_671;
    goto z_bb_76;
    z_bb_80:
    if ((int)(arg_type != (unsigned int)(18))) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    if ((int)(param_type == (unsigned int)(1))) goto z_bb_84; else goto z_bb_85;
    z_bb_82:
    zT_575 = self->call_arg_types;
    zT_579 = args.ptr;
    zT_576 = zT_579[ai];
    zT_577 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_575, zT_576, zT_577);
    goto z_bb_83;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    if ((int)(arg_type != (unsigned int)(18))) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    zT_592 = self;
    zT_596 = args.ptr;
    zT_593 = zT_596[ai];
    zT_594 = param_type;
    zT_595 = arg_type;
    zT_598 = zF_FFC95E09_errLitSrcType(zT_592, zT_593, zT_594, zT_595);
    carg_eff = zT_598;
    zT_599 = self->registry;
    zT_600 = carg_eff;
    zT_601 = param_type;
    zT_603 = zF_683AEB7F_typeRegistryIsAssig(zT_599, zT_600, zT_601);
    if ((int)(!zT_603)) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    zT_585 = self->call_arg_types;
    zT_589 = args.ptr;
    zT_586 = zT_589[ai];
    zT_587 = arg_type;
    zF_26476265_u32ToU32MapPut(zT_585, zT_586, zT_587);
    goto z_bb_87;
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_606 = self;
    zT_607 = carg_eff;
    zT_608 = param_type;
    zT_611 = zF_D728034A_isBShapeMismatch(zT_606, zT_607, zT_608, (int)(0));
    zT_605 = zT_611;
    goto z_bb_90;
    z_bb_89:
    zT_605 = 0;
    goto z_bb_90;
    z_bb_90:
    if (zT_605) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_613 = self->store;
    zT_616 = args.ptr;
    zT_614 = zT_616[ai];
    zT_618 = zF_FCDD1D35_astStoreNodeAt(zT_613, zT_614);
    argn = zT_618;
    zT_620 = argn.span_start;
    csp = zT_620;
    zT_622 = argn.span_len;
    zT_624 = csp + (unsigned int)((unsigned int)zT_622);
    cep = zT_624;
    zT_626 = "type mismatch in function argument — argument type may not be compatible with the parameter type";
    zT_628 = 98;
    zT_627.ptr = zT_626;
    zT_627.len = zT_628;
    ctm_msg = zT_627;
    zT_630 = self->diag;
    zT_633 = self->source_file_id;
    zT_634 = csp;
    zT_635 = cep;
    zT_636 = ctm_msg;
    zT_641 = zF_C82559AC_diagnosticCollector(zT_630, (unsigned char)(0), (unsigned short)(3000), zT_633, zT_634, zT_635, zT_636);
    cdi = zT_641;
    zT_642 = self->diag;
    zT_643 = cdi;
    zT_647 = self->registry;
    zT_648 = zT_647->types_items;
    zT_649 = (unsigned int)carg_eff;
    zT_650 = zT_648[zT_649];
    zT_646 = zT_650.kind;
    zT_652 = zF_C14453DE_typeKindSrcStr(zT_646);
    zT_644 = zT_652;
    zF_426E1F18_diagnosticCollector(zT_642, zT_643, zT_644);
    (void)self;
    zT_653 = self->diag;
    zT_654 = cdi;
    zT_658 = self->registry;
    zT_659 = zT_658->types_items;
    zT_660 = (unsigned int)param_type;
    zT_661 = zT_659[zT_660];
    zT_657 = zT_661.kind;
    zT_663 = zF_CC479241_typeKindTgtStr(zT_657);
    zT_655 = zT_663;
    zF_426E1F18_diagnosticCollector(zT_653, zT_654, zT_655);
    (void)self;
    goto z_bb_92;
    z_bb_92:
    zT_664 = self;
    zT_668 = args.ptr;
    zT_665 = zT_668[ai];
    zT_666 = carg_eff;
    zT_667 = param_type;
    zF_DF7434EB_tryRecordCoercion(zT_664, zT_665, zT_666, zT_667);
    goto z_bb_79;
    z_bb_93:
    vi = fixed;
    goto z_bb_95;
    z_bb_94:
    zT_699 = "FN4:R";
    zT_701 = 5;
    zT_700.ptr = zT_699;
    zT_700.len = zT_701;
    fn4_rm = zT_700;
    zT_702 = fn4_rm;
    zT_703 = fnp.return_type;
    zF_C914CB83_markerWriteInt(zT_702, zT_703);
    zT_705 = fnp.return_type;
    return zT_705;
    z_bb_95:
    zT_676 = args.len;
    if ((int)(vi < zT_676)) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_678 = self;
    zF_9665A229_pushExpectedType(zT_678, (unsigned int)(0));
    zT_682 = self;
    zT_684 = args.ptr;
    zT_683 = zT_684[vi];
    zT_686 = zF_54F95822_semanticAnalyzerRes(zT_682, zT_683);
    varg_type = zT_686;
    zT_687 = self;
    zF_BC478E78_popExpectedType(zT_687);
    if ((int)(varg_type != (unsigned int)(18))) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    goto z_bb_94;
    z_bb_98:
    zT_696 = 1;
    zT_697 = vi + zT_696;
    vi = zT_697;
    goto z_bb_95;
    z_bb_99:
    zT_690 = self->call_arg_types;
    zT_694 = args.ptr;
    zT_691 = zT_694[vi];
    zT_692 = varg_type;
    zF_26476265_u32ToU32MapPut(zT_690, zT_691, zT_692);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_98;
}

/* semanticAnalyzerResolveTryExpr */
unsigned int zF_B78F27CD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_42C2D6BF_EUPayload* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_42C2D6BF_EUPayload zT_34;
    unsigned int zT_35;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    zT_42C2D6BF_EUPayload eu;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((int)(zT_23 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned int)(1);
    z_bb_7:
    zT_30 = self->registry;
    zT_31 = zT_30->eu_items;
    zT_32 = ty.payload_idx;
    zT_33 = (unsigned int)zT_32;
    zT_34 = zT_31[zT_33];
    eu = zT_34;
    zT_35 = eu.payload;
    return zT_35;
}

/* semanticAnalyzerResolveOrelseExpr */
unsigned int zF_B36961FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_D155D06D_Type* zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type zT_22;
    zT_33EF6BFB_TypeKind zT_23;
    int zT_28;
    unsigned int zT_29;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_D155D06D_Type* zT_43;
    unsigned int zT_44;
    zT_D155D06D_Type zT_45;
    zT_33EF6BFB_TypeKind zT_47;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_0B10E8E9_OptionalPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_0B10E8E9_OptionalPayload zT_57;
    unsigned int zT_58;
    zT_338B7C76_TypeRegistry* zT_60;
    unsigned int zT_61;
    unsigned int zT_63 = 0;
    zT_66E7D2EF_CoercionTable* zT_64;
    unsigned int zT_65;
    unsigned int zT_67;
    zT_33EF6BFB_TypeKind zT_74;
    zT_33EF6BFB_TypeKind zT_79;
    int zT_84;
    zT_33EF6BFB_TypeKind zT_85;
    int zT_90;
    unsigned char* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_97;
    zT_F85C5DED_DiagnosticCollector* zT_98;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_117 = 0;
    zT_338B7C76_TypeRegistry* zT_120;
    zT_0B10E8E9_OptionalPayload* zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    zT_0B10E8E9_OptionalPayload zT_124;
    zT_66E7D2EF_CoercionTable* zT_125;
    unsigned int zT_126;
    unsigned int zT_128;
    unsigned int zT_135;
    zT_38C12417_SemanticAnalyzer* zT_138;
    unsigned int zT_139;
    zT_38C12417_SemanticAnalyzer* zT_142;
    unsigned int zT_143;
    unsigned int zT_145 = 0;
    zT_38C12417_SemanticAnalyzer* zT_146;
    int zT_149;
    zT_38C12417_SemanticAnalyzer* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_158;
    zT_22A7C88B_AstNode node;
    unsigned int inner;
    zT_D155D06D_Type ty;
    unsigned int expected;
    zT_D155D06D_Type oe_et;
    unsigned int payload_type;
    zT_0B10E8E9_OptionalPayload oe_opt;
    unsigned int opt_target;
    zT_0B10E8E9_OptionalPayload opt;
    zT_8F083A69_Slice_zT_0B42B2F8_u oe_msg;
    unsigned int rhs_result;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    inner = zT_11;
    if ((int)(inner == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_14 = inner == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_14 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(1);
    z_bb_5:
    zT_19 = self->registry;
    zT_20 = zT_19->types_items;
    zT_21 = (unsigned int)inner;
    zT_22 = zT_20[zT_21];
    ty = zT_22;
    zT_23 = ty.kind;
    if ((int)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_29 = self->expected_type_stack_len;
    zT_28 = zT_29 > (unsigned int)(0);
    goto z_bb_8;
    z_bb_7:
    zT_28 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_28) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = self->expected_type_stack_items;
    zT_34 = self->expected_type_stack_len;
    zT_37 = (unsigned int)(unsigned int)(zT_34 - (unsigned int)(1));
    zT_38 = zT_33[zT_37];
    expected = zT_38;
    if ((int)(expected != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_74 = ty.kind;
    if ((int)(zT_74 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_11:
    zT_42 = self->registry;
    zT_43 = zT_42->types_items;
    zT_44 = (unsigned int)expected;
    zT_45 = zT_43[zT_44];
    oe_et = zT_45;
    payload_type = expected;
    zT_47 = oe_et.kind;
    if ((int)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_53 = self->registry;
    zT_54 = zT_53->opt_items;
    zT_55 = oe_et.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    oe_opt = zT_57;
    zT_58 = oe_opt.payload;
    payload_type = zT_58;
    goto z_bb_14;
    z_bb_14:
    zT_60 = self->registry;
    zT_61 = payload_type;
    zT_63 = zF_74A7234F_typeRegistryGetOrCr(zT_60, zT_61);
    opt_target = zT_63;
    zT_64 = self->coercion_table;
    zT_65 = node.child_0;
    zT_67 = opt_target;
    zF_D21AE60A_coercionTableAdd(zT_64, zT_65, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional_null), zT_67);
    return payload_type;
    z_bb_15:
    zT_79 = ty.kind;
    if ((int)(zT_79 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_18; else goto z_bb_17;
    z_bb_16:
    zT_120 = self->registry;
    zT_121 = zT_120->opt_items;
    zT_122 = ty.payload_idx;
    zT_123 = (unsigned int)zT_122;
    zT_124 = zT_121[zT_123];
    opt = zT_124;
    zT_125 = self->coercion_table;
    zT_126 = node.child_0;
    zT_128 = opt.payload;
    zF_D21AE60A_coercionTableAdd(zT_125, zT_126, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_128);
    zT_135 = node.child_1;
    if ((int)(zT_135 != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_17:
    zT_85 = ty.kind;
    zT_84 = zT_85 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_19;
    z_bb_18:
    zT_84 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_84) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_90 = inner == (unsigned int)(3);
    goto z_bb_22;
    z_bb_21:
    zT_90 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_90) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned int)(1);
    z_bb_24:
    zT_95 = "orelse requires an optional operand; use 'catch' for error unions";
    zT_97 = 65;
    zT_96.ptr = zT_95;
    zT_96.len = zT_97;
    oe_msg = zT_96;
    zT_98 = self->diag;
    zT_101 = self->source_file_id;
    zT_102 = node.span_start;
    zT_113 = node.span_start;
    zT_114 = node.span_len;
    zT_104 = oe_msg;
    zT_117 = zF_C82559AC_diagnosticCollector(zT_98, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3016_ORELSE_REQUIRES_OPTIONAL)), zT_101, zT_102, (unsigned int)(zT_113 + (unsigned int)((unsigned int)zT_114)), zT_104);
    (void)zT_117;
    return (unsigned int)(18);
    z_bb_25:
    zT_138 = self;
    zT_139 = opt.payload;
    zF_9665A229_pushExpectedType(zT_138, zT_139);
    zT_142 = self;
    zT_143 = node.child_1;
    zT_145 = zF_54F95822_semanticAnalyzerRes(zT_142, zT_143);
    rhs_result = zT_145;
    zT_146 = self;
    zF_BC478E78_popExpectedType(zT_146);
    if ((int)(rhs_result != (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_158 = opt.payload;
    return zT_158;
    z_bb_27:
    zT_149 = rhs_result != (unsigned int)(1);
    goto z_bb_29;
    z_bb_28:
    zT_149 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_149) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_152 = self;
    zT_153 = node.child_1;
    zT_154 = rhs_result;
    zT_155 = opt.payload;
    zF_DF7434EB_tryRecordCoercion(zT_152, zT_153, zT_154, zT_155);
    goto z_bb_31;
    z_bb_31:
    goto z_bb_26;
}

/* semanticAnalyzerResolveIfExpr */
unsigned int zF_8B8EE70D_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    unsigned int zT_14;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8EED1867_ResolvedTypeTable* zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    zT_38C12417_SemanticAnalyzer* zT_44;
    unsigned int zT_45 = 0;
    int zT_48;
    int zT_54;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    zT_22A7C88B_AstNode zT_59 = {0};
    zT_8143F551_AstKind zT_60;
    int zT_68;
    zT_6B0A7D14_AstStore* zT_69;
    unsigned int zT_70;
    zT_22A7C88B_AstNode zT_73 = {0};
    zT_8143F551_AstKind zT_74;
    int zT_79;
    zT_338B7C76_TypeRegistry* zT_80;
    unsigned int zT_86 = 0;
    int zT_89;
    int zT_95;
    zT_0FB7FB13_CoercionKind zT_96;
    zT_338B7C76_TypeRegistry* zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    zT_0FB7FB13_CoercionKind zT_101 = 0;
    int zT_102 = 0;
    int zT_106;
    zT_0FB7FB13_CoercionKind zT_107;
    zT_338B7C76_TypeRegistry* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_0FB7FB13_CoercionKind zT_112 = 0;
    int zT_113 = 0;
    int zT_116;
    int zT_119;
    int zT_120;
    zT_338B7C76_TypeRegistry* zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    int zT_125 = 0;
    int zT_128;
    int zT_131;
    int zT_132;
    zT_338B7C76_TypeRegistry* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    int zT_137 = 0;
    int zT_138;
    zT_38C12417_SemanticAnalyzer* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_38C12417_SemanticAnalyzer* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_8EED1867_ResolvedTypeTable* zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned char* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    zT_8EED1867_ResolvedTypeTable* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned char* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190;
    unsigned char* zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    zT_8EED1867_ResolvedTypeTable* zT_196;
    unsigned int zT_197;
    unsigned int zT_198;
    unsigned char* zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    unsigned int zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207;
    unsigned char* zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned int zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned int zT_213;
    unsigned char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    zT_8EED1867_ResolvedTypeTable* zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    int zT_225;
    zT_338B7C76_TypeRegistry* zT_226;
    unsigned int zT_227;
    int zT_229 = 0;
    unsigned char* zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235;
    unsigned char* zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned int zT_239;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_240;
    unsigned int zT_241;
    unsigned char* zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned int zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    zT_66E7D2EF_CoercionTable* zT_247;
    unsigned int zT_248;
    unsigned int zT_250;
    zT_8EED1867_ResolvedTypeTable* zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    int zT_262;
    zT_338B7C76_TypeRegistry* zT_263;
    unsigned int zT_264;
    int zT_266 = 0;
    unsigned char* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    unsigned char* zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    unsigned int zT_278;
    unsigned char* zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    unsigned int zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    zT_66E7D2EF_CoercionTable* zT_284;
    unsigned int zT_285;
    unsigned int zT_287;
    zT_8EED1867_ResolvedTypeTable* zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned char* zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    unsigned int zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned int zT_304;
    unsigned char* zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned int zT_308;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    unsigned int zT_310;
    unsigned char* zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    unsigned int zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    zT_8EED1867_ResolvedTypeTable* zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned char* zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    unsigned int zT_327;
    unsigned char* zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    unsigned int zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned int zT_333;
    unsigned char* zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    zT_8EED1867_ResolvedTypeTable* zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    unsigned char* zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    unsigned int zT_346;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    unsigned int zT_348;
    unsigned char* zT_350;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_351;
    unsigned int zT_352;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_353;
    zT_8EED1867_ResolvedTypeTable* zT_354;
    unsigned int zT_355;
    zT_22A7C88B_AstNode node;
    unsigned int then_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif_nl;
    unsigned int else_type;
    unsigned int ie_exp;
    int ie_then_lit;
    int ie_else_lit;
    int ie_then_str;
    int ie_else_str;
    int ie_then_ok;
    int ie_else_ok;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif2nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif3nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif4nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif5nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif6nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sif7nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u siffm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sifftm;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_7, zT_8);
    zT_10 = self;
    zT_11 = node.child_1;
    zT_13 = zF_54F95822_semanticAnalyzerRes(zT_10, zT_11);
    then_type = zT_13;
    zT_14 = node.child_2;
    if ((int)(zT_14 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = "SIF:0N";
    zT_20 = 6;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    sif_m = zT_19;
    zT_21 = sif_m;
    zT_22 = node_idx;
    zF_C914CB83_markerWriteInt(zT_21, zT_22);
    zT_24 = "T";
    zT_26 = 1;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    sif_tm = zT_25;
    zT_27 = sif_tm;
    zT_28 = then_type;
    zF_C914CB83_markerWriteInt(zT_27, zT_28);
    zT_30 = " ";
    zT_32 = 1;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    sif_nl = zT_31;
    zT_33 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_33);
    zT_34 = self->type_table;
    zT_35 = node_idx;
    zT_36 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_34, zT_35, zT_36);
    return then_type;
    z_bb_2:
    zT_39 = self;
    zT_40 = node.child_2;
    zT_42 = zF_54F95822_semanticAnalyzerRes(zT_39, zT_40);
    else_type = zT_42;
    zT_44 = self;
    zT_45 = zF_4DE7C2BC_topExpectedType(zT_44);
    ie_exp = zT_45;
    if ((int)(ie_exp == (unsigned int)(0))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_48 = ie_exp == (unsigned int)(1);
    goto z_bb_5;
    z_bb_4:
    zT_48 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_48) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    if ((int)(then_type != (unsigned int)(3))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    if ((int)(ie_exp != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_8:
    zT_55 = self->store;
    zT_56 = node.child_1;
    zT_59 = zF_FCDD1D35_astStoreNodeAt(zT_55, zT_56);
    zT_60 = zT_59.kind;
    zT_54 = zT_60 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_10;
    z_bb_9:
    zT_54 = 0;
    goto z_bb_10;
    z_bb_10:
    ie_then_lit = zT_54;
    if ((int)(else_type != (unsigned int)(3))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_69 = self->store;
    zT_70 = node.child_2;
    zT_73 = zF_FCDD1D35_astStoreNodeAt(zT_69, zT_70);
    zT_74 = zT_73.kind;
    zT_68 = zT_74 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_13;
    z_bb_12:
    zT_68 = 0;
    goto z_bb_13;
    z_bb_13:
    ie_else_lit = zT_68;
    if (ie_then_lit) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_79 = ie_else_lit;
    goto z_bb_16;
    z_bb_15:
    zT_79 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_79) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_80 = self->registry;
    zT_86 = zF_8FC81A87_typeRegistryGetOrCr(zT_80, (unsigned int)(8), (int)(1));
    ie_exp = zT_86;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_7;
    z_bb_19:
    zT_89 = ie_exp != (unsigned int)(1);
    goto z_bb_21;
    z_bb_20:
    zT_89 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_89) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    if ((int)(then_type != (unsigned int)(3))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    if ((int)(then_type == else_type)) goto z_bb_57; else goto z_bb_58;
    z_bb_24:
    zT_97 = self->registry;
    zT_98 = then_type;
    zT_99 = ie_exp;
    zT_101 = zF_713658BF_classifyCoercion(zT_97, zT_98, zT_99);
    zT_96 = zT_101;
    zT_102 = zF_71304A07_isStringLiteralSlic(zT_96);
    zT_95 = zT_102;
    goto z_bb_26;
    z_bb_25:
    zT_95 = 0;
    goto z_bb_26;
    z_bb_26:
    ie_then_str = zT_95;
    if ((int)(else_type != (unsigned int)(3))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_108 = self->registry;
    zT_109 = else_type;
    zT_110 = ie_exp;
    zT_112 = zF_713658BF_classifyCoercion(zT_108, zT_109, zT_110);
    zT_107 = zT_112;
    zT_113 = zF_71304A07_isStringLiteralSlic(zT_107);
    zT_106 = zT_113;
    goto z_bb_29;
    z_bb_28:
    zT_106 = 0;
    goto z_bb_29;
    z_bb_29:
    ie_else_str = zT_106;
    if ((int)(then_type == ie_exp)) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_116 = then_type == (unsigned int)(3);
    goto z_bb_32;
    z_bb_31:
    zT_116 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_116) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_119 = ie_then_str;
    goto z_bb_35;
    z_bb_34:
    zT_119 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_119) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_121 = self->registry;
    zT_122 = then_type;
    zT_123 = ie_exp;
    zT_125 = zF_683AEB7F_typeRegistryIsAssig(zT_121, zT_122, zT_123);
    zT_120 = zT_125;
    goto z_bb_38;
    z_bb_37:
    zT_120 = 1;
    goto z_bb_38;
    z_bb_38:
    ie_then_ok = zT_120;
    if ((int)(else_type == ie_exp)) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_128 = else_type == (unsigned int)(3);
    goto z_bb_41;
    z_bb_40:
    zT_128 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_128) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_131 = ie_else_str;
    goto z_bb_44;
    z_bb_43:
    zT_131 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_131) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_133 = self->registry;
    zT_134 = else_type;
    zT_135 = ie_exp;
    zT_137 = zF_683AEB7F_typeRegistryIsAssig(zT_133, zT_134, zT_135);
    zT_132 = zT_137;
    goto z_bb_47;
    z_bb_46:
    zT_132 = 1;
    goto z_bb_47;
    z_bb_47:
    ie_else_ok = zT_132;
    if (ie_then_ok) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_138 = ie_else_ok;
    goto z_bb_50;
    z_bb_49:
    zT_138 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_138) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    if ((int)(then_type != ie_exp)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_23;
    z_bb_53:
    zT_140 = self;
    zT_141 = node.child_1;
    zT_142 = then_type;
    zT_143 = ie_exp;
    zF_DF7434EB_tryRecordCoercion(zT_140, zT_141, zT_142, zT_143);
    goto z_bb_54;
    z_bb_54:
    if ((int)(else_type != ie_exp)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_146 = self;
    zT_147 = node.child_2;
    zT_148 = else_type;
    zT_149 = ie_exp;
    zF_DF7434EB_tryRecordCoercion(zT_146, zT_147, zT_148, zT_149);
    goto z_bb_56;
    z_bb_56:
    zT_151 = self->type_table;
    zT_152 = node_idx;
    zT_153 = ie_exp;
    zF_19B4A07D_resolvedTypeTableSe(zT_151, zT_152, zT_153);
    return ie_exp;
    z_bb_57:
    zT_157 = "SIF:1N";
    zT_159 = 6;
    zT_158.ptr = zT_157;
    zT_158.len = zT_159;
    sif_m = zT_158;
    zT_160 = sif_m;
    zT_161 = node_idx;
    zF_C914CB83_markerWriteInt(zT_160, zT_161);
    zT_163 = "T";
    zT_165 = 1;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    sif_tm = zT_164;
    zT_166 = sif_tm;
    zT_167 = then_type;
    zF_C914CB83_markerWriteInt(zT_166, zT_167);
    zT_169 = " ";
    zT_171 = 1;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    sif_nl = zT_170;
    zT_172 = sif_nl;
    zF_48AC7B3A_markerWrite(zT_172);
    zT_173 = self->type_table;
    zT_174 = node_idx;
    zT_175 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_173, zT_174, zT_175);
    return then_type;
    z_bb_58:
    if ((int)(then_type == (unsigned int)(3))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_180 = "SIF:2N";
    zT_182 = 6;
    zT_181.ptr = zT_180;
    zT_181.len = zT_182;
    sif2m = zT_181;
    zT_183 = sif2m;
    zT_184 = node_idx;
    zF_C914CB83_markerWriteInt(zT_183, zT_184);
    zT_186 = "T";
    zT_188 = 1;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    sif2tm = zT_187;
    zT_189 = sif2tm;
    zT_190 = else_type;
    zF_C914CB83_markerWriteInt(zT_189, zT_190);
    zT_192 = " ";
    zT_194 = 1;
    zT_193.ptr = zT_192;
    zT_193.len = zT_194;
    sif2nl = zT_193;
    zT_195 = sif2nl;
    zF_48AC7B3A_markerWrite(zT_195);
    zT_196 = self->type_table;
    zT_197 = node_idx;
    zT_198 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_196, zT_197, zT_198);
    return else_type;
    z_bb_60:
    if ((int)(else_type == (unsigned int)(3))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_203 = "SIF:3N";
    zT_205 = 6;
    zT_204.ptr = zT_203;
    zT_204.len = zT_205;
    sif3m = zT_204;
    zT_206 = sif3m;
    zT_207 = node_idx;
    zF_C914CB83_markerWriteInt(zT_206, zT_207);
    zT_209 = "T";
    zT_211 = 1;
    zT_210.ptr = zT_209;
    zT_210.len = zT_211;
    sif3tm = zT_210;
    zT_212 = sif3tm;
    zT_213 = then_type;
    zF_C914CB83_markerWriteInt(zT_212, zT_213);
    zT_215 = " ";
    zT_217 = 1;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    sif3nl = zT_216;
    zT_218 = sif3nl;
    zF_48AC7B3A_markerWrite(zT_218);
    zT_219 = self->type_table;
    zT_220 = node_idx;
    zT_221 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_219, zT_220, zT_221);
    return then_type;
    z_bb_62:
    if ((int)(then_type == (unsigned int)(19))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_226 = self->registry;
    zT_227 = else_type;
    zT_229 = zF_3087E0A5_typeRegistryIsNumer(zT_226, zT_227);
    zT_225 = zT_229;
    goto z_bb_65;
    z_bb_64:
    zT_225 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_225) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_231 = "SIF:4N";
    zT_233 = 6;
    zT_232.ptr = zT_231;
    zT_232.len = zT_233;
    sif4m = zT_232;
    zT_234 = sif4m;
    zT_235 = node_idx;
    zF_C914CB83_markerWriteInt(zT_234, zT_235);
    zT_237 = "T";
    zT_239 = 1;
    zT_238.ptr = zT_237;
    zT_238.len = zT_239;
    sif4tm = zT_238;
    zT_240 = sif4tm;
    zT_241 = else_type;
    zF_C914CB83_markerWriteInt(zT_240, zT_241);
    zT_243 = " ";
    zT_245 = 1;
    zT_244.ptr = zT_243;
    zT_244.len = zT_245;
    sif4nl = zT_244;
    zT_246 = sif4nl;
    zF_48AC7B3A_markerWrite(zT_246);
    zT_247 = self->coercion_table;
    zT_248 = node.child_1;
    zT_250 = else_type;
    zF_D21AE60A_coercionTableAdd(zT_247, zT_248, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_250);
    zT_256 = self->type_table;
    zT_257 = node_idx;
    zT_258 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_256, zT_257, zT_258);
    return else_type;
    z_bb_67:
    if ((int)(else_type == (unsigned int)(19))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_263 = self->registry;
    zT_264 = then_type;
    zT_266 = zF_3087E0A5_typeRegistryIsNumer(zT_263, zT_264);
    zT_262 = zT_266;
    goto z_bb_70;
    z_bb_69:
    zT_262 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_262) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_268 = "SIF:5N";
    zT_270 = 6;
    zT_269.ptr = zT_268;
    zT_269.len = zT_270;
    sif5m = zT_269;
    zT_271 = sif5m;
    zT_272 = node_idx;
    zF_C914CB83_markerWriteInt(zT_271, zT_272);
    zT_274 = "T";
    zT_276 = 1;
    zT_275.ptr = zT_274;
    zT_275.len = zT_276;
    sif5tm = zT_275;
    zT_277 = sif5tm;
    zT_278 = then_type;
    zF_C914CB83_markerWriteInt(zT_277, zT_278);
    zT_280 = " ";
    zT_282 = 1;
    zT_281.ptr = zT_280;
    zT_281.len = zT_282;
    sif5nl = zT_281;
    zT_283 = sif5nl;
    zF_48AC7B3A_markerWrite(zT_283);
    zT_284 = self->coercion_table;
    zT_285 = node.child_2;
    zT_287 = then_type;
    zF_D21AE60A_coercionTableAdd(zT_284, zT_285, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce), zT_287);
    zT_293 = self->type_table;
    zT_294 = node_idx;
    zT_295 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_293, zT_294, zT_295);
    return then_type;
    z_bb_72:
    if ((int)(then_type == (unsigned int)(1))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_300 = "SIF:6N";
    zT_302 = 6;
    zT_301.ptr = zT_300;
    zT_301.len = zT_302;
    sif6m = zT_301;
    zT_303 = sif6m;
    zT_304 = node_idx;
    zF_C914CB83_markerWriteInt(zT_303, zT_304);
    zT_306 = "T";
    zT_308 = 1;
    zT_307.ptr = zT_306;
    zT_307.len = zT_308;
    sif6tm = zT_307;
    zT_309 = sif6tm;
    zT_310 = else_type;
    zF_C914CB83_markerWriteInt(zT_309, zT_310);
    zT_312 = " ";
    zT_314 = 1;
    zT_313.ptr = zT_312;
    zT_313.len = zT_314;
    sif6nl = zT_313;
    zT_315 = sif6nl;
    zF_48AC7B3A_markerWrite(zT_315);
    zT_316 = self->type_table;
    zT_317 = node_idx;
    zT_318 = else_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_316, zT_317, zT_318);
    return else_type;
    z_bb_74:
    if ((int)(else_type == (unsigned int)(1))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_323 = "SIF:7N";
    zT_325 = 6;
    zT_324.ptr = zT_323;
    zT_324.len = zT_325;
    sif7m = zT_324;
    zT_326 = sif7m;
    zT_327 = node_idx;
    zF_C914CB83_markerWriteInt(zT_326, zT_327);
    zT_329 = "T";
    zT_331 = 1;
    zT_330.ptr = zT_329;
    zT_330.len = zT_331;
    sif7tm = zT_330;
    zT_332 = sif7tm;
    zT_333 = then_type;
    zF_C914CB83_markerWriteInt(zT_332, zT_333);
    zT_335 = " ";
    zT_337 = 1;
    zT_336.ptr = zT_335;
    zT_336.len = zT_337;
    sif7nl = zT_336;
    zT_338 = sif7nl;
    zF_48AC7B3A_markerWrite(zT_338);
    zT_339 = self->type_table;
    zT_340 = node_idx;
    zT_341 = then_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_339, zT_340, zT_341);
    return then_type;
    z_bb_76:
    zT_344 = "SIF:FN";
    zT_346 = 6;
    zT_345.ptr = zT_344;
    zT_345.len = zT_346;
    siffm = zT_345;
    zT_347 = siffm;
    zT_348 = node_idx;
    zF_C914CB83_markerWriteInt(zT_347, zT_348);
    zT_350 = "\n";
    zT_352 = 1;
    zT_351.ptr = zT_350;
    zT_351.len = zT_352;
    sifftm = zT_351;
    zT_353 = sifftm;
    zF_48AC7B3A_markerWrite(zT_353);
    zT_354 = self->type_table;
    zT_355 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_354, zT_355, (unsigned int)(1));
    return (unsigned int)(1);
}

/* semanticAnalyzerResolveEnumLiteral */
unsigned int zF_8C008E53_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    zT_33EF6BFB_TypeKind zT_26;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_54FF90FA_TaggedUnionPayload* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_54FF90FA_TaggedUnionPayload zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned short zT_41;
    unsigned int zT_42;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_2DF01B61_FieldEntry* zT_45;
    zT_2DF01B61_FieldEntry zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    int zT_69;
    unsigned int zT_70;
    zT_338B7C76_TypeRegistry* zT_73;
    zT_2DF01B61_FieldEntry* zT_74;
    unsigned int zT_75;
    zT_2DF01B61_FieldEntry zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_83;
    unsigned int zT_85;
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_21D3708C_U32ToU32Map* zT_93;
    unsigned int zT_94;
    zT_21D3708C_U32ToU32Map* zT_96;
    unsigned int zT_97;
    zT_8EED1867_ResolvedTypeTable* zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_106;
    int zT_107;
    unsigned int zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_457ECFEE_EnumPayload* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    zT_457ECFEE_EnumPayload zT_119;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned short zT_124;
    unsigned int zT_125;
    int zT_127;
    unsigned int zT_128;
    zT_338B7C76_TypeRegistry* zT_131;
    zT_D96DCDF2_EnumMember* zT_132;
    unsigned int zT_133;
    zT_D96DCDF2_EnumMember zT_134;
    unsigned int zT_135;
    zT_21D3708C_U32ToU32Map* zT_137;
    unsigned int zT_138;
    zT_C69B2266_i64 zT_141;
    zT_8EED1867_ResolvedTypeTable* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_148;
    int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    int zT_152;
    unsigned int* zT_155;
    unsigned int zT_156;
    int zT_157;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_338B7C76_TypeRegistry* zT_164;
    zT_D155D06D_Type* zT_165;
    unsigned int zT_166;
    zT_D155D06D_Type zT_167;
    zT_33EF6BFB_TypeKind zT_168;
    zT_338B7C76_TypeRegistry* zT_174;
    zT_54FF90FA_TaggedUnionPayload* zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    zT_54FF90FA_TaggedUnionPayload zT_178;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned short zT_183;
    unsigned int zT_184;
    int zT_186;
    unsigned int zT_187;
    zT_338B7C76_TypeRegistry* zT_190;
    zT_2DF01B61_FieldEntry* zT_191;
    unsigned int zT_192;
    zT_2DF01B61_FieldEntry zT_193;
    unsigned int zT_194;
    unsigned int zT_196;
    zT_21D3708C_U32ToU32Map* zT_199;
    unsigned int zT_200;
    zT_8EED1867_ResolvedTypeTable* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned int zT_213;
    unsigned char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    zT_F85C5DED_DiagnosticCollector* zT_218;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_232 = 0;
    int zT_234;
    unsigned int zT_235;
    unsigned int zT_237;
    unsigned int zT_239;
    unsigned int zT_241;
    unsigned char* zT_243;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned int zT_245;
    zT_F85C5DED_DiagnosticCollector* zT_246;
    unsigned int zT_249;
    unsigned int zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_260 = 0;
    zT_33EF6BFB_TypeKind zT_262;
    zT_338B7C76_TypeRegistry* zT_268;
    zT_457ECFEE_EnumPayload* zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    zT_457ECFEE_EnumPayload zT_272;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned short zT_277;
    unsigned int zT_278;
    int zT_280;
    unsigned int zT_281;
    zT_338B7C76_TypeRegistry* zT_284;
    zT_D96DCDF2_EnumMember* zT_285;
    unsigned int zT_286;
    zT_D96DCDF2_EnumMember zT_287;
    unsigned int zT_288;
    zT_21D3708C_U32ToU32Map* zT_290;
    unsigned int zT_291;
    zT_C69B2266_i64 zT_294;
    zT_8EED1867_ResolvedTypeTable* zT_296;
    unsigned int zT_297;
    unsigned int zT_298;
    int zT_300;
    unsigned int zT_301;
    unsigned char* zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    unsigned int zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    unsigned int zT_307;
    zT_8EED1867_ResolvedTypeTable* zT_308;
    unsigned int zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u el;
    zT_22A7C88B_AstNode node;
    unsigned int n;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int f0;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elc_m;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u elv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u elm_m;
    zT_457ECFEE_EnumPayload enp;
    unsigned int estart;
    unsigned int ecount;
    unsigned int emi;
    zT_D96DCDF2_EnumMember member;
    unsigned int top;
    zT_D155D06D_Type top_ty;
    unsigned int fstart2;
    unsigned int fcount2;
    unsigned int fi2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u elr_msg;
    zT_457ECFEE_EnumPayload enp2;
    unsigned int estart2;
    unsigned int ecount2;
    unsigned int emi2;
    zT_D96DCDF2_EnumMember member2;
    zT_3 = "eL\n";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    el = zT_4;
    zT_6 = el;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self->store;
    zT_14 = node_idx;
    zT_16 = zF_53458827_astStoreIdentifier(zT_13, zT_14);
    n = zT_16;
    zT_17 = self->current_switch_cond_tu;
    if ((int)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = self->current_switch_cond_tu;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    tu_ty = zT_25;
    zT_26 = tu_ty.kind;
    if ((int)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_151 = self->expected_type_stack_len;
    zT_152 = 0;
    if ((int)(zT_151 > (unsigned int)zT_152)) goto z_bb_19; else goto z_bb_20;
    z_bb_3:
    zT_32 = self->registry;
    zT_33 = zT_32->tu_items;
    zT_34 = tu_ty.payload_idx;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zT_33[zT_35];
    tp = zT_36;
    zT_38 = tp.fields_start;
    zT_39 = (unsigned int)zT_38;
    fstart = zT_39;
    zT_41 = tp.fields_count;
    zT_42 = (unsigned int)zT_41;
    fcount = zT_42;
    zT_44 = self->registry;
    zT_45 = zT_44->fe_items;
    zT_46 = zT_45[fstart];
    zT_47 = zT_46.name_id;
    zT_48 = (unsigned int)zT_47;
    f0 = zT_48;
    zT_50 = "EL:N";
    zT_52 = 4;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    eln_m = zT_51;
    zT_53 = eln_m;
    zT_54 = n;
    zF_C914CB83_markerWriteInt(zT_53, zT_54);
    zT_56 = "EL:F";
    zT_58 = 4;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    elf_m = zT_57;
    zT_59 = elf_m;
    zT_60 = f0;
    zF_C914CB83_markerWriteInt(zT_59, zT_60);
    zT_62 = "EL:C";
    zT_64 = 4;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    elc_m = zT_63;
    zT_65 = elc_m;
    zF_C914CB83_markerWriteInt(zT_65, (unsigned int)((unsigned int)fcount));
    zT_69 = 0;
    zT_70 = (unsigned int)zT_69;
    fi = zT_70;
    goto z_bb_5;
    z_bb_4:
    zT_109 = tu_ty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_5:
    if ((int)(fi < fcount)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_73 = self->registry;
    zT_74 = zT_73->fe_items;
    zT_75 = fstart + fi;
    zT_76 = zT_74[zT_75];
    fe = zT_76;
    zT_78 = "EL:V";
    zT_80 = 4;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    elv_m = zT_79;
    zT_81 = elv_m;
    zT_83 = fe.name_id;
    zF_C914CB83_markerWriteInt(zT_81, (unsigned int)((unsigned int)zT_83));
    zT_85 = fe.name_id;
    if ((int)(zT_85 == n)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_107 = 1;
    zT_108 = fi + zT_107;
    fi = zT_108;
    goto z_bb_5;
    z_bb_9:
    zT_88 = "EL:M";
    zT_90 = 4;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    elm_m = zT_89;
    zT_91 = elm_m;
    zT_93 = self->enum_value_table;
    zT_94 = zT_93->count;
    zF_C914CB83_markerWriteInt(zT_91, (unsigned int)((unsigned int)zT_94));
    zT_96 = self->enum_value_table;
    zT_97 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_96, zT_97, (unsigned int)((unsigned int)fi));
    zT_101 = self->type_table;
    zT_102 = node_idx;
    zT_103 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_101, zT_102, zT_103);
    zT_106 = self->current_switch_cond_tu;
    return zT_106;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_115 = self->registry;
    zT_116 = zT_115->en_items;
    zT_117 = tu_ty.payload_idx;
    zT_118 = (unsigned int)zT_117;
    zT_119 = zT_116[zT_118];
    enp = zT_119;
    zT_121 = enp.members_start;
    zT_122 = (unsigned int)zT_121;
    estart = zT_122;
    zT_124 = enp.members_count;
    zT_125 = (unsigned int)zT_124;
    ecount = zT_125;
    zT_127 = 0;
    zT_128 = (unsigned int)zT_127;
    emi = zT_128;
    goto z_bb_13;
    z_bb_12:
    goto z_bb_2;
    z_bb_13:
    if ((int)(emi < ecount)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_131 = self->registry;
    zT_132 = zT_131->em_items;
    zT_133 = estart + emi;
    zT_134 = zT_132[zT_133];
    member = zT_134;
    zT_135 = member.name_id;
    if ((int)(zT_135 == n)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_149 = 1;
    zT_150 = emi + zT_149;
    emi = zT_150;
    goto z_bb_13;
    z_bb_17:
    zT_137 = self->enum_value_table;
    zT_138 = node_idx;
    zT_141 = member.value;
    zF_26476265_u32ToU32MapPut(zT_137, zT_138, (unsigned int)((unsigned int)zT_141));
    zT_143 = self->type_table;
    zT_144 = node_idx;
    zT_145 = self->current_switch_cond_tu;
    zF_19B4A07D_resolvedTypeTableSe(zT_143, zT_144, zT_145);
    zT_148 = self->current_switch_cond_tu;
    return zT_148;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    zT_155 = self->expected_type_stack_items;
    zT_156 = self->expected_type_stack_len;
    zT_157 = 1;
    zT_159 = (unsigned int)(unsigned int)(zT_156 - zT_157);
    zT_160 = zT_155[zT_159];
    top = zT_160;
    if ((int)(top != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_303 = "ELV:N";
    zT_305 = 5;
    zT_304.ptr = zT_303;
    zT_304.len = zT_305;
    elv_m = zT_304;
    zT_306 = elv_m;
    zT_307 = n;
    zF_C914CB83_markerWriteInt(zT_306, zT_307);
    zT_308 = self->type_table;
    zT_309 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_308, zT_309, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_21:
    zT_164 = self->registry;
    zT_165 = zT_164->types_items;
    zT_166 = (unsigned int)top;
    zT_167 = zT_165[zT_166];
    top_ty = zT_167;
    zT_168 = top_ty.kind;
    if ((int)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_174 = self->registry;
    zT_175 = zT_174->tu_items;
    zT_176 = top_ty.payload_idx;
    zT_177 = (unsigned int)zT_176;
    zT_178 = zT_175[zT_177];
    tp = zT_178;
    zT_180 = tp.fields_start;
    zT_181 = (unsigned int)zT_180;
    fstart2 = zT_181;
    zT_183 = tp.fields_count;
    zT_184 = (unsigned int)zT_183;
    fcount2 = zT_184;
    zT_186 = 0;
    zT_187 = (unsigned int)zT_186;
    fi2 = zT_187;
    goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_262 = top_ty.kind;
    if ((int)(zT_262 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_26:
    if ((int)(fi2 < fcount2)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_190 = self->registry;
    zT_191 = zT_190->fe_items;
    zT_192 = fstart2 + fi2;
    zT_193 = zT_191[zT_192];
    fe = zT_193;
    zT_194 = fe.name_id;
    if ((int)(zT_194 == n)) goto z_bb_30; else goto z_bb_31;
    z_bb_28:
    zT_237 = node.span_start;
    sp = zT_237;
    zT_239 = node.span_len;
    zT_241 = sp + (unsigned int)((unsigned int)zT_239);
    ep = zT_241;
    zT_243 = "unknown enum literal member";
    zT_245 = 27;
    zT_244.ptr = zT_243;
    zT_244.len = zT_245;
    elu_msg = zT_244;
    zT_246 = self->diag;
    zT_249 = self->source_file_id;
    zT_250 = sp;
    zT_251 = ep;
    zT_252 = elu_msg;
    zT_260 = zF_C82559AC_diagnosticCollector(zT_246, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3009_UNKNOWN_ENUM_LITERAL_MEMBER)), zT_249, zT_250, zT_251, zT_252);
    (void)zT_260;
    return (unsigned int)(1);
    z_bb_29:
    zT_234 = 1;
    zT_235 = fi2 + zT_234;
    fi2 = zT_235;
    goto z_bb_26;
    z_bb_30:
    zT_196 = fe.type_id;
    if ((int)(zT_196 == (unsigned int)(1))) goto z_bb_32; else goto z_bb_34;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_199 = self->enum_value_table;
    zT_200 = node_idx;
    zF_26476265_u32ToU32MapPut(zT_199, zT_200, (unsigned int)((unsigned int)fi2));
    zT_204 = self->type_table;
    zT_205 = node_idx;
    zT_206 = top;
    zF_19B4A07D_resolvedTypeTableSe(zT_204, zT_205, zT_206);
    return top;
    goto z_bb_31;
    z_bb_34:
    zT_209 = node.span_start;
    sp = zT_209;
    zT_211 = node.span_len;
    zT_213 = sp + (unsigned int)((unsigned int)zT_211);
    ep = zT_213;
    zT_215 = "enum literal member requires payload";
    zT_217 = 36;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    elr_msg = zT_216;
    zT_218 = self->diag;
    zT_221 = self->source_file_id;
    zT_222 = sp;
    zT_223 = ep;
    zT_224 = elr_msg;
    zT_232 = zF_C82559AC_diagnosticCollector(zT_218, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3008_ENUM_LITERAL_REQUIRES_PAYLOAD)), zT_221, zT_222, zT_223, zT_224);
    (void)zT_232;
    return (unsigned int)(1);
    z_bb_35:
    zT_268 = self->registry;
    zT_269 = zT_268->en_items;
    zT_270 = top_ty.payload_idx;
    zT_271 = (unsigned int)zT_270;
    zT_272 = zT_269[zT_271];
    enp2 = zT_272;
    zT_274 = enp2.members_start;
    zT_275 = (unsigned int)zT_274;
    estart2 = zT_275;
    zT_277 = enp2.members_count;
    zT_278 = (unsigned int)zT_277;
    ecount2 = zT_278;
    zT_280 = 0;
    zT_281 = (unsigned int)zT_280;
    emi2 = zT_281;
    goto z_bb_37;
    z_bb_36:
    goto z_bb_24;
    z_bb_37:
    if ((int)(emi2 < ecount2)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_284 = self->registry;
    zT_285 = zT_284->em_items;
    zT_286 = estart2 + emi2;
    zT_287 = zT_285[zT_286];
    member2 = zT_287;
    zT_288 = member2.name_id;
    if ((int)(zT_288 == n)) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_300 = 1;
    zT_301 = emi2 + zT_300;
    emi2 = zT_301;
    goto z_bb_37;
    z_bb_41:
    zT_290 = self->enum_value_table;
    zT_291 = node_idx;
    zT_294 = member2.value;
    zF_26476265_u32ToU32MapPut(zT_290, zT_291, (unsigned int)((unsigned int)zT_294));
    zT_296 = self->type_table;
    zT_297 = node_idx;
    zT_298 = top;
    zF_19B4A07D_resolvedTypeTableSe(zT_296, zT_297, zT_298);
    return top;
    z_bb_42:
    goto z_bb_40;
}

/* semanticAnalyzerResolveStructInit */
unsigned int zF_AD7EF126_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_38C12417_SemanticAnalyzer* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_38C12417_SemanticAnalyzer* zT_18;
    unsigned int zT_19 = 0;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_D155D06D_Type* zT_25;
    unsigned int zT_26;
    zT_D155D06D_Type zT_27;
    zT_33EF6BFB_TypeKind zT_28;
    zT_338B7C76_TypeRegistry* zT_34;
    zT_54FF90FA_TaggedUnionPayload* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    zT_54FF90FA_TaggedUnionPayload zT_38;
    unsigned int zT_40;
    unsigned int zT_41;
    unsigned short zT_43;
    unsigned int zT_44;
    zT_6B0A7D14_AstStore* zT_46;
    unsigned int zT_47;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_49 = {0};
    int zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int* zT_60;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    unsigned int* zT_67;
    unsigned int zT_69 = 0;
    int zT_73;
    unsigned int zT_74;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_2DF01B61_FieldEntry* zT_77;
    unsigned int zT_78;
    zT_2DF01B61_FieldEntry zT_79;
    unsigned int zT_80;
    unsigned int zT_82;
    zT_338B7C76_TypeRegistry* zT_86;
    zT_2DF01B61_FieldEntry* zT_87;
    unsigned int zT_88;
    zT_2DF01B61_FieldEntry zT_89;
    unsigned int zT_90;
    zT_38C12417_SemanticAnalyzer* zT_91;
    unsigned int zT_92;
    zT_38C12417_SemanticAnalyzer* zT_94;
    unsigned int zT_95;
    unsigned int zT_97 = 0;
    zT_38C12417_SemanticAnalyzer* zT_98;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    int zT_104;
    unsigned int zT_105;
    int zT_106;
    unsigned int zT_107;
    zT_8EED1867_ResolvedTypeTable* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    zT_33EF6BFB_TypeKind zT_112;
    zT_338B7C76_TypeRegistry* zT_118;
    zT_406493CE_StructPayload* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_406493CE_StructPayload zT_122;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned short zT_127;
    unsigned int zT_128;
    zT_6B0A7D14_AstStore* zT_130;
    unsigned int zT_131;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_133 = {0};
    int zT_135;
    unsigned int zT_136;
    unsigned int zT_138;
    zT_6B0A7D14_AstStore* zT_141;
    unsigned int zT_142;
    unsigned int* zT_144;
    zT_22A7C88B_AstNode zT_146 = {0};
    zT_6B0A7D14_AstStore* zT_148;
    unsigned int zT_149;
    unsigned int* zT_151;
    unsigned int zT_153 = 0;
    int zT_157;
    unsigned int zT_158;
    zT_338B7C76_TypeRegistry* zT_160;
    zT_2DF01B61_FieldEntry* zT_161;
    unsigned int zT_162;
    zT_2DF01B61_FieldEntry zT_163;
    unsigned int zT_164;
    unsigned int zT_166;
    zT_338B7C76_TypeRegistry* zT_170;
    zT_2DF01B61_FieldEntry* zT_171;
    unsigned int zT_172;
    zT_2DF01B61_FieldEntry zT_173;
    unsigned int zT_174;
    zT_38C12417_SemanticAnalyzer* zT_175;
    unsigned int zT_176;
    zT_38C12417_SemanticAnalyzer* zT_178;
    unsigned int zT_179;
    unsigned int zT_181 = 0;
    zT_38C12417_SemanticAnalyzer* zT_182;
    zT_38C12417_SemanticAnalyzer* zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    int zT_188;
    unsigned int zT_189;
    int zT_190;
    unsigned int zT_191;
    zT_8EED1867_ResolvedTypeTable* zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_33EF6BFB_TypeKind zT_196;
    int zT_201;
    zT_33EF6BFB_TypeKind zT_202;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_AF9231A2_UnionPayload* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    zT_AF9231A2_UnionPayload zT_212;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned short zT_217;
    unsigned int zT_218;
    zT_6B0A7D14_AstStore* zT_220;
    unsigned int zT_221;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_223 = {0};
    int zT_225;
    unsigned int zT_226;
    unsigned int zT_228;
    zT_6B0A7D14_AstStore* zT_231;
    unsigned int zT_232;
    unsigned int* zT_234;
    zT_22A7C88B_AstNode zT_236 = {0};
    zT_6B0A7D14_AstStore* zT_238;
    unsigned int zT_239;
    unsigned int* zT_241;
    unsigned int zT_243 = 0;
    int zT_247;
    unsigned int zT_248;
    zT_338B7C76_TypeRegistry* zT_250;
    zT_2DF01B61_FieldEntry* zT_251;
    unsigned int zT_252;
    zT_2DF01B61_FieldEntry zT_253;
    unsigned int zT_254;
    unsigned int zT_256;
    zT_338B7C76_TypeRegistry* zT_260;
    zT_2DF01B61_FieldEntry* zT_261;
    unsigned int zT_262;
    zT_2DF01B61_FieldEntry zT_263;
    unsigned int zT_264;
    zT_38C12417_SemanticAnalyzer* zT_265;
    unsigned int zT_266;
    zT_38C12417_SemanticAnalyzer* zT_268;
    unsigned int zT_269;
    unsigned int zT_271 = 0;
    zT_38C12417_SemanticAnalyzer* zT_272;
    zT_38C12417_SemanticAnalyzer* zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    int zT_278;
    unsigned int zT_279;
    int zT_280;
    unsigned int zT_281;
    zT_8EED1867_ResolvedTypeTable* zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    zT_22A7C88B_AstNode node;
    unsigned int target_type;
    zT_D155D06D_Type tgt;
    zT_54FF90FA_TaggedUnionPayload tp;
    unsigned int fstart;
    unsigned int fcount;
    zT_3CB0179A_Slice_zT_05F374B1_u field_inits;
    unsigned int fii;
    zT_22A7C88B_AstNode fi_node;
    unsigned int fname_id;
    unsigned int fi;
    unsigned int field_type;
    unsigned int init_type;
    zT_406493CE_StructPayload sp;
    zT_AF9231A2_UnionPayload up;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = 0;
    target_type = zT_8;
    zT_9 = node.child_0;
    if ((int)(zT_9 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = node.child_0;
    zT_15 = zF_54F95822_semanticAnalyzerRes(zT_12, zT_13);
    target_type = zT_15;
    goto z_bb_2;
    z_bb_2:
    if ((int)(target_type == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = self;
    zT_19 = zF_4DE7C2BC_topExpectedType(zT_18);
    target_type = zT_19;
    goto z_bb_4;
    z_bb_4:
    if ((int)(target_type == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(1);
    z_bb_6:
    zT_24 = self->registry;
    zT_25 = zT_24->types_items;
    zT_26 = (unsigned int)target_type;
    zT_27 = zT_25[zT_26];
    tgt = zT_27;
    zT_28 = tgt.kind;
    if ((int)(zT_28 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_34 = self->registry;
    zT_35 = zT_34->tu_items;
    zT_36 = tgt.payload_idx;
    zT_37 = (unsigned int)zT_36;
    zT_38 = zT_35[zT_37];
    tp = zT_38;
    zT_40 = tp.fields_start;
    zT_41 = (unsigned int)zT_40;
    fstart = zT_41;
    zT_43 = tp.fields_count;
    zT_44 = (unsigned int)zT_43;
    fcount = zT_44;
    zT_46 = self->store;
    zT_47 = node_idx;
    zT_49 = zF_850FDF81_astStoreNodeExtraCh(zT_46, zT_47);
    field_inits = zT_49;
    zT_51 = 0;
    zT_52 = (unsigned int)zT_51;
    fii = zT_52;
    goto z_bb_9;
    z_bb_8:
    zT_112 = tgt.kind;
    if ((int)(zT_112 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_9:
    zT_54 = field_inits.len;
    if ((int)(fii < zT_54)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_57 = self->store;
    zT_60 = field_inits.ptr;
    zT_58 = zT_60[fii];
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_57, zT_58);
    fi_node = zT_62;
    zT_64 = self->store;
    zT_67 = field_inits.ptr;
    zT_65 = zT_67[fii];
    zT_69 = zF_8BA26B9E_astStoreNodePayload(zT_64, zT_65);
    fname_id = zT_69;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_108 = self->type_table;
    zT_109 = node_idx;
    zT_110 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_108, zT_109, zT_110);
    return target_type;
    z_bb_12:
    zT_106 = 1;
    zT_107 = fii + zT_106;
    fii = zT_107;
    goto z_bb_9;
    z_bb_13:
    zT_73 = 0;
    zT_74 = (unsigned int)zT_73;
    fi = zT_74;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    if ((int)(fi < fcount)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_76 = self->registry;
    zT_77 = zT_76->fe_items;
    zT_78 = fstart + fi;
    zT_79 = zT_77[zT_78];
    zT_80 = zT_79.name_id;
    if ((int)(zT_80 == fname_id)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_104 = 1;
    zT_105 = fi + zT_104;
    fi = zT_105;
    goto z_bb_15;
    z_bb_19:
    zT_82 = fi_node.child_0;
    if ((int)(zT_82 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_86 = self->registry;
    zT_87 = zT_86->fe_items;
    zT_88 = fstart + fi;
    zT_89 = zT_87[zT_88];
    zT_90 = zT_89.type_id;
    field_type = zT_90;
    zT_91 = self;
    zT_92 = field_type;
    zF_9665A229_pushExpectedType(zT_91, zT_92);
    zT_94 = self;
    zT_95 = fi_node.child_0;
    zT_97 = zF_54F95822_semanticAnalyzerRes(zT_94, zT_95);
    init_type = zT_97;
    zT_98 = self;
    zF_BC478E78_popExpectedType(zT_98);
    zT_99 = self;
    zT_100 = fi_node.child_0;
    zT_101 = init_type;
    zT_102 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_99, zT_100, zT_101, zT_102);
    goto z_bb_22;
    z_bb_22:
    goto z_bb_17;
    z_bb_23:
    zT_118 = self->registry;
    zT_119 = zT_118->st_items;
    zT_120 = tgt.payload_idx;
    zT_121 = (unsigned int)zT_120;
    zT_122 = zT_119[zT_121];
    sp = zT_122;
    zT_124 = sp.fields_start;
    zT_125 = (unsigned int)zT_124;
    fstart = zT_125;
    zT_127 = sp.fields_count;
    zT_128 = (unsigned int)zT_127;
    fcount = zT_128;
    zT_130 = self->store;
    zT_131 = node_idx;
    zT_133 = zF_850FDF81_astStoreNodeExtraCh(zT_130, zT_131);
    field_inits = zT_133;
    zT_135 = 0;
    zT_136 = (unsigned int)zT_135;
    fii = zT_136;
    goto z_bb_25;
    z_bb_24:
    zT_196 = tgt.kind;
    if ((int)(zT_196 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_40; else goto z_bb_39;
    z_bb_25:
    zT_138 = field_inits.len;
    if ((int)(fii < zT_138)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_141 = self->store;
    zT_144 = field_inits.ptr;
    zT_142 = zT_144[fii];
    zT_146 = zF_FCDD1D35_astStoreNodeAt(zT_141, zT_142);
    fi_node = zT_146;
    zT_148 = self->store;
    zT_151 = field_inits.ptr;
    zT_149 = zT_151[fii];
    zT_153 = zF_8BA26B9E_astStoreNodePayload(zT_148, zT_149);
    fname_id = zT_153;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_192 = self->type_table;
    zT_193 = node_idx;
    zT_194 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_192, zT_193, zT_194);
    return target_type;
    z_bb_28:
    zT_190 = 1;
    zT_191 = fii + zT_190;
    fii = zT_191;
    goto z_bb_25;
    z_bb_29:
    zT_157 = 0;
    zT_158 = (unsigned int)zT_157;
    fi = zT_158;
    goto z_bb_31;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    if ((int)(fi < fcount)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_160 = self->registry;
    zT_161 = zT_160->fe_items;
    zT_162 = fstart + fi;
    zT_163 = zT_161[zT_162];
    zT_164 = zT_163.name_id;
    if ((int)(zT_164 == fname_id)) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_188 = 1;
    zT_189 = fi + zT_188;
    fi = zT_189;
    goto z_bb_31;
    z_bb_35:
    zT_166 = fi_node.child_0;
    if ((int)(zT_166 != (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_170 = self->registry;
    zT_171 = zT_170->fe_items;
    zT_172 = fstart + fi;
    zT_173 = zT_171[zT_172];
    zT_174 = zT_173.type_id;
    field_type = zT_174;
    zT_175 = self;
    zT_176 = field_type;
    zF_9665A229_pushExpectedType(zT_175, zT_176);
    zT_178 = self;
    zT_179 = fi_node.child_0;
    zT_181 = zF_54F95822_semanticAnalyzerRes(zT_178, zT_179);
    init_type = zT_181;
    zT_182 = self;
    zF_BC478E78_popExpectedType(zT_182);
    zT_183 = self;
    zT_184 = fi_node.child_0;
    zT_185 = init_type;
    zT_186 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_183, zT_184, zT_185, zT_186);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_33;
    z_bb_39:
    zT_202 = tgt.kind;
    zT_201 = zT_202 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_41;
    z_bb_40:
    zT_201 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_201) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_208 = self->registry;
    zT_209 = zT_208->un_items;
    zT_210 = tgt.payload_idx;
    zT_211 = (unsigned int)zT_210;
    zT_212 = zT_209[zT_211];
    up = zT_212;
    zT_214 = up.fields_start;
    zT_215 = (unsigned int)zT_214;
    fstart = zT_215;
    zT_217 = up.fields_count;
    zT_218 = (unsigned int)zT_217;
    fcount = zT_218;
    zT_220 = self->store;
    zT_221 = node_idx;
    zT_223 = zF_850FDF81_astStoreNodeExtraCh(zT_220, zT_221);
    field_inits = zT_223;
    zT_225 = 0;
    zT_226 = (unsigned int)zT_225;
    fii = zT_226;
    goto z_bb_44;
    z_bb_43:
    return (unsigned int)(1);
    z_bb_44:
    zT_228 = field_inits.len;
    if ((int)(fii < zT_228)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_231 = self->store;
    zT_234 = field_inits.ptr;
    zT_232 = zT_234[fii];
    zT_236 = zF_FCDD1D35_astStoreNodeAt(zT_231, zT_232);
    fi_node = zT_236;
    zT_238 = self->store;
    zT_241 = field_inits.ptr;
    zT_239 = zT_241[fii];
    zT_243 = zF_8BA26B9E_astStoreNodePayload(zT_238, zT_239);
    fname_id = zT_243;
    if ((int)(fname_id != (unsigned int)(0))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    zT_282 = self->type_table;
    zT_283 = node_idx;
    zT_284 = target_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_282, zT_283, zT_284);
    return target_type;
    z_bb_47:
    zT_280 = 1;
    zT_281 = fii + zT_280;
    fii = zT_281;
    goto z_bb_44;
    z_bb_48:
    zT_247 = 0;
    zT_248 = (unsigned int)zT_247;
    fi = zT_248;
    goto z_bb_50;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    if ((int)(fi < fcount)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_250 = self->registry;
    zT_251 = zT_250->fe_items;
    zT_252 = fstart + fi;
    zT_253 = zT_251[zT_252];
    zT_254 = zT_253.name_id;
    if ((int)(zT_254 == fname_id)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_278 = 1;
    zT_279 = fi + zT_278;
    fi = zT_279;
    goto z_bb_50;
    z_bb_54:
    zT_256 = fi_node.child_0;
    if ((int)(zT_256 != (unsigned int)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_260 = self->registry;
    zT_261 = zT_260->fe_items;
    zT_262 = fstart + fi;
    zT_263 = zT_261[zT_262];
    zT_264 = zT_263.type_id;
    field_type = zT_264;
    zT_265 = self;
    zT_266 = field_type;
    zF_9665A229_pushExpectedType(zT_265, zT_266);
    zT_268 = self;
    zT_269 = fi_node.child_0;
    zT_271 = zF_54F95822_semanticAnalyzerRes(zT_268, zT_269);
    init_type = zT_271;
    zT_272 = self;
    zF_BC478E78_popExpectedType(zT_272);
    zT_273 = self;
    zT_274 = fi_node.child_0;
    zT_275 = init_type;
    zT_276 = field_type;
    zF_DF7434EB_tryRecordCoercion(zT_273, zT_274, zT_275, zT_276);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_52;
}

/* semanticAnalyzerResolveAssign */
unsigned int zF_C0551BB8_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_38C12417_SemanticAnalyzer* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_22A7C88B_AstNode zT_25 = {0};
    zT_8143F551_AstKind zT_26;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_39 = 0;
    zT_D3EB6303_StringInterner* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_43 = 0;
    zT_38C12417_SemanticAnalyzer* zT_45;
    unsigned int zT_46;
    unsigned int zT_48 = 0;
    zT_38C12417_SemanticAnalyzer* zT_50;
    unsigned int zT_51;
    zT_38C12417_SemanticAnalyzer* zT_53;
    unsigned int zT_54;
    unsigned int zT_56 = 0;
    zT_38C12417_SemanticAnalyzer* zT_57;
    int zT_60;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_38C12417_SemanticAnalyzer* zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_75 = 0;
    zT_38C12417_SemanticAnalyzer* zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    int zT_81 = 0;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    int zT_87 = 0;
    zT_38C12417_SemanticAnalyzer* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_106;
    unsigned int zT_108;
    unsigned int zT_110;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_D155D06D_Type* zT_117;
    unsigned int zT_118;
    zT_D155D06D_Type zT_119;
    zT_33EF6BFB_TypeKind zT_120;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type* zT_123;
    unsigned int zT_124;
    zT_D155D06D_Type zT_125;
    zT_33EF6BFB_TypeKind zT_126;
    int zT_128;
    unsigned char zT_129;
    zT_38C12417_SemanticAnalyzer* zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    int zT_133 = 0;
    int zT_134;
    unsigned char zT_135;
    zT_38C12417_SemanticAnalyzer* zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    int zT_141 = 0;
    int zT_142;
    unsigned char zT_143;
    int zT_148;
    zT_338B7C76_TypeRegistry* zT_154;
    zT_42C2D6BF_EUPayload* zT_155;
    zT_338B7C76_TypeRegistry* zT_156;
    zT_D155D06D_Type* zT_157;
    unsigned int zT_158;
    zT_D155D06D_Type zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    zT_42C2D6BF_EUPayload zT_162;
    zT_338B7C76_TypeRegistry* zT_164;
    zT_42C2D6BF_EUPayload* zT_165;
    zT_338B7C76_TypeRegistry* zT_166;
    zT_D155D06D_Type* zT_167;
    unsigned int zT_168;
    zT_D155D06D_Type zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    zT_42C2D6BF_EUPayload zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    int zT_176;
    unsigned char zT_177;
    zT_F85C5DED_DiagnosticCollector* zT_179;
    unsigned char zT_180;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_189 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_190;
    unsigned int zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    zT_33EF6BFB_TypeKind zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_196;
    unsigned int zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    zT_33EF6BFB_TypeKind zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u ase;
    zT_22A7C88B_AstNode node;
    unsigned int lhs;
    zT_22A7C88B_AstNode lhs_node;
    unsigned int rhs;
    zT_8F083A69_Slice_zT_0B42B2F8_u us_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0;
    unsigned int eff_src;
    zT_8F083A69_Slice_zT_0B42B2F8_u as1;
    zT_8F083A69_Slice_zT_0B42B2F8_u as2;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u tma_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_3 = "ASE";
    zT_5 = 3;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ase = zT_4;
    zT_6 = ase;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_13 = self;
    zT_14 = node.child_0;
    zT_16 = zF_54F95822_semanticAnalyzerRes(zT_13, zT_14);
    lhs = zT_16;
    zT_17 = node.child_0;
    if ((int)(zT_17 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = self->store;
    zT_22 = node.child_0;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    lhs_node = zT_25;
    zT_26 = lhs_node.kind;
    if ((int)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_50 = self;
    zT_51 = lhs;
    zF_9665A229_pushExpectedType(zT_50, zT_51);
    zT_53 = self;
    zT_54 = node.child_1;
    zT_56 = zF_54F95822_semanticAnalyzerRes(zT_53, zT_54);
    rhs = zT_56;
    zT_57 = self;
    zF_BC478E78_popExpectedType(zT_57);
    if ((int)(lhs == (unsigned int)(0))) goto z_bb_8; else goto z_bb_7;
    z_bb_3:
    zT_32 = "_";
    zT_34 = 1;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    us_str = zT_33;
    zT_35 = self->store;
    zT_36 = node.child_0;
    zT_39 = zF_53458827_astStoreIdentifier(zT_35, zT_36);
    zT_40 = self->interner;
    zT_41 = us_str;
    zT_43 = zF_50C274AF_stringInternerInter(zT_40, zT_41);
    if ((int)(zT_39 == zT_43)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_45 = self;
    zT_46 = node.child_1;
    zT_48 = zF_54F95822_semanticAnalyzerRes(zT_45, zT_46);
    (void)zT_48;
    return (unsigned int)(1);
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_60 = rhs == (unsigned int)(0);
    goto z_bb_9;
    z_bb_8:
    zT_60 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_60) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_64 = "AS0";
    zT_66 = 3;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    as0 = zT_65;
    zT_67 = as0;
    zF_48AC7B3A_markerWrite(zT_67);
    return (unsigned int)(1);
    z_bb_11:
    zT_70 = self;
    zT_71 = node.child_1;
    zT_72 = lhs;
    zT_73 = rhs;
    zT_75 = zF_FFC95E09_errLitSrcType(zT_70, zT_71, zT_72, zT_73);
    eff_src = zT_75;
    zT_76 = self;
    zT_77 = node.child_1;
    zT_78 = eff_src;
    zT_79 = lhs;
    zT_81 = zF_86AAA417_semanticAnalyzerMay(zT_76, zT_77, zT_78, zT_79);
    if (zT_81) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_83 = self->registry;
    zT_84 = eff_src;
    zT_85 = lhs;
    zT_87 = zF_683AEB7F_typeRegistryIsAssig(zT_83, zT_84, zT_85);
    if (zT_87) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_88 = self;
    zT_89 = node.child_1;
    zT_90 = eff_src;
    zT_91 = lhs;
    zF_DF7434EB_tryRecordCoercion(zT_88, zT_89, zT_90, zT_91);
    zT_94 = "AS1";
    zT_96 = 3;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    as1 = zT_95;
    zT_97 = as1;
    zF_48AC7B3A_markerWrite(zT_97);
    return lhs;
    z_bb_15:
    zT_99 = "AS2";
    zT_101 = 3;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    as2 = zT_100;
    zT_102 = as2;
    zF_48AC7B3A_markerWrite(zT_102);
    if ((int)(lhs != (unsigned int)(1))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_106 = node.span_start;
    sp = zT_106;
    zT_108 = node.span_len;
    zT_110 = sp + (unsigned int)((unsigned int)zT_108);
    ep = zT_110;
    zT_112 = "type mismatch in assignment — internal type representations differ; generated code may be incorrect";
    zT_114 = 101;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    tma_msg = zT_113;
    zT_116 = self->registry;
    zT_117 = zT_116->types_items;
    zT_118 = (unsigned int)eff_src;
    zT_119 = zT_117[zT_118];
    zT_120 = zT_119.kind;
    sk = zT_120;
    zT_122 = self->registry;
    zT_123 = zT_122->types_items;
    zT_124 = (unsigned int)lhs;
    zT_125 = zT_123[zT_124];
    zT_126 = zT_125.kind;
    tk = zT_126;
    zT_128 = 1;
    zT_129 = (unsigned char)zT_128;
    level = zT_129;
    zT_130 = self;
    zT_131 = eff_src;
    zT_132 = lhs;
    zT_133 = zF_148F8E19_semanticAnalyzerFnP(zT_130, zT_131, zT_132);
    if (zT_133) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    return (unsigned int)(1);
    z_bb_18:
    zT_134 = 0;
    zT_135 = (unsigned char)zT_134;
    level = zT_135;
    goto z_bb_19;
    z_bb_19:
    zT_136 = self;
    zT_137 = eff_src;
    zT_138 = lhs;
    zT_141 = zF_D728034A_isBShapeMismatch(zT_136, zT_137, zT_138, (int)(1));
    if (zT_141) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_142 = 0;
    zT_143 = (unsigned char)zT_142;
    level = zT_143;
    goto z_bb_21;
    z_bb_21:
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_148 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_24;
    z_bb_23:
    zT_148 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_148) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_154 = self->registry;
    zT_155 = zT_154->eu_items;
    zT_156 = self->registry;
    zT_157 = zT_156->types_items;
    zT_158 = (unsigned int)eff_src;
    zT_159 = zT_157[zT_158];
    zT_160 = zT_159.payload_idx;
    zT_161 = (unsigned int)zT_160;
    zT_162 = zT_155[zT_161];
    eu_src = zT_162;
    zT_164 = self->registry;
    zT_165 = zT_164->eu_items;
    zT_166 = self->registry;
    zT_167 = zT_166->types_items;
    zT_168 = (unsigned int)lhs;
    zT_169 = zT_167[zT_168];
    zT_170 = zT_169.payload_idx;
    zT_171 = (unsigned int)zT_170;
    zT_172 = zT_165[zT_171];
    eu_tgt = zT_172;
    zT_173 = eu_src.error_set;
    zT_174 = eu_tgt.error_set;
    if ((int)(zT_173 == zT_174)) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_179 = self->diag;
    zT_180 = level;
    zT_182 = self->source_file_id;
    zT_183 = sp;
    zT_184 = ep;
    zT_185 = tma_msg;
    zT_189 = zF_C82559AC_diagnosticCollector(zT_179, zT_180, (unsigned short)(3000), zT_182, zT_183, zT_184, zT_185);
    di = zT_189;
    zT_190 = self->diag;
    zT_191 = di;
    zT_194 = sk;
    zT_195 = zF_C14453DE_typeKindSrcStr(zT_194);
    zT_192 = zT_195;
    zF_426E1F18_diagnosticCollector(zT_190, zT_191, zT_192);
    (void)self;
    zT_196 = self->diag;
    zT_197 = di;
    zT_200 = tk;
    zT_201 = zF_CC479241_typeKindTgtStr(zT_200);
    zT_198 = zT_201;
    zF_426E1F18_diagnosticCollector(zT_196, zT_197, zT_198);
    (void)self;
    goto z_bb_17;
    z_bb_27:
    zT_176 = 0;
    zT_177 = (unsigned char)zT_176;
    level = zT_177;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_26;
}

/* semanticAnalyzerResolveSwitchExpr */
unsigned int zF_2DB4F186_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_8143F551_AstKind zT_29;
    zT_79FAE712_u64 zT_32 = 0;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_46 = 0;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_55;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    int zT_61;
    unsigned char* zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65 = 0;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    zT_8EED1867_ResolvedTypeTable* zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    zT_38C12417_SemanticAnalyzer* zT_92;
    unsigned int zT_93;
    unsigned int zT_95 = 0;
    unsigned int zT_98;
    int zT_101;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D155D06D_Type* zT_106;
    unsigned int zT_107;
    zT_D155D06D_Type zT_108;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_114;
    zT_33EF6BFB_TypeKind zT_115;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_33EF6BFB_TypeKind zT_125;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    zT_33EF6BFB_TypeKind zT_141;
    zT_338B7C76_TypeRegistry* zT_147;
    zT_42C2D6BF_EUPayload* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_42C2D6BF_EUPayload zT_151;
    unsigned int zT_152;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    zT_6B0A7D14_AstStore* zT_165;
    unsigned int zT_166;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_168 = {0};
    unsigned int zT_170;
    unsigned char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_179;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    int zT_185;
    unsigned char* zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189 = 0;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned char* zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    zT_8EED1867_ResolvedTypeTable* zT_207;
    unsigned int zT_208;
    unsigned int zT_212;
    unsigned int zT_217;
    unsigned int zT_219;
    int zT_221;
    unsigned char zT_222;
    int zT_224;
    unsigned int zT_225;
    unsigned int zT_227;
    unsigned int zT_229;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233;
    unsigned int* zT_235;
    zT_22A7C88B_AstNode zT_237 = {0};
    unsigned char zT_238;
    int zT_243;
    unsigned char zT_244;
    unsigned char zT_245;
    int zT_250;
    unsigned char zT_251;
    unsigned char* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_259;
    zT_F85C5DED_DiagnosticCollector* zT_260;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    unsigned int zT_271 = 0;
    unsigned int zT_274;
    zT_6B0A7D14_AstStore* zT_276;
    unsigned int zT_277;
    unsigned int* zT_279;
    unsigned char* zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    zT_6B0A7D14_AstStore* zT_294;
    unsigned int zT_295;
    zT_8143F551_AstKind zT_296;
    unsigned int* zT_298;
    zT_79FAE712_u64 zT_301 = 0;
    unsigned int zT_305;
    int zT_308;
    zT_6B0A7D14_AstStore* zT_309;
    unsigned int zT_310;
    unsigned int* zT_312;
    unsigned int zT_314 = 0;
    zT_6B0A7D14_AstStore* zT_318;
    unsigned int zT_319;
    unsigned int* zT_321;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_323 = {0};
    int zT_325;
    unsigned int zT_326;
    unsigned int zT_328;
    zT_6B0A7D14_AstStore* zT_331;
    unsigned int zT_332;
    unsigned int* zT_334;
    zT_22A7C88B_AstNode zT_336 = {0};
    zT_8143F551_AstKind zT_338;
    unsigned int zT_339;
    unsigned char* zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned int zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned int zT_345;
    zT_8143F551_AstKind zT_346;
    zT_38C12417_SemanticAnalyzer* zT_351;
    unsigned int* zT_353;
    unsigned int zT_354;
    unsigned int zT_356 = 0;
    zT_8143F551_AstKind zT_357;
    zT_38C12417_SemanticAnalyzer* zT_362;
    unsigned int* zT_364;
    unsigned int zT_365;
    unsigned int zT_367 = 0;
    int zT_368;
    unsigned int zT_369;
    unsigned char zT_370;
    unsigned int zT_376;
    unsigned char* zT_378;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_379;
    unsigned int zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    unsigned int zT_382;
    unsigned char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned int zT_390;
    unsigned int zT_393;
    zT_21D3708C_U32ToU32Map* zT_397;
    unsigned int zT_398;
    unsigned int* zT_400;
    int zT_401;
    zT_BAEE192E_Opt_10 zT_403 = {0};
    unsigned char zT_404;
    zT_338B7C76_TypeRegistry* zT_407;
    zT_D155D06D_Type* zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    zT_D155D06D_Type zT_411;
    zT_33EF6BFB_TypeKind zT_412;
    zT_338B7C76_TypeRegistry* zT_418;
    zT_54FF90FA_TaggedUnionPayload* zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    zT_54FF90FA_TaggedUnionPayload zT_422;
    zT_338B7C76_TypeRegistry* zT_424;
    zT_2DF01B61_FieldEntry* zT_425;
    unsigned int zT_426;
    unsigned int zT_429;
    zT_2DF01B61_FieldEntry zT_430;
    unsigned char* zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned int zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned int zT_436;
    unsigned char* zT_438;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_439;
    unsigned int zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_441;
    unsigned int zT_442;
    unsigned char* zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    unsigned int zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_448;
    zT_33EF6BFB_TypeKind zT_450;
    unsigned int zT_452;
    unsigned int zT_453;
    zT_38C12417_SemanticAnalyzer* zT_455;
    unsigned int* zT_456;
    unsigned int zT_457;
    unsigned int zT_458;
    unsigned int* zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    unsigned char* zT_465;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_466;
    unsigned int zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    unsigned int zT_469;
    unsigned char* zT_471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_472;
    unsigned int zT_473;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_474;
    unsigned int zT_475;
    unsigned char* zT_478;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_479;
    unsigned int zT_480;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_481;
    unsigned int zT_482;
    zT_38C12417_SemanticAnalyzer* zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    int zT_489;
    zT_6B0A7D14_AstStore* zT_490;
    unsigned int zT_491;
    unsigned int* zT_493;
    unsigned int zT_495 = 0;
    zT_6B0A7D14_AstStore* zT_499;
    unsigned int zT_500;
    unsigned int* zT_502;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_504 = {0};
    int zT_506;
    unsigned int zT_507;
    unsigned int zT_509;
    zT_6B0A7D14_AstStore* zT_512;
    unsigned int zT_513;
    unsigned int* zT_515;
    zT_22A7C88B_AstNode zT_517 = {0};
    zT_8143F551_AstKind zT_518;
    zT_38C12417_SemanticAnalyzer* zT_523;
    unsigned int zT_524;
    zT_38C12417_SemanticAnalyzer* zT_525;
    unsigned int* zT_527;
    unsigned int zT_528;
    unsigned int zT_530 = 0;
    zT_38C12417_SemanticAnalyzer* zT_531;
    int zT_532;
    unsigned int zT_533;
    unsigned int zT_535;
    unsigned int zT_537;
    zT_6B0A7D14_AstStore* zT_541;
    unsigned int zT_542;
    zT_22A7C88B_AstNode zT_544 = {0};
    zT_8143F551_AstKind zT_545;
    unsigned int zT_546;
    unsigned char* zT_548;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_549;
    unsigned int zT_550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_551;
    unsigned int zT_552;
    unsigned char* zT_554;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_555;
    unsigned int zT_556;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_557;
    unsigned int zT_558;
    unsigned int zT_560;
    zT_38C12417_SemanticAnalyzer* zT_562;
    unsigned int zT_563;
    unsigned int zT_565 = 0;
    unsigned int zT_566;
    unsigned int zT_568;
    unsigned int* zT_572;
    unsigned int zT_573;
    unsigned int zT_574;
    zT_38C12417_SemanticAnalyzer* zT_577;
    unsigned int zT_578;
    unsigned char* zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned int zT_582;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_583;
    unsigned int zT_584;
    unsigned char* zT_587;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_588;
    unsigned int zT_589;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_590;
    unsigned int zT_591;
    unsigned char* zT_593;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_594;
    unsigned int zT_595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_596;
    unsigned int zT_597;
    unsigned char* zT_600;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    unsigned int zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    unsigned char* zT_607;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_608;
    unsigned int zT_609;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_610;
    unsigned int zT_611;
    zT_38C12417_SemanticAnalyzer* zT_617;
    unsigned int zT_618 = 0;
    unsigned int zT_620;
    int zT_623;
    zT_6B0A7D14_AstStore* zT_624;
    unsigned int zT_625;
    zT_22A7C88B_AstNode zT_628 = {0};
    zT_8143F551_AstKind zT_629;
    int zT_634;
    int zT_637;
    zT_338B7C76_TypeRegistry* zT_640;
    unsigned int zT_646 = 0;
    int zT_649;
    int zT_652;
    zT_0FB7FB13_CoercionKind zT_653;
    zT_338B7C76_TypeRegistry* zT_654;
    unsigned int zT_655;
    unsigned int zT_656;
    zT_0FB7FB13_CoercionKind zT_658 = 0;
    int zT_659 = 0;
    unsigned int zT_660;
    zT_38C12417_SemanticAnalyzer* zT_661;
    unsigned int zT_662;
    unsigned int zT_663;
    unsigned int zT_664;
    unsigned int zT_666;
    zT_338B7C76_TypeRegistry* zT_668;
    unsigned int zT_669;
    unsigned int zT_670;
    zT_0FB7FB13_CoercionKind zT_672 = 0;
    zT_38C12417_SemanticAnalyzer* zT_677;
    unsigned int zT_678;
    unsigned int zT_679;
    unsigned int zT_680;
    zT_338B7C76_TypeRegistry* zT_682;
    unsigned int zT_683;
    unsigned int zT_684;
    zT_0FB7FB13_CoercionKind zT_686 = 0;
    zT_38C12417_SemanticAnalyzer* zT_691;
    unsigned int zT_692;
    unsigned int zT_693;
    unsigned int zT_694;
    unsigned int zT_695;
    unsigned int zT_697;
    zT_338B7C76_TypeRegistry* zT_698;
    unsigned int zT_699;
    int zT_701 = 0;
    unsigned int zT_702;
    int zT_705;
    unsigned char* zT_709;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_710;
    unsigned int zT_711;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_712;
    unsigned char* zT_716;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_717;
    unsigned int zT_718;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_719;
    unsigned int zT_720;
    unsigned char* zT_722;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_723;
    unsigned int zT_724;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_725;
    unsigned int zT_726;
    unsigned char* zT_728;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_729;
    unsigned int zT_730;
    zT_338B7C76_TypeRegistry* zT_732;
    zT_D155D06D_Type* zT_733;
    unsigned int zT_734;
    zT_D155D06D_Type zT_735;
    zT_33EF6BFB_TypeKind zT_736;
    unsigned int zT_737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_738;
    unsigned int zT_739;
    unsigned char* zT_741;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_742;
    unsigned int zT_743;
    zT_338B7C76_TypeRegistry* zT_745;
    zT_D155D06D_Type* zT_746;
    unsigned int zT_747;
    zT_D155D06D_Type zT_748;
    zT_33EF6BFB_TypeKind zT_749;
    unsigned int zT_750;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_751;
    unsigned int zT_752;
    unsigned char* zT_754;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_755;
    unsigned int zT_756;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_757;
    unsigned int zT_758;
    unsigned char* zT_761;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_762;
    unsigned int zT_763;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_764;
    unsigned int zT_765;
    unsigned char* zT_768;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    unsigned int zT_770;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_771;
    unsigned char zT_773;
    unsigned char* zT_776;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_777;
    unsigned int zT_778;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_779;
    unsigned int zT_782;
    unsigned char* zT_785;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_786;
    unsigned int zT_787;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_788;
    unsigned int zT_789;
    zT_8EED1867_ResolvedTypeTable* zT_790;
    unsigned int zT_791;
    int zT_795;
    unsigned int zT_796;
    unsigned int zT_802;
    zT_8EED1867_ResolvedTypeTable* zT_803;
    unsigned int zT_804;
    unsigned int zT_805;
    unsigned char* zT_808;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_809;
    unsigned int zT_810;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_811;
    unsigned int zT_812;
    unsigned char* zT_814;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_815;
    unsigned int zT_816;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_817;
    unsigned int zT_818;
    unsigned int zT_819;
    zT_8F083A69_Slice_zT_0B42B2F8_u se;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swi_dm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_m;
    zT_5A26C2ED_Arr_unsigned_char_1 sep_b;
    unsigned int sep_l;
    unsigned int sep_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u sep_nl;
    unsigned int cond_type;
    unsigned int cond_es;
    zT_D155D06D_Type cond_ty;
    zT_3CB0179A_Slice_zT_05F374B1_u prongs;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swes_nl;
    zT_42C2D6BF_EUPayload cond_eu;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u sweu_nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_m;
    zT_5A26C2ED_Arr_unsigned_char_1 pr0_b;
    unsigned int pr0_l;
    unsigned int pr0_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u pr0_nl;
    unsigned int unified;
    unsigned int unified_node;
    unsigned char has_else;
    unsigned int i;
    unsigned int sw_base;
    zT_22A7C88B_AstNode prong;
    zT_8F083A69_Slice_zT_0B42B2F8_u swec_msg;
    unsigned int pct;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppt_m;
    zT_3CB0179A_Slice_zT_05F374B1_u case_ec;
    unsigned int ci;
    zT_22A7C88B_AstNode case_node;
    unsigned int cc_val;
    zT_8F083A69_Slice_zT_0B42B2F8_u cc_m;
    unsigned int cap_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_lm;
    zT_BAEE192E_Opt_10 ev;
    zT_8F083A69_Slice_zT_0B42B2F8_u sce_rm;
    unsigned int idx;
    zT_D155D06D_Type tu_ty;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_2DF01B61_FieldEntry fe;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u scfe_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u scax_tm;
    zT_3CB0179A_Slice_zT_05F374B1_u es_case_ec;
    unsigned int es_ci;
    unsigned int pbd_b0;
    unsigned int pbd_k0;
    zT_22A7C88B_AstNode es_case_node;
    zT_22A7C88B_AstNode pbd_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pbd_km;
    unsigned int saved_tu;
    unsigned int bt;
    unsigned int wi;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pct_fm;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u swpb_tm;
    unsigned int sw_exp0;
    unsigned int sw_peer;
    unsigned int unum;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_um;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_bm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_tk_m;
    unsigned int mix_tk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_uk_m;
    unsigned int mix_uk_v;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_cd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_b_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pf_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_pn_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u mix_ni_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u swu_tm;
    zT_2 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_2 + (unsigned int)(1));
    zT_6 = "SE";
    zT_8 = 2;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    se = zT_7;
    zT_9 = se;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    node = zT_14;
    zT_16 = "SWI:n";
    zT_18 = 5;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    swu_im = zT_17;
    zT_19 = swu_im;
    zT_20 = node_idx;
    zF_C914CB83_markerWriteInt(zT_19, zT_20);
    zT_22 = "SWI:p";
    zT_24 = 5;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    swu_pm = zT_23;
    zT_25 = swu_pm;
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_29 = node.kind;
    zT_32 = zF_0E4E10C6_astStoreNodePayload(zT_27, zT_28, zT_29);
    zF_C914CB83_markerWriteInt(zT_25, (unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_32 & (zT_79FAE712_u64)(4294967295u))));
    zT_37 = "SWI:d";
    zT_39 = 5;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    swi_dm = zT_38;
    zT_40 = swi_dm;
    zT_41 = self->switch_depth;
    zF_C914CB83_markerWriteInt(zT_40, zT_41);
    zT_43 = self->store;
    zT_44 = node_idx;
    zT_46 = zF_8BA26B9E_astStoreNodePayload(zT_43, zT_44);
    if ((int)(zT_46 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_50 = "P0: n";
    zT_52 = 5;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    sep_m = zT_51;
    zT_53 = sep_m;
    zF_48AC7B3A_markerWrite(zT_53);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_55[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        sep_b[_i] = zT_55[_i];
        _i++;
    }
}
    zT_57 = node_idx;
    zT_61 = 0;
    zT_62 = (unsigned char*)((unsigned char*)sep_b) + zT_61;
    zT_63 = (unsigned int)(10) - zT_61;
    zT_64.ptr = zT_62;
    zT_64.len = zT_63;
    zT_58 = zT_64;
    zT_65 = zF_A7504564_itoa(zT_57, zT_58);
    sep_l = zT_65;
    zT_69 = (unsigned int)(9) - (unsigned int)((unsigned int)sep_l);
    sep_s = zT_69;
    zT_74 = (unsigned char*)((unsigned char*)sep_b) + sep_s;
    zT_75 = (unsigned int)(9) - sep_s;
    zT_76.ptr = zT_74;
    zT_76.len = zT_75;
    zT_70 = zT_76;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_78 = "\n";
    zT_80 = 1;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    sep_nl = zT_79;
    zT_81 = sep_nl;
    zF_48AC7B3A_markerWrite(zT_81);
    zT_82 = self->type_table;
    zT_83 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_82, zT_83, (unsigned int)(1));
    zT_87 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_87 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_2:
    zT_92 = self;
    zT_93 = node.child_0;
    zT_95 = zF_54F95822_semanticAnalyzerRes(zT_92, zT_93);
    cond_type = zT_95;
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_98 = 0;
    cond_es = zT_98;
    if ((int)(cond_type != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_101 = cond_type != (unsigned int)(1);
    goto z_bb_5;
    z_bb_4:
    zT_101 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_101) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_105 = self->registry;
    zT_106 = zT_105->types_items;
    zT_107 = (unsigned int)cond_type;
    zT_108 = zT_106[zT_107];
    cond_ty = zT_108;
    zT_109 = cond_ty.kind;
    if ((int)(zT_109 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_9; else goto z_bb_8;
    z_bb_7:
    zT_165 = self->store;
    zT_166 = node_idx;
    zT_168 = zF_850FDF81_astStoreNodeExtraCh(zT_165, zT_166);
    prongs = zT_168;
    zT_170 = prongs.len;
    if ((int)(zT_170 == (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_8:
    zT_115 = cond_ty.kind;
    zT_114 = zT_115 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_10;
    z_bb_9:
    zT_114 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_114) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    self->current_switch_cond_tu = cond_type;
    zT_121 = "Z";
    zT_123 = 1;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    rs = zT_122;
    zT_124 = rs;
    zF_48AC7B3A_markerWrite(zT_124);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_7;
    z_bb_13:
    zT_125 = cond_ty.kind;
    if ((int)(zT_125 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cond_es = cond_type;
    zT_131 = "SWES:e";
    zT_133 = 6;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    swes_m = zT_132;
    zT_134 = swes_m;
    zT_135 = cond_es;
    zF_C914CB83_markerWriteInt(zT_134, zT_135);
    zT_137 = "\n";
    zT_139 = 1;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    swes_nl = zT_138;
    zT_140 = swes_nl;
    zF_48AC7B3A_markerWrite(zT_140);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_141 = cond_ty.kind;
    if ((int)(zT_141 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_147 = self->registry;
    zT_148 = zT_147->eu_items;
    zT_149 = cond_ty.payload_idx;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zT_148[zT_150];
    cond_eu = zT_151;
    zT_152 = cond_eu.error_set;
    cond_es = zT_152;
    zT_154 = "SWEU:e";
    zT_156 = 6;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    sweu_m = zT_155;
    zT_157 = sweu_m;
    zT_158 = cond_es;
    zF_C914CB83_markerWriteInt(zT_157, zT_158);
    zT_160 = "\n";
    zT_162 = 1;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    sweu_nl = zT_161;
    zT_163 = sweu_nl;
    zF_48AC7B3A_markerWrite(zT_163);
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_174 = "PL0:n";
    zT_176 = 5;
    zT_175.ptr = zT_174;
    zT_175.len = zT_176;
    pr0_m = zT_175;
    zT_177 = pr0_m;
    zF_48AC7B3A_markerWrite(zT_177);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_179[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        pr0_b[_i] = zT_179[_i];
        _i++;
    }
}
    zT_181 = node_idx;
    zT_185 = 0;
    zT_186 = (unsigned char*)((unsigned char*)pr0_b) + zT_185;
    zT_187 = (unsigned int)(10) - zT_185;
    zT_188.ptr = zT_186;
    zT_188.len = zT_187;
    zT_182 = zT_188;
    zT_189 = zF_A7504564_itoa(zT_181, zT_182);
    pr0_l = zT_189;
    zT_193 = (unsigned int)(9) - (unsigned int)((unsigned int)pr0_l);
    pr0_s = zT_193;
    zT_198 = (unsigned char*)((unsigned char*)pr0_b) + pr0_s;
    zT_199 = (unsigned int)(9) - pr0_s;
    zT_200.ptr = zT_198;
    zT_200.len = zT_199;
    zT_194 = zT_200;
    zF_48AC7B3A_markerWrite(zT_194);
    zT_202 = "\n";
    zT_204 = 1;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    pr0_nl = zT_203;
    zT_205 = pr0_nl;
    zF_48AC7B3A_markerWrite(zT_205);
    self->current_switch_cond_tu = (unsigned int)(0);
    zT_207 = self->type_table;
    zT_208 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_207, zT_208, (unsigned int)(1));
    zT_212 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_212 - (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_20:
    zT_217 = 0;
    unified = zT_217;
    zT_219 = 0;
    unified_node = zT_219;
    zT_221 = 0;
    zT_222 = (unsigned char)zT_221;
    has_else = zT_222;
    zT_224 = 0;
    zT_225 = (unsigned int)zT_224;
    i = zT_225;
    zT_227 = self->stmt_work_len;
    sw_base = zT_227;
    goto z_bb_21;
    z_bb_21:
    zT_229 = prongs.len;
    if ((int)(i < zT_229)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_232 = self->store;
    zT_235 = prongs.ptr;
    zT_233 = zT_235[i];
    zT_237 = zF_FCDD1D35_astStoreNodeAt(zT_232, zT_233);
    prong = zT_237;
    zT_238 = prong.flags;
    if ((int)((unsigned char)(zT_238 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    self->current_switch_cond_tu = (unsigned int)(0);
    if ((int)(has_else == (unsigned char)(0))) goto z_bb_119; else goto z_bb_120;
    z_bb_24:
    zT_795 = 1;
    zT_796 = i + zT_795;
    i = zT_796;
    goto z_bb_21;
    z_bb_25:
    zT_243 = 1;
    zT_244 = (unsigned char)zT_243;
    has_else = zT_244;
    goto z_bb_26;
    z_bb_26:
    zT_245 = prong.flags;
    if ((int)((unsigned char)(zT_245 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_251 = prong.flags;
    zT_250 = (unsigned char)(zT_251 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_29;
    z_bb_28:
    zT_250 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_250) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_257 = "switch else-prong capture (else => |capture|) is not supported";
    zT_259 = 62;
    zT_258.ptr = zT_257;
    zT_258.len = zT_259;
    swec_msg = zT_258;
    zT_260 = self->diag;
    zT_263 = self->source_file_id;
    zT_264 = node_idx;
    zT_265 = node_idx;
    zT_266 = swec_msg;
    zT_271 = zF_C82559AC_diagnosticCollector(zT_260, (unsigned char)(0), (unsigned short)(3001), zT_263, zT_264, zT_265, zT_266);
    (void)zT_271;
    return (unsigned int)(1);
    z_bb_31:
    zT_274 = self->current_switch_cond_tu;
    pct = zT_274;
    zT_276 = self->store;
    zT_279 = prongs.ptr;
    zT_277 = zT_279[i];
    (void)zF_8BA26B9E_astStoreNodePayload(zT_276, zT_277);
    zT_283 = "PCT:C";
    zT_285 = 5;
    zT_284.ptr = zT_283;
    zT_284.len = zT_285;
    pct_m2 = zT_284;
    zT_286 = pct_m2;
    zT_287 = pct;
    zF_C914CB83_markerWriteInt(zT_286, zT_287);
    zT_289 = "PCT:P";
    zT_291 = 5;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    ppt_m = zT_290;
    zT_292 = ppt_m;
    zT_294 = self->store;
    zT_298 = prongs.ptr;
    zT_295 = zT_298[i];
    zT_296 = prong.kind;
    zT_301 = zF_0E4E10C6_astStoreNodePayload(zT_294, zT_295, zT_296);
    zF_C914CB83_markerWriteInt(zT_292, (unsigned int)((unsigned int)(zT_79FAE712_u64)(zT_301 & (zT_79FAE712_u64)(4294967295u))));
    zT_305 = self->current_switch_cond_tu;
    if ((int)(zT_305 != (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_309 = self->store;
    zT_312 = prongs.ptr;
    zT_310 = zT_312[i];
    zT_314 = zF_8BA26B9E_astStoreNodePayload(zT_309, zT_310);
    zT_308 = zT_314 != (unsigned int)(0);
    goto z_bb_34;
    z_bb_33:
    zT_308 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_308) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_318 = self->store;
    zT_321 = prongs.ptr;
    zT_319 = zT_321[i];
    zT_323 = zF_850FDF81_astStoreNodeExtraCh(zT_318, zT_319);
    case_ec = zT_323;
    zT_325 = 0;
    zT_326 = (unsigned int)zT_325;
    ci = zT_326;
    goto z_bb_37;
    z_bb_36:
    if ((int)(cond_es != (unsigned int)(0))) goto z_bb_57; else goto z_bb_58;
    z_bb_37:
    zT_328 = case_ec.len;
    if ((int)(ci < zT_328)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_331 = self->store;
    zT_334 = case_ec.ptr;
    zT_332 = zT_334[ci];
    zT_336 = zF_FCDD1D35_astStoreNodeAt(zT_331, zT_332);
    case_node = zT_336;
    zT_338 = case_node.kind;
    zT_339 = (unsigned int)zT_338;
    cc_val = zT_339;
    zT_341 = "CC:K";
    zT_343 = 4;
    zT_342.ptr = zT_341;
    zT_342.len = zT_343;
    cc_m = zT_342;
    zT_344 = cc_m;
    zT_345 = cc_val;
    zF_C914CB83_markerWriteInt(zT_344, zT_345);
    zT_346 = case_node.kind;
    if ((int)(zT_346 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_41; else goto z_bb_43;
    z_bb_39:
    zT_370 = prong.flags;
    if ((int)((unsigned char)(zT_370 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_40:
    zT_368 = 1;
    zT_369 = ci + zT_368;
    ci = zT_369;
    goto z_bb_37;
    z_bb_41:
    zT_351 = self;
    zT_353 = case_ec.ptr;
    zT_354 = zT_353[ci];
    zT_356 = zF_8C008E53_semanticAnalyzerRes(zT_351, (unsigned int)((unsigned int)zT_354));
    (void)zT_356;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_357 = case_node.kind;
    if ((int)(zT_357 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_362 = self;
    zT_364 = case_ec.ptr;
    zT_365 = zT_364[ci];
    zT_367 = zF_8C008E53_semanticAnalyzerRes(zT_362, (unsigned int)((unsigned int)zT_365));
    (void)zT_367;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_376 = prong.child_1;
    cap_name = zT_376;
    zT_378 = "SCE:p";
    zT_380 = 5;
    zT_379.ptr = zT_378;
    zT_379.len = zT_380;
    sce_pm = zT_379;
    zT_381 = sce_pm;
    zT_382 = cap_name;
    zF_C914CB83_markerWriteInt(zT_381, zT_382);
    zT_384 = "SCE:l";
    zT_386 = 5;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    sce_lm = zT_385;
    zT_387 = sce_lm;
    zT_390 = case_ec.len;
    zF_C914CB83_markerWriteInt(zT_387, (unsigned int)((unsigned int)zT_390));
    zT_393 = case_ec.len;
    if ((int)(zT_393 > (unsigned int)(0))) goto z_bb_48; else goto z_bb_50;
    z_bb_47:
    goto z_bb_36;
    z_bb_48:
    zT_397 = self->enum_value_table;
    zT_400 = case_ec.ptr;
    zT_401 = 0;
    zT_398 = zT_400[zT_401];
    zT_403 = zF_F3EE5998_u32ToU32MapGet(zT_397, zT_398);
    ev = zT_403;
    zT_404 = ev.has_value;
    if (zT_404) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_478 = "SCE:R";
    zT_480 = 5;
    zT_479.ptr = zT_478;
    zT_479.len = zT_480;
    sce_rm = zT_479;
    zT_481 = sce_rm;
    zT_482 = cap_name;
    zF_C914CB83_markerWriteInt(zT_481, zT_482);
    zT_483 = self;
    zT_484 = cap_name;
    zT_485 = self->current_switch_cond_tu;
    zF_7BD72017_registerLocalDecl(zT_483, zT_484, zT_485);
    goto z_bb_49;
    z_bb_51:
    idx = ev.value;
    zT_407 = self->registry;
    zT_408 = zT_407->types_items;
    zT_409 = self->current_switch_cond_tu;
    zT_410 = (unsigned int)zT_409;
    zT_411 = zT_408[zT_410];
    tu_ty = zT_411;
    zT_412 = tu_ty.kind;
    if ((int)(zT_412 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_418 = self->registry;
    zT_419 = zT_418->tu_items;
    zT_420 = tu_ty.payload_idx;
    zT_421 = (unsigned int)zT_420;
    zT_422 = zT_419[zT_421];
    tp = zT_422;
    zT_424 = self->registry;
    zT_425 = zT_424->fe_items;
    zT_426 = tp.fields_start;
    zT_429 = (unsigned int)((unsigned int)zT_426) + (unsigned int)((unsigned int)idx);
    zT_430 = zT_425[zT_429];
    fe = zT_430;
    zT_432 = "SCFE:n";
    zT_434 = 6;
    zT_433.ptr = zT_432;
    zT_433.len = zT_434;
    scfe_nm = zT_433;
    zT_435 = scfe_nm;
    zT_436 = cap_name;
    zF_C914CB83_markerWriteInt(zT_435, zT_436);
    zT_438 = "SCFE:t";
    zT_440 = 6;
    zT_439.ptr = zT_438;
    zT_439.len = zT_440;
    scfe_tm = zT_439;
    zT_441 = scfe_tm;
    zT_442 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_441, zT_442);
    zT_445 = "SCFE:k";
    zT_447 = 6;
    zT_446.ptr = zT_445;
    zT_446.len = zT_447;
    scfe_km = zT_446;
    zT_448 = scfe_km;
    zT_450 = tu_ty.kind;
    zF_C914CB83_markerWriteInt(zT_448, (unsigned int)((unsigned int)zT_450));
    zT_452 = self->local_decl_count;
    zT_453 = self->local_decl_cap;
    if ((int)(zT_452 >= zT_453)) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_455 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_455);
    goto z_bb_56;
    z_bb_56:
    zT_456 = self->local_decl_names;
    zT_457 = self->local_decl_count;
    zT_456[zT_457] = cap_name;
    zT_458 = fe.type_id;
    zT_459 = self->local_decl_types;
    zT_460 = self->local_decl_count;
    zT_459[zT_460] = zT_458;
    zT_461 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_461 + (unsigned int)(1));
    zT_465 = "SCAX:N";
    zT_467 = 6;
    zT_466.ptr = zT_465;
    zT_466.len = zT_467;
    scax_m = zT_466;
    zT_468 = scax_m;
    zT_469 = cap_name;
    zF_C914CB83_markerWriteInt(zT_468, zT_469);
    zT_471 = "SCAX:T";
    zT_473 = 6;
    zT_472.ptr = zT_471;
    zT_472.len = zT_473;
    scax_tm = zT_472;
    zT_474 = scax_tm;
    zT_475 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_474, zT_475);
    goto z_bb_54;
    z_bb_57:
    zT_490 = self->store;
    zT_493 = prongs.ptr;
    zT_491 = zT_493[i];
    zT_495 = zF_8BA26B9E_astStoreNodePayload(zT_490, zT_491);
    zT_489 = zT_495 != (unsigned int)(0);
    goto z_bb_59;
    z_bb_58:
    zT_489 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_489) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_499 = self->store;
    zT_502 = prongs.ptr;
    zT_500 = zT_502[i];
    zT_504 = zF_850FDF81_astStoreNodeExtraCh(zT_499, zT_500);
    es_case_ec = zT_504;
    zT_506 = 0;
    zT_507 = (unsigned int)zT_506;
    es_ci = zT_507;
    goto z_bb_62;
    z_bb_61:
    zT_535 = prong.child_0;
    pbd_b0 = zT_535;
    zT_537 = 0;
    pbd_k0 = zT_537;
    if ((int)(pbd_b0 != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_62:
    zT_509 = es_case_ec.len;
    if ((int)(es_ci < zT_509)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_512 = self->store;
    zT_515 = es_case_ec.ptr;
    zT_513 = zT_515[es_ci];
    zT_517 = zF_FCDD1D35_astStoreNodeAt(zT_512, zT_513);
    es_case_node = zT_517;
    zT_518 = es_case_node.kind;
    if ((int)(zT_518 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_532 = 1;
    zT_533 = es_ci + zT_532;
    es_ci = zT_533;
    goto z_bb_62;
    z_bb_66:
    zT_523 = self;
    zT_524 = cond_es;
    zF_9665A229_pushExpectedType(zT_523, zT_524);
    zT_525 = self;
    zT_527 = es_case_ec.ptr;
    zT_528 = zT_527[es_ci];
    zT_530 = zF_54F95822_semanticAnalyzerRes(zT_525, (unsigned int)((unsigned int)zT_528));
    (void)zT_530;
    zT_531 = self;
    zF_BC478E78_popExpectedType(zT_531);
    goto z_bb_67;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_541 = self->store;
    zT_542 = pbd_b0;
    zT_544 = zF_FCDD1D35_astStoreNodeAt(zT_541, zT_542);
    pbd_n = zT_544;
    zT_545 = pbd_n.kind;
    zT_546 = (unsigned int)zT_545;
    pbd_k0 = zT_546;
    goto z_bb_69;
    z_bb_69:
    zT_548 = "PBD:N";
    zT_550 = 5;
    zT_549.ptr = zT_548;
    zT_549.len = zT_550;
    pbd_nm = zT_549;
    zT_551 = pbd_nm;
    zT_552 = pbd_b0;
    zF_C914CB83_markerWriteInt(zT_551, zT_552);
    zT_554 = "PBD:K";
    zT_556 = 5;
    zT_555.ptr = zT_554;
    zT_555.len = zT_556;
    pbd_km = zT_555;
    zT_557 = pbd_km;
    zT_558 = pbd_k0;
    zF_C914CB83_markerWriteInt(zT_557, zT_558);
    zT_560 = self->current_switch_cond_tu;
    saved_tu = zT_560;
    zT_562 = self;
    zT_563 = prong.child_0;
    zT_565 = zF_54F95822_semanticAnalyzerRes(zT_562, zT_563);
    bt = zT_565;
    self->current_switch_cond_tu = saved_tu;
    goto z_bb_70;
    z_bb_70:
    zT_566 = self->stmt_work_len;
    if ((int)(zT_566 > sw_base)) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_568 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_568 - (unsigned int)(1));
    zT_572 = self->stmt_work_items;
    zT_573 = self->stmt_work_len;
    zT_574 = zT_572[zT_573];
    wi = zT_574;
    if ((int)(wi != (unsigned int)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_580 = "PCT:n";
    zT_582 = 5;
    zT_581.ptr = zT_580;
    zT_581.len = zT_582;
    pct_m = zT_581;
    zT_583 = pct_m;
    zT_584 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_583, zT_584);
    zT_587 = "PCT:b";
    zT_589 = 5;
    zT_588.ptr = zT_587;
    zT_588.len = zT_589;
    pct_bm = zT_588;
    zT_590 = pct_bm;
    zT_591 = bt;
    zF_C914CB83_markerWriteInt(zT_590, zT_591);
    zT_593 = "PCT:f";
    zT_595 = 5;
    zT_594.ptr = zT_593;
    zT_594.len = zT_595;
    pct_fm = zT_594;
    zT_596 = pct_fm;
    zT_597 = self->current_fn_return;
    zF_C914CB83_markerWriteInt(zT_596, zT_597);
    zT_600 = "SWPB:i";
    zT_602 = 6;
    zT_601.ptr = zT_600;
    zT_601.len = zT_602;
    swpb_im = zT_601;
    zT_603 = swpb_im;
    zF_C914CB83_markerWriteInt(zT_603, (unsigned int)((unsigned int)i));
    zT_607 = "SWPB:t";
    zT_609 = 6;
    zT_608.ptr = zT_607;
    zT_608.len = zT_609;
    swpb_tm = zT_608;
    zT_610 = swpb_tm;
    zT_611 = bt;
    zF_C914CB83_markerWriteInt(zT_610, zT_611);
    if ((int)(bt == (unsigned int)(3))) goto z_bb_76; else goto z_bb_78;
    z_bb_73:
    goto z_bb_70;
    z_bb_74:
    zT_577 = self;
    zT_578 = wi;
    zF_10A0DC35_semanticAnalyzerRes(zT_577, zT_578);
    goto z_bb_75;
    z_bb_75:
    goto z_bb_73;
    z_bb_76:
    goto z_bb_77;
    z_bb_77:
    goto z_bb_24;
    z_bb_78:
    if ((int)(unified == (unsigned int)(0))) goto z_bb_79; else goto z_bb_81;
    z_bb_79:
    zT_617 = self;
    zT_618 = zF_4DE7C2BC_topExpectedType(zT_617);
    sw_exp0 = zT_618;
    sw_peer = sw_exp0;
    zT_620 = prong.child_0;
    if ((int)(zT_620 != (unsigned int)(0))) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    goto z_bb_77;
    z_bb_81:
    if ((int)(bt == unified)) goto z_bb_102; else goto z_bb_104;
    z_bb_82:
    zT_624 = self->store;
    zT_625 = prong.child_0;
    zT_628 = zF_FCDD1D35_astStoreNodeAt(zT_624, zT_625);
    zT_629 = zT_628.kind;
    zT_623 = zT_629 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal);
    goto z_bb_84;
    z_bb_83:
    zT_623 = 0;
    goto z_bb_84;
    z_bb_84:
    if (zT_623) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    if ((int)(sw_exp0 == (unsigned int)(0))) goto z_bb_89; else goto z_bb_88;
    z_bb_86:
    zT_634 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_634) goto z_bb_91; else goto z_bb_92;
    z_bb_88:
    zT_637 = sw_exp0 == (unsigned int)(1);
    goto z_bb_90;
    z_bb_89:
    zT_637 = 1;
    goto z_bb_90;
    z_bb_90:
    zT_634 = zT_637;
    goto z_bb_87;
    z_bb_91:
    zT_640 = self->registry;
    zT_646 = zF_8FC81A87_typeRegistryGetOrCr(zT_640, (unsigned int)(8), (int)(1));
    sw_peer = zT_646;
    goto z_bb_92;
    z_bb_92:
    if ((int)(sw_peer != (unsigned int)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_649 = sw_peer != (unsigned int)(1);
    goto z_bb_95;
    z_bb_94:
    zT_649 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_649) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_654 = self->registry;
    zT_655 = bt;
    zT_656 = sw_peer;
    zT_658 = zF_713658BF_classifyCoercion(zT_654, zT_655, zT_656);
    zT_653 = zT_658;
    zT_659 = zF_71304A07_isStringLiteralSlic(zT_653);
    zT_652 = zT_659;
    goto z_bb_98;
    z_bb_97:
    zT_652 = 0;
    goto z_bb_98;
    z_bb_98:
    if (zT_652) goto z_bb_99; else goto z_bb_101;
    z_bb_99:
    unified = sw_peer;
    zT_660 = prong.child_0;
    unified_node = zT_660;
    zT_661 = self;
    zT_662 = prong.child_0;
    zT_663 = bt;
    zT_664 = sw_peer;
    zF_DF7434EB_tryRecordCoercion(zT_661, zT_662, zT_663, zT_664);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_80;
    z_bb_101:
    unified = bt;
    zT_666 = prong.child_0;
    unified_node = zT_666;
    goto z_bb_100;
    z_bb_102:
    goto z_bb_103;
    z_bb_103:
    goto z_bb_80;
    z_bb_104:
    zT_668 = self->registry;
    zT_669 = bt;
    zT_670 = unified;
    zT_672 = zF_713658BF_classifyCoercion(zT_668, zT_669, zT_670);
    if ((int)(zT_672 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    zT_677 = self;
    zT_678 = prong.child_0;
    zT_679 = bt;
    zT_680 = unified;
    zF_DF7434EB_tryRecordCoercion(zT_677, zT_678, zT_679, zT_680);
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_682 = self->registry;
    zT_683 = unified;
    zT_684 = bt;
    zT_686 = zF_713658BF_classifyCoercion(zT_682, zT_683, zT_684);
    if ((int)(zT_686 != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_108; else goto z_bb_110;
    z_bb_108:
    zT_691 = self;
    zT_692 = unified_node;
    zT_693 = unified;
    zT_694 = bt;
    zF_DF7434EB_tryRecordCoercion(zT_691, zT_692, zT_693, zT_694);
    unified = bt;
    zT_695 = prong.child_0;
    unified_node = zT_695;
    goto z_bb_109;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    zT_697 = 0;
    unum = zT_697;
    zT_698 = self->registry;
    zT_699 = bt;
    zT_701 = zF_3087E0A5_typeRegistryIsNumer(zT_698, zT_699);
    if (zT_701) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_702 = 1;
    unum = zT_702;
    goto z_bb_112;
    z_bb_112:
    if ((int)(unified == (unsigned int)(19))) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_705 = unum != (unsigned int)(0);
    goto z_bb_115;
    z_bb_114:
    zT_705 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_705) goto z_bb_116; else goto z_bb_118;
    z_bb_116:
    unified = bt;
    goto z_bb_117;
    z_bb_117:
    goto z_bb_109;
    z_bb_118:
    zT_709 = "MIX:P";
    zT_711 = 5;
    zT_710.ptr = zT_709;
    zT_710.len = zT_711;
    mix_pm = zT_710;
    zT_712 = mix_pm;
    zF_C914CB83_markerWriteInt(zT_712, (unsigned int)((unsigned int)i));
    zT_716 = "MIX:U";
    zT_718 = 5;
    zT_717.ptr = zT_716;
    zT_717.len = zT_718;
    mix_um = zT_717;
    zT_719 = mix_um;
    zT_720 = unified;
    zF_C914CB83_markerWriteInt(zT_719, zT_720);
    zT_722 = "MIX:B";
    zT_724 = 5;
    zT_723.ptr = zT_722;
    zT_723.len = zT_724;
    mix_bm = zT_723;
    zT_725 = mix_bm;
    zT_726 = bt;
    zF_C914CB83_markerWriteInt(zT_725, zT_726);
    zT_728 = "MIX:tk";
    zT_730 = 6;
    zT_729.ptr = zT_728;
    zT_729.len = zT_730;
    mix_tk_m = zT_729;
    zT_732 = self->registry;
    zT_733 = zT_732->types_items;
    zT_734 = (unsigned int)bt;
    zT_735 = zT_733[zT_734];
    zT_736 = zT_735.kind;
    zT_737 = (unsigned int)zT_736;
    mix_tk_v = zT_737;
    zT_738 = mix_tk_m;
    zT_739 = mix_tk_v;
    zF_C914CB83_markerWriteInt(zT_738, zT_739);
    zT_741 = "MIX:uk";
    zT_743 = 6;
    zT_742.ptr = zT_741;
    zT_742.len = zT_743;
    mix_uk_m = zT_742;
    zT_745 = self->registry;
    zT_746 = zT_745->types_items;
    zT_747 = (unsigned int)unified;
    zT_748 = zT_746[zT_747];
    zT_749 = zT_748.kind;
    zT_750 = (unsigned int)zT_749;
    mix_uk_v = zT_750;
    zT_751 = mix_uk_m;
    zT_752 = mix_uk_v;
    zF_C914CB83_markerWriteInt(zT_751, zT_752);
    zT_754 = "MIX:cd";
    zT_756 = 6;
    zT_755.ptr = zT_754;
    zT_755.len = zT_756;
    mix_cd_m = zT_755;
    zT_757 = mix_cd_m;
    zT_758 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_757, zT_758);
    zT_761 = "MIX:b";
    zT_763 = 5;
    zT_762.ptr = zT_761;
    zT_762.len = zT_763;
    mix_b_m = zT_762;
    zT_764 = mix_b_m;
    zT_765 = prong.child_0;
    zF_C914CB83_markerWriteInt(zT_764, zT_765);
    zT_768 = "MIX:pf";
    zT_770 = 6;
    zT_769.ptr = zT_768;
    zT_769.len = zT_770;
    mix_pf_m = zT_769;
    zT_771 = mix_pf_m;
    zT_773 = prong.flags;
    zF_C914CB83_markerWriteInt(zT_771, (unsigned int)((unsigned int)zT_773));
    zT_776 = "MIX:pn";
    zT_778 = 6;
    zT_777.ptr = zT_776;
    zT_777.len = zT_778;
    mix_pn_m = zT_777;
    zT_779 = mix_pn_m;
    zT_782 = prongs.len;
    zF_C914CB83_markerWriteInt(zT_779, (unsigned int)((unsigned int)zT_782));
    zT_785 = "MIX:ni";
    zT_787 = 6;
    zT_786.ptr = zT_785;
    zT_786.len = zT_787;
    mix_ni_m = zT_786;
    zT_788 = mix_ni_m;
    zT_789 = node_idx;
    zF_C914CB83_markerWriteInt(zT_788, zT_789);
    zT_790 = self->type_table;
    zT_791 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_790, zT_791, (unsigned int)(1));
    goto z_bb_24;
    z_bb_119:
    goto z_bb_120;
    z_bb_120:
    if ((int)(unified == (unsigned int)(0))) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_802 = 3;
    unified = zT_802;
    goto z_bb_122;
    z_bb_122:
    zT_803 = self->type_table;
    zT_804 = node_idx;
    zT_805 = unified;
    zF_19B4A07D_resolvedTypeTableSe(zT_803, zT_804, zT_805);
    zT_808 = "SWU:n";
    zT_810 = 5;
    zT_809.ptr = zT_808;
    zT_809.len = zT_810;
    swu_m = zT_809;
    zT_811 = swu_m;
    zT_812 = node_idx;
    zF_C914CB83_markerWriteInt(zT_811, zT_812);
    zT_814 = "SWU:t";
    zT_816 = 5;
    zT_815.ptr = zT_814;
    zT_815.len = zT_816;
    swu_tm = zT_815;
    zT_817 = swu_tm;
    zT_818 = unified;
    zF_C914CB83_markerWriteInt(zT_817, zT_818);
    zT_819 = self->switch_depth;
    self->switch_depth = (unsigned int)(zT_819 - (unsigned int)(1));
    return unified;
}

/* semanticAnalyzerResolveExpr */
unsigned int zF_54F95822_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    unsigned int zT_12;
    zT_8143F551_AstKind zT_13;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8143F551_AstKind zT_29;
    unsigned int zT_34;
    zT_8143F551_AstKind zT_35;
    unsigned int zT_40;
    zT_8143F551_AstKind zT_41;
    unsigned int zT_46;
    zT_8143F551_AstKind zT_47;
    unsigned int zT_52;
    zT_8143F551_AstKind zT_53;
    unsigned int zT_58;
    zT_8143F551_AstKind zT_59;
    unsigned int zT_64;
    zT_8143F551_AstKind zT_65;
    unsigned int zT_70;
    zT_8143F551_AstKind zT_71;
    unsigned int zT_77;
    zT_6B0A7D14_AstStore* zT_79;
    unsigned int zT_80;
    unsigned int zT_82 = 0;
    zT_6B0A7D14_AstStore* zT_84;
    zT_D6EFFE14_anon_224394 zT_85;
    unsigned int zT_86;
    zT_6B0A7D14_AstStore* zT_89;
    zT_D6EFFE14_anon_224394 zT_90;
    unsigned int* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_D3EB6303_StringInterner* zT_95;
    unsigned int zT_96;
    zT_338B7C76_TypeRegistry* zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99 = {0};
    unsigned int zT_101;
    unsigned int zT_102;
    zT_338B7C76_TypeRegistry* zT_104;
    unsigned int zT_106;
    unsigned int zT_109 = 0;
    zT_338B7C76_TypeRegistry* zT_110;
    unsigned int zT_111;
    unsigned int zT_115 = 0;
    zT_8143F551_AstKind zT_116;
    zT_38C12417_SemanticAnalyzer* zT_121;
    unsigned int zT_122;
    unsigned int zT_123 = 0;
    zT_8143F551_AstKind zT_124;
    unsigned int zT_129;
    int zT_130;
    unsigned int* zT_133;
    unsigned int zT_134;
    int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    int zT_138;
    int zT_141;
    unsigned int zT_142;
    zT_338B7C76_TypeRegistry* zT_144;
    zT_D155D06D_Type* zT_145;
    unsigned int zT_146;
    zT_D155D06D_Type zT_147;
    zT_33EF6BFB_TypeKind zT_149;
    zT_338B7C76_TypeRegistry* zT_155;
    zT_0B10E8E9_OptionalPayload* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    zT_0B10E8E9_OptionalPayload zT_159;
    unsigned int zT_160;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_D155D06D_Type* zT_162;
    unsigned int zT_163;
    zT_D155D06D_Type zT_164;
    zT_33EF6BFB_TypeKind zT_165;
    zT_33EF6BFB_TypeKind zT_170;
    zT_338B7C76_TypeRegistry* zT_175;
    zT_42C2D6BF_EUPayload* zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    zT_42C2D6BF_EUPayload zT_179;
    unsigned int zT_180;
    int zT_181;
    zT_6B0A7D14_AstStore* zT_184;
    unsigned int zT_185;
    unsigned int zT_187 = 0;
    zT_338B7C76_TypeRegistry* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    unsigned int zT_193 = 0;
    zT_21D3708C_U32ToU32Map* zT_197;
    unsigned int zT_198;
    unsigned int zT_200 = 0;
    zT_21D3708C_U32ToU32Map* zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    zT_8EED1867_ResolvedTypeTable* zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int zT_210;
    unsigned int zT_212;
    unsigned int zT_214;
    unsigned char* zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_218;
    zT_F85C5DED_DiagnosticCollector* zT_219;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned int zT_233 = 0;
    unsigned int zT_234;
    zT_33EF6BFB_TypeKind zT_235;
    zT_8EED1867_ResolvedTypeTable* zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned int zT_244;
    unsigned int zT_245;
    unsigned int zT_246;
    zT_8143F551_AstKind zT_247;
    zT_38C12417_SemanticAnalyzer* zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    zT_6B0A7D14_AstStore* zT_257;
    unsigned int zT_258;
    unsigned int zT_260 = 0;
    unsigned int zT_261 = 0;
    zT_8143F551_AstKind zT_262;
    zT_38C12417_SemanticAnalyzer* zT_267;
    unsigned int zT_268;
    unsigned int zT_269 = 0;
    unsigned char* zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_8143F551_AstKind zT_276;
    zT_38C12417_SemanticAnalyzer* zT_281;
    unsigned int zT_282;
    unsigned int zT_283 = 0;
    zT_8143F551_AstKind zT_284;
    zT_38C12417_SemanticAnalyzer* zT_289;
    unsigned int zT_290;
    unsigned int zT_291 = 0;
    zT_8143F551_AstKind zT_292;
    zT_38C12417_SemanticAnalyzer* zT_298;
    unsigned int zT_299;
    unsigned int zT_301 = 0;
    int zT_304;
    zT_338B7C76_TypeRegistry* zT_308;
    zT_D155D06D_Type* zT_309;
    unsigned int zT_310;
    zT_D155D06D_Type zT_311;
    zT_33EF6BFB_TypeKind zT_312;
    int zT_317;
    zT_33EF6BFB_TypeKind zT_318;
    zT_338B7C76_TypeRegistry* zT_324;
    zT_112BF819_PtrPayload* zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    zT_112BF819_PtrPayload zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    zT_8143F551_AstKind zT_331;
    zT_38C12417_SemanticAnalyzer* zT_337;
    unsigned int zT_338;
    unsigned int zT_340 = 0;
    int zT_343;
    zT_6B0A7D14_AstStore* zT_347;
    unsigned int zT_348;
    zT_22A7C88B_AstNode zT_351 = {0};
    zT_8143F551_AstKind zT_352;
    zT_38C12417_SemanticAnalyzer* zT_358;
    unsigned int zT_359;
    unsigned int zT_361 = 0;
    int zT_365;
    zT_338B7C76_TypeRegistry* zT_369;
    zT_D155D06D_Type* zT_370;
    unsigned int zT_371;
    zT_D155D06D_Type zT_372;
    zT_33EF6BFB_TypeKind zT_373;
    int zT_378;
    zT_33EF6BFB_TypeKind zT_379;
    zT_338B7C76_TypeRegistry* zT_384;
    zT_112BF819_PtrPayload* zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    zT_112BF819_PtrPayload zT_388;
    unsigned int zT_389;
    zT_338B7C76_TypeRegistry* zT_390;
    zT_D155D06D_Type* zT_391;
    unsigned int zT_392;
    zT_D155D06D_Type zT_393;
    zT_33EF6BFB_TypeKind zT_394;
    zT_38C12417_SemanticAnalyzer* zT_400;
    unsigned int zT_401;
    unsigned int zT_402 = 0;
    unsigned int zT_406;
    unsigned int zT_408;
    unsigned int zT_410;
    unsigned char* zT_412;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_413;
    unsigned int zT_414;
    zT_F85C5DED_DiagnosticCollector* zT_415;
    unsigned int zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421;
    unsigned int zT_426 = 0;
    zT_33EF6BFB_TypeKind zT_427;
    unsigned int zT_433;
    unsigned int zT_435;
    unsigned int zT_437;
    unsigned char* zT_439;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_440;
    unsigned int zT_441;
    zT_F85C5DED_DiagnosticCollector* zT_442;
    unsigned int zT_445;
    unsigned int zT_446;
    unsigned int zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_448;
    unsigned int zT_453 = 0;
    zT_338B7C76_TypeRegistry* zT_454;
    unsigned int zT_455;
    unsigned int zT_459 = 0;
    unsigned int zT_460;
    zT_8143F551_AstKind zT_461;
    zT_38C12417_SemanticAnalyzer* zT_466;
    unsigned int zT_467;
    unsigned int zT_468 = 0;
    zT_8143F551_AstKind zT_469;
    int zT_474;
    zT_38C12417_SemanticAnalyzer* zT_475;
    unsigned int zT_476;
    int zT_478 = 0;
    unsigned char* zT_481;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_482;
    unsigned int zT_483;
    zT_F85C5DED_DiagnosticCollector* zT_484;
    unsigned int zT_487;
    unsigned int zT_488;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_490;
    unsigned int zT_496;
    unsigned int zT_497;
    unsigned int zT_500 = 0;
    unsigned int zT_501;
    zT_8143F551_AstKind zT_502;
    zT_6B0A7D14_AstStore* zT_508;
    unsigned int zT_509;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_511 = {0};
    unsigned char* zT_513;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_514;
    unsigned int zT_515;
    unsigned int zT_516;
    unsigned int zT_517;
    int zT_519;
    unsigned int zT_520;
    unsigned int zT_521;
    int zT_523;
    unsigned int zT_524;
    unsigned int zT_525;
    int zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    int zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    unsigned int zT_536;
    zT_ABC1EBBE_TypeResolveEnv zT_540;
    zT_6B0A7D14_AstStore* zT_541;
    zT_338B7C76_TypeRegistry* zT_542;
    zT_3D7259E2_SymbolRegistry* zT_543;
    zT_D3EB6303_StringInterner* zT_544;
    unsigned int zT_545;
    zT_F85C5DED_DiagnosticCollector* zT_546;
    zT_7334F4FE_Opt_225 zT_547;
    zT_F6B96876_Opt_395 zT_548 = {0};
    unsigned int zT_549;
    zT_ABC1EBBE_TypeResolveEnv* zT_550;
    unsigned int zT_551;
    unsigned int* zT_554;
    unsigned int zT_555;
    unsigned int zT_558 = 0;
    unsigned int zT_559;
    unsigned int zT_560;
    unsigned int zT_561;
    int zT_563;
    unsigned int zT_564;
    unsigned int zT_565;
    unsigned int zT_568;
    zT_38C12417_SemanticAnalyzer* zT_571;
    unsigned int zT_572;
    unsigned int* zT_573;
    unsigned int zT_574;
    unsigned int zT_576 = 0;
    unsigned int zT_577;
    unsigned int zT_578;
    unsigned int zT_579;
    unsigned int zT_583;
    unsigned int zT_585;
    zT_38C12417_SemanticAnalyzer* zT_588;
    unsigned int zT_589;
    unsigned int* zT_590;
    unsigned int zT_591;
    unsigned int zT_593 = 0;
    zT_38C12417_SemanticAnalyzer* zT_595;
    unsigned int zT_596 = 0;
    int zT_599;
    zT_338B7C76_TypeRegistry* zT_603;
    zT_D155D06D_Type* zT_604;
    unsigned int zT_605;
    zT_D155D06D_Type zT_606;
    zT_33EF6BFB_TypeKind zT_607;
    int zT_612;
    zT_33EF6BFB_TypeKind zT_613;
    unsigned char* zT_621;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_622;
    unsigned int zT_623;
    zT_F85C5DED_DiagnosticCollector* zT_624;
    unsigned int zT_627;
    unsigned int zT_628;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_630;
    unsigned int zT_639;
    unsigned int zT_640;
    unsigned int zT_643 = 0;
    unsigned int zT_644;
    unsigned int zT_645;
    unsigned int zT_649;
    unsigned int zT_651;
    zT_ABC1EBBE_TypeResolveEnv zT_655;
    zT_6B0A7D14_AstStore* zT_656;
    zT_338B7C76_TypeRegistry* zT_657;
    zT_3D7259E2_SymbolRegistry* zT_658;
    zT_D3EB6303_StringInterner* zT_659;
    unsigned int zT_660;
    zT_F85C5DED_DiagnosticCollector* zT_661;
    zT_7334F4FE_Opt_225 zT_662;
    zT_F6B96876_Opt_395 zT_663 = {0};
    unsigned int zT_664;
    zT_ABC1EBBE_TypeResolveEnv* zT_666;
    unsigned int zT_667;
    unsigned int* zT_670;
    unsigned int zT_671;
    unsigned int zT_674 = 0;
    zT_38C12417_SemanticAnalyzer* zT_677;
    unsigned int zT_678;
    unsigned int* zT_679;
    unsigned int zT_680;
    unsigned int zT_682 = 0;
    zT_338B7C76_TypeRegistry* zT_683;
    unsigned int zT_684;
    unsigned int zT_688 = 0;
    unsigned int zT_689;
    unsigned int zT_690;
    unsigned int zT_694;
    unsigned int zT_696;
    zT_ABC1EBBE_TypeResolveEnv zT_700;
    zT_6B0A7D14_AstStore* zT_701;
    zT_338B7C76_TypeRegistry* zT_702;
    zT_3D7259E2_SymbolRegistry* zT_703;
    zT_D3EB6303_StringInterner* zT_704;
    unsigned int zT_705;
    zT_F85C5DED_DiagnosticCollector* zT_706;
    zT_7334F4FE_Opt_225 zT_707;
    zT_F6B96876_Opt_395 zT_708 = {0};
    unsigned int zT_709;
    zT_ABC1EBBE_TypeResolveEnv* zT_711;
    unsigned int zT_712;
    unsigned int* zT_715;
    unsigned int zT_716;
    unsigned int zT_719 = 0;
    zT_38C12417_SemanticAnalyzer* zT_723;
    unsigned int zT_724;
    unsigned int* zT_725;
    unsigned int zT_726;
    unsigned int zT_728 = 0;
    unsigned char zT_730;
    int zT_733;
    zT_338B7C76_TypeRegistry* zT_734;
    unsigned int zT_735;
    int zT_737 = 0;
    int zT_738;
    zT_338B7C76_TypeRegistry* zT_739;
    unsigned int zT_740;
    int zT_742 = 0;
    zT_338B7C76_TypeRegistry* zT_744;
    zT_D155D06D_Type* zT_745;
    unsigned int zT_746;
    zT_D155D06D_Type zT_747;
    zT_338B7C76_TypeRegistry* zT_749;
    zT_D155D06D_Type* zT_750;
    unsigned int zT_751;
    zT_D155D06D_Type zT_752;
    unsigned char zT_753;
    int zT_756;
    unsigned char zT_757;
    int zT_760;
    unsigned int zT_761;
    unsigned int zT_762;
    unsigned char zT_764;
    unsigned char* zT_768;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    unsigned int zT_770;
    zT_F85C5DED_DiagnosticCollector* zT_771;
    unsigned int zT_774;
    unsigned int zT_775;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_777;
    unsigned int zT_786;
    unsigned int zT_787;
    unsigned int zT_790 = 0;
    unsigned int zT_791;
    unsigned int zT_792;
    unsigned int zT_794;
    unsigned int zT_795;
    unsigned int zT_796;
    unsigned int zT_799;
    zT_38C12417_SemanticAnalyzer* zT_802;
    unsigned int zT_803;
    unsigned int* zT_804;
    unsigned int zT_805;
    unsigned int zT_807 = 0;
    unsigned int zT_808;
    unsigned int zT_809;
    unsigned int zT_810;
    unsigned int zT_813;
    zT_38C12417_SemanticAnalyzer* zT_816;
    unsigned int zT_817;
    unsigned int* zT_818;
    unsigned int zT_819;
    unsigned int zT_821 = 0;
    unsigned int zT_822;
    unsigned int zT_823;
    unsigned int zT_824;
    int zT_826;
    unsigned int zT_827;
    unsigned int zT_828;
    unsigned int zT_831;
    zT_38C12417_SemanticAnalyzer* zT_834;
    unsigned int zT_835;
    unsigned int* zT_836;
    unsigned int zT_837;
    unsigned int zT_839 = 0;
    unsigned int zT_840;
    unsigned int zT_841;
    unsigned int zT_842;
    int zT_844;
    unsigned int zT_845;
    unsigned int zT_846;
    unsigned int zT_849;
    zT_38C12417_SemanticAnalyzer* zT_852;
    unsigned int zT_853;
    unsigned int* zT_854;
    unsigned int zT_855;
    unsigned int zT_857 = 0;
    zT_38C12417_SemanticAnalyzer* zT_858;
    unsigned int zT_859;
    unsigned int* zT_860;
    unsigned int zT_861;
    unsigned int zT_863 = 0;
    unsigned int zT_865;
    zT_38C12417_SemanticAnalyzer* zT_868;
    unsigned int zT_869;
    unsigned int* zT_870;
    unsigned int zT_871;
    unsigned int zT_873 = 0;
    unsigned int zT_874;
    unsigned int zT_875;
    unsigned int zT_876;
    unsigned int zT_878;
    unsigned int zT_879;
    unsigned int zT_880;
    unsigned int zT_882;
    unsigned int zT_883;
    unsigned int zT_884;
    int zT_886;
    unsigned int zT_887;
    unsigned int zT_888;
    unsigned int zT_891;
    zT_38C12417_SemanticAnalyzer* zT_894;
    unsigned int zT_895;
    unsigned int* zT_896;
    unsigned int zT_897;
    unsigned int zT_899 = 0;
    zT_38C12417_SemanticAnalyzer* zT_900;
    unsigned int zT_901;
    unsigned int* zT_902;
    unsigned int zT_903;
    unsigned int zT_905 = 0;
    unsigned int zT_907;
    zT_38C12417_SemanticAnalyzer* zT_910;
    unsigned int zT_911;
    unsigned int* zT_912;
    unsigned int zT_913;
    unsigned int zT_915 = 0;
    unsigned int zT_916;
    unsigned int zT_917;
    unsigned int zT_918;
    unsigned int zT_921;
    zT_38C12417_SemanticAnalyzer* zT_924;
    unsigned int zT_925;
    unsigned int* zT_926;
    unsigned int zT_927;
    unsigned int zT_929 = 0;
    int zT_931;
    zT_6B0A7D14_AstStore* zT_932;
    zT_3D7259E2_SymbolRegistry* zT_933;
    unsigned int zT_934;
    unsigned int zT_935;
    unsigned int* zT_939;
    unsigned int zT_940;
    zT_BBEE1AC1_Opt_11 zT_942 = {0};
    unsigned char zT_943;
    unsigned int zT_948;
    unsigned int zT_952;
    zT_A4CE86B7_U64ToU32Map* zT_953;
    unsigned int zT_954;
    unsigned int zT_955;
    int zT_957 = 0;
    int zT_958;
    unsigned char* zT_961;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_962;
    unsigned int zT_963;
    zT_F85C5DED_DiagnosticCollector* zT_964;
    unsigned int zT_967;
    unsigned int zT_968;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_970;
    unsigned int zT_979;
    unsigned int zT_980;
    unsigned int zT_983 = 0;
    unsigned int zT_984;
    unsigned int zT_985;
    unsigned int zT_986;
    unsigned int zT_989;
    zT_38C12417_SemanticAnalyzer* zT_992;
    unsigned int zT_993;
    unsigned int* zT_994;
    unsigned int zT_995;
    unsigned int zT_997 = 0;
    zT_38C12417_SemanticAnalyzer* zT_998;
    unsigned int zT_999;
    unsigned int* zT_1000;
    unsigned int zT_1001;
    unsigned int zT_1003 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1004;
    unsigned int zT_1005;
    unsigned int* zT_1006;
    unsigned int zT_1007;
    unsigned int zT_1009 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1010;
    unsigned int zT_1011;
    unsigned int* zT_1012;
    unsigned int zT_1013;
    unsigned int zT_1015 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1016;
    unsigned int zT_1017;
    zT_338B7C76_TypeRegistry* zT_1018;
    unsigned int zT_1024 = 0;
    unsigned int zT_1025;
    unsigned int zT_1026;
    unsigned int zT_1029;
    zT_38C12417_SemanticAnalyzer* zT_1032;
    unsigned int zT_1033;
    unsigned int* zT_1034;
    unsigned int zT_1035;
    unsigned int zT_1037 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1038;
    unsigned int zT_1039;
    unsigned int* zT_1040;
    unsigned int zT_1041;
    unsigned int zT_1043 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1044;
    unsigned int zT_1045;
    zT_338B7C76_TypeRegistry* zT_1046;
    unsigned int zT_1047;
    zT_338B7C76_TypeRegistry* zT_1049;
    unsigned int zT_1055 = 0;
    unsigned int zT_1056 = 0;
    unsigned int zT_1057;
    unsigned int zT_1058;
    unsigned int zT_1061;
    zT_38C12417_SemanticAnalyzer* zT_1064;
    unsigned int zT_1065;
    unsigned int* zT_1066;
    unsigned int zT_1067;
    unsigned int zT_1069 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1070;
    unsigned int zT_1071;
    zT_38C12417_SemanticAnalyzer* zT_1072;
    unsigned int zT_1073;
    zT_338B7C76_TypeRegistry* zT_1074;
    unsigned int zT_1080 = 0;
    unsigned int zT_1081;
    unsigned int zT_1082;
    int zT_1084;
    unsigned int zT_1086;
    unsigned char* zT_1090;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1091;
    unsigned int zT_1092;
    zT_F85C5DED_DiagnosticCollector* zT_1093;
    unsigned int zT_1096;
    unsigned int zT_1097;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1099;
    unsigned int zT_1108;
    unsigned int zT_1109;
    unsigned int zT_1112 = 0;
    unsigned int zT_1114;
    zT_38C12417_SemanticAnalyzer* zT_1117;
    unsigned int zT_1118;
    unsigned int* zT_1119;
    unsigned int zT_1120;
    unsigned int zT_1122 = 0;
    unsigned int zT_1123;
    zT_38C12417_SemanticAnalyzer* zT_1124;
    unsigned int zT_1125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1126;
    int zT_1128 = 0;
    unsigned int zT_1130;
    zT_38C12417_SemanticAnalyzer* zT_1133;
    unsigned int zT_1134;
    unsigned int* zT_1135;
    int zT_1136;
    unsigned int zT_1138 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_1140;
    zT_6B0A7D14_AstStore* zT_1141;
    zT_338B7C76_TypeRegistry* zT_1142;
    zT_3D7259E2_SymbolRegistry* zT_1143;
    zT_D3EB6303_StringInterner* zT_1144;
    unsigned int zT_1145;
    zT_F85C5DED_DiagnosticCollector* zT_1146;
    zT_7334F4FE_Opt_225 zT_1147;
    zT_F6B96876_Opt_395 zT_1148 = {0};
    unsigned int zT_1149;
    zT_ABC1EBBE_TypeResolveEnv* zT_1150;
    unsigned int zT_1151;
    unsigned int* zT_1154;
    int zT_1155;
    unsigned int zT_1158 = 0;
    unsigned int zT_1159;
    unsigned int zT_1161;
    zT_38C12417_SemanticAnalyzer* zT_1164;
    unsigned int zT_1165;
    int zT_1167 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1169;
    unsigned int zT_1170;
    unsigned int* zT_1171;
    unsigned int zT_1172;
    unsigned int zT_1174 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_1176;
    zT_6B0A7D14_AstStore* zT_1177;
    zT_338B7C76_TypeRegistry* zT_1178;
    zT_3D7259E2_SymbolRegistry* zT_1179;
    zT_D3EB6303_StringInterner* zT_1180;
    unsigned int zT_1181;
    zT_F85C5DED_DiagnosticCollector* zT_1182;
    zT_7334F4FE_Opt_225 zT_1183;
    zT_F6B96876_Opt_395 zT_1184 = {0};
    unsigned int zT_1185;
    zT_ABC1EBBE_TypeResolveEnv* zT_1186;
    unsigned int zT_1187;
    unsigned int* zT_1190;
    unsigned int zT_1191;
    unsigned int zT_1194 = 0;
    unsigned int zT_1195;
    unsigned int zT_1196;
    int zT_1198;
    int zT_1201;
    zT_38C12417_SemanticAnalyzer* zT_1204;
    unsigned int zT_1205;
    unsigned int zT_1206;
    int zT_1207 = 0;
    unsigned char* zT_1209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1210;
    unsigned int zT_1211;
    zT_F85C5DED_DiagnosticCollector* zT_1212;
    unsigned int zT_1215;
    unsigned int zT_1216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1218;
    unsigned int zT_1224;
    unsigned int zT_1225;
    unsigned int zT_1228 = 0;
    unsigned int zT_1229;
    unsigned int zT_1230;
    int zT_1232;
    int zT_1235;
    zT_38C12417_SemanticAnalyzer* zT_1238;
    unsigned int zT_1239;
    unsigned int zT_1240;
    int zT_1241 = 0;
    unsigned char* zT_1244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1245;
    unsigned int zT_1246;
    zT_F85C5DED_DiagnosticCollector* zT_1247;
    unsigned int zT_1250;
    unsigned int zT_1251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1253;
    unsigned int zT_1259;
    unsigned int zT_1260;
    unsigned int zT_1263 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1264;
    unsigned int zT_1265;
    unsigned int* zT_1266;
    int zT_1267;
    unsigned int zT_1269 = 0;
    unsigned int zT_1270;
    unsigned int zT_1271;
    int zT_1273;
    unsigned int zT_1275;
    zT_38C12417_SemanticAnalyzer* zT_1279;
    unsigned int zT_1280;
    unsigned int* zT_1281;
    unsigned int zT_1282;
    unsigned int zT_1284 = 0;
    zT_338B7C76_TypeRegistry* zT_1289;
    zT_D155D06D_Type* zT_1290;
    unsigned int zT_1291;
    zT_D155D06D_Type zT_1292;
    zT_33EF6BFB_TypeKind zT_1293;
    zT_338B7C76_TypeRegistry* zT_1299;
    unsigned int zT_1300;
    unsigned int zT_1302 = 0;
    int zT_1305;
    zT_338B7C76_TypeRegistry* zT_1307;
    unsigned int zT_1308;
    unsigned int zT_1311;
    zT_38C12417_SemanticAnalyzer* zT_1314;
    unsigned int zT_1315;
    unsigned int* zT_1316;
    int zT_1317;
    unsigned int zT_1319 = 0;
    unsigned int zT_1320;
    zT_8143F551_AstKind zT_1321;
    zT_38C12417_SemanticAnalyzer* zT_1326;
    unsigned int zT_1327;
    unsigned int zT_1329 = 0;
    unsigned int zT_1330;
    zT_8143F551_AstKind zT_1331;
    int zT_1336;
    zT_8143F551_AstKind zT_1337;
    zT_38C12417_SemanticAnalyzer* zT_1342;
    unsigned int zT_1343;
    unsigned int zT_1344 = 0;
    zT_8143F551_AstKind zT_1345;
    zT_38C12417_SemanticAnalyzer* zT_1350;
    unsigned int zT_1351;
    unsigned int zT_1352 = 0;
    zT_8143F551_AstKind zT_1353;
    zT_38C12417_SemanticAnalyzer* zT_1358;
    unsigned int zT_1359;
    unsigned int zT_1360 = 0;
    zT_8143F551_AstKind zT_1361;
    int zT_1367;
    unsigned int zT_1368;
    zT_38C12417_SemanticAnalyzer* zT_1369;
    unsigned int zT_1370;
    unsigned int zT_1372 = 0;
    zT_338B7C76_TypeRegistry* zT_1376;
    zT_D155D06D_Type* zT_1377;
    unsigned int zT_1378;
    zT_D155D06D_Type zT_1379;
    zT_33EF6BFB_TypeKind zT_1380;
    zT_338B7C76_TypeRegistry* zT_1385;
    zT_42C2D6BF_EUPayload* zT_1386;
    unsigned int zT_1387;
    unsigned int zT_1388;
    zT_42C2D6BF_EUPayload zT_1389;
    unsigned int zT_1390;
    zT_338B7C76_TypeRegistry* zT_1391;
    zT_42C2D6BF_EUPayload* zT_1392;
    unsigned int zT_1393;
    unsigned int zT_1394;
    zT_42C2D6BF_EUPayload zT_1395;
    unsigned int zT_1396;
    zT_66E7D2EF_CoercionTable* zT_1397;
    unsigned int zT_1398;
    unsigned int zT_1400;
    unsigned int zT_1406;
    int zT_1407;
    zT_6B0A7D14_AstStore* zT_1410;
    unsigned int zT_1411;
    unsigned int zT_1415;
    unsigned int zT_1416;
    zT_38C12417_SemanticAnalyzer* zT_1418;
    zT_6B0A7D14_AstStore* zT_1419;
    unsigned int zT_1420;
    unsigned int zT_1423 = 0;
    unsigned int* zT_1424;
    unsigned int zT_1425;
    int zT_1426;
    unsigned int zT_1428;
    unsigned int* zT_1430;
    unsigned int zT_1431;
    unsigned int zT_1432;
    unsigned int zT_1435;
    int zT_1438;
    zT_6B0A7D14_AstStore* zT_1441;
    unsigned int zT_1442;
    zT_22A7C88B_AstNode zT_1445 = {0};
    zT_8143F551_AstKind zT_1446;
    zT_38C12417_SemanticAnalyzer* zT_1451;
    unsigned int zT_1452;
    zT_38C12417_SemanticAnalyzer* zT_1453;
    unsigned int zT_1454;
    unsigned int zT_1456 = 0;
    zT_38C12417_SemanticAnalyzer* zT_1457;
    zT_38C12417_SemanticAnalyzer* zT_1458;
    unsigned int zT_1459;
    zT_8143F551_AstKind zT_1461;
    zT_38C12417_SemanticAnalyzer* zT_1466;
    unsigned int zT_1467;
    unsigned int zT_1468 = 0;
    zT_8143F551_AstKind zT_1469;
    int zT_1474;
    zT_8143F551_AstKind zT_1475;
    unsigned int zT_1480;
    zT_8143F551_AstKind zT_1481;
    int zT_1486;
    zT_8143F551_AstKind zT_1487;
    int zT_1492;
    zT_8143F551_AstKind zT_1493;
    int zT_1498;
    zT_8143F551_AstKind zT_1499;
    zT_38C12417_SemanticAnalyzer* zT_1504;
    unsigned int zT_1505;
    unsigned int zT_1506;
    zT_8143F551_AstKind zT_1507;
    zT_38C12417_SemanticAnalyzer* zT_1512;
    unsigned int zT_1513;
    unsigned int zT_1514 = 0;
    zT_8143F551_AstKind zT_1515;
    zT_38C12417_SemanticAnalyzer* zT_1520;
    unsigned int zT_1521;
    unsigned int zT_1522;
    zT_38C12417_SemanticAnalyzer* zT_1525;
    unsigned int zT_1526;
    unsigned int zT_1528;
    zT_38C12417_SemanticAnalyzer* zT_1531;
    unsigned int zT_1532;
    unsigned int zT_1534;
    zT_8143F551_AstKind zT_1535;
    zT_38C12417_SemanticAnalyzer* zT_1540;
    unsigned int zT_1541;
    unsigned int zT_1542;
    int zT_1543;
    zT_38C12417_SemanticAnalyzer* zT_1545;
    unsigned int zT_1546;
    unsigned int zT_1548;
    zT_8143F551_AstKind zT_1549;
    zT_38C12417_SemanticAnalyzer* zT_1554;
    unsigned int zT_1555;
    unsigned int zT_1556;
    int zT_1557;
    zT_38C12417_SemanticAnalyzer* zT_1559;
    unsigned int zT_1560;
    unsigned int zT_1562;
    zT_8143F551_AstKind zT_1563;
    zT_38C12417_SemanticAnalyzer* zT_1568;
    unsigned int zT_1569;
    unsigned int zT_1570 = 0;
    zT_8143F551_AstKind zT_1571;
    zT_38C12417_SemanticAnalyzer* zT_1576;
    unsigned int zT_1577;
    unsigned int zT_1578 = 0;
    zT_8143F551_AstKind zT_1579;
    zT_38C12417_SemanticAnalyzer* zT_1584;
    unsigned int zT_1585;
    unsigned int zT_1586 = 0;
    zT_8143F551_AstKind zT_1587;
    unsigned char* zT_1593;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1594;
    unsigned int zT_1595;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1596;
    unsigned int zT_1597;
    zT_38C12417_SemanticAnalyzer* zT_1598;
    unsigned int zT_1599;
    unsigned int zT_1600 = 0;
    zT_8143F551_AstKind zT_1601;
    int zT_1606;
    zT_8143F551_AstKind zT_1607;
    int zT_1612;
    zT_8143F551_AstKind zT_1613;
    int zT_1618;
    zT_8143F551_AstKind zT_1619;
    int zT_1624;
    zT_8143F551_AstKind zT_1625;
    int zT_1630;
    zT_8143F551_AstKind zT_1631;
    int zT_1636;
    zT_8143F551_AstKind zT_1637;
    int zT_1642;
    zT_8143F551_AstKind zT_1643;
    int zT_1648;
    zT_8143F551_AstKind zT_1649;
    int zT_1654;
    zT_8143F551_AstKind zT_1655;
    int zT_1660;
    zT_8143F551_AstKind zT_1661;
    zT_8143F551_AstKind zT_1666;
    zT_38C12417_SemanticAnalyzer* zT_1671;
    unsigned int zT_1672;
    unsigned int zT_1673;
    unsigned int zT_1675;
    zT_8143F551_AstKind zT_1676;
    zT_38C12417_SemanticAnalyzer* zT_1681;
    unsigned int zT_1682;
    unsigned int zT_1684 = 0;
    zT_8143F551_AstKind zT_1685;
    zT_38C12417_SemanticAnalyzer* zT_1690;
    unsigned int zT_1691;
    unsigned int zT_1692;
    zT_8143F551_AstKind zT_1693;
    zT_38C12417_SemanticAnalyzer* zT_1698;
    unsigned int zT_1699;
    unsigned int zT_1701 = 0;
    zT_8143F551_AstKind zT_1702;
    unsigned int zT_1707;
    zT_8143F551_AstKind zT_1708;
    unsigned char* zT_1714;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1715;
    unsigned int zT_1716;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1717;
    unsigned int zT_1718;
    zT_6B0A7D14_AstStore* zT_1720;
    unsigned int zT_1721;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1723 = {0};
    unsigned char* zT_1725;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1726;
    unsigned int zT_1727;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1728;
    unsigned int zT_1731;
    unsigned int zT_1734;
    int zT_1738;
    unsigned int zT_1739;
    unsigned int zT_1741;
    unsigned char* zT_1746;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1747;
    unsigned int zT_1748;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1749;
    unsigned char* zT_1753;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1754;
    unsigned int zT_1755;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1756;
    unsigned int zT_1757;
    unsigned int* zT_1758;
    zT_38C12417_SemanticAnalyzer* zT_1760;
    unsigned int zT_1761;
    unsigned int* zT_1762;
    int zT_1764;
    unsigned int zT_1765;
    unsigned int* zT_1767;
    unsigned int zT_1769;
    unsigned int zT_1771;
    unsigned int zT_1772;
    zT_38C12417_SemanticAnalyzer* zT_1773;
    unsigned int zT_1774;
    unsigned int zT_1775 = 0;
    unsigned int zT_1776;
    zT_8143F551_AstKind zT_1777;
    int zT_1782;
    zT_8143F551_AstKind zT_1783;
    int zT_1788;
    zT_8143F551_AstKind zT_1789;
    int zT_1794;
    zT_8143F551_AstKind zT_1795;
    int zT_1800;
    zT_8143F551_AstKind zT_1801;
    int zT_1806;
    zT_8143F551_AstKind zT_1807;
    int zT_1812;
    zT_8143F551_AstKind zT_1813;
    int zT_1818;
    zT_8143F551_AstKind zT_1819;
    int zT_1824;
    zT_8143F551_AstKind zT_1825;
    int zT_1830;
    zT_8143F551_AstKind zT_1831;
    int zT_1836;
    zT_8143F551_AstKind zT_1837;
    zT_38C12417_SemanticAnalyzer* zT_1842;
    unsigned int zT_1843;
    zT_8143F551_AstKind zT_1844;
    unsigned int zT_1846 = 0;
    zT_8143F551_AstKind zT_1847;
    int zT_1852;
    zT_8143F551_AstKind zT_1853;
    int zT_1858;
    zT_8143F551_AstKind zT_1859;
    int zT_1864;
    zT_8143F551_AstKind zT_1865;
    int zT_1870;
    zT_8143F551_AstKind zT_1871;
    int zT_1876;
    zT_8143F551_AstKind zT_1877;
    zT_38C12417_SemanticAnalyzer* zT_1882;
    unsigned int zT_1883;
    unsigned int zT_1884 = 0;
    zT_8143F551_AstKind zT_1885;
    int zT_1890;
    zT_8143F551_AstKind zT_1891;
    zT_38C12417_SemanticAnalyzer* zT_1896;
    unsigned int zT_1897;
    unsigned int zT_1898 = 0;
    zT_8143F551_AstKind zT_1899;
    int zT_1904;
    zT_8143F551_AstKind zT_1905;
    int zT_1910;
    zT_8143F551_AstKind zT_1911;
    int zT_1916;
    zT_8143F551_AstKind zT_1917;
    int zT_1922;
    zT_8143F551_AstKind zT_1923;
    int zT_1928;
    zT_8143F551_AstKind zT_1929;
    zT_38C12417_SemanticAnalyzer* zT_1934;
    unsigned int zT_1935;
    zT_8143F551_AstKind zT_1936;
    unsigned int zT_1938 = 0;
    zT_8143F551_AstKind zT_1939;
    int zT_1944;
    zT_8143F551_AstKind zT_1945;
    int zT_1950;
    zT_8143F551_AstKind zT_1951;
    int zT_1956;
    zT_8143F551_AstKind zT_1957;
    int zT_1962;
    zT_8143F551_AstKind zT_1963;
    int zT_1968;
    zT_8143F551_AstKind zT_1969;
    int zT_1974;
    zT_8143F551_AstKind zT_1975;
    int zT_1980;
    zT_8143F551_AstKind zT_1981;
    int zT_1986;
    zT_8143F551_AstKind zT_1987;
    int zT_1992;
    zT_8143F551_AstKind zT_1993;
    int zT_1998;
    zT_8143F551_AstKind zT_1999;
    int zT_2004;
    zT_8143F551_AstKind zT_2005;
    int zT_2010;
    zT_8143F551_AstKind zT_2011;
    int zT_2016;
    zT_8143F551_AstKind zT_2017;
    int zT_2022;
    zT_8143F551_AstKind zT_2023;
    int zT_2028;
    zT_8143F551_AstKind zT_2029;
    int zT_2034;
    zT_8143F551_AstKind zT_2035;
    int zT_2040;
    zT_8143F551_AstKind zT_2041;
    zT_38C12417_SemanticAnalyzer* zT_2046;
    unsigned int zT_2047;
    unsigned int zT_2048 = 0;
    zT_8143F551_AstKind zT_2049;
    int zT_2054;
    zT_8143F551_AstKind zT_2055;
    zT_8EED1867_ResolvedTypeTable* zT_2060;
    unsigned int zT_2061;
    unsigned char* zT_2067;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2068;
    unsigned int zT_2069;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2070;
    unsigned int zT_2071;
    zT_8143F551_AstKind zT_2073;
    unsigned int zT_2074;
    unsigned char* zT_2076;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2077;
    unsigned int zT_2078;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2079;
    unsigned int zT_2080;
    unsigned char* zT_2082;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2083;
    unsigned int zT_2084;
    zT_F85C5DED_DiagnosticCollector* zT_2085;
    unsigned int zT_2088;
    unsigned int zT_2089;
    unsigned int zT_2090;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2091;
    unsigned int zT_2096 = 0;
    unsigned char* zT_2099;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2100;
    unsigned int zT_2101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2102;
    unsigned int zT_2103;
    zT_8143F551_AstKind zT_2105;
    unsigned int zT_2106;
    unsigned char* zT_2108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2109;
    unsigned int zT_2110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2111;
    unsigned int zT_2112;
    unsigned char* zT_2114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2115;
    unsigned int zT_2116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2117;
    unsigned int zT_2118;
    unsigned char* zT_2120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2121;
    unsigned int zT_2122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2123;
    unsigned int zT_2124;
    zT_8143F551_AstKind zT_2126;
    unsigned int zT_2127;
    unsigned char* zT_2129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2130;
    unsigned int zT_2131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2132;
    unsigned int zT_2133;
    unsigned char* zT_2135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2136;
    unsigned int zT_2137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2138;
    unsigned int zT_2139;
    zT_8EED1867_ResolvedTypeTable* zT_2140;
    unsigned int zT_2141;
    unsigned int zT_2142;
    unsigned char* zT_2145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2146;
    unsigned int zT_2147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2148;
    unsigned int zT_2149;
    unsigned char* zT_2151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2152;
    unsigned int zT_2153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2154;
    unsigned int zT_2155;
    unsigned int result;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rx_sw_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rxs_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_m;
    unsigned int stx_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u stx_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_nm;
    unsigned int a4_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u a4_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u stb_rm;
    unsigned int sl_len;
    unsigned int sl_payload;
    unsigned int sl_str_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl_bytes;
    unsigned int sl_arr;
    unsigned int top;
    unsigned int es;
    zT_D155D06D_Type tty;
    unsigned int eff_top;
    unsigned int opt_pay;
    unsigned int name_id;
    unsigned int ord;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u eln_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u fad;
    unsigned int base;
    zT_D155D06D_Type bt;
    zT_112BF819_PtrPayload pp;
    zT_22A7C88B_AstNode base_node;
    unsigned int fa_base_t;
    unsigned int st;
    zT_D155D06D_Type st_ty;
    unsigned int sd;
    unsigned int aps;
    unsigned int ape;
    zT_8F083A69_Slice_zT_0B42B2F8_u aof_msg;
    unsigned int apu_s;
    unsigned int apu_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u aou_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ub_msg;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    zT_8F083A69_Slice_zT_0B42B2F8_u cva;
    zT_ABC1EBBE_TypeResolveEnv so_env;
    unsigned int pfi_res;
    unsigned int pfi_top;
    zT_D155D06D_Type pfi_ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfi_msg;
    unsigned int fpp_res;
    zT_ABC1EBBE_TypeResolveEnv fpp_env;
    unsigned int fpp_outer;
    unsigned int bc_res;
    zT_ABC1EBBE_TypeResolveEnv bc_env;
    unsigned int bc_dst;
    unsigned int bc_src;
    unsigned char bc_ok;
    zT_D155D06D_Type bc_dty;
    zT_D155D06D_Type bc_sty;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_msg;
    int afs_susp;
    zT_79FAE712_u64 afs_k;
    unsigned int afs_mid;
    unsigned int afs_nid;
    zT_8F083A69_Slice_zT_0B42B2F8_u e3046;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc3049;
    zT_ABC1EBBE_TypeResolveEnv cva_env;
    unsigned int tv_src;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    zT_8F083A69_Slice_zT_0B42B2F8_u pcq_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcc_msg;
    unsigned int e2i_arg;
    unsigned int e2i_res;
    zT_D155D06D_Type e2i_ty;
    unsigned int e2i_bt;
    unsigned int catch_es;
    zT_D155D06D_Type clt;
    zT_22A7C88B_AstNode child1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ai_dbg;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_m;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u eblk_cm2;
    unsigned int last_child;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_m;
    unsigned int st_kv;
    zT_8F083A69_Slice_zT_0B42B2F8_u st_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u unr_msg;
    zT_3 = 0;
    result = zT_3;
    zT_4 = 0;
    result = zT_4;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return result;
    z_bb_2:
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    node = zT_11;
    zT_12 = 1;
    result = zT_12;
    zT_13 = node.kind;
    if ((int)(zT_13 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = "RXS";
    zT_21 = 3;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    rx_sw_m = zT_20;
    zT_22 = rx_sw_m;
    zF_48AC7B3A_markerWrite(zT_22);
    zT_24 = "RXS:n";
    zT_26 = 5;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    rxs_nm = zT_25;
    zT_27 = rxs_nm;
    zT_28 = node_idx;
    zF_C914CB83_markerWriteInt(zT_27, zT_28);
    goto z_bb_4;
    z_bb_4:
    zT_29 = node.kind;
    if ((int)(zT_29 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_34 = 19;
    result = zT_34;
    goto z_bb_6;
    z_bb_6:
    zT_2099 = "STX:n";
    zT_2101 = 5;
    zT_2100.ptr = zT_2099;
    zT_2100.len = zT_2101;
    stx_m = zT_2100;
    zT_2102 = stx_m;
    zT_2103 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2102, zT_2103);
    zT_2105 = node.kind;
    zT_2106 = (unsigned int)zT_2105;
    stx_kv = zT_2106;
    zT_2108 = "STX:k";
    zT_2110 = 5;
    zT_2109.ptr = zT_2108;
    zT_2109.len = zT_2110;
    stx_km = zT_2109;
    zT_2111 = stx_km;
    zT_2112 = stx_kv;
    zF_C914CB83_markerWriteInt(zT_2111, zT_2112);
    zT_2114 = "STX:r";
    zT_2116 = 5;
    zT_2115.ptr = zT_2114;
    zT_2115.len = zT_2116;
    stx_rm = zT_2115;
    zT_2117 = stx_rm;
    zT_2118 = result;
    zF_C914CB83_markerWriteInt(zT_2117, zT_2118);
    zT_2120 = "A4:N";
    zT_2122 = 4;
    zT_2121.ptr = zT_2120;
    zT_2121.len = zT_2122;
    a4_nm = zT_2121;
    zT_2123 = a4_nm;
    zT_2124 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2123, zT_2124);
    zT_2126 = node.kind;
    zT_2127 = (unsigned int)zT_2126;
    a4_kv = zT_2127;
    zT_2129 = "A4:K";
    zT_2131 = 4;
    zT_2130.ptr = zT_2129;
    zT_2130.len = zT_2131;
    a4_km = zT_2130;
    zT_2132 = a4_km;
    zT_2133 = a4_kv;
    zF_C914CB83_markerWriteInt(zT_2132, zT_2133);
    zT_2135 = "A4:R";
    zT_2137 = 4;
    zT_2136.ptr = zT_2135;
    zT_2136.len = zT_2137;
    a4_rm = zT_2136;
    zT_2138 = a4_rm;
    zT_2139 = result;
    zF_C914CB83_markerWriteInt(zT_2138, zT_2139);
    zT_2140 = self->type_table;
    zT_2141 = node_idx;
    zT_2142 = result;
    zF_19B4A07D_resolvedTypeTableSe(zT_2140, zT_2141, zT_2142);
    zT_2145 = "STB:N";
    zT_2147 = 5;
    zT_2146.ptr = zT_2145;
    zT_2146.len = zT_2147;
    stb_nm = zT_2146;
    zT_2148 = stb_nm;
    zT_2149 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2148, zT_2149);
    zT_2151 = "STB:R";
    zT_2153 = 5;
    zT_2152.ptr = zT_2151;
    zT_2152.len = zT_2153;
    stb_rm = zT_2152;
    zT_2154 = stb_rm;
    zT_2155 = result;
    zF_C914CB83_markerWriteInt(zT_2154, zT_2155);
    return result;
    z_bb_7:
    zT_35 = node.kind;
    if ((int)(zT_35 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_40 = 16;
    result = zT_40;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_41 = node.kind;
    if ((int)(zT_41 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_46 = 8;
    result = zT_46;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_47 = node.kind;
    if ((int)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_52 = 2;
    result = zT_52;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_53 = node.kind;
    if ((int)(zT_53 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_null_literal))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_58 = 17;
    result = zT_58;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_59 = node.kind;
    if ((int)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_64 = 18;
    result = zT_64;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_65 = node.kind;
    if ((int)(zT_65 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_unreachable_expr))) goto z_bb_23; else goto z_bb_25;
    z_bb_23:
    zT_70 = 3;
    result = zT_70;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_71 = node.kind;
    if ((int)(zT_71 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    zT_77 = 0;
    sl_len = zT_77;
    zT_79 = self->store;
    zT_80 = node_idx;
    zT_82 = zF_8BA26B9E_astStoreNodePayload(zT_79, zT_80);
    sl_payload = zT_82;
    zT_84 = self->store;
    zT_85 = zT_84->string_values;
    zT_86 = zT_85.len;
    if ((int)((unsigned int)((unsigned int)sl_payload) < zT_86)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_116 = node.kind;
    if ((int)(zT_116 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal))) goto z_bb_31; else goto z_bb_33;
    z_bb_29:
    zT_89 = self->store;
    zT_90 = zT_89->string_values;
    zT_91 = zT_90.items;
    zT_92 = (unsigned int)sl_payload;
    zT_93 = zT_91[zT_92];
    sl_str_id = zT_93;
    zT_97 = self->registry;
    zT_95 = zT_97->interner;
    zT_96 = sl_str_id;
    zT_99 = zF_9134020D_stringInternerGet(zT_95, zT_96);
    sl_bytes = zT_99;
    zT_101 = sl_bytes.len;
    zT_102 = (unsigned int)zT_101;
    sl_len = zT_102;
    goto z_bb_30;
    z_bb_30:
    zT_104 = self->registry;
    zT_106 = sl_len;
    zT_109 = zF_BA693C74_typeRegistryGetOrCr(zT_104, (unsigned int)(8), zT_106);
    sl_arr = zT_109;
    zT_110 = self->registry;
    zT_111 = sl_arr;
    zT_115 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_110, zT_111, (int)(1));
    result = zT_115;
    goto z_bb_27;
    z_bb_31:
    zT_121 = self;
    zT_122 = node_idx;
    zT_123 = zF_8C008E53_semanticAnalyzerRes(zT_121, zT_122);
    result = zT_123;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_27;
    z_bb_33:
    zT_124 = node.kind;
    if ((int)(zT_124 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_129 = self->expected_type_stack_len;
    zT_130 = 0;
    if ((int)(zT_129 > (unsigned int)zT_130)) goto z_bb_37; else goto z_bb_39;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_247 = node.kind;
    if ((int)(zT_247 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_59; else goto z_bb_61;
    z_bb_37:
    zT_133 = self->expected_type_stack_items;
    zT_134 = self->expected_type_stack_len;
    zT_135 = 1;
    zT_136 = zT_134 - zT_135;
    zT_137 = zT_133[zT_136];
    top = zT_137;
    zT_138 = 0;
    if ((int)(top != (unsigned int)zT_138)) goto z_bb_40; else goto z_bb_42;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_246 = 1;
    result = zT_246;
    goto z_bb_38;
    z_bb_40:
    zT_141 = 0;
    zT_142 = (unsigned int)zT_141;
    es = zT_142;
    zT_144 = self->registry;
    zT_145 = zT_144->types_items;
    zT_146 = (unsigned int)top;
    zT_147 = zT_145[zT_146];
    tty = zT_147;
    eff_top = top;
    zT_149 = tty.kind;
    if ((int)(zT_149 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_245 = 1;
    result = zT_245;
    goto z_bb_41;
    z_bb_43:
    zT_155 = self->registry;
    zT_156 = zT_155->opt_items;
    zT_157 = tty.payload_idx;
    zT_158 = (unsigned int)zT_157;
    zT_159 = zT_156[zT_158];
    zT_160 = zT_159.payload;
    opt_pay = zT_160;
    zT_161 = self->registry;
    zT_162 = zT_161->types_items;
    zT_163 = (unsigned int)opt_pay;
    zT_164 = zT_162[zT_163];
    tty = zT_164;
    eff_top = opt_pay;
    goto z_bb_44;
    z_bb_44:
    zT_165 = tty.kind;
    if ((int)(zT_165 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_45; else goto z_bb_47;
    z_bb_45:
    es = eff_top;
    goto z_bb_46;
    z_bb_46:
    zT_181 = 0;
    if ((int)(es != (unsigned int)zT_181)) goto z_bb_50; else goto z_bb_52;
    z_bb_47:
    zT_170 = tty.kind;
    if ((int)(zT_170 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_175 = self->registry;
    zT_176 = zT_175->eu_items;
    zT_177 = tty.payload_idx;
    zT_178 = (unsigned int)zT_177;
    zT_179 = zT_176[zT_178];
    zT_180 = zT_179.error_set;
    es = zT_180;
    goto z_bb_49;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_184 = self->store;
    zT_185 = node_idx;
    zT_187 = zF_8BA26B9E_astStoreNodePayload(zT_184, zT_185);
    name_id = zT_187;
    zT_189 = self->registry;
    zT_190 = es;
    zT_191 = name_id;
    zT_193 = zF_D2ECD176_typeRegistryErrorSe(zT_189, zT_190, zT_191);
    ord = zT_193;
    if ((int)(ord != (unsigned int)(4294967295u))) goto z_bb_53; else goto z_bb_55;
    z_bb_51:
    goto z_bb_41;
    z_bb_52:
    zT_235 = tty.kind;
    if ((int)(zT_235 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_56; else goto z_bb_58;
    z_bb_53:
    zT_197 = self->error_code_registry;
    zT_198 = name_id;
    zT_200 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_197, zT_198);
    reg_code = zT_200;
    zT_201 = self->enum_value_table;
    zT_202 = node_idx;
    zT_203 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_201, zT_202, zT_203);
    zT_205 = self->type_table;
    zT_206 = node_idx;
    zT_207 = es;
    zF_19B4A07D_resolvedTypeTableSe(zT_205, zT_206, zT_207);
    result = es;
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_210 = node.span_start;
    sp = zT_210;
    zT_212 = node.span_len;
    zT_214 = sp + (unsigned int)((unsigned int)zT_212);
    ep = zT_214;
    zT_216 = "error literal not found in error set";
    zT_218 = 36;
    zT_217.ptr = zT_216;
    zT_217.len = zT_218;
    eln_msg = zT_217;
    zT_219 = self->diag;
    zT_222 = self->source_file_id;
    zT_223 = sp;
    zT_224 = ep;
    zT_225 = eln_msg;
    zT_233 = zF_C82559AC_diagnosticCollector(zT_219, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3011_ERROR_LITERAL_NOT_IN_SET)), zT_222, zT_223, zT_224, zT_225);
    (void)zT_233;
    zT_234 = 1;
    result = zT_234;
    goto z_bb_54;
    z_bb_56:
    zT_240 = self->type_table;
    zT_241 = node_idx;
    zT_242 = eff_top;
    zF_19B4A07D_resolvedTypeTableSe(zT_240, zT_241, zT_242);
    result = eff_top;
    goto z_bb_57;
    z_bb_57:
    goto z_bb_51;
    z_bb_58:
    zT_244 = 1;
    result = zT_244;
    goto z_bb_57;
    z_bb_59:
    zT_252 = self;
    zT_253 = self->module_id;
    zT_257 = self->store;
    zT_258 = node_idx;
    zT_260 = zF_53458827_astStoreIdentifier(zT_257, zT_258);
    zT_254 = zT_260;
    zT_255 = node_idx;
    zT_261 = zF_9F1ECA79_semanticAnalyzerRes(zT_252, zT_253, zT_254, zT_255);
    result = zT_261;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_35;
    z_bb_61:
    zT_262 = node.kind;
    if ((int)(zT_262 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    zT_267 = self;
    zT_268 = node_idx;
    zT_269 = zF_DDD991E1_semanticAnalyzerRes(zT_267, zT_268);
    result = zT_269;
    zT_271 = "FAD:R";
    zT_273 = 5;
    zT_272.ptr = zT_271;
    zT_272.len = zT_273;
    fad = zT_272;
    zT_274 = fad;
    zT_275 = result;
    zF_C914CB83_markerWriteInt(zT_274, zT_275);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_276 = node.kind;
    if ((int)(zT_276 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_index_access))) goto z_bb_65; else goto z_bb_67;
    z_bb_65:
    zT_281 = self;
    zT_282 = node_idx;
    zT_283 = zF_1926BC05_semanticAnalyzerRes(zT_281, zT_282);
    result = zT_283;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_284 = node.kind;
    if ((int)(zT_284 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_68; else goto z_bb_70;
    z_bb_68:
    zT_289 = self;
    zT_290 = node_idx;
    zT_291 = zF_F902E73E_semanticAnalyzerRes(zT_289, zT_290);
    result = zT_291;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_66;
    z_bb_70:
    zT_292 = node.kind;
    if ((int)(zT_292 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_deref))) goto z_bb_71; else goto z_bb_73;
    z_bb_71:
    zT_298 = self;
    zT_299 = node.child_0;
    zT_301 = zF_54F95822_semanticAnalyzerRes(zT_298, zT_299);
    base = zT_301;
    if ((int)(base != (unsigned int)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    goto z_bb_69;
    z_bb_73:
    zT_331 = node.kind;
    if ((int)(zT_331 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_address_of))) goto z_bb_86; else goto z_bb_88;
    z_bb_74:
    zT_304 = base != (unsigned int)(1);
    goto z_bb_76;
    z_bb_75:
    zT_304 = 0;
    goto z_bb_76;
    z_bb_76:
    if (zT_304) goto z_bb_77; else goto z_bb_79;
    z_bb_77:
    zT_308 = self->registry;
    zT_309 = zT_308->types_items;
    zT_310 = (unsigned int)base;
    zT_311 = zT_309[zT_310];
    bt = zT_311;
    zT_312 = bt.kind;
    if ((int)(zT_312 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_81; else goto z_bb_80;
    z_bb_78:
    goto z_bb_72;
    z_bb_79:
    zT_330 = 1;
    result = zT_330;
    goto z_bb_78;
    z_bb_80:
    zT_318 = bt.kind;
    zT_317 = zT_318 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_82;
    z_bb_81:
    zT_317 = 1;
    goto z_bb_82;
    z_bb_82:
    if (zT_317) goto z_bb_83; else goto z_bb_85;
    z_bb_83:
    zT_324 = self->registry;
    zT_325 = zT_324->ptr_items;
    zT_326 = bt.payload_idx;
    zT_327 = (unsigned int)zT_326;
    zT_328 = zT_325[zT_327];
    pp = zT_328;
    zT_329 = pp.base;
    result = zT_329;
    goto z_bb_84;
    z_bb_84:
    goto z_bb_78;
    z_bb_85:
    result = base;
    goto z_bb_84;
    z_bb_86:
    zT_337 = self;
    zT_338 = node.child_0;
    zT_340 = zF_54F95822_semanticAnalyzerRes(zT_337, zT_338);
    base = zT_340;
    if ((int)(base != (unsigned int)(0))) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    goto z_bb_72;
    z_bb_88:
    zT_461 = node.kind;
    if ((int)(zT_461 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_call))) goto z_bb_113; else goto z_bb_115;
    z_bb_89:
    zT_343 = base != (unsigned int)(1);
    goto z_bb_91;
    z_bb_90:
    zT_343 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_343) goto z_bb_92; else goto z_bb_94;
    z_bb_92:
    zT_347 = self->store;
    zT_348 = node.child_0;
    zT_351 = zF_FCDD1D35_astStoreNodeAt(zT_347, zT_348);
    base_node = zT_351;
    zT_352 = base_node.kind;
    if ((int)(zT_352 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_95; else goto z_bb_96;
    z_bb_93:
    goto z_bb_87;
    z_bb_94:
    zT_460 = 1;
    result = zT_460;
    goto z_bb_93;
    z_bb_95:
    zT_358 = self;
    zT_359 = base_node.child_0;
    zT_361 = zF_54F95822_semanticAnalyzerRes(zT_358, zT_359);
    fa_base_t = zT_361;
    st = fa_base_t;
    if ((int)(fa_base_t != (unsigned int)(0))) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    zT_454 = self->registry;
    zT_455 = base;
    zT_459 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_454, zT_455, (int)(0));
    result = zT_459;
    goto z_bb_93;
    z_bb_97:
    zT_365 = fa_base_t != (unsigned int)(1);
    goto z_bb_99;
    z_bb_98:
    zT_365 = 0;
    goto z_bb_99;
    z_bb_99:
    if (zT_365) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_369 = self->registry;
    zT_370 = zT_369->types_items;
    zT_371 = (unsigned int)st;
    zT_372 = zT_370[zT_371];
    st_ty = zT_372;
    zT_373 = st_ty.kind;
    if ((int)(zT_373 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_103; else goto z_bb_102;
    z_bb_101:
    goto z_bb_96;
    z_bb_102:
    zT_379 = st_ty.kind;
    zT_378 = zT_379 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_104;
    z_bb_103:
    zT_378 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_378) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_384 = self->registry;
    zT_385 = zT_384->ptr_items;
    zT_386 = st_ty.payload_idx;
    zT_387 = (unsigned int)zT_386;
    zT_388 = zT_385[zT_387];
    zT_389 = zT_388.base;
    st = zT_389;
    zT_390 = self->registry;
    zT_391 = zT_390->types_items;
    zT_392 = (unsigned int)st;
    zT_393 = zT_391[zT_392];
    st_ty = zT_393;
    goto z_bb_106;
    z_bb_106:
    zT_394 = st_ty.kind;
    if ((int)(zT_394 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_400 = self;
    zT_401 = st;
    zT_402 = zF_1BB4D489_semanticAnalyzerPac(zT_400, zT_401);
    sd = zT_402;
    if ((int)(sd != (unsigned int)(0))) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    zT_427 = st_ty.kind;
    if ((int)(zT_427 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_111; else goto z_bb_112;
    z_bb_109:
    zT_406 = node.span_start;
    aps = zT_406;
    zT_408 = node.span_len;
    zT_410 = aps + (unsigned int)((unsigned int)zT_408);
    ape = zT_410;
    zT_412 = "cannot take the address of a field of a packed struct; packed fields have no address";
    zT_414 = 84;
    zT_413.ptr = zT_412;
    zT_413.len = zT_414;
    aof_msg = zT_413;
    zT_415 = self->diag;
    zT_418 = self->source_file_id;
    zT_419 = aps;
    zT_420 = ape;
    zT_421 = aof_msg;
    zT_426 = zF_C82559AC_diagnosticCollector(zT_415, (unsigned char)(0), (unsigned short)(3000), zT_418, zT_419, zT_420, zT_421);
    (void)zT_426;
    goto z_bb_110;
    z_bb_110:
    goto z_bb_108;
    z_bb_111:
    zT_433 = node.span_start;
    apu_s = zT_433;
    zT_435 = node.span_len;
    zT_437 = apu_s + (unsigned int)((unsigned int)zT_435);
    apu_e = zT_437;
    zT_439 = "cannot take the address of a field of a packed union; packed fields have no address";
    zT_441 = 83;
    zT_440.ptr = zT_439;
    zT_440.len = zT_441;
    aou_msg = zT_440;
    zT_442 = self->diag;
    zT_445 = self->source_file_id;
    zT_446 = apu_s;
    zT_447 = apu_e;
    zT_448 = aou_msg;
    zT_453 = zF_C82559AC_diagnosticCollector(zT_442, (unsigned char)(0), (unsigned short)(3000), zT_445, zT_446, zT_447, zT_448);
    (void)zT_453;
    goto z_bb_112;
    z_bb_112:
    goto z_bb_101;
    z_bb_113:
    zT_466 = self;
    zT_467 = node_idx;
    zT_468 = zF_87E78775_semanticAnalyzerRes(zT_466, zT_467);
    result = zT_468;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_87;
    z_bb_115:
    zT_469 = node.kind;
    if ((int)(zT_469 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_475 = self;
    zT_476 = node.child_0;
    zT_478 = zF_CAF1FD28_semanticAnalyzerIsB(zT_475, zT_476);
    zT_474 = !zT_478;
    goto z_bb_118;
    z_bb_117:
    zT_474 = 0;
    goto z_bb_118;
    z_bb_118:
    if (zT_474) goto z_bb_119; else goto z_bb_121;
    z_bb_119:
    zT_481 = "unsupported builtin function";
    zT_483 = 28;
    zT_482.ptr = zT_481;
    zT_482.len = zT_483;
    ub_msg = zT_482;
    zT_484 = self->diag;
    zT_487 = self->source_file_id;
    zT_488 = node.span_start;
    zT_496 = node.span_start;
    zT_497 = node.span_len;
    zT_490 = ub_msg;
    zT_500 = zF_C82559AC_diagnosticCollector(zT_484, (unsigned char)(0), (unsigned short)(3000), zT_487, zT_488, (unsigned int)(zT_496 + (unsigned int)((unsigned int)zT_497)), zT_490);
    (void)zT_500;
    zT_501 = 1;
    result = zT_501;
    goto z_bb_120;
    z_bb_120:
    goto z_bb_114;
    z_bb_121:
    zT_502 = node.kind;
    if ((int)(zT_502 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_122; else goto z_bb_124;
    z_bb_122:
    zT_508 = self->store;
    zT_509 = node_idx;
    zT_511 = zF_850FDF81_astStoreNodeExtraCh(zT_508, zT_509);
    ec = zT_511;
    zT_513 = "@cVaArg";
    zT_515 = 7;
    zT_514.ptr = zT_513;
    zT_514.len = zT_515;
    cva = zT_514;
    zT_516 = node.child_0;
    zT_517 = self->size_of_name_id;
    if ((int)(zT_516 == zT_517)) goto z_bb_126; else goto z_bb_125;
    z_bb_123:
    goto z_bb_120;
    z_bb_124:
    zT_1321 = node.kind;
    if ((int)(zT_1321 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_332; else goto z_bb_334;
    z_bb_125:
    zT_520 = node.child_0;
    zT_521 = self->align_of_name_id;
    zT_519 = zT_520 == zT_521;
    goto z_bb_127;
    z_bb_126:
    zT_519 = 1;
    goto z_bb_127;
    z_bb_127:
    if (zT_519) goto z_bb_129; else goto z_bb_128;
    z_bb_128:
    zT_524 = node.child_0;
    zT_525 = self->offset_of_name_id;
    zT_523 = zT_524 == zT_525;
    goto z_bb_130;
    z_bb_129:
    zT_523 = 1;
    goto z_bb_130;
    z_bb_130:
    if (zT_523) goto z_bb_132; else goto z_bb_131;
    z_bb_131:
    zT_528 = node.child_0;
    zT_529 = self->bit_size_of_name_id;
    zT_527 = zT_528 == zT_529;
    goto z_bb_133;
    z_bb_132:
    zT_527 = 1;
    goto z_bb_133;
    z_bb_133:
    if (zT_527) goto z_bb_135; else goto z_bb_134;
    z_bb_134:
    zT_532 = node.child_0;
    zT_533 = self->bit_offset_of_name_id;
    zT_531 = zT_532 == zT_533;
    goto z_bb_136;
    z_bb_135:
    zT_531 = 1;
    goto z_bb_136;
    z_bb_136:
    if (zT_531) goto z_bb_137; else goto z_bb_139;
    z_bb_137:
    zT_536 = ec.len;
    if ((int)(zT_536 >= (unsigned int)(1))) goto z_bb_140; else goto z_bb_141;
    z_bb_138:
    goto z_bb_123;
    z_bb_139:
    zT_560 = node.child_0;
    zT_561 = self->ptrtoint_name_id;
    if ((int)(zT_560 == zT_561)) goto z_bb_143; else goto z_bb_142;
    z_bb_140:
    zT_541 = self->store;
    zT_540.store = zT_541;
    zT_542 = self->registry;
    zT_540.typereg = zT_542;
    zT_543 = self->symbols;
    zT_540.symbol_reg = zT_543;
    zT_544 = self->interner;
    zT_540.interner = zT_544;
    zT_545 = self->module_id;
    zT_540.module_id = zT_545;
    zT_546 = self->diag;
    zT_547.has_value = 1;
    zT_547.value = zT_546;
    zT_540.diag = zT_547;
    zT_548.has_value = 0;
    zT_540.local_consts = zT_548;
    zT_549 = self->source_file_id;
    zT_540.source_file_id = zT_549;
    so_env = zT_540;
    zT_550 = &so_env;
    zT_554 = ec.ptr;
    zT_555 = 0;
    zT_551 = zT_554[zT_555];
    zT_558 = zF_F2107C15_resolveTypeExprFull(zT_550, zT_551, (unsigned int)(0));
    (void)zT_558;
    goto z_bb_141;
    z_bb_141:
    zT_559 = 19;
    result = zT_559;
    goto z_bb_138;
    z_bb_142:
    zT_564 = node.child_0;
    zT_565 = self->int_from_ptr_name_id;
    zT_563 = zT_564 == zT_565;
    goto z_bb_144;
    z_bb_143:
    zT_563 = 1;
    goto z_bb_144;
    z_bb_144:
    if (zT_563) goto z_bb_145; else goto z_bb_147;
    z_bb_145:
    zT_568 = ec.len;
    if ((int)(zT_568 >= (unsigned int)(1))) goto z_bb_148; else goto z_bb_149;
    z_bb_146:
    goto z_bb_138;
    z_bb_147:
    zT_578 = node.child_0;
    zT_579 = self->ptr_from_int_name_id;
    if ((int)(zT_578 == zT_579)) goto z_bb_150; else goto z_bb_152;
    z_bb_148:
    zT_571 = self;
    zT_573 = ec.ptr;
    zT_574 = 0;
    zT_572 = zT_573[zT_574];
    zT_576 = zF_54F95822_semanticAnalyzerRes(zT_571, zT_572);
    (void)zT_576;
    goto z_bb_149;
    z_bb_149:
    zT_577 = 13;
    result = zT_577;
    goto z_bb_146;
    z_bb_150:
    zT_583 = 1;
    pfi_res = zT_583;
    zT_585 = ec.len;
    if ((int)(zT_585 >= (unsigned int)(1))) goto z_bb_153; else goto z_bb_154;
    z_bb_151:
    goto z_bb_146;
    z_bb_152:
    zT_644 = node.child_0;
    zT_645 = self->field_parent_ptr_name_id;
    if ((int)(zT_644 == zT_645)) goto z_bb_167; else goto z_bb_169;
    z_bb_153:
    zT_588 = self;
    zT_590 = ec.ptr;
    zT_591 = 0;
    zT_589 = zT_590[zT_591];
    zT_593 = zF_54F95822_semanticAnalyzerRes(zT_588, zT_589);
    (void)zT_593;
    zT_595 = self;
    zT_596 = zF_4DE7C2BC_topExpectedType(zT_595);
    pfi_top = zT_596;
    if ((int)(pfi_top != (unsigned int)(0))) goto z_bb_155; else goto z_bb_156;
    z_bb_154:
    if ((int)(pfi_res == (unsigned int)(1))) goto z_bb_165; else goto z_bb_166;
    z_bb_155:
    zT_599 = pfi_top != (unsigned int)(18);
    goto z_bb_157;
    z_bb_156:
    zT_599 = 0;
    goto z_bb_157;
    z_bb_157:
    if (zT_599) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_603 = self->registry;
    zT_604 = zT_603->types_items;
    zT_605 = (unsigned int)pfi_top;
    zT_606 = zT_604[zT_605];
    pfi_ty = zT_606;
    zT_607 = pfi_ty.kind;
    if ((int)(zT_607 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_161; else goto z_bb_160;
    z_bb_159:
    goto z_bb_154;
    z_bb_160:
    zT_613 = pfi_ty.kind;
    zT_612 = zT_613 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_162;
    z_bb_161:
    zT_612 = 1;
    goto z_bb_162;
    z_bb_162:
    if (zT_612) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    pfi_res = pfi_top;
    goto z_bb_164;
    z_bb_164:
    goto z_bb_159;
    z_bb_165:
    zT_621 = "cannot infer pointer type for @ptrFromInt; annotate the target variable type";
    zT_623 = 76;
    zT_622.ptr = zT_621;
    zT_622.len = zT_623;
    pfi_msg = zT_622;
    zT_624 = self->diag;
    zT_627 = self->source_file_id;
    zT_628 = node.span_start;
    zT_639 = node.span_start;
    zT_640 = node.span_len;
    zT_630 = pfi_msg;
    zT_643 = zF_C82559AC_diagnosticCollector(zT_624, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_627, zT_628, (unsigned int)(zT_639 + (unsigned int)((unsigned int)zT_640)), zT_630);
    (void)zT_643;
    goto z_bb_166;
    z_bb_166:
    result = pfi_res;
    goto z_bb_151;
    z_bb_167:
    zT_649 = 1;
    fpp_res = zT_649;
    zT_651 = ec.len;
    if ((int)(zT_651 >= (unsigned int)(3))) goto z_bb_170; else goto z_bb_171;
    z_bb_168:
    goto z_bb_151;
    z_bb_169:
    zT_689 = node.child_0;
    zT_690 = self->bitcast_name_id;
    if ((int)(zT_689 == zT_690)) goto z_bb_174; else goto z_bb_176;
    z_bb_170:
    zT_656 = self->store;
    zT_655.store = zT_656;
    zT_657 = self->registry;
    zT_655.typereg = zT_657;
    zT_658 = self->symbols;
    zT_655.symbol_reg = zT_658;
    zT_659 = self->interner;
    zT_655.interner = zT_659;
    zT_660 = self->module_id;
    zT_655.module_id = zT_660;
    zT_661 = self->diag;
    zT_662.has_value = 1;
    zT_662.value = zT_661;
    zT_655.diag = zT_662;
    zT_663.has_value = 0;
    zT_655.local_consts = zT_663;
    zT_664 = self->source_file_id;
    zT_655.source_file_id = zT_664;
    fpp_env = zT_655;
    zT_666 = &fpp_env;
    zT_670 = ec.ptr;
    zT_671 = 0;
    zT_667 = zT_670[zT_671];
    zT_674 = zF_F2107C15_resolveTypeExprFull(zT_666, zT_667, (unsigned int)(0));
    fpp_outer = zT_674;
    if ((int)(fpp_outer != (unsigned int)(18))) goto z_bb_172; else goto z_bb_173;
    z_bb_171:
    result = fpp_res;
    goto z_bb_168;
    z_bb_172:
    zT_677 = self;
    zT_679 = ec.ptr;
    zT_680 = 2;
    zT_678 = zT_679[zT_680];
    zT_682 = zF_54F95822_semanticAnalyzerRes(zT_677, zT_678);
    (void)zT_682;
    zT_683 = self->registry;
    zT_684 = fpp_outer;
    zT_688 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_683, zT_684, (int)(0));
    fpp_res = zT_688;
    goto z_bb_173;
    z_bb_173:
    goto z_bb_171;
    z_bb_174:
    zT_694 = 1;
    bc_res = zT_694;
    zT_696 = ec.len;
    if ((int)(zT_696 >= (unsigned int)(2))) goto z_bb_177; else goto z_bb_178;
    z_bb_175:
    goto z_bb_168;
    z_bb_176:
    zT_791 = node.child_0;
    zT_792 = self->getchar_name_id;
    if ((int)(zT_791 == zT_792)) goto z_bb_199; else goto z_bb_201;
    z_bb_177:
    zT_701 = self->store;
    zT_700.store = zT_701;
    zT_702 = self->registry;
    zT_700.typereg = zT_702;
    zT_703 = self->symbols;
    zT_700.symbol_reg = zT_703;
    zT_704 = self->interner;
    zT_700.interner = zT_704;
    zT_705 = self->module_id;
    zT_700.module_id = zT_705;
    zT_706 = self->diag;
    zT_707.has_value = 1;
    zT_707.value = zT_706;
    zT_700.diag = zT_707;
    zT_708.has_value = 0;
    zT_700.local_consts = zT_708;
    zT_709 = self->source_file_id;
    zT_700.source_file_id = zT_709;
    bc_env = zT_700;
    zT_711 = &bc_env;
    zT_715 = ec.ptr;
    zT_716 = 0;
    zT_712 = zT_715[zT_716];
    zT_719 = zF_F2107C15_resolveTypeExprFull(zT_711, zT_712, (unsigned int)(0));
    bc_dst = zT_719;
    if ((int)(bc_dst != (unsigned int)(18))) goto z_bb_179; else goto z_bb_180;
    z_bb_178:
    result = bc_res;
    goto z_bb_175;
    z_bb_179:
    zT_723 = self;
    zT_725 = ec.ptr;
    zT_726 = 1;
    zT_724 = zT_725[zT_726];
    zT_728 = zF_54F95822_semanticAnalyzerRes(zT_723, zT_724);
    bc_src = zT_728;
    zT_730 = 0;
    bc_ok = zT_730;
    if ((int)(bc_src != (unsigned int)(18))) goto z_bb_181; else goto z_bb_182;
    z_bb_180:
    goto z_bb_178;
    z_bb_181:
    zT_734 = self->registry;
    zT_735 = bc_dst;
    zT_737 = zF_3290E9C4_typeRegistryIsInteg(zT_734, zT_735);
    zT_733 = zT_737;
    goto z_bb_183;
    z_bb_182:
    zT_733 = 0;
    goto z_bb_183;
    z_bb_183:
    if (zT_733) goto z_bb_184; else goto z_bb_185;
    z_bb_184:
    zT_739 = self->registry;
    zT_740 = bc_src;
    zT_742 = zF_3290E9C4_typeRegistryIsInteg(zT_739, zT_740);
    zT_738 = zT_742;
    goto z_bb_186;
    z_bb_185:
    zT_738 = 0;
    goto z_bb_186;
    z_bb_186:
    if (zT_738) goto z_bb_187; else goto z_bb_188;
    z_bb_187:
    zT_744 = self->registry;
    zT_745 = zT_744->types_items;
    zT_746 = (unsigned int)bc_dst;
    zT_747 = zT_745[zT_746];
    bc_dty = zT_747;
    zT_749 = self->registry;
    zT_750 = zT_749->types_items;
    zT_751 = (unsigned int)bc_src;
    zT_752 = zT_750[zT_751];
    bc_sty = zT_752;
    zT_753 = bc_dty.state;
    if ((int)(zT_753 == (unsigned char)(2))) goto z_bb_189; else goto z_bb_190;
    z_bb_188:
    bc_res = bc_dst;
    if ((int)(bc_ok == (unsigned char)(0))) goto z_bb_197; else goto z_bb_198;
    z_bb_189:
    zT_757 = bc_sty.state;
    zT_756 = zT_757 == (unsigned char)(2);
    goto z_bb_191;
    z_bb_190:
    zT_756 = 0;
    goto z_bb_191;
    z_bb_191:
    if (zT_756) goto z_bb_192; else goto z_bb_193;
    z_bb_192:
    zT_761 = bc_dty.size;
    zT_762 = bc_sty.size;
    zT_760 = zT_761 == zT_762;
    goto z_bb_194;
    z_bb_193:
    zT_760 = 0;
    goto z_bb_194;
    z_bb_194:
    if (zT_760) goto z_bb_195; else goto z_bb_196;
    z_bb_195:
    zT_764 = 1;
    bc_ok = zT_764;
    goto z_bb_196;
    z_bb_196:
    goto z_bb_188;
    z_bb_197:
    zT_768 = "@bitCast requires same-size integer source and destination types";
    zT_770 = 64;
    zT_769.ptr = zT_768;
    zT_769.len = zT_770;
    bc_msg = zT_769;
    zT_771 = self->diag;
    zT_774 = self->source_file_id;
    zT_775 = node.span_start;
    zT_786 = node.span_start;
    zT_787 = node.span_len;
    zT_777 = bc_msg;
    zT_790 = zF_C82559AC_diagnosticCollector(zT_771, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3000_TYPE_MISMATCH)), zT_774, zT_775, (unsigned int)(zT_786 + (unsigned int)((unsigned int)zT_787)), zT_777);
    (void)zT_790;
    goto z_bb_198;
    z_bb_198:
    goto z_bb_180;
    z_bb_199:
    zT_794 = 8;
    result = zT_794;
    goto z_bb_200;
    z_bb_200:
    goto z_bb_175;
    z_bb_201:
    zT_795 = node.child_0;
    zT_796 = self->exit_name_id;
    if ((int)(zT_795 == zT_796)) goto z_bb_202; else goto z_bb_204;
    z_bb_202:
    zT_799 = ec.len;
    if ((int)(zT_799 >= (unsigned int)(1))) goto z_bb_205; else goto z_bb_206;
    z_bb_203:
    goto z_bb_200;
    z_bb_204:
    zT_809 = node.child_0;
    zT_810 = self->panic_name_id;
    if ((int)(zT_809 == zT_810)) goto z_bb_207; else goto z_bb_209;
    z_bb_205:
    zT_802 = self;
    zT_804 = ec.ptr;
    zT_805 = 0;
    zT_803 = zT_804[zT_805];
    zT_807 = zF_54F95822_semanticAnalyzerRes(zT_802, zT_803);
    (void)zT_807;
    goto z_bb_206;
    z_bb_206:
    zT_808 = 3;
    result = zT_808;
    goto z_bb_203;
    z_bb_207:
    zT_813 = ec.len;
    if ((int)(zT_813 >= (unsigned int)(1))) goto z_bb_210; else goto z_bb_211;
    z_bb_208:
    goto z_bb_203;
    z_bb_209:
    zT_823 = node.child_0;
    zT_824 = self->putchar_name_id;
    if ((int)(zT_823 == zT_824)) goto z_bb_213; else goto z_bb_212;
    z_bb_210:
    zT_816 = self;
    zT_818 = ec.ptr;
    zT_819 = 0;
    zT_817 = zT_818[zT_819];
    zT_821 = zF_54F95822_semanticAnalyzerRes(zT_816, zT_817);
    (void)zT_821;
    goto z_bb_211;
    z_bb_211:
    zT_822 = 3;
    result = zT_822;
    goto z_bb_208;
    z_bb_212:
    zT_827 = node.child_0;
    zT_828 = self->sleep_ms_name_id;
    zT_826 = zT_827 == zT_828;
    goto z_bb_214;
    z_bb_213:
    zT_826 = 1;
    goto z_bb_214;
    z_bb_214:
    if (zT_826) goto z_bb_215; else goto z_bb_217;
    z_bb_215:
    zT_831 = ec.len;
    if ((int)(zT_831 >= (unsigned int)(1))) goto z_bb_218; else goto z_bb_219;
    z_bb_216:
    goto z_bb_208;
    z_bb_217:
    zT_841 = node.child_0;
    zT_842 = self->stdout_write_name_id;
    if ((int)(zT_841 == zT_842)) goto z_bb_221; else goto z_bb_220;
    z_bb_218:
    zT_834 = self;
    zT_836 = ec.ptr;
    zT_837 = 0;
    zT_835 = zT_836[zT_837];
    zT_839 = zF_54F95822_semanticAnalyzerRes(zT_834, zT_835);
    (void)zT_839;
    goto z_bb_219;
    z_bb_219:
    zT_840 = 1;
    result = zT_840;
    goto z_bb_216;
    z_bb_220:
    zT_845 = node.child_0;
    zT_846 = self->stderr_write_name_id;
    zT_844 = zT_845 == zT_846;
    goto z_bb_222;
    z_bb_221:
    zT_844 = 1;
    goto z_bb_222;
    z_bb_222:
    if (zT_844) goto z_bb_223; else goto z_bb_225;
    z_bb_223:
    zT_849 = ec.len;
    if ((int)(zT_849 >= (unsigned int)(2))) goto z_bb_226; else goto z_bb_228;
    z_bb_224:
    goto z_bb_216;
    z_bb_225:
    zT_875 = node.child_0;
    zT_876 = self->is_windows_name_id;
    if ((int)(zT_875 == zT_876)) goto z_bb_231; else goto z_bb_233;
    z_bb_226:
    zT_852 = self;
    zT_854 = ec.ptr;
    zT_855 = 0;
    zT_853 = zT_854[zT_855];
    zT_857 = zF_54F95822_semanticAnalyzerRes(zT_852, zT_853);
    (void)zT_857;
    zT_858 = self;
    zT_860 = ec.ptr;
    zT_861 = 1;
    zT_859 = zT_860[zT_861];
    zT_863 = zF_54F95822_semanticAnalyzerRes(zT_858, zT_859);
    (void)zT_863;
    goto z_bb_227;
    z_bb_227:
    zT_874 = 1;
    result = zT_874;
    goto z_bb_224;
    z_bb_228:
    zT_865 = ec.len;
    if ((int)(zT_865 >= (unsigned int)(1))) goto z_bb_229; else goto z_bb_230;
    z_bb_229:
    zT_868 = self;
    zT_870 = ec.ptr;
    zT_871 = 0;
    zT_869 = zT_870[zT_871];
    zT_873 = zF_54F95822_semanticAnalyzerRes(zT_868, zT_869);
    (void)zT_873;
    goto z_bb_230;
    z_bb_230:
    goto z_bb_227;
    z_bb_231:
    zT_878 = 2;
    result = zT_878;
    goto z_bb_232;
    z_bb_232:
    goto z_bb_224;
    z_bb_233:
    zT_879 = node.child_0;
    zT_880 = self->console_clear_name_id;
    if ((int)(zT_879 == zT_880)) goto z_bb_234; else goto z_bb_236;
    z_bb_234:
    zT_882 = 1;
    result = zT_882;
    goto z_bb_235;
    z_bb_235:
    goto z_bb_232;
    z_bb_236:
    zT_883 = node.child_0;
    zT_884 = self->console_gotoxy_name_id;
    if ((int)(zT_883 == zT_884)) goto z_bb_238; else goto z_bb_237;
    z_bb_237:
    zT_887 = node.child_0;
    zT_888 = self->console_set_color_name_id;
    zT_886 = zT_887 == zT_888;
    goto z_bb_239;
    z_bb_238:
    zT_886 = 1;
    goto z_bb_239;
    z_bb_239:
    if (zT_886) goto z_bb_240; else goto z_bb_242;
    z_bb_240:
    zT_891 = ec.len;
    if ((int)(zT_891 >= (unsigned int)(2))) goto z_bb_243; else goto z_bb_245;
    z_bb_241:
    goto z_bb_235;
    z_bb_242:
    zT_917 = node.child_0;
    zT_918 = self->async_frame_size_name_id;
    if ((int)(zT_917 == zT_918)) goto z_bb_248; else goto z_bb_250;
    z_bb_243:
    zT_894 = self;
    zT_896 = ec.ptr;
    zT_897 = 0;
    zT_895 = zT_896[zT_897];
    zT_899 = zF_54F95822_semanticAnalyzerRes(zT_894, zT_895);
    (void)zT_899;
    zT_900 = self;
    zT_902 = ec.ptr;
    zT_903 = 1;
    zT_901 = zT_902[zT_903];
    zT_905 = zF_54F95822_semanticAnalyzerRes(zT_900, zT_901);
    (void)zT_905;
    goto z_bb_244;
    z_bb_244:
    zT_916 = 1;
    result = zT_916;
    goto z_bb_241;
    z_bb_245:
    zT_907 = ec.len;
    if ((int)(zT_907 >= (unsigned int)(1))) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    zT_910 = self;
    zT_912 = ec.ptr;
    zT_913 = 0;
    zT_911 = zT_912[zT_913];
    zT_915 = zF_54F95822_semanticAnalyzerRes(zT_910, zT_911);
    (void)zT_915;
    goto z_bb_247;
    z_bb_247:
    goto z_bb_244;
    z_bb_248:
    zT_921 = ec.len;
    if ((int)(zT_921 >= (unsigned int)(1))) goto z_bb_251; else goto z_bb_252;
    z_bb_249:
    goto z_bb_241;
    z_bb_250:
    zT_985 = node.child_0;
    zT_986 = self->async_init_name_id;
    if ((int)(zT_985 == zT_986)) goto z_bb_259; else goto z_bb_261;
    z_bb_251:
    zT_924 = self;
    zT_926 = ec.ptr;
    zT_927 = 0;
    zT_925 = zT_926[zT_927];
    zT_929 = zF_54F95822_semanticAnalyzerRes(zT_924, zT_925);
    (void)zT_929;
    zT_931 = 0;
    afs_susp = zT_931;
    zT_932 = self->store;
    zT_933 = self->symbols;
    zT_934 = self->module_id;
    zT_939 = ec.ptr;
    zT_940 = 0;
    zT_935 = zT_939[zT_940];
    zT_942 = zF_860C82EC_resolveCalleeKey(zT_932, zT_933, zT_934, zT_935);
    zT_943 = zT_942.has_value;
    if (zT_943) goto z_bb_253; else goto z_bb_254;
    z_bb_252:
    zT_984 = 19;
    result = zT_984;
    goto z_bb_249;
    z_bb_253:
    afs_k = zT_942.value;
    zT_948 = (unsigned int)(zT_79FAE712_u64)(afs_k >> (zT_79FAE712_u64)(32));
    afs_mid = zT_948;
    zT_952 = (unsigned int)(zT_79FAE712_u64)(afs_k & (zT_79FAE712_u64)(4294967295u));
    afs_nid = zT_952;
    zT_953 = self->suspending_fns;
    zT_954 = afs_mid;
    zT_955 = afs_nid;
    zT_957 = zF_7C7E43BF_asyncIsSuspending(zT_953, zT_954, zT_955);
    if (zT_957) goto z_bb_255; else goto z_bb_256;
    z_bb_254:
    if ((int)(!afs_susp)) goto z_bb_257; else goto z_bb_258;
    z_bb_255:
    zT_958 = 1;
    afs_susp = zT_958;
    goto z_bb_256;
    z_bb_256:
    goto z_bb_254;
    z_bb_257:
    zT_961 = "@asyncFrameSize argument must be a known suspending function";
    zT_963 = 60;
    zT_962.ptr = zT_961;
    zT_962.len = zT_963;
    e3046 = zT_962;
    zT_964 = self->diag;
    zT_967 = self->source_file_id;
    zT_968 = node.span_start;
    zT_979 = node.span_start;
    zT_980 = node.span_len;
    zT_970 = e3046;
    zT_983 = zF_C82559AC_diagnosticCollector(zT_964, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3046_ASYNC_FRAME_SIZE_INVALID)), zT_967, zT_968, (unsigned int)(zT_979 + (unsigned int)((unsigned int)zT_980)), zT_970);
    (void)zT_983;
    goto z_bb_258;
    z_bb_258:
    goto z_bb_252;
    z_bb_259:
    zT_989 = ec.len;
    if ((int)(zT_989 >= (unsigned int)(4))) goto z_bb_262; else goto z_bb_263;
    z_bb_260:
    goto z_bb_249;
    z_bb_261:
    zT_1025 = node.child_0;
    zT_1026 = self->async_resume_name_id;
    if ((int)(zT_1025 == zT_1026)) goto z_bb_264; else goto z_bb_266;
    z_bb_262:
    zT_992 = self;
    zT_994 = ec.ptr;
    zT_995 = 0;
    zT_993 = zT_994[zT_995];
    zT_997 = zF_54F95822_semanticAnalyzerRes(zT_992, zT_993);
    (void)zT_997;
    zT_998 = self;
    zT_1000 = ec.ptr;
    zT_1001 = 1;
    zT_999 = zT_1000[zT_1001];
    zT_1003 = zF_54F95822_semanticAnalyzerRes(zT_998, zT_999);
    (void)zT_1003;
    zT_1004 = self;
    zT_1006 = ec.ptr;
    zT_1007 = 2;
    zT_1005 = zT_1006[zT_1007];
    zT_1009 = zF_54F95822_semanticAnalyzerRes(zT_1004, zT_1005);
    (void)zT_1009;
    zT_1010 = self;
    zT_1012 = ec.ptr;
    zT_1013 = 3;
    zT_1011 = zT_1012[zT_1013];
    zT_1015 = zF_54F95822_semanticAnalyzerRes(zT_1010, zT_1011);
    (void)zT_1015;
    goto z_bb_263;
    z_bb_263:
    zT_1016 = self;
    zT_1017 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1016, zT_1017);
    zT_1018 = self->registry;
    zT_1024 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1018, (unsigned int)(1), (int)(0));
    result = zT_1024;
    goto z_bb_260;
    z_bb_264:
    zT_1029 = ec.len;
    if ((int)(zT_1029 >= (unsigned int)(2))) goto z_bb_267; else goto z_bb_268;
    z_bb_265:
    goto z_bb_260;
    z_bb_266:
    zT_1057 = node.child_0;
    zT_1058 = self->async_suspend_name_id;
    if ((int)(zT_1057 == zT_1058)) goto z_bb_269; else goto z_bb_271;
    z_bb_267:
    zT_1032 = self;
    zT_1034 = ec.ptr;
    zT_1035 = 0;
    zT_1033 = zT_1034[zT_1035];
    zT_1037 = zF_54F95822_semanticAnalyzerRes(zT_1032, zT_1033);
    (void)zT_1037;
    zT_1038 = self;
    zT_1040 = ec.ptr;
    zT_1041 = 1;
    zT_1039 = zT_1040[zT_1041];
    zT_1043 = zF_54F95822_semanticAnalyzerRes(zT_1038, zT_1039);
    (void)zT_1043;
    goto z_bb_268;
    z_bb_268:
    zT_1044 = self;
    zT_1045 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1044, zT_1045);
    zT_1046 = self->registry;
    zT_1049 = self->registry;
    zT_1055 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1049, (unsigned int)(1), (int)(0));
    zT_1047 = zT_1055;
    zT_1056 = zF_74A7234F_typeRegistryGetOrCr(zT_1046, zT_1047);
    result = zT_1056;
    goto z_bb_265;
    z_bb_269:
    zT_1061 = ec.len;
    if ((int)(zT_1061 >= (unsigned int)(1))) goto z_bb_272; else goto z_bb_273;
    z_bb_270:
    goto z_bb_265;
    z_bb_271:
    zT_1081 = node.child_0;
    zT_1082 = self->ptrcast_name_id;
    if ((int)(zT_1081 == zT_1082)) goto z_bb_274; else goto z_bb_275;
    z_bb_272:
    zT_1064 = self;
    zT_1066 = ec.ptr;
    zT_1067 = 0;
    zT_1065 = zT_1066[zT_1067];
    zT_1069 = zF_54F95822_semanticAnalyzerRes(zT_1064, zT_1065);
    (void)zT_1069;
    goto z_bb_273;
    z_bb_273:
    zT_1070 = self;
    zT_1071 = node_idx;
    zF_2EC0CDC8_semanticAnalyzerDia(zT_1070, zT_1071);
    zT_1072 = self;
    zT_1073 = node_idx;
    zF_D4D0798B_semanticAnalyzerDia(zT_1072, zT_1073);
    zT_1074 = self->registry;
    zT_1080 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_1074, (unsigned int)(1), (int)(0));
    result = zT_1080;
    goto z_bb_270;
    z_bb_274:
    zT_1086 = ec.len;
    zT_1084 = zT_1086 != (unsigned int)(2);
    goto z_bb_276;
    z_bb_275:
    zT_1084 = 0;
    goto z_bb_276;
    z_bb_276:
    if (zT_1084) goto z_bb_277; else goto z_bb_279;
    z_bb_277:
    zT_1090 = "@ptrCast requires exactly two arguments: @ptrCast(T, expr)";
    zT_1092 = 58;
    zT_1091.ptr = zT_1090;
    zT_1091.len = zT_1092;
    pc3049 = zT_1091;
    zT_1093 = self->diag;
    zT_1096 = self->source_file_id;
    zT_1097 = node.span_start;
    zT_1108 = node.span_start;
    zT_1109 = node.span_len;
    zT_1099 = pc3049;
    zT_1112 = zF_C82559AC_diagnosticCollector(zT_1093, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3049_PTRCAST_REQUIRES_TWO_ARGS)), zT_1096, zT_1097, (unsigned int)(zT_1108 + (unsigned int)((unsigned int)zT_1109)), zT_1099);
    (void)zT_1112;
    zT_1114 = ec.len;
    if ((int)(zT_1114 >= (unsigned int)(1))) goto z_bb_280; else goto z_bb_281;
    z_bb_278:
    goto z_bb_270;
    z_bb_279:
    zT_1124 = self;
    zT_1125 = node.child_0;
    zT_1126 = cva;
    zT_1128 = zF_2ACB4E23_semanticAnalyzerBui(zT_1124, zT_1125, zT_1126);
    if (zT_1128) goto z_bb_282; else goto z_bb_284;
    z_bb_280:
    zT_1117 = self;
    zT_1119 = ec.ptr;
    zT_1120 = 0;
    zT_1118 = zT_1119[zT_1120];
    zT_1122 = zF_54F95822_semanticAnalyzerRes(zT_1117, zT_1118);
    (void)zT_1122;
    goto z_bb_281;
    z_bb_281:
    zT_1123 = 18;
    result = zT_1123;
    goto z_bb_278;
    z_bb_282:
    zT_1130 = ec.len;
    if ((int)(zT_1130 >= (unsigned int)(2))) goto z_bb_285; else goto z_bb_287;
    z_bb_283:
    goto z_bb_278;
    z_bb_284:
    zT_1161 = ec.len;
    if ((int)(zT_1161 >= (unsigned int)(2))) goto z_bb_288; else goto z_bb_290;
    z_bb_285:
    zT_1133 = self;
    zT_1135 = ec.ptr;
    zT_1136 = 0;
    zT_1134 = zT_1135[zT_1136];
    zT_1138 = zF_54F95822_semanticAnalyzerRes(zT_1133, zT_1134);
    (void)zT_1138;
    zT_1141 = self->store;
    zT_1140.store = zT_1141;
    zT_1142 = self->registry;
    zT_1140.typereg = zT_1142;
    zT_1143 = self->symbols;
    zT_1140.symbol_reg = zT_1143;
    zT_1144 = self->interner;
    zT_1140.interner = zT_1144;
    zT_1145 = self->module_id;
    zT_1140.module_id = zT_1145;
    zT_1146 = self->diag;
    zT_1147.has_value = 1;
    zT_1147.value = zT_1146;
    zT_1140.diag = zT_1147;
    zT_1148.has_value = 0;
    zT_1140.local_consts = zT_1148;
    zT_1149 = self->source_file_id;
    zT_1140.source_file_id = zT_1149;
    cva_env = zT_1140;
    zT_1150 = &cva_env;
    zT_1154 = ec.ptr;
    zT_1155 = 1;
    zT_1151 = zT_1154[zT_1155];
    zT_1158 = zF_F2107C15_resolveTypeExprFull(zT_1150, zT_1151, (unsigned int)(0));
    result = zT_1158;
    goto z_bb_286;
    z_bb_286:
    goto z_bb_283;
    z_bb_287:
    zT_1159 = 1;
    result = zT_1159;
    goto z_bb_286;
    z_bb_288:
    zT_1164 = self;
    zT_1165 = node.child_0;
    zT_1167 = zF_3757023F_semanticAnalyzerIsT(zT_1164, zT_1165);
    if (zT_1167) goto z_bb_291; else goto z_bb_293;
    z_bb_289:
    goto z_bb_283;
    z_bb_290:
    zT_1270 = node.child_0;
    zT_1271 = self->enumtoint_name_id;
    if ((int)(zT_1270 == zT_1271)) goto z_bb_314; else goto z_bb_315;
    z_bb_291:
    zT_1169 = self;
    zT_1171 = ec.ptr;
    zT_1172 = 1;
    zT_1170 = zT_1171[zT_1172];
    zT_1174 = zF_54F95822_semanticAnalyzerRes(zT_1169, zT_1170);
    tv_src = zT_1174;
    zT_1177 = self->store;
    zT_1176.store = zT_1177;
    zT_1178 = self->registry;
    zT_1176.typereg = zT_1178;
    zT_1179 = self->symbols;
    zT_1176.symbol_reg = zT_1179;
    zT_1180 = self->interner;
    zT_1176.interner = zT_1180;
    zT_1181 = self->module_id;
    zT_1176.module_id = zT_1181;
    zT_1182 = self->diag;
    zT_1183.has_value = 1;
    zT_1183.value = zT_1182;
    zT_1176.diag = zT_1183;
    zT_1184.has_value = 0;
    zT_1176.local_consts = zT_1184;
    zT_1185 = self->source_file_id;
    zT_1176.source_file_id = zT_1185;
    tre_env = zT_1176;
    zT_1186 = &tre_env;
    zT_1190 = ec.ptr;
    zT_1191 = 0;
    zT_1187 = zT_1190[zT_1191];
    zT_1194 = zF_F2107C15_resolveTypeExprFull(zT_1186, zT_1187, (unsigned int)(0));
    result = zT_1194;
    zT_1195 = node.child_0;
    zT_1196 = self->ptrcast_name_id;
    if ((int)(zT_1195 == zT_1196)) goto z_bb_294; else goto z_bb_295;
    z_bb_292:
    goto z_bb_289;
    z_bb_293:
    zT_1264 = self;
    zT_1266 = ec.ptr;
    zT_1267 = 0;
    zT_1265 = zT_1266[zT_1267];
    zT_1269 = zF_54F95822_semanticAnalyzerRes(zT_1264, zT_1265);
    result = zT_1269;
    goto z_bb_292;
    z_bb_294:
    zT_1198 = tv_src != (unsigned int)(18);
    goto z_bb_296;
    z_bb_295:
    zT_1198 = 0;
    goto z_bb_296;
    z_bb_296:
    if (zT_1198) goto z_bb_297; else goto z_bb_298;
    z_bb_297:
    zT_1201 = result != (unsigned int)(18);
    goto z_bb_299;
    z_bb_298:
    zT_1201 = 0;
    goto z_bb_299;
    z_bb_299:
    if (zT_1201) goto z_bb_300; else goto z_bb_301;
    z_bb_300:
    zT_1204 = self;
    zT_1205 = tv_src;
    zT_1206 = result;
    zT_1207 = zF_5F2042EA_semanticAnalyzerPtr(zT_1204, zT_1205, zT_1206);
    if (zT_1207) goto z_bb_302; else goto z_bb_303;
    z_bb_301:
    zT_1229 = node.child_0;
    zT_1230 = self->volatilecast_name_id;
    if ((int)(zT_1229 == zT_1230)) goto z_bb_304; else goto z_bb_305;
    z_bb_302:
    zT_1209 = "@ptrCast cannot discard the 'volatile' qualifier; use @volatileCast to remove it";
    zT_1211 = 80;
    zT_1210.ptr = zT_1209;
    zT_1210.len = zT_1211;
    pcq_msg = zT_1210;
    zT_1212 = self->diag;
    zT_1215 = self->source_file_id;
    zT_1216 = node.span_start;
    zT_1224 = node.span_start;
    zT_1225 = node.span_len;
    zT_1218 = pcq_msg;
    zT_1228 = zF_C82559AC_diagnosticCollector(zT_1212, (unsigned char)(0), (unsigned short)(3000), zT_1215, zT_1216, (unsigned int)(zT_1224 + (unsigned int)((unsigned int)zT_1225)), zT_1218);
    (void)zT_1228;
    goto z_bb_303;
    z_bb_303:
    goto z_bb_301;
    z_bb_304:
    zT_1232 = tv_src != (unsigned int)(18);
    goto z_bb_306;
    z_bb_305:
    zT_1232 = 0;
    goto z_bb_306;
    z_bb_306:
    if (zT_1232) goto z_bb_307; else goto z_bb_308;
    z_bb_307:
    zT_1235 = result != (unsigned int)(18);
    goto z_bb_309;
    z_bb_308:
    zT_1235 = 0;
    goto z_bb_309;
    z_bb_309:
    if (zT_1235) goto z_bb_310; else goto z_bb_311;
    z_bb_310:
    zT_1238 = self;
    zT_1239 = tv_src;
    zT_1240 = result;
    zT_1241 = zF_EC29CB82_semanticAnalyzerVol(zT_1238, zT_1239, zT_1240);
    if ((int)(!zT_1241)) goto z_bb_312; else goto z_bb_313;
    z_bb_311:
    goto z_bb_292;
    z_bb_312:
    zT_1244 = "@volatileCast requires a volatile pointer source and a destination with the same base type";
    zT_1246 = 90;
    zT_1245.ptr = zT_1244;
    zT_1245.len = zT_1246;
    vcc_msg = zT_1245;
    zT_1247 = self->diag;
    zT_1250 = self->source_file_id;
    zT_1251 = node.span_start;
    zT_1259 = node.span_start;
    zT_1260 = node.span_len;
    zT_1253 = vcc_msg;
    zT_1263 = zF_C82559AC_diagnosticCollector(zT_1247, (unsigned char)(0), (unsigned short)(3000), zT_1250, zT_1251, (unsigned int)(zT_1259 + (unsigned int)((unsigned int)zT_1260)), zT_1253);
    (void)zT_1263;
    goto z_bb_313;
    z_bb_313:
    goto z_bb_311;
    z_bb_314:
    zT_1275 = ec.len;
    zT_1273 = zT_1275 >= (unsigned int)(1);
    goto z_bb_316;
    z_bb_315:
    zT_1273 = 0;
    goto z_bb_316;
    z_bb_316:
    if (zT_1273) goto z_bb_317; else goto z_bb_319;
    z_bb_317:
    zT_1279 = self;
    zT_1281 = ec.ptr;
    zT_1282 = 0;
    zT_1280 = zT_1281[zT_1282];
    zT_1284 = zF_54F95822_semanticAnalyzerRes(zT_1279, zT_1280);
    e2i_arg = zT_1284;
    e2i_res = e2i_arg;
    if ((int)(e2i_arg != (unsigned int)(18))) goto z_bb_320; else goto z_bb_321;
    z_bb_318:
    goto z_bb_289;
    z_bb_319:
    zT_1311 = ec.len;
    if ((int)(zT_1311 >= (unsigned int)(1))) goto z_bb_329; else goto z_bb_331;
    z_bb_320:
    zT_1289 = self->registry;
    zT_1290 = zT_1289->types_items;
    zT_1291 = (unsigned int)e2i_arg;
    zT_1292 = zT_1290[zT_1291];
    e2i_ty = zT_1292;
    zT_1293 = e2i_ty.kind;
    if ((int)(zT_1293 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_322; else goto z_bb_323;
    z_bb_321:
    result = e2i_res;
    goto z_bb_318;
    z_bb_322:
    zT_1299 = self->registry;
    zT_1300 = e2i_arg;
    zT_1302 = zF_014D7530_typeRegistryEnumBac(zT_1299, zT_1300);
    e2i_bt = zT_1302;
    if ((int)(e2i_bt != (unsigned int)(18))) goto z_bb_324; else goto z_bb_325;
    z_bb_323:
    goto z_bb_321;
    z_bb_324:
    zT_1307 = self->registry;
    zT_1308 = zT_1307->types_len;
    zT_1305 = (unsigned int)((unsigned int)e2i_bt) < zT_1308;
    goto z_bb_326;
    z_bb_325:
    zT_1305 = 0;
    goto z_bb_326;
    z_bb_326:
    if (zT_1305) goto z_bb_327; else goto z_bb_328;
    z_bb_327:
    e2i_res = e2i_bt;
    goto z_bb_328;
    z_bb_328:
    goto z_bb_323;
    z_bb_329:
    zT_1314 = self;
    zT_1316 = ec.ptr;
    zT_1317 = 0;
    zT_1315 = zT_1316[zT_1317];
    zT_1319 = zF_54F95822_semanticAnalyzerRes(zT_1314, zT_1315);
    result = zT_1319;
    goto z_bb_330;
    z_bb_330:
    goto z_bb_318;
    z_bb_331:
    zT_1320 = 1;
    result = zT_1320;
    goto z_bb_330;
    z_bb_332:
    zT_1326 = self;
    zT_1327 = node.child_0;
    zT_1329 = zF_54F95822_semanticAnalyzerRes(zT_1326, zT_1327);
    (void)zT_1329;
    zT_1330 = 2;
    result = zT_1330;
    goto z_bb_333;
    z_bb_333:
    goto z_bb_123;
    z_bb_334:
    zT_1331 = node.kind;
    if ((int)(zT_1331 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_336; else goto z_bb_335;
    z_bb_335:
    zT_1337 = node.kind;
    zT_1336 = zT_1337 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_negate);
    goto z_bb_337;
    z_bb_336:
    zT_1336 = 1;
    goto z_bb_337;
    z_bb_337:
    if (zT_1336) goto z_bb_338; else goto z_bb_340;
    z_bb_338:
    zT_1342 = self;
    zT_1343 = node_idx;
    zT_1344 = zF_09421FDF_semanticAnalyzerRes(zT_1342, zT_1343);
    result = zT_1344;
    goto z_bb_339;
    z_bb_339:
    goto z_bb_333;
    z_bb_340:
    zT_1345 = node.kind;
    if ((int)(zT_1345 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_341; else goto z_bb_343;
    z_bb_341:
    zT_1350 = self;
    zT_1351 = node_idx;
    zT_1352 = zF_6B59E8AD_semanticAnalyzerRes(zT_1350, zT_1351);
    result = zT_1352;
    goto z_bb_342;
    z_bb_342:
    goto z_bb_339;
    z_bb_343:
    zT_1353 = node.kind;
    if ((int)(zT_1353 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_try_expr))) goto z_bb_344; else goto z_bb_346;
    z_bb_344:
    zT_1358 = self;
    zT_1359 = node_idx;
    zT_1360 = zF_B78F27CD_semanticAnalyzerRes(zT_1358, zT_1359);
    result = zT_1360;
    goto z_bb_345;
    z_bb_345:
    goto z_bb_342;
    z_bb_346:
    zT_1361 = node.kind;
    if ((int)(zT_1361 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_catch_expr))) goto z_bb_347; else goto z_bb_349;
    z_bb_347:
    zT_1367 = 0;
    zT_1368 = (unsigned int)zT_1367;
    catch_es = zT_1368;
    zT_1369 = self;
    zT_1370 = node.child_0;
    zT_1372 = zF_54F95822_semanticAnalyzerRes(zT_1369, zT_1370);
    result = zT_1372;
    if ((int)(result != (unsigned int)(18))) goto z_bb_350; else goto z_bb_351;
    z_bb_348:
    goto z_bb_345;
    z_bb_349:
    zT_1461 = node.kind;
    if ((int)(zT_1461 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_orelse_expr))) goto z_bb_367; else goto z_bb_369;
    z_bb_350:
    zT_1376 = self->registry;
    zT_1377 = zT_1376->types_items;
    zT_1378 = (unsigned int)result;
    zT_1379 = zT_1377[zT_1378];
    clt = zT_1379;
    zT_1380 = clt.kind;
    if ((int)(zT_1380 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_352; else goto z_bb_353;
    z_bb_351:
    zT_1406 = node.child_2;
    zT_1407 = 0;
    if ((int)(zT_1406 != (unsigned int)zT_1407)) goto z_bb_354; else goto z_bb_355;
    z_bb_352:
    zT_1385 = self->registry;
    zT_1386 = zT_1385->eu_items;
    zT_1387 = clt.payload_idx;
    zT_1388 = (unsigned int)zT_1387;
    zT_1389 = zT_1386[zT_1388];
    zT_1390 = zT_1389.error_set;
    catch_es = zT_1390;
    zT_1391 = self->registry;
    zT_1392 = zT_1391->eu_items;
    zT_1393 = clt.payload_idx;
    zT_1394 = (unsigned int)zT_1393;
    zT_1395 = zT_1392[zT_1394];
    zT_1396 = zT_1395.payload;
    result = zT_1396;
    zT_1397 = self->coercion_table;
    zT_1398 = node.child_0;
    zT_1400 = result;
    zF_D21AE60A_coercionTableAdd(zT_1397, zT_1398, (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_unwrap_optional), zT_1400);
    goto z_bb_353;
    z_bb_353:
    goto z_bb_351;
    z_bb_354:
    zT_1410 = self->store;
    zT_1411 = node.child_2;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_1410, zT_1411);
    zT_1415 = self->local_decl_count;
    zT_1416 = self->local_decl_cap;
    if ((int)(zT_1415 >= zT_1416)) goto z_bb_356; else goto z_bb_357;
    z_bb_355:
    zT_1435 = node.child_1;
    if ((int)(zT_1435 != (unsigned int)(0))) goto z_bb_361; else goto z_bb_362;
    z_bb_356:
    zT_1418 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_1418);
    goto z_bb_357;
    z_bb_357:
    zT_1419 = self->store;
    zT_1420 = node.child_2;
    zT_1423 = zF_8BA26B9E_astStoreNodePayload(zT_1419, zT_1420);
    zT_1424 = self->local_decl_names;
    zT_1425 = self->local_decl_count;
    zT_1424[zT_1425] = zT_1423;
    zT_1426 = 0;
    if ((int)(catch_es != (unsigned int)zT_1426)) goto z_bb_358; else goto z_bb_359;
    z_bb_358:
    zT_1428 = catch_es;
    goto z_bb_360;
    z_bb_359:
    zT_1428 = 6;
    goto z_bb_360;
    z_bb_360:
    zT_1430 = self->local_decl_types;
    zT_1431 = self->local_decl_count;
    zT_1430[zT_1431] = zT_1428;
    zT_1432 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_1432 + (unsigned int)(1));
    goto z_bb_355;
    z_bb_361:
    zT_1438 = 0;
    if ((int)(catch_es != (unsigned int)zT_1438)) goto z_bb_363; else goto z_bb_364;
    z_bb_362:
    goto z_bb_348;
    z_bb_363:
    zT_1441 = self->store;
    zT_1442 = node.child_1;
    zT_1445 = zF_FCDD1D35_astStoreNodeAt(zT_1441, zT_1442);
    child1 = zT_1445;
    zT_1446 = child1.kind;
    if ((int)(zT_1446 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal))) goto z_bb_365; else goto z_bb_366;
    z_bb_364:
    zT_1458 = self;
    zT_1459 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1458, zT_1459);
    goto z_bb_362;
    z_bb_365:
    zT_1451 = self;
    zT_1452 = catch_es;
    zF_9665A229_pushExpectedType(zT_1451, zT_1452);
    zT_1453 = self;
    zT_1454 = node.child_1;
    zT_1456 = zF_54F95822_semanticAnalyzerRes(zT_1453, zT_1454);
    (void)zT_1456;
    zT_1457 = self;
    zF_BC478E78_popExpectedType(zT_1457);
    goto z_bb_366;
    z_bb_366:
    goto z_bb_364;
    z_bb_367:
    zT_1466 = self;
    zT_1467 = node_idx;
    zT_1468 = zF_B36961FA_semanticAnalyzerRes(zT_1466, zT_1467);
    result = zT_1468;
    goto z_bb_368;
    z_bb_368:
    goto z_bb_348;
    z_bb_369:
    zT_1469 = node.kind;
    if ((int)(zT_1469 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_371; else goto z_bb_370;
    z_bb_370:
    zT_1475 = node.kind;
    zT_1474 = zT_1475 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt);
    goto z_bb_372;
    z_bb_371:
    zT_1474 = 1;
    goto z_bb_372;
    z_bb_372:
    if (zT_1474) goto z_bb_373; else goto z_bb_375;
    z_bb_373:
    zT_1480 = 1;
    result = zT_1480;
    goto z_bb_374;
    z_bb_374:
    goto z_bb_368;
    z_bb_375:
    zT_1481 = node.kind;
    if ((int)(zT_1481 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_377; else goto z_bb_376;
    z_bb_376:
    zT_1487 = node.kind;
    zT_1486 = zT_1487 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt);
    goto z_bb_378;
    z_bb_377:
    zT_1486 = 1;
    goto z_bb_378;
    z_bb_378:
    if (zT_1486) goto z_bb_380; else goto z_bb_379;
    z_bb_379:
    zT_1493 = node.kind;
    zT_1492 = zT_1493 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_381;
    z_bb_380:
    zT_1492 = 1;
    goto z_bb_381;
    z_bb_381:
    if (zT_1492) goto z_bb_383; else goto z_bb_382;
    z_bb_382:
    zT_1499 = node.kind;
    zT_1498 = zT_1499 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt);
    goto z_bb_384;
    z_bb_383:
    zT_1498 = 1;
    goto z_bb_384;
    z_bb_384:
    if (zT_1498) goto z_bb_385; else goto z_bb_387;
    z_bb_385:
    zT_1504 = self;
    zT_1505 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_1504, zT_1505);
    zT_1506 = 1;
    result = zT_1506;
    goto z_bb_386;
    z_bb_386:
    goto z_bb_374;
    z_bb_387:
    zT_1507 = node.kind;
    if ((int)(zT_1507 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_388; else goto z_bb_390;
    z_bb_388:
    zT_1512 = self;
    zT_1513 = node_idx;
    zT_1514 = zF_8B8EE70D_semanticAnalyzerRes(zT_1512, zT_1513);
    result = zT_1514;
    goto z_bb_389;
    z_bb_389:
    goto z_bb_386;
    z_bb_390:
    zT_1515 = node.kind;
    if ((int)(zT_1515 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_391; else goto z_bb_393;
    z_bb_391:
    zT_1520 = self;
    zT_1521 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_1520, zT_1521);
    zT_1522 = node.child_2;
    if ((int)(zT_1522 != (unsigned int)(0))) goto z_bb_394; else goto z_bb_395;
    z_bb_392:
    goto z_bb_389;
    z_bb_393:
    zT_1535 = node.kind;
    if ((int)(zT_1535 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_398; else goto z_bb_400;
    z_bb_394:
    zT_1525 = self;
    zT_1526 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_1525, zT_1526);
    goto z_bb_395;
    z_bb_395:
    zT_1528 = node.child_1;
    if ((int)(zT_1528 != (unsigned int)(0))) goto z_bb_396; else goto z_bb_397;
    z_bb_396:
    zT_1531 = self;
    zT_1532 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1531, zT_1532);
    goto z_bb_397;
    z_bb_397:
    zT_1534 = 1;
    result = zT_1534;
    goto z_bb_392;
    z_bb_398:
    zT_1540 = self;
    zT_1541 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_1540, zT_1541);
    zT_1542 = node.child_1;
    zT_1543 = 0;
    if ((int)(zT_1542 != (unsigned int)zT_1543)) goto z_bb_401; else goto z_bb_402;
    z_bb_399:
    goto z_bb_392;
    z_bb_400:
    zT_1549 = node.kind;
    if ((int)(zT_1549 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_403; else goto z_bb_405;
    z_bb_401:
    zT_1545 = self;
    zT_1546 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1545, zT_1546);
    goto z_bb_402;
    z_bb_402:
    zT_1548 = 1;
    result = zT_1548;
    goto z_bb_399;
    z_bb_403:
    zT_1554 = self;
    zT_1555 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_1554, zT_1555);
    zT_1556 = node.child_1;
    zT_1557 = 0;
    if ((int)(zT_1556 != (unsigned int)zT_1557)) goto z_bb_406; else goto z_bb_407;
    z_bb_404:
    goto z_bb_399;
    z_bb_405:
    zT_1563 = node.kind;
    if ((int)(zT_1563 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_408; else goto z_bb_410;
    z_bb_406:
    zT_1559 = self;
    zT_1560 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_1559, zT_1560);
    goto z_bb_407;
    z_bb_407:
    zT_1562 = 1;
    result = zT_1562;
    goto z_bb_404;
    z_bb_408:
    zT_1568 = self;
    zT_1569 = node_idx;
    zT_1570 = zF_2DB4F186_semanticAnalyzerRes(zT_1568, zT_1569);
    result = zT_1570;
    goto z_bb_409;
    z_bb_409:
    goto z_bb_404;
    z_bb_410:
    zT_1571 = node.kind;
    if ((int)(zT_1571 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal))) goto z_bb_411; else goto z_bb_413;
    z_bb_411:
    zT_1576 = self;
    zT_1577 = node_idx;
    zT_1578 = zF_227D2404_semanticAnalyzerRes(zT_1576, zT_1577);
    result = zT_1578;
    goto z_bb_412;
    z_bb_412:
    goto z_bb_409;
    z_bb_413:
    zT_1579 = node.kind;
    if ((int)(zT_1579 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init))) goto z_bb_414; else goto z_bb_416;
    z_bb_414:
    zT_1584 = self;
    zT_1585 = node_idx;
    zT_1586 = zF_AD7EF126_semanticAnalyzerRes(zT_1584, zT_1585);
    result = zT_1586;
    goto z_bb_415;
    z_bb_415:
    goto z_bb_412;
    z_bb_416:
    zT_1587 = node.kind;
    if ((int)(zT_1587 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_417; else goto z_bb_419;
    z_bb_417:
    zT_1593 = "AW:R";
    zT_1595 = 4;
    zT_1594.ptr = zT_1593;
    zT_1594.len = zT_1595;
    ai_dbg = zT_1594;
    zT_1596 = ai_dbg;
    zT_1597 = result;
    zF_C914CB83_markerWriteInt(zT_1596, zT_1597);
    zT_1598 = self;
    zT_1599 = node_idx;
    zT_1600 = zF_F3DAABE0_semanticAnalyzerRes(zT_1598, zT_1599);
    result = zT_1600;
    goto z_bb_418;
    z_bb_418:
    goto z_bb_415;
    z_bb_419:
    zT_1601 = node.kind;
    if ((int)(zT_1601 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_421; else goto z_bb_420;
    z_bb_420:
    zT_1607 = node.kind;
    zT_1606 = zT_1607 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_422;
    z_bb_421:
    zT_1606 = 1;
    goto z_bb_422;
    z_bb_422:
    if (zT_1606) goto z_bb_424; else goto z_bb_423;
    z_bb_423:
    zT_1613 = node.kind;
    zT_1612 = zT_1613 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_425;
    z_bb_424:
    zT_1612 = 1;
    goto z_bb_425;
    z_bb_425:
    if (zT_1612) goto z_bb_427; else goto z_bb_426;
    z_bb_426:
    zT_1619 = node.kind;
    zT_1618 = zT_1619 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_428;
    z_bb_427:
    zT_1618 = 1;
    goto z_bb_428;
    z_bb_428:
    if (zT_1618) goto z_bb_430; else goto z_bb_429;
    z_bb_429:
    zT_1625 = node.kind;
    zT_1624 = zT_1625 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_431;
    z_bb_430:
    zT_1624 = 1;
    goto z_bb_431;
    z_bb_431:
    if (zT_1624) goto z_bb_433; else goto z_bb_432;
    z_bb_432:
    zT_1631 = node.kind;
    zT_1630 = zT_1631 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_434;
    z_bb_433:
    zT_1630 = 1;
    goto z_bb_434;
    z_bb_434:
    if (zT_1630) goto z_bb_436; else goto z_bb_435;
    z_bb_435:
    zT_1637 = node.kind;
    zT_1636 = zT_1637 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_437;
    z_bb_436:
    zT_1636 = 1;
    goto z_bb_437;
    z_bb_437:
    if (zT_1636) goto z_bb_439; else goto z_bb_438;
    z_bb_438:
    zT_1643 = node.kind;
    zT_1642 = zT_1643 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl);
    goto z_bb_440;
    z_bb_439:
    zT_1642 = 1;
    goto z_bb_440;
    z_bb_440:
    if (zT_1642) goto z_bb_442; else goto z_bb_441;
    z_bb_441:
    zT_1649 = node.kind;
    zT_1648 = zT_1649 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_443;
    z_bb_442:
    zT_1648 = 1;
    goto z_bb_443;
    z_bb_443:
    if (zT_1648) goto z_bb_445; else goto z_bb_444;
    z_bb_444:
    zT_1655 = node.kind;
    zT_1654 = zT_1655 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_446;
    z_bb_445:
    zT_1654 = 1;
    goto z_bb_446;
    z_bb_446:
    if (zT_1654) goto z_bb_448; else goto z_bb_447;
    z_bb_447:
    zT_1661 = node.kind;
    zT_1660 = zT_1661 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_449;
    z_bb_448:
    zT_1660 = 1;
    goto z_bb_449;
    z_bb_449:
    if (zT_1660) goto z_bb_450; else goto z_bb_452;
    z_bb_450:
    zT_1666 = node.kind;
    if ((int)(zT_1666 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_453; else goto z_bb_454;
    z_bb_451:
    goto z_bb_418;
    z_bb_452:
    zT_1676 = node.kind;
    if ((int)(zT_1676 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_455; else goto z_bb_457;
    z_bb_453:
    zT_1671 = self;
    zT_1672 = node_idx;
    zT_1673 = self->module_id;
    zF_C26EF425_semanticAnalyzerGat(zT_1671, zT_1672, zT_1673);
    goto z_bb_454;
    z_bb_454:
    zT_1675 = 20;
    result = zT_1675;
    goto z_bb_451;
    z_bb_455:
    zT_1681 = self;
    zT_1682 = node.child_0;
    zT_1684 = zF_54F95822_semanticAnalyzerRes(zT_1681, zT_1682);
    result = zT_1684;
    goto z_bb_456;
    z_bb_456:
    goto z_bb_451;
    z_bb_457:
    zT_1685 = node.kind;
    if ((int)(zT_1685 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_458; else goto z_bb_460;
    z_bb_458:
    zT_1690 = self;
    zT_1691 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_1690, zT_1691);
    zT_1692 = 3;
    result = zT_1692;
    goto z_bb_459;
    z_bb_459:
    goto z_bb_456;
    z_bb_460:
    zT_1693 = node.kind;
    if ((int)(zT_1693 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_461; else goto z_bb_463;
    z_bb_461:
    zT_1698 = self;
    zT_1699 = node.child_0;
    zT_1701 = zF_54F95822_semanticAnalyzerRes(zT_1698, zT_1699);
    result = zT_1701;
    goto z_bb_462;
    z_bb_462:
    goto z_bb_459;
    z_bb_463:
    zT_1702 = node.kind;
    if ((int)(zT_1702 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_464; else goto z_bb_466;
    z_bb_464:
    zT_1707 = 1;
    result = zT_1707;
    goto z_bb_465;
    z_bb_465:
    goto z_bb_462;
    z_bb_466:
    zT_1708 = node.kind;
    if ((int)(zT_1708 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_467; else goto z_bb_469;
    z_bb_467:
    zT_1714 = "EBLK:N";
    zT_1716 = 6;
    zT_1715.ptr = zT_1714;
    zT_1715.len = zT_1716;
    eblk_m = zT_1715;
    zT_1717 = eblk_m;
    zT_1718 = node_idx;
    zF_C914CB83_markerWriteInt(zT_1717, zT_1718);
    zT_1720 = self->store;
    zT_1721 = node_idx;
    zT_1723 = zF_850FDF81_astStoreNodeExtraCh(zT_1720, zT_1721);
    children = zT_1723;
    zT_1725 = "EBLK:C";
    zT_1727 = 6;
    zT_1726.ptr = zT_1725;
    zT_1726.len = zT_1727;
    eblk_cm = zT_1726;
    zT_1728 = eblk_cm;
    zT_1731 = children.len;
    zF_C914CB83_markerWriteInt(zT_1728, (unsigned int)((unsigned int)zT_1731));
    zT_1734 = children.len;
    if ((int)(zT_1734 > (unsigned int)(0))) goto z_bb_470; else goto z_bb_472;
    z_bb_468:
    goto z_bb_465;
    z_bb_469:
    zT_1777 = node.kind;
    if ((int)(zT_1777 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_478; else goto z_bb_477;
    z_bb_470:
    zT_1738 = 0;
    zT_1739 = (unsigned int)zT_1738;
    si = zT_1739;
    goto z_bb_473;
    z_bb_471:
    goto z_bb_468;
    z_bb_472:
    zT_1776 = 1;
    result = zT_1776;
    goto z_bb_471;
    z_bb_473:
    zT_1741 = children.len;
    if ((int)(si < (unsigned int)(zT_1741 - (unsigned int)(1)))) goto z_bb_474; else goto z_bb_475;
    z_bb_474:
    zT_1746 = "EBLK:S";
    zT_1748 = 6;
    zT_1747.ptr = zT_1746;
    zT_1747.len = zT_1748;
    eblk_sm = zT_1747;
    zT_1749 = eblk_sm;
    zF_C914CB83_markerWriteInt(zT_1749, (unsigned int)((unsigned int)si));
    zT_1753 = "EBLK:D";
    zT_1755 = 6;
    zT_1754.ptr = zT_1753;
    zT_1754.len = zT_1755;
    eblk_cm2 = zT_1754;
    zT_1756 = eblk_cm2;
    zT_1758 = children.ptr;
    zT_1757 = zT_1758[si];
    zF_C914CB83_markerWriteInt(zT_1756, zT_1757);
    zT_1760 = self;
    zT_1762 = children.ptr;
    zT_1761 = zT_1762[si];
    zF_10A0DC35_semanticAnalyzerRes(zT_1760, zT_1761);
    goto z_bb_476;
    z_bb_475:
    zT_1767 = children.ptr;
    zT_1769 = children.len;
    zT_1771 = zT_1769 - (unsigned int)(1);
    zT_1772 = zT_1767[zT_1771];
    last_child = zT_1772;
    zT_1773 = self;
    zT_1774 = last_child;
    zT_1775 = zF_54F95822_semanticAnalyzerRes(zT_1773, zT_1774);
    result = zT_1775;
    goto z_bb_471;
    z_bb_476:
    zT_1764 = 1;
    zT_1765 = si + zT_1764;
    si = zT_1765;
    goto z_bb_473;
    z_bb_477:
    zT_1783 = node.kind;
    zT_1782 = zT_1783 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_479;
    z_bb_478:
    zT_1782 = 1;
    goto z_bb_479;
    z_bb_479:
    if (zT_1782) goto z_bb_481; else goto z_bb_480;
    z_bb_480:
    zT_1789 = node.kind;
    zT_1788 = zT_1789 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_482;
    z_bb_481:
    zT_1788 = 1;
    goto z_bb_482;
    z_bb_482:
    if (zT_1788) goto z_bb_484; else goto z_bb_483;
    z_bb_483:
    zT_1795 = node.kind;
    zT_1794 = zT_1795 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_485;
    z_bb_484:
    zT_1794 = 1;
    goto z_bb_485;
    z_bb_485:
    if (zT_1794) goto z_bb_487; else goto z_bb_486;
    z_bb_486:
    zT_1801 = node.kind;
    zT_1800 = zT_1801 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_488;
    z_bb_487:
    zT_1800 = 1;
    goto z_bb_488;
    z_bb_488:
    if (zT_1800) goto z_bb_490; else goto z_bb_489;
    z_bb_489:
    zT_1807 = node.kind;
    zT_1806 = zT_1807 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add);
    goto z_bb_491;
    z_bb_490:
    zT_1806 = 1;
    goto z_bb_491;
    z_bb_491:
    if (zT_1806) goto z_bb_493; else goto z_bb_492;
    z_bb_492:
    zT_1813 = node.kind;
    zT_1812 = zT_1813 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub);
    goto z_bb_494;
    z_bb_493:
    zT_1812 = 1;
    goto z_bb_494;
    z_bb_494:
    if (zT_1812) goto z_bb_496; else goto z_bb_495;
    z_bb_495:
    zT_1819 = node.kind;
    zT_1818 = zT_1819 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul);
    goto z_bb_497;
    z_bb_496:
    zT_1818 = 1;
    goto z_bb_497;
    z_bb_497:
    if (zT_1818) goto z_bb_499; else goto z_bb_498;
    z_bb_498:
    zT_1825 = node.kind;
    zT_1824 = zT_1825 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add);
    goto z_bb_500;
    z_bb_499:
    zT_1824 = 1;
    goto z_bb_500;
    z_bb_500:
    if (zT_1824) goto z_bb_502; else goto z_bb_501;
    z_bb_501:
    zT_1831 = node.kind;
    zT_1830 = zT_1831 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub);
    goto z_bb_503;
    z_bb_502:
    zT_1830 = 1;
    goto z_bb_503;
    z_bb_503:
    if (zT_1830) goto z_bb_505; else goto z_bb_504;
    z_bb_504:
    zT_1837 = node.kind;
    zT_1836 = zT_1837 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul);
    goto z_bb_506;
    z_bb_505:
    zT_1836 = 1;
    goto z_bb_506;
    z_bb_506:
    if (zT_1836) goto z_bb_507; else goto z_bb_509;
    z_bb_507:
    zT_1842 = self;
    zT_1843 = node_idx;
    zT_1844 = node.kind;
    zT_1846 = zF_44006DDD_semanticAnalyzerRes(zT_1842, zT_1843, zT_1844);
    result = zT_1846;
    goto z_bb_508;
    z_bb_508:
    goto z_bb_468;
    z_bb_509:
    zT_1847 = node.kind;
    if ((int)(zT_1847 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_511; else goto z_bb_510;
    z_bb_510:
    zT_1853 = node.kind;
    zT_1852 = zT_1853 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_512;
    z_bb_511:
    zT_1852 = 1;
    goto z_bb_512;
    z_bb_512:
    if (zT_1852) goto z_bb_514; else goto z_bb_513;
    z_bb_513:
    zT_1859 = node.kind;
    zT_1858 = zT_1859 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_515;
    z_bb_514:
    zT_1858 = 1;
    goto z_bb_515;
    z_bb_515:
    if (zT_1858) goto z_bb_517; else goto z_bb_516;
    z_bb_516:
    zT_1865 = node.kind;
    zT_1864 = zT_1865 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_518;
    z_bb_517:
    zT_1864 = 1;
    goto z_bb_518;
    z_bb_518:
    if (zT_1864) goto z_bb_520; else goto z_bb_519;
    z_bb_519:
    zT_1871 = node.kind;
    zT_1870 = zT_1871 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_521;
    z_bb_520:
    zT_1870 = 1;
    goto z_bb_521;
    z_bb_521:
    if (zT_1870) goto z_bb_523; else goto z_bb_522;
    z_bb_522:
    zT_1877 = node.kind;
    zT_1876 = zT_1877 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl);
    goto z_bb_524;
    z_bb_523:
    zT_1876 = 1;
    goto z_bb_524;
    z_bb_524:
    if (zT_1876) goto z_bb_525; else goto z_bb_527;
    z_bb_525:
    zT_1882 = self;
    zT_1883 = node_idx;
    zT_1884 = zF_733BCA9C_semanticAnalyzerRes(zT_1882, zT_1883);
    result = zT_1884;
    goto z_bb_526;
    z_bb_526:
    goto z_bb_508;
    z_bb_527:
    zT_1885 = node.kind;
    if ((int)(zT_1885 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_529; else goto z_bb_528;
    z_bb_528:
    zT_1891 = node.kind;
    zT_1890 = zT_1891 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_530;
    z_bb_529:
    zT_1890 = 1;
    goto z_bb_530;
    z_bb_530:
    if (zT_1890) goto z_bb_531; else goto z_bb_533;
    z_bb_531:
    zT_1896 = self;
    zT_1897 = node_idx;
    zT_1898 = zF_6F2B8B98_semanticAnalyzerRes(zT_1896, zT_1897);
    result = zT_1898;
    goto z_bb_532;
    z_bb_532:
    goto z_bb_526;
    z_bb_533:
    zT_1899 = node.kind;
    if ((int)(zT_1899 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_535; else goto z_bb_534;
    z_bb_534:
    zT_1905 = node.kind;
    zT_1904 = zT_1905 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_536;
    z_bb_535:
    zT_1904 = 1;
    goto z_bb_536;
    z_bb_536:
    if (zT_1904) goto z_bb_538; else goto z_bb_537;
    z_bb_537:
    zT_1911 = node.kind;
    zT_1910 = zT_1911 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_539;
    z_bb_538:
    zT_1910 = 1;
    goto z_bb_539;
    z_bb_539:
    if (zT_1910) goto z_bb_541; else goto z_bb_540;
    z_bb_540:
    zT_1917 = node.kind;
    zT_1916 = zT_1917 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_542;
    z_bb_541:
    zT_1916 = 1;
    goto z_bb_542;
    z_bb_542:
    if (zT_1916) goto z_bb_544; else goto z_bb_543;
    z_bb_543:
    zT_1923 = node.kind;
    zT_1922 = zT_1923 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_545;
    z_bb_544:
    zT_1922 = 1;
    goto z_bb_545;
    z_bb_545:
    if (zT_1922) goto z_bb_547; else goto z_bb_546;
    z_bb_546:
    zT_1929 = node.kind;
    zT_1928 = zT_1929 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_548;
    z_bb_547:
    zT_1928 = 1;
    goto z_bb_548;
    z_bb_548:
    if (zT_1928) goto z_bb_549; else goto z_bb_551;
    z_bb_549:
    zT_1934 = self;
    zT_1935 = node_idx;
    zT_1936 = node.kind;
    zT_1938 = zF_EB621FF0_semanticAnalyzerRes(zT_1934, zT_1935, zT_1936);
    result = zT_1938;
    goto z_bb_550;
    z_bb_550:
    goto z_bb_532;
    z_bb_551:
    zT_1939 = node.kind;
    if ((int)(zT_1939 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_553; else goto z_bb_552;
    z_bb_552:
    zT_1945 = node.kind;
    zT_1944 = zT_1945 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_554;
    z_bb_553:
    zT_1944 = 1;
    goto z_bb_554;
    z_bb_554:
    if (zT_1944) goto z_bb_556; else goto z_bb_555;
    z_bb_555:
    zT_1951 = node.kind;
    zT_1950 = zT_1951 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_557;
    z_bb_556:
    zT_1950 = 1;
    goto z_bb_557;
    z_bb_557:
    if (zT_1950) goto z_bb_559; else goto z_bb_558;
    z_bb_558:
    zT_1957 = node.kind;
    zT_1956 = zT_1957 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_560;
    z_bb_559:
    zT_1956 = 1;
    goto z_bb_560;
    z_bb_560:
    if (zT_1956) goto z_bb_562; else goto z_bb_561;
    z_bb_561:
    zT_1963 = node.kind;
    zT_1962 = zT_1963 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_563;
    z_bb_562:
    zT_1962 = 1;
    goto z_bb_563;
    z_bb_563:
    if (zT_1962) goto z_bb_565; else goto z_bb_564;
    z_bb_564:
    zT_1969 = node.kind;
    zT_1968 = zT_1969 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_566;
    z_bb_565:
    zT_1968 = 1;
    goto z_bb_566;
    z_bb_566:
    if (zT_1968) goto z_bb_568; else goto z_bb_567;
    z_bb_567:
    zT_1975 = node.kind;
    zT_1974 = zT_1975 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_569;
    z_bb_568:
    zT_1974 = 1;
    goto z_bb_569;
    z_bb_569:
    if (zT_1974) goto z_bb_571; else goto z_bb_570;
    z_bb_570:
    zT_1981 = node.kind;
    zT_1980 = zT_1981 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_572;
    z_bb_571:
    zT_1980 = 1;
    goto z_bb_572;
    z_bb_572:
    if (zT_1980) goto z_bb_574; else goto z_bb_573;
    z_bb_573:
    zT_1987 = node.kind;
    zT_1986 = zT_1987 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_575;
    z_bb_574:
    zT_1986 = 1;
    goto z_bb_575;
    z_bb_575:
    if (zT_1986) goto z_bb_577; else goto z_bb_576;
    z_bb_576:
    zT_1993 = node.kind;
    zT_1992 = zT_1993 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_578;
    z_bb_577:
    zT_1992 = 1;
    goto z_bb_578;
    z_bb_578:
    if (zT_1992) goto z_bb_580; else goto z_bb_579;
    z_bb_579:
    zT_1999 = node.kind;
    zT_1998 = zT_1999 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_581;
    z_bb_580:
    zT_1998 = 1;
    goto z_bb_581;
    z_bb_581:
    if (zT_1998) goto z_bb_583; else goto z_bb_582;
    z_bb_582:
    zT_2005 = node.kind;
    zT_2004 = zT_2005 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_584;
    z_bb_583:
    zT_2004 = 1;
    goto z_bb_584;
    z_bb_584:
    if (zT_2004) goto z_bb_586; else goto z_bb_585;
    z_bb_585:
    zT_2011 = node.kind;
    zT_2010 = zT_2011 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_587;
    z_bb_586:
    zT_2010 = 1;
    goto z_bb_587;
    z_bb_587:
    if (zT_2010) goto z_bb_589; else goto z_bb_588;
    z_bb_588:
    zT_2017 = node.kind;
    zT_2016 = zT_2017 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_590;
    z_bb_589:
    zT_2016 = 1;
    goto z_bb_590;
    z_bb_590:
    if (zT_2016) goto z_bb_592; else goto z_bb_591;
    z_bb_591:
    zT_2023 = node.kind;
    zT_2022 = zT_2023 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_593;
    z_bb_592:
    zT_2022 = 1;
    goto z_bb_593;
    z_bb_593:
    if (zT_2022) goto z_bb_595; else goto z_bb_594;
    z_bb_594:
    zT_2029 = node.kind;
    zT_2028 = zT_2029 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_596;
    z_bb_595:
    zT_2028 = 1;
    goto z_bb_596;
    z_bb_596:
    if (zT_2028) goto z_bb_598; else goto z_bb_597;
    z_bb_597:
    zT_2035 = node.kind;
    zT_2034 = zT_2035 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_599;
    z_bb_598:
    zT_2034 = 1;
    goto z_bb_599;
    z_bb_599:
    if (zT_2034) goto z_bb_601; else goto z_bb_600;
    z_bb_600:
    zT_2041 = node.kind;
    zT_2040 = zT_2041 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_602;
    z_bb_601:
    zT_2040 = 1;
    goto z_bb_602;
    z_bb_602:
    if (zT_2040) goto z_bb_603; else goto z_bb_605;
    z_bb_603:
    zT_2046 = self;
    zT_2047 = node_idx;
    zT_2048 = zF_C0551BB8_semanticAnalyzerRes(zT_2046, zT_2047);
    result = zT_2048;
    goto z_bb_604;
    z_bb_604:
    goto z_bb_550;
    z_bb_605:
    zT_2049 = node.kind;
    if ((int)(zT_2049 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_607; else goto z_bb_606;
    z_bb_606:
    zT_2055 = node.kind;
    zT_2054 = zT_2055 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_608;
    z_bb_607:
    zT_2054 = 1;
    goto z_bb_608;
    z_bb_608:
    if (zT_2054) goto z_bb_609; else goto z_bb_611;
    z_bb_609:
    zT_2060 = self->type_table;
    zT_2061 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_2060, zT_2061, (unsigned int)(10));
    return (unsigned int)(10);
    goto z_bb_604;
    z_bb_611:
    zT_2067 = "ST:N";
    zT_2069 = 4;
    zT_2068.ptr = zT_2067;
    zT_2068.len = zT_2069;
    st_m = zT_2068;
    zT_2070 = st_m;
    zT_2071 = node_idx;
    zF_C914CB83_markerWriteInt(zT_2070, zT_2071);
    zT_2073 = node.kind;
    zT_2074 = (unsigned int)zT_2073;
    st_kv = zT_2074;
    zT_2076 = "ST:K";
    zT_2078 = 4;
    zT_2077.ptr = zT_2076;
    zT_2077.len = zT_2078;
    st_km = zT_2077;
    zT_2079 = st_km;
    zT_2080 = st_kv;
    zF_C914CB83_markerWriteInt(zT_2079, zT_2080);
    zT_2082 = "internal error: unhandled node kind in type resolution";
    zT_2084 = 54;
    zT_2083.ptr = zT_2082;
    zT_2083.len = zT_2084;
    unr_msg = zT_2083;
    zT_2085 = self->diag;
    zT_2088 = self->source_file_id;
    zT_2089 = node_idx;
    zT_2090 = node_idx;
    zT_2091 = unr_msg;
    zT_2096 = zF_C82559AC_diagnosticCollector(zT_2085, (unsigned char)(0), (unsigned short)(3020), zT_2088, zT_2089, zT_2090, zT_2091);
    (void)zT_2096;
    return (unsigned int)(1);
}

/* semanticAnalyzerFnPtrConvMismatch */
int zF_148F8E19_semanticAnalyzerFnP(zT_38C12417_SemanticAnalyzer* self, unsigned int src, unsigned int tgt) {
    zT_338B7C76_TypeRegistry* zT_6;
    unsigned int zT_7;
    int zT_9;
    zT_338B7C76_TypeRegistry* zT_11;
    unsigned int zT_12;
    zT_338B7C76_TypeRegistry* zT_18;
    zT_D155D06D_Type* zT_19;
    unsigned int zT_20;
    zT_D155D06D_Type zT_21;
    zT_33EF6BFB_TypeKind zT_22;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_112BF819_PtrPayload* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_112BF819_PtrPayload zT_31;
    unsigned int zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    zT_D155D06D_Type* zT_34;
    unsigned int zT_35;
    zT_D155D06D_Type zT_36;
    zT_338B7C76_TypeRegistry* zT_38;
    zT_D155D06D_Type* zT_39;
    unsigned int zT_40;
    zT_D155D06D_Type zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_112BF819_PtrPayload* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_112BF819_PtrPayload zT_51;
    unsigned int zT_52;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_D155D06D_Type* zT_54;
    unsigned int zT_55;
    zT_D155D06D_Type zT_56;
    zT_33EF6BFB_TypeKind zT_57;
    int zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_0317B1D5_FnPayload* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_0317B1D5_FnPayload zT_74;
    zT_338B7C76_TypeRegistry* zT_76;
    zT_0317B1D5_FnPayload* zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_0317B1D5_FnPayload zT_80;
    unsigned char zT_81;
    unsigned char zT_84;
    unsigned int s;
    unsigned int t;
    zT_D155D06D_Type st;
    zT_D155D06D_Type tt;
    zT_0317B1D5_FnPayload sfp;
    zT_0317B1D5_FnPayload tfp;
    if ((int)(src == tgt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_6 = self->registry;
    zT_7 = zT_6->types_len;
    if ((int)((unsigned int)((unsigned int)src) >= zT_7)) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_11 = self->registry;
    zT_12 = zT_11->types_len;
    zT_9 = (unsigned int)((unsigned int)tgt) >= zT_12;
    goto z_bb_5;
    z_bb_4:
    zT_9 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_9) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (int)(0);
    z_bb_7:
    s = src;
    t = tgt;
    zT_18 = self->registry;
    zT_19 = zT_18->types_items;
    zT_20 = (unsigned int)s;
    zT_21 = zT_19[zT_20];
    st = zT_21;
    zT_22 = st.kind;
    if ((int)(zT_22 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_27 = self->registry;
    zT_28 = zT_27->ptr_items;
    zT_29 = st.payload_idx;
    zT_30 = (unsigned int)zT_29;
    zT_31 = zT_28[zT_30];
    zT_32 = zT_31.base;
    s = zT_32;
    zT_33 = self->registry;
    zT_34 = zT_33->types_items;
    zT_35 = (unsigned int)s;
    zT_36 = zT_34[zT_35];
    st = zT_36;
    goto z_bb_9;
    z_bb_9:
    zT_38 = self->registry;
    zT_39 = zT_38->types_items;
    zT_40 = (unsigned int)t;
    zT_41 = zT_39[zT_40];
    tt = zT_41;
    zT_42 = tt.kind;
    if ((int)(zT_42 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_47 = self->registry;
    zT_48 = zT_47->ptr_items;
    zT_49 = tt.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    zT_52 = zT_51.base;
    t = zT_52;
    zT_53 = self->registry;
    zT_54 = zT_53->types_items;
    zT_55 = (unsigned int)t;
    zT_56 = zT_54[zT_55];
    tt = zT_56;
    goto z_bb_11;
    z_bb_11:
    zT_57 = st.kind;
    if ((int)(zT_57 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_63 = tt.kind;
    zT_62 = zT_63 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_14;
    z_bb_13:
    zT_62 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_62) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (int)(0);
    z_bb_16:
    zT_70 = self->registry;
    zT_71 = zT_70->fn_items;
    zT_72 = st.payload_idx;
    zT_73 = (unsigned int)zT_72;
    zT_74 = zT_71[zT_73];
    sfp = zT_74;
    zT_76 = self->registry;
    zT_77 = zT_76->fn_items;
    zT_78 = tt.payload_idx;
    zT_79 = (unsigned int)zT_78;
    zT_80 = zT_77[zT_79];
    tfp = zT_80;
    zT_81 = sfp.flags_packed;
    zT_84 = tfp.flags_packed;
    return (int)((unsigned char)(zT_81 & (unsigned char)(2)) != (unsigned char)(zT_84 & (unsigned char)(2)));
}

/* isBShapeMismatch */
int zF_D728034A_isBShapeMismatch(zT_38C12417_SemanticAnalyzer* self, unsigned int src_ty, unsigned int tgt_ty, int full) {
    int zT_6;
    zT_338B7C76_TypeRegistry* zT_11;
    unsigned int zT_12;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    int zT_36;
    int zT_42;
    int zT_47;
    int zT_57;
    int zT_67;
    int zT_77;
    zT_338B7C76_TypeRegistry* zT_78;
    unsigned int zT_79;
    int zT_81 = 0;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    if ((int)(src_ty == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_6 = tgt_ty == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_6) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    zT_11 = self->registry;
    zT_12 = zT_11->types_len;
    if ((int)((unsigned int)((unsigned int)src_ty) >= zT_12)) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    zT_14 = (unsigned int)((unsigned int)tgt_ty) >= zT_17;
    goto z_bb_8;
    z_bb_7:
    zT_14 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_14) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = (unsigned int)src_ty;
    zT_24 = zT_22[zT_23];
    zT_25 = zT_24.kind;
    sk = zT_25;
    zT_27 = self->registry;
    zT_28 = zT_27->types_items;
    zT_29 = (unsigned int)tgt_ty;
    zT_30 = zT_28[zT_29];
    zT_31 = zT_30.kind;
    tk = zT_31;
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_36 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_13;
    z_bb_12:
    zT_36 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_36) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (int)(1);
    z_bb_15:
    if (full) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_42 = sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_18;
    z_bb_17:
    zT_42 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_42) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_47 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_21;
    z_bb_20:
    zT_47 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_47) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (int)(1);
    z_bb_23:
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_57 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_26;
    z_bb_25:
    zT_57 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_57) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(1);
    z_bb_28:
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_67 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_31;
    z_bb_30:
    zT_67 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_67) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    return (int)(1);
    z_bb_33:
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_78 = self->registry;
    zT_79 = tgt_ty;
    zT_81 = zF_3290E9C4_typeRegistryIsInteg(zT_78, zT_79);
    zT_77 = zT_81;
    goto z_bb_36;
    z_bb_35:
    zT_77 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_77) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    return (int)(1);
    z_bb_38:
    return (int)(0);
}

/* semanticAnalyzerResolveFnBody */
void zF_406A2501_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int fn_decl_node) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_E2DF2801_LocalConstScope* zT_9;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_14 = {0};
    zT_8143F551_AstKind zT_15;
    zT_6B0A7D14_AstStore* zT_21;
    zT_4A7609CD_anon_224403 zT_23;
    zT_243D6A41_FnProto* zT_24;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int zT_28 = 0;
    unsigned int zT_29;
    zT_243D6A41_FnProto zT_30;
    zT_8EED1867_ResolvedTypeTable* zT_32;
    unsigned int zT_33;
    zT_BAEE192E_Opt_10 zT_35 = {0};
    unsigned char zT_36;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    zT_338B7C76_TypeRegistry* zT_43;
    zT_D155D06D_Type* zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_0317B1D5_FnPayload* zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_0317B1D5_FnPayload zT_57;
    unsigned char zT_58;
    int zT_63;
    unsigned char zT_64;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_F85C5DED_DiagnosticCollector* zT_73;
    unsigned int zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int zT_92 = 0;
    unsigned int zT_93;
    unsigned short zT_96;
    unsigned int zT_100;
    unsigned short zT_104;
    zT_79FAE712_u64 zT_106;
    zT_6B0A7D14_AstStore* zT_108;
    zT_79FAE712_u64 zT_109;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_110 = {0};
    unsigned int zT_112;
    unsigned int zT_114;
    zT_6B0A7D14_AstStore* zT_117;
    unsigned int zT_118;
    unsigned int* zT_119;
    zT_22A7C88B_AstNode zT_121 = {0};
    unsigned int zT_122;
    unsigned int zT_125;
    unsigned int zT_126;
    zT_38C12417_SemanticAnalyzer* zT_128;
    zT_6B0A7D14_AstStore* zT_129;
    unsigned int zT_130;
    unsigned int* zT_131;
    unsigned int zT_133 = 0;
    unsigned int* zT_134;
    unsigned int zT_135;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_143;
    unsigned int* zT_144;
    unsigned int zT_146 = 0;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    zT_8EED1867_ResolvedTypeTable* zT_155;
    unsigned int zT_156;
    zT_BAEE192E_Opt_10 zT_159 = {0};
    unsigned char zT_160;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167;
    unsigned int* zT_168;
    unsigned int zT_169;
    unsigned char* zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175;
    unsigned int* zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_182;
    zT_8EED1867_ResolvedTypeTable* zT_184;
    unsigned int zT_185;
    zT_BAEE192E_Opt_10 zT_188 = {0};
    unsigned char zT_189;
    unsigned int zT_191;
    zT_38C12417_SemanticAnalyzer* zT_192;
    unsigned int zT_193;
    zT_38C12417_SemanticAnalyzer* zT_196;
    unsigned int zT_197;
    int zT_199 = 0;
    int zT_200;
    zT_38C12417_SemanticAnalyzer* zT_201;
    unsigned int zT_202;
    int zT_204 = 0;
    unsigned int zT_207;
    unsigned int zT_209;
    unsigned int zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_F85C5DED_DiagnosticCollector* zT_216;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned int zT_227 = 0;
    zT_21D3708C_U32ToU32Map* zT_229;
    unsigned int zT_230;
    zT_21D3708C_U32ToU32Map* zT_232;
    unsigned int zT_233;
    unsigned char* zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u fb;
    zT_22A7C88B_AstNode decl;
    zT_6B0A7D14_AstStore* store;
    zT_243D6A41_FnProto proto;
    zT_BAEE192E_Opt_10 vsc_tt;
    unsigned int vsc_tid;
    zT_D155D06D_Type vsc_ty;
    zT_0317B1D5_FnPayload vsc_fp;
    zT_8F083A69_Slice_zT_0B42B2F8_u vs_msg;
    zT_79FAE712_u64 p_payload;
    zT_3CB0179A_Slice_zT_05F374B1_u pnodes;
    unsigned int pi;
    zT_BAEE192E_Opt_10 fn_rt;
    zT_22A7C88B_AstNode pnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rta_m;
    zT_BAEE192E_Opt_10 rt;
    unsigned int t;
    zT_8F083A69_Slice_zT_0B42B2F8_u rth_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtm2;
    unsigned int frt;
    unsigned int mrsp;
    unsigned int mrep;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr_msg;
    unsigned int evcap;
    unsigned int evcnt;
    zT_8F083A69_Slice_zT_0B42B2F8_u vm;
    zT_8F083A69_Slice_zT_0B42B2F8_u vcm;
    zT_3 = "FB";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    fb = zT_4;
    zT_6 = fb;
    zF_48AC7B3A_markerWrite(zT_6);
    self->local_decl_count = (unsigned int)(0);
    zT_9 = &self->local_consts;
    zT_9->count = (unsigned int)(0);
    zT_11 = self->store;
    zT_12 = fn_decl_node;
    zT_14 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    decl = zT_14;
    zT_15 = decl.kind;
    if ((int)(zT_15 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_21 = self->store;
    store = zT_21;
    zT_23 = store->fn_protos;
    zT_24 = zT_23.items;
    zT_25 = self->store;
    zT_26 = fn_decl_node;
    zT_28 = zF_8BA26B9E_astStoreNodePayload(zT_25, zT_26);
    zT_29 = (unsigned int)zT_28;
    zT_30 = zT_24[zT_29];
    proto = zT_30;
    zT_32 = self->type_table;
    zT_33 = fn_decl_node;
    zT_35 = zF_999DCF51_resolvedTypeTableGe(zT_32, zT_33);
    vsc_tt = zT_35;
    zT_36 = vsc_tt.has_value;
    if (zT_36) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    vsc_tid = vsc_tt.value;
    zT_39 = self->registry;
    zT_40 = zT_39->types_len;
    if ((int)((unsigned int)((unsigned int)vsc_tid) < zT_40)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_93 = decl.child_0;
    if ((int)(zT_93 == (unsigned int)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_5:
    zT_43 = self->registry;
    zT_44 = zT_43->types_items;
    zT_45 = (unsigned int)vsc_tid;
    zT_46 = zT_44[zT_45];
    vsc_ty = zT_46;
    zT_47 = vsc_ty.kind;
    if ((int)(zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_53 = self->registry;
    zT_54 = zT_53->fn_items;
    zT_55 = vsc_ty.payload_idx;
    zT_56 = (unsigned int)zT_55;
    zT_57 = zT_54[zT_56];
    vsc_fp = zT_57;
    zT_58 = vsc_fp.flags_packed;
    if ((int)((unsigned char)(zT_58 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_64 = vsc_fp.flags_packed;
    zT_63 = (unsigned char)(zT_64 & (unsigned char)(2)) != (unsigned char)(0);
    goto z_bb_11;
    z_bb_10:
    zT_63 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_63) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_70 = "variadic functions cannot use the stdcall calling convention";
    zT_72 = 60;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    vs_msg = zT_71;
    zT_73 = self->diag;
    zT_76 = self->source_file_id;
    zT_77 = decl.span_start;
    zT_88 = decl.span_start;
    zT_89 = decl.span_len;
    zT_79 = vs_msg;
    zT_92 = zF_C82559AC_diagnosticCollector(zT_73, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3012_VARARGS_INVALID)), zT_76, zT_77, (unsigned int)(zT_88 + (unsigned int)((unsigned int)zT_89)), zT_79);
    (void)zT_92;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_8;
    z_bb_14:
    return;
    z_bb_15:
    zT_96 = proto.params_count;
    if ((int)(zT_96 > (unsigned short)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_100 = proto.params_start;
    zT_104 = proto.params_count;
    zT_106 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_100) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_104);
    p_payload = zT_106;
    zT_108 = store;
    zT_109 = p_payload;
    zT_110 = zF_3EAD7B21_astStoreGetExtraChi(zT_108, zT_109);
    pnodes = zT_110;
    zT_112 = 0;
    pi = zT_112;
    goto z_bb_18;
    z_bb_17:
    zT_184 = self->type_table;
    zT_185 = proto.return_type_node;
    zT_188 = zF_999DCF51_resolvedTypeTableGe(zT_184, zT_185);
    fn_rt = zT_188;
    zT_189 = fn_rt.has_value;
    if (zT_189) goto z_bb_29; else goto z_bb_30;
    z_bb_18:
    zT_114 = pnodes.len;
    if ((int)(pi < zT_114)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_117 = store;
    zT_119 = pnodes.ptr;
    zT_118 = zT_119[pi];
    zT_121 = zF_FCDD1D35_astStoreNodeAt(zT_117, zT_118);
    pnode = zT_121;
    zT_122 = pnode.child_0;
    if ((int)(zT_122 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_182 = pi + (unsigned int)(1);
    pi = zT_182;
    goto z_bb_18;
    z_bb_22:
    zT_125 = self->local_decl_count;
    zT_126 = self->local_decl_cap;
    if ((int)(zT_125 >= zT_126)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_128 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_128);
    goto z_bb_25;
    z_bb_25:
    zT_129 = store;
    zT_131 = pnodes.ptr;
    zT_130 = zT_131[pi];
    zT_133 = zF_8BA26B9E_astStoreNodePayload(zT_129, zT_130);
    zT_134 = self->local_decl_names;
    zT_135 = self->local_decl_count;
    zT_134[zT_135] = zT_133;
    zT_137 = "RT:P";
    zT_139 = 4;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    rtp_m = zT_138;
    zT_140 = rtp_m;
    zT_142 = store;
    zT_144 = pnodes.ptr;
    zT_143 = zT_144[pi];
    zT_146 = zF_8BA26B9E_astStoreNodePayload(zT_142, zT_143);
    zT_141 = zT_146;
    zF_C914CB83_markerWriteInt(zT_140, zT_141);
    zT_148 = "RT:A";
    zT_150 = 4;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    rta_m = zT_149;
    zT_151 = rta_m;
    zT_152 = pnode.child_0;
    zF_C914CB83_markerWriteInt(zT_151, zT_152);
    zT_155 = self->type_table;
    zT_156 = pnode.child_0;
    zT_159 = zF_999DCF51_resolvedTypeTableGe(zT_155, zT_156);
    rt = zT_159;
    zT_160 = rt.has_value;
    if (zT_160) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    t = rt.value;
    zT_163 = "RT:T";
    zT_165 = 4;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    rth_m = zT_164;
    zT_166 = rth_m;
    zT_167 = t;
    zF_C914CB83_markerWriteInt(zT_166, zT_167);
    zT_168 = self->local_decl_types;
    zT_169 = self->local_decl_count;
    zT_168[zT_169] = t;
    goto z_bb_27;
    z_bb_27:
    zT_178 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_178 + (unsigned int)(1));
    goto z_bb_23;
    z_bb_28:
    zT_171 = "RT:M\n";
    zT_173 = 5;
    zT_172.ptr = zT_171;
    zT_172.len = zT_173;
    rtm2 = zT_172;
    zT_174 = rtm2;
    zF_48AC7B3A_markerWrite(zT_174);
    zT_175 = 18;
    zT_176 = self->local_decl_types;
    zT_177 = self->local_decl_count;
    zT_176[zT_177] = zT_175;
    goto z_bb_27;
    z_bb_29:
    frt = fn_rt.value;
    self->current_fn_return = frt;
    goto z_bb_30;
    z_bb_30:
    zT_191 = proto.name_id;
    self->current_fn_name = zT_191;
    zT_192 = self;
    zT_193 = decl.child_0;
    zF_979B6CFF_semanticAnalyzerRes(zT_192, zT_193);
    self->current_fn_name = (unsigned int)(0);
    zT_196 = self;
    zT_197 = self->current_fn_return;
    zT_199 = zF_15CE7BE8_fnReturnRequiresVal(zT_196, zT_197);
    if (zT_199) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_201 = self;
    zT_202 = decl.child_0;
    zT_204 = zF_AA164297_astTerminates(zT_201, zT_202);
    zT_200 = !zT_204;
    goto z_bb_33;
    z_bb_32:
    zT_200 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_200) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_207 = decl.span_start;
    mrsp = zT_207;
    zT_209 = decl.span_len;
    zT_211 = mrsp + (unsigned int)((unsigned int)zT_209);
    mrep = zT_211;
    zT_213 = "missing return: not all control paths return a value";
    zT_215 = 52;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    mr_msg = zT_214;
    zT_216 = self->diag;
    zT_219 = self->source_file_id;
    zT_220 = mrsp;
    zT_221 = mrep;
    zT_222 = mr_msg;
    zT_227 = zF_C82559AC_diagnosticCollector(zT_216, (unsigned char)(0), (unsigned short)(3003), zT_219, zT_220, zT_221, zT_222);
    (void)zT_227;
    goto z_bb_35;
    z_bb_35:
    zT_229 = self->enum_value_table;
    zT_230 = zT_229->capacity;
    evcap = zT_230;
    zT_232 = self->enum_value_table;
    zT_233 = zT_232->count;
    evcnt = zT_233;
    zT_235 = "EVC:N";
    zT_237 = 5;
    zT_236.ptr = zT_235;
    zT_236.len = zT_237;
    vm = zT_236;
    zT_238 = vm;
    zF_C914CB83_markerWriteInt(zT_238, (unsigned int)((unsigned int)evcnt));
    zT_242 = "EVC:C";
    zT_244 = 5;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    vcm = zT_243;
    zT_245 = vcm;
    zF_C914CB83_markerWriteInt(zT_245, (unsigned int)((unsigned int)evcap));
    return;
}

/* fnReturnRequiresValue */
int zF_15CE7BE8_fnReturnRequiresVal(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    int zT_4;
    int zT_7;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    zT_338B7C76_TypeRegistry* zT_17;
    zT_D155D06D_Type* zT_18;
    unsigned int zT_19;
    zT_D155D06D_Type zT_20;
    zT_33EF6BFB_TypeKind zT_21;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_42C2D6BF_EUPayload* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_42C2D6BF_EUPayload zT_31;
    unsigned int zT_32;
    zT_33EF6BFB_TypeKind zT_36;
    zT_338B7C76_TypeRegistry* zT_42;
    zT_0B10E8E9_OptionalPayload* zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_0B10E8E9_OptionalPayload zT_46;
    unsigned int zT_47;
    zT_D155D06D_Type t;
    zT_42C2D6BF_EUPayload eu;
    zT_0B10E8E9_OptionalPayload op;
    if ((int)(ty == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = ty == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = ty == (unsigned int)(3);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_7) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_12 = self->registry;
    zT_13 = zT_12->types_len;
    if ((int)((unsigned int)((unsigned int)ty) >= zT_13)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    zT_17 = self->registry;
    zT_18 = zT_17->types_items;
    zT_19 = (unsigned int)ty;
    zT_20 = zT_18[zT_19];
    t = zT_20;
    zT_21 = t.kind;
    if ((int)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_27 = self->registry;
    zT_28 = zT_27->eu_items;
    zT_29 = t.payload_idx;
    zT_30 = (unsigned int)zT_29;
    zT_31 = zT_28[zT_30];
    eu = zT_31;
    zT_32 = eu.payload;
    if ((int)(zT_32 == (unsigned int)(1))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    zT_36 = t.kind;
    if ((int)(zT_36 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_42 = self->registry;
    zT_43 = zT_42->opt_items;
    zT_44 = t.payload_idx;
    zT_45 = (unsigned int)zT_44;
    zT_46 = zT_43[zT_45];
    op = zT_46;
    zT_47 = op.payload;
    if ((int)(zT_47 == (unsigned int)(1))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    return (int)(1);
    z_bb_17:
    return (int)(0);
    z_bb_18:
    goto z_bb_16;
}

/* astTerminates */
int zF_AA164297_astTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_8EED1867_ResolvedTypeTable* zT_16;
    unsigned int zT_17;
    zT_BAEE192E_Opt_10 zT_19 = {0};
    unsigned char zT_20;
    zT_8143F551_AstKind zT_25;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_34 = {0};
    unsigned int zT_36;
    unsigned int zT_38;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_44 = 0;
    int zT_46;
    unsigned int zT_47;
    zT_8143F551_AstKind zT_49;
    int zT_54;
    zT_8143F551_AstKind zT_55;
    unsigned int zT_60;
    zT_38C12417_SemanticAnalyzer* zT_64;
    unsigned int zT_65;
    int zT_67 = 0;
    int zT_68;
    zT_38C12417_SemanticAnalyzer* zT_69;
    unsigned int zT_70;
    int zT_72 = 0;
    zT_8143F551_AstKind zT_73;
    unsigned int zT_78;
    zT_38C12417_SemanticAnalyzer* zT_82;
    unsigned int zT_84;
    zT_8143F551_AstKind zT_86;
    zT_38C12417_SemanticAnalyzer* zT_91;
    unsigned int zT_92;
    int zT_93 = 0;
    zT_8143F551_AstKind zT_94;
    zT_38C12417_SemanticAnalyzer* zT_99;
    unsigned int zT_100;
    int zT_101 = 0;
    zT_8143F551_AstKind zT_102;
    unsigned int zT_107;
    zT_38C12417_SemanticAnalyzer* zT_111;
    unsigned int zT_113;
    zT_8143F551_AstKind zT_115;
    int zT_120;
    zT_8143F551_AstKind zT_121;
    int zT_126;
    zT_8143F551_AstKind zT_127;
    int zT_132;
    zT_8143F551_AstKind zT_133;
    int zT_138;
    zT_8143F551_AstKind zT_139;
    int zT_144;
    zT_8143F551_AstKind zT_145;
    int zT_150;
    zT_8143F551_AstKind zT_151;
    int zT_156;
    zT_8143F551_AstKind zT_157;
    int zT_162;
    zT_8143F551_AstKind zT_163;
    int zT_168;
    zT_8143F551_AstKind zT_169;
    int zT_174;
    zT_8143F551_AstKind zT_175;
    int zT_180;
    zT_8143F551_AstKind zT_181;
    int zT_186;
    zT_8143F551_AstKind zT_187;
    int zT_192;
    zT_8143F551_AstKind zT_193;
    int zT_198;
    zT_8143F551_AstKind zT_199;
    int zT_204;
    zT_8143F551_AstKind zT_205;
    int zT_210;
    zT_8143F551_AstKind zT_211;
    int zT_216;
    zT_8143F551_AstKind zT_217;
    unsigned int zT_222;
    zT_38C12417_SemanticAnalyzer* zT_226;
    unsigned int zT_228;
    zT_22A7C88B_AstNode node;
    unsigned int t;
    zT_3CB0179A_Slice_zT_05F374B1_u ch;
    unsigned int bi;
    z_bb_0:
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((int)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_16 = self->type_table;
    zT_17 = node_idx;
    zT_19 = zF_999DCF51_resolvedTypeTableGe(zT_16, zT_17);
    zT_20 = zT_19.has_value;
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    t = zT_19.value;
    if ((int)(t == (unsigned int)(3))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_25 = node.kind;
    if ((int)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return (int)(1);
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_31 = self->store;
    zT_32 = node_idx;
    zT_34 = zF_850FDF81_astStoreNodeExtraCh(zT_31, zT_32);
    ch = zT_34;
    zT_36 = 0;
    bi = zT_36;
    goto z_bb_11;
    z_bb_10:
    zT_49 = node.kind;
    if ((int)(zT_49 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    zT_38 = ch.len;
    if ((int)(bi < zT_38)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_40 = self;
    zT_42 = ch.ptr;
    zT_41 = zT_42[bi];
    zT_44 = zF_AA164297_astTerminates(zT_40, zT_41);
    if (zT_44) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    return (int)(0);
    z_bb_14:
    zT_46 = 1;
    zT_47 = bi + zT_46;
    bi = zT_47;
    goto z_bb_11;
    z_bb_15:
    return (int)(1);
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_55 = node.kind;
    zT_54 = zT_55 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr);
    goto z_bb_19;
    z_bb_18:
    zT_54 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_54) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_60 = node.child_2;
    if ((int)(zT_60 == (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_73 = node.kind;
    if ((int)(zT_73 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_expr_stmt))) goto z_bb_27; else goto z_bb_28;
    z_bb_22:
    return (int)(0);
    z_bb_23:
    zT_64 = self;
    zT_65 = node.child_1;
    zT_67 = zF_AA164297_astTerminates(zT_64, zT_65);
    if (zT_67) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_69 = self;
    zT_70 = node.child_2;
    zT_72 = zF_AA164297_astTerminates(zT_69, zT_70);
    zT_68 = zT_72;
    goto z_bb_26;
    z_bb_25:
    zT_68 = 0;
    goto z_bb_26;
    z_bb_26:
    return zT_68;
    z_bb_27:
    zT_78 = node.child_0;
    if ((int)(zT_78 == (unsigned int)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_86 = node.kind;
    if ((int)(zT_86 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_swt_ex))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return (int)(0);
    z_bb_30:
    zT_82 = self;
    zT_84 = node.child_0;
    self = zT_82;
    node_idx = zT_84;
    goto z_bb_0;
    z_bb_31:
    zT_91 = self;
    zT_92 = node_idx;
    zT_93 = zF_A3A1FD27_astSwitchTerminates(zT_91, zT_92);
    return zT_93;
    z_bb_32:
    zT_94 = node.kind;
    if ((int)(zT_94 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_99 = self;
    zT_100 = node_idx;
    zT_101 = zF_FB2132D0_astWhileTerminates(zT_99, zT_100);
    return zT_101;
    z_bb_34:
    zT_102 = node.kind;
    if ((int)(zT_102 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_107 = node.child_1;
    if ((int)(zT_107 == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_115 = node.kind;
    if ((int)(zT_115 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_40; else goto z_bb_39;
    z_bb_37:
    return (int)(0);
    z_bb_38:
    zT_111 = self;
    zT_113 = node.child_1;
    self = zT_111;
    node_idx = zT_113;
    goto z_bb_0;
    z_bb_39:
    zT_121 = node.kind;
    zT_120 = zT_121 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_41;
    z_bb_40:
    zT_120 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_120) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_127 = node.kind;
    zT_126 = zT_127 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_44;
    z_bb_43:
    zT_126 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_126) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_133 = node.kind;
    zT_132 = zT_133 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_47;
    z_bb_46:
    zT_132 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_132) goto z_bb_49; else goto z_bb_48;
    z_bb_48:
    zT_139 = node.kind;
    zT_138 = zT_139 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_50;
    z_bb_49:
    zT_138 = 1;
    goto z_bb_50;
    z_bb_50:
    if (zT_138) goto z_bb_52; else goto z_bb_51;
    z_bb_51:
    zT_145 = node.kind;
    zT_144 = zT_145 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_53;
    z_bb_52:
    zT_144 = 1;
    goto z_bb_53;
    z_bb_53:
    if (zT_144) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_151 = node.kind;
    zT_150 = zT_151 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_56;
    z_bb_55:
    zT_150 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_150) goto z_bb_58; else goto z_bb_57;
    z_bb_57:
    zT_157 = node.kind;
    zT_156 = zT_157 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_59;
    z_bb_58:
    zT_156 = 1;
    goto z_bb_59;
    z_bb_59:
    if (zT_156) goto z_bb_61; else goto z_bb_60;
    z_bb_60:
    zT_163 = node.kind;
    zT_162 = zT_163 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_62;
    z_bb_61:
    zT_162 = 1;
    goto z_bb_62;
    z_bb_62:
    if (zT_162) goto z_bb_64; else goto z_bb_63;
    z_bb_63:
    zT_169 = node.kind;
    zT_168 = zT_169 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_65;
    z_bb_64:
    zT_168 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_168) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_175 = node.kind;
    zT_174 = zT_175 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_68;
    z_bb_67:
    zT_174 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_174) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_181 = node.kind;
    zT_180 = zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_71;
    z_bb_70:
    zT_180 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_180) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_187 = node.kind;
    zT_186 = zT_187 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_74;
    z_bb_73:
    zT_186 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_186) goto z_bb_76; else goto z_bb_75;
    z_bb_75:
    zT_193 = node.kind;
    zT_192 = zT_193 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_77;
    z_bb_76:
    zT_192 = 1;
    goto z_bb_77;
    z_bb_77:
    if (zT_192) goto z_bb_79; else goto z_bb_78;
    z_bb_78:
    zT_199 = node.kind;
    zT_198 = zT_199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_80;
    z_bb_79:
    zT_198 = 1;
    goto z_bb_80;
    z_bb_80:
    if (zT_198) goto z_bb_82; else goto z_bb_81;
    z_bb_81:
    zT_205 = node.kind;
    zT_204 = zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_83;
    z_bb_82:
    zT_204 = 1;
    goto z_bb_83;
    z_bb_83:
    if (zT_204) goto z_bb_85; else goto z_bb_84;
    z_bb_84:
    zT_211 = node.kind;
    zT_210 = zT_211 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_86;
    z_bb_85:
    zT_210 = 1;
    goto z_bb_86;
    z_bb_86:
    if (zT_210) goto z_bb_88; else goto z_bb_87;
    z_bb_87:
    zT_217 = node.kind;
    zT_216 = zT_217 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_89;
    z_bb_88:
    zT_216 = 1;
    goto z_bb_89;
    z_bb_89:
    if (zT_216) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_222 = node.child_1;
    if ((int)(zT_222 == (unsigned int)(0))) goto z_bb_92; else goto z_bb_93;
    z_bb_91:
    return (int)(0);
    z_bb_92:
    return (int)(0);
    z_bb_93:
    zT_226 = self;
    zT_228 = node.child_1;
    self = zT_226;
    node_idx = zT_228;
    goto z_bb_0;
}

/* astSwitchTerminates */
int zF_A3A1FD27_astSwitchTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_11 = {0};
    unsigned int zT_13;
    int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    unsigned int* zT_28;
    zT_22A7C88B_AstNode zT_30 = {0};
    unsigned char zT_31;
    int zT_36;
    zT_38C12417_SemanticAnalyzer* zT_37;
    unsigned int zT_38;
    int zT_40 = 0;
    int zT_43;
    unsigned int zT_44;
    zT_38C12417_SemanticAnalyzer* zT_46;
    unsigned int zT_47;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_48;
    int zT_50 = 0;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u prongs;
    int has_else;
    unsigned int pi;
    zT_22A7C88B_AstNode pr;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->store;
    zT_9 = node_idx;
    zT_11 = zF_850FDF81_astStoreNodeExtraCh(zT_8, zT_9);
    prongs = zT_11;
    zT_13 = prongs.len;
    if ((int)(zT_13 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_18 = 0;
    has_else = zT_18;
    zT_20 = 0;
    pi = zT_20;
    goto z_bb_3;
    z_bb_3:
    zT_22 = prongs.len;
    if ((int)(pi < zT_22)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_25 = self->store;
    zT_28 = prongs.ptr;
    zT_26 = zT_28[pi];
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_25, zT_26);
    pr = zT_30;
    zT_31 = pr.flags;
    if ((int)((unsigned char)(zT_31 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    if (has_else) goto z_bb_11; else goto z_bb_12;
    z_bb_6:
    zT_43 = 1;
    zT_44 = pi + zT_43;
    pi = zT_44;
    goto z_bb_3;
    z_bb_7:
    zT_36 = 1;
    has_else = zT_36;
    goto z_bb_8;
    z_bb_8:
    zT_37 = self;
    zT_38 = pr.child_0;
    zT_40 = zF_AA164297_astTerminates(zT_37, zT_38);
    if ((int)(!zT_40)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (int)(0);
    z_bb_10:
    goto z_bb_6;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_46 = self;
    zT_47 = node.child_0;
    zT_48 = prongs;
    zT_50 = zF_DCF9800F_astSwitchExhaustive(zT_46, zT_47, zT_48);
    return zT_50;
}

/* astSwitchExhaustive */
int zF_DCF9800F_astSwitchExhaustive(zT_38C12417_SemanticAnalyzer* self, unsigned int cond_idx, zT_3CB0179A_Slice_zT_05F374B1_u prongs) {
    zT_8EED1867_ResolvedTypeTable* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_9;
    int zT_14;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_D155D06D_Type* zT_22;
    unsigned int zT_23;
    zT_D155D06D_Type zT_24;
    unsigned int zT_26;
    zT_33EF6BFB_TypeKind zT_27;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_457ECFEE_EnumPayload* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_457ECFEE_EnumPayload zT_36;
    unsigned short zT_37;
    unsigned int zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    zT_338B7C76_TypeRegistry* zT_44;
    zT_54FF90FA_TaggedUnionPayload* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_54FF90FA_TaggedUnionPayload zT_48;
    unsigned short zT_49;
    unsigned int zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    zT_338B7C76_TypeRegistry* zT_56;
    zT_0B73C507_ErrorSetPayload* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    zT_0B73C507_ErrorSetPayload zT_60;
    unsigned short zT_61;
    unsigned int zT_62;
    zT_33EF6BFB_TypeKind zT_63;
    unsigned int zT_68;
    unsigned int zT_71;
    unsigned int zT_73;
    unsigned int zT_75;
    zT_6B0A7D14_AstStore* zT_78;
    unsigned int zT_79;
    unsigned int* zT_81;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_83 = {0};
    unsigned int zT_85;
    unsigned int zT_87;
    int zT_88;
    unsigned int zT_89;
    unsigned int ct;
    zT_D155D06D_Type ty;
    unsigned int member_count;
    unsigned int covered;
    unsigned int pi;
    zT_3CB0179A_Slice_zT_05F374B1_u items;
    zT_4 = self->type_table;
    zT_5 = cond_idx;
    zT_7 = zF_999DCF51_resolvedTypeTableGe(zT_4, zT_5);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_9 = zT_7.value;
    goto z_bb_3;
    z_bb_3:
    ct = zT_9;
    if ((int)(ct == (unsigned int)(0))) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_16 = self->registry;
    zT_17 = zT_16->types_len;
    zT_14 = (unsigned int)((unsigned int)ct) >= zT_17;
    goto z_bb_6;
    z_bb_5:
    zT_14 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_14) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_21 = self->registry;
    zT_22 = zT_21->types_items;
    zT_23 = (unsigned int)ct;
    zT_24 = zT_22[zT_23];
    ty = zT_24;
    zT_26 = 0;
    member_count = zT_26;
    zT_27 = ty.kind;
    if ((int)(zT_27 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_32 = self->registry;
    zT_33 = zT_32->en_items;
    zT_34 = ty.payload_idx;
    zT_35 = (unsigned int)zT_34;
    zT_36 = zT_33[zT_35];
    zT_37 = zT_36.members_count;
    zT_38 = (unsigned int)zT_37;
    member_count = zT_38;
    goto z_bb_10;
    z_bb_10:
    zT_71 = 0;
    covered = zT_71;
    zT_73 = 0;
    pi = zT_73;
    goto z_bb_21;
    z_bb_11:
    zT_39 = ty.kind;
    if ((int)(zT_39 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_44 = self->registry;
    zT_45 = zT_44->tu_items;
    zT_46 = ty.payload_idx;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zT_45[zT_47];
    zT_49 = zT_48.fields_count;
    zT_50 = (unsigned int)zT_49;
    member_count = zT_50;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_51 = ty.kind;
    if ((int)(zT_51 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_56 = self->registry;
    zT_57 = zT_56->es_items;
    zT_58 = ty.payload_idx;
    zT_59 = (unsigned int)zT_58;
    zT_60 = zT_57[zT_59];
    zT_61 = zT_60.tags_count;
    zT_62 = (unsigned int)zT_61;
    member_count = zT_62;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_63 = ty.kind;
    if ((int)(zT_63 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_68 = 2;
    member_count = zT_68;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    return (int)(0);
    z_bb_21:
    zT_75 = prongs.len;
    if ((int)(pi < zT_75)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_78 = self->store;
    zT_81 = prongs.ptr;
    zT_79 = zT_81[pi];
    zT_83 = zF_850FDF81_astStoreNodeExtraCh(zT_78, zT_79);
    items = zT_83;
    zT_85 = items.len;
    zT_87 = covered + (unsigned int)((unsigned int)zT_85);
    covered = zT_87;
    goto z_bb_24;
    z_bb_23:
    return (int)(covered >= member_count);
    z_bb_24:
    zT_88 = 1;
    zT_89 = pi + zT_88;
    pi = zT_89;
    goto z_bb_21;
}

/* astWhileTerminates */
int zF_FB2132D0_astWhileTerminates(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_20 = {0};
    zT_8143F551_AstKind zT_21;
    unsigned char zT_27;
    zT_38C12417_SemanticAnalyzer* zT_33;
    unsigned int zT_34;
    int zT_36 = 0;
    zT_38C12417_SemanticAnalyzer* zT_38;
    unsigned int zT_39;
    int zT_41 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode cond;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_0;
    if ((int)(zT_7 == (unsigned int)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11 = node.child_1;
    zT_10 = zT_11 == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_10 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (int)(0);
    z_bb_5:
    zT_16 = self->store;
    zT_17 = node.child_0;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    cond = zT_20;
    zT_21 = cond.kind;
    if ((int)(zT_21 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (int)(0);
    z_bb_7:
    zT_27 = cond.flags;
    if ((int)((unsigned char)(zT_27 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (int)(0);
    z_bb_9:
    zT_33 = self;
    zT_34 = node.child_1;
    zT_36 = zF_B5177CCC_astSubtreeHasBreak(zT_33, zT_34);
    if (zT_36) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (int)(0);
    z_bb_11:
    zT_38 = self;
    zT_39 = node.child_1;
    zT_41 = zF_AA164297_astTerminates(zT_38, zT_39);
    return zT_41;
}

/* astSubtreeHasBreak */
int zF_B5177CCC_astSubtreeHasBreak(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned int zT_16;
    int zT_19;
    zT_8143F551_AstKind zT_20;
    int zT_24 = 0;
    int zT_25;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    int zT_29 = 0;
    unsigned int zT_31;
    int zT_34;
    zT_8143F551_AstKind zT_35;
    int zT_39 = 0;
    int zT_40;
    zT_38C12417_SemanticAnalyzer* zT_41;
    unsigned int zT_42;
    int zT_44 = 0;
    unsigned int zT_46;
    int zT_49;
    zT_8143F551_AstKind zT_50;
    int zT_54 = 0;
    int zT_55;
    zT_38C12417_SemanticAnalyzer* zT_56;
    unsigned int zT_57;
    int zT_59 = 0;
    zT_8143F551_AstKind zT_61;
    int zT_63 = 0;
    int zT_64;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    unsigned int zT_68 = 0;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_75 = {0};
    unsigned int zT_77;
    unsigned int zT_79;
    zT_38C12417_SemanticAnalyzer* zT_81;
    unsigned int zT_82;
    unsigned int* zT_83;
    int zT_85 = 0;
    int zT_87;
    unsigned int zT_88;
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int ei;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_6 = self->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((int)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(1);
    z_bb_4:
    zT_16 = node.child_0;
    if ((int)(zT_16 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = node.kind;
    zT_24 = zF_C395F6FD_nodeChildIsNode(zT_20, (unsigned char)(0));
    zT_19 = zT_24;
    goto z_bb_7;
    z_bb_6:
    zT_19 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_19) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_26 = self;
    zT_27 = node.child_0;
    zT_29 = zF_B5177CCC_astSubtreeHasBreak(zT_26, zT_27);
    zT_25 = zT_29;
    goto z_bb_10;
    z_bb_9:
    zT_25 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_25) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    zT_31 = node.child_1;
    if ((int)(zT_31 != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = node.kind;
    zT_39 = zF_C395F6FD_nodeChildIsNode(zT_35, (unsigned char)(1));
    zT_34 = zT_39;
    goto z_bb_15;
    z_bb_14:
    zT_34 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_34) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_41 = self;
    zT_42 = node.child_1;
    zT_44 = zF_B5177CCC_astSubtreeHasBreak(zT_41, zT_42);
    zT_40 = zT_44;
    goto z_bb_18;
    z_bb_17:
    zT_40 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_40) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (int)(1);
    z_bb_20:
    zT_46 = node.child_2;
    if ((int)(zT_46 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_50 = node.kind;
    zT_54 = zF_C395F6FD_nodeChildIsNode(zT_50, (unsigned char)(2));
    zT_49 = zT_54;
    goto z_bb_23;
    z_bb_22:
    zT_49 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_49) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_56 = self;
    zT_57 = node.child_2;
    zT_59 = zF_B5177CCC_astSubtreeHasBreak(zT_56, zT_57);
    zT_55 = zT_59;
    goto z_bb_26;
    z_bb_25:
    zT_55 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_55) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (int)(1);
    z_bb_28:
    zT_61 = node.kind;
    zT_63 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_61);
    if (zT_63) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_65 = self->store;
    zT_66 = node_idx;
    zT_68 = zF_8BA26B9E_astStoreNodePayload(zT_65, zT_66);
    zT_64 = zT_68 != (unsigned int)(0);
    goto z_bb_31;
    z_bb_30:
    zT_64 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_64) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_72 = self->store;
    zT_73 = node_idx;
    zT_75 = zF_850FDF81_astStoreNodeExtraCh(zT_72, zT_73);
    ec = zT_75;
    zT_77 = 0;
    ei = zT_77;
    goto z_bb_34;
    z_bb_33:
    return (int)(0);
    z_bb_34:
    zT_79 = ec.len;
    if ((int)(ei < zT_79)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_81 = self;
    zT_83 = ec.ptr;
    zT_82 = zT_83[ei];
    zT_85 = zF_B5177CCC_astSubtreeHasBreak(zT_81, zT_82);
    if (zT_85) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_87 = 1;
    zT_88 = ei + zT_87;
    ei = zT_88;
    goto z_bb_34;
    z_bb_38:
    return (int)(1);
    z_bb_39:
    goto z_bb_37;
}

/* semanticAnalyzerStmtWorkPush */
void zF_7AB741D8_semanticAnalyzerStm(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_C6536882_EU_532 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->stmt_work_len;
    zT_3 = self->stmt_work_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->stmt_work_cap;
    if ((int)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->stmt_work_items;
    zT_38 = self->stmt_work_len;
    zT_37[zT_38] = node_idx;
    zT_39 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->stmt_work_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->stmt_work_len;
    if ((int)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->stmt_work_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->stmt_work_items = ndst;
    self->stmt_work_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* pushExpectedType */
void zF_9665A229_pushExpectedType(zT_38C12417_SemanticAnalyzer* self, unsigned int ty) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_15;
    zT_C6536882_EU_532 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned int* zT_27;
    int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* ndst;
    unsigned int ci;
    zT_2 = self->expected_type_stack_len;
    zT_3 = self->expected_type_stack_cap;
    if ((int)(zT_2 >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = self->expected_type_stack_cap;
    if ((int)(zT_6 < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_37 = self->expected_type_stack_items;
    zT_38 = self->expected_type_stack_len;
    zT_37[zT_38] = ty;
    zT_39 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_39 + (unsigned int)(1));
    return;
    z_bb_3:
    zT_9 = 64;
    goto z_bb_5;
    z_bb_4:
    zT_11 = self->expected_type_stack_cap;
    zT_9 = zT_11 * (unsigned int)(2);
    goto z_bb_5;
    z_bb_5:
    new_cap = zT_9;
    zT_15 = self->expected_type_stack_alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_15, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_24 = zT_22.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw = zT_24;
    zT_27 = (unsigned int*)raw;
    ndst = zT_27;
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    ci = zT_30;
    goto z_bb_9;
    z_bb_9:
    zT_31 = self->expected_type_stack_len;
    if ((int)(ci < zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = self->expected_type_stack_items;
    zT_34 = zT_33[ci];
    ndst[ci] = zT_34;
    goto z_bb_12;
    z_bb_11:
    self->expected_type_stack_items = ndst;
    self->expected_type_stack_cap = new_cap;
    goto z_bb_2;
    z_bb_12:
    zT_36 = ci + (unsigned int)(1);
    ci = zT_36;
    goto z_bb_9;
}

/* popExpectedType */
void zF_BC478E78_popExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int zT_4;
    zT_1 = self->expected_type_stack_len;
    if ((int)(zT_1 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self->expected_type_stack_len;
    self->expected_type_stack_len = (unsigned int)(zT_4 - (unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    return;
}

/* topExpectedType */
unsigned int zF_4DE7C2BC_topExpectedType(zT_38C12417_SemanticAnalyzer* self) {
    unsigned int zT_1;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_1 = self->expected_type_stack_len;
    if ((int)(zT_1 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_5 = self->expected_type_stack_items;
    zT_6 = self->expected_type_stack_len;
    zT_8 = zT_6 - (unsigned int)(1);
    zT_9 = zT_5[zT_8];
    return zT_9;
}

/* semanticAnalyzerResolveIfHeader */
void zF_0324C9A3_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_39 = 0;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_939EE900_Arr_unsigned_int_1 zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    int zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    int zT_59;
    zT_22A7C88B_AstNode zT_61 = {0};
    zT_8143F551_AstKind zT_62;
    unsigned int zT_63;
    int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    unsigned char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    int zT_77;
    unsigned char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    int zT_85;
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_939EE900_Arr_unsigned_int_1 zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_6B0A7D14_AstStore* zT_102;
    unsigned int zT_103;
    zT_22A7C88B_AstNode zT_106 = {0};
    zT_8143F551_AstKind zT_107;
    unsigned int zT_108;
    int zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    int zT_116;
    zT_22A7C88B_AstNode node;
    unsigned int icond_t;
    unsigned int icap_idx;
    zT_22A7C88B_AstNode icap_node;
    zT_939EE900_Arr_unsigned_int_1 ifs_b;
    zT_939EE900_Arr_unsigned_int_1 ifs_k;
    zT_22A7C88B_AstNode ifs_cn;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_cm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_c2m;
    zT_939EE900_Arr_unsigned_int_1 ifs_k2;
    zT_22A7C88B_AstNode ifs_cn2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ifst_k2m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self;
    zT_9 = node.child_0;
    zT_11 = zF_54F95822_semanticAnalyzerRes(zT_8, zT_9);
    icond_t = zT_11;
    zT_12 = self->store;
    zT_13 = node_idx;
    zT_15 = zF_8BA26B9E_astStoreNodePayload(zT_12, zT_13);
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->store;
    zT_20 = node_idx;
    zT_22 = zF_8BA26B9E_astStoreNodePayload(zT_19, zT_20);
    icap_idx = zT_22;
    zT_24 = self->store;
    zT_25 = icap_idx;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    icap_node = zT_27;
    zT_28 = icap_node.kind;
    if ((int)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_capture))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_45 = node.child_1;
    zT_46 = 0;
    zT_44[zT_46] = zT_45;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_b[_i] = zT_44[_i];
        _i++;
    }
}
    zT_49 = 0;
    zT_50 = 0;
    zT_48[zT_50] = zT_49;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k[_i] = zT_48[_i];
        _i++;
    }
}
    zT_51 = 0;
    zT_52 = ifs_b[zT_51];
    if ((int)(zT_52 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_33 = self;
    zT_36 = self->store;
    zT_37 = icap_idx;
    zT_39 = zF_8BA26B9E_astStoreNodePayload(zT_36, zT_37);
    zT_34 = zT_39;
    zT_40 = self;
    zT_41 = icond_t;
    zT_42 = zF_3E251D67_semanticAnalyzerCap(zT_40, zT_41);
    zT_35 = zT_42;
    zF_7BD72017_registerLocalDecl(zT_33, zT_34, zT_35);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_56 = self->store;
    zT_59 = 0;
    zT_57 = ifs_b[zT_59];
    zT_61 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    ifs_cn = zT_61;
    zT_62 = ifs_cn.kind;
    zT_63 = (unsigned int)zT_62;
    zT_64 = 0;
    ifs_k[zT_64] = zT_63;
    goto z_bb_6;
    z_bb_6:
    zT_66 = "IFST:N";
    zT_68 = 6;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    ifst_nm = zT_67;
    zT_69 = ifst_nm;
    zT_70 = node_idx;
    zF_C914CB83_markerWriteInt(zT_69, zT_70);
    zT_72 = "IFST:C";
    zT_74 = 6;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    ifst_cm = zT_73;
    zT_75 = ifst_cm;
    zT_77 = 0;
    zT_76 = ifs_b[zT_77];
    zF_C914CB83_markerWriteInt(zT_75, zT_76);
    zT_80 = "IFST:K";
    zT_82 = 6;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    ifst_km = zT_81;
    zT_83 = ifst_km;
    zT_85 = 0;
    zT_84 = ifs_k[zT_85];
    zF_C914CB83_markerWriteInt(zT_83, zT_84);
    zT_88 = "IFST:2";
    zT_90 = 6;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    ifst_c2m = zT_89;
    zT_91 = ifst_c2m;
    zT_92 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_91, zT_92);
    zT_96 = 0;
    zT_97 = 0;
    zT_95[zT_97] = zT_96;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        ifs_k2[_i] = zT_95[_i];
        _i++;
    }
}
    zT_98 = node.child_2;
    if ((int)(zT_98 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_102 = self->store;
    zT_103 = node.child_2;
    zT_106 = zF_FCDD1D35_astStoreNodeAt(zT_102, zT_103);
    ifs_cn2 = zT_106;
    zT_107 = ifs_cn2.kind;
    zT_108 = (unsigned int)zT_107;
    zT_109 = 0;
    ifs_k2[zT_109] = zT_108;
    goto z_bb_8;
    z_bb_8:
    zT_111 = "IFST:K2";
    zT_113 = 7;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    ifst_k2m = zT_112;
    zT_114 = ifst_k2m;
    zT_116 = 0;
    zT_115 = ifs_k2[zT_116];
    zF_C914CB83_markerWriteInt(zT_114, zT_115);
    return;
}

/* semanticAnalyzerResolveForHeader */
void zF_8CE01C41_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    zT_38C12417_SemanticAnalyzer* zT_7;
    unsigned int zT_8;
    unsigned int zT_10 = 0;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_8143F551_AstKind zT_30;
    zT_8EED1867_ResolvedTypeTable* zT_33;
    unsigned int zT_34;
    zT_BAEE192E_Opt_10 zT_37 = {0};
    unsigned char zT_38;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_338B7C76_TypeRegistry* zT_47;
    zT_D155D06D_Type* zT_48;
    unsigned int zT_49;
    zT_D155D06D_Type zT_50;
    zT_939EE900_Arr_unsigned_int_1 zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    zT_338B7C76_TypeRegistry* zT_60;
    zT_0BB2A741_SlicePayload* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    zT_0BB2A741_SlicePayload zT_64;
    unsigned int zT_65;
    int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_338B7C76_TypeRegistry* zT_72;
    zT_E834303C_ArrayPayload* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    zT_E834303C_ArrayPayload zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_8143F551_AstKind zT_79;
    int zT_84;
    zT_8143F551_AstKind zT_85;
    int zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    int zT_97;
    int zT_98;
    unsigned int zT_99;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned int zT_107;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_109;
    unsigned int zT_111 = 0;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    int zT_118;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_38C12417_SemanticAnalyzer* zT_123;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int zT_125;
    unsigned int zT_127 = 0;
    unsigned int* zT_128;
    unsigned int zT_129;
    int zT_130;
    unsigned int zT_131;
    unsigned int* zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_146 = 0;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    int zT_153;
    unsigned char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_38C12417_SemanticAnalyzer* zT_166;
    unsigned int zT_167;
    unsigned int* zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned int* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_c_m;
    zT_22A7C88B_AstNode cnode;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_ck_m;
    zT_BAEE192E_Opt_10 it_tid;
    unsigned int tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_tid_m;
    zT_D155D06D_Type ty;
    zT_939EE900_Arr_unsigned_int_1 elem_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u a5_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_p_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u fs_e_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u d4f_t;
    zT_8F083A69_Slice_zT_0B42B2F8_u f2_m;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = self;
    zT_8 = node.child_0;
    zT_10 = zF_54F95822_semanticAnalyzerRes(zT_7, zT_8);
    (void)zT_10;
    zT_12 = "FS:C";
    zT_14 = 4;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    fs_c_m = zT_13;
    zT_15 = fs_c_m;
    zT_16 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_19 = self->store;
    zT_20 = node.child_0;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    cnode = zT_23;
    zT_25 = "FS:CK";
    zT_27 = 5;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    fs_ck_m = zT_26;
    zT_28 = fs_ck_m;
    zT_30 = cnode.kind;
    zF_C914CB83_markerWriteInt(zT_28, (unsigned int)((unsigned int)zT_30));
    zT_33 = self->type_table;
    zT_34 = node.child_0;
    zT_37 = zF_999DCF51_resolvedTypeTableGe(zT_33, zT_34);
    it_tid = zT_37;
    zT_38 = it_tid.has_value;
    if (zT_38) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    tid = it_tid.value;
    zT_41 = "FS:T";
    zT_43 = 4;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    fs_tid_m = zT_42;
    zT_44 = fs_tid_m;
    zT_45 = tid;
    zF_C914CB83_markerWriteInt(zT_44, zT_45);
    zT_47 = self->registry;
    zT_48 = zT_47->types_items;
    zT_49 = (unsigned int)tid;
    zT_50 = zT_48[zT_49];
    ty = zT_50;
    zT_53 = 18;
    zT_54 = 0;
    zT_52[zT_54] = zT_53;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        elem_box[_i] = zT_52[_i];
        _i++;
    }
}
    zT_55 = ty.kind;
    if ((int)(zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    zT_160 = node.child_2;
    if ((int)(zT_160 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_3:
    zT_156 = "FS:M\n";
    zT_158 = 5;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    a5_m = zT_157;
    zT_159 = a5_m;
    zF_48AC7B3A_markerWrite(zT_159);
    goto z_bb_2;
    z_bb_4:
    zT_60 = self->registry;
    zT_61 = zT_60->slice_items;
    zT_62 = ty.payload_idx;
    zT_63 = (unsigned int)zT_62;
    zT_64 = zT_61[zT_63];
    zT_65 = zT_64.elem;
    zT_66 = 0;
    elem_box[zT_66] = zT_65;
    goto z_bb_5;
    z_bb_5:
    zT_91 = self->store;
    zT_92 = node_idx;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    if ((int)(zT_94 != (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_6:
    zT_67 = ty.kind;
    if ((int)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_72 = self->registry;
    zT_73 = zT_72->array_items;
    zT_74 = ty.payload_idx;
    zT_75 = (unsigned int)zT_74;
    zT_76 = zT_73[zT_75];
    zT_77 = zT_76.elem;
    zT_78 = 0;
    elem_box[zT_78] = zT_77;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_79 = cnode.kind;
    if ((int)(zT_79 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_exclusive))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_85 = cnode.kind;
    zT_84 = zT_85 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_range_inclusive);
    goto z_bb_12;
    z_bb_11:
    zT_84 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_84) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_90 = 0;
    elem_box[zT_90] = tid;
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    zT_98 = 0;
    zT_99 = elem_box[zT_98];
    zT_97 = zT_99 != (unsigned int)(18);
    goto z_bb_17;
    z_bb_16:
    zT_97 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_97) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_103 = "FS:P";
    zT_105 = 4;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    fs_p_m = zT_104;
    zT_106 = fs_p_m;
    zT_108 = self->store;
    zT_109 = node_idx;
    zT_111 = zF_8BA26B9E_astStoreNodePayload(zT_108, zT_109);
    zT_107 = zT_111;
    zF_C914CB83_markerWriteInt(zT_106, zT_107);
    zT_113 = "FS:E";
    zT_115 = 4;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    fs_e_m = zT_114;
    zT_116 = fs_e_m;
    zT_118 = 0;
    zT_117 = elem_box[zT_118];
    zF_C914CB83_markerWriteInt(zT_116, zT_117);
    zT_120 = self->local_decl_count;
    zT_121 = self->local_decl_cap;
    if ((int)(zT_120 >= zT_121)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_123 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_123);
    goto z_bb_21;
    z_bb_21:
    zT_124 = self->store;
    zT_125 = node_idx;
    zT_127 = zF_8BA26B9E_astStoreNodePayload(zT_124, zT_125);
    zT_128 = self->local_decl_names;
    zT_129 = self->local_decl_count;
    zT_128[zT_129] = zT_127;
    zT_130 = 0;
    zT_131 = elem_box[zT_130];
    zT_132 = self->local_decl_types;
    zT_133 = self->local_decl_count;
    zT_132[zT_133] = zT_131;
    zT_134 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_134 + (unsigned int)(1));
    zT_138 = "D4F:N";
    zT_140 = 5;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    d4f_n = zT_139;
    zT_141 = d4f_n;
    zT_143 = self->store;
    zT_144 = node_idx;
    zT_146 = zF_8BA26B9E_astStoreNodePayload(zT_143, zT_144);
    zT_142 = zT_146;
    zF_C914CB83_markerWriteInt(zT_141, zT_142);
    zT_148 = "D4F:T";
    zT_150 = 5;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    d4f_t = zT_149;
    zT_151 = d4f_t;
    zT_153 = 0;
    zT_152 = elem_box[zT_153];
    zF_C914CB83_markerWriteInt(zT_151, zT_152);
    goto z_bb_19;
    z_bb_22:
    zT_163 = self->local_decl_count;
    zT_164 = self->local_decl_cap;
    if ((int)(zT_163 >= zT_164)) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    return;
    z_bb_24:
    zT_166 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_166);
    goto z_bb_25;
    z_bb_25:
    zT_167 = node.child_2;
    zT_168 = self->local_decl_names;
    zT_169 = self->local_decl_count;
    zT_168[zT_169] = zT_167;
    zT_170 = 13;
    zT_171 = self->local_decl_types;
    zT_172 = self->local_decl_count;
    zT_171[zT_172] = zT_170;
    zT_173 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_173 + (unsigned int)(1));
    zT_177 = "FIX2:LN";
    zT_179 = 7;
    zT_178.ptr = zT_177;
    zT_178.len = zT_179;
    f2_m = zT_178;
    zT_180 = f2_m;
    zT_181 = node.child_2;
    zF_C914CB83_markerWriteInt(zT_180, zT_181);
    goto z_bb_23;
}

/* semanticAnalyzerResolveWhileHeader */
void zF_10900223_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    zT_22A7C88B_AstNode zT_15 = {0};
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_8143F551_AstKind zT_28;
    zT_38C12417_SemanticAnalyzer* zT_31;
    unsigned int zT_32;
    unsigned int zT_34 = 0;
    zT_6B0A7D14_AstStore* zT_35;
    unsigned int zT_36;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_48;
    zT_22A7C88B_AstNode zT_50 = {0};
    zT_8143F551_AstKind zT_51;
    zT_38C12417_SemanticAnalyzer* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_62 = 0;
    zT_38C12417_SemanticAnalyzer* zT_63;
    unsigned int zT_64;
    unsigned int zT_65 = 0;
    zT_22A7C88B_AstNode node;
    zT_22A7C88B_AstNode ws_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u wst_km;
    unsigned int wcond_t;
    unsigned int wcap_idx;
    zT_22A7C88B_AstNode wcap_node;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_7 = node.child_1;
    if ((int)(zT_7 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self->store;
    zT_12 = node.child_1;
    zT_15 = zF_FCDD1D35_astStoreNodeAt(zT_11, zT_12);
    ws_node = zT_15;
    zT_17 = "WST:N";
    zT_19 = 5;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    wst_nm = zT_18;
    zT_20 = wst_nm;
    zT_21 = node_idx;
    zF_C914CB83_markerWriteInt(zT_20, zT_21);
    zT_23 = "WST:K";
    zT_25 = 5;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    wst_km = zT_24;
    zT_26 = wst_km;
    zT_28 = ws_node.kind;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    goto z_bb_2;
    z_bb_2:
    zT_31 = self;
    zT_32 = node.child_0;
    zT_34 = zF_54F95822_semanticAnalyzerRes(zT_31, zT_32);
    wcond_t = zT_34;
    zT_35 = self->store;
    zT_36 = node_idx;
    zT_38 = zF_8BA26B9E_astStoreNodePayload(zT_35, zT_36);
    if ((int)(zT_38 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_42 = self->store;
    zT_43 = node_idx;
    zT_45 = zF_8BA26B9E_astStoreNodePayload(zT_42, zT_43);
    wcap_idx = zT_45;
    zT_47 = self->store;
    zT_48 = wcap_idx;
    zT_50 = zF_FCDD1D35_astStoreNodeAt(zT_47, zT_48);
    wcap_node = zT_50;
    zT_51 = wcap_node.kind;
    if ((int)(zT_51 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_capture))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return;
    z_bb_5:
    zT_56 = self;
    zT_59 = self->store;
    zT_60 = wcap_idx;
    zT_62 = zF_8BA26B9E_astStoreNodePayload(zT_59, zT_60);
    zT_57 = zT_62;
    zT_63 = self;
    zT_64 = wcond_t;
    zT_65 = zF_3E251D67_semanticAnalyzerCap(zT_63, zT_64);
    zT_58 = zT_65;
    zF_7BD72017_registerLocalDecl(zT_56, zT_57, zT_58);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* semanticAnalyzerResolveStmtIter */
void zF_10A0DC35_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int root_node) {
    unsigned int zT_3;
    zT_38C12417_SemanticAnalyzer* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_21 = {0};
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_28;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_8143F551_AstKind zT_36;
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_47 = {0};
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_61;
    unsigned int zT_65;
    unsigned int* zT_69;
    unsigned int zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    unsigned char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_99;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    zT_38C12417_SemanticAnalyzer* zT_107;
    unsigned int zT_108;
    unsigned int zT_110;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_8143F551_AstKind zT_116;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_124 = 0;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    unsigned int zT_141;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    zT_22A7C88B_AstNode zT_149 = {0};
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_8143F551_AstKind zT_156;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    unsigned int zT_167 = 0;
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_174;
    unsigned int zT_178;
    unsigned int zT_179;
    zT_6B0A7D14_AstStore* zT_183;
    unsigned int zT_184;
    zT_22A7C88B_AstNode zT_187 = {0};
    zT_8143F551_AstKind zT_188;
    zT_38C12417_SemanticAnalyzer* zT_193;
    unsigned int zT_194;
    unsigned int zT_196 = 0;
    zT_ABC1EBBE_TypeResolveEnv zT_200;
    zT_6B0A7D14_AstStore* zT_201;
    zT_338B7C76_TypeRegistry* zT_202;
    zT_3D7259E2_SymbolRegistry* zT_203;
    zT_D3EB6303_StringInterner* zT_204;
    unsigned int zT_205;
    zT_F85C5DED_DiagnosticCollector* zT_206;
    zT_7334F4FE_Opt_225 zT_207;
    zT_E2DF2801_LocalConstScope* zT_208;
    zT_F6B96876_Opt_395 zT_209;
    unsigned int zT_210;
    zT_ABC1EBBE_TypeResolveEnv* zT_212;
    unsigned int zT_213;
    unsigned int zT_218 = 0;
    unsigned char* zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    zT_F85C5DED_DiagnosticCollector* zT_225;
    unsigned int zT_228;
    unsigned int zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned int zT_241 = 0;
    unsigned int zT_242;
    zT_8EED1867_ResolvedTypeTable* zT_244;
    unsigned int zT_245;
    zT_BAEE192E_Opt_10 zT_248 = {0};
    unsigned char zT_249;
    zT_ABC1EBBE_TypeResolveEnv zT_252;
    zT_6B0A7D14_AstStore* zT_253;
    zT_338B7C76_TypeRegistry* zT_254;
    zT_3D7259E2_SymbolRegistry* zT_255;
    zT_D3EB6303_StringInterner* zT_256;
    unsigned int zT_257;
    zT_F85C5DED_DiagnosticCollector* zT_258;
    zT_7334F4FE_Opt_225 zT_259;
    zT_E2DF2801_LocalConstScope* zT_260;
    zT_F6B96876_Opt_395 zT_261;
    unsigned int zT_262;
    zT_ABC1EBBE_TypeResolveEnv* zT_263;
    unsigned int zT_264;
    unsigned int zT_269 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_272;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned char* zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    unsigned int zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_286;
    unsigned int zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    int zT_293;
    unsigned char* zT_294;
    unsigned int zT_295;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_296;
    unsigned int zT_297 = 0;
    unsigned int zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned char* zT_306;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    unsigned char* zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned int zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_315;
    unsigned int zT_317;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_318;
    int zT_321;
    unsigned char* zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned int zT_325 = 0;
    unsigned int zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    unsigned char* zT_334;
    unsigned int zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    unsigned char* zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    unsigned int zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    int zT_345;
    unsigned int zT_350;
    unsigned int zT_352;
    unsigned int zT_354;
    unsigned char* zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned int zT_358;
    zT_F85C5DED_DiagnosticCollector* zT_359;
    unsigned int zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    unsigned int zT_373 = 0;
    unsigned int zT_374;
    zT_6B0A7D14_AstStore* zT_378;
    unsigned int zT_379;
    zT_22A7C88B_AstNode zT_382 = {0};
    unsigned char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    zT_8143F551_AstKind zT_389;
    unsigned int zT_395;
    zT_38C12417_SemanticAnalyzer* zT_397;
    unsigned int zT_398;
    zT_38C12417_SemanticAnalyzer* zT_400;
    unsigned int zT_401;
    unsigned int zT_403 = 0;
    zT_38C12417_SemanticAnalyzer* zT_404;
    int zT_408;
    zT_8143F551_AstKind zT_409;
    zT_6B0A7D14_AstStore* zT_415;
    unsigned int zT_416;
    unsigned int zT_419 = 0;
    int zT_421;
    unsigned int zT_422;
    zT_338B7C76_TypeRegistry* zT_423;
    unsigned int zT_424;
    zT_338B7C76_TypeRegistry* zT_426;
    zT_D155D06D_Type* zT_427;
    zT_D155D06D_Type zT_428;
    zT_33EF6BFB_TypeKind zT_429;
    zT_338B7C76_TypeRegistry* zT_435;
    unsigned int zT_437;
    unsigned int zT_440 = 0;
    unsigned int zT_444;
    zT_21D3708C_U32ToU32Map* zT_446;
    unsigned int zT_447;
    unsigned int zT_449 = 0;
    zT_21D3708C_U32ToU32Map* zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    zT_8EED1867_ResolvedTypeTable* zT_455;
    unsigned int zT_456;
    unsigned int zT_457;
    int zT_460;
    unsigned int zT_461;
    int zT_465;
    zT_8143F551_AstKind zT_466;
    unsigned int zT_472;
    unsigned int zT_474;
    unsigned int zT_476;
    unsigned char* zT_478;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_479;
    unsigned int zT_480;
    zT_F85C5DED_DiagnosticCollector* zT_481;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned int zT_486;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_487;
    unsigned int zT_495 = 0;
    int zT_499;
    unsigned char* zT_504;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_505;
    unsigned int zT_506;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_507;
    zT_38C12417_SemanticAnalyzer* zT_509;
    unsigned int zT_510;
    unsigned int zT_511;
    unsigned int zT_512;
    unsigned int zT_514 = 0;
    zT_38C12417_SemanticAnalyzer* zT_515;
    unsigned int zT_516;
    unsigned int zT_517;
    unsigned int zT_518;
    int zT_520 = 0;
    zT_338B7C76_TypeRegistry* zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    zT_0FB7FB13_CoercionKind zT_526 = 0;
    unsigned char* zT_528;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_529;
    unsigned int zT_530;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_531;
    int zT_538;
    zT_338B7C76_TypeRegistry* zT_539;
    unsigned int zT_540;
    unsigned int zT_541;
    int zT_543 = 0;
    zT_66E7D2EF_CoercionTable* zT_544;
    unsigned int zT_545;
    zT_0FB7FB13_CoercionKind zT_546;
    unsigned int zT_547;
    int zT_552;
    zT_338B7C76_TypeRegistry* zT_553;
    unsigned int zT_554;
    unsigned int zT_555;
    int zT_557 = 0;
    unsigned int zT_560;
    unsigned int zT_562;
    unsigned int zT_564;
    unsigned char* zT_566;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_567;
    unsigned int zT_568;
    zT_338B7C76_TypeRegistry* zT_570;
    zT_D155D06D_Type* zT_571;
    unsigned int zT_572;
    zT_D155D06D_Type zT_573;
    zT_33EF6BFB_TypeKind zT_574;
    zT_338B7C76_TypeRegistry* zT_576;
    zT_D155D06D_Type* zT_577;
    unsigned int zT_578;
    zT_D155D06D_Type zT_579;
    zT_33EF6BFB_TypeKind zT_580;
    int zT_582;
    unsigned char zT_583;
    zT_38C12417_SemanticAnalyzer* zT_584;
    unsigned int zT_585;
    unsigned int zT_586;
    int zT_587 = 0;
    int zT_588;
    unsigned char zT_589;
    zT_38C12417_SemanticAnalyzer* zT_590;
    unsigned int zT_591;
    unsigned int zT_592;
    int zT_595 = 0;
    int zT_596;
    unsigned char zT_597;
    int zT_602;
    zT_338B7C76_TypeRegistry* zT_608;
    zT_42C2D6BF_EUPayload* zT_609;
    zT_338B7C76_TypeRegistry* zT_610;
    zT_D155D06D_Type* zT_611;
    unsigned int zT_612;
    zT_D155D06D_Type zT_613;
    unsigned int zT_614;
    unsigned int zT_615;
    zT_42C2D6BF_EUPayload zT_616;
    zT_338B7C76_TypeRegistry* zT_618;
    zT_42C2D6BF_EUPayload* zT_619;
    zT_338B7C76_TypeRegistry* zT_620;
    zT_D155D06D_Type* zT_621;
    unsigned int zT_622;
    zT_D155D06D_Type zT_623;
    unsigned int zT_624;
    unsigned int zT_625;
    zT_42C2D6BF_EUPayload zT_626;
    unsigned int zT_627;
    unsigned int zT_628;
    int zT_630;
    unsigned char zT_631;
    zT_F85C5DED_DiagnosticCollector* zT_633;
    unsigned char zT_634;
    unsigned int zT_636;
    unsigned int zT_637;
    unsigned int zT_638;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_639;
    unsigned int zT_643 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_644;
    unsigned int zT_645;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_646;
    zT_33EF6BFB_TypeKind zT_648;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_649 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_650;
    unsigned int zT_651;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_652;
    zT_33EF6BFB_TypeKind zT_654;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_655 = {0};
    unsigned char* zT_662;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_663;
    unsigned int zT_664;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_665;
    unsigned char* zT_667;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_668;
    unsigned int zT_669;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_670;
    unsigned int zT_672;
    unsigned int zT_674;
    unsigned int zT_676;
    unsigned char* zT_678;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_679;
    unsigned int zT_680;
    zT_F85C5DED_DiagnosticCollector* zT_681;
    unsigned int zT_684;
    unsigned int zT_685;
    unsigned int zT_686;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_687;
    unsigned int zT_692 = 0;
    zT_66E7D2EF_CoercionTable* zT_694;
    unsigned int zT_695;
    zT_5CC037A7_Opt_194 zT_698 = {0};
    unsigned char zT_699;
    zT_8EED1867_ResolvedTypeTable* zT_701;
    unsigned int zT_702;
    unsigned int zT_703;
    unsigned char zT_706;
    int zT_711;
    unsigned int zT_712;
    zT_E2DF2801_LocalConstScope* zT_715;
    unsigned int zT_716;
    unsigned int zT_717;
    zT_6B0A7D14_AstStore* zT_719;
    unsigned int zT_720;
    unsigned int zT_722 = 0;
    unsigned int zT_723;
    unsigned int zT_724;
    zT_38C12417_SemanticAnalyzer* zT_726;
    zT_6B0A7D14_AstStore* zT_730;
    unsigned int zT_731;
    unsigned int zT_733 = 0;
    unsigned int* zT_734;
    unsigned int zT_735;
    unsigned int* zT_736;
    unsigned int zT_737;
    unsigned int zT_738;
    unsigned int zT_742;
    zT_6B0A7D14_AstStore* zT_746;
    unsigned int zT_747;
    unsigned int zT_749 = 0;
    zT_79FAE712_u64 zT_751;
    zT_338B7C76_TypeRegistry* zT_752;
    zT_79FAE712_u64 zT_753;
    unsigned int zT_754;
    unsigned char* zT_757;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_758;
    unsigned int zT_759;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_760;
    unsigned int zT_761;
    zT_6B0A7D14_AstStore* zT_762;
    unsigned int zT_763;
    unsigned int zT_765 = 0;
    unsigned char* zT_767;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_768;
    unsigned int zT_769;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_770;
    unsigned int zT_771;
    zT_8143F551_AstKind zT_772;
    zT_38C12417_SemanticAnalyzer* zT_777;
    unsigned int zT_778;
    unsigned int zT_779;
    zT_38C12417_SemanticAnalyzer* zT_782;
    unsigned int zT_783;
    unsigned int zT_785;
    zT_38C12417_SemanticAnalyzer* zT_788;
    unsigned int zT_789;
    zT_8143F551_AstKind zT_791;
    zT_38C12417_SemanticAnalyzer* zT_796;
    unsigned int zT_797;
    unsigned int zT_798;
    zT_38C12417_SemanticAnalyzer* zT_801;
    unsigned int zT_802;
    zT_8143F551_AstKind zT_804;
    zT_38C12417_SemanticAnalyzer* zT_809;
    unsigned int zT_810;
    unsigned int zT_811;
    zT_38C12417_SemanticAnalyzer* zT_814;
    unsigned int zT_815;
    zT_8143F551_AstKind zT_817;
    zT_38C12417_SemanticAnalyzer* zT_822;
    unsigned int zT_823;
    zT_8143F551_AstKind zT_824;
    int zT_829;
    zT_8143F551_AstKind zT_830;
    int zT_835;
    zT_8143F551_AstKind zT_836;
    int zT_841;
    zT_8143F551_AstKind zT_842;
    int zT_847;
    zT_8143F551_AstKind zT_848;
    int zT_853;
    zT_8143F551_AstKind zT_854;
    int zT_859;
    zT_8143F551_AstKind zT_860;
    int zT_865;
    zT_8143F551_AstKind zT_866;
    int zT_871;
    zT_8143F551_AstKind zT_872;
    int zT_877;
    zT_8143F551_AstKind zT_878;
    int zT_883;
    zT_8143F551_AstKind zT_884;
    int zT_889;
    zT_8143F551_AstKind zT_890;
    int zT_895;
    zT_8143F551_AstKind zT_896;
    int zT_901;
    zT_8143F551_AstKind zT_902;
    int zT_907;
    zT_8143F551_AstKind zT_908;
    int zT_913;
    zT_8143F551_AstKind zT_914;
    int zT_919;
    zT_8143F551_AstKind zT_920;
    int zT_925;
    zT_8143F551_AstKind zT_926;
    zT_38C12417_SemanticAnalyzer* zT_931;
    unsigned int zT_932;
    unsigned int zT_933 = 0;
    zT_8143F551_AstKind zT_934;
    unsigned int zT_939;
    zT_38C12417_SemanticAnalyzer* zT_942;
    unsigned int zT_943;
    zT_8143F551_AstKind zT_945;
    int zT_950;
    zT_8143F551_AstKind zT_951;
    unsigned int zT_956;
    unsigned int zT_959;
    zT_38C12417_SemanticAnalyzer* zT_962;
    unsigned int zT_963;
    unsigned int zT_965;
    zT_8143F551_AstKind zT_968;
    zT_8143F551_AstKind zT_973;
    unsigned char* zT_979;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_980;
    unsigned int zT_981;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_982;
    unsigned int zT_983;
    unsigned char* zT_985;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_986;
    unsigned int zT_987;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_988;
    zT_8143F551_AstKind zT_990;
    unsigned int zT_992;
    unsigned char* zT_996;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_997;
    unsigned int zT_998;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_999;
    unsigned int zT_1000;
    zT_38C12417_SemanticAnalyzer* zT_1003;
    unsigned int zT_1004;
    unsigned int zT_1005 = 0;
    int zT_1008;
    zT_338B7C76_TypeRegistry* zT_1010;
    unsigned int zT_1011;
    int zT_1013;
    zT_338B7C76_TypeRegistry* zT_1014;
    zT_D155D06D_Type* zT_1015;
    unsigned int zT_1016;
    zT_D155D06D_Type zT_1017;
    zT_33EF6BFB_TypeKind zT_1018;
    unsigned int zT_1024;
    unsigned int zT_1026;
    unsigned int zT_1028;
    unsigned char* zT_1030;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1031;
    unsigned int zT_1032;
    zT_F85C5DED_DiagnosticCollector* zT_1033;
    unsigned int zT_1036;
    unsigned int zT_1037;
    unsigned int zT_1038;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1039;
    unsigned int zT_1047 = 0;
    unsigned int zT_1048;
    zT_6B0A7D14_AstStore* zT_1052;
    unsigned int zT_1053;
    zT_22A7C88B_AstNode zT_1056 = {0};
    zT_8143F551_AstKind zT_1057;
    unsigned int zT_1062;
    zT_6B0A7D14_AstStore* zT_1066;
    unsigned int zT_1067;
    zT_22A7C88B_AstNode zT_1070 = {0};
    zT_8143F551_AstKind zT_1071;
    unsigned int sp_base;
    unsigned int node_idx;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u spk_m;
    zT_3CB0179A_Slice_zT_05F374B1_u children;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u blk_cm;
    unsigned int i;
    unsigned int ci;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_im;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_nm;
    zT_8143F551_AstKind cnode_k;
    zT_8F083A69_Slice_zT_0B42B2F8_u bc_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u bcej;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10n_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10c_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vd2_m;
    unsigned int decl_type;
    zT_22A7C88B_AstNode inode;
    zT_8F083A69_Slice_zT_0B42B2F8_u d10k_m;
    zT_22A7C88B_AstNode ann;
    zT_BAEE192E_Opt_10 rt;
    zT_ABC1EBBE_TypeResolveEnv cd_env;
    unsigned int cd_full;
    zT_8F083A69_Slice_zT_0B42B2F8_u ut_msg;
    unsigned int t;
    zT_ABC1EBBE_TypeResolveEnv tre_env_vd;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1m;
    zT_5A26C2ED_Arr_unsigned_char_1 b1nb;
    unsigned int b1nl;
    unsigned int b1ns;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1c;
    zT_5A26C2ED_Arr_unsigned_char_1 b1tb;
    unsigned int b1tl;
    unsigned int b1ts;
    zT_8F083A69_Slice_zT_0B42B2F8_u b1nl2;
    unsigned int uisp;
    unsigned int uiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui_msg;
    zT_22A7C88B_AstNode init_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u ik_m;
    unsigned int vd_exp;
    unsigned int it;
    unsigned int name_id;
    unsigned int ei;
    unsigned int ord;
    unsigned int es_type_id;
    unsigned int reg_code;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u elu_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u cs4_m;
    unsigned int it_eff;
    zT_0FB7FB13_CoercionKind ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u ckv_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmd_msg;
    zT_33EF6BFB_TypeKind sk;
    zT_33EF6BFB_TypeKind tk;
    unsigned char level;
    zT_42C2D6BF_EUPayload eu_src;
    zT_42C2D6BF_EUPayload eu_tgt;
    unsigned int di;
    zT_8F083A69_Slice_zT_0B42B2F8_u vdag_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u vfvd_m;
    unsigned int vsp;
    unsigned int vep;
    zT_8F083A69_Slice_zT_0B42B2F8_u vv_msg;
    zT_5CC037A7_Opt_194 ct_entry;
    zT_79FAE712_u64 ck_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u regcp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u regct_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_km;
    zT_8F083A69_Slice_zT_0B42B2F8_u els_c0m;
    unsigned int els_r;
    unsigned int eisp;
    unsigned int eiep;
    zT_8F083A69_Slice_zT_0B42B2F8_u ei_msg;
    zT_22A7C88B_AstNode nc;
    zT_3 = self->stmt_work_len;
    sp_base = zT_3;
    zT_4 = self;
    zT_5 = root_node;
    zF_7AB741D8_semanticAnalyzerStm(zT_4, zT_5);
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->stmt_work_len;
    if ((int)(zT_6 > sp_base)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->stmt_work_len;
    self->stmt_work_len = (unsigned int)(zT_8 - (unsigned int)(1));
    zT_12 = self->stmt_work_items;
    zT_13 = self->stmt_work_len;
    zT_14 = zT_12[zT_13];
    node_idx = zT_14;
    if ((int)(node_idx == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_18 = self->store;
    zT_19 = node_idx;
    zT_21 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    node = zT_21;
    zT_23 = "SP:n";
    zT_25 = 4;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    sp_m = zT_24;
    zT_26 = sp_m;
    zT_28 = self->stmt_work_len;
    zF_C914CB83_markerWriteInt(zT_26, (unsigned int)((unsigned int)zT_28));
    zT_31 = "SP:K";
    zT_33 = 4;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    spk_m = zT_32;
    zT_34 = spk_m;
    zT_36 = node.kind;
    zF_C914CB83_markerWriteInt(zT_34, (unsigned int)((unsigned int)zT_36));
    zT_38 = node.kind;
    if ((int)(zT_38 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_block))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_44 = self->store;
    zT_45 = node_idx;
    zT_47 = zF_850FDF81_astStoreNodeExtraCh(zT_44, zT_45);
    children = zT_47;
    zT_49 = "BLK:N";
    zT_51 = 5;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    blk_nm = zT_50;
    zT_52 = blk_nm;
    zT_53 = node_idx;
    zF_C914CB83_markerWriteInt(zT_52, zT_53);
    zT_55 = "BLK:C";
    zT_57 = 5;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    blk_cm = zT_56;
    zT_58 = blk_cm;
    zT_61 = children.len;
    zF_C914CB83_markerWriteInt(zT_58, (unsigned int)((unsigned int)zT_61));
    zT_65 = children.len;
    i = zT_65;
    goto z_bb_10;
    z_bb_8:
    zT_1048 = node.child_0;
    if ((int)(zT_1048 != (unsigned int)(0))) goto z_bb_215; else goto z_bb_216;
    z_bb_9:
    zT_116 = node.kind;
    if ((int)(zT_116 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_14; else goto z_bb_16;
    z_bb_10:
    if ((int)(i > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_69 = children.ptr;
    zT_71 = i - (unsigned int)(1);
    zT_72 = zT_69[zT_71];
    ci = zT_72;
    zT_74 = "BCK:B";
    zT_76 = 5;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    bc_m = zT_75;
    zT_77 = bc_m;
    zT_78 = node_idx;
    zF_C914CB83_markerWriteInt(zT_77, zT_78);
    zT_80 = "BCK:I";
    zT_82 = 5;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    bc_im = zT_81;
    zT_83 = bc_im;
    zF_C914CB83_markerWriteInt(zT_83, (unsigned int)((unsigned int)(unsigned int)(i - (unsigned int)(1))));
    zT_89 = "BCK:N";
    zT_91 = 5;
    zT_90.ptr = zT_89;
    zT_90.len = zT_91;
    bc_nm = zT_90;
    zT_92 = bc_nm;
    zT_93 = ci;
    zF_C914CB83_markerWriteInt(zT_92, zT_93);
    zT_95 = self->store;
    zT_96 = ci;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_95, zT_96);
    zT_99 = zT_98.kind;
    cnode_k = zT_99;
    zT_101 = "BCK:K";
    zT_103 = 5;
    zT_102.ptr = zT_101;
    zT_102.len = zT_103;
    bc_km = zT_102;
    zT_104 = bc_km;
    zF_C914CB83_markerWriteInt(zT_104, (unsigned int)((unsigned int)cnode_k));
    zT_107 = self;
    zT_108 = ci;
    zF_7AB741D8_semanticAnalyzerStm(zT_107, zT_108);
    goto z_bb_13;
    z_bb_12:
    zT_112 = "]\n";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    bcej = zT_113;
    zT_115 = bcej;
    zF_48AC7B3A_markerWrite(zT_115);
    goto z_bb_8;
    z_bb_13:
    zT_110 = i - (unsigned int)(1);
    i = zT_110;
    goto z_bb_10;
    z_bb_14:
    zT_121 = self->store;
    zT_122 = node_idx;
    zT_124 = zF_8BA26B9E_astStoreNodePayload(zT_121, zT_122);
    if ((int)(zT_124 == (unsigned int)(55))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_772 = node.kind;
    if ((int)(zT_772 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt))) goto z_bb_112; else goto z_bb_114;
    z_bb_17:
    zT_128 = "D10:C0";
    zT_130 = 6;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    d10n_m = zT_129;
    zT_131 = d10n_m;
    zT_132 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_131, zT_132);
    zT_135 = "D10:C1";
    zT_137 = 6;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    d10c_m = zT_136;
    zT_138 = d10c_m;
    zT_139 = node.child_1;
    zF_C914CB83_markerWriteInt(zT_138, zT_139);
    zT_141 = node.child_1;
    if ((int)(zT_141 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_159 = "VD:N";
    zT_161 = 4;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    vd_m = zT_160;
    zT_162 = vd_m;
    zT_164 = self->store;
    zT_165 = node_idx;
    zT_167 = zF_8BA26B9E_astStoreNodePayload(zT_164, zT_165);
    zT_163 = zT_167;
    zF_C914CB83_markerWriteInt(zT_162, zT_163);
    zT_169 = "VD:C";
    zT_171 = 4;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    vd2_m = zT_170;
    zT_172 = vd2_m;
    zT_174 = self->local_decl_count;
    zF_C914CB83_markerWriteInt(zT_172, (unsigned int)((unsigned int)zT_174));
    zT_178 = 18;
    decl_type = zT_178;
    zT_179 = node.child_0;
    if ((int)(zT_179 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_145 = self->store;
    zT_146 = node.child_1;
    zT_149 = zF_FCDD1D35_astStoreNodeAt(zT_145, zT_146);
    inode = zT_149;
    zT_151 = "D10:IK";
    zT_153 = 6;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    d10k_m = zT_152;
    zT_154 = d10k_m;
    zT_156 = inode.kind;
    zF_C914CB83_markerWriteInt(zT_154, (unsigned int)((unsigned int)zT_156));
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_183 = self->store;
    zT_184 = node.child_0;
    zT_187 = zF_FCDD1D35_astStoreNodeAt(zT_183, zT_184);
    ann = zT_187;
    zT_188 = ann.kind;
    if ((int)(zT_188 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_23; else goto z_bb_25;
    z_bb_22:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_35; else goto z_bb_36;
    z_bb_23:
    zT_193 = self;
    zT_194 = node.child_0;
    zT_196 = zF_54F95822_semanticAnalyzerRes(zT_193, zT_194);
    decl_type = zT_196;
    if ((int)(decl_type == (unsigned int)(1))) goto z_bb_26; else goto z_bb_27;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_244 = self->type_table;
    zT_245 = node.child_0;
    zT_248 = zF_999DCF51_resolvedTypeTableGe(zT_244, zT_245);
    rt = zT_248;
    zT_249 = rt.has_value;
    if (zT_249) goto z_bb_30; else goto z_bb_32;
    z_bb_26:
    zT_201 = self->store;
    zT_200.store = zT_201;
    zT_202 = self->registry;
    zT_200.typereg = zT_202;
    zT_203 = self->symbols;
    zT_200.symbol_reg = zT_203;
    zT_204 = self->interner;
    zT_200.interner = zT_204;
    zT_205 = self->module_id;
    zT_200.module_id = zT_205;
    zT_206 = self->diag;
    zT_207.has_value = 1;
    zT_207.value = zT_206;
    zT_200.diag = zT_207;
    zT_208 = &self->local_consts;
    zT_209.has_value = 1;
    zT_209.value = zT_208;
    zT_200.local_consts = zT_209;
    zT_210 = self->source_file_id;
    zT_200.source_file_id = zT_210;
    cd_env = zT_200;
    zT_212 = &cd_env;
    zT_213 = node.child_0;
    zT_218 = zF_F2107C15_resolveTypeExprFull(zT_212, zT_213, (unsigned int)(0));
    cd_full = zT_218;
    if ((int)(cd_full == (unsigned int)(18))) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_222 = "unknown type in variable declaration";
    zT_224 = 36;
    zT_223.ptr = zT_222;
    zT_223.len = zT_224;
    ut_msg = zT_223;
    zT_225 = self->diag;
    zT_228 = self->source_file_id;
    zT_229 = ann.span_start;
    zT_237 = ann.span_start;
    zT_238 = ann.span_len;
    zT_231 = ut_msg;
    zT_241 = zF_C82559AC_diagnosticCollector(zT_225, (unsigned char)(0), (unsigned short)(3000), zT_228, zT_229, (unsigned int)(zT_237 + (unsigned int)((unsigned int)zT_238)), zT_231);
    (void)zT_241;
    zT_242 = 18;
    decl_type = zT_242;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    t = rt.value;
    decl_type = t;
    goto z_bb_31;
    z_bb_31:
    goto z_bb_24;
    z_bb_32:
    zT_253 = self->store;
    zT_252.store = zT_253;
    zT_254 = self->registry;
    zT_252.typereg = zT_254;
    zT_255 = self->symbols;
    zT_252.symbol_reg = zT_255;
    zT_256 = self->interner;
    zT_252.interner = zT_256;
    zT_257 = self->module_id;
    zT_252.module_id = zT_257;
    zT_258 = self->diag;
    zT_259.has_value = 1;
    zT_259.value = zT_258;
    zT_252.diag = zT_259;
    zT_260 = &self->local_consts;
    zT_261.has_value = 1;
    zT_261.value = zT_260;
    zT_252.local_consts = zT_261;
    zT_262 = self->source_file_id;
    zT_252.source_file_id = zT_262;
    tre_env_vd = zT_252;
    zT_263 = &tre_env_vd;
    zT_264 = node.child_0;
    zT_269 = zF_F2107C15_resolveTypeExprFull(zT_263, zT_264, (unsigned int)(0));
    decl_type = zT_269;
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_272 = self->type_table;
    zT_273 = node.child_0;
    zT_274 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_272, zT_273, zT_274);
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_281 = "VRT:";
    zT_283 = 4;
    zT_282.ptr = zT_281;
    zT_282.len = zT_283;
    b1m = zT_282;
    zT_284 = b1m;
    zF_48AC7B3A_markerWrite(zT_284);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_286[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1nb[_i] = zT_286[_i];
        _i++;
    }
}
    zT_288 = node.child_0;
    zT_293 = 0;
    zT_294 = (unsigned char*)((unsigned char*)b1nb) + zT_293;
    zT_295 = (unsigned int)(10) - zT_293;
    zT_296.ptr = zT_294;
    zT_296.len = zT_295;
    zT_289 = zT_296;
    zT_297 = zF_A7504564_itoa(zT_288, zT_289);
    b1nl = zT_297;
    zT_301 = (unsigned int)(9) - (unsigned int)((unsigned int)b1nl);
    b1ns = zT_301;
    zT_306 = (unsigned char*)((unsigned char*)b1nb) + b1ns;
    zT_307 = (unsigned int)(9) - b1ns;
    zT_308.ptr = zT_306;
    zT_308.len = zT_307;
    zT_302 = zT_308;
    zF_48AC7B3A_markerWrite(zT_302);
    zT_310 = ":";
    zT_312 = 1;
    zT_311.ptr = zT_310;
    zT_311.len = zT_312;
    b1c = zT_311;
    zT_313 = b1c;
    zF_48AC7B3A_markerWrite(zT_313);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_315[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        b1tb[_i] = zT_315[_i];
        _i++;
    }
}
    zT_317 = decl_type;
    zT_321 = 0;
    zT_322 = (unsigned char*)((unsigned char*)b1tb) + zT_321;
    zT_323 = (unsigned int)(10) - zT_321;
    zT_324.ptr = zT_322;
    zT_324.len = zT_323;
    zT_318 = zT_324;
    zT_325 = zF_A7504564_itoa(zT_317, zT_318);
    b1tl = zT_325;
    zT_329 = (unsigned int)(9) - (unsigned int)((unsigned int)b1tl);
    b1ts = zT_329;
    zT_334 = (unsigned char*)((unsigned char*)b1tb) + b1ts;
    zT_335 = (unsigned int)(9) - b1ts;
    zT_336.ptr = zT_334;
    zT_336.len = zT_335;
    zT_330 = zT_336;
    zF_48AC7B3A_markerWrite(zT_330);
    zT_338 = "\n";
    zT_340 = 1;
    zT_339.ptr = zT_338;
    zT_339.len = zT_340;
    b1nl2 = zT_339;
    zT_341 = b1nl2;
    zF_48AC7B3A_markerWrite(zT_341);
    goto z_bb_36;
    z_bb_36:
    zT_342 = node.child_1;
    if ((int)(zT_342 == (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_345 = decl_type != (unsigned int)(18);
    goto z_bb_39;
    z_bb_38:
    zT_345 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_345) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_350 = node.span_start;
    uisp = zT_350;
    zT_352 = node.span_len;
    zT_354 = uisp + (unsigned int)((unsigned int)zT_352);
    uiep = zT_354;
    zT_356 = "variable must be initialized; use '= undefined' to opt out";
    zT_358 = 58;
    zT_357.ptr = zT_356;
    zT_357.len = zT_358;
    ui_msg = zT_357;
    zT_359 = self->diag;
    zT_362 = self->source_file_id;
    zT_363 = uisp;
    zT_364 = uiep;
    zT_365 = ui_msg;
    zT_373 = zF_C82559AC_diagnosticCollector(zT_359, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3014_USE_OF_UNDEFINED_VARIABLE)), zT_362, zT_363, zT_364, zT_365);
    (void)zT_373;
    goto z_bb_41;
    z_bb_41:
    zT_374 = node.child_1;
    if ((int)(zT_374 != (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_378 = self->store;
    zT_379 = node.child_1;
    zT_382 = zF_FCDD1D35_astStoreNodeAt(zT_378, zT_379);
    init_node = zT_382;
    zT_384 = "I:K";
    zT_386 = 3;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    ik_m = zT_385;
    zT_387 = ik_m;
    zT_389 = init_node.kind;
    zF_C914CB83_markerWriteInt(zT_387, (unsigned int)((unsigned int)zT_389));
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    zT_706 = node.flags;
    if ((int)((unsigned char)(zT_706 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_103; else goto z_bb_104;
    z_bb_44:
    zT_395 = decl_type;
    goto z_bb_46;
    z_bb_45:
    zT_395 = 0;
    goto z_bb_46;
    z_bb_46:
    vd_exp = zT_395;
    zT_397 = self;
    zT_398 = vd_exp;
    zF_9665A229_pushExpectedType(zT_397, zT_398);
    zT_400 = self;
    zT_401 = node.child_1;
    zT_403 = zF_54F95822_semanticAnalyzerRes(zT_400, zT_401);
    it = zT_403;
    zT_404 = self;
    zF_BC478E78_popExpectedType(zT_404);
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_409 = init_node.kind;
    zT_408 = zT_409 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_literal);
    goto z_bb_49;
    z_bb_48:
    zT_408 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_408) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_415 = self->store;
    zT_416 = node.child_1;
    zT_419 = zF_8BA26B9E_astStoreNodePayload(zT_415, zT_416);
    name_id = zT_419;
    zT_421 = 0;
    zT_422 = (unsigned int)zT_421;
    ei = zT_422;
    goto z_bb_52;
    z_bb_51:
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_60; else goto z_bb_61;
    z_bb_52:
    zT_423 = self->registry;
    zT_424 = zT_423->types_len;
    if ((int)(ei < zT_424)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_426 = self->registry;
    zT_427 = zT_426->types_items;
    zT_428 = zT_427[ei];
    zT_429 = zT_428.kind;
    if ((int)(zT_429 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_460 = 1;
    zT_461 = ei + zT_460;
    ei = zT_461;
    goto z_bb_52;
    z_bb_56:
    zT_435 = self->registry;
    zT_437 = name_id;
    zT_440 = zF_D2ECD176_typeRegistryErrorSe(zT_435, (unsigned int)((unsigned int)ei), zT_437);
    ord = zT_440;
    if ((int)(ord != (unsigned int)(4294967295u))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    goto z_bb_55;
    z_bb_58:
    zT_444 = (unsigned int)ei;
    es_type_id = zT_444;
    zT_446 = self->error_code_registry;
    zT_447 = name_id;
    zT_449 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_446, zT_447);
    reg_code = zT_449;
    zT_450 = self->enum_value_table;
    zT_451 = node.child_1;
    zT_452 = reg_code;
    zF_26476265_u32ToU32MapPut(zT_450, zT_451, zT_452);
    zT_455 = self->type_table;
    zT_456 = node.child_1;
    zT_457 = es_type_id;
    zF_19B4A07D_resolvedTypeTableSe(zT_455, zT_456, zT_457);
    it = es_type_id;
    goto z_bb_54;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    zT_466 = init_node.kind;
    zT_465 = zT_466 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_literal);
    goto z_bb_62;
    z_bb_61:
    zT_465 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_465) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_472 = init_node.span_start;
    sp = zT_472;
    zT_474 = init_node.span_len;
    zT_476 = sp + (unsigned int)((unsigned int)zT_474);
    ep = zT_476;
    zT_478 = "unable to infer type of enum literal without context";
    zT_480 = 52;
    zT_479.ptr = zT_478;
    zT_479.len = zT_480;
    elu_msg = zT_479;
    zT_481 = self->diag;
    zT_484 = self->source_file_id;
    zT_485 = sp;
    zT_486 = ep;
    zT_487 = elu_msg;
    zT_495 = zF_C82559AC_diagnosticCollector(zT_481, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3010_CANNOT_INFER_ENUM_LITERAL_TYPE)), zT_484, zT_485, zT_486, zT_487);
    (void)zT_495;
    goto z_bb_64;
    z_bb_64:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_499 = it != decl_type;
    goto z_bb_67;
    z_bb_66:
    zT_499 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_499) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    if ((int)(it == (unsigned int)(17))) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    if ((int)(decl_type == (unsigned int)(18))) goto z_bb_97; else goto z_bb_98;
    z_bb_70:
    zT_504 = "CS4\n";
    zT_506 = 4;
    zT_505.ptr = zT_504;
    zT_505.len = zT_506;
    cs4_m = zT_505;
    zT_507 = cs4_m;
    zF_48AC7B3A_markerWrite(zT_507);
    goto z_bb_71;
    z_bb_71:
    zT_509 = self;
    zT_510 = node.child_1;
    zT_511 = decl_type;
    zT_512 = it;
    zT_514 = zF_FFC95E09_errLitSrcType(zT_509, zT_510, zT_511, zT_512);
    it_eff = zT_514;
    zT_515 = self;
    zT_516 = node.child_1;
    zT_517 = it_eff;
    zT_518 = decl_type;
    zT_520 = zF_86AAA417_semanticAnalyzerMay(zT_515, zT_516, zT_517, zT_518);
    if (zT_520) goto z_bb_72; else goto z_bb_74;
    z_bb_72:
    goto z_bb_73;
    z_bb_73:
    goto z_bb_69;
    z_bb_74:
    zT_522 = self->registry;
    zT_523 = it_eff;
    zT_524 = decl_type;
    zT_526 = zF_713658BF_classifyCoercion(zT_522, zT_523, zT_524);
    ck = zT_526;
    zT_528 = "CCK:vr";
    zT_530 = 6;
    zT_529.ptr = zT_528;
    zT_529.len = zT_530;
    ckv_m = zT_529;
    zT_531 = ckv_m;
    zF_C914CB83_markerWriteInt(zT_531, (unsigned int)((unsigned int)ck));
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_539 = self->registry;
    zT_540 = it_eff;
    zT_541 = decl_type;
    zT_543 = zF_683AEB7F_typeRegistryIsAssig(zT_539, zT_540, zT_541);
    zT_538 = zT_543;
    goto z_bb_77;
    z_bb_76:
    zT_538 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_538) goto z_bb_78; else goto z_bb_80;
    z_bb_78:
    zT_544 = self->coercion_table;
    zT_545 = node.child_1;
    zT_546 = ck;
    zT_547 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_544, zT_545, zT_546, zT_547);
    goto z_bb_79;
    z_bb_79:
    goto z_bb_73;
    z_bb_80:
    if ((int)(it != (unsigned int)(18))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_553 = self->registry;
    zT_554 = it;
    zT_555 = decl_type;
    zT_557 = zF_683AEB7F_typeRegistryIsAssig(zT_553, zT_554, zT_555);
    zT_552 = !zT_557;
    goto z_bb_83;
    z_bb_82:
    zT_552 = 0;
    goto z_bb_83;
    z_bb_83:
    if (zT_552) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_560 = node.span_start;
    sp = zT_560;
    zT_562 = node.span_len;
    zT_564 = sp + (unsigned int)((unsigned int)zT_562);
    ep = zT_564;
    zT_566 = "type mismatch in variable declaration — initialization type may not be compatible with declared type";
    zT_568 = 102;
    zT_567.ptr = zT_566;
    zT_567.len = zT_568;
    tmd_msg = zT_567;
    zT_570 = self->registry;
    zT_571 = zT_570->types_items;
    zT_572 = (unsigned int)it;
    zT_573 = zT_571[zT_572];
    zT_574 = zT_573.kind;
    sk = zT_574;
    zT_576 = self->registry;
    zT_577 = zT_576->types_items;
    zT_578 = (unsigned int)decl_type;
    zT_579 = zT_577[zT_578];
    zT_580 = zT_579.kind;
    tk = zT_580;
    zT_582 = 1;
    zT_583 = (unsigned char)zT_582;
    level = zT_583;
    zT_584 = self;
    zT_585 = it;
    zT_586 = decl_type;
    zT_587 = zF_148F8E19_semanticAnalyzerFnP(zT_584, zT_585, zT_586);
    if (zT_587) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    goto z_bb_79;
    z_bb_86:
    zT_588 = 0;
    zT_589 = (unsigned char)zT_588;
    level = zT_589;
    goto z_bb_87;
    z_bb_87:
    zT_590 = self;
    zT_591 = it;
    zT_592 = decl_type;
    zT_595 = zF_D728034A_isBShapeMismatch(zT_590, zT_591, zT_592, (int)(1));
    if (zT_595) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_596 = 0;
    zT_597 = (unsigned char)zT_596;
    level = zT_597;
    goto z_bb_89;
    z_bb_89:
    if ((int)(sk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_602 = tk == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_92;
    z_bb_91:
    zT_602 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_602) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_608 = self->registry;
    zT_609 = zT_608->eu_items;
    zT_610 = self->registry;
    zT_611 = zT_610->types_items;
    zT_612 = (unsigned int)it;
    zT_613 = zT_611[zT_612];
    zT_614 = zT_613.payload_idx;
    zT_615 = (unsigned int)zT_614;
    zT_616 = zT_609[zT_615];
    eu_src = zT_616;
    zT_618 = self->registry;
    zT_619 = zT_618->eu_items;
    zT_620 = self->registry;
    zT_621 = zT_620->types_items;
    zT_622 = (unsigned int)decl_type;
    zT_623 = zT_621[zT_622];
    zT_624 = zT_623.payload_idx;
    zT_625 = (unsigned int)zT_624;
    zT_626 = zT_619[zT_625];
    eu_tgt = zT_626;
    zT_627 = eu_src.error_set;
    zT_628 = eu_tgt.error_set;
    if ((int)(zT_627 == zT_628)) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    zT_633 = self->diag;
    zT_634 = level;
    zT_636 = self->source_file_id;
    zT_637 = sp;
    zT_638 = ep;
    zT_639 = tmd_msg;
    zT_643 = zF_C82559AC_diagnosticCollector(zT_633, zT_634, (unsigned short)(3000), zT_636, zT_637, zT_638, zT_639);
    di = zT_643;
    zT_644 = self->diag;
    zT_645 = di;
    zT_648 = sk;
    zT_649 = zF_C14453DE_typeKindSrcStr(zT_648);
    zT_646 = zT_649;
    zF_426E1F18_diagnosticCollector(zT_644, zT_645, zT_646);
    (void)self;
    zT_650 = self->diag;
    zT_651 = di;
    zT_654 = tk;
    zT_655 = zF_CC479241_typeKindTgtStr(zT_654);
    zT_652 = zT_655;
    zF_426E1F18_diagnosticCollector(zT_650, zT_651, zT_652);
    (void)self;
    goto z_bb_85;
    z_bb_95:
    zT_630 = 0;
    zT_631 = (unsigned char)zT_630;
    level = zT_631;
    goto z_bb_96;
    z_bb_96:
    goto z_bb_94;
    z_bb_97:
    decl_type = it;
    goto z_bb_98;
    z_bb_98:
    if ((int)(decl_type == (unsigned int)(1))) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_662 = "VDIAG:void_var\n";
    zT_664 = 15;
    zT_663.ptr = zT_662;
    zT_663.len = zT_664;
    vdag_m = zT_663;
    zT_665 = vdag_m;
    zF_48AC7B3A_markerWrite(zT_665);
    zT_667 = "VFLOW:vdag\n";
    zT_669 = 11;
    zT_668.ptr = zT_667;
    zT_668.len = zT_669;
    vfvd_m = zT_668;
    zT_670 = vfvd_m;
    zF_48AC7B3A_markerWrite(zT_670);
    zT_672 = node.span_start;
    vsp = zT_672;
    zT_674 = node.span_len;
    zT_676 = vsp + (unsigned int)((unsigned int)zT_674);
    vep = zT_676;
    zT_678 = "cannot declare variable of type void";
    zT_680 = 36;
    zT_679.ptr = zT_678;
    zT_679.len = zT_680;
    vv_msg = zT_679;
    zT_681 = self->diag;
    zT_684 = self->source_file_id;
    zT_685 = vsp;
    zT_686 = vep;
    zT_687 = vv_msg;
    zT_692 = zF_C82559AC_diagnosticCollector(zT_681, (unsigned char)(0), (unsigned short)(3000), zT_684, zT_685, zT_686, zT_687);
    (void)zT_692;
    goto z_bb_100;
    z_bb_100:
    zT_694 = self->coercion_table;
    zT_695 = node.child_1;
    zT_698 = zF_46B66789_coercionTableGet(zT_694, zT_695);
    ct_entry = zT_698;
    zT_699 = ct_entry.has_value;
    if ((int)(!zT_699)) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_701 = self->type_table;
    zT_702 = node.child_1;
    zT_703 = decl_type;
    zF_19B4A07D_resolvedTypeTableSe(zT_701, zT_702, zT_703);
    goto z_bb_102;
    z_bb_102:
    goto z_bb_43;
    z_bb_103:
    zT_712 = node.child_1;
    zT_711 = zT_712 != (unsigned int)(0);
    goto z_bb_105;
    z_bb_104:
    zT_711 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_711) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    zT_715 = &self->local_consts;
    zT_719 = self->store;
    zT_720 = node_idx;
    zT_722 = zF_8BA26B9E_astStoreNodePayload(zT_719, zT_720);
    zT_716 = zT_722;
    zT_717 = node_idx;
    zF_DA915531_localConstScopePush(zT_715, zT_716, zT_717);
    goto z_bb_107;
    z_bb_107:
    zT_723 = self->local_decl_count;
    zT_724 = self->local_decl_cap;
    if ((int)(zT_723 >= zT_724)) goto z_bb_108; else goto z_bb_109;
    z_bb_108:
    zT_726 = self;
    zF_156C79D0_semanticAnalyzerGro(zT_726);
    goto z_bb_109;
    z_bb_109:
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_730 = self->store;
    zT_731 = node_idx;
    zT_733 = zF_8BA26B9E_astStoreNodePayload(zT_730, zT_731);
    zT_734 = self->local_decl_names;
    zT_735 = self->local_decl_count;
    zT_734[zT_735] = zT_733;
    zT_736 = self->local_decl_types;
    zT_737 = self->local_decl_count;
    zT_736[zT_737] = decl_type;
    zT_738 = self->local_decl_count;
    self->local_decl_count = (unsigned int)(zT_738 + (unsigned int)(1));
    zT_742 = self->module_id;
    zT_746 = self->store;
    zT_747 = node_idx;
    zT_749 = zF_8BA26B9E_astStoreNodePayload(zT_746, zT_747);
    zT_751 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_742) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_749);
    ck_1 = zT_751;
    zT_752 = self->registry;
    zT_753 = ck_1;
    zT_754 = decl_type;
    zF_5E95558D_nameCachePut(zT_752, zT_753, zT_754);
    zT_757 = "REG:cp";
    zT_759 = 6;
    zT_758.ptr = zT_757;
    zT_758.len = zT_759;
    regcp_m = zT_758;
    zT_760 = regcp_m;
    zT_762 = self->store;
    zT_763 = node_idx;
    zT_765 = zF_8BA26B9E_astStoreNodePayload(zT_762, zT_763);
    zT_761 = zT_765;
    zF_C914CB83_markerWriteInt(zT_760, zT_761);
    zT_767 = "REG:ct";
    zT_769 = 6;
    zT_768.ptr = zT_767;
    zT_768.len = zT_769;
    regct_m = zT_768;
    zT_770 = regct_m;
    zT_771 = decl_type;
    zF_C914CB83_markerWriteInt(zT_770, zT_771);
    goto z_bb_111;
    z_bb_111:
    goto z_bb_15;
    z_bb_112:
    zT_777 = self;
    zT_778 = node_idx;
    zF_0324C9A3_semanticAnalyzerRes(zT_777, zT_778);
    zT_779 = node.child_2;
    if ((int)(zT_779 != (unsigned int)(0))) goto z_bb_115; else goto z_bb_116;
    z_bb_113:
    goto z_bb_15;
    z_bb_114:
    zT_791 = node.kind;
    if ((int)(zT_791 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_while_stmt))) goto z_bb_119; else goto z_bb_121;
    z_bb_115:
    zT_782 = self;
    zT_783 = node.child_2;
    zF_7AB741D8_semanticAnalyzerStm(zT_782, zT_783);
    goto z_bb_116;
    z_bb_116:
    zT_785 = node.child_1;
    if ((int)(zT_785 != (unsigned int)(0))) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    zT_788 = self;
    zT_789 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_788, zT_789);
    goto z_bb_118;
    z_bb_118:
    goto z_bb_113;
    z_bb_119:
    zT_796 = self;
    zT_797 = node_idx;
    zF_10900223_semanticAnalyzerRes(zT_796, zT_797);
    zT_798 = node.child_1;
    if ((int)(zT_798 != (unsigned int)(0))) goto z_bb_122; else goto z_bb_123;
    z_bb_120:
    goto z_bb_113;
    z_bb_121:
    zT_804 = node.kind;
    if ((int)(zT_804 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_for_stmt))) goto z_bb_124; else goto z_bb_126;
    z_bb_122:
    zT_801 = self;
    zT_802 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_801, zT_802);
    goto z_bb_123;
    z_bb_123:
    goto z_bb_120;
    z_bb_124:
    zT_809 = self;
    zT_810 = node_idx;
    zF_8CE01C41_semanticAnalyzerRes(zT_809, zT_810);
    zT_811 = node.child_1;
    if ((int)(zT_811 != (unsigned int)(0))) goto z_bb_127; else goto z_bb_128;
    z_bb_125:
    goto z_bb_120;
    z_bb_126:
    zT_817 = node.kind;
    if ((int)(zT_817 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_return_stmt))) goto z_bb_129; else goto z_bb_131;
    z_bb_127:
    zT_814 = self;
    zT_815 = node.child_1;
    zF_7AB741D8_semanticAnalyzerStm(zT_814, zT_815);
    goto z_bb_128;
    z_bb_128:
    goto z_bb_125;
    z_bb_129:
    zT_822 = self;
    zT_823 = node_idx;
    zF_F231D87F_resolveReturnStmt(zT_822, zT_823);
    goto z_bb_130;
    z_bb_130:
    goto z_bb_125;
    z_bb_131:
    zT_824 = node.kind;
    if ((int)(zT_824 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_plain_assign))) goto z_bb_133; else goto z_bb_132;
    z_bb_132:
    zT_830 = node.kind;
    zT_829 = zT_830 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add_assign);
    goto z_bb_134;
    z_bb_133:
    zT_829 = 1;
    goto z_bb_134;
    z_bb_134:
    if (zT_829) goto z_bb_136; else goto z_bb_135;
    z_bb_135:
    zT_836 = node.kind;
    zT_835 = zT_836 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub_assign);
    goto z_bb_137;
    z_bb_136:
    zT_835 = 1;
    goto z_bb_137;
    z_bb_137:
    if (zT_835) goto z_bb_139; else goto z_bb_138;
    z_bb_138:
    zT_842 = node.kind;
    zT_841 = zT_842 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul_assign);
    goto z_bb_140;
    z_bb_139:
    zT_841 = 1;
    goto z_bb_140;
    z_bb_140:
    if (zT_841) goto z_bb_142; else goto z_bb_141;
    z_bb_141:
    zT_848 = node.kind;
    zT_847 = zT_848 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div_assign);
    goto z_bb_143;
    z_bb_142:
    zT_847 = 1;
    goto z_bb_143;
    z_bb_143:
    if (zT_847) goto z_bb_145; else goto z_bb_144;
    z_bb_144:
    zT_854 = node.kind;
    zT_853 = zT_854 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_assign);
    goto z_bb_146;
    z_bb_145:
    zT_853 = 1;
    goto z_bb_146;
    z_bb_146:
    if (zT_853) goto z_bb_148; else goto z_bb_147;
    z_bb_147:
    zT_860 = node.kind;
    zT_859 = zT_860 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl_assign);
    goto z_bb_149;
    z_bb_148:
    zT_859 = 1;
    goto z_bb_149;
    z_bb_149:
    if (zT_859) goto z_bb_151; else goto z_bb_150;
    z_bb_150:
    zT_866 = node.kind;
    zT_865 = zT_866 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr_assign);
    goto z_bb_152;
    z_bb_151:
    zT_865 = 1;
    goto z_bb_152;
    z_bb_152:
    if (zT_865) goto z_bb_154; else goto z_bb_153;
    z_bb_153:
    zT_872 = node.kind;
    zT_871 = zT_872 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_and_assign);
    goto z_bb_155;
    z_bb_154:
    zT_871 = 1;
    goto z_bb_155;
    z_bb_155:
    if (zT_871) goto z_bb_157; else goto z_bb_156;
    z_bb_156:
    zT_878 = node.kind;
    zT_877 = zT_878 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_or_assign);
    goto z_bb_158;
    z_bb_157:
    zT_877 = 1;
    goto z_bb_158;
    z_bb_158:
    if (zT_877) goto z_bb_160; else goto z_bb_159;
    z_bb_159:
    zT_884 = node.kind;
    zT_883 = zT_884 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_xor_assign);
    goto z_bb_161;
    z_bb_160:
    zT_883 = 1;
    goto z_bb_161;
    z_bb_161:
    if (zT_883) goto z_bb_163; else goto z_bb_162;
    z_bb_162:
    zT_890 = node.kind;
    zT_889 = zT_890 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_add_assign);
    goto z_bb_164;
    z_bb_163:
    zT_889 = 1;
    goto z_bb_164;
    z_bb_164:
    if (zT_889) goto z_bb_166; else goto z_bb_165;
    z_bb_165:
    zT_896 = node.kind;
    zT_895 = zT_896 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_sub_assign);
    goto z_bb_167;
    z_bb_166:
    zT_895 = 1;
    goto z_bb_167;
    z_bb_167:
    if (zT_895) goto z_bb_169; else goto z_bb_168;
    z_bb_168:
    zT_902 = node.kind;
    zT_901 = zT_902 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_wrap_mul_assign);
    goto z_bb_170;
    z_bb_169:
    zT_901 = 1;
    goto z_bb_170;
    z_bb_170:
    if (zT_901) goto z_bb_172; else goto z_bb_171;
    z_bb_171:
    zT_908 = node.kind;
    zT_907 = zT_908 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_add_assign);
    goto z_bb_173;
    z_bb_172:
    zT_907 = 1;
    goto z_bb_173;
    z_bb_173:
    if (zT_907) goto z_bb_175; else goto z_bb_174;
    z_bb_174:
    zT_914 = node.kind;
    zT_913 = zT_914 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_sub_assign);
    goto z_bb_176;
    z_bb_175:
    zT_913 = 1;
    goto z_bb_176;
    z_bb_176:
    if (zT_913) goto z_bb_178; else goto z_bb_177;
    z_bb_177:
    zT_920 = node.kind;
    zT_919 = zT_920 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_mul_assign);
    goto z_bb_179;
    z_bb_178:
    zT_919 = 1;
    goto z_bb_179;
    z_bb_179:
    if (zT_919) goto z_bb_181; else goto z_bb_180;
    z_bb_180:
    zT_926 = node.kind;
    zT_925 = zT_926 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sat_shl_assign);
    goto z_bb_182;
    z_bb_181:
    zT_925 = 1;
    goto z_bb_182;
    z_bb_182:
    if (zT_925) goto z_bb_183; else goto z_bb_185;
    z_bb_183:
    zT_931 = self;
    zT_932 = node_idx;
    zT_933 = zF_54F95822_semanticAnalyzerRes(zT_931, zT_932);
    (void)zT_933;
    goto z_bb_184;
    z_bb_184:
    goto z_bb_130;
    z_bb_185:
    zT_934 = node.kind;
    if ((int)(zT_934 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_labeled_stmt))) goto z_bb_186; else goto z_bb_188;
    z_bb_186:
    zT_939 = node.child_0;
    if ((int)(zT_939 != (unsigned int)(0))) goto z_bb_189; else goto z_bb_190;
    z_bb_187:
    goto z_bb_184;
    z_bb_188:
    zT_945 = node.kind;
    if ((int)(zT_945 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_defer_stmt))) goto z_bb_192; else goto z_bb_191;
    z_bb_189:
    zT_942 = self;
    zT_943 = node.child_0;
    zF_7AB741D8_semanticAnalyzerStm(zT_942, zT_943);
    goto z_bb_190;
    z_bb_190:
    goto z_bb_187;
    z_bb_191:
    zT_951 = node.kind;
    zT_950 = zT_951 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_errdefer_stmt);
    goto z_bb_193;
    z_bb_192:
    zT_950 = 1;
    goto z_bb_193;
    z_bb_193:
    if (zT_950) goto z_bb_194; else goto z_bb_196;
    z_bb_194:
    zT_956 = node.child_0;
    if ((int)(zT_956 != (unsigned int)(0))) goto z_bb_197; else goto z_bb_198;
    z_bb_195:
    goto z_bb_187;
    z_bb_196:
    zT_968 = node.kind;
    if ((int)(zT_968 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_break_stmt))) goto z_bb_199; else goto z_bb_201;
    z_bb_197:
    zT_959 = self->defer_depth;
    self->defer_depth = (unsigned int)(zT_959 + (unsigned int)(1));
    zT_962 = self;
    zT_963 = node.child_0;
    zF_10A0DC35_semanticAnalyzerRes(zT_962, zT_963);
    zT_965 = self->defer_depth;
    self->defer_depth = (unsigned int)(zT_965 - (unsigned int)(1));
    goto z_bb_198;
    z_bb_198:
    goto z_bb_195;
    z_bb_199:
    goto z_bb_200;
    z_bb_200:
    goto z_bb_195;
    z_bb_201:
    zT_973 = node.kind;
    if ((int)(zT_973 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_continue_stmt))) goto z_bb_202; else goto z_bb_204;
    z_bb_202:
    goto z_bb_203;
    z_bb_203:
    goto z_bb_200;
    z_bb_204:
    zT_979 = "ELS:n";
    zT_981 = 5;
    zT_980.ptr = zT_979;
    zT_980.len = zT_981;
    els_nm = zT_980;
    zT_982 = els_nm;
    zT_983 = node_idx;
    zF_C914CB83_markerWriteInt(zT_982, zT_983);
    zT_985 = "ELS:k";
    zT_987 = 5;
    zT_986.ptr = zT_985;
    zT_986.len = zT_987;
    els_km = zT_986;
    zT_988 = els_km;
    zT_990 = node.kind;
    zF_C914CB83_markerWriteInt(zT_988, (unsigned int)((unsigned int)zT_990));
    zT_992 = node.child_0;
    if ((int)(zT_992 != (unsigned int)(0))) goto z_bb_205; else goto z_bb_206;
    z_bb_205:
    zT_996 = "ELS:c";
    zT_998 = 5;
    zT_997.ptr = zT_996;
    zT_997.len = zT_998;
    els_c0m = zT_997;
    zT_999 = els_c0m;
    zT_1000 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_999, zT_1000);
    goto z_bb_206;
    z_bb_206:
    zT_1003 = self;
    zT_1004 = node_idx;
    zT_1005 = zF_54F95822_semanticAnalyzerRes(zT_1003, zT_1004);
    els_r = zT_1005;
    if ((int)(els_r != (unsigned int)(0))) goto z_bb_207; else goto z_bb_208;
    z_bb_207:
    zT_1010 = self->registry;
    zT_1011 = zT_1010->types_len;
    zT_1008 = (unsigned int)((unsigned int)els_r) < zT_1011;
    goto z_bb_209;
    z_bb_208:
    zT_1008 = 0;
    goto z_bb_209;
    z_bb_209:
    if (zT_1008) goto z_bb_210; else goto z_bb_211;
    z_bb_210:
    zT_1014 = self->registry;
    zT_1015 = zT_1014->types_items;
    zT_1016 = (unsigned int)els_r;
    zT_1017 = zT_1015[zT_1016];
    zT_1018 = zT_1017.kind;
    zT_1013 = zT_1018 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_212;
    z_bb_211:
    zT_1013 = 0;
    goto z_bb_212;
    z_bb_212:
    if (zT_1013) goto z_bb_213; else goto z_bb_214;
    z_bb_213:
    zT_1024 = node.span_start;
    eisp = zT_1024;
    zT_1026 = node.span_len;
    zT_1028 = eisp + (unsigned int)((unsigned int)zT_1026);
    eiep = zT_1028;
    zT_1030 = "error union result is ignored; use 'try', 'catch', or assign the result";
    zT_1032 = 71;
    zT_1031.ptr = zT_1030;
    zT_1031.len = zT_1032;
    ei_msg = zT_1031;
    zT_1033 = self->diag;
    zT_1036 = self->source_file_id;
    zT_1037 = eisp;
    zT_1038 = eiep;
    zT_1039 = ei_msg;
    zT_1047 = zF_C82559AC_diagnosticCollector(zT_1033, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3015_ERROR_IGNORED)), zT_1036, zT_1037, zT_1038, zT_1039);
    (void)zT_1047;
    goto z_bb_214;
    z_bb_214:
    goto z_bb_203;
    z_bb_215:
    zT_1052 = self->store;
    zT_1053 = node.child_0;
    zT_1056 = zF_FCDD1D35_astStoreNodeAt(zT_1052, zT_1053);
    nc = zT_1056;
    zT_1057 = nc.kind;
    if ((int)(zT_1057 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_217; else goto z_bb_218;
    z_bb_216:
    zT_1062 = node.child_1;
    if ((int)(zT_1062 != (unsigned int)(0))) goto z_bb_219; else goto z_bb_220;
    z_bb_217:
    goto z_bb_4;
    z_bb_218:
    goto z_bb_216;
    z_bb_219:
    zT_1066 = self->store;
    zT_1067 = node.child_1;
    zT_1070 = zF_FCDD1D35_astStoreNodeAt(zT_1066, zT_1067);
    nc = zT_1070;
    zT_1071 = nc.kind;
    if ((int)(zT_1071 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_221; else goto z_bb_222;
    z_bb_220:
    goto z_bb_4;
    z_bb_221:
    goto z_bb_4;
    z_bb_222:
    goto z_bb_220;
}

/* semaTraceStep */
unsigned int zF_DE5079F2_semaTraceStep(zT_38C12417_SemanticAnalyzer* self, unsigned int* cur_name, unsigned char* done) {
    zT_3D7259E2_SymbolRegistry* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_5979294E_Opt_849 zT_10 = {0};
    unsigned char zT_11;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    zT_22A7C88B_AstNode zT_23 = {0};
    zT_8143F551_AstKind zT_24;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_49;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    zT_22A7C88B_AstNode zT_59 = {0};
    zT_8143F551_AstKind zT_60;
    zT_6B0A7D14_AstStore* zT_68;
    unsigned int zT_69;
    unsigned int zT_72 = 0;
    zT_5979294E_Opt_849 ss;
    zT_3A105EF1_Symbol* s;
    zT_22A7C88B_AstNode dn;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode c0;
    unsigned int nn;
    zT_4 = self->symbols;
    zT_5 = self->module_id;
    zT_6 = *cur_name;
    zT_10 = zF_A398987E_symbolRegistryQuali(zT_4, zT_5, zT_6);
    ss = zT_10;
    zT_11 = ss.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s = ss.value;
    zT_13 = s->decl_node;
    if ((int)(zT_13 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_3:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_4:
    zT_19 = self->store;
    zT_20 = s->decl_node;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_19, zT_20);
    dn = zT_23;
    zT_24 = dn.kind;
    if ((int)(zT_24 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_6:
    zT_31 = dn.child_1;
    if ((int)(zT_31 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_8:
    zT_37 = self->store;
    zT_38 = dn.child_1;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_37, zT_38);
    init = zT_41;
    zT_42 = init.kind;
    if ((int)(zT_42 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_10:
    zT_49 = init.child_0;
    if ((int)(zT_49 == (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_12:
    zT_55 = self->store;
    zT_56 = init.child_0;
    zT_59 = zF_FCDD1D35_astStoreNodeAt(zT_55, zT_56);
    c0 = zT_59;
    zT_60 = c0.kind;
    if ((int)(zT_60 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    *done = (unsigned char)(1);
    return (unsigned int)(0);
    z_bb_14:
    zT_68 = self->store;
    zT_69 = init.child_0;
    zT_72 = zF_53458827_astStoreIdentifier(zT_68, zT_69);
    nn = zT_72;
    *cur_name = nn;
    return nn;
}

/* semanticAnalyzerResolveIndexAccess */
unsigned int zF_1926BC05_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_22A7C88B_AstNode zT_12 = {0};
    unsigned int zT_14;
    zT_38C12417_SemanticAnalyzer* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    zT_38C12417_SemanticAnalyzer* zT_19;
    unsigned int zT_20;
    unsigned int zT_22 = 0;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_28 = {0};
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8143F551_AstKind zT_35;
    zT_8143F551_AstKind zT_37;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    unsigned int zT_47 = 0;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned char zT_60;
    int zT_63;
    zT_38C12417_SemanticAnalyzer* zT_66;
    unsigned int* zT_67;
    unsigned char* zT_68;
    unsigned int zT_71 = 0;
    unsigned int zT_73;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8EED1867_ResolvedTypeTable* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    unsigned int zT_100;
    int zT_103;
    unsigned int zT_104;
    zT_8EED1867_ResolvedTypeTable* zT_107;
    unsigned int zT_108;
    zT_338B7C76_TypeRegistry* zT_114;
    zT_D155D06D_Type* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    zT_D155D06D_Type zT_118;
    zT_338B7C76_TypeRegistry* zT_120;
    unsigned int zT_121;
    unsigned int zT_124 = 0;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    unsigned int zT_132;
    zT_33EF6BFB_TypeKind zT_133;
    zT_338B7C76_TypeRegistry* zT_139;
    zT_666DC2E1_TuplePayload* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    zT_666DC2E1_TuplePayload zT_143;
    zT_338B7C76_TypeRegistry* zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    unsigned int zT_155;
    unsigned char zT_157;
    zT_33EF6BFB_TypeKind zT_158;
    int zT_163;
    zT_33EF6BFB_TypeKind zT_164;
    int zT_169;
    zT_33EF6BFB_TypeKind zT_170;
    int zT_175;
    zT_33EF6BFB_TypeKind zT_176;
    int zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    int zT_187;
    zT_33EF6BFB_TypeKind zT_188;
    int zT_193;
    zT_33EF6BFB_TypeKind zT_194;
    int zT_199;
    zT_33EF6BFB_TypeKind zT_200;
    int zT_205;
    zT_33EF6BFB_TypeKind zT_206;
    int zT_211;
    zT_33EF6BFB_TypeKind zT_212;
    int zT_217;
    zT_33EF6BFB_TypeKind zT_218;
    int zT_223;
    zT_33EF6BFB_TypeKind zT_224;
    int zT_229;
    zT_33EF6BFB_TypeKind zT_230;
    int zT_235;
    zT_33EF6BFB_TypeKind zT_236;
    int zT_241;
    zT_33EF6BFB_TypeKind zT_242;
    int zT_247;
    zT_33EF6BFB_TypeKind zT_248;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_254;
    int zT_259;
    zT_33EF6BFB_TypeKind zT_260;
    int zT_265;
    zT_33EF6BFB_TypeKind zT_266;
    int zT_271;
    zT_33EF6BFB_TypeKind zT_272;
    int zT_277;
    zT_33EF6BFB_TypeKind zT_278;
    int zT_283;
    zT_33EF6BFB_TypeKind zT_284;
    int zT_289;
    zT_33EF6BFB_TypeKind zT_290;
    int zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    int zT_301;
    zT_33EF6BFB_TypeKind zT_302;
    int zT_307;
    zT_33EF6BFB_TypeKind zT_308;
    int zT_313;
    zT_33EF6BFB_TypeKind zT_314;
    unsigned char zT_319;
    unsigned char* zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    unsigned int zT_325;
    zT_F85C5DED_DiagnosticCollector* zT_326;
    unsigned int zT_329;
    unsigned int zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned int zT_338;
    unsigned int zT_339;
    unsigned int zT_342 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_343;
    unsigned int zT_344;
    unsigned int zT_350;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixa_m;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_22A7C88B_AstNode c0_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u c0k_m;
    unsigned int c0_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u ste_m;
    unsigned int src_cur_name;
    unsigned int src_depth;
    unsigned int src_name;
    unsigned char src_done;
    zT_8F083A69_Slice_zT_0B42B2F8_u ix_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u srs_s;
    zT_D155D06D_Type bt;
    unsigned int ix_elem;
    zT_8F083A69_Slice_zT_0B42B2F8_u ixr_m;
    unsigned char nidx_bad;
    zT_666DC2E1_TuplePayload tp;
    unsigned int r4;
    zT_8F083A69_Slice_zT_0B42B2F8_u nidx_msg;
    unsigned int ret;
    zT_3 = "IXA:N";
    zT_5 = 5;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    ixa_m = zT_4;
    zT_6 = ixa_m;
    zT_7 = node_idx;
    zF_C914CB83_markerWriteInt(zT_6, zT_7);
    zT_9 = self->store;
    zT_10 = node_idx;
    zT_12 = zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    node = zT_12;
    zT_14 = self->_stub_0;
    saved = zT_14;
    zT_15 = self;
    zT_16 = node.child_1;
    zT_18 = zF_54F95822_semanticAnalyzerRes(zT_15, zT_16);
    (void)zT_18;
    zT_19 = self;
    zT_20 = node.child_0;
    zT_22 = zF_54F95822_semanticAnalyzerRes(zT_19, zT_20);
    self->_stub_0 = zT_22;
    zT_24 = self->store;
    zT_25 = node.child_0;
    zT_28 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    c0_node = zT_28;
    zT_30 = "C0K:K";
    zT_32 = 5;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    c0k_m = zT_31;
    zT_33 = c0k_m;
    zT_35 = c0_node.kind;
    zF_C914CB83_markerWriteInt(zT_33, (unsigned int)((unsigned int)zT_35));
    zT_37 = c0_node.kind;
    if ((int)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_43 = self->store;
    zT_44 = node.child_0;
    zT_47 = zF_53458827_astStoreIdentifier(zT_43, zT_44);
    c0_name_id = zT_47;
    zT_49 = "STE:N";
    zT_51 = 5;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    ste_m = zT_50;
    zT_52 = ste_m;
    zT_53 = node_idx;
    zF_C914CB83_markerWriteInt(zT_52, zT_53);
    src_cur_name = c0_name_id;
    zT_56 = 0;
    src_depth = zT_56;
    zT_58 = 0;
    src_name = zT_58;
    zT_60 = 0;
    src_done = zT_60;
    goto z_bb_3;
    z_bb_2:
    zT_94 = "IX:T";
    zT_96 = 4;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    ix_m = zT_95;
    zT_97 = ix_m;
    zT_98 = self->_stub_0;
    zF_C914CB83_markerWriteInt(zT_97, zT_98);
    zT_100 = self->_stub_0;
    if ((int)(zT_100 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_12;
    z_bb_3:
    if ((int)(src_done == (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_66 = self;
    zT_67 = &src_cur_name;
    zT_68 = &src_done;
    zT_71 = zF_DE5079F2_semaTraceStep(zT_66, zT_67, zT_68);
    src_name = zT_71;
    goto z_bb_6;
    z_bb_5:
    if ((int)(src_name != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_6:
    zT_73 = src_depth + (unsigned int)(1);
    src_depth = zT_73;
    goto z_bb_3;
    z_bb_7:
    zT_63 = src_depth < (unsigned int)(3);
    goto z_bb_9;
    z_bb_8:
    zT_63 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_63) goto z_bb_4; else goto z_bb_5;
    z_bb_10:
    zT_77 = "SRC:N";
    zT_79 = 5;
    zT_78.ptr = zT_77;
    zT_78.len = zT_79;
    srs_n = zT_78;
    zT_80 = srs_n;
    zT_81 = node_idx;
    zF_C914CB83_markerWriteInt(zT_80, zT_81);
    zT_83 = "SRC:S";
    zT_85 = 5;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    srs_s = zT_84;
    zT_86 = srs_s;
    zT_87 = src_name;
    zF_C914CB83_markerWriteInt(zT_86, zT_87);
    zT_88 = self->type_table;
    zT_89 = node.child_0;
    zT_90 = src_name;
    zF_D976B454_resolvedSourceTable(zT_88, zT_89, zT_90);
    (void)self;
    goto z_bb_11;
    z_bb_11:
    goto z_bb_2;
    z_bb_12:
    zT_104 = self->_stub_0;
    zT_103 = zT_104 == (unsigned int)(1);
    goto z_bb_14;
    z_bb_13:
    zT_103 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_103) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    self->_stub_0 = saved;
    zT_107 = self->type_table;
    zT_108 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_107, zT_108, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_16:
    zT_114 = self->registry;
    zT_115 = zT_114->types_items;
    zT_116 = self->_stub_0;
    zT_117 = (unsigned int)zT_116;
    zT_118 = zT_115[zT_117];
    bt = zT_118;
    zT_120 = self->registry;
    zT_121 = self->_stub_0;
    zT_124 = zF_E02A7BC0_typeRegistryIndexed(zT_120, zT_121);
    ix_elem = zT_124;
    if ((int)(ix_elem != (unsigned int)(18))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_128 = "IX:R";
    zT_130 = 4;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    ixr_m = zT_129;
    zT_131 = ixr_m;
    zT_132 = ix_elem;
    zF_C914CB83_markerWriteInt(zT_131, zT_132);
    self->_stub_0 = saved;
    return ix_elem;
    z_bb_18:
    zT_157 = 0;
    nidx_bad = zT_157;
    zT_158 = bt.kind;
    if ((int)(zT_158 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_19:
    zT_133 = bt.kind;
    if ((int)(zT_133 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_139 = self->registry;
    zT_140 = zT_139->tup_items;
    zT_141 = bt.payload_idx;
    zT_142 = (unsigned int)zT_141;
    zT_143 = zT_140[zT_142];
    tp = zT_143;
    zT_145 = self->registry;
    zT_146 = zT_145->xt_items;
    zT_147 = tp.elems_start;
    zT_148 = (unsigned int)zT_147;
    zT_149 = zT_146[zT_148];
    r4 = zT_149;
    zT_151 = "IX:R";
    zT_153 = 4;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    ixr_m = zT_152;
    zT_154 = ixr_m;
    zT_155 = r4;
    zF_C914CB83_markerWriteInt(zT_154, zT_155);
    self->_stub_0 = saved;
    return r4;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_164 = bt.kind;
    zT_163 = zT_164 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type);
    goto z_bb_24;
    z_bb_23:
    zT_163 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_163) goto z_bb_26; else goto z_bb_25;
    z_bb_25:
    zT_170 = bt.kind;
    zT_169 = zT_170 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_27;
    z_bb_26:
    zT_169 = 1;
    goto z_bb_27;
    z_bb_27:
    if (zT_169) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_176 = bt.kind;
    zT_175 = zT_176 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_30;
    z_bb_29:
    zT_175 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_175) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_182 = bt.kind;
    zT_181 = zT_182 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_33;
    z_bb_32:
    zT_181 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_181) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_188 = bt.kind;
    zT_187 = zT_188 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_36;
    z_bb_35:
    zT_187 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_187) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_194 = bt.kind;
    zT_193 = zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_39;
    z_bb_38:
    zT_193 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_193) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_200 = bt.kind;
    zT_199 = zT_200 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_42;
    z_bb_41:
    zT_199 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_199) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_206 = bt.kind;
    zT_205 = zT_206 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_45;
    z_bb_44:
    zT_205 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_205) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_212 = bt.kind;
    zT_211 = zT_212 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_48;
    z_bb_47:
    zT_211 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_211) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_218 = bt.kind;
    zT_217 = zT_218 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_51;
    z_bb_50:
    zT_217 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_217) goto z_bb_53; else goto z_bb_52;
    z_bb_52:
    zT_224 = bt.kind;
    zT_223 = zT_224 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type);
    goto z_bb_54;
    z_bb_53:
    zT_223 = 1;
    goto z_bb_54;
    z_bb_54:
    if (zT_223) goto z_bb_56; else goto z_bb_55;
    z_bb_55:
    zT_230 = bt.kind;
    zT_229 = zT_230 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type);
    goto z_bb_57;
    z_bb_56:
    zT_229 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_229) goto z_bb_59; else goto z_bb_58;
    z_bb_58:
    zT_236 = bt.kind;
    zT_235 = zT_236 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_60;
    z_bb_59:
    zT_235 = 1;
    goto z_bb_60;
    z_bb_60:
    if (zT_235) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_242 = bt.kind;
    zT_241 = zT_242 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_63;
    z_bb_62:
    zT_241 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_241) goto z_bb_65; else goto z_bb_64;
    z_bb_64:
    zT_248 = bt.kind;
    zT_247 = zT_248 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_66;
    z_bb_65:
    zT_247 = 1;
    goto z_bb_66;
    z_bb_66:
    if (zT_247) goto z_bb_68; else goto z_bb_67;
    z_bb_67:
    zT_254 = bt.kind;
    zT_253 = zT_254 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_69;
    z_bb_68:
    zT_253 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_253) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_260 = bt.kind;
    zT_259 = zT_260 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_72;
    z_bb_71:
    zT_259 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_259) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_266 = bt.kind;
    zT_265 = zT_266 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_75;
    z_bb_74:
    zT_265 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_265) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_272 = bt.kind;
    zT_271 = zT_272 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_78;
    z_bb_77:
    zT_271 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_271) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_278 = bt.kind;
    zT_277 = zT_278 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_81;
    z_bb_80:
    zT_277 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_277) goto z_bb_83; else goto z_bb_82;
    z_bb_82:
    zT_284 = bt.kind;
    zT_283 = zT_284 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_84;
    z_bb_83:
    zT_283 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_283) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_290 = bt.kind;
    zT_289 = zT_290 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_87;
    z_bb_86:
    zT_289 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_289) goto z_bb_89; else goto z_bb_88;
    z_bb_88:
    zT_296 = bt.kind;
    zT_295 = zT_296 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type);
    goto z_bb_90;
    z_bb_89:
    zT_295 = 1;
    goto z_bb_90;
    z_bb_90:
    if (zT_295) goto z_bb_92; else goto z_bb_91;
    z_bb_91:
    zT_302 = bt.kind;
    zT_301 = zT_302 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type);
    goto z_bb_93;
    z_bb_92:
    zT_301 = 1;
    goto z_bb_93;
    z_bb_93:
    if (zT_301) goto z_bb_95; else goto z_bb_94;
    z_bb_94:
    zT_308 = bt.kind;
    zT_307 = zT_308 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type);
    goto z_bb_96;
    z_bb_95:
    zT_307 = 1;
    goto z_bb_96;
    z_bb_96:
    if (zT_307) goto z_bb_98; else goto z_bb_97;
    z_bb_97:
    zT_314 = bt.kind;
    zT_313 = zT_314 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type);
    goto z_bb_99;
    z_bb_98:
    zT_313 = 1;
    goto z_bb_99;
    z_bb_99:
    if (zT_313) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_319 = 1;
    nidx_bad = zT_319;
    goto z_bb_101;
    z_bb_101:
    if ((int)(nidx_bad != (unsigned char)(0))) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_323 = "cannot index a value of non-array, non-pointer type";
    zT_325 = 51;
    zT_324.ptr = zT_323;
    zT_324.len = zT_325;
    nidx_msg = zT_324;
    zT_326 = self->diag;
    zT_329 = self->source_file_id;
    zT_330 = node.span_start;
    zT_338 = node.span_start;
    zT_339 = node.span_len;
    zT_332 = nidx_msg;
    zT_342 = zF_C82559AC_diagnosticCollector(zT_326, (unsigned char)(0), (unsigned short)(3000), zT_329, zT_330, (unsigned int)(zT_338 + (unsigned int)((unsigned int)zT_339)), zT_332);
    (void)zT_342;
    self->_stub_0 = saved;
    zT_343 = self->type_table;
    zT_344 = node_idx;
    zF_19B4A07D_resolvedTypeTableSe(zT_343, zT_344, (unsigned int)(1));
    return (unsigned int)(1);
    z_bb_103:
    zT_350 = self->_stub_0;
    ret = zT_350;
    self->_stub_0 = saved;
    return ret;
}

/* semanticAnalyzerResolveSliceExpr */
unsigned int zF_F902E73E_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    zT_38C12417_SemanticAnalyzer* zT_9;
    unsigned int zT_10;
    unsigned int zT_12 = 0;
    unsigned int zT_13;
    zT_38C12417_SemanticAnalyzer* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    unsigned int zT_20;
    zT_38C12417_SemanticAnalyzer* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    int zT_30;
    unsigned int zT_31;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_D155D06D_Type zT_40;
    zT_33EF6BFB_TypeKind zT_41;
    int zT_46;
    zT_33EF6BFB_TypeKind zT_47;
    int zT_52;
    zT_33EF6BFB_TypeKind zT_53;
    int zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_80 = 0;
    zT_338B7C76_TypeRegistry* zT_84;
    unsigned int zT_85;
    unsigned int zT_88 = 0;
    unsigned int zT_91;
    unsigned int zT_92;
    int zT_97;
    zT_33EF6BFB_TypeKind zT_98;
    int zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    int zT_109;
    zT_33EF6BFB_TypeKind zT_110;
    int zT_115;
    zT_33EF6BFB_TypeKind zT_116;
    unsigned char zT_121;
    int zT_126;
    zT_338B7C76_TypeRegistry* zT_128;
    unsigned int zT_129;
    int zT_130;
    unsigned int zT_133 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    zT_D155D06D_Type bt;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl_msg;
    unsigned int ix_elem2;
    int se_is_const;
    unsigned int ret;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_9 = self;
    zT_10 = node.child_0;
    zT_12 = zF_54F95822_semanticAnalyzerRes(zT_9, zT_10);
    self->_stub_0 = zT_12;
    zT_13 = node.child_1;
    if ((int)(zT_13 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = self;
    zT_17 = node.child_1;
    zT_19 = zF_54F95822_semanticAnalyzerRes(zT_16, zT_17);
    (void)zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_20 = node.child_2;
    if ((int)(zT_20 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_23 = self;
    zT_24 = node.child_2;
    zT_26 = zF_54F95822_semanticAnalyzerRes(zT_23, zT_24);
    (void)zT_26;
    goto z_bb_4;
    z_bb_4:
    zT_27 = self->_stub_0;
    if ((int)(zT_27 == (unsigned int)(0))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_31 = self->_stub_0;
    zT_30 = zT_31 == (unsigned int)(1);
    goto z_bb_7;
    z_bb_6:
    zT_30 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_9:
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_38 = self->_stub_0;
    zT_39 = (unsigned int)zT_38;
    zT_40 = zT_37[zT_39];
    bt = zT_40;
    zT_41 = bt.kind;
    if ((int)(zT_41 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_47 = bt.kind;
    zT_46 = zT_47 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_12;
    z_bb_11:
    zT_46 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_46) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_53 = bt.kind;
    zT_52 = zT_53 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_15;
    z_bb_14:
    zT_52 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_52) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_59 = bt.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_18;
    z_bb_17:
    zT_58 = 1;
    goto z_bb_18;
    z_bb_18:
    if ((int)(!zT_58)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_66 = "cannot slice base type: expected array, slice, or many-pointer";
    zT_68 = 62;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    sl_msg = zT_67;
    zT_69 = self->diag;
    zT_72 = self->source_file_id;
    zT_73 = node_idx;
    zT_74 = node_idx;
    zT_75 = sl_msg;
    zT_80 = zF_C82559AC_diagnosticCollector(zT_69, (unsigned char)(0), (unsigned short)(2000), zT_72, zT_73, zT_74, zT_75);
    (void)zT_80;
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_20:
    self->_stub_1 = (unsigned int)(1);
    zT_84 = self->registry;
    zT_85 = self->_stub_0;
    zT_88 = zF_E02A7BC0_typeRegistryIndexed(zT_84, zT_85);
    ix_elem2 = zT_88;
    if ((int)(ix_elem2 != (unsigned int)(18))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    self->_stub_1 = ix_elem2;
    goto z_bb_22;
    z_bb_22:
    zT_92 = self->_stub_1;
    if ((int)(zT_92 == (unsigned int)(1))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_91 = self->_stub_0;
    self->_stub_1 = zT_91;
    goto z_bb_22;
    z_bb_24:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_25:
    zT_97 = 0;
    se_is_const = zT_97;
    zT_98 = bt.kind;
    if ((int)(zT_98 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_104 = bt.kind;
    zT_103 = zT_104 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_28;
    z_bb_27:
    zT_103 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_103) goto z_bb_30; else goto z_bb_29;
    z_bb_29:
    zT_110 = bt.kind;
    zT_109 = zT_110 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_31;
    z_bb_30:
    zT_109 = 1;
    goto z_bb_31;
    z_bb_31:
    if (zT_109) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_116 = bt.kind;
    zT_115 = zT_116 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_34;
    z_bb_33:
    zT_115 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_115) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_121 = bt.flags;
    if ((int)((unsigned char)(zT_121 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_128 = self->registry;
    zT_129 = self->_stub_1;
    zT_130 = se_is_const;
    zT_133 = zF_8FC81A87_typeRegistryGetOrCr(zT_128, zT_129, zT_130);
    ret = zT_133;
    self->_stub_0 = saved;
    return ret;
    z_bb_37:
    zT_126 = 1;
    se_is_const = zT_126;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_36;
}

/* semanticAnalyzerResolveTupleLiteral */
unsigned int zF_227D2404_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_13 = {0};
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned int* zT_31;
    unsigned int zT_33 = 0;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    unsigned int zT_43;
    zT_338B7C76_TypeRegistry* zT_44;
    unsigned int zT_45;
    unsigned int zT_49;
    unsigned int zT_51 = 0;
    unsigned int saved;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int start;
    unsigned int i;
    zT_3 = self->store;
    zT_4 = node_idx;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_850FDF81_astStoreNodeExtraCh(zT_10, zT_11);
    ec = zT_13;
    zT_15 = ec.len;
    if ((int)(zT_15 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_2:
    zT_20 = self->registry;
    zT_21 = zT_20->xt_len;
    zT_22 = (unsigned int)zT_21;
    start = zT_22;
    zT_24 = 0;
    zT_25 = (unsigned int)zT_24;
    i = zT_25;
    goto z_bb_3;
    z_bb_3:
    zT_27 = ec.len;
    if ((int)(i < zT_27)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_29 = self;
    zT_31 = ec.ptr;
    zT_30 = zT_31[i];
    zT_33 = zF_54F95822_semanticAnalyzerRes(zT_29, zT_30);
    self->_stub_0 = zT_33;
    zT_34 = self->_stub_0;
    if ((int)(zT_34 == (unsigned int)(1))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    self->_stub_0 = saved;
    zT_44 = self->registry;
    zT_45 = start;
    zT_49 = ec.len;
    zT_51 = zF_9996320F_typeRegistryGetOrCr(zT_44, zT_45, (unsigned short)((unsigned short)zT_49));
    return zT_51;
    z_bb_6:
    zT_43 = i + (unsigned int)(1);
    i = zT_43;
    goto z_bb_3;
    z_bb_7:
    self->_stub_0 = (unsigned int)(6);
    goto z_bb_8;
    z_bb_8:
    zT_38 = self->registry;
    zT_39 = self->_stub_0;
    zF_4C03AE3D_xtAppend(zT_38, zT_39);
    goto z_bb_6;
}

/* semanticAnalyzerResolveArrayInit */
unsigned int zF_F3DAABE0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_338B7C76_TypeRegistry* zT_27;
    zT_D155D06D_Type* zT_28;
    unsigned int zT_29;
    zT_D155D06D_Type zT_30;
    zT_33EF6BFB_TypeKind zT_31;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_44 = {0};
    zT_8143F551_AstKind zT_45;
    zT_ABC1EBBE_TypeResolveEnv zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    zT_338B7C76_TypeRegistry* zT_53;
    zT_3D7259E2_SymbolRegistry* zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    unsigned int zT_56;
    zT_F85C5DED_DiagnosticCollector* zT_57;
    zT_7334F4FE_Opt_225 zT_58;
    zT_E2DF2801_LocalConstScope* zT_59;
    zT_F6B96876_Opt_395 zT_60;
    unsigned int zT_61;
    zT_ABC1EBBE_TypeResolveEnv* zT_63;
    unsigned int zT_64;
    unsigned int zT_69 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    zT_D155D06D_Type* zT_75;
    unsigned int zT_76;
    zT_D155D06D_Type zT_77;
    zT_33EF6BFB_TypeKind zT_78;
    zT_8EED1867_ResolvedTypeTable* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    zT_22A7C88B_AstNode zT_96 = {0};
    int zT_98;
    zT_8143F551_AstKind zT_99;
    int zT_104;
    unsigned int zT_105;
    zT_6B0A7D14_AstStore* zT_109;
    unsigned int zT_110;
    zT_22A7C88B_AstNode zT_113 = {0};
    zT_8143F551_AstKind zT_114;
    zT_6B0A7D14_AstStore* zT_120;
    unsigned int zT_121;
    unsigned int zT_124 = 0;
    zT_D3EB6303_StringInterner* zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129 = {0};
    unsigned int zT_131;
    int zT_134;
    unsigned char* zT_135;
    int zT_136;
    unsigned char zT_137;
    int zT_140;
    int zT_141;
    unsigned int zT_142;
    zT_ABC1EBBE_TypeResolveEnv zT_146;
    zT_6B0A7D14_AstStore* zT_147;
    zT_338B7C76_TypeRegistry* zT_148;
    zT_3D7259E2_SymbolRegistry* zT_149;
    zT_D3EB6303_StringInterner* zT_150;
    unsigned int zT_151;
    zT_F85C5DED_DiagnosticCollector* zT_152;
    zT_7334F4FE_Opt_225 zT_153;
    zT_E2DF2801_LocalConstScope* zT_154;
    zT_F6B96876_Opt_395 zT_155;
    unsigned int zT_156;
    zT_ABC1EBBE_TypeResolveEnv* zT_158;
    unsigned int zT_159;
    unsigned int zT_164 = 0;
    zT_6B0A7D14_AstStore* zT_169;
    unsigned int zT_170;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_172 = {0};
    unsigned int zT_174;
    unsigned int zT_183;
    unsigned int zT_185;
    unsigned int zT_187;
    zT_6B0A7D14_AstStore* zT_190;
    unsigned int zT_191;
    unsigned int* zT_193;
    zT_22A7C88B_AstNode zT_195 = {0};
    unsigned int zT_198;
    zT_8143F551_AstKind zT_199;
    unsigned int zT_204;
    zT_8143F551_AstKind zT_205;
    unsigned int zT_210;
    zT_38C12417_SemanticAnalyzer* zT_211;
    unsigned int zT_212;
    unsigned int* zT_213;
    unsigned int zT_215 = 0;
    unsigned int zT_222;
    zT_338B7C76_TypeRegistry* zT_229;
    unsigned int zT_230;
    unsigned int zT_234;
    unsigned int zT_236 = 0;
    zT_338B7C76_TypeRegistry* zT_238;
    unsigned int zT_239;
    unsigned int zT_243;
    unsigned int zT_245 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int saved;
    unsigned int annot_tid;
    unsigned int annot_elem_tid;
    zT_BAEE192E_Opt_10 rt;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    unsigned int t;
    zT_D155D06D_Type tt;
    zT_22A7C88B_AstNode ann_kind_node;
    zT_ABC1EBBE_TypeResolveEnv tre_env0;
    unsigned int at0;
    zT_D155D06D_Type at0ty;
    zT_22A7C88B_AstNode annot_node;
    int inferred_len;
    zT_22A7C88B_AstNode sz_node;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_ABC1EBBE_TypeResolveEnv tre_env;
    unsigned int et;
    unsigned int arr_elem_tid;
    unsigned int aei;
    zT_22A7C88B_AstNode el;
    unsigned int el_tid;
    unsigned int arr_tid;
    zT_3 = self->store;
    zT_4 = node_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    node = zT_6;
    zT_8 = self->_stub_0;
    saved = zT_8;
    zT_11 = 18;
    annot_tid = zT_11;
    zT_14 = 18;
    annot_elem_tid = zT_14;
    zT_15 = node.child_0;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->type_table;
    zT_20 = node.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_169 = self->store;
    zT_170 = node_idx;
    zT_172 = zF_850FDF81_astStoreNodeExtraCh(zT_169, zT_170);
    ec = zT_172;
    zT_174 = ec.len;
    if ((int)(zT_174 == (unsigned int)(0))) goto z_bb_36; else goto z_bb_37;
    z_bb_3:
    t = rt.value;
    zT_27 = self->registry;
    zT_28 = zT_27->types_items;
    zT_29 = (unsigned int)t;
    zT_30 = zT_28[zT_29];
    tt = zT_30;
    zT_31 = tt.kind;
    if ((int)(zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((int)(annot_tid == (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    annot_tid = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_40 = self->store;
    zT_41 = node.child_0;
    zT_44 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    ann_kind_node = zT_44;
    zT_45 = ann_kind_node.kind;
    if ((int)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((int)(annot_tid == (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_9:
    zT_52 = self->store;
    zT_51.store = zT_52;
    zT_53 = self->registry;
    zT_51.typereg = zT_53;
    zT_54 = self->symbols;
    zT_51.symbol_reg = zT_54;
    zT_55 = self->interner;
    zT_51.interner = zT_55;
    zT_56 = self->module_id;
    zT_51.module_id = zT_56;
    zT_57 = self->diag;
    zT_58.has_value = 1;
    zT_58.value = zT_57;
    zT_51.diag = zT_58;
    zT_59 = &self->local_consts;
    zT_60.has_value = 1;
    zT_60.value = zT_59;
    zT_51.local_consts = zT_60;
    zT_61 = self->source_file_id;
    zT_51.source_file_id = zT_61;
    tre_env0 = zT_51;
    zT_63 = &tre_env0;
    zT_64 = node.child_0;
    zT_69 = zF_F2107C15_resolveTypeExprFull(zT_63, zT_64, (unsigned int)(0));
    at0 = zT_69;
    if ((int)(at0 != (unsigned int)(18))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    zT_74 = self->registry;
    zT_75 = zT_74->types_items;
    zT_76 = (unsigned int)at0;
    zT_77 = zT_75[zT_76];
    at0ty = zT_77;
    zT_78 = at0ty.kind;
    if ((int)(zT_78 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    annot_tid = at0;
    zT_83 = self->type_table;
    zT_84 = node.child_0;
    zT_85 = at0;
    zF_19B4A07D_resolvedTypeTableSe(zT_83, zT_84, zT_85);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_92 = self->store;
    zT_93 = node.child_0;
    zT_96 = zF_FCDD1D35_astStoreNodeAt(zT_92, zT_93);
    annot_node = zT_96;
    zT_98 = 0;
    inferred_len = zT_98;
    zT_99 = annot_node.kind;
    if ((int)(zT_99 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_2;
    z_bb_17:
    zT_105 = annot_node.child_1;
    zT_104 = zT_105 != (unsigned int)(0);
    goto z_bb_19;
    z_bb_18:
    zT_104 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_104) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_109 = self->store;
    zT_110 = annot_node.child_1;
    zT_113 = zF_FCDD1D35_astStoreNodeAt(zT_109, zT_110);
    sz_node = zT_113;
    zT_114 = sz_node.kind;
    if ((int)(zT_114 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    if (inferred_len) goto z_bb_29; else goto z_bb_30;
    z_bb_22:
    zT_120 = self->store;
    zT_121 = annot_node.child_1;
    zT_124 = zF_53458827_astStoreIdentifier(zT_120, zT_121);
    sz_name = zT_124;
    zT_126 = self->interner;
    zT_127 = sz_name;
    zT_129 = zF_9134020D_stringInternerGet(zT_126, zT_127);
    sz_text = zT_129;
    zT_131 = sz_text.len;
    if ((int)(zT_131 == (unsigned int)(1))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_135 = sz_text.ptr;
    zT_136 = 0;
    zT_137 = zT_135[zT_136];
    zT_134 = zT_137 == (unsigned char)(95);
    goto z_bb_26;
    z_bb_25:
    zT_134 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_134) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_140 = 1;
    inferred_len = zT_140;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_142 = annot_node.child_0;
    zT_141 = zT_142 != (unsigned int)(0);
    goto z_bb_31;
    z_bb_30:
    zT_141 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_141) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_147 = self->store;
    zT_146.store = zT_147;
    zT_148 = self->registry;
    zT_146.typereg = zT_148;
    zT_149 = self->symbols;
    zT_146.symbol_reg = zT_149;
    zT_150 = self->interner;
    zT_146.interner = zT_150;
    zT_151 = self->module_id;
    zT_146.module_id = zT_151;
    zT_152 = self->diag;
    zT_153.has_value = 1;
    zT_153.value = zT_152;
    zT_146.diag = zT_153;
    zT_154 = &self->local_consts;
    zT_155.has_value = 1;
    zT_155.value = zT_154;
    zT_146.local_consts = zT_155;
    zT_156 = self->source_file_id;
    zT_146.source_file_id = zT_156;
    tre_env = zT_146;
    zT_158 = &tre_env;
    zT_159 = annot_node.child_0;
    zT_164 = zF_F2107C15_resolveTypeExprFull(zT_158, zT_159, (unsigned int)(0));
    et = zT_164;
    if ((int)(et != (unsigned int)(18))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    goto z_bb_16;
    z_bb_34:
    annot_elem_tid = et;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    self->_stub_0 = saved;
    if ((int)(annot_tid != (unsigned int)(18))) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    zT_183 = 1;
    arr_elem_tid = zT_183;
    zT_185 = 0;
    aei = zT_185;
    goto z_bb_40;
    z_bb_38:
    return annot_tid;
    z_bb_39:
    return (unsigned int)(1);
    z_bb_40:
    zT_187 = ec.len;
    if ((int)(aei < zT_187)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_190 = self->store;
    zT_193 = ec.ptr;
    zT_191 = zT_193[aei];
    zT_195 = zF_FCDD1D35_astStoreNodeAt(zT_190, zT_191);
    el = zT_195;
    zT_198 = 1;
    el_tid = zT_198;
    zT_199 = el.kind;
    if ((int)(zT_199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_44; else goto z_bb_46;
    z_bb_42:
    if ((int)(annot_tid != (unsigned int)(18))) goto z_bb_54; else goto z_bb_55;
    z_bb_43:
    zT_222 = aei + (unsigned int)(1);
    aei = zT_222;
    goto z_bb_40;
    z_bb_44:
    zT_204 = 8;
    el_tid = zT_204;
    goto z_bb_45;
    z_bb_45:
    if ((int)(el_tid == (unsigned int)(1))) goto z_bb_50; else goto z_bb_51;
    z_bb_46:
    zT_205 = el.kind;
    if ((int)(zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_47; else goto z_bb_49;
    z_bb_47:
    zT_210 = 10;
    el_tid = zT_210;
    goto z_bb_48;
    z_bb_48:
    goto z_bb_45;
    z_bb_49:
    zT_211 = self;
    zT_213 = ec.ptr;
    zT_212 = zT_213[aei];
    zT_215 = zF_54F95822_semanticAnalyzerRes(zT_211, zT_212);
    el_tid = zT_215;
    goto z_bb_48;
    z_bb_50:
    self->_stub_0 = saved;
    return (unsigned int)(1);
    z_bb_51:
    if ((int)(aei == (unsigned int)(0))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    arr_elem_tid = el_tid;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_43;
    z_bb_54:
    self->_stub_0 = saved;
    return annot_tid;
    z_bb_55:
    if ((int)(annot_elem_tid != (unsigned int)(18))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    self->_stub_0 = saved;
    zT_229 = self->registry;
    zT_230 = annot_elem_tid;
    zT_234 = ec.len;
    zT_236 = zF_BA693C74_typeRegistryGetOrCr(zT_229, zT_230, (unsigned int)((unsigned int)zT_234));
    return zT_236;
    z_bb_57:
    zT_238 = self->registry;
    zT_239 = arr_elem_tid;
    zT_243 = ec.len;
    zT_245 = zF_BA693C74_typeRegistryGetOrCr(zT_238, zT_239, (unsigned int)((unsigned int)zT_243));
    arr_tid = zT_245;
    self->_stub_0 = saved;
    return arr_tid;
}

/* semanticAnalyzerResolveStmt */
void zF_979B6CFF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int node_idx) {
    zT_38C12417_SemanticAnalyzer* zT_2;
    unsigned int zT_3;
    zT_2 = self;
    zT_3 = node_idx;
    zF_10A0DC35_semanticAnalyzerRes(zT_2, zT_3);
    return;
}

/* semanticAnalyzerResolveModuleVarDecl */
unsigned int zF_CC4377FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer* self, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    zT_22A7C88B_AstNode zT_6 = {0};
    unsigned int zT_7;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    zT_38C12417_SemanticAnalyzer* zT_26;
    unsigned int zT_27;
    zT_38C12417_SemanticAnalyzer* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_38C12417_SemanticAnalyzer* zT_33;
    int zT_37;
    zT_38C12417_SemanticAnalyzer* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45 = 0;
    zT_38C12417_SemanticAnalyzer* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    int zT_51 = 0;
    zT_338B7C76_TypeRegistry* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_0FB7FB13_CoercionKind zT_57 = 0;
    zT_66E7D2EF_CoercionTable* zT_62;
    unsigned int zT_63;
    zT_0FB7FB13_CoercionKind zT_64;
    unsigned int zT_65;
    zT_22A7C88B_AstNode decl;
    unsigned int decl_type;
    zT_BAEE192E_Opt_10 rt;
    unsigned int it;
    unsigned int t;
    unsigned int it_eff;
    zT_0FB7FB13_CoercionKind ck;
    zT_3 = self->store;
    zT_4 = decl_idx;
    zT_6 = zF_FCDD1D35_astStoreNodeAt(zT_3, zT_4);
    decl = zT_6;
    zT_7 = decl.child_1;
    if ((int)(zT_7 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_14 = 18;
    decl_type = zT_14;
    zT_15 = decl.child_0;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = self->type_table;
    zT_20 = decl.child_0;
    zT_23 = zF_999DCF51_resolvedTypeTableGe(zT_19, zT_20);
    rt = zT_23;
    zT_24 = rt.has_value;
    if (zT_24) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_26 = self;
    zT_27 = decl_type;
    zF_9665A229_pushExpectedType(zT_26, zT_27);
    zT_29 = self;
    zT_30 = decl.child_1;
    zT_32 = zF_54F95822_semanticAnalyzerRes(zT_29, zT_30);
    it = zT_32;
    zT_33 = self;
    zF_BC478E78_popExpectedType(zT_33);
    if ((int)(decl_type != (unsigned int)(18))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    t = rt.value;
    decl_type = t;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_37 = it != decl_type;
    goto z_bb_9;
    z_bb_8:
    zT_37 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_37) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_40 = self;
    zT_41 = decl.child_1;
    zT_42 = decl_type;
    zT_43 = it;
    zT_45 = zF_FFC95E09_errLitSrcType(zT_40, zT_41, zT_42, zT_43);
    it_eff = zT_45;
    zT_46 = self;
    zT_47 = decl.child_1;
    zT_48 = it_eff;
    zT_49 = decl_type;
    zT_51 = zF_86AAA417_semanticAnalyzerMay(zT_46, zT_47, zT_48, zT_49);
    if (zT_51) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return it;
    z_bb_12:
    return it;
    z_bb_13:
    zT_53 = self->registry;
    zT_54 = it_eff;
    zT_55 = decl_type;
    zT_57 = zF_713658BF_classifyCoercion(zT_53, zT_54, zT_55);
    ck = zT_57;
    if ((int)(ck != (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_62 = self->coercion_table;
    zT_63 = decl.child_1;
    zT_64 = ck;
    zT_65 = decl_type;
    zF_D21AE60A_coercionTableAdd(zT_62, zT_63, zT_64, zT_65);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_11;
}

/* EOF */
