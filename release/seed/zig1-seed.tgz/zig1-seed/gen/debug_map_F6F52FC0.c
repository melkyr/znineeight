#include "debug_map_F6F52FC0.h"
unsigned int const zG_24C75564_HEADER_LEN = (unsigned int)(20);
unsigned int const zG_D3BBB9B7_VERSION = (unsigned int)(1);
/* magicSyms */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_DEE7AA30_magicSyms(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_1 = "Z98DBGsy";
    zT_3 = 8;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    s = zT_2;
    return s;
}

/* magicLines */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4FFC9427_magicLines(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_1 = "Z98DBGln";
    zT_3 = 8;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    s = zT_2;
    return s;
}

/* magicCnames */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_ED717857_magicCnames(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_1 = "Z98DBGcn";
    zT_3 = 8;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    s = zT_2;
    return s;
}

/* minUsize */
unsigned int zF_E2575727_minUsize(unsigned int a, unsigned int b) {
    if ((unsigned char)(a < b)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return a;
    z_bb_2:
    return b;
}

/* strCompare */
int zF_7814455F_strCompare(zT_8F083A69_Slice_zT_0B42B2F8_u a, zT_8F083A69_Slice_zT_0B42B2F8_u b) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_9 = 0;
    unsigned int zT_11;
    unsigned char* zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char zT_16;
    int zT_18;
    int zT_19;
    unsigned char* zT_21;
    unsigned char zT_22;
    unsigned char* zT_23;
    unsigned char zT_24;
    int zT_26;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned int zT_33;
    int zT_35;
    int zT_36;
    unsigned int zT_39;
    unsigned int zT_41;
    int zT_43;
    int zT_45;
    unsigned int n;
    unsigned int i;
    zT_3 = a.len;
    zT_4 = b.len;
    zT_9 = zF_E2575727_minUsize(zT_3, zT_4);
    n = zT_9;
    zT_11 = 0;
    i = zT_11;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < n)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = a.ptr;
    zT_14 = zT_13[i];
    zT_15 = b.ptr;
    zT_16 = zT_15[i];
    if ((unsigned char)(zT_14 < zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_31 = a.len;
    zT_33 = b.len;
    if ((unsigned char)(zT_31 < zT_33)) goto z_bb_9; else goto z_bb_10;
    z_bb_4:
    zT_29 = i + (unsigned int)(1);
    i = zT_29;
    goto z_bb_1;
    z_bb_5:
    zT_18 = 1;
    zT_19 = -zT_18;
    return (int)((int)zT_19);
    z_bb_6:
    zT_21 = a.ptr;
    zT_22 = zT_21[i];
    zT_23 = b.ptr;
    zT_24 = zT_23[i];
    if ((unsigned char)(zT_22 > zT_24)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_26 = 1;
    return (int)((int)zT_26);
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_35 = 1;
    zT_36 = -zT_35;
    return (int)((int)zT_36);
    z_bb_10:
    zT_39 = a.len;
    zT_41 = b.len;
    if ((unsigned char)(zT_39 > zT_41)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_43 = 1;
    return (int)((int)zT_43);
    z_bb_12:
    zT_45 = 0;
    return (int)((int)zT_45);
}

/* debugSpanStoreInit */
zT_C615AE29_DebugSpanStore zF_A1EED937_debugSpanStoreInit(void) {
    zT_C615AE29_DebugSpanStore zT_0;
    zT_D21A8776_SpillStore zT_1 = {0};
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned char zT_6;
    zT_1 = zF_22C79E6C_spillStoreInit();
    zT_0.spill = zT_1;
    zT_2 = 0;
    zT_0.index_items = (zT_4C3DEF60_DebugFnSpanIndex*)zT_2;
    zT_3 = 0;
    zT_0.index_len = zT_3;
    zT_4 = 0;
    zT_0.index_capacity = zT_4;
    zT_5 = 0;
    zT_0.alloc = (zT_3E40CD83_Sand*)zT_5;
    zT_6 = 0;
    zT_0.enabled = zT_6;
    return zT_0;
}

/* debugSpanIndexEnsure */
void zF_D0C0DC7A_debugSpanIndexEnsur(zT_C615AE29_DebugSpanStore* self, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_13;
    zT_FDFD82FD_EU_362 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    zT_4C3DEF60_DebugFnSpanIndex* zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_4C3DEF60_DebugFnSpanIndex* zT_30;
    zT_4C3DEF60_DebugFnSpanIndex zT_31;
    unsigned int zT_33;
    unsigned int cap;
    unsigned char* raw;
    zT_4C3DEF60_DebugFnSpanIndex* dst;
    unsigned int i;
    zT_2 = self->index_capacity;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->index_capacity;
    cap = zT_5;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 16;
    cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_13 = self->alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_13, (unsigned int)((unsigned int)(12) * cap), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_11 = cap * (unsigned int)(2);
    cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_22 = zT_20.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_22;
    zT_25 = (zT_4C3DEF60_DebugFnSpanIndex*)raw;
    dst = zT_25;
    zT_27 = 0;
    i = zT_27;
    goto z_bb_12;
    z_bb_12:
    zT_28 = self->index_len;
    if ((unsigned char)(i < zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_30 = self->index_items;
    zT_31 = zT_30[i];
    dst[i] = zT_31;
    goto z_bb_15;
    z_bb_14:
    self->index_items = dst;
    self->index_capacity = cap;
    return;
    z_bb_15:
    zT_33 = i + (unsigned int)(1);
    i = zT_33;
    goto z_bb_12;
}

/* debugSpanStoreOpen */
void zF_7FA61CF5_debugSpanStoreOpen(zT_C615AE29_DebugSpanStore* self, zT_3E40CD83_Sand* alloc, zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    unsigned char* zT_4;
    zT_D21A8776_SpillStore* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned char* zT_9;
    unsigned char* mode;
    self->alloc = alloc;
    zT_4 = "w+b";
    mode = zT_4;
    zT_5 = &self->spill;
    zT_7 = path;
    zT_8 = alloc;
    zT_9 = mode;
    zF_8AF94F71_spillOpen(zT_5, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_7, zT_8, zT_9);
    self->index_len = (unsigned int)(0);
    self->enabled = (unsigned char)(1);
    return;
}

/* debugSpanSort */
void zF_33C87494_debugSpanSort(zT_34BFE5CB_Slice_zT_10BDA76C_D spans) {
    unsigned int zT_2;
    unsigned int zT_4;
    zT_10BDA76C_DebugSpanEntry* zT_7;
    zT_10BDA76C_DebugSpanEntry zT_8;
    zT_10BDA76C_DebugSpanEntry* zT_13;
    unsigned int zT_15;
    zT_10BDA76C_DebugSpanEntry zT_16;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_10BDA76C_DebugSpanEntry* zT_30;
    unsigned int zT_32;
    zT_10BDA76C_DebugSpanEntry* zT_33;
    unsigned int zT_35;
    unsigned int i;
    zT_10BDA76C_DebugSpanEntry key;
    unsigned int j;
    zT_10BDA76C_DebugSpanEntry prev;
    unsigned char after;
    zT_2 = 1;
    i = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_4 = spans.len;
    if ((unsigned char)(i < zT_4)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = spans.ptr;
    zT_8 = zT_7[i];
    key = zT_8;
    j = i;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    zT_35 = i + (unsigned int)(1);
    i = zT_35;
    goto z_bb_1;
    z_bb_5:
    if ((unsigned char)(j > (unsigned int)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_13 = spans.ptr;
    zT_15 = j - (unsigned int)(1);
    zT_16 = zT_13[zT_15];
    prev = zT_16;
    zT_18 = prev.bb;
    zT_19 = key.bb;
    if ((unsigned char)(zT_18 > zT_19)) goto z_bb_10; else goto z_bb_9;
    z_bb_7:
    zT_33 = spans.ptr;
    zT_33[j] = key;
    goto z_bb_4;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_22 = prev.bb;
    zT_23 = key.bb;
    if ((unsigned char)(zT_22 == zT_23)) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    zT_21 = 1;
    goto z_bb_11;
    z_bb_11:
    after = zT_21;
    if ((unsigned char)(!after)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_26 = prev.inst;
    zT_27 = key.inst;
    zT_25 = zT_26 > zT_27;
    goto z_bb_14;
    z_bb_13:
    zT_25 = 0;
    goto z_bb_14;
    z_bb_14:
    zT_21 = zT_25;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_7;
    z_bb_16:
    zT_30 = spans.ptr;
    zT_30[j] = prev;
    zT_32 = j - (unsigned int)(1);
    j = zT_32;
    goto z_bb_8;
}

/* debugStoreWriteU32 */
void zF_FE62D392_debugStoreWriteU32(zT_C615AE29_DebugSpanStore* self, unsigned int value) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_12;
    int zT_13;
    unsigned char zT_18;
    int zT_19;
    unsigned char zT_24;
    int zT_25;
    zT_D21A8776_SpillStore* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_D21A8776_SpillStore zT_30;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_6 = (unsigned char)(unsigned int)(value & (unsigned int)(255));
    zT_7 = 0;
    b[zT_7] = zT_6;
    zT_12 = (unsigned char)(unsigned int)((unsigned int)(value >> (unsigned int)(8)) & (unsigned int)(255));
    zT_13 = 1;
    b[zT_13] = zT_12;
    zT_18 = (unsigned char)(unsigned int)((unsigned int)(value >> (unsigned int)(16)) & (unsigned int)(255));
    zT_19 = 2;
    b[zT_19] = zT_18;
    zT_24 = (unsigned char)(unsigned int)((unsigned int)(value >> (unsigned int)(24)) & (unsigned int)(255));
    zT_25 = 3;
    b[zT_25] = zT_24;
    zT_26 = &self->spill;
    zT_30 = self->spill;
    zT_27 = zT_30.cur;
    zT_34 = 0;
    zT_35 = (unsigned char*)((unsigned char*)b) + zT_34;
    zT_36 = (unsigned int)(4) - zT_34;
    zT_37.ptr = (unsigned char*)zT_35;
    zT_37.len = zT_36;
    zT_28 = zT_37;
    zF_BFB33631_spillWriteAt(zT_26, zT_27, zT_28);
    return;
}

/* debugSpanStoreAppend */
void zF_BB256CBD_debugSpanStoreAppen(zT_C615AE29_DebugSpanStore* self, unsigned int disk_offset, zT_34BFE5CB_Slice_zT_10BDA76C_D spans) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned int zT_8;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_11;
    zT_C615AE29_DebugSpanStore* zT_12;
    unsigned int zT_14;
    zT_4C3DEF60_DebugFnSpanIndex zT_18;
    zT_D21A8776_SpillStore zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_C615AE29_DebugSpanStore* zT_24;
    unsigned int zT_27;
    zT_D21A8776_SpillStore* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    zT_D21A8776_SpillStore zT_33;
    zT_10BDA76C_DebugSpanEntry* zT_36;
    unsigned int zT_39;
    int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_4C3DEF60_DebugFnSpanIndex* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_4C3DEF60_DebugFnSpanIndex rec;
    zT_3 = self->enabled;
    if ((unsigned char)(zT_3 == (unsigned char)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = spans.len;
    zT_6 = zT_8 == (unsigned int)(0);
    goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_6) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_11 = spans;
    zF_33C87494_debugSpanSort(zT_11);
    zT_12 = self;
    zT_14 = self->index_len;
    zF_D0C0DC7A_debugSpanIndexEnsur(zT_12, (unsigned int)(zT_14 + (unsigned int)(1)));
    zT_18.disk_offset = disk_offset;
    zT_19 = self->spill;
    zT_20 = zT_19.cur;
    zT_18.spill_offset = zT_20;
    zT_22 = spans.len;
    zT_23 = (unsigned int)zT_22;
    zT_18.count = zT_23;
    rec = zT_18;
    zT_24 = self;
    zT_27 = spans.len;
    zF_FE62D392_debugStoreWriteU32(zT_24, (unsigned int)((unsigned int)zT_27));
    zT_29 = &self->spill;
    zT_33 = self->spill;
    zT_30 = zT_33.cur;
    zT_36 = spans.ptr;
    zT_39 = spans.len;
    zT_42 = 0;
    zT_43 = (unsigned char*)((unsigned char*)zT_36) + zT_42;
    zT_44 = (unsigned int)(zT_39 * (unsigned int)(12)) - zT_42;
    zT_45.ptr = (unsigned char*)zT_43;
    zT_45.len = zT_44;
    zT_31 = zT_45;
    zF_BFB33631_spillWriteAt(zT_29, zT_30, zT_31);
    zT_46 = self->index_items;
    zT_47 = self->index_len;
    zT_46[zT_47] = rec;
    zT_48 = self->index_len;
    self->index_len = (unsigned int)(zT_48 + (unsigned int)(1));
    return;
}

/* debugSpanStoreLookup */
zT_5EC03ACD_Opt_196 zF_92DA876F_debugSpanStoreLooku(zT_C615AE29_DebugSpanStore* self, unsigned int disk_offset) {
    unsigned char zT_2;
    zT_5EC03ACD_Opt_196 zT_5 = {0};
    unsigned int zT_7;
    unsigned int zT_8;
    zT_4C3DEF60_DebugFnSpanIndex* zT_10;
    zT_4C3DEF60_DebugFnSpanIndex zT_11;
    unsigned int zT_12;
    zT_4C3DEF60_DebugFnSpanIndex* zT_14;
    zT_4C3DEF60_DebugFnSpanIndex zT_15;
    zT_5EC03ACD_Opt_196 zT_16;
    unsigned int zT_18;
    zT_5EC03ACD_Opt_196 zT_19 = {0};
    unsigned int i;
    zT_2 = self->enabled;
    if ((unsigned char)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = 0;
    i = zT_7;
    goto z_bb_3;
    z_bb_3:
    zT_8 = self->index_len;
    if ((unsigned char)(i < zT_8)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->index_items;
    zT_11 = zT_10[i];
    zT_12 = zT_11.disk_offset;
    if ((unsigned char)(zT_12 == disk_offset)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_19.has_value = 0;
    return zT_19;
    z_bb_6:
    zT_18 = i + (unsigned int)(1);
    i = zT_18;
    goto z_bb_3;
    z_bb_7:
    zT_14 = self->index_items;
    zT_15 = zT_14[i];
    zT_16.has_value = 1;
    zT_16.value = zT_15;
    return zT_16;
    z_bb_8:
    goto z_bb_6;
}

/* debugStoreReadU32 */
unsigned int zF_CC56B3A5_debugStoreReadU32(zT_C615AE29_DebugSpanStore* self, unsigned int off) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    zT_D21A8776_SpillStore* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_14;
    unsigned char zT_15;
    int zT_17;
    unsigned char zT_18;
    int zT_23;
    unsigned char zT_24;
    int zT_29;
    unsigned char zT_30;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = &self->spill;
    zT_5 = off;
    zT_10 = 0;
    zT_11 = (unsigned char*)((unsigned char*)b) + zT_10;
    zT_12 = (unsigned int)(4) - zT_10;
    zT_13.ptr = (unsigned char*)zT_11;
    zT_13.len = zT_12;
    zT_6 = zT_13;
    zF_E9F67450_spillReadAt(zT_4, zT_5, zT_6);
    zT_14 = 0;
    zT_15 = b[zT_14];
    zT_17 = 1;
    zT_18 = b[zT_17];
    zT_23 = 2;
    zT_24 = b[zT_23];
    zT_29 = 3;
    zT_30 = b[zT_29];
    return (unsigned int)((unsigned int)((unsigned int)((unsigned int)((unsigned int)zT_15) | (unsigned int)((unsigned int)((unsigned int)zT_18) << (unsigned int)(8))) | (unsigned int)((unsigned int)((unsigned int)zT_24) << (unsigned int)(16))) | (unsigned int)((unsigned int)((unsigned int)zT_30) << (unsigned int)(24)));
}

/* debugSpanStoreRead */
void zF_9C00E029_debugSpanStoreRead(zT_C615AE29_DebugSpanStore* self, zT_4C3DEF60_DebugFnSpanIndex rec, zT_34BFE5CB_Slice_zT_10BDA76C_D dst) {
    unsigned int zT_4;
    zT_C615AE29_DebugSpanStore* zT_8;
    unsigned int zT_9;
    unsigned int zT_11 = 0;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_21;
    zT_D21A8776_SpillStore* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_26;
    zT_10BDA76C_DebugSpanEntry* zT_30;
    int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int count;
    unsigned int n;
    unsigned int byte_len;
    zT_4 = dst.len;
    if ((unsigned char)(zT_4 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = self;
    zT_9 = rec.spill_offset;
    zT_11 = zF_CC56B3A5_debugStoreReadU32(zT_8, zT_9);
    count = zT_11;
    zT_13 = (unsigned int)count;
    n = zT_13;
    zT_15 = dst.len;
    if ((unsigned char)(n > zT_15)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = dst.len;
    n = zT_18;
    goto z_bb_4;
    z_bb_4:
    zT_21 = n * (unsigned int)(12);
    byte_len = zT_21;
    zT_22 = &self->spill;
    zT_26 = rec.spill_offset;
    zT_30 = dst.ptr;
    zT_32 = 0;
    zT_33 = (unsigned char*)((unsigned char*)zT_30) + zT_32;
    zT_34 = byte_len - zT_32;
    zT_35.ptr = (unsigned char*)zT_33;
    zT_35.len = zT_34;
    zT_24 = zT_35;
    zF_E9F67450_spillReadAt(zT_22, (unsigned int)(zT_26 + (unsigned int)(4)), zT_24);
    return;
}

/* debugSpanStoreClose */
void zF_BE98E387_debugSpanStoreClose(zT_C615AE29_DebugSpanStore* self) {
    unsigned char zT_1;
    zT_D21A8776_SpillStore* zT_4;
    zT_1 = self->enabled;
    if ((unsigned char)(zT_1 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = &self->spill;
    zF_DB2CDC3B_spillClose(zT_4);
    self->enabled = (unsigned char)(0);
    return;
}

/* debugSpanLookup */
unsigned int zF_AA3D1D7E_debugSpanLookup(zT_34BFE5CB_Slice_zT_10BDA76C_D spans, unsigned int bb, unsigned int inst) {
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_13;
    zT_10BDA76C_DebugSpanEntry* zT_15;
    zT_10BDA76C_DebugSpanEntry zT_16;
    unsigned int zT_17;
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned char zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned char zT_29;
    unsigned int zT_30;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int lo;
    unsigned int hi;
    unsigned int mid;
    zT_10BDA76C_DebugSpanEntry e;
    zT_4 = 0;
    lo = zT_4;
    zT_7 = spans.len;
    hi = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(lo < hi)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = lo + (unsigned int)((unsigned int)(hi - lo) / (unsigned int)(2));
    mid = zT_13;
    zT_15 = spans.ptr;
    zT_16 = zT_15[mid];
    e = zT_16;
    zT_17 = e.bb;
    if ((unsigned char)(zT_17 < bb)) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_20 = e.bb;
    if ((unsigned char)(zT_20 == bb)) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    zT_19 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_19) goto z_bb_11; else goto z_bb_13;
    z_bb_8:
    zT_23 = e.inst;
    zT_22 = zT_23 < inst;
    goto z_bb_10;
    z_bb_9:
    zT_22 = 0;
    goto z_bb_10;
    z_bb_10:
    zT_19 = zT_22;
    goto z_bb_7;
    z_bb_11:
    zT_26 = mid + (unsigned int)(1);
    lo = zT_26;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_4;
    z_bb_13:
    zT_27 = e.bb;
    if ((unsigned char)(zT_27 > bb)) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_30 = e.bb;
    if ((unsigned char)(zT_30 == bb)) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    zT_29 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_29) goto z_bb_20; else goto z_bb_22;
    z_bb_17:
    zT_33 = e.inst;
    zT_32 = zT_33 > inst;
    goto z_bb_19;
    z_bb_18:
    zT_32 = 0;
    goto z_bb_19;
    z_bb_19:
    zT_29 = zT_32;
    goto z_bb_16;
    z_bb_20:
    hi = mid;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_12;
    z_bb_22:
    zT_35 = e.span_start;
    return zT_35;
}

/* debugSymbolListInit */
zT_8B83E3B4_DebugSymbolList zF_5779AF56_debugSymbolListInit(zT_3E40CD83_Sand* allocator) {
    zT_8B83E3B4_DebugSymbolList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (zT_1001656C_DebugSymbol*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* debugSymbolListEnsure */
void zF_7E8D0B2A_debugSymbolListEnsu(zT_8B83E3B4_DebugSymbolList* self, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_13;
    zT_FDFD82FD_EU_362 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    zT_1001656C_DebugSymbol* zT_25;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_1001656C_DebugSymbol* zT_30;
    zT_1001656C_DebugSymbol zT_31;
    unsigned int zT_33;
    unsigned int cap;
    unsigned char* raw;
    zT_1001656C_DebugSymbol* dst;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->capacity;
    cap = zT_5;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 32;
    cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_13 = self->allocator;
    zT_20 = zF_1395EB68_sandAlloc(zT_13, (unsigned int)((unsigned int)(28) * cap), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_11 = cap * (unsigned int)(2);
    cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_22 = zT_20.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_22;
    zT_25 = (zT_1001656C_DebugSymbol*)raw;
    dst = zT_25;
    zT_27 = 0;
    i = zT_27;
    goto z_bb_12;
    z_bb_12:
    zT_28 = self->len;
    if ((unsigned char)(i < zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_30 = self->items;
    zT_31 = zT_30[i];
    dst[i] = zT_31;
    goto z_bb_15;
    z_bb_14:
    self->items = dst;
    self->capacity = cap;
    return;
    z_bb_15:
    zT_33 = i + (unsigned int)(1);
    i = zT_33;
    goto z_bb_12;
}

/* debugSymbolListAppend */
void zF_3CC05A74_debugSymbolListAppe(zT_8B83E3B4_DebugSymbolList* self, zT_1001656C_DebugSymbol value) {
    zT_8B83E3B4_DebugSymbolList* zT_2;
    unsigned int zT_4;
    zT_1001656C_DebugSymbol* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_2 = self;
    zT_4 = self->len;
    zF_7E8D0B2A_debugSymbolListEnsu(zT_2, (unsigned int)(zT_4 + (unsigned int)(1)));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    self->len = (unsigned int)(zT_9 + (unsigned int)(1));
    return;
}

/* debugSymbolFindFn */
zT_50C024C3_Opt_198 zF_C72C1B0F_debugSymbolFindFn(zT_8B83E3B4_DebugSymbolList* self, unsigned int module_id, zT_8F083A69_Slice_zT_0B42B2F8_u name, zT_D3EB6303_StringInterner* interner) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_1001656C_DebugSymbol* zT_9;
    zT_1001656C_DebugSymbol zT_10;
    unsigned char zT_11;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_D3EB6303_StringInterner* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21 = {0};
    int zT_22 = 0;
    int zT_23;
    zT_50C024C3_Opt_198 zT_25;
    unsigned int zT_27;
    zT_50C024C3_Opt_198 zT_28 = {0};
    unsigned int i;
    zT_1001656C_DebugSymbol s;
    zT_5 = 0;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = self->items;
    zT_10 = zT_9[i];
    s = zT_10;
    zT_11 = s.kind;
    if ((unsigned char)(zT_11 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_28.has_value = 0;
    return zT_28;
    z_bb_4:
    zT_27 = i + (unsigned int)(1);
    i = zT_27;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = s.module_id;
    if ((unsigned char)(zT_14 != module_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_18 = interner;
    zT_19 = s.name_id;
    zT_21 = zF_9134020D_stringInternerGet(zT_18, zT_19);
    zT_16 = zT_21;
    zT_17 = name;
    zT_22 = zF_7814455F_strCompare(zT_16, zT_17);
    zT_23 = 0;
    if ((unsigned char)(zT_22 == zT_23)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_25.has_value = 1;
    zT_25.value = s;
    return zT_25;
    z_bb_10:
    goto z_bb_4;
}

/* debugOutOpen */
void zF_D70BEADC_debugOutOpen(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc, zT_8F083A69_Slice_zT_0B42B2F8_u magic) {
    zT_D21A8776_SpillStore zT_4 = {0};
    unsigned char* zT_6;
    zT_D21A8776_SpillStore* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand* zT_10;
    unsigned char* zT_11;
    zT_D21A8776_SpillStore* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_D21A8776_SpillStore zT_20;
    zT_B5AAF170_Arr_unsigned_char_4 zT_23;
    unsigned char zT_24;
    int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_28;
    int zT_29;
    unsigned char zT_30;
    int zT_31;
    zT_D21A8776_SpillStore* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_D21A8776_SpillStore zT_36;
    int zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_B5AAF170_Arr_unsigned_char_4 zT_45;
    int zT_46;
    unsigned int zT_47;
    int zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    zT_D21A8776_SpillStore* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    zT_D21A8776_SpillStore zT_58;
    int zT_62;
    unsigned char* zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    zT_D21A8776_SpillStore* zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    zT_D21A8776_SpillStore zT_70;
    int zT_74;
    unsigned char* zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned char* mode;
    zT_B5AAF170_Arr_unsigned_char_4 ver;
    zT_B5AAF170_Arr_unsigned_char_4 zero;
    zT_4 = zF_22C79E6C_spillStoreInit();
    out->store = zT_4;
    zT_6 = "w+b";
    mode = zT_6;
    zT_7 = &out->store;
    zT_9 = path;
    zT_10 = alloc;
    zT_11 = mode;
    zF_8AF94F71_spillOpen(zT_7, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_9, zT_10, zT_11);
    out->count = (unsigned int)(0);
    zT_16 = &out->store;
    zT_20 = out->store;
    zT_17 = zT_20.cur;
    zT_18 = magic;
    zF_BFB33631_spillWriteAt(zT_16, zT_17, zT_18);
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_23[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        ver[_i] = zT_23[_i];
        _i++;
    }
}
    zT_24 = 1;
    zT_25 = 0;
    ver[zT_25] = zT_24;
    zT_26 = 0;
    zT_27 = 1;
    ver[zT_27] = zT_26;
    zT_28 = 0;
    zT_29 = 2;
    ver[zT_29] = zT_28;
    zT_30 = 0;
    zT_31 = 3;
    ver[zT_31] = zT_30;
    zT_32 = &out->store;
    zT_36 = out->store;
    zT_33 = zT_36.cur;
    zT_40 = 0;
    zT_41 = (unsigned char*)((unsigned char*)ver) + zT_40;
    zT_42 = (unsigned int)(4) - zT_40;
    zT_43.ptr = (unsigned char*)zT_41;
    zT_43.len = zT_42;
    zT_34 = zT_43;
    zF_BFB33631_spillWriteAt(zT_32, zT_33, zT_34);
    zT_46 = 0;
    zT_47 = 0;
    zT_45[zT_47] = zT_46;
    zT_48 = 0;
    zT_49 = 1;
    zT_45[zT_49] = zT_48;
    zT_50 = 0;
    zT_51 = 2;
    zT_45[zT_51] = zT_50;
    zT_52 = 0;
    zT_53 = 3;
    zT_45[zT_53] = zT_52;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zero[_i] = zT_45[_i];
        _i++;
    }
}
    zT_54 = &out->store;
    zT_58 = out->store;
    zT_55 = zT_58.cur;
    zT_62 = 0;
    zT_63 = (unsigned char*)((unsigned char*)zero) + zT_62;
    zT_64 = (unsigned int)(4) - zT_62;
    zT_65.ptr = (unsigned char*)zT_63;
    zT_65.len = zT_64;
    zT_56 = zT_65;
    zF_BFB33631_spillWriteAt(zT_54, zT_55, zT_56);
    zT_66 = &out->store;
    zT_70 = out->store;
    zT_67 = zT_70.cur;
    zT_74 = 0;
    zT_75 = (unsigned char*)((unsigned char*)zero) + zT_74;
    zT_76 = (unsigned int)(4) - zT_74;
    zT_77.ptr = (unsigned char*)zT_75;
    zT_77.len = zT_76;
    zT_68 = zT_77;
    zF_BFB33631_spillWriteAt(zT_66, zT_67, zT_68);
    return;
}

/* debugOutWriteU16 */
void zF_C9405045_debugOutWriteU16(zT_BEF92BCA_DebugOutFile* out, unsigned short value) {
    zT_BBAAFAE2_Arr_unsigned_char_2 zT_3;
    unsigned char zT_7;
    int zT_8;
    unsigned char zT_14;
    int zT_15;
    zT_D21A8776_SpillStore* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_D21A8776_SpillStore zT_20;
    int zT_24;
    unsigned char* zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_BBAAFAE2_Arr_unsigned_char_2 b;
    {
    unsigned int _i = 0;
    while (_i < 2) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 2) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_7 = (unsigned char)(unsigned int)((unsigned int)((unsigned int)value) & (unsigned int)(255));
    zT_8 = 0;
    b[zT_8] = zT_7;
    zT_14 = (unsigned char)(unsigned int)((unsigned int)((unsigned int)((unsigned int)value) >> (unsigned int)(8)) & (unsigned int)(255));
    zT_15 = 1;
    b[zT_15] = zT_14;
    zT_16 = &out->store;
    zT_20 = out->store;
    zT_17 = zT_20.cur;
    zT_24 = 0;
    zT_25 = (unsigned char*)((unsigned char*)b) + zT_24;
    zT_26 = (unsigned int)(2) - zT_24;
    zT_27.ptr = (unsigned char*)zT_25;
    zT_27.len = zT_26;
    zT_18 = zT_27;
    zF_BFB33631_spillWriteAt(zT_16, zT_17, zT_18);
    return;
}

/* debugOutWriteU32 */
void zF_D53BE5FB_debugOutWriteU32(zT_BEF92BCA_DebugOutFile* out, unsigned int value) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_12;
    int zT_13;
    unsigned char zT_18;
    int zT_19;
    unsigned char zT_24;
    int zT_25;
    zT_D21A8776_SpillStore* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_D21A8776_SpillStore zT_30;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_6 = (unsigned char)(unsigned int)(value & (unsigned int)(255));
    zT_7 = 0;
    b[zT_7] = zT_6;
    zT_12 = (unsigned char)(unsigned int)((unsigned int)(value >> (unsigned int)(8)) & (unsigned int)(255));
    zT_13 = 1;
    b[zT_13] = zT_12;
    zT_18 = (unsigned char)(unsigned int)((unsigned int)(value >> (unsigned int)(16)) & (unsigned int)(255));
    zT_19 = 2;
    b[zT_19] = zT_18;
    zT_24 = (unsigned char)(unsigned int)((unsigned int)(value >> (unsigned int)(24)) & (unsigned int)(255));
    zT_25 = 3;
    b[zT_25] = zT_24;
    zT_26 = &out->store;
    zT_30 = out->store;
    zT_27 = zT_30.cur;
    zT_34 = 0;
    zT_35 = (unsigned char*)((unsigned char*)b) + zT_34;
    zT_36 = (unsigned int)(4) - zT_34;
    zT_37.ptr = (unsigned char*)zT_35;
    zT_37.len = zT_36;
    zT_28 = zT_37;
    zF_BFB33631_spillWriteAt(zT_26, zT_27, zT_28);
    return;
}

/* debugOutWriteBytes */
void zF_BFE5287E_debugOutWriteBytes(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u bytes) {
    unsigned int zT_3;
    zT_D21A8776_SpillStore* zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_D21A8776_SpillStore zT_10;
    zT_3 = bytes.len;
    if ((unsigned char)(zT_3 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = &out->store;
    zT_10 = out->store;
    zT_7 = zT_10.cur;
    zT_8 = bytes;
    zF_BFB33631_spillWriteAt(zT_6, zT_7, zT_8);
    return;
}

/* debugOutWriteStr16Pair */
void zF_D8B6F339_debugOutWriteStr16P(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u a, zT_8F083A69_Slice_zT_0B42B2F8_u b) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned int zT_17;
    zT_BEF92BCA_DebugOutFile* zT_18;
    zT_BEF92BCA_DebugOutFile* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned char* zT_23;
    int zT_25;
    unsigned char* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_30;
    unsigned int zT_33;
    zT_BEF92BCA_DebugOutFile* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned char* zT_36;
    int zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int total;
    unsigned int la;
    unsigned int lb;
    zT_5 = a.len;
    zT_7 = b.len;
    zT_8 = zT_5 + zT_7;
    total = zT_8;
    if ((unsigned char)(total > (unsigned int)(65535))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = 65535;
    total = zT_11;
    goto z_bb_2;
    z_bb_2:
    zT_14 = a.len;
    la = zT_14;
    if ((unsigned char)(la > total)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    la = total;
    goto z_bb_4;
    z_bb_4:
    zT_17 = total - la;
    lb = zT_17;
    zT_18 = out;
    zF_C9405045_debugOutWriteU16(zT_18, (unsigned short)((unsigned short)total));
    zT_21 = out;
    zT_23 = a.ptr;
    zT_25 = 0;
    zT_26 = zT_23 + zT_25;
    zT_27 = la - zT_25;
    zT_28.ptr = (unsigned char*)zT_26;
    zT_28.len = zT_27;
    zT_22 = zT_28;
    zF_BFE5287E_debugOutWriteBytes(zT_21, zT_22);
    zT_30 = b.len;
    if ((unsigned char)(lb > zT_30)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_33 = b.len;
    lb = zT_33;
    goto z_bb_6;
    z_bb_6:
    zT_34 = out;
    zT_36 = b.ptr;
    zT_38 = 0;
    zT_39 = zT_36 + zT_38;
    zT_40 = lb - zT_38;
    zT_41.ptr = (unsigned char*)zT_39;
    zT_41.len = zT_40;
    zT_35 = zT_41;
    zF_BFE5287E_debugOutWriteBytes(zT_34, zT_35);
    return;
}

/* debugOutWriteStr16 */
void zF_5C16527D_debugOutWriteStr16(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    unsigned int zT_4;
    unsigned int zT_7;
    zT_BEF92BCA_DebugOutFile* zT_8;
    zT_BEF92BCA_DebugOutFile* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned char* zT_13;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int len;
    zT_4 = s.len;
    len = zT_4;
    if ((unsigned char)(len > (unsigned int)(65535))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = 65535;
    len = zT_7;
    goto z_bb_2;
    z_bb_2:
    zT_8 = out;
    zF_C9405045_debugOutWriteU16(zT_8, (unsigned short)((unsigned short)len));
    zT_11 = out;
    zT_13 = s.ptr;
    zT_15 = 0;
    zT_16 = zT_13 + zT_15;
    zT_17 = len - zT_15;
    zT_18.ptr = (unsigned char*)zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zF_BFE5287E_debugOutWriteBytes(zT_11, zT_12);
    return;
}

/* debugOutClose */
void zF_4A7C5D00_debugOutClose(zT_BEF92BCA_DebugOutFile* out, zT_8F083A69_Slice_zT_0B42B2F8_u magic) {
    zT_D21A8776_SpillStore zT_3;
    unsigned int zT_4;
    zT_D21A8776_SpillStore* zT_5;
    zT_BEF92BCA_DebugOutFile* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_BEF92BCA_DebugOutFile* zT_11;
    zT_BEF92BCA_DebugOutFile* zT_14;
    unsigned int zT_15;
    zT_BEF92BCA_DebugOutFile* zT_17;
    unsigned int zT_18;
    zT_D21A8776_SpillStore* zT_19;
    unsigned int total;
    zT_3 = out->store;
    zT_4 = zT_3.cur;
    total = zT_4;
    zT_5 = &out->store;
    zF_56A911A9_spillSeek(zT_5, (unsigned int)(0));
    zT_9 = out;
    zT_10 = magic;
    zF_BFE5287E_debugOutWriteBytes(zT_9, zT_10);
    zT_11 = out;
    zF_D53BE5FB_debugOutWriteU32(zT_11, (unsigned int)(1));
    zT_14 = out;
    zT_15 = out->count;
    zF_D53BE5FB_debugOutWriteU32(zT_14, zT_15);
    zT_17 = out;
    zT_18 = total;
    zF_D53BE5FB_debugOutWriteU32(zT_17, zT_18);
    zT_19 = &out->store;
    zF_DB2CDC3B_spillClose(zT_19);
    return;
}

/* debugMapWriterInit */
zT_DEDDFC41_DebugMapWriter zF_CCB1E6BF_debugMapWriterInit(void) {
    zT_DEDDFC41_DebugMapWriter zT_0;
    zT_BEF92BCA_DebugOutFile zT_1;
    zT_D21A8776_SpillStore zT_2 = {0};
    unsigned int zT_3;
    zT_BEF92BCA_DebugOutFile zT_4;
    zT_D21A8776_SpillStore zT_5 = {0};
    unsigned int zT_6;
    zT_BEF92BCA_DebugOutFile zT_7;
    zT_D21A8776_SpillStore zT_8 = {0};
    unsigned int zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char zT_17;
    zT_2 = zF_22C79E6C_spillStoreInit();
    zT_1.store = zT_2;
    zT_3 = 0;
    zT_1.count = zT_3;
    zT_0.syms = zT_1;
    zT_5 = zF_22C79E6C_spillStoreInit();
    zT_4.store = zT_5;
    zT_6 = 0;
    zT_4.count = zT_6;
    zT_0.lines = zT_4;
    zT_8 = zF_22C79E6C_spillStoreInit();
    zT_7.store = zT_8;
    zT_9 = 0;
    zT_7.count = zT_9;
    zT_0.cnames = zT_7;
    zT_10 = 0;
    zT_0.enabled = zT_10;
    zT_11 = 0;
    zT_0.group_open = zT_11;
    zT_12 = 0;
    zT_0.group_count_offset = zT_12;
    zT_13 = 0;
    zT_0.group_run_count = zT_13;
    zT_14 = 0;
    zT_0.last_src_line = zT_14;
    zT_15 = 0;
    zT_0.last_out_start = zT_15;
    zT_16 = 0;
    zT_0.last_out_count = zT_16;
    zT_17 = 0;
    zT_0.has_last = zT_17;
    return zT_0;
}

/* debugMapWriterOpen */
void zF_ED14666D_debugMapWriterOpen(zT_DEDDFC41_DebugMapWriter* self, zT_3E40CD83_Sand* alloc, zT_8F083A69_Slice_zT_0B42B2F8_u syms_path, zT_8F083A69_Slice_zT_0B42B2F8_u lines_path, zT_8F083A69_Slice_zT_0B42B2F8_u cnames_path) {
    zT_BEF92BCA_DebugOutFile* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_3E40CD83_Sand* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10 = {0};
    zT_BEF92BCA_DebugOutFile* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16 = {0};
    zT_BEF92BCA_DebugOutFile* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22 = {0};
    zT_5 = &self->syms;
    zT_6 = syms_path;
    zT_7 = alloc;
    zT_10 = zF_DEE7AA30_magicSyms();
    zT_8 = zT_10;
    zF_D70BEADC_debugOutOpen(zT_5, zT_6, zT_7, zT_8);
    zT_11 = &self->lines;
    zT_12 = lines_path;
    zT_13 = alloc;
    zT_16 = zF_4FFC9427_magicLines();
    zT_14 = zT_16;
    zF_D70BEADC_debugOutOpen(zT_11, zT_12, zT_13, zT_14);
    zT_17 = &self->cnames;
    zT_18 = cnames_path;
    zT_19 = alloc;
    zT_22 = zF_ED717857_magicCnames();
    zT_20 = zT_22;
    zF_D70BEADC_debugOutOpen(zT_17, zT_18, zT_19, zT_20);
    self->enabled = (unsigned char)(1);
    return;
}

/* debugMapWriterBeginLineGroup */
void zF_FFA3F32B_debugMapWriterBegin(zT_DEDDFC41_DebugMapWriter* self, zT_8F083A69_Slice_zT_0B42B2F8_u src_file, zT_8F083A69_Slice_zT_0B42B2F8_u out_base) {
    unsigned char zT_3;
    zT_BEF92BCA_DebugOutFile* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_BEF92BCA_DebugOutFile* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_BEF92BCA_DebugOutFile zT_17;
    zT_D21A8776_SpillStore zT_18;
    unsigned int zT_19;
    zT_BEF92BCA_DebugOutFile* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    zT_3 = self->enabled;
    if ((unsigned char)(zT_3 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = &self->lines;
    zT_7 = src_file;
    zF_5C16527D_debugOutWriteStr16(zT_6, zT_7);
    zT_10 = ".c";
    zT_12 = 2;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    cext = zT_11;
    zT_13 = &self->lines;
    zT_14 = out_base;
    zT_15 = cext;
    zF_D8B6F339_debugOutWriteStr16P(zT_13, zT_14, zT_15);
    zT_17 = self->lines;
    zT_18 = zT_17.store;
    zT_19 = zT_18.cur;
    self->group_count_offset = zT_19;
    zT_20 = &self->lines;
    zF_D53BE5FB_debugOutWriteU32(zT_20, (unsigned int)(0));
    self->group_run_count = (unsigned int)(0);
    self->has_last = (unsigned char)(0);
    self->group_open = (unsigned char)(1);
    return;
}

/* debugMapFlushLast */
void zF_1565BCB0_debugMapFlushLast(zT_DEDDFC41_DebugMapWriter* self) {
    unsigned char zT_1;
    zT_BEF92BCA_DebugOutFile* zT_4;
    unsigned int zT_5;
    zT_BEF92BCA_DebugOutFile* zT_8;
    unsigned int zT_9;
    zT_BEF92BCA_DebugOutFile* zT_12;
    unsigned int zT_13;
    unsigned int zT_16;
    zT_1 = self->has_last;
    if ((unsigned char)(zT_1 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = &self->lines;
    zT_5 = self->last_src_line;
    zF_D53BE5FB_debugOutWriteU32(zT_4, zT_5);
    zT_8 = &self->lines;
    zT_9 = self->last_out_start;
    zF_D53BE5FB_debugOutWriteU32(zT_8, zT_9);
    zT_12 = &self->lines;
    zT_13 = self->last_out_count;
    zF_D53BE5FB_debugOutWriteU32(zT_12, zT_13);
    zT_16 = self->group_run_count;
    self->group_run_count = (unsigned int)(zT_16 + (unsigned int)(1));
    self->has_last = (unsigned char)(0);
    return;
}

/* debugMapWriterAddRun */
void zF_6CD06D0D_debugMapWriterAddRu(zT_DEDDFC41_DebugMapWriter* self, unsigned int src_line, unsigned int out_start, unsigned int out_count) {
    unsigned char zT_4;
    unsigned char zT_7;
    unsigned char zT_8;
    unsigned char zT_11;
    unsigned char zT_14;
    unsigned char zT_17;
    unsigned int zT_18;
    unsigned char zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_25;
    zT_DEDDFC41_DebugMapWriter* zT_27;
    zT_4 = self->enabled;
    if ((unsigned char)(zT_4 == (unsigned char)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_8 = self->group_open;
    zT_7 = zT_8 == (unsigned char)(0);
    goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_7) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_11 = out_count == (unsigned int)(0);
    goto z_bb_6;
    z_bb_5:
    zT_11 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_11) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    zT_14 = self->has_last;
    if ((unsigned char)(zT_14 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_18 = self->last_src_line;
    zT_17 = zT_18 == src_line;
    goto z_bb_11;
    z_bb_10:
    zT_17 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_17) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_21 = self->last_out_start;
    zT_22 = self->last_out_count;
    zT_20 = (unsigned int)(zT_21 + zT_22) == out_start;
    goto z_bb_14;
    z_bb_13:
    zT_20 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_20) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_25 = self->last_out_count;
    self->last_out_count = (unsigned int)(zT_25 + out_count);
    return;
    z_bb_16:
    zT_27 = self;
    zF_1565BCB0_debugMapFlushLast(zT_27);
    self->last_src_line = src_line;
    self->last_out_start = out_start;
    self->last_out_count = out_count;
    self->has_last = (unsigned char)(1);
    return;
}

/* debugMapWriterEndLineGroup */
void zF_B7665FFF_debugMapWriterEndLi(zT_DEDDFC41_DebugMapWriter* self) {
    unsigned char zT_1;
    unsigned char zT_4;
    unsigned char zT_5;
    zT_DEDDFC41_DebugMapWriter* zT_8;
    zT_BEF92BCA_DebugOutFile zT_10;
    zT_D21A8776_SpillStore zT_11;
    unsigned int zT_12;
    zT_D21A8776_SpillStore* zT_13;
    unsigned int zT_14;
    zT_BEF92BCA_DebugOutFile* zT_15;
    zT_BEF92BCA_DebugOutFile* zT_18;
    unsigned int zT_19;
    zT_D21A8776_SpillStore* zT_22;
    unsigned int zT_23;
    zT_BEF92BCA_DebugOutFile* zT_24;
    zT_BEF92BCA_DebugOutFile zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_BEF92BCA_DebugOutFile* zT_30;
    unsigned int end;
    zT_1 = self->enabled;
    if ((unsigned char)(zT_1 == (unsigned char)(0))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = self->group_open;
    zT_4 = zT_5 == (unsigned char)(0);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_8 = self;
    zF_1565BCB0_debugMapFlushLast(zT_8);
    zT_10 = self->lines;
    zT_11 = zT_10.store;
    zT_12 = zT_11.cur;
    end = zT_12;
    zT_15 = &self->lines;
    zT_13 = &zT_15->store;
    zT_14 = self->group_count_offset;
    zF_56A911A9_spillSeek(zT_13, zT_14);
    zT_18 = &self->lines;
    zT_19 = self->group_run_count;
    zF_D53BE5FB_debugOutWriteU32(zT_18, zT_19);
    zT_24 = &self->lines;
    zT_22 = &zT_24->store;
    zT_23 = end;
    zF_56A911A9_spillSeek(zT_22, zT_23);
    zT_26 = self->lines;
    zT_27 = zT_26.count;
    zT_28 = self->group_run_count;
    zT_30 = &self->lines;
    zT_30->count = (unsigned int)(zT_27 + zT_28);
    self->group_open = (unsigned char)(0);
    return;
}

/* debugModuleStem */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_D560F1C1_debugModuleStem(zT_CEC2984A_NameMangler* mangler, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, unsigned int module_id) {
    zT_072B53A6_ModuleRegistry* zT_5;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_6 = {0};
    zT_D3EB6303_StringInterner* zT_8;
    unsigned int zT_9;
    zT_6E8D187B_ModuleEntry* zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14 = {0};
    zT_CEC2984A_NameMangler* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17 = {0};
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_8F083A69_Slice_zT_0B42B2F8_u path_str;
    zT_5 = module_reg;
    zT_6 = zF_3452C137_moduleRegistryGetMo(zT_5);
    mods = zT_6;
    zT_8 = interner;
    zT_10 = mods.ptr;
    zT_11 = (unsigned int)module_id;
    zT_12 = zT_10[zT_11];
    zT_9 = zT_12.path_id;
    zT_14 = zF_9134020D_stringInternerGet(zT_8, zT_9);
    path_str = zT_14;
    zT_15 = mangler;
    zT_16 = path_str;
    zT_17 = zF_C4A5232F_nameManglerMintModu(zT_15, zT_16);
    return zT_17;
}

/* debugSymbolSrcFile */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_B7A9322C_debugSymbolSrcFile(zT_1001656C_DebugSymbol sym, zT_227EDE07_SourceManager* source_man) {
    zT_227EDE07_SourceManager* zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5 = {0};
    zT_2 = source_man;
    zT_3 = sym.src_file_id;
    zT_5 = zF_B7076474_sourceManagerGetFil(zT_2, zT_3);
    return zT_5;
}

/* debugSymbolName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_EA891367_debugSymbolName(zT_1001656C_DebugSymbol sym, zT_D3EB6303_StringInterner* interner) {
    zT_D3EB6303_StringInterner* zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5 = {0};
    zT_2 = interner;
    zT_3 = sym.name_id;
    zT_5 = zF_9134020D_stringInternerGet(zT_2, zT_3);
    return zT_5;
}

/* debugSymbolLess */
unsigned char zF_48A32BF5_debugSymbolLess(zT_1001656C_DebugSymbol a, zT_1001656C_DebugSymbol b, zT_227EDE07_SourceManager* source_man, zT_D3EB6303_StringInterner* interner) {
    zT_1001656C_DebugSymbol zT_5;
    zT_227EDE07_SourceManager* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7 = {0};
    zT_1001656C_DebugSymbol zT_9;
    zT_227EDE07_SourceManager* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_15 = 0;
    int zT_16;
    int zT_19;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    unsigned int zT_27;
    zT_1001656C_DebugSymbol zT_31;
    zT_D3EB6303_StringInterner* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33 = {0};
    zT_1001656C_DebugSymbol zT_35;
    zT_D3EB6303_StringInterner* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    int zT_40 = 0;
    int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u af;
    zT_8F083A69_Slice_zT_0B42B2F8_u bf;
    int c;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_8F083A69_Slice_zT_0B42B2F8_u bn;
    zT_5 = a;
    zT_6 = source_man;
    zT_7 = zF_B7A9322C_debugSymbolSrcFile(zT_5, zT_6);
    af = zT_7;
    zT_9 = b;
    zT_10 = source_man;
    zT_11 = zF_B7A9322C_debugSymbolSrcFile(zT_9, zT_10);
    bf = zT_11;
    zT_13 = af;
    zT_14 = bf;
    zT_15 = zF_7814455F_strCompare(zT_13, zT_14);
    c = zT_15;
    zT_16 = 0;
    if ((unsigned char)(c < zT_16)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_19 = 0;
    if ((unsigned char)(c > zT_19)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_22 = a.src_line;
    zT_23 = b.src_line;
    if ((unsigned char)(zT_22 < zT_23)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_26 = a.src_line;
    zT_27 = b.src_line;
    if ((unsigned char)(zT_26 > zT_27)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_31 = a;
    zT_32 = interner;
    zT_33 = zF_EA891367_debugSymbolName(zT_31, zT_32);
    an = zT_33;
    zT_35 = b;
    zT_36 = interner;
    zT_37 = zF_EA891367_debugSymbolName(zT_35, zT_36);
    bn = zT_37;
    zT_38 = an;
    zT_39 = bn;
    zT_40 = zF_7814455F_strCompare(zT_38, zT_39);
    zT_41 = 0;
    return (unsigned char)(zT_40 < zT_41);
}

/* debugCnameLess */
unsigned char zF_D5054183_debugCnameLess(zT_1001656C_DebugSymbol a, zT_1001656C_DebugSymbol b, zT_D3EB6303_StringInterner* interner) {
    zT_1001656C_DebugSymbol zT_4;
    zT_D3EB6303_StringInterner* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6 = {0};
    zT_1001656C_DebugSymbol zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_14 = 0;
    int zT_15;
    int zT_18;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned char zT_29;
    unsigned char zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_8F083A69_Slice_zT_0B42B2F8_u bn;
    int c;
    zT_4 = a;
    zT_5 = interner;
    zT_6 = zF_EA891367_debugSymbolName(zT_4, zT_5);
    an = zT_6;
    zT_8 = b;
    zT_9 = interner;
    zT_10 = zF_EA891367_debugSymbolName(zT_8, zT_9);
    bn = zT_10;
    zT_12 = an;
    zT_13 = bn;
    zT_14 = zF_7814455F_strCompare(zT_12, zT_13);
    c = zT_14;
    zT_15 = 0;
    if ((unsigned char)(c < zT_15)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_18 = 0;
    if ((unsigned char)(c > zT_18)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_21 = a.module_id;
    zT_22 = b.module_id;
    if ((unsigned char)(zT_21 < zT_22)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    zT_25 = a.module_id;
    zT_26 = b.module_id;
    if ((unsigned char)(zT_25 > zT_26)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_29 = a.kind;
    zT_30 = b.kind;
    return (unsigned char)(zT_29 < zT_30);
}

/* debugMapWriterClose */
void zF_48EEEA4F_debugMapWriterClose(zT_DEDDFC41_DebugMapWriter* self, zT_3E40CD83_Sand* alloc, zT_39D2FAA1_Slice_zT_1001656C_D symbols, zT_227EDE07_SourceManager* source_man, zT_CEC2984A_NameMangler* mangler, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_338B7C76_TypeRegistry* registry) {
    unsigned char zT_8;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_12 = {0};
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_18;
    unsigned int zT_23;
    zT_FDFD82FD_EU_362 zT_26 = {0};
    unsigned char zT_27;
    unsigned char* zT_28;
    zT_1001656C_DebugSymbol* zT_31;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_1001656C_DebugSymbol* zT_37;
    zT_1001656C_DebugSymbol zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    int zT_43;
    zT_1001656C_DebugSymbol* zT_44;
    unsigned int zT_45;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_46;
    unsigned int zT_48;
    unsigned int zT_50;
    zT_1001656C_DebugSymbol* zT_53;
    zT_1001656C_DebugSymbol zT_54;
    zT_1001656C_DebugSymbol zT_58;
    zT_1001656C_DebugSymbol zT_59;
    zT_227EDE07_SourceManager* zT_60;
    zT_D3EB6303_StringInterner* zT_61;
    zT_1001656C_DebugSymbol* zT_62;
    unsigned int zT_64;
    zT_1001656C_DebugSymbol zT_65;
    unsigned char zT_66 = 0;
    zT_1001656C_DebugSymbol* zT_68;
    unsigned int zT_70;
    zT_1001656C_DebugSymbol zT_71;
    zT_1001656C_DebugSymbol* zT_72;
    unsigned int zT_74;
    zT_1001656C_DebugSymbol* zT_75;
    unsigned int zT_77;
    unsigned int zT_79;
    unsigned int zT_81;
    zT_1001656C_DebugSymbol* zT_84;
    zT_1001656C_DebugSymbol zT_85;
    zT_1001656C_DebugSymbol zT_87;
    zT_D3EB6303_StringInterner* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89 = {0};
    zT_CEC2984A_NameMangler* zT_91;
    zT_D3EB6303_StringInterner* zT_92;
    zT_072B53A6_ModuleRegistry* zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96 = {0};
    zT_1001656C_DebugSymbol zT_98;
    zT_227EDE07_SourceManager* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100 = {0};
    zT_BEF92BCA_DebugOutFile* zT_102;
    zT_BAAAF94F_Arr_unsigned_char_1 zT_104;
    unsigned char zT_105;
    int zT_106;
    zT_BEF92BCA_DebugOutFile* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    int zT_111;
    unsigned char* zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    zT_BEF92BCA_DebugOutFile* zT_115;
    unsigned int zT_116;
    zT_BEF92BCA_DebugOutFile* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_BEF92BCA_DebugOutFile* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_BEF92BCA_DebugOutFile* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    unsigned int zT_128;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_130 = {0};
    unsigned int zT_132;
    zT_3E40CD83_Sand* zT_136;
    unsigned int zT_141;
    zT_FDFD82FD_EU_362 zT_144 = {0};
    unsigned char zT_145;
    unsigned char* zT_146;
    zT_1001656C_DebugSymbol* zT_149;
    unsigned int zT_151;
    unsigned int zT_153;
    zT_1001656C_DebugSymbol* zT_155;
    zT_1001656C_DebugSymbol zT_156;
    unsigned int zT_158;
    unsigned int zT_160;
    int zT_161;
    zT_1001656C_DebugSymbol* zT_162;
    unsigned int zT_163;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_164;
    unsigned int zT_166;
    unsigned int zT_168;
    zT_1001656C_DebugSymbol* zT_171;
    zT_1001656C_DebugSymbol zT_172;
    zT_1001656C_DebugSymbol zT_176;
    zT_1001656C_DebugSymbol zT_177;
    zT_D3EB6303_StringInterner* zT_178;
    zT_1001656C_DebugSymbol* zT_179;
    unsigned int zT_181;
    zT_1001656C_DebugSymbol zT_182;
    unsigned char zT_183 = 0;
    zT_1001656C_DebugSymbol* zT_185;
    unsigned int zT_187;
    zT_1001656C_DebugSymbol zT_188;
    zT_1001656C_DebugSymbol* zT_189;
    unsigned int zT_191;
    zT_1001656C_DebugSymbol* zT_192;
    unsigned int zT_194;
    unsigned int zT_196;
    unsigned int zT_198;
    zT_1001656C_DebugSymbol* zT_201;
    zT_1001656C_DebugSymbol zT_202;
    zT_1001656C_DebugSymbol zT_204;
    zT_D3EB6303_StringInterner* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206 = {0};
    unsigned char zT_208;
    unsigned char zT_211;
    zT_CEC2984A_NameMangler* zT_215;
    unsigned int zT_216;
    unsigned int zT_218;
    unsigned int zT_222 = 0;
    zT_D3EB6303_StringInterner* zT_223;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225 = {0};
    zT_CEC2984A_NameMangler* zT_227;
    zT_338B7C76_TypeRegistry* zT_228;
    unsigned int zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned int zT_235 = 0;
    zT_D3EB6303_StringInterner* zT_236;
    unsigned int zT_237;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_238 = {0};
    zT_BEF92BCA_DebugOutFile* zT_239;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_240;
    zT_BEF92BCA_DebugOutFile* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    zT_BEF92BCA_DebugOutFile zT_245;
    unsigned int zT_246;
    zT_BEF92BCA_DebugOutFile* zT_249;
    unsigned int zT_251;
    zT_BEF92BCA_DebugOutFile* zT_252;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255 = {0};
    zT_BEF92BCA_DebugOutFile* zT_256;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259 = {0};
    zT_BEF92BCA_DebugOutFile* zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263 = {0};
    zT_39D2FAA1_Slice_zT_1001656C_D sym_copy;
    unsigned char* raw;
    unsigned int si;
    zT_1001656C_DebugSymbol* dst;
    unsigned int ci;
    unsigned int i;
    zT_1001656C_DebugSymbol key;
    unsigned int j;
    zT_1001656C_DebugSymbol s;
    zT_8F083A69_Slice_zT_0B42B2F8_u nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mstem;
    zT_8F083A69_Slice_zT_0B42B2F8_u sf;
    zT_BEF92BCA_DebugOutFile* out;
    zT_BAAAF94F_Arr_unsigned_char_1 kb;
    zT_39D2FAA1_Slice_zT_1001656C_D cn_copy;
    unsigned int cn;
    zT_8F083A69_Slice_zT_0B42B2F8_u src_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u mangled;
    unsigned int gmid;
    unsigned int mid;
    zT_8 = self->enabled;
    if ((unsigned char)(zT_8 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    sym_copy = zT_12;
    zT_14 = symbols.len;
    if ((unsigned char)(zT_14 > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = alloc;
    zT_23 = symbols.len;
    zT_26 = zF_1395EB68_sandAlloc(zT_18, (unsigned int)((unsigned int)(28) * zT_23), (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_79 = 0;
    si = zT_79;
    goto z_bb_22;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_28 = zT_26.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_28;
    zT_31 = (zT_1001656C_DebugSymbol*)raw;
    dst = zT_31;
    zT_33 = 0;
    ci = zT_33;
    goto z_bb_8;
    z_bb_8:
    zT_35 = symbols.len;
    if ((unsigned char)(ci < zT_35)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_37 = symbols.ptr;
    zT_38 = zT_37[ci];
    dst[ci] = zT_38;
    goto z_bb_11;
    z_bb_10:
    zT_42 = symbols.len;
    zT_43 = 0;
    zT_44 = dst + zT_43;
    zT_45 = zT_42 - zT_43;
    zT_46.ptr = (zT_1001656C_DebugSymbol*)zT_44;
    zT_46.len = zT_45;
    sym_copy = zT_46;
    zT_48 = 1;
    i = zT_48;
    goto z_bb_12;
    z_bb_11:
    zT_40 = ci + (unsigned int)(1);
    ci = zT_40;
    goto z_bb_8;
    z_bb_12:
    zT_50 = sym_copy.len;
    if ((unsigned char)(i < zT_50)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_53 = sym_copy.ptr;
    zT_54 = zT_53[i];
    key = zT_54;
    j = i;
    goto z_bb_16;
    z_bb_14:
    goto z_bb_4;
    z_bb_15:
    zT_77 = i + (unsigned int)(1);
    i = zT_77;
    goto z_bb_12;
    z_bb_16:
    if ((unsigned char)(j > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_58 = key;
    zT_62 = sym_copy.ptr;
    zT_64 = j - (unsigned int)(1);
    zT_65 = zT_62[zT_64];
    zT_59 = zT_65;
    zT_60 = source_man;
    zT_61 = interner;
    zT_66 = zF_48A32BF5_debugSymbolLess(zT_58, zT_59, zT_60, zT_61);
    if ((unsigned char)(!zT_66)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_75 = sym_copy.ptr;
    zT_75[j] = key;
    goto z_bb_15;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_68 = sym_copy.ptr;
    zT_70 = j - (unsigned int)(1);
    zT_71 = zT_68[zT_70];
    zT_72 = sym_copy.ptr;
    zT_72[j] = zT_71;
    zT_74 = j - (unsigned int)(1);
    j = zT_74;
    goto z_bb_19;
    z_bb_22:
    zT_81 = symbols.len;
    if ((unsigned char)(si < zT_81)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_84 = sym_copy.ptr;
    zT_85 = zT_84[si];
    s = zT_85;
    zT_87 = s;
    zT_88 = interner;
    zT_89 = zF_EA891367_debugSymbolName(zT_87, zT_88);
    nm = zT_89;
    zT_91 = mangler;
    zT_92 = interner;
    zT_93 = module_reg;
    zT_94 = s.module_id;
    zT_96 = zF_D560F1C1_debugModuleStem(zT_91, zT_92, zT_93, zT_94);
    mstem = zT_96;
    zT_98 = s;
    zT_99 = source_man;
    zT_100 = zF_B7A9322C_debugSymbolSrcFile(zT_98, zT_99);
    sf = zT_100;
    zT_102 = &self->syms;
    out = zT_102;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_104[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        kb[_i] = zT_104[_i];
        _i++;
    }
}
    zT_105 = s.kind;
    zT_106 = 0;
    kb[zT_106] = zT_105;
    zT_107 = out;
    zT_111 = 0;
    zT_112 = (unsigned char*)((unsigned char*)kb) + zT_111;
    zT_113 = (unsigned int)(1) - zT_111;
    zT_114.ptr = (unsigned char*)zT_112;
    zT_114.len = zT_113;
    zT_108 = zT_114;
    zF_BFE5287E_debugOutWriteBytes(zT_107, zT_108);
    zT_115 = out;
    zT_116 = s.src_line;
    zF_D53BE5FB_debugOutWriteU32(zT_115, zT_116);
    zT_118 = out;
    zT_119 = nm;
    zF_5C16527D_debugOutWriteStr16(zT_118, zT_119);
    zT_120 = out;
    zT_121 = mstem;
    zF_5C16527D_debugOutWriteStr16(zT_120, zT_121);
    zT_122 = out;
    zT_123 = sf;
    zF_5C16527D_debugOutWriteStr16(zT_122, zT_123);
    zT_124 = out->count;
    out->count = (unsigned int)(zT_124 + (unsigned int)(1));
    goto z_bb_25;
    z_bb_24:
    cn_copy = zT_130;
    zT_132 = symbols.len;
    if ((unsigned char)(zT_132 > (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    zT_128 = si + (unsigned int)(1);
    si = zT_128;
    goto z_bb_22;
    z_bb_26:
    zT_136 = alloc;
    zT_141 = symbols.len;
    zT_144 = zF_1395EB68_sandAlloc(zT_136, (unsigned int)((unsigned int)(28) * zT_141), (unsigned int)(4));
    zT_145 = zT_144.is_error;
    if (zT_145) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_196 = 0;
    cn = zT_196;
    goto z_bb_45;
    z_bb_28:
    pal_trap();
    z_bb_29:
    zT_146 = zT_144.data.payload;
    goto z_bb_30;
    z_bb_30:
    raw = zT_146;
    zT_149 = (zT_1001656C_DebugSymbol*)raw;
    dst = zT_149;
    zT_151 = 0;
    ci = zT_151;
    goto z_bb_31;
    z_bb_31:
    zT_153 = symbols.len;
    if ((unsigned char)(ci < zT_153)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_155 = symbols.ptr;
    zT_156 = zT_155[ci];
    dst[ci] = zT_156;
    goto z_bb_34;
    z_bb_33:
    zT_160 = symbols.len;
    zT_161 = 0;
    zT_162 = dst + zT_161;
    zT_163 = zT_160 - zT_161;
    zT_164.ptr = (zT_1001656C_DebugSymbol*)zT_162;
    zT_164.len = zT_163;
    cn_copy = zT_164;
    zT_166 = 1;
    i = zT_166;
    goto z_bb_35;
    z_bb_34:
    zT_158 = ci + (unsigned int)(1);
    ci = zT_158;
    goto z_bb_31;
    z_bb_35:
    zT_168 = cn_copy.len;
    if ((unsigned char)(i < zT_168)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_171 = cn_copy.ptr;
    zT_172 = zT_171[i];
    key = zT_172;
    j = i;
    goto z_bb_39;
    z_bb_37:
    goto z_bb_27;
    z_bb_38:
    zT_194 = i + (unsigned int)(1);
    i = zT_194;
    goto z_bb_35;
    z_bb_39:
    if ((unsigned char)(j > (unsigned int)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_176 = key;
    zT_179 = cn_copy.ptr;
    zT_181 = j - (unsigned int)(1);
    zT_182 = zT_179[zT_181];
    zT_177 = zT_182;
    zT_178 = interner;
    zT_183 = zF_D5054183_debugCnameLess(zT_176, zT_177, zT_178);
    if ((unsigned char)(!zT_183)) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_192 = cn_copy.ptr;
    zT_192[j] = key;
    goto z_bb_38;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    goto z_bb_41;
    z_bb_44:
    zT_185 = cn_copy.ptr;
    zT_187 = j - (unsigned int)(1);
    zT_188 = zT_185[zT_187];
    zT_189 = cn_copy.ptr;
    zT_189[j] = zT_188;
    zT_191 = j - (unsigned int)(1);
    j = zT_191;
    goto z_bb_42;
    z_bb_45:
    zT_198 = symbols.len;
    if ((unsigned char)(cn < zT_198)) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_201 = cn_copy.ptr;
    zT_202 = zT_201[cn];
    s = zT_202;
    zT_204 = s;
    zT_205 = interner;
    zT_206 = zF_EA891367_debugSymbolName(zT_204, zT_205);
    src_nm = zT_206;
    mangled = src_nm;
    zT_208 = s.kind;
    if ((unsigned char)(zT_208 == (unsigned char)(0))) goto z_bb_49; else goto z_bb_51;
    z_bb_47:
    zT_252 = &self->syms;
    zT_255 = zF_DEE7AA30_magicSyms();
    zT_253 = zT_255;
    zF_4A7C5D00_debugOutClose(zT_252, zT_253);
    zT_256 = &self->cnames;
    zT_259 = zF_ED717857_magicCnames();
    zT_257 = zT_259;
    zF_4A7C5D00_debugOutClose(zT_256, zT_257);
    zT_260 = &self->lines;
    zT_263 = zF_4FFC9427_magicLines();
    zT_261 = zT_263;
    zF_4A7C5D00_debugOutClose(zT_260, zT_261);
    self->enabled = (unsigned char)(0);
    return;
    z_bb_48:
    zT_251 = cn + (unsigned int)(1);
    cn = zT_251;
    goto z_bb_45;
    z_bb_49:
    zT_211 = s.is_extern;
    if ((unsigned char)(zT_211 == (unsigned char)(0))) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    zT_239 = &self->cnames;
    zT_240 = src_nm;
    zF_5C16527D_debugOutWriteStr16(zT_239, zT_240);
    zT_242 = &self->cnames;
    zT_243 = mangled;
    zF_5C16527D_debugOutWriteStr16(zT_242, zT_243);
    zT_245 = self->cnames;
    zT_246 = zT_245.count;
    zT_249 = &self->cnames;
    zT_249->count = (unsigned int)(zT_246 + (unsigned int)(1));
    goto z_bb_48;
    z_bb_51:
    zT_227 = mangler;
    zT_228 = registry;
    zT_229 = s.name_id;
    zT_230 = s.module_id;
    zT_231 = s.type_id;
    zT_235 = zF_027E7C4F_nameManglerMangle_1(zT_227, zT_228, zT_229, zT_230, zT_231);
    gmid = zT_235;
    zT_236 = interner;
    zT_237 = gmid;
    zT_238 = zF_9134020D_stringInternerGet(zT_236, zT_237);
    mangled = zT_238;
    goto z_bb_50;
    z_bb_52:
    zT_215 = mangler;
    zT_216 = s.name_id;
    zT_218 = s.module_id;
    zT_222 = zF_713D1938_nameManglerMangle(zT_215, zT_216, (unsigned char)(0), zT_218);
    mid = zT_222;
    zT_223 = interner;
    zT_224 = mid;
    zT_225 = zF_9134020D_stringInternerGet(zT_223, zT_224);
    mangled = zT_225;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_50;
}

/* EOF */
