#include "allocator_E75B7A0B.h"
zT_3E40CD83_Sand zG_3E40CD83_Sand;
zT_69057089_CompilerAlloc zG_69057089_CompilerAlloc;
zT_5B44B793_Arr_unsigned_char_2 zG_EEB4E6C3_memory_pool_buf;
zT_3E40CD83_Sand zG_91DD7983_pool;
zT_7D82FE60_GrowableSand zG_2D921856_perm_gs;
zT_7D82FE60_GrowableSand zG_D2119B4E_mod_gs;
zT_7D82FE60_GrowableSand zG_8901137E_scr_gs;
zT_7D82FE60_GrowableSand zG_74F406AB_lir_gs;
zT_7D82FE60_GrowableSand zG_DD5B2E91_emit_gs;
zT_6B32A9CF_Opt_239 zG_D5B16534_seg_free_head;
unsigned int zG_7135C933_DEV_MAX_MEM;
unsigned int zG_3B40C71D_RELEASE_MAX_MEM;
unsigned int zG_18AE3D2F_DEFAULT_MAX_MEM_KB;
/* sandInit */
zT_3E40CD83_Sand zF_CE0A77DD_sandInit(zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand zT_6;
    unsigned char* zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_7132B341_Opt_237 zT_13 = {0};
    unsigned int zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u uname;
    zT_3E40CD83_Sand s;
    unsigned int used;
    zT_2 = "unknown";
    zT_4 = 7;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    uname = zT_3;
    zT_8 = buf.ptr;
    zT_6.start = zT_8;
    zT_9 = 0;
    zT_6.pos = zT_9;
    zT_11 = buf.len;
    zT_6.end = zT_11;
    zT_12 = 0;
    zT_6.peak = zT_12;
    zT_6.name = uname;
    zT_13.has_value = 0;
    zT_6.growable = zT_13;
    s = zT_6;
    zT_15 = s.pos;
    used = zT_15;
    zT_16 = s.peak;
    if ((unsigned char)(used > zT_16)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s.peak = used;
    goto z_bb_2;
    z_bb_2:
    return s;
}

/* sandAlloc */
zT_ACA03DB3_EU_632 zF_1395EB68_sandAlloc(zT_3E40CD83_Sand* sand, unsigned int size, unsigned int alignment) {
    unsigned int zT_4;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned char* zT_19;
    unsigned char* zT_20;
    unsigned int zT_21;
    zT_ACA03DB3_EU_632 zT_23;
    zT_7132B341_Opt_237 zT_24;
    unsigned char zT_25;
    zT_7D82FE60_GrowableSand* zT_27;
    zT_3E40CD83_Sand* zT_28;
    unsigned int zT_29;
    unsigned char zT_30 = 0;
    zT_7132B341_Opt_237 zT_31;
    unsigned char zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    int zT_68;
    int zT_70;
    zT_ACA03DB3_EU_632 zT_71;
    unsigned int fail_new_pos;
    unsigned int mask;
    unsigned int aligned;
    unsigned int new_pos;
    unsigned char* result;
    zT_7D82FE60_GrowableSand* gs;
    zT_4 = 0;
    fail_new_pos = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = alignment - (unsigned int)(1);
    mask = zT_8;
    zT_10 = sand->pos;
    zT_13 = (unsigned int)(zT_10 + mask) & (unsigned int)(~mask);
    aligned = zT_13;
    zT_15 = aligned + size;
    new_pos = zT_15;
    zT_16 = sand->end;
    if ((unsigned char)(new_pos <= zT_16)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_31 = sand->growable;
    zT_32 = zT_31.has_value;
    if (zT_32) goto z_bb_13; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_19 = sand->start;
    zT_20 = zT_19 + aligned;
    result = zT_20;
    sand->pos = new_pos;
    zT_21 = sand->peak;
    if ((unsigned char)(new_pos > zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_24 = sand->growable;
    zT_25 = zT_24.has_value;
    if (zT_25) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    sand->peak = new_pos;
    goto z_bb_8;
    z_bb_8:
    zT_23.data.payload = result;
    zT_23.is_error = 0;
    return zT_23;
    z_bb_9:
    gs = zT_24.value;
    zT_27 = gs;
    zT_28 = sand;
    zT_29 = size;
    zT_30 = zF_130612FB_growableSandGrow(zT_27, zT_28, zT_29);
    if (zT_30) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    fail_new_pos = new_pos;
    goto z_bb_3;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    gs = zT_31.value;
    (void)gs;
    zT_35 = "OOM: growable arena cannot grow (pool exhausted)\n";
    zT_37 = 49;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    zT_34 = zT_36;
    zF_E4B2EF19_stderr_write(zT_34);
    goto z_bb_14;
    z_bb_14:
    zT_39 = "OOM: used=";
    zT_41 = 10;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    zT_38 = zT_40;
    zF_E4B2EF19_stderr_write(zT_38);
    zT_42 = sand->pos;
    zF_4ACF6BFE_printUsize(zT_42);
    zT_45 = " new=";
    zT_47 = 5;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    zT_44 = zT_46;
    zF_E4B2EF19_stderr_write(zT_44);
    zT_48 = fail_new_pos;
    zF_4ACF6BFE_printUsize(zT_48);
    zT_50 = " total=";
    zT_52 = 7;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    zT_49 = zT_51;
    zF_E4B2EF19_stderr_write(zT_49);
    zT_53 = sand->end;
    zF_4ACF6BFE_printUsize(zT_53);
    zT_56 = "\n";
    zT_58 = 1;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    zT_55 = zT_57;
    zF_E4B2EF19_stderr_write(zT_55);
    zT_62 = "out of memory";
    zT_64 = 13;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    zT_59 = zT_63;
    zT_65 = "allocator.zig";
    zT_67 = 13;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    zT_60 = zT_66;
    zT_68 = 28;
    zF_6D97D338_panicHandler(zT_59, zT_60, (unsigned int)((unsigned int)zT_68));
    zT_70 = 2;
    zT_71.data.err = zT_70;
    zT_71.is_error = 1;
    return zT_71;
}

/* sandReset */
void zF_F1B3F8C2_sandReset(zT_3E40CD83_Sand* sand) {
    zT_7132B341_Opt_237 zT_1;
    unsigned char zT_2;
    zT_C59F83AC_SandSegment zT_5;
    zT_6B32A9CF_Opt_239 zT_6;
    zT_6B32A9CF_Opt_239 zT_7 = {0};
    zT_C59F83AC_SandSegment* zT_8;
    zT_C59F83AC_SandSegment* zT_9;
    zT_C59F83AC_SandSegment zT_10;
    unsigned char* zT_11;
    zT_C59F83AC_SandSegment zT_12;
    unsigned int zT_13;
    unsigned char zT_15;
    zT_6B32A9CF_Opt_239 zT_18;
    unsigned char zT_19;
    zT_6B32A9CF_Opt_239 zT_22;
    zT_7D82FE60_GrowableSand* gs;
    zT_6B32A9CF_Opt_239 rest;
    zT_C59F83AC_SandSegment* r;
    zT_C59F83AC_SandSegment* tail;
    zT_C59F83AC_SandSegment* nn;
    zT_1 = sand->growable;
    zT_2 = zT_1.has_value;
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    gs = zT_1.value;
    zT_5 = gs->first;
    zT_6 = zT_5.next;
    rest = zT_6;
    zT_7.has_value = 0;
    zT_8 = &gs->first;
    zT_8->next = zT_7;
    zT_9 = &gs->first;
    gs->last = zT_9;
    zT_10 = gs->first;
    zT_11 = zT_10.start;
    sand->start = zT_11;
    zT_12 = gs->first;
    zT_13 = zT_12.end;
    sand->end = zT_13;
    sand->pos = (unsigned int)(0);
    zT_15 = rest.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    sand->pos = (unsigned int)(0);
    return;
    z_bb_3:
    r = rest.value;
    tail = r;
    goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    zT_18 = tail->next;
    zT_19 = zT_18.has_value;
    if (zT_19) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    nn = zT_18.value;
    tail = nn;
    goto z_bb_8;
    z_bb_7:
    tail->next = zG_D5B16534_seg_free_head;
    zT_22.has_value = 1;
    zT_22.value = r;
    zG_D5B16534_seg_free_head = zT_22;
    goto z_bb_4;
    z_bb_8:
    goto z_bb_5;
}

/* growableSandInit */
void zF_07B11742_growableSandInit(zT_7D82FE60_GrowableSand* gs, zT_3E40CD83_Sand* backing, unsigned int first_size, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_3E40CD83_Sand* zT_5;
    unsigned int zT_6;
    int zT_8;
    zT_ACA03DB3_EU_632 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    int zT_22;
    zT_C59F83AC_SandSegment zT_25;
    zT_6B32A9CF_Opt_239 zT_26 = {0};
    zT_C59F83AC_SandSegment* zT_27;
    zT_3E40CD83_Sand zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_7132B341_Opt_237 zT_31 = {0};
    zT_7132B341_Opt_237 zT_32;
    zT_3E40CD83_Sand* zT_33;
    unsigned char* raw;
    zT_5 = backing;
    zT_6 = first_size;
    zT_8 = 4;
    zT_10 = zF_1395EB68_sandAlloc(zT_5, zT_6, (unsigned int)((unsigned int)zT_8));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = "growable init oom";
    zT_18 = 17;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    zT_13 = zT_17;
    zT_19 = "allocator.zig";
    zT_21 = 13;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    zT_14 = zT_20;
    zT_22 = 28;
    zF_6D97D338_panicHandler(zT_13, zT_14, (unsigned int)((unsigned int)zT_22));
    return;
    z_bb_2:
    zT_12 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    zT_25.start = raw;
    zT_25.size = first_size;
    zT_25.end = first_size;
    zT_26.has_value = 0;
    zT_25.next = zT_26;
    gs->first = zT_25;
    zT_27 = &gs->first;
    gs->last = zT_27;
    gs->backing = backing;
    zT_28.start = raw;
    zT_29 = 0;
    zT_28.pos = zT_29;
    zT_28.end = first_size;
    zT_30 = 0;
    zT_28.peak = zT_30;
    zT_28.name = name;
    zT_31.has_value = 0;
    zT_28.growable = zT_31;
    gs->view = zT_28;
    zT_32.has_value = 1;
    zT_32.value = gs;
    zT_33 = &gs->view;
    zT_33->growable = zT_32;
    return;
}

/* growableSandGrow */
unsigned char zF_130612FB_growableSandGrow(zT_7D82FE60_GrowableSand* gs, zT_3E40CD83_Sand* view, unsigned int size) {
    zT_C59F83AC_SandSegment* zT_3;
    zT_6B32A9CF_Opt_239 zT_4;
    unsigned char zT_5;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_C59F83AC_SandSegment* zT_12;
    unsigned int zT_13;
    zT_C59F83AC_SandSegment* zT_15;
    unsigned int zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned char zT_24;
    unsigned int zT_25;
    zT_6B32A9CF_Opt_239 zT_26 = {0};
    unsigned char zT_27;
    unsigned int zT_30;
    zT_6B32A9CF_Opt_239 zT_31;
    zT_C59F83AC_SandSegment* zT_32;
    zT_6B32A9CF_Opt_239 zT_33 = {0};
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_39;
    unsigned int zT_40;
    int zT_43;
    zT_ACA03DB3_EU_632 zT_45 = {0};
    unsigned char zT_46;
    unsigned char* zT_47;
    zT_3E40CD83_Sand* zT_51;
    int zT_56;
    zT_ACA03DB3_EU_632 zT_58 = {0};
    unsigned char zT_59;
    unsigned char* zT_60;
    zT_C59F83AC_SandSegment* zT_64;
    zT_C59F83AC_SandSegment zT_65;
    zT_6B32A9CF_Opt_239 zT_66 = {0};
    zT_6B32A9CF_Opt_239 zT_67;
    zT_C59F83AC_SandSegment* zT_68;
    unsigned char* zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    zT_C59F83AC_SandSegment* next;
    unsigned int old_size;
    unsigned int new_size;
    unsigned int max_segment;
    unsigned char* raw;
    zT_C59F83AC_SandSegment* seg;
    unsigned int seg_cap;
    unsigned char* seg_raw;
    zT_C59F83AC_SandSegment* node;
    zT_3 = gs->last;
    zT_4 = zT_3->next;
    zT_5 = zT_4.has_value;
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    next = zT_4.value;
    gs->last = next;
    zT_7 = next->start;
    view->start = zT_7;
    zT_8 = next->end;
    view->end = zT_8;
    view->pos = (unsigned int)(0);
    return (unsigned char)(1);
    z_bb_2:
    zT_12 = gs->last;
    zT_13 = zT_12->size;
    old_size = zT_13;
    zT_15 = gs->last;
    zT_16 = zT_15->size;
    zT_17 = 2;
    zT_18 = zT_16 * zT_17;
    new_size = zT_18;
    zT_20 = 1048576;
    max_segment = zT_20;
    if ((unsigned char)(new_size > max_segment)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    new_size = max_segment;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(size > new_size)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    new_size = size;
    goto z_bb_6;
    z_bb_6:
    zT_24 = zG_D5B16534_seg_free_head.has_value;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = new_size;
    zT_26 = zF_DFE38AD3_popFreeBestFit(zT_25);
    zT_27 = zT_26.has_value;
    if (zT_27) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_39 = gs->backing;
    zT_40 = new_size;
    zT_43 = 4;
    zT_45 = zF_1395EB68_sandAlloc(zT_39, zT_40, (unsigned int)((unsigned int)zT_43));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    seg = zT_26.value;
    zT_30 = seg->end;
    seg_cap = zT_30;
    zT_31.has_value = 1;
    zT_31.value = seg;
    zT_32 = gs->last;
    zT_32->next = zT_31;
    gs->last = seg;
    zT_33.has_value = 0;
    seg->next = zT_33;
    seg->size = new_size;
    seg->end = seg_cap;
    zT_34 = seg->start;
    view->start = zT_34;
    zT_35 = seg->end;
    view->end = zT_35;
    view->pos = (unsigned int)(0);
    return (unsigned char)(1);
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_47 = zT_45.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_47;
    zT_51 = gs->backing;
    zT_56 = 4;
    zT_58 = zF_1395EB68_sandAlloc(zT_51, (unsigned int)(20), (unsigned int)((unsigned int)zT_56));
    zT_59 = zT_58.is_error;
    if (zT_59) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (unsigned char)(0);
    z_bb_15:
    zT_60 = zT_58.data.payload;
    goto z_bb_16;
    z_bb_16:
    seg_raw = zT_60;
    zT_64 = (zT_C59F83AC_SandSegment*)seg_raw;
    node = zT_64;
    zT_65.start = raw;
    zT_65.size = new_size;
    zT_65.end = new_size;
    zT_66.has_value = 0;
    zT_65.next = zT_66;
    *node = zT_65;
    zT_67.has_value = 1;
    zT_67.value = node;
    zT_68 = gs->last;
    zT_68->next = zT_67;
    gs->last = node;
    zT_69 = node->start;
    view->start = zT_69;
    zT_70 = node->end;
    view->end = zT_70;
    view->pos = (unsigned int)(0);
    zT_75 = view->name;
    zT_72 = zT_75;
    zT_73 = old_size;
    zT_74 = new_size;
    zF_4C1017CD_arenaGrew(zT_72, zT_73, zT_74);
    return (unsigned char)(1);
}

/* popFreeBestFit */
zT_6B32A9CF_Opt_239 zF_DFE38AD3_popFreeBestFit(unsigned int min_cap) {
    unsigned char zT_6;
    unsigned int zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_6B32A9CF_Opt_239 zT_15;
    unsigned int zT_16;
    zT_6B32A9CF_Opt_239 zT_18;
    unsigned int zT_19;
    zT_6B32A9CF_Opt_239 zT_21;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_6B32A9CF_Opt_239 zT_26;
    zT_6B32A9CF_Opt_239 zT_27;
    zT_6B32A9CF_Opt_239 zT_28 = {0};
    zT_6B32A9CF_Opt_239 zT_29;
    zT_6B32A9CF_Opt_239 zT_30 = {0};
    zT_6B32A9CF_Opt_239 best;
    zT_6B32A9CF_Opt_239 best_prev;
    zT_6B32A9CF_Opt_239 prev;
    zT_6B32A9CF_Opt_239 cur;
    zT_C59F83AC_SandSegment* c;
    zT_C59F83AC_SandSegment* b;
    zT_C59F83AC_SandSegment* bp;
    best.has_value = 0;
    best_prev.has_value = 0;
    prev.has_value = 0;
    cur = zG_D5B16534_seg_free_head;
    goto z_bb_1;
    z_bb_1:
    zT_6 = cur.has_value;
    if (zT_6) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    c = cur.value;
    zT_8 = c->end;
    if ((unsigned char)(zT_8 >= min_cap)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_22 = best.has_value;
    if (zT_22) goto z_bb_16; else goto z_bb_17;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_10 = best.has_value;
    if (zT_10) goto z_bb_7; else goto z_bb_9;
    z_bb_6:
    prev = cur;
    zT_21 = c->next;
    cur = zT_21;
    goto z_bb_4;
    z_bb_7:
    b = best.value;
    zT_12 = c->end;
    zT_13 = b->end;
    if ((unsigned char)(zT_12 < zT_13)) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_18.has_value = 1;
    zT_18.value = c;
    best = zT_18;
    best_prev = prev;
    zT_19 = c->end;
    if ((unsigned char)(zT_19 == min_cap)) goto z_bb_14; else goto z_bb_15;
    z_bb_10:
    zT_15.has_value = 1;
    zT_15.value = c;
    best = zT_15;
    best_prev = prev;
    zT_16 = c->end;
    if ((unsigned char)(zT_16 == min_cap)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    goto z_bb_3;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    goto z_bb_3;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    b = best.value;
    zT_24 = best_prev.has_value;
    if (zT_24) goto z_bb_18; else goto z_bb_20;
    z_bb_17:
    zT_30.has_value = 0;
    return zT_30;
    z_bb_18:
    bp = best_prev.value;
    zT_26 = b->next;
    bp->next = zT_26;
    goto z_bb_19;
    z_bb_19:
    zT_28.has_value = 0;
    b->next = zT_28;
    zT_29.has_value = 1;
    zT_29.value = b;
    return zT_29;
    z_bb_20:
    zT_27 = b->next;
    zG_D5B16534_seg_free_head = zT_27;
    goto z_bb_19;
}

/* arenaGrew */
void zF_4C1017CD_arenaGrew(zT_8F083A69_Slice_zT_0B42B2F8_u name, unsigned int old_size, unsigned int new_size) {
    unsigned char zT_3 = 0;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u p0;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_8F083A69_Slice_zT_0B42B2F8_u p3;
    zT_3 = zF_F632D1ED_isMarkersEnabled();
    if ((unsigned char)(!zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = "arena ";
    zT_8 = 6;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    p0 = zT_7;
    zT_9 = p0;
    zF_B5478454_measureMarkerWrite(zT_9);
    zT_10 = name;
    zF_B5478454_measureMarkerWrite(zT_10);
    zT_12 = ": grew ";
    zT_14 = 7;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    p1 = zT_13;
    zT_15 = p1;
    zF_B5478454_measureMarkerWrite(zT_15);
    zT_16 = old_size;
    zF_139949FD_writeUsizeExact(zT_16);
    zT_18 = " -> ";
    zT_20 = 4;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    p2 = zT_19;
    zT_21 = p2;
    zF_B5478454_measureMarkerWrite(zT_21);
    zT_22 = new_size;
    zF_139949FD_writeUsizeExact(zT_22);
    zT_24 = "\n";
    zT_26 = 1;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    p3 = zT_25;
    zT_27 = p3;
    zF_B5478454_measureMarkerWrite(zT_27);
    return;
}

/* writeUsizeExact */
void zF_139949FD_writeUsizeExact(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13 = 0;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned char* zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int len;
    unsigned int start;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_9 = 0;
    zT_10 = (unsigned char*)((unsigned char*)buf) + zT_9;
    zT_11 = (unsigned int)(16) - zT_9;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    zT_5 = zT_12;
    zT_13 = zF_A7504564_itoa((unsigned int)((unsigned int)val), zT_5);
    len = zT_13;
    zT_19 = (unsigned int)((unsigned int)(16) - (unsigned int)((unsigned int)len)) - (unsigned int)(1);
    start = zT_19;
    zT_24 = (unsigned char*)((unsigned char*)buf) + start;
    zT_25 = (unsigned int)(15) - start;
    zT_26.ptr = zT_24;
    zT_26.len = zT_25;
    zT_20 = zT_26;
    zF_B5478454_measureMarkerWrite(zT_20);
    return;
}

/* sandResetPeak */
void zF_CB5A85E9_sandResetPeak(zT_3E40CD83_Sand* sand) {
    unsigned int zT_1;
    zT_1 = sand->pos;
    sand->peak = zT_1;
    return;
}

/* sandTryReallocInPlace */
zT_7032B1AE_Opt_236 zF_33A3D4F8_sandTryReallocInPla(zT_3E40CD83_Sand* sand, unsigned char* old_ptr, unsigned int old_size, unsigned int new_size, unsigned int alignment) {
    zT_7032B1AE_Opt_236 zT_6;
    unsigned int zT_9;
    unsigned char* zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    zT_7032B1AE_Opt_236 zT_26;
    zT_7032B1AE_Opt_236 zT_27 = {0};
    unsigned int old_end;
    unsigned int arena_end;
    unsigned int new_pos;
    (void)alignment;
    if ((unsigned char)(new_size <= old_size)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6.has_value = 1;
    zT_6.value = old_ptr;
    return zT_6;
    z_bb_2:
    zT_9 = (unsigned int)((unsigned int)old_ptr) + old_size;
    old_end = zT_9;
    zT_11 = sand->start;
    zT_13 = sand->pos;
    zT_14 = (unsigned int)((unsigned int)zT_11) + zT_13;
    arena_end = zT_14;
    if ((unsigned char)(old_end == arena_end)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = sand->pos;
    zT_19 = zT_17 + (unsigned int)(new_size - old_size);
    new_pos = zT_19;
    zT_20 = sand->end;
    if ((unsigned char)(new_pos <= zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_27.has_value = 0;
    return zT_27;
    z_bb_5:
    sand->pos = new_pos;
    zT_22 = sand->pos;
    zT_23 = sand->peak;
    if ((unsigned char)(zT_22 > zT_23)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_25 = sand->pos;
    sand->peak = zT_25;
    goto z_bb_8;
    z_bb_8:
    zT_26.has_value = 1;
    zT_26.value = old_ptr;
    return zT_26;
}

/* sandReallocInPlace */
zT_7032B1AE_Opt_236 zF_B635FA63_sandReallocInPlace(zT_3E40CD83_Sand* sand, unsigned char* old_ptr, unsigned int old_size, unsigned int new_size, unsigned int alignment) {
    zT_3E40CD83_Sand* zT_5;
    unsigned char* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_7032B1AE_Opt_236 zT_10 = {0};
    zT_5 = sand;
    zT_6 = old_ptr;
    zT_7 = old_size;
    zT_8 = new_size;
    zT_9 = alignment;
    zT_10 = zF_33A3D4F8_sandTryReallocInPla(zT_5, zT_6, zT_7, zT_8, zT_9);
    return zT_10;
}

/* poolPtr */
zT_3E40CD83_Sand* zF_8C23960F_poolPtr(void) {
    zT_3E40CD83_Sand* zT_1;
    zT_1 = &zG_91DD7983_pool;
    return zT_1;
}

/* poolPeak */
unsigned int zF_E5D0D49C_poolPeak(void) {
    unsigned int zT_1;
    zT_1 = zG_91DD7983_pool.peak;
    return zT_1;
}

/* initCompilerAlloc */
zT_69057089_CompilerAlloc zF_90E832C7_initCompilerAlloc(void) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_0;
    int zT_4;
    unsigned char* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_3E40CD83_Sand zT_8 = {0};
    zT_7D82FE60_GrowableSand* zT_9;
    zT_3E40CD83_Sand* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_17;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_7D82FE60_GrowableSand* zT_22;
    zT_3E40CD83_Sand* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    int zT_30;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_7D82FE60_GrowableSand* zT_35;
    zT_3E40CD83_Sand* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    int zT_43;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_7D82FE60_GrowableSand* zT_48;
    zT_3E40CD83_Sand* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_7D82FE60_GrowableSand* zT_61;
    zT_3E40CD83_Sand* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    int zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_69057089_CompilerAlloc zT_75;
    zT_3E40CD83_Sand zT_77;
    zT_3E40CD83_Sand zT_79;
    zT_3E40CD83_Sand zT_81;
    zT_3E40CD83_Sand zT_83;
    zT_3E40CD83_Sand zT_85;
    unsigned int zT_86;
    zT_69057089_CompilerAlloc ca;
    zT_4 = 0;
    zT_5 = (unsigned char*)((unsigned char*)zG_EEB4E6C3_memory_pool_buf) + zT_4;
    zT_6 = (unsigned int)(268435456) - zT_4;
    zT_7.ptr = zT_5;
    zT_7.len = zT_6;
    zT_0 = zT_7;
    zT_8 = zF_CE0A77DD_sandInit(zT_0);
    zG_91DD7983_pool = zT_8;
    zT_9 = &zG_2D921856_perm_gs;
    zT_10 = &zG_91DD7983_pool;
    zT_17 = 4096;
    zT_19 = "perm";
    zT_21 = 4;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    zT_12 = zT_20;
    zF_07B11742_growableSandInit(zT_9, zT_10, (unsigned int)((unsigned int)zT_17), zT_12);
    zT_22 = &zG_D2119B4E_mod_gs;
    zT_23 = &zG_91DD7983_pool;
    zT_30 = 4096;
    zT_32 = "module";
    zT_34 = 6;
    zT_33.ptr = zT_32;
    zT_33.len = zT_34;
    zT_25 = zT_33;
    zF_07B11742_growableSandInit(zT_22, zT_23, (unsigned int)((unsigned int)zT_30), zT_25);
    zT_35 = &zG_8901137E_scr_gs;
    zT_36 = &zG_91DD7983_pool;
    zT_43 = 4096;
    zT_45 = "scratch";
    zT_47 = 7;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    zT_38 = zT_46;
    zF_07B11742_growableSandInit(zT_35, zT_36, (unsigned int)((unsigned int)zT_43), zT_38);
    zT_48 = &zG_74F406AB_lir_gs;
    zT_49 = &zG_91DD7983_pool;
    zT_56 = 4096;
    zT_58 = "lir_read";
    zT_60 = 8;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    zT_51 = zT_59;
    zF_07B11742_growableSandInit(zT_48, zT_49, (unsigned int)((unsigned int)zT_56), zT_51);
    zT_61 = &zG_DD5B2E91_emit_gs;
    zT_62 = &zG_91DD7983_pool;
    zT_69 = 4096;
    zT_71 = "emission";
    zT_73 = 8;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    zT_64 = zT_72;
    zF_07B11742_growableSandInit(zT_61, zT_62, (unsigned int)((unsigned int)zT_69), zT_64);
    zT_77 = zG_2D921856_perm_gs.view;
    zT_75.permanent = zT_77;
    zT_79 = zG_D2119B4E_mod_gs.view;
    zT_75.module = zT_79;
    zT_81 = zG_8901137E_scr_gs.view;
    zT_75.scratch = zT_81;
    zT_83 = zG_74F406AB_lir_gs.view;
    zT_75.lir_read = zT_83;
    zT_85 = zG_DD5B2E91_emit_gs.view;
    zT_75.emission = zT_85;
    zT_86 = 16777216;
    zT_75.max_mem = zT_86;
    ca = zT_75;
    return ca;
}

/* checkCombinedPeak */
void zF_BA490D17_checkCombinedPeak(zT_69057089_CompilerAlloc* alloc) {
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    int zT_42;
    unsigned int pool_kb;
    unsigned int limit_kb;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm;
    zT_8F083A69_Slice_zT_0B42B2F8_u p;
    zT_8F083A69_Slice_zT_0B42B2F8_u t;
    zT_3 = zG_91DD7983_pool.peak;
    zT_5 = zT_3 / (unsigned int)(1024);
    pool_kb = zT_5;
    zT_9 = 262144;
    limit_kb = zT_9;
    zT_10 = alloc->max_mem;
    zT_11 = 0;
    if ((unsigned char)(zT_10 != (unsigned int)zT_11)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = alloc->max_mem;
    zT_14 = (unsigned int)zT_13;
    limit_kb = zT_14;
    goto z_bb_2;
    z_bb_2:
    if ((unsigned char)(pool_kb > limit_kb)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_17 = "memory limit exceeded: pool limit=";
    zT_19 = 34;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    mm = zT_18;
    zT_20 = mm;
    zF_E4B2EF19_stderr_write(zT_20);
    zT_21 = limit_kb;
    zF_4ACF6BFE_printUsize(zT_21);
    zT_23 = "K pool=";
    zT_25 = 7;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    p = zT_24;
    zT_26 = p;
    zF_E4B2EF19_stderr_write(zT_26);
    zT_27 = pool_kb;
    zF_4ACF6BFE_printUsize(zT_27);
    zT_29 = "K\n";
    zT_31 = 2;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    t = zT_30;
    zT_32 = t;
    zF_E4B2EF19_stderr_write(zT_32);
    zT_36 = "out of memory";
    zT_38 = 13;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    zT_33 = zT_37;
    zT_39 = "allocator.zig";
    zT_41 = 13;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    zT_34 = zT_40;
    zT_42 = 28;
    zF_6D97D338_panicHandler(zT_33, zT_34, (unsigned int)((unsigned int)zT_42));
    goto z_bb_4;
    z_bb_4:
    return;
}

/* printUsize */
void zF_4ACF6BFE_printUsize(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13 = 0;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int len;
    unsigned int start;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_9 = 0;
    zT_10 = (unsigned char*)((unsigned char*)buf) + zT_9;
    zT_11 = (unsigned int)(16) - zT_9;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    zT_5 = zT_12;
    zT_13 = zF_A7504564_itoa((unsigned int)((unsigned int)val), zT_5);
    len = zT_13;
    zT_17 = (unsigned int)(15) - (unsigned int)((unsigned int)len);
    start = zT_17;
    zT_22 = (unsigned char*)((unsigned char*)buf) + start;
    zT_23 = (unsigned int)(15) - start;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_18 = zT_24;
    zF_E4B2EF19_stderr_write(zT_18);
    return;
}

/* trackingAllocatorInit */
zT_36103E01_TrackingAllocator zF_76B743BF_trackingAllocatorIn(zT_3E40CD83_Sand* arena) {
    zT_36103E01_TrackingAllocator zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_1.arena = arena;
    zT_2 = 0;
    zT_1.total_allocated = zT_2;
    zT_3 = 0;
    zT_1.peak_allocated = zT_3;
    zT_4 = 0;
    zT_1.allocation_count = zT_4;
    return zT_1;
}

/* trackingAlloc */
zT_ACA03DB3_EU_632 zF_A3D28661_trackingAlloc(zT_36103E01_TrackingAllocator* tracker, unsigned int size, unsigned int alignment) {
    zT_3E40CD83_Sand* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_ACA03DB3_EU_632 zT_8 = {0};
    unsigned char zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    int zT_12;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_ACA03DB3_EU_632 zT_22;
    unsigned char* ptr;
    zT_4 = tracker->arena;
    zT_5 = size;
    zT_6 = alignment;
    zT_8 = zF_1395EB68_sandAlloc(zT_4, zT_5, zT_6);
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zT_8;
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    ptr = zT_10;
    zT_11 = tracker->allocation_count;
    zT_12 = 1;
    tracker->allocation_count = (unsigned int)(zT_11 + (unsigned int)((unsigned int)zT_12));
    zT_15 = tracker->total_allocated;
    tracker->total_allocated = (unsigned int)(zT_15 + (unsigned int)((unsigned int)size));
    zT_18 = tracker->total_allocated;
    zT_19 = tracker->peak_allocated;
    if ((unsigned char)(zT_18 > zT_19)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_21 = tracker->total_allocated;
    tracker->peak_allocated = zT_21;
    goto z_bb_5;
    z_bb_5:
    zT_22.data.payload = ptr;
    zT_22.is_error = 0;
    return zT_22;
}

/* trackingReset */
void zF_BABD990B_trackingReset(zT_36103E01_TrackingAllocator* tracker) {
    zT_3E40CD83_Sand* zT_1;
    zT_1 = tracker->arena;
    zF_F1B3F8C2_sandReset(zT_1);
    tracker->total_allocated = (unsigned int)(0);
    return;
}

/* trackingPeak */
unsigned int zF_6D8BD187_trackingPeak(zT_36103E01_TrackingAllocator* tracker) {
    unsigned int zT_1;
    zT_1 = tracker->peak_allocated;
    return zT_1;
}

/* trackingAllocatorReport */
zT_5FDE47EF_TrackingAllocatorRe zF_6F4768CF_trackingAllocatorRe(zT_36103E01_TrackingAllocator* tracker) {
    zT_5FDE47EF_TrackingAllocatorRe zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = tracker->peak_allocated;
    zT_1.peak = zT_2;
    zT_3 = tracker->total_allocated;
    zT_1.total = zT_3;
    zT_4 = tracker->allocation_count;
    zT_1.count = zT_4;
    return zT_1;
}

/* __module_init */
void zF_780653D2___module_init_1(void) {
    zT_6B32A9CF_Opt_239 zT_0 = {0};
    zT_0.has_value = 0;
    zG_D5B16534_seg_free_head = zT_0;
    zG_7135C933_DEV_MAX_MEM = (unsigned int)(16777216);
    zG_3B40C71D_RELEASE_MAX_MEM = (unsigned int)(16777216);
    zG_18AE3D2F_DEFAULT_MAX_MEM_KB = (unsigned int)(65536);
    return;
}

/* EOF */
