#include "main_9472B9CB.h"
/* main */
void zF_EA90E208_main(int argc, unsigned char** argv) {
    int zT_2;
    unsigned char** zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_C98AF326_CompilerCli zT_10 = {0};
    unsigned char zT_11;
    unsigned char zT_14;
    zT_69057089_CompilerAlloc zT_16 = {0};
    zT_3E40CD83_Sand* zT_18;
    zT_69057089_CompilerAlloc* zT_20;
    int zT_22;
    zT_D3EB6303_StringInterner zT_24 = {0};
    zT_3E40CD83_Sand* zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_227EDE07_SourceManager zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_227EDE07_SourceManager* zT_32;
    zT_D3EB6303_StringInterner* zT_33;
    zT_69057089_CompilerAlloc* zT_34;
    zT_3E40CD83_Sand* zT_39;
    zT_69057089_CompilerAlloc* zT_40;
    unsigned char zT_42;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_53;
    int zT_54;
    unsigned char zT_56;
    unsigned char zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char zT_60 = 0;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_69057089_CompilerAlloc zT_77 = {0};
    unsigned int zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_3E40CD83_Sand* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    zT_69057089_CompilerAlloc* zT_85;
    zT_07DD6349_Opt_466 zT_87 = {0};
    unsigned char zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_101;
    unsigned int zT_104;
    unsigned int zT_108;
    unsigned int zT_111;
    unsigned int zT_114;
    unsigned int zT_117;
    unsigned int zT_120;
    unsigned int zT_123;
    unsigned int zT_126;
    unsigned int zT_129;
    unsigned int zT_132;
    unsigned int zT_135;
    unsigned int zT_138;
    zT_3E40CD83_Sand* zT_140;
    unsigned int zT_141;
    zT_69057089_CompilerAlloc* zT_142;
    zT_D3EB6303_StringInterner zT_144 = {0};
    zT_3E40CD83_Sand* zT_146;
    zT_69057089_CompilerAlloc* zT_147;
    zT_227EDE07_SourceManager zT_149 = {0};
    zT_3E40CD83_Sand* zT_151;
    zT_227EDE07_SourceManager* zT_152;
    zT_D3EB6303_StringInterner* zT_153;
    zT_69057089_CompilerAlloc* zT_154;
    zT_F85C5DED_DiagnosticCollector zT_158 = {0};
    unsigned int zT_159;
    zT_3E40CD83_Sand* zT_161;
    zT_69057089_CompilerAlloc* zT_162;
    zT_3E40CD83_Sand* zT_165;
    zT_D3EB6303_StringInterner* zT_166;
    zT_F85C5DED_DiagnosticCollector* zT_167;
    zT_69057089_CompilerAlloc* zT_168;
    zT_072B53A6_ModuleRegistry zT_172 = {0};
    zT_072B53A6_ModuleRegistry* zT_173;
    zT_227EDE07_SourceManager* zT_174;
    zT_072B53A6_ModuleRegistry* zT_177;
    unsigned char zT_178;
    zT_7D82FE60_GrowableSand zT_182 = {0};
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_7D82FE60_GrowableSand* zT_187;
    zT_3E40CD83_Sand* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    zT_3E40CD83_Sand* zT_192 = 0;
    int zT_193;
    zT_3E40CD83_Sand* zT_196;
    zT_D3EB6303_StringInterner* zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    zT_7D82FE60_GrowableSand* zT_200;
    zT_338B7C76_TypeRegistry zT_203 = {0};
    zT_338B7C76_TypeRegistry* zT_204;
    zT_3E40CD83_Sand* zT_207;
    zT_69057089_CompilerAlloc* zT_208;
    zT_6B0A7D14_AstStore zT_210 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_212;
    unsigned int zT_214;
    unsigned char zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_219;
    unsigned int zT_221;
    unsigned char zT_223;
    unsigned char* zT_226;
    unsigned char zT_227;
    unsigned int zT_229;
    unsigned int zT_231;
    unsigned char zT_232;
    unsigned int zT_234;
    unsigned char zT_235;
    unsigned int zT_237;
    unsigned char zT_238;
    unsigned int zT_240;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    unsigned int zT_246;
    unsigned int zT_248;
    unsigned char zT_250;
    unsigned char* zT_253;
    unsigned char zT_254;
    unsigned int zT_256;
    unsigned int zT_258;
    zT_6B0A7D14_AstStore* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    int zT_264;
    unsigned char* zT_265;
    unsigned int zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    zT_846744CC_Arr_unsigned_char_5 zT_269;
    unsigned int zT_271;
    unsigned char zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_276;
    unsigned int zT_278;
    unsigned char zT_280;
    unsigned char* zT_283;
    unsigned char zT_284;
    unsigned int zT_286;
    unsigned int zT_288;
    unsigned char zT_289;
    unsigned int zT_291;
    unsigned char zT_292;
    unsigned int zT_294;
    unsigned char zT_295;
    unsigned int zT_297;
    unsigned char* zT_299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_300;
    unsigned int zT_301;
    unsigned int zT_303;
    unsigned int zT_305;
    unsigned char zT_307;
    unsigned char* zT_310;
    unsigned char zT_311;
    unsigned int zT_313;
    unsigned int zT_315;
    zT_6B0A7D14_AstStore* zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_318;
    int zT_323;
    unsigned char* zT_324;
    unsigned int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    zT_846744CC_Arr_unsigned_char_5 zT_328;
    unsigned int zT_330;
    unsigned char zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_335;
    unsigned int zT_337;
    unsigned char zT_339;
    unsigned char* zT_342;
    unsigned char zT_343;
    unsigned int zT_345;
    unsigned int zT_347;
    unsigned char zT_348;
    unsigned int zT_350;
    unsigned char zT_351;
    unsigned int zT_353;
    unsigned char zT_354;
    unsigned int zT_356;
    unsigned char* zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    unsigned int zT_360;
    unsigned int zT_362;
    unsigned int zT_364;
    unsigned char zT_366;
    unsigned char* zT_369;
    unsigned char zT_370;
    unsigned int zT_372;
    unsigned int zT_374;
    zT_6B0A7D14_AstStore* zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_377;
    int zT_382;
    unsigned char* zT_383;
    unsigned int zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    zT_846744CC_Arr_unsigned_char_5 zT_387;
    unsigned int zT_389;
    unsigned char zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_392;
    unsigned int zT_394;
    unsigned int zT_396;
    unsigned char zT_398;
    unsigned char* zT_401;
    unsigned char zT_402;
    unsigned int zT_404;
    unsigned int zT_406;
    unsigned char zT_407;
    unsigned int zT_409;
    unsigned char zT_410;
    unsigned int zT_412;
    unsigned char zT_413;
    unsigned int zT_415;
    unsigned char* zT_417;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_418;
    unsigned int zT_419;
    unsigned int zT_421;
    unsigned int zT_423;
    unsigned char zT_425;
    unsigned char* zT_428;
    unsigned char zT_429;
    unsigned int zT_431;
    unsigned int zT_433;
    zT_6B0A7D14_AstStore* zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_436;
    int zT_441;
    unsigned char* zT_442;
    unsigned int zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_444;
    zT_846744CC_Arr_unsigned_char_5 zT_446;
    unsigned int zT_448;
    unsigned char zT_449;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    unsigned int zT_453;
    unsigned int zT_455;
    unsigned char zT_457;
    unsigned char* zT_460;
    unsigned char zT_461;
    unsigned int zT_463;
    unsigned int zT_465;
    unsigned char zT_466;
    unsigned int zT_468;
    unsigned char zT_469;
    unsigned int zT_471;
    unsigned char zT_472;
    unsigned int zT_474;
    unsigned char* zT_476;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_477;
    unsigned int zT_478;
    unsigned int zT_480;
    unsigned int zT_482;
    unsigned char zT_484;
    unsigned char* zT_487;
    unsigned char zT_488;
    unsigned int zT_490;
    unsigned int zT_492;
    zT_6B0A7D14_AstStore* zT_493;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_495;
    int zT_500;
    unsigned char* zT_501;
    unsigned int zT_502;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_503;
    zT_3E40CD83_Sand* zT_505;
    zT_69057089_CompilerAlloc* zT_506;
    zT_3D7259E2_SymbolRegistry zT_508 = {0};
    zT_3E40CD83_Sand* zT_510;
    zT_69057089_CompilerAlloc* zT_511;
    zT_8EED1867_ResolvedTypeTable zT_513 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_515;
    unsigned int zT_517;
    unsigned char zT_518;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_520;
    unsigned int zT_522;
    unsigned int zT_524;
    unsigned char zT_526;
    unsigned char* zT_529;
    unsigned char zT_530;
    unsigned int zT_532;
    unsigned int zT_534;
    unsigned char zT_535;
    unsigned int zT_537;
    unsigned char zT_538;
    unsigned int zT_540;
    unsigned char zT_541;
    unsigned int zT_543;
    unsigned char* zT_545;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_546;
    unsigned int zT_547;
    unsigned int zT_549;
    unsigned int zT_551;
    unsigned char zT_553;
    unsigned char* zT_556;
    unsigned char zT_557;
    unsigned int zT_559;
    unsigned int zT_561;
    zT_8EED1867_ResolvedTypeTable* zT_562;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_563;
    int zT_567;
    unsigned char* zT_568;
    unsigned int zT_569;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_570;
    zT_3E40CD83_Sand* zT_572;
    zT_69057089_CompilerAlloc* zT_573;
    zT_66E7D2EF_CoercionTable zT_575 = {0};
    zT_3E40CD83_Sand* zT_577;
    zT_69057089_CompilerAlloc* zT_578;
    zT_CA01C129_LirSlotArrayList zT_580 = {0};
    zT_3E40CD83_Sand* zT_582;
    zT_69057089_CompilerAlloc* zT_583;
    zT_4D61441E_DepGraph zT_585 = {0};
    zT_3E40CD83_Sand* zT_587;
    zT_69057089_CompilerAlloc* zT_588;
    zT_21D3708C_U32ToU32Map zT_590 = {0};
    zT_3E40CD83_Sand* zT_592;
    zT_69057089_CompilerAlloc* zT_593;
    zT_21D3708C_U32ToU32Map zT_595 = {0};
    zT_3E40CD83_Sand* zT_597;
    zT_69057089_CompilerAlloc* zT_598;
    zT_21D3708C_U32ToU32Map zT_600 = {0};
    zT_3E40CD83_Sand* zT_602;
    zT_69057089_CompilerAlloc* zT_603;
    zT_21D3708C_U32ToU32Map zT_605 = {0};
    zT_3E40CD83_Sand* zT_607;
    zT_69057089_CompilerAlloc* zT_608;
    zT_21D3708C_U32ToU32Map zT_610 = {0};
    zT_3E40CD83_Sand* zT_612;
    zT_69057089_CompilerAlloc* zT_614;
    zT_77F6F59C_ComptimeFoldTable zT_617 = {0};
    zT_786E6CF2_EmissionClassificat zT_619;
    zT_3E40CD83_Sand* zT_620;
    zT_69057089_CompilerAlloc* zT_621;
    zT_21D3708C_U32ToU32Map zT_623 = {0};
    zT_3E40CD83_Sand* zT_624;
    zT_69057089_CompilerAlloc* zT_625;
    zT_21D3708C_U32ToU32Map zT_627 = {0};
    zT_3E40CD83_Sand* zT_628;
    zT_69057089_CompilerAlloc* zT_629;
    zT_21D3708C_U32ToU32Map zT_631 = {0};
    zT_3E40CD83_Sand* zT_632;
    zT_69057089_CompilerAlloc* zT_633;
    zT_21D3708C_U32ToU32Map zT_635 = {0};
    zT_1317DCD6_C89SpellPlan zT_637 = {0};
    zT_3E40CD83_Sand* zT_639;
    zT_69057089_CompilerAlloc* zT_640;
    zT_A4CE86B7_U64ToU32Map zT_642 = {0};
    zT_3E40CD83_Sand* zT_644;
    zT_69057089_CompilerAlloc* zT_645;
    zT_A4CE86B7_U64ToU32Map zT_647 = {0};
    zT_3E40CD83_Sand* zT_649;
    zT_69057089_CompilerAlloc* zT_650;
    zT_A4CE86B7_U64ToU32Map zT_652 = {0};
    zT_3E40CD83_Sand* zT_654;
    zT_69057089_CompilerAlloc* zT_655;
    zT_A4CE86B7_U64ToU32Map zT_657 = {0};
    zT_3E40CD83_Sand* zT_659;
    zT_69057089_CompilerAlloc* zT_660;
    zT_A4CE86B7_U64ToU32Map zT_662 = {0};
    zT_3E40CD83_Sand* zT_664;
    zT_69057089_CompilerAlloc* zT_665;
    zT_A4CE86B7_U64ToU32Map zT_667 = {0};
    zT_3E40CD83_Sand* zT_669;
    zT_69057089_CompilerAlloc* zT_670;
    zT_A4CE86B7_U64ToU32Map zT_672 = {0};
    zT_3E40CD83_Sand* zT_674;
    zT_69057089_CompilerAlloc* zT_675;
    zT_B687BB96_U32ArrayList zT_677 = {0};
    zT_3E40CD83_Sand* zT_679;
    zT_69057089_CompilerAlloc* zT_680;
    zT_A4CE86B7_U64ToU32Map zT_682 = {0};
    zT_3E40CD83_Sand* zT_684;
    zT_69057089_CompilerAlloc* zT_685;
    zT_A4CE86B7_U64ToU32Map zT_687 = {0};
    zT_3E40CD83_Sand* zT_689;
    zT_69057089_CompilerAlloc* zT_690;
    zT_A4CE86B7_U64ToU32Map zT_692 = {0};
    zT_5AB29387_CompilerContext zT_694;
    zT_69057089_CompilerAlloc* zT_695;
    zT_D3EB6303_StringInterner* zT_696;
    zT_F85C5DED_DiagnosticCollector* zT_697;
    zT_227EDE07_SourceManager* zT_698;
    zT_072B53A6_ModuleRegistry* zT_699;
    zT_338B7C76_TypeRegistry* zT_700;
    zT_6B0A7D14_AstStore* zT_701;
    zT_3D7259E2_SymbolRegistry* zT_702;
    zT_8EED1867_ResolvedTypeTable* zT_703;
    zT_66E7D2EF_CoercionTable* zT_704;
    zT_4D61441E_DepGraph* zT_705;
    zT_7E7544E4_LirStream zT_706 = {0};
    zT_3E40CD83_Sand* zT_707;
    zT_69057089_CompilerAlloc* zT_708;
    zT_E1A783EF_GlobalDeclArrayList zT_710 = {0};
    zT_3E40CD83_Sand* zT_711;
    zT_69057089_CompilerAlloc* zT_712;
    zT_A4CE86B7_U64ToU32Map zT_714 = {0};
    zT_3E40CD83_Sand* zT_715;
    zT_69057089_CompilerAlloc* zT_716;
    zT_B687BB96_U32ArrayList zT_718 = {0};
    zT_5AB29387_CompilerContext* zT_719;
    zT_8F083A69_Slice_zT_0B42B2F8_u startmsg;
    zT_C98AF326_CompilerCli cli;
    zT_69057089_CompilerAlloc compiler_alloc;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u source;
    unsigned int interner_bc;
    unsigned int type_hint;
    unsigned int name_hint;
    unsigned int fold_hint;
    zT_072B53A6_ModuleRegistry mr;
    zT_7D82FE60_GrowableSand type_db_arena;
    zT_8F083A69_Slice_zT_0B42B2F8_u type_db_name;
    zT_338B7C76_TypeRegistry typereg;
    zT_6B0A7D14_AstStore store;
    zT_846744CC_Arr_unsigned_char_5 ast_spill_path;
    unsigned int asp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od2;
    unsigned int oi2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ast_tmp_name;
    unsigned int ati;
    zT_846744CC_Arr_unsigned_char_5 id_spill_path;
    unsigned int idp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od3;
    unsigned int oi3;
    zT_8F083A69_Slice_zT_0B42B2F8_u id_tmp_name;
    unsigned int iti;
    zT_846744CC_Arr_unsigned_char_5 iv_spill_path;
    unsigned int ivp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od5;
    unsigned int oi5;
    zT_8F083A69_Slice_zT_0B42B2F8_u iv_tmp_name;
    unsigned int ivi;
    zT_846744CC_Arr_unsigned_char_5 ec_spill_path;
    unsigned int ecp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od6;
    unsigned int oi6;
    zT_8F083A69_Slice_zT_0B42B2F8_u ec_tmp_name;
    unsigned int eci;
    zT_846744CC_Arr_unsigned_char_5 er_spill_path;
    unsigned int erp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od7;
    unsigned int oi7;
    zT_8F083A69_Slice_zT_0B42B2F8_u er_tmp_name;
    unsigned int eri;
    zT_3D7259E2_SymbolRegistry symbol_reg;
    zT_8EED1867_ResolvedTypeTable resolved_types;
    zT_846744CC_Arr_unsigned_char_5 rtt_spill_path;
    unsigned int rsp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od4;
    unsigned int oi4;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtt_tmp_name;
    unsigned int rti2;
    zT_66E7D2EF_CoercionTable coercion_table;
    zT_CA01C129_LirSlotArrayList lir_slots;
    zT_4D61441E_DepGraph dep_graph;
    zT_21D3708C_U32ToU32Map enum_value_table;
    zT_21D3708C_U32ToU32Map tuple_index_table;
    zT_21D3708C_U32ToU32Map error_code_registry;
    zT_21D3708C_U32ToU32Map call_arg_types;
    zT_21D3708C_U32ToU32Map call_param_map;
    zT_77F6F59C_ComptimeFoldTable comptime_folds;
    zT_786E6CF2_EmissionClassificat emission_classif;
    zT_1317DCD6_C89SpellPlan spell_plan_ph;
    zT_A4CE86B7_U64ToU32Map exported;
    zT_A4CE86B7_U64ToU32Map suspending_fns;
    zT_A4CE86B7_U64ToU32Map frame_sizes;
    zT_A4CE86B7_U64ToU32Map state_widths;
    zT_A4CE86B7_U64ToU32Map awaited_fns;
    zT_A4CE86B7_U64ToU32Map async_hidden_fns;
    zT_A4CE86B7_U64ToU32Map driver_targets;
    zT_B687BB96_U32ArrayList parent_result_type_list;
    zT_A4CE86B7_U64ToU32Map parent_result_start;
    zT_A4CE86B7_U64ToU32Map parent_result_count;
    zT_A4CE86B7_U64ToU32Map async_layouts;
    zT_5AB29387_CompilerContext ctx;
    zT_2 = argc;
    zT_3 = argv;
    zF_4DE8E0A6_initArgs(zT_2, zT_3);
    zT_5 = "START\n";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    startmsg = zT_6;
    zT_8 = startmsg;
    zF_48AC7B3A_markerWrite(zT_8);
    zT_10 = zF_6143A521_parseArgs();
    cli = zT_10;
    zT_11 = cli.show_markers;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zF_3C88665D_markersEnabled((unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    zT_14 = cli.sanity_test_mode;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_16;
    zT_20 = &compiler_alloc;
    zT_18 = &zT_20->permanent;
    zT_22 = 4;
    zT_24 = zF_FB2E811D_stringInternerInit(zT_18, (unsigned int)((unsigned int)zT_22));
    interner = zT_24;
    zT_27 = &compiler_alloc;
    zT_26 = &zT_27->permanent;
    zT_29 = zF_01351F51_sourceManagerInit(zT_26);
    source_man = zT_29;
    zT_34 = &compiler_alloc;
    zT_31 = &zT_34->permanent;
    zT_32 = &source_man;
    zT_33 = &interner;
    (void)zF_C7BA7DAB_diagnosticCollector(zT_31, zT_32, zT_33);
    zT_40 = &compiler_alloc;
    zT_39 = &zT_40->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_39);
    zF_519E4401_lexerTestSanityChec();
    return;
    z_bb_4:
    zT_42 = cli.test_mode;
    if (zT_42) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_44 = "error: use test_main.zig for test mode\n";
    zT_46 = 39;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    msg = zT_45;
    zT_47 = msg;
    zF_48AC7B3A_markerWrite(zT_47);
    zT_49 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_49));
    return;
    z_bb_6:
    zT_51 = cli.input_file;
    zT_53 = zT_51.len;
    zT_54 = 0;
    if ((unsigned char)(zT_53 == (unsigned int)zT_54)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zF_9D45DFBF_printUsage();
    return;
    z_bb_8:
    zT_56 = cli.output_dir_set;
    if (zT_56) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_59 = cli.output_dir;
    zT_58 = zT_59;
    zT_60 = zF_8CC05F84_dirExists(zT_58);
    zT_57 = !zT_60;
    goto z_bb_11;
    z_bb_10:
    zT_57 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_57) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63 = "error: output directory does not exist: ";
    zT_65 = 40;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    msg = zT_64;
    zT_66 = msg;
    zF_E4B2EF19_stderr_write(zT_66);
    zT_68 = cli.output_dir;
    zT_67 = zT_68;
    zF_E4B2EF19_stderr_write(zT_67);
    zT_70 = "\n";
    zT_72 = 1;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    nl = zT_71;
    zT_73 = nl;
    zF_E4B2EF19_stderr_write(zT_73);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_13:
    zT_77 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_77;
    zT_78 = cli.max_mem;
    compiler_alloc.max_mem = zT_78;
    zT_79 = cli.spill_level;
    zF_4EDF4E7B_spillSetLevel(zT_79);
    zT_84 = cli.input_file;
    zT_82 = zT_84;
    zT_85 = &compiler_alloc;
    zT_83 = &zT_85->scratch;
    zT_87 = zF_5B859C63_readFile(zT_82, zT_83);
    zT_88 = zT_87.has_value;
    if (zT_88) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_92 = "error: could not read input file\n";
    zT_94 = 33;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = msg;
    zF_E4B2EF19_stderr_write(zT_95);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_15:
    zT_98 = zT_87.value;
    zT_89 = zT_98;
    goto z_bb_16;
    z_bb_16:
    source = zT_89;
    zT_101 = source.len;
    zT_104 = source.len;
    zT_108 = (unsigned int)((unsigned int)zT_101) + (unsigned int)((unsigned int)(unsigned int)(zT_104 / (unsigned int)(4)));
    interner_bc = zT_108;
    if ((unsigned char)(interner_bc < (unsigned int)(4096))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_111 = 4096;
    interner_bc = zT_111;
    goto z_bb_18;
    z_bb_18:
    zT_114 = source.len;
    zT_117 = (unsigned int)(unsigned int)(zT_114 / (unsigned int)(32));
    type_hint = zT_117;
    if ((unsigned char)(type_hint < (unsigned int)(4096))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_120 = 4096;
    type_hint = zT_120;
    goto z_bb_20;
    z_bb_20:
    zT_123 = source.len;
    zT_126 = (unsigned int)(unsigned int)(zT_123 / (unsigned int)(10));
    name_hint = zT_126;
    if ((unsigned char)(name_hint < (unsigned int)(2048))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_129 = 2048;
    name_hint = zT_129;
    goto z_bb_22;
    z_bb_22:
    zT_132 = source.len;
    zT_135 = (unsigned int)(unsigned int)(zT_132 / (unsigned int)(9));
    fold_hint = zT_135;
    if ((unsigned char)(fold_hint < (unsigned int)(16))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_138 = 16;
    fold_hint = zT_138;
    goto z_bb_24;
    z_bb_24:
    zT_142 = &compiler_alloc;
    zT_140 = &zT_142->permanent;
    zT_141 = interner_bc;
    zT_144 = zF_FB2E811D_stringInternerInit(zT_140, zT_141);
    interner = zT_144;
    zT_147 = &compiler_alloc;
    zT_146 = &zT_147->permanent;
    zT_149 = zF_01351F51_sourceManagerInit(zT_146);
    source_man = zT_149;
    zT_154 = &compiler_alloc;
    zT_151 = &zT_154->permanent;
    zT_152 = &source_man;
    zT_153 = &interner;
    zT_158 = zF_C7BA7DAB_diagnosticCollector(zT_151, zT_152, zT_153);
    diag = zT_158;
    zT_159 = cli.max_errors;
    diag.max_diagnostics = (unsigned int)((unsigned int)zT_159);
    zT_162 = &compiler_alloc;
    zT_161 = &zT_162->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_161);
    zT_168 = &compiler_alloc;
    zT_165 = &zT_168->permanent;
    zT_166 = &interner;
    zT_167 = &diag;
    zT_172 = zF_896FAF3C_moduleRegistryInit(zT_165, zT_166, zT_167);
    mr = zT_172;
    zT_173 = &mr;
    zT_174 = &source_man;
    zF_BD2BF0BD_moduleRegistrySetSo(zT_173, zT_174);
    zT_177 = &mr;
    zT_178 = cli.target_is_windows;
    zF_849BBF28_moduleRegistrySetTa(zT_177, zT_178);
    type_db_arena = zT_182;
    zT_184 = "type_db";
    zT_186 = 7;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    type_db_name = zT_185;
    zT_187 = &type_db_arena;
    zT_192 = zF_8C23960F_poolPtr();
    zT_188 = zT_192;
    zT_193 = 4096;
    zT_190 = type_db_name;
    zF_07B11742_growableSandInit(zT_187, zT_188, (unsigned int)((unsigned int)zT_193), zT_190);
    zT_200 = &type_db_arena;
    zT_196 = &zT_200->view;
    zT_197 = &interner;
    zT_198 = type_hint;
    zT_199 = name_hint;
    zT_203 = zF_28AE6613_typeRegistryInitSiz(zT_196, zT_197, zT_198, zT_199);
    typereg = zT_203;
    zT_204 = &typereg;
    zF_541737A5_typeRegistryRegiste(zT_204);
    zT_208 = &compiler_alloc;
    zT_207 = &zT_208->module;
    zT_210 = zF_D9F91436_astStoreInit(zT_207);
    store = zT_210;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_212[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ast_spill_path[_i] = zT_212[_i];
        _i++;
    }
}
    zT_214 = 0;
    asp_len = zT_214;
    zT_215 = cli.output_dir_set;
    if (zT_215) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    zT_217 = cli.output_dir;
    od2 = zT_217;
    zT_219 = 0;
    oi2 = zT_219;
    goto z_bb_28;
    z_bb_26:
    zT_242 = ".zig1_ast.tmp";
    zT_244 = 13;
    zT_243.ptr = zT_242;
    zT_243.len = zT_244;
    ast_tmp_name = zT_243;
    zT_246 = 0;
    ati = zT_246;
    goto z_bb_35;
    z_bb_27:
    zT_235 = 46;
    ast_spill_path[asp_len] = zT_235;
    zT_237 = asp_len + (unsigned int)(1);
    asp_len = zT_237;
    zT_238 = 47;
    ast_spill_path[asp_len] = zT_238;
    zT_240 = asp_len + (unsigned int)(1);
    asp_len = zT_240;
    goto z_bb_26;
    z_bb_28:
    zT_221 = od2.len;
    if ((unsigned char)(oi2 < zT_221)) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    zT_226 = od2.ptr;
    zT_227 = zT_226[oi2];
    ast_spill_path[asp_len] = zT_227;
    zT_229 = asp_len + (unsigned int)(1);
    asp_len = zT_229;
    goto z_bb_31;
    z_bb_30:
    zT_232 = 47;
    ast_spill_path[asp_len] = zT_232;
    zT_234 = asp_len + (unsigned int)(1);
    asp_len = zT_234;
    goto z_bb_26;
    z_bb_31:
    zT_231 = oi2 + (unsigned int)(1);
    oi2 = zT_231;
    goto z_bb_28;
    z_bb_32:
    zT_223 = asp_len < (unsigned int)(511);
    goto z_bb_34;
    z_bb_33:
    zT_223 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_223) goto z_bb_29; else goto z_bb_30;
    z_bb_35:
    zT_248 = ast_tmp_name.len;
    if ((unsigned char)(ati < zT_248)) goto z_bb_39; else goto z_bb_40;
    z_bb_36:
    zT_253 = ast_tmp_name.ptr;
    zT_254 = zT_253[ati];
    ast_spill_path[asp_len] = zT_254;
    zT_256 = asp_len + (unsigned int)(1);
    asp_len = zT_256;
    goto z_bb_38;
    z_bb_37:
    zT_259 = &store;
    zT_264 = 0;
    zT_265 = (unsigned char*)((unsigned char*)ast_spill_path) + zT_264;
    zT_266 = asp_len - zT_264;
    zT_267.ptr = zT_265;
    zT_267.len = zT_266;
    zT_260 = zT_267;
    zF_2A507339_astStoreSetSpillPat(zT_259, zT_260);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_269[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        id_spill_path[_i] = zT_269[_i];
        _i++;
    }
}
    zT_271 = 0;
    idp_len = zT_271;
    zT_272 = cli.output_dir_set;
    if (zT_272) goto z_bb_42; else goto z_bb_44;
    z_bb_38:
    zT_258 = ati + (unsigned int)(1);
    ati = zT_258;
    goto z_bb_35;
    z_bb_39:
    zT_250 = asp_len < (unsigned int)(511);
    goto z_bb_41;
    z_bb_40:
    zT_250 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_250) goto z_bb_36; else goto z_bb_37;
    z_bb_42:
    zT_274 = cli.output_dir;
    od3 = zT_274;
    zT_276 = 0;
    oi3 = zT_276;
    goto z_bb_45;
    z_bb_43:
    zT_299 = ".zig1_side.tmp";
    zT_301 = 14;
    zT_300.ptr = zT_299;
    zT_300.len = zT_301;
    id_tmp_name = zT_300;
    zT_303 = 0;
    iti = zT_303;
    goto z_bb_52;
    z_bb_44:
    zT_292 = 46;
    id_spill_path[idp_len] = zT_292;
    zT_294 = idp_len + (unsigned int)(1);
    idp_len = zT_294;
    zT_295 = 47;
    id_spill_path[idp_len] = zT_295;
    zT_297 = idp_len + (unsigned int)(1);
    idp_len = zT_297;
    goto z_bb_43;
    z_bb_45:
    zT_278 = od3.len;
    if ((unsigned char)(oi3 < zT_278)) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_283 = od3.ptr;
    zT_284 = zT_283[oi3];
    id_spill_path[idp_len] = zT_284;
    zT_286 = idp_len + (unsigned int)(1);
    idp_len = zT_286;
    goto z_bb_48;
    z_bb_47:
    zT_289 = 47;
    id_spill_path[idp_len] = zT_289;
    zT_291 = idp_len + (unsigned int)(1);
    idp_len = zT_291;
    goto z_bb_43;
    z_bb_48:
    zT_288 = oi3 + (unsigned int)(1);
    oi3 = zT_288;
    goto z_bb_45;
    z_bb_49:
    zT_280 = idp_len < (unsigned int)(511);
    goto z_bb_51;
    z_bb_50:
    zT_280 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_280) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_305 = id_tmp_name.len;
    if ((unsigned char)(iti < zT_305)) goto z_bb_56; else goto z_bb_57;
    z_bb_53:
    zT_310 = id_tmp_name.ptr;
    zT_311 = zT_310[iti];
    id_spill_path[idp_len] = zT_311;
    zT_313 = idp_len + (unsigned int)(1);
    idp_len = zT_313;
    goto z_bb_55;
    z_bb_54:
    zT_316 = &store;
    zT_323 = 0;
    zT_324 = (unsigned char*)((unsigned char*)id_spill_path) + zT_323;
    zT_325 = idp_len - zT_323;
    zT_326.ptr = zT_324;
    zT_326.len = zT_325;
    zT_318 = zT_326;
    zF_35B9B6EC_astStoreSetValuePoo(zT_316, (unsigned int)(0), zT_318);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_328[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        iv_spill_path[_i] = zT_328[_i];
        _i++;
    }
}
    zT_330 = 0;
    ivp_len = zT_330;
    zT_331 = cli.output_dir_set;
    if (zT_331) goto z_bb_59; else goto z_bb_61;
    z_bb_55:
    zT_315 = iti + (unsigned int)(1);
    iti = zT_315;
    goto z_bb_52;
    z_bb_56:
    zT_307 = idp_len < (unsigned int)(511);
    goto z_bb_58;
    z_bb_57:
    zT_307 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_307) goto z_bb_53; else goto z_bb_54;
    z_bb_59:
    zT_333 = cli.output_dir;
    od5 = zT_333;
    zT_335 = 0;
    oi5 = zT_335;
    goto z_bb_62;
    z_bb_60:
    zT_358 = ".zig1_side_iv.tmp";
    zT_360 = 17;
    zT_359.ptr = zT_358;
    zT_359.len = zT_360;
    iv_tmp_name = zT_359;
    zT_362 = 0;
    ivi = zT_362;
    goto z_bb_69;
    z_bb_61:
    zT_351 = 46;
    iv_spill_path[ivp_len] = zT_351;
    zT_353 = ivp_len + (unsigned int)(1);
    ivp_len = zT_353;
    zT_354 = 47;
    iv_spill_path[ivp_len] = zT_354;
    zT_356 = ivp_len + (unsigned int)(1);
    ivp_len = zT_356;
    goto z_bb_60;
    z_bb_62:
    zT_337 = od5.len;
    if ((unsigned char)(oi5 < zT_337)) goto z_bb_66; else goto z_bb_67;
    z_bb_63:
    zT_342 = od5.ptr;
    zT_343 = zT_342[oi5];
    iv_spill_path[ivp_len] = zT_343;
    zT_345 = ivp_len + (unsigned int)(1);
    ivp_len = zT_345;
    goto z_bb_65;
    z_bb_64:
    zT_348 = 47;
    iv_spill_path[ivp_len] = zT_348;
    zT_350 = ivp_len + (unsigned int)(1);
    ivp_len = zT_350;
    goto z_bb_60;
    z_bb_65:
    zT_347 = oi5 + (unsigned int)(1);
    oi5 = zT_347;
    goto z_bb_62;
    z_bb_66:
    zT_339 = ivp_len < (unsigned int)(511);
    goto z_bb_68;
    z_bb_67:
    zT_339 = 0;
    goto z_bb_68;
    z_bb_68:
    if (zT_339) goto z_bb_63; else goto z_bb_64;
    z_bb_69:
    zT_364 = iv_tmp_name.len;
    if ((unsigned char)(ivi < zT_364)) goto z_bb_73; else goto z_bb_74;
    z_bb_70:
    zT_369 = iv_tmp_name.ptr;
    zT_370 = zT_369[ivi];
    iv_spill_path[ivp_len] = zT_370;
    zT_372 = ivp_len + (unsigned int)(1);
    ivp_len = zT_372;
    goto z_bb_72;
    z_bb_71:
    zT_375 = &store;
    zT_382 = 0;
    zT_383 = (unsigned char*)((unsigned char*)iv_spill_path) + zT_382;
    zT_384 = ivp_len - zT_382;
    zT_385.ptr = zT_383;
    zT_385.len = zT_384;
    zT_377 = zT_385;
    zF_35B9B6EC_astStoreSetValuePoo(zT_375, (unsigned int)(1), zT_377);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_387[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ec_spill_path[_i] = zT_387[_i];
        _i++;
    }
}
    zT_389 = 0;
    ecp_len = zT_389;
    zT_390 = cli.output_dir_set;
    if (zT_390) goto z_bb_76; else goto z_bb_78;
    z_bb_72:
    zT_374 = ivi + (unsigned int)(1);
    ivi = zT_374;
    goto z_bb_69;
    z_bb_73:
    zT_366 = ivp_len < (unsigned int)(511);
    goto z_bb_75;
    z_bb_74:
    zT_366 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_366) goto z_bb_70; else goto z_bb_71;
    z_bb_76:
    zT_392 = cli.output_dir;
    od6 = zT_392;
    zT_394 = 0;
    oi6 = zT_394;
    goto z_bb_79;
    z_bb_77:
    zT_417 = ".zig1_extra_ec.tmp";
    zT_419 = 18;
    zT_418.ptr = zT_417;
    zT_418.len = zT_419;
    ec_tmp_name = zT_418;
    zT_421 = 0;
    eci = zT_421;
    goto z_bb_86;
    z_bb_78:
    zT_410 = 46;
    ec_spill_path[ecp_len] = zT_410;
    zT_412 = ecp_len + (unsigned int)(1);
    ecp_len = zT_412;
    zT_413 = 47;
    ec_spill_path[ecp_len] = zT_413;
    zT_415 = ecp_len + (unsigned int)(1);
    ecp_len = zT_415;
    goto z_bb_77;
    z_bb_79:
    zT_396 = od6.len;
    if ((unsigned char)(oi6 < zT_396)) goto z_bb_83; else goto z_bb_84;
    z_bb_80:
    zT_401 = od6.ptr;
    zT_402 = zT_401[oi6];
    ec_spill_path[ecp_len] = zT_402;
    zT_404 = ecp_len + (unsigned int)(1);
    ecp_len = zT_404;
    goto z_bb_82;
    z_bb_81:
    zT_407 = 47;
    ec_spill_path[ecp_len] = zT_407;
    zT_409 = ecp_len + (unsigned int)(1);
    ecp_len = zT_409;
    goto z_bb_77;
    z_bb_82:
    zT_406 = oi6 + (unsigned int)(1);
    oi6 = zT_406;
    goto z_bb_79;
    z_bb_83:
    zT_398 = ecp_len < (unsigned int)(511);
    goto z_bb_85;
    z_bb_84:
    zT_398 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_398) goto z_bb_80; else goto z_bb_81;
    z_bb_86:
    zT_423 = ec_tmp_name.len;
    if ((unsigned char)(eci < zT_423)) goto z_bb_90; else goto z_bb_91;
    z_bb_87:
    zT_428 = ec_tmp_name.ptr;
    zT_429 = zT_428[eci];
    ec_spill_path[ecp_len] = zT_429;
    zT_431 = ecp_len + (unsigned int)(1);
    ecp_len = zT_431;
    goto z_bb_89;
    z_bb_88:
    zT_434 = &store;
    zT_441 = 0;
    zT_442 = (unsigned char*)((unsigned char*)ec_spill_path) + zT_441;
    zT_443 = ecp_len - zT_441;
    zT_444.ptr = zT_442;
    zT_444.len = zT_443;
    zT_436 = zT_444;
    zF_35B9B6EC_astStoreSetValuePoo(zT_434, (unsigned int)(2), zT_436);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_446[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        er_spill_path[_i] = zT_446[_i];
        _i++;
    }
}
    zT_448 = 0;
    erp_len = zT_448;
    zT_449 = cli.output_dir_set;
    if (zT_449) goto z_bb_93; else goto z_bb_95;
    z_bb_89:
    zT_433 = eci + (unsigned int)(1);
    eci = zT_433;
    goto z_bb_86;
    z_bb_90:
    zT_425 = ecp_len < (unsigned int)(511);
    goto z_bb_92;
    z_bb_91:
    zT_425 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_425) goto z_bb_87; else goto z_bb_88;
    z_bb_93:
    zT_451 = cli.output_dir;
    od7 = zT_451;
    zT_453 = 0;
    oi7 = zT_453;
    goto z_bb_96;
    z_bb_94:
    zT_476 = ".zig1_extra_er.tmp";
    zT_478 = 18;
    zT_477.ptr = zT_476;
    zT_477.len = zT_478;
    er_tmp_name = zT_477;
    zT_480 = 0;
    eri = zT_480;
    goto z_bb_103;
    z_bb_95:
    zT_469 = 46;
    er_spill_path[erp_len] = zT_469;
    zT_471 = erp_len + (unsigned int)(1);
    erp_len = zT_471;
    zT_472 = 47;
    er_spill_path[erp_len] = zT_472;
    zT_474 = erp_len + (unsigned int)(1);
    erp_len = zT_474;
    goto z_bb_94;
    z_bb_96:
    zT_455 = od7.len;
    if ((unsigned char)(oi7 < zT_455)) goto z_bb_100; else goto z_bb_101;
    z_bb_97:
    zT_460 = od7.ptr;
    zT_461 = zT_460[oi7];
    er_spill_path[erp_len] = zT_461;
    zT_463 = erp_len + (unsigned int)(1);
    erp_len = zT_463;
    goto z_bb_99;
    z_bb_98:
    zT_466 = 47;
    er_spill_path[erp_len] = zT_466;
    zT_468 = erp_len + (unsigned int)(1);
    erp_len = zT_468;
    goto z_bb_94;
    z_bb_99:
    zT_465 = oi7 + (unsigned int)(1);
    oi7 = zT_465;
    goto z_bb_96;
    z_bb_100:
    zT_457 = erp_len < (unsigned int)(511);
    goto z_bb_102;
    z_bb_101:
    zT_457 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_457) goto z_bb_97; else goto z_bb_98;
    z_bb_103:
    zT_482 = er_tmp_name.len;
    if ((unsigned char)(eri < zT_482)) goto z_bb_107; else goto z_bb_108;
    z_bb_104:
    zT_487 = er_tmp_name.ptr;
    zT_488 = zT_487[eri];
    er_spill_path[erp_len] = zT_488;
    zT_490 = erp_len + (unsigned int)(1);
    erp_len = zT_490;
    goto z_bb_106;
    z_bb_105:
    zT_493 = &store;
    zT_500 = 0;
    zT_501 = (unsigned char*)((unsigned char*)er_spill_path) + zT_500;
    zT_502 = erp_len - zT_500;
    zT_503.ptr = zT_501;
    zT_503.len = zT_502;
    zT_495 = zT_503;
    zF_35B9B6EC_astStoreSetValuePoo(zT_493, (unsigned int)(3), zT_495);
    zT_506 = &compiler_alloc;
    zT_505 = &zT_506->permanent;
    zT_508 = zF_09A884A8_symbolRegistryInit(zT_505);
    symbol_reg = zT_508;
    zT_511 = &compiler_alloc;
    zT_510 = &zT_511->module;
    zT_513 = zF_8D0F00B1_resolvedTypeTableIn(zT_510);
    resolved_types = zT_513;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_515[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        rtt_spill_path[_i] = zT_515[_i];
        _i++;
    }
}
    zT_517 = 0;
    rsp_len = zT_517;
    zT_518 = cli.output_dir_set;
    if (zT_518) goto z_bb_110; else goto z_bb_112;
    z_bb_106:
    zT_492 = eri + (unsigned int)(1);
    eri = zT_492;
    goto z_bb_103;
    z_bb_107:
    zT_484 = erp_len < (unsigned int)(511);
    goto z_bb_109;
    z_bb_108:
    zT_484 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_484) goto z_bb_104; else goto z_bb_105;
    z_bb_110:
    zT_520 = cli.output_dir;
    od4 = zT_520;
    zT_522 = 0;
    oi4 = zT_522;
    goto z_bb_113;
    z_bb_111:
    zT_545 = ".zig1_res.tmp";
    zT_547 = 13;
    zT_546.ptr = zT_545;
    zT_546.len = zT_547;
    rtt_tmp_name = zT_546;
    zT_549 = 0;
    rti2 = zT_549;
    goto z_bb_120;
    z_bb_112:
    zT_538 = 46;
    rtt_spill_path[rsp_len] = zT_538;
    zT_540 = rsp_len + (unsigned int)(1);
    rsp_len = zT_540;
    zT_541 = 47;
    rtt_spill_path[rsp_len] = zT_541;
    zT_543 = rsp_len + (unsigned int)(1);
    rsp_len = zT_543;
    goto z_bb_111;
    z_bb_113:
    zT_524 = od4.len;
    if ((unsigned char)(oi4 < zT_524)) goto z_bb_117; else goto z_bb_118;
    z_bb_114:
    zT_529 = od4.ptr;
    zT_530 = zT_529[oi4];
    rtt_spill_path[rsp_len] = zT_530;
    zT_532 = rsp_len + (unsigned int)(1);
    rsp_len = zT_532;
    goto z_bb_116;
    z_bb_115:
    zT_535 = 47;
    rtt_spill_path[rsp_len] = zT_535;
    zT_537 = rsp_len + (unsigned int)(1);
    rsp_len = zT_537;
    goto z_bb_111;
    z_bb_116:
    zT_534 = oi4 + (unsigned int)(1);
    oi4 = zT_534;
    goto z_bb_113;
    z_bb_117:
    zT_526 = rsp_len < (unsigned int)(511);
    goto z_bb_119;
    z_bb_118:
    zT_526 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_526) goto z_bb_114; else goto z_bb_115;
    z_bb_120:
    zT_551 = rtt_tmp_name.len;
    if ((unsigned char)(rti2 < zT_551)) goto z_bb_124; else goto z_bb_125;
    z_bb_121:
    zT_556 = rtt_tmp_name.ptr;
    zT_557 = zT_556[rti2];
    rtt_spill_path[rsp_len] = zT_557;
    zT_559 = rsp_len + (unsigned int)(1);
    rsp_len = zT_559;
    goto z_bb_123;
    z_bb_122:
    zT_562 = &resolved_types;
    zT_567 = 0;
    zT_568 = (unsigned char*)((unsigned char*)rtt_spill_path) + zT_567;
    zT_569 = rsp_len - zT_567;
    zT_570.ptr = zT_568;
    zT_570.len = zT_569;
    zT_563 = zT_570;
    zF_7238A436_resolvedTypeTableSe(zT_562, zT_563);
    zT_573 = &compiler_alloc;
    zT_572 = &zT_573->module;
    zT_575 = zF_26B6D809_coercionTableInit(zT_572);
    coercion_table = zT_575;
    zT_578 = &compiler_alloc;
    zT_577 = &zT_578->emission;
    zT_580 = zF_F91F6677_lirSlotArrayListIni(zT_577);
    lir_slots = zT_580;
    zT_583 = &compiler_alloc;
    zT_582 = &zT_583->module;
    zT_585 = zF_7F194604_depGraphInit(zT_582);
    dep_graph = zT_585;
    zT_588 = &compiler_alloc;
    zT_587 = &zT_588->module;
    zT_590 = zF_58BDA2DE_u32ToU32MapInit(zT_587);
    enum_value_table = zT_590;
    zT_593 = &compiler_alloc;
    zT_592 = &zT_593->module;
    zT_595 = zF_58BDA2DE_u32ToU32MapInit(zT_592);
    tuple_index_table = zT_595;
    zT_598 = &compiler_alloc;
    zT_597 = &zT_598->emission;
    zT_600 = zF_58BDA2DE_u32ToU32MapInit(zT_597);
    error_code_registry = zT_600;
    zT_603 = &compiler_alloc;
    zT_602 = &zT_603->module;
    zT_605 = zF_58BDA2DE_u32ToU32MapInit(zT_602);
    call_arg_types = zT_605;
    zT_608 = &compiler_alloc;
    zT_607 = &zT_608->module;
    zT_610 = zF_58BDA2DE_u32ToU32MapInit(zT_607);
    call_param_map = zT_610;
    zT_614 = &compiler_alloc;
    zT_612 = &zT_614->module;
    zT_617 = zF_125E6ED1_comptimeFoldTableIn(zT_612, (unsigned int)((unsigned int)fold_hint));
    comptime_folds = zT_617;
    zT_621 = &compiler_alloc;
    zT_620 = &zT_621->permanent;
    zT_623 = zF_58BDA2DE_u32ToU32MapInit(zT_620);
    zT_619.shared_set = zT_623;
    zT_625 = &compiler_alloc;
    zT_624 = &zT_625->permanent;
    zT_627 = zF_58BDA2DE_u32ToU32MapInit(zT_624);
    zT_619.pointer_only_map = zT_627;
    zT_629 = &compiler_alloc;
    zT_628 = &zT_629->permanent;
    zT_631 = zF_58BDA2DE_u32ToU32MapInit(zT_628);
    zT_619.needs_def_map = zT_631;
    zT_633 = &compiler_alloc;
    zT_632 = &zT_633->permanent;
    zT_635 = zF_58BDA2DE_u32ToU32MapInit(zT_632);
    zT_619.needed_tuple_set = zT_635;
    emission_classif = zT_619;
    spell_plan_ph = zT_637;
    zT_640 = &compiler_alloc;
    zT_639 = &zT_640->emission;
    zT_642 = zF_986226E1_u64ToU32MapInit(zT_639);
    exported = zT_642;
    zT_645 = &compiler_alloc;
    zT_644 = &zT_645->module;
    zT_647 = zF_986226E1_u64ToU32MapInit(zT_644);
    suspending_fns = zT_647;
    zT_650 = &compiler_alloc;
    zT_649 = &zT_650->module;
    zT_652 = zF_986226E1_u64ToU32MapInit(zT_649);
    frame_sizes = zT_652;
    zT_655 = &compiler_alloc;
    zT_654 = &zT_655->module;
    zT_657 = zF_986226E1_u64ToU32MapInit(zT_654);
    state_widths = zT_657;
    zT_660 = &compiler_alloc;
    zT_659 = &zT_660->module;
    zT_662 = zF_986226E1_u64ToU32MapInit(zT_659);
    awaited_fns = zT_662;
    zT_665 = &compiler_alloc;
    zT_664 = &zT_665->module;
    zT_667 = zF_986226E1_u64ToU32MapInit(zT_664);
    async_hidden_fns = zT_667;
    zT_670 = &compiler_alloc;
    zT_669 = &zT_670->module;
    zT_672 = zF_986226E1_u64ToU32MapInit(zT_669);
    driver_targets = zT_672;
    zT_675 = &compiler_alloc;
    zT_674 = &zT_675->module;
    zT_677 = zF_8E537D0C_u32ArrayListInit(zT_674);
    parent_result_type_list = zT_677;
    zT_680 = &compiler_alloc;
    zT_679 = &zT_680->module;
    zT_682 = zF_986226E1_u64ToU32MapInit(zT_679);
    parent_result_start = zT_682;
    zT_685 = &compiler_alloc;
    zT_684 = &zT_685->module;
    zT_687 = zF_986226E1_u64ToU32MapInit(zT_684);
    parent_result_count = zT_687;
    zT_690 = &compiler_alloc;
    zT_689 = &zT_690->module;
    zT_692 = zF_986226E1_u64ToU32MapInit(zT_689);
    async_layouts = zT_692;
    zT_694.cli = cli;
    zT_695 = &compiler_alloc;
    zT_694.alloc = zT_695;
    zT_696 = &interner;
    zT_694.interner = zT_696;
    zT_697 = &diag;
    zT_694.diag = zT_697;
    zT_698 = &source_man;
    zT_694.source_man = zT_698;
    zT_699 = &mr;
    zT_694.module_reg = zT_699;
    zT_700 = &typereg;
    zT_694.typereg = zT_700;
    zT_701 = &store;
    zT_694.store = zT_701;
    zT_702 = &symbol_reg;
    zT_694.symbol_reg = zT_702;
    zT_703 = &resolved_types;
    zT_694.resolved_types = zT_703;
    zT_704 = &coercion_table;
    zT_694.coercion_table = zT_704;
    zT_705 = &dep_graph;
    zT_694.dep_graph = zT_705;
    zT_694.lir_slots = lir_slots;
    zT_706 = zF_E9CBFCA6_lirStreamInit();
    zT_694.lir_stream = zT_706;
    zT_694.enum_value_table = enum_value_table;
    zT_694.tuple_index_table = tuple_index_table;
    zT_694.error_code_registry = error_code_registry;
    zT_694.call_arg_types = call_arg_types;
    zT_694.call_param_map = call_param_map;
    zT_694.comptime_folds = comptime_folds;
    zT_694.exported = exported;
    zT_694.suspending_fns = suspending_fns;
    zT_694.frame_sizes = frame_sizes;
    zT_694.state_widths = state_widths;
    zT_694.awaited_fns = awaited_fns;
    zT_694.async_hidden_fns = async_hidden_fns;
    zT_694.driver_targets = driver_targets;
    zT_694.parent_result_type_list = parent_result_type_list;
    zT_694.parent_result_start = parent_result_start;
    zT_694.parent_result_count = parent_result_count;
    zT_694.async_layouts = async_layouts;
    zT_694.emission_classif = emission_classif;
    zT_694.spell_plan = spell_plan_ph;
    zT_708 = &compiler_alloc;
    zT_707 = &zT_708->emission;
    zT_710 = zF_EB0B1609_globalDeclArrayList(zT_707);
    zT_694.global_decls = zT_710;
    zT_712 = &compiler_alloc;
    zT_711 = &zT_712->module;
    zT_714 = zF_986226E1_u64ToU32MapInit(zT_711);
    zT_694.module_init_deps = zT_714;
    zT_716 = &compiler_alloc;
    zT_715 = &zT_716->emission;
    zT_718 = zF_8E537D0C_u32ArrayListInit(zT_715);
    zT_694.module_init_order = zT_718;
    ctx = zT_694;
    zT_719 = &ctx;
    zF_74055C03_runCompiler(zT_719);
    return;
    z_bb_123:
    zT_561 = rti2 + (unsigned int)(1);
    rti2 = zT_561;
    goto z_bb_120;
    z_bb_124:
    zT_553 = rsp_len < (unsigned int)(511);
    goto z_bb_126;
    z_bb_125:
    zT_553 = 0;
    goto z_bb_126;
    z_bb_126:
    if (zT_553) goto z_bb_121; else goto z_bb_122;
}

int main(int argc, char** argv) {
    zF_780653D2___module_init();
    zF_780653D2___module_init_1();
    zF_780653D2___module_init_2();
    zF_780653D2___module_init_3();
    zF_780653D2___module_init_4();
    zF_780653D2___module_init_5();
    zF_780653D2___module_init_6();
    zF_780653D2___module_init_7();
    zF_780653D2___module_init_8();
    zF_780653D2___module_init_9();
    zF_780653D2___module_init_10();
    zF_780653D2___module_init_11();
    zF_780653D2___module_init_12();
    zF_780653D2___module_init_13();
    zF_780653D2___module_init_14();
    zF_780653D2___module_init_15();
    zF_780653D2___module_init_16();
    zF_780653D2___module_init_17();
    zF_780653D2___module_init_18();
    zF_780653D2___module_init_19();
    zF_780653D2___module_init_20();
    zF_780653D2___module_init_21();
    zF_780653D2___module_init_22();
    zF_780653D2___module_init_23();
    zF_780653D2___module_init_24();
    zF_780653D2___module_init_25();
    zF_780653D2___module_init_26();
    zF_780653D2___module_init_27();
    zF_780653D2___module_init_28();
    zF_780653D2___module_init_29();
    zF_EA90E208_main(argc, (unsigned char**)argv);
    return 0;
}

/* runCompiler */
void zF_74055C03_runCompiler(zT_5AB29387_CompilerContext* ctx) {
    zT_5AB29387_CompilerContext* zT_1;
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5AB29387_CompilerContext* zT_24;
    zT_69057089_CompilerAlloc* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    zT_3D7259E2_SymbolRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_D3EB6303_StringInterner* zT_31;
    zT_A4CE86B7_U64ToU32Map* zT_32;
    zT_69057089_CompilerAlloc* zT_33;
    zT_5AB29387_CompilerContext* zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_69057089_CompilerAlloc* zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned char zT_55 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_59;
    zT_69057089_CompilerAlloc* zT_61;
    zT_5AB29387_CompilerContext* zT_63;
    zT_5AB29387_CompilerContext* zT_64;
    zT_5AB29387_CompilerContext* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    unsigned char zT_68 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    int zT_72;
    zT_5AB29387_CompilerContext* zT_74;
    zT_69057089_CompilerAlloc* zT_75;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned char zT_79 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_80;
    int zT_83;
    zT_5AB29387_CompilerContext* zT_85;
    zT_5AB29387_CompilerContext* zT_86;
    zT_69057089_CompilerAlloc* zT_87;
    zT_F85C5DED_DiagnosticCollector* zT_89;
    unsigned char zT_91 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    int zT_95;
    zT_8EED1867_ResolvedTypeTable* zT_97;
    zT_3E40CD83_Sand* zT_99;
    zT_69057089_CompilerAlloc* zT_100;
    zT_5AB29387_CompilerContext* zT_102;
    zT_5AB29387_CompilerContext* zT_103;
    zT_69057089_CompilerAlloc* zT_104;
    zT_C98AF326_CompilerCli zT_106;
    unsigned char zT_107;
    unsigned char zT_108;
    zT_C98AF326_CompilerCli zT_109;
    unsigned char zT_111;
    zT_F85C5DED_DiagnosticCollector* zT_112;
    unsigned int zT_114 = 0;
    int zT_115;
    zT_F85C5DED_DiagnosticCollector* zT_117;
    int zT_120;
    zT_C98AF326_CompilerCli zT_122;
    unsigned char zT_123;
    zT_69057089_CompilerAlloc* zT_125;
    zT_3E40CD83_Sand zT_126;
    unsigned int zT_127;
    unsigned int zT_130;
    zT_69057089_CompilerAlloc* zT_132;
    zT_3E40CD83_Sand zT_133;
    unsigned int zT_134;
    unsigned int zT_137;
    zT_69057089_CompilerAlloc* zT_139;
    zT_3E40CD83_Sand zT_140;
    unsigned int zT_141;
    unsigned int zT_144;
    unsigned int zT_146 = 0;
    unsigned int zT_149;
    zT_338B7C76_TypeRegistry* zT_151;
    zT_3E40CD83_Sand* zT_152;
    unsigned int zT_153;
    unsigned int zT_156;
    unsigned int zT_159;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    unsigned char* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_182;
    unsigned int zT_183;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_194;
    unsigned int zT_195;
    unsigned char* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    zT_F85C5DED_DiagnosticCollector* zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u z2;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3a;
    zT_8F083A69_Slice_zT_0B42B2F8_u z4;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2;
    unsigned int perm_kb;
    unsigned int mod_kb;
    unsigned int scr_kb;
    unsigned int pool_kb;
    unsigned int type_db_kb;
    unsigned int total;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3b;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3c;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg4;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg5;
    zT_1 = ctx;
    zF_E2BA93CE_phase_ImportResolut(zT_1);
    zT_3 = "2\n";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    z2 = zT_4;
    zT_6 = z2;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_7 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_7);
    zT_10 = "3\n";
    zT_12 = 2;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    z3 = zT_11;
    zT_13 = z3;
    zF_48AC7B3A_markerWrite(zT_13);
    zT_15 = "3a\n";
    zT_17 = 3;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    z3a = zT_16;
    zT_18 = z3a;
    zF_48AC7B3A_markerWrite(zT_18);
    zT_20 = "4\n";
    zT_22 = 2;
    zT_21.ptr = zT_20;
    zT_21.len = zT_22;
    z4 = zT_21;
    zT_23 = z4;
    zF_48AC7B3A_markerWrite(zT_23);
    zT_24 = ctx;
    zF_945DEA54_phase_SymbolRegistr(zT_24);
    zT_25 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_25);
    zT_33 = ctx->alloc;
    zT_27 = &zT_33->module;
    zT_28 = ctx->store;
    zT_29 = ctx->symbol_reg;
    zT_30 = ctx->module_reg;
    zT_31 = ctx->interner;
    zT_32 = &ctx->suspending_fns;
    zF_790061E7_suspensionAnalysisR(zT_27, zT_28, zT_29, zT_30, zT_31, zT_32);
    zT_40 = ctx;
    zF_D3497187_phase_TypeResolutio(zT_40);
    zT_42 = "t1\n";
    zT_44 = 3;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    t1 = zT_43;
    zT_45 = t1;
    zF_48AC7B3A_markerWrite(zT_45);
    zT_46 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_46);
    zT_49 = "t2\n";
    zT_51 = 3;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    t2 = zT_50;
    zT_52 = t2;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_53 = ctx->diag;
    zT_55 = zF_8F770780_diagnosticCollector(zT_53);
    if (zT_55) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_56 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_56);
    zT_59 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_59));
    goto z_bb_2;
    z_bb_2:
    zT_61 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_61);
    zT_63 = ctx;
    zF_F862154A_phase_FrontResoluti(zT_63);
    zT_64 = ctx;
    zF_9609BF31_phase_ComptimeEvalu(zT_64);
    zT_65 = ctx;
    zF_0666ED4F_phase_SemanticAnaly(zT_65);
    zT_66 = ctx->diag;
    zT_68 = zF_8F770780_diagnosticCollector(zT_66);
    if (zT_68) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_69 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_69);
    zT_72 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_72));
    goto z_bb_4;
    z_bb_4:
    zT_74 = ctx;
    zF_F3B55B42_phase_StaticAnalyze(zT_74);
    zT_75 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_75);
    zT_77 = ctx->diag;
    zT_79 = zF_8F770780_diagnosticCollector(zT_77);
    if (zT_79) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_80 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_80);
    zT_83 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_83));
    goto z_bb_6;
    z_bb_6:
    zT_85 = ctx;
    zF_9BC6214D_phase_AsyncFrameSiz(zT_85);
    zT_86 = ctx;
    zF_1F21ABE7_phase_LIRLowering(zT_86);
    zT_87 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_87);
    zT_89 = ctx->diag;
    zT_91 = zF_8F770780_diagnosticCollector(zT_89);
    if (zT_91) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_92 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_92);
    zT_95 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_95));
    goto z_bb_8;
    z_bb_8:
    zT_97 = ctx->resolved_types;
    zF_5209815D_resolvedTypeTableCl(zT_97);
    zT_100 = ctx->alloc;
    zT_99 = &zT_100->module;
    zF_F1B3F8C2_sandReset(zT_99);
    zT_102 = ctx;
    zF_2682C512_phase_EmissionClass(zT_102);
    zT_103 = ctx;
    zF_2268F8CE_phase_C89Emission(zT_103);
    zT_104 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_104);
    zT_106 = ctx->cli;
    zT_107 = zT_106.warnings_as_errors;
    if (zT_107) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_109 = ctx->cli;
    zT_108 = zT_109.warn_error;
    goto z_bb_11;
    z_bb_10:
    zT_108 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_108) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_112 = ctx->diag;
    zT_114 = zF_4AF2092E_diagnosticCollector(zT_112);
    zT_115 = 0;
    zT_111 = zT_114 > (unsigned int)zT_115;
    goto z_bb_14;
    z_bb_13:
    zT_111 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_111) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_117 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_117);
    zT_120 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_120));
    goto z_bb_16;
    z_bb_16:
    zT_122 = ctx->cli;
    zT_123 = zT_122.track_memory;
    if (zT_123) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_125 = ctx->alloc;
    zT_126 = zT_125->permanent;
    zT_127 = zT_126.peak;
    zT_130 = (unsigned int)(unsigned int)(zT_127 / (unsigned int)(1024));
    perm_kb = zT_130;
    zT_132 = ctx->alloc;
    zT_133 = zT_132->module;
    zT_134 = zT_133.peak;
    zT_137 = (unsigned int)(unsigned int)(zT_134 / (unsigned int)(1024));
    mod_kb = zT_137;
    zT_139 = ctx->alloc;
    zT_140 = zT_139->scratch;
    zT_141 = zT_140.peak;
    zT_144 = (unsigned int)(unsigned int)(zT_141 / (unsigned int)(1024));
    scr_kb = zT_144;
    zT_146 = zF_E5D0D49C_poolPeak();
    zT_149 = (unsigned int)(unsigned int)(zT_146 / (unsigned int)(1024));
    pool_kb = zT_149;
    zT_151 = ctx->typereg;
    zT_152 = zT_151->types_alloc;
    zT_153 = zT_152->peak;
    zT_156 = (unsigned int)(unsigned int)(zT_153 / (unsigned int)(1024));
    type_db_kb = zT_156;
    zT_159 = (unsigned int)(perm_kb + mod_kb) + scr_kb;
    total = zT_159;
    zT_161 = "track-memory: perm=";
    zT_163 = 19;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    msg1 = zT_162;
    zT_164 = msg1;
    zF_B5478454_measureMarkerWrite(zT_164);
    zT_165 = perm_kb;
    zF_266B1B8E_writeU32(zT_165);
    zT_167 = "K mod=";
    zT_169 = 6;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    msg2 = zT_168;
    zT_170 = msg2;
    zF_B5478454_measureMarkerWrite(zT_170);
    zT_171 = mod_kb;
    zF_266B1B8E_writeU32(zT_171);
    zT_173 = "K scr=";
    zT_175 = 6;
    zT_174.ptr = zT_173;
    zT_174.len = zT_175;
    msg3 = zT_174;
    zT_176 = msg3;
    zF_B5478454_measureMarkerWrite(zT_176);
    zT_177 = scr_kb;
    zF_266B1B8E_writeU32(zT_177);
    zT_179 = "K pool=";
    zT_181 = 7;
    zT_180.ptr = zT_179;
    zT_180.len = zT_181;
    msg3b = zT_180;
    zT_182 = msg3b;
    zF_B5478454_measureMarkerWrite(zT_182);
    zT_183 = pool_kb;
    zF_266B1B8E_writeU32(zT_183);
    zT_185 = "K type_db=";
    zT_187 = 10;
    zT_186.ptr = zT_185;
    zT_186.len = zT_187;
    msg3c = zT_186;
    zT_188 = msg3c;
    zF_B5478454_measureMarkerWrite(zT_188);
    zT_189 = type_db_kb;
    zF_266B1B8E_writeU32(zT_189);
    zT_191 = "K total=";
    zT_193 = 8;
    zT_192.ptr = zT_191;
    zT_192.len = zT_193;
    msg4 = zT_192;
    zT_194 = msg4;
    zF_B5478454_measureMarkerWrite(zT_194);
    zT_195 = total;
    zF_266B1B8E_writeU32(zT_195);
    zT_197 = "K\n";
    zT_199 = 2;
    zT_198.ptr = zT_197;
    zT_198.len = zT_199;
    msg5 = zT_198;
    zT_200 = msg5;
    zF_B5478454_measureMarkerWrite(zT_200);
    goto z_bb_18;
    z_bb_18:
    zT_201 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_201);
    return;
}

/* astStoreHasPrintRef */
unsigned char zF_A42B6E3C_astStoreHasPrintRef(zT_6B0A7D14_AstStore* store, unsigned int print_id) {
    unsigned int zT_3;
    zT_02497559_anon_271470 zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_8;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char zT_16;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24 = 0;
    unsigned int zT_28;
    unsigned int i;
    zT_22A7C88B_AstNode node;
    zT_3 = 0;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = store->nodes;
    zT_5 = zT_4.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = store;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, (unsigned int)((unsigned int)i));
    node = zT_11;
    zT_12 = node.kind;
    if ((unsigned char)(zT_12 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_28 = i + (unsigned int)(1);
    i = zT_28;
    goto z_bb_1;
    z_bb_5:
    zT_17 = node.kind;
    zT_16 = zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access);
    goto z_bb_7;
    z_bb_6:
    zT_16 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_16) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_21 = store;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, (unsigned int)((unsigned int)i));
    if ((unsigned char)(zT_24 == print_id)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    goto z_bb_4;
}

/* phase_ImportResolution */
void zF_E2BA93CE_phase_ImportResolut(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_C98AF326_CompilerCli zT_12;
    unsigned int zT_13;
    zT_4DB1475B_ModuleResolver* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_072B53A6_ModuleRegistry* zT_17;
    zT_C98AF326_CompilerCli zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    unsigned int zT_25;
    zT_846744CC_Arr_unsigned_char_5 zT_27;
    unsigned char* zT_29;
    int zT_31;
    unsigned char* zT_32;
    int zT_34 = 0;
    int zT_35;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char zT_46 = 0;
    zT_4DB1475B_ModuleResolver* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_072B53A6_ModuleRegistry* zT_49;
    zT_846744CC_Arr_unsigned_char_5 zT_52;
    zT_C98AF326_CompilerCli zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_C98AF326_CompilerCli zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_59;
    int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_C98AF326_CompilerCli zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_70;
    int zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_C98AF326_CompilerCli zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    zT_7532B98D_Opt_233 zT_77 = {0};
    unsigned char zT_78;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_84 = 0;
    zT_072B53A6_ModuleRegistry* zT_86;
    unsigned int zT_87;
    unsigned int zT_89 = 0;
    zT_47A5CDFB_ImportQueue* zT_90;
    unsigned int zT_91;
    zT_072B53A6_ModuleRegistry* zT_92;
    zT_072B53A6_ModuleRegistry* zT_94;
    zT_3E40CD83_Sand* zT_95;
    zT_3E40CD83_Sand* zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    zT_69057089_CompilerAlloc* zT_99;
    zT_69057089_CompilerAlloc* zT_101;
    zT_D3EB6303_StringInterner* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    unsigned int zT_111 = 0;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned char zT_115 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_4DB1475B_ModuleResolver* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_3E40CD83_Sand* zT_123;
    zT_072B53A6_ModuleRegistry* zT_124;
    zT_69057089_CompilerAlloc* zT_126;
    zT_BAEE192E_Opt_10 zT_128 = {0};
    unsigned char zT_129;
    zT_D3EB6303_StringInterner* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_134 = 0;
    zT_072B53A6_ModuleRegistry* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_3E40CD83_Sand* zT_138;
    zT_69057089_CompilerAlloc* zT_140;
    zT_BAEE192E_Opt_10 zT_142 = {0};
    zT_072B53A6_ModuleRegistry* zT_143;
    zT_3E40CD83_Sand* zT_144;
    zT_3E40CD83_Sand* zT_145;
    zT_6B0A7D14_AstStore* zT_146;
    zT_69057089_CompilerAlloc* zT_148;
    zT_69057089_CompilerAlloc* zT_150;
    zT_846744CC_Arr_unsigned_char_5 zT_154;
    unsigned int zT_156;
    zT_C98AF326_CompilerCli zT_157;
    unsigned char zT_158;
    zT_C98AF326_CompilerCli zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_163;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned char* zT_170;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned int zT_175;
    unsigned char zT_176;
    unsigned int zT_178;
    unsigned char zT_179;
    unsigned int zT_181;
    unsigned char zT_182;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_192;
    unsigned char zT_194;
    unsigned char* zT_197;
    unsigned char zT_198;
    unsigned int zT_200;
    unsigned int zT_202;
    zT_072B53A6_ModuleRegistry* zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    int zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    unsigned int si;
    zT_846744CC_Arr_unsigned_char_5 lib_buf;
    int lib_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_path;
    zT_846744CC_Arr_unsigned_char_5 root_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u root_path;
    zT_7532B98D_Opt_233 norm;
    unsigned int path_id;
    unsigned int mod_id;
    unsigned int print_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_name;
    zT_846744CC_Arr_unsigned_char_5 hash_spill_path;
    unsigned int hsp_len;
    unsigned int fmt_path_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hash_tmp_name;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u z_msg;
    zT_2 = "I\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    si = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_12 = ctx->cli;
    zT_13 = zT_12.include_count;
    if ((unsigned char)(si < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = ctx->module_reg;
    zT_15 = &zT_17->resolver;
    zT_19 = ctx->cli;
    zT_20 = zT_19.include_dirs;
    zT_21 = (unsigned int)si;
    zT_22 = zT_20[zT_21];
    zT_16 = zT_22;
    zF_B75A4515_moduleResolverAddSe(zT_15, zT_16);
    goto z_bb_4;
    z_bb_3:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_27[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        lib_buf[_i] = zT_27[_i];
        _i++;
    }
}
    zT_31 = 0;
    zT_32 = lib_buf + zT_31;
    zT_29 = zT_32;
    zT_34 = zF_BEB0BFA8_getDefaultLibPath(zT_29, (int)(512));
    lib_len = zT_34;
    zT_35 = 0;
    if ((unsigned char)(lib_len > zT_35)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_25 = si + (unsigned int)((unsigned int)zT_23);
    si = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_41 = 0;
    zT_42 = (unsigned char*)((unsigned char*)lib_buf) + zT_41;
    zT_43 = (unsigned int)((unsigned int)lib_len) - zT_41;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    lib_path = zT_44;
    zT_45 = lib_path;
    zT_46 = zF_8CC05F84_dirExists(zT_45);
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        root_buf[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = ctx->cli;
    zT_55 = zT_54.input_file;
    root_path = zT_55;
    zT_56 = ctx->cli;
    zT_57 = zT_56.input_file;
    zT_59 = zT_57.len;
    zT_60 = 512;
    if ((unsigned char)(zT_59 <= (unsigned int)zT_60)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_49 = ctx->module_reg;
    zT_47 = &zT_49->resolver;
    zT_48 = lib_path;
    zF_B75A4515_moduleResolverAddSe(zT_47, zT_48);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_67 = ctx->cli;
    zT_68 = zT_67.input_file;
    zT_70 = zT_68.len;
    zT_71 = 0;
    zT_72 = (unsigned char*)((unsigned char*)root_buf) + zT_71;
    zT_73 = zT_70 - zT_71;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_63 = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.input_file;
    zT_64 = zT_76;
    zT_77 = zF_36F0DB6B_normalizePath(zT_63, zT_64);
    norm = zT_77;
    zT_78 = norm.has_value;
    if (zT_78) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_81 = ctx->interner;
    zT_82 = root_path;
    zT_84 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    path_id = zT_84;
    zT_86 = ctx->module_reg;
    zT_87 = path_id;
    zT_89 = zF_E4DCE20D_moduleRegistryAddMo(zT_86, zT_87);
    mod_id = zT_89;
    zT_92 = ctx->module_reg;
    zT_90 = &zT_92->import_queue;
    zT_91 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_90, zT_91);
    zT_94 = ctx->module_reg;
    zT_99 = ctx->alloc;
    zT_95 = &zT_99->module;
    zT_101 = ctx->alloc;
    zT_96 = &zT_101->scratch;
    zT_97 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_94, zT_95, zT_96, zT_97);
    zT_105 = ctx->interner;
    zT_108 = "print";
    zT_110 = 5;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    zT_106 = zT_109;
    zT_111 = zF_50C274AF_stringInternerInter(zT_105, zT_106);
    print_name_id = zT_111;
    zT_112 = ctx->store;
    zT_113 = print_name_id;
    zT_115 = zF_A42B6E3C_astStoreHasPrintRef(zT_112, zT_113);
    if (zT_115) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    n = norm.value;
    root_path = n;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_117 = "std_fmt.zig";
    zT_119 = 11;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    fmt_name = zT_118;
    zT_124 = ctx->module_reg;
    zT_120 = &zT_124->resolver;
    zT_121 = root_path;
    zT_122 = fmt_name;
    zT_126 = ctx->alloc;
    zT_123 = &zT_126->scratch;
    zT_128 = zF_6F148E15_moduleResolverResol(zT_120, zT_121, zT_122, zT_123);
    zT_129 = zT_128.has_value;
    if (zT_129) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_154[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hash_spill_path[_i] = zT_154[_i];
        _i++;
    }
}
    zT_156 = 0;
    hsp_len = zT_156;
    zT_157 = ctx->cli;
    zT_158 = zT_157.output_dir_set;
    if (zT_158) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    zT_131 = ctx->interner;
    zT_132 = fmt_name;
    zT_134 = zF_50C274AF_stringInternerInter(zT_131, zT_132);
    fmt_path_id = zT_134;
    zT_135 = ctx->module_reg;
    zT_136 = fmt_path_id;
    zT_137 = mod_id;
    zT_140 = ctx->alloc;
    zT_138 = &zT_140->scratch;
    zT_142 = zF_620E3E3B_moduleRegistryResol(zT_135, zT_136, zT_137, zT_138);
    (void)zT_142;
    zT_143 = ctx->module_reg;
    zT_148 = ctx->alloc;
    zT_144 = &zT_148->module;
    zT_150 = ctx->alloc;
    zT_145 = &zT_150->scratch;
    zT_146 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_143, zT_144, zT_145, zT_146);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_160 = ctx->cli;
    zT_161 = zT_160.output_dir;
    od = zT_161;
    zT_163 = 0;
    oi = zT_163;
    goto z_bb_20;
    z_bb_18:
    zT_186 = ".zig1_hash.tmp";
    zT_188 = 14;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    hash_tmp_name = zT_187;
    zT_190 = 0;
    hi = zT_190;
    goto z_bb_27;
    z_bb_19:
    zT_179 = 46;
    hash_spill_path[hsp_len] = zT_179;
    zT_181 = hsp_len + (unsigned int)(1);
    hsp_len = zT_181;
    zT_182 = 47;
    hash_spill_path[hsp_len] = zT_182;
    zT_184 = hsp_len + (unsigned int)(1);
    hsp_len = zT_184;
    goto z_bb_18;
    z_bb_20:
    zT_165 = od.len;
    if ((unsigned char)(oi < zT_165)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_170 = od.ptr;
    zT_171 = zT_170[oi];
    hash_spill_path[hsp_len] = zT_171;
    zT_173 = hsp_len + (unsigned int)(1);
    hsp_len = zT_173;
    goto z_bb_23;
    z_bb_22:
    zT_176 = 47;
    hash_spill_path[hsp_len] = zT_176;
    zT_178 = hsp_len + (unsigned int)(1);
    hsp_len = zT_178;
    goto z_bb_18;
    z_bb_23:
    zT_175 = oi + (unsigned int)(1);
    oi = zT_175;
    goto z_bb_20;
    z_bb_24:
    zT_167 = hsp_len < (unsigned int)(511);
    goto z_bb_26;
    z_bb_25:
    zT_167 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_167) goto z_bb_21; else goto z_bb_22;
    z_bb_27:
    zT_192 = hash_tmp_name.len;
    if ((unsigned char)(hi < zT_192)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_197 = hash_tmp_name.ptr;
    zT_198 = zT_197[hi];
    hash_spill_path[hsp_len] = zT_198;
    zT_200 = hsp_len + (unsigned int)(1);
    hsp_len = zT_200;
    goto z_bb_30;
    z_bb_29:
    zT_203 = ctx->module_reg;
    zT_208 = 0;
    zT_209 = (unsigned char*)((unsigned char*)hash_spill_path) + zT_208;
    zT_210 = hsp_len - zT_208;
    zT_211.ptr = zT_209;
    zT_211.len = zT_210;
    zT_204 = zT_211;
    zF_8767909B_moduleRegistrySpill(zT_203, zT_204);
    zT_213 = "Z\n";
    zT_215 = 2;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    z_msg = zT_214;
    zT_216 = z_msg;
    zF_48AC7B3A_markerWrite(zT_216);
    return;
    z_bb_30:
    zT_202 = hi + (unsigned int)(1);
    hi = zT_202;
    goto z_bb_27;
    z_bb_31:
    zT_194 = hsp_len < (unsigned int)(511);
    goto z_bb_33;
    z_bb_32:
    zT_194 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_194) goto z_bb_28; else goto z_bb_29;
}

/* phase_SymbolRegistration */
void zF_945DEA54_phase_SymbolRegistr(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_11;
    zT_4D61441E_DepGraph zT_13 = {0};
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_072B53A6_ModuleRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_4D61441E_DepGraph* zT_29;
    zT_6E8D187B_ModuleEntry* zT_35;
    zT_6E8D187B_ModuleEntry zT_36;
    int zT_40;
    unsigned int zT_42;
    zT_072B53A6_ModuleRegistry* zT_44;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_46 = {0};
    unsigned int zT_48;
    unsigned char zT_51;
    zT_6E8D187B_ModuleEntry* zT_52;
    int zT_53;
    zT_6E8D187B_ModuleEntry zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    zT_6E8D187B_ModuleEntry* zT_62;
    int zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    zT_22A7C88B_AstNode zT_66 = {0};
    zT_8143F551_AstKind zT_67;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_6E8D187B_ModuleEntry* zT_75;
    int zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_79 = 0;
    unsigned int zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_97;
    int zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_102 = 0;
    zT_22A7C88B_AstNode zT_103 = {0};
    zT_8143F551_AstKind zT_105;
    unsigned int zT_106;
    zT_4028D896_Arr_unsigned_char_2 zT_108;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    int zT_114;
    unsigned char* zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118 = 0;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned char* zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_136;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_DDCD424B_Slice_zT_6E8D187B_M smods;
    zT_22A7C88B_AstNode sr;
    unsigned int sdl_n;
    unsigned int sdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl;
    zT_22A7C88B_AstNode sd;
    unsigned int sk;
    zT_4028D896_Arr_unsigned_char_2 sb;
    unsigned int slen;
    unsigned int sst;
    zT_8F083A69_Slice_zT_0B42B2F8_u ssp;
    zT_8F083A69_Slice_zT_0B42B2F8_u sn;
    zT_2 = "S\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->alloc;
    zT_10 = &zT_11->scratch;
    zT_13 = zF_7F194604_depGraphInit(zT_10);
    dep_graph = zT_13;
    zT_15 = ctx->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_22 = mods.len;
    if ((unsigned char)(mi < zT_22)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_24 = ctx->module_reg;
    zT_25 = ctx->symbol_reg;
    zT_26 = ctx->typereg;
    zT_27 = ctx->store;
    zT_35 = mods.ptr;
    zT_36 = zT_35[mi];
    zT_28 = zT_36.id;
    zT_29 = &dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_24, zT_25, zT_26, zT_27, zT_28, zT_29, (unsigned char)(1));
    goto z_bb_4;
    z_bb_3:
    zT_44 = ctx->module_reg;
    zT_46 = zF_3452C137_moduleRegistryGetMo(zT_44);
    smods = zT_46;
    zT_48 = smods.len;
    if ((unsigned char)(zT_48 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_40 = 1;
    zT_42 = mi + (unsigned int)((unsigned int)zT_40);
    mi = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_52 = smods.ptr;
    zT_53 = 0;
    zT_54 = zT_52[zT_53];
    zT_55 = zT_54.ast_root;
    zT_51 = zT_55 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_51 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_51) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_59 = ctx->store;
    zT_62 = smods.ptr;
    zT_63 = 0;
    zT_64 = zT_62[zT_63];
    zT_60 = zT_64.ast_root;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_59, zT_60);
    sr = zT_66;
    zT_67 = sr.kind;
    if ((unsigned char)(zT_67 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_72 = ctx->store;
    zT_75 = smods.ptr;
    zT_76 = 0;
    zT_77 = zT_75[zT_76];
    zT_73 = zT_77.ast_root;
    zT_79 = zF_152E19CB_astStoreNodeExtraCh(zT_72, zT_73);
    sdl_n = zT_79;
    zT_81 = 0;
    sdi = zT_81;
    zT_83 = "S0";
    zT_85 = 2;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    sl = zT_84;
    zT_86 = sl;
    zF_48AC7B3A_markerWrite(zT_86);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(sdi < (unsigned int)((unsigned int)sdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_90 = ctx->store;
    zT_93 = ctx->store;
    zT_97 = smods.ptr;
    zT_98 = 0;
    zT_99 = zT_97[zT_98];
    zT_94 = zT_99.ast_root;
    zT_102 = zF_B10B1BC1_astStoreNodeExtraCh(zT_93, zT_94, (unsigned int)((unsigned int)sdi));
    zT_91 = zT_102;
    zT_103 = zF_FCDD1D35_astStoreNodeAt(zT_90, zT_91);
    sd = zT_103;
    zT_105 = sd.kind;
    zT_106 = (unsigned int)zT_105;
    sk = zT_106;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_108[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sb[_i] = zT_108[_i];
        _i++;
    }
}
    zT_110 = sk;
    zT_114 = 0;
    zT_115 = (unsigned char*)((unsigned char*)sb) + zT_114;
    zT_116 = (unsigned int)(20) - zT_114;
    zT_117.ptr = zT_115;
    zT_117.len = zT_116;
    zT_111 = zT_117;
    zT_118 = zF_A7504564_itoa(zT_110, zT_111);
    slen = zT_118;
    zT_122 = (unsigned int)(19) - (unsigned int)((unsigned int)slen);
    sst = zT_122;
    zT_127 = (unsigned char*)((unsigned char*)sb) + sst;
    zT_128 = (unsigned int)(19) - sst;
    zT_129.ptr = zT_127;
    zT_129.len = zT_128;
    zT_123 = zT_129;
    zF_48AC7B3A_markerWrite(zT_123);
    zT_131 = " ";
    zT_133 = 1;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    ssp = zT_132;
    zT_134 = ssp;
    zF_48AC7B3A_markerWrite(zT_134);
    goto z_bb_15;
    z_bb_14:
    zT_138 = "\n";
    zT_140 = 1;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    sn = zT_139;
    zT_141 = sn;
    zF_48AC7B3A_markerWrite(zT_141);
    goto z_bb_11;
    z_bb_15:
    zT_136 = sdi + (unsigned int)(1);
    sdi = zT_136;
    goto z_bb_12;
}

/* phase_TypeResolution */
void zF_D3497187_phase_TypeResolutio(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_02497559_anon_271470 zT_10;
    zT_3E40CD83_Sand* zT_12;
    zT_69057089_CompilerAlloc* zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_69057089_CompilerAlloc* zT_17;
    zT_4D61441E_DepGraph zT_19 = {0};
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_3D7259E2_SymbolRegistry* zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_4D61441E_DepGraph* zT_35;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    int zT_46;
    unsigned int zT_48;
    zT_3D7259E2_SymbolRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_D3EB6303_StringInterner* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    zT_3E40CD83_Sand* zT_53;
    zT_69057089_CompilerAlloc* zT_58;
    zT_6B0A7D14_AstStore* zT_60;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_3D7259E2_SymbolRegistry* zT_62;
    zT_D3EB6303_StringInterner* zT_63;
    zT_8EED1867_ResolvedTypeTable* zT_64;
    zT_072B53A6_ModuleRegistry* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_69057089_CompilerAlloc* zT_75;
    zT_338B7C76_TypeRegistry* zT_78;
    zT_F85C5DED_DiagnosticCollector* zT_79;
    zT_3E40CD83_Sand* zT_80;
    zT_69057089_CompilerAlloc* zT_83;
    zT_C890C8CB_TypeResolver zT_85 = {0};
    zT_C890C8CB_TypeResolver* zT_86;
    zT_C890C8CB_TypeResolver* zT_88;
    zT_4D61441E_DepGraph* zT_89;
    zT_C890C8CB_TypeResolver* zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_3D7259E2_SymbolRegistry* zT_96;
    zT_D3EB6303_StringInterner* zT_97;
    zT_072B53A6_ModuleRegistry* zT_98;
    zT_F85C5DED_DiagnosticCollector* zT_99;
    zT_C890C8CB_TypeResolver* zT_106;
    zT_786E6CF2_EmissionClassificat* zT_107;
    zT_3E40CD83_Sand* zT_108;
    zT_69057089_CompilerAlloc* zT_111;
    unsigned int zT_114;
    unsigned char zT_117;
    zT_6E8D187B_ModuleEntry* zT_118;
    int zT_119;
    zT_6E8D187B_ModuleEntry zT_120;
    unsigned int zT_121;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    zT_6E8D187B_ModuleEntry* zT_128;
    int zT_129;
    zT_6E8D187B_ModuleEntry zT_130;
    zT_22A7C88B_AstNode zT_132 = {0};
    zT_8143F551_AstKind zT_133;
    zT_6B0A7D14_AstStore* zT_138;
    unsigned int zT_139;
    zT_6E8D187B_ModuleEntry* zT_141;
    int zT_142;
    zT_6E8D187B_ModuleEntry zT_143;
    unsigned int zT_145 = 0;
    unsigned int zT_147;
    unsigned char* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_159;
    unsigned int zT_160;
    zT_6E8D187B_ModuleEntry* zT_163;
    int zT_164;
    zT_6E8D187B_ModuleEntry zT_165;
    unsigned int zT_168 = 0;
    zT_22A7C88B_AstNode zT_169 = {0};
    zT_8143F551_AstKind zT_171;
    unsigned int zT_172;
    zT_4028D896_Arr_unsigned_char_2 zT_174;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    int zT_180;
    unsigned char* zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184 = 0;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned char* zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned char* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_202;
    unsigned char* zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_C890C8CB_TypeResolver tr;
    zT_22A7C88B_AstNode tr2;
    unsigned int tdl_n;
    unsigned int tdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tl;
    zT_22A7C88B_AstNode td;
    unsigned int tk;
    zT_4028D896_Arr_unsigned_char_2 tb;
    unsigned int tlen;
    unsigned int tst;
    zT_8F083A69_Slice_zT_0B42B2F8_u tsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tn;
    zT_2 = "T\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->resolved_types;
    zT_9 = ctx->store;
    zT_10 = zT_9->nodes;
    zT_7 = zT_10.len;
    zF_75224871_resolvedTypeTableRe(zT_6, zT_7);
    zT_13 = ctx->alloc;
    zT_12 = &zT_13->scratch;
    zF_F1B3F8C2_sandReset(zT_12);
    zT_17 = ctx->alloc;
    zT_16 = &zT_17->scratch;
    zT_19 = zF_7F194604_depGraphInit(zT_16);
    dep_graph = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    mi = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_28 = mods.len;
    if ((unsigned char)(mi < zT_28)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_30 = ctx->module_reg;
    zT_31 = ctx->symbol_reg;
    zT_32 = ctx->typereg;
    zT_33 = ctx->store;
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_34 = zT_42.id;
    zT_35 = &dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_30, zT_31, zT_32, zT_33, zT_34, zT_35, (unsigned char)(0));
    goto z_bb_4;
    z_bb_3:
    zT_49 = ctx->symbol_reg;
    zT_50 = ctx->typereg;
    zT_51 = ctx->interner;
    zT_52 = ctx->store;
    zT_58 = ctx->alloc;
    zT_53 = &zT_58->permanent;
    zF_EF7F7D3C_constAliasPrepass(zT_49, zT_50, zT_51, zT_52, zT_53);
    zT_60 = ctx->store;
    zT_61 = ctx->typereg;
    zT_62 = ctx->symbol_reg;
    zT_63 = ctx->interner;
    zT_64 = ctx->resolved_types;
    zT_65 = ctx->module_reg;
    zT_66 = ctx->diag;
    zT_75 = ctx->alloc;
    zT_67 = &zT_75->permanent;
    zF_373A7BEF_typeResolverResolve(zT_60, zT_61, zT_62, zT_63, zT_64, zT_65, zT_66, zT_67);
    zT_78 = ctx->typereg;
    zT_79 = ctx->diag;
    zT_83 = ctx->alloc;
    zT_80 = &zT_83->scratch;
    zT_85 = zF_5BFAC855_typeResolverInit(zT_78, zT_79, zT_80);
    tr = zT_85;
    zT_86 = &tr;
    zF_D5C4530C_typeResolverBuildDe(zT_86);
    zT_88 = &tr;
    zT_89 = &dep_graph;
    zF_33272F41_typeResolverBuild(zT_88, zT_89);
    zT_92 = &tr;
    zF_30BE7185_typeResolverResolve(zT_92);
    zT_94 = ctx->store;
    zT_95 = ctx->typereg;
    zT_96 = ctx->symbol_reg;
    zT_97 = ctx->interner;
    zT_98 = ctx->module_reg;
    zT_99 = ctx->diag;
    zF_153D24FD_enumReevaluateAll(zT_94, zT_95, zT_96, zT_97, zT_98, zT_99);
    zT_106 = &tr;
    zT_107 = &ctx->emission_classif;
    zT_111 = ctx->alloc;
    zT_108 = &zT_111->permanent;
    zF_ACC002C8_classifyTypeEmissio(zT_106, zT_107, zT_108);
    zT_114 = mods.len;
    if ((unsigned char)(zT_114 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_46 = 1;
    zT_48 = mi + (unsigned int)((unsigned int)zT_46);
    mi = zT_48;
    goto z_bb_1;
    z_bb_5:
    zT_118 = mods.ptr;
    zT_119 = 0;
    zT_120 = zT_118[zT_119];
    zT_121 = zT_120.ast_root;
    zT_117 = zT_121 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_117 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_117) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_125 = ctx->store;
    zT_128 = mods.ptr;
    zT_129 = 0;
    zT_130 = zT_128[zT_129];
    zT_126 = zT_130.ast_root;
    zT_132 = zF_FCDD1D35_astStoreNodeAt(zT_125, zT_126);
    tr2 = zT_132;
    zT_133 = tr2.kind;
    if ((unsigned char)(zT_133 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_138 = ctx->store;
    zT_141 = mods.ptr;
    zT_142 = 0;
    zT_143 = zT_141[zT_142];
    zT_139 = zT_143.ast_root;
    zT_145 = zF_152E19CB_astStoreNodeExtraCh(zT_138, zT_139);
    tdl_n = zT_145;
    zT_147 = 0;
    tdi = zT_147;
    zT_149 = "T0";
    zT_151 = 2;
    zT_150.ptr = zT_149;
    zT_150.len = zT_151;
    tl = zT_150;
    zT_152 = tl;
    zF_48AC7B3A_markerWrite(zT_152);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(tdi < (unsigned int)((unsigned int)tdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_156 = ctx->store;
    zT_159 = ctx->store;
    zT_163 = mods.ptr;
    zT_164 = 0;
    zT_165 = zT_163[zT_164];
    zT_160 = zT_165.ast_root;
    zT_168 = zF_B10B1BC1_astStoreNodeExtraCh(zT_159, zT_160, (unsigned int)((unsigned int)tdi));
    zT_157 = zT_168;
    zT_169 = zF_FCDD1D35_astStoreNodeAt(zT_156, zT_157);
    td = zT_169;
    zT_171 = td.kind;
    zT_172 = (unsigned int)zT_171;
    tk = zT_172;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_174[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        tb[_i] = zT_174[_i];
        _i++;
    }
}
    zT_176 = tk;
    zT_180 = 0;
    zT_181 = (unsigned char*)((unsigned char*)tb) + zT_180;
    zT_182 = (unsigned int)(20) - zT_180;
    zT_183.ptr = zT_181;
    zT_183.len = zT_182;
    zT_177 = zT_183;
    zT_184 = zF_A7504564_itoa(zT_176, zT_177);
    tlen = zT_184;
    zT_188 = (unsigned int)(19) - (unsigned int)((unsigned int)tlen);
    tst = zT_188;
    zT_193 = (unsigned char*)((unsigned char*)tb) + tst;
    zT_194 = (unsigned int)(19) - tst;
    zT_195.ptr = zT_193;
    zT_195.len = zT_194;
    zT_189 = zT_195;
    zF_48AC7B3A_markerWrite(zT_189);
    zT_197 = " ";
    zT_199 = 1;
    zT_198.ptr = zT_197;
    zT_198.len = zT_199;
    tsp = zT_198;
    zT_200 = tsp;
    zF_48AC7B3A_markerWrite(zT_200);
    goto z_bb_15;
    z_bb_14:
    zT_204 = "\n";
    zT_206 = 1;
    zT_205.ptr = zT_204;
    zT_205.len = zT_206;
    tn = zT_205;
    zT_207 = tn;
    zF_48AC7B3A_markerWrite(zT_207);
    goto z_bb_11;
    z_bb_15:
    zT_202 = tdi + (unsigned int)(1);
    tdi = zT_202;
    goto z_bb_12;
}

/* phase_FrontResolution */
void zF_F862154A_phase_FrontResoluti(zT_5AB29387_CompilerContext* ctx) {
    zT_6DCFC8DB_FrontResCtx zT_2;
    zT_6B0A7D14_AstStore* zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_3E40CD83_Sand* zT_11;
    zT_66E7D2EF_CoercionTable* zT_12;
    zT_21D3708C_U32ToU32Map* zT_13;
    zT_21D3708C_U32ToU32Map* zT_14;
    zT_21D3708C_U32ToU32Map* zT_15;
    zT_21D3708C_U32ToU32Map* zT_16;
    zT_21D3708C_U32ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_19;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_3 = ctx->store;
    zT_2.store = zT_3;
    zT_4 = ctx->typereg;
    zT_2.typereg = zT_4;
    zT_5 = ctx->symbol_reg;
    zT_2.symbol_reg = zT_5;
    zT_6 = ctx->resolved_types;
    zT_2.resolved_types = zT_6;
    zT_7 = ctx->module_reg;
    zT_2.module_reg = zT_7;
    zT_8 = ctx->interner;
    zT_2.interner = zT_8;
    zT_9 = ctx->diag;
    zT_2.diag = zT_9;
    zT_10 = ctx->alloc;
    zT_11 = &zT_10->scratch;
    zT_2.scratch = zT_11;
    zT_12 = ctx->coercion_table;
    zT_2.coercion_table = zT_12;
    zT_13 = &ctx->enum_value_table;
    zT_2.enum_value_table = zT_13;
    zT_14 = &ctx->tuple_index_table;
    zT_2.tuple_index_table = zT_14;
    zT_15 = &ctx->error_code_registry;
    zT_2.error_code_registry = zT_15;
    zT_16 = &ctx->call_arg_types;
    zT_2.call_arg_types = zT_16;
    zT_17 = &ctx->call_param_map;
    zT_2.call_param_map = zT_17;
    zT_18 = &ctx->suspending_fns;
    zT_2.suspending_fns = zT_18;
    frc = zT_2;
    zT_19 = &frc;
    zF_8A0E7747_frontResolveModuleI(zT_19);
    return;
}

/* phase_ComptimeEvaluation */
void zF_9609BF31_phase_ComptimeEvalu(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15 = {0};
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_7132B341_Opt_237 zT_19;
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    zT_02497559_anon_271470 zT_28;
    unsigned int zT_29;
    unsigned int zT_32;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_39;
    zT_6E8D187B_ModuleEntry* zT_42;
    zT_6E8D187B_ModuleEntry zT_43;
    unsigned int zT_44;
    unsigned char zT_49;
    zT_6E8D187B_ModuleEntry* zT_51;
    zT_6E8D187B_ModuleEntry zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_58;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_8143F551_AstKind zT_63;
    zT_DA663F79_ComptimeEval* zT_68;
    zT_EB3A2F14_Opt_209 zT_72 = {0};
    unsigned char zT_73;
    zT_77F6F59C_ComptimeFoldTable* zT_75;
    zT_89B1DDDA_ComptimeVal zT_77;
    zT_8143F551_AstKind zT_80;
    unsigned char zT_84;
    unsigned int zT_85;
    int zT_86;
    unsigned char zT_88;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_100;
    unsigned int zT_101;
    unsigned char zT_104;
    unsigned char zT_107;
    unsigned char zT_110;
    zT_DA663F79_ComptimeEval* zT_114;
    unsigned int zT_115;
    zT_EB3A2F14_Opt_209 zT_118 = {0};
    unsigned char zT_119;
    zT_77F6F59C_ComptimeFoldTable* zT_121;
    unsigned int zT_122;
    zT_89B1DDDA_ComptimeVal zT_123;
    zT_8143F551_AstKind zT_126;
    unsigned char zT_130;
    zT_8143F551_AstKind zT_131;
    zT_6B0A7D14_AstStore* zT_135;
    unsigned int zT_139 = 0;
    zT_DA663F79_ComptimeEval* zT_143;
    unsigned int zT_144;
    zT_EB3A2F14_Opt_209 zT_147 = {0};
    unsigned char zT_148;
    unsigned char zT_150;
    zT_77F6F59C_ComptimeFoldTable* zT_153;
    unsigned int zT_154;
    zT_89B1DDDA_ComptimeVal zT_155;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_m;
    zT_DA663F79_ComptimeEval ce;
    zT_DDCD424B_Slice_zT_6E8D187B_M p7_mods;
    unsigned int ni;
    unsigned int p7_best_root;
    unsigned int p7_best_id;
    unsigned int p7_si;
    unsigned int p7_r;
    zT_22A7C88B_AstNode node;
    zT_EB3A2F14_Opt_209 val;
    zT_89B1DDDA_ComptimeVal v;
    zT_22A7C88B_AstNode init_n;
    unsigned int ik;
    zT_EB3A2F14_Opt_209 val2;
    zT_89B1DDDA_ComptimeVal v2;
    zT_EB3A2F14_Opt_209 cval;
    zT_89B1DDDA_ComptimeVal cv;
    zT_2 = "CE\n";
    zT_4 = 3;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    pc_m = zT_3;
    zT_5 = pc_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ce.diag = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    p7_mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    ni = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_27 = ctx->store;
    zT_28 = zT_27->nodes;
    zT_29 = zT_28.len;
    if ((unsigned char)(ni < zT_29)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_32 = 4294967295u;
    p7_best_root = zT_32;
    p7_best_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    p7_si = zT_37;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    zT_159 = ni + (unsigned int)(1);
    ni = zT_159;
    goto z_bb_1;
    z_bb_5:
    zT_39 = p7_mods.len;
    if ((unsigned char)(p7_si < zT_39)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_42 = p7_mods.ptr;
    zT_43 = zT_42[p7_si];
    zT_44 = zT_43.ast_root;
    p7_r = zT_44;
    if ((unsigned char)(p7_r == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    ce.module_id = p7_best_id;
    zT_58 = ctx->store;
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_58, (unsigned int)((unsigned int)ni));
    node = zT_62;
    zT_63 = node.kind;
    if ((unsigned char)(zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_16; else goto z_bb_18;
    z_bb_8:
    zT_54 = 1;
    zT_56 = p7_si + (unsigned int)((unsigned int)zT_54);
    p7_si = zT_56;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    if ((unsigned char)((unsigned int)((unsigned int)p7_r) >= ni)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_49 = p7_r < p7_best_root;
    goto z_bb_13;
    z_bb_12:
    zT_49 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_49) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    p7_best_root = p7_r;
    zT_51 = p7_mods.ptr;
    zT_52 = zT_51[p7_si];
    zT_53 = zT_52.id;
    p7_best_id = zT_53;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_68 = &ce;
    zT_72 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_68, (unsigned int)((unsigned int)ni));
    val = zT_72;
    zT_73 = val.has_value;
    if (zT_73) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_4;
    z_bb_18:
    zT_80 = node.kind;
    if ((unsigned char)(zT_80 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    v = val.value;
    zT_75 = &ctx->comptime_folds;
    zT_77 = v;
    zF_376429F5_comptimeFoldTablePu(zT_75, (unsigned int)((unsigned int)ni), zT_77);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_85 = node.child_1;
    zT_86 = 0;
    zT_84 = zT_85 != (unsigned int)zT_86;
    goto z_bb_23;
    z_bb_22:
    zT_84 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_84) goto z_bb_24; else goto z_bb_26;
    z_bb_24:
    zT_88 = node.flags;
    if ((unsigned char)((unsigned char)(zT_88 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    goto z_bb_17;
    z_bb_26:
    zT_126 = node.kind;
    if ((unsigned char)(zT_126 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_43; else goto z_bb_42;
    z_bb_27:
    zT_94 = ctx->store;
    zT_95 = node.child_1;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    init_n = zT_98;
    zT_100 = init_n.kind;
    zT_101 = (unsigned int)zT_100;
    ik = zT_101;
    if ((unsigned char)(ik >= (unsigned int)(33))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_104 = ik <= (unsigned int)(42);
    goto z_bb_31;
    z_bb_30:
    zT_104 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_104) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_107 = ik == (unsigned int)(62);
    goto z_bb_34;
    z_bb_33:
    zT_107 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_107) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_110 = ik == (unsigned int)(64);
    goto z_bb_37;
    z_bb_36:
    zT_110 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_110) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_114 = &ce;
    zT_115 = node.child_1;
    zT_118 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_114, zT_115);
    val2 = zT_118;
    zT_119 = val2.has_value;
    if (zT_119) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_28;
    z_bb_40:
    v2 = val2.value;
    zT_121 = &ctx->comptime_folds;
    zT_122 = node.child_1;
    zT_123 = v2;
    zF_376429F5_comptimeFoldTablePu(zT_121, zT_122, zT_123);
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    zT_131 = node.kind;
    zT_130 = zT_131 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt);
    goto z_bb_44;
    z_bb_43:
    zT_130 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_130) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_135 = ctx->store;
    zT_139 = zF_8BA26B9E_astStoreNodePayload(zT_135, (unsigned int)((unsigned int)ni));
    if ((unsigned char)(zT_139 == (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_25;
    z_bb_47:
    zT_143 = &ce;
    zT_144 = node.child_0;
    zT_147 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_143, zT_144);
    cval = zT_147;
    zT_148 = cval.has_value;
    if (zT_148) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    cv = cval.value;
    zT_150 = cv.kind;
    if ((unsigned char)(zT_150 == (unsigned char)(1))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_153 = &ctx->comptime_folds;
    zT_154 = node.child_0;
    zT_155 = cv;
    zF_376429F5_comptimeFoldTablePu(zT_153, zT_154, zT_155);
    goto z_bb_52;
    z_bb_52:
    goto z_bb_50;
}

/* phase_SemanticAnalysis */
void zF_0666ED4F_phase_SemanticAnaly(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_6DCFC8DB_FrontResCtx zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_D3EB6303_StringInterner* zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    zT_69057089_CompilerAlloc* zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_66E7D2EF_CoercionTable* zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    zT_21D3708C_U32ToU32Map* zT_22;
    zT_21D3708C_U32ToU32Map* zT_23;
    zT_21D3708C_U32ToU32Map* zT_24;
    zT_21D3708C_U32ToU32Map* zT_25;
    zT_A4CE86B7_U64ToU32Map* zT_26;
    zT_072B53A6_ModuleRegistry* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_30 = {0};
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_69057089_CompilerAlloc* zT_38;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    unsigned int zT_43;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_60 = 0;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_6E8D187B_ModuleEntry* zT_72;
    zT_6E8D187B_ModuleEntry zT_73;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_76;
    zT_8EED1867_ResolvedTypeTable* zT_77;
    zT_F85C5DED_DiagnosticCollector* zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_3D7259E2_SymbolRegistry* zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_66E7D2EF_CoercionTable* zT_84;
    zT_21D3708C_U32ToU32Map* zT_85;
    zT_21D3708C_U32ToU32Map* zT_86;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_D3EB6303_StringInterner* zT_88;
    zT_21D3708C_U32ToU32Map* zT_89;
    zT_21D3708C_U32ToU32Map* zT_90;
    zT_072B53A6_ModuleRegistry* zT_91;
    zT_A4CE86B7_U64ToU32Map* zT_92;
    zT_69057089_CompilerAlloc* zT_93;
    zT_6E8D187B_ModuleEntry* zT_100;
    zT_6E8D187B_ModuleEntry zT_101;
    zT_38C12417_SemanticAnalyzer zT_112 = {0};
    zT_77F6F59C_ComptimeFoldTable* zT_113;
    zT_F2A81909_Opt_321 zT_114;
    int zT_116;
    unsigned int zT_117;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_126 = 0;
    zT_6B0A7D14_AstStore* zT_128;
    unsigned int zT_129;
    zT_22A7C88B_AstNode zT_131 = {0};
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8143F551_AstKind zT_137;
    unsigned int zT_141;
    int zT_142;
    zT_6DCFC8DB_FrontResCtx* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_148;
    zT_6E8D187B_ModuleEntry* zT_150;
    zT_6E8D187B_ModuleEntry zT_151;
    zT_6E8D187B_ModuleEntry* zT_155;
    zT_6E8D187B_ModuleEntry zT_156;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    zT_38C12417_SemanticAnalyzer* zT_163;
    unsigned int zT_164;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    zT_8143F551_AstKind zT_171;
    unsigned char zT_175;
    unsigned int zT_176;
    zT_6B0A7D14_AstStore* zT_180;
    unsigned int zT_181;
    zT_22A7C88B_AstNode zT_184 = {0};
    zT_8143F551_AstKind zT_185;
    zT_38C12417_SemanticAnalyzer* zT_189;
    unsigned int zT_190;
    zT_8143F551_AstKind zT_192;
    unsigned char zT_196;
    unsigned char zT_197;
    zT_38C12417_SemanticAnalyzer* zT_202;
    unsigned int zT_203;
    zT_8143F551_AstKind zT_205;
    zT_38C12417_SemanticAnalyzer* zT_209;
    unsigned int zT_210;
    zT_8143F551_AstKind zT_212;
    zT_38C12417_SemanticAnalyzer* zT_216;
    unsigned int zT_217;
    int zT_219;
    unsigned int zT_221;
    int zT_222;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mz;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u ad;
    zT_8F083A69_Slice_zT_0B42B2F8_u dse_m;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa0;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa1;
    zT_22A7C88B_AstNode di_inn;
    zT_2 = "RS";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    rs = zT_3;
    zT_5 = rs;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->store;
    zT_10.store = zT_11;
    zT_12 = ctx->typereg;
    zT_10.typereg = zT_12;
    zT_13 = ctx->symbol_reg;
    zT_10.symbol_reg = zT_13;
    zT_14 = ctx->resolved_types;
    zT_10.resolved_types = zT_14;
    zT_15 = ctx->module_reg;
    zT_10.module_reg = zT_15;
    zT_16 = ctx->interner;
    zT_10.interner = zT_16;
    zT_17 = ctx->diag;
    zT_10.diag = zT_17;
    zT_18 = ctx->alloc;
    zT_19 = &zT_18->scratch;
    zT_10.scratch = zT_19;
    zT_20 = ctx->coercion_table;
    zT_10.coercion_table = zT_20;
    zT_21 = &ctx->enum_value_table;
    zT_10.enum_value_table = zT_21;
    zT_22 = &ctx->tuple_index_table;
    zT_10.tuple_index_table = zT_22;
    zT_23 = &ctx->error_code_registry;
    zT_10.error_code_registry = zT_23;
    zT_24 = &ctx->call_arg_types;
    zT_10.call_arg_types = zT_24;
    zT_25 = &ctx->call_param_map;
    zT_10.call_param_map = zT_25;
    zT_26 = &ctx->suspending_fns;
    zT_10.suspending_fns = zT_26;
    frc = zT_10;
    zT_28 = ctx->module_reg;
    zT_30 = zF_3452C137_moduleRegistryGetMo(zT_28);
    mods = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    mi = zT_33;
    goto z_bb_1;
    z_bb_1:
    zT_35 = mods.len;
    if ((unsigned char)(mi < zT_35)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_38 = ctx->alloc;
    zT_37 = &zT_38->scratch;
    zF_F1B3F8C2_sandReset(zT_37);
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_43 = zT_42.ast_root;
    ast_root = zT_43;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_222 = 1;
    zT_224 = mi + (unsigned int)((unsigned int)zT_222);
    mi = zT_224;
    goto z_bb_1;
    z_bb_5:
    zT_47 = "MZ";
    zT_49 = 2;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    mz = zT_48;
    zT_50 = mz;
    zF_48AC7B3A_markerWrite(zT_50);
    goto z_bb_4;
    z_bb_6:
    zT_52 = ctx->store;
    zT_53 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_52, zT_53);
    zT_57 = ctx->store;
    zT_58 = ast_root;
    zT_60 = zF_152E19CB_astStoreNodeExtraCh(zT_57, zT_58);
    decls_n = zT_60;
    zT_62 = "AD";
    zT_64 = 2;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    ad = zT_63;
    zT_65 = ad;
    zF_48AC7B3A_markerWrite(zT_65);
    zT_67 = "DSE\n";
    zT_69 = 4;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    dse_m = zT_68;
    zT_70 = dse_m;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_72 = mods.ptr;
    zT_73 = zT_72[mi];
    zT_74 = zT_73.source_file_id;
    src_fid = zT_74;
    zT_93 = ctx->alloc;
    zT_76 = &zT_93->scratch;
    zT_77 = ctx->resolved_types;
    zT_78 = ctx->diag;
    zT_79 = ctx->typereg;
    zT_80 = ctx->symbol_reg;
    zT_81 = ctx->store;
    zT_100 = mods.ptr;
    zT_101 = zT_100[mi];
    zT_82 = zT_101.id;
    zT_83 = src_fid;
    zT_84 = ctx->coercion_table;
    zT_85 = &ctx->enum_value_table;
    zT_86 = &ctx->tuple_index_table;
    zT_87 = &ctx->error_code_registry;
    zT_88 = ctx->interner;
    zT_89 = &ctx->call_arg_types;
    zT_90 = &ctx->call_param_map;
    zT_91 = ctx->module_reg;
    zT_92 = &ctx->suspending_fns;
    zT_112 = zF_84ADA681_semanticAnalyzerIni(zT_76, zT_77, zT_78, zT_79, zT_80, zT_81, zT_82, zT_83, zT_84, zT_85, zT_86, zT_87, zT_88, zT_89, zT_90, zT_91, zT_92);
    sa = zT_112;
    zT_113 = &ctx->comptime_folds;
    zT_114.has_value = 1;
    zT_114.value = zT_113;
    sa.comptime_folds = zT_114;
    zT_116 = 0;
    zT_117 = (unsigned int)zT_116;
    di = zT_117;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_121 = ctx->store;
    zT_122 = ast_root;
    zT_126 = zF_B10B1BC1_astStoreNodeExtraCh(zT_121, zT_122, (unsigned int)((unsigned int)di));
    decl_idx = zT_126;
    zT_128 = ctx->store;
    zT_129 = decl_idx;
    zT_131 = zF_FCDD1D35_astStoreNodeAt(zT_128, zT_129);
    decl = zT_131;
    zT_133 = "DN";
    zT_135 = 2;
    zT_134.ptr = zT_133;
    zT_134.len = zT_135;
    dn = zT_134;
    zT_136 = dn;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_137 = decl.kind;
    if ((unsigned char)(zT_137 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_219 = 1;
    zT_221 = di + (unsigned int)((unsigned int)zT_219);
    di = zT_221;
    goto z_bb_7;
    z_bb_11:
    zT_141 = decl.child_0;
    zT_142 = 0;
    if ((unsigned char)(zT_141 != (unsigned int)zT_142)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_171 = decl.kind;
    if ((unsigned char)(zT_171 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_144 = &frc;
    zT_150 = mods.ptr;
    zT_151 = zT_150[mi];
    zT_145 = zT_151.id;
    zT_146 = decl.child_0;
    zT_155 = mods.ptr;
    zT_156 = zT_155[mi];
    zT_148 = zT_156.source_file_id;
    zF_783226DA_resolveStmtTypes(zT_144, zT_145, zT_146, (unsigned int)(0), zT_148);
    goto z_bb_15;
    z_bb_15:
    zT_159 = "SA";
    zT_161 = 2;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    sa0 = zT_160;
    zT_162 = sa0;
    zF_48AC7B3A_markerWrite(zT_162);
    zT_163 = &sa;
    zT_164 = decl_idx;
    zF_406A2501_semanticAnalyzerRes(zT_163, zT_164);
    zT_167 = "sA";
    zT_169 = 2;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    sa1 = zT_168;
    zT_170 = sa1;
    zF_48AC7B3A_markerWrite(zT_170);
    goto z_bb_12;
    z_bb_16:
    zT_176 = decl.child_1;
    zT_175 = zT_176 != (unsigned int)(0);
    goto z_bb_18;
    z_bb_17:
    zT_175 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_175) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_180 = ctx->store;
    zT_181 = decl.child_1;
    zT_184 = zF_FCDD1D35_astStoreNodeAt(zT_180, zT_181);
    di_inn = zT_184;
    zT_185 = di_inn.kind;
    if ((unsigned char)(zT_185 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_212 = decl.kind;
    if ((unsigned char)(zT_212 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_31; else goto z_bb_32;
    z_bb_22:
    zT_189 = &sa;
    zT_190 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_189, zT_190);
    goto z_bb_23;
    z_bb_23:
    zT_192 = di_inn.kind;
    if ((unsigned char)(zT_192 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_197 = di_inn.flags;
    zT_196 = (unsigned char)(zT_197 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_196 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_196) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_202 = &sa;
    zT_203 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_202, zT_203);
    goto z_bb_28;
    z_bb_28:
    zT_205 = di_inn.kind;
    if ((unsigned char)(zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_209 = &sa;
    zT_210 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_209, zT_210);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_20;
    z_bb_31:
    zT_216 = &sa;
    zT_217 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_216, zT_217);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_20;
}

/* phase_StaticAnalyzers */
void zF_F3B55B42_phase_StaticAnalyze(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_C98AF326_CompilerCli zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    zT_C98AF326_CompilerCli zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    zT_C98AF326_CompilerCli zT_22;
    unsigned char zT_23;
    zT_072B53A6_ModuleRegistry* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29 = {0};
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_69057089_CompilerAlloc* zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_46;
    zT_060CD1EB_SymbolTable* zT_50 = 0;
    zT_7E2F335A_AnalyzerContext zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    zT_69057089_CompilerAlloc* zT_57;
    zT_3E40CD83_Sand* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_69057089_CompilerAlloc* zT_63;
    zT_3E40CD83_Sand* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_C98AF326_CompilerCli zT_67;
    unsigned char zT_68;
    unsigned char zT_69;
    int zT_70;
    int zT_72;
    unsigned char zT_74;
    zT_C98AF326_CompilerCli zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    int zT_78;
    int zT_80;
    unsigned char zT_82;
    zT_C98AF326_CompilerCli zT_83;
    unsigned char zT_84;
    unsigned char zT_85;
    int zT_86;
    int zT_88;
    unsigned char zT_90;
    zT_C98AF326_CompilerCli zT_91;
    unsigned char zT_92;
    unsigned char zT_93;
    int zT_94;
    int zT_96;
    unsigned char zT_98;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    zT_6E8D187B_ModuleEntry* zT_103;
    zT_6E8D187B_ModuleEntry zT_104;
    unsigned int zT_105;
    zT_7E2F335A_AnalyzerContext* zT_106;
    unsigned int zT_107;
    zT_227EDE07_SourceManager* zT_109;
    int zT_111;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_060CD1EB_SymbolTable* sym_table;
    zT_7E2F335A_AnalyzerContext ac;
    zT_2 = "A\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = ctx->alloc;
    zT_9 = &zT_10->scratch;
    zF_CB5A85E9_sandResetPeak(zT_9);
    zT_12 = ctx->cli;
    zT_13 = zT_12.no_null_check;
    if ((unsigned char)(zT_13 != (unsigned char)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_17 = ctx->cli;
    zT_18 = zT_17.no_lifetime_check;
    zT_16 = zT_18 != (unsigned char)(1);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = ctx->cli;
    zT_23 = zT_22.no_leak_check;
    zT_21 = zT_23 != (unsigned char)(1);
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = ctx->module_reg;
    zT_29 = zF_3452C137_moduleRegistryGetMo(zT_27);
    mods = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    mi = zT_32;
    goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    zT_34 = mods.len;
    if ((unsigned char)(mi < zT_34)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = ctx->alloc;
    zT_36 = &zT_37->scratch;
    zF_F1B3F8C2_sandReset(zT_36);
    zT_40 = mods.ptr;
    zT_41 = zT_40[mi];
    zT_42 = zT_41.ast_root;
    ast_root = zT_42;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_111 = 1;
    zT_113 = mi + (unsigned int)((unsigned int)zT_111);
    mi = zT_113;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_46 = ctx->symbol_reg;
    zT_50 = zF_9B36C202_symbolRegistryGetTa(zT_46, (unsigned int)((unsigned int)mi));
    sym_table = zT_50;
    zT_53 = ctx->store;
    zT_52.store = zT_53;
    zT_54 = ctx->typereg;
    zT_52.registry = zT_54;
    zT_55 = ctx->interner;
    zT_52.interner = zT_55;
    zT_56 = ctx->diag;
    zT_52.diag = zT_56;
    zT_52.symbols = sym_table;
    zT_57 = ctx->alloc;
    zT_58 = &zT_57->scratch;
    zT_52.alloc = zT_58;
    zT_59 = 0;
    zT_52.current_fn_name = zT_59;
    zT_60 = 0;
    zT_52.defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_60;
    zT_61 = 0;
    zT_52.defer_queue_len = zT_61;
    zT_62 = 0;
    zT_52.defer_queue_cap = zT_62;
    zT_63 = ctx->alloc;
    zT_64 = &zT_63->scratch;
    zT_52.defer_queue_alloc = zT_64;
    zT_65 = 0;
    zT_52.current_depth = zT_65;
    zT_66 = 0;
    zT_52.null_analysis_mode = zT_66;
    zT_67 = ctx->cli;
    zT_68 = zT_67.no_null_check;
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_70 = 1;
    zT_69 = (unsigned char)zT_70;
    goto z_bb_17;
    z_bb_16:
    zT_72 = 0;
    zT_69 = (unsigned char)zT_72;
    goto z_bb_17;
    z_bb_17:
    zT_74 = (unsigned char)zT_69;
    zT_52.skip_null_check = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.no_lifetime_check;
    if (zT_76) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_78 = 1;
    zT_77 = (unsigned char)zT_78;
    goto z_bb_20;
    z_bb_19:
    zT_80 = 0;
    zT_77 = (unsigned char)zT_80;
    goto z_bb_20;
    z_bb_20:
    zT_82 = (unsigned char)zT_77;
    zT_52.skip_lifetime_check = zT_82;
    zT_83 = ctx->cli;
    zT_84 = zT_83.no_leak_check;
    if (zT_84) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_86 = 1;
    zT_85 = (unsigned char)zT_86;
    goto z_bb_23;
    z_bb_22:
    zT_88 = 0;
    zT_85 = (unsigned char)zT_88;
    goto z_bb_23;
    z_bb_23:
    zT_90 = (unsigned char)zT_85;
    zT_52.skip_doublefree_check = zT_90;
    zT_91 = ctx->cli;
    zT_92 = zT_91.warn_all;
    if (zT_92) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_94 = 1;
    zT_93 = (unsigned char)zT_94;
    goto z_bb_26;
    z_bb_25:
    zT_96 = 0;
    zT_93 = (unsigned char)zT_96;
    goto z_bb_26;
    z_bb_26:
    zT_98 = (unsigned char)zT_93;
    zT_52.warn_all = zT_98;
    zT_99 = zF_43C99FB3_onNullStmt;
    zT_52.on_stmt_cb = zT_99;
    zT_100 = 0;
    zT_52.in_defer_exec = zT_100;
    zT_101 = 0;
    zT_52.lifetime_analysis_mode = zT_101;
    zT_102 = 0;
    zT_52.doublefree_analysis_mode = zT_102;
    zT_103 = mods.ptr;
    zT_104 = zT_103[mi];
    zT_105 = zT_104.source_file_id;
    zT_52.source_file_id = zT_105;
    ac = zT_52;
    zT_106 = &ac;
    zT_107 = ast_root;
    zF_F697813C_runAllAnalyzers(zT_106, zT_107);
    zT_109 = ctx->source_man;
    zF_196FDF3B_sourceManagerResetF(zT_109);
    goto z_bb_12;
}

/* phase_AsyncFrameSize */
void zF_9BC6214D_phase_AsyncFrameSiz(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_3D7259E2_SymbolRegistry* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_072B53A6_ModuleRegistry* zT_10;
    zT_338B7C76_TypeRegistry* zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_12;
    zT_A4CE86B7_U64ToU32Map* zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_A4CE86B7_U64ToU32Map* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_B687BB96_U32ArrayList* zT_19;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_69057089_CompilerAlloc* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_2 = "AFS\n";
    zT_4 = 4;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_22 = ctx->alloc;
    zT_6 = &zT_22->module;
    zT_7 = ctx->store;
    zT_8 = ctx->symbol_reg;
    zT_9 = ctx->interner;
    zT_10 = ctx->module_reg;
    zT_11 = ctx->typereg;
    zT_12 = ctx->resolved_types;
    zT_13 = &ctx->suspending_fns;
    zT_14 = &ctx->frame_sizes;
    zT_15 = &ctx->state_widths;
    zT_16 = &ctx->awaited_fns;
    zT_17 = &ctx->async_hidden_fns;
    zT_18 = &ctx->driver_targets;
    zT_19 = &ctx->parent_result_type_list;
    zT_20 = &ctx->parent_result_start;
    zT_21 = &ctx->parent_result_count;
    zF_7DBA21B2_asyncFrameSizeRun(zT_6, zT_7, zT_8, zT_9, zT_10, zT_11, zT_12, zT_13, zT_14, zT_15, zT_16, zT_17, zT_18, zT_19, zT_20, zT_21);
    return;
}

/* phase_LIRLowering */
void zF_1F21ABE7_phase_LIRLowering(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_4028D896_Arr_unsigned_char_2 zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_02497559_anon_271470 zT_17;
    unsigned int zT_18;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_4028D896_Arr_unsigned_char_2 zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    zT_01BE9D46_AstValuePool zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_69057089_CompilerAlloc* zT_76;
    zT_CA01C129_LirSlotArrayList* zT_79;
    zT_846744CC_Arr_unsigned_char_5 zT_81;
    unsigned int zT_83;
    zT_C98AF326_CompilerCli zT_84;
    unsigned char zT_85;
    zT_C98AF326_CompilerCli zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned char zT_94;
    unsigned char* zT_97;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned char zT_103;
    unsigned int zT_105;
    unsigned char zT_106;
    unsigned int zT_108;
    unsigned char zT_109;
    unsigned int zT_111;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    unsigned int zT_119;
    unsigned char zT_121;
    unsigned char* zT_124;
    unsigned char zT_125;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_7E7544E4_LirStream* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    zT_3E40CD83_Sand* zT_132;
    int zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    zT_69057089_CompilerAlloc* zT_140;
    zT_6B356268_SemanticContext zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_3D7259E2_SymbolRegistry* zT_146;
    zT_8EED1867_ResolvedTypeTable* zT_147;
    zT_66E7D2EF_CoercionTable* zT_148;
    zT_F85C5DED_DiagnosticCollector* zT_149;
    unsigned char zT_150;
    zT_21D3708C_U32ToU32Map* zT_151;
    zT_21D3708C_U32ToU32Map* zT_152;
    zT_21D3708C_U32ToU32Map* zT_153;
    zT_21D3708C_U32ToU32Map* zT_154;
    zT_77F6F59C_ComptimeFoldTable* zT_155;
    unsigned int zT_156;
    zT_C98AF326_CompilerCli zT_157;
    unsigned char zT_158;
    zT_A4CE86B7_U64ToU32Map* zT_159;
    zT_A4CE86B7_U64ToU32Map* zT_160;
    zT_A4CE86B7_U64ToU32Map* zT_161;
    unsigned char zT_162;
    zT_072B53A6_ModuleRegistry* zT_164;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_166 = {0};
    zT_3E40CD83_Sand* zT_168;
    zT_69057089_CompilerAlloc* zT_169;
    zT_B687BB96_U32ArrayList zT_171 = {0};
    unsigned char zT_173;
    int zT_175;
    unsigned int zT_176;
    unsigned int zT_178;
    zT_6E8D187B_ModuleEntry* zT_180;
    zT_6E8D187B_ModuleEntry zT_181;
    unsigned int zT_182;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    zT_4028D896_Arr_unsigned_char_2 zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    int zT_196;
    unsigned char* zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200 = 0;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_6E8D187B_ModuleEntry* zT_217;
    zT_6E8D187B_ModuleEntry zT_218;
    unsigned int zT_219;
    zT_4028D896_Arr_unsigned_char_2 zT_223;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    zT_6E8D187B_ModuleEntry* zT_227;
    zT_6E8D187B_ModuleEntry zT_228;
    int zT_232;
    unsigned char* zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236 = 0;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned char* zT_245;
    unsigned int zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    zT_6B0A7D14_AstStore* zT_250;
    unsigned int zT_251;
    zT_6E8D187B_ModuleEntry* zT_253;
    zT_6E8D187B_ModuleEntry zT_254;
    zT_22A7C88B_AstNode zT_256 = {0};
    zT_8143F551_AstKind zT_257;
    unsigned char* zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    zT_6B0A7D14_AstStore* zT_267;
    unsigned int zT_268;
    zT_6E8D187B_ModuleEntry* zT_270;
    zT_6E8D187B_ModuleEntry zT_271;
    unsigned int zT_273 = 0;
    unsigned int zT_275;
    zT_4028D896_Arr_unsigned_char_2 zT_277;
    unsigned int zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    int zT_283;
    unsigned char* zT_284;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287 = 0;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned char* zT_296;
    unsigned int zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    zT_6B0A7D14_AstStore* zT_300;
    unsigned int zT_301;
    zT_B687BB96_U32ArrayList* zT_302;
    zT_6E8D187B_ModuleEntry* zT_304;
    zT_6E8D187B_ModuleEntry zT_305;
    zT_6E8D187B_ModuleEntry* zT_307;
    zT_6E8D187B_ModuleEntry* zT_308;
    unsigned char zT_311;
    unsigned int zT_313;
    zT_6B0A7D14_AstStore* zT_317;
    unsigned int zT_318;
    zT_6E8D187B_ModuleEntry* zT_321;
    zT_6E8D187B_ModuleEntry zT_322;
    unsigned int zT_325 = 0;
    zT_6B0A7D14_AstStore* zT_327;
    unsigned int zT_328;
    zT_22A7C88B_AstNode zT_330 = {0};
    zT_8143F551_AstKind zT_332;
    unsigned int zT_333;
    zT_4028D896_Arr_unsigned_char_2 zT_335;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    int zT_341;
    unsigned char* zT_342;
    unsigned int zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned int zT_345 = 0;
    unsigned int zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned char* zT_354;
    unsigned int zT_355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    unsigned char* zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    unsigned int zT_360;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_361;
    zT_8143F551_AstKind zT_362;
    unsigned char* zT_367;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    unsigned int zT_369;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_370;
    unsigned char zT_371;
    zT_6B0A7D14_AstStore* zT_378;
    zT_FD2A0A98_anon_271503 zT_379;
    zT_243D6A41_FnProto* zT_380;
    zT_6B0A7D14_AstStore* zT_381;
    unsigned int zT_382;
    unsigned int zT_384 = 0;
    unsigned int zT_385;
    zT_243D6A41_FnProto zT_386;
    zT_6E8D187B_ModuleEntry* zT_388;
    zT_6E8D187B_ModuleEntry zT_389;
    unsigned int zT_390;
    unsigned int zT_398;
    zT_79FAE712_u64 zT_400;
    zT_A4CE86B7_U64ToU32Map* zT_401;
    zT_79FAE712_u64 zT_402;
    zT_6B356268_SemanticContext* zT_407;
    zT_3E40CD83_Sand* zT_408;
    zT_69057089_CompilerAlloc* zT_410;
    zT_02EB57B2_LirLowerer zT_412 = {0};
    zT_6E8D187B_ModuleEntry* zT_413;
    zT_6E8D187B_ModuleEntry zT_414;
    unsigned int zT_415;
    zT_072B53A6_ModuleRegistry* zT_416;
    zT_02EB57B2_LirLowerer* zT_418;
    unsigned int zT_419;
    zT_BBC23664_LirFunction zT_421 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_422;
    unsigned int zT_423;
    unsigned int zT_424;
    unsigned char zT_428 = 0;
    zT_3E40CD83_Sand* zT_430;
    zT_338B7C76_TypeRegistry* zT_431;
    zT_BBC23664_LirFunction* zT_432;
    zT_A4CE86B7_U64ToU32Map* zT_433;
    zT_A4CE86B7_U64ToU32Map* zT_434;
    zT_A4CE86B7_U64ToU32Map* zT_435;
    zT_A4CE86B7_U64ToU32Map* zT_436;
    zT_A4CE86B7_U64ToU32Map* zT_437;
    zT_A4CE86B7_U64ToU32Map* zT_438;
    zT_B687BB96_U32ArrayList* zT_439;
    zT_A4CE86B7_U64ToU32Map* zT_440;
    zT_A4CE86B7_U64ToU32Map* zT_441;
    zT_69057089_CompilerAlloc* zT_442;
    zT_3F3BF87A_AsyncFrameLayout zT_455 = {0};
    zT_3E40CD83_Sand* zT_456;
    zT_A4CE86B7_U64ToU32Map* zT_457;
    unsigned int zT_458;
    unsigned int zT_459;
    zT_3F3BF87A_AsyncFrameLayout zT_460;
    zT_69057089_CompilerAlloc* zT_461;
    zT_3E40CD83_Sand* zT_467;
    zT_69057089_CompilerAlloc* zT_470;
    zT_2AAC3D00_EU_642 zT_474 = {0};
    unsigned char zT_475;
    unsigned char* zT_476;
    zT_BBC23664_LirFunction* zT_479;
    zT_B687BB96_U32ArrayList* zT_480;
    unsigned char zT_485;
    zT_7E7544E4_LirStream* zT_487;
    zT_BBC23664_LirFunction zT_488;
    zT_E7714190_LirSlot zT_490 = {0};
    zT_CA01C129_LirSlotArrayList* zT_491;
    zT_E7714190_LirSlot zT_492;
    zT_3E40CD83_Sand* zT_495;
    zT_69057089_CompilerAlloc* zT_496;
    zT_8143F551_AstKind zT_498;
    unsigned char zT_502;
    zT_6B0A7D14_AstStore* zT_509;
    unsigned int zT_510;
    unsigned int zT_512 = 0;
    zT_3D7259E2_SymbolRegistry* zT_514;
    unsigned int zT_515;
    unsigned int zT_516;
    zT_6E8D187B_ModuleEntry* zT_518;
    zT_6E8D187B_ModuleEntry zT_519;
    zT_E5E651A2_Opt_926 zT_521 = {0};
    unsigned char zT_522;
    zT_3C598AEF_SymbolKind zT_524;
    unsigned char zT_529;
    unsigned char zT_530;
    unsigned char zT_536;
    unsigned int zT_537;
    zT_6B0A7D14_AstStore* zT_541;
    unsigned int zT_542;
    zT_22A7C88B_AstNode zT_545 = {0};
    zT_8143F551_AstKind zT_546;
    unsigned char zT_550;
    zT_8143F551_AstKind zT_551;
    unsigned char zT_555;
    zT_8143F551_AstKind zT_556;
    unsigned char zT_560;
    unsigned int zT_563;
    zT_6B0A7D14_AstStore* zT_567;
    unsigned int zT_568;
    zT_22A7C88B_AstNode zT_571 = {0};
    zT_8143F551_AstKind zT_572;
    unsigned char zT_576;
    zT_8143F551_AstKind zT_577;
    zT_6B0A7D14_AstStore* zT_582;
    unsigned int zT_583;
    zT_22A7C88B_AstNode zT_586 = {0};
    zT_8143F551_AstKind zT_587;
    unsigned char zT_591;
    unsigned char zT_594;
    zT_6E8D187B_ModuleEntry* zT_601;
    zT_6E8D187B_ModuleEntry zT_602;
    unsigned int zT_603;
    zT_79FAE712_u64 zT_612;
    zT_A4CE86B7_U64ToU32Map* zT_613;
    zT_79FAE712_u64 zT_614;
    unsigned char zT_619;
    unsigned int zT_620;
    zT_6B0A7D14_AstStore* zT_624;
    unsigned int zT_625;
    zT_22A7C88B_AstNode zT_628 = {0};
    zT_8143F551_AstKind zT_629;
    unsigned char zT_633;
    unsigned char zT_636;
    zT_8EED1867_ResolvedTypeTable* zT_638;
    unsigned int zT_639;
    zT_BAEE192E_Opt_10 zT_641 = {0};
    unsigned char zT_643;
    unsigned int zT_644;
    zT_E1A783EF_GlobalDeclArrayList* zT_647;
    zT_54906056_ModuleGlobalDecl zT_648;
    zT_54906056_ModuleGlobalDecl zT_650;
    zT_6E8D187B_ModuleEntry* zT_651;
    zT_6E8D187B_ModuleEntry zT_652;
    unsigned int zT_653;
    unsigned int zT_655;
    zT_6B356268_SemanticContext* zT_659;
    zT_3E40CD83_Sand* zT_660;
    zT_69057089_CompilerAlloc* zT_662;
    zT_02EB57B2_LirLowerer zT_664 = {0};
    zT_6E8D187B_ModuleEntry* zT_665;
    zT_6E8D187B_ModuleEntry zT_666;
    unsigned int zT_667;
    zT_072B53A6_ModuleRegistry* zT_668;
    zT_02EB57B2_LirLowerer* zT_670;
    unsigned int zT_671;
    unsigned int zT_672;
    zT_A4CE86B7_U64ToU32Map* zT_673;
    zT_6E8D187B_ModuleEntry* zT_675;
    zT_6E8D187B_ModuleEntry zT_676;
    zT_6E8D187B_ModuleEntry* zT_678;
    zT_6E8D187B_ModuleEntry zT_679;
    zT_BBC23664_LirFunction zT_682 = {0};
    zT_7E7544E4_LirStream* zT_684;
    zT_BBC23664_LirFunction zT_685;
    zT_E7714190_LirSlot zT_687 = {0};
    zT_CA01C129_LirSlotArrayList* zT_688;
    zT_E7714190_LirSlot zT_689;
    zT_3E40CD83_Sand* zT_692;
    zT_69057089_CompilerAlloc* zT_693;
    zT_072B53A6_ModuleRegistry* zT_696;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_698 = {0};
    unsigned int zT_700;
    unsigned char zT_703;
    zT_6E8D187B_ModuleEntry* zT_704;
    int zT_705;
    zT_6E8D187B_ModuleEntry zT_706;
    unsigned int zT_707;
    zT_6B0A7D14_AstStore* zT_711;
    unsigned int zT_712;
    zT_6E8D187B_ModuleEntry* zT_714;
    int zT_715;
    zT_6E8D187B_ModuleEntry zT_716;
    zT_22A7C88B_AstNode zT_718 = {0};
    zT_8143F551_AstKind zT_719;
    zT_6B0A7D14_AstStore* zT_724;
    unsigned int zT_725;
    zT_6E8D187B_ModuleEntry* zT_727;
    int zT_728;
    zT_6E8D187B_ModuleEntry zT_729;
    unsigned int zT_731 = 0;
    unsigned int zT_733;
    unsigned char* zT_735;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_736;
    unsigned int zT_737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_738;
    zT_6B0A7D14_AstStore* zT_742;
    unsigned int zT_743;
    zT_6B0A7D14_AstStore* zT_745;
    unsigned int zT_746;
    zT_6E8D187B_ModuleEntry* zT_749;
    int zT_750;
    zT_6E8D187B_ModuleEntry zT_751;
    unsigned int zT_754 = 0;
    zT_22A7C88B_AstNode zT_755 = {0};
    zT_8143F551_AstKind zT_757;
    unsigned int zT_758;
    zT_4028D896_Arr_unsigned_char_2 zT_760;
    unsigned int zT_762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_763;
    int zT_766;
    unsigned char* zT_767;
    unsigned int zT_768;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    unsigned int zT_770 = 0;
    unsigned int zT_774;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_775;
    unsigned char* zT_779;
    unsigned int zT_780;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_781;
    unsigned char* zT_783;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_784;
    unsigned int zT_785;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_786;
    unsigned int zT_788;
    unsigned char* zT_790;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_791;
    unsigned int zT_792;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_793;
    int zT_794;
    unsigned int zT_796;
    unsigned int zT_798;
    unsigned int zT_799;
    unsigned int* zT_802;
    unsigned int zT_803;
    zT_BBC23664_LirFunction* zT_805;
    zT_A4CE86B7_U64ToU32Map* zT_806;
    unsigned int zT_807;
    unsigned int zT_808;
    zT_13D2E8D1_Opt_422 zT_812 = {0};
    unsigned char zT_813;
    zT_5839647A_AsyncTransformCtx zT_816;
    zT_69057089_CompilerAlloc* zT_817;
    zT_3E40CD83_Sand* zT_818;
    zT_338B7C76_TypeRegistry* zT_819;
    zT_D3EB6303_StringInterner* zT_820;
    zT_7E7544E4_LirStream* zT_821;
    zT_CA01C129_LirSlotArrayList* zT_822;
    zT_A4CE86B7_U64ToU32Map* zT_823;
    zT_C98AF326_CompilerCli zT_824;
    unsigned char zT_825;
    zT_A4CE86B7_U64ToU32Map* zT_826;
    zT_A4CE86B7_U64ToU32Map* zT_827;
    zT_F85C5DED_DiagnosticCollector* zT_828;
    zT_BBC23664_LirFunction* zT_829;
    zT_5839647A_AsyncTransformCtx* zT_830;
    unsigned char zT_832 = 0;
    unsigned int zT_834;
    zT_3E40CD83_Sand* zT_835;
    zT_69057089_CompilerAlloc* zT_836;
    zT_5AB29387_CompilerContext* zT_838;
    zT_7E7544E4_LirStream* zT_839;
    unsigned char zT_841;
    unsigned char* zT_845;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_846;
    unsigned int zT_847;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_848;
    zT_D3EB6303_StringInterner* zT_849;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_850;
    zT_072B53A6_ModuleRegistry* zT_851;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_853 = {0};
    unsigned int zT_855 = 0;
    unsigned char* zT_859;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_860;
    unsigned int zT_861;
    unsigned char* zT_863;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_864;
    unsigned int zT_865;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_867;
    unsigned int zT_868;
    unsigned int zT_869;
    unsigned int zT_870;
    zT_D3EB6303_StringInterner* zT_872;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_873;
    int zT_876;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_877;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_879 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_880;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_886;
    unsigned int zT_895 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnmsg;
    zT_4028D896_Arr_unsigned_char_2 ln_buf;
    unsigned int ln_len;
    unsigned int ln_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lemsg;
    zT_4028D896_Arr_unsigned_char_2 le_buf;
    unsigned int le_len;
    unsigned int le_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnl;
    zT_846744CC_Arr_unsigned_char_5 spill_path;
    unsigned int sp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmp_name;
    unsigned int ti;
    zT_6B356268_SemanticContext sem_ctx;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_B687BB96_U32ArrayList async_retained;
    unsigned char async_pending;
    unsigned int mi;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm;
    zT_4028D896_Arr_unsigned_char_2 mi_buf;
    unsigned int mi_len;
    unsigned int mi2_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u msep;
    unsigned int arl_i;
    zT_4028D896_Arr_unsigned_char_2 ar_buf;
    unsigned int ar_len;
    unsigned int ar_start;
    zT_22A7C88B_AstNode root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr;
    unsigned int decls_n;
    unsigned int decl_len;
    zT_4028D896_Arr_unsigned_char_2 dcount_buf;
    unsigned int dcount_len;
    unsigned int dstart;
    unsigned char mod_has_ri;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int raw_k;
    zT_4028D896_Arr_unsigned_char_2 rbuf;
    unsigned int rlen;
    unsigned int rstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp2;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf;
    zT_243D6A41_FnProto fexp_proto;
    zT_79FAE712_u64 fexp_key;
    zT_02EB57B2_LirLowerer lowerer;
    zT_BBC23664_LirFunction lf;
    zT_3F3BF87A_AsyncFrameLayout async_layout;
    unsigned char* lf_raw;
    zT_E7714190_LirSlot slot;
    zT_BBC23664_LirFunction* lf_ptr;
    unsigned int gv_name;
    zT_E5E651A2_Opt_926 gv_sym;
    zT_3A105EF1_Symbol* gvs;
    unsigned char gv_is_storage;
    zT_22A7C88B_AstNode gv_init;
    zT_22A7C88B_AstNode gv_init3;
    zT_22A7C88B_AstNode gv_fb;
    zT_79FAE712_u64 gexp_key;
    unsigned char gv_has_ri;
    zT_22A7C88B_AstNode gv_init2;
    zT_BAEE192E_Opt_10 gv_rt;
    unsigned int gv_tid;
    unsigned int grt;
    zT_02EB57B2_LirLowerer ilowerer;
    zT_BBC23664_LirFunction imf;
    zT_E7714190_LirSlot islot;
    zT_DDCD424B_Slice_zT_6E8D187B_M amods;
    zT_22A7C88B_AstNode ar;
    unsigned int adl_n;
    unsigned int adi;
    zT_8F083A69_Slice_zT_0B42B2F8_u al;
    zT_22A7C88B_AstNode ad;
    unsigned int ak;
    zT_4028D896_Arr_unsigned_char_2 ab;
    unsigned int alen;
    unsigned int ast;
    zT_8F083A69_Slice_zT_0B42B2F8_u asp;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_BBC23664_LirFunction* lf2;
    zT_3F3BF87A_AsyncFrameLayout* lay2;
    zT_5839647A_AsyncTransformCtx async_ctx2;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = "L\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = "nodes=";
    zT_9 = 6;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    lnmsg = zT_8;
    zT_10 = lnmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ln_buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_16 = ctx->store;
    zT_17 = zT_16->nodes;
    zT_18 = zT_17.len;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)ln_buf) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = zT_23;
    zT_25.len = zT_24;
    zT_15 = zT_25;
    zT_26 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_18), zT_15);
    ln_len = zT_26;
    zT_30 = (unsigned int)(19) - (unsigned int)((unsigned int)ln_len);
    ln_start = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)ln_buf) + ln_start;
    zT_36 = (unsigned int)(19) - ln_start;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = " extra=";
    zT_41 = 7;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    lemsg = zT_40;
    zT_42 = lemsg;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        le_buf[_i] = zT_44[_i];
        _i++;
    }
}
    zT_48 = ctx->store;
    zT_49 = zT_48->extra_children;
    zT_50 = zT_49.len;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)le_buf) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_47 = zT_57;
    zT_58 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_50), zT_47);
    le_len = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)le_len);
    le_start = zT_62;
    zT_67 = (unsigned char*)((unsigned char*)le_buf) + le_start;
    zT_68 = (unsigned int)(19) - le_start;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zF_48AC7B3A_markerWrite(zT_63);
    zT_71 = "\n";
    zT_73 = 1;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    lnl = zT_72;
    zT_74 = lnl;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_76 = ctx->alloc;
    zT_75 = &zT_76->scratch;
    zF_F1B3F8C2_sandReset(zT_75);
    zT_79 = &ctx->lir_slots;
    zT_79->len = (unsigned int)(0);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_81[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        spill_path[_i] = zT_81[_i];
        _i++;
    }
}
    zT_83 = 0;
    sp_len = zT_83;
    zT_84 = ctx->cli;
    zT_85 = zT_84.output_dir_set;
    if (zT_85) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_87 = ctx->cli;
    zT_88 = zT_87.output_dir;
    od = zT_88;
    zT_90 = 0;
    oi = zT_90;
    goto z_bb_4;
    z_bb_2:
    zT_113 = ".zig1_lir.tmp";
    zT_115 = 13;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    tmp_name = zT_114;
    zT_117 = 0;
    ti = zT_117;
    goto z_bb_11;
    z_bb_3:
    zT_106 = 46;
    spill_path[sp_len] = zT_106;
    zT_108 = sp_len + (unsigned int)(1);
    sp_len = zT_108;
    zT_109 = 47;
    spill_path[sp_len] = zT_109;
    zT_111 = sp_len + (unsigned int)(1);
    sp_len = zT_111;
    goto z_bb_2;
    z_bb_4:
    zT_92 = od.len;
    if ((unsigned char)(oi < zT_92)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_97 = od.ptr;
    zT_98 = zT_97[oi];
    spill_path[sp_len] = zT_98;
    zT_100 = sp_len + (unsigned int)(1);
    sp_len = zT_100;
    goto z_bb_7;
    z_bb_6:
    zT_103 = 47;
    spill_path[sp_len] = zT_103;
    zT_105 = sp_len + (unsigned int)(1);
    sp_len = zT_105;
    goto z_bb_2;
    z_bb_7:
    zT_102 = oi + (unsigned int)(1);
    oi = zT_102;
    goto z_bb_4;
    z_bb_8:
    zT_94 = sp_len < (unsigned int)(511);
    goto z_bb_10;
    z_bb_9:
    zT_94 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_94) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    zT_119 = tmp_name.len;
    if ((unsigned char)(ti < zT_119)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_124 = tmp_name.ptr;
    zT_125 = zT_124[ti];
    spill_path[sp_len] = zT_125;
    zT_127 = sp_len + (unsigned int)(1);
    sp_len = zT_127;
    goto z_bb_14;
    z_bb_13:
    zT_130 = &ctx->lir_stream;
    zT_136 = 0;
    zT_137 = (unsigned char*)((unsigned char*)spill_path) + zT_136;
    zT_138 = sp_len - zT_136;
    zT_139.ptr = zT_137;
    zT_139.len = zT_138;
    zT_131 = zT_139;
    zT_140 = ctx->alloc;
    zT_132 = &zT_140->emission;
    zF_B0B74E20_lirStreamBeginWrite(zT_130, zT_131, zT_132);
    zT_144 = ctx->store;
    zT_143.store = zT_144;
    zT_145 = ctx->typereg;
    zT_143.registry = zT_145;
    zT_146 = ctx->symbol_reg;
    zT_143.symbol_tables = zT_146;
    zT_147 = ctx->resolved_types;
    zT_143.resolved_types = zT_147;
    zT_148 = ctx->coercion_table;
    zT_143.coercions = zT_148;
    zT_149 = ctx->diag;
    zT_143.diag = zT_149;
    zT_150 = 1;
    zT_143.has_symbols = zT_150;
    zT_151 = &ctx->enum_value_table;
    zT_143.enum_value_table = zT_151;
    zT_152 = &ctx->tuple_index_table;
    zT_143.tuple_index_table = zT_152;
    zT_153 = &ctx->error_code_registry;
    zT_143.error_code_registry = zT_153;
    zT_154 = &ctx->call_arg_types;
    zT_143.call_arg_types = zT_154;
    zT_155 = &ctx->comptime_folds;
    zT_143.comptime_folds = zT_155;
    zT_156 = 0;
    zT_143.source_file_id = zT_156;
    zT_157 = ctx->cli;
    zT_158 = zT_157.safe_checks;
    zT_143.safe_checks = zT_158;
    zT_159 = &ctx->suspending_fns;
    zT_143.suspending_fns = zT_159;
    zT_160 = &ctx->frame_sizes;
    zT_143.frame_sizes = zT_160;
    zT_161 = &ctx->state_widths;
    zT_143.state_widths = zT_161;
    zT_162 = 0;
    zT_143.print_value_lowered = zT_162;
    sem_ctx = zT_143;
    zT_164 = ctx->module_reg;
    zT_166 = zF_3452C137_moduleRegistryGetMo(zT_164);
    mods = zT_166;
    zT_169 = ctx->alloc;
    zT_168 = &zT_169->module;
    zT_171 = zF_8E537D0C_u32ArrayListInit(zT_168);
    async_retained = zT_171;
    zT_173 = 0;
    async_pending = zT_173;
    zT_175 = 0;
    zT_176 = (unsigned int)zT_175;
    mi = zT_176;
    goto z_bb_18;
    z_bb_14:
    zT_129 = ti + (unsigned int)(1);
    ti = zT_129;
    goto z_bb_11;
    z_bb_15:
    zT_121 = sp_len < (unsigned int)(511);
    goto z_bb_17;
    z_bb_16:
    zT_121 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_121) goto z_bb_12; else goto z_bb_13;
    z_bb_18:
    zT_178 = mods.len;
    if ((unsigned char)(mi < zT_178)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_180 = mods.ptr;
    zT_181 = zT_180[mi];
    zT_182 = zT_181.source_file_id;
    sem_ctx.source_file_id = zT_182;
    zT_184 = "M";
    zT_186 = 1;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    mm = zT_185;
    zT_187 = mm;
    zF_48AC7B3A_markerWrite(zT_187);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_189[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        mi_buf[_i] = zT_189[_i];
        _i++;
    }
}
    zT_196 = 0;
    zT_197 = (unsigned char*)((unsigned char*)mi_buf) + zT_196;
    zT_198 = (unsigned int)(20) - zT_196;
    zT_199.ptr = zT_197;
    zT_199.len = zT_198;
    zT_192 = zT_199;
    zT_200 = zF_A7504564_itoa((unsigned int)((unsigned int)mi), zT_192);
    mi_len = zT_200;
    zT_204 = (unsigned int)(19) - (unsigned int)((unsigned int)mi_len);
    mi2_start = zT_204;
    zT_209 = (unsigned char*)((unsigned char*)mi_buf) + mi2_start;
    zT_210 = (unsigned int)(19) - mi2_start;
    zT_211.ptr = zT_209;
    zT_211.len = zT_210;
    zT_205 = zT_211;
    zF_48AC7B3A_markerWrite(zT_205);
    zT_213 = ":";
    zT_215 = 1;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    msep = zT_214;
    zT_216 = msep;
    zF_48AC7B3A_markerWrite(zT_216);
    zT_217 = mods.ptr;
    zT_218 = zT_217[mi];
    zT_219 = zT_218.ast_root;
    if ((unsigned char)(zT_219 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_798 = 0;
    arl_i = zT_798;
    goto z_bb_102;
    z_bb_21:
    zT_794 = 1;
    zT_796 = mi + (unsigned int)((unsigned int)zT_794);
    mi = zT_796;
    goto z_bb_18;
    z_bb_22:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_223[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ar_buf[_i] = zT_223[_i];
        _i++;
    }
}
    zT_227 = mods.ptr;
    zT_228 = zT_227[mi];
    zT_225 = zT_228.ast_root;
    zT_232 = 0;
    zT_233 = (unsigned char*)((unsigned char*)ar_buf) + zT_232;
    zT_234 = (unsigned int)(20) - zT_232;
    zT_235.ptr = zT_233;
    zT_235.len = zT_234;
    zT_226 = zT_235;
    zT_236 = zF_A7504564_itoa(zT_225, zT_226);
    ar_len = zT_236;
    zT_240 = (unsigned int)(19) - (unsigned int)((unsigned int)ar_len);
    ar_start = zT_240;
    zT_245 = (unsigned char*)((unsigned char*)ar_buf) + ar_start;
    zT_246 = (unsigned int)(19) - ar_start;
    zT_247.ptr = zT_245;
    zT_247.len = zT_246;
    zT_241 = zT_247;
    zF_48AC7B3A_markerWrite(zT_241);
    zT_248 = msep;
    zF_48AC7B3A_markerWrite(zT_248);
    zT_250 = ctx->store;
    zT_253 = mods.ptr;
    zT_254 = zT_253[mi];
    zT_251 = zT_254.ast_root;
    zT_256 = zF_FCDD1D35_astStoreNodeAt(zT_250, zT_251);
    root = zT_256;
    zT_257 = root.kind;
    if ((unsigned char)(zT_257 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_262 = "R";
    zT_264 = 1;
    zT_263.ptr = zT_262;
    zT_263.len = zT_264;
    mr = zT_263;
    zT_265 = mr;
    zF_48AC7B3A_markerWrite(zT_265);
    zT_267 = ctx->store;
    zT_270 = mods.ptr;
    zT_271 = zT_270[mi];
    zT_268 = zT_271.ast_root;
    zT_273 = zF_152E19CB_astStoreNodeExtraCh(zT_267, zT_268);
    decls_n = zT_273;
    zT_275 = (unsigned int)decls_n;
    decl_len = zT_275;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_277[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dcount_buf[_i] = zT_277[_i];
        _i++;
    }
}
    zT_279 = decl_len;
    zT_283 = 0;
    zT_284 = (unsigned char*)((unsigned char*)dcount_buf) + zT_283;
    zT_285 = (unsigned int)(20) - zT_283;
    zT_286.ptr = zT_284;
    zT_286.len = zT_285;
    zT_280 = zT_286;
    zT_287 = zF_A7504564_itoa(zT_279, zT_280);
    dcount_len = zT_287;
    zT_291 = (unsigned int)(19) - (unsigned int)((unsigned int)dcount_len);
    dstart = zT_291;
    zT_296 = (unsigned char*)((unsigned char*)dcount_buf) + dstart;
    zT_297 = (unsigned int)(19) - dstart;
    zT_298.ptr = zT_296;
    zT_298.len = zT_297;
    zT_292 = zT_298;
    zF_48AC7B3A_markerWrite(zT_292);
    zT_299 = msep;
    zF_48AC7B3A_markerWrite(zT_299);
    zT_300 = ctx->store;
    zT_304 = mods.ptr;
    zT_305 = zT_304[mi];
    zT_301 = zT_305.ast_root;
    zT_307 = mods.ptr;
    zT_308 = zT_307 + mi;
    zT_302 = &zT_308->c_includes;
    zF_7D71E4ED_moduleRegistryColle(zT_300, zT_301, zT_302);
    zT_311 = 0;
    mod_has_ri = zT_311;
    zT_313 = 0;
    di = zT_313;
    goto z_bb_26;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_317 = ctx->store;
    zT_321 = mods.ptr;
    zT_322 = zT_321[mi];
    zT_318 = zT_322.ast_root;
    zT_325 = zF_B10B1BC1_astStoreNodeExtraCh(zT_317, zT_318, (unsigned int)((unsigned int)di));
    decl_idx = zT_325;
    zT_327 = ctx->store;
    zT_328 = decl_idx;
    zT_330 = zF_FCDD1D35_astStoreNodeAt(zT_327, zT_328);
    decl = zT_330;
    zT_332 = decl.kind;
    zT_333 = (unsigned int)zT_332;
    raw_k = zT_333;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_335[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rbuf[_i] = zT_335[_i];
        _i++;
    }
}
    zT_337 = raw_k;
    zT_341 = 0;
    zT_342 = (unsigned char*)((unsigned char*)rbuf) + zT_341;
    zT_343 = (unsigned int)(20) - zT_341;
    zT_344.ptr = zT_342;
    zT_344.len = zT_343;
    zT_338 = zT_344;
    zT_345 = zF_A7504564_itoa(zT_337, zT_338);
    rlen = zT_345;
    zT_349 = (unsigned int)(19) - (unsigned int)((unsigned int)rlen);
    rstart = zT_349;
    zT_354 = (unsigned char*)((unsigned char*)rbuf) + rstart;
    zT_355 = (unsigned int)(19) - rstart;
    zT_356.ptr = zT_354;
    zT_356.len = zT_355;
    zT_350 = zT_356;
    zF_48AC7B3A_markerWrite(zT_350);
    zT_358 = " ";
    zT_360 = 1;
    zT_359.ptr = zT_358;
    zT_359.len = zT_360;
    sp2 = zT_359;
    zT_361 = sp2;
    zF_48AC7B3A_markerWrite(zT_361);
    zT_362 = decl.kind;
    if ((unsigned char)(zT_362 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_30; else goto z_bb_32;
    z_bb_28:
    if ((unsigned char)(mod_has_ri != (unsigned char)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_29:
    zT_655 = di + (unsigned int)(1);
    di = zT_655;
    goto z_bb_26;
    z_bb_30:
    zT_367 = "F";
    zT_369 = 1;
    zT_368.ptr = zT_367;
    zT_368.len = zT_369;
    mf = zT_368;
    zT_370 = mf;
    zF_48AC7B3A_markerWrite(zT_370);
    zT_371 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_371) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_498 = decl.kind;
    if ((unsigned char)(zT_498 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_43; else goto z_bb_44;
    z_bb_33:
    zT_378 = ctx->store;
    zT_379 = zT_378->fn_protos;
    zT_380 = zT_379.items;
    zT_381 = ctx->store;
    zT_382 = decl_idx;
    zT_384 = zF_8BA26B9E_astStoreNodePayload(zT_381, zT_382);
    zT_385 = (unsigned int)zT_384;
    zT_386 = zT_380[zT_385];
    fexp_proto = zT_386;
    zT_388 = mods.ptr;
    zT_389 = zT_388[mi];
    zT_390 = zT_389.id;
    zT_398 = fexp_proto.name_id;
    zT_400 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_390) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(0)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_398);
    fexp_key = zT_400;
    zT_401 = &ctx->exported;
    zT_402 = fexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_401, zT_402, (unsigned int)(1));
    goto z_bb_34;
    z_bb_34:
    zT_407 = &sem_ctx;
    zT_410 = ctx->alloc;
    zT_408 = &zT_410->scratch;
    zT_412 = zF_ADD4254B_lowererInit(zT_407, zT_408);
    lowerer = zT_412;
    zT_413 = mods.ptr;
    zT_414 = zT_413[mi];
    zT_415 = zT_414.id;
    lowerer.module_id = zT_415;
    zT_416 = ctx->module_reg;
    lowerer.module_reg = zT_416;
    zT_418 = &lowerer;
    zT_419 = decl_idx;
    zT_421 = zF_B53F5F2E_lowerFn(zT_418, zT_419);
    lf = zT_421;
    zT_422 = &ctx->suspending_fns;
    zT_423 = lf.module_id;
    zT_424 = lf.name_id;
    zT_428 = zF_7C7E43BF_asyncIsSuspending(zT_422, zT_423, zT_424);
    if (zT_428) goto z_bb_35; else goto z_bb_37;
    z_bb_35:
    zT_442 = ctx->alloc;
    zT_430 = &zT_442->scratch;
    zT_431 = ctx->typereg;
    zT_432 = &lf;
    zT_433 = &ctx->suspending_fns;
    zT_434 = &ctx->frame_sizes;
    zT_435 = &ctx->state_widths;
    zT_436 = &ctx->awaited_fns;
    zT_437 = &ctx->async_hidden_fns;
    zT_438 = &ctx->driver_targets;
    zT_439 = &ctx->parent_result_type_list;
    zT_440 = &ctx->parent_result_start;
    zT_441 = &ctx->parent_result_count;
    zT_455 = zF_28031796_asyncLayoutFrame(zT_430, zT_431, zT_432, zT_433, zT_434, zT_435, zT_436, zT_437, zT_438, zT_439, zT_440, zT_441);
    async_layout = zT_455;
    zT_461 = ctx->alloc;
    zT_456 = &zT_461->scratch;
    zT_457 = &ctx->async_layouts;
    zT_458 = lf.module_id;
    zT_459 = lf.name_id;
    zT_460 = async_layout;
    zF_17324878_asyncLayoutPublish(zT_456, zT_457, zT_458, zT_459, zT_460);
    zT_470 = ctx->alloc;
    zT_467 = &zT_470->scratch;
    zT_474 = zF_1395EB68_sandAlloc(zT_467, (unsigned int)(124), (unsigned int)(4));
    zT_475 = zT_474.is_error;
    if (zT_475) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_487 = &ctx->lir_stream;
    zT_488 = lf;
    zT_490 = zF_9F47D5E4_lirStreamAppend(zT_487, zT_488);
    slot = zT_490;
    zT_491 = &ctx->lir_slots;
    zT_492 = slot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_491, zT_492);
    if ((unsigned char)(!async_pending)) goto z_bb_41; else goto z_bb_42;
    z_bb_38:
    pal_trap();
    z_bb_39:
    zT_476 = zT_474.data.payload;
    goto z_bb_40;
    z_bb_40:
    lf_raw = zT_476;
    zT_479 = (zT_BBC23664_LirFunction*)lf_raw;
    lf_ptr = zT_479;
    *lf_ptr = lf;
    zT_480 = &async_retained;
    zF_62F717A2_u32ArrayListAppend(zT_480, (unsigned int)((unsigned int)(unsigned int)((unsigned int)lf_ptr)));
    zT_485 = 1;
    async_pending = zT_485;
    goto z_bb_36;
    z_bb_41:
    zT_496 = ctx->alloc;
    zT_495 = &zT_496->scratch;
    zF_F1B3F8C2_sandReset(zT_495);
    goto z_bb_42;
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_502 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_502) & (unsigned short)(4)) == (unsigned short)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_31;
    z_bb_45:
    zT_509 = ctx->store;
    zT_510 = decl_idx;
    zT_512 = zF_8BA26B9E_astStoreNodePayload(zT_509, zT_510);
    gv_name = zT_512;
    zT_514 = ctx->symbol_reg;
    zT_518 = mods.ptr;
    zT_519 = zT_518[mi];
    zT_515 = zT_519.id;
    zT_516 = gv_name;
    zT_521 = zF_A398987E_symbolRegistryQuali(zT_514, zT_515, zT_516);
    gv_sym = zT_521;
    zT_522 = gv_sym.has_value;
    if (zT_522) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_44;
    z_bb_47:
    gvs = gv_sym.value;
    zT_524 = gvs->kind;
    if ((unsigned char)(zT_524 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    zT_529 = 0;
    gv_is_storage = zT_529;
    zT_530 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_530) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_51; else goto z_bb_53;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_536 = 1;
    gv_is_storage = zT_536;
    goto z_bb_52;
    z_bb_52:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_64; else goto z_bb_65;
    z_bb_53:
    zT_537 = decl.child_1;
    if ((unsigned char)(zT_537 != (unsigned int)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_541 = ctx->store;
    zT_542 = decl.child_1;
    zT_545 = zF_FCDD1D35_astStoreNodeAt(zT_541, zT_542);
    gv_init = zT_545;
    zT_546 = gv_init.kind;
    if ((unsigned char)(zT_546 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_551 = gv_init.kind;
    zT_550 = zT_551 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal);
    goto z_bb_58;
    z_bb_57:
    zT_550 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_550) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_556 = gv_init.kind;
    zT_555 = zT_556 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_61;
    z_bb_60:
    zT_555 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_555) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_560 = 1;
    gv_is_storage = zT_560;
    goto z_bb_63;
    z_bb_63:
    goto z_bb_55;
    z_bb_64:
    zT_563 = decl.child_1;
    if ((unsigned char)(zT_563 != (unsigned int)(0))) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_74; else goto z_bb_75;
    z_bb_66:
    zT_567 = ctx->store;
    zT_568 = decl.child_1;
    zT_571 = zF_FCDD1D35_astStoreNodeAt(zT_567, zT_568);
    gv_init3 = zT_571;
    zT_572 = gv_init3.kind;
    if ((unsigned char)(zT_572 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_576 = 0;
    gv_is_storage = zT_576;
    goto z_bb_69;
    z_bb_69:
    zT_577 = gv_init3.kind;
    if ((unsigned char)(zT_577 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_582 = ctx->store;
    zT_583 = gv_init3.child_0;
    zT_586 = zF_FCDD1D35_astStoreNodeAt(zT_582, zT_583);
    gv_fb = zT_586;
    zT_587 = gv_fb.kind;
    if ((unsigned char)(zT_587 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    goto z_bb_67;
    z_bb_72:
    zT_591 = 0;
    gv_is_storage = zT_591;
    goto z_bb_73;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    zT_594 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_594) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    goto z_bb_50;
    z_bb_76:
    zT_601 = mods.ptr;
    zT_602 = zT_601[mi];
    zT_603 = zT_602.id;
    zT_612 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_603) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(Z98_U64_C(4294967296))) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_612;
    zT_613 = &ctx->exported;
    zT_614 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_613, zT_614, (unsigned int)(1));
    goto z_bb_77;
    z_bb_77:
    zT_619 = 0;
    gv_has_ri = zT_619;
    zT_620 = decl.child_1;
    if ((unsigned char)(zT_620 != (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_624 = ctx->store;
    zT_625 = decl.child_1;
    zT_628 = zF_FCDD1D35_astStoreNodeAt(zT_624, zT_625);
    gv_init2 = zT_628;
    zT_629 = gv_init2.kind;
    if ((unsigned char)(zT_629 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    if ((unsigned char)(gv_has_ri == (unsigned char)(1))) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    zT_633 = 1;
    gv_has_ri = zT_633;
    goto z_bb_81;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_636 = 1;
    mod_has_ri = zT_636;
    goto z_bb_83;
    z_bb_83:
    zT_638 = ctx->resolved_types;
    zT_639 = decl_idx;
    zT_641 = zF_999DCF51_resolvedTypeTableGe(zT_638, zT_639);
    gv_rt = zT_641;
    zT_643 = gv_rt.has_value;
    if (zT_643) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    grt = gv_rt.value;
    zT_644 = grt;
    goto z_bb_86;
    z_bb_85:
    zT_644 = 18;
    goto z_bb_86;
    z_bb_86:
    gv_tid = zT_644;
    zT_647 = &ctx->global_decls;
    zT_650.name_id = gv_name;
    zT_651 = mods.ptr;
    zT_652 = zT_651[mi];
    zT_653 = zT_652.id;
    zT_650.module_id = zT_653;
    zT_650.type_id = gv_tid;
    zT_650.has_runtime_init = gv_has_ri;
    zT_648 = zT_650;
    zF_F2C82CE7_globalDeclArrayList(zT_647, zT_648);
    goto z_bb_75;
    z_bb_87:
    zT_659 = &sem_ctx;
    zT_662 = ctx->alloc;
    zT_660 = &zT_662->scratch;
    zT_664 = zF_ADD4254B_lowererInit(zT_659, zT_660);
    ilowerer = zT_664;
    zT_665 = mods.ptr;
    zT_666 = zT_665[mi];
    zT_667 = zT_666.id;
    ilowerer.module_id = zT_667;
    zT_668 = ctx->module_reg;
    ilowerer.module_reg = zT_668;
    zT_670 = &ilowerer;
    zT_675 = mods.ptr;
    zT_676 = zT_675[mi];
    zT_671 = zT_676.ast_root;
    zT_678 = mods.ptr;
    zT_679 = zT_678[mi];
    zT_672 = zT_679.id;
    zT_673 = &ctx->module_init_deps;
    zT_682 = zF_552B231C_lowerModuleInit(zT_670, zT_671, zT_672, zT_673);
    imf = zT_682;
    zT_684 = &ctx->lir_stream;
    zT_685 = imf;
    zT_687 = zF_9F47D5E4_lirStreamAppend(zT_684, zT_685);
    islot = zT_687;
    zT_688 = &ctx->lir_slots;
    zT_689 = islot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_688, zT_689);
    if ((unsigned char)(!async_pending)) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_696 = ctx->module_reg;
    zT_698 = zF_3452C137_moduleRegistryGetMo(zT_696);
    amods = zT_698;
    zT_700 = amods.len;
    if ((unsigned char)(zT_700 > (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_89:
    zT_693 = ctx->alloc;
    zT_692 = &zT_693->scratch;
    zF_F1B3F8C2_sandReset(zT_692);
    goto z_bb_90;
    z_bb_90:
    goto z_bb_88;
    z_bb_91:
    zT_704 = amods.ptr;
    zT_705 = 0;
    zT_706 = zT_704[zT_705];
    zT_707 = zT_706.ast_root;
    zT_703 = zT_707 != (unsigned int)(0);
    goto z_bb_93;
    z_bb_92:
    zT_703 = 0;
    goto z_bb_93;
    z_bb_93:
    if (zT_703) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_711 = ctx->store;
    zT_714 = amods.ptr;
    zT_715 = 0;
    zT_716 = zT_714[zT_715];
    zT_712 = zT_716.ast_root;
    zT_718 = zF_FCDD1D35_astStoreNodeAt(zT_711, zT_712);
    ar = zT_718;
    zT_719 = ar.kind;
    if ((unsigned char)(zT_719 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_96; else goto z_bb_97;
    z_bb_95:
    goto z_bb_25;
    z_bb_96:
    zT_724 = ctx->store;
    zT_727 = amods.ptr;
    zT_728 = 0;
    zT_729 = zT_727[zT_728];
    zT_725 = zT_729.ast_root;
    zT_731 = zF_152E19CB_astStoreNodeExtraCh(zT_724, zT_725);
    adl_n = zT_731;
    zT_733 = 0;
    adi = zT_733;
    zT_735 = "A0";
    zT_737 = 2;
    zT_736.ptr = zT_735;
    zT_736.len = zT_737;
    al = zT_736;
    zT_738 = al;
    zF_48AC7B3A_markerWrite(zT_738);
    goto z_bb_98;
    z_bb_97:
    goto z_bb_95;
    z_bb_98:
    if ((unsigned char)(adi < (unsigned int)((unsigned int)adl_n))) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_742 = ctx->store;
    zT_745 = ctx->store;
    zT_749 = amods.ptr;
    zT_750 = 0;
    zT_751 = zT_749[zT_750];
    zT_746 = zT_751.ast_root;
    zT_754 = zF_B10B1BC1_astStoreNodeExtraCh(zT_745, zT_746, (unsigned int)((unsigned int)adi));
    zT_743 = zT_754;
    zT_755 = zF_FCDD1D35_astStoreNodeAt(zT_742, zT_743);
    ad = zT_755;
    zT_757 = ad.kind;
    zT_758 = (unsigned int)zT_757;
    ak = zT_758;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_760[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ab[_i] = zT_760[_i];
        _i++;
    }
}
    zT_762 = ak;
    zT_766 = 0;
    zT_767 = (unsigned char*)((unsigned char*)ab) + zT_766;
    zT_768 = (unsigned int)(20) - zT_766;
    zT_769.ptr = zT_767;
    zT_769.len = zT_768;
    zT_763 = zT_769;
    zT_770 = zF_A7504564_itoa(zT_762, zT_763);
    alen = zT_770;
    zT_774 = (unsigned int)(19) - (unsigned int)((unsigned int)alen);
    ast = zT_774;
    zT_779 = (unsigned char*)((unsigned char*)ab) + ast;
    zT_780 = (unsigned int)(19) - ast;
    zT_781.ptr = zT_779;
    zT_781.len = zT_780;
    zT_775 = zT_781;
    zF_48AC7B3A_markerWrite(zT_775);
    zT_783 = " ";
    zT_785 = 1;
    zT_784.ptr = zT_783;
    zT_784.len = zT_785;
    asp = zT_784;
    zT_786 = asp;
    zF_48AC7B3A_markerWrite(zT_786);
    goto z_bb_101;
    z_bb_100:
    zT_790 = "\n";
    zT_792 = 1;
    zT_791.ptr = zT_790;
    zT_791.len = zT_792;
    an = zT_791;
    zT_793 = an;
    zF_48AC7B3A_markerWrite(zT_793);
    goto z_bb_97;
    z_bb_101:
    zT_788 = adi + (unsigned int)(1);
    adi = zT_788;
    goto z_bb_98;
    z_bb_102:
    zT_799 = async_retained.len;
    if ((unsigned char)(arl_i < zT_799)) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_802 = async_retained.items;
    zT_803 = zT_802[arl_i];
    zT_805 = (zT_BBC23664_LirFunction*)(unsigned int)(unsigned int)((unsigned int)zT_803);
    lf2 = zT_805;
    zT_806 = &ctx->async_layouts;
    zT_807 = lf2->module_id;
    zT_808 = lf2->name_id;
    zT_812 = zF_A1F56FFB_asyncLayoutLookup(zT_806, zT_807, zT_808);
    zT_813 = zT_812.has_value;
    if (zT_813) goto z_bb_106; else goto z_bb_107;
    z_bb_104:
    if (async_pending) goto z_bb_108; else goto z_bb_109;
    z_bb_105:
    zT_834 = arl_i + (unsigned int)(1);
    arl_i = zT_834;
    goto z_bb_102;
    z_bb_106:
    lay2 = zT_812.value;
    zT_817 = ctx->alloc;
    zT_818 = &zT_817->scratch;
    zT_816.alloc = zT_818;
    zT_819 = ctx->typereg;
    zT_816.registry = zT_819;
    zT_820 = ctx->interner;
    zT_816.interner = zT_820;
    zT_821 = &ctx->lir_stream;
    zT_816.lir_stream = zT_821;
    zT_822 = &ctx->lir_slots;
    zT_816.lir_slots = zT_822;
    zT_823 = &ctx->suspending_fns;
    zT_816.suspending_fns = zT_823;
    zT_816.layout = lay2;
    zT_824 = ctx->cli;
    zT_825 = zT_824.safe_checks;
    zT_816.safe_checks = zT_825;
    zT_826 = &ctx->frame_sizes;
    zT_816.frame_sizes = zT_826;
    zT_827 = &ctx->async_layouts;
    zT_816.async_layouts = zT_827;
    zT_828 = ctx->diag;
    zT_816.diag = zT_828;
    async_ctx2 = zT_816;
    zT_829 = lf2;
    zT_830 = &async_ctx2;
    zT_832 = zF_7C1ED6D1_asyncTransform(zT_829, zT_830);
    (void)zT_832;
    goto z_bb_107;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    zT_836 = ctx->alloc;
    zT_835 = &zT_836->scratch;
    zF_F1B3F8C2_sandReset(zT_835);
    goto z_bb_109;
    z_bb_109:
    zT_838 = ctx;
    zF_B69A3794_computeModuleInitOr(zT_838);
    zT_839 = &ctx->lir_stream;
    zF_256E5B86_lirStreamFinishWrit(zT_839);
    zT_841 = sem_ctx.print_value_lowered;
    if ((unsigned char)(zT_841 != (unsigned char)(0))) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_845 = "std_fmt.zig";
    zT_847 = 11;
    zT_846.ptr = zT_845;
    zT_846.len = zT_847;
    c89_fmt_base = zT_846;
    zT_851 = ctx->module_reg;
    zT_853 = zF_3452C137_moduleRegistryGetMo(zT_851);
    zT_848 = zT_853;
    zT_849 = ctx->interner;
    zT_850 = c89_fmt_base;
    zT_855 = zF_D27A4A01_moduleIdForBasename(zT_848, zT_849, zT_850);
    if ((unsigned char)(zT_855 == (unsigned int)(4294967295u))) goto z_bb_112; else goto z_bb_113;
    z_bb_111:
    return;
    z_bb_112:
    zT_859 = "could not resolve imported file '";
    zT_861 = 33;
    zT_860.ptr = zT_859;
    zT_860.len = zT_861;
    p1 = zT_860;
    zT_863 = "'";
    zT_865 = 1;
    zT_864.ptr = zT_863;
    zT_864.len = zT_865;
    p2 = zT_864;
    zT_868 = 0;
    zT_867[zT_868] = p1;
    zT_869 = 1;
    zT_867[zT_869] = c89_fmt_base;
    zT_870 = 2;
    zT_867[zT_870] = p2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        parts[_i] = zT_867[_i];
        _i++;
    }
}
    zT_872 = ctx->interner;
    zT_876 = 0;
    zT_877 = parts + zT_876;
    zT_873 = zT_877;
    zT_879 = zF_8C4BFF7C_diagnosticBuilderMa(zT_872, zT_873, (unsigned int)(3));
    msg = zT_879;
    zT_880 = ctx->diag;
    zT_886 = msg;
    zT_895 = zF_C82559AC_diagnosticCollector(zT_880, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3048_CANNOT_READ_FILE)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_886);
    (void)zT_895;
    goto z_bb_113;
    z_bb_113:
    goto z_bb_111;
}

/* computeModuleInitOrder */
void zF_B69A3794_computeModuleInitOr(zT_5AB29387_CompilerContext* ctx) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_4 = {0};
    unsigned int zT_7;
    zT_B687BB96_U32ArrayList* zT_9;
    zT_3E40CD83_Sand* zT_11;
    zT_69057089_CompilerAlloc* zT_14;
    zT_2AAC3D00_EU_642 zT_19 = {0};
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned char* zT_23;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char zT_38;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_6E8D187B_ModuleEntry* zT_50;
    zT_6E8D187B_ModuleEntry zT_51;
    unsigned int zT_52;
    zT_6E8D187B_ModuleEntry* zT_56;
    zT_6E8D187B_ModuleEntry zT_57;
    unsigned int zT_58;
    zT_79FAE712_u64 zT_60;
    zT_A4CE86B7_U64ToU32Map* zT_61;
    zT_79FAE712_u64 zT_62;
    zT_BAEE192E_Opt_10 zT_64 = {0};
    unsigned char zT_65;
    unsigned char zT_66;
    unsigned int zT_68;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_6E8D187B_ModuleEntry* zT_92;
    zT_6E8D187B_ModuleEntry zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_100;
    zT_79FAE712_u64 zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    zT_BAEE192E_Opt_10 zT_106 = {0};
    unsigned char zT_107;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    zT_22A7C88B_AstNode zT_113 = {0};
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_F85C5DED_DiagnosticCollector* zT_118;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_6E8D187B_ModuleEntry* zT_130;
    zT_6E8D187B_ModuleEntry zT_131;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_138 = 0;
    unsigned char zT_139;
    unsigned int zT_141;
    unsigned int zT_143;
    unsigned char zT_144;
    zT_B687BB96_U32ArrayList* zT_145;
    unsigned int zT_146;
    zT_6E8D187B_ModuleEntry* zT_148;
    zT_6E8D187B_ModuleEntry zT_149;
    unsigned int zT_152;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int n;
    unsigned char* placed;
    unsigned int i;
    unsigned int remaining;
    unsigned int pick;
    unsigned char ok;
    unsigned int j;
    zT_79FAE712_u64 dep_key;
    unsigned int ri;
    unsigned char reported;
    unsigned int rj;
    zT_79FAE712_u64 cyc_key;
    unsigned int ref_decl;
    zT_22A7C88B_AstNode cyc_dcl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cyc_msg;
    zT_2 = ctx->module_reg;
    zT_4 = zF_3452C137_moduleRegistryGetMo(zT_2);
    mods = zT_4;
    zT_7 = mods.len;
    n = zT_7;
    zT_9 = &ctx->module_init_order;
    zT_9->len = (unsigned int)(0);
    zT_14 = ctx->alloc;
    zT_11 = &zT_14->scratch;
    zT_19 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)(n + (unsigned int)(1)), (unsigned int)(1));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_21 = zT_19.data.payload;
    goto z_bb_3;
    z_bb_3:
    zT_23 = (unsigned char*)zT_21;
    placed = zT_23;
    zT_25 = 0;
    i = zT_25;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < n)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = 0;
    placed[i] = zT_27;
    goto z_bb_7;
    z_bb_6:
    remaining = n;
    goto z_bb_8;
    z_bb_7:
    zT_29 = i + (unsigned int)(1);
    i = zT_29;
    goto z_bb_4;
    z_bb_8:
    if ((unsigned char)(remaining > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pick = n;
    zT_34 = 0;
    i = zT_34;
    goto z_bb_12;
    z_bb_10:
    return;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    if ((unsigned char)(i < n)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_38 = placed[i];
    if ((unsigned char)(zT_38 != (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_14:
    if ((unsigned char)(pick == n)) goto z_bb_31; else goto z_bb_32;
    z_bb_15:
    zT_72 = i + (unsigned int)(1);
    i = zT_72;
    goto z_bb_12;
    z_bb_16:
    zT_36 = pick == n;
    goto z_bb_18;
    z_bb_17:
    zT_36 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_36) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_42 = 1;
    ok = zT_42;
    zT_44 = 0;
    j = zT_44;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(j < n)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_46 = placed[j];
    if ((unsigned char)(zT_46 != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    if ((unsigned char)(ok != (unsigned char)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_24:
    zT_68 = j + (unsigned int)(1);
    j = zT_68;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_50 = mods.ptr;
    zT_51 = zT_50[i];
    zT_52 = zT_51.id;
    zT_56 = mods.ptr;
    zT_57 = zT_56[j];
    zT_58 = zT_57.id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_52) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_58);
    dep_key = zT_60;
    zT_61 = &ctx->module_init_deps;
    zT_62 = dep_key;
    zT_64 = zF_A05A7BE1_u64ToU32MapGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_66 = 0;
    ok = zT_66;
    goto z_bb_23;
    z_bb_28:
    goto z_bb_24;
    z_bb_29:
    pick = i;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_15;
    z_bb_31:
    zT_75 = 0;
    ri = zT_75;
    zT_77 = 0;
    reported = zT_77;
    goto z_bb_33;
    z_bb_32:
    zT_144 = 1;
    placed[pick] = zT_144;
    zT_145 = &ctx->module_init_order;
    zT_148 = mods.ptr;
    zT_149 = zT_148[pick];
    zT_146 = zT_149.id;
    zF_62F717A2_u32ArrayListAppend(zT_145, zT_146);
    zT_152 = remaining - (unsigned int)(1);
    remaining = zT_152;
    goto z_bb_11;
    z_bb_33:
    if ((unsigned char)(ri < n)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    zT_82 = placed[ri];
    if ((unsigned char)(zT_82 != (unsigned char)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_35:
    goto z_bb_10;
    z_bb_36:
    zT_143 = ri + (unsigned int)(1);
    ri = zT_143;
    goto z_bb_33;
    z_bb_37:
    zT_79 = reported == (unsigned char)(0);
    goto z_bb_39;
    z_bb_38:
    zT_79 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_79) goto z_bb_34; else goto z_bb_35;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_86 = 0;
    rj = zT_86;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(rj < n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_88 = placed[rj];
    if ((unsigned char)(zT_88 != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_36;
    z_bb_45:
    zT_141 = rj + (unsigned int)(1);
    rj = zT_141;
    goto z_bb_42;
    z_bb_46:
    goto z_bb_45;
    z_bb_47:
    zT_92 = mods.ptr;
    zT_93 = zT_92[ri];
    zT_94 = zT_93.id;
    zT_98 = mods.ptr;
    zT_99 = zT_98[rj];
    zT_100 = zT_99.id;
    zT_102 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_94) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_100);
    cyc_key = zT_102;
    zT_103 = &ctx->module_init_deps;
    zT_104 = cyc_key;
    zT_106 = zF_A05A7BE1_u64ToU32MapGet(zT_103, zT_104);
    zT_107 = zT_106.has_value;
    if (zT_107) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    ref_decl = zT_106.value;
    zT_110 = ctx->store;
    zT_111 = ref_decl;
    zT_113 = zF_FCDD1D35_astStoreNodeAt(zT_110, zT_111);
    cyc_dcl = zT_113;
    zT_115 = "cyclic global initializer dependency";
    zT_117 = 36;
    zT_116.ptr = zT_115;
    zT_116.len = zT_117;
    cyc_msg = zT_116;
    zT_118 = ctx->diag;
    zT_130 = mods.ptr;
    zT_131 = zT_130[ri];
    zT_121 = zT_131.source_file_id;
    zT_122 = cyc_dcl.span_start;
    zT_134 = cyc_dcl.span_start;
    zT_135 = cyc_dcl.span_len;
    zT_124 = cyc_msg;
    zT_138 = zF_C82559AC_diagnosticCollector(zT_118, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3064_CYCLIC_GLOBAL_INIT)), zT_121, zT_122, (unsigned int)(zT_134 + (unsigned int)((unsigned int)zT_135)), zT_124);
    (void)zT_138;
    zT_139 = 1;
    reported = zT_139;
    goto z_bb_44;
    z_bb_49:
    goto z_bb_45;
}

/* errorCodeRegistryFinalize */
void zF_FC691B4D_errorCodeRegistryFi(zT_5AB29387_CompilerContext* ctx) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_0B73C507_ErrorSetPayload* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_0B73C507_ErrorSetPayload zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int* zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_21D3708C_U32ToU32Map* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    int zT_43;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int ti;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload esp;
    unsigned int ei;
    unsigned int mname_id;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ctx->typereg;
    zT_5 = zT_4->types_len;
    if ((unsigned char)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = ctx->typereg;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_46 = 1;
    zT_48 = ti + (unsigned int)((unsigned int)zT_46);
    ti = zT_48;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = ty.payload_idx;
    zT_17 = ctx->typereg;
    zT_18 = zT_17->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_15) >= zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_21 = ctx->typereg;
    zT_22 = zT_21->es_items;
    zT_23 = ty.payload_idx;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    esp = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    ei = zT_28;
    goto z_bb_9;
    z_bb_9:
    zT_29 = esp.tags_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_29))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = ctx->typereg;
    zT_34 = zT_33->xn_items;
    zT_35 = esp.tags_start;
    zT_37 = (unsigned int)((unsigned int)zT_35) + ei;
    zT_38 = zT_34[zT_37];
    mname_id = zT_38;
    zT_39 = &ctx->error_code_registry;
    zT_40 = mname_id;
    zT_42 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_39, zT_40);
    (void)zT_42;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_43 = 1;
    zT_45 = ei + (unsigned int)((unsigned int)zT_43);
    ei = zT_45;
    goto z_bb_9;
}

/* pruneTypeMarkByValue */
void zF_BC6C7740_pruneTypeMarkByValu(zT_21D3708C_U32ToU32Map* ref_edges, zT_338B7C76_TypeRegistry* reg, zT_A4CE86B7_U64ToU32Map* visited, unsigned int src_mid, unsigned int tid) {
    unsigned int zT_5;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_79FAE712_u64 zT_15;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_79FAE712_u64 zT_19;
    zT_D155D06D_Type* zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    unsigned short zT_26;
    unsigned char zT_29;
    unsigned short zT_30;
    zT_21D3708C_U32ToU32Map* zT_32;
    unsigned short zT_37;
    zT_33EF6BFB_TypeKind zT_40;
    zT_406493CE_StructPayload* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_406493CE_StructPayload zT_48;
    unsigned int zT_50;
    unsigned short zT_51;
    zT_21D3708C_U32ToU32Map* zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    zT_A4CE86B7_U64ToU32Map* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_2DF01B61_FieldEntry* zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    zT_2DF01B61_FieldEntry zT_63;
    unsigned int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_54FF90FA_TaggedUnionPayload* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_54FF90FA_TaggedUnionPayload zT_75;
    zT_21D3708C_U32ToU32Map* zT_76;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned short zT_84;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_A4CE86B7_U64ToU32Map* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_2DF01B61_FieldEntry* zT_92;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_2DF01B61_FieldEntry zT_96;
    unsigned int zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    unsigned char zT_104;
    zT_33EF6BFB_TypeKind zT_105;
    zT_AF9231A2_UnionPayload* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_AF9231A2_UnionPayload zT_113;
    zT_21D3708C_U32ToU32Map* zT_114;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_A4CE86B7_U64ToU32Map* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_121;
    unsigned short zT_122;
    zT_21D3708C_U32ToU32Map* zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_A4CE86B7_U64ToU32Map* zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    zT_2DF01B61_FieldEntry* zT_130;
    unsigned int zT_131;
    unsigned int zT_133;
    zT_2DF01B61_FieldEntry zT_134;
    unsigned int zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_457ECFEE_EnumPayload* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_457ECFEE_EnumPayload zT_146;
    zT_21D3708C_U32ToU32Map* zT_147;
    zT_338B7C76_TypeRegistry* zT_148;
    zT_A4CE86B7_U64ToU32Map* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_33EF6BFB_TypeKind zT_153;
    zT_E834303C_ArrayPayload* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_E834303C_ArrayPayload zT_161;
    zT_21D3708C_U32ToU32Map* zT_162;
    zT_338B7C76_TypeRegistry* zT_163;
    zT_A4CE86B7_U64ToU32Map* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_33EF6BFB_TypeKind zT_168;
    zT_666DC2E1_TuplePayload* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_666DC2E1_TuplePayload zT_176;
    unsigned int zT_178;
    unsigned short zT_179;
    zT_21D3708C_U32ToU32Map* zT_182;
    zT_338B7C76_TypeRegistry* zT_183;
    zT_A4CE86B7_U64ToU32Map* zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int* zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_193;
    zT_33EF6BFB_TypeKind zT_194;
    zT_0B10E8E9_OptionalPayload* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_0B10E8E9_OptionalPayload zT_202;
    zT_21D3708C_U32ToU32Map* zT_203;
    zT_338B7C76_TypeRegistry* zT_204;
    zT_A4CE86B7_U64ToU32Map* zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_33EF6BFB_TypeKind zT_209;
    zT_42C2D6BF_EUPayload* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    zT_42C2D6BF_EUPayload zT_217;
    zT_21D3708C_U32ToU32Map* zT_218;
    zT_338B7C76_TypeRegistry* zT_219;
    zT_A4CE86B7_U64ToU32Map* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_21D3708C_U32ToU32Map* zT_224;
    zT_338B7C76_TypeRegistry* zT_225;
    zT_A4CE86B7_U64ToU32Map* zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    zT_79FAE712_u64 vkey;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload p;
    unsigned int fi;
    zT_54FF90FA_TaggedUnionPayload p_1;
    zT_AF9231A2_UnionPayload p_2;
    zT_457ECFEE_EnumPayload p_3;
    zT_E834303C_ArrayPayload p_4;
    zT_666DC2E1_TuplePayload p_5;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload p_6;
    zT_42C2D6BF_EUPayload p_7;
    zT_5 = reg->types_len;
    if ((unsigned char)(tid >= (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)src_mid) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)tid);
    vkey = zT_13;
    zT_14 = visited;
    zT_15 = vkey;
    zT_16 = zF_A05A7BE1_u64ToU32MapGet(zT_14, zT_15);
    zT_17 = zT_16.has_value;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = visited;
    zT_19 = vkey;
    zF_B6EB812C_u64ToU32MapPut(zT_18, zT_19, (unsigned int)(1));
    zT_23 = reg->types_items;
    zT_24 = (unsigned int)tid;
    zT_25 = zT_23[zT_24];
    ty = zT_25;
    zT_26 = ty.module_id;
    if ((unsigned char)(zT_26 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = ty.module_id;
    zT_29 = zT_30 != src_mid;
    goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = ref_edges;
    zT_37 = ty.module_id;
    zF_26476265_u32ToU32MapPut(zT_32, (unsigned int)((unsigned int)(src_mid * (unsigned int)(65536)) + zT_37), (unsigned int)(1));
    goto z_bb_9;
    z_bb_9:
    zT_40 = ty.kind;
    if ((unsigned char)(zT_40 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_45 = reg->st_items;
    zT_46 = ty.payload_idx;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zT_45[zT_47];
    p = zT_48;
    zT_50 = 0;
    fi = zT_50;
    goto z_bb_13;
    z_bb_11:
    return;
    z_bb_12:
    zT_67 = ty.kind;
    if ((unsigned char)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_13:
    zT_51 = p.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_51))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_54 = ref_edges;
    zT_55 = reg;
    zT_56 = visited;
    zT_57 = src_mid;
    zT_59 = reg->fe_items;
    zT_60 = p.fields_start;
    zT_62 = (unsigned int)((unsigned int)zT_60) + fi;
    zT_63 = zT_59[zT_62];
    zT_58 = zT_63.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_54, zT_55, zT_56, zT_57, zT_58);
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_66 = fi + (unsigned int)(1);
    fi = zT_66;
    goto z_bb_13;
    z_bb_17:
    zT_72 = reg->tu_items;
    zT_73 = ty.payload_idx;
    zT_74 = (unsigned int)zT_73;
    zT_75 = zT_72[zT_74];
    p_1 = zT_75;
    zT_76 = ref_edges;
    zT_77 = reg;
    zT_78 = visited;
    zT_79 = src_mid;
    zT_80 = p_1.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_76, zT_77, zT_78, zT_79, zT_80);
    zT_83 = 0;
    fi = zT_83;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_11;
    z_bb_19:
    zT_100 = ty.kind;
    if ((unsigned char)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_25; else goto z_bb_24;
    z_bb_20:
    zT_84 = p_1.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_84))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_87 = ref_edges;
    zT_88 = reg;
    zT_89 = visited;
    zT_90 = src_mid;
    zT_92 = reg->fe_items;
    zT_93 = p_1.fields_start;
    zT_95 = (unsigned int)((unsigned int)zT_93) + fi;
    zT_96 = zT_92[zT_95];
    zT_91 = zT_96.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_87, zT_88, zT_89, zT_90, zT_91);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_99 = fi + (unsigned int)(1);
    fi = zT_99;
    goto z_bb_20;
    z_bb_24:
    zT_105 = ty.kind;
    zT_104 = zT_105 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_26;
    z_bb_25:
    zT_104 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_104) goto z_bb_27; else goto z_bb_29;
    z_bb_27:
    zT_110 = reg->un_items;
    zT_111 = ty.payload_idx;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zT_110[zT_112];
    p_2 = zT_113;
    zT_114 = ref_edges;
    zT_115 = reg;
    zT_116 = visited;
    zT_117 = src_mid;
    zT_118 = p_2.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_114, zT_115, zT_116, zT_117, zT_118);
    zT_121 = 0;
    fi = zT_121;
    goto z_bb_30;
    z_bb_28:
    goto z_bb_18;
    z_bb_29:
    zT_138 = ty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_36;
    z_bb_30:
    zT_122 = p_2.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_122))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_125 = ref_edges;
    zT_126 = reg;
    zT_127 = visited;
    zT_128 = src_mid;
    zT_130 = reg->fe_items;
    zT_131 = p_2.fields_start;
    zT_133 = (unsigned int)((unsigned int)zT_131) + fi;
    zT_134 = zT_130[zT_133];
    zT_129 = zT_134.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_125, zT_126, zT_127, zT_128, zT_129);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_137 = fi + (unsigned int)(1);
    fi = zT_137;
    goto z_bb_30;
    z_bb_34:
    zT_143 = reg->en_items;
    zT_144 = ty.payload_idx;
    zT_145 = (unsigned int)zT_144;
    zT_146 = zT_143[zT_145];
    p_3 = zT_146;
    zT_147 = ref_edges;
    zT_148 = reg;
    zT_149 = visited;
    zT_150 = src_mid;
    zT_151 = p_3.backing_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_147, zT_148, zT_149, zT_150, zT_151);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_28;
    z_bb_36:
    zT_153 = ty.kind;
    if ((unsigned char)(zT_153 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_158 = reg->array_items;
    zT_159 = ty.payload_idx;
    zT_160 = (unsigned int)zT_159;
    zT_161 = zT_158[zT_160];
    p_4 = zT_161;
    zT_162 = ref_edges;
    zT_163 = reg;
    zT_164 = visited;
    zT_165 = src_mid;
    zT_166 = p_4.elem;
    zF_BC6C7740_pruneTypeMarkByValu(zT_162, zT_163, zT_164, zT_165, zT_166);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_168 = ty.kind;
    if ((unsigned char)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_173 = reg->tup_items;
    zT_174 = ty.payload_idx;
    zT_175 = (unsigned int)zT_174;
    zT_176 = zT_173[zT_175];
    p_5 = zT_176;
    zT_178 = 0;
    ei = zT_178;
    goto z_bb_43;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_194 = ty.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_47; else goto z_bb_49;
    z_bb_43:
    zT_179 = p_5.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_179))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_182 = ref_edges;
    zT_183 = reg;
    zT_184 = visited;
    zT_185 = src_mid;
    zT_187 = reg->xt_items;
    zT_188 = p_5.elems_start;
    zT_190 = (unsigned int)((unsigned int)zT_188) + ei;
    zT_186 = zT_187[zT_190];
    zF_BC6C7740_pruneTypeMarkByValu(zT_182, zT_183, zT_184, zT_185, zT_186);
    goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_193 = ei + (unsigned int)(1);
    ei = zT_193;
    goto z_bb_43;
    z_bb_47:
    zT_199 = reg->opt_items;
    zT_200 = ty.payload_idx;
    zT_201 = (unsigned int)zT_200;
    zT_202 = zT_199[zT_201];
    p_6 = zT_202;
    zT_203 = ref_edges;
    zT_204 = reg;
    zT_205 = visited;
    zT_206 = src_mid;
    zT_207 = p_6.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_203, zT_204, zT_205, zT_206, zT_207);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_41;
    z_bb_49:
    zT_209 = ty.kind;
    if ((unsigned char)(zT_209 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_214 = reg->eu_items;
    zT_215 = ty.payload_idx;
    zT_216 = (unsigned int)zT_215;
    zT_217 = zT_214[zT_216];
    p_7 = zT_217;
    zT_218 = ref_edges;
    zT_219 = reg;
    zT_220 = visited;
    zT_221 = src_mid;
    zT_222 = p_7.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_218, zT_219, zT_220, zT_221, zT_222);
    zT_224 = ref_edges;
    zT_225 = reg;
    zT_226 = visited;
    zT_227 = src_mid;
    zT_228 = p_7.error_set;
    zF_BC6C7740_pruneTypeMarkByValu(zT_224, zT_225, zT_226, zT_227, zT_228);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
}

/* moduleIdForBasename */
unsigned int zF_D27A4A01_moduleIdForBasename(zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u base) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_D3EB6303_StringInterner* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry* zT_11;
    zT_6E8D187B_ModuleEntry zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14 = {0};
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned char* zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned char zT_37;
    unsigned char zT_39;
    unsigned int zT_41;
    zT_6E8D187B_ModuleEntry* zT_46;
    zT_6E8D187B_ModuleEntry zT_47;
    unsigned int zT_48;
    unsigned char* zT_49;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_6E8D187B_ModuleEntry* zT_55;
    zT_6E8D187B_ModuleEntry zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u p;
    unsigned int off;
    unsigned char eq;
    unsigned int j;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = interner;
    zT_11 = mods.ptr;
    zT_12 = zT_11[i];
    zT_10 = zT_12.path_id;
    zT_14 = zF_9134020D_stringInternerGet(zT_9, zT_10);
    p = zT_14;
    zT_16 = p.len;
    zT_18 = base.len;
    if ((unsigned char)(zT_16 >= zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_1;
    z_bb_5:
    zT_22 = p.len;
    zT_24 = base.len;
    zT_25 = zT_22 - zT_24;
    off = zT_25;
    zT_27 = 1;
    eq = zT_27;
    zT_29 = 0;
    j = zT_29;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = base.len;
    if ((unsigned char)(j < zT_31)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = p.ptr;
    zT_34 = off + j;
    zT_35 = zT_33[zT_34];
    zT_36 = base.ptr;
    zT_37 = zT_36[j];
    if ((unsigned char)(zT_35 != zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    if ((unsigned char)(eq != (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_41 = j + (unsigned int)(1);
    j = zT_41;
    goto z_bb_7;
    z_bb_11:
    zT_39 = 0;
    eq = zT_39;
    goto z_bb_9;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    if ((unsigned char)(off == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_46 = mods.ptr;
    zT_47 = zT_46[i];
    zT_48 = zT_47.id;
    return zT_48;
    z_bb_16:
    zT_49 = p.ptr;
    zT_51 = off - (unsigned int)(1);
    zT_52 = zT_49[zT_51];
    if ((unsigned char)(zT_52 == (unsigned char)(47))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_55 = mods.ptr;
    zT_56 = zT_55[i];
    zT_57 = zT_56.id;
    return zT_57;
    z_bb_18:
    goto z_bb_14;
}

/* phase_EmissionClassification */
void zF_2682C512_phase_EmissionClass(zT_5AB29387_CompilerContext* ctx) {
    zT_1317DCD6_C89SpellPlan* zT_1;
    zT_3E40CD83_Sand* zT_2;
    unsigned int zT_3;
    zT_69057089_CompilerAlloc* zT_5;
    zT_CA01C129_LirSlotArrayList zT_7;
    zT_7E7544E4_LirStream* zT_9;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_12;
    unsigned int zT_15;
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_7E7544E4_LirStream* zT_20;
    zT_E7714190_LirSlot zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_CA01C129_LirSlotArrayList zT_24;
    zT_E7714190_LirSlot* zT_25;
    zT_E7714190_LirSlot zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_BBC23664_LirFunction zT_29 = {0};
    unsigned int zT_31;
    zT_5D72FBF8_TempDeclArrayList zT_32;
    unsigned int zT_33;
    zT_338B7C76_TypeRegistry* zT_35;
    zT_21D3708C_U32ToU32Map* zT_36;
    unsigned int zT_37;
    zT_786E6CF2_EmissionClassificat* zT_39;
    zT_5D72FBF8_TempDeclArrayList zT_41;
    zT_1937645B_TempDecl* zT_42;
    zT_1937645B_TempDecl zT_43;
    unsigned int zT_46;
    zT_1317DCD6_C89SpellPlan* zT_47;
    zT_3E40CD83_Sand* zT_48;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    zT_BBC23664_LirFunction* zT_51;
    zT_69057089_CompilerAlloc* zT_53;
    zT_CA01C129_LirSlotArrayList zT_56;
    zT_E7714190_LirSlot* zT_57;
    zT_E7714190_LirSlot zT_58;
    unsigned int zT_62;
    zT_7E7544E4_LirStream* zT_63;
    unsigned int zT_66;
    zT_E1A783EF_GlobalDeclArrayList zT_67;
    unsigned int zT_68;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_21D3708C_U32ToU32Map* zT_71;
    unsigned int zT_72;
    zT_786E6CF2_EmissionClassificat* zT_74;
    zT_E1A783EF_GlobalDeclArrayList zT_76;
    zT_54906056_ModuleGlobalDecl* zT_77;
    zT_54906056_ModuleGlobalDecl zT_78;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_786E6CF2_EmissionClassificat* zT_83;
    zT_1317DCD6_C89SpellPlan* zT_86;
    zT_3E40CD83_Sand* zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_69057089_CompilerAlloc* zT_90;
    unsigned int ec_fi;
    zT_BBC23664_LirFunction ec_fn;
    unsigned int ec_hi;
    unsigned int ec_gi;
    zT_1 = &ctx->spell_plan;
    zT_5 = ctx->alloc;
    zT_2 = &zT_5->permanent;
    zT_7 = ctx->lir_slots;
    zT_3 = zT_7.len;
    zF_D67A348C_spellPlanInit(zT_1, zT_2, zT_3);
    zT_9 = &ctx->lir_stream;
    zT_12 = ctx->alloc;
    zT_10 = &zT_12->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_9, zT_10);
    zT_15 = 0;
    ec_fi = zT_15;
    goto z_bb_1;
    z_bb_1:
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    if ((unsigned char)(ec_fi < zT_17)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_20 = &ctx->lir_stream;
    zT_24 = ctx->lir_slots;
    zT_25 = zT_24.items;
    zT_26 = zT_25[ec_fi];
    zT_21 = zT_26;
    zT_27 = ctx->alloc;
    zT_22 = &zT_27->lir_read;
    zT_29 = zF_1B7118E0_lirStreamReadFuncti(zT_20, zT_21, zT_22);
    ec_fn = zT_29;
    zT_31 = 0;
    ec_hi = zT_31;
    goto z_bb_5;
    z_bb_3:
    zT_63 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_63);
    zT_66 = 0;
    ec_gi = zT_66;
    goto z_bb_9;
    z_bb_4:
    zT_62 = ec_fi + (unsigned int)(1);
    ec_fi = zT_62;
    goto z_bb_1;
    z_bb_5:
    zT_32 = ec_fn.hoisted_temps;
    zT_33 = zT_32.len;
    if ((unsigned char)(ec_hi < zT_33)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_35 = ctx->typereg;
    zT_39 = &ctx->emission_classif;
    zT_36 = &zT_39->needed_tuple_set;
    zT_41 = ec_fn.hoisted_temps;
    zT_42 = zT_41.items;
    zT_43 = zT_42[ec_hi];
    zT_37 = zT_43.type_id;
    zF_7845A68F_collectNeededTuples(zT_35, zT_36, zT_37);
    goto z_bb_8;
    z_bb_7:
    zT_47 = &ctx->spell_plan;
    zT_53 = ctx->alloc;
    zT_48 = &zT_53->permanent;
    zT_49 = ctx->typereg;
    zT_56 = ctx->lir_slots;
    zT_57 = zT_56.items;
    zT_58 = zT_57[ec_fi];
    zT_50 = zT_58.disk_offset;
    zT_51 = &ec_fn;
    zF_72205F3D_spellPlanPlanFn(zT_47, zT_48, zT_49, zT_50, zT_51);
    goto z_bb_4;
    z_bb_8:
    zT_46 = ec_hi + (unsigned int)(1);
    ec_hi = zT_46;
    goto z_bb_5;
    z_bb_9:
    zT_67 = ctx->global_decls;
    zT_68 = zT_67.len;
    if ((unsigned char)(ec_gi < zT_68)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_70 = ctx->typereg;
    zT_74 = &ctx->emission_classif;
    zT_71 = &zT_74->needed_tuple_set;
    zT_76 = ctx->global_decls;
    zT_77 = zT_76.items;
    zT_78 = zT_77[ec_gi];
    zT_72 = zT_78.type_id;
    zF_7845A68F_collectNeededTuples(zT_70, zT_71, zT_72);
    goto z_bb_12;
    z_bb_11:
    zT_82 = ctx->typereg;
    zT_83 = &ctx->emission_classif;
    zF_0DE160E2_classifyTypeEmissio(zT_82, zT_83);
    zT_86 = &ctx->spell_plan;
    zT_90 = ctx->alloc;
    zT_87 = &zT_90->permanent;
    zT_88 = ctx->typereg;
    zF_869C84A7_spellPlanPlanTypeOr(zT_86, zT_87, zT_88);
    return;
    z_bb_12:
    zT_81 = ec_gi + (unsigned int)(1);
    ec_gi = zT_81;
    goto z_bb_9;
}

/* phase_C89Emission */
void zF_2268F8CE_phase_C89Emission(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_C98AF326_CompilerCli zT_6;
    unsigned char zT_7;
    unsigned char zT_9;
    zT_C98AF326_CompilerCli zT_10;
    unsigned char zT_11;
    zT_CEC2984A_NameMangler zT_14 = {0};
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_E1A783EF_GlobalDeclArrayList zT_18;
    unsigned int zT_19;
    zT_786E6CF2_EmissionClassificat zT_21;
    zT_21D3708C_U32ToU32Map zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    zT_D3EB6303_StringInterner* zT_27;
    zT_3E40CD83_Sand* zT_28;
    unsigned int zT_29;
    zT_69057089_CompilerAlloc* zT_31;
    zT_CEC2984A_NameMangler zT_33 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_34;
    zT_EFA81450_Opt_322 zT_35;
    zT_72C4E2ED_C89Emitter zT_37 = {0};
    zT_338B7C76_TypeRegistry* zT_38;
    zT_D3EB6303_StringInterner* zT_39;
    zT_CEC2984A_NameMangler* zT_40;
    zT_F85C5DED_DiagnosticCollector* zT_41;
    zT_9F514E82_SwitchCaseArrayList* zT_42;
    zT_B687BB96_U32ArrayList* zT_43;
    zT_3E40CD83_Sand* zT_44;
    zT_3E40CD83_Sand* zT_45;
    zT_21D3708C_U32ToU32Map* zT_46;
    zT_786E6CF2_EmissionClassificat* zT_47;
    zT_1317DCD6_C89SpellPlan* zT_48;
    unsigned char zT_49;
    int zT_54;
    int zT_55;
    zT_69057089_CompilerAlloc* zT_56;
    zT_69057089_CompilerAlloc* zT_58;
    zT_C98AF326_CompilerCli zT_63;
    zT_72C4E2ED_C89Emitter zT_65 = {0};
    zT_072B53A6_ModuleRegistry* zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_71;
    zT_D3EB6303_StringInterner* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_072B53A6_ModuleRegistry* zT_74;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_76 = {0};
    unsigned int zT_78 = 0;
    zT_5AB29387_CompilerContext* zT_79;
    zT_E1A783EF_GlobalDeclArrayList* zT_81;
    zT_23133B1E_Slice_zT_54906056_M zT_83 = {0};
    zT_54906056_ModuleGlobalDecl* zT_85;
    unsigned int zT_87;
    zT_B687BB96_U32ArrayList zT_89;
    unsigned int* zT_90;
    zT_B687BB96_U32ArrayList zT_91;
    unsigned int zT_92;
    zT_7E7544E4_LirStream* zT_93;
    zT_CA01C129_LirSlotArrayList zT_94;
    zT_E7714190_LirSlot* zT_95;
    zT_CA01C129_LirSlotArrayList zT_97;
    unsigned int zT_98;
    zT_69057089_CompilerAlloc* zT_99;
    zT_3E40CD83_Sand* zT_100;
    zT_7E7544E4_LirStream* zT_101;
    zT_3E40CD83_Sand* zT_102;
    zT_69057089_CompilerAlloc* zT_104;
    unsigned char* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    zT_3E40CD83_Sand* zT_111;
    zT_69057089_CompilerAlloc* zT_112;
    zT_21D3708C_U32ToU32Map zT_114 = {0};
    zT_3E40CD83_Sand* zT_116;
    unsigned int zT_117;
    zT_69057089_CompilerAlloc* zT_118;
    zT_CA01C129_LirSlotArrayList zT_120;
    zT_21D3708C_U32ToU32Map zT_122 = {0};
    zT_3E40CD83_Sand* zT_124;
    zT_69057089_CompilerAlloc* zT_125;
    zT_A4CE86B7_U64ToU32Map zT_127 = {0};
    unsigned int zT_129;
    zT_CA01C129_LirSlotArrayList zT_130;
    unsigned int zT_131;
    zT_7E7544E4_LirStream* zT_134;
    zT_E7714190_LirSlot zT_135;
    zT_3E40CD83_Sand* zT_136;
    zT_CA01C129_LirSlotArrayList zT_138;
    zT_E7714190_LirSlot* zT_139;
    zT_E7714190_LirSlot zT_140;
    zT_69057089_CompilerAlloc* zT_141;
    zT_BBC23664_LirFunction zT_143 = {0};
    unsigned int zT_145;
    unsigned int zT_147;
    zT_5D72FBF8_TempDeclArrayList zT_148;
    unsigned int zT_149;
    zT_5D72FBF8_TempDeclArrayList zT_152;
    zT_1937645B_TempDecl* zT_153;
    zT_1937645B_TempDecl zT_154;
    zT_21D3708C_U32ToU32Map* zT_155;
    zT_338B7C76_TypeRegistry* zT_156;
    zT_A4CE86B7_U64ToU32Map* zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_338B7C76_TypeRegistry* zT_167;
    unsigned int zT_168;
    zT_21D3708C_U32ToU32Map* zT_171;
    zT_338B7C76_TypeRegistry* zT_172;
    zT_A4CE86B7_U64ToU32Map* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_181;
    zT_CFE23D0A_LirParamArrayList zT_182;
    unsigned int zT_183;
    zT_CFE23D0A_LirParamArrayList zT_186;
    zT_8779209D_LirParam* zT_187;
    zT_8779209D_LirParam zT_188;
    zT_21D3708C_U32ToU32Map* zT_189;
    zT_338B7C76_TypeRegistry* zT_190;
    zT_A4CE86B7_U64ToU32Map* zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_199;
    unsigned int zT_201;
    zT_1CF28CA3_BasicBlockArrayList zT_202;
    unsigned int zT_203;
    zT_1CF28CA3_BasicBlockArrayList zT_206;
    zT_88A68B1A_BasicBlock* zT_207;
    zT_88A68B1A_BasicBlock zT_208;
    unsigned int zT_210;
    zT_DAE4631D_LirInstArrayList zT_211;
    unsigned int zT_212;
    zT_DAE4631D_LirInstArrayList zT_215;
    zT_6BA597BC_LirInst* zT_216;
    zT_6BA597BC_LirInst zT_217;
    unsigned int zT_219;
    unsigned char zT_221;
    unsigned int zT_223;
    zT_6BA597BC_LirInst zT_226;
    zT_BBC23664_LirFunction* zT_229;
    unsigned int zT_230;
    zT_3BFB1E70_CallDirectData zT_234 = {0};
    unsigned int zT_235;
    unsigned char zT_236;
    zT_6BA597BC_LirInst zT_239;
    zT_BBC23664_LirFunction* zT_242;
    unsigned int zT_243;
    zT_0624AC1B_TailCallData zT_247 = {0};
    unsigned int zT_248;
    unsigned char zT_249;
    zT_6BA597BC_LirInst zT_252;
    zT_EE92EDE9_anon_105256 zT_255;
    unsigned int zT_256;
    unsigned char zT_257;
    zT_6BA597BC_LirInst zT_260;
    zT_62D66EC3_anon_105438 zT_263;
    unsigned int zT_264;
    unsigned char zT_265;
    zT_6BA597BC_LirInst zT_268;
    zT_6ED8C03E_anon_105446 zT_271;
    unsigned int zT_272;
    unsigned char zT_273;
    unsigned char zT_276;
    zT_21D3708C_U32ToU32Map* zT_278;
    zT_6BA597BC_LirInst zT_288;
    unsigned char zT_290;
    unsigned int zT_291;
    unsigned int zT_294;
    zT_21D3708C_U32ToU32Map* zT_296;
    unsigned int zT_302;
    zT_6BA597BC_LirInst zT_307;
    unsigned char zT_309;
    zT_6BA597BC_LirInst zT_312;
    unsigned int zT_315;
    unsigned int zT_317;
    zT_6BA597BC_LirInst zT_320;
    zT_62D66EC3_anon_105438 zT_323;
    unsigned int zT_324;
    zT_62D66EC3_anon_105438 zT_326;
    unsigned int zT_327;
    zT_6ED8C03E_anon_105446 zT_329;
    unsigned int zT_330;
    zT_6ED8C03E_anon_105446 zT_332;
    unsigned int zT_333;
    unsigned int zT_335;
    unsigned int zT_337;
    zT_5D72FBF8_TempDeclArrayList zT_338;
    unsigned int zT_339;
    zT_5D72FBF8_TempDeclArrayList zT_342;
    zT_1937645B_TempDecl* zT_343;
    zT_1937645B_TempDecl zT_344;
    unsigned int zT_345;
    unsigned int zT_347;
    unsigned int zT_349;
    zT_338B7C76_TypeRegistry* zT_350;
    unsigned int zT_351;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_D155D06D_Type* zT_356;
    unsigned int zT_357;
    zT_D155D06D_Type zT_358;
    unsigned int zT_359;
    unsigned char zT_362;
    unsigned int zT_363;
    zT_21D3708C_U32ToU32Map* zT_365;
    unsigned int zT_366;
    unsigned int zT_371;
    unsigned int zT_373;
    unsigned int zT_375;
    zT_072B53A6_ModuleRegistry* zT_377;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_379 = {0};
    unsigned int zT_381;
    zT_E1A783EF_GlobalDeclArrayList zT_382;
    unsigned int zT_383;
    zT_E1A783EF_GlobalDeclArrayList zT_386;
    zT_54906056_ModuleGlobalDecl* zT_387;
    zT_54906056_ModuleGlobalDecl zT_388;
    unsigned int zT_389;
    zT_338B7C76_TypeRegistry* zT_390;
    unsigned int zT_391;
    zT_338B7C76_TypeRegistry* zT_395;
    zT_D155D06D_Type* zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    zT_D155D06D_Type zT_399;
    unsigned int zT_400;
    unsigned char zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    zT_21D3708C_U32ToU32Map* zT_407;
    zT_338B7C76_TypeRegistry* zT_408;
    zT_A4CE86B7_U64ToU32Map* zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned int zT_418;
    zT_3E40CD83_Sand* zT_420;
    unsigned int zT_421;
    zT_69057089_CompilerAlloc* zT_422;
    zT_21D3708C_U32ToU32Map zT_426 = {0};
    zT_21D3708C_U32ToU32Map* zT_427;
    unsigned char zT_434;
    unsigned char zT_437;
    unsigned int zT_439;
    unsigned int zT_441;
    zT_6E8D187B_ModuleEntry* zT_444;
    zT_6E8D187B_ModuleEntry zT_445;
    unsigned int zT_446;
    zT_21D3708C_U32ToU32Map* zT_447;
    unsigned int zT_448;
    zT_BAEE192E_Opt_10 zT_450 = {0};
    unsigned char zT_451;
    unsigned int zT_454;
    unsigned int zT_456;
    zT_6E8D187B_ModuleEntry* zT_459;
    zT_6E8D187B_ModuleEntry zT_460;
    unsigned int zT_461;
    zT_21D3708C_U32ToU32Map* zT_463;
    unsigned int zT_464;
    zT_BAEE192E_Opt_10 zT_466 = {0};
    unsigned char zT_467;
    zT_21D3708C_U32ToU32Map* zT_468;
    zT_BAEE192E_Opt_10 zT_474 = {0};
    unsigned char zT_475;
    zT_21D3708C_U32ToU32Map* zT_476;
    unsigned int zT_477;
    unsigned char zT_481;
    unsigned int zT_483;
    unsigned int zT_485;
    unsigned int zT_487;
    unsigned int zT_489;
    zT_6E8D187B_ModuleEntry* zT_491;
    zT_6E8D187B_ModuleEntry zT_492;
    unsigned int zT_493;
    zT_21D3708C_U32ToU32Map* zT_496;
    unsigned int zT_497;
    zT_6E8D187B_ModuleEntry* zT_499;
    zT_6E8D187B_ModuleEntry zT_500;
    zT_BAEE192E_Opt_10 zT_502 = {0};
    unsigned char zT_503;
    unsigned char zT_506;
    unsigned int zT_508;
    zT_E1A783EF_GlobalDeclArrayList zT_509;
    unsigned int zT_510;
    zT_E1A783EF_GlobalDeclArrayList zT_513;
    zT_54906056_ModuleGlobalDecl* zT_514;
    zT_54906056_ModuleGlobalDecl zT_515;
    unsigned int zT_516;
    zT_6E8D187B_ModuleEntry* zT_517;
    zT_6E8D187B_ModuleEntry zT_518;
    unsigned int zT_519;
    unsigned char zT_521;
    unsigned char zT_522;
    unsigned char zT_525;
    unsigned int zT_527;
    zT_21D3708C_U32ToU32Map* zT_530;
    zT_6E8D187B_ModuleEntry* zT_537;
    zT_6E8D187B_ModuleEntry zT_538;
    unsigned int zT_539;
    unsigned int zT_543;
    zT_C98AF326_CompilerCli zT_544;
    unsigned char zT_545;
    zT_1317DCD6_C89SpellPlan zT_547;
    unsigned int* zT_548;
    zT_846744CC_Arr_unsigned_char_5 zT_550;
    unsigned int zT_552;
    zT_C98AF326_CompilerCli zT_554;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_555;
    zT_72C4E2ED_C89Emitter* zT_556;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_557;
    unsigned int zT_560;
    unsigned int zT_562;
    unsigned char zT_564;
    unsigned char* zT_567;
    unsigned char zT_568;
    int zT_569;
    unsigned int zT_571;
    int zT_572;
    unsigned int zT_574;
    unsigned char zT_575;
    int zT_576;
    unsigned int zT_578;
    unsigned char* zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned int zT_582;
    unsigned int zT_584;
    unsigned int zT_586;
    unsigned char zT_588;
    unsigned char* zT_591;
    unsigned char zT_592;
    int zT_593;
    unsigned int zT_595;
    int zT_596;
    unsigned int zT_598;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_600;
    int zT_604;
    unsigned char* zT_605;
    unsigned int zT_606;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_607;
    unsigned int zT_609 = 0;
    unsigned char* zT_613;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_614;
    unsigned int zT_615;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_616;
    zT_63BE4FF5_BufferedWriter zT_620 = {0};
    unsigned int zT_621;
    zT_63BE4FF5_BufferedWriter zT_622 = {0};
    zT_72C4E2ED_C89Emitter* zT_623;
    zT_338B7C76_TypeRegistry* zT_624;
    unsigned int* zT_625;
    zT_63BE4FF5_BufferedWriter* zT_628;
    zT_72C4E2ED_C89Emitter* zT_629;
    unsigned int zT_631;
    zT_072B53A6_ModuleRegistry* zT_633;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_635 = {0};
    zT_CA01C129_LirSlotArrayList zT_638;
    unsigned int zT_639;
    int zT_640;
    zT_3E40CD83_Sand* zT_643;
    zT_69057089_CompilerAlloc* zT_646;
    unsigned int zT_650;
    zT_2AAC3D00_EU_642 zT_653 = {0};
    unsigned char zT_654;
    unsigned char* zT_655;
    unsigned int* zT_657;
    zT_3E40CD83_Sand* zT_659;
    zT_69057089_CompilerAlloc* zT_662;
    unsigned int zT_666;
    zT_2AAC3D00_EU_642 zT_669 = {0};
    unsigned char zT_670;
    unsigned char* zT_671;
    unsigned int* zT_673;
    unsigned int zT_675;
    unsigned int zT_677;
    unsigned int zT_679;
    int zT_680;
    unsigned int zT_682;
    unsigned int zT_684;
    zT_CA01C129_LirSlotArrayList zT_687;
    zT_E7714190_LirSlot* zT_688;
    zT_E7714190_LirSlot zT_689;
    unsigned int zT_690;
    unsigned int zT_693;
    unsigned int zT_695;
    unsigned int zT_696;
    unsigned int zT_698;
    unsigned int zT_699;
    int zT_700;
    unsigned int zT_702;
    unsigned int zT_704;
    unsigned int zT_705;
    unsigned int zT_707;
    unsigned int zT_709;
    unsigned int zT_710;
    int zT_711;
    unsigned int zT_713;
    zT_3E40CD83_Sand* zT_715;
    zT_69057089_CompilerAlloc* zT_718;
    zT_2AAC3D00_EU_642 zT_723 = {0};
    unsigned char zT_724;
    unsigned char* zT_725;
    zT_E7714190_LirSlot* zT_727;
    unsigned int zT_728;
    zT_CA01C129_LirSlotArrayList zT_731;
    zT_E7714190_LirSlot* zT_732;
    zT_E7714190_LirSlot zT_733;
    unsigned int zT_735;
    unsigned int zT_738;
    unsigned int zT_741;
    unsigned int zT_742;
    unsigned int zT_743;
    unsigned int zT_745;
    unsigned int zT_746;
    int zT_747;
    unsigned int zT_749;
    zT_CA01C129_LirSlotArrayList* zT_750;
    zT_CA01C129_LirSlotArrayList* zT_752;
    unsigned int zT_754;
    unsigned int zT_756;
    unsigned int zT_758;
    zT_6E8D187B_ModuleEntry* zT_761;
    zT_6E8D187B_ModuleEntry zT_762;
    zT_CA01C129_LirSlotArrayList zT_764;
    unsigned int zT_765;
    unsigned char zT_767;
    zT_CA01C129_LirSlotArrayList zT_768;
    zT_E7714190_LirSlot* zT_769;
    zT_E7714190_LirSlot zT_770;
    unsigned int zT_771;
    unsigned int zT_772;
    unsigned int zT_775;
    zT_21D3708C_U32ToU32Map* zT_776;
    unsigned int zT_777;
    zT_BAEE192E_Opt_10 zT_780 = {0};
    unsigned char zT_781;
    zT_72C4E2ED_C89Emitter* zT_785;
    unsigned int zT_786;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_789 = {0};
    unsigned int zT_791;
    unsigned int zT_795;
    unsigned char* zT_802;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_803;
    unsigned int zT_804;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_805;
    unsigned int zT_809;
    unsigned int zT_811;
    unsigned int zT_813;
    unsigned char zT_815;
    unsigned char* zT_818;
    unsigned char zT_819;
    int zT_820;
    unsigned int zT_822;
    int zT_823;
    unsigned int zT_825;
    unsigned char zT_826;
    int zT_827;
    unsigned int zT_829;
    unsigned int zT_831;
    unsigned int zT_833;
    unsigned char zT_835;
    unsigned char* zT_838;
    unsigned char zT_839;
    int zT_840;
    unsigned int zT_842;
    int zT_843;
    unsigned int zT_845;
    unsigned char* zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    unsigned int zT_849;
    unsigned int zT_851;
    unsigned int zT_853;
    unsigned char zT_855;
    unsigned char* zT_858;
    unsigned char zT_859;
    int zT_860;
    unsigned int zT_862;
    int zT_863;
    unsigned int zT_865;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_867;
    int zT_871;
    unsigned char* zT_872;
    unsigned int zT_873;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_874;
    unsigned int zT_876 = 0;
    unsigned char* zT_880;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_881;
    unsigned int zT_882;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_883;
    zT_63BE4FF5_BufferedWriter zT_887 = {0};
    unsigned int zT_888;
    zT_63BE4FF5_BufferedWriter zT_889 = {0};
    unsigned int zT_891;
    unsigned int zT_892;
    unsigned int zT_894;
    unsigned int zT_896;
    zT_072B53A6_ModuleRegistry* zT_898;
    unsigned int* zT_899;
    unsigned int* zT_900;
    unsigned int zT_901;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_902;
    zT_B687BB96_U32ArrayList zT_904;
    unsigned int* zT_905;
    zT_B687BB96_U32ArrayList zT_906;
    unsigned int zT_907;
    int zT_908;
    unsigned int* zT_909;
    unsigned int zT_910;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_911;
    zT_3E40CD83_Sand* zT_913;
    zT_69057089_CompilerAlloc* zT_916;
    unsigned int zT_920;
    zT_2AAC3D00_EU_642 zT_923 = {0};
    unsigned char zT_924;
    unsigned char* zT_925;
    unsigned int* zT_928;
    unsigned int zT_930;
    unsigned int zT_932;
    unsigned int zT_934;
    unsigned int* zT_937;
    unsigned int zT_938;
    unsigned int zT_939;
    zT_21D3708C_U32ToU32Map* zT_941;
    unsigned int zT_942;
    zT_BAEE192E_Opt_10 zT_944 = {0};
    unsigned char zT_945;
    unsigned char zT_948;
    unsigned int zT_950;
    unsigned int zT_952;
    unsigned char zT_954;
    unsigned int zT_956;
    unsigned int zT_960;
    unsigned int zT_962;
    unsigned int zT_964;
    unsigned int zT_966;
    zT_6E8D187B_ModuleEntry* zT_969;
    zT_6E8D187B_ModuleEntry zT_970;
    unsigned int zT_971;
    unsigned int zT_972;
    zT_21D3708C_U32ToU32Map* zT_974;
    unsigned int zT_975;
    zT_BAEE192E_Opt_10 zT_977 = {0};
    unsigned char zT_978;
    zT_21D3708C_U32ToU32Map* zT_980;
    unsigned int zT_983;
    zT_BAEE192E_Opt_10 zT_987 = {0};
    unsigned char zT_988;
    unsigned char zT_991;
    unsigned int zT_993;
    unsigned int zT_995;
    unsigned char zT_997;
    unsigned int zT_999;
    unsigned int zT_1003;
    unsigned int zT_1005;
    int zT_1007;
    unsigned int* zT_1008;
    unsigned int zT_1009;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1010;
    zT_72C4E2ED_C89Emitter* zT_1011;
    unsigned int zT_1012;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1013;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1014;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1015;
    unsigned int* zT_1016;
    zT_63BE4FF5_BufferedWriter* zT_1019;
    zT_72C4E2ED_C89Emitter* zT_1020;
    unsigned int zT_1022;
    unsigned char* zT_1024;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1025;
    unsigned int zT_1026;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1027;
    zT_846744CC_Arr_unsigned_char_5 zT_1029;
    unsigned int zT_1031;
    unsigned int zT_1033;
    unsigned int zT_1035;
    unsigned char zT_1037;
    unsigned char* zT_1040;
    unsigned char zT_1041;
    int zT_1042;
    unsigned int zT_1044;
    int zT_1045;
    unsigned int zT_1047;
    unsigned char zT_1048;
    int zT_1049;
    unsigned int zT_1051;
    unsigned int zT_1053;
    unsigned int zT_1055;
    unsigned char zT_1057;
    unsigned char* zT_1060;
    unsigned char zT_1061;
    int zT_1062;
    unsigned int zT_1064;
    int zT_1065;
    unsigned int zT_1067;
    unsigned char* zT_1069;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1070;
    unsigned int zT_1071;
    unsigned int zT_1073;
    unsigned int zT_1075;
    unsigned char zT_1077;
    unsigned char* zT_1080;
    unsigned char zT_1081;
    int zT_1082;
    unsigned int zT_1084;
    int zT_1085;
    unsigned int zT_1087;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1089;
    int zT_1093;
    unsigned char* zT_1094;
    unsigned int zT_1095;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1096;
    unsigned int zT_1098 = 0;
    unsigned char* zT_1102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1103;
    unsigned int zT_1104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1105;
    zT_63BE4FF5_BufferedWriter zT_1109 = {0};
    unsigned int zT_1110;
    zT_63BE4FF5_BufferedWriter zT_1111 = {0};
    zT_72C4E2ED_C89Emitter* zT_1112;
    unsigned int zT_1113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1114;
    zT_63BE4FF5_BufferedWriter* zT_1117;
    zT_72C4E2ED_C89Emitter* zT_1118;
    unsigned int zT_1120;
    unsigned char* zT_1122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1123;
    unsigned int zT_1124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1125;
    int zT_1126;
    unsigned int zT_1128;
    zT_72C4E2ED_C89Emitter* zT_1129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1130;
    unsigned char zT_1131;
    zT_074080EA_WinProfile zT_1132;
    zT_C98AF326_CompilerCli zT_1134;
    zT_C98AF326_CompilerCli zT_1136;
    zT_7E7544E4_LirStream* zT_1138;
    zT_6B0A7D14_AstStore* zT_1140;
    zT_63BE4FF5_BufferedWriter zT_1143 = {0};
    zT_63BE4FF5_BufferedWriter zT_1144 = {0};
    zT_63BE4FF5_BufferedWriter* zT_1145;
    zT_63BE4FF5_BufferedWriter* zT_1147;
    zT_072B53A6_ModuleRegistry* zT_1150;
    zT_3E40CD83_Sand* zT_1151;
    zT_69057089_CompilerAlloc* zT_1153;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1155 = {0};
    zT_72C4E2ED_C89Emitter* zT_1156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1157;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1158;
    unsigned char* zT_1161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1162;
    unsigned int zT_1163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1164;
    zT_63BE4FF5_BufferedWriter* zT_1165;
    zT_72C4E2ED_C89Emitter* zT_1166;
    zT_7E7544E4_LirStream* zT_1168;
    zT_6B0A7D14_AstStore* zT_1170;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_CEC2984A_NameMangler mangler;
    unsigned int mangler_hint;
    zT_72C4E2ED_C89Emitter emitter;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_23133B1E_Slice_zT_54906056_M gd_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u module_name;
    zT_21D3708C_U32ToU32Map ts_ref_set;
    zT_21D3708C_U32ToU32Map ref_edges;
    zT_A4CE86B7_U64ToU32Map type_visited;
    unsigned int ts_fi;
    zT_BBC23664_LirFunction ts_fn;
    unsigned int ts_src;
    unsigned int ts_tti;
    zT_DDCD424B_Slice_zT_6E8D187B_M ri_mods;
    unsigned int gt_i;
    zT_1937645B_TempDecl ts_hty;
    unsigned int ts_pi;
    zT_8779209D_LirParam ts_pt;
    unsigned int ts_bi;
    zT_88A68B1A_BasicBlock ts_blk;
    unsigned int ts_ii;
    zT_6BA597BC_LirInst ts_inst;
    unsigned int ts_tg;
    unsigned char ts_edge_has;
    unsigned int ts_edge_dst;
    zT_3BFB1E70_CallDirectData ts_cd;
    zT_0624AC1B_TailCallData ts_tc;
    unsigned int ts_name_id;
    unsigned int ts_tmp;
    unsigned int ts_tid;
    unsigned int ts_tj;
    zT_1937645B_TempDecl ts_ht;
    zT_D155D06D_Type ts_ty;
    zT_54906056_ModuleGlobalDecl gt_g;
    zT_21D3708C_U32ToU32Map reachable;
    unsigned char rf_changed;
    zT_D155D06D_Type gt_ty;
    unsigned int rf_s;
    unsigned int ri_i;
    unsigned int rf_src;
    unsigned int rf_d;
    unsigned int rf_dst;
    unsigned char ri_has;
    unsigned int gd_ri;
    zT_54906056_ModuleGlobalDecl gd_g;
    unsigned int* sorted;
    zT_846744CC_Arr_unsigned_char_5 hpath;
    unsigned int hp;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int hi;
    zT_63BE4FF5_BufferedWriter cwriter;
    zT_3CB0179A_Slice_zT_05F374B1_u c_incs;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u hfn;
    unsigned int hfi;
    unsigned int fd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_63BE4FF5_BufferedWriter hw;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int slot_count;
    unsigned int* grp_counts;
    unsigned int fn_cursor;
    unsigned int mi;
    unsigned int* grp_cursor;
    unsigned int gci;
    unsigned int gsi;
    unsigned int gsmid;
    unsigned int gacc;
    zT_E7714190_LirSlot* grouped;
    zT_E7714190_LirSlot gslot;
    unsigned int gdst;
    zT_6E8D187B_ModuleEntry m;
    unsigned int fn_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    unsigned int hp2;
    unsigned int hi2;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hext;
    unsigned int hx;
    unsigned int fd2;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg2;
    zT_63BE4FF5_BufferedWriter hw2;
    unsigned int dep_start;
    unsigned int dep_end;
    zT_3CB0179A_Slice_zT_05F374B1_u dep_ids;
    zT_3CB0179A_Slice_zT_05F374B1_u m_c_incs;
    unsigned char* inc_raw;
    unsigned int* inc_arr;
    unsigned int inc_n;
    unsigned int di0;
    unsigned int dd0;
    unsigned int vd0;
    unsigned char dup0;
    unsigned int dj0;
    unsigned int vdd0;
    zT_3CB0179A_Slice_zT_05F374B1_u inc_slice;
    zT_846744CC_Arr_unsigned_char_5 cpath;
    unsigned int cp2;
    unsigned int ci2;
    unsigned char dup1;
    unsigned int dj1;
    unsigned int cbi;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    unsigned int cx;
    unsigned int cfd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg3;
    zT_63BE4FF5_BufferedWriter cw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2_m;
    zT_2 = "C\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->cli;
    zT_7 = zT_6.dump_c89;
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = ctx->cli;
    zT_11 = zT_10.output_dir_set;
    zT_9 = !zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_9 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    mangler = zT_14;
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    zT_18 = ctx->global_decls;
    zT_19 = zT_18.len;
    zT_21 = ctx->emission_classif;
    zT_22 = zT_21.pointer_only_map;
    zT_23 = zT_22.count;
    zT_26 = (unsigned int)((unsigned int)(zT_17 + zT_19) + zT_23) + (unsigned int)(32);
    mangler_hint = zT_26;
    zT_27 = ctx->interner;
    zT_31 = ctx->alloc;
    zT_28 = &zT_31->emission;
    zT_29 = mangler_hint;
    zT_33 = zF_27DA3900_nameManglerInit(zT_27, zT_28, zT_29);
    mangler = zT_33;
    zT_34 = &ctx->exported;
    zT_35.has_value = 1;
    zT_35.value = zT_34;
    mangler.exported = zT_35;
    emitter = zT_37;
    zT_38 = ctx->typereg;
    zT_39 = ctx->interner;
    zT_40 = &mangler;
    zT_41 = ctx->diag;
    zT_54 = 0;
    zT_42 = (zT_9F514E82_SwitchCaseArrayList*)zT_54;
    zT_55 = 0;
    zT_43 = (zT_B687BB96_U32ArrayList*)zT_55;
    zT_56 = ctx->alloc;
    zT_44 = &zT_56->scratch;
    zT_58 = ctx->alloc;
    zT_45 = &zT_58->emission;
    zT_46 = &ctx->error_code_registry;
    zT_47 = &ctx->emission_classif;
    zT_48 = &ctx->spell_plan;
    zT_63 = ctx->cli;
    zT_49 = zT_63.safe_checks;
    zT_65 = zF_63D58A2B_c89EmitterInit(zT_38, zT_39, zT_40, zT_41, zT_42, zT_43, zT_44, zT_45, zT_46, zT_47, zT_48, zT_49);
    emitter = zT_65;
    zT_66 = ctx->module_reg;
    emitter.module_reg = zT_66;
    zT_68 = "std_fmt.zig";
    zT_70 = 11;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    c89_fmt_base = zT_69;
    zT_74 = ctx->module_reg;
    zT_76 = zF_3452C137_moduleRegistryGetMo(zT_74);
    zT_71 = zT_76;
    zT_72 = ctx->interner;
    zT_73 = c89_fmt_base;
    zT_78 = zF_D27A4A01_moduleIdForBasename(zT_71, zT_72, zT_73);
    emitter.std_fmt_module_id = zT_78;
    zT_79 = ctx;
    zF_FC691B4D_errorCodeRegistryFi(zT_79);
    zT_81 = &ctx->global_decls;
    zT_83 = zF_6ACCE52D_globalDeclArrayList(zT_81);
    gd_slice = zT_83;
    zT_85 = gd_slice.ptr;
    emitter.global_decls = zT_85;
    zT_87 = gd_slice.len;
    emitter.global_decls_len = (unsigned int)((unsigned int)zT_87);
    zT_89 = ctx->module_init_order;
    zT_90 = zT_89.items;
    emitter.module_init_order = zT_90;
    zT_91 = ctx->module_init_order;
    zT_92 = zT_91.len;
    emitter.module_init_order_len = zT_92;
    zT_93 = &ctx->lir_stream;
    emitter.spill = zT_93;
    zT_94 = ctx->lir_slots;
    zT_95 = zT_94.items;
    emitter.fn_slots = zT_95;
    emitter.fn_slots_start = (unsigned int)(0);
    zT_97 = ctx->lir_slots;
    zT_98 = zT_97.len;
    emitter.fn_slots_len = zT_98;
    zT_99 = ctx->alloc;
    zT_100 = &zT_99->lir_read;
    emitter.spill_arena = zT_100;
    zT_101 = &ctx->lir_stream;
    zT_104 = ctx->alloc;
    zT_102 = &zT_104->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_101, zT_102);
    zT_107 = "output";
    zT_109 = 6;
    zT_108.ptr = zT_107;
    zT_108.len = zT_109;
    module_name = zT_108;
    zT_112 = ctx->alloc;
    zT_111 = &zT_112->emission;
    zT_114 = zF_58BDA2DE_u32ToU32MapInit(zT_111);
    ts_ref_set = zT_114;
    zT_118 = ctx->alloc;
    zT_116 = &zT_118->emission;
    zT_120 = ctx->lir_slots;
    zT_117 = zT_120.len;
    zT_122 = zF_619D56E6_u32ToU32MapInitCap(zT_116, zT_117);
    ref_edges = zT_122;
    zT_125 = ctx->alloc;
    zT_124 = &zT_125->emission;
    zT_127 = zF_986226E1_u64ToU32MapInit(zT_124);
    type_visited = zT_127;
    zT_129 = 0;
    ts_fi = zT_129;
    goto z_bb_6;
    z_bb_6:
    zT_130 = ctx->lir_slots;
    zT_131 = zT_130.len;
    if ((unsigned char)(ts_fi < zT_131)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_134 = &ctx->lir_stream;
    zT_138 = ctx->lir_slots;
    zT_139 = zT_138.items;
    zT_140 = zT_139[ts_fi];
    zT_135 = zT_140;
    zT_141 = ctx->alloc;
    zT_136 = &zT_141->lir_read;
    zT_143 = zF_1B7118E0_lirStreamReadFuncti(zT_134, zT_135, zT_136);
    ts_fn = zT_143;
    zT_145 = ts_fn.module_id;
    ts_src = zT_145;
    zT_147 = 0;
    ts_tti = zT_147;
    goto z_bb_10;
    z_bb_8:
    emitter.ts_ref_set = ts_ref_set;
    zT_377 = ctx->module_reg;
    zT_379 = zF_3452C137_moduleRegistryGetMo(zT_377);
    ri_mods = zT_379;
    zT_381 = 0;
    gt_i = zT_381;
    goto z_bb_75;
    z_bb_9:
    zT_375 = ts_fi + (unsigned int)(1);
    ts_fi = zT_375;
    goto z_bb_6;
    z_bb_10:
    zT_148 = ts_fn.hoisted_temps;
    zT_149 = zT_148.len;
    if ((unsigned char)(ts_tti < zT_149)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_152 = ts_fn.hoisted_temps;
    zT_153 = zT_152.items;
    zT_154 = zT_153[ts_tti];
    ts_hty = zT_154;
    zT_155 = &ref_edges;
    zT_156 = ctx->typereg;
    zT_157 = &type_visited;
    zT_158 = ts_src;
    zT_159 = ts_hty.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_155, zT_156, zT_157, zT_158, zT_159);
    goto z_bb_13;
    z_bb_12:
    zT_166 = ts_fn.return_type;
    zT_167 = ctx->typereg;
    zT_168 = zT_167->types_len;
    if ((unsigned char)(zT_166 < (unsigned int)((unsigned int)zT_168))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_165 = ts_tti + (unsigned int)(1);
    ts_tti = zT_165;
    goto z_bb_10;
    z_bb_14:
    zT_171 = &ref_edges;
    zT_172 = ctx->typereg;
    zT_173 = &type_visited;
    zT_174 = ts_src;
    zT_175 = ts_fn.return_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_171, zT_172, zT_173, zT_174, zT_175);
    goto z_bb_15;
    z_bb_15:
    zT_181 = 0;
    ts_pi = zT_181;
    goto z_bb_16;
    z_bb_16:
    zT_182 = ts_fn.params;
    zT_183 = zT_182.len;
    if ((unsigned char)(ts_pi < zT_183)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_186 = ts_fn.params;
    zT_187 = zT_186.items;
    zT_188 = zT_187[ts_pi];
    ts_pt = zT_188;
    zT_189 = &ref_edges;
    zT_190 = ctx->typereg;
    zT_191 = &type_visited;
    zT_192 = ts_src;
    zT_193 = ts_pt.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_189, zT_190, zT_191, zT_192, zT_193);
    goto z_bb_19;
    z_bb_18:
    zT_201 = 0;
    ts_bi = zT_201;
    goto z_bb_20;
    z_bb_19:
    zT_199 = ts_pi + (unsigned int)(1);
    ts_pi = zT_199;
    goto z_bb_16;
    z_bb_20:
    zT_202 = ts_fn.blocks;
    zT_203 = zT_202.len;
    if ((unsigned char)(ts_bi < zT_203)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_206 = ts_fn.blocks;
    zT_207 = zT_206.items;
    zT_208 = zT_207[ts_bi];
    ts_blk = zT_208;
    zT_210 = 0;
    ts_ii = zT_210;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_9;
    z_bb_23:
    zT_373 = ts_bi + (unsigned int)(1);
    ts_bi = zT_373;
    goto z_bb_20;
    z_bb_24:
    zT_211 = ts_blk.insts;
    zT_212 = zT_211.len;
    if ((unsigned char)(ts_ii < zT_212)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_215 = ts_blk.insts;
    zT_216 = zT_215.items;
    zT_217 = zT_216[ts_ii];
    ts_inst = zT_217;
    zT_219 = ts_inst.tag;
    ts_tg = zT_219;
    zT_221 = 0;
    ts_edge_has = zT_221;
    zT_223 = 0;
    ts_edge_dst = zT_223;
    zT_226.tag = 23;
    if ((unsigned char)(ts_tg == zT_226.tag)) goto z_bb_28; else goto z_bb_30;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_371 = ts_ii + (unsigned int)(1);
    ts_ii = zT_371;
    goto z_bb_24;
    z_bb_28:
    zT_229 = &ts_fn;
    zT_230 = ts_inst.payload.jump._0;
    zT_234 = zF_75DE985C_lirSideGetCallDirec(zT_229, zT_230);
    ts_cd = zT_234;
    zT_235 = ts_cd.module_id;
    ts_edge_dst = zT_235;
    zT_236 = 1;
    ts_edge_has = zT_236;
    goto z_bb_29;
    z_bb_29:
    if ((unsigned char)(ts_edge_has != (unsigned char)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_30:
    zT_239.tag = 27;
    if ((unsigned char)(ts_tg == zT_239.tag)) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_242 = &ts_fn;
    zT_243 = ts_inst.payload.jump._0;
    zT_247 = zF_1AB3807F_lirSideGetTailCall(zT_242, zT_243);
    ts_tc = zT_247;
    zT_248 = ts_tc.module_id;
    ts_edge_dst = zT_248;
    zT_249 = 1;
    ts_edge_has = zT_249;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_252.tag = 28;
    if ((unsigned char)(ts_tg == zT_252.tag)) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_255 = ts_inst.payload.func_ref._0;
    zT_256 = zT_255.module_id;
    ts_edge_dst = zT_256;
    zT_257 = 1;
    ts_edge_has = zT_257;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_260.tag = 54;
    if ((unsigned char)(ts_tg == zT_260.tag)) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_263 = ts_inst.payload.load_global._0;
    zT_264 = zT_263.module_id;
    ts_edge_dst = zT_264;
    zT_265 = 1;
    ts_edge_has = zT_265;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_268.tag = 55;
    if ((unsigned char)(ts_tg == zT_268.tag)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_271 = ts_inst.payload.store_global._0;
    zT_272 = zT_271.module_id;
    ts_edge_dst = zT_272;
    zT_273 = 1;
    ts_edge_has = zT_273;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_276 = ts_edge_dst != ts_src;
    goto z_bb_44;
    z_bb_43:
    zT_276 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_276) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_278 = &ref_edges;
    zF_26476265_u32ToU32MapPut(zT_278, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + ts_edge_dst), (unsigned int)(1));
    goto z_bb_46;
    z_bb_46:
    zT_288.tag = 57;
    if ((unsigned char)(ts_tg == zT_288.tag)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_291 = emitter.std_fmt_module_id;
    zT_290 = zT_291 != (unsigned int)(4294967295u);
    goto z_bb_49;
    z_bb_48:
    zT_290 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_290) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_294 = emitter.std_fmt_module_id;
    if ((unsigned char)(zT_294 != ts_src)) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    zT_307.tag = 54;
    if ((unsigned char)(ts_tg != zT_307.tag)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_296 = &ref_edges;
    zT_302 = emitter.std_fmt_module_id;
    zF_26476265_u32ToU32MapPut(zT_296, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + zT_302), (unsigned int)(1));
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    zT_312.tag = 55;
    zT_309 = ts_tg != zT_312.tag;
    goto z_bb_56;
    z_bb_55:
    zT_309 = 0;
    goto z_bb_56;
    z_bb_56:
    if (zT_309) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    goto z_bb_27;
    z_bb_58:
    zT_315 = 0;
    ts_name_id = zT_315;
    zT_317 = 0;
    ts_tmp = zT_317;
    zT_320.tag = 54;
    if ((unsigned char)(ts_tg == zT_320.tag)) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    zT_323 = ts_inst.payload.load_global._0;
    zT_324 = zT_323.name_id;
    ts_name_id = zT_324;
    zT_326 = ts_inst.payload.load_global._0;
    zT_327 = zT_326.result;
    ts_tmp = zT_327;
    goto z_bb_60;
    z_bb_60:
    zT_335 = 0;
    ts_tid = zT_335;
    zT_337 = 0;
    ts_tj = zT_337;
    goto z_bb_62;
    z_bb_61:
    zT_329 = ts_inst.payload.store_global._0;
    zT_330 = zT_329.name_id;
    ts_name_id = zT_330;
    zT_332 = ts_inst.payload.store_global._0;
    zT_333 = zT_332.value;
    ts_tmp = zT_333;
    goto z_bb_60;
    z_bb_62:
    zT_338 = ts_fn.hoisted_temps;
    zT_339 = zT_338.len;
    if ((unsigned char)(ts_tj < zT_339)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_342 = ts_fn.hoisted_temps;
    zT_343 = zT_342.items;
    zT_344 = zT_343[ts_tj];
    ts_ht = zT_344;
    zT_345 = ts_ht.temp_id;
    if ((unsigned char)(zT_345 == ts_tmp)) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    zT_350 = ctx->typereg;
    zT_351 = zT_350->types_len;
    if ((unsigned char)(ts_tid >= (unsigned int)((unsigned int)zT_351))) goto z_bb_68; else goto z_bb_69;
    z_bb_65:
    zT_349 = ts_tj + (unsigned int)(1);
    ts_tj = zT_349;
    goto z_bb_62;
    z_bb_66:
    zT_347 = ts_ht.type_id;
    ts_tid = zT_347;
    goto z_bb_64;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    goto z_bb_27;
    z_bb_69:
    zT_355 = ctx->typereg;
    zT_356 = zT_355->types_items;
    zT_357 = (unsigned int)ts_tid;
    zT_358 = zT_356[zT_357];
    ts_ty = zT_358;
    zT_359 = ts_ty.name_id;
    if ((unsigned char)(zT_359 != (unsigned int)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_363 = ts_ty.name_id;
    zT_362 = zT_363 == ts_name_id;
    goto z_bb_72;
    z_bb_71:
    zT_362 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_362) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_365 = &ts_ref_set;
    zT_366 = ts_tid;
    zF_26476265_u32ToU32MapPut(zT_365, zT_366, (unsigned int)(1));
    goto z_bb_74;
    z_bb_74:
    goto z_bb_27;
    z_bb_75:
    zT_382 = ctx->global_decls;
    zT_383 = zT_382.len;
    if ((unsigned char)(gt_i < zT_383)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_386 = ctx->global_decls;
    zT_387 = zT_386.items;
    zT_388 = zT_387[gt_i];
    gt_g = zT_388;
    zT_389 = gt_g.type_id;
    zT_390 = ctx->typereg;
    zT_391 = zT_390->types_len;
    if ((unsigned char)(zT_389 >= (unsigned int)((unsigned int)zT_391))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_422 = ctx->alloc;
    zT_420 = &zT_422->emission;
    zT_421 = ri_mods.len;
    zT_426 = zF_619D56E6_u32ToU32MapInitCap(zT_420, zT_421);
    reachable = zT_426;
    zT_427 = &reachable;
    zF_26476265_u32ToU32MapPut(zT_427, (unsigned int)(0), (unsigned int)(1));
    zT_434 = 1;
    rf_changed = zT_434;
    goto z_bb_86;
    z_bb_78:
    zT_418 = gt_i + (unsigned int)(1);
    gt_i = zT_418;
    goto z_bb_75;
    z_bb_79:
    goto z_bb_78;
    z_bb_80:
    zT_395 = ctx->typereg;
    zT_396 = zT_395->types_items;
    zT_397 = gt_g.type_id;
    zT_398 = (unsigned int)zT_397;
    zT_399 = zT_396[zT_398];
    gt_ty = zT_399;
    zT_400 = gt_ty.name_id;
    if ((unsigned char)(zT_400 != (unsigned int)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_404 = gt_ty.name_id;
    zT_405 = gt_g.name_id;
    zT_403 = zT_404 == zT_405;
    goto z_bb_83;
    z_bb_82:
    zT_403 = 0;
    goto z_bb_83;
    z_bb_83:
    if (zT_403) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    goto z_bb_78;
    z_bb_85:
    zT_407 = &ref_edges;
    zT_408 = ctx->typereg;
    zT_409 = &type_visited;
    zT_410 = gt_g.module_id;
    zT_411 = gt_g.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_407, zT_408, zT_409, zT_410, zT_411);
    goto z_bb_78;
    z_bb_86:
    if ((unsigned char)(rf_changed != (unsigned char)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_437 = 0;
    rf_changed = zT_437;
    zT_439 = 0;
    rf_s = zT_439;
    goto z_bb_90;
    z_bb_88:
    zT_487 = 0;
    ri_i = zT_487;
    goto z_bb_106;
    z_bb_89:
    goto z_bb_86;
    z_bb_90:
    zT_441 = ri_mods.len;
    if ((unsigned char)(rf_s < zT_441)) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_444 = ri_mods.ptr;
    zT_445 = zT_444[rf_s];
    zT_446 = zT_445.id;
    rf_src = zT_446;
    zT_447 = &reachable;
    zT_448 = rf_src;
    zT_450 = zF_F3EE5998_u32ToU32MapGet(zT_447, zT_448);
    zT_451 = zT_450.has_value;
    if ((unsigned char)(!zT_451)) goto z_bb_94; else goto z_bb_95;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_485 = rf_s + (unsigned int)(1);
    rf_s = zT_485;
    goto z_bb_90;
    z_bb_94:
    goto z_bb_93;
    z_bb_95:
    zT_454 = 0;
    rf_d = zT_454;
    goto z_bb_96;
    z_bb_96:
    zT_456 = ri_mods.len;
    if ((unsigned char)(rf_d < zT_456)) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_459 = ri_mods.ptr;
    zT_460 = zT_459[rf_d];
    zT_461 = zT_460.id;
    rf_dst = zT_461;
    if ((unsigned char)(rf_dst == rf_src)) goto z_bb_100; else goto z_bb_101;
    z_bb_98:
    goto z_bb_93;
    z_bb_99:
    zT_483 = rf_d + (unsigned int)(1);
    rf_d = zT_483;
    goto z_bb_96;
    z_bb_100:
    goto z_bb_99;
    z_bb_101:
    zT_463 = &reachable;
    zT_464 = rf_dst;
    zT_466 = zF_F3EE5998_u32ToU32MapGet(zT_463, zT_464);
    zT_467 = zT_466.has_value;
    if (zT_467) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    goto z_bb_99;
    z_bb_103:
    zT_468 = &ref_edges;
    zT_474 = zF_F3EE5998_u32ToU32MapGet(zT_468, (unsigned int)((unsigned int)(rf_src * (unsigned int)(65536)) + rf_dst));
    zT_475 = zT_474.has_value;
    if (zT_475) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    zT_476 = &reachable;
    zT_477 = rf_dst;
    zF_26476265_u32ToU32MapPut(zT_476, zT_477, (unsigned int)(1));
    zT_481 = 1;
    rf_changed = zT_481;
    goto z_bb_105;
    z_bb_105:
    goto z_bb_99;
    z_bb_106:
    zT_489 = ri_mods.len;
    if ((unsigned char)(ri_i < zT_489)) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_491 = ri_mods.ptr;
    zT_492 = zT_491[ri_i];
    zT_493 = zT_492.id;
    if ((unsigned char)(zT_493 == (unsigned int)(0))) goto z_bb_110; else goto z_bb_111;
    z_bb_108:
    emitter.reachable = reachable;
    zT_544 = ctx->cli;
    zT_545 = zT_544.output_dir_set;
    if (zT_545) goto z_bb_125; else goto z_bb_126;
    z_bb_109:
    zT_543 = ri_i + (unsigned int)(1);
    ri_i = zT_543;
    goto z_bb_106;
    z_bb_110:
    goto z_bb_109;
    z_bb_111:
    zT_496 = &reachable;
    zT_499 = ri_mods.ptr;
    zT_500 = zT_499[ri_i];
    zT_497 = zT_500.id;
    zT_502 = zF_F3EE5998_u32ToU32MapGet(zT_496, zT_497);
    zT_503 = zT_502.has_value;
    if ((unsigned char)(!zT_503)) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    goto z_bb_109;
    z_bb_113:
    zT_506 = 0;
    ri_has = zT_506;
    zT_508 = 0;
    gd_ri = zT_508;
    goto z_bb_114;
    z_bb_114:
    zT_509 = ctx->global_decls;
    zT_510 = zT_509.len;
    if ((unsigned char)(gd_ri < zT_510)) goto z_bb_115; else goto z_bb_116;
    z_bb_115:
    zT_513 = ctx->global_decls;
    zT_514 = zT_513.items;
    zT_515 = zT_514[gd_ri];
    gd_g = zT_515;
    zT_516 = gd_g.module_id;
    zT_517 = ri_mods.ptr;
    zT_518 = zT_517[ri_i];
    zT_519 = zT_518.id;
    if ((unsigned char)(zT_516 == zT_519)) goto z_bb_118; else goto z_bb_119;
    z_bb_116:
    if ((unsigned char)(ri_has != (unsigned char)(0))) goto z_bb_123; else goto z_bb_124;
    z_bb_117:
    zT_527 = gd_ri + (unsigned int)(1);
    gd_ri = zT_527;
    goto z_bb_114;
    z_bb_118:
    zT_522 = gd_g.has_runtime_init;
    zT_521 = zT_522 != (unsigned char)(0);
    goto z_bb_120;
    z_bb_119:
    zT_521 = 0;
    goto z_bb_120;
    z_bb_120:
    if (zT_521) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_525 = 1;
    ri_has = zT_525;
    goto z_bb_116;
    z_bb_122:
    goto z_bb_117;
    z_bb_123:
    zT_530 = &ref_edges;
    zT_537 = ri_mods.ptr;
    zT_538 = zT_537[ri_i];
    zT_539 = zT_538.id;
    zF_26476265_u32ToU32MapPut(zT_530, (unsigned int)((unsigned int)(0) + zT_539), (unsigned int)(1));
    goto z_bb_124;
    z_bb_124:
    goto z_bb_109;
    z_bb_125:
    zT_547 = ctx->spell_plan;
    zT_548 = zT_547.typedef_order;
    sorted = zT_548;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_550[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hpath[_i] = zT_550[_i];
        _i++;
    }
}
    zT_552 = 0;
    hp = zT_552;
    zT_554 = ctx->cli;
    zT_555 = zT_554.output_dir;
    od = zT_555;
    zT_556 = &emitter;
    zT_557 = od;
    zF_AB1E9CD4_emitSupportFiles(zT_556, zT_557);
    zT_560 = 0;
    hi = zT_560;
    goto z_bb_127;
    z_bb_126:
    cwriter = zT_1143;
    zT_1144 = zF_F9E678C3_bufferedWriterInit();
    cwriter = zT_1144;
    zT_1145 = &cwriter;
    zF_225796FB_emitIncludes(zT_1145);
    zT_1147 = &cwriter;
    zF_B35650AD_bufferedWriterFlush(zT_1147);
    zT_1150 = ctx->module_reg;
    zT_1153 = ctx->alloc;
    zT_1151 = &zT_1153->emission;
    zT_1155 = zF_1E2E8788_cincludeUnionAll(zT_1150, zT_1151);
    c_incs = zT_1155;
    zT_1156 = &emitter;
    zT_1157 = module_name;
    zT_1158 = c_incs;
    zF_503E3056_emitModule(zT_1156, zT_1157, zT_1158);
    zT_1161 = "FINAL_FLUSH\n";
    zT_1163 = 12;
    zT_1162.ptr = zT_1161;
    zT_1162.len = zT_1163;
    ff_m = zT_1162;
    zT_1164 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1164);
    zT_1166 = &emitter;
    zT_1165 = &zT_1166->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1165);
    zT_1168 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1168);
    zT_1170 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1170);
    return;
    z_bb_127:
    zT_562 = od.len;
    if ((unsigned char)(hi < zT_562)) goto z_bb_131; else goto z_bb_132;
    z_bb_128:
    zT_567 = od.ptr;
    zT_568 = zT_567[hi];
    hpath[hp] = zT_568;
    zT_569 = 1;
    zT_571 = hp + (unsigned int)((unsigned int)zT_569);
    hp = zT_571;
    goto z_bb_130;
    z_bb_129:
    zT_575 = 47;
    hpath[hp] = zT_575;
    zT_576 = 1;
    zT_578 = hp + (unsigned int)((unsigned int)zT_576);
    hp = zT_578;
    zT_580 = "zig_special_types.h";
    zT_582 = 19;
    zT_581.ptr = zT_580;
    zT_581.len = zT_582;
    hfn = zT_581;
    zT_584 = 0;
    hfi = zT_584;
    goto z_bb_134;
    z_bb_130:
    zT_572 = 1;
    zT_574 = hi + (unsigned int)((unsigned int)zT_572);
    hi = zT_574;
    goto z_bb_127;
    z_bb_131:
    zT_564 = hp < (unsigned int)(510);
    goto z_bb_133;
    z_bb_132:
    zT_564 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_564) goto z_bb_128; else goto z_bb_129;
    z_bb_134:
    zT_586 = hfn.len;
    if ((unsigned char)(hfi < zT_586)) goto z_bb_138; else goto z_bb_139;
    z_bb_135:
    zT_591 = hfn.ptr;
    zT_592 = zT_591[hfi];
    hpath[hp] = zT_592;
    zT_593 = 1;
    zT_595 = hp + (unsigned int)((unsigned int)zT_593);
    hp = zT_595;
    goto z_bb_137;
    z_bb_136:
    zT_604 = 0;
    zT_605 = (unsigned char*)((unsigned char*)hpath) + zT_604;
    zT_606 = hp - zT_604;
    zT_607.ptr = zT_605;
    zT_607.len = zT_606;
    zT_600 = zT_607;
    zT_609 = zF_39FE21EF_fileOpen(zT_600, (int)(0));
    fd = zT_609;
    if ((unsigned char)(fd == zG_CC81CC5F_INVALID_FD)) goto z_bb_141; else goto z_bb_142;
    z_bb_137:
    zT_596 = 1;
    zT_598 = hfi + (unsigned int)((unsigned int)zT_596);
    hfi = zT_598;
    goto z_bb_134;
    z_bb_138:
    zT_588 = hp < (unsigned int)(511);
    goto z_bb_140;
    z_bb_139:
    zT_588 = 0;
    goto z_bb_140;
    z_bb_140:
    if (zT_588) goto z_bb_135; else goto z_bb_136;
    z_bb_141:
    zT_613 = "error: cannot open output file\n";
    zT_615 = 31;
    zT_614.ptr = zT_613;
    zT_614.len = zT_615;
    emsg = zT_614;
    zT_616 = emsg;
    zF_E4B2EF19_stderr_write(zT_616);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_142;
    z_bb_142:
    hw = zT_620;
    zT_621 = fd;
    zT_622 = zF_E00097E1_bufferedWriterInitF(zT_621);
    hw = zT_622;
    emitter.writer = hw;
    zT_623 = &emitter;
    zT_624 = ctx->typereg;
    zT_625 = sorted;
    zF_62841416_emitSharedHeader(zT_623, zT_624, zT_625);
    zT_629 = &emitter;
    zT_628 = &zT_629->writer;
    zF_B35650AD_bufferedWriterFlush(zT_628);
    zT_631 = fd;
    zF_B30B1D79_fileClose(zT_631);
    zT_633 = ctx->module_reg;
    zT_635 = zF_3452C137_moduleRegistryGetMo(zT_633);
    mods = zT_635;
    emitter.prune_active = (unsigned char)(1);
    zT_638 = ctx->lir_slots;
    zT_639 = zT_638.len;
    slot_count = zT_639;
    zT_640 = 0;
    if ((unsigned char)(slot_count > (unsigned int)zT_640)) goto z_bb_143; else goto z_bb_144;
    z_bb_143:
    zT_646 = ctx->alloc;
    zT_643 = &zT_646->emission;
    zT_650 = mods.len;
    zT_653 = zF_1395EB68_sandAlloc(zT_643, (unsigned int)((unsigned int)(4) * zT_650), (unsigned int)(4));
    zT_654 = zT_653.is_error;
    if (zT_654) goto z_bb_145; else goto z_bb_146;
    z_bb_144:
    zT_754 = 0;
    fn_cursor = zT_754;
    zT_756 = 0;
    mi = zT_756;
    goto z_bb_174;
    z_bb_145:
    pal_trap();
    z_bb_146:
    zT_655 = zT_653.data.payload;
    goto z_bb_147;
    z_bb_147:
    zT_657 = (unsigned int*)zT_655;
    grp_counts = zT_657;
    zT_662 = ctx->alloc;
    zT_659 = &zT_662->emission;
    zT_666 = mods.len;
    zT_669 = zF_1395EB68_sandAlloc(zT_659, (unsigned int)((unsigned int)(4) * zT_666), (unsigned int)(4));
    zT_670 = zT_669.is_error;
    if (zT_670) goto z_bb_148; else goto z_bb_149;
    z_bb_148:
    pal_trap();
    z_bb_149:
    zT_671 = zT_669.data.payload;
    goto z_bb_150;
    z_bb_150:
    zT_673 = (unsigned int*)zT_671;
    grp_cursor = zT_673;
    zT_675 = 0;
    gci = zT_675;
    goto z_bb_151;
    z_bb_151:
    zT_677 = mods.len;
    if ((unsigned char)(gci < zT_677)) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_679 = 0;
    grp_counts[gci] = zT_679;
    goto z_bb_154;
    z_bb_153:
    zT_684 = 0;
    gsi = zT_684;
    goto z_bb_155;
    z_bb_154:
    zT_680 = 1;
    zT_682 = gci + (unsigned int)((unsigned int)zT_680);
    gci = zT_682;
    goto z_bb_151;
    z_bb_155:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_687 = ctx->lir_slots;
    zT_688 = zT_687.items;
    zT_689 = zT_688[gsi];
    zT_690 = zT_689.module_id;
    gsmid = zT_690;
    zT_693 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) < zT_693)) goto z_bb_159; else goto z_bb_160;
    z_bb_157:
    zT_704 = 0;
    gacc = zT_704;
    zT_705 = 0;
    gci = zT_705;
    goto z_bb_161;
    z_bb_158:
    zT_700 = 1;
    zT_702 = gsi + (unsigned int)((unsigned int)zT_700);
    gsi = zT_702;
    goto z_bb_155;
    z_bb_159:
    zT_695 = (unsigned int)gsmid;
    zT_696 = grp_counts[zT_695];
    zT_698 = zT_696 + (unsigned int)(1);
    zT_699 = (unsigned int)gsmid;
    grp_counts[zT_699] = zT_698;
    goto z_bb_160;
    z_bb_160:
    goto z_bb_158;
    z_bb_161:
    zT_707 = mods.len;
    if ((unsigned char)(gci < zT_707)) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    grp_cursor[gci] = gacc;
    zT_709 = grp_counts[gci];
    zT_710 = gacc + zT_709;
    gacc = zT_710;
    goto z_bb_164;
    z_bb_163:
    zT_718 = ctx->alloc;
    zT_715 = &zT_718->emission;
    zT_723 = zF_1395EB68_sandAlloc(zT_715, (unsigned int)((unsigned int)(12) * slot_count), (unsigned int)(4));
    zT_724 = zT_723.is_error;
    if (zT_724) goto z_bb_165; else goto z_bb_166;
    z_bb_164:
    zT_711 = 1;
    zT_713 = gci + (unsigned int)((unsigned int)zT_711);
    gci = zT_713;
    goto z_bb_161;
    z_bb_165:
    pal_trap();
    z_bb_166:
    zT_725 = zT_723.data.payload;
    goto z_bb_167;
    z_bb_167:
    zT_727 = (zT_E7714190_LirSlot*)zT_725;
    grouped = zT_727;
    zT_728 = 0;
    gsi = zT_728;
    goto z_bb_168;
    z_bb_168:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_169; else goto z_bb_170;
    z_bb_169:
    zT_731 = ctx->lir_slots;
    zT_732 = zT_731.items;
    zT_733 = zT_732[gsi];
    gslot = zT_733;
    zT_735 = gslot.module_id;
    gsmid = zT_735;
    zT_738 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) >= zT_738)) goto z_bb_172; else goto z_bb_173;
    z_bb_170:
    zT_750 = &ctx->lir_slots;
    zT_750->items = grouped;
    zT_752 = &ctx->lir_slots;
    zT_752->len = (unsigned int)((unsigned int)gacc);
    emitter.fn_slots = grouped;
    goto z_bb_144;
    z_bb_171:
    zT_747 = 1;
    zT_749 = gsi + (unsigned int)((unsigned int)zT_747);
    gsi = zT_749;
    goto z_bb_168;
    z_bb_172:
    goto z_bb_171;
    z_bb_173:
    zT_741 = (unsigned int)gsmid;
    zT_742 = grp_cursor[zT_741];
    gdst = zT_742;
    zT_743 = (unsigned int)gdst;
    grouped[zT_743] = gslot;
    zT_745 = gdst + (unsigned int)(1);
    zT_746 = (unsigned int)gsmid;
    grp_cursor[zT_746] = zT_745;
    goto z_bb_171;
    z_bb_174:
    zT_758 = mods.len;
    if ((unsigned char)(mi < zT_758)) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    zT_761 = mods.ptr;
    zT_762 = zT_761[mi];
    m = zT_762;
    fn_start = fn_cursor;
    goto z_bb_178;
    z_bb_176:
    zT_1129 = &emitter;
    zT_1130 = od;
    zT_1134 = ctx->cli;
    zT_1131 = zT_1134.target_is_windows;
    zT_1136 = ctx->cli;
    zT_1132 = zT_1136.target_win_profile;
    zF_A62DB57E_emitBuildScripts(zT_1129, zT_1130, zT_1131, zT_1132);
    zT_1138 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1138);
    zT_1140 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1140);
    return;
    z_bb_177:
    zT_1126 = 1;
    zT_1128 = mi + (unsigned int)((unsigned int)zT_1126);
    mi = zT_1128;
    goto z_bb_174;
    z_bb_178:
    zT_764 = ctx->lir_slots;
    zT_765 = zT_764.len;
    if ((unsigned char)(fn_cursor < zT_765)) goto z_bb_182; else goto z_bb_183;
    z_bb_179:
    goto z_bb_181;
    z_bb_180:
    zT_776 = &reachable;
    zT_777 = m.id;
    zT_780 = zF_F3EE5998_u32ToU32MapGet(zT_776, zT_777);
    zT_781 = zT_780.has_value;
    if ((unsigned char)(!zT_781)) goto z_bb_185; else goto z_bb_186;
    z_bb_181:
    zT_775 = fn_cursor + (unsigned int)(1);
    fn_cursor = zT_775;
    goto z_bb_178;
    z_bb_182:
    zT_768 = ctx->lir_slots;
    zT_769 = zT_768.items;
    zT_770 = zT_769[fn_cursor];
    zT_771 = zT_770.module_id;
    zT_772 = m.id;
    zT_767 = zT_771 == zT_772;
    goto z_bb_184;
    z_bb_183:
    zT_767 = 0;
    goto z_bb_184;
    z_bb_184:
    if (zT_767) goto z_bb_179; else goto z_bb_180;
    z_bb_185:
    goto z_bb_177;
    z_bb_186:
    emitter.fn_slots_start = fn_start;
    emitter.fn_slots_len = (unsigned int)(fn_cursor - fn_start);
    zT_785 = &emitter;
    zT_786 = m.id;
    zT_789 = zF_E295413A_moduleQualifiedName(zT_785, zT_786);
    base = zT_789;
    zT_791 = od.len;
    zT_795 = base.len;
    if ((unsigned char)((unsigned int)((unsigned int)((unsigned int)(zT_791 + (unsigned int)(1)) + zT_795) + (unsigned int)(3)) > (unsigned int)(511))) goto z_bb_187; else goto z_bb_188;
    z_bb_187:
    zT_802 = "error: output filename too long\n";
    zT_804 = 32;
    zT_803.ptr = zT_802;
    zT_803.len = zT_804;
    lmsg = zT_803;
    zT_805 = lmsg;
    zF_E4B2EF19_stderr_write(zT_805);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_188;
    z_bb_188:
    zT_809 = 0;
    hp2 = zT_809;
    zT_811 = 0;
    hi2 = zT_811;
    goto z_bb_189;
    z_bb_189:
    zT_813 = od.len;
    if ((unsigned char)(hi2 < zT_813)) goto z_bb_193; else goto z_bb_194;
    z_bb_190:
    zT_818 = od.ptr;
    zT_819 = zT_818[hi2];
    hpath[hp2] = zT_819;
    zT_820 = 1;
    zT_822 = hp2 + (unsigned int)((unsigned int)zT_820);
    hp2 = zT_822;
    goto z_bb_192;
    z_bb_191:
    zT_826 = 47;
    hpath[hp2] = zT_826;
    zT_827 = 1;
    zT_829 = hp2 + (unsigned int)((unsigned int)zT_827);
    hp2 = zT_829;
    zT_831 = 0;
    bi = zT_831;
    goto z_bb_196;
    z_bb_192:
    zT_823 = 1;
    zT_825 = hi2 + (unsigned int)((unsigned int)zT_823);
    hi2 = zT_825;
    goto z_bb_189;
    z_bb_193:
    zT_815 = hp2 < (unsigned int)(510);
    goto z_bb_195;
    z_bb_194:
    zT_815 = 0;
    goto z_bb_195;
    z_bb_195:
    if (zT_815) goto z_bb_190; else goto z_bb_191;
    z_bb_196:
    zT_833 = base.len;
    if ((unsigned char)(bi < zT_833)) goto z_bb_200; else goto z_bb_201;
    z_bb_197:
    zT_838 = base.ptr;
    zT_839 = zT_838[bi];
    hpath[hp2] = zT_839;
    zT_840 = 1;
    zT_842 = hp2 + (unsigned int)((unsigned int)zT_840);
    hp2 = zT_842;
    goto z_bb_199;
    z_bb_198:
    zT_847 = ".h";
    zT_849 = 2;
    zT_848.ptr = zT_847;
    zT_848.len = zT_849;
    hext = zT_848;
    zT_851 = 0;
    hx = zT_851;
    goto z_bb_203;
    z_bb_199:
    zT_843 = 1;
    zT_845 = bi + (unsigned int)((unsigned int)zT_843);
    bi = zT_845;
    goto z_bb_196;
    z_bb_200:
    zT_835 = hp2 < (unsigned int)(510);
    goto z_bb_202;
    z_bb_201:
    zT_835 = 0;
    goto z_bb_202;
    z_bb_202:
    if (zT_835) goto z_bb_197; else goto z_bb_198;
    z_bb_203:
    zT_853 = hext.len;
    if ((unsigned char)(hx < zT_853)) goto z_bb_207; else goto z_bb_208;
    z_bb_204:
    zT_858 = hext.ptr;
    zT_859 = zT_858[hx];
    hpath[hp2] = zT_859;
    zT_860 = 1;
    zT_862 = hp2 + (unsigned int)((unsigned int)zT_860);
    hp2 = zT_862;
    goto z_bb_206;
    z_bb_205:
    zT_871 = 0;
    zT_872 = (unsigned char*)((unsigned char*)hpath) + zT_871;
    zT_873 = hp2 - zT_871;
    zT_874.ptr = zT_872;
    zT_874.len = zT_873;
    zT_867 = zT_874;
    zT_876 = zF_39FE21EF_fileOpen(zT_867, (int)(0));
    fd2 = zT_876;
    if ((unsigned char)(fd2 == zG_CC81CC5F_INVALID_FD)) goto z_bb_210; else goto z_bb_211;
    z_bb_206:
    zT_863 = 1;
    zT_865 = hx + (unsigned int)((unsigned int)zT_863);
    hx = zT_865;
    goto z_bb_203;
    z_bb_207:
    zT_855 = hp2 < (unsigned int)(511);
    goto z_bb_209;
    z_bb_208:
    zT_855 = 0;
    goto z_bb_209;
    z_bb_209:
    if (zT_855) goto z_bb_204; else goto z_bb_205;
    z_bb_210:
    zT_880 = "error: cannot open output file\n";
    zT_882 = 31;
    zT_881.ptr = zT_880;
    zT_881.len = zT_882;
    emsg2 = zT_881;
    zT_883 = emsg2;
    zF_E4B2EF19_stderr_write(zT_883);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_211;
    z_bb_211:
    hw2 = zT_887;
    zT_888 = fd2;
    zT_889 = zF_E00097E1_bufferedWriterInitF(zT_888);
    hw2 = zT_889;
    emitter.writer = hw2;
    zT_891 = m.imports_start;
    zT_892 = (unsigned int)zT_891;
    dep_start = zT_892;
    zT_894 = m.import_count;
    zT_896 = dep_start + (unsigned int)((unsigned int)zT_894);
    dep_end = zT_896;
    zT_898 = ctx->module_reg;
    zT_899 = zT_898->import_edges_items;
    zT_900 = zT_899 + dep_start;
    zT_901 = dep_end - dep_start;
    zT_902.ptr = zT_900;
    zT_902.len = zT_901;
    dep_ids = zT_902;
    zT_904 = m.c_includes;
    zT_905 = zT_904.items;
    zT_906 = m.c_includes;
    zT_907 = zT_906.len;
    zT_908 = 0;
    zT_909 = zT_905 + zT_908;
    zT_910 = zT_907 - zT_908;
    zT_911.ptr = zT_909;
    zT_911.len = zT_910;
    m_c_incs = zT_911;
    zT_916 = ctx->alloc;
    zT_913 = &zT_916->emission;
    zT_920 = mods.len;
    zT_923 = zF_1395EB68_sandAlloc(zT_913, (unsigned int)((unsigned int)(4) * zT_920), (unsigned int)(4));
    zT_924 = zT_923.is_error;
    if (zT_924) goto z_bb_212; else goto z_bb_213;
    z_bb_212:
    pal_trap();
    z_bb_213:
    zT_925 = zT_923.data.payload;
    goto z_bb_214;
    z_bb_214:
    inc_raw = zT_925;
    zT_928 = (unsigned int*)inc_raw;
    inc_arr = zT_928;
    zT_930 = 0;
    inc_n = zT_930;
    zT_932 = 0;
    di0 = zT_932;
    goto z_bb_215;
    z_bb_215:
    zT_934 = dep_ids.len;
    if ((unsigned char)(di0 < zT_934)) goto z_bb_216; else goto z_bb_217;
    z_bb_216:
    zT_937 = dep_ids.ptr;
    zT_938 = zT_937[di0];
    dd0 = zT_938;
    zT_939 = m.id;
    if ((unsigned char)(dd0 == zT_939)) goto z_bb_219; else goto z_bb_220;
    z_bb_217:
    zT_964 = 0;
    vd0 = zT_964;
    goto z_bb_231;
    z_bb_218:
    zT_962 = di0 + (unsigned int)(1);
    di0 = zT_962;
    goto z_bb_215;
    z_bb_219:
    goto z_bb_218;
    z_bb_220:
    zT_941 = &reachable;
    zT_942 = dd0;
    zT_944 = zF_F3EE5998_u32ToU32MapGet(zT_941, zT_942);
    zT_945 = zT_944.has_value;
    if ((unsigned char)(!zT_945)) goto z_bb_221; else goto z_bb_222;
    z_bb_221:
    goto z_bb_218;
    z_bb_222:
    zT_948 = 0;
    dup0 = zT_948;
    zT_950 = 0;
    dj0 = zT_950;
    goto z_bb_223;
    z_bb_223:
    if ((unsigned char)(dj0 < inc_n)) goto z_bb_224; else goto z_bb_225;
    z_bb_224:
    zT_952 = inc_arr[dj0];
    if ((unsigned char)(zT_952 == dd0)) goto z_bb_227; else goto z_bb_228;
    z_bb_225:
    if ((unsigned char)(dup0 != (unsigned char)(0))) goto z_bb_229; else goto z_bb_230;
    z_bb_226:
    zT_956 = dj0 + (unsigned int)(1);
    dj0 = zT_956;
    goto z_bb_223;
    z_bb_227:
    zT_954 = 1;
    dup0 = zT_954;
    goto z_bb_225;
    z_bb_228:
    goto z_bb_226;
    z_bb_229:
    goto z_bb_218;
    z_bb_230:
    inc_arr[inc_n] = dd0;
    zT_960 = inc_n + (unsigned int)(1);
    inc_n = zT_960;
    goto z_bb_218;
    z_bb_231:
    zT_966 = mods.len;
    if ((unsigned char)(vd0 < zT_966)) goto z_bb_232; else goto z_bb_233;
    z_bb_232:
    zT_969 = mods.ptr;
    zT_970 = zT_969[vd0];
    zT_971 = zT_970.id;
    vdd0 = zT_971;
    zT_972 = m.id;
    if ((unsigned char)(vdd0 == zT_972)) goto z_bb_235; else goto z_bb_236;
    z_bb_233:
    zT_1007 = 0;
    zT_1008 = inc_arr + zT_1007;
    zT_1009 = inc_n - zT_1007;
    zT_1010.ptr = zT_1008;
    zT_1010.len = zT_1009;
    inc_slice = zT_1010;
    zT_1011 = &emitter;
    zT_1012 = m.id;
    zT_1013 = base;
    zT_1014 = m_c_incs;
    zT_1015 = inc_slice;
    zT_1016 = sorted;
    zF_1AF3E3A9_emitModuleHeaderFil(zT_1011, zT_1012, zT_1013, zT_1014, zT_1015, zT_1016);
    zT_1020 = &emitter;
    zT_1019 = &zT_1020->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1019);
    zT_1022 = fd2;
    zF_B30B1D79_fileClose(zT_1022);
    zT_1024 = "FINAL_FLUSH\n";
    zT_1026 = 12;
    zT_1025.ptr = zT_1024;
    zT_1025.len = zT_1026;
    ff_m = zT_1025;
    zT_1027 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1027);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_1029[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        cpath[_i] = zT_1029[_i];
        _i++;
    }
}
    zT_1031 = 0;
    cp2 = zT_1031;
    zT_1033 = 0;
    ci2 = zT_1033;
    goto z_bb_249;
    z_bb_234:
    zT_1005 = vd0 + (unsigned int)(1);
    vd0 = zT_1005;
    goto z_bb_231;
    z_bb_235:
    goto z_bb_234;
    z_bb_236:
    zT_974 = &reachable;
    zT_975 = vdd0;
    zT_977 = zF_F3EE5998_u32ToU32MapGet(zT_974, zT_975);
    zT_978 = zT_977.has_value;
    if ((unsigned char)(!zT_978)) goto z_bb_237; else goto z_bb_238;
    z_bb_237:
    goto z_bb_234;
    z_bb_238:
    zT_980 = &ref_edges;
    zT_983 = m.id;
    zT_987 = zF_F3EE5998_u32ToU32MapGet(zT_980, (unsigned int)((unsigned int)(zT_983 * (unsigned int)(65536)) + vdd0));
    zT_988 = zT_987.has_value;
    if ((unsigned char)(!zT_988)) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    goto z_bb_234;
    z_bb_240:
    zT_991 = 0;
    dup1 = zT_991;
    zT_993 = 0;
    dj1 = zT_993;
    goto z_bb_241;
    z_bb_241:
    if ((unsigned char)(dj1 < inc_n)) goto z_bb_242; else goto z_bb_243;
    z_bb_242:
    zT_995 = inc_arr[dj1];
    if ((unsigned char)(zT_995 == vdd0)) goto z_bb_245; else goto z_bb_246;
    z_bb_243:
    if ((unsigned char)(dup1 != (unsigned char)(0))) goto z_bb_247; else goto z_bb_248;
    z_bb_244:
    zT_999 = dj1 + (unsigned int)(1);
    dj1 = zT_999;
    goto z_bb_241;
    z_bb_245:
    zT_997 = 1;
    dup1 = zT_997;
    goto z_bb_243;
    z_bb_246:
    goto z_bb_244;
    z_bb_247:
    goto z_bb_234;
    z_bb_248:
    inc_arr[inc_n] = vdd0;
    zT_1003 = inc_n + (unsigned int)(1);
    inc_n = zT_1003;
    goto z_bb_234;
    z_bb_249:
    zT_1035 = od.len;
    if ((unsigned char)(ci2 < zT_1035)) goto z_bb_253; else goto z_bb_254;
    z_bb_250:
    zT_1040 = od.ptr;
    zT_1041 = zT_1040[ci2];
    cpath[cp2] = zT_1041;
    zT_1042 = 1;
    zT_1044 = cp2 + (unsigned int)((unsigned int)zT_1042);
    cp2 = zT_1044;
    goto z_bb_252;
    z_bb_251:
    zT_1048 = 47;
    cpath[cp2] = zT_1048;
    zT_1049 = 1;
    zT_1051 = cp2 + (unsigned int)((unsigned int)zT_1049);
    cp2 = zT_1051;
    zT_1053 = 0;
    cbi = zT_1053;
    goto z_bb_256;
    z_bb_252:
    zT_1045 = 1;
    zT_1047 = ci2 + (unsigned int)((unsigned int)zT_1045);
    ci2 = zT_1047;
    goto z_bb_249;
    z_bb_253:
    zT_1037 = cp2 < (unsigned int)(510);
    goto z_bb_255;
    z_bb_254:
    zT_1037 = 0;
    goto z_bb_255;
    z_bb_255:
    if (zT_1037) goto z_bb_250; else goto z_bb_251;
    z_bb_256:
    zT_1055 = base.len;
    if ((unsigned char)(cbi < zT_1055)) goto z_bb_260; else goto z_bb_261;
    z_bb_257:
    zT_1060 = base.ptr;
    zT_1061 = zT_1060[cbi];
    cpath[cp2] = zT_1061;
    zT_1062 = 1;
    zT_1064 = cp2 + (unsigned int)((unsigned int)zT_1062);
    cp2 = zT_1064;
    goto z_bb_259;
    z_bb_258:
    zT_1069 = ".c";
    zT_1071 = 2;
    zT_1070.ptr = zT_1069;
    zT_1070.len = zT_1071;
    cext = zT_1070;
    zT_1073 = 0;
    cx = zT_1073;
    goto z_bb_263;
    z_bb_259:
    zT_1065 = 1;
    zT_1067 = cbi + (unsigned int)((unsigned int)zT_1065);
    cbi = zT_1067;
    goto z_bb_256;
    z_bb_260:
    zT_1057 = cp2 < (unsigned int)(510);
    goto z_bb_262;
    z_bb_261:
    zT_1057 = 0;
    goto z_bb_262;
    z_bb_262:
    if (zT_1057) goto z_bb_257; else goto z_bb_258;
    z_bb_263:
    zT_1075 = cext.len;
    if ((unsigned char)(cx < zT_1075)) goto z_bb_267; else goto z_bb_268;
    z_bb_264:
    zT_1080 = cext.ptr;
    zT_1081 = zT_1080[cx];
    cpath[cp2] = zT_1081;
    zT_1082 = 1;
    zT_1084 = cp2 + (unsigned int)((unsigned int)zT_1082);
    cp2 = zT_1084;
    goto z_bb_266;
    z_bb_265:
    zT_1093 = 0;
    zT_1094 = (unsigned char*)((unsigned char*)cpath) + zT_1093;
    zT_1095 = cp2 - zT_1093;
    zT_1096.ptr = zT_1094;
    zT_1096.len = zT_1095;
    zT_1089 = zT_1096;
    zT_1098 = zF_39FE21EF_fileOpen(zT_1089, (int)(0));
    cfd = zT_1098;
    if ((unsigned char)(cfd == zG_CC81CC5F_INVALID_FD)) goto z_bb_270; else goto z_bb_271;
    z_bb_266:
    zT_1085 = 1;
    zT_1087 = cx + (unsigned int)((unsigned int)zT_1085);
    cx = zT_1087;
    goto z_bb_263;
    z_bb_267:
    zT_1077 = cp2 < (unsigned int)(511);
    goto z_bb_269;
    z_bb_268:
    zT_1077 = 0;
    goto z_bb_269;
    z_bb_269:
    if (zT_1077) goto z_bb_264; else goto z_bb_265;
    z_bb_270:
    zT_1102 = "error: cannot open output file\n";
    zT_1104 = 31;
    zT_1103.ptr = zT_1102;
    zT_1103.len = zT_1104;
    emsg3 = zT_1103;
    zT_1105 = emsg3;
    zF_E4B2EF19_stderr_write(zT_1105);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_271;
    z_bb_271:
    cw = zT_1109;
    zT_1110 = cfd;
    zT_1111 = zF_E00097E1_bufferedWriterInitF(zT_1110);
    cw = zT_1111;
    emitter.writer = cw;
    zT_1112 = &emitter;
    zT_1113 = m.id;
    zT_1114 = base;
    zF_7B8B9B90_emitModuleFile(zT_1112, zT_1113, zT_1114);
    zT_1118 = &emitter;
    zT_1117 = &zT_1118->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1117);
    zT_1120 = cfd;
    zF_B30B1D79_fileClose(zT_1120);
    zT_1122 = "FINAL_FLUSH\n";
    zT_1124 = 12;
    zT_1123.ptr = zT_1122;
    zT_1123.len = zT_1124;
    ff2_m = zT_1123;
    zT_1125 = ff2_m;
    zF_48AC7B3A_markerWrite(zT_1125);
    goto z_bb_177;
}

/* parseArgs */
zT_C98AF326_CompilerCli zF_6143A521_parseArgs(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_C98AF326_CompilerCli zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_CAF40AAB_ColorMode zT_18;
    zT_A4FB690E_ErrorFormat zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    zT_074080EA_WinProfile zT_35;
    int zT_37 = 0;
    int zT_39;
    int zT_40;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    unsigned char* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    unsigned char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    unsigned char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    unsigned char* zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    unsigned char* zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    unsigned char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    unsigned char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned char* zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    int zT_195;
    unsigned char* zT_196 = 0;
    unsigned char* zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199 = {0};
    unsigned int zT_201;
    int zT_202;
    unsigned char zT_204;
    unsigned char* zT_205;
    int zT_206;
    unsigned char zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char zT_212 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned char zT_217 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    unsigned char zT_221 = 0;
    unsigned char zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned char zT_225 = 0;
    int zT_226;
    int zT_228;
    unsigned char* zT_230;
    int zT_231;
    unsigned char* zT_232 = 0;
    unsigned int zT_233 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned char zT_235 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned char* zT_237;
    unsigned int zT_238;
    int zT_239;
    unsigned char* zT_240;
    unsigned int zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned char zT_245 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned char* zT_247;
    unsigned int zT_248;
    int zT_249;
    unsigned char* zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_253 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char zT_256 = 0;
    unsigned char zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned char zT_260 = 0;
    int zT_261;
    int zT_263;
    unsigned char* zT_265;
    int zT_266;
    unsigned char* zT_267 = 0;
    unsigned int zT_268 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned char zT_271 = 0;
    unsigned char zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned char zT_275 = 0;
    int zT_276;
    int zT_278;
    unsigned char* zT_280;
    int zT_281;
    unsigned char* zT_282 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned char zT_287 = 0;
    unsigned char zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned char zT_291 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned char zT_295 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    unsigned char zT_299 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned char zT_303 = 0;
    unsigned char zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    unsigned char zT_307 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    unsigned char zT_311 = 0;
    int zT_312;
    int zT_314;
    unsigned char* zT_316;
    int zT_317;
    unsigned char* zT_318 = 0;
    zT_CAF40AAB_ColorMode zT_319 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_321;
    unsigned char zT_322 = 0;
    int zT_323;
    int zT_325;
    unsigned char* zT_327;
    int zT_328;
    unsigned char* zT_329 = 0;
    zT_A4FB690E_ErrorFormat zT_330 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned char zT_333 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    unsigned char zT_337 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned char zT_341 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned char zT_345 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    unsigned char zT_349 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_352;
    unsigned char zT_353 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned char zT_358 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_361;
    unsigned char zT_362 = 0;
    unsigned char zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    unsigned char zT_366 = 0;
    int zT_367;
    int zT_369;
    unsigned char zT_371;
    unsigned int zT_372;
    int zT_373;
    unsigned char* zT_375;
    int zT_376;
    unsigned char* zT_377 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_378 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_379;
    unsigned int zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    int zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned char zT_388 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    unsigned char zT_392 = 0;
    int zT_396;
    unsigned char* zT_400;
    int zT_402;
    unsigned char* zT_404 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405 = {0};
    unsigned int zT_407;
    int zT_408;
    unsigned char zT_410;
    unsigned char* zT_411;
    int zT_412;
    unsigned char zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_417;
    unsigned char zT_418 = 0;
    int zT_421;
    int zT_423;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned char zT_426 = 0;
    int zT_429;
    int zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned char zT_434 = 0;
    int zT_435;
    int zT_437;
    unsigned char* zT_439;
    int zT_440;
    unsigned char* zT_441 = 0;
    unsigned char zT_442 = 0;
    unsigned char zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_447;
    unsigned char zT_448 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_450;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    unsigned char zT_452 = 0;
    unsigned char* zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455 = {0};
    unsigned char* zT_456;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_457 = {0};
    int zT_458;
    int zT_460;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u dot_str;
    zT_C98AF326_CompilerCli cli;
    int argc;
    int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dump_c89;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_mem;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_errors;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_output_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_quiet;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sanity_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warnings;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_color;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_error_format;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_track_memory;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_lifetime;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_leak;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_all;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_error;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_markers;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_include;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_lib_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_o;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_q;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_W;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osw;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_profile_9x;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_profile_nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fsafe;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ffast;
    unsigned char* arg_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u arg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nxt;
    zT_1 = "";
    zT_3 = 0;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    empty_str = zT_2;
    zT_5 = ".";
    zT_7 = 1;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    dot_str = zT_6;
    zT_9.input_file = empty_str;
    zT_9.output_dir = dot_str;
    zT_10 = 0;
    zT_9.output_dir_set = zT_10;
    zT_11 = 0;
    zT_9.dump_types = zT_11;
    zT_12 = 0;
    zT_9.dump_lir = zT_12;
    zT_13 = 0;
    zT_9.dump_c89 = zT_13;
    zT_15 = (unsigned int)zG_18AE3D2F_DEFAULT_MAX_MEM_KB;
    zT_9.max_mem = zT_15;
    zT_16 = 0;
    zT_9.spill_level = zT_16;
    zT_17 = 256;
    zT_9.max_errors = zT_17;
    zT_18 = zT_CAF40AAB_ColorMode_auto;
    zT_9.color = zT_18;
    zT_19 = zT_A4FB690E_ErrorFormat_human;
    zT_9.error_format = zT_19;
    zT_20 = 0;
    zT_9.warnings_as_errors = zT_20;
    zT_21 = 0;
    zT_9.quiet = zT_21;
    zT_22 = 0;
    zT_9.test_mode = zT_22;
    zT_23 = 0;
    zT_9.sanity_test_mode = zT_23;
    zT_24 = 0;
    zT_9.track_memory = zT_24;
    zT_25 = 0;
    zT_9.no_null_check = zT_25;
    zT_26 = 0;
    zT_9.no_lifetime_check = zT_26;
    zT_27 = 0;
    zT_9.no_leak_check = zT_27;
    zT_28 = 1;
    zT_9.safe_checks = zT_28;
    zT_29 = 0;
    zT_9.warn_all = zT_29;
    zT_30 = 0;
    zT_9.warn_error = zT_30;
    zT_31 = 0;
    zT_9.show_markers = zT_31;
    zT_32 = 0;
    zT_9.include_count = zT_32;
    zT_33 = 0;
    zT_9.target_is_windows = zT_33;
    zT_35 = zT_074080EA_WinProfile_win9x;
    zT_9.target_win_profile = zT_35;
    cli = zT_9;
    zT_37 = zF_EEF840BE_argCount();
    argc = zT_37;
    zT_39 = 1;
    zT_40 = (int)zT_39;
    i = zT_40;
    zT_50 = "--dump-c89";
    zT_52 = 10;
    zT_51.ptr = zT_50;
    zT_51.len = zT_52;
    s_dump_c89 = zT_51;
    zT_54 = "--help";
    zT_56 = 6;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    s_help = zT_55;
    zT_58 = "--max-mem";
    zT_60 = 9;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_max_mem = zT_59;
    zT_62 = "--max-errors";
    zT_64 = 12;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    s_max_errors = zT_63;
    zT_66 = "--output-dir";
    zT_68 = 12;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    s_output_dir = zT_67;
    zT_70 = "--quiet";
    zT_72 = 7;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    s_quiet = zT_71;
    zT_74 = "--test";
    zT_76 = 6;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    s_test = zT_75;
    zT_78 = "--sanity-test";
    zT_80 = 13;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    s_sanity_test = zT_79;
    zT_82 = "--warnings-as-errors";
    zT_84 = 20;
    zT_83.ptr = zT_82;
    zT_83.len = zT_84;
    s_warnings = zT_83;
    zT_86 = "--color";
    zT_88 = 7;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    s_color = zT_87;
    zT_90 = "--error-format";
    zT_92 = 14;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    s_error_format = zT_91;
    zT_94 = "--track-memory";
    zT_96 = 14;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    s_track_memory = zT_95;
    zT_98 = "--no-null-check";
    zT_100 = 15;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    s_no_null = zT_99;
    zT_102 = "--no-lifetime-check";
    zT_104 = 19;
    zT_103.ptr = zT_102;
    zT_103.len = zT_104;
    s_no_lifetime = zT_103;
    zT_106 = "--no-leak-check";
    zT_108 = 15;
    zT_107.ptr = zT_106;
    zT_107.len = zT_108;
    s_no_leak = zT_107;
    zT_110 = "--warn-all";
    zT_112 = 10;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    s_warn_all = zT_111;
    zT_114 = "--warn-error";
    zT_116 = 12;
    zT_115.ptr = zT_114;
    zT_115.len = zT_116;
    s_warn_error = zT_115;
    zT_118 = "--markers";
    zT_120 = 9;
    zT_119.ptr = zT_118;
    zT_119.len = zT_120;
    s_markers = zT_119;
    zT_122 = "-I";
    zT_124 = 2;
    zT_123.ptr = zT_122;
    zT_123.len = zT_124;
    s_include = zT_123;
    zT_126 = "--lib-dir";
    zT_128 = 9;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    s_lib_dir = zT_127;
    zT_146 = "-m";
    zT_148 = 2;
    zT_147.ptr = zT_146;
    zT_147.len = zT_148;
    s_m = zT_147;
    zT_150 = "-e";
    zT_152 = 2;
    zT_151.ptr = zT_150;
    zT_151.len = zT_152;
    s_e = zT_151;
    zT_154 = "-o";
    zT_156 = 2;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    s_o = zT_155;
    zT_158 = "-q";
    zT_160 = 2;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    s_q = zT_159;
    zT_162 = "-W";
    zT_164 = 2;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    s_W = zT_163;
    zT_166 = "-osl";
    zT_168 = 4;
    zT_167.ptr = zT_166;
    zT_167.len = zT_168;
    s_osl = zT_167;
    zT_170 = "-osw";
    zT_172 = 4;
    zT_171.ptr = zT_170;
    zT_171.len = zT_172;
    s_osw = zT_171;
    zT_174 = "9x";
    zT_176 = 2;
    zT_175.ptr = zT_174;
    zT_175.len = zT_176;
    s_profile_9x = zT_175;
    zT_178 = "nt";
    zT_180 = 2;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    s_profile_nt = zT_179;
    zT_182 = "--target";
    zT_184 = 8;
    zT_183.ptr = zT_182;
    zT_183.len = zT_184;
    s_target = zT_183;
    zT_186 = "-fsafe";
    zT_188 = 6;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    s_fsafe = zT_187;
    zT_190 = "-ffast";
    zT_192 = 6;
    zT_191.ptr = zT_190;
    zT_191.len = zT_192;
    s_ffast = zT_191;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < argc)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_195 = i;
    zT_196 = zF_70B5BFF1_argGet(zT_195);
    arg_ptr = zT_196;
    zT_198 = arg_ptr;
    zT_199 = zF_22D0470E_cstrToSlice(zT_198);
    arg = zT_199;
    zT_201 = arg.len;
    zT_202 = 0;
    if ((unsigned char)(zT_201 > (unsigned int)zT_202)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cli;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_205 = arg.ptr;
    zT_206 = 0;
    zT_207 = zT_205[zT_206];
    zT_204 = zT_207 == (unsigned char)(45);
    goto z_bb_7;
    z_bb_6:
    zT_204 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_204) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_210 = arg;
    zT_211 = s_help;
    zT_212 = zF_5FE51158_matchFlag(zT_210, zT_211);
    if (zT_212) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_458 = 1;
    zT_460 = i + (int)((int)zT_458);
    i = zT_460;
    goto z_bb_4;
    z_bb_10:
    zT_456 = arg_ptr;
    zT_457 = zF_22D0470E_cstrToSlice(zT_456);
    cli.input_file = zT_457;
    goto z_bb_9;
    z_bb_11:
    zF_9D45DFBF_printUsage();
    zF_CDED1A85_exit((unsigned char)(0));
    return cli;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_215 = arg;
    zT_216 = s_dump_c89;
    zT_217 = zF_5FE51158_matchFlag(zT_215, zT_216);
    if (zT_217) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cli.dump_c89 = (unsigned char)(1);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_219 = arg;
    zT_220 = s_max_mem;
    zT_221 = zF_5FE51158_matchFlag(zT_219, zT_220);
    if (zT_221) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_223 = arg;
    zT_224 = s_m;
    zT_225 = zF_5FE51158_matchFlag(zT_223, zT_224);
    zT_222 = zT_225;
    goto z_bb_19;
    z_bb_18:
    zT_222 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_222) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_226 = 1;
    zT_228 = i + (int)((int)zT_226);
    i = zT_228;
    if ((unsigned char)(i < argc)) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_234 = arg;
    zT_235 = zF_FBF91F7E_matchMMFlag(zT_234);
    if (zT_235) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    zT_231 = i;
    zT_232 = zF_70B5BFF1_argGet(zT_231);
    zT_230 = zT_232;
    zT_233 = zF_6CF11065_parseSize(zT_230);
    cli.max_mem = zT_233;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_237 = arg.ptr;
    zT_238 = arg.len;
    zT_239 = 3;
    zT_240 = zT_237 + zT_239;
    zT_241 = zT_238 - zT_239;
    zT_242.ptr = zT_240;
    zT_242.len = zT_241;
    zT_236 = zT_242;
    zT_243 = zF_B9231BB9_parseMMBytes(zT_236);
    cli.max_mem = zT_243;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_244 = arg;
    zT_245 = zF_C4E3C361_matchSFlag(zT_244);
    if (zT_245) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_247 = arg.ptr;
    zT_248 = arg.len;
    zT_249 = 2;
    zT_250 = zT_247 + zT_249;
    zT_251 = zT_248 - zT_249;
    zT_252.ptr = zT_250;
    zT_252.len = zT_251;
    zT_246 = zT_252;
    zT_253 = zF_153C3795_parseSLevel(zT_246);
    cli.spill_level = zT_253;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    zT_254 = arg;
    zT_255 = s_max_errors;
    zT_256 = zF_5FE51158_matchFlag(zT_254, zT_255);
    if (zT_256) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_258 = arg;
    zT_259 = s_e;
    zT_260 = zF_5FE51158_matchFlag(zT_258, zT_259);
    zT_257 = zT_260;
    goto z_bb_33;
    z_bb_32:
    zT_257 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_257) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_261 = 1;
    zT_263 = i + (int)((int)zT_261);
    i = zT_263;
    if ((unsigned char)(i < argc)) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    goto z_bb_29;
    z_bb_36:
    zT_269 = arg;
    zT_270 = s_output_dir;
    zT_271 = zF_5FE51158_matchFlag(zT_269, zT_270);
    if (zT_271) goto z_bb_40; else goto z_bb_39;
    z_bb_37:
    zT_266 = i;
    zT_267 = zF_70B5BFF1_argGet(zT_266);
    zT_265 = zT_267;
    zT_268 = zF_16BBA09E_parseU32(zT_265);
    cli.max_errors = zT_268;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_273 = arg;
    zT_274 = s_o;
    zT_275 = zF_5FE51158_matchFlag(zT_273, zT_274);
    zT_272 = zT_275;
    goto z_bb_41;
    z_bb_40:
    zT_272 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_272) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_276 = 1;
    zT_278 = i + (int)((int)zT_276);
    i = zT_278;
    if ((unsigned char)(i < argc)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_35;
    z_bb_44:
    zT_285 = arg;
    zT_286 = s_quiet;
    zT_287 = zF_5FE51158_matchFlag(zT_285, zT_286);
    if (zT_287) goto z_bb_48; else goto z_bb_47;
    z_bb_45:
    zT_281 = i;
    zT_282 = zF_70B5BFF1_argGet(zT_281);
    zT_280 = zT_282;
    zT_283 = zF_22D0470E_cstrToSlice(zT_280);
    cli.output_dir = zT_283;
    cli.output_dir_set = (unsigned char)(1);
    goto z_bb_46;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_289 = arg;
    zT_290 = s_q;
    zT_291 = zF_5FE51158_matchFlag(zT_289, zT_290);
    zT_288 = zT_291;
    goto z_bb_49;
    z_bb_48:
    zT_288 = 1;
    goto z_bb_49;
    z_bb_49:
    if (zT_288) goto z_bb_50; else goto z_bb_52;
    z_bb_50:
    cli.quiet = (unsigned char)(1);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_43;
    z_bb_52:
    zT_293 = arg;
    zT_294 = s_test;
    zT_295 = zF_5FE51158_matchFlag(zT_293, zT_294);
    if (zT_295) goto z_bb_53; else goto z_bb_55;
    z_bb_53:
    cli.test_mode = (unsigned char)(1);
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_297 = arg;
    zT_298 = s_sanity_test;
    zT_299 = zF_5FE51158_matchFlag(zT_297, zT_298);
    if (zT_299) goto z_bb_56; else goto z_bb_58;
    z_bb_56:
    cli.sanity_test_mode = (unsigned char)(1);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_54;
    z_bb_58:
    zT_301 = arg;
    zT_302 = s_warnings;
    zT_303 = zF_5FE51158_matchFlag(zT_301, zT_302);
    if (zT_303) goto z_bb_60; else goto z_bb_59;
    z_bb_59:
    zT_305 = arg;
    zT_306 = s_W;
    zT_307 = zF_5FE51158_matchFlag(zT_305, zT_306);
    zT_304 = zT_307;
    goto z_bb_61;
    z_bb_60:
    zT_304 = 1;
    goto z_bb_61;
    z_bb_61:
    if (zT_304) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    cli.warnings_as_errors = (unsigned char)(1);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_57;
    z_bb_64:
    zT_309 = arg;
    zT_310 = s_color;
    zT_311 = zF_5FE51158_matchFlag(zT_309, zT_310);
    if (zT_311) goto z_bb_65; else goto z_bb_67;
    z_bb_65:
    zT_312 = 1;
    zT_314 = i + (int)((int)zT_312);
    i = zT_314;
    if ((unsigned char)(i < argc)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_320 = arg;
    zT_321 = s_error_format;
    zT_322 = zF_5FE51158_matchFlag(zT_320, zT_321);
    if (zT_322) goto z_bb_70; else goto z_bb_72;
    z_bb_68:
    zT_317 = i;
    zT_318 = zF_70B5BFF1_argGet(zT_317);
    zT_316 = zT_318;
    zT_319 = zF_05AD3AFC_parseColorMode(zT_316);
    cli.color = zT_319;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_66;
    z_bb_70:
    zT_323 = 1;
    zT_325 = i + (int)((int)zT_323);
    i = zT_325;
    if ((unsigned char)(i < argc)) goto z_bb_73; else goto z_bb_74;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_331 = arg;
    zT_332 = s_track_memory;
    zT_333 = zF_5FE51158_matchFlag(zT_331, zT_332);
    if (zT_333) goto z_bb_75; else goto z_bb_77;
    z_bb_73:
    zT_328 = i;
    zT_329 = zF_70B5BFF1_argGet(zT_328);
    zT_327 = zT_329;
    zT_330 = zF_A4602959_parseErrorFormat(zT_327);
    cli.error_format = zT_330;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    cli.track_memory = (unsigned char)(1);
    goto z_bb_76;
    z_bb_76:
    goto z_bb_71;
    z_bb_77:
    zT_335 = arg;
    zT_336 = s_no_null;
    zT_337 = zF_5FE51158_matchFlag(zT_335, zT_336);
    if (zT_337) goto z_bb_78; else goto z_bb_80;
    z_bb_78:
    cli.no_null_check = (unsigned char)(1);
    goto z_bb_79;
    z_bb_79:
    goto z_bb_76;
    z_bb_80:
    zT_339 = arg;
    zT_340 = s_no_lifetime;
    zT_341 = zF_5FE51158_matchFlag(zT_339, zT_340);
    if (zT_341) goto z_bb_81; else goto z_bb_83;
    z_bb_81:
    cli.no_lifetime_check = (unsigned char)(1);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    zT_343 = arg;
    zT_344 = s_no_leak;
    zT_345 = zF_5FE51158_matchFlag(zT_343, zT_344);
    if (zT_345) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    cli.no_leak_check = (unsigned char)(1);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_347 = arg;
    zT_348 = s_warn_all;
    zT_349 = zF_5FE51158_matchFlag(zT_347, zT_348);
    if (zT_349) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    cli.warn_all = (unsigned char)(1);
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_351 = arg;
    zT_352 = s_warn_error;
    zT_353 = zF_5FE51158_matchFlag(zT_351, zT_352);
    if (zT_353) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    cli.warnings_as_errors = (unsigned char)(1);
    cli.warn_error = (unsigned char)(1);
    goto z_bb_91;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_356 = arg;
    zT_357 = s_markers;
    zT_358 = zF_5FE51158_matchFlag(zT_356, zT_357);
    if (zT_358) goto z_bb_93; else goto z_bb_95;
    z_bb_93:
    cli.show_markers = (unsigned char)(1);
    goto z_bb_94;
    z_bb_94:
    goto z_bb_91;
    z_bb_95:
    zT_360 = arg;
    zT_361 = s_include;
    zT_362 = zF_5FE51158_matchFlag(zT_360, zT_361);
    if (zT_362) goto z_bb_97; else goto z_bb_96;
    z_bb_96:
    zT_364 = arg;
    zT_365 = s_lib_dir;
    zT_366 = zF_5FE51158_matchFlag(zT_364, zT_365);
    zT_363 = zT_366;
    goto z_bb_98;
    z_bb_97:
    zT_363 = 1;
    goto z_bb_98;
    z_bb_98:
    if (zT_363) goto z_bb_99; else goto z_bb_101;
    z_bb_99:
    zT_367 = 1;
    zT_369 = i + (int)((int)zT_367);
    i = zT_369;
    if ((unsigned char)(i < argc)) goto z_bb_102; else goto z_bb_103;
    z_bb_100:
    goto z_bb_94;
    z_bb_101:
    zT_386 = arg;
    zT_387 = s_osl;
    zT_388 = zF_5FE51158_matchFlag(zT_386, zT_387);
    if (zT_388) goto z_bb_107; else goto z_bb_109;
    z_bb_102:
    zT_372 = cli.include_count;
    zT_373 = 16;
    zT_371 = zT_372 < (unsigned int)zT_373;
    goto z_bb_104;
    z_bb_103:
    zT_371 = 0;
    goto z_bb_104;
    z_bb_104:
    if (zT_371) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_376 = i;
    zT_377 = zF_70B5BFF1_argGet(zT_376);
    zT_375 = zT_377;
    zT_378 = zF_22D0470E_cstrToSlice(zT_375);
    zT_379 = cli.include_dirs;
    zT_380 = cli.include_count;
    zT_381 = (unsigned int)zT_380;
    zT_379[zT_381] = zT_378;
    zT_382 = cli.include_count;
    zT_383 = 1;
    cli.include_count = (unsigned int)(zT_382 + (unsigned int)((unsigned int)zT_383));
    goto z_bb_106;
    z_bb_106:
    goto z_bb_100;
    z_bb_107:
    cli.target_is_windows = (unsigned char)(0);
    goto z_bb_108;
    z_bb_108:
    goto z_bb_100;
    z_bb_109:
    zT_390 = arg;
    zT_391 = s_osw;
    zT_392 = zF_5FE51158_matchFlag(zT_390, zT_391);
    if (zT_392) goto z_bb_110; else goto z_bb_112;
    z_bb_110:
    cli.target_is_windows = (unsigned char)(1);
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    zT_396 = 1;
    if ((unsigned char)((int)(i + zT_396) < argc)) goto z_bb_113; else goto z_bb_114;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_432 = arg;
    zT_433 = s_target;
    zT_434 = zF_5FE51158_matchFlag(zT_432, zT_433);
    if (zT_434) goto z_bb_125; else goto z_bb_127;
    z_bb_113:
    zT_402 = 1;
    zT_404 = zF_70B5BFF1_argGet((int)(i + zT_402));
    zT_400 = zT_404;
    zT_405 = zF_22D0470E_cstrToSlice(zT_400);
    nxt = zT_405;
    zT_407 = nxt.len;
    zT_408 = 0;
    if ((unsigned char)(zT_407 > (unsigned int)zT_408)) goto z_bb_115; else goto z_bb_116;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_411 = nxt.ptr;
    zT_412 = 0;
    zT_413 = zT_411[zT_412];
    zT_410 = zT_413 != (unsigned char)(45);
    goto z_bb_117;
    z_bb_116:
    zT_410 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_410) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_416 = nxt;
    zT_417 = s_profile_9x;
    zT_418 = zF_5FE51158_matchFlag(zT_416, zT_417);
    if (zT_418) goto z_bb_120; else goto z_bb_122;
    z_bb_119:
    goto z_bb_114;
    z_bb_120:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    zT_421 = 1;
    zT_423 = i + (int)((int)zT_421);
    i = zT_423;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_424 = nxt;
    zT_425 = s_profile_nt;
    zT_426 = zF_5FE51158_matchFlag(zT_424, zT_425);
    if (zT_426) goto z_bb_123; else goto z_bb_124;
    z_bb_123:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_nt);
    zT_429 = 1;
    zT_431 = i + (int)((int)zT_429);
    i = zT_431;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_435 = 1;
    zT_437 = i + (int)((int)zT_435);
    i = zT_437;
    if ((unsigned char)(i < argc)) goto z_bb_128; else goto z_bb_129;
    z_bb_126:
    goto z_bb_111;
    z_bb_127:
    zT_446 = arg;
    zT_447 = s_ffast;
    zT_448 = zF_5FE51158_matchFlag(zT_446, zT_447);
    if (zT_448) goto z_bb_132; else goto z_bb_134;
    z_bb_128:
    zT_440 = i;
    zT_441 = zF_70B5BFF1_argGet(zT_440);
    zT_439 = zT_441;
    zT_442 = zF_06CC17EA_parseTargetIsWindow(zT_439);
    cli.target_is_windows = zT_442;
    zT_443 = cli.target_is_windows;
    if (zT_443) goto z_bb_130; else goto z_bb_131;
    z_bb_129:
    goto z_bb_126;
    z_bb_130:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    goto z_bb_131;
    z_bb_131:
    goto z_bb_129;
    z_bb_132:
    cli.safe_checks = (unsigned char)(0);
    goto z_bb_133;
    z_bb_133:
    goto z_bb_126;
    z_bb_134:
    zT_450 = arg;
    zT_451 = s_fsafe;
    zT_452 = zF_5FE51158_matchFlag(zT_450, zT_451);
    if (zT_452) goto z_bb_135; else goto z_bb_137;
    z_bb_135:
    cli.safe_checks = (unsigned char)(1);
    goto z_bb_136;
    z_bb_136:
    goto z_bb_133;
    z_bb_137:
    zT_454 = arg_ptr;
    zT_455 = zF_22D0470E_cstrToSlice(zT_454);
    cli.input_file = zT_455;
    goto z_bb_136;
}

/* matchFlag */
unsigned char zF_5FE51158_matchFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg, zT_8F083A69_Slice_zT_0B42B2F8_u flag) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    int zT_20;
    unsigned int zT_22;
    unsigned int j;
    zT_3 = arg.len;
    zT_5 = flag.len;
    if ((unsigned char)(zT_3 != zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    j = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = arg.len;
    if ((unsigned char)(j < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = arg.ptr;
    zT_15 = zT_14[j];
    zT_16 = flag.ptr;
    zT_17 = zT_16[j];
    if ((unsigned char)(zT_15 != zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_20 = 1;
    zT_22 = j + (unsigned int)((unsigned int)zT_20);
    j = zT_22;
    goto z_bb_6;
}

/* matchMMFlag */
unsigned char zF_FBF91F7E_matchMMFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mm;
    unsigned int j;
    zT_2 = "-mm";
    zT_4 = 3;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_mm = zT_3;
    zT_6 = arg.len;
    zT_8 = s_mm.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_mm.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_mm.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* cstrToSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D0470E_cstrToSlice(unsigned char* ptr) {
    int zT_2;
    unsigned int zT_3;
    unsigned char zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int len;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    len = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ptr[len];
    zT_5 = 0;
    if ((unsigned char)(zT_4 != zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    zT_9 = len + (unsigned int)((unsigned int)zT_7);
    len = zT_9;
    goto z_bb_4;
    z_bb_3:
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    return zT_13;
    z_bb_4:
    goto z_bb_1;
}

/* parseSize */
unsigned int zF_6CF11065_parseSize(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    unsigned char zT_29;
    int zT_32;
    unsigned int zT_33;
    unsigned char zT_36;
    int zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned char zT_45;
    int zT_48;
    int zT_50;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_54 = 1;
    zT_56 = i + (unsigned int)((unsigned int)zT_54);
    i = zT_56;
    goto z_bb_4;
    z_bb_10:
    if ((unsigned char)(c == (unsigned char)(107))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_29 = c == (unsigned char)(75);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_32 = 1024;
    zT_33 = val * zT_32;
    val = zT_33;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    if ((unsigned char)(c == (unsigned char)(109))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_36 = c == (unsigned char)(77);
    goto z_bb_19;
    z_bb_18:
    zT_36 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_36) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_39 = 1024;
    zT_41 = 1024;
    zT_42 = (unsigned int)(val * zT_39) * zT_41;
    val = zT_42;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    if ((unsigned char)(c == (unsigned char)(103))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_45 = c == (unsigned char)(71);
    goto z_bb_25;
    z_bb_24:
    zT_45 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_45) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_48 = 1024;
    zT_50 = 1024;
    zT_52 = 1024;
    zT_53 = (unsigned int)((unsigned int)(val * zT_48) * zT_50) * zT_52;
    val = zT_53;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_21;
}

/* parseU32 */
unsigned int zF_16BBA09E_parseU32(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_4;
}

/* parseMMBytes */
unsigned int zF_B9231BB9_parseMMBytes(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned char* zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    int zT_26;
    unsigned int zT_28;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_39;
    int zT_40;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int max_mb;
    unsigned int i;
    unsigned int n;
    unsigned int mb;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_5 = (unsigned int)(unsigned int)(256);
    max_mb = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    n = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    mb = zT_14;
    goto z_bb_1;
    z_bb_1:
    zT_16 = rest.len;
    if ((unsigned char)(i < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_19 = rest.ptr;
    zT_20 = zT_19[i];
    c = zT_20;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_40 = 0;
    if ((unsigned char)(n == (unsigned int)zT_40)) goto z_bb_15; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_23 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_23 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_26 = 1;
    zT_28 = n + (unsigned int)((unsigned int)zT_26);
    n = zT_28;
    if ((unsigned char)(mb < max_mb)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = (unsigned int)(mb * (unsigned int)(10)) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    mb = zT_35;
    if ((unsigned char)(mb > max_mb)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_4;
    z_bb_12:
    mb = max_mb;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    zT_44 = rest.len;
    zT_42 = i != zT_44;
    goto z_bb_16;
    z_bb_15:
    zT_42 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_47 = "error: -mm<N> requires a decimal MB size (e.g. -mm64)\n";
    zT_49 = 54;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    em = zT_48;
    zT_50 = em;
    zF_E4B2EF19_stderr_write(zT_50);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_18:
    return (unsigned int)(mb * (unsigned int)(1024));
}

/* matchSFlag */
unsigned char zF_C4E3C361_matchSFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_s;
    unsigned int j;
    zT_2 = "-s";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_s = zT_3;
    zT_6 = arg.len;
    zT_8 = s_s.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_s.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_s.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* parseSLevel */
unsigned int zF_153C3795_parseSLevel(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    int zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_32;
    unsigned int zT_36;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_43;
    int zT_44;
    unsigned char zT_46;
    unsigned int zT_48;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_58;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int i;
    unsigned int n;
    unsigned int level;
    unsigned int over;
    unsigned char c;
    unsigned int d;
    unsigned int nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    n = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    level = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    over = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_14 = rest.len;
    if ((unsigned char)(i < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = rest.ptr;
    zT_18 = zT_17[i];
    c = zT_18;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_44 = 0;
    if ((unsigned char)(n == (unsigned int)zT_44)) goto z_bb_16; else goto z_bb_15;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_21 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_21 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_21) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_24 = 1;
    zT_26 = n + (unsigned int)((unsigned int)zT_24);
    n = zT_26;
    zT_27 = 0;
    if ((unsigned char)(over == (unsigned int)zT_27)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_32;
    zT_36 = (unsigned int)(level * (unsigned int)(10)) + d;
    nl = zT_36;
    if ((unsigned char)(nl > (unsigned int)(6))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_4;
    z_bb_12:
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    over = zT_40;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    level = nl;
    goto z_bb_13;
    z_bb_15:
    zT_48 = rest.len;
    zT_46 = i != zT_48;
    goto z_bb_17;
    z_bb_16:
    zT_46 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_46) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_51 = "error: -s<N> requires a decimal level 0..6 (e.g. -s0 all on disk, -s6 all in RAM)\n";
    zT_53 = 82;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    em = zT_52;
    zT_54 = em;
    zF_E4B2EF19_stderr_write(zT_54);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_19:
    zT_58 = 0;
    if ((unsigned char)(over != (unsigned int)zT_58)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = "error: -s<N> spill level out of range (0..6: 0 = all on disk, 6 = all in RAM)\n";
    zT_63 = 78;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    em = zT_62;
    zT_64 = em;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_21:
    return level;
}

/* parseColorMode */
zT_CAF40AAB_ColorMode zF_05AD3AFC_parseColorMode(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_always;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_never;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "always";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_always = zT_6;
    zT_9 = "never";
    zT_11 = 5;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_never = zT_10;
    zT_12 = s;
    zT_13 = s_always;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_always);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_never;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_never);
    z_bb_4:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_auto);
}

/* parseErrorFormat */
zT_A4FB690E_ErrorFormat zF_A4602959_parseErrorFormat(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_json;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sarif;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "json";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_json = zT_6;
    zT_9 = "sarif";
    zT_11 = 5;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_sarif = zT_10;
    zT_12 = s;
    zT_13 = s_json;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_json);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_sarif;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_sarif);
    z_bb_4:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_human);
}

/* parseTargetIsWindows */
unsigned char zF_06CC17EA_parseTargetIsWindow(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_linux;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_windows;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "linux";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_linux = zT_6;
    zT_9 = "windows";
    zT_11 = 7;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_windows = zT_10;
    zT_12 = s;
    zT_13 = s_windows;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_linux;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_21 = "error: --target must be 'linux' or 'windows'\n";
    zT_23 = 45;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    err_msg = zT_22;
    zT_24 = err_msg;
    zF_E4B2EF19_stderr_write(zT_24);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned char)(0);
}

/* writeU32 */
void zF_266B1B8E_writeU32(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_11;
    int zT_15;
    int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    unsigned char zT_23;
    int zT_24;
    int zT_26;
    unsigned int zT_28;
    int zT_29;
    int zT_30;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 16;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    v = val;
    zT_7 = 0;
    if ((unsigned char)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 48;
    zT_10 = (unsigned char)zT_9;
    zT_11 = 15;
    buf[zT_11] = zT_10;
    zT_15 = 16;
    zT_16 = 15;
    zT_17 = (unsigned char*)((unsigned char*)buf) + zT_16;
    zT_18 = zT_15 - zT_16;
    zT_19.ptr = zT_17;
    zT_19.len = zT_18;
    s = zT_19;
    zT_20 = s;
    zF_B5478454_measureMarkerWrite(zT_20);
    return;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_21 = 0;
    if ((unsigned char)(v > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_26 = 1;
    zT_28 = i - (unsigned int)((unsigned int)zT_26);
    i = zT_28;
    zT_29 = 48;
    zT_30 = 10;
    zT_35 = (unsigned char)(unsigned int)((unsigned int)(unsigned int)(zT_29 + (unsigned int)((unsigned int)(unsigned int)(v % zT_30))));
    buf[i] = zT_35;
    zT_36 = 10;
    zT_37 = v / zT_36;
    v = zT_37;
    goto z_bb_6;
    z_bb_5:
    zT_41 = 16;
    zT_42 = (unsigned char*)((unsigned char*)buf) + i;
    zT_43 = zT_41 - i;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    s = zT_44;
    zT_45 = s;
    zF_B5478454_measureMarkerWrite(zT_45);
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_24 = 0;
    zT_23 = i > (unsigned int)zT_24;
    goto z_bb_9;
    z_bb_8:
    zT_23 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_23) goto z_bb_4; else goto z_bb_5;
}

/* printUsage */
void zF_9D45DFBF_printUsage(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help3;
    zT_8F083A69_Slice_zT_0B42B2F8_u os_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u osw_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u tgt_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u io_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u mem_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u quiet_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u mode_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u warn_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u warn_all_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u diag_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u track_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u checks_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u markers_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u inc_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u safe_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u fast_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u help_help;
    zT_1 = "zig1 - Z98 self-hosted compiler - usage: zig1 [options] <input.zig>\n";
    zT_3 = 68;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_6 = "  -mm<N>    hard pool budget in MB (default 64; pool.peak over budget -> ICE rc=3)\n";
    zT_8 = 83;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    mm_help = zT_7;
    zT_9 = mm_help;
    zF_E4B2EF19_stderr_write(zT_9);
    zT_11 = "  -s<N>     spill level 0..6 (default 0 = all spills on disk; -s1..-s6 deactivate the\n";
    zT_13 = 86;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    s_help = zT_12;
    zT_14 = s_help;
    zF_E4B2EF19_stderr_write(zT_14);
    zT_16 = "            first N spills to RAM in order AST,LIR,HASH,RES,SIDE,EXTRA: higher -s = more RAM,\n";
    zT_18 = 94;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    s_help2 = zT_17;
    zT_19 = s_help2;
    zF_E4B2EF19_stderr_write(zT_19);
    zT_21 = "            less disk I/O (pool= rises; -s6 = all in RAM -> pair with -mm128)\n";
    zT_23 = 78;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    s_help3 = zT_22;
    zT_24 = s_help3;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_26 = "  -osl      compile target = linux (default)\n";
    zT_28 = 45;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    os_help = zT_27;
    zT_29 = os_help;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_31 = "  -osw [9x|nt]  compile target = windows (default 9x = Win9x; nt = NT/XP profile)\n";
    zT_33 = 82;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    osw_help = zT_32;
    zT_34 = osw_help;
    zF_E4B2EF19_stderr_write(zT_34);
    zT_36 = "  --target <linux|windows>  long-form target alias for -osl/-osw (windows = 9x default)\n";
    zT_38 = 88;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    tgt_help = zT_37;
    zT_39 = tgt_help;
    zF_E4B2EF19_stderr_write(zT_39);
    zT_41 = "  -o, --output-dir <dir>    output directory (default .)\n";
    zT_43 = 57;
    zT_42.ptr = zT_41;
    zT_42.len = zT_43;
    io_help = zT_42;
    zT_44 = io_help;
    zF_E4B2EF19_stderr_write(zT_44);
    zT_46 = "  -m, --max-mem <size>      hard pool budget with k/m/g suffix (same as -mm<N>)\n";
    zT_48 = 80;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    mem_help = zT_47;
    zT_49 = mem_help;
    zF_E4B2EF19_stderr_write(zT_49);
    zT_51 = "  -e, --max-errors <n>      max diagnostics (default 256)\n";
    zT_53 = 58;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    err_help = zT_52;
    zT_54 = err_help;
    zF_E4B2EF19_stderr_write(zT_54);
    zT_56 = "  -q, --quiet               suppress non-error output\n";
    zT_58 = 54;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    quiet_help = zT_57;
    zT_59 = quiet_help;
    zF_E4B2EF19_stderr_write(zT_59);
    zT_61 = "  --test                    run test blocks\n  --sanity-test             lexer sanity test\n";
    zT_63 = 90;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    mode_help = zT_62;
    zT_64 = mode_help;
    zF_E4B2EF19_stderr_write(zT_64);
    zT_66 = "  -W, --warnings-as-errors  treat warnings as errors; --warn-error also sets warn_error\n";
    zT_68 = 88;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    warn_help = zT_67;
    zT_69 = warn_help;
    zF_E4B2EF19_stderr_write(zT_69);
    zT_71 = "  --warn-all                enable all warnings\n";
    zT_73 = 48;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    warn_all_help = zT_72;
    zT_74 = warn_all_help;
    zF_E4B2EF19_stderr_write(zT_74);
    zT_76 = "  --color <auto|always|never>  diagnostic color mode (default auto)\n";
    zT_78 = 68;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    diag_help = zT_77;
    zT_79 = diag_help;
    zF_E4B2EF19_stderr_write(zT_79);
    zT_81 = "  --error-format <human|json|sarif>  diagnostic format (default human)\n";
    zT_83 = 71;
    zT_82.ptr = zT_81;
    zT_82.len = zT_83;
    fmt_help = zT_82;
    zT_84 = fmt_help;
    zF_E4B2EF19_stderr_write(zT_84);
    zT_86 = "  --track-memory            report peak memory\n";
    zT_88 = 47;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    track_help = zT_87;
    zT_89 = track_help;
    zF_E4B2EF19_stderr_write(zT_89);
    zT_91 = "  --no-null-check | --no-lifetime-check | --no-leak-check  disable those checks\n";
    zT_93 = 80;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    checks_help = zT_92;
    zT_94 = checks_help;
    zF_E4B2EF19_stderr_write(zT_94);
    zT_96 = "  --markers                 emit phase markers\n";
    zT_98 = 47;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    markers_help = zT_97;
    zT_99 = markers_help;
    zF_E4B2EF19_stderr_write(zT_99);
    zT_101 = "  -I <dir>, --lib-dir <dir> add an include/library directory (max 16)\n";
    zT_103 = 70;
    zT_102.ptr = zT_101;
    zT_102.len = zT_103;
    inc_help = zT_102;
    zT_104 = inc_help;
    zF_E4B2EF19_stderr_write(zT_104);
    zT_106 = "  -fsafe                    enable runtime checks + undefined poison (default)\n";
    zT_108 = 79;
    zT_107.ptr = zT_106;
    zT_107.len = zT_108;
    safe_help = zT_107;
    zT_109 = safe_help;
    zF_E4B2EF19_stderr_write(zT_109);
    zT_111 = "  -ffast                    disable runtime checks + undefined poison\n";
    zT_113 = 70;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    fast_help = zT_112;
    zT_114 = fast_help;
    zF_E4B2EF19_stderr_write(zT_114);
    zT_116 = "  --dump-c89                emit C89 into the output directory\n";
    zT_118 = 63;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    c89_help = zT_117;
    zT_119 = c89_help;
    zF_E4B2EF19_stderr_write(zT_119);
    zT_121 = "  --help                    show this help\n";
    zT_123 = 43;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    help_help = zT_122;
    zT_124 = help_help;
    zF_E4B2EF19_stderr_write(zT_124);
    return;
}

/* __module_init */
void zF_780653D2___module_init(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_69057089_CompilerAlloc zT_1 = {0};
    zT_D3EB6303_StringInterner zT_2 = {0};
    zT_227EDE07_SourceManager zT_3 = {0};
    zT_F85C5DED_DiagnosticCollector zT_4 = {0};
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6 = 0;
    zT_072B53A6_ModuleRegistry zT_7 = {0};
    zT_338B7C76_TypeRegistry zT_8 = {0};
    zT_6B356268_SemanticContext zT_9 = {0};
    zT_02EB57B2_LirLowerer zT_10 = {0};
    zT_CA01C129_LirSlotArrayList zT_11 = {0};
    zT_8EED1867_ResolvedTypeTable zT_12 = {0};
    zT_66E7D2EF_CoercionTable zT_13 = {0};
    zT_3D7259E2_SymbolRegistry zT_14 = {0};
    zT_8143F551_AstKind zT_15 = 0;
    zT_6B0A7D14_AstStore zT_16 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_69057089_CompilerAlloc = zT_1;
    zG_D3EB6303_StringInterner = zT_2;
    zG_227EDE07_SourceManager = zT_3;
    zG_F85C5DED_DiagnosticCollector = zT_4;
    zG_3A355BD2_Token = zT_5;
    zG_EAC3E484_TokenKind = zT_6;
    zG_072B53A6_ModuleRegistry = zT_7;
    zG_338B7C76_TypeRegistry = zT_8;
    zG_6B356268_SemanticContext = zT_9;
    zG_02EB57B2_LirLowerer = zT_10;
    zG_CA01C129_LirSlotArrayList = zT_11;
    zG_8EED1867_ResolvedTypeTable = zT_12;
    zG_66E7D2EF_CoercionTable = zT_13;
    zG_3D7259E2_SymbolRegistry = zT_14;
    zG_8143F551_AstKind = zT_15;
    zG_6B0A7D14_AstStore = zT_16;
    return;
}

/* EOF */
