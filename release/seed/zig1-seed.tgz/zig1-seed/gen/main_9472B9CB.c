#include "main_9472B9CB.h"
/* main */
void zF_EA90E208_main(int argc, unsigned char** argv) {
    int zT_2;
    unsigned char** zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_C98AF326_CompilerCli zT_10 = {0};
    unsigned char zT_11;
    unsigned char zT_14;
    zT_69057089_CompilerAlloc zT_16 = {0};
    zT_3E40CD83_Sand* zT_18;
    zT_69057089_CompilerAlloc* zT_20;
    int zT_22;
    zT_D3EB6303_StringInterner zT_24 = {0};
    zT_3E40CD83_Sand* zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_227EDE07_SourceManager zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_227EDE07_SourceManager* zT_32;
    zT_D3EB6303_StringInterner* zT_33;
    zT_69057089_CompilerAlloc* zT_34;
    zT_3E40CD83_Sand* zT_39;
    zT_69057089_CompilerAlloc* zT_40;
    unsigned char zT_42;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_53;
    int zT_54;
    unsigned char zT_56;
    unsigned char zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char zT_60 = 0;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_69057089_CompilerAlloc zT_77 = {0};
    unsigned int zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_3E40CD83_Sand* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    zT_69057089_CompilerAlloc* zT_85;
    zT_93D5F0E8_Opt_454 zT_87 = {0};
    unsigned char zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_101;
    unsigned int zT_104;
    unsigned int zT_108;
    unsigned int zT_111;
    unsigned int zT_114;
    unsigned int zT_117;
    unsigned int zT_120;
    unsigned int zT_123;
    unsigned int zT_126;
    unsigned int zT_129;
    unsigned int zT_132;
    unsigned int zT_135;
    unsigned int zT_138;
    zT_3E40CD83_Sand* zT_140;
    unsigned int zT_141;
    zT_69057089_CompilerAlloc* zT_142;
    zT_D3EB6303_StringInterner zT_144 = {0};
    zT_3E40CD83_Sand* zT_146;
    zT_69057089_CompilerAlloc* zT_147;
    zT_227EDE07_SourceManager zT_149 = {0};
    zT_3E40CD83_Sand* zT_151;
    zT_227EDE07_SourceManager* zT_152;
    zT_D3EB6303_StringInterner* zT_153;
    zT_69057089_CompilerAlloc* zT_154;
    zT_F85C5DED_DiagnosticCollector zT_158 = {0};
    unsigned int zT_159;
    zT_3E40CD83_Sand* zT_161;
    zT_69057089_CompilerAlloc* zT_162;
    zT_CEC2984A_NameMangler zT_165 = {0};
    zT_3E40CD83_Sand* zT_167;
    zT_D3EB6303_StringInterner* zT_168;
    zT_F85C5DED_DiagnosticCollector* zT_169;
    zT_69057089_CompilerAlloc* zT_170;
    zT_072B53A6_ModuleRegistry zT_174 = {0};
    zT_072B53A6_ModuleRegistry* zT_175;
    zT_227EDE07_SourceManager* zT_176;
    zT_7D82FE60_GrowableSand zT_180 = {0};
    unsigned char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    zT_7D82FE60_GrowableSand* zT_185;
    zT_3E40CD83_Sand* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    zT_3E40CD83_Sand* zT_190 = 0;
    int zT_191;
    zT_3E40CD83_Sand* zT_194;
    zT_D3EB6303_StringInterner* zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    zT_7D82FE60_GrowableSand* zT_198;
    zT_338B7C76_TypeRegistry zT_201 = {0};
    zT_338B7C76_TypeRegistry* zT_202;
    zT_3E40CD83_Sand* zT_205;
    zT_69057089_CompilerAlloc* zT_206;
    zT_6B0A7D14_AstStore zT_208 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_210;
    unsigned int zT_212;
    unsigned char zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_217;
    unsigned int zT_219;
    unsigned char zT_221;
    unsigned char* zT_224;
    unsigned char zT_225;
    unsigned int zT_227;
    unsigned int zT_229;
    unsigned char zT_230;
    unsigned int zT_232;
    unsigned char zT_233;
    unsigned int zT_235;
    unsigned char zT_236;
    unsigned int zT_238;
    unsigned char* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    unsigned int zT_244;
    unsigned int zT_246;
    unsigned char zT_248;
    unsigned char* zT_251;
    unsigned char zT_252;
    unsigned int zT_254;
    unsigned int zT_256;
    zT_6B0A7D14_AstStore* zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    int zT_262;
    unsigned char* zT_263;
    unsigned int zT_264;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    zT_846744CC_Arr_unsigned_char_5 zT_267;
    unsigned int zT_269;
    unsigned char zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_274;
    unsigned int zT_276;
    unsigned char zT_278;
    unsigned char* zT_281;
    unsigned char zT_282;
    unsigned int zT_284;
    unsigned int zT_286;
    unsigned char zT_287;
    unsigned int zT_289;
    unsigned char zT_290;
    unsigned int zT_292;
    unsigned char zT_293;
    unsigned int zT_295;
    unsigned char* zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    unsigned int zT_299;
    unsigned int zT_301;
    unsigned int zT_303;
    unsigned char zT_305;
    unsigned char* zT_308;
    unsigned char zT_309;
    unsigned int zT_311;
    unsigned int zT_313;
    zT_6B0A7D14_AstStore* zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    int zT_321;
    unsigned char* zT_322;
    unsigned int zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    zT_846744CC_Arr_unsigned_char_5 zT_326;
    unsigned int zT_328;
    unsigned char zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_333;
    unsigned int zT_335;
    unsigned char zT_337;
    unsigned char* zT_340;
    unsigned char zT_341;
    unsigned int zT_343;
    unsigned int zT_345;
    unsigned char zT_346;
    unsigned int zT_348;
    unsigned char zT_349;
    unsigned int zT_351;
    unsigned char zT_352;
    unsigned int zT_354;
    unsigned char* zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned int zT_358;
    unsigned int zT_360;
    unsigned int zT_362;
    unsigned char zT_364;
    unsigned char* zT_367;
    unsigned char zT_368;
    unsigned int zT_370;
    unsigned int zT_372;
    zT_6B0A7D14_AstStore* zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    int zT_380;
    unsigned char* zT_381;
    unsigned int zT_382;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_383;
    zT_846744CC_Arr_unsigned_char_5 zT_385;
    unsigned int zT_387;
    unsigned char zT_388;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_390;
    unsigned int zT_392;
    unsigned int zT_394;
    unsigned char zT_396;
    unsigned char* zT_399;
    unsigned char zT_400;
    unsigned int zT_402;
    unsigned int zT_404;
    unsigned char zT_405;
    unsigned int zT_407;
    unsigned char zT_408;
    unsigned int zT_410;
    unsigned char zT_411;
    unsigned int zT_413;
    unsigned char* zT_415;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    unsigned int zT_417;
    unsigned int zT_419;
    unsigned int zT_421;
    unsigned char zT_423;
    unsigned char* zT_426;
    unsigned char zT_427;
    unsigned int zT_429;
    unsigned int zT_431;
    zT_6B0A7D14_AstStore* zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    int zT_439;
    unsigned char* zT_440;
    unsigned int zT_441;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_442;
    zT_846744CC_Arr_unsigned_char_5 zT_444;
    unsigned int zT_446;
    unsigned char zT_447;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_449;
    unsigned int zT_451;
    unsigned int zT_453;
    unsigned char zT_455;
    unsigned char* zT_458;
    unsigned char zT_459;
    unsigned int zT_461;
    unsigned int zT_463;
    unsigned char zT_464;
    unsigned int zT_466;
    unsigned char zT_467;
    unsigned int zT_469;
    unsigned char zT_470;
    unsigned int zT_472;
    unsigned char* zT_474;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_475;
    unsigned int zT_476;
    unsigned int zT_478;
    unsigned int zT_480;
    unsigned char zT_482;
    unsigned char* zT_485;
    unsigned char zT_486;
    unsigned int zT_488;
    unsigned int zT_490;
    zT_6B0A7D14_AstStore* zT_491;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_493;
    int zT_498;
    unsigned char* zT_499;
    unsigned int zT_500;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_501;
    zT_3E40CD83_Sand* zT_503;
    zT_69057089_CompilerAlloc* zT_504;
    zT_3D7259E2_SymbolRegistry zT_506 = {0};
    zT_3E40CD83_Sand* zT_508;
    zT_69057089_CompilerAlloc* zT_509;
    zT_8EED1867_ResolvedTypeTable zT_511 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_513;
    unsigned int zT_515;
    unsigned char zT_516;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_518;
    unsigned int zT_520;
    unsigned int zT_522;
    unsigned char zT_524;
    unsigned char* zT_527;
    unsigned char zT_528;
    unsigned int zT_530;
    unsigned int zT_532;
    unsigned char zT_533;
    unsigned int zT_535;
    unsigned char zT_536;
    unsigned int zT_538;
    unsigned char zT_539;
    unsigned int zT_541;
    unsigned char* zT_543;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_544;
    unsigned int zT_545;
    unsigned int zT_547;
    unsigned int zT_549;
    unsigned char zT_551;
    unsigned char* zT_554;
    unsigned char zT_555;
    unsigned int zT_557;
    unsigned int zT_559;
    zT_8EED1867_ResolvedTypeTable* zT_560;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_561;
    int zT_565;
    unsigned char* zT_566;
    unsigned int zT_567;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_568;
    zT_3E40CD83_Sand* zT_570;
    zT_69057089_CompilerAlloc* zT_571;
    zT_66E7D2EF_CoercionTable zT_573 = {0};
    zT_3E40CD83_Sand* zT_575;
    zT_69057089_CompilerAlloc* zT_576;
    zT_CA01C129_LirSlotArrayList zT_578 = {0};
    zT_3E40CD83_Sand* zT_580;
    zT_69057089_CompilerAlloc* zT_581;
    zT_4D61441E_DepGraph zT_583 = {0};
    zT_3E40CD83_Sand* zT_585;
    zT_69057089_CompilerAlloc* zT_586;
    zT_21D3708C_U32ToU32Map zT_588 = {0};
    zT_3E40CD83_Sand* zT_590;
    zT_69057089_CompilerAlloc* zT_591;
    zT_21D3708C_U32ToU32Map zT_593 = {0};
    zT_3E40CD83_Sand* zT_595;
    zT_69057089_CompilerAlloc* zT_596;
    zT_21D3708C_U32ToU32Map zT_598 = {0};
    zT_3E40CD83_Sand* zT_600;
    zT_69057089_CompilerAlloc* zT_601;
    zT_21D3708C_U32ToU32Map zT_603 = {0};
    zT_3E40CD83_Sand* zT_605;
    zT_69057089_CompilerAlloc* zT_606;
    zT_21D3708C_U32ToU32Map zT_608 = {0};
    zT_3E40CD83_Sand* zT_610;
    zT_69057089_CompilerAlloc* zT_612;
    zT_77F6F59C_ComptimeFoldTable zT_615 = {0};
    zT_3E40CD83_Sand* zT_617;
    zT_69057089_CompilerAlloc* zT_618;
    zT_A4CE86B7_U64ToU32Map zT_620 = {0};
    zT_3E40CD83_Sand* zT_622;
    zT_69057089_CompilerAlloc* zT_623;
    zT_A4CE86B7_U64ToU32Map zT_625 = {0};
    zT_3E40CD83_Sand* zT_627;
    zT_69057089_CompilerAlloc* zT_628;
    zT_A4CE86B7_U64ToU32Map zT_630 = {0};
    zT_3E40CD83_Sand* zT_632;
    zT_69057089_CompilerAlloc* zT_633;
    zT_A4CE86B7_U64ToU32Map zT_635 = {0};
    zT_3E40CD83_Sand* zT_637;
    zT_69057089_CompilerAlloc* zT_638;
    zT_A4CE86B7_U64ToU32Map zT_640 = {0};
    zT_3E40CD83_Sand* zT_642;
    zT_69057089_CompilerAlloc* zT_643;
    zT_A4CE86B7_U64ToU32Map zT_645 = {0};
    zT_3E40CD83_Sand* zT_647;
    zT_69057089_CompilerAlloc* zT_648;
    zT_A4CE86B7_U64ToU32Map zT_650 = {0};
    zT_3E40CD83_Sand* zT_652;
    zT_69057089_CompilerAlloc* zT_653;
    zT_B687BB96_U32ArrayList zT_655 = {0};
    zT_3E40CD83_Sand* zT_657;
    zT_69057089_CompilerAlloc* zT_658;
    zT_A4CE86B7_U64ToU32Map zT_660 = {0};
    zT_3E40CD83_Sand* zT_662;
    zT_69057089_CompilerAlloc* zT_663;
    zT_A4CE86B7_U64ToU32Map zT_665 = {0};
    zT_3E40CD83_Sand* zT_667;
    zT_69057089_CompilerAlloc* zT_668;
    zT_A4CE86B7_U64ToU32Map zT_670 = {0};
    zT_5AB29387_CompilerContext zT_672;
    zT_69057089_CompilerAlloc* zT_673;
    zT_D3EB6303_StringInterner* zT_674;
    zT_F85C5DED_DiagnosticCollector* zT_675;
    zT_227EDE07_SourceManager* zT_676;
    zT_CEC2984A_NameMangler* zT_677;
    zT_072B53A6_ModuleRegistry* zT_678;
    zT_338B7C76_TypeRegistry* zT_679;
    zT_6B0A7D14_AstStore* zT_680;
    zT_3D7259E2_SymbolRegistry* zT_681;
    zT_8EED1867_ResolvedTypeTable* zT_682;
    zT_66E7D2EF_CoercionTable* zT_683;
    zT_4D61441E_DepGraph* zT_684;
    zT_7E7544E4_LirStream zT_685 = {0};
    int zT_686;
    unsigned int zT_687;
    zT_3E40CD83_Sand* zT_688;
    zT_69057089_CompilerAlloc* zT_689;
    zT_E1A783EF_GlobalDeclArrayList zT_691 = {0};
    zT_3E40CD83_Sand* zT_692;
    zT_69057089_CompilerAlloc* zT_693;
    zT_A4CE86B7_U64ToU32Map zT_695 = {0};
    zT_3E40CD83_Sand* zT_696;
    zT_69057089_CompilerAlloc* zT_697;
    zT_B687BB96_U32ArrayList zT_699 = {0};
    zT_5AB29387_CompilerContext* zT_700;
    zT_8F083A69_Slice_zT_0B42B2F8_u startmsg;
    zT_C98AF326_CompilerCli cli;
    zT_69057089_CompilerAlloc compiler_alloc;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u source;
    unsigned int interner_bc;
    unsigned int type_hint;
    unsigned int name_hint;
    unsigned int fold_hint;
    zT_CEC2984A_NameMangler name_mangler;
    zT_072B53A6_ModuleRegistry mr;
    zT_7D82FE60_GrowableSand type_db_arena;
    zT_8F083A69_Slice_zT_0B42B2F8_u type_db_name;
    zT_338B7C76_TypeRegistry typereg;
    zT_6B0A7D14_AstStore store;
    zT_846744CC_Arr_unsigned_char_5 ast_spill_path;
    unsigned int asp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od2;
    unsigned int oi2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ast_tmp_name;
    unsigned int ati;
    zT_846744CC_Arr_unsigned_char_5 id_spill_path;
    unsigned int idp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od3;
    unsigned int oi3;
    zT_8F083A69_Slice_zT_0B42B2F8_u id_tmp_name;
    unsigned int iti;
    zT_846744CC_Arr_unsigned_char_5 iv_spill_path;
    unsigned int ivp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od5;
    unsigned int oi5;
    zT_8F083A69_Slice_zT_0B42B2F8_u iv_tmp_name;
    unsigned int ivi;
    zT_846744CC_Arr_unsigned_char_5 ec_spill_path;
    unsigned int ecp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od6;
    unsigned int oi6;
    zT_8F083A69_Slice_zT_0B42B2F8_u ec_tmp_name;
    unsigned int eci;
    zT_846744CC_Arr_unsigned_char_5 er_spill_path;
    unsigned int erp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od7;
    unsigned int oi7;
    zT_8F083A69_Slice_zT_0B42B2F8_u er_tmp_name;
    unsigned int eri;
    zT_3D7259E2_SymbolRegistry symbol_reg;
    zT_8EED1867_ResolvedTypeTable resolved_types;
    zT_846744CC_Arr_unsigned_char_5 rtt_spill_path;
    unsigned int rsp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od4;
    unsigned int oi4;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtt_tmp_name;
    unsigned int rti2;
    zT_66E7D2EF_CoercionTable coercion_table;
    zT_CA01C129_LirSlotArrayList lir_slots;
    zT_4D61441E_DepGraph dep_graph;
    zT_21D3708C_U32ToU32Map enum_value_table;
    zT_21D3708C_U32ToU32Map tuple_index_table;
    zT_21D3708C_U32ToU32Map error_code_registry;
    zT_21D3708C_U32ToU32Map call_arg_types;
    zT_21D3708C_U32ToU32Map call_param_map;
    zT_77F6F59C_ComptimeFoldTable comptime_folds;
    zT_A4CE86B7_U64ToU32Map exported;
    zT_A4CE86B7_U64ToU32Map suspending_fns;
    zT_A4CE86B7_U64ToU32Map frame_sizes;
    zT_A4CE86B7_U64ToU32Map state_widths;
    zT_A4CE86B7_U64ToU32Map awaited_fns;
    zT_A4CE86B7_U64ToU32Map async_hidden_fns;
    zT_A4CE86B7_U64ToU32Map driver_targets;
    zT_B687BB96_U32ArrayList parent_result_type_list;
    zT_A4CE86B7_U64ToU32Map parent_result_start;
    zT_A4CE86B7_U64ToU32Map parent_result_count;
    zT_A4CE86B7_U64ToU32Map async_layouts;
    zT_5AB29387_CompilerContext ctx;
    zT_2 = argc;
    zT_3 = argv;
    zF_4DE8E0A6_initArgs(zT_2, zT_3);
    zT_5 = "START\n";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    startmsg = zT_6;
    zT_8 = startmsg;
    zF_48AC7B3A_markerWrite(zT_8);
    zT_10 = zF_6143A521_parseArgs();
    cli = zT_10;
    zT_11 = cli.show_markers;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zF_3C88665D_markersEnabled((unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    zT_14 = cli.sanity_test_mode;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_16;
    zT_20 = &compiler_alloc;
    zT_18 = &zT_20->permanent;
    zT_22 = 4;
    zT_24 = zF_FB2E811D_stringInternerInit(zT_18, (unsigned int)((unsigned int)zT_22));
    interner = zT_24;
    zT_27 = &compiler_alloc;
    zT_26 = &zT_27->permanent;
    zT_29 = zF_01351F51_sourceManagerInit(zT_26);
    source_man = zT_29;
    zT_34 = &compiler_alloc;
    zT_31 = &zT_34->permanent;
    zT_32 = &source_man;
    zT_33 = &interner;
    (void)zF_C7BA7DAB_diagnosticCollector(zT_31, zT_32, zT_33);
    zT_40 = &compiler_alloc;
    zT_39 = &zT_40->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_39);
    zF_519E4401_lexerTestSanityChec();
    return;
    z_bb_4:
    zT_42 = cli.test_mode;
    if (zT_42) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_44 = "error: use test_main.zig for test mode\n";
    zT_46 = 39;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    msg = zT_45;
    zT_47 = msg;
    zF_48AC7B3A_markerWrite(zT_47);
    zT_49 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_49));
    return;
    z_bb_6:
    zT_51 = cli.input_file;
    zT_53 = zT_51.len;
    zT_54 = 0;
    if ((unsigned char)(zT_53 == (unsigned int)zT_54)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zF_9D45DFBF_printUsage();
    return;
    z_bb_8:
    zT_56 = cli.output_dir_set;
    if (zT_56) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_59 = cli.output_dir;
    zT_58 = zT_59;
    zT_60 = zF_8CC05F84_dirExists(zT_58);
    zT_57 = !zT_60;
    goto z_bb_11;
    z_bb_10:
    zT_57 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_57) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63 = "error: output directory does not exist: ";
    zT_65 = 40;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    msg = zT_64;
    zT_66 = msg;
    zF_E4B2EF19_stderr_write(zT_66);
    zT_68 = cli.output_dir;
    zT_67 = zT_68;
    zF_E4B2EF19_stderr_write(zT_67);
    zT_70 = "\n";
    zT_72 = 1;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    nl = zT_71;
    zT_73 = nl;
    zF_E4B2EF19_stderr_write(zT_73);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_13:
    zT_77 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_77;
    zT_78 = cli.max_mem;
    compiler_alloc.max_mem = zT_78;
    zT_79 = cli.spill_level;
    zF_4EDF4E7B_spillSetLevel(zT_79);
    zT_84 = cli.input_file;
    zT_82 = zT_84;
    zT_85 = &compiler_alloc;
    zT_83 = &zT_85->scratch;
    zT_87 = zF_5B859C63_readFile(zT_82, zT_83);
    zT_88 = zT_87.has_value;
    if (zT_88) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_92 = "error: could not read input file\n";
    zT_94 = 33;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = msg;
    zF_E4B2EF19_stderr_write(zT_95);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_15:
    zT_98 = zT_87.value;
    zT_89 = zT_98;
    goto z_bb_16;
    z_bb_16:
    source = zT_89;
    zT_101 = source.len;
    zT_104 = source.len;
    zT_108 = (unsigned int)((unsigned int)zT_101) + (unsigned int)((unsigned int)(unsigned int)(zT_104 / (unsigned int)(4)));
    interner_bc = zT_108;
    if ((unsigned char)(interner_bc < (unsigned int)(4096))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_111 = 4096;
    interner_bc = zT_111;
    goto z_bb_18;
    z_bb_18:
    zT_114 = source.len;
    zT_117 = (unsigned int)(unsigned int)(zT_114 / (unsigned int)(32));
    type_hint = zT_117;
    if ((unsigned char)(type_hint < (unsigned int)(4096))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_120 = 4096;
    type_hint = zT_120;
    goto z_bb_20;
    z_bb_20:
    zT_123 = source.len;
    zT_126 = (unsigned int)(unsigned int)(zT_123 / (unsigned int)(10));
    name_hint = zT_126;
    if ((unsigned char)(name_hint < (unsigned int)(2048))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_129 = 2048;
    name_hint = zT_129;
    goto z_bb_22;
    z_bb_22:
    zT_132 = source.len;
    zT_135 = (unsigned int)(unsigned int)(zT_132 / (unsigned int)(9));
    fold_hint = zT_135;
    if ((unsigned char)(fold_hint < (unsigned int)(16))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_138 = 16;
    fold_hint = zT_138;
    goto z_bb_24;
    z_bb_24:
    zT_142 = &compiler_alloc;
    zT_140 = &zT_142->permanent;
    zT_141 = interner_bc;
    zT_144 = zF_FB2E811D_stringInternerInit(zT_140, zT_141);
    interner = zT_144;
    zT_147 = &compiler_alloc;
    zT_146 = &zT_147->permanent;
    zT_149 = zF_01351F51_sourceManagerInit(zT_146);
    source_man = zT_149;
    zT_154 = &compiler_alloc;
    zT_151 = &zT_154->permanent;
    zT_152 = &source_man;
    zT_153 = &interner;
    zT_158 = zF_C7BA7DAB_diagnosticCollector(zT_151, zT_152, zT_153);
    diag = zT_158;
    zT_159 = cli.max_errors;
    diag.max_diagnostics = (unsigned int)((unsigned int)zT_159);
    zT_162 = &compiler_alloc;
    zT_161 = &zT_162->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_161);
    zT_165 = zF_27DA3900_nameManglerInit();
    name_mangler = zT_165;
    zT_170 = &compiler_alloc;
    zT_167 = &zT_170->permanent;
    zT_168 = &interner;
    zT_169 = &diag;
    zT_174 = zF_896FAF3C_moduleRegistryInit(zT_167, zT_168, zT_169);
    mr = zT_174;
    zT_175 = &mr;
    zT_176 = &source_man;
    zF_BD2BF0BD_moduleRegistrySetSo(zT_175, zT_176);
    type_db_arena = zT_180;
    zT_182 = "type_db";
    zT_184 = 7;
    zT_183.ptr = zT_182;
    zT_183.len = zT_184;
    type_db_name = zT_183;
    zT_185 = &type_db_arena;
    zT_190 = zF_8C23960F_poolPtr();
    zT_186 = zT_190;
    zT_191 = 4096;
    zT_188 = type_db_name;
    zF_07B11742_growableSandInit(zT_185, zT_186, (unsigned int)((unsigned int)zT_191), zT_188);
    zT_198 = &type_db_arena;
    zT_194 = &zT_198->view;
    zT_195 = &interner;
    zT_196 = type_hint;
    zT_197 = name_hint;
    zT_201 = zF_28AE6613_typeRegistryInitSiz(zT_194, zT_195, zT_196, zT_197);
    typereg = zT_201;
    zT_202 = &typereg;
    zF_541737A5_typeRegistryRegiste(zT_202);
    zT_206 = &compiler_alloc;
    zT_205 = &zT_206->module;
    zT_208 = zF_D9F91436_astStoreInit(zT_205);
    store = zT_208;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_210[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ast_spill_path[_i] = zT_210[_i];
        _i++;
    }
}
    zT_212 = 0;
    asp_len = zT_212;
    zT_213 = cli.output_dir_set;
    if (zT_213) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    zT_215 = cli.output_dir;
    od2 = zT_215;
    zT_217 = 0;
    oi2 = zT_217;
    goto z_bb_28;
    z_bb_26:
    zT_240 = ".zig1_ast.tmp";
    zT_242 = 13;
    zT_241.ptr = zT_240;
    zT_241.len = zT_242;
    ast_tmp_name = zT_241;
    zT_244 = 0;
    ati = zT_244;
    goto z_bb_35;
    z_bb_27:
    zT_233 = 46;
    ast_spill_path[asp_len] = zT_233;
    zT_235 = asp_len + (unsigned int)(1);
    asp_len = zT_235;
    zT_236 = 47;
    ast_spill_path[asp_len] = zT_236;
    zT_238 = asp_len + (unsigned int)(1);
    asp_len = zT_238;
    goto z_bb_26;
    z_bb_28:
    zT_219 = od2.len;
    if ((unsigned char)(oi2 < zT_219)) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    zT_224 = od2.ptr;
    zT_225 = zT_224[oi2];
    ast_spill_path[asp_len] = zT_225;
    zT_227 = asp_len + (unsigned int)(1);
    asp_len = zT_227;
    goto z_bb_31;
    z_bb_30:
    zT_230 = 47;
    ast_spill_path[asp_len] = zT_230;
    zT_232 = asp_len + (unsigned int)(1);
    asp_len = zT_232;
    goto z_bb_26;
    z_bb_31:
    zT_229 = oi2 + (unsigned int)(1);
    oi2 = zT_229;
    goto z_bb_28;
    z_bb_32:
    zT_221 = asp_len < (unsigned int)(511);
    goto z_bb_34;
    z_bb_33:
    zT_221 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_221) goto z_bb_29; else goto z_bb_30;
    z_bb_35:
    zT_246 = ast_tmp_name.len;
    if ((unsigned char)(ati < zT_246)) goto z_bb_39; else goto z_bb_40;
    z_bb_36:
    zT_251 = ast_tmp_name.ptr;
    zT_252 = zT_251[ati];
    ast_spill_path[asp_len] = zT_252;
    zT_254 = asp_len + (unsigned int)(1);
    asp_len = zT_254;
    goto z_bb_38;
    z_bb_37:
    zT_257 = &store;
    zT_262 = 0;
    zT_263 = (unsigned char*)((unsigned char*)ast_spill_path) + zT_262;
    zT_264 = asp_len - zT_262;
    zT_265.ptr = zT_263;
    zT_265.len = zT_264;
    zT_258 = zT_265;
    zF_2A507339_astStoreSetSpillPat(zT_257, zT_258);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_267[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        id_spill_path[_i] = zT_267[_i];
        _i++;
    }
}
    zT_269 = 0;
    idp_len = zT_269;
    zT_270 = cli.output_dir_set;
    if (zT_270) goto z_bb_42; else goto z_bb_44;
    z_bb_38:
    zT_256 = ati + (unsigned int)(1);
    ati = zT_256;
    goto z_bb_35;
    z_bb_39:
    zT_248 = asp_len < (unsigned int)(511);
    goto z_bb_41;
    z_bb_40:
    zT_248 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_248) goto z_bb_36; else goto z_bb_37;
    z_bb_42:
    zT_272 = cli.output_dir;
    od3 = zT_272;
    zT_274 = 0;
    oi3 = zT_274;
    goto z_bb_45;
    z_bb_43:
    zT_297 = ".zig1_side.tmp";
    zT_299 = 14;
    zT_298.ptr = zT_297;
    zT_298.len = zT_299;
    id_tmp_name = zT_298;
    zT_301 = 0;
    iti = zT_301;
    goto z_bb_52;
    z_bb_44:
    zT_290 = 46;
    id_spill_path[idp_len] = zT_290;
    zT_292 = idp_len + (unsigned int)(1);
    idp_len = zT_292;
    zT_293 = 47;
    id_spill_path[idp_len] = zT_293;
    zT_295 = idp_len + (unsigned int)(1);
    idp_len = zT_295;
    goto z_bb_43;
    z_bb_45:
    zT_276 = od3.len;
    if ((unsigned char)(oi3 < zT_276)) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_281 = od3.ptr;
    zT_282 = zT_281[oi3];
    id_spill_path[idp_len] = zT_282;
    zT_284 = idp_len + (unsigned int)(1);
    idp_len = zT_284;
    goto z_bb_48;
    z_bb_47:
    zT_287 = 47;
    id_spill_path[idp_len] = zT_287;
    zT_289 = idp_len + (unsigned int)(1);
    idp_len = zT_289;
    goto z_bb_43;
    z_bb_48:
    zT_286 = oi3 + (unsigned int)(1);
    oi3 = zT_286;
    goto z_bb_45;
    z_bb_49:
    zT_278 = idp_len < (unsigned int)(511);
    goto z_bb_51;
    z_bb_50:
    zT_278 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_278) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_303 = id_tmp_name.len;
    if ((unsigned char)(iti < zT_303)) goto z_bb_56; else goto z_bb_57;
    z_bb_53:
    zT_308 = id_tmp_name.ptr;
    zT_309 = zT_308[iti];
    id_spill_path[idp_len] = zT_309;
    zT_311 = idp_len + (unsigned int)(1);
    idp_len = zT_311;
    goto z_bb_55;
    z_bb_54:
    zT_314 = &store;
    zT_321 = 0;
    zT_322 = (unsigned char*)((unsigned char*)id_spill_path) + zT_321;
    zT_323 = idp_len - zT_321;
    zT_324.ptr = zT_322;
    zT_324.len = zT_323;
    zT_316 = zT_324;
    zF_35B9B6EC_astStoreSetValuePoo(zT_314, (unsigned int)(0), zT_316);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_326[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        iv_spill_path[_i] = zT_326[_i];
        _i++;
    }
}
    zT_328 = 0;
    ivp_len = zT_328;
    zT_329 = cli.output_dir_set;
    if (zT_329) goto z_bb_59; else goto z_bb_61;
    z_bb_55:
    zT_313 = iti + (unsigned int)(1);
    iti = zT_313;
    goto z_bb_52;
    z_bb_56:
    zT_305 = idp_len < (unsigned int)(511);
    goto z_bb_58;
    z_bb_57:
    zT_305 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_305) goto z_bb_53; else goto z_bb_54;
    z_bb_59:
    zT_331 = cli.output_dir;
    od5 = zT_331;
    zT_333 = 0;
    oi5 = zT_333;
    goto z_bb_62;
    z_bb_60:
    zT_356 = ".zig1_side_iv.tmp";
    zT_358 = 17;
    zT_357.ptr = zT_356;
    zT_357.len = zT_358;
    iv_tmp_name = zT_357;
    zT_360 = 0;
    ivi = zT_360;
    goto z_bb_69;
    z_bb_61:
    zT_349 = 46;
    iv_spill_path[ivp_len] = zT_349;
    zT_351 = ivp_len + (unsigned int)(1);
    ivp_len = zT_351;
    zT_352 = 47;
    iv_spill_path[ivp_len] = zT_352;
    zT_354 = ivp_len + (unsigned int)(1);
    ivp_len = zT_354;
    goto z_bb_60;
    z_bb_62:
    zT_335 = od5.len;
    if ((unsigned char)(oi5 < zT_335)) goto z_bb_66; else goto z_bb_67;
    z_bb_63:
    zT_340 = od5.ptr;
    zT_341 = zT_340[oi5];
    iv_spill_path[ivp_len] = zT_341;
    zT_343 = ivp_len + (unsigned int)(1);
    ivp_len = zT_343;
    goto z_bb_65;
    z_bb_64:
    zT_346 = 47;
    iv_spill_path[ivp_len] = zT_346;
    zT_348 = ivp_len + (unsigned int)(1);
    ivp_len = zT_348;
    goto z_bb_60;
    z_bb_65:
    zT_345 = oi5 + (unsigned int)(1);
    oi5 = zT_345;
    goto z_bb_62;
    z_bb_66:
    zT_337 = ivp_len < (unsigned int)(511);
    goto z_bb_68;
    z_bb_67:
    zT_337 = 0;
    goto z_bb_68;
    z_bb_68:
    if (zT_337) goto z_bb_63; else goto z_bb_64;
    z_bb_69:
    zT_362 = iv_tmp_name.len;
    if ((unsigned char)(ivi < zT_362)) goto z_bb_73; else goto z_bb_74;
    z_bb_70:
    zT_367 = iv_tmp_name.ptr;
    zT_368 = zT_367[ivi];
    iv_spill_path[ivp_len] = zT_368;
    zT_370 = ivp_len + (unsigned int)(1);
    ivp_len = zT_370;
    goto z_bb_72;
    z_bb_71:
    zT_373 = &store;
    zT_380 = 0;
    zT_381 = (unsigned char*)((unsigned char*)iv_spill_path) + zT_380;
    zT_382 = ivp_len - zT_380;
    zT_383.ptr = zT_381;
    zT_383.len = zT_382;
    zT_375 = zT_383;
    zF_35B9B6EC_astStoreSetValuePoo(zT_373, (unsigned int)(1), zT_375);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_385[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ec_spill_path[_i] = zT_385[_i];
        _i++;
    }
}
    zT_387 = 0;
    ecp_len = zT_387;
    zT_388 = cli.output_dir_set;
    if (zT_388) goto z_bb_76; else goto z_bb_78;
    z_bb_72:
    zT_372 = ivi + (unsigned int)(1);
    ivi = zT_372;
    goto z_bb_69;
    z_bb_73:
    zT_364 = ivp_len < (unsigned int)(511);
    goto z_bb_75;
    z_bb_74:
    zT_364 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_364) goto z_bb_70; else goto z_bb_71;
    z_bb_76:
    zT_390 = cli.output_dir;
    od6 = zT_390;
    zT_392 = 0;
    oi6 = zT_392;
    goto z_bb_79;
    z_bb_77:
    zT_415 = ".zig1_extra_ec.tmp";
    zT_417 = 18;
    zT_416.ptr = zT_415;
    zT_416.len = zT_417;
    ec_tmp_name = zT_416;
    zT_419 = 0;
    eci = zT_419;
    goto z_bb_86;
    z_bb_78:
    zT_408 = 46;
    ec_spill_path[ecp_len] = zT_408;
    zT_410 = ecp_len + (unsigned int)(1);
    ecp_len = zT_410;
    zT_411 = 47;
    ec_spill_path[ecp_len] = zT_411;
    zT_413 = ecp_len + (unsigned int)(1);
    ecp_len = zT_413;
    goto z_bb_77;
    z_bb_79:
    zT_394 = od6.len;
    if ((unsigned char)(oi6 < zT_394)) goto z_bb_83; else goto z_bb_84;
    z_bb_80:
    zT_399 = od6.ptr;
    zT_400 = zT_399[oi6];
    ec_spill_path[ecp_len] = zT_400;
    zT_402 = ecp_len + (unsigned int)(1);
    ecp_len = zT_402;
    goto z_bb_82;
    z_bb_81:
    zT_405 = 47;
    ec_spill_path[ecp_len] = zT_405;
    zT_407 = ecp_len + (unsigned int)(1);
    ecp_len = zT_407;
    goto z_bb_77;
    z_bb_82:
    zT_404 = oi6 + (unsigned int)(1);
    oi6 = zT_404;
    goto z_bb_79;
    z_bb_83:
    zT_396 = ecp_len < (unsigned int)(511);
    goto z_bb_85;
    z_bb_84:
    zT_396 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_396) goto z_bb_80; else goto z_bb_81;
    z_bb_86:
    zT_421 = ec_tmp_name.len;
    if ((unsigned char)(eci < zT_421)) goto z_bb_90; else goto z_bb_91;
    z_bb_87:
    zT_426 = ec_tmp_name.ptr;
    zT_427 = zT_426[eci];
    ec_spill_path[ecp_len] = zT_427;
    zT_429 = ecp_len + (unsigned int)(1);
    ecp_len = zT_429;
    goto z_bb_89;
    z_bb_88:
    zT_432 = &store;
    zT_439 = 0;
    zT_440 = (unsigned char*)((unsigned char*)ec_spill_path) + zT_439;
    zT_441 = ecp_len - zT_439;
    zT_442.ptr = zT_440;
    zT_442.len = zT_441;
    zT_434 = zT_442;
    zF_35B9B6EC_astStoreSetValuePoo(zT_432, (unsigned int)(2), zT_434);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_444[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        er_spill_path[_i] = zT_444[_i];
        _i++;
    }
}
    zT_446 = 0;
    erp_len = zT_446;
    zT_447 = cli.output_dir_set;
    if (zT_447) goto z_bb_93; else goto z_bb_95;
    z_bb_89:
    zT_431 = eci + (unsigned int)(1);
    eci = zT_431;
    goto z_bb_86;
    z_bb_90:
    zT_423 = ecp_len < (unsigned int)(511);
    goto z_bb_92;
    z_bb_91:
    zT_423 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_423) goto z_bb_87; else goto z_bb_88;
    z_bb_93:
    zT_449 = cli.output_dir;
    od7 = zT_449;
    zT_451 = 0;
    oi7 = zT_451;
    goto z_bb_96;
    z_bb_94:
    zT_474 = ".zig1_extra_er.tmp";
    zT_476 = 18;
    zT_475.ptr = zT_474;
    zT_475.len = zT_476;
    er_tmp_name = zT_475;
    zT_478 = 0;
    eri = zT_478;
    goto z_bb_103;
    z_bb_95:
    zT_467 = 46;
    er_spill_path[erp_len] = zT_467;
    zT_469 = erp_len + (unsigned int)(1);
    erp_len = zT_469;
    zT_470 = 47;
    er_spill_path[erp_len] = zT_470;
    zT_472 = erp_len + (unsigned int)(1);
    erp_len = zT_472;
    goto z_bb_94;
    z_bb_96:
    zT_453 = od7.len;
    if ((unsigned char)(oi7 < zT_453)) goto z_bb_100; else goto z_bb_101;
    z_bb_97:
    zT_458 = od7.ptr;
    zT_459 = zT_458[oi7];
    er_spill_path[erp_len] = zT_459;
    zT_461 = erp_len + (unsigned int)(1);
    erp_len = zT_461;
    goto z_bb_99;
    z_bb_98:
    zT_464 = 47;
    er_spill_path[erp_len] = zT_464;
    zT_466 = erp_len + (unsigned int)(1);
    erp_len = zT_466;
    goto z_bb_94;
    z_bb_99:
    zT_463 = oi7 + (unsigned int)(1);
    oi7 = zT_463;
    goto z_bb_96;
    z_bb_100:
    zT_455 = erp_len < (unsigned int)(511);
    goto z_bb_102;
    z_bb_101:
    zT_455 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_455) goto z_bb_97; else goto z_bb_98;
    z_bb_103:
    zT_480 = er_tmp_name.len;
    if ((unsigned char)(eri < zT_480)) goto z_bb_107; else goto z_bb_108;
    z_bb_104:
    zT_485 = er_tmp_name.ptr;
    zT_486 = zT_485[eri];
    er_spill_path[erp_len] = zT_486;
    zT_488 = erp_len + (unsigned int)(1);
    erp_len = zT_488;
    goto z_bb_106;
    z_bb_105:
    zT_491 = &store;
    zT_498 = 0;
    zT_499 = (unsigned char*)((unsigned char*)er_spill_path) + zT_498;
    zT_500 = erp_len - zT_498;
    zT_501.ptr = zT_499;
    zT_501.len = zT_500;
    zT_493 = zT_501;
    zF_35B9B6EC_astStoreSetValuePoo(zT_491, (unsigned int)(3), zT_493);
    zT_504 = &compiler_alloc;
    zT_503 = &zT_504->permanent;
    zT_506 = zF_09A884A8_symbolRegistryInit(zT_503);
    symbol_reg = zT_506;
    zT_509 = &compiler_alloc;
    zT_508 = &zT_509->module;
    zT_511 = zF_8D0F00B1_resolvedTypeTableIn(zT_508);
    resolved_types = zT_511;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_513[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        rtt_spill_path[_i] = zT_513[_i];
        _i++;
    }
}
    zT_515 = 0;
    rsp_len = zT_515;
    zT_516 = cli.output_dir_set;
    if (zT_516) goto z_bb_110; else goto z_bb_112;
    z_bb_106:
    zT_490 = eri + (unsigned int)(1);
    eri = zT_490;
    goto z_bb_103;
    z_bb_107:
    zT_482 = erp_len < (unsigned int)(511);
    goto z_bb_109;
    z_bb_108:
    zT_482 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_482) goto z_bb_104; else goto z_bb_105;
    z_bb_110:
    zT_518 = cli.output_dir;
    od4 = zT_518;
    zT_520 = 0;
    oi4 = zT_520;
    goto z_bb_113;
    z_bb_111:
    zT_543 = ".zig1_res.tmp";
    zT_545 = 13;
    zT_544.ptr = zT_543;
    zT_544.len = zT_545;
    rtt_tmp_name = zT_544;
    zT_547 = 0;
    rti2 = zT_547;
    goto z_bb_120;
    z_bb_112:
    zT_536 = 46;
    rtt_spill_path[rsp_len] = zT_536;
    zT_538 = rsp_len + (unsigned int)(1);
    rsp_len = zT_538;
    zT_539 = 47;
    rtt_spill_path[rsp_len] = zT_539;
    zT_541 = rsp_len + (unsigned int)(1);
    rsp_len = zT_541;
    goto z_bb_111;
    z_bb_113:
    zT_522 = od4.len;
    if ((unsigned char)(oi4 < zT_522)) goto z_bb_117; else goto z_bb_118;
    z_bb_114:
    zT_527 = od4.ptr;
    zT_528 = zT_527[oi4];
    rtt_spill_path[rsp_len] = zT_528;
    zT_530 = rsp_len + (unsigned int)(1);
    rsp_len = zT_530;
    goto z_bb_116;
    z_bb_115:
    zT_533 = 47;
    rtt_spill_path[rsp_len] = zT_533;
    zT_535 = rsp_len + (unsigned int)(1);
    rsp_len = zT_535;
    goto z_bb_111;
    z_bb_116:
    zT_532 = oi4 + (unsigned int)(1);
    oi4 = zT_532;
    goto z_bb_113;
    z_bb_117:
    zT_524 = rsp_len < (unsigned int)(511);
    goto z_bb_119;
    z_bb_118:
    zT_524 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_524) goto z_bb_114; else goto z_bb_115;
    z_bb_120:
    zT_549 = rtt_tmp_name.len;
    if ((unsigned char)(rti2 < zT_549)) goto z_bb_124; else goto z_bb_125;
    z_bb_121:
    zT_554 = rtt_tmp_name.ptr;
    zT_555 = zT_554[rti2];
    rtt_spill_path[rsp_len] = zT_555;
    zT_557 = rsp_len + (unsigned int)(1);
    rsp_len = zT_557;
    goto z_bb_123;
    z_bb_122:
    zT_560 = &resolved_types;
    zT_565 = 0;
    zT_566 = (unsigned char*)((unsigned char*)rtt_spill_path) + zT_565;
    zT_567 = rsp_len - zT_565;
    zT_568.ptr = zT_566;
    zT_568.len = zT_567;
    zT_561 = zT_568;
    zF_7238A436_resolvedTypeTableSe(zT_560, zT_561);
    zT_571 = &compiler_alloc;
    zT_570 = &zT_571->module;
    zT_573 = zF_26B6D809_coercionTableInit(zT_570);
    coercion_table = zT_573;
    zT_576 = &compiler_alloc;
    zT_575 = &zT_576->emission;
    zT_578 = zF_F91F6677_lirSlotArrayListIni(zT_575);
    lir_slots = zT_578;
    zT_581 = &compiler_alloc;
    zT_580 = &zT_581->module;
    zT_583 = zF_7F194604_depGraphInit(zT_580);
    dep_graph = zT_583;
    zT_586 = &compiler_alloc;
    zT_585 = &zT_586->module;
    zT_588 = zF_58BDA2DE_u32ToU32MapInit(zT_585);
    enum_value_table = zT_588;
    zT_591 = &compiler_alloc;
    zT_590 = &zT_591->module;
    zT_593 = zF_58BDA2DE_u32ToU32MapInit(zT_590);
    tuple_index_table = zT_593;
    zT_596 = &compiler_alloc;
    zT_595 = &zT_596->emission;
    zT_598 = zF_58BDA2DE_u32ToU32MapInit(zT_595);
    error_code_registry = zT_598;
    zT_601 = &compiler_alloc;
    zT_600 = &zT_601->module;
    zT_603 = zF_58BDA2DE_u32ToU32MapInit(zT_600);
    call_arg_types = zT_603;
    zT_606 = &compiler_alloc;
    zT_605 = &zT_606->module;
    zT_608 = zF_58BDA2DE_u32ToU32MapInit(zT_605);
    call_param_map = zT_608;
    zT_612 = &compiler_alloc;
    zT_610 = &zT_612->module;
    zT_615 = zF_125E6ED1_comptimeFoldTableIn(zT_610, (unsigned int)((unsigned int)fold_hint));
    comptime_folds = zT_615;
    zT_618 = &compiler_alloc;
    zT_617 = &zT_618->emission;
    zT_620 = zF_986226E1_u64ToU32MapInit(zT_617);
    exported = zT_620;
    zT_623 = &compiler_alloc;
    zT_622 = &zT_623->module;
    zT_625 = zF_986226E1_u64ToU32MapInit(zT_622);
    suspending_fns = zT_625;
    zT_628 = &compiler_alloc;
    zT_627 = &zT_628->module;
    zT_630 = zF_986226E1_u64ToU32MapInit(zT_627);
    frame_sizes = zT_630;
    zT_633 = &compiler_alloc;
    zT_632 = &zT_633->module;
    zT_635 = zF_986226E1_u64ToU32MapInit(zT_632);
    state_widths = zT_635;
    zT_638 = &compiler_alloc;
    zT_637 = &zT_638->module;
    zT_640 = zF_986226E1_u64ToU32MapInit(zT_637);
    awaited_fns = zT_640;
    zT_643 = &compiler_alloc;
    zT_642 = &zT_643->module;
    zT_645 = zF_986226E1_u64ToU32MapInit(zT_642);
    async_hidden_fns = zT_645;
    zT_648 = &compiler_alloc;
    zT_647 = &zT_648->module;
    zT_650 = zF_986226E1_u64ToU32MapInit(zT_647);
    driver_targets = zT_650;
    zT_653 = &compiler_alloc;
    zT_652 = &zT_653->module;
    zT_655 = zF_8E537D0C_u32ArrayListInit(zT_652);
    parent_result_type_list = zT_655;
    zT_658 = &compiler_alloc;
    zT_657 = &zT_658->module;
    zT_660 = zF_986226E1_u64ToU32MapInit(zT_657);
    parent_result_start = zT_660;
    zT_663 = &compiler_alloc;
    zT_662 = &zT_663->module;
    zT_665 = zF_986226E1_u64ToU32MapInit(zT_662);
    parent_result_count = zT_665;
    zT_668 = &compiler_alloc;
    zT_667 = &zT_668->module;
    zT_670 = zF_986226E1_u64ToU32MapInit(zT_667);
    async_layouts = zT_670;
    zT_672.cli = cli;
    zT_673 = &compiler_alloc;
    zT_672.alloc = zT_673;
    zT_674 = &interner;
    zT_672.interner = zT_674;
    zT_675 = &diag;
    zT_672.diag = zT_675;
    zT_676 = &source_man;
    zT_672.source_man = zT_676;
    zT_677 = &name_mangler;
    zT_672.name_mangler = zT_677;
    zT_678 = &mr;
    zT_672.module_reg = zT_678;
    zT_679 = &typereg;
    zT_672.typereg = zT_679;
    zT_680 = &store;
    zT_672.store = zT_680;
    zT_681 = &symbol_reg;
    zT_672.symbol_reg = zT_681;
    zT_682 = &resolved_types;
    zT_672.resolved_types = zT_682;
    zT_683 = &coercion_table;
    zT_672.coercion_table = zT_683;
    zT_684 = &dep_graph;
    zT_672.dep_graph = zT_684;
    zT_672.lir_slots = lir_slots;
    zT_685 = zF_E9CBFCA6_lirStreamInit();
    zT_672.lir_stream = zT_685;
    zT_672.enum_value_table = enum_value_table;
    zT_672.tuple_index_table = tuple_index_table;
    zT_672.error_code_registry = error_code_registry;
    zT_672.call_arg_types = call_arg_types;
    zT_672.call_param_map = call_param_map;
    zT_672.comptime_folds = comptime_folds;
    zT_672.exported = exported;
    zT_672.suspending_fns = suspending_fns;
    zT_672.frame_sizes = frame_sizes;
    zT_672.state_widths = state_widths;
    zT_672.awaited_fns = awaited_fns;
    zT_672.async_hidden_fns = async_hidden_fns;
    zT_672.driver_targets = driver_targets;
    zT_672.parent_result_type_list = parent_result_type_list;
    zT_672.parent_result_start = parent_result_start;
    zT_672.parent_result_count = parent_result_count;
    zT_672.async_layouts = async_layouts;
    zT_686 = 0;
    zT_672.pointer_only_ids = (unsigned int*)zT_686;
    zT_687 = 0;
    zT_672.pointer_only_len = zT_687;
    zT_689 = &compiler_alloc;
    zT_688 = &zT_689->emission;
    zT_691 = zF_EB0B1609_globalDeclArrayList(zT_688);
    zT_672.global_decls = zT_691;
    zT_693 = &compiler_alloc;
    zT_692 = &zT_693->module;
    zT_695 = zF_986226E1_u64ToU32MapInit(zT_692);
    zT_672.module_init_deps = zT_695;
    zT_697 = &compiler_alloc;
    zT_696 = &zT_697->emission;
    zT_699 = zF_8E537D0C_u32ArrayListInit(zT_696);
    zT_672.module_init_order = zT_699;
    ctx = zT_672;
    zT_700 = &ctx;
    zF_74055C03_runCompiler(zT_700);
    return;
    z_bb_123:
    zT_559 = rti2 + (unsigned int)(1);
    rti2 = zT_559;
    goto z_bb_120;
    z_bb_124:
    zT_551 = rsp_len < (unsigned int)(511);
    goto z_bb_126;
    z_bb_125:
    zT_551 = 0;
    goto z_bb_126;
    z_bb_126:
    if (zT_551) goto z_bb_121; else goto z_bb_122;
}

int main(int argc, char** argv) {
    zF_780653D2___module_init();
    zF_780653D2___module_init_1();
    zF_780653D2___module_init_2();
    zF_780653D2___module_init_3();
    zF_780653D2___module_init_4();
    zF_780653D2___module_init_5();
    zF_780653D2___module_init_6();
    zF_780653D2___module_init_7();
    zF_780653D2___module_init_8();
    zF_780653D2___module_init_9();
    zF_780653D2___module_init_10();
    zF_780653D2___module_init_11();
    zF_780653D2___module_init_12();
    zF_780653D2___module_init_13();
    zF_780653D2___module_init_14();
    zF_780653D2___module_init_15();
    zF_780653D2___module_init_16();
    zF_780653D2___module_init_17();
    zF_780653D2___module_init_18();
    zF_780653D2___module_init_19();
    zF_780653D2___module_init_20();
    zF_780653D2___module_init_21();
    zF_780653D2___module_init_22();
    zF_780653D2___module_init_23();
    zF_780653D2___module_init_24();
    zF_780653D2___module_init_25();
    zF_780653D2___module_init_26();
    zF_780653D2___module_init_27();
    zF_780653D2___module_init_28();
    zF_EA90E208_main(argc, (unsigned char**)argv);
    return 0;
}

/* runCompiler */
void zF_74055C03_runCompiler(zT_5AB29387_CompilerContext* ctx) {
    zT_5AB29387_CompilerContext* zT_1;
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5AB29387_CompilerContext* zT_24;
    zT_69057089_CompilerAlloc* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    zT_3D7259E2_SymbolRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_D3EB6303_StringInterner* zT_31;
    zT_A4CE86B7_U64ToU32Map* zT_32;
    zT_69057089_CompilerAlloc* zT_33;
    zT_5AB29387_CompilerContext* zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_69057089_CompilerAlloc* zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned char zT_55 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_59;
    zT_69057089_CompilerAlloc* zT_61;
    zT_5AB29387_CompilerContext* zT_63;
    zT_5AB29387_CompilerContext* zT_64;
    zT_5AB29387_CompilerContext* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    unsigned char zT_68 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    int zT_72;
    zT_5AB29387_CompilerContext* zT_74;
    zT_69057089_CompilerAlloc* zT_75;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned char zT_79 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_80;
    int zT_83;
    zT_5AB29387_CompilerContext* zT_85;
    zT_5AB29387_CompilerContext* zT_86;
    zT_69057089_CompilerAlloc* zT_87;
    zT_F85C5DED_DiagnosticCollector* zT_89;
    unsigned char zT_91 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    int zT_95;
    zT_8EED1867_ResolvedTypeTable* zT_97;
    zT_3E40CD83_Sand* zT_99;
    zT_69057089_CompilerAlloc* zT_100;
    zT_5AB29387_CompilerContext* zT_102;
    zT_69057089_CompilerAlloc* zT_103;
    zT_C98AF326_CompilerCli zT_105;
    unsigned char zT_106;
    unsigned char zT_107;
    zT_C98AF326_CompilerCli zT_108;
    unsigned char zT_110;
    zT_F85C5DED_DiagnosticCollector* zT_111;
    unsigned int zT_113 = 0;
    int zT_114;
    zT_F85C5DED_DiagnosticCollector* zT_116;
    int zT_119;
    zT_C98AF326_CompilerCli zT_121;
    unsigned char zT_122;
    zT_69057089_CompilerAlloc* zT_124;
    zT_3E40CD83_Sand zT_125;
    unsigned int zT_126;
    unsigned int zT_129;
    zT_69057089_CompilerAlloc* zT_131;
    zT_3E40CD83_Sand zT_132;
    unsigned int zT_133;
    unsigned int zT_136;
    zT_69057089_CompilerAlloc* zT_138;
    zT_3E40CD83_Sand zT_139;
    unsigned int zT_140;
    unsigned int zT_143;
    unsigned int zT_145 = 0;
    unsigned int zT_148;
    zT_338B7C76_TypeRegistry* zT_150;
    zT_3E40CD83_Sand* zT_151;
    unsigned int zT_152;
    unsigned int zT_155;
    unsigned int zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    unsigned char* zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    unsigned char* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned char* zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    unsigned char* zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    zT_F85C5DED_DiagnosticCollector* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u z2;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3a;
    zT_8F083A69_Slice_zT_0B42B2F8_u z4;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2;
    unsigned int perm_kb;
    unsigned int mod_kb;
    unsigned int scr_kb;
    unsigned int pool_kb;
    unsigned int type_db_kb;
    unsigned int total;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3b;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3c;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg4;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg5;
    zT_1 = ctx;
    zF_E2BA93CE_phase_ImportResolut(zT_1);
    zT_3 = "2\n";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    z2 = zT_4;
    zT_6 = z2;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_7 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_7);
    zT_10 = "3\n";
    zT_12 = 2;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    z3 = zT_11;
    zT_13 = z3;
    zF_48AC7B3A_markerWrite(zT_13);
    zT_15 = "3a\n";
    zT_17 = 3;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    z3a = zT_16;
    zT_18 = z3a;
    zF_48AC7B3A_markerWrite(zT_18);
    zT_20 = "4\n";
    zT_22 = 2;
    zT_21.ptr = zT_20;
    zT_21.len = zT_22;
    z4 = zT_21;
    zT_23 = z4;
    zF_48AC7B3A_markerWrite(zT_23);
    zT_24 = ctx;
    zF_945DEA54_phase_SymbolRegistr(zT_24);
    zT_25 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_25);
    zT_33 = ctx->alloc;
    zT_27 = &zT_33->module;
    zT_28 = ctx->store;
    zT_29 = ctx->symbol_reg;
    zT_30 = ctx->module_reg;
    zT_31 = ctx->interner;
    zT_32 = &ctx->suspending_fns;
    zF_790061E7_suspensionAnalysisR(zT_27, zT_28, zT_29, zT_30, zT_31, zT_32);
    zT_40 = ctx;
    zF_D3497187_phase_TypeResolutio(zT_40);
    zT_42 = "t1\n";
    zT_44 = 3;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    t1 = zT_43;
    zT_45 = t1;
    zF_48AC7B3A_markerWrite(zT_45);
    zT_46 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_46);
    zT_49 = "t2\n";
    zT_51 = 3;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    t2 = zT_50;
    zT_52 = t2;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_53 = ctx->diag;
    zT_55 = zF_8F770780_diagnosticCollector(zT_53);
    if (zT_55) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_56 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_56);
    zT_59 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_59));
    goto z_bb_2;
    z_bb_2:
    zT_61 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_61);
    zT_63 = ctx;
    zF_F862154A_phase_FrontResoluti(zT_63);
    zT_64 = ctx;
    zF_9609BF31_phase_ComptimeEvalu(zT_64);
    zT_65 = ctx;
    zF_0666ED4F_phase_SemanticAnaly(zT_65);
    zT_66 = ctx->diag;
    zT_68 = zF_8F770780_diagnosticCollector(zT_66);
    if (zT_68) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_69 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_69);
    zT_72 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_72));
    goto z_bb_4;
    z_bb_4:
    zT_74 = ctx;
    zF_F3B55B42_phase_StaticAnalyze(zT_74);
    zT_75 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_75);
    zT_77 = ctx->diag;
    zT_79 = zF_8F770780_diagnosticCollector(zT_77);
    if (zT_79) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_80 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_80);
    zT_83 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_83));
    goto z_bb_6;
    z_bb_6:
    zT_85 = ctx;
    zF_9BC6214D_phase_AsyncFrameSiz(zT_85);
    zT_86 = ctx;
    zF_1F21ABE7_phase_LIRLowering(zT_86);
    zT_87 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_87);
    zT_89 = ctx->diag;
    zT_91 = zF_8F770780_diagnosticCollector(zT_89);
    if (zT_91) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_92 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_92);
    zT_95 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_95));
    goto z_bb_8;
    z_bb_8:
    zT_97 = ctx->resolved_types;
    zF_5209815D_resolvedTypeTableCl(zT_97);
    zT_100 = ctx->alloc;
    zT_99 = &zT_100->module;
    zF_F1B3F8C2_sandReset(zT_99);
    zT_102 = ctx;
    zF_2268F8CE_phase_C89Emission(zT_102);
    zT_103 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_103);
    zT_105 = ctx->cli;
    zT_106 = zT_105.warnings_as_errors;
    if (zT_106) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_108 = ctx->cli;
    zT_107 = zT_108.warn_error;
    goto z_bb_11;
    z_bb_10:
    zT_107 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_107) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_111 = ctx->diag;
    zT_113 = zF_4AF2092E_diagnosticCollector(zT_111);
    zT_114 = 0;
    zT_110 = zT_113 > (unsigned int)zT_114;
    goto z_bb_14;
    z_bb_13:
    zT_110 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_110) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_116 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_116);
    zT_119 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_119));
    goto z_bb_16;
    z_bb_16:
    zT_121 = ctx->cli;
    zT_122 = zT_121.track_memory;
    if (zT_122) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_124 = ctx->alloc;
    zT_125 = zT_124->permanent;
    zT_126 = zT_125.peak;
    zT_129 = (unsigned int)(unsigned int)(zT_126 / (unsigned int)(1024));
    perm_kb = zT_129;
    zT_131 = ctx->alloc;
    zT_132 = zT_131->module;
    zT_133 = zT_132.peak;
    zT_136 = (unsigned int)(unsigned int)(zT_133 / (unsigned int)(1024));
    mod_kb = zT_136;
    zT_138 = ctx->alloc;
    zT_139 = zT_138->scratch;
    zT_140 = zT_139.peak;
    zT_143 = (unsigned int)(unsigned int)(zT_140 / (unsigned int)(1024));
    scr_kb = zT_143;
    zT_145 = zF_E5D0D49C_poolPeak();
    zT_148 = (unsigned int)(unsigned int)(zT_145 / (unsigned int)(1024));
    pool_kb = zT_148;
    zT_150 = ctx->typereg;
    zT_151 = zT_150->types_alloc;
    zT_152 = zT_151->peak;
    zT_155 = (unsigned int)(unsigned int)(zT_152 / (unsigned int)(1024));
    type_db_kb = zT_155;
    zT_158 = (unsigned int)(perm_kb + mod_kb) + scr_kb;
    total = zT_158;
    zT_160 = "track-memory: perm=";
    zT_162 = 19;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    msg1 = zT_161;
    zT_163 = msg1;
    zF_B5478454_measureMarkerWrite(zT_163);
    zT_164 = perm_kb;
    zF_266B1B8E_writeU32(zT_164);
    zT_166 = "K mod=";
    zT_168 = 6;
    zT_167.ptr = zT_166;
    zT_167.len = zT_168;
    msg2 = zT_167;
    zT_169 = msg2;
    zF_B5478454_measureMarkerWrite(zT_169);
    zT_170 = mod_kb;
    zF_266B1B8E_writeU32(zT_170);
    zT_172 = "K scr=";
    zT_174 = 6;
    zT_173.ptr = zT_172;
    zT_173.len = zT_174;
    msg3 = zT_173;
    zT_175 = msg3;
    zF_B5478454_measureMarkerWrite(zT_175);
    zT_176 = scr_kb;
    zF_266B1B8E_writeU32(zT_176);
    zT_178 = "K pool=";
    zT_180 = 7;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    msg3b = zT_179;
    zT_181 = msg3b;
    zF_B5478454_measureMarkerWrite(zT_181);
    zT_182 = pool_kb;
    zF_266B1B8E_writeU32(zT_182);
    zT_184 = "K type_db=";
    zT_186 = 10;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    msg3c = zT_185;
    zT_187 = msg3c;
    zF_B5478454_measureMarkerWrite(zT_187);
    zT_188 = type_db_kb;
    zF_266B1B8E_writeU32(zT_188);
    zT_190 = "K total=";
    zT_192 = 8;
    zT_191.ptr = zT_190;
    zT_191.len = zT_192;
    msg4 = zT_191;
    zT_193 = msg4;
    zF_B5478454_measureMarkerWrite(zT_193);
    zT_194 = total;
    zF_266B1B8E_writeU32(zT_194);
    zT_196 = "K\n";
    zT_198 = 2;
    zT_197.ptr = zT_196;
    zT_197.len = zT_198;
    msg5 = zT_197;
    zT_199 = msg5;
    zF_B5478454_measureMarkerWrite(zT_199);
    goto z_bb_18;
    z_bb_18:
    zT_200 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_200);
    return;
}

/* astStoreHasPrintRef */
unsigned char zF_A42B6E3C_astStoreHasPrintRef(zT_6B0A7D14_AstStore* store, unsigned int print_id) {
    unsigned int zT_3;
    zT_C13790A8_anon_259686 zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_8;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char zT_16;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24 = 0;
    unsigned int zT_28;
    unsigned int i;
    zT_22A7C88B_AstNode node;
    zT_3 = 0;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = store->nodes;
    zT_5 = zT_4.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = store;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, (unsigned int)((unsigned int)i));
    node = zT_11;
    zT_12 = node.kind;
    if ((unsigned char)(zT_12 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_28 = i + (unsigned int)(1);
    i = zT_28;
    goto z_bb_1;
    z_bb_5:
    zT_17 = node.kind;
    zT_16 = zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access);
    goto z_bb_7;
    z_bb_6:
    zT_16 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_16) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_21 = store;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, (unsigned int)((unsigned int)i));
    if ((unsigned char)(zT_24 == print_id)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    goto z_bb_4;
}

/* phase_ImportResolution */
void zF_E2BA93CE_phase_ImportResolut(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_C98AF326_CompilerCli zT_12;
    unsigned int zT_13;
    zT_4DB1475B_ModuleResolver* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_072B53A6_ModuleRegistry* zT_17;
    zT_C98AF326_CompilerCli zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    unsigned int zT_25;
    zT_846744CC_Arr_unsigned_char_5 zT_27;
    unsigned char* zT_29;
    int zT_31;
    unsigned char* zT_32;
    int zT_34 = 0;
    int zT_35;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char zT_46 = 0;
    zT_4DB1475B_ModuleResolver* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_072B53A6_ModuleRegistry* zT_49;
    zT_846744CC_Arr_unsigned_char_5 zT_52;
    zT_C98AF326_CompilerCli zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_C98AF326_CompilerCli zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_59;
    int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_C98AF326_CompilerCli zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_70;
    int zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_C98AF326_CompilerCli zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    zT_7034F045_Opt_228 zT_77 = {0};
    unsigned char zT_78;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_84 = 0;
    zT_072B53A6_ModuleRegistry* zT_86;
    unsigned int zT_87;
    unsigned int zT_89 = 0;
    zT_47A5CDFB_ImportQueue* zT_90;
    unsigned int zT_91;
    zT_072B53A6_ModuleRegistry* zT_92;
    zT_072B53A6_ModuleRegistry* zT_94;
    zT_3E40CD83_Sand* zT_95;
    zT_3E40CD83_Sand* zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    zT_69057089_CompilerAlloc* zT_99;
    zT_69057089_CompilerAlloc* zT_101;
    zT_D3EB6303_StringInterner* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    unsigned int zT_111 = 0;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned char zT_115 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_4DB1475B_ModuleResolver* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_3E40CD83_Sand* zT_123;
    zT_072B53A6_ModuleRegistry* zT_124;
    zT_69057089_CompilerAlloc* zT_126;
    zT_BAEE192E_Opt_10 zT_128 = {0};
    unsigned char zT_129;
    zT_D3EB6303_StringInterner* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_134 = 0;
    zT_072B53A6_ModuleRegistry* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_3E40CD83_Sand* zT_138;
    zT_69057089_CompilerAlloc* zT_140;
    zT_BAEE192E_Opt_10 zT_142 = {0};
    zT_072B53A6_ModuleRegistry* zT_143;
    zT_3E40CD83_Sand* zT_144;
    zT_3E40CD83_Sand* zT_145;
    zT_6B0A7D14_AstStore* zT_146;
    zT_69057089_CompilerAlloc* zT_148;
    zT_69057089_CompilerAlloc* zT_150;
    zT_846744CC_Arr_unsigned_char_5 zT_154;
    unsigned int zT_156;
    zT_C98AF326_CompilerCli zT_157;
    unsigned char zT_158;
    zT_C98AF326_CompilerCli zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_163;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned char* zT_170;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned int zT_175;
    unsigned char zT_176;
    unsigned int zT_178;
    unsigned char zT_179;
    unsigned int zT_181;
    unsigned char zT_182;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_192;
    unsigned char zT_194;
    unsigned char* zT_197;
    unsigned char zT_198;
    unsigned int zT_200;
    unsigned int zT_202;
    zT_072B53A6_ModuleRegistry* zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    int zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    unsigned int si;
    zT_846744CC_Arr_unsigned_char_5 lib_buf;
    int lib_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_path;
    zT_846744CC_Arr_unsigned_char_5 root_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u root_path;
    zT_7034F045_Opt_228 norm;
    unsigned int path_id;
    unsigned int mod_id;
    unsigned int print_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_name;
    zT_846744CC_Arr_unsigned_char_5 hash_spill_path;
    unsigned int hsp_len;
    unsigned int fmt_path_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hash_tmp_name;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u z_msg;
    zT_2 = "I\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    si = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_12 = ctx->cli;
    zT_13 = zT_12.include_count;
    if ((unsigned char)(si < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = ctx->module_reg;
    zT_15 = &zT_17->resolver;
    zT_19 = ctx->cli;
    zT_20 = zT_19.include_dirs;
    zT_21 = (unsigned int)si;
    zT_22 = zT_20[zT_21];
    zT_16 = zT_22;
    zF_B75A4515_moduleResolverAddSe(zT_15, zT_16);
    goto z_bb_4;
    z_bb_3:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_27[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        lib_buf[_i] = zT_27[_i];
        _i++;
    }
}
    zT_31 = 0;
    zT_32 = lib_buf + zT_31;
    zT_29 = zT_32;
    zT_34 = zF_BEB0BFA8_getDefaultLibPath(zT_29, (int)(512));
    lib_len = zT_34;
    zT_35 = 0;
    if ((unsigned char)(lib_len > zT_35)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_25 = si + (unsigned int)((unsigned int)zT_23);
    si = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_41 = 0;
    zT_42 = (unsigned char*)((unsigned char*)lib_buf) + zT_41;
    zT_43 = (unsigned int)((unsigned int)lib_len) - zT_41;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    lib_path = zT_44;
    zT_45 = lib_path;
    zT_46 = zF_8CC05F84_dirExists(zT_45);
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        root_buf[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = ctx->cli;
    zT_55 = zT_54.input_file;
    root_path = zT_55;
    zT_56 = ctx->cli;
    zT_57 = zT_56.input_file;
    zT_59 = zT_57.len;
    zT_60 = 512;
    if ((unsigned char)(zT_59 <= (unsigned int)zT_60)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_49 = ctx->module_reg;
    zT_47 = &zT_49->resolver;
    zT_48 = lib_path;
    zF_B75A4515_moduleResolverAddSe(zT_47, zT_48);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_67 = ctx->cli;
    zT_68 = zT_67.input_file;
    zT_70 = zT_68.len;
    zT_71 = 0;
    zT_72 = (unsigned char*)((unsigned char*)root_buf) + zT_71;
    zT_73 = zT_70 - zT_71;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_63 = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.input_file;
    zT_64 = zT_76;
    zT_77 = zF_36F0DB6B_normalizePath(zT_63, zT_64);
    norm = zT_77;
    zT_78 = norm.has_value;
    if (zT_78) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_81 = ctx->interner;
    zT_82 = root_path;
    zT_84 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    path_id = zT_84;
    zT_86 = ctx->module_reg;
    zT_87 = path_id;
    zT_89 = zF_E4DCE20D_moduleRegistryAddMo(zT_86, zT_87);
    mod_id = zT_89;
    zT_92 = ctx->module_reg;
    zT_90 = &zT_92->import_queue;
    zT_91 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_90, zT_91);
    zT_94 = ctx->module_reg;
    zT_99 = ctx->alloc;
    zT_95 = &zT_99->module;
    zT_101 = ctx->alloc;
    zT_96 = &zT_101->scratch;
    zT_97 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_94, zT_95, zT_96, zT_97);
    zT_105 = ctx->interner;
    zT_108 = "print";
    zT_110 = 5;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    zT_106 = zT_109;
    zT_111 = zF_50C274AF_stringInternerInter(zT_105, zT_106);
    print_name_id = zT_111;
    zT_112 = ctx->store;
    zT_113 = print_name_id;
    zT_115 = zF_A42B6E3C_astStoreHasPrintRef(zT_112, zT_113);
    if (zT_115) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    n = norm.value;
    root_path = n;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_117 = "std_fmt.zig";
    zT_119 = 11;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    fmt_name = zT_118;
    zT_124 = ctx->module_reg;
    zT_120 = &zT_124->resolver;
    zT_121 = root_path;
    zT_122 = fmt_name;
    zT_126 = ctx->alloc;
    zT_123 = &zT_126->scratch;
    zT_128 = zF_6F148E15_moduleResolverResol(zT_120, zT_121, zT_122, zT_123);
    zT_129 = zT_128.has_value;
    if (zT_129) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_154[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hash_spill_path[_i] = zT_154[_i];
        _i++;
    }
}
    zT_156 = 0;
    hsp_len = zT_156;
    zT_157 = ctx->cli;
    zT_158 = zT_157.output_dir_set;
    if (zT_158) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    zT_131 = ctx->interner;
    zT_132 = fmt_name;
    zT_134 = zF_50C274AF_stringInternerInter(zT_131, zT_132);
    fmt_path_id = zT_134;
    zT_135 = ctx->module_reg;
    zT_136 = fmt_path_id;
    zT_137 = mod_id;
    zT_140 = ctx->alloc;
    zT_138 = &zT_140->scratch;
    zT_142 = zF_620E3E3B_moduleRegistryResol(zT_135, zT_136, zT_137, zT_138);
    (void)zT_142;
    zT_143 = ctx->module_reg;
    zT_148 = ctx->alloc;
    zT_144 = &zT_148->module;
    zT_150 = ctx->alloc;
    zT_145 = &zT_150->scratch;
    zT_146 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_143, zT_144, zT_145, zT_146);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_160 = ctx->cli;
    zT_161 = zT_160.output_dir;
    od = zT_161;
    zT_163 = 0;
    oi = zT_163;
    goto z_bb_20;
    z_bb_18:
    zT_186 = ".zig1_hash.tmp";
    zT_188 = 14;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    hash_tmp_name = zT_187;
    zT_190 = 0;
    hi = zT_190;
    goto z_bb_27;
    z_bb_19:
    zT_179 = 46;
    hash_spill_path[hsp_len] = zT_179;
    zT_181 = hsp_len + (unsigned int)(1);
    hsp_len = zT_181;
    zT_182 = 47;
    hash_spill_path[hsp_len] = zT_182;
    zT_184 = hsp_len + (unsigned int)(1);
    hsp_len = zT_184;
    goto z_bb_18;
    z_bb_20:
    zT_165 = od.len;
    if ((unsigned char)(oi < zT_165)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_170 = od.ptr;
    zT_171 = zT_170[oi];
    hash_spill_path[hsp_len] = zT_171;
    zT_173 = hsp_len + (unsigned int)(1);
    hsp_len = zT_173;
    goto z_bb_23;
    z_bb_22:
    zT_176 = 47;
    hash_spill_path[hsp_len] = zT_176;
    zT_178 = hsp_len + (unsigned int)(1);
    hsp_len = zT_178;
    goto z_bb_18;
    z_bb_23:
    zT_175 = oi + (unsigned int)(1);
    oi = zT_175;
    goto z_bb_20;
    z_bb_24:
    zT_167 = hsp_len < (unsigned int)(511);
    goto z_bb_26;
    z_bb_25:
    zT_167 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_167) goto z_bb_21; else goto z_bb_22;
    z_bb_27:
    zT_192 = hash_tmp_name.len;
    if ((unsigned char)(hi < zT_192)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_197 = hash_tmp_name.ptr;
    zT_198 = zT_197[hi];
    hash_spill_path[hsp_len] = zT_198;
    zT_200 = hsp_len + (unsigned int)(1);
    hsp_len = zT_200;
    goto z_bb_30;
    z_bb_29:
    zT_203 = ctx->module_reg;
    zT_208 = 0;
    zT_209 = (unsigned char*)((unsigned char*)hash_spill_path) + zT_208;
    zT_210 = hsp_len - zT_208;
    zT_211.ptr = zT_209;
    zT_211.len = zT_210;
    zT_204 = zT_211;
    zF_8767909B_moduleRegistrySpill(zT_203, zT_204);
    zT_213 = "Z\n";
    zT_215 = 2;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    z_msg = zT_214;
    zT_216 = z_msg;
    zF_48AC7B3A_markerWrite(zT_216);
    return;
    z_bb_30:
    zT_202 = hi + (unsigned int)(1);
    hi = zT_202;
    goto z_bb_27;
    z_bb_31:
    zT_194 = hsp_len < (unsigned int)(511);
    goto z_bb_33;
    z_bb_32:
    zT_194 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_194) goto z_bb_28; else goto z_bb_29;
}

/* phase_SymbolRegistration */
void zF_945DEA54_phase_SymbolRegistr(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_11;
    zT_4D61441E_DepGraph zT_13 = {0};
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_072B53A6_ModuleRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_4D61441E_DepGraph* zT_29;
    zT_6E8D187B_ModuleEntry* zT_35;
    zT_6E8D187B_ModuleEntry zT_36;
    int zT_40;
    unsigned int zT_42;
    zT_072B53A6_ModuleRegistry* zT_44;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_46 = {0};
    unsigned int zT_48;
    unsigned char zT_51;
    zT_6E8D187B_ModuleEntry* zT_52;
    int zT_53;
    zT_6E8D187B_ModuleEntry zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    zT_6E8D187B_ModuleEntry* zT_62;
    int zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    zT_22A7C88B_AstNode zT_66 = {0};
    zT_8143F551_AstKind zT_67;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_6E8D187B_ModuleEntry* zT_75;
    int zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_79 = 0;
    unsigned int zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_97;
    int zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_102 = 0;
    zT_22A7C88B_AstNode zT_103 = {0};
    zT_8143F551_AstKind zT_105;
    unsigned int zT_106;
    zT_4028D896_Arr_unsigned_char_2 zT_108;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    int zT_114;
    unsigned char* zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118 = 0;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned char* zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_136;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_DDCD424B_Slice_zT_6E8D187B_M smods;
    zT_22A7C88B_AstNode sr;
    unsigned int sdl_n;
    unsigned int sdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl;
    zT_22A7C88B_AstNode sd;
    unsigned int sk;
    zT_4028D896_Arr_unsigned_char_2 sb;
    unsigned int slen;
    unsigned int sst;
    zT_8F083A69_Slice_zT_0B42B2F8_u ssp;
    zT_8F083A69_Slice_zT_0B42B2F8_u sn;
    zT_2 = "S\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->alloc;
    zT_10 = &zT_11->scratch;
    zT_13 = zF_7F194604_depGraphInit(zT_10);
    dep_graph = zT_13;
    zT_15 = ctx->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_22 = mods.len;
    if ((unsigned char)(mi < zT_22)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_24 = ctx->module_reg;
    zT_25 = ctx->symbol_reg;
    zT_26 = ctx->typereg;
    zT_27 = ctx->store;
    zT_35 = mods.ptr;
    zT_36 = zT_35[mi];
    zT_28 = zT_36.id;
    zT_29 = &dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_24, zT_25, zT_26, zT_27, zT_28, zT_29, (unsigned char)(1));
    goto z_bb_4;
    z_bb_3:
    zT_44 = ctx->module_reg;
    zT_46 = zF_3452C137_moduleRegistryGetMo(zT_44);
    smods = zT_46;
    zT_48 = smods.len;
    if ((unsigned char)(zT_48 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_40 = 1;
    zT_42 = mi + (unsigned int)((unsigned int)zT_40);
    mi = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_52 = smods.ptr;
    zT_53 = 0;
    zT_54 = zT_52[zT_53];
    zT_55 = zT_54.ast_root;
    zT_51 = zT_55 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_51 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_51) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_59 = ctx->store;
    zT_62 = smods.ptr;
    zT_63 = 0;
    zT_64 = zT_62[zT_63];
    zT_60 = zT_64.ast_root;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_59, zT_60);
    sr = zT_66;
    zT_67 = sr.kind;
    if ((unsigned char)(zT_67 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_72 = ctx->store;
    zT_75 = smods.ptr;
    zT_76 = 0;
    zT_77 = zT_75[zT_76];
    zT_73 = zT_77.ast_root;
    zT_79 = zF_152E19CB_astStoreNodeExtraCh(zT_72, zT_73);
    sdl_n = zT_79;
    zT_81 = 0;
    sdi = zT_81;
    zT_83 = "S0";
    zT_85 = 2;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    sl = zT_84;
    zT_86 = sl;
    zF_48AC7B3A_markerWrite(zT_86);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(sdi < (unsigned int)((unsigned int)sdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_90 = ctx->store;
    zT_93 = ctx->store;
    zT_97 = smods.ptr;
    zT_98 = 0;
    zT_99 = zT_97[zT_98];
    zT_94 = zT_99.ast_root;
    zT_102 = zF_B10B1BC1_astStoreNodeExtraCh(zT_93, zT_94, (unsigned int)((unsigned int)sdi));
    zT_91 = zT_102;
    zT_103 = zF_FCDD1D35_astStoreNodeAt(zT_90, zT_91);
    sd = zT_103;
    zT_105 = sd.kind;
    zT_106 = (unsigned int)zT_105;
    sk = zT_106;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_108[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sb[_i] = zT_108[_i];
        _i++;
    }
}
    zT_110 = sk;
    zT_114 = 0;
    zT_115 = (unsigned char*)((unsigned char*)sb) + zT_114;
    zT_116 = (unsigned int)(20) - zT_114;
    zT_117.ptr = zT_115;
    zT_117.len = zT_116;
    zT_111 = zT_117;
    zT_118 = zF_A7504564_itoa(zT_110, zT_111);
    slen = zT_118;
    zT_122 = (unsigned int)(19) - (unsigned int)((unsigned int)slen);
    sst = zT_122;
    zT_127 = (unsigned char*)((unsigned char*)sb) + sst;
    zT_128 = (unsigned int)(19) - sst;
    zT_129.ptr = zT_127;
    zT_129.len = zT_128;
    zT_123 = zT_129;
    zF_48AC7B3A_markerWrite(zT_123);
    zT_131 = " ";
    zT_133 = 1;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    ssp = zT_132;
    zT_134 = ssp;
    zF_48AC7B3A_markerWrite(zT_134);
    goto z_bb_15;
    z_bb_14:
    zT_138 = "\n";
    zT_140 = 1;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    sn = zT_139;
    zT_141 = sn;
    zF_48AC7B3A_markerWrite(zT_141);
    goto z_bb_11;
    z_bb_15:
    zT_136 = sdi + (unsigned int)(1);
    sdi = zT_136;
    goto z_bb_12;
}

/* phase_TypeResolution */
void zF_D3497187_phase_TypeResolutio(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_C13790A8_anon_259686 zT_10;
    zT_3E40CD83_Sand* zT_12;
    zT_69057089_CompilerAlloc* zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_69057089_CompilerAlloc* zT_17;
    zT_4D61441E_DepGraph zT_19 = {0};
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_3D7259E2_SymbolRegistry* zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_4D61441E_DepGraph* zT_35;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    int zT_46;
    unsigned int zT_48;
    zT_3D7259E2_SymbolRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_D3EB6303_StringInterner* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    zT_3E40CD83_Sand* zT_53;
    zT_69057089_CompilerAlloc* zT_58;
    zT_6B0A7D14_AstStore* zT_60;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_3D7259E2_SymbolRegistry* zT_62;
    zT_D3EB6303_StringInterner* zT_63;
    zT_8EED1867_ResolvedTypeTable* zT_64;
    zT_072B53A6_ModuleRegistry* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_69057089_CompilerAlloc* zT_75;
    zT_338B7C76_TypeRegistry* zT_78;
    zT_F85C5DED_DiagnosticCollector* zT_79;
    zT_3E40CD83_Sand* zT_80;
    zT_69057089_CompilerAlloc* zT_83;
    zT_C890C8CB_TypeResolver zT_85 = {0};
    zT_C890C8CB_TypeResolver* zT_86;
    zT_C890C8CB_TypeResolver* zT_88;
    zT_4D61441E_DepGraph* zT_89;
    zT_C890C8CB_TypeResolver* zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_3D7259E2_SymbolRegistry* zT_96;
    zT_D3EB6303_StringInterner* zT_97;
    zT_072B53A6_ModuleRegistry* zT_98;
    zT_F85C5DED_DiagnosticCollector* zT_99;
    zT_C890C8CB_TypeResolver* zT_107;
    zT_3E40CD83_Sand* zT_108;
    zT_69057089_CompilerAlloc* zT_110;
    zT_010C8DF0_ClassificationResul zT_112 = {0};
    unsigned int* zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned char zT_119;
    zT_6E8D187B_ModuleEntry* zT_120;
    int zT_121;
    zT_6E8D187B_ModuleEntry zT_122;
    unsigned int zT_123;
    zT_6B0A7D14_AstStore* zT_127;
    unsigned int zT_128;
    zT_6E8D187B_ModuleEntry* zT_130;
    int zT_131;
    zT_6E8D187B_ModuleEntry zT_132;
    zT_22A7C88B_AstNode zT_134 = {0};
    zT_8143F551_AstKind zT_135;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    zT_6E8D187B_ModuleEntry* zT_143;
    int zT_144;
    zT_6E8D187B_ModuleEntry zT_145;
    unsigned int zT_147 = 0;
    unsigned int zT_149;
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    zT_6B0A7D14_AstStore* zT_161;
    unsigned int zT_162;
    zT_6E8D187B_ModuleEntry* zT_165;
    int zT_166;
    zT_6E8D187B_ModuleEntry zT_167;
    unsigned int zT_170 = 0;
    zT_22A7C88B_AstNode zT_171 = {0};
    zT_8143F551_AstKind zT_173;
    unsigned int zT_174;
    zT_4028D896_Arr_unsigned_char_2 zT_176;
    unsigned int zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    int zT_182;
    unsigned char* zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186 = 0;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned char* zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_204;
    unsigned char* zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned int zT_208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_C890C8CB_TypeResolver tr;
    zT_010C8DF0_ClassificationResul ptr_grp;
    zT_22A7C88B_AstNode tr2;
    unsigned int tdl_n;
    unsigned int tdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tl;
    zT_22A7C88B_AstNode td;
    unsigned int tk;
    zT_4028D896_Arr_unsigned_char_2 tb;
    unsigned int tlen;
    unsigned int tst;
    zT_8F083A69_Slice_zT_0B42B2F8_u tsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tn;
    zT_2 = "T\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->resolved_types;
    zT_9 = ctx->store;
    zT_10 = zT_9->nodes;
    zT_7 = zT_10.len;
    zF_75224871_resolvedTypeTableRe(zT_6, zT_7);
    zT_13 = ctx->alloc;
    zT_12 = &zT_13->scratch;
    zF_F1B3F8C2_sandReset(zT_12);
    zT_17 = ctx->alloc;
    zT_16 = &zT_17->scratch;
    zT_19 = zF_7F194604_depGraphInit(zT_16);
    dep_graph = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    mi = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_28 = mods.len;
    if ((unsigned char)(mi < zT_28)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_30 = ctx->module_reg;
    zT_31 = ctx->symbol_reg;
    zT_32 = ctx->typereg;
    zT_33 = ctx->store;
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_34 = zT_42.id;
    zT_35 = &dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_30, zT_31, zT_32, zT_33, zT_34, zT_35, (unsigned char)(0));
    goto z_bb_4;
    z_bb_3:
    zT_49 = ctx->symbol_reg;
    zT_50 = ctx->typereg;
    zT_51 = ctx->interner;
    zT_52 = ctx->store;
    zT_58 = ctx->alloc;
    zT_53 = &zT_58->permanent;
    zF_EF7F7D3C_constAliasPrepass(zT_49, zT_50, zT_51, zT_52, zT_53);
    zT_60 = ctx->store;
    zT_61 = ctx->typereg;
    zT_62 = ctx->symbol_reg;
    zT_63 = ctx->interner;
    zT_64 = ctx->resolved_types;
    zT_65 = ctx->module_reg;
    zT_66 = ctx->diag;
    zT_75 = ctx->alloc;
    zT_67 = &zT_75->permanent;
    zF_373A7BEF_typeResolverResolve(zT_60, zT_61, zT_62, zT_63, zT_64, zT_65, zT_66, zT_67);
    zT_78 = ctx->typereg;
    zT_79 = ctx->diag;
    zT_83 = ctx->alloc;
    zT_80 = &zT_83->scratch;
    zT_85 = zF_5BFAC855_typeResolverInit(zT_78, zT_79, zT_80);
    tr = zT_85;
    zT_86 = &tr;
    zF_D5C4530C_typeResolverBuildDe(zT_86);
    zT_88 = &tr;
    zT_89 = &dep_graph;
    zF_33272F41_typeResolverBuild(zT_88, zT_89);
    zT_92 = &tr;
    zF_30BE7185_typeResolverResolve(zT_92);
    zT_94 = ctx->store;
    zT_95 = ctx->typereg;
    zT_96 = ctx->symbol_reg;
    zT_97 = ctx->interner;
    zT_98 = ctx->module_reg;
    zT_99 = ctx->diag;
    zF_153D24FD_enumReevaluateAll(zT_94, zT_95, zT_96, zT_97, zT_98, zT_99);
    zT_107 = &tr;
    zT_110 = ctx->alloc;
    zT_108 = &zT_110->permanent;
    zT_112 = zF_ACC002C8_classifyTypeEmissio(zT_107, zT_108);
    ptr_grp = zT_112;
    zT_113 = ptr_grp.ids;
    ctx->pointer_only_ids = zT_113;
    zT_114 = ptr_grp.len;
    ctx->pointer_only_len = zT_114;
    zT_116 = mods.len;
    if ((unsigned char)(zT_116 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_46 = 1;
    zT_48 = mi + (unsigned int)((unsigned int)zT_46);
    mi = zT_48;
    goto z_bb_1;
    z_bb_5:
    zT_120 = mods.ptr;
    zT_121 = 0;
    zT_122 = zT_120[zT_121];
    zT_123 = zT_122.ast_root;
    zT_119 = zT_123 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_119 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_119) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_127 = ctx->store;
    zT_130 = mods.ptr;
    zT_131 = 0;
    zT_132 = zT_130[zT_131];
    zT_128 = zT_132.ast_root;
    zT_134 = zF_FCDD1D35_astStoreNodeAt(zT_127, zT_128);
    tr2 = zT_134;
    zT_135 = tr2.kind;
    if ((unsigned char)(zT_135 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_140 = ctx->store;
    zT_143 = mods.ptr;
    zT_144 = 0;
    zT_145 = zT_143[zT_144];
    zT_141 = zT_145.ast_root;
    zT_147 = zF_152E19CB_astStoreNodeExtraCh(zT_140, zT_141);
    tdl_n = zT_147;
    zT_149 = 0;
    tdi = zT_149;
    zT_151 = "T0";
    zT_153 = 2;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    tl = zT_152;
    zT_154 = tl;
    zF_48AC7B3A_markerWrite(zT_154);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(tdi < (unsigned int)((unsigned int)tdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_158 = ctx->store;
    zT_161 = ctx->store;
    zT_165 = mods.ptr;
    zT_166 = 0;
    zT_167 = zT_165[zT_166];
    zT_162 = zT_167.ast_root;
    zT_170 = zF_B10B1BC1_astStoreNodeExtraCh(zT_161, zT_162, (unsigned int)((unsigned int)tdi));
    zT_159 = zT_170;
    zT_171 = zF_FCDD1D35_astStoreNodeAt(zT_158, zT_159);
    td = zT_171;
    zT_173 = td.kind;
    zT_174 = (unsigned int)zT_173;
    tk = zT_174;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_176[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        tb[_i] = zT_176[_i];
        _i++;
    }
}
    zT_178 = tk;
    zT_182 = 0;
    zT_183 = (unsigned char*)((unsigned char*)tb) + zT_182;
    zT_184 = (unsigned int)(20) - zT_182;
    zT_185.ptr = zT_183;
    zT_185.len = zT_184;
    zT_179 = zT_185;
    zT_186 = zF_A7504564_itoa(zT_178, zT_179);
    tlen = zT_186;
    zT_190 = (unsigned int)(19) - (unsigned int)((unsigned int)tlen);
    tst = zT_190;
    zT_195 = (unsigned char*)((unsigned char*)tb) + tst;
    zT_196 = (unsigned int)(19) - tst;
    zT_197.ptr = zT_195;
    zT_197.len = zT_196;
    zT_191 = zT_197;
    zF_48AC7B3A_markerWrite(zT_191);
    zT_199 = " ";
    zT_201 = 1;
    zT_200.ptr = zT_199;
    zT_200.len = zT_201;
    tsp = zT_200;
    zT_202 = tsp;
    zF_48AC7B3A_markerWrite(zT_202);
    goto z_bb_15;
    z_bb_14:
    zT_206 = "\n";
    zT_208 = 1;
    zT_207.ptr = zT_206;
    zT_207.len = zT_208;
    tn = zT_207;
    zT_209 = tn;
    zF_48AC7B3A_markerWrite(zT_209);
    goto z_bb_11;
    z_bb_15:
    zT_204 = tdi + (unsigned int)(1);
    tdi = zT_204;
    goto z_bb_12;
}

/* phase_FrontResolution */
void zF_F862154A_phase_FrontResoluti(zT_5AB29387_CompilerContext* ctx) {
    zT_6DCFC8DB_FrontResCtx zT_2;
    zT_6B0A7D14_AstStore* zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_3E40CD83_Sand* zT_11;
    zT_66E7D2EF_CoercionTable* zT_12;
    zT_21D3708C_U32ToU32Map* zT_13;
    zT_21D3708C_U32ToU32Map* zT_14;
    zT_21D3708C_U32ToU32Map* zT_15;
    zT_21D3708C_U32ToU32Map* zT_16;
    zT_21D3708C_U32ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_19;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_3 = ctx->store;
    zT_2.store = zT_3;
    zT_4 = ctx->typereg;
    zT_2.typereg = zT_4;
    zT_5 = ctx->symbol_reg;
    zT_2.symbol_reg = zT_5;
    zT_6 = ctx->resolved_types;
    zT_2.resolved_types = zT_6;
    zT_7 = ctx->module_reg;
    zT_2.module_reg = zT_7;
    zT_8 = ctx->interner;
    zT_2.interner = zT_8;
    zT_9 = ctx->diag;
    zT_2.diag = zT_9;
    zT_10 = ctx->alloc;
    zT_11 = &zT_10->scratch;
    zT_2.scratch = zT_11;
    zT_12 = ctx->coercion_table;
    zT_2.coercion_table = zT_12;
    zT_13 = &ctx->enum_value_table;
    zT_2.enum_value_table = zT_13;
    zT_14 = &ctx->tuple_index_table;
    zT_2.tuple_index_table = zT_14;
    zT_15 = &ctx->error_code_registry;
    zT_2.error_code_registry = zT_15;
    zT_16 = &ctx->call_arg_types;
    zT_2.call_arg_types = zT_16;
    zT_17 = &ctx->call_param_map;
    zT_2.call_param_map = zT_17;
    zT_18 = &ctx->suspending_fns;
    zT_2.suspending_fns = zT_18;
    frc = zT_2;
    zT_19 = &frc;
    zF_8A0E7747_frontResolveModuleI(zT_19);
    return;
}

/* phase_ComptimeEvaluation */
void zF_9609BF31_phase_ComptimeEvalu(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15 = {0};
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_7432B7FA_Opt_232 zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    zT_C13790A8_anon_259686 zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_28;
    zT_22A7C88B_AstNode zT_32 = {0};
    zT_8143F551_AstKind zT_33;
    zT_DA663F79_ComptimeEval* zT_38;
    zT_E03A1DC3_Opt_204 zT_42 = {0};
    unsigned char zT_43;
    zT_77F6F59C_ComptimeFoldTable* zT_45;
    zT_89B1DDDA_ComptimeVal zT_47;
    zT_8143F551_AstKind zT_50;
    unsigned char zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned char zT_58;
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    zT_22A7C88B_AstNode zT_68 = {0};
    zT_8143F551_AstKind zT_70;
    unsigned int zT_71;
    unsigned char zT_74;
    unsigned char zT_77;
    unsigned char zT_80;
    zT_DA663F79_ComptimeEval* zT_84;
    unsigned int zT_85;
    zT_E03A1DC3_Opt_204 zT_88 = {0};
    unsigned char zT_89;
    zT_77F6F59C_ComptimeFoldTable* zT_91;
    unsigned int zT_92;
    zT_89B1DDDA_ComptimeVal zT_93;
    zT_8143F551_AstKind zT_96;
    unsigned char zT_100;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_108 = 0;
    zT_DA663F79_ComptimeEval* zT_112;
    unsigned int zT_113;
    zT_E03A1DC3_Opt_204 zT_116 = {0};
    unsigned char zT_117;
    unsigned char zT_119;
    zT_77F6F59C_ComptimeFoldTable* zT_122;
    unsigned int zT_123;
    zT_89B1DDDA_ComptimeVal zT_124;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_m;
    zT_DA663F79_ComptimeEval ce;
    unsigned int ni;
    zT_22A7C88B_AstNode node;
    zT_E03A1DC3_Opt_204 val;
    zT_89B1DDDA_ComptimeVal v;
    zT_22A7C88B_AstNode init_n;
    unsigned int ik;
    zT_E03A1DC3_Opt_204 val2;
    zT_89B1DDDA_ComptimeVal v2;
    zT_E03A1DC3_Opt_204 cval;
    zT_89B1DDDA_ComptimeVal cv;
    zT_2 = "CE\n";
    zT_4 = 3;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    pc_m = zT_3;
    zT_5 = pc_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ce.diag = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    ni = zT_22;
    goto z_bb_1;
    z_bb_1:
    zT_23 = ctx->store;
    zT_24 = zT_23->nodes;
    zT_25 = zT_24.len;
    if ((unsigned char)(ni < zT_25)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_28 = ctx->store;
    zT_32 = zF_FCDD1D35_astStoreNodeAt(zT_28, (unsigned int)((unsigned int)ni));
    node = zT_32;
    zT_33 = node.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_128 = ni + (unsigned int)(1);
    ni = zT_128;
    goto z_bb_1;
    z_bb_5:
    zT_38 = &ce;
    zT_42 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_38, (unsigned int)((unsigned int)ni));
    val = zT_42;
    zT_43 = val.has_value;
    if (zT_43) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_50 = node.kind;
    if ((unsigned char)(zT_50 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    v = val.value;
    zT_45 = &ctx->comptime_folds;
    zT_47 = v;
    zF_376429F5_comptimeFoldTablePu(zT_45, (unsigned int)((unsigned int)ni), zT_47);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_55 = node.child_1;
    zT_56 = 0;
    zT_54 = zT_55 != (unsigned int)zT_56;
    goto z_bb_12;
    z_bb_11:
    zT_54 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_54) goto z_bb_13; else goto z_bb_15;
    z_bb_13:
    zT_58 = node.flags;
    if ((unsigned char)((unsigned char)(zT_58 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_96 = node.kind;
    if ((unsigned char)(zT_96 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_31; else goto z_bb_32;
    z_bb_16:
    zT_64 = ctx->store;
    zT_65 = node.child_1;
    zT_68 = zF_FCDD1D35_astStoreNodeAt(zT_64, zT_65);
    init_n = zT_68;
    zT_70 = init_n.kind;
    zT_71 = (unsigned int)zT_70;
    ik = zT_71;
    if ((unsigned char)(ik >= (unsigned int)(33))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_74 = ik <= (unsigned int)(42);
    goto z_bb_20;
    z_bb_19:
    zT_74 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_74) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_77 = ik == (unsigned int)(62);
    goto z_bb_23;
    z_bb_22:
    zT_77 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_77) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_80 = ik == (unsigned int)(64);
    goto z_bb_26;
    z_bb_25:
    zT_80 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_80) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_84 = &ce;
    zT_85 = node.child_1;
    zT_88 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_84, zT_85);
    val2 = zT_88;
    zT_89 = val2.has_value;
    if (zT_89) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_17;
    z_bb_29:
    v2 = val2.value;
    zT_91 = &ctx->comptime_folds;
    zT_92 = node.child_1;
    zT_93 = v2;
    zF_376429F5_comptimeFoldTablePu(zT_91, zT_92, zT_93);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_101 = node.child_2;
    zT_100 = zT_101 == (unsigned int)(0);
    goto z_bb_33;
    z_bb_32:
    zT_100 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_100) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_104 = ctx->store;
    zT_108 = zF_8BA26B9E_astStoreNodePayload(zT_104, (unsigned int)((unsigned int)ni));
    if ((unsigned char)(zT_108 == (unsigned int)(0))) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_14;
    z_bb_36:
    zT_112 = &ce;
    zT_113 = node.child_0;
    zT_116 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_112, zT_113);
    cval = zT_116;
    zT_117 = cval.has_value;
    if (zT_117) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    cv = cval.value;
    zT_119 = cv.kind;
    if ((unsigned char)(zT_119 == (unsigned char)(1))) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    zT_122 = &ctx->comptime_folds;
    zT_123 = node.child_0;
    zT_124 = cv;
    zF_376429F5_comptimeFoldTablePu(zT_122, zT_123, zT_124);
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
}

/* phase_SemanticAnalysis */
void zF_0666ED4F_phase_SemanticAnaly(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_6DCFC8DB_FrontResCtx zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_D3EB6303_StringInterner* zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    zT_69057089_CompilerAlloc* zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_66E7D2EF_CoercionTable* zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    zT_21D3708C_U32ToU32Map* zT_22;
    zT_21D3708C_U32ToU32Map* zT_23;
    zT_21D3708C_U32ToU32Map* zT_24;
    zT_21D3708C_U32ToU32Map* zT_25;
    zT_A4CE86B7_U64ToU32Map* zT_26;
    zT_072B53A6_ModuleRegistry* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_30 = {0};
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_69057089_CompilerAlloc* zT_38;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    unsigned int zT_43;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_60 = 0;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_6E8D187B_ModuleEntry* zT_72;
    zT_6E8D187B_ModuleEntry zT_73;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_76;
    zT_8EED1867_ResolvedTypeTable* zT_77;
    zT_F85C5DED_DiagnosticCollector* zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_3D7259E2_SymbolRegistry* zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_66E7D2EF_CoercionTable* zT_84;
    zT_21D3708C_U32ToU32Map* zT_85;
    zT_21D3708C_U32ToU32Map* zT_86;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_D3EB6303_StringInterner* zT_88;
    zT_21D3708C_U32ToU32Map* zT_89;
    zT_21D3708C_U32ToU32Map* zT_90;
    zT_072B53A6_ModuleRegistry* zT_91;
    zT_A4CE86B7_U64ToU32Map* zT_92;
    zT_69057089_CompilerAlloc* zT_93;
    zT_6E8D187B_ModuleEntry* zT_100;
    zT_6E8D187B_ModuleEntry zT_101;
    zT_38C12417_SemanticAnalyzer zT_112 = {0};
    int zT_114;
    unsigned int zT_115;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_120;
    unsigned int zT_124 = 0;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    zT_22A7C88B_AstNode zT_129 = {0};
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_8143F551_AstKind zT_135;
    unsigned int zT_139;
    int zT_140;
    zT_6DCFC8DB_FrontResCtx* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_146;
    zT_6E8D187B_ModuleEntry* zT_148;
    zT_6E8D187B_ModuleEntry zT_149;
    zT_6E8D187B_ModuleEntry* zT_153;
    zT_6E8D187B_ModuleEntry zT_154;
    unsigned char* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    zT_38C12417_SemanticAnalyzer* zT_161;
    unsigned int zT_162;
    unsigned char* zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    unsigned int zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    zT_8143F551_AstKind zT_169;
    unsigned char zT_173;
    unsigned int zT_174;
    zT_6B0A7D14_AstStore* zT_178;
    unsigned int zT_179;
    zT_22A7C88B_AstNode zT_182 = {0};
    zT_8143F551_AstKind zT_183;
    zT_38C12417_SemanticAnalyzer* zT_187;
    unsigned int zT_188;
    zT_8143F551_AstKind zT_190;
    unsigned char zT_194;
    unsigned char zT_195;
    zT_38C12417_SemanticAnalyzer* zT_200;
    unsigned int zT_201;
    zT_8143F551_AstKind zT_203;
    zT_38C12417_SemanticAnalyzer* zT_207;
    unsigned int zT_208;
    zT_8143F551_AstKind zT_210;
    zT_38C12417_SemanticAnalyzer* zT_214;
    unsigned int zT_215;
    int zT_217;
    unsigned int zT_219;
    int zT_220;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mz;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u ad;
    zT_8F083A69_Slice_zT_0B42B2F8_u dse_m;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa0;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa1;
    zT_22A7C88B_AstNode di_inn;
    zT_2 = "RS";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    rs = zT_3;
    zT_5 = rs;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->store;
    zT_10.store = zT_11;
    zT_12 = ctx->typereg;
    zT_10.typereg = zT_12;
    zT_13 = ctx->symbol_reg;
    zT_10.symbol_reg = zT_13;
    zT_14 = ctx->resolved_types;
    zT_10.resolved_types = zT_14;
    zT_15 = ctx->module_reg;
    zT_10.module_reg = zT_15;
    zT_16 = ctx->interner;
    zT_10.interner = zT_16;
    zT_17 = ctx->diag;
    zT_10.diag = zT_17;
    zT_18 = ctx->alloc;
    zT_19 = &zT_18->scratch;
    zT_10.scratch = zT_19;
    zT_20 = ctx->coercion_table;
    zT_10.coercion_table = zT_20;
    zT_21 = &ctx->enum_value_table;
    zT_10.enum_value_table = zT_21;
    zT_22 = &ctx->tuple_index_table;
    zT_10.tuple_index_table = zT_22;
    zT_23 = &ctx->error_code_registry;
    zT_10.error_code_registry = zT_23;
    zT_24 = &ctx->call_arg_types;
    zT_10.call_arg_types = zT_24;
    zT_25 = &ctx->call_param_map;
    zT_10.call_param_map = zT_25;
    zT_26 = &ctx->suspending_fns;
    zT_10.suspending_fns = zT_26;
    frc = zT_10;
    zT_28 = ctx->module_reg;
    zT_30 = zF_3452C137_moduleRegistryGetMo(zT_28);
    mods = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    mi = zT_33;
    goto z_bb_1;
    z_bb_1:
    zT_35 = mods.len;
    if ((unsigned char)(mi < zT_35)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_38 = ctx->alloc;
    zT_37 = &zT_38->scratch;
    zF_F1B3F8C2_sandReset(zT_37);
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_43 = zT_42.ast_root;
    ast_root = zT_43;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_220 = 1;
    zT_222 = mi + (unsigned int)((unsigned int)zT_220);
    mi = zT_222;
    goto z_bb_1;
    z_bb_5:
    zT_47 = "MZ";
    zT_49 = 2;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    mz = zT_48;
    zT_50 = mz;
    zF_48AC7B3A_markerWrite(zT_50);
    goto z_bb_4;
    z_bb_6:
    zT_52 = ctx->store;
    zT_53 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_52, zT_53);
    zT_57 = ctx->store;
    zT_58 = ast_root;
    zT_60 = zF_152E19CB_astStoreNodeExtraCh(zT_57, zT_58);
    decls_n = zT_60;
    zT_62 = "AD";
    zT_64 = 2;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    ad = zT_63;
    zT_65 = ad;
    zF_48AC7B3A_markerWrite(zT_65);
    zT_67 = "DSE\n";
    zT_69 = 4;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    dse_m = zT_68;
    zT_70 = dse_m;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_72 = mods.ptr;
    zT_73 = zT_72[mi];
    zT_74 = zT_73.source_file_id;
    src_fid = zT_74;
    zT_93 = ctx->alloc;
    zT_76 = &zT_93->scratch;
    zT_77 = ctx->resolved_types;
    zT_78 = ctx->diag;
    zT_79 = ctx->typereg;
    zT_80 = ctx->symbol_reg;
    zT_81 = ctx->store;
    zT_100 = mods.ptr;
    zT_101 = zT_100[mi];
    zT_82 = zT_101.id;
    zT_83 = src_fid;
    zT_84 = ctx->coercion_table;
    zT_85 = &ctx->enum_value_table;
    zT_86 = &ctx->tuple_index_table;
    zT_87 = &ctx->error_code_registry;
    zT_88 = ctx->interner;
    zT_89 = &ctx->call_arg_types;
    zT_90 = &ctx->call_param_map;
    zT_91 = ctx->module_reg;
    zT_92 = &ctx->suspending_fns;
    zT_112 = zF_84ADA681_semanticAnalyzerIni(zT_76, zT_77, zT_78, zT_79, zT_80, zT_81, zT_82, zT_83, zT_84, zT_85, zT_86, zT_87, zT_88, zT_89, zT_90, zT_91, zT_92);
    sa = zT_112;
    zT_114 = 0;
    zT_115 = (unsigned int)zT_114;
    di = zT_115;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_119 = ctx->store;
    zT_120 = ast_root;
    zT_124 = zF_B10B1BC1_astStoreNodeExtraCh(zT_119, zT_120, (unsigned int)((unsigned int)di));
    decl_idx = zT_124;
    zT_126 = ctx->store;
    zT_127 = decl_idx;
    zT_129 = zF_FCDD1D35_astStoreNodeAt(zT_126, zT_127);
    decl = zT_129;
    zT_131 = "DN";
    zT_133 = 2;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    dn = zT_132;
    zT_134 = dn;
    zF_48AC7B3A_markerWrite(zT_134);
    zT_135 = decl.kind;
    if ((unsigned char)(zT_135 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_217 = 1;
    zT_219 = di + (unsigned int)((unsigned int)zT_217);
    di = zT_219;
    goto z_bb_7;
    z_bb_11:
    zT_139 = decl.child_0;
    zT_140 = 0;
    if ((unsigned char)(zT_139 != (unsigned int)zT_140)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_169 = decl.kind;
    if ((unsigned char)(zT_169 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_142 = &frc;
    zT_148 = mods.ptr;
    zT_149 = zT_148[mi];
    zT_143 = zT_149.id;
    zT_144 = decl.child_0;
    zT_153 = mods.ptr;
    zT_154 = zT_153[mi];
    zT_146 = zT_154.source_file_id;
    zF_783226DA_resolveStmtTypes(zT_142, zT_143, zT_144, (unsigned int)(0), zT_146);
    goto z_bb_15;
    z_bb_15:
    zT_157 = "SA";
    zT_159 = 2;
    zT_158.ptr = zT_157;
    zT_158.len = zT_159;
    sa0 = zT_158;
    zT_160 = sa0;
    zF_48AC7B3A_markerWrite(zT_160);
    zT_161 = &sa;
    zT_162 = decl_idx;
    zF_406A2501_semanticAnalyzerRes(zT_161, zT_162);
    zT_165 = "sA";
    zT_167 = 2;
    zT_166.ptr = zT_165;
    zT_166.len = zT_167;
    sa1 = zT_166;
    zT_168 = sa1;
    zF_48AC7B3A_markerWrite(zT_168);
    goto z_bb_12;
    z_bb_16:
    zT_174 = decl.child_1;
    zT_173 = zT_174 != (unsigned int)(0);
    goto z_bb_18;
    z_bb_17:
    zT_173 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_173) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_178 = ctx->store;
    zT_179 = decl.child_1;
    zT_182 = zF_FCDD1D35_astStoreNodeAt(zT_178, zT_179);
    di_inn = zT_182;
    zT_183 = di_inn.kind;
    if ((unsigned char)(zT_183 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_210 = decl.kind;
    if ((unsigned char)(zT_210 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_31; else goto z_bb_32;
    z_bb_22:
    zT_187 = &sa;
    zT_188 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_187, zT_188);
    goto z_bb_23;
    z_bb_23:
    zT_190 = di_inn.kind;
    if ((unsigned char)(zT_190 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_195 = di_inn.flags;
    zT_194 = (unsigned char)(zT_195 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_194 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_194) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_200 = &sa;
    zT_201 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_200, zT_201);
    goto z_bb_28;
    z_bb_28:
    zT_203 = di_inn.kind;
    if ((unsigned char)(zT_203 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_207 = &sa;
    zT_208 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_207, zT_208);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_20;
    z_bb_31:
    zT_214 = &sa;
    zT_215 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_214, zT_215);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_20;
}

/* phase_StaticAnalyzers */
void zF_F3B55B42_phase_StaticAnalyze(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_C98AF326_CompilerCli zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    zT_C98AF326_CompilerCli zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    zT_C98AF326_CompilerCli zT_22;
    unsigned char zT_23;
    zT_072B53A6_ModuleRegistry* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29 = {0};
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_69057089_CompilerAlloc* zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_46;
    zT_060CD1EB_SymbolTable* zT_50 = 0;
    zT_7E2F335A_AnalyzerContext zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    zT_69057089_CompilerAlloc* zT_57;
    zT_3E40CD83_Sand* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_69057089_CompilerAlloc* zT_63;
    zT_3E40CD83_Sand* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_C98AF326_CompilerCli zT_67;
    unsigned char zT_68;
    unsigned char zT_69;
    int zT_70;
    int zT_72;
    unsigned char zT_74;
    zT_C98AF326_CompilerCli zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    int zT_78;
    int zT_80;
    unsigned char zT_82;
    zT_C98AF326_CompilerCli zT_83;
    unsigned char zT_84;
    unsigned char zT_85;
    int zT_86;
    int zT_88;
    unsigned char zT_90;
    zT_C98AF326_CompilerCli zT_91;
    unsigned char zT_92;
    unsigned char zT_93;
    int zT_94;
    int zT_96;
    unsigned char zT_98;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    zT_6E8D187B_ModuleEntry* zT_103;
    zT_6E8D187B_ModuleEntry zT_104;
    unsigned int zT_105;
    zT_7E2F335A_AnalyzerContext* zT_106;
    unsigned int zT_107;
    zT_227EDE07_SourceManager* zT_109;
    int zT_111;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_060CD1EB_SymbolTable* sym_table;
    zT_7E2F335A_AnalyzerContext ac;
    zT_2 = "A\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = ctx->alloc;
    zT_9 = &zT_10->scratch;
    zF_CB5A85E9_sandResetPeak(zT_9);
    zT_12 = ctx->cli;
    zT_13 = zT_12.no_null_check;
    if ((unsigned char)(zT_13 != (unsigned char)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_17 = ctx->cli;
    zT_18 = zT_17.no_lifetime_check;
    zT_16 = zT_18 != (unsigned char)(1);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = ctx->cli;
    zT_23 = zT_22.no_leak_check;
    zT_21 = zT_23 != (unsigned char)(1);
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = ctx->module_reg;
    zT_29 = zF_3452C137_moduleRegistryGetMo(zT_27);
    mods = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    mi = zT_32;
    goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    zT_34 = mods.len;
    if ((unsigned char)(mi < zT_34)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = ctx->alloc;
    zT_36 = &zT_37->scratch;
    zF_F1B3F8C2_sandReset(zT_36);
    zT_40 = mods.ptr;
    zT_41 = zT_40[mi];
    zT_42 = zT_41.ast_root;
    ast_root = zT_42;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_111 = 1;
    zT_113 = mi + (unsigned int)((unsigned int)zT_111);
    mi = zT_113;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_46 = ctx->symbol_reg;
    zT_50 = zF_9B36C202_symbolRegistryGetTa(zT_46, (unsigned int)((unsigned int)mi));
    sym_table = zT_50;
    zT_53 = ctx->store;
    zT_52.store = zT_53;
    zT_54 = ctx->typereg;
    zT_52.registry = zT_54;
    zT_55 = ctx->interner;
    zT_52.interner = zT_55;
    zT_56 = ctx->diag;
    zT_52.diag = zT_56;
    zT_52.symbols = sym_table;
    zT_57 = ctx->alloc;
    zT_58 = &zT_57->scratch;
    zT_52.alloc = zT_58;
    zT_59 = 0;
    zT_52.current_fn_name = zT_59;
    zT_60 = 0;
    zT_52.defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_60;
    zT_61 = 0;
    zT_52.defer_queue_len = zT_61;
    zT_62 = 0;
    zT_52.defer_queue_cap = zT_62;
    zT_63 = ctx->alloc;
    zT_64 = &zT_63->scratch;
    zT_52.defer_queue_alloc = zT_64;
    zT_65 = 0;
    zT_52.current_depth = zT_65;
    zT_66 = 0;
    zT_52.null_analysis_mode = zT_66;
    zT_67 = ctx->cli;
    zT_68 = zT_67.no_null_check;
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_70 = 1;
    zT_69 = (unsigned char)zT_70;
    goto z_bb_17;
    z_bb_16:
    zT_72 = 0;
    zT_69 = (unsigned char)zT_72;
    goto z_bb_17;
    z_bb_17:
    zT_74 = (unsigned char)zT_69;
    zT_52.skip_null_check = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.no_lifetime_check;
    if (zT_76) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_78 = 1;
    zT_77 = (unsigned char)zT_78;
    goto z_bb_20;
    z_bb_19:
    zT_80 = 0;
    zT_77 = (unsigned char)zT_80;
    goto z_bb_20;
    z_bb_20:
    zT_82 = (unsigned char)zT_77;
    zT_52.skip_lifetime_check = zT_82;
    zT_83 = ctx->cli;
    zT_84 = zT_83.no_leak_check;
    if (zT_84) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_86 = 1;
    zT_85 = (unsigned char)zT_86;
    goto z_bb_23;
    z_bb_22:
    zT_88 = 0;
    zT_85 = (unsigned char)zT_88;
    goto z_bb_23;
    z_bb_23:
    zT_90 = (unsigned char)zT_85;
    zT_52.skip_doublefree_check = zT_90;
    zT_91 = ctx->cli;
    zT_92 = zT_91.warn_all;
    if (zT_92) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_94 = 1;
    zT_93 = (unsigned char)zT_94;
    goto z_bb_26;
    z_bb_25:
    zT_96 = 0;
    zT_93 = (unsigned char)zT_96;
    goto z_bb_26;
    z_bb_26:
    zT_98 = (unsigned char)zT_93;
    zT_52.warn_all = zT_98;
    zT_99 = zF_43C99FB3_onNullStmt;
    zT_52.on_stmt_cb = zT_99;
    zT_100 = 0;
    zT_52.in_defer_exec = zT_100;
    zT_101 = 0;
    zT_52.lifetime_analysis_mode = zT_101;
    zT_102 = 0;
    zT_52.doublefree_analysis_mode = zT_102;
    zT_103 = mods.ptr;
    zT_104 = zT_103[mi];
    zT_105 = zT_104.source_file_id;
    zT_52.source_file_id = zT_105;
    ac = zT_52;
    zT_106 = &ac;
    zT_107 = ast_root;
    zF_F697813C_runAllAnalyzers(zT_106, zT_107);
    zT_109 = ctx->source_man;
    zF_196FDF3B_sourceManagerResetF(zT_109);
    goto z_bb_12;
}

/* phase_AsyncFrameSize */
void zF_9BC6214D_phase_AsyncFrameSiz(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_3D7259E2_SymbolRegistry* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_072B53A6_ModuleRegistry* zT_10;
    zT_338B7C76_TypeRegistry* zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_12;
    zT_A4CE86B7_U64ToU32Map* zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_A4CE86B7_U64ToU32Map* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_B687BB96_U32ArrayList* zT_19;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_69057089_CompilerAlloc* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_2 = "AFS\n";
    zT_4 = 4;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_22 = ctx->alloc;
    zT_6 = &zT_22->module;
    zT_7 = ctx->store;
    zT_8 = ctx->symbol_reg;
    zT_9 = ctx->interner;
    zT_10 = ctx->module_reg;
    zT_11 = ctx->typereg;
    zT_12 = ctx->resolved_types;
    zT_13 = &ctx->suspending_fns;
    zT_14 = &ctx->frame_sizes;
    zT_15 = &ctx->state_widths;
    zT_16 = &ctx->awaited_fns;
    zT_17 = &ctx->async_hidden_fns;
    zT_18 = &ctx->driver_targets;
    zT_19 = &ctx->parent_result_type_list;
    zT_20 = &ctx->parent_result_start;
    zT_21 = &ctx->parent_result_count;
    zF_7DBA21B2_asyncFrameSizeRun(zT_6, zT_7, zT_8, zT_9, zT_10, zT_11, zT_12, zT_13, zT_14, zT_15, zT_16, zT_17, zT_18, zT_19, zT_20, zT_21);
    return;
}

/* phase_LIRLowering */
void zF_1F21ABE7_phase_LIRLowering(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_4028D896_Arr_unsigned_char_2 zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_C13790A8_anon_259686 zT_17;
    unsigned int zT_18;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_4028D896_Arr_unsigned_char_2 zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    zT_01BE9D46_AstValuePool zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_69057089_CompilerAlloc* zT_76;
    zT_CA01C129_LirSlotArrayList* zT_79;
    zT_846744CC_Arr_unsigned_char_5 zT_81;
    unsigned int zT_83;
    zT_C98AF326_CompilerCli zT_84;
    unsigned char zT_85;
    zT_C98AF326_CompilerCli zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned char zT_94;
    unsigned char* zT_97;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned char zT_103;
    unsigned int zT_105;
    unsigned char zT_106;
    unsigned int zT_108;
    unsigned char zT_109;
    unsigned int zT_111;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    unsigned int zT_119;
    unsigned char zT_121;
    unsigned char* zT_124;
    unsigned char zT_125;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_7E7544E4_LirStream* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    zT_3E40CD83_Sand* zT_132;
    int zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    zT_69057089_CompilerAlloc* zT_140;
    zT_6B356268_SemanticContext zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_3D7259E2_SymbolRegistry* zT_146;
    zT_8EED1867_ResolvedTypeTable* zT_147;
    zT_66E7D2EF_CoercionTable* zT_148;
    zT_F85C5DED_DiagnosticCollector* zT_149;
    unsigned char zT_150;
    zT_21D3708C_U32ToU32Map* zT_151;
    zT_21D3708C_U32ToU32Map* zT_152;
    zT_21D3708C_U32ToU32Map* zT_153;
    zT_21D3708C_U32ToU32Map* zT_154;
    zT_77F6F59C_ComptimeFoldTable* zT_155;
    unsigned int zT_156;
    zT_C98AF326_CompilerCli zT_157;
    unsigned char zT_158;
    zT_A4CE86B7_U64ToU32Map* zT_159;
    zT_A4CE86B7_U64ToU32Map* zT_160;
    zT_A4CE86B7_U64ToU32Map* zT_161;
    unsigned char zT_162;
    zT_072B53A6_ModuleRegistry* zT_164;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_166 = {0};
    zT_3E40CD83_Sand* zT_168;
    zT_69057089_CompilerAlloc* zT_169;
    zT_B687BB96_U32ArrayList zT_171 = {0};
    unsigned char zT_173;
    int zT_175;
    unsigned int zT_176;
    unsigned int zT_178;
    zT_6E8D187B_ModuleEntry* zT_180;
    zT_6E8D187B_ModuleEntry zT_181;
    unsigned int zT_182;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    zT_4028D896_Arr_unsigned_char_2 zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    int zT_196;
    unsigned char* zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200 = 0;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_6E8D187B_ModuleEntry* zT_217;
    zT_6E8D187B_ModuleEntry zT_218;
    unsigned int zT_219;
    zT_4028D896_Arr_unsigned_char_2 zT_223;
    unsigned int zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    zT_6E8D187B_ModuleEntry* zT_227;
    zT_6E8D187B_ModuleEntry zT_228;
    int zT_232;
    unsigned char* zT_233;
    unsigned int zT_234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    unsigned int zT_236 = 0;
    unsigned int zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned char* zT_245;
    unsigned int zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    zT_6B0A7D14_AstStore* zT_250;
    unsigned int zT_251;
    zT_6E8D187B_ModuleEntry* zT_253;
    zT_6E8D187B_ModuleEntry zT_254;
    zT_22A7C88B_AstNode zT_256 = {0};
    zT_8143F551_AstKind zT_257;
    unsigned char* zT_262;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    unsigned int zT_264;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    zT_6B0A7D14_AstStore* zT_267;
    unsigned int zT_268;
    zT_6E8D187B_ModuleEntry* zT_270;
    zT_6E8D187B_ModuleEntry zT_271;
    unsigned int zT_273 = 0;
    unsigned int zT_275;
    zT_4028D896_Arr_unsigned_char_2 zT_277;
    unsigned int zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    int zT_283;
    unsigned char* zT_284;
    unsigned int zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned int zT_287 = 0;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned char* zT_296;
    unsigned int zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    zT_6B0A7D14_AstStore* zT_300;
    unsigned int zT_301;
    zT_B687BB96_U32ArrayList* zT_302;
    zT_6E8D187B_ModuleEntry* zT_304;
    zT_6E8D187B_ModuleEntry zT_305;
    zT_6E8D187B_ModuleEntry* zT_307;
    zT_6E8D187B_ModuleEntry* zT_308;
    unsigned char zT_311;
    unsigned int zT_313;
    zT_6B0A7D14_AstStore* zT_317;
    unsigned int zT_318;
    zT_6E8D187B_ModuleEntry* zT_321;
    zT_6E8D187B_ModuleEntry zT_322;
    unsigned int zT_325 = 0;
    zT_6B0A7D14_AstStore* zT_327;
    unsigned int zT_328;
    zT_22A7C88B_AstNode zT_330 = {0};
    zT_8143F551_AstKind zT_332;
    unsigned int zT_333;
    zT_4028D896_Arr_unsigned_char_2 zT_335;
    unsigned int zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    int zT_341;
    unsigned char* zT_342;
    unsigned int zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned int zT_345 = 0;
    unsigned int zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned char* zT_354;
    unsigned int zT_355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    unsigned char* zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    unsigned int zT_360;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_361;
    zT_8143F551_AstKind zT_362;
    unsigned char* zT_367;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    unsigned int zT_369;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_370;
    unsigned char zT_371;
    zT_6B0A7D14_AstStore* zT_378;
    zT_A8B842CF_anon_259719 zT_379;
    zT_243D6A41_FnProto* zT_380;
    zT_6B0A7D14_AstStore* zT_381;
    unsigned int zT_382;
    unsigned int zT_384 = 0;
    unsigned int zT_385;
    zT_243D6A41_FnProto zT_386;
    zT_6E8D187B_ModuleEntry* zT_388;
    zT_6E8D187B_ModuleEntry zT_389;
    unsigned int zT_390;
    unsigned int zT_398;
    zT_79FAE712_u64 zT_400;
    zT_A4CE86B7_U64ToU32Map* zT_401;
    zT_79FAE712_u64 zT_402;
    zT_6B356268_SemanticContext* zT_407;
    zT_3E40CD83_Sand* zT_408;
    zT_69057089_CompilerAlloc* zT_410;
    zT_02EB57B2_LirLowerer zT_412 = {0};
    zT_6E8D187B_ModuleEntry* zT_413;
    zT_6E8D187B_ModuleEntry zT_414;
    unsigned int zT_415;
    zT_072B53A6_ModuleRegistry* zT_416;
    zT_02EB57B2_LirLowerer* zT_418;
    unsigned int zT_419;
    zT_BBC23664_LirFunction zT_421 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_422;
    unsigned int zT_423;
    unsigned int zT_424;
    unsigned char zT_428 = 0;
    zT_3E40CD83_Sand* zT_430;
    zT_338B7C76_TypeRegistry* zT_431;
    zT_BBC23664_LirFunction* zT_432;
    zT_A4CE86B7_U64ToU32Map* zT_433;
    zT_A4CE86B7_U64ToU32Map* zT_434;
    zT_A4CE86B7_U64ToU32Map* zT_435;
    zT_A4CE86B7_U64ToU32Map* zT_436;
    zT_A4CE86B7_U64ToU32Map* zT_437;
    zT_A4CE86B7_U64ToU32Map* zT_438;
    zT_B687BB96_U32ArrayList* zT_439;
    zT_A4CE86B7_U64ToU32Map* zT_440;
    zT_A4CE86B7_U64ToU32Map* zT_441;
    zT_69057089_CompilerAlloc* zT_442;
    zT_3F3BF87A_AsyncFrameLayout zT_455 = {0};
    zT_3E40CD83_Sand* zT_456;
    zT_A4CE86B7_U64ToU32Map* zT_457;
    unsigned int zT_458;
    unsigned int zT_459;
    zT_3F3BF87A_AsyncFrameLayout zT_460;
    zT_69057089_CompilerAlloc* zT_461;
    zT_3E40CD83_Sand* zT_467;
    zT_69057089_CompilerAlloc* zT_470;
    zT_FF4D4E6C_EU_242 zT_474 = {0};
    unsigned char zT_475;
    unsigned char* zT_476;
    zT_BBC23664_LirFunction* zT_479;
    zT_B687BB96_U32ArrayList* zT_480;
    unsigned char zT_485;
    zT_7E7544E4_LirStream* zT_487;
    zT_BBC23664_LirFunction zT_488;
    zT_E7714190_LirSlot zT_490 = {0};
    zT_CA01C129_LirSlotArrayList* zT_491;
    zT_E7714190_LirSlot zT_492;
    zT_3E40CD83_Sand* zT_495;
    zT_69057089_CompilerAlloc* zT_496;
    zT_8143F551_AstKind zT_498;
    unsigned char zT_502;
    zT_6B0A7D14_AstStore* zT_509;
    unsigned int zT_510;
    unsigned int zT_512 = 0;
    zT_3D7259E2_SymbolRegistry* zT_514;
    unsigned int zT_515;
    unsigned int zT_516;
    zT_6E8D187B_ModuleEntry* zT_518;
    zT_6E8D187B_ModuleEntry zT_519;
    zT_D0942820_Opt_894 zT_521 = {0};
    unsigned char zT_522;
    zT_3C598AEF_SymbolKind zT_524;
    unsigned char zT_529;
    unsigned char zT_530;
    unsigned char zT_536;
    unsigned int zT_537;
    zT_6B0A7D14_AstStore* zT_541;
    unsigned int zT_542;
    zT_22A7C88B_AstNode zT_545 = {0};
    zT_8143F551_AstKind zT_546;
    unsigned char zT_550;
    zT_8143F551_AstKind zT_551;
    unsigned char zT_555;
    zT_8143F551_AstKind zT_556;
    unsigned char zT_560;
    unsigned int zT_563;
    zT_6B0A7D14_AstStore* zT_567;
    unsigned int zT_568;
    zT_22A7C88B_AstNode zT_571 = {0};
    zT_8143F551_AstKind zT_572;
    unsigned char zT_576;
    zT_8143F551_AstKind zT_577;
    zT_6B0A7D14_AstStore* zT_582;
    unsigned int zT_583;
    zT_22A7C88B_AstNode zT_586 = {0};
    zT_8143F551_AstKind zT_587;
    unsigned char zT_591;
    unsigned char zT_594;
    zT_6E8D187B_ModuleEntry* zT_601;
    zT_6E8D187B_ModuleEntry zT_602;
    unsigned int zT_603;
    zT_79FAE712_u64 zT_612;
    zT_A4CE86B7_U64ToU32Map* zT_613;
    zT_79FAE712_u64 zT_614;
    unsigned char zT_619;
    unsigned int zT_620;
    zT_6B0A7D14_AstStore* zT_624;
    unsigned int zT_625;
    zT_22A7C88B_AstNode zT_628 = {0};
    zT_8143F551_AstKind zT_629;
    unsigned char zT_633;
    unsigned char zT_636;
    zT_8EED1867_ResolvedTypeTable* zT_638;
    unsigned int zT_639;
    zT_BAEE192E_Opt_10 zT_641 = {0};
    unsigned char zT_643;
    unsigned int zT_644;
    zT_E1A783EF_GlobalDeclArrayList* zT_647;
    zT_54906056_ModuleGlobalDecl zT_648;
    zT_54906056_ModuleGlobalDecl zT_650;
    zT_6E8D187B_ModuleEntry* zT_651;
    zT_6E8D187B_ModuleEntry zT_652;
    unsigned int zT_653;
    unsigned int zT_655;
    zT_6B356268_SemanticContext* zT_659;
    zT_3E40CD83_Sand* zT_660;
    zT_69057089_CompilerAlloc* zT_662;
    zT_02EB57B2_LirLowerer zT_664 = {0};
    zT_6E8D187B_ModuleEntry* zT_665;
    zT_6E8D187B_ModuleEntry zT_666;
    unsigned int zT_667;
    zT_072B53A6_ModuleRegistry* zT_668;
    zT_02EB57B2_LirLowerer* zT_670;
    unsigned int zT_671;
    unsigned int zT_672;
    zT_A4CE86B7_U64ToU32Map* zT_673;
    zT_6E8D187B_ModuleEntry* zT_675;
    zT_6E8D187B_ModuleEntry zT_676;
    zT_6E8D187B_ModuleEntry* zT_678;
    zT_6E8D187B_ModuleEntry zT_679;
    zT_BBC23664_LirFunction zT_682 = {0};
    zT_7E7544E4_LirStream* zT_684;
    zT_BBC23664_LirFunction zT_685;
    zT_E7714190_LirSlot zT_687 = {0};
    zT_CA01C129_LirSlotArrayList* zT_688;
    zT_E7714190_LirSlot zT_689;
    zT_3E40CD83_Sand* zT_692;
    zT_69057089_CompilerAlloc* zT_693;
    zT_072B53A6_ModuleRegistry* zT_696;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_698 = {0};
    unsigned int zT_700;
    unsigned char zT_703;
    zT_6E8D187B_ModuleEntry* zT_704;
    int zT_705;
    zT_6E8D187B_ModuleEntry zT_706;
    unsigned int zT_707;
    zT_6B0A7D14_AstStore* zT_711;
    unsigned int zT_712;
    zT_6E8D187B_ModuleEntry* zT_714;
    int zT_715;
    zT_6E8D187B_ModuleEntry zT_716;
    zT_22A7C88B_AstNode zT_718 = {0};
    zT_8143F551_AstKind zT_719;
    zT_6B0A7D14_AstStore* zT_724;
    unsigned int zT_725;
    zT_6E8D187B_ModuleEntry* zT_727;
    int zT_728;
    zT_6E8D187B_ModuleEntry zT_729;
    unsigned int zT_731 = 0;
    unsigned int zT_733;
    unsigned char* zT_735;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_736;
    unsigned int zT_737;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_738;
    zT_6B0A7D14_AstStore* zT_742;
    unsigned int zT_743;
    zT_6B0A7D14_AstStore* zT_745;
    unsigned int zT_746;
    zT_6E8D187B_ModuleEntry* zT_749;
    int zT_750;
    zT_6E8D187B_ModuleEntry zT_751;
    unsigned int zT_754 = 0;
    zT_22A7C88B_AstNode zT_755 = {0};
    zT_8143F551_AstKind zT_757;
    unsigned int zT_758;
    zT_4028D896_Arr_unsigned_char_2 zT_760;
    unsigned int zT_762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_763;
    int zT_766;
    unsigned char* zT_767;
    unsigned int zT_768;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    unsigned int zT_770 = 0;
    unsigned int zT_774;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_775;
    unsigned char* zT_779;
    unsigned int zT_780;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_781;
    unsigned char* zT_783;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_784;
    unsigned int zT_785;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_786;
    unsigned int zT_788;
    unsigned char* zT_790;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_791;
    unsigned int zT_792;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_793;
    int zT_794;
    unsigned int zT_796;
    unsigned int zT_798;
    unsigned int zT_799;
    unsigned int* zT_802;
    unsigned int zT_803;
    zT_BBC23664_LirFunction* zT_805;
    zT_A4CE86B7_U64ToU32Map* zT_806;
    unsigned int zT_807;
    unsigned int zT_808;
    zT_01CC10B6_Opt_412 zT_812 = {0};
    unsigned char zT_813;
    zT_5839647A_AsyncTransformCtx zT_816;
    zT_69057089_CompilerAlloc* zT_817;
    zT_3E40CD83_Sand* zT_818;
    zT_338B7C76_TypeRegistry* zT_819;
    zT_D3EB6303_StringInterner* zT_820;
    zT_7E7544E4_LirStream* zT_821;
    zT_CA01C129_LirSlotArrayList* zT_822;
    zT_A4CE86B7_U64ToU32Map* zT_823;
    zT_C98AF326_CompilerCli zT_824;
    unsigned char zT_825;
    zT_A4CE86B7_U64ToU32Map* zT_826;
    zT_A4CE86B7_U64ToU32Map* zT_827;
    zT_F85C5DED_DiagnosticCollector* zT_828;
    zT_BBC23664_LirFunction* zT_829;
    zT_5839647A_AsyncTransformCtx* zT_830;
    unsigned char zT_832 = 0;
    unsigned int zT_834;
    zT_3E40CD83_Sand* zT_835;
    zT_69057089_CompilerAlloc* zT_836;
    zT_5AB29387_CompilerContext* zT_838;
    zT_7E7544E4_LirStream* zT_839;
    unsigned char zT_841;
    unsigned char* zT_845;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_846;
    unsigned int zT_847;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_848;
    zT_D3EB6303_StringInterner* zT_849;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_850;
    zT_072B53A6_ModuleRegistry* zT_851;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_853 = {0};
    unsigned int zT_855 = 0;
    unsigned char* zT_859;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_860;
    unsigned int zT_861;
    unsigned char* zT_863;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_864;
    unsigned int zT_865;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_867;
    unsigned int zT_868;
    unsigned int zT_869;
    unsigned int zT_870;
    zT_D3EB6303_StringInterner* zT_872;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_873;
    int zT_876;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_877;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_879 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_880;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_886;
    unsigned int zT_895 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnmsg;
    zT_4028D896_Arr_unsigned_char_2 ln_buf;
    unsigned int ln_len;
    unsigned int ln_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lemsg;
    zT_4028D896_Arr_unsigned_char_2 le_buf;
    unsigned int le_len;
    unsigned int le_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnl;
    zT_846744CC_Arr_unsigned_char_5 spill_path;
    unsigned int sp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmp_name;
    unsigned int ti;
    zT_6B356268_SemanticContext sem_ctx;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_B687BB96_U32ArrayList async_retained;
    unsigned char async_pending;
    unsigned int mi;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm;
    zT_4028D896_Arr_unsigned_char_2 mi_buf;
    unsigned int mi_len;
    unsigned int mi2_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u msep;
    unsigned int arl_i;
    zT_4028D896_Arr_unsigned_char_2 ar_buf;
    unsigned int ar_len;
    unsigned int ar_start;
    zT_22A7C88B_AstNode root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr;
    unsigned int decls_n;
    unsigned int decl_len;
    zT_4028D896_Arr_unsigned_char_2 dcount_buf;
    unsigned int dcount_len;
    unsigned int dstart;
    unsigned char mod_has_ri;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int raw_k;
    zT_4028D896_Arr_unsigned_char_2 rbuf;
    unsigned int rlen;
    unsigned int rstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp2;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf;
    zT_243D6A41_FnProto fexp_proto;
    zT_79FAE712_u64 fexp_key;
    zT_02EB57B2_LirLowerer lowerer;
    zT_BBC23664_LirFunction lf;
    zT_3F3BF87A_AsyncFrameLayout async_layout;
    unsigned char* lf_raw;
    zT_E7714190_LirSlot slot;
    zT_BBC23664_LirFunction* lf_ptr;
    unsigned int gv_name;
    zT_D0942820_Opt_894 gv_sym;
    zT_3A105EF1_Symbol* gvs;
    unsigned char gv_is_storage;
    zT_22A7C88B_AstNode gv_init;
    zT_22A7C88B_AstNode gv_init3;
    zT_22A7C88B_AstNode gv_fb;
    zT_79FAE712_u64 gexp_key;
    unsigned char gv_has_ri;
    zT_22A7C88B_AstNode gv_init2;
    zT_BAEE192E_Opt_10 gv_rt;
    unsigned int gv_tid;
    unsigned int grt;
    zT_02EB57B2_LirLowerer ilowerer;
    zT_BBC23664_LirFunction imf;
    zT_E7714190_LirSlot islot;
    zT_DDCD424B_Slice_zT_6E8D187B_M amods;
    zT_22A7C88B_AstNode ar;
    unsigned int adl_n;
    unsigned int adi;
    zT_8F083A69_Slice_zT_0B42B2F8_u al;
    zT_22A7C88B_AstNode ad;
    unsigned int ak;
    zT_4028D896_Arr_unsigned_char_2 ab;
    unsigned int alen;
    unsigned int ast;
    zT_8F083A69_Slice_zT_0B42B2F8_u asp;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_BBC23664_LirFunction* lf2;
    zT_3F3BF87A_AsyncFrameLayout* lay2;
    zT_5839647A_AsyncTransformCtx async_ctx2;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = "L\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = "nodes=";
    zT_9 = 6;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    lnmsg = zT_8;
    zT_10 = lnmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ln_buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_16 = ctx->store;
    zT_17 = zT_16->nodes;
    zT_18 = zT_17.len;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)ln_buf) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = zT_23;
    zT_25.len = zT_24;
    zT_15 = zT_25;
    zT_26 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_18), zT_15);
    ln_len = zT_26;
    zT_30 = (unsigned int)(19) - (unsigned int)((unsigned int)ln_len);
    ln_start = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)ln_buf) + ln_start;
    zT_36 = (unsigned int)(19) - ln_start;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = " extra=";
    zT_41 = 7;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    lemsg = zT_40;
    zT_42 = lemsg;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        le_buf[_i] = zT_44[_i];
        _i++;
    }
}
    zT_48 = ctx->store;
    zT_49 = zT_48->extra_children;
    zT_50 = zT_49.len;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)le_buf) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_47 = zT_57;
    zT_58 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_50), zT_47);
    le_len = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)le_len);
    le_start = zT_62;
    zT_67 = (unsigned char*)((unsigned char*)le_buf) + le_start;
    zT_68 = (unsigned int)(19) - le_start;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zF_48AC7B3A_markerWrite(zT_63);
    zT_71 = "\n";
    zT_73 = 1;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    lnl = zT_72;
    zT_74 = lnl;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_76 = ctx->alloc;
    zT_75 = &zT_76->scratch;
    zF_F1B3F8C2_sandReset(zT_75);
    zT_79 = &ctx->lir_slots;
    zT_79->len = (unsigned int)(0);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_81[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        spill_path[_i] = zT_81[_i];
        _i++;
    }
}
    zT_83 = 0;
    sp_len = zT_83;
    zT_84 = ctx->cli;
    zT_85 = zT_84.output_dir_set;
    if (zT_85) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_87 = ctx->cli;
    zT_88 = zT_87.output_dir;
    od = zT_88;
    zT_90 = 0;
    oi = zT_90;
    goto z_bb_4;
    z_bb_2:
    zT_113 = ".zig1_lir.tmp";
    zT_115 = 13;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    tmp_name = zT_114;
    zT_117 = 0;
    ti = zT_117;
    goto z_bb_11;
    z_bb_3:
    zT_106 = 46;
    spill_path[sp_len] = zT_106;
    zT_108 = sp_len + (unsigned int)(1);
    sp_len = zT_108;
    zT_109 = 47;
    spill_path[sp_len] = zT_109;
    zT_111 = sp_len + (unsigned int)(1);
    sp_len = zT_111;
    goto z_bb_2;
    z_bb_4:
    zT_92 = od.len;
    if ((unsigned char)(oi < zT_92)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_97 = od.ptr;
    zT_98 = zT_97[oi];
    spill_path[sp_len] = zT_98;
    zT_100 = sp_len + (unsigned int)(1);
    sp_len = zT_100;
    goto z_bb_7;
    z_bb_6:
    zT_103 = 47;
    spill_path[sp_len] = zT_103;
    zT_105 = sp_len + (unsigned int)(1);
    sp_len = zT_105;
    goto z_bb_2;
    z_bb_7:
    zT_102 = oi + (unsigned int)(1);
    oi = zT_102;
    goto z_bb_4;
    z_bb_8:
    zT_94 = sp_len < (unsigned int)(511);
    goto z_bb_10;
    z_bb_9:
    zT_94 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_94) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    zT_119 = tmp_name.len;
    if ((unsigned char)(ti < zT_119)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_124 = tmp_name.ptr;
    zT_125 = zT_124[ti];
    spill_path[sp_len] = zT_125;
    zT_127 = sp_len + (unsigned int)(1);
    sp_len = zT_127;
    goto z_bb_14;
    z_bb_13:
    zT_130 = &ctx->lir_stream;
    zT_136 = 0;
    zT_137 = (unsigned char*)((unsigned char*)spill_path) + zT_136;
    zT_138 = sp_len - zT_136;
    zT_139.ptr = zT_137;
    zT_139.len = zT_138;
    zT_131 = zT_139;
    zT_140 = ctx->alloc;
    zT_132 = &zT_140->emission;
    zF_B0B74E20_lirStreamBeginWrite(zT_130, zT_131, zT_132);
    zT_144 = ctx->store;
    zT_143.store = zT_144;
    zT_145 = ctx->typereg;
    zT_143.registry = zT_145;
    zT_146 = ctx->symbol_reg;
    zT_143.symbol_tables = zT_146;
    zT_147 = ctx->resolved_types;
    zT_143.resolved_types = zT_147;
    zT_148 = ctx->coercion_table;
    zT_143.coercions = zT_148;
    zT_149 = ctx->diag;
    zT_143.diag = zT_149;
    zT_150 = 1;
    zT_143.has_symbols = zT_150;
    zT_151 = &ctx->enum_value_table;
    zT_143.enum_value_table = zT_151;
    zT_152 = &ctx->tuple_index_table;
    zT_143.tuple_index_table = zT_152;
    zT_153 = &ctx->error_code_registry;
    zT_143.error_code_registry = zT_153;
    zT_154 = &ctx->call_arg_types;
    zT_143.call_arg_types = zT_154;
    zT_155 = &ctx->comptime_folds;
    zT_143.comptime_folds = zT_155;
    zT_156 = 0;
    zT_143.source_file_id = zT_156;
    zT_157 = ctx->cli;
    zT_158 = zT_157.safe_checks;
    zT_143.safe_checks = zT_158;
    zT_159 = &ctx->suspending_fns;
    zT_143.suspending_fns = zT_159;
    zT_160 = &ctx->frame_sizes;
    zT_143.frame_sizes = zT_160;
    zT_161 = &ctx->state_widths;
    zT_143.state_widths = zT_161;
    zT_162 = 0;
    zT_143.print_value_lowered = zT_162;
    sem_ctx = zT_143;
    zT_164 = ctx->module_reg;
    zT_166 = zF_3452C137_moduleRegistryGetMo(zT_164);
    mods = zT_166;
    zT_169 = ctx->alloc;
    zT_168 = &zT_169->module;
    zT_171 = zF_8E537D0C_u32ArrayListInit(zT_168);
    async_retained = zT_171;
    zT_173 = 0;
    async_pending = zT_173;
    zT_175 = 0;
    zT_176 = (unsigned int)zT_175;
    mi = zT_176;
    goto z_bb_18;
    z_bb_14:
    zT_129 = ti + (unsigned int)(1);
    ti = zT_129;
    goto z_bb_11;
    z_bb_15:
    zT_121 = sp_len < (unsigned int)(511);
    goto z_bb_17;
    z_bb_16:
    zT_121 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_121) goto z_bb_12; else goto z_bb_13;
    z_bb_18:
    zT_178 = mods.len;
    if ((unsigned char)(mi < zT_178)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_180 = mods.ptr;
    zT_181 = zT_180[mi];
    zT_182 = zT_181.source_file_id;
    sem_ctx.source_file_id = zT_182;
    zT_184 = "M";
    zT_186 = 1;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    mm = zT_185;
    zT_187 = mm;
    zF_48AC7B3A_markerWrite(zT_187);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_189[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        mi_buf[_i] = zT_189[_i];
        _i++;
    }
}
    zT_196 = 0;
    zT_197 = (unsigned char*)((unsigned char*)mi_buf) + zT_196;
    zT_198 = (unsigned int)(20) - zT_196;
    zT_199.ptr = zT_197;
    zT_199.len = zT_198;
    zT_192 = zT_199;
    zT_200 = zF_A7504564_itoa((unsigned int)((unsigned int)mi), zT_192);
    mi_len = zT_200;
    zT_204 = (unsigned int)(19) - (unsigned int)((unsigned int)mi_len);
    mi2_start = zT_204;
    zT_209 = (unsigned char*)((unsigned char*)mi_buf) + mi2_start;
    zT_210 = (unsigned int)(19) - mi2_start;
    zT_211.ptr = zT_209;
    zT_211.len = zT_210;
    zT_205 = zT_211;
    zF_48AC7B3A_markerWrite(zT_205);
    zT_213 = ":";
    zT_215 = 1;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    msep = zT_214;
    zT_216 = msep;
    zF_48AC7B3A_markerWrite(zT_216);
    zT_217 = mods.ptr;
    zT_218 = zT_217[mi];
    zT_219 = zT_218.ast_root;
    if ((unsigned char)(zT_219 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_798 = 0;
    arl_i = zT_798;
    goto z_bb_102;
    z_bb_21:
    zT_794 = 1;
    zT_796 = mi + (unsigned int)((unsigned int)zT_794);
    mi = zT_796;
    goto z_bb_18;
    z_bb_22:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_223[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ar_buf[_i] = zT_223[_i];
        _i++;
    }
}
    zT_227 = mods.ptr;
    zT_228 = zT_227[mi];
    zT_225 = zT_228.ast_root;
    zT_232 = 0;
    zT_233 = (unsigned char*)((unsigned char*)ar_buf) + zT_232;
    zT_234 = (unsigned int)(20) - zT_232;
    zT_235.ptr = zT_233;
    zT_235.len = zT_234;
    zT_226 = zT_235;
    zT_236 = zF_A7504564_itoa(zT_225, zT_226);
    ar_len = zT_236;
    zT_240 = (unsigned int)(19) - (unsigned int)((unsigned int)ar_len);
    ar_start = zT_240;
    zT_245 = (unsigned char*)((unsigned char*)ar_buf) + ar_start;
    zT_246 = (unsigned int)(19) - ar_start;
    zT_247.ptr = zT_245;
    zT_247.len = zT_246;
    zT_241 = zT_247;
    zF_48AC7B3A_markerWrite(zT_241);
    zT_248 = msep;
    zF_48AC7B3A_markerWrite(zT_248);
    zT_250 = ctx->store;
    zT_253 = mods.ptr;
    zT_254 = zT_253[mi];
    zT_251 = zT_254.ast_root;
    zT_256 = zF_FCDD1D35_astStoreNodeAt(zT_250, zT_251);
    root = zT_256;
    zT_257 = root.kind;
    if ((unsigned char)(zT_257 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_262 = "R";
    zT_264 = 1;
    zT_263.ptr = zT_262;
    zT_263.len = zT_264;
    mr = zT_263;
    zT_265 = mr;
    zF_48AC7B3A_markerWrite(zT_265);
    zT_267 = ctx->store;
    zT_270 = mods.ptr;
    zT_271 = zT_270[mi];
    zT_268 = zT_271.ast_root;
    zT_273 = zF_152E19CB_astStoreNodeExtraCh(zT_267, zT_268);
    decls_n = zT_273;
    zT_275 = (unsigned int)decls_n;
    decl_len = zT_275;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_277[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dcount_buf[_i] = zT_277[_i];
        _i++;
    }
}
    zT_279 = decl_len;
    zT_283 = 0;
    zT_284 = (unsigned char*)((unsigned char*)dcount_buf) + zT_283;
    zT_285 = (unsigned int)(20) - zT_283;
    zT_286.ptr = zT_284;
    zT_286.len = zT_285;
    zT_280 = zT_286;
    zT_287 = zF_A7504564_itoa(zT_279, zT_280);
    dcount_len = zT_287;
    zT_291 = (unsigned int)(19) - (unsigned int)((unsigned int)dcount_len);
    dstart = zT_291;
    zT_296 = (unsigned char*)((unsigned char*)dcount_buf) + dstart;
    zT_297 = (unsigned int)(19) - dstart;
    zT_298.ptr = zT_296;
    zT_298.len = zT_297;
    zT_292 = zT_298;
    zF_48AC7B3A_markerWrite(zT_292);
    zT_299 = msep;
    zF_48AC7B3A_markerWrite(zT_299);
    zT_300 = ctx->store;
    zT_304 = mods.ptr;
    zT_305 = zT_304[mi];
    zT_301 = zT_305.ast_root;
    zT_307 = mods.ptr;
    zT_308 = zT_307 + mi;
    zT_302 = &zT_308->c_includes;
    zF_7D71E4ED_moduleRegistryColle(zT_300, zT_301, zT_302);
    zT_311 = 0;
    mod_has_ri = zT_311;
    zT_313 = 0;
    di = zT_313;
    goto z_bb_26;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_317 = ctx->store;
    zT_321 = mods.ptr;
    zT_322 = zT_321[mi];
    zT_318 = zT_322.ast_root;
    zT_325 = zF_B10B1BC1_astStoreNodeExtraCh(zT_317, zT_318, (unsigned int)((unsigned int)di));
    decl_idx = zT_325;
    zT_327 = ctx->store;
    zT_328 = decl_idx;
    zT_330 = zF_FCDD1D35_astStoreNodeAt(zT_327, zT_328);
    decl = zT_330;
    zT_332 = decl.kind;
    zT_333 = (unsigned int)zT_332;
    raw_k = zT_333;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_335[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rbuf[_i] = zT_335[_i];
        _i++;
    }
}
    zT_337 = raw_k;
    zT_341 = 0;
    zT_342 = (unsigned char*)((unsigned char*)rbuf) + zT_341;
    zT_343 = (unsigned int)(20) - zT_341;
    zT_344.ptr = zT_342;
    zT_344.len = zT_343;
    zT_338 = zT_344;
    zT_345 = zF_A7504564_itoa(zT_337, zT_338);
    rlen = zT_345;
    zT_349 = (unsigned int)(19) - (unsigned int)((unsigned int)rlen);
    rstart = zT_349;
    zT_354 = (unsigned char*)((unsigned char*)rbuf) + rstart;
    zT_355 = (unsigned int)(19) - rstart;
    zT_356.ptr = zT_354;
    zT_356.len = zT_355;
    zT_350 = zT_356;
    zF_48AC7B3A_markerWrite(zT_350);
    zT_358 = " ";
    zT_360 = 1;
    zT_359.ptr = zT_358;
    zT_359.len = zT_360;
    sp2 = zT_359;
    zT_361 = sp2;
    zF_48AC7B3A_markerWrite(zT_361);
    zT_362 = decl.kind;
    if ((unsigned char)(zT_362 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_30; else goto z_bb_32;
    z_bb_28:
    if ((unsigned char)(mod_has_ri != (unsigned char)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_29:
    zT_655 = di + (unsigned int)(1);
    di = zT_655;
    goto z_bb_26;
    z_bb_30:
    zT_367 = "F";
    zT_369 = 1;
    zT_368.ptr = zT_367;
    zT_368.len = zT_369;
    mf = zT_368;
    zT_370 = mf;
    zF_48AC7B3A_markerWrite(zT_370);
    zT_371 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_371) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_498 = decl.kind;
    if ((unsigned char)(zT_498 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_43; else goto z_bb_44;
    z_bb_33:
    zT_378 = ctx->store;
    zT_379 = zT_378->fn_protos;
    zT_380 = zT_379.items;
    zT_381 = ctx->store;
    zT_382 = decl_idx;
    zT_384 = zF_8BA26B9E_astStoreNodePayload(zT_381, zT_382);
    zT_385 = (unsigned int)zT_384;
    zT_386 = zT_380[zT_385];
    fexp_proto = zT_386;
    zT_388 = mods.ptr;
    zT_389 = zT_388[mi];
    zT_390 = zT_389.id;
    zT_398 = fexp_proto.name_id;
    zT_400 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_390) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(0)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_398);
    fexp_key = zT_400;
    zT_401 = &ctx->exported;
    zT_402 = fexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_401, zT_402, (unsigned int)(1));
    goto z_bb_34;
    z_bb_34:
    zT_407 = &sem_ctx;
    zT_410 = ctx->alloc;
    zT_408 = &zT_410->scratch;
    zT_412 = zF_ADD4254B_lowererInit(zT_407, zT_408);
    lowerer = zT_412;
    zT_413 = mods.ptr;
    zT_414 = zT_413[mi];
    zT_415 = zT_414.id;
    lowerer.module_id = zT_415;
    zT_416 = ctx->module_reg;
    lowerer.module_reg = zT_416;
    zT_418 = &lowerer;
    zT_419 = decl_idx;
    zT_421 = zF_B53F5F2E_lowerFn(zT_418, zT_419);
    lf = zT_421;
    zT_422 = &ctx->suspending_fns;
    zT_423 = lf.module_id;
    zT_424 = lf.name_id;
    zT_428 = zF_7C7E43BF_asyncIsSuspending(zT_422, zT_423, zT_424);
    if (zT_428) goto z_bb_35; else goto z_bb_37;
    z_bb_35:
    zT_442 = ctx->alloc;
    zT_430 = &zT_442->scratch;
    zT_431 = ctx->typereg;
    zT_432 = &lf;
    zT_433 = &ctx->suspending_fns;
    zT_434 = &ctx->frame_sizes;
    zT_435 = &ctx->state_widths;
    zT_436 = &ctx->awaited_fns;
    zT_437 = &ctx->async_hidden_fns;
    zT_438 = &ctx->driver_targets;
    zT_439 = &ctx->parent_result_type_list;
    zT_440 = &ctx->parent_result_start;
    zT_441 = &ctx->parent_result_count;
    zT_455 = zF_28031796_asyncLayoutFrame(zT_430, zT_431, zT_432, zT_433, zT_434, zT_435, zT_436, zT_437, zT_438, zT_439, zT_440, zT_441);
    async_layout = zT_455;
    zT_461 = ctx->alloc;
    zT_456 = &zT_461->scratch;
    zT_457 = &ctx->async_layouts;
    zT_458 = lf.module_id;
    zT_459 = lf.name_id;
    zT_460 = async_layout;
    zF_17324878_asyncLayoutPublish(zT_456, zT_457, zT_458, zT_459, zT_460);
    zT_470 = ctx->alloc;
    zT_467 = &zT_470->scratch;
    zT_474 = zF_1395EB68_sandAlloc(zT_467, (unsigned int)(124), (unsigned int)(4));
    zT_475 = zT_474.is_error;
    if (zT_475) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_487 = &ctx->lir_stream;
    zT_488 = lf;
    zT_490 = zF_9F47D5E4_lirStreamAppend(zT_487, zT_488);
    slot = zT_490;
    zT_491 = &ctx->lir_slots;
    zT_492 = slot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_491, zT_492);
    if ((unsigned char)(!async_pending)) goto z_bb_41; else goto z_bb_42;
    z_bb_38:
    pal_trap();
    z_bb_39:
    zT_476 = zT_474.data.payload;
    goto z_bb_40;
    z_bb_40:
    lf_raw = zT_476;
    zT_479 = (zT_BBC23664_LirFunction*)lf_raw;
    lf_ptr = zT_479;
    *lf_ptr = lf;
    zT_480 = &async_retained;
    zF_62F717A2_u32ArrayListAppend(zT_480, (unsigned int)((unsigned int)(unsigned int)((unsigned int)lf_ptr)));
    zT_485 = 1;
    async_pending = zT_485;
    goto z_bb_36;
    z_bb_41:
    zT_496 = ctx->alloc;
    zT_495 = &zT_496->scratch;
    zF_F1B3F8C2_sandReset(zT_495);
    goto z_bb_42;
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_502 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_502) & (unsigned short)(4)) == (unsigned short)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_31;
    z_bb_45:
    zT_509 = ctx->store;
    zT_510 = decl_idx;
    zT_512 = zF_8BA26B9E_astStoreNodePayload(zT_509, zT_510);
    gv_name = zT_512;
    zT_514 = ctx->symbol_reg;
    zT_518 = mods.ptr;
    zT_519 = zT_518[mi];
    zT_515 = zT_519.id;
    zT_516 = gv_name;
    zT_521 = zF_A398987E_symbolRegistryQuali(zT_514, zT_515, zT_516);
    gv_sym = zT_521;
    zT_522 = gv_sym.has_value;
    if (zT_522) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_44;
    z_bb_47:
    gvs = gv_sym.value;
    zT_524 = gvs->kind;
    if ((unsigned char)(zT_524 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    zT_529 = 0;
    gv_is_storage = zT_529;
    zT_530 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_530) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_51; else goto z_bb_53;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_536 = 1;
    gv_is_storage = zT_536;
    goto z_bb_52;
    z_bb_52:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_64; else goto z_bb_65;
    z_bb_53:
    zT_537 = decl.child_1;
    if ((unsigned char)(zT_537 != (unsigned int)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_541 = ctx->store;
    zT_542 = decl.child_1;
    zT_545 = zF_FCDD1D35_astStoreNodeAt(zT_541, zT_542);
    gv_init = zT_545;
    zT_546 = gv_init.kind;
    if ((unsigned char)(zT_546 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_551 = gv_init.kind;
    zT_550 = zT_551 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal);
    goto z_bb_58;
    z_bb_57:
    zT_550 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_550) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_556 = gv_init.kind;
    zT_555 = zT_556 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_61;
    z_bb_60:
    zT_555 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_555) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_560 = 1;
    gv_is_storage = zT_560;
    goto z_bb_63;
    z_bb_63:
    goto z_bb_55;
    z_bb_64:
    zT_563 = decl.child_1;
    if ((unsigned char)(zT_563 != (unsigned int)(0))) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_74; else goto z_bb_75;
    z_bb_66:
    zT_567 = ctx->store;
    zT_568 = decl.child_1;
    zT_571 = zF_FCDD1D35_astStoreNodeAt(zT_567, zT_568);
    gv_init3 = zT_571;
    zT_572 = gv_init3.kind;
    if ((unsigned char)(zT_572 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_576 = 0;
    gv_is_storage = zT_576;
    goto z_bb_69;
    z_bb_69:
    zT_577 = gv_init3.kind;
    if ((unsigned char)(zT_577 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_582 = ctx->store;
    zT_583 = gv_init3.child_0;
    zT_586 = zF_FCDD1D35_astStoreNodeAt(zT_582, zT_583);
    gv_fb = zT_586;
    zT_587 = gv_fb.kind;
    if ((unsigned char)(zT_587 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    goto z_bb_67;
    z_bb_72:
    zT_591 = 0;
    gv_is_storage = zT_591;
    goto z_bb_73;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    zT_594 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_594) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    goto z_bb_50;
    z_bb_76:
    zT_601 = mods.ptr;
    zT_602 = zT_601[mi];
    zT_603 = zT_602.id;
    zT_612 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_603) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(4294967296ULL)) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_612;
    zT_613 = &ctx->exported;
    zT_614 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_613, zT_614, (unsigned int)(1));
    goto z_bb_77;
    z_bb_77:
    zT_619 = 0;
    gv_has_ri = zT_619;
    zT_620 = decl.child_1;
    if ((unsigned char)(zT_620 != (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_624 = ctx->store;
    zT_625 = decl.child_1;
    zT_628 = zF_FCDD1D35_astStoreNodeAt(zT_624, zT_625);
    gv_init2 = zT_628;
    zT_629 = gv_init2.kind;
    if ((unsigned char)(zT_629 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    if ((unsigned char)(gv_has_ri == (unsigned char)(1))) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    zT_633 = 1;
    gv_has_ri = zT_633;
    goto z_bb_81;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_636 = 1;
    mod_has_ri = zT_636;
    goto z_bb_83;
    z_bb_83:
    zT_638 = ctx->resolved_types;
    zT_639 = decl_idx;
    zT_641 = zF_999DCF51_resolvedTypeTableGe(zT_638, zT_639);
    gv_rt = zT_641;
    zT_643 = gv_rt.has_value;
    if (zT_643) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    grt = gv_rt.value;
    zT_644 = grt;
    goto z_bb_86;
    z_bb_85:
    zT_644 = 18;
    goto z_bb_86;
    z_bb_86:
    gv_tid = zT_644;
    zT_647 = &ctx->global_decls;
    zT_650.name_id = gv_name;
    zT_651 = mods.ptr;
    zT_652 = zT_651[mi];
    zT_653 = zT_652.id;
    zT_650.module_id = zT_653;
    zT_650.type_id = gv_tid;
    zT_650.has_runtime_init = gv_has_ri;
    zT_648 = zT_650;
    zF_F2C82CE7_globalDeclArrayList(zT_647, zT_648);
    goto z_bb_75;
    z_bb_87:
    zT_659 = &sem_ctx;
    zT_662 = ctx->alloc;
    zT_660 = &zT_662->scratch;
    zT_664 = zF_ADD4254B_lowererInit(zT_659, zT_660);
    ilowerer = zT_664;
    zT_665 = mods.ptr;
    zT_666 = zT_665[mi];
    zT_667 = zT_666.id;
    ilowerer.module_id = zT_667;
    zT_668 = ctx->module_reg;
    ilowerer.module_reg = zT_668;
    zT_670 = &ilowerer;
    zT_675 = mods.ptr;
    zT_676 = zT_675[mi];
    zT_671 = zT_676.ast_root;
    zT_678 = mods.ptr;
    zT_679 = zT_678[mi];
    zT_672 = zT_679.id;
    zT_673 = &ctx->module_init_deps;
    zT_682 = zF_552B231C_lowerModuleInit(zT_670, zT_671, zT_672, zT_673);
    imf = zT_682;
    zT_684 = &ctx->lir_stream;
    zT_685 = imf;
    zT_687 = zF_9F47D5E4_lirStreamAppend(zT_684, zT_685);
    islot = zT_687;
    zT_688 = &ctx->lir_slots;
    zT_689 = islot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_688, zT_689);
    if ((unsigned char)(!async_pending)) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_696 = ctx->module_reg;
    zT_698 = zF_3452C137_moduleRegistryGetMo(zT_696);
    amods = zT_698;
    zT_700 = amods.len;
    if ((unsigned char)(zT_700 > (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_89:
    zT_693 = ctx->alloc;
    zT_692 = &zT_693->scratch;
    zF_F1B3F8C2_sandReset(zT_692);
    goto z_bb_90;
    z_bb_90:
    goto z_bb_88;
    z_bb_91:
    zT_704 = amods.ptr;
    zT_705 = 0;
    zT_706 = zT_704[zT_705];
    zT_707 = zT_706.ast_root;
    zT_703 = zT_707 != (unsigned int)(0);
    goto z_bb_93;
    z_bb_92:
    zT_703 = 0;
    goto z_bb_93;
    z_bb_93:
    if (zT_703) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_711 = ctx->store;
    zT_714 = amods.ptr;
    zT_715 = 0;
    zT_716 = zT_714[zT_715];
    zT_712 = zT_716.ast_root;
    zT_718 = zF_FCDD1D35_astStoreNodeAt(zT_711, zT_712);
    ar = zT_718;
    zT_719 = ar.kind;
    if ((unsigned char)(zT_719 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_96; else goto z_bb_97;
    z_bb_95:
    goto z_bb_25;
    z_bb_96:
    zT_724 = ctx->store;
    zT_727 = amods.ptr;
    zT_728 = 0;
    zT_729 = zT_727[zT_728];
    zT_725 = zT_729.ast_root;
    zT_731 = zF_152E19CB_astStoreNodeExtraCh(zT_724, zT_725);
    adl_n = zT_731;
    zT_733 = 0;
    adi = zT_733;
    zT_735 = "A0";
    zT_737 = 2;
    zT_736.ptr = zT_735;
    zT_736.len = zT_737;
    al = zT_736;
    zT_738 = al;
    zF_48AC7B3A_markerWrite(zT_738);
    goto z_bb_98;
    z_bb_97:
    goto z_bb_95;
    z_bb_98:
    if ((unsigned char)(adi < (unsigned int)((unsigned int)adl_n))) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_742 = ctx->store;
    zT_745 = ctx->store;
    zT_749 = amods.ptr;
    zT_750 = 0;
    zT_751 = zT_749[zT_750];
    zT_746 = zT_751.ast_root;
    zT_754 = zF_B10B1BC1_astStoreNodeExtraCh(zT_745, zT_746, (unsigned int)((unsigned int)adi));
    zT_743 = zT_754;
    zT_755 = zF_FCDD1D35_astStoreNodeAt(zT_742, zT_743);
    ad = zT_755;
    zT_757 = ad.kind;
    zT_758 = (unsigned int)zT_757;
    ak = zT_758;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_760[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ab[_i] = zT_760[_i];
        _i++;
    }
}
    zT_762 = ak;
    zT_766 = 0;
    zT_767 = (unsigned char*)((unsigned char*)ab) + zT_766;
    zT_768 = (unsigned int)(20) - zT_766;
    zT_769.ptr = zT_767;
    zT_769.len = zT_768;
    zT_763 = zT_769;
    zT_770 = zF_A7504564_itoa(zT_762, zT_763);
    alen = zT_770;
    zT_774 = (unsigned int)(19) - (unsigned int)((unsigned int)alen);
    ast = zT_774;
    zT_779 = (unsigned char*)((unsigned char*)ab) + ast;
    zT_780 = (unsigned int)(19) - ast;
    zT_781.ptr = zT_779;
    zT_781.len = zT_780;
    zT_775 = zT_781;
    zF_48AC7B3A_markerWrite(zT_775);
    zT_783 = " ";
    zT_785 = 1;
    zT_784.ptr = zT_783;
    zT_784.len = zT_785;
    asp = zT_784;
    zT_786 = asp;
    zF_48AC7B3A_markerWrite(zT_786);
    goto z_bb_101;
    z_bb_100:
    zT_790 = "\n";
    zT_792 = 1;
    zT_791.ptr = zT_790;
    zT_791.len = zT_792;
    an = zT_791;
    zT_793 = an;
    zF_48AC7B3A_markerWrite(zT_793);
    goto z_bb_97;
    z_bb_101:
    zT_788 = adi + (unsigned int)(1);
    adi = zT_788;
    goto z_bb_98;
    z_bb_102:
    zT_799 = async_retained.len;
    if ((unsigned char)(arl_i < zT_799)) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_802 = async_retained.items;
    zT_803 = zT_802[arl_i];
    zT_805 = (zT_BBC23664_LirFunction*)(unsigned int)(unsigned int)((unsigned int)zT_803);
    lf2 = zT_805;
    zT_806 = &ctx->async_layouts;
    zT_807 = lf2->module_id;
    zT_808 = lf2->name_id;
    zT_812 = zF_A1F56FFB_asyncLayoutLookup(zT_806, zT_807, zT_808);
    zT_813 = zT_812.has_value;
    if (zT_813) goto z_bb_106; else goto z_bb_107;
    z_bb_104:
    if (async_pending) goto z_bb_108; else goto z_bb_109;
    z_bb_105:
    zT_834 = arl_i + (unsigned int)(1);
    arl_i = zT_834;
    goto z_bb_102;
    z_bb_106:
    lay2 = zT_812.value;
    zT_817 = ctx->alloc;
    zT_818 = &zT_817->scratch;
    zT_816.alloc = zT_818;
    zT_819 = ctx->typereg;
    zT_816.registry = zT_819;
    zT_820 = ctx->interner;
    zT_816.interner = zT_820;
    zT_821 = &ctx->lir_stream;
    zT_816.lir_stream = zT_821;
    zT_822 = &ctx->lir_slots;
    zT_816.lir_slots = zT_822;
    zT_823 = &ctx->suspending_fns;
    zT_816.suspending_fns = zT_823;
    zT_816.layout = lay2;
    zT_824 = ctx->cli;
    zT_825 = zT_824.safe_checks;
    zT_816.safe_checks = zT_825;
    zT_826 = &ctx->frame_sizes;
    zT_816.frame_sizes = zT_826;
    zT_827 = &ctx->async_layouts;
    zT_816.async_layouts = zT_827;
    zT_828 = ctx->diag;
    zT_816.diag = zT_828;
    async_ctx2 = zT_816;
    zT_829 = lf2;
    zT_830 = &async_ctx2;
    zT_832 = zF_7C1ED6D1_asyncTransform(zT_829, zT_830);
    (void)zT_832;
    goto z_bb_107;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    zT_836 = ctx->alloc;
    zT_835 = &zT_836->scratch;
    zF_F1B3F8C2_sandReset(zT_835);
    goto z_bb_109;
    z_bb_109:
    zT_838 = ctx;
    zF_B69A3794_computeModuleInitOr(zT_838);
    zT_839 = &ctx->lir_stream;
    zF_256E5B86_lirStreamFinishWrit(zT_839);
    zT_841 = sem_ctx.print_value_lowered;
    if ((unsigned char)(zT_841 != (unsigned char)(0))) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_845 = "std_fmt.zig";
    zT_847 = 11;
    zT_846.ptr = zT_845;
    zT_846.len = zT_847;
    c89_fmt_base = zT_846;
    zT_851 = ctx->module_reg;
    zT_853 = zF_3452C137_moduleRegistryGetMo(zT_851);
    zT_848 = zT_853;
    zT_849 = ctx->interner;
    zT_850 = c89_fmt_base;
    zT_855 = zF_D27A4A01_moduleIdForBasename(zT_848, zT_849, zT_850);
    if ((unsigned char)(zT_855 == (unsigned int)(4294967295u))) goto z_bb_112; else goto z_bb_113;
    z_bb_111:
    return;
    z_bb_112:
    zT_859 = "could not resolve imported file '";
    zT_861 = 33;
    zT_860.ptr = zT_859;
    zT_860.len = zT_861;
    p1 = zT_860;
    zT_863 = "'";
    zT_865 = 1;
    zT_864.ptr = zT_863;
    zT_864.len = zT_865;
    p2 = zT_864;
    zT_868 = 0;
    zT_867[zT_868] = p1;
    zT_869 = 1;
    zT_867[zT_869] = c89_fmt_base;
    zT_870 = 2;
    zT_867[zT_870] = p2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        parts[_i] = zT_867[_i];
        _i++;
    }
}
    zT_872 = ctx->interner;
    zT_876 = 0;
    zT_877 = parts + zT_876;
    zT_873 = zT_877;
    zT_879 = zF_8C4BFF7C_diagnosticBuilderMa(zT_872, zT_873, (unsigned int)(3));
    msg = zT_879;
    zT_880 = ctx->diag;
    zT_886 = msg;
    zT_895 = zF_C82559AC_diagnosticCollector(zT_880, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3048_CANNOT_READ_FILE)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_886);
    (void)zT_895;
    goto z_bb_113;
    z_bb_113:
    goto z_bb_111;
}

/* computeModuleInitOrder */
void zF_B69A3794_computeModuleInitOr(zT_5AB29387_CompilerContext* ctx) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_4 = {0};
    unsigned int zT_7;
    zT_B687BB96_U32ArrayList* zT_9;
    zT_3E40CD83_Sand* zT_11;
    zT_69057089_CompilerAlloc* zT_14;
    zT_FF4D4E6C_EU_242 zT_19 = {0};
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned char* zT_23;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char zT_38;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_6E8D187B_ModuleEntry* zT_50;
    zT_6E8D187B_ModuleEntry zT_51;
    unsigned int zT_52;
    zT_6E8D187B_ModuleEntry* zT_56;
    zT_6E8D187B_ModuleEntry zT_57;
    unsigned int zT_58;
    zT_79FAE712_u64 zT_60;
    zT_A4CE86B7_U64ToU32Map* zT_61;
    zT_79FAE712_u64 zT_62;
    zT_BAEE192E_Opt_10 zT_64 = {0};
    unsigned char zT_65;
    unsigned char zT_66;
    unsigned int zT_68;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_6E8D187B_ModuleEntry* zT_92;
    zT_6E8D187B_ModuleEntry zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_100;
    zT_79FAE712_u64 zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    zT_BAEE192E_Opt_10 zT_106 = {0};
    unsigned char zT_107;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    zT_22A7C88B_AstNode zT_113 = {0};
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_F85C5DED_DiagnosticCollector* zT_118;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_6E8D187B_ModuleEntry* zT_130;
    zT_6E8D187B_ModuleEntry zT_131;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_138 = 0;
    unsigned char zT_139;
    unsigned int zT_141;
    unsigned int zT_143;
    unsigned char zT_144;
    zT_B687BB96_U32ArrayList* zT_145;
    unsigned int zT_146;
    zT_6E8D187B_ModuleEntry* zT_148;
    zT_6E8D187B_ModuleEntry zT_149;
    unsigned int zT_152;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int n;
    unsigned char* placed;
    unsigned int i;
    unsigned int remaining;
    unsigned int pick;
    unsigned char ok;
    unsigned int j;
    zT_79FAE712_u64 dep_key;
    unsigned int ri;
    unsigned char reported;
    unsigned int rj;
    zT_79FAE712_u64 cyc_key;
    unsigned int ref_decl;
    zT_22A7C88B_AstNode cyc_dcl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cyc_msg;
    zT_2 = ctx->module_reg;
    zT_4 = zF_3452C137_moduleRegistryGetMo(zT_2);
    mods = zT_4;
    zT_7 = mods.len;
    n = zT_7;
    zT_9 = &ctx->module_init_order;
    zT_9->len = (unsigned int)(0);
    zT_14 = ctx->alloc;
    zT_11 = &zT_14->scratch;
    zT_19 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)(n + (unsigned int)(1)), (unsigned int)(1));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_21 = zT_19.data.payload;
    goto z_bb_3;
    z_bb_3:
    zT_23 = (unsigned char*)zT_21;
    placed = zT_23;
    zT_25 = 0;
    i = zT_25;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < n)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = 0;
    placed[i] = zT_27;
    goto z_bb_7;
    z_bb_6:
    remaining = n;
    goto z_bb_8;
    z_bb_7:
    zT_29 = i + (unsigned int)(1);
    i = zT_29;
    goto z_bb_4;
    z_bb_8:
    if ((unsigned char)(remaining > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pick = n;
    zT_34 = 0;
    i = zT_34;
    goto z_bb_12;
    z_bb_10:
    return;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    if ((unsigned char)(i < n)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_38 = placed[i];
    if ((unsigned char)(zT_38 != (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_14:
    if ((unsigned char)(pick == n)) goto z_bb_31; else goto z_bb_32;
    z_bb_15:
    zT_72 = i + (unsigned int)(1);
    i = zT_72;
    goto z_bb_12;
    z_bb_16:
    zT_36 = pick == n;
    goto z_bb_18;
    z_bb_17:
    zT_36 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_36) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_42 = 1;
    ok = zT_42;
    zT_44 = 0;
    j = zT_44;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(j < n)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_46 = placed[j];
    if ((unsigned char)(zT_46 != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    if ((unsigned char)(ok != (unsigned char)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_24:
    zT_68 = j + (unsigned int)(1);
    j = zT_68;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_50 = mods.ptr;
    zT_51 = zT_50[i];
    zT_52 = zT_51.id;
    zT_56 = mods.ptr;
    zT_57 = zT_56[j];
    zT_58 = zT_57.id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_52) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_58);
    dep_key = zT_60;
    zT_61 = &ctx->module_init_deps;
    zT_62 = dep_key;
    zT_64 = zF_A05A7BE1_u64ToU32MapGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_66 = 0;
    ok = zT_66;
    goto z_bb_23;
    z_bb_28:
    goto z_bb_24;
    z_bb_29:
    pick = i;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_15;
    z_bb_31:
    zT_75 = 0;
    ri = zT_75;
    zT_77 = 0;
    reported = zT_77;
    goto z_bb_33;
    z_bb_32:
    zT_144 = 1;
    placed[pick] = zT_144;
    zT_145 = &ctx->module_init_order;
    zT_148 = mods.ptr;
    zT_149 = zT_148[pick];
    zT_146 = zT_149.id;
    zF_62F717A2_u32ArrayListAppend(zT_145, zT_146);
    zT_152 = remaining - (unsigned int)(1);
    remaining = zT_152;
    goto z_bb_11;
    z_bb_33:
    if ((unsigned char)(ri < n)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    zT_82 = placed[ri];
    if ((unsigned char)(zT_82 != (unsigned char)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_35:
    goto z_bb_10;
    z_bb_36:
    zT_143 = ri + (unsigned int)(1);
    ri = zT_143;
    goto z_bb_33;
    z_bb_37:
    zT_79 = reported == (unsigned char)(0);
    goto z_bb_39;
    z_bb_38:
    zT_79 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_79) goto z_bb_34; else goto z_bb_35;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_86 = 0;
    rj = zT_86;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(rj < n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_88 = placed[rj];
    if ((unsigned char)(zT_88 != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_36;
    z_bb_45:
    zT_141 = rj + (unsigned int)(1);
    rj = zT_141;
    goto z_bb_42;
    z_bb_46:
    goto z_bb_45;
    z_bb_47:
    zT_92 = mods.ptr;
    zT_93 = zT_92[ri];
    zT_94 = zT_93.id;
    zT_98 = mods.ptr;
    zT_99 = zT_98[rj];
    zT_100 = zT_99.id;
    zT_102 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_94) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_100);
    cyc_key = zT_102;
    zT_103 = &ctx->module_init_deps;
    zT_104 = cyc_key;
    zT_106 = zF_A05A7BE1_u64ToU32MapGet(zT_103, zT_104);
    zT_107 = zT_106.has_value;
    if (zT_107) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    ref_decl = zT_106.value;
    zT_110 = ctx->store;
    zT_111 = ref_decl;
    zT_113 = zF_FCDD1D35_astStoreNodeAt(zT_110, zT_111);
    cyc_dcl = zT_113;
    zT_115 = "cyclic global initializer dependency";
    zT_117 = 36;
    zT_116.ptr = zT_115;
    zT_116.len = zT_117;
    cyc_msg = zT_116;
    zT_118 = ctx->diag;
    zT_130 = mods.ptr;
    zT_131 = zT_130[ri];
    zT_121 = zT_131.source_file_id;
    zT_122 = cyc_dcl.span_start;
    zT_134 = cyc_dcl.span_start;
    zT_135 = cyc_dcl.span_len;
    zT_124 = cyc_msg;
    zT_138 = zF_C82559AC_diagnosticCollector(zT_118, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3064_CYCLIC_GLOBAL_INIT)), zT_121, zT_122, (unsigned int)(zT_134 + (unsigned int)((unsigned int)zT_135)), zT_124);
    (void)zT_138;
    zT_139 = 1;
    reported = zT_139;
    goto z_bb_44;
    z_bb_49:
    goto z_bb_45;
}

/* errorCodeRegistryFinalize */
void zF_FC691B4D_errorCodeRegistryFi(zT_5AB29387_CompilerContext* ctx) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned short zT_15;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_0B73C507_ErrorSetPayload* zT_22;
    unsigned short zT_23;
    unsigned int zT_24;
    zT_0B73C507_ErrorSetPayload zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int* zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_21D3708C_U32ToU32Map* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    int zT_43;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int ti;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload esp;
    unsigned int ei;
    unsigned int mname_id;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ctx->typereg;
    zT_5 = zT_4->types_len;
    if ((unsigned char)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = ctx->typereg;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_46 = 1;
    zT_48 = ti + (unsigned int)((unsigned int)zT_46);
    ti = zT_48;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = ty.payload_idx;
    zT_17 = ctx->typereg;
    zT_18 = zT_17->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_15) >= zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_21 = ctx->typereg;
    zT_22 = zT_21->es_items;
    zT_23 = ty.payload_idx;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    esp = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    ei = zT_28;
    goto z_bb_9;
    z_bb_9:
    zT_29 = esp.tags_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_29))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = ctx->typereg;
    zT_34 = zT_33->xn_items;
    zT_35 = esp.tags_start;
    zT_37 = (unsigned int)((unsigned int)zT_35) + ei;
    zT_38 = zT_34[zT_37];
    mname_id = zT_38;
    zT_39 = &ctx->error_code_registry;
    zT_40 = mname_id;
    zT_42 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_39, zT_40);
    (void)zT_42;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_43 = 1;
    zT_45 = ei + (unsigned int)((unsigned int)zT_43);
    ei = zT_45;
    goto z_bb_9;
}

/* pruneTypeMarkByValue */
void zF_BC6C7740_pruneTypeMarkByValu(zT_21D3708C_U32ToU32Map* ref_edges, zT_338B7C76_TypeRegistry* reg, zT_A4CE86B7_U64ToU32Map* visited, unsigned int src_mid, unsigned int tid) {
    unsigned int zT_5;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_79FAE712_u64 zT_15;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_79FAE712_u64 zT_19;
    zT_D155D06D_Type* zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    unsigned char zT_26;
    unsigned char zT_29;
    unsigned char zT_30;
    zT_21D3708C_U32ToU32Map* zT_32;
    unsigned char zT_37;
    zT_33EF6BFB_TypeKind zT_40;
    zT_406493CE_StructPayload* zT_45;
    unsigned short zT_46;
    unsigned int zT_47;
    zT_406493CE_StructPayload zT_48;
    unsigned int zT_50;
    unsigned short zT_51;
    zT_21D3708C_U32ToU32Map* zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    zT_A4CE86B7_U64ToU32Map* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_2DF01B61_FieldEntry* zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    zT_2DF01B61_FieldEntry zT_63;
    unsigned int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_54FF90FA_TaggedUnionPayload* zT_72;
    unsigned short zT_73;
    unsigned int zT_74;
    zT_54FF90FA_TaggedUnionPayload zT_75;
    zT_21D3708C_U32ToU32Map* zT_76;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned short zT_84;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_A4CE86B7_U64ToU32Map* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_2DF01B61_FieldEntry* zT_92;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_2DF01B61_FieldEntry zT_96;
    unsigned int zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    unsigned char zT_104;
    zT_33EF6BFB_TypeKind zT_105;
    zT_AF9231A2_UnionPayload* zT_110;
    unsigned short zT_111;
    unsigned int zT_112;
    zT_AF9231A2_UnionPayload zT_113;
    zT_21D3708C_U32ToU32Map* zT_114;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_A4CE86B7_U64ToU32Map* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_121;
    unsigned short zT_122;
    zT_21D3708C_U32ToU32Map* zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_A4CE86B7_U64ToU32Map* zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    zT_2DF01B61_FieldEntry* zT_130;
    unsigned int zT_131;
    unsigned int zT_133;
    zT_2DF01B61_FieldEntry zT_134;
    unsigned int zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_457ECFEE_EnumPayload* zT_143;
    unsigned short zT_144;
    unsigned int zT_145;
    zT_457ECFEE_EnumPayload zT_146;
    zT_21D3708C_U32ToU32Map* zT_147;
    zT_338B7C76_TypeRegistry* zT_148;
    zT_A4CE86B7_U64ToU32Map* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_33EF6BFB_TypeKind zT_153;
    zT_E834303C_ArrayPayload* zT_158;
    unsigned short zT_159;
    unsigned int zT_160;
    zT_E834303C_ArrayPayload zT_161;
    zT_21D3708C_U32ToU32Map* zT_162;
    zT_338B7C76_TypeRegistry* zT_163;
    zT_A4CE86B7_U64ToU32Map* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_33EF6BFB_TypeKind zT_168;
    zT_666DC2E1_TuplePayload* zT_173;
    unsigned short zT_174;
    unsigned int zT_175;
    zT_666DC2E1_TuplePayload zT_176;
    unsigned int zT_178;
    unsigned short zT_179;
    zT_21D3708C_U32ToU32Map* zT_182;
    zT_338B7C76_TypeRegistry* zT_183;
    zT_A4CE86B7_U64ToU32Map* zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int* zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_193;
    zT_33EF6BFB_TypeKind zT_194;
    zT_0B10E8E9_OptionalPayload* zT_199;
    unsigned short zT_200;
    unsigned int zT_201;
    zT_0B10E8E9_OptionalPayload zT_202;
    zT_21D3708C_U32ToU32Map* zT_203;
    zT_338B7C76_TypeRegistry* zT_204;
    zT_A4CE86B7_U64ToU32Map* zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_33EF6BFB_TypeKind zT_209;
    zT_42C2D6BF_EUPayload* zT_214;
    unsigned short zT_215;
    unsigned int zT_216;
    zT_42C2D6BF_EUPayload zT_217;
    zT_21D3708C_U32ToU32Map* zT_218;
    zT_338B7C76_TypeRegistry* zT_219;
    zT_A4CE86B7_U64ToU32Map* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_21D3708C_U32ToU32Map* zT_224;
    zT_338B7C76_TypeRegistry* zT_225;
    zT_A4CE86B7_U64ToU32Map* zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    zT_79FAE712_u64 vkey;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload p;
    unsigned int fi;
    zT_54FF90FA_TaggedUnionPayload p_1;
    zT_AF9231A2_UnionPayload p_2;
    zT_457ECFEE_EnumPayload p_3;
    zT_E834303C_ArrayPayload p_4;
    zT_666DC2E1_TuplePayload p_5;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload p_6;
    zT_42C2D6BF_EUPayload p_7;
    zT_5 = reg->types_len;
    if ((unsigned char)(tid >= (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)src_mid) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)tid);
    vkey = zT_13;
    zT_14 = visited;
    zT_15 = vkey;
    zT_16 = zF_A05A7BE1_u64ToU32MapGet(zT_14, zT_15);
    zT_17 = zT_16.has_value;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = visited;
    zT_19 = vkey;
    zF_B6EB812C_u64ToU32MapPut(zT_18, zT_19, (unsigned int)(1));
    zT_23 = reg->types_items;
    zT_24 = (unsigned int)tid;
    zT_25 = zT_23[zT_24];
    ty = zT_25;
    zT_26 = ty.module_id;
    if ((unsigned char)(zT_26 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = ty.module_id;
    zT_29 = zT_30 != src_mid;
    goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = ref_edges;
    zT_37 = ty.module_id;
    zF_26476265_u32ToU32MapPut(zT_32, (unsigned int)((unsigned int)(src_mid * (unsigned int)(65536)) + zT_37), (unsigned int)(1));
    goto z_bb_9;
    z_bb_9:
    zT_40 = ty.kind;
    if ((unsigned char)(zT_40 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_45 = reg->st_items;
    zT_46 = ty.payload_idx;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zT_45[zT_47];
    p = zT_48;
    zT_50 = 0;
    fi = zT_50;
    goto z_bb_13;
    z_bb_11:
    return;
    z_bb_12:
    zT_67 = ty.kind;
    if ((unsigned char)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_13:
    zT_51 = p.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_51))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_54 = ref_edges;
    zT_55 = reg;
    zT_56 = visited;
    zT_57 = src_mid;
    zT_59 = reg->fe_items;
    zT_60 = p.fields_start;
    zT_62 = (unsigned int)((unsigned int)zT_60) + fi;
    zT_63 = zT_59[zT_62];
    zT_58 = zT_63.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_54, zT_55, zT_56, zT_57, zT_58);
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_66 = fi + (unsigned int)(1);
    fi = zT_66;
    goto z_bb_13;
    z_bb_17:
    zT_72 = reg->tu_items;
    zT_73 = ty.payload_idx;
    zT_74 = (unsigned int)zT_73;
    zT_75 = zT_72[zT_74];
    p_1 = zT_75;
    zT_76 = ref_edges;
    zT_77 = reg;
    zT_78 = visited;
    zT_79 = src_mid;
    zT_80 = p_1.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_76, zT_77, zT_78, zT_79, zT_80);
    zT_83 = 0;
    fi = zT_83;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_11;
    z_bb_19:
    zT_100 = ty.kind;
    if ((unsigned char)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_25; else goto z_bb_24;
    z_bb_20:
    zT_84 = p_1.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_84))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_87 = ref_edges;
    zT_88 = reg;
    zT_89 = visited;
    zT_90 = src_mid;
    zT_92 = reg->fe_items;
    zT_93 = p_1.fields_start;
    zT_95 = (unsigned int)((unsigned int)zT_93) + fi;
    zT_96 = zT_92[zT_95];
    zT_91 = zT_96.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_87, zT_88, zT_89, zT_90, zT_91);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_99 = fi + (unsigned int)(1);
    fi = zT_99;
    goto z_bb_20;
    z_bb_24:
    zT_105 = ty.kind;
    zT_104 = zT_105 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_26;
    z_bb_25:
    zT_104 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_104) goto z_bb_27; else goto z_bb_29;
    z_bb_27:
    zT_110 = reg->un_items;
    zT_111 = ty.payload_idx;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zT_110[zT_112];
    p_2 = zT_113;
    zT_114 = ref_edges;
    zT_115 = reg;
    zT_116 = visited;
    zT_117 = src_mid;
    zT_118 = p_2.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_114, zT_115, zT_116, zT_117, zT_118);
    zT_121 = 0;
    fi = zT_121;
    goto z_bb_30;
    z_bb_28:
    goto z_bb_18;
    z_bb_29:
    zT_138 = ty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_36;
    z_bb_30:
    zT_122 = p_2.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_122))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_125 = ref_edges;
    zT_126 = reg;
    zT_127 = visited;
    zT_128 = src_mid;
    zT_130 = reg->fe_items;
    zT_131 = p_2.fields_start;
    zT_133 = (unsigned int)((unsigned int)zT_131) + fi;
    zT_134 = zT_130[zT_133];
    zT_129 = zT_134.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_125, zT_126, zT_127, zT_128, zT_129);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_137 = fi + (unsigned int)(1);
    fi = zT_137;
    goto z_bb_30;
    z_bb_34:
    zT_143 = reg->en_items;
    zT_144 = ty.payload_idx;
    zT_145 = (unsigned int)zT_144;
    zT_146 = zT_143[zT_145];
    p_3 = zT_146;
    zT_147 = ref_edges;
    zT_148 = reg;
    zT_149 = visited;
    zT_150 = src_mid;
    zT_151 = p_3.backing_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_147, zT_148, zT_149, zT_150, zT_151);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_28;
    z_bb_36:
    zT_153 = ty.kind;
    if ((unsigned char)(zT_153 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_158 = reg->array_items;
    zT_159 = ty.payload_idx;
    zT_160 = (unsigned int)zT_159;
    zT_161 = zT_158[zT_160];
    p_4 = zT_161;
    zT_162 = ref_edges;
    zT_163 = reg;
    zT_164 = visited;
    zT_165 = src_mid;
    zT_166 = p_4.elem;
    zF_BC6C7740_pruneTypeMarkByValu(zT_162, zT_163, zT_164, zT_165, zT_166);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_168 = ty.kind;
    if ((unsigned char)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_173 = reg->tup_items;
    zT_174 = ty.payload_idx;
    zT_175 = (unsigned int)zT_174;
    zT_176 = zT_173[zT_175];
    p_5 = zT_176;
    zT_178 = 0;
    ei = zT_178;
    goto z_bb_43;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_194 = ty.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_47; else goto z_bb_49;
    z_bb_43:
    zT_179 = p_5.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_179))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_182 = ref_edges;
    zT_183 = reg;
    zT_184 = visited;
    zT_185 = src_mid;
    zT_187 = reg->xt_items;
    zT_188 = p_5.elems_start;
    zT_190 = (unsigned int)((unsigned int)zT_188) + ei;
    zT_186 = zT_187[zT_190];
    zF_BC6C7740_pruneTypeMarkByValu(zT_182, zT_183, zT_184, zT_185, zT_186);
    goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_193 = ei + (unsigned int)(1);
    ei = zT_193;
    goto z_bb_43;
    z_bb_47:
    zT_199 = reg->opt_items;
    zT_200 = ty.payload_idx;
    zT_201 = (unsigned int)zT_200;
    zT_202 = zT_199[zT_201];
    p_6 = zT_202;
    zT_203 = ref_edges;
    zT_204 = reg;
    zT_205 = visited;
    zT_206 = src_mid;
    zT_207 = p_6.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_203, zT_204, zT_205, zT_206, zT_207);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_41;
    z_bb_49:
    zT_209 = ty.kind;
    if ((unsigned char)(zT_209 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_214 = reg->eu_items;
    zT_215 = ty.payload_idx;
    zT_216 = (unsigned int)zT_215;
    zT_217 = zT_214[zT_216];
    p_7 = zT_217;
    zT_218 = ref_edges;
    zT_219 = reg;
    zT_220 = visited;
    zT_221 = src_mid;
    zT_222 = p_7.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_218, zT_219, zT_220, zT_221, zT_222);
    zT_224 = ref_edges;
    zT_225 = reg;
    zT_226 = visited;
    zT_227 = src_mid;
    zT_228 = p_7.error_set;
    zF_BC6C7740_pruneTypeMarkByValu(zT_224, zT_225, zT_226, zT_227, zT_228);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
}

/* moduleIdForBasename */
unsigned int zF_D27A4A01_moduleIdForBasename(zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u base) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_D3EB6303_StringInterner* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry* zT_11;
    zT_6E8D187B_ModuleEntry zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14 = {0};
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned char* zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned char zT_37;
    unsigned char zT_39;
    unsigned int zT_41;
    zT_6E8D187B_ModuleEntry* zT_46;
    zT_6E8D187B_ModuleEntry zT_47;
    unsigned int zT_48;
    unsigned char* zT_49;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_6E8D187B_ModuleEntry* zT_55;
    zT_6E8D187B_ModuleEntry zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u p;
    unsigned int off;
    unsigned char eq;
    unsigned int j;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = interner;
    zT_11 = mods.ptr;
    zT_12 = zT_11[i];
    zT_10 = zT_12.path_id;
    zT_14 = zF_9134020D_stringInternerGet(zT_9, zT_10);
    p = zT_14;
    zT_16 = p.len;
    zT_18 = base.len;
    if ((unsigned char)(zT_16 >= zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_1;
    z_bb_5:
    zT_22 = p.len;
    zT_24 = base.len;
    zT_25 = zT_22 - zT_24;
    off = zT_25;
    zT_27 = 1;
    eq = zT_27;
    zT_29 = 0;
    j = zT_29;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = base.len;
    if ((unsigned char)(j < zT_31)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = p.ptr;
    zT_34 = off + j;
    zT_35 = zT_33[zT_34];
    zT_36 = base.ptr;
    zT_37 = zT_36[j];
    if ((unsigned char)(zT_35 != zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    if ((unsigned char)(eq != (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_41 = j + (unsigned int)(1);
    j = zT_41;
    goto z_bb_7;
    z_bb_11:
    zT_39 = 0;
    eq = zT_39;
    goto z_bb_9;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    if ((unsigned char)(off == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_46 = mods.ptr;
    zT_47 = zT_46[i];
    zT_48 = zT_47.id;
    return zT_48;
    z_bb_16:
    zT_49 = p.ptr;
    zT_51 = off - (unsigned int)(1);
    zT_52 = zT_49[zT_51];
    if ((unsigned char)(zT_52 == (unsigned char)(47))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_55 = mods.ptr;
    zT_56 = zT_55[i];
    zT_57 = zT_56.id;
    return zT_57;
    z_bb_18:
    goto z_bb_14;
}

/* phase_C89Emission */
void zF_2268F8CE_phase_C89Emission(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_C98AF326_CompilerCli zT_6;
    unsigned char zT_7;
    unsigned char zT_9;
    zT_C98AF326_CompilerCli zT_10;
    unsigned char zT_11;
    zT_CEC2984A_NameMangler_1 zT_14 = {0};
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_E1A783EF_GlobalDeclArrayList zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_25;
    zT_D3EB6303_StringInterner* zT_26;
    zT_3E40CD83_Sand* zT_27;
    unsigned int zT_28;
    zT_69057089_CompilerAlloc* zT_30;
    zT_CEC2984A_NameMangler_1 zT_32 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_33;
    zT_81A2E9F8_Opt_304 zT_34;
    zT_72C4E2ED_C89Emitter zT_36 = {0};
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D3EB6303_StringInterner* zT_38;
    zT_CEC2984A_NameMangler_1* zT_39;
    zT_F85C5DED_DiagnosticCollector* zT_40;
    zT_9F514E82_SwitchCaseArrayList* zT_41;
    zT_B687BB96_U32ArrayList* zT_42;
    zT_3E40CD83_Sand* zT_43;
    zT_3E40CD83_Sand* zT_44;
    zT_21D3708C_U32ToU32Map* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    int zT_52;
    int zT_53;
    zT_69057089_CompilerAlloc* zT_54;
    zT_69057089_CompilerAlloc* zT_56;
    zT_C98AF326_CompilerCli zT_60;
    zT_72C4E2ED_C89Emitter zT_62 = {0};
    zT_072B53A6_ModuleRegistry* zT_63;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_68;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_072B53A6_ModuleRegistry* zT_71;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_73 = {0};
    unsigned int zT_75 = 0;
    zT_5AB29387_CompilerContext* zT_76;
    zT_E1A783EF_GlobalDeclArrayList* zT_78;
    zT_23133B1E_Slice_zT_54906056_M zT_80 = {0};
    zT_54906056_ModuleGlobalDecl* zT_82;
    unsigned int zT_84;
    zT_B687BB96_U32ArrayList zT_86;
    unsigned int* zT_87;
    zT_B687BB96_U32ArrayList zT_88;
    unsigned int zT_89;
    zT_7E7544E4_LirStream* zT_90;
    zT_CA01C129_LirSlotArrayList zT_91;
    zT_E7714190_LirSlot* zT_92;
    zT_CA01C129_LirSlotArrayList zT_94;
    unsigned int zT_95;
    zT_69057089_CompilerAlloc* zT_96;
    zT_3E40CD83_Sand* zT_97;
    zT_7E7544E4_LirStream* zT_98;
    zT_3E40CD83_Sand* zT_99;
    zT_69057089_CompilerAlloc* zT_101;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_3E40CD83_Sand* zT_108;
    zT_69057089_CompilerAlloc* zT_109;
    zT_21D3708C_U32ToU32Map zT_111 = {0};
    zT_3E40CD83_Sand* zT_113;
    unsigned int zT_114;
    zT_69057089_CompilerAlloc* zT_115;
    zT_CA01C129_LirSlotArrayList zT_117;
    zT_21D3708C_U32ToU32Map zT_119 = {0};
    zT_3E40CD83_Sand* zT_121;
    zT_69057089_CompilerAlloc* zT_122;
    zT_A4CE86B7_U64ToU32Map zT_124 = {0};
    unsigned int zT_126;
    zT_CA01C129_LirSlotArrayList zT_127;
    unsigned int zT_128;
    zT_7E7544E4_LirStream* zT_131;
    zT_E7714190_LirSlot zT_132;
    zT_3E40CD83_Sand* zT_133;
    zT_CA01C129_LirSlotArrayList zT_135;
    zT_E7714190_LirSlot* zT_136;
    zT_E7714190_LirSlot zT_137;
    zT_69057089_CompilerAlloc* zT_138;
    zT_BBC23664_LirFunction zT_140 = {0};
    unsigned int zT_142;
    unsigned int zT_144;
    zT_5D72FBF8_TempDeclArrayList zT_145;
    unsigned int zT_146;
    zT_5D72FBF8_TempDeclArrayList zT_149;
    zT_1937645B_TempDecl* zT_150;
    zT_1937645B_TempDecl zT_151;
    zT_21D3708C_U32ToU32Map* zT_152;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_A4CE86B7_U64ToU32Map* zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_21D3708C_U32ToU32Map* zT_162;
    unsigned int zT_163;
    zT_72C4E2ED_C89Emitter* zT_165;
    unsigned int zT_169;
    unsigned int zT_170;
    zT_338B7C76_TypeRegistry* zT_171;
    unsigned int zT_172;
    zT_21D3708C_U32ToU32Map* zT_175;
    zT_338B7C76_TypeRegistry* zT_176;
    zT_A4CE86B7_U64ToU32Map* zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned int zT_185;
    zT_CFE23D0A_LirParamArrayList zT_186;
    unsigned int zT_187;
    zT_CFE23D0A_LirParamArrayList zT_190;
    zT_8779209D_LirParam* zT_191;
    zT_8779209D_LirParam zT_192;
    zT_21D3708C_U32ToU32Map* zT_193;
    zT_338B7C76_TypeRegistry* zT_194;
    zT_A4CE86B7_U64ToU32Map* zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned int zT_203;
    unsigned int zT_205;
    zT_1CF28CA3_BasicBlockArrayList zT_206;
    unsigned int zT_207;
    zT_1CF28CA3_BasicBlockArrayList zT_210;
    zT_88A68B1A_BasicBlock* zT_211;
    zT_88A68B1A_BasicBlock zT_212;
    unsigned int zT_214;
    zT_DAE4631D_LirInstArrayList zT_215;
    unsigned int zT_216;
    zT_DAE4631D_LirInstArrayList zT_219;
    zT_6BA597BC_LirInst* zT_220;
    zT_6BA597BC_LirInst zT_221;
    unsigned int zT_223;
    unsigned char zT_225;
    unsigned int zT_227;
    zT_6BA597BC_LirInst zT_230;
    zT_BBC23664_LirFunction* zT_233;
    unsigned int zT_234;
    zT_3BFB1E70_CallDirectData zT_238 = {0};
    unsigned int zT_239;
    unsigned char zT_240;
    zT_6BA597BC_LirInst zT_243;
    zT_BBC23664_LirFunction* zT_246;
    unsigned int zT_247;
    zT_0624AC1B_TailCallData zT_251 = {0};
    unsigned int zT_252;
    unsigned char zT_253;
    zT_6BA597BC_LirInst zT_256;
    zT_A7EEA2A6_anon_101279 zT_259;
    unsigned int zT_260;
    unsigned char zT_261;
    zT_6BA597BC_LirInst zT_264;
    zT_7AD38B2C_anon_101457 zT_267;
    unsigned int zT_268;
    unsigned char zT_269;
    zT_6BA597BC_LirInst zT_272;
    zT_7CD5CCE9_anon_101465 zT_275;
    unsigned int zT_276;
    unsigned char zT_277;
    unsigned char zT_280;
    zT_21D3708C_U32ToU32Map* zT_282;
    zT_6BA597BC_LirInst zT_292;
    unsigned char zT_294;
    unsigned int zT_295;
    unsigned int zT_298;
    zT_21D3708C_U32ToU32Map* zT_300;
    unsigned int zT_306;
    zT_6BA597BC_LirInst zT_311;
    unsigned char zT_313;
    zT_6BA597BC_LirInst zT_316;
    unsigned int zT_319;
    unsigned int zT_321;
    zT_6BA597BC_LirInst zT_324;
    zT_7AD38B2C_anon_101457 zT_327;
    unsigned int zT_328;
    zT_7AD38B2C_anon_101457 zT_330;
    unsigned int zT_331;
    zT_7CD5CCE9_anon_101465 zT_333;
    unsigned int zT_334;
    zT_7CD5CCE9_anon_101465 zT_336;
    unsigned int zT_337;
    unsigned int zT_339;
    unsigned int zT_341;
    zT_5D72FBF8_TempDeclArrayList zT_342;
    unsigned int zT_343;
    zT_5D72FBF8_TempDeclArrayList zT_346;
    zT_1937645B_TempDecl* zT_347;
    zT_1937645B_TempDecl zT_348;
    unsigned int zT_349;
    unsigned int zT_351;
    unsigned int zT_353;
    zT_338B7C76_TypeRegistry* zT_354;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_359;
    zT_D155D06D_Type* zT_360;
    unsigned int zT_361;
    zT_D155D06D_Type zT_362;
    unsigned short zT_363;
    unsigned char zT_366;
    unsigned short zT_367;
    zT_21D3708C_U32ToU32Map* zT_369;
    unsigned int zT_370;
    unsigned int zT_375;
    unsigned int zT_377;
    unsigned int zT_379;
    zT_072B53A6_ModuleRegistry* zT_381;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_383 = {0};
    unsigned int zT_385;
    unsigned int zT_387;
    zT_6E8D187B_ModuleEntry* zT_389;
    zT_6E8D187B_ModuleEntry zT_390;
    unsigned int zT_391;
    unsigned char zT_395;
    unsigned int zT_397;
    zT_E1A783EF_GlobalDeclArrayList zT_398;
    unsigned int zT_399;
    zT_E1A783EF_GlobalDeclArrayList zT_402;
    zT_54906056_ModuleGlobalDecl* zT_403;
    zT_54906056_ModuleGlobalDecl zT_404;
    unsigned int zT_405;
    zT_6E8D187B_ModuleEntry* zT_406;
    zT_6E8D187B_ModuleEntry zT_407;
    unsigned int zT_408;
    unsigned char zT_410;
    unsigned char zT_411;
    unsigned char zT_414;
    unsigned int zT_416;
    zT_21D3708C_U32ToU32Map* zT_419;
    zT_6E8D187B_ModuleEntry* zT_426;
    zT_6E8D187B_ModuleEntry zT_427;
    unsigned int zT_428;
    unsigned int zT_432;
    unsigned int zT_434;
    zT_E1A783EF_GlobalDeclArrayList zT_435;
    unsigned int zT_436;
    zT_E1A783EF_GlobalDeclArrayList zT_439;
    zT_54906056_ModuleGlobalDecl* zT_440;
    zT_54906056_ModuleGlobalDecl zT_441;
    unsigned int zT_442;
    zT_338B7C76_TypeRegistry* zT_443;
    unsigned int zT_444;
    zT_338B7C76_TypeRegistry* zT_448;
    zT_D155D06D_Type* zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    zT_D155D06D_Type zT_452;
    zT_338B7C76_TypeRegistry* zT_453;
    zT_21D3708C_U32ToU32Map* zT_454;
    unsigned int zT_455;
    zT_72C4E2ED_C89Emitter* zT_457;
    unsigned short zT_460;
    unsigned char zT_463;
    unsigned short zT_464;
    unsigned int zT_465;
    zT_21D3708C_U32ToU32Map* zT_467;
    zT_338B7C76_TypeRegistry* zT_468;
    zT_A4CE86B7_U64ToU32Map* zT_469;
    unsigned int zT_470;
    unsigned int zT_471;
    unsigned int zT_478;
    zT_3E40CD83_Sand* zT_480;
    unsigned int zT_481;
    zT_69057089_CompilerAlloc* zT_482;
    zT_21D3708C_U32ToU32Map zT_486 = {0};
    zT_21D3708C_U32ToU32Map* zT_487;
    unsigned char zT_494;
    unsigned char zT_497;
    unsigned int zT_499;
    unsigned int zT_501;
    zT_6E8D187B_ModuleEntry* zT_504;
    zT_6E8D187B_ModuleEntry zT_505;
    unsigned int zT_506;
    zT_21D3708C_U32ToU32Map* zT_507;
    unsigned int zT_508;
    zT_BAEE192E_Opt_10 zT_510 = {0};
    unsigned char zT_511;
    unsigned int zT_514;
    unsigned int zT_516;
    zT_6E8D187B_ModuleEntry* zT_519;
    zT_6E8D187B_ModuleEntry zT_520;
    unsigned int zT_521;
    zT_21D3708C_U32ToU32Map* zT_523;
    unsigned int zT_524;
    zT_BAEE192E_Opt_10 zT_526 = {0};
    unsigned char zT_527;
    zT_21D3708C_U32ToU32Map* zT_528;
    zT_BAEE192E_Opt_10 zT_534 = {0};
    unsigned char zT_535;
    zT_21D3708C_U32ToU32Map* zT_536;
    unsigned int zT_537;
    unsigned char zT_541;
    unsigned int zT_543;
    unsigned int zT_545;
    zT_C98AF326_CompilerCli zT_546;
    unsigned char zT_547;
    unsigned int zT_549;
    unsigned int zT_550;
    zT_21D3708C_U32ToU32Map* zT_552;
    unsigned int zT_553;
    zT_72C4E2ED_C89Emitter* zT_555;
    unsigned int* zT_557;
    unsigned int zT_558;
    int zT_561;
    unsigned int zT_563;
    zT_338B7C76_TypeRegistry* zT_565;
    zT_3E40CD83_Sand* zT_566;
    zT_69057089_CompilerAlloc* zT_568;
    unsigned int* zT_570 = 0;
    zT_846744CC_Arr_unsigned_char_5 zT_572;
    unsigned int zT_574;
    zT_C98AF326_CompilerCli zT_576;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_577;
    zT_72C4E2ED_C89Emitter* zT_578;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_579;
    unsigned int zT_582;
    unsigned int zT_584;
    unsigned char zT_586;
    unsigned char* zT_589;
    unsigned char zT_590;
    int zT_591;
    unsigned int zT_593;
    int zT_594;
    unsigned int zT_596;
    unsigned char zT_597;
    int zT_598;
    unsigned int zT_600;
    unsigned char* zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    unsigned int zT_604;
    unsigned int zT_606;
    unsigned int zT_608;
    unsigned char zT_610;
    unsigned char* zT_613;
    unsigned char zT_614;
    int zT_615;
    unsigned int zT_617;
    int zT_618;
    unsigned int zT_620;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_622;
    int zT_626;
    unsigned char* zT_627;
    unsigned int zT_628;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_629;
    unsigned int zT_631 = 0;
    unsigned char* zT_635;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_636;
    unsigned int zT_637;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_638;
    zT_63BE4FF5_BufferedWriter zT_642 = {0};
    unsigned int zT_643;
    zT_63BE4FF5_BufferedWriter zT_644 = {0};
    zT_72C4E2ED_C89Emitter* zT_645;
    zT_338B7C76_TypeRegistry* zT_646;
    unsigned int* zT_647;
    zT_63BE4FF5_BufferedWriter* zT_650;
    zT_72C4E2ED_C89Emitter* zT_651;
    unsigned int zT_653;
    zT_072B53A6_ModuleRegistry* zT_655;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_657 = {0};
    zT_CA01C129_LirSlotArrayList zT_660;
    unsigned int zT_661;
    int zT_662;
    zT_3E40CD83_Sand* zT_665;
    zT_69057089_CompilerAlloc* zT_668;
    unsigned int zT_672;
    zT_FF4D4E6C_EU_242 zT_675 = {0};
    unsigned char zT_676;
    unsigned char* zT_677;
    unsigned int* zT_679;
    zT_3E40CD83_Sand* zT_681;
    zT_69057089_CompilerAlloc* zT_684;
    unsigned int zT_688;
    zT_FF4D4E6C_EU_242 zT_691 = {0};
    unsigned char zT_692;
    unsigned char* zT_693;
    unsigned int* zT_695;
    unsigned int zT_697;
    unsigned int zT_699;
    unsigned int zT_701;
    int zT_702;
    unsigned int zT_704;
    unsigned int zT_706;
    zT_CA01C129_LirSlotArrayList zT_709;
    zT_E7714190_LirSlot* zT_710;
    zT_E7714190_LirSlot zT_711;
    unsigned int zT_712;
    unsigned int zT_715;
    unsigned int zT_717;
    unsigned int zT_718;
    unsigned int zT_720;
    unsigned int zT_721;
    int zT_722;
    unsigned int zT_724;
    unsigned int zT_726;
    unsigned int zT_727;
    unsigned int zT_729;
    unsigned int zT_731;
    unsigned int zT_732;
    int zT_733;
    unsigned int zT_735;
    zT_3E40CD83_Sand* zT_737;
    zT_69057089_CompilerAlloc* zT_740;
    zT_FF4D4E6C_EU_242 zT_745 = {0};
    unsigned char zT_746;
    unsigned char* zT_747;
    zT_E7714190_LirSlot* zT_749;
    unsigned int zT_750;
    zT_CA01C129_LirSlotArrayList zT_753;
    zT_E7714190_LirSlot* zT_754;
    zT_E7714190_LirSlot zT_755;
    unsigned int zT_757;
    unsigned int zT_760;
    unsigned int zT_763;
    unsigned int zT_764;
    unsigned int zT_765;
    unsigned int zT_767;
    unsigned int zT_768;
    int zT_769;
    unsigned int zT_771;
    zT_CA01C129_LirSlotArrayList* zT_772;
    zT_CA01C129_LirSlotArrayList* zT_774;
    unsigned int zT_776;
    unsigned int zT_778;
    unsigned int zT_780;
    zT_6E8D187B_ModuleEntry* zT_783;
    zT_6E8D187B_ModuleEntry zT_784;
    zT_CA01C129_LirSlotArrayList zT_786;
    unsigned int zT_787;
    unsigned char zT_789;
    zT_CA01C129_LirSlotArrayList zT_790;
    zT_E7714190_LirSlot* zT_791;
    zT_E7714190_LirSlot zT_792;
    unsigned int zT_793;
    unsigned int zT_794;
    unsigned int zT_797;
    zT_21D3708C_U32ToU32Map* zT_798;
    unsigned int zT_799;
    zT_BAEE192E_Opt_10 zT_802 = {0};
    unsigned char zT_803;
    zT_72C4E2ED_C89Emitter* zT_807;
    unsigned int zT_808;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_811 = {0};
    unsigned int zT_813;
    unsigned int zT_817;
    unsigned char* zT_824;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_825;
    unsigned int zT_826;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_827;
    unsigned int zT_831;
    unsigned int zT_833;
    unsigned int zT_835;
    unsigned char zT_837;
    unsigned char* zT_840;
    unsigned char zT_841;
    int zT_842;
    unsigned int zT_844;
    int zT_845;
    unsigned int zT_847;
    unsigned char zT_848;
    int zT_849;
    unsigned int zT_851;
    unsigned int zT_853;
    unsigned int zT_855;
    unsigned char zT_857;
    unsigned char* zT_860;
    unsigned char zT_861;
    int zT_862;
    unsigned int zT_864;
    int zT_865;
    unsigned int zT_867;
    unsigned char* zT_869;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_870;
    unsigned int zT_871;
    unsigned int zT_873;
    unsigned int zT_875;
    unsigned char zT_877;
    unsigned char* zT_880;
    unsigned char zT_881;
    int zT_882;
    unsigned int zT_884;
    int zT_885;
    unsigned int zT_887;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_889;
    int zT_893;
    unsigned char* zT_894;
    unsigned int zT_895;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_896;
    unsigned int zT_898 = 0;
    unsigned char* zT_902;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_903;
    unsigned int zT_904;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_905;
    zT_63BE4FF5_BufferedWriter zT_909 = {0};
    unsigned int zT_910;
    zT_63BE4FF5_BufferedWriter zT_911 = {0};
    unsigned int zT_913;
    unsigned int zT_914;
    unsigned int zT_916;
    unsigned int zT_918;
    zT_072B53A6_ModuleRegistry* zT_920;
    unsigned int* zT_921;
    unsigned int* zT_922;
    unsigned int zT_923;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_924;
    zT_B687BB96_U32ArrayList zT_926;
    unsigned int* zT_927;
    zT_B687BB96_U32ArrayList zT_928;
    unsigned int zT_929;
    int zT_930;
    unsigned int* zT_931;
    unsigned int zT_932;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_933;
    zT_3E40CD83_Sand* zT_935;
    zT_69057089_CompilerAlloc* zT_938;
    unsigned int zT_942;
    zT_FF4D4E6C_EU_242 zT_945 = {0};
    unsigned char zT_946;
    unsigned char* zT_947;
    unsigned int* zT_950;
    unsigned int zT_952;
    unsigned int zT_954;
    unsigned int zT_956;
    unsigned int* zT_959;
    unsigned int zT_960;
    unsigned int zT_961;
    zT_21D3708C_U32ToU32Map* zT_963;
    unsigned int zT_964;
    zT_BAEE192E_Opt_10 zT_966 = {0};
    unsigned char zT_967;
    unsigned char zT_970;
    unsigned int zT_972;
    unsigned int zT_974;
    unsigned char zT_976;
    unsigned int zT_978;
    unsigned int zT_982;
    unsigned int zT_984;
    unsigned int zT_986;
    unsigned int zT_988;
    zT_6E8D187B_ModuleEntry* zT_991;
    zT_6E8D187B_ModuleEntry zT_992;
    unsigned int zT_993;
    unsigned int zT_994;
    zT_21D3708C_U32ToU32Map* zT_996;
    unsigned int zT_997;
    zT_BAEE192E_Opt_10 zT_999 = {0};
    unsigned char zT_1000;
    zT_21D3708C_U32ToU32Map* zT_1002;
    unsigned int zT_1005;
    zT_BAEE192E_Opt_10 zT_1009 = {0};
    unsigned char zT_1010;
    unsigned char zT_1013;
    unsigned int zT_1015;
    unsigned int zT_1017;
    unsigned char zT_1019;
    unsigned int zT_1021;
    unsigned int zT_1025;
    unsigned int zT_1027;
    int zT_1029;
    unsigned int* zT_1030;
    unsigned int zT_1031;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1032;
    zT_72C4E2ED_C89Emitter* zT_1033;
    unsigned int zT_1034;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1035;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1036;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1037;
    unsigned int* zT_1038;
    zT_63BE4FF5_BufferedWriter* zT_1041;
    zT_72C4E2ED_C89Emitter* zT_1042;
    unsigned int zT_1044;
    unsigned char* zT_1046;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1047;
    unsigned int zT_1048;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1049;
    zT_846744CC_Arr_unsigned_char_5 zT_1051;
    unsigned int zT_1053;
    unsigned int zT_1055;
    unsigned int zT_1057;
    unsigned char zT_1059;
    unsigned char* zT_1062;
    unsigned char zT_1063;
    int zT_1064;
    unsigned int zT_1066;
    int zT_1067;
    unsigned int zT_1069;
    unsigned char zT_1070;
    int zT_1071;
    unsigned int zT_1073;
    unsigned int zT_1075;
    unsigned int zT_1077;
    unsigned char zT_1079;
    unsigned char* zT_1082;
    unsigned char zT_1083;
    int zT_1084;
    unsigned int zT_1086;
    int zT_1087;
    unsigned int zT_1089;
    unsigned char* zT_1091;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1092;
    unsigned int zT_1093;
    unsigned int zT_1095;
    unsigned int zT_1097;
    unsigned char zT_1099;
    unsigned char* zT_1102;
    unsigned char zT_1103;
    int zT_1104;
    unsigned int zT_1106;
    int zT_1107;
    unsigned int zT_1109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1111;
    int zT_1115;
    unsigned char* zT_1116;
    unsigned int zT_1117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1118;
    unsigned int zT_1120 = 0;
    unsigned char* zT_1124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1125;
    unsigned int zT_1126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1127;
    zT_63BE4FF5_BufferedWriter zT_1131 = {0};
    unsigned int zT_1132;
    zT_63BE4FF5_BufferedWriter zT_1133 = {0};
    zT_72C4E2ED_C89Emitter* zT_1134;
    unsigned int zT_1135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1136;
    zT_63BE4FF5_BufferedWriter* zT_1139;
    zT_72C4E2ED_C89Emitter* zT_1140;
    unsigned int zT_1142;
    unsigned char* zT_1144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1145;
    unsigned int zT_1146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1147;
    int zT_1148;
    unsigned int zT_1150;
    zT_72C4E2ED_C89Emitter* zT_1151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1152;
    unsigned char zT_1153;
    zT_C98AF326_CompilerCli zT_1155;
    zT_7E7544E4_LirStream* zT_1157;
    zT_6B0A7D14_AstStore* zT_1159;
    zT_63BE4FF5_BufferedWriter zT_1162 = {0};
    zT_63BE4FF5_BufferedWriter zT_1163 = {0};
    zT_63BE4FF5_BufferedWriter* zT_1164;
    zT_63BE4FF5_BufferedWriter* zT_1166;
    zT_072B53A6_ModuleRegistry* zT_1169;
    zT_3E40CD83_Sand* zT_1170;
    zT_69057089_CompilerAlloc* zT_1172;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1174 = {0};
    zT_72C4E2ED_C89Emitter* zT_1175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1176;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1177;
    unsigned int* zT_1178;
    unsigned int zT_1179;
    unsigned char* zT_1184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1185;
    unsigned int zT_1186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1187;
    zT_63BE4FF5_BufferedWriter* zT_1188;
    zT_72C4E2ED_C89Emitter* zT_1189;
    zT_7E7544E4_LirStream* zT_1191;
    zT_6B0A7D14_AstStore* zT_1193;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_CEC2984A_NameMangler_1 mangler;
    unsigned int mangler_hint;
    zT_72C4E2ED_C89Emitter emitter;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_23133B1E_Slice_zT_54906056_M gd_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u module_name;
    zT_21D3708C_U32ToU32Map ts_ref_set;
    zT_21D3708C_U32ToU32Map ref_edges;
    zT_A4CE86B7_U64ToU32Map type_visited;
    unsigned int ts_fi;
    zT_BBC23664_LirFunction ts_fn;
    unsigned int ts_src;
    unsigned int ts_tti;
    zT_DDCD424B_Slice_zT_6E8D187B_M ri_mods;
    unsigned int ri_i;
    zT_1937645B_TempDecl ts_hty;
    unsigned int ts_pi;
    zT_8779209D_LirParam ts_pt;
    unsigned int ts_bi;
    zT_88A68B1A_BasicBlock ts_blk;
    unsigned int ts_ii;
    zT_6BA597BC_LirInst ts_inst;
    unsigned int ts_tg;
    unsigned char ts_edge_has;
    unsigned int ts_edge_dst;
    zT_3BFB1E70_CallDirectData ts_cd;
    zT_0624AC1B_TailCallData ts_tc;
    unsigned int ts_name_id;
    unsigned int ts_tmp;
    unsigned int ts_tid;
    unsigned int ts_tj;
    zT_1937645B_TempDecl ts_ht;
    zT_D155D06D_Type ts_ty;
    unsigned int gt_i;
    unsigned char ri_has;
    unsigned int gd_ri;
    zT_54906056_ModuleGlobalDecl gd_g;
    zT_54906056_ModuleGlobalDecl gt_g;
    zT_21D3708C_U32ToU32Map reachable;
    unsigned char rf_changed;
    zT_D155D06D_Type gt_ty;
    unsigned int rf_s;
    unsigned int rf_src;
    unsigned int rf_d;
    unsigned int rf_dst;
    unsigned int poi;
    zT_63BE4FF5_BufferedWriter cwriter;
    zT_3CB0179A_Slice_zT_05F374B1_u c_incs;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    unsigned int* sorted;
    zT_846744CC_Arr_unsigned_char_5 hpath;
    unsigned int hp;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hfn;
    unsigned int hfi;
    unsigned int fd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_63BE4FF5_BufferedWriter hw;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int slot_count;
    unsigned int* grp_counts;
    unsigned int fn_cursor;
    unsigned int mi;
    unsigned int* grp_cursor;
    unsigned int gci;
    unsigned int gsi;
    unsigned int gsmid;
    unsigned int gacc;
    zT_E7714190_LirSlot* grouped;
    zT_E7714190_LirSlot gslot;
    unsigned int gdst;
    zT_6E8D187B_ModuleEntry m;
    unsigned int fn_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    unsigned int hp2;
    unsigned int hi2;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hext;
    unsigned int hx;
    unsigned int fd2;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg2;
    zT_63BE4FF5_BufferedWriter hw2;
    unsigned int dep_start;
    unsigned int dep_end;
    zT_3CB0179A_Slice_zT_05F374B1_u dep_ids;
    zT_3CB0179A_Slice_zT_05F374B1_u m_c_incs;
    unsigned char* inc_raw;
    unsigned int* inc_arr;
    unsigned int inc_n;
    unsigned int di0;
    unsigned int dd0;
    unsigned int vd0;
    unsigned char dup0;
    unsigned int dj0;
    unsigned int vdd0;
    zT_3CB0179A_Slice_zT_05F374B1_u inc_slice;
    zT_846744CC_Arr_unsigned_char_5 cpath;
    unsigned int cp2;
    unsigned int ci2;
    unsigned char dup1;
    unsigned int dj1;
    unsigned int cbi;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    unsigned int cx;
    unsigned int cfd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg3;
    zT_63BE4FF5_BufferedWriter cw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2_m;
    zT_2 = "C\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->cli;
    zT_7 = zT_6.dump_c89;
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = ctx->cli;
    zT_11 = zT_10.output_dir_set;
    zT_9 = !zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_9 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    mangler = zT_14;
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    zT_18 = ctx->global_decls;
    zT_19 = zT_18.len;
    zT_21 = ctx->pointer_only_len;
    zT_25 = (unsigned int)((unsigned int)(zT_17 + zT_19) + (unsigned int)((unsigned int)zT_21)) + (unsigned int)(32);
    mangler_hint = zT_25;
    zT_26 = ctx->interner;
    zT_30 = ctx->alloc;
    zT_27 = &zT_30->emission;
    zT_28 = mangler_hint;
    zT_32 = zF_27DA3900_nameManglerInit_1(zT_26, zT_27, zT_28);
    mangler = zT_32;
    zT_33 = &ctx->exported;
    zT_34.has_value = 1;
    zT_34.value = zT_33;
    mangler.exported = zT_34;
    emitter = zT_36;
    zT_37 = ctx->typereg;
    zT_38 = ctx->interner;
    zT_39 = &mangler;
    zT_40 = ctx->diag;
    zT_52 = 0;
    zT_41 = (zT_9F514E82_SwitchCaseArrayList*)zT_52;
    zT_53 = 0;
    zT_42 = (zT_B687BB96_U32ArrayList*)zT_53;
    zT_54 = ctx->alloc;
    zT_43 = &zT_54->scratch;
    zT_56 = ctx->alloc;
    zT_44 = &zT_56->emission;
    zT_45 = &ctx->error_code_registry;
    zT_46 = ctx->pointer_only_len;
    zT_60 = ctx->cli;
    zT_47 = zT_60.safe_checks;
    zT_62 = zF_63D58A2B_c89EmitterInit(zT_37, zT_38, zT_39, zT_40, zT_41, zT_42, zT_43, zT_44, zT_45, zT_46, zT_47);
    emitter = zT_62;
    zT_63 = ctx->module_reg;
    emitter.module_reg = zT_63;
    zT_65 = "std_fmt.zig";
    zT_67 = 11;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    c89_fmt_base = zT_66;
    zT_71 = ctx->module_reg;
    zT_73 = zF_3452C137_moduleRegistryGetMo(zT_71);
    zT_68 = zT_73;
    zT_69 = ctx->interner;
    zT_70 = c89_fmt_base;
    zT_75 = zF_D27A4A01_moduleIdForBasename(zT_68, zT_69, zT_70);
    emitter.std_fmt_module_id = zT_75;
    zT_76 = ctx;
    zF_FC691B4D_errorCodeRegistryFi(zT_76);
    zT_78 = &ctx->global_decls;
    zT_80 = zF_6ACCE52D_globalDeclArrayList(zT_78);
    gd_slice = zT_80;
    zT_82 = gd_slice.ptr;
    emitter.global_decls = zT_82;
    zT_84 = gd_slice.len;
    emitter.global_decls_len = (unsigned int)((unsigned int)zT_84);
    zT_86 = ctx->module_init_order;
    zT_87 = zT_86.items;
    emitter.module_init_order = zT_87;
    zT_88 = ctx->module_init_order;
    zT_89 = zT_88.len;
    emitter.module_init_order_len = zT_89;
    zT_90 = &ctx->lir_stream;
    emitter.spill = zT_90;
    zT_91 = ctx->lir_slots;
    zT_92 = zT_91.items;
    emitter.fn_slots = zT_92;
    emitter.fn_slots_start = (unsigned int)(0);
    zT_94 = ctx->lir_slots;
    zT_95 = zT_94.len;
    emitter.fn_slots_len = zT_95;
    zT_96 = ctx->alloc;
    zT_97 = &zT_96->lir_read;
    emitter.spill_arena = zT_97;
    zT_98 = &ctx->lir_stream;
    zT_101 = ctx->alloc;
    zT_99 = &zT_101->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_98, zT_99);
    zT_104 = "output";
    zT_106 = 6;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    module_name = zT_105;
    zT_109 = ctx->alloc;
    zT_108 = &zT_109->emission;
    zT_111 = zF_58BDA2DE_u32ToU32MapInit(zT_108);
    ts_ref_set = zT_111;
    zT_115 = ctx->alloc;
    zT_113 = &zT_115->emission;
    zT_117 = ctx->lir_slots;
    zT_114 = zT_117.len;
    zT_119 = zF_619D56E6_u32ToU32MapInitCap(zT_113, zT_114);
    ref_edges = zT_119;
    zT_122 = ctx->alloc;
    zT_121 = &zT_122->emission;
    zT_124 = zF_986226E1_u64ToU32MapInit(zT_121);
    type_visited = zT_124;
    zT_126 = 0;
    ts_fi = zT_126;
    goto z_bb_6;
    z_bb_6:
    zT_127 = ctx->lir_slots;
    zT_128 = zT_127.len;
    if ((unsigned char)(ts_fi < zT_128)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_131 = &ctx->lir_stream;
    zT_135 = ctx->lir_slots;
    zT_136 = zT_135.items;
    zT_137 = zT_136[ts_fi];
    zT_132 = zT_137;
    zT_138 = ctx->alloc;
    zT_133 = &zT_138->lir_read;
    zT_140 = zF_1B7118E0_lirStreamReadFuncti(zT_131, zT_132, zT_133);
    ts_fn = zT_140;
    zT_142 = ts_fn.module_id;
    ts_src = zT_142;
    zT_144 = 0;
    ts_tti = zT_144;
    goto z_bb_10;
    z_bb_8:
    emitter.ts_ref_set = ts_ref_set;
    zT_381 = ctx->module_reg;
    zT_383 = zF_3452C137_moduleRegistryGetMo(zT_381);
    ri_mods = zT_383;
    zT_385 = 0;
    ri_i = zT_385;
    goto z_bb_75;
    z_bb_9:
    zT_379 = ts_fi + (unsigned int)(1);
    ts_fi = zT_379;
    goto z_bb_6;
    z_bb_10:
    zT_145 = ts_fn.hoisted_temps;
    zT_146 = zT_145.len;
    if ((unsigned char)(ts_tti < zT_146)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_149 = ts_fn.hoisted_temps;
    zT_150 = zT_149.items;
    zT_151 = zT_150[ts_tti];
    ts_hty = zT_151;
    zT_152 = &ref_edges;
    zT_153 = ctx->typereg;
    zT_154 = &type_visited;
    zT_155 = ts_src;
    zT_156 = ts_hty.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_152, zT_153, zT_154, zT_155, zT_156);
    zT_161 = ctx->typereg;
    zT_165 = &emitter;
    zT_162 = &zT_165->needed_tuple_set;
    zT_163 = ts_hty.type_id;
    zF_7845A68F_collectNeededTuples(zT_161, zT_162, zT_163);
    goto z_bb_13;
    z_bb_12:
    zT_170 = ts_fn.return_type;
    zT_171 = ctx->typereg;
    zT_172 = zT_171->types_len;
    if ((unsigned char)(zT_170 < (unsigned int)((unsigned int)zT_172))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_169 = ts_tti + (unsigned int)(1);
    ts_tti = zT_169;
    goto z_bb_10;
    z_bb_14:
    zT_175 = &ref_edges;
    zT_176 = ctx->typereg;
    zT_177 = &type_visited;
    zT_178 = ts_src;
    zT_179 = ts_fn.return_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_175, zT_176, zT_177, zT_178, zT_179);
    goto z_bb_15;
    z_bb_15:
    zT_185 = 0;
    ts_pi = zT_185;
    goto z_bb_16;
    z_bb_16:
    zT_186 = ts_fn.params;
    zT_187 = zT_186.len;
    if ((unsigned char)(ts_pi < zT_187)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_190 = ts_fn.params;
    zT_191 = zT_190.items;
    zT_192 = zT_191[ts_pi];
    ts_pt = zT_192;
    zT_193 = &ref_edges;
    zT_194 = ctx->typereg;
    zT_195 = &type_visited;
    zT_196 = ts_src;
    zT_197 = ts_pt.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_193, zT_194, zT_195, zT_196, zT_197);
    goto z_bb_19;
    z_bb_18:
    zT_205 = 0;
    ts_bi = zT_205;
    goto z_bb_20;
    z_bb_19:
    zT_203 = ts_pi + (unsigned int)(1);
    ts_pi = zT_203;
    goto z_bb_16;
    z_bb_20:
    zT_206 = ts_fn.blocks;
    zT_207 = zT_206.len;
    if ((unsigned char)(ts_bi < zT_207)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_210 = ts_fn.blocks;
    zT_211 = zT_210.items;
    zT_212 = zT_211[ts_bi];
    ts_blk = zT_212;
    zT_214 = 0;
    ts_ii = zT_214;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_9;
    z_bb_23:
    zT_377 = ts_bi + (unsigned int)(1);
    ts_bi = zT_377;
    goto z_bb_20;
    z_bb_24:
    zT_215 = ts_blk.insts;
    zT_216 = zT_215.len;
    if ((unsigned char)(ts_ii < zT_216)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_219 = ts_blk.insts;
    zT_220 = zT_219.items;
    zT_221 = zT_220[ts_ii];
    ts_inst = zT_221;
    zT_223 = ts_inst.tag;
    ts_tg = zT_223;
    zT_225 = 0;
    ts_edge_has = zT_225;
    zT_227 = 0;
    ts_edge_dst = zT_227;
    zT_230.tag = 23;
    if ((unsigned char)(ts_tg == zT_230.tag)) goto z_bb_28; else goto z_bb_30;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_375 = ts_ii + (unsigned int)(1);
    ts_ii = zT_375;
    goto z_bb_24;
    z_bb_28:
    zT_233 = &ts_fn;
    zT_234 = ts_inst.payload.jump._0;
    zT_238 = zF_75DE985C_lirSideGetCallDirec(zT_233, zT_234);
    ts_cd = zT_238;
    zT_239 = ts_cd.module_id;
    ts_edge_dst = zT_239;
    zT_240 = 1;
    ts_edge_has = zT_240;
    goto z_bb_29;
    z_bb_29:
    if ((unsigned char)(ts_edge_has != (unsigned char)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_30:
    zT_243.tag = 27;
    if ((unsigned char)(ts_tg == zT_243.tag)) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_246 = &ts_fn;
    zT_247 = ts_inst.payload.jump._0;
    zT_251 = zF_1AB3807F_lirSideGetTailCall(zT_246, zT_247);
    ts_tc = zT_251;
    zT_252 = ts_tc.module_id;
    ts_edge_dst = zT_252;
    zT_253 = 1;
    ts_edge_has = zT_253;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_256.tag = 28;
    if ((unsigned char)(ts_tg == zT_256.tag)) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_259 = ts_inst.payload.func_ref._0;
    zT_260 = zT_259.module_id;
    ts_edge_dst = zT_260;
    zT_261 = 1;
    ts_edge_has = zT_261;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_264.tag = 54;
    if ((unsigned char)(ts_tg == zT_264.tag)) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_267 = ts_inst.payload.load_global._0;
    zT_268 = zT_267.module_id;
    ts_edge_dst = zT_268;
    zT_269 = 1;
    ts_edge_has = zT_269;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_272.tag = 55;
    if ((unsigned char)(ts_tg == zT_272.tag)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_275 = ts_inst.payload.store_global._0;
    zT_276 = zT_275.module_id;
    ts_edge_dst = zT_276;
    zT_277 = 1;
    ts_edge_has = zT_277;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_280 = ts_edge_dst != ts_src;
    goto z_bb_44;
    z_bb_43:
    zT_280 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_280) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_282 = &ref_edges;
    zF_26476265_u32ToU32MapPut(zT_282, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + ts_edge_dst), (unsigned int)(1));
    goto z_bb_46;
    z_bb_46:
    zT_292.tag = 57;
    if ((unsigned char)(ts_tg == zT_292.tag)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_295 = emitter.std_fmt_module_id;
    zT_294 = zT_295 != (unsigned int)(4294967295u);
    goto z_bb_49;
    z_bb_48:
    zT_294 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_294) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_298 = emitter.std_fmt_module_id;
    if ((unsigned char)(zT_298 != ts_src)) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    zT_311.tag = 54;
    if ((unsigned char)(ts_tg != zT_311.tag)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_300 = &ref_edges;
    zT_306 = emitter.std_fmt_module_id;
    zF_26476265_u32ToU32MapPut(zT_300, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + zT_306), (unsigned int)(1));
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    zT_316.tag = 55;
    zT_313 = ts_tg != zT_316.tag;
    goto z_bb_56;
    z_bb_55:
    zT_313 = 0;
    goto z_bb_56;
    z_bb_56:
    if (zT_313) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    goto z_bb_27;
    z_bb_58:
    zT_319 = 0;
    ts_name_id = zT_319;
    zT_321 = 0;
    ts_tmp = zT_321;
    zT_324.tag = 54;
    if ((unsigned char)(ts_tg == zT_324.tag)) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    zT_327 = ts_inst.payload.load_global._0;
    zT_328 = zT_327.name_id;
    ts_name_id = zT_328;
    zT_330 = ts_inst.payload.load_global._0;
    zT_331 = zT_330.result;
    ts_tmp = zT_331;
    goto z_bb_60;
    z_bb_60:
    zT_339 = 0;
    ts_tid = zT_339;
    zT_341 = 0;
    ts_tj = zT_341;
    goto z_bb_62;
    z_bb_61:
    zT_333 = ts_inst.payload.store_global._0;
    zT_334 = zT_333.name_id;
    ts_name_id = zT_334;
    zT_336 = ts_inst.payload.store_global._0;
    zT_337 = zT_336.value;
    ts_tmp = zT_337;
    goto z_bb_60;
    z_bb_62:
    zT_342 = ts_fn.hoisted_temps;
    zT_343 = zT_342.len;
    if ((unsigned char)(ts_tj < zT_343)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_346 = ts_fn.hoisted_temps;
    zT_347 = zT_346.items;
    zT_348 = zT_347[ts_tj];
    ts_ht = zT_348;
    zT_349 = ts_ht.temp_id;
    if ((unsigned char)(zT_349 == ts_tmp)) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    zT_354 = ctx->typereg;
    zT_355 = zT_354->types_len;
    if ((unsigned char)(ts_tid >= (unsigned int)((unsigned int)zT_355))) goto z_bb_68; else goto z_bb_69;
    z_bb_65:
    zT_353 = ts_tj + (unsigned int)(1);
    ts_tj = zT_353;
    goto z_bb_62;
    z_bb_66:
    zT_351 = ts_ht.type_id;
    ts_tid = zT_351;
    goto z_bb_64;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    goto z_bb_27;
    z_bb_69:
    zT_359 = ctx->typereg;
    zT_360 = zT_359->types_items;
    zT_361 = (unsigned int)ts_tid;
    zT_362 = zT_360[zT_361];
    ts_ty = zT_362;
    zT_363 = ts_ty.name_id;
    if ((unsigned char)(zT_363 != (unsigned int)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_367 = ts_ty.name_id;
    zT_366 = zT_367 == ts_name_id;
    goto z_bb_72;
    z_bb_71:
    zT_366 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_366) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_369 = &ts_ref_set;
    zT_370 = ts_tid;
    zF_26476265_u32ToU32MapPut(zT_369, zT_370, (unsigned int)(1));
    goto z_bb_74;
    z_bb_74:
    goto z_bb_27;
    z_bb_75:
    zT_387 = ri_mods.len;
    if ((unsigned char)(ri_i < zT_387)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_389 = ri_mods.ptr;
    zT_390 = zT_389[ri_i];
    zT_391 = zT_390.id;
    if ((unsigned char)(zT_391 == (unsigned int)(0))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_434 = 0;
    gt_i = zT_434;
    goto z_bb_92;
    z_bb_78:
    zT_432 = ri_i + (unsigned int)(1);
    ri_i = zT_432;
    goto z_bb_75;
    z_bb_79:
    goto z_bb_78;
    z_bb_80:
    zT_395 = 0;
    ri_has = zT_395;
    zT_397 = 0;
    gd_ri = zT_397;
    goto z_bb_81;
    z_bb_81:
    zT_398 = ctx->global_decls;
    zT_399 = zT_398.len;
    if ((unsigned char)(gd_ri < zT_399)) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_402 = ctx->global_decls;
    zT_403 = zT_402.items;
    zT_404 = zT_403[gd_ri];
    gd_g = zT_404;
    zT_405 = gd_g.module_id;
    zT_406 = ri_mods.ptr;
    zT_407 = zT_406[ri_i];
    zT_408 = zT_407.id;
    if ((unsigned char)(zT_405 == zT_408)) goto z_bb_85; else goto z_bb_86;
    z_bb_83:
    if ((unsigned char)(ri_has != (unsigned char)(0))) goto z_bb_90; else goto z_bb_91;
    z_bb_84:
    zT_416 = gd_ri + (unsigned int)(1);
    gd_ri = zT_416;
    goto z_bb_81;
    z_bb_85:
    zT_411 = gd_g.has_runtime_init;
    zT_410 = zT_411 != (unsigned char)(0);
    goto z_bb_87;
    z_bb_86:
    zT_410 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_410) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_414 = 1;
    ri_has = zT_414;
    goto z_bb_83;
    z_bb_89:
    goto z_bb_84;
    z_bb_90:
    zT_419 = &ref_edges;
    zT_426 = ri_mods.ptr;
    zT_427 = zT_426[ri_i];
    zT_428 = zT_427.id;
    zF_26476265_u32ToU32MapPut(zT_419, (unsigned int)((unsigned int)(0) + zT_428), (unsigned int)(1));
    goto z_bb_91;
    z_bb_91:
    goto z_bb_78;
    z_bb_92:
    zT_435 = ctx->global_decls;
    zT_436 = zT_435.len;
    if ((unsigned char)(gt_i < zT_436)) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_439 = ctx->global_decls;
    zT_440 = zT_439.items;
    zT_441 = zT_440[gt_i];
    gt_g = zT_441;
    zT_442 = gt_g.type_id;
    zT_443 = ctx->typereg;
    zT_444 = zT_443->types_len;
    if ((unsigned char)(zT_442 >= (unsigned int)((unsigned int)zT_444))) goto z_bb_96; else goto z_bb_97;
    z_bb_94:
    zT_482 = ctx->alloc;
    zT_480 = &zT_482->emission;
    zT_481 = ri_mods.len;
    zT_486 = zF_619D56E6_u32ToU32MapInitCap(zT_480, zT_481);
    reachable = zT_486;
    zT_487 = &reachable;
    zF_26476265_u32ToU32MapPut(zT_487, (unsigned int)(0), (unsigned int)(1));
    zT_494 = 1;
    rf_changed = zT_494;
    goto z_bb_103;
    z_bb_95:
    zT_478 = gt_i + (unsigned int)(1);
    gt_i = zT_478;
    goto z_bb_92;
    z_bb_96:
    goto z_bb_95;
    z_bb_97:
    zT_448 = ctx->typereg;
    zT_449 = zT_448->types_items;
    zT_450 = gt_g.type_id;
    zT_451 = (unsigned int)zT_450;
    zT_452 = zT_449[zT_451];
    gt_ty = zT_452;
    zT_453 = ctx->typereg;
    zT_457 = &emitter;
    zT_454 = &zT_457->needed_tuple_set;
    zT_455 = gt_g.type_id;
    zF_7845A68F_collectNeededTuples(zT_453, zT_454, zT_455);
    zT_460 = gt_ty.name_id;
    if ((unsigned char)(zT_460 != (unsigned int)(0))) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_464 = gt_ty.name_id;
    zT_465 = gt_g.name_id;
    zT_463 = zT_464 == zT_465;
    goto z_bb_100;
    z_bb_99:
    zT_463 = 0;
    goto z_bb_100;
    z_bb_100:
    if (zT_463) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    goto z_bb_95;
    z_bb_102:
    zT_467 = &ref_edges;
    zT_468 = ctx->typereg;
    zT_469 = &type_visited;
    zT_470 = gt_g.module_id;
    zT_471 = gt_g.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_467, zT_468, zT_469, zT_470, zT_471);
    goto z_bb_95;
    z_bb_103:
    if ((unsigned char)(rf_changed != (unsigned char)(0))) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    zT_497 = 0;
    rf_changed = zT_497;
    zT_499 = 0;
    rf_s = zT_499;
    goto z_bb_107;
    z_bb_105:
    emitter.reachable = reachable;
    zT_546 = ctx->cli;
    zT_547 = zT_546.output_dir_set;
    if (zT_547) goto z_bb_123; else goto z_bb_124;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_501 = ri_mods.len;
    if ((unsigned char)(rf_s < zT_501)) goto z_bb_108; else goto z_bb_109;
    z_bb_108:
    zT_504 = ri_mods.ptr;
    zT_505 = zT_504[rf_s];
    zT_506 = zT_505.id;
    rf_src = zT_506;
    zT_507 = &reachable;
    zT_508 = rf_src;
    zT_510 = zF_F3EE5998_u32ToU32MapGet(zT_507, zT_508);
    zT_511 = zT_510.has_value;
    if ((unsigned char)(!zT_511)) goto z_bb_111; else goto z_bb_112;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    zT_545 = rf_s + (unsigned int)(1);
    rf_s = zT_545;
    goto z_bb_107;
    z_bb_111:
    goto z_bb_110;
    z_bb_112:
    zT_514 = 0;
    rf_d = zT_514;
    goto z_bb_113;
    z_bb_113:
    zT_516 = ri_mods.len;
    if ((unsigned char)(rf_d < zT_516)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_519 = ri_mods.ptr;
    zT_520 = zT_519[rf_d];
    zT_521 = zT_520.id;
    rf_dst = zT_521;
    if ((unsigned char)(rf_dst == rf_src)) goto z_bb_117; else goto z_bb_118;
    z_bb_115:
    goto z_bb_110;
    z_bb_116:
    zT_543 = rf_d + (unsigned int)(1);
    rf_d = zT_543;
    goto z_bb_113;
    z_bb_117:
    goto z_bb_116;
    z_bb_118:
    zT_523 = &reachable;
    zT_524 = rf_dst;
    zT_526 = zF_F3EE5998_u32ToU32MapGet(zT_523, zT_524);
    zT_527 = zT_526.has_value;
    if (zT_527) goto z_bb_119; else goto z_bb_120;
    z_bb_119:
    goto z_bb_116;
    z_bb_120:
    zT_528 = &ref_edges;
    zT_534 = zF_F3EE5998_u32ToU32MapGet(zT_528, (unsigned int)((unsigned int)(rf_src * (unsigned int)(65536)) + rf_dst));
    zT_535 = zT_534.has_value;
    if (zT_535) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_536 = &reachable;
    zT_537 = rf_dst;
    zF_26476265_u32ToU32MapPut(zT_536, zT_537, (unsigned int)(1));
    zT_541 = 1;
    rf_changed = zT_541;
    goto z_bb_122;
    z_bb_122:
    goto z_bb_116;
    z_bb_123:
    zT_549 = 0;
    poi = zT_549;
    goto z_bb_125;
    z_bb_124:
    cwriter = zT_1162;
    zT_1163 = zF_F9E678C3_bufferedWriterInit();
    cwriter = zT_1163;
    zT_1164 = &cwriter;
    zF_225796FB_emitIncludes(zT_1164);
    zT_1166 = &cwriter;
    zF_B35650AD_bufferedWriterFlush(zT_1166);
    zT_1169 = ctx->module_reg;
    zT_1172 = ctx->alloc;
    zT_1170 = &zT_1172->emission;
    zT_1174 = zF_1E2E8788_cincludeUnionAll(zT_1169, zT_1170);
    c_incs = zT_1174;
    zT_1175 = &emitter;
    zT_1176 = module_name;
    zT_1177 = c_incs;
    zT_1178 = ctx->pointer_only_ids;
    zT_1179 = ctx->pointer_only_len;
    zF_503E3056_emitModule(zT_1175, zT_1176, zT_1177, zT_1178, zT_1179);
    zT_1184 = "FINAL_FLUSH\n";
    zT_1186 = 12;
    zT_1185.ptr = zT_1184;
    zT_1185.len = zT_1186;
    ff_m = zT_1185;
    zT_1187 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1187);
    zT_1189 = &emitter;
    zT_1188 = &zT_1189->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1188);
    zT_1191 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1191);
    zT_1193 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1193);
    return;
    z_bb_125:
    zT_550 = ctx->pointer_only_len;
    if ((unsigned char)(poi < zT_550)) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_555 = &emitter;
    zT_552 = &zT_555->pointer_only_map;
    zT_557 = ctx->pointer_only_ids;
    zT_558 = (unsigned int)poi;
    zT_553 = zT_557[zT_558];
    zF_26476265_u32ToU32MapPut(zT_552, zT_553, (unsigned int)(1));
    goto z_bb_128;
    z_bb_127:
    zT_565 = ctx->typereg;
    zT_568 = ctx->alloc;
    zT_566 = &zT_568->emission;
    zT_570 = zF_1DD26D63_tstTopologicalSort(zT_565, zT_566);
    sorted = zT_570;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_572[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hpath[_i] = zT_572[_i];
        _i++;
    }
}
    zT_574 = 0;
    hp = zT_574;
    zT_576 = ctx->cli;
    zT_577 = zT_576.output_dir;
    od = zT_577;
    zT_578 = &emitter;
    zT_579 = od;
    zF_AB1E9CD4_emitSupportFiles(zT_578, zT_579);
    zT_582 = 0;
    hi = zT_582;
    goto z_bb_129;
    z_bb_128:
    zT_561 = 1;
    zT_563 = poi + (unsigned int)((unsigned int)zT_561);
    poi = zT_563;
    goto z_bb_125;
    z_bb_129:
    zT_584 = od.len;
    if ((unsigned char)(hi < zT_584)) goto z_bb_133; else goto z_bb_134;
    z_bb_130:
    zT_589 = od.ptr;
    zT_590 = zT_589[hi];
    hpath[hp] = zT_590;
    zT_591 = 1;
    zT_593 = hp + (unsigned int)((unsigned int)zT_591);
    hp = zT_593;
    goto z_bb_132;
    z_bb_131:
    zT_597 = 47;
    hpath[hp] = zT_597;
    zT_598 = 1;
    zT_600 = hp + (unsigned int)((unsigned int)zT_598);
    hp = zT_600;
    zT_602 = "zig_special_types.h";
    zT_604 = 19;
    zT_603.ptr = zT_602;
    zT_603.len = zT_604;
    hfn = zT_603;
    zT_606 = 0;
    hfi = zT_606;
    goto z_bb_136;
    z_bb_132:
    zT_594 = 1;
    zT_596 = hi + (unsigned int)((unsigned int)zT_594);
    hi = zT_596;
    goto z_bb_129;
    z_bb_133:
    zT_586 = hp < (unsigned int)(510);
    goto z_bb_135;
    z_bb_134:
    zT_586 = 0;
    goto z_bb_135;
    z_bb_135:
    if (zT_586) goto z_bb_130; else goto z_bb_131;
    z_bb_136:
    zT_608 = hfn.len;
    if ((unsigned char)(hfi < zT_608)) goto z_bb_140; else goto z_bb_141;
    z_bb_137:
    zT_613 = hfn.ptr;
    zT_614 = zT_613[hfi];
    hpath[hp] = zT_614;
    zT_615 = 1;
    zT_617 = hp + (unsigned int)((unsigned int)zT_615);
    hp = zT_617;
    goto z_bb_139;
    z_bb_138:
    zT_626 = 0;
    zT_627 = (unsigned char*)((unsigned char*)hpath) + zT_626;
    zT_628 = hp - zT_626;
    zT_629.ptr = zT_627;
    zT_629.len = zT_628;
    zT_622 = zT_629;
    zT_631 = zF_39FE21EF_fileOpen(zT_622, (int)(0));
    fd = zT_631;
    if ((unsigned char)(fd == zG_CC81CC5F_INVALID_FD)) goto z_bb_143; else goto z_bb_144;
    z_bb_139:
    zT_618 = 1;
    zT_620 = hfi + (unsigned int)((unsigned int)zT_618);
    hfi = zT_620;
    goto z_bb_136;
    z_bb_140:
    zT_610 = hp < (unsigned int)(511);
    goto z_bb_142;
    z_bb_141:
    zT_610 = 0;
    goto z_bb_142;
    z_bb_142:
    if (zT_610) goto z_bb_137; else goto z_bb_138;
    z_bb_143:
    zT_635 = "error: cannot open output file\n";
    zT_637 = 31;
    zT_636.ptr = zT_635;
    zT_636.len = zT_637;
    emsg = zT_636;
    zT_638 = emsg;
    zF_E4B2EF19_stderr_write(zT_638);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_144;
    z_bb_144:
    hw = zT_642;
    zT_643 = fd;
    zT_644 = zF_E00097E1_bufferedWriterInitF(zT_643);
    hw = zT_644;
    emitter.writer = hw;
    zT_645 = &emitter;
    zT_646 = ctx->typereg;
    zT_647 = sorted;
    zF_62841416_emitSharedHeader(zT_645, zT_646, zT_647);
    zT_651 = &emitter;
    zT_650 = &zT_651->writer;
    zF_B35650AD_bufferedWriterFlush(zT_650);
    zT_653 = fd;
    zF_B30B1D79_fileClose(zT_653);
    zT_655 = ctx->module_reg;
    zT_657 = zF_3452C137_moduleRegistryGetMo(zT_655);
    mods = zT_657;
    emitter.prune_active = (unsigned char)(1);
    zT_660 = ctx->lir_slots;
    zT_661 = zT_660.len;
    slot_count = zT_661;
    zT_662 = 0;
    if ((unsigned char)(slot_count > (unsigned int)zT_662)) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_668 = ctx->alloc;
    zT_665 = &zT_668->emission;
    zT_672 = mods.len;
    zT_675 = zF_1395EB68_sandAlloc(zT_665, (unsigned int)((unsigned int)(4) * zT_672), (unsigned int)(4));
    zT_676 = zT_675.is_error;
    if (zT_676) goto z_bb_147; else goto z_bb_148;
    z_bb_146:
    zT_776 = 0;
    fn_cursor = zT_776;
    zT_778 = 0;
    mi = zT_778;
    goto z_bb_176;
    z_bb_147:
    pal_trap();
    z_bb_148:
    zT_677 = zT_675.data.payload;
    goto z_bb_149;
    z_bb_149:
    zT_679 = (unsigned int*)zT_677;
    grp_counts = zT_679;
    zT_684 = ctx->alloc;
    zT_681 = &zT_684->emission;
    zT_688 = mods.len;
    zT_691 = zF_1395EB68_sandAlloc(zT_681, (unsigned int)((unsigned int)(4) * zT_688), (unsigned int)(4));
    zT_692 = zT_691.is_error;
    if (zT_692) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    pal_trap();
    z_bb_151:
    zT_693 = zT_691.data.payload;
    goto z_bb_152;
    z_bb_152:
    zT_695 = (unsigned int*)zT_693;
    grp_cursor = zT_695;
    zT_697 = 0;
    gci = zT_697;
    goto z_bb_153;
    z_bb_153:
    zT_699 = mods.len;
    if ((unsigned char)(gci < zT_699)) goto z_bb_154; else goto z_bb_155;
    z_bb_154:
    zT_701 = 0;
    grp_counts[gci] = zT_701;
    goto z_bb_156;
    z_bb_155:
    zT_706 = 0;
    gsi = zT_706;
    goto z_bb_157;
    z_bb_156:
    zT_702 = 1;
    zT_704 = gci + (unsigned int)((unsigned int)zT_702);
    gci = zT_704;
    goto z_bb_153;
    z_bb_157:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_709 = ctx->lir_slots;
    zT_710 = zT_709.items;
    zT_711 = zT_710[gsi];
    zT_712 = zT_711.module_id;
    gsmid = zT_712;
    zT_715 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) < zT_715)) goto z_bb_161; else goto z_bb_162;
    z_bb_159:
    zT_726 = 0;
    gacc = zT_726;
    zT_727 = 0;
    gci = zT_727;
    goto z_bb_163;
    z_bb_160:
    zT_722 = 1;
    zT_724 = gsi + (unsigned int)((unsigned int)zT_722);
    gsi = zT_724;
    goto z_bb_157;
    z_bb_161:
    zT_717 = (unsigned int)gsmid;
    zT_718 = grp_counts[zT_717];
    zT_720 = zT_718 + (unsigned int)(1);
    zT_721 = (unsigned int)gsmid;
    grp_counts[zT_721] = zT_720;
    goto z_bb_162;
    z_bb_162:
    goto z_bb_160;
    z_bb_163:
    zT_729 = mods.len;
    if ((unsigned char)(gci < zT_729)) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    grp_cursor[gci] = gacc;
    zT_731 = grp_counts[gci];
    zT_732 = gacc + zT_731;
    gacc = zT_732;
    goto z_bb_166;
    z_bb_165:
    zT_740 = ctx->alloc;
    zT_737 = &zT_740->emission;
    zT_745 = zF_1395EB68_sandAlloc(zT_737, (unsigned int)((unsigned int)(12) * slot_count), (unsigned int)(4));
    zT_746 = zT_745.is_error;
    if (zT_746) goto z_bb_167; else goto z_bb_168;
    z_bb_166:
    zT_733 = 1;
    zT_735 = gci + (unsigned int)((unsigned int)zT_733);
    gci = zT_735;
    goto z_bb_163;
    z_bb_167:
    pal_trap();
    z_bb_168:
    zT_747 = zT_745.data.payload;
    goto z_bb_169;
    z_bb_169:
    zT_749 = (zT_E7714190_LirSlot*)zT_747;
    grouped = zT_749;
    zT_750 = 0;
    gsi = zT_750;
    goto z_bb_170;
    z_bb_170:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_171; else goto z_bb_172;
    z_bb_171:
    zT_753 = ctx->lir_slots;
    zT_754 = zT_753.items;
    zT_755 = zT_754[gsi];
    gslot = zT_755;
    zT_757 = gslot.module_id;
    gsmid = zT_757;
    zT_760 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) >= zT_760)) goto z_bb_174; else goto z_bb_175;
    z_bb_172:
    zT_772 = &ctx->lir_slots;
    zT_772->items = grouped;
    zT_774 = &ctx->lir_slots;
    zT_774->len = (unsigned int)((unsigned int)gacc);
    emitter.fn_slots = grouped;
    goto z_bb_146;
    z_bb_173:
    zT_769 = 1;
    zT_771 = gsi + (unsigned int)((unsigned int)zT_769);
    gsi = zT_771;
    goto z_bb_170;
    z_bb_174:
    goto z_bb_173;
    z_bb_175:
    zT_763 = (unsigned int)gsmid;
    zT_764 = grp_cursor[zT_763];
    gdst = zT_764;
    zT_765 = (unsigned int)gdst;
    grouped[zT_765] = gslot;
    zT_767 = gdst + (unsigned int)(1);
    zT_768 = (unsigned int)gsmid;
    grp_cursor[zT_768] = zT_767;
    goto z_bb_173;
    z_bb_176:
    zT_780 = mods.len;
    if ((unsigned char)(mi < zT_780)) goto z_bb_177; else goto z_bb_178;
    z_bb_177:
    zT_783 = mods.ptr;
    zT_784 = zT_783[mi];
    m = zT_784;
    fn_start = fn_cursor;
    goto z_bb_180;
    z_bb_178:
    zT_1151 = &emitter;
    zT_1152 = od;
    zT_1155 = ctx->cli;
    zT_1153 = zT_1155.target_is_windows;
    zF_A62DB57E_emitBuildScripts(zT_1151, zT_1152, zT_1153);
    zT_1157 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1157);
    zT_1159 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1159);
    return;
    z_bb_179:
    zT_1148 = 1;
    zT_1150 = mi + (unsigned int)((unsigned int)zT_1148);
    mi = zT_1150;
    goto z_bb_176;
    z_bb_180:
    zT_786 = ctx->lir_slots;
    zT_787 = zT_786.len;
    if ((unsigned char)(fn_cursor < zT_787)) goto z_bb_184; else goto z_bb_185;
    z_bb_181:
    goto z_bb_183;
    z_bb_182:
    zT_798 = &reachable;
    zT_799 = m.id;
    zT_802 = zF_F3EE5998_u32ToU32MapGet(zT_798, zT_799);
    zT_803 = zT_802.has_value;
    if ((unsigned char)(!zT_803)) goto z_bb_187; else goto z_bb_188;
    z_bb_183:
    zT_797 = fn_cursor + (unsigned int)(1);
    fn_cursor = zT_797;
    goto z_bb_180;
    z_bb_184:
    zT_790 = ctx->lir_slots;
    zT_791 = zT_790.items;
    zT_792 = zT_791[fn_cursor];
    zT_793 = zT_792.module_id;
    zT_794 = m.id;
    zT_789 = zT_793 == zT_794;
    goto z_bb_186;
    z_bb_185:
    zT_789 = 0;
    goto z_bb_186;
    z_bb_186:
    if (zT_789) goto z_bb_181; else goto z_bb_182;
    z_bb_187:
    goto z_bb_179;
    z_bb_188:
    emitter.fn_slots_start = fn_start;
    emitter.fn_slots_len = (unsigned int)(fn_cursor - fn_start);
    zT_807 = &emitter;
    zT_808 = m.id;
    zT_811 = zF_E295413A_moduleQualifiedName(zT_807, zT_808);
    base = zT_811;
    zT_813 = od.len;
    zT_817 = base.len;
    if ((unsigned char)((unsigned int)((unsigned int)((unsigned int)(zT_813 + (unsigned int)(1)) + zT_817) + (unsigned int)(3)) > (unsigned int)(511))) goto z_bb_189; else goto z_bb_190;
    z_bb_189:
    zT_824 = "error: output filename too long\n";
    zT_826 = 32;
    zT_825.ptr = zT_824;
    zT_825.len = zT_826;
    lmsg = zT_825;
    zT_827 = lmsg;
    zF_E4B2EF19_stderr_write(zT_827);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_190;
    z_bb_190:
    zT_831 = 0;
    hp2 = zT_831;
    zT_833 = 0;
    hi2 = zT_833;
    goto z_bb_191;
    z_bb_191:
    zT_835 = od.len;
    if ((unsigned char)(hi2 < zT_835)) goto z_bb_195; else goto z_bb_196;
    z_bb_192:
    zT_840 = od.ptr;
    zT_841 = zT_840[hi2];
    hpath[hp2] = zT_841;
    zT_842 = 1;
    zT_844 = hp2 + (unsigned int)((unsigned int)zT_842);
    hp2 = zT_844;
    goto z_bb_194;
    z_bb_193:
    zT_848 = 47;
    hpath[hp2] = zT_848;
    zT_849 = 1;
    zT_851 = hp2 + (unsigned int)((unsigned int)zT_849);
    hp2 = zT_851;
    zT_853 = 0;
    bi = zT_853;
    goto z_bb_198;
    z_bb_194:
    zT_845 = 1;
    zT_847 = hi2 + (unsigned int)((unsigned int)zT_845);
    hi2 = zT_847;
    goto z_bb_191;
    z_bb_195:
    zT_837 = hp2 < (unsigned int)(510);
    goto z_bb_197;
    z_bb_196:
    zT_837 = 0;
    goto z_bb_197;
    z_bb_197:
    if (zT_837) goto z_bb_192; else goto z_bb_193;
    z_bb_198:
    zT_855 = base.len;
    if ((unsigned char)(bi < zT_855)) goto z_bb_202; else goto z_bb_203;
    z_bb_199:
    zT_860 = base.ptr;
    zT_861 = zT_860[bi];
    hpath[hp2] = zT_861;
    zT_862 = 1;
    zT_864 = hp2 + (unsigned int)((unsigned int)zT_862);
    hp2 = zT_864;
    goto z_bb_201;
    z_bb_200:
    zT_869 = ".h";
    zT_871 = 2;
    zT_870.ptr = zT_869;
    zT_870.len = zT_871;
    hext = zT_870;
    zT_873 = 0;
    hx = zT_873;
    goto z_bb_205;
    z_bb_201:
    zT_865 = 1;
    zT_867 = bi + (unsigned int)((unsigned int)zT_865);
    bi = zT_867;
    goto z_bb_198;
    z_bb_202:
    zT_857 = hp2 < (unsigned int)(510);
    goto z_bb_204;
    z_bb_203:
    zT_857 = 0;
    goto z_bb_204;
    z_bb_204:
    if (zT_857) goto z_bb_199; else goto z_bb_200;
    z_bb_205:
    zT_875 = hext.len;
    if ((unsigned char)(hx < zT_875)) goto z_bb_209; else goto z_bb_210;
    z_bb_206:
    zT_880 = hext.ptr;
    zT_881 = zT_880[hx];
    hpath[hp2] = zT_881;
    zT_882 = 1;
    zT_884 = hp2 + (unsigned int)((unsigned int)zT_882);
    hp2 = zT_884;
    goto z_bb_208;
    z_bb_207:
    zT_893 = 0;
    zT_894 = (unsigned char*)((unsigned char*)hpath) + zT_893;
    zT_895 = hp2 - zT_893;
    zT_896.ptr = zT_894;
    zT_896.len = zT_895;
    zT_889 = zT_896;
    zT_898 = zF_39FE21EF_fileOpen(zT_889, (int)(0));
    fd2 = zT_898;
    if ((unsigned char)(fd2 == zG_CC81CC5F_INVALID_FD)) goto z_bb_212; else goto z_bb_213;
    z_bb_208:
    zT_885 = 1;
    zT_887 = hx + (unsigned int)((unsigned int)zT_885);
    hx = zT_887;
    goto z_bb_205;
    z_bb_209:
    zT_877 = hp2 < (unsigned int)(511);
    goto z_bb_211;
    z_bb_210:
    zT_877 = 0;
    goto z_bb_211;
    z_bb_211:
    if (zT_877) goto z_bb_206; else goto z_bb_207;
    z_bb_212:
    zT_902 = "error: cannot open output file\n";
    zT_904 = 31;
    zT_903.ptr = zT_902;
    zT_903.len = zT_904;
    emsg2 = zT_903;
    zT_905 = emsg2;
    zF_E4B2EF19_stderr_write(zT_905);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_213;
    z_bb_213:
    hw2 = zT_909;
    zT_910 = fd2;
    zT_911 = zF_E00097E1_bufferedWriterInitF(zT_910);
    hw2 = zT_911;
    emitter.writer = hw2;
    zT_913 = m.imports_start;
    zT_914 = (unsigned int)zT_913;
    dep_start = zT_914;
    zT_916 = m.import_count;
    zT_918 = dep_start + (unsigned int)((unsigned int)zT_916);
    dep_end = zT_918;
    zT_920 = ctx->module_reg;
    zT_921 = zT_920->import_edges_items;
    zT_922 = zT_921 + dep_start;
    zT_923 = dep_end - dep_start;
    zT_924.ptr = zT_922;
    zT_924.len = zT_923;
    dep_ids = zT_924;
    zT_926 = m.c_includes;
    zT_927 = zT_926.items;
    zT_928 = m.c_includes;
    zT_929 = zT_928.len;
    zT_930 = 0;
    zT_931 = zT_927 + zT_930;
    zT_932 = zT_929 - zT_930;
    zT_933.ptr = zT_931;
    zT_933.len = zT_932;
    m_c_incs = zT_933;
    zT_938 = ctx->alloc;
    zT_935 = &zT_938->emission;
    zT_942 = mods.len;
    zT_945 = zF_1395EB68_sandAlloc(zT_935, (unsigned int)((unsigned int)(4) * zT_942), (unsigned int)(4));
    zT_946 = zT_945.is_error;
    if (zT_946) goto z_bb_214; else goto z_bb_215;
    z_bb_214:
    pal_trap();
    z_bb_215:
    zT_947 = zT_945.data.payload;
    goto z_bb_216;
    z_bb_216:
    inc_raw = zT_947;
    zT_950 = (unsigned int*)inc_raw;
    inc_arr = zT_950;
    zT_952 = 0;
    inc_n = zT_952;
    zT_954 = 0;
    di0 = zT_954;
    goto z_bb_217;
    z_bb_217:
    zT_956 = dep_ids.len;
    if ((unsigned char)(di0 < zT_956)) goto z_bb_218; else goto z_bb_219;
    z_bb_218:
    zT_959 = dep_ids.ptr;
    zT_960 = zT_959[di0];
    dd0 = zT_960;
    zT_961 = m.id;
    if ((unsigned char)(dd0 == zT_961)) goto z_bb_221; else goto z_bb_222;
    z_bb_219:
    zT_986 = 0;
    vd0 = zT_986;
    goto z_bb_233;
    z_bb_220:
    zT_984 = di0 + (unsigned int)(1);
    di0 = zT_984;
    goto z_bb_217;
    z_bb_221:
    goto z_bb_220;
    z_bb_222:
    zT_963 = &reachable;
    zT_964 = dd0;
    zT_966 = zF_F3EE5998_u32ToU32MapGet(zT_963, zT_964);
    zT_967 = zT_966.has_value;
    if ((unsigned char)(!zT_967)) goto z_bb_223; else goto z_bb_224;
    z_bb_223:
    goto z_bb_220;
    z_bb_224:
    zT_970 = 0;
    dup0 = zT_970;
    zT_972 = 0;
    dj0 = zT_972;
    goto z_bb_225;
    z_bb_225:
    if ((unsigned char)(dj0 < inc_n)) goto z_bb_226; else goto z_bb_227;
    z_bb_226:
    zT_974 = inc_arr[dj0];
    if ((unsigned char)(zT_974 == dd0)) goto z_bb_229; else goto z_bb_230;
    z_bb_227:
    if ((unsigned char)(dup0 != (unsigned char)(0))) goto z_bb_231; else goto z_bb_232;
    z_bb_228:
    zT_978 = dj0 + (unsigned int)(1);
    dj0 = zT_978;
    goto z_bb_225;
    z_bb_229:
    zT_976 = 1;
    dup0 = zT_976;
    goto z_bb_227;
    z_bb_230:
    goto z_bb_228;
    z_bb_231:
    goto z_bb_220;
    z_bb_232:
    inc_arr[inc_n] = dd0;
    zT_982 = inc_n + (unsigned int)(1);
    inc_n = zT_982;
    goto z_bb_220;
    z_bb_233:
    zT_988 = mods.len;
    if ((unsigned char)(vd0 < zT_988)) goto z_bb_234; else goto z_bb_235;
    z_bb_234:
    zT_991 = mods.ptr;
    zT_992 = zT_991[vd0];
    zT_993 = zT_992.id;
    vdd0 = zT_993;
    zT_994 = m.id;
    if ((unsigned char)(vdd0 == zT_994)) goto z_bb_237; else goto z_bb_238;
    z_bb_235:
    zT_1029 = 0;
    zT_1030 = inc_arr + zT_1029;
    zT_1031 = inc_n - zT_1029;
    zT_1032.ptr = zT_1030;
    zT_1032.len = zT_1031;
    inc_slice = zT_1032;
    zT_1033 = &emitter;
    zT_1034 = m.id;
    zT_1035 = base;
    zT_1036 = m_c_incs;
    zT_1037 = inc_slice;
    zT_1038 = sorted;
    zF_1AF3E3A9_emitModuleHeaderFil(zT_1033, zT_1034, zT_1035, zT_1036, zT_1037, zT_1038);
    zT_1042 = &emitter;
    zT_1041 = &zT_1042->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1041);
    zT_1044 = fd2;
    zF_B30B1D79_fileClose(zT_1044);
    zT_1046 = "FINAL_FLUSH\n";
    zT_1048 = 12;
    zT_1047.ptr = zT_1046;
    zT_1047.len = zT_1048;
    ff_m = zT_1047;
    zT_1049 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1049);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_1051[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        cpath[_i] = zT_1051[_i];
        _i++;
    }
}
    zT_1053 = 0;
    cp2 = zT_1053;
    zT_1055 = 0;
    ci2 = zT_1055;
    goto z_bb_251;
    z_bb_236:
    zT_1027 = vd0 + (unsigned int)(1);
    vd0 = zT_1027;
    goto z_bb_233;
    z_bb_237:
    goto z_bb_236;
    z_bb_238:
    zT_996 = &reachable;
    zT_997 = vdd0;
    zT_999 = zF_F3EE5998_u32ToU32MapGet(zT_996, zT_997);
    zT_1000 = zT_999.has_value;
    if ((unsigned char)(!zT_1000)) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    goto z_bb_236;
    z_bb_240:
    zT_1002 = &ref_edges;
    zT_1005 = m.id;
    zT_1009 = zF_F3EE5998_u32ToU32MapGet(zT_1002, (unsigned int)((unsigned int)(zT_1005 * (unsigned int)(65536)) + vdd0));
    zT_1010 = zT_1009.has_value;
    if ((unsigned char)(!zT_1010)) goto z_bb_241; else goto z_bb_242;
    z_bb_241:
    goto z_bb_236;
    z_bb_242:
    zT_1013 = 0;
    dup1 = zT_1013;
    zT_1015 = 0;
    dj1 = zT_1015;
    goto z_bb_243;
    z_bb_243:
    if ((unsigned char)(dj1 < inc_n)) goto z_bb_244; else goto z_bb_245;
    z_bb_244:
    zT_1017 = inc_arr[dj1];
    if ((unsigned char)(zT_1017 == vdd0)) goto z_bb_247; else goto z_bb_248;
    z_bb_245:
    if ((unsigned char)(dup1 != (unsigned char)(0))) goto z_bb_249; else goto z_bb_250;
    z_bb_246:
    zT_1021 = dj1 + (unsigned int)(1);
    dj1 = zT_1021;
    goto z_bb_243;
    z_bb_247:
    zT_1019 = 1;
    dup1 = zT_1019;
    goto z_bb_245;
    z_bb_248:
    goto z_bb_246;
    z_bb_249:
    goto z_bb_236;
    z_bb_250:
    inc_arr[inc_n] = vdd0;
    zT_1025 = inc_n + (unsigned int)(1);
    inc_n = zT_1025;
    goto z_bb_236;
    z_bb_251:
    zT_1057 = od.len;
    if ((unsigned char)(ci2 < zT_1057)) goto z_bb_255; else goto z_bb_256;
    z_bb_252:
    zT_1062 = od.ptr;
    zT_1063 = zT_1062[ci2];
    cpath[cp2] = zT_1063;
    zT_1064 = 1;
    zT_1066 = cp2 + (unsigned int)((unsigned int)zT_1064);
    cp2 = zT_1066;
    goto z_bb_254;
    z_bb_253:
    zT_1070 = 47;
    cpath[cp2] = zT_1070;
    zT_1071 = 1;
    zT_1073 = cp2 + (unsigned int)((unsigned int)zT_1071);
    cp2 = zT_1073;
    zT_1075 = 0;
    cbi = zT_1075;
    goto z_bb_258;
    z_bb_254:
    zT_1067 = 1;
    zT_1069 = ci2 + (unsigned int)((unsigned int)zT_1067);
    ci2 = zT_1069;
    goto z_bb_251;
    z_bb_255:
    zT_1059 = cp2 < (unsigned int)(510);
    goto z_bb_257;
    z_bb_256:
    zT_1059 = 0;
    goto z_bb_257;
    z_bb_257:
    if (zT_1059) goto z_bb_252; else goto z_bb_253;
    z_bb_258:
    zT_1077 = base.len;
    if ((unsigned char)(cbi < zT_1077)) goto z_bb_262; else goto z_bb_263;
    z_bb_259:
    zT_1082 = base.ptr;
    zT_1083 = zT_1082[cbi];
    cpath[cp2] = zT_1083;
    zT_1084 = 1;
    zT_1086 = cp2 + (unsigned int)((unsigned int)zT_1084);
    cp2 = zT_1086;
    goto z_bb_261;
    z_bb_260:
    zT_1091 = ".c";
    zT_1093 = 2;
    zT_1092.ptr = zT_1091;
    zT_1092.len = zT_1093;
    cext = zT_1092;
    zT_1095 = 0;
    cx = zT_1095;
    goto z_bb_265;
    z_bb_261:
    zT_1087 = 1;
    zT_1089 = cbi + (unsigned int)((unsigned int)zT_1087);
    cbi = zT_1089;
    goto z_bb_258;
    z_bb_262:
    zT_1079 = cp2 < (unsigned int)(510);
    goto z_bb_264;
    z_bb_263:
    zT_1079 = 0;
    goto z_bb_264;
    z_bb_264:
    if (zT_1079) goto z_bb_259; else goto z_bb_260;
    z_bb_265:
    zT_1097 = cext.len;
    if ((unsigned char)(cx < zT_1097)) goto z_bb_269; else goto z_bb_270;
    z_bb_266:
    zT_1102 = cext.ptr;
    zT_1103 = zT_1102[cx];
    cpath[cp2] = zT_1103;
    zT_1104 = 1;
    zT_1106 = cp2 + (unsigned int)((unsigned int)zT_1104);
    cp2 = zT_1106;
    goto z_bb_268;
    z_bb_267:
    zT_1115 = 0;
    zT_1116 = (unsigned char*)((unsigned char*)cpath) + zT_1115;
    zT_1117 = cp2 - zT_1115;
    zT_1118.ptr = zT_1116;
    zT_1118.len = zT_1117;
    zT_1111 = zT_1118;
    zT_1120 = zF_39FE21EF_fileOpen(zT_1111, (int)(0));
    cfd = zT_1120;
    if ((unsigned char)(cfd == zG_CC81CC5F_INVALID_FD)) goto z_bb_272; else goto z_bb_273;
    z_bb_268:
    zT_1107 = 1;
    zT_1109 = cx + (unsigned int)((unsigned int)zT_1107);
    cx = zT_1109;
    goto z_bb_265;
    z_bb_269:
    zT_1099 = cp2 < (unsigned int)(511);
    goto z_bb_271;
    z_bb_270:
    zT_1099 = 0;
    goto z_bb_271;
    z_bb_271:
    if (zT_1099) goto z_bb_266; else goto z_bb_267;
    z_bb_272:
    zT_1124 = "error: cannot open output file\n";
    zT_1126 = 31;
    zT_1125.ptr = zT_1124;
    zT_1125.len = zT_1126;
    emsg3 = zT_1125;
    zT_1127 = emsg3;
    zF_E4B2EF19_stderr_write(zT_1127);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_273;
    z_bb_273:
    cw = zT_1131;
    zT_1132 = cfd;
    zT_1133 = zF_E00097E1_bufferedWriterInitF(zT_1132);
    cw = zT_1133;
    emitter.writer = cw;
    zT_1134 = &emitter;
    zT_1135 = m.id;
    zT_1136 = base;
    zF_7B8B9B90_emitModuleFile(zT_1134, zT_1135, zT_1136);
    zT_1140 = &emitter;
    zT_1139 = &zT_1140->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1139);
    zT_1142 = cfd;
    zF_B30B1D79_fileClose(zT_1142);
    zT_1144 = "FINAL_FLUSH\n";
    zT_1146 = 12;
    zT_1145.ptr = zT_1144;
    zT_1145.len = zT_1146;
    ff2_m = zT_1145;
    zT_1147 = ff2_m;
    zF_48AC7B3A_markerWrite(zT_1147);
    goto z_bb_179;
}

/* parseArgs */
zT_C98AF326_CompilerCli zF_6143A521_parseArgs(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_C98AF326_CompilerCli zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_CAF40AAB_ColorMode zT_18;
    zT_A4FB690E_ErrorFormat zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    int zT_35 = 0;
    int zT_37;
    int zT_38;
    unsigned char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    unsigned char* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    unsigned char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    unsigned char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    unsigned char* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    unsigned char* zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int zT_102;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    unsigned char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    unsigned char* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    unsigned char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    unsigned char* zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    unsigned char* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    unsigned char* zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    int zT_181;
    unsigned char* zT_182 = 0;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185 = {0};
    unsigned int zT_187;
    int zT_188;
    unsigned char zT_190;
    unsigned char* zT_191;
    int zT_192;
    unsigned char zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned char zT_198 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned char zT_202 = 0;
    unsigned char zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned char zT_206 = 0;
    int zT_207;
    int zT_209;
    unsigned char* zT_211;
    int zT_212;
    unsigned char* zT_213 = 0;
    unsigned int zT_214 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char zT_216 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned char* zT_218;
    unsigned int zT_219;
    int zT_220;
    unsigned char* zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned char zT_226 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned char* zT_228;
    unsigned int zT_229;
    int zT_230;
    unsigned char* zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned char zT_237 = 0;
    unsigned char zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_240;
    unsigned char zT_241 = 0;
    int zT_242;
    int zT_244;
    unsigned char* zT_246;
    int zT_247;
    unsigned char* zT_248 = 0;
    unsigned int zT_249 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned char zT_252 = 0;
    unsigned char zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char zT_256 = 0;
    int zT_257;
    int zT_259;
    unsigned char* zT_261;
    int zT_262;
    unsigned char* zT_263 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned char zT_268 = 0;
    unsigned char zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned char zT_272 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned char zT_276 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char zT_280 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned char zT_284 = 0;
    unsigned char zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned char zT_288 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned char zT_292 = 0;
    int zT_293;
    int zT_295;
    unsigned char* zT_297;
    int zT_298;
    unsigned char* zT_299 = 0;
    zT_CAF40AAB_ColorMode zT_300 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned char zT_303 = 0;
    int zT_304;
    int zT_306;
    unsigned char* zT_308;
    int zT_309;
    unsigned char* zT_310 = 0;
    zT_A4FB690E_ErrorFormat zT_311 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    unsigned char zT_314 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_317;
    unsigned char zT_318 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_321;
    unsigned char zT_322 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned char zT_326 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    unsigned char zT_330 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned char zT_334 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned char zT_339 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned char zT_343 = 0;
    unsigned char zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    unsigned char zT_347 = 0;
    int zT_348;
    int zT_350;
    unsigned char zT_352;
    unsigned int zT_353;
    int zT_354;
    unsigned char* zT_356;
    int zT_357;
    unsigned char* zT_358 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    unsigned int zT_363;
    int zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    unsigned char zT_369 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_372;
    unsigned char zT_373 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    unsigned char zT_377 = 0;
    int zT_378;
    int zT_380;
    unsigned char* zT_382;
    int zT_383;
    unsigned char* zT_384 = 0;
    unsigned char zT_385 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned char zT_388 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    unsigned char zT_392 = 0;
    unsigned char* zT_394;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_395 = {0};
    unsigned char* zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397 = {0};
    int zT_398;
    int zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u dot_str;
    zT_C98AF326_CompilerCli cli;
    int argc;
    int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dump_c89;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_mem;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_errors;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_output_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_quiet;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sanity_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warnings;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_color;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_error_format;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_track_memory;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_lifetime;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_leak;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_all;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_error;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_markers;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_include;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_lib_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_o;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_q;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_W;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osw;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fsafe;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ffast;
    unsigned char* arg_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u arg;
    zT_1 = "";
    zT_3 = 0;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    empty_str = zT_2;
    zT_5 = ".";
    zT_7 = 1;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    dot_str = zT_6;
    zT_9.input_file = empty_str;
    zT_9.output_dir = dot_str;
    zT_10 = 0;
    zT_9.output_dir_set = zT_10;
    zT_11 = 0;
    zT_9.dump_types = zT_11;
    zT_12 = 0;
    zT_9.dump_lir = zT_12;
    zT_13 = 0;
    zT_9.dump_c89 = zT_13;
    zT_15 = (unsigned int)zG_18AE3D2F_DEFAULT_MAX_MEM_KB;
    zT_9.max_mem = zT_15;
    zT_16 = 0;
    zT_9.spill_level = zT_16;
    zT_17 = 256;
    zT_9.max_errors = zT_17;
    zT_18 = zT_CAF40AAB_ColorMode_auto;
    zT_9.color = zT_18;
    zT_19 = zT_A4FB690E_ErrorFormat_human;
    zT_9.error_format = zT_19;
    zT_20 = 0;
    zT_9.warnings_as_errors = zT_20;
    zT_21 = 0;
    zT_9.quiet = zT_21;
    zT_22 = 0;
    zT_9.test_mode = zT_22;
    zT_23 = 0;
    zT_9.sanity_test_mode = zT_23;
    zT_24 = 0;
    zT_9.track_memory = zT_24;
    zT_25 = 0;
    zT_9.no_null_check = zT_25;
    zT_26 = 0;
    zT_9.no_lifetime_check = zT_26;
    zT_27 = 0;
    zT_9.no_leak_check = zT_27;
    zT_28 = 1;
    zT_9.safe_checks = zT_28;
    zT_29 = 0;
    zT_9.warn_all = zT_29;
    zT_30 = 0;
    zT_9.warn_error = zT_30;
    zT_31 = 0;
    zT_9.show_markers = zT_31;
    zT_32 = 0;
    zT_9.include_count = zT_32;
    zT_33 = 0;
    zT_9.target_is_windows = zT_33;
    cli = zT_9;
    zT_35 = zF_EEF840BE_argCount();
    argc = zT_35;
    zT_37 = 1;
    zT_38 = (int)zT_37;
    i = zT_38;
    zT_48 = "--dump-c89";
    zT_50 = 10;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    s_dump_c89 = zT_49;
    zT_52 = "--max-mem";
    zT_54 = 9;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    s_max_mem = zT_53;
    zT_56 = "--max-errors";
    zT_58 = 12;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    s_max_errors = zT_57;
    zT_60 = "--output-dir";
    zT_62 = 12;
    zT_61.ptr = zT_60;
    zT_61.len = zT_62;
    s_output_dir = zT_61;
    zT_64 = "--quiet";
    zT_66 = 7;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    s_quiet = zT_65;
    zT_68 = "--test";
    zT_70 = 6;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    s_test = zT_69;
    zT_72 = "--sanity-test";
    zT_74 = 13;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    s_sanity_test = zT_73;
    zT_76 = "--warnings-as-errors";
    zT_78 = 20;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    s_warnings = zT_77;
    zT_80 = "--color";
    zT_82 = 7;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    s_color = zT_81;
    zT_84 = "--error-format";
    zT_86 = 14;
    zT_85.ptr = zT_84;
    zT_85.len = zT_86;
    s_error_format = zT_85;
    zT_88 = "--track-memory";
    zT_90 = 14;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    s_track_memory = zT_89;
    zT_92 = "--no-null-check";
    zT_94 = 15;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    s_no_null = zT_93;
    zT_96 = "--no-lifetime-check";
    zT_98 = 19;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    s_no_lifetime = zT_97;
    zT_100 = "--no-leak-check";
    zT_102 = 15;
    zT_101.ptr = zT_100;
    zT_101.len = zT_102;
    s_no_leak = zT_101;
    zT_104 = "--warn-all";
    zT_106 = 10;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    s_warn_all = zT_105;
    zT_108 = "--warn-error";
    zT_110 = 12;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    s_warn_error = zT_109;
    zT_112 = "--markers";
    zT_114 = 9;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    s_markers = zT_113;
    zT_116 = "-I";
    zT_118 = 2;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    s_include = zT_117;
    zT_120 = "--lib-dir";
    zT_122 = 9;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    s_lib_dir = zT_121;
    zT_140 = "-m";
    zT_142 = 2;
    zT_141.ptr = zT_140;
    zT_141.len = zT_142;
    s_m = zT_141;
    zT_144 = "-e";
    zT_146 = 2;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    s_e = zT_145;
    zT_148 = "-o";
    zT_150 = 2;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    s_o = zT_149;
    zT_152 = "-q";
    zT_154 = 2;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    s_q = zT_153;
    zT_156 = "-W";
    zT_158 = 2;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    s_W = zT_157;
    zT_160 = "-osl";
    zT_162 = 4;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    s_osl = zT_161;
    zT_164 = "-osw";
    zT_166 = 4;
    zT_165.ptr = zT_164;
    zT_165.len = zT_166;
    s_osw = zT_165;
    zT_168 = "--target";
    zT_170 = 8;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    s_target = zT_169;
    zT_172 = "-fsafe";
    zT_174 = 6;
    zT_173.ptr = zT_172;
    zT_173.len = zT_174;
    s_fsafe = zT_173;
    zT_176 = "-ffast";
    zT_178 = 6;
    zT_177.ptr = zT_176;
    zT_177.len = zT_178;
    s_ffast = zT_177;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < argc)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_181 = i;
    zT_182 = zF_70B5BFF1_argGet(zT_181);
    arg_ptr = zT_182;
    zT_184 = arg_ptr;
    zT_185 = zF_22D0470E_cstrToSlice(zT_184);
    arg = zT_185;
    zT_187 = arg.len;
    zT_188 = 0;
    if ((unsigned char)(zT_187 > (unsigned int)zT_188)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cli;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_191 = arg.ptr;
    zT_192 = 0;
    zT_193 = zT_191[zT_192];
    zT_190 = zT_193 == (unsigned char)(45);
    goto z_bb_7;
    z_bb_6:
    zT_190 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_190) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_196 = arg;
    zT_197 = s_dump_c89;
    zT_198 = zF_5FE51158_matchFlag(zT_196, zT_197);
    if (zT_198) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_398 = 1;
    zT_400 = i + (int)((int)zT_398);
    i = zT_400;
    goto z_bb_4;
    z_bb_10:
    zT_396 = arg_ptr;
    zT_397 = zF_22D0470E_cstrToSlice(zT_396);
    cli.input_file = zT_397;
    goto z_bb_9;
    z_bb_11:
    cli.dump_c89 = (unsigned char)(1);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_200 = arg;
    zT_201 = s_max_mem;
    zT_202 = zF_5FE51158_matchFlag(zT_200, zT_201);
    if (zT_202) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_204 = arg;
    zT_205 = s_m;
    zT_206 = zF_5FE51158_matchFlag(zT_204, zT_205);
    zT_203 = zT_206;
    goto z_bb_16;
    z_bb_15:
    zT_203 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_203) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_207 = 1;
    zT_209 = i + (int)((int)zT_207);
    i = zT_209;
    if ((unsigned char)(i < argc)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    goto z_bb_12;
    z_bb_19:
    zT_215 = arg;
    zT_216 = zF_FBF91F7E_matchMMFlag(zT_215);
    if (zT_216) goto z_bb_22; else goto z_bb_24;
    z_bb_20:
    zT_212 = i;
    zT_213 = zF_70B5BFF1_argGet(zT_212);
    zT_211 = zT_213;
    zT_214 = zF_6CF11065_parseSize(zT_211);
    cli.max_mem = zT_214;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_218 = arg.ptr;
    zT_219 = arg.len;
    zT_220 = 3;
    zT_221 = zT_218 + zT_220;
    zT_222 = zT_219 - zT_220;
    zT_223.ptr = zT_221;
    zT_223.len = zT_222;
    zT_217 = zT_223;
    zT_224 = zF_B9231BB9_parseMMBytes(zT_217);
    cli.max_mem = zT_224;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_18;
    z_bb_24:
    zT_225 = arg;
    zT_226 = zF_C4E3C361_matchSFlag(zT_225);
    if (zT_226) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    zT_228 = arg.ptr;
    zT_229 = arg.len;
    zT_230 = 2;
    zT_231 = zT_228 + zT_230;
    zT_232 = zT_229 - zT_230;
    zT_233.ptr = zT_231;
    zT_233.len = zT_232;
    zT_227 = zT_233;
    zT_234 = zF_153C3795_parseSLevel(zT_227);
    cli.spill_level = zT_234;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_235 = arg;
    zT_236 = s_max_errors;
    zT_237 = zF_5FE51158_matchFlag(zT_235, zT_236);
    if (zT_237) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_239 = arg;
    zT_240 = s_e;
    zT_241 = zF_5FE51158_matchFlag(zT_239, zT_240);
    zT_238 = zT_241;
    goto z_bb_30;
    z_bb_29:
    zT_238 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_238) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_242 = 1;
    zT_244 = i + (int)((int)zT_242);
    i = zT_244;
    if ((unsigned char)(i < argc)) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    goto z_bb_26;
    z_bb_33:
    zT_250 = arg;
    zT_251 = s_output_dir;
    zT_252 = zF_5FE51158_matchFlag(zT_250, zT_251);
    if (zT_252) goto z_bb_37; else goto z_bb_36;
    z_bb_34:
    zT_247 = i;
    zT_248 = zF_70B5BFF1_argGet(zT_247);
    zT_246 = zT_248;
    zT_249 = zF_16BBA09E_parseU32(zT_246);
    cli.max_errors = zT_249;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_254 = arg;
    zT_255 = s_o;
    zT_256 = zF_5FE51158_matchFlag(zT_254, zT_255);
    zT_253 = zT_256;
    goto z_bb_38;
    z_bb_37:
    zT_253 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_253) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_257 = 1;
    zT_259 = i + (int)((int)zT_257);
    i = zT_259;
    if ((unsigned char)(i < argc)) goto z_bb_42; else goto z_bb_43;
    z_bb_40:
    goto z_bb_32;
    z_bb_41:
    zT_266 = arg;
    zT_267 = s_quiet;
    zT_268 = zF_5FE51158_matchFlag(zT_266, zT_267);
    if (zT_268) goto z_bb_45; else goto z_bb_44;
    z_bb_42:
    zT_262 = i;
    zT_263 = zF_70B5BFF1_argGet(zT_262);
    zT_261 = zT_263;
    zT_264 = zF_22D0470E_cstrToSlice(zT_261);
    cli.output_dir = zT_264;
    cli.output_dir_set = (unsigned char)(1);
    goto z_bb_43;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_270 = arg;
    zT_271 = s_q;
    zT_272 = zF_5FE51158_matchFlag(zT_270, zT_271);
    zT_269 = zT_272;
    goto z_bb_46;
    z_bb_45:
    zT_269 = 1;
    goto z_bb_46;
    z_bb_46:
    if (zT_269) goto z_bb_47; else goto z_bb_49;
    z_bb_47:
    cli.quiet = (unsigned char)(1);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_40;
    z_bb_49:
    zT_274 = arg;
    zT_275 = s_test;
    zT_276 = zF_5FE51158_matchFlag(zT_274, zT_275);
    if (zT_276) goto z_bb_50; else goto z_bb_52;
    z_bb_50:
    cli.test_mode = (unsigned char)(1);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
    z_bb_52:
    zT_278 = arg;
    zT_279 = s_sanity_test;
    zT_280 = zF_5FE51158_matchFlag(zT_278, zT_279);
    if (zT_280) goto z_bb_53; else goto z_bb_55;
    z_bb_53:
    cli.sanity_test_mode = (unsigned char)(1);
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_282 = arg;
    zT_283 = s_warnings;
    zT_284 = zF_5FE51158_matchFlag(zT_282, zT_283);
    if (zT_284) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_286 = arg;
    zT_287 = s_W;
    zT_288 = zF_5FE51158_matchFlag(zT_286, zT_287);
    zT_285 = zT_288;
    goto z_bb_58;
    z_bb_57:
    zT_285 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_285) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    cli.warnings_as_errors = (unsigned char)(1);
    goto z_bb_60;
    z_bb_60:
    goto z_bb_54;
    z_bb_61:
    zT_290 = arg;
    zT_291 = s_color;
    zT_292 = zF_5FE51158_matchFlag(zT_290, zT_291);
    if (zT_292) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    zT_293 = 1;
    zT_295 = i + (int)((int)zT_293);
    i = zT_295;
    if ((unsigned char)(i < argc)) goto z_bb_65; else goto z_bb_66;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_301 = arg;
    zT_302 = s_error_format;
    zT_303 = zF_5FE51158_matchFlag(zT_301, zT_302);
    if (zT_303) goto z_bb_67; else goto z_bb_69;
    z_bb_65:
    zT_298 = i;
    zT_299 = zF_70B5BFF1_argGet(zT_298);
    zT_297 = zT_299;
    zT_300 = zF_05AD3AFC_parseColorMode(zT_297);
    cli.color = zT_300;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_304 = 1;
    zT_306 = i + (int)((int)zT_304);
    i = zT_306;
    if ((unsigned char)(i < argc)) goto z_bb_70; else goto z_bb_71;
    z_bb_68:
    goto z_bb_63;
    z_bb_69:
    zT_312 = arg;
    zT_313 = s_track_memory;
    zT_314 = zF_5FE51158_matchFlag(zT_312, zT_313);
    if (zT_314) goto z_bb_72; else goto z_bb_74;
    z_bb_70:
    zT_309 = i;
    zT_310 = zF_70B5BFF1_argGet(zT_309);
    zT_308 = zT_310;
    zT_311 = zF_A4602959_parseErrorFormat(zT_308);
    cli.error_format = zT_311;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_68;
    z_bb_72:
    cli.track_memory = (unsigned char)(1);
    goto z_bb_73;
    z_bb_73:
    goto z_bb_68;
    z_bb_74:
    zT_316 = arg;
    zT_317 = s_no_null;
    zT_318 = zF_5FE51158_matchFlag(zT_316, zT_317);
    if (zT_318) goto z_bb_75; else goto z_bb_77;
    z_bb_75:
    cli.no_null_check = (unsigned char)(1);
    goto z_bb_76;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_320 = arg;
    zT_321 = s_no_lifetime;
    zT_322 = zF_5FE51158_matchFlag(zT_320, zT_321);
    if (zT_322) goto z_bb_78; else goto z_bb_80;
    z_bb_78:
    cli.no_lifetime_check = (unsigned char)(1);
    goto z_bb_79;
    z_bb_79:
    goto z_bb_76;
    z_bb_80:
    zT_324 = arg;
    zT_325 = s_no_leak;
    zT_326 = zF_5FE51158_matchFlag(zT_324, zT_325);
    if (zT_326) goto z_bb_81; else goto z_bb_83;
    z_bb_81:
    cli.no_leak_check = (unsigned char)(1);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    zT_328 = arg;
    zT_329 = s_warn_all;
    zT_330 = zF_5FE51158_matchFlag(zT_328, zT_329);
    if (zT_330) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    cli.warn_all = (unsigned char)(1);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_332 = arg;
    zT_333 = s_warn_error;
    zT_334 = zF_5FE51158_matchFlag(zT_332, zT_333);
    if (zT_334) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    cli.warnings_as_errors = (unsigned char)(1);
    cli.warn_error = (unsigned char)(1);
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_337 = arg;
    zT_338 = s_markers;
    zT_339 = zF_5FE51158_matchFlag(zT_337, zT_338);
    if (zT_339) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    cli.show_markers = (unsigned char)(1);
    goto z_bb_91;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_341 = arg;
    zT_342 = s_include;
    zT_343 = zF_5FE51158_matchFlag(zT_341, zT_342);
    if (zT_343) goto z_bb_94; else goto z_bb_93;
    z_bb_93:
    zT_345 = arg;
    zT_346 = s_lib_dir;
    zT_347 = zF_5FE51158_matchFlag(zT_345, zT_346);
    zT_344 = zT_347;
    goto z_bb_95;
    z_bb_94:
    zT_344 = 1;
    goto z_bb_95;
    z_bb_95:
    if (zT_344) goto z_bb_96; else goto z_bb_98;
    z_bb_96:
    zT_348 = 1;
    zT_350 = i + (int)((int)zT_348);
    i = zT_350;
    if ((unsigned char)(i < argc)) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    goto z_bb_91;
    z_bb_98:
    zT_367 = arg;
    zT_368 = s_osl;
    zT_369 = zF_5FE51158_matchFlag(zT_367, zT_368);
    if (zT_369) goto z_bb_104; else goto z_bb_106;
    z_bb_99:
    zT_353 = cli.include_count;
    zT_354 = 16;
    zT_352 = zT_353 < (unsigned int)zT_354;
    goto z_bb_101;
    z_bb_100:
    zT_352 = 0;
    goto z_bb_101;
    z_bb_101:
    if (zT_352) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_357 = i;
    zT_358 = zF_70B5BFF1_argGet(zT_357);
    zT_356 = zT_358;
    zT_359 = zF_22D0470E_cstrToSlice(zT_356);
    zT_360 = cli.include_dirs;
    zT_361 = cli.include_count;
    zT_362 = (unsigned int)zT_361;
    zT_360[zT_362] = zT_359;
    zT_363 = cli.include_count;
    zT_364 = 1;
    cli.include_count = (unsigned int)(zT_363 + (unsigned int)((unsigned int)zT_364));
    goto z_bb_103;
    z_bb_103:
    goto z_bb_97;
    z_bb_104:
    cli.target_is_windows = (unsigned char)(0);
    goto z_bb_105;
    z_bb_105:
    goto z_bb_97;
    z_bb_106:
    zT_371 = arg;
    zT_372 = s_osw;
    zT_373 = zF_5FE51158_matchFlag(zT_371, zT_372);
    if (zT_373) goto z_bb_107; else goto z_bb_109;
    z_bb_107:
    cli.target_is_windows = (unsigned char)(1);
    goto z_bb_108;
    z_bb_108:
    goto z_bb_105;
    z_bb_109:
    zT_375 = arg;
    zT_376 = s_target;
    zT_377 = zF_5FE51158_matchFlag(zT_375, zT_376);
    if (zT_377) goto z_bb_110; else goto z_bb_112;
    z_bb_110:
    zT_378 = 1;
    zT_380 = i + (int)((int)zT_378);
    i = zT_380;
    if ((unsigned char)(i < argc)) goto z_bb_113; else goto z_bb_114;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_386 = arg;
    zT_387 = s_ffast;
    zT_388 = zF_5FE51158_matchFlag(zT_386, zT_387);
    if (zT_388) goto z_bb_115; else goto z_bb_117;
    z_bb_113:
    zT_383 = i;
    zT_384 = zF_70B5BFF1_argGet(zT_383);
    zT_382 = zT_384;
    zT_385 = zF_06CC17EA_parseTargetIsWindow(zT_382);
    cli.target_is_windows = zT_385;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    cli.safe_checks = (unsigned char)(0);
    goto z_bb_116;
    z_bb_116:
    goto z_bb_111;
    z_bb_117:
    zT_390 = arg;
    zT_391 = s_fsafe;
    zT_392 = zF_5FE51158_matchFlag(zT_390, zT_391);
    if (zT_392) goto z_bb_118; else goto z_bb_120;
    z_bb_118:
    cli.safe_checks = (unsigned char)(1);
    goto z_bb_119;
    z_bb_119:
    goto z_bb_116;
    z_bb_120:
    zT_394 = arg_ptr;
    zT_395 = zF_22D0470E_cstrToSlice(zT_394);
    cli.input_file = zT_395;
    goto z_bb_119;
}

/* matchFlag */
unsigned char zF_5FE51158_matchFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg, zT_8F083A69_Slice_zT_0B42B2F8_u flag) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    int zT_20;
    unsigned int zT_22;
    unsigned int j;
    zT_3 = arg.len;
    zT_5 = flag.len;
    if ((unsigned char)(zT_3 != zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    j = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = arg.len;
    if ((unsigned char)(j < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = arg.ptr;
    zT_15 = zT_14[j];
    zT_16 = flag.ptr;
    zT_17 = zT_16[j];
    if ((unsigned char)(zT_15 != zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_20 = 1;
    zT_22 = j + (unsigned int)((unsigned int)zT_20);
    j = zT_22;
    goto z_bb_6;
}

/* matchMMFlag */
unsigned char zF_FBF91F7E_matchMMFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mm;
    unsigned int j;
    zT_2 = "-mm";
    zT_4 = 3;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_mm = zT_3;
    zT_6 = arg.len;
    zT_8 = s_mm.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_mm.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_mm.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* cstrToSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D0470E_cstrToSlice(unsigned char* ptr) {
    int zT_2;
    unsigned int zT_3;
    unsigned char zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int len;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    len = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ptr[len];
    zT_5 = 0;
    if ((unsigned char)(zT_4 != zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    zT_9 = len + (unsigned int)((unsigned int)zT_7);
    len = zT_9;
    goto z_bb_4;
    z_bb_3:
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    return zT_13;
    z_bb_4:
    goto z_bb_1;
}

/* parseSize */
unsigned int zF_6CF11065_parseSize(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    unsigned char zT_29;
    int zT_32;
    unsigned int zT_33;
    unsigned char zT_36;
    int zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned char zT_45;
    int zT_48;
    int zT_50;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_54 = 1;
    zT_56 = i + (unsigned int)((unsigned int)zT_54);
    i = zT_56;
    goto z_bb_4;
    z_bb_10:
    if ((unsigned char)(c == (unsigned char)(107))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_29 = c == (unsigned char)(75);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_32 = 1024;
    zT_33 = val * zT_32;
    val = zT_33;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    if ((unsigned char)(c == (unsigned char)(109))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_36 = c == (unsigned char)(77);
    goto z_bb_19;
    z_bb_18:
    zT_36 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_36) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_39 = 1024;
    zT_41 = 1024;
    zT_42 = (unsigned int)(val * zT_39) * zT_41;
    val = zT_42;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    if ((unsigned char)(c == (unsigned char)(103))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_45 = c == (unsigned char)(71);
    goto z_bb_25;
    z_bb_24:
    zT_45 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_45) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_48 = 1024;
    zT_50 = 1024;
    zT_52 = 1024;
    zT_53 = (unsigned int)((unsigned int)(val * zT_48) * zT_50) * zT_52;
    val = zT_53;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_21;
}

/* parseU32 */
unsigned int zF_16BBA09E_parseU32(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_4;
}

/* parseMMBytes */
unsigned int zF_B9231BB9_parseMMBytes(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned char* zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    int zT_26;
    unsigned int zT_28;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_39;
    int zT_40;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int max_mb;
    unsigned int i;
    unsigned int n;
    unsigned int mb;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_5 = (unsigned int)(unsigned int)(256);
    max_mb = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    n = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    mb = zT_14;
    goto z_bb_1;
    z_bb_1:
    zT_16 = rest.len;
    if ((unsigned char)(i < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_19 = rest.ptr;
    zT_20 = zT_19[i];
    c = zT_20;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_40 = 0;
    if ((unsigned char)(n == (unsigned int)zT_40)) goto z_bb_15; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_23 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_23 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_26 = 1;
    zT_28 = n + (unsigned int)((unsigned int)zT_26);
    n = zT_28;
    if ((unsigned char)(mb < max_mb)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = (unsigned int)(mb * (unsigned int)(10)) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    mb = zT_35;
    if ((unsigned char)(mb > max_mb)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_4;
    z_bb_12:
    mb = max_mb;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    zT_44 = rest.len;
    zT_42 = i != zT_44;
    goto z_bb_16;
    z_bb_15:
    zT_42 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_47 = "error: -mm<N> requires a decimal MB size (e.g. -mm64)\n";
    zT_49 = 54;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    em = zT_48;
    zT_50 = em;
    zF_E4B2EF19_stderr_write(zT_50);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_18:
    return (unsigned int)(mb * (unsigned int)(1024));
}

/* matchSFlag */
unsigned char zF_C4E3C361_matchSFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_s;
    unsigned int j;
    zT_2 = "-s";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_s = zT_3;
    zT_6 = arg.len;
    zT_8 = s_s.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_s.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_s.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* parseSLevel */
unsigned int zF_153C3795_parseSLevel(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    int zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_32;
    unsigned int zT_36;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_43;
    int zT_44;
    unsigned char zT_46;
    unsigned int zT_48;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_58;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int i;
    unsigned int n;
    unsigned int level;
    unsigned int over;
    unsigned char c;
    unsigned int d;
    unsigned int nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    n = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    level = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    over = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_14 = rest.len;
    if ((unsigned char)(i < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = rest.ptr;
    zT_18 = zT_17[i];
    c = zT_18;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_44 = 0;
    if ((unsigned char)(n == (unsigned int)zT_44)) goto z_bb_16; else goto z_bb_15;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_21 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_21 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_21) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_24 = 1;
    zT_26 = n + (unsigned int)((unsigned int)zT_24);
    n = zT_26;
    zT_27 = 0;
    if ((unsigned char)(over == (unsigned int)zT_27)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_32;
    zT_36 = (unsigned int)(level * (unsigned int)(10)) + d;
    nl = zT_36;
    if ((unsigned char)(nl > (unsigned int)(6))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_4;
    z_bb_12:
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    over = zT_40;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    level = nl;
    goto z_bb_13;
    z_bb_15:
    zT_48 = rest.len;
    zT_46 = i != zT_48;
    goto z_bb_17;
    z_bb_16:
    zT_46 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_46) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_51 = "error: -s<N> requires a decimal level 0..6 (e.g. -s0 all on disk, -s6 all in RAM)\n";
    zT_53 = 82;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    em = zT_52;
    zT_54 = em;
    zF_E4B2EF19_stderr_write(zT_54);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_19:
    zT_58 = 0;
    if ((unsigned char)(over != (unsigned int)zT_58)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = "error: -s<N> spill level out of range (0..6: 0 = all on disk, 6 = all in RAM)\n";
    zT_63 = 78;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    em = zT_62;
    zT_64 = em;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_21:
    return level;
}

/* parseColorMode */
zT_CAF40AAB_ColorMode zF_05AD3AFC_parseColorMode(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_always;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_never;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "always";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_always = zT_6;
    zT_9 = "never";
    zT_11 = 5;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_never = zT_10;
    zT_12 = s;
    zT_13 = s_always;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_always);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_never;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_never);
    z_bb_4:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_auto);
}

/* parseErrorFormat */
zT_A4FB690E_ErrorFormat zF_A4602959_parseErrorFormat(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_json;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sarif;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "json";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_json = zT_6;
    zT_9 = "sarif";
    zT_11 = 5;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_sarif = zT_10;
    zT_12 = s;
    zT_13 = s_json;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_json);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_sarif;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_sarif);
    z_bb_4:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_human);
}

/* parseTargetIsWindows */
unsigned char zF_06CC17EA_parseTargetIsWindow(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_linux;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_windows;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "linux";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_linux = zT_6;
    zT_9 = "windows";
    zT_11 = 7;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_windows = zT_10;
    zT_12 = s;
    zT_13 = s_windows;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_linux;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_21 = "error: --target must be 'linux' or 'windows'\n";
    zT_23 = 45;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    err_msg = zT_22;
    zT_24 = err_msg;
    zF_E4B2EF19_stderr_write(zT_24);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned char)(0);
}

/* writeU32 */
void zF_266B1B8E_writeU32(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_11;
    int zT_15;
    int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    unsigned char zT_23;
    int zT_24;
    int zT_26;
    unsigned int zT_28;
    int zT_29;
    int zT_30;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 16;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    v = val;
    zT_7 = 0;
    if ((unsigned char)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 48;
    zT_10 = (unsigned char)zT_9;
    zT_11 = 15;
    buf[zT_11] = zT_10;
    zT_15 = 16;
    zT_16 = 15;
    zT_17 = (unsigned char*)((unsigned char*)buf) + zT_16;
    zT_18 = zT_15 - zT_16;
    zT_19.ptr = zT_17;
    zT_19.len = zT_18;
    s = zT_19;
    zT_20 = s;
    zF_B5478454_measureMarkerWrite(zT_20);
    return;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_21 = 0;
    if ((unsigned char)(v > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_26 = 1;
    zT_28 = i - (unsigned int)((unsigned int)zT_26);
    i = zT_28;
    zT_29 = 48;
    zT_30 = 10;
    zT_35 = (unsigned char)(unsigned int)((unsigned int)(unsigned int)(zT_29 + (unsigned int)((unsigned int)(unsigned int)(v % zT_30))));
    buf[i] = zT_35;
    zT_36 = 10;
    zT_37 = v / zT_36;
    v = zT_37;
    goto z_bb_6;
    z_bb_5:
    zT_41 = 16;
    zT_42 = (unsigned char*)((unsigned char*)buf) + i;
    zT_43 = zT_41 - i;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    s = zT_44;
    zT_45 = s;
    zF_B5478454_measureMarkerWrite(zT_45);
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_24 = 0;
    zT_23 = i > (unsigned int)zT_24;
    goto z_bb_9;
    z_bb_8:
    zT_23 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_23) goto z_bb_4; else goto z_bb_5;
}

/* printUsage */
void zF_9D45DFBF_printUsage(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help3;
    zT_8F083A69_Slice_zT_0B42B2F8_u os_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u tgt_help;
    zT_1 = "zig1 - Z98 self-hosted compiler - usage: zig1 [options] <input.zig>\n";
    zT_3 = 68;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_6 = "  -mm<N>    hard pool budget in MB (default 64; pool.peak over budget -> ICE rc=3)\n";
    zT_8 = 83;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    mm_help = zT_7;
    zT_9 = mm_help;
    zF_E4B2EF19_stderr_write(zT_9);
    zT_11 = "  -s<N>     spill level 0..6 (default 0 = all spills on disk; -s1..-s6 deactivate the\n";
    zT_13 = 86;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    s_help = zT_12;
    zT_14 = s_help;
    zF_E4B2EF19_stderr_write(zT_14);
    zT_16 = "            first N spills to RAM in order AST,LIR,HASH,RES,SIDE,EXTRA: higher -s = more RAM,\n";
    zT_18 = 94;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    s_help2 = zT_17;
    zT_19 = s_help2;
    zF_E4B2EF19_stderr_write(zT_19);
    zT_21 = "            less disk I/O (pool= rises; -s6 = all in RAM -> pair with -mm128)\n";
    zT_23 = 78;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    s_help3 = zT_22;
    zT_24 = s_help3;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_26 = "  -osl       compile target = linux (default); -osw = windows\n";
    zT_28 = 62;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    os_help = zT_27;
    zT_29 = os_help;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_31 = "  --target <linux|windows>  long-form target alias for -osl/-osw\n";
    zT_33 = 65;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    tgt_help = zT_32;
    zT_34 = tgt_help;
    zF_E4B2EF19_stderr_write(zT_34);
    return;
}

/* __module_init */
void zF_780653D2___module_init(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_69057089_CompilerAlloc zT_1 = {0};
    zT_D3EB6303_StringInterner zT_2 = {0};
    zT_227EDE07_SourceManager zT_3 = {0};
    zT_F85C5DED_DiagnosticCollector zT_4 = {0};
    zT_CEC2984A_NameMangler zT_5 = {0};
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7 = 0;
    zT_072B53A6_ModuleRegistry zT_8 = {0};
    zT_338B7C76_TypeRegistry zT_9 = {0};
    zT_6B356268_SemanticContext zT_10 = {0};
    zT_02EB57B2_LirLowerer zT_11 = {0};
    zT_CA01C129_LirSlotArrayList zT_12 = {0};
    zT_8EED1867_ResolvedTypeTable zT_13 = {0};
    zT_66E7D2EF_CoercionTable zT_14 = {0};
    zT_3D7259E2_SymbolRegistry zT_15 = {0};
    zT_8143F551_AstKind zT_16 = 0;
    zT_6B0A7D14_AstStore zT_17 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_69057089_CompilerAlloc = zT_1;
    zG_D3EB6303_StringInterner = zT_2;
    zG_227EDE07_SourceManager = zT_3;
    zG_F85C5DED_DiagnosticCollector = zT_4;
    zG_CEC2984A_NameMangler = zT_5;
    zG_3A355BD2_Token = zT_6;
    zG_EAC3E484_TokenKind = zT_7;
    zG_072B53A6_ModuleRegistry = zT_8;
    zG_338B7C76_TypeRegistry = zT_9;
    zG_6B356268_SemanticContext = zT_10;
    zG_02EB57B2_LirLowerer = zT_11;
    zG_CA01C129_LirSlotArrayList = zT_12;
    zG_8EED1867_ResolvedTypeTable = zT_13;
    zG_66E7D2EF_CoercionTable = zT_14;
    zG_3D7259E2_SymbolRegistry = zT_15;
    zG_8143F551_AstKind = zT_16;
    zG_6B0A7D14_AstStore = zT_17;
    return;
}

/* EOF */
