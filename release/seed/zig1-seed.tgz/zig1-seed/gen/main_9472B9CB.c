#include "main_9472B9CB.h"
/* main */
void zF_EA90E208_main(int argc, unsigned char** argv) {
    int zT_2;
    unsigned char** zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_C98AF326_CompilerCli zT_10 = {0};
    unsigned char zT_11;
    unsigned char zT_14;
    zT_69057089_CompilerAlloc zT_16 = {0};
    zT_3E40CD83_Sand* zT_18;
    zT_69057089_CompilerAlloc* zT_20;
    int zT_22;
    zT_D3EB6303_StringInterner zT_24 = {0};
    zT_3E40CD83_Sand* zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_227EDE07_SourceManager zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_227EDE07_SourceManager* zT_32;
    zT_D3EB6303_StringInterner* zT_33;
    zT_69057089_CompilerAlloc* zT_34;
    zT_3E40CD83_Sand* zT_39;
    zT_69057089_CompilerAlloc* zT_40;
    unsigned char zT_42;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_53;
    int zT_54;
    unsigned char zT_56;
    unsigned char zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char zT_60 = 0;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_69057089_CompilerAlloc zT_77 = {0};
    unsigned int zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_3E40CD83_Sand* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    zT_69057089_CompilerAlloc* zT_85;
    zT_94D83112_Opt_449 zT_87 = {0};
    unsigned char zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_101;
    unsigned int zT_104;
    unsigned int zT_108;
    unsigned int zT_111;
    zT_3E40CD83_Sand* zT_113;
    unsigned int zT_114;
    zT_69057089_CompilerAlloc* zT_115;
    zT_D3EB6303_StringInterner zT_117 = {0};
    zT_3E40CD83_Sand* zT_119;
    zT_69057089_CompilerAlloc* zT_120;
    zT_227EDE07_SourceManager zT_122 = {0};
    zT_3E40CD83_Sand* zT_124;
    zT_227EDE07_SourceManager* zT_125;
    zT_D3EB6303_StringInterner* zT_126;
    zT_69057089_CompilerAlloc* zT_127;
    zT_F85C5DED_DiagnosticCollector zT_131 = {0};
    unsigned int zT_132;
    zT_3E40CD83_Sand* zT_134;
    zT_69057089_CompilerAlloc* zT_135;
    zT_CEC2984A_NameMangler zT_138 = {0};
    zT_3E40CD83_Sand* zT_140;
    zT_D3EB6303_StringInterner* zT_141;
    zT_F85C5DED_DiagnosticCollector* zT_142;
    zT_69057089_CompilerAlloc* zT_143;
    zT_072B53A6_ModuleRegistry zT_147 = {0};
    zT_072B53A6_ModuleRegistry* zT_148;
    zT_227EDE07_SourceManager* zT_149;
    zT_7D82FE60_GrowableSand zT_153 = {0};
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_7D82FE60_GrowableSand* zT_158;
    zT_3E40CD83_Sand* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    zT_3E40CD83_Sand* zT_163 = 0;
    int zT_164;
    zT_3E40CD83_Sand* zT_167;
    zT_D3EB6303_StringInterner* zT_168;
    zT_7D82FE60_GrowableSand* zT_169;
    zT_338B7C76_TypeRegistry zT_172 = {0};
    zT_338B7C76_TypeRegistry* zT_173;
    zT_3E40CD83_Sand* zT_176;
    zT_69057089_CompilerAlloc* zT_177;
    zT_6B0A7D14_AstStore zT_179 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_181;
    unsigned int zT_183;
    unsigned char zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned char zT_192;
    unsigned char* zT_195;
    unsigned char zT_196;
    unsigned int zT_198;
    unsigned int zT_200;
    unsigned char zT_201;
    unsigned int zT_203;
    unsigned char zT_204;
    unsigned int zT_206;
    unsigned char zT_207;
    unsigned int zT_209;
    unsigned char* zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned int zT_213;
    unsigned int zT_215;
    unsigned int zT_217;
    unsigned char zT_219;
    unsigned char* zT_222;
    unsigned char zT_223;
    unsigned int zT_225;
    unsigned int zT_227;
    zT_6B0A7D14_AstStore* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    int zT_233;
    unsigned char* zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    zT_846744CC_Arr_unsigned_char_5 zT_238;
    unsigned int zT_240;
    unsigned char zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_245;
    unsigned int zT_247;
    unsigned char zT_249;
    unsigned char* zT_252;
    unsigned char zT_253;
    unsigned int zT_255;
    unsigned int zT_257;
    unsigned char zT_258;
    unsigned int zT_260;
    unsigned char zT_261;
    unsigned int zT_263;
    unsigned char zT_264;
    unsigned int zT_266;
    unsigned char* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_270;
    unsigned int zT_272;
    unsigned int zT_274;
    unsigned char zT_276;
    unsigned char* zT_279;
    unsigned char zT_280;
    unsigned int zT_282;
    unsigned int zT_284;
    zT_6B0A7D14_AstStore* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    int zT_292;
    unsigned char* zT_293;
    unsigned int zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    zT_846744CC_Arr_unsigned_char_5 zT_297;
    unsigned int zT_299;
    unsigned char zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_304;
    unsigned int zT_306;
    unsigned char zT_308;
    unsigned char* zT_311;
    unsigned char zT_312;
    unsigned int zT_314;
    unsigned int zT_316;
    unsigned char zT_317;
    unsigned int zT_319;
    unsigned char zT_320;
    unsigned int zT_322;
    unsigned char zT_323;
    unsigned int zT_325;
    unsigned char* zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    unsigned int zT_331;
    unsigned int zT_333;
    unsigned char zT_335;
    unsigned char* zT_338;
    unsigned char zT_339;
    unsigned int zT_341;
    unsigned int zT_343;
    zT_6B0A7D14_AstStore* zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    int zT_351;
    unsigned char* zT_352;
    unsigned int zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    zT_846744CC_Arr_unsigned_char_5 zT_356;
    unsigned int zT_358;
    unsigned char zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_361;
    unsigned int zT_363;
    unsigned int zT_365;
    unsigned char zT_367;
    unsigned char* zT_370;
    unsigned char zT_371;
    unsigned int zT_373;
    unsigned int zT_375;
    unsigned char zT_376;
    unsigned int zT_378;
    unsigned char zT_379;
    unsigned int zT_381;
    unsigned char zT_382;
    unsigned int zT_384;
    unsigned char* zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned int zT_388;
    unsigned int zT_390;
    unsigned int zT_392;
    unsigned char zT_394;
    unsigned char* zT_397;
    unsigned char zT_398;
    unsigned int zT_400;
    unsigned int zT_402;
    zT_6B0A7D14_AstStore* zT_403;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405;
    int zT_410;
    unsigned char* zT_411;
    unsigned int zT_412;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_413;
    zT_846744CC_Arr_unsigned_char_5 zT_415;
    unsigned int zT_417;
    unsigned char zT_418;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_420;
    unsigned int zT_422;
    unsigned int zT_424;
    unsigned char zT_426;
    unsigned char* zT_429;
    unsigned char zT_430;
    unsigned int zT_432;
    unsigned int zT_434;
    unsigned char zT_435;
    unsigned int zT_437;
    unsigned char zT_438;
    unsigned int zT_440;
    unsigned char zT_441;
    unsigned int zT_443;
    unsigned char* zT_445;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    unsigned int zT_447;
    unsigned int zT_449;
    unsigned int zT_451;
    unsigned char zT_453;
    unsigned char* zT_456;
    unsigned char zT_457;
    unsigned int zT_459;
    unsigned int zT_461;
    zT_6B0A7D14_AstStore* zT_462;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_464;
    int zT_469;
    unsigned char* zT_470;
    unsigned int zT_471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_472;
    zT_3E40CD83_Sand* zT_474;
    zT_69057089_CompilerAlloc* zT_475;
    zT_3D7259E2_SymbolRegistry zT_477 = {0};
    zT_3E40CD83_Sand* zT_479;
    zT_69057089_CompilerAlloc* zT_480;
    zT_8EED1867_ResolvedTypeTable zT_482 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_484;
    unsigned int zT_486;
    unsigned char zT_487;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_489;
    unsigned int zT_491;
    unsigned int zT_493;
    unsigned char zT_495;
    unsigned char* zT_498;
    unsigned char zT_499;
    unsigned int zT_501;
    unsigned int zT_503;
    unsigned char zT_504;
    unsigned int zT_506;
    unsigned char zT_507;
    unsigned int zT_509;
    unsigned char zT_510;
    unsigned int zT_512;
    unsigned char* zT_514;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_515;
    unsigned int zT_516;
    unsigned int zT_518;
    unsigned int zT_520;
    unsigned char zT_522;
    unsigned char* zT_525;
    unsigned char zT_526;
    unsigned int zT_528;
    unsigned int zT_530;
    zT_8EED1867_ResolvedTypeTable* zT_531;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_532;
    int zT_536;
    unsigned char* zT_537;
    unsigned int zT_538;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_539;
    zT_3E40CD83_Sand* zT_541;
    zT_69057089_CompilerAlloc* zT_542;
    zT_66E7D2EF_CoercionTable zT_544 = {0};
    zT_3E40CD83_Sand* zT_546;
    zT_69057089_CompilerAlloc* zT_547;
    zT_CA01C129_LirSlotArrayList zT_549 = {0};
    zT_3E40CD83_Sand* zT_551;
    zT_69057089_CompilerAlloc* zT_552;
    zT_4D61441E_DepGraph zT_554 = {0};
    zT_3E40CD83_Sand* zT_556;
    zT_69057089_CompilerAlloc* zT_557;
    zT_21D3708C_U32ToU32Map zT_559 = {0};
    zT_3E40CD83_Sand* zT_561;
    zT_69057089_CompilerAlloc* zT_562;
    zT_21D3708C_U32ToU32Map zT_564 = {0};
    zT_3E40CD83_Sand* zT_566;
    zT_69057089_CompilerAlloc* zT_567;
    zT_21D3708C_U32ToU32Map zT_569 = {0};
    zT_3E40CD83_Sand* zT_571;
    zT_69057089_CompilerAlloc* zT_572;
    zT_21D3708C_U32ToU32Map zT_574 = {0};
    zT_3E40CD83_Sand* zT_576;
    zT_69057089_CompilerAlloc* zT_577;
    zT_77F6F59C_ComptimeFoldTable zT_579 = {0};
    zT_3E40CD83_Sand* zT_581;
    zT_69057089_CompilerAlloc* zT_582;
    zT_A4CE86B7_U64ToU32Map zT_584 = {0};
    zT_3E40CD83_Sand* zT_586;
    zT_69057089_CompilerAlloc* zT_587;
    zT_A4CE86B7_U64ToU32Map zT_589 = {0};
    zT_3E40CD83_Sand* zT_591;
    zT_69057089_CompilerAlloc* zT_592;
    zT_A4CE86B7_U64ToU32Map zT_594 = {0};
    zT_3E40CD83_Sand* zT_596;
    zT_69057089_CompilerAlloc* zT_597;
    zT_A4CE86B7_U64ToU32Map zT_599 = {0};
    zT_3E40CD83_Sand* zT_601;
    zT_69057089_CompilerAlloc* zT_602;
    zT_A4CE86B7_U64ToU32Map zT_604 = {0};
    zT_3E40CD83_Sand* zT_606;
    zT_69057089_CompilerAlloc* zT_607;
    zT_A4CE86B7_U64ToU32Map zT_609 = {0};
    zT_3E40CD83_Sand* zT_611;
    zT_69057089_CompilerAlloc* zT_612;
    zT_A4CE86B7_U64ToU32Map zT_614 = {0};
    zT_3E40CD83_Sand* zT_616;
    zT_69057089_CompilerAlloc* zT_617;
    zT_B687BB96_U32ArrayList zT_619 = {0};
    zT_3E40CD83_Sand* zT_621;
    zT_69057089_CompilerAlloc* zT_622;
    zT_A4CE86B7_U64ToU32Map zT_624 = {0};
    zT_3E40CD83_Sand* zT_626;
    zT_69057089_CompilerAlloc* zT_627;
    zT_A4CE86B7_U64ToU32Map zT_629 = {0};
    zT_3E40CD83_Sand* zT_631;
    zT_69057089_CompilerAlloc* zT_632;
    zT_A4CE86B7_U64ToU32Map zT_634 = {0};
    zT_5AB29387_CompilerContext zT_636;
    zT_69057089_CompilerAlloc* zT_637;
    zT_D3EB6303_StringInterner* zT_638;
    zT_F85C5DED_DiagnosticCollector* zT_639;
    zT_227EDE07_SourceManager* zT_640;
    zT_CEC2984A_NameMangler* zT_641;
    zT_072B53A6_ModuleRegistry* zT_642;
    zT_338B7C76_TypeRegistry* zT_643;
    zT_6B0A7D14_AstStore* zT_644;
    zT_3D7259E2_SymbolRegistry* zT_645;
    zT_8EED1867_ResolvedTypeTable* zT_646;
    zT_66E7D2EF_CoercionTable* zT_647;
    zT_4D61441E_DepGraph* zT_648;
    zT_7E7544E4_LirStream zT_649 = {0};
    int zT_650;
    unsigned int zT_651;
    zT_3E40CD83_Sand* zT_652;
    zT_69057089_CompilerAlloc* zT_653;
    zT_E1A783EF_GlobalDeclArrayList zT_655 = {0};
    zT_3E40CD83_Sand* zT_656;
    zT_69057089_CompilerAlloc* zT_657;
    zT_A4CE86B7_U64ToU32Map zT_659 = {0};
    zT_3E40CD83_Sand* zT_660;
    zT_69057089_CompilerAlloc* zT_661;
    zT_B687BB96_U32ArrayList zT_663 = {0};
    zT_5AB29387_CompilerContext* zT_664;
    zT_8F083A69_Slice_zT_0B42B2F8_u startmsg;
    zT_C98AF326_CompilerCli cli;
    zT_69057089_CompilerAlloc compiler_alloc;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u source;
    unsigned int interner_bc;
    zT_CEC2984A_NameMangler name_mangler;
    zT_072B53A6_ModuleRegistry mr;
    zT_7D82FE60_GrowableSand type_db_arena;
    zT_8F083A69_Slice_zT_0B42B2F8_u type_db_name;
    zT_338B7C76_TypeRegistry typereg;
    zT_6B0A7D14_AstStore store;
    zT_846744CC_Arr_unsigned_char_5 ast_spill_path;
    unsigned int asp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od2;
    unsigned int oi2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ast_tmp_name;
    unsigned int ati;
    zT_846744CC_Arr_unsigned_char_5 id_spill_path;
    unsigned int idp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od3;
    unsigned int oi3;
    zT_8F083A69_Slice_zT_0B42B2F8_u id_tmp_name;
    unsigned int iti;
    zT_846744CC_Arr_unsigned_char_5 iv_spill_path;
    unsigned int ivp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od5;
    unsigned int oi5;
    zT_8F083A69_Slice_zT_0B42B2F8_u iv_tmp_name;
    unsigned int ivi;
    zT_846744CC_Arr_unsigned_char_5 ec_spill_path;
    unsigned int ecp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od6;
    unsigned int oi6;
    zT_8F083A69_Slice_zT_0B42B2F8_u ec_tmp_name;
    unsigned int eci;
    zT_846744CC_Arr_unsigned_char_5 er_spill_path;
    unsigned int erp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od7;
    unsigned int oi7;
    zT_8F083A69_Slice_zT_0B42B2F8_u er_tmp_name;
    unsigned int eri;
    zT_3D7259E2_SymbolRegistry symbol_reg;
    zT_8EED1867_ResolvedTypeTable resolved_types;
    zT_846744CC_Arr_unsigned_char_5 rtt_spill_path;
    unsigned int rsp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od4;
    unsigned int oi4;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtt_tmp_name;
    unsigned int rti2;
    zT_66E7D2EF_CoercionTable coercion_table;
    zT_CA01C129_LirSlotArrayList lir_slots;
    zT_4D61441E_DepGraph dep_graph;
    zT_21D3708C_U32ToU32Map enum_value_table;
    zT_21D3708C_U32ToU32Map error_code_registry;
    zT_21D3708C_U32ToU32Map call_arg_types;
    zT_21D3708C_U32ToU32Map call_param_map;
    zT_77F6F59C_ComptimeFoldTable comptime_folds;
    zT_A4CE86B7_U64ToU32Map exported;
    zT_A4CE86B7_U64ToU32Map suspending_fns;
    zT_A4CE86B7_U64ToU32Map frame_sizes;
    zT_A4CE86B7_U64ToU32Map state_widths;
    zT_A4CE86B7_U64ToU32Map awaited_fns;
    zT_A4CE86B7_U64ToU32Map async_hidden_fns;
    zT_A4CE86B7_U64ToU32Map driver_targets;
    zT_B687BB96_U32ArrayList parent_result_type_list;
    zT_A4CE86B7_U64ToU32Map parent_result_start;
    zT_A4CE86B7_U64ToU32Map parent_result_count;
    zT_A4CE86B7_U64ToU32Map async_layouts;
    zT_5AB29387_CompilerContext ctx;
    zT_2 = argc;
    zT_3 = argv;
    zF_4DE8E0A6_initArgs(zT_2, zT_3);
    zT_5 = "START\n";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    startmsg = zT_6;
    zT_8 = startmsg;
    zF_48AC7B3A_markerWrite(zT_8);
    zT_10 = zF_6143A521_parseArgs();
    cli = zT_10;
    zT_11 = cli.show_markers;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zF_3C88665D_markersEnabled((unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    zT_14 = cli.sanity_test_mode;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_16;
    zT_20 = &compiler_alloc;
    zT_18 = &zT_20->permanent;
    zT_22 = 4;
    zT_24 = zF_FB2E811D_stringInternerInit(zT_18, (unsigned int)((unsigned int)zT_22));
    interner = zT_24;
    zT_27 = &compiler_alloc;
    zT_26 = &zT_27->permanent;
    zT_29 = zF_01351F51_sourceManagerInit(zT_26);
    source_man = zT_29;
    zT_34 = &compiler_alloc;
    zT_31 = &zT_34->permanent;
    zT_32 = &source_man;
    zT_33 = &interner;
    (void)zF_C7BA7DAB_diagnosticCollector(zT_31, zT_32, zT_33);
    zT_40 = &compiler_alloc;
    zT_39 = &zT_40->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_39);
    zF_519E4401_lexerTestSanityChec();
    return;
    z_bb_4:
    zT_42 = cli.test_mode;
    if (zT_42) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_44 = "error: use test_main.zig for test mode\n";
    zT_46 = 39;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    msg = zT_45;
    zT_47 = msg;
    zF_48AC7B3A_markerWrite(zT_47);
    zT_49 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_49));
    return;
    z_bb_6:
    zT_51 = cli.input_file;
    zT_53 = zT_51.len;
    zT_54 = 0;
    if ((unsigned char)(zT_53 == (unsigned int)zT_54)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zF_9D45DFBF_printUsage();
    return;
    z_bb_8:
    zT_56 = cli.output_dir_set;
    if (zT_56) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_59 = cli.output_dir;
    zT_58 = zT_59;
    zT_60 = zF_8CC05F84_dirExists(zT_58);
    zT_57 = !zT_60;
    goto z_bb_11;
    z_bb_10:
    zT_57 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_57) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63 = "error: output directory does not exist: ";
    zT_65 = 40;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    msg = zT_64;
    zT_66 = msg;
    zF_E4B2EF19_stderr_write(zT_66);
    zT_68 = cli.output_dir;
    zT_67 = zT_68;
    zF_E4B2EF19_stderr_write(zT_67);
    zT_70 = "\n";
    zT_72 = 1;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    nl = zT_71;
    zT_73 = nl;
    zF_E4B2EF19_stderr_write(zT_73);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_13:
    zT_77 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_77;
    zT_78 = cli.max_mem;
    compiler_alloc.max_mem = zT_78;
    zT_79 = cli.spill_level;
    zF_4EDF4E7B_spillSetLevel(zT_79);
    zT_84 = cli.input_file;
    zT_82 = zT_84;
    zT_85 = &compiler_alloc;
    zT_83 = &zT_85->scratch;
    zT_87 = zF_5B859C63_readFile(zT_82, zT_83);
    zT_88 = zT_87.has_value;
    if (zT_88) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_92 = "error: could not read input file\n";
    zT_94 = 33;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = msg;
    zF_E4B2EF19_stderr_write(zT_95);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_15:
    zT_98 = zT_87.value;
    zT_89 = zT_98;
    goto z_bb_16;
    z_bb_16:
    source = zT_89;
    zT_101 = source.len;
    zT_104 = source.len;
    zT_108 = (unsigned int)((unsigned int)zT_101) + (unsigned int)((unsigned int)(unsigned int)(zT_104 / (unsigned int)(4)));
    interner_bc = zT_108;
    if ((unsigned char)(interner_bc < (unsigned int)(4096))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_111 = 4096;
    interner_bc = zT_111;
    goto z_bb_18;
    z_bb_18:
    zT_115 = &compiler_alloc;
    zT_113 = &zT_115->permanent;
    zT_114 = interner_bc;
    zT_117 = zF_FB2E811D_stringInternerInit(zT_113, zT_114);
    interner = zT_117;
    zT_120 = &compiler_alloc;
    zT_119 = &zT_120->permanent;
    zT_122 = zF_01351F51_sourceManagerInit(zT_119);
    source_man = zT_122;
    zT_127 = &compiler_alloc;
    zT_124 = &zT_127->permanent;
    zT_125 = &source_man;
    zT_126 = &interner;
    zT_131 = zF_C7BA7DAB_diagnosticCollector(zT_124, zT_125, zT_126);
    diag = zT_131;
    zT_132 = cli.max_errors;
    diag.max_diagnostics = (unsigned int)((unsigned int)zT_132);
    zT_135 = &compiler_alloc;
    zT_134 = &zT_135->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_134);
    zT_138 = zF_27DA3900_nameManglerInit();
    name_mangler = zT_138;
    zT_143 = &compiler_alloc;
    zT_140 = &zT_143->permanent;
    zT_141 = &interner;
    zT_142 = &diag;
    zT_147 = zF_896FAF3C_moduleRegistryInit(zT_140, zT_141, zT_142);
    mr = zT_147;
    zT_148 = &mr;
    zT_149 = &source_man;
    zF_BD2BF0BD_moduleRegistrySetSo(zT_148, zT_149);
    type_db_arena = zT_153;
    zT_155 = "type_db";
    zT_157 = 7;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    type_db_name = zT_156;
    zT_158 = &type_db_arena;
    zT_163 = zF_8C23960F_poolPtr();
    zT_159 = zT_163;
    zT_164 = 4096;
    zT_161 = type_db_name;
    zF_07B11742_growableSandInit(zT_158, zT_159, (unsigned int)((unsigned int)zT_164), zT_161);
    zT_169 = &type_db_arena;
    zT_167 = &zT_169->view;
    zT_168 = &interner;
    zT_172 = zF_4801746C_typeRegistryInit(zT_167, zT_168);
    typereg = zT_172;
    zT_173 = &typereg;
    zF_541737A5_typeRegistryRegiste(zT_173);
    zT_177 = &compiler_alloc;
    zT_176 = &zT_177->module;
    zT_179 = zF_D9F91436_astStoreInit(zT_176);
    store = zT_179;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_181[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ast_spill_path[_i] = zT_181[_i];
        _i++;
    }
}
    zT_183 = 0;
    asp_len = zT_183;
    zT_184 = cli.output_dir_set;
    if (zT_184) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_186 = cli.output_dir;
    od2 = zT_186;
    zT_188 = 0;
    oi2 = zT_188;
    goto z_bb_22;
    z_bb_20:
    zT_211 = ".zig1_ast.tmp";
    zT_213 = 13;
    zT_212.ptr = zT_211;
    zT_212.len = zT_213;
    ast_tmp_name = zT_212;
    zT_215 = 0;
    ati = zT_215;
    goto z_bb_29;
    z_bb_21:
    zT_204 = 46;
    ast_spill_path[asp_len] = zT_204;
    zT_206 = asp_len + (unsigned int)(1);
    asp_len = zT_206;
    zT_207 = 47;
    ast_spill_path[asp_len] = zT_207;
    zT_209 = asp_len + (unsigned int)(1);
    asp_len = zT_209;
    goto z_bb_20;
    z_bb_22:
    zT_190 = od2.len;
    if ((unsigned char)(oi2 < zT_190)) goto z_bb_26; else goto z_bb_27;
    z_bb_23:
    zT_195 = od2.ptr;
    zT_196 = zT_195[oi2];
    ast_spill_path[asp_len] = zT_196;
    zT_198 = asp_len + (unsigned int)(1);
    asp_len = zT_198;
    goto z_bb_25;
    z_bb_24:
    zT_201 = 47;
    ast_spill_path[asp_len] = zT_201;
    zT_203 = asp_len + (unsigned int)(1);
    asp_len = zT_203;
    goto z_bb_20;
    z_bb_25:
    zT_200 = oi2 + (unsigned int)(1);
    oi2 = zT_200;
    goto z_bb_22;
    z_bb_26:
    zT_192 = asp_len < (unsigned int)(511);
    goto z_bb_28;
    z_bb_27:
    zT_192 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_192) goto z_bb_23; else goto z_bb_24;
    z_bb_29:
    zT_217 = ast_tmp_name.len;
    if ((unsigned char)(ati < zT_217)) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_222 = ast_tmp_name.ptr;
    zT_223 = zT_222[ati];
    ast_spill_path[asp_len] = zT_223;
    zT_225 = asp_len + (unsigned int)(1);
    asp_len = zT_225;
    goto z_bb_32;
    z_bb_31:
    zT_228 = &store;
    zT_233 = 0;
    zT_234 = (unsigned char*)((unsigned char*)ast_spill_path) + zT_233;
    zT_235 = asp_len - zT_233;
    zT_236.ptr = zT_234;
    zT_236.len = zT_235;
    zT_229 = zT_236;
    zF_2A507339_astStoreSetSpillPat(zT_228, zT_229);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_238[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        id_spill_path[_i] = zT_238[_i];
        _i++;
    }
}
    zT_240 = 0;
    idp_len = zT_240;
    zT_241 = cli.output_dir_set;
    if (zT_241) goto z_bb_36; else goto z_bb_38;
    z_bb_32:
    zT_227 = ati + (unsigned int)(1);
    ati = zT_227;
    goto z_bb_29;
    z_bb_33:
    zT_219 = asp_len < (unsigned int)(511);
    goto z_bb_35;
    z_bb_34:
    zT_219 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_219) goto z_bb_30; else goto z_bb_31;
    z_bb_36:
    zT_243 = cli.output_dir;
    od3 = zT_243;
    zT_245 = 0;
    oi3 = zT_245;
    goto z_bb_39;
    z_bb_37:
    zT_268 = ".zig1_side.tmp";
    zT_270 = 14;
    zT_269.ptr = zT_268;
    zT_269.len = zT_270;
    id_tmp_name = zT_269;
    zT_272 = 0;
    iti = zT_272;
    goto z_bb_46;
    z_bb_38:
    zT_261 = 46;
    id_spill_path[idp_len] = zT_261;
    zT_263 = idp_len + (unsigned int)(1);
    idp_len = zT_263;
    zT_264 = 47;
    id_spill_path[idp_len] = zT_264;
    zT_266 = idp_len + (unsigned int)(1);
    idp_len = zT_266;
    goto z_bb_37;
    z_bb_39:
    zT_247 = od3.len;
    if ((unsigned char)(oi3 < zT_247)) goto z_bb_43; else goto z_bb_44;
    z_bb_40:
    zT_252 = od3.ptr;
    zT_253 = zT_252[oi3];
    id_spill_path[idp_len] = zT_253;
    zT_255 = idp_len + (unsigned int)(1);
    idp_len = zT_255;
    goto z_bb_42;
    z_bb_41:
    zT_258 = 47;
    id_spill_path[idp_len] = zT_258;
    zT_260 = idp_len + (unsigned int)(1);
    idp_len = zT_260;
    goto z_bb_37;
    z_bb_42:
    zT_257 = oi3 + (unsigned int)(1);
    oi3 = zT_257;
    goto z_bb_39;
    z_bb_43:
    zT_249 = idp_len < (unsigned int)(511);
    goto z_bb_45;
    z_bb_44:
    zT_249 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_249) goto z_bb_40; else goto z_bb_41;
    z_bb_46:
    zT_274 = id_tmp_name.len;
    if ((unsigned char)(iti < zT_274)) goto z_bb_50; else goto z_bb_51;
    z_bb_47:
    zT_279 = id_tmp_name.ptr;
    zT_280 = zT_279[iti];
    id_spill_path[idp_len] = zT_280;
    zT_282 = idp_len + (unsigned int)(1);
    idp_len = zT_282;
    goto z_bb_49;
    z_bb_48:
    zT_285 = &store;
    zT_292 = 0;
    zT_293 = (unsigned char*)((unsigned char*)id_spill_path) + zT_292;
    zT_294 = idp_len - zT_292;
    zT_295.ptr = zT_293;
    zT_295.len = zT_294;
    zT_287 = zT_295;
    zF_35B9B6EC_astStoreSetValuePoo(zT_285, (unsigned int)(0), zT_287);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_297[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        iv_spill_path[_i] = zT_297[_i];
        _i++;
    }
}
    zT_299 = 0;
    ivp_len = zT_299;
    zT_300 = cli.output_dir_set;
    if (zT_300) goto z_bb_53; else goto z_bb_55;
    z_bb_49:
    zT_284 = iti + (unsigned int)(1);
    iti = zT_284;
    goto z_bb_46;
    z_bb_50:
    zT_276 = idp_len < (unsigned int)(511);
    goto z_bb_52;
    z_bb_51:
    zT_276 = 0;
    goto z_bb_52;
    z_bb_52:
    if (zT_276) goto z_bb_47; else goto z_bb_48;
    z_bb_53:
    zT_302 = cli.output_dir;
    od5 = zT_302;
    zT_304 = 0;
    oi5 = zT_304;
    goto z_bb_56;
    z_bb_54:
    zT_327 = ".zig1_side_iv.tmp";
    zT_329 = 17;
    zT_328.ptr = zT_327;
    zT_328.len = zT_329;
    iv_tmp_name = zT_328;
    zT_331 = 0;
    ivi = zT_331;
    goto z_bb_63;
    z_bb_55:
    zT_320 = 46;
    iv_spill_path[ivp_len] = zT_320;
    zT_322 = ivp_len + (unsigned int)(1);
    ivp_len = zT_322;
    zT_323 = 47;
    iv_spill_path[ivp_len] = zT_323;
    zT_325 = ivp_len + (unsigned int)(1);
    ivp_len = zT_325;
    goto z_bb_54;
    z_bb_56:
    zT_306 = od5.len;
    if ((unsigned char)(oi5 < zT_306)) goto z_bb_60; else goto z_bb_61;
    z_bb_57:
    zT_311 = od5.ptr;
    zT_312 = zT_311[oi5];
    iv_spill_path[ivp_len] = zT_312;
    zT_314 = ivp_len + (unsigned int)(1);
    ivp_len = zT_314;
    goto z_bb_59;
    z_bb_58:
    zT_317 = 47;
    iv_spill_path[ivp_len] = zT_317;
    zT_319 = ivp_len + (unsigned int)(1);
    ivp_len = zT_319;
    goto z_bb_54;
    z_bb_59:
    zT_316 = oi5 + (unsigned int)(1);
    oi5 = zT_316;
    goto z_bb_56;
    z_bb_60:
    zT_308 = ivp_len < (unsigned int)(511);
    goto z_bb_62;
    z_bb_61:
    zT_308 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_308) goto z_bb_57; else goto z_bb_58;
    z_bb_63:
    zT_333 = iv_tmp_name.len;
    if ((unsigned char)(ivi < zT_333)) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_338 = iv_tmp_name.ptr;
    zT_339 = zT_338[ivi];
    iv_spill_path[ivp_len] = zT_339;
    zT_341 = ivp_len + (unsigned int)(1);
    ivp_len = zT_341;
    goto z_bb_66;
    z_bb_65:
    zT_344 = &store;
    zT_351 = 0;
    zT_352 = (unsigned char*)((unsigned char*)iv_spill_path) + zT_351;
    zT_353 = ivp_len - zT_351;
    zT_354.ptr = zT_352;
    zT_354.len = zT_353;
    zT_346 = zT_354;
    zF_35B9B6EC_astStoreSetValuePoo(zT_344, (unsigned int)(1), zT_346);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_356[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ec_spill_path[_i] = zT_356[_i];
        _i++;
    }
}
    zT_358 = 0;
    ecp_len = zT_358;
    zT_359 = cli.output_dir_set;
    if (zT_359) goto z_bb_70; else goto z_bb_72;
    z_bb_66:
    zT_343 = ivi + (unsigned int)(1);
    ivi = zT_343;
    goto z_bb_63;
    z_bb_67:
    zT_335 = ivp_len < (unsigned int)(511);
    goto z_bb_69;
    z_bb_68:
    zT_335 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_335) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_361 = cli.output_dir;
    od6 = zT_361;
    zT_363 = 0;
    oi6 = zT_363;
    goto z_bb_73;
    z_bb_71:
    zT_386 = ".zig1_extra_ec.tmp";
    zT_388 = 18;
    zT_387.ptr = zT_386;
    zT_387.len = zT_388;
    ec_tmp_name = zT_387;
    zT_390 = 0;
    eci = zT_390;
    goto z_bb_80;
    z_bb_72:
    zT_379 = 46;
    ec_spill_path[ecp_len] = zT_379;
    zT_381 = ecp_len + (unsigned int)(1);
    ecp_len = zT_381;
    zT_382 = 47;
    ec_spill_path[ecp_len] = zT_382;
    zT_384 = ecp_len + (unsigned int)(1);
    ecp_len = zT_384;
    goto z_bb_71;
    z_bb_73:
    zT_365 = od6.len;
    if ((unsigned char)(oi6 < zT_365)) goto z_bb_77; else goto z_bb_78;
    z_bb_74:
    zT_370 = od6.ptr;
    zT_371 = zT_370[oi6];
    ec_spill_path[ecp_len] = zT_371;
    zT_373 = ecp_len + (unsigned int)(1);
    ecp_len = zT_373;
    goto z_bb_76;
    z_bb_75:
    zT_376 = 47;
    ec_spill_path[ecp_len] = zT_376;
    zT_378 = ecp_len + (unsigned int)(1);
    ecp_len = zT_378;
    goto z_bb_71;
    z_bb_76:
    zT_375 = oi6 + (unsigned int)(1);
    oi6 = zT_375;
    goto z_bb_73;
    z_bb_77:
    zT_367 = ecp_len < (unsigned int)(511);
    goto z_bb_79;
    z_bb_78:
    zT_367 = 0;
    goto z_bb_79;
    z_bb_79:
    if (zT_367) goto z_bb_74; else goto z_bb_75;
    z_bb_80:
    zT_392 = ec_tmp_name.len;
    if ((unsigned char)(eci < zT_392)) goto z_bb_84; else goto z_bb_85;
    z_bb_81:
    zT_397 = ec_tmp_name.ptr;
    zT_398 = zT_397[eci];
    ec_spill_path[ecp_len] = zT_398;
    zT_400 = ecp_len + (unsigned int)(1);
    ecp_len = zT_400;
    goto z_bb_83;
    z_bb_82:
    zT_403 = &store;
    zT_410 = 0;
    zT_411 = (unsigned char*)((unsigned char*)ec_spill_path) + zT_410;
    zT_412 = ecp_len - zT_410;
    zT_413.ptr = zT_411;
    zT_413.len = zT_412;
    zT_405 = zT_413;
    zF_35B9B6EC_astStoreSetValuePoo(zT_403, (unsigned int)(2), zT_405);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_415[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        er_spill_path[_i] = zT_415[_i];
        _i++;
    }
}
    zT_417 = 0;
    erp_len = zT_417;
    zT_418 = cli.output_dir_set;
    if (zT_418) goto z_bb_87; else goto z_bb_89;
    z_bb_83:
    zT_402 = eci + (unsigned int)(1);
    eci = zT_402;
    goto z_bb_80;
    z_bb_84:
    zT_394 = ecp_len < (unsigned int)(511);
    goto z_bb_86;
    z_bb_85:
    zT_394 = 0;
    goto z_bb_86;
    z_bb_86:
    if (zT_394) goto z_bb_81; else goto z_bb_82;
    z_bb_87:
    zT_420 = cli.output_dir;
    od7 = zT_420;
    zT_422 = 0;
    oi7 = zT_422;
    goto z_bb_90;
    z_bb_88:
    zT_445 = ".zig1_extra_er.tmp";
    zT_447 = 18;
    zT_446.ptr = zT_445;
    zT_446.len = zT_447;
    er_tmp_name = zT_446;
    zT_449 = 0;
    eri = zT_449;
    goto z_bb_97;
    z_bb_89:
    zT_438 = 46;
    er_spill_path[erp_len] = zT_438;
    zT_440 = erp_len + (unsigned int)(1);
    erp_len = zT_440;
    zT_441 = 47;
    er_spill_path[erp_len] = zT_441;
    zT_443 = erp_len + (unsigned int)(1);
    erp_len = zT_443;
    goto z_bb_88;
    z_bb_90:
    zT_424 = od7.len;
    if ((unsigned char)(oi7 < zT_424)) goto z_bb_94; else goto z_bb_95;
    z_bb_91:
    zT_429 = od7.ptr;
    zT_430 = zT_429[oi7];
    er_spill_path[erp_len] = zT_430;
    zT_432 = erp_len + (unsigned int)(1);
    erp_len = zT_432;
    goto z_bb_93;
    z_bb_92:
    zT_435 = 47;
    er_spill_path[erp_len] = zT_435;
    zT_437 = erp_len + (unsigned int)(1);
    erp_len = zT_437;
    goto z_bb_88;
    z_bb_93:
    zT_434 = oi7 + (unsigned int)(1);
    oi7 = zT_434;
    goto z_bb_90;
    z_bb_94:
    zT_426 = erp_len < (unsigned int)(511);
    goto z_bb_96;
    z_bb_95:
    zT_426 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_426) goto z_bb_91; else goto z_bb_92;
    z_bb_97:
    zT_451 = er_tmp_name.len;
    if ((unsigned char)(eri < zT_451)) goto z_bb_101; else goto z_bb_102;
    z_bb_98:
    zT_456 = er_tmp_name.ptr;
    zT_457 = zT_456[eri];
    er_spill_path[erp_len] = zT_457;
    zT_459 = erp_len + (unsigned int)(1);
    erp_len = zT_459;
    goto z_bb_100;
    z_bb_99:
    zT_462 = &store;
    zT_469 = 0;
    zT_470 = (unsigned char*)((unsigned char*)er_spill_path) + zT_469;
    zT_471 = erp_len - zT_469;
    zT_472.ptr = zT_470;
    zT_472.len = zT_471;
    zT_464 = zT_472;
    zF_35B9B6EC_astStoreSetValuePoo(zT_462, (unsigned int)(3), zT_464);
    zT_475 = &compiler_alloc;
    zT_474 = &zT_475->permanent;
    zT_477 = zF_09A884A8_symbolRegistryInit(zT_474);
    symbol_reg = zT_477;
    zT_480 = &compiler_alloc;
    zT_479 = &zT_480->module;
    zT_482 = zF_8D0F00B1_resolvedTypeTableIn(zT_479);
    resolved_types = zT_482;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_484[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        rtt_spill_path[_i] = zT_484[_i];
        _i++;
    }
}
    zT_486 = 0;
    rsp_len = zT_486;
    zT_487 = cli.output_dir_set;
    if (zT_487) goto z_bb_104; else goto z_bb_106;
    z_bb_100:
    zT_461 = eri + (unsigned int)(1);
    eri = zT_461;
    goto z_bb_97;
    z_bb_101:
    zT_453 = erp_len < (unsigned int)(511);
    goto z_bb_103;
    z_bb_102:
    zT_453 = 0;
    goto z_bb_103;
    z_bb_103:
    if (zT_453) goto z_bb_98; else goto z_bb_99;
    z_bb_104:
    zT_489 = cli.output_dir;
    od4 = zT_489;
    zT_491 = 0;
    oi4 = zT_491;
    goto z_bb_107;
    z_bb_105:
    zT_514 = ".zig1_res.tmp";
    zT_516 = 13;
    zT_515.ptr = zT_514;
    zT_515.len = zT_516;
    rtt_tmp_name = zT_515;
    zT_518 = 0;
    rti2 = zT_518;
    goto z_bb_114;
    z_bb_106:
    zT_507 = 46;
    rtt_spill_path[rsp_len] = zT_507;
    zT_509 = rsp_len + (unsigned int)(1);
    rsp_len = zT_509;
    zT_510 = 47;
    rtt_spill_path[rsp_len] = zT_510;
    zT_512 = rsp_len + (unsigned int)(1);
    rsp_len = zT_512;
    goto z_bb_105;
    z_bb_107:
    zT_493 = od4.len;
    if ((unsigned char)(oi4 < zT_493)) goto z_bb_111; else goto z_bb_112;
    z_bb_108:
    zT_498 = od4.ptr;
    zT_499 = zT_498[oi4];
    rtt_spill_path[rsp_len] = zT_499;
    zT_501 = rsp_len + (unsigned int)(1);
    rsp_len = zT_501;
    goto z_bb_110;
    z_bb_109:
    zT_504 = 47;
    rtt_spill_path[rsp_len] = zT_504;
    zT_506 = rsp_len + (unsigned int)(1);
    rsp_len = zT_506;
    goto z_bb_105;
    z_bb_110:
    zT_503 = oi4 + (unsigned int)(1);
    oi4 = zT_503;
    goto z_bb_107;
    z_bb_111:
    zT_495 = rsp_len < (unsigned int)(511);
    goto z_bb_113;
    z_bb_112:
    zT_495 = 0;
    goto z_bb_113;
    z_bb_113:
    if (zT_495) goto z_bb_108; else goto z_bb_109;
    z_bb_114:
    zT_520 = rtt_tmp_name.len;
    if ((unsigned char)(rti2 < zT_520)) goto z_bb_118; else goto z_bb_119;
    z_bb_115:
    zT_525 = rtt_tmp_name.ptr;
    zT_526 = zT_525[rti2];
    rtt_spill_path[rsp_len] = zT_526;
    zT_528 = rsp_len + (unsigned int)(1);
    rsp_len = zT_528;
    goto z_bb_117;
    z_bb_116:
    zT_531 = &resolved_types;
    zT_536 = 0;
    zT_537 = (unsigned char*)((unsigned char*)rtt_spill_path) + zT_536;
    zT_538 = rsp_len - zT_536;
    zT_539.ptr = zT_537;
    zT_539.len = zT_538;
    zT_532 = zT_539;
    zF_7238A436_resolvedTypeTableSe(zT_531, zT_532);
    zT_542 = &compiler_alloc;
    zT_541 = &zT_542->module;
    zT_544 = zF_26B6D809_coercionTableInit(zT_541);
    coercion_table = zT_544;
    zT_547 = &compiler_alloc;
    zT_546 = &zT_547->emission;
    zT_549 = zF_F91F6677_lirSlotArrayListIni(zT_546);
    lir_slots = zT_549;
    zT_552 = &compiler_alloc;
    zT_551 = &zT_552->module;
    zT_554 = zF_7F194604_depGraphInit(zT_551);
    dep_graph = zT_554;
    zT_557 = &compiler_alloc;
    zT_556 = &zT_557->module;
    zT_559 = zF_58BDA2DE_u32ToU32MapInit(zT_556);
    enum_value_table = zT_559;
    zT_562 = &compiler_alloc;
    zT_561 = &zT_562->emission;
    zT_564 = zF_58BDA2DE_u32ToU32MapInit(zT_561);
    error_code_registry = zT_564;
    zT_567 = &compiler_alloc;
    zT_566 = &zT_567->module;
    zT_569 = zF_58BDA2DE_u32ToU32MapInit(zT_566);
    call_arg_types = zT_569;
    zT_572 = &compiler_alloc;
    zT_571 = &zT_572->module;
    zT_574 = zF_58BDA2DE_u32ToU32MapInit(zT_571);
    call_param_map = zT_574;
    zT_577 = &compiler_alloc;
    zT_576 = &zT_577->module;
    zT_579 = zF_9BB9958E_comptimeFoldTableIn(zT_576);
    comptime_folds = zT_579;
    zT_582 = &compiler_alloc;
    zT_581 = &zT_582->emission;
    zT_584 = zF_986226E1_u64ToU32MapInit(zT_581);
    exported = zT_584;
    zT_587 = &compiler_alloc;
    zT_586 = &zT_587->module;
    zT_589 = zF_986226E1_u64ToU32MapInit(zT_586);
    suspending_fns = zT_589;
    zT_592 = &compiler_alloc;
    zT_591 = &zT_592->module;
    zT_594 = zF_986226E1_u64ToU32MapInit(zT_591);
    frame_sizes = zT_594;
    zT_597 = &compiler_alloc;
    zT_596 = &zT_597->module;
    zT_599 = zF_986226E1_u64ToU32MapInit(zT_596);
    state_widths = zT_599;
    zT_602 = &compiler_alloc;
    zT_601 = &zT_602->module;
    zT_604 = zF_986226E1_u64ToU32MapInit(zT_601);
    awaited_fns = zT_604;
    zT_607 = &compiler_alloc;
    zT_606 = &zT_607->module;
    zT_609 = zF_986226E1_u64ToU32MapInit(zT_606);
    async_hidden_fns = zT_609;
    zT_612 = &compiler_alloc;
    zT_611 = &zT_612->module;
    zT_614 = zF_986226E1_u64ToU32MapInit(zT_611);
    driver_targets = zT_614;
    zT_617 = &compiler_alloc;
    zT_616 = &zT_617->module;
    zT_619 = zF_8E537D0C_u32ArrayListInit(zT_616);
    parent_result_type_list = zT_619;
    zT_622 = &compiler_alloc;
    zT_621 = &zT_622->module;
    zT_624 = zF_986226E1_u64ToU32MapInit(zT_621);
    parent_result_start = zT_624;
    zT_627 = &compiler_alloc;
    zT_626 = &zT_627->module;
    zT_629 = zF_986226E1_u64ToU32MapInit(zT_626);
    parent_result_count = zT_629;
    zT_632 = &compiler_alloc;
    zT_631 = &zT_632->module;
    zT_634 = zF_986226E1_u64ToU32MapInit(zT_631);
    async_layouts = zT_634;
    zT_636.cli = cli;
    zT_637 = &compiler_alloc;
    zT_636.alloc = zT_637;
    zT_638 = &interner;
    zT_636.interner = zT_638;
    zT_639 = &diag;
    zT_636.diag = zT_639;
    zT_640 = &source_man;
    zT_636.source_man = zT_640;
    zT_641 = &name_mangler;
    zT_636.name_mangler = zT_641;
    zT_642 = &mr;
    zT_636.module_reg = zT_642;
    zT_643 = &typereg;
    zT_636.typereg = zT_643;
    zT_644 = &store;
    zT_636.store = zT_644;
    zT_645 = &symbol_reg;
    zT_636.symbol_reg = zT_645;
    zT_646 = &resolved_types;
    zT_636.resolved_types = zT_646;
    zT_647 = &coercion_table;
    zT_636.coercion_table = zT_647;
    zT_648 = &dep_graph;
    zT_636.dep_graph = zT_648;
    zT_636.lir_slots = lir_slots;
    zT_649 = zF_E9CBFCA6_lirStreamInit();
    zT_636.lir_stream = zT_649;
    zT_636.enum_value_table = enum_value_table;
    zT_636.error_code_registry = error_code_registry;
    zT_636.call_arg_types = call_arg_types;
    zT_636.call_param_map = call_param_map;
    zT_636.comptime_folds = comptime_folds;
    zT_636.exported = exported;
    zT_636.suspending_fns = suspending_fns;
    zT_636.frame_sizes = frame_sizes;
    zT_636.state_widths = state_widths;
    zT_636.awaited_fns = awaited_fns;
    zT_636.async_hidden_fns = async_hidden_fns;
    zT_636.driver_targets = driver_targets;
    zT_636.parent_result_type_list = parent_result_type_list;
    zT_636.parent_result_start = parent_result_start;
    zT_636.parent_result_count = parent_result_count;
    zT_636.async_layouts = async_layouts;
    zT_650 = 0;
    zT_636.pointer_only_ids = (unsigned int*)zT_650;
    zT_651 = 0;
    zT_636.pointer_only_len = zT_651;
    zT_653 = &compiler_alloc;
    zT_652 = &zT_653->emission;
    zT_655 = zF_EB0B1609_globalDeclArrayList(zT_652);
    zT_636.global_decls = zT_655;
    zT_657 = &compiler_alloc;
    zT_656 = &zT_657->module;
    zT_659 = zF_986226E1_u64ToU32MapInit(zT_656);
    zT_636.module_init_deps = zT_659;
    zT_661 = &compiler_alloc;
    zT_660 = &zT_661->emission;
    zT_663 = zF_8E537D0C_u32ArrayListInit(zT_660);
    zT_636.module_init_order = zT_663;
    ctx = zT_636;
    zT_664 = &ctx;
    zF_74055C03_runCompiler(zT_664);
    return;
    z_bb_117:
    zT_530 = rti2 + (unsigned int)(1);
    rti2 = zT_530;
    goto z_bb_114;
    z_bb_118:
    zT_522 = rsp_len < (unsigned int)(511);
    goto z_bb_120;
    z_bb_119:
    zT_522 = 0;
    goto z_bb_120;
    z_bb_120:
    if (zT_522) goto z_bb_115; else goto z_bb_116;
}

int main(int argc, char** argv) {
    zF_780653D2___module_init();
    zF_780653D2___module_init_1();
    zF_780653D2___module_init_2();
    zF_780653D2___module_init_3();
    zF_780653D2___module_init_4();
    zF_780653D2___module_init_5();
    zF_780653D2___module_init_6();
    zF_780653D2___module_init_7();
    zF_780653D2___module_init_8();
    zF_780653D2___module_init_9();
    zF_780653D2___module_init_10();
    zF_780653D2___module_init_11();
    zF_780653D2___module_init_12();
    zF_780653D2___module_init_13();
    zF_780653D2___module_init_14();
    zF_780653D2___module_init_15();
    zF_780653D2___module_init_16();
    zF_780653D2___module_init_17();
    zF_780653D2___module_init_18();
    zF_780653D2___module_init_19();
    zF_780653D2___module_init_20();
    zF_780653D2___module_init_21();
    zF_780653D2___module_init_22();
    zF_780653D2___module_init_23();
    zF_780653D2___module_init_24();
    zF_780653D2___module_init_25();
    zF_780653D2___module_init_26();
    zF_780653D2___module_init_27();
    zF_780653D2___module_init_28();
    zF_EA90E208_main(argc, (unsigned char**)argv);
    return 0;
}

/* runCompiler */
void zF_74055C03_runCompiler(zT_5AB29387_CompilerContext* ctx) {
    zT_5AB29387_CompilerContext* zT_1;
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5AB29387_CompilerContext* zT_24;
    zT_69057089_CompilerAlloc* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    zT_3D7259E2_SymbolRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_D3EB6303_StringInterner* zT_31;
    zT_A4CE86B7_U64ToU32Map* zT_32;
    zT_69057089_CompilerAlloc* zT_33;
    zT_5AB29387_CompilerContext* zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_69057089_CompilerAlloc* zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned char zT_55 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_59;
    zT_69057089_CompilerAlloc* zT_61;
    zT_5AB29387_CompilerContext* zT_63;
    zT_5AB29387_CompilerContext* zT_64;
    zT_5AB29387_CompilerContext* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    unsigned char zT_68 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    int zT_72;
    zT_5AB29387_CompilerContext* zT_74;
    zT_69057089_CompilerAlloc* zT_75;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned char zT_79 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_80;
    int zT_83;
    zT_5AB29387_CompilerContext* zT_85;
    zT_5AB29387_CompilerContext* zT_86;
    zT_69057089_CompilerAlloc* zT_87;
    zT_F85C5DED_DiagnosticCollector* zT_89;
    unsigned char zT_91 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    int zT_95;
    zT_8EED1867_ResolvedTypeTable* zT_97;
    zT_3E40CD83_Sand* zT_99;
    zT_69057089_CompilerAlloc* zT_100;
    zT_5AB29387_CompilerContext* zT_102;
    zT_69057089_CompilerAlloc* zT_103;
    zT_C98AF326_CompilerCli zT_105;
    unsigned char zT_106;
    unsigned char zT_107;
    zT_C98AF326_CompilerCli zT_108;
    unsigned char zT_110;
    zT_F85C5DED_DiagnosticCollector* zT_111;
    unsigned int zT_113 = 0;
    int zT_114;
    zT_F85C5DED_DiagnosticCollector* zT_116;
    int zT_119;
    zT_C98AF326_CompilerCli zT_121;
    unsigned char zT_122;
    zT_69057089_CompilerAlloc* zT_124;
    zT_3E40CD83_Sand zT_125;
    unsigned int zT_126;
    unsigned int zT_129;
    zT_69057089_CompilerAlloc* zT_131;
    zT_3E40CD83_Sand zT_132;
    unsigned int zT_133;
    unsigned int zT_136;
    zT_69057089_CompilerAlloc* zT_138;
    zT_3E40CD83_Sand zT_139;
    unsigned int zT_140;
    unsigned int zT_143;
    unsigned int zT_145 = 0;
    unsigned int zT_148;
    zT_338B7C76_TypeRegistry* zT_150;
    zT_3E40CD83_Sand* zT_151;
    unsigned int zT_152;
    unsigned int zT_155;
    unsigned int zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    unsigned char* zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    unsigned char* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned char* zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    unsigned char* zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    zT_F85C5DED_DiagnosticCollector* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u z2;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3a;
    zT_8F083A69_Slice_zT_0B42B2F8_u z4;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2;
    unsigned int perm_kb;
    unsigned int mod_kb;
    unsigned int scr_kb;
    unsigned int pool_kb;
    unsigned int type_db_kb;
    unsigned int total;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3b;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3c;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg4;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg5;
    zT_1 = ctx;
    zF_E2BA93CE_phase_ImportResolut(zT_1);
    zT_3 = "2\n";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    z2 = zT_4;
    zT_6 = z2;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_7 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_7);
    zT_10 = "3\n";
    zT_12 = 2;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    z3 = zT_11;
    zT_13 = z3;
    zF_48AC7B3A_markerWrite(zT_13);
    zT_15 = "3a\n";
    zT_17 = 3;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    z3a = zT_16;
    zT_18 = z3a;
    zF_48AC7B3A_markerWrite(zT_18);
    zT_20 = "4\n";
    zT_22 = 2;
    zT_21.ptr = zT_20;
    zT_21.len = zT_22;
    z4 = zT_21;
    zT_23 = z4;
    zF_48AC7B3A_markerWrite(zT_23);
    zT_24 = ctx;
    zF_945DEA54_phase_SymbolRegistr(zT_24);
    zT_25 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_25);
    zT_33 = ctx->alloc;
    zT_27 = &zT_33->module;
    zT_28 = ctx->store;
    zT_29 = ctx->symbol_reg;
    zT_30 = ctx->module_reg;
    zT_31 = ctx->interner;
    zT_32 = &ctx->suspending_fns;
    zF_790061E7_suspensionAnalysisR(zT_27, zT_28, zT_29, zT_30, zT_31, zT_32);
    zT_40 = ctx;
    zF_D3497187_phase_TypeResolutio(zT_40);
    zT_42 = "t1\n";
    zT_44 = 3;
    zT_43.ptr = zT_42;
    zT_43.len = zT_44;
    t1 = zT_43;
    zT_45 = t1;
    zF_48AC7B3A_markerWrite(zT_45);
    zT_46 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_46);
    zT_49 = "t2\n";
    zT_51 = 3;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    t2 = zT_50;
    zT_52 = t2;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_53 = ctx->diag;
    zT_55 = zF_8F770780_diagnosticCollector(zT_53);
    if (zT_55) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_56 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_56);
    zT_59 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_59));
    goto z_bb_2;
    z_bb_2:
    zT_61 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_61);
    zT_63 = ctx;
    zF_F862154A_phase_FrontResoluti(zT_63);
    zT_64 = ctx;
    zF_9609BF31_phase_ComptimeEvalu(zT_64);
    zT_65 = ctx;
    zF_0666ED4F_phase_SemanticAnaly(zT_65);
    zT_66 = ctx->diag;
    zT_68 = zF_8F770780_diagnosticCollector(zT_66);
    if (zT_68) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_69 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_69);
    zT_72 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_72));
    goto z_bb_4;
    z_bb_4:
    zT_74 = ctx;
    zF_F3B55B42_phase_StaticAnalyze(zT_74);
    zT_75 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_75);
    zT_77 = ctx->diag;
    zT_79 = zF_8F770780_diagnosticCollector(zT_77);
    if (zT_79) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_80 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_80);
    zT_83 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_83));
    goto z_bb_6;
    z_bb_6:
    zT_85 = ctx;
    zF_9BC6214D_phase_AsyncFrameSiz(zT_85);
    zT_86 = ctx;
    zF_1F21ABE7_phase_LIRLowering(zT_86);
    zT_87 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_87);
    zT_89 = ctx->diag;
    zT_91 = zF_8F770780_diagnosticCollector(zT_89);
    if (zT_91) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_92 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_92);
    zT_95 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_95));
    goto z_bb_8;
    z_bb_8:
    zT_97 = ctx->resolved_types;
    zF_5209815D_resolvedTypeTableCl(zT_97);
    zT_100 = ctx->alloc;
    zT_99 = &zT_100->module;
    zF_F1B3F8C2_sandReset(zT_99);
    zT_102 = ctx;
    zF_2268F8CE_phase_C89Emission(zT_102);
    zT_103 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_103);
    zT_105 = ctx->cli;
    zT_106 = zT_105.warnings_as_errors;
    if (zT_106) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_108 = ctx->cli;
    zT_107 = zT_108.warn_error;
    goto z_bb_11;
    z_bb_10:
    zT_107 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_107) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_111 = ctx->diag;
    zT_113 = zF_4AF2092E_diagnosticCollector(zT_111);
    zT_114 = 0;
    zT_110 = zT_113 > (unsigned int)zT_114;
    goto z_bb_14;
    z_bb_13:
    zT_110 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_110) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_116 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_116);
    zT_119 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_119));
    goto z_bb_16;
    z_bb_16:
    zT_121 = ctx->cli;
    zT_122 = zT_121.track_memory;
    if (zT_122) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_124 = ctx->alloc;
    zT_125 = zT_124->permanent;
    zT_126 = zT_125.peak;
    zT_129 = (unsigned int)(unsigned int)(zT_126 / (unsigned int)(1024));
    perm_kb = zT_129;
    zT_131 = ctx->alloc;
    zT_132 = zT_131->module;
    zT_133 = zT_132.peak;
    zT_136 = (unsigned int)(unsigned int)(zT_133 / (unsigned int)(1024));
    mod_kb = zT_136;
    zT_138 = ctx->alloc;
    zT_139 = zT_138->scratch;
    zT_140 = zT_139.peak;
    zT_143 = (unsigned int)(unsigned int)(zT_140 / (unsigned int)(1024));
    scr_kb = zT_143;
    zT_145 = zF_E5D0D49C_poolPeak();
    zT_148 = (unsigned int)(unsigned int)(zT_145 / (unsigned int)(1024));
    pool_kb = zT_148;
    zT_150 = ctx->typereg;
    zT_151 = zT_150->types_alloc;
    zT_152 = zT_151->peak;
    zT_155 = (unsigned int)(unsigned int)(zT_152 / (unsigned int)(1024));
    type_db_kb = zT_155;
    zT_158 = (unsigned int)(perm_kb + mod_kb) + scr_kb;
    total = zT_158;
    zT_160 = "track-memory: perm=";
    zT_162 = 19;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    msg1 = zT_161;
    zT_163 = msg1;
    zF_B5478454_measureMarkerWrite(zT_163);
    zT_164 = perm_kb;
    zF_266B1B8E_writeU32(zT_164);
    zT_166 = "K mod=";
    zT_168 = 6;
    zT_167.ptr = zT_166;
    zT_167.len = zT_168;
    msg2 = zT_167;
    zT_169 = msg2;
    zF_B5478454_measureMarkerWrite(zT_169);
    zT_170 = mod_kb;
    zF_266B1B8E_writeU32(zT_170);
    zT_172 = "K scr=";
    zT_174 = 6;
    zT_173.ptr = zT_172;
    zT_173.len = zT_174;
    msg3 = zT_173;
    zT_175 = msg3;
    zF_B5478454_measureMarkerWrite(zT_175);
    zT_176 = scr_kb;
    zF_266B1B8E_writeU32(zT_176);
    zT_178 = "K pool=";
    zT_180 = 7;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    msg3b = zT_179;
    zT_181 = msg3b;
    zF_B5478454_measureMarkerWrite(zT_181);
    zT_182 = pool_kb;
    zF_266B1B8E_writeU32(zT_182);
    zT_184 = "K type_db=";
    zT_186 = 10;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    msg3c = zT_185;
    zT_187 = msg3c;
    zF_B5478454_measureMarkerWrite(zT_187);
    zT_188 = type_db_kb;
    zF_266B1B8E_writeU32(zT_188);
    zT_190 = "K total=";
    zT_192 = 8;
    zT_191.ptr = zT_190;
    zT_191.len = zT_192;
    msg4 = zT_191;
    zT_193 = msg4;
    zF_B5478454_measureMarkerWrite(zT_193);
    zT_194 = total;
    zF_266B1B8E_writeU32(zT_194);
    zT_196 = "K\n";
    zT_198 = 2;
    zT_197.ptr = zT_196;
    zT_197.len = zT_198;
    msg5 = zT_197;
    zT_199 = msg5;
    zF_B5478454_measureMarkerWrite(zT_199);
    goto z_bb_18;
    z_bb_18:
    zT_200 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_200);
    return;
}

/* astStoreHasPrintRef */
unsigned char zF_A42B6E3C_astStoreHasPrintRef(zT_6B0A7D14_AstStore* store, unsigned int print_id) {
    unsigned int zT_3;
    zT_42BEFD80_anon_258018 zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_8;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char zT_16;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24 = 0;
    unsigned int zT_28;
    unsigned int i;
    zT_22A7C88B_AstNode node;
    zT_3 = 0;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = store->nodes;
    zT_5 = zT_4.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = store;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, (unsigned int)((unsigned int)i));
    node = zT_11;
    zT_12 = node.kind;
    if ((unsigned char)(zT_12 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_28 = i + (unsigned int)(1);
    i = zT_28;
    goto z_bb_1;
    z_bb_5:
    zT_17 = node.kind;
    zT_16 = zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access);
    goto z_bb_7;
    z_bb_6:
    zT_16 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_16) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_21 = store;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, (unsigned int)((unsigned int)i));
    if ((unsigned char)(zT_24 == print_id)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    goto z_bb_4;
}

/* phase_ImportResolution */
void zF_E2BA93CE_phase_ImportResolut(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_C98AF326_CompilerCli zT_12;
    unsigned int zT_13;
    zT_4DB1475B_ModuleResolver* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_072B53A6_ModuleRegistry* zT_17;
    zT_C98AF326_CompilerCli zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    unsigned int zT_25;
    zT_846744CC_Arr_unsigned_char_5 zT_27;
    unsigned char* zT_29;
    int zT_31;
    unsigned char* zT_32;
    int zT_34 = 0;
    int zT_35;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char zT_46 = 0;
    zT_4DB1475B_ModuleResolver* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_072B53A6_ModuleRegistry* zT_49;
    zT_846744CC_Arr_unsigned_char_5 zT_52;
    zT_C98AF326_CompilerCli zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_C98AF326_CompilerCli zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_59;
    int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_C98AF326_CompilerCli zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_70;
    int zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_C98AF326_CompilerCli zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    zT_7434F691_Opt_224 zT_77 = {0};
    unsigned char zT_78;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_84 = 0;
    zT_072B53A6_ModuleRegistry* zT_86;
    unsigned int zT_87;
    unsigned int zT_89 = 0;
    zT_47A5CDFB_ImportQueue* zT_90;
    unsigned int zT_91;
    zT_072B53A6_ModuleRegistry* zT_92;
    zT_072B53A6_ModuleRegistry* zT_94;
    zT_3E40CD83_Sand* zT_95;
    zT_3E40CD83_Sand* zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    zT_69057089_CompilerAlloc* zT_99;
    zT_69057089_CompilerAlloc* zT_101;
    zT_D3EB6303_StringInterner* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    unsigned int zT_111 = 0;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned char zT_115 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_4DB1475B_ModuleResolver* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_3E40CD83_Sand* zT_123;
    zT_072B53A6_ModuleRegistry* zT_124;
    zT_69057089_CompilerAlloc* zT_126;
    zT_BAEE192E_Opt_10 zT_128 = {0};
    unsigned char zT_129;
    zT_D3EB6303_StringInterner* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_134 = 0;
    zT_072B53A6_ModuleRegistry* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_3E40CD83_Sand* zT_138;
    zT_69057089_CompilerAlloc* zT_140;
    zT_BAEE192E_Opt_10 zT_142 = {0};
    zT_072B53A6_ModuleRegistry* zT_143;
    zT_3E40CD83_Sand* zT_144;
    zT_3E40CD83_Sand* zT_145;
    zT_6B0A7D14_AstStore* zT_146;
    zT_69057089_CompilerAlloc* zT_148;
    zT_69057089_CompilerAlloc* zT_150;
    zT_846744CC_Arr_unsigned_char_5 zT_154;
    unsigned int zT_156;
    zT_C98AF326_CompilerCli zT_157;
    unsigned char zT_158;
    zT_C98AF326_CompilerCli zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_163;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned char* zT_170;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned int zT_175;
    unsigned char zT_176;
    unsigned int zT_178;
    unsigned char zT_179;
    unsigned int zT_181;
    unsigned char zT_182;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_192;
    unsigned char zT_194;
    unsigned char* zT_197;
    unsigned char zT_198;
    unsigned int zT_200;
    unsigned int zT_202;
    zT_072B53A6_ModuleRegistry* zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    int zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    unsigned int si;
    zT_846744CC_Arr_unsigned_char_5 lib_buf;
    int lib_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_path;
    zT_846744CC_Arr_unsigned_char_5 root_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u root_path;
    zT_7434F691_Opt_224 norm;
    unsigned int path_id;
    unsigned int mod_id;
    unsigned int print_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_name;
    zT_846744CC_Arr_unsigned_char_5 hash_spill_path;
    unsigned int hsp_len;
    unsigned int fmt_path_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hash_tmp_name;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u z_msg;
    zT_2 = "I\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    si = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_12 = ctx->cli;
    zT_13 = zT_12.include_count;
    if ((unsigned char)(si < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = ctx->module_reg;
    zT_15 = &zT_17->resolver;
    zT_19 = ctx->cli;
    zT_20 = zT_19.include_dirs;
    zT_21 = (unsigned int)si;
    zT_22 = zT_20[zT_21];
    zT_16 = zT_22;
    zF_B75A4515_moduleResolverAddSe(zT_15, zT_16);
    goto z_bb_4;
    z_bb_3:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_27[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        lib_buf[_i] = zT_27[_i];
        _i++;
    }
}
    zT_31 = 0;
    zT_32 = lib_buf + zT_31;
    zT_29 = zT_32;
    zT_34 = zF_BEB0BFA8_getDefaultLibPath(zT_29, (int)(512));
    lib_len = zT_34;
    zT_35 = 0;
    if ((unsigned char)(lib_len > zT_35)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_25 = si + (unsigned int)((unsigned int)zT_23);
    si = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_41 = 0;
    zT_42 = (unsigned char*)((unsigned char*)lib_buf) + zT_41;
    zT_43 = (unsigned int)((unsigned int)lib_len) - zT_41;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    lib_path = zT_44;
    zT_45 = lib_path;
    zT_46 = zF_8CC05F84_dirExists(zT_45);
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        root_buf[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = ctx->cli;
    zT_55 = zT_54.input_file;
    root_path = zT_55;
    zT_56 = ctx->cli;
    zT_57 = zT_56.input_file;
    zT_59 = zT_57.len;
    zT_60 = 512;
    if ((unsigned char)(zT_59 <= (unsigned int)zT_60)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_49 = ctx->module_reg;
    zT_47 = &zT_49->resolver;
    zT_48 = lib_path;
    zF_B75A4515_moduleResolverAddSe(zT_47, zT_48);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_67 = ctx->cli;
    zT_68 = zT_67.input_file;
    zT_70 = zT_68.len;
    zT_71 = 0;
    zT_72 = (unsigned char*)((unsigned char*)root_buf) + zT_71;
    zT_73 = zT_70 - zT_71;
    zT_74.ptr = zT_72;
    zT_74.len = zT_73;
    zT_63 = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.input_file;
    zT_64 = zT_76;
    zT_77 = zF_36F0DB6B_normalizePath(zT_63, zT_64);
    norm = zT_77;
    zT_78 = norm.has_value;
    if (zT_78) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_81 = ctx->interner;
    zT_82 = root_path;
    zT_84 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    path_id = zT_84;
    zT_86 = ctx->module_reg;
    zT_87 = path_id;
    zT_89 = zF_E4DCE20D_moduleRegistryAddMo(zT_86, zT_87);
    mod_id = zT_89;
    zT_92 = ctx->module_reg;
    zT_90 = &zT_92->import_queue;
    zT_91 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_90, zT_91);
    zT_94 = ctx->module_reg;
    zT_99 = ctx->alloc;
    zT_95 = &zT_99->module;
    zT_101 = ctx->alloc;
    zT_96 = &zT_101->scratch;
    zT_97 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_94, zT_95, zT_96, zT_97);
    zT_105 = ctx->interner;
    zT_108 = "print";
    zT_110 = 5;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    zT_106 = zT_109;
    zT_111 = zF_50C274AF_stringInternerInter(zT_105, zT_106);
    print_name_id = zT_111;
    zT_112 = ctx->store;
    zT_113 = print_name_id;
    zT_115 = zF_A42B6E3C_astStoreHasPrintRef(zT_112, zT_113);
    if (zT_115) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    n = norm.value;
    root_path = n;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_117 = "std_fmt.zig";
    zT_119 = 11;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    fmt_name = zT_118;
    zT_124 = ctx->module_reg;
    zT_120 = &zT_124->resolver;
    zT_121 = root_path;
    zT_122 = fmt_name;
    zT_126 = ctx->alloc;
    zT_123 = &zT_126->scratch;
    zT_128 = zF_6F148E15_moduleResolverResol(zT_120, zT_121, zT_122, zT_123);
    zT_129 = zT_128.has_value;
    if (zT_129) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_154[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hash_spill_path[_i] = zT_154[_i];
        _i++;
    }
}
    zT_156 = 0;
    hsp_len = zT_156;
    zT_157 = ctx->cli;
    zT_158 = zT_157.output_dir_set;
    if (zT_158) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    zT_131 = ctx->interner;
    zT_132 = fmt_name;
    zT_134 = zF_50C274AF_stringInternerInter(zT_131, zT_132);
    fmt_path_id = zT_134;
    zT_135 = ctx->module_reg;
    zT_136 = fmt_path_id;
    zT_137 = mod_id;
    zT_140 = ctx->alloc;
    zT_138 = &zT_140->scratch;
    zT_142 = zF_620E3E3B_moduleRegistryResol(zT_135, zT_136, zT_137, zT_138);
    (void)zT_142;
    zT_143 = ctx->module_reg;
    zT_148 = ctx->alloc;
    zT_144 = &zT_148->module;
    zT_150 = ctx->alloc;
    zT_145 = &zT_150->scratch;
    zT_146 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_143, zT_144, zT_145, zT_146);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_160 = ctx->cli;
    zT_161 = zT_160.output_dir;
    od = zT_161;
    zT_163 = 0;
    oi = zT_163;
    goto z_bb_20;
    z_bb_18:
    zT_186 = ".zig1_hash.tmp";
    zT_188 = 14;
    zT_187.ptr = zT_186;
    zT_187.len = zT_188;
    hash_tmp_name = zT_187;
    zT_190 = 0;
    hi = zT_190;
    goto z_bb_27;
    z_bb_19:
    zT_179 = 46;
    hash_spill_path[hsp_len] = zT_179;
    zT_181 = hsp_len + (unsigned int)(1);
    hsp_len = zT_181;
    zT_182 = 47;
    hash_spill_path[hsp_len] = zT_182;
    zT_184 = hsp_len + (unsigned int)(1);
    hsp_len = zT_184;
    goto z_bb_18;
    z_bb_20:
    zT_165 = od.len;
    if ((unsigned char)(oi < zT_165)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_170 = od.ptr;
    zT_171 = zT_170[oi];
    hash_spill_path[hsp_len] = zT_171;
    zT_173 = hsp_len + (unsigned int)(1);
    hsp_len = zT_173;
    goto z_bb_23;
    z_bb_22:
    zT_176 = 47;
    hash_spill_path[hsp_len] = zT_176;
    zT_178 = hsp_len + (unsigned int)(1);
    hsp_len = zT_178;
    goto z_bb_18;
    z_bb_23:
    zT_175 = oi + (unsigned int)(1);
    oi = zT_175;
    goto z_bb_20;
    z_bb_24:
    zT_167 = hsp_len < (unsigned int)(511);
    goto z_bb_26;
    z_bb_25:
    zT_167 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_167) goto z_bb_21; else goto z_bb_22;
    z_bb_27:
    zT_192 = hash_tmp_name.len;
    if ((unsigned char)(hi < zT_192)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_197 = hash_tmp_name.ptr;
    zT_198 = zT_197[hi];
    hash_spill_path[hsp_len] = zT_198;
    zT_200 = hsp_len + (unsigned int)(1);
    hsp_len = zT_200;
    goto z_bb_30;
    z_bb_29:
    zT_203 = ctx->module_reg;
    zT_208 = 0;
    zT_209 = (unsigned char*)((unsigned char*)hash_spill_path) + zT_208;
    zT_210 = hsp_len - zT_208;
    zT_211.ptr = zT_209;
    zT_211.len = zT_210;
    zT_204 = zT_211;
    zF_8767909B_moduleRegistrySpill(zT_203, zT_204);
    zT_213 = "Z\n";
    zT_215 = 2;
    zT_214.ptr = zT_213;
    zT_214.len = zT_215;
    z_msg = zT_214;
    zT_216 = z_msg;
    zF_48AC7B3A_markerWrite(zT_216);
    return;
    z_bb_30:
    zT_202 = hi + (unsigned int)(1);
    hi = zT_202;
    goto z_bb_27;
    z_bb_31:
    zT_194 = hsp_len < (unsigned int)(511);
    goto z_bb_33;
    z_bb_32:
    zT_194 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_194) goto z_bb_28; else goto z_bb_29;
}

/* phase_SymbolRegistration */
void zF_945DEA54_phase_SymbolRegistr(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_11;
    zT_4D61441E_DepGraph zT_13 = {0};
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_072B53A6_ModuleRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_4D61441E_DepGraph* zT_29;
    zT_6E8D187B_ModuleEntry* zT_35;
    zT_6E8D187B_ModuleEntry zT_36;
    int zT_40;
    unsigned int zT_42;
    zT_072B53A6_ModuleRegistry* zT_44;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_46 = {0};
    unsigned int zT_48;
    unsigned char zT_51;
    zT_6E8D187B_ModuleEntry* zT_52;
    int zT_53;
    zT_6E8D187B_ModuleEntry zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    zT_6E8D187B_ModuleEntry* zT_62;
    int zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    zT_22A7C88B_AstNode zT_66 = {0};
    zT_8143F551_AstKind zT_67;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_6E8D187B_ModuleEntry* zT_75;
    int zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_79 = 0;
    unsigned int zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_97;
    int zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_102 = 0;
    zT_22A7C88B_AstNode zT_103 = {0};
    zT_8143F551_AstKind zT_105;
    unsigned int zT_106;
    zT_4028D896_Arr_unsigned_char_2 zT_108;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    int zT_114;
    unsigned char* zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118 = 0;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned char* zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_136;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_DDCD424B_Slice_zT_6E8D187B_M smods;
    zT_22A7C88B_AstNode sr;
    unsigned int sdl_n;
    unsigned int sdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl;
    zT_22A7C88B_AstNode sd;
    unsigned int sk;
    zT_4028D896_Arr_unsigned_char_2 sb;
    unsigned int slen;
    unsigned int sst;
    zT_8F083A69_Slice_zT_0B42B2F8_u ssp;
    zT_8F083A69_Slice_zT_0B42B2F8_u sn;
    zT_2 = "S\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->alloc;
    zT_10 = &zT_11->scratch;
    zT_13 = zF_7F194604_depGraphInit(zT_10);
    dep_graph = zT_13;
    zT_15 = ctx->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_22 = mods.len;
    if ((unsigned char)(mi < zT_22)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_24 = ctx->module_reg;
    zT_25 = ctx->symbol_reg;
    zT_26 = ctx->typereg;
    zT_27 = ctx->store;
    zT_35 = mods.ptr;
    zT_36 = zT_35[mi];
    zT_28 = zT_36.id;
    zT_29 = &dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_24, zT_25, zT_26, zT_27, zT_28, zT_29, (unsigned char)(1));
    goto z_bb_4;
    z_bb_3:
    zT_44 = ctx->module_reg;
    zT_46 = zF_3452C137_moduleRegistryGetMo(zT_44);
    smods = zT_46;
    zT_48 = smods.len;
    if ((unsigned char)(zT_48 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_40 = 1;
    zT_42 = mi + (unsigned int)((unsigned int)zT_40);
    mi = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_52 = smods.ptr;
    zT_53 = 0;
    zT_54 = zT_52[zT_53];
    zT_55 = zT_54.ast_root;
    zT_51 = zT_55 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_51 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_51) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_59 = ctx->store;
    zT_62 = smods.ptr;
    zT_63 = 0;
    zT_64 = zT_62[zT_63];
    zT_60 = zT_64.ast_root;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_59, zT_60);
    sr = zT_66;
    zT_67 = sr.kind;
    if ((unsigned char)(zT_67 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_72 = ctx->store;
    zT_75 = smods.ptr;
    zT_76 = 0;
    zT_77 = zT_75[zT_76];
    zT_73 = zT_77.ast_root;
    zT_79 = zF_152E19CB_astStoreNodeExtraCh(zT_72, zT_73);
    sdl_n = zT_79;
    zT_81 = 0;
    sdi = zT_81;
    zT_83 = "S0";
    zT_85 = 2;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    sl = zT_84;
    zT_86 = sl;
    zF_48AC7B3A_markerWrite(zT_86);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(sdi < (unsigned int)((unsigned int)sdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_90 = ctx->store;
    zT_93 = ctx->store;
    zT_97 = smods.ptr;
    zT_98 = 0;
    zT_99 = zT_97[zT_98];
    zT_94 = zT_99.ast_root;
    zT_102 = zF_B10B1BC1_astStoreNodeExtraCh(zT_93, zT_94, (unsigned int)((unsigned int)sdi));
    zT_91 = zT_102;
    zT_103 = zF_FCDD1D35_astStoreNodeAt(zT_90, zT_91);
    sd = zT_103;
    zT_105 = sd.kind;
    zT_106 = (unsigned int)zT_105;
    sk = zT_106;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_108[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sb[_i] = zT_108[_i];
        _i++;
    }
}
    zT_110 = sk;
    zT_114 = 0;
    zT_115 = (unsigned char*)((unsigned char*)sb) + zT_114;
    zT_116 = (unsigned int)(20) - zT_114;
    zT_117.ptr = zT_115;
    zT_117.len = zT_116;
    zT_111 = zT_117;
    zT_118 = zF_A7504564_itoa(zT_110, zT_111);
    slen = zT_118;
    zT_122 = (unsigned int)(19) - (unsigned int)((unsigned int)slen);
    sst = zT_122;
    zT_127 = (unsigned char*)((unsigned char*)sb) + sst;
    zT_128 = (unsigned int)(19) - sst;
    zT_129.ptr = zT_127;
    zT_129.len = zT_128;
    zT_123 = zT_129;
    zF_48AC7B3A_markerWrite(zT_123);
    zT_131 = " ";
    zT_133 = 1;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    ssp = zT_132;
    zT_134 = ssp;
    zF_48AC7B3A_markerWrite(zT_134);
    goto z_bb_15;
    z_bb_14:
    zT_138 = "\n";
    zT_140 = 1;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    sn = zT_139;
    zT_141 = sn;
    zF_48AC7B3A_markerWrite(zT_141);
    goto z_bb_11;
    z_bb_15:
    zT_136 = sdi + (unsigned int)(1);
    sdi = zT_136;
    goto z_bb_12;
}

/* phase_TypeResolution */
void zF_D3497187_phase_TypeResolutio(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_42BEFD80_anon_258018 zT_10;
    zT_3E40CD83_Sand* zT_12;
    zT_69057089_CompilerAlloc* zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_69057089_CompilerAlloc* zT_17;
    zT_4D61441E_DepGraph zT_19 = {0};
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_3D7259E2_SymbolRegistry* zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_4D61441E_DepGraph* zT_35;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    int zT_46;
    unsigned int zT_48;
    zT_3D7259E2_SymbolRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_D3EB6303_StringInterner* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    zT_3E40CD83_Sand* zT_53;
    zT_69057089_CompilerAlloc* zT_58;
    zT_6B0A7D14_AstStore* zT_60;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_3D7259E2_SymbolRegistry* zT_62;
    zT_D3EB6303_StringInterner* zT_63;
    zT_8EED1867_ResolvedTypeTable* zT_64;
    zT_072B53A6_ModuleRegistry* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_69057089_CompilerAlloc* zT_75;
    zT_338B7C76_TypeRegistry* zT_78;
    zT_F85C5DED_DiagnosticCollector* zT_79;
    zT_3E40CD83_Sand* zT_80;
    zT_69057089_CompilerAlloc* zT_83;
    zT_C890C8CB_TypeResolver zT_85 = {0};
    zT_C890C8CB_TypeResolver* zT_86;
    zT_C890C8CB_TypeResolver* zT_88;
    zT_4D61441E_DepGraph* zT_89;
    zT_C890C8CB_TypeResolver* zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_3D7259E2_SymbolRegistry* zT_96;
    zT_D3EB6303_StringInterner* zT_97;
    zT_072B53A6_ModuleRegistry* zT_98;
    zT_F85C5DED_DiagnosticCollector* zT_99;
    zT_C890C8CB_TypeResolver* zT_107;
    zT_3E40CD83_Sand* zT_108;
    zT_69057089_CompilerAlloc* zT_110;
    zT_010C8DF0_ClassificationResul zT_112 = {0};
    unsigned int* zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned char zT_119;
    zT_6E8D187B_ModuleEntry* zT_120;
    int zT_121;
    zT_6E8D187B_ModuleEntry zT_122;
    unsigned int zT_123;
    zT_6B0A7D14_AstStore* zT_127;
    unsigned int zT_128;
    zT_6E8D187B_ModuleEntry* zT_130;
    int zT_131;
    zT_6E8D187B_ModuleEntry zT_132;
    zT_22A7C88B_AstNode zT_134 = {0};
    zT_8143F551_AstKind zT_135;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    zT_6E8D187B_ModuleEntry* zT_143;
    int zT_144;
    zT_6E8D187B_ModuleEntry zT_145;
    unsigned int zT_147 = 0;
    unsigned int zT_149;
    unsigned char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    zT_6B0A7D14_AstStore* zT_161;
    unsigned int zT_162;
    zT_6E8D187B_ModuleEntry* zT_165;
    int zT_166;
    zT_6E8D187B_ModuleEntry zT_167;
    unsigned int zT_170 = 0;
    zT_22A7C88B_AstNode zT_171 = {0};
    zT_8143F551_AstKind zT_173;
    unsigned int zT_174;
    zT_4028D896_Arr_unsigned_char_2 zT_176;
    unsigned int zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    int zT_182;
    unsigned char* zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186 = 0;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned char* zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    unsigned int zT_204;
    unsigned char* zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned int zT_208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_C890C8CB_TypeResolver tr;
    zT_010C8DF0_ClassificationResul ptr_grp;
    zT_22A7C88B_AstNode tr2;
    unsigned int tdl_n;
    unsigned int tdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tl;
    zT_22A7C88B_AstNode td;
    unsigned int tk;
    zT_4028D896_Arr_unsigned_char_2 tb;
    unsigned int tlen;
    unsigned int tst;
    zT_8F083A69_Slice_zT_0B42B2F8_u tsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tn;
    zT_2 = "T\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->resolved_types;
    zT_9 = ctx->store;
    zT_10 = zT_9->nodes;
    zT_7 = zT_10.len;
    zF_75224871_resolvedTypeTableRe(zT_6, zT_7);
    zT_13 = ctx->alloc;
    zT_12 = &zT_13->scratch;
    zF_F1B3F8C2_sandReset(zT_12);
    zT_17 = ctx->alloc;
    zT_16 = &zT_17->scratch;
    zT_19 = zF_7F194604_depGraphInit(zT_16);
    dep_graph = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    mi = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_28 = mods.len;
    if ((unsigned char)(mi < zT_28)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_30 = ctx->module_reg;
    zT_31 = ctx->symbol_reg;
    zT_32 = ctx->typereg;
    zT_33 = ctx->store;
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_34 = zT_42.id;
    zT_35 = &dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_30, zT_31, zT_32, zT_33, zT_34, zT_35, (unsigned char)(0));
    goto z_bb_4;
    z_bb_3:
    zT_49 = ctx->symbol_reg;
    zT_50 = ctx->typereg;
    zT_51 = ctx->interner;
    zT_52 = ctx->store;
    zT_58 = ctx->alloc;
    zT_53 = &zT_58->permanent;
    zF_EF7F7D3C_constAliasPrepass(zT_49, zT_50, zT_51, zT_52, zT_53);
    zT_60 = ctx->store;
    zT_61 = ctx->typereg;
    zT_62 = ctx->symbol_reg;
    zT_63 = ctx->interner;
    zT_64 = ctx->resolved_types;
    zT_65 = ctx->module_reg;
    zT_66 = ctx->diag;
    zT_75 = ctx->alloc;
    zT_67 = &zT_75->permanent;
    zF_373A7BEF_typeResolverResolve(zT_60, zT_61, zT_62, zT_63, zT_64, zT_65, zT_66, zT_67);
    zT_78 = ctx->typereg;
    zT_79 = ctx->diag;
    zT_83 = ctx->alloc;
    zT_80 = &zT_83->scratch;
    zT_85 = zF_5BFAC855_typeResolverInit(zT_78, zT_79, zT_80);
    tr = zT_85;
    zT_86 = &tr;
    zF_D5C4530C_typeResolverBuildDe(zT_86);
    zT_88 = &tr;
    zT_89 = &dep_graph;
    zF_33272F41_typeResolverBuild(zT_88, zT_89);
    zT_92 = &tr;
    zF_30BE7185_typeResolverResolve(zT_92);
    zT_94 = ctx->store;
    zT_95 = ctx->typereg;
    zT_96 = ctx->symbol_reg;
    zT_97 = ctx->interner;
    zT_98 = ctx->module_reg;
    zT_99 = ctx->diag;
    zF_153D24FD_enumReevaluateAll(zT_94, zT_95, zT_96, zT_97, zT_98, zT_99);
    zT_107 = &tr;
    zT_110 = ctx->alloc;
    zT_108 = &zT_110->permanent;
    zT_112 = zF_ACC002C8_classifyTypeEmissio(zT_107, zT_108);
    ptr_grp = zT_112;
    zT_113 = ptr_grp.ids;
    ctx->pointer_only_ids = zT_113;
    zT_114 = ptr_grp.len;
    ctx->pointer_only_len = zT_114;
    zT_116 = mods.len;
    if ((unsigned char)(zT_116 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_46 = 1;
    zT_48 = mi + (unsigned int)((unsigned int)zT_46);
    mi = zT_48;
    goto z_bb_1;
    z_bb_5:
    zT_120 = mods.ptr;
    zT_121 = 0;
    zT_122 = zT_120[zT_121];
    zT_123 = zT_122.ast_root;
    zT_119 = zT_123 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_119 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_119) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_127 = ctx->store;
    zT_130 = mods.ptr;
    zT_131 = 0;
    zT_132 = zT_130[zT_131];
    zT_128 = zT_132.ast_root;
    zT_134 = zF_FCDD1D35_astStoreNodeAt(zT_127, zT_128);
    tr2 = zT_134;
    zT_135 = tr2.kind;
    if ((unsigned char)(zT_135 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_140 = ctx->store;
    zT_143 = mods.ptr;
    zT_144 = 0;
    zT_145 = zT_143[zT_144];
    zT_141 = zT_145.ast_root;
    zT_147 = zF_152E19CB_astStoreNodeExtraCh(zT_140, zT_141);
    tdl_n = zT_147;
    zT_149 = 0;
    tdi = zT_149;
    zT_151 = "T0";
    zT_153 = 2;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    tl = zT_152;
    zT_154 = tl;
    zF_48AC7B3A_markerWrite(zT_154);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(tdi < (unsigned int)((unsigned int)tdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_158 = ctx->store;
    zT_161 = ctx->store;
    zT_165 = mods.ptr;
    zT_166 = 0;
    zT_167 = zT_165[zT_166];
    zT_162 = zT_167.ast_root;
    zT_170 = zF_B10B1BC1_astStoreNodeExtraCh(zT_161, zT_162, (unsigned int)((unsigned int)tdi));
    zT_159 = zT_170;
    zT_171 = zF_FCDD1D35_astStoreNodeAt(zT_158, zT_159);
    td = zT_171;
    zT_173 = td.kind;
    zT_174 = (unsigned int)zT_173;
    tk = zT_174;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_176[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        tb[_i] = zT_176[_i];
        _i++;
    }
}
    zT_178 = tk;
    zT_182 = 0;
    zT_183 = (unsigned char*)((unsigned char*)tb) + zT_182;
    zT_184 = (unsigned int)(20) - zT_182;
    zT_185.ptr = zT_183;
    zT_185.len = zT_184;
    zT_179 = zT_185;
    zT_186 = zF_A7504564_itoa(zT_178, zT_179);
    tlen = zT_186;
    zT_190 = (unsigned int)(19) - (unsigned int)((unsigned int)tlen);
    tst = zT_190;
    zT_195 = (unsigned char*)((unsigned char*)tb) + tst;
    zT_196 = (unsigned int)(19) - tst;
    zT_197.ptr = zT_195;
    zT_197.len = zT_196;
    zT_191 = zT_197;
    zF_48AC7B3A_markerWrite(zT_191);
    zT_199 = " ";
    zT_201 = 1;
    zT_200.ptr = zT_199;
    zT_200.len = zT_201;
    tsp = zT_200;
    zT_202 = tsp;
    zF_48AC7B3A_markerWrite(zT_202);
    goto z_bb_15;
    z_bb_14:
    zT_206 = "\n";
    zT_208 = 1;
    zT_207.ptr = zT_206;
    zT_207.len = zT_208;
    tn = zT_207;
    zT_209 = tn;
    zF_48AC7B3A_markerWrite(zT_209);
    goto z_bb_11;
    z_bb_15:
    zT_204 = tdi + (unsigned int)(1);
    tdi = zT_204;
    goto z_bb_12;
}

/* phase_FrontResolution */
void zF_F862154A_phase_FrontResoluti(zT_5AB29387_CompilerContext* ctx) {
    zT_6DCFC8DB_FrontResCtx zT_2;
    zT_6B0A7D14_AstStore* zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_3E40CD83_Sand* zT_11;
    zT_66E7D2EF_CoercionTable* zT_12;
    zT_21D3708C_U32ToU32Map* zT_13;
    zT_21D3708C_U32ToU32Map* zT_14;
    zT_21D3708C_U32ToU32Map* zT_15;
    zT_21D3708C_U32ToU32Map* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_6DCFC8DB_FrontResCtx* zT_18;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_3 = ctx->store;
    zT_2.store = zT_3;
    zT_4 = ctx->typereg;
    zT_2.typereg = zT_4;
    zT_5 = ctx->symbol_reg;
    zT_2.symbol_reg = zT_5;
    zT_6 = ctx->resolved_types;
    zT_2.resolved_types = zT_6;
    zT_7 = ctx->module_reg;
    zT_2.module_reg = zT_7;
    zT_8 = ctx->interner;
    zT_2.interner = zT_8;
    zT_9 = ctx->diag;
    zT_2.diag = zT_9;
    zT_10 = ctx->alloc;
    zT_11 = &zT_10->scratch;
    zT_2.scratch = zT_11;
    zT_12 = ctx->coercion_table;
    zT_2.coercion_table = zT_12;
    zT_13 = &ctx->enum_value_table;
    zT_2.enum_value_table = zT_13;
    zT_14 = &ctx->error_code_registry;
    zT_2.error_code_registry = zT_14;
    zT_15 = &ctx->call_arg_types;
    zT_2.call_arg_types = zT_15;
    zT_16 = &ctx->call_param_map;
    zT_2.call_param_map = zT_16;
    zT_17 = &ctx->suspending_fns;
    zT_2.suspending_fns = zT_17;
    frc = zT_2;
    zT_18 = &frc;
    zF_8A0E7747_frontResolveModuleI(zT_18);
    return;
}

/* phase_ComptimeEvaluation */
void zF_9609BF31_phase_ComptimeEvalu(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15 = {0};
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_7034F045_Opt_228 zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    zT_42BEFD80_anon_258018 zT_24;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_28;
    zT_22A7C88B_AstNode zT_32 = {0};
    zT_8143F551_AstKind zT_33;
    zT_DA663F79_ComptimeEval* zT_38;
    zT_E53A25A2_Opt_203 zT_42 = {0};
    unsigned char zT_43;
    zT_77F6F59C_ComptimeFoldTable* zT_45;
    zT_89B1DDDA_ComptimeVal zT_47;
    zT_8143F551_AstKind zT_50;
    unsigned char zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned char zT_58;
    zT_6B0A7D14_AstStore* zT_64;
    unsigned int zT_65;
    zT_22A7C88B_AstNode zT_68 = {0};
    zT_8143F551_AstKind zT_70;
    unsigned int zT_71;
    unsigned char zT_74;
    unsigned char zT_77;
    unsigned char zT_80;
    zT_DA663F79_ComptimeEval* zT_84;
    unsigned int zT_85;
    zT_E53A25A2_Opt_203 zT_88 = {0};
    unsigned char zT_89;
    zT_77F6F59C_ComptimeFoldTable* zT_91;
    unsigned int zT_92;
    zT_89B1DDDA_ComptimeVal zT_93;
    zT_8143F551_AstKind zT_96;
    unsigned char zT_100;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_104;
    unsigned int zT_108 = 0;
    zT_DA663F79_ComptimeEval* zT_112;
    unsigned int zT_113;
    zT_E53A25A2_Opt_203 zT_116 = {0};
    unsigned char zT_117;
    unsigned char zT_119;
    zT_77F6F59C_ComptimeFoldTable* zT_122;
    unsigned int zT_123;
    zT_89B1DDDA_ComptimeVal zT_124;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_m;
    zT_DA663F79_ComptimeEval ce;
    unsigned int ni;
    zT_22A7C88B_AstNode node;
    zT_E53A25A2_Opt_203 val;
    zT_89B1DDDA_ComptimeVal v;
    zT_22A7C88B_AstNode init_n;
    unsigned int ik;
    zT_E53A25A2_Opt_203 val2;
    zT_89B1DDDA_ComptimeVal v2;
    zT_E53A25A2_Opt_203 cval;
    zT_89B1DDDA_ComptimeVal cv;
    zT_2 = "CE\n";
    zT_4 = 3;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    pc_m = zT_3;
    zT_5 = pc_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ce.diag = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    ni = zT_22;
    goto z_bb_1;
    z_bb_1:
    zT_23 = ctx->store;
    zT_24 = zT_23->nodes;
    zT_25 = zT_24.len;
    if ((unsigned char)(ni < zT_25)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_28 = ctx->store;
    zT_32 = zF_FCDD1D35_astStoreNodeAt(zT_28, (unsigned int)((unsigned int)ni));
    node = zT_32;
    zT_33 = node.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_128 = ni + (unsigned int)(1);
    ni = zT_128;
    goto z_bb_1;
    z_bb_5:
    zT_38 = &ce;
    zT_42 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_38, (unsigned int)((unsigned int)ni));
    val = zT_42;
    zT_43 = val.has_value;
    if (zT_43) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_50 = node.kind;
    if ((unsigned char)(zT_50 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    v = val.value;
    zT_45 = &ctx->comptime_folds;
    zT_47 = v;
    zF_376429F5_comptimeFoldTablePu(zT_45, (unsigned int)((unsigned int)ni), zT_47);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_55 = node.child_1;
    zT_56 = 0;
    zT_54 = zT_55 != (unsigned int)zT_56;
    goto z_bb_12;
    z_bb_11:
    zT_54 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_54) goto z_bb_13; else goto z_bb_15;
    z_bb_13:
    zT_58 = node.flags;
    if ((unsigned char)((unsigned char)(zT_58 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_96 = node.kind;
    if ((unsigned char)(zT_96 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_31; else goto z_bb_32;
    z_bb_16:
    zT_64 = ctx->store;
    zT_65 = node.child_1;
    zT_68 = zF_FCDD1D35_astStoreNodeAt(zT_64, zT_65);
    init_n = zT_68;
    zT_70 = init_n.kind;
    zT_71 = (unsigned int)zT_70;
    ik = zT_71;
    if ((unsigned char)(ik >= (unsigned int)(33))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_74 = ik <= (unsigned int)(42);
    goto z_bb_20;
    z_bb_19:
    zT_74 = 0;
    goto z_bb_20;
    z_bb_20:
    if (zT_74) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_77 = ik == (unsigned int)(62);
    goto z_bb_23;
    z_bb_22:
    zT_77 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_77) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_80 = ik == (unsigned int)(64);
    goto z_bb_26;
    z_bb_25:
    zT_80 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_80) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_84 = &ce;
    zT_85 = node.child_1;
    zT_88 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_84, zT_85);
    val2 = zT_88;
    zT_89 = val2.has_value;
    if (zT_89) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_17;
    z_bb_29:
    v2 = val2.value;
    zT_91 = &ctx->comptime_folds;
    zT_92 = node.child_1;
    zT_93 = v2;
    zF_376429F5_comptimeFoldTablePu(zT_91, zT_92, zT_93);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_101 = node.child_2;
    zT_100 = zT_101 == (unsigned int)(0);
    goto z_bb_33;
    z_bb_32:
    zT_100 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_100) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_104 = ctx->store;
    zT_108 = zF_8BA26B9E_astStoreNodePayload(zT_104, (unsigned int)((unsigned int)ni));
    if ((unsigned char)(zT_108 == (unsigned int)(0))) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_14;
    z_bb_36:
    zT_112 = &ce;
    zT_113 = node.child_0;
    zT_116 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_112, zT_113);
    cval = zT_116;
    zT_117 = cval.has_value;
    if (zT_117) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    cv = cval.value;
    zT_119 = cv.kind;
    if ((unsigned char)(zT_119 == (unsigned char)(1))) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    zT_122 = &ctx->comptime_folds;
    zT_123 = node.child_0;
    zT_124 = cv;
    zF_376429F5_comptimeFoldTablePu(zT_122, zT_123, zT_124);
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
}

/* phase_SemanticAnalysis */
void zF_0666ED4F_phase_SemanticAnaly(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_6DCFC8DB_FrontResCtx zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_D3EB6303_StringInterner* zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    zT_69057089_CompilerAlloc* zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_66E7D2EF_CoercionTable* zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    zT_21D3708C_U32ToU32Map* zT_22;
    zT_21D3708C_U32ToU32Map* zT_23;
    zT_21D3708C_U32ToU32Map* zT_24;
    zT_A4CE86B7_U64ToU32Map* zT_25;
    zT_072B53A6_ModuleRegistry* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29 = {0};
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_69057089_CompilerAlloc* zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    unsigned int zT_59 = 0;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    zT_6E8D187B_ModuleEntry* zT_71;
    zT_6E8D187B_ModuleEntry zT_72;
    unsigned int zT_73;
    zT_3E40CD83_Sand* zT_75;
    zT_8EED1867_ResolvedTypeTable* zT_76;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    zT_338B7C76_TypeRegistry* zT_78;
    zT_3D7259E2_SymbolRegistry* zT_79;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    zT_66E7D2EF_CoercionTable* zT_83;
    zT_21D3708C_U32ToU32Map* zT_84;
    zT_21D3708C_U32ToU32Map* zT_85;
    zT_D3EB6303_StringInterner* zT_86;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_21D3708C_U32ToU32Map* zT_88;
    zT_072B53A6_ModuleRegistry* zT_89;
    zT_A4CE86B7_U64ToU32Map* zT_90;
    zT_69057089_CompilerAlloc* zT_91;
    zT_6E8D187B_ModuleEntry* zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    zT_38C12417_SemanticAnalyzer zT_109 = {0};
    int zT_111;
    unsigned int zT_112;
    zT_6B0A7D14_AstStore* zT_116;
    unsigned int zT_117;
    unsigned int zT_121 = 0;
    zT_6B0A7D14_AstStore* zT_123;
    unsigned int zT_124;
    zT_22A7C88B_AstNode zT_126 = {0};
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    zT_8143F551_AstKind zT_132;
    unsigned int zT_136;
    int zT_137;
    zT_6DCFC8DB_FrontResCtx* zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_143;
    zT_6E8D187B_ModuleEntry* zT_145;
    zT_6E8D187B_ModuleEntry zT_146;
    zT_6E8D187B_ModuleEntry* zT_150;
    zT_6E8D187B_ModuleEntry zT_151;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    zT_38C12417_SemanticAnalyzer* zT_158;
    unsigned int zT_159;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    zT_8143F551_AstKind zT_166;
    unsigned char zT_170;
    unsigned int zT_171;
    zT_6B0A7D14_AstStore* zT_175;
    unsigned int zT_176;
    zT_22A7C88B_AstNode zT_179 = {0};
    zT_8143F551_AstKind zT_180;
    zT_38C12417_SemanticAnalyzer* zT_184;
    unsigned int zT_185;
    zT_8143F551_AstKind zT_187;
    unsigned char zT_191;
    unsigned char zT_192;
    zT_38C12417_SemanticAnalyzer* zT_197;
    unsigned int zT_198;
    zT_8143F551_AstKind zT_200;
    zT_38C12417_SemanticAnalyzer* zT_204;
    unsigned int zT_205;
    zT_8143F551_AstKind zT_207;
    zT_38C12417_SemanticAnalyzer* zT_211;
    unsigned int zT_212;
    int zT_214;
    unsigned int zT_216;
    int zT_217;
    unsigned int zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mz;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u ad;
    zT_8F083A69_Slice_zT_0B42B2F8_u dse_m;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa0;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa1;
    zT_22A7C88B_AstNode di_inn;
    zT_2 = "RS";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    rs = zT_3;
    zT_5 = rs;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->store;
    zT_10.store = zT_11;
    zT_12 = ctx->typereg;
    zT_10.typereg = zT_12;
    zT_13 = ctx->symbol_reg;
    zT_10.symbol_reg = zT_13;
    zT_14 = ctx->resolved_types;
    zT_10.resolved_types = zT_14;
    zT_15 = ctx->module_reg;
    zT_10.module_reg = zT_15;
    zT_16 = ctx->interner;
    zT_10.interner = zT_16;
    zT_17 = ctx->diag;
    zT_10.diag = zT_17;
    zT_18 = ctx->alloc;
    zT_19 = &zT_18->scratch;
    zT_10.scratch = zT_19;
    zT_20 = ctx->coercion_table;
    zT_10.coercion_table = zT_20;
    zT_21 = &ctx->enum_value_table;
    zT_10.enum_value_table = zT_21;
    zT_22 = &ctx->error_code_registry;
    zT_10.error_code_registry = zT_22;
    zT_23 = &ctx->call_arg_types;
    zT_10.call_arg_types = zT_23;
    zT_24 = &ctx->call_param_map;
    zT_10.call_param_map = zT_24;
    zT_25 = &ctx->suspending_fns;
    zT_10.suspending_fns = zT_25;
    frc = zT_10;
    zT_27 = ctx->module_reg;
    zT_29 = zF_3452C137_moduleRegistryGetMo(zT_27);
    mods = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    mi = zT_32;
    goto z_bb_1;
    z_bb_1:
    zT_34 = mods.len;
    if ((unsigned char)(mi < zT_34)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_37 = ctx->alloc;
    zT_36 = &zT_37->scratch;
    zF_F1B3F8C2_sandReset(zT_36);
    zT_40 = mods.ptr;
    zT_41 = zT_40[mi];
    zT_42 = zT_41.ast_root;
    ast_root = zT_42;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_217 = 1;
    zT_219 = mi + (unsigned int)((unsigned int)zT_217);
    mi = zT_219;
    goto z_bb_1;
    z_bb_5:
    zT_46 = "MZ";
    zT_48 = 2;
    zT_47.ptr = zT_46;
    zT_47.len = zT_48;
    mz = zT_47;
    zT_49 = mz;
    zF_48AC7B3A_markerWrite(zT_49);
    goto z_bb_4;
    z_bb_6:
    zT_51 = ctx->store;
    zT_52 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_51, zT_52);
    zT_56 = ctx->store;
    zT_57 = ast_root;
    zT_59 = zF_152E19CB_astStoreNodeExtraCh(zT_56, zT_57);
    decls_n = zT_59;
    zT_61 = "AD";
    zT_63 = 2;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    ad = zT_62;
    zT_64 = ad;
    zF_48AC7B3A_markerWrite(zT_64);
    zT_66 = "DSE\n";
    zT_68 = 4;
    zT_67.ptr = zT_66;
    zT_67.len = zT_68;
    dse_m = zT_67;
    zT_69 = dse_m;
    zF_48AC7B3A_markerWrite(zT_69);
    zT_71 = mods.ptr;
    zT_72 = zT_71[mi];
    zT_73 = zT_72.source_file_id;
    src_fid = zT_73;
    zT_91 = ctx->alloc;
    zT_75 = &zT_91->scratch;
    zT_76 = ctx->resolved_types;
    zT_77 = ctx->diag;
    zT_78 = ctx->typereg;
    zT_79 = ctx->symbol_reg;
    zT_80 = ctx->store;
    zT_98 = mods.ptr;
    zT_99 = zT_98[mi];
    zT_81 = zT_99.id;
    zT_82 = src_fid;
    zT_83 = ctx->coercion_table;
    zT_84 = &ctx->enum_value_table;
    zT_85 = &ctx->error_code_registry;
    zT_86 = ctx->interner;
    zT_87 = &ctx->call_arg_types;
    zT_88 = &ctx->call_param_map;
    zT_89 = ctx->module_reg;
    zT_90 = &ctx->suspending_fns;
    zT_109 = zF_84ADA681_semanticAnalyzerIni(zT_75, zT_76, zT_77, zT_78, zT_79, zT_80, zT_81, zT_82, zT_83, zT_84, zT_85, zT_86, zT_87, zT_88, zT_89, zT_90);
    sa = zT_109;
    zT_111 = 0;
    zT_112 = (unsigned int)zT_111;
    di = zT_112;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_116 = ctx->store;
    zT_117 = ast_root;
    zT_121 = zF_B10B1BC1_astStoreNodeExtraCh(zT_116, zT_117, (unsigned int)((unsigned int)di));
    decl_idx = zT_121;
    zT_123 = ctx->store;
    zT_124 = decl_idx;
    zT_126 = zF_FCDD1D35_astStoreNodeAt(zT_123, zT_124);
    decl = zT_126;
    zT_128 = "DN";
    zT_130 = 2;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    dn = zT_129;
    zT_131 = dn;
    zF_48AC7B3A_markerWrite(zT_131);
    zT_132 = decl.kind;
    if ((unsigned char)(zT_132 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_214 = 1;
    zT_216 = di + (unsigned int)((unsigned int)zT_214);
    di = zT_216;
    goto z_bb_7;
    z_bb_11:
    zT_136 = decl.child_0;
    zT_137 = 0;
    if ((unsigned char)(zT_136 != (unsigned int)zT_137)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_166 = decl.kind;
    if ((unsigned char)(zT_166 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_139 = &frc;
    zT_145 = mods.ptr;
    zT_146 = zT_145[mi];
    zT_140 = zT_146.id;
    zT_141 = decl.child_0;
    zT_150 = mods.ptr;
    zT_151 = zT_150[mi];
    zT_143 = zT_151.source_file_id;
    zF_783226DA_resolveStmtTypes(zT_139, zT_140, zT_141, (unsigned int)(0), zT_143);
    goto z_bb_15;
    z_bb_15:
    zT_154 = "SA";
    zT_156 = 2;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    sa0 = zT_155;
    zT_157 = sa0;
    zF_48AC7B3A_markerWrite(zT_157);
    zT_158 = &sa;
    zT_159 = decl_idx;
    zF_406A2501_semanticAnalyzerRes(zT_158, zT_159);
    zT_162 = "sA";
    zT_164 = 2;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    sa1 = zT_163;
    zT_165 = sa1;
    zF_48AC7B3A_markerWrite(zT_165);
    goto z_bb_12;
    z_bb_16:
    zT_171 = decl.child_1;
    zT_170 = zT_171 != (unsigned int)(0);
    goto z_bb_18;
    z_bb_17:
    zT_170 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_170) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_175 = ctx->store;
    zT_176 = decl.child_1;
    zT_179 = zF_FCDD1D35_astStoreNodeAt(zT_175, zT_176);
    di_inn = zT_179;
    zT_180 = di_inn.kind;
    if ((unsigned char)(zT_180 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_207 = decl.kind;
    if ((unsigned char)(zT_207 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_31; else goto z_bb_32;
    z_bb_22:
    zT_184 = &sa;
    zT_185 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_184, zT_185);
    goto z_bb_23;
    z_bb_23:
    zT_187 = di_inn.kind;
    if ((unsigned char)(zT_187 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_192 = di_inn.flags;
    zT_191 = (unsigned char)(zT_192 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_191 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_191) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_197 = &sa;
    zT_198 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_197, zT_198);
    goto z_bb_28;
    z_bb_28:
    zT_200 = di_inn.kind;
    if ((unsigned char)(zT_200 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_204 = &sa;
    zT_205 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_204, zT_205);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_20;
    z_bb_31:
    zT_211 = &sa;
    zT_212 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_211, zT_212);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_20;
}

/* phase_StaticAnalyzers */
void zF_F3B55B42_phase_StaticAnalyze(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_C98AF326_CompilerCli zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    zT_C98AF326_CompilerCli zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    zT_C98AF326_CompilerCli zT_22;
    unsigned char zT_23;
    zT_072B53A6_ModuleRegistry* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29 = {0};
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_69057089_CompilerAlloc* zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_46;
    zT_060CD1EB_SymbolTable* zT_50 = 0;
    zT_7E2F335A_AnalyzerContext zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    zT_69057089_CompilerAlloc* zT_57;
    zT_3E40CD83_Sand* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_69057089_CompilerAlloc* zT_63;
    zT_3E40CD83_Sand* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_C98AF326_CompilerCli zT_67;
    unsigned char zT_68;
    unsigned char zT_69;
    int zT_70;
    int zT_72;
    unsigned char zT_74;
    zT_C98AF326_CompilerCli zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    int zT_78;
    int zT_80;
    unsigned char zT_82;
    zT_C98AF326_CompilerCli zT_83;
    unsigned char zT_84;
    unsigned char zT_85;
    int zT_86;
    int zT_88;
    unsigned char zT_90;
    zT_C98AF326_CompilerCli zT_91;
    unsigned char zT_92;
    unsigned char zT_93;
    int zT_94;
    int zT_96;
    unsigned char zT_98;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    zT_7E2F335A_AnalyzerContext* zT_103;
    unsigned int zT_104;
    int zT_106;
    unsigned int zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_060CD1EB_SymbolTable* sym_table;
    zT_7E2F335A_AnalyzerContext ac;
    zT_2 = "A\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = ctx->alloc;
    zT_9 = &zT_10->scratch;
    zF_CB5A85E9_sandResetPeak(zT_9);
    zT_12 = ctx->cli;
    zT_13 = zT_12.no_null_check;
    if ((unsigned char)(zT_13 != (unsigned char)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_17 = ctx->cli;
    zT_18 = zT_17.no_lifetime_check;
    zT_16 = zT_18 != (unsigned char)(1);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = ctx->cli;
    zT_23 = zT_22.no_leak_check;
    zT_21 = zT_23 != (unsigned char)(1);
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = ctx->module_reg;
    zT_29 = zF_3452C137_moduleRegistryGetMo(zT_27);
    mods = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    mi = zT_32;
    goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    zT_34 = mods.len;
    if ((unsigned char)(mi < zT_34)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = ctx->alloc;
    zT_36 = &zT_37->scratch;
    zF_F1B3F8C2_sandReset(zT_36);
    zT_40 = mods.ptr;
    zT_41 = zT_40[mi];
    zT_42 = zT_41.ast_root;
    ast_root = zT_42;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_106 = 1;
    zT_108 = mi + (unsigned int)((unsigned int)zT_106);
    mi = zT_108;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_46 = ctx->symbol_reg;
    zT_50 = zF_9B36C202_symbolRegistryGetTa(zT_46, (unsigned int)((unsigned int)mi));
    sym_table = zT_50;
    zT_53 = ctx->store;
    zT_52.store = zT_53;
    zT_54 = ctx->typereg;
    zT_52.registry = zT_54;
    zT_55 = ctx->interner;
    zT_52.interner = zT_55;
    zT_56 = ctx->diag;
    zT_52.diag = zT_56;
    zT_52.symbols = sym_table;
    zT_57 = ctx->alloc;
    zT_58 = &zT_57->scratch;
    zT_52.alloc = zT_58;
    zT_59 = 0;
    zT_52.current_fn_name = zT_59;
    zT_60 = 0;
    zT_52.defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_60;
    zT_61 = 0;
    zT_52.defer_queue_len = zT_61;
    zT_62 = 0;
    zT_52.defer_queue_cap = zT_62;
    zT_63 = ctx->alloc;
    zT_64 = &zT_63->scratch;
    zT_52.defer_queue_alloc = zT_64;
    zT_65 = 0;
    zT_52.current_depth = zT_65;
    zT_66 = 0;
    zT_52.null_analysis_mode = zT_66;
    zT_67 = ctx->cli;
    zT_68 = zT_67.no_null_check;
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_70 = 1;
    zT_69 = (unsigned char)zT_70;
    goto z_bb_17;
    z_bb_16:
    zT_72 = 0;
    zT_69 = (unsigned char)zT_72;
    goto z_bb_17;
    z_bb_17:
    zT_74 = (unsigned char)zT_69;
    zT_52.skip_null_check = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.no_lifetime_check;
    if (zT_76) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_78 = 1;
    zT_77 = (unsigned char)zT_78;
    goto z_bb_20;
    z_bb_19:
    zT_80 = 0;
    zT_77 = (unsigned char)zT_80;
    goto z_bb_20;
    z_bb_20:
    zT_82 = (unsigned char)zT_77;
    zT_52.skip_lifetime_check = zT_82;
    zT_83 = ctx->cli;
    zT_84 = zT_83.no_leak_check;
    if (zT_84) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_86 = 1;
    zT_85 = (unsigned char)zT_86;
    goto z_bb_23;
    z_bb_22:
    zT_88 = 0;
    zT_85 = (unsigned char)zT_88;
    goto z_bb_23;
    z_bb_23:
    zT_90 = (unsigned char)zT_85;
    zT_52.skip_doublefree_check = zT_90;
    zT_91 = ctx->cli;
    zT_92 = zT_91.warn_all;
    if (zT_92) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_94 = 1;
    zT_93 = (unsigned char)zT_94;
    goto z_bb_26;
    z_bb_25:
    zT_96 = 0;
    zT_93 = (unsigned char)zT_96;
    goto z_bb_26;
    z_bb_26:
    zT_98 = (unsigned char)zT_93;
    zT_52.warn_all = zT_98;
    zT_99 = zF_43C99FB3_onNullStmt;
    zT_52.on_stmt_cb = zT_99;
    zT_100 = 0;
    zT_52.in_defer_exec = zT_100;
    zT_101 = 0;
    zT_52.lifetime_analysis_mode = zT_101;
    zT_102 = 0;
    zT_52.doublefree_analysis_mode = zT_102;
    ac = zT_52;
    zT_103 = &ac;
    zT_104 = ast_root;
    zF_F697813C_runAllAnalyzers(zT_103, zT_104);
    goto z_bb_12;
}

/* phase_AsyncFrameSize */
void zF_9BC6214D_phase_AsyncFrameSiz(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_3D7259E2_SymbolRegistry* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_072B53A6_ModuleRegistry* zT_10;
    zT_338B7C76_TypeRegistry* zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_12;
    zT_A4CE86B7_U64ToU32Map* zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_A4CE86B7_U64ToU32Map* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_B687BB96_U32ArrayList* zT_19;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_69057089_CompilerAlloc* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_2 = "AFS\n";
    zT_4 = 4;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_22 = ctx->alloc;
    zT_6 = &zT_22->module;
    zT_7 = ctx->store;
    zT_8 = ctx->symbol_reg;
    zT_9 = ctx->interner;
    zT_10 = ctx->module_reg;
    zT_11 = ctx->typereg;
    zT_12 = ctx->resolved_types;
    zT_13 = &ctx->suspending_fns;
    zT_14 = &ctx->frame_sizes;
    zT_15 = &ctx->state_widths;
    zT_16 = &ctx->awaited_fns;
    zT_17 = &ctx->async_hidden_fns;
    zT_18 = &ctx->driver_targets;
    zT_19 = &ctx->parent_result_type_list;
    zT_20 = &ctx->parent_result_start;
    zT_21 = &ctx->parent_result_count;
    zF_7DBA21B2_asyncFrameSizeRun(zT_6, zT_7, zT_8, zT_9, zT_10, zT_11, zT_12, zT_13, zT_14, zT_15, zT_16, zT_17, zT_18, zT_19, zT_20, zT_21);
    return;
}

/* phase_LIRLowering */
void zF_1F21ABE7_phase_LIRLowering(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_4028D896_Arr_unsigned_char_2 zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_42BEFD80_anon_258018 zT_17;
    unsigned int zT_18;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_4028D896_Arr_unsigned_char_2 zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    zT_01BE9D46_AstValuePool zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_69057089_CompilerAlloc* zT_76;
    zT_CA01C129_LirSlotArrayList* zT_79;
    zT_846744CC_Arr_unsigned_char_5 zT_81;
    unsigned int zT_83;
    zT_C98AF326_CompilerCli zT_84;
    unsigned char zT_85;
    zT_C98AF326_CompilerCli zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned char zT_94;
    unsigned char* zT_97;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned char zT_103;
    unsigned int zT_105;
    unsigned char zT_106;
    unsigned int zT_108;
    unsigned char zT_109;
    unsigned int zT_111;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    unsigned int zT_119;
    unsigned char zT_121;
    unsigned char* zT_124;
    unsigned char zT_125;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_7E7544E4_LirStream* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    zT_3E40CD83_Sand* zT_132;
    int zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    zT_69057089_CompilerAlloc* zT_140;
    zT_6B356268_SemanticContext zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_3D7259E2_SymbolRegistry* zT_146;
    zT_8EED1867_ResolvedTypeTable* zT_147;
    zT_66E7D2EF_CoercionTable* zT_148;
    zT_F85C5DED_DiagnosticCollector* zT_149;
    unsigned char zT_150;
    zT_21D3708C_U32ToU32Map* zT_151;
    zT_21D3708C_U32ToU32Map* zT_152;
    zT_21D3708C_U32ToU32Map* zT_153;
    zT_77F6F59C_ComptimeFoldTable* zT_154;
    unsigned int zT_155;
    zT_C98AF326_CompilerCli zT_156;
    unsigned char zT_157;
    zT_A4CE86B7_U64ToU32Map* zT_158;
    zT_A4CE86B7_U64ToU32Map* zT_159;
    zT_A4CE86B7_U64ToU32Map* zT_160;
    unsigned char zT_161;
    zT_072B53A6_ModuleRegistry* zT_163;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_165 = {0};
    zT_3E40CD83_Sand* zT_167;
    zT_69057089_CompilerAlloc* zT_168;
    zT_B687BB96_U32ArrayList zT_170 = {0};
    unsigned char zT_172;
    int zT_174;
    unsigned int zT_175;
    unsigned int zT_177;
    zT_6E8D187B_ModuleEntry* zT_179;
    zT_6E8D187B_ModuleEntry zT_180;
    unsigned int zT_181;
    unsigned char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    zT_4028D896_Arr_unsigned_char_2 zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    int zT_195;
    unsigned char* zT_196;
    unsigned int zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199 = 0;
    unsigned int zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    unsigned char* zT_208;
    unsigned int zT_209;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    unsigned char* zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_213;
    unsigned int zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    zT_6E8D187B_ModuleEntry* zT_216;
    zT_6E8D187B_ModuleEntry zT_217;
    unsigned int zT_218;
    zT_4028D896_Arr_unsigned_char_2 zT_222;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    zT_6E8D187B_ModuleEntry* zT_226;
    zT_6E8D187B_ModuleEntry zT_227;
    int zT_231;
    unsigned char* zT_232;
    unsigned int zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned int zT_235 = 0;
    unsigned int zT_239;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_240;
    unsigned char* zT_244;
    unsigned int zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_247;
    zT_6B0A7D14_AstStore* zT_249;
    unsigned int zT_250;
    zT_6E8D187B_ModuleEntry* zT_252;
    zT_6E8D187B_ModuleEntry zT_253;
    zT_22A7C88B_AstNode zT_255 = {0};
    zT_8143F551_AstKind zT_256;
    unsigned char* zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    unsigned int zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    zT_6B0A7D14_AstStore* zT_266;
    unsigned int zT_267;
    zT_6E8D187B_ModuleEntry* zT_269;
    zT_6E8D187B_ModuleEntry zT_270;
    unsigned int zT_272 = 0;
    unsigned int zT_274;
    zT_4028D896_Arr_unsigned_char_2 zT_276;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    int zT_282;
    unsigned char* zT_283;
    unsigned int zT_284;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_285;
    unsigned int zT_286 = 0;
    unsigned int zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned char* zT_295;
    unsigned int zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    zT_6B0A7D14_AstStore* zT_299;
    unsigned int zT_300;
    zT_B687BB96_U32ArrayList* zT_301;
    zT_6E8D187B_ModuleEntry* zT_303;
    zT_6E8D187B_ModuleEntry zT_304;
    zT_6E8D187B_ModuleEntry* zT_306;
    zT_6E8D187B_ModuleEntry* zT_307;
    unsigned char zT_310;
    unsigned int zT_312;
    zT_6B0A7D14_AstStore* zT_316;
    unsigned int zT_317;
    zT_6E8D187B_ModuleEntry* zT_320;
    zT_6E8D187B_ModuleEntry zT_321;
    unsigned int zT_324 = 0;
    zT_6B0A7D14_AstStore* zT_326;
    unsigned int zT_327;
    zT_22A7C88B_AstNode zT_329 = {0};
    zT_8143F551_AstKind zT_331;
    unsigned int zT_332;
    zT_4028D896_Arr_unsigned_char_2 zT_334;
    unsigned int zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    int zT_340;
    unsigned char* zT_341;
    unsigned int zT_342;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    unsigned int zT_344 = 0;
    unsigned int zT_348;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_349;
    unsigned char* zT_353;
    unsigned int zT_354;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_355;
    unsigned char* zT_357;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_358;
    unsigned int zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    zT_8143F551_AstKind zT_361;
    unsigned char* zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    unsigned int zT_368;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_369;
    unsigned char zT_370;
    zT_6B0A7D14_AstStore* zT_377;
    zT_43C98C6F_anon_258051 zT_378;
    zT_243D6A41_FnProto* zT_379;
    zT_6B0A7D14_AstStore* zT_380;
    unsigned int zT_381;
    unsigned int zT_383 = 0;
    unsigned int zT_384;
    zT_243D6A41_FnProto zT_385;
    zT_6E8D187B_ModuleEntry* zT_387;
    zT_6E8D187B_ModuleEntry zT_388;
    unsigned int zT_389;
    unsigned int zT_397;
    zT_79FAE712_u64 zT_399;
    zT_A4CE86B7_U64ToU32Map* zT_400;
    zT_79FAE712_u64 zT_401;
    zT_6B356268_SemanticContext* zT_406;
    zT_3E40CD83_Sand* zT_407;
    zT_69057089_CompilerAlloc* zT_409;
    zT_02EB57B2_LirLowerer zT_411 = {0};
    zT_6E8D187B_ModuleEntry* zT_412;
    zT_6E8D187B_ModuleEntry zT_413;
    unsigned int zT_414;
    zT_072B53A6_ModuleRegistry* zT_415;
    zT_02EB57B2_LirLowerer* zT_417;
    unsigned int zT_418;
    zT_BBC23664_LirFunction zT_420 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_421;
    unsigned int zT_422;
    unsigned int zT_423;
    unsigned char zT_427 = 0;
    zT_3E40CD83_Sand* zT_429;
    zT_338B7C76_TypeRegistry* zT_430;
    zT_BBC23664_LirFunction* zT_431;
    zT_A4CE86B7_U64ToU32Map* zT_432;
    zT_A4CE86B7_U64ToU32Map* zT_433;
    zT_A4CE86B7_U64ToU32Map* zT_434;
    zT_A4CE86B7_U64ToU32Map* zT_435;
    zT_A4CE86B7_U64ToU32Map* zT_436;
    zT_A4CE86B7_U64ToU32Map* zT_437;
    zT_B687BB96_U32ArrayList* zT_438;
    zT_A4CE86B7_U64ToU32Map* zT_439;
    zT_A4CE86B7_U64ToU32Map* zT_440;
    zT_69057089_CompilerAlloc* zT_441;
    zT_3F3BF87A_AsyncFrameLayout zT_454 = {0};
    zT_3E40CD83_Sand* zT_455;
    zT_A4CE86B7_U64ToU32Map* zT_456;
    unsigned int zT_457;
    unsigned int zT_458;
    zT_3F3BF87A_AsyncFrameLayout zT_459;
    zT_69057089_CompilerAlloc* zT_460;
    zT_3E40CD83_Sand* zT_466;
    zT_69057089_CompilerAlloc* zT_469;
    zT_019EE88E_EU_932 zT_473 = {0};
    unsigned char zT_474;
    unsigned char* zT_475;
    zT_BBC23664_LirFunction* zT_478;
    zT_B687BB96_U32ArrayList* zT_479;
    unsigned char zT_484;
    zT_7E7544E4_LirStream* zT_486;
    zT_BBC23664_LirFunction zT_487;
    zT_E7714190_LirSlot zT_489 = {0};
    zT_CA01C129_LirSlotArrayList* zT_490;
    zT_E7714190_LirSlot zT_491;
    zT_3E40CD83_Sand* zT_494;
    zT_69057089_CompilerAlloc* zT_495;
    zT_8143F551_AstKind zT_497;
    unsigned char zT_501;
    zT_6B0A7D14_AstStore* zT_508;
    unsigned int zT_509;
    unsigned int zT_511 = 0;
    zT_3D7259E2_SymbolRegistry* zT_513;
    unsigned int zT_514;
    unsigned int zT_515;
    zT_6E8D187B_ModuleEntry* zT_517;
    zT_6E8D187B_ModuleEntry zT_518;
    zT_577B64BF_Opt_873 zT_520 = {0};
    unsigned char zT_521;
    zT_3C598AEF_SymbolKind zT_523;
    unsigned char zT_528;
    unsigned char zT_529;
    unsigned char zT_535;
    unsigned int zT_536;
    zT_6B0A7D14_AstStore* zT_540;
    unsigned int zT_541;
    zT_22A7C88B_AstNode zT_544 = {0};
    zT_8143F551_AstKind zT_545;
    unsigned char zT_549;
    zT_8143F551_AstKind zT_550;
    unsigned char zT_554;
    zT_8143F551_AstKind zT_555;
    unsigned char zT_559;
    unsigned int zT_562;
    zT_6B0A7D14_AstStore* zT_566;
    unsigned int zT_567;
    zT_22A7C88B_AstNode zT_570 = {0};
    zT_8143F551_AstKind zT_571;
    unsigned char zT_575;
    zT_8143F551_AstKind zT_576;
    zT_6B0A7D14_AstStore* zT_581;
    unsigned int zT_582;
    zT_22A7C88B_AstNode zT_585 = {0};
    zT_8143F551_AstKind zT_586;
    unsigned char zT_590;
    unsigned char zT_593;
    zT_6E8D187B_ModuleEntry* zT_600;
    zT_6E8D187B_ModuleEntry zT_601;
    unsigned int zT_602;
    zT_79FAE712_u64 zT_611;
    zT_A4CE86B7_U64ToU32Map* zT_612;
    zT_79FAE712_u64 zT_613;
    unsigned char zT_618;
    unsigned int zT_619;
    zT_6B0A7D14_AstStore* zT_623;
    unsigned int zT_624;
    zT_22A7C88B_AstNode zT_627 = {0};
    zT_8143F551_AstKind zT_628;
    unsigned char zT_632;
    unsigned char zT_635;
    zT_8EED1867_ResolvedTypeTable* zT_637;
    unsigned int zT_638;
    zT_BAEE192E_Opt_10 zT_640 = {0};
    unsigned char zT_642;
    unsigned int zT_643;
    zT_E1A783EF_GlobalDeclArrayList* zT_646;
    zT_54906056_ModuleGlobalDecl zT_647;
    zT_54906056_ModuleGlobalDecl zT_649;
    zT_6E8D187B_ModuleEntry* zT_650;
    zT_6E8D187B_ModuleEntry zT_651;
    unsigned int zT_652;
    unsigned int zT_654;
    zT_6B356268_SemanticContext* zT_658;
    zT_3E40CD83_Sand* zT_659;
    zT_69057089_CompilerAlloc* zT_661;
    zT_02EB57B2_LirLowerer zT_663 = {0};
    zT_6E8D187B_ModuleEntry* zT_664;
    zT_6E8D187B_ModuleEntry zT_665;
    unsigned int zT_666;
    zT_072B53A6_ModuleRegistry* zT_667;
    zT_02EB57B2_LirLowerer* zT_669;
    unsigned int zT_670;
    unsigned int zT_671;
    zT_A4CE86B7_U64ToU32Map* zT_672;
    zT_6E8D187B_ModuleEntry* zT_674;
    zT_6E8D187B_ModuleEntry zT_675;
    zT_6E8D187B_ModuleEntry* zT_677;
    zT_6E8D187B_ModuleEntry zT_678;
    zT_BBC23664_LirFunction zT_681 = {0};
    zT_7E7544E4_LirStream* zT_683;
    zT_BBC23664_LirFunction zT_684;
    zT_E7714190_LirSlot zT_686 = {0};
    zT_CA01C129_LirSlotArrayList* zT_687;
    zT_E7714190_LirSlot zT_688;
    zT_3E40CD83_Sand* zT_691;
    zT_69057089_CompilerAlloc* zT_692;
    zT_072B53A6_ModuleRegistry* zT_695;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_697 = {0};
    unsigned int zT_699;
    unsigned char zT_702;
    zT_6E8D187B_ModuleEntry* zT_703;
    int zT_704;
    zT_6E8D187B_ModuleEntry zT_705;
    unsigned int zT_706;
    zT_6B0A7D14_AstStore* zT_710;
    unsigned int zT_711;
    zT_6E8D187B_ModuleEntry* zT_713;
    int zT_714;
    zT_6E8D187B_ModuleEntry zT_715;
    zT_22A7C88B_AstNode zT_717 = {0};
    zT_8143F551_AstKind zT_718;
    zT_6B0A7D14_AstStore* zT_723;
    unsigned int zT_724;
    zT_6E8D187B_ModuleEntry* zT_726;
    int zT_727;
    zT_6E8D187B_ModuleEntry zT_728;
    unsigned int zT_730 = 0;
    unsigned int zT_732;
    unsigned char* zT_734;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_735;
    unsigned int zT_736;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_737;
    zT_6B0A7D14_AstStore* zT_741;
    unsigned int zT_742;
    zT_6B0A7D14_AstStore* zT_744;
    unsigned int zT_745;
    zT_6E8D187B_ModuleEntry* zT_748;
    int zT_749;
    zT_6E8D187B_ModuleEntry zT_750;
    unsigned int zT_753 = 0;
    zT_22A7C88B_AstNode zT_754 = {0};
    zT_8143F551_AstKind zT_756;
    unsigned int zT_757;
    zT_4028D896_Arr_unsigned_char_2 zT_759;
    unsigned int zT_761;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_762;
    int zT_765;
    unsigned char* zT_766;
    unsigned int zT_767;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_768;
    unsigned int zT_769 = 0;
    unsigned int zT_773;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_774;
    unsigned char* zT_778;
    unsigned int zT_779;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_780;
    unsigned char* zT_782;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_783;
    unsigned int zT_784;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_785;
    unsigned int zT_787;
    unsigned char* zT_789;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_790;
    unsigned int zT_791;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_792;
    int zT_793;
    unsigned int zT_795;
    unsigned int zT_797;
    unsigned int zT_798;
    unsigned int* zT_801;
    unsigned int zT_802;
    zT_BBC23664_LirFunction* zT_804;
    zT_A4CE86B7_U64ToU32Map* zT_805;
    unsigned int zT_806;
    unsigned int zT_807;
    zT_06CE572C_Opt_407 zT_811 = {0};
    unsigned char zT_812;
    zT_5839647A_AsyncTransformCtx zT_815;
    zT_69057089_CompilerAlloc* zT_816;
    zT_3E40CD83_Sand* zT_817;
    zT_338B7C76_TypeRegistry* zT_818;
    zT_D3EB6303_StringInterner* zT_819;
    zT_7E7544E4_LirStream* zT_820;
    zT_CA01C129_LirSlotArrayList* zT_821;
    zT_A4CE86B7_U64ToU32Map* zT_822;
    zT_C98AF326_CompilerCli zT_823;
    unsigned char zT_824;
    zT_A4CE86B7_U64ToU32Map* zT_825;
    zT_A4CE86B7_U64ToU32Map* zT_826;
    zT_F85C5DED_DiagnosticCollector* zT_827;
    zT_BBC23664_LirFunction* zT_828;
    zT_5839647A_AsyncTransformCtx* zT_829;
    unsigned char zT_831 = 0;
    unsigned int zT_833;
    zT_3E40CD83_Sand* zT_834;
    zT_69057089_CompilerAlloc* zT_835;
    zT_5AB29387_CompilerContext* zT_837;
    zT_7E7544E4_LirStream* zT_838;
    unsigned char zT_840;
    unsigned char* zT_844;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_845;
    unsigned int zT_846;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_847;
    zT_D3EB6303_StringInterner* zT_848;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_849;
    zT_072B53A6_ModuleRegistry* zT_850;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_852 = {0};
    unsigned int zT_854 = 0;
    unsigned char* zT_858;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_859;
    unsigned int zT_860;
    unsigned char* zT_862;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_863;
    unsigned int zT_864;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_866;
    unsigned int zT_867;
    unsigned int zT_868;
    unsigned int zT_869;
    zT_D3EB6303_StringInterner* zT_871;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_872;
    int zT_875;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_876;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_878 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_879;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_885;
    unsigned int zT_894 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnmsg;
    zT_4028D896_Arr_unsigned_char_2 ln_buf;
    unsigned int ln_len;
    unsigned int ln_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lemsg;
    zT_4028D896_Arr_unsigned_char_2 le_buf;
    unsigned int le_len;
    unsigned int le_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnl;
    zT_846744CC_Arr_unsigned_char_5 spill_path;
    unsigned int sp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmp_name;
    unsigned int ti;
    zT_6B356268_SemanticContext sem_ctx;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_B687BB96_U32ArrayList async_retained;
    unsigned char async_pending;
    unsigned int mi;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm;
    zT_4028D896_Arr_unsigned_char_2 mi_buf;
    unsigned int mi_len;
    unsigned int mi2_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u msep;
    unsigned int arl_i;
    zT_4028D896_Arr_unsigned_char_2 ar_buf;
    unsigned int ar_len;
    unsigned int ar_start;
    zT_22A7C88B_AstNode root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr;
    unsigned int decls_n;
    unsigned int decl_len;
    zT_4028D896_Arr_unsigned_char_2 dcount_buf;
    unsigned int dcount_len;
    unsigned int dstart;
    unsigned char mod_has_ri;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int raw_k;
    zT_4028D896_Arr_unsigned_char_2 rbuf;
    unsigned int rlen;
    unsigned int rstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp2;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf;
    zT_243D6A41_FnProto fexp_proto;
    zT_79FAE712_u64 fexp_key;
    zT_02EB57B2_LirLowerer lowerer;
    zT_BBC23664_LirFunction lf;
    zT_3F3BF87A_AsyncFrameLayout async_layout;
    unsigned char* lf_raw;
    zT_E7714190_LirSlot slot;
    zT_BBC23664_LirFunction* lf_ptr;
    unsigned int gv_name;
    zT_577B64BF_Opt_873 gv_sym;
    zT_3A105EF1_Symbol* gvs;
    unsigned char gv_is_storage;
    zT_22A7C88B_AstNode gv_init;
    zT_22A7C88B_AstNode gv_init3;
    zT_22A7C88B_AstNode gv_fb;
    zT_79FAE712_u64 gexp_key;
    unsigned char gv_has_ri;
    zT_22A7C88B_AstNode gv_init2;
    zT_BAEE192E_Opt_10 gv_rt;
    unsigned int gv_tid;
    unsigned int grt;
    zT_02EB57B2_LirLowerer ilowerer;
    zT_BBC23664_LirFunction imf;
    zT_E7714190_LirSlot islot;
    zT_DDCD424B_Slice_zT_6E8D187B_M amods;
    zT_22A7C88B_AstNode ar;
    unsigned int adl_n;
    unsigned int adi;
    zT_8F083A69_Slice_zT_0B42B2F8_u al;
    zT_22A7C88B_AstNode ad;
    unsigned int ak;
    zT_4028D896_Arr_unsigned_char_2 ab;
    unsigned int alen;
    unsigned int ast;
    zT_8F083A69_Slice_zT_0B42B2F8_u asp;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_BBC23664_LirFunction* lf2;
    zT_3F3BF87A_AsyncFrameLayout* lay2;
    zT_5839647A_AsyncTransformCtx async_ctx2;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = "L\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = "nodes=";
    zT_9 = 6;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    lnmsg = zT_8;
    zT_10 = lnmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ln_buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_16 = ctx->store;
    zT_17 = zT_16->nodes;
    zT_18 = zT_17.len;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)ln_buf) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = zT_23;
    zT_25.len = zT_24;
    zT_15 = zT_25;
    zT_26 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_18), zT_15);
    ln_len = zT_26;
    zT_30 = (unsigned int)(19) - (unsigned int)((unsigned int)ln_len);
    ln_start = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)ln_buf) + ln_start;
    zT_36 = (unsigned int)(19) - ln_start;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = " extra=";
    zT_41 = 7;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    lemsg = zT_40;
    zT_42 = lemsg;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        le_buf[_i] = zT_44[_i];
        _i++;
    }
}
    zT_48 = ctx->store;
    zT_49 = zT_48->extra_children;
    zT_50 = zT_49.len;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)le_buf) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_47 = zT_57;
    zT_58 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_50), zT_47);
    le_len = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)le_len);
    le_start = zT_62;
    zT_67 = (unsigned char*)((unsigned char*)le_buf) + le_start;
    zT_68 = (unsigned int)(19) - le_start;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zF_48AC7B3A_markerWrite(zT_63);
    zT_71 = "\n";
    zT_73 = 1;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    lnl = zT_72;
    zT_74 = lnl;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_76 = ctx->alloc;
    zT_75 = &zT_76->scratch;
    zF_F1B3F8C2_sandReset(zT_75);
    zT_79 = &ctx->lir_slots;
    zT_79->len = (unsigned int)(0);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_81[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        spill_path[_i] = zT_81[_i];
        _i++;
    }
}
    zT_83 = 0;
    sp_len = zT_83;
    zT_84 = ctx->cli;
    zT_85 = zT_84.output_dir_set;
    if (zT_85) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_87 = ctx->cli;
    zT_88 = zT_87.output_dir;
    od = zT_88;
    zT_90 = 0;
    oi = zT_90;
    goto z_bb_4;
    z_bb_2:
    zT_113 = ".zig1_lir.tmp";
    zT_115 = 13;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    tmp_name = zT_114;
    zT_117 = 0;
    ti = zT_117;
    goto z_bb_11;
    z_bb_3:
    zT_106 = 46;
    spill_path[sp_len] = zT_106;
    zT_108 = sp_len + (unsigned int)(1);
    sp_len = zT_108;
    zT_109 = 47;
    spill_path[sp_len] = zT_109;
    zT_111 = sp_len + (unsigned int)(1);
    sp_len = zT_111;
    goto z_bb_2;
    z_bb_4:
    zT_92 = od.len;
    if ((unsigned char)(oi < zT_92)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_97 = od.ptr;
    zT_98 = zT_97[oi];
    spill_path[sp_len] = zT_98;
    zT_100 = sp_len + (unsigned int)(1);
    sp_len = zT_100;
    goto z_bb_7;
    z_bb_6:
    zT_103 = 47;
    spill_path[sp_len] = zT_103;
    zT_105 = sp_len + (unsigned int)(1);
    sp_len = zT_105;
    goto z_bb_2;
    z_bb_7:
    zT_102 = oi + (unsigned int)(1);
    oi = zT_102;
    goto z_bb_4;
    z_bb_8:
    zT_94 = sp_len < (unsigned int)(511);
    goto z_bb_10;
    z_bb_9:
    zT_94 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_94) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    zT_119 = tmp_name.len;
    if ((unsigned char)(ti < zT_119)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_124 = tmp_name.ptr;
    zT_125 = zT_124[ti];
    spill_path[sp_len] = zT_125;
    zT_127 = sp_len + (unsigned int)(1);
    sp_len = zT_127;
    goto z_bb_14;
    z_bb_13:
    zT_130 = &ctx->lir_stream;
    zT_136 = 0;
    zT_137 = (unsigned char*)((unsigned char*)spill_path) + zT_136;
    zT_138 = sp_len - zT_136;
    zT_139.ptr = zT_137;
    zT_139.len = zT_138;
    zT_131 = zT_139;
    zT_140 = ctx->alloc;
    zT_132 = &zT_140->emission;
    zF_B0B74E20_lirStreamBeginWrite(zT_130, zT_131, zT_132);
    zT_144 = ctx->store;
    zT_143.store = zT_144;
    zT_145 = ctx->typereg;
    zT_143.registry = zT_145;
    zT_146 = ctx->symbol_reg;
    zT_143.symbol_tables = zT_146;
    zT_147 = ctx->resolved_types;
    zT_143.resolved_types = zT_147;
    zT_148 = ctx->coercion_table;
    zT_143.coercions = zT_148;
    zT_149 = ctx->diag;
    zT_143.diag = zT_149;
    zT_150 = 1;
    zT_143.has_symbols = zT_150;
    zT_151 = &ctx->enum_value_table;
    zT_143.enum_value_table = zT_151;
    zT_152 = &ctx->error_code_registry;
    zT_143.error_code_registry = zT_152;
    zT_153 = &ctx->call_arg_types;
    zT_143.call_arg_types = zT_153;
    zT_154 = &ctx->comptime_folds;
    zT_143.comptime_folds = zT_154;
    zT_155 = 0;
    zT_143.source_file_id = zT_155;
    zT_156 = ctx->cli;
    zT_157 = zT_156.safe_checks;
    zT_143.safe_checks = zT_157;
    zT_158 = &ctx->suspending_fns;
    zT_143.suspending_fns = zT_158;
    zT_159 = &ctx->frame_sizes;
    zT_143.frame_sizes = zT_159;
    zT_160 = &ctx->state_widths;
    zT_143.state_widths = zT_160;
    zT_161 = 0;
    zT_143.print_value_lowered = zT_161;
    sem_ctx = zT_143;
    zT_163 = ctx->module_reg;
    zT_165 = zF_3452C137_moduleRegistryGetMo(zT_163);
    mods = zT_165;
    zT_168 = ctx->alloc;
    zT_167 = &zT_168->module;
    zT_170 = zF_8E537D0C_u32ArrayListInit(zT_167);
    async_retained = zT_170;
    zT_172 = 0;
    async_pending = zT_172;
    zT_174 = 0;
    zT_175 = (unsigned int)zT_174;
    mi = zT_175;
    goto z_bb_18;
    z_bb_14:
    zT_129 = ti + (unsigned int)(1);
    ti = zT_129;
    goto z_bb_11;
    z_bb_15:
    zT_121 = sp_len < (unsigned int)(511);
    goto z_bb_17;
    z_bb_16:
    zT_121 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_121) goto z_bb_12; else goto z_bb_13;
    z_bb_18:
    zT_177 = mods.len;
    if ((unsigned char)(mi < zT_177)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_179 = mods.ptr;
    zT_180 = zT_179[mi];
    zT_181 = zT_180.source_file_id;
    sem_ctx.source_file_id = zT_181;
    zT_183 = "M";
    zT_185 = 1;
    zT_184.ptr = zT_183;
    zT_184.len = zT_185;
    mm = zT_184;
    zT_186 = mm;
    zF_48AC7B3A_markerWrite(zT_186);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_188[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        mi_buf[_i] = zT_188[_i];
        _i++;
    }
}
    zT_195 = 0;
    zT_196 = (unsigned char*)((unsigned char*)mi_buf) + zT_195;
    zT_197 = (unsigned int)(20) - zT_195;
    zT_198.ptr = zT_196;
    zT_198.len = zT_197;
    zT_191 = zT_198;
    zT_199 = zF_A7504564_itoa((unsigned int)((unsigned int)mi), zT_191);
    mi_len = zT_199;
    zT_203 = (unsigned int)(19) - (unsigned int)((unsigned int)mi_len);
    mi2_start = zT_203;
    zT_208 = (unsigned char*)((unsigned char*)mi_buf) + mi2_start;
    zT_209 = (unsigned int)(19) - mi2_start;
    zT_210.ptr = zT_208;
    zT_210.len = zT_209;
    zT_204 = zT_210;
    zF_48AC7B3A_markerWrite(zT_204);
    zT_212 = ":";
    zT_214 = 1;
    zT_213.ptr = zT_212;
    zT_213.len = zT_214;
    msep = zT_213;
    zT_215 = msep;
    zF_48AC7B3A_markerWrite(zT_215);
    zT_216 = mods.ptr;
    zT_217 = zT_216[mi];
    zT_218 = zT_217.ast_root;
    if ((unsigned char)(zT_218 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_797 = 0;
    arl_i = zT_797;
    goto z_bb_102;
    z_bb_21:
    zT_793 = 1;
    zT_795 = mi + (unsigned int)((unsigned int)zT_793);
    mi = zT_795;
    goto z_bb_18;
    z_bb_22:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_222[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ar_buf[_i] = zT_222[_i];
        _i++;
    }
}
    zT_226 = mods.ptr;
    zT_227 = zT_226[mi];
    zT_224 = zT_227.ast_root;
    zT_231 = 0;
    zT_232 = (unsigned char*)((unsigned char*)ar_buf) + zT_231;
    zT_233 = (unsigned int)(20) - zT_231;
    zT_234.ptr = zT_232;
    zT_234.len = zT_233;
    zT_225 = zT_234;
    zT_235 = zF_A7504564_itoa(zT_224, zT_225);
    ar_len = zT_235;
    zT_239 = (unsigned int)(19) - (unsigned int)((unsigned int)ar_len);
    ar_start = zT_239;
    zT_244 = (unsigned char*)((unsigned char*)ar_buf) + ar_start;
    zT_245 = (unsigned int)(19) - ar_start;
    zT_246.ptr = zT_244;
    zT_246.len = zT_245;
    zT_240 = zT_246;
    zF_48AC7B3A_markerWrite(zT_240);
    zT_247 = msep;
    zF_48AC7B3A_markerWrite(zT_247);
    zT_249 = ctx->store;
    zT_252 = mods.ptr;
    zT_253 = zT_252[mi];
    zT_250 = zT_253.ast_root;
    zT_255 = zF_FCDD1D35_astStoreNodeAt(zT_249, zT_250);
    root = zT_255;
    zT_256 = root.kind;
    if ((unsigned char)(zT_256 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_261 = "R";
    zT_263 = 1;
    zT_262.ptr = zT_261;
    zT_262.len = zT_263;
    mr = zT_262;
    zT_264 = mr;
    zF_48AC7B3A_markerWrite(zT_264);
    zT_266 = ctx->store;
    zT_269 = mods.ptr;
    zT_270 = zT_269[mi];
    zT_267 = zT_270.ast_root;
    zT_272 = zF_152E19CB_astStoreNodeExtraCh(zT_266, zT_267);
    decls_n = zT_272;
    zT_274 = (unsigned int)decls_n;
    decl_len = zT_274;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_276[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dcount_buf[_i] = zT_276[_i];
        _i++;
    }
}
    zT_278 = decl_len;
    zT_282 = 0;
    zT_283 = (unsigned char*)((unsigned char*)dcount_buf) + zT_282;
    zT_284 = (unsigned int)(20) - zT_282;
    zT_285.ptr = zT_283;
    zT_285.len = zT_284;
    zT_279 = zT_285;
    zT_286 = zF_A7504564_itoa(zT_278, zT_279);
    dcount_len = zT_286;
    zT_290 = (unsigned int)(19) - (unsigned int)((unsigned int)dcount_len);
    dstart = zT_290;
    zT_295 = (unsigned char*)((unsigned char*)dcount_buf) + dstart;
    zT_296 = (unsigned int)(19) - dstart;
    zT_297.ptr = zT_295;
    zT_297.len = zT_296;
    zT_291 = zT_297;
    zF_48AC7B3A_markerWrite(zT_291);
    zT_298 = msep;
    zF_48AC7B3A_markerWrite(zT_298);
    zT_299 = ctx->store;
    zT_303 = mods.ptr;
    zT_304 = zT_303[mi];
    zT_300 = zT_304.ast_root;
    zT_306 = mods.ptr;
    zT_307 = zT_306 + mi;
    zT_301 = &zT_307->c_includes;
    zF_7D71E4ED_moduleRegistryColle(zT_299, zT_300, zT_301);
    zT_310 = 0;
    mod_has_ri = zT_310;
    zT_312 = 0;
    di = zT_312;
    goto z_bb_26;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_316 = ctx->store;
    zT_320 = mods.ptr;
    zT_321 = zT_320[mi];
    zT_317 = zT_321.ast_root;
    zT_324 = zF_B10B1BC1_astStoreNodeExtraCh(zT_316, zT_317, (unsigned int)((unsigned int)di));
    decl_idx = zT_324;
    zT_326 = ctx->store;
    zT_327 = decl_idx;
    zT_329 = zF_FCDD1D35_astStoreNodeAt(zT_326, zT_327);
    decl = zT_329;
    zT_331 = decl.kind;
    zT_332 = (unsigned int)zT_331;
    raw_k = zT_332;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_334[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rbuf[_i] = zT_334[_i];
        _i++;
    }
}
    zT_336 = raw_k;
    zT_340 = 0;
    zT_341 = (unsigned char*)((unsigned char*)rbuf) + zT_340;
    zT_342 = (unsigned int)(20) - zT_340;
    zT_343.ptr = zT_341;
    zT_343.len = zT_342;
    zT_337 = zT_343;
    zT_344 = zF_A7504564_itoa(zT_336, zT_337);
    rlen = zT_344;
    zT_348 = (unsigned int)(19) - (unsigned int)((unsigned int)rlen);
    rstart = zT_348;
    zT_353 = (unsigned char*)((unsigned char*)rbuf) + rstart;
    zT_354 = (unsigned int)(19) - rstart;
    zT_355.ptr = zT_353;
    zT_355.len = zT_354;
    zT_349 = zT_355;
    zF_48AC7B3A_markerWrite(zT_349);
    zT_357 = " ";
    zT_359 = 1;
    zT_358.ptr = zT_357;
    zT_358.len = zT_359;
    sp2 = zT_358;
    zT_360 = sp2;
    zF_48AC7B3A_markerWrite(zT_360);
    zT_361 = decl.kind;
    if ((unsigned char)(zT_361 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_30; else goto z_bb_32;
    z_bb_28:
    if ((unsigned char)(mod_has_ri != (unsigned char)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_29:
    zT_654 = di + (unsigned int)(1);
    di = zT_654;
    goto z_bb_26;
    z_bb_30:
    zT_366 = "F";
    zT_368 = 1;
    zT_367.ptr = zT_366;
    zT_367.len = zT_368;
    mf = zT_367;
    zT_369 = mf;
    zF_48AC7B3A_markerWrite(zT_369);
    zT_370 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_370) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_497 = decl.kind;
    if ((unsigned char)(zT_497 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_43; else goto z_bb_44;
    z_bb_33:
    zT_377 = ctx->store;
    zT_378 = zT_377->fn_protos;
    zT_379 = zT_378.items;
    zT_380 = ctx->store;
    zT_381 = decl_idx;
    zT_383 = zF_8BA26B9E_astStoreNodePayload(zT_380, zT_381);
    zT_384 = (unsigned int)zT_383;
    zT_385 = zT_379[zT_384];
    fexp_proto = zT_385;
    zT_387 = mods.ptr;
    zT_388 = zT_387[mi];
    zT_389 = zT_388.id;
    zT_397 = fexp_proto.name_id;
    zT_399 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_389) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(0)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_397);
    fexp_key = zT_399;
    zT_400 = &ctx->exported;
    zT_401 = fexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_400, zT_401, (unsigned int)(1));
    goto z_bb_34;
    z_bb_34:
    zT_406 = &sem_ctx;
    zT_409 = ctx->alloc;
    zT_407 = &zT_409->scratch;
    zT_411 = zF_ADD4254B_lowererInit(zT_406, zT_407);
    lowerer = zT_411;
    zT_412 = mods.ptr;
    zT_413 = zT_412[mi];
    zT_414 = zT_413.id;
    lowerer.module_id = zT_414;
    zT_415 = ctx->module_reg;
    lowerer.module_reg = zT_415;
    zT_417 = &lowerer;
    zT_418 = decl_idx;
    zT_420 = zF_B53F5F2E_lowerFn(zT_417, zT_418);
    lf = zT_420;
    zT_421 = &ctx->suspending_fns;
    zT_422 = lf.module_id;
    zT_423 = lf.name_id;
    zT_427 = zF_7C7E43BF_asyncIsSuspending(zT_421, zT_422, zT_423);
    if (zT_427) goto z_bb_35; else goto z_bb_37;
    z_bb_35:
    zT_441 = ctx->alloc;
    zT_429 = &zT_441->scratch;
    zT_430 = ctx->typereg;
    zT_431 = &lf;
    zT_432 = &ctx->suspending_fns;
    zT_433 = &ctx->frame_sizes;
    zT_434 = &ctx->state_widths;
    zT_435 = &ctx->awaited_fns;
    zT_436 = &ctx->async_hidden_fns;
    zT_437 = &ctx->driver_targets;
    zT_438 = &ctx->parent_result_type_list;
    zT_439 = &ctx->parent_result_start;
    zT_440 = &ctx->parent_result_count;
    zT_454 = zF_28031796_asyncLayoutFrame(zT_429, zT_430, zT_431, zT_432, zT_433, zT_434, zT_435, zT_436, zT_437, zT_438, zT_439, zT_440);
    async_layout = zT_454;
    zT_460 = ctx->alloc;
    zT_455 = &zT_460->scratch;
    zT_456 = &ctx->async_layouts;
    zT_457 = lf.module_id;
    zT_458 = lf.name_id;
    zT_459 = async_layout;
    zF_17324878_asyncLayoutPublish(zT_455, zT_456, zT_457, zT_458, zT_459);
    zT_469 = ctx->alloc;
    zT_466 = &zT_469->scratch;
    zT_473 = zF_1395EB68_sandAlloc(zT_466, (unsigned int)(124), (unsigned int)(4));
    zT_474 = zT_473.is_error;
    if (zT_474) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_486 = &ctx->lir_stream;
    zT_487 = lf;
    zT_489 = zF_9F47D5E4_lirStreamAppend(zT_486, zT_487);
    slot = zT_489;
    zT_490 = &ctx->lir_slots;
    zT_491 = slot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_490, zT_491);
    if ((unsigned char)(!async_pending)) goto z_bb_41; else goto z_bb_42;
    z_bb_38:
    pal_trap();
    z_bb_39:
    zT_475 = zT_473.data.payload;
    goto z_bb_40;
    z_bb_40:
    lf_raw = zT_475;
    zT_478 = (zT_BBC23664_LirFunction*)lf_raw;
    lf_ptr = zT_478;
    *lf_ptr = lf;
    zT_479 = &async_retained;
    zF_62F717A2_u32ArrayListAppend(zT_479, (unsigned int)((unsigned int)(unsigned int)((unsigned int)lf_ptr)));
    zT_484 = 1;
    async_pending = zT_484;
    goto z_bb_36;
    z_bb_41:
    zT_495 = ctx->alloc;
    zT_494 = &zT_495->scratch;
    zF_F1B3F8C2_sandReset(zT_494);
    goto z_bb_42;
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_501 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_501) & (unsigned short)(4)) == (unsigned short)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_31;
    z_bb_45:
    zT_508 = ctx->store;
    zT_509 = decl_idx;
    zT_511 = zF_8BA26B9E_astStoreNodePayload(zT_508, zT_509);
    gv_name = zT_511;
    zT_513 = ctx->symbol_reg;
    zT_517 = mods.ptr;
    zT_518 = zT_517[mi];
    zT_514 = zT_518.id;
    zT_515 = gv_name;
    zT_520 = zF_A398987E_symbolRegistryQuali(zT_513, zT_514, zT_515);
    gv_sym = zT_520;
    zT_521 = gv_sym.has_value;
    if (zT_521) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_44;
    z_bb_47:
    gvs = gv_sym.value;
    zT_523 = gvs->kind;
    if ((unsigned char)(zT_523 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    zT_528 = 0;
    gv_is_storage = zT_528;
    zT_529 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_529) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_51; else goto z_bb_53;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_535 = 1;
    gv_is_storage = zT_535;
    goto z_bb_52;
    z_bb_52:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_64; else goto z_bb_65;
    z_bb_53:
    zT_536 = decl.child_1;
    if ((unsigned char)(zT_536 != (unsigned int)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_540 = ctx->store;
    zT_541 = decl.child_1;
    zT_544 = zF_FCDD1D35_astStoreNodeAt(zT_540, zT_541);
    gv_init = zT_544;
    zT_545 = gv_init.kind;
    if ((unsigned char)(zT_545 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_550 = gv_init.kind;
    zT_549 = zT_550 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal);
    goto z_bb_58;
    z_bb_57:
    zT_549 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_549) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_555 = gv_init.kind;
    zT_554 = zT_555 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_61;
    z_bb_60:
    zT_554 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_554) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_559 = 1;
    gv_is_storage = zT_559;
    goto z_bb_63;
    z_bb_63:
    goto z_bb_55;
    z_bb_64:
    zT_562 = decl.child_1;
    if ((unsigned char)(zT_562 != (unsigned int)(0))) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_74; else goto z_bb_75;
    z_bb_66:
    zT_566 = ctx->store;
    zT_567 = decl.child_1;
    zT_570 = zF_FCDD1D35_astStoreNodeAt(zT_566, zT_567);
    gv_init3 = zT_570;
    zT_571 = gv_init3.kind;
    if ((unsigned char)(zT_571 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_575 = 0;
    gv_is_storage = zT_575;
    goto z_bb_69;
    z_bb_69:
    zT_576 = gv_init3.kind;
    if ((unsigned char)(zT_576 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_581 = ctx->store;
    zT_582 = gv_init3.child_0;
    zT_585 = zF_FCDD1D35_astStoreNodeAt(zT_581, zT_582);
    gv_fb = zT_585;
    zT_586 = gv_fb.kind;
    if ((unsigned char)(zT_586 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    goto z_bb_67;
    z_bb_72:
    zT_590 = 0;
    gv_is_storage = zT_590;
    goto z_bb_73;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    zT_593 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_593) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    goto z_bb_50;
    z_bb_76:
    zT_600 = mods.ptr;
    zT_601 = zT_600[mi];
    zT_602 = zT_601.id;
    zT_611 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_602) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(4294967296ULL)) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_611;
    zT_612 = &ctx->exported;
    zT_613 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_612, zT_613, (unsigned int)(1));
    goto z_bb_77;
    z_bb_77:
    zT_618 = 0;
    gv_has_ri = zT_618;
    zT_619 = decl.child_1;
    if ((unsigned char)(zT_619 != (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_623 = ctx->store;
    zT_624 = decl.child_1;
    zT_627 = zF_FCDD1D35_astStoreNodeAt(zT_623, zT_624);
    gv_init2 = zT_627;
    zT_628 = gv_init2.kind;
    if ((unsigned char)(zT_628 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    if ((unsigned char)(gv_has_ri == (unsigned char)(1))) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    zT_632 = 1;
    gv_has_ri = zT_632;
    goto z_bb_81;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_635 = 1;
    mod_has_ri = zT_635;
    goto z_bb_83;
    z_bb_83:
    zT_637 = ctx->resolved_types;
    zT_638 = decl_idx;
    zT_640 = zF_999DCF51_resolvedTypeTableGe(zT_637, zT_638);
    gv_rt = zT_640;
    zT_642 = gv_rt.has_value;
    if (zT_642) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    grt = gv_rt.value;
    zT_643 = grt;
    goto z_bb_86;
    z_bb_85:
    zT_643 = 18;
    goto z_bb_86;
    z_bb_86:
    gv_tid = zT_643;
    zT_646 = &ctx->global_decls;
    zT_649.name_id = gv_name;
    zT_650 = mods.ptr;
    zT_651 = zT_650[mi];
    zT_652 = zT_651.id;
    zT_649.module_id = zT_652;
    zT_649.type_id = gv_tid;
    zT_649.has_runtime_init = gv_has_ri;
    zT_647 = zT_649;
    zF_F2C82CE7_globalDeclArrayList(zT_646, zT_647);
    goto z_bb_75;
    z_bb_87:
    zT_658 = &sem_ctx;
    zT_661 = ctx->alloc;
    zT_659 = &zT_661->scratch;
    zT_663 = zF_ADD4254B_lowererInit(zT_658, zT_659);
    ilowerer = zT_663;
    zT_664 = mods.ptr;
    zT_665 = zT_664[mi];
    zT_666 = zT_665.id;
    ilowerer.module_id = zT_666;
    zT_667 = ctx->module_reg;
    ilowerer.module_reg = zT_667;
    zT_669 = &ilowerer;
    zT_674 = mods.ptr;
    zT_675 = zT_674[mi];
    zT_670 = zT_675.ast_root;
    zT_677 = mods.ptr;
    zT_678 = zT_677[mi];
    zT_671 = zT_678.id;
    zT_672 = &ctx->module_init_deps;
    zT_681 = zF_552B231C_lowerModuleInit(zT_669, zT_670, zT_671, zT_672);
    imf = zT_681;
    zT_683 = &ctx->lir_stream;
    zT_684 = imf;
    zT_686 = zF_9F47D5E4_lirStreamAppend(zT_683, zT_684);
    islot = zT_686;
    zT_687 = &ctx->lir_slots;
    zT_688 = islot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_687, zT_688);
    if ((unsigned char)(!async_pending)) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_695 = ctx->module_reg;
    zT_697 = zF_3452C137_moduleRegistryGetMo(zT_695);
    amods = zT_697;
    zT_699 = amods.len;
    if ((unsigned char)(zT_699 > (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_89:
    zT_692 = ctx->alloc;
    zT_691 = &zT_692->scratch;
    zF_F1B3F8C2_sandReset(zT_691);
    goto z_bb_90;
    z_bb_90:
    goto z_bb_88;
    z_bb_91:
    zT_703 = amods.ptr;
    zT_704 = 0;
    zT_705 = zT_703[zT_704];
    zT_706 = zT_705.ast_root;
    zT_702 = zT_706 != (unsigned int)(0);
    goto z_bb_93;
    z_bb_92:
    zT_702 = 0;
    goto z_bb_93;
    z_bb_93:
    if (zT_702) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_710 = ctx->store;
    zT_713 = amods.ptr;
    zT_714 = 0;
    zT_715 = zT_713[zT_714];
    zT_711 = zT_715.ast_root;
    zT_717 = zF_FCDD1D35_astStoreNodeAt(zT_710, zT_711);
    ar = zT_717;
    zT_718 = ar.kind;
    if ((unsigned char)(zT_718 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_96; else goto z_bb_97;
    z_bb_95:
    goto z_bb_25;
    z_bb_96:
    zT_723 = ctx->store;
    zT_726 = amods.ptr;
    zT_727 = 0;
    zT_728 = zT_726[zT_727];
    zT_724 = zT_728.ast_root;
    zT_730 = zF_152E19CB_astStoreNodeExtraCh(zT_723, zT_724);
    adl_n = zT_730;
    zT_732 = 0;
    adi = zT_732;
    zT_734 = "A0";
    zT_736 = 2;
    zT_735.ptr = zT_734;
    zT_735.len = zT_736;
    al = zT_735;
    zT_737 = al;
    zF_48AC7B3A_markerWrite(zT_737);
    goto z_bb_98;
    z_bb_97:
    goto z_bb_95;
    z_bb_98:
    if ((unsigned char)(adi < (unsigned int)((unsigned int)adl_n))) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_741 = ctx->store;
    zT_744 = ctx->store;
    zT_748 = amods.ptr;
    zT_749 = 0;
    zT_750 = zT_748[zT_749];
    zT_745 = zT_750.ast_root;
    zT_753 = zF_B10B1BC1_astStoreNodeExtraCh(zT_744, zT_745, (unsigned int)((unsigned int)adi));
    zT_742 = zT_753;
    zT_754 = zF_FCDD1D35_astStoreNodeAt(zT_741, zT_742);
    ad = zT_754;
    zT_756 = ad.kind;
    zT_757 = (unsigned int)zT_756;
    ak = zT_757;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_759[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ab[_i] = zT_759[_i];
        _i++;
    }
}
    zT_761 = ak;
    zT_765 = 0;
    zT_766 = (unsigned char*)((unsigned char*)ab) + zT_765;
    zT_767 = (unsigned int)(20) - zT_765;
    zT_768.ptr = zT_766;
    zT_768.len = zT_767;
    zT_762 = zT_768;
    zT_769 = zF_A7504564_itoa(zT_761, zT_762);
    alen = zT_769;
    zT_773 = (unsigned int)(19) - (unsigned int)((unsigned int)alen);
    ast = zT_773;
    zT_778 = (unsigned char*)((unsigned char*)ab) + ast;
    zT_779 = (unsigned int)(19) - ast;
    zT_780.ptr = zT_778;
    zT_780.len = zT_779;
    zT_774 = zT_780;
    zF_48AC7B3A_markerWrite(zT_774);
    zT_782 = " ";
    zT_784 = 1;
    zT_783.ptr = zT_782;
    zT_783.len = zT_784;
    asp = zT_783;
    zT_785 = asp;
    zF_48AC7B3A_markerWrite(zT_785);
    goto z_bb_101;
    z_bb_100:
    zT_789 = "\n";
    zT_791 = 1;
    zT_790.ptr = zT_789;
    zT_790.len = zT_791;
    an = zT_790;
    zT_792 = an;
    zF_48AC7B3A_markerWrite(zT_792);
    goto z_bb_97;
    z_bb_101:
    zT_787 = adi + (unsigned int)(1);
    adi = zT_787;
    goto z_bb_98;
    z_bb_102:
    zT_798 = async_retained.len;
    if ((unsigned char)(arl_i < zT_798)) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_801 = async_retained.items;
    zT_802 = zT_801[arl_i];
    zT_804 = (zT_BBC23664_LirFunction*)(unsigned int)(unsigned int)((unsigned int)zT_802);
    lf2 = zT_804;
    zT_805 = &ctx->async_layouts;
    zT_806 = lf2->module_id;
    zT_807 = lf2->name_id;
    zT_811 = zF_A1F56FFB_asyncLayoutLookup(zT_805, zT_806, zT_807);
    zT_812 = zT_811.has_value;
    if (zT_812) goto z_bb_106; else goto z_bb_107;
    z_bb_104:
    if (async_pending) goto z_bb_108; else goto z_bb_109;
    z_bb_105:
    zT_833 = arl_i + (unsigned int)(1);
    arl_i = zT_833;
    goto z_bb_102;
    z_bb_106:
    lay2 = zT_811.value;
    zT_816 = ctx->alloc;
    zT_817 = &zT_816->scratch;
    zT_815.alloc = zT_817;
    zT_818 = ctx->typereg;
    zT_815.registry = zT_818;
    zT_819 = ctx->interner;
    zT_815.interner = zT_819;
    zT_820 = &ctx->lir_stream;
    zT_815.lir_stream = zT_820;
    zT_821 = &ctx->lir_slots;
    zT_815.lir_slots = zT_821;
    zT_822 = &ctx->suspending_fns;
    zT_815.suspending_fns = zT_822;
    zT_815.layout = lay2;
    zT_823 = ctx->cli;
    zT_824 = zT_823.safe_checks;
    zT_815.safe_checks = zT_824;
    zT_825 = &ctx->frame_sizes;
    zT_815.frame_sizes = zT_825;
    zT_826 = &ctx->async_layouts;
    zT_815.async_layouts = zT_826;
    zT_827 = ctx->diag;
    zT_815.diag = zT_827;
    async_ctx2 = zT_815;
    zT_828 = lf2;
    zT_829 = &async_ctx2;
    zT_831 = zF_7C1ED6D1_asyncTransform(zT_828, zT_829);
    (void)zT_831;
    goto z_bb_107;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    zT_835 = ctx->alloc;
    zT_834 = &zT_835->scratch;
    zF_F1B3F8C2_sandReset(zT_834);
    goto z_bb_109;
    z_bb_109:
    zT_837 = ctx;
    zF_B69A3794_computeModuleInitOr(zT_837);
    zT_838 = &ctx->lir_stream;
    zF_256E5B86_lirStreamFinishWrit(zT_838);
    zT_840 = sem_ctx.print_value_lowered;
    if ((unsigned char)(zT_840 != (unsigned char)(0))) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_844 = "std_fmt.zig";
    zT_846 = 11;
    zT_845.ptr = zT_844;
    zT_845.len = zT_846;
    c89_fmt_base = zT_845;
    zT_850 = ctx->module_reg;
    zT_852 = zF_3452C137_moduleRegistryGetMo(zT_850);
    zT_847 = zT_852;
    zT_848 = ctx->interner;
    zT_849 = c89_fmt_base;
    zT_854 = zF_D27A4A01_moduleIdForBasename(zT_847, zT_848, zT_849);
    if ((unsigned char)(zT_854 == (unsigned int)(4294967295u))) goto z_bb_112; else goto z_bb_113;
    z_bb_111:
    return;
    z_bb_112:
    zT_858 = "could not resolve imported file '";
    zT_860 = 33;
    zT_859.ptr = zT_858;
    zT_859.len = zT_860;
    p1 = zT_859;
    zT_862 = "'";
    zT_864 = 1;
    zT_863.ptr = zT_862;
    zT_863.len = zT_864;
    p2 = zT_863;
    zT_867 = 0;
    zT_866[zT_867] = p1;
    zT_868 = 1;
    zT_866[zT_868] = c89_fmt_base;
    zT_869 = 2;
    zT_866[zT_869] = p2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        parts[_i] = zT_866[_i];
        _i++;
    }
}
    zT_871 = ctx->interner;
    zT_875 = 0;
    zT_876 = parts + zT_875;
    zT_872 = zT_876;
    zT_878 = zF_8C4BFF7C_diagnosticBuilderMa(zT_871, zT_872, (unsigned int)(3));
    msg = zT_878;
    zT_879 = ctx->diag;
    zT_885 = msg;
    zT_894 = zF_C82559AC_diagnosticCollector(zT_879, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3048_CANNOT_READ_FILE)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_885);
    (void)zT_894;
    goto z_bb_113;
    z_bb_113:
    goto z_bb_111;
}

/* computeModuleInitOrder */
void zF_B69A3794_computeModuleInitOr(zT_5AB29387_CompilerContext* ctx) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_4 = {0};
    unsigned int zT_7;
    zT_B687BB96_U32ArrayList* zT_9;
    zT_3E40CD83_Sand* zT_11;
    zT_69057089_CompilerAlloc* zT_14;
    zT_019EE88E_EU_932 zT_19 = {0};
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned char* zT_23;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char zT_38;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_6E8D187B_ModuleEntry* zT_50;
    zT_6E8D187B_ModuleEntry zT_51;
    unsigned int zT_52;
    zT_6E8D187B_ModuleEntry* zT_56;
    zT_6E8D187B_ModuleEntry zT_57;
    unsigned int zT_58;
    zT_79FAE712_u64 zT_60;
    zT_A4CE86B7_U64ToU32Map* zT_61;
    zT_79FAE712_u64 zT_62;
    zT_BAEE192E_Opt_10 zT_64 = {0};
    unsigned char zT_65;
    unsigned char zT_66;
    unsigned int zT_68;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_6E8D187B_ModuleEntry* zT_92;
    zT_6E8D187B_ModuleEntry zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_100;
    zT_79FAE712_u64 zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    zT_BAEE192E_Opt_10 zT_106 = {0};
    unsigned char zT_107;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    zT_22A7C88B_AstNode zT_113 = {0};
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_F85C5DED_DiagnosticCollector* zT_118;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_6E8D187B_ModuleEntry* zT_130;
    zT_6E8D187B_ModuleEntry zT_131;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_138 = 0;
    unsigned char zT_139;
    unsigned int zT_141;
    unsigned int zT_143;
    unsigned char zT_144;
    zT_B687BB96_U32ArrayList* zT_145;
    unsigned int zT_146;
    zT_6E8D187B_ModuleEntry* zT_148;
    zT_6E8D187B_ModuleEntry zT_149;
    unsigned int zT_152;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int n;
    unsigned char* placed;
    unsigned int i;
    unsigned int remaining;
    unsigned int pick;
    unsigned char ok;
    unsigned int j;
    zT_79FAE712_u64 dep_key;
    unsigned int ri;
    unsigned char reported;
    unsigned int rj;
    zT_79FAE712_u64 cyc_key;
    unsigned int ref_decl;
    zT_22A7C88B_AstNode cyc_dcl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cyc_msg;
    zT_2 = ctx->module_reg;
    zT_4 = zF_3452C137_moduleRegistryGetMo(zT_2);
    mods = zT_4;
    zT_7 = mods.len;
    n = zT_7;
    zT_9 = &ctx->module_init_order;
    zT_9->len = (unsigned int)(0);
    zT_14 = ctx->alloc;
    zT_11 = &zT_14->scratch;
    zT_19 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)(n + (unsigned int)(1)), (unsigned int)(1));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_21 = zT_19.data.payload;
    goto z_bb_3;
    z_bb_3:
    zT_23 = (unsigned char*)zT_21;
    placed = zT_23;
    zT_25 = 0;
    i = zT_25;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < n)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = 0;
    placed[i] = zT_27;
    goto z_bb_7;
    z_bb_6:
    remaining = n;
    goto z_bb_8;
    z_bb_7:
    zT_29 = i + (unsigned int)(1);
    i = zT_29;
    goto z_bb_4;
    z_bb_8:
    if ((unsigned char)(remaining > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pick = n;
    zT_34 = 0;
    i = zT_34;
    goto z_bb_12;
    z_bb_10:
    return;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    if ((unsigned char)(i < n)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_38 = placed[i];
    if ((unsigned char)(zT_38 != (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_14:
    if ((unsigned char)(pick == n)) goto z_bb_31; else goto z_bb_32;
    z_bb_15:
    zT_72 = i + (unsigned int)(1);
    i = zT_72;
    goto z_bb_12;
    z_bb_16:
    zT_36 = pick == n;
    goto z_bb_18;
    z_bb_17:
    zT_36 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_36) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_42 = 1;
    ok = zT_42;
    zT_44 = 0;
    j = zT_44;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(j < n)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_46 = placed[j];
    if ((unsigned char)(zT_46 != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    if ((unsigned char)(ok != (unsigned char)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_24:
    zT_68 = j + (unsigned int)(1);
    j = zT_68;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_50 = mods.ptr;
    zT_51 = zT_50[i];
    zT_52 = zT_51.id;
    zT_56 = mods.ptr;
    zT_57 = zT_56[j];
    zT_58 = zT_57.id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_52) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_58);
    dep_key = zT_60;
    zT_61 = &ctx->module_init_deps;
    zT_62 = dep_key;
    zT_64 = zF_A05A7BE1_u64ToU32MapGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_66 = 0;
    ok = zT_66;
    goto z_bb_23;
    z_bb_28:
    goto z_bb_24;
    z_bb_29:
    pick = i;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_15;
    z_bb_31:
    zT_75 = 0;
    ri = zT_75;
    zT_77 = 0;
    reported = zT_77;
    goto z_bb_33;
    z_bb_32:
    zT_144 = 1;
    placed[pick] = zT_144;
    zT_145 = &ctx->module_init_order;
    zT_148 = mods.ptr;
    zT_149 = zT_148[pick];
    zT_146 = zT_149.id;
    zF_62F717A2_u32ArrayListAppend(zT_145, zT_146);
    zT_152 = remaining - (unsigned int)(1);
    remaining = zT_152;
    goto z_bb_11;
    z_bb_33:
    if ((unsigned char)(ri < n)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    zT_82 = placed[ri];
    if ((unsigned char)(zT_82 != (unsigned char)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_35:
    goto z_bb_10;
    z_bb_36:
    zT_143 = ri + (unsigned int)(1);
    ri = zT_143;
    goto z_bb_33;
    z_bb_37:
    zT_79 = reported == (unsigned char)(0);
    goto z_bb_39;
    z_bb_38:
    zT_79 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_79) goto z_bb_34; else goto z_bb_35;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_86 = 0;
    rj = zT_86;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(rj < n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_88 = placed[rj];
    if ((unsigned char)(zT_88 != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_36;
    z_bb_45:
    zT_141 = rj + (unsigned int)(1);
    rj = zT_141;
    goto z_bb_42;
    z_bb_46:
    goto z_bb_45;
    z_bb_47:
    zT_92 = mods.ptr;
    zT_93 = zT_92[ri];
    zT_94 = zT_93.id;
    zT_98 = mods.ptr;
    zT_99 = zT_98[rj];
    zT_100 = zT_99.id;
    zT_102 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_94) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_100);
    cyc_key = zT_102;
    zT_103 = &ctx->module_init_deps;
    zT_104 = cyc_key;
    zT_106 = zF_A05A7BE1_u64ToU32MapGet(zT_103, zT_104);
    zT_107 = zT_106.has_value;
    if (zT_107) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    ref_decl = zT_106.value;
    zT_110 = ctx->store;
    zT_111 = ref_decl;
    zT_113 = zF_FCDD1D35_astStoreNodeAt(zT_110, zT_111);
    cyc_dcl = zT_113;
    zT_115 = "cyclic global initializer dependency";
    zT_117 = 36;
    zT_116.ptr = zT_115;
    zT_116.len = zT_117;
    cyc_msg = zT_116;
    zT_118 = ctx->diag;
    zT_130 = mods.ptr;
    zT_131 = zT_130[ri];
    zT_121 = zT_131.source_file_id;
    zT_122 = cyc_dcl.span_start;
    zT_134 = cyc_dcl.span_start;
    zT_135 = cyc_dcl.span_len;
    zT_124 = cyc_msg;
    zT_138 = zF_C82559AC_diagnosticCollector(zT_118, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3064_CYCLIC_GLOBAL_INIT)), zT_121, zT_122, (unsigned int)(zT_134 + (unsigned int)((unsigned int)zT_135)), zT_124);
    (void)zT_138;
    zT_139 = 1;
    reported = zT_139;
    goto z_bb_44;
    z_bb_49:
    goto z_bb_45;
}

/* errorCodeRegistryFinalize */
void zF_FC691B4D_errorCodeRegistryFi(zT_5AB29387_CompilerContext* ctx) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_0B73C507_ErrorSetPayload* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_0B73C507_ErrorSetPayload zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int* zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_21D3708C_U32ToU32Map* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    int zT_43;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int ti;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload esp;
    unsigned int ei;
    unsigned int mname_id;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ctx->typereg;
    zT_5 = zT_4->types_len;
    if ((unsigned char)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = ctx->typereg;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_46 = 1;
    zT_48 = ti + (unsigned int)((unsigned int)zT_46);
    ti = zT_48;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = ty.payload_idx;
    zT_17 = ctx->typereg;
    zT_18 = zT_17->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_15) >= zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_21 = ctx->typereg;
    zT_22 = zT_21->es_items;
    zT_23 = ty.payload_idx;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    esp = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    ei = zT_28;
    goto z_bb_9;
    z_bb_9:
    zT_29 = esp.tags_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_29))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = ctx->typereg;
    zT_34 = zT_33->xn_items;
    zT_35 = esp.tags_start;
    zT_37 = (unsigned int)((unsigned int)zT_35) + ei;
    zT_38 = zT_34[zT_37];
    mname_id = zT_38;
    zT_39 = &ctx->error_code_registry;
    zT_40 = mname_id;
    zT_42 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_39, zT_40);
    (void)zT_42;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_43 = 1;
    zT_45 = ei + (unsigned int)((unsigned int)zT_43);
    ei = zT_45;
    goto z_bb_9;
}

/* pruneTypeMarkByValue */
void zF_BC6C7740_pruneTypeMarkByValu(zT_21D3708C_U32ToU32Map* ref_edges, zT_338B7C76_TypeRegistry* reg, zT_A4CE86B7_U64ToU32Map* visited, unsigned int src_mid, unsigned int tid) {
    unsigned int zT_5;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_79FAE712_u64 zT_15;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_79FAE712_u64 zT_19;
    zT_D155D06D_Type* zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    unsigned int zT_26;
    unsigned char zT_29;
    unsigned int zT_30;
    zT_21D3708C_U32ToU32Map* zT_32;
    unsigned int zT_37;
    zT_33EF6BFB_TypeKind zT_40;
    zT_406493CE_StructPayload* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_406493CE_StructPayload zT_48;
    unsigned int zT_50;
    unsigned short zT_51;
    zT_21D3708C_U32ToU32Map* zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    zT_A4CE86B7_U64ToU32Map* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_2DF01B61_FieldEntry* zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    zT_2DF01B61_FieldEntry zT_63;
    unsigned int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_54FF90FA_TaggedUnionPayload* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_54FF90FA_TaggedUnionPayload zT_75;
    zT_21D3708C_U32ToU32Map* zT_76;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned short zT_84;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_A4CE86B7_U64ToU32Map* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_2DF01B61_FieldEntry* zT_92;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_2DF01B61_FieldEntry zT_96;
    unsigned int zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    unsigned char zT_104;
    zT_33EF6BFB_TypeKind zT_105;
    zT_AF9231A2_UnionPayload* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_AF9231A2_UnionPayload zT_113;
    zT_21D3708C_U32ToU32Map* zT_114;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_A4CE86B7_U64ToU32Map* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_121;
    unsigned short zT_122;
    zT_21D3708C_U32ToU32Map* zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_A4CE86B7_U64ToU32Map* zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    zT_2DF01B61_FieldEntry* zT_130;
    unsigned int zT_131;
    unsigned int zT_133;
    zT_2DF01B61_FieldEntry zT_134;
    unsigned int zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_457ECFEE_EnumPayload* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_457ECFEE_EnumPayload zT_146;
    zT_21D3708C_U32ToU32Map* zT_147;
    zT_338B7C76_TypeRegistry* zT_148;
    zT_A4CE86B7_U64ToU32Map* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_33EF6BFB_TypeKind zT_153;
    zT_E834303C_ArrayPayload* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_E834303C_ArrayPayload zT_161;
    zT_21D3708C_U32ToU32Map* zT_162;
    zT_338B7C76_TypeRegistry* zT_163;
    zT_A4CE86B7_U64ToU32Map* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_33EF6BFB_TypeKind zT_168;
    zT_666DC2E1_TuplePayload* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_666DC2E1_TuplePayload zT_176;
    unsigned int zT_178;
    unsigned short zT_179;
    zT_21D3708C_U32ToU32Map* zT_182;
    zT_338B7C76_TypeRegistry* zT_183;
    zT_A4CE86B7_U64ToU32Map* zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int* zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_193;
    zT_33EF6BFB_TypeKind zT_194;
    zT_0B10E8E9_OptionalPayload* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_0B10E8E9_OptionalPayload zT_202;
    zT_21D3708C_U32ToU32Map* zT_203;
    zT_338B7C76_TypeRegistry* zT_204;
    zT_A4CE86B7_U64ToU32Map* zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_33EF6BFB_TypeKind zT_209;
    zT_42C2D6BF_EUPayload* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    zT_42C2D6BF_EUPayload zT_217;
    zT_21D3708C_U32ToU32Map* zT_218;
    zT_338B7C76_TypeRegistry* zT_219;
    zT_A4CE86B7_U64ToU32Map* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_21D3708C_U32ToU32Map* zT_224;
    zT_338B7C76_TypeRegistry* zT_225;
    zT_A4CE86B7_U64ToU32Map* zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    zT_79FAE712_u64 vkey;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload p;
    unsigned int fi;
    zT_54FF90FA_TaggedUnionPayload p_1;
    zT_AF9231A2_UnionPayload p_2;
    zT_457ECFEE_EnumPayload p_3;
    zT_E834303C_ArrayPayload p_4;
    zT_666DC2E1_TuplePayload p_5;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload p_6;
    zT_42C2D6BF_EUPayload p_7;
    zT_5 = reg->types_len;
    if ((unsigned char)(tid >= (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)src_mid) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)tid);
    vkey = zT_13;
    zT_14 = visited;
    zT_15 = vkey;
    zT_16 = zF_A05A7BE1_u64ToU32MapGet(zT_14, zT_15);
    zT_17 = zT_16.has_value;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = visited;
    zT_19 = vkey;
    zF_B6EB812C_u64ToU32MapPut(zT_18, zT_19, (unsigned int)(1));
    zT_23 = reg->types_items;
    zT_24 = (unsigned int)tid;
    zT_25 = zT_23[zT_24];
    ty = zT_25;
    zT_26 = ty.module_id;
    if ((unsigned char)(zT_26 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = ty.module_id;
    zT_29 = zT_30 != src_mid;
    goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = ref_edges;
    zT_37 = ty.module_id;
    zF_26476265_u32ToU32MapPut(zT_32, (unsigned int)((unsigned int)(src_mid * (unsigned int)(65536)) + zT_37), (unsigned int)(1));
    goto z_bb_9;
    z_bb_9:
    zT_40 = ty.kind;
    if ((unsigned char)(zT_40 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_45 = reg->st_items;
    zT_46 = ty.payload_idx;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zT_45[zT_47];
    p = zT_48;
    zT_50 = 0;
    fi = zT_50;
    goto z_bb_13;
    z_bb_11:
    return;
    z_bb_12:
    zT_67 = ty.kind;
    if ((unsigned char)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_13:
    zT_51 = p.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_51))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_54 = ref_edges;
    zT_55 = reg;
    zT_56 = visited;
    zT_57 = src_mid;
    zT_59 = reg->fe_items;
    zT_60 = p.fields_start;
    zT_62 = (unsigned int)((unsigned int)zT_60) + fi;
    zT_63 = zT_59[zT_62];
    zT_58 = zT_63.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_54, zT_55, zT_56, zT_57, zT_58);
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_66 = fi + (unsigned int)(1);
    fi = zT_66;
    goto z_bb_13;
    z_bb_17:
    zT_72 = reg->tu_items;
    zT_73 = ty.payload_idx;
    zT_74 = (unsigned int)zT_73;
    zT_75 = zT_72[zT_74];
    p_1 = zT_75;
    zT_76 = ref_edges;
    zT_77 = reg;
    zT_78 = visited;
    zT_79 = src_mid;
    zT_80 = p_1.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_76, zT_77, zT_78, zT_79, zT_80);
    zT_83 = 0;
    fi = zT_83;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_11;
    z_bb_19:
    zT_100 = ty.kind;
    if ((unsigned char)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_25; else goto z_bb_24;
    z_bb_20:
    zT_84 = p_1.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_84))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_87 = ref_edges;
    zT_88 = reg;
    zT_89 = visited;
    zT_90 = src_mid;
    zT_92 = reg->fe_items;
    zT_93 = p_1.fields_start;
    zT_95 = (unsigned int)((unsigned int)zT_93) + fi;
    zT_96 = zT_92[zT_95];
    zT_91 = zT_96.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_87, zT_88, zT_89, zT_90, zT_91);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_99 = fi + (unsigned int)(1);
    fi = zT_99;
    goto z_bb_20;
    z_bb_24:
    zT_105 = ty.kind;
    zT_104 = zT_105 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_26;
    z_bb_25:
    zT_104 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_104) goto z_bb_27; else goto z_bb_29;
    z_bb_27:
    zT_110 = reg->un_items;
    zT_111 = ty.payload_idx;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zT_110[zT_112];
    p_2 = zT_113;
    zT_114 = ref_edges;
    zT_115 = reg;
    zT_116 = visited;
    zT_117 = src_mid;
    zT_118 = p_2.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_114, zT_115, zT_116, zT_117, zT_118);
    zT_121 = 0;
    fi = zT_121;
    goto z_bb_30;
    z_bb_28:
    goto z_bb_18;
    z_bb_29:
    zT_138 = ty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_36;
    z_bb_30:
    zT_122 = p_2.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_122))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_125 = ref_edges;
    zT_126 = reg;
    zT_127 = visited;
    zT_128 = src_mid;
    zT_130 = reg->fe_items;
    zT_131 = p_2.fields_start;
    zT_133 = (unsigned int)((unsigned int)zT_131) + fi;
    zT_134 = zT_130[zT_133];
    zT_129 = zT_134.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_125, zT_126, zT_127, zT_128, zT_129);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_137 = fi + (unsigned int)(1);
    fi = zT_137;
    goto z_bb_30;
    z_bb_34:
    zT_143 = reg->en_items;
    zT_144 = ty.payload_idx;
    zT_145 = (unsigned int)zT_144;
    zT_146 = zT_143[zT_145];
    p_3 = zT_146;
    zT_147 = ref_edges;
    zT_148 = reg;
    zT_149 = visited;
    zT_150 = src_mid;
    zT_151 = p_3.backing_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_147, zT_148, zT_149, zT_150, zT_151);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_28;
    z_bb_36:
    zT_153 = ty.kind;
    if ((unsigned char)(zT_153 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_158 = reg->array_items;
    zT_159 = ty.payload_idx;
    zT_160 = (unsigned int)zT_159;
    zT_161 = zT_158[zT_160];
    p_4 = zT_161;
    zT_162 = ref_edges;
    zT_163 = reg;
    zT_164 = visited;
    zT_165 = src_mid;
    zT_166 = p_4.elem;
    zF_BC6C7740_pruneTypeMarkByValu(zT_162, zT_163, zT_164, zT_165, zT_166);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_168 = ty.kind;
    if ((unsigned char)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_173 = reg->tup_items;
    zT_174 = ty.payload_idx;
    zT_175 = (unsigned int)zT_174;
    zT_176 = zT_173[zT_175];
    p_5 = zT_176;
    zT_178 = 0;
    ei = zT_178;
    goto z_bb_43;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_194 = ty.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_47; else goto z_bb_49;
    z_bb_43:
    zT_179 = p_5.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_179))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_182 = ref_edges;
    zT_183 = reg;
    zT_184 = visited;
    zT_185 = src_mid;
    zT_187 = reg->xt_items;
    zT_188 = p_5.elems_start;
    zT_190 = (unsigned int)((unsigned int)zT_188) + ei;
    zT_186 = zT_187[zT_190];
    zF_BC6C7740_pruneTypeMarkByValu(zT_182, zT_183, zT_184, zT_185, zT_186);
    goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_193 = ei + (unsigned int)(1);
    ei = zT_193;
    goto z_bb_43;
    z_bb_47:
    zT_199 = reg->opt_items;
    zT_200 = ty.payload_idx;
    zT_201 = (unsigned int)zT_200;
    zT_202 = zT_199[zT_201];
    p_6 = zT_202;
    zT_203 = ref_edges;
    zT_204 = reg;
    zT_205 = visited;
    zT_206 = src_mid;
    zT_207 = p_6.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_203, zT_204, zT_205, zT_206, zT_207);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_41;
    z_bb_49:
    zT_209 = ty.kind;
    if ((unsigned char)(zT_209 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_214 = reg->eu_items;
    zT_215 = ty.payload_idx;
    zT_216 = (unsigned int)zT_215;
    zT_217 = zT_214[zT_216];
    p_7 = zT_217;
    zT_218 = ref_edges;
    zT_219 = reg;
    zT_220 = visited;
    zT_221 = src_mid;
    zT_222 = p_7.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_218, zT_219, zT_220, zT_221, zT_222);
    zT_224 = ref_edges;
    zT_225 = reg;
    zT_226 = visited;
    zT_227 = src_mid;
    zT_228 = p_7.error_set;
    zF_BC6C7740_pruneTypeMarkByValu(zT_224, zT_225, zT_226, zT_227, zT_228);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
}

/* moduleIdForBasename */
unsigned int zF_D27A4A01_moduleIdForBasename(zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u base) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_D3EB6303_StringInterner* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry* zT_11;
    zT_6E8D187B_ModuleEntry zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14 = {0};
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned char* zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned char zT_37;
    unsigned char zT_39;
    unsigned int zT_41;
    zT_6E8D187B_ModuleEntry* zT_46;
    zT_6E8D187B_ModuleEntry zT_47;
    unsigned int zT_48;
    unsigned char* zT_49;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_6E8D187B_ModuleEntry* zT_55;
    zT_6E8D187B_ModuleEntry zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u p;
    unsigned int off;
    unsigned char eq;
    unsigned int j;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = interner;
    zT_11 = mods.ptr;
    zT_12 = zT_11[i];
    zT_10 = zT_12.path_id;
    zT_14 = zF_9134020D_stringInternerGet(zT_9, zT_10);
    p = zT_14;
    zT_16 = p.len;
    zT_18 = base.len;
    if ((unsigned char)(zT_16 >= zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_1;
    z_bb_5:
    zT_22 = p.len;
    zT_24 = base.len;
    zT_25 = zT_22 - zT_24;
    off = zT_25;
    zT_27 = 1;
    eq = zT_27;
    zT_29 = 0;
    j = zT_29;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = base.len;
    if ((unsigned char)(j < zT_31)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = p.ptr;
    zT_34 = off + j;
    zT_35 = zT_33[zT_34];
    zT_36 = base.ptr;
    zT_37 = zT_36[j];
    if ((unsigned char)(zT_35 != zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    if ((unsigned char)(eq != (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_41 = j + (unsigned int)(1);
    j = zT_41;
    goto z_bb_7;
    z_bb_11:
    zT_39 = 0;
    eq = zT_39;
    goto z_bb_9;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    if ((unsigned char)(off == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_46 = mods.ptr;
    zT_47 = zT_46[i];
    zT_48 = zT_47.id;
    return zT_48;
    z_bb_16:
    zT_49 = p.ptr;
    zT_51 = off - (unsigned int)(1);
    zT_52 = zT_49[zT_51];
    if ((unsigned char)(zT_52 == (unsigned char)(47))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_55 = mods.ptr;
    zT_56 = zT_55[i];
    zT_57 = zT_56.id;
    return zT_57;
    z_bb_18:
    goto z_bb_14;
}

/* phase_C89Emission */
void zF_2268F8CE_phase_C89Emission(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_C98AF326_CompilerCli zT_6;
    unsigned char zT_7;
    unsigned char zT_9;
    zT_C98AF326_CompilerCli zT_10;
    unsigned char zT_11;
    zT_CEC2984A_NameMangler_1 zT_14 = {0};
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_E1A783EF_GlobalDeclArrayList zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_25;
    zT_D3EB6303_StringInterner* zT_26;
    zT_3E40CD83_Sand* zT_27;
    unsigned int zT_28;
    zT_69057089_CompilerAlloc* zT_30;
    zT_CEC2984A_NameMangler_1 zT_32 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_33;
    zT_85A2F044_Opt_300 zT_34;
    zT_72C4E2ED_C89Emitter zT_36 = {0};
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D3EB6303_StringInterner* zT_38;
    zT_CEC2984A_NameMangler_1* zT_39;
    zT_F85C5DED_DiagnosticCollector* zT_40;
    zT_9F514E82_SwitchCaseArrayList* zT_41;
    zT_B687BB96_U32ArrayList* zT_42;
    zT_3E40CD83_Sand* zT_43;
    zT_3E40CD83_Sand* zT_44;
    zT_21D3708C_U32ToU32Map* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    int zT_52;
    int zT_53;
    zT_69057089_CompilerAlloc* zT_54;
    zT_69057089_CompilerAlloc* zT_56;
    zT_C98AF326_CompilerCli zT_60;
    zT_72C4E2ED_C89Emitter zT_62 = {0};
    zT_072B53A6_ModuleRegistry* zT_63;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_68;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_072B53A6_ModuleRegistry* zT_71;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_73 = {0};
    unsigned int zT_75 = 0;
    zT_5AB29387_CompilerContext* zT_76;
    zT_E1A783EF_GlobalDeclArrayList* zT_78;
    zT_23133B1E_Slice_zT_54906056_M zT_80 = {0};
    zT_54906056_ModuleGlobalDecl* zT_82;
    unsigned int zT_84;
    zT_B687BB96_U32ArrayList zT_86;
    unsigned int* zT_87;
    zT_B687BB96_U32ArrayList zT_88;
    unsigned int zT_89;
    zT_7E7544E4_LirStream* zT_90;
    zT_CA01C129_LirSlotArrayList zT_91;
    zT_E7714190_LirSlot* zT_92;
    zT_CA01C129_LirSlotArrayList zT_94;
    unsigned int zT_95;
    zT_69057089_CompilerAlloc* zT_96;
    zT_3E40CD83_Sand* zT_97;
    zT_7E7544E4_LirStream* zT_98;
    zT_3E40CD83_Sand* zT_99;
    zT_69057089_CompilerAlloc* zT_101;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_3E40CD83_Sand* zT_108;
    zT_69057089_CompilerAlloc* zT_109;
    zT_21D3708C_U32ToU32Map zT_111 = {0};
    zT_3E40CD83_Sand* zT_113;
    unsigned int zT_114;
    zT_69057089_CompilerAlloc* zT_115;
    zT_CA01C129_LirSlotArrayList zT_117;
    zT_21D3708C_U32ToU32Map zT_119 = {0};
    zT_3E40CD83_Sand* zT_121;
    zT_69057089_CompilerAlloc* zT_122;
    zT_A4CE86B7_U64ToU32Map zT_124 = {0};
    unsigned int zT_126;
    zT_CA01C129_LirSlotArrayList zT_127;
    unsigned int zT_128;
    zT_7E7544E4_LirStream* zT_131;
    zT_E7714190_LirSlot zT_132;
    zT_3E40CD83_Sand* zT_133;
    zT_CA01C129_LirSlotArrayList zT_135;
    zT_E7714190_LirSlot* zT_136;
    zT_E7714190_LirSlot zT_137;
    zT_69057089_CompilerAlloc* zT_138;
    zT_BBC23664_LirFunction zT_140 = {0};
    unsigned int zT_142;
    unsigned int zT_144;
    zT_5D72FBF8_TempDeclArrayList zT_145;
    unsigned int zT_146;
    zT_5D72FBF8_TempDeclArrayList zT_149;
    zT_1937645B_TempDecl* zT_150;
    zT_1937645B_TempDecl zT_151;
    zT_21D3708C_U32ToU32Map* zT_152;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_A4CE86B7_U64ToU32Map* zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_338B7C76_TypeRegistry* zT_161;
    zT_21D3708C_U32ToU32Map* zT_162;
    unsigned int zT_163;
    zT_72C4E2ED_C89Emitter* zT_165;
    unsigned int zT_169;
    unsigned int zT_170;
    zT_338B7C76_TypeRegistry* zT_171;
    unsigned int zT_172;
    zT_21D3708C_U32ToU32Map* zT_175;
    zT_338B7C76_TypeRegistry* zT_176;
    zT_A4CE86B7_U64ToU32Map* zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned int zT_185;
    zT_CFE23D0A_LirParamArrayList zT_186;
    unsigned int zT_187;
    zT_CFE23D0A_LirParamArrayList zT_190;
    zT_8779209D_LirParam* zT_191;
    zT_8779209D_LirParam zT_192;
    zT_21D3708C_U32ToU32Map* zT_193;
    zT_338B7C76_TypeRegistry* zT_194;
    zT_A4CE86B7_U64ToU32Map* zT_195;
    unsigned int zT_196;
    unsigned int zT_197;
    unsigned int zT_203;
    unsigned int zT_205;
    zT_1CF28CA3_BasicBlockArrayList zT_206;
    unsigned int zT_207;
    zT_1CF28CA3_BasicBlockArrayList zT_210;
    zT_88A68B1A_BasicBlock* zT_211;
    zT_88A68B1A_BasicBlock zT_212;
    unsigned int zT_214;
    zT_DAE4631D_LirInstArrayList zT_215;
    unsigned int zT_216;
    zT_DAE4631D_LirInstArrayList zT_219;
    zT_6BA597BC_LirInst* zT_220;
    zT_6BA597BC_LirInst zT_221;
    unsigned int zT_223;
    unsigned char zT_225;
    unsigned int zT_227;
    zT_6BA597BC_LirInst zT_230;
    zT_BBC23664_LirFunction* zT_233;
    unsigned int zT_234;
    zT_3BFB1E70_CallDirectData zT_238 = {0};
    unsigned int zT_239;
    unsigned char zT_240;
    zT_6BA597BC_LirInst zT_243;
    zT_BBC23664_LirFunction* zT_246;
    unsigned int zT_247;
    zT_0624AC1B_TailCallData zT_251 = {0};
    unsigned int zT_252;
    unsigned char zT_253;
    zT_6BA597BC_LirInst zT_256;
    zT_7AF6F585_anon_92206 zT_259;
    unsigned int zT_260;
    unsigned char zT_261;
    zT_6BA597BC_LirInst zT_264;
    zT_0A4C1DAC_anon_92384 zT_267;
    unsigned int zT_268;
    unsigned char zT_269;
    zT_6BA597BC_LirInst zT_272;
    zT_0A4E5C43_anon_92392 zT_275;
    unsigned int zT_276;
    unsigned char zT_277;
    unsigned char zT_280;
    zT_21D3708C_U32ToU32Map* zT_282;
    zT_6BA597BC_LirInst zT_292;
    unsigned char zT_294;
    unsigned int zT_295;
    unsigned int zT_298;
    zT_21D3708C_U32ToU32Map* zT_300;
    unsigned int zT_306;
    zT_6BA597BC_LirInst zT_311;
    unsigned char zT_313;
    zT_6BA597BC_LirInst zT_316;
    unsigned int zT_319;
    unsigned int zT_321;
    zT_6BA597BC_LirInst zT_324;
    zT_0A4C1DAC_anon_92384 zT_327;
    unsigned int zT_328;
    zT_0A4C1DAC_anon_92384 zT_330;
    unsigned int zT_331;
    zT_0A4E5C43_anon_92392 zT_333;
    unsigned int zT_334;
    zT_0A4E5C43_anon_92392 zT_336;
    unsigned int zT_337;
    unsigned int zT_339;
    unsigned int zT_341;
    zT_5D72FBF8_TempDeclArrayList zT_342;
    unsigned int zT_343;
    zT_5D72FBF8_TempDeclArrayList zT_346;
    zT_1937645B_TempDecl* zT_347;
    zT_1937645B_TempDecl zT_348;
    unsigned int zT_349;
    unsigned int zT_351;
    unsigned int zT_353;
    zT_338B7C76_TypeRegistry* zT_354;
    unsigned int zT_355;
    zT_338B7C76_TypeRegistry* zT_359;
    zT_D155D06D_Type* zT_360;
    unsigned int zT_361;
    zT_D155D06D_Type zT_362;
    unsigned int zT_363;
    unsigned char zT_366;
    unsigned int zT_367;
    zT_21D3708C_U32ToU32Map* zT_369;
    unsigned int zT_370;
    unsigned int zT_375;
    unsigned int zT_377;
    unsigned int zT_379;
    zT_072B53A6_ModuleRegistry* zT_381;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_383 = {0};
    unsigned int zT_385;
    unsigned int zT_387;
    zT_6E8D187B_ModuleEntry* zT_389;
    zT_6E8D187B_ModuleEntry zT_390;
    unsigned int zT_391;
    unsigned char zT_395;
    unsigned int zT_397;
    zT_E1A783EF_GlobalDeclArrayList zT_398;
    unsigned int zT_399;
    zT_E1A783EF_GlobalDeclArrayList zT_402;
    zT_54906056_ModuleGlobalDecl* zT_403;
    zT_54906056_ModuleGlobalDecl zT_404;
    unsigned int zT_405;
    zT_6E8D187B_ModuleEntry* zT_406;
    zT_6E8D187B_ModuleEntry zT_407;
    unsigned int zT_408;
    unsigned char zT_410;
    unsigned char zT_411;
    unsigned char zT_414;
    unsigned int zT_416;
    zT_21D3708C_U32ToU32Map* zT_419;
    zT_6E8D187B_ModuleEntry* zT_426;
    zT_6E8D187B_ModuleEntry zT_427;
    unsigned int zT_428;
    unsigned int zT_432;
    unsigned int zT_434;
    zT_E1A783EF_GlobalDeclArrayList zT_435;
    unsigned int zT_436;
    zT_E1A783EF_GlobalDeclArrayList zT_439;
    zT_54906056_ModuleGlobalDecl* zT_440;
    zT_54906056_ModuleGlobalDecl zT_441;
    unsigned int zT_442;
    zT_338B7C76_TypeRegistry* zT_443;
    unsigned int zT_444;
    zT_338B7C76_TypeRegistry* zT_448;
    zT_D155D06D_Type* zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    zT_D155D06D_Type zT_452;
    zT_338B7C76_TypeRegistry* zT_453;
    zT_21D3708C_U32ToU32Map* zT_454;
    unsigned int zT_455;
    zT_72C4E2ED_C89Emitter* zT_457;
    unsigned int zT_460;
    unsigned char zT_463;
    unsigned int zT_464;
    unsigned int zT_465;
    zT_21D3708C_U32ToU32Map* zT_467;
    zT_338B7C76_TypeRegistry* zT_468;
    zT_A4CE86B7_U64ToU32Map* zT_469;
    unsigned int zT_470;
    unsigned int zT_471;
    unsigned int zT_478;
    zT_3E40CD83_Sand* zT_480;
    unsigned int zT_481;
    zT_69057089_CompilerAlloc* zT_482;
    zT_21D3708C_U32ToU32Map zT_486 = {0};
    zT_21D3708C_U32ToU32Map* zT_487;
    unsigned char zT_494;
    unsigned char zT_497;
    unsigned int zT_499;
    unsigned int zT_501;
    zT_6E8D187B_ModuleEntry* zT_504;
    zT_6E8D187B_ModuleEntry zT_505;
    unsigned int zT_506;
    zT_21D3708C_U32ToU32Map* zT_507;
    unsigned int zT_508;
    zT_BAEE192E_Opt_10 zT_510 = {0};
    unsigned char zT_511;
    unsigned int zT_514;
    unsigned int zT_516;
    zT_6E8D187B_ModuleEntry* zT_519;
    zT_6E8D187B_ModuleEntry zT_520;
    unsigned int zT_521;
    zT_21D3708C_U32ToU32Map* zT_523;
    unsigned int zT_524;
    zT_BAEE192E_Opt_10 zT_526 = {0};
    unsigned char zT_527;
    zT_21D3708C_U32ToU32Map* zT_528;
    zT_BAEE192E_Opt_10 zT_534 = {0};
    unsigned char zT_535;
    zT_21D3708C_U32ToU32Map* zT_536;
    unsigned int zT_537;
    unsigned char zT_541;
    unsigned int zT_543;
    unsigned int zT_545;
    zT_C98AF326_CompilerCli zT_546;
    unsigned char zT_547;
    unsigned int zT_549;
    unsigned int zT_550;
    zT_21D3708C_U32ToU32Map* zT_552;
    unsigned int zT_553;
    zT_72C4E2ED_C89Emitter* zT_555;
    unsigned int* zT_557;
    unsigned int zT_558;
    int zT_561;
    unsigned int zT_563;
    zT_338B7C76_TypeRegistry* zT_565;
    zT_3E40CD83_Sand* zT_566;
    zT_69057089_CompilerAlloc* zT_568;
    unsigned int* zT_570 = 0;
    zT_846744CC_Arr_unsigned_char_5 zT_572;
    unsigned int zT_574;
    zT_C98AF326_CompilerCli zT_576;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_577;
    zT_72C4E2ED_C89Emitter* zT_578;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_579;
    unsigned int zT_582;
    unsigned int zT_584;
    unsigned char zT_586;
    unsigned char* zT_589;
    unsigned char zT_590;
    int zT_591;
    unsigned int zT_593;
    int zT_594;
    unsigned int zT_596;
    unsigned char zT_597;
    int zT_598;
    unsigned int zT_600;
    unsigned char* zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    unsigned int zT_604;
    unsigned int zT_606;
    unsigned int zT_608;
    unsigned char zT_610;
    unsigned char* zT_613;
    unsigned char zT_614;
    int zT_615;
    unsigned int zT_617;
    int zT_618;
    unsigned int zT_620;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_622;
    int zT_626;
    unsigned char* zT_627;
    unsigned int zT_628;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_629;
    unsigned int zT_631 = 0;
    unsigned char* zT_635;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_636;
    unsigned int zT_637;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_638;
    zT_63BE4FF5_BufferedWriter zT_642 = {0};
    unsigned int zT_643;
    zT_63BE4FF5_BufferedWriter zT_644 = {0};
    zT_72C4E2ED_C89Emitter* zT_645;
    zT_338B7C76_TypeRegistry* zT_646;
    unsigned int* zT_647;
    zT_63BE4FF5_BufferedWriter* zT_650;
    zT_72C4E2ED_C89Emitter* zT_651;
    unsigned int zT_653;
    zT_072B53A6_ModuleRegistry* zT_655;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_657 = {0};
    zT_CA01C129_LirSlotArrayList zT_660;
    unsigned int zT_661;
    int zT_662;
    zT_3E40CD83_Sand* zT_665;
    zT_69057089_CompilerAlloc* zT_668;
    unsigned int zT_672;
    zT_019EE88E_EU_932 zT_675 = {0};
    unsigned char zT_676;
    unsigned char* zT_677;
    unsigned int* zT_679;
    zT_3E40CD83_Sand* zT_681;
    zT_69057089_CompilerAlloc* zT_684;
    unsigned int zT_688;
    zT_019EE88E_EU_932 zT_691 = {0};
    unsigned char zT_692;
    unsigned char* zT_693;
    unsigned int* zT_695;
    unsigned int zT_697;
    unsigned int zT_699;
    unsigned int zT_701;
    int zT_702;
    unsigned int zT_704;
    unsigned int zT_706;
    zT_CA01C129_LirSlotArrayList zT_709;
    zT_E7714190_LirSlot* zT_710;
    zT_E7714190_LirSlot zT_711;
    unsigned int zT_712;
    unsigned int zT_715;
    unsigned int zT_717;
    unsigned int zT_718;
    unsigned int zT_720;
    unsigned int zT_721;
    int zT_722;
    unsigned int zT_724;
    unsigned int zT_726;
    unsigned int zT_727;
    unsigned int zT_729;
    unsigned int zT_731;
    unsigned int zT_732;
    int zT_733;
    unsigned int zT_735;
    zT_3E40CD83_Sand* zT_737;
    zT_69057089_CompilerAlloc* zT_740;
    zT_019EE88E_EU_932 zT_745 = {0};
    unsigned char zT_746;
    unsigned char* zT_747;
    zT_E7714190_LirSlot* zT_749;
    unsigned int zT_750;
    zT_CA01C129_LirSlotArrayList zT_753;
    zT_E7714190_LirSlot* zT_754;
    zT_E7714190_LirSlot zT_755;
    unsigned int zT_757;
    unsigned int zT_760;
    unsigned int zT_763;
    unsigned int zT_764;
    unsigned int zT_765;
    unsigned int zT_767;
    unsigned int zT_768;
    int zT_769;
    unsigned int zT_771;
    zT_CA01C129_LirSlotArrayList* zT_772;
    zT_CA01C129_LirSlotArrayList* zT_774;
    unsigned int zT_776;
    unsigned int zT_778;
    unsigned int zT_780;
    zT_6E8D187B_ModuleEntry* zT_783;
    zT_6E8D187B_ModuleEntry zT_784;
    zT_CA01C129_LirSlotArrayList zT_786;
    unsigned int zT_787;
    unsigned char zT_789;
    zT_CA01C129_LirSlotArrayList zT_790;
    zT_E7714190_LirSlot* zT_791;
    zT_E7714190_LirSlot zT_792;
    unsigned int zT_793;
    unsigned int zT_794;
    unsigned int zT_797;
    zT_21D3708C_U32ToU32Map* zT_798;
    unsigned int zT_799;
    zT_BAEE192E_Opt_10 zT_802 = {0};
    unsigned char zT_803;
    zT_72C4E2ED_C89Emitter* zT_807;
    unsigned int zT_808;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_811 = {0};
    unsigned int zT_813;
    unsigned int zT_817;
    unsigned char* zT_824;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_825;
    unsigned int zT_826;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_827;
    unsigned int zT_831;
    unsigned int zT_833;
    unsigned int zT_835;
    unsigned char zT_837;
    unsigned char* zT_840;
    unsigned char zT_841;
    int zT_842;
    unsigned int zT_844;
    int zT_845;
    unsigned int zT_847;
    unsigned char zT_848;
    int zT_849;
    unsigned int zT_851;
    unsigned int zT_853;
    unsigned int zT_855;
    unsigned char zT_857;
    unsigned char* zT_860;
    unsigned char zT_861;
    int zT_862;
    unsigned int zT_864;
    int zT_865;
    unsigned int zT_867;
    unsigned char* zT_869;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_870;
    unsigned int zT_871;
    unsigned int zT_873;
    unsigned int zT_875;
    unsigned char zT_877;
    unsigned char* zT_880;
    unsigned char zT_881;
    int zT_882;
    unsigned int zT_884;
    int zT_885;
    unsigned int zT_887;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_889;
    int zT_893;
    unsigned char* zT_894;
    unsigned int zT_895;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_896;
    unsigned int zT_898 = 0;
    unsigned char* zT_902;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_903;
    unsigned int zT_904;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_905;
    zT_63BE4FF5_BufferedWriter zT_909 = {0};
    unsigned int zT_910;
    zT_63BE4FF5_BufferedWriter zT_911 = {0};
    unsigned int zT_913;
    unsigned int zT_914;
    unsigned int zT_916;
    unsigned int zT_918;
    zT_072B53A6_ModuleRegistry* zT_920;
    unsigned int* zT_921;
    unsigned int* zT_922;
    unsigned int zT_923;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_924;
    zT_B687BB96_U32ArrayList zT_926;
    unsigned int* zT_927;
    zT_B687BB96_U32ArrayList zT_928;
    unsigned int zT_929;
    int zT_930;
    unsigned int* zT_931;
    unsigned int zT_932;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_933;
    zT_3E40CD83_Sand* zT_935;
    zT_69057089_CompilerAlloc* zT_938;
    unsigned int zT_942;
    zT_019EE88E_EU_932 zT_945 = {0};
    unsigned char zT_946;
    unsigned char* zT_947;
    unsigned int* zT_950;
    unsigned int zT_952;
    unsigned int zT_954;
    unsigned int zT_956;
    unsigned int* zT_959;
    unsigned int zT_960;
    unsigned int zT_961;
    zT_21D3708C_U32ToU32Map* zT_963;
    unsigned int zT_964;
    zT_BAEE192E_Opt_10 zT_966 = {0};
    unsigned char zT_967;
    unsigned char zT_970;
    unsigned int zT_972;
    unsigned int zT_974;
    unsigned char zT_976;
    unsigned int zT_978;
    unsigned int zT_982;
    unsigned int zT_984;
    unsigned int zT_986;
    unsigned int zT_988;
    zT_6E8D187B_ModuleEntry* zT_991;
    zT_6E8D187B_ModuleEntry zT_992;
    unsigned int zT_993;
    unsigned int zT_994;
    zT_21D3708C_U32ToU32Map* zT_996;
    unsigned int zT_997;
    zT_BAEE192E_Opt_10 zT_999 = {0};
    unsigned char zT_1000;
    zT_21D3708C_U32ToU32Map* zT_1002;
    unsigned int zT_1005;
    zT_BAEE192E_Opt_10 zT_1009 = {0};
    unsigned char zT_1010;
    unsigned char zT_1013;
    unsigned int zT_1015;
    unsigned int zT_1017;
    unsigned char zT_1019;
    unsigned int zT_1021;
    unsigned int zT_1025;
    unsigned int zT_1027;
    int zT_1029;
    unsigned int* zT_1030;
    unsigned int zT_1031;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1032;
    zT_72C4E2ED_C89Emitter* zT_1033;
    unsigned int zT_1034;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1035;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1036;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1037;
    unsigned int* zT_1038;
    zT_63BE4FF5_BufferedWriter* zT_1041;
    zT_72C4E2ED_C89Emitter* zT_1042;
    unsigned int zT_1044;
    unsigned char* zT_1046;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1047;
    unsigned int zT_1048;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1049;
    zT_846744CC_Arr_unsigned_char_5 zT_1051;
    unsigned int zT_1053;
    unsigned int zT_1055;
    unsigned int zT_1057;
    unsigned char zT_1059;
    unsigned char* zT_1062;
    unsigned char zT_1063;
    int zT_1064;
    unsigned int zT_1066;
    int zT_1067;
    unsigned int zT_1069;
    unsigned char zT_1070;
    int zT_1071;
    unsigned int zT_1073;
    unsigned int zT_1075;
    unsigned int zT_1077;
    unsigned char zT_1079;
    unsigned char* zT_1082;
    unsigned char zT_1083;
    int zT_1084;
    unsigned int zT_1086;
    int zT_1087;
    unsigned int zT_1089;
    unsigned char* zT_1091;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1092;
    unsigned int zT_1093;
    unsigned int zT_1095;
    unsigned int zT_1097;
    unsigned char zT_1099;
    unsigned char* zT_1102;
    unsigned char zT_1103;
    int zT_1104;
    unsigned int zT_1106;
    int zT_1107;
    unsigned int zT_1109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1111;
    int zT_1115;
    unsigned char* zT_1116;
    unsigned int zT_1117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1118;
    unsigned int zT_1120 = 0;
    unsigned char* zT_1124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1125;
    unsigned int zT_1126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1127;
    zT_63BE4FF5_BufferedWriter zT_1131 = {0};
    unsigned int zT_1132;
    zT_63BE4FF5_BufferedWriter zT_1133 = {0};
    zT_72C4E2ED_C89Emitter* zT_1134;
    unsigned int zT_1135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1136;
    zT_63BE4FF5_BufferedWriter* zT_1139;
    zT_72C4E2ED_C89Emitter* zT_1140;
    unsigned int zT_1142;
    unsigned char* zT_1144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1145;
    unsigned int zT_1146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1147;
    int zT_1148;
    unsigned int zT_1150;
    zT_72C4E2ED_C89Emitter* zT_1151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1152;
    unsigned char zT_1153;
    zT_C98AF326_CompilerCli zT_1155;
    zT_7E7544E4_LirStream* zT_1157;
    zT_6B0A7D14_AstStore* zT_1159;
    zT_63BE4FF5_BufferedWriter zT_1162 = {0};
    zT_63BE4FF5_BufferedWriter zT_1163 = {0};
    zT_63BE4FF5_BufferedWriter* zT_1164;
    zT_63BE4FF5_BufferedWriter* zT_1166;
    zT_072B53A6_ModuleRegistry* zT_1169;
    zT_3E40CD83_Sand* zT_1170;
    zT_69057089_CompilerAlloc* zT_1172;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1174 = {0};
    zT_72C4E2ED_C89Emitter* zT_1175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1176;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1177;
    unsigned int* zT_1178;
    unsigned int zT_1179;
    unsigned char* zT_1184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1185;
    unsigned int zT_1186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1187;
    zT_63BE4FF5_BufferedWriter* zT_1188;
    zT_72C4E2ED_C89Emitter* zT_1189;
    zT_7E7544E4_LirStream* zT_1191;
    zT_6B0A7D14_AstStore* zT_1193;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_CEC2984A_NameMangler_1 mangler;
    unsigned int mangler_hint;
    zT_72C4E2ED_C89Emitter emitter;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_23133B1E_Slice_zT_54906056_M gd_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u module_name;
    zT_21D3708C_U32ToU32Map ts_ref_set;
    zT_21D3708C_U32ToU32Map ref_edges;
    zT_A4CE86B7_U64ToU32Map type_visited;
    unsigned int ts_fi;
    zT_BBC23664_LirFunction ts_fn;
    unsigned int ts_src;
    unsigned int ts_tti;
    zT_DDCD424B_Slice_zT_6E8D187B_M ri_mods;
    unsigned int ri_i;
    zT_1937645B_TempDecl ts_hty;
    unsigned int ts_pi;
    zT_8779209D_LirParam ts_pt;
    unsigned int ts_bi;
    zT_88A68B1A_BasicBlock ts_blk;
    unsigned int ts_ii;
    zT_6BA597BC_LirInst ts_inst;
    unsigned int ts_tg;
    unsigned char ts_edge_has;
    unsigned int ts_edge_dst;
    zT_3BFB1E70_CallDirectData ts_cd;
    zT_0624AC1B_TailCallData ts_tc;
    unsigned int ts_name_id;
    unsigned int ts_tmp;
    unsigned int ts_tid;
    unsigned int ts_tj;
    zT_1937645B_TempDecl ts_ht;
    zT_D155D06D_Type ts_ty;
    unsigned int gt_i;
    unsigned char ri_has;
    unsigned int gd_ri;
    zT_54906056_ModuleGlobalDecl gd_g;
    zT_54906056_ModuleGlobalDecl gt_g;
    zT_21D3708C_U32ToU32Map reachable;
    unsigned char rf_changed;
    zT_D155D06D_Type gt_ty;
    unsigned int rf_s;
    unsigned int rf_src;
    unsigned int rf_d;
    unsigned int rf_dst;
    unsigned int poi;
    zT_63BE4FF5_BufferedWriter cwriter;
    zT_3CB0179A_Slice_zT_05F374B1_u c_incs;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    unsigned int* sorted;
    zT_846744CC_Arr_unsigned_char_5 hpath;
    unsigned int hp;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hfn;
    unsigned int hfi;
    unsigned int fd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_63BE4FF5_BufferedWriter hw;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int slot_count;
    unsigned int* grp_counts;
    unsigned int fn_cursor;
    unsigned int mi;
    unsigned int* grp_cursor;
    unsigned int gci;
    unsigned int gsi;
    unsigned int gsmid;
    unsigned int gacc;
    zT_E7714190_LirSlot* grouped;
    zT_E7714190_LirSlot gslot;
    unsigned int gdst;
    zT_6E8D187B_ModuleEntry m;
    unsigned int fn_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    unsigned int hp2;
    unsigned int hi2;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hext;
    unsigned int hx;
    unsigned int fd2;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg2;
    zT_63BE4FF5_BufferedWriter hw2;
    unsigned int dep_start;
    unsigned int dep_end;
    zT_3CB0179A_Slice_zT_05F374B1_u dep_ids;
    zT_3CB0179A_Slice_zT_05F374B1_u m_c_incs;
    unsigned char* inc_raw;
    unsigned int* inc_arr;
    unsigned int inc_n;
    unsigned int di0;
    unsigned int dd0;
    unsigned int vd0;
    unsigned char dup0;
    unsigned int dj0;
    unsigned int vdd0;
    zT_3CB0179A_Slice_zT_05F374B1_u inc_slice;
    zT_846744CC_Arr_unsigned_char_5 cpath;
    unsigned int cp2;
    unsigned int ci2;
    unsigned char dup1;
    unsigned int dj1;
    unsigned int cbi;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    unsigned int cx;
    unsigned int cfd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg3;
    zT_63BE4FF5_BufferedWriter cw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2_m;
    zT_2 = "C\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->cli;
    zT_7 = zT_6.dump_c89;
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = ctx->cli;
    zT_11 = zT_10.output_dir_set;
    zT_9 = !zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_9 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    mangler = zT_14;
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    zT_18 = ctx->global_decls;
    zT_19 = zT_18.len;
    zT_21 = ctx->pointer_only_len;
    zT_25 = (unsigned int)((unsigned int)(zT_17 + zT_19) + (unsigned int)((unsigned int)zT_21)) + (unsigned int)(32);
    mangler_hint = zT_25;
    zT_26 = ctx->interner;
    zT_30 = ctx->alloc;
    zT_27 = &zT_30->emission;
    zT_28 = mangler_hint;
    zT_32 = zF_27DA3900_nameManglerInit_1(zT_26, zT_27, zT_28);
    mangler = zT_32;
    zT_33 = &ctx->exported;
    zT_34.has_value = 1;
    zT_34.value = zT_33;
    mangler.exported = zT_34;
    emitter = zT_36;
    zT_37 = ctx->typereg;
    zT_38 = ctx->interner;
    zT_39 = &mangler;
    zT_40 = ctx->diag;
    zT_52 = 0;
    zT_41 = (zT_9F514E82_SwitchCaseArrayList*)zT_52;
    zT_53 = 0;
    zT_42 = (zT_B687BB96_U32ArrayList*)zT_53;
    zT_54 = ctx->alloc;
    zT_43 = &zT_54->scratch;
    zT_56 = ctx->alloc;
    zT_44 = &zT_56->emission;
    zT_45 = &ctx->error_code_registry;
    zT_46 = ctx->pointer_only_len;
    zT_60 = ctx->cli;
    zT_47 = zT_60.safe_checks;
    zT_62 = zF_63D58A2B_c89EmitterInit(zT_37, zT_38, zT_39, zT_40, zT_41, zT_42, zT_43, zT_44, zT_45, zT_46, zT_47);
    emitter = zT_62;
    zT_63 = ctx->module_reg;
    emitter.module_reg = zT_63;
    zT_65 = "std_fmt.zig";
    zT_67 = 11;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    c89_fmt_base = zT_66;
    zT_71 = ctx->module_reg;
    zT_73 = zF_3452C137_moduleRegistryGetMo(zT_71);
    zT_68 = zT_73;
    zT_69 = ctx->interner;
    zT_70 = c89_fmt_base;
    zT_75 = zF_D27A4A01_moduleIdForBasename(zT_68, zT_69, zT_70);
    emitter.std_fmt_module_id = zT_75;
    zT_76 = ctx;
    zF_FC691B4D_errorCodeRegistryFi(zT_76);
    zT_78 = &ctx->global_decls;
    zT_80 = zF_6ACCE52D_globalDeclArrayList(zT_78);
    gd_slice = zT_80;
    zT_82 = gd_slice.ptr;
    emitter.global_decls = zT_82;
    zT_84 = gd_slice.len;
    emitter.global_decls_len = (unsigned int)((unsigned int)zT_84);
    zT_86 = ctx->module_init_order;
    zT_87 = zT_86.items;
    emitter.module_init_order = zT_87;
    zT_88 = ctx->module_init_order;
    zT_89 = zT_88.len;
    emitter.module_init_order_len = zT_89;
    zT_90 = &ctx->lir_stream;
    emitter.spill = zT_90;
    zT_91 = ctx->lir_slots;
    zT_92 = zT_91.items;
    emitter.fn_slots = zT_92;
    emitter.fn_slots_start = (unsigned int)(0);
    zT_94 = ctx->lir_slots;
    zT_95 = zT_94.len;
    emitter.fn_slots_len = zT_95;
    zT_96 = ctx->alloc;
    zT_97 = &zT_96->lir_read;
    emitter.spill_arena = zT_97;
    zT_98 = &ctx->lir_stream;
    zT_101 = ctx->alloc;
    zT_99 = &zT_101->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_98, zT_99);
    zT_104 = "output";
    zT_106 = 6;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    module_name = zT_105;
    zT_109 = ctx->alloc;
    zT_108 = &zT_109->emission;
    zT_111 = zF_58BDA2DE_u32ToU32MapInit(zT_108);
    ts_ref_set = zT_111;
    zT_115 = ctx->alloc;
    zT_113 = &zT_115->emission;
    zT_117 = ctx->lir_slots;
    zT_114 = zT_117.len;
    zT_119 = zF_619D56E6_u32ToU32MapInitCap(zT_113, zT_114);
    ref_edges = zT_119;
    zT_122 = ctx->alloc;
    zT_121 = &zT_122->emission;
    zT_124 = zF_986226E1_u64ToU32MapInit(zT_121);
    type_visited = zT_124;
    zT_126 = 0;
    ts_fi = zT_126;
    goto z_bb_6;
    z_bb_6:
    zT_127 = ctx->lir_slots;
    zT_128 = zT_127.len;
    if ((unsigned char)(ts_fi < zT_128)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_131 = &ctx->lir_stream;
    zT_135 = ctx->lir_slots;
    zT_136 = zT_135.items;
    zT_137 = zT_136[ts_fi];
    zT_132 = zT_137;
    zT_138 = ctx->alloc;
    zT_133 = &zT_138->lir_read;
    zT_140 = zF_1B7118E0_lirStreamReadFuncti(zT_131, zT_132, zT_133);
    ts_fn = zT_140;
    zT_142 = ts_fn.module_id;
    ts_src = zT_142;
    zT_144 = 0;
    ts_tti = zT_144;
    goto z_bb_10;
    z_bb_8:
    emitter.ts_ref_set = ts_ref_set;
    zT_381 = ctx->module_reg;
    zT_383 = zF_3452C137_moduleRegistryGetMo(zT_381);
    ri_mods = zT_383;
    zT_385 = 0;
    ri_i = zT_385;
    goto z_bb_75;
    z_bb_9:
    zT_379 = ts_fi + (unsigned int)(1);
    ts_fi = zT_379;
    goto z_bb_6;
    z_bb_10:
    zT_145 = ts_fn.hoisted_temps;
    zT_146 = zT_145.len;
    if ((unsigned char)(ts_tti < zT_146)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_149 = ts_fn.hoisted_temps;
    zT_150 = zT_149.items;
    zT_151 = zT_150[ts_tti];
    ts_hty = zT_151;
    zT_152 = &ref_edges;
    zT_153 = ctx->typereg;
    zT_154 = &type_visited;
    zT_155 = ts_src;
    zT_156 = ts_hty.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_152, zT_153, zT_154, zT_155, zT_156);
    zT_161 = ctx->typereg;
    zT_165 = &emitter;
    zT_162 = &zT_165->needed_tuple_set;
    zT_163 = ts_hty.type_id;
    zF_7845A68F_collectNeededTuples(zT_161, zT_162, zT_163);
    goto z_bb_13;
    z_bb_12:
    zT_170 = ts_fn.return_type;
    zT_171 = ctx->typereg;
    zT_172 = zT_171->types_len;
    if ((unsigned char)(zT_170 < (unsigned int)((unsigned int)zT_172))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_169 = ts_tti + (unsigned int)(1);
    ts_tti = zT_169;
    goto z_bb_10;
    z_bb_14:
    zT_175 = &ref_edges;
    zT_176 = ctx->typereg;
    zT_177 = &type_visited;
    zT_178 = ts_src;
    zT_179 = ts_fn.return_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_175, zT_176, zT_177, zT_178, zT_179);
    goto z_bb_15;
    z_bb_15:
    zT_185 = 0;
    ts_pi = zT_185;
    goto z_bb_16;
    z_bb_16:
    zT_186 = ts_fn.params;
    zT_187 = zT_186.len;
    if ((unsigned char)(ts_pi < zT_187)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_190 = ts_fn.params;
    zT_191 = zT_190.items;
    zT_192 = zT_191[ts_pi];
    ts_pt = zT_192;
    zT_193 = &ref_edges;
    zT_194 = ctx->typereg;
    zT_195 = &type_visited;
    zT_196 = ts_src;
    zT_197 = ts_pt.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_193, zT_194, zT_195, zT_196, zT_197);
    goto z_bb_19;
    z_bb_18:
    zT_205 = 0;
    ts_bi = zT_205;
    goto z_bb_20;
    z_bb_19:
    zT_203 = ts_pi + (unsigned int)(1);
    ts_pi = zT_203;
    goto z_bb_16;
    z_bb_20:
    zT_206 = ts_fn.blocks;
    zT_207 = zT_206.len;
    if ((unsigned char)(ts_bi < zT_207)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_210 = ts_fn.blocks;
    zT_211 = zT_210.items;
    zT_212 = zT_211[ts_bi];
    ts_blk = zT_212;
    zT_214 = 0;
    ts_ii = zT_214;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_9;
    z_bb_23:
    zT_377 = ts_bi + (unsigned int)(1);
    ts_bi = zT_377;
    goto z_bb_20;
    z_bb_24:
    zT_215 = ts_blk.insts;
    zT_216 = zT_215.len;
    if ((unsigned char)(ts_ii < zT_216)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_219 = ts_blk.insts;
    zT_220 = zT_219.items;
    zT_221 = zT_220[ts_ii];
    ts_inst = zT_221;
    zT_223 = ts_inst.tag;
    ts_tg = zT_223;
    zT_225 = 0;
    ts_edge_has = zT_225;
    zT_227 = 0;
    ts_edge_dst = zT_227;
    zT_230.tag = 23;
    if ((unsigned char)(ts_tg == zT_230.tag)) goto z_bb_28; else goto z_bb_30;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_375 = ts_ii + (unsigned int)(1);
    ts_ii = zT_375;
    goto z_bb_24;
    z_bb_28:
    zT_233 = &ts_fn;
    zT_234 = ts_inst.payload.jump._0;
    zT_238 = zF_75DE985C_lirSideGetCallDirec(zT_233, zT_234);
    ts_cd = zT_238;
    zT_239 = ts_cd.module_id;
    ts_edge_dst = zT_239;
    zT_240 = 1;
    ts_edge_has = zT_240;
    goto z_bb_29;
    z_bb_29:
    if ((unsigned char)(ts_edge_has != (unsigned char)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_30:
    zT_243.tag = 27;
    if ((unsigned char)(ts_tg == zT_243.tag)) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_246 = &ts_fn;
    zT_247 = ts_inst.payload.jump._0;
    zT_251 = zF_1AB3807F_lirSideGetTailCall(zT_246, zT_247);
    ts_tc = zT_251;
    zT_252 = ts_tc.module_id;
    ts_edge_dst = zT_252;
    zT_253 = 1;
    ts_edge_has = zT_253;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_256.tag = 28;
    if ((unsigned char)(ts_tg == zT_256.tag)) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_259 = ts_inst.payload.func_ref._0;
    zT_260 = zT_259.module_id;
    ts_edge_dst = zT_260;
    zT_261 = 1;
    ts_edge_has = zT_261;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_264.tag = 54;
    if ((unsigned char)(ts_tg == zT_264.tag)) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_267 = ts_inst.payload.load_global._0;
    zT_268 = zT_267.module_id;
    ts_edge_dst = zT_268;
    zT_269 = 1;
    ts_edge_has = zT_269;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_272.tag = 55;
    if ((unsigned char)(ts_tg == zT_272.tag)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_275 = ts_inst.payload.store_global._0;
    zT_276 = zT_275.module_id;
    ts_edge_dst = zT_276;
    zT_277 = 1;
    ts_edge_has = zT_277;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_280 = ts_edge_dst != ts_src;
    goto z_bb_44;
    z_bb_43:
    zT_280 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_280) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_282 = &ref_edges;
    zF_26476265_u32ToU32MapPut(zT_282, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + ts_edge_dst), (unsigned int)(1));
    goto z_bb_46;
    z_bb_46:
    zT_292.tag = 57;
    if ((unsigned char)(ts_tg == zT_292.tag)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_295 = emitter.std_fmt_module_id;
    zT_294 = zT_295 != (unsigned int)(4294967295u);
    goto z_bb_49;
    z_bb_48:
    zT_294 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_294) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_298 = emitter.std_fmt_module_id;
    if ((unsigned char)(zT_298 != ts_src)) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    zT_311.tag = 54;
    if ((unsigned char)(ts_tg != zT_311.tag)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_300 = &ref_edges;
    zT_306 = emitter.std_fmt_module_id;
    zF_26476265_u32ToU32MapPut(zT_300, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + zT_306), (unsigned int)(1));
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    zT_316.tag = 55;
    zT_313 = ts_tg != zT_316.tag;
    goto z_bb_56;
    z_bb_55:
    zT_313 = 0;
    goto z_bb_56;
    z_bb_56:
    if (zT_313) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    goto z_bb_27;
    z_bb_58:
    zT_319 = 0;
    ts_name_id = zT_319;
    zT_321 = 0;
    ts_tmp = zT_321;
    zT_324.tag = 54;
    if ((unsigned char)(ts_tg == zT_324.tag)) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    zT_327 = ts_inst.payload.load_global._0;
    zT_328 = zT_327.name_id;
    ts_name_id = zT_328;
    zT_330 = ts_inst.payload.load_global._0;
    zT_331 = zT_330.result;
    ts_tmp = zT_331;
    goto z_bb_60;
    z_bb_60:
    zT_339 = 0;
    ts_tid = zT_339;
    zT_341 = 0;
    ts_tj = zT_341;
    goto z_bb_62;
    z_bb_61:
    zT_333 = ts_inst.payload.store_global._0;
    zT_334 = zT_333.name_id;
    ts_name_id = zT_334;
    zT_336 = ts_inst.payload.store_global._0;
    zT_337 = zT_336.value;
    ts_tmp = zT_337;
    goto z_bb_60;
    z_bb_62:
    zT_342 = ts_fn.hoisted_temps;
    zT_343 = zT_342.len;
    if ((unsigned char)(ts_tj < zT_343)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_346 = ts_fn.hoisted_temps;
    zT_347 = zT_346.items;
    zT_348 = zT_347[ts_tj];
    ts_ht = zT_348;
    zT_349 = ts_ht.temp_id;
    if ((unsigned char)(zT_349 == ts_tmp)) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    zT_354 = ctx->typereg;
    zT_355 = zT_354->types_len;
    if ((unsigned char)(ts_tid >= (unsigned int)((unsigned int)zT_355))) goto z_bb_68; else goto z_bb_69;
    z_bb_65:
    zT_353 = ts_tj + (unsigned int)(1);
    ts_tj = zT_353;
    goto z_bb_62;
    z_bb_66:
    zT_351 = ts_ht.type_id;
    ts_tid = zT_351;
    goto z_bb_64;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    goto z_bb_27;
    z_bb_69:
    zT_359 = ctx->typereg;
    zT_360 = zT_359->types_items;
    zT_361 = (unsigned int)ts_tid;
    zT_362 = zT_360[zT_361];
    ts_ty = zT_362;
    zT_363 = ts_ty.name_id;
    if ((unsigned char)(zT_363 != (unsigned int)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_367 = ts_ty.name_id;
    zT_366 = zT_367 == ts_name_id;
    goto z_bb_72;
    z_bb_71:
    zT_366 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_366) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_369 = &ts_ref_set;
    zT_370 = ts_tid;
    zF_26476265_u32ToU32MapPut(zT_369, zT_370, (unsigned int)(1));
    goto z_bb_74;
    z_bb_74:
    goto z_bb_27;
    z_bb_75:
    zT_387 = ri_mods.len;
    if ((unsigned char)(ri_i < zT_387)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_389 = ri_mods.ptr;
    zT_390 = zT_389[ri_i];
    zT_391 = zT_390.id;
    if ((unsigned char)(zT_391 == (unsigned int)(0))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_434 = 0;
    gt_i = zT_434;
    goto z_bb_92;
    z_bb_78:
    zT_432 = ri_i + (unsigned int)(1);
    ri_i = zT_432;
    goto z_bb_75;
    z_bb_79:
    goto z_bb_78;
    z_bb_80:
    zT_395 = 0;
    ri_has = zT_395;
    zT_397 = 0;
    gd_ri = zT_397;
    goto z_bb_81;
    z_bb_81:
    zT_398 = ctx->global_decls;
    zT_399 = zT_398.len;
    if ((unsigned char)(gd_ri < zT_399)) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_402 = ctx->global_decls;
    zT_403 = zT_402.items;
    zT_404 = zT_403[gd_ri];
    gd_g = zT_404;
    zT_405 = gd_g.module_id;
    zT_406 = ri_mods.ptr;
    zT_407 = zT_406[ri_i];
    zT_408 = zT_407.id;
    if ((unsigned char)(zT_405 == zT_408)) goto z_bb_85; else goto z_bb_86;
    z_bb_83:
    if ((unsigned char)(ri_has != (unsigned char)(0))) goto z_bb_90; else goto z_bb_91;
    z_bb_84:
    zT_416 = gd_ri + (unsigned int)(1);
    gd_ri = zT_416;
    goto z_bb_81;
    z_bb_85:
    zT_411 = gd_g.has_runtime_init;
    zT_410 = zT_411 != (unsigned char)(0);
    goto z_bb_87;
    z_bb_86:
    zT_410 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_410) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_414 = 1;
    ri_has = zT_414;
    goto z_bb_83;
    z_bb_89:
    goto z_bb_84;
    z_bb_90:
    zT_419 = &ref_edges;
    zT_426 = ri_mods.ptr;
    zT_427 = zT_426[ri_i];
    zT_428 = zT_427.id;
    zF_26476265_u32ToU32MapPut(zT_419, (unsigned int)((unsigned int)(0) + zT_428), (unsigned int)(1));
    goto z_bb_91;
    z_bb_91:
    goto z_bb_78;
    z_bb_92:
    zT_435 = ctx->global_decls;
    zT_436 = zT_435.len;
    if ((unsigned char)(gt_i < zT_436)) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_439 = ctx->global_decls;
    zT_440 = zT_439.items;
    zT_441 = zT_440[gt_i];
    gt_g = zT_441;
    zT_442 = gt_g.type_id;
    zT_443 = ctx->typereg;
    zT_444 = zT_443->types_len;
    if ((unsigned char)(zT_442 >= (unsigned int)((unsigned int)zT_444))) goto z_bb_96; else goto z_bb_97;
    z_bb_94:
    zT_482 = ctx->alloc;
    zT_480 = &zT_482->emission;
    zT_481 = ri_mods.len;
    zT_486 = zF_619D56E6_u32ToU32MapInitCap(zT_480, zT_481);
    reachable = zT_486;
    zT_487 = &reachable;
    zF_26476265_u32ToU32MapPut(zT_487, (unsigned int)(0), (unsigned int)(1));
    zT_494 = 1;
    rf_changed = zT_494;
    goto z_bb_103;
    z_bb_95:
    zT_478 = gt_i + (unsigned int)(1);
    gt_i = zT_478;
    goto z_bb_92;
    z_bb_96:
    goto z_bb_95;
    z_bb_97:
    zT_448 = ctx->typereg;
    zT_449 = zT_448->types_items;
    zT_450 = gt_g.type_id;
    zT_451 = (unsigned int)zT_450;
    zT_452 = zT_449[zT_451];
    gt_ty = zT_452;
    zT_453 = ctx->typereg;
    zT_457 = &emitter;
    zT_454 = &zT_457->needed_tuple_set;
    zT_455 = gt_g.type_id;
    zF_7845A68F_collectNeededTuples(zT_453, zT_454, zT_455);
    zT_460 = gt_ty.name_id;
    if ((unsigned char)(zT_460 != (unsigned int)(0))) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_464 = gt_ty.name_id;
    zT_465 = gt_g.name_id;
    zT_463 = zT_464 == zT_465;
    goto z_bb_100;
    z_bb_99:
    zT_463 = 0;
    goto z_bb_100;
    z_bb_100:
    if (zT_463) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    goto z_bb_95;
    z_bb_102:
    zT_467 = &ref_edges;
    zT_468 = ctx->typereg;
    zT_469 = &type_visited;
    zT_470 = gt_g.module_id;
    zT_471 = gt_g.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_467, zT_468, zT_469, zT_470, zT_471);
    goto z_bb_95;
    z_bb_103:
    if ((unsigned char)(rf_changed != (unsigned char)(0))) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    zT_497 = 0;
    rf_changed = zT_497;
    zT_499 = 0;
    rf_s = zT_499;
    goto z_bb_107;
    z_bb_105:
    emitter.reachable = reachable;
    zT_546 = ctx->cli;
    zT_547 = zT_546.output_dir_set;
    if (zT_547) goto z_bb_123; else goto z_bb_124;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_501 = ri_mods.len;
    if ((unsigned char)(rf_s < zT_501)) goto z_bb_108; else goto z_bb_109;
    z_bb_108:
    zT_504 = ri_mods.ptr;
    zT_505 = zT_504[rf_s];
    zT_506 = zT_505.id;
    rf_src = zT_506;
    zT_507 = &reachable;
    zT_508 = rf_src;
    zT_510 = zF_F3EE5998_u32ToU32MapGet(zT_507, zT_508);
    zT_511 = zT_510.has_value;
    if ((unsigned char)(!zT_511)) goto z_bb_111; else goto z_bb_112;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    zT_545 = rf_s + (unsigned int)(1);
    rf_s = zT_545;
    goto z_bb_107;
    z_bb_111:
    goto z_bb_110;
    z_bb_112:
    zT_514 = 0;
    rf_d = zT_514;
    goto z_bb_113;
    z_bb_113:
    zT_516 = ri_mods.len;
    if ((unsigned char)(rf_d < zT_516)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_519 = ri_mods.ptr;
    zT_520 = zT_519[rf_d];
    zT_521 = zT_520.id;
    rf_dst = zT_521;
    if ((unsigned char)(rf_dst == rf_src)) goto z_bb_117; else goto z_bb_118;
    z_bb_115:
    goto z_bb_110;
    z_bb_116:
    zT_543 = rf_d + (unsigned int)(1);
    rf_d = zT_543;
    goto z_bb_113;
    z_bb_117:
    goto z_bb_116;
    z_bb_118:
    zT_523 = &reachable;
    zT_524 = rf_dst;
    zT_526 = zF_F3EE5998_u32ToU32MapGet(zT_523, zT_524);
    zT_527 = zT_526.has_value;
    if (zT_527) goto z_bb_119; else goto z_bb_120;
    z_bb_119:
    goto z_bb_116;
    z_bb_120:
    zT_528 = &ref_edges;
    zT_534 = zF_F3EE5998_u32ToU32MapGet(zT_528, (unsigned int)((unsigned int)(rf_src * (unsigned int)(65536)) + rf_dst));
    zT_535 = zT_534.has_value;
    if (zT_535) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_536 = &reachable;
    zT_537 = rf_dst;
    zF_26476265_u32ToU32MapPut(zT_536, zT_537, (unsigned int)(1));
    zT_541 = 1;
    rf_changed = zT_541;
    goto z_bb_122;
    z_bb_122:
    goto z_bb_116;
    z_bb_123:
    zT_549 = 0;
    poi = zT_549;
    goto z_bb_125;
    z_bb_124:
    cwriter = zT_1162;
    zT_1163 = zF_F9E678C3_bufferedWriterInit();
    cwriter = zT_1163;
    zT_1164 = &cwriter;
    zF_225796FB_emitIncludes(zT_1164);
    zT_1166 = &cwriter;
    zF_B35650AD_bufferedWriterFlush(zT_1166);
    zT_1169 = ctx->module_reg;
    zT_1172 = ctx->alloc;
    zT_1170 = &zT_1172->emission;
    zT_1174 = zF_1E2E8788_cincludeUnionAll(zT_1169, zT_1170);
    c_incs = zT_1174;
    zT_1175 = &emitter;
    zT_1176 = module_name;
    zT_1177 = c_incs;
    zT_1178 = ctx->pointer_only_ids;
    zT_1179 = ctx->pointer_only_len;
    zF_503E3056_emitModule(zT_1175, zT_1176, zT_1177, zT_1178, zT_1179);
    zT_1184 = "FINAL_FLUSH\n";
    zT_1186 = 12;
    zT_1185.ptr = zT_1184;
    zT_1185.len = zT_1186;
    ff_m = zT_1185;
    zT_1187 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1187);
    zT_1189 = &emitter;
    zT_1188 = &zT_1189->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1188);
    zT_1191 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1191);
    zT_1193 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1193);
    return;
    z_bb_125:
    zT_550 = ctx->pointer_only_len;
    if ((unsigned char)(poi < zT_550)) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_555 = &emitter;
    zT_552 = &zT_555->pointer_only_map;
    zT_557 = ctx->pointer_only_ids;
    zT_558 = (unsigned int)poi;
    zT_553 = zT_557[zT_558];
    zF_26476265_u32ToU32MapPut(zT_552, zT_553, (unsigned int)(1));
    goto z_bb_128;
    z_bb_127:
    zT_565 = ctx->typereg;
    zT_568 = ctx->alloc;
    zT_566 = &zT_568->emission;
    zT_570 = zF_1DD26D63_tstTopologicalSort(zT_565, zT_566);
    sorted = zT_570;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_572[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hpath[_i] = zT_572[_i];
        _i++;
    }
}
    zT_574 = 0;
    hp = zT_574;
    zT_576 = ctx->cli;
    zT_577 = zT_576.output_dir;
    od = zT_577;
    zT_578 = &emitter;
    zT_579 = od;
    zF_AB1E9CD4_emitSupportFiles(zT_578, zT_579);
    zT_582 = 0;
    hi = zT_582;
    goto z_bb_129;
    z_bb_128:
    zT_561 = 1;
    zT_563 = poi + (unsigned int)((unsigned int)zT_561);
    poi = zT_563;
    goto z_bb_125;
    z_bb_129:
    zT_584 = od.len;
    if ((unsigned char)(hi < zT_584)) goto z_bb_133; else goto z_bb_134;
    z_bb_130:
    zT_589 = od.ptr;
    zT_590 = zT_589[hi];
    hpath[hp] = zT_590;
    zT_591 = 1;
    zT_593 = hp + (unsigned int)((unsigned int)zT_591);
    hp = zT_593;
    goto z_bb_132;
    z_bb_131:
    zT_597 = 47;
    hpath[hp] = zT_597;
    zT_598 = 1;
    zT_600 = hp + (unsigned int)((unsigned int)zT_598);
    hp = zT_600;
    zT_602 = "zig_special_types.h";
    zT_604 = 19;
    zT_603.ptr = zT_602;
    zT_603.len = zT_604;
    hfn = zT_603;
    zT_606 = 0;
    hfi = zT_606;
    goto z_bb_136;
    z_bb_132:
    zT_594 = 1;
    zT_596 = hi + (unsigned int)((unsigned int)zT_594);
    hi = zT_596;
    goto z_bb_129;
    z_bb_133:
    zT_586 = hp < (unsigned int)(510);
    goto z_bb_135;
    z_bb_134:
    zT_586 = 0;
    goto z_bb_135;
    z_bb_135:
    if (zT_586) goto z_bb_130; else goto z_bb_131;
    z_bb_136:
    zT_608 = hfn.len;
    if ((unsigned char)(hfi < zT_608)) goto z_bb_140; else goto z_bb_141;
    z_bb_137:
    zT_613 = hfn.ptr;
    zT_614 = zT_613[hfi];
    hpath[hp] = zT_614;
    zT_615 = 1;
    zT_617 = hp + (unsigned int)((unsigned int)zT_615);
    hp = zT_617;
    goto z_bb_139;
    z_bb_138:
    zT_626 = 0;
    zT_627 = (unsigned char*)((unsigned char*)hpath) + zT_626;
    zT_628 = hp - zT_626;
    zT_629.ptr = zT_627;
    zT_629.len = zT_628;
    zT_622 = zT_629;
    zT_631 = zF_39FE21EF_fileOpen(zT_622, (int)(0));
    fd = zT_631;
    if ((unsigned char)(fd == zG_CC81CC5F_INVALID_FD)) goto z_bb_143; else goto z_bb_144;
    z_bb_139:
    zT_618 = 1;
    zT_620 = hfi + (unsigned int)((unsigned int)zT_618);
    hfi = zT_620;
    goto z_bb_136;
    z_bb_140:
    zT_610 = hp < (unsigned int)(511);
    goto z_bb_142;
    z_bb_141:
    zT_610 = 0;
    goto z_bb_142;
    z_bb_142:
    if (zT_610) goto z_bb_137; else goto z_bb_138;
    z_bb_143:
    zT_635 = "error: cannot open output file\n";
    zT_637 = 31;
    zT_636.ptr = zT_635;
    zT_636.len = zT_637;
    emsg = zT_636;
    zT_638 = emsg;
    zF_E4B2EF19_stderr_write(zT_638);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_144;
    z_bb_144:
    hw = zT_642;
    zT_643 = fd;
    zT_644 = zF_E00097E1_bufferedWriterInitF(zT_643);
    hw = zT_644;
    emitter.writer = hw;
    zT_645 = &emitter;
    zT_646 = ctx->typereg;
    zT_647 = sorted;
    zF_62841416_emitSharedHeader(zT_645, zT_646, zT_647);
    zT_651 = &emitter;
    zT_650 = &zT_651->writer;
    zF_B35650AD_bufferedWriterFlush(zT_650);
    zT_653 = fd;
    zF_B30B1D79_fileClose(zT_653);
    zT_655 = ctx->module_reg;
    zT_657 = zF_3452C137_moduleRegistryGetMo(zT_655);
    mods = zT_657;
    emitter.prune_active = (unsigned char)(1);
    zT_660 = ctx->lir_slots;
    zT_661 = zT_660.len;
    slot_count = zT_661;
    zT_662 = 0;
    if ((unsigned char)(slot_count > (unsigned int)zT_662)) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_668 = ctx->alloc;
    zT_665 = &zT_668->emission;
    zT_672 = mods.len;
    zT_675 = zF_1395EB68_sandAlloc(zT_665, (unsigned int)((unsigned int)(4) * zT_672), (unsigned int)(4));
    zT_676 = zT_675.is_error;
    if (zT_676) goto z_bb_147; else goto z_bb_148;
    z_bb_146:
    zT_776 = 0;
    fn_cursor = zT_776;
    zT_778 = 0;
    mi = zT_778;
    goto z_bb_176;
    z_bb_147:
    pal_trap();
    z_bb_148:
    zT_677 = zT_675.data.payload;
    goto z_bb_149;
    z_bb_149:
    zT_679 = (unsigned int*)zT_677;
    grp_counts = zT_679;
    zT_684 = ctx->alloc;
    zT_681 = &zT_684->emission;
    zT_688 = mods.len;
    zT_691 = zF_1395EB68_sandAlloc(zT_681, (unsigned int)((unsigned int)(4) * zT_688), (unsigned int)(4));
    zT_692 = zT_691.is_error;
    if (zT_692) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    pal_trap();
    z_bb_151:
    zT_693 = zT_691.data.payload;
    goto z_bb_152;
    z_bb_152:
    zT_695 = (unsigned int*)zT_693;
    grp_cursor = zT_695;
    zT_697 = 0;
    gci = zT_697;
    goto z_bb_153;
    z_bb_153:
    zT_699 = mods.len;
    if ((unsigned char)(gci < zT_699)) goto z_bb_154; else goto z_bb_155;
    z_bb_154:
    zT_701 = 0;
    grp_counts[gci] = zT_701;
    goto z_bb_156;
    z_bb_155:
    zT_706 = 0;
    gsi = zT_706;
    goto z_bb_157;
    z_bb_156:
    zT_702 = 1;
    zT_704 = gci + (unsigned int)((unsigned int)zT_702);
    gci = zT_704;
    goto z_bb_153;
    z_bb_157:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_709 = ctx->lir_slots;
    zT_710 = zT_709.items;
    zT_711 = zT_710[gsi];
    zT_712 = zT_711.module_id;
    gsmid = zT_712;
    zT_715 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) < zT_715)) goto z_bb_161; else goto z_bb_162;
    z_bb_159:
    zT_726 = 0;
    gacc = zT_726;
    zT_727 = 0;
    gci = zT_727;
    goto z_bb_163;
    z_bb_160:
    zT_722 = 1;
    zT_724 = gsi + (unsigned int)((unsigned int)zT_722);
    gsi = zT_724;
    goto z_bb_157;
    z_bb_161:
    zT_717 = (unsigned int)gsmid;
    zT_718 = grp_counts[zT_717];
    zT_720 = zT_718 + (unsigned int)(1);
    zT_721 = (unsigned int)gsmid;
    grp_counts[zT_721] = zT_720;
    goto z_bb_162;
    z_bb_162:
    goto z_bb_160;
    z_bb_163:
    zT_729 = mods.len;
    if ((unsigned char)(gci < zT_729)) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    grp_cursor[gci] = gacc;
    zT_731 = grp_counts[gci];
    zT_732 = gacc + zT_731;
    gacc = zT_732;
    goto z_bb_166;
    z_bb_165:
    zT_740 = ctx->alloc;
    zT_737 = &zT_740->emission;
    zT_745 = zF_1395EB68_sandAlloc(zT_737, (unsigned int)((unsigned int)(12) * slot_count), (unsigned int)(4));
    zT_746 = zT_745.is_error;
    if (zT_746) goto z_bb_167; else goto z_bb_168;
    z_bb_166:
    zT_733 = 1;
    zT_735 = gci + (unsigned int)((unsigned int)zT_733);
    gci = zT_735;
    goto z_bb_163;
    z_bb_167:
    pal_trap();
    z_bb_168:
    zT_747 = zT_745.data.payload;
    goto z_bb_169;
    z_bb_169:
    zT_749 = (zT_E7714190_LirSlot*)zT_747;
    grouped = zT_749;
    zT_750 = 0;
    gsi = zT_750;
    goto z_bb_170;
    z_bb_170:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_171; else goto z_bb_172;
    z_bb_171:
    zT_753 = ctx->lir_slots;
    zT_754 = zT_753.items;
    zT_755 = zT_754[gsi];
    gslot = zT_755;
    zT_757 = gslot.module_id;
    gsmid = zT_757;
    zT_760 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) >= zT_760)) goto z_bb_174; else goto z_bb_175;
    z_bb_172:
    zT_772 = &ctx->lir_slots;
    zT_772->items = grouped;
    zT_774 = &ctx->lir_slots;
    zT_774->len = (unsigned int)((unsigned int)gacc);
    emitter.fn_slots = grouped;
    goto z_bb_146;
    z_bb_173:
    zT_769 = 1;
    zT_771 = gsi + (unsigned int)((unsigned int)zT_769);
    gsi = zT_771;
    goto z_bb_170;
    z_bb_174:
    goto z_bb_173;
    z_bb_175:
    zT_763 = (unsigned int)gsmid;
    zT_764 = grp_cursor[zT_763];
    gdst = zT_764;
    zT_765 = (unsigned int)gdst;
    grouped[zT_765] = gslot;
    zT_767 = gdst + (unsigned int)(1);
    zT_768 = (unsigned int)gsmid;
    grp_cursor[zT_768] = zT_767;
    goto z_bb_173;
    z_bb_176:
    zT_780 = mods.len;
    if ((unsigned char)(mi < zT_780)) goto z_bb_177; else goto z_bb_178;
    z_bb_177:
    zT_783 = mods.ptr;
    zT_784 = zT_783[mi];
    m = zT_784;
    fn_start = fn_cursor;
    goto z_bb_180;
    z_bb_178:
    zT_1151 = &emitter;
    zT_1152 = od;
    zT_1155 = ctx->cli;
    zT_1153 = zT_1155.target_is_windows;
    zF_A62DB57E_emitBuildScripts(zT_1151, zT_1152, zT_1153);
    zT_1157 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1157);
    zT_1159 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1159);
    return;
    z_bb_179:
    zT_1148 = 1;
    zT_1150 = mi + (unsigned int)((unsigned int)zT_1148);
    mi = zT_1150;
    goto z_bb_176;
    z_bb_180:
    zT_786 = ctx->lir_slots;
    zT_787 = zT_786.len;
    if ((unsigned char)(fn_cursor < zT_787)) goto z_bb_184; else goto z_bb_185;
    z_bb_181:
    goto z_bb_183;
    z_bb_182:
    zT_798 = &reachable;
    zT_799 = m.id;
    zT_802 = zF_F3EE5998_u32ToU32MapGet(zT_798, zT_799);
    zT_803 = zT_802.has_value;
    if ((unsigned char)(!zT_803)) goto z_bb_187; else goto z_bb_188;
    z_bb_183:
    zT_797 = fn_cursor + (unsigned int)(1);
    fn_cursor = zT_797;
    goto z_bb_180;
    z_bb_184:
    zT_790 = ctx->lir_slots;
    zT_791 = zT_790.items;
    zT_792 = zT_791[fn_cursor];
    zT_793 = zT_792.module_id;
    zT_794 = m.id;
    zT_789 = zT_793 == zT_794;
    goto z_bb_186;
    z_bb_185:
    zT_789 = 0;
    goto z_bb_186;
    z_bb_186:
    if (zT_789) goto z_bb_181; else goto z_bb_182;
    z_bb_187:
    goto z_bb_179;
    z_bb_188:
    emitter.fn_slots_start = fn_start;
    emitter.fn_slots_len = (unsigned int)(fn_cursor - fn_start);
    zT_807 = &emitter;
    zT_808 = m.id;
    zT_811 = zF_E295413A_moduleQualifiedName(zT_807, zT_808);
    base = zT_811;
    zT_813 = od.len;
    zT_817 = base.len;
    if ((unsigned char)((unsigned int)((unsigned int)((unsigned int)(zT_813 + (unsigned int)(1)) + zT_817) + (unsigned int)(3)) > (unsigned int)(511))) goto z_bb_189; else goto z_bb_190;
    z_bb_189:
    zT_824 = "error: output filename too long\n";
    zT_826 = 32;
    zT_825.ptr = zT_824;
    zT_825.len = zT_826;
    lmsg = zT_825;
    zT_827 = lmsg;
    zF_E4B2EF19_stderr_write(zT_827);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_190;
    z_bb_190:
    zT_831 = 0;
    hp2 = zT_831;
    zT_833 = 0;
    hi2 = zT_833;
    goto z_bb_191;
    z_bb_191:
    zT_835 = od.len;
    if ((unsigned char)(hi2 < zT_835)) goto z_bb_195; else goto z_bb_196;
    z_bb_192:
    zT_840 = od.ptr;
    zT_841 = zT_840[hi2];
    hpath[hp2] = zT_841;
    zT_842 = 1;
    zT_844 = hp2 + (unsigned int)((unsigned int)zT_842);
    hp2 = zT_844;
    goto z_bb_194;
    z_bb_193:
    zT_848 = 47;
    hpath[hp2] = zT_848;
    zT_849 = 1;
    zT_851 = hp2 + (unsigned int)((unsigned int)zT_849);
    hp2 = zT_851;
    zT_853 = 0;
    bi = zT_853;
    goto z_bb_198;
    z_bb_194:
    zT_845 = 1;
    zT_847 = hi2 + (unsigned int)((unsigned int)zT_845);
    hi2 = zT_847;
    goto z_bb_191;
    z_bb_195:
    zT_837 = hp2 < (unsigned int)(510);
    goto z_bb_197;
    z_bb_196:
    zT_837 = 0;
    goto z_bb_197;
    z_bb_197:
    if (zT_837) goto z_bb_192; else goto z_bb_193;
    z_bb_198:
    zT_855 = base.len;
    if ((unsigned char)(bi < zT_855)) goto z_bb_202; else goto z_bb_203;
    z_bb_199:
    zT_860 = base.ptr;
    zT_861 = zT_860[bi];
    hpath[hp2] = zT_861;
    zT_862 = 1;
    zT_864 = hp2 + (unsigned int)((unsigned int)zT_862);
    hp2 = zT_864;
    goto z_bb_201;
    z_bb_200:
    zT_869 = ".h";
    zT_871 = 2;
    zT_870.ptr = zT_869;
    zT_870.len = zT_871;
    hext = zT_870;
    zT_873 = 0;
    hx = zT_873;
    goto z_bb_205;
    z_bb_201:
    zT_865 = 1;
    zT_867 = bi + (unsigned int)((unsigned int)zT_865);
    bi = zT_867;
    goto z_bb_198;
    z_bb_202:
    zT_857 = hp2 < (unsigned int)(510);
    goto z_bb_204;
    z_bb_203:
    zT_857 = 0;
    goto z_bb_204;
    z_bb_204:
    if (zT_857) goto z_bb_199; else goto z_bb_200;
    z_bb_205:
    zT_875 = hext.len;
    if ((unsigned char)(hx < zT_875)) goto z_bb_209; else goto z_bb_210;
    z_bb_206:
    zT_880 = hext.ptr;
    zT_881 = zT_880[hx];
    hpath[hp2] = zT_881;
    zT_882 = 1;
    zT_884 = hp2 + (unsigned int)((unsigned int)zT_882);
    hp2 = zT_884;
    goto z_bb_208;
    z_bb_207:
    zT_893 = 0;
    zT_894 = (unsigned char*)((unsigned char*)hpath) + zT_893;
    zT_895 = hp2 - zT_893;
    zT_896.ptr = zT_894;
    zT_896.len = zT_895;
    zT_889 = zT_896;
    zT_898 = zF_39FE21EF_fileOpen(zT_889, (int)(0));
    fd2 = zT_898;
    if ((unsigned char)(fd2 == zG_CC81CC5F_INVALID_FD)) goto z_bb_212; else goto z_bb_213;
    z_bb_208:
    zT_885 = 1;
    zT_887 = hx + (unsigned int)((unsigned int)zT_885);
    hx = zT_887;
    goto z_bb_205;
    z_bb_209:
    zT_877 = hp2 < (unsigned int)(511);
    goto z_bb_211;
    z_bb_210:
    zT_877 = 0;
    goto z_bb_211;
    z_bb_211:
    if (zT_877) goto z_bb_206; else goto z_bb_207;
    z_bb_212:
    zT_902 = "error: cannot open output file\n";
    zT_904 = 31;
    zT_903.ptr = zT_902;
    zT_903.len = zT_904;
    emsg2 = zT_903;
    zT_905 = emsg2;
    zF_E4B2EF19_stderr_write(zT_905);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_213;
    z_bb_213:
    hw2 = zT_909;
    zT_910 = fd2;
    zT_911 = zF_E00097E1_bufferedWriterInitF(zT_910);
    hw2 = zT_911;
    emitter.writer = hw2;
    zT_913 = m.imports_start;
    zT_914 = (unsigned int)zT_913;
    dep_start = zT_914;
    zT_916 = m.import_count;
    zT_918 = dep_start + (unsigned int)((unsigned int)zT_916);
    dep_end = zT_918;
    zT_920 = ctx->module_reg;
    zT_921 = zT_920->import_edges_items;
    zT_922 = zT_921 + dep_start;
    zT_923 = dep_end - dep_start;
    zT_924.ptr = zT_922;
    zT_924.len = zT_923;
    dep_ids = zT_924;
    zT_926 = m.c_includes;
    zT_927 = zT_926.items;
    zT_928 = m.c_includes;
    zT_929 = zT_928.len;
    zT_930 = 0;
    zT_931 = zT_927 + zT_930;
    zT_932 = zT_929 - zT_930;
    zT_933.ptr = zT_931;
    zT_933.len = zT_932;
    m_c_incs = zT_933;
    zT_938 = ctx->alloc;
    zT_935 = &zT_938->emission;
    zT_942 = mods.len;
    zT_945 = zF_1395EB68_sandAlloc(zT_935, (unsigned int)((unsigned int)(4) * zT_942), (unsigned int)(4));
    zT_946 = zT_945.is_error;
    if (zT_946) goto z_bb_214; else goto z_bb_215;
    z_bb_214:
    pal_trap();
    z_bb_215:
    zT_947 = zT_945.data.payload;
    goto z_bb_216;
    z_bb_216:
    inc_raw = zT_947;
    zT_950 = (unsigned int*)inc_raw;
    inc_arr = zT_950;
    zT_952 = 0;
    inc_n = zT_952;
    zT_954 = 0;
    di0 = zT_954;
    goto z_bb_217;
    z_bb_217:
    zT_956 = dep_ids.len;
    if ((unsigned char)(di0 < zT_956)) goto z_bb_218; else goto z_bb_219;
    z_bb_218:
    zT_959 = dep_ids.ptr;
    zT_960 = zT_959[di0];
    dd0 = zT_960;
    zT_961 = m.id;
    if ((unsigned char)(dd0 == zT_961)) goto z_bb_221; else goto z_bb_222;
    z_bb_219:
    zT_986 = 0;
    vd0 = zT_986;
    goto z_bb_233;
    z_bb_220:
    zT_984 = di0 + (unsigned int)(1);
    di0 = zT_984;
    goto z_bb_217;
    z_bb_221:
    goto z_bb_220;
    z_bb_222:
    zT_963 = &reachable;
    zT_964 = dd0;
    zT_966 = zF_F3EE5998_u32ToU32MapGet(zT_963, zT_964);
    zT_967 = zT_966.has_value;
    if ((unsigned char)(!zT_967)) goto z_bb_223; else goto z_bb_224;
    z_bb_223:
    goto z_bb_220;
    z_bb_224:
    zT_970 = 0;
    dup0 = zT_970;
    zT_972 = 0;
    dj0 = zT_972;
    goto z_bb_225;
    z_bb_225:
    if ((unsigned char)(dj0 < inc_n)) goto z_bb_226; else goto z_bb_227;
    z_bb_226:
    zT_974 = inc_arr[dj0];
    if ((unsigned char)(zT_974 == dd0)) goto z_bb_229; else goto z_bb_230;
    z_bb_227:
    if ((unsigned char)(dup0 != (unsigned char)(0))) goto z_bb_231; else goto z_bb_232;
    z_bb_228:
    zT_978 = dj0 + (unsigned int)(1);
    dj0 = zT_978;
    goto z_bb_225;
    z_bb_229:
    zT_976 = 1;
    dup0 = zT_976;
    goto z_bb_227;
    z_bb_230:
    goto z_bb_228;
    z_bb_231:
    goto z_bb_220;
    z_bb_232:
    inc_arr[inc_n] = dd0;
    zT_982 = inc_n + (unsigned int)(1);
    inc_n = zT_982;
    goto z_bb_220;
    z_bb_233:
    zT_988 = mods.len;
    if ((unsigned char)(vd0 < zT_988)) goto z_bb_234; else goto z_bb_235;
    z_bb_234:
    zT_991 = mods.ptr;
    zT_992 = zT_991[vd0];
    zT_993 = zT_992.id;
    vdd0 = zT_993;
    zT_994 = m.id;
    if ((unsigned char)(vdd0 == zT_994)) goto z_bb_237; else goto z_bb_238;
    z_bb_235:
    zT_1029 = 0;
    zT_1030 = inc_arr + zT_1029;
    zT_1031 = inc_n - zT_1029;
    zT_1032.ptr = zT_1030;
    zT_1032.len = zT_1031;
    inc_slice = zT_1032;
    zT_1033 = &emitter;
    zT_1034 = m.id;
    zT_1035 = base;
    zT_1036 = m_c_incs;
    zT_1037 = inc_slice;
    zT_1038 = sorted;
    zF_1AF3E3A9_emitModuleHeaderFil(zT_1033, zT_1034, zT_1035, zT_1036, zT_1037, zT_1038);
    zT_1042 = &emitter;
    zT_1041 = &zT_1042->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1041);
    zT_1044 = fd2;
    zF_B30B1D79_fileClose(zT_1044);
    zT_1046 = "FINAL_FLUSH\n";
    zT_1048 = 12;
    zT_1047.ptr = zT_1046;
    zT_1047.len = zT_1048;
    ff_m = zT_1047;
    zT_1049 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1049);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_1051[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        cpath[_i] = zT_1051[_i];
        _i++;
    }
}
    zT_1053 = 0;
    cp2 = zT_1053;
    zT_1055 = 0;
    ci2 = zT_1055;
    goto z_bb_251;
    z_bb_236:
    zT_1027 = vd0 + (unsigned int)(1);
    vd0 = zT_1027;
    goto z_bb_233;
    z_bb_237:
    goto z_bb_236;
    z_bb_238:
    zT_996 = &reachable;
    zT_997 = vdd0;
    zT_999 = zF_F3EE5998_u32ToU32MapGet(zT_996, zT_997);
    zT_1000 = zT_999.has_value;
    if ((unsigned char)(!zT_1000)) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    goto z_bb_236;
    z_bb_240:
    zT_1002 = &ref_edges;
    zT_1005 = m.id;
    zT_1009 = zF_F3EE5998_u32ToU32MapGet(zT_1002, (unsigned int)((unsigned int)(zT_1005 * (unsigned int)(65536)) + vdd0));
    zT_1010 = zT_1009.has_value;
    if ((unsigned char)(!zT_1010)) goto z_bb_241; else goto z_bb_242;
    z_bb_241:
    goto z_bb_236;
    z_bb_242:
    zT_1013 = 0;
    dup1 = zT_1013;
    zT_1015 = 0;
    dj1 = zT_1015;
    goto z_bb_243;
    z_bb_243:
    if ((unsigned char)(dj1 < inc_n)) goto z_bb_244; else goto z_bb_245;
    z_bb_244:
    zT_1017 = inc_arr[dj1];
    if ((unsigned char)(zT_1017 == vdd0)) goto z_bb_247; else goto z_bb_248;
    z_bb_245:
    if ((unsigned char)(dup1 != (unsigned char)(0))) goto z_bb_249; else goto z_bb_250;
    z_bb_246:
    zT_1021 = dj1 + (unsigned int)(1);
    dj1 = zT_1021;
    goto z_bb_243;
    z_bb_247:
    zT_1019 = 1;
    dup1 = zT_1019;
    goto z_bb_245;
    z_bb_248:
    goto z_bb_246;
    z_bb_249:
    goto z_bb_236;
    z_bb_250:
    inc_arr[inc_n] = vdd0;
    zT_1025 = inc_n + (unsigned int)(1);
    inc_n = zT_1025;
    goto z_bb_236;
    z_bb_251:
    zT_1057 = od.len;
    if ((unsigned char)(ci2 < zT_1057)) goto z_bb_255; else goto z_bb_256;
    z_bb_252:
    zT_1062 = od.ptr;
    zT_1063 = zT_1062[ci2];
    cpath[cp2] = zT_1063;
    zT_1064 = 1;
    zT_1066 = cp2 + (unsigned int)((unsigned int)zT_1064);
    cp2 = zT_1066;
    goto z_bb_254;
    z_bb_253:
    zT_1070 = 47;
    cpath[cp2] = zT_1070;
    zT_1071 = 1;
    zT_1073 = cp2 + (unsigned int)((unsigned int)zT_1071);
    cp2 = zT_1073;
    zT_1075 = 0;
    cbi = zT_1075;
    goto z_bb_258;
    z_bb_254:
    zT_1067 = 1;
    zT_1069 = ci2 + (unsigned int)((unsigned int)zT_1067);
    ci2 = zT_1069;
    goto z_bb_251;
    z_bb_255:
    zT_1059 = cp2 < (unsigned int)(510);
    goto z_bb_257;
    z_bb_256:
    zT_1059 = 0;
    goto z_bb_257;
    z_bb_257:
    if (zT_1059) goto z_bb_252; else goto z_bb_253;
    z_bb_258:
    zT_1077 = base.len;
    if ((unsigned char)(cbi < zT_1077)) goto z_bb_262; else goto z_bb_263;
    z_bb_259:
    zT_1082 = base.ptr;
    zT_1083 = zT_1082[cbi];
    cpath[cp2] = zT_1083;
    zT_1084 = 1;
    zT_1086 = cp2 + (unsigned int)((unsigned int)zT_1084);
    cp2 = zT_1086;
    goto z_bb_261;
    z_bb_260:
    zT_1091 = ".c";
    zT_1093 = 2;
    zT_1092.ptr = zT_1091;
    zT_1092.len = zT_1093;
    cext = zT_1092;
    zT_1095 = 0;
    cx = zT_1095;
    goto z_bb_265;
    z_bb_261:
    zT_1087 = 1;
    zT_1089 = cbi + (unsigned int)((unsigned int)zT_1087);
    cbi = zT_1089;
    goto z_bb_258;
    z_bb_262:
    zT_1079 = cp2 < (unsigned int)(510);
    goto z_bb_264;
    z_bb_263:
    zT_1079 = 0;
    goto z_bb_264;
    z_bb_264:
    if (zT_1079) goto z_bb_259; else goto z_bb_260;
    z_bb_265:
    zT_1097 = cext.len;
    if ((unsigned char)(cx < zT_1097)) goto z_bb_269; else goto z_bb_270;
    z_bb_266:
    zT_1102 = cext.ptr;
    zT_1103 = zT_1102[cx];
    cpath[cp2] = zT_1103;
    zT_1104 = 1;
    zT_1106 = cp2 + (unsigned int)((unsigned int)zT_1104);
    cp2 = zT_1106;
    goto z_bb_268;
    z_bb_267:
    zT_1115 = 0;
    zT_1116 = (unsigned char*)((unsigned char*)cpath) + zT_1115;
    zT_1117 = cp2 - zT_1115;
    zT_1118.ptr = zT_1116;
    zT_1118.len = zT_1117;
    zT_1111 = zT_1118;
    zT_1120 = zF_39FE21EF_fileOpen(zT_1111, (int)(0));
    cfd = zT_1120;
    if ((unsigned char)(cfd == zG_CC81CC5F_INVALID_FD)) goto z_bb_272; else goto z_bb_273;
    z_bb_268:
    zT_1107 = 1;
    zT_1109 = cx + (unsigned int)((unsigned int)zT_1107);
    cx = zT_1109;
    goto z_bb_265;
    z_bb_269:
    zT_1099 = cp2 < (unsigned int)(511);
    goto z_bb_271;
    z_bb_270:
    zT_1099 = 0;
    goto z_bb_271;
    z_bb_271:
    if (zT_1099) goto z_bb_266; else goto z_bb_267;
    z_bb_272:
    zT_1124 = "error: cannot open output file\n";
    zT_1126 = 31;
    zT_1125.ptr = zT_1124;
    zT_1125.len = zT_1126;
    emsg3 = zT_1125;
    zT_1127 = emsg3;
    zF_E4B2EF19_stderr_write(zT_1127);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_273;
    z_bb_273:
    cw = zT_1131;
    zT_1132 = cfd;
    zT_1133 = zF_E00097E1_bufferedWriterInitF(zT_1132);
    cw = zT_1133;
    emitter.writer = cw;
    zT_1134 = &emitter;
    zT_1135 = m.id;
    zT_1136 = base;
    zF_7B8B9B90_emitModuleFile(zT_1134, zT_1135, zT_1136);
    zT_1140 = &emitter;
    zT_1139 = &zT_1140->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1139);
    zT_1142 = cfd;
    zF_B30B1D79_fileClose(zT_1142);
    zT_1144 = "FINAL_FLUSH\n";
    zT_1146 = 12;
    zT_1145.ptr = zT_1144;
    zT_1145.len = zT_1146;
    ff2_m = zT_1145;
    zT_1147 = ff2_m;
    zF_48AC7B3A_markerWrite(zT_1147);
    goto z_bb_179;
}

/* parseArgs */
zT_C98AF326_CompilerCli zF_6143A521_parseArgs(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_C98AF326_CompilerCli zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_CAF40AAB_ColorMode zT_18;
    zT_A4FB690E_ErrorFormat zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    int zT_35 = 0;
    int zT_37;
    int zT_38;
    unsigned char* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_50;
    unsigned char* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned int zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    unsigned char* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    unsigned char* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    unsigned char* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_82;
    unsigned char* zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_85;
    unsigned int zT_86;
    unsigned char* zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    unsigned char* zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned int zT_102;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    unsigned char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    unsigned char* zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    unsigned int zT_142;
    unsigned char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    unsigned char* zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    unsigned char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    unsigned char* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    unsigned int zT_158;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    unsigned char* zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    unsigned char* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    unsigned char* zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    int zT_181;
    unsigned char* zT_182 = 0;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185 = {0};
    unsigned int zT_187;
    int zT_188;
    unsigned char zT_190;
    unsigned char* zT_191;
    int zT_192;
    unsigned char zT_193;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned char zT_198 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned char zT_202 = 0;
    unsigned char zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned char zT_206 = 0;
    int zT_207;
    int zT_209;
    unsigned char* zT_211;
    int zT_212;
    unsigned char* zT_213 = 0;
    unsigned int zT_214 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned char zT_216 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned char* zT_218;
    unsigned int zT_219;
    int zT_220;
    unsigned char* zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned char zT_226 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned char* zT_228;
    unsigned int zT_229;
    int zT_230;
    unsigned char* zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned char zT_237 = 0;
    unsigned char zT_238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_239;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_240;
    unsigned char zT_241 = 0;
    int zT_242;
    int zT_244;
    unsigned char* zT_246;
    int zT_247;
    unsigned char* zT_248 = 0;
    unsigned int zT_249 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned char zT_252 = 0;
    unsigned char zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char zT_256 = 0;
    int zT_257;
    int zT_259;
    unsigned char* zT_261;
    int zT_262;
    unsigned char* zT_263 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned char zT_268 = 0;
    unsigned char zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned char zT_272 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned char zT_276 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char zT_280 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned char zT_284 = 0;
    unsigned char zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned char zT_288 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    unsigned char zT_292 = 0;
    int zT_293;
    int zT_295;
    unsigned char* zT_297;
    int zT_298;
    unsigned char* zT_299 = 0;
    zT_CAF40AAB_ColorMode zT_300 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned char zT_303 = 0;
    int zT_304;
    int zT_306;
    unsigned char* zT_308;
    int zT_309;
    unsigned char* zT_310 = 0;
    zT_A4FB690E_ErrorFormat zT_311 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    unsigned char zT_314 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_317;
    unsigned char zT_318 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_321;
    unsigned char zT_322 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned char zT_326 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    unsigned char zT_330 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned char zT_334 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned char zT_339 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_342;
    unsigned char zT_343 = 0;
    unsigned char zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    unsigned char zT_347 = 0;
    int zT_348;
    int zT_350;
    unsigned char zT_352;
    unsigned int zT_353;
    int zT_354;
    unsigned char* zT_356;
    int zT_357;
    unsigned char* zT_358 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    unsigned int zT_363;
    int zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    unsigned char zT_369 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_372;
    unsigned char zT_373 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    unsigned char zT_377 = 0;
    int zT_378;
    int zT_380;
    unsigned char* zT_382;
    int zT_383;
    unsigned char* zT_384 = 0;
    unsigned char zT_385 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned char zT_388 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    unsigned char zT_392 = 0;
    unsigned char* zT_394;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_395 = {0};
    unsigned char* zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397 = {0};
    int zT_398;
    int zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u dot_str;
    zT_C98AF326_CompilerCli cli;
    int argc;
    int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dump_c89;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_mem;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_errors;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_output_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_quiet;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sanity_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warnings;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_color;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_error_format;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_track_memory;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_lifetime;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_leak;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_all;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_error;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_markers;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_include;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_lib_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_o;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_q;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_W;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osw;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fsafe;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ffast;
    unsigned char* arg_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u arg;
    zT_1 = "";
    zT_3 = 0;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    empty_str = zT_2;
    zT_5 = ".";
    zT_7 = 1;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    dot_str = zT_6;
    zT_9.input_file = empty_str;
    zT_9.output_dir = dot_str;
    zT_10 = 0;
    zT_9.output_dir_set = zT_10;
    zT_11 = 0;
    zT_9.dump_types = zT_11;
    zT_12 = 0;
    zT_9.dump_lir = zT_12;
    zT_13 = 0;
    zT_9.dump_c89 = zT_13;
    zT_15 = (unsigned int)zG_18AE3D2F_DEFAULT_MAX_MEM_KB;
    zT_9.max_mem = zT_15;
    zT_16 = 0;
    zT_9.spill_level = zT_16;
    zT_17 = 256;
    zT_9.max_errors = zT_17;
    zT_18 = zT_CAF40AAB_ColorMode_auto;
    zT_9.color = zT_18;
    zT_19 = zT_A4FB690E_ErrorFormat_human;
    zT_9.error_format = zT_19;
    zT_20 = 0;
    zT_9.warnings_as_errors = zT_20;
    zT_21 = 0;
    zT_9.quiet = zT_21;
    zT_22 = 0;
    zT_9.test_mode = zT_22;
    zT_23 = 0;
    zT_9.sanity_test_mode = zT_23;
    zT_24 = 0;
    zT_9.track_memory = zT_24;
    zT_25 = 0;
    zT_9.no_null_check = zT_25;
    zT_26 = 0;
    zT_9.no_lifetime_check = zT_26;
    zT_27 = 0;
    zT_9.no_leak_check = zT_27;
    zT_28 = 1;
    zT_9.safe_checks = zT_28;
    zT_29 = 0;
    zT_9.warn_all = zT_29;
    zT_30 = 0;
    zT_9.warn_error = zT_30;
    zT_31 = 0;
    zT_9.show_markers = zT_31;
    zT_32 = 0;
    zT_9.include_count = zT_32;
    zT_33 = 0;
    zT_9.target_is_windows = zT_33;
    cli = zT_9;
    zT_35 = zF_EEF840BE_argCount();
    argc = zT_35;
    zT_37 = 1;
    zT_38 = (int)zT_37;
    i = zT_38;
    zT_48 = "--dump-c89";
    zT_50 = 10;
    zT_49.ptr = zT_48;
    zT_49.len = zT_50;
    s_dump_c89 = zT_49;
    zT_52 = "--max-mem";
    zT_54 = 9;
    zT_53.ptr = zT_52;
    zT_53.len = zT_54;
    s_max_mem = zT_53;
    zT_56 = "--max-errors";
    zT_58 = 12;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    s_max_errors = zT_57;
    zT_60 = "--output-dir";
    zT_62 = 12;
    zT_61.ptr = zT_60;
    zT_61.len = zT_62;
    s_output_dir = zT_61;
    zT_64 = "--quiet";
    zT_66 = 7;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    s_quiet = zT_65;
    zT_68 = "--test";
    zT_70 = 6;
    zT_69.ptr = zT_68;
    zT_69.len = zT_70;
    s_test = zT_69;
    zT_72 = "--sanity-test";
    zT_74 = 13;
    zT_73.ptr = zT_72;
    zT_73.len = zT_74;
    s_sanity_test = zT_73;
    zT_76 = "--warnings-as-errors";
    zT_78 = 20;
    zT_77.ptr = zT_76;
    zT_77.len = zT_78;
    s_warnings = zT_77;
    zT_80 = "--color";
    zT_82 = 7;
    zT_81.ptr = zT_80;
    zT_81.len = zT_82;
    s_color = zT_81;
    zT_84 = "--error-format";
    zT_86 = 14;
    zT_85.ptr = zT_84;
    zT_85.len = zT_86;
    s_error_format = zT_85;
    zT_88 = "--track-memory";
    zT_90 = 14;
    zT_89.ptr = zT_88;
    zT_89.len = zT_90;
    s_track_memory = zT_89;
    zT_92 = "--no-null-check";
    zT_94 = 15;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    s_no_null = zT_93;
    zT_96 = "--no-lifetime-check";
    zT_98 = 19;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    s_no_lifetime = zT_97;
    zT_100 = "--no-leak-check";
    zT_102 = 15;
    zT_101.ptr = zT_100;
    zT_101.len = zT_102;
    s_no_leak = zT_101;
    zT_104 = "--warn-all";
    zT_106 = 10;
    zT_105.ptr = zT_104;
    zT_105.len = zT_106;
    s_warn_all = zT_105;
    zT_108 = "--warn-error";
    zT_110 = 12;
    zT_109.ptr = zT_108;
    zT_109.len = zT_110;
    s_warn_error = zT_109;
    zT_112 = "--markers";
    zT_114 = 9;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    s_markers = zT_113;
    zT_116 = "-I";
    zT_118 = 2;
    zT_117.ptr = zT_116;
    zT_117.len = zT_118;
    s_include = zT_117;
    zT_120 = "--lib-dir";
    zT_122 = 9;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    s_lib_dir = zT_121;
    zT_140 = "-m";
    zT_142 = 2;
    zT_141.ptr = zT_140;
    zT_141.len = zT_142;
    s_m = zT_141;
    zT_144 = "-e";
    zT_146 = 2;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    s_e = zT_145;
    zT_148 = "-o";
    zT_150 = 2;
    zT_149.ptr = zT_148;
    zT_149.len = zT_150;
    s_o = zT_149;
    zT_152 = "-q";
    zT_154 = 2;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    s_q = zT_153;
    zT_156 = "-W";
    zT_158 = 2;
    zT_157.ptr = zT_156;
    zT_157.len = zT_158;
    s_W = zT_157;
    zT_160 = "-osl";
    zT_162 = 4;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    s_osl = zT_161;
    zT_164 = "-osw";
    zT_166 = 4;
    zT_165.ptr = zT_164;
    zT_165.len = zT_166;
    s_osw = zT_165;
    zT_168 = "--target";
    zT_170 = 8;
    zT_169.ptr = zT_168;
    zT_169.len = zT_170;
    s_target = zT_169;
    zT_172 = "-fsafe";
    zT_174 = 6;
    zT_173.ptr = zT_172;
    zT_173.len = zT_174;
    s_fsafe = zT_173;
    zT_176 = "-ffast";
    zT_178 = 6;
    zT_177.ptr = zT_176;
    zT_177.len = zT_178;
    s_ffast = zT_177;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < argc)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_181 = i;
    zT_182 = zF_70B5BFF1_argGet(zT_181);
    arg_ptr = zT_182;
    zT_184 = arg_ptr;
    zT_185 = zF_22D0470E_cstrToSlice(zT_184);
    arg = zT_185;
    zT_187 = arg.len;
    zT_188 = 0;
    if ((unsigned char)(zT_187 > (unsigned int)zT_188)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cli;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_191 = arg.ptr;
    zT_192 = 0;
    zT_193 = zT_191[zT_192];
    zT_190 = zT_193 == (unsigned char)(45);
    goto z_bb_7;
    z_bb_6:
    zT_190 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_190) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_196 = arg;
    zT_197 = s_dump_c89;
    zT_198 = zF_5FE51158_matchFlag(zT_196, zT_197);
    if (zT_198) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_398 = 1;
    zT_400 = i + (int)((int)zT_398);
    i = zT_400;
    goto z_bb_4;
    z_bb_10:
    zT_396 = arg_ptr;
    zT_397 = zF_22D0470E_cstrToSlice(zT_396);
    cli.input_file = zT_397;
    goto z_bb_9;
    z_bb_11:
    cli.dump_c89 = (unsigned char)(1);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_200 = arg;
    zT_201 = s_max_mem;
    zT_202 = zF_5FE51158_matchFlag(zT_200, zT_201);
    if (zT_202) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_204 = arg;
    zT_205 = s_m;
    zT_206 = zF_5FE51158_matchFlag(zT_204, zT_205);
    zT_203 = zT_206;
    goto z_bb_16;
    z_bb_15:
    zT_203 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_203) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_207 = 1;
    zT_209 = i + (int)((int)zT_207);
    i = zT_209;
    if ((unsigned char)(i < argc)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    goto z_bb_12;
    z_bb_19:
    zT_215 = arg;
    zT_216 = zF_FBF91F7E_matchMMFlag(zT_215);
    if (zT_216) goto z_bb_22; else goto z_bb_24;
    z_bb_20:
    zT_212 = i;
    zT_213 = zF_70B5BFF1_argGet(zT_212);
    zT_211 = zT_213;
    zT_214 = zF_6CF11065_parseSize(zT_211);
    cli.max_mem = zT_214;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_218 = arg.ptr;
    zT_219 = arg.len;
    zT_220 = 3;
    zT_221 = zT_218 + zT_220;
    zT_222 = zT_219 - zT_220;
    zT_223.ptr = zT_221;
    zT_223.len = zT_222;
    zT_217 = zT_223;
    zT_224 = zF_B9231BB9_parseMMBytes(zT_217);
    cli.max_mem = zT_224;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_18;
    z_bb_24:
    zT_225 = arg;
    zT_226 = zF_C4E3C361_matchSFlag(zT_225);
    if (zT_226) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    zT_228 = arg.ptr;
    zT_229 = arg.len;
    zT_230 = 2;
    zT_231 = zT_228 + zT_230;
    zT_232 = zT_229 - zT_230;
    zT_233.ptr = zT_231;
    zT_233.len = zT_232;
    zT_227 = zT_233;
    zT_234 = zF_153C3795_parseSLevel(zT_227);
    cli.spill_level = zT_234;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_235 = arg;
    zT_236 = s_max_errors;
    zT_237 = zF_5FE51158_matchFlag(zT_235, zT_236);
    if (zT_237) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_239 = arg;
    zT_240 = s_e;
    zT_241 = zF_5FE51158_matchFlag(zT_239, zT_240);
    zT_238 = zT_241;
    goto z_bb_30;
    z_bb_29:
    zT_238 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_238) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_242 = 1;
    zT_244 = i + (int)((int)zT_242);
    i = zT_244;
    if ((unsigned char)(i < argc)) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    goto z_bb_26;
    z_bb_33:
    zT_250 = arg;
    zT_251 = s_output_dir;
    zT_252 = zF_5FE51158_matchFlag(zT_250, zT_251);
    if (zT_252) goto z_bb_37; else goto z_bb_36;
    z_bb_34:
    zT_247 = i;
    zT_248 = zF_70B5BFF1_argGet(zT_247);
    zT_246 = zT_248;
    zT_249 = zF_16BBA09E_parseU32(zT_246);
    cli.max_errors = zT_249;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_254 = arg;
    zT_255 = s_o;
    zT_256 = zF_5FE51158_matchFlag(zT_254, zT_255);
    zT_253 = zT_256;
    goto z_bb_38;
    z_bb_37:
    zT_253 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_253) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_257 = 1;
    zT_259 = i + (int)((int)zT_257);
    i = zT_259;
    if ((unsigned char)(i < argc)) goto z_bb_42; else goto z_bb_43;
    z_bb_40:
    goto z_bb_32;
    z_bb_41:
    zT_266 = arg;
    zT_267 = s_quiet;
    zT_268 = zF_5FE51158_matchFlag(zT_266, zT_267);
    if (zT_268) goto z_bb_45; else goto z_bb_44;
    z_bb_42:
    zT_262 = i;
    zT_263 = zF_70B5BFF1_argGet(zT_262);
    zT_261 = zT_263;
    zT_264 = zF_22D0470E_cstrToSlice(zT_261);
    cli.output_dir = zT_264;
    cli.output_dir_set = (unsigned char)(1);
    goto z_bb_43;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_270 = arg;
    zT_271 = s_q;
    zT_272 = zF_5FE51158_matchFlag(zT_270, zT_271);
    zT_269 = zT_272;
    goto z_bb_46;
    z_bb_45:
    zT_269 = 1;
    goto z_bb_46;
    z_bb_46:
    if (zT_269) goto z_bb_47; else goto z_bb_49;
    z_bb_47:
    cli.quiet = (unsigned char)(1);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_40;
    z_bb_49:
    zT_274 = arg;
    zT_275 = s_test;
    zT_276 = zF_5FE51158_matchFlag(zT_274, zT_275);
    if (zT_276) goto z_bb_50; else goto z_bb_52;
    z_bb_50:
    cli.test_mode = (unsigned char)(1);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
    z_bb_52:
    zT_278 = arg;
    zT_279 = s_sanity_test;
    zT_280 = zF_5FE51158_matchFlag(zT_278, zT_279);
    if (zT_280) goto z_bb_53; else goto z_bb_55;
    z_bb_53:
    cli.sanity_test_mode = (unsigned char)(1);
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_282 = arg;
    zT_283 = s_warnings;
    zT_284 = zF_5FE51158_matchFlag(zT_282, zT_283);
    if (zT_284) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_286 = arg;
    zT_287 = s_W;
    zT_288 = zF_5FE51158_matchFlag(zT_286, zT_287);
    zT_285 = zT_288;
    goto z_bb_58;
    z_bb_57:
    zT_285 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_285) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    cli.warnings_as_errors = (unsigned char)(1);
    goto z_bb_60;
    z_bb_60:
    goto z_bb_54;
    z_bb_61:
    zT_290 = arg;
    zT_291 = s_color;
    zT_292 = zF_5FE51158_matchFlag(zT_290, zT_291);
    if (zT_292) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    zT_293 = 1;
    zT_295 = i + (int)((int)zT_293);
    i = zT_295;
    if ((unsigned char)(i < argc)) goto z_bb_65; else goto z_bb_66;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_301 = arg;
    zT_302 = s_error_format;
    zT_303 = zF_5FE51158_matchFlag(zT_301, zT_302);
    if (zT_303) goto z_bb_67; else goto z_bb_69;
    z_bb_65:
    zT_298 = i;
    zT_299 = zF_70B5BFF1_argGet(zT_298);
    zT_297 = zT_299;
    zT_300 = zF_05AD3AFC_parseColorMode(zT_297);
    cli.color = zT_300;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_304 = 1;
    zT_306 = i + (int)((int)zT_304);
    i = zT_306;
    if ((unsigned char)(i < argc)) goto z_bb_70; else goto z_bb_71;
    z_bb_68:
    goto z_bb_63;
    z_bb_69:
    zT_312 = arg;
    zT_313 = s_track_memory;
    zT_314 = zF_5FE51158_matchFlag(zT_312, zT_313);
    if (zT_314) goto z_bb_72; else goto z_bb_74;
    z_bb_70:
    zT_309 = i;
    zT_310 = zF_70B5BFF1_argGet(zT_309);
    zT_308 = zT_310;
    zT_311 = zF_A4602959_parseErrorFormat(zT_308);
    cli.error_format = zT_311;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_68;
    z_bb_72:
    cli.track_memory = (unsigned char)(1);
    goto z_bb_73;
    z_bb_73:
    goto z_bb_68;
    z_bb_74:
    zT_316 = arg;
    zT_317 = s_no_null;
    zT_318 = zF_5FE51158_matchFlag(zT_316, zT_317);
    if (zT_318) goto z_bb_75; else goto z_bb_77;
    z_bb_75:
    cli.no_null_check = (unsigned char)(1);
    goto z_bb_76;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_320 = arg;
    zT_321 = s_no_lifetime;
    zT_322 = zF_5FE51158_matchFlag(zT_320, zT_321);
    if (zT_322) goto z_bb_78; else goto z_bb_80;
    z_bb_78:
    cli.no_lifetime_check = (unsigned char)(1);
    goto z_bb_79;
    z_bb_79:
    goto z_bb_76;
    z_bb_80:
    zT_324 = arg;
    zT_325 = s_no_leak;
    zT_326 = zF_5FE51158_matchFlag(zT_324, zT_325);
    if (zT_326) goto z_bb_81; else goto z_bb_83;
    z_bb_81:
    cli.no_leak_check = (unsigned char)(1);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    zT_328 = arg;
    zT_329 = s_warn_all;
    zT_330 = zF_5FE51158_matchFlag(zT_328, zT_329);
    if (zT_330) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    cli.warn_all = (unsigned char)(1);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_332 = arg;
    zT_333 = s_warn_error;
    zT_334 = zF_5FE51158_matchFlag(zT_332, zT_333);
    if (zT_334) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    cli.warnings_as_errors = (unsigned char)(1);
    cli.warn_error = (unsigned char)(1);
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_337 = arg;
    zT_338 = s_markers;
    zT_339 = zF_5FE51158_matchFlag(zT_337, zT_338);
    if (zT_339) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    cli.show_markers = (unsigned char)(1);
    goto z_bb_91;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_341 = arg;
    zT_342 = s_include;
    zT_343 = zF_5FE51158_matchFlag(zT_341, zT_342);
    if (zT_343) goto z_bb_94; else goto z_bb_93;
    z_bb_93:
    zT_345 = arg;
    zT_346 = s_lib_dir;
    zT_347 = zF_5FE51158_matchFlag(zT_345, zT_346);
    zT_344 = zT_347;
    goto z_bb_95;
    z_bb_94:
    zT_344 = 1;
    goto z_bb_95;
    z_bb_95:
    if (zT_344) goto z_bb_96; else goto z_bb_98;
    z_bb_96:
    zT_348 = 1;
    zT_350 = i + (int)((int)zT_348);
    i = zT_350;
    if ((unsigned char)(i < argc)) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    goto z_bb_91;
    z_bb_98:
    zT_367 = arg;
    zT_368 = s_osl;
    zT_369 = zF_5FE51158_matchFlag(zT_367, zT_368);
    if (zT_369) goto z_bb_104; else goto z_bb_106;
    z_bb_99:
    zT_353 = cli.include_count;
    zT_354 = 16;
    zT_352 = zT_353 < (unsigned int)zT_354;
    goto z_bb_101;
    z_bb_100:
    zT_352 = 0;
    goto z_bb_101;
    z_bb_101:
    if (zT_352) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_357 = i;
    zT_358 = zF_70B5BFF1_argGet(zT_357);
    zT_356 = zT_358;
    zT_359 = zF_22D0470E_cstrToSlice(zT_356);
    zT_360 = cli.include_dirs;
    zT_361 = cli.include_count;
    zT_362 = (unsigned int)zT_361;
    zT_360[zT_362] = zT_359;
    zT_363 = cli.include_count;
    zT_364 = 1;
    cli.include_count = (unsigned int)(zT_363 + (unsigned int)((unsigned int)zT_364));
    goto z_bb_103;
    z_bb_103:
    goto z_bb_97;
    z_bb_104:
    cli.target_is_windows = (unsigned char)(0);
    goto z_bb_105;
    z_bb_105:
    goto z_bb_97;
    z_bb_106:
    zT_371 = arg;
    zT_372 = s_osw;
    zT_373 = zF_5FE51158_matchFlag(zT_371, zT_372);
    if (zT_373) goto z_bb_107; else goto z_bb_109;
    z_bb_107:
    cli.target_is_windows = (unsigned char)(1);
    goto z_bb_108;
    z_bb_108:
    goto z_bb_105;
    z_bb_109:
    zT_375 = arg;
    zT_376 = s_target;
    zT_377 = zF_5FE51158_matchFlag(zT_375, zT_376);
    if (zT_377) goto z_bb_110; else goto z_bb_112;
    z_bb_110:
    zT_378 = 1;
    zT_380 = i + (int)((int)zT_378);
    i = zT_380;
    if ((unsigned char)(i < argc)) goto z_bb_113; else goto z_bb_114;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_386 = arg;
    zT_387 = s_ffast;
    zT_388 = zF_5FE51158_matchFlag(zT_386, zT_387);
    if (zT_388) goto z_bb_115; else goto z_bb_117;
    z_bb_113:
    zT_383 = i;
    zT_384 = zF_70B5BFF1_argGet(zT_383);
    zT_382 = zT_384;
    zT_385 = zF_06CC17EA_parseTargetIsWindow(zT_382);
    cli.target_is_windows = zT_385;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    cli.safe_checks = (unsigned char)(0);
    goto z_bb_116;
    z_bb_116:
    goto z_bb_111;
    z_bb_117:
    zT_390 = arg;
    zT_391 = s_fsafe;
    zT_392 = zF_5FE51158_matchFlag(zT_390, zT_391);
    if (zT_392) goto z_bb_118; else goto z_bb_120;
    z_bb_118:
    cli.safe_checks = (unsigned char)(1);
    goto z_bb_119;
    z_bb_119:
    goto z_bb_116;
    z_bb_120:
    zT_394 = arg_ptr;
    zT_395 = zF_22D0470E_cstrToSlice(zT_394);
    cli.input_file = zT_395;
    goto z_bb_119;
}

/* matchFlag */
unsigned char zF_5FE51158_matchFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg, zT_8F083A69_Slice_zT_0B42B2F8_u flag) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    int zT_20;
    unsigned int zT_22;
    unsigned int j;
    zT_3 = arg.len;
    zT_5 = flag.len;
    if ((unsigned char)(zT_3 != zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    j = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = arg.len;
    if ((unsigned char)(j < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = arg.ptr;
    zT_15 = zT_14[j];
    zT_16 = flag.ptr;
    zT_17 = zT_16[j];
    if ((unsigned char)(zT_15 != zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_20 = 1;
    zT_22 = j + (unsigned int)((unsigned int)zT_20);
    j = zT_22;
    goto z_bb_6;
}

/* matchMMFlag */
unsigned char zF_FBF91F7E_matchMMFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mm;
    unsigned int j;
    zT_2 = "-mm";
    zT_4 = 3;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_mm = zT_3;
    zT_6 = arg.len;
    zT_8 = s_mm.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_mm.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_mm.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* cstrToSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D0470E_cstrToSlice(unsigned char* ptr) {
    int zT_2;
    unsigned int zT_3;
    unsigned char zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int len;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    len = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ptr[len];
    zT_5 = 0;
    if ((unsigned char)(zT_4 != zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    zT_9 = len + (unsigned int)((unsigned int)zT_7);
    len = zT_9;
    goto z_bb_4;
    z_bb_3:
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    return zT_13;
    z_bb_4:
    goto z_bb_1;
}

/* parseSize */
unsigned int zF_6CF11065_parseSize(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    unsigned char zT_29;
    int zT_32;
    unsigned int zT_33;
    unsigned char zT_36;
    int zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned char zT_45;
    int zT_48;
    int zT_50;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_54 = 1;
    zT_56 = i + (unsigned int)((unsigned int)zT_54);
    i = zT_56;
    goto z_bb_4;
    z_bb_10:
    if ((unsigned char)(c == (unsigned char)(107))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_29 = c == (unsigned char)(75);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_32 = 1024;
    zT_33 = val * zT_32;
    val = zT_33;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    if ((unsigned char)(c == (unsigned char)(109))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_36 = c == (unsigned char)(77);
    goto z_bb_19;
    z_bb_18:
    zT_36 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_36) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_39 = 1024;
    zT_41 = 1024;
    zT_42 = (unsigned int)(val * zT_39) * zT_41;
    val = zT_42;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    if ((unsigned char)(c == (unsigned char)(103))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_45 = c == (unsigned char)(71);
    goto z_bb_25;
    z_bb_24:
    zT_45 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_45) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_48 = 1024;
    zT_50 = 1024;
    zT_52 = 1024;
    zT_53 = (unsigned int)((unsigned int)(val * zT_48) * zT_50) * zT_52;
    val = zT_53;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_21;
}

/* parseU32 */
unsigned int zF_16BBA09E_parseU32(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_4;
}

/* parseMMBytes */
unsigned int zF_B9231BB9_parseMMBytes(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned char* zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    int zT_26;
    unsigned int zT_28;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_39;
    int zT_40;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int max_mb;
    unsigned int i;
    unsigned int n;
    unsigned int mb;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_5 = (unsigned int)(unsigned int)(256);
    max_mb = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    n = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    mb = zT_14;
    goto z_bb_1;
    z_bb_1:
    zT_16 = rest.len;
    if ((unsigned char)(i < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_19 = rest.ptr;
    zT_20 = zT_19[i];
    c = zT_20;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_40 = 0;
    if ((unsigned char)(n == (unsigned int)zT_40)) goto z_bb_15; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_23 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_23 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_26 = 1;
    zT_28 = n + (unsigned int)((unsigned int)zT_26);
    n = zT_28;
    if ((unsigned char)(mb < max_mb)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = (unsigned int)(mb * (unsigned int)(10)) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    mb = zT_35;
    if ((unsigned char)(mb > max_mb)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_4;
    z_bb_12:
    mb = max_mb;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    zT_44 = rest.len;
    zT_42 = i != zT_44;
    goto z_bb_16;
    z_bb_15:
    zT_42 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_47 = "error: -mm<N> requires a decimal MB size (e.g. -mm64)\n";
    zT_49 = 54;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    em = zT_48;
    zT_50 = em;
    zF_E4B2EF19_stderr_write(zT_50);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_18:
    return (unsigned int)(mb * (unsigned int)(1024));
}

/* matchSFlag */
unsigned char zF_C4E3C361_matchSFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_s;
    unsigned int j;
    zT_2 = "-s";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_s = zT_3;
    zT_6 = arg.len;
    zT_8 = s_s.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_s.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_s.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* parseSLevel */
unsigned int zF_153C3795_parseSLevel(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    int zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_32;
    unsigned int zT_36;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_43;
    int zT_44;
    unsigned char zT_46;
    unsigned int zT_48;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_58;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int i;
    unsigned int n;
    unsigned int level;
    unsigned int over;
    unsigned char c;
    unsigned int d;
    unsigned int nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    n = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    level = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    over = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_14 = rest.len;
    if ((unsigned char)(i < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = rest.ptr;
    zT_18 = zT_17[i];
    c = zT_18;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_44 = 0;
    if ((unsigned char)(n == (unsigned int)zT_44)) goto z_bb_16; else goto z_bb_15;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_21 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_21 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_21) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_24 = 1;
    zT_26 = n + (unsigned int)((unsigned int)zT_24);
    n = zT_26;
    zT_27 = 0;
    if ((unsigned char)(over == (unsigned int)zT_27)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_32;
    zT_36 = (unsigned int)(level * (unsigned int)(10)) + d;
    nl = zT_36;
    if ((unsigned char)(nl > (unsigned int)(6))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_4;
    z_bb_12:
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    over = zT_40;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    level = nl;
    goto z_bb_13;
    z_bb_15:
    zT_48 = rest.len;
    zT_46 = i != zT_48;
    goto z_bb_17;
    z_bb_16:
    zT_46 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_46) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_51 = "error: -s<N> requires a decimal level 0..6 (e.g. -s0 all on disk, -s6 all in RAM)\n";
    zT_53 = 82;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    em = zT_52;
    zT_54 = em;
    zF_E4B2EF19_stderr_write(zT_54);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_19:
    zT_58 = 0;
    if ((unsigned char)(over != (unsigned int)zT_58)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = "error: -s<N> spill level out of range (0..6: 0 = all on disk, 6 = all in RAM)\n";
    zT_63 = 78;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    em = zT_62;
    zT_64 = em;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_21:
    return level;
}

/* parseColorMode */
zT_CAF40AAB_ColorMode zF_05AD3AFC_parseColorMode(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_always;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_never;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "always";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_always = zT_6;
    zT_9 = "never";
    zT_11 = 5;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_never = zT_10;
    zT_12 = s;
    zT_13 = s_always;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_always);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_never;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_never);
    z_bb_4:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_auto);
}

/* parseErrorFormat */
zT_A4FB690E_ErrorFormat zF_A4602959_parseErrorFormat(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_json;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sarif;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "json";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_json = zT_6;
    zT_9 = "sarif";
    zT_11 = 5;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_sarif = zT_10;
    zT_12 = s;
    zT_13 = s_json;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_json);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_sarif;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_sarif);
    z_bb_4:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_human);
}

/* parseTargetIsWindows */
unsigned char zF_06CC17EA_parseTargetIsWindow(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_linux;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_windows;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "linux";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_linux = zT_6;
    zT_9 = "windows";
    zT_11 = 7;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_windows = zT_10;
    zT_12 = s;
    zT_13 = s_windows;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_linux;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_21 = "error: --target must be 'linux' or 'windows'\n";
    zT_23 = 45;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    err_msg = zT_22;
    zT_24 = err_msg;
    zF_E4B2EF19_stderr_write(zT_24);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned char)(0);
}

/* writeU32 */
void zF_266B1B8E_writeU32(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_11;
    int zT_15;
    int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    unsigned char zT_23;
    int zT_24;
    int zT_26;
    unsigned int zT_28;
    int zT_29;
    int zT_30;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 16;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    v = val;
    zT_7 = 0;
    if ((unsigned char)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 48;
    zT_10 = (unsigned char)zT_9;
    zT_11 = 15;
    buf[zT_11] = zT_10;
    zT_15 = 16;
    zT_16 = 15;
    zT_17 = (unsigned char*)((unsigned char*)buf) + zT_16;
    zT_18 = zT_15 - zT_16;
    zT_19.ptr = zT_17;
    zT_19.len = zT_18;
    s = zT_19;
    zT_20 = s;
    zF_B5478454_measureMarkerWrite(zT_20);
    return;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_21 = 0;
    if ((unsigned char)(v > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_26 = 1;
    zT_28 = i - (unsigned int)((unsigned int)zT_26);
    i = zT_28;
    zT_29 = 48;
    zT_30 = 10;
    zT_35 = (unsigned char)(unsigned int)((unsigned int)(unsigned int)(zT_29 + (unsigned int)((unsigned int)(unsigned int)(v % zT_30))));
    buf[i] = zT_35;
    zT_36 = 10;
    zT_37 = v / zT_36;
    v = zT_37;
    goto z_bb_6;
    z_bb_5:
    zT_41 = 16;
    zT_42 = (unsigned char*)((unsigned char*)buf) + i;
    zT_43 = zT_41 - i;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    s = zT_44;
    zT_45 = s;
    zF_B5478454_measureMarkerWrite(zT_45);
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_24 = 0;
    zT_23 = i > (unsigned int)zT_24;
    goto z_bb_9;
    z_bb_8:
    zT_23 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_23) goto z_bb_4; else goto z_bb_5;
}

/* printUsage */
void zF_9D45DFBF_printUsage(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help3;
    zT_8F083A69_Slice_zT_0B42B2F8_u os_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u tgt_help;
    zT_1 = "zig1 - Z98 self-hosted compiler - usage: zig1 [options] <input.zig>\n";
    zT_3 = 68;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_6 = "  -mm<N>    hard pool budget in MB (default 64; pool.peak over budget -> ICE rc=3)\n";
    zT_8 = 83;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    mm_help = zT_7;
    zT_9 = mm_help;
    zF_E4B2EF19_stderr_write(zT_9);
    zT_11 = "  -s<N>     spill level 0..6 (default 0 = all spills on disk; -s1..-s6 deactivate the\n";
    zT_13 = 86;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    s_help = zT_12;
    zT_14 = s_help;
    zF_E4B2EF19_stderr_write(zT_14);
    zT_16 = "            first N spills to RAM in order AST,LIR,HASH,RES,SIDE,EXTRA: higher -s = more RAM,\n";
    zT_18 = 94;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    s_help2 = zT_17;
    zT_19 = s_help2;
    zF_E4B2EF19_stderr_write(zT_19);
    zT_21 = "            less disk I/O (pool= rises; -s6 = all in RAM -> pair with -mm128)\n";
    zT_23 = 78;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    s_help3 = zT_22;
    zT_24 = s_help3;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_26 = "  -osl       compile target = linux (default); -osw = windows\n";
    zT_28 = 62;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    os_help = zT_27;
    zT_29 = os_help;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_31 = "  --target <linux|windows>  long-form target alias for -osl/-osw\n";
    zT_33 = 65;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    tgt_help = zT_32;
    zT_34 = tgt_help;
    zF_E4B2EF19_stderr_write(zT_34);
    return;
}

/* __module_init */
void zF_780653D2___module_init(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_69057089_CompilerAlloc zT_1 = {0};
    zT_D3EB6303_StringInterner zT_2 = {0};
    zT_227EDE07_SourceManager zT_3 = {0};
    zT_F85C5DED_DiagnosticCollector zT_4 = {0};
    zT_CEC2984A_NameMangler zT_5 = {0};
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7 = 0;
    zT_072B53A6_ModuleRegistry zT_8 = {0};
    zT_338B7C76_TypeRegistry zT_9 = {0};
    zT_6B356268_SemanticContext zT_10 = {0};
    zT_02EB57B2_LirLowerer zT_11 = {0};
    zT_CA01C129_LirSlotArrayList zT_12 = {0};
    zT_8EED1867_ResolvedTypeTable zT_13 = {0};
    zT_66E7D2EF_CoercionTable zT_14 = {0};
    zT_3D7259E2_SymbolRegistry zT_15 = {0};
    zT_8143F551_AstKind zT_16 = 0;
    zT_6B0A7D14_AstStore zT_17 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_69057089_CompilerAlloc = zT_1;
    zG_D3EB6303_StringInterner = zT_2;
    zG_227EDE07_SourceManager = zT_3;
    zG_F85C5DED_DiagnosticCollector = zT_4;
    zG_CEC2984A_NameMangler = zT_5;
    zG_3A355BD2_Token = zT_6;
    zG_EAC3E484_TokenKind = zT_7;
    zG_072B53A6_ModuleRegistry = zT_8;
    zG_338B7C76_TypeRegistry = zT_9;
    zG_6B356268_SemanticContext = zT_10;
    zG_02EB57B2_LirLowerer = zT_11;
    zG_CA01C129_LirSlotArrayList = zT_12;
    zG_8EED1867_ResolvedTypeTable = zT_13;
    zG_66E7D2EF_CoercionTable = zT_14;
    zG_3D7259E2_SymbolRegistry = zT_15;
    zG_8143F551_AstKind = zT_16;
    zG_6B0A7D14_AstStore = zT_17;
    return;
}

/* EOF */
