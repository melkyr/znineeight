#include "main_9472B9CB.h"
/* main */
void zF_EA90E208_main(int argc, unsigned char** argv) {
    int zT_2;
    unsigned char** zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_C98AF326_CompilerCli zT_10 = {0};
    unsigned char zT_11;
    unsigned char zT_14;
    unsigned char zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned char* zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned char zT_38;
    zT_69057089_CompilerAlloc zT_40 = {0};
    zT_3E40CD83_Sand* zT_42;
    zT_69057089_CompilerAlloc* zT_44;
    int zT_46;
    zT_D3EB6303_StringInterner zT_48 = {0};
    zT_3E40CD83_Sand* zT_50;
    zT_69057089_CompilerAlloc* zT_51;
    zT_227EDE07_SourceManager zT_53 = {0};
    zT_3E40CD83_Sand* zT_55;
    zT_227EDE07_SourceManager* zT_56;
    zT_D3EB6303_StringInterner* zT_57;
    zT_69057089_CompilerAlloc* zT_58;
    zT_3E40CD83_Sand* zT_63;
    zT_69057089_CompilerAlloc* zT_64;
    unsigned char zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_77;
    int zT_78;
    unsigned char zT_80;
    unsigned char zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char zT_84 = 0;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    unsigned char zT_102 = 0;
    unsigned char* zT_104;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    unsigned int zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    zT_69057089_CompilerAlloc zT_118 = {0};
    unsigned int zT_119;
    unsigned int zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_3E40CD83_Sand* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    zT_69057089_CompilerAlloc* zT_126;
    zT_13E1F35B_Opt_482 zT_128 = {0};
    unsigned char zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_142;
    unsigned int zT_145;
    unsigned int zT_149;
    unsigned int zT_152;
    unsigned int zT_155;
    unsigned int zT_158;
    unsigned int zT_161;
    unsigned int zT_164;
    unsigned int zT_167;
    unsigned int zT_170;
    unsigned int zT_173;
    unsigned int zT_176;
    unsigned int zT_179;
    zT_3E40CD83_Sand* zT_181;
    unsigned int zT_182;
    zT_69057089_CompilerAlloc* zT_183;
    zT_D3EB6303_StringInterner zT_185 = {0};
    zT_3E40CD83_Sand* zT_187;
    zT_69057089_CompilerAlloc* zT_188;
    zT_227EDE07_SourceManager zT_190 = {0};
    zT_3E40CD83_Sand* zT_192;
    zT_227EDE07_SourceManager* zT_193;
    zT_D3EB6303_StringInterner* zT_194;
    zT_69057089_CompilerAlloc* zT_195;
    zT_F85C5DED_DiagnosticCollector zT_199 = {0};
    unsigned int zT_200;
    zT_3E40CD83_Sand* zT_202;
    zT_69057089_CompilerAlloc* zT_203;
    zT_3E40CD83_Sand* zT_206;
    zT_D3EB6303_StringInterner* zT_207;
    zT_F85C5DED_DiagnosticCollector* zT_208;
    zT_69057089_CompilerAlloc* zT_209;
    zT_072B53A6_ModuleRegistry zT_213 = {0};
    zT_072B53A6_ModuleRegistry* zT_214;
    zT_227EDE07_SourceManager* zT_215;
    zT_072B53A6_ModuleRegistry* zT_218;
    unsigned char zT_219;
    zT_7D82FE60_GrowableSand zT_223 = {0};
    unsigned char* zT_225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    unsigned int zT_227;
    zT_7D82FE60_GrowableSand* zT_228;
    zT_3E40CD83_Sand* zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    zT_3E40CD83_Sand* zT_233 = 0;
    int zT_234;
    zT_3E40CD83_Sand* zT_237;
    zT_D3EB6303_StringInterner* zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    zT_7D82FE60_GrowableSand* zT_241;
    zT_338B7C76_TypeRegistry zT_244 = {0};
    zT_338B7C76_TypeRegistry* zT_245;
    zT_3E40CD83_Sand* zT_248;
    zT_69057089_CompilerAlloc* zT_249;
    zT_6B0A7D14_AstStore zT_251 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_253;
    unsigned int zT_255;
    unsigned char zT_256;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    unsigned int zT_260;
    unsigned int zT_262;
    unsigned char zT_264;
    unsigned char* zT_267;
    unsigned char zT_268;
    unsigned int zT_270;
    unsigned int zT_272;
    unsigned char zT_273;
    unsigned int zT_275;
    unsigned char zT_276;
    unsigned int zT_278;
    unsigned char zT_279;
    unsigned int zT_281;
    unsigned char* zT_283;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_284;
    unsigned int zT_285;
    unsigned int zT_287;
    unsigned int zT_289;
    unsigned char zT_291;
    unsigned char* zT_294;
    unsigned char zT_295;
    unsigned int zT_297;
    unsigned int zT_299;
    zT_6B0A7D14_AstStore* zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    int zT_305;
    unsigned char* zT_306;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    zT_846744CC_Arr_unsigned_char_5 zT_310;
    unsigned int zT_312;
    unsigned char zT_313;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned int zT_317;
    unsigned int zT_319;
    unsigned char zT_321;
    unsigned char* zT_324;
    unsigned char zT_325;
    unsigned int zT_327;
    unsigned int zT_329;
    unsigned char zT_330;
    unsigned int zT_332;
    unsigned char zT_333;
    unsigned int zT_335;
    unsigned char zT_336;
    unsigned int zT_338;
    unsigned char* zT_340;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_341;
    unsigned int zT_342;
    unsigned int zT_344;
    unsigned int zT_346;
    unsigned char zT_348;
    unsigned char* zT_351;
    unsigned char zT_352;
    unsigned int zT_354;
    unsigned int zT_356;
    zT_6B0A7D14_AstStore* zT_357;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    int zT_364;
    unsigned char* zT_365;
    unsigned int zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    zT_846744CC_Arr_unsigned_char_5 zT_369;
    unsigned int zT_371;
    unsigned char zT_372;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_374;
    unsigned int zT_376;
    unsigned int zT_378;
    unsigned char zT_380;
    unsigned char* zT_383;
    unsigned char zT_384;
    unsigned int zT_386;
    unsigned int zT_388;
    unsigned char zT_389;
    unsigned int zT_391;
    unsigned char zT_392;
    unsigned int zT_394;
    unsigned char zT_395;
    unsigned int zT_397;
    unsigned char* zT_399;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_400;
    unsigned int zT_401;
    unsigned int zT_403;
    unsigned int zT_405;
    unsigned char zT_407;
    unsigned char* zT_410;
    unsigned char zT_411;
    unsigned int zT_413;
    unsigned int zT_415;
    zT_6B0A7D14_AstStore* zT_416;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_418;
    int zT_423;
    unsigned char* zT_424;
    unsigned int zT_425;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_426;
    zT_846744CC_Arr_unsigned_char_5 zT_428;
    unsigned int zT_430;
    unsigned char zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned int zT_435;
    unsigned int zT_437;
    unsigned char zT_439;
    unsigned char* zT_442;
    unsigned char zT_443;
    unsigned int zT_445;
    unsigned int zT_447;
    unsigned char zT_448;
    unsigned int zT_450;
    unsigned char zT_451;
    unsigned int zT_453;
    unsigned char zT_454;
    unsigned int zT_456;
    unsigned char* zT_458;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_459;
    unsigned int zT_460;
    unsigned int zT_462;
    unsigned int zT_464;
    unsigned char zT_466;
    unsigned char* zT_469;
    unsigned char zT_470;
    unsigned int zT_472;
    unsigned int zT_474;
    zT_6B0A7D14_AstStore* zT_475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_477;
    int zT_482;
    unsigned char* zT_483;
    unsigned int zT_484;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_485;
    zT_846744CC_Arr_unsigned_char_5 zT_487;
    unsigned int zT_489;
    unsigned char zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_492;
    unsigned int zT_494;
    unsigned int zT_496;
    unsigned char zT_498;
    unsigned char* zT_501;
    unsigned char zT_502;
    unsigned int zT_504;
    unsigned int zT_506;
    unsigned char zT_507;
    unsigned int zT_509;
    unsigned char zT_510;
    unsigned int zT_512;
    unsigned char zT_513;
    unsigned int zT_515;
    unsigned char* zT_517;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_518;
    unsigned int zT_519;
    unsigned int zT_521;
    unsigned int zT_523;
    unsigned char zT_525;
    unsigned char* zT_528;
    unsigned char zT_529;
    unsigned int zT_531;
    unsigned int zT_533;
    zT_6B0A7D14_AstStore* zT_534;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_536;
    int zT_541;
    unsigned char* zT_542;
    unsigned int zT_543;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_544;
    zT_3E40CD83_Sand* zT_546;
    zT_69057089_CompilerAlloc* zT_547;
    zT_3D7259E2_SymbolRegistry zT_549 = {0};
    zT_3E40CD83_Sand* zT_551;
    zT_69057089_CompilerAlloc* zT_552;
    zT_8EED1867_ResolvedTypeTable zT_554 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_556;
    unsigned int zT_558;
    unsigned char zT_559;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_561;
    unsigned int zT_563;
    unsigned int zT_565;
    unsigned char zT_567;
    unsigned char* zT_570;
    unsigned char zT_571;
    unsigned int zT_573;
    unsigned int zT_575;
    unsigned char zT_576;
    unsigned int zT_578;
    unsigned char zT_579;
    unsigned int zT_581;
    unsigned char zT_582;
    unsigned int zT_584;
    unsigned char* zT_586;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_587;
    unsigned int zT_588;
    unsigned int zT_590;
    unsigned int zT_592;
    unsigned char zT_594;
    unsigned char* zT_597;
    unsigned char zT_598;
    unsigned int zT_600;
    unsigned int zT_602;
    zT_8EED1867_ResolvedTypeTable* zT_603;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_604;
    int zT_608;
    unsigned char* zT_609;
    unsigned int zT_610;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_611;
    zT_3E40CD83_Sand* zT_613;
    zT_69057089_CompilerAlloc* zT_614;
    zT_66E7D2EF_CoercionTable zT_616 = {0};
    zT_3E40CD83_Sand* zT_618;
    zT_69057089_CompilerAlloc* zT_619;
    zT_CA01C129_LirSlotArrayList zT_621 = {0};
    zT_3E40CD83_Sand* zT_623;
    zT_69057089_CompilerAlloc* zT_624;
    zT_4D61441E_DepGraph zT_626 = {0};
    zT_3E40CD83_Sand* zT_628;
    zT_69057089_CompilerAlloc* zT_629;
    zT_21D3708C_U32ToU32Map zT_631 = {0};
    zT_3E40CD83_Sand* zT_633;
    zT_69057089_CompilerAlloc* zT_634;
    zT_21D3708C_U32ToU32Map zT_636 = {0};
    zT_3E40CD83_Sand* zT_638;
    zT_69057089_CompilerAlloc* zT_639;
    zT_21D3708C_U32ToU32Map zT_641 = {0};
    zT_3E40CD83_Sand* zT_643;
    zT_69057089_CompilerAlloc* zT_644;
    zT_21D3708C_U32ToU32Map zT_646 = {0};
    zT_3E40CD83_Sand* zT_648;
    zT_69057089_CompilerAlloc* zT_649;
    zT_21D3708C_U32ToU32Map zT_651 = {0};
    zT_3E40CD83_Sand* zT_653;
    zT_69057089_CompilerAlloc* zT_655;
    zT_77F6F59C_ComptimeFoldTable zT_658 = {0};
    zT_3E40CD83_Sand* zT_660;
    zT_69057089_CompilerAlloc* zT_661;
    zT_4065182A_ConstInitTable zT_663 = {0};
    zT_786E6CF2_EmissionClassificat zT_665;
    zT_3E40CD83_Sand* zT_666;
    zT_69057089_CompilerAlloc* zT_667;
    zT_21D3708C_U32ToU32Map zT_669 = {0};
    zT_3E40CD83_Sand* zT_670;
    zT_69057089_CompilerAlloc* zT_671;
    zT_21D3708C_U32ToU32Map zT_673 = {0};
    zT_3E40CD83_Sand* zT_674;
    zT_69057089_CompilerAlloc* zT_675;
    zT_21D3708C_U32ToU32Map zT_677 = {0};
    zT_3E40CD83_Sand* zT_678;
    zT_69057089_CompilerAlloc* zT_679;
    zT_21D3708C_U32ToU32Map zT_681 = {0};
    zT_1317DCD6_C89SpellPlan zT_683 = {0};
    zT_3E40CD83_Sand* zT_685;
    zT_69057089_CompilerAlloc* zT_686;
    zT_A4CE86B7_U64ToU32Map zT_688 = {0};
    zT_3E40CD83_Sand* zT_690;
    zT_69057089_CompilerAlloc* zT_691;
    zT_A4CE86B7_U64ToU32Map zT_693 = {0};
    zT_3E40CD83_Sand* zT_695;
    zT_69057089_CompilerAlloc* zT_696;
    zT_A4CE86B7_U64ToU32Map zT_698 = {0};
    zT_3E40CD83_Sand* zT_700;
    zT_69057089_CompilerAlloc* zT_701;
    zT_A4CE86B7_U64ToU32Map zT_703 = {0};
    zT_3E40CD83_Sand* zT_705;
    zT_69057089_CompilerAlloc* zT_706;
    zT_A4CE86B7_U64ToU32Map zT_708 = {0};
    zT_3E40CD83_Sand* zT_710;
    zT_69057089_CompilerAlloc* zT_711;
    zT_A4CE86B7_U64ToU32Map zT_713 = {0};
    zT_3E40CD83_Sand* zT_715;
    zT_69057089_CompilerAlloc* zT_716;
    zT_A4CE86B7_U64ToU32Map zT_718 = {0};
    zT_3E40CD83_Sand* zT_720;
    zT_69057089_CompilerAlloc* zT_721;
    zT_B687BB96_U32ArrayList zT_723 = {0};
    zT_3E40CD83_Sand* zT_725;
    zT_69057089_CompilerAlloc* zT_726;
    zT_A4CE86B7_U64ToU32Map zT_728 = {0};
    zT_3E40CD83_Sand* zT_730;
    zT_69057089_CompilerAlloc* zT_731;
    zT_A4CE86B7_U64ToU32Map zT_733 = {0};
    zT_3E40CD83_Sand* zT_735;
    zT_69057089_CompilerAlloc* zT_736;
    zT_A4CE86B7_U64ToU32Map zT_738 = {0};
    zT_5AB29387_CompilerContext zT_740;
    zT_69057089_CompilerAlloc* zT_741;
    zT_D3EB6303_StringInterner* zT_742;
    zT_F85C5DED_DiagnosticCollector* zT_743;
    zT_227EDE07_SourceManager* zT_744;
    zT_072B53A6_ModuleRegistry* zT_745;
    zT_338B7C76_TypeRegistry* zT_746;
    zT_6B0A7D14_AstStore* zT_747;
    zT_3D7259E2_SymbolRegistry* zT_748;
    zT_8EED1867_ResolvedTypeTable* zT_749;
    zT_66E7D2EF_CoercionTable* zT_750;
    zT_4D61441E_DepGraph* zT_751;
    zT_7E7544E4_LirStream zT_752 = {0};
    zT_3E40CD83_Sand* zT_753;
    zT_69057089_CompilerAlloc* zT_754;
    zT_E1A783EF_GlobalDeclArrayList zT_756 = {0};
    zT_3E40CD83_Sand* zT_757;
    zT_69057089_CompilerAlloc* zT_758;
    zT_A4CE86B7_U64ToU32Map zT_760 = {0};
    zT_3E40CD83_Sand* zT_761;
    zT_69057089_CompilerAlloc* zT_762;
    zT_B687BB96_U32ArrayList zT_764 = {0};
    zT_C615AE29_DebugSpanStore zT_765 = {0};
    zT_3E40CD83_Sand* zT_766;
    zT_69057089_CompilerAlloc* zT_767;
    zT_8B83E3B4_DebugSymbolList zT_769 = {0};
    zT_DEDDFC41_DebugMapWriter zT_770 = {0};
    zT_3E40CD83_Sand* zT_771;
    zT_69057089_CompilerAlloc* zT_772;
    zT_1F328BC1_DebugSpanArrayList zT_774 = {0};
    zT_5AB29387_CompilerContext* zT_775;
    zT_8F083A69_Slice_zT_0B42B2F8_u startmsg;
    zT_C98AF326_CompilerCli cli;
    zT_8F083A69_Slice_zT_0B42B2F8_u bon;
    zT_8F083A69_Slice_zT_0B42B2F8_u boff;
    zT_8F083A69_Slice_zT_0B42B2F8_u dmsg;
    zT_69057089_CompilerAlloc compiler_alloc;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u source;
    unsigned int interner_bc;
    unsigned int type_hint;
    unsigned int name_hint;
    unsigned int fold_hint;
    zT_072B53A6_ModuleRegistry mr;
    zT_7D82FE60_GrowableSand type_db_arena;
    zT_8F083A69_Slice_zT_0B42B2F8_u type_db_name;
    zT_338B7C76_TypeRegistry typereg;
    zT_6B0A7D14_AstStore store;
    zT_846744CC_Arr_unsigned_char_5 ast_spill_path;
    unsigned int asp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od2;
    unsigned int oi2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ast_tmp_name;
    unsigned int ati;
    zT_846744CC_Arr_unsigned_char_5 id_spill_path;
    unsigned int idp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od3;
    unsigned int oi3;
    zT_8F083A69_Slice_zT_0B42B2F8_u id_tmp_name;
    unsigned int iti;
    zT_846744CC_Arr_unsigned_char_5 iv_spill_path;
    unsigned int ivp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od5;
    unsigned int oi5;
    zT_8F083A69_Slice_zT_0B42B2F8_u iv_tmp_name;
    unsigned int ivi;
    zT_846744CC_Arr_unsigned_char_5 ec_spill_path;
    unsigned int ecp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od6;
    unsigned int oi6;
    zT_8F083A69_Slice_zT_0B42B2F8_u ec_tmp_name;
    unsigned int eci;
    zT_846744CC_Arr_unsigned_char_5 er_spill_path;
    unsigned int erp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od7;
    unsigned int oi7;
    zT_8F083A69_Slice_zT_0B42B2F8_u er_tmp_name;
    unsigned int eri;
    zT_3D7259E2_SymbolRegistry symbol_reg;
    zT_8EED1867_ResolvedTypeTable resolved_types;
    zT_846744CC_Arr_unsigned_char_5 rtt_spill_path;
    unsigned int rsp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od4;
    unsigned int oi4;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtt_tmp_name;
    unsigned int rti2;
    zT_66E7D2EF_CoercionTable coercion_table;
    zT_CA01C129_LirSlotArrayList lir_slots;
    zT_4D61441E_DepGraph dep_graph;
    zT_21D3708C_U32ToU32Map enum_value_table;
    zT_21D3708C_U32ToU32Map tuple_index_table;
    zT_21D3708C_U32ToU32Map error_code_registry;
    zT_21D3708C_U32ToU32Map call_arg_types;
    zT_21D3708C_U32ToU32Map call_param_map;
    zT_77F6F59C_ComptimeFoldTable comptime_folds;
    zT_4065182A_ConstInitTable const_inits;
    zT_786E6CF2_EmissionClassificat emission_classif;
    zT_1317DCD6_C89SpellPlan spell_plan_ph;
    zT_A4CE86B7_U64ToU32Map exported;
    zT_A4CE86B7_U64ToU32Map suspending_fns;
    zT_A4CE86B7_U64ToU32Map frame_sizes;
    zT_A4CE86B7_U64ToU32Map state_widths;
    zT_A4CE86B7_U64ToU32Map awaited_fns;
    zT_A4CE86B7_U64ToU32Map async_hidden_fns;
    zT_A4CE86B7_U64ToU32Map driver_targets;
    zT_B687BB96_U32ArrayList parent_result_type_list;
    zT_A4CE86B7_U64ToU32Map parent_result_start;
    zT_A4CE86B7_U64ToU32Map parent_result_count;
    zT_A4CE86B7_U64ToU32Map async_layouts;
    zT_5AB29387_CompilerContext ctx;
    zT_2 = argc;
    zT_3 = argv;
    zF_4DE8E0A6_initArgs(zT_2, zT_3);
    zT_5 = "START\n";
    zT_7 = 6;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    startmsg = zT_6;
    zT_8 = startmsg;
    zF_48AC7B3A_markerWrite(zT_8);
    zT_10 = zF_6143A521_parseArgs();
    cli = zT_10;
    zT_11 = cli.show_markers;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zF_3C88665D_markersEnabled((unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    zT_14 = cli.quiet;
    if ((unsigned char)(!zT_14)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = cli.debug;
    if (zT_16) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    zT_27 = cli.debug;
    if (zT_27) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_18 = "Z98 Compiler 2026 (map: on)\n";
    zT_20 = 28;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    bon = zT_19;
    zT_21 = bon;
    zF_E4B2EF19_stderr_write(zT_21);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_23 = "Z98 Compiler 2026 (map: off)\n";
    zT_25 = 29;
    zT_24.ptr = (unsigned char*)zT_23;
    zT_24.len = zT_25;
    boff = zT_24;
    zT_26 = boff;
    zF_E4B2EF19_stderr_write(zT_26);
    goto z_bb_6;
    z_bb_8:
    zT_29 = cli.output_dir_set;
    zT_28 = !zT_29;
    goto z_bb_10;
    z_bb_9:
    zT_28 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_28) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_32 = "error: --debug/-d requires --output-dir\n";
    zT_34 = 40;
    zT_33.ptr = (unsigned char*)zT_32;
    zT_33.len = zT_34;
    dmsg = zT_33;
    zT_35 = dmsg;
    zF_E4B2EF19_stderr_write(zT_35);
    zF_CDED1A85_exit((unsigned char)(2));
    return;
    z_bb_12:
    zT_38 = cli.sanity_test_mode;
    if (zT_38) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_40 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_40;
    zT_44 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_42 = &zT_44->permanent;
    zT_46 = 4;
    zT_48 = zF_FB2E811D_stringInternerInit(zT_42, (unsigned int)((unsigned int)zT_46));
    interner = zT_48;
    zT_51 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_50 = &zT_51->permanent;
    zT_53 = zF_01351F51_sourceManagerInit(zT_50);
    source_man = zT_53;
    zT_58 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_55 = &zT_58->permanent;
    zT_56 = (zT_227EDE07_SourceManager*)&source_man;
    zT_57 = (zT_D3EB6303_StringInterner*)&interner;
    (void)zF_C7BA7DAB_diagnosticCollector(zT_55, zT_56, zT_57);
    zT_64 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_63 = &zT_64->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_63);
    zF_519E4401_lexerTestSanityChec();
    return;
    z_bb_14:
    zT_66 = cli.test_mode;
    if (zT_66) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_68 = "error: use test_main.zig for test mode\n";
    zT_70 = 39;
    zT_69.ptr = (unsigned char*)zT_68;
    zT_69.len = zT_70;
    msg = zT_69;
    zT_71 = msg;
    zF_48AC7B3A_markerWrite(zT_71);
    zT_73 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_73));
    return;
    z_bb_16:
    zT_75 = cli.input_file;
    zT_77 = zT_75.len;
    zT_78 = 0;
    if ((unsigned char)(zT_77 == (unsigned int)zT_78)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zF_9D45DFBF_printUsage();
    return;
    z_bb_18:
    zT_80 = cli.output_dir_set;
    if (zT_80) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_83 = cli.output_dir;
    zT_82 = zT_83;
    zT_84 = zF_8CC05F84_dirExists(zT_82);
    zT_81 = !zT_84;
    goto z_bb_21;
    z_bb_20:
    zT_81 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_81) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_87 = "error: output directory does not exist: ";
    zT_89 = 40;
    zT_88.ptr = (unsigned char*)zT_87;
    zT_88.len = zT_89;
    msg = zT_88;
    zT_90 = msg;
    zF_E4B2EF19_stderr_write(zT_90);
    zT_92 = cli.output_dir;
    zT_91 = zT_92;
    zF_E4B2EF19_stderr_write(zT_91);
    zT_94 = "\n";
    zT_96 = 1;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    nl = zT_95;
    zT_97 = nl;
    zF_E4B2EF19_stderr_write(zT_97);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_23:
    zT_101 = cli.input_file;
    zT_100 = zT_101;
    zT_102 = zF_5FF93310_isReservedDosDevice(zT_100);
    if (zT_102) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_104 = "error: reserved DOS device name in input file path: ";
    zT_106 = 52;
    zT_105.ptr = (unsigned char*)zT_104;
    zT_105.len = zT_106;
    msg = zT_105;
    zT_107 = msg;
    zF_E4B2EF19_stderr_write(zT_107);
    zT_109 = cli.input_file;
    zT_108 = zT_109;
    zF_E4B2EF19_stderr_write(zT_108);
    zT_111 = "\n";
    zT_113 = 1;
    zT_112.ptr = (unsigned char*)zT_111;
    zT_112.len = zT_113;
    nl = zT_112;
    zT_114 = nl;
    zF_E4B2EF19_stderr_write(zT_114);
    zF_CDED1A85_exit((unsigned char)(2));
    return;
    z_bb_25:
    zT_118 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_118;
    zT_119 = cli.max_mem;
    compiler_alloc.max_mem = zT_119;
    zT_120 = cli.spill_level;
    zF_4EDF4E7B_spillSetLevel(zT_120);
    zT_125 = cli.input_file;
    zT_123 = zT_125;
    zT_126 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_124 = &zT_126->scratch;
    zT_128 = zF_5B859C63_readFile(zT_123, zT_124);
    zT_129 = zT_128.has_value;
    if (zT_129) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_133 = "error: could not read input file\n";
    zT_135 = 33;
    zT_134.ptr = (unsigned char*)zT_133;
    zT_134.len = zT_135;
    msg = zT_134;
    zT_136 = msg;
    zF_E4B2EF19_stderr_write(zT_136);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_27:
    zT_139 = zT_128.value;
    zT_130 = zT_139;
    goto z_bb_28;
    z_bb_28:
    source = zT_130;
    zT_142 = source.len;
    zT_145 = source.len;
    zT_149 = (unsigned int)((unsigned int)zT_142) + (unsigned int)((unsigned int)(unsigned int)(zT_145 / (unsigned int)(4)));
    interner_bc = zT_149;
    if ((unsigned char)(interner_bc < (unsigned int)(4096))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_152 = 4096;
    interner_bc = zT_152;
    goto z_bb_30;
    z_bb_30:
    zT_155 = source.len;
    zT_158 = (unsigned int)(unsigned int)(zT_155 / (unsigned int)(32));
    type_hint = zT_158;
    if ((unsigned char)(type_hint < (unsigned int)(4096))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_161 = 4096;
    type_hint = zT_161;
    goto z_bb_32;
    z_bb_32:
    zT_164 = source.len;
    zT_167 = (unsigned int)(unsigned int)(zT_164 / (unsigned int)(10));
    name_hint = zT_167;
    if ((unsigned char)(name_hint < (unsigned int)(2048))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_170 = 2048;
    name_hint = zT_170;
    goto z_bb_34;
    z_bb_34:
    zT_173 = source.len;
    zT_176 = (unsigned int)(unsigned int)(zT_173 / (unsigned int)(9));
    fold_hint = zT_176;
    if ((unsigned char)(fold_hint < (unsigned int)(16))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_179 = 16;
    fold_hint = zT_179;
    goto z_bb_36;
    z_bb_36:
    zT_183 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_181 = &zT_183->permanent;
    zT_182 = interner_bc;
    zT_185 = zF_FB2E811D_stringInternerInit(zT_181, zT_182);
    interner = zT_185;
    zT_188 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_187 = &zT_188->permanent;
    zT_190 = zF_01351F51_sourceManagerInit(zT_187);
    source_man = zT_190;
    zT_195 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_192 = &zT_195->permanent;
    zT_193 = (zT_227EDE07_SourceManager*)&source_man;
    zT_194 = (zT_D3EB6303_StringInterner*)&interner;
    zT_199 = zF_C7BA7DAB_diagnosticCollector(zT_192, zT_193, zT_194);
    diag = zT_199;
    zT_200 = cli.max_errors;
    diag.max_diagnostics = (unsigned int)((unsigned int)zT_200);
    zT_203 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_202 = &zT_203->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_202);
    zT_209 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_206 = &zT_209->permanent;
    zT_207 = (zT_D3EB6303_StringInterner*)&interner;
    zT_208 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_213 = zF_896FAF3C_moduleRegistryInit(zT_206, zT_207, zT_208);
    mr = zT_213;
    zT_214 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_215 = (zT_227EDE07_SourceManager*)&source_man;
    zF_BD2BF0BD_moduleRegistrySetSo(zT_214, zT_215);
    zT_218 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_219 = cli.target_is_windows;
    zF_849BBF28_moduleRegistrySetTa(zT_218, zT_219);
    type_db_arena = zT_223;
    zT_225 = "type_db";
    zT_227 = 7;
    zT_226.ptr = (unsigned char*)zT_225;
    zT_226.len = zT_227;
    type_db_name = zT_226;
    zT_228 = (zT_7D82FE60_GrowableSand*)&type_db_arena;
    zT_233 = zF_8C23960F_poolPtr();
    zT_229 = zT_233;
    zT_234 = 4096;
    zT_231 = type_db_name;
    zF_07B11742_growableSandInit(zT_228, zT_229, (unsigned int)((unsigned int)zT_234), zT_231);
    zT_241 = (zT_7D82FE60_GrowableSand*)&type_db_arena;
    zT_237 = &zT_241->view;
    zT_238 = (zT_D3EB6303_StringInterner*)&interner;
    zT_239 = type_hint;
    zT_240 = name_hint;
    zT_244 = zF_28AE6613_typeRegistryInitSiz(zT_237, zT_238, zT_239, zT_240);
    typereg = zT_244;
    zT_245 = (zT_338B7C76_TypeRegistry*)&typereg;
    zF_541737A5_typeRegistryRegiste(zT_245);
    zT_249 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_248 = &zT_249->module;
    zT_251 = zF_D9F91436_astStoreInit(zT_248);
    store = zT_251;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_253[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ast_spill_path[_i] = zT_253[_i];
        _i++;
    }
}
    zT_255 = 0;
    asp_len = zT_255;
    zT_256 = cli.output_dir_set;
    if (zT_256) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_258 = cli.output_dir;
    od2 = zT_258;
    zT_260 = 0;
    oi2 = zT_260;
    goto z_bb_40;
    z_bb_38:
    zT_283 = ".zig1_ast.tmp";
    zT_285 = 13;
    zT_284.ptr = (unsigned char*)zT_283;
    zT_284.len = zT_285;
    ast_tmp_name = zT_284;
    zT_287 = 0;
    ati = zT_287;
    goto z_bb_47;
    z_bb_39:
    zT_276 = 46;
    ast_spill_path[asp_len] = zT_276;
    zT_278 = asp_len + (unsigned int)(1);
    asp_len = zT_278;
    zT_279 = 47;
    ast_spill_path[asp_len] = zT_279;
    zT_281 = asp_len + (unsigned int)(1);
    asp_len = zT_281;
    goto z_bb_38;
    z_bb_40:
    zT_262 = od2.len;
    if ((unsigned char)(oi2 < zT_262)) goto z_bb_44; else goto z_bb_45;
    z_bb_41:
    zT_267 = od2.ptr;
    zT_268 = zT_267[oi2];
    ast_spill_path[asp_len] = zT_268;
    zT_270 = asp_len + (unsigned int)(1);
    asp_len = zT_270;
    goto z_bb_43;
    z_bb_42:
    zT_273 = 47;
    ast_spill_path[asp_len] = zT_273;
    zT_275 = asp_len + (unsigned int)(1);
    asp_len = zT_275;
    goto z_bb_38;
    z_bb_43:
    zT_272 = oi2 + (unsigned int)(1);
    oi2 = zT_272;
    goto z_bb_40;
    z_bb_44:
    zT_264 = asp_len < (unsigned int)(511);
    goto z_bb_46;
    z_bb_45:
    zT_264 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_264) goto z_bb_41; else goto z_bb_42;
    z_bb_47:
    zT_289 = ast_tmp_name.len;
    if ((unsigned char)(ati < zT_289)) goto z_bb_51; else goto z_bb_52;
    z_bb_48:
    zT_294 = ast_tmp_name.ptr;
    zT_295 = zT_294[ati];
    ast_spill_path[asp_len] = zT_295;
    zT_297 = asp_len + (unsigned int)(1);
    asp_len = zT_297;
    goto z_bb_50;
    z_bb_49:
    zT_300 = (zT_6B0A7D14_AstStore*)&store;
    zT_305 = 0;
    zT_306 = (unsigned char*)((unsigned char*)ast_spill_path) + zT_305;
    zT_307 = asp_len - zT_305;
    zT_308.ptr = (unsigned char*)zT_306;
    zT_308.len = zT_307;
    zT_301 = zT_308;
    zF_2A507339_astStoreSetSpillPat(zT_300, zT_301);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_310[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        id_spill_path[_i] = zT_310[_i];
        _i++;
    }
}
    zT_312 = 0;
    idp_len = zT_312;
    zT_313 = cli.output_dir_set;
    if (zT_313) goto z_bb_54; else goto z_bb_56;
    z_bb_50:
    zT_299 = ati + (unsigned int)(1);
    ati = zT_299;
    goto z_bb_47;
    z_bb_51:
    zT_291 = asp_len < (unsigned int)(511);
    goto z_bb_53;
    z_bb_52:
    zT_291 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_291) goto z_bb_48; else goto z_bb_49;
    z_bb_54:
    zT_315 = cli.output_dir;
    od3 = zT_315;
    zT_317 = 0;
    oi3 = zT_317;
    goto z_bb_57;
    z_bb_55:
    zT_340 = ".zig1_side.tmp";
    zT_342 = 14;
    zT_341.ptr = (unsigned char*)zT_340;
    zT_341.len = zT_342;
    id_tmp_name = zT_341;
    zT_344 = 0;
    iti = zT_344;
    goto z_bb_64;
    z_bb_56:
    zT_333 = 46;
    id_spill_path[idp_len] = zT_333;
    zT_335 = idp_len + (unsigned int)(1);
    idp_len = zT_335;
    zT_336 = 47;
    id_spill_path[idp_len] = zT_336;
    zT_338 = idp_len + (unsigned int)(1);
    idp_len = zT_338;
    goto z_bb_55;
    z_bb_57:
    zT_319 = od3.len;
    if ((unsigned char)(oi3 < zT_319)) goto z_bb_61; else goto z_bb_62;
    z_bb_58:
    zT_324 = od3.ptr;
    zT_325 = zT_324[oi3];
    id_spill_path[idp_len] = zT_325;
    zT_327 = idp_len + (unsigned int)(1);
    idp_len = zT_327;
    goto z_bb_60;
    z_bb_59:
    zT_330 = 47;
    id_spill_path[idp_len] = zT_330;
    zT_332 = idp_len + (unsigned int)(1);
    idp_len = zT_332;
    goto z_bb_55;
    z_bb_60:
    zT_329 = oi3 + (unsigned int)(1);
    oi3 = zT_329;
    goto z_bb_57;
    z_bb_61:
    zT_321 = idp_len < (unsigned int)(511);
    goto z_bb_63;
    z_bb_62:
    zT_321 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_321) goto z_bb_58; else goto z_bb_59;
    z_bb_64:
    zT_346 = id_tmp_name.len;
    if ((unsigned char)(iti < zT_346)) goto z_bb_68; else goto z_bb_69;
    z_bb_65:
    zT_351 = id_tmp_name.ptr;
    zT_352 = zT_351[iti];
    id_spill_path[idp_len] = zT_352;
    zT_354 = idp_len + (unsigned int)(1);
    idp_len = zT_354;
    goto z_bb_67;
    z_bb_66:
    zT_357 = (zT_6B0A7D14_AstStore*)&store;
    zT_364 = 0;
    zT_365 = (unsigned char*)((unsigned char*)id_spill_path) + zT_364;
    zT_366 = idp_len - zT_364;
    zT_367.ptr = (unsigned char*)zT_365;
    zT_367.len = zT_366;
    zT_359 = zT_367;
    zF_35B9B6EC_astStoreSetValuePoo(zT_357, (unsigned int)(0), zT_359);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_369[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        iv_spill_path[_i] = zT_369[_i];
        _i++;
    }
}
    zT_371 = 0;
    ivp_len = zT_371;
    zT_372 = cli.output_dir_set;
    if (zT_372) goto z_bb_71; else goto z_bb_73;
    z_bb_67:
    zT_356 = iti + (unsigned int)(1);
    iti = zT_356;
    goto z_bb_64;
    z_bb_68:
    zT_348 = idp_len < (unsigned int)(511);
    goto z_bb_70;
    z_bb_69:
    zT_348 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_348) goto z_bb_65; else goto z_bb_66;
    z_bb_71:
    zT_374 = cli.output_dir;
    od5 = zT_374;
    zT_376 = 0;
    oi5 = zT_376;
    goto z_bb_74;
    z_bb_72:
    zT_399 = ".zig1_side_iv.tmp";
    zT_401 = 17;
    zT_400.ptr = (unsigned char*)zT_399;
    zT_400.len = zT_401;
    iv_tmp_name = zT_400;
    zT_403 = 0;
    ivi = zT_403;
    goto z_bb_81;
    z_bb_73:
    zT_392 = 46;
    iv_spill_path[ivp_len] = zT_392;
    zT_394 = ivp_len + (unsigned int)(1);
    ivp_len = zT_394;
    zT_395 = 47;
    iv_spill_path[ivp_len] = zT_395;
    zT_397 = ivp_len + (unsigned int)(1);
    ivp_len = zT_397;
    goto z_bb_72;
    z_bb_74:
    zT_378 = od5.len;
    if ((unsigned char)(oi5 < zT_378)) goto z_bb_78; else goto z_bb_79;
    z_bb_75:
    zT_383 = od5.ptr;
    zT_384 = zT_383[oi5];
    iv_spill_path[ivp_len] = zT_384;
    zT_386 = ivp_len + (unsigned int)(1);
    ivp_len = zT_386;
    goto z_bb_77;
    z_bb_76:
    zT_389 = 47;
    iv_spill_path[ivp_len] = zT_389;
    zT_391 = ivp_len + (unsigned int)(1);
    ivp_len = zT_391;
    goto z_bb_72;
    z_bb_77:
    zT_388 = oi5 + (unsigned int)(1);
    oi5 = zT_388;
    goto z_bb_74;
    z_bb_78:
    zT_380 = ivp_len < (unsigned int)(511);
    goto z_bb_80;
    z_bb_79:
    zT_380 = 0;
    goto z_bb_80;
    z_bb_80:
    if (zT_380) goto z_bb_75; else goto z_bb_76;
    z_bb_81:
    zT_405 = iv_tmp_name.len;
    if ((unsigned char)(ivi < zT_405)) goto z_bb_85; else goto z_bb_86;
    z_bb_82:
    zT_410 = iv_tmp_name.ptr;
    zT_411 = zT_410[ivi];
    iv_spill_path[ivp_len] = zT_411;
    zT_413 = ivp_len + (unsigned int)(1);
    ivp_len = zT_413;
    goto z_bb_84;
    z_bb_83:
    zT_416 = (zT_6B0A7D14_AstStore*)&store;
    zT_423 = 0;
    zT_424 = (unsigned char*)((unsigned char*)iv_spill_path) + zT_423;
    zT_425 = ivp_len - zT_423;
    zT_426.ptr = (unsigned char*)zT_424;
    zT_426.len = zT_425;
    zT_418 = zT_426;
    zF_35B9B6EC_astStoreSetValuePoo(zT_416, (unsigned int)(1), zT_418);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_428[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ec_spill_path[_i] = zT_428[_i];
        _i++;
    }
}
    zT_430 = 0;
    ecp_len = zT_430;
    zT_431 = cli.output_dir_set;
    if (zT_431) goto z_bb_88; else goto z_bb_90;
    z_bb_84:
    zT_415 = ivi + (unsigned int)(1);
    ivi = zT_415;
    goto z_bb_81;
    z_bb_85:
    zT_407 = ivp_len < (unsigned int)(511);
    goto z_bb_87;
    z_bb_86:
    zT_407 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_407) goto z_bb_82; else goto z_bb_83;
    z_bb_88:
    zT_433 = cli.output_dir;
    od6 = zT_433;
    zT_435 = 0;
    oi6 = zT_435;
    goto z_bb_91;
    z_bb_89:
    zT_458 = ".zig1_extra_ec.tmp";
    zT_460 = 18;
    zT_459.ptr = (unsigned char*)zT_458;
    zT_459.len = zT_460;
    ec_tmp_name = zT_459;
    zT_462 = 0;
    eci = zT_462;
    goto z_bb_98;
    z_bb_90:
    zT_451 = 46;
    ec_spill_path[ecp_len] = zT_451;
    zT_453 = ecp_len + (unsigned int)(1);
    ecp_len = zT_453;
    zT_454 = 47;
    ec_spill_path[ecp_len] = zT_454;
    zT_456 = ecp_len + (unsigned int)(1);
    ecp_len = zT_456;
    goto z_bb_89;
    z_bb_91:
    zT_437 = od6.len;
    if ((unsigned char)(oi6 < zT_437)) goto z_bb_95; else goto z_bb_96;
    z_bb_92:
    zT_442 = od6.ptr;
    zT_443 = zT_442[oi6];
    ec_spill_path[ecp_len] = zT_443;
    zT_445 = ecp_len + (unsigned int)(1);
    ecp_len = zT_445;
    goto z_bb_94;
    z_bb_93:
    zT_448 = 47;
    ec_spill_path[ecp_len] = zT_448;
    zT_450 = ecp_len + (unsigned int)(1);
    ecp_len = zT_450;
    goto z_bb_89;
    z_bb_94:
    zT_447 = oi6 + (unsigned int)(1);
    oi6 = zT_447;
    goto z_bb_91;
    z_bb_95:
    zT_439 = ecp_len < (unsigned int)(511);
    goto z_bb_97;
    z_bb_96:
    zT_439 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_439) goto z_bb_92; else goto z_bb_93;
    z_bb_98:
    zT_464 = ec_tmp_name.len;
    if ((unsigned char)(eci < zT_464)) goto z_bb_102; else goto z_bb_103;
    z_bb_99:
    zT_469 = ec_tmp_name.ptr;
    zT_470 = zT_469[eci];
    ec_spill_path[ecp_len] = zT_470;
    zT_472 = ecp_len + (unsigned int)(1);
    ecp_len = zT_472;
    goto z_bb_101;
    z_bb_100:
    zT_475 = (zT_6B0A7D14_AstStore*)&store;
    zT_482 = 0;
    zT_483 = (unsigned char*)((unsigned char*)ec_spill_path) + zT_482;
    zT_484 = ecp_len - zT_482;
    zT_485.ptr = (unsigned char*)zT_483;
    zT_485.len = zT_484;
    zT_477 = zT_485;
    zF_35B9B6EC_astStoreSetValuePoo(zT_475, (unsigned int)(2), zT_477);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_487[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        er_spill_path[_i] = zT_487[_i];
        _i++;
    }
}
    zT_489 = 0;
    erp_len = zT_489;
    zT_490 = cli.output_dir_set;
    if (zT_490) goto z_bb_105; else goto z_bb_107;
    z_bb_101:
    zT_474 = eci + (unsigned int)(1);
    eci = zT_474;
    goto z_bb_98;
    z_bb_102:
    zT_466 = ecp_len < (unsigned int)(511);
    goto z_bb_104;
    z_bb_103:
    zT_466 = 0;
    goto z_bb_104;
    z_bb_104:
    if (zT_466) goto z_bb_99; else goto z_bb_100;
    z_bb_105:
    zT_492 = cli.output_dir;
    od7 = zT_492;
    zT_494 = 0;
    oi7 = zT_494;
    goto z_bb_108;
    z_bb_106:
    zT_517 = ".zig1_extra_er.tmp";
    zT_519 = 18;
    zT_518.ptr = (unsigned char*)zT_517;
    zT_518.len = zT_519;
    er_tmp_name = zT_518;
    zT_521 = 0;
    eri = zT_521;
    goto z_bb_115;
    z_bb_107:
    zT_510 = 46;
    er_spill_path[erp_len] = zT_510;
    zT_512 = erp_len + (unsigned int)(1);
    erp_len = zT_512;
    zT_513 = 47;
    er_spill_path[erp_len] = zT_513;
    zT_515 = erp_len + (unsigned int)(1);
    erp_len = zT_515;
    goto z_bb_106;
    z_bb_108:
    zT_496 = od7.len;
    if ((unsigned char)(oi7 < zT_496)) goto z_bb_112; else goto z_bb_113;
    z_bb_109:
    zT_501 = od7.ptr;
    zT_502 = zT_501[oi7];
    er_spill_path[erp_len] = zT_502;
    zT_504 = erp_len + (unsigned int)(1);
    erp_len = zT_504;
    goto z_bb_111;
    z_bb_110:
    zT_507 = 47;
    er_spill_path[erp_len] = zT_507;
    zT_509 = erp_len + (unsigned int)(1);
    erp_len = zT_509;
    goto z_bb_106;
    z_bb_111:
    zT_506 = oi7 + (unsigned int)(1);
    oi7 = zT_506;
    goto z_bb_108;
    z_bb_112:
    zT_498 = erp_len < (unsigned int)(511);
    goto z_bb_114;
    z_bb_113:
    zT_498 = 0;
    goto z_bb_114;
    z_bb_114:
    if (zT_498) goto z_bb_109; else goto z_bb_110;
    z_bb_115:
    zT_523 = er_tmp_name.len;
    if ((unsigned char)(eri < zT_523)) goto z_bb_119; else goto z_bb_120;
    z_bb_116:
    zT_528 = er_tmp_name.ptr;
    zT_529 = zT_528[eri];
    er_spill_path[erp_len] = zT_529;
    zT_531 = erp_len + (unsigned int)(1);
    erp_len = zT_531;
    goto z_bb_118;
    z_bb_117:
    zT_534 = (zT_6B0A7D14_AstStore*)&store;
    zT_541 = 0;
    zT_542 = (unsigned char*)((unsigned char*)er_spill_path) + zT_541;
    zT_543 = erp_len - zT_541;
    zT_544.ptr = (unsigned char*)zT_542;
    zT_544.len = zT_543;
    zT_536 = zT_544;
    zF_35B9B6EC_astStoreSetValuePoo(zT_534, (unsigned int)(3), zT_536);
    zT_547 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_546 = &zT_547->permanent;
    zT_549 = zF_09A884A8_symbolRegistryInit(zT_546);
    symbol_reg = zT_549;
    zT_552 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_551 = &zT_552->module;
    zT_554 = zF_8D0F00B1_resolvedTypeTableIn(zT_551);
    resolved_types = zT_554;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_556[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        rtt_spill_path[_i] = zT_556[_i];
        _i++;
    }
}
    zT_558 = 0;
    rsp_len = zT_558;
    zT_559 = cli.output_dir_set;
    if (zT_559) goto z_bb_122; else goto z_bb_124;
    z_bb_118:
    zT_533 = eri + (unsigned int)(1);
    eri = zT_533;
    goto z_bb_115;
    z_bb_119:
    zT_525 = erp_len < (unsigned int)(511);
    goto z_bb_121;
    z_bb_120:
    zT_525 = 0;
    goto z_bb_121;
    z_bb_121:
    if (zT_525) goto z_bb_116; else goto z_bb_117;
    z_bb_122:
    zT_561 = cli.output_dir;
    od4 = zT_561;
    zT_563 = 0;
    oi4 = zT_563;
    goto z_bb_125;
    z_bb_123:
    zT_586 = ".zig1_res.tmp";
    zT_588 = 13;
    zT_587.ptr = (unsigned char*)zT_586;
    zT_587.len = zT_588;
    rtt_tmp_name = zT_587;
    zT_590 = 0;
    rti2 = zT_590;
    goto z_bb_132;
    z_bb_124:
    zT_579 = 46;
    rtt_spill_path[rsp_len] = zT_579;
    zT_581 = rsp_len + (unsigned int)(1);
    rsp_len = zT_581;
    zT_582 = 47;
    rtt_spill_path[rsp_len] = zT_582;
    zT_584 = rsp_len + (unsigned int)(1);
    rsp_len = zT_584;
    goto z_bb_123;
    z_bb_125:
    zT_565 = od4.len;
    if ((unsigned char)(oi4 < zT_565)) goto z_bb_129; else goto z_bb_130;
    z_bb_126:
    zT_570 = od4.ptr;
    zT_571 = zT_570[oi4];
    rtt_spill_path[rsp_len] = zT_571;
    zT_573 = rsp_len + (unsigned int)(1);
    rsp_len = zT_573;
    goto z_bb_128;
    z_bb_127:
    zT_576 = 47;
    rtt_spill_path[rsp_len] = zT_576;
    zT_578 = rsp_len + (unsigned int)(1);
    rsp_len = zT_578;
    goto z_bb_123;
    z_bb_128:
    zT_575 = oi4 + (unsigned int)(1);
    oi4 = zT_575;
    goto z_bb_125;
    z_bb_129:
    zT_567 = rsp_len < (unsigned int)(511);
    goto z_bb_131;
    z_bb_130:
    zT_567 = 0;
    goto z_bb_131;
    z_bb_131:
    if (zT_567) goto z_bb_126; else goto z_bb_127;
    z_bb_132:
    zT_592 = rtt_tmp_name.len;
    if ((unsigned char)(rti2 < zT_592)) goto z_bb_136; else goto z_bb_137;
    z_bb_133:
    zT_597 = rtt_tmp_name.ptr;
    zT_598 = zT_597[rti2];
    rtt_spill_path[rsp_len] = zT_598;
    zT_600 = rsp_len + (unsigned int)(1);
    rsp_len = zT_600;
    goto z_bb_135;
    z_bb_134:
    zT_603 = (zT_8EED1867_ResolvedTypeTable*)&resolved_types;
    zT_608 = 0;
    zT_609 = (unsigned char*)((unsigned char*)rtt_spill_path) + zT_608;
    zT_610 = rsp_len - zT_608;
    zT_611.ptr = (unsigned char*)zT_609;
    zT_611.len = zT_610;
    zT_604 = zT_611;
    zF_7238A436_resolvedTypeTableSe(zT_603, zT_604);
    zT_614 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_613 = &zT_614->module;
    zT_616 = zF_26B6D809_coercionTableInit(zT_613);
    coercion_table = zT_616;
    zT_619 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_618 = &zT_619->emission;
    zT_621 = zF_F91F6677_lirSlotArrayListIni(zT_618);
    lir_slots = zT_621;
    zT_624 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_623 = &zT_624->module;
    zT_626 = zF_7F194604_depGraphInit(zT_623);
    dep_graph = zT_626;
    zT_629 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_628 = &zT_629->module;
    zT_631 = zF_58BDA2DE_u32ToU32MapInit(zT_628);
    enum_value_table = zT_631;
    zT_634 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_633 = &zT_634->module;
    zT_636 = zF_58BDA2DE_u32ToU32MapInit(zT_633);
    tuple_index_table = zT_636;
    zT_639 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_638 = &zT_639->emission;
    zT_641 = zF_58BDA2DE_u32ToU32MapInit(zT_638);
    error_code_registry = zT_641;
    zT_644 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_643 = &zT_644->module;
    zT_646 = zF_58BDA2DE_u32ToU32MapInit(zT_643);
    call_arg_types = zT_646;
    zT_649 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_648 = &zT_649->module;
    zT_651 = zF_58BDA2DE_u32ToU32MapInit(zT_648);
    call_param_map = zT_651;
    zT_655 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_653 = &zT_655->module;
    zT_658 = zF_125E6ED1_comptimeFoldTableIn(zT_653, (unsigned int)((unsigned int)fold_hint));
    comptime_folds = zT_658;
    zT_661 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_660 = &zT_661->emission;
    zT_663 = zF_046B7660_constInitTableInit(zT_660);
    const_inits = zT_663;
    zT_667 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_666 = &zT_667->permanent;
    zT_669 = zF_58BDA2DE_u32ToU32MapInit(zT_666);
    zT_665.shared_set = zT_669;
    zT_671 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_670 = &zT_671->permanent;
    zT_673 = zF_58BDA2DE_u32ToU32MapInit(zT_670);
    zT_665.pointer_only_map = zT_673;
    zT_675 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_674 = &zT_675->permanent;
    zT_677 = zF_58BDA2DE_u32ToU32MapInit(zT_674);
    zT_665.needs_def_map = zT_677;
    zT_679 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_678 = &zT_679->permanent;
    zT_681 = zF_58BDA2DE_u32ToU32MapInit(zT_678);
    zT_665.needed_tuple_set = zT_681;
    emission_classif = zT_665;
    spell_plan_ph = zT_683;
    zT_686 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_685 = &zT_686->emission;
    zT_688 = zF_986226E1_u64ToU32MapInit(zT_685);
    exported = zT_688;
    zT_691 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_690 = &zT_691->module;
    zT_693 = zF_986226E1_u64ToU32MapInit(zT_690);
    suspending_fns = zT_693;
    zT_696 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_695 = &zT_696->module;
    zT_698 = zF_986226E1_u64ToU32MapInit(zT_695);
    frame_sizes = zT_698;
    zT_701 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_700 = &zT_701->module;
    zT_703 = zF_986226E1_u64ToU32MapInit(zT_700);
    state_widths = zT_703;
    zT_706 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_705 = &zT_706->module;
    zT_708 = zF_986226E1_u64ToU32MapInit(zT_705);
    awaited_fns = zT_708;
    zT_711 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_710 = &zT_711->module;
    zT_713 = zF_986226E1_u64ToU32MapInit(zT_710);
    async_hidden_fns = zT_713;
    zT_716 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_715 = &zT_716->module;
    zT_718 = zF_986226E1_u64ToU32MapInit(zT_715);
    driver_targets = zT_718;
    zT_721 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_720 = &zT_721->module;
    zT_723 = zF_8E537D0C_u32ArrayListInit(zT_720);
    parent_result_type_list = zT_723;
    zT_726 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_725 = &zT_726->module;
    zT_728 = zF_986226E1_u64ToU32MapInit(zT_725);
    parent_result_start = zT_728;
    zT_731 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_730 = &zT_731->module;
    zT_733 = zF_986226E1_u64ToU32MapInit(zT_730);
    parent_result_count = zT_733;
    zT_736 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_735 = &zT_736->module;
    zT_738 = zF_986226E1_u64ToU32MapInit(zT_735);
    async_layouts = zT_738;
    zT_740.cli = cli;
    zT_741 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_740.alloc = zT_741;
    zT_742 = (zT_D3EB6303_StringInterner*)&interner;
    zT_740.interner = zT_742;
    zT_743 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_740.diag = zT_743;
    zT_744 = (zT_227EDE07_SourceManager*)&source_man;
    zT_740.source_man = zT_744;
    zT_745 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_740.module_reg = zT_745;
    zT_746 = (zT_338B7C76_TypeRegistry*)&typereg;
    zT_740.typereg = zT_746;
    zT_747 = (zT_6B0A7D14_AstStore*)&store;
    zT_740.store = zT_747;
    zT_748 = (zT_3D7259E2_SymbolRegistry*)&symbol_reg;
    zT_740.symbol_reg = zT_748;
    zT_749 = (zT_8EED1867_ResolvedTypeTable*)&resolved_types;
    zT_740.resolved_types = zT_749;
    zT_750 = (zT_66E7D2EF_CoercionTable*)&coercion_table;
    zT_740.coercion_table = zT_750;
    zT_751 = (zT_4D61441E_DepGraph*)&dep_graph;
    zT_740.dep_graph = zT_751;
    zT_740.lir_slots = lir_slots;
    zT_752 = zF_E9CBFCA6_lirStreamInit();
    zT_740.lir_stream = zT_752;
    zT_740.enum_value_table = enum_value_table;
    zT_740.tuple_index_table = tuple_index_table;
    zT_740.error_code_registry = error_code_registry;
    zT_740.call_arg_types = call_arg_types;
    zT_740.call_param_map = call_param_map;
    zT_740.comptime_folds = comptime_folds;
    zT_740.const_inits = const_inits;
    zT_740.exported = exported;
    zT_740.suspending_fns = suspending_fns;
    zT_740.frame_sizes = frame_sizes;
    zT_740.state_widths = state_widths;
    zT_740.awaited_fns = awaited_fns;
    zT_740.async_hidden_fns = async_hidden_fns;
    zT_740.driver_targets = driver_targets;
    zT_740.parent_result_type_list = parent_result_type_list;
    zT_740.parent_result_start = parent_result_start;
    zT_740.parent_result_count = parent_result_count;
    zT_740.async_layouts = async_layouts;
    zT_740.emission_classif = emission_classif;
    zT_740.spell_plan = spell_plan_ph;
    zT_754 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_753 = &zT_754->emission;
    zT_756 = zF_EB0B1609_globalDeclArrayList(zT_753);
    zT_740.global_decls = zT_756;
    zT_758 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_757 = &zT_758->module;
    zT_760 = zF_986226E1_u64ToU32MapInit(zT_757);
    zT_740.module_init_deps = zT_760;
    zT_762 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_761 = &zT_762->emission;
    zT_764 = zF_8E537D0C_u32ArrayListInit(zT_761);
    zT_740.module_init_order = zT_764;
    zT_765 = zF_A1EED937_debugSpanStoreInit();
    zT_740.debug_spans = zT_765;
    zT_767 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_766 = &zT_767->emission;
    zT_769 = zF_5779AF56_debugSymbolListInit(zT_766);
    zT_740.debug_symbols = zT_769;
    zT_770 = zF_CCB1E6BF_debugMapWriterInit();
    zT_740.debug_map = zT_770;
    zT_772 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_771 = &zT_772->emission;
    zT_774 = zF_48A72C7F_debugSpanArrayListI(zT_771);
    zT_740.debug_span_buf = zT_774;
    ctx = zT_740;
    zT_775 = (zT_5AB29387_CompilerContext*)&ctx;
    zF_74055C03_runCompiler(zT_775);
    return;
    z_bb_135:
    zT_602 = rti2 + (unsigned int)(1);
    rti2 = zT_602;
    goto z_bb_132;
    z_bb_136:
    zT_594 = rsp_len < (unsigned int)(511);
    goto z_bb_138;
    z_bb_137:
    zT_594 = 0;
    goto z_bb_138;
    z_bb_138:
    if (zT_594) goto z_bb_133; else goto z_bb_134;
}

int main(int argc, char** argv) {
    zF_780653D2___module_init();
    zF_780653D2___module_init_1();
    zF_780653D2___module_init_2();
    zF_780653D2___module_init_3();
    zF_780653D2___module_init_4();
    zF_780653D2___module_init_5();
    zF_780653D2___module_init_6();
    zF_780653D2___module_init_7();
    zF_780653D2___module_init_8();
    zF_780653D2___module_init_9();
    zF_780653D2___module_init_10();
    zF_780653D2___module_init_11();
    zF_780653D2___module_init_12();
    zF_780653D2___module_init_13();
    zF_780653D2___module_init_14();
    zF_780653D2___module_init_15();
    zF_780653D2___module_init_16();
    zF_780653D2___module_init_17();
    zF_780653D2___module_init_18();
    zF_780653D2___module_init_19();
    zF_780653D2___module_init_20();
    zF_780653D2___module_init_21();
    zF_780653D2___module_init_22();
    zF_780653D2___module_init_23();
    zF_780653D2___module_init_24();
    zF_EA90E208_main(argc, (unsigned char**)argv);
    return 0;
}

/* runCompiler */
void zF_74055C03_runCompiler(zT_5AB29387_CompilerContext* ctx) {
    zT_5AB29387_CompilerContext* zT_1;
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5AB29387_CompilerContext* zT_24;
    zT_69057089_CompilerAlloc* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    zT_3D7259E2_SymbolRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_D3EB6303_StringInterner* zT_31;
    zT_A4CE86B7_U64ToU32Map* zT_32;
    zT_69057089_CompilerAlloc* zT_33;
    zT_5AB29387_CompilerContext* zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_69057089_CompilerAlloc* zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned char zT_55 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_59;
    zT_69057089_CompilerAlloc* zT_61;
    zT_5AB29387_CompilerContext* zT_63;
    zT_5AB29387_CompilerContext* zT_64;
    zT_5AB29387_CompilerContext* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    unsigned char zT_68 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    int zT_72;
    zT_5AB29387_CompilerContext* zT_74;
    zT_69057089_CompilerAlloc* zT_75;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned char zT_79 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_80;
    int zT_83;
    zT_5AB29387_CompilerContext* zT_85;
    zT_5AB29387_CompilerContext* zT_86;
    zT_5AB29387_CompilerContext* zT_87;
    zT_69057089_CompilerAlloc* zT_88;
    zT_F85C5DED_DiagnosticCollector* zT_90;
    unsigned char zT_92 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_93;
    int zT_96;
    zT_8EED1867_ResolvedTypeTable* zT_98;
    zT_3E40CD83_Sand* zT_100;
    zT_69057089_CompilerAlloc* zT_101;
    zT_5AB29387_CompilerContext* zT_103;
    zT_5AB29387_CompilerContext* zT_104;
    zT_69057089_CompilerAlloc* zT_105;
    zT_C98AF326_CompilerCli zT_107;
    unsigned char zT_108;
    unsigned char zT_109;
    zT_C98AF326_CompilerCli zT_110;
    unsigned char zT_112;
    zT_F85C5DED_DiagnosticCollector* zT_113;
    unsigned int zT_115 = 0;
    int zT_116;
    zT_F85C5DED_DiagnosticCollector* zT_118;
    int zT_121;
    zT_C98AF326_CompilerCli zT_123;
    unsigned char zT_124;
    zT_69057089_CompilerAlloc* zT_126;
    zT_3E40CD83_Sand zT_127;
    unsigned int zT_128;
    unsigned int zT_131;
    zT_69057089_CompilerAlloc* zT_133;
    zT_3E40CD83_Sand zT_134;
    unsigned int zT_135;
    unsigned int zT_138;
    zT_69057089_CompilerAlloc* zT_140;
    zT_3E40CD83_Sand zT_141;
    unsigned int zT_142;
    unsigned int zT_145;
    unsigned int zT_147 = 0;
    unsigned int zT_150;
    zT_338B7C76_TypeRegistry* zT_152;
    zT_3E40CD83_Sand* zT_153;
    unsigned int zT_154;
    unsigned int zT_157;
    unsigned int zT_160;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    unsigned char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    unsigned char* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190;
    unsigned char* zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    unsigned char* zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    zT_F85C5DED_DiagnosticCollector* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u z2;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3a;
    zT_8F083A69_Slice_zT_0B42B2F8_u z4;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2;
    unsigned int perm_kb;
    unsigned int mod_kb;
    unsigned int scr_kb;
    unsigned int pool_kb;
    unsigned int type_db_kb;
    unsigned int total;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3b;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3c;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg4;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg5;
    zT_1 = ctx;
    zF_E2BA93CE_phase_ImportResolut(zT_1);
    zT_3 = "2\n";
    zT_5 = 2;
    zT_4.ptr = (unsigned char*)zT_3;
    zT_4.len = zT_5;
    z2 = zT_4;
    zT_6 = z2;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_7 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_7);
    zT_10 = "3\n";
    zT_12 = 2;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    z3 = zT_11;
    zT_13 = z3;
    zF_48AC7B3A_markerWrite(zT_13);
    zT_15 = "3a\n";
    zT_17 = 3;
    zT_16.ptr = (unsigned char*)zT_15;
    zT_16.len = zT_17;
    z3a = zT_16;
    zT_18 = z3a;
    zF_48AC7B3A_markerWrite(zT_18);
    zT_20 = "4\n";
    zT_22 = 2;
    zT_21.ptr = (unsigned char*)zT_20;
    zT_21.len = zT_22;
    z4 = zT_21;
    zT_23 = z4;
    zF_48AC7B3A_markerWrite(zT_23);
    zT_24 = ctx;
    zF_945DEA54_phase_SymbolRegistr(zT_24);
    zT_25 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_25);
    zT_33 = ctx->alloc;
    zT_27 = &zT_33->module;
    zT_28 = ctx->store;
    zT_29 = ctx->symbol_reg;
    zT_30 = ctx->module_reg;
    zT_31 = ctx->interner;
    zT_32 = &ctx->suspending_fns;
    zF_790061E7_suspensionAnalysisR(zT_27, zT_28, zT_29, zT_30, zT_31, zT_32);
    zT_40 = ctx;
    zF_D3497187_phase_TypeResolutio(zT_40);
    zT_42 = "t1\n";
    zT_44 = 3;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    t1 = zT_43;
    zT_45 = t1;
    zF_48AC7B3A_markerWrite(zT_45);
    zT_46 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_46);
    zT_49 = "t2\n";
    zT_51 = 3;
    zT_50.ptr = (unsigned char*)zT_49;
    zT_50.len = zT_51;
    t2 = zT_50;
    zT_52 = t2;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_53 = ctx->diag;
    zT_55 = zF_8F770780_diagnosticCollector(zT_53);
    if (zT_55) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_56 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_56);
    zT_59 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_59));
    goto z_bb_2;
    z_bb_2:
    zT_61 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_61);
    zT_63 = ctx;
    zF_F862154A_phase_FrontResoluti(zT_63);
    zT_64 = ctx;
    zF_9609BF31_phase_ComptimeEvalu(zT_64);
    zT_65 = ctx;
    zF_0666ED4F_phase_SemanticAnaly(zT_65);
    zT_66 = ctx->diag;
    zT_68 = zF_8F770780_diagnosticCollector(zT_66);
    if (zT_68) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_69 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_69);
    zT_72 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_72));
    goto z_bb_4;
    z_bb_4:
    zT_74 = ctx;
    zF_F3B55B42_phase_StaticAnalyze(zT_74);
    zT_75 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_75);
    zT_77 = ctx->diag;
    zT_79 = zF_8F770780_diagnosticCollector(zT_77);
    if (zT_79) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_80 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_80);
    zT_83 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_83));
    goto z_bb_6;
    z_bb_6:
    zT_85 = ctx;
    zF_9BC6214D_phase_AsyncFrameSiz(zT_85);
    zT_86 = ctx;
    zF_A6065296_phase_ConstInit(zT_86);
    zT_87 = ctx;
    zF_1F21ABE7_phase_LIRLowering(zT_87);
    zT_88 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_88);
    zT_90 = ctx->diag;
    zT_92 = zF_8F770780_diagnosticCollector(zT_90);
    if (zT_92) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_93 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_93);
    zT_96 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_96));
    goto z_bb_8;
    z_bb_8:
    zT_98 = ctx->resolved_types;
    zF_5209815D_resolvedTypeTableCl(zT_98);
    zT_101 = ctx->alloc;
    zT_100 = &zT_101->module;
    zF_F1B3F8C2_sandReset(zT_100);
    zT_103 = ctx;
    zF_2682C512_phase_EmissionClass(zT_103);
    zT_104 = ctx;
    zF_2268F8CE_phase_C89Emission(zT_104);
    zT_105 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_105);
    zT_107 = ctx->cli;
    zT_108 = zT_107.warnings_as_errors;
    if (zT_108) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_110 = ctx->cli;
    zT_109 = zT_110.warn_error;
    goto z_bb_11;
    z_bb_10:
    zT_109 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_109) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_113 = ctx->diag;
    zT_115 = zF_4AF2092E_diagnosticCollector(zT_113);
    zT_116 = 0;
    zT_112 = zT_115 > (unsigned int)zT_116;
    goto z_bb_14;
    z_bb_13:
    zT_112 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_112) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_118 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_118);
    zT_121 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_121));
    goto z_bb_16;
    z_bb_16:
    zT_123 = ctx->cli;
    zT_124 = zT_123.track_memory;
    if (zT_124) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_126 = ctx->alloc;
    zT_127 = zT_126->permanent;
    zT_128 = zT_127.peak;
    zT_131 = (unsigned int)(unsigned int)(zT_128 / (unsigned int)(1024));
    perm_kb = zT_131;
    zT_133 = ctx->alloc;
    zT_134 = zT_133->module;
    zT_135 = zT_134.peak;
    zT_138 = (unsigned int)(unsigned int)(zT_135 / (unsigned int)(1024));
    mod_kb = zT_138;
    zT_140 = ctx->alloc;
    zT_141 = zT_140->scratch;
    zT_142 = zT_141.peak;
    zT_145 = (unsigned int)(unsigned int)(zT_142 / (unsigned int)(1024));
    scr_kb = zT_145;
    zT_147 = zF_E5D0D49C_poolPeak();
    zT_150 = (unsigned int)(unsigned int)(zT_147 / (unsigned int)(1024));
    pool_kb = zT_150;
    zT_152 = ctx->typereg;
    zT_153 = zT_152->types_alloc;
    zT_154 = zT_153->peak;
    zT_157 = (unsigned int)(unsigned int)(zT_154 / (unsigned int)(1024));
    type_db_kb = zT_157;
    zT_160 = (unsigned int)(perm_kb + mod_kb) + scr_kb;
    total = zT_160;
    zT_162 = "track-memory: perm=";
    zT_164 = 19;
    zT_163.ptr = (unsigned char*)zT_162;
    zT_163.len = zT_164;
    msg1 = zT_163;
    zT_165 = msg1;
    zF_B5478454_measureMarkerWrite(zT_165);
    zT_166 = perm_kb;
    zF_266B1B8E_writeU32(zT_166);
    zT_168 = "K mod=";
    zT_170 = 6;
    zT_169.ptr = (unsigned char*)zT_168;
    zT_169.len = zT_170;
    msg2 = zT_169;
    zT_171 = msg2;
    zF_B5478454_measureMarkerWrite(zT_171);
    zT_172 = mod_kb;
    zF_266B1B8E_writeU32(zT_172);
    zT_174 = "K scr=";
    zT_176 = 6;
    zT_175.ptr = (unsigned char*)zT_174;
    zT_175.len = zT_176;
    msg3 = zT_175;
    zT_177 = msg3;
    zF_B5478454_measureMarkerWrite(zT_177);
    zT_178 = scr_kb;
    zF_266B1B8E_writeU32(zT_178);
    zT_180 = "K pool=";
    zT_182 = 7;
    zT_181.ptr = (unsigned char*)zT_180;
    zT_181.len = zT_182;
    msg3b = zT_181;
    zT_183 = msg3b;
    zF_B5478454_measureMarkerWrite(zT_183);
    zT_184 = pool_kb;
    zF_266B1B8E_writeU32(zT_184);
    zT_186 = "K type_db=";
    zT_188 = 10;
    zT_187.ptr = (unsigned char*)zT_186;
    zT_187.len = zT_188;
    msg3c = zT_187;
    zT_189 = msg3c;
    zF_B5478454_measureMarkerWrite(zT_189);
    zT_190 = type_db_kb;
    zF_266B1B8E_writeU32(zT_190);
    zT_192 = "K total=";
    zT_194 = 8;
    zT_193.ptr = (unsigned char*)zT_192;
    zT_193.len = zT_194;
    msg4 = zT_193;
    zT_195 = msg4;
    zF_B5478454_measureMarkerWrite(zT_195);
    zT_196 = total;
    zF_266B1B8E_writeU32(zT_196);
    zT_198 = "K\n";
    zT_200 = 2;
    zT_199.ptr = (unsigned char*)zT_198;
    zT_199.len = zT_200;
    msg5 = zT_199;
    zT_201 = msg5;
    zF_B5478454_measureMarkerWrite(zT_201);
    goto z_bb_18;
    z_bb_18:
    zT_202 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_202);
    return;
}

/* astStoreHasPrintRef */
unsigned char zF_A42B6E3C_astStoreHasPrintRef(zT_6B0A7D14_AstStore* store, unsigned int print_id) {
    unsigned int zT_3;
    zT_BDEA985E_anon_318158 zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_8;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char zT_16;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24 = 0;
    unsigned int zT_28;
    unsigned int i;
    zT_22A7C88B_AstNode node;
    zT_3 = 0;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = store->nodes;
    zT_5 = zT_4.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = store;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, (unsigned int)((unsigned int)i));
    node = zT_11;
    zT_12 = node.kind;
    if ((unsigned char)(zT_12 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_28 = i + (unsigned int)(1);
    i = zT_28;
    goto z_bb_1;
    z_bb_5:
    zT_17 = node.kind;
    zT_16 = zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access);
    goto z_bb_7;
    z_bb_6:
    zT_16 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_16) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_21 = store;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, (unsigned int)((unsigned int)i));
    if ((unsigned char)(zT_24 == print_id)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    goto z_bb_4;
}

/* phase_ImportResolution */
void zF_E2BA93CE_phase_ImportResolut(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_C98AF326_CompilerCli zT_12;
    unsigned int zT_13;
    zT_4DB1475B_ModuleResolver* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_072B53A6_ModuleRegistry* zT_17;
    zT_C98AF326_CompilerCli zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    unsigned int zT_25;
    zT_846744CC_Arr_unsigned_char_5 zT_27;
    unsigned char* zT_29;
    int zT_31;
    unsigned char* zT_32;
    int zT_34 = 0;
    int zT_35;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char zT_46 = 0;
    zT_4DB1475B_ModuleResolver* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_072B53A6_ModuleRegistry* zT_49;
    zT_846744CC_Arr_unsigned_char_5 zT_52;
    zT_C98AF326_CompilerCli zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_C98AF326_CompilerCli zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_59;
    int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_C98AF326_CompilerCli zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_70;
    int zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_C98AF326_CompilerCli zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    zT_662E24C2_Opt_250 zT_77 = {0};
    unsigned char zT_78;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_84 = 0;
    zT_072B53A6_ModuleRegistry* zT_86;
    unsigned int zT_87;
    unsigned int zT_89 = 0;
    zT_47A5CDFB_ImportQueue* zT_90;
    unsigned int zT_91;
    zT_072B53A6_ModuleRegistry* zT_92;
    zT_072B53A6_ModuleRegistry* zT_94;
    zT_3E40CD83_Sand* zT_95;
    zT_3E40CD83_Sand* zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    zT_69057089_CompilerAlloc* zT_99;
    zT_69057089_CompilerAlloc* zT_101;
    zT_D3EB6303_StringInterner* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    unsigned int zT_111 = 0;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned char zT_115 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_4DB1475B_ModuleResolver* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_3E40CD83_Sand* zT_123;
    zT_072B53A6_ModuleRegistry* zT_124;
    zT_69057089_CompilerAlloc* zT_126;
    zT_BAEE192E_Opt_10 zT_128 = {0};
    unsigned char zT_129;
    zT_D3EB6303_StringInterner* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_134 = 0;
    zT_072B53A6_ModuleRegistry* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_3E40CD83_Sand* zT_138;
    zT_69057089_CompilerAlloc* zT_140;
    zT_BAEE192E_Opt_10 zT_142 = {0};
    zT_072B53A6_ModuleRegistry* zT_143;
    zT_3E40CD83_Sand* zT_144;
    zT_3E40CD83_Sand* zT_145;
    zT_6B0A7D14_AstStore* zT_146;
    zT_69057089_CompilerAlloc* zT_148;
    zT_69057089_CompilerAlloc* zT_150;
    zT_846744CC_Arr_unsigned_char_5 zT_154;
    unsigned int zT_156;
    zT_C98AF326_CompilerCli zT_157;
    unsigned char zT_158;
    zT_C98AF326_CompilerCli zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_163;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned char* zT_170;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned int zT_175;
    unsigned char zT_176;
    unsigned int zT_178;
    unsigned char zT_179;
    unsigned int zT_181;
    unsigned char zT_182;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_192;
    unsigned char zT_194;
    unsigned char* zT_197;
    unsigned char zT_198;
    unsigned int zT_200;
    unsigned int zT_202;
    zT_072B53A6_ModuleRegistry* zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    int zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    unsigned int si;
    zT_846744CC_Arr_unsigned_char_5 lib_buf;
    int lib_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_path;
    zT_846744CC_Arr_unsigned_char_5 root_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u root_path;
    zT_662E24C2_Opt_250 norm;
    unsigned int path_id;
    unsigned int mod_id;
    unsigned int print_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_name;
    zT_846744CC_Arr_unsigned_char_5 hash_spill_path;
    unsigned int hsp_len;
    unsigned int fmt_path_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hash_tmp_name;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u z_msg;
    zT_2 = "I\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    si = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_12 = ctx->cli;
    zT_13 = zT_12.include_count;
    if ((unsigned char)(si < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = ctx->module_reg;
    zT_15 = &zT_17->resolver;
    zT_19 = ctx->cli;
    zT_20 = zT_19.include_dirs;
    zT_21 = (unsigned int)si;
    zT_22 = zT_20[zT_21];
    zT_16 = zT_22;
    zF_B75A4515_moduleResolverAddSe(zT_15, zT_16);
    goto z_bb_4;
    z_bb_3:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_27[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        lib_buf[_i] = zT_27[_i];
        _i++;
    }
}
    zT_31 = 0;
    zT_32 = lib_buf + zT_31;
    zT_29 = zT_32;
    zT_34 = zF_BEB0BFA8_getDefaultLibPath(zT_29, (int)(512));
    lib_len = zT_34;
    zT_35 = 0;
    if ((unsigned char)(lib_len > zT_35)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_25 = si + (unsigned int)((unsigned int)zT_23);
    si = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_41 = 0;
    zT_42 = (unsigned char*)((unsigned char*)lib_buf) + zT_41;
    zT_43 = (unsigned int)((unsigned int)lib_len) - zT_41;
    zT_44.ptr = (unsigned char*)zT_42;
    zT_44.len = zT_43;
    lib_path = zT_44;
    zT_45 = lib_path;
    zT_46 = zF_8CC05F84_dirExists(zT_45);
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        root_buf[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = ctx->cli;
    zT_55 = zT_54.input_file;
    root_path = zT_55;
    zT_56 = ctx->cli;
    zT_57 = zT_56.input_file;
    zT_59 = zT_57.len;
    zT_60 = 512;
    if ((unsigned char)(zT_59 <= (unsigned int)zT_60)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_49 = ctx->module_reg;
    zT_47 = &zT_49->resolver;
    zT_48 = lib_path;
    zF_B75A4515_moduleResolverAddSe(zT_47, zT_48);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_67 = ctx->cli;
    zT_68 = zT_67.input_file;
    zT_70 = zT_68.len;
    zT_71 = 0;
    zT_72 = (unsigned char*)((unsigned char*)root_buf) + zT_71;
    zT_73 = zT_70 - zT_71;
    zT_74.ptr = (unsigned char*)zT_72;
    zT_74.len = zT_73;
    zT_63 = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.input_file;
    zT_64 = zT_76;
    zT_77 = zF_36F0DB6B_normalizePath(zT_63, zT_64);
    norm = zT_77;
    zT_78 = norm.has_value;
    if (zT_78) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_81 = ctx->interner;
    zT_82 = root_path;
    zT_84 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    path_id = zT_84;
    zT_86 = ctx->module_reg;
    zT_87 = path_id;
    zT_89 = zF_E4DCE20D_moduleRegistryAddMo(zT_86, zT_87);
    mod_id = zT_89;
    zT_92 = ctx->module_reg;
    zT_90 = &zT_92->import_queue;
    zT_91 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_90, zT_91);
    zT_94 = ctx->module_reg;
    zT_99 = ctx->alloc;
    zT_95 = &zT_99->module;
    zT_101 = ctx->alloc;
    zT_96 = &zT_101->scratch;
    zT_97 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_94, zT_95, zT_96, zT_97);
    zT_105 = ctx->interner;
    zT_108 = "print";
    zT_110 = 5;
    zT_109.ptr = (unsigned char*)zT_108;
    zT_109.len = zT_110;
    zT_106 = zT_109;
    zT_111 = zF_50C274AF_stringInternerInter(zT_105, zT_106);
    print_name_id = zT_111;
    zT_112 = ctx->store;
    zT_113 = print_name_id;
    zT_115 = zF_A42B6E3C_astStoreHasPrintRef(zT_112, zT_113);
    if (zT_115) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    n = norm.value;
    root_path = n;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_117 = "std_fmt.zig";
    zT_119 = 11;
    zT_118.ptr = (unsigned char*)zT_117;
    zT_118.len = zT_119;
    fmt_name = zT_118;
    zT_124 = ctx->module_reg;
    zT_120 = &zT_124->resolver;
    zT_121 = root_path;
    zT_122 = fmt_name;
    zT_126 = ctx->alloc;
    zT_123 = &zT_126->scratch;
    zT_128 = zF_6F148E15_moduleResolverResol(zT_120, zT_121, zT_122, zT_123);
    zT_129 = zT_128.has_value;
    if (zT_129) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_154[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hash_spill_path[_i] = zT_154[_i];
        _i++;
    }
}
    zT_156 = 0;
    hsp_len = zT_156;
    zT_157 = ctx->cli;
    zT_158 = zT_157.output_dir_set;
    if (zT_158) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    zT_131 = ctx->interner;
    zT_132 = fmt_name;
    zT_134 = zF_50C274AF_stringInternerInter(zT_131, zT_132);
    fmt_path_id = zT_134;
    zT_135 = ctx->module_reg;
    zT_136 = fmt_path_id;
    zT_137 = mod_id;
    zT_140 = ctx->alloc;
    zT_138 = &zT_140->scratch;
    zT_142 = zF_620E3E3B_moduleRegistryResol(zT_135, zT_136, zT_137, zT_138);
    (void)zT_142;
    zT_143 = ctx->module_reg;
    zT_148 = ctx->alloc;
    zT_144 = &zT_148->module;
    zT_150 = ctx->alloc;
    zT_145 = &zT_150->scratch;
    zT_146 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_143, zT_144, zT_145, zT_146);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_160 = ctx->cli;
    zT_161 = zT_160.output_dir;
    od = zT_161;
    zT_163 = 0;
    oi = zT_163;
    goto z_bb_20;
    z_bb_18:
    zT_186 = ".zig1_hash.tmp";
    zT_188 = 14;
    zT_187.ptr = (unsigned char*)zT_186;
    zT_187.len = zT_188;
    hash_tmp_name = zT_187;
    zT_190 = 0;
    hi = zT_190;
    goto z_bb_27;
    z_bb_19:
    zT_179 = 46;
    hash_spill_path[hsp_len] = zT_179;
    zT_181 = hsp_len + (unsigned int)(1);
    hsp_len = zT_181;
    zT_182 = 47;
    hash_spill_path[hsp_len] = zT_182;
    zT_184 = hsp_len + (unsigned int)(1);
    hsp_len = zT_184;
    goto z_bb_18;
    z_bb_20:
    zT_165 = od.len;
    if ((unsigned char)(oi < zT_165)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_170 = od.ptr;
    zT_171 = zT_170[oi];
    hash_spill_path[hsp_len] = zT_171;
    zT_173 = hsp_len + (unsigned int)(1);
    hsp_len = zT_173;
    goto z_bb_23;
    z_bb_22:
    zT_176 = 47;
    hash_spill_path[hsp_len] = zT_176;
    zT_178 = hsp_len + (unsigned int)(1);
    hsp_len = zT_178;
    goto z_bb_18;
    z_bb_23:
    zT_175 = oi + (unsigned int)(1);
    oi = zT_175;
    goto z_bb_20;
    z_bb_24:
    zT_167 = hsp_len < (unsigned int)(511);
    goto z_bb_26;
    z_bb_25:
    zT_167 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_167) goto z_bb_21; else goto z_bb_22;
    z_bb_27:
    zT_192 = hash_tmp_name.len;
    if ((unsigned char)(hi < zT_192)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_197 = hash_tmp_name.ptr;
    zT_198 = zT_197[hi];
    hash_spill_path[hsp_len] = zT_198;
    zT_200 = hsp_len + (unsigned int)(1);
    hsp_len = zT_200;
    goto z_bb_30;
    z_bb_29:
    zT_203 = ctx->module_reg;
    zT_208 = 0;
    zT_209 = (unsigned char*)((unsigned char*)hash_spill_path) + zT_208;
    zT_210 = hsp_len - zT_208;
    zT_211.ptr = (unsigned char*)zT_209;
    zT_211.len = zT_210;
    zT_204 = zT_211;
    zF_8767909B_moduleRegistrySpill(zT_203, zT_204);
    zT_213 = "Z\n";
    zT_215 = 2;
    zT_214.ptr = (unsigned char*)zT_213;
    zT_214.len = zT_215;
    z_msg = zT_214;
    zT_216 = z_msg;
    zF_48AC7B3A_markerWrite(zT_216);
    return;
    z_bb_30:
    zT_202 = hi + (unsigned int)(1);
    hi = zT_202;
    goto z_bb_27;
    z_bb_31:
    zT_194 = hsp_len < (unsigned int)(511);
    goto z_bb_33;
    z_bb_32:
    zT_194 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_194) goto z_bb_28; else goto z_bb_29;
}

/* phase_SymbolRegistration */
void zF_945DEA54_phase_SymbolRegistr(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_11;
    zT_4D61441E_DepGraph zT_13 = {0};
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_072B53A6_ModuleRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_4D61441E_DepGraph* zT_29;
    zT_6E8D187B_ModuleEntry* zT_35;
    zT_6E8D187B_ModuleEntry zT_36;
    int zT_40;
    unsigned int zT_42;
    zT_072B53A6_ModuleRegistry* zT_44;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_46 = {0};
    unsigned int zT_48;
    unsigned char zT_51;
    zT_6E8D187B_ModuleEntry* zT_52;
    int zT_53;
    zT_6E8D187B_ModuleEntry zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    zT_6E8D187B_ModuleEntry* zT_62;
    int zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    zT_22A7C88B_AstNode zT_66 = {0};
    zT_8143F551_AstKind zT_67;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_6E8D187B_ModuleEntry* zT_75;
    int zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_79 = 0;
    unsigned int zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_97;
    int zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_102 = 0;
    zT_22A7C88B_AstNode zT_103 = {0};
    zT_8143F551_AstKind zT_105;
    unsigned int zT_106;
    zT_4028D896_Arr_unsigned_char_2 zT_108;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    int zT_114;
    unsigned char* zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118 = 0;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned char* zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_136;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_DDCD424B_Slice_zT_6E8D187B_M smods;
    zT_22A7C88B_AstNode sr;
    unsigned int sdl_n;
    unsigned int sdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl;
    zT_22A7C88B_AstNode sd;
    unsigned int sk;
    zT_4028D896_Arr_unsigned_char_2 sb;
    unsigned int slen;
    unsigned int sst;
    zT_8F083A69_Slice_zT_0B42B2F8_u ssp;
    zT_8F083A69_Slice_zT_0B42B2F8_u sn;
    zT_2 = "S\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->alloc;
    zT_10 = &zT_11->scratch;
    zT_13 = zF_7F194604_depGraphInit(zT_10);
    dep_graph = zT_13;
    zT_15 = ctx->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_22 = mods.len;
    if ((unsigned char)(mi < zT_22)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_24 = ctx->module_reg;
    zT_25 = ctx->symbol_reg;
    zT_26 = ctx->typereg;
    zT_27 = ctx->store;
    zT_35 = mods.ptr;
    zT_36 = zT_35[mi];
    zT_28 = zT_36.id;
    zT_29 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_24, zT_25, zT_26, zT_27, zT_28, zT_29, (unsigned char)(1));
    goto z_bb_4;
    z_bb_3:
    zT_44 = ctx->module_reg;
    zT_46 = zF_3452C137_moduleRegistryGetMo(zT_44);
    smods = zT_46;
    zT_48 = smods.len;
    if ((unsigned char)(zT_48 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_40 = 1;
    zT_42 = mi + (unsigned int)((unsigned int)zT_40);
    mi = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_52 = smods.ptr;
    zT_53 = 0;
    zT_54 = zT_52[zT_53];
    zT_55 = zT_54.ast_root;
    zT_51 = zT_55 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_51 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_51) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_59 = ctx->store;
    zT_62 = smods.ptr;
    zT_63 = 0;
    zT_64 = zT_62[zT_63];
    zT_60 = zT_64.ast_root;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_59, zT_60);
    sr = zT_66;
    zT_67 = sr.kind;
    if ((unsigned char)(zT_67 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_72 = ctx->store;
    zT_75 = smods.ptr;
    zT_76 = 0;
    zT_77 = zT_75[zT_76];
    zT_73 = zT_77.ast_root;
    zT_79 = zF_152E19CB_astStoreNodeExtraCh(zT_72, zT_73);
    sdl_n = zT_79;
    zT_81 = 0;
    sdi = zT_81;
    zT_83 = "S0";
    zT_85 = 2;
    zT_84.ptr = (unsigned char*)zT_83;
    zT_84.len = zT_85;
    sl = zT_84;
    zT_86 = sl;
    zF_48AC7B3A_markerWrite(zT_86);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(sdi < (unsigned int)((unsigned int)sdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_90 = ctx->store;
    zT_93 = ctx->store;
    zT_97 = smods.ptr;
    zT_98 = 0;
    zT_99 = zT_97[zT_98];
    zT_94 = zT_99.ast_root;
    zT_102 = zF_B10B1BC1_astStoreNodeExtraCh(zT_93, zT_94, (unsigned int)((unsigned int)sdi));
    zT_91 = zT_102;
    zT_103 = zF_FCDD1D35_astStoreNodeAt(zT_90, zT_91);
    sd = zT_103;
    zT_105 = sd.kind;
    zT_106 = (unsigned int)zT_105;
    sk = zT_106;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_108[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sb[_i] = zT_108[_i];
        _i++;
    }
}
    zT_110 = sk;
    zT_114 = 0;
    zT_115 = (unsigned char*)((unsigned char*)sb) + zT_114;
    zT_116 = (unsigned int)(20) - zT_114;
    zT_117.ptr = (unsigned char*)zT_115;
    zT_117.len = zT_116;
    zT_111 = zT_117;
    zT_118 = zF_A7504564_itoa(zT_110, zT_111);
    slen = zT_118;
    zT_122 = (unsigned int)(19) - (unsigned int)((unsigned int)slen);
    sst = zT_122;
    zT_127 = (unsigned char*)((unsigned char*)sb) + sst;
    zT_128 = (unsigned int)(19) - sst;
    zT_129.ptr = (unsigned char*)zT_127;
    zT_129.len = zT_128;
    zT_123 = zT_129;
    zF_48AC7B3A_markerWrite(zT_123);
    zT_131 = " ";
    zT_133 = 1;
    zT_132.ptr = (unsigned char*)zT_131;
    zT_132.len = zT_133;
    ssp = zT_132;
    zT_134 = ssp;
    zF_48AC7B3A_markerWrite(zT_134);
    goto z_bb_15;
    z_bb_14:
    zT_138 = "\n";
    zT_140 = 1;
    zT_139.ptr = (unsigned char*)zT_138;
    zT_139.len = zT_140;
    sn = zT_139;
    zT_141 = sn;
    zF_48AC7B3A_markerWrite(zT_141);
    goto z_bb_11;
    z_bb_15:
    zT_136 = sdi + (unsigned int)(1);
    sdi = zT_136;
    goto z_bb_12;
}

/* phase_TypeResolution */
void zF_D3497187_phase_TypeResolutio(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_BDEA985E_anon_318158 zT_10;
    zT_3E40CD83_Sand* zT_12;
    zT_69057089_CompilerAlloc* zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_69057089_CompilerAlloc* zT_17;
    zT_4D61441E_DepGraph zT_19 = {0};
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_3D7259E2_SymbolRegistry* zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_4D61441E_DepGraph* zT_35;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    int zT_46;
    unsigned int zT_48;
    zT_3D7259E2_SymbolRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_D3EB6303_StringInterner* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    zT_3E40CD83_Sand* zT_53;
    zT_69057089_CompilerAlloc* zT_58;
    zT_6B0A7D14_AstStore* zT_60;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_3D7259E2_SymbolRegistry* zT_62;
    zT_D3EB6303_StringInterner* zT_63;
    zT_8EED1867_ResolvedTypeTable* zT_64;
    zT_072B53A6_ModuleRegistry* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_69057089_CompilerAlloc* zT_75;
    zT_338B7C76_TypeRegistry* zT_78;
    zT_F85C5DED_DiagnosticCollector* zT_79;
    zT_3E40CD83_Sand* zT_80;
    zT_69057089_CompilerAlloc* zT_83;
    zT_C890C8CB_TypeResolver zT_85 = {0};
    zT_C890C8CB_TypeResolver* zT_86;
    zT_C890C8CB_TypeResolver* zT_88;
    zT_4D61441E_DepGraph* zT_89;
    zT_C890C8CB_TypeResolver* zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_3D7259E2_SymbolRegistry* zT_96;
    zT_D3EB6303_StringInterner* zT_97;
    zT_072B53A6_ModuleRegistry* zT_98;
    zT_F85C5DED_DiagnosticCollector* zT_99;
    zT_C890C8CB_TypeResolver* zT_106;
    zT_786E6CF2_EmissionClassificat* zT_107;
    zT_3E40CD83_Sand* zT_108;
    zT_69057089_CompilerAlloc* zT_111;
    unsigned int zT_114;
    unsigned char zT_117;
    zT_6E8D187B_ModuleEntry* zT_118;
    int zT_119;
    zT_6E8D187B_ModuleEntry zT_120;
    unsigned int zT_121;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    zT_6E8D187B_ModuleEntry* zT_128;
    int zT_129;
    zT_6E8D187B_ModuleEntry zT_130;
    zT_22A7C88B_AstNode zT_132 = {0};
    zT_8143F551_AstKind zT_133;
    zT_6B0A7D14_AstStore* zT_138;
    unsigned int zT_139;
    zT_6E8D187B_ModuleEntry* zT_141;
    int zT_142;
    zT_6E8D187B_ModuleEntry zT_143;
    unsigned int zT_145 = 0;
    unsigned int zT_147;
    unsigned char* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_159;
    unsigned int zT_160;
    zT_6E8D187B_ModuleEntry* zT_163;
    int zT_164;
    zT_6E8D187B_ModuleEntry zT_165;
    unsigned int zT_168 = 0;
    zT_22A7C88B_AstNode zT_169 = {0};
    zT_8143F551_AstKind zT_171;
    unsigned int zT_172;
    zT_4028D896_Arr_unsigned_char_2 zT_174;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    int zT_180;
    unsigned char* zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184 = 0;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned char* zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned char* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_202;
    unsigned char* zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_C890C8CB_TypeResolver tr;
    zT_22A7C88B_AstNode tr2;
    unsigned int tdl_n;
    unsigned int tdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tl;
    zT_22A7C88B_AstNode td;
    unsigned int tk;
    zT_4028D896_Arr_unsigned_char_2 tb;
    unsigned int tlen;
    unsigned int tst;
    zT_8F083A69_Slice_zT_0B42B2F8_u tsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tn;
    zT_2 = "T\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->resolved_types;
    zT_9 = ctx->store;
    zT_10 = zT_9->nodes;
    zT_7 = zT_10.len;
    zF_75224871_resolvedTypeTableRe(zT_6, zT_7);
    zT_13 = ctx->alloc;
    zT_12 = &zT_13->scratch;
    zF_F1B3F8C2_sandReset(zT_12);
    zT_17 = ctx->alloc;
    zT_16 = &zT_17->scratch;
    zT_19 = zF_7F194604_depGraphInit(zT_16);
    dep_graph = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    mi = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_28 = mods.len;
    if ((unsigned char)(mi < zT_28)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_30 = ctx->module_reg;
    zT_31 = ctx->symbol_reg;
    zT_32 = ctx->typereg;
    zT_33 = ctx->store;
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_34 = zT_42.id;
    zT_35 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_30, zT_31, zT_32, zT_33, zT_34, zT_35, (unsigned char)(0));
    goto z_bb_4;
    z_bb_3:
    zT_49 = ctx->symbol_reg;
    zT_50 = ctx->typereg;
    zT_51 = ctx->interner;
    zT_52 = ctx->store;
    zT_58 = ctx->alloc;
    zT_53 = &zT_58->permanent;
    zF_EF7F7D3C_constAliasPrepass(zT_49, zT_50, zT_51, zT_52, zT_53);
    zT_60 = ctx->store;
    zT_61 = ctx->typereg;
    zT_62 = ctx->symbol_reg;
    zT_63 = ctx->interner;
    zT_64 = ctx->resolved_types;
    zT_65 = ctx->module_reg;
    zT_66 = ctx->diag;
    zT_75 = ctx->alloc;
    zT_67 = &zT_75->permanent;
    zF_373A7BEF_typeResolverResolve(zT_60, zT_61, zT_62, zT_63, zT_64, zT_65, zT_66, zT_67);
    zT_78 = ctx->typereg;
    zT_79 = ctx->diag;
    zT_83 = ctx->alloc;
    zT_80 = &zT_83->scratch;
    zT_85 = zF_5BFAC855_typeResolverInit(zT_78, zT_79, zT_80);
    tr = zT_85;
    zT_86 = (zT_C890C8CB_TypeResolver*)&tr;
    zF_D5C4530C_typeResolverBuildDe(zT_86);
    zT_88 = (zT_C890C8CB_TypeResolver*)&tr;
    zT_89 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_33272F41_typeResolverBuild(zT_88, zT_89);
    zT_92 = (zT_C890C8CB_TypeResolver*)&tr;
    zF_30BE7185_typeResolverResolve(zT_92);
    zT_94 = ctx->store;
    zT_95 = ctx->typereg;
    zT_96 = ctx->symbol_reg;
    zT_97 = ctx->interner;
    zT_98 = ctx->module_reg;
    zT_99 = ctx->diag;
    zF_153D24FD_enumReevaluateAll(zT_94, zT_95, zT_96, zT_97, zT_98, zT_99);
    zT_106 = (zT_C890C8CB_TypeResolver*)&tr;
    zT_107 = &ctx->emission_classif;
    zT_111 = ctx->alloc;
    zT_108 = &zT_111->permanent;
    zF_ACC002C8_classifyTypeEmissio(zT_106, zT_107, zT_108);
    zT_114 = mods.len;
    if ((unsigned char)(zT_114 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_46 = 1;
    zT_48 = mi + (unsigned int)((unsigned int)zT_46);
    mi = zT_48;
    goto z_bb_1;
    z_bb_5:
    zT_118 = mods.ptr;
    zT_119 = 0;
    zT_120 = zT_118[zT_119];
    zT_121 = zT_120.ast_root;
    zT_117 = zT_121 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_117 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_117) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_125 = ctx->store;
    zT_128 = mods.ptr;
    zT_129 = 0;
    zT_130 = zT_128[zT_129];
    zT_126 = zT_130.ast_root;
    zT_132 = zF_FCDD1D35_astStoreNodeAt(zT_125, zT_126);
    tr2 = zT_132;
    zT_133 = tr2.kind;
    if ((unsigned char)(zT_133 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_138 = ctx->store;
    zT_141 = mods.ptr;
    zT_142 = 0;
    zT_143 = zT_141[zT_142];
    zT_139 = zT_143.ast_root;
    zT_145 = zF_152E19CB_astStoreNodeExtraCh(zT_138, zT_139);
    tdl_n = zT_145;
    zT_147 = 0;
    tdi = zT_147;
    zT_149 = "T0";
    zT_151 = 2;
    zT_150.ptr = (unsigned char*)zT_149;
    zT_150.len = zT_151;
    tl = zT_150;
    zT_152 = tl;
    zF_48AC7B3A_markerWrite(zT_152);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(tdi < (unsigned int)((unsigned int)tdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_156 = ctx->store;
    zT_159 = ctx->store;
    zT_163 = mods.ptr;
    zT_164 = 0;
    zT_165 = zT_163[zT_164];
    zT_160 = zT_165.ast_root;
    zT_168 = zF_B10B1BC1_astStoreNodeExtraCh(zT_159, zT_160, (unsigned int)((unsigned int)tdi));
    zT_157 = zT_168;
    zT_169 = zF_FCDD1D35_astStoreNodeAt(zT_156, zT_157);
    td = zT_169;
    zT_171 = td.kind;
    zT_172 = (unsigned int)zT_171;
    tk = zT_172;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_174[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        tb[_i] = zT_174[_i];
        _i++;
    }
}
    zT_176 = tk;
    zT_180 = 0;
    zT_181 = (unsigned char*)((unsigned char*)tb) + zT_180;
    zT_182 = (unsigned int)(20) - zT_180;
    zT_183.ptr = (unsigned char*)zT_181;
    zT_183.len = zT_182;
    zT_177 = zT_183;
    zT_184 = zF_A7504564_itoa(zT_176, zT_177);
    tlen = zT_184;
    zT_188 = (unsigned int)(19) - (unsigned int)((unsigned int)tlen);
    tst = zT_188;
    zT_193 = (unsigned char*)((unsigned char*)tb) + tst;
    zT_194 = (unsigned int)(19) - tst;
    zT_195.ptr = (unsigned char*)zT_193;
    zT_195.len = zT_194;
    zT_189 = zT_195;
    zF_48AC7B3A_markerWrite(zT_189);
    zT_197 = " ";
    zT_199 = 1;
    zT_198.ptr = (unsigned char*)zT_197;
    zT_198.len = zT_199;
    tsp = zT_198;
    zT_200 = tsp;
    zF_48AC7B3A_markerWrite(zT_200);
    goto z_bb_15;
    z_bb_14:
    zT_204 = "\n";
    zT_206 = 1;
    zT_205.ptr = (unsigned char*)zT_204;
    zT_205.len = zT_206;
    tn = zT_205;
    zT_207 = tn;
    zF_48AC7B3A_markerWrite(zT_207);
    goto z_bb_11;
    z_bb_15:
    zT_202 = tdi + (unsigned int)(1);
    tdi = zT_202;
    goto z_bb_12;
}

/* phase_FrontResolution */
void zF_F862154A_phase_FrontResoluti(zT_5AB29387_CompilerContext* ctx) {
    zT_6DCFC8DB_FrontResCtx zT_2;
    zT_6B0A7D14_AstStore* zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_3E40CD83_Sand* zT_11;
    zT_66E7D2EF_CoercionTable* zT_12;
    zT_21D3708C_U32ToU32Map* zT_13;
    zT_21D3708C_U32ToU32Map* zT_14;
    zT_21D3708C_U32ToU32Map* zT_15;
    zT_21D3708C_U32ToU32Map* zT_16;
    zT_21D3708C_U32ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_19;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_3 = ctx->store;
    zT_2.store = zT_3;
    zT_4 = ctx->typereg;
    zT_2.typereg = zT_4;
    zT_5 = ctx->symbol_reg;
    zT_2.symbol_reg = zT_5;
    zT_6 = ctx->resolved_types;
    zT_2.resolved_types = zT_6;
    zT_7 = ctx->module_reg;
    zT_2.module_reg = zT_7;
    zT_8 = ctx->interner;
    zT_2.interner = zT_8;
    zT_9 = ctx->diag;
    zT_2.diag = zT_9;
    zT_10 = ctx->alloc;
    zT_11 = &zT_10->scratch;
    zT_2.scratch = zT_11;
    zT_12 = ctx->coercion_table;
    zT_2.coercion_table = zT_12;
    zT_13 = &ctx->enum_value_table;
    zT_2.enum_value_table = zT_13;
    zT_14 = &ctx->tuple_index_table;
    zT_2.tuple_index_table = zT_14;
    zT_15 = &ctx->error_code_registry;
    zT_2.error_code_registry = zT_15;
    zT_16 = &ctx->call_arg_types;
    zT_2.call_arg_types = zT_16;
    zT_17 = &ctx->call_param_map;
    zT_2.call_param_map = zT_17;
    zT_18 = &ctx->suspending_fns;
    zT_2.suspending_fns = zT_18;
    frc = zT_2;
    zT_19 = (zT_6DCFC8DB_FrontResCtx*)&frc;
    zF_8A0E7747_frontResolveModuleI(zT_19);
    return;
}

/* phase_ComptimeEvaluation */
void zF_9609BF31_phase_ComptimeEvalu(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15 = {0};
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_622E1E76_Opt_254 zT_19;
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    zT_BDEA985E_anon_318158 zT_28;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_39;
    zT_6E8D187B_ModuleEntry* zT_42;
    zT_6E8D187B_ModuleEntry zT_43;
    unsigned int zT_44;
    unsigned char zT_49;
    zT_6E8D187B_ModuleEntry* zT_51;
    zT_6E8D187B_ModuleEntry zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_58;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_8143F551_AstKind zT_63;
    zT_DA663F79_ComptimeEval* zT_68;
    zT_7534F824_Opt_223 zT_72 = {0};
    unsigned char zT_73;
    zT_77F6F59C_ComptimeFoldTable* zT_75;
    zT_89B1DDDA_ComptimeVal zT_77;
    zT_8143F551_AstKind zT_80;
    unsigned char zT_84;
    unsigned int zT_85;
    int zT_86;
    unsigned char zT_88;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_100;
    unsigned int zT_101;
    unsigned char zT_104;
    unsigned char zT_107;
    unsigned char zT_110;
    zT_DA663F79_ComptimeEval* zT_114;
    unsigned int zT_115;
    zT_7534F824_Opt_223 zT_118 = {0};
    unsigned char zT_119;
    zT_77F6F59C_ComptimeFoldTable* zT_121;
    unsigned int zT_122;
    zT_89B1DDDA_ComptimeVal zT_123;
    zT_8143F551_AstKind zT_126;
    unsigned char zT_130;
    zT_8143F551_AstKind zT_131;
    zT_6B0A7D14_AstStore* zT_135;
    unsigned int zT_139 = 0;
    zT_DA663F79_ComptimeEval* zT_143;
    unsigned int zT_144;
    zT_7534F824_Opt_223 zT_147 = {0};
    unsigned char zT_148;
    unsigned char zT_150;
    zT_77F6F59C_ComptimeFoldTable* zT_153;
    unsigned int zT_154;
    zT_89B1DDDA_ComptimeVal zT_155;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_m;
    zT_DA663F79_ComptimeEval ce;
    zT_DDCD424B_Slice_zT_6E8D187B_M p7_mods;
    unsigned int ni;
    unsigned int p7_best_root;
    unsigned int p7_best_id;
    unsigned int p7_si;
    unsigned int p7_r;
    zT_22A7C88B_AstNode node;
    zT_7534F824_Opt_223 val;
    zT_89B1DDDA_ComptimeVal v;
    zT_22A7C88B_AstNode init_n;
    unsigned int ik;
    zT_7534F824_Opt_223 val2;
    zT_89B1DDDA_ComptimeVal v2;
    zT_7534F824_Opt_223 cval;
    zT_89B1DDDA_ComptimeVal cv;
    zT_2 = "CE\n";
    zT_4 = 3;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    pc_m = zT_3;
    zT_5 = pc_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ce.diag = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    p7_mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    ni = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_27 = ctx->store;
    zT_28 = zT_27->nodes;
    zT_29 = zT_28.len;
    if ((unsigned char)(ni < zT_29)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_32 = 4294967295u;
    p7_best_root = zT_32;
    zT_34 = 4294967295u;
    p7_best_id = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    p7_si = zT_37;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    zT_159 = ni + (unsigned int)(1);
    ni = zT_159;
    goto z_bb_1;
    z_bb_5:
    zT_39 = p7_mods.len;
    if ((unsigned char)(p7_si < zT_39)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_42 = p7_mods.ptr;
    zT_43 = zT_42[p7_si];
    zT_44 = zT_43.ast_root;
    p7_r = zT_44;
    if ((unsigned char)(p7_r == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    ce.module_id = p7_best_id;
    zT_58 = ctx->store;
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_58, (unsigned int)((unsigned int)ni));
    node = zT_62;
    zT_63 = node.kind;
    if ((unsigned char)(zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_16; else goto z_bb_18;
    z_bb_8:
    zT_54 = 1;
    zT_56 = p7_si + (unsigned int)((unsigned int)zT_54);
    p7_si = zT_56;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    if ((unsigned char)((unsigned int)((unsigned int)p7_r) >= ni)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_49 = p7_r < p7_best_root;
    goto z_bb_13;
    z_bb_12:
    zT_49 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_49) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    p7_best_root = p7_r;
    zT_51 = p7_mods.ptr;
    zT_52 = zT_51[p7_si];
    zT_53 = zT_52.id;
    p7_best_id = zT_53;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_68 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_72 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_68, (unsigned int)((unsigned int)ni));
    val = zT_72;
    zT_73 = val.has_value;
    if (zT_73) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_4;
    z_bb_18:
    zT_80 = node.kind;
    if ((unsigned char)(zT_80 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    v = val.value;
    zT_75 = &ctx->comptime_folds;
    zT_77 = v;
    zF_376429F5_comptimeFoldTablePu(zT_75, (unsigned int)((unsigned int)ni), zT_77);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_85 = node.child_1;
    zT_86 = 0;
    zT_84 = zT_85 != (unsigned int)zT_86;
    goto z_bb_23;
    z_bb_22:
    zT_84 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_84) goto z_bb_24; else goto z_bb_26;
    z_bb_24:
    zT_88 = node.flags;
    if ((unsigned char)((unsigned char)(zT_88 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    goto z_bb_17;
    z_bb_26:
    zT_126 = node.kind;
    if ((unsigned char)(zT_126 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_43; else goto z_bb_42;
    z_bb_27:
    zT_94 = ctx->store;
    zT_95 = node.child_1;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    init_n = zT_98;
    zT_100 = init_n.kind;
    zT_101 = (unsigned int)zT_100;
    ik = zT_101;
    if ((unsigned char)(ik >= (unsigned int)(33))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_104 = ik <= (unsigned int)(42);
    goto z_bb_31;
    z_bb_30:
    zT_104 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_104) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_107 = ik == (unsigned int)(62);
    goto z_bb_34;
    z_bb_33:
    zT_107 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_107) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_110 = ik == (unsigned int)(64);
    goto z_bb_37;
    z_bb_36:
    zT_110 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_110) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_114 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_115 = node.child_1;
    zT_118 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_114, zT_115);
    val2 = zT_118;
    zT_119 = val2.has_value;
    if (zT_119) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_28;
    z_bb_40:
    v2 = val2.value;
    zT_121 = &ctx->comptime_folds;
    zT_122 = node.child_1;
    zT_123 = v2;
    zF_376429F5_comptimeFoldTablePu(zT_121, zT_122, zT_123);
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    zT_131 = node.kind;
    zT_130 = zT_131 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt);
    goto z_bb_44;
    z_bb_43:
    zT_130 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_130) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_135 = ctx->store;
    zT_139 = zF_8BA26B9E_astStoreNodePayload(zT_135, (unsigned int)((unsigned int)ni));
    if ((unsigned char)(zT_139 == (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_25;
    z_bb_47:
    zT_143 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_144 = node.child_0;
    zT_147 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_143, zT_144);
    cval = zT_147;
    zT_148 = cval.has_value;
    if (zT_148) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    cv = cval.value;
    zT_150 = cv.kind;
    if ((unsigned char)(zT_150 == (unsigned char)(1))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_153 = &ctx->comptime_folds;
    zT_154 = node.child_0;
    zT_155 = cv;
    zF_376429F5_comptimeFoldTablePu(zT_153, zT_154, zT_155);
    goto z_bb_52;
    z_bb_52:
    goto z_bb_50;
}

/* phase_SemanticAnalysis */
void zF_0666ED4F_phase_SemanticAnaly(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_6DCFC8DB_FrontResCtx zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_D3EB6303_StringInterner* zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    zT_69057089_CompilerAlloc* zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_66E7D2EF_CoercionTable* zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    zT_21D3708C_U32ToU32Map* zT_22;
    zT_21D3708C_U32ToU32Map* zT_23;
    zT_21D3708C_U32ToU32Map* zT_24;
    zT_21D3708C_U32ToU32Map* zT_25;
    zT_A4CE86B7_U64ToU32Map* zT_26;
    zT_072B53A6_ModuleRegistry* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_30 = {0};
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_69057089_CompilerAlloc* zT_38;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    unsigned int zT_43;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_60 = 0;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_6E8D187B_ModuleEntry* zT_72;
    zT_6E8D187B_ModuleEntry zT_73;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_76;
    zT_8EED1867_ResolvedTypeTable* zT_77;
    zT_F85C5DED_DiagnosticCollector* zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_3D7259E2_SymbolRegistry* zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_66E7D2EF_CoercionTable* zT_84;
    zT_21D3708C_U32ToU32Map* zT_85;
    zT_21D3708C_U32ToU32Map* zT_86;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_D3EB6303_StringInterner* zT_88;
    zT_21D3708C_U32ToU32Map* zT_89;
    zT_21D3708C_U32ToU32Map* zT_90;
    zT_072B53A6_ModuleRegistry* zT_91;
    zT_A4CE86B7_U64ToU32Map* zT_92;
    zT_69057089_CompilerAlloc* zT_93;
    zT_6E8D187B_ModuleEntry* zT_100;
    zT_6E8D187B_ModuleEntry zT_101;
    zT_38C12417_SemanticAnalyzer zT_112 = {0};
    zT_77F6F59C_ComptimeFoldTable* zT_113;
    zT_F3991012_Opt_346 zT_114;
    int zT_116;
    unsigned int zT_117;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_126 = 0;
    zT_6B0A7D14_AstStore* zT_128;
    unsigned int zT_129;
    zT_22A7C88B_AstNode zT_131 = {0};
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8143F551_AstKind zT_137;
    unsigned int zT_141;
    int zT_142;
    zT_6DCFC8DB_FrontResCtx* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_148;
    zT_6E8D187B_ModuleEntry* zT_150;
    zT_6E8D187B_ModuleEntry zT_151;
    zT_6E8D187B_ModuleEntry* zT_155;
    zT_6E8D187B_ModuleEntry zT_156;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    zT_38C12417_SemanticAnalyzer* zT_163;
    unsigned int zT_164;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    zT_8143F551_AstKind zT_171;
    unsigned char zT_175;
    unsigned int zT_176;
    zT_6B0A7D14_AstStore* zT_180;
    unsigned int zT_181;
    zT_22A7C88B_AstNode zT_184 = {0};
    zT_8143F551_AstKind zT_185;
    zT_38C12417_SemanticAnalyzer* zT_189;
    unsigned int zT_190;
    zT_8143F551_AstKind zT_192;
    unsigned char zT_196;
    unsigned char zT_197;
    zT_38C12417_SemanticAnalyzer* zT_202;
    unsigned int zT_203;
    zT_8143F551_AstKind zT_205;
    zT_38C12417_SemanticAnalyzer* zT_209;
    unsigned int zT_210;
    zT_8143F551_AstKind zT_212;
    zT_38C12417_SemanticAnalyzer* zT_216;
    unsigned int zT_217;
    int zT_219;
    unsigned int zT_221;
    int zT_222;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mz;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u ad;
    zT_8F083A69_Slice_zT_0B42B2F8_u dse_m;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa0;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa1;
    zT_22A7C88B_AstNode di_inn;
    zT_2 = "RS";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    rs = zT_3;
    zT_5 = rs;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->store;
    zT_10.store = zT_11;
    zT_12 = ctx->typereg;
    zT_10.typereg = zT_12;
    zT_13 = ctx->symbol_reg;
    zT_10.symbol_reg = zT_13;
    zT_14 = ctx->resolved_types;
    zT_10.resolved_types = zT_14;
    zT_15 = ctx->module_reg;
    zT_10.module_reg = zT_15;
    zT_16 = ctx->interner;
    zT_10.interner = zT_16;
    zT_17 = ctx->diag;
    zT_10.diag = zT_17;
    zT_18 = ctx->alloc;
    zT_19 = &zT_18->scratch;
    zT_10.scratch = zT_19;
    zT_20 = ctx->coercion_table;
    zT_10.coercion_table = zT_20;
    zT_21 = &ctx->enum_value_table;
    zT_10.enum_value_table = zT_21;
    zT_22 = &ctx->tuple_index_table;
    zT_10.tuple_index_table = zT_22;
    zT_23 = &ctx->error_code_registry;
    zT_10.error_code_registry = zT_23;
    zT_24 = &ctx->call_arg_types;
    zT_10.call_arg_types = zT_24;
    zT_25 = &ctx->call_param_map;
    zT_10.call_param_map = zT_25;
    zT_26 = &ctx->suspending_fns;
    zT_10.suspending_fns = zT_26;
    frc = zT_10;
    zT_28 = ctx->module_reg;
    zT_30 = zF_3452C137_moduleRegistryGetMo(zT_28);
    mods = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    mi = zT_33;
    goto z_bb_1;
    z_bb_1:
    zT_35 = mods.len;
    if ((unsigned char)(mi < zT_35)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_38 = ctx->alloc;
    zT_37 = &zT_38->scratch;
    zF_F1B3F8C2_sandReset(zT_37);
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_43 = zT_42.ast_root;
    ast_root = zT_43;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_222 = 1;
    zT_224 = mi + (unsigned int)((unsigned int)zT_222);
    mi = zT_224;
    goto z_bb_1;
    z_bb_5:
    zT_47 = "MZ";
    zT_49 = 2;
    zT_48.ptr = (unsigned char*)zT_47;
    zT_48.len = zT_49;
    mz = zT_48;
    zT_50 = mz;
    zF_48AC7B3A_markerWrite(zT_50);
    goto z_bb_4;
    z_bb_6:
    zT_52 = ctx->store;
    zT_53 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_52, zT_53);
    zT_57 = ctx->store;
    zT_58 = ast_root;
    zT_60 = zF_152E19CB_astStoreNodeExtraCh(zT_57, zT_58);
    decls_n = zT_60;
    zT_62 = "AD";
    zT_64 = 2;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    ad = zT_63;
    zT_65 = ad;
    zF_48AC7B3A_markerWrite(zT_65);
    zT_67 = "DSE\n";
    zT_69 = 4;
    zT_68.ptr = (unsigned char*)zT_67;
    zT_68.len = zT_69;
    dse_m = zT_68;
    zT_70 = dse_m;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_72 = mods.ptr;
    zT_73 = zT_72[mi];
    zT_74 = zT_73.source_file_id;
    src_fid = zT_74;
    zT_93 = ctx->alloc;
    zT_76 = &zT_93->scratch;
    zT_77 = ctx->resolved_types;
    zT_78 = ctx->diag;
    zT_79 = ctx->typereg;
    zT_80 = ctx->symbol_reg;
    zT_81 = ctx->store;
    zT_100 = mods.ptr;
    zT_101 = zT_100[mi];
    zT_82 = zT_101.id;
    zT_83 = src_fid;
    zT_84 = ctx->coercion_table;
    zT_85 = &ctx->enum_value_table;
    zT_86 = &ctx->tuple_index_table;
    zT_87 = &ctx->error_code_registry;
    zT_88 = ctx->interner;
    zT_89 = &ctx->call_arg_types;
    zT_90 = &ctx->call_param_map;
    zT_91 = ctx->module_reg;
    zT_92 = &ctx->suspending_fns;
    zT_112 = zF_84ADA681_semanticAnalyzerIni(zT_76, zT_77, zT_78, zT_79, zT_80, zT_81, zT_82, zT_83, zT_84, zT_85, zT_86, zT_87, zT_88, zT_89, zT_90, zT_91, zT_92);
    sa = zT_112;
    zT_113 = &ctx->comptime_folds;
    zT_114.has_value = 1;
    zT_114.value = zT_113;
    sa.comptime_folds = zT_114;
    zT_116 = 0;
    zT_117 = (unsigned int)zT_116;
    di = zT_117;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_121 = ctx->store;
    zT_122 = ast_root;
    zT_126 = zF_B10B1BC1_astStoreNodeExtraCh(zT_121, zT_122, (unsigned int)((unsigned int)di));
    decl_idx = zT_126;
    zT_128 = ctx->store;
    zT_129 = decl_idx;
    zT_131 = zF_FCDD1D35_astStoreNodeAt(zT_128, zT_129);
    decl = zT_131;
    zT_133 = "DN";
    zT_135 = 2;
    zT_134.ptr = (unsigned char*)zT_133;
    zT_134.len = zT_135;
    dn = zT_134;
    zT_136 = dn;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_137 = decl.kind;
    if ((unsigned char)(zT_137 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_219 = 1;
    zT_221 = di + (unsigned int)((unsigned int)zT_219);
    di = zT_221;
    goto z_bb_7;
    z_bb_11:
    zT_141 = decl.child_0;
    zT_142 = 0;
    if ((unsigned char)(zT_141 != (unsigned int)zT_142)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_171 = decl.kind;
    if ((unsigned char)(zT_171 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_144 = (zT_6DCFC8DB_FrontResCtx*)&frc;
    zT_150 = mods.ptr;
    zT_151 = zT_150[mi];
    zT_145 = zT_151.id;
    zT_146 = decl.child_0;
    zT_155 = mods.ptr;
    zT_156 = zT_155[mi];
    zT_148 = zT_156.source_file_id;
    zF_783226DA_resolveStmtTypes(zT_144, zT_145, zT_146, (unsigned int)(0), zT_148);
    goto z_bb_15;
    z_bb_15:
    zT_159 = "SA";
    zT_161 = 2;
    zT_160.ptr = (unsigned char*)zT_159;
    zT_160.len = zT_161;
    sa0 = zT_160;
    zT_162 = sa0;
    zF_48AC7B3A_markerWrite(zT_162);
    zT_163 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_164 = decl_idx;
    zF_406A2501_semanticAnalyzerRes(zT_163, zT_164);
    zT_167 = "sA";
    zT_169 = 2;
    zT_168.ptr = (unsigned char*)zT_167;
    zT_168.len = zT_169;
    sa1 = zT_168;
    zT_170 = sa1;
    zF_48AC7B3A_markerWrite(zT_170);
    goto z_bb_12;
    z_bb_16:
    zT_176 = decl.child_1;
    zT_175 = zT_176 != (unsigned int)(0);
    goto z_bb_18;
    z_bb_17:
    zT_175 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_175) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_180 = ctx->store;
    zT_181 = decl.child_1;
    zT_184 = zF_FCDD1D35_astStoreNodeAt(zT_180, zT_181);
    di_inn = zT_184;
    zT_185 = di_inn.kind;
    if ((unsigned char)(zT_185 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_212 = decl.kind;
    if ((unsigned char)(zT_212 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_31; else goto z_bb_32;
    z_bb_22:
    zT_189 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_190 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_189, zT_190);
    goto z_bb_23;
    z_bb_23:
    zT_192 = di_inn.kind;
    if ((unsigned char)(zT_192 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_197 = di_inn.flags;
    zT_196 = (unsigned char)(zT_197 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_196 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_196) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_202 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_203 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_202, zT_203);
    goto z_bb_28;
    z_bb_28:
    zT_205 = di_inn.kind;
    if ((unsigned char)(zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_209 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_210 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_209, zT_210);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_20;
    z_bb_31:
    zT_216 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_217 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_216, zT_217);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_20;
}

/* phase_StaticAnalyzers */
void zF_F3B55B42_phase_StaticAnalyze(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_C98AF326_CompilerCli zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    zT_C98AF326_CompilerCli zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    zT_C98AF326_CompilerCli zT_22;
    unsigned char zT_23;
    zT_072B53A6_ModuleRegistry* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29 = {0};
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_69057089_CompilerAlloc* zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_46;
    zT_060CD1EB_SymbolTable* zT_50 = 0;
    zT_7E2F335A_AnalyzerContext zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    zT_69057089_CompilerAlloc* zT_57;
    zT_3E40CD83_Sand* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_69057089_CompilerAlloc* zT_63;
    zT_3E40CD83_Sand* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_C98AF326_CompilerCli zT_67;
    unsigned char zT_68;
    unsigned char zT_69;
    int zT_70;
    int zT_72;
    unsigned char zT_74;
    zT_C98AF326_CompilerCli zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    int zT_78;
    int zT_80;
    unsigned char zT_82;
    zT_C98AF326_CompilerCli zT_83;
    unsigned char zT_84;
    unsigned char zT_85;
    int zT_86;
    int zT_88;
    unsigned char zT_90;
    zT_C98AF326_CompilerCli zT_91;
    unsigned char zT_92;
    unsigned char zT_93;
    int zT_94;
    int zT_96;
    unsigned char zT_98;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    zT_6E8D187B_ModuleEntry* zT_103;
    zT_6E8D187B_ModuleEntry zT_104;
    unsigned int zT_105;
    zT_7E2F335A_AnalyzerContext* zT_106;
    unsigned int zT_107;
    zT_227EDE07_SourceManager* zT_109;
    int zT_111;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_060CD1EB_SymbolTable* sym_table;
    zT_7E2F335A_AnalyzerContext ac;
    zT_2 = "A\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = ctx->alloc;
    zT_9 = &zT_10->scratch;
    zF_CB5A85E9_sandResetPeak(zT_9);
    zT_12 = ctx->cli;
    zT_13 = zT_12.no_null_check;
    if ((unsigned char)(zT_13 != (unsigned char)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_17 = ctx->cli;
    zT_18 = zT_17.no_lifetime_check;
    zT_16 = zT_18 != (unsigned char)(1);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = ctx->cli;
    zT_23 = zT_22.no_leak_check;
    zT_21 = zT_23 != (unsigned char)(1);
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = ctx->module_reg;
    zT_29 = zF_3452C137_moduleRegistryGetMo(zT_27);
    mods = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    mi = zT_32;
    goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    zT_34 = mods.len;
    if ((unsigned char)(mi < zT_34)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = ctx->alloc;
    zT_36 = &zT_37->scratch;
    zF_F1B3F8C2_sandReset(zT_36);
    zT_40 = mods.ptr;
    zT_41 = zT_40[mi];
    zT_42 = zT_41.ast_root;
    ast_root = zT_42;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_111 = 1;
    zT_113 = mi + (unsigned int)((unsigned int)zT_111);
    mi = zT_113;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_46 = ctx->symbol_reg;
    zT_50 = zF_9B36C202_symbolRegistryGetTa(zT_46, (unsigned int)((unsigned int)mi));
    sym_table = zT_50;
    zT_53 = ctx->store;
    zT_52.store = zT_53;
    zT_54 = ctx->typereg;
    zT_52.registry = zT_54;
    zT_55 = ctx->interner;
    zT_52.interner = zT_55;
    zT_56 = ctx->diag;
    zT_52.diag = zT_56;
    zT_52.symbols = sym_table;
    zT_57 = ctx->alloc;
    zT_58 = &zT_57->scratch;
    zT_52.alloc = zT_58;
    zT_59 = 0;
    zT_52.current_fn_name = zT_59;
    zT_60 = 0;
    zT_52.defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_60;
    zT_61 = 0;
    zT_52.defer_queue_len = zT_61;
    zT_62 = 0;
    zT_52.defer_queue_cap = zT_62;
    zT_63 = ctx->alloc;
    zT_64 = &zT_63->scratch;
    zT_52.defer_queue_alloc = zT_64;
    zT_65 = 0;
    zT_52.current_depth = zT_65;
    zT_66 = 0;
    zT_52.null_analysis_mode = zT_66;
    zT_67 = ctx->cli;
    zT_68 = zT_67.no_null_check;
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_70 = 1;
    zT_69 = (unsigned char)zT_70;
    goto z_bb_17;
    z_bb_16:
    zT_72 = 0;
    zT_69 = (unsigned char)zT_72;
    goto z_bb_17;
    z_bb_17:
    zT_74 = (unsigned char)zT_69;
    zT_52.skip_null_check = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.no_lifetime_check;
    if (zT_76) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_78 = 1;
    zT_77 = (unsigned char)zT_78;
    goto z_bb_20;
    z_bb_19:
    zT_80 = 0;
    zT_77 = (unsigned char)zT_80;
    goto z_bb_20;
    z_bb_20:
    zT_82 = (unsigned char)zT_77;
    zT_52.skip_lifetime_check = zT_82;
    zT_83 = ctx->cli;
    zT_84 = zT_83.no_leak_check;
    if (zT_84) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_86 = 1;
    zT_85 = (unsigned char)zT_86;
    goto z_bb_23;
    z_bb_22:
    zT_88 = 0;
    zT_85 = (unsigned char)zT_88;
    goto z_bb_23;
    z_bb_23:
    zT_90 = (unsigned char)zT_85;
    zT_52.skip_doublefree_check = zT_90;
    zT_91 = ctx->cli;
    zT_92 = zT_91.warn_all;
    if (zT_92) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_94 = 1;
    zT_93 = (unsigned char)zT_94;
    goto z_bb_26;
    z_bb_25:
    zT_96 = 0;
    zT_93 = (unsigned char)zT_96;
    goto z_bb_26;
    z_bb_26:
    zT_98 = (unsigned char)zT_93;
    zT_52.warn_all = zT_98;
    zT_99 = zF_43C99FB3_onNullStmt;
    zT_52.on_stmt_cb = zT_99;
    zT_100 = 0;
    zT_52.in_defer_exec = zT_100;
    zT_101 = 0;
    zT_52.lifetime_analysis_mode = zT_101;
    zT_102 = 0;
    zT_52.doublefree_analysis_mode = zT_102;
    zT_103 = mods.ptr;
    zT_104 = zT_103[mi];
    zT_105 = zT_104.source_file_id;
    zT_52.source_file_id = zT_105;
    ac = zT_52;
    zT_106 = (zT_7E2F335A_AnalyzerContext*)&ac;
    zT_107 = ast_root;
    zF_F697813C_runAllAnalyzers(zT_106, zT_107);
    zT_109 = ctx->source_man;
    zF_196FDF3B_sourceManagerResetF(zT_109);
    goto z_bb_12;
}

/* phase_AsyncFrameSize */
void zF_9BC6214D_phase_AsyncFrameSiz(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_3D7259E2_SymbolRegistry* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_072B53A6_ModuleRegistry* zT_10;
    zT_338B7C76_TypeRegistry* zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_12;
    zT_A4CE86B7_U64ToU32Map* zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_A4CE86B7_U64ToU32Map* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_B687BB96_U32ArrayList* zT_19;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_69057089_CompilerAlloc* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_2 = "AFS\n";
    zT_4 = 4;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_22 = ctx->alloc;
    zT_6 = &zT_22->module;
    zT_7 = ctx->store;
    zT_8 = ctx->symbol_reg;
    zT_9 = ctx->interner;
    zT_10 = ctx->module_reg;
    zT_11 = ctx->typereg;
    zT_12 = ctx->resolved_types;
    zT_13 = &ctx->suspending_fns;
    zT_14 = &ctx->frame_sizes;
    zT_15 = &ctx->state_widths;
    zT_16 = &ctx->awaited_fns;
    zT_17 = &ctx->async_hidden_fns;
    zT_18 = &ctx->driver_targets;
    zT_19 = &ctx->parent_result_type_list;
    zT_20 = &ctx->parent_result_start;
    zT_21 = &ctx->parent_result_count;
    zF_7DBA21B2_asyncFrameSizeRun(zT_6, zT_7, zT_8, zT_9, zT_10, zT_11, zT_12, zT_13, zT_14, zT_15, zT_16, zT_17, zT_18, zT_19, zT_20, zT_21);
    return;
}

/* phase_ConstInit */
void zF_A6065296_phase_ConstInit(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15 = {0};
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_622E1E76_Opt_254 zT_19;
    zT_4D150975_ConstInitEvalCtx zT_21;
    zT_4065182A_ConstInitTable* zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_8EED1867_ResolvedTypeTable* zT_26;
    zT_DA663F79_ComptimeEval* zT_27;
    zT_21D3708C_U32ToU32Map* zT_28;
    zT_072B53A6_ModuleRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_31;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_33 = {0};
    unsigned int zT_35;
    unsigned int zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    zT_6E8D187B_ModuleEntry* zT_45;
    zT_6E8D187B_ModuleEntry zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    unsigned int zT_52 = 0;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    unsigned int zT_63 = 0;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_68 = {0};
    zT_8143F551_AstKind zT_69;
    unsigned char zT_73;
    unsigned char zT_79;
    unsigned int zT_85;
    zT_4D150975_ConstInitEvalCtx* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_6E8D187B_ModuleEntry* zT_92;
    zT_6E8D187B_ModuleEntry zT_93;
    zT_BAEE192E_Opt_10 zT_95 = {0};
    unsigned int zT_97;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u ci_m;
    zT_DA663F79_ComptimeEval ci_ce;
    zT_4D150975_ConstInitEvalCtx cic;
    zT_DDCD424B_Slice_zT_6E8D187B_M cmods;
    unsigned int cmi;
    unsigned int croot;
    unsigned int cdn;
    unsigned int cdi;
    unsigned int cdecl_idx;
    zT_22A7C88B_AstNode cdecl;
    zT_2 = "CIE\n";
    zT_4 = 4;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    ci_m = zT_3;
    zT_5 = ci_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ci_ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ci_ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ci_ce.diag = zT_19;
    zT_22 = &ctx->const_inits;
    zT_21.tbl = zT_22;
    zT_23 = ctx->store;
    zT_21.store = zT_23;
    zT_24 = ctx->typereg;
    zT_21.registry = zT_24;
    zT_25 = ctx->symbol_reg;
    zT_21.symbol_reg = zT_25;
    zT_26 = ctx->resolved_types;
    zT_21.resolved = zT_26;
    zT_27 = (zT_DA663F79_ComptimeEval*)&ci_ce;
    zT_21.ce = zT_27;
    zT_28 = &ctx->enum_value_table;
    zT_21.enum_values = zT_28;
    zT_29 = ctx->module_reg;
    zT_21.module_reg = zT_29;
    cic = zT_21;
    zT_31 = ctx->module_reg;
    zT_33 = zF_3452C137_moduleRegistryGetMo(zT_31);
    cmods = zT_33;
    zT_35 = 0;
    cmi = zT_35;
    goto z_bb_1;
    z_bb_1:
    zT_37 = cmods.len;
    if ((unsigned char)(cmi < zT_37)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_40 = cmods.ptr;
    zT_41 = zT_40[cmi];
    zT_42 = zT_41.ast_root;
    croot = zT_42;
    if ((unsigned char)(croot == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_99 = cmi + (unsigned int)(1);
    cmi = zT_99;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_45 = cmods.ptr;
    zT_46 = zT_45[cmi];
    zT_47 = zT_46.id;
    ci_ce.module_id = zT_47;
    zT_49 = ctx->store;
    zT_50 = croot;
    zT_52 = zF_152E19CB_astStoreNodeExtraCh(zT_49, zT_50);
    cdn = zT_52;
    zT_54 = 0;
    cdi = zT_54;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(cdi < (unsigned int)((unsigned int)cdn))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_58 = ctx->store;
    zT_59 = croot;
    zT_63 = zF_B10B1BC1_astStoreNodeExtraCh(zT_58, zT_59, (unsigned int)((unsigned int)cdi));
    cdecl_idx = zT_63;
    zT_65 = ctx->store;
    zT_66 = cdecl_idx;
    zT_68 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    cdecl = zT_68;
    zT_69 = cdecl.kind;
    if ((unsigned char)(zT_69 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_97 = cdi + (unsigned int)(1);
    cdi = zT_97;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_73 = cdecl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_73) & (unsigned short)(4)) != (unsigned short)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_79 = cdecl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_79) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_85 = cdecl.child_1;
    if ((unsigned char)(zT_85 == (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_88 = (zT_4D150975_ConstInitEvalCtx*)&cic;
    zT_92 = cmods.ptr;
    zT_93 = zT_92[cmi];
    zT_89 = zT_93.id;
    zT_90 = cdecl_idx;
    zT_95 = zF_2B750645_constInitEvaluate(zT_88, zT_89, zT_90);
    (void)zT_95;
    goto z_bb_10;
}

/* phase_LIRLowering */
void zF_1F21ABE7_phase_LIRLowering(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_4028D896_Arr_unsigned_char_2 zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_BDEA985E_anon_318158 zT_17;
    unsigned int zT_18;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_4028D896_Arr_unsigned_char_2 zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    zT_01BE9D46_AstValuePool zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_69057089_CompilerAlloc* zT_76;
    zT_CA01C129_LirSlotArrayList* zT_79;
    zT_846744CC_Arr_unsigned_char_5 zT_81;
    unsigned int zT_83;
    zT_C98AF326_CompilerCli zT_84;
    unsigned char zT_85;
    zT_C98AF326_CompilerCli zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned char zT_94;
    unsigned char* zT_97;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned char zT_103;
    unsigned int zT_105;
    unsigned char zT_106;
    unsigned int zT_108;
    unsigned char zT_109;
    unsigned int zT_111;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    unsigned int zT_119;
    unsigned char zT_121;
    unsigned char* zT_124;
    unsigned char zT_125;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_7E7544E4_LirStream* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    zT_3E40CD83_Sand* zT_132;
    int zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    zT_69057089_CompilerAlloc* zT_140;
    zT_C98AF326_CompilerCli zT_142;
    unsigned char zT_143;
    zT_846744CC_Arr_unsigned_char_5 zT_145;
    unsigned int zT_147;
    zT_C98AF326_CompilerCli zT_148;
    unsigned char zT_149;
    zT_C98AF326_CompilerCli zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_154;
    unsigned int zT_156;
    unsigned char zT_158;
    unsigned char* zT_161;
    unsigned char zT_162;
    unsigned int zT_164;
    unsigned int zT_166;
    unsigned char zT_167;
    unsigned int zT_169;
    unsigned char zT_170;
    unsigned int zT_172;
    unsigned char zT_173;
    unsigned int zT_175;
    unsigned char* zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    unsigned int zT_179;
    unsigned int zT_181;
    unsigned int zT_183;
    unsigned char zT_185;
    unsigned char* zT_188;
    unsigned char zT_189;
    unsigned int zT_191;
    unsigned int zT_193;
    zT_C615AE29_DebugSpanStore* zT_194;
    zT_3E40CD83_Sand* zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    zT_69057089_CompilerAlloc* zT_198;
    int zT_202;
    unsigned char* zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    zT_6B356268_SemanticContext zT_207;
    zT_6B0A7D14_AstStore* zT_208;
    zT_338B7C76_TypeRegistry* zT_209;
    zT_3D7259E2_SymbolRegistry* zT_210;
    zT_8EED1867_ResolvedTypeTable* zT_211;
    zT_66E7D2EF_CoercionTable* zT_212;
    zT_F85C5DED_DiagnosticCollector* zT_213;
    unsigned char zT_214;
    zT_21D3708C_U32ToU32Map* zT_215;
    zT_21D3708C_U32ToU32Map* zT_216;
    zT_21D3708C_U32ToU32Map* zT_217;
    zT_21D3708C_U32ToU32Map* zT_218;
    zT_77F6F59C_ComptimeFoldTable* zT_219;
    zT_4065182A_ConstInitTable* zT_220;
    unsigned int zT_221;
    zT_C98AF326_CompilerCli zT_222;
    unsigned char zT_223;
    zT_A4CE86B7_U64ToU32Map* zT_224;
    zT_A4CE86B7_U64ToU32Map* zT_225;
    zT_A4CE86B7_U64ToU32Map* zT_226;
    unsigned char zT_227;
    zT_072B53A6_ModuleRegistry* zT_229;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_231 = {0};
    zT_3E40CD83_Sand* zT_233;
    zT_69057089_CompilerAlloc* zT_234;
    zT_B687BB96_U32ArrayList zT_236 = {0};
    unsigned char zT_238;
    int zT_240;
    unsigned int zT_241;
    unsigned int zT_243;
    zT_6E8D187B_ModuleEntry* zT_245;
    zT_6E8D187B_ModuleEntry zT_246;
    unsigned int zT_247;
    unsigned char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    zT_4028D896_Arr_unsigned_char_2 zT_254;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_257;
    int zT_261;
    unsigned char* zT_262;
    unsigned int zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    unsigned int zT_265 = 0;
    unsigned int zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned char* zT_274;
    unsigned int zT_275;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_276;
    unsigned char* zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned int zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    zT_6E8D187B_ModuleEntry* zT_282;
    zT_6E8D187B_ModuleEntry zT_283;
    unsigned int zT_284;
    zT_4028D896_Arr_unsigned_char_2 zT_288;
    unsigned int zT_290;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_291;
    zT_6E8D187B_ModuleEntry* zT_292;
    zT_6E8D187B_ModuleEntry zT_293;
    int zT_297;
    unsigned char* zT_298;
    unsigned int zT_299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_300;
    unsigned int zT_301 = 0;
    unsigned int zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    unsigned char* zT_310;
    unsigned int zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_313;
    zT_6B0A7D14_AstStore* zT_315;
    unsigned int zT_316;
    zT_6E8D187B_ModuleEntry* zT_318;
    zT_6E8D187B_ModuleEntry zT_319;
    zT_22A7C88B_AstNode zT_321 = {0};
    zT_8143F551_AstKind zT_322;
    unsigned char* zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    zT_6B0A7D14_AstStore* zT_332;
    unsigned int zT_333;
    zT_6E8D187B_ModuleEntry* zT_335;
    zT_6E8D187B_ModuleEntry zT_336;
    unsigned int zT_338 = 0;
    unsigned int zT_340;
    zT_4028D896_Arr_unsigned_char_2 zT_342;
    unsigned int zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    int zT_348;
    unsigned char* zT_349;
    unsigned int zT_350;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_351;
    unsigned int zT_352 = 0;
    unsigned int zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned char* zT_361;
    unsigned int zT_362;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    zT_6B0A7D14_AstStore* zT_365;
    unsigned int zT_366;
    zT_B687BB96_U32ArrayList* zT_367;
    zT_6E8D187B_ModuleEntry* zT_369;
    zT_6E8D187B_ModuleEntry zT_370;
    zT_6E8D187B_ModuleEntry* zT_372;
    zT_6E8D187B_ModuleEntry* zT_373;
    unsigned char zT_376;
    unsigned int zT_378;
    zT_6B0A7D14_AstStore* zT_382;
    unsigned int zT_383;
    zT_6E8D187B_ModuleEntry* zT_386;
    zT_6E8D187B_ModuleEntry zT_387;
    unsigned int zT_390 = 0;
    zT_6B0A7D14_AstStore* zT_392;
    unsigned int zT_393;
    zT_22A7C88B_AstNode zT_395 = {0};
    zT_8143F551_AstKind zT_397;
    unsigned int zT_398;
    zT_4028D896_Arr_unsigned_char_2 zT_400;
    unsigned int zT_402;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    int zT_406;
    unsigned char* zT_407;
    unsigned int zT_408;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_409;
    unsigned int zT_410 = 0;
    unsigned int zT_414;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_415;
    unsigned char* zT_419;
    unsigned int zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421;
    unsigned char* zT_423;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_424;
    unsigned int zT_425;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_426;
    zT_8143F551_AstKind zT_427;
    unsigned char* zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned int zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_435;
    unsigned char zT_436;
    zT_6B0A7D14_AstStore* zT_443;
    zT_4EF476FD_anon_318191 zT_444;
    zT_243D6A41_FnProto* zT_445;
    zT_6B0A7D14_AstStore* zT_446;
    unsigned int zT_447;
    unsigned int zT_449 = 0;
    unsigned int zT_450;
    zT_243D6A41_FnProto zT_451;
    zT_6E8D187B_ModuleEntry* zT_453;
    zT_6E8D187B_ModuleEntry zT_454;
    unsigned int zT_455;
    unsigned int zT_463;
    zT_79FAE712_u64 zT_465;
    zT_A4CE86B7_U64ToU32Map* zT_466;
    zT_79FAE712_u64 zT_467;
    zT_6B356268_SemanticContext* zT_472;
    zT_3E40CD83_Sand* zT_473;
    zT_69057089_CompilerAlloc* zT_475;
    zT_02EB57B2_LirLowerer zT_477 = {0};
    zT_6E8D187B_ModuleEntry* zT_478;
    zT_6E8D187B_ModuleEntry zT_479;
    unsigned int zT_480;
    zT_072B53A6_ModuleRegistry* zT_481;
    zT_C98AF326_CompilerCli zT_482;
    unsigned char zT_483;
    unsigned char zT_484;
    int zT_485;
    int zT_487;
    zT_C98AF326_CompilerCli zT_490;
    unsigned char zT_491;
    zT_6B0A7D14_AstStore* zT_493;
    zT_4EF476FD_anon_318191 zT_494;
    zT_243D6A41_FnProto* zT_495;
    zT_6B0A7D14_AstStore* zT_496;
    unsigned int zT_497;
    unsigned int zT_499 = 0;
    unsigned int zT_500;
    zT_243D6A41_FnProto zT_501;
    zT_227EDE07_SourceManager* zT_503;
    unsigned int zT_504;
    unsigned int zT_505;
    zT_6E8D187B_ModuleEntry* zT_507;
    zT_6E8D187B_ModuleEntry zT_508;
    zT_5BC08DC6_Location zT_511 = {0};
    zT_8B83E3B4_DebugSymbolList* zT_512;
    zT_1001656C_DebugSymbol zT_513;
    zT_8B83E3B4_DebugSymbolList* zT_514;
    zT_1001656C_DebugSymbol zT_515;
    unsigned char zT_516;
    unsigned char zT_517;
    unsigned char zT_523;
    int zT_524;
    int zT_526;
    unsigned char zT_528;
    unsigned int zT_529;
    zT_6E8D187B_ModuleEntry* zT_530;
    zT_6E8D187B_ModuleEntry zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    unsigned int zT_534;
    zT_6E8D187B_ModuleEntry* zT_535;
    zT_6E8D187B_ModuleEntry zT_536;
    unsigned int zT_537;
    unsigned int zT_538;
    zT_C98AF326_CompilerCli zT_539;
    unsigned char zT_540;
    zT_1F328BC1_DebugSpanArrayList zT_541;
    int zT_542;
    zT_02EB57B2_LirLowerer* zT_544;
    zT_1F328BC1_DebugSpanArrayList* zT_545;
    zT_02EB57B2_LirLowerer* zT_547;
    unsigned int zT_548;
    zT_BBC23664_LirFunction zT_550 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_551;
    unsigned int zT_552;
    unsigned int zT_553;
    unsigned char zT_557 = 0;
    zT_3E40CD83_Sand* zT_559;
    zT_338B7C76_TypeRegistry* zT_560;
    zT_BBC23664_LirFunction* zT_561;
    zT_A4CE86B7_U64ToU32Map* zT_562;
    zT_A4CE86B7_U64ToU32Map* zT_563;
    zT_A4CE86B7_U64ToU32Map* zT_564;
    zT_A4CE86B7_U64ToU32Map* zT_565;
    zT_A4CE86B7_U64ToU32Map* zT_566;
    zT_A4CE86B7_U64ToU32Map* zT_567;
    zT_B687BB96_U32ArrayList* zT_568;
    zT_A4CE86B7_U64ToU32Map* zT_569;
    zT_A4CE86B7_U64ToU32Map* zT_570;
    zT_69057089_CompilerAlloc* zT_571;
    zT_3F3BF87A_AsyncFrameLayout zT_584 = {0};
    zT_3E40CD83_Sand* zT_585;
    zT_A4CE86B7_U64ToU32Map* zT_586;
    unsigned int zT_587;
    unsigned int zT_588;
    zT_3F3BF87A_AsyncFrameLayout zT_589;
    zT_69057089_CompilerAlloc* zT_590;
    zT_3E40CD83_Sand* zT_596;
    zT_69057089_CompilerAlloc* zT_599;
    zT_FDFD82FD_EU_362 zT_603 = {0};
    unsigned char zT_604;
    unsigned char* zT_605;
    zT_BBC23664_LirFunction* zT_608;
    zT_B687BB96_U32ArrayList* zT_609;
    unsigned char zT_614;
    zT_7E7544E4_LirStream* zT_616;
    zT_BBC23664_LirFunction zT_617;
    zT_E7714190_LirSlot zT_619 = {0};
    zT_CA01C129_LirSlotArrayList* zT_620;
    zT_E7714190_LirSlot zT_621;
    zT_C98AF326_CompilerCli zT_623;
    unsigned char zT_624;
    zT_C615AE29_DebugSpanStore* zT_625;
    unsigned int zT_626;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_627;
    zT_1F328BC1_DebugSpanArrayList zT_630;
    zT_10BDA76C_DebugSpanEntry* zT_631;
    zT_1F328BC1_DebugSpanArrayList zT_632;
    unsigned int zT_633;
    int zT_634;
    zT_10BDA76C_DebugSpanEntry* zT_635;
    unsigned int zT_636;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_637;
    zT_3E40CD83_Sand* zT_639;
    zT_69057089_CompilerAlloc* zT_640;
    zT_C98AF326_CompilerCli zT_642;
    unsigned char zT_643;
    zT_1F328BC1_DebugSpanArrayList zT_644;
    int zT_645;
    zT_1F328BC1_DebugSpanArrayList* zT_647;
    zT_8143F551_AstKind zT_648;
    unsigned char zT_652;
    zT_6B0A7D14_AstStore* zT_659;
    unsigned int zT_660;
    unsigned int zT_662 = 0;
    zT_3D7259E2_SymbolRegistry* zT_664;
    unsigned int zT_665;
    unsigned int zT_666;
    zT_6E8D187B_ModuleEntry* zT_668;
    zT_6E8D187B_ModuleEntry zT_669;
    zT_77F031D4_Opt_960 zT_671 = {0};
    unsigned char zT_672;
    zT_3C598AEF_SymbolKind zT_674;
    unsigned int zT_679;
    unsigned char zT_680;
    unsigned char zT_686;
    unsigned int zT_687;
    zT_6B0A7D14_AstStore* zT_691;
    unsigned int zT_692;
    zT_22A7C88B_AstNode zT_695 = {0};
    unsigned char zT_697;
    zT_8143F551_AstKind zT_698;
    unsigned char zT_702;
    zT_8143F551_AstKind zT_703;
    zT_6B0A7D14_AstStore* zT_708;
    unsigned int zT_709;
    zT_22A7C88B_AstNode zT_712 = {0};
    zT_8143F551_AstKind zT_713;
    unsigned char zT_717;
    zT_21D3708C_U32ToU32Map* zT_720;
    unsigned int zT_721;
    zT_4065182A_ConstInitTable* zT_722;
    zT_BAEE192E_Opt_10 zT_724 = {0};
    unsigned char zT_725;
    unsigned char zT_731;
    zT_6E8D187B_ModuleEntry* zT_738;
    zT_6E8D187B_ModuleEntry zT_739;
    unsigned int zT_740;
    zT_79FAE712_u64 zT_749;
    zT_A4CE86B7_U64ToU32Map* zT_750;
    zT_79FAE712_u64 zT_751;
    zT_8EED1867_ResolvedTypeTable* zT_756;
    unsigned int zT_757;
    zT_BAEE192E_Opt_10 zT_759 = {0};
    unsigned char zT_761;
    unsigned int zT_762;
    unsigned char zT_767;
    unsigned char zT_770;
    zT_4065182A_ConstInitTable* zT_774;
    unsigned int zT_775;
    zT_49DE1C22_ConstInitNode zT_777 = {0};
    unsigned char zT_778;
    unsigned char zT_781;
    unsigned char zT_782;
    unsigned int zT_785;
    unsigned int zT_786;
    unsigned int zT_791;
    zT_79FAE712_u64 zT_792;
    unsigned int zT_795;
    unsigned char zT_796;
    unsigned int zT_799;
    unsigned char zT_800;
    unsigned int zT_803;
    unsigned char zT_805;
    unsigned char zT_806;
    unsigned char zT_812;
    zT_E1A783EF_GlobalDeclArrayList* zT_813;
    zT_54906056_ModuleGlobalDecl zT_814;
    zT_54906056_ModuleGlobalDecl zT_816;
    zT_6E8D187B_ModuleEntry* zT_817;
    zT_6E8D187B_ModuleEntry zT_818;
    unsigned int zT_819;
    unsigned char zT_820;
    zT_C98AF326_CompilerCli zT_821;
    unsigned char zT_822;
    zT_227EDE07_SourceManager* zT_824;
    unsigned int zT_825;
    unsigned int zT_826;
    zT_6E8D187B_ModuleEntry* zT_828;
    zT_6E8D187B_ModuleEntry zT_829;
    zT_5BC08DC6_Location zT_832 = {0};
    zT_8B83E3B4_DebugSymbolList* zT_833;
    zT_1001656C_DebugSymbol zT_834;
    zT_1001656C_DebugSymbol zT_836;
    unsigned char zT_837;
    unsigned char zT_838;
    zT_6E8D187B_ModuleEntry* zT_839;
    zT_6E8D187B_ModuleEntry zT_840;
    unsigned int zT_841;
    unsigned int zT_842;
    zT_6E8D187B_ModuleEntry* zT_843;
    zT_6E8D187B_ModuleEntry zT_844;
    unsigned int zT_845;
    unsigned int zT_846;
    unsigned char zT_848;
    unsigned char zT_849;
    unsigned char zT_855;
    unsigned int zT_856;
    zT_6B0A7D14_AstStore* zT_860;
    unsigned int zT_861;
    zT_22A7C88B_AstNode zT_864 = {0};
    zT_8143F551_AstKind zT_865;
    unsigned char zT_869;
    zT_8143F551_AstKind zT_870;
    unsigned char zT_874;
    zT_8143F551_AstKind zT_875;
    unsigned char zT_879;
    unsigned int zT_882;
    zT_6B0A7D14_AstStore* zT_886;
    unsigned int zT_887;
    zT_22A7C88B_AstNode zT_890 = {0};
    zT_8143F551_AstKind zT_891;
    unsigned char zT_895;
    zT_8143F551_AstKind zT_896;
    zT_6B0A7D14_AstStore* zT_901;
    unsigned int zT_902;
    zT_22A7C88B_AstNode zT_905 = {0};
    zT_8143F551_AstKind zT_906;
    unsigned char zT_910;
    unsigned char zT_913;
    zT_6E8D187B_ModuleEntry* zT_920;
    zT_6E8D187B_ModuleEntry zT_921;
    unsigned int zT_922;
    zT_79FAE712_u64 zT_931;
    zT_A4CE86B7_U64ToU32Map* zT_932;
    zT_79FAE712_u64 zT_933;
    unsigned char zT_938;
    unsigned int zT_939;
    zT_6B0A7D14_AstStore* zT_943;
    unsigned int zT_944;
    zT_22A7C88B_AstNode zT_947 = {0};
    zT_8143F551_AstKind zT_948;
    unsigned char zT_952;
    unsigned char zT_955;
    zT_8EED1867_ResolvedTypeTable* zT_957;
    unsigned int zT_958;
    zT_BAEE192E_Opt_10 zT_960 = {0};
    unsigned char zT_962;
    unsigned int zT_963;
    unsigned char zT_967;
    unsigned char zT_968;
    unsigned char zT_974;
    zT_E1A783EF_GlobalDeclArrayList* zT_975;
    zT_54906056_ModuleGlobalDecl zT_976;
    zT_54906056_ModuleGlobalDecl zT_978;
    zT_6E8D187B_ModuleEntry* zT_979;
    zT_6E8D187B_ModuleEntry zT_980;
    unsigned int zT_981;
    unsigned int zT_982;
    zT_C98AF326_CompilerCli zT_983;
    unsigned char zT_984;
    zT_227EDE07_SourceManager* zT_986;
    unsigned int zT_987;
    unsigned int zT_988;
    zT_6E8D187B_ModuleEntry* zT_990;
    zT_6E8D187B_ModuleEntry zT_991;
    zT_5BC08DC6_Location zT_994 = {0};
    zT_8B83E3B4_DebugSymbolList* zT_995;
    zT_1001656C_DebugSymbol zT_996;
    zT_1001656C_DebugSymbol zT_998;
    unsigned char zT_999;
    unsigned char zT_1000;
    zT_6E8D187B_ModuleEntry* zT_1001;
    zT_6E8D187B_ModuleEntry zT_1002;
    unsigned int zT_1003;
    unsigned int zT_1004;
    zT_6E8D187B_ModuleEntry* zT_1005;
    zT_6E8D187B_ModuleEntry zT_1006;
    unsigned int zT_1007;
    unsigned int zT_1008;
    unsigned int zT_1010;
    zT_6B356268_SemanticContext* zT_1014;
    zT_3E40CD83_Sand* zT_1015;
    zT_69057089_CompilerAlloc* zT_1017;
    zT_02EB57B2_LirLowerer zT_1019 = {0};
    zT_6E8D187B_ModuleEntry* zT_1020;
    zT_6E8D187B_ModuleEntry zT_1021;
    unsigned int zT_1022;
    zT_072B53A6_ModuleRegistry* zT_1023;
    zT_C98AF326_CompilerCli zT_1024;
    unsigned char zT_1025;
    unsigned char zT_1026;
    int zT_1027;
    int zT_1029;
    zT_C98AF326_CompilerCli zT_1032;
    unsigned char zT_1033;
    zT_1F328BC1_DebugSpanArrayList zT_1034;
    int zT_1035;
    zT_02EB57B2_LirLowerer* zT_1037;
    zT_1F328BC1_DebugSpanArrayList* zT_1038;
    zT_02EB57B2_LirLowerer* zT_1040;
    unsigned int zT_1041;
    unsigned int zT_1042;
    zT_A4CE86B7_U64ToU32Map* zT_1043;
    zT_6E8D187B_ModuleEntry* zT_1045;
    zT_6E8D187B_ModuleEntry zT_1046;
    zT_6E8D187B_ModuleEntry* zT_1048;
    zT_6E8D187B_ModuleEntry zT_1049;
    zT_BBC23664_LirFunction zT_1052 = {0};
    zT_7E7544E4_LirStream* zT_1054;
    zT_BBC23664_LirFunction zT_1055;
    zT_E7714190_LirSlot zT_1057 = {0};
    zT_CA01C129_LirSlotArrayList* zT_1058;
    zT_E7714190_LirSlot zT_1059;
    zT_C98AF326_CompilerCli zT_1061;
    unsigned char zT_1062;
    zT_C615AE29_DebugSpanStore* zT_1063;
    unsigned int zT_1064;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_1065;
    zT_1F328BC1_DebugSpanArrayList zT_1068;
    zT_10BDA76C_DebugSpanEntry* zT_1069;
    zT_1F328BC1_DebugSpanArrayList zT_1070;
    unsigned int zT_1071;
    int zT_1072;
    zT_10BDA76C_DebugSpanEntry* zT_1073;
    unsigned int zT_1074;
    zT_34BFE5CB_Slice_zT_10BDA76C_D zT_1075;
    zT_1F328BC1_DebugSpanArrayList zT_1076;
    int zT_1077;
    zT_1F328BC1_DebugSpanArrayList* zT_1079;
    zT_3E40CD83_Sand* zT_1081;
    zT_69057089_CompilerAlloc* zT_1082;
    zT_072B53A6_ModuleRegistry* zT_1085;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_1087 = {0};
    unsigned int zT_1089;
    unsigned char zT_1092;
    zT_6E8D187B_ModuleEntry* zT_1093;
    int zT_1094;
    zT_6E8D187B_ModuleEntry zT_1095;
    unsigned int zT_1096;
    zT_6B0A7D14_AstStore* zT_1100;
    unsigned int zT_1101;
    zT_6E8D187B_ModuleEntry* zT_1103;
    int zT_1104;
    zT_6E8D187B_ModuleEntry zT_1105;
    zT_22A7C88B_AstNode zT_1107 = {0};
    zT_8143F551_AstKind zT_1108;
    zT_6B0A7D14_AstStore* zT_1113;
    unsigned int zT_1114;
    zT_6E8D187B_ModuleEntry* zT_1116;
    int zT_1117;
    zT_6E8D187B_ModuleEntry zT_1118;
    unsigned int zT_1120 = 0;
    unsigned int zT_1122;
    unsigned char* zT_1124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1125;
    unsigned int zT_1126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1127;
    zT_6B0A7D14_AstStore* zT_1131;
    unsigned int zT_1132;
    zT_6B0A7D14_AstStore* zT_1134;
    unsigned int zT_1135;
    zT_6E8D187B_ModuleEntry* zT_1138;
    int zT_1139;
    zT_6E8D187B_ModuleEntry zT_1140;
    unsigned int zT_1143 = 0;
    zT_22A7C88B_AstNode zT_1144 = {0};
    zT_8143F551_AstKind zT_1146;
    unsigned int zT_1147;
    zT_4028D896_Arr_unsigned_char_2 zT_1149;
    unsigned int zT_1151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1152;
    int zT_1155;
    unsigned char* zT_1156;
    unsigned int zT_1157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1158;
    unsigned int zT_1159 = 0;
    unsigned int zT_1163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1164;
    unsigned char* zT_1168;
    unsigned int zT_1169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1170;
    unsigned char* zT_1172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1173;
    unsigned int zT_1174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1175;
    unsigned int zT_1177;
    unsigned char* zT_1179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1180;
    unsigned int zT_1181;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1182;
    int zT_1183;
    unsigned int zT_1185;
    unsigned int zT_1187;
    unsigned int zT_1188;
    unsigned int* zT_1191;
    unsigned int zT_1192;
    zT_BBC23664_LirFunction* zT_1194;
    zT_A4CE86B7_U64ToU32Map* zT_1195;
    unsigned int zT_1196;
    unsigned int zT_1197;
    zT_9AD5FBED_Opt_453 zT_1201 = {0};
    unsigned char zT_1202;
    zT_5839647A_AsyncTransformCtx zT_1205;
    zT_69057089_CompilerAlloc* zT_1206;
    zT_3E40CD83_Sand* zT_1207;
    zT_338B7C76_TypeRegistry* zT_1208;
    zT_D3EB6303_StringInterner* zT_1209;
    zT_7E7544E4_LirStream* zT_1210;
    zT_CA01C129_LirSlotArrayList* zT_1211;
    zT_A4CE86B7_U64ToU32Map* zT_1212;
    zT_C98AF326_CompilerCli zT_1213;
    unsigned char zT_1214;
    zT_A4CE86B7_U64ToU32Map* zT_1215;
    zT_A4CE86B7_U64ToU32Map* zT_1216;
    zT_F85C5DED_DiagnosticCollector* zT_1217;
    zT_BBC23664_LirFunction* zT_1218;
    zT_5839647A_AsyncTransformCtx* zT_1219;
    unsigned char zT_1221 = 0;
    unsigned int zT_1223;
    zT_3E40CD83_Sand* zT_1224;
    zT_69057089_CompilerAlloc* zT_1225;
    zT_5AB29387_CompilerContext* zT_1227;
    zT_7E7544E4_LirStream* zT_1228;
    unsigned char zT_1230;
    unsigned char* zT_1234;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1235;
    unsigned int zT_1236;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_1237;
    zT_D3EB6303_StringInterner* zT_1238;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1239;
    zT_072B53A6_ModuleRegistry* zT_1240;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_1242 = {0};
    unsigned int zT_1244 = 0;
    unsigned char* zT_1248;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1249;
    unsigned int zT_1250;
    unsigned char* zT_1252;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1253;
    unsigned int zT_1254;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_1256;
    unsigned int zT_1257;
    unsigned int zT_1258;
    unsigned int zT_1259;
    zT_D3EB6303_StringInterner* zT_1261;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_1262;
    int zT_1265;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_1266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1268 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_1269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1275;
    unsigned int zT_1284 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnmsg;
    zT_4028D896_Arr_unsigned_char_2 ln_buf;
    unsigned int ln_len;
    unsigned int ln_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lemsg;
    zT_4028D896_Arr_unsigned_char_2 le_buf;
    unsigned int le_len;
    unsigned int le_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnl;
    zT_846744CC_Arr_unsigned_char_5 spill_path;
    unsigned int sp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmp_name;
    unsigned int ti;
    zT_846744CC_Arr_unsigned_char_5 dbg_path;
    unsigned int dp;
    zT_6B356268_SemanticContext sem_ctx;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_B687BB96_U32ArrayList async_retained;
    unsigned char async_pending;
    unsigned int mi;
    zT_8F083A69_Slice_zT_0B42B2F8_u odb;
    unsigned int oib;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_name;
    unsigned int dni;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm;
    zT_4028D896_Arr_unsigned_char_2 mi_buf;
    unsigned int mi_len;
    unsigned int mi2_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u msep;
    unsigned int arl_i;
    zT_4028D896_Arr_unsigned_char_2 ar_buf;
    unsigned int ar_len;
    unsigned int ar_start;
    zT_22A7C88B_AstNode root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr;
    unsigned int decls_n;
    unsigned int decl_len;
    zT_4028D896_Arr_unsigned_char_2 dcount_buf;
    unsigned int dcount_len;
    unsigned int dstart;
    unsigned char mod_has_ri;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int raw_k;
    zT_4028D896_Arr_unsigned_char_2 rbuf;
    unsigned int rlen;
    unsigned int rstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp2;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf;
    zT_243D6A41_FnProto fexp_proto;
    zT_79FAE712_u64 fexp_key;
    zT_02EB57B2_LirLowerer lowerer;
    zT_243D6A41_FnProto f_sym_proto;
    zT_5BC08DC6_Location f_sym_loc;
    zT_BBC23664_LirFunction lf;
    zT_3F3BF87A_AsyncFrameLayout async_layout;
    unsigned char* lf_raw;
    zT_E7714190_LirSlot slot;
    zT_BBC23664_LirFunction* lf_ptr;
    unsigned int gv_name;
    zT_77F031D4_Opt_960 gv_sym;
    zT_3A105EF1_Symbol* gvs;
    unsigned int gv_ctree;
    zT_22A7C88B_AstNode gv_i0;
    unsigned char gv_alias;
    zT_22A7C88B_AstNode gv_fb0;
    unsigned int croot;
    unsigned char gv_is_storage;
    zT_79FAE712_u64 gexp_key;
    zT_BAEE192E_Opt_10 gv_rt2;
    unsigned int gv_tid2;
    unsigned int grt2;
    zT_49DE1C22_ConstInitNode gv_rn;
    unsigned char gv_lv;
    zT_5BC08DC6_Location g_sym_loc;
    zT_22A7C88B_AstNode gv_init;
    zT_22A7C88B_AstNode gv_init3;
    zT_22A7C88B_AstNode gv_fb;
    unsigned char gv_has_ri;
    zT_22A7C88B_AstNode gv_init2;
    zT_BAEE192E_Opt_10 gv_rt;
    unsigned int gv_tid;
    unsigned int grt;
    unsigned char gv_lv2;
    zT_5BC08DC6_Location g2_sym_loc;
    zT_02EB57B2_LirLowerer ilowerer;
    zT_DDCD424B_Slice_zT_6E8D187B_M amods;
    zT_BBC23664_LirFunction imf;
    zT_E7714190_LirSlot islot;
    zT_22A7C88B_AstNode ar;
    unsigned int adl_n;
    unsigned int adi;
    zT_8F083A69_Slice_zT_0B42B2F8_u al;
    zT_22A7C88B_AstNode ad;
    unsigned int ak;
    zT_4028D896_Arr_unsigned_char_2 ab;
    unsigned int alen;
    unsigned int ast;
    zT_8F083A69_Slice_zT_0B42B2F8_u asp;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_BBC23664_LirFunction* lf2;
    zT_3F3BF87A_AsyncFrameLayout* lay2;
    zT_5839647A_AsyncTransformCtx async_ctx2;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = "L\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = "nodes=";
    zT_9 = 6;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    lnmsg = zT_8;
    zT_10 = lnmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ln_buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_16 = ctx->store;
    zT_17 = zT_16->nodes;
    zT_18 = zT_17.len;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)ln_buf) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = (unsigned char*)zT_23;
    zT_25.len = zT_24;
    zT_15 = zT_25;
    zT_26 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_18), zT_15);
    ln_len = zT_26;
    zT_30 = (unsigned int)(19) - (unsigned int)((unsigned int)ln_len);
    ln_start = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)ln_buf) + ln_start;
    zT_36 = (unsigned int)(19) - ln_start;
    zT_37.ptr = (unsigned char*)zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = " extra=";
    zT_41 = 7;
    zT_40.ptr = (unsigned char*)zT_39;
    zT_40.len = zT_41;
    lemsg = zT_40;
    zT_42 = lemsg;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        le_buf[_i] = zT_44[_i];
        _i++;
    }
}
    zT_48 = ctx->store;
    zT_49 = zT_48->extra_children;
    zT_50 = zT_49.len;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)le_buf) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = (unsigned char*)zT_55;
    zT_57.len = zT_56;
    zT_47 = zT_57;
    zT_58 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_50), zT_47);
    le_len = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)le_len);
    le_start = zT_62;
    zT_67 = (unsigned char*)((unsigned char*)le_buf) + le_start;
    zT_68 = (unsigned int)(19) - le_start;
    zT_69.ptr = (unsigned char*)zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zF_48AC7B3A_markerWrite(zT_63);
    zT_71 = "\n";
    zT_73 = 1;
    zT_72.ptr = (unsigned char*)zT_71;
    zT_72.len = zT_73;
    lnl = zT_72;
    zT_74 = lnl;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_76 = ctx->alloc;
    zT_75 = &zT_76->scratch;
    zF_F1B3F8C2_sandReset(zT_75);
    zT_79 = &ctx->lir_slots;
    zT_79->len = (unsigned int)(0);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_81[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        spill_path[_i] = zT_81[_i];
        _i++;
    }
}
    zT_83 = 0;
    sp_len = zT_83;
    zT_84 = ctx->cli;
    zT_85 = zT_84.output_dir_set;
    if (zT_85) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_87 = ctx->cli;
    zT_88 = zT_87.output_dir;
    od = zT_88;
    zT_90 = 0;
    oi = zT_90;
    goto z_bb_4;
    z_bb_2:
    zT_113 = ".zig1_lir.tmp";
    zT_115 = 13;
    zT_114.ptr = (unsigned char*)zT_113;
    zT_114.len = zT_115;
    tmp_name = zT_114;
    zT_117 = 0;
    ti = zT_117;
    goto z_bb_11;
    z_bb_3:
    zT_106 = 46;
    spill_path[sp_len] = zT_106;
    zT_108 = sp_len + (unsigned int)(1);
    sp_len = zT_108;
    zT_109 = 47;
    spill_path[sp_len] = zT_109;
    zT_111 = sp_len + (unsigned int)(1);
    sp_len = zT_111;
    goto z_bb_2;
    z_bb_4:
    zT_92 = od.len;
    if ((unsigned char)(oi < zT_92)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_97 = od.ptr;
    zT_98 = zT_97[oi];
    spill_path[sp_len] = zT_98;
    zT_100 = sp_len + (unsigned int)(1);
    sp_len = zT_100;
    goto z_bb_7;
    z_bb_6:
    zT_103 = 47;
    spill_path[sp_len] = zT_103;
    zT_105 = sp_len + (unsigned int)(1);
    sp_len = zT_105;
    goto z_bb_2;
    z_bb_7:
    zT_102 = oi + (unsigned int)(1);
    oi = zT_102;
    goto z_bb_4;
    z_bb_8:
    zT_94 = sp_len < (unsigned int)(511);
    goto z_bb_10;
    z_bb_9:
    zT_94 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_94) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    zT_119 = tmp_name.len;
    if ((unsigned char)(ti < zT_119)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_124 = tmp_name.ptr;
    zT_125 = zT_124[ti];
    spill_path[sp_len] = zT_125;
    zT_127 = sp_len + (unsigned int)(1);
    sp_len = zT_127;
    goto z_bb_14;
    z_bb_13:
    zT_130 = &ctx->lir_stream;
    zT_136 = 0;
    zT_137 = (unsigned char*)((unsigned char*)spill_path) + zT_136;
    zT_138 = sp_len - zT_136;
    zT_139.ptr = (unsigned char*)zT_137;
    zT_139.len = zT_138;
    zT_131 = zT_139;
    zT_140 = ctx->alloc;
    zT_132 = &zT_140->emission;
    zF_B0B74E20_lirStreamBeginWrite(zT_130, zT_131, zT_132);
    zT_142 = ctx->cli;
    zT_143 = zT_142.debug;
    if (zT_143) goto z_bb_18; else goto z_bb_19;
    z_bb_14:
    zT_129 = ti + (unsigned int)(1);
    ti = zT_129;
    goto z_bb_11;
    z_bb_15:
    zT_121 = sp_len < (unsigned int)(511);
    goto z_bb_17;
    z_bb_16:
    zT_121 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_121) goto z_bb_12; else goto z_bb_13;
    z_bb_18:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_145[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        dbg_path[_i] = zT_145[_i];
        _i++;
    }
}
    zT_147 = 0;
    dp = zT_147;
    zT_148 = ctx->cli;
    zT_149 = zT_148.output_dir_set;
    if (zT_149) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    zT_208 = ctx->store;
    zT_207.store = zT_208;
    zT_209 = ctx->typereg;
    zT_207.registry = zT_209;
    zT_210 = ctx->symbol_reg;
    zT_207.symbol_tables = zT_210;
    zT_211 = ctx->resolved_types;
    zT_207.resolved_types = zT_211;
    zT_212 = ctx->coercion_table;
    zT_207.coercions = zT_212;
    zT_213 = ctx->diag;
    zT_207.diag = zT_213;
    zT_214 = 1;
    zT_207.has_symbols = zT_214;
    zT_215 = &ctx->enum_value_table;
    zT_207.enum_value_table = zT_215;
    zT_216 = &ctx->tuple_index_table;
    zT_207.tuple_index_table = zT_216;
    zT_217 = &ctx->error_code_registry;
    zT_207.error_code_registry = zT_217;
    zT_218 = &ctx->call_arg_types;
    zT_207.call_arg_types = zT_218;
    zT_219 = &ctx->comptime_folds;
    zT_207.comptime_folds = zT_219;
    zT_220 = &ctx->const_inits;
    zT_207.const_inits = zT_220;
    zT_221 = 0;
    zT_207.source_file_id = zT_221;
    zT_222 = ctx->cli;
    zT_223 = zT_222.safe_checks;
    zT_207.safe_checks = zT_223;
    zT_224 = &ctx->suspending_fns;
    zT_207.suspending_fns = zT_224;
    zT_225 = &ctx->frame_sizes;
    zT_207.frame_sizes = zT_225;
    zT_226 = &ctx->state_widths;
    zT_207.state_widths = zT_226;
    zT_227 = 0;
    zT_207.print_value_lowered = zT_227;
    sem_ctx = zT_207;
    zT_229 = ctx->module_reg;
    zT_231 = zF_3452C137_moduleRegistryGetMo(zT_229);
    mods = zT_231;
    zT_234 = ctx->alloc;
    zT_233 = &zT_234->module;
    zT_236 = zF_8E537D0C_u32ArrayListInit(zT_233);
    async_retained = zT_236;
    zT_238 = 0;
    async_pending = zT_238;
    zT_240 = 0;
    zT_241 = (unsigned int)zT_240;
    mi = zT_241;
    goto z_bb_37;
    z_bb_20:
    zT_151 = ctx->cli;
    zT_152 = zT_151.output_dir;
    odb = zT_152;
    zT_154 = 0;
    oib = zT_154;
    goto z_bb_23;
    z_bb_21:
    zT_177 = ".zig1_dbg.tmp";
    zT_179 = 13;
    zT_178.ptr = (unsigned char*)zT_177;
    zT_178.len = zT_179;
    dbg_name = zT_178;
    zT_181 = 0;
    dni = zT_181;
    goto z_bb_30;
    z_bb_22:
    zT_170 = 46;
    dbg_path[dp] = zT_170;
    zT_172 = dp + (unsigned int)(1);
    dp = zT_172;
    zT_173 = 47;
    dbg_path[dp] = zT_173;
    zT_175 = dp + (unsigned int)(1);
    dp = zT_175;
    goto z_bb_21;
    z_bb_23:
    zT_156 = odb.len;
    if ((unsigned char)(oib < zT_156)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_161 = odb.ptr;
    zT_162 = zT_161[oib];
    dbg_path[dp] = zT_162;
    zT_164 = dp + (unsigned int)(1);
    dp = zT_164;
    goto z_bb_26;
    z_bb_25:
    zT_167 = 47;
    dbg_path[dp] = zT_167;
    zT_169 = dp + (unsigned int)(1);
    dp = zT_169;
    goto z_bb_21;
    z_bb_26:
    zT_166 = oib + (unsigned int)(1);
    oib = zT_166;
    goto z_bb_23;
    z_bb_27:
    zT_158 = dp < (unsigned int)(511);
    goto z_bb_29;
    z_bb_28:
    zT_158 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_158) goto z_bb_24; else goto z_bb_25;
    z_bb_30:
    zT_183 = dbg_name.len;
    if ((unsigned char)(dni < zT_183)) goto z_bb_34; else goto z_bb_35;
    z_bb_31:
    zT_188 = dbg_name.ptr;
    zT_189 = zT_188[dni];
    dbg_path[dp] = zT_189;
    zT_191 = dp + (unsigned int)(1);
    dp = zT_191;
    goto z_bb_33;
    z_bb_32:
    zT_194 = &ctx->debug_spans;
    zT_198 = ctx->alloc;
    zT_195 = &zT_198->emission;
    zT_202 = 0;
    zT_203 = (unsigned char*)((unsigned char*)dbg_path) + zT_202;
    zT_204 = dp - zT_202;
    zT_205.ptr = (unsigned char*)zT_203;
    zT_205.len = zT_204;
    zT_196 = zT_205;
    zF_7FA61CF5_debugSpanStoreOpen(zT_194, zT_195, zT_196);
    goto z_bb_19;
    z_bb_33:
    zT_193 = dni + (unsigned int)(1);
    dni = zT_193;
    goto z_bb_30;
    z_bb_34:
    zT_185 = dp < (unsigned int)(511);
    goto z_bb_36;
    z_bb_35:
    zT_185 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_185) goto z_bb_31; else goto z_bb_32;
    z_bb_37:
    zT_243 = mods.len;
    if ((unsigned char)(mi < zT_243)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_245 = mods.ptr;
    zT_246 = zT_245[mi];
    zT_247 = zT_246.source_file_id;
    sem_ctx.source_file_id = zT_247;
    zT_249 = "M";
    zT_251 = 1;
    zT_250.ptr = (unsigned char*)zT_249;
    zT_250.len = zT_251;
    mm = zT_250;
    zT_252 = mm;
    zF_48AC7B3A_markerWrite(zT_252);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_254[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        mi_buf[_i] = zT_254[_i];
        _i++;
    }
}
    zT_261 = 0;
    zT_262 = (unsigned char*)((unsigned char*)mi_buf) + zT_261;
    zT_263 = (unsigned int)(20) - zT_261;
    zT_264.ptr = (unsigned char*)zT_262;
    zT_264.len = zT_263;
    zT_257 = zT_264;
    zT_265 = zF_A7504564_itoa((unsigned int)((unsigned int)mi), zT_257);
    mi_len = zT_265;
    zT_269 = (unsigned int)(19) - (unsigned int)((unsigned int)mi_len);
    mi2_start = zT_269;
    zT_274 = (unsigned char*)((unsigned char*)mi_buf) + mi2_start;
    zT_275 = (unsigned int)(19) - mi2_start;
    zT_276.ptr = (unsigned char*)zT_274;
    zT_276.len = zT_275;
    zT_270 = zT_276;
    zF_48AC7B3A_markerWrite(zT_270);
    zT_278 = ":";
    zT_280 = 1;
    zT_279.ptr = (unsigned char*)zT_278;
    zT_279.len = zT_280;
    msep = zT_279;
    zT_281 = msep;
    zF_48AC7B3A_markerWrite(zT_281);
    zT_282 = mods.ptr;
    zT_283 = zT_282[mi];
    zT_284 = zT_283.ast_root;
    if ((unsigned char)(zT_284 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    zT_1187 = 0;
    arl_i = zT_1187;
    goto z_bb_199;
    z_bb_40:
    zT_1183 = 1;
    zT_1185 = mi + (unsigned int)((unsigned int)zT_1183);
    mi = zT_1185;
    goto z_bb_37;
    z_bb_41:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_288[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ar_buf[_i] = zT_288[_i];
        _i++;
    }
}
    zT_292 = mods.ptr;
    zT_293 = zT_292[mi];
    zT_290 = zT_293.ast_root;
    zT_297 = 0;
    zT_298 = (unsigned char*)((unsigned char*)ar_buf) + zT_297;
    zT_299 = (unsigned int)(20) - zT_297;
    zT_300.ptr = (unsigned char*)zT_298;
    zT_300.len = zT_299;
    zT_291 = zT_300;
    zT_301 = zF_A7504564_itoa(zT_290, zT_291);
    ar_len = zT_301;
    zT_305 = (unsigned int)(19) - (unsigned int)((unsigned int)ar_len);
    ar_start = zT_305;
    zT_310 = (unsigned char*)((unsigned char*)ar_buf) + ar_start;
    zT_311 = (unsigned int)(19) - ar_start;
    zT_312.ptr = (unsigned char*)zT_310;
    zT_312.len = zT_311;
    zT_306 = zT_312;
    zF_48AC7B3A_markerWrite(zT_306);
    zT_313 = msep;
    zF_48AC7B3A_markerWrite(zT_313);
    zT_315 = ctx->store;
    zT_318 = mods.ptr;
    zT_319 = zT_318[mi];
    zT_316 = zT_319.ast_root;
    zT_321 = zF_FCDD1D35_astStoreNodeAt(zT_315, zT_316);
    root = zT_321;
    zT_322 = root.kind;
    if ((unsigned char)(zT_322 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_327 = "R";
    zT_329 = 1;
    zT_328.ptr = (unsigned char*)zT_327;
    zT_328.len = zT_329;
    mr = zT_328;
    zT_330 = mr;
    zF_48AC7B3A_markerWrite(zT_330);
    zT_332 = ctx->store;
    zT_335 = mods.ptr;
    zT_336 = zT_335[mi];
    zT_333 = zT_336.ast_root;
    zT_338 = zF_152E19CB_astStoreNodeExtraCh(zT_332, zT_333);
    decls_n = zT_338;
    zT_340 = (unsigned int)decls_n;
    decl_len = zT_340;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_342[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dcount_buf[_i] = zT_342[_i];
        _i++;
    }
}
    zT_344 = decl_len;
    zT_348 = 0;
    zT_349 = (unsigned char*)((unsigned char*)dcount_buf) + zT_348;
    zT_350 = (unsigned int)(20) - zT_348;
    zT_351.ptr = (unsigned char*)zT_349;
    zT_351.len = zT_350;
    zT_345 = zT_351;
    zT_352 = zF_A7504564_itoa(zT_344, zT_345);
    dcount_len = zT_352;
    zT_356 = (unsigned int)(19) - (unsigned int)((unsigned int)dcount_len);
    dstart = zT_356;
    zT_361 = (unsigned char*)((unsigned char*)dcount_buf) + dstart;
    zT_362 = (unsigned int)(19) - dstart;
    zT_363.ptr = (unsigned char*)zT_361;
    zT_363.len = zT_362;
    zT_357 = zT_363;
    zF_48AC7B3A_markerWrite(zT_357);
    zT_364 = msep;
    zF_48AC7B3A_markerWrite(zT_364);
    zT_365 = ctx->store;
    zT_369 = mods.ptr;
    zT_370 = zT_369[mi];
    zT_366 = zT_370.ast_root;
    zT_372 = mods.ptr;
    zT_373 = zT_372 + mi;
    zT_367 = &zT_373->c_includes;
    zF_7D71E4ED_moduleRegistryColle(zT_365, zT_366, zT_367);
    zT_376 = 0;
    mod_has_ri = zT_376;
    zT_378 = 0;
    di = zT_378;
    goto z_bb_45;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_382 = ctx->store;
    zT_386 = mods.ptr;
    zT_387 = zT_386[mi];
    zT_383 = zT_387.ast_root;
    zT_390 = zF_B10B1BC1_astStoreNodeExtraCh(zT_382, zT_383, (unsigned int)((unsigned int)di));
    decl_idx = zT_390;
    zT_392 = ctx->store;
    zT_393 = decl_idx;
    zT_395 = zF_FCDD1D35_astStoreNodeAt(zT_392, zT_393);
    decl = zT_395;
    zT_397 = decl.kind;
    zT_398 = (unsigned int)zT_397;
    raw_k = zT_398;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_400[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rbuf[_i] = zT_400[_i];
        _i++;
    }
}
    zT_402 = raw_k;
    zT_406 = 0;
    zT_407 = (unsigned char*)((unsigned char*)rbuf) + zT_406;
    zT_408 = (unsigned int)(20) - zT_406;
    zT_409.ptr = (unsigned char*)zT_407;
    zT_409.len = zT_408;
    zT_403 = zT_409;
    zT_410 = zF_A7504564_itoa(zT_402, zT_403);
    rlen = zT_410;
    zT_414 = (unsigned int)(19) - (unsigned int)((unsigned int)rlen);
    rstart = zT_414;
    zT_419 = (unsigned char*)((unsigned char*)rbuf) + rstart;
    zT_420 = (unsigned int)(19) - rstart;
    zT_421.ptr = (unsigned char*)zT_419;
    zT_421.len = zT_420;
    zT_415 = zT_421;
    zF_48AC7B3A_markerWrite(zT_415);
    zT_423 = " ";
    zT_425 = 1;
    zT_424.ptr = (unsigned char*)zT_423;
    zT_424.len = zT_425;
    sp2 = zT_424;
    zT_426 = sp2;
    zF_48AC7B3A_markerWrite(zT_426);
    zT_427 = decl.kind;
    if ((unsigned char)(zT_427 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_49; else goto z_bb_51;
    z_bb_47:
    if ((unsigned char)(mod_has_ri != (unsigned char)(0))) goto z_bb_177; else goto z_bb_178;
    z_bb_48:
    zT_1010 = di + (unsigned int)(1);
    di = zT_1010;
    goto z_bb_45;
    z_bb_49:
    zT_432 = "F";
    zT_434 = 1;
    zT_433.ptr = (unsigned char*)zT_432;
    zT_433.len = zT_434;
    mf = zT_433;
    zT_435 = mf;
    zF_48AC7B3A_markerWrite(zT_435);
    zT_436 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_436) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_648 = decl.kind;
    if ((unsigned char)(zT_648 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_76; else goto z_bb_77;
    z_bb_52:
    zT_443 = ctx->store;
    zT_444 = zT_443->fn_protos;
    zT_445 = zT_444.items;
    zT_446 = ctx->store;
    zT_447 = decl_idx;
    zT_449 = zF_8BA26B9E_astStoreNodePayload(zT_446, zT_447);
    zT_450 = (unsigned int)zT_449;
    zT_451 = zT_445[zT_450];
    fexp_proto = zT_451;
    zT_453 = mods.ptr;
    zT_454 = zT_453[mi];
    zT_455 = zT_454.id;
    zT_463 = fexp_proto.name_id;
    zT_465 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_455) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(0)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_463);
    fexp_key = zT_465;
    zT_466 = &ctx->exported;
    zT_467 = fexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_466, zT_467, (unsigned int)(1));
    goto z_bb_53;
    z_bb_53:
    zT_472 = (zT_6B356268_SemanticContext*)&sem_ctx;
    zT_475 = ctx->alloc;
    zT_473 = &zT_475->scratch;
    zT_477 = zF_ADD4254B_lowererInit(zT_472, zT_473);
    lowerer = zT_477;
    zT_478 = mods.ptr;
    zT_479 = zT_478[mi];
    zT_480 = zT_479.id;
    lowerer.module_id = zT_480;
    zT_481 = ctx->module_reg;
    lowerer.module_reg = zT_481;
    zT_482 = ctx->cli;
    zT_483 = zT_482.debug;
    if (zT_483) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_485 = 1;
    zT_484 = (unsigned char)zT_485;
    goto z_bb_56;
    z_bb_55:
    zT_487 = 0;
    zT_484 = (unsigned char)zT_487;
    goto z_bb_56;
    z_bb_56:
    lowerer.debug_enabled = (unsigned char)((unsigned char)zT_484);
    zT_490 = ctx->cli;
    zT_491 = zT_490.debug;
    if (zT_491) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_493 = ctx->store;
    zT_494 = zT_493->fn_protos;
    zT_495 = zT_494.items;
    zT_496 = ctx->store;
    zT_497 = decl_idx;
    zT_499 = zF_8BA26B9E_astStoreNodePayload(zT_496, zT_497);
    zT_500 = (unsigned int)zT_499;
    zT_501 = zT_495[zT_500];
    f_sym_proto = zT_501;
    zT_503 = ctx->source_man;
    zT_507 = mods.ptr;
    zT_508 = zT_507[mi];
    zT_504 = zT_508.source_file_id;
    zT_505 = decl.span_start;
    zT_511 = zF_4966CE4A_sourceManagerGetLoc(zT_503, zT_504, zT_505);
    f_sym_loc = zT_511;
    zT_514 = &ctx->debug_symbols;
    zT_512 = zT_514;
    zT_516 = 0;
    zT_515.kind = zT_516;
    zT_517 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_517) & (unsigned short)(4)) != (unsigned short)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    zT_539 = ctx->cli;
    zT_540 = zT_539.debug;
    if (zT_540) goto z_bb_62; else goto z_bb_63;
    z_bb_59:
    zT_524 = 1;
    zT_523 = (unsigned char)zT_524;
    goto z_bb_61;
    z_bb_60:
    zT_526 = 0;
    zT_523 = (unsigned char)zT_526;
    goto z_bb_61;
    z_bb_61:
    zT_528 = (unsigned char)zT_523;
    zT_515.is_extern = zT_528;
    zT_529 = f_sym_proto.name_id;
    zT_515.name_id = zT_529;
    zT_530 = mods.ptr;
    zT_531 = zT_530[mi];
    zT_532 = zT_531.id;
    zT_515.module_id = zT_532;
    zT_533 = 0;
    zT_515.type_id = zT_533;
    zT_534 = f_sym_loc.line;
    zT_515.src_line = zT_534;
    zT_535 = mods.ptr;
    zT_536 = zT_535[mi];
    zT_537 = zT_536.source_file_id;
    zT_515.src_file_id = zT_537;
    zT_538 = decl.span_start;
    zT_515.decl_span = zT_538;
    zT_513 = zT_515;
    zF_3CC05A74_debugSymbolListAppe(zT_512, zT_513);
    goto z_bb_58;
    z_bb_62:
    zT_541 = ctx->debug_span_buf;
    lowerer.debug_spans = zT_541;
    zT_542 = 0;
    zT_544 = (zT_02EB57B2_LirLowerer*)&lowerer;
    zT_545 = &zT_544->debug_spans;
    zT_545->len = (unsigned int)((unsigned int)zT_542);
    goto z_bb_63;
    z_bb_63:
    zT_547 = (zT_02EB57B2_LirLowerer*)&lowerer;
    zT_548 = decl_idx;
    zT_550 = zF_B53F5F2E_lowerFn(zT_547, zT_548);
    lf = zT_550;
    zT_551 = &ctx->suspending_fns;
    zT_552 = lf.module_id;
    zT_553 = lf.name_id;
    zT_557 = zF_7C7E43BF_asyncIsSuspending(zT_551, zT_552, zT_553);
    if (zT_557) goto z_bb_64; else goto z_bb_66;
    z_bb_64:
    zT_571 = ctx->alloc;
    zT_559 = &zT_571->scratch;
    zT_560 = ctx->typereg;
    zT_561 = (zT_BBC23664_LirFunction*)&lf;
    zT_562 = &ctx->suspending_fns;
    zT_563 = &ctx->frame_sizes;
    zT_564 = &ctx->state_widths;
    zT_565 = &ctx->awaited_fns;
    zT_566 = &ctx->async_hidden_fns;
    zT_567 = &ctx->driver_targets;
    zT_568 = &ctx->parent_result_type_list;
    zT_569 = &ctx->parent_result_start;
    zT_570 = &ctx->parent_result_count;
    zT_584 = zF_28031796_asyncLayoutFrame(zT_559, zT_560, zT_561, zT_562, zT_563, zT_564, zT_565, zT_566, zT_567, zT_568, zT_569, zT_570);
    async_layout = zT_584;
    zT_590 = ctx->alloc;
    zT_585 = &zT_590->scratch;
    zT_586 = &ctx->async_layouts;
    zT_587 = lf.module_id;
    zT_588 = lf.name_id;
    zT_589 = async_layout;
    zF_17324878_asyncLayoutPublish(zT_585, zT_586, zT_587, zT_588, zT_589);
    zT_599 = ctx->alloc;
    zT_596 = &zT_599->scratch;
    zT_603 = zF_1395EB68_sandAlloc(zT_596, (unsigned int)(124), (unsigned int)(4));
    zT_604 = zT_603.is_error;
    if (zT_604) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    zT_642 = ctx->cli;
    zT_643 = zT_642.debug;
    if (zT_643) goto z_bb_74; else goto z_bb_75;
    z_bb_66:
    zT_616 = &ctx->lir_stream;
    zT_617 = lf;
    zT_619 = zF_9F47D5E4_lirStreamAppend(zT_616, zT_617);
    slot = zT_619;
    zT_620 = &ctx->lir_slots;
    zT_621 = slot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_620, zT_621);
    zT_623 = ctx->cli;
    zT_624 = zT_623.debug;
    if (zT_624) goto z_bb_70; else goto z_bb_71;
    z_bb_67:
    pal_trap();
    z_bb_68:
    zT_605 = zT_603.data.payload;
    goto z_bb_69;
    z_bb_69:
    lf_raw = zT_605;
    zT_608 = (zT_BBC23664_LirFunction*)lf_raw;
    lf_ptr = zT_608;
    *lf_ptr = lf;
    zT_609 = (zT_B687BB96_U32ArrayList*)&async_retained;
    zF_62F717A2_u32ArrayListAppend(zT_609, (unsigned int)((unsigned int)(unsigned int)((unsigned int)lf_ptr)));
    zT_614 = 1;
    async_pending = zT_614;
    goto z_bb_65;
    z_bb_70:
    zT_625 = &ctx->debug_spans;
    zT_626 = slot.disk_offset;
    zT_630 = lowerer.debug_spans;
    zT_631 = zT_630.items;
    zT_632 = lowerer.debug_spans;
    zT_633 = zT_632.len;
    zT_634 = 0;
    zT_635 = zT_631 + zT_634;
    zT_636 = zT_633 - zT_634;
    zT_637.ptr = (zT_10BDA76C_DebugSpanEntry*)zT_635;
    zT_637.len = zT_636;
    zT_627 = zT_637;
    zF_BB256CBD_debugSpanStoreAppen(zT_625, zT_626, zT_627);
    goto z_bb_71;
    z_bb_71:
    if ((unsigned char)(!async_pending)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_640 = ctx->alloc;
    zT_639 = &zT_640->scratch;
    zF_F1B3F8C2_sandReset(zT_639);
    goto z_bb_73;
    z_bb_73:
    goto z_bb_65;
    z_bb_74:
    zT_644 = lowerer.debug_spans;
    ctx->debug_span_buf = zT_644;
    zT_645 = 0;
    zT_647 = &ctx->debug_span_buf;
    zT_647->len = (unsigned int)((unsigned int)zT_645);
    goto z_bb_75;
    z_bb_75:
    goto z_bb_50;
    z_bb_76:
    zT_652 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_652) & (unsigned short)(4)) == (unsigned short)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_77:
    goto z_bb_50;
    z_bb_78:
    zT_659 = ctx->store;
    zT_660 = decl_idx;
    zT_662 = zF_8BA26B9E_astStoreNodePayload(zT_659, zT_660);
    gv_name = zT_662;
    zT_664 = ctx->symbol_reg;
    zT_668 = mods.ptr;
    zT_669 = zT_668[mi];
    zT_665 = zT_669.id;
    zT_666 = gv_name;
    zT_671 = zF_A398987E_symbolRegistryQuali(zT_664, zT_665, zT_666);
    gv_sym = zT_671;
    zT_672 = gv_sym.has_value;
    if (zT_672) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    goto z_bb_77;
    z_bb_80:
    gvs = gv_sym.value;
    zT_674 = gvs->kind;
    if ((unsigned char)(zT_674 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_679 = 4294967295u;
    gv_ctree = zT_679;
    zT_680 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_680) & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    zT_687 = decl.child_1;
    zT_686 = zT_687 != (unsigned int)(0);
    goto z_bb_86;
    z_bb_85:
    zT_686 = 0;
    goto z_bb_86;
    z_bb_86:
    if (zT_686) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_691 = ctx->store;
    zT_692 = decl.child_1;
    zT_695 = zF_FCDD1D35_astStoreNodeAt(zT_691, zT_692);
    gv_i0 = zT_695;
    zT_697 = 0;
    gv_alias = zT_697;
    zT_698 = gv_i0.kind;
    if ((unsigned char)(zT_698 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    if ((unsigned char)(gv_ctree != (unsigned int)(4294967295u))) goto z_bb_101; else goto z_bb_103;
    z_bb_89:
    zT_702 = 1;
    gv_alias = zT_702;
    goto z_bb_90;
    z_bb_90:
    zT_703 = gv_i0.kind;
    if ((unsigned char)(zT_703 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_708 = ctx->store;
    zT_709 = gv_i0.child_0;
    zT_712 = zF_FCDD1D35_astStoreNodeAt(zT_708, zT_709);
    gv_fb0 = zT_712;
    zT_713 = gv_fb0.kind;
    if ((unsigned char)(zT_713 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    if ((unsigned char)(gv_alias == (unsigned char)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_93:
    zT_717 = 1;
    gv_alias = zT_717;
    goto z_bb_94;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    zT_722 = &ctx->const_inits;
    zT_720 = &zT_722->roots;
    zT_721 = decl_idx;
    zT_724 = zF_F3EE5998_u32ToU32MapGet(zT_720, zT_721);
    zT_725 = zT_724.has_value;
    if (zT_725) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    goto z_bb_88;
    z_bb_97:
    croot = zT_724.value;
    if ((unsigned char)(croot != (unsigned int)(4294967295u))) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    goto z_bb_96;
    z_bb_99:
    gv_ctree = croot;
    goto z_bb_100;
    z_bb_100:
    goto z_bb_98;
    z_bb_101:
    zT_731 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_731) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_104; else goto z_bb_105;
    z_bb_102:
    goto z_bb_83;
    z_bb_103:
    zT_848 = 0;
    gv_is_storage = zT_848;
    zT_849 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_849) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_137; else goto z_bb_139;
    z_bb_104:
    zT_738 = mods.ptr;
    zT_739 = zT_738[mi];
    zT_740 = zT_739.id;
    zT_749 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_740) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(Z98_U64_C(4294967296))) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_749;
    zT_750 = &ctx->exported;
    zT_751 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_750, zT_751, (unsigned int)(1));
    goto z_bb_105;
    z_bb_105:
    zT_756 = ctx->resolved_types;
    zT_757 = decl_idx;
    zT_759 = zF_999DCF51_resolvedTypeTableGe(zT_756, zT_757);
    gv_rt2 = zT_759;
    zT_761 = gv_rt2.has_value;
    if (zT_761) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    grt2 = gv_rt2.value;
    zT_762 = grt2;
    goto z_bb_108;
    z_bb_107:
    zT_762 = 18;
    goto z_bb_108;
    z_bb_108:
    gv_tid2 = zT_762;
    if ((unsigned char)(gv_tid2 == (unsigned int)(19))) goto z_bb_110; else goto z_bb_109;
    z_bb_109:
    zT_767 = gv_tid2 == (unsigned int)(18);
    goto z_bb_111;
    z_bb_110:
    zT_767 = 1;
    goto z_bb_111;
    z_bb_111:
    if (zT_767) goto z_bb_113; else goto z_bb_112;
    z_bb_112:
    zT_770 = gv_tid2 == (unsigned int)(0);
    goto z_bb_114;
    z_bb_113:
    zT_770 = 1;
    goto z_bb_114;
    z_bb_114:
    if (zT_770) goto z_bb_115; else goto z_bb_116;
    z_bb_115:
    zT_774 = &ctx->const_inits;
    zT_775 = gv_ctree;
    zT_777 = zF_C30CDA77_constInitNodeAt(zT_774, zT_775);
    gv_rn = zT_777;
    zT_778 = gv_rn.kind;
    if ((unsigned char)(zT_778 == (unsigned char)(1))) goto z_bb_118; else goto z_bb_117;
    z_bb_116:
    zT_805 = 0;
    gv_lv = zT_805;
    zT_806 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_806) & (unsigned short)(10)) != (unsigned short)(0))) goto z_bb_133; else goto z_bb_134;
    z_bb_117:
    zT_782 = gv_rn.kind;
    zT_781 = zT_782 == (unsigned char)(4);
    goto z_bb_119;
    z_bb_118:
    zT_781 = 1;
    goto z_bb_119;
    z_bb_119:
    if (zT_781) goto z_bb_120; else goto z_bb_122;
    z_bb_120:
    zT_785 = 10;
    gv_tid2 = zT_785;
    zT_786 = gv_rn.b;
    if ((unsigned char)((unsigned int)(zT_786 & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_123; else goto z_bb_125;
    z_bb_121:
    goto z_bb_116;
    z_bb_122:
    zT_796 = gv_rn.kind;
    if ((unsigned char)(zT_796 == (unsigned char)(3))) goto z_bb_128; else goto z_bb_130;
    z_bb_123:
    zT_791 = 7;
    gv_tid2 = zT_791;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_792 = gv_rn.a;
    if ((unsigned char)(zT_792 > (zT_79FAE712_u64)(4294967295u))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_795 = 11;
    gv_tid2 = zT_795;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_124;
    z_bb_128:
    zT_799 = 2;
    gv_tid2 = zT_799;
    goto z_bb_129;
    z_bb_129:
    goto z_bb_121;
    z_bb_130:
    zT_800 = gv_rn.kind;
    if ((unsigned char)(zT_800 == (unsigned char)(2))) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_803 = 16;
    gv_tid2 = zT_803;
    goto z_bb_132;
    z_bb_132:
    goto z_bb_129;
    z_bb_133:
    zT_812 = 1;
    gv_lv = zT_812;
    goto z_bb_134;
    z_bb_134:
    zT_813 = &ctx->global_decls;
    zT_816.name_id = gv_name;
    zT_817 = mods.ptr;
    zT_818 = zT_817[mi];
    zT_819 = zT_818.id;
    zT_816.module_id = zT_819;
    zT_816.type_id = gv_tid2;
    zT_820 = 0;
    zT_816.has_runtime_init = zT_820;
    zT_816.const_init = gv_ctree;
    zT_816.link_visible = gv_lv;
    zT_814 = zT_816;
    zF_F2C82CE7_globalDeclArrayList(zT_813, zT_814);
    zT_821 = ctx->cli;
    zT_822 = zT_821.debug;
    if (zT_822) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_824 = ctx->source_man;
    zT_828 = mods.ptr;
    zT_829 = zT_828[mi];
    zT_825 = zT_829.source_file_id;
    zT_826 = decl.span_start;
    zT_832 = zF_4966CE4A_sourceManagerGetLoc(zT_824, zT_825, zT_826);
    g_sym_loc = zT_832;
    zT_833 = &ctx->debug_symbols;
    zT_837 = 1;
    zT_836.kind = zT_837;
    zT_838 = 0;
    zT_836.is_extern = zT_838;
    zT_836.name_id = gv_name;
    zT_839 = mods.ptr;
    zT_840 = zT_839[mi];
    zT_841 = zT_840.id;
    zT_836.module_id = zT_841;
    zT_836.type_id = gv_tid2;
    zT_842 = g_sym_loc.line;
    zT_836.src_line = zT_842;
    zT_843 = mods.ptr;
    zT_844 = zT_843[mi];
    zT_845 = zT_844.source_file_id;
    zT_836.src_file_id = zT_845;
    zT_846 = decl.span_start;
    zT_836.decl_span = zT_846;
    zT_834 = zT_836;
    zF_3CC05A74_debugSymbolListAppe(zT_833, zT_834);
    goto z_bb_136;
    z_bb_136:
    goto z_bb_102;
    z_bb_137:
    zT_855 = 1;
    gv_is_storage = zT_855;
    goto z_bb_138;
    z_bb_138:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_150; else goto z_bb_151;
    z_bb_139:
    zT_856 = decl.child_1;
    if ((unsigned char)(zT_856 != (unsigned int)(0))) goto z_bb_140; else goto z_bb_141;
    z_bb_140:
    zT_860 = ctx->store;
    zT_861 = decl.child_1;
    zT_864 = zF_FCDD1D35_astStoreNodeAt(zT_860, zT_861);
    gv_init = zT_864;
    zT_865 = gv_init.kind;
    if ((unsigned char)(zT_865 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    goto z_bb_138;
    z_bb_142:
    zT_870 = gv_init.kind;
    zT_869 = zT_870 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal);
    goto z_bb_144;
    z_bb_143:
    zT_869 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_869) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_875 = gv_init.kind;
    zT_874 = zT_875 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_147;
    z_bb_146:
    zT_874 = 0;
    goto z_bb_147;
    z_bb_147:
    if (zT_874) goto z_bb_148; else goto z_bb_149;
    z_bb_148:
    zT_879 = 1;
    gv_is_storage = zT_879;
    goto z_bb_149;
    z_bb_149:
    goto z_bb_141;
    z_bb_150:
    zT_882 = decl.child_1;
    if ((unsigned char)(zT_882 != (unsigned int)(0))) goto z_bb_152; else goto z_bb_153;
    z_bb_151:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_160; else goto z_bb_161;
    z_bb_152:
    zT_886 = ctx->store;
    zT_887 = decl.child_1;
    zT_890 = zF_FCDD1D35_astStoreNodeAt(zT_886, zT_887);
    gv_init3 = zT_890;
    zT_891 = gv_init3.kind;
    if ((unsigned char)(zT_891 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_154; else goto z_bb_155;
    z_bb_153:
    goto z_bb_151;
    z_bb_154:
    zT_895 = 0;
    gv_is_storage = zT_895;
    goto z_bb_155;
    z_bb_155:
    zT_896 = gv_init3.kind;
    if ((unsigned char)(zT_896 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_901 = ctx->store;
    zT_902 = gv_init3.child_0;
    zT_905 = zF_FCDD1D35_astStoreNodeAt(zT_901, zT_902);
    gv_fb = zT_905;
    zT_906 = gv_fb.kind;
    if ((unsigned char)(zT_906 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_158; else goto z_bb_159;
    z_bb_157:
    goto z_bb_153;
    z_bb_158:
    zT_910 = 0;
    gv_is_storage = zT_910;
    goto z_bb_159;
    z_bb_159:
    goto z_bb_157;
    z_bb_160:
    zT_913 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_913) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_162; else goto z_bb_163;
    z_bb_161:
    goto z_bb_102;
    z_bb_162:
    zT_920 = mods.ptr;
    zT_921 = zT_920[mi];
    zT_922 = zT_921.id;
    zT_931 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_922) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(Z98_U64_C(4294967296))) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_931;
    zT_932 = &ctx->exported;
    zT_933 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_932, zT_933, (unsigned int)(1));
    goto z_bb_163;
    z_bb_163:
    zT_938 = 0;
    gv_has_ri = zT_938;
    zT_939 = decl.child_1;
    if ((unsigned char)(zT_939 != (unsigned int)(0))) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_943 = ctx->store;
    zT_944 = decl.child_1;
    zT_947 = zF_FCDD1D35_astStoreNodeAt(zT_943, zT_944);
    gv_init2 = zT_947;
    zT_948 = gv_init2.kind;
    if ((unsigned char)(zT_948 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_166; else goto z_bb_167;
    z_bb_165:
    if ((unsigned char)(gv_has_ri == (unsigned char)(1))) goto z_bb_168; else goto z_bb_169;
    z_bb_166:
    zT_952 = 1;
    gv_has_ri = zT_952;
    goto z_bb_167;
    z_bb_167:
    goto z_bb_165;
    z_bb_168:
    zT_955 = 1;
    mod_has_ri = zT_955;
    goto z_bb_169;
    z_bb_169:
    zT_957 = ctx->resolved_types;
    zT_958 = decl_idx;
    zT_960 = zF_999DCF51_resolvedTypeTableGe(zT_957, zT_958);
    gv_rt = zT_960;
    zT_962 = gv_rt.has_value;
    if (zT_962) goto z_bb_170; else goto z_bb_171;
    z_bb_170:
    grt = gv_rt.value;
    zT_963 = grt;
    goto z_bb_172;
    z_bb_171:
    zT_963 = 18;
    goto z_bb_172;
    z_bb_172:
    gv_tid = zT_963;
    zT_967 = 0;
    gv_lv2 = zT_967;
    zT_968 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_968) & (unsigned short)(10)) != (unsigned short)(0))) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_974 = 1;
    gv_lv2 = zT_974;
    goto z_bb_174;
    z_bb_174:
    zT_975 = &ctx->global_decls;
    zT_978.name_id = gv_name;
    zT_979 = mods.ptr;
    zT_980 = zT_979[mi];
    zT_981 = zT_980.id;
    zT_978.module_id = zT_981;
    zT_978.type_id = gv_tid;
    zT_978.has_runtime_init = gv_has_ri;
    zT_982 = 4294967295u;
    zT_978.const_init = zT_982;
    zT_978.link_visible = gv_lv2;
    zT_976 = zT_978;
    zF_F2C82CE7_globalDeclArrayList(zT_975, zT_976);
    zT_983 = ctx->cli;
    zT_984 = zT_983.debug;
    if (zT_984) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    zT_986 = ctx->source_man;
    zT_990 = mods.ptr;
    zT_991 = zT_990[mi];
    zT_987 = zT_991.source_file_id;
    zT_988 = decl.span_start;
    zT_994 = zF_4966CE4A_sourceManagerGetLoc(zT_986, zT_987, zT_988);
    g2_sym_loc = zT_994;
    zT_995 = &ctx->debug_symbols;
    zT_999 = 1;
    zT_998.kind = zT_999;
    zT_1000 = 0;
    zT_998.is_extern = zT_1000;
    zT_998.name_id = gv_name;
    zT_1001 = mods.ptr;
    zT_1002 = zT_1001[mi];
    zT_1003 = zT_1002.id;
    zT_998.module_id = zT_1003;
    zT_998.type_id = gv_tid;
    zT_1004 = g2_sym_loc.line;
    zT_998.src_line = zT_1004;
    zT_1005 = mods.ptr;
    zT_1006 = zT_1005[mi];
    zT_1007 = zT_1006.source_file_id;
    zT_998.src_file_id = zT_1007;
    zT_1008 = decl.span_start;
    zT_998.decl_span = zT_1008;
    zT_996 = zT_998;
    zF_3CC05A74_debugSymbolListAppe(zT_995, zT_996);
    goto z_bb_176;
    z_bb_176:
    goto z_bb_161;
    z_bb_177:
    zT_1014 = (zT_6B356268_SemanticContext*)&sem_ctx;
    zT_1017 = ctx->alloc;
    zT_1015 = &zT_1017->scratch;
    zT_1019 = zF_ADD4254B_lowererInit(zT_1014, zT_1015);
    ilowerer = zT_1019;
    zT_1020 = mods.ptr;
    zT_1021 = zT_1020[mi];
    zT_1022 = zT_1021.id;
    ilowerer.module_id = zT_1022;
    zT_1023 = ctx->module_reg;
    ilowerer.module_reg = zT_1023;
    zT_1024 = ctx->cli;
    zT_1025 = zT_1024.debug;
    if (zT_1025) goto z_bb_179; else goto z_bb_180;
    z_bb_178:
    zT_1085 = ctx->module_reg;
    zT_1087 = zF_3452C137_moduleRegistryGetMo(zT_1085);
    amods = zT_1087;
    zT_1089 = amods.len;
    if ((unsigned char)(zT_1089 > (unsigned int)(0))) goto z_bb_188; else goto z_bb_189;
    z_bb_179:
    zT_1027 = 1;
    zT_1026 = (unsigned char)zT_1027;
    goto z_bb_181;
    z_bb_180:
    zT_1029 = 0;
    zT_1026 = (unsigned char)zT_1029;
    goto z_bb_181;
    z_bb_181:
    ilowerer.debug_enabled = (unsigned char)((unsigned char)zT_1026);
    zT_1032 = ctx->cli;
    zT_1033 = zT_1032.debug;
    if (zT_1033) goto z_bb_182; else goto z_bb_183;
    z_bb_182:
    zT_1034 = ctx->debug_span_buf;
    ilowerer.debug_spans = zT_1034;
    zT_1035 = 0;
    zT_1037 = (zT_02EB57B2_LirLowerer*)&ilowerer;
    zT_1038 = &zT_1037->debug_spans;
    zT_1038->len = (unsigned int)((unsigned int)zT_1035);
    goto z_bb_183;
    z_bb_183:
    zT_1040 = (zT_02EB57B2_LirLowerer*)&ilowerer;
    zT_1045 = mods.ptr;
    zT_1046 = zT_1045[mi];
    zT_1041 = zT_1046.ast_root;
    zT_1048 = mods.ptr;
    zT_1049 = zT_1048[mi];
    zT_1042 = zT_1049.id;
    zT_1043 = &ctx->module_init_deps;
    zT_1052 = zF_552B231C_lowerModuleInit(zT_1040, zT_1041, zT_1042, zT_1043);
    imf = zT_1052;
    zT_1054 = &ctx->lir_stream;
    zT_1055 = imf;
    zT_1057 = zF_9F47D5E4_lirStreamAppend(zT_1054, zT_1055);
    islot = zT_1057;
    zT_1058 = &ctx->lir_slots;
    zT_1059 = islot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_1058, zT_1059);
    zT_1061 = ctx->cli;
    zT_1062 = zT_1061.debug;
    if (zT_1062) goto z_bb_184; else goto z_bb_185;
    z_bb_184:
    zT_1063 = &ctx->debug_spans;
    zT_1064 = islot.disk_offset;
    zT_1068 = ilowerer.debug_spans;
    zT_1069 = zT_1068.items;
    zT_1070 = ilowerer.debug_spans;
    zT_1071 = zT_1070.len;
    zT_1072 = 0;
    zT_1073 = zT_1069 + zT_1072;
    zT_1074 = zT_1071 - zT_1072;
    zT_1075.ptr = (zT_10BDA76C_DebugSpanEntry*)zT_1073;
    zT_1075.len = zT_1074;
    zT_1065 = zT_1075;
    zF_BB256CBD_debugSpanStoreAppen(zT_1063, zT_1064, zT_1065);
    zT_1076 = ilowerer.debug_spans;
    ctx->debug_span_buf = zT_1076;
    zT_1077 = 0;
    zT_1079 = &ctx->debug_span_buf;
    zT_1079->len = (unsigned int)((unsigned int)zT_1077);
    goto z_bb_185;
    z_bb_185:
    if ((unsigned char)(!async_pending)) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_1082 = ctx->alloc;
    zT_1081 = &zT_1082->scratch;
    zF_F1B3F8C2_sandReset(zT_1081);
    goto z_bb_187;
    z_bb_187:
    goto z_bb_178;
    z_bb_188:
    zT_1093 = amods.ptr;
    zT_1094 = 0;
    zT_1095 = zT_1093[zT_1094];
    zT_1096 = zT_1095.ast_root;
    zT_1092 = zT_1096 != (unsigned int)(0);
    goto z_bb_190;
    z_bb_189:
    zT_1092 = 0;
    goto z_bb_190;
    z_bb_190:
    if (zT_1092) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_1100 = ctx->store;
    zT_1103 = amods.ptr;
    zT_1104 = 0;
    zT_1105 = zT_1103[zT_1104];
    zT_1101 = zT_1105.ast_root;
    zT_1107 = zF_FCDD1D35_astStoreNodeAt(zT_1100, zT_1101);
    ar = zT_1107;
    zT_1108 = ar.kind;
    if ((unsigned char)(zT_1108 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_193; else goto z_bb_194;
    z_bb_192:
    goto z_bb_44;
    z_bb_193:
    zT_1113 = ctx->store;
    zT_1116 = amods.ptr;
    zT_1117 = 0;
    zT_1118 = zT_1116[zT_1117];
    zT_1114 = zT_1118.ast_root;
    zT_1120 = zF_152E19CB_astStoreNodeExtraCh(zT_1113, zT_1114);
    adl_n = zT_1120;
    zT_1122 = 0;
    adi = zT_1122;
    zT_1124 = "A0";
    zT_1126 = 2;
    zT_1125.ptr = (unsigned char*)zT_1124;
    zT_1125.len = zT_1126;
    al = zT_1125;
    zT_1127 = al;
    zF_48AC7B3A_markerWrite(zT_1127);
    goto z_bb_195;
    z_bb_194:
    goto z_bb_192;
    z_bb_195:
    if ((unsigned char)(adi < (unsigned int)((unsigned int)adl_n))) goto z_bb_196; else goto z_bb_197;
    z_bb_196:
    zT_1131 = ctx->store;
    zT_1134 = ctx->store;
    zT_1138 = amods.ptr;
    zT_1139 = 0;
    zT_1140 = zT_1138[zT_1139];
    zT_1135 = zT_1140.ast_root;
    zT_1143 = zF_B10B1BC1_astStoreNodeExtraCh(zT_1134, zT_1135, (unsigned int)((unsigned int)adi));
    zT_1132 = zT_1143;
    zT_1144 = zF_FCDD1D35_astStoreNodeAt(zT_1131, zT_1132);
    ad = zT_1144;
    zT_1146 = ad.kind;
    zT_1147 = (unsigned int)zT_1146;
    ak = zT_1147;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_1149[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ab[_i] = zT_1149[_i];
        _i++;
    }
}
    zT_1151 = ak;
    zT_1155 = 0;
    zT_1156 = (unsigned char*)((unsigned char*)ab) + zT_1155;
    zT_1157 = (unsigned int)(20) - zT_1155;
    zT_1158.ptr = (unsigned char*)zT_1156;
    zT_1158.len = zT_1157;
    zT_1152 = zT_1158;
    zT_1159 = zF_A7504564_itoa(zT_1151, zT_1152);
    alen = zT_1159;
    zT_1163 = (unsigned int)(19) - (unsigned int)((unsigned int)alen);
    ast = zT_1163;
    zT_1168 = (unsigned char*)((unsigned char*)ab) + ast;
    zT_1169 = (unsigned int)(19) - ast;
    zT_1170.ptr = (unsigned char*)zT_1168;
    zT_1170.len = zT_1169;
    zT_1164 = zT_1170;
    zF_48AC7B3A_markerWrite(zT_1164);
    zT_1172 = " ";
    zT_1174 = 1;
    zT_1173.ptr = (unsigned char*)zT_1172;
    zT_1173.len = zT_1174;
    asp = zT_1173;
    zT_1175 = asp;
    zF_48AC7B3A_markerWrite(zT_1175);
    goto z_bb_198;
    z_bb_197:
    zT_1179 = "\n";
    zT_1181 = 1;
    zT_1180.ptr = (unsigned char*)zT_1179;
    zT_1180.len = zT_1181;
    an = zT_1180;
    zT_1182 = an;
    zF_48AC7B3A_markerWrite(zT_1182);
    goto z_bb_194;
    z_bb_198:
    zT_1177 = adi + (unsigned int)(1);
    adi = zT_1177;
    goto z_bb_195;
    z_bb_199:
    zT_1188 = async_retained.len;
    if ((unsigned char)(arl_i < zT_1188)) goto z_bb_200; else goto z_bb_201;
    z_bb_200:
    zT_1191 = async_retained.items;
    zT_1192 = zT_1191[arl_i];
    zT_1194 = (zT_BBC23664_LirFunction*)(unsigned int)(unsigned int)((unsigned int)zT_1192);
    lf2 = zT_1194;
    zT_1195 = &ctx->async_layouts;
    zT_1196 = lf2->module_id;
    zT_1197 = lf2->name_id;
    zT_1201 = zF_A1F56FFB_asyncLayoutLookup(zT_1195, zT_1196, zT_1197);
    zT_1202 = zT_1201.has_value;
    if (zT_1202) goto z_bb_203; else goto z_bb_204;
    z_bb_201:
    if (async_pending) goto z_bb_205; else goto z_bb_206;
    z_bb_202:
    zT_1223 = arl_i + (unsigned int)(1);
    arl_i = zT_1223;
    goto z_bb_199;
    z_bb_203:
    lay2 = zT_1201.value;
    zT_1206 = ctx->alloc;
    zT_1207 = &zT_1206->scratch;
    zT_1205.alloc = zT_1207;
    zT_1208 = ctx->typereg;
    zT_1205.registry = zT_1208;
    zT_1209 = ctx->interner;
    zT_1205.interner = zT_1209;
    zT_1210 = &ctx->lir_stream;
    zT_1205.lir_stream = zT_1210;
    zT_1211 = &ctx->lir_slots;
    zT_1205.lir_slots = zT_1211;
    zT_1212 = &ctx->suspending_fns;
    zT_1205.suspending_fns = zT_1212;
    zT_1205.layout = lay2;
    zT_1213 = ctx->cli;
    zT_1214 = zT_1213.safe_checks;
    zT_1205.safe_checks = zT_1214;
    zT_1215 = &ctx->frame_sizes;
    zT_1205.frame_sizes = zT_1215;
    zT_1216 = &ctx->async_layouts;
    zT_1205.async_layouts = zT_1216;
    zT_1217 = ctx->diag;
    zT_1205.diag = zT_1217;
    async_ctx2 = zT_1205;
    zT_1218 = lf2;
    zT_1219 = (zT_5839647A_AsyncTransformCtx*)&async_ctx2;
    zT_1221 = zF_7C1ED6D1_asyncTransform(zT_1218, zT_1219);
    (void)zT_1221;
    goto z_bb_204;
    z_bb_204:
    goto z_bb_202;
    z_bb_205:
    zT_1225 = ctx->alloc;
    zT_1224 = &zT_1225->scratch;
    zF_F1B3F8C2_sandReset(zT_1224);
    goto z_bb_206;
    z_bb_206:
    zT_1227 = ctx;
    zF_B69A3794_computeModuleInitOr(zT_1227);
    zT_1228 = &ctx->lir_stream;
    zF_256E5B86_lirStreamFinishWrit(zT_1228);
    zT_1230 = sem_ctx.print_value_lowered;
    if ((unsigned char)(zT_1230 != (unsigned char)(0))) goto z_bb_207; else goto z_bb_208;
    z_bb_207:
    zT_1234 = "std_fmt.zig";
    zT_1236 = 11;
    zT_1235.ptr = (unsigned char*)zT_1234;
    zT_1235.len = zT_1236;
    c89_fmt_base = zT_1235;
    zT_1240 = ctx->module_reg;
    zT_1242 = zF_3452C137_moduleRegistryGetMo(zT_1240);
    zT_1237 = zT_1242;
    zT_1238 = ctx->interner;
    zT_1239 = c89_fmt_base;
    zT_1244 = zF_D27A4A01_moduleIdForBasename(zT_1237, zT_1238, zT_1239);
    if ((unsigned char)(zT_1244 == (unsigned int)(4294967295u))) goto z_bb_209; else goto z_bb_210;
    z_bb_208:
    return;
    z_bb_209:
    zT_1248 = "could not resolve imported file '";
    zT_1250 = 33;
    zT_1249.ptr = (unsigned char*)zT_1248;
    zT_1249.len = zT_1250;
    p1 = zT_1249;
    zT_1252 = "'";
    zT_1254 = 1;
    zT_1253.ptr = (unsigned char*)zT_1252;
    zT_1253.len = zT_1254;
    p2 = zT_1253;
    zT_1257 = 0;
    zT_1256[zT_1257] = p1;
    zT_1258 = 1;
    zT_1256[zT_1258] = c89_fmt_base;
    zT_1259 = 2;
    zT_1256[zT_1259] = p2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        parts[_i] = zT_1256[_i];
        _i++;
    }
}
    zT_1261 = ctx->interner;
    zT_1265 = 0;
    zT_1266 = parts + zT_1265;
    zT_1262 = zT_1266;
    zT_1268 = zF_8C4BFF7C_diagnosticBuilderMa(zT_1261, zT_1262, (unsigned int)(3));
    msg = zT_1268;
    zT_1269 = ctx->diag;
    zT_1275 = msg;
    zT_1284 = zF_C82559AC_diagnosticCollector(zT_1269, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3048_CANNOT_READ_FILE)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_1275);
    (void)zT_1284;
    goto z_bb_210;
    z_bb_210:
    goto z_bb_208;
}

/* computeModuleInitOrder */
void zF_B69A3794_computeModuleInitOr(zT_5AB29387_CompilerContext* ctx) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_4 = {0};
    unsigned int zT_7;
    zT_B687BB96_U32ArrayList* zT_9;
    zT_3E40CD83_Sand* zT_11;
    zT_69057089_CompilerAlloc* zT_14;
    zT_FDFD82FD_EU_362 zT_19 = {0};
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned char* zT_23;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char zT_38;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_6E8D187B_ModuleEntry* zT_50;
    zT_6E8D187B_ModuleEntry zT_51;
    unsigned int zT_52;
    zT_6E8D187B_ModuleEntry* zT_56;
    zT_6E8D187B_ModuleEntry zT_57;
    unsigned int zT_58;
    zT_79FAE712_u64 zT_60;
    zT_A4CE86B7_U64ToU32Map* zT_61;
    zT_79FAE712_u64 zT_62;
    zT_BAEE192E_Opt_10 zT_64 = {0};
    unsigned char zT_65;
    unsigned char zT_66;
    unsigned int zT_68;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_6E8D187B_ModuleEntry* zT_92;
    zT_6E8D187B_ModuleEntry zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_100;
    zT_79FAE712_u64 zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    zT_BAEE192E_Opt_10 zT_106 = {0};
    unsigned char zT_107;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    zT_22A7C88B_AstNode zT_113 = {0};
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_F85C5DED_DiagnosticCollector* zT_118;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_6E8D187B_ModuleEntry* zT_130;
    zT_6E8D187B_ModuleEntry zT_131;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_138 = 0;
    unsigned char zT_139;
    unsigned int zT_141;
    unsigned int zT_143;
    unsigned char zT_144;
    zT_B687BB96_U32ArrayList* zT_145;
    unsigned int zT_146;
    zT_6E8D187B_ModuleEntry* zT_148;
    zT_6E8D187B_ModuleEntry zT_149;
    unsigned int zT_152;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int n;
    unsigned char* placed;
    unsigned int i;
    unsigned int remaining;
    unsigned int pick;
    unsigned char ok;
    unsigned int j;
    zT_79FAE712_u64 dep_key;
    unsigned int ri;
    unsigned char reported;
    unsigned int rj;
    zT_79FAE712_u64 cyc_key;
    unsigned int ref_decl;
    zT_22A7C88B_AstNode cyc_dcl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cyc_msg;
    zT_2 = ctx->module_reg;
    zT_4 = zF_3452C137_moduleRegistryGetMo(zT_2);
    mods = zT_4;
    zT_7 = mods.len;
    n = zT_7;
    zT_9 = &ctx->module_init_order;
    zT_9->len = (unsigned int)(0);
    zT_14 = ctx->alloc;
    zT_11 = &zT_14->scratch;
    zT_19 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)(n + (unsigned int)(1)), (unsigned int)(1));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_21 = zT_19.data.payload;
    goto z_bb_3;
    z_bb_3:
    zT_23 = (unsigned char*)zT_21;
    placed = zT_23;
    zT_25 = 0;
    i = zT_25;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < n)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = 0;
    placed[i] = zT_27;
    goto z_bb_7;
    z_bb_6:
    remaining = n;
    goto z_bb_8;
    z_bb_7:
    zT_29 = i + (unsigned int)(1);
    i = zT_29;
    goto z_bb_4;
    z_bb_8:
    if ((unsigned char)(remaining > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pick = n;
    zT_34 = 0;
    i = zT_34;
    goto z_bb_12;
    z_bb_10:
    return;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    if ((unsigned char)(i < n)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_38 = placed[i];
    if ((unsigned char)(zT_38 != (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_14:
    if ((unsigned char)(pick == n)) goto z_bb_31; else goto z_bb_32;
    z_bb_15:
    zT_72 = i + (unsigned int)(1);
    i = zT_72;
    goto z_bb_12;
    z_bb_16:
    zT_36 = pick == n;
    goto z_bb_18;
    z_bb_17:
    zT_36 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_36) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_42 = 1;
    ok = zT_42;
    zT_44 = 0;
    j = zT_44;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(j < n)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_46 = placed[j];
    if ((unsigned char)(zT_46 != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    if ((unsigned char)(ok != (unsigned char)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_24:
    zT_68 = j + (unsigned int)(1);
    j = zT_68;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_50 = mods.ptr;
    zT_51 = zT_50[i];
    zT_52 = zT_51.id;
    zT_56 = mods.ptr;
    zT_57 = zT_56[j];
    zT_58 = zT_57.id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_52) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_58);
    dep_key = zT_60;
    zT_61 = &ctx->module_init_deps;
    zT_62 = dep_key;
    zT_64 = zF_A05A7BE1_u64ToU32MapGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_66 = 0;
    ok = zT_66;
    goto z_bb_23;
    z_bb_28:
    goto z_bb_24;
    z_bb_29:
    pick = i;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_15;
    z_bb_31:
    zT_75 = 0;
    ri = zT_75;
    zT_77 = 0;
    reported = zT_77;
    goto z_bb_33;
    z_bb_32:
    zT_144 = 1;
    placed[pick] = zT_144;
    zT_145 = &ctx->module_init_order;
    zT_148 = mods.ptr;
    zT_149 = zT_148[pick];
    zT_146 = zT_149.id;
    zF_62F717A2_u32ArrayListAppend(zT_145, zT_146);
    zT_152 = remaining - (unsigned int)(1);
    remaining = zT_152;
    goto z_bb_11;
    z_bb_33:
    if ((unsigned char)(ri < n)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    zT_82 = placed[ri];
    if ((unsigned char)(zT_82 != (unsigned char)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_35:
    goto z_bb_10;
    z_bb_36:
    zT_143 = ri + (unsigned int)(1);
    ri = zT_143;
    goto z_bb_33;
    z_bb_37:
    zT_79 = reported == (unsigned char)(0);
    goto z_bb_39;
    z_bb_38:
    zT_79 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_79) goto z_bb_34; else goto z_bb_35;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_86 = 0;
    rj = zT_86;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(rj < n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_88 = placed[rj];
    if ((unsigned char)(zT_88 != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_36;
    z_bb_45:
    zT_141 = rj + (unsigned int)(1);
    rj = zT_141;
    goto z_bb_42;
    z_bb_46:
    goto z_bb_45;
    z_bb_47:
    zT_92 = mods.ptr;
    zT_93 = zT_92[ri];
    zT_94 = zT_93.id;
    zT_98 = mods.ptr;
    zT_99 = zT_98[rj];
    zT_100 = zT_99.id;
    zT_102 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_94) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_100);
    cyc_key = zT_102;
    zT_103 = &ctx->module_init_deps;
    zT_104 = cyc_key;
    zT_106 = zF_A05A7BE1_u64ToU32MapGet(zT_103, zT_104);
    zT_107 = zT_106.has_value;
    if (zT_107) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    ref_decl = zT_106.value;
    zT_110 = ctx->store;
    zT_111 = ref_decl;
    zT_113 = zF_FCDD1D35_astStoreNodeAt(zT_110, zT_111);
    cyc_dcl = zT_113;
    zT_115 = "cyclic global initializer dependency";
    zT_117 = 36;
    zT_116.ptr = (unsigned char*)zT_115;
    zT_116.len = zT_117;
    cyc_msg = zT_116;
    zT_118 = ctx->diag;
    zT_130 = mods.ptr;
    zT_131 = zT_130[ri];
    zT_121 = zT_131.source_file_id;
    zT_122 = cyc_dcl.span_start;
    zT_134 = cyc_dcl.span_start;
    zT_135 = cyc_dcl.span_len;
    zT_124 = cyc_msg;
    zT_138 = zF_C82559AC_diagnosticCollector(zT_118, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3064_CYCLIC_GLOBAL_INIT)), zT_121, zT_122, (unsigned int)(zT_134 + (unsigned int)((unsigned int)zT_135)), zT_124);
    (void)zT_138;
    zT_139 = 1;
    reported = zT_139;
    goto z_bb_44;
    z_bb_49:
    goto z_bb_45;
}

/* errorCodeRegistryFinalize */
void zF_FC691B4D_errorCodeRegistryFi(zT_5AB29387_CompilerContext* ctx) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_0B73C507_ErrorSetPayload* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_0B73C507_ErrorSetPayload zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int* zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_21D3708C_U32ToU32Map* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    int zT_43;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int ti;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload esp;
    unsigned int ei;
    unsigned int mname_id;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ctx->typereg;
    zT_5 = zT_4->types_len;
    if ((unsigned char)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = ctx->typereg;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_46 = 1;
    zT_48 = ti + (unsigned int)((unsigned int)zT_46);
    ti = zT_48;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = ty.payload_idx;
    zT_17 = ctx->typereg;
    zT_18 = zT_17->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_15) >= zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_21 = ctx->typereg;
    zT_22 = zT_21->es_items;
    zT_23 = ty.payload_idx;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    esp = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    ei = zT_28;
    goto z_bb_9;
    z_bb_9:
    zT_29 = esp.tags_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_29))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = ctx->typereg;
    zT_34 = zT_33->xn_items;
    zT_35 = esp.tags_start;
    zT_37 = (unsigned int)((unsigned int)zT_35) + ei;
    zT_38 = zT_34[zT_37];
    mname_id = zT_38;
    zT_39 = &ctx->error_code_registry;
    zT_40 = mname_id;
    zT_42 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_39, zT_40);
    (void)zT_42;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_43 = 1;
    zT_45 = ei + (unsigned int)((unsigned int)zT_43);
    ei = zT_45;
    goto z_bb_9;
}

/* pruneTypeMarkByValue */
void zF_BC6C7740_pruneTypeMarkByValu(zT_21D3708C_U32ToU32Map* ref_edges, zT_338B7C76_TypeRegistry* reg, zT_A4CE86B7_U64ToU32Map* visited, unsigned int src_mid, unsigned int tid) {
    unsigned int zT_5;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_79FAE712_u64 zT_15;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_79FAE712_u64 zT_19;
    zT_D155D06D_Type* zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    unsigned short zT_26;
    unsigned char zT_29;
    unsigned short zT_30;
    zT_21D3708C_U32ToU32Map* zT_32;
    unsigned short zT_37;
    zT_33EF6BFB_TypeKind zT_40;
    zT_406493CE_StructPayload* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_406493CE_StructPayload zT_48;
    unsigned int zT_50;
    unsigned short zT_51;
    zT_21D3708C_U32ToU32Map* zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    zT_A4CE86B7_U64ToU32Map* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_2DF01B61_FieldEntry* zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    zT_2DF01B61_FieldEntry zT_63;
    unsigned int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_54FF90FA_TaggedUnionPayload* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_54FF90FA_TaggedUnionPayload zT_75;
    zT_21D3708C_U32ToU32Map* zT_76;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned short zT_84;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_A4CE86B7_U64ToU32Map* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_2DF01B61_FieldEntry* zT_92;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_2DF01B61_FieldEntry zT_96;
    unsigned int zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    unsigned char zT_104;
    zT_33EF6BFB_TypeKind zT_105;
    zT_AF9231A2_UnionPayload* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_AF9231A2_UnionPayload zT_113;
    zT_21D3708C_U32ToU32Map* zT_114;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_A4CE86B7_U64ToU32Map* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_121;
    unsigned short zT_122;
    zT_21D3708C_U32ToU32Map* zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_A4CE86B7_U64ToU32Map* zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    zT_2DF01B61_FieldEntry* zT_130;
    unsigned int zT_131;
    unsigned int zT_133;
    zT_2DF01B61_FieldEntry zT_134;
    unsigned int zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_457ECFEE_EnumPayload* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_457ECFEE_EnumPayload zT_146;
    zT_21D3708C_U32ToU32Map* zT_147;
    zT_338B7C76_TypeRegistry* zT_148;
    zT_A4CE86B7_U64ToU32Map* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_33EF6BFB_TypeKind zT_153;
    zT_E834303C_ArrayPayload* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_E834303C_ArrayPayload zT_161;
    zT_21D3708C_U32ToU32Map* zT_162;
    zT_338B7C76_TypeRegistry* zT_163;
    zT_A4CE86B7_U64ToU32Map* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_33EF6BFB_TypeKind zT_168;
    zT_666DC2E1_TuplePayload* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_666DC2E1_TuplePayload zT_176;
    unsigned int zT_178;
    unsigned short zT_179;
    zT_21D3708C_U32ToU32Map* zT_182;
    zT_338B7C76_TypeRegistry* zT_183;
    zT_A4CE86B7_U64ToU32Map* zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int* zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_193;
    zT_33EF6BFB_TypeKind zT_194;
    zT_0B10E8E9_OptionalPayload* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_0B10E8E9_OptionalPayload zT_202;
    zT_21D3708C_U32ToU32Map* zT_203;
    zT_338B7C76_TypeRegistry* zT_204;
    zT_A4CE86B7_U64ToU32Map* zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_33EF6BFB_TypeKind zT_209;
    zT_42C2D6BF_EUPayload* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    zT_42C2D6BF_EUPayload zT_217;
    zT_21D3708C_U32ToU32Map* zT_218;
    zT_338B7C76_TypeRegistry* zT_219;
    zT_A4CE86B7_U64ToU32Map* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_21D3708C_U32ToU32Map* zT_224;
    zT_338B7C76_TypeRegistry* zT_225;
    zT_A4CE86B7_U64ToU32Map* zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    zT_79FAE712_u64 vkey;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload p;
    unsigned int fi;
    zT_54FF90FA_TaggedUnionPayload p_1;
    zT_AF9231A2_UnionPayload p_2;
    zT_457ECFEE_EnumPayload p_3;
    zT_E834303C_ArrayPayload p_4;
    zT_666DC2E1_TuplePayload p_5;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload p_6;
    zT_42C2D6BF_EUPayload p_7;
    zT_5 = reg->types_len;
    if ((unsigned char)(tid >= (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)src_mid) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)tid);
    vkey = zT_13;
    zT_14 = visited;
    zT_15 = vkey;
    zT_16 = zF_A05A7BE1_u64ToU32MapGet(zT_14, zT_15);
    zT_17 = zT_16.has_value;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = visited;
    zT_19 = vkey;
    zF_B6EB812C_u64ToU32MapPut(zT_18, zT_19, (unsigned int)(1));
    zT_23 = reg->types_items;
    zT_24 = (unsigned int)tid;
    zT_25 = zT_23[zT_24];
    ty = zT_25;
    zT_26 = ty.module_id;
    if ((unsigned char)(zT_26 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = ty.module_id;
    zT_29 = zT_30 != src_mid;
    goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = ref_edges;
    zT_37 = ty.module_id;
    zF_26476265_u32ToU32MapPut(zT_32, (unsigned int)((unsigned int)(src_mid * (unsigned int)(65536)) + zT_37), (unsigned int)(1));
    goto z_bb_9;
    z_bb_9:
    zT_40 = ty.kind;
    if ((unsigned char)(zT_40 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_45 = reg->st_items;
    zT_46 = ty.payload_idx;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zT_45[zT_47];
    p = zT_48;
    zT_50 = 0;
    fi = zT_50;
    goto z_bb_13;
    z_bb_11:
    return;
    z_bb_12:
    zT_67 = ty.kind;
    if ((unsigned char)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_13:
    zT_51 = p.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_51))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_54 = ref_edges;
    zT_55 = reg;
    zT_56 = visited;
    zT_57 = src_mid;
    zT_59 = reg->fe_items;
    zT_60 = p.fields_start;
    zT_62 = (unsigned int)((unsigned int)zT_60) + fi;
    zT_63 = zT_59[zT_62];
    zT_58 = zT_63.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_54, zT_55, zT_56, zT_57, zT_58);
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_66 = fi + (unsigned int)(1);
    fi = zT_66;
    goto z_bb_13;
    z_bb_17:
    zT_72 = reg->tu_items;
    zT_73 = ty.payload_idx;
    zT_74 = (unsigned int)zT_73;
    zT_75 = zT_72[zT_74];
    p_1 = zT_75;
    zT_76 = ref_edges;
    zT_77 = reg;
    zT_78 = visited;
    zT_79 = src_mid;
    zT_80 = p_1.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_76, zT_77, zT_78, zT_79, zT_80);
    zT_83 = 0;
    fi = zT_83;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_11;
    z_bb_19:
    zT_100 = ty.kind;
    if ((unsigned char)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_25; else goto z_bb_24;
    z_bb_20:
    zT_84 = p_1.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_84))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_87 = ref_edges;
    zT_88 = reg;
    zT_89 = visited;
    zT_90 = src_mid;
    zT_92 = reg->fe_items;
    zT_93 = p_1.fields_start;
    zT_95 = (unsigned int)((unsigned int)zT_93) + fi;
    zT_96 = zT_92[zT_95];
    zT_91 = zT_96.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_87, zT_88, zT_89, zT_90, zT_91);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_99 = fi + (unsigned int)(1);
    fi = zT_99;
    goto z_bb_20;
    z_bb_24:
    zT_105 = ty.kind;
    zT_104 = zT_105 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_26;
    z_bb_25:
    zT_104 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_104) goto z_bb_27; else goto z_bb_29;
    z_bb_27:
    zT_110 = reg->un_items;
    zT_111 = ty.payload_idx;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zT_110[zT_112];
    p_2 = zT_113;
    zT_114 = ref_edges;
    zT_115 = reg;
    zT_116 = visited;
    zT_117 = src_mid;
    zT_118 = p_2.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_114, zT_115, zT_116, zT_117, zT_118);
    zT_121 = 0;
    fi = zT_121;
    goto z_bb_30;
    z_bb_28:
    goto z_bb_18;
    z_bb_29:
    zT_138 = ty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_36;
    z_bb_30:
    zT_122 = p_2.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_122))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_125 = ref_edges;
    zT_126 = reg;
    zT_127 = visited;
    zT_128 = src_mid;
    zT_130 = reg->fe_items;
    zT_131 = p_2.fields_start;
    zT_133 = (unsigned int)((unsigned int)zT_131) + fi;
    zT_134 = zT_130[zT_133];
    zT_129 = zT_134.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_125, zT_126, zT_127, zT_128, zT_129);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_137 = fi + (unsigned int)(1);
    fi = zT_137;
    goto z_bb_30;
    z_bb_34:
    zT_143 = reg->en_items;
    zT_144 = ty.payload_idx;
    zT_145 = (unsigned int)zT_144;
    zT_146 = zT_143[zT_145];
    p_3 = zT_146;
    zT_147 = ref_edges;
    zT_148 = reg;
    zT_149 = visited;
    zT_150 = src_mid;
    zT_151 = p_3.backing_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_147, zT_148, zT_149, zT_150, zT_151);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_28;
    z_bb_36:
    zT_153 = ty.kind;
    if ((unsigned char)(zT_153 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_158 = reg->array_items;
    zT_159 = ty.payload_idx;
    zT_160 = (unsigned int)zT_159;
    zT_161 = zT_158[zT_160];
    p_4 = zT_161;
    zT_162 = ref_edges;
    zT_163 = reg;
    zT_164 = visited;
    zT_165 = src_mid;
    zT_166 = p_4.elem;
    zF_BC6C7740_pruneTypeMarkByValu(zT_162, zT_163, zT_164, zT_165, zT_166);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_168 = ty.kind;
    if ((unsigned char)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_173 = reg->tup_items;
    zT_174 = ty.payload_idx;
    zT_175 = (unsigned int)zT_174;
    zT_176 = zT_173[zT_175];
    p_5 = zT_176;
    zT_178 = 0;
    ei = zT_178;
    goto z_bb_43;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_194 = ty.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_47; else goto z_bb_49;
    z_bb_43:
    zT_179 = p_5.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_179))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_182 = ref_edges;
    zT_183 = reg;
    zT_184 = visited;
    zT_185 = src_mid;
    zT_187 = reg->xt_items;
    zT_188 = p_5.elems_start;
    zT_190 = (unsigned int)((unsigned int)zT_188) + ei;
    zT_186 = zT_187[zT_190];
    zF_BC6C7740_pruneTypeMarkByValu(zT_182, zT_183, zT_184, zT_185, zT_186);
    goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_193 = ei + (unsigned int)(1);
    ei = zT_193;
    goto z_bb_43;
    z_bb_47:
    zT_199 = reg->opt_items;
    zT_200 = ty.payload_idx;
    zT_201 = (unsigned int)zT_200;
    zT_202 = zT_199[zT_201];
    p_6 = zT_202;
    zT_203 = ref_edges;
    zT_204 = reg;
    zT_205 = visited;
    zT_206 = src_mid;
    zT_207 = p_6.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_203, zT_204, zT_205, zT_206, zT_207);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_41;
    z_bb_49:
    zT_209 = ty.kind;
    if ((unsigned char)(zT_209 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_214 = reg->eu_items;
    zT_215 = ty.payload_idx;
    zT_216 = (unsigned int)zT_215;
    zT_217 = zT_214[zT_216];
    p_7 = zT_217;
    zT_218 = ref_edges;
    zT_219 = reg;
    zT_220 = visited;
    zT_221 = src_mid;
    zT_222 = p_7.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_218, zT_219, zT_220, zT_221, zT_222);
    zT_224 = ref_edges;
    zT_225 = reg;
    zT_226 = visited;
    zT_227 = src_mid;
    zT_228 = p_7.error_set;
    zF_BC6C7740_pruneTypeMarkByValu(zT_224, zT_225, zT_226, zT_227, zT_228);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
}

/* moduleIdForBasename */
unsigned int zF_D27A4A01_moduleIdForBasename(zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u base) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_D3EB6303_StringInterner* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry* zT_11;
    zT_6E8D187B_ModuleEntry zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14 = {0};
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned char* zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned char zT_37;
    unsigned char zT_39;
    unsigned int zT_41;
    zT_6E8D187B_ModuleEntry* zT_46;
    zT_6E8D187B_ModuleEntry zT_47;
    unsigned int zT_48;
    unsigned char* zT_49;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_6E8D187B_ModuleEntry* zT_55;
    zT_6E8D187B_ModuleEntry zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u p;
    unsigned int off;
    unsigned char eq;
    unsigned int j;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = interner;
    zT_11 = mods.ptr;
    zT_12 = zT_11[i];
    zT_10 = zT_12.path_id;
    zT_14 = zF_9134020D_stringInternerGet(zT_9, zT_10);
    p = zT_14;
    zT_16 = p.len;
    zT_18 = base.len;
    if ((unsigned char)(zT_16 >= zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_1;
    z_bb_5:
    zT_22 = p.len;
    zT_24 = base.len;
    zT_25 = zT_22 - zT_24;
    off = zT_25;
    zT_27 = 1;
    eq = zT_27;
    zT_29 = 0;
    j = zT_29;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = base.len;
    if ((unsigned char)(j < zT_31)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = p.ptr;
    zT_34 = off + j;
    zT_35 = zT_33[zT_34];
    zT_36 = base.ptr;
    zT_37 = zT_36[j];
    if ((unsigned char)(zT_35 != zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    if ((unsigned char)(eq != (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_41 = j + (unsigned int)(1);
    j = zT_41;
    goto z_bb_7;
    z_bb_11:
    zT_39 = 0;
    eq = zT_39;
    goto z_bb_9;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    if ((unsigned char)(off == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_46 = mods.ptr;
    zT_47 = zT_46[i];
    zT_48 = zT_47.id;
    return zT_48;
    z_bb_16:
    zT_49 = p.ptr;
    zT_51 = off - (unsigned int)(1);
    zT_52 = zT_49[zT_51];
    if ((unsigned char)(zT_52 == (unsigned char)(47))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_55 = mods.ptr;
    zT_56 = zT_55[i];
    zT_57 = zT_56.id;
    return zT_57;
    z_bb_18:
    goto z_bb_14;
}

/* phase_EmissionClassification */
void zF_2682C512_phase_EmissionClass(zT_5AB29387_CompilerContext* ctx) {
    zT_1317DCD6_C89SpellPlan* zT_1;
    zT_3E40CD83_Sand* zT_2;
    unsigned int zT_3;
    zT_69057089_CompilerAlloc* zT_5;
    zT_CA01C129_LirSlotArrayList zT_7;
    zT_7E7544E4_LirStream* zT_9;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_12;
    unsigned int zT_15;
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_7E7544E4_LirStream* zT_20;
    zT_E7714190_LirSlot zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_CA01C129_LirSlotArrayList zT_24;
    zT_E7714190_LirSlot* zT_25;
    zT_E7714190_LirSlot zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_BBC23664_LirFunction zT_29 = {0};
    unsigned int zT_31;
    zT_5D72FBF8_TempDeclArrayList zT_32;
    unsigned int zT_33;
    zT_338B7C76_TypeRegistry* zT_35;
    zT_21D3708C_U32ToU32Map* zT_36;
    unsigned int zT_37;
    zT_786E6CF2_EmissionClassificat* zT_39;
    zT_5D72FBF8_TempDeclArrayList zT_41;
    zT_1937645B_TempDecl* zT_42;
    zT_1937645B_TempDecl zT_43;
    unsigned int zT_46;
    zT_1317DCD6_C89SpellPlan* zT_47;
    zT_3E40CD83_Sand* zT_48;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    zT_BBC23664_LirFunction* zT_51;
    zT_69057089_CompilerAlloc* zT_53;
    zT_CA01C129_LirSlotArrayList zT_56;
    zT_E7714190_LirSlot* zT_57;
    zT_E7714190_LirSlot zT_58;
    unsigned int zT_62;
    zT_7E7544E4_LirStream* zT_63;
    unsigned int zT_66;
    zT_E1A783EF_GlobalDeclArrayList zT_67;
    unsigned int zT_68;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_21D3708C_U32ToU32Map* zT_71;
    unsigned int zT_72;
    zT_786E6CF2_EmissionClassificat* zT_74;
    zT_E1A783EF_GlobalDeclArrayList zT_76;
    zT_54906056_ModuleGlobalDecl* zT_77;
    zT_54906056_ModuleGlobalDecl zT_78;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_786E6CF2_EmissionClassificat* zT_83;
    zT_1317DCD6_C89SpellPlan* zT_86;
    zT_3E40CD83_Sand* zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_69057089_CompilerAlloc* zT_90;
    unsigned int ec_fi;
    zT_BBC23664_LirFunction ec_fn;
    unsigned int ec_hi;
    unsigned int ec_gi;
    zT_1 = &ctx->spell_plan;
    zT_5 = ctx->alloc;
    zT_2 = &zT_5->permanent;
    zT_7 = ctx->lir_slots;
    zT_3 = zT_7.len;
    zF_D67A348C_spellPlanInit(zT_1, zT_2, zT_3);
    zT_9 = &ctx->lir_stream;
    zT_12 = ctx->alloc;
    zT_10 = &zT_12->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_9, zT_10);
    zT_15 = 0;
    ec_fi = zT_15;
    goto z_bb_1;
    z_bb_1:
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    if ((unsigned char)(ec_fi < zT_17)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_20 = &ctx->lir_stream;
    zT_24 = ctx->lir_slots;
    zT_25 = zT_24.items;
    zT_26 = zT_25[ec_fi];
    zT_21 = zT_26;
    zT_27 = ctx->alloc;
    zT_22 = &zT_27->lir_read;
    zT_29 = zF_1B7118E0_lirStreamReadFuncti(zT_20, zT_21, zT_22);
    ec_fn = zT_29;
    zT_31 = 0;
    ec_hi = zT_31;
    goto z_bb_5;
    z_bb_3:
    zT_63 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_63);
    zT_66 = 0;
    ec_gi = zT_66;
    goto z_bb_9;
    z_bb_4:
    zT_62 = ec_fi + (unsigned int)(1);
    ec_fi = zT_62;
    goto z_bb_1;
    z_bb_5:
    zT_32 = ec_fn.hoisted_temps;
    zT_33 = zT_32.len;
    if ((unsigned char)(ec_hi < zT_33)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_35 = ctx->typereg;
    zT_39 = &ctx->emission_classif;
    zT_36 = &zT_39->needed_tuple_set;
    zT_41 = ec_fn.hoisted_temps;
    zT_42 = zT_41.items;
    zT_43 = zT_42[ec_hi];
    zT_37 = zT_43.type_id;
    zF_7845A68F_collectNeededTuples(zT_35, zT_36, zT_37);
    goto z_bb_8;
    z_bb_7:
    zT_47 = &ctx->spell_plan;
    zT_53 = ctx->alloc;
    zT_48 = &zT_53->permanent;
    zT_49 = ctx->typereg;
    zT_56 = ctx->lir_slots;
    zT_57 = zT_56.items;
    zT_58 = zT_57[ec_fi];
    zT_50 = zT_58.disk_offset;
    zT_51 = (zT_BBC23664_LirFunction*)&ec_fn;
    zF_72205F3D_spellPlanPlanFn(zT_47, zT_48, zT_49, zT_50, zT_51);
    goto z_bb_4;
    z_bb_8:
    zT_46 = ec_hi + (unsigned int)(1);
    ec_hi = zT_46;
    goto z_bb_5;
    z_bb_9:
    zT_67 = ctx->global_decls;
    zT_68 = zT_67.len;
    if ((unsigned char)(ec_gi < zT_68)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_70 = ctx->typereg;
    zT_74 = &ctx->emission_classif;
    zT_71 = &zT_74->needed_tuple_set;
    zT_76 = ctx->global_decls;
    zT_77 = zT_76.items;
    zT_78 = zT_77[ec_gi];
    zT_72 = zT_78.type_id;
    zF_7845A68F_collectNeededTuples(zT_70, zT_71, zT_72);
    goto z_bb_12;
    z_bb_11:
    zT_82 = ctx->typereg;
    zT_83 = &ctx->emission_classif;
    zF_0DE160E2_classifyTypeEmissio(zT_82, zT_83);
    zT_86 = &ctx->spell_plan;
    zT_90 = ctx->alloc;
    zT_87 = &zT_90->permanent;
    zT_88 = ctx->typereg;
    zF_869C84A7_spellPlanPlanTypeOr(zT_86, zT_87, zT_88);
    return;
    z_bb_12:
    zT_81 = ec_gi + (unsigned int)(1);
    ec_gi = zT_81;
    goto z_bb_9;
}

/* buildDebugMapPath */
unsigned int zF_5E17F383_buildDebugMapPath(zT_8F083A69_Slice_zT_0B42B2F8_u buf, zT_8F083A69_Slice_zT_0B42B2F8_u od, zT_8F083A69_Slice_zT_0B42B2F8_u stem, zT_8F083A69_Slice_zT_0B42B2F8_u ext) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned char zT_33;
    unsigned char* zT_36;
    unsigned char zT_37;
    unsigned char* zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned char* zT_50;
    unsigned char zT_51;
    unsigned char* zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    unsigned char zT_61;
    unsigned char* zT_64;
    unsigned char zT_65;
    unsigned char* zT_66;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int p;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u es;
    zT_5 = 0;
    p = zT_5;
    zT_7 = 0;
    i = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_9 = od.len;
    if ((unsigned char)(i < zT_9)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_14 = od.ptr;
    zT_15 = zT_14[i];
    zT_16 = buf.ptr;
    zT_16[p] = zT_15;
    zT_18 = p + (unsigned int)(1);
    p = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_21 = 47;
    zT_22 = buf.ptr;
    zT_22[p] = zT_21;
    zT_24 = p + (unsigned int)(1);
    p = zT_24;
    zT_25 = 0;
    i = zT_25;
    zT_27 = ".z98dbg.";
    zT_29 = 8;
    zT_28.ptr = (unsigned char*)zT_27;
    zT_28.len = zT_29;
    es = zT_28;
    goto z_bb_8;
    z_bb_4:
    zT_20 = i + (unsigned int)(1);
    i = zT_20;
    goto z_bb_1;
    z_bb_5:
    zT_11 = p < (unsigned int)(510);
    goto z_bb_7;
    z_bb_6:
    zT_11 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_11) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_31 = stem.len;
    if ((unsigned char)(i < zT_31)) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    zT_36 = stem.ptr;
    zT_37 = zT_36[i];
    zT_38 = buf.ptr;
    zT_38[p] = zT_37;
    zT_40 = p + (unsigned int)(1);
    p = zT_40;
    goto z_bb_11;
    z_bb_10:
    zT_43 = 0;
    i = zT_43;
    goto z_bb_15;
    z_bb_11:
    zT_42 = i + (unsigned int)(1);
    i = zT_42;
    goto z_bb_8;
    z_bb_12:
    zT_33 = p < (unsigned int)(510);
    goto z_bb_14;
    z_bb_13:
    zT_33 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_33) goto z_bb_9; else goto z_bb_10;
    z_bb_15:
    zT_45 = es.len;
    if ((unsigned char)(i < zT_45)) goto z_bb_19; else goto z_bb_20;
    z_bb_16:
    zT_50 = es.ptr;
    zT_51 = zT_50[i];
    zT_52 = buf.ptr;
    zT_52[p] = zT_51;
    zT_54 = p + (unsigned int)(1);
    p = zT_54;
    goto z_bb_18;
    z_bb_17:
    zT_57 = 0;
    i = zT_57;
    goto z_bb_22;
    z_bb_18:
    zT_56 = i + (unsigned int)(1);
    i = zT_56;
    goto z_bb_15;
    z_bb_19:
    zT_47 = p < (unsigned int)(511);
    goto z_bb_21;
    z_bb_20:
    zT_47 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_47) goto z_bb_16; else goto z_bb_17;
    z_bb_22:
    zT_59 = ext.len;
    if ((unsigned char)(i < zT_59)) goto z_bb_26; else goto z_bb_27;
    z_bb_23:
    zT_64 = ext.ptr;
    zT_65 = zT_64[i];
    zT_66 = buf.ptr;
    zT_66[p] = zT_65;
    zT_68 = p + (unsigned int)(1);
    p = zT_68;
    goto z_bb_25;
    z_bb_24:
    return p;
    z_bb_25:
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_22;
    z_bb_26:
    zT_61 = p < (unsigned int)(511);
    goto z_bb_28;
    z_bb_27:
    zT_61 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_61) goto z_bb_23; else goto z_bb_24;
}

/* phase_C89Emission */
void zF_2268F8CE_phase_C89Emission(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_C98AF326_CompilerCli zT_6;
    unsigned char zT_7;
    unsigned char zT_9;
    zT_C98AF326_CompilerCli zT_10;
    unsigned char zT_11;
    zT_CEC2984A_NameMangler zT_14 = {0};
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_E1A783EF_GlobalDeclArrayList zT_18;
    unsigned int zT_19;
    zT_786E6CF2_EmissionClassificat zT_21;
    zT_21D3708C_U32ToU32Map zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    zT_D3EB6303_StringInterner* zT_27;
    zT_3E40CD83_Sand* zT_28;
    unsigned int zT_29;
    zT_69057089_CompilerAlloc* zT_31;
    zT_CEC2984A_NameMangler zT_33 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_34;
    zT_F49911A5_Opt_347 zT_35;
    zT_72C4E2ED_C89Emitter zT_37 = {0};
    zT_338B7C76_TypeRegistry* zT_38;
    zT_D3EB6303_StringInterner* zT_39;
    zT_CEC2984A_NameMangler* zT_40;
    zT_F85C5DED_DiagnosticCollector* zT_41;
    zT_9F514E82_SwitchCaseArrayList* zT_42;
    zT_B687BB96_U32ArrayList* zT_43;
    zT_3E40CD83_Sand* zT_44;
    zT_3E40CD83_Sand* zT_45;
    zT_21D3708C_U32ToU32Map* zT_46;
    zT_786E6CF2_EmissionClassificat* zT_47;
    zT_1317DCD6_C89SpellPlan* zT_48;
    unsigned char zT_49;
    int zT_54;
    int zT_55;
    zT_69057089_CompilerAlloc* zT_56;
    zT_69057089_CompilerAlloc* zT_58;
    zT_C98AF326_CompilerCli zT_63;
    zT_72C4E2ED_C89Emitter zT_65 = {0};
    zT_072B53A6_ModuleRegistry* zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_71;
    zT_D3EB6303_StringInterner* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_072B53A6_ModuleRegistry* zT_74;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_76 = {0};
    unsigned int zT_78 = 0;
    zT_5AB29387_CompilerContext* zT_79;
    zT_E1A783EF_GlobalDeclArrayList* zT_81;
    zT_23133B1E_Slice_zT_54906056_M zT_83 = {0};
    zT_54906056_ModuleGlobalDecl* zT_85;
    unsigned int zT_87;
    zT_4065182A_ConstInitTable* zT_89;
    zT_B687BB96_U32ArrayList zT_90;
    unsigned int* zT_91;
    zT_B687BB96_U32ArrayList zT_92;
    unsigned int zT_93;
    zT_7E7544E4_LirStream* zT_94;
    zT_CA01C129_LirSlotArrayList zT_95;
    zT_E7714190_LirSlot* zT_96;
    zT_CA01C129_LirSlotArrayList zT_98;
    unsigned int zT_99;
    zT_69057089_CompilerAlloc* zT_100;
    zT_3E40CD83_Sand* zT_101;
    zT_C98AF326_CompilerCli zT_102;
    unsigned char zT_103;
    zT_DEDDFC41_DebugMapWriter* zT_104;
    zT_FFAA6C17_Opt_338 zT_105;
    zT_C615AE29_DebugSpanStore* zT_106;
    zT_ED9906A0_Opt_340 zT_107;
    zT_8B83E3B4_DebugSymbolList* zT_108;
    zT_EF9909C6_Opt_342 zT_109;
    zT_7E7544E4_LirStream* zT_110;
    zT_3E40CD83_Sand* zT_111;
    zT_69057089_CompilerAlloc* zT_113;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_3E40CD83_Sand* zT_120;
    zT_69057089_CompilerAlloc* zT_121;
    zT_21D3708C_U32ToU32Map zT_123 = {0};
    zT_3E40CD83_Sand* zT_125;
    unsigned int zT_126;
    zT_69057089_CompilerAlloc* zT_127;
    zT_CA01C129_LirSlotArrayList zT_129;
    zT_21D3708C_U32ToU32Map zT_131 = {0};
    zT_3E40CD83_Sand* zT_133;
    zT_69057089_CompilerAlloc* zT_134;
    zT_A4CE86B7_U64ToU32Map zT_136 = {0};
    unsigned int zT_138;
    zT_CA01C129_LirSlotArrayList zT_139;
    unsigned int zT_140;
    zT_7E7544E4_LirStream* zT_143;
    zT_E7714190_LirSlot zT_144;
    zT_3E40CD83_Sand* zT_145;
    zT_CA01C129_LirSlotArrayList zT_147;
    zT_E7714190_LirSlot* zT_148;
    zT_E7714190_LirSlot zT_149;
    zT_69057089_CompilerAlloc* zT_150;
    zT_BBC23664_LirFunction zT_152 = {0};
    unsigned int zT_154;
    unsigned int zT_156;
    zT_5D72FBF8_TempDeclArrayList zT_157;
    unsigned int zT_158;
    zT_5D72FBF8_TempDeclArrayList zT_161;
    zT_1937645B_TempDecl* zT_162;
    zT_1937645B_TempDecl zT_163;
    zT_21D3708C_U32ToU32Map* zT_164;
    zT_338B7C76_TypeRegistry* zT_165;
    zT_A4CE86B7_U64ToU32Map* zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_338B7C76_TypeRegistry* zT_176;
    unsigned int zT_177;
    zT_21D3708C_U32ToU32Map* zT_180;
    zT_338B7C76_TypeRegistry* zT_181;
    zT_A4CE86B7_U64ToU32Map* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int zT_190;
    zT_CFE23D0A_LirParamArrayList zT_191;
    unsigned int zT_192;
    zT_CFE23D0A_LirParamArrayList zT_195;
    zT_8779209D_LirParam* zT_196;
    zT_8779209D_LirParam zT_197;
    zT_21D3708C_U32ToU32Map* zT_198;
    zT_338B7C76_TypeRegistry* zT_199;
    zT_A4CE86B7_U64ToU32Map* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned int zT_208;
    unsigned int zT_210;
    zT_1CF28CA3_BasicBlockArrayList zT_211;
    unsigned int zT_212;
    zT_1CF28CA3_BasicBlockArrayList zT_215;
    zT_88A68B1A_BasicBlock* zT_216;
    zT_88A68B1A_BasicBlock zT_217;
    unsigned int zT_219;
    zT_DAE4631D_LirInstArrayList zT_220;
    unsigned int zT_221;
    zT_DAE4631D_LirInstArrayList zT_224;
    zT_6BA597BC_LirInst* zT_225;
    zT_6BA597BC_LirInst zT_226;
    unsigned int zT_228;
    unsigned char zT_230;
    unsigned int zT_232;
    zT_6BA597BC_LirInst zT_235;
    zT_BBC23664_LirFunction* zT_238;
    unsigned int zT_239;
    zT_3BFB1E70_CallDirectData zT_243 = {0};
    unsigned int zT_244;
    unsigned char zT_245;
    zT_6BA597BC_LirInst zT_248;
    zT_BBC23664_LirFunction* zT_251;
    unsigned int zT_252;
    zT_0624AC1B_TailCallData zT_256 = {0};
    unsigned int zT_257;
    unsigned char zT_258;
    zT_6BA597BC_LirInst zT_261;
    zT_6C58DB1B_anon_116953 zT_264;
    unsigned int zT_265;
    unsigned char zT_266;
    zT_6BA597BC_LirInst zT_269;
    zT_4E52D78E_anon_117135 zT_272;
    unsigned int zT_273;
    unsigned char zT_274;
    zT_6BA597BC_LirInst zT_277;
    zT_C04B3C3F_anon_117143 zT_280;
    unsigned int zT_281;
    unsigned char zT_282;
    unsigned char zT_285;
    zT_21D3708C_U32ToU32Map* zT_287;
    zT_6BA597BC_LirInst zT_297;
    unsigned char zT_299;
    unsigned int zT_300;
    unsigned int zT_303;
    zT_21D3708C_U32ToU32Map* zT_305;
    unsigned int zT_311;
    zT_6BA597BC_LirInst zT_316;
    unsigned char zT_318;
    zT_6BA597BC_LirInst zT_321;
    unsigned int zT_324;
    unsigned int zT_326;
    zT_6BA597BC_LirInst zT_329;
    zT_4E52D78E_anon_117135 zT_332;
    unsigned int zT_333;
    zT_4E52D78E_anon_117135 zT_335;
    unsigned int zT_336;
    zT_C04B3C3F_anon_117143 zT_338;
    unsigned int zT_339;
    zT_C04B3C3F_anon_117143 zT_341;
    unsigned int zT_342;
    unsigned int zT_344;
    unsigned int zT_346;
    zT_5D72FBF8_TempDeclArrayList zT_347;
    unsigned int zT_348;
    zT_5D72FBF8_TempDeclArrayList zT_351;
    zT_1937645B_TempDecl* zT_352;
    zT_1937645B_TempDecl zT_353;
    unsigned int zT_354;
    unsigned int zT_356;
    unsigned int zT_358;
    zT_338B7C76_TypeRegistry* zT_359;
    unsigned int zT_360;
    zT_338B7C76_TypeRegistry* zT_364;
    zT_D155D06D_Type* zT_365;
    unsigned int zT_366;
    zT_D155D06D_Type zT_367;
    unsigned int zT_368;
    unsigned char zT_371;
    unsigned int zT_372;
    zT_21D3708C_U32ToU32Map* zT_374;
    unsigned int zT_375;
    unsigned int zT_380;
    unsigned int zT_382;
    unsigned int zT_384;
    zT_072B53A6_ModuleRegistry* zT_386;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_388 = {0};
    unsigned int zT_390;
    zT_E1A783EF_GlobalDeclArrayList zT_391;
    unsigned int zT_392;
    zT_E1A783EF_GlobalDeclArrayList zT_395;
    zT_54906056_ModuleGlobalDecl* zT_396;
    zT_54906056_ModuleGlobalDecl zT_397;
    unsigned int zT_398;
    zT_338B7C76_TypeRegistry* zT_399;
    unsigned int zT_400;
    zT_338B7C76_TypeRegistry* zT_404;
    zT_D155D06D_Type* zT_405;
    unsigned int zT_406;
    unsigned int zT_407;
    zT_D155D06D_Type zT_408;
    unsigned int zT_409;
    unsigned char zT_412;
    unsigned int zT_413;
    unsigned int zT_414;
    zT_21D3708C_U32ToU32Map* zT_416;
    zT_338B7C76_TypeRegistry* zT_417;
    zT_A4CE86B7_U64ToU32Map* zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_427;
    zT_3E40CD83_Sand* zT_429;
    unsigned int zT_430;
    zT_69057089_CompilerAlloc* zT_431;
    zT_21D3708C_U32ToU32Map zT_435 = {0};
    zT_21D3708C_U32ToU32Map* zT_436;
    unsigned char zT_443;
    unsigned char zT_446;
    unsigned int zT_448;
    unsigned int zT_450;
    zT_6E8D187B_ModuleEntry* zT_453;
    zT_6E8D187B_ModuleEntry zT_454;
    unsigned int zT_455;
    zT_21D3708C_U32ToU32Map* zT_456;
    unsigned int zT_457;
    zT_BAEE192E_Opt_10 zT_459 = {0};
    unsigned char zT_460;
    unsigned int zT_463;
    unsigned int zT_465;
    zT_6E8D187B_ModuleEntry* zT_468;
    zT_6E8D187B_ModuleEntry zT_469;
    unsigned int zT_470;
    zT_21D3708C_U32ToU32Map* zT_472;
    unsigned int zT_473;
    zT_BAEE192E_Opt_10 zT_475 = {0};
    unsigned char zT_476;
    zT_21D3708C_U32ToU32Map* zT_477;
    zT_BAEE192E_Opt_10 zT_483 = {0};
    unsigned char zT_484;
    zT_21D3708C_U32ToU32Map* zT_485;
    unsigned int zT_486;
    unsigned char zT_490;
    unsigned int zT_492;
    unsigned int zT_494;
    unsigned int zT_496;
    unsigned int zT_498;
    zT_6E8D187B_ModuleEntry* zT_500;
    zT_6E8D187B_ModuleEntry zT_501;
    unsigned int zT_502;
    zT_21D3708C_U32ToU32Map* zT_505;
    unsigned int zT_506;
    zT_6E8D187B_ModuleEntry* zT_508;
    zT_6E8D187B_ModuleEntry zT_509;
    zT_BAEE192E_Opt_10 zT_511 = {0};
    unsigned char zT_512;
    unsigned char zT_515;
    unsigned int zT_517;
    zT_E1A783EF_GlobalDeclArrayList zT_518;
    unsigned int zT_519;
    zT_E1A783EF_GlobalDeclArrayList zT_522;
    zT_54906056_ModuleGlobalDecl* zT_523;
    zT_54906056_ModuleGlobalDecl zT_524;
    unsigned int zT_525;
    zT_6E8D187B_ModuleEntry* zT_526;
    zT_6E8D187B_ModuleEntry zT_527;
    unsigned int zT_528;
    unsigned char zT_530;
    unsigned char zT_531;
    unsigned char zT_534;
    unsigned int zT_536;
    zT_21D3708C_U32ToU32Map* zT_539;
    zT_6E8D187B_ModuleEntry* zT_546;
    zT_6E8D187B_ModuleEntry zT_547;
    unsigned int zT_548;
    unsigned int zT_552;
    zT_C98AF326_CompilerCli zT_553;
    unsigned char zT_554;
    zT_C98AF326_CompilerCli zT_555;
    unsigned char zT_556;
    zT_72C4E2ED_C89Emitter* zT_558;
    int zT_561;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_563 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_565;
    zT_846744CC_Arr_unsigned_char_5 zT_567;
    zT_846744CC_Arr_unsigned_char_5 zT_569;
    unsigned char* zT_571;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_572;
    unsigned int zT_573;
    unsigned char* zT_575;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_576;
    unsigned int zT_577;
    unsigned char* zT_579;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_580;
    unsigned int zT_581;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_583;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_584;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_585;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_586;
    int zT_589;
    unsigned char* zT_590;
    unsigned int zT_591;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_592;
    zT_C98AF326_CompilerCli zT_593;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_594;
    unsigned int zT_595 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_597;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_598;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_599;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_600;
    int zT_603;
    unsigned char* zT_604;
    unsigned int zT_605;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_606;
    zT_C98AF326_CompilerCli zT_607;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_608;
    unsigned int zT_609 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_611;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_612;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_613;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_614;
    int zT_617;
    unsigned char* zT_618;
    unsigned int zT_619;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_620;
    zT_C98AF326_CompilerCli zT_621;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_622;
    unsigned int zT_623 = 0;
    zT_DEDDFC41_DebugMapWriter* zT_624;
    zT_3E40CD83_Sand* zT_625;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_626;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_627;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_628;
    zT_69057089_CompilerAlloc* zT_630;
    int zT_634;
    unsigned char* zT_635;
    unsigned int zT_636;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_637;
    int zT_640;
    unsigned char* zT_641;
    unsigned int zT_642;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_643;
    int zT_646;
    unsigned char* zT_647;
    unsigned int zT_648;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_649;
    zT_1317DCD6_C89SpellPlan zT_651;
    unsigned int* zT_652;
    zT_846744CC_Arr_unsigned_char_5 zT_654;
    unsigned int zT_656;
    zT_C98AF326_CompilerCli zT_658;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_659;
    zT_72C4E2ED_C89Emitter* zT_660;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_661;
    unsigned int zT_664;
    unsigned int zT_666;
    unsigned char zT_668;
    unsigned char* zT_671;
    unsigned char zT_672;
    int zT_673;
    unsigned int zT_675;
    int zT_676;
    unsigned int zT_678;
    unsigned char zT_679;
    int zT_680;
    unsigned int zT_682;
    unsigned char* zT_684;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_685;
    unsigned int zT_686;
    unsigned int zT_688;
    unsigned int zT_690;
    unsigned char zT_692;
    unsigned char* zT_695;
    unsigned char zT_696;
    int zT_697;
    unsigned int zT_699;
    int zT_700;
    unsigned int zT_702;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_704;
    int zT_708;
    unsigned char* zT_709;
    unsigned int zT_710;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_711;
    unsigned int zT_713 = 0;
    unsigned char* zT_717;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_718;
    unsigned int zT_719;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_720;
    zT_63BE4FF5_BufferedWriter zT_724 = {0};
    unsigned int zT_725;
    zT_63BE4FF5_BufferedWriter zT_726 = {0};
    zT_72C4E2ED_C89Emitter* zT_727;
    zT_338B7C76_TypeRegistry* zT_728;
    unsigned int* zT_729;
    zT_63BE4FF5_BufferedWriter* zT_732;
    zT_72C4E2ED_C89Emitter* zT_733;
    unsigned int zT_735;
    zT_072B53A6_ModuleRegistry* zT_737;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_739 = {0};
    zT_CA01C129_LirSlotArrayList zT_742;
    unsigned int zT_743;
    int zT_744;
    zT_3E40CD83_Sand* zT_747;
    zT_69057089_CompilerAlloc* zT_750;
    unsigned int zT_754;
    zT_FDFD82FD_EU_362 zT_757 = {0};
    unsigned char zT_758;
    unsigned char* zT_759;
    unsigned int* zT_761;
    zT_3E40CD83_Sand* zT_763;
    zT_69057089_CompilerAlloc* zT_766;
    unsigned int zT_770;
    zT_FDFD82FD_EU_362 zT_773 = {0};
    unsigned char zT_774;
    unsigned char* zT_775;
    unsigned int* zT_777;
    unsigned int zT_779;
    unsigned int zT_781;
    unsigned int zT_783;
    int zT_784;
    unsigned int zT_786;
    unsigned int zT_788;
    zT_CA01C129_LirSlotArrayList zT_791;
    zT_E7714190_LirSlot* zT_792;
    zT_E7714190_LirSlot zT_793;
    unsigned int zT_794;
    unsigned int zT_797;
    unsigned int zT_799;
    unsigned int zT_800;
    unsigned int zT_802;
    unsigned int zT_803;
    int zT_804;
    unsigned int zT_806;
    unsigned int zT_808;
    unsigned int zT_809;
    unsigned int zT_811;
    unsigned int zT_813;
    unsigned int zT_814;
    int zT_815;
    unsigned int zT_817;
    zT_3E40CD83_Sand* zT_819;
    zT_69057089_CompilerAlloc* zT_822;
    zT_FDFD82FD_EU_362 zT_827 = {0};
    unsigned char zT_828;
    unsigned char* zT_829;
    zT_E7714190_LirSlot* zT_831;
    unsigned int zT_832;
    zT_CA01C129_LirSlotArrayList zT_835;
    zT_E7714190_LirSlot* zT_836;
    zT_E7714190_LirSlot zT_837;
    unsigned int zT_839;
    unsigned int zT_842;
    unsigned int zT_845;
    unsigned int zT_846;
    unsigned int zT_847;
    unsigned int zT_849;
    unsigned int zT_850;
    int zT_851;
    unsigned int zT_853;
    zT_CA01C129_LirSlotArrayList* zT_854;
    zT_CA01C129_LirSlotArrayList* zT_856;
    unsigned int zT_858;
    unsigned int zT_860;
    unsigned int zT_862;
    zT_6E8D187B_ModuleEntry* zT_865;
    zT_6E8D187B_ModuleEntry zT_866;
    zT_CA01C129_LirSlotArrayList zT_868;
    unsigned int zT_869;
    unsigned char zT_871;
    zT_CA01C129_LirSlotArrayList zT_872;
    zT_E7714190_LirSlot* zT_873;
    zT_E7714190_LirSlot zT_874;
    unsigned int zT_875;
    unsigned int zT_876;
    unsigned int zT_879;
    zT_21D3708C_U32ToU32Map* zT_880;
    unsigned int zT_881;
    zT_BAEE192E_Opt_10 zT_884 = {0};
    unsigned char zT_885;
    zT_72C4E2ED_C89Emitter* zT_889;
    unsigned int zT_890;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_893 = {0};
    unsigned int zT_895;
    unsigned int zT_899;
    unsigned char* zT_906;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_907;
    unsigned int zT_908;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_909;
    unsigned int zT_913;
    unsigned int zT_915;
    unsigned int zT_917;
    unsigned char zT_919;
    unsigned char* zT_922;
    unsigned char zT_923;
    int zT_924;
    unsigned int zT_926;
    int zT_927;
    unsigned int zT_929;
    unsigned char zT_930;
    int zT_931;
    unsigned int zT_933;
    unsigned int zT_935;
    unsigned int zT_937;
    unsigned char zT_939;
    unsigned char* zT_942;
    unsigned char zT_943;
    int zT_944;
    unsigned int zT_946;
    int zT_947;
    unsigned int zT_949;
    unsigned char* zT_951;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_952;
    unsigned int zT_953;
    unsigned int zT_955;
    unsigned int zT_957;
    unsigned char zT_959;
    unsigned char* zT_962;
    unsigned char zT_963;
    int zT_964;
    unsigned int zT_966;
    int zT_967;
    unsigned int zT_969;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_971;
    int zT_975;
    unsigned char* zT_976;
    unsigned int zT_977;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_978;
    unsigned int zT_980 = 0;
    unsigned char* zT_984;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_985;
    unsigned int zT_986;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_987;
    zT_63BE4FF5_BufferedWriter zT_991 = {0};
    unsigned int zT_992;
    zT_63BE4FF5_BufferedWriter zT_993 = {0};
    unsigned int zT_995;
    unsigned int zT_996;
    unsigned int zT_998;
    unsigned int zT_1000;
    zT_072B53A6_ModuleRegistry* zT_1002;
    unsigned int* zT_1003;
    unsigned int* zT_1004;
    unsigned int zT_1005;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1006;
    zT_B687BB96_U32ArrayList zT_1008;
    unsigned int* zT_1009;
    zT_B687BB96_U32ArrayList zT_1010;
    unsigned int zT_1011;
    int zT_1012;
    unsigned int* zT_1013;
    unsigned int zT_1014;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1015;
    zT_3E40CD83_Sand* zT_1017;
    zT_69057089_CompilerAlloc* zT_1020;
    unsigned int zT_1024;
    zT_FDFD82FD_EU_362 zT_1027 = {0};
    unsigned char zT_1028;
    unsigned char* zT_1029;
    unsigned int* zT_1032;
    unsigned int zT_1034;
    unsigned int zT_1036;
    unsigned int zT_1038;
    unsigned int* zT_1041;
    unsigned int zT_1042;
    unsigned int zT_1043;
    zT_21D3708C_U32ToU32Map* zT_1045;
    unsigned int zT_1046;
    zT_BAEE192E_Opt_10 zT_1048 = {0};
    unsigned char zT_1049;
    unsigned char zT_1052;
    unsigned int zT_1054;
    unsigned int zT_1056;
    unsigned char zT_1058;
    unsigned int zT_1060;
    unsigned int zT_1064;
    unsigned int zT_1066;
    unsigned int zT_1068;
    unsigned int zT_1070;
    zT_6E8D187B_ModuleEntry* zT_1073;
    zT_6E8D187B_ModuleEntry zT_1074;
    unsigned int zT_1075;
    unsigned int zT_1076;
    zT_21D3708C_U32ToU32Map* zT_1078;
    unsigned int zT_1079;
    zT_BAEE192E_Opt_10 zT_1081 = {0};
    unsigned char zT_1082;
    zT_21D3708C_U32ToU32Map* zT_1084;
    unsigned int zT_1087;
    zT_BAEE192E_Opt_10 zT_1091 = {0};
    unsigned char zT_1092;
    unsigned char zT_1095;
    unsigned int zT_1097;
    unsigned int zT_1099;
    unsigned char zT_1101;
    unsigned int zT_1103;
    unsigned int zT_1107;
    unsigned int zT_1109;
    int zT_1111;
    unsigned int* zT_1112;
    unsigned int zT_1113;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1114;
    zT_72C4E2ED_C89Emitter* zT_1115;
    unsigned int zT_1116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1117;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1118;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1119;
    unsigned int* zT_1120;
    zT_63BE4FF5_BufferedWriter* zT_1123;
    zT_72C4E2ED_C89Emitter* zT_1124;
    unsigned int zT_1126;
    unsigned char* zT_1128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1129;
    unsigned int zT_1130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1131;
    zT_846744CC_Arr_unsigned_char_5 zT_1133;
    unsigned int zT_1135;
    unsigned int zT_1137;
    unsigned int zT_1139;
    unsigned char zT_1141;
    unsigned char* zT_1144;
    unsigned char zT_1145;
    int zT_1146;
    unsigned int zT_1148;
    int zT_1149;
    unsigned int zT_1151;
    unsigned char zT_1152;
    int zT_1153;
    unsigned int zT_1155;
    unsigned int zT_1157;
    unsigned int zT_1159;
    unsigned char zT_1161;
    unsigned char* zT_1164;
    unsigned char zT_1165;
    int zT_1166;
    unsigned int zT_1168;
    int zT_1169;
    unsigned int zT_1171;
    unsigned char* zT_1173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1174;
    unsigned int zT_1175;
    unsigned int zT_1177;
    unsigned int zT_1179;
    unsigned char zT_1181;
    unsigned char* zT_1184;
    unsigned char zT_1185;
    int zT_1186;
    unsigned int zT_1188;
    int zT_1189;
    unsigned int zT_1191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1193;
    int zT_1197;
    unsigned char* zT_1198;
    unsigned int zT_1199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1200;
    unsigned int zT_1202 = 0;
    unsigned char* zT_1206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1207;
    unsigned int zT_1208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1209;
    zT_63BE4FF5_BufferedWriter zT_1213 = {0};
    unsigned int zT_1214;
    zT_63BE4FF5_BufferedWriter zT_1215 = {0};
    zT_C98AF326_CompilerCli zT_1216;
    unsigned char zT_1217;
    zT_227EDE07_SourceManager* zT_1219;
    unsigned int zT_1220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1223 = {0};
    zT_DEDDFC41_DebugMapWriter* zT_1224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1225;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1226;
    zT_72C4E2ED_C89Emitter* zT_1228;
    unsigned int zT_1229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1230;
    zT_C98AF326_CompilerCli zT_1233;
    unsigned char zT_1234;
    zT_DEDDFC41_DebugMapWriter* zT_1235;
    zT_63BE4FF5_BufferedWriter* zT_1237;
    zT_72C4E2ED_C89Emitter* zT_1238;
    unsigned int zT_1240;
    unsigned char* zT_1242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1243;
    unsigned int zT_1244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1245;
    int zT_1246;
    unsigned int zT_1248;
    zT_C98AF326_CompilerCli zT_1249;
    unsigned char zT_1250;
    zT_DEDDFC41_DebugMapWriter* zT_1251;
    zT_3E40CD83_Sand* zT_1252;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_1253;
    zT_227EDE07_SourceManager* zT_1254;
    zT_CEC2984A_NameMangler* zT_1255;
    zT_D3EB6303_StringInterner* zT_1256;
    zT_072B53A6_ModuleRegistry* zT_1257;
    zT_338B7C76_TypeRegistry* zT_1258;
    zT_69057089_CompilerAlloc* zT_1260;
    zT_8B83E3B4_DebugSymbolList zT_1262;
    zT_1001656C_DebugSymbol* zT_1263;
    zT_8B83E3B4_DebugSymbolList zT_1264;
    unsigned int zT_1265;
    int zT_1266;
    zT_1001656C_DebugSymbol* zT_1267;
    unsigned int zT_1268;
    zT_39D2FAA1_Slice_zT_1001656C_D zT_1269;
    zT_C615AE29_DebugSpanStore* zT_1275;
    zT_72C4E2ED_C89Emitter* zT_1277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1278;
    unsigned char zT_1279;
    zT_074080EA_WinProfile zT_1280;
    zT_C98AF326_CompilerCli zT_1282;
    zT_C98AF326_CompilerCli zT_1284;
    zT_7E7544E4_LirStream* zT_1286;
    zT_6B0A7D14_AstStore* zT_1288;
    zT_63BE4FF5_BufferedWriter zT_1291 = {0};
    zT_63BE4FF5_BufferedWriter zT_1292 = {0};
    zT_63BE4FF5_BufferedWriter* zT_1293;
    zT_63BE4FF5_BufferedWriter* zT_1295;
    zT_072B53A6_ModuleRegistry* zT_1298;
    zT_3E40CD83_Sand* zT_1299;
    zT_69057089_CompilerAlloc* zT_1301;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1303 = {0};
    zT_72C4E2ED_C89Emitter* zT_1304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1305;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1306;
    unsigned char* zT_1309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1310;
    unsigned int zT_1311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1312;
    zT_63BE4FF5_BufferedWriter* zT_1313;
    zT_72C4E2ED_C89Emitter* zT_1314;
    zT_7E7544E4_LirStream* zT_1316;
    zT_6B0A7D14_AstStore* zT_1318;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_CEC2984A_NameMangler mangler;
    unsigned int mangler_hint;
    zT_72C4E2ED_C89Emitter emitter;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_23133B1E_Slice_zT_54906056_M gd_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u module_name;
    zT_21D3708C_U32ToU32Map ts_ref_set;
    zT_21D3708C_U32ToU32Map ref_edges;
    zT_A4CE86B7_U64ToU32Map type_visited;
    unsigned int ts_fi;
    zT_BBC23664_LirFunction ts_fn;
    unsigned int ts_src;
    unsigned int ts_tti;
    zT_DDCD424B_Slice_zT_6E8D187B_M ri_mods;
    unsigned int gt_i;
    zT_1937645B_TempDecl ts_hty;
    unsigned int ts_pi;
    zT_8779209D_LirParam ts_pt;
    unsigned int ts_bi;
    zT_88A68B1A_BasicBlock ts_blk;
    unsigned int ts_ii;
    zT_6BA597BC_LirInst ts_inst;
    unsigned int ts_tg;
    unsigned char ts_edge_has;
    unsigned int ts_edge_dst;
    zT_3BFB1E70_CallDirectData ts_cd;
    zT_0624AC1B_TailCallData ts_tc;
    unsigned int ts_name_id;
    unsigned int ts_tmp;
    unsigned int ts_tid;
    unsigned int ts_tj;
    zT_1937645B_TempDecl ts_ht;
    zT_D155D06D_Type ts_ty;
    zT_54906056_ModuleGlobalDecl gt_g;
    zT_21D3708C_U32ToU32Map reachable;
    unsigned char rf_changed;
    zT_D155D06D_Type gt_ty;
    unsigned int rf_s;
    unsigned int ri_i;
    unsigned int rf_src;
    unsigned int rf_d;
    unsigned int rf_dst;
    unsigned char ri_has;
    unsigned int gd_ri;
    zT_54906056_ModuleGlobalDecl gd_g;
    zT_63BE4FF5_BufferedWriter cwriter;
    zT_3CB0179A_Slice_zT_05F374B1_u c_incs;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_root_stem;
    zT_846744CC_Arr_unsigned_char_5 dbg_p1;
    zT_846744CC_Arr_unsigned_char_5 dbg_p2;
    zT_846744CC_Arr_unsigned_char_5 dbg_p3;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_e1;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_e2;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_e3;
    unsigned int dbg_n1;
    unsigned int dbg_n2;
    unsigned int dbg_n3;
    unsigned int* sorted;
    zT_846744CC_Arr_unsigned_char_5 hpath;
    unsigned int hp;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hfn;
    unsigned int hfi;
    unsigned int fd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_63BE4FF5_BufferedWriter hw;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int slot_count;
    unsigned int* grp_counts;
    unsigned int fn_cursor;
    unsigned int mi;
    unsigned int* grp_cursor;
    unsigned int gci;
    unsigned int gsi;
    unsigned int gsmid;
    unsigned int gacc;
    zT_E7714190_LirSlot* grouped;
    zT_E7714190_LirSlot gslot;
    unsigned int gdst;
    zT_6E8D187B_ModuleEntry m;
    unsigned int fn_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    unsigned int hp2;
    unsigned int hi2;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hext;
    unsigned int hx;
    unsigned int fd2;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg2;
    zT_63BE4FF5_BufferedWriter hw2;
    unsigned int dep_start;
    unsigned int dep_end;
    zT_3CB0179A_Slice_zT_05F374B1_u dep_ids;
    zT_3CB0179A_Slice_zT_05F374B1_u m_c_incs;
    unsigned char* inc_raw;
    unsigned int* inc_arr;
    unsigned int inc_n;
    unsigned int di0;
    unsigned int dd0;
    unsigned int vd0;
    unsigned char dup0;
    unsigned int dj0;
    unsigned int vdd0;
    zT_3CB0179A_Slice_zT_05F374B1_u inc_slice;
    zT_846744CC_Arr_unsigned_char_5 cpath;
    unsigned int cp2;
    unsigned int ci2;
    unsigned char dup1;
    unsigned int dj1;
    unsigned int cbi;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    unsigned int cx;
    unsigned int cfd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg3;
    zT_63BE4FF5_BufferedWriter cw;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_src_file;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2_m;
    zT_2 = "C\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->cli;
    zT_7 = zT_6.dump_c89;
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = ctx->cli;
    zT_11 = zT_10.output_dir_set;
    zT_9 = !zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_9 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    mangler = zT_14;
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    zT_18 = ctx->global_decls;
    zT_19 = zT_18.len;
    zT_21 = ctx->emission_classif;
    zT_22 = zT_21.pointer_only_map;
    zT_23 = zT_22.count;
    zT_26 = (unsigned int)((unsigned int)(zT_17 + zT_19) + zT_23) + (unsigned int)(32);
    mangler_hint = zT_26;
    zT_27 = ctx->interner;
    zT_31 = ctx->alloc;
    zT_28 = &zT_31->emission;
    zT_29 = mangler_hint;
    zT_33 = zF_27DA3900_nameManglerInit(zT_27, zT_28, zT_29);
    mangler = zT_33;
    zT_34 = &ctx->exported;
    zT_35.has_value = 1;
    zT_35.value = zT_34;
    mangler.exported = zT_35;
    emitter = zT_37;
    zT_38 = ctx->typereg;
    zT_39 = ctx->interner;
    zT_40 = (zT_CEC2984A_NameMangler*)&mangler;
    zT_41 = ctx->diag;
    zT_54 = 0;
    zT_42 = (zT_9F514E82_SwitchCaseArrayList*)zT_54;
    zT_55 = 0;
    zT_43 = (zT_B687BB96_U32ArrayList*)zT_55;
    zT_56 = ctx->alloc;
    zT_44 = &zT_56->scratch;
    zT_58 = ctx->alloc;
    zT_45 = &zT_58->emission;
    zT_46 = &ctx->error_code_registry;
    zT_47 = &ctx->emission_classif;
    zT_48 = &ctx->spell_plan;
    zT_63 = ctx->cli;
    zT_49 = zT_63.safe_checks;
    zT_65 = zF_63D58A2B_c89EmitterInit(zT_38, zT_39, zT_40, zT_41, zT_42, zT_43, zT_44, zT_45, zT_46, zT_47, zT_48, zT_49);
    emitter = zT_65;
    zT_66 = ctx->module_reg;
    emitter.module_reg = zT_66;
    zT_68 = "std_fmt.zig";
    zT_70 = 11;
    zT_69.ptr = (unsigned char*)zT_68;
    zT_69.len = zT_70;
    c89_fmt_base = zT_69;
    zT_74 = ctx->module_reg;
    zT_76 = zF_3452C137_moduleRegistryGetMo(zT_74);
    zT_71 = zT_76;
    zT_72 = ctx->interner;
    zT_73 = c89_fmt_base;
    zT_78 = zF_D27A4A01_moduleIdForBasename(zT_71, zT_72, zT_73);
    emitter.std_fmt_module_id = zT_78;
    zT_79 = ctx;
    zF_FC691B4D_errorCodeRegistryFi(zT_79);
    zT_81 = &ctx->global_decls;
    zT_83 = zF_6ACCE52D_globalDeclArrayList(zT_81);
    gd_slice = zT_83;
    zT_85 = gd_slice.ptr;
    emitter.global_decls = zT_85;
    zT_87 = gd_slice.len;
    emitter.global_decls_len = (unsigned int)((unsigned int)zT_87);
    zT_89 = &ctx->const_inits;
    emitter.const_inits = zT_89;
    zT_90 = ctx->module_init_order;
    zT_91 = zT_90.items;
    emitter.module_init_order = zT_91;
    zT_92 = ctx->module_init_order;
    zT_93 = zT_92.len;
    emitter.module_init_order_len = zT_93;
    zT_94 = &ctx->lir_stream;
    emitter.spill = zT_94;
    zT_95 = ctx->lir_slots;
    zT_96 = zT_95.items;
    emitter.fn_slots = zT_96;
    emitter.fn_slots_start = (unsigned int)(0);
    zT_98 = ctx->lir_slots;
    zT_99 = zT_98.len;
    emitter.fn_slots_len = zT_99;
    zT_100 = ctx->alloc;
    zT_101 = &zT_100->lir_read;
    emitter.spill_arena = zT_101;
    zT_102 = ctx->cli;
    zT_103 = zT_102.debug;
    if (zT_103) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_104 = &ctx->debug_map;
    zT_105.has_value = 1;
    zT_105.value = zT_104;
    emitter.debug_map = zT_105;
    zT_106 = &ctx->debug_spans;
    zT_107.has_value = 1;
    zT_107.value = zT_106;
    emitter.debug_store = zT_107;
    zT_108 = &ctx->debug_symbols;
    zT_109.has_value = 1;
    zT_109.value = zT_108;
    emitter.debug_symbols = zT_109;
    goto z_bb_7;
    z_bb_7:
    zT_110 = &ctx->lir_stream;
    zT_113 = ctx->alloc;
    zT_111 = &zT_113->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_110, zT_111);
    zT_116 = "output";
    zT_118 = 6;
    zT_117.ptr = (unsigned char*)zT_116;
    zT_117.len = zT_118;
    module_name = zT_117;
    zT_121 = ctx->alloc;
    zT_120 = &zT_121->emission;
    zT_123 = zF_58BDA2DE_u32ToU32MapInit(zT_120);
    ts_ref_set = zT_123;
    zT_127 = ctx->alloc;
    zT_125 = &zT_127->emission;
    zT_129 = ctx->lir_slots;
    zT_126 = zT_129.len;
    zT_131 = zF_619D56E6_u32ToU32MapInitCap(zT_125, zT_126);
    ref_edges = zT_131;
    zT_134 = ctx->alloc;
    zT_133 = &zT_134->emission;
    zT_136 = zF_986226E1_u64ToU32MapInit(zT_133);
    type_visited = zT_136;
    zT_138 = 0;
    ts_fi = zT_138;
    goto z_bb_8;
    z_bb_8:
    zT_139 = ctx->lir_slots;
    zT_140 = zT_139.len;
    if ((unsigned char)(ts_fi < zT_140)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_143 = &ctx->lir_stream;
    zT_147 = ctx->lir_slots;
    zT_148 = zT_147.items;
    zT_149 = zT_148[ts_fi];
    zT_144 = zT_149;
    zT_150 = ctx->alloc;
    zT_145 = &zT_150->lir_read;
    zT_152 = zF_1B7118E0_lirStreamReadFuncti(zT_143, zT_144, zT_145);
    ts_fn = zT_152;
    zT_154 = ts_fn.module_id;
    ts_src = zT_154;
    zT_156 = 0;
    ts_tti = zT_156;
    goto z_bb_12;
    z_bb_10:
    emitter.ts_ref_set = ts_ref_set;
    zT_386 = ctx->module_reg;
    zT_388 = zF_3452C137_moduleRegistryGetMo(zT_386);
    ri_mods = zT_388;
    zT_390 = 0;
    gt_i = zT_390;
    goto z_bb_77;
    z_bb_11:
    zT_384 = ts_fi + (unsigned int)(1);
    ts_fi = zT_384;
    goto z_bb_8;
    z_bb_12:
    zT_157 = ts_fn.hoisted_temps;
    zT_158 = zT_157.len;
    if ((unsigned char)(ts_tti < zT_158)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_161 = ts_fn.hoisted_temps;
    zT_162 = zT_161.items;
    zT_163 = zT_162[ts_tti];
    ts_hty = zT_163;
    zT_164 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_165 = ctx->typereg;
    zT_166 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_167 = ts_src;
    zT_168 = ts_hty.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_164, zT_165, zT_166, zT_167, zT_168);
    goto z_bb_15;
    z_bb_14:
    zT_175 = ts_fn.return_type;
    zT_176 = ctx->typereg;
    zT_177 = zT_176->types_len;
    if ((unsigned char)(zT_175 < (unsigned int)((unsigned int)zT_177))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_174 = ts_tti + (unsigned int)(1);
    ts_tti = zT_174;
    goto z_bb_12;
    z_bb_16:
    zT_180 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_181 = ctx->typereg;
    zT_182 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_183 = ts_src;
    zT_184 = ts_fn.return_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_180, zT_181, zT_182, zT_183, zT_184);
    goto z_bb_17;
    z_bb_17:
    zT_190 = 0;
    ts_pi = zT_190;
    goto z_bb_18;
    z_bb_18:
    zT_191 = ts_fn.params;
    zT_192 = zT_191.len;
    if ((unsigned char)(ts_pi < zT_192)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_195 = ts_fn.params;
    zT_196 = zT_195.items;
    zT_197 = zT_196[ts_pi];
    ts_pt = zT_197;
    zT_198 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_199 = ctx->typereg;
    zT_200 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_201 = ts_src;
    zT_202 = ts_pt.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_198, zT_199, zT_200, zT_201, zT_202);
    goto z_bb_21;
    z_bb_20:
    zT_210 = 0;
    ts_bi = zT_210;
    goto z_bb_22;
    z_bb_21:
    zT_208 = ts_pi + (unsigned int)(1);
    ts_pi = zT_208;
    goto z_bb_18;
    z_bb_22:
    zT_211 = ts_fn.blocks;
    zT_212 = zT_211.len;
    if ((unsigned char)(ts_bi < zT_212)) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_215 = ts_fn.blocks;
    zT_216 = zT_215.items;
    zT_217 = zT_216[ts_bi];
    ts_blk = zT_217;
    zT_219 = 0;
    ts_ii = zT_219;
    goto z_bb_26;
    z_bb_24:
    goto z_bb_11;
    z_bb_25:
    zT_382 = ts_bi + (unsigned int)(1);
    ts_bi = zT_382;
    goto z_bb_22;
    z_bb_26:
    zT_220 = ts_blk.insts;
    zT_221 = zT_220.len;
    if ((unsigned char)(ts_ii < zT_221)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_224 = ts_blk.insts;
    zT_225 = zT_224.items;
    zT_226 = zT_225[ts_ii];
    ts_inst = zT_226;
    zT_228 = ts_inst.tag;
    ts_tg = zT_228;
    zT_230 = 0;
    ts_edge_has = zT_230;
    zT_232 = 0;
    ts_edge_dst = zT_232;
    zT_235.tag = 23;
    if ((unsigned char)(ts_tg == zT_235.tag)) goto z_bb_30; else goto z_bb_32;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_380 = ts_ii + (unsigned int)(1);
    ts_ii = zT_380;
    goto z_bb_26;
    z_bb_30:
    zT_238 = (zT_BBC23664_LirFunction*)&ts_fn;
    zT_239 = ts_inst.payload.jump._0;
    zT_243 = zF_75DE985C_lirSideGetCallDirec(zT_238, zT_239);
    ts_cd = zT_243;
    zT_244 = ts_cd.module_id;
    ts_edge_dst = zT_244;
    zT_245 = 1;
    ts_edge_has = zT_245;
    goto z_bb_31;
    z_bb_31:
    if ((unsigned char)(ts_edge_has != (unsigned char)(0))) goto z_bb_44; else goto z_bb_45;
    z_bb_32:
    zT_248.tag = 27;
    if ((unsigned char)(ts_tg == zT_248.tag)) goto z_bb_33; else goto z_bb_35;
    z_bb_33:
    zT_251 = (zT_BBC23664_LirFunction*)&ts_fn;
    zT_252 = ts_inst.payload.jump._0;
    zT_256 = zF_1AB3807F_lirSideGetTailCall(zT_251, zT_252);
    ts_tc = zT_256;
    zT_257 = ts_tc.module_id;
    ts_edge_dst = zT_257;
    zT_258 = 1;
    ts_edge_has = zT_258;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_261.tag = 28;
    if ((unsigned char)(ts_tg == zT_261.tag)) goto z_bb_36; else goto z_bb_38;
    z_bb_36:
    zT_264 = ts_inst.payload.func_ref._0;
    zT_265 = zT_264.module_id;
    ts_edge_dst = zT_265;
    zT_266 = 1;
    ts_edge_has = zT_266;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_269.tag = 54;
    if ((unsigned char)(ts_tg == zT_269.tag)) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_272 = ts_inst.payload.load_global._0;
    zT_273 = zT_272.module_id;
    ts_edge_dst = zT_273;
    zT_274 = 1;
    ts_edge_has = zT_274;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_277.tag = 55;
    if ((unsigned char)(ts_tg == zT_277.tag)) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_280 = ts_inst.payload.store_global._0;
    zT_281 = zT_280.module_id;
    ts_edge_dst = zT_281;
    zT_282 = 1;
    ts_edge_has = zT_282;
    goto z_bb_43;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_285 = ts_edge_dst != ts_src;
    goto z_bb_46;
    z_bb_45:
    zT_285 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_285) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_287 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zF_26476265_u32ToU32MapPut(zT_287, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + ts_edge_dst), (unsigned int)(1));
    goto z_bb_48;
    z_bb_48:
    zT_297.tag = 57;
    if ((unsigned char)(ts_tg == zT_297.tag)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_300 = emitter.std_fmt_module_id;
    zT_299 = zT_300 != (unsigned int)(4294967295u);
    goto z_bb_51;
    z_bb_50:
    zT_299 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_299) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_303 = emitter.std_fmt_module_id;
    if ((unsigned char)(zT_303 != ts_src)) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_316.tag = 54;
    if ((unsigned char)(ts_tg != zT_316.tag)) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    zT_305 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_311 = emitter.std_fmt_module_id;
    zF_26476265_u32ToU32MapPut(zT_305, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + zT_311), (unsigned int)(1));
    goto z_bb_55;
    z_bb_55:
    goto z_bb_53;
    z_bb_56:
    zT_321.tag = 55;
    zT_318 = ts_tg != zT_321.tag;
    goto z_bb_58;
    z_bb_57:
    zT_318 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_318) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    goto z_bb_29;
    z_bb_60:
    zT_324 = 0;
    ts_name_id = zT_324;
    zT_326 = 0;
    ts_tmp = zT_326;
    zT_329.tag = 54;
    if ((unsigned char)(ts_tg == zT_329.tag)) goto z_bb_61; else goto z_bb_63;
    z_bb_61:
    zT_332 = ts_inst.payload.load_global._0;
    zT_333 = zT_332.name_id;
    ts_name_id = zT_333;
    zT_335 = ts_inst.payload.load_global._0;
    zT_336 = zT_335.result;
    ts_tmp = zT_336;
    goto z_bb_62;
    z_bb_62:
    zT_344 = 0;
    ts_tid = zT_344;
    zT_346 = 0;
    ts_tj = zT_346;
    goto z_bb_64;
    z_bb_63:
    zT_338 = ts_inst.payload.store_global._0;
    zT_339 = zT_338.name_id;
    ts_name_id = zT_339;
    zT_341 = ts_inst.payload.store_global._0;
    zT_342 = zT_341.value;
    ts_tmp = zT_342;
    goto z_bb_62;
    z_bb_64:
    zT_347 = ts_fn.hoisted_temps;
    zT_348 = zT_347.len;
    if ((unsigned char)(ts_tj < zT_348)) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_351 = ts_fn.hoisted_temps;
    zT_352 = zT_351.items;
    zT_353 = zT_352[ts_tj];
    ts_ht = zT_353;
    zT_354 = ts_ht.temp_id;
    if ((unsigned char)(zT_354 == ts_tmp)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    zT_359 = ctx->typereg;
    zT_360 = zT_359->types_len;
    if ((unsigned char)(ts_tid >= (unsigned int)((unsigned int)zT_360))) goto z_bb_70; else goto z_bb_71;
    z_bb_67:
    zT_358 = ts_tj + (unsigned int)(1);
    ts_tj = zT_358;
    goto z_bb_64;
    z_bb_68:
    zT_356 = ts_ht.type_id;
    ts_tid = zT_356;
    goto z_bb_66;
    z_bb_69:
    goto z_bb_67;
    z_bb_70:
    goto z_bb_29;
    z_bb_71:
    zT_364 = ctx->typereg;
    zT_365 = zT_364->types_items;
    zT_366 = (unsigned int)ts_tid;
    zT_367 = zT_365[zT_366];
    ts_ty = zT_367;
    zT_368 = ts_ty.name_id;
    if ((unsigned char)(zT_368 != (unsigned int)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_372 = ts_ty.name_id;
    zT_371 = zT_372 == ts_name_id;
    goto z_bb_74;
    z_bb_73:
    zT_371 = 0;
    goto z_bb_74;
    z_bb_74:
    if (zT_371) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_374 = (zT_21D3708C_U32ToU32Map*)&ts_ref_set;
    zT_375 = ts_tid;
    zF_26476265_u32ToU32MapPut(zT_374, zT_375, (unsigned int)(1));
    goto z_bb_76;
    z_bb_76:
    goto z_bb_29;
    z_bb_77:
    zT_391 = ctx->global_decls;
    zT_392 = zT_391.len;
    if ((unsigned char)(gt_i < zT_392)) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_395 = ctx->global_decls;
    zT_396 = zT_395.items;
    zT_397 = zT_396[gt_i];
    gt_g = zT_397;
    zT_398 = gt_g.type_id;
    zT_399 = ctx->typereg;
    zT_400 = zT_399->types_len;
    if ((unsigned char)(zT_398 >= (unsigned int)((unsigned int)zT_400))) goto z_bb_81; else goto z_bb_82;
    z_bb_79:
    zT_431 = ctx->alloc;
    zT_429 = &zT_431->emission;
    zT_430 = ri_mods.len;
    zT_435 = zF_619D56E6_u32ToU32MapInitCap(zT_429, zT_430);
    reachable = zT_435;
    zT_436 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zF_26476265_u32ToU32MapPut(zT_436, (unsigned int)(0), (unsigned int)(1));
    zT_443 = 1;
    rf_changed = zT_443;
    goto z_bb_88;
    z_bb_80:
    zT_427 = gt_i + (unsigned int)(1);
    gt_i = zT_427;
    goto z_bb_77;
    z_bb_81:
    goto z_bb_80;
    z_bb_82:
    zT_404 = ctx->typereg;
    zT_405 = zT_404->types_items;
    zT_406 = gt_g.type_id;
    zT_407 = (unsigned int)zT_406;
    zT_408 = zT_405[zT_407];
    gt_ty = zT_408;
    zT_409 = gt_ty.name_id;
    if ((unsigned char)(zT_409 != (unsigned int)(0))) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_413 = gt_ty.name_id;
    zT_414 = gt_g.name_id;
    zT_412 = zT_413 == zT_414;
    goto z_bb_85;
    z_bb_84:
    zT_412 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_412) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    goto z_bb_80;
    z_bb_87:
    zT_416 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_417 = ctx->typereg;
    zT_418 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_419 = gt_g.module_id;
    zT_420 = gt_g.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_416, zT_417, zT_418, zT_419, zT_420);
    goto z_bb_80;
    z_bb_88:
    if ((unsigned char)(rf_changed != (unsigned char)(0))) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_446 = 0;
    rf_changed = zT_446;
    zT_448 = 0;
    rf_s = zT_448;
    goto z_bb_92;
    z_bb_90:
    zT_496 = 0;
    ri_i = zT_496;
    goto z_bb_108;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_450 = ri_mods.len;
    if ((unsigned char)(rf_s < zT_450)) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_453 = ri_mods.ptr;
    zT_454 = zT_453[rf_s];
    zT_455 = zT_454.id;
    rf_src = zT_455;
    zT_456 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_457 = rf_src;
    zT_459 = zF_F3EE5998_u32ToU32MapGet(zT_456, zT_457);
    zT_460 = zT_459.has_value;
    if ((unsigned char)(!zT_460)) goto z_bb_96; else goto z_bb_97;
    z_bb_94:
    goto z_bb_91;
    z_bb_95:
    zT_494 = rf_s + (unsigned int)(1);
    rf_s = zT_494;
    goto z_bb_92;
    z_bb_96:
    goto z_bb_95;
    z_bb_97:
    zT_463 = 0;
    rf_d = zT_463;
    goto z_bb_98;
    z_bb_98:
    zT_465 = ri_mods.len;
    if ((unsigned char)(rf_d < zT_465)) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_468 = ri_mods.ptr;
    zT_469 = zT_468[rf_d];
    zT_470 = zT_469.id;
    rf_dst = zT_470;
    if ((unsigned char)(rf_dst == rf_src)) goto z_bb_102; else goto z_bb_103;
    z_bb_100:
    goto z_bb_95;
    z_bb_101:
    zT_492 = rf_d + (unsigned int)(1);
    rf_d = zT_492;
    goto z_bb_98;
    z_bb_102:
    goto z_bb_101;
    z_bb_103:
    zT_472 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_473 = rf_dst;
    zT_475 = zF_F3EE5998_u32ToU32MapGet(zT_472, zT_473);
    zT_476 = zT_475.has_value;
    if (zT_476) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    goto z_bb_101;
    z_bb_105:
    zT_477 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_483 = zF_F3EE5998_u32ToU32MapGet(zT_477, (unsigned int)((unsigned int)(rf_src * (unsigned int)(65536)) + rf_dst));
    zT_484 = zT_483.has_value;
    if (zT_484) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    zT_485 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_486 = rf_dst;
    zF_26476265_u32ToU32MapPut(zT_485, zT_486, (unsigned int)(1));
    zT_490 = 1;
    rf_changed = zT_490;
    goto z_bb_107;
    z_bb_107:
    goto z_bb_101;
    z_bb_108:
    zT_498 = ri_mods.len;
    if ((unsigned char)(ri_i < zT_498)) goto z_bb_109; else goto z_bb_110;
    z_bb_109:
    zT_500 = ri_mods.ptr;
    zT_501 = zT_500[ri_i];
    zT_502 = zT_501.id;
    if ((unsigned char)(zT_502 == (unsigned int)(0))) goto z_bb_112; else goto z_bb_113;
    z_bb_110:
    emitter.reachable = reachable;
    zT_553 = ctx->cli;
    zT_554 = zT_553.output_dir_set;
    if (zT_554) goto z_bb_127; else goto z_bb_128;
    z_bb_111:
    zT_552 = ri_i + (unsigned int)(1);
    ri_i = zT_552;
    goto z_bb_108;
    z_bb_112:
    goto z_bb_111;
    z_bb_113:
    zT_505 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_508 = ri_mods.ptr;
    zT_509 = zT_508[ri_i];
    zT_506 = zT_509.id;
    zT_511 = zF_F3EE5998_u32ToU32MapGet(zT_505, zT_506);
    zT_512 = zT_511.has_value;
    if ((unsigned char)(!zT_512)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_515 = 0;
    ri_has = zT_515;
    zT_517 = 0;
    gd_ri = zT_517;
    goto z_bb_116;
    z_bb_116:
    zT_518 = ctx->global_decls;
    zT_519 = zT_518.len;
    if ((unsigned char)(gd_ri < zT_519)) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    zT_522 = ctx->global_decls;
    zT_523 = zT_522.items;
    zT_524 = zT_523[gd_ri];
    gd_g = zT_524;
    zT_525 = gd_g.module_id;
    zT_526 = ri_mods.ptr;
    zT_527 = zT_526[ri_i];
    zT_528 = zT_527.id;
    if ((unsigned char)(zT_525 == zT_528)) goto z_bb_120; else goto z_bb_121;
    z_bb_118:
    if ((unsigned char)(ri_has != (unsigned char)(0))) goto z_bb_125; else goto z_bb_126;
    z_bb_119:
    zT_536 = gd_ri + (unsigned int)(1);
    gd_ri = zT_536;
    goto z_bb_116;
    z_bb_120:
    zT_531 = gd_g.has_runtime_init;
    zT_530 = zT_531 != (unsigned char)(0);
    goto z_bb_122;
    z_bb_121:
    zT_530 = 0;
    goto z_bb_122;
    z_bb_122:
    if (zT_530) goto z_bb_123; else goto z_bb_124;
    z_bb_123:
    zT_534 = 1;
    ri_has = zT_534;
    goto z_bb_118;
    z_bb_124:
    goto z_bb_119;
    z_bb_125:
    zT_539 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_546 = ri_mods.ptr;
    zT_547 = zT_546[ri_i];
    zT_548 = zT_547.id;
    zF_26476265_u32ToU32MapPut(zT_539, (unsigned int)((unsigned int)(0) + zT_548), (unsigned int)(1));
    goto z_bb_126;
    z_bb_126:
    goto z_bb_111;
    z_bb_127:
    zT_555 = ctx->cli;
    zT_556 = zT_555.debug;
    if (zT_556) goto z_bb_129; else goto z_bb_130;
    z_bb_128:
    cwriter = zT_1291;
    zT_1292 = zF_F9E678C3_bufferedWriterInit();
    cwriter = zT_1292;
    zT_1293 = (zT_63BE4FF5_BufferedWriter*)&cwriter;
    zF_225796FB_emitIncludes(zT_1293);
    zT_1295 = (zT_63BE4FF5_BufferedWriter*)&cwriter;
    zF_B35650AD_bufferedWriterFlush(zT_1295);
    zT_1298 = ctx->module_reg;
    zT_1301 = ctx->alloc;
    zT_1299 = &zT_1301->emission;
    zT_1303 = zF_1E2E8788_cincludeUnionAll(zT_1298, zT_1299);
    c_incs = zT_1303;
    zT_1304 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1305 = module_name;
    zT_1306 = c_incs;
    zF_503E3056_emitModule(zT_1304, zT_1305, zT_1306);
    zT_1309 = "FINAL_FLUSH\n";
    zT_1311 = 12;
    zT_1310.ptr = (unsigned char*)zT_1309;
    zT_1310.len = zT_1311;
    ff_m = zT_1310;
    zT_1312 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1312);
    zT_1314 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1313 = &zT_1314->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1313);
    zT_1316 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1316);
    zT_1318 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1318);
    return;
    z_bb_129:
    zT_558 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_561 = 0;
    zT_563 = zF_E295413A_moduleQualifiedName(zT_558, (unsigned int)((unsigned int)zT_561));
    dbg_root_stem = zT_563;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_565[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        dbg_p1[_i] = zT_565[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_567[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        dbg_p2[_i] = zT_567[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_569[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        dbg_p3[_i] = zT_569[_i];
        _i++;
    }
}
    zT_571 = "syms";
    zT_573 = 4;
    zT_572.ptr = (unsigned char*)zT_571;
    zT_572.len = zT_573;
    dbg_e1 = zT_572;
    zT_575 = "lines";
    zT_577 = 5;
    zT_576.ptr = (unsigned char*)zT_575;
    zT_576.len = zT_577;
    dbg_e2 = zT_576;
    zT_579 = "cnames";
    zT_581 = 6;
    zT_580.ptr = (unsigned char*)zT_579;
    zT_580.len = zT_581;
    dbg_e3 = zT_580;
    zT_589 = 0;
    zT_590 = (unsigned char*)((unsigned char*)dbg_p1) + zT_589;
    zT_591 = (unsigned int)(512) - zT_589;
    zT_592.ptr = (unsigned char*)zT_590;
    zT_592.len = zT_591;
    zT_583 = zT_592;
    zT_593 = ctx->cli;
    zT_594 = zT_593.output_dir;
    zT_584 = zT_594;
    zT_585 = dbg_root_stem;
    zT_586 = dbg_e1;
    zT_595 = zF_5E17F383_buildDebugMapPath(zT_583, zT_584, zT_585, zT_586);
    dbg_n1 = zT_595;
    zT_603 = 0;
    zT_604 = (unsigned char*)((unsigned char*)dbg_p2) + zT_603;
    zT_605 = (unsigned int)(512) - zT_603;
    zT_606.ptr = (unsigned char*)zT_604;
    zT_606.len = zT_605;
    zT_597 = zT_606;
    zT_607 = ctx->cli;
    zT_608 = zT_607.output_dir;
    zT_598 = zT_608;
    zT_599 = dbg_root_stem;
    zT_600 = dbg_e2;
    zT_609 = zF_5E17F383_buildDebugMapPath(zT_597, zT_598, zT_599, zT_600);
    dbg_n2 = zT_609;
    zT_617 = 0;
    zT_618 = (unsigned char*)((unsigned char*)dbg_p3) + zT_617;
    zT_619 = (unsigned int)(512) - zT_617;
    zT_620.ptr = (unsigned char*)zT_618;
    zT_620.len = zT_619;
    zT_611 = zT_620;
    zT_621 = ctx->cli;
    zT_622 = zT_621.output_dir;
    zT_612 = zT_622;
    zT_613 = dbg_root_stem;
    zT_614 = dbg_e3;
    zT_623 = zF_5E17F383_buildDebugMapPath(zT_611, zT_612, zT_613, zT_614);
    dbg_n3 = zT_623;
    zT_624 = &ctx->debug_map;
    zT_630 = ctx->alloc;
    zT_625 = &zT_630->emission;
    zT_634 = 0;
    zT_635 = (unsigned char*)((unsigned char*)dbg_p1) + zT_634;
    zT_636 = dbg_n1 - zT_634;
    zT_637.ptr = (unsigned char*)zT_635;
    zT_637.len = zT_636;
    zT_626 = zT_637;
    zT_640 = 0;
    zT_641 = (unsigned char*)((unsigned char*)dbg_p2) + zT_640;
    zT_642 = dbg_n2 - zT_640;
    zT_643.ptr = (unsigned char*)zT_641;
    zT_643.len = zT_642;
    zT_627 = zT_643;
    zT_646 = 0;
    zT_647 = (unsigned char*)((unsigned char*)dbg_p3) + zT_646;
    zT_648 = dbg_n3 - zT_646;
    zT_649.ptr = (unsigned char*)zT_647;
    zT_649.len = zT_648;
    zT_628 = zT_649;
    zF_ED14666D_debugMapWriterOpen(zT_624, zT_625, zT_626, zT_627, zT_628);
    goto z_bb_130;
    z_bb_130:
    zT_651 = ctx->spell_plan;
    zT_652 = zT_651.typedef_order;
    sorted = zT_652;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_654[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hpath[_i] = zT_654[_i];
        _i++;
    }
}
    zT_656 = 0;
    hp = zT_656;
    zT_658 = ctx->cli;
    zT_659 = zT_658.output_dir;
    od = zT_659;
    zT_660 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_661 = od;
    zF_AB1E9CD4_emitSupportFiles(zT_660, zT_661);
    zT_664 = 0;
    hi = zT_664;
    goto z_bb_131;
    z_bb_131:
    zT_666 = od.len;
    if ((unsigned char)(hi < zT_666)) goto z_bb_135; else goto z_bb_136;
    z_bb_132:
    zT_671 = od.ptr;
    zT_672 = zT_671[hi];
    hpath[hp] = zT_672;
    zT_673 = 1;
    zT_675 = hp + (unsigned int)((unsigned int)zT_673);
    hp = zT_675;
    goto z_bb_134;
    z_bb_133:
    zT_679 = 47;
    hpath[hp] = zT_679;
    zT_680 = 1;
    zT_682 = hp + (unsigned int)((unsigned int)zT_680);
    hp = zT_682;
    zT_684 = "zig_special_types.h";
    zT_686 = 19;
    zT_685.ptr = (unsigned char*)zT_684;
    zT_685.len = zT_686;
    hfn = zT_685;
    zT_688 = 0;
    hfi = zT_688;
    goto z_bb_138;
    z_bb_134:
    zT_676 = 1;
    zT_678 = hi + (unsigned int)((unsigned int)zT_676);
    hi = zT_678;
    goto z_bb_131;
    z_bb_135:
    zT_668 = hp < (unsigned int)(510);
    goto z_bb_137;
    z_bb_136:
    zT_668 = 0;
    goto z_bb_137;
    z_bb_137:
    if (zT_668) goto z_bb_132; else goto z_bb_133;
    z_bb_138:
    zT_690 = hfn.len;
    if ((unsigned char)(hfi < zT_690)) goto z_bb_142; else goto z_bb_143;
    z_bb_139:
    zT_695 = hfn.ptr;
    zT_696 = zT_695[hfi];
    hpath[hp] = zT_696;
    zT_697 = 1;
    zT_699 = hp + (unsigned int)((unsigned int)zT_697);
    hp = zT_699;
    goto z_bb_141;
    z_bb_140:
    zT_708 = 0;
    zT_709 = (unsigned char*)((unsigned char*)hpath) + zT_708;
    zT_710 = hp - zT_708;
    zT_711.ptr = (unsigned char*)zT_709;
    zT_711.len = zT_710;
    zT_704 = zT_711;
    zT_713 = zF_39FE21EF_fileOpen(zT_704, (int)(0));
    fd = zT_713;
    if ((unsigned char)(fd == (unsigned int)(4294967295u))) goto z_bb_145; else goto z_bb_146;
    z_bb_141:
    zT_700 = 1;
    zT_702 = hfi + (unsigned int)((unsigned int)zT_700);
    hfi = zT_702;
    goto z_bb_138;
    z_bb_142:
    zT_692 = hp < (unsigned int)(511);
    goto z_bb_144;
    z_bb_143:
    zT_692 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_692) goto z_bb_139; else goto z_bb_140;
    z_bb_145:
    zT_717 = "error: cannot open output file\n";
    zT_719 = 31;
    zT_718.ptr = (unsigned char*)zT_717;
    zT_718.len = zT_719;
    emsg = zT_718;
    zT_720 = emsg;
    zF_E4B2EF19_stderr_write(zT_720);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_146;
    z_bb_146:
    hw = zT_724;
    zT_725 = fd;
    zT_726 = zF_E00097E1_bufferedWriterInitF(zT_725);
    hw = zT_726;
    emitter.writer = hw;
    zT_727 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_728 = ctx->typereg;
    zT_729 = sorted;
    zF_62841416_emitSharedHeader(zT_727, zT_728, zT_729);
    zT_733 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_732 = &zT_733->writer;
    zF_B35650AD_bufferedWriterFlush(zT_732);
    zT_735 = fd;
    zF_B30B1D79_fileClose(zT_735);
    zT_737 = ctx->module_reg;
    zT_739 = zF_3452C137_moduleRegistryGetMo(zT_737);
    mods = zT_739;
    emitter.prune_active = (unsigned char)(1);
    zT_742 = ctx->lir_slots;
    zT_743 = zT_742.len;
    slot_count = zT_743;
    zT_744 = 0;
    if ((unsigned char)(slot_count > (unsigned int)zT_744)) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_750 = ctx->alloc;
    zT_747 = &zT_750->emission;
    zT_754 = mods.len;
    zT_757 = zF_1395EB68_sandAlloc(zT_747, (unsigned int)((unsigned int)(4) * zT_754), (unsigned int)(4));
    zT_758 = zT_757.is_error;
    if (zT_758) goto z_bb_149; else goto z_bb_150;
    z_bb_148:
    zT_858 = 0;
    fn_cursor = zT_858;
    zT_860 = 0;
    mi = zT_860;
    goto z_bb_178;
    z_bb_149:
    pal_trap();
    z_bb_150:
    zT_759 = zT_757.data.payload;
    goto z_bb_151;
    z_bb_151:
    zT_761 = (unsigned int*)zT_759;
    grp_counts = zT_761;
    zT_766 = ctx->alloc;
    zT_763 = &zT_766->emission;
    zT_770 = mods.len;
    zT_773 = zF_1395EB68_sandAlloc(zT_763, (unsigned int)((unsigned int)(4) * zT_770), (unsigned int)(4));
    zT_774 = zT_773.is_error;
    if (zT_774) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    pal_trap();
    z_bb_153:
    zT_775 = zT_773.data.payload;
    goto z_bb_154;
    z_bb_154:
    zT_777 = (unsigned int*)zT_775;
    grp_cursor = zT_777;
    zT_779 = 0;
    gci = zT_779;
    goto z_bb_155;
    z_bb_155:
    zT_781 = mods.len;
    if ((unsigned char)(gci < zT_781)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_783 = 0;
    grp_counts[gci] = zT_783;
    goto z_bb_158;
    z_bb_157:
    zT_788 = 0;
    gsi = zT_788;
    goto z_bb_159;
    z_bb_158:
    zT_784 = 1;
    zT_786 = gci + (unsigned int)((unsigned int)zT_784);
    gci = zT_786;
    goto z_bb_155;
    z_bb_159:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_791 = ctx->lir_slots;
    zT_792 = zT_791.items;
    zT_793 = zT_792[gsi];
    zT_794 = zT_793.module_id;
    gsmid = zT_794;
    zT_797 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) < zT_797)) goto z_bb_163; else goto z_bb_164;
    z_bb_161:
    zT_808 = 0;
    gacc = zT_808;
    zT_809 = 0;
    gci = zT_809;
    goto z_bb_165;
    z_bb_162:
    zT_804 = 1;
    zT_806 = gsi + (unsigned int)((unsigned int)zT_804);
    gsi = zT_806;
    goto z_bb_159;
    z_bb_163:
    zT_799 = (unsigned int)gsmid;
    zT_800 = grp_counts[zT_799];
    zT_802 = zT_800 + (unsigned int)(1);
    zT_803 = (unsigned int)gsmid;
    grp_counts[zT_803] = zT_802;
    goto z_bb_164;
    z_bb_164:
    goto z_bb_162;
    z_bb_165:
    zT_811 = mods.len;
    if ((unsigned char)(gci < zT_811)) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    grp_cursor[gci] = gacc;
    zT_813 = grp_counts[gci];
    zT_814 = gacc + zT_813;
    gacc = zT_814;
    goto z_bb_168;
    z_bb_167:
    zT_822 = ctx->alloc;
    zT_819 = &zT_822->emission;
    zT_827 = zF_1395EB68_sandAlloc(zT_819, (unsigned int)((unsigned int)(12) * slot_count), (unsigned int)(4));
    zT_828 = zT_827.is_error;
    if (zT_828) goto z_bb_169; else goto z_bb_170;
    z_bb_168:
    zT_815 = 1;
    zT_817 = gci + (unsigned int)((unsigned int)zT_815);
    gci = zT_817;
    goto z_bb_165;
    z_bb_169:
    pal_trap();
    z_bb_170:
    zT_829 = zT_827.data.payload;
    goto z_bb_171;
    z_bb_171:
    zT_831 = (zT_E7714190_LirSlot*)zT_829;
    grouped = zT_831;
    zT_832 = 0;
    gsi = zT_832;
    goto z_bb_172;
    z_bb_172:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_173; else goto z_bb_174;
    z_bb_173:
    zT_835 = ctx->lir_slots;
    zT_836 = zT_835.items;
    zT_837 = zT_836[gsi];
    gslot = zT_837;
    zT_839 = gslot.module_id;
    gsmid = zT_839;
    zT_842 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) >= zT_842)) goto z_bb_176; else goto z_bb_177;
    z_bb_174:
    zT_854 = &ctx->lir_slots;
    zT_854->items = grouped;
    zT_856 = &ctx->lir_slots;
    zT_856->len = (unsigned int)((unsigned int)gacc);
    emitter.fn_slots = grouped;
    goto z_bb_148;
    z_bb_175:
    zT_851 = 1;
    zT_853 = gsi + (unsigned int)((unsigned int)zT_851);
    gsi = zT_853;
    goto z_bb_172;
    z_bb_176:
    goto z_bb_175;
    z_bb_177:
    zT_845 = (unsigned int)gsmid;
    zT_846 = grp_cursor[zT_845];
    gdst = zT_846;
    zT_847 = (unsigned int)gdst;
    grouped[zT_847] = gslot;
    zT_849 = gdst + (unsigned int)(1);
    zT_850 = (unsigned int)gsmid;
    grp_cursor[zT_850] = zT_849;
    goto z_bb_175;
    z_bb_178:
    zT_862 = mods.len;
    if ((unsigned char)(mi < zT_862)) goto z_bb_179; else goto z_bb_180;
    z_bb_179:
    zT_865 = mods.ptr;
    zT_866 = zT_865[mi];
    m = zT_866;
    fn_start = fn_cursor;
    goto z_bb_182;
    z_bb_180:
    zT_1249 = ctx->cli;
    zT_1250 = zT_1249.debug;
    if (zT_1250) goto z_bb_280; else goto z_bb_281;
    z_bb_181:
    zT_1246 = 1;
    zT_1248 = mi + (unsigned int)((unsigned int)zT_1246);
    mi = zT_1248;
    goto z_bb_178;
    z_bb_182:
    zT_868 = ctx->lir_slots;
    zT_869 = zT_868.len;
    if ((unsigned char)(fn_cursor < zT_869)) goto z_bb_186; else goto z_bb_187;
    z_bb_183:
    goto z_bb_185;
    z_bb_184:
    zT_880 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_881 = m.id;
    zT_884 = zF_F3EE5998_u32ToU32MapGet(zT_880, zT_881);
    zT_885 = zT_884.has_value;
    if ((unsigned char)(!zT_885)) goto z_bb_189; else goto z_bb_190;
    z_bb_185:
    zT_879 = fn_cursor + (unsigned int)(1);
    fn_cursor = zT_879;
    goto z_bb_182;
    z_bb_186:
    zT_872 = ctx->lir_slots;
    zT_873 = zT_872.items;
    zT_874 = zT_873[fn_cursor];
    zT_875 = zT_874.module_id;
    zT_876 = m.id;
    zT_871 = zT_875 == zT_876;
    goto z_bb_188;
    z_bb_187:
    zT_871 = 0;
    goto z_bb_188;
    z_bb_188:
    if (zT_871) goto z_bb_183; else goto z_bb_184;
    z_bb_189:
    goto z_bb_181;
    z_bb_190:
    emitter.fn_slots_start = fn_start;
    emitter.fn_slots_len = (unsigned int)(fn_cursor - fn_start);
    zT_889 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_890 = m.id;
    zT_893 = zF_E295413A_moduleQualifiedName(zT_889, zT_890);
    base = zT_893;
    zT_895 = od.len;
    zT_899 = base.len;
    if ((unsigned char)((unsigned int)((unsigned int)((unsigned int)(zT_895 + (unsigned int)(1)) + zT_899) + (unsigned int)(3)) > (unsigned int)(511))) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_906 = "error: output filename too long\n";
    zT_908 = 32;
    zT_907.ptr = (unsigned char*)zT_906;
    zT_907.len = zT_908;
    lmsg = zT_907;
    zT_909 = lmsg;
    zF_E4B2EF19_stderr_write(zT_909);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_192;
    z_bb_192:
    zT_913 = 0;
    hp2 = zT_913;
    zT_915 = 0;
    hi2 = zT_915;
    goto z_bb_193;
    z_bb_193:
    zT_917 = od.len;
    if ((unsigned char)(hi2 < zT_917)) goto z_bb_197; else goto z_bb_198;
    z_bb_194:
    zT_922 = od.ptr;
    zT_923 = zT_922[hi2];
    hpath[hp2] = zT_923;
    zT_924 = 1;
    zT_926 = hp2 + (unsigned int)((unsigned int)zT_924);
    hp2 = zT_926;
    goto z_bb_196;
    z_bb_195:
    zT_930 = 47;
    hpath[hp2] = zT_930;
    zT_931 = 1;
    zT_933 = hp2 + (unsigned int)((unsigned int)zT_931);
    hp2 = zT_933;
    zT_935 = 0;
    bi = zT_935;
    goto z_bb_200;
    z_bb_196:
    zT_927 = 1;
    zT_929 = hi2 + (unsigned int)((unsigned int)zT_927);
    hi2 = zT_929;
    goto z_bb_193;
    z_bb_197:
    zT_919 = hp2 < (unsigned int)(510);
    goto z_bb_199;
    z_bb_198:
    zT_919 = 0;
    goto z_bb_199;
    z_bb_199:
    if (zT_919) goto z_bb_194; else goto z_bb_195;
    z_bb_200:
    zT_937 = base.len;
    if ((unsigned char)(bi < zT_937)) goto z_bb_204; else goto z_bb_205;
    z_bb_201:
    zT_942 = base.ptr;
    zT_943 = zT_942[bi];
    hpath[hp2] = zT_943;
    zT_944 = 1;
    zT_946 = hp2 + (unsigned int)((unsigned int)zT_944);
    hp2 = zT_946;
    goto z_bb_203;
    z_bb_202:
    zT_951 = ".h";
    zT_953 = 2;
    zT_952.ptr = (unsigned char*)zT_951;
    zT_952.len = zT_953;
    hext = zT_952;
    zT_955 = 0;
    hx = zT_955;
    goto z_bb_207;
    z_bb_203:
    zT_947 = 1;
    zT_949 = bi + (unsigned int)((unsigned int)zT_947);
    bi = zT_949;
    goto z_bb_200;
    z_bb_204:
    zT_939 = hp2 < (unsigned int)(510);
    goto z_bb_206;
    z_bb_205:
    zT_939 = 0;
    goto z_bb_206;
    z_bb_206:
    if (zT_939) goto z_bb_201; else goto z_bb_202;
    z_bb_207:
    zT_957 = hext.len;
    if ((unsigned char)(hx < zT_957)) goto z_bb_211; else goto z_bb_212;
    z_bb_208:
    zT_962 = hext.ptr;
    zT_963 = zT_962[hx];
    hpath[hp2] = zT_963;
    zT_964 = 1;
    zT_966 = hp2 + (unsigned int)((unsigned int)zT_964);
    hp2 = zT_966;
    goto z_bb_210;
    z_bb_209:
    zT_975 = 0;
    zT_976 = (unsigned char*)((unsigned char*)hpath) + zT_975;
    zT_977 = hp2 - zT_975;
    zT_978.ptr = (unsigned char*)zT_976;
    zT_978.len = zT_977;
    zT_971 = zT_978;
    zT_980 = zF_39FE21EF_fileOpen(zT_971, (int)(0));
    fd2 = zT_980;
    if ((unsigned char)(fd2 == (unsigned int)(4294967295u))) goto z_bb_214; else goto z_bb_215;
    z_bb_210:
    zT_967 = 1;
    zT_969 = hx + (unsigned int)((unsigned int)zT_967);
    hx = zT_969;
    goto z_bb_207;
    z_bb_211:
    zT_959 = hp2 < (unsigned int)(511);
    goto z_bb_213;
    z_bb_212:
    zT_959 = 0;
    goto z_bb_213;
    z_bb_213:
    if (zT_959) goto z_bb_208; else goto z_bb_209;
    z_bb_214:
    zT_984 = "error: cannot open output file\n";
    zT_986 = 31;
    zT_985.ptr = (unsigned char*)zT_984;
    zT_985.len = zT_986;
    emsg2 = zT_985;
    zT_987 = emsg2;
    zF_E4B2EF19_stderr_write(zT_987);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_215;
    z_bb_215:
    hw2 = zT_991;
    zT_992 = fd2;
    zT_993 = zF_E00097E1_bufferedWriterInitF(zT_992);
    hw2 = zT_993;
    emitter.writer = hw2;
    zT_995 = m.imports_start;
    zT_996 = (unsigned int)zT_995;
    dep_start = zT_996;
    zT_998 = m.import_count;
    zT_1000 = dep_start + (unsigned int)((unsigned int)zT_998);
    dep_end = zT_1000;
    zT_1002 = ctx->module_reg;
    zT_1003 = zT_1002->import_edges_items;
    zT_1004 = zT_1003 + dep_start;
    zT_1005 = dep_end - dep_start;
    zT_1006.ptr = (unsigned int*)zT_1004;
    zT_1006.len = zT_1005;
    dep_ids = zT_1006;
    zT_1008 = m.c_includes;
    zT_1009 = zT_1008.items;
    zT_1010 = m.c_includes;
    zT_1011 = zT_1010.len;
    zT_1012 = 0;
    zT_1013 = zT_1009 + zT_1012;
    zT_1014 = zT_1011 - zT_1012;
    zT_1015.ptr = (unsigned int*)zT_1013;
    zT_1015.len = zT_1014;
    m_c_incs = zT_1015;
    zT_1020 = ctx->alloc;
    zT_1017 = &zT_1020->emission;
    zT_1024 = mods.len;
    zT_1027 = zF_1395EB68_sandAlloc(zT_1017, (unsigned int)((unsigned int)(4) * zT_1024), (unsigned int)(4));
    zT_1028 = zT_1027.is_error;
    if (zT_1028) goto z_bb_216; else goto z_bb_217;
    z_bb_216:
    pal_trap();
    z_bb_217:
    zT_1029 = zT_1027.data.payload;
    goto z_bb_218;
    z_bb_218:
    inc_raw = zT_1029;
    zT_1032 = (unsigned int*)inc_raw;
    inc_arr = zT_1032;
    zT_1034 = 0;
    inc_n = zT_1034;
    zT_1036 = 0;
    di0 = zT_1036;
    goto z_bb_219;
    z_bb_219:
    zT_1038 = dep_ids.len;
    if ((unsigned char)(di0 < zT_1038)) goto z_bb_220; else goto z_bb_221;
    z_bb_220:
    zT_1041 = dep_ids.ptr;
    zT_1042 = zT_1041[di0];
    dd0 = zT_1042;
    zT_1043 = m.id;
    if ((unsigned char)(dd0 == zT_1043)) goto z_bb_223; else goto z_bb_224;
    z_bb_221:
    zT_1068 = 0;
    vd0 = zT_1068;
    goto z_bb_235;
    z_bb_222:
    zT_1066 = di0 + (unsigned int)(1);
    di0 = zT_1066;
    goto z_bb_219;
    z_bb_223:
    goto z_bb_222;
    z_bb_224:
    zT_1045 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_1046 = dd0;
    zT_1048 = zF_F3EE5998_u32ToU32MapGet(zT_1045, zT_1046);
    zT_1049 = zT_1048.has_value;
    if ((unsigned char)(!zT_1049)) goto z_bb_225; else goto z_bb_226;
    z_bb_225:
    goto z_bb_222;
    z_bb_226:
    zT_1052 = 0;
    dup0 = zT_1052;
    zT_1054 = 0;
    dj0 = zT_1054;
    goto z_bb_227;
    z_bb_227:
    if ((unsigned char)(dj0 < inc_n)) goto z_bb_228; else goto z_bb_229;
    z_bb_228:
    zT_1056 = inc_arr[dj0];
    if ((unsigned char)(zT_1056 == dd0)) goto z_bb_231; else goto z_bb_232;
    z_bb_229:
    if ((unsigned char)(dup0 != (unsigned char)(0))) goto z_bb_233; else goto z_bb_234;
    z_bb_230:
    zT_1060 = dj0 + (unsigned int)(1);
    dj0 = zT_1060;
    goto z_bb_227;
    z_bb_231:
    zT_1058 = 1;
    dup0 = zT_1058;
    goto z_bb_229;
    z_bb_232:
    goto z_bb_230;
    z_bb_233:
    goto z_bb_222;
    z_bb_234:
    inc_arr[inc_n] = dd0;
    zT_1064 = inc_n + (unsigned int)(1);
    inc_n = zT_1064;
    goto z_bb_222;
    z_bb_235:
    zT_1070 = mods.len;
    if ((unsigned char)(vd0 < zT_1070)) goto z_bb_236; else goto z_bb_237;
    z_bb_236:
    zT_1073 = mods.ptr;
    zT_1074 = zT_1073[vd0];
    zT_1075 = zT_1074.id;
    vdd0 = zT_1075;
    zT_1076 = m.id;
    if ((unsigned char)(vdd0 == zT_1076)) goto z_bb_239; else goto z_bb_240;
    z_bb_237:
    zT_1111 = 0;
    zT_1112 = inc_arr + zT_1111;
    zT_1113 = inc_n - zT_1111;
    zT_1114.ptr = (unsigned int*)zT_1112;
    zT_1114.len = zT_1113;
    inc_slice = zT_1114;
    zT_1115 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1116 = m.id;
    zT_1117 = base;
    zT_1118 = m_c_incs;
    zT_1119 = inc_slice;
    zT_1120 = sorted;
    zF_1AF3E3A9_emitModuleHeaderFil(zT_1115, zT_1116, zT_1117, zT_1118, zT_1119, zT_1120);
    zT_1124 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1123 = &zT_1124->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1123);
    zT_1126 = fd2;
    zF_B30B1D79_fileClose(zT_1126);
    zT_1128 = "FINAL_FLUSH\n";
    zT_1130 = 12;
    zT_1129.ptr = (unsigned char*)zT_1128;
    zT_1129.len = zT_1130;
    ff_m = zT_1129;
    zT_1131 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1131);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_1133[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        cpath[_i] = zT_1133[_i];
        _i++;
    }
}
    zT_1135 = 0;
    cp2 = zT_1135;
    zT_1137 = 0;
    ci2 = zT_1137;
    goto z_bb_253;
    z_bb_238:
    zT_1109 = vd0 + (unsigned int)(1);
    vd0 = zT_1109;
    goto z_bb_235;
    z_bb_239:
    goto z_bb_238;
    z_bb_240:
    zT_1078 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_1079 = vdd0;
    zT_1081 = zF_F3EE5998_u32ToU32MapGet(zT_1078, zT_1079);
    zT_1082 = zT_1081.has_value;
    if ((unsigned char)(!zT_1082)) goto z_bb_241; else goto z_bb_242;
    z_bb_241:
    goto z_bb_238;
    z_bb_242:
    zT_1084 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_1087 = m.id;
    zT_1091 = zF_F3EE5998_u32ToU32MapGet(zT_1084, (unsigned int)((unsigned int)(zT_1087 * (unsigned int)(65536)) + vdd0));
    zT_1092 = zT_1091.has_value;
    if ((unsigned char)(!zT_1092)) goto z_bb_243; else goto z_bb_244;
    z_bb_243:
    goto z_bb_238;
    z_bb_244:
    zT_1095 = 0;
    dup1 = zT_1095;
    zT_1097 = 0;
    dj1 = zT_1097;
    goto z_bb_245;
    z_bb_245:
    if ((unsigned char)(dj1 < inc_n)) goto z_bb_246; else goto z_bb_247;
    z_bb_246:
    zT_1099 = inc_arr[dj1];
    if ((unsigned char)(zT_1099 == vdd0)) goto z_bb_249; else goto z_bb_250;
    z_bb_247:
    if ((unsigned char)(dup1 != (unsigned char)(0))) goto z_bb_251; else goto z_bb_252;
    z_bb_248:
    zT_1103 = dj1 + (unsigned int)(1);
    dj1 = zT_1103;
    goto z_bb_245;
    z_bb_249:
    zT_1101 = 1;
    dup1 = zT_1101;
    goto z_bb_247;
    z_bb_250:
    goto z_bb_248;
    z_bb_251:
    goto z_bb_238;
    z_bb_252:
    inc_arr[inc_n] = vdd0;
    zT_1107 = inc_n + (unsigned int)(1);
    inc_n = zT_1107;
    goto z_bb_238;
    z_bb_253:
    zT_1139 = od.len;
    if ((unsigned char)(ci2 < zT_1139)) goto z_bb_257; else goto z_bb_258;
    z_bb_254:
    zT_1144 = od.ptr;
    zT_1145 = zT_1144[ci2];
    cpath[cp2] = zT_1145;
    zT_1146 = 1;
    zT_1148 = cp2 + (unsigned int)((unsigned int)zT_1146);
    cp2 = zT_1148;
    goto z_bb_256;
    z_bb_255:
    zT_1152 = 47;
    cpath[cp2] = zT_1152;
    zT_1153 = 1;
    zT_1155 = cp2 + (unsigned int)((unsigned int)zT_1153);
    cp2 = zT_1155;
    zT_1157 = 0;
    cbi = zT_1157;
    goto z_bb_260;
    z_bb_256:
    zT_1149 = 1;
    zT_1151 = ci2 + (unsigned int)((unsigned int)zT_1149);
    ci2 = zT_1151;
    goto z_bb_253;
    z_bb_257:
    zT_1141 = cp2 < (unsigned int)(510);
    goto z_bb_259;
    z_bb_258:
    zT_1141 = 0;
    goto z_bb_259;
    z_bb_259:
    if (zT_1141) goto z_bb_254; else goto z_bb_255;
    z_bb_260:
    zT_1159 = base.len;
    if ((unsigned char)(cbi < zT_1159)) goto z_bb_264; else goto z_bb_265;
    z_bb_261:
    zT_1164 = base.ptr;
    zT_1165 = zT_1164[cbi];
    cpath[cp2] = zT_1165;
    zT_1166 = 1;
    zT_1168 = cp2 + (unsigned int)((unsigned int)zT_1166);
    cp2 = zT_1168;
    goto z_bb_263;
    z_bb_262:
    zT_1173 = ".c";
    zT_1175 = 2;
    zT_1174.ptr = (unsigned char*)zT_1173;
    zT_1174.len = zT_1175;
    cext = zT_1174;
    zT_1177 = 0;
    cx = zT_1177;
    goto z_bb_267;
    z_bb_263:
    zT_1169 = 1;
    zT_1171 = cbi + (unsigned int)((unsigned int)zT_1169);
    cbi = zT_1171;
    goto z_bb_260;
    z_bb_264:
    zT_1161 = cp2 < (unsigned int)(510);
    goto z_bb_266;
    z_bb_265:
    zT_1161 = 0;
    goto z_bb_266;
    z_bb_266:
    if (zT_1161) goto z_bb_261; else goto z_bb_262;
    z_bb_267:
    zT_1179 = cext.len;
    if ((unsigned char)(cx < zT_1179)) goto z_bb_271; else goto z_bb_272;
    z_bb_268:
    zT_1184 = cext.ptr;
    zT_1185 = zT_1184[cx];
    cpath[cp2] = zT_1185;
    zT_1186 = 1;
    zT_1188 = cp2 + (unsigned int)((unsigned int)zT_1186);
    cp2 = zT_1188;
    goto z_bb_270;
    z_bb_269:
    zT_1197 = 0;
    zT_1198 = (unsigned char*)((unsigned char*)cpath) + zT_1197;
    zT_1199 = cp2 - zT_1197;
    zT_1200.ptr = (unsigned char*)zT_1198;
    zT_1200.len = zT_1199;
    zT_1193 = zT_1200;
    zT_1202 = zF_39FE21EF_fileOpen(zT_1193, (int)(0));
    cfd = zT_1202;
    if ((unsigned char)(cfd == (unsigned int)(4294967295u))) goto z_bb_274; else goto z_bb_275;
    z_bb_270:
    zT_1189 = 1;
    zT_1191 = cx + (unsigned int)((unsigned int)zT_1189);
    cx = zT_1191;
    goto z_bb_267;
    z_bb_271:
    zT_1181 = cp2 < (unsigned int)(511);
    goto z_bb_273;
    z_bb_272:
    zT_1181 = 0;
    goto z_bb_273;
    z_bb_273:
    if (zT_1181) goto z_bb_268; else goto z_bb_269;
    z_bb_274:
    zT_1206 = "error: cannot open output file\n";
    zT_1208 = 31;
    zT_1207.ptr = (unsigned char*)zT_1206;
    zT_1207.len = zT_1208;
    emsg3 = zT_1207;
    zT_1209 = emsg3;
    zF_E4B2EF19_stderr_write(zT_1209);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_275;
    z_bb_275:
    cw = zT_1213;
    zT_1214 = cfd;
    zT_1215 = zF_E00097E1_bufferedWriterInitF(zT_1214);
    cw = zT_1215;
    emitter.writer = cw;
    zT_1216 = ctx->cli;
    zT_1217 = zT_1216.debug;
    if (zT_1217) goto z_bb_276; else goto z_bb_277;
    z_bb_276:
    zT_1219 = ctx->source_man;
    zT_1220 = m.source_file_id;
    zT_1223 = zF_B7076474_sourceManagerGetFil(zT_1219, zT_1220);
    dbg_src_file = zT_1223;
    zT_1224 = &ctx->debug_map;
    zT_1225 = dbg_src_file;
    zT_1226 = base;
    zF_FFA3F32B_debugMapWriterBegin(zT_1224, zT_1225, zT_1226);
    goto z_bb_277;
    z_bb_277:
    zT_1228 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1229 = m.id;
    zT_1230 = base;
    zF_7B8B9B90_emitModuleFile(zT_1228, zT_1229, zT_1230);
    zT_1233 = ctx->cli;
    zT_1234 = zT_1233.debug;
    if (zT_1234) goto z_bb_278; else goto z_bb_279;
    z_bb_278:
    zT_1235 = &ctx->debug_map;
    zF_B7665FFF_debugMapWriterEndLi(zT_1235);
    goto z_bb_279;
    z_bb_279:
    zT_1238 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1237 = &zT_1238->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1237);
    zT_1240 = cfd;
    zF_B30B1D79_fileClose(zT_1240);
    zT_1242 = "FINAL_FLUSH\n";
    zT_1244 = 12;
    zT_1243.ptr = (unsigned char*)zT_1242;
    zT_1243.len = zT_1244;
    ff2_m = zT_1243;
    zT_1245 = ff2_m;
    zF_48AC7B3A_markerWrite(zT_1245);
    goto z_bb_181;
    z_bb_280:
    zT_1251 = &ctx->debug_map;
    zT_1260 = ctx->alloc;
    zT_1252 = &zT_1260->emission;
    zT_1262 = ctx->debug_symbols;
    zT_1263 = zT_1262.items;
    zT_1264 = ctx->debug_symbols;
    zT_1265 = zT_1264.len;
    zT_1266 = 0;
    zT_1267 = zT_1263 + zT_1266;
    zT_1268 = zT_1265 - zT_1266;
    zT_1269.ptr = (zT_1001656C_DebugSymbol*)zT_1267;
    zT_1269.len = zT_1268;
    zT_1253 = zT_1269;
    zT_1254 = ctx->source_man;
    zT_1255 = (zT_CEC2984A_NameMangler*)&mangler;
    zT_1256 = ctx->interner;
    zT_1257 = ctx->module_reg;
    zT_1258 = ctx->typereg;
    zF_48EEEA4F_debugMapWriterClose(zT_1251, zT_1252, zT_1253, zT_1254, zT_1255, zT_1256, zT_1257, zT_1258);
    zT_1275 = &ctx->debug_spans;
    zF_BE98E387_debugSpanStoreClose(zT_1275);
    goto z_bb_281;
    z_bb_281:
    zT_1277 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1278 = od;
    zT_1282 = ctx->cli;
    zT_1279 = zT_1282.target_is_windows;
    zT_1284 = ctx->cli;
    zT_1280 = zT_1284.target_win_profile;
    zF_A62DB57E_emitBuildScripts(zT_1277, zT_1278, zT_1279, zT_1280);
    zT_1286 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1286);
    zT_1288 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1288);
    return;
}

/* parseArgs */
zT_C98AF326_CompilerCli zF_6143A521_parseArgs(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_C98AF326_CompilerCli zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_CAF40AAB_ColorMode zT_18;
    zT_A4FB690E_ErrorFormat zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned char zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    zT_074080EA_WinProfile zT_36;
    int zT_38 = 0;
    int zT_40;
    int zT_41;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    unsigned char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    unsigned char* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_97;
    unsigned char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    unsigned char* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    unsigned char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    unsigned char* zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned int zT_125;
    unsigned char* zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    unsigned int zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    unsigned char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    unsigned char* zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    unsigned char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    unsigned char* zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_180;
    unsigned int zT_181;
    unsigned char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    unsigned char* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    unsigned int zT_193;
    unsigned char* zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    unsigned char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    int zT_204;
    unsigned char* zT_205 = 0;
    unsigned char* zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208 = {0};
    unsigned int zT_210;
    int zT_211;
    unsigned char zT_213;
    unsigned char* zT_214;
    int zT_215;
    unsigned char zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    unsigned char zT_221 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned char zT_226 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    unsigned char zT_230 = 0;
    unsigned char zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned char zT_234 = 0;
    int zT_235;
    int zT_237;
    unsigned char* zT_239;
    int zT_240;
    unsigned char* zT_241 = 0;
    unsigned int zT_242 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned char zT_244 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    unsigned char* zT_246;
    unsigned int zT_247;
    int zT_248;
    unsigned char* zT_249;
    unsigned int zT_250;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_251;
    unsigned int zT_252 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_253;
    unsigned char zT_254 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char* zT_256;
    unsigned int zT_257;
    int zT_258;
    unsigned char* zT_259;
    unsigned int zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    unsigned int zT_262 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    unsigned char zT_265 = 0;
    unsigned char zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_268;
    unsigned char zT_269 = 0;
    int zT_270;
    int zT_272;
    unsigned char* zT_274;
    int zT_275;
    unsigned char* zT_276 = 0;
    unsigned int zT_277 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    unsigned char zT_280 = 0;
    unsigned char zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    unsigned char zT_284 = 0;
    int zT_285;
    int zT_287;
    unsigned char* zT_289;
    int zT_290;
    unsigned char* zT_291 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned char zT_296 = 0;
    unsigned char zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    unsigned char zT_300 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    unsigned char zT_304 = 0;
    unsigned char zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    unsigned char zT_308 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    unsigned char zT_312 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_314;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    unsigned char zT_316 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_318;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    unsigned char zT_320 = 0;
    unsigned char zT_321;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned char zT_324 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    unsigned char zT_328 = 0;
    int zT_329;
    int zT_331;
    unsigned char* zT_333;
    int zT_334;
    unsigned char* zT_335 = 0;
    zT_CAF40AAB_ColorMode zT_336 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned char zT_339 = 0;
    int zT_340;
    int zT_342;
    unsigned char* zT_344;
    int zT_345;
    unsigned char* zT_346 = 0;
    zT_A4FB690E_ErrorFormat zT_347 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_349;
    unsigned char zT_350 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_352;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_353;
    unsigned char zT_354 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned char zT_358 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_361;
    unsigned char zT_362 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    unsigned char zT_366 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_368;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_369;
    unsigned char zT_370 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_373;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_374;
    unsigned char zT_375 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_377;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_378;
    unsigned char zT_379 = 0;
    unsigned char zT_380;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_381;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_382;
    unsigned char zT_383 = 0;
    int zT_384;
    int zT_386;
    unsigned char zT_388;
    unsigned int zT_389;
    int zT_390;
    unsigned char* zT_392;
    int zT_393;
    unsigned char* zT_394 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_395 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    int zT_400;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_403;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_404;
    unsigned char zT_405 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_408;
    unsigned char zT_409 = 0;
    int zT_413;
    unsigned char* zT_417;
    int zT_419;
    unsigned char* zT_421 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_422 = {0};
    unsigned int zT_424;
    int zT_425;
    unsigned char zT_427;
    unsigned char* zT_428;
    int zT_429;
    unsigned char zT_430;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    unsigned char zT_435 = 0;
    int zT_438;
    int zT_440;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_441;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_442;
    unsigned char zT_443 = 0;
    int zT_446;
    int zT_448;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_449;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_450;
    unsigned char zT_451 = 0;
    int zT_452;
    int zT_454;
    unsigned char* zT_456;
    int zT_457;
    unsigned char* zT_458 = 0;
    unsigned char zT_459 = 0;
    unsigned char zT_460;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_463;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_464;
    unsigned char zT_465 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_467;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_468;
    unsigned char zT_469 = 0;
    unsigned char* zT_471;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_472 = {0};
    unsigned char* zT_473;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_474 = {0};
    int zT_475;
    int zT_477;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u dot_str;
    zT_C98AF326_CompilerCli cli;
    int argc;
    int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dump_c89;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_mem;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_errors;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_output_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_quiet;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_debug;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_d;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sanity_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warnings;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_color;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_error_format;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_track_memory;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_lifetime;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_leak;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_all;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_error;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_markers;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_include;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_lib_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_o;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_q;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_W;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osw;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_profile_9x;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_profile_nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fsafe;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ffast;
    unsigned char* arg_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u arg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nxt;
    zT_1 = "";
    zT_3 = 0;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    empty_str = zT_2;
    zT_5 = ".";
    zT_7 = 1;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    dot_str = zT_6;
    zT_9.input_file = empty_str;
    zT_9.output_dir = dot_str;
    zT_10 = 0;
    zT_9.output_dir_set = zT_10;
    zT_11 = 0;
    zT_9.dump_types = zT_11;
    zT_12 = 0;
    zT_9.dump_lir = zT_12;
    zT_13 = 0;
    zT_9.dump_c89 = zT_13;
    zT_15 = 65536;
    zT_9.max_mem = zT_15;
    zT_16 = 0;
    zT_9.spill_level = zT_16;
    zT_17 = 256;
    zT_9.max_errors = zT_17;
    zT_18 = zT_CAF40AAB_ColorMode_auto;
    zT_9.color = zT_18;
    zT_19 = zT_A4FB690E_ErrorFormat_human;
    zT_9.error_format = zT_19;
    zT_20 = 0;
    zT_9.warnings_as_errors = zT_20;
    zT_21 = 0;
    zT_9.quiet = zT_21;
    zT_22 = 0;
    zT_9.debug = zT_22;
    zT_23 = 0;
    zT_9.test_mode = zT_23;
    zT_24 = 0;
    zT_9.sanity_test_mode = zT_24;
    zT_25 = 0;
    zT_9.track_memory = zT_25;
    zT_26 = 0;
    zT_9.no_null_check = zT_26;
    zT_27 = 0;
    zT_9.no_lifetime_check = zT_27;
    zT_28 = 0;
    zT_9.no_leak_check = zT_28;
    zT_29 = 1;
    zT_9.safe_checks = zT_29;
    zT_30 = 0;
    zT_9.warn_all = zT_30;
    zT_31 = 0;
    zT_9.warn_error = zT_31;
    zT_32 = 0;
    zT_9.show_markers = zT_32;
    zT_33 = 0;
    zT_9.include_count = zT_33;
    zT_34 = 0;
    zT_9.target_is_windows = zT_34;
    zT_36 = zT_074080EA_WinProfile_win9x;
    zT_9.target_win_profile = zT_36;
    cli = zT_9;
    zT_38 = zF_EEF840BE_argCount();
    argc = zT_38;
    zT_40 = 1;
    zT_41 = (int)zT_40;
    i = zT_41;
    zT_51 = "--dump-c89";
    zT_53 = 10;
    zT_52.ptr = (unsigned char*)zT_51;
    zT_52.len = zT_53;
    s_dump_c89 = zT_52;
    zT_55 = "--help";
    zT_57 = 6;
    zT_56.ptr = (unsigned char*)zT_55;
    zT_56.len = zT_57;
    s_help = zT_56;
    zT_59 = "--max-mem";
    zT_61 = 9;
    zT_60.ptr = (unsigned char*)zT_59;
    zT_60.len = zT_61;
    s_max_mem = zT_60;
    zT_63 = "--max-errors";
    zT_65 = 12;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    s_max_errors = zT_64;
    zT_67 = "--output-dir";
    zT_69 = 12;
    zT_68.ptr = (unsigned char*)zT_67;
    zT_68.len = zT_69;
    s_output_dir = zT_68;
    zT_71 = "--quiet";
    zT_73 = 7;
    zT_72.ptr = (unsigned char*)zT_71;
    zT_72.len = zT_73;
    s_quiet = zT_72;
    zT_75 = "--debug";
    zT_77 = 7;
    zT_76.ptr = (unsigned char*)zT_75;
    zT_76.len = zT_77;
    s_debug = zT_76;
    zT_79 = "-d";
    zT_81 = 2;
    zT_80.ptr = (unsigned char*)zT_79;
    zT_80.len = zT_81;
    s_d = zT_80;
    zT_83 = "--test";
    zT_85 = 6;
    zT_84.ptr = (unsigned char*)zT_83;
    zT_84.len = zT_85;
    s_test = zT_84;
    zT_87 = "--sanity-test";
    zT_89 = 13;
    zT_88.ptr = (unsigned char*)zT_87;
    zT_88.len = zT_89;
    s_sanity_test = zT_88;
    zT_91 = "--warnings-as-errors";
    zT_93 = 20;
    zT_92.ptr = (unsigned char*)zT_91;
    zT_92.len = zT_93;
    s_warnings = zT_92;
    zT_95 = "--color";
    zT_97 = 7;
    zT_96.ptr = (unsigned char*)zT_95;
    zT_96.len = zT_97;
    s_color = zT_96;
    zT_99 = "--error-format";
    zT_101 = 14;
    zT_100.ptr = (unsigned char*)zT_99;
    zT_100.len = zT_101;
    s_error_format = zT_100;
    zT_103 = "--track-memory";
    zT_105 = 14;
    zT_104.ptr = (unsigned char*)zT_103;
    zT_104.len = zT_105;
    s_track_memory = zT_104;
    zT_107 = "--no-null-check";
    zT_109 = 15;
    zT_108.ptr = (unsigned char*)zT_107;
    zT_108.len = zT_109;
    s_no_null = zT_108;
    zT_111 = "--no-lifetime-check";
    zT_113 = 19;
    zT_112.ptr = (unsigned char*)zT_111;
    zT_112.len = zT_113;
    s_no_lifetime = zT_112;
    zT_115 = "--no-leak-check";
    zT_117 = 15;
    zT_116.ptr = (unsigned char*)zT_115;
    zT_116.len = zT_117;
    s_no_leak = zT_116;
    zT_119 = "--warn-all";
    zT_121 = 10;
    zT_120.ptr = (unsigned char*)zT_119;
    zT_120.len = zT_121;
    s_warn_all = zT_120;
    zT_123 = "--warn-error";
    zT_125 = 12;
    zT_124.ptr = (unsigned char*)zT_123;
    zT_124.len = zT_125;
    s_warn_error = zT_124;
    zT_127 = "--markers";
    zT_129 = 9;
    zT_128.ptr = (unsigned char*)zT_127;
    zT_128.len = zT_129;
    s_markers = zT_128;
    zT_131 = "-I";
    zT_133 = 2;
    zT_132.ptr = (unsigned char*)zT_131;
    zT_132.len = zT_133;
    s_include = zT_132;
    zT_135 = "--lib-dir";
    zT_137 = 9;
    zT_136.ptr = (unsigned char*)zT_135;
    zT_136.len = zT_137;
    s_lib_dir = zT_136;
    zT_155 = "-m";
    zT_157 = 2;
    zT_156.ptr = (unsigned char*)zT_155;
    zT_156.len = zT_157;
    s_m = zT_156;
    zT_159 = "-e";
    zT_161 = 2;
    zT_160.ptr = (unsigned char*)zT_159;
    zT_160.len = zT_161;
    s_e = zT_160;
    zT_163 = "-o";
    zT_165 = 2;
    zT_164.ptr = (unsigned char*)zT_163;
    zT_164.len = zT_165;
    s_o = zT_164;
    zT_167 = "-q";
    zT_169 = 2;
    zT_168.ptr = (unsigned char*)zT_167;
    zT_168.len = zT_169;
    s_q = zT_168;
    zT_171 = "-W";
    zT_173 = 2;
    zT_172.ptr = (unsigned char*)zT_171;
    zT_172.len = zT_173;
    s_W = zT_172;
    zT_175 = "-osl";
    zT_177 = 4;
    zT_176.ptr = (unsigned char*)zT_175;
    zT_176.len = zT_177;
    s_osl = zT_176;
    zT_179 = "-osw";
    zT_181 = 4;
    zT_180.ptr = (unsigned char*)zT_179;
    zT_180.len = zT_181;
    s_osw = zT_180;
    zT_183 = "9x";
    zT_185 = 2;
    zT_184.ptr = (unsigned char*)zT_183;
    zT_184.len = zT_185;
    s_profile_9x = zT_184;
    zT_187 = "nt";
    zT_189 = 2;
    zT_188.ptr = (unsigned char*)zT_187;
    zT_188.len = zT_189;
    s_profile_nt = zT_188;
    zT_191 = "--target";
    zT_193 = 8;
    zT_192.ptr = (unsigned char*)zT_191;
    zT_192.len = zT_193;
    s_target = zT_192;
    zT_195 = "-fsafe";
    zT_197 = 6;
    zT_196.ptr = (unsigned char*)zT_195;
    zT_196.len = zT_197;
    s_fsafe = zT_196;
    zT_199 = "-ffast";
    zT_201 = 6;
    zT_200.ptr = (unsigned char*)zT_199;
    zT_200.len = zT_201;
    s_ffast = zT_200;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < argc)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_204 = i;
    zT_205 = zF_70B5BFF1_argGet(zT_204);
    arg_ptr = zT_205;
    zT_207 = arg_ptr;
    zT_208 = zF_22D0470E_cstrToSlice(zT_207);
    arg = zT_208;
    zT_210 = arg.len;
    zT_211 = 0;
    if ((unsigned char)(zT_210 > (unsigned int)zT_211)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cli;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_214 = arg.ptr;
    zT_215 = 0;
    zT_216 = zT_214[zT_215];
    zT_213 = zT_216 == (unsigned char)(45);
    goto z_bb_7;
    z_bb_6:
    zT_213 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_213) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_219 = arg;
    zT_220 = s_help;
    zT_221 = zF_5FE51158_matchFlag(zT_219, zT_220);
    if (zT_221) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_475 = 1;
    zT_477 = i + (int)((int)zT_475);
    i = zT_477;
    goto z_bb_4;
    z_bb_10:
    zT_473 = arg_ptr;
    zT_474 = zF_22D0470E_cstrToSlice(zT_473);
    cli.input_file = zT_474;
    goto z_bb_9;
    z_bb_11:
    zF_9D45DFBF_printUsage();
    zF_CDED1A85_exit((unsigned char)(0));
    return cli;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_224 = arg;
    zT_225 = s_dump_c89;
    zT_226 = zF_5FE51158_matchFlag(zT_224, zT_225);
    if (zT_226) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cli.dump_c89 = (unsigned char)(1);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_228 = arg;
    zT_229 = s_max_mem;
    zT_230 = zF_5FE51158_matchFlag(zT_228, zT_229);
    if (zT_230) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_232 = arg;
    zT_233 = s_m;
    zT_234 = zF_5FE51158_matchFlag(zT_232, zT_233);
    zT_231 = zT_234;
    goto z_bb_19;
    z_bb_18:
    zT_231 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_231) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_235 = 1;
    zT_237 = i + (int)((int)zT_235);
    i = zT_237;
    if ((unsigned char)(i < argc)) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_243 = arg;
    zT_244 = zF_FBF91F7E_matchMMFlag(zT_243);
    if (zT_244) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    zT_240 = i;
    zT_241 = zF_70B5BFF1_argGet(zT_240);
    zT_239 = zT_241;
    zT_242 = zF_6CF11065_parseSize(zT_239);
    cli.max_mem = zT_242;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_246 = arg.ptr;
    zT_247 = arg.len;
    zT_248 = 3;
    zT_249 = zT_246 + zT_248;
    zT_250 = zT_247 - zT_248;
    zT_251.ptr = (unsigned char*)zT_249;
    zT_251.len = zT_250;
    zT_245 = zT_251;
    zT_252 = zF_B9231BB9_parseMMBytes(zT_245);
    cli.max_mem = zT_252;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_253 = arg;
    zT_254 = zF_C4E3C361_matchSFlag(zT_253);
    if (zT_254) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_256 = arg.ptr;
    zT_257 = arg.len;
    zT_258 = 2;
    zT_259 = zT_256 + zT_258;
    zT_260 = zT_257 - zT_258;
    zT_261.ptr = (unsigned char*)zT_259;
    zT_261.len = zT_260;
    zT_255 = zT_261;
    zT_262 = zF_153C3795_parseSLevel(zT_255);
    cli.spill_level = zT_262;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    zT_263 = arg;
    zT_264 = s_max_errors;
    zT_265 = zF_5FE51158_matchFlag(zT_263, zT_264);
    if (zT_265) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_267 = arg;
    zT_268 = s_e;
    zT_269 = zF_5FE51158_matchFlag(zT_267, zT_268);
    zT_266 = zT_269;
    goto z_bb_33;
    z_bb_32:
    zT_266 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_266) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_270 = 1;
    zT_272 = i + (int)((int)zT_270);
    i = zT_272;
    if ((unsigned char)(i < argc)) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    goto z_bb_29;
    z_bb_36:
    zT_278 = arg;
    zT_279 = s_output_dir;
    zT_280 = zF_5FE51158_matchFlag(zT_278, zT_279);
    if (zT_280) goto z_bb_40; else goto z_bb_39;
    z_bb_37:
    zT_275 = i;
    zT_276 = zF_70B5BFF1_argGet(zT_275);
    zT_274 = zT_276;
    zT_277 = zF_16BBA09E_parseU32(zT_274);
    cli.max_errors = zT_277;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_282 = arg;
    zT_283 = s_o;
    zT_284 = zF_5FE51158_matchFlag(zT_282, zT_283);
    zT_281 = zT_284;
    goto z_bb_41;
    z_bb_40:
    zT_281 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_281) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_285 = 1;
    zT_287 = i + (int)((int)zT_285);
    i = zT_287;
    if ((unsigned char)(i < argc)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_35;
    z_bb_44:
    zT_294 = arg;
    zT_295 = s_quiet;
    zT_296 = zF_5FE51158_matchFlag(zT_294, zT_295);
    if (zT_296) goto z_bb_48; else goto z_bb_47;
    z_bb_45:
    zT_290 = i;
    zT_291 = zF_70B5BFF1_argGet(zT_290);
    zT_289 = zT_291;
    zT_292 = zF_22D0470E_cstrToSlice(zT_289);
    cli.output_dir = zT_292;
    cli.output_dir_set = (unsigned char)(1);
    goto z_bb_46;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_298 = arg;
    zT_299 = s_q;
    zT_300 = zF_5FE51158_matchFlag(zT_298, zT_299);
    zT_297 = zT_300;
    goto z_bb_49;
    z_bb_48:
    zT_297 = 1;
    goto z_bb_49;
    z_bb_49:
    if (zT_297) goto z_bb_50; else goto z_bb_52;
    z_bb_50:
    cli.quiet = (unsigned char)(1);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_43;
    z_bb_52:
    zT_302 = arg;
    zT_303 = s_debug;
    zT_304 = zF_5FE51158_matchFlag(zT_302, zT_303);
    if (zT_304) goto z_bb_54; else goto z_bb_53;
    z_bb_53:
    zT_306 = arg;
    zT_307 = s_d;
    zT_308 = zF_5FE51158_matchFlag(zT_306, zT_307);
    zT_305 = zT_308;
    goto z_bb_55;
    z_bb_54:
    zT_305 = 1;
    goto z_bb_55;
    z_bb_55:
    if (zT_305) goto z_bb_56; else goto z_bb_58;
    z_bb_56:
    cli.debug = (unsigned char)(1);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_51;
    z_bb_58:
    zT_310 = arg;
    zT_311 = s_test;
    zT_312 = zF_5FE51158_matchFlag(zT_310, zT_311);
    if (zT_312) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    cli.test_mode = (unsigned char)(1);
    goto z_bb_60;
    z_bb_60:
    goto z_bb_57;
    z_bb_61:
    zT_314 = arg;
    zT_315 = s_sanity_test;
    zT_316 = zF_5FE51158_matchFlag(zT_314, zT_315);
    if (zT_316) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    cli.sanity_test_mode = (unsigned char)(1);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_318 = arg;
    zT_319 = s_warnings;
    zT_320 = zF_5FE51158_matchFlag(zT_318, zT_319);
    if (zT_320) goto z_bb_66; else goto z_bb_65;
    z_bb_65:
    zT_322 = arg;
    zT_323 = s_W;
    zT_324 = zF_5FE51158_matchFlag(zT_322, zT_323);
    zT_321 = zT_324;
    goto z_bb_67;
    z_bb_66:
    zT_321 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_321) goto z_bb_68; else goto z_bb_70;
    z_bb_68:
    cli.warnings_as_errors = (unsigned char)(1);
    goto z_bb_69;
    z_bb_69:
    goto z_bb_63;
    z_bb_70:
    zT_326 = arg;
    zT_327 = s_color;
    zT_328 = zF_5FE51158_matchFlag(zT_326, zT_327);
    if (zT_328) goto z_bb_71; else goto z_bb_73;
    z_bb_71:
    zT_329 = 1;
    zT_331 = i + (int)((int)zT_329);
    i = zT_331;
    if ((unsigned char)(i < argc)) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    goto z_bb_69;
    z_bb_73:
    zT_337 = arg;
    zT_338 = s_error_format;
    zT_339 = zF_5FE51158_matchFlag(zT_337, zT_338);
    if (zT_339) goto z_bb_76; else goto z_bb_78;
    z_bb_74:
    zT_334 = i;
    zT_335 = zF_70B5BFF1_argGet(zT_334);
    zT_333 = zT_335;
    zT_336 = zF_05AD3AFC_parseColorMode(zT_333);
    cli.color = zT_336;
    goto z_bb_75;
    z_bb_75:
    goto z_bb_72;
    z_bb_76:
    zT_340 = 1;
    zT_342 = i + (int)((int)zT_340);
    i = zT_342;
    if ((unsigned char)(i < argc)) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    goto z_bb_72;
    z_bb_78:
    zT_348 = arg;
    zT_349 = s_track_memory;
    zT_350 = zF_5FE51158_matchFlag(zT_348, zT_349);
    if (zT_350) goto z_bb_81; else goto z_bb_83;
    z_bb_79:
    zT_345 = i;
    zT_346 = zF_70B5BFF1_argGet(zT_345);
    zT_344 = zT_346;
    zT_347 = zF_A4602959_parseErrorFormat(zT_344);
    cli.error_format = zT_347;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_77;
    z_bb_81:
    cli.track_memory = (unsigned char)(1);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_77;
    z_bb_83:
    zT_352 = arg;
    zT_353 = s_no_null;
    zT_354 = zF_5FE51158_matchFlag(zT_352, zT_353);
    if (zT_354) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    cli.no_null_check = (unsigned char)(1);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_356 = arg;
    zT_357 = s_no_lifetime;
    zT_358 = zF_5FE51158_matchFlag(zT_356, zT_357);
    if (zT_358) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    cli.no_lifetime_check = (unsigned char)(1);
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_360 = arg;
    zT_361 = s_no_leak;
    zT_362 = zF_5FE51158_matchFlag(zT_360, zT_361);
    if (zT_362) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    cli.no_leak_check = (unsigned char)(1);
    goto z_bb_91;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_364 = arg;
    zT_365 = s_warn_all;
    zT_366 = zF_5FE51158_matchFlag(zT_364, zT_365);
    if (zT_366) goto z_bb_93; else goto z_bb_95;
    z_bb_93:
    cli.warn_all = (unsigned char)(1);
    goto z_bb_94;
    z_bb_94:
    goto z_bb_91;
    z_bb_95:
    zT_368 = arg;
    zT_369 = s_warn_error;
    zT_370 = zF_5FE51158_matchFlag(zT_368, zT_369);
    if (zT_370) goto z_bb_96; else goto z_bb_98;
    z_bb_96:
    cli.warnings_as_errors = (unsigned char)(1);
    cli.warn_error = (unsigned char)(1);
    goto z_bb_97;
    z_bb_97:
    goto z_bb_94;
    z_bb_98:
    zT_373 = arg;
    zT_374 = s_markers;
    zT_375 = zF_5FE51158_matchFlag(zT_373, zT_374);
    if (zT_375) goto z_bb_99; else goto z_bb_101;
    z_bb_99:
    cli.show_markers = (unsigned char)(1);
    goto z_bb_100;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_377 = arg;
    zT_378 = s_include;
    zT_379 = zF_5FE51158_matchFlag(zT_377, zT_378);
    if (zT_379) goto z_bb_103; else goto z_bb_102;
    z_bb_102:
    zT_381 = arg;
    zT_382 = s_lib_dir;
    zT_383 = zF_5FE51158_matchFlag(zT_381, zT_382);
    zT_380 = zT_383;
    goto z_bb_104;
    z_bb_103:
    zT_380 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_380) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    zT_384 = 1;
    zT_386 = i + (int)((int)zT_384);
    i = zT_386;
    if ((unsigned char)(i < argc)) goto z_bb_108; else goto z_bb_109;
    z_bb_106:
    goto z_bb_100;
    z_bb_107:
    zT_403 = arg;
    zT_404 = s_osl;
    zT_405 = zF_5FE51158_matchFlag(zT_403, zT_404);
    if (zT_405) goto z_bb_113; else goto z_bb_115;
    z_bb_108:
    zT_389 = cli.include_count;
    zT_390 = 16;
    zT_388 = zT_389 < (unsigned int)zT_390;
    goto z_bb_110;
    z_bb_109:
    zT_388 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_388) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_393 = i;
    zT_394 = zF_70B5BFF1_argGet(zT_393);
    zT_392 = zT_394;
    zT_395 = zF_22D0470E_cstrToSlice(zT_392);
    zT_396 = cli.include_dirs;
    zT_397 = cli.include_count;
    zT_398 = (unsigned int)zT_397;
    zT_396[zT_398] = zT_395;
    zT_399 = cli.include_count;
    zT_400 = 1;
    cli.include_count = (unsigned int)(zT_399 + (unsigned int)((unsigned int)zT_400));
    goto z_bb_112;
    z_bb_112:
    goto z_bb_106;
    z_bb_113:
    cli.target_is_windows = (unsigned char)(0);
    goto z_bb_114;
    z_bb_114:
    goto z_bb_106;
    z_bb_115:
    zT_407 = arg;
    zT_408 = s_osw;
    zT_409 = zF_5FE51158_matchFlag(zT_407, zT_408);
    if (zT_409) goto z_bb_116; else goto z_bb_118;
    z_bb_116:
    cli.target_is_windows = (unsigned char)(1);
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    zT_413 = 1;
    if ((unsigned char)((int)(i + zT_413) < argc)) goto z_bb_119; else goto z_bb_120;
    z_bb_117:
    goto z_bb_114;
    z_bb_118:
    zT_449 = arg;
    zT_450 = s_target;
    zT_451 = zF_5FE51158_matchFlag(zT_449, zT_450);
    if (zT_451) goto z_bb_131; else goto z_bb_133;
    z_bb_119:
    zT_419 = 1;
    zT_421 = zF_70B5BFF1_argGet((int)(i + zT_419));
    zT_417 = zT_421;
    zT_422 = zF_22D0470E_cstrToSlice(zT_417);
    nxt = zT_422;
    zT_424 = nxt.len;
    zT_425 = 0;
    if ((unsigned char)(zT_424 > (unsigned int)zT_425)) goto z_bb_121; else goto z_bb_122;
    z_bb_120:
    goto z_bb_117;
    z_bb_121:
    zT_428 = nxt.ptr;
    zT_429 = 0;
    zT_430 = zT_428[zT_429];
    zT_427 = zT_430 != (unsigned char)(45);
    goto z_bb_123;
    z_bb_122:
    zT_427 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_427) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    zT_433 = nxt;
    zT_434 = s_profile_9x;
    zT_435 = zF_5FE51158_matchFlag(zT_433, zT_434);
    if (zT_435) goto z_bb_126; else goto z_bb_128;
    z_bb_125:
    goto z_bb_120;
    z_bb_126:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    zT_438 = 1;
    zT_440 = i + (int)((int)zT_438);
    i = zT_440;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_125;
    z_bb_128:
    zT_441 = nxt;
    zT_442 = s_profile_nt;
    zT_443 = zF_5FE51158_matchFlag(zT_441, zT_442);
    if (zT_443) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_nt);
    zT_446 = 1;
    zT_448 = i + (int)((int)zT_446);
    i = zT_448;
    goto z_bb_130;
    z_bb_130:
    goto z_bb_127;
    z_bb_131:
    zT_452 = 1;
    zT_454 = i + (int)((int)zT_452);
    i = zT_454;
    if ((unsigned char)(i < argc)) goto z_bb_134; else goto z_bb_135;
    z_bb_132:
    goto z_bb_117;
    z_bb_133:
    zT_463 = arg;
    zT_464 = s_ffast;
    zT_465 = zF_5FE51158_matchFlag(zT_463, zT_464);
    if (zT_465) goto z_bb_138; else goto z_bb_140;
    z_bb_134:
    zT_457 = i;
    zT_458 = zF_70B5BFF1_argGet(zT_457);
    zT_456 = zT_458;
    zT_459 = zF_06CC17EA_parseTargetIsWindow(zT_456);
    cli.target_is_windows = zT_459;
    zT_460 = cli.target_is_windows;
    if (zT_460) goto z_bb_136; else goto z_bb_137;
    z_bb_135:
    goto z_bb_132;
    z_bb_136:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    goto z_bb_137;
    z_bb_137:
    goto z_bb_135;
    z_bb_138:
    cli.safe_checks = (unsigned char)(0);
    goto z_bb_139;
    z_bb_139:
    goto z_bb_132;
    z_bb_140:
    zT_467 = arg;
    zT_468 = s_fsafe;
    zT_469 = zF_5FE51158_matchFlag(zT_467, zT_468);
    if (zT_469) goto z_bb_141; else goto z_bb_143;
    z_bb_141:
    cli.safe_checks = (unsigned char)(1);
    goto z_bb_142;
    z_bb_142:
    goto z_bb_139;
    z_bb_143:
    zT_471 = arg_ptr;
    zT_472 = zF_22D0470E_cstrToSlice(zT_471);
    cli.input_file = zT_472;
    goto z_bb_142;
}

/* matchFlag */
unsigned char zF_5FE51158_matchFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg, zT_8F083A69_Slice_zT_0B42B2F8_u flag) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    int zT_20;
    unsigned int zT_22;
    unsigned int j;
    zT_3 = arg.len;
    zT_5 = flag.len;
    if ((unsigned char)(zT_3 != zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    j = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = arg.len;
    if ((unsigned char)(j < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = arg.ptr;
    zT_15 = zT_14[j];
    zT_16 = flag.ptr;
    zT_17 = zT_16[j];
    if ((unsigned char)(zT_15 != zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_20 = 1;
    zT_22 = j + (unsigned int)((unsigned int)zT_20);
    j = zT_22;
    goto z_bb_6;
}

/* matchMMFlag */
unsigned char zF_FBF91F7E_matchMMFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mm;
    unsigned int j;
    zT_2 = "-mm";
    zT_4 = 3;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s_mm = zT_3;
    zT_6 = arg.len;
    zT_8 = s_mm.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_mm.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_mm.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* cstrToSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D0470E_cstrToSlice(unsigned char* ptr) {
    int zT_2;
    unsigned int zT_3;
    unsigned char zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int len;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    len = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ptr[len];
    zT_5 = 0;
    if ((unsigned char)(zT_4 != zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    zT_9 = len + (unsigned int)((unsigned int)zT_7);
    len = zT_9;
    goto z_bb_4;
    z_bb_3:
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = (unsigned char*)zT_11;
    zT_13.len = zT_12;
    return zT_13;
    z_bb_4:
    goto z_bb_1;
}

/* parseSize */
unsigned int zF_6CF11065_parseSize(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    unsigned char zT_29;
    int zT_32;
    unsigned int zT_33;
    unsigned char zT_36;
    int zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned char zT_45;
    int zT_48;
    int zT_50;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_54 = 1;
    zT_56 = i + (unsigned int)((unsigned int)zT_54);
    i = zT_56;
    goto z_bb_4;
    z_bb_10:
    if ((unsigned char)(c == (unsigned char)(107))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_29 = c == (unsigned char)(75);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_32 = 1024;
    zT_33 = val * zT_32;
    val = zT_33;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    if ((unsigned char)(c == (unsigned char)(109))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_36 = c == (unsigned char)(77);
    goto z_bb_19;
    z_bb_18:
    zT_36 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_36) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_39 = 1024;
    zT_41 = 1024;
    zT_42 = (unsigned int)(val * zT_39) * zT_41;
    val = zT_42;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    if ((unsigned char)(c == (unsigned char)(103))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_45 = c == (unsigned char)(71);
    goto z_bb_25;
    z_bb_24:
    zT_45 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_45) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_48 = 1024;
    zT_50 = 1024;
    zT_52 = 1024;
    zT_53 = (unsigned int)((unsigned int)(val * zT_48) * zT_50) * zT_52;
    val = zT_53;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_21;
}

/* parseU32 */
unsigned int zF_16BBA09E_parseU32(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_4;
}

/* parseMMBytes */
unsigned int zF_B9231BB9_parseMMBytes(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned char* zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    int zT_26;
    unsigned int zT_28;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_39;
    int zT_40;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int max_mb;
    unsigned int i;
    unsigned int n;
    unsigned int mb;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_5 = (unsigned int)(unsigned int)(256);
    max_mb = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    n = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    mb = zT_14;
    goto z_bb_1;
    z_bb_1:
    zT_16 = rest.len;
    if ((unsigned char)(i < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_19 = rest.ptr;
    zT_20 = zT_19[i];
    c = zT_20;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_40 = 0;
    if ((unsigned char)(n == (unsigned int)zT_40)) goto z_bb_15; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_23 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_23 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_26 = 1;
    zT_28 = n + (unsigned int)((unsigned int)zT_26);
    n = zT_28;
    if ((unsigned char)(mb < max_mb)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = (unsigned int)(mb * (unsigned int)(10)) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    mb = zT_35;
    if ((unsigned char)(mb > max_mb)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_4;
    z_bb_12:
    mb = max_mb;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    zT_44 = rest.len;
    zT_42 = i != zT_44;
    goto z_bb_16;
    z_bb_15:
    zT_42 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_47 = "error: -mm<N> requires a decimal MB size (e.g. -mm64)\n";
    zT_49 = 54;
    zT_48.ptr = (unsigned char*)zT_47;
    zT_48.len = zT_49;
    em = zT_48;
    zT_50 = em;
    zF_E4B2EF19_stderr_write(zT_50);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_18:
    return (unsigned int)(mb * (unsigned int)(1024));
}

/* matchSFlag */
unsigned char zF_C4E3C361_matchSFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_s;
    unsigned int j;
    zT_2 = "-s";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s_s = zT_3;
    zT_6 = arg.len;
    zT_8 = s_s.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_s.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_s.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* parseSLevel */
unsigned int zF_153C3795_parseSLevel(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    int zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_32;
    unsigned int zT_36;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_43;
    int zT_44;
    unsigned char zT_46;
    unsigned int zT_48;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_58;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int i;
    unsigned int n;
    unsigned int level;
    unsigned int over;
    unsigned char c;
    unsigned int d;
    unsigned int nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    n = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    level = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    over = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_14 = rest.len;
    if ((unsigned char)(i < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = rest.ptr;
    zT_18 = zT_17[i];
    c = zT_18;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_44 = 0;
    if ((unsigned char)(n == (unsigned int)zT_44)) goto z_bb_16; else goto z_bb_15;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_21 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_21 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_21) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_24 = 1;
    zT_26 = n + (unsigned int)((unsigned int)zT_24);
    n = zT_26;
    zT_27 = 0;
    if ((unsigned char)(over == (unsigned int)zT_27)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_32;
    zT_36 = (unsigned int)(level * (unsigned int)(10)) + d;
    nl = zT_36;
    if ((unsigned char)(nl > (unsigned int)(6))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_4;
    z_bb_12:
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    over = zT_40;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    level = nl;
    goto z_bb_13;
    z_bb_15:
    zT_48 = rest.len;
    zT_46 = i != zT_48;
    goto z_bb_17;
    z_bb_16:
    zT_46 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_46) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_51 = "error: -s<N> requires a decimal level 0..6 (e.g. -s0 all on disk, -s6 all in RAM)\n";
    zT_53 = 82;
    zT_52.ptr = (unsigned char*)zT_51;
    zT_52.len = zT_53;
    em = zT_52;
    zT_54 = em;
    zF_E4B2EF19_stderr_write(zT_54);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_19:
    zT_58 = 0;
    if ((unsigned char)(over != (unsigned int)zT_58)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = "error: -s<N> spill level out of range (0..6: 0 = all on disk, 6 = all in RAM)\n";
    zT_63 = 78;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    em = zT_62;
    zT_64 = em;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_21:
    return level;
}

/* parseColorMode */
zT_CAF40AAB_ColorMode zF_05AD3AFC_parseColorMode(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_always;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_never;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "always";
    zT_7 = 6;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_always = zT_6;
    zT_9 = "never";
    zT_11 = 5;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_never = zT_10;
    zT_12 = s;
    zT_13 = s_always;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_always);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_never;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_never);
    z_bb_4:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_auto);
}

/* parseErrorFormat */
zT_A4FB690E_ErrorFormat zF_A4602959_parseErrorFormat(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_json;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sarif;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "json";
    zT_7 = 4;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_json = zT_6;
    zT_9 = "sarif";
    zT_11 = 5;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_sarif = zT_10;
    zT_12 = s;
    zT_13 = s_json;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_json);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_sarif;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_sarif);
    z_bb_4:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_human);
}

/* parseTargetIsWindows */
unsigned char zF_06CC17EA_parseTargetIsWindow(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_linux;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_windows;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "linux";
    zT_7 = 5;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_linux = zT_6;
    zT_9 = "windows";
    zT_11 = 7;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_windows = zT_10;
    zT_12 = s;
    zT_13 = s_windows;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_linux;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_21 = "error: --target must be 'linux' or 'windows'\n";
    zT_23 = 45;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    err_msg = zT_22;
    zT_24 = err_msg;
    zF_E4B2EF19_stderr_write(zT_24);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned char)(0);
}

/* writeU32 */
void zF_266B1B8E_writeU32(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_11;
    int zT_15;
    int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    unsigned char zT_23;
    int zT_24;
    int zT_26;
    unsigned int zT_28;
    int zT_29;
    int zT_30;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 16;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    v = val;
    zT_7 = 0;
    if ((unsigned char)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 48;
    zT_10 = (unsigned char)zT_9;
    zT_11 = 15;
    buf[zT_11] = zT_10;
    zT_15 = 16;
    zT_16 = 15;
    zT_17 = (unsigned char*)((unsigned char*)buf) + zT_16;
    zT_18 = zT_15 - zT_16;
    zT_19.ptr = (unsigned char*)zT_17;
    zT_19.len = zT_18;
    s = zT_19;
    zT_20 = s;
    zF_B5478454_measureMarkerWrite(zT_20);
    return;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_21 = 0;
    if ((unsigned char)(v > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_26 = 1;
    zT_28 = i - (unsigned int)((unsigned int)zT_26);
    i = zT_28;
    zT_29 = 48;
    zT_30 = 10;
    zT_35 = (unsigned char)(unsigned int)((unsigned int)(unsigned int)(zT_29 + (unsigned int)((unsigned int)(unsigned int)(v % zT_30))));
    buf[i] = zT_35;
    zT_36 = 10;
    zT_37 = v / zT_36;
    v = zT_37;
    goto z_bb_6;
    z_bb_5:
    zT_41 = 16;
    zT_42 = (unsigned char*)((unsigned char*)buf) + i;
    zT_43 = zT_41 - i;
    zT_44.ptr = (unsigned char*)zT_42;
    zT_44.len = zT_43;
    s = zT_44;
    zT_45 = s;
    zF_B5478454_measureMarkerWrite(zT_45);
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_24 = 0;
    zT_23 = i > (unsigned int)zT_24;
    goto z_bb_9;
    z_bb_8:
    zT_23 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_23) goto z_bb_4; else goto z_bb_5;
}

/* printUsage */
void zF_9D45DFBF_printUsage(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help3;
    zT_8F083A69_Slice_zT_0B42B2F8_u os_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u osw_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u tgt_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u io_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u mem_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u quiet_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u mode_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u warn_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u warn_all_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u diag_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u track_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u checks_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u markers_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u inc_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u safe_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u fast_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u dbg_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u help_help;
    zT_1 = "zig1 - Z98 self-hosted compiler - usage: zig1 [options] <input.zig>\n";
    zT_3 = 68;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_6 = "  -mm<N>    hard pool budget in MB (default 64; pool.peak over budget -> ICE rc=3)\n";
    zT_8 = 83;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    mm_help = zT_7;
    zT_9 = mm_help;
    zF_E4B2EF19_stderr_write(zT_9);
    zT_11 = "  -s<N>     spill level 0..6 (default 0 = all spills on disk; -s1..-s6 deactivate the\n";
    zT_13 = 86;
    zT_12.ptr = (unsigned char*)zT_11;
    zT_12.len = zT_13;
    s_help = zT_12;
    zT_14 = s_help;
    zF_E4B2EF19_stderr_write(zT_14);
    zT_16 = "            first N spills to RAM in order AST,LIR,HASH,RES,SIDE,EXTRA: higher -s = more RAM,\n";
    zT_18 = 94;
    zT_17.ptr = (unsigned char*)zT_16;
    zT_17.len = zT_18;
    s_help2 = zT_17;
    zT_19 = s_help2;
    zF_E4B2EF19_stderr_write(zT_19);
    zT_21 = "            less disk I/O (pool= rises; -s6 = all in RAM -> pair with -mm128)\n";
    zT_23 = 78;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    s_help3 = zT_22;
    zT_24 = s_help3;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_26 = "  -osl      compile target = linux (default)\n";
    zT_28 = 45;
    zT_27.ptr = (unsigned char*)zT_26;
    zT_27.len = zT_28;
    os_help = zT_27;
    zT_29 = os_help;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_31 = "  -osw [9x|nt]  compile target = windows (default 9x = Win9x; nt = NT/XP profile)\n";
    zT_33 = 82;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    osw_help = zT_32;
    zT_34 = osw_help;
    zF_E4B2EF19_stderr_write(zT_34);
    zT_36 = "  --target <linux|windows>  long-form target alias for -osl/-osw (windows = 9x default)\n";
    zT_38 = 88;
    zT_37.ptr = (unsigned char*)zT_36;
    zT_37.len = zT_38;
    tgt_help = zT_37;
    zT_39 = tgt_help;
    zF_E4B2EF19_stderr_write(zT_39);
    zT_41 = "  -o, --output-dir <dir>    output directory (default .)\n";
    zT_43 = 57;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    io_help = zT_42;
    zT_44 = io_help;
    zF_E4B2EF19_stderr_write(zT_44);
    zT_46 = "  -m, --max-mem <size>      hard pool budget with k/m/g suffix (same as -mm<N>)\n";
    zT_48 = 80;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    mem_help = zT_47;
    zT_49 = mem_help;
    zF_E4B2EF19_stderr_write(zT_49);
    zT_51 = "  -e, --max-errors <n>      max diagnostics (default 256)\n";
    zT_53 = 58;
    zT_52.ptr = (unsigned char*)zT_51;
    zT_52.len = zT_53;
    err_help = zT_52;
    zT_54 = err_help;
    zF_E4B2EF19_stderr_write(zT_54);
    zT_56 = "  -q, --quiet               suppress non-error output\n";
    zT_58 = 54;
    zT_57.ptr = (unsigned char*)zT_56;
    zT_57.len = zT_58;
    quiet_help = zT_57;
    zT_59 = quiet_help;
    zF_E4B2EF19_stderr_write(zT_59);
    zT_61 = "  --test                    run test blocks\n  --sanity-test             lexer sanity test\n";
    zT_63 = 90;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    mode_help = zT_62;
    zT_64 = mode_help;
    zF_E4B2EF19_stderr_write(zT_64);
    zT_66 = "  -W, --warnings-as-errors  treat warnings as errors; --warn-error also sets warn_error\n";
    zT_68 = 88;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    warn_help = zT_67;
    zT_69 = warn_help;
    zF_E4B2EF19_stderr_write(zT_69);
    zT_71 = "  --warn-all                enable all warnings\n";
    zT_73 = 48;
    zT_72.ptr = (unsigned char*)zT_71;
    zT_72.len = zT_73;
    warn_all_help = zT_72;
    zT_74 = warn_all_help;
    zF_E4B2EF19_stderr_write(zT_74);
    zT_76 = "  --color <auto|always|never>  diagnostic color mode (default auto)\n";
    zT_78 = 68;
    zT_77.ptr = (unsigned char*)zT_76;
    zT_77.len = zT_78;
    diag_help = zT_77;
    zT_79 = diag_help;
    zF_E4B2EF19_stderr_write(zT_79);
    zT_81 = "  --error-format <human|json|sarif>  diagnostic format (default human)\n";
    zT_83 = 71;
    zT_82.ptr = (unsigned char*)zT_81;
    zT_82.len = zT_83;
    fmt_help = zT_82;
    zT_84 = fmt_help;
    zF_E4B2EF19_stderr_write(zT_84);
    zT_86 = "  --track-memory            report peak memory\n";
    zT_88 = 47;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    track_help = zT_87;
    zT_89 = track_help;
    zF_E4B2EF19_stderr_write(zT_89);
    zT_91 = "  --no-null-check | --no-lifetime-check | --no-leak-check  disable those checks\n";
    zT_93 = 80;
    zT_92.ptr = (unsigned char*)zT_91;
    zT_92.len = zT_93;
    checks_help = zT_92;
    zT_94 = checks_help;
    zF_E4B2EF19_stderr_write(zT_94);
    zT_96 = "  --markers                 emit phase markers\n";
    zT_98 = 47;
    zT_97.ptr = (unsigned char*)zT_96;
    zT_97.len = zT_98;
    markers_help = zT_97;
    zT_99 = markers_help;
    zF_E4B2EF19_stderr_write(zT_99);
    zT_101 = "  -I <dir>, --lib-dir <dir> add an include/library directory (max 16)\n";
    zT_103 = 70;
    zT_102.ptr = (unsigned char*)zT_101;
    zT_102.len = zT_103;
    inc_help = zT_102;
    zT_104 = inc_help;
    zF_E4B2EF19_stderr_write(zT_104);
    zT_106 = "  -fsafe                    enable runtime checks + undefined poison (default)\n";
    zT_108 = 79;
    zT_107.ptr = (unsigned char*)zT_106;
    zT_107.len = zT_108;
    safe_help = zT_107;
    zT_109 = safe_help;
    zF_E4B2EF19_stderr_write(zT_109);
    zT_111 = "  -ffast                    disable runtime checks + undefined poison\n";
    zT_113 = 70;
    zT_112.ptr = (unsigned char*)zT_111;
    zT_112.len = zT_113;
    fast_help = zT_112;
    zT_114 = fast_help;
    zF_E4B2EF19_stderr_write(zT_114);
    zT_116 = "  --dump-c89                emit C89 into the output directory\n";
    zT_118 = 63;
    zT_117.ptr = (unsigned char*)zT_116;
    zT_117.len = zT_118;
    c89_help = zT_117;
    zT_119 = c89_help;
    zF_E4B2EF19_stderr_write(zT_119);
    zT_121 = "  -d, --debug               emit <stem>.z98dbg.{syms,lines,cnames} (requires --output-dir)\n";
    zT_123 = 91;
    zT_122.ptr = (unsigned char*)zT_121;
    zT_122.len = zT_123;
    dbg_help = zT_122;
    zT_124 = dbg_help;
    zF_E4B2EF19_stderr_write(zT_124);
    zT_126 = "  --help                    show this help\n";
    zT_128 = 43;
    zT_127.ptr = (unsigned char*)zT_126;
    zT_127.len = zT_128;
    help_help = zT_127;
    zT_129 = help_help;
    zF_E4B2EF19_stderr_write(zT_129);
    return;
}

/* __module_init */
void zF_780653D2___module_init(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_69057089_CompilerAlloc zT_1 = {0};
    zT_D3EB6303_StringInterner zT_2 = {0};
    zT_227EDE07_SourceManager zT_3 = {0};
    zT_F85C5DED_DiagnosticCollector zT_4 = {0};
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6 = 0;
    zT_072B53A6_ModuleRegistry zT_7 = {0};
    zT_338B7C76_TypeRegistry zT_8 = {0};
    zT_6B356268_SemanticContext zT_9 = {0};
    zT_02EB57B2_LirLowerer zT_10 = {0};
    zT_CA01C129_LirSlotArrayList zT_11 = {0};
    zT_8EED1867_ResolvedTypeTable zT_12 = {0};
    zT_66E7D2EF_CoercionTable zT_13 = {0};
    zT_3D7259E2_SymbolRegistry zT_14 = {0};
    zT_8143F551_AstKind zT_15 = 0;
    zT_6B0A7D14_AstStore zT_16 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_69057089_CompilerAlloc = zT_1;
    zG_D3EB6303_StringInterner = zT_2;
    zG_227EDE07_SourceManager = zT_3;
    zG_F85C5DED_DiagnosticCollector = zT_4;
    zG_3A355BD2_Token = zT_5;
    zG_EAC3E484_TokenKind = zT_6;
    zG_072B53A6_ModuleRegistry = zT_7;
    zG_338B7C76_TypeRegistry = zT_8;
    zG_6B356268_SemanticContext = zT_9;
    zG_02EB57B2_LirLowerer = zT_10;
    zG_CA01C129_LirSlotArrayList = zT_11;
    zG_8EED1867_ResolvedTypeTable = zT_12;
    zG_66E7D2EF_CoercionTable = zT_13;
    zG_3D7259E2_SymbolRegistry = zT_14;
    zG_8143F551_AstKind = zT_15;
    zG_6B0A7D14_AstStore = zT_16;
    return;
}

/* EOF */
