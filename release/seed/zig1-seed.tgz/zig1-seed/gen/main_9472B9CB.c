#include "main_9472B9CB.h"
/* main */
void zF_EA90E208_main(int argc, unsigned char** argv) {
    int zT_2;
    unsigned char** zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_C98AF326_CompilerCli zT_10 = {0};
    unsigned char zT_11;
    unsigned char zT_14;
    zT_69057089_CompilerAlloc zT_16 = {0};
    zT_3E40CD83_Sand* zT_18;
    zT_69057089_CompilerAlloc* zT_20;
    int zT_22;
    zT_D3EB6303_StringInterner zT_24 = {0};
    zT_3E40CD83_Sand* zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_227EDE07_SourceManager zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_227EDE07_SourceManager* zT_32;
    zT_D3EB6303_StringInterner* zT_33;
    zT_69057089_CompilerAlloc* zT_34;
    zT_3E40CD83_Sand* zT_39;
    zT_69057089_CompilerAlloc* zT_40;
    unsigned char zT_42;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_53;
    int zT_54;
    unsigned char zT_56;
    unsigned char zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char zT_60 = 0;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_69057089_CompilerAlloc zT_77 = {0};
    unsigned int zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_3E40CD83_Sand* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    zT_69057089_CompilerAlloc* zT_85;
    zT_87DA5B32_Opt_474 zT_87 = {0};
    unsigned char zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_101;
    unsigned int zT_104;
    unsigned int zT_108;
    unsigned int zT_111;
    unsigned int zT_114;
    unsigned int zT_117;
    unsigned int zT_120;
    unsigned int zT_123;
    unsigned int zT_126;
    unsigned int zT_129;
    unsigned int zT_132;
    unsigned int zT_135;
    unsigned int zT_138;
    zT_3E40CD83_Sand* zT_140;
    unsigned int zT_141;
    zT_69057089_CompilerAlloc* zT_142;
    zT_D3EB6303_StringInterner zT_144 = {0};
    zT_3E40CD83_Sand* zT_146;
    zT_69057089_CompilerAlloc* zT_147;
    zT_227EDE07_SourceManager zT_149 = {0};
    zT_3E40CD83_Sand* zT_151;
    zT_227EDE07_SourceManager* zT_152;
    zT_D3EB6303_StringInterner* zT_153;
    zT_69057089_CompilerAlloc* zT_154;
    zT_F85C5DED_DiagnosticCollector zT_158 = {0};
    unsigned int zT_159;
    zT_3E40CD83_Sand* zT_161;
    zT_69057089_CompilerAlloc* zT_162;
    zT_3E40CD83_Sand* zT_165;
    zT_D3EB6303_StringInterner* zT_166;
    zT_F85C5DED_DiagnosticCollector* zT_167;
    zT_69057089_CompilerAlloc* zT_168;
    zT_072B53A6_ModuleRegistry zT_172 = {0};
    zT_072B53A6_ModuleRegistry* zT_173;
    zT_227EDE07_SourceManager* zT_174;
    zT_072B53A6_ModuleRegistry* zT_177;
    unsigned char zT_178;
    zT_7D82FE60_GrowableSand zT_182 = {0};
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_7D82FE60_GrowableSand* zT_187;
    zT_3E40CD83_Sand* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190;
    zT_3E40CD83_Sand* zT_192 = 0;
    int zT_193;
    zT_3E40CD83_Sand* zT_196;
    zT_D3EB6303_StringInterner* zT_197;
    unsigned int zT_198;
    unsigned int zT_199;
    zT_7D82FE60_GrowableSand* zT_200;
    zT_338B7C76_TypeRegistry zT_203 = {0};
    zT_338B7C76_TypeRegistry* zT_204;
    zT_3E40CD83_Sand* zT_207;
    zT_69057089_CompilerAlloc* zT_208;
    zT_6B0A7D14_AstStore zT_210 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_212;
    unsigned int zT_214;
    unsigned char zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned int zT_219;
    unsigned int zT_221;
    unsigned char zT_223;
    unsigned char* zT_226;
    unsigned char zT_227;
    unsigned int zT_229;
    unsigned int zT_231;
    unsigned char zT_232;
    unsigned int zT_234;
    unsigned char zT_235;
    unsigned int zT_237;
    unsigned char zT_238;
    unsigned int zT_240;
    unsigned char* zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_244;
    unsigned int zT_246;
    unsigned int zT_248;
    unsigned char zT_250;
    unsigned char* zT_253;
    unsigned char zT_254;
    unsigned int zT_256;
    unsigned int zT_258;
    zT_6B0A7D14_AstStore* zT_259;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_260;
    int zT_264;
    unsigned char* zT_265;
    unsigned int zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    zT_846744CC_Arr_unsigned_char_5 zT_269;
    unsigned int zT_271;
    unsigned char zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_276;
    unsigned int zT_278;
    unsigned char zT_280;
    unsigned char* zT_283;
    unsigned char zT_284;
    unsigned int zT_286;
    unsigned int zT_288;
    unsigned char zT_289;
    unsigned int zT_291;
    unsigned char zT_292;
    unsigned int zT_294;
    unsigned char zT_295;
    unsigned int zT_297;
    unsigned char* zT_299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_300;
    unsigned int zT_301;
    unsigned int zT_303;
    unsigned int zT_305;
    unsigned char zT_307;
    unsigned char* zT_310;
    unsigned char zT_311;
    unsigned int zT_313;
    unsigned int zT_315;
    zT_6B0A7D14_AstStore* zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_318;
    int zT_323;
    unsigned char* zT_324;
    unsigned int zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    zT_846744CC_Arr_unsigned_char_5 zT_328;
    unsigned int zT_330;
    unsigned char zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_335;
    unsigned int zT_337;
    unsigned char zT_339;
    unsigned char* zT_342;
    unsigned char zT_343;
    unsigned int zT_345;
    unsigned int zT_347;
    unsigned char zT_348;
    unsigned int zT_350;
    unsigned char zT_351;
    unsigned int zT_353;
    unsigned char zT_354;
    unsigned int zT_356;
    unsigned char* zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    unsigned int zT_360;
    unsigned int zT_362;
    unsigned int zT_364;
    unsigned char zT_366;
    unsigned char* zT_369;
    unsigned char zT_370;
    unsigned int zT_372;
    unsigned int zT_374;
    zT_6B0A7D14_AstStore* zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_377;
    int zT_382;
    unsigned char* zT_383;
    unsigned int zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    zT_846744CC_Arr_unsigned_char_5 zT_387;
    unsigned int zT_389;
    unsigned char zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_392;
    unsigned int zT_394;
    unsigned int zT_396;
    unsigned char zT_398;
    unsigned char* zT_401;
    unsigned char zT_402;
    unsigned int zT_404;
    unsigned int zT_406;
    unsigned char zT_407;
    unsigned int zT_409;
    unsigned char zT_410;
    unsigned int zT_412;
    unsigned char zT_413;
    unsigned int zT_415;
    unsigned char* zT_417;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_418;
    unsigned int zT_419;
    unsigned int zT_421;
    unsigned int zT_423;
    unsigned char zT_425;
    unsigned char* zT_428;
    unsigned char zT_429;
    unsigned int zT_431;
    unsigned int zT_433;
    zT_6B0A7D14_AstStore* zT_434;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_436;
    int zT_441;
    unsigned char* zT_442;
    unsigned int zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_444;
    zT_846744CC_Arr_unsigned_char_5 zT_446;
    unsigned int zT_448;
    unsigned char zT_449;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    unsigned int zT_453;
    unsigned int zT_455;
    unsigned char zT_457;
    unsigned char* zT_460;
    unsigned char zT_461;
    unsigned int zT_463;
    unsigned int zT_465;
    unsigned char zT_466;
    unsigned int zT_468;
    unsigned char zT_469;
    unsigned int zT_471;
    unsigned char zT_472;
    unsigned int zT_474;
    unsigned char* zT_476;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_477;
    unsigned int zT_478;
    unsigned int zT_480;
    unsigned int zT_482;
    unsigned char zT_484;
    unsigned char* zT_487;
    unsigned char zT_488;
    unsigned int zT_490;
    unsigned int zT_492;
    zT_6B0A7D14_AstStore* zT_493;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_495;
    int zT_500;
    unsigned char* zT_501;
    unsigned int zT_502;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_503;
    zT_3E40CD83_Sand* zT_505;
    zT_69057089_CompilerAlloc* zT_506;
    zT_3D7259E2_SymbolRegistry zT_508 = {0};
    zT_3E40CD83_Sand* zT_510;
    zT_69057089_CompilerAlloc* zT_511;
    zT_8EED1867_ResolvedTypeTable zT_513 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_515;
    unsigned int zT_517;
    unsigned char zT_518;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_520;
    unsigned int zT_522;
    unsigned int zT_524;
    unsigned char zT_526;
    unsigned char* zT_529;
    unsigned char zT_530;
    unsigned int zT_532;
    unsigned int zT_534;
    unsigned char zT_535;
    unsigned int zT_537;
    unsigned char zT_538;
    unsigned int zT_540;
    unsigned char zT_541;
    unsigned int zT_543;
    unsigned char* zT_545;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_546;
    unsigned int zT_547;
    unsigned int zT_549;
    unsigned int zT_551;
    unsigned char zT_553;
    unsigned char* zT_556;
    unsigned char zT_557;
    unsigned int zT_559;
    unsigned int zT_561;
    zT_8EED1867_ResolvedTypeTable* zT_562;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_563;
    int zT_567;
    unsigned char* zT_568;
    unsigned int zT_569;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_570;
    zT_3E40CD83_Sand* zT_572;
    zT_69057089_CompilerAlloc* zT_573;
    zT_66E7D2EF_CoercionTable zT_575 = {0};
    zT_3E40CD83_Sand* zT_577;
    zT_69057089_CompilerAlloc* zT_578;
    zT_CA01C129_LirSlotArrayList zT_580 = {0};
    zT_3E40CD83_Sand* zT_582;
    zT_69057089_CompilerAlloc* zT_583;
    zT_4D61441E_DepGraph zT_585 = {0};
    zT_3E40CD83_Sand* zT_587;
    zT_69057089_CompilerAlloc* zT_588;
    zT_21D3708C_U32ToU32Map zT_590 = {0};
    zT_3E40CD83_Sand* zT_592;
    zT_69057089_CompilerAlloc* zT_593;
    zT_21D3708C_U32ToU32Map zT_595 = {0};
    zT_3E40CD83_Sand* zT_597;
    zT_69057089_CompilerAlloc* zT_598;
    zT_21D3708C_U32ToU32Map zT_600 = {0};
    zT_3E40CD83_Sand* zT_602;
    zT_69057089_CompilerAlloc* zT_603;
    zT_21D3708C_U32ToU32Map zT_605 = {0};
    zT_3E40CD83_Sand* zT_607;
    zT_69057089_CompilerAlloc* zT_608;
    zT_21D3708C_U32ToU32Map zT_610 = {0};
    zT_3E40CD83_Sand* zT_612;
    zT_69057089_CompilerAlloc* zT_614;
    zT_77F6F59C_ComptimeFoldTable zT_617 = {0};
    zT_3E40CD83_Sand* zT_619;
    zT_69057089_CompilerAlloc* zT_620;
    zT_4065182A_ConstInitTable zT_622 = {0};
    zT_786E6CF2_EmissionClassificat zT_624;
    zT_3E40CD83_Sand* zT_625;
    zT_69057089_CompilerAlloc* zT_626;
    zT_21D3708C_U32ToU32Map zT_628 = {0};
    zT_3E40CD83_Sand* zT_629;
    zT_69057089_CompilerAlloc* zT_630;
    zT_21D3708C_U32ToU32Map zT_632 = {0};
    zT_3E40CD83_Sand* zT_633;
    zT_69057089_CompilerAlloc* zT_634;
    zT_21D3708C_U32ToU32Map zT_636 = {0};
    zT_3E40CD83_Sand* zT_637;
    zT_69057089_CompilerAlloc* zT_638;
    zT_21D3708C_U32ToU32Map zT_640 = {0};
    zT_1317DCD6_C89SpellPlan zT_642 = {0};
    zT_3E40CD83_Sand* zT_644;
    zT_69057089_CompilerAlloc* zT_645;
    zT_A4CE86B7_U64ToU32Map zT_647 = {0};
    zT_3E40CD83_Sand* zT_649;
    zT_69057089_CompilerAlloc* zT_650;
    zT_A4CE86B7_U64ToU32Map zT_652 = {0};
    zT_3E40CD83_Sand* zT_654;
    zT_69057089_CompilerAlloc* zT_655;
    zT_A4CE86B7_U64ToU32Map zT_657 = {0};
    zT_3E40CD83_Sand* zT_659;
    zT_69057089_CompilerAlloc* zT_660;
    zT_A4CE86B7_U64ToU32Map zT_662 = {0};
    zT_3E40CD83_Sand* zT_664;
    zT_69057089_CompilerAlloc* zT_665;
    zT_A4CE86B7_U64ToU32Map zT_667 = {0};
    zT_3E40CD83_Sand* zT_669;
    zT_69057089_CompilerAlloc* zT_670;
    zT_A4CE86B7_U64ToU32Map zT_672 = {0};
    zT_3E40CD83_Sand* zT_674;
    zT_69057089_CompilerAlloc* zT_675;
    zT_A4CE86B7_U64ToU32Map zT_677 = {0};
    zT_3E40CD83_Sand* zT_679;
    zT_69057089_CompilerAlloc* zT_680;
    zT_B687BB96_U32ArrayList zT_682 = {0};
    zT_3E40CD83_Sand* zT_684;
    zT_69057089_CompilerAlloc* zT_685;
    zT_A4CE86B7_U64ToU32Map zT_687 = {0};
    zT_3E40CD83_Sand* zT_689;
    zT_69057089_CompilerAlloc* zT_690;
    zT_A4CE86B7_U64ToU32Map zT_692 = {0};
    zT_3E40CD83_Sand* zT_694;
    zT_69057089_CompilerAlloc* zT_695;
    zT_A4CE86B7_U64ToU32Map zT_697 = {0};
    zT_5AB29387_CompilerContext zT_699;
    zT_69057089_CompilerAlloc* zT_700;
    zT_D3EB6303_StringInterner* zT_701;
    zT_F85C5DED_DiagnosticCollector* zT_702;
    zT_227EDE07_SourceManager* zT_703;
    zT_072B53A6_ModuleRegistry* zT_704;
    zT_338B7C76_TypeRegistry* zT_705;
    zT_6B0A7D14_AstStore* zT_706;
    zT_3D7259E2_SymbolRegistry* zT_707;
    zT_8EED1867_ResolvedTypeTable* zT_708;
    zT_66E7D2EF_CoercionTable* zT_709;
    zT_4D61441E_DepGraph* zT_710;
    zT_7E7544E4_LirStream zT_711 = {0};
    zT_3E40CD83_Sand* zT_712;
    zT_69057089_CompilerAlloc* zT_713;
    zT_E1A783EF_GlobalDeclArrayList zT_715 = {0};
    zT_3E40CD83_Sand* zT_716;
    zT_69057089_CompilerAlloc* zT_717;
    zT_A4CE86B7_U64ToU32Map zT_719 = {0};
    zT_3E40CD83_Sand* zT_720;
    zT_69057089_CompilerAlloc* zT_721;
    zT_B687BB96_U32ArrayList zT_723 = {0};
    zT_5AB29387_CompilerContext* zT_724;
    zT_8F083A69_Slice_zT_0B42B2F8_u startmsg;
    zT_C98AF326_CompilerCli cli;
    zT_69057089_CompilerAlloc compiler_alloc;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u source;
    unsigned int interner_bc;
    unsigned int type_hint;
    unsigned int name_hint;
    unsigned int fold_hint;
    zT_072B53A6_ModuleRegistry mr;
    zT_7D82FE60_GrowableSand type_db_arena;
    zT_8F083A69_Slice_zT_0B42B2F8_u type_db_name;
    zT_338B7C76_TypeRegistry typereg;
    zT_6B0A7D14_AstStore store;
    zT_846744CC_Arr_unsigned_char_5 ast_spill_path;
    unsigned int asp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od2;
    unsigned int oi2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ast_tmp_name;
    unsigned int ati;
    zT_846744CC_Arr_unsigned_char_5 id_spill_path;
    unsigned int idp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od3;
    unsigned int oi3;
    zT_8F083A69_Slice_zT_0B42B2F8_u id_tmp_name;
    unsigned int iti;
    zT_846744CC_Arr_unsigned_char_5 iv_spill_path;
    unsigned int ivp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od5;
    unsigned int oi5;
    zT_8F083A69_Slice_zT_0B42B2F8_u iv_tmp_name;
    unsigned int ivi;
    zT_846744CC_Arr_unsigned_char_5 ec_spill_path;
    unsigned int ecp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od6;
    unsigned int oi6;
    zT_8F083A69_Slice_zT_0B42B2F8_u ec_tmp_name;
    unsigned int eci;
    zT_846744CC_Arr_unsigned_char_5 er_spill_path;
    unsigned int erp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od7;
    unsigned int oi7;
    zT_8F083A69_Slice_zT_0B42B2F8_u er_tmp_name;
    unsigned int eri;
    zT_3D7259E2_SymbolRegistry symbol_reg;
    zT_8EED1867_ResolvedTypeTable resolved_types;
    zT_846744CC_Arr_unsigned_char_5 rtt_spill_path;
    unsigned int rsp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od4;
    unsigned int oi4;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtt_tmp_name;
    unsigned int rti2;
    zT_66E7D2EF_CoercionTable coercion_table;
    zT_CA01C129_LirSlotArrayList lir_slots;
    zT_4D61441E_DepGraph dep_graph;
    zT_21D3708C_U32ToU32Map enum_value_table;
    zT_21D3708C_U32ToU32Map tuple_index_table;
    zT_21D3708C_U32ToU32Map error_code_registry;
    zT_21D3708C_U32ToU32Map call_arg_types;
    zT_21D3708C_U32ToU32Map call_param_map;
    zT_77F6F59C_ComptimeFoldTable comptime_folds;
    zT_4065182A_ConstInitTable const_inits;
    zT_786E6CF2_EmissionClassificat emission_classif;
    zT_1317DCD6_C89SpellPlan spell_plan_ph;
    zT_A4CE86B7_U64ToU32Map exported;
    zT_A4CE86B7_U64ToU32Map suspending_fns;
    zT_A4CE86B7_U64ToU32Map frame_sizes;
    zT_A4CE86B7_U64ToU32Map state_widths;
    zT_A4CE86B7_U64ToU32Map awaited_fns;
    zT_A4CE86B7_U64ToU32Map async_hidden_fns;
    zT_A4CE86B7_U64ToU32Map driver_targets;
    zT_B687BB96_U32ArrayList parent_result_type_list;
    zT_A4CE86B7_U64ToU32Map parent_result_start;
    zT_A4CE86B7_U64ToU32Map parent_result_count;
    zT_A4CE86B7_U64ToU32Map async_layouts;
    zT_5AB29387_CompilerContext ctx;
    zT_2 = argc;
    zT_3 = argv;
    zF_4DE8E0A6_initArgs(zT_2, zT_3);
    zT_5 = "START\n";
    zT_7 = 6;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    startmsg = zT_6;
    zT_8 = startmsg;
    zF_48AC7B3A_markerWrite(zT_8);
    zT_10 = zF_6143A521_parseArgs();
    cli = zT_10;
    zT_11 = cli.show_markers;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zF_3C88665D_markersEnabled((unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    zT_14 = cli.sanity_test_mode;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_16;
    zT_20 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_18 = &zT_20->permanent;
    zT_22 = 4;
    zT_24 = zF_FB2E811D_stringInternerInit(zT_18, (unsigned int)((unsigned int)zT_22));
    interner = zT_24;
    zT_27 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_26 = &zT_27->permanent;
    zT_29 = zF_01351F51_sourceManagerInit(zT_26);
    source_man = zT_29;
    zT_34 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_31 = &zT_34->permanent;
    zT_32 = (zT_227EDE07_SourceManager*)&source_man;
    zT_33 = (zT_D3EB6303_StringInterner*)&interner;
    (void)zF_C7BA7DAB_diagnosticCollector(zT_31, zT_32, zT_33);
    zT_40 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_39 = &zT_40->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_39);
    zF_519E4401_lexerTestSanityChec();
    return;
    z_bb_4:
    zT_42 = cli.test_mode;
    if (zT_42) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_44 = "error: use test_main.zig for test mode\n";
    zT_46 = 39;
    zT_45.ptr = (unsigned char*)zT_44;
    zT_45.len = zT_46;
    msg = zT_45;
    zT_47 = msg;
    zF_48AC7B3A_markerWrite(zT_47);
    zT_49 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_49));
    return;
    z_bb_6:
    zT_51 = cli.input_file;
    zT_53 = zT_51.len;
    zT_54 = 0;
    if ((unsigned char)(zT_53 == (unsigned int)zT_54)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zF_9D45DFBF_printUsage();
    return;
    z_bb_8:
    zT_56 = cli.output_dir_set;
    if (zT_56) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_59 = cli.output_dir;
    zT_58 = zT_59;
    zT_60 = zF_8CC05F84_dirExists(zT_58);
    zT_57 = !zT_60;
    goto z_bb_11;
    z_bb_10:
    zT_57 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_57) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63 = "error: output directory does not exist: ";
    zT_65 = 40;
    zT_64.ptr = (unsigned char*)zT_63;
    zT_64.len = zT_65;
    msg = zT_64;
    zT_66 = msg;
    zF_E4B2EF19_stderr_write(zT_66);
    zT_68 = cli.output_dir;
    zT_67 = zT_68;
    zF_E4B2EF19_stderr_write(zT_67);
    zT_70 = "\n";
    zT_72 = 1;
    zT_71.ptr = (unsigned char*)zT_70;
    zT_71.len = zT_72;
    nl = zT_71;
    zT_73 = nl;
    zF_E4B2EF19_stderr_write(zT_73);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_13:
    zT_77 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_77;
    zT_78 = cli.max_mem;
    compiler_alloc.max_mem = zT_78;
    zT_79 = cli.spill_level;
    zF_4EDF4E7B_spillSetLevel(zT_79);
    zT_84 = cli.input_file;
    zT_82 = zT_84;
    zT_85 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_83 = &zT_85->scratch;
    zT_87 = zF_5B859C63_readFile(zT_82, zT_83);
    zT_88 = zT_87.has_value;
    if (zT_88) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_92 = "error: could not read input file\n";
    zT_94 = 33;
    zT_93.ptr = (unsigned char*)zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = msg;
    zF_E4B2EF19_stderr_write(zT_95);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_15:
    zT_98 = zT_87.value;
    zT_89 = zT_98;
    goto z_bb_16;
    z_bb_16:
    source = zT_89;
    zT_101 = source.len;
    zT_104 = source.len;
    zT_108 = (unsigned int)((unsigned int)zT_101) + (unsigned int)((unsigned int)(unsigned int)(zT_104 / (unsigned int)(4)));
    interner_bc = zT_108;
    if ((unsigned char)(interner_bc < (unsigned int)(4096))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_111 = 4096;
    interner_bc = zT_111;
    goto z_bb_18;
    z_bb_18:
    zT_114 = source.len;
    zT_117 = (unsigned int)(unsigned int)(zT_114 / (unsigned int)(32));
    type_hint = zT_117;
    if ((unsigned char)(type_hint < (unsigned int)(4096))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_120 = 4096;
    type_hint = zT_120;
    goto z_bb_20;
    z_bb_20:
    zT_123 = source.len;
    zT_126 = (unsigned int)(unsigned int)(zT_123 / (unsigned int)(10));
    name_hint = zT_126;
    if ((unsigned char)(name_hint < (unsigned int)(2048))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_129 = 2048;
    name_hint = zT_129;
    goto z_bb_22;
    z_bb_22:
    zT_132 = source.len;
    zT_135 = (unsigned int)(unsigned int)(zT_132 / (unsigned int)(9));
    fold_hint = zT_135;
    if ((unsigned char)(fold_hint < (unsigned int)(16))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_138 = 16;
    fold_hint = zT_138;
    goto z_bb_24;
    z_bb_24:
    zT_142 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_140 = &zT_142->permanent;
    zT_141 = interner_bc;
    zT_144 = zF_FB2E811D_stringInternerInit(zT_140, zT_141);
    interner = zT_144;
    zT_147 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_146 = &zT_147->permanent;
    zT_149 = zF_01351F51_sourceManagerInit(zT_146);
    source_man = zT_149;
    zT_154 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_151 = &zT_154->permanent;
    zT_152 = (zT_227EDE07_SourceManager*)&source_man;
    zT_153 = (zT_D3EB6303_StringInterner*)&interner;
    zT_158 = zF_C7BA7DAB_diagnosticCollector(zT_151, zT_152, zT_153);
    diag = zT_158;
    zT_159 = cli.max_errors;
    diag.max_diagnostics = (unsigned int)((unsigned int)zT_159);
    zT_162 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_161 = &zT_162->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_161);
    zT_168 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_165 = &zT_168->permanent;
    zT_166 = (zT_D3EB6303_StringInterner*)&interner;
    zT_167 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_172 = zF_896FAF3C_moduleRegistryInit(zT_165, zT_166, zT_167);
    mr = zT_172;
    zT_173 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_174 = (zT_227EDE07_SourceManager*)&source_man;
    zF_BD2BF0BD_moduleRegistrySetSo(zT_173, zT_174);
    zT_177 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_178 = cli.target_is_windows;
    zF_849BBF28_moduleRegistrySetTa(zT_177, zT_178);
    type_db_arena = zT_182;
    zT_184 = "type_db";
    zT_186 = 7;
    zT_185.ptr = (unsigned char*)zT_184;
    zT_185.len = zT_186;
    type_db_name = zT_185;
    zT_187 = (zT_7D82FE60_GrowableSand*)&type_db_arena;
    zT_192 = zF_8C23960F_poolPtr();
    zT_188 = zT_192;
    zT_193 = 4096;
    zT_190 = type_db_name;
    zF_07B11742_growableSandInit(zT_187, zT_188, (unsigned int)((unsigned int)zT_193), zT_190);
    zT_200 = (zT_7D82FE60_GrowableSand*)&type_db_arena;
    zT_196 = &zT_200->view;
    zT_197 = (zT_D3EB6303_StringInterner*)&interner;
    zT_198 = type_hint;
    zT_199 = name_hint;
    zT_203 = zF_28AE6613_typeRegistryInitSiz(zT_196, zT_197, zT_198, zT_199);
    typereg = zT_203;
    zT_204 = (zT_338B7C76_TypeRegistry*)&typereg;
    zF_541737A5_typeRegistryRegiste(zT_204);
    zT_208 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_207 = &zT_208->module;
    zT_210 = zF_D9F91436_astStoreInit(zT_207);
    store = zT_210;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_212[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ast_spill_path[_i] = zT_212[_i];
        _i++;
    }
}
    zT_214 = 0;
    asp_len = zT_214;
    zT_215 = cli.output_dir_set;
    if (zT_215) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    zT_217 = cli.output_dir;
    od2 = zT_217;
    zT_219 = 0;
    oi2 = zT_219;
    goto z_bb_28;
    z_bb_26:
    zT_242 = ".zig1_ast.tmp";
    zT_244 = 13;
    zT_243.ptr = (unsigned char*)zT_242;
    zT_243.len = zT_244;
    ast_tmp_name = zT_243;
    zT_246 = 0;
    ati = zT_246;
    goto z_bb_35;
    z_bb_27:
    zT_235 = 46;
    ast_spill_path[asp_len] = zT_235;
    zT_237 = asp_len + (unsigned int)(1);
    asp_len = zT_237;
    zT_238 = 47;
    ast_spill_path[asp_len] = zT_238;
    zT_240 = asp_len + (unsigned int)(1);
    asp_len = zT_240;
    goto z_bb_26;
    z_bb_28:
    zT_221 = od2.len;
    if ((unsigned char)(oi2 < zT_221)) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    zT_226 = od2.ptr;
    zT_227 = zT_226[oi2];
    ast_spill_path[asp_len] = zT_227;
    zT_229 = asp_len + (unsigned int)(1);
    asp_len = zT_229;
    goto z_bb_31;
    z_bb_30:
    zT_232 = 47;
    ast_spill_path[asp_len] = zT_232;
    zT_234 = asp_len + (unsigned int)(1);
    asp_len = zT_234;
    goto z_bb_26;
    z_bb_31:
    zT_231 = oi2 + (unsigned int)(1);
    oi2 = zT_231;
    goto z_bb_28;
    z_bb_32:
    zT_223 = asp_len < (unsigned int)(511);
    goto z_bb_34;
    z_bb_33:
    zT_223 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_223) goto z_bb_29; else goto z_bb_30;
    z_bb_35:
    zT_248 = ast_tmp_name.len;
    if ((unsigned char)(ati < zT_248)) goto z_bb_39; else goto z_bb_40;
    z_bb_36:
    zT_253 = ast_tmp_name.ptr;
    zT_254 = zT_253[ati];
    ast_spill_path[asp_len] = zT_254;
    zT_256 = asp_len + (unsigned int)(1);
    asp_len = zT_256;
    goto z_bb_38;
    z_bb_37:
    zT_259 = (zT_6B0A7D14_AstStore*)&store;
    zT_264 = 0;
    zT_265 = (unsigned char*)((unsigned char*)ast_spill_path) + zT_264;
    zT_266 = asp_len - zT_264;
    zT_267.ptr = (unsigned char*)zT_265;
    zT_267.len = zT_266;
    zT_260 = zT_267;
    zF_2A507339_astStoreSetSpillPat(zT_259, zT_260);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_269[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        id_spill_path[_i] = zT_269[_i];
        _i++;
    }
}
    zT_271 = 0;
    idp_len = zT_271;
    zT_272 = cli.output_dir_set;
    if (zT_272) goto z_bb_42; else goto z_bb_44;
    z_bb_38:
    zT_258 = ati + (unsigned int)(1);
    ati = zT_258;
    goto z_bb_35;
    z_bb_39:
    zT_250 = asp_len < (unsigned int)(511);
    goto z_bb_41;
    z_bb_40:
    zT_250 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_250) goto z_bb_36; else goto z_bb_37;
    z_bb_42:
    zT_274 = cli.output_dir;
    od3 = zT_274;
    zT_276 = 0;
    oi3 = zT_276;
    goto z_bb_45;
    z_bb_43:
    zT_299 = ".zig1_side.tmp";
    zT_301 = 14;
    zT_300.ptr = (unsigned char*)zT_299;
    zT_300.len = zT_301;
    id_tmp_name = zT_300;
    zT_303 = 0;
    iti = zT_303;
    goto z_bb_52;
    z_bb_44:
    zT_292 = 46;
    id_spill_path[idp_len] = zT_292;
    zT_294 = idp_len + (unsigned int)(1);
    idp_len = zT_294;
    zT_295 = 47;
    id_spill_path[idp_len] = zT_295;
    zT_297 = idp_len + (unsigned int)(1);
    idp_len = zT_297;
    goto z_bb_43;
    z_bb_45:
    zT_278 = od3.len;
    if ((unsigned char)(oi3 < zT_278)) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_283 = od3.ptr;
    zT_284 = zT_283[oi3];
    id_spill_path[idp_len] = zT_284;
    zT_286 = idp_len + (unsigned int)(1);
    idp_len = zT_286;
    goto z_bb_48;
    z_bb_47:
    zT_289 = 47;
    id_spill_path[idp_len] = zT_289;
    zT_291 = idp_len + (unsigned int)(1);
    idp_len = zT_291;
    goto z_bb_43;
    z_bb_48:
    zT_288 = oi3 + (unsigned int)(1);
    oi3 = zT_288;
    goto z_bb_45;
    z_bb_49:
    zT_280 = idp_len < (unsigned int)(511);
    goto z_bb_51;
    z_bb_50:
    zT_280 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_280) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_305 = id_tmp_name.len;
    if ((unsigned char)(iti < zT_305)) goto z_bb_56; else goto z_bb_57;
    z_bb_53:
    zT_310 = id_tmp_name.ptr;
    zT_311 = zT_310[iti];
    id_spill_path[idp_len] = zT_311;
    zT_313 = idp_len + (unsigned int)(1);
    idp_len = zT_313;
    goto z_bb_55;
    z_bb_54:
    zT_316 = (zT_6B0A7D14_AstStore*)&store;
    zT_323 = 0;
    zT_324 = (unsigned char*)((unsigned char*)id_spill_path) + zT_323;
    zT_325 = idp_len - zT_323;
    zT_326.ptr = (unsigned char*)zT_324;
    zT_326.len = zT_325;
    zT_318 = zT_326;
    zF_35B9B6EC_astStoreSetValuePoo(zT_316, (unsigned int)(0), zT_318);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_328[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        iv_spill_path[_i] = zT_328[_i];
        _i++;
    }
}
    zT_330 = 0;
    ivp_len = zT_330;
    zT_331 = cli.output_dir_set;
    if (zT_331) goto z_bb_59; else goto z_bb_61;
    z_bb_55:
    zT_315 = iti + (unsigned int)(1);
    iti = zT_315;
    goto z_bb_52;
    z_bb_56:
    zT_307 = idp_len < (unsigned int)(511);
    goto z_bb_58;
    z_bb_57:
    zT_307 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_307) goto z_bb_53; else goto z_bb_54;
    z_bb_59:
    zT_333 = cli.output_dir;
    od5 = zT_333;
    zT_335 = 0;
    oi5 = zT_335;
    goto z_bb_62;
    z_bb_60:
    zT_358 = ".zig1_side_iv.tmp";
    zT_360 = 17;
    zT_359.ptr = (unsigned char*)zT_358;
    zT_359.len = zT_360;
    iv_tmp_name = zT_359;
    zT_362 = 0;
    ivi = zT_362;
    goto z_bb_69;
    z_bb_61:
    zT_351 = 46;
    iv_spill_path[ivp_len] = zT_351;
    zT_353 = ivp_len + (unsigned int)(1);
    ivp_len = zT_353;
    zT_354 = 47;
    iv_spill_path[ivp_len] = zT_354;
    zT_356 = ivp_len + (unsigned int)(1);
    ivp_len = zT_356;
    goto z_bb_60;
    z_bb_62:
    zT_337 = od5.len;
    if ((unsigned char)(oi5 < zT_337)) goto z_bb_66; else goto z_bb_67;
    z_bb_63:
    zT_342 = od5.ptr;
    zT_343 = zT_342[oi5];
    iv_spill_path[ivp_len] = zT_343;
    zT_345 = ivp_len + (unsigned int)(1);
    ivp_len = zT_345;
    goto z_bb_65;
    z_bb_64:
    zT_348 = 47;
    iv_spill_path[ivp_len] = zT_348;
    zT_350 = ivp_len + (unsigned int)(1);
    ivp_len = zT_350;
    goto z_bb_60;
    z_bb_65:
    zT_347 = oi5 + (unsigned int)(1);
    oi5 = zT_347;
    goto z_bb_62;
    z_bb_66:
    zT_339 = ivp_len < (unsigned int)(511);
    goto z_bb_68;
    z_bb_67:
    zT_339 = 0;
    goto z_bb_68;
    z_bb_68:
    if (zT_339) goto z_bb_63; else goto z_bb_64;
    z_bb_69:
    zT_364 = iv_tmp_name.len;
    if ((unsigned char)(ivi < zT_364)) goto z_bb_73; else goto z_bb_74;
    z_bb_70:
    zT_369 = iv_tmp_name.ptr;
    zT_370 = zT_369[ivi];
    iv_spill_path[ivp_len] = zT_370;
    zT_372 = ivp_len + (unsigned int)(1);
    ivp_len = zT_372;
    goto z_bb_72;
    z_bb_71:
    zT_375 = (zT_6B0A7D14_AstStore*)&store;
    zT_382 = 0;
    zT_383 = (unsigned char*)((unsigned char*)iv_spill_path) + zT_382;
    zT_384 = ivp_len - zT_382;
    zT_385.ptr = (unsigned char*)zT_383;
    zT_385.len = zT_384;
    zT_377 = zT_385;
    zF_35B9B6EC_astStoreSetValuePoo(zT_375, (unsigned int)(1), zT_377);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_387[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ec_spill_path[_i] = zT_387[_i];
        _i++;
    }
}
    zT_389 = 0;
    ecp_len = zT_389;
    zT_390 = cli.output_dir_set;
    if (zT_390) goto z_bb_76; else goto z_bb_78;
    z_bb_72:
    zT_374 = ivi + (unsigned int)(1);
    ivi = zT_374;
    goto z_bb_69;
    z_bb_73:
    zT_366 = ivp_len < (unsigned int)(511);
    goto z_bb_75;
    z_bb_74:
    zT_366 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_366) goto z_bb_70; else goto z_bb_71;
    z_bb_76:
    zT_392 = cli.output_dir;
    od6 = zT_392;
    zT_394 = 0;
    oi6 = zT_394;
    goto z_bb_79;
    z_bb_77:
    zT_417 = ".zig1_extra_ec.tmp";
    zT_419 = 18;
    zT_418.ptr = (unsigned char*)zT_417;
    zT_418.len = zT_419;
    ec_tmp_name = zT_418;
    zT_421 = 0;
    eci = zT_421;
    goto z_bb_86;
    z_bb_78:
    zT_410 = 46;
    ec_spill_path[ecp_len] = zT_410;
    zT_412 = ecp_len + (unsigned int)(1);
    ecp_len = zT_412;
    zT_413 = 47;
    ec_spill_path[ecp_len] = zT_413;
    zT_415 = ecp_len + (unsigned int)(1);
    ecp_len = zT_415;
    goto z_bb_77;
    z_bb_79:
    zT_396 = od6.len;
    if ((unsigned char)(oi6 < zT_396)) goto z_bb_83; else goto z_bb_84;
    z_bb_80:
    zT_401 = od6.ptr;
    zT_402 = zT_401[oi6];
    ec_spill_path[ecp_len] = zT_402;
    zT_404 = ecp_len + (unsigned int)(1);
    ecp_len = zT_404;
    goto z_bb_82;
    z_bb_81:
    zT_407 = 47;
    ec_spill_path[ecp_len] = zT_407;
    zT_409 = ecp_len + (unsigned int)(1);
    ecp_len = zT_409;
    goto z_bb_77;
    z_bb_82:
    zT_406 = oi6 + (unsigned int)(1);
    oi6 = zT_406;
    goto z_bb_79;
    z_bb_83:
    zT_398 = ecp_len < (unsigned int)(511);
    goto z_bb_85;
    z_bb_84:
    zT_398 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_398) goto z_bb_80; else goto z_bb_81;
    z_bb_86:
    zT_423 = ec_tmp_name.len;
    if ((unsigned char)(eci < zT_423)) goto z_bb_90; else goto z_bb_91;
    z_bb_87:
    zT_428 = ec_tmp_name.ptr;
    zT_429 = zT_428[eci];
    ec_spill_path[ecp_len] = zT_429;
    zT_431 = ecp_len + (unsigned int)(1);
    ecp_len = zT_431;
    goto z_bb_89;
    z_bb_88:
    zT_434 = (zT_6B0A7D14_AstStore*)&store;
    zT_441 = 0;
    zT_442 = (unsigned char*)((unsigned char*)ec_spill_path) + zT_441;
    zT_443 = ecp_len - zT_441;
    zT_444.ptr = (unsigned char*)zT_442;
    zT_444.len = zT_443;
    zT_436 = zT_444;
    zF_35B9B6EC_astStoreSetValuePoo(zT_434, (unsigned int)(2), zT_436);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_446[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        er_spill_path[_i] = zT_446[_i];
        _i++;
    }
}
    zT_448 = 0;
    erp_len = zT_448;
    zT_449 = cli.output_dir_set;
    if (zT_449) goto z_bb_93; else goto z_bb_95;
    z_bb_89:
    zT_433 = eci + (unsigned int)(1);
    eci = zT_433;
    goto z_bb_86;
    z_bb_90:
    zT_425 = ecp_len < (unsigned int)(511);
    goto z_bb_92;
    z_bb_91:
    zT_425 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_425) goto z_bb_87; else goto z_bb_88;
    z_bb_93:
    zT_451 = cli.output_dir;
    od7 = zT_451;
    zT_453 = 0;
    oi7 = zT_453;
    goto z_bb_96;
    z_bb_94:
    zT_476 = ".zig1_extra_er.tmp";
    zT_478 = 18;
    zT_477.ptr = (unsigned char*)zT_476;
    zT_477.len = zT_478;
    er_tmp_name = zT_477;
    zT_480 = 0;
    eri = zT_480;
    goto z_bb_103;
    z_bb_95:
    zT_469 = 46;
    er_spill_path[erp_len] = zT_469;
    zT_471 = erp_len + (unsigned int)(1);
    erp_len = zT_471;
    zT_472 = 47;
    er_spill_path[erp_len] = zT_472;
    zT_474 = erp_len + (unsigned int)(1);
    erp_len = zT_474;
    goto z_bb_94;
    z_bb_96:
    zT_455 = od7.len;
    if ((unsigned char)(oi7 < zT_455)) goto z_bb_100; else goto z_bb_101;
    z_bb_97:
    zT_460 = od7.ptr;
    zT_461 = zT_460[oi7];
    er_spill_path[erp_len] = zT_461;
    zT_463 = erp_len + (unsigned int)(1);
    erp_len = zT_463;
    goto z_bb_99;
    z_bb_98:
    zT_466 = 47;
    er_spill_path[erp_len] = zT_466;
    zT_468 = erp_len + (unsigned int)(1);
    erp_len = zT_468;
    goto z_bb_94;
    z_bb_99:
    zT_465 = oi7 + (unsigned int)(1);
    oi7 = zT_465;
    goto z_bb_96;
    z_bb_100:
    zT_457 = erp_len < (unsigned int)(511);
    goto z_bb_102;
    z_bb_101:
    zT_457 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_457) goto z_bb_97; else goto z_bb_98;
    z_bb_103:
    zT_482 = er_tmp_name.len;
    if ((unsigned char)(eri < zT_482)) goto z_bb_107; else goto z_bb_108;
    z_bb_104:
    zT_487 = er_tmp_name.ptr;
    zT_488 = zT_487[eri];
    er_spill_path[erp_len] = zT_488;
    zT_490 = erp_len + (unsigned int)(1);
    erp_len = zT_490;
    goto z_bb_106;
    z_bb_105:
    zT_493 = (zT_6B0A7D14_AstStore*)&store;
    zT_500 = 0;
    zT_501 = (unsigned char*)((unsigned char*)er_spill_path) + zT_500;
    zT_502 = erp_len - zT_500;
    zT_503.ptr = (unsigned char*)zT_501;
    zT_503.len = zT_502;
    zT_495 = zT_503;
    zF_35B9B6EC_astStoreSetValuePoo(zT_493, (unsigned int)(3), zT_495);
    zT_506 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_505 = &zT_506->permanent;
    zT_508 = zF_09A884A8_symbolRegistryInit(zT_505);
    symbol_reg = zT_508;
    zT_511 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_510 = &zT_511->module;
    zT_513 = zF_8D0F00B1_resolvedTypeTableIn(zT_510);
    resolved_types = zT_513;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_515[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        rtt_spill_path[_i] = zT_515[_i];
        _i++;
    }
}
    zT_517 = 0;
    rsp_len = zT_517;
    zT_518 = cli.output_dir_set;
    if (zT_518) goto z_bb_110; else goto z_bb_112;
    z_bb_106:
    zT_492 = eri + (unsigned int)(1);
    eri = zT_492;
    goto z_bb_103;
    z_bb_107:
    zT_484 = erp_len < (unsigned int)(511);
    goto z_bb_109;
    z_bb_108:
    zT_484 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_484) goto z_bb_104; else goto z_bb_105;
    z_bb_110:
    zT_520 = cli.output_dir;
    od4 = zT_520;
    zT_522 = 0;
    oi4 = zT_522;
    goto z_bb_113;
    z_bb_111:
    zT_545 = ".zig1_res.tmp";
    zT_547 = 13;
    zT_546.ptr = (unsigned char*)zT_545;
    zT_546.len = zT_547;
    rtt_tmp_name = zT_546;
    zT_549 = 0;
    rti2 = zT_549;
    goto z_bb_120;
    z_bb_112:
    zT_538 = 46;
    rtt_spill_path[rsp_len] = zT_538;
    zT_540 = rsp_len + (unsigned int)(1);
    rsp_len = zT_540;
    zT_541 = 47;
    rtt_spill_path[rsp_len] = zT_541;
    zT_543 = rsp_len + (unsigned int)(1);
    rsp_len = zT_543;
    goto z_bb_111;
    z_bb_113:
    zT_524 = od4.len;
    if ((unsigned char)(oi4 < zT_524)) goto z_bb_117; else goto z_bb_118;
    z_bb_114:
    zT_529 = od4.ptr;
    zT_530 = zT_529[oi4];
    rtt_spill_path[rsp_len] = zT_530;
    zT_532 = rsp_len + (unsigned int)(1);
    rsp_len = zT_532;
    goto z_bb_116;
    z_bb_115:
    zT_535 = 47;
    rtt_spill_path[rsp_len] = zT_535;
    zT_537 = rsp_len + (unsigned int)(1);
    rsp_len = zT_537;
    goto z_bb_111;
    z_bb_116:
    zT_534 = oi4 + (unsigned int)(1);
    oi4 = zT_534;
    goto z_bb_113;
    z_bb_117:
    zT_526 = rsp_len < (unsigned int)(511);
    goto z_bb_119;
    z_bb_118:
    zT_526 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_526) goto z_bb_114; else goto z_bb_115;
    z_bb_120:
    zT_551 = rtt_tmp_name.len;
    if ((unsigned char)(rti2 < zT_551)) goto z_bb_124; else goto z_bb_125;
    z_bb_121:
    zT_556 = rtt_tmp_name.ptr;
    zT_557 = zT_556[rti2];
    rtt_spill_path[rsp_len] = zT_557;
    zT_559 = rsp_len + (unsigned int)(1);
    rsp_len = zT_559;
    goto z_bb_123;
    z_bb_122:
    zT_562 = (zT_8EED1867_ResolvedTypeTable*)&resolved_types;
    zT_567 = 0;
    zT_568 = (unsigned char*)((unsigned char*)rtt_spill_path) + zT_567;
    zT_569 = rsp_len - zT_567;
    zT_570.ptr = (unsigned char*)zT_568;
    zT_570.len = zT_569;
    zT_563 = zT_570;
    zF_7238A436_resolvedTypeTableSe(zT_562, zT_563);
    zT_573 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_572 = &zT_573->module;
    zT_575 = zF_26B6D809_coercionTableInit(zT_572);
    coercion_table = zT_575;
    zT_578 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_577 = &zT_578->emission;
    zT_580 = zF_F91F6677_lirSlotArrayListIni(zT_577);
    lir_slots = zT_580;
    zT_583 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_582 = &zT_583->module;
    zT_585 = zF_7F194604_depGraphInit(zT_582);
    dep_graph = zT_585;
    zT_588 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_587 = &zT_588->module;
    zT_590 = zF_58BDA2DE_u32ToU32MapInit(zT_587);
    enum_value_table = zT_590;
    zT_593 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_592 = &zT_593->module;
    zT_595 = zF_58BDA2DE_u32ToU32MapInit(zT_592);
    tuple_index_table = zT_595;
    zT_598 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_597 = &zT_598->emission;
    zT_600 = zF_58BDA2DE_u32ToU32MapInit(zT_597);
    error_code_registry = zT_600;
    zT_603 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_602 = &zT_603->module;
    zT_605 = zF_58BDA2DE_u32ToU32MapInit(zT_602);
    call_arg_types = zT_605;
    zT_608 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_607 = &zT_608->module;
    zT_610 = zF_58BDA2DE_u32ToU32MapInit(zT_607);
    call_param_map = zT_610;
    zT_614 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_612 = &zT_614->module;
    zT_617 = zF_125E6ED1_comptimeFoldTableIn(zT_612, (unsigned int)((unsigned int)fold_hint));
    comptime_folds = zT_617;
    zT_620 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_619 = &zT_620->emission;
    zT_622 = zF_046B7660_constInitTableInit(zT_619);
    const_inits = zT_622;
    zT_626 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_625 = &zT_626->permanent;
    zT_628 = zF_58BDA2DE_u32ToU32MapInit(zT_625);
    zT_624.shared_set = zT_628;
    zT_630 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_629 = &zT_630->permanent;
    zT_632 = zF_58BDA2DE_u32ToU32MapInit(zT_629);
    zT_624.pointer_only_map = zT_632;
    zT_634 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_633 = &zT_634->permanent;
    zT_636 = zF_58BDA2DE_u32ToU32MapInit(zT_633);
    zT_624.needs_def_map = zT_636;
    zT_638 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_637 = &zT_638->permanent;
    zT_640 = zF_58BDA2DE_u32ToU32MapInit(zT_637);
    zT_624.needed_tuple_set = zT_640;
    emission_classif = zT_624;
    spell_plan_ph = zT_642;
    zT_645 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_644 = &zT_645->emission;
    zT_647 = zF_986226E1_u64ToU32MapInit(zT_644);
    exported = zT_647;
    zT_650 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_649 = &zT_650->module;
    zT_652 = zF_986226E1_u64ToU32MapInit(zT_649);
    suspending_fns = zT_652;
    zT_655 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_654 = &zT_655->module;
    zT_657 = zF_986226E1_u64ToU32MapInit(zT_654);
    frame_sizes = zT_657;
    zT_660 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_659 = &zT_660->module;
    zT_662 = zF_986226E1_u64ToU32MapInit(zT_659);
    state_widths = zT_662;
    zT_665 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_664 = &zT_665->module;
    zT_667 = zF_986226E1_u64ToU32MapInit(zT_664);
    awaited_fns = zT_667;
    zT_670 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_669 = &zT_670->module;
    zT_672 = zF_986226E1_u64ToU32MapInit(zT_669);
    async_hidden_fns = zT_672;
    zT_675 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_674 = &zT_675->module;
    zT_677 = zF_986226E1_u64ToU32MapInit(zT_674);
    driver_targets = zT_677;
    zT_680 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_679 = &zT_680->module;
    zT_682 = zF_8E537D0C_u32ArrayListInit(zT_679);
    parent_result_type_list = zT_682;
    zT_685 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_684 = &zT_685->module;
    zT_687 = zF_986226E1_u64ToU32MapInit(zT_684);
    parent_result_start = zT_687;
    zT_690 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_689 = &zT_690->module;
    zT_692 = zF_986226E1_u64ToU32MapInit(zT_689);
    parent_result_count = zT_692;
    zT_695 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_694 = &zT_695->module;
    zT_697 = zF_986226E1_u64ToU32MapInit(zT_694);
    async_layouts = zT_697;
    zT_699.cli = cli;
    zT_700 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_699.alloc = zT_700;
    zT_701 = (zT_D3EB6303_StringInterner*)&interner;
    zT_699.interner = zT_701;
    zT_702 = (zT_F85C5DED_DiagnosticCollector*)&diag;
    zT_699.diag = zT_702;
    zT_703 = (zT_227EDE07_SourceManager*)&source_man;
    zT_699.source_man = zT_703;
    zT_704 = (zT_072B53A6_ModuleRegistry*)&mr;
    zT_699.module_reg = zT_704;
    zT_705 = (zT_338B7C76_TypeRegistry*)&typereg;
    zT_699.typereg = zT_705;
    zT_706 = (zT_6B0A7D14_AstStore*)&store;
    zT_699.store = zT_706;
    zT_707 = (zT_3D7259E2_SymbolRegistry*)&symbol_reg;
    zT_699.symbol_reg = zT_707;
    zT_708 = (zT_8EED1867_ResolvedTypeTable*)&resolved_types;
    zT_699.resolved_types = zT_708;
    zT_709 = (zT_66E7D2EF_CoercionTable*)&coercion_table;
    zT_699.coercion_table = zT_709;
    zT_710 = (zT_4D61441E_DepGraph*)&dep_graph;
    zT_699.dep_graph = zT_710;
    zT_699.lir_slots = lir_slots;
    zT_711 = zF_E9CBFCA6_lirStreamInit();
    zT_699.lir_stream = zT_711;
    zT_699.enum_value_table = enum_value_table;
    zT_699.tuple_index_table = tuple_index_table;
    zT_699.error_code_registry = error_code_registry;
    zT_699.call_arg_types = call_arg_types;
    zT_699.call_param_map = call_param_map;
    zT_699.comptime_folds = comptime_folds;
    zT_699.const_inits = const_inits;
    zT_699.exported = exported;
    zT_699.suspending_fns = suspending_fns;
    zT_699.frame_sizes = frame_sizes;
    zT_699.state_widths = state_widths;
    zT_699.awaited_fns = awaited_fns;
    zT_699.async_hidden_fns = async_hidden_fns;
    zT_699.driver_targets = driver_targets;
    zT_699.parent_result_type_list = parent_result_type_list;
    zT_699.parent_result_start = parent_result_start;
    zT_699.parent_result_count = parent_result_count;
    zT_699.async_layouts = async_layouts;
    zT_699.emission_classif = emission_classif;
    zT_699.spell_plan = spell_plan_ph;
    zT_713 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_712 = &zT_713->emission;
    zT_715 = zF_EB0B1609_globalDeclArrayList(zT_712);
    zT_699.global_decls = zT_715;
    zT_717 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_716 = &zT_717->module;
    zT_719 = zF_986226E1_u64ToU32MapInit(zT_716);
    zT_699.module_init_deps = zT_719;
    zT_721 = (zT_69057089_CompilerAlloc*)&compiler_alloc;
    zT_720 = &zT_721->emission;
    zT_723 = zF_8E537D0C_u32ArrayListInit(zT_720);
    zT_699.module_init_order = zT_723;
    ctx = zT_699;
    zT_724 = (zT_5AB29387_CompilerContext*)&ctx;
    zF_74055C03_runCompiler(zT_724);
    return;
    z_bb_123:
    zT_561 = rti2 + (unsigned int)(1);
    rti2 = zT_561;
    goto z_bb_120;
    z_bb_124:
    zT_553 = rsp_len < (unsigned int)(511);
    goto z_bb_126;
    z_bb_125:
    zT_553 = 0;
    goto z_bb_126;
    z_bb_126:
    if (zT_553) goto z_bb_121; else goto z_bb_122;
}

int main(int argc, char** argv) {
    zF_780653D2___module_init();
    zF_780653D2___module_init_1();
    zF_780653D2___module_init_2();
    zF_780653D2___module_init_3();
    zF_780653D2___module_init_4();
    zF_780653D2___module_init_5();
    zF_780653D2___module_init_6();
    zF_780653D2___module_init_7();
    zF_780653D2___module_init_8();
    zF_780653D2___module_init_9();
    zF_780653D2___module_init_10();
    zF_780653D2___module_init_11();
    zF_780653D2___module_init_12();
    zF_780653D2___module_init_13();
    zF_780653D2___module_init_14();
    zF_780653D2___module_init_15();
    zF_780653D2___module_init_16();
    zF_780653D2___module_init_17();
    zF_780653D2___module_init_18();
    zF_780653D2___module_init_19();
    zF_780653D2___module_init_20();
    zF_780653D2___module_init_21();
    zF_780653D2___module_init_22();
    zF_780653D2___module_init_23();
    zF_780653D2___module_init_24();
    zF_EA90E208_main(argc, (unsigned char**)argv);
    return 0;
}

/* runCompiler */
void zF_74055C03_runCompiler(zT_5AB29387_CompilerContext* ctx) {
    zT_5AB29387_CompilerContext* zT_1;
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5AB29387_CompilerContext* zT_24;
    zT_69057089_CompilerAlloc* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    zT_3D7259E2_SymbolRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_D3EB6303_StringInterner* zT_31;
    zT_A4CE86B7_U64ToU32Map* zT_32;
    zT_69057089_CompilerAlloc* zT_33;
    zT_5AB29387_CompilerContext* zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_69057089_CompilerAlloc* zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned char zT_55 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_59;
    zT_69057089_CompilerAlloc* zT_61;
    zT_5AB29387_CompilerContext* zT_63;
    zT_5AB29387_CompilerContext* zT_64;
    zT_5AB29387_CompilerContext* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    unsigned char zT_68 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    int zT_72;
    zT_5AB29387_CompilerContext* zT_74;
    zT_69057089_CompilerAlloc* zT_75;
    zT_F85C5DED_DiagnosticCollector* zT_77;
    unsigned char zT_79 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_80;
    int zT_83;
    zT_5AB29387_CompilerContext* zT_85;
    zT_5AB29387_CompilerContext* zT_86;
    zT_5AB29387_CompilerContext* zT_87;
    zT_69057089_CompilerAlloc* zT_88;
    zT_F85C5DED_DiagnosticCollector* zT_90;
    unsigned char zT_92 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_93;
    int zT_96;
    zT_8EED1867_ResolvedTypeTable* zT_98;
    zT_3E40CD83_Sand* zT_100;
    zT_69057089_CompilerAlloc* zT_101;
    zT_5AB29387_CompilerContext* zT_103;
    zT_5AB29387_CompilerContext* zT_104;
    zT_69057089_CompilerAlloc* zT_105;
    zT_C98AF326_CompilerCli zT_107;
    unsigned char zT_108;
    unsigned char zT_109;
    zT_C98AF326_CompilerCli zT_110;
    unsigned char zT_112;
    zT_F85C5DED_DiagnosticCollector* zT_113;
    unsigned int zT_115 = 0;
    int zT_116;
    zT_F85C5DED_DiagnosticCollector* zT_118;
    int zT_121;
    zT_C98AF326_CompilerCli zT_123;
    unsigned char zT_124;
    zT_69057089_CompilerAlloc* zT_126;
    zT_3E40CD83_Sand zT_127;
    unsigned int zT_128;
    unsigned int zT_131;
    zT_69057089_CompilerAlloc* zT_133;
    zT_3E40CD83_Sand zT_134;
    unsigned int zT_135;
    unsigned int zT_138;
    zT_69057089_CompilerAlloc* zT_140;
    zT_3E40CD83_Sand zT_141;
    unsigned int zT_142;
    unsigned int zT_145;
    unsigned int zT_147 = 0;
    unsigned int zT_150;
    zT_338B7C76_TypeRegistry* zT_152;
    zT_3E40CD83_Sand* zT_153;
    unsigned int zT_154;
    unsigned int zT_157;
    unsigned int zT_160;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    unsigned char* zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    unsigned int zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    unsigned char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    unsigned char* zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned int zT_190;
    unsigned char* zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    unsigned char* zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    unsigned int zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    zT_F85C5DED_DiagnosticCollector* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u z2;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3a;
    zT_8F083A69_Slice_zT_0B42B2F8_u z4;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2;
    unsigned int perm_kb;
    unsigned int mod_kb;
    unsigned int scr_kb;
    unsigned int pool_kb;
    unsigned int type_db_kb;
    unsigned int total;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3b;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3c;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg4;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg5;
    zT_1 = ctx;
    zF_E2BA93CE_phase_ImportResolut(zT_1);
    zT_3 = "2\n";
    zT_5 = 2;
    zT_4.ptr = (unsigned char*)zT_3;
    zT_4.len = zT_5;
    z2 = zT_4;
    zT_6 = z2;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_7 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_7);
    zT_10 = "3\n";
    zT_12 = 2;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    z3 = zT_11;
    zT_13 = z3;
    zF_48AC7B3A_markerWrite(zT_13);
    zT_15 = "3a\n";
    zT_17 = 3;
    zT_16.ptr = (unsigned char*)zT_15;
    zT_16.len = zT_17;
    z3a = zT_16;
    zT_18 = z3a;
    zF_48AC7B3A_markerWrite(zT_18);
    zT_20 = "4\n";
    zT_22 = 2;
    zT_21.ptr = (unsigned char*)zT_20;
    zT_21.len = zT_22;
    z4 = zT_21;
    zT_23 = z4;
    zF_48AC7B3A_markerWrite(zT_23);
    zT_24 = ctx;
    zF_945DEA54_phase_SymbolRegistr(zT_24);
    zT_25 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_25);
    zT_33 = ctx->alloc;
    zT_27 = &zT_33->module;
    zT_28 = ctx->store;
    zT_29 = ctx->symbol_reg;
    zT_30 = ctx->module_reg;
    zT_31 = ctx->interner;
    zT_32 = &ctx->suspending_fns;
    zF_790061E7_suspensionAnalysisR(zT_27, zT_28, zT_29, zT_30, zT_31, zT_32);
    zT_40 = ctx;
    zF_D3497187_phase_TypeResolutio(zT_40);
    zT_42 = "t1\n";
    zT_44 = 3;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    t1 = zT_43;
    zT_45 = t1;
    zF_48AC7B3A_markerWrite(zT_45);
    zT_46 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_46);
    zT_49 = "t2\n";
    zT_51 = 3;
    zT_50.ptr = (unsigned char*)zT_49;
    zT_50.len = zT_51;
    t2 = zT_50;
    zT_52 = t2;
    zF_48AC7B3A_markerWrite(zT_52);
    zT_53 = ctx->diag;
    zT_55 = zF_8F770780_diagnosticCollector(zT_53);
    if (zT_55) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_56 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_56);
    zT_59 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_59));
    goto z_bb_2;
    z_bb_2:
    zT_61 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_61);
    zT_63 = ctx;
    zF_F862154A_phase_FrontResoluti(zT_63);
    zT_64 = ctx;
    zF_9609BF31_phase_ComptimeEvalu(zT_64);
    zT_65 = ctx;
    zF_0666ED4F_phase_SemanticAnaly(zT_65);
    zT_66 = ctx->diag;
    zT_68 = zF_8F770780_diagnosticCollector(zT_66);
    if (zT_68) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_69 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_69);
    zT_72 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_72));
    goto z_bb_4;
    z_bb_4:
    zT_74 = ctx;
    zF_F3B55B42_phase_StaticAnalyze(zT_74);
    zT_75 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_75);
    zT_77 = ctx->diag;
    zT_79 = zF_8F770780_diagnosticCollector(zT_77);
    if (zT_79) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_80 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_80);
    zT_83 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_83));
    goto z_bb_6;
    z_bb_6:
    zT_85 = ctx;
    zF_9BC6214D_phase_AsyncFrameSiz(zT_85);
    zT_86 = ctx;
    zF_A6065296_phase_ConstInit(zT_86);
    zT_87 = ctx;
    zF_1F21ABE7_phase_LIRLowering(zT_87);
    zT_88 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_88);
    zT_90 = ctx->diag;
    zT_92 = zF_8F770780_diagnosticCollector(zT_90);
    if (zT_92) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_93 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_93);
    zT_96 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_96));
    goto z_bb_8;
    z_bb_8:
    zT_98 = ctx->resolved_types;
    zF_5209815D_resolvedTypeTableCl(zT_98);
    zT_101 = ctx->alloc;
    zT_100 = &zT_101->module;
    zF_F1B3F8C2_sandReset(zT_100);
    zT_103 = ctx;
    zF_2682C512_phase_EmissionClass(zT_103);
    zT_104 = ctx;
    zF_2268F8CE_phase_C89Emission(zT_104);
    zT_105 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_105);
    zT_107 = ctx->cli;
    zT_108 = zT_107.warnings_as_errors;
    if (zT_108) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_110 = ctx->cli;
    zT_109 = zT_110.warn_error;
    goto z_bb_11;
    z_bb_10:
    zT_109 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_109) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_113 = ctx->diag;
    zT_115 = zF_4AF2092E_diagnosticCollector(zT_113);
    zT_116 = 0;
    zT_112 = zT_115 > (unsigned int)zT_116;
    goto z_bb_14;
    z_bb_13:
    zT_112 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_112) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_118 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_118);
    zT_121 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_121));
    goto z_bb_16;
    z_bb_16:
    zT_123 = ctx->cli;
    zT_124 = zT_123.track_memory;
    if (zT_124) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_126 = ctx->alloc;
    zT_127 = zT_126->permanent;
    zT_128 = zT_127.peak;
    zT_131 = (unsigned int)(unsigned int)(zT_128 / (unsigned int)(1024));
    perm_kb = zT_131;
    zT_133 = ctx->alloc;
    zT_134 = zT_133->module;
    zT_135 = zT_134.peak;
    zT_138 = (unsigned int)(unsigned int)(zT_135 / (unsigned int)(1024));
    mod_kb = zT_138;
    zT_140 = ctx->alloc;
    zT_141 = zT_140->scratch;
    zT_142 = zT_141.peak;
    zT_145 = (unsigned int)(unsigned int)(zT_142 / (unsigned int)(1024));
    scr_kb = zT_145;
    zT_147 = zF_E5D0D49C_poolPeak();
    zT_150 = (unsigned int)(unsigned int)(zT_147 / (unsigned int)(1024));
    pool_kb = zT_150;
    zT_152 = ctx->typereg;
    zT_153 = zT_152->types_alloc;
    zT_154 = zT_153->peak;
    zT_157 = (unsigned int)(unsigned int)(zT_154 / (unsigned int)(1024));
    type_db_kb = zT_157;
    zT_160 = (unsigned int)(perm_kb + mod_kb) + scr_kb;
    total = zT_160;
    zT_162 = "track-memory: perm=";
    zT_164 = 19;
    zT_163.ptr = (unsigned char*)zT_162;
    zT_163.len = zT_164;
    msg1 = zT_163;
    zT_165 = msg1;
    zF_B5478454_measureMarkerWrite(zT_165);
    zT_166 = perm_kb;
    zF_266B1B8E_writeU32(zT_166);
    zT_168 = "K mod=";
    zT_170 = 6;
    zT_169.ptr = (unsigned char*)zT_168;
    zT_169.len = zT_170;
    msg2 = zT_169;
    zT_171 = msg2;
    zF_B5478454_measureMarkerWrite(zT_171);
    zT_172 = mod_kb;
    zF_266B1B8E_writeU32(zT_172);
    zT_174 = "K scr=";
    zT_176 = 6;
    zT_175.ptr = (unsigned char*)zT_174;
    zT_175.len = zT_176;
    msg3 = zT_175;
    zT_177 = msg3;
    zF_B5478454_measureMarkerWrite(zT_177);
    zT_178 = scr_kb;
    zF_266B1B8E_writeU32(zT_178);
    zT_180 = "K pool=";
    zT_182 = 7;
    zT_181.ptr = (unsigned char*)zT_180;
    zT_181.len = zT_182;
    msg3b = zT_181;
    zT_183 = msg3b;
    zF_B5478454_measureMarkerWrite(zT_183);
    zT_184 = pool_kb;
    zF_266B1B8E_writeU32(zT_184);
    zT_186 = "K type_db=";
    zT_188 = 10;
    zT_187.ptr = (unsigned char*)zT_186;
    zT_187.len = zT_188;
    msg3c = zT_187;
    zT_189 = msg3c;
    zF_B5478454_measureMarkerWrite(zT_189);
    zT_190 = type_db_kb;
    zF_266B1B8E_writeU32(zT_190);
    zT_192 = "K total=";
    zT_194 = 8;
    zT_193.ptr = (unsigned char*)zT_192;
    zT_193.len = zT_194;
    msg4 = zT_193;
    zT_195 = msg4;
    zF_B5478454_measureMarkerWrite(zT_195);
    zT_196 = total;
    zF_266B1B8E_writeU32(zT_196);
    zT_198 = "K\n";
    zT_200 = 2;
    zT_199.ptr = (unsigned char*)zT_198;
    zT_199.len = zT_200;
    msg5 = zT_199;
    zT_201 = msg5;
    zF_B5478454_measureMarkerWrite(zT_201);
    goto z_bb_18;
    z_bb_18:
    zT_202 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_202);
    return;
}

/* astStoreHasPrintRef */
unsigned char zF_A42B6E3C_astStoreHasPrintRef(zT_6B0A7D14_AstStore* store, unsigned int print_id) {
    unsigned int zT_3;
    zT_D1EDC242_anon_279761 zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_8;
    zT_22A7C88B_AstNode zT_11 = {0};
    zT_8143F551_AstKind zT_12;
    unsigned char zT_16;
    zT_8143F551_AstKind zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_24 = 0;
    unsigned int zT_28;
    unsigned int i;
    zT_22A7C88B_AstNode node;
    zT_3 = 0;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = store->nodes;
    zT_5 = zT_4.len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = store;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, (unsigned int)((unsigned int)i));
    node = zT_11;
    zT_12 = node.kind;
    if ((unsigned char)(zT_12 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_28 = i + (unsigned int)(1);
    i = zT_28;
    goto z_bb_1;
    z_bb_5:
    zT_17 = node.kind;
    zT_16 = zT_17 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access);
    goto z_bb_7;
    z_bb_6:
    zT_16 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_16) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_21 = store;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, (unsigned int)((unsigned int)i));
    if ((unsigned char)(zT_24 == print_id)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    goto z_bb_4;
}

/* phase_ImportResolution */
void zF_E2BA93CE_phase_ImportResolut(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_C98AF326_CompilerCli zT_12;
    unsigned int zT_13;
    zT_4DB1475B_ModuleResolver* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_072B53A6_ModuleRegistry* zT_17;
    zT_C98AF326_CompilerCli zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    unsigned int zT_25;
    zT_846744CC_Arr_unsigned_char_5 zT_27;
    unsigned char* zT_29;
    int zT_31;
    unsigned char* zT_32;
    int zT_34 = 0;
    int zT_35;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char zT_46 = 0;
    zT_4DB1475B_ModuleResolver* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_072B53A6_ModuleRegistry* zT_49;
    zT_846744CC_Arr_unsigned_char_5 zT_52;
    zT_C98AF326_CompilerCli zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_C98AF326_CompilerCli zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_59;
    int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_C98AF326_CompilerCli zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_70;
    int zT_71;
    unsigned char* zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_C98AF326_CompilerCli zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    zT_7132B341_Opt_237 zT_77 = {0};
    unsigned char zT_78;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_84 = 0;
    zT_072B53A6_ModuleRegistry* zT_86;
    unsigned int zT_87;
    unsigned int zT_89 = 0;
    zT_47A5CDFB_ImportQueue* zT_90;
    unsigned int zT_91;
    zT_072B53A6_ModuleRegistry* zT_92;
    zT_072B53A6_ModuleRegistry* zT_94;
    zT_3E40CD83_Sand* zT_95;
    zT_3E40CD83_Sand* zT_96;
    zT_6B0A7D14_AstStore* zT_97;
    zT_69057089_CompilerAlloc* zT_99;
    zT_69057089_CompilerAlloc* zT_101;
    zT_D3EB6303_StringInterner* zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_106;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    unsigned int zT_111 = 0;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned char zT_115 = 0;
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_4DB1475B_ModuleResolver* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    zT_3E40CD83_Sand* zT_123;
    zT_072B53A6_ModuleRegistry* zT_124;
    zT_69057089_CompilerAlloc* zT_126;
    zT_BAEE192E_Opt_10 zT_128 = {0};
    unsigned char zT_129;
    zT_D3EB6303_StringInterner* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_134 = 0;
    zT_072B53A6_ModuleRegistry* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    zT_3E40CD83_Sand* zT_138;
    zT_69057089_CompilerAlloc* zT_140;
    zT_BAEE192E_Opt_10 zT_142 = {0};
    zT_072B53A6_ModuleRegistry* zT_143;
    zT_3E40CD83_Sand* zT_144;
    zT_3E40CD83_Sand* zT_145;
    zT_6B0A7D14_AstStore* zT_146;
    zT_69057089_CompilerAlloc* zT_148;
    zT_69057089_CompilerAlloc* zT_150;
    zT_846744CC_Arr_unsigned_char_5 zT_154;
    unsigned int zT_156;
    zT_C98AF326_CompilerCli zT_157;
    unsigned char zT_158;
    zT_C98AF326_CompilerCli zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_163;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned char* zT_170;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned int zT_175;
    unsigned char zT_176;
    unsigned int zT_178;
    unsigned char zT_179;
    unsigned int zT_181;
    unsigned char zT_182;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_192;
    unsigned char zT_194;
    unsigned char* zT_197;
    unsigned char zT_198;
    unsigned int zT_200;
    unsigned int zT_202;
    zT_072B53A6_ModuleRegistry* zT_203;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    int zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char* zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    unsigned int si;
    zT_846744CC_Arr_unsigned_char_5 lib_buf;
    int lib_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_path;
    zT_846744CC_Arr_unsigned_char_5 root_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u root_path;
    zT_7132B341_Opt_237 norm;
    unsigned int path_id;
    unsigned int mod_id;
    unsigned int print_name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_name;
    zT_846744CC_Arr_unsigned_char_5 hash_spill_path;
    unsigned int hsp_len;
    unsigned int fmt_path_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hash_tmp_name;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u z_msg;
    zT_2 = "I\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    si = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_12 = ctx->cli;
    zT_13 = zT_12.include_count;
    if ((unsigned char)(si < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = ctx->module_reg;
    zT_15 = &zT_17->resolver;
    zT_19 = ctx->cli;
    zT_20 = zT_19.include_dirs;
    zT_21 = (unsigned int)si;
    zT_22 = zT_20[zT_21];
    zT_16 = zT_22;
    zF_B75A4515_moduleResolverAddSe(zT_15, zT_16);
    goto z_bb_4;
    z_bb_3:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_27[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        lib_buf[_i] = zT_27[_i];
        _i++;
    }
}
    zT_31 = 0;
    zT_32 = lib_buf + zT_31;
    zT_29 = zT_32;
    zT_34 = zF_BEB0BFA8_getDefaultLibPath(zT_29, (int)(512));
    lib_len = zT_34;
    zT_35 = 0;
    if ((unsigned char)(lib_len > zT_35)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_25 = si + (unsigned int)((unsigned int)zT_23);
    si = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_41 = 0;
    zT_42 = (unsigned char*)((unsigned char*)lib_buf) + zT_41;
    zT_43 = (unsigned int)((unsigned int)lib_len) - zT_41;
    zT_44.ptr = (unsigned char*)zT_42;
    zT_44.len = zT_43;
    lib_path = zT_44;
    zT_45 = lib_path;
    zT_46 = zF_8CC05F84_dirExists(zT_45);
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_52[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        root_buf[_i] = zT_52[_i];
        _i++;
    }
}
    zT_54 = ctx->cli;
    zT_55 = zT_54.input_file;
    root_path = zT_55;
    zT_56 = ctx->cli;
    zT_57 = zT_56.input_file;
    zT_59 = zT_57.len;
    zT_60 = 512;
    if ((unsigned char)(zT_59 <= (unsigned int)zT_60)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_49 = ctx->module_reg;
    zT_47 = &zT_49->resolver;
    zT_48 = lib_path;
    zF_B75A4515_moduleResolverAddSe(zT_47, zT_48);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_67 = ctx->cli;
    zT_68 = zT_67.input_file;
    zT_70 = zT_68.len;
    zT_71 = 0;
    zT_72 = (unsigned char*)((unsigned char*)root_buf) + zT_71;
    zT_73 = zT_70 - zT_71;
    zT_74.ptr = (unsigned char*)zT_72;
    zT_74.len = zT_73;
    zT_63 = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.input_file;
    zT_64 = zT_76;
    zT_77 = zF_36F0DB6B_normalizePath(zT_63, zT_64);
    norm = zT_77;
    zT_78 = norm.has_value;
    if (zT_78) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_81 = ctx->interner;
    zT_82 = root_path;
    zT_84 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    path_id = zT_84;
    zT_86 = ctx->module_reg;
    zT_87 = path_id;
    zT_89 = zF_E4DCE20D_moduleRegistryAddMo(zT_86, zT_87);
    mod_id = zT_89;
    zT_92 = ctx->module_reg;
    zT_90 = &zT_92->import_queue;
    zT_91 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_90, zT_91);
    zT_94 = ctx->module_reg;
    zT_99 = ctx->alloc;
    zT_95 = &zT_99->module;
    zT_101 = ctx->alloc;
    zT_96 = &zT_101->scratch;
    zT_97 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_94, zT_95, zT_96, zT_97);
    zT_105 = ctx->interner;
    zT_108 = "print";
    zT_110 = 5;
    zT_109.ptr = (unsigned char*)zT_108;
    zT_109.len = zT_110;
    zT_106 = zT_109;
    zT_111 = zF_50C274AF_stringInternerInter(zT_105, zT_106);
    print_name_id = zT_111;
    zT_112 = ctx->store;
    zT_113 = print_name_id;
    zT_115 = zF_A42B6E3C_astStoreHasPrintRef(zT_112, zT_113);
    if (zT_115) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    n = norm.value;
    root_path = n;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_117 = "std_fmt.zig";
    zT_119 = 11;
    zT_118.ptr = (unsigned char*)zT_117;
    zT_118.len = zT_119;
    fmt_name = zT_118;
    zT_124 = ctx->module_reg;
    zT_120 = &zT_124->resolver;
    zT_121 = root_path;
    zT_122 = fmt_name;
    zT_126 = ctx->alloc;
    zT_123 = &zT_126->scratch;
    zT_128 = zF_6F148E15_moduleResolverResol(zT_120, zT_121, zT_122, zT_123);
    zT_129 = zT_128.has_value;
    if (zT_129) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_154[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hash_spill_path[_i] = zT_154[_i];
        _i++;
    }
}
    zT_156 = 0;
    hsp_len = zT_156;
    zT_157 = ctx->cli;
    zT_158 = zT_157.output_dir_set;
    if (zT_158) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    zT_131 = ctx->interner;
    zT_132 = fmt_name;
    zT_134 = zF_50C274AF_stringInternerInter(zT_131, zT_132);
    fmt_path_id = zT_134;
    zT_135 = ctx->module_reg;
    zT_136 = fmt_path_id;
    zT_137 = mod_id;
    zT_140 = ctx->alloc;
    zT_138 = &zT_140->scratch;
    zT_142 = zF_620E3E3B_moduleRegistryResol(zT_135, zT_136, zT_137, zT_138);
    (void)zT_142;
    zT_143 = ctx->module_reg;
    zT_148 = ctx->alloc;
    zT_144 = &zT_148->module;
    zT_150 = ctx->alloc;
    zT_145 = &zT_150->scratch;
    zT_146 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_143, zT_144, zT_145, zT_146);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_160 = ctx->cli;
    zT_161 = zT_160.output_dir;
    od = zT_161;
    zT_163 = 0;
    oi = zT_163;
    goto z_bb_20;
    z_bb_18:
    zT_186 = ".zig1_hash.tmp";
    zT_188 = 14;
    zT_187.ptr = (unsigned char*)zT_186;
    zT_187.len = zT_188;
    hash_tmp_name = zT_187;
    zT_190 = 0;
    hi = zT_190;
    goto z_bb_27;
    z_bb_19:
    zT_179 = 46;
    hash_spill_path[hsp_len] = zT_179;
    zT_181 = hsp_len + (unsigned int)(1);
    hsp_len = zT_181;
    zT_182 = 47;
    hash_spill_path[hsp_len] = zT_182;
    zT_184 = hsp_len + (unsigned int)(1);
    hsp_len = zT_184;
    goto z_bb_18;
    z_bb_20:
    zT_165 = od.len;
    if ((unsigned char)(oi < zT_165)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_170 = od.ptr;
    zT_171 = zT_170[oi];
    hash_spill_path[hsp_len] = zT_171;
    zT_173 = hsp_len + (unsigned int)(1);
    hsp_len = zT_173;
    goto z_bb_23;
    z_bb_22:
    zT_176 = 47;
    hash_spill_path[hsp_len] = zT_176;
    zT_178 = hsp_len + (unsigned int)(1);
    hsp_len = zT_178;
    goto z_bb_18;
    z_bb_23:
    zT_175 = oi + (unsigned int)(1);
    oi = zT_175;
    goto z_bb_20;
    z_bb_24:
    zT_167 = hsp_len < (unsigned int)(511);
    goto z_bb_26;
    z_bb_25:
    zT_167 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_167) goto z_bb_21; else goto z_bb_22;
    z_bb_27:
    zT_192 = hash_tmp_name.len;
    if ((unsigned char)(hi < zT_192)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_197 = hash_tmp_name.ptr;
    zT_198 = zT_197[hi];
    hash_spill_path[hsp_len] = zT_198;
    zT_200 = hsp_len + (unsigned int)(1);
    hsp_len = zT_200;
    goto z_bb_30;
    z_bb_29:
    zT_203 = ctx->module_reg;
    zT_208 = 0;
    zT_209 = (unsigned char*)((unsigned char*)hash_spill_path) + zT_208;
    zT_210 = hsp_len - zT_208;
    zT_211.ptr = (unsigned char*)zT_209;
    zT_211.len = zT_210;
    zT_204 = zT_211;
    zF_8767909B_moduleRegistrySpill(zT_203, zT_204);
    zT_213 = "Z\n";
    zT_215 = 2;
    zT_214.ptr = (unsigned char*)zT_213;
    zT_214.len = zT_215;
    z_msg = zT_214;
    zT_216 = z_msg;
    zF_48AC7B3A_markerWrite(zT_216);
    return;
    z_bb_30:
    zT_202 = hi + (unsigned int)(1);
    hi = zT_202;
    goto z_bb_27;
    z_bb_31:
    zT_194 = hsp_len < (unsigned int)(511);
    goto z_bb_33;
    z_bb_32:
    zT_194 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_194) goto z_bb_28; else goto z_bb_29;
}

/* phase_SymbolRegistration */
void zF_945DEA54_phase_SymbolRegistr(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_11;
    zT_4D61441E_DepGraph zT_13 = {0};
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_072B53A6_ModuleRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_4D61441E_DepGraph* zT_29;
    zT_6E8D187B_ModuleEntry* zT_35;
    zT_6E8D187B_ModuleEntry zT_36;
    int zT_40;
    unsigned int zT_42;
    zT_072B53A6_ModuleRegistry* zT_44;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_46 = {0};
    unsigned int zT_48;
    unsigned char zT_51;
    zT_6E8D187B_ModuleEntry* zT_52;
    int zT_53;
    zT_6E8D187B_ModuleEntry zT_54;
    unsigned int zT_55;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    zT_6E8D187B_ModuleEntry* zT_62;
    int zT_63;
    zT_6E8D187B_ModuleEntry zT_64;
    zT_22A7C88B_AstNode zT_66 = {0};
    zT_8143F551_AstKind zT_67;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_6E8D187B_ModuleEntry* zT_75;
    int zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_79 = 0;
    unsigned int zT_81;
    unsigned char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    zT_6B0A7D14_AstStore* zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_97;
    int zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_102 = 0;
    zT_22A7C88B_AstNode zT_103 = {0};
    zT_8143F551_AstKind zT_105;
    unsigned int zT_106;
    zT_4028D896_Arr_unsigned_char_2 zT_108;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    int zT_114;
    unsigned char* zT_115;
    unsigned int zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118 = 0;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned char* zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_136;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_141;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_DDCD424B_Slice_zT_6E8D187B_M smods;
    zT_22A7C88B_AstNode sr;
    unsigned int sdl_n;
    unsigned int sdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl;
    zT_22A7C88B_AstNode sd;
    unsigned int sk;
    zT_4028D896_Arr_unsigned_char_2 sb;
    unsigned int slen;
    unsigned int sst;
    zT_8F083A69_Slice_zT_0B42B2F8_u ssp;
    zT_8F083A69_Slice_zT_0B42B2F8_u sn;
    zT_2 = "S\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->alloc;
    zT_10 = &zT_11->scratch;
    zT_13 = zF_7F194604_depGraphInit(zT_10);
    dep_graph = zT_13;
    zT_15 = ctx->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_22 = mods.len;
    if ((unsigned char)(mi < zT_22)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_24 = ctx->module_reg;
    zT_25 = ctx->symbol_reg;
    zT_26 = ctx->typereg;
    zT_27 = ctx->store;
    zT_35 = mods.ptr;
    zT_36 = zT_35[mi];
    zT_28 = zT_36.id;
    zT_29 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_24, zT_25, zT_26, zT_27, zT_28, zT_29, (unsigned char)(1));
    goto z_bb_4;
    z_bb_3:
    zT_44 = ctx->module_reg;
    zT_46 = zF_3452C137_moduleRegistryGetMo(zT_44);
    smods = zT_46;
    zT_48 = smods.len;
    if ((unsigned char)(zT_48 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_40 = 1;
    zT_42 = mi + (unsigned int)((unsigned int)zT_40);
    mi = zT_42;
    goto z_bb_1;
    z_bb_5:
    zT_52 = smods.ptr;
    zT_53 = 0;
    zT_54 = zT_52[zT_53];
    zT_55 = zT_54.ast_root;
    zT_51 = zT_55 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_51 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_51) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_59 = ctx->store;
    zT_62 = smods.ptr;
    zT_63 = 0;
    zT_64 = zT_62[zT_63];
    zT_60 = zT_64.ast_root;
    zT_66 = zF_FCDD1D35_astStoreNodeAt(zT_59, zT_60);
    sr = zT_66;
    zT_67 = sr.kind;
    if ((unsigned char)(zT_67 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_72 = ctx->store;
    zT_75 = smods.ptr;
    zT_76 = 0;
    zT_77 = zT_75[zT_76];
    zT_73 = zT_77.ast_root;
    zT_79 = zF_152E19CB_astStoreNodeExtraCh(zT_72, zT_73);
    sdl_n = zT_79;
    zT_81 = 0;
    sdi = zT_81;
    zT_83 = "S0";
    zT_85 = 2;
    zT_84.ptr = (unsigned char*)zT_83;
    zT_84.len = zT_85;
    sl = zT_84;
    zT_86 = sl;
    zF_48AC7B3A_markerWrite(zT_86);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(sdi < (unsigned int)((unsigned int)sdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_90 = ctx->store;
    zT_93 = ctx->store;
    zT_97 = smods.ptr;
    zT_98 = 0;
    zT_99 = zT_97[zT_98];
    zT_94 = zT_99.ast_root;
    zT_102 = zF_B10B1BC1_astStoreNodeExtraCh(zT_93, zT_94, (unsigned int)((unsigned int)sdi));
    zT_91 = zT_102;
    zT_103 = zF_FCDD1D35_astStoreNodeAt(zT_90, zT_91);
    sd = zT_103;
    zT_105 = sd.kind;
    zT_106 = (unsigned int)zT_105;
    sk = zT_106;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_108[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sb[_i] = zT_108[_i];
        _i++;
    }
}
    zT_110 = sk;
    zT_114 = 0;
    zT_115 = (unsigned char*)((unsigned char*)sb) + zT_114;
    zT_116 = (unsigned int)(20) - zT_114;
    zT_117.ptr = (unsigned char*)zT_115;
    zT_117.len = zT_116;
    zT_111 = zT_117;
    zT_118 = zF_A7504564_itoa(zT_110, zT_111);
    slen = zT_118;
    zT_122 = (unsigned int)(19) - (unsigned int)((unsigned int)slen);
    sst = zT_122;
    zT_127 = (unsigned char*)((unsigned char*)sb) + sst;
    zT_128 = (unsigned int)(19) - sst;
    zT_129.ptr = (unsigned char*)zT_127;
    zT_129.len = zT_128;
    zT_123 = zT_129;
    zF_48AC7B3A_markerWrite(zT_123);
    zT_131 = " ";
    zT_133 = 1;
    zT_132.ptr = (unsigned char*)zT_131;
    zT_132.len = zT_133;
    ssp = zT_132;
    zT_134 = ssp;
    zF_48AC7B3A_markerWrite(zT_134);
    goto z_bb_15;
    z_bb_14:
    zT_138 = "\n";
    zT_140 = 1;
    zT_139.ptr = (unsigned char*)zT_138;
    zT_139.len = zT_140;
    sn = zT_139;
    zT_141 = sn;
    zF_48AC7B3A_markerWrite(zT_141);
    goto z_bb_11;
    z_bb_15:
    zT_136 = sdi + (unsigned int)(1);
    sdi = zT_136;
    goto z_bb_12;
}

/* phase_TypeResolution */
void zF_D3497187_phase_TypeResolutio(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_D1EDC242_anon_279761 zT_10;
    zT_3E40CD83_Sand* zT_12;
    zT_69057089_CompilerAlloc* zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_69057089_CompilerAlloc* zT_17;
    zT_4D61441E_DepGraph zT_19 = {0};
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_3D7259E2_SymbolRegistry* zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_4D61441E_DepGraph* zT_35;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    int zT_46;
    unsigned int zT_48;
    zT_3D7259E2_SymbolRegistry* zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    zT_D3EB6303_StringInterner* zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    zT_3E40CD83_Sand* zT_53;
    zT_69057089_CompilerAlloc* zT_58;
    zT_6B0A7D14_AstStore* zT_60;
    zT_338B7C76_TypeRegistry* zT_61;
    zT_3D7259E2_SymbolRegistry* zT_62;
    zT_D3EB6303_StringInterner* zT_63;
    zT_8EED1867_ResolvedTypeTable* zT_64;
    zT_072B53A6_ModuleRegistry* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    zT_69057089_CompilerAlloc* zT_75;
    zT_338B7C76_TypeRegistry* zT_78;
    zT_F85C5DED_DiagnosticCollector* zT_79;
    zT_3E40CD83_Sand* zT_80;
    zT_69057089_CompilerAlloc* zT_83;
    zT_C890C8CB_TypeResolver zT_85 = {0};
    zT_C890C8CB_TypeResolver* zT_86;
    zT_C890C8CB_TypeResolver* zT_88;
    zT_4D61441E_DepGraph* zT_89;
    zT_C890C8CB_TypeResolver* zT_92;
    zT_6B0A7D14_AstStore* zT_94;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_3D7259E2_SymbolRegistry* zT_96;
    zT_D3EB6303_StringInterner* zT_97;
    zT_072B53A6_ModuleRegistry* zT_98;
    zT_F85C5DED_DiagnosticCollector* zT_99;
    zT_C890C8CB_TypeResolver* zT_106;
    zT_786E6CF2_EmissionClassificat* zT_107;
    zT_3E40CD83_Sand* zT_108;
    zT_69057089_CompilerAlloc* zT_111;
    unsigned int zT_114;
    unsigned char zT_117;
    zT_6E8D187B_ModuleEntry* zT_118;
    int zT_119;
    zT_6E8D187B_ModuleEntry zT_120;
    unsigned int zT_121;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    zT_6E8D187B_ModuleEntry* zT_128;
    int zT_129;
    zT_6E8D187B_ModuleEntry zT_130;
    zT_22A7C88B_AstNode zT_132 = {0};
    zT_8143F551_AstKind zT_133;
    zT_6B0A7D14_AstStore* zT_138;
    unsigned int zT_139;
    zT_6E8D187B_ModuleEntry* zT_141;
    int zT_142;
    zT_6E8D187B_ModuleEntry zT_143;
    unsigned int zT_145 = 0;
    unsigned int zT_147;
    unsigned char* zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned int zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_159;
    unsigned int zT_160;
    zT_6E8D187B_ModuleEntry* zT_163;
    int zT_164;
    zT_6E8D187B_ModuleEntry zT_165;
    unsigned int zT_168 = 0;
    zT_22A7C88B_AstNode zT_169 = {0};
    zT_8143F551_AstKind zT_171;
    unsigned int zT_172;
    zT_4028D896_Arr_unsigned_char_2 zT_174;
    unsigned int zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    int zT_180;
    unsigned char* zT_181;
    unsigned int zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184 = 0;
    unsigned int zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_189;
    unsigned char* zT_193;
    unsigned int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned char* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_202;
    unsigned char* zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_C890C8CB_TypeResolver tr;
    zT_22A7C88B_AstNode tr2;
    unsigned int tdl_n;
    unsigned int tdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tl;
    zT_22A7C88B_AstNode td;
    unsigned int tk;
    zT_4028D896_Arr_unsigned_char_2 tb;
    unsigned int tlen;
    unsigned int tst;
    zT_8F083A69_Slice_zT_0B42B2F8_u tsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tn;
    zT_2 = "T\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->resolved_types;
    zT_9 = ctx->store;
    zT_10 = zT_9->nodes;
    zT_7 = zT_10.len;
    zF_75224871_resolvedTypeTableRe(zT_6, zT_7);
    zT_13 = ctx->alloc;
    zT_12 = &zT_13->scratch;
    zF_F1B3F8C2_sandReset(zT_12);
    zT_17 = ctx->alloc;
    zT_16 = &zT_17->scratch;
    zT_19 = zF_7F194604_depGraphInit(zT_16);
    dep_graph = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    mi = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_28 = mods.len;
    if ((unsigned char)(mi < zT_28)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_30 = ctx->module_reg;
    zT_31 = ctx->symbol_reg;
    zT_32 = ctx->typereg;
    zT_33 = ctx->store;
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_34 = zT_42.id;
    zT_35 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_30, zT_31, zT_32, zT_33, zT_34, zT_35, (unsigned char)(0));
    goto z_bb_4;
    z_bb_3:
    zT_49 = ctx->symbol_reg;
    zT_50 = ctx->typereg;
    zT_51 = ctx->interner;
    zT_52 = ctx->store;
    zT_58 = ctx->alloc;
    zT_53 = &zT_58->permanent;
    zF_EF7F7D3C_constAliasPrepass(zT_49, zT_50, zT_51, zT_52, zT_53);
    zT_60 = ctx->store;
    zT_61 = ctx->typereg;
    zT_62 = ctx->symbol_reg;
    zT_63 = ctx->interner;
    zT_64 = ctx->resolved_types;
    zT_65 = ctx->module_reg;
    zT_66 = ctx->diag;
    zT_75 = ctx->alloc;
    zT_67 = &zT_75->permanent;
    zF_373A7BEF_typeResolverResolve(zT_60, zT_61, zT_62, zT_63, zT_64, zT_65, zT_66, zT_67);
    zT_78 = ctx->typereg;
    zT_79 = ctx->diag;
    zT_83 = ctx->alloc;
    zT_80 = &zT_83->scratch;
    zT_85 = zF_5BFAC855_typeResolverInit(zT_78, zT_79, zT_80);
    tr = zT_85;
    zT_86 = (zT_C890C8CB_TypeResolver*)&tr;
    zF_D5C4530C_typeResolverBuildDe(zT_86);
    zT_88 = (zT_C890C8CB_TypeResolver*)&tr;
    zT_89 = (zT_4D61441E_DepGraph*)&dep_graph;
    zF_33272F41_typeResolverBuild(zT_88, zT_89);
    zT_92 = (zT_C890C8CB_TypeResolver*)&tr;
    zF_30BE7185_typeResolverResolve(zT_92);
    zT_94 = ctx->store;
    zT_95 = ctx->typereg;
    zT_96 = ctx->symbol_reg;
    zT_97 = ctx->interner;
    zT_98 = ctx->module_reg;
    zT_99 = ctx->diag;
    zF_153D24FD_enumReevaluateAll(zT_94, zT_95, zT_96, zT_97, zT_98, zT_99);
    zT_106 = (zT_C890C8CB_TypeResolver*)&tr;
    zT_107 = &ctx->emission_classif;
    zT_111 = ctx->alloc;
    zT_108 = &zT_111->permanent;
    zF_ACC002C8_classifyTypeEmissio(zT_106, zT_107, zT_108);
    zT_114 = mods.len;
    if ((unsigned char)(zT_114 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_46 = 1;
    zT_48 = mi + (unsigned int)((unsigned int)zT_46);
    mi = zT_48;
    goto z_bb_1;
    z_bb_5:
    zT_118 = mods.ptr;
    zT_119 = 0;
    zT_120 = zT_118[zT_119];
    zT_121 = zT_120.ast_root;
    zT_117 = zT_121 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_117 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_117) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_125 = ctx->store;
    zT_128 = mods.ptr;
    zT_129 = 0;
    zT_130 = zT_128[zT_129];
    zT_126 = zT_130.ast_root;
    zT_132 = zF_FCDD1D35_astStoreNodeAt(zT_125, zT_126);
    tr2 = zT_132;
    zT_133 = tr2.kind;
    if ((unsigned char)(zT_133 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_138 = ctx->store;
    zT_141 = mods.ptr;
    zT_142 = 0;
    zT_143 = zT_141[zT_142];
    zT_139 = zT_143.ast_root;
    zT_145 = zF_152E19CB_astStoreNodeExtraCh(zT_138, zT_139);
    tdl_n = zT_145;
    zT_147 = 0;
    tdi = zT_147;
    zT_149 = "T0";
    zT_151 = 2;
    zT_150.ptr = (unsigned char*)zT_149;
    zT_150.len = zT_151;
    tl = zT_150;
    zT_152 = tl;
    zF_48AC7B3A_markerWrite(zT_152);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    if ((unsigned char)(tdi < (unsigned int)((unsigned int)tdl_n))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_156 = ctx->store;
    zT_159 = ctx->store;
    zT_163 = mods.ptr;
    zT_164 = 0;
    zT_165 = zT_163[zT_164];
    zT_160 = zT_165.ast_root;
    zT_168 = zF_B10B1BC1_astStoreNodeExtraCh(zT_159, zT_160, (unsigned int)((unsigned int)tdi));
    zT_157 = zT_168;
    zT_169 = zF_FCDD1D35_astStoreNodeAt(zT_156, zT_157);
    td = zT_169;
    zT_171 = td.kind;
    zT_172 = (unsigned int)zT_171;
    tk = zT_172;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_174[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        tb[_i] = zT_174[_i];
        _i++;
    }
}
    zT_176 = tk;
    zT_180 = 0;
    zT_181 = (unsigned char*)((unsigned char*)tb) + zT_180;
    zT_182 = (unsigned int)(20) - zT_180;
    zT_183.ptr = (unsigned char*)zT_181;
    zT_183.len = zT_182;
    zT_177 = zT_183;
    zT_184 = zF_A7504564_itoa(zT_176, zT_177);
    tlen = zT_184;
    zT_188 = (unsigned int)(19) - (unsigned int)((unsigned int)tlen);
    tst = zT_188;
    zT_193 = (unsigned char*)((unsigned char*)tb) + tst;
    zT_194 = (unsigned int)(19) - tst;
    zT_195.ptr = (unsigned char*)zT_193;
    zT_195.len = zT_194;
    zT_189 = zT_195;
    zF_48AC7B3A_markerWrite(zT_189);
    zT_197 = " ";
    zT_199 = 1;
    zT_198.ptr = (unsigned char*)zT_197;
    zT_198.len = zT_199;
    tsp = zT_198;
    zT_200 = tsp;
    zF_48AC7B3A_markerWrite(zT_200);
    goto z_bb_15;
    z_bb_14:
    zT_204 = "\n";
    zT_206 = 1;
    zT_205.ptr = (unsigned char*)zT_204;
    zT_205.len = zT_206;
    tn = zT_205;
    zT_207 = tn;
    zF_48AC7B3A_markerWrite(zT_207);
    goto z_bb_11;
    z_bb_15:
    zT_202 = tdi + (unsigned int)(1);
    tdi = zT_202;
    goto z_bb_12;
}

/* phase_FrontResolution */
void zF_F862154A_phase_FrontResoluti(zT_5AB29387_CompilerContext* ctx) {
    zT_6DCFC8DB_FrontResCtx zT_2;
    zT_6B0A7D14_AstStore* zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_3E40CD83_Sand* zT_11;
    zT_66E7D2EF_CoercionTable* zT_12;
    zT_21D3708C_U32ToU32Map* zT_13;
    zT_21D3708C_U32ToU32Map* zT_14;
    zT_21D3708C_U32ToU32Map* zT_15;
    zT_21D3708C_U32ToU32Map* zT_16;
    zT_21D3708C_U32ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_6DCFC8DB_FrontResCtx* zT_19;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_3 = ctx->store;
    zT_2.store = zT_3;
    zT_4 = ctx->typereg;
    zT_2.typereg = zT_4;
    zT_5 = ctx->symbol_reg;
    zT_2.symbol_reg = zT_5;
    zT_6 = ctx->resolved_types;
    zT_2.resolved_types = zT_6;
    zT_7 = ctx->module_reg;
    zT_2.module_reg = zT_7;
    zT_8 = ctx->interner;
    zT_2.interner = zT_8;
    zT_9 = ctx->diag;
    zT_2.diag = zT_9;
    zT_10 = ctx->alloc;
    zT_11 = &zT_10->scratch;
    zT_2.scratch = zT_11;
    zT_12 = ctx->coercion_table;
    zT_2.coercion_table = zT_12;
    zT_13 = &ctx->enum_value_table;
    zT_2.enum_value_table = zT_13;
    zT_14 = &ctx->tuple_index_table;
    zT_2.tuple_index_table = zT_14;
    zT_15 = &ctx->error_code_registry;
    zT_2.error_code_registry = zT_15;
    zT_16 = &ctx->call_arg_types;
    zT_2.call_arg_types = zT_16;
    zT_17 = &ctx->call_param_map;
    zT_2.call_param_map = zT_17;
    zT_18 = &ctx->suspending_fns;
    zT_2.suspending_fns = zT_18;
    frc = zT_2;
    zT_19 = (zT_6DCFC8DB_FrontResCtx*)&frc;
    zF_8A0E7747_frontResolveModuleI(zT_19);
    return;
}

/* phase_ComptimeEvaluation */
void zF_9609BF31_phase_ComptimeEvalu(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15 = {0};
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_6B306B38_Opt_241 zT_19;
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    zT_D1EDC242_anon_279761 zT_28;
    unsigned int zT_29;
    unsigned int zT_32;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_39;
    zT_6E8D187B_ModuleEntry* zT_42;
    zT_6E8D187B_ModuleEntry zT_43;
    unsigned int zT_44;
    unsigned char zT_49;
    zT_6E8D187B_ModuleEntry* zT_51;
    zT_6E8D187B_ModuleEntry zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_58;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_8143F551_AstKind zT_63;
    zT_DA663F79_ComptimeEval* zT_68;
    zT_DE37DC06_Opt_210 zT_72 = {0};
    unsigned char zT_73;
    zT_77F6F59C_ComptimeFoldTable* zT_75;
    zT_89B1DDDA_ComptimeVal zT_77;
    zT_8143F551_AstKind zT_80;
    unsigned char zT_84;
    unsigned int zT_85;
    int zT_86;
    unsigned char zT_88;
    zT_6B0A7D14_AstStore* zT_94;
    unsigned int zT_95;
    zT_22A7C88B_AstNode zT_98 = {0};
    zT_8143F551_AstKind zT_100;
    unsigned int zT_101;
    unsigned char zT_104;
    unsigned char zT_107;
    unsigned char zT_110;
    zT_DA663F79_ComptimeEval* zT_114;
    unsigned int zT_115;
    zT_DE37DC06_Opt_210 zT_118 = {0};
    unsigned char zT_119;
    zT_77F6F59C_ComptimeFoldTable* zT_121;
    unsigned int zT_122;
    zT_89B1DDDA_ComptimeVal zT_123;
    zT_8143F551_AstKind zT_126;
    unsigned char zT_130;
    zT_8143F551_AstKind zT_131;
    zT_6B0A7D14_AstStore* zT_135;
    unsigned int zT_139 = 0;
    zT_DA663F79_ComptimeEval* zT_143;
    unsigned int zT_144;
    zT_DE37DC06_Opt_210 zT_147 = {0};
    unsigned char zT_148;
    unsigned char zT_150;
    zT_77F6F59C_ComptimeFoldTable* zT_153;
    unsigned int zT_154;
    zT_89B1DDDA_ComptimeVal zT_155;
    unsigned int zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_m;
    zT_DA663F79_ComptimeEval ce;
    zT_DDCD424B_Slice_zT_6E8D187B_M p7_mods;
    unsigned int ni;
    unsigned int p7_best_root;
    unsigned int p7_best_id;
    unsigned int p7_si;
    unsigned int p7_r;
    zT_22A7C88B_AstNode node;
    zT_DE37DC06_Opt_210 val;
    zT_89B1DDDA_ComptimeVal v;
    zT_22A7C88B_AstNode init_n;
    unsigned int ik;
    zT_DE37DC06_Opt_210 val2;
    zT_89B1DDDA_ComptimeVal v2;
    zT_DE37DC06_Opt_210 cval;
    zT_89B1DDDA_ComptimeVal cv;
    zT_2 = "CE\n";
    zT_4 = 3;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    pc_m = zT_3;
    zT_5 = pc_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ce.diag = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    p7_mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    ni = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_27 = ctx->store;
    zT_28 = zT_27->nodes;
    zT_29 = zT_28.len;
    if ((unsigned char)(ni < zT_29)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_32 = 4294967295u;
    p7_best_root = zT_32;
    zT_34 = 4294967295u;
    p7_best_id = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    p7_si = zT_37;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    zT_159 = ni + (unsigned int)(1);
    ni = zT_159;
    goto z_bb_1;
    z_bb_5:
    zT_39 = p7_mods.len;
    if ((unsigned char)(p7_si < zT_39)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_42 = p7_mods.ptr;
    zT_43 = zT_42[p7_si];
    zT_44 = zT_43.ast_root;
    p7_r = zT_44;
    if ((unsigned char)(p7_r == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    ce.module_id = p7_best_id;
    zT_58 = ctx->store;
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_58, (unsigned int)((unsigned int)ni));
    node = zT_62;
    zT_63 = node.kind;
    if ((unsigned char)(zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_16; else goto z_bb_18;
    z_bb_8:
    zT_54 = 1;
    zT_56 = p7_si + (unsigned int)((unsigned int)zT_54);
    p7_si = zT_56;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    if ((unsigned char)((unsigned int)((unsigned int)p7_r) >= ni)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_49 = p7_r < p7_best_root;
    goto z_bb_13;
    z_bb_12:
    zT_49 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_49) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    p7_best_root = p7_r;
    zT_51 = p7_mods.ptr;
    zT_52 = zT_51[p7_si];
    zT_53 = zT_52.id;
    p7_best_id = zT_53;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_68 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_72 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_68, (unsigned int)((unsigned int)ni));
    val = zT_72;
    zT_73 = val.has_value;
    if (zT_73) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_4;
    z_bb_18:
    zT_80 = node.kind;
    if ((unsigned char)(zT_80 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    v = val.value;
    zT_75 = &ctx->comptime_folds;
    zT_77 = v;
    zF_376429F5_comptimeFoldTablePu(zT_75, (unsigned int)((unsigned int)ni), zT_77);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_85 = node.child_1;
    zT_86 = 0;
    zT_84 = zT_85 != (unsigned int)zT_86;
    goto z_bb_23;
    z_bb_22:
    zT_84 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_84) goto z_bb_24; else goto z_bb_26;
    z_bb_24:
    zT_88 = node.flags;
    if ((unsigned char)((unsigned char)(zT_88 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    goto z_bb_17;
    z_bb_26:
    zT_126 = node.kind;
    if ((unsigned char)(zT_126 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_expr))) goto z_bb_43; else goto z_bb_42;
    z_bb_27:
    zT_94 = ctx->store;
    zT_95 = node.child_1;
    zT_98 = zF_FCDD1D35_astStoreNodeAt(zT_94, zT_95);
    init_n = zT_98;
    zT_100 = init_n.kind;
    zT_101 = (unsigned int)zT_100;
    ik = zT_101;
    if ((unsigned char)(ik >= (unsigned int)(33))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_104 = ik <= (unsigned int)(42);
    goto z_bb_31;
    z_bb_30:
    zT_104 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_104) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_107 = ik == (unsigned int)(62);
    goto z_bb_34;
    z_bb_33:
    zT_107 = 1;
    goto z_bb_34;
    z_bb_34:
    if (zT_107) goto z_bb_36; else goto z_bb_35;
    z_bb_35:
    zT_110 = ik == (unsigned int)(64);
    goto z_bb_37;
    z_bb_36:
    zT_110 = 1;
    goto z_bb_37;
    z_bb_37:
    if (zT_110) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_114 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_115 = node.child_1;
    zT_118 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_114, zT_115);
    val2 = zT_118;
    zT_119 = val2.has_value;
    if (zT_119) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_28;
    z_bb_40:
    v2 = val2.value;
    zT_121 = &ctx->comptime_folds;
    zT_122 = node.child_1;
    zT_123 = v2;
    zF_376429F5_comptimeFoldTablePu(zT_121, zT_122, zT_123);
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    zT_131 = node.kind;
    zT_130 = zT_131 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_if_stmt);
    goto z_bb_44;
    z_bb_43:
    zT_130 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_130) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_135 = ctx->store;
    zT_139 = zF_8BA26B9E_astStoreNodePayload(zT_135, (unsigned int)((unsigned int)ni));
    if ((unsigned char)(zT_139 == (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_25;
    z_bb_47:
    zT_143 = (zT_DA663F79_ComptimeEval*)&ce;
    zT_144 = node.child_0;
    zT_147 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_143, zT_144);
    cval = zT_147;
    zT_148 = cval.has_value;
    if (zT_148) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    cv = cval.value;
    zT_150 = cv.kind;
    if ((unsigned char)(zT_150 == (unsigned char)(1))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_153 = &ctx->comptime_folds;
    zT_154 = node.child_0;
    zT_155 = cv;
    zF_376429F5_comptimeFoldTablePu(zT_153, zT_154, zT_155);
    goto z_bb_52;
    z_bb_52:
    goto z_bb_50;
}

/* phase_SemanticAnalysis */
void zF_0666ED4F_phase_SemanticAnaly(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_6DCFC8DB_FrontResCtx zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_D3EB6303_StringInterner* zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    zT_69057089_CompilerAlloc* zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_66E7D2EF_CoercionTable* zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    zT_21D3708C_U32ToU32Map* zT_22;
    zT_21D3708C_U32ToU32Map* zT_23;
    zT_21D3708C_U32ToU32Map* zT_24;
    zT_21D3708C_U32ToU32Map* zT_25;
    zT_A4CE86B7_U64ToU32Map* zT_26;
    zT_072B53A6_ModuleRegistry* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_30 = {0};
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_69057089_CompilerAlloc* zT_38;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    unsigned int zT_43;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_60 = 0;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    zT_6E8D187B_ModuleEntry* zT_72;
    zT_6E8D187B_ModuleEntry zT_73;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_76;
    zT_8EED1867_ResolvedTypeTable* zT_77;
    zT_F85C5DED_DiagnosticCollector* zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_3D7259E2_SymbolRegistry* zT_80;
    zT_6B0A7D14_AstStore* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_66E7D2EF_CoercionTable* zT_84;
    zT_21D3708C_U32ToU32Map* zT_85;
    zT_21D3708C_U32ToU32Map* zT_86;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_D3EB6303_StringInterner* zT_88;
    zT_21D3708C_U32ToU32Map* zT_89;
    zT_21D3708C_U32ToU32Map* zT_90;
    zT_072B53A6_ModuleRegistry* zT_91;
    zT_A4CE86B7_U64ToU32Map* zT_92;
    zT_69057089_CompilerAlloc* zT_93;
    zT_6E8D187B_ModuleEntry* zT_100;
    zT_6E8D187B_ModuleEntry zT_101;
    zT_38C12417_SemanticAnalyzer zT_112 = {0};
    zT_77F6F59C_ComptimeFoldTable* zT_113;
    zT_F3A81A9C_Opt_326 zT_114;
    int zT_116;
    unsigned int zT_117;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_126 = 0;
    zT_6B0A7D14_AstStore* zT_128;
    unsigned int zT_129;
    zT_22A7C88B_AstNode zT_131 = {0};
    unsigned char* zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8143F551_AstKind zT_137;
    unsigned int zT_141;
    int zT_142;
    zT_6DCFC8DB_FrontResCtx* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_148;
    zT_6E8D187B_ModuleEntry* zT_150;
    zT_6E8D187B_ModuleEntry zT_151;
    zT_6E8D187B_ModuleEntry* zT_155;
    zT_6E8D187B_ModuleEntry zT_156;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    zT_38C12417_SemanticAnalyzer* zT_163;
    unsigned int zT_164;
    unsigned char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    zT_8143F551_AstKind zT_171;
    unsigned char zT_175;
    unsigned int zT_176;
    zT_6B0A7D14_AstStore* zT_180;
    unsigned int zT_181;
    zT_22A7C88B_AstNode zT_184 = {0};
    zT_8143F551_AstKind zT_185;
    zT_38C12417_SemanticAnalyzer* zT_189;
    unsigned int zT_190;
    zT_8143F551_AstKind zT_192;
    unsigned char zT_196;
    unsigned char zT_197;
    zT_38C12417_SemanticAnalyzer* zT_202;
    unsigned int zT_203;
    zT_8143F551_AstKind zT_205;
    zT_38C12417_SemanticAnalyzer* zT_209;
    unsigned int zT_210;
    zT_8143F551_AstKind zT_212;
    zT_38C12417_SemanticAnalyzer* zT_216;
    unsigned int zT_217;
    int zT_219;
    unsigned int zT_221;
    int zT_222;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mz;
    unsigned int decls_n;
    zT_8F083A69_Slice_zT_0B42B2F8_u ad;
    zT_8F083A69_Slice_zT_0B42B2F8_u dse_m;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa0;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa1;
    zT_22A7C88B_AstNode di_inn;
    zT_2 = "RS";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    rs = zT_3;
    zT_5 = rs;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->store;
    zT_10.store = zT_11;
    zT_12 = ctx->typereg;
    zT_10.typereg = zT_12;
    zT_13 = ctx->symbol_reg;
    zT_10.symbol_reg = zT_13;
    zT_14 = ctx->resolved_types;
    zT_10.resolved_types = zT_14;
    zT_15 = ctx->module_reg;
    zT_10.module_reg = zT_15;
    zT_16 = ctx->interner;
    zT_10.interner = zT_16;
    zT_17 = ctx->diag;
    zT_10.diag = zT_17;
    zT_18 = ctx->alloc;
    zT_19 = &zT_18->scratch;
    zT_10.scratch = zT_19;
    zT_20 = ctx->coercion_table;
    zT_10.coercion_table = zT_20;
    zT_21 = &ctx->enum_value_table;
    zT_10.enum_value_table = zT_21;
    zT_22 = &ctx->tuple_index_table;
    zT_10.tuple_index_table = zT_22;
    zT_23 = &ctx->error_code_registry;
    zT_10.error_code_registry = zT_23;
    zT_24 = &ctx->call_arg_types;
    zT_10.call_arg_types = zT_24;
    zT_25 = &ctx->call_param_map;
    zT_10.call_param_map = zT_25;
    zT_26 = &ctx->suspending_fns;
    zT_10.suspending_fns = zT_26;
    frc = zT_10;
    zT_28 = ctx->module_reg;
    zT_30 = zF_3452C137_moduleRegistryGetMo(zT_28);
    mods = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    mi = zT_33;
    goto z_bb_1;
    z_bb_1:
    zT_35 = mods.len;
    if ((unsigned char)(mi < zT_35)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_38 = ctx->alloc;
    zT_37 = &zT_38->scratch;
    zF_F1B3F8C2_sandReset(zT_37);
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_43 = zT_42.ast_root;
    ast_root = zT_43;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_222 = 1;
    zT_224 = mi + (unsigned int)((unsigned int)zT_222);
    mi = zT_224;
    goto z_bb_1;
    z_bb_5:
    zT_47 = "MZ";
    zT_49 = 2;
    zT_48.ptr = (unsigned char*)zT_47;
    zT_48.len = zT_49;
    mz = zT_48;
    zT_50 = mz;
    zF_48AC7B3A_markerWrite(zT_50);
    goto z_bb_4;
    z_bb_6:
    zT_52 = ctx->store;
    zT_53 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_52, zT_53);
    zT_57 = ctx->store;
    zT_58 = ast_root;
    zT_60 = zF_152E19CB_astStoreNodeExtraCh(zT_57, zT_58);
    decls_n = zT_60;
    zT_62 = "AD";
    zT_64 = 2;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    ad = zT_63;
    zT_65 = ad;
    zF_48AC7B3A_markerWrite(zT_65);
    zT_67 = "DSE\n";
    zT_69 = 4;
    zT_68.ptr = (unsigned char*)zT_67;
    zT_68.len = zT_69;
    dse_m = zT_68;
    zT_70 = dse_m;
    zF_48AC7B3A_markerWrite(zT_70);
    zT_72 = mods.ptr;
    zT_73 = zT_72[mi];
    zT_74 = zT_73.source_file_id;
    src_fid = zT_74;
    zT_93 = ctx->alloc;
    zT_76 = &zT_93->scratch;
    zT_77 = ctx->resolved_types;
    zT_78 = ctx->diag;
    zT_79 = ctx->typereg;
    zT_80 = ctx->symbol_reg;
    zT_81 = ctx->store;
    zT_100 = mods.ptr;
    zT_101 = zT_100[mi];
    zT_82 = zT_101.id;
    zT_83 = src_fid;
    zT_84 = ctx->coercion_table;
    zT_85 = &ctx->enum_value_table;
    zT_86 = &ctx->tuple_index_table;
    zT_87 = &ctx->error_code_registry;
    zT_88 = ctx->interner;
    zT_89 = &ctx->call_arg_types;
    zT_90 = &ctx->call_param_map;
    zT_91 = ctx->module_reg;
    zT_92 = &ctx->suspending_fns;
    zT_112 = zF_84ADA681_semanticAnalyzerIni(zT_76, zT_77, zT_78, zT_79, zT_80, zT_81, zT_82, zT_83, zT_84, zT_85, zT_86, zT_87, zT_88, zT_89, zT_90, zT_91, zT_92);
    sa = zT_112;
    zT_113 = &ctx->comptime_folds;
    zT_114.has_value = 1;
    zT_114.value = zT_113;
    sa.comptime_folds = zT_114;
    zT_116 = 0;
    zT_117 = (unsigned int)zT_116;
    di = zT_117;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_121 = ctx->store;
    zT_122 = ast_root;
    zT_126 = zF_B10B1BC1_astStoreNodeExtraCh(zT_121, zT_122, (unsigned int)((unsigned int)di));
    decl_idx = zT_126;
    zT_128 = ctx->store;
    zT_129 = decl_idx;
    zT_131 = zF_FCDD1D35_astStoreNodeAt(zT_128, zT_129);
    decl = zT_131;
    zT_133 = "DN";
    zT_135 = 2;
    zT_134.ptr = (unsigned char*)zT_133;
    zT_134.len = zT_135;
    dn = zT_134;
    zT_136 = dn;
    zF_48AC7B3A_markerWrite(zT_136);
    zT_137 = decl.kind;
    if ((unsigned char)(zT_137 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_219 = 1;
    zT_221 = di + (unsigned int)((unsigned int)zT_219);
    di = zT_221;
    goto z_bb_7;
    z_bb_11:
    zT_141 = decl.child_0;
    zT_142 = 0;
    if ((unsigned char)(zT_141 != (unsigned int)zT_142)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_171 = decl.kind;
    if ((unsigned char)(zT_171 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_144 = (zT_6DCFC8DB_FrontResCtx*)&frc;
    zT_150 = mods.ptr;
    zT_151 = zT_150[mi];
    zT_145 = zT_151.id;
    zT_146 = decl.child_0;
    zT_155 = mods.ptr;
    zT_156 = zT_155[mi];
    zT_148 = zT_156.source_file_id;
    zF_783226DA_resolveStmtTypes(zT_144, zT_145, zT_146, (unsigned int)(0), zT_148);
    goto z_bb_15;
    z_bb_15:
    zT_159 = "SA";
    zT_161 = 2;
    zT_160.ptr = (unsigned char*)zT_159;
    zT_160.len = zT_161;
    sa0 = zT_160;
    zT_162 = sa0;
    zF_48AC7B3A_markerWrite(zT_162);
    zT_163 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_164 = decl_idx;
    zF_406A2501_semanticAnalyzerRes(zT_163, zT_164);
    zT_167 = "sA";
    zT_169 = 2;
    zT_168.ptr = (unsigned char*)zT_167;
    zT_168.len = zT_169;
    sa1 = zT_168;
    zT_170 = sa1;
    zF_48AC7B3A_markerWrite(zT_170);
    goto z_bb_12;
    z_bb_16:
    zT_176 = decl.child_1;
    zT_175 = zT_176 != (unsigned int)(0);
    goto z_bb_18;
    z_bb_17:
    zT_175 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_175) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_180 = ctx->store;
    zT_181 = decl.child_1;
    zT_184 = zF_FCDD1D35_astStoreNodeAt(zT_180, zT_181);
    di_inn = zT_184;
    zT_185 = di_inn.kind;
    if ((unsigned char)(zT_185 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_212 = decl.kind;
    if ((unsigned char)(zT_212 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_31; else goto z_bb_32;
    z_bb_22:
    zT_189 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_190 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_189, zT_190);
    goto z_bb_23;
    z_bb_23:
    zT_192 = di_inn.kind;
    if ((unsigned char)(zT_192 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_197 = di_inn.flags;
    zT_196 = (unsigned char)(zT_197 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_196 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_196) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_202 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_203 = decl_idx;
    zF_6A91A8CC_semanticAnalyzerGat(zT_202, zT_203);
    goto z_bb_28;
    z_bb_28:
    zT_205 = di_inn.kind;
    if ((unsigned char)(zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_209 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_210 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_209, zT_210);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_20;
    z_bb_31:
    zT_216 = (zT_38C12417_SemanticAnalyzer*)&sa;
    zT_217 = decl_idx;
    zF_4E74AE9D_semanticAnalyzerGat(zT_216, zT_217);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_20;
}

/* phase_StaticAnalyzers */
void zF_F3B55B42_phase_StaticAnalyze(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_C98AF326_CompilerCli zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    zT_C98AF326_CompilerCli zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    zT_C98AF326_CompilerCli zT_22;
    unsigned char zT_23;
    zT_072B53A6_ModuleRegistry* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29 = {0};
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_69057089_CompilerAlloc* zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_46;
    zT_060CD1EB_SymbolTable* zT_50 = 0;
    zT_7E2F335A_AnalyzerContext zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    zT_69057089_CompilerAlloc* zT_57;
    zT_3E40CD83_Sand* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_69057089_CompilerAlloc* zT_63;
    zT_3E40CD83_Sand* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_C98AF326_CompilerCli zT_67;
    unsigned char zT_68;
    unsigned char zT_69;
    int zT_70;
    int zT_72;
    unsigned char zT_74;
    zT_C98AF326_CompilerCli zT_75;
    unsigned char zT_76;
    unsigned char zT_77;
    int zT_78;
    int zT_80;
    unsigned char zT_82;
    zT_C98AF326_CompilerCli zT_83;
    unsigned char zT_84;
    unsigned char zT_85;
    int zT_86;
    int zT_88;
    unsigned char zT_90;
    zT_C98AF326_CompilerCli zT_91;
    unsigned char zT_92;
    unsigned char zT_93;
    int zT_94;
    int zT_96;
    unsigned char zT_98;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    unsigned char zT_102;
    zT_6E8D187B_ModuleEntry* zT_103;
    zT_6E8D187B_ModuleEntry zT_104;
    unsigned int zT_105;
    zT_7E2F335A_AnalyzerContext* zT_106;
    unsigned int zT_107;
    zT_227EDE07_SourceManager* zT_109;
    int zT_111;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_060CD1EB_SymbolTable* sym_table;
    zT_7E2F335A_AnalyzerContext ac;
    zT_2 = "A\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = ctx->alloc;
    zT_9 = &zT_10->scratch;
    zF_CB5A85E9_sandResetPeak(zT_9);
    zT_12 = ctx->cli;
    zT_13 = zT_12.no_null_check;
    if ((unsigned char)(zT_13 != (unsigned char)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_17 = ctx->cli;
    zT_18 = zT_17.no_lifetime_check;
    zT_16 = zT_18 != (unsigned char)(1);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = ctx->cli;
    zT_23 = zT_22.no_leak_check;
    zT_21 = zT_23 != (unsigned char)(1);
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = ctx->module_reg;
    zT_29 = zF_3452C137_moduleRegistryGetMo(zT_27);
    mods = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    mi = zT_32;
    goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    zT_34 = mods.len;
    if ((unsigned char)(mi < zT_34)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = ctx->alloc;
    zT_36 = &zT_37->scratch;
    zF_F1B3F8C2_sandReset(zT_36);
    zT_40 = mods.ptr;
    zT_41 = zT_40[mi];
    zT_42 = zT_41.ast_root;
    ast_root = zT_42;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_111 = 1;
    zT_113 = mi + (unsigned int)((unsigned int)zT_111);
    mi = zT_113;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_46 = ctx->symbol_reg;
    zT_50 = zF_9B36C202_symbolRegistryGetTa(zT_46, (unsigned int)((unsigned int)mi));
    sym_table = zT_50;
    zT_53 = ctx->store;
    zT_52.store = zT_53;
    zT_54 = ctx->typereg;
    zT_52.registry = zT_54;
    zT_55 = ctx->interner;
    zT_52.interner = zT_55;
    zT_56 = ctx->diag;
    zT_52.diag = zT_56;
    zT_52.symbols = sym_table;
    zT_57 = ctx->alloc;
    zT_58 = &zT_57->scratch;
    zT_52.alloc = zT_58;
    zT_59 = 0;
    zT_52.current_fn_name = zT_59;
    zT_60 = 0;
    zT_52.defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_60;
    zT_61 = 0;
    zT_52.defer_queue_len = zT_61;
    zT_62 = 0;
    zT_52.defer_queue_cap = zT_62;
    zT_63 = ctx->alloc;
    zT_64 = &zT_63->scratch;
    zT_52.defer_queue_alloc = zT_64;
    zT_65 = 0;
    zT_52.current_depth = zT_65;
    zT_66 = 0;
    zT_52.null_analysis_mode = zT_66;
    zT_67 = ctx->cli;
    zT_68 = zT_67.no_null_check;
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_70 = 1;
    zT_69 = (unsigned char)zT_70;
    goto z_bb_17;
    z_bb_16:
    zT_72 = 0;
    zT_69 = (unsigned char)zT_72;
    goto z_bb_17;
    z_bb_17:
    zT_74 = (unsigned char)zT_69;
    zT_52.skip_null_check = zT_74;
    zT_75 = ctx->cli;
    zT_76 = zT_75.no_lifetime_check;
    if (zT_76) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_78 = 1;
    zT_77 = (unsigned char)zT_78;
    goto z_bb_20;
    z_bb_19:
    zT_80 = 0;
    zT_77 = (unsigned char)zT_80;
    goto z_bb_20;
    z_bb_20:
    zT_82 = (unsigned char)zT_77;
    zT_52.skip_lifetime_check = zT_82;
    zT_83 = ctx->cli;
    zT_84 = zT_83.no_leak_check;
    if (zT_84) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_86 = 1;
    zT_85 = (unsigned char)zT_86;
    goto z_bb_23;
    z_bb_22:
    zT_88 = 0;
    zT_85 = (unsigned char)zT_88;
    goto z_bb_23;
    z_bb_23:
    zT_90 = (unsigned char)zT_85;
    zT_52.skip_doublefree_check = zT_90;
    zT_91 = ctx->cli;
    zT_92 = zT_91.warn_all;
    if (zT_92) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_94 = 1;
    zT_93 = (unsigned char)zT_94;
    goto z_bb_26;
    z_bb_25:
    zT_96 = 0;
    zT_93 = (unsigned char)zT_96;
    goto z_bb_26;
    z_bb_26:
    zT_98 = (unsigned char)zT_93;
    zT_52.warn_all = zT_98;
    zT_99 = zF_43C99FB3_onNullStmt;
    zT_52.on_stmt_cb = zT_99;
    zT_100 = 0;
    zT_52.in_defer_exec = zT_100;
    zT_101 = 0;
    zT_52.lifetime_analysis_mode = zT_101;
    zT_102 = 0;
    zT_52.doublefree_analysis_mode = zT_102;
    zT_103 = mods.ptr;
    zT_104 = zT_103[mi];
    zT_105 = zT_104.source_file_id;
    zT_52.source_file_id = zT_105;
    ac = zT_52;
    zT_106 = (zT_7E2F335A_AnalyzerContext*)&ac;
    zT_107 = ast_root;
    zF_F697813C_runAllAnalyzers(zT_106, zT_107);
    zT_109 = ctx->source_man;
    zF_196FDF3B_sourceManagerResetF(zT_109);
    goto z_bb_12;
}

/* phase_AsyncFrameSize */
void zF_9BC6214D_phase_AsyncFrameSiz(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_3D7259E2_SymbolRegistry* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_072B53A6_ModuleRegistry* zT_10;
    zT_338B7C76_TypeRegistry* zT_11;
    zT_8EED1867_ResolvedTypeTable* zT_12;
    zT_A4CE86B7_U64ToU32Map* zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_A4CE86B7_U64ToU32Map* zT_15;
    zT_A4CE86B7_U64ToU32Map* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_B687BB96_U32ArrayList* zT_19;
    zT_A4CE86B7_U64ToU32Map* zT_20;
    zT_A4CE86B7_U64ToU32Map* zT_21;
    zT_69057089_CompilerAlloc* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_2 = "AFS\n";
    zT_4 = 4;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_22 = ctx->alloc;
    zT_6 = &zT_22->module;
    zT_7 = ctx->store;
    zT_8 = ctx->symbol_reg;
    zT_9 = ctx->interner;
    zT_10 = ctx->module_reg;
    zT_11 = ctx->typereg;
    zT_12 = ctx->resolved_types;
    zT_13 = &ctx->suspending_fns;
    zT_14 = &ctx->frame_sizes;
    zT_15 = &ctx->state_widths;
    zT_16 = &ctx->awaited_fns;
    zT_17 = &ctx->async_hidden_fns;
    zT_18 = &ctx->driver_targets;
    zT_19 = &ctx->parent_result_type_list;
    zT_20 = &ctx->parent_result_start;
    zT_21 = &ctx->parent_result_count;
    zF_7DBA21B2_asyncFrameSizeRun(zT_6, zT_7, zT_8, zT_9, zT_10, zT_11, zT_12, zT_13, zT_14, zT_15, zT_16, zT_17, zT_18, zT_19, zT_20, zT_21);
    return;
}

/* phase_ConstInit */
void zF_A6065296_phase_ConstInit(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15 = {0};
    zT_C98AF326_CompilerCli zT_16;
    unsigned char zT_17;
    zT_F85C5DED_DiagnosticCollector* zT_18;
    zT_6B306B38_Opt_241 zT_19;
    zT_4D150975_ConstInitEvalCtx zT_21;
    zT_4065182A_ConstInitTable* zT_22;
    zT_6B0A7D14_AstStore* zT_23;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_8EED1867_ResolvedTypeTable* zT_26;
    zT_DA663F79_ComptimeEval* zT_27;
    zT_21D3708C_U32ToU32Map* zT_28;
    zT_072B53A6_ModuleRegistry* zT_29;
    zT_072B53A6_ModuleRegistry* zT_31;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_33 = {0};
    unsigned int zT_35;
    unsigned int zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    zT_6E8D187B_ModuleEntry* zT_45;
    zT_6E8D187B_ModuleEntry zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    unsigned int zT_52 = 0;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    unsigned int zT_63 = 0;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_68 = {0};
    zT_8143F551_AstKind zT_69;
    unsigned char zT_73;
    unsigned char zT_79;
    unsigned int zT_85;
    zT_4D150975_ConstInitEvalCtx* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_6E8D187B_ModuleEntry* zT_92;
    zT_6E8D187B_ModuleEntry zT_93;
    zT_BAEE192E_Opt_10 zT_95 = {0};
    unsigned int zT_97;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u ci_m;
    zT_DA663F79_ComptimeEval ci_ce;
    zT_4D150975_ConstInitEvalCtx cic;
    zT_DDCD424B_Slice_zT_6E8D187B_M cmods;
    unsigned int cmi;
    unsigned int croot;
    unsigned int cdn;
    unsigned int cdi;
    unsigned int cdecl_idx;
    zT_22A7C88B_AstNode cdecl;
    zT_2 = "CIE\n";
    zT_4 = 4;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    ci_m = zT_3;
    zT_5 = ci_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ci_ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ci_ce.host_is_windows = zT_17;
    zT_18 = ctx->diag;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    ci_ce.diag = zT_19;
    zT_22 = &ctx->const_inits;
    zT_21.tbl = zT_22;
    zT_23 = ctx->store;
    zT_21.store = zT_23;
    zT_24 = ctx->typereg;
    zT_21.registry = zT_24;
    zT_25 = ctx->symbol_reg;
    zT_21.symbol_reg = zT_25;
    zT_26 = ctx->resolved_types;
    zT_21.resolved = zT_26;
    zT_27 = (zT_DA663F79_ComptimeEval*)&ci_ce;
    zT_21.ce = zT_27;
    zT_28 = &ctx->enum_value_table;
    zT_21.enum_values = zT_28;
    zT_29 = ctx->module_reg;
    zT_21.module_reg = zT_29;
    cic = zT_21;
    zT_31 = ctx->module_reg;
    zT_33 = zF_3452C137_moduleRegistryGetMo(zT_31);
    cmods = zT_33;
    zT_35 = 0;
    cmi = zT_35;
    goto z_bb_1;
    z_bb_1:
    zT_37 = cmods.len;
    if ((unsigned char)(cmi < zT_37)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_40 = cmods.ptr;
    zT_41 = zT_40[cmi];
    zT_42 = zT_41.ast_root;
    croot = zT_42;
    if ((unsigned char)(croot == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_99 = cmi + (unsigned int)(1);
    cmi = zT_99;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_45 = cmods.ptr;
    zT_46 = zT_45[cmi];
    zT_47 = zT_46.id;
    ci_ce.module_id = zT_47;
    zT_49 = ctx->store;
    zT_50 = croot;
    zT_52 = zF_152E19CB_astStoreNodeExtraCh(zT_49, zT_50);
    cdn = zT_52;
    zT_54 = 0;
    cdi = zT_54;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(cdi < (unsigned int)((unsigned int)cdn))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_58 = ctx->store;
    zT_59 = croot;
    zT_63 = zF_B10B1BC1_astStoreNodeExtraCh(zT_58, zT_59, (unsigned int)((unsigned int)cdi));
    cdecl_idx = zT_63;
    zT_65 = ctx->store;
    zT_66 = cdecl_idx;
    zT_68 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    cdecl = zT_68;
    zT_69 = cdecl.kind;
    if ((unsigned char)(zT_69 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_97 = cdi + (unsigned int)(1);
    cdi = zT_97;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_73 = cdecl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_73) & (unsigned short)(4)) != (unsigned short)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_79 = cdecl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_79) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_85 = cdecl.child_1;
    if ((unsigned char)(zT_85 == (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_88 = (zT_4D150975_ConstInitEvalCtx*)&cic;
    zT_92 = cmods.ptr;
    zT_93 = zT_92[cmi];
    zT_89 = zT_93.id;
    zT_90 = cdecl_idx;
    zT_95 = zF_2B750645_constInitEvaluate(zT_88, zT_89, zT_90);
    (void)zT_95;
    goto z_bb_10;
}

/* phase_LIRLowering */
void zF_1F21ABE7_phase_LIRLowering(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_4028D896_Arr_unsigned_char_2 zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_D1EDC242_anon_279761 zT_17;
    unsigned int zT_18;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_4028D896_Arr_unsigned_char_2 zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    zT_01BE9D46_AstValuePool zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_69057089_CompilerAlloc* zT_76;
    zT_CA01C129_LirSlotArrayList* zT_79;
    zT_846744CC_Arr_unsigned_char_5 zT_81;
    unsigned int zT_83;
    zT_C98AF326_CompilerCli zT_84;
    unsigned char zT_85;
    zT_C98AF326_CompilerCli zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    unsigned char zT_94;
    unsigned char* zT_97;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned char zT_103;
    unsigned int zT_105;
    unsigned char zT_106;
    unsigned int zT_108;
    unsigned char zT_109;
    unsigned int zT_111;
    unsigned char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    unsigned int zT_119;
    unsigned char zT_121;
    unsigned char* zT_124;
    unsigned char zT_125;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_7E7544E4_LirStream* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    zT_3E40CD83_Sand* zT_132;
    int zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    zT_69057089_CompilerAlloc* zT_140;
    zT_6B356268_SemanticContext zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_3D7259E2_SymbolRegistry* zT_146;
    zT_8EED1867_ResolvedTypeTable* zT_147;
    zT_66E7D2EF_CoercionTable* zT_148;
    zT_F85C5DED_DiagnosticCollector* zT_149;
    unsigned char zT_150;
    zT_21D3708C_U32ToU32Map* zT_151;
    zT_21D3708C_U32ToU32Map* zT_152;
    zT_21D3708C_U32ToU32Map* zT_153;
    zT_21D3708C_U32ToU32Map* zT_154;
    zT_77F6F59C_ComptimeFoldTable* zT_155;
    zT_4065182A_ConstInitTable* zT_156;
    unsigned int zT_157;
    zT_C98AF326_CompilerCli zT_158;
    unsigned char zT_159;
    zT_A4CE86B7_U64ToU32Map* zT_160;
    zT_A4CE86B7_U64ToU32Map* zT_161;
    zT_A4CE86B7_U64ToU32Map* zT_162;
    unsigned char zT_163;
    zT_072B53A6_ModuleRegistry* zT_165;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_167 = {0};
    zT_3E40CD83_Sand* zT_169;
    zT_69057089_CompilerAlloc* zT_170;
    zT_B687BB96_U32ArrayList zT_172 = {0};
    unsigned char zT_174;
    int zT_176;
    unsigned int zT_177;
    unsigned int zT_179;
    zT_6E8D187B_ModuleEntry* zT_181;
    zT_6E8D187B_ModuleEntry zT_182;
    unsigned int zT_183;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    zT_4028D896_Arr_unsigned_char_2 zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    int zT_197;
    unsigned char* zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201 = 0;
    unsigned int zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned char* zT_210;
    unsigned int zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned char* zT_214;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    zT_6E8D187B_ModuleEntry* zT_218;
    zT_6E8D187B_ModuleEntry zT_219;
    unsigned int zT_220;
    zT_4028D896_Arr_unsigned_char_2 zT_224;
    unsigned int zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    zT_6E8D187B_ModuleEntry* zT_228;
    zT_6E8D187B_ModuleEntry zT_229;
    int zT_233;
    unsigned char* zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned int zT_237 = 0;
    unsigned int zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned char* zT_246;
    unsigned int zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_249;
    zT_6B0A7D14_AstStore* zT_251;
    unsigned int zT_252;
    zT_6E8D187B_ModuleEntry* zT_254;
    zT_6E8D187B_ModuleEntry zT_255;
    zT_22A7C88B_AstNode zT_257 = {0};
    zT_8143F551_AstKind zT_258;
    unsigned char* zT_263;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_264;
    unsigned int zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    zT_6B0A7D14_AstStore* zT_268;
    unsigned int zT_269;
    zT_6E8D187B_ModuleEntry* zT_271;
    zT_6E8D187B_ModuleEntry zT_272;
    unsigned int zT_274 = 0;
    unsigned int zT_276;
    zT_4028D896_Arr_unsigned_char_2 zT_278;
    unsigned int zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    int zT_284;
    unsigned char* zT_285;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    unsigned int zT_288 = 0;
    unsigned int zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    unsigned char* zT_297;
    unsigned int zT_298;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_300;
    zT_6B0A7D14_AstStore* zT_301;
    unsigned int zT_302;
    zT_B687BB96_U32ArrayList* zT_303;
    zT_6E8D187B_ModuleEntry* zT_305;
    zT_6E8D187B_ModuleEntry zT_306;
    zT_6E8D187B_ModuleEntry* zT_308;
    zT_6E8D187B_ModuleEntry* zT_309;
    unsigned char zT_312;
    unsigned int zT_314;
    zT_6B0A7D14_AstStore* zT_318;
    unsigned int zT_319;
    zT_6E8D187B_ModuleEntry* zT_322;
    zT_6E8D187B_ModuleEntry zT_323;
    unsigned int zT_326 = 0;
    zT_6B0A7D14_AstStore* zT_328;
    unsigned int zT_329;
    zT_22A7C88B_AstNode zT_331 = {0};
    zT_8143F551_AstKind zT_333;
    unsigned int zT_334;
    zT_4028D896_Arr_unsigned_char_2 zT_336;
    unsigned int zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    int zT_342;
    unsigned char* zT_343;
    unsigned int zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_345;
    unsigned int zT_346 = 0;
    unsigned int zT_350;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_351;
    unsigned char* zT_355;
    unsigned int zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned char* zT_359;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    unsigned int zT_361;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_362;
    zT_8143F551_AstKind zT_363;
    unsigned char* zT_368;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_369;
    unsigned int zT_370;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    unsigned char zT_372;
    zT_6B0A7D14_AstStore* zT_379;
    zT_CCD1E3E6_anon_279794 zT_380;
    zT_243D6A41_FnProto* zT_381;
    zT_6B0A7D14_AstStore* zT_382;
    unsigned int zT_383;
    unsigned int zT_385 = 0;
    unsigned int zT_386;
    zT_243D6A41_FnProto zT_387;
    zT_6E8D187B_ModuleEntry* zT_389;
    zT_6E8D187B_ModuleEntry zT_390;
    unsigned int zT_391;
    unsigned int zT_399;
    zT_79FAE712_u64 zT_401;
    zT_A4CE86B7_U64ToU32Map* zT_402;
    zT_79FAE712_u64 zT_403;
    zT_6B356268_SemanticContext* zT_408;
    zT_3E40CD83_Sand* zT_409;
    zT_69057089_CompilerAlloc* zT_411;
    zT_02EB57B2_LirLowerer zT_413 = {0};
    zT_6E8D187B_ModuleEntry* zT_414;
    zT_6E8D187B_ModuleEntry zT_415;
    unsigned int zT_416;
    zT_072B53A6_ModuleRegistry* zT_417;
    zT_02EB57B2_LirLowerer* zT_419;
    unsigned int zT_420;
    zT_BBC23664_LirFunction zT_422 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_423;
    unsigned int zT_424;
    unsigned int zT_425;
    unsigned char zT_429 = 0;
    zT_3E40CD83_Sand* zT_431;
    zT_338B7C76_TypeRegistry* zT_432;
    zT_BBC23664_LirFunction* zT_433;
    zT_A4CE86B7_U64ToU32Map* zT_434;
    zT_A4CE86B7_U64ToU32Map* zT_435;
    zT_A4CE86B7_U64ToU32Map* zT_436;
    zT_A4CE86B7_U64ToU32Map* zT_437;
    zT_A4CE86B7_U64ToU32Map* zT_438;
    zT_A4CE86B7_U64ToU32Map* zT_439;
    zT_B687BB96_U32ArrayList* zT_440;
    zT_A4CE86B7_U64ToU32Map* zT_441;
    zT_A4CE86B7_U64ToU32Map* zT_442;
    zT_69057089_CompilerAlloc* zT_443;
    zT_3F3BF87A_AsyncFrameLayout zT_456 = {0};
    zT_3E40CD83_Sand* zT_457;
    zT_A4CE86B7_U64ToU32Map* zT_458;
    unsigned int zT_459;
    unsigned int zT_460;
    zT_3F3BF87A_AsyncFrameLayout zT_461;
    zT_69057089_CompilerAlloc* zT_462;
    zT_3E40CD83_Sand* zT_468;
    zT_69057089_CompilerAlloc* zT_471;
    zT_38349D67_EU_052 zT_475 = {0};
    unsigned char zT_476;
    unsigned char* zT_477;
    zT_BBC23664_LirFunction* zT_480;
    zT_B687BB96_U32ArrayList* zT_481;
    unsigned char zT_486;
    zT_7E7544E4_LirStream* zT_488;
    zT_BBC23664_LirFunction zT_489;
    zT_E7714190_LirSlot zT_491 = {0};
    zT_CA01C129_LirSlotArrayList* zT_492;
    zT_E7714190_LirSlot zT_493;
    zT_3E40CD83_Sand* zT_496;
    zT_69057089_CompilerAlloc* zT_497;
    zT_8143F551_AstKind zT_499;
    unsigned char zT_503;
    zT_6B0A7D14_AstStore* zT_510;
    unsigned int zT_511;
    unsigned int zT_513 = 0;
    zT_3D7259E2_SymbolRegistry* zT_515;
    unsigned int zT_516;
    unsigned int zT_517;
    zT_6E8D187B_ModuleEntry* zT_519;
    zT_6E8D187B_ModuleEntry zT_520;
    zT_E9E89685_Opt_934 zT_522 = {0};
    unsigned char zT_523;
    zT_3C598AEF_SymbolKind zT_525;
    unsigned int zT_530;
    unsigned char zT_531;
    unsigned char zT_537;
    unsigned int zT_538;
    zT_6B0A7D14_AstStore* zT_542;
    unsigned int zT_543;
    zT_22A7C88B_AstNode zT_546 = {0};
    unsigned char zT_548;
    zT_8143F551_AstKind zT_549;
    unsigned char zT_553;
    zT_8143F551_AstKind zT_554;
    zT_6B0A7D14_AstStore* zT_559;
    unsigned int zT_560;
    zT_22A7C88B_AstNode zT_563 = {0};
    zT_8143F551_AstKind zT_564;
    unsigned char zT_568;
    zT_21D3708C_U32ToU32Map* zT_571;
    unsigned int zT_572;
    zT_4065182A_ConstInitTable* zT_573;
    zT_BAEE192E_Opt_10 zT_575 = {0};
    unsigned char zT_576;
    unsigned char zT_582;
    zT_6E8D187B_ModuleEntry* zT_589;
    zT_6E8D187B_ModuleEntry zT_590;
    unsigned int zT_591;
    zT_79FAE712_u64 zT_600;
    zT_A4CE86B7_U64ToU32Map* zT_601;
    zT_79FAE712_u64 zT_602;
    zT_8EED1867_ResolvedTypeTable* zT_607;
    unsigned int zT_608;
    zT_BAEE192E_Opt_10 zT_610 = {0};
    unsigned char zT_612;
    unsigned int zT_613;
    unsigned char zT_618;
    unsigned char zT_621;
    zT_4065182A_ConstInitTable* zT_625;
    unsigned int zT_626;
    zT_49DE1C22_ConstInitNode zT_628 = {0};
    unsigned char zT_629;
    unsigned char zT_632;
    unsigned char zT_633;
    unsigned int zT_636;
    unsigned int zT_637;
    unsigned int zT_642;
    zT_79FAE712_u64 zT_643;
    unsigned int zT_646;
    unsigned char zT_647;
    unsigned int zT_650;
    unsigned char zT_651;
    unsigned int zT_654;
    unsigned char zT_656;
    unsigned char zT_657;
    unsigned char zT_663;
    zT_E1A783EF_GlobalDeclArrayList* zT_664;
    zT_54906056_ModuleGlobalDecl zT_665;
    zT_54906056_ModuleGlobalDecl zT_667;
    zT_6E8D187B_ModuleEntry* zT_668;
    zT_6E8D187B_ModuleEntry zT_669;
    unsigned int zT_670;
    unsigned char zT_671;
    unsigned char zT_673;
    unsigned char zT_674;
    unsigned char zT_680;
    unsigned int zT_681;
    zT_6B0A7D14_AstStore* zT_685;
    unsigned int zT_686;
    zT_22A7C88B_AstNode zT_689 = {0};
    zT_8143F551_AstKind zT_690;
    unsigned char zT_694;
    zT_8143F551_AstKind zT_695;
    unsigned char zT_699;
    zT_8143F551_AstKind zT_700;
    unsigned char zT_704;
    unsigned int zT_707;
    zT_6B0A7D14_AstStore* zT_711;
    unsigned int zT_712;
    zT_22A7C88B_AstNode zT_715 = {0};
    zT_8143F551_AstKind zT_716;
    unsigned char zT_720;
    zT_8143F551_AstKind zT_721;
    zT_6B0A7D14_AstStore* zT_726;
    unsigned int zT_727;
    zT_22A7C88B_AstNode zT_730 = {0};
    zT_8143F551_AstKind zT_731;
    unsigned char zT_735;
    unsigned char zT_738;
    zT_6E8D187B_ModuleEntry* zT_745;
    zT_6E8D187B_ModuleEntry zT_746;
    unsigned int zT_747;
    zT_79FAE712_u64 zT_756;
    zT_A4CE86B7_U64ToU32Map* zT_757;
    zT_79FAE712_u64 zT_758;
    unsigned char zT_763;
    unsigned int zT_764;
    zT_6B0A7D14_AstStore* zT_768;
    unsigned int zT_769;
    zT_22A7C88B_AstNode zT_772 = {0};
    zT_8143F551_AstKind zT_773;
    unsigned char zT_777;
    unsigned char zT_780;
    zT_8EED1867_ResolvedTypeTable* zT_782;
    unsigned int zT_783;
    zT_BAEE192E_Opt_10 zT_785 = {0};
    unsigned char zT_787;
    unsigned int zT_788;
    unsigned char zT_792;
    unsigned char zT_793;
    unsigned char zT_799;
    zT_E1A783EF_GlobalDeclArrayList* zT_800;
    zT_54906056_ModuleGlobalDecl zT_801;
    zT_54906056_ModuleGlobalDecl zT_803;
    zT_6E8D187B_ModuleEntry* zT_804;
    zT_6E8D187B_ModuleEntry zT_805;
    unsigned int zT_806;
    unsigned int zT_807;
    unsigned int zT_809;
    zT_6B356268_SemanticContext* zT_813;
    zT_3E40CD83_Sand* zT_814;
    zT_69057089_CompilerAlloc* zT_816;
    zT_02EB57B2_LirLowerer zT_818 = {0};
    zT_6E8D187B_ModuleEntry* zT_819;
    zT_6E8D187B_ModuleEntry zT_820;
    unsigned int zT_821;
    zT_072B53A6_ModuleRegistry* zT_822;
    zT_02EB57B2_LirLowerer* zT_824;
    unsigned int zT_825;
    unsigned int zT_826;
    zT_A4CE86B7_U64ToU32Map* zT_827;
    zT_6E8D187B_ModuleEntry* zT_829;
    zT_6E8D187B_ModuleEntry zT_830;
    zT_6E8D187B_ModuleEntry* zT_832;
    zT_6E8D187B_ModuleEntry zT_833;
    zT_BBC23664_LirFunction zT_836 = {0};
    zT_7E7544E4_LirStream* zT_838;
    zT_BBC23664_LirFunction zT_839;
    zT_E7714190_LirSlot zT_841 = {0};
    zT_CA01C129_LirSlotArrayList* zT_842;
    zT_E7714190_LirSlot zT_843;
    zT_3E40CD83_Sand* zT_846;
    zT_69057089_CompilerAlloc* zT_847;
    zT_072B53A6_ModuleRegistry* zT_850;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_852 = {0};
    unsigned int zT_854;
    unsigned char zT_857;
    zT_6E8D187B_ModuleEntry* zT_858;
    int zT_859;
    zT_6E8D187B_ModuleEntry zT_860;
    unsigned int zT_861;
    zT_6B0A7D14_AstStore* zT_865;
    unsigned int zT_866;
    zT_6E8D187B_ModuleEntry* zT_868;
    int zT_869;
    zT_6E8D187B_ModuleEntry zT_870;
    zT_22A7C88B_AstNode zT_872 = {0};
    zT_8143F551_AstKind zT_873;
    zT_6B0A7D14_AstStore* zT_878;
    unsigned int zT_879;
    zT_6E8D187B_ModuleEntry* zT_881;
    int zT_882;
    zT_6E8D187B_ModuleEntry zT_883;
    unsigned int zT_885 = 0;
    unsigned int zT_887;
    unsigned char* zT_889;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_890;
    unsigned int zT_891;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_892;
    zT_6B0A7D14_AstStore* zT_896;
    unsigned int zT_897;
    zT_6B0A7D14_AstStore* zT_899;
    unsigned int zT_900;
    zT_6E8D187B_ModuleEntry* zT_903;
    int zT_904;
    zT_6E8D187B_ModuleEntry zT_905;
    unsigned int zT_908 = 0;
    zT_22A7C88B_AstNode zT_909 = {0};
    zT_8143F551_AstKind zT_911;
    unsigned int zT_912;
    zT_4028D896_Arr_unsigned_char_2 zT_914;
    unsigned int zT_916;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_917;
    int zT_920;
    unsigned char* zT_921;
    unsigned int zT_922;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_923;
    unsigned int zT_924 = 0;
    unsigned int zT_928;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_929;
    unsigned char* zT_933;
    unsigned int zT_934;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_935;
    unsigned char* zT_937;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_938;
    unsigned int zT_939;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_940;
    unsigned int zT_942;
    unsigned char* zT_944;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_945;
    unsigned int zT_946;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_947;
    int zT_948;
    unsigned int zT_950;
    unsigned int zT_952;
    unsigned int zT_953;
    unsigned int* zT_956;
    unsigned int zT_957;
    zT_BBC23664_LirFunction* zT_959;
    zT_A4CE86B7_U64ToU32Map* zT_960;
    unsigned int zT_961;
    unsigned int zT_962;
    zT_08D2D780_Opt_429 zT_966 = {0};
    unsigned char zT_967;
    zT_5839647A_AsyncTransformCtx zT_970;
    zT_69057089_CompilerAlloc* zT_971;
    zT_3E40CD83_Sand* zT_972;
    zT_338B7C76_TypeRegistry* zT_973;
    zT_D3EB6303_StringInterner* zT_974;
    zT_7E7544E4_LirStream* zT_975;
    zT_CA01C129_LirSlotArrayList* zT_976;
    zT_A4CE86B7_U64ToU32Map* zT_977;
    zT_C98AF326_CompilerCli zT_978;
    unsigned char zT_979;
    zT_A4CE86B7_U64ToU32Map* zT_980;
    zT_A4CE86B7_U64ToU32Map* zT_981;
    zT_F85C5DED_DiagnosticCollector* zT_982;
    zT_BBC23664_LirFunction* zT_983;
    zT_5839647A_AsyncTransformCtx* zT_984;
    unsigned char zT_986 = 0;
    unsigned int zT_988;
    zT_3E40CD83_Sand* zT_989;
    zT_69057089_CompilerAlloc* zT_990;
    zT_5AB29387_CompilerContext* zT_992;
    zT_7E7544E4_LirStream* zT_993;
    unsigned char zT_995;
    unsigned char* zT_999;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1000;
    unsigned int zT_1001;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_1002;
    zT_D3EB6303_StringInterner* zT_1003;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1004;
    zT_072B53A6_ModuleRegistry* zT_1005;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_1007 = {0};
    unsigned int zT_1009 = 0;
    unsigned char* zT_1013;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1014;
    unsigned int zT_1015;
    unsigned char* zT_1017;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1018;
    unsigned int zT_1019;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_1021;
    unsigned int zT_1022;
    unsigned int zT_1023;
    unsigned int zT_1024;
    zT_D3EB6303_StringInterner* zT_1026;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_1027;
    int zT_1030;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_1031;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1033 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_1034;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1040;
    unsigned int zT_1049 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnmsg;
    zT_4028D896_Arr_unsigned_char_2 ln_buf;
    unsigned int ln_len;
    unsigned int ln_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lemsg;
    zT_4028D896_Arr_unsigned_char_2 le_buf;
    unsigned int le_len;
    unsigned int le_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnl;
    zT_846744CC_Arr_unsigned_char_5 spill_path;
    unsigned int sp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmp_name;
    unsigned int ti;
    zT_6B356268_SemanticContext sem_ctx;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_B687BB96_U32ArrayList async_retained;
    unsigned char async_pending;
    unsigned int mi;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm;
    zT_4028D896_Arr_unsigned_char_2 mi_buf;
    unsigned int mi_len;
    unsigned int mi2_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u msep;
    unsigned int arl_i;
    zT_4028D896_Arr_unsigned_char_2 ar_buf;
    unsigned int ar_len;
    unsigned int ar_start;
    zT_22A7C88B_AstNode root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr;
    unsigned int decls_n;
    unsigned int decl_len;
    zT_4028D896_Arr_unsigned_char_2 dcount_buf;
    unsigned int dcount_len;
    unsigned int dstart;
    unsigned char mod_has_ri;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    unsigned int raw_k;
    zT_4028D896_Arr_unsigned_char_2 rbuf;
    unsigned int rlen;
    unsigned int rstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp2;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf;
    zT_243D6A41_FnProto fexp_proto;
    zT_79FAE712_u64 fexp_key;
    zT_02EB57B2_LirLowerer lowerer;
    zT_BBC23664_LirFunction lf;
    zT_3F3BF87A_AsyncFrameLayout async_layout;
    unsigned char* lf_raw;
    zT_E7714190_LirSlot slot;
    zT_BBC23664_LirFunction* lf_ptr;
    unsigned int gv_name;
    zT_E9E89685_Opt_934 gv_sym;
    zT_3A105EF1_Symbol* gvs;
    unsigned int gv_ctree;
    zT_22A7C88B_AstNode gv_i0;
    unsigned char gv_alias;
    zT_22A7C88B_AstNode gv_fb0;
    unsigned int croot;
    unsigned char gv_is_storage;
    zT_79FAE712_u64 gexp_key;
    zT_BAEE192E_Opt_10 gv_rt2;
    unsigned int gv_tid2;
    unsigned int grt2;
    zT_49DE1C22_ConstInitNode gv_rn;
    unsigned char gv_lv;
    zT_22A7C88B_AstNode gv_init;
    zT_22A7C88B_AstNode gv_init3;
    zT_22A7C88B_AstNode gv_fb;
    unsigned char gv_has_ri;
    zT_22A7C88B_AstNode gv_init2;
    zT_BAEE192E_Opt_10 gv_rt;
    unsigned int gv_tid;
    unsigned int grt;
    unsigned char gv_lv2;
    zT_02EB57B2_LirLowerer ilowerer;
    zT_BBC23664_LirFunction imf;
    zT_E7714190_LirSlot islot;
    zT_DDCD424B_Slice_zT_6E8D187B_M amods;
    zT_22A7C88B_AstNode ar;
    unsigned int adl_n;
    unsigned int adi;
    zT_8F083A69_Slice_zT_0B42B2F8_u al;
    zT_22A7C88B_AstNode ad;
    unsigned int ak;
    zT_4028D896_Arr_unsigned_char_2 ab;
    unsigned int alen;
    unsigned int ast;
    zT_8F083A69_Slice_zT_0B42B2F8_u asp;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_BBC23664_LirFunction* lf2;
    zT_3F3BF87A_AsyncFrameLayout* lay2;
    zT_5839647A_AsyncTransformCtx async_ctx2;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = "L\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = "nodes=";
    zT_9 = 6;
    zT_8.ptr = (unsigned char*)zT_7;
    zT_8.len = zT_9;
    lnmsg = zT_8;
    zT_10 = lnmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ln_buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_16 = ctx->store;
    zT_17 = zT_16->nodes;
    zT_18 = zT_17.len;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)ln_buf) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = (unsigned char*)zT_23;
    zT_25.len = zT_24;
    zT_15 = zT_25;
    zT_26 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_18), zT_15);
    ln_len = zT_26;
    zT_30 = (unsigned int)(19) - (unsigned int)((unsigned int)ln_len);
    ln_start = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)ln_buf) + ln_start;
    zT_36 = (unsigned int)(19) - ln_start;
    zT_37.ptr = (unsigned char*)zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = " extra=";
    zT_41 = 7;
    zT_40.ptr = (unsigned char*)zT_39;
    zT_40.len = zT_41;
    lemsg = zT_40;
    zT_42 = lemsg;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        le_buf[_i] = zT_44[_i];
        _i++;
    }
}
    zT_48 = ctx->store;
    zT_49 = zT_48->extra_children;
    zT_50 = zT_49.len;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)le_buf) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = (unsigned char*)zT_55;
    zT_57.len = zT_56;
    zT_47 = zT_57;
    zT_58 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_50), zT_47);
    le_len = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)le_len);
    le_start = zT_62;
    zT_67 = (unsigned char*)((unsigned char*)le_buf) + le_start;
    zT_68 = (unsigned int)(19) - le_start;
    zT_69.ptr = (unsigned char*)zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zF_48AC7B3A_markerWrite(zT_63);
    zT_71 = "\n";
    zT_73 = 1;
    zT_72.ptr = (unsigned char*)zT_71;
    zT_72.len = zT_73;
    lnl = zT_72;
    zT_74 = lnl;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_76 = ctx->alloc;
    zT_75 = &zT_76->scratch;
    zF_F1B3F8C2_sandReset(zT_75);
    zT_79 = &ctx->lir_slots;
    zT_79->len = (unsigned int)(0);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_81[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        spill_path[_i] = zT_81[_i];
        _i++;
    }
}
    zT_83 = 0;
    sp_len = zT_83;
    zT_84 = ctx->cli;
    zT_85 = zT_84.output_dir_set;
    if (zT_85) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_87 = ctx->cli;
    zT_88 = zT_87.output_dir;
    od = zT_88;
    zT_90 = 0;
    oi = zT_90;
    goto z_bb_4;
    z_bb_2:
    zT_113 = ".zig1_lir.tmp";
    zT_115 = 13;
    zT_114.ptr = (unsigned char*)zT_113;
    zT_114.len = zT_115;
    tmp_name = zT_114;
    zT_117 = 0;
    ti = zT_117;
    goto z_bb_11;
    z_bb_3:
    zT_106 = 46;
    spill_path[sp_len] = zT_106;
    zT_108 = sp_len + (unsigned int)(1);
    sp_len = zT_108;
    zT_109 = 47;
    spill_path[sp_len] = zT_109;
    zT_111 = sp_len + (unsigned int)(1);
    sp_len = zT_111;
    goto z_bb_2;
    z_bb_4:
    zT_92 = od.len;
    if ((unsigned char)(oi < zT_92)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_97 = od.ptr;
    zT_98 = zT_97[oi];
    spill_path[sp_len] = zT_98;
    zT_100 = sp_len + (unsigned int)(1);
    sp_len = zT_100;
    goto z_bb_7;
    z_bb_6:
    zT_103 = 47;
    spill_path[sp_len] = zT_103;
    zT_105 = sp_len + (unsigned int)(1);
    sp_len = zT_105;
    goto z_bb_2;
    z_bb_7:
    zT_102 = oi + (unsigned int)(1);
    oi = zT_102;
    goto z_bb_4;
    z_bb_8:
    zT_94 = sp_len < (unsigned int)(511);
    goto z_bb_10;
    z_bb_9:
    zT_94 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_94) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    zT_119 = tmp_name.len;
    if ((unsigned char)(ti < zT_119)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_124 = tmp_name.ptr;
    zT_125 = zT_124[ti];
    spill_path[sp_len] = zT_125;
    zT_127 = sp_len + (unsigned int)(1);
    sp_len = zT_127;
    goto z_bb_14;
    z_bb_13:
    zT_130 = &ctx->lir_stream;
    zT_136 = 0;
    zT_137 = (unsigned char*)((unsigned char*)spill_path) + zT_136;
    zT_138 = sp_len - zT_136;
    zT_139.ptr = (unsigned char*)zT_137;
    zT_139.len = zT_138;
    zT_131 = zT_139;
    zT_140 = ctx->alloc;
    zT_132 = &zT_140->emission;
    zF_B0B74E20_lirStreamBeginWrite(zT_130, zT_131, zT_132);
    zT_144 = ctx->store;
    zT_143.store = zT_144;
    zT_145 = ctx->typereg;
    zT_143.registry = zT_145;
    zT_146 = ctx->symbol_reg;
    zT_143.symbol_tables = zT_146;
    zT_147 = ctx->resolved_types;
    zT_143.resolved_types = zT_147;
    zT_148 = ctx->coercion_table;
    zT_143.coercions = zT_148;
    zT_149 = ctx->diag;
    zT_143.diag = zT_149;
    zT_150 = 1;
    zT_143.has_symbols = zT_150;
    zT_151 = &ctx->enum_value_table;
    zT_143.enum_value_table = zT_151;
    zT_152 = &ctx->tuple_index_table;
    zT_143.tuple_index_table = zT_152;
    zT_153 = &ctx->error_code_registry;
    zT_143.error_code_registry = zT_153;
    zT_154 = &ctx->call_arg_types;
    zT_143.call_arg_types = zT_154;
    zT_155 = &ctx->comptime_folds;
    zT_143.comptime_folds = zT_155;
    zT_156 = &ctx->const_inits;
    zT_143.const_inits = zT_156;
    zT_157 = 0;
    zT_143.source_file_id = zT_157;
    zT_158 = ctx->cli;
    zT_159 = zT_158.safe_checks;
    zT_143.safe_checks = zT_159;
    zT_160 = &ctx->suspending_fns;
    zT_143.suspending_fns = zT_160;
    zT_161 = &ctx->frame_sizes;
    zT_143.frame_sizes = zT_161;
    zT_162 = &ctx->state_widths;
    zT_143.state_widths = zT_162;
    zT_163 = 0;
    zT_143.print_value_lowered = zT_163;
    sem_ctx = zT_143;
    zT_165 = ctx->module_reg;
    zT_167 = zF_3452C137_moduleRegistryGetMo(zT_165);
    mods = zT_167;
    zT_170 = ctx->alloc;
    zT_169 = &zT_170->module;
    zT_172 = zF_8E537D0C_u32ArrayListInit(zT_169);
    async_retained = zT_172;
    zT_174 = 0;
    async_pending = zT_174;
    zT_176 = 0;
    zT_177 = (unsigned int)zT_176;
    mi = zT_177;
    goto z_bb_18;
    z_bb_14:
    zT_129 = ti + (unsigned int)(1);
    ti = zT_129;
    goto z_bb_11;
    z_bb_15:
    zT_121 = sp_len < (unsigned int)(511);
    goto z_bb_17;
    z_bb_16:
    zT_121 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_121) goto z_bb_12; else goto z_bb_13;
    z_bb_18:
    zT_179 = mods.len;
    if ((unsigned char)(mi < zT_179)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_181 = mods.ptr;
    zT_182 = zT_181[mi];
    zT_183 = zT_182.source_file_id;
    sem_ctx.source_file_id = zT_183;
    zT_185 = "M";
    zT_187 = 1;
    zT_186.ptr = (unsigned char*)zT_185;
    zT_186.len = zT_187;
    mm = zT_186;
    zT_188 = mm;
    zF_48AC7B3A_markerWrite(zT_188);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_190[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        mi_buf[_i] = zT_190[_i];
        _i++;
    }
}
    zT_197 = 0;
    zT_198 = (unsigned char*)((unsigned char*)mi_buf) + zT_197;
    zT_199 = (unsigned int)(20) - zT_197;
    zT_200.ptr = (unsigned char*)zT_198;
    zT_200.len = zT_199;
    zT_193 = zT_200;
    zT_201 = zF_A7504564_itoa((unsigned int)((unsigned int)mi), zT_193);
    mi_len = zT_201;
    zT_205 = (unsigned int)(19) - (unsigned int)((unsigned int)mi_len);
    mi2_start = zT_205;
    zT_210 = (unsigned char*)((unsigned char*)mi_buf) + mi2_start;
    zT_211 = (unsigned int)(19) - mi2_start;
    zT_212.ptr = (unsigned char*)zT_210;
    zT_212.len = zT_211;
    zT_206 = zT_212;
    zF_48AC7B3A_markerWrite(zT_206);
    zT_214 = ":";
    zT_216 = 1;
    zT_215.ptr = (unsigned char*)zT_214;
    zT_215.len = zT_216;
    msep = zT_215;
    zT_217 = msep;
    zF_48AC7B3A_markerWrite(zT_217);
    zT_218 = mods.ptr;
    zT_219 = zT_218[mi];
    zT_220 = zT_219.ast_root;
    if ((unsigned char)(zT_220 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_952 = 0;
    arl_i = zT_952;
    goto z_bb_155;
    z_bb_21:
    zT_948 = 1;
    zT_950 = mi + (unsigned int)((unsigned int)zT_948);
    mi = zT_950;
    goto z_bb_18;
    z_bb_22:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_224[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ar_buf[_i] = zT_224[_i];
        _i++;
    }
}
    zT_228 = mods.ptr;
    zT_229 = zT_228[mi];
    zT_226 = zT_229.ast_root;
    zT_233 = 0;
    zT_234 = (unsigned char*)((unsigned char*)ar_buf) + zT_233;
    zT_235 = (unsigned int)(20) - zT_233;
    zT_236.ptr = (unsigned char*)zT_234;
    zT_236.len = zT_235;
    zT_227 = zT_236;
    zT_237 = zF_A7504564_itoa(zT_226, zT_227);
    ar_len = zT_237;
    zT_241 = (unsigned int)(19) - (unsigned int)((unsigned int)ar_len);
    ar_start = zT_241;
    zT_246 = (unsigned char*)((unsigned char*)ar_buf) + ar_start;
    zT_247 = (unsigned int)(19) - ar_start;
    zT_248.ptr = (unsigned char*)zT_246;
    zT_248.len = zT_247;
    zT_242 = zT_248;
    zF_48AC7B3A_markerWrite(zT_242);
    zT_249 = msep;
    zF_48AC7B3A_markerWrite(zT_249);
    zT_251 = ctx->store;
    zT_254 = mods.ptr;
    zT_255 = zT_254[mi];
    zT_252 = zT_255.ast_root;
    zT_257 = zF_FCDD1D35_astStoreNodeAt(zT_251, zT_252);
    root = zT_257;
    zT_258 = root.kind;
    if ((unsigned char)(zT_258 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_263 = "R";
    zT_265 = 1;
    zT_264.ptr = (unsigned char*)zT_263;
    zT_264.len = zT_265;
    mr = zT_264;
    zT_266 = mr;
    zF_48AC7B3A_markerWrite(zT_266);
    zT_268 = ctx->store;
    zT_271 = mods.ptr;
    zT_272 = zT_271[mi];
    zT_269 = zT_272.ast_root;
    zT_274 = zF_152E19CB_astStoreNodeExtraCh(zT_268, zT_269);
    decls_n = zT_274;
    zT_276 = (unsigned int)decls_n;
    decl_len = zT_276;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_278[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dcount_buf[_i] = zT_278[_i];
        _i++;
    }
}
    zT_280 = decl_len;
    zT_284 = 0;
    zT_285 = (unsigned char*)((unsigned char*)dcount_buf) + zT_284;
    zT_286 = (unsigned int)(20) - zT_284;
    zT_287.ptr = (unsigned char*)zT_285;
    zT_287.len = zT_286;
    zT_281 = zT_287;
    zT_288 = zF_A7504564_itoa(zT_280, zT_281);
    dcount_len = zT_288;
    zT_292 = (unsigned int)(19) - (unsigned int)((unsigned int)dcount_len);
    dstart = zT_292;
    zT_297 = (unsigned char*)((unsigned char*)dcount_buf) + dstart;
    zT_298 = (unsigned int)(19) - dstart;
    zT_299.ptr = (unsigned char*)zT_297;
    zT_299.len = zT_298;
    zT_293 = zT_299;
    zF_48AC7B3A_markerWrite(zT_293);
    zT_300 = msep;
    zF_48AC7B3A_markerWrite(zT_300);
    zT_301 = ctx->store;
    zT_305 = mods.ptr;
    zT_306 = zT_305[mi];
    zT_302 = zT_306.ast_root;
    zT_308 = mods.ptr;
    zT_309 = zT_308 + mi;
    zT_303 = &zT_309->c_includes;
    zF_7D71E4ED_moduleRegistryColle(zT_301, zT_302, zT_303);
    zT_312 = 0;
    mod_has_ri = zT_312;
    zT_314 = 0;
    di = zT_314;
    goto z_bb_26;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_318 = ctx->store;
    zT_322 = mods.ptr;
    zT_323 = zT_322[mi];
    zT_319 = zT_323.ast_root;
    zT_326 = zF_B10B1BC1_astStoreNodeExtraCh(zT_318, zT_319, (unsigned int)((unsigned int)di));
    decl_idx = zT_326;
    zT_328 = ctx->store;
    zT_329 = decl_idx;
    zT_331 = zF_FCDD1D35_astStoreNodeAt(zT_328, zT_329);
    decl = zT_331;
    zT_333 = decl.kind;
    zT_334 = (unsigned int)zT_333;
    raw_k = zT_334;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_336[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rbuf[_i] = zT_336[_i];
        _i++;
    }
}
    zT_338 = raw_k;
    zT_342 = 0;
    zT_343 = (unsigned char*)((unsigned char*)rbuf) + zT_342;
    zT_344 = (unsigned int)(20) - zT_342;
    zT_345.ptr = (unsigned char*)zT_343;
    zT_345.len = zT_344;
    zT_339 = zT_345;
    zT_346 = zF_A7504564_itoa(zT_338, zT_339);
    rlen = zT_346;
    zT_350 = (unsigned int)(19) - (unsigned int)((unsigned int)rlen);
    rstart = zT_350;
    zT_355 = (unsigned char*)((unsigned char*)rbuf) + rstart;
    zT_356 = (unsigned int)(19) - rstart;
    zT_357.ptr = (unsigned char*)zT_355;
    zT_357.len = zT_356;
    zT_351 = zT_357;
    zF_48AC7B3A_markerWrite(zT_351);
    zT_359 = " ";
    zT_361 = 1;
    zT_360.ptr = (unsigned char*)zT_359;
    zT_360.len = zT_361;
    sp2 = zT_360;
    zT_362 = sp2;
    zF_48AC7B3A_markerWrite(zT_362);
    zT_363 = decl.kind;
    if ((unsigned char)(zT_363 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_30; else goto z_bb_32;
    z_bb_28:
    if ((unsigned char)(mod_has_ri != (unsigned char)(0))) goto z_bb_140; else goto z_bb_141;
    z_bb_29:
    zT_809 = di + (unsigned int)(1);
    di = zT_809;
    goto z_bb_26;
    z_bb_30:
    zT_368 = "F";
    zT_370 = 1;
    zT_369.ptr = (unsigned char*)zT_368;
    zT_369.len = zT_370;
    mf = zT_369;
    zT_371 = mf;
    zF_48AC7B3A_markerWrite(zT_371);
    zT_372 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_372) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_499 = decl.kind;
    if ((unsigned char)(zT_499 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_43; else goto z_bb_44;
    z_bb_33:
    zT_379 = ctx->store;
    zT_380 = zT_379->fn_protos;
    zT_381 = zT_380.items;
    zT_382 = ctx->store;
    zT_383 = decl_idx;
    zT_385 = zF_8BA26B9E_astStoreNodePayload(zT_382, zT_383);
    zT_386 = (unsigned int)zT_385;
    zT_387 = zT_381[zT_386];
    fexp_proto = zT_387;
    zT_389 = mods.ptr;
    zT_390 = zT_389[mi];
    zT_391 = zT_390.id;
    zT_399 = fexp_proto.name_id;
    zT_401 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_391) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(0)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_399);
    fexp_key = zT_401;
    zT_402 = &ctx->exported;
    zT_403 = fexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_402, zT_403, (unsigned int)(1));
    goto z_bb_34;
    z_bb_34:
    zT_408 = (zT_6B356268_SemanticContext*)&sem_ctx;
    zT_411 = ctx->alloc;
    zT_409 = &zT_411->scratch;
    zT_413 = zF_ADD4254B_lowererInit(zT_408, zT_409);
    lowerer = zT_413;
    zT_414 = mods.ptr;
    zT_415 = zT_414[mi];
    zT_416 = zT_415.id;
    lowerer.module_id = zT_416;
    zT_417 = ctx->module_reg;
    lowerer.module_reg = zT_417;
    zT_419 = (zT_02EB57B2_LirLowerer*)&lowerer;
    zT_420 = decl_idx;
    zT_422 = zF_B53F5F2E_lowerFn(zT_419, zT_420);
    lf = zT_422;
    zT_423 = &ctx->suspending_fns;
    zT_424 = lf.module_id;
    zT_425 = lf.name_id;
    zT_429 = zF_7C7E43BF_asyncIsSuspending(zT_423, zT_424, zT_425);
    if (zT_429) goto z_bb_35; else goto z_bb_37;
    z_bb_35:
    zT_443 = ctx->alloc;
    zT_431 = &zT_443->scratch;
    zT_432 = ctx->typereg;
    zT_433 = (zT_BBC23664_LirFunction*)&lf;
    zT_434 = &ctx->suspending_fns;
    zT_435 = &ctx->frame_sizes;
    zT_436 = &ctx->state_widths;
    zT_437 = &ctx->awaited_fns;
    zT_438 = &ctx->async_hidden_fns;
    zT_439 = &ctx->driver_targets;
    zT_440 = &ctx->parent_result_type_list;
    zT_441 = &ctx->parent_result_start;
    zT_442 = &ctx->parent_result_count;
    zT_456 = zF_28031796_asyncLayoutFrame(zT_431, zT_432, zT_433, zT_434, zT_435, zT_436, zT_437, zT_438, zT_439, zT_440, zT_441, zT_442);
    async_layout = zT_456;
    zT_462 = ctx->alloc;
    zT_457 = &zT_462->scratch;
    zT_458 = &ctx->async_layouts;
    zT_459 = lf.module_id;
    zT_460 = lf.name_id;
    zT_461 = async_layout;
    zF_17324878_asyncLayoutPublish(zT_457, zT_458, zT_459, zT_460, zT_461);
    zT_471 = ctx->alloc;
    zT_468 = &zT_471->scratch;
    zT_475 = zF_1395EB68_sandAlloc(zT_468, (unsigned int)(124), (unsigned int)(4));
    zT_476 = zT_475.is_error;
    if (zT_476) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_488 = &ctx->lir_stream;
    zT_489 = lf;
    zT_491 = zF_9F47D5E4_lirStreamAppend(zT_488, zT_489);
    slot = zT_491;
    zT_492 = &ctx->lir_slots;
    zT_493 = slot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_492, zT_493);
    if ((unsigned char)(!async_pending)) goto z_bb_41; else goto z_bb_42;
    z_bb_38:
    pal_trap();
    z_bb_39:
    zT_477 = zT_475.data.payload;
    goto z_bb_40;
    z_bb_40:
    lf_raw = zT_477;
    zT_480 = (zT_BBC23664_LirFunction*)lf_raw;
    lf_ptr = zT_480;
    *lf_ptr = lf;
    zT_481 = (zT_B687BB96_U32ArrayList*)&async_retained;
    zF_62F717A2_u32ArrayListAppend(zT_481, (unsigned int)((unsigned int)(unsigned int)((unsigned int)lf_ptr)));
    zT_486 = 1;
    async_pending = zT_486;
    goto z_bb_36;
    z_bb_41:
    zT_497 = ctx->alloc;
    zT_496 = &zT_497->scratch;
    zF_F1B3F8C2_sandReset(zT_496);
    goto z_bb_42;
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    zT_503 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_503) & (unsigned short)(4)) == (unsigned short)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_31;
    z_bb_45:
    zT_510 = ctx->store;
    zT_511 = decl_idx;
    zT_513 = zF_8BA26B9E_astStoreNodePayload(zT_510, zT_511);
    gv_name = zT_513;
    zT_515 = ctx->symbol_reg;
    zT_519 = mods.ptr;
    zT_520 = zT_519[mi];
    zT_516 = zT_520.id;
    zT_517 = gv_name;
    zT_522 = zF_A398987E_symbolRegistryQuali(zT_515, zT_516, zT_517);
    gv_sym = zT_522;
    zT_523 = gv_sym.has_value;
    if (zT_523) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_44;
    z_bb_47:
    gvs = gv_sym.value;
    zT_525 = gvs->kind;
    if ((unsigned char)(zT_525 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    zT_530 = 4294967295u;
    gv_ctree = zT_530;
    zT_531 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_531) & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_538 = decl.child_1;
    zT_537 = zT_538 != (unsigned int)(0);
    goto z_bb_53;
    z_bb_52:
    zT_537 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_537) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_542 = ctx->store;
    zT_543 = decl.child_1;
    zT_546 = zF_FCDD1D35_astStoreNodeAt(zT_542, zT_543);
    gv_i0 = zT_546;
    zT_548 = 0;
    gv_alias = zT_548;
    zT_549 = gv_i0.kind;
    if ((unsigned char)(zT_549 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    if ((unsigned char)(gv_ctree != (unsigned int)(4294967295u))) goto z_bb_68; else goto z_bb_70;
    z_bb_56:
    zT_553 = 1;
    gv_alias = zT_553;
    goto z_bb_57;
    z_bb_57:
    zT_554 = gv_i0.kind;
    if ((unsigned char)(zT_554 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_559 = ctx->store;
    zT_560 = gv_i0.child_0;
    zT_563 = zF_FCDD1D35_astStoreNodeAt(zT_559, zT_560);
    gv_fb0 = zT_563;
    zT_564 = gv_fb0.kind;
    if ((unsigned char)(zT_564 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    if ((unsigned char)(gv_alias == (unsigned char)(0))) goto z_bb_62; else goto z_bb_63;
    z_bb_60:
    zT_568 = 1;
    gv_alias = zT_568;
    goto z_bb_61;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    zT_573 = &ctx->const_inits;
    zT_571 = &zT_573->roots;
    zT_572 = decl_idx;
    zT_575 = zF_F3EE5998_u32ToU32MapGet(zT_571, zT_572);
    zT_576 = zT_575.has_value;
    if (zT_576) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    goto z_bb_55;
    z_bb_64:
    croot = zT_575.value;
    if ((unsigned char)(croot != (unsigned int)(4294967295u))) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    gv_ctree = croot;
    goto z_bb_67;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    zT_582 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_582) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    goto z_bb_50;
    z_bb_70:
    zT_673 = 0;
    gv_is_storage = zT_673;
    zT_674 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_674) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_102; else goto z_bb_104;
    z_bb_71:
    zT_589 = mods.ptr;
    zT_590 = zT_589[mi];
    zT_591 = zT_590.id;
    zT_600 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_591) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(Z98_U64_C(4294967296))) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_600;
    zT_601 = &ctx->exported;
    zT_602 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_601, zT_602, (unsigned int)(1));
    goto z_bb_72;
    z_bb_72:
    zT_607 = ctx->resolved_types;
    zT_608 = decl_idx;
    zT_610 = zF_999DCF51_resolvedTypeTableGe(zT_607, zT_608);
    gv_rt2 = zT_610;
    zT_612 = gv_rt2.has_value;
    if (zT_612) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    grt2 = gv_rt2.value;
    zT_613 = grt2;
    goto z_bb_75;
    z_bb_74:
    zT_613 = 18;
    goto z_bb_75;
    z_bb_75:
    gv_tid2 = zT_613;
    if ((unsigned char)(gv_tid2 == (unsigned int)(19))) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_618 = gv_tid2 == (unsigned int)(18);
    goto z_bb_78;
    z_bb_77:
    zT_618 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_618) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_621 = gv_tid2 == (unsigned int)(0);
    goto z_bb_81;
    z_bb_80:
    zT_621 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_621) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_625 = &ctx->const_inits;
    zT_626 = gv_ctree;
    zT_628 = zF_C30CDA77_constInitNodeAt(zT_625, zT_626);
    gv_rn = zT_628;
    zT_629 = gv_rn.kind;
    if ((unsigned char)(zT_629 == (unsigned char)(1))) goto z_bb_85; else goto z_bb_84;
    z_bb_83:
    zT_656 = 0;
    gv_lv = zT_656;
    zT_657 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_657) & (unsigned short)(10)) != (unsigned short)(0))) goto z_bb_100; else goto z_bb_101;
    z_bb_84:
    zT_633 = gv_rn.kind;
    zT_632 = zT_633 == (unsigned char)(4);
    goto z_bb_86;
    z_bb_85:
    zT_632 = 1;
    goto z_bb_86;
    z_bb_86:
    if (zT_632) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    zT_636 = 10;
    gv_tid2 = zT_636;
    zT_637 = gv_rn.b;
    if ((unsigned char)((unsigned int)(zT_637 & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_90; else goto z_bb_92;
    z_bb_88:
    goto z_bb_83;
    z_bb_89:
    zT_647 = gv_rn.kind;
    if ((unsigned char)(zT_647 == (unsigned char)(3))) goto z_bb_95; else goto z_bb_97;
    z_bb_90:
    zT_642 = 7;
    gv_tid2 = zT_642;
    goto z_bb_91;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_643 = gv_rn.a;
    if ((unsigned char)(zT_643 > (zT_79FAE712_u64)(4294967295u))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_646 = 11;
    gv_tid2 = zT_646;
    goto z_bb_94;
    z_bb_94:
    goto z_bb_91;
    z_bb_95:
    zT_650 = 2;
    gv_tid2 = zT_650;
    goto z_bb_96;
    z_bb_96:
    goto z_bb_88;
    z_bb_97:
    zT_651 = gv_rn.kind;
    if ((unsigned char)(zT_651 == (unsigned char)(2))) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_654 = 16;
    gv_tid2 = zT_654;
    goto z_bb_99;
    z_bb_99:
    goto z_bb_96;
    z_bb_100:
    zT_663 = 1;
    gv_lv = zT_663;
    goto z_bb_101;
    z_bb_101:
    zT_664 = &ctx->global_decls;
    zT_667.name_id = gv_name;
    zT_668 = mods.ptr;
    zT_669 = zT_668[mi];
    zT_670 = zT_669.id;
    zT_667.module_id = zT_670;
    zT_667.type_id = gv_tid2;
    zT_671 = 0;
    zT_667.has_runtime_init = zT_671;
    zT_667.const_init = gv_ctree;
    zT_667.link_visible = gv_lv;
    zT_665 = zT_667;
    zF_F2C82CE7_globalDeclArrayList(zT_664, zT_665);
    goto z_bb_69;
    z_bb_102:
    zT_680 = 1;
    gv_is_storage = zT_680;
    goto z_bb_103;
    z_bb_103:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_115; else goto z_bb_116;
    z_bb_104:
    zT_681 = decl.child_1;
    if ((unsigned char)(zT_681 != (unsigned int)(0))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_685 = ctx->store;
    zT_686 = decl.child_1;
    zT_689 = zF_FCDD1D35_astStoreNodeAt(zT_685, zT_686);
    gv_init = zT_689;
    zT_690 = gv_init.kind;
    if ((unsigned char)(zT_690 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_695 = gv_init.kind;
    zT_694 = zT_695 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal);
    goto z_bb_109;
    z_bb_108:
    zT_694 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_694) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_700 = gv_init.kind;
    zT_699 = zT_700 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_112;
    z_bb_111:
    zT_699 = 0;
    goto z_bb_112;
    z_bb_112:
    if (zT_699) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_704 = 1;
    gv_is_storage = zT_704;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_106;
    z_bb_115:
    zT_707 = decl.child_1;
    if ((unsigned char)(zT_707 != (unsigned int)(0))) goto z_bb_117; else goto z_bb_118;
    z_bb_116:
    if ((unsigned char)(gv_is_storage == (unsigned char)(1))) goto z_bb_125; else goto z_bb_126;
    z_bb_117:
    zT_711 = ctx->store;
    zT_712 = decl.child_1;
    zT_715 = zF_FCDD1D35_astStoreNodeAt(zT_711, zT_712);
    gv_init3 = zT_715;
    zT_716 = gv_init3.kind;
    if ((unsigned char)(zT_716 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_119; else goto z_bb_120;
    z_bb_118:
    goto z_bb_116;
    z_bb_119:
    zT_720 = 0;
    gv_is_storage = zT_720;
    goto z_bb_120;
    z_bb_120:
    zT_721 = gv_init3.kind;
    if ((unsigned char)(zT_721 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_726 = ctx->store;
    zT_727 = gv_init3.child_0;
    zT_730 = zF_FCDD1D35_astStoreNodeAt(zT_726, zT_727);
    gv_fb = zT_730;
    zT_731 = gv_fb.kind;
    if ((unsigned char)(zT_731 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_123; else goto z_bb_124;
    z_bb_122:
    goto z_bb_118;
    z_bb_123:
    zT_735 = 0;
    gv_is_storage = zT_735;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_122;
    z_bb_125:
    zT_738 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_738) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_127; else goto z_bb_128;
    z_bb_126:
    goto z_bb_69;
    z_bb_127:
    zT_745 = mods.ptr;
    zT_746 = zT_745[mi];
    zT_747 = zT_746.id;
    zT_756 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_747) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(Z98_U64_C(4294967296))) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_756;
    zT_757 = &ctx->exported;
    zT_758 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_757, zT_758, (unsigned int)(1));
    goto z_bb_128;
    z_bb_128:
    zT_763 = 0;
    gv_has_ri = zT_763;
    zT_764 = decl.child_1;
    if ((unsigned char)(zT_764 != (unsigned int)(0))) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    zT_768 = ctx->store;
    zT_769 = decl.child_1;
    zT_772 = zF_FCDD1D35_astStoreNodeAt(zT_768, zT_769);
    gv_init2 = zT_772;
    zT_773 = gv_init2.kind;
    if ((unsigned char)(zT_773 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_131; else goto z_bb_132;
    z_bb_130:
    if ((unsigned char)(gv_has_ri == (unsigned char)(1))) goto z_bb_133; else goto z_bb_134;
    z_bb_131:
    zT_777 = 1;
    gv_has_ri = zT_777;
    goto z_bb_132;
    z_bb_132:
    goto z_bb_130;
    z_bb_133:
    zT_780 = 1;
    mod_has_ri = zT_780;
    goto z_bb_134;
    z_bb_134:
    zT_782 = ctx->resolved_types;
    zT_783 = decl_idx;
    zT_785 = zF_999DCF51_resolvedTypeTableGe(zT_782, zT_783);
    gv_rt = zT_785;
    zT_787 = gv_rt.has_value;
    if (zT_787) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    grt = gv_rt.value;
    zT_788 = grt;
    goto z_bb_137;
    z_bb_136:
    zT_788 = 18;
    goto z_bb_137;
    z_bb_137:
    gv_tid = zT_788;
    zT_792 = 0;
    gv_lv2 = zT_792;
    zT_793 = decl.flags;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_793) & (unsigned short)(10)) != (unsigned short)(0))) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    zT_799 = 1;
    gv_lv2 = zT_799;
    goto z_bb_139;
    z_bb_139:
    zT_800 = &ctx->global_decls;
    zT_803.name_id = gv_name;
    zT_804 = mods.ptr;
    zT_805 = zT_804[mi];
    zT_806 = zT_805.id;
    zT_803.module_id = zT_806;
    zT_803.type_id = gv_tid;
    zT_803.has_runtime_init = gv_has_ri;
    zT_807 = 4294967295u;
    zT_803.const_init = zT_807;
    zT_803.link_visible = gv_lv2;
    zT_801 = zT_803;
    zF_F2C82CE7_globalDeclArrayList(zT_800, zT_801);
    goto z_bb_126;
    z_bb_140:
    zT_813 = (zT_6B356268_SemanticContext*)&sem_ctx;
    zT_816 = ctx->alloc;
    zT_814 = &zT_816->scratch;
    zT_818 = zF_ADD4254B_lowererInit(zT_813, zT_814);
    ilowerer = zT_818;
    zT_819 = mods.ptr;
    zT_820 = zT_819[mi];
    zT_821 = zT_820.id;
    ilowerer.module_id = zT_821;
    zT_822 = ctx->module_reg;
    ilowerer.module_reg = zT_822;
    zT_824 = (zT_02EB57B2_LirLowerer*)&ilowerer;
    zT_829 = mods.ptr;
    zT_830 = zT_829[mi];
    zT_825 = zT_830.ast_root;
    zT_832 = mods.ptr;
    zT_833 = zT_832[mi];
    zT_826 = zT_833.id;
    zT_827 = &ctx->module_init_deps;
    zT_836 = zF_552B231C_lowerModuleInit(zT_824, zT_825, zT_826, zT_827);
    imf = zT_836;
    zT_838 = &ctx->lir_stream;
    zT_839 = imf;
    zT_841 = zF_9F47D5E4_lirStreamAppend(zT_838, zT_839);
    islot = zT_841;
    zT_842 = &ctx->lir_slots;
    zT_843 = islot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_842, zT_843);
    if ((unsigned char)(!async_pending)) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    zT_850 = ctx->module_reg;
    zT_852 = zF_3452C137_moduleRegistryGetMo(zT_850);
    amods = zT_852;
    zT_854 = amods.len;
    if ((unsigned char)(zT_854 > (unsigned int)(0))) goto z_bb_144; else goto z_bb_145;
    z_bb_142:
    zT_847 = ctx->alloc;
    zT_846 = &zT_847->scratch;
    zF_F1B3F8C2_sandReset(zT_846);
    goto z_bb_143;
    z_bb_143:
    goto z_bb_141;
    z_bb_144:
    zT_858 = amods.ptr;
    zT_859 = 0;
    zT_860 = zT_858[zT_859];
    zT_861 = zT_860.ast_root;
    zT_857 = zT_861 != (unsigned int)(0);
    goto z_bb_146;
    z_bb_145:
    zT_857 = 0;
    goto z_bb_146;
    z_bb_146:
    if (zT_857) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_865 = ctx->store;
    zT_868 = amods.ptr;
    zT_869 = 0;
    zT_870 = zT_868[zT_869];
    zT_866 = zT_870.ast_root;
    zT_872 = zF_FCDD1D35_astStoreNodeAt(zT_865, zT_866);
    ar = zT_872;
    zT_873 = ar.kind;
    if ((unsigned char)(zT_873 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_149; else goto z_bb_150;
    z_bb_148:
    goto z_bb_25;
    z_bb_149:
    zT_878 = ctx->store;
    zT_881 = amods.ptr;
    zT_882 = 0;
    zT_883 = zT_881[zT_882];
    zT_879 = zT_883.ast_root;
    zT_885 = zF_152E19CB_astStoreNodeExtraCh(zT_878, zT_879);
    adl_n = zT_885;
    zT_887 = 0;
    adi = zT_887;
    zT_889 = "A0";
    zT_891 = 2;
    zT_890.ptr = (unsigned char*)zT_889;
    zT_890.len = zT_891;
    al = zT_890;
    zT_892 = al;
    zF_48AC7B3A_markerWrite(zT_892);
    goto z_bb_151;
    z_bb_150:
    goto z_bb_148;
    z_bb_151:
    if ((unsigned char)(adi < (unsigned int)((unsigned int)adl_n))) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_896 = ctx->store;
    zT_899 = ctx->store;
    zT_903 = amods.ptr;
    zT_904 = 0;
    zT_905 = zT_903[zT_904];
    zT_900 = zT_905.ast_root;
    zT_908 = zF_B10B1BC1_astStoreNodeExtraCh(zT_899, zT_900, (unsigned int)((unsigned int)adi));
    zT_897 = zT_908;
    zT_909 = zF_FCDD1D35_astStoreNodeAt(zT_896, zT_897);
    ad = zT_909;
    zT_911 = ad.kind;
    zT_912 = (unsigned int)zT_911;
    ak = zT_912;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_914[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ab[_i] = zT_914[_i];
        _i++;
    }
}
    zT_916 = ak;
    zT_920 = 0;
    zT_921 = (unsigned char*)((unsigned char*)ab) + zT_920;
    zT_922 = (unsigned int)(20) - zT_920;
    zT_923.ptr = (unsigned char*)zT_921;
    zT_923.len = zT_922;
    zT_917 = zT_923;
    zT_924 = zF_A7504564_itoa(zT_916, zT_917);
    alen = zT_924;
    zT_928 = (unsigned int)(19) - (unsigned int)((unsigned int)alen);
    ast = zT_928;
    zT_933 = (unsigned char*)((unsigned char*)ab) + ast;
    zT_934 = (unsigned int)(19) - ast;
    zT_935.ptr = (unsigned char*)zT_933;
    zT_935.len = zT_934;
    zT_929 = zT_935;
    zF_48AC7B3A_markerWrite(zT_929);
    zT_937 = " ";
    zT_939 = 1;
    zT_938.ptr = (unsigned char*)zT_937;
    zT_938.len = zT_939;
    asp = zT_938;
    zT_940 = asp;
    zF_48AC7B3A_markerWrite(zT_940);
    goto z_bb_154;
    z_bb_153:
    zT_944 = "\n";
    zT_946 = 1;
    zT_945.ptr = (unsigned char*)zT_944;
    zT_945.len = zT_946;
    an = zT_945;
    zT_947 = an;
    zF_48AC7B3A_markerWrite(zT_947);
    goto z_bb_150;
    z_bb_154:
    zT_942 = adi + (unsigned int)(1);
    adi = zT_942;
    goto z_bb_151;
    z_bb_155:
    zT_953 = async_retained.len;
    if ((unsigned char)(arl_i < zT_953)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_956 = async_retained.items;
    zT_957 = zT_956[arl_i];
    zT_959 = (zT_BBC23664_LirFunction*)(unsigned int)(unsigned int)((unsigned int)zT_957);
    lf2 = zT_959;
    zT_960 = &ctx->async_layouts;
    zT_961 = lf2->module_id;
    zT_962 = lf2->name_id;
    zT_966 = zF_A1F56FFB_asyncLayoutLookup(zT_960, zT_961, zT_962);
    zT_967 = zT_966.has_value;
    if (zT_967) goto z_bb_159; else goto z_bb_160;
    z_bb_157:
    if (async_pending) goto z_bb_161; else goto z_bb_162;
    z_bb_158:
    zT_988 = arl_i + (unsigned int)(1);
    arl_i = zT_988;
    goto z_bb_155;
    z_bb_159:
    lay2 = zT_966.value;
    zT_971 = ctx->alloc;
    zT_972 = &zT_971->scratch;
    zT_970.alloc = zT_972;
    zT_973 = ctx->typereg;
    zT_970.registry = zT_973;
    zT_974 = ctx->interner;
    zT_970.interner = zT_974;
    zT_975 = &ctx->lir_stream;
    zT_970.lir_stream = zT_975;
    zT_976 = &ctx->lir_slots;
    zT_970.lir_slots = zT_976;
    zT_977 = &ctx->suspending_fns;
    zT_970.suspending_fns = zT_977;
    zT_970.layout = lay2;
    zT_978 = ctx->cli;
    zT_979 = zT_978.safe_checks;
    zT_970.safe_checks = zT_979;
    zT_980 = &ctx->frame_sizes;
    zT_970.frame_sizes = zT_980;
    zT_981 = &ctx->async_layouts;
    zT_970.async_layouts = zT_981;
    zT_982 = ctx->diag;
    zT_970.diag = zT_982;
    async_ctx2 = zT_970;
    zT_983 = lf2;
    zT_984 = (zT_5839647A_AsyncTransformCtx*)&async_ctx2;
    zT_986 = zF_7C1ED6D1_asyncTransform(zT_983, zT_984);
    (void)zT_986;
    goto z_bb_160;
    z_bb_160:
    goto z_bb_158;
    z_bb_161:
    zT_990 = ctx->alloc;
    zT_989 = &zT_990->scratch;
    zF_F1B3F8C2_sandReset(zT_989);
    goto z_bb_162;
    z_bb_162:
    zT_992 = ctx;
    zF_B69A3794_computeModuleInitOr(zT_992);
    zT_993 = &ctx->lir_stream;
    zF_256E5B86_lirStreamFinishWrit(zT_993);
    zT_995 = sem_ctx.print_value_lowered;
    if ((unsigned char)(zT_995 != (unsigned char)(0))) goto z_bb_163; else goto z_bb_164;
    z_bb_163:
    zT_999 = "std_fmt.zig";
    zT_1001 = 11;
    zT_1000.ptr = (unsigned char*)zT_999;
    zT_1000.len = zT_1001;
    c89_fmt_base = zT_1000;
    zT_1005 = ctx->module_reg;
    zT_1007 = zF_3452C137_moduleRegistryGetMo(zT_1005);
    zT_1002 = zT_1007;
    zT_1003 = ctx->interner;
    zT_1004 = c89_fmt_base;
    zT_1009 = zF_D27A4A01_moduleIdForBasename(zT_1002, zT_1003, zT_1004);
    if ((unsigned char)(zT_1009 == (unsigned int)(4294967295u))) goto z_bb_165; else goto z_bb_166;
    z_bb_164:
    return;
    z_bb_165:
    zT_1013 = "could not resolve imported file '";
    zT_1015 = 33;
    zT_1014.ptr = (unsigned char*)zT_1013;
    zT_1014.len = zT_1015;
    p1 = zT_1014;
    zT_1017 = "'";
    zT_1019 = 1;
    zT_1018.ptr = (unsigned char*)zT_1017;
    zT_1018.len = zT_1019;
    p2 = zT_1018;
    zT_1022 = 0;
    zT_1021[zT_1022] = p1;
    zT_1023 = 1;
    zT_1021[zT_1023] = c89_fmt_base;
    zT_1024 = 2;
    zT_1021[zT_1024] = p2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        parts[_i] = zT_1021[_i];
        _i++;
    }
}
    zT_1026 = ctx->interner;
    zT_1030 = 0;
    zT_1031 = parts + zT_1030;
    zT_1027 = zT_1031;
    zT_1033 = zF_8C4BFF7C_diagnosticBuilderMa(zT_1026, zT_1027, (unsigned int)(3));
    msg = zT_1033;
    zT_1034 = ctx->diag;
    zT_1040 = msg;
    zT_1049 = zF_C82559AC_diagnosticCollector(zT_1034, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3048_CANNOT_READ_FILE)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_1040);
    (void)zT_1049;
    goto z_bb_166;
    z_bb_166:
    goto z_bb_164;
}

/* computeModuleInitOrder */
void zF_B69A3794_computeModuleInitOr(zT_5AB29387_CompilerContext* ctx) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_4 = {0};
    unsigned int zT_7;
    zT_B687BB96_U32ArrayList* zT_9;
    zT_3E40CD83_Sand* zT_11;
    zT_69057089_CompilerAlloc* zT_14;
    zT_38349D67_EU_052 zT_19 = {0};
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned char* zT_23;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_34;
    unsigned char zT_36;
    unsigned char zT_38;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char zT_46;
    zT_6E8D187B_ModuleEntry* zT_50;
    zT_6E8D187B_ModuleEntry zT_51;
    unsigned int zT_52;
    zT_6E8D187B_ModuleEntry* zT_56;
    zT_6E8D187B_ModuleEntry zT_57;
    unsigned int zT_58;
    zT_79FAE712_u64 zT_60;
    zT_A4CE86B7_U64ToU32Map* zT_61;
    zT_79FAE712_u64 zT_62;
    zT_BAEE192E_Opt_10 zT_64 = {0};
    unsigned char zT_65;
    unsigned char zT_66;
    unsigned int zT_68;
    unsigned int zT_72;
    unsigned int zT_75;
    unsigned char zT_77;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned int zT_86;
    unsigned char zT_88;
    zT_6E8D187B_ModuleEntry* zT_92;
    zT_6E8D187B_ModuleEntry zT_93;
    unsigned int zT_94;
    zT_6E8D187B_ModuleEntry* zT_98;
    zT_6E8D187B_ModuleEntry zT_99;
    unsigned int zT_100;
    zT_79FAE712_u64 zT_102;
    zT_A4CE86B7_U64ToU32Map* zT_103;
    zT_79FAE712_u64 zT_104;
    zT_BAEE192E_Opt_10 zT_106 = {0};
    unsigned char zT_107;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    zT_22A7C88B_AstNode zT_113 = {0};
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_F85C5DED_DiagnosticCollector* zT_118;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_6E8D187B_ModuleEntry* zT_130;
    zT_6E8D187B_ModuleEntry zT_131;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_138 = 0;
    unsigned char zT_139;
    unsigned int zT_141;
    unsigned int zT_143;
    unsigned char zT_144;
    zT_B687BB96_U32ArrayList* zT_145;
    unsigned int zT_146;
    zT_6E8D187B_ModuleEntry* zT_148;
    zT_6E8D187B_ModuleEntry zT_149;
    unsigned int zT_152;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int n;
    unsigned char* placed;
    unsigned int i;
    unsigned int remaining;
    unsigned int pick;
    unsigned char ok;
    unsigned int j;
    zT_79FAE712_u64 dep_key;
    unsigned int ri;
    unsigned char reported;
    unsigned int rj;
    zT_79FAE712_u64 cyc_key;
    unsigned int ref_decl;
    zT_22A7C88B_AstNode cyc_dcl;
    zT_8F083A69_Slice_zT_0B42B2F8_u cyc_msg;
    zT_2 = ctx->module_reg;
    zT_4 = zF_3452C137_moduleRegistryGetMo(zT_2);
    mods = zT_4;
    zT_7 = mods.len;
    n = zT_7;
    zT_9 = &ctx->module_init_order;
    zT_9->len = (unsigned int)(0);
    zT_14 = ctx->alloc;
    zT_11 = &zT_14->scratch;
    zT_19 = zF_1395EB68_sandAlloc(zT_11, (unsigned int)(n + (unsigned int)(1)), (unsigned int)(1));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_21 = zT_19.data.payload;
    goto z_bb_3;
    z_bb_3:
    zT_23 = (unsigned char*)zT_21;
    placed = zT_23;
    zT_25 = 0;
    i = zT_25;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < n)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_27 = 0;
    placed[i] = zT_27;
    goto z_bb_7;
    z_bb_6:
    remaining = n;
    goto z_bb_8;
    z_bb_7:
    zT_29 = i + (unsigned int)(1);
    i = zT_29;
    goto z_bb_4;
    z_bb_8:
    if ((unsigned char)(remaining > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pick = n;
    zT_34 = 0;
    i = zT_34;
    goto z_bb_12;
    z_bb_10:
    return;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    if ((unsigned char)(i < n)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_38 = placed[i];
    if ((unsigned char)(zT_38 != (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_14:
    if ((unsigned char)(pick == n)) goto z_bb_31; else goto z_bb_32;
    z_bb_15:
    zT_72 = i + (unsigned int)(1);
    i = zT_72;
    goto z_bb_12;
    z_bb_16:
    zT_36 = pick == n;
    goto z_bb_18;
    z_bb_17:
    zT_36 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_36) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    goto z_bb_15;
    z_bb_20:
    zT_42 = 1;
    ok = zT_42;
    zT_44 = 0;
    j = zT_44;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(j < n)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_46 = placed[j];
    if ((unsigned char)(zT_46 != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    if ((unsigned char)(ok != (unsigned char)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_24:
    zT_68 = j + (unsigned int)(1);
    j = zT_68;
    goto z_bb_21;
    z_bb_25:
    goto z_bb_24;
    z_bb_26:
    zT_50 = mods.ptr;
    zT_51 = zT_50[i];
    zT_52 = zT_51.id;
    zT_56 = mods.ptr;
    zT_57 = zT_56[j];
    zT_58 = zT_57.id;
    zT_60 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_52) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_58);
    dep_key = zT_60;
    zT_61 = &ctx->module_init_deps;
    zT_62 = dep_key;
    zT_64 = zF_A05A7BE1_u64ToU32MapGet(zT_61, zT_62);
    zT_65 = zT_64.has_value;
    if (zT_65) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_66 = 0;
    ok = zT_66;
    goto z_bb_23;
    z_bb_28:
    goto z_bb_24;
    z_bb_29:
    pick = i;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_15;
    z_bb_31:
    zT_75 = 0;
    ri = zT_75;
    zT_77 = 0;
    reported = zT_77;
    goto z_bb_33;
    z_bb_32:
    zT_144 = 1;
    placed[pick] = zT_144;
    zT_145 = &ctx->module_init_order;
    zT_148 = mods.ptr;
    zT_149 = zT_148[pick];
    zT_146 = zT_149.id;
    zF_62F717A2_u32ArrayListAppend(zT_145, zT_146);
    zT_152 = remaining - (unsigned int)(1);
    remaining = zT_152;
    goto z_bb_11;
    z_bb_33:
    if ((unsigned char)(ri < n)) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    zT_82 = placed[ri];
    if ((unsigned char)(zT_82 != (unsigned char)(0))) goto z_bb_40; else goto z_bb_41;
    z_bb_35:
    goto z_bb_10;
    z_bb_36:
    zT_143 = ri + (unsigned int)(1);
    ri = zT_143;
    goto z_bb_33;
    z_bb_37:
    zT_79 = reported == (unsigned char)(0);
    goto z_bb_39;
    z_bb_38:
    zT_79 = 0;
    goto z_bb_39;
    z_bb_39:
    if (zT_79) goto z_bb_34; else goto z_bb_35;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_86 = 0;
    rj = zT_86;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(rj < n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_88 = placed[rj];
    if ((unsigned char)(zT_88 != (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_36;
    z_bb_45:
    zT_141 = rj + (unsigned int)(1);
    rj = zT_141;
    goto z_bb_42;
    z_bb_46:
    goto z_bb_45;
    z_bb_47:
    zT_92 = mods.ptr;
    zT_93 = zT_92[ri];
    zT_94 = zT_93.id;
    zT_98 = mods.ptr;
    zT_99 = zT_98[rj];
    zT_100 = zT_99.id;
    zT_102 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_94) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_100);
    cyc_key = zT_102;
    zT_103 = &ctx->module_init_deps;
    zT_104 = cyc_key;
    zT_106 = zF_A05A7BE1_u64ToU32MapGet(zT_103, zT_104);
    zT_107 = zT_106.has_value;
    if (zT_107) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    ref_decl = zT_106.value;
    zT_110 = ctx->store;
    zT_111 = ref_decl;
    zT_113 = zF_FCDD1D35_astStoreNodeAt(zT_110, zT_111);
    cyc_dcl = zT_113;
    zT_115 = "cyclic global initializer dependency";
    zT_117 = 36;
    zT_116.ptr = (unsigned char*)zT_115;
    zT_116.len = zT_117;
    cyc_msg = zT_116;
    zT_118 = ctx->diag;
    zT_130 = mods.ptr;
    zT_131 = zT_130[ri];
    zT_121 = zT_131.source_file_id;
    zT_122 = cyc_dcl.span_start;
    zT_134 = cyc_dcl.span_start;
    zT_135 = cyc_dcl.span_len;
    zT_124 = cyc_msg;
    zT_138 = zF_C82559AC_diagnosticCollector(zT_118, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3064_CYCLIC_GLOBAL_INIT)), zT_121, zT_122, (unsigned int)(zT_134 + (unsigned int)((unsigned int)zT_135)), zT_124);
    (void)zT_138;
    zT_139 = 1;
    reported = zT_139;
    goto z_bb_44;
    z_bb_49:
    goto z_bb_45;
}

/* errorCodeRegistryFinalize */
void zF_FC691B4D_errorCodeRegistryFi(zT_5AB29387_CompilerContext* ctx) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_15;
    zT_338B7C76_TypeRegistry* zT_17;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_21;
    zT_0B73C507_ErrorSetPayload* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_0B73C507_ErrorSetPayload zT_25;
    int zT_27;
    unsigned int zT_28;
    unsigned short zT_29;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int* zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    zT_21D3708C_U32ToU32Map* zT_39;
    unsigned int zT_40;
    unsigned int zT_42 = 0;
    int zT_43;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_48;
    unsigned int ti;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload esp;
    unsigned int ei;
    unsigned int mname_id;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ctx->typereg;
    zT_5 = zT_4->types_len;
    if ((unsigned char)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = ctx->typereg;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_46 = 1;
    zT_48 = ti + (unsigned int)((unsigned int)zT_46);
    ti = zT_48;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = ty.payload_idx;
    zT_17 = ctx->typereg;
    zT_18 = zT_17->es_len;
    if ((unsigned char)((unsigned int)((unsigned int)zT_15) >= zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_21 = ctx->typereg;
    zT_22 = zT_21->es_items;
    zT_23 = ty.payload_idx;
    zT_24 = (unsigned int)zT_23;
    zT_25 = zT_22[zT_24];
    esp = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    ei = zT_28;
    goto z_bb_9;
    z_bb_9:
    zT_29 = esp.tags_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_29))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_33 = ctx->typereg;
    zT_34 = zT_33->xn_items;
    zT_35 = esp.tags_start;
    zT_37 = (unsigned int)((unsigned int)zT_35) + ei;
    zT_38 = zT_34[zT_37];
    mname_id = zT_38;
    zT_39 = &ctx->error_code_registry;
    zT_40 = mname_id;
    zT_42 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_39, zT_40);
    (void)zT_42;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_43 = 1;
    zT_45 = ei + (unsigned int)((unsigned int)zT_43);
    ei = zT_45;
    goto z_bb_9;
}

/* pruneTypeMarkByValue */
void zF_BC6C7740_pruneTypeMarkByValu(zT_21D3708C_U32ToU32Map* ref_edges, zT_338B7C76_TypeRegistry* reg, zT_A4CE86B7_U64ToU32Map* visited, unsigned int src_mid, unsigned int tid) {
    unsigned int zT_5;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_79FAE712_u64 zT_15;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_79FAE712_u64 zT_19;
    zT_D155D06D_Type* zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    unsigned short zT_26;
    unsigned char zT_29;
    unsigned short zT_30;
    zT_21D3708C_U32ToU32Map* zT_32;
    unsigned short zT_37;
    zT_33EF6BFB_TypeKind zT_40;
    zT_406493CE_StructPayload* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_406493CE_StructPayload zT_48;
    unsigned int zT_50;
    unsigned short zT_51;
    zT_21D3708C_U32ToU32Map* zT_54;
    zT_338B7C76_TypeRegistry* zT_55;
    zT_A4CE86B7_U64ToU32Map* zT_56;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_2DF01B61_FieldEntry* zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    zT_2DF01B61_FieldEntry zT_63;
    unsigned int zT_66;
    zT_33EF6BFB_TypeKind zT_67;
    zT_54FF90FA_TaggedUnionPayload* zT_72;
    unsigned int zT_73;
    unsigned int zT_74;
    zT_54FF90FA_TaggedUnionPayload zT_75;
    zT_21D3708C_U32ToU32Map* zT_76;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_A4CE86B7_U64ToU32Map* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_83;
    unsigned short zT_84;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_A4CE86B7_U64ToU32Map* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    zT_2DF01B61_FieldEntry* zT_92;
    unsigned int zT_93;
    unsigned int zT_95;
    zT_2DF01B61_FieldEntry zT_96;
    unsigned int zT_99;
    zT_33EF6BFB_TypeKind zT_100;
    unsigned char zT_104;
    zT_33EF6BFB_TypeKind zT_105;
    zT_AF9231A2_UnionPayload* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_AF9231A2_UnionPayload zT_113;
    zT_21D3708C_U32ToU32Map* zT_114;
    zT_338B7C76_TypeRegistry* zT_115;
    zT_A4CE86B7_U64ToU32Map* zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_121;
    unsigned short zT_122;
    zT_21D3708C_U32ToU32Map* zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    zT_A4CE86B7_U64ToU32Map* zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    zT_2DF01B61_FieldEntry* zT_130;
    unsigned int zT_131;
    unsigned int zT_133;
    zT_2DF01B61_FieldEntry zT_134;
    unsigned int zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_457ECFEE_EnumPayload* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_457ECFEE_EnumPayload zT_146;
    zT_21D3708C_U32ToU32Map* zT_147;
    zT_338B7C76_TypeRegistry* zT_148;
    zT_A4CE86B7_U64ToU32Map* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_33EF6BFB_TypeKind zT_153;
    zT_E834303C_ArrayPayload* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_E834303C_ArrayPayload zT_161;
    zT_21D3708C_U32ToU32Map* zT_162;
    zT_338B7C76_TypeRegistry* zT_163;
    zT_A4CE86B7_U64ToU32Map* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_33EF6BFB_TypeKind zT_168;
    zT_666DC2E1_TuplePayload* zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_666DC2E1_TuplePayload zT_176;
    unsigned int zT_178;
    unsigned short zT_179;
    zT_21D3708C_U32ToU32Map* zT_182;
    zT_338B7C76_TypeRegistry* zT_183;
    zT_A4CE86B7_U64ToU32Map* zT_184;
    unsigned int zT_185;
    unsigned int zT_186;
    unsigned int* zT_187;
    unsigned int zT_188;
    unsigned int zT_190;
    unsigned int zT_193;
    zT_33EF6BFB_TypeKind zT_194;
    zT_0B10E8E9_OptionalPayload* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_0B10E8E9_OptionalPayload zT_202;
    zT_21D3708C_U32ToU32Map* zT_203;
    zT_338B7C76_TypeRegistry* zT_204;
    zT_A4CE86B7_U64ToU32Map* zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_33EF6BFB_TypeKind zT_209;
    zT_42C2D6BF_EUPayload* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    zT_42C2D6BF_EUPayload zT_217;
    zT_21D3708C_U32ToU32Map* zT_218;
    zT_338B7C76_TypeRegistry* zT_219;
    zT_A4CE86B7_U64ToU32Map* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_21D3708C_U32ToU32Map* zT_224;
    zT_338B7C76_TypeRegistry* zT_225;
    zT_A4CE86B7_U64ToU32Map* zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    zT_79FAE712_u64 vkey;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload p;
    unsigned int fi;
    zT_54FF90FA_TaggedUnionPayload p_1;
    zT_AF9231A2_UnionPayload p_2;
    zT_457ECFEE_EnumPayload p_3;
    zT_E834303C_ArrayPayload p_4;
    zT_666DC2E1_TuplePayload p_5;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload p_6;
    zT_42C2D6BF_EUPayload p_7;
    zT_5 = reg->types_len;
    if ((unsigned char)(tid >= (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)src_mid) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)tid);
    vkey = zT_13;
    zT_14 = visited;
    zT_15 = vkey;
    zT_16 = zF_A05A7BE1_u64ToU32MapGet(zT_14, zT_15);
    zT_17 = zT_16.has_value;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = visited;
    zT_19 = vkey;
    zF_B6EB812C_u64ToU32MapPut(zT_18, zT_19, (unsigned int)(1));
    zT_23 = reg->types_items;
    zT_24 = (unsigned int)tid;
    zT_25 = zT_23[zT_24];
    ty = zT_25;
    zT_26 = ty.module_id;
    if ((unsigned char)(zT_26 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = ty.module_id;
    zT_29 = zT_30 != src_mid;
    goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = ref_edges;
    zT_37 = ty.module_id;
    zF_26476265_u32ToU32MapPut(zT_32, (unsigned int)((unsigned int)(src_mid * (unsigned int)(65536)) + zT_37), (unsigned int)(1));
    goto z_bb_9;
    z_bb_9:
    zT_40 = ty.kind;
    if ((unsigned char)(zT_40 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_45 = reg->st_items;
    zT_46 = ty.payload_idx;
    zT_47 = (unsigned int)zT_46;
    zT_48 = zT_45[zT_47];
    p = zT_48;
    zT_50 = 0;
    fi = zT_50;
    goto z_bb_13;
    z_bb_11:
    return;
    z_bb_12:
    zT_67 = ty.kind;
    if ((unsigned char)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_13:
    zT_51 = p.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_51))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_54 = ref_edges;
    zT_55 = reg;
    zT_56 = visited;
    zT_57 = src_mid;
    zT_59 = reg->fe_items;
    zT_60 = p.fields_start;
    zT_62 = (unsigned int)((unsigned int)zT_60) + fi;
    zT_63 = zT_59[zT_62];
    zT_58 = zT_63.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_54, zT_55, zT_56, zT_57, zT_58);
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_66 = fi + (unsigned int)(1);
    fi = zT_66;
    goto z_bb_13;
    z_bb_17:
    zT_72 = reg->tu_items;
    zT_73 = ty.payload_idx;
    zT_74 = (unsigned int)zT_73;
    zT_75 = zT_72[zT_74];
    p_1 = zT_75;
    zT_76 = ref_edges;
    zT_77 = reg;
    zT_78 = visited;
    zT_79 = src_mid;
    zT_80 = p_1.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_76, zT_77, zT_78, zT_79, zT_80);
    zT_83 = 0;
    fi = zT_83;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_11;
    z_bb_19:
    zT_100 = ty.kind;
    if ((unsigned char)(zT_100 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_25; else goto z_bb_24;
    z_bb_20:
    zT_84 = p_1.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_84))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_87 = ref_edges;
    zT_88 = reg;
    zT_89 = visited;
    zT_90 = src_mid;
    zT_92 = reg->fe_items;
    zT_93 = p_1.fields_start;
    zT_95 = (unsigned int)((unsigned int)zT_93) + fi;
    zT_96 = zT_92[zT_95];
    zT_91 = zT_96.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_87, zT_88, zT_89, zT_90, zT_91);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_99 = fi + (unsigned int)(1);
    fi = zT_99;
    goto z_bb_20;
    z_bb_24:
    zT_105 = ty.kind;
    zT_104 = zT_105 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_26;
    z_bb_25:
    zT_104 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_104) goto z_bb_27; else goto z_bb_29;
    z_bb_27:
    zT_110 = reg->un_items;
    zT_111 = ty.payload_idx;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zT_110[zT_112];
    p_2 = zT_113;
    zT_114 = ref_edges;
    zT_115 = reg;
    zT_116 = visited;
    zT_117 = src_mid;
    zT_118 = p_2.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_114, zT_115, zT_116, zT_117, zT_118);
    zT_121 = 0;
    fi = zT_121;
    goto z_bb_30;
    z_bb_28:
    goto z_bb_18;
    z_bb_29:
    zT_138 = ty.kind;
    if ((unsigned char)(zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_36;
    z_bb_30:
    zT_122 = p_2.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_122))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_125 = ref_edges;
    zT_126 = reg;
    zT_127 = visited;
    zT_128 = src_mid;
    zT_130 = reg->fe_items;
    zT_131 = p_2.fields_start;
    zT_133 = (unsigned int)((unsigned int)zT_131) + fi;
    zT_134 = zT_130[zT_133];
    zT_129 = zT_134.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_125, zT_126, zT_127, zT_128, zT_129);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_137 = fi + (unsigned int)(1);
    fi = zT_137;
    goto z_bb_30;
    z_bb_34:
    zT_143 = reg->en_items;
    zT_144 = ty.payload_idx;
    zT_145 = (unsigned int)zT_144;
    zT_146 = zT_143[zT_145];
    p_3 = zT_146;
    zT_147 = ref_edges;
    zT_148 = reg;
    zT_149 = visited;
    zT_150 = src_mid;
    zT_151 = p_3.backing_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_147, zT_148, zT_149, zT_150, zT_151);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_28;
    z_bb_36:
    zT_153 = ty.kind;
    if ((unsigned char)(zT_153 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_158 = reg->array_items;
    zT_159 = ty.payload_idx;
    zT_160 = (unsigned int)zT_159;
    zT_161 = zT_158[zT_160];
    p_4 = zT_161;
    zT_162 = ref_edges;
    zT_163 = reg;
    zT_164 = visited;
    zT_165 = src_mid;
    zT_166 = p_4.elem;
    zF_BC6C7740_pruneTypeMarkByValu(zT_162, zT_163, zT_164, zT_165, zT_166);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_168 = ty.kind;
    if ((unsigned char)(zT_168 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_173 = reg->tup_items;
    zT_174 = ty.payload_idx;
    zT_175 = (unsigned int)zT_174;
    zT_176 = zT_173[zT_175];
    p_5 = zT_176;
    zT_178 = 0;
    ei = zT_178;
    goto z_bb_43;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_194 = ty.kind;
    if ((unsigned char)(zT_194 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_47; else goto z_bb_49;
    z_bb_43:
    zT_179 = p_5.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_179))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_182 = ref_edges;
    zT_183 = reg;
    zT_184 = visited;
    zT_185 = src_mid;
    zT_187 = reg->xt_items;
    zT_188 = p_5.elems_start;
    zT_190 = (unsigned int)((unsigned int)zT_188) + ei;
    zT_186 = zT_187[zT_190];
    zF_BC6C7740_pruneTypeMarkByValu(zT_182, zT_183, zT_184, zT_185, zT_186);
    goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_193 = ei + (unsigned int)(1);
    ei = zT_193;
    goto z_bb_43;
    z_bb_47:
    zT_199 = reg->opt_items;
    zT_200 = ty.payload_idx;
    zT_201 = (unsigned int)zT_200;
    zT_202 = zT_199[zT_201];
    p_6 = zT_202;
    zT_203 = ref_edges;
    zT_204 = reg;
    zT_205 = visited;
    zT_206 = src_mid;
    zT_207 = p_6.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_203, zT_204, zT_205, zT_206, zT_207);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_41;
    z_bb_49:
    zT_209 = ty.kind;
    if ((unsigned char)(zT_209 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_214 = reg->eu_items;
    zT_215 = ty.payload_idx;
    zT_216 = (unsigned int)zT_215;
    zT_217 = zT_214[zT_216];
    p_7 = zT_217;
    zT_218 = ref_edges;
    zT_219 = reg;
    zT_220 = visited;
    zT_221 = src_mid;
    zT_222 = p_7.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_218, zT_219, zT_220, zT_221, zT_222);
    zT_224 = ref_edges;
    zT_225 = reg;
    zT_226 = visited;
    zT_227 = src_mid;
    zT_228 = p_7.error_set;
    zF_BC6C7740_pruneTypeMarkByValu(zT_224, zT_225, zT_226, zT_227, zT_228);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
}

/* moduleIdForBasename */
unsigned int zF_D27A4A01_moduleIdForBasename(zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_D3EB6303_StringInterner* interner, zT_8F083A69_Slice_zT_0B42B2F8_u base) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_D3EB6303_StringInterner* zT_9;
    unsigned int zT_10;
    zT_6E8D187B_ModuleEntry* zT_11;
    zT_6E8D187B_ModuleEntry zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14 = {0};
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int zT_31;
    unsigned char* zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned char zT_37;
    unsigned char zT_39;
    unsigned int zT_41;
    zT_6E8D187B_ModuleEntry* zT_46;
    zT_6E8D187B_ModuleEntry zT_47;
    unsigned int zT_48;
    unsigned char* zT_49;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_6E8D187B_ModuleEntry* zT_55;
    zT_6E8D187B_ModuleEntry zT_56;
    unsigned int zT_57;
    unsigned int zT_59;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u p;
    unsigned int off;
    unsigned char eq;
    unsigned int j;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = interner;
    zT_11 = mods.ptr;
    zT_12 = zT_11[i];
    zT_10 = zT_12.path_id;
    zT_14 = zF_9134020D_stringInternerGet(zT_9, zT_10);
    p = zT_14;
    zT_16 = p.len;
    zT_18 = base.len;
    if ((unsigned char)(zT_16 >= zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_59 = i + (unsigned int)(1);
    i = zT_59;
    goto z_bb_1;
    z_bb_5:
    zT_22 = p.len;
    zT_24 = base.len;
    zT_25 = zT_22 - zT_24;
    off = zT_25;
    zT_27 = 1;
    eq = zT_27;
    zT_29 = 0;
    j = zT_29;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = base.len;
    if ((unsigned char)(j < zT_31)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = p.ptr;
    zT_34 = off + j;
    zT_35 = zT_33[zT_34];
    zT_36 = base.ptr;
    zT_37 = zT_36[j];
    if ((unsigned char)(zT_35 != zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    if ((unsigned char)(eq != (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_10:
    zT_41 = j + (unsigned int)(1);
    j = zT_41;
    goto z_bb_7;
    z_bb_11:
    zT_39 = 0;
    eq = zT_39;
    goto z_bb_9;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    if ((unsigned char)(off == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_46 = mods.ptr;
    zT_47 = zT_46[i];
    zT_48 = zT_47.id;
    return zT_48;
    z_bb_16:
    zT_49 = p.ptr;
    zT_51 = off - (unsigned int)(1);
    zT_52 = zT_49[zT_51];
    if ((unsigned char)(zT_52 == (unsigned char)(47))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_55 = mods.ptr;
    zT_56 = zT_55[i];
    zT_57 = zT_56.id;
    return zT_57;
    z_bb_18:
    goto z_bb_14;
}

/* phase_EmissionClassification */
void zF_2682C512_phase_EmissionClass(zT_5AB29387_CompilerContext* ctx) {
    zT_1317DCD6_C89SpellPlan* zT_1;
    zT_3E40CD83_Sand* zT_2;
    unsigned int zT_3;
    zT_69057089_CompilerAlloc* zT_5;
    zT_CA01C129_LirSlotArrayList zT_7;
    zT_7E7544E4_LirStream* zT_9;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_12;
    unsigned int zT_15;
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_7E7544E4_LirStream* zT_20;
    zT_E7714190_LirSlot zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_CA01C129_LirSlotArrayList zT_24;
    zT_E7714190_LirSlot* zT_25;
    zT_E7714190_LirSlot zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_BBC23664_LirFunction zT_29 = {0};
    unsigned int zT_31;
    zT_5D72FBF8_TempDeclArrayList zT_32;
    unsigned int zT_33;
    zT_338B7C76_TypeRegistry* zT_35;
    zT_21D3708C_U32ToU32Map* zT_36;
    unsigned int zT_37;
    zT_786E6CF2_EmissionClassificat* zT_39;
    zT_5D72FBF8_TempDeclArrayList zT_41;
    zT_1937645B_TempDecl* zT_42;
    zT_1937645B_TempDecl zT_43;
    unsigned int zT_46;
    zT_1317DCD6_C89SpellPlan* zT_47;
    zT_3E40CD83_Sand* zT_48;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    zT_BBC23664_LirFunction* zT_51;
    zT_69057089_CompilerAlloc* zT_53;
    zT_CA01C129_LirSlotArrayList zT_56;
    zT_E7714190_LirSlot* zT_57;
    zT_E7714190_LirSlot zT_58;
    unsigned int zT_62;
    zT_7E7544E4_LirStream* zT_63;
    unsigned int zT_66;
    zT_E1A783EF_GlobalDeclArrayList zT_67;
    unsigned int zT_68;
    zT_338B7C76_TypeRegistry* zT_70;
    zT_21D3708C_U32ToU32Map* zT_71;
    unsigned int zT_72;
    zT_786E6CF2_EmissionClassificat* zT_74;
    zT_E1A783EF_GlobalDeclArrayList zT_76;
    zT_54906056_ModuleGlobalDecl* zT_77;
    zT_54906056_ModuleGlobalDecl zT_78;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_82;
    zT_786E6CF2_EmissionClassificat* zT_83;
    zT_1317DCD6_C89SpellPlan* zT_86;
    zT_3E40CD83_Sand* zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_69057089_CompilerAlloc* zT_90;
    unsigned int ec_fi;
    zT_BBC23664_LirFunction ec_fn;
    unsigned int ec_hi;
    unsigned int ec_gi;
    zT_1 = &ctx->spell_plan;
    zT_5 = ctx->alloc;
    zT_2 = &zT_5->permanent;
    zT_7 = ctx->lir_slots;
    zT_3 = zT_7.len;
    zF_D67A348C_spellPlanInit(zT_1, zT_2, zT_3);
    zT_9 = &ctx->lir_stream;
    zT_12 = ctx->alloc;
    zT_10 = &zT_12->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_9, zT_10);
    zT_15 = 0;
    ec_fi = zT_15;
    goto z_bb_1;
    z_bb_1:
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    if ((unsigned char)(ec_fi < zT_17)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_20 = &ctx->lir_stream;
    zT_24 = ctx->lir_slots;
    zT_25 = zT_24.items;
    zT_26 = zT_25[ec_fi];
    zT_21 = zT_26;
    zT_27 = ctx->alloc;
    zT_22 = &zT_27->lir_read;
    zT_29 = zF_1B7118E0_lirStreamReadFuncti(zT_20, zT_21, zT_22);
    ec_fn = zT_29;
    zT_31 = 0;
    ec_hi = zT_31;
    goto z_bb_5;
    z_bb_3:
    zT_63 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_63);
    zT_66 = 0;
    ec_gi = zT_66;
    goto z_bb_9;
    z_bb_4:
    zT_62 = ec_fi + (unsigned int)(1);
    ec_fi = zT_62;
    goto z_bb_1;
    z_bb_5:
    zT_32 = ec_fn.hoisted_temps;
    zT_33 = zT_32.len;
    if ((unsigned char)(ec_hi < zT_33)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_35 = ctx->typereg;
    zT_39 = &ctx->emission_classif;
    zT_36 = &zT_39->needed_tuple_set;
    zT_41 = ec_fn.hoisted_temps;
    zT_42 = zT_41.items;
    zT_43 = zT_42[ec_hi];
    zT_37 = zT_43.type_id;
    zF_7845A68F_collectNeededTuples(zT_35, zT_36, zT_37);
    goto z_bb_8;
    z_bb_7:
    zT_47 = &ctx->spell_plan;
    zT_53 = ctx->alloc;
    zT_48 = &zT_53->permanent;
    zT_49 = ctx->typereg;
    zT_56 = ctx->lir_slots;
    zT_57 = zT_56.items;
    zT_58 = zT_57[ec_fi];
    zT_50 = zT_58.disk_offset;
    zT_51 = (zT_BBC23664_LirFunction*)&ec_fn;
    zF_72205F3D_spellPlanPlanFn(zT_47, zT_48, zT_49, zT_50, zT_51);
    goto z_bb_4;
    z_bb_8:
    zT_46 = ec_hi + (unsigned int)(1);
    ec_hi = zT_46;
    goto z_bb_5;
    z_bb_9:
    zT_67 = ctx->global_decls;
    zT_68 = zT_67.len;
    if ((unsigned char)(ec_gi < zT_68)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_70 = ctx->typereg;
    zT_74 = &ctx->emission_classif;
    zT_71 = &zT_74->needed_tuple_set;
    zT_76 = ctx->global_decls;
    zT_77 = zT_76.items;
    zT_78 = zT_77[ec_gi];
    zT_72 = zT_78.type_id;
    zF_7845A68F_collectNeededTuples(zT_70, zT_71, zT_72);
    goto z_bb_12;
    z_bb_11:
    zT_82 = ctx->typereg;
    zT_83 = &ctx->emission_classif;
    zF_0DE160E2_classifyTypeEmissio(zT_82, zT_83);
    zT_86 = &ctx->spell_plan;
    zT_90 = ctx->alloc;
    zT_87 = &zT_90->permanent;
    zT_88 = ctx->typereg;
    zF_869C84A7_spellPlanPlanTypeOr(zT_86, zT_87, zT_88);
    return;
    z_bb_12:
    zT_81 = ec_gi + (unsigned int)(1);
    ec_gi = zT_81;
    goto z_bb_9;
}

/* phase_C89Emission */
void zF_2268F8CE_phase_C89Emission(zT_5AB29387_CompilerContext* ctx) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_C98AF326_CompilerCli zT_6;
    unsigned char zT_7;
    unsigned char zT_9;
    zT_C98AF326_CompilerCli zT_10;
    unsigned char zT_11;
    zT_CEC2984A_NameMangler zT_14 = {0};
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_E1A783EF_GlobalDeclArrayList zT_18;
    unsigned int zT_19;
    zT_786E6CF2_EmissionClassificat zT_21;
    zT_21D3708C_U32ToU32Map zT_22;
    unsigned int zT_23;
    unsigned int zT_26;
    zT_D3EB6303_StringInterner* zT_27;
    zT_3E40CD83_Sand* zT_28;
    unsigned int zT_29;
    zT_69057089_CompilerAlloc* zT_31;
    zT_CEC2984A_NameMangler zT_33 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_34;
    zT_F4A81C2F_Opt_327 zT_35;
    zT_72C4E2ED_C89Emitter zT_37 = {0};
    zT_338B7C76_TypeRegistry* zT_38;
    zT_D3EB6303_StringInterner* zT_39;
    zT_CEC2984A_NameMangler* zT_40;
    zT_F85C5DED_DiagnosticCollector* zT_41;
    zT_9F514E82_SwitchCaseArrayList* zT_42;
    zT_B687BB96_U32ArrayList* zT_43;
    zT_3E40CD83_Sand* zT_44;
    zT_3E40CD83_Sand* zT_45;
    zT_21D3708C_U32ToU32Map* zT_46;
    zT_786E6CF2_EmissionClassificat* zT_47;
    zT_1317DCD6_C89SpellPlan* zT_48;
    unsigned char zT_49;
    int zT_54;
    int zT_55;
    zT_69057089_CompilerAlloc* zT_56;
    zT_69057089_CompilerAlloc* zT_58;
    zT_C98AF326_CompilerCli zT_63;
    zT_72C4E2ED_C89Emitter zT_65 = {0};
    zT_072B53A6_ModuleRegistry* zT_66;
    unsigned char* zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_71;
    zT_D3EB6303_StringInterner* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_072B53A6_ModuleRegistry* zT_74;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_76 = {0};
    unsigned int zT_78 = 0;
    zT_5AB29387_CompilerContext* zT_79;
    zT_E1A783EF_GlobalDeclArrayList* zT_81;
    zT_23133B1E_Slice_zT_54906056_M zT_83 = {0};
    zT_54906056_ModuleGlobalDecl* zT_85;
    unsigned int zT_87;
    zT_4065182A_ConstInitTable* zT_89;
    zT_B687BB96_U32ArrayList zT_90;
    unsigned int* zT_91;
    zT_B687BB96_U32ArrayList zT_92;
    unsigned int zT_93;
    zT_7E7544E4_LirStream* zT_94;
    zT_CA01C129_LirSlotArrayList zT_95;
    zT_E7714190_LirSlot* zT_96;
    zT_CA01C129_LirSlotArrayList zT_98;
    unsigned int zT_99;
    zT_69057089_CompilerAlloc* zT_100;
    zT_3E40CD83_Sand* zT_101;
    zT_7E7544E4_LirStream* zT_102;
    zT_3E40CD83_Sand* zT_103;
    zT_69057089_CompilerAlloc* zT_105;
    unsigned char* zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned int zT_110;
    zT_3E40CD83_Sand* zT_112;
    zT_69057089_CompilerAlloc* zT_113;
    zT_21D3708C_U32ToU32Map zT_115 = {0};
    zT_3E40CD83_Sand* zT_117;
    unsigned int zT_118;
    zT_69057089_CompilerAlloc* zT_119;
    zT_CA01C129_LirSlotArrayList zT_121;
    zT_21D3708C_U32ToU32Map zT_123 = {0};
    zT_3E40CD83_Sand* zT_125;
    zT_69057089_CompilerAlloc* zT_126;
    zT_A4CE86B7_U64ToU32Map zT_128 = {0};
    unsigned int zT_130;
    zT_CA01C129_LirSlotArrayList zT_131;
    unsigned int zT_132;
    zT_7E7544E4_LirStream* zT_135;
    zT_E7714190_LirSlot zT_136;
    zT_3E40CD83_Sand* zT_137;
    zT_CA01C129_LirSlotArrayList zT_139;
    zT_E7714190_LirSlot* zT_140;
    zT_E7714190_LirSlot zT_141;
    zT_69057089_CompilerAlloc* zT_142;
    zT_BBC23664_LirFunction zT_144 = {0};
    unsigned int zT_146;
    unsigned int zT_148;
    zT_5D72FBF8_TempDeclArrayList zT_149;
    unsigned int zT_150;
    zT_5D72FBF8_TempDeclArrayList zT_153;
    zT_1937645B_TempDecl* zT_154;
    zT_1937645B_TempDecl zT_155;
    zT_21D3708C_U32ToU32Map* zT_156;
    zT_338B7C76_TypeRegistry* zT_157;
    zT_A4CE86B7_U64ToU32Map* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_166;
    unsigned int zT_167;
    zT_338B7C76_TypeRegistry* zT_168;
    unsigned int zT_169;
    zT_21D3708C_U32ToU32Map* zT_172;
    zT_338B7C76_TypeRegistry* zT_173;
    zT_A4CE86B7_U64ToU32Map* zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_182;
    zT_CFE23D0A_LirParamArrayList zT_183;
    unsigned int zT_184;
    zT_CFE23D0A_LirParamArrayList zT_187;
    zT_8779209D_LirParam* zT_188;
    zT_8779209D_LirParam zT_189;
    zT_21D3708C_U32ToU32Map* zT_190;
    zT_338B7C76_TypeRegistry* zT_191;
    zT_A4CE86B7_U64ToU32Map* zT_192;
    unsigned int zT_193;
    unsigned int zT_194;
    unsigned int zT_200;
    unsigned int zT_202;
    zT_1CF28CA3_BasicBlockArrayList zT_203;
    unsigned int zT_204;
    zT_1CF28CA3_BasicBlockArrayList zT_207;
    zT_88A68B1A_BasicBlock* zT_208;
    zT_88A68B1A_BasicBlock zT_209;
    unsigned int zT_211;
    zT_DAE4631D_LirInstArrayList zT_212;
    unsigned int zT_213;
    zT_DAE4631D_LirInstArrayList zT_216;
    zT_6BA597BC_LirInst* zT_217;
    zT_6BA597BC_LirInst zT_218;
    unsigned int zT_220;
    unsigned char zT_222;
    unsigned int zT_224;
    zT_6BA597BC_LirInst zT_227;
    zT_BBC23664_LirFunction* zT_230;
    unsigned int zT_231;
    zT_3BFB1E70_CallDirectData zT_235 = {0};
    unsigned int zT_236;
    unsigned char zT_237;
    zT_6BA597BC_LirInst zT_240;
    zT_BBC23664_LirFunction* zT_243;
    unsigned int zT_244;
    zT_0624AC1B_TailCallData zT_248 = {0};
    unsigned int zT_249;
    unsigned char zT_250;
    zT_6BA597BC_LirInst zT_253;
    zT_3747923B_anon_110506 zT_256;
    unsigned int zT_257;
    unsigned char zT_258;
    zT_6BA597BC_LirInst zT_261;
    zT_E87F0ACC_anon_110688 zT_264;
    unsigned int zT_265;
    unsigned char zT_266;
    zT_6BA597BC_LirInst zT_269;
    zT_70821F7B_anon_110696 zT_272;
    unsigned int zT_273;
    unsigned char zT_274;
    unsigned char zT_277;
    zT_21D3708C_U32ToU32Map* zT_279;
    zT_6BA597BC_LirInst zT_289;
    unsigned char zT_291;
    unsigned int zT_292;
    unsigned int zT_295;
    zT_21D3708C_U32ToU32Map* zT_297;
    unsigned int zT_303;
    zT_6BA597BC_LirInst zT_308;
    unsigned char zT_310;
    zT_6BA597BC_LirInst zT_313;
    unsigned int zT_316;
    unsigned int zT_318;
    zT_6BA597BC_LirInst zT_321;
    zT_E87F0ACC_anon_110688 zT_324;
    unsigned int zT_325;
    zT_E87F0ACC_anon_110688 zT_327;
    unsigned int zT_328;
    zT_70821F7B_anon_110696 zT_330;
    unsigned int zT_331;
    zT_70821F7B_anon_110696 zT_333;
    unsigned int zT_334;
    unsigned int zT_336;
    unsigned int zT_338;
    zT_5D72FBF8_TempDeclArrayList zT_339;
    unsigned int zT_340;
    zT_5D72FBF8_TempDeclArrayList zT_343;
    zT_1937645B_TempDecl* zT_344;
    zT_1937645B_TempDecl zT_345;
    unsigned int zT_346;
    unsigned int zT_348;
    unsigned int zT_350;
    zT_338B7C76_TypeRegistry* zT_351;
    unsigned int zT_352;
    zT_338B7C76_TypeRegistry* zT_356;
    zT_D155D06D_Type* zT_357;
    unsigned int zT_358;
    zT_D155D06D_Type zT_359;
    unsigned int zT_360;
    unsigned char zT_363;
    unsigned int zT_364;
    zT_21D3708C_U32ToU32Map* zT_366;
    unsigned int zT_367;
    unsigned int zT_372;
    unsigned int zT_374;
    unsigned int zT_376;
    zT_072B53A6_ModuleRegistry* zT_378;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_380 = {0};
    unsigned int zT_382;
    zT_E1A783EF_GlobalDeclArrayList zT_383;
    unsigned int zT_384;
    zT_E1A783EF_GlobalDeclArrayList zT_387;
    zT_54906056_ModuleGlobalDecl* zT_388;
    zT_54906056_ModuleGlobalDecl zT_389;
    unsigned int zT_390;
    zT_338B7C76_TypeRegistry* zT_391;
    unsigned int zT_392;
    zT_338B7C76_TypeRegistry* zT_396;
    zT_D155D06D_Type* zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    zT_D155D06D_Type zT_400;
    unsigned int zT_401;
    unsigned char zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    zT_21D3708C_U32ToU32Map* zT_408;
    zT_338B7C76_TypeRegistry* zT_409;
    zT_A4CE86B7_U64ToU32Map* zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned int zT_419;
    zT_3E40CD83_Sand* zT_421;
    unsigned int zT_422;
    zT_69057089_CompilerAlloc* zT_423;
    zT_21D3708C_U32ToU32Map zT_427 = {0};
    zT_21D3708C_U32ToU32Map* zT_428;
    unsigned char zT_435;
    unsigned char zT_438;
    unsigned int zT_440;
    unsigned int zT_442;
    zT_6E8D187B_ModuleEntry* zT_445;
    zT_6E8D187B_ModuleEntry zT_446;
    unsigned int zT_447;
    zT_21D3708C_U32ToU32Map* zT_448;
    unsigned int zT_449;
    zT_BAEE192E_Opt_10 zT_451 = {0};
    unsigned char zT_452;
    unsigned int zT_455;
    unsigned int zT_457;
    zT_6E8D187B_ModuleEntry* zT_460;
    zT_6E8D187B_ModuleEntry zT_461;
    unsigned int zT_462;
    zT_21D3708C_U32ToU32Map* zT_464;
    unsigned int zT_465;
    zT_BAEE192E_Opt_10 zT_467 = {0};
    unsigned char zT_468;
    zT_21D3708C_U32ToU32Map* zT_469;
    zT_BAEE192E_Opt_10 zT_475 = {0};
    unsigned char zT_476;
    zT_21D3708C_U32ToU32Map* zT_477;
    unsigned int zT_478;
    unsigned char zT_482;
    unsigned int zT_484;
    unsigned int zT_486;
    unsigned int zT_488;
    unsigned int zT_490;
    zT_6E8D187B_ModuleEntry* zT_492;
    zT_6E8D187B_ModuleEntry zT_493;
    unsigned int zT_494;
    zT_21D3708C_U32ToU32Map* zT_497;
    unsigned int zT_498;
    zT_6E8D187B_ModuleEntry* zT_500;
    zT_6E8D187B_ModuleEntry zT_501;
    zT_BAEE192E_Opt_10 zT_503 = {0};
    unsigned char zT_504;
    unsigned char zT_507;
    unsigned int zT_509;
    zT_E1A783EF_GlobalDeclArrayList zT_510;
    unsigned int zT_511;
    zT_E1A783EF_GlobalDeclArrayList zT_514;
    zT_54906056_ModuleGlobalDecl* zT_515;
    zT_54906056_ModuleGlobalDecl zT_516;
    unsigned int zT_517;
    zT_6E8D187B_ModuleEntry* zT_518;
    zT_6E8D187B_ModuleEntry zT_519;
    unsigned int zT_520;
    unsigned char zT_522;
    unsigned char zT_523;
    unsigned char zT_526;
    unsigned int zT_528;
    zT_21D3708C_U32ToU32Map* zT_531;
    zT_6E8D187B_ModuleEntry* zT_538;
    zT_6E8D187B_ModuleEntry zT_539;
    unsigned int zT_540;
    unsigned int zT_544;
    zT_C98AF326_CompilerCli zT_545;
    unsigned char zT_546;
    zT_1317DCD6_C89SpellPlan zT_548;
    unsigned int* zT_549;
    zT_846744CC_Arr_unsigned_char_5 zT_551;
    unsigned int zT_553;
    zT_C98AF326_CompilerCli zT_555;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_556;
    zT_72C4E2ED_C89Emitter* zT_557;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_558;
    unsigned int zT_561;
    unsigned int zT_563;
    unsigned char zT_565;
    unsigned char* zT_568;
    unsigned char zT_569;
    int zT_570;
    unsigned int zT_572;
    int zT_573;
    unsigned int zT_575;
    unsigned char zT_576;
    int zT_577;
    unsigned int zT_579;
    unsigned char* zT_581;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_582;
    unsigned int zT_583;
    unsigned int zT_585;
    unsigned int zT_587;
    unsigned char zT_589;
    unsigned char* zT_592;
    unsigned char zT_593;
    int zT_594;
    unsigned int zT_596;
    int zT_597;
    unsigned int zT_599;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    int zT_605;
    unsigned char* zT_606;
    unsigned int zT_607;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_608;
    unsigned int zT_610 = 0;
    unsigned char* zT_614;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_615;
    unsigned int zT_616;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_617;
    zT_63BE4FF5_BufferedWriter zT_621 = {0};
    unsigned int zT_622;
    zT_63BE4FF5_BufferedWriter zT_623 = {0};
    zT_72C4E2ED_C89Emitter* zT_624;
    zT_338B7C76_TypeRegistry* zT_625;
    unsigned int* zT_626;
    zT_63BE4FF5_BufferedWriter* zT_629;
    zT_72C4E2ED_C89Emitter* zT_630;
    unsigned int zT_632;
    zT_072B53A6_ModuleRegistry* zT_634;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_636 = {0};
    zT_CA01C129_LirSlotArrayList zT_639;
    unsigned int zT_640;
    int zT_641;
    zT_3E40CD83_Sand* zT_644;
    zT_69057089_CompilerAlloc* zT_647;
    unsigned int zT_651;
    zT_38349D67_EU_052 zT_654 = {0};
    unsigned char zT_655;
    unsigned char* zT_656;
    unsigned int* zT_658;
    zT_3E40CD83_Sand* zT_660;
    zT_69057089_CompilerAlloc* zT_663;
    unsigned int zT_667;
    zT_38349D67_EU_052 zT_670 = {0};
    unsigned char zT_671;
    unsigned char* zT_672;
    unsigned int* zT_674;
    unsigned int zT_676;
    unsigned int zT_678;
    unsigned int zT_680;
    int zT_681;
    unsigned int zT_683;
    unsigned int zT_685;
    zT_CA01C129_LirSlotArrayList zT_688;
    zT_E7714190_LirSlot* zT_689;
    zT_E7714190_LirSlot zT_690;
    unsigned int zT_691;
    unsigned int zT_694;
    unsigned int zT_696;
    unsigned int zT_697;
    unsigned int zT_699;
    unsigned int zT_700;
    int zT_701;
    unsigned int zT_703;
    unsigned int zT_705;
    unsigned int zT_706;
    unsigned int zT_708;
    unsigned int zT_710;
    unsigned int zT_711;
    int zT_712;
    unsigned int zT_714;
    zT_3E40CD83_Sand* zT_716;
    zT_69057089_CompilerAlloc* zT_719;
    zT_38349D67_EU_052 zT_724 = {0};
    unsigned char zT_725;
    unsigned char* zT_726;
    zT_E7714190_LirSlot* zT_728;
    unsigned int zT_729;
    zT_CA01C129_LirSlotArrayList zT_732;
    zT_E7714190_LirSlot* zT_733;
    zT_E7714190_LirSlot zT_734;
    unsigned int zT_736;
    unsigned int zT_739;
    unsigned int zT_742;
    unsigned int zT_743;
    unsigned int zT_744;
    unsigned int zT_746;
    unsigned int zT_747;
    int zT_748;
    unsigned int zT_750;
    zT_CA01C129_LirSlotArrayList* zT_751;
    zT_CA01C129_LirSlotArrayList* zT_753;
    unsigned int zT_755;
    unsigned int zT_757;
    unsigned int zT_759;
    zT_6E8D187B_ModuleEntry* zT_762;
    zT_6E8D187B_ModuleEntry zT_763;
    zT_CA01C129_LirSlotArrayList zT_765;
    unsigned int zT_766;
    unsigned char zT_768;
    zT_CA01C129_LirSlotArrayList zT_769;
    zT_E7714190_LirSlot* zT_770;
    zT_E7714190_LirSlot zT_771;
    unsigned int zT_772;
    unsigned int zT_773;
    unsigned int zT_776;
    zT_21D3708C_U32ToU32Map* zT_777;
    unsigned int zT_778;
    zT_BAEE192E_Opt_10 zT_781 = {0};
    unsigned char zT_782;
    zT_72C4E2ED_C89Emitter* zT_786;
    unsigned int zT_787;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_790 = {0};
    unsigned int zT_792;
    unsigned int zT_796;
    unsigned char* zT_803;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_804;
    unsigned int zT_805;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_806;
    unsigned int zT_810;
    unsigned int zT_812;
    unsigned int zT_814;
    unsigned char zT_816;
    unsigned char* zT_819;
    unsigned char zT_820;
    int zT_821;
    unsigned int zT_823;
    int zT_824;
    unsigned int zT_826;
    unsigned char zT_827;
    int zT_828;
    unsigned int zT_830;
    unsigned int zT_832;
    unsigned int zT_834;
    unsigned char zT_836;
    unsigned char* zT_839;
    unsigned char zT_840;
    int zT_841;
    unsigned int zT_843;
    int zT_844;
    unsigned int zT_846;
    unsigned char* zT_848;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_849;
    unsigned int zT_850;
    unsigned int zT_852;
    unsigned int zT_854;
    unsigned char zT_856;
    unsigned char* zT_859;
    unsigned char zT_860;
    int zT_861;
    unsigned int zT_863;
    int zT_864;
    unsigned int zT_866;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_868;
    int zT_872;
    unsigned char* zT_873;
    unsigned int zT_874;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_875;
    unsigned int zT_877 = 0;
    unsigned char* zT_881;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_882;
    unsigned int zT_883;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_884;
    zT_63BE4FF5_BufferedWriter zT_888 = {0};
    unsigned int zT_889;
    zT_63BE4FF5_BufferedWriter zT_890 = {0};
    unsigned int zT_892;
    unsigned int zT_893;
    unsigned int zT_895;
    unsigned int zT_897;
    zT_072B53A6_ModuleRegistry* zT_899;
    unsigned int* zT_900;
    unsigned int* zT_901;
    unsigned int zT_902;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_903;
    zT_B687BB96_U32ArrayList zT_905;
    unsigned int* zT_906;
    zT_B687BB96_U32ArrayList zT_907;
    unsigned int zT_908;
    int zT_909;
    unsigned int* zT_910;
    unsigned int zT_911;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_912;
    zT_3E40CD83_Sand* zT_914;
    zT_69057089_CompilerAlloc* zT_917;
    unsigned int zT_921;
    zT_38349D67_EU_052 zT_924 = {0};
    unsigned char zT_925;
    unsigned char* zT_926;
    unsigned int* zT_929;
    unsigned int zT_931;
    unsigned int zT_933;
    unsigned int zT_935;
    unsigned int* zT_938;
    unsigned int zT_939;
    unsigned int zT_940;
    zT_21D3708C_U32ToU32Map* zT_942;
    unsigned int zT_943;
    zT_BAEE192E_Opt_10 zT_945 = {0};
    unsigned char zT_946;
    unsigned char zT_949;
    unsigned int zT_951;
    unsigned int zT_953;
    unsigned char zT_955;
    unsigned int zT_957;
    unsigned int zT_961;
    unsigned int zT_963;
    unsigned int zT_965;
    unsigned int zT_967;
    zT_6E8D187B_ModuleEntry* zT_970;
    zT_6E8D187B_ModuleEntry zT_971;
    unsigned int zT_972;
    unsigned int zT_973;
    zT_21D3708C_U32ToU32Map* zT_975;
    unsigned int zT_976;
    zT_BAEE192E_Opt_10 zT_978 = {0};
    unsigned char zT_979;
    zT_21D3708C_U32ToU32Map* zT_981;
    unsigned int zT_984;
    zT_BAEE192E_Opt_10 zT_988 = {0};
    unsigned char zT_989;
    unsigned char zT_992;
    unsigned int zT_994;
    unsigned int zT_996;
    unsigned char zT_998;
    unsigned int zT_1000;
    unsigned int zT_1004;
    unsigned int zT_1006;
    int zT_1008;
    unsigned int* zT_1009;
    unsigned int zT_1010;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1011;
    zT_72C4E2ED_C89Emitter* zT_1012;
    unsigned int zT_1013;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1014;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1015;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1016;
    unsigned int* zT_1017;
    zT_63BE4FF5_BufferedWriter* zT_1020;
    zT_72C4E2ED_C89Emitter* zT_1021;
    unsigned int zT_1023;
    unsigned char* zT_1025;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1026;
    unsigned int zT_1027;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1028;
    zT_846744CC_Arr_unsigned_char_5 zT_1030;
    unsigned int zT_1032;
    unsigned int zT_1034;
    unsigned int zT_1036;
    unsigned char zT_1038;
    unsigned char* zT_1041;
    unsigned char zT_1042;
    int zT_1043;
    unsigned int zT_1045;
    int zT_1046;
    unsigned int zT_1048;
    unsigned char zT_1049;
    int zT_1050;
    unsigned int zT_1052;
    unsigned int zT_1054;
    unsigned int zT_1056;
    unsigned char zT_1058;
    unsigned char* zT_1061;
    unsigned char zT_1062;
    int zT_1063;
    unsigned int zT_1065;
    int zT_1066;
    unsigned int zT_1068;
    unsigned char* zT_1070;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1071;
    unsigned int zT_1072;
    unsigned int zT_1074;
    unsigned int zT_1076;
    unsigned char zT_1078;
    unsigned char* zT_1081;
    unsigned char zT_1082;
    int zT_1083;
    unsigned int zT_1085;
    int zT_1086;
    unsigned int zT_1088;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1090;
    int zT_1094;
    unsigned char* zT_1095;
    unsigned int zT_1096;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1097;
    unsigned int zT_1099 = 0;
    unsigned char* zT_1103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1104;
    unsigned int zT_1105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1106;
    zT_63BE4FF5_BufferedWriter zT_1110 = {0};
    unsigned int zT_1111;
    zT_63BE4FF5_BufferedWriter zT_1112 = {0};
    zT_72C4E2ED_C89Emitter* zT_1113;
    unsigned int zT_1114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1115;
    zT_63BE4FF5_BufferedWriter* zT_1118;
    zT_72C4E2ED_C89Emitter* zT_1119;
    unsigned int zT_1121;
    unsigned char* zT_1123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1124;
    unsigned int zT_1125;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1126;
    int zT_1127;
    unsigned int zT_1129;
    zT_72C4E2ED_C89Emitter* zT_1130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1131;
    unsigned char zT_1132;
    zT_074080EA_WinProfile zT_1133;
    zT_C98AF326_CompilerCli zT_1135;
    zT_C98AF326_CompilerCli zT_1137;
    zT_7E7544E4_LirStream* zT_1139;
    zT_6B0A7D14_AstStore* zT_1141;
    zT_63BE4FF5_BufferedWriter zT_1144 = {0};
    zT_63BE4FF5_BufferedWriter zT_1145 = {0};
    zT_63BE4FF5_BufferedWriter* zT_1146;
    zT_63BE4FF5_BufferedWriter* zT_1148;
    zT_072B53A6_ModuleRegistry* zT_1151;
    zT_3E40CD83_Sand* zT_1152;
    zT_69057089_CompilerAlloc* zT_1154;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1156 = {0};
    zT_72C4E2ED_C89Emitter* zT_1157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1158;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_1159;
    unsigned char* zT_1162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1163;
    unsigned int zT_1164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1165;
    zT_63BE4FF5_BufferedWriter* zT_1166;
    zT_72C4E2ED_C89Emitter* zT_1167;
    zT_7E7544E4_LirStream* zT_1169;
    zT_6B0A7D14_AstStore* zT_1171;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_CEC2984A_NameMangler mangler;
    unsigned int mangler_hint;
    zT_72C4E2ED_C89Emitter emitter;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_fmt_base;
    zT_23133B1E_Slice_zT_54906056_M gd_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u module_name;
    zT_21D3708C_U32ToU32Map ts_ref_set;
    zT_21D3708C_U32ToU32Map ref_edges;
    zT_A4CE86B7_U64ToU32Map type_visited;
    unsigned int ts_fi;
    zT_BBC23664_LirFunction ts_fn;
    unsigned int ts_src;
    unsigned int ts_tti;
    zT_DDCD424B_Slice_zT_6E8D187B_M ri_mods;
    unsigned int gt_i;
    zT_1937645B_TempDecl ts_hty;
    unsigned int ts_pi;
    zT_8779209D_LirParam ts_pt;
    unsigned int ts_bi;
    zT_88A68B1A_BasicBlock ts_blk;
    unsigned int ts_ii;
    zT_6BA597BC_LirInst ts_inst;
    unsigned int ts_tg;
    unsigned char ts_edge_has;
    unsigned int ts_edge_dst;
    zT_3BFB1E70_CallDirectData ts_cd;
    zT_0624AC1B_TailCallData ts_tc;
    unsigned int ts_name_id;
    unsigned int ts_tmp;
    unsigned int ts_tid;
    unsigned int ts_tj;
    zT_1937645B_TempDecl ts_ht;
    zT_D155D06D_Type ts_ty;
    zT_54906056_ModuleGlobalDecl gt_g;
    zT_21D3708C_U32ToU32Map reachable;
    unsigned char rf_changed;
    zT_D155D06D_Type gt_ty;
    unsigned int rf_s;
    unsigned int ri_i;
    unsigned int rf_src;
    unsigned int rf_d;
    unsigned int rf_dst;
    unsigned char ri_has;
    unsigned int gd_ri;
    zT_54906056_ModuleGlobalDecl gd_g;
    unsigned int* sorted;
    zT_846744CC_Arr_unsigned_char_5 hpath;
    unsigned int hp;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int hi;
    zT_63BE4FF5_BufferedWriter cwriter;
    zT_3CB0179A_Slice_zT_05F374B1_u c_incs;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u hfn;
    unsigned int hfi;
    unsigned int fd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_63BE4FF5_BufferedWriter hw;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int slot_count;
    unsigned int* grp_counts;
    unsigned int fn_cursor;
    unsigned int mi;
    unsigned int* grp_cursor;
    unsigned int gci;
    unsigned int gsi;
    unsigned int gsmid;
    unsigned int gacc;
    zT_E7714190_LirSlot* grouped;
    zT_E7714190_LirSlot gslot;
    unsigned int gdst;
    zT_6E8D187B_ModuleEntry m;
    unsigned int fn_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    unsigned int hp2;
    unsigned int hi2;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hext;
    unsigned int hx;
    unsigned int fd2;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg2;
    zT_63BE4FF5_BufferedWriter hw2;
    unsigned int dep_start;
    unsigned int dep_end;
    zT_3CB0179A_Slice_zT_05F374B1_u dep_ids;
    zT_3CB0179A_Slice_zT_05F374B1_u m_c_incs;
    unsigned char* inc_raw;
    unsigned int* inc_arr;
    unsigned int inc_n;
    unsigned int di0;
    unsigned int dd0;
    unsigned int vd0;
    unsigned char dup0;
    unsigned int dj0;
    unsigned int vdd0;
    zT_3CB0179A_Slice_zT_05F374B1_u inc_slice;
    zT_846744CC_Arr_unsigned_char_5 cpath;
    unsigned int cp2;
    unsigned int ci2;
    unsigned char dup1;
    unsigned int dj1;
    unsigned int cbi;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    unsigned int cx;
    unsigned int cfd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg3;
    zT_63BE4FF5_BufferedWriter cw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2_m;
    zT_2 = "C\n";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->cli;
    zT_7 = zT_6.dump_c89;
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = ctx->cli;
    zT_11 = zT_10.output_dir_set;
    zT_9 = !zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_9 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    mangler = zT_14;
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    zT_18 = ctx->global_decls;
    zT_19 = zT_18.len;
    zT_21 = ctx->emission_classif;
    zT_22 = zT_21.pointer_only_map;
    zT_23 = zT_22.count;
    zT_26 = (unsigned int)((unsigned int)(zT_17 + zT_19) + zT_23) + (unsigned int)(32);
    mangler_hint = zT_26;
    zT_27 = ctx->interner;
    zT_31 = ctx->alloc;
    zT_28 = &zT_31->emission;
    zT_29 = mangler_hint;
    zT_33 = zF_27DA3900_nameManglerInit(zT_27, zT_28, zT_29);
    mangler = zT_33;
    zT_34 = &ctx->exported;
    zT_35.has_value = 1;
    zT_35.value = zT_34;
    mangler.exported = zT_35;
    emitter = zT_37;
    zT_38 = ctx->typereg;
    zT_39 = ctx->interner;
    zT_40 = (zT_CEC2984A_NameMangler*)&mangler;
    zT_41 = ctx->diag;
    zT_54 = 0;
    zT_42 = (zT_9F514E82_SwitchCaseArrayList*)zT_54;
    zT_55 = 0;
    zT_43 = (zT_B687BB96_U32ArrayList*)zT_55;
    zT_56 = ctx->alloc;
    zT_44 = &zT_56->scratch;
    zT_58 = ctx->alloc;
    zT_45 = &zT_58->emission;
    zT_46 = &ctx->error_code_registry;
    zT_47 = &ctx->emission_classif;
    zT_48 = &ctx->spell_plan;
    zT_63 = ctx->cli;
    zT_49 = zT_63.safe_checks;
    zT_65 = zF_63D58A2B_c89EmitterInit(zT_38, zT_39, zT_40, zT_41, zT_42, zT_43, zT_44, zT_45, zT_46, zT_47, zT_48, zT_49);
    emitter = zT_65;
    zT_66 = ctx->module_reg;
    emitter.module_reg = zT_66;
    zT_68 = "std_fmt.zig";
    zT_70 = 11;
    zT_69.ptr = (unsigned char*)zT_68;
    zT_69.len = zT_70;
    c89_fmt_base = zT_69;
    zT_74 = ctx->module_reg;
    zT_76 = zF_3452C137_moduleRegistryGetMo(zT_74);
    zT_71 = zT_76;
    zT_72 = ctx->interner;
    zT_73 = c89_fmt_base;
    zT_78 = zF_D27A4A01_moduleIdForBasename(zT_71, zT_72, zT_73);
    emitter.std_fmt_module_id = zT_78;
    zT_79 = ctx;
    zF_FC691B4D_errorCodeRegistryFi(zT_79);
    zT_81 = &ctx->global_decls;
    zT_83 = zF_6ACCE52D_globalDeclArrayList(zT_81);
    gd_slice = zT_83;
    zT_85 = gd_slice.ptr;
    emitter.global_decls = zT_85;
    zT_87 = gd_slice.len;
    emitter.global_decls_len = (unsigned int)((unsigned int)zT_87);
    zT_89 = &ctx->const_inits;
    emitter.const_inits = zT_89;
    zT_90 = ctx->module_init_order;
    zT_91 = zT_90.items;
    emitter.module_init_order = zT_91;
    zT_92 = ctx->module_init_order;
    zT_93 = zT_92.len;
    emitter.module_init_order_len = zT_93;
    zT_94 = &ctx->lir_stream;
    emitter.spill = zT_94;
    zT_95 = ctx->lir_slots;
    zT_96 = zT_95.items;
    emitter.fn_slots = zT_96;
    emitter.fn_slots_start = (unsigned int)(0);
    zT_98 = ctx->lir_slots;
    zT_99 = zT_98.len;
    emitter.fn_slots_len = zT_99;
    zT_100 = ctx->alloc;
    zT_101 = &zT_100->lir_read;
    emitter.spill_arena = zT_101;
    zT_102 = &ctx->lir_stream;
    zT_105 = ctx->alloc;
    zT_103 = &zT_105->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_102, zT_103);
    zT_108 = "output";
    zT_110 = 6;
    zT_109.ptr = (unsigned char*)zT_108;
    zT_109.len = zT_110;
    module_name = zT_109;
    zT_113 = ctx->alloc;
    zT_112 = &zT_113->emission;
    zT_115 = zF_58BDA2DE_u32ToU32MapInit(zT_112);
    ts_ref_set = zT_115;
    zT_119 = ctx->alloc;
    zT_117 = &zT_119->emission;
    zT_121 = ctx->lir_slots;
    zT_118 = zT_121.len;
    zT_123 = zF_619D56E6_u32ToU32MapInitCap(zT_117, zT_118);
    ref_edges = zT_123;
    zT_126 = ctx->alloc;
    zT_125 = &zT_126->emission;
    zT_128 = zF_986226E1_u64ToU32MapInit(zT_125);
    type_visited = zT_128;
    zT_130 = 0;
    ts_fi = zT_130;
    goto z_bb_6;
    z_bb_6:
    zT_131 = ctx->lir_slots;
    zT_132 = zT_131.len;
    if ((unsigned char)(ts_fi < zT_132)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_135 = &ctx->lir_stream;
    zT_139 = ctx->lir_slots;
    zT_140 = zT_139.items;
    zT_141 = zT_140[ts_fi];
    zT_136 = zT_141;
    zT_142 = ctx->alloc;
    zT_137 = &zT_142->lir_read;
    zT_144 = zF_1B7118E0_lirStreamReadFuncti(zT_135, zT_136, zT_137);
    ts_fn = zT_144;
    zT_146 = ts_fn.module_id;
    ts_src = zT_146;
    zT_148 = 0;
    ts_tti = zT_148;
    goto z_bb_10;
    z_bb_8:
    emitter.ts_ref_set = ts_ref_set;
    zT_378 = ctx->module_reg;
    zT_380 = zF_3452C137_moduleRegistryGetMo(zT_378);
    ri_mods = zT_380;
    zT_382 = 0;
    gt_i = zT_382;
    goto z_bb_75;
    z_bb_9:
    zT_376 = ts_fi + (unsigned int)(1);
    ts_fi = zT_376;
    goto z_bb_6;
    z_bb_10:
    zT_149 = ts_fn.hoisted_temps;
    zT_150 = zT_149.len;
    if ((unsigned char)(ts_tti < zT_150)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_153 = ts_fn.hoisted_temps;
    zT_154 = zT_153.items;
    zT_155 = zT_154[ts_tti];
    ts_hty = zT_155;
    zT_156 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_157 = ctx->typereg;
    zT_158 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_159 = ts_src;
    zT_160 = ts_hty.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_156, zT_157, zT_158, zT_159, zT_160);
    goto z_bb_13;
    z_bb_12:
    zT_167 = ts_fn.return_type;
    zT_168 = ctx->typereg;
    zT_169 = zT_168->types_len;
    if ((unsigned char)(zT_167 < (unsigned int)((unsigned int)zT_169))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_166 = ts_tti + (unsigned int)(1);
    ts_tti = zT_166;
    goto z_bb_10;
    z_bb_14:
    zT_172 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_173 = ctx->typereg;
    zT_174 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_175 = ts_src;
    zT_176 = ts_fn.return_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_172, zT_173, zT_174, zT_175, zT_176);
    goto z_bb_15;
    z_bb_15:
    zT_182 = 0;
    ts_pi = zT_182;
    goto z_bb_16;
    z_bb_16:
    zT_183 = ts_fn.params;
    zT_184 = zT_183.len;
    if ((unsigned char)(ts_pi < zT_184)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_187 = ts_fn.params;
    zT_188 = zT_187.items;
    zT_189 = zT_188[ts_pi];
    ts_pt = zT_189;
    zT_190 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_191 = ctx->typereg;
    zT_192 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_193 = ts_src;
    zT_194 = ts_pt.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_190, zT_191, zT_192, zT_193, zT_194);
    goto z_bb_19;
    z_bb_18:
    zT_202 = 0;
    ts_bi = zT_202;
    goto z_bb_20;
    z_bb_19:
    zT_200 = ts_pi + (unsigned int)(1);
    ts_pi = zT_200;
    goto z_bb_16;
    z_bb_20:
    zT_203 = ts_fn.blocks;
    zT_204 = zT_203.len;
    if ((unsigned char)(ts_bi < zT_204)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_207 = ts_fn.blocks;
    zT_208 = zT_207.items;
    zT_209 = zT_208[ts_bi];
    ts_blk = zT_209;
    zT_211 = 0;
    ts_ii = zT_211;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_9;
    z_bb_23:
    zT_374 = ts_bi + (unsigned int)(1);
    ts_bi = zT_374;
    goto z_bb_20;
    z_bb_24:
    zT_212 = ts_blk.insts;
    zT_213 = zT_212.len;
    if ((unsigned char)(ts_ii < zT_213)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_216 = ts_blk.insts;
    zT_217 = zT_216.items;
    zT_218 = zT_217[ts_ii];
    ts_inst = zT_218;
    zT_220 = ts_inst.tag;
    ts_tg = zT_220;
    zT_222 = 0;
    ts_edge_has = zT_222;
    zT_224 = 0;
    ts_edge_dst = zT_224;
    zT_227.tag = 23;
    if ((unsigned char)(ts_tg == zT_227.tag)) goto z_bb_28; else goto z_bb_30;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_372 = ts_ii + (unsigned int)(1);
    ts_ii = zT_372;
    goto z_bb_24;
    z_bb_28:
    zT_230 = (zT_BBC23664_LirFunction*)&ts_fn;
    zT_231 = ts_inst.payload.jump._0;
    zT_235 = zF_75DE985C_lirSideGetCallDirec(zT_230, zT_231);
    ts_cd = zT_235;
    zT_236 = ts_cd.module_id;
    ts_edge_dst = zT_236;
    zT_237 = 1;
    ts_edge_has = zT_237;
    goto z_bb_29;
    z_bb_29:
    if ((unsigned char)(ts_edge_has != (unsigned char)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_30:
    zT_240.tag = 27;
    if ((unsigned char)(ts_tg == zT_240.tag)) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_243 = (zT_BBC23664_LirFunction*)&ts_fn;
    zT_244 = ts_inst.payload.jump._0;
    zT_248 = zF_1AB3807F_lirSideGetTailCall(zT_243, zT_244);
    ts_tc = zT_248;
    zT_249 = ts_tc.module_id;
    ts_edge_dst = zT_249;
    zT_250 = 1;
    ts_edge_has = zT_250;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_253.tag = 28;
    if ((unsigned char)(ts_tg == zT_253.tag)) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_256 = ts_inst.payload.func_ref._0;
    zT_257 = zT_256.module_id;
    ts_edge_dst = zT_257;
    zT_258 = 1;
    ts_edge_has = zT_258;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_261.tag = 54;
    if ((unsigned char)(ts_tg == zT_261.tag)) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_264 = ts_inst.payload.load_global._0;
    zT_265 = zT_264.module_id;
    ts_edge_dst = zT_265;
    zT_266 = 1;
    ts_edge_has = zT_266;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_269.tag = 55;
    if ((unsigned char)(ts_tg == zT_269.tag)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_272 = ts_inst.payload.store_global._0;
    zT_273 = zT_272.module_id;
    ts_edge_dst = zT_273;
    zT_274 = 1;
    ts_edge_has = zT_274;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_277 = ts_edge_dst != ts_src;
    goto z_bb_44;
    z_bb_43:
    zT_277 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_277) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_279 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zF_26476265_u32ToU32MapPut(zT_279, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + ts_edge_dst), (unsigned int)(1));
    goto z_bb_46;
    z_bb_46:
    zT_289.tag = 57;
    if ((unsigned char)(ts_tg == zT_289.tag)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_292 = emitter.std_fmt_module_id;
    zT_291 = zT_292 != (unsigned int)(4294967295u);
    goto z_bb_49;
    z_bb_48:
    zT_291 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_291) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_295 = emitter.std_fmt_module_id;
    if ((unsigned char)(zT_295 != ts_src)) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    zT_308.tag = 54;
    if ((unsigned char)(ts_tg != zT_308.tag)) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_297 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_303 = emitter.std_fmt_module_id;
    zF_26476265_u32ToU32MapPut(zT_297, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + zT_303), (unsigned int)(1));
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    zT_313.tag = 55;
    zT_310 = ts_tg != zT_313.tag;
    goto z_bb_56;
    z_bb_55:
    zT_310 = 0;
    goto z_bb_56;
    z_bb_56:
    if (zT_310) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    goto z_bb_27;
    z_bb_58:
    zT_316 = 0;
    ts_name_id = zT_316;
    zT_318 = 0;
    ts_tmp = zT_318;
    zT_321.tag = 54;
    if ((unsigned char)(ts_tg == zT_321.tag)) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    zT_324 = ts_inst.payload.load_global._0;
    zT_325 = zT_324.name_id;
    ts_name_id = zT_325;
    zT_327 = ts_inst.payload.load_global._0;
    zT_328 = zT_327.result;
    ts_tmp = zT_328;
    goto z_bb_60;
    z_bb_60:
    zT_336 = 0;
    ts_tid = zT_336;
    zT_338 = 0;
    ts_tj = zT_338;
    goto z_bb_62;
    z_bb_61:
    zT_330 = ts_inst.payload.store_global._0;
    zT_331 = zT_330.name_id;
    ts_name_id = zT_331;
    zT_333 = ts_inst.payload.store_global._0;
    zT_334 = zT_333.value;
    ts_tmp = zT_334;
    goto z_bb_60;
    z_bb_62:
    zT_339 = ts_fn.hoisted_temps;
    zT_340 = zT_339.len;
    if ((unsigned char)(ts_tj < zT_340)) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_343 = ts_fn.hoisted_temps;
    zT_344 = zT_343.items;
    zT_345 = zT_344[ts_tj];
    ts_ht = zT_345;
    zT_346 = ts_ht.temp_id;
    if ((unsigned char)(zT_346 == ts_tmp)) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    zT_351 = ctx->typereg;
    zT_352 = zT_351->types_len;
    if ((unsigned char)(ts_tid >= (unsigned int)((unsigned int)zT_352))) goto z_bb_68; else goto z_bb_69;
    z_bb_65:
    zT_350 = ts_tj + (unsigned int)(1);
    ts_tj = zT_350;
    goto z_bb_62;
    z_bb_66:
    zT_348 = ts_ht.type_id;
    ts_tid = zT_348;
    goto z_bb_64;
    z_bb_67:
    goto z_bb_65;
    z_bb_68:
    goto z_bb_27;
    z_bb_69:
    zT_356 = ctx->typereg;
    zT_357 = zT_356->types_items;
    zT_358 = (unsigned int)ts_tid;
    zT_359 = zT_357[zT_358];
    ts_ty = zT_359;
    zT_360 = ts_ty.name_id;
    if ((unsigned char)(zT_360 != (unsigned int)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_364 = ts_ty.name_id;
    zT_363 = zT_364 == ts_name_id;
    goto z_bb_72;
    z_bb_71:
    zT_363 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_363) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_366 = (zT_21D3708C_U32ToU32Map*)&ts_ref_set;
    zT_367 = ts_tid;
    zF_26476265_u32ToU32MapPut(zT_366, zT_367, (unsigned int)(1));
    goto z_bb_74;
    z_bb_74:
    goto z_bb_27;
    z_bb_75:
    zT_383 = ctx->global_decls;
    zT_384 = zT_383.len;
    if ((unsigned char)(gt_i < zT_384)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_387 = ctx->global_decls;
    zT_388 = zT_387.items;
    zT_389 = zT_388[gt_i];
    gt_g = zT_389;
    zT_390 = gt_g.type_id;
    zT_391 = ctx->typereg;
    zT_392 = zT_391->types_len;
    if ((unsigned char)(zT_390 >= (unsigned int)((unsigned int)zT_392))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_423 = ctx->alloc;
    zT_421 = &zT_423->emission;
    zT_422 = ri_mods.len;
    zT_427 = zF_619D56E6_u32ToU32MapInitCap(zT_421, zT_422);
    reachable = zT_427;
    zT_428 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zF_26476265_u32ToU32MapPut(zT_428, (unsigned int)(0), (unsigned int)(1));
    zT_435 = 1;
    rf_changed = zT_435;
    goto z_bb_86;
    z_bb_78:
    zT_419 = gt_i + (unsigned int)(1);
    gt_i = zT_419;
    goto z_bb_75;
    z_bb_79:
    goto z_bb_78;
    z_bb_80:
    zT_396 = ctx->typereg;
    zT_397 = zT_396->types_items;
    zT_398 = gt_g.type_id;
    zT_399 = (unsigned int)zT_398;
    zT_400 = zT_397[zT_399];
    gt_ty = zT_400;
    zT_401 = gt_ty.name_id;
    if ((unsigned char)(zT_401 != (unsigned int)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_405 = gt_ty.name_id;
    zT_406 = gt_g.name_id;
    zT_404 = zT_405 == zT_406;
    goto z_bb_83;
    z_bb_82:
    zT_404 = 0;
    goto z_bb_83;
    z_bb_83:
    if (zT_404) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    goto z_bb_78;
    z_bb_85:
    zT_408 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_409 = ctx->typereg;
    zT_410 = (zT_A4CE86B7_U64ToU32Map*)&type_visited;
    zT_411 = gt_g.module_id;
    zT_412 = gt_g.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_408, zT_409, zT_410, zT_411, zT_412);
    goto z_bb_78;
    z_bb_86:
    if ((unsigned char)(rf_changed != (unsigned char)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_438 = 0;
    rf_changed = zT_438;
    zT_440 = 0;
    rf_s = zT_440;
    goto z_bb_90;
    z_bb_88:
    zT_488 = 0;
    ri_i = zT_488;
    goto z_bb_106;
    z_bb_89:
    goto z_bb_86;
    z_bb_90:
    zT_442 = ri_mods.len;
    if ((unsigned char)(rf_s < zT_442)) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_445 = ri_mods.ptr;
    zT_446 = zT_445[rf_s];
    zT_447 = zT_446.id;
    rf_src = zT_447;
    zT_448 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_449 = rf_src;
    zT_451 = zF_F3EE5998_u32ToU32MapGet(zT_448, zT_449);
    zT_452 = zT_451.has_value;
    if ((unsigned char)(!zT_452)) goto z_bb_94; else goto z_bb_95;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_486 = rf_s + (unsigned int)(1);
    rf_s = zT_486;
    goto z_bb_90;
    z_bb_94:
    goto z_bb_93;
    z_bb_95:
    zT_455 = 0;
    rf_d = zT_455;
    goto z_bb_96;
    z_bb_96:
    zT_457 = ri_mods.len;
    if ((unsigned char)(rf_d < zT_457)) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_460 = ri_mods.ptr;
    zT_461 = zT_460[rf_d];
    zT_462 = zT_461.id;
    rf_dst = zT_462;
    if ((unsigned char)(rf_dst == rf_src)) goto z_bb_100; else goto z_bb_101;
    z_bb_98:
    goto z_bb_93;
    z_bb_99:
    zT_484 = rf_d + (unsigned int)(1);
    rf_d = zT_484;
    goto z_bb_96;
    z_bb_100:
    goto z_bb_99;
    z_bb_101:
    zT_464 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_465 = rf_dst;
    zT_467 = zF_F3EE5998_u32ToU32MapGet(zT_464, zT_465);
    zT_468 = zT_467.has_value;
    if (zT_468) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    goto z_bb_99;
    z_bb_103:
    zT_469 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_475 = zF_F3EE5998_u32ToU32MapGet(zT_469, (unsigned int)((unsigned int)(rf_src * (unsigned int)(65536)) + rf_dst));
    zT_476 = zT_475.has_value;
    if (zT_476) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    zT_477 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_478 = rf_dst;
    zF_26476265_u32ToU32MapPut(zT_477, zT_478, (unsigned int)(1));
    zT_482 = 1;
    rf_changed = zT_482;
    goto z_bb_105;
    z_bb_105:
    goto z_bb_99;
    z_bb_106:
    zT_490 = ri_mods.len;
    if ((unsigned char)(ri_i < zT_490)) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_492 = ri_mods.ptr;
    zT_493 = zT_492[ri_i];
    zT_494 = zT_493.id;
    if ((unsigned char)(zT_494 == (unsigned int)(0))) goto z_bb_110; else goto z_bb_111;
    z_bb_108:
    emitter.reachable = reachable;
    zT_545 = ctx->cli;
    zT_546 = zT_545.output_dir_set;
    if (zT_546) goto z_bb_125; else goto z_bb_126;
    z_bb_109:
    zT_544 = ri_i + (unsigned int)(1);
    ri_i = zT_544;
    goto z_bb_106;
    z_bb_110:
    goto z_bb_109;
    z_bb_111:
    zT_497 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_500 = ri_mods.ptr;
    zT_501 = zT_500[ri_i];
    zT_498 = zT_501.id;
    zT_503 = zF_F3EE5998_u32ToU32MapGet(zT_497, zT_498);
    zT_504 = zT_503.has_value;
    if ((unsigned char)(!zT_504)) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    goto z_bb_109;
    z_bb_113:
    zT_507 = 0;
    ri_has = zT_507;
    zT_509 = 0;
    gd_ri = zT_509;
    goto z_bb_114;
    z_bb_114:
    zT_510 = ctx->global_decls;
    zT_511 = zT_510.len;
    if ((unsigned char)(gd_ri < zT_511)) goto z_bb_115; else goto z_bb_116;
    z_bb_115:
    zT_514 = ctx->global_decls;
    zT_515 = zT_514.items;
    zT_516 = zT_515[gd_ri];
    gd_g = zT_516;
    zT_517 = gd_g.module_id;
    zT_518 = ri_mods.ptr;
    zT_519 = zT_518[ri_i];
    zT_520 = zT_519.id;
    if ((unsigned char)(zT_517 == zT_520)) goto z_bb_118; else goto z_bb_119;
    z_bb_116:
    if ((unsigned char)(ri_has != (unsigned char)(0))) goto z_bb_123; else goto z_bb_124;
    z_bb_117:
    zT_528 = gd_ri + (unsigned int)(1);
    gd_ri = zT_528;
    goto z_bb_114;
    z_bb_118:
    zT_523 = gd_g.has_runtime_init;
    zT_522 = zT_523 != (unsigned char)(0);
    goto z_bb_120;
    z_bb_119:
    zT_522 = 0;
    goto z_bb_120;
    z_bb_120:
    if (zT_522) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_526 = 1;
    ri_has = zT_526;
    goto z_bb_116;
    z_bb_122:
    goto z_bb_117;
    z_bb_123:
    zT_531 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_538 = ri_mods.ptr;
    zT_539 = zT_538[ri_i];
    zT_540 = zT_539.id;
    zF_26476265_u32ToU32MapPut(zT_531, (unsigned int)((unsigned int)(0) + zT_540), (unsigned int)(1));
    goto z_bb_124;
    z_bb_124:
    goto z_bb_109;
    z_bb_125:
    zT_548 = ctx->spell_plan;
    zT_549 = zT_548.typedef_order;
    sorted = zT_549;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_551[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hpath[_i] = zT_551[_i];
        _i++;
    }
}
    zT_553 = 0;
    hp = zT_553;
    zT_555 = ctx->cli;
    zT_556 = zT_555.output_dir;
    od = zT_556;
    zT_557 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_558 = od;
    zF_AB1E9CD4_emitSupportFiles(zT_557, zT_558);
    zT_561 = 0;
    hi = zT_561;
    goto z_bb_127;
    z_bb_126:
    cwriter = zT_1144;
    zT_1145 = zF_F9E678C3_bufferedWriterInit();
    cwriter = zT_1145;
    zT_1146 = (zT_63BE4FF5_BufferedWriter*)&cwriter;
    zF_225796FB_emitIncludes(zT_1146);
    zT_1148 = (zT_63BE4FF5_BufferedWriter*)&cwriter;
    zF_B35650AD_bufferedWriterFlush(zT_1148);
    zT_1151 = ctx->module_reg;
    zT_1154 = ctx->alloc;
    zT_1152 = &zT_1154->emission;
    zT_1156 = zF_1E2E8788_cincludeUnionAll(zT_1151, zT_1152);
    c_incs = zT_1156;
    zT_1157 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1158 = module_name;
    zT_1159 = c_incs;
    zF_503E3056_emitModule(zT_1157, zT_1158, zT_1159);
    zT_1162 = "FINAL_FLUSH\n";
    zT_1164 = 12;
    zT_1163.ptr = (unsigned char*)zT_1162;
    zT_1163.len = zT_1164;
    ff_m = zT_1163;
    zT_1165 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1165);
    zT_1167 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1166 = &zT_1167->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1166);
    zT_1169 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1169);
    zT_1171 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1171);
    return;
    z_bb_127:
    zT_563 = od.len;
    if ((unsigned char)(hi < zT_563)) goto z_bb_131; else goto z_bb_132;
    z_bb_128:
    zT_568 = od.ptr;
    zT_569 = zT_568[hi];
    hpath[hp] = zT_569;
    zT_570 = 1;
    zT_572 = hp + (unsigned int)((unsigned int)zT_570);
    hp = zT_572;
    goto z_bb_130;
    z_bb_129:
    zT_576 = 47;
    hpath[hp] = zT_576;
    zT_577 = 1;
    zT_579 = hp + (unsigned int)((unsigned int)zT_577);
    hp = zT_579;
    zT_581 = "zig_special_types.h";
    zT_583 = 19;
    zT_582.ptr = (unsigned char*)zT_581;
    zT_582.len = zT_583;
    hfn = zT_582;
    zT_585 = 0;
    hfi = zT_585;
    goto z_bb_134;
    z_bb_130:
    zT_573 = 1;
    zT_575 = hi + (unsigned int)((unsigned int)zT_573);
    hi = zT_575;
    goto z_bb_127;
    z_bb_131:
    zT_565 = hp < (unsigned int)(510);
    goto z_bb_133;
    z_bb_132:
    zT_565 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_565) goto z_bb_128; else goto z_bb_129;
    z_bb_134:
    zT_587 = hfn.len;
    if ((unsigned char)(hfi < zT_587)) goto z_bb_138; else goto z_bb_139;
    z_bb_135:
    zT_592 = hfn.ptr;
    zT_593 = zT_592[hfi];
    hpath[hp] = zT_593;
    zT_594 = 1;
    zT_596 = hp + (unsigned int)((unsigned int)zT_594);
    hp = zT_596;
    goto z_bb_137;
    z_bb_136:
    zT_605 = 0;
    zT_606 = (unsigned char*)((unsigned char*)hpath) + zT_605;
    zT_607 = hp - zT_605;
    zT_608.ptr = (unsigned char*)zT_606;
    zT_608.len = zT_607;
    zT_601 = zT_608;
    zT_610 = zF_39FE21EF_fileOpen(zT_601, (int)(0));
    fd = zT_610;
    if ((unsigned char)(fd == (unsigned int)(4294967295u))) goto z_bb_141; else goto z_bb_142;
    z_bb_137:
    zT_597 = 1;
    zT_599 = hfi + (unsigned int)((unsigned int)zT_597);
    hfi = zT_599;
    goto z_bb_134;
    z_bb_138:
    zT_589 = hp < (unsigned int)(511);
    goto z_bb_140;
    z_bb_139:
    zT_589 = 0;
    goto z_bb_140;
    z_bb_140:
    if (zT_589) goto z_bb_135; else goto z_bb_136;
    z_bb_141:
    zT_614 = "error: cannot open output file\n";
    zT_616 = 31;
    zT_615.ptr = (unsigned char*)zT_614;
    zT_615.len = zT_616;
    emsg = zT_615;
    zT_617 = emsg;
    zF_E4B2EF19_stderr_write(zT_617);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_142;
    z_bb_142:
    hw = zT_621;
    zT_622 = fd;
    zT_623 = zF_E00097E1_bufferedWriterInitF(zT_622);
    hw = zT_623;
    emitter.writer = hw;
    zT_624 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_625 = ctx->typereg;
    zT_626 = sorted;
    zF_62841416_emitSharedHeader(zT_624, zT_625, zT_626);
    zT_630 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_629 = &zT_630->writer;
    zF_B35650AD_bufferedWriterFlush(zT_629);
    zT_632 = fd;
    zF_B30B1D79_fileClose(zT_632);
    zT_634 = ctx->module_reg;
    zT_636 = zF_3452C137_moduleRegistryGetMo(zT_634);
    mods = zT_636;
    emitter.prune_active = (unsigned char)(1);
    zT_639 = ctx->lir_slots;
    zT_640 = zT_639.len;
    slot_count = zT_640;
    zT_641 = 0;
    if ((unsigned char)(slot_count > (unsigned int)zT_641)) goto z_bb_143; else goto z_bb_144;
    z_bb_143:
    zT_647 = ctx->alloc;
    zT_644 = &zT_647->emission;
    zT_651 = mods.len;
    zT_654 = zF_1395EB68_sandAlloc(zT_644, (unsigned int)((unsigned int)(4) * zT_651), (unsigned int)(4));
    zT_655 = zT_654.is_error;
    if (zT_655) goto z_bb_145; else goto z_bb_146;
    z_bb_144:
    zT_755 = 0;
    fn_cursor = zT_755;
    zT_757 = 0;
    mi = zT_757;
    goto z_bb_174;
    z_bb_145:
    pal_trap();
    z_bb_146:
    zT_656 = zT_654.data.payload;
    goto z_bb_147;
    z_bb_147:
    zT_658 = (unsigned int*)zT_656;
    grp_counts = zT_658;
    zT_663 = ctx->alloc;
    zT_660 = &zT_663->emission;
    zT_667 = mods.len;
    zT_670 = zF_1395EB68_sandAlloc(zT_660, (unsigned int)((unsigned int)(4) * zT_667), (unsigned int)(4));
    zT_671 = zT_670.is_error;
    if (zT_671) goto z_bb_148; else goto z_bb_149;
    z_bb_148:
    pal_trap();
    z_bb_149:
    zT_672 = zT_670.data.payload;
    goto z_bb_150;
    z_bb_150:
    zT_674 = (unsigned int*)zT_672;
    grp_cursor = zT_674;
    zT_676 = 0;
    gci = zT_676;
    goto z_bb_151;
    z_bb_151:
    zT_678 = mods.len;
    if ((unsigned char)(gci < zT_678)) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_680 = 0;
    grp_counts[gci] = zT_680;
    goto z_bb_154;
    z_bb_153:
    zT_685 = 0;
    gsi = zT_685;
    goto z_bb_155;
    z_bb_154:
    zT_681 = 1;
    zT_683 = gci + (unsigned int)((unsigned int)zT_681);
    gci = zT_683;
    goto z_bb_151;
    z_bb_155:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_688 = ctx->lir_slots;
    zT_689 = zT_688.items;
    zT_690 = zT_689[gsi];
    zT_691 = zT_690.module_id;
    gsmid = zT_691;
    zT_694 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) < zT_694)) goto z_bb_159; else goto z_bb_160;
    z_bb_157:
    zT_705 = 0;
    gacc = zT_705;
    zT_706 = 0;
    gci = zT_706;
    goto z_bb_161;
    z_bb_158:
    zT_701 = 1;
    zT_703 = gsi + (unsigned int)((unsigned int)zT_701);
    gsi = zT_703;
    goto z_bb_155;
    z_bb_159:
    zT_696 = (unsigned int)gsmid;
    zT_697 = grp_counts[zT_696];
    zT_699 = zT_697 + (unsigned int)(1);
    zT_700 = (unsigned int)gsmid;
    grp_counts[zT_700] = zT_699;
    goto z_bb_160;
    z_bb_160:
    goto z_bb_158;
    z_bb_161:
    zT_708 = mods.len;
    if ((unsigned char)(gci < zT_708)) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    grp_cursor[gci] = gacc;
    zT_710 = grp_counts[gci];
    zT_711 = gacc + zT_710;
    gacc = zT_711;
    goto z_bb_164;
    z_bb_163:
    zT_719 = ctx->alloc;
    zT_716 = &zT_719->emission;
    zT_724 = zF_1395EB68_sandAlloc(zT_716, (unsigned int)((unsigned int)(12) * slot_count), (unsigned int)(4));
    zT_725 = zT_724.is_error;
    if (zT_725) goto z_bb_165; else goto z_bb_166;
    z_bb_164:
    zT_712 = 1;
    zT_714 = gci + (unsigned int)((unsigned int)zT_712);
    gci = zT_714;
    goto z_bb_161;
    z_bb_165:
    pal_trap();
    z_bb_166:
    zT_726 = zT_724.data.payload;
    goto z_bb_167;
    z_bb_167:
    zT_728 = (zT_E7714190_LirSlot*)zT_726;
    grouped = zT_728;
    zT_729 = 0;
    gsi = zT_729;
    goto z_bb_168;
    z_bb_168:
    if ((unsigned char)(gsi < slot_count)) goto z_bb_169; else goto z_bb_170;
    z_bb_169:
    zT_732 = ctx->lir_slots;
    zT_733 = zT_732.items;
    zT_734 = zT_733[gsi];
    gslot = zT_734;
    zT_736 = gslot.module_id;
    gsmid = zT_736;
    zT_739 = mods.len;
    if ((unsigned char)((unsigned int)((unsigned int)gsmid) >= zT_739)) goto z_bb_172; else goto z_bb_173;
    z_bb_170:
    zT_751 = &ctx->lir_slots;
    zT_751->items = grouped;
    zT_753 = &ctx->lir_slots;
    zT_753->len = (unsigned int)((unsigned int)gacc);
    emitter.fn_slots = grouped;
    goto z_bb_144;
    z_bb_171:
    zT_748 = 1;
    zT_750 = gsi + (unsigned int)((unsigned int)zT_748);
    gsi = zT_750;
    goto z_bb_168;
    z_bb_172:
    goto z_bb_171;
    z_bb_173:
    zT_742 = (unsigned int)gsmid;
    zT_743 = grp_cursor[zT_742];
    gdst = zT_743;
    zT_744 = (unsigned int)gdst;
    grouped[zT_744] = gslot;
    zT_746 = gdst + (unsigned int)(1);
    zT_747 = (unsigned int)gsmid;
    grp_cursor[zT_747] = zT_746;
    goto z_bb_171;
    z_bb_174:
    zT_759 = mods.len;
    if ((unsigned char)(mi < zT_759)) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    zT_762 = mods.ptr;
    zT_763 = zT_762[mi];
    m = zT_763;
    fn_start = fn_cursor;
    goto z_bb_178;
    z_bb_176:
    zT_1130 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1131 = od;
    zT_1135 = ctx->cli;
    zT_1132 = zT_1135.target_is_windows;
    zT_1137 = ctx->cli;
    zT_1133 = zT_1137.target_win_profile;
    zF_A62DB57E_emitBuildScripts(zT_1130, zT_1131, zT_1132, zT_1133);
    zT_1139 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1139);
    zT_1141 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1141);
    return;
    z_bb_177:
    zT_1127 = 1;
    zT_1129 = mi + (unsigned int)((unsigned int)zT_1127);
    mi = zT_1129;
    goto z_bb_174;
    z_bb_178:
    zT_765 = ctx->lir_slots;
    zT_766 = zT_765.len;
    if ((unsigned char)(fn_cursor < zT_766)) goto z_bb_182; else goto z_bb_183;
    z_bb_179:
    goto z_bb_181;
    z_bb_180:
    zT_777 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_778 = m.id;
    zT_781 = zF_F3EE5998_u32ToU32MapGet(zT_777, zT_778);
    zT_782 = zT_781.has_value;
    if ((unsigned char)(!zT_782)) goto z_bb_185; else goto z_bb_186;
    z_bb_181:
    zT_776 = fn_cursor + (unsigned int)(1);
    fn_cursor = zT_776;
    goto z_bb_178;
    z_bb_182:
    zT_769 = ctx->lir_slots;
    zT_770 = zT_769.items;
    zT_771 = zT_770[fn_cursor];
    zT_772 = zT_771.module_id;
    zT_773 = m.id;
    zT_768 = zT_772 == zT_773;
    goto z_bb_184;
    z_bb_183:
    zT_768 = 0;
    goto z_bb_184;
    z_bb_184:
    if (zT_768) goto z_bb_179; else goto z_bb_180;
    z_bb_185:
    goto z_bb_177;
    z_bb_186:
    emitter.fn_slots_start = fn_start;
    emitter.fn_slots_len = (unsigned int)(fn_cursor - fn_start);
    zT_786 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_787 = m.id;
    zT_790 = zF_E295413A_moduleQualifiedName(zT_786, zT_787);
    base = zT_790;
    zT_792 = od.len;
    zT_796 = base.len;
    if ((unsigned char)((unsigned int)((unsigned int)((unsigned int)(zT_792 + (unsigned int)(1)) + zT_796) + (unsigned int)(3)) > (unsigned int)(511))) goto z_bb_187; else goto z_bb_188;
    z_bb_187:
    zT_803 = "error: output filename too long\n";
    zT_805 = 32;
    zT_804.ptr = (unsigned char*)zT_803;
    zT_804.len = zT_805;
    lmsg = zT_804;
    zT_806 = lmsg;
    zF_E4B2EF19_stderr_write(zT_806);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_188;
    z_bb_188:
    zT_810 = 0;
    hp2 = zT_810;
    zT_812 = 0;
    hi2 = zT_812;
    goto z_bb_189;
    z_bb_189:
    zT_814 = od.len;
    if ((unsigned char)(hi2 < zT_814)) goto z_bb_193; else goto z_bb_194;
    z_bb_190:
    zT_819 = od.ptr;
    zT_820 = zT_819[hi2];
    hpath[hp2] = zT_820;
    zT_821 = 1;
    zT_823 = hp2 + (unsigned int)((unsigned int)zT_821);
    hp2 = zT_823;
    goto z_bb_192;
    z_bb_191:
    zT_827 = 47;
    hpath[hp2] = zT_827;
    zT_828 = 1;
    zT_830 = hp2 + (unsigned int)((unsigned int)zT_828);
    hp2 = zT_830;
    zT_832 = 0;
    bi = zT_832;
    goto z_bb_196;
    z_bb_192:
    zT_824 = 1;
    zT_826 = hi2 + (unsigned int)((unsigned int)zT_824);
    hi2 = zT_826;
    goto z_bb_189;
    z_bb_193:
    zT_816 = hp2 < (unsigned int)(510);
    goto z_bb_195;
    z_bb_194:
    zT_816 = 0;
    goto z_bb_195;
    z_bb_195:
    if (zT_816) goto z_bb_190; else goto z_bb_191;
    z_bb_196:
    zT_834 = base.len;
    if ((unsigned char)(bi < zT_834)) goto z_bb_200; else goto z_bb_201;
    z_bb_197:
    zT_839 = base.ptr;
    zT_840 = zT_839[bi];
    hpath[hp2] = zT_840;
    zT_841 = 1;
    zT_843 = hp2 + (unsigned int)((unsigned int)zT_841);
    hp2 = zT_843;
    goto z_bb_199;
    z_bb_198:
    zT_848 = ".h";
    zT_850 = 2;
    zT_849.ptr = (unsigned char*)zT_848;
    zT_849.len = zT_850;
    hext = zT_849;
    zT_852 = 0;
    hx = zT_852;
    goto z_bb_203;
    z_bb_199:
    zT_844 = 1;
    zT_846 = bi + (unsigned int)((unsigned int)zT_844);
    bi = zT_846;
    goto z_bb_196;
    z_bb_200:
    zT_836 = hp2 < (unsigned int)(510);
    goto z_bb_202;
    z_bb_201:
    zT_836 = 0;
    goto z_bb_202;
    z_bb_202:
    if (zT_836) goto z_bb_197; else goto z_bb_198;
    z_bb_203:
    zT_854 = hext.len;
    if ((unsigned char)(hx < zT_854)) goto z_bb_207; else goto z_bb_208;
    z_bb_204:
    zT_859 = hext.ptr;
    zT_860 = zT_859[hx];
    hpath[hp2] = zT_860;
    zT_861 = 1;
    zT_863 = hp2 + (unsigned int)((unsigned int)zT_861);
    hp2 = zT_863;
    goto z_bb_206;
    z_bb_205:
    zT_872 = 0;
    zT_873 = (unsigned char*)((unsigned char*)hpath) + zT_872;
    zT_874 = hp2 - zT_872;
    zT_875.ptr = (unsigned char*)zT_873;
    zT_875.len = zT_874;
    zT_868 = zT_875;
    zT_877 = zF_39FE21EF_fileOpen(zT_868, (int)(0));
    fd2 = zT_877;
    if ((unsigned char)(fd2 == (unsigned int)(4294967295u))) goto z_bb_210; else goto z_bb_211;
    z_bb_206:
    zT_864 = 1;
    zT_866 = hx + (unsigned int)((unsigned int)zT_864);
    hx = zT_866;
    goto z_bb_203;
    z_bb_207:
    zT_856 = hp2 < (unsigned int)(511);
    goto z_bb_209;
    z_bb_208:
    zT_856 = 0;
    goto z_bb_209;
    z_bb_209:
    if (zT_856) goto z_bb_204; else goto z_bb_205;
    z_bb_210:
    zT_881 = "error: cannot open output file\n";
    zT_883 = 31;
    zT_882.ptr = (unsigned char*)zT_881;
    zT_882.len = zT_883;
    emsg2 = zT_882;
    zT_884 = emsg2;
    zF_E4B2EF19_stderr_write(zT_884);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_211;
    z_bb_211:
    hw2 = zT_888;
    zT_889 = fd2;
    zT_890 = zF_E00097E1_bufferedWriterInitF(zT_889);
    hw2 = zT_890;
    emitter.writer = hw2;
    zT_892 = m.imports_start;
    zT_893 = (unsigned int)zT_892;
    dep_start = zT_893;
    zT_895 = m.import_count;
    zT_897 = dep_start + (unsigned int)((unsigned int)zT_895);
    dep_end = zT_897;
    zT_899 = ctx->module_reg;
    zT_900 = zT_899->import_edges_items;
    zT_901 = zT_900 + dep_start;
    zT_902 = dep_end - dep_start;
    zT_903.ptr = (unsigned int*)zT_901;
    zT_903.len = zT_902;
    dep_ids = zT_903;
    zT_905 = m.c_includes;
    zT_906 = zT_905.items;
    zT_907 = m.c_includes;
    zT_908 = zT_907.len;
    zT_909 = 0;
    zT_910 = zT_906 + zT_909;
    zT_911 = zT_908 - zT_909;
    zT_912.ptr = (unsigned int*)zT_910;
    zT_912.len = zT_911;
    m_c_incs = zT_912;
    zT_917 = ctx->alloc;
    zT_914 = &zT_917->emission;
    zT_921 = mods.len;
    zT_924 = zF_1395EB68_sandAlloc(zT_914, (unsigned int)((unsigned int)(4) * zT_921), (unsigned int)(4));
    zT_925 = zT_924.is_error;
    if (zT_925) goto z_bb_212; else goto z_bb_213;
    z_bb_212:
    pal_trap();
    z_bb_213:
    zT_926 = zT_924.data.payload;
    goto z_bb_214;
    z_bb_214:
    inc_raw = zT_926;
    zT_929 = (unsigned int*)inc_raw;
    inc_arr = zT_929;
    zT_931 = 0;
    inc_n = zT_931;
    zT_933 = 0;
    di0 = zT_933;
    goto z_bb_215;
    z_bb_215:
    zT_935 = dep_ids.len;
    if ((unsigned char)(di0 < zT_935)) goto z_bb_216; else goto z_bb_217;
    z_bb_216:
    zT_938 = dep_ids.ptr;
    zT_939 = zT_938[di0];
    dd0 = zT_939;
    zT_940 = m.id;
    if ((unsigned char)(dd0 == zT_940)) goto z_bb_219; else goto z_bb_220;
    z_bb_217:
    zT_965 = 0;
    vd0 = zT_965;
    goto z_bb_231;
    z_bb_218:
    zT_963 = di0 + (unsigned int)(1);
    di0 = zT_963;
    goto z_bb_215;
    z_bb_219:
    goto z_bb_218;
    z_bb_220:
    zT_942 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_943 = dd0;
    zT_945 = zF_F3EE5998_u32ToU32MapGet(zT_942, zT_943);
    zT_946 = zT_945.has_value;
    if ((unsigned char)(!zT_946)) goto z_bb_221; else goto z_bb_222;
    z_bb_221:
    goto z_bb_218;
    z_bb_222:
    zT_949 = 0;
    dup0 = zT_949;
    zT_951 = 0;
    dj0 = zT_951;
    goto z_bb_223;
    z_bb_223:
    if ((unsigned char)(dj0 < inc_n)) goto z_bb_224; else goto z_bb_225;
    z_bb_224:
    zT_953 = inc_arr[dj0];
    if ((unsigned char)(zT_953 == dd0)) goto z_bb_227; else goto z_bb_228;
    z_bb_225:
    if ((unsigned char)(dup0 != (unsigned char)(0))) goto z_bb_229; else goto z_bb_230;
    z_bb_226:
    zT_957 = dj0 + (unsigned int)(1);
    dj0 = zT_957;
    goto z_bb_223;
    z_bb_227:
    zT_955 = 1;
    dup0 = zT_955;
    goto z_bb_225;
    z_bb_228:
    goto z_bb_226;
    z_bb_229:
    goto z_bb_218;
    z_bb_230:
    inc_arr[inc_n] = dd0;
    zT_961 = inc_n + (unsigned int)(1);
    inc_n = zT_961;
    goto z_bb_218;
    z_bb_231:
    zT_967 = mods.len;
    if ((unsigned char)(vd0 < zT_967)) goto z_bb_232; else goto z_bb_233;
    z_bb_232:
    zT_970 = mods.ptr;
    zT_971 = zT_970[vd0];
    zT_972 = zT_971.id;
    vdd0 = zT_972;
    zT_973 = m.id;
    if ((unsigned char)(vdd0 == zT_973)) goto z_bb_235; else goto z_bb_236;
    z_bb_233:
    zT_1008 = 0;
    zT_1009 = inc_arr + zT_1008;
    zT_1010 = inc_n - zT_1008;
    zT_1011.ptr = (unsigned int*)zT_1009;
    zT_1011.len = zT_1010;
    inc_slice = zT_1011;
    zT_1012 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1013 = m.id;
    zT_1014 = base;
    zT_1015 = m_c_incs;
    zT_1016 = inc_slice;
    zT_1017 = sorted;
    zF_1AF3E3A9_emitModuleHeaderFil(zT_1012, zT_1013, zT_1014, zT_1015, zT_1016, zT_1017);
    zT_1021 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1020 = &zT_1021->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1020);
    zT_1023 = fd2;
    zF_B30B1D79_fileClose(zT_1023);
    zT_1025 = "FINAL_FLUSH\n";
    zT_1027 = 12;
    zT_1026.ptr = (unsigned char*)zT_1025;
    zT_1026.len = zT_1027;
    ff_m = zT_1026;
    zT_1028 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1028);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_1030[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        cpath[_i] = zT_1030[_i];
        _i++;
    }
}
    zT_1032 = 0;
    cp2 = zT_1032;
    zT_1034 = 0;
    ci2 = zT_1034;
    goto z_bb_249;
    z_bb_234:
    zT_1006 = vd0 + (unsigned int)(1);
    vd0 = zT_1006;
    goto z_bb_231;
    z_bb_235:
    goto z_bb_234;
    z_bb_236:
    zT_975 = (zT_21D3708C_U32ToU32Map*)&reachable;
    zT_976 = vdd0;
    zT_978 = zF_F3EE5998_u32ToU32MapGet(zT_975, zT_976);
    zT_979 = zT_978.has_value;
    if ((unsigned char)(!zT_979)) goto z_bb_237; else goto z_bb_238;
    z_bb_237:
    goto z_bb_234;
    z_bb_238:
    zT_981 = (zT_21D3708C_U32ToU32Map*)&ref_edges;
    zT_984 = m.id;
    zT_988 = zF_F3EE5998_u32ToU32MapGet(zT_981, (unsigned int)((unsigned int)(zT_984 * (unsigned int)(65536)) + vdd0));
    zT_989 = zT_988.has_value;
    if ((unsigned char)(!zT_989)) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    goto z_bb_234;
    z_bb_240:
    zT_992 = 0;
    dup1 = zT_992;
    zT_994 = 0;
    dj1 = zT_994;
    goto z_bb_241;
    z_bb_241:
    if ((unsigned char)(dj1 < inc_n)) goto z_bb_242; else goto z_bb_243;
    z_bb_242:
    zT_996 = inc_arr[dj1];
    if ((unsigned char)(zT_996 == vdd0)) goto z_bb_245; else goto z_bb_246;
    z_bb_243:
    if ((unsigned char)(dup1 != (unsigned char)(0))) goto z_bb_247; else goto z_bb_248;
    z_bb_244:
    zT_1000 = dj1 + (unsigned int)(1);
    dj1 = zT_1000;
    goto z_bb_241;
    z_bb_245:
    zT_998 = 1;
    dup1 = zT_998;
    goto z_bb_243;
    z_bb_246:
    goto z_bb_244;
    z_bb_247:
    goto z_bb_234;
    z_bb_248:
    inc_arr[inc_n] = vdd0;
    zT_1004 = inc_n + (unsigned int)(1);
    inc_n = zT_1004;
    goto z_bb_234;
    z_bb_249:
    zT_1036 = od.len;
    if ((unsigned char)(ci2 < zT_1036)) goto z_bb_253; else goto z_bb_254;
    z_bb_250:
    zT_1041 = od.ptr;
    zT_1042 = zT_1041[ci2];
    cpath[cp2] = zT_1042;
    zT_1043 = 1;
    zT_1045 = cp2 + (unsigned int)((unsigned int)zT_1043);
    cp2 = zT_1045;
    goto z_bb_252;
    z_bb_251:
    zT_1049 = 47;
    cpath[cp2] = zT_1049;
    zT_1050 = 1;
    zT_1052 = cp2 + (unsigned int)((unsigned int)zT_1050);
    cp2 = zT_1052;
    zT_1054 = 0;
    cbi = zT_1054;
    goto z_bb_256;
    z_bb_252:
    zT_1046 = 1;
    zT_1048 = ci2 + (unsigned int)((unsigned int)zT_1046);
    ci2 = zT_1048;
    goto z_bb_249;
    z_bb_253:
    zT_1038 = cp2 < (unsigned int)(510);
    goto z_bb_255;
    z_bb_254:
    zT_1038 = 0;
    goto z_bb_255;
    z_bb_255:
    if (zT_1038) goto z_bb_250; else goto z_bb_251;
    z_bb_256:
    zT_1056 = base.len;
    if ((unsigned char)(cbi < zT_1056)) goto z_bb_260; else goto z_bb_261;
    z_bb_257:
    zT_1061 = base.ptr;
    zT_1062 = zT_1061[cbi];
    cpath[cp2] = zT_1062;
    zT_1063 = 1;
    zT_1065 = cp2 + (unsigned int)((unsigned int)zT_1063);
    cp2 = zT_1065;
    goto z_bb_259;
    z_bb_258:
    zT_1070 = ".c";
    zT_1072 = 2;
    zT_1071.ptr = (unsigned char*)zT_1070;
    zT_1071.len = zT_1072;
    cext = zT_1071;
    zT_1074 = 0;
    cx = zT_1074;
    goto z_bb_263;
    z_bb_259:
    zT_1066 = 1;
    zT_1068 = cbi + (unsigned int)((unsigned int)zT_1066);
    cbi = zT_1068;
    goto z_bb_256;
    z_bb_260:
    zT_1058 = cp2 < (unsigned int)(510);
    goto z_bb_262;
    z_bb_261:
    zT_1058 = 0;
    goto z_bb_262;
    z_bb_262:
    if (zT_1058) goto z_bb_257; else goto z_bb_258;
    z_bb_263:
    zT_1076 = cext.len;
    if ((unsigned char)(cx < zT_1076)) goto z_bb_267; else goto z_bb_268;
    z_bb_264:
    zT_1081 = cext.ptr;
    zT_1082 = zT_1081[cx];
    cpath[cp2] = zT_1082;
    zT_1083 = 1;
    zT_1085 = cp2 + (unsigned int)((unsigned int)zT_1083);
    cp2 = zT_1085;
    goto z_bb_266;
    z_bb_265:
    zT_1094 = 0;
    zT_1095 = (unsigned char*)((unsigned char*)cpath) + zT_1094;
    zT_1096 = cp2 - zT_1094;
    zT_1097.ptr = (unsigned char*)zT_1095;
    zT_1097.len = zT_1096;
    zT_1090 = zT_1097;
    zT_1099 = zF_39FE21EF_fileOpen(zT_1090, (int)(0));
    cfd = zT_1099;
    if ((unsigned char)(cfd == (unsigned int)(4294967295u))) goto z_bb_270; else goto z_bb_271;
    z_bb_266:
    zT_1086 = 1;
    zT_1088 = cx + (unsigned int)((unsigned int)zT_1086);
    cx = zT_1088;
    goto z_bb_263;
    z_bb_267:
    zT_1078 = cp2 < (unsigned int)(511);
    goto z_bb_269;
    z_bb_268:
    zT_1078 = 0;
    goto z_bb_269;
    z_bb_269:
    if (zT_1078) goto z_bb_264; else goto z_bb_265;
    z_bb_270:
    zT_1103 = "error: cannot open output file\n";
    zT_1105 = 31;
    zT_1104.ptr = (unsigned char*)zT_1103;
    zT_1104.len = zT_1105;
    emsg3 = zT_1104;
    zT_1106 = emsg3;
    zF_E4B2EF19_stderr_write(zT_1106);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_271;
    z_bb_271:
    cw = zT_1110;
    zT_1111 = cfd;
    zT_1112 = zF_E00097E1_bufferedWriterInitF(zT_1111);
    cw = zT_1112;
    emitter.writer = cw;
    zT_1113 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1114 = m.id;
    zT_1115 = base;
    zF_7B8B9B90_emitModuleFile(zT_1113, zT_1114, zT_1115);
    zT_1119 = (zT_72C4E2ED_C89Emitter*)&emitter;
    zT_1118 = &zT_1119->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1118);
    zT_1121 = cfd;
    zF_B30B1D79_fileClose(zT_1121);
    zT_1123 = "FINAL_FLUSH\n";
    zT_1125 = 12;
    zT_1124.ptr = (unsigned char*)zT_1123;
    zT_1124.len = zT_1125;
    ff2_m = zT_1124;
    zT_1126 = ff2_m;
    zF_48AC7B3A_markerWrite(zT_1126);
    goto z_bb_177;
}

/* parseArgs */
zT_C98AF326_CompilerCli zF_6143A521_parseArgs(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_C98AF326_CompilerCli zT_9;
    unsigned char zT_10;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_CAF40AAB_ColorMode zT_18;
    zT_A4FB690E_ErrorFormat zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    unsigned char zT_25;
    unsigned char zT_26;
    unsigned char zT_27;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned char zT_33;
    zT_074080EA_WinProfile zT_35;
    int zT_37 = 0;
    int zT_39;
    int zT_40;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    unsigned char* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    unsigned char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    unsigned char* zT_150;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned int zT_152;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    unsigned char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    unsigned char* zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    unsigned char* zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    unsigned char* zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176;
    unsigned char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    unsigned char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    unsigned char* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    unsigned int zT_188;
    unsigned char* zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned int zT_192;
    int zT_195;
    unsigned char* zT_196 = 0;
    unsigned char* zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199 = {0};
    unsigned int zT_201;
    int zT_202;
    unsigned char zT_204;
    unsigned char* zT_205;
    int zT_206;
    unsigned char zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_210;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_211;
    unsigned char zT_212 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned char zT_217 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_219;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_220;
    unsigned char zT_221 = 0;
    unsigned char zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned char zT_225 = 0;
    int zT_226;
    int zT_228;
    unsigned char* zT_230;
    int zT_231;
    unsigned char* zT_232 = 0;
    unsigned int zT_233 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    unsigned char zT_235 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    unsigned char* zT_237;
    unsigned int zT_238;
    int zT_239;
    unsigned char* zT_240;
    unsigned int zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    unsigned int zT_243 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_244;
    unsigned char zT_245 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    unsigned char* zT_247;
    unsigned int zT_248;
    int zT_249;
    unsigned char* zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    unsigned int zT_253 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255;
    unsigned char zT_256 = 0;
    unsigned char zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_259;
    unsigned char zT_260 = 0;
    int zT_261;
    int zT_263;
    unsigned char* zT_265;
    int zT_266;
    unsigned char* zT_267 = 0;
    unsigned int zT_268 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    unsigned char zT_271 = 0;
    unsigned char zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned char zT_275 = 0;
    int zT_276;
    int zT_278;
    unsigned char* zT_280;
    int zT_281;
    unsigned char* zT_282 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_286;
    unsigned char zT_287 = 0;
    unsigned char zT_288;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned char zT_291 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_294;
    unsigned char zT_295 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_297;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    unsigned char zT_299 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned char zT_303 = 0;
    unsigned char zT_304;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    unsigned char zT_307 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_309;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_310;
    unsigned char zT_311 = 0;
    int zT_312;
    int zT_314;
    unsigned char* zT_316;
    int zT_317;
    unsigned char* zT_318 = 0;
    zT_CAF40AAB_ColorMode zT_319 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_321;
    unsigned char zT_322 = 0;
    int zT_323;
    int zT_325;
    unsigned char* zT_327;
    int zT_328;
    unsigned char* zT_329 = 0;
    zT_A4FB690E_ErrorFormat zT_330 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    unsigned char zT_333 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    unsigned char zT_337 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    unsigned char zT_341 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_343;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_344;
    unsigned char zT_345 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    unsigned char zT_349 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_351;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_352;
    unsigned char zT_353 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_356;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_357;
    unsigned char zT_358 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_361;
    unsigned char zT_362 = 0;
    unsigned char zT_363;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_364;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_365;
    unsigned char zT_366 = 0;
    int zT_367;
    int zT_369;
    unsigned char zT_371;
    unsigned int zT_372;
    int zT_373;
    unsigned char* zT_375;
    int zT_376;
    unsigned char* zT_377 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_378 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_379;
    unsigned int zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    int zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    unsigned char zT_388 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    unsigned char zT_392 = 0;
    int zT_396;
    unsigned char* zT_400;
    int zT_402;
    unsigned char* zT_404 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_405 = {0};
    unsigned int zT_407;
    int zT_408;
    unsigned char zT_410;
    unsigned char* zT_411;
    int zT_412;
    unsigned char zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_417;
    unsigned char zT_418 = 0;
    int zT_421;
    int zT_423;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned char zT_426 = 0;
    int zT_429;
    int zT_431;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned char zT_434 = 0;
    int zT_435;
    int zT_437;
    unsigned char* zT_439;
    int zT_440;
    unsigned char* zT_441 = 0;
    unsigned char zT_442 = 0;
    unsigned char zT_443;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_446;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_447;
    unsigned char zT_448 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_450;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_451;
    unsigned char zT_452 = 0;
    unsigned char* zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455 = {0};
    unsigned char* zT_456;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_457 = {0};
    int zT_458;
    int zT_460;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u dot_str;
    zT_C98AF326_CompilerCli cli;
    int argc;
    int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dump_c89;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_mem;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_errors;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_output_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_quiet;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sanity_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warnings;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_color;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_error_format;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_track_memory;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_lifetime;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_leak;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_all;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_error;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_markers;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_include;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_lib_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_o;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_q;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_W;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osw;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_profile_9x;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_profile_nt;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_target;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fsafe;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ffast;
    unsigned char* arg_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u arg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nxt;
    zT_1 = "";
    zT_3 = 0;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    empty_str = zT_2;
    zT_5 = ".";
    zT_7 = 1;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    dot_str = zT_6;
    zT_9.input_file = empty_str;
    zT_9.output_dir = dot_str;
    zT_10 = 0;
    zT_9.output_dir_set = zT_10;
    zT_11 = 0;
    zT_9.dump_types = zT_11;
    zT_12 = 0;
    zT_9.dump_lir = zT_12;
    zT_13 = 0;
    zT_9.dump_c89 = zT_13;
    zT_15 = 65536;
    zT_9.max_mem = zT_15;
    zT_16 = 0;
    zT_9.spill_level = zT_16;
    zT_17 = 256;
    zT_9.max_errors = zT_17;
    zT_18 = zT_CAF40AAB_ColorMode_auto;
    zT_9.color = zT_18;
    zT_19 = zT_A4FB690E_ErrorFormat_human;
    zT_9.error_format = zT_19;
    zT_20 = 0;
    zT_9.warnings_as_errors = zT_20;
    zT_21 = 0;
    zT_9.quiet = zT_21;
    zT_22 = 0;
    zT_9.test_mode = zT_22;
    zT_23 = 0;
    zT_9.sanity_test_mode = zT_23;
    zT_24 = 0;
    zT_9.track_memory = zT_24;
    zT_25 = 0;
    zT_9.no_null_check = zT_25;
    zT_26 = 0;
    zT_9.no_lifetime_check = zT_26;
    zT_27 = 0;
    zT_9.no_leak_check = zT_27;
    zT_28 = 1;
    zT_9.safe_checks = zT_28;
    zT_29 = 0;
    zT_9.warn_all = zT_29;
    zT_30 = 0;
    zT_9.warn_error = zT_30;
    zT_31 = 0;
    zT_9.show_markers = zT_31;
    zT_32 = 0;
    zT_9.include_count = zT_32;
    zT_33 = 0;
    zT_9.target_is_windows = zT_33;
    zT_35 = zT_074080EA_WinProfile_win9x;
    zT_9.target_win_profile = zT_35;
    cli = zT_9;
    zT_37 = zF_EEF840BE_argCount();
    argc = zT_37;
    zT_39 = 1;
    zT_40 = (int)zT_39;
    i = zT_40;
    zT_50 = "--dump-c89";
    zT_52 = 10;
    zT_51.ptr = (unsigned char*)zT_50;
    zT_51.len = zT_52;
    s_dump_c89 = zT_51;
    zT_54 = "--help";
    zT_56 = 6;
    zT_55.ptr = (unsigned char*)zT_54;
    zT_55.len = zT_56;
    s_help = zT_55;
    zT_58 = "--max-mem";
    zT_60 = 9;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    s_max_mem = zT_59;
    zT_62 = "--max-errors";
    zT_64 = 12;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    s_max_errors = zT_63;
    zT_66 = "--output-dir";
    zT_68 = 12;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    s_output_dir = zT_67;
    zT_70 = "--quiet";
    zT_72 = 7;
    zT_71.ptr = (unsigned char*)zT_70;
    zT_71.len = zT_72;
    s_quiet = zT_71;
    zT_74 = "--test";
    zT_76 = 6;
    zT_75.ptr = (unsigned char*)zT_74;
    zT_75.len = zT_76;
    s_test = zT_75;
    zT_78 = "--sanity-test";
    zT_80 = 13;
    zT_79.ptr = (unsigned char*)zT_78;
    zT_79.len = zT_80;
    s_sanity_test = zT_79;
    zT_82 = "--warnings-as-errors";
    zT_84 = 20;
    zT_83.ptr = (unsigned char*)zT_82;
    zT_83.len = zT_84;
    s_warnings = zT_83;
    zT_86 = "--color";
    zT_88 = 7;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    s_color = zT_87;
    zT_90 = "--error-format";
    zT_92 = 14;
    zT_91.ptr = (unsigned char*)zT_90;
    zT_91.len = zT_92;
    s_error_format = zT_91;
    zT_94 = "--track-memory";
    zT_96 = 14;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    s_track_memory = zT_95;
    zT_98 = "--no-null-check";
    zT_100 = 15;
    zT_99.ptr = (unsigned char*)zT_98;
    zT_99.len = zT_100;
    s_no_null = zT_99;
    zT_102 = "--no-lifetime-check";
    zT_104 = 19;
    zT_103.ptr = (unsigned char*)zT_102;
    zT_103.len = zT_104;
    s_no_lifetime = zT_103;
    zT_106 = "--no-leak-check";
    zT_108 = 15;
    zT_107.ptr = (unsigned char*)zT_106;
    zT_107.len = zT_108;
    s_no_leak = zT_107;
    zT_110 = "--warn-all";
    zT_112 = 10;
    zT_111.ptr = (unsigned char*)zT_110;
    zT_111.len = zT_112;
    s_warn_all = zT_111;
    zT_114 = "--warn-error";
    zT_116 = 12;
    zT_115.ptr = (unsigned char*)zT_114;
    zT_115.len = zT_116;
    s_warn_error = zT_115;
    zT_118 = "--markers";
    zT_120 = 9;
    zT_119.ptr = (unsigned char*)zT_118;
    zT_119.len = zT_120;
    s_markers = zT_119;
    zT_122 = "-I";
    zT_124 = 2;
    zT_123.ptr = (unsigned char*)zT_122;
    zT_123.len = zT_124;
    s_include = zT_123;
    zT_126 = "--lib-dir";
    zT_128 = 9;
    zT_127.ptr = (unsigned char*)zT_126;
    zT_127.len = zT_128;
    s_lib_dir = zT_127;
    zT_146 = "-m";
    zT_148 = 2;
    zT_147.ptr = (unsigned char*)zT_146;
    zT_147.len = zT_148;
    s_m = zT_147;
    zT_150 = "-e";
    zT_152 = 2;
    zT_151.ptr = (unsigned char*)zT_150;
    zT_151.len = zT_152;
    s_e = zT_151;
    zT_154 = "-o";
    zT_156 = 2;
    zT_155.ptr = (unsigned char*)zT_154;
    zT_155.len = zT_156;
    s_o = zT_155;
    zT_158 = "-q";
    zT_160 = 2;
    zT_159.ptr = (unsigned char*)zT_158;
    zT_159.len = zT_160;
    s_q = zT_159;
    zT_162 = "-W";
    zT_164 = 2;
    zT_163.ptr = (unsigned char*)zT_162;
    zT_163.len = zT_164;
    s_W = zT_163;
    zT_166 = "-osl";
    zT_168 = 4;
    zT_167.ptr = (unsigned char*)zT_166;
    zT_167.len = zT_168;
    s_osl = zT_167;
    zT_170 = "-osw";
    zT_172 = 4;
    zT_171.ptr = (unsigned char*)zT_170;
    zT_171.len = zT_172;
    s_osw = zT_171;
    zT_174 = "9x";
    zT_176 = 2;
    zT_175.ptr = (unsigned char*)zT_174;
    zT_175.len = zT_176;
    s_profile_9x = zT_175;
    zT_178 = "nt";
    zT_180 = 2;
    zT_179.ptr = (unsigned char*)zT_178;
    zT_179.len = zT_180;
    s_profile_nt = zT_179;
    zT_182 = "--target";
    zT_184 = 8;
    zT_183.ptr = (unsigned char*)zT_182;
    zT_183.len = zT_184;
    s_target = zT_183;
    zT_186 = "-fsafe";
    zT_188 = 6;
    zT_187.ptr = (unsigned char*)zT_186;
    zT_187.len = zT_188;
    s_fsafe = zT_187;
    zT_190 = "-ffast";
    zT_192 = 6;
    zT_191.ptr = (unsigned char*)zT_190;
    zT_191.len = zT_192;
    s_ffast = zT_191;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < argc)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_195 = i;
    zT_196 = zF_70B5BFF1_argGet(zT_195);
    arg_ptr = zT_196;
    zT_198 = arg_ptr;
    zT_199 = zF_22D0470E_cstrToSlice(zT_198);
    arg = zT_199;
    zT_201 = arg.len;
    zT_202 = 0;
    if ((unsigned char)(zT_201 > (unsigned int)zT_202)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cli;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_205 = arg.ptr;
    zT_206 = 0;
    zT_207 = zT_205[zT_206];
    zT_204 = zT_207 == (unsigned char)(45);
    goto z_bb_7;
    z_bb_6:
    zT_204 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_204) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_210 = arg;
    zT_211 = s_help;
    zT_212 = zF_5FE51158_matchFlag(zT_210, zT_211);
    if (zT_212) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_458 = 1;
    zT_460 = i + (int)((int)zT_458);
    i = zT_460;
    goto z_bb_4;
    z_bb_10:
    zT_456 = arg_ptr;
    zT_457 = zF_22D0470E_cstrToSlice(zT_456);
    cli.input_file = zT_457;
    goto z_bb_9;
    z_bb_11:
    zF_9D45DFBF_printUsage();
    zF_CDED1A85_exit((unsigned char)(0));
    return cli;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_215 = arg;
    zT_216 = s_dump_c89;
    zT_217 = zF_5FE51158_matchFlag(zT_215, zT_216);
    if (zT_217) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    cli.dump_c89 = (unsigned char)(1);
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_219 = arg;
    zT_220 = s_max_mem;
    zT_221 = zF_5FE51158_matchFlag(zT_219, zT_220);
    if (zT_221) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_223 = arg;
    zT_224 = s_m;
    zT_225 = zF_5FE51158_matchFlag(zT_223, zT_224);
    zT_222 = zT_225;
    goto z_bb_19;
    z_bb_18:
    zT_222 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_222) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_226 = 1;
    zT_228 = i + (int)((int)zT_226);
    i = zT_228;
    if ((unsigned char)(i < argc)) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_234 = arg;
    zT_235 = zF_FBF91F7E_matchMMFlag(zT_234);
    if (zT_235) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    zT_231 = i;
    zT_232 = zF_70B5BFF1_argGet(zT_231);
    zT_230 = zT_232;
    zT_233 = zF_6CF11065_parseSize(zT_230);
    cli.max_mem = zT_233;
    goto z_bb_24;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_237 = arg.ptr;
    zT_238 = arg.len;
    zT_239 = 3;
    zT_240 = zT_237 + zT_239;
    zT_241 = zT_238 - zT_239;
    zT_242.ptr = (unsigned char*)zT_240;
    zT_242.len = zT_241;
    zT_236 = zT_242;
    zT_243 = zF_B9231BB9_parseMMBytes(zT_236);
    cli.max_mem = zT_243;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_244 = arg;
    zT_245 = zF_C4E3C361_matchSFlag(zT_244);
    if (zT_245) goto z_bb_28; else goto z_bb_30;
    z_bb_28:
    zT_247 = arg.ptr;
    zT_248 = arg.len;
    zT_249 = 2;
    zT_250 = zT_247 + zT_249;
    zT_251 = zT_248 - zT_249;
    zT_252.ptr = (unsigned char*)zT_250;
    zT_252.len = zT_251;
    zT_246 = zT_252;
    zT_253 = zF_153C3795_parseSLevel(zT_246);
    cli.spill_level = zT_253;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    zT_254 = arg;
    zT_255 = s_max_errors;
    zT_256 = zF_5FE51158_matchFlag(zT_254, zT_255);
    if (zT_256) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_258 = arg;
    zT_259 = s_e;
    zT_260 = zF_5FE51158_matchFlag(zT_258, zT_259);
    zT_257 = zT_260;
    goto z_bb_33;
    z_bb_32:
    zT_257 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_257) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_261 = 1;
    zT_263 = i + (int)((int)zT_261);
    i = zT_263;
    if ((unsigned char)(i < argc)) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    goto z_bb_29;
    z_bb_36:
    zT_269 = arg;
    zT_270 = s_output_dir;
    zT_271 = zF_5FE51158_matchFlag(zT_269, zT_270);
    if (zT_271) goto z_bb_40; else goto z_bb_39;
    z_bb_37:
    zT_266 = i;
    zT_267 = zF_70B5BFF1_argGet(zT_266);
    zT_265 = zT_267;
    zT_268 = zF_16BBA09E_parseU32(zT_265);
    cli.max_errors = zT_268;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_273 = arg;
    zT_274 = s_o;
    zT_275 = zF_5FE51158_matchFlag(zT_273, zT_274);
    zT_272 = zT_275;
    goto z_bb_41;
    z_bb_40:
    zT_272 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_272) goto z_bb_42; else goto z_bb_44;
    z_bb_42:
    zT_276 = 1;
    zT_278 = i + (int)((int)zT_276);
    i = zT_278;
    if ((unsigned char)(i < argc)) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_35;
    z_bb_44:
    zT_285 = arg;
    zT_286 = s_quiet;
    zT_287 = zF_5FE51158_matchFlag(zT_285, zT_286);
    if (zT_287) goto z_bb_48; else goto z_bb_47;
    z_bb_45:
    zT_281 = i;
    zT_282 = zF_70B5BFF1_argGet(zT_281);
    zT_280 = zT_282;
    zT_283 = zF_22D0470E_cstrToSlice(zT_280);
    cli.output_dir = zT_283;
    cli.output_dir_set = (unsigned char)(1);
    goto z_bb_46;
    z_bb_46:
    goto z_bb_43;
    z_bb_47:
    zT_289 = arg;
    zT_290 = s_q;
    zT_291 = zF_5FE51158_matchFlag(zT_289, zT_290);
    zT_288 = zT_291;
    goto z_bb_49;
    z_bb_48:
    zT_288 = 1;
    goto z_bb_49;
    z_bb_49:
    if (zT_288) goto z_bb_50; else goto z_bb_52;
    z_bb_50:
    cli.quiet = (unsigned char)(1);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_43;
    z_bb_52:
    zT_293 = arg;
    zT_294 = s_test;
    zT_295 = zF_5FE51158_matchFlag(zT_293, zT_294);
    if (zT_295) goto z_bb_53; else goto z_bb_55;
    z_bb_53:
    cli.test_mode = (unsigned char)(1);
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_297 = arg;
    zT_298 = s_sanity_test;
    zT_299 = zF_5FE51158_matchFlag(zT_297, zT_298);
    if (zT_299) goto z_bb_56; else goto z_bb_58;
    z_bb_56:
    cli.sanity_test_mode = (unsigned char)(1);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_54;
    z_bb_58:
    zT_301 = arg;
    zT_302 = s_warnings;
    zT_303 = zF_5FE51158_matchFlag(zT_301, zT_302);
    if (zT_303) goto z_bb_60; else goto z_bb_59;
    z_bb_59:
    zT_305 = arg;
    zT_306 = s_W;
    zT_307 = zF_5FE51158_matchFlag(zT_305, zT_306);
    zT_304 = zT_307;
    goto z_bb_61;
    z_bb_60:
    zT_304 = 1;
    goto z_bb_61;
    z_bb_61:
    if (zT_304) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    cli.warnings_as_errors = (unsigned char)(1);
    goto z_bb_63;
    z_bb_63:
    goto z_bb_57;
    z_bb_64:
    zT_309 = arg;
    zT_310 = s_color;
    zT_311 = zF_5FE51158_matchFlag(zT_309, zT_310);
    if (zT_311) goto z_bb_65; else goto z_bb_67;
    z_bb_65:
    zT_312 = 1;
    zT_314 = i + (int)((int)zT_312);
    i = zT_314;
    if ((unsigned char)(i < argc)) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_320 = arg;
    zT_321 = s_error_format;
    zT_322 = zF_5FE51158_matchFlag(zT_320, zT_321);
    if (zT_322) goto z_bb_70; else goto z_bb_72;
    z_bb_68:
    zT_317 = i;
    zT_318 = zF_70B5BFF1_argGet(zT_317);
    zT_316 = zT_318;
    zT_319 = zF_05AD3AFC_parseColorMode(zT_316);
    cli.color = zT_319;
    goto z_bb_69;
    z_bb_69:
    goto z_bb_66;
    z_bb_70:
    zT_323 = 1;
    zT_325 = i + (int)((int)zT_323);
    i = zT_325;
    if ((unsigned char)(i < argc)) goto z_bb_73; else goto z_bb_74;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_331 = arg;
    zT_332 = s_track_memory;
    zT_333 = zF_5FE51158_matchFlag(zT_331, zT_332);
    if (zT_333) goto z_bb_75; else goto z_bb_77;
    z_bb_73:
    zT_328 = i;
    zT_329 = zF_70B5BFF1_argGet(zT_328);
    zT_327 = zT_329;
    zT_330 = zF_A4602959_parseErrorFormat(zT_327);
    cli.error_format = zT_330;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    cli.track_memory = (unsigned char)(1);
    goto z_bb_76;
    z_bb_76:
    goto z_bb_71;
    z_bb_77:
    zT_335 = arg;
    zT_336 = s_no_null;
    zT_337 = zF_5FE51158_matchFlag(zT_335, zT_336);
    if (zT_337) goto z_bb_78; else goto z_bb_80;
    z_bb_78:
    cli.no_null_check = (unsigned char)(1);
    goto z_bb_79;
    z_bb_79:
    goto z_bb_76;
    z_bb_80:
    zT_339 = arg;
    zT_340 = s_no_lifetime;
    zT_341 = zF_5FE51158_matchFlag(zT_339, zT_340);
    if (zT_341) goto z_bb_81; else goto z_bb_83;
    z_bb_81:
    cli.no_lifetime_check = (unsigned char)(1);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    zT_343 = arg;
    zT_344 = s_no_leak;
    zT_345 = zF_5FE51158_matchFlag(zT_343, zT_344);
    if (zT_345) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    cli.no_leak_check = (unsigned char)(1);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_347 = arg;
    zT_348 = s_warn_all;
    zT_349 = zF_5FE51158_matchFlag(zT_347, zT_348);
    if (zT_349) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    cli.warn_all = (unsigned char)(1);
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_351 = arg;
    zT_352 = s_warn_error;
    zT_353 = zF_5FE51158_matchFlag(zT_351, zT_352);
    if (zT_353) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    cli.warnings_as_errors = (unsigned char)(1);
    cli.warn_error = (unsigned char)(1);
    goto z_bb_91;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_356 = arg;
    zT_357 = s_markers;
    zT_358 = zF_5FE51158_matchFlag(zT_356, zT_357);
    if (zT_358) goto z_bb_93; else goto z_bb_95;
    z_bb_93:
    cli.show_markers = (unsigned char)(1);
    goto z_bb_94;
    z_bb_94:
    goto z_bb_91;
    z_bb_95:
    zT_360 = arg;
    zT_361 = s_include;
    zT_362 = zF_5FE51158_matchFlag(zT_360, zT_361);
    if (zT_362) goto z_bb_97; else goto z_bb_96;
    z_bb_96:
    zT_364 = arg;
    zT_365 = s_lib_dir;
    zT_366 = zF_5FE51158_matchFlag(zT_364, zT_365);
    zT_363 = zT_366;
    goto z_bb_98;
    z_bb_97:
    zT_363 = 1;
    goto z_bb_98;
    z_bb_98:
    if (zT_363) goto z_bb_99; else goto z_bb_101;
    z_bb_99:
    zT_367 = 1;
    zT_369 = i + (int)((int)zT_367);
    i = zT_369;
    if ((unsigned char)(i < argc)) goto z_bb_102; else goto z_bb_103;
    z_bb_100:
    goto z_bb_94;
    z_bb_101:
    zT_386 = arg;
    zT_387 = s_osl;
    zT_388 = zF_5FE51158_matchFlag(zT_386, zT_387);
    if (zT_388) goto z_bb_107; else goto z_bb_109;
    z_bb_102:
    zT_372 = cli.include_count;
    zT_373 = 16;
    zT_371 = zT_372 < (unsigned int)zT_373;
    goto z_bb_104;
    z_bb_103:
    zT_371 = 0;
    goto z_bb_104;
    z_bb_104:
    if (zT_371) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_376 = i;
    zT_377 = zF_70B5BFF1_argGet(zT_376);
    zT_375 = zT_377;
    zT_378 = zF_22D0470E_cstrToSlice(zT_375);
    zT_379 = cli.include_dirs;
    zT_380 = cli.include_count;
    zT_381 = (unsigned int)zT_380;
    zT_379[zT_381] = zT_378;
    zT_382 = cli.include_count;
    zT_383 = 1;
    cli.include_count = (unsigned int)(zT_382 + (unsigned int)((unsigned int)zT_383));
    goto z_bb_106;
    z_bb_106:
    goto z_bb_100;
    z_bb_107:
    cli.target_is_windows = (unsigned char)(0);
    goto z_bb_108;
    z_bb_108:
    goto z_bb_100;
    z_bb_109:
    zT_390 = arg;
    zT_391 = s_osw;
    zT_392 = zF_5FE51158_matchFlag(zT_390, zT_391);
    if (zT_392) goto z_bb_110; else goto z_bb_112;
    z_bb_110:
    cli.target_is_windows = (unsigned char)(1);
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    zT_396 = 1;
    if ((unsigned char)((int)(i + zT_396) < argc)) goto z_bb_113; else goto z_bb_114;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_432 = arg;
    zT_433 = s_target;
    zT_434 = zF_5FE51158_matchFlag(zT_432, zT_433);
    if (zT_434) goto z_bb_125; else goto z_bb_127;
    z_bb_113:
    zT_402 = 1;
    zT_404 = zF_70B5BFF1_argGet((int)(i + zT_402));
    zT_400 = zT_404;
    zT_405 = zF_22D0470E_cstrToSlice(zT_400);
    nxt = zT_405;
    zT_407 = nxt.len;
    zT_408 = 0;
    if ((unsigned char)(zT_407 > (unsigned int)zT_408)) goto z_bb_115; else goto z_bb_116;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_411 = nxt.ptr;
    zT_412 = 0;
    zT_413 = zT_411[zT_412];
    zT_410 = zT_413 != (unsigned char)(45);
    goto z_bb_117;
    z_bb_116:
    zT_410 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_410) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_416 = nxt;
    zT_417 = s_profile_9x;
    zT_418 = zF_5FE51158_matchFlag(zT_416, zT_417);
    if (zT_418) goto z_bb_120; else goto z_bb_122;
    z_bb_119:
    goto z_bb_114;
    z_bb_120:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    zT_421 = 1;
    zT_423 = i + (int)((int)zT_421);
    i = zT_423;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_424 = nxt;
    zT_425 = s_profile_nt;
    zT_426 = zF_5FE51158_matchFlag(zT_424, zT_425);
    if (zT_426) goto z_bb_123; else goto z_bb_124;
    z_bb_123:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_nt);
    zT_429 = 1;
    zT_431 = i + (int)((int)zT_429);
    i = zT_431;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_435 = 1;
    zT_437 = i + (int)((int)zT_435);
    i = zT_437;
    if ((unsigned char)(i < argc)) goto z_bb_128; else goto z_bb_129;
    z_bb_126:
    goto z_bb_111;
    z_bb_127:
    zT_446 = arg;
    zT_447 = s_ffast;
    zT_448 = zF_5FE51158_matchFlag(zT_446, zT_447);
    if (zT_448) goto z_bb_132; else goto z_bb_134;
    z_bb_128:
    zT_440 = i;
    zT_441 = zF_70B5BFF1_argGet(zT_440);
    zT_439 = zT_441;
    zT_442 = zF_06CC17EA_parseTargetIsWindow(zT_439);
    cli.target_is_windows = zT_442;
    zT_443 = cli.target_is_windows;
    if (zT_443) goto z_bb_130; else goto z_bb_131;
    z_bb_129:
    goto z_bb_126;
    z_bb_130:
    cli.target_win_profile = (zT_074080EA_WinProfile)(zT_074080EA_WinProfile_win9x);
    goto z_bb_131;
    z_bb_131:
    goto z_bb_129;
    z_bb_132:
    cli.safe_checks = (unsigned char)(0);
    goto z_bb_133;
    z_bb_133:
    goto z_bb_126;
    z_bb_134:
    zT_450 = arg;
    zT_451 = s_fsafe;
    zT_452 = zF_5FE51158_matchFlag(zT_450, zT_451);
    if (zT_452) goto z_bb_135; else goto z_bb_137;
    z_bb_135:
    cli.safe_checks = (unsigned char)(1);
    goto z_bb_136;
    z_bb_136:
    goto z_bb_133;
    z_bb_137:
    zT_454 = arg_ptr;
    zT_455 = zF_22D0470E_cstrToSlice(zT_454);
    cli.input_file = zT_455;
    goto z_bb_136;
}

/* matchFlag */
unsigned char zF_5FE51158_matchFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg, zT_8F083A69_Slice_zT_0B42B2F8_u flag) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    int zT_20;
    unsigned int zT_22;
    unsigned int j;
    zT_3 = arg.len;
    zT_5 = flag.len;
    if ((unsigned char)(zT_3 != zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    j = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = arg.len;
    if ((unsigned char)(j < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = arg.ptr;
    zT_15 = zT_14[j];
    zT_16 = flag.ptr;
    zT_17 = zT_16[j];
    if ((unsigned char)(zT_15 != zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_20 = 1;
    zT_22 = j + (unsigned int)((unsigned int)zT_20);
    j = zT_22;
    goto z_bb_6;
}

/* matchMMFlag */
unsigned char zF_FBF91F7E_matchMMFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mm;
    unsigned int j;
    zT_2 = "-mm";
    zT_4 = 3;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s_mm = zT_3;
    zT_6 = arg.len;
    zT_8 = s_mm.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_mm.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_mm.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* cstrToSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D0470E_cstrToSlice(unsigned char* ptr) {
    int zT_2;
    unsigned int zT_3;
    unsigned char zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int len;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    len = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ptr[len];
    zT_5 = 0;
    if ((unsigned char)(zT_4 != zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    zT_9 = len + (unsigned int)((unsigned int)zT_7);
    len = zT_9;
    goto z_bb_4;
    z_bb_3:
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = (unsigned char*)zT_11;
    zT_13.len = zT_12;
    return zT_13;
    z_bb_4:
    goto z_bb_1;
}

/* parseSize */
unsigned int zF_6CF11065_parseSize(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    unsigned char zT_29;
    int zT_32;
    unsigned int zT_33;
    unsigned char zT_36;
    int zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned char zT_45;
    int zT_48;
    int zT_50;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_54 = 1;
    zT_56 = i + (unsigned int)((unsigned int)zT_54);
    i = zT_56;
    goto z_bb_4;
    z_bb_10:
    if ((unsigned char)(c == (unsigned char)(107))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_29 = c == (unsigned char)(75);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_32 = 1024;
    zT_33 = val * zT_32;
    val = zT_33;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    if ((unsigned char)(c == (unsigned char)(109))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_36 = c == (unsigned char)(77);
    goto z_bb_19;
    z_bb_18:
    zT_36 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_36) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_39 = 1024;
    zT_41 = 1024;
    zT_42 = (unsigned int)(val * zT_39) * zT_41;
    val = zT_42;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    if ((unsigned char)(c == (unsigned char)(103))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_45 = c == (unsigned char)(71);
    goto z_bb_25;
    z_bb_24:
    zT_45 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_45) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_48 = 1024;
    zT_50 = 1024;
    zT_52 = 1024;
    zT_53 = (unsigned int)((unsigned int)(val * zT_48) * zT_50) * zT_52;
    val = zT_53;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_21;
}

/* parseU32 */
unsigned int zF_16BBA09E_parseU32(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char zT_18;
    int zT_21;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_4;
}

/* parseMMBytes */
unsigned int zF_B9231BB9_parseMMBytes(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned char* zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    int zT_26;
    unsigned int zT_28;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_39;
    int zT_40;
    unsigned char zT_42;
    unsigned int zT_44;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int max_mb;
    unsigned int i;
    unsigned int n;
    unsigned int mb;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_5 = (unsigned int)(unsigned int)(256);
    max_mb = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    n = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    mb = zT_14;
    goto z_bb_1;
    z_bb_1:
    zT_16 = rest.len;
    if ((unsigned char)(i < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_19 = rest.ptr;
    zT_20 = zT_19[i];
    c = zT_20;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_40 = 0;
    if ((unsigned char)(n == (unsigned int)zT_40)) goto z_bb_15; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_23 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_23 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_26 = 1;
    zT_28 = n + (unsigned int)((unsigned int)zT_26);
    n = zT_28;
    if ((unsigned char)(mb < max_mb)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = (unsigned int)(mb * (unsigned int)(10)) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    mb = zT_35;
    if ((unsigned char)(mb > max_mb)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_4;
    z_bb_12:
    mb = max_mb;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    zT_44 = rest.len;
    zT_42 = i != zT_44;
    goto z_bb_16;
    z_bb_15:
    zT_42 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_47 = "error: -mm<N> requires a decimal MB size (e.g. -mm64)\n";
    zT_49 = 54;
    zT_48.ptr = (unsigned char*)zT_47;
    zT_48.len = zT_49;
    em = zT_48;
    zT_50 = em;
    zF_E4B2EF19_stderr_write(zT_50);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_18:
    return (unsigned int)(mb * (unsigned int)(1024));
}

/* matchSFlag */
unsigned char zF_C4E3C361_matchSFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_s;
    unsigned int j;
    zT_2 = "-s";
    zT_4 = 2;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    s_s = zT_3;
    zT_6 = arg.len;
    zT_8 = s_s.len;
    if ((unsigned char)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_s.len;
    if ((unsigned char)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_s.ptr;
    zT_20 = zT_19[j];
    if ((unsigned char)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* parseSLevel */
unsigned int zF_153C3795_parseSLevel(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char zT_21;
    int zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_32;
    unsigned int zT_36;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_43;
    int zT_44;
    unsigned char zT_46;
    unsigned int zT_48;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_58;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int i;
    unsigned int n;
    unsigned int level;
    unsigned int over;
    unsigned char c;
    unsigned int d;
    unsigned int nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    n = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    level = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    over = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_14 = rest.len;
    if ((unsigned char)(i < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = rest.ptr;
    zT_18 = zT_17[i];
    c = zT_18;
    if ((unsigned char)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_44 = 0;
    if ((unsigned char)(n == (unsigned int)zT_44)) goto z_bb_16; else goto z_bb_15;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_21 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_21 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_21) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_24 = 1;
    zT_26 = n + (unsigned int)((unsigned int)zT_24);
    n = zT_26;
    zT_27 = 0;
    if ((unsigned char)(over == (unsigned int)zT_27)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_32;
    zT_36 = (unsigned int)(level * (unsigned int)(10)) + d;
    nl = zT_36;
    if ((unsigned char)(nl > (unsigned int)(6))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_4;
    z_bb_12:
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    over = zT_40;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    level = nl;
    goto z_bb_13;
    z_bb_15:
    zT_48 = rest.len;
    zT_46 = i != zT_48;
    goto z_bb_17;
    z_bb_16:
    zT_46 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_46) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_51 = "error: -s<N> requires a decimal level 0..6 (e.g. -s0 all on disk, -s6 all in RAM)\n";
    zT_53 = 82;
    zT_52.ptr = (unsigned char*)zT_51;
    zT_52.len = zT_53;
    em = zT_52;
    zT_54 = em;
    zF_E4B2EF19_stderr_write(zT_54);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_19:
    zT_58 = 0;
    if ((unsigned char)(over != (unsigned int)zT_58)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = "error: -s<N> spill level out of range (0..6: 0 = all on disk, 6 = all in RAM)\n";
    zT_63 = 78;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    em = zT_62;
    zT_64 = em;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_21:
    return level;
}

/* parseColorMode */
zT_CAF40AAB_ColorMode zF_05AD3AFC_parseColorMode(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_always;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_never;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "always";
    zT_7 = 6;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_always = zT_6;
    zT_9 = "never";
    zT_11 = 5;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_never = zT_10;
    zT_12 = s;
    zT_13 = s_always;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_always);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_never;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_never);
    z_bb_4:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_auto);
}

/* parseErrorFormat */
zT_A4FB690E_ErrorFormat zF_A4602959_parseErrorFormat(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_json;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sarif;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "json";
    zT_7 = 4;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_json = zT_6;
    zT_9 = "sarif";
    zT_11 = 5;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_sarif = zT_10;
    zT_12 = s;
    zT_13 = s_json;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_json);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_sarif;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_sarif);
    z_bb_4:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_human);
}

/* parseTargetIsWindows */
unsigned char zF_06CC17EA_parseTargetIsWindow(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned char zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char zT_18 = 0;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_linux;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_windows;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "linux";
    zT_7 = 5;
    zT_6.ptr = (unsigned char*)zT_5;
    zT_6.len = zT_7;
    s_linux = zT_6;
    zT_9 = "windows";
    zT_11 = 7;
    zT_10.ptr = (unsigned char*)zT_9;
    zT_10.len = zT_11;
    s_windows = zT_10;
    zT_12 = s;
    zT_13 = s_windows;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_linux;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_21 = "error: --target must be 'linux' or 'windows'\n";
    zT_23 = 45;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    err_msg = zT_22;
    zT_24 = err_msg;
    zF_E4B2EF19_stderr_write(zT_24);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned char)(0);
}

/* writeU32 */
void zF_266B1B8E_writeU32(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_11;
    int zT_15;
    int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    unsigned char zT_23;
    int zT_24;
    int zT_26;
    unsigned int zT_28;
    int zT_29;
    int zT_30;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 16;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    v = val;
    zT_7 = 0;
    if ((unsigned char)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 48;
    zT_10 = (unsigned char)zT_9;
    zT_11 = 15;
    buf[zT_11] = zT_10;
    zT_15 = 16;
    zT_16 = 15;
    zT_17 = (unsigned char*)((unsigned char*)buf) + zT_16;
    zT_18 = zT_15 - zT_16;
    zT_19.ptr = (unsigned char*)zT_17;
    zT_19.len = zT_18;
    s = zT_19;
    zT_20 = s;
    zF_B5478454_measureMarkerWrite(zT_20);
    return;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_21 = 0;
    if ((unsigned char)(v > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_26 = 1;
    zT_28 = i - (unsigned int)((unsigned int)zT_26);
    i = zT_28;
    zT_29 = 48;
    zT_30 = 10;
    zT_35 = (unsigned char)(unsigned int)((unsigned int)(unsigned int)(zT_29 + (unsigned int)((unsigned int)(unsigned int)(v % zT_30))));
    buf[i] = zT_35;
    zT_36 = 10;
    zT_37 = v / zT_36;
    v = zT_37;
    goto z_bb_6;
    z_bb_5:
    zT_41 = 16;
    zT_42 = (unsigned char*)((unsigned char*)buf) + i;
    zT_43 = zT_41 - i;
    zT_44.ptr = (unsigned char*)zT_42;
    zT_44.len = zT_43;
    s = zT_44;
    zT_45 = s;
    zF_B5478454_measureMarkerWrite(zT_45);
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_24 = 0;
    zT_23 = i > (unsigned int)zT_24;
    goto z_bb_9;
    z_bb_8:
    zT_23 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_23) goto z_bb_4; else goto z_bb_5;
}

/* printUsage */
void zF_9D45DFBF_printUsage(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned char* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned char* zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_109;
    unsigned char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned char* zT_116;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help3;
    zT_8F083A69_Slice_zT_0B42B2F8_u os_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u osw_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u tgt_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u io_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u mem_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u quiet_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u mode_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u warn_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u warn_all_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u diag_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u fmt_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u track_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u checks_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u markers_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u inc_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u safe_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u fast_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u c89_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u help_help;
    zT_1 = "zig1 - Z98 self-hosted compiler - usage: zig1 [options] <input.zig>\n";
    zT_3 = 68;
    zT_2.ptr = (unsigned char*)zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_6 = "  -mm<N>    hard pool budget in MB (default 64; pool.peak over budget -> ICE rc=3)\n";
    zT_8 = 83;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    mm_help = zT_7;
    zT_9 = mm_help;
    zF_E4B2EF19_stderr_write(zT_9);
    zT_11 = "  -s<N>     spill level 0..6 (default 0 = all spills on disk; -s1..-s6 deactivate the\n";
    zT_13 = 86;
    zT_12.ptr = (unsigned char*)zT_11;
    zT_12.len = zT_13;
    s_help = zT_12;
    zT_14 = s_help;
    zF_E4B2EF19_stderr_write(zT_14);
    zT_16 = "            first N spills to RAM in order AST,LIR,HASH,RES,SIDE,EXTRA: higher -s = more RAM,\n";
    zT_18 = 94;
    zT_17.ptr = (unsigned char*)zT_16;
    zT_17.len = zT_18;
    s_help2 = zT_17;
    zT_19 = s_help2;
    zF_E4B2EF19_stderr_write(zT_19);
    zT_21 = "            less disk I/O (pool= rises; -s6 = all in RAM -> pair with -mm128)\n";
    zT_23 = 78;
    zT_22.ptr = (unsigned char*)zT_21;
    zT_22.len = zT_23;
    s_help3 = zT_22;
    zT_24 = s_help3;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_26 = "  -osl      compile target = linux (default)\n";
    zT_28 = 45;
    zT_27.ptr = (unsigned char*)zT_26;
    zT_27.len = zT_28;
    os_help = zT_27;
    zT_29 = os_help;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_31 = "  -osw [9x|nt]  compile target = windows (default 9x = Win9x; nt = NT/XP profile)\n";
    zT_33 = 82;
    zT_32.ptr = (unsigned char*)zT_31;
    zT_32.len = zT_33;
    osw_help = zT_32;
    zT_34 = osw_help;
    zF_E4B2EF19_stderr_write(zT_34);
    zT_36 = "  --target <linux|windows>  long-form target alias for -osl/-osw (windows = 9x default)\n";
    zT_38 = 88;
    zT_37.ptr = (unsigned char*)zT_36;
    zT_37.len = zT_38;
    tgt_help = zT_37;
    zT_39 = tgt_help;
    zF_E4B2EF19_stderr_write(zT_39);
    zT_41 = "  -o, --output-dir <dir>    output directory (default .)\n";
    zT_43 = 57;
    zT_42.ptr = (unsigned char*)zT_41;
    zT_42.len = zT_43;
    io_help = zT_42;
    zT_44 = io_help;
    zF_E4B2EF19_stderr_write(zT_44);
    zT_46 = "  -m, --max-mem <size>      hard pool budget with k/m/g suffix (same as -mm<N>)\n";
    zT_48 = 80;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    mem_help = zT_47;
    zT_49 = mem_help;
    zF_E4B2EF19_stderr_write(zT_49);
    zT_51 = "  -e, --max-errors <n>      max diagnostics (default 256)\n";
    zT_53 = 58;
    zT_52.ptr = (unsigned char*)zT_51;
    zT_52.len = zT_53;
    err_help = zT_52;
    zT_54 = err_help;
    zF_E4B2EF19_stderr_write(zT_54);
    zT_56 = "  -q, --quiet               suppress non-error output\n";
    zT_58 = 54;
    zT_57.ptr = (unsigned char*)zT_56;
    zT_57.len = zT_58;
    quiet_help = zT_57;
    zT_59 = quiet_help;
    zF_E4B2EF19_stderr_write(zT_59);
    zT_61 = "  --test                    run test blocks\n  --sanity-test             lexer sanity test\n";
    zT_63 = 90;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    mode_help = zT_62;
    zT_64 = mode_help;
    zF_E4B2EF19_stderr_write(zT_64);
    zT_66 = "  -W, --warnings-as-errors  treat warnings as errors; --warn-error also sets warn_error\n";
    zT_68 = 88;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    warn_help = zT_67;
    zT_69 = warn_help;
    zF_E4B2EF19_stderr_write(zT_69);
    zT_71 = "  --warn-all                enable all warnings\n";
    zT_73 = 48;
    zT_72.ptr = (unsigned char*)zT_71;
    zT_72.len = zT_73;
    warn_all_help = zT_72;
    zT_74 = warn_all_help;
    zF_E4B2EF19_stderr_write(zT_74);
    zT_76 = "  --color <auto|always|never>  diagnostic color mode (default auto)\n";
    zT_78 = 68;
    zT_77.ptr = (unsigned char*)zT_76;
    zT_77.len = zT_78;
    diag_help = zT_77;
    zT_79 = diag_help;
    zF_E4B2EF19_stderr_write(zT_79);
    zT_81 = "  --error-format <human|json|sarif>  diagnostic format (default human)\n";
    zT_83 = 71;
    zT_82.ptr = (unsigned char*)zT_81;
    zT_82.len = zT_83;
    fmt_help = zT_82;
    zT_84 = fmt_help;
    zF_E4B2EF19_stderr_write(zT_84);
    zT_86 = "  --track-memory            report peak memory\n";
    zT_88 = 47;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    track_help = zT_87;
    zT_89 = track_help;
    zF_E4B2EF19_stderr_write(zT_89);
    zT_91 = "  --no-null-check | --no-lifetime-check | --no-leak-check  disable those checks\n";
    zT_93 = 80;
    zT_92.ptr = (unsigned char*)zT_91;
    zT_92.len = zT_93;
    checks_help = zT_92;
    zT_94 = checks_help;
    zF_E4B2EF19_stderr_write(zT_94);
    zT_96 = "  --markers                 emit phase markers\n";
    zT_98 = 47;
    zT_97.ptr = (unsigned char*)zT_96;
    zT_97.len = zT_98;
    markers_help = zT_97;
    zT_99 = markers_help;
    zF_E4B2EF19_stderr_write(zT_99);
    zT_101 = "  -I <dir>, --lib-dir <dir> add an include/library directory (max 16)\n";
    zT_103 = 70;
    zT_102.ptr = (unsigned char*)zT_101;
    zT_102.len = zT_103;
    inc_help = zT_102;
    zT_104 = inc_help;
    zF_E4B2EF19_stderr_write(zT_104);
    zT_106 = "  -fsafe                    enable runtime checks + undefined poison (default)\n";
    zT_108 = 79;
    zT_107.ptr = (unsigned char*)zT_106;
    zT_107.len = zT_108;
    safe_help = zT_107;
    zT_109 = safe_help;
    zF_E4B2EF19_stderr_write(zT_109);
    zT_111 = "  -ffast                    disable runtime checks + undefined poison\n";
    zT_113 = 70;
    zT_112.ptr = (unsigned char*)zT_111;
    zT_112.len = zT_113;
    fast_help = zT_112;
    zT_114 = fast_help;
    zF_E4B2EF19_stderr_write(zT_114);
    zT_116 = "  --dump-c89                emit C89 into the output directory\n";
    zT_118 = 63;
    zT_117.ptr = (unsigned char*)zT_116;
    zT_117.len = zT_118;
    c89_help = zT_117;
    zT_119 = c89_help;
    zF_E4B2EF19_stderr_write(zT_119);
    zT_121 = "  --help                    show this help\n";
    zT_123 = 43;
    zT_122.ptr = (unsigned char*)zT_121;
    zT_122.len = zT_123;
    help_help = zT_122;
    zT_124 = help_help;
    zF_E4B2EF19_stderr_write(zT_124);
    return;
}

/* __module_init */
void zF_780653D2___module_init(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_69057089_CompilerAlloc zT_1 = {0};
    zT_D3EB6303_StringInterner zT_2 = {0};
    zT_227EDE07_SourceManager zT_3 = {0};
    zT_F85C5DED_DiagnosticCollector zT_4 = {0};
    zT_3A355BD2_Token zT_5 = {0};
    zT_EAC3E484_TokenKind zT_6 = 0;
    zT_072B53A6_ModuleRegistry zT_7 = {0};
    zT_338B7C76_TypeRegistry zT_8 = {0};
    zT_6B356268_SemanticContext zT_9 = {0};
    zT_02EB57B2_LirLowerer zT_10 = {0};
    zT_CA01C129_LirSlotArrayList zT_11 = {0};
    zT_8EED1867_ResolvedTypeTable zT_12 = {0};
    zT_66E7D2EF_CoercionTable zT_13 = {0};
    zT_3D7259E2_SymbolRegistry zT_14 = {0};
    zT_8143F551_AstKind zT_15 = 0;
    zT_6B0A7D14_AstStore zT_16 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_69057089_CompilerAlloc = zT_1;
    zG_D3EB6303_StringInterner = zT_2;
    zG_227EDE07_SourceManager = zT_3;
    zG_F85C5DED_DiagnosticCollector = zT_4;
    zG_3A355BD2_Token = zT_5;
    zG_EAC3E484_TokenKind = zT_6;
    zG_072B53A6_ModuleRegistry = zT_7;
    zG_338B7C76_TypeRegistry = zT_8;
    zG_6B356268_SemanticContext = zT_9;
    zG_02EB57B2_LirLowerer = zT_10;
    zG_CA01C129_LirSlotArrayList = zT_11;
    zG_8EED1867_ResolvedTypeTable = zT_12;
    zG_66E7D2EF_CoercionTable = zT_13;
    zG_3D7259E2_SymbolRegistry = zT_14;
    zG_8143F551_AstKind = zT_15;
    zG_6B0A7D14_AstStore = zT_16;
    return;
}

/* EOF */
