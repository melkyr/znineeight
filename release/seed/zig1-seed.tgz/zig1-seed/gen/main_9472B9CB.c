#include "main_9472B9CB.h"
/* main */
void zF_EA90E208_main(int argc, unsigned char** argv) {
    int zT_2;
    unsigned char** zT_3;
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    zT_C98AF326_CompilerCli zT_10 = {0};
    int zT_11;
    int zT_14;
    zT_69057089_CompilerAlloc zT_16 = {0};
    zT_3E40CD83_Sand* zT_18;
    zT_69057089_CompilerAlloc* zT_20;
    int zT_22;
    zT_D3EB6303_StringInterner zT_24 = {0};
    zT_3E40CD83_Sand* zT_26;
    zT_69057089_CompilerAlloc* zT_27;
    zT_227EDE07_SourceManager zT_29 = {0};
    zT_3E40CD83_Sand* zT_31;
    zT_227EDE07_SourceManager* zT_32;
    zT_D3EB6303_StringInterner* zT_33;
    zT_69057089_CompilerAlloc* zT_34;
    zT_3E40CD83_Sand* zT_39;
    zT_69057089_CompilerAlloc* zT_40;
    int zT_42;
    char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_53;
    int zT_54;
    int zT_56;
    int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    int zT_60 = 0;
    char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_69057089_CompilerAlloc zT_77 = {0};
    unsigned int zT_78;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_3E40CD83_Sand* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    zT_69057089_CompilerAlloc* zT_85;
    zT_06CE572C_Opt_407 zT_87 = {0};
    unsigned char zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    unsigned int zT_101;
    unsigned int zT_104;
    unsigned int zT_108;
    unsigned int zT_111;
    zT_3E40CD83_Sand* zT_113;
    unsigned int zT_114;
    zT_69057089_CompilerAlloc* zT_115;
    zT_D3EB6303_StringInterner zT_117 = {0};
    zT_3E40CD83_Sand* zT_119;
    zT_69057089_CompilerAlloc* zT_120;
    zT_227EDE07_SourceManager zT_122 = {0};
    zT_3E40CD83_Sand* zT_124;
    zT_227EDE07_SourceManager* zT_125;
    zT_D3EB6303_StringInterner* zT_126;
    zT_69057089_CompilerAlloc* zT_127;
    zT_F85C5DED_DiagnosticCollector zT_131 = {0};
    unsigned int zT_132;
    zT_3E40CD83_Sand* zT_134;
    zT_69057089_CompilerAlloc* zT_135;
    zT_CEC2984A_NameMangler zT_138 = {0};
    zT_3E40CD83_Sand* zT_140;
    zT_D3EB6303_StringInterner* zT_141;
    zT_F85C5DED_DiagnosticCollector* zT_142;
    zT_69057089_CompilerAlloc* zT_143;
    zT_072B53A6_ModuleRegistry zT_147 = {0};
    zT_072B53A6_ModuleRegistry* zT_148;
    zT_227EDE07_SourceManager* zT_149;
    zT_7D82FE60_GrowableSand zT_153 = {0};
    char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_7D82FE60_GrowableSand* zT_158;
    zT_3E40CD83_Sand* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    zT_3E40CD83_Sand* zT_163 = 0;
    int zT_164;
    zT_3E40CD83_Sand* zT_167;
    zT_D3EB6303_StringInterner* zT_168;
    zT_7D82FE60_GrowableSand* zT_169;
    zT_338B7C76_TypeRegistry zT_172 = {0};
    zT_338B7C76_TypeRegistry* zT_173;
    zT_3E40CD83_Sand* zT_176;
    zT_69057089_CompilerAlloc* zT_177;
    zT_6B0A7D14_AstStore zT_179 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_181;
    unsigned int zT_183;
    int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_188;
    unsigned int zT_190;
    int zT_192;
    unsigned char* zT_195;
    unsigned char zT_196;
    unsigned int zT_198;
    unsigned int zT_200;
    unsigned char zT_201;
    unsigned int zT_203;
    unsigned char zT_204;
    unsigned int zT_206;
    unsigned char zT_207;
    unsigned int zT_209;
    char* zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    unsigned int zT_213;
    unsigned int zT_215;
    unsigned int zT_217;
    int zT_219;
    unsigned char* zT_222;
    unsigned char zT_223;
    unsigned int zT_225;
    unsigned int zT_227;
    zT_6B0A7D14_AstStore* zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229;
    int zT_233;
    unsigned char* zT_234;
    unsigned int zT_235;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_236;
    zT_846744CC_Arr_unsigned_char_5 zT_238;
    unsigned int zT_240;
    int zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned int zT_245;
    unsigned int zT_247;
    int zT_249;
    unsigned char* zT_252;
    unsigned char zT_253;
    unsigned int zT_255;
    unsigned int zT_257;
    unsigned char zT_258;
    unsigned int zT_260;
    unsigned char zT_261;
    unsigned int zT_263;
    unsigned char zT_264;
    unsigned int zT_266;
    char* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_270;
    unsigned int zT_272;
    unsigned int zT_274;
    int zT_276;
    unsigned char* zT_279;
    unsigned char zT_280;
    unsigned int zT_282;
    unsigned int zT_284;
    zT_6B0A7D14_AstStore* zT_285;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    int zT_292;
    unsigned char* zT_293;
    unsigned int zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    zT_846744CC_Arr_unsigned_char_5 zT_297;
    unsigned int zT_299;
    int zT_300;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_304;
    unsigned int zT_306;
    int zT_308;
    unsigned char* zT_311;
    unsigned char zT_312;
    unsigned int zT_314;
    unsigned int zT_316;
    unsigned char zT_317;
    unsigned int zT_319;
    unsigned char zT_320;
    unsigned int zT_322;
    unsigned char zT_323;
    unsigned int zT_325;
    char* zT_327;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    unsigned int zT_329;
    unsigned int zT_331;
    unsigned int zT_333;
    int zT_335;
    unsigned char* zT_338;
    unsigned char zT_339;
    unsigned int zT_341;
    unsigned int zT_343;
    zT_6B0A7D14_AstStore* zT_344;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_346;
    int zT_351;
    unsigned char* zT_352;
    unsigned int zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354;
    zT_3E40CD83_Sand* zT_356;
    zT_69057089_CompilerAlloc* zT_357;
    zT_3D7259E2_SymbolRegistry zT_359 = {0};
    zT_3E40CD83_Sand* zT_361;
    zT_69057089_CompilerAlloc* zT_362;
    zT_8EED1867_ResolvedTypeTable zT_364 = {0};
    zT_846744CC_Arr_unsigned_char_5 zT_366;
    unsigned int zT_368;
    int zT_369;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_371;
    unsigned int zT_373;
    unsigned int zT_375;
    int zT_377;
    unsigned char* zT_380;
    unsigned char zT_381;
    unsigned int zT_383;
    unsigned int zT_385;
    unsigned char zT_386;
    unsigned int zT_388;
    unsigned char zT_389;
    unsigned int zT_391;
    unsigned char zT_392;
    unsigned int zT_394;
    char* zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397;
    unsigned int zT_398;
    unsigned int zT_400;
    unsigned int zT_402;
    int zT_404;
    unsigned char* zT_407;
    unsigned char zT_408;
    unsigned int zT_410;
    unsigned int zT_412;
    zT_8EED1867_ResolvedTypeTable* zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_414;
    int zT_418;
    unsigned char* zT_419;
    unsigned int zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421;
    zT_3E40CD83_Sand* zT_423;
    zT_69057089_CompilerAlloc* zT_424;
    zT_66E7D2EF_CoercionTable zT_426 = {0};
    zT_3E40CD83_Sand* zT_428;
    zT_69057089_CompilerAlloc* zT_429;
    zT_CA01C129_LirSlotArrayList zT_431 = {0};
    zT_3E40CD83_Sand* zT_433;
    zT_69057089_CompilerAlloc* zT_434;
    zT_4D61441E_DepGraph zT_436 = {0};
    zT_3E40CD83_Sand* zT_438;
    zT_69057089_CompilerAlloc* zT_439;
    zT_21D3708C_U32ToU32Map zT_441 = {0};
    zT_3E40CD83_Sand* zT_443;
    zT_69057089_CompilerAlloc* zT_444;
    zT_21D3708C_U32ToU32Map zT_446 = {0};
    zT_3E40CD83_Sand* zT_448;
    zT_69057089_CompilerAlloc* zT_449;
    zT_21D3708C_U32ToU32Map zT_451 = {0};
    zT_3E40CD83_Sand* zT_453;
    zT_69057089_CompilerAlloc* zT_454;
    zT_21D3708C_U32ToU32Map zT_456 = {0};
    zT_3E40CD83_Sand* zT_458;
    zT_69057089_CompilerAlloc* zT_459;
    zT_89877D19_U32ToU64Map zT_461 = {0};
    zT_3E40CD83_Sand* zT_463;
    zT_69057089_CompilerAlloc* zT_464;
    zT_A4CE86B7_U64ToU32Map zT_466 = {0};
    zT_5AB29387_CompilerContext zT_468;
    zT_69057089_CompilerAlloc* zT_469;
    zT_D3EB6303_StringInterner* zT_470;
    zT_F85C5DED_DiagnosticCollector* zT_471;
    zT_227EDE07_SourceManager* zT_472;
    zT_CEC2984A_NameMangler* zT_473;
    zT_072B53A6_ModuleRegistry* zT_474;
    zT_338B7C76_TypeRegistry* zT_475;
    zT_6B0A7D14_AstStore* zT_476;
    zT_3D7259E2_SymbolRegistry* zT_477;
    zT_8EED1867_ResolvedTypeTable* zT_478;
    zT_66E7D2EF_CoercionTable* zT_479;
    zT_4D61441E_DepGraph* zT_480;
    zT_7E7544E4_LirStream zT_481 = {0};
    int zT_482;
    unsigned int zT_483;
    zT_3E40CD83_Sand* zT_484;
    zT_69057089_CompilerAlloc* zT_485;
    zT_E1A783EF_GlobalDeclArrayList zT_487 = {0};
    zT_5AB29387_CompilerContext* zT_488;
    zT_8F083A69_Slice_zT_0B42B2F8_u startmsg;
    zT_C98AF326_CompilerCli cli;
    zT_69057089_CompilerAlloc compiler_alloc;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u source;
    unsigned int interner_bc;
    zT_CEC2984A_NameMangler name_mangler;
    zT_072B53A6_ModuleRegistry mr;
    zT_7D82FE60_GrowableSand type_db_arena;
    zT_8F083A69_Slice_zT_0B42B2F8_u type_db_name;
    zT_338B7C76_TypeRegistry typereg;
    zT_6B0A7D14_AstStore store;
    zT_846744CC_Arr_unsigned_char_5 ast_spill_path;
    unsigned int asp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od2;
    unsigned int oi2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ast_tmp_name;
    unsigned int ati;
    zT_846744CC_Arr_unsigned_char_5 id_spill_path;
    unsigned int idp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od3;
    unsigned int oi3;
    zT_8F083A69_Slice_zT_0B42B2F8_u id_tmp_name;
    unsigned int iti;
    zT_846744CC_Arr_unsigned_char_5 iv_spill_path;
    unsigned int ivp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od5;
    unsigned int oi5;
    zT_8F083A69_Slice_zT_0B42B2F8_u iv_tmp_name;
    unsigned int ivi;
    zT_3D7259E2_SymbolRegistry symbol_reg;
    zT_8EED1867_ResolvedTypeTable resolved_types;
    zT_846744CC_Arr_unsigned_char_5 rtt_spill_path;
    unsigned int rsp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od4;
    unsigned int oi4;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtt_tmp_name;
    unsigned int rti2;
    zT_66E7D2EF_CoercionTable coercion_table;
    zT_CA01C129_LirSlotArrayList lir_slots;
    zT_4D61441E_DepGraph dep_graph;
    zT_21D3708C_U32ToU32Map enum_value_table;
    zT_21D3708C_U32ToU32Map error_code_registry;
    zT_21D3708C_U32ToU32Map call_arg_types;
    zT_21D3708C_U32ToU32Map call_param_map;
    zT_89877D19_U32ToU64Map comptime_values;
    zT_A4CE86B7_U64ToU32Map exported;
    zT_5AB29387_CompilerContext ctx;
    zT_2 = argc;
    zT_3 = argv;
    zF_4DE8E0A6_initArgs(zT_2, zT_3);
    zT_5 = "START\n";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    startmsg = zT_6;
    zT_8 = startmsg;
    zF_48AC7B3A_markerWrite(zT_8);
    zT_10 = zF_6143A521_parseArgs();
    cli = zT_10;
    zT_11 = cli.show_markers;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zF_3C88665D_markersEnabled((unsigned int)(1));
    goto z_bb_2;
    z_bb_2:
    zT_14 = cli.sanity_test_mode;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_16;
    zT_20 = &compiler_alloc;
    zT_18 = &zT_20->permanent;
    zT_22 = 4;
    zT_24 = zF_FB2E811D_stringInternerInit(zT_18, (unsigned int)((unsigned int)zT_22));
    interner = zT_24;
    zT_27 = &compiler_alloc;
    zT_26 = &zT_27->permanent;
    zT_29 = zF_01351F51_sourceManagerInit(zT_26);
    source_man = zT_29;
    zT_34 = &compiler_alloc;
    zT_31 = &zT_34->permanent;
    zT_32 = &source_man;
    zT_33 = &interner;
    (void)zF_C7BA7DAB_diagnosticCollector(zT_31, zT_32, zT_33);
    zT_40 = &compiler_alloc;
    zT_39 = &zT_40->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_39);
    zF_519E4401_lexerTestSanityChec();
    return;
    z_bb_4:
    zT_42 = cli.test_mode;
    if (zT_42) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_44 = "error: use test_main.zig for test mode\n";
    zT_46 = 39;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    msg = zT_45;
    zT_47 = msg;
    zF_48AC7B3A_markerWrite(zT_47);
    zT_49 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_49));
    return;
    z_bb_6:
    zT_51 = cli.input_file;
    zT_53 = zT_51.len;
    zT_54 = 0;
    if ((int)(zT_53 == (unsigned int)zT_54)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zF_9D45DFBF_printUsage();
    return;
    z_bb_8:
    zT_56 = cli.output_dir_set;
    if (zT_56) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_59 = cli.output_dir;
    zT_58 = zT_59;
    zT_60 = zF_8CC05F84_dirExists(zT_58);
    zT_57 = !zT_60;
    goto z_bb_11;
    z_bb_10:
    zT_57 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_57) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_63 = "error: output directory does not exist: ";
    zT_65 = 40;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    msg = zT_64;
    zT_66 = msg;
    zF_E4B2EF19_stderr_write(zT_66);
    zT_68 = cli.output_dir;
    zT_67 = zT_68;
    zF_E4B2EF19_stderr_write(zT_67);
    zT_70 = "\n";
    zT_72 = 1;
    zT_71.ptr = zT_70;
    zT_71.len = zT_72;
    nl = zT_71;
    zT_73 = nl;
    zF_E4B2EF19_stderr_write(zT_73);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_13:
    zT_77 = zF_90E832C7_initCompilerAlloc();
    compiler_alloc = zT_77;
    zT_78 = cli.max_mem;
    compiler_alloc.max_mem = zT_78;
    zT_79 = cli.spill_level;
    zF_4EDF4E7B_spillSetLevel(zT_79);
    zT_84 = cli.input_file;
    zT_82 = zT_84;
    zT_85 = &compiler_alloc;
    zT_83 = &zT_85->permanent;
    zT_87 = zF_5B859C63_readFile(zT_82, zT_83);
    zT_88 = zT_87.has_value;
    if (zT_88) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_92 = "error: could not read input file\n";
    zT_94 = 33;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = msg;
    zF_E4B2EF19_stderr_write(zT_95);
    zF_CDED1A85_exit((unsigned char)(1));
    return;
    z_bb_15:
    zT_98 = zT_87.value;
    zT_89 = zT_98;
    goto z_bb_16;
    z_bb_16:
    source = zT_89;
    zT_101 = source.len;
    zT_104 = source.len;
    zT_108 = (unsigned int)((unsigned int)zT_101) + (unsigned int)((unsigned int)(unsigned int)(zT_104 / (unsigned int)(4)));
    interner_bc = zT_108;
    if ((int)(interner_bc < (unsigned int)(4096))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_111 = 4096;
    interner_bc = zT_111;
    goto z_bb_18;
    z_bb_18:
    zT_115 = &compiler_alloc;
    zT_113 = &zT_115->permanent;
    zT_114 = interner_bc;
    zT_117 = zF_FB2E811D_stringInternerInit(zT_113, zT_114);
    interner = zT_117;
    zT_120 = &compiler_alloc;
    zT_119 = &zT_120->permanent;
    zT_122 = zF_01351F51_sourceManagerInit(zT_119);
    source_man = zT_122;
    zT_127 = &compiler_alloc;
    zT_124 = &zT_127->permanent;
    zT_125 = &source_man;
    zT_126 = &interner;
    zT_131 = zF_C7BA7DAB_diagnosticCollector(zT_124, zT_125, zT_126);
    diag = zT_131;
    zT_132 = cli.max_errors;
    diag.max_diagnostics = (unsigned int)((unsigned int)zT_132);
    zT_135 = &compiler_alloc;
    zT_134 = &zT_135->permanent;
    zF_DAFC3CA2_initKeywordTable(zT_134);
    zT_138 = zF_27DA3900_nameManglerInit();
    name_mangler = zT_138;
    zT_143 = &compiler_alloc;
    zT_140 = &zT_143->permanent;
    zT_141 = &interner;
    zT_142 = &diag;
    zT_147 = zF_896FAF3C_moduleRegistryInit(zT_140, zT_141, zT_142);
    mr = zT_147;
    zT_148 = &mr;
    zT_149 = &source_man;
    zF_BD2BF0BD_moduleRegistrySetSo(zT_148, zT_149);
    type_db_arena = zT_153;
    zT_155 = "type_db";
    zT_157 = 7;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    type_db_name = zT_156;
    zT_158 = &type_db_arena;
    zT_163 = zF_8C23960F_poolPtr();
    zT_159 = zT_163;
    zT_164 = 4096;
    zT_161 = type_db_name;
    zF_07B11742_growableSandInit(zT_158, zT_159, (unsigned int)((unsigned int)zT_164), zT_161);
    zT_169 = &type_db_arena;
    zT_167 = &zT_169->view;
    zT_168 = &interner;
    zT_172 = zF_4801746C_typeRegistryInit(zT_167, zT_168);
    typereg = zT_172;
    zT_173 = &typereg;
    zF_541737A5_typeRegistryRegiste(zT_173);
    zT_177 = &compiler_alloc;
    zT_176 = &zT_177->module;
    zT_179 = zF_D9F91436_astStoreInit(zT_176);
    store = zT_179;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_181[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        ast_spill_path[_i] = zT_181[_i];
        _i++;
    }
}
    zT_183 = 0;
    asp_len = zT_183;
    zT_184 = cli.output_dir_set;
    if (zT_184) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_186 = cli.output_dir;
    od2 = zT_186;
    zT_188 = 0;
    oi2 = zT_188;
    goto z_bb_22;
    z_bb_20:
    zT_211 = ".zig1_ast.tmp";
    zT_213 = 13;
    zT_212.ptr = zT_211;
    zT_212.len = zT_213;
    ast_tmp_name = zT_212;
    zT_215 = 0;
    ati = zT_215;
    goto z_bb_29;
    z_bb_21:
    zT_204 = 46;
    ast_spill_path[asp_len] = zT_204;
    zT_206 = asp_len + (unsigned int)(1);
    asp_len = zT_206;
    zT_207 = 47;
    ast_spill_path[asp_len] = zT_207;
    zT_209 = asp_len + (unsigned int)(1);
    asp_len = zT_209;
    goto z_bb_20;
    z_bb_22:
    zT_190 = od2.len;
    if ((int)(oi2 < zT_190)) goto z_bb_26; else goto z_bb_27;
    z_bb_23:
    zT_195 = od2.ptr;
    zT_196 = zT_195[oi2];
    ast_spill_path[asp_len] = zT_196;
    zT_198 = asp_len + (unsigned int)(1);
    asp_len = zT_198;
    goto z_bb_25;
    z_bb_24:
    zT_201 = 47;
    ast_spill_path[asp_len] = zT_201;
    zT_203 = asp_len + (unsigned int)(1);
    asp_len = zT_203;
    goto z_bb_20;
    z_bb_25:
    zT_200 = oi2 + (unsigned int)(1);
    oi2 = zT_200;
    goto z_bb_22;
    z_bb_26:
    zT_192 = asp_len < (unsigned int)(511);
    goto z_bb_28;
    z_bb_27:
    zT_192 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_192) goto z_bb_23; else goto z_bb_24;
    z_bb_29:
    zT_217 = ast_tmp_name.len;
    if ((int)(ati < zT_217)) goto z_bb_33; else goto z_bb_34;
    z_bb_30:
    zT_222 = ast_tmp_name.ptr;
    zT_223 = zT_222[ati];
    ast_spill_path[asp_len] = zT_223;
    zT_225 = asp_len + (unsigned int)(1);
    asp_len = zT_225;
    goto z_bb_32;
    z_bb_31:
    zT_228 = &store;
    zT_233 = 0;
    zT_234 = (unsigned char*)((unsigned char*)ast_spill_path) + zT_233;
    zT_235 = asp_len - zT_233;
    zT_236.ptr = zT_234;
    zT_236.len = zT_235;
    zT_229 = zT_236;
    zF_2A507339_astStoreSetSpillPat(zT_228, zT_229);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_238[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        id_spill_path[_i] = zT_238[_i];
        _i++;
    }
}
    zT_240 = 0;
    idp_len = zT_240;
    zT_241 = cli.output_dir_set;
    if (zT_241) goto z_bb_36; else goto z_bb_38;
    z_bb_32:
    zT_227 = ati + (unsigned int)(1);
    ati = zT_227;
    goto z_bb_29;
    z_bb_33:
    zT_219 = asp_len < (unsigned int)(511);
    goto z_bb_35;
    z_bb_34:
    zT_219 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_219) goto z_bb_30; else goto z_bb_31;
    z_bb_36:
    zT_243 = cli.output_dir;
    od3 = zT_243;
    zT_245 = 0;
    oi3 = zT_245;
    goto z_bb_39;
    z_bb_37:
    zT_268 = ".zig1_side.tmp";
    zT_270 = 14;
    zT_269.ptr = zT_268;
    zT_269.len = zT_270;
    id_tmp_name = zT_269;
    zT_272 = 0;
    iti = zT_272;
    goto z_bb_46;
    z_bb_38:
    zT_261 = 46;
    id_spill_path[idp_len] = zT_261;
    zT_263 = idp_len + (unsigned int)(1);
    idp_len = zT_263;
    zT_264 = 47;
    id_spill_path[idp_len] = zT_264;
    zT_266 = idp_len + (unsigned int)(1);
    idp_len = zT_266;
    goto z_bb_37;
    z_bb_39:
    zT_247 = od3.len;
    if ((int)(oi3 < zT_247)) goto z_bb_43; else goto z_bb_44;
    z_bb_40:
    zT_252 = od3.ptr;
    zT_253 = zT_252[oi3];
    id_spill_path[idp_len] = zT_253;
    zT_255 = idp_len + (unsigned int)(1);
    idp_len = zT_255;
    goto z_bb_42;
    z_bb_41:
    zT_258 = 47;
    id_spill_path[idp_len] = zT_258;
    zT_260 = idp_len + (unsigned int)(1);
    idp_len = zT_260;
    goto z_bb_37;
    z_bb_42:
    zT_257 = oi3 + (unsigned int)(1);
    oi3 = zT_257;
    goto z_bb_39;
    z_bb_43:
    zT_249 = idp_len < (unsigned int)(511);
    goto z_bb_45;
    z_bb_44:
    zT_249 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_249) goto z_bb_40; else goto z_bb_41;
    z_bb_46:
    zT_274 = id_tmp_name.len;
    if ((int)(iti < zT_274)) goto z_bb_50; else goto z_bb_51;
    z_bb_47:
    zT_279 = id_tmp_name.ptr;
    zT_280 = zT_279[iti];
    id_spill_path[idp_len] = zT_280;
    zT_282 = idp_len + (unsigned int)(1);
    idp_len = zT_282;
    goto z_bb_49;
    z_bb_48:
    zT_285 = &store;
    zT_292 = 0;
    zT_293 = (unsigned char*)((unsigned char*)id_spill_path) + zT_292;
    zT_294 = idp_len - zT_292;
    zT_295.ptr = zT_293;
    zT_295.len = zT_294;
    zT_287 = zT_295;
    zF_35B9B6EC_astStoreSetValuePoo(zT_285, (unsigned int)(0), zT_287);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_297[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        iv_spill_path[_i] = zT_297[_i];
        _i++;
    }
}
    zT_299 = 0;
    ivp_len = zT_299;
    zT_300 = cli.output_dir_set;
    if (zT_300) goto z_bb_53; else goto z_bb_55;
    z_bb_49:
    zT_284 = iti + (unsigned int)(1);
    iti = zT_284;
    goto z_bb_46;
    z_bb_50:
    zT_276 = idp_len < (unsigned int)(511);
    goto z_bb_52;
    z_bb_51:
    zT_276 = 0;
    goto z_bb_52;
    z_bb_52:
    if (zT_276) goto z_bb_47; else goto z_bb_48;
    z_bb_53:
    zT_302 = cli.output_dir;
    od5 = zT_302;
    zT_304 = 0;
    oi5 = zT_304;
    goto z_bb_56;
    z_bb_54:
    zT_327 = ".zig1_side_iv.tmp";
    zT_329 = 17;
    zT_328.ptr = zT_327;
    zT_328.len = zT_329;
    iv_tmp_name = zT_328;
    zT_331 = 0;
    ivi = zT_331;
    goto z_bb_63;
    z_bb_55:
    zT_320 = 46;
    iv_spill_path[ivp_len] = zT_320;
    zT_322 = ivp_len + (unsigned int)(1);
    ivp_len = zT_322;
    zT_323 = 47;
    iv_spill_path[ivp_len] = zT_323;
    zT_325 = ivp_len + (unsigned int)(1);
    ivp_len = zT_325;
    goto z_bb_54;
    z_bb_56:
    zT_306 = od5.len;
    if ((int)(oi5 < zT_306)) goto z_bb_60; else goto z_bb_61;
    z_bb_57:
    zT_311 = od5.ptr;
    zT_312 = zT_311[oi5];
    iv_spill_path[ivp_len] = zT_312;
    zT_314 = ivp_len + (unsigned int)(1);
    ivp_len = zT_314;
    goto z_bb_59;
    z_bb_58:
    zT_317 = 47;
    iv_spill_path[ivp_len] = zT_317;
    zT_319 = ivp_len + (unsigned int)(1);
    ivp_len = zT_319;
    goto z_bb_54;
    z_bb_59:
    zT_316 = oi5 + (unsigned int)(1);
    oi5 = zT_316;
    goto z_bb_56;
    z_bb_60:
    zT_308 = ivp_len < (unsigned int)(511);
    goto z_bb_62;
    z_bb_61:
    zT_308 = 0;
    goto z_bb_62;
    z_bb_62:
    if (zT_308) goto z_bb_57; else goto z_bb_58;
    z_bb_63:
    zT_333 = iv_tmp_name.len;
    if ((int)(ivi < zT_333)) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_338 = iv_tmp_name.ptr;
    zT_339 = zT_338[ivi];
    iv_spill_path[ivp_len] = zT_339;
    zT_341 = ivp_len + (unsigned int)(1);
    ivp_len = zT_341;
    goto z_bb_66;
    z_bb_65:
    zT_344 = &store;
    zT_351 = 0;
    zT_352 = (unsigned char*)((unsigned char*)iv_spill_path) + zT_351;
    zT_353 = ivp_len - zT_351;
    zT_354.ptr = zT_352;
    zT_354.len = zT_353;
    zT_346 = zT_354;
    zF_35B9B6EC_astStoreSetValuePoo(zT_344, (unsigned int)(1), zT_346);
    zT_357 = &compiler_alloc;
    zT_356 = &zT_357->permanent;
    zT_359 = zF_09A884A8_symbolRegistryInit(zT_356);
    symbol_reg = zT_359;
    zT_362 = &compiler_alloc;
    zT_361 = &zT_362->module;
    zT_364 = zF_8D0F00B1_resolvedTypeTableIn(zT_361);
    resolved_types = zT_364;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_366[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        rtt_spill_path[_i] = zT_366[_i];
        _i++;
    }
}
    zT_368 = 0;
    rsp_len = zT_368;
    zT_369 = cli.output_dir_set;
    if (zT_369) goto z_bb_70; else goto z_bb_72;
    z_bb_66:
    zT_343 = ivi + (unsigned int)(1);
    ivi = zT_343;
    goto z_bb_63;
    z_bb_67:
    zT_335 = ivp_len < (unsigned int)(511);
    goto z_bb_69;
    z_bb_68:
    zT_335 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_335) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_371 = cli.output_dir;
    od4 = zT_371;
    zT_373 = 0;
    oi4 = zT_373;
    goto z_bb_73;
    z_bb_71:
    zT_396 = ".zig1_res.tmp";
    zT_398 = 13;
    zT_397.ptr = zT_396;
    zT_397.len = zT_398;
    rtt_tmp_name = zT_397;
    zT_400 = 0;
    rti2 = zT_400;
    goto z_bb_80;
    z_bb_72:
    zT_389 = 46;
    rtt_spill_path[rsp_len] = zT_389;
    zT_391 = rsp_len + (unsigned int)(1);
    rsp_len = zT_391;
    zT_392 = 47;
    rtt_spill_path[rsp_len] = zT_392;
    zT_394 = rsp_len + (unsigned int)(1);
    rsp_len = zT_394;
    goto z_bb_71;
    z_bb_73:
    zT_375 = od4.len;
    if ((int)(oi4 < zT_375)) goto z_bb_77; else goto z_bb_78;
    z_bb_74:
    zT_380 = od4.ptr;
    zT_381 = zT_380[oi4];
    rtt_spill_path[rsp_len] = zT_381;
    zT_383 = rsp_len + (unsigned int)(1);
    rsp_len = zT_383;
    goto z_bb_76;
    z_bb_75:
    zT_386 = 47;
    rtt_spill_path[rsp_len] = zT_386;
    zT_388 = rsp_len + (unsigned int)(1);
    rsp_len = zT_388;
    goto z_bb_71;
    z_bb_76:
    zT_385 = oi4 + (unsigned int)(1);
    oi4 = zT_385;
    goto z_bb_73;
    z_bb_77:
    zT_377 = rsp_len < (unsigned int)(511);
    goto z_bb_79;
    z_bb_78:
    zT_377 = 0;
    goto z_bb_79;
    z_bb_79:
    if (zT_377) goto z_bb_74; else goto z_bb_75;
    z_bb_80:
    zT_402 = rtt_tmp_name.len;
    if ((int)(rti2 < zT_402)) goto z_bb_84; else goto z_bb_85;
    z_bb_81:
    zT_407 = rtt_tmp_name.ptr;
    zT_408 = zT_407[rti2];
    rtt_spill_path[rsp_len] = zT_408;
    zT_410 = rsp_len + (unsigned int)(1);
    rsp_len = zT_410;
    goto z_bb_83;
    z_bb_82:
    zT_413 = &resolved_types;
    zT_418 = 0;
    zT_419 = (unsigned char*)((unsigned char*)rtt_spill_path) + zT_418;
    zT_420 = rsp_len - zT_418;
    zT_421.ptr = zT_419;
    zT_421.len = zT_420;
    zT_414 = zT_421;
    zF_7238A436_resolvedTypeTableSe(zT_413, zT_414);
    zT_424 = &compiler_alloc;
    zT_423 = &zT_424->module;
    zT_426 = zF_26B6D809_coercionTableInit(zT_423);
    coercion_table = zT_426;
    zT_429 = &compiler_alloc;
    zT_428 = &zT_429->emission;
    zT_431 = zF_F91F6677_lirSlotArrayListIni(zT_428);
    lir_slots = zT_431;
    zT_434 = &compiler_alloc;
    zT_433 = &zT_434->module;
    zT_436 = zF_7F194604_depGraphInit(zT_433);
    dep_graph = zT_436;
    zT_439 = &compiler_alloc;
    zT_438 = &zT_439->module;
    zT_441 = zF_58BDA2DE_u32ToU32MapInit(zT_438);
    enum_value_table = zT_441;
    zT_444 = &compiler_alloc;
    zT_443 = &zT_444->emission;
    zT_446 = zF_58BDA2DE_u32ToU32MapInit(zT_443);
    error_code_registry = zT_446;
    zT_449 = &compiler_alloc;
    zT_448 = &zT_449->module;
    zT_451 = zF_58BDA2DE_u32ToU32MapInit(zT_448);
    call_arg_types = zT_451;
    zT_454 = &compiler_alloc;
    zT_453 = &zT_454->module;
    zT_456 = zF_58BDA2DE_u32ToU32MapInit(zT_453);
    call_param_map = zT_456;
    zT_459 = &compiler_alloc;
    zT_458 = &zT_459->module;
    zT_461 = zF_A8016047_u32ToU64MapInit(zT_458);
    comptime_values = zT_461;
    zT_464 = &compiler_alloc;
    zT_463 = &zT_464->emission;
    zT_466 = zF_986226E1_u64ToU32MapInit(zT_463);
    exported = zT_466;
    zT_468.cli = cli;
    zT_469 = &compiler_alloc;
    zT_468.alloc = zT_469;
    zT_470 = &interner;
    zT_468.interner = zT_470;
    zT_471 = &diag;
    zT_468.diag = zT_471;
    zT_472 = &source_man;
    zT_468.source_man = zT_472;
    zT_473 = &name_mangler;
    zT_468.name_mangler = zT_473;
    zT_474 = &mr;
    zT_468.module_reg = zT_474;
    zT_475 = &typereg;
    zT_468.typereg = zT_475;
    zT_476 = &store;
    zT_468.store = zT_476;
    zT_477 = &symbol_reg;
    zT_468.symbol_reg = zT_477;
    zT_478 = &resolved_types;
    zT_468.resolved_types = zT_478;
    zT_479 = &coercion_table;
    zT_468.coercion_table = zT_479;
    zT_480 = &dep_graph;
    zT_468.dep_graph = zT_480;
    zT_468.lir_slots = lir_slots;
    zT_481 = zF_E9CBFCA6_lirStreamInit();
    zT_468.lir_stream = zT_481;
    zT_468.enum_value_table = enum_value_table;
    zT_468.error_code_registry = error_code_registry;
    zT_468.call_arg_types = call_arg_types;
    zT_468.call_param_map = call_param_map;
    zT_468.comptime_values = comptime_values;
    zT_468.exported = exported;
    zT_482 = 0;
    zT_468.pointer_only_ids = (unsigned int*)zT_482;
    zT_483 = 0;
    zT_468.pointer_only_len = zT_483;
    zT_485 = &compiler_alloc;
    zT_484 = &zT_485->emission;
    zT_487 = zF_EB0B1609_globalDeclArrayList(zT_484);
    zT_468.global_decls = zT_487;
    ctx = zT_468;
    zT_488 = &ctx;
    zF_74055C03_runCompiler(zT_488);
    return;
    z_bb_83:
    zT_412 = rti2 + (unsigned int)(1);
    rti2 = zT_412;
    goto z_bb_80;
    z_bb_84:
    zT_404 = rsp_len < (unsigned int)(511);
    goto z_bb_86;
    z_bb_85:
    zT_404 = 0;
    goto z_bb_86;
    z_bb_86:
    if (zT_404) goto z_bb_81; else goto z_bb_82;
}

int main(int argc, char** argv) {
    zF_780653D2___module_init();
    zF_780653D2___module_init_1();
    zF_780653D2___module_init_2();
    zF_780653D2___module_init_3();
    zF_780653D2___module_init_4();
    zF_780653D2___module_init_5();
    zF_780653D2___module_init_6();
    zF_780653D2___module_init_7();
    zF_780653D2___module_init_8();
    zF_780653D2___module_init_9();
    zF_780653D2___module_init_10();
    zF_780653D2___module_init_11();
    zF_780653D2___module_init_12();
    zF_780653D2___module_init_13();
    zF_780653D2___module_init_14();
    zF_780653D2___module_init_15();
    zF_780653D2___module_init_16();
    zF_780653D2___module_init_17();
    zF_780653D2___module_init_18();
    zF_780653D2___module_init_19();
    zF_780653D2___module_init_20();
    zF_780653D2___module_init_21();
    zF_780653D2___module_init_22();
    zF_780653D2___module_init_23();
    zF_780653D2___module_init_24();
    zF_EA90E208_main(argc, (unsigned char**)argv);
    return 0;
}

/* runCompiler */
void zF_74055C03_runCompiler(zT_5AB29387_CompilerContext* ctx) {
    zT_5AB29387_CompilerContext* zT_1;
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5AB29387_CompilerContext* zT_24;
    zT_69057089_CompilerAlloc* zT_25;
    zT_5AB29387_CompilerContext* zT_27;
    char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    zT_69057089_CompilerAlloc* zT_33;
    char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_F85C5DED_DiagnosticCollector* zT_40;
    int zT_42 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_43;
    int zT_46;
    zT_69057089_CompilerAlloc* zT_48;
    zT_5AB29387_CompilerContext* zT_50;
    zT_5AB29387_CompilerContext* zT_51;
    zT_5AB29387_CompilerContext* zT_52;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    int zT_55 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    int zT_59;
    zT_5AB29387_CompilerContext* zT_61;
    zT_69057089_CompilerAlloc* zT_62;
    zT_F85C5DED_DiagnosticCollector* zT_64;
    int zT_66 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_67;
    int zT_70;
    zT_5AB29387_CompilerContext* zT_72;
    zT_69057089_CompilerAlloc* zT_73;
    zT_F85C5DED_DiagnosticCollector* zT_75;
    int zT_77 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_78;
    int zT_81;
    zT_8EED1867_ResolvedTypeTable* zT_83;
    zT_3E40CD83_Sand* zT_85;
    zT_69057089_CompilerAlloc* zT_86;
    zT_5AB29387_CompilerContext* zT_88;
    zT_69057089_CompilerAlloc* zT_89;
    zT_C98AF326_CompilerCli zT_91;
    int zT_92;
    int zT_93;
    zT_C98AF326_CompilerCli zT_94;
    int zT_96;
    zT_F85C5DED_DiagnosticCollector* zT_97;
    unsigned int zT_99 = 0;
    int zT_100;
    zT_F85C5DED_DiagnosticCollector* zT_102;
    int zT_105;
    zT_C98AF326_CompilerCli zT_107;
    int zT_108;
    zT_69057089_CompilerAlloc* zT_110;
    zT_3E40CD83_Sand zT_111;
    unsigned int zT_112;
    unsigned int zT_115;
    zT_69057089_CompilerAlloc* zT_117;
    zT_3E40CD83_Sand zT_118;
    unsigned int zT_119;
    unsigned int zT_122;
    zT_69057089_CompilerAlloc* zT_124;
    zT_3E40CD83_Sand zT_125;
    unsigned int zT_126;
    unsigned int zT_129;
    unsigned int zT_131 = 0;
    unsigned int zT_134;
    zT_338B7C76_TypeRegistry* zT_136;
    zT_3E40CD83_Sand* zT_137;
    unsigned int zT_138;
    unsigned int zT_141;
    unsigned int zT_144;
    char* zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    unsigned int zT_148;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned int zT_150;
    char* zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    unsigned int zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    char* zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    char* zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167;
    unsigned int zT_168;
    char* zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    char* zT_176;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_177;
    unsigned int zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    zT_F85C5DED_DiagnosticCollector* zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u z2;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3;
    zT_8F083A69_Slice_zT_0B42B2F8_u z3a;
    zT_8F083A69_Slice_zT_0B42B2F8_u z4;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2;
    unsigned int perm_kb;
    unsigned int mod_kb;
    unsigned int scr_kb;
    unsigned int pool_kb;
    unsigned int type_db_kb;
    unsigned int total;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3b;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg3c;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg4;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg5;
    zT_1 = ctx;
    zF_E2BA93CE_phase_ImportResolut(zT_1);
    zT_3 = "2\n";
    zT_5 = 2;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    z2 = zT_4;
    zT_6 = z2;
    zF_48AC7B3A_markerWrite(zT_6);
    zT_7 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_7);
    zT_10 = "3\n";
    zT_12 = 2;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    z3 = zT_11;
    zT_13 = z3;
    zF_48AC7B3A_markerWrite(zT_13);
    zT_15 = "3a\n";
    zT_17 = 3;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    z3a = zT_16;
    zT_18 = z3a;
    zF_48AC7B3A_markerWrite(zT_18);
    zT_20 = "4\n";
    zT_22 = 2;
    zT_21.ptr = zT_20;
    zT_21.len = zT_22;
    z4 = zT_21;
    zT_23 = z4;
    zF_48AC7B3A_markerWrite(zT_23);
    zT_24 = ctx;
    zF_945DEA54_phase_SymbolRegistr(zT_24);
    zT_25 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_25);
    zT_27 = ctx;
    zF_D3497187_phase_TypeResolutio(zT_27);
    zT_29 = "t1\n";
    zT_31 = 3;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    t1 = zT_30;
    zT_32 = t1;
    zF_48AC7B3A_markerWrite(zT_32);
    zT_33 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_33);
    zT_36 = "t2\n";
    zT_38 = 3;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    t2 = zT_37;
    zT_39 = t2;
    zF_48AC7B3A_markerWrite(zT_39);
    zT_40 = ctx->diag;
    zT_42 = zF_8F770780_diagnosticCollector(zT_40);
    if (zT_42) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_43 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_43);
    zT_46 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_46));
    goto z_bb_2;
    z_bb_2:
    zT_48 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_48);
    zT_50 = ctx;
    zF_F862154A_phase_FrontResoluti(zT_50);
    zT_51 = ctx;
    zF_9609BF31_phase_ComptimeEvalu(zT_51);
    zT_52 = ctx;
    zF_0666ED4F_phase_SemanticAnaly(zT_52);
    zT_53 = ctx->diag;
    zT_55 = zF_8F770780_diagnosticCollector(zT_53);
    if (zT_55) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_56 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_56);
    zT_59 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_59));
    goto z_bb_4;
    z_bb_4:
    zT_61 = ctx;
    zF_F3B55B42_phase_StaticAnalyze(zT_61);
    zT_62 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_62);
    zT_64 = ctx->diag;
    zT_66 = zF_8F770780_diagnosticCollector(zT_64);
    if (zT_66) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_67 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_67);
    zT_70 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_70));
    goto z_bb_6;
    z_bb_6:
    zT_72 = ctx;
    zF_1F21ABE7_phase_LIRLowering(zT_72);
    zT_73 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_73);
    zT_75 = ctx->diag;
    zT_77 = zF_8F770780_diagnosticCollector(zT_75);
    if (zT_77) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_78 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_78);
    zT_81 = 2;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_81));
    goto z_bb_8;
    z_bb_8:
    zT_83 = ctx->resolved_types;
    zF_5209815D_resolvedTypeTableCl(zT_83);
    zT_86 = ctx->alloc;
    zT_85 = &zT_86->module;
    zF_F1B3F8C2_sandReset(zT_85);
    zT_88 = ctx;
    zF_2268F8CE_phase_C89Emission(zT_88);
    zT_89 = ctx->alloc;
    zF_BA490D17_checkCombinedPeak(zT_89);
    zT_91 = ctx->cli;
    zT_92 = zT_91.warnings_as_errors;
    if (zT_92) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_94 = ctx->cli;
    zT_93 = zT_94.warn_error;
    goto z_bb_11;
    z_bb_10:
    zT_93 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_93) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_97 = ctx->diag;
    zT_99 = zF_4AF2092E_diagnosticCollector(zT_97);
    zT_100 = 0;
    zT_96 = zT_99 > (unsigned int)zT_100;
    goto z_bb_14;
    z_bb_13:
    zT_96 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_96) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_102 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_102);
    zT_105 = 1;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_105));
    goto z_bb_16;
    z_bb_16:
    zT_107 = ctx->cli;
    zT_108 = zT_107.track_memory;
    if (zT_108) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_110 = ctx->alloc;
    zT_111 = zT_110->permanent;
    zT_112 = zT_111.peak;
    zT_115 = (unsigned int)(unsigned int)(zT_112 / (unsigned int)(1024));
    perm_kb = zT_115;
    zT_117 = ctx->alloc;
    zT_118 = zT_117->module;
    zT_119 = zT_118.peak;
    zT_122 = (unsigned int)(unsigned int)(zT_119 / (unsigned int)(1024));
    mod_kb = zT_122;
    zT_124 = ctx->alloc;
    zT_125 = zT_124->scratch;
    zT_126 = zT_125.peak;
    zT_129 = (unsigned int)(unsigned int)(zT_126 / (unsigned int)(1024));
    scr_kb = zT_129;
    zT_131 = zF_E5D0D49C_poolPeak();
    zT_134 = (unsigned int)(unsigned int)(zT_131 / (unsigned int)(1024));
    pool_kb = zT_134;
    zT_136 = ctx->typereg;
    zT_137 = zT_136->types_alloc;
    zT_138 = zT_137->peak;
    zT_141 = (unsigned int)(unsigned int)(zT_138 / (unsigned int)(1024));
    type_db_kb = zT_141;
    zT_144 = (unsigned int)(perm_kb + mod_kb) + scr_kb;
    total = zT_144;
    zT_146 = "track-memory: perm=";
    zT_148 = 19;
    zT_147.ptr = zT_146;
    zT_147.len = zT_148;
    msg1 = zT_147;
    zT_149 = msg1;
    zF_B5478454_measureMarkerWrite(zT_149);
    zT_150 = perm_kb;
    zF_266B1B8E_writeU32(zT_150);
    zT_152 = "K mod=";
    zT_154 = 6;
    zT_153.ptr = zT_152;
    zT_153.len = zT_154;
    msg2 = zT_153;
    zT_155 = msg2;
    zF_B5478454_measureMarkerWrite(zT_155);
    zT_156 = mod_kb;
    zF_266B1B8E_writeU32(zT_156);
    zT_158 = "K scr=";
    zT_160 = 6;
    zT_159.ptr = zT_158;
    zT_159.len = zT_160;
    msg3 = zT_159;
    zT_161 = msg3;
    zF_B5478454_measureMarkerWrite(zT_161);
    zT_162 = scr_kb;
    zF_266B1B8E_writeU32(zT_162);
    zT_164 = "K pool=";
    zT_166 = 7;
    zT_165.ptr = zT_164;
    zT_165.len = zT_166;
    msg3b = zT_165;
    zT_167 = msg3b;
    zF_B5478454_measureMarkerWrite(zT_167);
    zT_168 = pool_kb;
    zF_266B1B8E_writeU32(zT_168);
    zT_170 = "K type_db=";
    zT_172 = 10;
    zT_171.ptr = zT_170;
    zT_171.len = zT_172;
    msg3c = zT_171;
    zT_173 = msg3c;
    zF_B5478454_measureMarkerWrite(zT_173);
    zT_174 = type_db_kb;
    zF_266B1B8E_writeU32(zT_174);
    zT_176 = "K total=";
    zT_178 = 8;
    zT_177.ptr = zT_176;
    zT_177.len = zT_178;
    msg4 = zT_177;
    zT_179 = msg4;
    zF_B5478454_measureMarkerWrite(zT_179);
    zT_180 = total;
    zF_266B1B8E_writeU32(zT_180);
    zT_182 = "K\n";
    zT_184 = 2;
    zT_183.ptr = zT_182;
    zT_183.len = zT_184;
    msg5 = zT_183;
    zT_185 = msg5;
    zF_B5478454_measureMarkerWrite(zT_185);
    goto z_bb_18;
    z_bb_18:
    zT_186 = ctx->diag;
    zF_8E894A93_diagnosticCollector(zT_186);
    return;
}

/* phase_ImportResolution */
void zF_E2BA93CE_phase_ImportResolut(zT_5AB29387_CompilerContext* ctx) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    int zT_10;
    unsigned int zT_11;
    zT_C98AF326_CompilerCli zT_12;
    unsigned int zT_13;
    zT_4DB1475B_ModuleResolver* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_072B53A6_ModuleRegistry* zT_17;
    zT_C98AF326_CompilerCli zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    int zT_23;
    unsigned int zT_24;
    zT_846744CC_Arr_unsigned_char_5 zT_26;
    unsigned char* zT_28;
    int zT_30;
    unsigned char* zT_31;
    int zT_33 = 0;
    int zT_34;
    unsigned int zT_39;
    int zT_40;
    unsigned char* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    int zT_45 = 0;
    zT_4DB1475B_ModuleResolver* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_072B53A6_ModuleRegistry* zT_48;
    zT_846744CC_Arr_unsigned_char_5 zT_51;
    zT_C98AF326_CompilerCli zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_C98AF326_CompilerCli zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_58;
    int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_C98AF326_CompilerCli zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_69;
    int zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    zT_C98AF326_CompilerCli zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    zT_EC3A30A7_Opt_208 zT_76 = {0};
    unsigned char zT_77;
    zT_D3EB6303_StringInterner* zT_80;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_81;
    unsigned int zT_83 = 0;
    zT_072B53A6_ModuleRegistry* zT_85;
    unsigned int zT_86;
    unsigned int zT_88 = 0;
    zT_47A5CDFB_ImportQueue* zT_89;
    unsigned int zT_90;
    zT_072B53A6_ModuleRegistry* zT_91;
    zT_072B53A6_ModuleRegistry* zT_93;
    zT_3E40CD83_Sand* zT_94;
    zT_3E40CD83_Sand* zT_95;
    zT_6B0A7D14_AstStore* zT_96;
    zT_69057089_CompilerAlloc* zT_98;
    zT_69057089_CompilerAlloc* zT_100;
    zT_846744CC_Arr_unsigned_char_5 zT_104;
    unsigned int zT_106;
    zT_C98AF326_CompilerCli zT_107;
    int zT_108;
    zT_C98AF326_CompilerCli zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_113;
    unsigned int zT_115;
    int zT_117;
    unsigned char* zT_120;
    unsigned char zT_121;
    unsigned int zT_123;
    unsigned int zT_125;
    unsigned char zT_126;
    unsigned int zT_128;
    unsigned char zT_129;
    unsigned int zT_131;
    unsigned char zT_132;
    unsigned int zT_134;
    char* zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    unsigned int zT_140;
    unsigned int zT_142;
    int zT_144;
    unsigned char* zT_147;
    unsigned char zT_148;
    unsigned int zT_150;
    unsigned int zT_152;
    zT_072B53A6_ModuleRegistry* zT_153;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_154;
    int zT_158;
    unsigned char* zT_159;
    unsigned int zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_166;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    unsigned int si;
    zT_846744CC_Arr_unsigned_char_5 lib_buf;
    int lib_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_path;
    zT_846744CC_Arr_unsigned_char_5 root_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u root_path;
    zT_EC3A30A7_Opt_208 norm;
    unsigned int path_id;
    unsigned int mod_id;
    zT_846744CC_Arr_unsigned_char_5 hash_spill_path;
    unsigned int hsp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hash_tmp_name;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u z_msg;
    zT_2 = "I\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    si = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_12 = ctx->cli;
    zT_13 = zT_12.include_count;
    if ((int)(si < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = ctx->module_reg;
    zT_15 = &zT_17->resolver;
    zT_19 = ctx->cli;
    zT_20 = zT_19.include_dirs;
    zT_21 = (unsigned int)si;
    zT_22 = zT_20[zT_21];
    zT_16 = zT_22;
    zF_B75A4515_moduleResolverAddSe(zT_15, zT_16);
    goto z_bb_4;
    z_bb_3:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_26[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        lib_buf[_i] = zT_26[_i];
        _i++;
    }
}
    zT_30 = 0;
    zT_31 = lib_buf + zT_30;
    zT_28 = zT_31;
    zT_33 = zF_BEB0BFA8_getDefaultLibPath(zT_28, (int)(512));
    lib_len = zT_33;
    zT_34 = 0;
    if ((int)(lib_len > zT_34)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_24 = si + zT_23;
    si = zT_24;
    goto z_bb_1;
    z_bb_5:
    zT_39 = __bootstrap_usize_from_i32(lib_len);
    zT_40 = 0;
    zT_41 = (unsigned char*)((unsigned char*)lib_buf) + zT_40;
    zT_42 = zT_39 - zT_40;
    zT_43.ptr = zT_41;
    zT_43.len = zT_42;
    lib_path = zT_43;
    zT_44 = lib_path;
    zT_45 = zF_852C5C93_fileExists(zT_44);
    if (zT_45) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_51[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        root_buf[_i] = zT_51[_i];
        _i++;
    }
}
    zT_53 = ctx->cli;
    zT_54 = zT_53.input_file;
    root_path = zT_54;
    zT_55 = ctx->cli;
    zT_56 = zT_55.input_file;
    zT_58 = zT_56.len;
    zT_59 = 512;
    if ((int)(zT_58 <= (unsigned int)zT_59)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_48 = ctx->module_reg;
    zT_46 = &zT_48->resolver;
    zT_47 = lib_path;
    zF_B75A4515_moduleResolverAddSe(zT_46, zT_47);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_66 = ctx->cli;
    zT_67 = zT_66.input_file;
    zT_69 = zT_67.len;
    zT_70 = 0;
    zT_71 = (unsigned char*)((unsigned char*)root_buf) + zT_70;
    zT_72 = zT_69 - zT_70;
    zT_73.ptr = zT_71;
    zT_73.len = zT_72;
    zT_62 = zT_73;
    zT_74 = ctx->cli;
    zT_75 = zT_74.input_file;
    zT_63 = zT_75;
    zT_76 = zF_36F0DB6B_normalizePath(zT_62, zT_63);
    norm = zT_76;
    zT_77 = norm.has_value;
    if (zT_77) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_80 = ctx->interner;
    zT_81 = root_path;
    zT_83 = zF_50C274AF_stringInternerInter(zT_80, zT_81);
    path_id = zT_83;
    zT_85 = ctx->module_reg;
    zT_86 = path_id;
    zT_88 = zF_E4DCE20D_moduleRegistryAddMo(zT_85, zT_86);
    mod_id = zT_88;
    zT_91 = ctx->module_reg;
    zT_89 = &zT_91->import_queue;
    zT_90 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_89, zT_90);
    zT_93 = ctx->module_reg;
    zT_98 = ctx->alloc;
    zT_94 = &zT_98->module;
    zT_100 = ctx->alloc;
    zT_95 = &zT_100->scratch;
    zT_96 = ctx->store;
    zF_A46C0B58_moduleRegistryResol(zT_93, zT_94, zT_95, zT_96);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_104[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hash_spill_path[_i] = zT_104[_i];
        _i++;
    }
}
    zT_106 = 0;
    hsp_len = zT_106;
    zT_107 = ctx->cli;
    zT_108 = zT_107.output_dir_set;
    if (zT_108) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    n = norm.value;
    root_path = n;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_110 = ctx->cli;
    zT_111 = zT_110.output_dir;
    od = zT_111;
    zT_113 = 0;
    oi = zT_113;
    goto z_bb_16;
    z_bb_14:
    zT_136 = ".zig1_hash.tmp";
    zT_138 = 14;
    zT_137.ptr = zT_136;
    zT_137.len = zT_138;
    hash_tmp_name = zT_137;
    zT_140 = 0;
    hi = zT_140;
    goto z_bb_23;
    z_bb_15:
    zT_129 = 46;
    hash_spill_path[hsp_len] = zT_129;
    zT_131 = hsp_len + (unsigned int)(1);
    hsp_len = zT_131;
    zT_132 = 47;
    hash_spill_path[hsp_len] = zT_132;
    zT_134 = hsp_len + (unsigned int)(1);
    hsp_len = zT_134;
    goto z_bb_14;
    z_bb_16:
    zT_115 = od.len;
    if ((int)(oi < zT_115)) goto z_bb_20; else goto z_bb_21;
    z_bb_17:
    zT_120 = od.ptr;
    zT_121 = zT_120[oi];
    hash_spill_path[hsp_len] = zT_121;
    zT_123 = hsp_len + (unsigned int)(1);
    hsp_len = zT_123;
    goto z_bb_19;
    z_bb_18:
    zT_126 = 47;
    hash_spill_path[hsp_len] = zT_126;
    zT_128 = hsp_len + (unsigned int)(1);
    hsp_len = zT_128;
    goto z_bb_14;
    z_bb_19:
    zT_125 = oi + (unsigned int)(1);
    oi = zT_125;
    goto z_bb_16;
    z_bb_20:
    zT_117 = hsp_len < (unsigned int)(511);
    goto z_bb_22;
    z_bb_21:
    zT_117 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_117) goto z_bb_17; else goto z_bb_18;
    z_bb_23:
    zT_142 = hash_tmp_name.len;
    if ((int)(hi < zT_142)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_147 = hash_tmp_name.ptr;
    zT_148 = zT_147[hi];
    hash_spill_path[hsp_len] = zT_148;
    zT_150 = hsp_len + (unsigned int)(1);
    hsp_len = zT_150;
    goto z_bb_26;
    z_bb_25:
    zT_153 = ctx->module_reg;
    zT_158 = 0;
    zT_159 = (unsigned char*)((unsigned char*)hash_spill_path) + zT_158;
    zT_160 = hsp_len - zT_158;
    zT_161.ptr = zT_159;
    zT_161.len = zT_160;
    zT_154 = zT_161;
    zF_8767909B_moduleRegistrySpill(zT_153, zT_154);
    zT_163 = "Z\n";
    zT_165 = 2;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    z_msg = zT_164;
    zT_166 = z_msg;
    zF_48AC7B3A_markerWrite(zT_166);
    return;
    z_bb_26:
    zT_152 = hi + (unsigned int)(1);
    hi = zT_152;
    goto z_bb_23;
    z_bb_27:
    zT_144 = hsp_len < (unsigned int)(511);
    goto z_bb_29;
    z_bb_28:
    zT_144 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_144) goto z_bb_24; else goto z_bb_25;
}

/* phase_SymbolRegistration */
void zF_945DEA54_phase_SymbolRegistr(zT_5AB29387_CompilerContext* ctx) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_10;
    zT_69057089_CompilerAlloc* zT_11;
    zT_4D61441E_DepGraph zT_13 = {0};
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_17 = {0};
    int zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    zT_072B53A6_ModuleRegistry* zT_24;
    zT_3D7259E2_SymbolRegistry* zT_25;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_4D61441E_DepGraph* zT_29;
    zT_6E8D187B_ModuleEntry* zT_35;
    zT_6E8D187B_ModuleEntry zT_36;
    int zT_40;
    unsigned int zT_41;
    zT_072B53A6_ModuleRegistry* zT_43;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_45 = {0};
    unsigned int zT_47;
    int zT_50;
    zT_6E8D187B_ModuleEntry* zT_51;
    int zT_52;
    zT_6E8D187B_ModuleEntry zT_53;
    unsigned int zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_6E8D187B_ModuleEntry* zT_61;
    int zT_62;
    zT_6E8D187B_ModuleEntry zT_63;
    zT_22A7C88B_AstNode zT_65 = {0};
    zT_8143F551_AstKind zT_66;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_6E8D187B_ModuleEntry* zT_75;
    int zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_79 = {0};
    unsigned int zT_81;
    char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_88;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int* zT_94;
    zT_22A7C88B_AstNode zT_96 = {0};
    zT_8143F551_AstKind zT_98;
    unsigned int zT_99;
    zT_4028D896_Arr_unsigned_char_2 zT_101;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    int zT_107;
    unsigned char* zT_108;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_110;
    unsigned int zT_111 = 0;
    unsigned int zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned char* zT_120;
    unsigned int zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    char* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_129;
    char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_134;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_DDCD424B_Slice_zT_6E8D187B_M smods;
    zT_22A7C88B_AstNode sr;
    zT_3CB0179A_Slice_zT_05F374B1_u sdl;
    unsigned int sdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u sl;
    zT_22A7C88B_AstNode sd;
    unsigned int sk;
    zT_4028D896_Arr_unsigned_char_2 sb;
    unsigned int slen;
    unsigned int sst;
    zT_8F083A69_Slice_zT_0B42B2F8_u ssp;
    zT_8F083A69_Slice_zT_0B42B2F8_u sn;
    zT_2 = "S\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->alloc;
    zT_10 = &zT_11->scratch;
    zT_13 = zF_7F194604_depGraphInit(zT_10);
    dep_graph = zT_13;
    zT_15 = ctx->module_reg;
    zT_17 = zF_3452C137_moduleRegistryGetMo(zT_15);
    mods = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    mi = zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_22 = mods.len;
    if ((int)(mi < zT_22)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_24 = ctx->module_reg;
    zT_25 = ctx->symbol_reg;
    zT_26 = ctx->typereg;
    zT_27 = ctx->store;
    zT_35 = mods.ptr;
    zT_36 = zT_35[mi];
    zT_28 = zT_36.id;
    zT_29 = &dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_24, zT_25, zT_26, zT_27, zT_28, zT_29, (int)(1));
    goto z_bb_4;
    z_bb_3:
    zT_43 = ctx->module_reg;
    zT_45 = zF_3452C137_moduleRegistryGetMo(zT_43);
    smods = zT_45;
    zT_47 = smods.len;
    if ((int)(zT_47 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_40 = 1;
    zT_41 = mi + zT_40;
    mi = zT_41;
    goto z_bb_1;
    z_bb_5:
    zT_51 = smods.ptr;
    zT_52 = 0;
    zT_53 = zT_51[zT_52];
    zT_54 = zT_53.ast_root;
    zT_50 = zT_54 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_50 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_50) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_58 = ctx->store;
    zT_61 = smods.ptr;
    zT_62 = 0;
    zT_63 = zT_61[zT_62];
    zT_59 = zT_63.ast_root;
    zT_65 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    sr = zT_65;
    zT_66 = sr.kind;
    if ((int)(zT_66 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_72 = ctx->store;
    zT_75 = smods.ptr;
    zT_76 = 0;
    zT_77 = zT_75[zT_76];
    zT_73 = zT_77.ast_root;
    zT_79 = zF_850FDF81_astStoreNodeExtraCh(zT_72, zT_73);
    sdl = zT_79;
    zT_81 = 0;
    sdi = zT_81;
    zT_83 = "S0";
    zT_85 = 2;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    sl = zT_84;
    zT_86 = sl;
    zF_48AC7B3A_markerWrite(zT_86);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    zT_88 = sdl.len;
    if ((int)(sdi < zT_88)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_91 = ctx->store;
    zT_94 = sdl.ptr;
    zT_92 = zT_94[sdi];
    zT_96 = zF_FCDD1D35_astStoreNodeAt(zT_91, zT_92);
    sd = zT_96;
    zT_98 = sd.kind;
    zT_99 = (unsigned int)zT_98;
    sk = zT_99;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_101[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        sb[_i] = zT_101[_i];
        _i++;
    }
}
    zT_103 = sk;
    zT_107 = 0;
    zT_108 = (unsigned char*)((unsigned char*)sb) + zT_107;
    zT_109 = (unsigned int)(20) - zT_107;
    zT_110.ptr = zT_108;
    zT_110.len = zT_109;
    zT_104 = zT_110;
    zT_111 = zF_A7504564_itoa(zT_103, zT_104);
    slen = zT_111;
    zT_115 = (unsigned int)(19) - (unsigned int)((unsigned int)slen);
    sst = zT_115;
    zT_120 = (unsigned char*)((unsigned char*)sb) + sst;
    zT_121 = (unsigned int)(19) - sst;
    zT_122.ptr = zT_120;
    zT_122.len = zT_121;
    zT_116 = zT_122;
    zF_48AC7B3A_markerWrite(zT_116);
    zT_124 = " ";
    zT_126 = 1;
    zT_125.ptr = zT_124;
    zT_125.len = zT_126;
    ssp = zT_125;
    zT_127 = ssp;
    zF_48AC7B3A_markerWrite(zT_127);
    goto z_bb_15;
    z_bb_14:
    zT_131 = "\n";
    zT_133 = 1;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    sn = zT_132;
    zT_134 = sn;
    zF_48AC7B3A_markerWrite(zT_134);
    goto z_bb_11;
    z_bb_15:
    zT_129 = sdi + (unsigned int)(1);
    sdi = zT_129;
    goto z_bb_12;
}

/* phase_TypeResolution */
void zF_D3497187_phase_TypeResolutio(zT_5AB29387_CompilerContext* ctx) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    unsigned int zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_06ACABEC_anon_190680 zT_10;
    zT_3E40CD83_Sand* zT_12;
    zT_69057089_CompilerAlloc* zT_13;
    zT_3E40CD83_Sand* zT_16;
    zT_69057089_CompilerAlloc* zT_17;
    zT_4D61441E_DepGraph zT_19 = {0};
    zT_072B53A6_ModuleRegistry* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_23 = {0};
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    zT_072B53A6_ModuleRegistry* zT_30;
    zT_3D7259E2_SymbolRegistry* zT_31;
    zT_338B7C76_TypeRegistry* zT_32;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_4D61441E_DepGraph* zT_35;
    zT_6E8D187B_ModuleEntry* zT_41;
    zT_6E8D187B_ModuleEntry zT_42;
    int zT_46;
    unsigned int zT_47;
    zT_3D7259E2_SymbolRegistry* zT_48;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_D3EB6303_StringInterner* zT_50;
    zT_6B0A7D14_AstStore* zT_51;
    zT_3E40CD83_Sand* zT_52;
    zT_69057089_CompilerAlloc* zT_57;
    zT_6B0A7D14_AstStore* zT_59;
    zT_338B7C76_TypeRegistry* zT_60;
    zT_3D7259E2_SymbolRegistry* zT_61;
    zT_D3EB6303_StringInterner* zT_62;
    zT_8EED1867_ResolvedTypeTable* zT_63;
    zT_072B53A6_ModuleRegistry* zT_64;
    zT_3E40CD83_Sand* zT_65;
    zT_69057089_CompilerAlloc* zT_72;
    zT_338B7C76_TypeRegistry* zT_75;
    zT_F85C5DED_DiagnosticCollector* zT_76;
    zT_3E40CD83_Sand* zT_77;
    zT_69057089_CompilerAlloc* zT_80;
    zT_C890C8CB_TypeResolver zT_82 = {0};
    zT_C890C8CB_TypeResolver* zT_83;
    zT_C890C8CB_TypeResolver* zT_85;
    zT_4D61441E_DepGraph* zT_86;
    zT_C890C8CB_TypeResolver* zT_89;
    zT_C890C8CB_TypeResolver* zT_92;
    zT_3E40CD83_Sand* zT_93;
    zT_69057089_CompilerAlloc* zT_95;
    zT_010C8DF0_ClassificationResul zT_97 = {0};
    unsigned int* zT_98;
    unsigned int zT_99;
    unsigned int zT_101;
    int zT_104;
    zT_6E8D187B_ModuleEntry* zT_105;
    int zT_106;
    zT_6E8D187B_ModuleEntry zT_107;
    unsigned int zT_108;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    zT_6E8D187B_ModuleEntry* zT_115;
    int zT_116;
    zT_6E8D187B_ModuleEntry zT_117;
    zT_22A7C88B_AstNode zT_119 = {0};
    zT_8143F551_AstKind zT_120;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    zT_6E8D187B_ModuleEntry* zT_129;
    int zT_130;
    zT_6E8D187B_ModuleEntry zT_131;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_133 = {0};
    unsigned int zT_135;
    char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_145;
    unsigned int zT_146;
    unsigned int* zT_148;
    zT_22A7C88B_AstNode zT_150 = {0};
    zT_8143F551_AstKind zT_152;
    unsigned int zT_153;
    zT_4028D896_Arr_unsigned_char_2 zT_155;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    int zT_161;
    unsigned char* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165 = 0;
    unsigned int zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned char* zT_174;
    unsigned int zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    char* zT_178;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_179;
    unsigned int zT_180;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_181;
    unsigned int zT_183;
    char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_4D61441E_DepGraph dep_graph;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_C890C8CB_TypeResolver tr;
    zT_010C8DF0_ClassificationResul ptr_grp;
    zT_22A7C88B_AstNode tr2;
    zT_3CB0179A_Slice_zT_05F374B1_u tdl;
    unsigned int tdi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tl;
    zT_22A7C88B_AstNode td;
    unsigned int tk;
    zT_4028D896_Arr_unsigned_char_2 tb;
    unsigned int tlen;
    unsigned int tst;
    zT_8F083A69_Slice_zT_0B42B2F8_u tsp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tn;
    zT_2 = "T\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->resolved_types;
    zT_9 = ctx->store;
    zT_10 = zT_9->nodes;
    zT_7 = zT_10.len;
    zF_75224871_resolvedTypeTableRe(zT_6, zT_7);
    zT_13 = ctx->alloc;
    zT_12 = &zT_13->scratch;
    zF_F1B3F8C2_sandReset(zT_12);
    zT_17 = ctx->alloc;
    zT_16 = &zT_17->scratch;
    zT_19 = zF_7F194604_depGraphInit(zT_16);
    dep_graph = zT_19;
    zT_21 = ctx->module_reg;
    zT_23 = zF_3452C137_moduleRegistryGetMo(zT_21);
    mods = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    mi = zT_26;
    goto z_bb_1;
    z_bb_1:
    zT_28 = mods.len;
    if ((int)(mi < zT_28)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_30 = ctx->module_reg;
    zT_31 = ctx->symbol_reg;
    zT_32 = ctx->typereg;
    zT_33 = ctx->store;
    zT_41 = mods.ptr;
    zT_42 = zT_41[mi];
    zT_34 = zT_42.id;
    zT_35 = &dep_graph;
    zF_16302C7D_registerModuleSymbo(zT_30, zT_31, zT_32, zT_33, zT_34, zT_35, (int)(0));
    goto z_bb_4;
    z_bb_3:
    zT_48 = ctx->symbol_reg;
    zT_49 = ctx->typereg;
    zT_50 = ctx->interner;
    zT_51 = ctx->store;
    zT_57 = ctx->alloc;
    zT_52 = &zT_57->permanent;
    zF_EF7F7D3C_constAliasPrepass(zT_48, zT_49, zT_50, zT_51, zT_52);
    zT_59 = ctx->store;
    zT_60 = ctx->typereg;
    zT_61 = ctx->symbol_reg;
    zT_62 = ctx->interner;
    zT_63 = ctx->resolved_types;
    zT_64 = ctx->module_reg;
    zT_72 = ctx->alloc;
    zT_65 = &zT_72->permanent;
    zF_373A7BEF_typeResolverResolve(zT_59, zT_60, zT_61, zT_62, zT_63, zT_64, zT_65);
    zT_75 = ctx->typereg;
    zT_76 = ctx->diag;
    zT_80 = ctx->alloc;
    zT_77 = &zT_80->scratch;
    zT_82 = zF_5BFAC855_typeResolverInit(zT_75, zT_76, zT_77);
    tr = zT_82;
    zT_83 = &tr;
    zF_D5C4530C_typeResolverBuildDe(zT_83);
    zT_85 = &tr;
    zT_86 = &dep_graph;
    zF_33272F41_typeResolverBuild(zT_85, zT_86);
    zT_89 = &tr;
    zF_30BE7185_typeResolverResolve(zT_89);
    zT_92 = &tr;
    zT_95 = ctx->alloc;
    zT_93 = &zT_95->permanent;
    zT_97 = zF_ACC002C8_classifyTypeEmissio(zT_92, zT_93);
    ptr_grp = zT_97;
    zT_98 = ptr_grp.ids;
    ctx->pointer_only_ids = zT_98;
    zT_99 = ptr_grp.len;
    ctx->pointer_only_len = zT_99;
    zT_101 = mods.len;
    if ((int)(zT_101 > (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_46 = 1;
    zT_47 = mi + zT_46;
    mi = zT_47;
    goto z_bb_1;
    z_bb_5:
    zT_105 = mods.ptr;
    zT_106 = 0;
    zT_107 = zT_105[zT_106];
    zT_108 = zT_107.ast_root;
    zT_104 = zT_108 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_104 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_104) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_112 = ctx->store;
    zT_115 = mods.ptr;
    zT_116 = 0;
    zT_117 = zT_115[zT_116];
    zT_113 = zT_117.ast_root;
    zT_119 = zF_FCDD1D35_astStoreNodeAt(zT_112, zT_113);
    tr2 = zT_119;
    zT_120 = tr2.kind;
    if ((int)(zT_120 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_126 = ctx->store;
    zT_129 = mods.ptr;
    zT_130 = 0;
    zT_131 = zT_129[zT_130];
    zT_127 = zT_131.ast_root;
    zT_133 = zF_850FDF81_astStoreNodeExtraCh(zT_126, zT_127);
    tdl = zT_133;
    zT_135 = 0;
    tdi = zT_135;
    zT_137 = "T0";
    zT_139 = 2;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    tl = zT_138;
    zT_140 = tl;
    zF_48AC7B3A_markerWrite(zT_140);
    goto z_bb_12;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    zT_142 = tdl.len;
    if ((int)(tdi < zT_142)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_145 = ctx->store;
    zT_148 = tdl.ptr;
    zT_146 = zT_148[tdi];
    zT_150 = zF_FCDD1D35_astStoreNodeAt(zT_145, zT_146);
    td = zT_150;
    zT_152 = td.kind;
    zT_153 = (unsigned int)zT_152;
    tk = zT_153;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_155[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        tb[_i] = zT_155[_i];
        _i++;
    }
}
    zT_157 = tk;
    zT_161 = 0;
    zT_162 = (unsigned char*)((unsigned char*)tb) + zT_161;
    zT_163 = (unsigned int)(20) - zT_161;
    zT_164.ptr = zT_162;
    zT_164.len = zT_163;
    zT_158 = zT_164;
    zT_165 = zF_A7504564_itoa(zT_157, zT_158);
    tlen = zT_165;
    zT_169 = (unsigned int)(19) - (unsigned int)((unsigned int)tlen);
    tst = zT_169;
    zT_174 = (unsigned char*)((unsigned char*)tb) + tst;
    zT_175 = (unsigned int)(19) - tst;
    zT_176.ptr = zT_174;
    zT_176.len = zT_175;
    zT_170 = zT_176;
    zF_48AC7B3A_markerWrite(zT_170);
    zT_178 = " ";
    zT_180 = 1;
    zT_179.ptr = zT_178;
    zT_179.len = zT_180;
    tsp = zT_179;
    zT_181 = tsp;
    zF_48AC7B3A_markerWrite(zT_181);
    goto z_bb_15;
    z_bb_14:
    zT_185 = "\n";
    zT_187 = 1;
    zT_186.ptr = zT_185;
    zT_186.len = zT_187;
    tn = zT_186;
    zT_188 = tn;
    zF_48AC7B3A_markerWrite(zT_188);
    goto z_bb_11;
    z_bb_15:
    zT_183 = tdi + (unsigned int)(1);
    tdi = zT_183;
    goto z_bb_12;
}

/* phase_FrontResolution */
void zF_F862154A_phase_FrontResoluti(zT_5AB29387_CompilerContext* ctx) {
    zT_6DCFC8DB_FrontResCtx zT_2;
    zT_6B0A7D14_AstStore* zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_6;
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_D3EB6303_StringInterner* zT_8;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_3E40CD83_Sand* zT_11;
    zT_66E7D2EF_CoercionTable* zT_12;
    zT_21D3708C_U32ToU32Map* zT_13;
    zT_21D3708C_U32ToU32Map* zT_14;
    zT_21D3708C_U32ToU32Map* zT_15;
    zT_21D3708C_U32ToU32Map* zT_16;
    zT_6DCFC8DB_FrontResCtx* zT_17;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_3 = ctx->store;
    zT_2.store = zT_3;
    zT_4 = ctx->typereg;
    zT_2.typereg = zT_4;
    zT_5 = ctx->symbol_reg;
    zT_2.symbol_reg = zT_5;
    zT_6 = ctx->resolved_types;
    zT_2.resolved_types = zT_6;
    zT_7 = ctx->module_reg;
    zT_2.module_reg = zT_7;
    zT_8 = ctx->interner;
    zT_2.interner = zT_8;
    zT_9 = ctx->diag;
    zT_2.diag = zT_9;
    zT_10 = ctx->alloc;
    zT_11 = &zT_10->scratch;
    zT_2.scratch = zT_11;
    zT_12 = ctx->coercion_table;
    zT_2.coercion_table = zT_12;
    zT_13 = &ctx->enum_value_table;
    zT_2.enum_value_table = zT_13;
    zT_14 = &ctx->error_code_registry;
    zT_2.error_code_registry = zT_14;
    zT_15 = &ctx->call_arg_types;
    zT_2.call_arg_types = zT_15;
    zT_16 = &ctx->call_param_map;
    zT_2.call_param_map = zT_16;
    frc = zT_2;
    zT_17 = &frc;
    zF_8A0E7747_frontResolveModuleI(zT_17);
    return;
}

/* phase_ComptimeEvaluation */
void zF_9609BF31_phase_ComptimeEvalu(zT_5AB29387_CompilerContext* ctx) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_338B7C76_TypeRegistry* zT_7;
    zT_6B0A7D14_AstStore* zT_8;
    zT_D3EB6303_StringInterner* zT_9;
    zT_3D7259E2_SymbolRegistry* zT_10;
    zT_DA663F79_ComptimeEval zT_15 = {0};
    zT_C98AF326_CompilerCli zT_16;
    int zT_17;
    int zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    zT_06ACABEC_anon_190680 zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_31;
    zT_DA663F79_ComptimeEval* zT_37;
    zT_57C02FC8_Opt_191 zT_41 = {0};
    unsigned char zT_42;
    zT_89877D19_U32ToU64Map* zT_44;
    zT_79FAE712_u64 zT_46;
    zT_8143F551_AstKind zT_50;
    int zT_55;
    unsigned int zT_56;
    int zT_57;
    unsigned char zT_59;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_71;
    unsigned int zT_72;
    int zT_75;
    int zT_78;
    int zT_81;
    zT_DA663F79_ComptimeEval* zT_85;
    unsigned int zT_86;
    zT_57C02FC8_Opt_191 zT_89 = {0};
    unsigned char zT_90;
    zT_89877D19_U32ToU64Map* zT_92;
    unsigned int zT_93;
    zT_79FAE712_u64 zT_94;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u pc_m;
    zT_DA663F79_ComptimeEval ce;
    unsigned int ni;
    zT_22A7C88B_AstNode node;
    zT_57C02FC8_Opt_191 val;
    zT_89B1DDDA_ComptimeVal v;
    zT_22A7C88B_AstNode init_n;
    unsigned int ik;
    zT_57C02FC8_Opt_191 val2;
    zT_89B1DDDA_ComptimeVal v2;
    zT_2 = "CE\n";
    zT_4 = 3;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    pc_m = zT_3;
    zT_5 = pc_m;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->typereg;
    zT_8 = ctx->store;
    zT_9 = ctx->interner;
    zT_10 = ctx->symbol_reg;
    zT_15 = zF_6D84C2E7_comptimeEvalInit(zT_7, zT_8, zT_9, zT_10);
    ce = zT_15;
    zT_16 = ctx->cli;
    zT_17 = zT_16.target_is_windows;
    ce.host_is_windows = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    ni = zT_20;
    goto z_bb_1;
    z_bb_1:
    zT_21 = ctx->store;
    zT_22 = zT_21->nodes;
    zT_23 = zT_22.len;
    if ((int)(ni < zT_23)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_26 = ctx->store;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_26, (unsigned int)((unsigned int)ni));
    node = zT_30;
    zT_31 = node.kind;
    if ((int)(zT_31 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_99 = ni + (unsigned int)(1);
    ni = zT_99;
    goto z_bb_1;
    z_bb_5:
    zT_37 = &ce;
    zT_41 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_37, (unsigned int)((unsigned int)ni));
    val = zT_41;
    zT_42 = val.has_value;
    if (zT_42) goto z_bb_8; else goto z_bb_9;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_50 = node.kind;
    if ((int)(zT_50 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    v = val.value;
    zT_44 = &ctx->comptime_values;
    zT_46 = v.bits;
    zF_75699BAA_u32ToU64MapPut(zT_44, (unsigned int)((unsigned int)ni), zT_46);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_56 = node.child_1;
    zT_57 = 0;
    zT_55 = zT_56 != (unsigned int)zT_57;
    goto z_bb_12;
    z_bb_11:
    zT_55 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_55) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_59 = node.flags;
    if ((int)((unsigned char)(zT_59 & (unsigned char)(1)) == (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_6;
    z_bb_15:
    zT_65 = ctx->store;
    zT_66 = node.child_1;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    init_n = zT_69;
    zT_71 = init_n.kind;
    zT_72 = (unsigned int)zT_71;
    ik = zT_72;
    if ((int)(ik >= (unsigned int)(33))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_75 = ik <= (unsigned int)(42);
    goto z_bb_19;
    z_bb_18:
    zT_75 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_75) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_78 = ik == (unsigned int)(62);
    goto z_bb_22;
    z_bb_21:
    zT_78 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_78) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_81 = ik == (unsigned int)(64);
    goto z_bb_25;
    z_bb_24:
    zT_81 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_81) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_85 = &ce;
    zT_86 = node.child_1;
    zT_89 = zF_EBC0E9BE_comptimeEvalEvaluat(zT_85, zT_86);
    val2 = zT_89;
    zT_90 = val2.has_value;
    if (zT_90) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    goto z_bb_16;
    z_bb_28:
    v2 = val2.value;
    zT_92 = &ctx->comptime_values;
    zT_93 = node.child_1;
    zT_94 = v2.bits;
    zF_75699BAA_u32ToU64MapPut(zT_92, zT_93, zT_94);
    goto z_bb_29;
    z_bb_29:
    goto z_bb_27;
}

/* phase_SemanticAnalysis */
void zF_0666ED4F_phase_SemanticAnaly(zT_5AB29387_CompilerContext* ctx) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_6DCFC8DB_FrontResCtx zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    zT_3D7259E2_SymbolRegistry* zT_13;
    zT_8EED1867_ResolvedTypeTable* zT_14;
    zT_072B53A6_ModuleRegistry* zT_15;
    zT_D3EB6303_StringInterner* zT_16;
    zT_F85C5DED_DiagnosticCollector* zT_17;
    zT_69057089_CompilerAlloc* zT_18;
    zT_3E40CD83_Sand* zT_19;
    zT_66E7D2EF_CoercionTable* zT_20;
    zT_21D3708C_U32ToU32Map* zT_21;
    zT_21D3708C_U32ToU32Map* zT_22;
    zT_21D3708C_U32ToU32Map* zT_23;
    zT_21D3708C_U32ToU32Map* zT_24;
    zT_072B53A6_ModuleRegistry* zT_26;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_28 = {0};
    int zT_30;
    unsigned int zT_31;
    unsigned int zT_33;
    zT_3E40CD83_Sand* zT_35;
    zT_69057089_CompilerAlloc* zT_36;
    zT_6E8D187B_ModuleEntry* zT_39;
    zT_6E8D187B_ModuleEntry zT_40;
    unsigned int zT_41;
    char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_55;
    unsigned int zT_56;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_58 = {0};
    char* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    zT_6E8D187B_ModuleEntry* zT_70;
    zT_6E8D187B_ModuleEntry zT_71;
    unsigned int zT_72;
    zT_3E40CD83_Sand* zT_74;
    zT_8EED1867_ResolvedTypeTable* zT_75;
    zT_F85C5DED_DiagnosticCollector* zT_76;
    zT_338B7C76_TypeRegistry* zT_77;
    zT_3D7259E2_SymbolRegistry* zT_78;
    zT_6B0A7D14_AstStore* zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    zT_66E7D2EF_CoercionTable* zT_82;
    zT_21D3708C_U32ToU32Map* zT_83;
    zT_21D3708C_U32ToU32Map* zT_84;
    zT_D3EB6303_StringInterner* zT_85;
    zT_21D3708C_U32ToU32Map* zT_86;
    zT_21D3708C_U32ToU32Map* zT_87;
    zT_072B53A6_ModuleRegistry* zT_88;
    zT_69057089_CompilerAlloc* zT_89;
    zT_6E8D187B_ModuleEntry* zT_96;
    zT_6E8D187B_ModuleEntry zT_97;
    zT_38C12417_SemanticAnalyzer zT_106 = {0};
    int zT_108;
    unsigned int zT_109;
    unsigned int zT_111;
    zT_6B0A7D14_AstStore* zT_114;
    unsigned int zT_115;
    unsigned int* zT_117;
    zT_22A7C88B_AstNode zT_119 = {0};
    char* zT_121;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_122;
    unsigned int zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_124;
    zT_8143F551_AstKind zT_125;
    unsigned int zT_130;
    int zT_131;
    zT_6DCFC8DB_FrontResCtx* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    zT_6E8D187B_ModuleEntry* zT_138;
    zT_6E8D187B_ModuleEntry zT_139;
    char* zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int zT_146;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_147;
    zT_38C12417_SemanticAnalyzer* zT_148;
    unsigned int zT_149;
    unsigned int* zT_151;
    char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    zT_8143F551_AstKind zT_158;
    int zT_163;
    unsigned int zT_164;
    zT_6B0A7D14_AstStore* zT_168;
    unsigned int zT_169;
    zT_22A7C88B_AstNode zT_172 = {0};
    zT_8143F551_AstKind zT_173;
    zT_38C12417_SemanticAnalyzer* zT_178;
    unsigned int zT_179;
    unsigned int* zT_181;
    zT_8143F551_AstKind zT_183;
    int zT_188;
    unsigned char zT_189;
    zT_38C12417_SemanticAnalyzer* zT_194;
    unsigned int zT_195;
    unsigned int* zT_197;
    zT_8143F551_AstKind zT_199;
    zT_38C12417_SemanticAnalyzer* zT_204;
    unsigned int zT_205;
    unsigned int* zT_207;
    zT_8143F551_AstKind zT_209;
    zT_38C12417_SemanticAnalyzer* zT_214;
    unsigned int zT_215;
    unsigned int* zT_217;
    int zT_219;
    unsigned int zT_220;
    int zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u rs;
    zT_6DCFC8DB_FrontResCtx frc;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mz;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    zT_8F083A69_Slice_zT_0B42B2F8_u ad;
    zT_8F083A69_Slice_zT_0B42B2F8_u dse_m;
    unsigned int src_fid;
    zT_38C12417_SemanticAnalyzer sa;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u dn;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa0;
    zT_8F083A69_Slice_zT_0B42B2F8_u sa1;
    zT_22A7C88B_AstNode di_inn;
    zT_2 = "RS";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    rs = zT_3;
    zT_5 = rs;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_11 = ctx->store;
    zT_10.store = zT_11;
    zT_12 = ctx->typereg;
    zT_10.typereg = zT_12;
    zT_13 = ctx->symbol_reg;
    zT_10.symbol_reg = zT_13;
    zT_14 = ctx->resolved_types;
    zT_10.resolved_types = zT_14;
    zT_15 = ctx->module_reg;
    zT_10.module_reg = zT_15;
    zT_16 = ctx->interner;
    zT_10.interner = zT_16;
    zT_17 = ctx->diag;
    zT_10.diag = zT_17;
    zT_18 = ctx->alloc;
    zT_19 = &zT_18->scratch;
    zT_10.scratch = zT_19;
    zT_20 = ctx->coercion_table;
    zT_10.coercion_table = zT_20;
    zT_21 = &ctx->enum_value_table;
    zT_10.enum_value_table = zT_21;
    zT_22 = &ctx->error_code_registry;
    zT_10.error_code_registry = zT_22;
    zT_23 = &ctx->call_arg_types;
    zT_10.call_arg_types = zT_23;
    zT_24 = &ctx->call_param_map;
    zT_10.call_param_map = zT_24;
    frc = zT_10;
    zT_26 = ctx->module_reg;
    zT_28 = zF_3452C137_moduleRegistryGetMo(zT_26);
    mods = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    mi = zT_31;
    goto z_bb_1;
    z_bb_1:
    zT_33 = mods.len;
    if ((int)(mi < zT_33)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_36 = ctx->alloc;
    zT_35 = &zT_36->scratch;
    zF_F1B3F8C2_sandReset(zT_35);
    zT_39 = mods.ptr;
    zT_40 = zT_39[mi];
    zT_41 = zT_40.ast_root;
    ast_root = zT_41;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_221 = 1;
    zT_222 = mi + zT_221;
    mi = zT_222;
    goto z_bb_1;
    z_bb_5:
    zT_45 = "MZ";
    zT_47 = 2;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    mz = zT_46;
    zT_48 = mz;
    zF_48AC7B3A_markerWrite(zT_48);
    goto z_bb_4;
    z_bb_6:
    zT_50 = ctx->store;
    zT_51 = ast_root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    zT_55 = ctx->store;
    zT_56 = ast_root;
    zT_58 = zF_850FDF81_astStoreNodeExtraCh(zT_55, zT_56);
    decls = zT_58;
    zT_60 = "AD";
    zT_62 = 2;
    zT_61.ptr = zT_60;
    zT_61.len = zT_62;
    ad = zT_61;
    zT_63 = ad;
    zF_48AC7B3A_markerWrite(zT_63);
    zT_65 = "DSE\n";
    zT_67 = 4;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    dse_m = zT_66;
    zT_68 = dse_m;
    zF_48AC7B3A_markerWrite(zT_68);
    zT_70 = mods.ptr;
    zT_71 = zT_70[mi];
    zT_72 = zT_71.source_file_id;
    src_fid = zT_72;
    zT_89 = ctx->alloc;
    zT_74 = &zT_89->scratch;
    zT_75 = ctx->resolved_types;
    zT_76 = ctx->diag;
    zT_77 = ctx->typereg;
    zT_78 = ctx->symbol_reg;
    zT_79 = ctx->store;
    zT_96 = mods.ptr;
    zT_97 = zT_96[mi];
    zT_80 = zT_97.id;
    zT_81 = src_fid;
    zT_82 = ctx->coercion_table;
    zT_83 = &ctx->enum_value_table;
    zT_84 = &ctx->error_code_registry;
    zT_85 = ctx->interner;
    zT_86 = &ctx->call_arg_types;
    zT_87 = &ctx->call_param_map;
    zT_88 = ctx->module_reg;
    zT_106 = zF_84ADA681_semanticAnalyzerIni(zT_74, zT_75, zT_76, zT_77, zT_78, zT_79, zT_80, zT_81, zT_82, zT_83, zT_84, zT_85, zT_86, zT_87, zT_88);
    sa = zT_106;
    zT_108 = 0;
    zT_109 = (unsigned int)zT_108;
    di = zT_109;
    goto z_bb_7;
    z_bb_7:
    zT_111 = decls.len;
    if ((int)(di < zT_111)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_114 = ctx->store;
    zT_117 = decls.ptr;
    zT_115 = zT_117[di];
    zT_119 = zF_FCDD1D35_astStoreNodeAt(zT_114, zT_115);
    decl = zT_119;
    zT_121 = "DN";
    zT_123 = 2;
    zT_122.ptr = zT_121;
    zT_122.len = zT_123;
    dn = zT_122;
    zT_124 = dn;
    zF_48AC7B3A_markerWrite(zT_124);
    zT_125 = decl.kind;
    if ((int)(zT_125 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_219 = 1;
    zT_220 = di + zT_219;
    di = zT_220;
    goto z_bb_7;
    z_bb_11:
    zT_130 = decl.child_0;
    zT_131 = 0;
    if ((int)(zT_130 != (unsigned int)zT_131)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_158 = decl.kind;
    if ((int)(zT_158 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_133 = &frc;
    zT_138 = mods.ptr;
    zT_139 = zT_138[mi];
    zT_134 = zT_139.id;
    zT_135 = decl.child_0;
    zF_783226DA_resolveStmtTypes(zT_133, zT_134, zT_135, (unsigned int)(0));
    goto z_bb_15;
    z_bb_15:
    zT_144 = "SA";
    zT_146 = 2;
    zT_145.ptr = zT_144;
    zT_145.len = zT_146;
    sa0 = zT_145;
    zT_147 = sa0;
    zF_48AC7B3A_markerWrite(zT_147);
    zT_148 = &sa;
    zT_151 = decls.ptr;
    zT_149 = zT_151[di];
    zF_406A2501_semanticAnalyzerRes(zT_148, zT_149);
    zT_154 = "sA";
    zT_156 = 2;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    sa1 = zT_155;
    zT_157 = sa1;
    zF_48AC7B3A_markerWrite(zT_157);
    goto z_bb_12;
    z_bb_16:
    zT_164 = decl.child_1;
    zT_163 = zT_164 != (unsigned int)(0);
    goto z_bb_18;
    z_bb_17:
    zT_163 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_163) goto z_bb_19; else goto z_bb_21;
    z_bb_19:
    zT_168 = ctx->store;
    zT_169 = decl.child_1;
    zT_172 = zF_FCDD1D35_astStoreNodeAt(zT_168, zT_169);
    di_inn = zT_172;
    zT_173 = di_inn.kind;
    if ((int)(zT_173 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_12;
    z_bb_21:
    zT_209 = decl.kind;
    if ((int)(zT_209 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_31; else goto z_bb_32;
    z_bb_22:
    zT_178 = &sa;
    zT_181 = decls.ptr;
    zT_179 = zT_181[di];
    zF_6A91A8CC_semanticAnalyzerGat(zT_178, zT_179);
    goto z_bb_23;
    z_bb_23:
    zT_183 = di_inn.kind;
    if ((int)(zT_183 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_189 = di_inn.flags;
    zT_188 = (unsigned char)(zT_189 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_188 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_188) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_194 = &sa;
    zT_197 = decls.ptr;
    zT_195 = zT_197[di];
    zF_6A91A8CC_semanticAnalyzerGat(zT_194, zT_195);
    goto z_bb_28;
    z_bb_28:
    zT_199 = di_inn.kind;
    if ((int)(zT_199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_204 = &sa;
    zT_207 = decls.ptr;
    zT_205 = zT_207[di];
    zF_4E74AE9D_semanticAnalyzerGat(zT_204, zT_205);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_20;
    z_bb_31:
    zT_214 = &sa;
    zT_217 = decls.ptr;
    zT_215 = zT_217[di];
    zF_4E74AE9D_semanticAnalyzerGat(zT_214, zT_215);
    goto z_bb_32;
    z_bb_32:
    goto z_bb_20;
}

/* phase_StaticAnalyzers */
void zF_F3B55B42_phase_StaticAnalyze(zT_5AB29387_CompilerContext* ctx) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_3E40CD83_Sand* zT_6;
    zT_69057089_CompilerAlloc* zT_7;
    zT_3E40CD83_Sand* zT_9;
    zT_69057089_CompilerAlloc* zT_10;
    zT_C98AF326_CompilerCli zT_12;
    int zT_13;
    int zT_16;
    zT_C98AF326_CompilerCli zT_17;
    int zT_18;
    int zT_21;
    zT_C98AF326_CompilerCli zT_22;
    int zT_23;
    zT_072B53A6_ModuleRegistry* zT_27;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29 = {0};
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    zT_3E40CD83_Sand* zT_36;
    zT_69057089_CompilerAlloc* zT_37;
    zT_6E8D187B_ModuleEntry* zT_40;
    zT_6E8D187B_ModuleEntry zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_46;
    zT_060CD1EB_SymbolTable* zT_50 = 0;
    zT_7E2F335A_AnalyzerContext zT_52;
    zT_6B0A7D14_AstStore* zT_53;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_D3EB6303_StringInterner* zT_55;
    zT_F85C5DED_DiagnosticCollector* zT_56;
    zT_69057089_CompilerAlloc* zT_57;
    zT_3E40CD83_Sand* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_69057089_CompilerAlloc* zT_63;
    zT_3E40CD83_Sand* zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_C98AF326_CompilerCli zT_67;
    int zT_68;
    int zT_69;
    int zT_70;
    int zT_71;
    unsigned char zT_72;
    zT_C98AF326_CompilerCli zT_73;
    int zT_74;
    int zT_75;
    int zT_76;
    int zT_77;
    unsigned char zT_78;
    zT_C98AF326_CompilerCli zT_79;
    int zT_80;
    int zT_81;
    int zT_82;
    int zT_83;
    unsigned char zT_84;
    zT_C98AF326_CompilerCli zT_85;
    int zT_86;
    int zT_87;
    int zT_88;
    int zT_89;
    unsigned char zT_90;
    zT_68F0EBCB_FP_void_zT_7E2F335A zT_91;
    unsigned char zT_92;
    unsigned char zT_93;
    unsigned char zT_94;
    zT_7E2F335A_AnalyzerContext* zT_95;
    unsigned int zT_96;
    int zT_98;
    unsigned int zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    zT_060CD1EB_SymbolTable* sym_table;
    zT_7E2F335A_AnalyzerContext ac;
    zT_2 = "A\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = ctx->alloc;
    zT_6 = &zT_7->scratch;
    zF_F1B3F8C2_sandReset(zT_6);
    zT_10 = ctx->alloc;
    zT_9 = &zT_10->scratch;
    zF_CB5A85E9_sandResetPeak(zT_9);
    zT_12 = ctx->cli;
    zT_13 = zT_12.no_null_check;
    if ((int)(zT_13 != (int)(1))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_17 = ctx->cli;
    zT_18 = zT_17.no_lifetime_check;
    zT_16 = zT_18 != (int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_16 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_16) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_22 = ctx->cli;
    zT_23 = zT_22.no_leak_check;
    zT_21 = zT_23 != (int)(1);
    goto z_bb_6;
    z_bb_5:
    zT_21 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_21) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_27 = ctx->module_reg;
    zT_29 = zF_3452C137_moduleRegistryGetMo(zT_27);
    mods = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    mi = zT_32;
    goto z_bb_9;
    z_bb_8:
    return;
    z_bb_9:
    zT_34 = mods.len;
    if ((int)(mi < zT_34)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = ctx->alloc;
    zT_36 = &zT_37->scratch;
    zF_F1B3F8C2_sandReset(zT_36);
    zT_40 = mods.ptr;
    zT_41 = zT_40[mi];
    zT_42 = zT_41.ast_root;
    ast_root = zT_42;
    if ((int)(ast_root == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_98 = 1;
    zT_99 = mi + zT_98;
    mi = zT_99;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_12;
    z_bb_14:
    zT_46 = ctx->symbol_reg;
    zT_50 = zF_9B36C202_symbolRegistryGetTa(zT_46, (unsigned int)((unsigned int)mi));
    sym_table = zT_50;
    zT_53 = ctx->store;
    zT_52.store = zT_53;
    zT_54 = ctx->typereg;
    zT_52.registry = zT_54;
    zT_55 = ctx->interner;
    zT_52.interner = zT_55;
    zT_56 = ctx->diag;
    zT_52.diag = zT_56;
    zT_52.symbols = sym_table;
    zT_57 = ctx->alloc;
    zT_58 = &zT_57->scratch;
    zT_52.alloc = zT_58;
    zT_59 = 0;
    zT_52.current_fn_name = zT_59;
    zT_60 = 0;
    zT_52.defer_queue_items = (zT_7A19C4A5_DeferEntry*)zT_60;
    zT_61 = 0;
    zT_52.defer_queue_len = zT_61;
    zT_62 = 0;
    zT_52.defer_queue_cap = zT_62;
    zT_63 = ctx->alloc;
    zT_64 = &zT_63->scratch;
    zT_52.defer_queue_alloc = zT_64;
    zT_65 = 0;
    zT_52.current_depth = zT_65;
    zT_66 = 0;
    zT_52.null_analysis_mode = zT_66;
    zT_67 = ctx->cli;
    zT_68 = zT_67.no_null_check;
    if (zT_68) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_70 = 1;
    zT_69 = zT_70;
    goto z_bb_17;
    z_bb_16:
    zT_71 = 0;
    zT_69 = zT_71;
    goto z_bb_17;
    z_bb_17:
    zT_72 = (unsigned char)zT_69;
    zT_52.skip_null_check = zT_72;
    zT_73 = ctx->cli;
    zT_74 = zT_73.no_lifetime_check;
    if (zT_74) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_76 = 1;
    zT_75 = zT_76;
    goto z_bb_20;
    z_bb_19:
    zT_77 = 0;
    zT_75 = zT_77;
    goto z_bb_20;
    z_bb_20:
    zT_78 = (unsigned char)zT_75;
    zT_52.skip_lifetime_check = zT_78;
    zT_79 = ctx->cli;
    zT_80 = zT_79.no_leak_check;
    if (zT_80) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_82 = 1;
    zT_81 = zT_82;
    goto z_bb_23;
    z_bb_22:
    zT_83 = 0;
    zT_81 = zT_83;
    goto z_bb_23;
    z_bb_23:
    zT_84 = (unsigned char)zT_81;
    zT_52.skip_doublefree_check = zT_84;
    zT_85 = ctx->cli;
    zT_86 = zT_85.warn_all;
    if (zT_86) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_88 = 1;
    zT_87 = zT_88;
    goto z_bb_26;
    z_bb_25:
    zT_89 = 0;
    zT_87 = zT_89;
    goto z_bb_26;
    z_bb_26:
    zT_90 = (unsigned char)zT_87;
    zT_52.warn_all = zT_90;
    zT_91 = zF_43C99FB3_onNullStmt;
    zT_52.on_stmt_cb = zT_91;
    zT_92 = 0;
    zT_52.in_defer_exec = zT_92;
    zT_93 = 0;
    zT_52.lifetime_analysis_mode = zT_93;
    zT_94 = 0;
    zT_52.doublefree_analysis_mode = zT_94;
    ac = zT_52;
    zT_95 = &ac;
    zT_96 = ast_root;
    zF_F697813C_runAllAnalyzers(zT_95, zT_96);
    goto z_bb_12;
}

/* phase_LIRLowering */
void zF_1F21ABE7_phase_LIRLowering(zT_5AB29387_CompilerContext* ctx) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_4028D896_Arr_unsigned_char_2 zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    zT_06ACABEC_anon_190680 zT_17;
    unsigned int zT_18;
    int zT_22;
    unsigned char* zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26 = 0;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_4028D896_Arr_unsigned_char_2 zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_6B0A7D14_AstStore* zT_48;
    zT_0FACBA17_anon_190689 zT_49;
    unsigned int zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    unsigned int zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_3E40CD83_Sand* zT_75;
    zT_69057089_CompilerAlloc* zT_76;
    zT_CA01C129_LirSlotArrayList* zT_79;
    zT_846744CC_Arr_unsigned_char_5 zT_81;
    unsigned int zT_83;
    zT_C98AF326_CompilerCli zT_84;
    int zT_85;
    zT_C98AF326_CompilerCli zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    int zT_94;
    unsigned char* zT_97;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned char zT_103;
    unsigned int zT_105;
    unsigned char zT_106;
    unsigned int zT_108;
    unsigned char zT_109;
    unsigned int zT_111;
    char* zT_113;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    unsigned int zT_119;
    int zT_121;
    unsigned char* zT_124;
    unsigned char zT_125;
    unsigned int zT_127;
    unsigned int zT_129;
    zT_7E7544E4_LirStream* zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_131;
    zT_3E40CD83_Sand* zT_132;
    int zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    zT_69057089_CompilerAlloc* zT_140;
    zT_6B356268_SemanticContext zT_143;
    zT_6B0A7D14_AstStore* zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    zT_3D7259E2_SymbolRegistry* zT_146;
    zT_8EED1867_ResolvedTypeTable* zT_147;
    zT_66E7D2EF_CoercionTable* zT_148;
    zT_F85C5DED_DiagnosticCollector* zT_149;
    unsigned char zT_150;
    zT_21D3708C_U32ToU32Map* zT_151;
    zT_21D3708C_U32ToU32Map* zT_152;
    zT_21D3708C_U32ToU32Map* zT_153;
    zT_89877D19_U32ToU64Map* zT_154;
    unsigned int zT_155;
    zT_072B53A6_ModuleRegistry* zT_157;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_159 = {0};
    int zT_161;
    unsigned int zT_162;
    unsigned int zT_164;
    zT_6E8D187B_ModuleEntry* zT_166;
    zT_6E8D187B_ModuleEntry zT_167;
    unsigned int zT_168;
    char* zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    zT_4028D896_Arr_unsigned_char_2 zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    int zT_182;
    unsigned char* zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186 = 0;
    unsigned int zT_190;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    unsigned char* zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    char* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_202;
    zT_6E8D187B_ModuleEntry* zT_203;
    zT_6E8D187B_ModuleEntry zT_204;
    unsigned int zT_205;
    zT_4028D896_Arr_unsigned_char_2 zT_209;
    unsigned int zT_211;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_212;
    zT_6E8D187B_ModuleEntry* zT_213;
    zT_6E8D187B_ModuleEntry zT_214;
    int zT_218;
    unsigned char* zT_219;
    unsigned int zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned int zT_222 = 0;
    unsigned int zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    unsigned char* zT_231;
    unsigned int zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_234;
    zT_6B0A7D14_AstStore* zT_236;
    unsigned int zT_237;
    zT_6E8D187B_ModuleEntry* zT_239;
    zT_6E8D187B_ModuleEntry zT_240;
    zT_22A7C88B_AstNode zT_242 = {0};
    zT_8143F551_AstKind zT_243;
    char* zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_252;
    zT_6B0A7D14_AstStore* zT_254;
    unsigned int zT_255;
    zT_6E8D187B_ModuleEntry* zT_257;
    zT_6E8D187B_ModuleEntry zT_258;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_260 = {0};
    unsigned int zT_263;
    unsigned int zT_264;
    zT_4028D896_Arr_unsigned_char_2 zT_266;
    unsigned int zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    int zT_272;
    unsigned char* zT_273;
    unsigned int zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276 = 0;
    unsigned int zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    unsigned char* zT_285;
    unsigned int zT_286;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_287;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_288;
    zT_6B0A7D14_AstStore* zT_289;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_290;
    zT_B687BB96_U32ArrayList* zT_291;
    zT_6E8D187B_ModuleEntry* zT_293;
    zT_6E8D187B_ModuleEntry* zT_294;
    unsigned char zT_297;
    unsigned int zT_299;
    unsigned int zT_301;
    zT_6B0A7D14_AstStore* zT_304;
    unsigned int zT_305;
    unsigned int* zT_307;
    zT_22A7C88B_AstNode zT_309 = {0};
    zT_8143F551_AstKind zT_311;
    unsigned int zT_312;
    zT_4028D896_Arr_unsigned_char_2 zT_314;
    unsigned int zT_316;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_317;
    int zT_320;
    unsigned char* zT_321;
    unsigned int zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324 = 0;
    unsigned int zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    unsigned char* zT_333;
    unsigned int zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    char* zT_337;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_338;
    unsigned int zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    zT_8143F551_AstKind zT_341;
    char* zT_347;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_348;
    unsigned int zT_349;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350;
    unsigned char zT_351;
    zT_6B0A7D14_AstStore* zT_358;
    zT_092B49FD_anon_190720 zT_359;
    zT_243D6A41_FnProto* zT_360;
    zT_6B0A7D14_AstStore* zT_361;
    unsigned int zT_362;
    unsigned int* zT_364;
    unsigned int zT_366 = 0;
    unsigned int zT_367;
    zT_243D6A41_FnProto zT_368;
    zT_6E8D187B_ModuleEntry* zT_370;
    zT_6E8D187B_ModuleEntry zT_371;
    unsigned int zT_372;
    unsigned int zT_380;
    zT_79FAE712_u64 zT_382;
    zT_A4CE86B7_U64ToU32Map* zT_383;
    zT_79FAE712_u64 zT_384;
    zT_6B356268_SemanticContext* zT_389;
    zT_3E40CD83_Sand* zT_390;
    zT_69057089_CompilerAlloc* zT_392;
    zT_02EB57B2_LirLowerer zT_394 = {0};
    zT_6E8D187B_ModuleEntry* zT_395;
    zT_6E8D187B_ModuleEntry zT_396;
    unsigned int zT_397;
    zT_072B53A6_ModuleRegistry* zT_398;
    zT_02EB57B2_LirLowerer* zT_400;
    unsigned int zT_401;
    unsigned int* zT_403;
    zT_BBC23664_LirFunction zT_405 = {0};
    zT_7E7544E4_LirStream* zT_407;
    zT_BBC23664_LirFunction zT_408;
    zT_E7714190_LirSlot zT_410 = {0};
    zT_CA01C129_LirSlotArrayList* zT_411;
    zT_E7714190_LirSlot zT_412;
    zT_3E40CD83_Sand* zT_414;
    zT_69057089_CompilerAlloc* zT_415;
    zT_8143F551_AstKind zT_417;
    unsigned char zT_422;
    zT_6B0A7D14_AstStore* zT_429;
    unsigned int zT_430;
    unsigned int* zT_432;
    unsigned int zT_434 = 0;
    zT_3D7259E2_SymbolRegistry* zT_436;
    unsigned int zT_437;
    unsigned int zT_438;
    zT_6E8D187B_ModuleEntry* zT_440;
    zT_6E8D187B_ModuleEntry zT_441;
    zT_647FF664_Opt_810 zT_443 = {0};
    unsigned char zT_444;
    zT_3C598AEF_SymbolKind zT_446;
    unsigned char zT_452;
    unsigned char zT_453;
    unsigned char zT_459;
    unsigned int zT_460;
    zT_6B0A7D14_AstStore* zT_464;
    unsigned int zT_465;
    zT_22A7C88B_AstNode zT_468 = {0};
    zT_8143F551_AstKind zT_469;
    int zT_474;
    zT_8143F551_AstKind zT_475;
    int zT_480;
    zT_8143F551_AstKind zT_481;
    unsigned char zT_486;
    unsigned int zT_489;
    zT_6B0A7D14_AstStore* zT_493;
    unsigned int zT_494;
    zT_22A7C88B_AstNode zT_497 = {0};
    zT_8143F551_AstKind zT_498;
    unsigned char zT_503;
    zT_8143F551_AstKind zT_504;
    zT_6B0A7D14_AstStore* zT_510;
    unsigned int zT_511;
    zT_22A7C88B_AstNode zT_514 = {0};
    zT_8143F551_AstKind zT_515;
    unsigned char zT_520;
    unsigned char zT_523;
    zT_6E8D187B_ModuleEntry* zT_530;
    zT_6E8D187B_ModuleEntry zT_531;
    unsigned int zT_532;
    zT_79FAE712_u64 zT_541;
    zT_A4CE86B7_U64ToU32Map* zT_542;
    zT_79FAE712_u64 zT_543;
    unsigned char zT_548;
    unsigned int zT_549;
    zT_6B0A7D14_AstStore* zT_553;
    unsigned int zT_554;
    zT_22A7C88B_AstNode zT_557 = {0};
    zT_8143F551_AstKind zT_558;
    unsigned char zT_563;
    unsigned char zT_566;
    zT_8EED1867_ResolvedTypeTable* zT_568;
    unsigned int zT_569;
    unsigned int* zT_571;
    zT_BAEE192E_Opt_10 zT_573 = {0};
    unsigned char zT_575;
    unsigned int zT_576;
    zT_E1A783EF_GlobalDeclArrayList* zT_579;
    zT_54906056_ModuleGlobalDecl zT_580;
    zT_54906056_ModuleGlobalDecl zT_582;
    zT_6E8D187B_ModuleEntry* zT_583;
    zT_6E8D187B_ModuleEntry zT_584;
    unsigned int zT_585;
    unsigned int zT_587;
    zT_6B356268_SemanticContext* zT_591;
    zT_3E40CD83_Sand* zT_592;
    zT_69057089_CompilerAlloc* zT_594;
    zT_02EB57B2_LirLowerer zT_596 = {0};
    zT_6E8D187B_ModuleEntry* zT_597;
    zT_6E8D187B_ModuleEntry zT_598;
    unsigned int zT_599;
    zT_072B53A6_ModuleRegistry* zT_600;
    zT_02EB57B2_LirLowerer* zT_602;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_603;
    unsigned int zT_604;
    zT_6E8D187B_ModuleEntry* zT_606;
    zT_6E8D187B_ModuleEntry zT_607;
    zT_BBC23664_LirFunction zT_609 = {0};
    zT_7E7544E4_LirStream* zT_611;
    zT_BBC23664_LirFunction zT_612;
    zT_E7714190_LirSlot zT_614 = {0};
    zT_CA01C129_LirSlotArrayList* zT_615;
    zT_E7714190_LirSlot zT_616;
    zT_3E40CD83_Sand* zT_618;
    zT_69057089_CompilerAlloc* zT_619;
    zT_072B53A6_ModuleRegistry* zT_622;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_624 = {0};
    unsigned int zT_626;
    int zT_629;
    zT_6E8D187B_ModuleEntry* zT_630;
    int zT_631;
    zT_6E8D187B_ModuleEntry zT_632;
    unsigned int zT_633;
    zT_6B0A7D14_AstStore* zT_637;
    unsigned int zT_638;
    zT_6E8D187B_ModuleEntry* zT_640;
    int zT_641;
    zT_6E8D187B_ModuleEntry zT_642;
    zT_22A7C88B_AstNode zT_644 = {0};
    zT_8143F551_AstKind zT_645;
    zT_6B0A7D14_AstStore* zT_651;
    unsigned int zT_652;
    zT_6E8D187B_ModuleEntry* zT_654;
    int zT_655;
    zT_6E8D187B_ModuleEntry zT_656;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_658 = {0};
    unsigned int zT_660;
    char* zT_662;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_663;
    unsigned int zT_664;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_665;
    unsigned int zT_667;
    zT_6B0A7D14_AstStore* zT_670;
    unsigned int zT_671;
    unsigned int* zT_673;
    zT_22A7C88B_AstNode zT_675 = {0};
    zT_8143F551_AstKind zT_677;
    unsigned int zT_678;
    zT_4028D896_Arr_unsigned_char_2 zT_680;
    unsigned int zT_682;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_683;
    int zT_686;
    unsigned char* zT_687;
    unsigned int zT_688;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_689;
    unsigned int zT_690 = 0;
    unsigned int zT_694;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_695;
    unsigned char* zT_699;
    unsigned int zT_700;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_701;
    char* zT_703;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_704;
    unsigned int zT_705;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_706;
    unsigned int zT_708;
    char* zT_710;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_711;
    unsigned int zT_712;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_713;
    int zT_714;
    unsigned int zT_715;
    zT_7E7544E4_LirStream* zT_716;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnmsg;
    zT_4028D896_Arr_unsigned_char_2 ln_buf;
    unsigned int ln_len;
    unsigned int ln_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lemsg;
    zT_4028D896_Arr_unsigned_char_2 le_buf;
    unsigned int le_len;
    unsigned int le_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u lnl;
    zT_846744CC_Arr_unsigned_char_5 spill_path;
    unsigned int sp_len;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int oi;
    zT_8F083A69_Slice_zT_0B42B2F8_u tmp_name;
    unsigned int ti;
    zT_6B356268_SemanticContext sem_ctx;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm;
    zT_4028D896_Arr_unsigned_char_2 mi_buf;
    unsigned int mi_len;
    unsigned int mi2_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u msep;
    zT_4028D896_Arr_unsigned_char_2 ar_buf;
    unsigned int ar_len;
    unsigned int ar_start;
    zT_22A7C88B_AstNode root;
    zT_8F083A69_Slice_zT_0B42B2F8_u mr;
    zT_3CB0179A_Slice_zT_05F374B1_u decls;
    unsigned int decl_len;
    zT_4028D896_Arr_unsigned_char_2 dcount_buf;
    unsigned int dcount_len;
    unsigned int dstart;
    unsigned char mod_has_ri;
    unsigned int di;
    zT_22A7C88B_AstNode decl;
    unsigned int raw_k;
    zT_4028D896_Arr_unsigned_char_2 rbuf;
    unsigned int rlen;
    unsigned int rstart;
    zT_8F083A69_Slice_zT_0B42B2F8_u sp2;
    zT_8F083A69_Slice_zT_0B42B2F8_u mf;
    zT_243D6A41_FnProto fexp_proto;
    zT_79FAE712_u64 fexp_key;
    zT_02EB57B2_LirLowerer lowerer;
    zT_BBC23664_LirFunction lf;
    zT_E7714190_LirSlot slot;
    unsigned int gv_name;
    zT_647FF664_Opt_810 gv_sym;
    zT_3A105EF1_Symbol* gvs;
    unsigned char gv_is_storage;
    zT_22A7C88B_AstNode gv_init;
    zT_22A7C88B_AstNode gv_init3;
    zT_22A7C88B_AstNode gv_fb;
    zT_79FAE712_u64 gexp_key;
    unsigned char gv_has_ri;
    zT_22A7C88B_AstNode gv_init2;
    zT_BAEE192E_Opt_10 gv_rt;
    unsigned int gv_tid;
    unsigned int grt;
    zT_02EB57B2_LirLowerer ilowerer;
    zT_BBC23664_LirFunction imf;
    zT_E7714190_LirSlot islot;
    zT_DDCD424B_Slice_zT_6E8D187B_M amods;
    zT_22A7C88B_AstNode ar;
    zT_3CB0179A_Slice_zT_05F374B1_u adl;
    unsigned int adi;
    zT_8F083A69_Slice_zT_0B42B2F8_u al;
    zT_22A7C88B_AstNode ad;
    unsigned int ak;
    zT_4028D896_Arr_unsigned_char_2 ab;
    unsigned int alen;
    unsigned int ast;
    zT_8F083A69_Slice_zT_0B42B2F8_u asp;
    zT_8F083A69_Slice_zT_0B42B2F8_u an;
    zT_2 = "L\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_7 = "nodes=";
    zT_9 = 6;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    lnmsg = zT_8;
    zT_10 = lnmsg;
    zF_48AC7B3A_markerWrite(zT_10);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_12[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ln_buf[_i] = zT_12[_i];
        _i++;
    }
}
    zT_16 = ctx->store;
    zT_17 = zT_16->nodes;
    zT_18 = zT_17.len;
    zT_22 = 0;
    zT_23 = (unsigned char*)((unsigned char*)ln_buf) + zT_22;
    zT_24 = (unsigned int)(20) - zT_22;
    zT_25.ptr = zT_23;
    zT_25.len = zT_24;
    zT_15 = zT_25;
    zT_26 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_18), zT_15);
    ln_len = zT_26;
    zT_30 = (unsigned int)(19) - (unsigned int)((unsigned int)ln_len);
    ln_start = zT_30;
    zT_35 = (unsigned char*)((unsigned char*)ln_buf) + ln_start;
    zT_36 = (unsigned int)(19) - ln_start;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_31 = zT_37;
    zF_48AC7B3A_markerWrite(zT_31);
    zT_39 = " extra=";
    zT_41 = 7;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    lemsg = zT_40;
    zT_42 = lemsg;
    zF_48AC7B3A_markerWrite(zT_42);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        le_buf[_i] = zT_44[_i];
        _i++;
    }
}
    zT_48 = ctx->store;
    zT_49 = zT_48->extra_children;
    zT_50 = zT_49.len;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)le_buf) + zT_54;
    zT_56 = (unsigned int)(20) - zT_54;
    zT_57.ptr = zT_55;
    zT_57.len = zT_56;
    zT_47 = zT_57;
    zT_58 = zF_A7504564_itoa((unsigned int)((unsigned int)zT_50), zT_47);
    le_len = zT_58;
    zT_62 = (unsigned int)(19) - (unsigned int)((unsigned int)le_len);
    le_start = zT_62;
    zT_67 = (unsigned char*)((unsigned char*)le_buf) + le_start;
    zT_68 = (unsigned int)(19) - le_start;
    zT_69.ptr = zT_67;
    zT_69.len = zT_68;
    zT_63 = zT_69;
    zF_48AC7B3A_markerWrite(zT_63);
    zT_71 = "\n";
    zT_73 = 1;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    lnl = zT_72;
    zT_74 = lnl;
    zF_48AC7B3A_markerWrite(zT_74);
    zT_76 = ctx->alloc;
    zT_75 = &zT_76->scratch;
    zF_F1B3F8C2_sandReset(zT_75);
    zT_79 = &ctx->lir_slots;
    zT_79->len = (unsigned int)(0);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_81[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        spill_path[_i] = zT_81[_i];
        _i++;
    }
}
    zT_83 = 0;
    sp_len = zT_83;
    zT_84 = ctx->cli;
    zT_85 = zT_84.output_dir_set;
    if (zT_85) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_87 = ctx->cli;
    zT_88 = zT_87.output_dir;
    od = zT_88;
    zT_90 = 0;
    oi = zT_90;
    goto z_bb_4;
    z_bb_2:
    zT_113 = ".zig1_lir.tmp";
    zT_115 = 13;
    zT_114.ptr = zT_113;
    zT_114.len = zT_115;
    tmp_name = zT_114;
    zT_117 = 0;
    ti = zT_117;
    goto z_bb_11;
    z_bb_3:
    zT_106 = 46;
    spill_path[sp_len] = zT_106;
    zT_108 = sp_len + (unsigned int)(1);
    sp_len = zT_108;
    zT_109 = 47;
    spill_path[sp_len] = zT_109;
    zT_111 = sp_len + (unsigned int)(1);
    sp_len = zT_111;
    goto z_bb_2;
    z_bb_4:
    zT_92 = od.len;
    if ((int)(oi < zT_92)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_97 = od.ptr;
    zT_98 = zT_97[oi];
    spill_path[sp_len] = zT_98;
    zT_100 = sp_len + (unsigned int)(1);
    sp_len = zT_100;
    goto z_bb_7;
    z_bb_6:
    zT_103 = 47;
    spill_path[sp_len] = zT_103;
    zT_105 = sp_len + (unsigned int)(1);
    sp_len = zT_105;
    goto z_bb_2;
    z_bb_7:
    zT_102 = oi + (unsigned int)(1);
    oi = zT_102;
    goto z_bb_4;
    z_bb_8:
    zT_94 = sp_len < (unsigned int)(511);
    goto z_bb_10;
    z_bb_9:
    zT_94 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_94) goto z_bb_5; else goto z_bb_6;
    z_bb_11:
    zT_119 = tmp_name.len;
    if ((int)(ti < zT_119)) goto z_bb_15; else goto z_bb_16;
    z_bb_12:
    zT_124 = tmp_name.ptr;
    zT_125 = zT_124[ti];
    spill_path[sp_len] = zT_125;
    zT_127 = sp_len + (unsigned int)(1);
    sp_len = zT_127;
    goto z_bb_14;
    z_bb_13:
    zT_130 = &ctx->lir_stream;
    zT_136 = 0;
    zT_137 = (unsigned char*)((unsigned char*)spill_path) + zT_136;
    zT_138 = sp_len - zT_136;
    zT_139.ptr = zT_137;
    zT_139.len = zT_138;
    zT_131 = zT_139;
    zT_140 = ctx->alloc;
    zT_132 = &zT_140->emission;
    zF_B0B74E20_lirStreamBeginWrite(zT_130, zT_131, zT_132);
    zT_144 = ctx->store;
    zT_143.store = zT_144;
    zT_145 = ctx->typereg;
    zT_143.registry = zT_145;
    zT_146 = ctx->symbol_reg;
    zT_143.symbol_tables = zT_146;
    zT_147 = ctx->resolved_types;
    zT_143.resolved_types = zT_147;
    zT_148 = ctx->coercion_table;
    zT_143.coercions = zT_148;
    zT_149 = ctx->diag;
    zT_143.diag = zT_149;
    zT_150 = 1;
    zT_143.has_symbols = zT_150;
    zT_151 = &ctx->enum_value_table;
    zT_143.enum_value_table = zT_151;
    zT_152 = &ctx->error_code_registry;
    zT_143.error_code_registry = zT_152;
    zT_153 = &ctx->call_arg_types;
    zT_143.call_arg_types = zT_153;
    zT_154 = &ctx->comptime_values;
    zT_143.comptime_values = zT_154;
    zT_155 = 0;
    zT_143.source_file_id = zT_155;
    sem_ctx = zT_143;
    zT_157 = ctx->module_reg;
    zT_159 = zF_3452C137_moduleRegistryGetMo(zT_157);
    mods = zT_159;
    zT_161 = 0;
    zT_162 = (unsigned int)zT_161;
    mi = zT_162;
    goto z_bb_18;
    z_bb_14:
    zT_129 = ti + (unsigned int)(1);
    ti = zT_129;
    goto z_bb_11;
    z_bb_15:
    zT_121 = sp_len < (unsigned int)(511);
    goto z_bb_17;
    z_bb_16:
    zT_121 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_121) goto z_bb_12; else goto z_bb_13;
    z_bb_18:
    zT_164 = mods.len;
    if ((int)(mi < zT_164)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_166 = mods.ptr;
    zT_167 = zT_166[mi];
    zT_168 = zT_167.source_file_id;
    sem_ctx.source_file_id = zT_168;
    zT_170 = "M";
    zT_172 = 1;
    zT_171.ptr = zT_170;
    zT_171.len = zT_172;
    mm = zT_171;
    zT_173 = mm;
    zF_48AC7B3A_markerWrite(zT_173);
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_175[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        mi_buf[_i] = zT_175[_i];
        _i++;
    }
}
    zT_182 = 0;
    zT_183 = (unsigned char*)((unsigned char*)mi_buf) + zT_182;
    zT_184 = (unsigned int)(20) - zT_182;
    zT_185.ptr = zT_183;
    zT_185.len = zT_184;
    zT_178 = zT_185;
    zT_186 = zF_A7504564_itoa((unsigned int)((unsigned int)mi), zT_178);
    mi_len = zT_186;
    zT_190 = (unsigned int)(19) - (unsigned int)((unsigned int)mi_len);
    mi2_start = zT_190;
    zT_195 = (unsigned char*)((unsigned char*)mi_buf) + mi2_start;
    zT_196 = (unsigned int)(19) - mi2_start;
    zT_197.ptr = zT_195;
    zT_197.len = zT_196;
    zT_191 = zT_197;
    zF_48AC7B3A_markerWrite(zT_191);
    zT_199 = ":";
    zT_201 = 1;
    zT_200.ptr = zT_199;
    zT_200.len = zT_201;
    msep = zT_200;
    zT_202 = msep;
    zF_48AC7B3A_markerWrite(zT_202);
    zT_203 = mods.ptr;
    zT_204 = zT_203[mi];
    zT_205 = zT_204.ast_root;
    if ((int)(zT_205 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_716 = &ctx->lir_stream;
    zF_256E5B86_lirStreamFinishWrit(zT_716);
    return;
    z_bb_21:
    zT_714 = 1;
    zT_715 = mi + zT_714;
    mi = zT_715;
    goto z_bb_18;
    z_bb_22:
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_209[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ar_buf[_i] = zT_209[_i];
        _i++;
    }
}
    zT_213 = mods.ptr;
    zT_214 = zT_213[mi];
    zT_211 = zT_214.ast_root;
    zT_218 = 0;
    zT_219 = (unsigned char*)((unsigned char*)ar_buf) + zT_218;
    zT_220 = (unsigned int)(20) - zT_218;
    zT_221.ptr = zT_219;
    zT_221.len = zT_220;
    zT_212 = zT_221;
    zT_222 = zF_A7504564_itoa(zT_211, zT_212);
    ar_len = zT_222;
    zT_226 = (unsigned int)(19) - (unsigned int)((unsigned int)ar_len);
    ar_start = zT_226;
    zT_231 = (unsigned char*)((unsigned char*)ar_buf) + ar_start;
    zT_232 = (unsigned int)(19) - ar_start;
    zT_233.ptr = zT_231;
    zT_233.len = zT_232;
    zT_227 = zT_233;
    zF_48AC7B3A_markerWrite(zT_227);
    zT_234 = msep;
    zF_48AC7B3A_markerWrite(zT_234);
    zT_236 = ctx->store;
    zT_239 = mods.ptr;
    zT_240 = zT_239[mi];
    zT_237 = zT_240.ast_root;
    zT_242 = zF_FCDD1D35_astStoreNodeAt(zT_236, zT_237);
    root = zT_242;
    zT_243 = root.kind;
    if ((int)(zT_243 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_249 = "R";
    zT_251 = 1;
    zT_250.ptr = zT_249;
    zT_250.len = zT_251;
    mr = zT_250;
    zT_252 = mr;
    zF_48AC7B3A_markerWrite(zT_252);
    zT_254 = ctx->store;
    zT_257 = mods.ptr;
    zT_258 = zT_257[mi];
    zT_255 = zT_258.ast_root;
    zT_260 = zF_850FDF81_astStoreNodeExtraCh(zT_254, zT_255);
    decls = zT_260;
    zT_263 = decls.len;
    zT_264 = (unsigned int)zT_263;
    decl_len = zT_264;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_266[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        dcount_buf[_i] = zT_266[_i];
        _i++;
    }
}
    zT_268 = decl_len;
    zT_272 = 0;
    zT_273 = (unsigned char*)((unsigned char*)dcount_buf) + zT_272;
    zT_274 = (unsigned int)(20) - zT_272;
    zT_275.ptr = zT_273;
    zT_275.len = zT_274;
    zT_269 = zT_275;
    zT_276 = zF_A7504564_itoa(zT_268, zT_269);
    dcount_len = zT_276;
    zT_280 = (unsigned int)(19) - (unsigned int)((unsigned int)dcount_len);
    dstart = zT_280;
    zT_285 = (unsigned char*)((unsigned char*)dcount_buf) + dstart;
    zT_286 = (unsigned int)(19) - dstart;
    zT_287.ptr = zT_285;
    zT_287.len = zT_286;
    zT_281 = zT_287;
    zF_48AC7B3A_markerWrite(zT_281);
    zT_288 = msep;
    zF_48AC7B3A_markerWrite(zT_288);
    zT_289 = ctx->store;
    zT_290 = decls;
    zT_293 = mods.ptr;
    zT_294 = zT_293 + mi;
    zT_291 = &zT_294->c_includes;
    zF_7D71E4ED_moduleRegistryColle(zT_289, zT_290, zT_291);
    zT_297 = 0;
    mod_has_ri = zT_297;
    zT_299 = 0;
    di = zT_299;
    goto z_bb_26;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_301 = decls.len;
    if ((int)(di < zT_301)) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_304 = ctx->store;
    zT_307 = decls.ptr;
    zT_305 = zT_307[di];
    zT_309 = zF_FCDD1D35_astStoreNodeAt(zT_304, zT_305);
    decl = zT_309;
    zT_311 = decl.kind;
    zT_312 = (unsigned int)zT_311;
    raw_k = zT_312;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_314[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        rbuf[_i] = zT_314[_i];
        _i++;
    }
}
    zT_316 = raw_k;
    zT_320 = 0;
    zT_321 = (unsigned char*)((unsigned char*)rbuf) + zT_320;
    zT_322 = (unsigned int)(20) - zT_320;
    zT_323.ptr = zT_321;
    zT_323.len = zT_322;
    zT_317 = zT_323;
    zT_324 = zF_A7504564_itoa(zT_316, zT_317);
    rlen = zT_324;
    zT_328 = (unsigned int)(19) - (unsigned int)((unsigned int)rlen);
    rstart = zT_328;
    zT_333 = (unsigned char*)((unsigned char*)rbuf) + rstart;
    zT_334 = (unsigned int)(19) - rstart;
    zT_335.ptr = zT_333;
    zT_335.len = zT_334;
    zT_329 = zT_335;
    zF_48AC7B3A_markerWrite(zT_329);
    zT_337 = " ";
    zT_339 = 1;
    zT_338.ptr = zT_337;
    zT_338.len = zT_339;
    sp2 = zT_338;
    zT_340 = sp2;
    zF_48AC7B3A_markerWrite(zT_340);
    zT_341 = decl.kind;
    if ((int)(zT_341 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_30; else goto z_bb_32;
    z_bb_28:
    if ((int)(mod_has_ri != (unsigned char)(0))) goto z_bb_79; else goto z_bb_80;
    z_bb_29:
    zT_587 = di + (unsigned int)(1);
    di = zT_587;
    goto z_bb_26;
    z_bb_30:
    zT_347 = "F";
    zT_349 = 1;
    zT_348.ptr = zT_347;
    zT_348.len = zT_349;
    mf = zT_348;
    zT_350 = mf;
    zF_48AC7B3A_markerWrite(zT_350);
    zT_351 = decl.flags;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_351) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_29;
    z_bb_32:
    zT_417 = decl.kind;
    if ((int)(zT_417 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    zT_358 = ctx->store;
    zT_359 = zT_358->fn_protos;
    zT_360 = zT_359.items;
    zT_361 = ctx->store;
    zT_364 = decls.ptr;
    zT_362 = zT_364[di];
    zT_366 = zF_8BA26B9E_astStoreNodePayload(zT_361, zT_362);
    zT_367 = (unsigned int)zT_366;
    zT_368 = zT_360[zT_367];
    fexp_proto = zT_368;
    zT_370 = mods.ptr;
    zT_371 = zT_370[mi];
    zT_372 = zT_371.id;
    zT_380 = fexp_proto.name_id;
    zT_382 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_372) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(0)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_380);
    fexp_key = zT_382;
    zT_383 = &ctx->exported;
    zT_384 = fexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_383, zT_384, (unsigned int)(1));
    (void)ctx;
    goto z_bb_34;
    z_bb_34:
    zT_389 = &sem_ctx;
    zT_392 = ctx->alloc;
    zT_390 = &zT_392->scratch;
    zT_394 = zF_ADD4254B_lowererInit(zT_389, zT_390);
    lowerer = zT_394;
    zT_395 = mods.ptr;
    zT_396 = zT_395[mi];
    zT_397 = zT_396.id;
    lowerer.module_id = zT_397;
    zT_398 = ctx->module_reg;
    lowerer.module_reg = zT_398;
    zT_400 = &lowerer;
    zT_403 = decls.ptr;
    zT_401 = zT_403[di];
    zT_405 = zF_B53F5F2E_lowerFn(zT_400, zT_401);
    lf = zT_405;
    zT_407 = &ctx->lir_stream;
    zT_408 = lf;
    zT_410 = zF_9F47D5E4_lirStreamAppend(zT_407, zT_408);
    slot = zT_410;
    zT_411 = &ctx->lir_slots;
    zT_412 = slot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_411, zT_412);
    zT_415 = ctx->alloc;
    zT_414 = &zT_415->scratch;
    zF_F1B3F8C2_sandReset(zT_414);
    goto z_bb_31;
    z_bb_35:
    zT_422 = decl.flags;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_422) & (unsigned short)(4)) == (unsigned short)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_429 = ctx->store;
    zT_432 = decls.ptr;
    zT_430 = zT_432[di];
    zT_434 = zF_8BA26B9E_astStoreNodePayload(zT_429, zT_430);
    gv_name = zT_434;
    zT_436 = ctx->symbol_reg;
    zT_440 = mods.ptr;
    zT_441 = zT_440[mi];
    zT_437 = zT_441.id;
    zT_438 = gv_name;
    zT_443 = zF_A398987E_symbolRegistryQuali(zT_436, zT_437, zT_438);
    gv_sym = zT_443;
    zT_444 = gv_sym.has_value;
    if (zT_444) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    gvs = gv_sym.value;
    zT_446 = gvs->kind;
    if ((int)(zT_446 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    goto z_bb_38;
    z_bb_41:
    zT_452 = 0;
    gv_is_storage = zT_452;
    zT_453 = decl.flags;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_453) & (unsigned short)(1)) != (unsigned short)(0))) goto z_bb_43; else goto z_bb_45;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_459 = 1;
    gv_is_storage = zT_459;
    goto z_bb_44;
    z_bb_44:
    if ((int)(gv_is_storage == (unsigned char)(1))) goto z_bb_56; else goto z_bb_57;
    z_bb_45:
    zT_460 = decl.child_1;
    if ((int)(zT_460 != (unsigned int)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_464 = ctx->store;
    zT_465 = decl.child_1;
    zT_468 = zF_FCDD1D35_astStoreNodeAt(zT_464, zT_465);
    gv_init = zT_468;
    zT_469 = gv_init.kind;
    if ((int)(zT_469 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_475 = gv_init.kind;
    zT_474 = zT_475 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal);
    goto z_bb_50;
    z_bb_49:
    zT_474 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_474) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_481 = gv_init.kind;
    zT_480 = zT_481 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_53;
    z_bb_52:
    zT_480 = 0;
    goto z_bb_53;
    z_bb_53:
    if (zT_480) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_486 = 1;
    gv_is_storage = zT_486;
    goto z_bb_55;
    z_bb_55:
    goto z_bb_47;
    z_bb_56:
    zT_489 = decl.child_1;
    if ((int)(zT_489 != (unsigned int)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    if ((int)(gv_is_storage == (unsigned char)(1))) goto z_bb_66; else goto z_bb_67;
    z_bb_58:
    zT_493 = ctx->store;
    zT_494 = decl.child_1;
    zT_497 = zF_FCDD1D35_astStoreNodeAt(zT_493, zT_494);
    gv_init3 = zT_497;
    zT_498 = gv_init3.kind;
    if ((int)(zT_498 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_57;
    z_bb_60:
    zT_503 = 0;
    gv_is_storage = zT_503;
    goto z_bb_61;
    z_bb_61:
    zT_504 = gv_init3.kind;
    if ((int)(zT_504 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_510 = ctx->store;
    zT_511 = gv_init3.child_0;
    zT_514 = zF_FCDD1D35_astStoreNodeAt(zT_510, zT_511);
    gv_fb = zT_514;
    zT_515 = gv_fb.kind;
    if ((int)(zT_515 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_64; else goto z_bb_65;
    z_bb_63:
    goto z_bb_59;
    z_bb_64:
    zT_520 = 0;
    gv_is_storage = zT_520;
    goto z_bb_65;
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    zT_523 = decl.flags;
    if ((int)((unsigned short)((unsigned short)((unsigned short)zT_523) & (unsigned short)(8)) != (unsigned short)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    goto z_bb_42;
    z_bb_68:
    zT_530 = mods.ptr;
    zT_531 = zT_530[mi];
    zT_532 = zT_531.id;
    zT_541 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_532) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)(4294967296ULL)) | (zT_79FAE712_u64)((zT_79FAE712_u64)gv_name);
    gexp_key = zT_541;
    zT_542 = &ctx->exported;
    zT_543 = gexp_key;
    zF_B6EB812C_u64ToU32MapPut(zT_542, zT_543, (unsigned int)(1));
    (void)ctx;
    goto z_bb_69;
    z_bb_69:
    zT_548 = 0;
    gv_has_ri = zT_548;
    zT_549 = decl.child_1;
    if ((int)(zT_549 != (unsigned int)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_553 = ctx->store;
    zT_554 = decl.child_1;
    zT_557 = zF_FCDD1D35_astStoreNodeAt(zT_553, zT_554);
    gv_init2 = zT_557;
    zT_558 = gv_init2.kind;
    if ((int)(zT_558 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_undefined_literal))) goto z_bb_72; else goto z_bb_73;
    z_bb_71:
    if ((int)(gv_has_ri == (unsigned char)(1))) goto z_bb_74; else goto z_bb_75;
    z_bb_72:
    zT_563 = 1;
    gv_has_ri = zT_563;
    goto z_bb_73;
    z_bb_73:
    goto z_bb_71;
    z_bb_74:
    zT_566 = 1;
    mod_has_ri = zT_566;
    goto z_bb_75;
    z_bb_75:
    zT_568 = ctx->resolved_types;
    zT_571 = decls.ptr;
    zT_569 = zT_571[di];
    zT_573 = zF_999DCF51_resolvedTypeTableGe(zT_568, zT_569);
    gv_rt = zT_573;
    zT_575 = gv_rt.has_value;
    if (zT_575) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    grt = gv_rt.value;
    zT_576 = grt;
    goto z_bb_78;
    z_bb_77:
    zT_576 = 18;
    goto z_bb_78;
    z_bb_78:
    gv_tid = zT_576;
    zT_579 = &ctx->global_decls;
    zT_582.name_id = gv_name;
    zT_583 = mods.ptr;
    zT_584 = zT_583[mi];
    zT_585 = zT_584.id;
    zT_582.module_id = zT_585;
    zT_582.type_id = gv_tid;
    zT_582.has_runtime_init = gv_has_ri;
    zT_580 = zT_582;
    zF_F2C82CE7_globalDeclArrayList(zT_579, zT_580);
    goto z_bb_67;
    z_bb_79:
    zT_591 = &sem_ctx;
    zT_594 = ctx->alloc;
    zT_592 = &zT_594->scratch;
    zT_596 = zF_ADD4254B_lowererInit(zT_591, zT_592);
    ilowerer = zT_596;
    zT_597 = mods.ptr;
    zT_598 = zT_597[mi];
    zT_599 = zT_598.id;
    ilowerer.module_id = zT_599;
    zT_600 = ctx->module_reg;
    ilowerer.module_reg = zT_600;
    zT_602 = &ilowerer;
    zT_603 = decls;
    zT_606 = mods.ptr;
    zT_607 = zT_606[mi];
    zT_604 = zT_607.id;
    zT_609 = zF_552B231C_lowerModuleInit(zT_602, zT_603, zT_604);
    imf = zT_609;
    zT_611 = &ctx->lir_stream;
    zT_612 = imf;
    zT_614 = zF_9F47D5E4_lirStreamAppend(zT_611, zT_612);
    islot = zT_614;
    zT_615 = &ctx->lir_slots;
    zT_616 = islot;
    zF_BD1C46FD_lirSlotArrayListApp(zT_615, zT_616);
    zT_619 = ctx->alloc;
    zT_618 = &zT_619->scratch;
    zF_F1B3F8C2_sandReset(zT_618);
    goto z_bb_80;
    z_bb_80:
    zT_622 = ctx->module_reg;
    zT_624 = zF_3452C137_moduleRegistryGetMo(zT_622);
    amods = zT_624;
    zT_626 = amods.len;
    if ((int)(zT_626 > (unsigned int)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_630 = amods.ptr;
    zT_631 = 0;
    zT_632 = zT_630[zT_631];
    zT_633 = zT_632.ast_root;
    zT_629 = zT_633 != (unsigned int)(0);
    goto z_bb_83;
    z_bb_82:
    zT_629 = 0;
    goto z_bb_83;
    z_bb_83:
    if (zT_629) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_637 = ctx->store;
    zT_640 = amods.ptr;
    zT_641 = 0;
    zT_642 = zT_640[zT_641];
    zT_638 = zT_642.ast_root;
    zT_644 = zF_FCDD1D35_astStoreNodeAt(zT_637, zT_638);
    ar = zT_644;
    zT_645 = ar.kind;
    if ((int)(zT_645 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_module_root))) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    goto z_bb_25;
    z_bb_86:
    zT_651 = ctx->store;
    zT_654 = amods.ptr;
    zT_655 = 0;
    zT_656 = zT_654[zT_655];
    zT_652 = zT_656.ast_root;
    zT_658 = zF_850FDF81_astStoreNodeExtraCh(zT_651, zT_652);
    adl = zT_658;
    zT_660 = 0;
    adi = zT_660;
    zT_662 = "A0";
    zT_664 = 2;
    zT_663.ptr = zT_662;
    zT_663.len = zT_664;
    al = zT_663;
    zT_665 = al;
    zF_48AC7B3A_markerWrite(zT_665);
    goto z_bb_88;
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_667 = adl.len;
    if ((int)(adi < zT_667)) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_670 = ctx->store;
    zT_673 = adl.ptr;
    zT_671 = zT_673[adi];
    zT_675 = zF_FCDD1D35_astStoreNodeAt(zT_670, zT_671);
    ad = zT_675;
    zT_677 = ad.kind;
    zT_678 = (unsigned int)zT_677;
    ak = zT_678;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_680[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        ab[_i] = zT_680[_i];
        _i++;
    }
}
    zT_682 = ak;
    zT_686 = 0;
    zT_687 = (unsigned char*)((unsigned char*)ab) + zT_686;
    zT_688 = (unsigned int)(20) - zT_686;
    zT_689.ptr = zT_687;
    zT_689.len = zT_688;
    zT_683 = zT_689;
    zT_690 = zF_A7504564_itoa(zT_682, zT_683);
    alen = zT_690;
    zT_694 = (unsigned int)(19) - (unsigned int)((unsigned int)alen);
    ast = zT_694;
    zT_699 = (unsigned char*)((unsigned char*)ab) + ast;
    zT_700 = (unsigned int)(19) - ast;
    zT_701.ptr = zT_699;
    zT_701.len = zT_700;
    zT_695 = zT_701;
    zF_48AC7B3A_markerWrite(zT_695);
    zT_703 = " ";
    zT_705 = 1;
    zT_704.ptr = zT_703;
    zT_704.len = zT_705;
    asp = zT_704;
    zT_706 = asp;
    zF_48AC7B3A_markerWrite(zT_706);
    goto z_bb_91;
    z_bb_90:
    zT_710 = "\n";
    zT_712 = 1;
    zT_711.ptr = zT_710;
    zT_711.len = zT_712;
    an = zT_711;
    zT_713 = an;
    zF_48AC7B3A_markerWrite(zT_713);
    goto z_bb_87;
    z_bb_91:
    zT_708 = adi + (unsigned int)(1);
    adi = zT_708;
    goto z_bb_88;
}

/* errorCodeRegistryFinalize */
void zF_FC691B4D_errorCodeRegistryFi(zT_5AB29387_CompilerContext* ctx) {
    int zT_2;
    unsigned int zT_3;
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_D155D06D_Type* zT_9;
    zT_D155D06D_Type zT_10;
    zT_33EF6BFB_TypeKind zT_11;
    unsigned int zT_16;
    zT_338B7C76_TypeRegistry* zT_18;
    unsigned int zT_19;
    zT_338B7C76_TypeRegistry* zT_22;
    zT_0B73C507_ErrorSetPayload* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_0B73C507_ErrorSetPayload zT_26;
    int zT_28;
    unsigned int zT_29;
    unsigned short zT_30;
    zT_338B7C76_TypeRegistry* zT_34;
    unsigned int* zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_21D3708C_U32ToU32Map* zT_40;
    unsigned int zT_41;
    unsigned int zT_43 = 0;
    int zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    unsigned int ti;
    zT_D155D06D_Type ty;
    zT_0B73C507_ErrorSetPayload esp;
    unsigned int ei;
    unsigned int mname_id;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    ti = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ctx->typereg;
    zT_5 = zT_4->types_len;
    if ((int)(ti < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = ctx->typereg;
    zT_9 = zT_8->types_items;
    zT_10 = zT_9[ti];
    ty = zT_10;
    zT_11 = ty.kind;
    if ((int)(zT_11 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_46 = 1;
    zT_47 = ti + zT_46;
    ti = zT_47;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_16 = ty.payload_idx;
    zT_18 = ctx->typereg;
    zT_19 = zT_18->es_len;
    if ((int)((unsigned int)((unsigned int)zT_16) >= zT_19)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_22 = ctx->typereg;
    zT_23 = zT_22->es_items;
    zT_24 = ty.payload_idx;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23[zT_25];
    esp = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    ei = zT_29;
    goto z_bb_9;
    z_bb_9:
    zT_30 = esp.tags_count;
    if ((int)(ei < (unsigned int)((unsigned int)zT_30))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_34 = ctx->typereg;
    zT_35 = zT_34->xn_items;
    zT_36 = esp.tags_start;
    zT_38 = (unsigned int)((unsigned int)zT_36) + ei;
    zT_39 = zT_35[zT_38];
    mname_id = zT_39;
    zT_40 = &ctx->error_code_registry;
    zT_41 = mname_id;
    zT_43 = zF_8879E7FF_u32ToU32MapGetOrAdd(zT_40, zT_41);
    (void)zT_43;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    zT_44 = 1;
    zT_45 = ei + zT_44;
    ei = zT_45;
    goto z_bb_9;
}

/* pruneTypeMarkByValue */
void zF_BC6C7740_pruneTypeMarkByValu(zT_21D3708C_U32ToU32Map* ref_edges, zT_338B7C76_TypeRegistry* reg, zT_A4CE86B7_U64ToU32Map* visited, unsigned int src_mid, unsigned int tid) {
    unsigned int zT_5;
    zT_79FAE712_u64 zT_13;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    zT_79FAE712_u64 zT_15;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_A4CE86B7_U64ToU32Map* zT_18;
    zT_79FAE712_u64 zT_19;
    zT_D155D06D_Type* zT_23;
    unsigned int zT_24;
    zT_D155D06D_Type zT_25;
    unsigned int zT_26;
    int zT_29;
    unsigned int zT_30;
    zT_21D3708C_U32ToU32Map* zT_32;
    unsigned int zT_37;
    zT_33EF6BFB_TypeKind zT_40;
    zT_406493CE_StructPayload* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_406493CE_StructPayload zT_49;
    unsigned int zT_51;
    unsigned short zT_52;
    zT_21D3708C_U32ToU32Map* zT_55;
    zT_338B7C76_TypeRegistry* zT_56;
    zT_A4CE86B7_U64ToU32Map* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    zT_2DF01B61_FieldEntry* zT_60;
    unsigned int zT_61;
    unsigned int zT_63;
    zT_2DF01B61_FieldEntry zT_64;
    unsigned int zT_67;
    zT_33EF6BFB_TypeKind zT_68;
    zT_54FF90FA_TaggedUnionPayload* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    zT_54FF90FA_TaggedUnionPayload zT_77;
    zT_21D3708C_U32ToU32Map* zT_78;
    zT_338B7C76_TypeRegistry* zT_79;
    zT_A4CE86B7_U64ToU32Map* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_85;
    unsigned short zT_86;
    zT_21D3708C_U32ToU32Map* zT_89;
    zT_338B7C76_TypeRegistry* zT_90;
    zT_A4CE86B7_U64ToU32Map* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_2DF01B61_FieldEntry* zT_94;
    unsigned int zT_95;
    unsigned int zT_97;
    zT_2DF01B61_FieldEntry zT_98;
    unsigned int zT_101;
    zT_33EF6BFB_TypeKind zT_102;
    int zT_107;
    zT_33EF6BFB_TypeKind zT_108;
    zT_AF9231A2_UnionPayload* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_AF9231A2_UnionPayload zT_117;
    zT_21D3708C_U32ToU32Map* zT_118;
    zT_338B7C76_TypeRegistry* zT_119;
    zT_A4CE86B7_U64ToU32Map* zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_125;
    unsigned short zT_126;
    zT_21D3708C_U32ToU32Map* zT_129;
    zT_338B7C76_TypeRegistry* zT_130;
    zT_A4CE86B7_U64ToU32Map* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    zT_2DF01B61_FieldEntry* zT_134;
    unsigned int zT_135;
    unsigned int zT_137;
    zT_2DF01B61_FieldEntry zT_138;
    unsigned int zT_141;
    zT_33EF6BFB_TypeKind zT_142;
    zT_457ECFEE_EnumPayload* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_457ECFEE_EnumPayload zT_151;
    zT_21D3708C_U32ToU32Map* zT_152;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_A4CE86B7_U64ToU32Map* zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_33EF6BFB_TypeKind zT_158;
    zT_E834303C_ArrayPayload* zT_164;
    unsigned int zT_165;
    unsigned int zT_166;
    zT_E834303C_ArrayPayload zT_167;
    zT_21D3708C_U32ToU32Map* zT_168;
    zT_338B7C76_TypeRegistry* zT_169;
    zT_A4CE86B7_U64ToU32Map* zT_170;
    unsigned int zT_171;
    unsigned int zT_172;
    zT_33EF6BFB_TypeKind zT_174;
    zT_666DC2E1_TuplePayload* zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    zT_666DC2E1_TuplePayload zT_183;
    unsigned int zT_185;
    unsigned short zT_186;
    zT_21D3708C_U32ToU32Map* zT_189;
    zT_338B7C76_TypeRegistry* zT_190;
    zT_A4CE86B7_U64ToU32Map* zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int* zT_194;
    unsigned int zT_195;
    unsigned int zT_197;
    unsigned int zT_200;
    zT_33EF6BFB_TypeKind zT_201;
    zT_0B10E8E9_OptionalPayload* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    zT_0B10E8E9_OptionalPayload zT_210;
    zT_21D3708C_U32ToU32Map* zT_211;
    zT_338B7C76_TypeRegistry* zT_212;
    zT_A4CE86B7_U64ToU32Map* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    zT_33EF6BFB_TypeKind zT_217;
    zT_42C2D6BF_EUPayload* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    zT_42C2D6BF_EUPayload zT_226;
    zT_21D3708C_U32ToU32Map* zT_227;
    zT_338B7C76_TypeRegistry* zT_228;
    zT_A4CE86B7_U64ToU32Map* zT_229;
    unsigned int zT_230;
    unsigned int zT_231;
    zT_21D3708C_U32ToU32Map* zT_233;
    zT_338B7C76_TypeRegistry* zT_234;
    zT_A4CE86B7_U64ToU32Map* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_79FAE712_u64 vkey;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload p;
    unsigned int fi;
    zT_54FF90FA_TaggedUnionPayload p_1;
    zT_AF9231A2_UnionPayload p_2;
    zT_457ECFEE_EnumPayload p_3;
    zT_E834303C_ArrayPayload p_4;
    zT_666DC2E1_TuplePayload p_5;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload p_6;
    zT_42C2D6BF_EUPayload p_7;
    zT_5 = reg->types_len;
    if ((int)(tid >= (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_13 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)src_mid) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)tid);
    vkey = zT_13;
    zT_14 = visited;
    zT_15 = vkey;
    zT_16 = zF_A05A7BE1_u64ToU32MapGet(zT_14, zT_15);
    zT_17 = zT_16.has_value;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_18 = visited;
    zT_19 = vkey;
    zF_B6EB812C_u64ToU32MapPut(zT_18, zT_19, (unsigned int)(1));
    zT_23 = reg->types_items;
    zT_24 = (unsigned int)tid;
    zT_25 = zT_23[zT_24];
    ty = zT_25;
    zT_26 = ty.module_id;
    if ((int)(zT_26 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = ty.module_id;
    zT_29 = zT_30 != src_mid;
    goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = ref_edges;
    zT_37 = ty.module_id;
    zF_26476265_u32ToU32MapPut(zT_32, (unsigned int)((unsigned int)(src_mid * (unsigned int)(65536)) + zT_37), (unsigned int)(1));
    goto z_bb_9;
    z_bb_9:
    zT_40 = ty.kind;
    if ((int)(zT_40 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    zT_46 = reg->st_items;
    zT_47 = ty.payload_idx;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zT_46[zT_48];
    p = zT_49;
    zT_51 = 0;
    fi = zT_51;
    goto z_bb_13;
    z_bb_11:
    return;
    z_bb_12:
    zT_68 = ty.kind;
    if ((int)(zT_68 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_13:
    zT_52 = p.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_52))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_55 = ref_edges;
    zT_56 = reg;
    zT_57 = visited;
    zT_58 = src_mid;
    zT_60 = reg->fe_items;
    zT_61 = p.fields_start;
    zT_63 = (unsigned int)((unsigned int)zT_61) + fi;
    zT_64 = zT_60[zT_63];
    zT_59 = zT_64.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_55, zT_56, zT_57, zT_58, zT_59);
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    zT_67 = fi + (unsigned int)(1);
    fi = zT_67;
    goto z_bb_13;
    z_bb_17:
    zT_74 = reg->tu_items;
    zT_75 = ty.payload_idx;
    zT_76 = (unsigned int)zT_75;
    zT_77 = zT_74[zT_76];
    p_1 = zT_77;
    zT_78 = ref_edges;
    zT_79 = reg;
    zT_80 = visited;
    zT_81 = src_mid;
    zT_82 = p_1.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_78, zT_79, zT_80, zT_81, zT_82);
    zT_85 = 0;
    fi = zT_85;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_11;
    z_bb_19:
    zT_102 = ty.kind;
    if ((int)(zT_102 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_25; else goto z_bb_24;
    z_bb_20:
    zT_86 = p_1.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_86))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_89 = ref_edges;
    zT_90 = reg;
    zT_91 = visited;
    zT_92 = src_mid;
    zT_94 = reg->fe_items;
    zT_95 = p_1.fields_start;
    zT_97 = (unsigned int)((unsigned int)zT_95) + fi;
    zT_98 = zT_94[zT_97];
    zT_93 = zT_98.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_89, zT_90, zT_91, zT_92, zT_93);
    goto z_bb_23;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_101 = fi + (unsigned int)(1);
    fi = zT_101;
    goto z_bb_20;
    z_bb_24:
    zT_108 = ty.kind;
    zT_107 = zT_108 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_26;
    z_bb_25:
    zT_107 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_107) goto z_bb_27; else goto z_bb_29;
    z_bb_27:
    zT_114 = reg->un_items;
    zT_115 = ty.payload_idx;
    zT_116 = (unsigned int)zT_115;
    zT_117 = zT_114[zT_116];
    p_2 = zT_117;
    zT_118 = ref_edges;
    zT_119 = reg;
    zT_120 = visited;
    zT_121 = src_mid;
    zT_122 = p_2.tag_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_118, zT_119, zT_120, zT_121, zT_122);
    zT_125 = 0;
    fi = zT_125;
    goto z_bb_30;
    z_bb_28:
    goto z_bb_18;
    z_bb_29:
    zT_142 = ty.kind;
    if ((int)(zT_142 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_34; else goto z_bb_36;
    z_bb_30:
    zT_126 = p_2.fields_count;
    if ((int)(fi < (unsigned int)((unsigned int)zT_126))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_129 = ref_edges;
    zT_130 = reg;
    zT_131 = visited;
    zT_132 = src_mid;
    zT_134 = reg->fe_items;
    zT_135 = p_2.fields_start;
    zT_137 = (unsigned int)((unsigned int)zT_135) + fi;
    zT_138 = zT_134[zT_137];
    zT_133 = zT_138.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_129, zT_130, zT_131, zT_132, zT_133);
    goto z_bb_33;
    z_bb_32:
    goto z_bb_28;
    z_bb_33:
    zT_141 = fi + (unsigned int)(1);
    fi = zT_141;
    goto z_bb_30;
    z_bb_34:
    zT_148 = reg->en_items;
    zT_149 = ty.payload_idx;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zT_148[zT_150];
    p_3 = zT_151;
    zT_152 = ref_edges;
    zT_153 = reg;
    zT_154 = visited;
    zT_155 = src_mid;
    zT_156 = p_3.backing_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_152, zT_153, zT_154, zT_155, zT_156);
    goto z_bb_35;
    z_bb_35:
    goto z_bb_28;
    z_bb_36:
    zT_158 = ty.kind;
    if ((int)(zT_158 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_164 = reg->array_items;
    zT_165 = ty.payload_idx;
    zT_166 = (unsigned int)zT_165;
    zT_167 = zT_164[zT_166];
    p_4 = zT_167;
    zT_168 = ref_edges;
    zT_169 = reg;
    zT_170 = visited;
    zT_171 = src_mid;
    zT_172 = p_4.elem;
    zF_BC6C7740_pruneTypeMarkByValu(zT_168, zT_169, zT_170, zT_171, zT_172);
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_174 = ty.kind;
    if ((int)(zT_174 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_40; else goto z_bb_42;
    z_bb_40:
    zT_180 = reg->tup_items;
    zT_181 = ty.payload_idx;
    zT_182 = (unsigned int)zT_181;
    zT_183 = zT_180[zT_182];
    p_5 = zT_183;
    zT_185 = 0;
    ei = zT_185;
    goto z_bb_43;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_201 = ty.kind;
    if ((int)(zT_201 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_47; else goto z_bb_49;
    z_bb_43:
    zT_186 = p_5.elems_count;
    if ((int)(ei < (unsigned int)((unsigned int)zT_186))) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_189 = ref_edges;
    zT_190 = reg;
    zT_191 = visited;
    zT_192 = src_mid;
    zT_194 = reg->xt_items;
    zT_195 = p_5.elems_start;
    zT_197 = (unsigned int)((unsigned int)zT_195) + ei;
    zT_193 = zT_194[zT_197];
    zF_BC6C7740_pruneTypeMarkByValu(zT_189, zT_190, zT_191, zT_192, zT_193);
    goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_200 = ei + (unsigned int)(1);
    ei = zT_200;
    goto z_bb_43;
    z_bb_47:
    zT_207 = reg->opt_items;
    zT_208 = ty.payload_idx;
    zT_209 = (unsigned int)zT_208;
    zT_210 = zT_207[zT_209];
    p_6 = zT_210;
    zT_211 = ref_edges;
    zT_212 = reg;
    zT_213 = visited;
    zT_214 = src_mid;
    zT_215 = p_6.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_211, zT_212, zT_213, zT_214, zT_215);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_41;
    z_bb_49:
    zT_217 = ty.kind;
    if ((int)(zT_217 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_223 = reg->eu_items;
    zT_224 = ty.payload_idx;
    zT_225 = (unsigned int)zT_224;
    zT_226 = zT_223[zT_225];
    p_7 = zT_226;
    zT_227 = ref_edges;
    zT_228 = reg;
    zT_229 = visited;
    zT_230 = src_mid;
    zT_231 = p_7.payload;
    zF_BC6C7740_pruneTypeMarkByValu(zT_227, zT_228, zT_229, zT_230, zT_231);
    zT_233 = ref_edges;
    zT_234 = reg;
    zT_235 = visited;
    zT_236 = src_mid;
    zT_237 = p_7.error_set;
    zF_BC6C7740_pruneTypeMarkByValu(zT_233, zT_234, zT_235, zT_236, zT_237);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
}

/* phase_C89Emission */
void zF_2268F8CE_phase_C89Emission(zT_5AB29387_CompilerContext* ctx) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_C98AF326_CompilerCli zT_6;
    int zT_7;
    int zT_9;
    zT_C98AF326_CompilerCli zT_10;
    int zT_11;
    zT_CEC2984A_NameMangler_1 zT_14 = {0};
    zT_CA01C129_LirSlotArrayList zT_16;
    unsigned int zT_17;
    zT_E1A783EF_GlobalDeclArrayList zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_25;
    zT_D3EB6303_StringInterner* zT_26;
    zT_3E40CD83_Sand* zT_27;
    unsigned int zT_28;
    zT_69057089_CompilerAlloc* zT_30;
    zT_CEC2984A_NameMangler_1 zT_32 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_33;
    zT_F14DC03E_Opt_287 zT_34;
    zT_72C4E2ED_C89Emitter zT_36 = {0};
    zT_338B7C76_TypeRegistry* zT_37;
    zT_D3EB6303_StringInterner* zT_38;
    zT_CEC2984A_NameMangler_1* zT_39;
    zT_F85C5DED_DiagnosticCollector* zT_40;
    zT_9F514E82_SwitchCaseArrayList* zT_41;
    zT_B687BB96_U32ArrayList* zT_42;
    zT_3E40CD83_Sand* zT_43;
    zT_3E40CD83_Sand* zT_44;
    zT_21D3708C_U32ToU32Map* zT_45;
    unsigned int zT_46;
    int zT_51;
    int zT_52;
    zT_69057089_CompilerAlloc* zT_53;
    zT_69057089_CompilerAlloc* zT_55;
    zT_72C4E2ED_C89Emitter zT_59 = {0};
    zT_072B53A6_ModuleRegistry* zT_60;
    zT_5AB29387_CompilerContext* zT_61;
    zT_E1A783EF_GlobalDeclArrayList* zT_63;
    zT_23133B1E_Slice_zT_54906056_M zT_65 = {0};
    zT_54906056_ModuleGlobalDecl* zT_67;
    unsigned int zT_69;
    zT_7E7544E4_LirStream* zT_71;
    zT_CA01C129_LirSlotArrayList zT_72;
    zT_E7714190_LirSlot* zT_73;
    zT_CA01C129_LirSlotArrayList zT_75;
    unsigned int zT_76;
    zT_69057089_CompilerAlloc* zT_77;
    zT_3E40CD83_Sand* zT_78;
    zT_7E7544E4_LirStream* zT_79;
    zT_3E40CD83_Sand* zT_80;
    zT_69057089_CompilerAlloc* zT_82;
    char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_3E40CD83_Sand* zT_89;
    zT_69057089_CompilerAlloc* zT_90;
    zT_21D3708C_U32ToU32Map zT_92 = {0};
    zT_3E40CD83_Sand* zT_94;
    unsigned int zT_95;
    zT_69057089_CompilerAlloc* zT_96;
    zT_CA01C129_LirSlotArrayList zT_98;
    zT_21D3708C_U32ToU32Map zT_100 = {0};
    zT_3E40CD83_Sand* zT_102;
    zT_69057089_CompilerAlloc* zT_103;
    zT_A4CE86B7_U64ToU32Map zT_105 = {0};
    unsigned int zT_107;
    zT_CA01C129_LirSlotArrayList zT_108;
    unsigned int zT_109;
    zT_7E7544E4_LirStream* zT_112;
    zT_E7714190_LirSlot zT_113;
    zT_3E40CD83_Sand* zT_114;
    zT_CA01C129_LirSlotArrayList zT_116;
    zT_E7714190_LirSlot* zT_117;
    zT_E7714190_LirSlot zT_118;
    zT_69057089_CompilerAlloc* zT_119;
    zT_BBC23664_LirFunction zT_121 = {0};
    unsigned int zT_123;
    unsigned int zT_125;
    zT_5D72FBF8_TempDeclArrayList zT_126;
    unsigned int zT_127;
    zT_5D72FBF8_TempDeclArrayList zT_130;
    zT_1937645B_TempDecl* zT_131;
    zT_1937645B_TempDecl zT_132;
    zT_21D3708C_U32ToU32Map* zT_133;
    zT_338B7C76_TypeRegistry* zT_134;
    zT_A4CE86B7_U64ToU32Map* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_143;
    unsigned int zT_144;
    zT_338B7C76_TypeRegistry* zT_145;
    unsigned int zT_146;
    zT_21D3708C_U32ToU32Map* zT_149;
    zT_338B7C76_TypeRegistry* zT_150;
    zT_A4CE86B7_U64ToU32Map* zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_159;
    zT_CFE23D0A_LirParamArrayList zT_160;
    unsigned int zT_161;
    zT_CFE23D0A_LirParamArrayList zT_164;
    zT_8779209D_LirParam* zT_165;
    zT_8779209D_LirParam zT_166;
    zT_21D3708C_U32ToU32Map* zT_167;
    zT_338B7C76_TypeRegistry* zT_168;
    zT_A4CE86B7_U64ToU32Map* zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned int zT_177;
    unsigned int zT_179;
    zT_1CF28CA3_BasicBlockArrayList zT_180;
    unsigned int zT_181;
    zT_1CF28CA3_BasicBlockArrayList zT_184;
    zT_88A68B1A_BasicBlock* zT_185;
    zT_88A68B1A_BasicBlock zT_186;
    unsigned int zT_188;
    zT_DAE4631D_LirInstArrayList zT_189;
    unsigned int zT_190;
    zT_DAE4631D_LirInstArrayList zT_193;
    zT_6BA597BC_LirInst* zT_194;
    zT_6BA597BC_LirInst zT_195;
    unsigned int zT_197;
    unsigned char zT_199;
    unsigned int zT_201;
    zT_6BA597BC_LirInst zT_204;
    zT_BBC23664_LirFunction* zT_207;
    unsigned int zT_208;
    zT_3BFB1E70_CallDirectData zT_212 = {0};
    unsigned int zT_213;
    unsigned char zT_214;
    zT_6BA597BC_LirInst zT_217;
    zT_BBC23664_LirFunction* zT_220;
    unsigned int zT_221;
    zT_0624AC1B_TailCallData zT_225 = {0};
    unsigned int zT_226;
    unsigned char zT_227;
    zT_6BA597BC_LirInst zT_230;
    zT_0E7FFF0A_anon_50469 zT_233;
    unsigned int zT_234;
    unsigned char zT_235;
    zT_6BA597BC_LirInst zT_238;
    zT_E8A22582_anon_50649 zT_241;
    unsigned int zT_242;
    unsigned char zT_243;
    zT_6BA597BC_LirInst zT_246;
    zT_6A9F2091_anon_50657 zT_249;
    unsigned int zT_250;
    unsigned char zT_251;
    int zT_254;
    zT_21D3708C_U32ToU32Map* zT_256;
    zT_6BA597BC_LirInst zT_266;
    int zT_268;
    zT_6BA597BC_LirInst zT_271;
    unsigned int zT_274;
    unsigned int zT_276;
    zT_6BA597BC_LirInst zT_279;
    zT_E8A22582_anon_50649 zT_282;
    unsigned int zT_283;
    zT_E8A22582_anon_50649 zT_285;
    unsigned int zT_286;
    zT_6A9F2091_anon_50657 zT_288;
    unsigned int zT_289;
    zT_6A9F2091_anon_50657 zT_291;
    unsigned int zT_292;
    unsigned int zT_294;
    unsigned int zT_296;
    zT_5D72FBF8_TempDeclArrayList zT_297;
    unsigned int zT_298;
    zT_5D72FBF8_TempDeclArrayList zT_301;
    zT_1937645B_TempDecl* zT_302;
    zT_1937645B_TempDecl zT_303;
    unsigned int zT_304;
    unsigned int zT_306;
    unsigned int zT_308;
    zT_338B7C76_TypeRegistry* zT_309;
    unsigned int zT_310;
    zT_338B7C76_TypeRegistry* zT_314;
    zT_D155D06D_Type* zT_315;
    unsigned int zT_316;
    zT_D155D06D_Type zT_317;
    unsigned int zT_318;
    int zT_321;
    unsigned int zT_322;
    zT_21D3708C_U32ToU32Map* zT_324;
    unsigned int zT_325;
    unsigned int zT_330;
    unsigned int zT_332;
    unsigned int zT_334;
    zT_072B53A6_ModuleRegistry* zT_336;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_338 = {0};
    unsigned int zT_340;
    unsigned int zT_342;
    zT_6E8D187B_ModuleEntry* zT_344;
    zT_6E8D187B_ModuleEntry zT_345;
    unsigned int zT_346;
    unsigned char zT_350;
    unsigned int zT_352;
    zT_E1A783EF_GlobalDeclArrayList zT_353;
    unsigned int zT_354;
    zT_E1A783EF_GlobalDeclArrayList zT_357;
    zT_54906056_ModuleGlobalDecl* zT_358;
    zT_54906056_ModuleGlobalDecl zT_359;
    unsigned int zT_360;
    zT_6E8D187B_ModuleEntry* zT_361;
    zT_6E8D187B_ModuleEntry zT_362;
    unsigned int zT_363;
    int zT_365;
    unsigned char zT_366;
    unsigned char zT_369;
    unsigned int zT_371;
    zT_21D3708C_U32ToU32Map* zT_374;
    zT_6E8D187B_ModuleEntry* zT_381;
    zT_6E8D187B_ModuleEntry zT_382;
    unsigned int zT_383;
    unsigned int zT_387;
    unsigned int zT_389;
    zT_E1A783EF_GlobalDeclArrayList zT_390;
    unsigned int zT_391;
    zT_E1A783EF_GlobalDeclArrayList zT_394;
    zT_54906056_ModuleGlobalDecl* zT_395;
    zT_54906056_ModuleGlobalDecl zT_396;
    unsigned int zT_397;
    zT_338B7C76_TypeRegistry* zT_398;
    unsigned int zT_399;
    zT_338B7C76_TypeRegistry* zT_403;
    zT_D155D06D_Type* zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    zT_D155D06D_Type zT_407;
    unsigned int zT_408;
    int zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    zT_21D3708C_U32ToU32Map* zT_415;
    zT_338B7C76_TypeRegistry* zT_416;
    zT_A4CE86B7_U64ToU32Map* zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    unsigned int zT_426;
    zT_3E40CD83_Sand* zT_428;
    unsigned int zT_429;
    zT_69057089_CompilerAlloc* zT_430;
    zT_21D3708C_U32ToU32Map zT_434 = {0};
    zT_21D3708C_U32ToU32Map* zT_435;
    unsigned char zT_442;
    unsigned char zT_445;
    unsigned int zT_447;
    unsigned int zT_449;
    zT_6E8D187B_ModuleEntry* zT_452;
    zT_6E8D187B_ModuleEntry zT_453;
    unsigned int zT_454;
    zT_21D3708C_U32ToU32Map* zT_455;
    unsigned int zT_456;
    zT_BAEE192E_Opt_10 zT_458 = {0};
    unsigned char zT_459;
    unsigned int zT_462;
    unsigned int zT_464;
    zT_6E8D187B_ModuleEntry* zT_467;
    zT_6E8D187B_ModuleEntry zT_468;
    unsigned int zT_469;
    zT_21D3708C_U32ToU32Map* zT_471;
    unsigned int zT_472;
    zT_BAEE192E_Opt_10 zT_474 = {0};
    unsigned char zT_475;
    zT_21D3708C_U32ToU32Map* zT_476;
    zT_BAEE192E_Opt_10 zT_482 = {0};
    unsigned char zT_483;
    zT_21D3708C_U32ToU32Map* zT_484;
    unsigned int zT_485;
    unsigned char zT_489;
    unsigned int zT_491;
    unsigned int zT_493;
    zT_C98AF326_CompilerCli zT_494;
    int zT_495;
    unsigned int zT_497;
    unsigned int zT_498;
    zT_21D3708C_U32ToU32Map* zT_500;
    unsigned int zT_501;
    zT_72C4E2ED_C89Emitter* zT_503;
    unsigned int* zT_505;
    unsigned int zT_506;
    int zT_509;
    unsigned int zT_510;
    zT_338B7C76_TypeRegistry* zT_512;
    zT_3E40CD83_Sand* zT_513;
    zT_69057089_CompilerAlloc* zT_515;
    unsigned int* zT_517 = 0;
    zT_846744CC_Arr_unsigned_char_5 zT_519;
    unsigned int zT_521;
    zT_C98AF326_CompilerCli zT_523;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_524;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_525;
    unsigned int zT_527;
    unsigned int zT_529;
    int zT_531;
    unsigned char* zT_534;
    unsigned char zT_535;
    int zT_536;
    unsigned int zT_538;
    int zT_539;
    unsigned int zT_540;
    unsigned char zT_541;
    int zT_542;
    unsigned int zT_544;
    char* zT_546;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_547;
    unsigned int zT_548;
    unsigned int zT_550;
    unsigned int zT_552;
    int zT_554;
    unsigned char* zT_557;
    unsigned char zT_558;
    int zT_559;
    unsigned int zT_561;
    int zT_562;
    unsigned int zT_563;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_565;
    int zT_569;
    unsigned char* zT_570;
    unsigned int zT_571;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_572;
    unsigned int zT_574 = 0;
    char* zT_578;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_579;
    unsigned int zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    zT_63BE4FF5_BufferedWriter zT_585 = {0};
    unsigned int zT_586;
    zT_63BE4FF5_BufferedWriter zT_587 = {0};
    zT_72C4E2ED_C89Emitter* zT_588;
    zT_338B7C76_TypeRegistry* zT_589;
    unsigned int* zT_590;
    zT_63BE4FF5_BufferedWriter* zT_593;
    zT_72C4E2ED_C89Emitter* zT_594;
    unsigned int zT_596;
    zT_072B53A6_ModuleRegistry* zT_598;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_600 = {0};
    unsigned int zT_603;
    unsigned int zT_605;
    unsigned int zT_607;
    zT_6E8D187B_ModuleEntry* zT_610;
    zT_6E8D187B_ModuleEntry zT_611;
    zT_CA01C129_LirSlotArrayList zT_613;
    unsigned int zT_614;
    int zT_616;
    zT_CA01C129_LirSlotArrayList zT_617;
    zT_E7714190_LirSlot* zT_618;
    zT_E7714190_LirSlot zT_619;
    unsigned int zT_620;
    unsigned int zT_621;
    unsigned int zT_624;
    zT_21D3708C_U32ToU32Map* zT_625;
    unsigned int zT_626;
    zT_BAEE192E_Opt_10 zT_629 = {0};
    unsigned char zT_630;
    zT_72C4E2ED_C89Emitter* zT_634;
    unsigned int zT_635;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_638 = {0};
    unsigned int zT_640;
    unsigned int zT_644;
    char* zT_651;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_652;
    unsigned int zT_653;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_654;
    unsigned int zT_658;
    unsigned int zT_660;
    unsigned int zT_662;
    int zT_664;
    unsigned char* zT_667;
    unsigned char zT_668;
    int zT_669;
    unsigned int zT_671;
    int zT_672;
    unsigned int zT_673;
    unsigned char zT_674;
    int zT_675;
    unsigned int zT_677;
    unsigned int zT_679;
    unsigned int zT_681;
    int zT_683;
    unsigned char* zT_686;
    unsigned char zT_687;
    int zT_688;
    unsigned int zT_690;
    int zT_691;
    unsigned int zT_692;
    char* zT_694;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_695;
    unsigned int zT_696;
    unsigned int zT_698;
    unsigned int zT_700;
    int zT_702;
    unsigned char* zT_705;
    unsigned char zT_706;
    int zT_707;
    unsigned int zT_709;
    int zT_710;
    unsigned int zT_711;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_713;
    int zT_717;
    unsigned char* zT_718;
    unsigned int zT_719;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_720;
    unsigned int zT_722 = 0;
    char* zT_726;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_727;
    unsigned int zT_728;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_729;
    zT_63BE4FF5_BufferedWriter zT_733 = {0};
    unsigned int zT_734;
    zT_63BE4FF5_BufferedWriter zT_735 = {0};
    unsigned int zT_737;
    unsigned int zT_738;
    unsigned int zT_740;
    unsigned int zT_742;
    zT_072B53A6_ModuleRegistry* zT_744;
    unsigned int* zT_745;
    unsigned int* zT_746;
    unsigned int zT_747;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_748;
    zT_B687BB96_U32ArrayList zT_750;
    unsigned int* zT_751;
    zT_B687BB96_U32ArrayList zT_752;
    unsigned int zT_753;
    int zT_754;
    unsigned int* zT_755;
    unsigned int zT_756;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_757;
    zT_3E40CD83_Sand* zT_759;
    zT_69057089_CompilerAlloc* zT_762;
    unsigned int zT_766;
    zT_65F39959_EU_322 zT_769 = {0};
    unsigned char zT_770;
    unsigned char* zT_771;
    unsigned int* zT_774;
    unsigned int zT_776;
    unsigned int zT_778;
    unsigned int zT_780;
    unsigned int* zT_783;
    unsigned int zT_784;
    unsigned int zT_785;
    zT_21D3708C_U32ToU32Map* zT_787;
    unsigned int zT_788;
    zT_BAEE192E_Opt_10 zT_790 = {0};
    unsigned char zT_791;
    unsigned char zT_794;
    unsigned int zT_796;
    unsigned int zT_798;
    unsigned char zT_800;
    unsigned int zT_802;
    unsigned int zT_806;
    unsigned int zT_808;
    unsigned int zT_810;
    unsigned int zT_812;
    zT_6E8D187B_ModuleEntry* zT_815;
    zT_6E8D187B_ModuleEntry zT_816;
    unsigned int zT_817;
    unsigned int zT_818;
    zT_21D3708C_U32ToU32Map* zT_820;
    unsigned int zT_821;
    zT_BAEE192E_Opt_10 zT_823 = {0};
    unsigned char zT_824;
    zT_21D3708C_U32ToU32Map* zT_826;
    unsigned int zT_829;
    zT_BAEE192E_Opt_10 zT_833 = {0};
    unsigned char zT_834;
    unsigned char zT_837;
    unsigned int zT_839;
    unsigned int zT_841;
    unsigned char zT_843;
    unsigned int zT_845;
    unsigned int zT_849;
    unsigned int zT_851;
    int zT_853;
    unsigned int* zT_854;
    unsigned int zT_855;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_856;
    zT_72C4E2ED_C89Emitter* zT_857;
    unsigned int zT_858;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_859;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_860;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_861;
    unsigned int* zT_862;
    zT_63BE4FF5_BufferedWriter* zT_865;
    zT_72C4E2ED_C89Emitter* zT_866;
    unsigned int zT_868;
    char* zT_870;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_871;
    unsigned int zT_872;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_873;
    zT_846744CC_Arr_unsigned_char_5 zT_875;
    unsigned int zT_877;
    unsigned int zT_879;
    unsigned int zT_881;
    int zT_883;
    unsigned char* zT_886;
    unsigned char zT_887;
    int zT_888;
    unsigned int zT_890;
    int zT_891;
    unsigned int zT_892;
    unsigned char zT_893;
    int zT_894;
    unsigned int zT_896;
    unsigned int zT_898;
    unsigned int zT_900;
    int zT_902;
    unsigned char* zT_905;
    unsigned char zT_906;
    int zT_907;
    unsigned int zT_909;
    int zT_910;
    unsigned int zT_911;
    char* zT_913;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_914;
    unsigned int zT_915;
    unsigned int zT_917;
    unsigned int zT_919;
    int zT_921;
    unsigned char* zT_924;
    unsigned char zT_925;
    int zT_926;
    unsigned int zT_928;
    int zT_929;
    unsigned int zT_930;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_932;
    int zT_936;
    unsigned char* zT_937;
    unsigned int zT_938;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_939;
    unsigned int zT_941 = 0;
    char* zT_945;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_946;
    unsigned int zT_947;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_948;
    zT_63BE4FF5_BufferedWriter zT_952 = {0};
    unsigned int zT_953;
    zT_63BE4FF5_BufferedWriter zT_954 = {0};
    zT_72C4E2ED_C89Emitter* zT_955;
    unsigned int zT_956;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_957;
    zT_63BE4FF5_BufferedWriter* zT_960;
    zT_72C4E2ED_C89Emitter* zT_961;
    unsigned int zT_963;
    char* zT_965;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_966;
    unsigned int zT_967;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_968;
    int zT_969;
    unsigned int zT_970;
    zT_72C4E2ED_C89Emitter* zT_971;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_972;
    int zT_973;
    zT_C98AF326_CompilerCli zT_975;
    zT_7E7544E4_LirStream* zT_977;
    zT_6B0A7D14_AstStore* zT_979;
    zT_63BE4FF5_BufferedWriter zT_982 = {0};
    zT_63BE4FF5_BufferedWriter zT_983 = {0};
    zT_63BE4FF5_BufferedWriter* zT_984;
    zT_63BE4FF5_BufferedWriter* zT_986;
    zT_072B53A6_ModuleRegistry* zT_989;
    zT_3E40CD83_Sand* zT_990;
    zT_69057089_CompilerAlloc* zT_992;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_994 = {0};
    zT_72C4E2ED_C89Emitter* zT_995;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_996;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_997;
    unsigned int* zT_998;
    unsigned int zT_999;
    char* zT_1004;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1005;
    unsigned int zT_1006;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1007;
    zT_63BE4FF5_BufferedWriter* zT_1008;
    zT_72C4E2ED_C89Emitter* zT_1009;
    zT_7E7544E4_LirStream* zT_1011;
    zT_6B0A7D14_AstStore* zT_1013;
    zT_8F083A69_Slice_zT_0B42B2F8_u p_msg;
    zT_CEC2984A_NameMangler_1 mangler;
    unsigned int mangler_hint;
    zT_72C4E2ED_C89Emitter emitter;
    zT_23133B1E_Slice_zT_54906056_M gd_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u module_name;
    zT_21D3708C_U32ToU32Map ts_ref_set;
    zT_21D3708C_U32ToU32Map ref_edges;
    zT_A4CE86B7_U64ToU32Map type_visited;
    unsigned int ts_fi;
    zT_BBC23664_LirFunction ts_fn;
    unsigned int ts_src;
    unsigned int ts_tti;
    zT_DDCD424B_Slice_zT_6E8D187B_M ri_mods;
    unsigned int ri_i;
    zT_1937645B_TempDecl ts_hty;
    unsigned int ts_pi;
    zT_8779209D_LirParam ts_pt;
    unsigned int ts_bi;
    zT_88A68B1A_BasicBlock ts_blk;
    unsigned int ts_ii;
    zT_6BA597BC_LirInst ts_inst;
    unsigned int ts_tg;
    unsigned char ts_edge_has;
    unsigned int ts_edge_dst;
    zT_3BFB1E70_CallDirectData ts_cd;
    zT_0624AC1B_TailCallData ts_tc;
    unsigned int ts_name_id;
    unsigned int ts_tmp;
    unsigned int ts_tid;
    unsigned int ts_tj;
    zT_1937645B_TempDecl ts_ht;
    zT_D155D06D_Type ts_ty;
    unsigned int gt_i;
    unsigned char ri_has;
    unsigned int gd_ri;
    zT_54906056_ModuleGlobalDecl gd_g;
    zT_54906056_ModuleGlobalDecl gt_g;
    zT_21D3708C_U32ToU32Map reachable;
    unsigned char rf_changed;
    zT_D155D06D_Type gt_ty;
    unsigned int rf_s;
    unsigned int rf_src;
    unsigned int rf_d;
    unsigned int rf_dst;
    unsigned int poi;
    zT_63BE4FF5_BufferedWriter cwriter;
    zT_3CB0179A_Slice_zT_05F374B1_u c_incs;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff_m;
    unsigned int* sorted;
    zT_846744CC_Arr_unsigned_char_5 hpath;
    unsigned int hp;
    zT_8F083A69_Slice_zT_0B42B2F8_u od;
    unsigned int hi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hfn;
    unsigned int hfi;
    unsigned int fd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_63BE4FF5_BufferedWriter hw;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int fn_cursor;
    unsigned int mi;
    zT_6E8D187B_ModuleEntry m;
    unsigned int fn_start;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    zT_8F083A69_Slice_zT_0B42B2F8_u lmsg;
    unsigned int hp2;
    unsigned int hi2;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u hext;
    unsigned int hx;
    unsigned int fd2;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg2;
    zT_63BE4FF5_BufferedWriter hw2;
    unsigned int dep_start;
    unsigned int dep_end;
    zT_3CB0179A_Slice_zT_05F374B1_u dep_ids;
    zT_3CB0179A_Slice_zT_05F374B1_u m_c_incs;
    unsigned char* inc_raw;
    unsigned int* inc_arr;
    unsigned int inc_n;
    unsigned int di0;
    unsigned int dd0;
    unsigned int vd0;
    unsigned char dup0;
    unsigned int dj0;
    unsigned int vdd0;
    zT_3CB0179A_Slice_zT_05F374B1_u inc_slice;
    zT_846744CC_Arr_unsigned_char_5 cpath;
    unsigned int cp2;
    unsigned int ci2;
    unsigned char dup1;
    unsigned int dj1;
    unsigned int cbi;
    zT_8F083A69_Slice_zT_0B42B2F8_u cext;
    unsigned int cx;
    unsigned int cfd;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg3;
    zT_63BE4FF5_BufferedWriter cw;
    zT_8F083A69_Slice_zT_0B42B2F8_u ff2_m;
    zT_2 = "C\n";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    p_msg = zT_3;
    zT_5 = p_msg;
    zF_48AC7B3A_markerWrite(zT_5);
    zT_6 = ctx->cli;
    zT_7 = zT_6.dump_c89;
    if ((int)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = ctx->cli;
    zT_11 = zT_10.output_dir_set;
    zT_9 = !zT_11;
    goto z_bb_3;
    z_bb_2:
    zT_9 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_9) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return;
    z_bb_5:
    mangler = zT_14;
    zT_16 = ctx->lir_slots;
    zT_17 = zT_16.len;
    zT_18 = ctx->global_decls;
    zT_19 = zT_18.len;
    zT_21 = ctx->pointer_only_len;
    zT_25 = (unsigned int)((unsigned int)(zT_17 + zT_19) + (unsigned int)((unsigned int)zT_21)) + (unsigned int)(32);
    mangler_hint = zT_25;
    zT_26 = ctx->interner;
    zT_30 = ctx->alloc;
    zT_27 = &zT_30->emission;
    zT_28 = mangler_hint;
    zT_32 = zF_27DA3900_nameManglerInit_1(zT_26, zT_27, zT_28);
    mangler = zT_32;
    zT_33 = &ctx->exported;
    zT_34.has_value = 1;
    zT_34.value = zT_33;
    mangler.exported = zT_34;
    emitter = zT_36;
    zT_37 = ctx->typereg;
    zT_38 = ctx->interner;
    zT_39 = &mangler;
    zT_40 = ctx->diag;
    zT_51 = 0;
    zT_41 = (zT_9F514E82_SwitchCaseArrayList*)zT_51;
    zT_52 = 0;
    zT_42 = (zT_B687BB96_U32ArrayList*)zT_52;
    zT_53 = ctx->alloc;
    zT_43 = &zT_53->scratch;
    zT_55 = ctx->alloc;
    zT_44 = &zT_55->emission;
    zT_45 = &ctx->error_code_registry;
    zT_46 = ctx->pointer_only_len;
    zT_59 = zF_63D58A2B_c89EmitterInit(zT_37, zT_38, zT_39, zT_40, zT_41, zT_42, zT_43, zT_44, zT_45, zT_46);
    emitter = zT_59;
    zT_60 = ctx->module_reg;
    emitter.module_reg = zT_60;
    zT_61 = ctx;
    zF_FC691B4D_errorCodeRegistryFi(zT_61);
    zT_63 = &ctx->global_decls;
    zT_65 = zF_6ACCE52D_globalDeclArrayList(zT_63);
    gd_slice = zT_65;
    zT_67 = gd_slice.ptr;
    emitter.global_decls = zT_67;
    zT_69 = gd_slice.len;
    emitter.global_decls_len = (unsigned int)((unsigned int)zT_69);
    zT_71 = &ctx->lir_stream;
    emitter.spill = zT_71;
    zT_72 = ctx->lir_slots;
    zT_73 = zT_72.items;
    emitter.fn_slots = zT_73;
    emitter.fn_slots_start = (unsigned int)(0);
    zT_75 = ctx->lir_slots;
    zT_76 = zT_75.len;
    emitter.fn_slots_len = zT_76;
    zT_77 = ctx->alloc;
    zT_78 = &zT_77->lir_read;
    emitter.spill_arena = zT_78;
    zT_79 = &ctx->lir_stream;
    zT_82 = ctx->alloc;
    zT_80 = &zT_82->emission;
    zF_72DA7B39_lirStreamBeginRead(zT_79, zT_80);
    zT_85 = "output";
    zT_87 = 6;
    zT_86.ptr = zT_85;
    zT_86.len = zT_87;
    module_name = zT_86;
    zT_90 = ctx->alloc;
    zT_89 = &zT_90->emission;
    zT_92 = zF_58BDA2DE_u32ToU32MapInit(zT_89);
    ts_ref_set = zT_92;
    zT_96 = ctx->alloc;
    zT_94 = &zT_96->emission;
    zT_98 = ctx->lir_slots;
    zT_95 = zT_98.len;
    zT_100 = zF_619D56E6_u32ToU32MapInitCap(zT_94, zT_95);
    ref_edges = zT_100;
    zT_103 = ctx->alloc;
    zT_102 = &zT_103->emission;
    zT_105 = zF_986226E1_u64ToU32MapInit(zT_102);
    type_visited = zT_105;
    zT_107 = 0;
    ts_fi = zT_107;
    goto z_bb_6;
    z_bb_6:
    zT_108 = ctx->lir_slots;
    zT_109 = zT_108.len;
    if ((int)(ts_fi < zT_109)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_112 = &ctx->lir_stream;
    zT_116 = ctx->lir_slots;
    zT_117 = zT_116.items;
    zT_118 = zT_117[ts_fi];
    zT_113 = zT_118;
    zT_119 = ctx->alloc;
    zT_114 = &zT_119->lir_read;
    zT_121 = zF_1B7118E0_lirStreamReadFuncti(zT_112, zT_113, zT_114);
    ts_fn = zT_121;
    zT_123 = ts_fn.module_id;
    ts_src = zT_123;
    zT_125 = 0;
    ts_tti = zT_125;
    goto z_bb_10;
    z_bb_8:
    emitter.ts_ref_set = ts_ref_set;
    zT_336 = ctx->module_reg;
    zT_338 = zF_3452C137_moduleRegistryGetMo(zT_336);
    ri_mods = zT_338;
    zT_340 = 0;
    ri_i = zT_340;
    goto z_bb_68;
    z_bb_9:
    zT_334 = ts_fi + (unsigned int)(1);
    ts_fi = zT_334;
    goto z_bb_6;
    z_bb_10:
    zT_126 = ts_fn.hoisted_temps;
    zT_127 = zT_126.len;
    if ((int)(ts_tti < zT_127)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_130 = ts_fn.hoisted_temps;
    zT_131 = zT_130.items;
    zT_132 = zT_131[ts_tti];
    ts_hty = zT_132;
    zT_133 = &ref_edges;
    zT_134 = ctx->typereg;
    zT_135 = &type_visited;
    zT_136 = ts_src;
    zT_137 = ts_hty.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_133, zT_134, zT_135, zT_136, zT_137);
    goto z_bb_13;
    z_bb_12:
    zT_144 = ts_fn.return_type;
    zT_145 = ctx->typereg;
    zT_146 = zT_145->types_len;
    if ((int)(zT_144 < (unsigned int)((unsigned int)zT_146))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_143 = ts_tti + (unsigned int)(1);
    ts_tti = zT_143;
    goto z_bb_10;
    z_bb_14:
    zT_149 = &ref_edges;
    zT_150 = ctx->typereg;
    zT_151 = &type_visited;
    zT_152 = ts_src;
    zT_153 = ts_fn.return_type;
    zF_BC6C7740_pruneTypeMarkByValu(zT_149, zT_150, zT_151, zT_152, zT_153);
    goto z_bb_15;
    z_bb_15:
    zT_159 = 0;
    ts_pi = zT_159;
    goto z_bb_16;
    z_bb_16:
    zT_160 = ts_fn.params;
    zT_161 = zT_160.len;
    if ((int)(ts_pi < zT_161)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_164 = ts_fn.params;
    zT_165 = zT_164.items;
    zT_166 = zT_165[ts_pi];
    ts_pt = zT_166;
    zT_167 = &ref_edges;
    zT_168 = ctx->typereg;
    zT_169 = &type_visited;
    zT_170 = ts_src;
    zT_171 = ts_pt.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_167, zT_168, zT_169, zT_170, zT_171);
    goto z_bb_19;
    z_bb_18:
    zT_179 = 0;
    ts_bi = zT_179;
    goto z_bb_20;
    z_bb_19:
    zT_177 = ts_pi + (unsigned int)(1);
    ts_pi = zT_177;
    goto z_bb_16;
    z_bb_20:
    zT_180 = ts_fn.blocks;
    zT_181 = zT_180.len;
    if ((int)(ts_bi < zT_181)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_184 = ts_fn.blocks;
    zT_185 = zT_184.items;
    zT_186 = zT_185[ts_bi];
    ts_blk = zT_186;
    zT_188 = 0;
    ts_ii = zT_188;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_9;
    z_bb_23:
    zT_332 = ts_bi + (unsigned int)(1);
    ts_bi = zT_332;
    goto z_bb_20;
    z_bb_24:
    zT_189 = ts_blk.insts;
    zT_190 = zT_189.len;
    if ((int)(ts_ii < zT_190)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_193 = ts_blk.insts;
    zT_194 = zT_193.items;
    zT_195 = zT_194[ts_ii];
    ts_inst = zT_195;
    zT_197 = ts_inst.tag;
    ts_tg = zT_197;
    zT_199 = 0;
    ts_edge_has = zT_199;
    zT_201 = 0;
    ts_edge_dst = zT_201;
    zT_204.tag = 23;
    if ((int)(ts_tg == zT_204.tag)) goto z_bb_28; else goto z_bb_30;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_330 = ts_ii + (unsigned int)(1);
    ts_ii = zT_330;
    goto z_bb_24;
    z_bb_28:
    zT_207 = &ts_fn;
    zT_208 = ts_inst.payload.jump._0;
    zT_212 = zF_75DE985C_lirSideGetCallDirec(zT_207, zT_208);
    ts_cd = zT_212;
    zT_213 = ts_cd.module_id;
    ts_edge_dst = zT_213;
    zT_214 = 1;
    ts_edge_has = zT_214;
    goto z_bb_29;
    z_bb_29:
    if ((int)(ts_edge_has != (unsigned char)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_30:
    zT_217.tag = 27;
    if ((int)(ts_tg == zT_217.tag)) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_220 = &ts_fn;
    zT_221 = ts_inst.payload.jump._0;
    zT_225 = zF_1AB3807F_lirSideGetTailCall(zT_220, zT_221);
    ts_tc = zT_225;
    zT_226 = ts_tc.module_id;
    ts_edge_dst = zT_226;
    zT_227 = 1;
    ts_edge_has = zT_227;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_230.tag = 28;
    if ((int)(ts_tg == zT_230.tag)) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_233 = ts_inst.payload.func_ref._0;
    zT_234 = zT_233.module_id;
    ts_edge_dst = zT_234;
    zT_235 = 1;
    ts_edge_has = zT_235;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_238.tag = 54;
    if ((int)(ts_tg == zT_238.tag)) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_241 = ts_inst.payload.load_global._0;
    zT_242 = zT_241.module_id;
    ts_edge_dst = zT_242;
    zT_243 = 1;
    ts_edge_has = zT_243;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_246.tag = 55;
    if ((int)(ts_tg == zT_246.tag)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_249 = ts_inst.payload.store_global._0;
    zT_250 = zT_249.module_id;
    ts_edge_dst = zT_250;
    zT_251 = 1;
    ts_edge_has = zT_251;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_254 = ts_edge_dst != ts_src;
    goto z_bb_44;
    z_bb_43:
    zT_254 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_254) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_256 = &ref_edges;
    zF_26476265_u32ToU32MapPut(zT_256, (unsigned int)((unsigned int)(ts_src * (unsigned int)(65536)) + ts_edge_dst), (unsigned int)(1));
    goto z_bb_46;
    z_bb_46:
    zT_266.tag = 54;
    if ((int)(ts_tg != zT_266.tag)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_271.tag = 55;
    zT_268 = ts_tg != zT_271.tag;
    goto z_bb_49;
    z_bb_48:
    zT_268 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_268) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    goto z_bb_27;
    z_bb_51:
    zT_274 = 0;
    ts_name_id = zT_274;
    zT_276 = 0;
    ts_tmp = zT_276;
    zT_279.tag = 54;
    if ((int)(ts_tg == zT_279.tag)) goto z_bb_52; else goto z_bb_54;
    z_bb_52:
    zT_282 = ts_inst.payload.load_global._0;
    zT_283 = zT_282.name_id;
    ts_name_id = zT_283;
    zT_285 = ts_inst.payload.load_global._0;
    zT_286 = zT_285.result;
    ts_tmp = zT_286;
    goto z_bb_53;
    z_bb_53:
    zT_294 = 0;
    ts_tid = zT_294;
    zT_296 = 0;
    ts_tj = zT_296;
    goto z_bb_55;
    z_bb_54:
    zT_288 = ts_inst.payload.store_global._0;
    zT_289 = zT_288.name_id;
    ts_name_id = zT_289;
    zT_291 = ts_inst.payload.store_global._0;
    zT_292 = zT_291.value;
    ts_tmp = zT_292;
    goto z_bb_53;
    z_bb_55:
    zT_297 = ts_fn.hoisted_temps;
    zT_298 = zT_297.len;
    if ((int)(ts_tj < zT_298)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_301 = ts_fn.hoisted_temps;
    zT_302 = zT_301.items;
    zT_303 = zT_302[ts_tj];
    ts_ht = zT_303;
    zT_304 = ts_ht.temp_id;
    if ((int)(zT_304 == ts_tmp)) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_309 = ctx->typereg;
    zT_310 = zT_309->types_len;
    if ((int)(ts_tid >= (unsigned int)((unsigned int)zT_310))) goto z_bb_61; else goto z_bb_62;
    z_bb_58:
    zT_308 = ts_tj + (unsigned int)(1);
    ts_tj = zT_308;
    goto z_bb_55;
    z_bb_59:
    zT_306 = ts_ht.type_id;
    ts_tid = zT_306;
    goto z_bb_57;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    goto z_bb_27;
    z_bb_62:
    zT_314 = ctx->typereg;
    zT_315 = zT_314->types_items;
    zT_316 = (unsigned int)ts_tid;
    zT_317 = zT_315[zT_316];
    ts_ty = zT_317;
    zT_318 = ts_ty.name_id;
    if ((int)(zT_318 != (unsigned int)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_322 = ts_ty.name_id;
    zT_321 = zT_322 == ts_name_id;
    goto z_bb_65;
    z_bb_64:
    zT_321 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_321) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_324 = &ts_ref_set;
    zT_325 = ts_tid;
    zF_26476265_u32ToU32MapPut(zT_324, zT_325, (unsigned int)(1));
    goto z_bb_67;
    z_bb_67:
    goto z_bb_27;
    z_bb_68:
    zT_342 = ri_mods.len;
    if ((int)(ri_i < zT_342)) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_344 = ri_mods.ptr;
    zT_345 = zT_344[ri_i];
    zT_346 = zT_345.id;
    if ((int)(zT_346 == (unsigned int)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_70:
    zT_389 = 0;
    gt_i = zT_389;
    goto z_bb_85;
    z_bb_71:
    zT_387 = ri_i + (unsigned int)(1);
    ri_i = zT_387;
    goto z_bb_68;
    z_bb_72:
    goto z_bb_71;
    z_bb_73:
    zT_350 = 0;
    ri_has = zT_350;
    zT_352 = 0;
    gd_ri = zT_352;
    goto z_bb_74;
    z_bb_74:
    zT_353 = ctx->global_decls;
    zT_354 = zT_353.len;
    if ((int)(gd_ri < zT_354)) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_357 = ctx->global_decls;
    zT_358 = zT_357.items;
    zT_359 = zT_358[gd_ri];
    gd_g = zT_359;
    zT_360 = gd_g.module_id;
    zT_361 = ri_mods.ptr;
    zT_362 = zT_361[ri_i];
    zT_363 = zT_362.id;
    if ((int)(zT_360 == zT_363)) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    if ((int)(ri_has != (unsigned char)(0))) goto z_bb_83; else goto z_bb_84;
    z_bb_77:
    zT_371 = gd_ri + (unsigned int)(1);
    gd_ri = zT_371;
    goto z_bb_74;
    z_bb_78:
    zT_366 = gd_g.has_runtime_init;
    zT_365 = zT_366 != (unsigned char)(0);
    goto z_bb_80;
    z_bb_79:
    zT_365 = 0;
    goto z_bb_80;
    z_bb_80:
    if (zT_365) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_369 = 1;
    ri_has = zT_369;
    goto z_bb_76;
    z_bb_82:
    goto z_bb_77;
    z_bb_83:
    zT_374 = &ref_edges;
    zT_381 = ri_mods.ptr;
    zT_382 = zT_381[ri_i];
    zT_383 = zT_382.id;
    zF_26476265_u32ToU32MapPut(zT_374, (unsigned int)((unsigned int)(0) + zT_383), (unsigned int)(1));
    goto z_bb_84;
    z_bb_84:
    goto z_bb_71;
    z_bb_85:
    zT_390 = ctx->global_decls;
    zT_391 = zT_390.len;
    if ((int)(gt_i < zT_391)) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_394 = ctx->global_decls;
    zT_395 = zT_394.items;
    zT_396 = zT_395[gt_i];
    gt_g = zT_396;
    zT_397 = gt_g.type_id;
    zT_398 = ctx->typereg;
    zT_399 = zT_398->types_len;
    if ((int)(zT_397 >= (unsigned int)((unsigned int)zT_399))) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    zT_430 = ctx->alloc;
    zT_428 = &zT_430->emission;
    zT_429 = ri_mods.len;
    zT_434 = zF_619D56E6_u32ToU32MapInitCap(zT_428, zT_429);
    reachable = zT_434;
    zT_435 = &reachable;
    zF_26476265_u32ToU32MapPut(zT_435, (unsigned int)(0), (unsigned int)(1));
    zT_442 = 1;
    rf_changed = zT_442;
    goto z_bb_96;
    z_bb_88:
    zT_426 = gt_i + (unsigned int)(1);
    gt_i = zT_426;
    goto z_bb_85;
    z_bb_89:
    goto z_bb_88;
    z_bb_90:
    zT_403 = ctx->typereg;
    zT_404 = zT_403->types_items;
    zT_405 = gt_g.type_id;
    zT_406 = (unsigned int)zT_405;
    zT_407 = zT_404[zT_406];
    gt_ty = zT_407;
    zT_408 = gt_ty.name_id;
    if ((int)(zT_408 != (unsigned int)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_412 = gt_ty.name_id;
    zT_413 = gt_g.name_id;
    zT_411 = zT_412 == zT_413;
    goto z_bb_93;
    z_bb_92:
    zT_411 = 0;
    goto z_bb_93;
    z_bb_93:
    if (zT_411) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    goto z_bb_88;
    z_bb_95:
    zT_415 = &ref_edges;
    zT_416 = ctx->typereg;
    zT_417 = &type_visited;
    zT_418 = gt_g.module_id;
    zT_419 = gt_g.type_id;
    zF_BC6C7740_pruneTypeMarkByValu(zT_415, zT_416, zT_417, zT_418, zT_419);
    goto z_bb_88;
    z_bb_96:
    if ((int)(rf_changed != (unsigned char)(0))) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_445 = 0;
    rf_changed = zT_445;
    zT_447 = 0;
    rf_s = zT_447;
    goto z_bb_100;
    z_bb_98:
    emitter.reachable = reachable;
    zT_494 = ctx->cli;
    zT_495 = zT_494.output_dir_set;
    if (zT_495) goto z_bb_116; else goto z_bb_117;
    z_bb_99:
    goto z_bb_96;
    z_bb_100:
    zT_449 = ri_mods.len;
    if ((int)(rf_s < zT_449)) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_452 = ri_mods.ptr;
    zT_453 = zT_452[rf_s];
    zT_454 = zT_453.id;
    rf_src = zT_454;
    zT_455 = &reachable;
    zT_456 = rf_src;
    zT_458 = zF_F3EE5998_u32ToU32MapGet(zT_455, zT_456);
    zT_459 = zT_458.has_value;
    if ((int)(!zT_459)) goto z_bb_104; else goto z_bb_105;
    z_bb_102:
    goto z_bb_99;
    z_bb_103:
    zT_493 = rf_s + (unsigned int)(1);
    rf_s = zT_493;
    goto z_bb_100;
    z_bb_104:
    goto z_bb_103;
    z_bb_105:
    zT_462 = 0;
    rf_d = zT_462;
    goto z_bb_106;
    z_bb_106:
    zT_464 = ri_mods.len;
    if ((int)(rf_d < zT_464)) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_467 = ri_mods.ptr;
    zT_468 = zT_467[rf_d];
    zT_469 = zT_468.id;
    rf_dst = zT_469;
    if ((int)(rf_dst == rf_src)) goto z_bb_110; else goto z_bb_111;
    z_bb_108:
    goto z_bb_103;
    z_bb_109:
    zT_491 = rf_d + (unsigned int)(1);
    rf_d = zT_491;
    goto z_bb_106;
    z_bb_110:
    goto z_bb_109;
    z_bb_111:
    zT_471 = &reachable;
    zT_472 = rf_dst;
    zT_474 = zF_F3EE5998_u32ToU32MapGet(zT_471, zT_472);
    zT_475 = zT_474.has_value;
    if (zT_475) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    goto z_bb_109;
    z_bb_113:
    zT_476 = &ref_edges;
    zT_482 = zF_F3EE5998_u32ToU32MapGet(zT_476, (unsigned int)((unsigned int)(rf_src * (unsigned int)(65536)) + rf_dst));
    zT_483 = zT_482.has_value;
    if (zT_483) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_484 = &reachable;
    zT_485 = rf_dst;
    zF_26476265_u32ToU32MapPut(zT_484, zT_485, (unsigned int)(1));
    zT_489 = 1;
    rf_changed = zT_489;
    goto z_bb_115;
    z_bb_115:
    goto z_bb_109;
    z_bb_116:
    zT_497 = 0;
    poi = zT_497;
    goto z_bb_118;
    z_bb_117:
    cwriter = zT_982;
    zT_983 = zF_F9E678C3_bufferedWriterInit();
    cwriter = zT_983;
    zT_984 = &cwriter;
    zF_225796FB_emitIncludes(zT_984);
    zT_986 = &cwriter;
    zF_B35650AD_bufferedWriterFlush(zT_986);
    zT_989 = ctx->module_reg;
    zT_992 = ctx->alloc;
    zT_990 = &zT_992->emission;
    zT_994 = zF_1E2E8788_cincludeUnionAll(zT_989, zT_990);
    c_incs = zT_994;
    zT_995 = &emitter;
    zT_996 = module_name;
    zT_997 = c_incs;
    zT_998 = ctx->pointer_only_ids;
    zT_999 = ctx->pointer_only_len;
    zF_503E3056_emitModule(zT_995, zT_996, zT_997, zT_998, zT_999);
    zT_1004 = "FINAL_FLUSH\n";
    zT_1006 = 12;
    zT_1005.ptr = zT_1004;
    zT_1005.len = zT_1006;
    ff_m = zT_1005;
    zT_1007 = ff_m;
    zF_48AC7B3A_markerWrite(zT_1007);
    zT_1009 = &emitter;
    zT_1008 = &zT_1009->writer;
    zF_B35650AD_bufferedWriterFlush(zT_1008);
    zT_1011 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_1011);
    zT_1013 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_1013);
    return;
    z_bb_118:
    zT_498 = ctx->pointer_only_len;
    if ((int)(poi < zT_498)) goto z_bb_119; else goto z_bb_120;
    z_bb_119:
    zT_503 = &emitter;
    zT_500 = &zT_503->pointer_only_map;
    zT_505 = ctx->pointer_only_ids;
    zT_506 = (unsigned int)poi;
    zT_501 = zT_505[zT_506];
    zF_26476265_u32ToU32MapPut(zT_500, zT_501, (unsigned int)(1));
    goto z_bb_121;
    z_bb_120:
    zT_512 = ctx->typereg;
    zT_515 = ctx->alloc;
    zT_513 = &zT_515->emission;
    zT_517 = zF_1DD26D63_tstTopologicalSort(zT_512, zT_513);
    sorted = zT_517;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_519[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        hpath[_i] = zT_519[_i];
        _i++;
    }
}
    zT_521 = 0;
    hp = zT_521;
    zT_523 = ctx->cli;
    zT_524 = zT_523.output_dir;
    od = zT_524;
    zT_525 = od;
    zF_AB1E9CD4_emitSupportFiles(zT_525);
    zT_527 = 0;
    hi = zT_527;
    goto z_bb_122;
    z_bb_121:
    zT_509 = 1;
    zT_510 = poi + zT_509;
    poi = zT_510;
    goto z_bb_118;
    z_bb_122:
    zT_529 = od.len;
    if ((int)(hi < zT_529)) goto z_bb_126; else goto z_bb_127;
    z_bb_123:
    zT_534 = od.ptr;
    zT_535 = zT_534[hi];
    hpath[hp] = zT_535;
    zT_536 = 1;
    zT_538 = hp + (unsigned int)((unsigned int)zT_536);
    hp = zT_538;
    goto z_bb_125;
    z_bb_124:
    zT_541 = 47;
    hpath[hp] = zT_541;
    zT_542 = 1;
    zT_544 = hp + (unsigned int)((unsigned int)zT_542);
    hp = zT_544;
    zT_546 = "zig_special_types.h";
    zT_548 = 19;
    zT_547.ptr = zT_546;
    zT_547.len = zT_548;
    hfn = zT_547;
    zT_550 = 0;
    hfi = zT_550;
    goto z_bb_129;
    z_bb_125:
    zT_539 = 1;
    zT_540 = hi + zT_539;
    hi = zT_540;
    goto z_bb_122;
    z_bb_126:
    zT_531 = hp < (unsigned int)(510);
    goto z_bb_128;
    z_bb_127:
    zT_531 = 0;
    goto z_bb_128;
    z_bb_128:
    if (zT_531) goto z_bb_123; else goto z_bb_124;
    z_bb_129:
    zT_552 = hfn.len;
    if ((int)(hfi < zT_552)) goto z_bb_133; else goto z_bb_134;
    z_bb_130:
    zT_557 = hfn.ptr;
    zT_558 = zT_557[hfi];
    hpath[hp] = zT_558;
    zT_559 = 1;
    zT_561 = hp + (unsigned int)((unsigned int)zT_559);
    hp = zT_561;
    goto z_bb_132;
    z_bb_131:
    zT_569 = 0;
    zT_570 = (unsigned char*)((unsigned char*)hpath) + zT_569;
    zT_571 = hp - zT_569;
    zT_572.ptr = zT_570;
    zT_572.len = zT_571;
    zT_565 = zT_572;
    zT_574 = zF_39FE21EF_fileOpen(zT_565, (int)(0));
    fd = zT_574;
    if ((int)(fd == zG_CC81CC5F_INVALID_FD)) goto z_bb_136; else goto z_bb_137;
    z_bb_132:
    zT_562 = 1;
    zT_563 = hfi + zT_562;
    hfi = zT_563;
    goto z_bb_129;
    z_bb_133:
    zT_554 = hp < (unsigned int)(511);
    goto z_bb_135;
    z_bb_134:
    zT_554 = 0;
    goto z_bb_135;
    z_bb_135:
    if (zT_554) goto z_bb_130; else goto z_bb_131;
    z_bb_136:
    zT_578 = "error: cannot open output file\n";
    zT_580 = 31;
    zT_579.ptr = zT_578;
    zT_579.len = zT_580;
    emsg = zT_579;
    zT_581 = emsg;
    zF_E4B2EF19_stderr_write(zT_581);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_137;
    z_bb_137:
    hw = zT_585;
    zT_586 = fd;
    zT_587 = zF_E00097E1_bufferedWriterInitF(zT_586);
    hw = zT_587;
    emitter.writer = hw;
    zT_588 = &emitter;
    zT_589 = ctx->typereg;
    zT_590 = sorted;
    zF_62841416_emitSharedHeader(zT_588, zT_589, zT_590);
    zT_594 = &emitter;
    zT_593 = &zT_594->writer;
    zF_B35650AD_bufferedWriterFlush(zT_593);
    zT_596 = fd;
    zF_B30B1D79_fileClose(zT_596);
    zT_598 = ctx->module_reg;
    zT_600 = zF_3452C137_moduleRegistryGetMo(zT_598);
    mods = zT_600;
    emitter.prune_active = (unsigned char)(1);
    zT_603 = 0;
    fn_cursor = zT_603;
    zT_605 = 0;
    mi = zT_605;
    goto z_bb_138;
    z_bb_138:
    zT_607 = mods.len;
    if ((int)(mi < zT_607)) goto z_bb_139; else goto z_bb_140;
    z_bb_139:
    zT_610 = mods.ptr;
    zT_611 = zT_610[mi];
    m = zT_611;
    fn_start = fn_cursor;
    goto z_bb_142;
    z_bb_140:
    zT_971 = &emitter;
    zT_972 = od;
    zT_975 = ctx->cli;
    zT_973 = zT_975.target_is_windows;
    zF_A62DB57E_emitBuildScripts(zT_971, zT_972, zT_973);
    zT_977 = &ctx->lir_stream;
    zF_9427AE59_lirStreamEndRead(zT_977);
    zT_979 = ctx->store;
    zF_21027FAE_astStoreCloseSpill(zT_979);
    return;
    z_bb_141:
    zT_969 = 1;
    zT_970 = mi + zT_969;
    mi = zT_970;
    goto z_bb_138;
    z_bb_142:
    zT_613 = ctx->lir_slots;
    zT_614 = zT_613.len;
    if ((int)(fn_cursor < zT_614)) goto z_bb_146; else goto z_bb_147;
    z_bb_143:
    goto z_bb_145;
    z_bb_144:
    zT_625 = &reachable;
    zT_626 = m.id;
    zT_629 = zF_F3EE5998_u32ToU32MapGet(zT_625, zT_626);
    zT_630 = zT_629.has_value;
    if ((int)(!zT_630)) goto z_bb_149; else goto z_bb_150;
    z_bb_145:
    zT_624 = fn_cursor + (unsigned int)(1);
    fn_cursor = zT_624;
    goto z_bb_142;
    z_bb_146:
    zT_617 = ctx->lir_slots;
    zT_618 = zT_617.items;
    zT_619 = zT_618[fn_cursor];
    zT_620 = zT_619.module_id;
    zT_621 = m.id;
    zT_616 = zT_620 == zT_621;
    goto z_bb_148;
    z_bb_147:
    zT_616 = 0;
    goto z_bb_148;
    z_bb_148:
    if (zT_616) goto z_bb_143; else goto z_bb_144;
    z_bb_149:
    goto z_bb_141;
    z_bb_150:
    emitter.fn_slots_start = fn_start;
    emitter.fn_slots_len = (unsigned int)(fn_cursor - fn_start);
    zT_634 = &emitter;
    zT_635 = m.id;
    zT_638 = zF_E295413A_moduleQualifiedName(zT_634, zT_635);
    base = zT_638;
    zT_640 = od.len;
    zT_644 = base.len;
    if ((int)((unsigned int)((unsigned int)((unsigned int)(zT_640 + (unsigned int)(1)) + zT_644) + (unsigned int)(3)) > (unsigned int)(511))) goto z_bb_151; else goto z_bb_152;
    z_bb_151:
    zT_651 = "error: output filename too long\n";
    zT_653 = 32;
    zT_652.ptr = zT_651;
    zT_652.len = zT_653;
    lmsg = zT_652;
    zT_654 = lmsg;
    zF_E4B2EF19_stderr_write(zT_654);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_152;
    z_bb_152:
    zT_658 = 0;
    hp2 = zT_658;
    zT_660 = 0;
    hi2 = zT_660;
    goto z_bb_153;
    z_bb_153:
    zT_662 = od.len;
    if ((int)(hi2 < zT_662)) goto z_bb_157; else goto z_bb_158;
    z_bb_154:
    zT_667 = od.ptr;
    zT_668 = zT_667[hi2];
    hpath[hp2] = zT_668;
    zT_669 = 1;
    zT_671 = hp2 + (unsigned int)((unsigned int)zT_669);
    hp2 = zT_671;
    goto z_bb_156;
    z_bb_155:
    zT_674 = 47;
    hpath[hp2] = zT_674;
    zT_675 = 1;
    zT_677 = hp2 + (unsigned int)((unsigned int)zT_675);
    hp2 = zT_677;
    zT_679 = 0;
    bi = zT_679;
    goto z_bb_160;
    z_bb_156:
    zT_672 = 1;
    zT_673 = hi2 + zT_672;
    hi2 = zT_673;
    goto z_bb_153;
    z_bb_157:
    zT_664 = hp2 < (unsigned int)(510);
    goto z_bb_159;
    z_bb_158:
    zT_664 = 0;
    goto z_bb_159;
    z_bb_159:
    if (zT_664) goto z_bb_154; else goto z_bb_155;
    z_bb_160:
    zT_681 = base.len;
    if ((int)(bi < zT_681)) goto z_bb_164; else goto z_bb_165;
    z_bb_161:
    zT_686 = base.ptr;
    zT_687 = zT_686[bi];
    hpath[hp2] = zT_687;
    zT_688 = 1;
    zT_690 = hp2 + (unsigned int)((unsigned int)zT_688);
    hp2 = zT_690;
    goto z_bb_163;
    z_bb_162:
    zT_694 = ".h";
    zT_696 = 2;
    zT_695.ptr = zT_694;
    zT_695.len = zT_696;
    hext = zT_695;
    zT_698 = 0;
    hx = zT_698;
    goto z_bb_167;
    z_bb_163:
    zT_691 = 1;
    zT_692 = bi + zT_691;
    bi = zT_692;
    goto z_bb_160;
    z_bb_164:
    zT_683 = hp2 < (unsigned int)(510);
    goto z_bb_166;
    z_bb_165:
    zT_683 = 0;
    goto z_bb_166;
    z_bb_166:
    if (zT_683) goto z_bb_161; else goto z_bb_162;
    z_bb_167:
    zT_700 = hext.len;
    if ((int)(hx < zT_700)) goto z_bb_171; else goto z_bb_172;
    z_bb_168:
    zT_705 = hext.ptr;
    zT_706 = zT_705[hx];
    hpath[hp2] = zT_706;
    zT_707 = 1;
    zT_709 = hp2 + (unsigned int)((unsigned int)zT_707);
    hp2 = zT_709;
    goto z_bb_170;
    z_bb_169:
    zT_717 = 0;
    zT_718 = (unsigned char*)((unsigned char*)hpath) + zT_717;
    zT_719 = hp2 - zT_717;
    zT_720.ptr = zT_718;
    zT_720.len = zT_719;
    zT_713 = zT_720;
    zT_722 = zF_39FE21EF_fileOpen(zT_713, (int)(0));
    fd2 = zT_722;
    if ((int)(fd2 == zG_CC81CC5F_INVALID_FD)) goto z_bb_174; else goto z_bb_175;
    z_bb_170:
    zT_710 = 1;
    zT_711 = hx + zT_710;
    hx = zT_711;
    goto z_bb_167;
    z_bb_171:
    zT_702 = hp2 < (unsigned int)(511);
    goto z_bb_173;
    z_bb_172:
    zT_702 = 0;
    goto z_bb_173;
    z_bb_173:
    if (zT_702) goto z_bb_168; else goto z_bb_169;
    z_bb_174:
    zT_726 = "error: cannot open output file\n";
    zT_728 = 31;
    zT_727.ptr = zT_726;
    zT_727.len = zT_728;
    emsg2 = zT_727;
    zT_729 = emsg2;
    zF_E4B2EF19_stderr_write(zT_729);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_175;
    z_bb_175:
    hw2 = zT_733;
    zT_734 = fd2;
    zT_735 = zF_E00097E1_bufferedWriterInitF(zT_734);
    hw2 = zT_735;
    emitter.writer = hw2;
    zT_737 = m.imports_start;
    zT_738 = (unsigned int)zT_737;
    dep_start = zT_738;
    zT_740 = m.import_count;
    zT_742 = dep_start + (unsigned int)((unsigned int)zT_740);
    dep_end = zT_742;
    zT_744 = ctx->module_reg;
    zT_745 = zT_744->import_edges_items;
    zT_746 = zT_745 + dep_start;
    zT_747 = dep_end - dep_start;
    zT_748.ptr = zT_746;
    zT_748.len = zT_747;
    dep_ids = zT_748;
    zT_750 = m.c_includes;
    zT_751 = zT_750.items;
    zT_752 = m.c_includes;
    zT_753 = zT_752.len;
    zT_754 = 0;
    zT_755 = zT_751 + zT_754;
    zT_756 = zT_753 - zT_754;
    zT_757.ptr = zT_755;
    zT_757.len = zT_756;
    m_c_incs = zT_757;
    zT_762 = ctx->alloc;
    zT_759 = &zT_762->emission;
    zT_766 = mods.len;
    zT_769 = zF_1395EB68_sandAlloc(zT_759, (unsigned int)((unsigned int)(4) * zT_766), (unsigned int)(4));
    zT_770 = zT_769.is_error;
    if (zT_770) goto z_bb_176; else goto z_bb_177;
    z_bb_176:
    z_bb_177:
    zT_771 = zT_769.data.payload;
    goto z_bb_178;
    z_bb_178:
    inc_raw = zT_771;
    zT_774 = (unsigned int*)inc_raw;
    inc_arr = zT_774;
    zT_776 = 0;
    inc_n = zT_776;
    zT_778 = 0;
    di0 = zT_778;
    goto z_bb_179;
    z_bb_179:
    zT_780 = dep_ids.len;
    if ((int)(di0 < zT_780)) goto z_bb_180; else goto z_bb_181;
    z_bb_180:
    zT_783 = dep_ids.ptr;
    zT_784 = zT_783[di0];
    dd0 = zT_784;
    zT_785 = m.id;
    if ((int)(dd0 == zT_785)) goto z_bb_183; else goto z_bb_184;
    z_bb_181:
    zT_810 = 0;
    vd0 = zT_810;
    goto z_bb_195;
    z_bb_182:
    zT_808 = di0 + (unsigned int)(1);
    di0 = zT_808;
    goto z_bb_179;
    z_bb_183:
    goto z_bb_182;
    z_bb_184:
    zT_787 = &reachable;
    zT_788 = dd0;
    zT_790 = zF_F3EE5998_u32ToU32MapGet(zT_787, zT_788);
    zT_791 = zT_790.has_value;
    if ((int)(!zT_791)) goto z_bb_185; else goto z_bb_186;
    z_bb_185:
    goto z_bb_182;
    z_bb_186:
    zT_794 = 0;
    dup0 = zT_794;
    zT_796 = 0;
    dj0 = zT_796;
    goto z_bb_187;
    z_bb_187:
    if ((int)(dj0 < inc_n)) goto z_bb_188; else goto z_bb_189;
    z_bb_188:
    zT_798 = inc_arr[dj0];
    if ((int)(zT_798 == dd0)) goto z_bb_191; else goto z_bb_192;
    z_bb_189:
    if ((int)(dup0 != (unsigned char)(0))) goto z_bb_193; else goto z_bb_194;
    z_bb_190:
    zT_802 = dj0 + (unsigned int)(1);
    dj0 = zT_802;
    goto z_bb_187;
    z_bb_191:
    zT_800 = 1;
    dup0 = zT_800;
    goto z_bb_189;
    z_bb_192:
    goto z_bb_190;
    z_bb_193:
    goto z_bb_182;
    z_bb_194:
    inc_arr[inc_n] = dd0;
    zT_806 = inc_n + (unsigned int)(1);
    inc_n = zT_806;
    goto z_bb_182;
    z_bb_195:
    zT_812 = mods.len;
    if ((int)(vd0 < zT_812)) goto z_bb_196; else goto z_bb_197;
    z_bb_196:
    zT_815 = mods.ptr;
    zT_816 = zT_815[vd0];
    zT_817 = zT_816.id;
    vdd0 = zT_817;
    zT_818 = m.id;
    if ((int)(vdd0 == zT_818)) goto z_bb_199; else goto z_bb_200;
    z_bb_197:
    zT_853 = 0;
    zT_854 = inc_arr + zT_853;
    zT_855 = inc_n - zT_853;
    zT_856.ptr = zT_854;
    zT_856.len = zT_855;
    inc_slice = zT_856;
    zT_857 = &emitter;
    zT_858 = m.id;
    zT_859 = base;
    zT_860 = m_c_incs;
    zT_861 = inc_slice;
    zT_862 = sorted;
    zF_1AF3E3A9_emitModuleHeaderFil(zT_857, zT_858, zT_859, zT_860, zT_861, zT_862);
    zT_866 = &emitter;
    zT_865 = &zT_866->writer;
    zF_B35650AD_bufferedWriterFlush(zT_865);
    zT_868 = fd2;
    zF_B30B1D79_fileClose(zT_868);
    zT_870 = "FINAL_FLUSH\n";
    zT_872 = 12;
    zT_871.ptr = zT_870;
    zT_871.len = zT_872;
    ff_m = zT_871;
    zT_873 = ff_m;
    zF_48AC7B3A_markerWrite(zT_873);
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_875[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        cpath[_i] = zT_875[_i];
        _i++;
    }
}
    zT_877 = 0;
    cp2 = zT_877;
    zT_879 = 0;
    ci2 = zT_879;
    goto z_bb_213;
    z_bb_198:
    zT_851 = vd0 + (unsigned int)(1);
    vd0 = zT_851;
    goto z_bb_195;
    z_bb_199:
    goto z_bb_198;
    z_bb_200:
    zT_820 = &reachable;
    zT_821 = vdd0;
    zT_823 = zF_F3EE5998_u32ToU32MapGet(zT_820, zT_821);
    zT_824 = zT_823.has_value;
    if ((int)(!zT_824)) goto z_bb_201; else goto z_bb_202;
    z_bb_201:
    goto z_bb_198;
    z_bb_202:
    zT_826 = &ref_edges;
    zT_829 = m.id;
    zT_833 = zF_F3EE5998_u32ToU32MapGet(zT_826, (unsigned int)((unsigned int)(zT_829 * (unsigned int)(65536)) + vdd0));
    zT_834 = zT_833.has_value;
    if ((int)(!zT_834)) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    goto z_bb_198;
    z_bb_204:
    zT_837 = 0;
    dup1 = zT_837;
    zT_839 = 0;
    dj1 = zT_839;
    goto z_bb_205;
    z_bb_205:
    if ((int)(dj1 < inc_n)) goto z_bb_206; else goto z_bb_207;
    z_bb_206:
    zT_841 = inc_arr[dj1];
    if ((int)(zT_841 == vdd0)) goto z_bb_209; else goto z_bb_210;
    z_bb_207:
    if ((int)(dup1 != (unsigned char)(0))) goto z_bb_211; else goto z_bb_212;
    z_bb_208:
    zT_845 = dj1 + (unsigned int)(1);
    dj1 = zT_845;
    goto z_bb_205;
    z_bb_209:
    zT_843 = 1;
    dup1 = zT_843;
    goto z_bb_207;
    z_bb_210:
    goto z_bb_208;
    z_bb_211:
    goto z_bb_198;
    z_bb_212:
    inc_arr[inc_n] = vdd0;
    zT_849 = inc_n + (unsigned int)(1);
    inc_n = zT_849;
    goto z_bb_198;
    z_bb_213:
    zT_881 = od.len;
    if ((int)(ci2 < zT_881)) goto z_bb_217; else goto z_bb_218;
    z_bb_214:
    zT_886 = od.ptr;
    zT_887 = zT_886[ci2];
    cpath[cp2] = zT_887;
    zT_888 = 1;
    zT_890 = cp2 + (unsigned int)((unsigned int)zT_888);
    cp2 = zT_890;
    goto z_bb_216;
    z_bb_215:
    zT_893 = 47;
    cpath[cp2] = zT_893;
    zT_894 = 1;
    zT_896 = cp2 + (unsigned int)((unsigned int)zT_894);
    cp2 = zT_896;
    zT_898 = 0;
    cbi = zT_898;
    goto z_bb_220;
    z_bb_216:
    zT_891 = 1;
    zT_892 = ci2 + zT_891;
    ci2 = zT_892;
    goto z_bb_213;
    z_bb_217:
    zT_883 = cp2 < (unsigned int)(510);
    goto z_bb_219;
    z_bb_218:
    zT_883 = 0;
    goto z_bb_219;
    z_bb_219:
    if (zT_883) goto z_bb_214; else goto z_bb_215;
    z_bb_220:
    zT_900 = base.len;
    if ((int)(cbi < zT_900)) goto z_bb_224; else goto z_bb_225;
    z_bb_221:
    zT_905 = base.ptr;
    zT_906 = zT_905[cbi];
    cpath[cp2] = zT_906;
    zT_907 = 1;
    zT_909 = cp2 + (unsigned int)((unsigned int)zT_907);
    cp2 = zT_909;
    goto z_bb_223;
    z_bb_222:
    zT_913 = ".c";
    zT_915 = 2;
    zT_914.ptr = zT_913;
    zT_914.len = zT_915;
    cext = zT_914;
    zT_917 = 0;
    cx = zT_917;
    goto z_bb_227;
    z_bb_223:
    zT_910 = 1;
    zT_911 = cbi + zT_910;
    cbi = zT_911;
    goto z_bb_220;
    z_bb_224:
    zT_902 = cp2 < (unsigned int)(510);
    goto z_bb_226;
    z_bb_225:
    zT_902 = 0;
    goto z_bb_226;
    z_bb_226:
    if (zT_902) goto z_bb_221; else goto z_bb_222;
    z_bb_227:
    zT_919 = cext.len;
    if ((int)(cx < zT_919)) goto z_bb_231; else goto z_bb_232;
    z_bb_228:
    zT_924 = cext.ptr;
    zT_925 = zT_924[cx];
    cpath[cp2] = zT_925;
    zT_926 = 1;
    zT_928 = cp2 + (unsigned int)((unsigned int)zT_926);
    cp2 = zT_928;
    goto z_bb_230;
    z_bb_229:
    zT_936 = 0;
    zT_937 = (unsigned char*)((unsigned char*)cpath) + zT_936;
    zT_938 = cp2 - zT_936;
    zT_939.ptr = zT_937;
    zT_939.len = zT_938;
    zT_932 = zT_939;
    zT_941 = zF_39FE21EF_fileOpen(zT_932, (int)(0));
    cfd = zT_941;
    if ((int)(cfd == zG_CC81CC5F_INVALID_FD)) goto z_bb_234; else goto z_bb_235;
    z_bb_230:
    zT_929 = 1;
    zT_930 = cx + zT_929;
    cx = zT_930;
    goto z_bb_227;
    z_bb_231:
    zT_921 = cp2 < (unsigned int)(511);
    goto z_bb_233;
    z_bb_232:
    zT_921 = 0;
    goto z_bb_233;
    z_bb_233:
    if (zT_921) goto z_bb_228; else goto z_bb_229;
    z_bb_234:
    zT_945 = "error: cannot open output file\n";
    zT_947 = 31;
    zT_946.ptr = zT_945;
    zT_946.len = zT_947;
    emsg3 = zT_946;
    zT_948 = emsg3;
    zF_E4B2EF19_stderr_write(zT_948);
    zF_CDED1A85_exit((unsigned char)(1));
    goto z_bb_235;
    z_bb_235:
    cw = zT_952;
    zT_953 = cfd;
    zT_954 = zF_E00097E1_bufferedWriterInitF(zT_953);
    cw = zT_954;
    emitter.writer = cw;
    zT_955 = &emitter;
    zT_956 = m.id;
    zT_957 = base;
    zF_7B8B9B90_emitModuleFile(zT_955, zT_956, zT_957);
    zT_961 = &emitter;
    zT_960 = &zT_961->writer;
    zF_B35650AD_bufferedWriterFlush(zT_960);
    zT_963 = cfd;
    zF_B30B1D79_fileClose(zT_963);
    zT_965 = "FINAL_FLUSH\n";
    zT_967 = 12;
    zT_966.ptr = zT_965;
    zT_966.len = zT_967;
    ff2_m = zT_966;
    zT_968 = ff2_m;
    zF_48AC7B3A_markerWrite(zT_968);
    goto z_bb_141;
}

/* parseArgs */
zT_C98AF326_CompilerCli zF_6143A521_parseArgs(void) {
    char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    zT_C98AF326_CompilerCli zT_9;
    int zT_10;
    int zT_11;
    int zT_12;
    int zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    zT_CAF40AAB_ColorMode zT_18;
    zT_A4FB690E_ErrorFormat zT_19;
    int zT_20;
    int zT_21;
    int zT_22;
    int zT_23;
    int zT_24;
    int zT_25;
    int zT_26;
    int zT_27;
    int zT_28;
    int zT_29;
    int zT_30;
    unsigned int zT_31;
    int zT_32;
    int zT_34 = 0;
    int zT_36;
    int zT_37;
    char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    char* zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_57;
    char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    char* zT_83;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_84;
    unsigned int zT_85;
    char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    char* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    unsigned int zT_97;
    char* zT_99;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_100;
    unsigned int zT_101;
    char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    char* zT_107;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_108;
    unsigned int zT_109;
    char* zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_113;
    char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    char* zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_120;
    unsigned int zT_121;
    char* zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    char* zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    unsigned int zT_145;
    char* zT_147;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_148;
    unsigned int zT_149;
    char* zT_151;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_152;
    unsigned int zT_153;
    char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    char* zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    char* zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_168;
    unsigned int zT_169;
    int zT_172;
    unsigned char* zT_173 = 0;
    unsigned char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176 = {0};
    unsigned int zT_178;
    int zT_179;
    int zT_181;
    unsigned char* zT_182;
    int zT_183;
    unsigned char zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    int zT_189 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_192;
    int zT_193 = 0;
    int zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    int zT_197 = 0;
    int zT_198;
    int zT_200;
    unsigned char* zT_202;
    int zT_203;
    unsigned char* zT_204 = 0;
    unsigned int zT_205 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    int zT_207 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    int zT_211;
    unsigned char* zT_212;
    unsigned int zT_213;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_214;
    unsigned int zT_215 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    int zT_217 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_218;
    unsigned char* zT_219;
    unsigned int zT_220;
    int zT_221;
    unsigned char* zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_226;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_227;
    int zT_228 = 0;
    int zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    int zT_232 = 0;
    int zT_233;
    int zT_235;
    unsigned char* zT_237;
    int zT_238;
    unsigned char* zT_239 = 0;
    unsigned int zT_240 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_242;
    int zT_243 = 0;
    int zT_244;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_245;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_246;
    int zT_247 = 0;
    int zT_248;
    int zT_250;
    unsigned char* zT_252;
    int zT_253;
    unsigned char* zT_254 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_255 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_257;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_258;
    int zT_259 = 0;
    int zT_260;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_261;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_262;
    int zT_263 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_266;
    int zT_267 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_270;
    int zT_271 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    int zT_275 = 0;
    int zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    int zT_279 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    int zT_283 = 0;
    int zT_284;
    int zT_286;
    unsigned char* zT_288;
    int zT_289;
    unsigned char* zT_290 = 0;
    zT_CAF40AAB_ColorMode zT_291 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_293;
    int zT_294 = 0;
    int zT_295;
    int zT_297;
    unsigned char* zT_299;
    int zT_300;
    unsigned char* zT_301 = 0;
    zT_A4FB690E_ErrorFormat zT_302 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_303;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_304;
    int zT_305 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    int zT_309 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_311;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_312;
    int zT_313 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_315;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_316;
    int zT_317 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_319;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_320;
    int zT_321 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_324;
    int zT_325 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_328;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_329;
    int zT_330 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    int zT_334 = 0;
    int zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    int zT_338 = 0;
    int zT_339;
    int zT_341;
    int zT_343;
    unsigned int zT_344;
    int zT_345;
    unsigned char* zT_347;
    int zT_348;
    unsigned char* zT_349 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_350 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned int zT_354;
    int zT_355;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    int zT_360 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_362;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_363;
    int zT_364 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_366;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_367;
    int zT_368 = 0;
    int zT_369;
    int zT_371;
    unsigned char* zT_373;
    int zT_374;
    unsigned char* zT_375 = 0;
    int zT_376 = 0;
    unsigned char* zT_377;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_378 = {0};
    unsigned char* zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380 = {0};
    int zT_381;
    int zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u dot_str;
    zT_C98AF326_CompilerCli cli;
    int argc;
    int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dump_c89;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_mem;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_max_errors;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_output_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_quiet;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sanity_test;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warnings;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_color;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_error_format;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_track_memory;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_null;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_lifetime;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_no_leak;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_all;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_warn_error;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_markers;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_include;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_lib_dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_e;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_o;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_q;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_W;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_osw;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_target;
    unsigned char* arg_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u arg;
    zT_1 = "";
    zT_3 = 0;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    empty_str = zT_2;
    zT_5 = ".";
    zT_7 = 1;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    dot_str = zT_6;
    zT_9.input_file = empty_str;
    zT_9.output_dir = dot_str;
    zT_10 = 0;
    zT_9.output_dir_set = zT_10;
    zT_11 = 0;
    zT_9.dump_types = zT_11;
    zT_12 = 0;
    zT_9.dump_lir = zT_12;
    zT_13 = 0;
    zT_9.dump_c89 = zT_13;
    zT_15 = (unsigned int)zG_18AE3D2F_DEFAULT_MAX_MEM_KB;
    zT_9.max_mem = zT_15;
    zT_16 = 0;
    zT_9.spill_level = zT_16;
    zT_17 = 256;
    zT_9.max_errors = zT_17;
    zT_18 = zT_CAF40AAB_ColorMode_auto;
    zT_9.color = zT_18;
    zT_19 = zT_A4FB690E_ErrorFormat_human;
    zT_9.error_format = zT_19;
    zT_20 = 0;
    zT_9.warnings_as_errors = zT_20;
    zT_21 = 0;
    zT_9.quiet = zT_21;
    zT_22 = 0;
    zT_9.test_mode = zT_22;
    zT_23 = 0;
    zT_9.sanity_test_mode = zT_23;
    zT_24 = 0;
    zT_9.track_memory = zT_24;
    zT_25 = 0;
    zT_9.no_null_check = zT_25;
    zT_26 = 0;
    zT_9.no_lifetime_check = zT_26;
    zT_27 = 0;
    zT_9.no_leak_check = zT_27;
    zT_28 = 0;
    zT_9.warn_all = zT_28;
    zT_29 = 0;
    zT_9.warn_error = zT_29;
    zT_30 = 0;
    zT_9.show_markers = zT_30;
    zT_31 = 0;
    zT_9.include_count = zT_31;
    zT_32 = 0;
    zT_9.target_is_windows = zT_32;
    cli = zT_9;
    zT_34 = zF_EEF840BE_argCount();
    argc = zT_34;
    zT_36 = 1;
    zT_37 = (int)zT_36;
    i = zT_37;
    zT_47 = "--dump-c89";
    zT_49 = 10;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    s_dump_c89 = zT_48;
    zT_51 = "--max-mem";
    zT_53 = 9;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    s_max_mem = zT_52;
    zT_55 = "--max-errors";
    zT_57 = 12;
    zT_56.ptr = zT_55;
    zT_56.len = zT_57;
    s_max_errors = zT_56;
    zT_59 = "--output-dir";
    zT_61 = 12;
    zT_60.ptr = zT_59;
    zT_60.len = zT_61;
    s_output_dir = zT_60;
    zT_63 = "--quiet";
    zT_65 = 7;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    s_quiet = zT_64;
    zT_67 = "--test";
    zT_69 = 6;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    s_test = zT_68;
    zT_71 = "--sanity-test";
    zT_73 = 13;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    s_sanity_test = zT_72;
    zT_75 = "--warnings-as-errors";
    zT_77 = 20;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    s_warnings = zT_76;
    zT_79 = "--color";
    zT_81 = 7;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    s_color = zT_80;
    zT_83 = "--error-format";
    zT_85 = 14;
    zT_84.ptr = zT_83;
    zT_84.len = zT_85;
    s_error_format = zT_84;
    zT_87 = "--track-memory";
    zT_89 = 14;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    s_track_memory = zT_88;
    zT_91 = "--no-null-check";
    zT_93 = 15;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    s_no_null = zT_92;
    zT_95 = "--no-lifetime-check";
    zT_97 = 19;
    zT_96.ptr = zT_95;
    zT_96.len = zT_97;
    s_no_lifetime = zT_96;
    zT_99 = "--no-leak-check";
    zT_101 = 15;
    zT_100.ptr = zT_99;
    zT_100.len = zT_101;
    s_no_leak = zT_100;
    zT_103 = "--warn-all";
    zT_105 = 10;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    s_warn_all = zT_104;
    zT_107 = "--warn-error";
    zT_109 = 12;
    zT_108.ptr = zT_107;
    zT_108.len = zT_109;
    s_warn_error = zT_108;
    zT_111 = "--markers";
    zT_113 = 9;
    zT_112.ptr = zT_111;
    zT_112.len = zT_113;
    s_markers = zT_112;
    zT_115 = "-I";
    zT_117 = 2;
    zT_116.ptr = zT_115;
    zT_116.len = zT_117;
    s_include = zT_116;
    zT_119 = "--lib-dir";
    zT_121 = 9;
    zT_120.ptr = zT_119;
    zT_120.len = zT_121;
    s_lib_dir = zT_120;
    zT_139 = "-m";
    zT_141 = 2;
    zT_140.ptr = zT_139;
    zT_140.len = zT_141;
    s_m = zT_140;
    zT_143 = "-e";
    zT_145 = 2;
    zT_144.ptr = zT_143;
    zT_144.len = zT_145;
    s_e = zT_144;
    zT_147 = "-o";
    zT_149 = 2;
    zT_148.ptr = zT_147;
    zT_148.len = zT_149;
    s_o = zT_148;
    zT_151 = "-q";
    zT_153 = 2;
    zT_152.ptr = zT_151;
    zT_152.len = zT_153;
    s_q = zT_152;
    zT_155 = "-W";
    zT_157 = 2;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    s_W = zT_156;
    zT_159 = "-osl";
    zT_161 = 4;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    s_osl = zT_160;
    zT_163 = "-osw";
    zT_165 = 4;
    zT_164.ptr = zT_163;
    zT_164.len = zT_165;
    s_osw = zT_164;
    zT_167 = "--target";
    zT_169 = 8;
    zT_168.ptr = zT_167;
    zT_168.len = zT_169;
    s_target = zT_168;
    goto z_bb_1;
    z_bb_1:
    if ((int)(i < argc)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_172 = i;
    zT_173 = zF_70B5BFF1_argGet(zT_172);
    arg_ptr = zT_173;
    zT_175 = arg_ptr;
    zT_176 = zF_22D0470E_cstrToSlice(zT_175);
    arg = zT_176;
    zT_178 = arg.len;
    zT_179 = 0;
    if ((int)(zT_178 > (unsigned int)zT_179)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return cli;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_182 = arg.ptr;
    zT_183 = 0;
    zT_184 = zT_182[zT_183];
    zT_181 = zT_184 == (unsigned char)(45);
    goto z_bb_7;
    z_bb_6:
    zT_181 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_181) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_187 = arg;
    zT_188 = s_dump_c89;
    zT_189 = zF_5FE51158_matchFlag(zT_187, zT_188);
    if (zT_189) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_381 = 1;
    zT_383 = i + (int)((int)zT_381);
    i = zT_383;
    goto z_bb_4;
    z_bb_10:
    zT_379 = arg_ptr;
    zT_380 = zF_22D0470E_cstrToSlice(zT_379);
    cli.input_file = zT_380;
    goto z_bb_9;
    z_bb_11:
    cli.dump_c89 = (int)(1);
    goto z_bb_12;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_191 = arg;
    zT_192 = s_max_mem;
    zT_193 = zF_5FE51158_matchFlag(zT_191, zT_192);
    if (zT_193) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_195 = arg;
    zT_196 = s_m;
    zT_197 = zF_5FE51158_matchFlag(zT_195, zT_196);
    zT_194 = zT_197;
    goto z_bb_16;
    z_bb_15:
    zT_194 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_194) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    zT_198 = 1;
    zT_200 = i + (int)((int)zT_198);
    i = zT_200;
    if ((int)(i < argc)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    goto z_bb_12;
    z_bb_19:
    zT_206 = arg;
    zT_207 = zF_FBF91F7E_matchMMFlag(zT_206);
    if (zT_207) goto z_bb_22; else goto z_bb_24;
    z_bb_20:
    zT_203 = i;
    zT_204 = zF_70B5BFF1_argGet(zT_203);
    zT_202 = zT_204;
    zT_205 = zF_6CF11065_parseSize(zT_202);
    cli.max_mem = zT_205;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_209 = arg.ptr;
    zT_210 = arg.len;
    zT_211 = 3;
    zT_212 = zT_209 + zT_211;
    zT_213 = zT_210 - zT_211;
    zT_214.ptr = zT_212;
    zT_214.len = zT_213;
    zT_208 = zT_214;
    zT_215 = zF_B9231BB9_parseMMBytes(zT_208);
    cli.max_mem = zT_215;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_18;
    z_bb_24:
    zT_216 = arg;
    zT_217 = zF_C4E3C361_matchSFlag(zT_216);
    if (zT_217) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    zT_219 = arg.ptr;
    zT_220 = arg.len;
    zT_221 = 2;
    zT_222 = zT_219 + zT_221;
    zT_223 = zT_220 - zT_221;
    zT_224.ptr = zT_222;
    zT_224.len = zT_223;
    zT_218 = zT_224;
    zT_225 = zF_153C3795_parseSLevel(zT_218);
    cli.spill_level = zT_225;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_226 = arg;
    zT_227 = s_max_errors;
    zT_228 = zF_5FE51158_matchFlag(zT_226, zT_227);
    if (zT_228) goto z_bb_29; else goto z_bb_28;
    z_bb_28:
    zT_230 = arg;
    zT_231 = s_e;
    zT_232 = zF_5FE51158_matchFlag(zT_230, zT_231);
    zT_229 = zT_232;
    goto z_bb_30;
    z_bb_29:
    zT_229 = 1;
    goto z_bb_30;
    z_bb_30:
    if (zT_229) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_233 = 1;
    zT_235 = i + (int)((int)zT_233);
    i = zT_235;
    if ((int)(i < argc)) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    goto z_bb_26;
    z_bb_33:
    zT_241 = arg;
    zT_242 = s_output_dir;
    zT_243 = zF_5FE51158_matchFlag(zT_241, zT_242);
    if (zT_243) goto z_bb_37; else goto z_bb_36;
    z_bb_34:
    zT_238 = i;
    zT_239 = zF_70B5BFF1_argGet(zT_238);
    zT_237 = zT_239;
    zT_240 = zF_16BBA09E_parseU32(zT_237);
    cli.max_errors = zT_240;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_245 = arg;
    zT_246 = s_o;
    zT_247 = zF_5FE51158_matchFlag(zT_245, zT_246);
    zT_244 = zT_247;
    goto z_bb_38;
    z_bb_37:
    zT_244 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_244) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_248 = 1;
    zT_250 = i + (int)((int)zT_248);
    i = zT_250;
    if ((int)(i < argc)) goto z_bb_42; else goto z_bb_43;
    z_bb_40:
    goto z_bb_32;
    z_bb_41:
    zT_257 = arg;
    zT_258 = s_quiet;
    zT_259 = zF_5FE51158_matchFlag(zT_257, zT_258);
    if (zT_259) goto z_bb_45; else goto z_bb_44;
    z_bb_42:
    zT_253 = i;
    zT_254 = zF_70B5BFF1_argGet(zT_253);
    zT_252 = zT_254;
    zT_255 = zF_22D0470E_cstrToSlice(zT_252);
    cli.output_dir = zT_255;
    cli.output_dir_set = (int)(1);
    goto z_bb_43;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_261 = arg;
    zT_262 = s_q;
    zT_263 = zF_5FE51158_matchFlag(zT_261, zT_262);
    zT_260 = zT_263;
    goto z_bb_46;
    z_bb_45:
    zT_260 = 1;
    goto z_bb_46;
    z_bb_46:
    if (zT_260) goto z_bb_47; else goto z_bb_49;
    z_bb_47:
    cli.quiet = (int)(1);
    goto z_bb_48;
    z_bb_48:
    goto z_bb_40;
    z_bb_49:
    zT_265 = arg;
    zT_266 = s_test;
    zT_267 = zF_5FE51158_matchFlag(zT_265, zT_266);
    if (zT_267) goto z_bb_50; else goto z_bb_52;
    z_bb_50:
    cli.test_mode = (int)(1);
    goto z_bb_51;
    z_bb_51:
    goto z_bb_48;
    z_bb_52:
    zT_269 = arg;
    zT_270 = s_sanity_test;
    zT_271 = zF_5FE51158_matchFlag(zT_269, zT_270);
    if (zT_271) goto z_bb_53; else goto z_bb_55;
    z_bb_53:
    cli.sanity_test_mode = (int)(1);
    goto z_bb_54;
    z_bb_54:
    goto z_bb_51;
    z_bb_55:
    zT_273 = arg;
    zT_274 = s_warnings;
    zT_275 = zF_5FE51158_matchFlag(zT_273, zT_274);
    if (zT_275) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_277 = arg;
    zT_278 = s_W;
    zT_279 = zF_5FE51158_matchFlag(zT_277, zT_278);
    zT_276 = zT_279;
    goto z_bb_58;
    z_bb_57:
    zT_276 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_276) goto z_bb_59; else goto z_bb_61;
    z_bb_59:
    cli.warnings_as_errors = (int)(1);
    goto z_bb_60;
    z_bb_60:
    goto z_bb_54;
    z_bb_61:
    zT_281 = arg;
    zT_282 = s_color;
    zT_283 = zF_5FE51158_matchFlag(zT_281, zT_282);
    if (zT_283) goto z_bb_62; else goto z_bb_64;
    z_bb_62:
    zT_284 = 1;
    zT_286 = i + (int)((int)zT_284);
    i = zT_286;
    if ((int)(i < argc)) goto z_bb_65; else goto z_bb_66;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_292 = arg;
    zT_293 = s_error_format;
    zT_294 = zF_5FE51158_matchFlag(zT_292, zT_293);
    if (zT_294) goto z_bb_67; else goto z_bb_69;
    z_bb_65:
    zT_289 = i;
    zT_290 = zF_70B5BFF1_argGet(zT_289);
    zT_288 = zT_290;
    zT_291 = zF_05AD3AFC_parseColorMode(zT_288);
    cli.color = zT_291;
    goto z_bb_66;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_295 = 1;
    zT_297 = i + (int)((int)zT_295);
    i = zT_297;
    if ((int)(i < argc)) goto z_bb_70; else goto z_bb_71;
    z_bb_68:
    goto z_bb_63;
    z_bb_69:
    zT_303 = arg;
    zT_304 = s_track_memory;
    zT_305 = zF_5FE51158_matchFlag(zT_303, zT_304);
    if (zT_305) goto z_bb_72; else goto z_bb_74;
    z_bb_70:
    zT_300 = i;
    zT_301 = zF_70B5BFF1_argGet(zT_300);
    zT_299 = zT_301;
    zT_302 = zF_A4602959_parseErrorFormat(zT_299);
    cli.error_format = zT_302;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_68;
    z_bb_72:
    cli.track_memory = (int)(1);
    goto z_bb_73;
    z_bb_73:
    goto z_bb_68;
    z_bb_74:
    zT_307 = arg;
    zT_308 = s_no_null;
    zT_309 = zF_5FE51158_matchFlag(zT_307, zT_308);
    if (zT_309) goto z_bb_75; else goto z_bb_77;
    z_bb_75:
    cli.no_null_check = (int)(1);
    goto z_bb_76;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_311 = arg;
    zT_312 = s_no_lifetime;
    zT_313 = zF_5FE51158_matchFlag(zT_311, zT_312);
    if (zT_313) goto z_bb_78; else goto z_bb_80;
    z_bb_78:
    cli.no_lifetime_check = (int)(1);
    goto z_bb_79;
    z_bb_79:
    goto z_bb_76;
    z_bb_80:
    zT_315 = arg;
    zT_316 = s_no_leak;
    zT_317 = zF_5FE51158_matchFlag(zT_315, zT_316);
    if (zT_317) goto z_bb_81; else goto z_bb_83;
    z_bb_81:
    cli.no_leak_check = (int)(1);
    goto z_bb_82;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    zT_319 = arg;
    zT_320 = s_warn_all;
    zT_321 = zF_5FE51158_matchFlag(zT_319, zT_320);
    if (zT_321) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    cli.warn_all = (int)(1);
    goto z_bb_85;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_323 = arg;
    zT_324 = s_warn_error;
    zT_325 = zF_5FE51158_matchFlag(zT_323, zT_324);
    if (zT_325) goto z_bb_87; else goto z_bb_89;
    z_bb_87:
    cli.warnings_as_errors = (int)(1);
    cli.warn_error = (int)(1);
    goto z_bb_88;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    zT_328 = arg;
    zT_329 = s_markers;
    zT_330 = zF_5FE51158_matchFlag(zT_328, zT_329);
    if (zT_330) goto z_bb_90; else goto z_bb_92;
    z_bb_90:
    cli.show_markers = (int)(1);
    goto z_bb_91;
    z_bb_91:
    goto z_bb_88;
    z_bb_92:
    zT_332 = arg;
    zT_333 = s_include;
    zT_334 = zF_5FE51158_matchFlag(zT_332, zT_333);
    if (zT_334) goto z_bb_94; else goto z_bb_93;
    z_bb_93:
    zT_336 = arg;
    zT_337 = s_lib_dir;
    zT_338 = zF_5FE51158_matchFlag(zT_336, zT_337);
    zT_335 = zT_338;
    goto z_bb_95;
    z_bb_94:
    zT_335 = 1;
    goto z_bb_95;
    z_bb_95:
    if (zT_335) goto z_bb_96; else goto z_bb_98;
    z_bb_96:
    zT_339 = 1;
    zT_341 = i + (int)((int)zT_339);
    i = zT_341;
    if ((int)(i < argc)) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    goto z_bb_91;
    z_bb_98:
    zT_358 = arg;
    zT_359 = s_osl;
    zT_360 = zF_5FE51158_matchFlag(zT_358, zT_359);
    if (zT_360) goto z_bb_104; else goto z_bb_106;
    z_bb_99:
    zT_344 = cli.include_count;
    zT_345 = 16;
    zT_343 = zT_344 < (unsigned int)zT_345;
    goto z_bb_101;
    z_bb_100:
    zT_343 = 0;
    goto z_bb_101;
    z_bb_101:
    if (zT_343) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_348 = i;
    zT_349 = zF_70B5BFF1_argGet(zT_348);
    zT_347 = zT_349;
    zT_350 = zF_22D0470E_cstrToSlice(zT_347);
    zT_351 = cli.include_dirs;
    zT_352 = cli.include_count;
    zT_353 = (unsigned int)zT_352;
    zT_351[zT_353] = zT_350;
    zT_354 = cli.include_count;
    zT_355 = 1;
    cli.include_count = (unsigned int)(zT_354 + (unsigned int)((unsigned int)zT_355));
    goto z_bb_103;
    z_bb_103:
    goto z_bb_97;
    z_bb_104:
    cli.target_is_windows = (int)(0);
    goto z_bb_105;
    z_bb_105:
    goto z_bb_97;
    z_bb_106:
    zT_362 = arg;
    zT_363 = s_osw;
    zT_364 = zF_5FE51158_matchFlag(zT_362, zT_363);
    if (zT_364) goto z_bb_107; else goto z_bb_109;
    z_bb_107:
    cli.target_is_windows = (int)(1);
    goto z_bb_108;
    z_bb_108:
    goto z_bb_105;
    z_bb_109:
    zT_366 = arg;
    zT_367 = s_target;
    zT_368 = zF_5FE51158_matchFlag(zT_366, zT_367);
    if (zT_368) goto z_bb_110; else goto z_bb_112;
    z_bb_110:
    zT_369 = 1;
    zT_371 = i + (int)((int)zT_369);
    i = zT_371;
    if ((int)(i < argc)) goto z_bb_113; else goto z_bb_114;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_377 = arg_ptr;
    zT_378 = zF_22D0470E_cstrToSlice(zT_377);
    cli.input_file = zT_378;
    goto z_bb_111;
    z_bb_113:
    zT_374 = i;
    zT_375 = zF_70B5BFF1_argGet(zT_374);
    zT_373 = zT_375;
    zT_376 = zF_06CC17EA_parseTargetIsWindow(zT_373);
    cli.target_is_windows = zT_376;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
}

/* matchFlag */
int zF_5FE51158_matchFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg, zT_8F083A69_Slice_zT_0B42B2F8_u flag) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    int zT_20;
    unsigned int zT_22;
    unsigned int j;
    zT_3 = arg.len;
    zT_5 = flag.len;
    if ((int)(zT_3 != zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    j = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = arg.len;
    if ((int)(j < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = arg.ptr;
    zT_15 = zT_14[j];
    zT_16 = flag.ptr;
    zT_17 = zT_16[j];
    if ((int)(zT_15 != zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_20 = 1;
    zT_22 = j + (unsigned int)((unsigned int)zT_20);
    j = zT_22;
    goto z_bb_6;
}

/* matchMMFlag */
int zF_FBF91F7E_matchMMFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_mm;
    unsigned int j;
    zT_2 = "-mm";
    zT_4 = 3;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_mm = zT_3;
    zT_6 = arg.len;
    zT_8 = s_mm.len;
    if ((int)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_mm.len;
    if ((int)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_mm.ptr;
    zT_20 = zT_19[j];
    if ((int)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* cstrToSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D0470E_cstrToSlice(unsigned char* ptr) {
    int zT_2;
    unsigned int zT_3;
    unsigned char zT_4;
    int zT_5;
    int zT_7;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int len;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    len = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = ptr[len];
    zT_5 = 0;
    if ((int)(zT_4 != zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 1;
    zT_9 = len + (unsigned int)((unsigned int)zT_7);
    len = zT_9;
    goto z_bb_4;
    z_bb_3:
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    return zT_13;
    z_bb_4:
    goto z_bb_1;
}

/* parseSize */
unsigned int zF_6CF11065_parseSize(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    int zT_18;
    int zT_21;
    unsigned int zT_26;
    int zT_29;
    int zT_32;
    unsigned int zT_33;
    int zT_36;
    int zT_39;
    int zT_41;
    unsigned int zT_42;
    int zT_45;
    int zT_48;
    int zT_50;
    int zT_52;
    unsigned int zT_53;
    int zT_54;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((int)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((int)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_54 = 1;
    zT_56 = i + (unsigned int)((unsigned int)zT_54);
    i = zT_56;
    goto z_bb_4;
    z_bb_10:
    if ((int)(c == (unsigned char)(107))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_29 = c == (unsigned char)(75);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_32 = 1024;
    zT_33 = val * zT_32;
    val = zT_33;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    if ((int)(c == (unsigned char)(109))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_36 = c == (unsigned char)(77);
    goto z_bb_19;
    z_bb_18:
    zT_36 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_36) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_39 = 1024;
    zT_41 = 1024;
    zT_42 = (unsigned int)(val * zT_39) * zT_41;
    val = zT_42;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    if ((int)(c == (unsigned char)(103))) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_45 = c == (unsigned char)(71);
    goto z_bb_25;
    z_bb_24:
    zT_45 = 1;
    goto z_bb_25;
    z_bb_25:
    if (zT_45) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_48 = 1024;
    zT_50 = 1024;
    zT_52 = 1024;
    zT_53 = (unsigned int)((unsigned int)(val * zT_48) * zT_50) * zT_52;
    val = zT_53;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_21;
}

/* parseU32 */
unsigned int zF_16BBA09E_parseU32(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char* zT_14;
    unsigned char zT_15;
    int zT_18;
    int zT_21;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    unsigned int val;
    unsigned int i;
    unsigned char c;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    val = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = s.len;
    if ((int)(i < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_14 = s.ptr;
    zT_15 = zT_14[i];
    c = zT_15;
    if ((int)(c >= (unsigned char)(48))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return val;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = c <= (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = 10;
    zT_26 = (unsigned int)(val * zT_21) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    val = zT_26;
    goto z_bb_9;
    z_bb_9:
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_4;
}

/* parseMMBytes */
unsigned int zF_B9231BB9_parseMMBytes(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    int zT_26;
    unsigned int zT_28;
    unsigned int zT_35;
    int zT_37;
    unsigned int zT_39;
    int zT_40;
    int zT_42;
    unsigned int zT_44;
    char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int max_mb;
    unsigned int i;
    unsigned int n;
    unsigned int mb;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_5 = (unsigned int)(unsigned int)(256);
    max_mb = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    n = zT_11;
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    mb = zT_14;
    goto z_bb_1;
    z_bb_1:
    zT_16 = rest.len;
    if ((int)(i < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_19 = rest.ptr;
    zT_20 = zT_19[i];
    c = zT_20;
    if ((int)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_40 = 0;
    if ((int)(n == (unsigned int)zT_40)) goto z_bb_15; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_23 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_23 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_23) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_26 = 1;
    zT_28 = n + (unsigned int)((unsigned int)zT_26);
    n = zT_28;
    if ((int)(mb < max_mb)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_35 = (unsigned int)(mb * (unsigned int)(10)) + (unsigned int)((unsigned int)(unsigned char)(c - (unsigned char)(48)));
    mb = zT_35;
    if ((int)(mb > max_mb)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    goto z_bb_4;
    z_bb_12:
    mb = max_mb;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    zT_44 = rest.len;
    zT_42 = i != zT_44;
    goto z_bb_16;
    z_bb_15:
    zT_42 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_47 = "error: -mm<N> requires a decimal MB size (e.g. -mm64)\n";
    zT_49 = 54;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    em = zT_48;
    zT_50 = em;
    zF_E4B2EF19_stderr_write(zT_50);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_18:
    return (unsigned int)(mb * (unsigned int)(1024));
}

/* matchSFlag */
int zF_C4E3C361_matchSFlag(zT_8F083A69_Slice_zT_0B42B2F8_u arg) {
    char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned char* zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned char zT_20;
    int zT_23;
    unsigned int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_s;
    unsigned int j;
    zT_2 = "-s";
    zT_4 = 2;
    zT_3.ptr = zT_2;
    zT_3.len = zT_4;
    s_s = zT_3;
    zT_6 = arg.len;
    zT_8 = s_s.len;
    if ((int)(zT_6 < zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    j = zT_13;
    goto z_bb_3;
    z_bb_3:
    zT_15 = s_s.len;
    if ((int)(j < zT_15)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = arg.ptr;
    zT_18 = zT_17[j];
    zT_19 = s_s.ptr;
    zT_20 = zT_19[j];
    if ((int)(zT_18 != zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    return (int)(1);
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    zT_23 = 1;
    zT_25 = j + (unsigned int)((unsigned int)zT_23);
    j = zT_25;
    goto z_bb_6;
}

/* parseSLevel */
unsigned int zF_153C3795_parseSLevel(zT_8F083A69_Slice_zT_0B42B2F8_u rest) {
    int zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_17;
    unsigned char zT_18;
    int zT_21;
    int zT_24;
    unsigned int zT_26;
    int zT_27;
    unsigned int zT_32;
    unsigned int zT_36;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_43;
    int zT_44;
    int zT_46;
    unsigned int zT_48;
    char* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_58;
    char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int i;
    unsigned int n;
    unsigned int level;
    unsigned int over;
    unsigned char c;
    unsigned int d;
    unsigned int nl;
    zT_8F083A69_Slice_zT_0B42B2F8_u em;
    zT_2 = 0;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    n = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    level = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    over = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_14 = rest.len;
    if ((int)(i < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = rest.ptr;
    zT_18 = zT_17[i];
    c = zT_18;
    if ((int)(c < (unsigned char)(48))) goto z_bb_6; else goto z_bb_5;
    z_bb_3:
    zT_44 = 0;
    if ((int)(n == (unsigned int)zT_44)) goto z_bb_16; else goto z_bb_15;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_21 = c > (unsigned char)(57);
    goto z_bb_7;
    z_bb_6:
    zT_21 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_21) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_24 = 1;
    zT_26 = n + (unsigned int)((unsigned int)zT_24);
    n = zT_26;
    zT_27 = 0;
    if ((int)(over == (unsigned int)zT_27)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_32 = (unsigned int)(unsigned char)(c - (unsigned char)(48));
    d = zT_32;
    zT_36 = (unsigned int)(level * (unsigned int)(10)) + d;
    nl = zT_36;
    if ((int)(nl > (unsigned int)(5))) goto z_bb_12; else goto z_bb_14;
    z_bb_11:
    zT_41 = 1;
    zT_43 = i + (unsigned int)((unsigned int)zT_41);
    i = zT_43;
    goto z_bb_4;
    z_bb_12:
    zT_39 = 1;
    zT_40 = (unsigned int)zT_39;
    over = zT_40;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
    z_bb_14:
    level = nl;
    goto z_bb_13;
    z_bb_15:
    zT_48 = rest.len;
    zT_46 = i != zT_48;
    goto z_bb_17;
    z_bb_16:
    zT_46 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_46) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_51 = "error: -s<N> requires a decimal level 0..5 (e.g. -s0 all on disk, -s5 all in RAM)\n";
    zT_53 = 82;
    zT_52.ptr = zT_51;
    zT_52.len = zT_53;
    em = zT_52;
    zT_54 = em;
    zF_E4B2EF19_stderr_write(zT_54);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_19:
    zT_58 = 0;
    if ((int)(over != (unsigned int)zT_58)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = "error: -s<N> spill level out of range (0..5: 0 = all on disk, 5 = all in RAM)\n";
    zT_63 = 78;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    em = zT_62;
    zT_64 = em;
    zF_E4B2EF19_stderr_write(zT_64);
    zF_CDED1A85_exit((unsigned char)(1));
    return (unsigned int)(0);
    z_bb_21:
    return level;
}

/* parseColorMode */
zT_CAF40AAB_ColorMode zF_05AD3AFC_parseColorMode(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    int zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_always;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_never;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "always";
    zT_7 = 6;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_always = zT_6;
    zT_9 = "never";
    zT_11 = 5;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_never = zT_10;
    zT_12 = s;
    zT_13 = s_always;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_always);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_never;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_never);
    z_bb_4:
    return (zT_CAF40AAB_ColorMode)(zT_CAF40AAB_ColorMode_auto);
}

/* parseErrorFormat */
zT_A4FB690E_ErrorFormat zF_A4602959_parseErrorFormat(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    int zT_18 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_json;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sarif;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "json";
    zT_7 = 4;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_json = zT_6;
    zT_9 = "sarif";
    zT_11 = 5;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_sarif = zT_10;
    zT_12 = s;
    zT_13 = s_json;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_json);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_sarif;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_sarif);
    z_bb_4:
    return (zT_A4FB690E_ErrorFormat)(zT_A4FB690E_ErrorFormat_human);
}

/* parseTargetIsWindows */
int zF_06CC17EA_parseTargetIsWindow(unsigned char* ptr) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3 = {0};
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_14 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    int zT_18 = 0;
    char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_linux;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_windows;
    zT_8F083A69_Slice_zT_0B42B2F8_u err_msg;
    zT_2 = ptr;
    zT_3 = zF_22D0470E_cstrToSlice(zT_2);
    s = zT_3;
    zT_5 = "linux";
    zT_7 = 5;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_linux = zT_6;
    zT_9 = "windows";
    zT_11 = 7;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_windows = zT_10;
    zT_12 = s;
    zT_13 = s_windows;
    zT_14 = zF_5FE51158_matchFlag(zT_12, zT_13);
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_16 = s;
    zT_17 = s_linux;
    zT_18 = zF_5FE51158_matchFlag(zT_16, zT_17);
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_21 = "error: --target must be 'linux' or 'windows'\n";
    zT_23 = 45;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    err_msg = zT_22;
    zT_24 = err_msg;
    zF_E4B2EF19_stderr_write(zT_24);
    zF_CDED1A85_exit((unsigned char)(1));
    return (int)(0);
}

/* writeU32 */
void zF_266B1B8E_writeU32(unsigned int val) {
    zT_5426B97B_Arr_unsigned_char_1 zT_2;
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    int zT_9;
    unsigned char zT_10;
    int zT_11;
    int zT_15;
    int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    int zT_23;
    int zT_24;
    int zT_26;
    unsigned int zT_28;
    int zT_29;
    int zT_30;
    unsigned int zT_34;
    unsigned char zT_35;
    int zT_36;
    unsigned int zT_37;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u s;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 16;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    v = val;
    zT_7 = 0;
    if ((int)(v == (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 48;
    zT_10 = (unsigned char)zT_9;
    zT_11 = 15;
    buf[zT_11] = zT_10;
    zT_15 = 16;
    zT_16 = 15;
    zT_17 = (unsigned char*)((unsigned char*)buf) + zT_16;
    zT_18 = zT_15 - zT_16;
    zT_19.ptr = zT_17;
    zT_19.len = zT_18;
    s = zT_19;
    zT_20 = s;
    zF_B5478454_measureMarkerWrite(zT_20);
    return;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_21 = 0;
    if ((int)(v > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_26 = 1;
    zT_28 = i - (unsigned int)((unsigned int)zT_26);
    i = zT_28;
    zT_29 = 48;
    zT_30 = 10;
    zT_34 = (unsigned int)(unsigned int)(zT_29 + (unsigned int)((unsigned int)(unsigned int)(v % zT_30)));
    zT_35 = __bootstrap_u8_from_u32(zT_34);
    buf[i] = zT_35;
    zT_36 = 10;
    zT_37 = v / zT_36;
    v = zT_37;
    goto z_bb_6;
    z_bb_5:
    zT_41 = 16;
    zT_42 = (unsigned char*)((unsigned char*)buf) + i;
    zT_43 = zT_41 - i;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    s = zT_44;
    zT_45 = s;
    zF_B5478454_measureMarkerWrite(zT_45);
    return;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_24 = 0;
    zT_23 = i > (unsigned int)zT_24;
    goto z_bb_9;
    z_bb_8:
    zT_23 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_23) goto z_bb_4; else goto z_bb_5;
}

/* printUsage */
void zF_9D45DFBF_printUsage(void) {
    char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u mm_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_help3;
    zT_8F083A69_Slice_zT_0B42B2F8_u os_help;
    zT_8F083A69_Slice_zT_0B42B2F8_u tgt_help;
    zT_1 = "zig1 - Z98 self-hosted compiler - usage: zig1 [options] <input.zig>\n";
    zT_3 = 68;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_6 = "  -mm<N>    hard pool budget in MB (default 64; pool.peak over budget -> ICE rc=3)\n";
    zT_8 = 83;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    mm_help = zT_7;
    zT_9 = mm_help;
    zF_E4B2EF19_stderr_write(zT_9);
    zT_11 = "  -s<N>     spill level 0..5 (default 0 = all spills on disk; -s1..-s5 deactivate the\n";
    zT_13 = 86;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    s_help = zT_12;
    zT_14 = s_help;
    zF_E4B2EF19_stderr_write(zT_14);
    zT_16 = "            first N spills to RAM in order AST,LIR,HASH,RES,SIDE: higher -s = more RAM,\n";
    zT_18 = 88;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    s_help2 = zT_17;
    zT_19 = s_help2;
    zF_E4B2EF19_stderr_write(zT_19);
    zT_21 = "            less disk I/O (pool= rises; -s5 = all in RAM ~71 MB -> pair with -mm128)\n";
    zT_23 = 85;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    s_help3 = zT_22;
    zT_24 = s_help3;
    zF_E4B2EF19_stderr_write(zT_24);
    zT_26 = "  -osl       compile target = linux (default); -osw = windows\n";
    zT_28 = 62;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    os_help = zT_27;
    zT_29 = os_help;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_31 = "  --target <linux|windows>  long-form target alias for -osl/-osw\n";
    zT_33 = 65;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    tgt_help = zT_32;
    zT_34 = tgt_help;
    zF_E4B2EF19_stderr_write(zT_34);
    return;
}

/* __module_init */
void zF_780653D2___module_init(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_69057089_CompilerAlloc zT_1 = {0};
    zT_D3EB6303_StringInterner zT_2 = {0};
    zT_227EDE07_SourceManager zT_3 = {0};
    zT_F85C5DED_DiagnosticCollector zT_4 = {0};
    zT_CEC2984A_NameMangler zT_5 = {0};
    zT_3A355BD2_Token zT_6 = {0};
    zT_EAC3E484_TokenKind zT_7 = 0;
    zT_072B53A6_ModuleRegistry zT_8 = {0};
    zT_338B7C76_TypeRegistry zT_9 = {0};
    zT_6B356268_SemanticContext zT_10 = {0};
    zT_02EB57B2_LirLowerer zT_11 = {0};
    zT_CA01C129_LirSlotArrayList zT_12 = {0};
    zT_8EED1867_ResolvedTypeTable zT_13 = {0};
    zT_66E7D2EF_CoercionTable zT_14 = {0};
    zT_3D7259E2_SymbolRegistry zT_15 = {0};
    zT_8143F551_AstKind zT_16 = 0;
    zT_6B0A7D14_AstStore zT_17 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_69057089_CompilerAlloc = zT_1;
    zG_D3EB6303_StringInterner = zT_2;
    zG_227EDE07_SourceManager = zT_3;
    zG_F85C5DED_DiagnosticCollector = zT_4;
    zG_CEC2984A_NameMangler = zT_5;
    zG_3A355BD2_Token = zT_6;
    zG_EAC3E484_TokenKind = zT_7;
    zG_072B53A6_ModuleRegistry = zT_8;
    zG_338B7C76_TypeRegistry = zT_9;
    zG_6B356268_SemanticContext = zT_10;
    zG_02EB57B2_LirLowerer = zT_11;
    zG_CA01C129_LirSlotArrayList = zT_12;
    zG_8EED1867_ResolvedTypeTable = zT_13;
    zG_66E7D2EF_CoercionTable = zT_14;
    zG_3D7259E2_SymbolRegistry = zT_15;
    zG_8143F551_AstKind = zT_16;
    zG_6B0A7D14_AstStore = zT_17;
    return;
}

/* EOF */
