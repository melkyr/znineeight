#ifndef ZIG_MODULE_PANIC_CE239B25_H
#define ZIG_MODULE_PANIC_CE239B25_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "pal_388A8A1B.h"
#include "itoa_4E677A6A.h"


/* Forward declarations */
void zF_6D97D338_panicHandler(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_PANIC_CE239B25_H */
