#include "ast_2FA12982.h"
zT_8143F551_AstKind zG_8143F551_AstKind;
zT_6B0A7D14_AstStore zG_6B0A7D14_AstStore;
unsigned char* zG_CC2D7D2E_zzz_astnode_sz;
/* u32ArrayListAppendInner */
void zF_8B163A32_u32ArrayListAppen_1(unsigned int** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_3E40CD83_Sand* zT_24;
    unsigned int* zT_29;
    unsigned int zT_31;
    zT_6F32B01B_Opt_235 zT_37 = {0};
    unsigned char zT_38;
    unsigned int* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_3E40CD83_Sand* zT_46;
    zT_C6536882_EU_532 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int* zT_57;
    unsigned int* zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int* zT_61;
    unsigned int zT_62;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_63;
    unsigned int* zT_64;
    unsigned int zT_65;
    unsigned int zT_70;
    unsigned int* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int new_cap;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    unsigned int* new_items_p;
    unsigned int item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((int)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((int)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_71 = *items;
    zT_72 = *len;
    zT_71[zT_72] = value;
    zT_73 = *len;
    zT_74 = 1;
    *len = (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74));
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    if ((int)(new_cap < (unsigned int)(zT_13 * zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = *len;
    zT_18 = 2;
    zT_19 = zT_17 * zT_18;
    new_cap = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = *capacity;
    zT_21 = 0;
    if ((int)(zT_20 > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = arena;
    zT_29 = *items;
    zT_31 = *capacity;
    zT_37 = zF_33A3D4F8_sandTryReallocInPla(zT_24, (unsigned char*)((unsigned char*)zT_29), (unsigned int)(zT_31 * (unsigned int)(4)), (unsigned int)(new_cap * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_37;
    zT_38 = grown.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_46 = arena;
    zT_52 = zF_1395EB68_sandAlloc(zT_46, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_39 = *items;
    zT_40 = *len;
    zT_39[zT_40] = value;
    zT_41 = *len;
    zT_42 = 1;
    *len = (unsigned int)(zT_41 + (unsigned int)((unsigned int)zT_42));
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_54 = zT_52.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_54;
    zT_57 = (unsigned int*)raw;
    new_items_p = zT_57;
    zT_58 = *items;
    zT_59 = *len;
    zT_60 = 0;
    zT_61 = zT_58 + zT_60;
    zT_62 = zT_59 - zT_60;
    zT_63.ptr = zT_61;
    zT_63.len = zT_62;
    zT_64 = zT_63.ptr;
    zT_65 = zT_63.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_65)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_64[i];
    new_items_p[i] = item;
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_14;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
}

/* u64ArrayListAppendInner */
void zF_FA105BA5_u64ArrayListAppendI(zT_79FAE712_u64** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, zT_79FAE712_u64 value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_3E40CD83_Sand* zT_24;
    zT_79FAE712_u64* zT_29;
    unsigned int zT_31;
    zT_6F32B01B_Opt_235 zT_37 = {0};
    unsigned char zT_38;
    zT_79FAE712_u64* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_3E40CD83_Sand* zT_46;
    zT_C6536882_EU_532 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    zT_79FAE712_u64* zT_57;
    zT_79FAE712_u64* zT_58;
    unsigned int zT_59;
    int zT_60;
    zT_79FAE712_u64* zT_61;
    unsigned int zT_62;
    zT_A62C5D8D_Slice_zT_79FAE712_u zT_63;
    zT_79FAE712_u64* zT_64;
    unsigned int zT_65;
    unsigned int zT_70;
    zT_79FAE712_u64* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int new_cap;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    zT_79FAE712_u64* new_items_p;
    zT_79FAE712_u64 item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((int)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((int)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_71 = *items;
    zT_72 = *len;
    zT_71[zT_72] = value;
    zT_73 = *len;
    zT_74 = 1;
    *len = (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74));
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    if ((int)(new_cap < (unsigned int)(zT_13 * zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = *len;
    zT_18 = 2;
    zT_19 = zT_17 * zT_18;
    new_cap = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = *capacity;
    zT_21 = 0;
    if ((int)(zT_20 > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = arena;
    zT_29 = *items;
    zT_31 = *capacity;
    zT_37 = zF_33A3D4F8_sandTryReallocInPla(zT_24, (unsigned char*)((unsigned char*)zT_29), (unsigned int)(zT_31 * (unsigned int)(8)), (unsigned int)(new_cap * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_37;
    zT_38 = grown.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_46 = arena;
    zT_52 = zF_1395EB68_sandAlloc(zT_46, (unsigned int)((unsigned int)(8) * new_cap), (unsigned int)(4));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_39 = *items;
    zT_40 = *len;
    zT_39[zT_40] = value;
    zT_41 = *len;
    zT_42 = 1;
    *len = (unsigned int)(zT_41 + (unsigned int)((unsigned int)zT_42));
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_54 = zT_52.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_54;
    zT_57 = (zT_79FAE712_u64*)raw;
    new_items_p = zT_57;
    zT_58 = *items;
    zT_59 = *len;
    zT_60 = 0;
    zT_61 = zT_58 + zT_60;
    zT_62 = zT_59 - zT_60;
    zT_63.ptr = zT_61;
    zT_63.len = zT_62;
    zT_64 = zT_63.ptr;
    zT_65 = zT_63.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_65)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_64[i];
    new_items_p[i] = item;
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_14;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
}

/* f64ArrayListAppendInner */
void zF_51A5BB50_f64ArrayListAppendI(double** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, double value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_3E40CD83_Sand* zT_24;
    double* zT_29;
    unsigned int zT_31;
    zT_6F32B01B_Opt_235 zT_37 = {0};
    unsigned char zT_38;
    double* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_3E40CD83_Sand* zT_46;
    zT_C6536882_EU_532 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    double* zT_57;
    double* zT_58;
    unsigned int zT_59;
    int zT_60;
    double* zT_61;
    unsigned int zT_62;
    zT_ACF60AF6_Slice_zT_00435AEB_f zT_63;
    double* zT_64;
    unsigned int zT_65;
    unsigned int zT_70;
    double* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int new_cap;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    double* new_items_p;
    double item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((int)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((int)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_71 = *items;
    zT_72 = *len;
    zT_71[zT_72] = value;
    zT_73 = *len;
    zT_74 = 1;
    *len = (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74));
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    if ((int)(new_cap < (unsigned int)(zT_13 * zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = *len;
    zT_18 = 2;
    zT_19 = zT_17 * zT_18;
    new_cap = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = *capacity;
    zT_21 = 0;
    if ((int)(zT_20 > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = arena;
    zT_29 = *items;
    zT_31 = *capacity;
    zT_37 = zF_33A3D4F8_sandTryReallocInPla(zT_24, (unsigned char*)((unsigned char*)zT_29), (unsigned int)(zT_31 * (unsigned int)(8)), (unsigned int)(new_cap * (unsigned int)(8)), (unsigned int)(4));
    grown = zT_37;
    zT_38 = grown.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_46 = arena;
    zT_52 = zF_1395EB68_sandAlloc(zT_46, (unsigned int)((unsigned int)(8) * new_cap), (unsigned int)(4));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_39 = *items;
    zT_40 = *len;
    zT_39[zT_40] = value;
    zT_41 = *len;
    zT_42 = 1;
    *len = (unsigned int)(zT_41 + (unsigned int)((unsigned int)zT_42));
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_54 = zT_52.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_54;
    zT_57 = (double*)raw;
    new_items_p = zT_57;
    zT_58 = *items;
    zT_59 = *len;
    zT_60 = 0;
    zT_61 = zT_58 + zT_60;
    zT_62 = zT_59 - zT_60;
    zT_63.ptr = zT_61;
    zT_63.len = zT_62;
    zT_64 = zT_63.ptr;
    zT_65 = zT_63.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_65)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_64[i];
    new_items_p[i] = item;
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_14;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
}

/* fnProtoArrayListAppendInner */
void zF_F22CE022_fnProtoArrayListApp(zT_243D6A41_FnProto** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, zT_243D6A41_FnProto value) {
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_3E40CD83_Sand* zT_24;
    zT_243D6A41_FnProto* zT_29;
    unsigned int zT_31;
    zT_6F32B01B_Opt_235 zT_37 = {0};
    unsigned char zT_38;
    zT_243D6A41_FnProto* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_3E40CD83_Sand* zT_46;
    zT_C6536882_EU_532 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    zT_243D6A41_FnProto* zT_57;
    zT_243D6A41_FnProto* zT_58;
    unsigned int zT_59;
    int zT_60;
    zT_243D6A41_FnProto* zT_61;
    unsigned int zT_62;
    zT_91F8F99F_Slice_zT_243D6A41_F zT_63;
    zT_243D6A41_FnProto* zT_64;
    unsigned int zT_65;
    unsigned int zT_70;
    zT_243D6A41_FnProto* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    unsigned int new_cap;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    zT_243D6A41_FnProto* new_items_p;
    zT_243D6A41_FnProto item;
    unsigned int i;
    zT_5 = *len;
    zT_6 = *capacity;
    if ((int)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = *capacity;
    new_cap = zT_9;
    if ((int)(new_cap < (unsigned int)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_71 = *items;
    zT_72 = *len;
    zT_71[zT_72] = value;
    zT_73 = *len;
    zT_74 = 1;
    *len = (unsigned int)(zT_73 + (unsigned int)((unsigned int)zT_74));
    return;
    z_bb_3:
    zT_12 = 8;
    new_cap = zT_12;
    goto z_bb_4;
    z_bb_4:
    zT_13 = *len;
    zT_14 = 2;
    if ((int)(new_cap < (unsigned int)(zT_13 * zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = *len;
    zT_18 = 2;
    zT_19 = zT_17 * zT_18;
    new_cap = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = *capacity;
    zT_21 = 0;
    if ((int)(zT_20 > (unsigned int)zT_21)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = arena;
    zT_29 = *items;
    zT_31 = *capacity;
    zT_37 = zF_33A3D4F8_sandTryReallocInPla(zT_24, (unsigned char*)((unsigned char*)zT_29), (unsigned int)(zT_31 * (unsigned int)(16)), (unsigned int)(new_cap * (unsigned int)(16)), (unsigned int)(4));
    grown = zT_37;
    zT_38 = grown.has_value;
    if (zT_38) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_46 = arena;
    zT_52 = zF_1395EB68_sandAlloc(zT_46, (unsigned int)((unsigned int)(16) * new_cap), (unsigned int)(4));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *capacity = new_cap;
    zT_39 = *items;
    zT_40 = *len;
    zT_39[zT_40] = value;
    zT_41 = *len;
    zT_42 = 1;
    *len = (unsigned int)(zT_41 + (unsigned int)((unsigned int)zT_42));
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_54 = zT_52.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_54;
    zT_57 = (zT_243D6A41_FnProto*)raw;
    new_items_p = zT_57;
    zT_58 = *items;
    zT_59 = *len;
    zT_60 = 0;
    zT_61 = zT_58 + zT_60;
    zT_62 = zT_59 - zT_60;
    zT_63.ptr = zT_61;
    zT_63.len = zT_62;
    zT_64 = zT_63.ptr;
    zT_65 = zT_63.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_65)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_64[i];
    new_items_p[i] = item;
    zT_70 = i + (unsigned int)(1);
    i = zT_70;
    goto z_bb_14;
    z_bb_16:
    *items = new_items_p;
    *capacity = new_cap;
    goto z_bb_2;
}

/* astStoreInit */
zT_6B0A7D14_AstStore zF_D9F91436_astStoreInit(zT_3E40CD83_Sand* arena) {
    zT_22A7C88B_AstNode zT_2;
    zT_8143F551_AstKind zT_3;
    unsigned char zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore zT_11;
    zT_A318155C_anon_226697 zT_12;
    unsigned int zT_13;
    zT_01BE9D46_AstValuePool zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_24;
    unsigned char zT_25;
    unsigned int zT_26;
    zT_D21A8776_SpillStore zT_27 = {0};
    unsigned int zT_28;
    unsigned char zT_29;
    zT_01BE9D46_AstValuePool zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    int zT_40;
    unsigned char zT_41;
    unsigned int zT_42;
    zT_D21A8776_SpillStore zT_43 = {0};
    unsigned int zT_44;
    unsigned char zT_45;
    zT_01BE9D46_AstValuePool zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    int zT_56;
    unsigned char zT_57;
    unsigned int zT_58;
    zT_D21A8776_SpillStore zT_59 = {0};
    unsigned int zT_60;
    unsigned char zT_61;
    zT_A2BDBE24_anon_226712 zT_62;
    int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_98B93138_anon_226730 zT_66;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_9DBB77AE_anon_226721 zT_70;
    int zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_9CB93784_anon_226734 zT_74;
    unsigned int zT_75;
    zT_01BE9D46_AstValuePool zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    int zT_86;
    unsigned char zT_87;
    unsigned int zT_88;
    zT_D21A8776_SpillStore zT_89 = {0};
    unsigned int zT_90;
    unsigned char zT_91;
    zT_9ACA7D7F_anon_226748 zT_92;
    int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_D21A8776_SpillStore zT_99 = {0};
    unsigned int zT_100;
    zT_6B0A7D14_AstStore* zT_101;
    int zT_104;
    unsigned int zT_105;
    zT_6DD0D007_AstSlot zT_108;
    int zT_109;
    unsigned int zT_110;
    int zT_111;
    unsigned int zT_112;
    unsigned char zT_113;
    zT_6DD0D007_AstSlot* zT_114;
    unsigned int zT_115;
    unsigned int* zT_116;
    int zT_117;
    unsigned int zT_118;
    zT_6DD0D007_AstSlot* zT_120;
    zT_6DD0D007_AstSlot* zT_122;
    zT_6B0A7D14_AstStore* zT_123;
    zT_E2FE8472_NodeBlockInfo zT_127;
    unsigned int zT_128;
    unsigned char zT_129;
    unsigned int zT_130;
    zT_9ACA7D7F_anon_226748 zT_131;
    zT_E2FE8472_NodeBlockInfo* zT_132;
    int zT_133;
    unsigned int zT_134;
    unsigned int* zT_135;
    unsigned int zT_136;
    unsigned char* zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    unsigned int zT_140;
    int zT_142;
    unsigned int zT_143;
    unsigned int zT_145;
    unsigned char* zT_147;
    unsigned char zT_148;
    unsigned char* zT_149;
    int zT_150;
    unsigned int zT_151;
    unsigned int zT_153;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    int zT_159;
    unsigned int zT_160;
    unsigned int zT_162;
    unsigned char* zT_164;
    unsigned char zT_165;
    zT_01BE9D46_AstValuePool zT_166;
    unsigned char* zT_167;
    int zT_168;
    unsigned int zT_169;
    unsigned int zT_171;
    zT_6B0A7D14_AstStore* zT_172;
    zT_01BE9D46_AstValuePool* zT_173;
    unsigned char* zT_175;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_176;
    unsigned int zT_177;
    int zT_179;
    unsigned int zT_180;
    unsigned int zT_182;
    unsigned char* zT_184;
    unsigned char zT_185;
    zT_01BE9D46_AstValuePool zT_186;
    unsigned char* zT_187;
    int zT_188;
    unsigned int zT_189;
    unsigned int zT_191;
    zT_6B0A7D14_AstStore* zT_192;
    zT_01BE9D46_AstValuePool* zT_193;
    unsigned char* zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    int zT_199;
    unsigned int zT_200;
    unsigned int zT_202;
    unsigned char* zT_204;
    unsigned char zT_205;
    zT_01BE9D46_AstValuePool zT_206;
    unsigned char* zT_207;
    int zT_208;
    unsigned int zT_209;
    unsigned int zT_211;
    zT_6B0A7D14_AstStore* zT_212;
    zT_01BE9D46_AstValuePool* zT_213;
    unsigned char* zT_215;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_216;
    unsigned int zT_217;
    int zT_219;
    unsigned int zT_220;
    unsigned int zT_222;
    unsigned char* zT_224;
    unsigned char zT_225;
    zT_01BE9D46_AstValuePool zT_226;
    unsigned char* zT_227;
    int zT_228;
    unsigned int zT_229;
    unsigned int zT_231;
    zT_6B0A7D14_AstStore* zT_232;
    zT_01BE9D46_AstValuePool* zT_233;
    zT_6B0A7D14_AstStore* zT_234;
    zT_22A7C88B_AstNode zT_235;
    zT_6B0A7D14_AstStore* zT_239;
    zT_01BE9D46_AstValuePool* zT_240;
    zT_6B0A7D14_AstStore* zT_243;
    unsigned int zT_246 = 0;
    zT_22A7C88B_AstNode null_node;
    zT_6B0A7D14_AstStore store;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u default_path;
    unsigned int pi;
    zT_8F083A69_Slice_zT_0B42B2F8_u d_id;
    unsigned int di;
    zT_8F083A69_Slice_zT_0B42B2F8_u d_iv;
    unsigned int dvi;
    zT_8F083A69_Slice_zT_0B42B2F8_u d_ec;
    unsigned int deci;
    zT_8F083A69_Slice_zT_0B42B2F8_u d_er;
    unsigned int deri;
    zT_3 = zT_8143F551_AstKind_err;
    zT_2.kind = zT_3;
    zT_4 = 0;
    zT_2.flags = zT_4;
    zT_5 = 0;
    zT_2.span_start = zT_5;
    zT_6 = 0;
    zT_2.span_len = zT_6;
    zT_7 = 0;
    zT_2.child_0 = zT_7;
    zT_8 = 0;
    zT_2.child_1 = zT_8;
    zT_9 = 0;
    zT_2.child_2 = zT_9;
    null_node = zT_2;
    zT_13 = 0;
    zT_12.len = zT_13;
    zT_11.nodes = zT_12;
    zT_15 = 0;
    zT_14.len = zT_15;
    zT_16 = 0;
    zT_14.elem_bytes = zT_16;
    zT_17 = 0;
    zT_14.elems_per_block = zT_17;
    zT_18 = 0;
    zT_14.block_shift = zT_18;
    zT_19 = 0;
    zT_14.block_mask = zT_19;
    zT_20 = 0;
    zT_14.head_buf = (unsigned char*)zT_20;
    zT_21 = 0;
    zT_14.head_cap = zT_21;
    zT_22 = 0;
    zT_14.head_elems = zT_22;
    zT_23 = 0;
    zT_14.cur_block = zT_23;
    zT_24 = 0;
    zT_14.cache_buf = (unsigned char*)zT_24;
    zT_25 = 0;
    zT_14.cache_allocated = zT_25;
    zT_26 = 0;
    zT_14.ring_next = zT_26;
    zT_27 = zF_22C79E6C_spillStoreInit();
    zT_14.spill = zT_27;
    zT_28 = 0;
    zT_14.spill_path_len = zT_28;
    zT_29 = 1;
    zT_14.is_extra = zT_29;
    zT_11.extra_children = zT_14;
    zT_31 = 0;
    zT_30.len = zT_31;
    zT_32 = 0;
    zT_30.elem_bytes = zT_32;
    zT_33 = 0;
    zT_30.elems_per_block = zT_33;
    zT_34 = 0;
    zT_30.block_shift = zT_34;
    zT_35 = 0;
    zT_30.block_mask = zT_35;
    zT_36 = 0;
    zT_30.head_buf = (unsigned char*)zT_36;
    zT_37 = 0;
    zT_30.head_cap = zT_37;
    zT_38 = 0;
    zT_30.head_elems = zT_38;
    zT_39 = 0;
    zT_30.cur_block = zT_39;
    zT_40 = 0;
    zT_30.cache_buf = (unsigned char*)zT_40;
    zT_41 = 0;
    zT_30.cache_allocated = zT_41;
    zT_42 = 0;
    zT_30.ring_next = zT_42;
    zT_43 = zF_22C79E6C_spillStoreInit();
    zT_30.spill = zT_43;
    zT_44 = 0;
    zT_30.spill_path_len = zT_44;
    zT_45 = 0;
    zT_30.is_extra = zT_45;
    zT_11.identifiers = zT_30;
    zT_47 = 0;
    zT_46.len = zT_47;
    zT_48 = 0;
    zT_46.elem_bytes = zT_48;
    zT_49 = 0;
    zT_46.elems_per_block = zT_49;
    zT_50 = 0;
    zT_46.block_shift = zT_50;
    zT_51 = 0;
    zT_46.block_mask = zT_51;
    zT_52 = 0;
    zT_46.head_buf = (unsigned char*)zT_52;
    zT_53 = 0;
    zT_46.head_cap = zT_53;
    zT_54 = 0;
    zT_46.head_elems = zT_54;
    zT_55 = 0;
    zT_46.cur_block = zT_55;
    zT_56 = 0;
    zT_46.cache_buf = (unsigned char*)zT_56;
    zT_57 = 0;
    zT_46.cache_allocated = zT_57;
    zT_58 = 0;
    zT_46.ring_next = zT_58;
    zT_59 = zF_22C79E6C_spillStoreInit();
    zT_46.spill = zT_59;
    zT_60 = 0;
    zT_46.spill_path_len = zT_60;
    zT_61 = 0;
    zT_46.is_extra = zT_61;
    zT_11.int_values = zT_46;
    zT_63 = 0;
    zT_62.items = (double*)zT_63;
    zT_64 = 0;
    zT_62.len = zT_64;
    zT_65 = 0;
    zT_62.capacity = zT_65;
    zT_11.float_values = zT_62;
    zT_67 = 0;
    zT_66.items = (zT_243D6A41_FnProto*)zT_67;
    zT_68 = 0;
    zT_66.len = zT_68;
    zT_69 = 0;
    zT_66.capacity = zT_69;
    zT_11.fn_protos = zT_66;
    zT_71 = 0;
    zT_70.items = (unsigned int*)zT_71;
    zT_72 = 0;
    zT_70.len = zT_72;
    zT_73 = 0;
    zT_70.capacity = zT_73;
    zT_11.string_values = zT_70;
    zT_75 = 0;
    zT_74.len = zT_75;
    zT_11.payload = zT_74;
    zT_77 = 0;
    zT_76.len = zT_77;
    zT_78 = 0;
    zT_76.elem_bytes = zT_78;
    zT_79 = 0;
    zT_76.elems_per_block = zT_79;
    zT_80 = 0;
    zT_76.block_shift = zT_80;
    zT_81 = 0;
    zT_76.block_mask = zT_81;
    zT_82 = 0;
    zT_76.head_buf = (unsigned char*)zT_82;
    zT_83 = 0;
    zT_76.head_cap = zT_83;
    zT_84 = 0;
    zT_76.head_elems = zT_84;
    zT_85 = 0;
    zT_76.cur_block = zT_85;
    zT_86 = 0;
    zT_76.cache_buf = (unsigned char*)zT_86;
    zT_87 = 0;
    zT_76.cache_allocated = zT_87;
    zT_88 = 0;
    zT_76.ring_next = zT_88;
    zT_89 = zF_22C79E6C_spillStoreInit();
    zT_76.spill = zT_89;
    zT_90 = 0;
    zT_76.spill_path_len = zT_90;
    zT_91 = 1;
    zT_76.is_extra = zT_91;
    zT_11.extra_ranges = zT_76;
    zT_11.allocator = arena;
    zT_93 = 0;
    zT_92.items = (zT_E2FE8472_NodeBlockInfo*)zT_93;
    zT_94 = 0;
    zT_92.len = zT_94;
    zT_95 = 0;
    zT_92.capacity = zT_95;
    zT_11.block_table = zT_92;
    zT_96 = 0;
    zT_11.cur_block = zT_96;
    zT_97 = 0;
    zT_11.cur_block_len = zT_97;
    zT_98 = 1;
    zT_11.ring_next = zT_98;
    zT_99 = zF_22C79E6C_spillStoreInit();
    zT_11.spill = zT_99;
    zT_100 = 0;
    zT_11.spill_path_len = zT_100;
    store = zT_11;
    zT_101 = &store;
    zF_A0C14FAA_astStoreInitValuePo(zT_101);
    zT_104 = 0;
    zT_105 = (unsigned int)zT_104;
    si = zT_105;
    goto z_bb_1;
    z_bb_1:
    if ((int)(si < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_109 = 0;
    zT_108.node_buf = (zT_22A7C88B_AstNode*)zT_109;
    zT_110 = 0;
    zT_108.node_cap = zT_110;
    zT_111 = 0;
    zT_108.payload_buf = (unsigned int*)zT_111;
    zT_112 = 0;
    zT_108.payload_cap = zT_112;
    zT_113 = 0;
    zT_108.in_use = zT_113;
    zT_114 = store.slots;
    zT_114[si] = zT_108;
    zT_115 = 0;
    zT_116 = store.slot_block;
    zT_116[si] = zT_115;
    goto z_bb_4;
    z_bb_3:
    zT_120 = store.slots;
    zT_122 = zT_120 + (unsigned int)(0);
    zT_122->in_use = (unsigned char)(1);
    zT_123 = &store;
    zF_1D4F4DCE_astBlockTableEnsure(zT_123, (unsigned int)(1));
    zT_128 = 0;
    zT_127.disk_off = zT_128;
    zT_129 = 1;
    zT_127.resident = zT_129;
    zT_130 = 0;
    zT_127.slot = zT_130;
    zT_131 = store.block_table;
    zT_132 = zT_131.items;
    zT_133 = 0;
    zT_132[zT_133] = zT_127;
    zT_134 = 0;
    zT_135 = store.slot_block;
    zT_136 = 0;
    zT_135[zT_136] = zT_134;
    zT_138 = ".zig1_ast.tmp";
    zT_140 = 13;
    zT_139.ptr = zT_138;
    zT_139.len = zT_140;
    default_path = zT_139;
    zT_142 = 0;
    zT_143 = (unsigned int)zT_142;
    pi = zT_143;
    goto z_bb_5;
    z_bb_4:
    zT_117 = 1;
    zT_118 = si + zT_117;
    si = zT_118;
    goto z_bb_1;
    z_bb_5:
    zT_145 = default_path.len;
    if ((int)(pi < zT_145)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_147 = default_path.ptr;
    zT_148 = zT_147[pi];
    zT_149 = store.spill_path;
    zT_149[pi] = zT_148;
    goto z_bb_8;
    z_bb_7:
    zT_153 = default_path.len;
    store.spill_path_len = zT_153;
    zT_155 = ".zig1_side.tmp";
    zT_157 = 14;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    d_id = zT_156;
    zT_159 = 0;
    zT_160 = (unsigned int)zT_159;
    di = zT_160;
    goto z_bb_9;
    z_bb_8:
    zT_150 = 1;
    zT_151 = pi + zT_150;
    pi = zT_151;
    goto z_bb_5;
    z_bb_9:
    zT_162 = d_id.len;
    if ((int)(di < zT_162)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_164 = d_id.ptr;
    zT_165 = zT_164[di];
    zT_166 = store.identifiers;
    zT_167 = zT_166.spill_path;
    zT_167[di] = zT_165;
    goto z_bb_12;
    z_bb_11:
    zT_171 = d_id.len;
    zT_172 = &store;
    zT_173 = &zT_172->identifiers;
    zT_173->spill_path_len = zT_171;
    zT_175 = ".zig1_side_iv.tmp";
    zT_177 = 17;
    zT_176.ptr = zT_175;
    zT_176.len = zT_177;
    d_iv = zT_176;
    zT_179 = 0;
    zT_180 = (unsigned int)zT_179;
    dvi = zT_180;
    goto z_bb_13;
    z_bb_12:
    zT_168 = 1;
    zT_169 = di + zT_168;
    di = zT_169;
    goto z_bb_9;
    z_bb_13:
    zT_182 = d_iv.len;
    if ((int)(dvi < zT_182)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_184 = d_iv.ptr;
    zT_185 = zT_184[dvi];
    zT_186 = store.int_values;
    zT_187 = zT_186.spill_path;
    zT_187[dvi] = zT_185;
    goto z_bb_16;
    z_bb_15:
    zT_191 = d_iv.len;
    zT_192 = &store;
    zT_193 = &zT_192->int_values;
    zT_193->spill_path_len = zT_191;
    zT_195 = ".zig1_extra_ec.tmp";
    zT_197 = 18;
    zT_196.ptr = zT_195;
    zT_196.len = zT_197;
    d_ec = zT_196;
    zT_199 = 0;
    zT_200 = (unsigned int)zT_199;
    deci = zT_200;
    goto z_bb_17;
    z_bb_16:
    zT_188 = 1;
    zT_189 = dvi + zT_188;
    dvi = zT_189;
    goto z_bb_13;
    z_bb_17:
    zT_202 = d_ec.len;
    if ((int)(deci < zT_202)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_204 = d_ec.ptr;
    zT_205 = zT_204[deci];
    zT_206 = store.extra_children;
    zT_207 = zT_206.spill_path;
    zT_207[deci] = zT_205;
    goto z_bb_20;
    z_bb_19:
    zT_211 = d_ec.len;
    zT_212 = &store;
    zT_213 = &zT_212->extra_children;
    zT_213->spill_path_len = zT_211;
    zT_215 = ".zig1_extra_er.tmp";
    zT_217 = 18;
    zT_216.ptr = zT_215;
    zT_216.len = zT_217;
    d_er = zT_216;
    zT_219 = 0;
    zT_220 = (unsigned int)zT_219;
    deri = zT_220;
    goto z_bb_21;
    z_bb_20:
    zT_208 = 1;
    zT_209 = deci + zT_208;
    deci = zT_209;
    goto z_bb_17;
    z_bb_21:
    zT_222 = d_er.len;
    if ((int)(deri < zT_222)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_224 = d_er.ptr;
    zT_225 = zT_224[deri];
    zT_226 = store.extra_ranges;
    zT_227 = zT_226.spill_path;
    zT_227[deri] = zT_225;
    goto z_bb_24;
    z_bb_23:
    zT_231 = d_er.len;
    zT_232 = &store;
    zT_233 = &zT_232->extra_ranges;
    zT_233->spill_path_len = zT_231;
    zT_234 = &store;
    zT_235 = null_node;
    zF_3A477168_astStoreNodeAppend(zT_234, zT_235, (unsigned int)(0));
    zT_239 = &store;
    zT_243 = &store;
    zT_240 = &zT_243->extra_ranges;
    zT_246 = zF_B73DE9D0_valuePoolAppend(zT_239, zT_240, (zT_79FAE712_u64)(0));
    (void)zT_246;
    return store;
    z_bb_24:
    zT_228 = 1;
    zT_229 = deri + zT_228;
    deri = zT_229;
    goto z_bb_21;
}

/* astStoreInitValuePools */
void zF_A0C14FAA_astStoreInitValuePo(zT_6B0A7D14_AstStore* store) {
    zT_01BE9D46_AstValuePool* zT_1;
    zT_01BE9D46_AstValuePool* zT_5;
    zT_01BE9D46_AstValuePool* zT_9;
    zT_01BE9D46_AstValuePool* zT_13;
    zT_01BE9D46_AstValuePool* zT_18;
    zT_01BE9D46_AstValuePool* zT_20;
    zT_1 = &store->identifiers;
    zF_F58FD6FA_valuePoolInit(zT_1, (unsigned int)(4));
    zT_5 = &store->int_values;
    zF_F58FD6FA_valuePoolInit(zT_5, (unsigned int)(8));
    zT_9 = &store->extra_children;
    zF_F58FD6FA_valuePoolInit(zT_9, (unsigned int)(4));
    zT_13 = &store->extra_ranges;
    zF_F58FD6FA_valuePoolInit(zT_13, (unsigned int)(8));
    zT_18 = &store->extra_children;
    zT_18->is_extra = (unsigned char)(1);
    zT_20 = &store->extra_ranges;
    zT_20->is_extra = (unsigned char)(1);
    return;
}

/* astStoreSetSpillPath */
void zF_2A507339_astStoreSetSpillPat(zT_6B0A7D14_AstStore* store, zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_8;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = path.len;
    if ((int)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_11 = path.ptr;
    zT_12 = zT_11[i];
    zT_13 = store->spill_path;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    store->spill_path_len = i;
    zT_16 = 0;
    zT_17 = store->spill_path;
    zT_17[i] = zT_16;
    return;
    z_bb_4:
    zT_14 = 1;
    zT_15 = i + zT_14;
    i = zT_15;
    goto z_bb_1;
    z_bb_5:
    zT_8 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* astStoreCloseSpill */
void zF_21027FAE_astStoreCloseSpill(zT_6B0A7D14_AstStore* store) {
    zT_D21A8776_SpillStore* zT_1;
    zT_6B0A7D14_AstStore* zT_3;
    zT_01BE9D46_AstValuePool* zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    zT_01BE9D46_AstValuePool* zT_7;
    zT_6B0A7D14_AstStore* zT_9;
    zT_01BE9D46_AstValuePool* zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    zT_01BE9D46_AstValuePool* zT_13;
    zT_1 = &store->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    zT_3 = store;
    zT_4 = &store->identifiers;
    zF_131F3CDC_valuePoolClose(zT_3, zT_4);
    zT_6 = store;
    zT_7 = &store->int_values;
    zF_131F3CDC_valuePoolClose(zT_6, zT_7);
    zT_9 = store;
    zT_10 = &store->extra_children;
    zF_131F3CDC_valuePoolClose(zT_9, zT_10);
    zT_12 = store;
    zT_13 = &store->extra_ranges;
    zF_131F3CDC_valuePoolClose(zT_12, zT_13);
    return;
}

/* valuePoolInit */
void zF_F58FD6FA_valuePoolInit(zT_01BE9D46_AstValuePool* p, unsigned int elem_bytes) {
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int* zT_31;
    int zT_32;
    unsigned int zT_33;
    zT_D21A8776_SpillStore zT_35 = {0};
    unsigned int shift_tmp;
    unsigned int si;
    p->len = (unsigned int)(0);
    p->elem_bytes = elem_bytes;
    p->elems_per_block = (unsigned int)((unsigned int)(4096) / elem_bytes);
    p->block_shift = (unsigned int)(0);
    zT_7 = p->elems_per_block;
    zT_9 = zT_7 - (unsigned int)(1);
    shift_tmp = zT_9;
    goto z_bb_1;
    z_bb_1:
    if ((int)(shift_tmp != (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_12 = p->block_shift;
    p->block_shift = (unsigned int)(zT_12 + (unsigned int)(1));
    goto z_bb_4;
    z_bb_3:
    zT_17 = p->elems_per_block;
    p->block_mask = (unsigned int)(zT_17 - (unsigned int)(1));
    p->head_cap = (unsigned int)(0);
    p->head_elems = (unsigned int)(0);
    p->cur_block = (unsigned int)(0);
    p->cache_allocated = (unsigned char)(0);
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    si = zT_26;
    goto z_bb_5;
    z_bb_4:
    zT_16 = shift_tmp >> (unsigned int)(1);
    shift_tmp = zT_16;
    goto z_bb_1;
    z_bb_5:
    if ((int)(si < (unsigned int)(8))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_29 = 4294967295u;
    zT_30 = (unsigned int)zT_29;
    zT_31 = p->slot_block;
    zT_31[si] = zT_30;
    goto z_bb_8;
    z_bb_7:
    p->ring_next = (unsigned int)(0);
    zT_35 = zF_22C79E6C_spillStoreInit();
    p->spill = zT_35;
    p->spill_path_len = (unsigned int)(0);
    p->is_extra = (unsigned char)(0);
    return;
    z_bb_8:
    zT_32 = 1;
    zT_33 = si + zT_32;
    si = zT_33;
    goto z_bb_5;
}

/* astStoreSetValuePoolSpillPath */
void zF_35B9B6EC_astStoreSetValuePoo(zT_6B0A7D14_AstStore* store, unsigned int which, zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    zT_01BE9D46_AstValuePool* zT_4 = 0;
    zT_01BE9D46_AstValuePool* zT_7;
    zT_01BE9D46_AstValuePool* zT_10;
    zT_01BE9D46_AstValuePool* zT_13;
    zT_01BE9D46_AstValuePool* zT_14;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    int zT_21;
    unsigned char* zT_24;
    unsigned char zT_25;
    unsigned char* zT_26;
    int zT_27;
    unsigned int zT_28;
    unsigned char zT_29;
    unsigned char* zT_30;
    zT_01BE9D46_AstValuePool* p;
    unsigned int i;
    p = zT_4;
    if ((int)(which == (unsigned int)(0))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_7 = &store->identifiers;
    p = zT_7;
    goto z_bb_2;
    z_bb_2:
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    i = zT_17;
    goto z_bb_10;
    z_bb_3:
    if ((int)(which == (unsigned int)(1))) goto z_bb_4; else goto z_bb_6;
    z_bb_4:
    zT_10 = &store->int_values;
    p = zT_10;
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    if ((int)(which == (unsigned int)(2))) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_13 = &store->extra_children;
    p = zT_13;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_14 = &store->extra_ranges;
    p = zT_14;
    goto z_bb_8;
    z_bb_10:
    zT_19 = path.len;
    if ((int)(i < zT_19)) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    zT_24 = path.ptr;
    zT_25 = zT_24[i];
    zT_26 = p->spill_path;
    zT_26[i] = zT_25;
    goto z_bb_13;
    z_bb_12:
    p->spill_path_len = i;
    zT_29 = 0;
    zT_30 = p->spill_path;
    zT_30[i] = zT_29;
    return;
    z_bb_13:
    zT_27 = 1;
    zT_28 = i + zT_27;
    i = zT_28;
    goto z_bb_10;
    z_bb_14:
    zT_21 = i < (unsigned int)(511);
    goto z_bb_16;
    z_bb_15:
    zT_21 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_21) goto z_bb_11; else goto z_bb_12;
}

/* valuePoolOpen */
void zF_E407C3F0_valuePoolOpen(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    zT_D21A8776_SpillStore zT_2;
    unsigned char zT_3;
    zT_0426DCE7_SpillBackend zT_9;
    unsigned char zT_10;
    zT_0426DCE7_SpillBackend zT_17 = 0;
    zT_0426DCE7_SpillBackend zT_22 = 0;
    zT_D21A8776_SpillStore* zT_23;
    zT_0426DCE7_SpillBackend zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_3E40CD83_Sand* zT_26;
    unsigned char* zT_27;
    unsigned char* zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned char* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_0426DCE7_SpillBackend backend;
    zT_2 = p->spill;
    zT_3 = zT_2.opened;
    if ((int)(zT_3 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = zT_0426DCE7_SpillBackend_disk;
    backend = zT_9;
    zT_10 = p->is_extra;
    if ((int)(zT_10 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_17 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_extra));
    backend = zT_17;
    goto z_bb_4;
    z_bb_4:
    zT_23 = &p->spill;
    zT_24 = backend;
    zT_29 = p->spill_path;
    zT_30 = p->spill_path_len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_25 = zT_34;
    zT_26 = store->allocator;
    zT_36 = "w+b";
    zT_27 = zT_36;
    zF_8AF94F71_spillOpen(zT_23, zT_24, zT_25, zT_26, zT_27);
    return;
    z_bb_5:
    zT_22 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_side));
    backend = zT_22;
    goto z_bb_4;
}

/* valuePoolEnsureHead */
void zF_76A14F48_valuePoolEnsureHead(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    unsigned int zT_2;
    zT_3E40CD83_Sand* zT_6;
    zT_C6536882_EU_532 zT_12 = {0};
    unsigned char zT_13;
    unsigned char* zT_14;
    unsigned char* raw;
    zT_2 = p->head_cap;
    if ((int)(zT_2 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = store->allocator;
    zT_12 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(4096), (unsigned int)(4));
    zT_13 = zT_12.is_error;
    if (zT_13) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_14 = zT_12.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_14;
    p->head_buf = raw;
    p->head_cap = (unsigned int)(4096);
    return;
}

/* valuePoolAppend */
unsigned int zF_B73DE9D0_valuePoolAppend(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p, zT_79FAE712_u64 value) {
    zT_6B0A7D14_AstStore* zT_3;
    zT_01BE9D46_AstValuePool* zT_4;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_6B0A7D14_AstStore* zT_16;
    zT_01BE9D46_AstValuePool* zT_17;
    unsigned int zT_19;
    unsigned int zT_21;
    zT_D21A8776_SpillStore* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned char* zT_26;
    int zT_28;
    unsigned char* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_44;
    unsigned char* zT_45;
    unsigned char zT_51;
    unsigned char* zT_52;
    int zT_53;
    unsigned int zT_54;
    unsigned char zT_60;
    unsigned char* zT_61;
    int zT_62;
    unsigned int zT_63;
    unsigned char zT_69;
    unsigned char* zT_70;
    int zT_71;
    unsigned int zT_72;
    unsigned char zT_76;
    unsigned char* zT_77;
    unsigned char zT_83;
    unsigned char* zT_84;
    int zT_85;
    unsigned int zT_86;
    unsigned char zT_92;
    unsigned char* zT_93;
    int zT_94;
    unsigned int zT_95;
    unsigned char zT_101;
    unsigned char* zT_102;
    int zT_103;
    unsigned int zT_104;
    unsigned char zT_110;
    unsigned char* zT_111;
    int zT_112;
    unsigned int zT_113;
    unsigned char zT_119;
    unsigned char* zT_120;
    int zT_121;
    unsigned int zT_122;
    unsigned char zT_128;
    unsigned char* zT_129;
    int zT_130;
    unsigned int zT_131;
    unsigned char zT_137;
    unsigned char* zT_138;
    int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    int zT_142;
    unsigned int zT_145;
    int zT_146;
    unsigned int elem_idx;
    unsigned int block;
    unsigned int off;
    unsigned int disk_off;
    unsigned int byte_off;
    zT_3 = store;
    zT_4 = p;
    zF_76A14F48_valuePoolEnsureHead(zT_3, zT_4);
    zT_6 = p->len;
    zT_7 = (unsigned int)zT_6;
    elem_idx = zT_7;
    zT_9 = p->elems_per_block;
    zT_10 = elem_idx / zT_9;
    block = zT_10;
    zT_12 = p->elems_per_block;
    zT_13 = elem_idx % zT_12;
    off = zT_13;
    zT_14 = p->cur_block;
    if ((int)(block != zT_14)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = store;
    zT_17 = p;
    zF_E407C3F0_valuePoolOpen(zT_16, zT_17);
    zT_19 = p->cur_block;
    zT_21 = zT_19 * (unsigned int)(4096);
    disk_off = zT_21;
    zT_22 = &p->spill;
    zT_23 = disk_off;
    zT_26 = p->head_buf;
    zT_28 = 0;
    zT_29 = zT_26 + zT_28;
    zT_30 = (unsigned int)(4096) - zT_28;
    zT_31.ptr = zT_29;
    zT_31.len = zT_30;
    zT_24 = zT_31;
    zF_BFB33631_spillWriteAt(zT_22, zT_23, zT_24);
    p->cur_block = block;
    p->head_elems = (unsigned int)(0);
    goto z_bb_2;
    z_bb_2:
    zT_35 = p->elem_bytes;
    zT_37 = (unsigned int)((unsigned int)off) * (unsigned int)((unsigned int)zT_35);
    byte_off = zT_37;
    zT_38 = p->elem_bytes;
    if ((int)(zT_38 == (unsigned int)(4))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_44 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)(value & (zT_79FAE712_u64)(255)));
    zT_45 = p->head_buf;
    zT_45[byte_off] = zT_44;
    zT_51 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(8)) & (zT_79FAE712_u64)(255)));
    zT_52 = p->head_buf;
    zT_53 = 1;
    zT_54 = byte_off + zT_53;
    zT_52[zT_54] = zT_51;
    zT_60 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(16)) & (zT_79FAE712_u64)(255)));
    zT_61 = p->head_buf;
    zT_62 = 2;
    zT_63 = byte_off + zT_62;
    zT_61[zT_63] = zT_60;
    zT_69 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(24)) & (zT_79FAE712_u64)(255)));
    zT_70 = p->head_buf;
    zT_71 = 3;
    zT_72 = byte_off + zT_71;
    zT_70[zT_72] = zT_69;
    goto z_bb_4;
    z_bb_4:
    zT_141 = p->head_elems;
    zT_142 = 1;
    p->head_elems = (unsigned int)(zT_141 + (unsigned int)((unsigned int)zT_142));
    zT_145 = p->len;
    zT_146 = 1;
    p->len = (unsigned int)(zT_145 + (unsigned int)((unsigned int)zT_146));
    return elem_idx;
    z_bb_5:
    zT_76 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)(value & (zT_79FAE712_u64)(255)));
    zT_77 = p->head_buf;
    zT_77[byte_off] = zT_76;
    zT_83 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(8)) & (zT_79FAE712_u64)(255)));
    zT_84 = p->head_buf;
    zT_85 = 1;
    zT_86 = byte_off + zT_85;
    zT_84[zT_86] = zT_83;
    zT_92 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(16)) & (zT_79FAE712_u64)(255)));
    zT_93 = p->head_buf;
    zT_94 = 2;
    zT_95 = byte_off + zT_94;
    zT_93[zT_95] = zT_92;
    zT_101 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(24)) & (zT_79FAE712_u64)(255)));
    zT_102 = p->head_buf;
    zT_103 = 3;
    zT_104 = byte_off + zT_103;
    zT_102[zT_104] = zT_101;
    zT_110 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(32)) & (zT_79FAE712_u64)(255)));
    zT_111 = p->head_buf;
    zT_112 = 4;
    zT_113 = byte_off + zT_112;
    zT_111[zT_113] = zT_110;
    zT_119 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(40)) & (zT_79FAE712_u64)(255)));
    zT_120 = p->head_buf;
    zT_121 = 5;
    zT_122 = byte_off + zT_121;
    zT_120[zT_122] = zT_119;
    zT_128 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(48)) & (zT_79FAE712_u64)(255)));
    zT_129 = p->head_buf;
    zT_130 = 6;
    zT_131 = byte_off + zT_130;
    zT_129[zT_131] = zT_128;
    zT_137 = (unsigned char)(unsigned int)((unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(value >> (zT_79FAE712_u64)(56)) & (zT_79FAE712_u64)(255)));
    zT_138 = p->head_buf;
    zT_139 = 7;
    zT_140 = byte_off + zT_139;
    zT_138[zT_140] = zT_137;
    goto z_bb_4;
}

/* valuePoolEnsureCache */
void zF_82730D0C_valuePoolEnsureCach(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    unsigned char zT_2;
    zT_3E40CD83_Sand* zT_6;
    zT_C6536882_EU_532 zT_14 = {0};
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned char* raw;
    zT_2 = p->cache_allocated;
    if ((int)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = store->allocator;
    zT_14 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(32768), (unsigned int)(4));
    zT_15 = zT_14.is_error;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_16 = zT_14.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_16;
    p->cache_buf = raw;
    p->cache_allocated = (unsigned char)(1);
    return;
}

/* valuePoolCacheSlot */
unsigned int zF_73B68926_valuePoolCacheSlot(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p, unsigned int block) {
    zT_6B0A7D14_AstStore* zT_3;
    zT_01BE9D46_AstValuePool* zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_13;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    zT_01BE9D46_AstValuePool* zT_24;
    unsigned int zT_27;
    unsigned char* zT_29;
    unsigned char* zT_33;
    zT_D21A8776_SpillStore* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    int zT_39;
    unsigned char* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int* zT_43;
    unsigned int s;
    unsigned int v;
    unsigned int disk_off;
    unsigned char* base;
    zT_3 = store;
    zT_4 = p;
    zF_82730D0C_valuePoolEnsureCach(zT_3, zT_4);
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    s = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((int)(s < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = p->slot_block;
    zT_11 = zT_10[s];
    if ((int)(zT_11 == block)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_16 = p->ring_next;
    v = zT_16;
    p->ring_next = (unsigned int)(v + (unsigned int)(1));
    zT_19 = p->ring_next;
    if ((int)(zT_19 >= (unsigned int)(8))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_13 = 1;
    zT_14 = s + zT_13;
    s = zT_14;
    goto z_bb_1;
    z_bb_5:
    return s;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    p->ring_next = (unsigned int)(0);
    goto z_bb_8;
    z_bb_8:
    zT_23 = store;
    zT_24 = p;
    zF_E407C3F0_valuePoolOpen(zT_23, zT_24);
    zT_27 = block * (unsigned int)(4096);
    disk_off = zT_27;
    zT_29 = p->cache_buf;
    zT_33 = zT_29 + (unsigned int)((unsigned int)((unsigned int)v) * (unsigned int)(4096));
    base = zT_33;
    zT_34 = &p->spill;
    zT_35 = disk_off;
    zT_39 = 0;
    zT_40 = base + zT_39;
    zT_41 = (unsigned int)(4096) - zT_39;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    zT_36 = zT_42;
    zF_E9F67450_spillReadAt(zT_34, zT_35, zT_36);
    zT_43 = p->slot_block;
    zT_43[v] = block;
    return v;
}

/* valuePoolGetValue */
zT_79FAE712_u64 zF_FDA4EEAD_valuePoolGetValue(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p, unsigned int elem_idx) {
    unsigned int zT_3;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_15;
    unsigned int zT_17;
    unsigned char* zT_19 = 0;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    unsigned char* zT_26;
    zT_6B0A7D14_AstStore* zT_28;
    zT_01BE9D46_AstValuePool* zT_29;
    unsigned int zT_30;
    unsigned int zT_31 = 0;
    unsigned char* zT_32;
    unsigned char* zT_36;
    unsigned char zT_38;
    zT_79FAE712_u64 zT_39;
    unsigned int zT_40;
    int zT_43;
    unsigned int zT_44;
    unsigned char zT_45;
    zT_79FAE712_u64 zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_79FAE712_u64 zT_56;
    int zT_57;
    unsigned int zT_58;
    unsigned char zT_59;
    zT_79FAE712_u64 zT_63;
    int zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_79FAE712_u64 zT_70;
    int zT_71;
    unsigned int zT_72;
    unsigned char zT_73;
    zT_79FAE712_u64 zT_77;
    int zT_78;
    unsigned int zT_79;
    unsigned char zT_80;
    zT_79FAE712_u64 zT_84;
    int zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    zT_79FAE712_u64 zT_91;
    int zT_92;
    unsigned int zT_93;
    unsigned char zT_94;
    zT_79FAE712_u64 zT_98;
    int zT_99;
    unsigned int zT_100;
    unsigned char zT_101;
    zT_79FAE712_u64 zT_105;
    int zT_106;
    unsigned int zT_107;
    unsigned char zT_108;
    zT_79FAE712_u64 zT_112;
    unsigned int block;
    unsigned int off;
    unsigned int byte_off;
    unsigned char* buf;
    zT_79FAE712_u64 v;
    unsigned int slot;
    zT_3 = p->len;
    if ((int)(elem_idx >= (unsigned int)((unsigned int)zT_3))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_79FAE712_u64)(0);
    z_bb_2:
    zT_8 = p->block_shift;
    zT_9 = elem_idx >> zT_8;
    block = zT_9;
    zT_11 = p->block_mask;
    zT_12 = elem_idx & zT_11;
    off = zT_12;
    zT_15 = p->elem_bytes;
    zT_17 = (unsigned int)((unsigned int)off) * (unsigned int)((unsigned int)zT_15);
    byte_off = zT_17;
    buf = zT_19;
    zT_20 = p->cur_block;
    if ((int)(block == zT_20)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_23 = p->head_cap;
    zT_22 = zT_23 != (unsigned int)(0);
    goto z_bb_5;
    z_bb_4:
    zT_22 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_22) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_26 = p->head_buf;
    buf = zT_26;
    goto z_bb_7;
    z_bb_7:
    zT_38 = buf[byte_off];
    zT_39 = (zT_79FAE712_u64)zT_38;
    v = zT_39;
    zT_40 = p->elem_bytes;
    if ((int)(zT_40 == (unsigned int)(8))) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    zT_28 = store;
    zT_29 = p;
    zT_30 = block;
    zT_31 = zF_73B68926_valuePoolCacheSlot(zT_28, zT_29, zT_30);
    slot = zT_31;
    zT_32 = p->cache_buf;
    zT_36 = zT_32 + (unsigned int)((unsigned int)((unsigned int)slot) * (unsigned int)(4096));
    buf = zT_36;
    goto z_bb_7;
    z_bb_9:
    zT_43 = 1;
    zT_44 = byte_off + zT_43;
    zT_45 = buf[zT_44];
    zT_49 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_45) << (zT_79FAE712_u64)(8));
    v = zT_49;
    zT_50 = 2;
    zT_51 = byte_off + zT_50;
    zT_52 = buf[zT_51];
    zT_56 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_52) << (zT_79FAE712_u64)(16));
    v = zT_56;
    zT_57 = 3;
    zT_58 = byte_off + zT_57;
    zT_59 = buf[zT_58];
    zT_63 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_59) << (zT_79FAE712_u64)(24));
    v = zT_63;
    zT_64 = 4;
    zT_65 = byte_off + zT_64;
    zT_66 = buf[zT_65];
    zT_70 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_66) << (zT_79FAE712_u64)(32));
    v = zT_70;
    zT_71 = 5;
    zT_72 = byte_off + zT_71;
    zT_73 = buf[zT_72];
    zT_77 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_73) << (zT_79FAE712_u64)(40));
    v = zT_77;
    zT_78 = 6;
    zT_79 = byte_off + zT_78;
    zT_80 = buf[zT_79];
    zT_84 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_80) << (zT_79FAE712_u64)(48));
    v = zT_84;
    zT_85 = 7;
    zT_86 = byte_off + zT_85;
    zT_87 = buf[zT_86];
    zT_91 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_87) << (zT_79FAE712_u64)(56));
    v = zT_91;
    goto z_bb_10;
    z_bb_10:
    return v;
    z_bb_11:
    zT_92 = 1;
    zT_93 = byte_off + zT_92;
    zT_94 = buf[zT_93];
    zT_98 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_94) << (zT_79FAE712_u64)(8));
    v = zT_98;
    zT_99 = 2;
    zT_100 = byte_off + zT_99;
    zT_101 = buf[zT_100];
    zT_105 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_101) << (zT_79FAE712_u64)(16));
    v = zT_105;
    zT_106 = 3;
    zT_107 = byte_off + zT_106;
    zT_108 = buf[zT_107];
    zT_112 = v | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_108) << (zT_79FAE712_u64)(24));
    v = zT_112;
    goto z_bb_10;
}

/* valuePoolClose */
void zF_131F3CDC_valuePoolClose(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    zT_D21A8776_SpillStore* zT_2;
    (void)store;
    zT_2 = &p->spill;
    zF_DB2CDC3B_spillClose(zT_2);
    return;
}

/* astStoreIdentifier */
unsigned int zF_53458827_astStoreIdentifier(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_5 = 0;
    zT_6B0A7D14_AstStore* zT_6;
    zT_01BE9D46_AstValuePool* zT_7;
    unsigned int zT_8;
    zT_79FAE712_u64 zT_10 = 0;
    unsigned int pool_idx;
    zT_3 = store;
    zT_4 = node_idx;
    zT_5 = zF_8BA26B9E_astStoreNodePayload(zT_3, zT_4);
    pool_idx = zT_5;
    zT_6 = store;
    zT_7 = &store->identifiers;
    zT_8 = pool_idx;
    zT_10 = zF_FDA4EEAD_valuePoolGetValue(zT_6, zT_7, zT_8);
    return (unsigned int)((unsigned int)zT_10);
}

/* astStoreIntValue */
zT_79FAE712_u64 zF_678B9A72_astStoreIntValue(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_5 = 0;
    zT_6B0A7D14_AstStore* zT_6;
    zT_01BE9D46_AstValuePool* zT_7;
    unsigned int zT_8;
    zT_79FAE712_u64 zT_10 = 0;
    unsigned int pool_idx;
    zT_3 = store;
    zT_4 = node_idx;
    zT_5 = zF_8BA26B9E_astStoreNodePayload(zT_3, zT_4);
    pool_idx = zT_5;
    zT_6 = store;
    zT_7 = &store->int_values;
    zT_8 = pool_idx;
    zT_10 = zF_FDA4EEAD_valuePoolGetValue(zT_6, zT_7, zT_8);
    return zT_10;
}

/* astStoreAddNode */
unsigned int zF_6C9FF72F_astStoreAddNode(zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind kind, unsigned char flags, unsigned int span_start, unsigned int span_end, unsigned int c0, unsigned int c1, unsigned int c2, unsigned int payload) {
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13;
    zT_6B0A7D14_AstStore* zT_14;
    zT_22A7C88B_AstNode zT_15;
    unsigned int zT_16;
    zT_A318155C_anon_226697 zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int span_len;
    zT_22A7C88B_AstNode node;
    zT_11 = (unsigned int)(unsigned int)(span_end - span_start);
    span_len = zT_11;
    zT_13.kind = kind;
    zT_13.flags = flags;
    zT_13.span_start = span_start;
    zT_13.span_len = span_len;
    zT_13.child_0 = c0;
    zT_13.child_1 = c1;
    zT_13.child_2 = c2;
    node = zT_13;
    zT_14 = store;
    zT_15 = node;
    zT_16 = payload;
    zF_3A477168_astStoreNodeAppend(zT_14, zT_15, zT_16);
    zT_17 = store->nodes;
    zT_18 = zT_17.len;
    zT_19 = 1;
    return (unsigned int)((unsigned int)(unsigned int)(zT_18 - zT_19));
}

/* astStoreNodeAppend */
void zF_3A477168_astStoreNodeAppend(zT_6B0A7D14_AstStore* store, zT_22A7C88B_AstNode node, unsigned int payload) {
    zT_A318155C_anon_226697 zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_18;
    zT_6B0A7D14_AstStore* zT_24;
    zT_6DD0D007_AstSlot* zT_30;
    unsigned int zT_31;
    zT_6DD0D007_AstSlot zT_32;
    zT_22A7C88B_AstNode* zT_33;
    zT_6DD0D007_AstSlot* zT_34;
    unsigned int zT_35;
    zT_6DD0D007_AstSlot zT_36;
    unsigned int* zT_37;
    zT_A318155C_anon_226697 zT_38;
    unsigned int zT_39;
    int zT_40;
    zT_A318155C_anon_226697* zT_43;
    zT_9CB93784_anon_226734 zT_44;
    unsigned int zT_45;
    int zT_46;
    zT_9CB93784_anon_226734* zT_49;
    unsigned int zT_50;
    int zT_51;
    unsigned int node_idx;
    unsigned int bi;
    unsigned int off;
    zT_4 = store->nodes;
    zT_5 = zT_4.len;
    node_idx = zT_5;
    zT_7 = 12;
    zT_9 = (unsigned int)(unsigned int)(node_idx >> zT_7);
    bi = zT_9;
    zT_10 = store->cur_block;
    if ((int)(bi != zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = store;
    zF_D45C652C_astBlockSpillHead(zT_12);
    zT_13 = store;
    zT_14 = bi;
    zF_BA06A188_astBlockAdvanceHead(zT_13, zT_14);
    goto z_bb_2;
    z_bb_2:
    zT_17 = node_idx & (unsigned int)(4095);
    off = zT_17;
    zT_18 = store;
    zF_420B3B4B_astSlotEnsureNodeCa(zT_18, (unsigned int)(0), (unsigned int)(off + (unsigned int)(1)));
    zT_24 = store;
    zF_5184AF33_astSlotEnsurePayloa(zT_24, (unsigned int)(0), (unsigned int)(off + (unsigned int)(1)));
    zT_30 = store->slots;
    zT_31 = 0;
    zT_32 = zT_30[zT_31];
    zT_33 = zT_32.node_buf;
    zT_33[off] = node;
    zT_34 = store->slots;
    zT_35 = 0;
    zT_36 = zT_34[zT_35];
    zT_37 = zT_36.payload_buf;
    zT_37[off] = payload;
    zT_38 = store->nodes;
    zT_39 = zT_38.len;
    zT_40 = 1;
    zT_43 = &store->nodes;
    zT_43->len = (unsigned int)(zT_39 + (unsigned int)((unsigned int)zT_40));
    zT_44 = store->payload;
    zT_45 = zT_44.len;
    zT_46 = 1;
    zT_49 = &store->payload;
    zT_49->len = (unsigned int)(zT_45 + (unsigned int)((unsigned int)zT_46));
    zT_50 = store->cur_block_len;
    zT_51 = 1;
    store->cur_block_len = (unsigned int)(zT_50 + (unsigned int)((unsigned int)zT_51));
    return;
}

/* astBlockTableEnsure */
void zF_1D4F4DCE_astBlockTableEnsure(zT_6B0A7D14_AstStore* store, unsigned int new_len) {
    zT_9ACA7D7F_anon_226748 zT_2;
    unsigned int zT_3;
    zT_9ACA7D7F_anon_226748 zT_6;
    unsigned int zT_7;
    unsigned int zT_10;
    int zT_12;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_C6536882_EU_532 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_E2FE8472_NodeBlockInfo* zT_28;
    int zT_30;
    unsigned int zT_31;
    zT_9ACA7D7F_anon_226748 zT_32;
    unsigned int zT_33;
    zT_9ACA7D7F_anon_226748 zT_35;
    zT_E2FE8472_NodeBlockInfo* zT_36;
    zT_E2FE8472_NodeBlockInfo zT_37;
    int zT_38;
    unsigned int zT_39;
    zT_9ACA7D7F_anon_226748* zT_40;
    zT_9ACA7D7F_anon_226748* zT_41;
    zT_9ACA7D7F_anon_226748* zT_42;
    unsigned int new_cap;
    unsigned char* raw;
    zT_E2FE8472_NodeBlockInfo* new_items;
    unsigned int i;
    zT_2 = store->block_table;
    zT_3 = zT_2.len;
    if ((int)(new_len <= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = store->block_table;
    zT_7 = zT_6.capacity;
    new_cap = zT_7;
    if ((int)(new_cap < (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = 16;
    new_cap = zT_10;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((int)(new_cap < new_len)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_12 = 2;
    zT_14 = new_cap * (unsigned int)((unsigned int)zT_12);
    new_cap = zT_14;
    goto z_bb_8;
    z_bb_7:
    zT_16 = store->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)(12) * new_cap), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_25 = zT_23.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw = zT_25;
    zT_28 = (zT_E2FE8472_NodeBlockInfo*)raw;
    new_items = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_12;
    z_bb_12:
    zT_32 = store->block_table;
    zT_33 = zT_32.len;
    if ((int)(i < zT_33)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_35 = store->block_table;
    zT_36 = zT_35.items;
    zT_37 = zT_36[i];
    new_items[i] = zT_37;
    goto z_bb_15;
    z_bb_14:
    zT_40 = &store->block_table;
    zT_40->items = new_items;
    zT_41 = &store->block_table;
    zT_41->capacity = new_cap;
    zT_42 = &store->block_table;
    zT_42->len = new_len;
    return;
    z_bb_15:
    zT_38 = 1;
    zT_39 = i + zT_38;
    i = zT_39;
    goto z_bb_12;
}

/* astBlockOpenSpill */
void zF_548211A2_astBlockOpenSpill(zT_6B0A7D14_AstStore* store) {
    zT_D21A8776_SpillStore zT_1;
    unsigned char zT_2;
    zT_D21A8776_SpillStore* zT_5;
    zT_0426DCE7_SpillBackend zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned char* zT_9;
    zT_0426DCE7_SpillBackend zT_15 = 0;
    unsigned char* zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned char* zT_23;
    zT_1 = store->spill;
    zT_2 = zT_1.opened;
    if ((int)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &store->spill;
    zT_15 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_ast));
    zT_6 = zT_15;
    zT_16 = store->spill_path;
    zT_17 = store->spill_path_len;
    zT_18 = 0;
    zT_19 = zT_16 + zT_18;
    zT_20 = zT_17 - zT_18;
    zT_21.ptr = zT_19;
    zT_21.len = zT_20;
    zT_7 = zT_21;
    zT_8 = store->allocator;
    zT_23 = "w+b";
    zT_9 = zT_23;
    zF_8AF94F71_spillOpen(zT_5, zT_6, zT_7, zT_8, zT_9);
    return;
}

/* astBlockSpillHead */
void zF_D45C652C_astBlockSpillHead(zT_6B0A7D14_AstStore* store) {
    zT_6B0A7D14_AstStore* zT_1;
    unsigned int zT_3;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    int zT_17;
    unsigned int zT_21;
    zT_9ACA7D7F_anon_226748 zT_23;
    zT_E2FE8472_NodeBlockInfo* zT_24;
    zT_E2FE8472_NodeBlockInfo zT_25;
    unsigned int zT_27;
    zT_9ACA7D7F_anon_226748 zT_29;
    zT_E2FE8472_NodeBlockInfo* zT_30;
    zT_6DD0D007_AstSlot* zT_32;
    unsigned int zT_33;
    zT_6DD0D007_AstSlot zT_34;
    zT_22A7C88B_AstNode* zT_35;
    unsigned char* zT_36;
    zT_D21A8776_SpillStore* zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_6DD0D007_AstSlot* zT_47;
    unsigned int zT_48;
    zT_6DD0D007_AstSlot zT_49;
    unsigned int* zT_50;
    unsigned char* zT_51;
    zT_D21A8776_SpillStore* zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    int zT_59;
    unsigned char* zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int bi;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    unsigned int disk_off;
    zT_E2FE8472_NodeBlockInfo entry;
    unsigned char* nraw;
    unsigned char* praw;
    zT_1 = store;
    zF_548211A2_astBlockOpenSpill(zT_1);
    zT_3 = store->cur_block;
    bi = zT_3;
    if ((int)(bi > (unsigned int)(18724))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = "S-AST spill block count exceeds i32 seek limit (astBlockSpillHead)";
    zT_9 = 66;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    emsg = zT_8;
    zT_11 = "ast.zig";
    zT_13 = 7;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    ef = zT_12;
    zT_14 = emsg;
    zT_15 = ef;
    zT_17 = 537;
    zF_6D97D338_panicHandler(zT_14, zT_15, (unsigned int)((unsigned int)zT_17));
    return;
    z_bb_2:
    zT_21 = bi * (unsigned int)(114688);
    disk_off = zT_21;
    zT_23 = store->block_table;
    zT_24 = zT_23.items;
    zT_25 = zT_24[bi];
    entry = zT_25;
    entry.disk_off = disk_off;
    entry.resident = (unsigned char)(0);
    zT_27 = 4294967295u;
    entry.slot = (unsigned int)((unsigned int)zT_27);
    zT_29 = store->block_table;
    zT_30 = zT_29.items;
    zT_30[bi] = entry;
    zT_32 = store->slots;
    zT_33 = 0;
    zT_34 = zT_32[zT_33];
    zT_35 = zT_34.node_buf;
    zT_36 = (unsigned char*)zT_35;
    nraw = zT_36;
    zT_37 = &store->spill;
    zT_38 = disk_off;
    zT_42 = 0;
    zT_43 = nraw + zT_42;
    zT_44 = (unsigned int)(98304) - zT_42;
    zT_45.ptr = zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zF_BFB33631_spillWriteAt(zT_37, zT_38, zT_39);
    zT_47 = store->slots;
    zT_48 = 0;
    zT_49 = zT_47[zT_48];
    zT_50 = zT_49.payload_buf;
    zT_51 = (unsigned char*)zT_50;
    praw = zT_51;
    zT_52 = &store->spill;
    zT_59 = 0;
    zT_60 = praw + zT_59;
    zT_61 = (unsigned int)(16384) - zT_59;
    zT_62.ptr = zT_60;
    zT_62.len = zT_61;
    zT_54 = zT_62;
    zF_BFB33631_spillWriteAt(zT_52, (unsigned int)(disk_off + (unsigned int)(98304)), zT_54);
    return;
}

/* astBlockAdvanceHead */
void zF_BA06A188_astBlockAdvanceHead(zT_6B0A7D14_AstStore* store, unsigned int new_bi) {
    zT_6B0A7D14_AstStore* zT_2;
    int zT_5;
    zT_E2FE8472_NodeBlockInfo zT_7;
    unsigned int zT_9;
    unsigned char zT_10;
    unsigned int zT_11;
    zT_9ACA7D7F_anon_226748 zT_12;
    zT_E2FE8472_NodeBlockInfo* zT_13;
    zT_6DD0D007_AstSlot* zT_15;
    zT_6DD0D007_AstSlot* zT_17;
    unsigned int* zT_18;
    unsigned int zT_19;
    zT_2 = store;
    zT_5 = 1;
    zF_1D4F4DCE_astBlockTableEnsure(zT_2, (unsigned int)((unsigned int)((unsigned int)new_bi) + zT_5));
    zT_9 = new_bi * (unsigned int)(114688);
    zT_7.disk_off = zT_9;
    zT_10 = 1;
    zT_7.resident = zT_10;
    zT_11 = 0;
    zT_7.slot = zT_11;
    zT_12 = store->block_table;
    zT_13 = zT_12.items;
    zT_13[new_bi] = zT_7;
    zT_15 = store->slots;
    zT_17 = zT_15 + (unsigned int)(0);
    zT_17->in_use = (unsigned char)(1);
    zT_18 = store->slot_block;
    zT_19 = 0;
    zT_18[zT_19] = new_bi;
    store->cur_block = new_bi;
    store->cur_block_len = (unsigned int)(0);
    return;
}

/* astSlotEnsureNodeCap */
void zF_420B3B4B_astSlotEnsureNodeCa(zT_6B0A7D14_AstStore* store, unsigned int s, unsigned int need) {
    zT_6DD0D007_AstSlot* zT_3;
    zT_6DD0D007_AstSlot zT_4;
    unsigned int zT_5;
    zT_6DD0D007_AstSlot* zT_8;
    zT_6DD0D007_AstSlot zT_9;
    unsigned int zT_10;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    zT_C6536882_EU_532 zT_29 = {0};
    unsigned char zT_30;
    unsigned char* zT_31;
    zT_22A7C88B_AstNode* zT_34;
    int zT_36;
    unsigned int zT_37;
    zT_6DD0D007_AstSlot* zT_38;
    zT_6DD0D007_AstSlot zT_39;
    unsigned int zT_40;
    zT_6DD0D007_AstSlot* zT_42;
    zT_6DD0D007_AstSlot zT_43;
    zT_22A7C88B_AstNode* zT_44;
    zT_22A7C88B_AstNode zT_45;
    int zT_46;
    unsigned int zT_47;
    zT_6DD0D007_AstSlot* zT_48;
    zT_6DD0D007_AstSlot* zT_49;
    zT_6DD0D007_AstSlot* zT_50;
    zT_6DD0D007_AstSlot* zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    zT_22A7C88B_AstNode* nb;
    unsigned int i;
    zT_3 = store->slots;
    zT_4 = zT_3[s];
    zT_5 = zT_4.node_cap;
    if ((int)(zT_5 >= need)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = store->slots;
    zT_9 = zT_8[s];
    zT_10 = zT_9.node_cap;
    new_cap = zT_10;
    if ((int)(new_cap < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = 64;
    new_cap = zT_13;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((int)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = 2;
    zT_17 = new_cap * (unsigned int)((unsigned int)zT_15);
    new_cap = zT_17;
    goto z_bb_8;
    z_bb_7:
    if ((int)(new_cap > (unsigned int)(4096))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_20 = 4096;
    new_cap = zT_20;
    goto z_bb_10;
    z_bb_10:
    zT_22 = store->allocator;
    zT_29 = zF_1395EB68_sandAlloc(zT_22, (unsigned int)((unsigned int)(24) * new_cap), (unsigned int)(4));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_31 = zT_29.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_31;
    zT_34 = (zT_22A7C88B_AstNode*)raw;
    nb = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    goto z_bb_14;
    z_bb_14:
    zT_38 = store->slots;
    zT_39 = zT_38[s];
    zT_40 = zT_39.node_cap;
    if ((int)(i < zT_40)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_42 = store->slots;
    zT_43 = zT_42[s];
    zT_44 = zT_43.node_buf;
    zT_45 = zT_44[i];
    nb[i] = zT_45;
    goto z_bb_17;
    z_bb_16:
    zT_48 = store->slots;
    zT_49 = zT_48 + s;
    zT_49->node_buf = nb;
    zT_50 = store->slots;
    zT_51 = zT_50 + s;
    zT_51->node_cap = new_cap;
    return;
    z_bb_17:
    zT_46 = 1;
    zT_47 = i + zT_46;
    i = zT_47;
    goto z_bb_14;
}

/* astSlotEnsurePayloadCap */
void zF_5184AF33_astSlotEnsurePayloa(zT_6B0A7D14_AstStore* store, unsigned int s, unsigned int need) {
    zT_6DD0D007_AstSlot* zT_3;
    zT_6DD0D007_AstSlot zT_4;
    unsigned int zT_5;
    zT_6DD0D007_AstSlot* zT_8;
    zT_6DD0D007_AstSlot zT_9;
    unsigned int zT_10;
    unsigned int zT_13;
    int zT_15;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_3E40CD83_Sand* zT_22;
    zT_C6536882_EU_532 zT_29 = {0};
    unsigned char zT_30;
    unsigned char* zT_31;
    unsigned int* zT_34;
    int zT_36;
    unsigned int zT_37;
    zT_6DD0D007_AstSlot* zT_38;
    zT_6DD0D007_AstSlot zT_39;
    unsigned int zT_40;
    zT_6DD0D007_AstSlot* zT_42;
    zT_6DD0D007_AstSlot zT_43;
    unsigned int* zT_44;
    unsigned int zT_45;
    int zT_46;
    unsigned int zT_47;
    zT_6DD0D007_AstSlot* zT_48;
    zT_6DD0D007_AstSlot* zT_49;
    zT_6DD0D007_AstSlot* zT_50;
    zT_6DD0D007_AstSlot* zT_51;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* nb;
    unsigned int i;
    zT_3 = store->slots;
    zT_4 = zT_3[s];
    zT_5 = zT_4.payload_cap;
    if ((int)(zT_5 >= need)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = store->slots;
    zT_9 = zT_8[s];
    zT_10 = zT_9.payload_cap;
    new_cap = zT_10;
    if ((int)(new_cap < (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = 64;
    new_cap = zT_13;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((int)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = 2;
    zT_17 = new_cap * (unsigned int)((unsigned int)zT_15);
    new_cap = zT_17;
    goto z_bb_8;
    z_bb_7:
    if ((int)(new_cap > (unsigned int)(4096))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_20 = 4096;
    new_cap = zT_20;
    goto z_bb_10;
    z_bb_10:
    zT_22 = store->allocator;
    zT_29 = zF_1395EB68_sandAlloc(zT_22, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_31 = zT_29.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_31;
    zT_34 = (unsigned int*)raw;
    nb = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    i = zT_37;
    goto z_bb_14;
    z_bb_14:
    zT_38 = store->slots;
    zT_39 = zT_38[s];
    zT_40 = zT_39.payload_cap;
    if ((int)(i < zT_40)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_42 = store->slots;
    zT_43 = zT_42[s];
    zT_44 = zT_43.payload_buf;
    zT_45 = zT_44[i];
    nb[i] = zT_45;
    goto z_bb_17;
    z_bb_16:
    zT_48 = store->slots;
    zT_49 = zT_48 + s;
    zT_49->payload_buf = nb;
    zT_50 = store->slots;
    zT_51 = zT_50 + s;
    zT_51->payload_cap = new_cap;
    return;
    z_bb_17:
    zT_46 = 1;
    zT_47 = i + zT_46;
    i = zT_47;
    goto z_bb_14;
}

/* astSlotEnsureFull */
void zF_8D6C3544_astSlotEnsureFull(zT_6B0A7D14_AstStore* store, unsigned int s) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned int zT_3;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_2 = store;
    zT_3 = s;
    zF_420B3B4B_astSlotEnsureNodeCa(zT_2, zT_3, (unsigned int)(4096));
    zT_6 = store;
    zT_7 = s;
    zF_5184AF33_astSlotEnsurePayloa(zT_6, zT_7, (unsigned int)(4096));
    return;
}

/* astSlotAcquire */
unsigned int zF_E0B03A59_astSlotAcquire(zT_6B0A7D14_AstStore* store) {
    int zT_2;
    unsigned int zT_3;
    zT_6DD0D007_AstSlot* zT_6;
    zT_6DD0D007_AstSlot zT_7;
    unsigned char zT_8;
    zT_6DD0D007_AstSlot* zT_12;
    zT_6DD0D007_AstSlot* zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_17;
    int zT_20;
    unsigned int zT_21;
    int zT_24;
    unsigned int zT_25;
    unsigned int* zT_27;
    unsigned int zT_28;
    zT_9ACA7D7F_anon_226748 zT_30;
    zT_E2FE8472_NodeBlockInfo* zT_31;
    zT_E2FE8472_NodeBlockInfo zT_32;
    unsigned int zT_34;
    zT_9ACA7D7F_anon_226748 zT_36;
    zT_E2FE8472_NodeBlockInfo* zT_37;
    unsigned int zT_40;
    int zT_43;
    unsigned int zT_44;
    unsigned int i;
    unsigned int victim;
    unsigned int vblock;
    zT_E2FE8472_NodeBlockInfo ventry;
    unsigned int nv;
    zT_2 = 1;
    zT_3 = (unsigned int)zT_2;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    if ((int)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = store->slots;
    zT_7 = zT_6[i];
    zT_8 = zT_7.in_use;
    if ((int)(zT_8 == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17 = store->ring_next;
    victim = zT_17;
    if ((int)(victim == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    zT_14 = 1;
    zT_15 = i + zT_14;
    i = zT_15;
    goto z_bb_1;
    z_bb_5:
    zT_12 = store->slots;
    zT_13 = zT_12 + i;
    zT_13->in_use = (unsigned char)(1);
    return i;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    victim = zT_21;
    goto z_bb_8;
    z_bb_8:
    if ((int)(victim >= (unsigned int)(8))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_24 = 1;
    zT_25 = (unsigned int)zT_24;
    victim = zT_25;
    goto z_bb_10;
    z_bb_10:
    zT_27 = store->slot_block;
    zT_28 = zT_27[victim];
    vblock = zT_28;
    zT_30 = store->block_table;
    zT_31 = zT_30.items;
    zT_32 = zT_31[vblock];
    ventry = zT_32;
    ventry.resident = (unsigned char)(0);
    zT_34 = 4294967295u;
    ventry.slot = (unsigned int)((unsigned int)zT_34);
    zT_36 = store->block_table;
    zT_37 = zT_36.items;
    zT_37[vblock] = ventry;
    zT_40 = victim + (unsigned int)(1);
    nv = zT_40;
    if ((int)(nv >= (unsigned int)(8))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_43 = 1;
    zT_44 = (unsigned int)zT_43;
    nv = zT_44;
    goto z_bb_12;
    z_bb_12:
    store->ring_next = nv;
    return victim;
}

/* astBlockFaultIn */
void zF_4891718F_astBlockFaultIn(zT_6B0A7D14_AstStore* store, unsigned int bi) {
    zT_6B0A7D14_AstStore* zT_2;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_16;
    zT_9ACA7D7F_anon_226748 zT_19;
    zT_E2FE8472_NodeBlockInfo* zT_20;
    zT_E2FE8472_NodeBlockInfo zT_21;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24 = 0;
    zT_6B0A7D14_AstStore* zT_25;
    unsigned int zT_26;
    zT_6DD0D007_AstSlot* zT_28;
    zT_6DD0D007_AstSlot zT_29;
    zT_22A7C88B_AstNode* zT_30;
    unsigned char* zT_31;
    zT_D21A8776_SpillStore* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    int zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    zT_6DD0D007_AstSlot* zT_43;
    zT_6DD0D007_AstSlot zT_44;
    unsigned int* zT_45;
    unsigned char* zT_46;
    zT_D21A8776_SpillStore* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_51;
    int zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_6DD0D007_AstSlot* zT_60;
    zT_6DD0D007_AstSlot* zT_61;
    unsigned int* zT_62;
    zT_9ACA7D7F_anon_226748 zT_64;
    zT_E2FE8472_NodeBlockInfo* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_E2FE8472_NodeBlockInfo entry;
    unsigned int s;
    unsigned char* nraw;
    unsigned char* praw;
    zT_2 = store;
    zF_548211A2_astBlockOpenSpill(zT_2);
    if ((int)(bi > (unsigned int)(18724))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = "S-AST spill block count exceeds i32 seek limit (astBlockFaultIn)";
    zT_8 = 64;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    emsg = zT_7;
    zT_10 = "ast.zig";
    zT_12 = 7;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    ef = zT_11;
    zT_13 = emsg;
    zT_14 = ef;
    zT_16 = 627;
    zF_6D97D338_panicHandler(zT_13, zT_14, (unsigned int)((unsigned int)zT_16));
    return;
    z_bb_2:
    zT_19 = store->block_table;
    zT_20 = zT_19.items;
    zT_21 = zT_20[bi];
    entry = zT_21;
    zT_23 = store;
    zT_24 = zF_E0B03A59_astSlotAcquire(zT_23);
    s = zT_24;
    zT_25 = store;
    zT_26 = s;
    zF_8D6C3544_astSlotEnsureFull(zT_25, zT_26);
    zT_28 = store->slots;
    zT_29 = zT_28[s];
    zT_30 = zT_29.node_buf;
    zT_31 = (unsigned char*)zT_30;
    nraw = zT_31;
    zT_32 = &store->spill;
    zT_33 = entry.disk_off;
    zT_38 = 0;
    zT_39 = nraw + zT_38;
    zT_40 = (unsigned int)(98304) - zT_38;
    zT_41.ptr = zT_39;
    zT_41.len = zT_40;
    zT_34 = zT_41;
    zF_E9F67450_spillReadAt(zT_32, zT_33, zT_34);
    zT_43 = store->slots;
    zT_44 = zT_43[s];
    zT_45 = zT_44.payload_buf;
    zT_46 = (unsigned char*)zT_45;
    praw = zT_46;
    zT_47 = &store->spill;
    zT_51 = entry.disk_off;
    zT_55 = 0;
    zT_56 = praw + zT_55;
    zT_57 = (unsigned int)(16384) - zT_55;
    zT_58.ptr = zT_56;
    zT_58.len = zT_57;
    zT_49 = zT_58;
    zF_E9F67450_spillReadAt(zT_47, (unsigned int)(zT_51 + (unsigned int)(98304)), zT_49);
    zT_60 = store->slots;
    zT_61 = zT_60 + s;
    zT_61->in_use = (unsigned char)(1);
    zT_62 = store->slot_block;
    zT_62[s] = bi;
    entry.resident = (unsigned char)(1);
    entry.slot = s;
    zT_64 = store->block_table;
    zT_65 = zT_64.items;
    zT_65[bi] = entry;
    return;
}

/* astStoreNodeAt */
zT_22A7C88B_AstNode zF_FCDD1D35_astStoreNodeAt(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    zT_9ACA7D7F_anon_226748 zT_9;
    zT_E2FE8472_NodeBlockInfo* zT_10;
    zT_E2FE8472_NodeBlockInfo zT_11;
    unsigned char zT_12;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_9ACA7D7F_anon_226748 zT_17;
    zT_E2FE8472_NodeBlockInfo* zT_18;
    zT_E2FE8472_NodeBlockInfo zT_19;
    zT_6DD0D007_AstSlot* zT_20;
    unsigned int zT_21;
    zT_6DD0D007_AstSlot zT_22;
    zT_22A7C88B_AstNode* zT_23;
    zT_22A7C88B_AstNode zT_24;
    unsigned int bi;
    unsigned int off;
    zT_E2FE8472_NodeBlockInfo entry;
    zT_3 = 12;
    zT_4 = idx >> zT_3;
    bi = zT_4;
    zT_7 = idx & (unsigned int)(4095);
    off = zT_7;
    zT_9 = store->block_table;
    zT_10 = zT_9.items;
    zT_11 = zT_10[bi];
    entry = zT_11;
    zT_12 = entry.resident;
    if ((int)(zT_12 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = store;
    zT_16 = bi;
    zF_4891718F_astBlockFaultIn(zT_15, zT_16);
    zT_17 = store->block_table;
    zT_18 = zT_17.items;
    zT_19 = zT_18[bi];
    entry = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_20 = store->slots;
    zT_21 = entry.slot;
    zT_22 = zT_20[zT_21];
    zT_23 = zT_22.node_buf;
    zT_24 = zT_23[off];
    return zT_24;
}

/* astStoreAddExtraChildren */
unsigned int zF_583E993C_astStoreAddExtraChi(zT_6B0A7D14_AstStore* store, zT_3CB0179A_Slice_zT_05F374B1_u children) {
    zT_01BE9D46_AstValuePool zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    zT_01BE9D46_AstValuePool* zT_13;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int zT_19 = 0;
    int zT_20;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_24;
    zT_01BE9D46_AstValuePool* zT_25;
    unsigned int zT_32;
    unsigned int zT_35 = 0;
    unsigned int start;
    unsigned int i;
    unsigned int range_idx;
    zT_3 = store->extra_children;
    zT_4 = zT_3.len;
    zT_5 = (unsigned int)zT_4;
    start = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_10 = children.len;
    if ((int)(i < zT_10)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_12 = store;
    zT_13 = &store->extra_children;
    zT_16 = children.ptr;
    zT_17 = zT_16[i];
    zT_19 = zF_B73DE9D0_valuePoolAppend(zT_12, zT_13, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_17));
    (void)zT_19;
    zT_20 = 1;
    zT_22 = i + (unsigned int)((unsigned int)zT_20);
    i = zT_22;
    goto z_bb_4;
    z_bb_3:
    zT_24 = store;
    zT_25 = &store->extra_ranges;
    zT_32 = children.len;
    zT_35 = zF_B73DE9D0_valuePoolAppend(zT_24, zT_25, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)start) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_32)));
    range_idx = zT_35;
    return range_idx;
    z_bb_4:
    goto z_bb_1;
}

/* astStoreGetExtraChildCount */
unsigned int zF_03CE8CAB_astStoreGetExtraChi(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 payload) {
    (void)store;
    return (unsigned int)((unsigned int)(zT_79FAE712_u64)(payload & (zT_79FAE712_u64)(4294967295u)));
}

/* astStoreGetExtraChildAt */
unsigned int zF_E5B10421_astStoreGetExtraChi(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 payload, unsigned int i) {
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_01BE9D46_AstValuePool* zT_8;
    zT_79FAE712_u64 zT_12 = 0;
    unsigned int start;
    zT_6 = (unsigned int)(zT_79FAE712_u64)(payload >> (zT_79FAE712_u64)(32));
    start = zT_6;
    zT_7 = store;
    zT_8 = &store->extra_children;
    zT_12 = zF_FDA4EEAD_valuePoolGetValue(zT_7, zT_8, (unsigned int)(start + i));
    return (unsigned int)((unsigned int)zT_12);
}

/* astStoreGetExtraChildrenCopy */
unsigned int zF_67ADE488_astStoreGetExtraChi(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 payload, zT_3CB0179A_Slice_zT_05F374B1_u out) {
    zT_6B0A7D14_AstStore* zT_4;
    zT_79FAE712_u64 zT_5;
    unsigned int zT_6 = 0;
    unsigned int zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    zT_79FAE712_u64 zT_20;
    unsigned int zT_21;
    unsigned int zT_22 = 0;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int count;
    unsigned int n;
    unsigned int i;
    zT_4 = store;
    zT_5 = payload;
    zT_6 = zF_03CE8CAB_astStoreGetExtraChi(zT_4, zT_5);
    count = zT_6;
    n = count;
    zT_10 = out.len;
    if ((int)((unsigned int)((unsigned int)n) > zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = out.len;
    zT_14 = (unsigned int)zT_13;
    n = zT_14;
    goto z_bb_2;
    z_bb_2:
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    i = zT_17;
    goto z_bb_3;
    z_bb_3:
    if ((int)(i < n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = store;
    zT_20 = payload;
    zT_21 = i;
    zT_22 = zF_E5B10421_astStoreGetExtraChi(zT_19, zT_20, zT_21);
    zT_23 = out.ptr;
    zT_24 = (unsigned int)i;
    zT_23[zT_24] = zT_22;
    goto z_bb_6;
    z_bb_5:
    return count;
    z_bb_6:
    zT_25 = 1;
    zT_26 = i + zT_25;
    i = zT_26;
    goto z_bb_3;
}

/* astStoreExtraChildAtRaw */
unsigned int zF_884B7FF9_astStoreExtraChildA(zT_6B0A7D14_AstStore* store, unsigned int idx) {
    zT_6B0A7D14_AstStore* zT_2;
    zT_01BE9D46_AstValuePool* zT_3;
    unsigned int zT_4;
    zT_79FAE712_u64 zT_6 = 0;
    zT_2 = store;
    zT_3 = &store->extra_children;
    zT_4 = idx;
    zT_6 = zF_FDA4EEAD_valuePoolGetValue(zT_2, zT_3, zT_4);
    return (unsigned int)((unsigned int)zT_6);
}

/* astStoreExtraRangeAt */
zT_79FAE712_u64 zF_F956A1CA_astStoreExtraRangeA(zT_6B0A7D14_AstStore* store, unsigned int range_idx) {
    zT_6B0A7D14_AstStore* zT_2;
    zT_01BE9D46_AstValuePool* zT_3;
    unsigned int zT_4;
    zT_79FAE712_u64 zT_6 = 0;
    zT_2 = store;
    zT_3 = &store->extra_ranges;
    zT_4 = range_idx;
    zT_6 = zF_FDA4EEAD_valuePoolGetValue(zT_2, zT_3, zT_4);
    return zT_6;
}

/* astStoreNodePayload */
unsigned int zF_8BA26B9E_astStoreNodePayload(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    zT_9ACA7D7F_anon_226748 zT_9;
    zT_E2FE8472_NodeBlockInfo* zT_10;
    zT_E2FE8472_NodeBlockInfo zT_11;
    unsigned char zT_12;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_9ACA7D7F_anon_226748 zT_17;
    zT_E2FE8472_NodeBlockInfo* zT_18;
    zT_E2FE8472_NodeBlockInfo zT_19;
    zT_6DD0D007_AstSlot* zT_20;
    unsigned int zT_21;
    zT_6DD0D007_AstSlot zT_22;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int bi;
    unsigned int off;
    zT_E2FE8472_NodeBlockInfo entry;
    zT_3 = 12;
    zT_4 = node_idx >> zT_3;
    bi = zT_4;
    zT_7 = node_idx & (unsigned int)(4095);
    off = zT_7;
    zT_9 = store->block_table;
    zT_10 = zT_9.items;
    zT_11 = zT_10[bi];
    entry = zT_11;
    zT_12 = entry.resident;
    if ((int)(zT_12 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = store;
    zT_16 = bi;
    zF_4891718F_astBlockFaultIn(zT_15, zT_16);
    zT_17 = store->block_table;
    zT_18 = zT_17.items;
    zT_19 = zT_18[bi];
    entry = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_20 = store->slots;
    zT_21 = entry.slot;
    zT_22 = zT_20[zT_21];
    zT_23 = zT_22.payload_buf;
    zT_24 = zT_23[off];
    return zT_24;
}

/* astStoreNodePayloadPacked */
zT_79FAE712_u64 zF_0E4E10C6_astStoreNodePayload(zT_6B0A7D14_AstStore* store, unsigned int node_idx, zT_8143F551_AstKind kind) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    unsigned int zT_6 = 0;
    zT_8143F551_AstKind zT_10;
    int zT_11 = 0;
    int zT_12;
    zT_6B0A7D14_AstStore* zT_15;
    zT_01BE9D46_AstValuePool* zT_16;
    unsigned int zT_17;
    zT_79FAE712_u64 zT_19 = 0;
    unsigned int v;
    zT_4 = store;
    zT_5 = node_idx;
    zT_6 = zF_8BA26B9E_astStoreNodePayload(zT_4, zT_5);
    v = zT_6;
    if ((int)(v == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_79FAE712_u64)(0);
    z_bb_2:
    zT_10 = kind;
    zT_11 = zF_A5D7FF20_nodeHasExtraChildre(zT_10);
    if (zT_11) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call);
    goto z_bb_5;
    z_bb_4:
    zT_12 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_12) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = store;
    zT_16 = &store->extra_ranges;
    zT_17 = v;
    zT_19 = zF_FDA4EEAD_valuePoolGetValue(zT_15, zT_16, zT_17);
    return zT_19;
    z_bb_7:
    return (zT_79FAE712_u64)((zT_79FAE712_u64)v);
}

/* astStoreNodeExtraChildCount */
unsigned int zF_152E19CB_astStoreNodeExtraCh(zT_6B0A7D14_AstStore* store, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_3;
    unsigned int zT_4;
    unsigned int zT_5 = 0;
    zT_6B0A7D14_AstStore* zT_10;
    zT_01BE9D46_AstValuePool* zT_11;
    unsigned int zT_12;
    zT_79FAE712_u64 zT_14 = 0;
    unsigned int range_idx;
    zT_79FAE712_u64 packed_range;
    zT_3 = store;
    zT_4 = node_idx;
    zT_5 = zF_8BA26B9E_astStoreNodePayload(zT_3, zT_4);
    range_idx = zT_5;
    if ((int)(range_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_10 = store;
    zT_11 = &store->extra_ranges;
    zT_12 = range_idx;
    zT_14 = zF_FDA4EEAD_valuePoolGetValue(zT_10, zT_11, zT_12);
    packed_range = zT_14;
    return (unsigned int)((unsigned int)(zT_79FAE712_u64)(packed_range & (zT_79FAE712_u64)(4294967295u)));
}

/* astStoreNodeExtraChildAt */
unsigned int zF_B10B1BC1_astStoreNodeExtraCh(zT_6B0A7D14_AstStore* store, unsigned int node_idx, unsigned int i) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    unsigned int zT_6 = 0;
    zT_6B0A7D14_AstStore* zT_8;
    zT_01BE9D46_AstValuePool* zT_9;
    unsigned int zT_10;
    zT_79FAE712_u64 zT_12 = 0;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    zT_01BE9D46_AstValuePool* zT_18;
    zT_79FAE712_u64 zT_22 = 0;
    unsigned int range_idx;
    zT_79FAE712_u64 packed_range;
    unsigned int start;
    zT_4 = store;
    zT_5 = node_idx;
    zT_6 = zF_8BA26B9E_astStoreNodePayload(zT_4, zT_5);
    range_idx = zT_6;
    zT_8 = store;
    zT_9 = &store->extra_ranges;
    zT_10 = range_idx;
    zT_12 = zF_FDA4EEAD_valuePoolGetValue(zT_8, zT_9, zT_10);
    packed_range = zT_12;
    zT_16 = (unsigned int)(zT_79FAE712_u64)(packed_range >> (zT_79FAE712_u64)(32));
    start = zT_16;
    zT_17 = store;
    zT_18 = &store->extra_children;
    zT_22 = zF_FDA4EEAD_valuePoolGetValue(zT_17, zT_18, (unsigned int)(start + i));
    return (unsigned int)((unsigned int)zT_22);
}

/* astStoreNodeExtraChildrenCopy */
unsigned int zF_111E5D28_astStoreNodeExtraCh(zT_6B0A7D14_AstStore* store, unsigned int node_idx, zT_3CB0179A_Slice_zT_05F374B1_u out) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    unsigned int zT_6 = 0;
    unsigned int zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22 = 0;
    unsigned int* zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int count;
    unsigned int n;
    unsigned int i;
    zT_4 = store;
    zT_5 = node_idx;
    zT_6 = zF_152E19CB_astStoreNodeExtraCh(zT_4, zT_5);
    count = zT_6;
    n = count;
    zT_10 = out.len;
    if ((int)((unsigned int)((unsigned int)n) > zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = out.len;
    zT_14 = (unsigned int)zT_13;
    n = zT_14;
    goto z_bb_2;
    z_bb_2:
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    i = zT_17;
    goto z_bb_3;
    z_bb_3:
    if ((int)(i < n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = store;
    zT_20 = node_idx;
    zT_21 = i;
    zT_22 = zF_B10B1BC1_astStoreNodeExtraCh(zT_19, zT_20, zT_21);
    zT_23 = out.ptr;
    zT_24 = (unsigned int)i;
    zT_23[zT_24] = zT_22;
    goto z_bb_6;
    z_bb_5:
    return count;
    z_bb_6:
    zT_25 = 1;
    zT_26 = i + zT_25;
    i = zT_26;
    goto z_bb_3;
}

/* astStoreAddIntLiteral */
unsigned int zF_E45552BF_astStoreAddIntLiter(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 value, unsigned int span_start, unsigned int span_end) {
    zT_6B0A7D14_AstStore* zT_5;
    zT_01BE9D46_AstValuePool* zT_6;
    zT_79FAE712_u64 zT_7;
    unsigned int zT_9 = 0;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_18;
    unsigned int zT_24 = 0;
    unsigned int val_idx;
    zT_5 = store;
    zT_6 = &store->int_values;
    zT_7 = value;
    zT_9 = zF_B73DE9D0_valuePoolAppend(zT_5, zT_6, zT_7);
    val_idx = zT_9;
    zT_10 = store;
    zT_13 = span_start;
    zT_14 = span_end;
    zT_18 = val_idx;
    zT_24 = zF_6C9FF72F_astStoreAddNode(zT_10, (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal), (unsigned char)(0), zT_13, zT_14, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_18);
    return zT_24;
}

/* astStoreAddCharLiteral */
unsigned int zF_2CAC92AE_astStoreAddCharLite(zT_6B0A7D14_AstStore* store, zT_79FAE712_u64 value, unsigned int span_start, unsigned int span_end) {
    zT_6B0A7D14_AstStore* zT_5;
    zT_01BE9D46_AstValuePool* zT_6;
    zT_79FAE712_u64 zT_7;
    unsigned int zT_9 = 0;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_18;
    unsigned int zT_24 = 0;
    unsigned int val_idx;
    zT_5 = store;
    zT_6 = &store->int_values;
    zT_7 = value;
    zT_9 = zF_B73DE9D0_valuePoolAppend(zT_5, zT_6, zT_7);
    val_idx = zT_9;
    zT_10 = store;
    zT_13 = span_start;
    zT_14 = span_end;
    zT_18 = val_idx;
    zT_24 = zF_6C9FF72F_astStoreAddNode(zT_10, (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal), (unsigned char)(0), zT_13, zT_14, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_18);
    return zT_24;
}

/* astStoreAddFloatLiteral */
unsigned int zF_0CEAF68A_astStoreAddFloatLit(zT_6B0A7D14_AstStore* store, double value, unsigned int span_start, unsigned int span_end) {
    int zT_4 = 0;
    zT_C41F1B06_Arr_unsigned_char_6 zT_6;
    double zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    int zT_13;
    unsigned char* zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19 = {0};
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_A2BDBE24_anon_226712 zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    double** zT_35;
    unsigned int* zT_36;
    unsigned int* zT_37;
    zT_3E40CD83_Sand* zT_38;
    double zT_39;
    zT_A2BDBE24_anon_226712* zT_40;
    zT_A2BDBE24_anon_226712* zT_42;
    zT_A2BDBE24_anon_226712* zT_44;
    zT_6B0A7D14_AstStore* zT_47;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_55;
    unsigned int zT_61 = 0;
    zT_C41F1B06_Arr_unsigned_char_6 as0_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0s;
    zT_8F083A69_Slice_zT_0B42B2F8_u as0n;
    unsigned int val_idx;
    zT_4 = zF_F632D1ED_isMarkersEnabled();
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_6[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        as0_buf[_i] = zT_6[_i];
        _i++;
    }
}
    zT_8 = value;
    zT_13 = 0;
    zT_14 = (unsigned char*)((unsigned char*)as0_buf) + zT_13;
    zT_15 = (unsigned int)(64) - zT_13;
    zT_16.ptr = zT_14;
    zT_16.len = zT_15;
    zT_9 = zT_16;
    zT_17 = 64;
    zT_19 = zF_4CAEBE7E_formatF64(zT_8, zT_9, (unsigned int)((unsigned int)zT_17));
    as0 = zT_19;
    zT_21 = "AS:";
    zT_23 = 3;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    as0s = zT_22;
    zT_24 = as0s;
    zF_48AC7B3A_markerWrite(zT_24);
    zT_25 = as0;
    zF_48AC7B3A_markerWrite(zT_25);
    zT_27 = "\n";
    zT_29 = 1;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    as0n = zT_28;
    zT_30 = as0n;
    zF_48AC7B3A_markerWrite(zT_30);
    goto z_bb_2;
    z_bb_2:
    zT_32 = store->float_values;
    zT_33 = zT_32.len;
    zT_34 = (unsigned int)zT_33;
    val_idx = zT_34;
    zT_40 = &store->float_values;
    zT_35 = &zT_40->items;
    zT_42 = &store->float_values;
    zT_36 = &zT_42->len;
    zT_44 = &store->float_values;
    zT_37 = &zT_44->capacity;
    zT_38 = store->allocator;
    zT_39 = value;
    zF_51A5BB50_f64ArrayListAppendI(zT_35, zT_36, zT_37, zT_38, zT_39);
    zT_47 = store;
    zT_50 = span_start;
    zT_51 = span_end;
    zT_55 = val_idx;
    zT_61 = zF_6C9FF72F_astStoreAddNode(zT_47, (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal), (unsigned char)(0), zT_50, zT_51, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_55);
    return zT_61;
}

/* astStoreAddStringLiteral */
unsigned int zF_042235B9_astStoreAddStringLi(zT_6B0A7D14_AstStore* store, unsigned int string_id, unsigned int span_start, unsigned int span_end) {
    zT_9DBB77AE_anon_226721 zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    zT_9DBB77AE_anon_226721* zT_13;
    zT_9DBB77AE_anon_226721* zT_15;
    zT_9DBB77AE_anon_226721* zT_17;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_28;
    unsigned int zT_34 = 0;
    unsigned int sv_idx;
    zT_5 = store->string_values;
    zT_6 = zT_5.len;
    zT_7 = (unsigned int)zT_6;
    sv_idx = zT_7;
    zT_13 = &store->string_values;
    zT_8 = &zT_13->items;
    zT_15 = &store->string_values;
    zT_9 = &zT_15->len;
    zT_17 = &store->string_values;
    zT_10 = &zT_17->capacity;
    zT_11 = store->allocator;
    zT_12 = string_id;
    zF_8B163A32_u32ArrayListAppen_1(zT_8, zT_9, zT_10, zT_11, zT_12);
    zT_20 = store;
    zT_23 = span_start;
    zT_24 = span_end;
    zT_28 = sv_idx;
    zT_34 = zF_6C9FF72F_astStoreAddNode(zT_20, (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal), (unsigned char)(0), zT_23, zT_24, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_28);
    return zT_34;
}

/* astStoreAddIdentifier */
unsigned int zF_1DF77BD4_astStoreAddIdentifi(zT_6B0A7D14_AstStore* store, zT_8143F551_AstKind kind, unsigned int string_id, unsigned int span_start, unsigned int span_end) {
    zT_6B0A7D14_AstStore* zT_6;
    zT_01BE9D46_AstValuePool* zT_7;
    unsigned int zT_11 = 0;
    zT_6B0A7D14_AstStore* zT_12;
    zT_8143F551_AstKind zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned int zT_25 = 0;
    unsigned int id_idx;
    zT_6 = store;
    zT_7 = &store->identifiers;
    zT_11 = zF_B73DE9D0_valuePoolAppend(zT_6, zT_7, (zT_79FAE712_u64)((zT_79FAE712_u64)string_id));
    id_idx = zT_11;
    zT_12 = store;
    zT_13 = kind;
    zT_15 = span_start;
    zT_16 = span_end;
    zT_20 = id_idx;
    zT_25 = zF_6C9FF72F_astStoreAddNode(zT_12, zT_13, (unsigned char)(0), zT_15, zT_16, (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_20);
    return zT_25;
}

/* astStoreAddFnProto */
unsigned int zF_F1F8D02B_astStoreAddFnProto(zT_6B0A7D14_AstStore* store, zT_243D6A41_FnProto proto) {
    zT_98B93138_anon_226730 zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_243D6A41_FnProto** zT_6;
    unsigned int* zT_7;
    unsigned int* zT_8;
    zT_3E40CD83_Sand* zT_9;
    zT_243D6A41_FnProto zT_10;
    zT_98B93138_anon_226730* zT_11;
    zT_98B93138_anon_226730* zT_13;
    zT_98B93138_anon_226730* zT_15;
    unsigned int idx;
    zT_3 = store->fn_protos;
    zT_4 = zT_3.len;
    zT_5 = (unsigned int)zT_4;
    idx = zT_5;
    zT_11 = &store->fn_protos;
    zT_6 = &zT_11->items;
    zT_13 = &store->fn_protos;
    zT_7 = &zT_13->len;
    zT_15 = &store->fn_protos;
    zT_8 = &zT_15->capacity;
    zT_9 = store->allocator;
    zT_10 = proto;
    zF_F22CE022_fnProtoArrayListApp(zT_6, zT_7, zT_8, zT_9, zT_10);
    return idx;
}

/* nodeHasExtraChildren */
int zF_A5D7FF20_nodeHasExtraChildre(zT_8143F551_AstKind kind) {
switch (kind) {
case 30: goto z_bb_1;
case 76: goto z_bb_2;
case 3: goto z_bb_3;
case 4: goto z_bb_4;
case 5: goto z_bb_5;
case 56: goto z_bb_6;
case 20: goto z_bb_7;
case 21: goto z_bb_8;
case 22: goto z_bb_9;
case 92: goto z_bb_10;
case 75: goto z_bb_11;
case 9: goto z_bb_12;
default: goto z_bb_13;
}
    z_bb_1:
    return (int)(1);
    z_bb_2:
    return (int)(1);
    z_bb_3:
    return (int)(1);
    z_bb_4:
    return (int)(1);
    z_bb_5:
    return (int)(1);
    z_bb_6:
    return (int)(1);
    z_bb_7:
    return (int)(1);
    z_bb_8:
    return (int)(1);
    z_bb_9:
    return (int)(1);
    z_bb_10:
    return (int)(1);
    z_bb_11:
    return (int)(1);
    z_bb_12:
    return (int)(1);
    z_bb_13:
    return (int)(0);
    return 0;
}

/* nodeChildIsNode */
int zF_C395F6FD_nodeChildIsNode(zT_8143F551_AstKind kind, unsigned char slot) {
    int zT_2;
    int zT_4;
    int zT_6;
    int zT_8;
switch (kind) {
case 31: goto z_bb_1;
case 75: goto z_bb_2;
case 73: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_4;
case 5: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_1:
    zT_2 = 0;
    return (int)(slot != zT_2);
    z_bb_2:
    zT_4 = 1;
    return (int)(slot != zT_4);
    z_bb_3:
    zT_6 = 2;
    return (int)(slot != zT_6);
    z_bb_4:
    zT_8 = 0;
    return (int)(slot != zT_8);
    z_bb_5:
    return (int)(1);
    return 0;
}

/* nodeHasNodeExtraChildren */
int zF_BB9BCB30_nodeHasNodeExtraChi(zT_8143F551_AstKind kind) {
    zT_8143F551_AstKind zT_1;
    int zT_2 = 0;
    int zT_3;
    zT_1 = kind;
    zT_2 = zF_A5D7FF20_nodeHasExtraChildre(zT_1);
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = kind != (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    return zT_3;
}

/* visitPreOrder */
void zF_D5CCA077_visitPreOrder(zT_6B0A7D14_AstStore* store, unsigned int root, zT_EEDBD622_FP_void_zT_6B0A7D14 callback) {
    zT_894C14AF_Arr_unsigned_int_51 zT_4;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_10;
    int zT_11;
    int zT_13;
    unsigned int zT_15;
    unsigned int zT_17;
    int zT_18;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_22A7C88B_AstNode zT_23 = {0};
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_8143F551_AstKind zT_26;
    int zT_28 = 0;
    int zT_29;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_32 = 0;
    int zT_33;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_38 = 0;
    int zT_40;
    unsigned int zT_41;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    unsigned int zT_52 = 0;
    int zT_53;
    unsigned int zT_55;
    int zT_56;
    unsigned int zT_58;
    unsigned int zT_59;
    int zT_60;
    int zT_62;
    zT_8143F551_AstKind zT_63;
    int zT_67 = 0;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_71;
    unsigned int zT_72;
    int zT_73;
    int zT_75;
    zT_8143F551_AstKind zT_76;
    int zT_80 = 0;
    unsigned int zT_81;
    int zT_82;
    unsigned int zT_84;
    unsigned int zT_85;
    int zT_86;
    int zT_88;
    zT_8143F551_AstKind zT_89;
    int zT_93 = 0;
    unsigned int zT_94;
    int zT_95;
    unsigned int zT_97;
    zT_894C14AF_Arr_unsigned_int_51 stack;
    unsigned int sp;
    unsigned int node_idx;
    zT_22A7C88B_AstNode node;
    unsigned int ec_count;
    unsigned int ei;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_4[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        stack[_i] = zT_4[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    sp = zT_7;
    stack[sp] = root;
    zT_8 = 1;
    zT_10 = sp + (unsigned int)((unsigned int)zT_8);
    sp = zT_10;
    goto z_bb_1;
    z_bb_1:
    zT_11 = 0;
    if ((int)(sp > (unsigned int)zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = 1;
    zT_15 = sp - (unsigned int)((unsigned int)zT_13);
    sp = zT_15;
    zT_17 = stack[sp];
    node_idx = zT_17;
    zT_18 = 0;
    if ((int)(node_idx == (unsigned int)zT_18)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_21 = store;
    zT_22 = node_idx;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    node = zT_23;
    zT_24 = store;
    zT_25 = node_idx;
    callback(zT_24, zT_25);
    zT_26 = node.kind;
    zT_28 = zF_BB9BCB30_nodeHasNodeExtraChi(zT_26);
    if (zT_28) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = store;
    zT_31 = node_idx;
    zT_32 = zF_8BA26B9E_astStoreNodePayload(zT_30, zT_31);
    zT_33 = 0;
    zT_29 = zT_32 != (unsigned int)zT_33;
    goto z_bb_9;
    z_bb_8:
    zT_29 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_29) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_36 = store;
    zT_37 = node_idx;
    zT_38 = zF_152E19CB_astStoreNodeExtraCh(zT_36, zT_37);
    ec_count = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    ei = zT_41;
    goto z_bb_12;
    z_bb_11:
    zT_59 = node.child_2;
    zT_60 = 0;
    if ((int)(zT_59 != (unsigned int)zT_60)) goto z_bb_16; else goto z_bb_17;
    z_bb_12:
    if ((int)(ei < (unsigned int)((unsigned int)ec_count))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_44 = store;
    zT_45 = node_idx;
    zT_52 = zF_B10B1BC1_astStoreNodeExtraCh(zT_44, zT_45, (unsigned int)((unsigned int)(unsigned int)((unsigned int)(ec_count - (unsigned int)((unsigned int)ei)) - (unsigned int)(1))));
    stack[sp] = zT_52;
    zT_53 = 1;
    zT_55 = sp + (unsigned int)((unsigned int)zT_53);
    sp = zT_55;
    zT_56 = 1;
    zT_58 = ei + (unsigned int)((unsigned int)zT_56);
    ei = zT_58;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_63 = node.kind;
    zT_67 = zF_C395F6FD_nodeChildIsNode(zT_63, (unsigned char)(2));
    zT_62 = zT_67;
    goto z_bb_18;
    z_bb_17:
    zT_62 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_62) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_68 = node.child_2;
    stack[sp] = zT_68;
    zT_69 = 1;
    zT_71 = sp + (unsigned int)((unsigned int)zT_69);
    sp = zT_71;
    goto z_bb_20;
    z_bb_20:
    zT_72 = node.child_1;
    zT_73 = 0;
    if ((int)(zT_72 != (unsigned int)zT_73)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_76 = node.kind;
    zT_80 = zF_C395F6FD_nodeChildIsNode(zT_76, (unsigned char)(1));
    zT_75 = zT_80;
    goto z_bb_23;
    z_bb_22:
    zT_75 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_75) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_81 = node.child_1;
    stack[sp] = zT_81;
    zT_82 = 1;
    zT_84 = sp + (unsigned int)((unsigned int)zT_82);
    sp = zT_84;
    goto z_bb_25;
    z_bb_25:
    zT_85 = node.child_0;
    zT_86 = 0;
    if ((int)(zT_85 != (unsigned int)zT_86)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_89 = node.kind;
    zT_93 = zF_C395F6FD_nodeChildIsNode(zT_89, (unsigned char)(0));
    zT_88 = zT_93;
    goto z_bb_28;
    z_bb_27:
    zT_88 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_88) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_94 = node.child_0;
    stack[sp] = zT_94;
    zT_95 = 1;
    zT_97 = sp + (unsigned int)((unsigned int)zT_95);
    sp = zT_97;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_4;
}

/* astStoreComputeMemory */
zT_79FAE712_u64 zF_65495966_astStoreComputeMemo(zT_6B0A7D14_AstStore* store) {
    int zT_2;
    zT_79FAE712_u64 zT_3;
    int zT_5;
    unsigned int zT_6;
    int zT_8;
    unsigned int zT_9;
    zT_9ACA7D7F_anon_226748 zT_10;
    unsigned int zT_11;
    zT_9ACA7D7F_anon_226748 zT_13;
    zT_E2FE8472_NodeBlockInfo* zT_14;
    zT_E2FE8472_NodeBlockInfo zT_15;
    unsigned char zT_16;
    int zT_19;
    unsigned int zT_21;
    int zT_22;
    unsigned int zT_23;
    zT_79FAE712_u64 zT_27;
    zT_9ACA7D7F_anon_226748 zT_28;
    unsigned int zT_29;
    zT_79FAE712_u64 zT_33;
    zT_A2BDBE24_anon_226712 zT_34;
    unsigned int zT_35;
    zT_79FAE712_u64 zT_39;
    zT_9DBB77AE_anon_226721 zT_40;
    unsigned int zT_41;
    zT_79FAE712_u64 zT_45;
    zT_98B93138_anon_226730 zT_46;
    unsigned int zT_47;
    zT_79FAE712_u64 zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    zT_01BE9D46_AstValuePool* zT_53;
    zT_79FAE712_u64 zT_55 = 0;
    zT_79FAE712_u64 zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    zT_01BE9D46_AstValuePool* zT_58;
    zT_79FAE712_u64 zT_60 = 0;
    zT_79FAE712_u64 zT_61;
    zT_6B0A7D14_AstStore* zT_62;
    zT_01BE9D46_AstValuePool* zT_63;
    zT_79FAE712_u64 zT_65 = 0;
    zT_79FAE712_u64 zT_66;
    zT_6B0A7D14_AstStore* zT_67;
    zT_01BE9D46_AstValuePool* zT_68;
    zT_79FAE712_u64 zT_70 = 0;
    zT_79FAE712_u64 zT_71;
    zT_79FAE712_u64 total;
    unsigned int resident_blocks;
    unsigned int bi;
    zT_2 = 0;
    zT_3 = (zT_79FAE712_u64)zT_2;
    total = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    resident_blocks = zT_6;
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    bi = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_10 = store->block_table;
    zT_11 = zT_10.len;
    if ((int)(bi < zT_11)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_13 = store->block_table;
    zT_14 = zT_13.items;
    zT_15 = zT_14[bi];
    zT_16 = zT_15.resident;
    if ((int)(zT_16 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_27 = total + (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)resident_blocks) * (zT_79FAE712_u64)(114688));
    total = zT_27;
    zT_28 = store->block_table;
    zT_29 = zT_28.len;
    zT_33 = total + (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_29) * (unsigned int)(12));
    total = zT_33;
    zT_34 = store->float_values;
    zT_35 = zT_34.len;
    zT_39 = total + (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_35) * (unsigned int)(8));
    total = zT_39;
    zT_40 = store->string_values;
    zT_41 = zT_40.len;
    zT_45 = total + (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_41) * (unsigned int)(4));
    total = zT_45;
    zT_46 = store->fn_protos;
    zT_47 = zT_46.len;
    zT_51 = total + (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_47) * (unsigned int)(16));
    total = zT_51;
    zT_52 = store;
    zT_53 = &store->extra_children;
    zT_55 = zF_27FFD5B8_valuePoolResident(zT_52, zT_53);
    zT_56 = total + zT_55;
    total = zT_56;
    zT_57 = store;
    zT_58 = &store->extra_ranges;
    zT_60 = zF_27FFD5B8_valuePoolResident(zT_57, zT_58);
    zT_61 = total + zT_60;
    total = zT_61;
    zT_62 = store;
    zT_63 = &store->identifiers;
    zT_65 = zF_27FFD5B8_valuePoolResident(zT_62, zT_63);
    zT_66 = total + zT_65;
    total = zT_66;
    zT_67 = store;
    zT_68 = &store->int_values;
    zT_70 = zF_27FFD5B8_valuePoolResident(zT_67, zT_68);
    zT_71 = total + zT_70;
    total = zT_71;
    return total;
    z_bb_4:
    zT_22 = 1;
    zT_23 = bi + zT_22;
    bi = zT_23;
    goto z_bb_1;
    z_bb_5:
    zT_19 = 1;
    zT_21 = resident_blocks + (unsigned int)((unsigned int)zT_19);
    resident_blocks = zT_21;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* valuePoolResident */
zT_79FAE712_u64 zF_27FFD5B8_valuePoolResident(zT_6B0A7D14_AstStore* store, zT_01BE9D46_AstValuePool* p) {
    int zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    zT_79FAE712_u64 zT_9;
    unsigned char zT_10;
    zT_79FAE712_u64 zT_16;
    zT_79FAE712_u64 sum;
    (void)store;
    zT_3 = 0;
    zT_4 = (zT_79FAE712_u64)zT_3;
    sum = zT_4;
    zT_5 = p->head_cap;
    if ((int)(zT_5 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = sum + (zT_79FAE712_u64)(4096);
    sum = zT_9;
    goto z_bb_2;
    z_bb_2:
    zT_10 = p->cache_allocated;
    if ((int)(zT_10 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = sum + (zT_79FAE712_u64)(32768);
    sum = zT_16;
    goto z_bb_4;
    z_bb_4:
    return sum;
}

/* __module_init */
void zF_780653D2___module_init_8(void) {
    unsigned char* zT_0;
    zT_0 = "ZZZ_ASTNODE_24B_OFFSETS_kind0_flags1_pad2_spanlen4_spanstart8_child0_12_child1_16_child2_20";
    zG_CC2D7D2E_zzz_astnode_sz = zT_0;
    return;
}

/* EOF */
