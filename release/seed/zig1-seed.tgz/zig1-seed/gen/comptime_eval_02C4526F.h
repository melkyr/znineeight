#ifndef ZIG_MODULE_COMPTIME_EVAL_02C4526F_H
#define ZIG_MODULE_COMPTIME_EVAL_02C4526F_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "type_registry_8EE489B8.h"
#include "ast_2FA12982.h"
#include "string_interner_51340A9F.h"
#include "symbol_table_74081C75.h"
#include "type_resolver_7446D285.h"
#include "diagnostics_B9C6175E.h"

#ifndef ZIG_ENUM_zT_FEE05D6C_SignClass
#define ZIG_ENUM_zT_FEE05D6C_SignClass
typedef unsigned char zT_FEE05D6C_SignClass;
#define zT_FEE05D6C_SignClass_unknown 0
#define zT_FEE05D6C_SignClass_negative 1
#define zT_FEE05D6C_SignClass_non_negative 2

#endif /* ZIG_ENUM_zT_FEE05D6C_SignClass */
#ifndef ZIG_STRUCT_zT_DA663F79_ComptimeEval
#define ZIG_STRUCT_zT_DA663F79_ComptimeEval
struct zT_DA663F79_ComptimeEval {
	zT_338B7C76_TypeRegistry* registry;
	zT_6B0A7D14_AstStore* store;
	zT_D3EB6303_StringInterner* interner;
	zT_3D7259E2_SymbolRegistry* symbol_reg;
	unsigned int size_of_id;
	unsigned int align_of_id;
	unsigned int offset_of_id;
	unsigned int bit_size_of_id;
	unsigned int bit_offset_of_id;
	unsigned int int_cast_id;
	unsigned int as_id;
	unsigned int float_cast_id;
	unsigned int int_to_float_id;
	unsigned int is_windows_id;
	unsigned char host_is_windows;
	zT_03B97CED_Opt_398 local_consts;
	zT_7034F045_Opt_228 diag;
};
#endif /* ZIG_STRUCT_zT_DA663F79_ComptimeEval */

/* Forward declarations */
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry*, zT_6B0A7D14_AstStore*, zT_D3EB6303_StringInterner*, zT_3D7259E2_SymbolRegistry*);
zT_E53A25A2_Opt_203 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval*, unsigned int, zT_8143F551_AstKind, unsigned int);
zT_E53A25A2_Opt_203 zF_CD4BD838_comptimeEvalCompare(zT_DA663F79_ComptimeEval*, unsigned int, zT_8143F551_AstKind, unsigned int);
zT_E53A25A2_Opt_203 zF_40F99F20_comptimeEvalLogical(zT_DA663F79_ComptimeEval*, unsigned int, zT_8143F551_AstKind, unsigned int);
zT_49E17557_Opt_2 zF_118C3450_comptimeEvalOperand(zT_DA663F79_ComptimeEval*, unsigned int);
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval*, unsigned int);
unsigned char zF_BB4D792E_comptimeValFitsType(zT_DA663F79_ComptimeEval*, zT_89B1DDDA_ComptimeVal, unsigned int, unsigned int);
zT_FEE05D6C_SignClass zF_E7337520_comptimeEvalSignCla(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
zT_E53A25A2_Opt_203 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
zT_BCEE1C54_Opt_16 zF_B719EB81_comptimeEvalFloat(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
unsigned char zF_0D60B956_comptimeEvalOperand(zT_DA663F79_ComptimeEval*, unsigned int, zT_89B1DDDA_ComptimeVal);
zT_BCEE1C54_Opt_16 zF_8C4B1954_comptimeEvalFloatBu(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
zT_E53A25A2_Opt_203 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval*, unsigned int);
zT_E53A25A2_Opt_203 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
void zF_780653D2___module_init_18(void);
/* Storage globals (extern decls) */
extern unsigned int zG_9D6D351A_WIDTH_FLOAT;

#endif /* ZIG_MODULE_COMPTIME_EVAL_02C4526F_H */
