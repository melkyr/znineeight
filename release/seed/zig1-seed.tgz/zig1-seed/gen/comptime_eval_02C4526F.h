#ifndef ZIG_MODULE_COMPTIME_EVAL_02C4526F_H
#define ZIG_MODULE_COMPTIME_EVAL_02C4526F_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "type_registry_8EE489B8.h"
#include "ast_2FA12982.h"
#include "string_interner_51340A9F.h"
#include "symbol_table_74081C75.h"
#include "type_resolver_7446D285.h"

#ifndef ZIG_STRUCT_zT_DA663F79_ComptimeEval
#define ZIG_STRUCT_zT_DA663F79_ComptimeEval
struct zT_DA663F79_ComptimeEval {
	zT_338B7C76_TypeRegistry* registry;
	zT_6B0A7D14_AstStore* store;
	zT_D3EB6303_StringInterner* interner;
	zT_3D7259E2_SymbolRegistry* symbol_reg;
	unsigned int size_of_id;
	unsigned int align_of_id;
	unsigned int offset_of_id;
	unsigned int bit_size_of_id;
	unsigned int bit_offset_of_id;
	unsigned int int_cast_id;
	unsigned int is_windows_id;
	int host_is_windows;
};
#endif /* ZIG_STRUCT_zT_DA663F79_ComptimeEval */

/* Forward declarations */
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry*, zT_6B0A7D14_AstStore*, zT_D3EB6303_StringInterner*, zT_3D7259E2_SymbolRegistry*);
zT_E43A240F_Opt_200 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval*, unsigned int, zT_8143F551_AstKind, unsigned int);
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval*, unsigned int);
zT_E43A240F_Opt_200 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
zT_E43A240F_Opt_200 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval*, unsigned int);
zT_E43A240F_Opt_200 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_COMPTIME_EVAL_02C4526F_H */
