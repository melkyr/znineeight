#ifndef ZIG_MODULE_COMPTIME_EVAL_02C4526F_H
#define ZIG_MODULE_COMPTIME_EVAL_02C4526F_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "type_registry_8EE489B8.h"
#include "ast_2FA12982.h"
#include "string_interner_51340A9F.h"
#include "symbol_table_74081C75.h"
#include "type_resolver_7446D285.h"
#include "diagnostics_B9C6175E.h"
#include "hash_02AFCD13.h"
#include "allocator_E75B7A0B.h"

#ifndef ZIG_STRUCT_zT_DA663F79_ComptimeEval
#define ZIG_STRUCT_zT_DA663F79_ComptimeEval
struct zT_DA663F79_ComptimeEval {
	zT_338B7C76_TypeRegistry* registry;
	zT_6B0A7D14_AstStore* store;
	zT_D3EB6303_StringInterner* interner;
	zT_3D7259E2_SymbolRegistry* symbol_reg;
	unsigned int size_of_id;
	unsigned int align_of_id;
	unsigned int offset_of_id;
	unsigned int bit_size_of_id;
	unsigned int bit_offset_of_id;
	unsigned int int_cast_id;
	unsigned int as_id;
	unsigned int float_cast_id;
	unsigned int int_to_float_id;
	unsigned int is_windows_id;
	unsigned char host_is_windows;
	zT_03B97CED_Opt_398 local_consts;
	zT_7034F045_Opt_228 diag;
};
#endif /* ZIG_STRUCT_zT_DA663F79_ComptimeEval */

/* Forward declarations */
zT_77F6F59C_ComptimeFoldTable zF_9BB9958E_comptimeFoldTableIn(zT_3E40CD83_Sand*);
void zF_82A38CDF_comptimeFoldTableGr(zT_77F6F59C_ComptimeFoldTable*);
void zF_376429F5_comptimeFoldTablePu(zT_77F6F59C_ComptimeFoldTable*, unsigned int, zT_89B1DDDA_ComptimeVal);
zT_E53A25A2_Opt_203 zF_A230D7A8_comptimeFoldTableGe(zT_77F6F59C_ComptimeFoldTable*, unsigned int);
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry*, zT_6B0A7D14_AstStore*, zT_D3EB6303_StringInterner*, zT_3D7259E2_SymbolRegistry*);
zT_0163D9A4_ComptimeInt zF_DC9B7BC0_ciZeroInt(void);
zT_0163D9A4_ComptimeInt zF_1EAA44E6_ciFromU64(zT_79FAE712_u64);
zT_0163D9A4_ComptimeInt zF_8F225501_ciPow2(unsigned int);
void zF_45C2B9E7_ciSet(zT_0163D9A4_ComptimeInt*, zT_0163D9A4_ComptimeInt);
void zF_390E9E58_ciNormalize(zT_0163D9A4_ComptimeInt*);
unsigned char zF_0F5FA15F_ciIsZero(zT_0163D9A4_ComptimeInt);
int zF_0B19E30C_ciMagCmp(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt);
int zF_6408F093_ciCmp(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt);
zT_79FAE712_u64 zF_4F2C9C5D_ciToU64(zT_0163D9A4_ComptimeInt);
double zF_E6CE9168_ciToF64(zT_0163D9A4_ComptimeInt);
zT_89B1DDDA_ComptimeVal zF_237A4571_ciIntVal(zT_0163D9A4_ComptimeInt);
zT_89B1DDDA_ComptimeVal zF_E867E750_ciBoolVal(unsigned char);
void zF_51463AE1_ciMagAnd(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
void zF_5F410015_ciMagOr(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
void zF_3DC94F2D_ciMagXor(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
void zF_EBF92AE9_ciMagNot(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_29F86241_ciMagAddInto(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_965473A4_ciMagSubInto(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_962947A9_ciMagAddOne(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_CBDA30A2_ciMagSubOne(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_8A5DB878_ciAdd(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_539A2D81_ciSub(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_EECBFD7D_ciNeg(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_A3E385DD_ciMul(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_25A0EEC0_ciDivMod(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*, zT_0163D9A4_ComptimeInt*);
unsigned char zF_E15DE14D_ciBitAnd(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_93823331_ciBitOr(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_C592CA21_ciBitXor(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_223ABA6D_ciBitNot(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_4FDD0D22_ciShl(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
unsigned char zF_41DCF718_ciShr(zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt*);
zT_E53A25A2_Opt_203 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval*, unsigned int, zT_8143F551_AstKind, unsigned int);
zT_E53A25A2_Opt_203 zF_CD4BD838_comptimeEvalCompare(zT_DA663F79_ComptimeEval*, unsigned int, zT_8143F551_AstKind, unsigned int);
zT_E53A25A2_Opt_203 zF_40F99F20_comptimeEvalLogical(zT_DA663F79_ComptimeEval*, unsigned int, zT_8143F551_AstKind, unsigned int);
zT_BAEE192E_Opt_10 zF_6B810D4A_comptimeEvalOperand(zT_DA663F79_ComptimeEval*, unsigned int);
zT_BAEE192E_Opt_10 zF_F60B0343_comptimeEvalOperand(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
unsigned int zF_CE5A812D_comptimeEvalWiderIn(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval*, unsigned int);
unsigned char zF_B28C4720_comptimeIntFitsType(zT_338B7C76_TypeRegistry*, zT_0163D9A4_ComptimeInt, unsigned int);
zT_79FAE712_u64 zF_FB88E1A5_comptimeIntMaterial(zT_0163D9A4_ComptimeInt);
unsigned char zF_EF3A264A_comptimeIntFits64(zT_0163D9A4_ComptimeInt);
zT_BAEE192E_Opt_10 zF_42B163B9_comptimeIntUntypedT(zT_0163D9A4_ComptimeInt);
zT_BBEE1AC1_Opt_11 zF_E3420380_comptimeValStoreU64(zT_89B1DDDA_ComptimeVal);
zT_E53A25A2_Opt_203 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
zT_BCEE1C54_Opt_16 zF_B719EB81_comptimeEvalFloat(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
zT_BCEE1C54_Opt_16 zF_8C4B1954_comptimeEvalFloatBu(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
zT_E53A25A2_Opt_203 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval*, unsigned int);
zT_E53A25A2_Opt_203 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval*, unsigned int, unsigned int);
unsigned char zF_EFA97F51_comptimeEvalDeclFit(zT_DA663F79_ComptimeEval*, unsigned int, zT_89B1DDDA_ComptimeVal);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_COMPTIME_EVAL_02C4526F_H */
