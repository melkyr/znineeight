#ifndef ZIG_MODULE_STRING_INTERNER_51340A9F_H
#define ZIG_MODULE_STRING_INTERNER_51340A9F_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "hash_02AFCD13.h"
#include "mem_19CC4C40.h"
#include "allocator_E75B7A0B.h"
#include "pal_388A8A1B.h"

#ifndef ZIG_STRUCT_zT_D3EB6303_StringInterner
#define ZIG_STRUCT_zT_D3EB6303_StringInterner
struct zT_D3EB6303_StringInterner {
	unsigned short* buckets_narrow_items;
	unsigned int* buckets_wide_items;
	unsigned char buckets_is_wide;
	unsigned int buckets_len;
	unsigned int buckets_capacity;
	zT_EABC94D3_InternEntry* entries_items;
	unsigned int entries_len;
	unsigned int entries_capacity;
	zT_3E40CD83_Sand* entries_allocator;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_D3EB6303_StringInterner */
#ifndef ZIG_STRUCT_zT_EABC94D3_InternEntry
#define ZIG_STRUCT_zT_EABC94D3_InternEntry
struct zT_EABC94D3_InternEntry {
	zT_8F083A69_Slice_zT_0B42B2F8_u text;
	unsigned int next;
};
#endif /* ZIG_STRUCT_zT_EABC94D3_InternEntry */

/* Forward declarations */
void zF_9DC2533D_internerBucketsAllo(zT_D3EB6303_StringInterner*, unsigned int);
void zF_22329EAD_internerBucketsAllo(zT_D3EB6303_StringInterner*, unsigned int);
unsigned int zF_6162B7CC_internerBucketGet(zT_D3EB6303_StringInterner*, unsigned int);
void zF_DF70E160_internerBucketSet(zT_D3EB6303_StringInterner*, unsigned int, unsigned int);
void zF_57DE4452_internerBucketZero(zT_D3EB6303_StringInterner*, unsigned int);
void zF_FB994A71_ensureCapacityEntri(zT_EABC94D3_InternEntry**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int);
void zF_A7C4EDCF_appendEntry(zT_EABC94D3_InternEntry**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, zT_EABC94D3_InternEntry);
zT_D3EB6303_StringInterner zF_FB2E811D_stringInternerInit(zT_3E40CD83_Sand*, unsigned int);
unsigned int zF_50C274AF_stringInternerInter(zT_D3EB6303_StringInterner*, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_9134020D_stringInternerGet(zT_D3EB6303_StringInterner*, unsigned int);
unsigned char* zF_EDFF876E_stringInternerCopyT(zT_D3EB6303_StringInterner*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_3765B9F7_stringInternerMakeB(zT_D3EB6303_StringInterner*);
void zF_3A9E8EDF_stringInternerGrowB(zT_D3EB6303_StringInterner*, unsigned int);
/* Storage globals (extern decls) */
extern zT_D3EB6303_StringInterner zG_D3EB6303_StringInterner;

#endif /* ZIG_MODULE_STRING_INTERNER_51340A9F_H */
