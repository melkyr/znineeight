#ifndef ZIG_SPECIAL_TYPES_H
#define ZIG_SPECIAL_TYPES_H

#include "zig_compat.h"
#include "zig_runtime.h"

/* Error tags */
#define ERROR_OutOfMemory 2
#define ERROR_UnexpectedToken 1

typedef struct zT_36103E01_TrackingAllocator zT_36103E01_TrackingAllocator;
typedef struct zT_5FDE47EF_TrackingAllocatorRe zT_5FDE47EF_TrackingAllocatorRe;
typedef struct zT_D3EB6303_StringInterner zT_D3EB6303_StringInterner;
typedef struct zT_6B45117F_SourceFileArrayList zT_6B45117F_SourceFileArrayList;
typedef struct zT_5BC08DC6_Location zT_5BC08DC6_Location;
typedef struct zT_227EDE07_SourceManager zT_227EDE07_SourceManager;
typedef struct zT_B258D528_RelatedSpan zT_B258D528_RelatedSpan;
typedef struct zT_C0B2E5AF_DiagnosticArrayList zT_C0B2E5AF_DiagnosticArrayList;
typedef struct zT_F85C5DED_DiagnosticCollector zT_F85C5DED_DiagnosticCollector;
typedef struct zT_CEC2984A_NameMangler zT_CEC2984A_NameMangler;
typedef union zT_85CBA4DB_TokenValue zT_85CBA4DB_TokenValue;
typedef struct zT_243D6A41_FnProto zT_243D6A41_FnProto;
typedef struct zT_E2FE8472_NodeBlockInfo zT_E2FE8472_NodeBlockInfo;
typedef struct zT_6DD0D007_AstSlot zT_6DD0D007_AstSlot;
typedef struct zT_E41AEC18_ModuleEntryArrayLis zT_E41AEC18_ModuleEntryArrayLis;
typedef struct zT_4EA49A91_SearchDirArrayList zT_4EA49A91_SearchDirArrayList;
typedef struct zT_ABD0FF08_HashMapSpillMeta zT_ABD0FF08_HashMapSpillMeta;
typedef struct zT_47A5CDFB_ImportQueue zT_47A5CDFB_ImportQueue;
typedef struct zT_7A19C4A5_DeferEntry zT_7A19C4A5_DeferEntry;
typedef struct zT_438E6589_NullGuard zT_438E6589_NullGuard;
typedef struct zT_7E2F335A_AnalyzerContext zT_7E2F335A_AnalyzerContext;
typedef struct zT_060CD1EB_SymbolTable zT_060CD1EB_SymbolTable;
typedef struct zT_3D7259E2_SymbolRegistry zT_3D7259E2_SymbolRegistry;
typedef struct zT_112BF819_PtrPayload zT_112BF819_PtrPayload;
typedef struct zT_E834303C_ArrayPayload zT_E834303C_ArrayPayload;
typedef struct zT_0BB2A741_SlicePayload zT_0BB2A741_SlicePayload;
typedef struct zT_0B10E8E9_OptionalPayload zT_0B10E8E9_OptionalPayload;
typedef struct zT_42C2D6BF_EUPayload zT_42C2D6BF_EUPayload;
typedef struct zT_0B73C507_ErrorSetPayload zT_0B73C507_ErrorSetPayload;
typedef struct zT_0317B1D5_FnPayload zT_0317B1D5_FnPayload;
typedef struct zT_406493CE_StructPayload zT_406493CE_StructPayload;
typedef struct zT_457ECFEE_EnumPayload zT_457ECFEE_EnumPayload;
typedef struct zT_AF9231A2_UnionPayload zT_AF9231A2_UnionPayload;
typedef struct zT_54FF90FA_TaggedUnionPayload zT_54FF90FA_TaggedUnionPayload;
typedef struct zT_666DC2E1_TuplePayload zT_666DC2E1_TuplePayload;
typedef struct zT_42E798B0_UnresolvedPayload zT_42E798B0_UnresolvedPayload;
typedef struct zT_2DF01B61_FieldEntry zT_2DF01B61_FieldEntry;
typedef struct zT_E276DDD0_PackedBitField zT_E276DDD0_PackedBitField;
typedef struct zT_FA398D58_PackedStructInfo zT_FA398D58_PackedStructInfo;
typedef struct zT_D96DCDF2_EnumMember zT_D96DCDF2_EnumMember;
typedef struct zT_FA84B422_FnParam zT_FA84B422_FnParam;
typedef struct zT_CE6A1A99_DeferAction zT_CE6A1A99_DeferAction;
typedef struct zT_78074DEF_LoopInfo zT_78074DEF_LoopInfo;
typedef struct zT_6996DA09_SwitchInfo zT_6996DA09_SwitchInfo;
typedef struct zT_6B356268_SemanticContext zT_6B356268_SemanticContext;
typedef struct zT_A528929E_DeferActionArrayLis zT_A528929E_DeferActionArrayLis;
typedef struct zT_5819C854_LoopInfoArrayList zT_5819C854_LoopInfoArrayList;
typedef struct zT_347CB10E_SwitchInfoArrayList zT_347CB10E_SwitchInfoArrayList;
typedef struct zT_FEED5D3B_ScopeNode zT_FEED5D3B_ScopeNode;
typedef struct zT_2F2F63D8_ScopeNodeArrayList zT_2F2F63D8_ScopeNodeArrayList;
typedef struct zT_573A3319_LocalBinding zT_573A3319_LocalBinding;
typedef struct zT_DCBFE211_CallInfo zT_DCBFE211_CallInfo;
typedef struct zT_4BD97095_SwitchCase zT_4BD97095_SwitchCase;
typedef struct zT_8779209D_LirParam zT_8779209D_LirParam;
typedef struct zT_1937645B_TempDecl zT_1937645B_TempDecl;
typedef struct zT_3BFB1E70_CallDirectData zT_3BFB1E70_CallDirectData;
typedef struct zT_0624AC1B_TailCallData zT_0624AC1B_TailCallData;
typedef struct zT_AC00B5F6_LirSideEntryArrayLi zT_AC00B5F6_LirSideEntryArrayLi;
typedef struct zT_DAE4631D_LirInstArrayList zT_DAE4631D_LirInstArrayList;
typedef struct zT_1CF28CA3_BasicBlockArrayList zT_1CF28CA3_BasicBlockArrayList;
typedef struct zT_CFE23D0A_LirParamArrayList zT_CFE23D0A_LirParamArrayList;
typedef struct zT_5D72FBF8_TempDeclArrayList zT_5D72FBF8_TempDeclArrayList;
typedef struct zT_9F514E82_SwitchCaseArrayList zT_9F514E82_SwitchCaseArrayList;
typedef struct zT_E7714190_LirSlot zT_E7714190_LirSlot;
typedef struct zT_CA01C129_LirSlotArrayList zT_CA01C129_LirSlotArrayList;
typedef struct zT_54906056_ModuleGlobalDecl zT_54906056_ModuleGlobalDecl;
typedef struct zT_E1A783EF_GlobalDeclArrayList zT_E1A783EF_GlobalDeclArrayList;
typedef struct zT_21D3708C_U32ToU32Map zT_21D3708C_U32ToU32Map;
typedef struct zT_A4CE86B7_U64ToU32Map zT_A4CE86B7_U64ToU32Map;
typedef struct zT_89877D19_U32ToU64Map zT_89877D19_U32ToU64Map;
typedef struct zT_B687BB96_U32ArrayList zT_B687BB96_U32ArrayList;
typedef struct zT_47B162D1_U8ArrayList zT_47B162D1_U8ArrayList;
typedef struct zT_1386C3E8_AstNodeArrayList zT_1386C3E8_AstNodeArrayList;
typedef struct zT_C4A0A7DB_U64ArrayList zT_C4A0A7DB_U64ArrayList;
typedef struct zT_AB1FE668_F64ArrayList zT_AB1FE668_F64ArrayList;
typedef struct zT_CCB21906_FnProtoArrayList zT_CCB21906_FnProtoArrayList;
typedef struct zT_E2DF2801_LocalConstScope zT_E2DF2801_LocalConstScope;
typedef struct zT_010C8DF0_ClassificationResul zT_010C8DF0_ClassificationResul;
typedef struct zT_C890C8CB_TypeResolver zT_C890C8CB_TypeResolver;
typedef struct zT_89B1DDDA_ComptimeVal zT_89B1DDDA_ComptimeVal;
typedef struct zT_DA663F79_ComptimeEval zT_DA663F79_ComptimeEval;
typedef struct zT_52CDA6EF_DepEdge zT_52CDA6EF_DepEdge;
typedef struct zT_4D61441E_DepGraph zT_4D61441E_DepGraph;
typedef struct zT_6DCFC8DB_FrontResCtx zT_6DCFC8DB_FrontResCtx;
typedef struct zT_902E38E8_AsyncFrameField zT_902E38E8_AsyncFrameField;
typedef struct zT_2CF63CE1_AsyncFrameFieldArra zT_2CF63CE1_AsyncFrameFieldArra;
typedef struct zT_6D148508_Scan zT_6D148508_Scan;
typedef struct zT_5839647A_AsyncTransformCtx zT_5839647A_AsyncTransformCtx;
typedef struct zT_95967543_Build zT_95967543_Build;
typedef struct zT_C72CD5DD_FrameInitParam zT_C72CD5DD_FrameInitParam;
typedef struct zT_79D145D1_AsyncFrameHeader zT_79D145D1_AsyncFrameHeader;
typedef struct zT_5EDE903E_Ctx zT_5EDE903E_Ctx;
typedef struct zT_6B392E0E_StateEntry zT_6B392E0E_StateEntry;
typedef struct zT_8DDC796C_anon_225780 zT_8DDC796C_anon_225780;
typedef struct zT_8EDEB996_anon_225795 zT_8EDEB996_anon_225795;
typedef struct zT_4B5CDF4D_anon_225804 zT_4B5CDF4D_anon_225804;
typedef struct zT_445A95B1_anon_225813 zT_445A95B1_anon_225813;
typedef struct zT_485A9BFD_anon_225817 zT_485A9BFD_anon_225817;
typedef struct zT_4E5F229D_anon_225831 zT_4E5F229D_anon_225831;
typedef struct zT_3B0148B6_anon_74360 zT_3B0148B6_anon_74360;
typedef struct zT_4301554E_anon_74368 zT_4301554E_anon_74368;
typedef struct zT_3F038D99_anon_74376 zT_3F038D99_anon_74376;
typedef struct zT_4D05E23A_anon_74386 zT_4D05E23A_anon_74386;
typedef struct zT_4F0823F7_anon_74396 zT_4F0823F7_anon_74396;
typedef struct zT_C940E31B_anon_74406 zT_C940E31B_anon_74406;
typedef struct zT_C73EA15E_anon_74416 zT_C73EA15E_anon_74416;
typedef struct zT_3943D202_anon_74434 zT_3943D202_anon_74434;
typedef struct zT_3536FFC3_anon_74442 zT_3536FFC3_anon_74442;
typedef struct zT_3334BE06_anon_74452 zT_3334BE06_anon_74452;
typedef struct zT_C53C5FA1_anon_74462 zT_C53C5FA1_anon_74462;
typedef struct zT_3B3947CC_anon_74472 zT_3B3947CC_anon_74472;
typedef struct zT_3B551E49_anon_74484 zT_3B551E49_anon_74484;
typedef struct zT_B952130C_anon_74490 zT_B952130C_anon_74490;
typedef struct zT_B7520FE6_anon_74496 zT_B7520FE6_anon_74496;
typedef struct zT_4D6C4EBC_anon_74502 zT_4D6C4EBC_anon_74502;
typedef struct zT_556E99EB_anon_74510 zT_556E99EB_anon_74510;
typedef struct zT_4D6E8D53_anon_74518 zT_4D6E8D53_anon_74518;
typedef struct zT_4967CB42_anon_74526 zT_4967CB42_anon_74526;
typedef struct zT_4D6A1025_anon_74534 zT_4D6A1025_anon_74534;
typedef struct zT_516A1671_anon_74538 zT_516A1671_anon_74538;
typedef struct zT_CF7615BE_anon_74548 zT_CF7615BE_anon_74548;
typedef struct zT_49791463_anon_74554 zT_49791463_anon_74554;
typedef struct zT_DB71AB74_anon_74560 zT_DB71AB74_anon_74560;
typedef struct zT_D971A84E_anon_74566 zT_D971A84E_anon_74566;
typedef struct zT_DD73ED31_anon_74574 zT_DD73ED31_anon_74574;
typedef struct zT_5D7FEFA4_anon_74582 zT_5D7FEFA4_anon_74582;
typedef struct zT_577FE632_anon_74588 zT_577FE632_anon_74588;
typedef struct zT_C982D83F_anon_74594 zT_C982D83F_anon_74594;
typedef struct zT_71240677_anon_74600 zT_71240677_anon_74600;
typedef struct zT_6B21BE6E_anon_74610 zT_6B21BE6E_anon_74610;
typedef struct zT_6321B1D6_anon_74618 zT_6321B1D6_anon_74618;
typedef struct zT_5F1F6CF3_anon_74626 zT_5F1F6CF3_anon_74626;
typedef struct zT_5B1D2810_anon_74634 zT_5B1D2810_anon_74634;
typedef struct zT_DB1A1FF9_anon_74642 zT_DB1A1FF9_anon_74642;
typedef struct zT_E11A296B_anon_74648 zT_E11A296B_anon_74648;
typedef struct zT_ED17FDB8_anon_74656 zT_ED17FDB8_anon_74656;
typedef struct zT_EB15BBFB_anon_74662 zT_EB15BBFB_anon_74662;
typedef struct zT_E515B289_anon_74668 zT_E515B289_anon_74668;
typedef struct zT_6B12B3E4_anon_74674 zT_6B12B3E4_anon_74674;
typedef struct zT_5F12A100_anon_74678 zT_5F12A100_anon_74678;
typedef struct zT_5D105F43_anon_74684 zT_5D105F43_anon_74684;
typedef struct zT_5B0E1D86_anon_74690 zT_5B0E1D86_anon_74690;
typedef struct zT_5D0E20AC_anon_74696 zT_5D0E20AC_anon_74696;
typedef struct zT_F08C9D26_anon_74706 zT_F08C9D26_anon_74706;
typedef struct zT_768FAEAF_anon_74712 zT_768FAEAF_anon_74712;
typedef struct zT_808FBE6D_anon_74718 zT_808FBE6D_anon_74718;
typedef struct zT_8091FD04_anon_74726 zT_8091FD04_anon_74726;
typedef struct zT_80943B9B_anon_74734 zT_80943B9B_anon_74734;
typedef struct zT_7C94354F_anon_74738 zT_7C94354F_anon_74738;
typedef struct zT_8082F27A_anon_74746 zT_8082F27A_anon_74746;
typedef struct zT_80853111_anon_74750 zT_80853111_anon_74750;
typedef struct zT_82853437_anon_74756 zT_82853437_anon_74756;
typedef struct zT_04883F74_anon_74762 zT_04883F74_anon_74762;
typedef struct zT_00883928_anon_74766 zT_00883928_anon_74766;
typedef struct zT_EC8A5843_anon_74770 zT_EC8A5843_anon_74770;
typedef struct zT_F08A5E8F_anon_74774 zT_F08A5E8F_anon_74774;
typedef struct zT_047934EA_anon_74782 zT_047934EA_anon_74782;
typedef struct zT_FA79252C_anon_74788 zT_FA79252C_anon_74788;
typedef struct zT_E88C3713_anon_74802 zT_E88C3713_anon_74802;
typedef struct zT_E689F556_anon_74812 zT_E689F556_anon_74812;
typedef struct zT_769193CB_anon_74820 zT_769193CB_anon_74820;
typedef struct zT_6C8F4576_anon_74834 zT_6C8F4576_anon_74834;
typedef struct zT_7A961745_anon_74848 zT_7A961745_anon_74848;
typedef struct zT_F09B4E35_anon_74862 zT_F09B4E35_anon_74862;
typedef struct zT_EA99062C_anon_74876 zT_EA99062C_anon_74876;
typedef struct zT_72A09809_anon_74888 zT_72A09809_anon_74888;
typedef struct zT_8F078A1A_anon_74904 zT_8F078A1A_anon_74904;
typedef struct zT_9109CBD7_anon_74910 zT_9109CBD7_anon_74910;
typedef struct zT_8D09C58B_anon_74914 zT_8D09C58B_anon_74914;
typedef struct zT_05047245_anon_74930 zT_05047245_anon_74930;
typedef struct zT_90FCFFE4_anon_74942 zT_90FCFFE4_anon_74942;
typedef struct zT_2B3424E9_ParseToken zT_2B3424E9_ParseToken;
typedef struct zT_3A355BD2_Token zT_3A355BD2_Token;
typedef struct zT_F4EBEA72_OpInfo zT_F4EBEA72_OpInfo;
typedef struct zT_22A7C88B_AstNode zT_22A7C88B_AstNode;
typedef struct zT_4DB1475B_ModuleResolver zT_4DB1475B_ModuleResolver;
typedef struct zT_3A105EF1_Symbol zT_3A105EF1_Symbol;
typedef struct zT_D155D06D_Type zT_D155D06D_Type;
typedef union zT_A8A5B231_LirSideEntry zT_A8A5B231_LirSideEntry;
typedef struct zT_88A68B1A_BasicBlock zT_88A68B1A_BasicBlock;
typedef struct zT_02EB57B2_LirLowerer zT_02EB57B2_LirLowerer;
typedef struct zT_BBC23664_LirFunction zT_BBC23664_LirFunction;
typedef struct zT_66E7D2EF_CoercionTable zT_66E7D2EF_CoercionTable;
typedef struct zT_338B7C76_TypeRegistry zT_338B7C76_TypeRegistry;
typedef struct zT_6E8D187B_ModuleEntry zT_6E8D187B_ModuleEntry;
typedef struct zT_9CDC9863_CoercionEntry zT_9CDC9863_CoercionEntry;
typedef struct zT_38C12417_SemanticAnalyzer zT_38C12417_SemanticAnalyzer;
typedef struct zT_3F3BF87A_AsyncFrameLayout zT_3F3BF87A_AsyncFrameLayout;
typedef struct zT_EABC94D3_InternEntry zT_EABC94D3_InternEntry;
typedef struct zT_ED18556E_SourceFile zT_ED18556E_SourceFile;
typedef struct zT_C1009AE8_KeywordEntry zT_C1009AE8_KeywordEntry;
typedef struct zT_138FFB41_Lexer zT_138FFB41_Lexer;
typedef struct zT_3E40CD83_Sand zT_3E40CD83_Sand;
typedef struct zT_C59F83AC_SandSegment zT_C59F83AC_SandSegment;
typedef struct zT_50FBF81E_Diagnostic zT_50FBF81E_Diagnostic;
typedef struct zT_63BE4FF5_BufferedWriter zT_63BE4FF5_BufferedWriter;
typedef struct zT_CEC2984A_NameMangler_1 zT_CEC2984A_NameMangler_1;
typedef struct zT_6BA597BC_LirInst zT_6BA597BC_LirInst;
typedef struct zT_ABC1EBBE_TypeResolveEnv zT_ABC1EBBE_TypeResolveEnv;
typedef struct zT_D21A8776_SpillStore zT_D21A8776_SpillStore;
typedef struct zT_2C0927B0_StateMap zT_2C0927B0_StateMap;
typedef struct zT_C98AF326_CompilerCli zT_C98AF326_CompilerCli;
typedef struct zT_69057089_CompilerAlloc zT_69057089_CompilerAlloc;
typedef struct zT_7D82FE60_GrowableSand zT_7D82FE60_GrowableSand;
typedef struct zT_72C4E2ED_C89Emitter zT_72C4E2ED_C89Emitter;
typedef struct zT_01BE9D46_AstValuePool zT_01BE9D46_AstValuePool;
typedef struct zT_072B53A6_ModuleRegistry zT_072B53A6_ModuleRegistry;
typedef struct zT_7E7544E4_LirStream zT_7E7544E4_LirStream;
typedef struct zT_8EED1867_ResolvedTypeTable zT_8EED1867_ResolvedTypeTable;
typedef struct zT_B559F9DA_Parser zT_B559F9DA_Parser;
typedef struct zT_6B0A7D14_AstStore zT_6B0A7D14_AstStore;
typedef struct zT_5AB29387_CompilerContext zT_5AB29387_CompilerContext;
#ifndef ZIG_I64_zT_C69B2266_i64
#define ZIG_I64_zT_C69B2266_i64
typedef long long zT_C69B2266_i64;
#endif /* ZIG_I64_zT_C69B2266_i64 */
#ifndef ZIG_U64_zT_79FAE712_u64
#define ZIG_U64_zT_79FAE712_u64
typedef unsigned long long zT_79FAE712_u64;
#endif /* ZIG_U64_zT_79FAE712_u64 */
#ifndef ZIG_ENUM_zT_CAF40AAB_ColorMode
#define ZIG_ENUM_zT_CAF40AAB_ColorMode
typedef unsigned char zT_CAF40AAB_ColorMode;
#define zT_CAF40AAB_ColorMode_auto 0
#define zT_CAF40AAB_ColorMode_always 1
#define zT_CAF40AAB_ColorMode_never 2

#endif /* ZIG_ENUM_zT_CAF40AAB_ColorMode */
#ifndef ZIG_ENUM_zT_A4FB690E_ErrorFormat
#define ZIG_ENUM_zT_A4FB690E_ErrorFormat
typedef unsigned char zT_A4FB690E_ErrorFormat;
#define zT_A4FB690E_ErrorFormat_human 0
#define zT_A4FB690E_ErrorFormat_json 1
#define zT_A4FB690E_ErrorFormat_sarif 2

#endif /* ZIG_ENUM_zT_A4FB690E_ErrorFormat */
#ifndef ZIG_ENUM_zT_EAC3E484_TokenKind
#define ZIG_ENUM_zT_EAC3E484_TokenKind
typedef unsigned short zT_EAC3E484_TokenKind;
#define zT_EAC3E484_TokenKind_integer_literal 0
#define zT_EAC3E484_TokenKind_float_literal 1
#define zT_EAC3E484_TokenKind_string_literal 2
#define zT_EAC3E484_TokenKind_char_literal 3
#define zT_EAC3E484_TokenKind_identifier 4
#define zT_EAC3E484_TokenKind_builtin_identifier 5
#define zT_EAC3E484_TokenKind_lparen 6
#define zT_EAC3E484_TokenKind_rparen 7
#define zT_EAC3E484_TokenKind_lbracket 8
#define zT_EAC3E484_TokenKind_rbracket 9
#define zT_EAC3E484_TokenKind_lbrace 10
#define zT_EAC3E484_TokenKind_rbrace 11
#define zT_EAC3E484_TokenKind_semicolon 12
#define zT_EAC3E484_TokenKind_colon 13
#define zT_EAC3E484_TokenKind_comma 14
#define zT_EAC3E484_TokenKind_dot 15
#define zT_EAC3E484_TokenKind_at_sign 16
#define zT_EAC3E484_TokenKind_underscore 17
#define zT_EAC3E484_TokenKind_question_mark 18
#define zT_EAC3E484_TokenKind_bang 19
#define zT_EAC3E484_TokenKind_plus 20
#define zT_EAC3E484_TokenKind_minus 21
#define zT_EAC3E484_TokenKind_star 22
#define zT_EAC3E484_TokenKind_slash 23
#define zT_EAC3E484_TokenKind_percent 24
#define zT_EAC3E484_TokenKind_ampersand 25
#define zT_EAC3E484_TokenKind_pipe 26
#define zT_EAC3E484_TokenKind_caret 27
#define zT_EAC3E484_TokenKind_tilde 28
#define zT_EAC3E484_TokenKind_shl 29
#define zT_EAC3E484_TokenKind_shr 30
#define zT_EAC3E484_TokenKind_eq_eq 31
#define zT_EAC3E484_TokenKind_bang_eq 32
#define zT_EAC3E484_TokenKind_less 33
#define zT_EAC3E484_TokenKind_less_eq 34
#define zT_EAC3E484_TokenKind_greater 35
#define zT_EAC3E484_TokenKind_greater_eq 36
#define zT_EAC3E484_TokenKind_eq 37
#define zT_EAC3E484_TokenKind_plus_eq 38
#define zT_EAC3E484_TokenKind_minus_eq 39
#define zT_EAC3E484_TokenKind_star_eq 40
#define zT_EAC3E484_TokenKind_slash_eq 41
#define zT_EAC3E484_TokenKind_percent_eq 42
#define zT_EAC3E484_TokenKind_ampersand_eq 43
#define zT_EAC3E484_TokenKind_pipe_eq 44
#define zT_EAC3E484_TokenKind_caret_eq 45
#define zT_EAC3E484_TokenKind_shl_eq 46
#define zT_EAC3E484_TokenKind_shr_eq 47
#define zT_EAC3E484_TokenKind_plus_pct 48
#define zT_EAC3E484_TokenKind_minus_pct 49
#define zT_EAC3E484_TokenKind_star_pct 50
#define zT_EAC3E484_TokenKind_plus_pct_eq 51
#define zT_EAC3E484_TokenKind_minus_pct_eq 52
#define zT_EAC3E484_TokenKind_star_pct_eq 53
#define zT_EAC3E484_TokenKind_plus_pipe 54
#define zT_EAC3E484_TokenKind_minus_pipe 55
#define zT_EAC3E484_TokenKind_star_pipe 56
#define zT_EAC3E484_TokenKind_shl_pipe 57
#define zT_EAC3E484_TokenKind_plus_pipe_eq 58
#define zT_EAC3E484_TokenKind_minus_pipe_eq 59
#define zT_EAC3E484_TokenKind_star_pipe_eq 60
#define zT_EAC3E484_TokenKind_shl_pipe_eq 61
#define zT_EAC3E484_TokenKind_dot_dot 62
#define zT_EAC3E484_TokenKind_dot_dot_dot 63
#define zT_EAC3E484_TokenKind_dot_lbrace 64
#define zT_EAC3E484_TokenKind_dot_star 65
#define zT_EAC3E484_TokenKind_fat_arrow 66
#define zT_EAC3E484_TokenKind_kw_const 67
#define zT_EAC3E484_TokenKind_kw_var 68
#define zT_EAC3E484_TokenKind_kw_fn 69
#define zT_EAC3E484_TokenKind_kw_pub 70
#define zT_EAC3E484_TokenKind_kw_extern 71
#define zT_EAC3E484_TokenKind_kw_export 72
#define zT_EAC3E484_TokenKind_kw_test 73
#define zT_EAC3E484_TokenKind_kw_struct 74
#define zT_EAC3E484_TokenKind_kw_enum 75
#define zT_EAC3E484_TokenKind_kw_union 76
#define zT_EAC3E484_TokenKind_kw_packed 77
#define zT_EAC3E484_TokenKind_kw_if 78
#define zT_EAC3E484_TokenKind_kw_else 79
#define zT_EAC3E484_TokenKind_kw_while 80
#define zT_EAC3E484_TokenKind_kw_for 81
#define zT_EAC3E484_TokenKind_kw_switch 82
#define zT_EAC3E484_TokenKind_kw_return 83
#define zT_EAC3E484_TokenKind_kw_break 84
#define zT_EAC3E484_TokenKind_kw_continue 85
#define zT_EAC3E484_TokenKind_kw_defer 86
#define zT_EAC3E484_TokenKind_kw_errdefer 87
#define zT_EAC3E484_TokenKind_kw_try 88
#define zT_EAC3E484_TokenKind_kw_catch 89
#define zT_EAC3E484_TokenKind_kw_orelse 90
#define zT_EAC3E484_TokenKind_kw_error 91
#define zT_EAC3E484_TokenKind_kw_and 92
#define zT_EAC3E484_TokenKind_kw_or 93
#define zT_EAC3E484_TokenKind_kw_true 94
#define zT_EAC3E484_TokenKind_kw_false 95
#define zT_EAC3E484_TokenKind_kw_null 96
#define zT_EAC3E484_TokenKind_kw_undefined 97
#define zT_EAC3E484_TokenKind_kw_unreachable 98
#define zT_EAC3E484_TokenKind_kw_void 99
#define zT_EAC3E484_TokenKind_kw_bool 100
#define zT_EAC3E484_TokenKind_kw_noreturn 101
#define zT_EAC3E484_TokenKind_kw_c_char 102
#define zT_EAC3E484_TokenKind_kw_anytype 103
#define zT_EAC3E484_TokenKind_kw_volatile 104
#define zT_EAC3E484_TokenKind_c_include_builtin 105
#define zT_EAC3E484_TokenKind_eof 106
#define zT_EAC3E484_TokenKind_err_token 107

#endif /* ZIG_ENUM_zT_EAC3E484_TokenKind */
#ifndef ZIG_UNION_zT_85CBA4DB_TokenValue
#define ZIG_UNION_zT_85CBA4DB_TokenValue
union zT_85CBA4DB_TokenValue {
	zT_79FAE712_u64 int_val;
	double float_val;
	unsigned int string_id;
};
#endif /* ZIG_UNION_zT_85CBA4DB_TokenValue */
#ifndef ZIG_ENUM_zT_2B10107F_Prec
#define ZIG_ENUM_zT_2B10107F_Prec
typedef unsigned char zT_2B10107F_Prec;
#define zT_2B10107F_Prec_none 0
#define zT_2B10107F_Prec_assignment 1
#define zT_2B10107F_Prec_prec_orelse 2
#define zT_2B10107F_Prec_prec_catch 3
#define zT_2B10107F_Prec_bool_or 4
#define zT_2B10107F_Prec_bool_and 5
#define zT_2B10107F_Prec_comparison 6
#define zT_2B10107F_Prec_bit_or 7
#define zT_2B10107F_Prec_bit_xor 8
#define zT_2B10107F_Prec_bit_and 9
#define zT_2B10107F_Prec_shift 10
#define zT_2B10107F_Prec_additive 11
#define zT_2B10107F_Prec_multiply 12
#define zT_2B10107F_Prec_prefix 13
#define zT_2B10107F_Prec_postfix 14

#endif /* ZIG_ENUM_zT_2B10107F_Prec */
#ifndef ZIG_ENUM_zT_8143F551_AstKind
#define ZIG_ENUM_zT_8143F551_AstKind
typedef unsigned char zT_8143F551_AstKind;
#define zT_8143F551_AstKind_err 0
#define zT_8143F551_AstKind_var_decl 1
#define zT_8143F551_AstKind_fn_decl 2
#define zT_8143F551_AstKind_struct_decl 3
#define zT_8143F551_AstKind_enum_decl 4
#define zT_8143F551_AstKind_union_decl 5
#define zT_8143F551_AstKind_field_decl 6
#define zT_8143F551_AstKind_param_decl 7
#define zT_8143F551_AstKind_test_decl 8
#define zT_8143F551_AstKind_error_set_decl 9
#define zT_8143F551_AstKind_int_literal 10
#define zT_8143F551_AstKind_float_literal 11
#define zT_8143F551_AstKind_string_literal 12
#define zT_8143F551_AstKind_char_literal 13
#define zT_8143F551_AstKind_bool_literal 14
#define zT_8143F551_AstKind_null_literal 15
#define zT_8143F551_AstKind_undefined_literal 16
#define zT_8143F551_AstKind_unreachable_expr 17
#define zT_8143F551_AstKind_enum_literal 18
#define zT_8143F551_AstKind_error_literal 19
#define zT_8143F551_AstKind_tuple_literal 20
#define zT_8143F551_AstKind_struct_init 21
#define zT_8143F551_AstKind_array_init 22
#define zT_8143F551_AstKind_field_init 23
#define zT_8143F551_AstKind_ident_expr 24
#define zT_8143F551_AstKind_field_access 25
#define zT_8143F551_AstKind_index_access 26
#define zT_8143F551_AstKind_slice_expr 27
#define zT_8143F551_AstKind_deref 28
#define zT_8143F551_AstKind_address_of 29
#define zT_8143F551_AstKind_fn_call 30
#define zT_8143F551_AstKind_builtin_call 31
#define zT_8143F551_AstKind_paren_expr 32
#define zT_8143F551_AstKind_add 33
#define zT_8143F551_AstKind_sub 34
#define zT_8143F551_AstKind_mul 35
#define zT_8143F551_AstKind_div 36
#define zT_8143F551_AstKind_mod_op 37
#define zT_8143F551_AstKind_bit_and 38
#define zT_8143F551_AstKind_bit_or 39
#define zT_8143F551_AstKind_bit_xor 40
#define zT_8143F551_AstKind_shl 41
#define zT_8143F551_AstKind_shr 42
#define zT_8143F551_AstKind_bool_and 43
#define zT_8143F551_AstKind_bool_or 44
#define zT_8143F551_AstKind_cmp_eq 45
#define zT_8143F551_AstKind_cmp_ne 46
#define zT_8143F551_AstKind_cmp_lt 47
#define zT_8143F551_AstKind_cmp_le 48
#define zT_8143F551_AstKind_cmp_gt 49
#define zT_8143F551_AstKind_cmp_ge 50
#define zT_8143F551_AstKind_plain_assign 51
#define zT_8143F551_AstKind_add_assign 52
#define zT_8143F551_AstKind_sub_assign 53
#define zT_8143F551_AstKind_mul_assign 54
#define zT_8143F551_AstKind_div_assign 55
#define zT_8143F551_AstKind_mod_assign 74
#define zT_8143F551_AstKind_shl_assign 57
#define zT_8143F551_AstKind_shr_assign 58
#define zT_8143F551_AstKind_and_assign 59
#define zT_8143F551_AstKind_xor_assign 60
#define zT_8143F551_AstKind_or_assign 61
#define zT_8143F551_AstKind_negate 62
#define zT_8143F551_AstKind_bool_not 63
#define zT_8143F551_AstKind_bit_not 64
#define zT_8143F551_AstKind_try_expr 65
#define zT_8143F551_AstKind_catch_expr 66
#define zT_8143F551_AstKind_orelse_expr 67
#define zT_8143F551_AstKind_if_stmt 68
#define zT_8143F551_AstKind_if_expr 69
#define zT_8143F551_AstKind_if_capture 70
#define zT_8143F551_AstKind_while_stmt 71
#define zT_8143F551_AstKind_while_capture 72
#define zT_8143F551_AstKind_for_stmt 73
#define zT_8143F551_AstKind_swt_ex 56
#define zT_8143F551_AstKind_swt_prong 75
#define zT_8143F551_AstKind_block 76
#define zT_8143F551_AstKind_return_stmt 77
#define zT_8143F551_AstKind_break_stmt 78
#define zT_8143F551_AstKind_continue_stmt 79
#define zT_8143F551_AstKind_defer_stmt 80
#define zT_8143F551_AstKind_errdefer_stmt 81
#define zT_8143F551_AstKind_labeled_stmt 82
#define zT_8143F551_AstKind_expr_stmt 83
#define zT_8143F551_AstKind_ptr_type 84
#define zT_8143F551_AstKind_many_ptr_type 85
#define zT_8143F551_AstKind_array_type 86
#define zT_8143F551_AstKind_slice_type 87
#define zT_8143F551_AstKind_optional_type 88
#define zT_8143F551_AstKind_error_union_type 89
#define zT_8143F551_AstKind_fn_type 90
#define zT_8143F551_AstKind_import_expr 91
#define zT_8143F551_AstKind_module_root 92
#define zT_8143F551_AstKind_payload_capture 93
#define zT_8143F551_AstKind_range_exclusive 94
#define zT_8143F551_AstKind_range_inclusive 95
#define zT_8143F551_AstKind_c_include 96
#define zT_8143F551_AstKind_wrap_add 97
#define zT_8143F551_AstKind_wrap_sub 98
#define zT_8143F551_AstKind_wrap_mul 99
#define zT_8143F551_AstKind_wrap_negate 100
#define zT_8143F551_AstKind_wrap_add_assign 101
#define zT_8143F551_AstKind_wrap_sub_assign 102
#define zT_8143F551_AstKind_wrap_mul_assign 103
#define zT_8143F551_AstKind_sat_add 104
#define zT_8143F551_AstKind_sat_sub 105
#define zT_8143F551_AstKind_sat_mul 106
#define zT_8143F551_AstKind_sat_shl 107
#define zT_8143F551_AstKind_sat_add_assign 108
#define zT_8143F551_AstKind_sat_sub_assign 109
#define zT_8143F551_AstKind_sat_mul_assign 110
#define zT_8143F551_AstKind_sat_shl_assign 111

#endif /* ZIG_ENUM_zT_8143F551_AstKind */
#ifndef ZIG_STRUCT_zT_6DD0D007_AstSlot
#define ZIG_STRUCT_zT_6DD0D007_AstSlot
struct zT_6DD0D007_AstSlot {
	zT_22A7C88B_AstNode* node_buf;
	unsigned int node_cap;
	unsigned int* payload_buf;
	unsigned int payload_cap;
	unsigned char in_use;
};
#endif /* ZIG_STRUCT_zT_6DD0D007_AstSlot */
#ifndef ZIG_ENUM_zT_9FE1BFFE_ModuleState
#define ZIG_ENUM_zT_9FE1BFFE_ModuleState
typedef unsigned char zT_9FE1BFFE_ModuleState;
#define zT_9FE1BFFE_ModuleState_pending 0
#define zT_9FE1BFFE_ModuleState_parsing 1
#define zT_9FE1BFFE_ModuleState_parsed 2
#define zT_9FE1BFFE_ModuleState_resolved 3
#define zT_9FE1BFFE_ModuleState_failed 4

#endif /* ZIG_ENUM_zT_9FE1BFFE_ModuleState */
#ifndef ZIG_STRUCT_zT_E41AEC18_ModuleEntryArrayLis
#define ZIG_STRUCT_zT_E41AEC18_ModuleEntryArrayLis
struct zT_E41AEC18_ModuleEntryArrayLis {
	zT_6E8D187B_ModuleEntry* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_E41AEC18_ModuleEntryArrayLis */
#ifndef ZIG_STRUCT_zT_4EA49A91_SearchDirArrayList
#define ZIG_STRUCT_zT_4EA49A91_SearchDirArrayList
struct zT_4EA49A91_SearchDirArrayList {
	unsigned int* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_4EA49A91_SearchDirArrayList */
#ifndef ZIG_STRUCT_zT_ABD0FF08_HashMapSpillMeta
#define ZIG_STRUCT_zT_ABD0FF08_HashMapSpillMeta
struct zT_ABD0FF08_HashMapSpillMeta {
	unsigned int disk_off;
	unsigned int capacity;
	unsigned int count;
	unsigned char spilled;
};
#endif /* ZIG_STRUCT_zT_ABD0FF08_HashMapSpillMeta */
#ifndef ZIG_STRUCT_zT_47A5CDFB_ImportQueue
#define ZIG_STRUCT_zT_47A5CDFB_ImportQueue
struct zT_47A5CDFB_ImportQueue {
	unsigned int* pending_items;
	unsigned int pending_len;
	unsigned int pending_cap;
	zT_3E40CD83_Sand* pending_alloc;
	zT_F85C5DED_DiagnosticCollector* diag;
};
#endif /* ZIG_STRUCT_zT_47A5CDFB_ImportQueue */
#ifndef ZIG_STRUCT_zT_438E6589_NullGuard
#define ZIG_STRUCT_zT_438E6589_NullGuard
struct zT_438E6589_NullGuard {
	unsigned int name_id;
	unsigned char is_not_null;
};
#endif /* ZIG_STRUCT_zT_438E6589_NullGuard */
#ifndef ZIG_ENUM_zT_3C598AEF_SymbolKind
#define ZIG_ENUM_zT_3C598AEF_SymbolKind
typedef unsigned char zT_3C598AEF_SymbolKind;
#define zT_3C598AEF_SymbolKind_local 0
#define zT_3C598AEF_SymbolKind_param 1
#define zT_3C598AEF_SymbolKind_global 2
#define zT_3C598AEF_SymbolKind_function 3
#define zT_3C598AEF_SymbolKind_type_alias 4
#define zT_3C598AEF_SymbolKind_module 5
#define zT_3C598AEF_SymbolKind_test_sym 6

#endif /* ZIG_ENUM_zT_3C598AEF_SymbolKind */
#ifndef ZIG_ENUM_zT_33EF6BFB_TypeKind
#define ZIG_ENUM_zT_33EF6BFB_TypeKind
typedef unsigned char zT_33EF6BFB_TypeKind;
#define zT_33EF6BFB_TypeKind_none_sentinel 0
#define zT_33EF6BFB_TypeKind_void_type 1
#define zT_33EF6BFB_TypeKind_bool_type 2
#define zT_33EF6BFB_TypeKind_noreturn_type 3
#define zT_33EF6BFB_TypeKind_i8_type 4
#define zT_33EF6BFB_TypeKind_i16_type 5
#define zT_33EF6BFB_TypeKind_i32_type 6
#define zT_33EF6BFB_TypeKind_i64_type 7
#define zT_33EF6BFB_TypeKind_u8_type 8
#define zT_33EF6BFB_TypeKind_u16_type 9
#define zT_33EF6BFB_TypeKind_u32_type 10
#define zT_33EF6BFB_TypeKind_u64_type 11
#define zT_33EF6BFB_TypeKind_isize_type 12
#define zT_33EF6BFB_TypeKind_usize_type 13
#define zT_33EF6BFB_TypeKind_c_char_type 14
#define zT_33EF6BFB_TypeKind_f32_type 15
#define zT_33EF6BFB_TypeKind_f64_type 16
#define zT_33EF6BFB_TypeKind_ptr_type 17
#define zT_33EF6BFB_TypeKind_many_ptr_type 18
#define zT_33EF6BFB_TypeKind_array_type 19
#define zT_33EF6BFB_TypeKind_slice_type 20
#define zT_33EF6BFB_TypeKind_optional_type 21
#define zT_33EF6BFB_TypeKind_error_union_type 22
#define zT_33EF6BFB_TypeKind_error_set_type 23
#define zT_33EF6BFB_TypeKind_fn_type 24
#define zT_33EF6BFB_TypeKind_struct_type 25
#define zT_33EF6BFB_TypeKind_enum_type 26
#define zT_33EF6BFB_TypeKind_union_type 27
#define zT_33EF6BFB_TypeKind_tagged_union_type 28
#define zT_33EF6BFB_TypeKind_tuple_type 29
#define zT_33EF6BFB_TypeKind_unresolved_name 30
#define zT_33EF6BFB_TypeKind_type_type 31
#define zT_33EF6BFB_TypeKind_module_type 32
#define zT_33EF6BFB_TypeKind_null_type 33
#define zT_33EF6BFB_TypeKind_undefined_type 34
#define zT_33EF6BFB_TypeKind_integer_literal_type 35
#define zT_33EF6BFB_TypeKind_anon_struct_init 36
#define zT_33EF6BFB_TypeKind_anon_array 37
#define zT_33EF6BFB_TypeKind_anon_tuple 38
#define zT_33EF6BFB_TypeKind_anon_union 39
#define zT_33EF6BFB_TypeKind_va_list_type 40
#define zT_33EF6BFB_TypeKind_arb_uint_type 41
#define zT_33EF6BFB_TypeKind_arb_int_type 42
#define zT_33EF6BFB_TypeKind_packed_union_type 43

#endif /* ZIG_ENUM_zT_33EF6BFB_TypeKind */
#ifndef ZIG_STRUCT_zT_A528929E_DeferActionArrayLis
#define ZIG_STRUCT_zT_A528929E_DeferActionArrayLis
struct zT_A528929E_DeferActionArrayLis {
	zT_CE6A1A99_DeferAction* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_A528929E_DeferActionArrayLis */
#ifndef ZIG_STRUCT_zT_5819C854_LoopInfoArrayList
#define ZIG_STRUCT_zT_5819C854_LoopInfoArrayList
struct zT_5819C854_LoopInfoArrayList {
	zT_78074DEF_LoopInfo* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_5819C854_LoopInfoArrayList */
#ifndef ZIG_STRUCT_zT_347CB10E_SwitchInfoArrayList
#define ZIG_STRUCT_zT_347CB10E_SwitchInfoArrayList
struct zT_347CB10E_SwitchInfoArrayList {
	zT_6996DA09_SwitchInfo* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_347CB10E_SwitchInfoArrayList */
#ifndef ZIG_STRUCT_zT_2F2F63D8_ScopeNodeArrayList
#define ZIG_STRUCT_zT_2F2F63D8_ScopeNodeArrayList
struct zT_2F2F63D8_ScopeNodeArrayList {
	zT_FEED5D3B_ScopeNode* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_2F2F63D8_ScopeNodeArrayList */
#ifndef ZIG_STRUCT_zT_573A3319_LocalBinding
#define ZIG_STRUCT_zT_573A3319_LocalBinding
struct zT_573A3319_LocalBinding {
	unsigned int temp;
	unsigned char kind;
	unsigned int tid;
};
#endif /* ZIG_STRUCT_zT_573A3319_LocalBinding */
#ifndef ZIG_STRUCT_zT_DCBFE211_CallInfo
#define ZIG_STRUCT_zT_DCBFE211_CallInfo
struct zT_DCBFE211_CallInfo {
	unsigned char is_self;
	unsigned char is_indirect;
	unsigned char is_extern;
	unsigned char call_conv;
	unsigned int callee;
	unsigned int module_id;
	unsigned int args_start;
	unsigned int args_count;
	unsigned int result;
	unsigned int return_type;
	unsigned int call_block_idx;
	unsigned int call_inst_idx;
};
#endif /* ZIG_STRUCT_zT_DCBFE211_CallInfo */
#ifndef ZIG_STRUCT_zT_3BFB1E70_CallDirectData
#define ZIG_STRUCT_zT_3BFB1E70_CallDirectData
struct zT_3BFB1E70_CallDirectData {
	unsigned int name_id;
	unsigned int module_id;
	unsigned int args_start;
	unsigned int args_count;
	unsigned int result;
	unsigned int return_type;
	unsigned char is_extern;
	unsigned char call_conv;
};
#endif /* ZIG_STRUCT_zT_3BFB1E70_CallDirectData */
#ifndef ZIG_STRUCT_zT_0624AC1B_TailCallData
#define ZIG_STRUCT_zT_0624AC1B_TailCallData
struct zT_0624AC1B_TailCallData {
	unsigned int callee;
	unsigned int module_id;
	unsigned int args_start;
	unsigned int args_count;
	unsigned int result;
	unsigned int return_type;
	unsigned char is_indirect;
	unsigned char is_extern;
	unsigned char call_conv;
};
#endif /* ZIG_STRUCT_zT_0624AC1B_TailCallData */
#ifndef ZIG_STRUCT_zT_AC00B5F6_LirSideEntryArrayLi
#define ZIG_STRUCT_zT_AC00B5F6_LirSideEntryArrayLi
struct zT_AC00B5F6_LirSideEntryArrayLi {
	zT_A8A5B231_LirSideEntry* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_AC00B5F6_LirSideEntryArrayLi */
#ifndef ZIG_STRUCT_zT_DAE4631D_LirInstArrayList
#define ZIG_STRUCT_zT_DAE4631D_LirInstArrayList
struct zT_DAE4631D_LirInstArrayList {
	zT_6BA597BC_LirInst* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_DAE4631D_LirInstArrayList */
#ifndef ZIG_STRUCT_zT_1CF28CA3_BasicBlockArrayList
#define ZIG_STRUCT_zT_1CF28CA3_BasicBlockArrayList
struct zT_1CF28CA3_BasicBlockArrayList {
	zT_88A68B1A_BasicBlock* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_1CF28CA3_BasicBlockArrayList */
#ifndef ZIG_STRUCT_zT_CFE23D0A_LirParamArrayList
#define ZIG_STRUCT_zT_CFE23D0A_LirParamArrayList
struct zT_CFE23D0A_LirParamArrayList {
	zT_8779209D_LirParam* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_CFE23D0A_LirParamArrayList */
#ifndef ZIG_STRUCT_zT_5D72FBF8_TempDeclArrayList
#define ZIG_STRUCT_zT_5D72FBF8_TempDeclArrayList
struct zT_5D72FBF8_TempDeclArrayList {
	zT_1937645B_TempDecl* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_5D72FBF8_TempDeclArrayList */
#ifndef ZIG_STRUCT_zT_9F514E82_SwitchCaseArrayList
#define ZIG_STRUCT_zT_9F514E82_SwitchCaseArrayList
struct zT_9F514E82_SwitchCaseArrayList {
	zT_4BD97095_SwitchCase* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_9F514E82_SwitchCaseArrayList */
#ifndef ZIG_STRUCT_zT_CA01C129_LirSlotArrayList
#define ZIG_STRUCT_zT_CA01C129_LirSlotArrayList
struct zT_CA01C129_LirSlotArrayList {
	zT_E7714190_LirSlot* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_CA01C129_LirSlotArrayList */
#ifndef ZIG_STRUCT_zT_E1A783EF_GlobalDeclArrayList
#define ZIG_STRUCT_zT_E1A783EF_GlobalDeclArrayList
struct zT_E1A783EF_GlobalDeclArrayList {
	zT_54906056_ModuleGlobalDecl* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_E1A783EF_GlobalDeclArrayList */
#ifndef ZIG_STRUCT_zT_21D3708C_U32ToU32Map
#define ZIG_STRUCT_zT_21D3708C_U32ToU32Map
struct zT_21D3708C_U32ToU32Map {
	unsigned int* keys;
	unsigned int* values;
	unsigned char* occupied;
	unsigned int capacity;
	unsigned int count;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_21D3708C_U32ToU32Map */
#ifndef ZIG_STRUCT_zT_A4CE86B7_U64ToU32Map
#define ZIG_STRUCT_zT_A4CE86B7_U64ToU32Map
struct zT_A4CE86B7_U64ToU32Map {
	zT_79FAE712_u64* keys;
	unsigned int* values;
	unsigned char* occupied;
	unsigned int capacity;
	unsigned int count;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_A4CE86B7_U64ToU32Map */
#ifndef ZIG_STRUCT_zT_89877D19_U32ToU64Map
#define ZIG_STRUCT_zT_89877D19_U32ToU64Map
struct zT_89877D19_U32ToU64Map {
	unsigned int* keys;
	zT_79FAE712_u64* values;
	unsigned char* occupied;
	unsigned int capacity;
	unsigned int count;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_89877D19_U32ToU64Map */
#ifndef ZIG_STRUCT_zT_B687BB96_U32ArrayList
#define ZIG_STRUCT_zT_B687BB96_U32ArrayList
struct zT_B687BB96_U32ArrayList {
	unsigned int* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_B687BB96_U32ArrayList */
#ifndef ZIG_ENUM_zT_0FB7FB13_CoercionKind
#define ZIG_ENUM_zT_0FB7FB13_CoercionKind
typedef unsigned char zT_0FB7FB13_CoercionKind;
#define zT_0FB7FB13_CoercionKind_none 0
#define zT_0FB7FB13_CoercionKind_wrap_optional 1
#define zT_0FB7FB13_CoercionKind_wrap_error_success 2
#define zT_0FB7FB13_CoercionKind_wrap_error_err 3
#define zT_0FB7FB13_CoercionKind_unwrap_optional 4
#define zT_0FB7FB13_CoercionKind_array_to_slice 5
#define zT_0FB7FB13_CoercionKind_array_to_many_ptr 6
#define zT_0FB7FB13_CoercionKind_slice_to_many_ptr 7
#define zT_0FB7FB13_CoercionKind_string_to_slice 8
#define zT_0FB7FB13_CoercionKind_string_to_many_ptr 9
#define zT_0FB7FB13_CoercionKind_string_to_ptr 10
#define zT_0FB7FB13_CoercionKind_ptr_to_optional_ptr 11
#define zT_0FB7FB13_CoercionKind_const_qualify 12
#define zT_0FB7FB13_CoercionKind_int_widen 13
#define zT_0FB7FB13_CoercionKind_float_widen 14
#define zT_0FB7FB13_CoercionKind_int_literal_coerce 15
#define zT_0FB7FB13_CoercionKind_wrap_optional_null 16

#endif /* ZIG_ENUM_zT_0FB7FB13_CoercionKind */
#ifndef ZIG_STRUCT_zT_E2DF2801_LocalConstScope
#define ZIG_STRUCT_zT_E2DF2801_LocalConstScope
struct zT_E2DF2801_LocalConstScope {
	unsigned int* names;
	unsigned int* nodes;
	unsigned int count;
	unsigned int cap;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_E2DF2801_LocalConstScope */
#ifndef ZIG_STRUCT_zT_89B1DDDA_ComptimeVal
#define ZIG_STRUCT_zT_89B1DDDA_ComptimeVal
struct zT_89B1DDDA_ComptimeVal {
	zT_79FAE712_u64 bits;
	unsigned int width_bits;
	int sig;
};
#endif /* ZIG_STRUCT_zT_89B1DDDA_ComptimeVal */
#ifndef ZIG_STRUCT_zT_2CF63CE1_AsyncFrameFieldArra
#define ZIG_STRUCT_zT_2CF63CE1_AsyncFrameFieldArra
struct zT_2CF63CE1_AsyncFrameFieldArra {
	zT_902E38E8_AsyncFrameField* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_2CF63CE1_AsyncFrameFieldArra */
#ifndef ZIG_ENUM_zT_0426DCE7_SpillBackend
#define ZIG_ENUM_zT_0426DCE7_SpillBackend
typedef unsigned char zT_0426DCE7_SpillBackend;
#define zT_0426DCE7_SpillBackend_disk 0
#define zT_0426DCE7_SpillBackend_ram 1

#endif /* ZIG_ENUM_zT_0426DCE7_SpillBackend */
#ifndef ZIG_SLICE_zT_8F083A69_Slice_zT_0B42B2F8_u
#define ZIG_SLICE_zT_8F083A69_Slice_zT_0B42B2F8_u
typedef struct { unsigned char* ptr; unsigned int len; } zT_8F083A69_Slice_zT_0B42B2F8_u;
#endif /* ZIG_SLICE_zT_8F083A69_Slice_zT_0B42B2F8_u */
#ifndef ZIG_OPTIONAL_zT_7032B1AE_Opt_236
#define ZIG_OPTIONAL_zT_7032B1AE_Opt_236
typedef struct { zT_7D82FE60_GrowableSand* value; int has_value; } zT_7032B1AE_Opt_236;
#endif /* ZIG_OPTIONAL_zT_7032B1AE_Opt_236 */
#ifndef ZIG_OPTIONAL_zT_6A32A83C_Opt_238
#define ZIG_OPTIONAL_zT_6A32A83C_Opt_238
typedef struct { zT_C59F83AC_SandSegment* value; int has_value; } zT_6A32A83C_Opt_238;
#endif /* ZIG_OPTIONAL_zT_6A32A83C_Opt_238 */
#ifndef ZIG_ARRAY_zT_959EEC26_Arr_unsigned_int_3
#define ZIG_ARRAY_zT_959EEC26_Arr_unsigned_int_3
typedef unsigned int zT_959EEC26_Arr_unsigned_int_3[3];
#endif /* ZIG_ARRAY_zT_959EEC26_Arr_unsigned_int_3 */
#ifndef ZIG_OPTIONAL_zT_7034F045_Opt_228
#define ZIG_OPTIONAL_zT_7034F045_Opt_228
typedef struct { zT_072B53A6_ModuleRegistry* value; int has_value; } zT_7034F045_Opt_228;
#endif /* ZIG_OPTIONAL_zT_7034F045_Opt_228 */
#ifndef ZIG_OPTIONAL_zT_6C306CCB_Opt_240
#define ZIG_OPTIONAL_zT_6C306CCB_Opt_240
typedef struct { zT_3E40CD83_Sand* value; int has_value; } zT_6C306CCB_Opt_240;
#endif /* ZIG_OPTIONAL_zT_6C306CCB_Opt_240 */
#ifndef ZIG_ARRAY_zT_9C9EF72B_Arr_unsigned_int_8
#define ZIG_ARRAY_zT_9C9EF72B_Arr_unsigned_int_8
typedef unsigned int zT_9C9EF72B_Arr_unsigned_int_8[8];
#endif /* ZIG_ARRAY_zT_9C9EF72B_Arr_unsigned_int_8 */
#ifndef ZIG_ARRAY_zT_846744CC_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_846744CC_Arr_unsigned_char_5
typedef unsigned char zT_846744CC_Arr_unsigned_char_5[512];
#endif /* ZIG_ARRAY_zT_846744CC_Arr_unsigned_char_5 */
#ifndef ZIG_STRUCT_zT_8DDC796C_anon_225780
#define ZIG_STRUCT_zT_8DDC796C_anon_225780
struct zT_8DDC796C_anon_225780 {
	unsigned int len;
};
#endif /* ZIG_STRUCT_zT_8DDC796C_anon_225780 */
#ifndef ZIG_STRUCT_zT_8EDEB996_anon_225795
#define ZIG_STRUCT_zT_8EDEB996_anon_225795
struct zT_8EDEB996_anon_225795 {
	double* items;
	unsigned int len;
	unsigned int capacity;
};
#endif /* ZIG_STRUCT_zT_8EDEB996_anon_225795 */
#ifndef ZIG_STRUCT_zT_4B5CDF4D_anon_225804
#define ZIG_STRUCT_zT_4B5CDF4D_anon_225804
struct zT_4B5CDF4D_anon_225804 {
	unsigned int* items;
	unsigned int len;
	unsigned int capacity;
};
#endif /* ZIG_STRUCT_zT_4B5CDF4D_anon_225804 */
#ifndef ZIG_STRUCT_zT_445A95B1_anon_225813
#define ZIG_STRUCT_zT_445A95B1_anon_225813
struct zT_445A95B1_anon_225813 {
	zT_243D6A41_FnProto* items;
	unsigned int len;
	unsigned int capacity;
};
#endif /* ZIG_STRUCT_zT_445A95B1_anon_225813 */
#ifndef ZIG_STRUCT_zT_485A9BFD_anon_225817
#define ZIG_STRUCT_zT_485A9BFD_anon_225817
struct zT_485A9BFD_anon_225817 {
	unsigned int len;
};
#endif /* ZIG_STRUCT_zT_485A9BFD_anon_225817 */
#ifndef ZIG_STRUCT_zT_4E5F229D_anon_225831
#define ZIG_STRUCT_zT_4E5F229D_anon_225831
struct zT_4E5F229D_anon_225831 {
	zT_E2FE8472_NodeBlockInfo* items;
	unsigned int len;
	unsigned int capacity;
};
#endif /* ZIG_STRUCT_zT_4E5F229D_anon_225831 */
#ifndef ZIG_FNPTR_zT_68F0EBCB_FP_void_zT_7E2F335A
#define ZIG_FNPTR_zT_68F0EBCB_FP_void_zT_7E2F335A
typedef void (*zT_68F0EBCB_FP_void_zT_7E2F335A)(zT_7E2F335A_AnalyzerContext*, zT_2C0927B0_StateMap*, unsigned int);
#endif /* ZIG_FNPTR_zT_68F0EBCB_FP_void_zT_7E2F335A */
#ifndef ZIG_ARRAY_zT_47D166B7_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_47D166B7_Arr_unsigned_char_4
typedef unsigned char zT_47D166B7_Arr_unsigned_char_4[4096];
#endif /* ZIG_ARRAY_zT_47D166B7_Arr_unsigned_char_4 */
#ifndef ZIG_OPTIONAL_zT_F04B8014_Opt_296
#define ZIG_OPTIONAL_zT_F04B8014_Opt_296
typedef struct { zT_A4CE86B7_U64ToU32Map* value; int has_value; } zT_F04B8014_Opt_296;
#endif /* ZIG_OPTIONAL_zT_F04B8014_Opt_296 */
#ifndef ZIG_STRUCT_zT_3B0148B6_anon_74360
#define ZIG_STRUCT_zT_3B0148B6_anon_74360
struct zT_3B0148B6_anon_74360 {
	unsigned int temp;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_3B0148B6_anon_74360 */
#ifndef ZIG_STRUCT_zT_4301554E_anon_74368
#define ZIG_STRUCT_zT_4301554E_anon_74368
struct zT_4301554E_anon_74368 {
	unsigned int name_id;
	unsigned int type_id;
	unsigned int temp;
};
#endif /* ZIG_STRUCT_zT_4301554E_anon_74368 */
#ifndef ZIG_STRUCT_zT_3F038D99_anon_74376
#define ZIG_STRUCT_zT_3F038D99_anon_74376
struct zT_3F038D99_anon_74376 {
	unsigned int dst;
	unsigned int src;
	unsigned int name_id;
};
#endif /* ZIG_STRUCT_zT_3F038D99_anon_74376 */
#ifndef ZIG_STRUCT_zT_4D05E23A_anon_74386
#define ZIG_STRUCT_zT_4D05E23A_anon_74386
struct zT_4D05E23A_anon_74386 {
	unsigned int base;
	unsigned int field_id;
	unsigned int src;
	unsigned int name_id;
};
#endif /* ZIG_STRUCT_zT_4D05E23A_anon_74386 */
#ifndef ZIG_STRUCT_zT_4F0823F7_anon_74396
#define ZIG_STRUCT_zT_4F0823F7_anon_74396
struct zT_4F0823F7_anon_74396 {
	unsigned int base;
	unsigned int index;
	unsigned int src;
	unsigned int name_id;
};
#endif /* ZIG_STRUCT_zT_4F0823F7_anon_74396 */
#ifndef ZIG_STRUCT_zT_C940E31B_anon_74406
#define ZIG_STRUCT_zT_C940E31B_anon_74406
struct zT_C940E31B_anon_74406 {
	unsigned int cond;
	unsigned int then_bb;
	unsigned int else_bb;
};
#endif /* ZIG_STRUCT_zT_C940E31B_anon_74406 */
#ifndef ZIG_STRUCT_zT_C73EA15E_anon_74416
#define ZIG_STRUCT_zT_C73EA15E_anon_74416
struct zT_C73EA15E_anon_74416 {
	unsigned int cond;
	unsigned int cases_start;
	unsigned int cases_count;
	unsigned int else_bb;
};
#endif /* ZIG_STRUCT_zT_C73EA15E_anon_74416 */
#ifndef ZIG_STRUCT_zT_3943D202_anon_74434
#define ZIG_STRUCT_zT_3943D202_anon_74434
struct zT_3943D202_anon_74434 {
	unsigned char op;
	unsigned int lhs;
	unsigned int rhs;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_3943D202_anon_74434 */
#ifndef ZIG_STRUCT_zT_3536FFC3_anon_74442
#define ZIG_STRUCT_zT_3536FFC3_anon_74442
struct zT_3536FFC3_anon_74442 {
	unsigned char op;
	unsigned int operand;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_3536FFC3_anon_74442 */
#ifndef ZIG_STRUCT_zT_3334BE06_anon_74452
#define ZIG_STRUCT_zT_3334BE06_anon_74452
struct zT_3334BE06_anon_74452 {
	unsigned int callee;
	unsigned int args_start;
	unsigned int args_count;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_3334BE06_anon_74452 */
#ifndef ZIG_STRUCT_zT_C53C5FA1_anon_74462
#define ZIG_STRUCT_zT_C53C5FA1_anon_74462
struct zT_C53C5FA1_anon_74462 {
	unsigned int base;
	unsigned int field_id;
	unsigned int result;
	unsigned int name_id;
};
#endif /* ZIG_STRUCT_zT_C53C5FA1_anon_74462 */
#ifndef ZIG_STRUCT_zT_3B3947CC_anon_74472
#define ZIG_STRUCT_zT_3B3947CC_anon_74472
struct zT_3B3947CC_anon_74472 {
	unsigned int base;
	unsigned int field_id;
	unsigned int value;
	unsigned int name_id;
};
#endif /* ZIG_STRUCT_zT_3B3947CC_anon_74472 */
#ifndef ZIG_STRUCT_zT_3B551E49_anon_74484
#define ZIG_STRUCT_zT_3B551E49_anon_74484
struct zT_3B551E49_anon_74484 {
	unsigned int base;
	unsigned int index;
	unsigned int result;
	unsigned int name_id;
	unsigned char decay;
};
#endif /* ZIG_STRUCT_zT_3B551E49_anon_74484 */
#ifndef ZIG_STRUCT_zT_B952130C_anon_74490
#define ZIG_STRUCT_zT_B952130C_anon_74490
struct zT_B952130C_anon_74490 {
	unsigned int ptr;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_B952130C_anon_74490 */
#ifndef ZIG_STRUCT_zT_B7520FE6_anon_74496
#define ZIG_STRUCT_zT_B7520FE6_anon_74496
struct zT_B7520FE6_anon_74496 {
	unsigned int ptr;
	unsigned int value;
};
#endif /* ZIG_STRUCT_zT_B7520FE6_anon_74496 */
#ifndef ZIG_STRUCT_zT_4D6C4EBC_anon_74502
#define ZIG_STRUCT_zT_4D6C4EBC_anon_74502
struct zT_4D6C4EBC_anon_74502 {
	unsigned int operand;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_4D6C4EBC_anon_74502 */
#ifndef ZIG_STRUCT_zT_556E99EB_anon_74510
#define ZIG_STRUCT_zT_556E99EB_anon_74510
struct zT_556E99EB_anon_74510 {
	unsigned int base;
	unsigned int field_id;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_556E99EB_anon_74510 */
#ifndef ZIG_STRUCT_zT_4D6E8D53_anon_74518
#define ZIG_STRUCT_zT_4D6E8D53_anon_74518
struct zT_4D6E8D53_anon_74518 {
	unsigned int value;
	unsigned int result;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_4D6E8D53_anon_74518 */
#ifndef ZIG_STRUCT_zT_4967CB42_anon_74526
#define ZIG_STRUCT_zT_4967CB42_anon_74526
struct zT_4967CB42_anon_74526 {
	unsigned int va_list_temp;
	unsigned int last_param_temp;
};
#endif /* ZIG_STRUCT_zT_4967CB42_anon_74526 */
#ifndef ZIG_STRUCT_zT_4D6A1025_anon_74534
#define ZIG_STRUCT_zT_4D6A1025_anon_74534
struct zT_4D6A1025_anon_74534 {
	unsigned int va_list_temp;
	unsigned int type_id;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_4D6A1025_anon_74534 */
#ifndef ZIG_STRUCT_zT_516A1671_anon_74538
#define ZIG_STRUCT_zT_516A1671_anon_74538
struct zT_516A1671_anon_74538 {
	unsigned int va_list_temp;
};
#endif /* ZIG_STRUCT_zT_516A1671_anon_74538 */
#ifndef ZIG_STRUCT_zT_CF7615BE_anon_74548
#define ZIG_STRUCT_zT_CF7615BE_anon_74548
struct zT_CF7615BE_anon_74548 {
	unsigned int name_id;
	unsigned int module_id;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_CF7615BE_anon_74548 */
#ifndef ZIG_STRUCT_zT_49791463_anon_74554
#define ZIG_STRUCT_zT_49791463_anon_74554
struct zT_49791463_anon_74554 {
	unsigned int value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_49791463_anon_74554 */
#ifndef ZIG_STRUCT_zT_DB71AB74_anon_74560
#define ZIG_STRUCT_zT_DB71AB74_anon_74560
struct zT_DB71AB74_anon_74560 {
	unsigned int value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_DB71AB74_anon_74560 */
#ifndef ZIG_STRUCT_zT_D971A84E_anon_74566
#define ZIG_STRUCT_zT_D971A84E_anon_74566
struct zT_D971A84E_anon_74566 {
	unsigned int value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_D971A84E_anon_74566 */
#ifndef ZIG_STRUCT_zT_DD73ED31_anon_74574
#define ZIG_STRUCT_zT_DD73ED31_anon_74574
struct zT_DD73ED31_anon_74574 {
	unsigned int value;
	unsigned int result;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_DD73ED31_anon_74574 */
#ifndef ZIG_STRUCT_zT_5D7FEFA4_anon_74582
#define ZIG_STRUCT_zT_5D7FEFA4_anon_74582
struct zT_5D7FEFA4_anon_74582 {
	unsigned int value;
	unsigned int result;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_5D7FEFA4_anon_74582 */
#ifndef ZIG_STRUCT_zT_577FE632_anon_74588
#define ZIG_STRUCT_zT_577FE632_anon_74588
struct zT_577FE632_anon_74588 {
	unsigned int value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_577FE632_anon_74588 */
#ifndef ZIG_STRUCT_zT_C982D83F_anon_74594
#define ZIG_STRUCT_zT_C982D83F_anon_74594
struct zT_C982D83F_anon_74594 {
	unsigned int value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_C982D83F_anon_74594 */
#ifndef ZIG_STRUCT_zT_71240677_anon_74600
#define ZIG_STRUCT_zT_71240677_anon_74600
struct zT_71240677_anon_74600 {
	unsigned int value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_71240677_anon_74600 */
#ifndef ZIG_STRUCT_zT_6B21BE6E_anon_74610
#define ZIG_STRUCT_zT_6B21BE6E_anon_74610
struct zT_6B21BE6E_anon_74610 {
	unsigned int ptr;
	unsigned int len;
	unsigned int result;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_6B21BE6E_anon_74610 */
#ifndef ZIG_STRUCT_zT_6321B1D6_anon_74618
#define ZIG_STRUCT_zT_6321B1D6_anon_74618
struct zT_6321B1D6_anon_74618 {
	unsigned int value;
	unsigned int target;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_6321B1D6_anon_74618 */
#ifndef ZIG_STRUCT_zT_5F1F6CF3_anon_74626
#define ZIG_STRUCT_zT_5F1F6CF3_anon_74626
struct zT_5F1F6CF3_anon_74626 {
	unsigned int value;
	unsigned int target;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_5F1F6CF3_anon_74626 */
#ifndef ZIG_STRUCT_zT_5B1D2810_anon_74634
#define ZIG_STRUCT_zT_5B1D2810_anon_74634
struct zT_5B1D2810_anon_74634 {
	unsigned int value;
	unsigned int target;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_5B1D2810_anon_74634 */
#ifndef ZIG_STRUCT_zT_DB1A1FF9_anon_74642
#define ZIG_STRUCT_zT_DB1A1FF9_anon_74642
struct zT_DB1A1FF9_anon_74642 {
	unsigned int value;
	unsigned int target;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_DB1A1FF9_anon_74642 */
#ifndef ZIG_STRUCT_zT_E11A296B_anon_74648
#define ZIG_STRUCT_zT_E11A296B_anon_74648
struct zT_E11A296B_anon_74648 {
	unsigned int value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_E11A296B_anon_74648 */
#ifndef ZIG_STRUCT_zT_ED17FDB8_anon_74656
#define ZIG_STRUCT_zT_ED17FDB8_anon_74656
struct zT_ED17FDB8_anon_74656 {
	unsigned int value;
	unsigned int target;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_ED17FDB8_anon_74656 */
#ifndef ZIG_STRUCT_zT_EB15BBFB_anon_74662
#define ZIG_STRUCT_zT_EB15BBFB_anon_74662
struct zT_EB15BBFB_anon_74662 {
	zT_79FAE712_u64 value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_EB15BBFB_anon_74662 */
#ifndef ZIG_STRUCT_zT_E515B289_anon_74668
#define ZIG_STRUCT_zT_E515B289_anon_74668
struct zT_E515B289_anon_74668 {
	double value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_E515B289_anon_74668 */
#ifndef ZIG_STRUCT_zT_6B12B3E4_anon_74674
#define ZIG_STRUCT_zT_6B12B3E4_anon_74674
struct zT_6B12B3E4_anon_74674 {
	unsigned int string_id;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_6B12B3E4_anon_74674 */
#ifndef ZIG_STRUCT_zT_5F12A100_anon_74678
#define ZIG_STRUCT_zT_5F12A100_anon_74678
struct zT_5F12A100_anon_74678 {
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_5F12A100_anon_74678 */
#ifndef ZIG_STRUCT_zT_5D105F43_anon_74684
#define ZIG_STRUCT_zT_5D105F43_anon_74684
struct zT_5D105F43_anon_74684 {
	unsigned int result;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_5D105F43_anon_74684 */
#ifndef ZIG_STRUCT_zT_5B0E1D86_anon_74690
#define ZIG_STRUCT_zT_5B0E1D86_anon_74690
struct zT_5B0E1D86_anon_74690 {
	unsigned char value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_5B0E1D86_anon_74690 */
#ifndef ZIG_STRUCT_zT_5D0E20AC_anon_74696
#define ZIG_STRUCT_zT_5D0E20AC_anon_74696
struct zT_5D0E20AC_anon_74696 {
	unsigned int result;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_5D0E20AC_anon_74696 */
#ifndef ZIG_STRUCT_zT_F08C9D26_anon_74706
#define ZIG_STRUCT_zT_F08C9D26_anon_74706
struct zT_F08C9D26_anon_74706 {
	zT_79FAE712_u64 value;
	unsigned int result;
	unsigned int type_id;
	unsigned int member_name_id;
};
#endif /* ZIG_STRUCT_zT_F08C9D26_anon_74706 */
#ifndef ZIG_STRUCT_zT_768FAEAF_anon_74712
#define ZIG_STRUCT_zT_768FAEAF_anon_74712
struct zT_768FAEAF_anon_74712 {
	unsigned int name_id;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_768FAEAF_anon_74712 */
#ifndef ZIG_STRUCT_zT_808FBE6D_anon_74718
#define ZIG_STRUCT_zT_808FBE6D_anon_74718
struct zT_808FBE6D_anon_74718 {
	unsigned int name_id;
	unsigned int value;
};
#endif /* ZIG_STRUCT_zT_808FBE6D_anon_74718 */
#ifndef ZIG_STRUCT_zT_8091FD04_anon_74726
#define ZIG_STRUCT_zT_8091FD04_anon_74726
struct zT_8091FD04_anon_74726 {
	unsigned int name_id;
	unsigned int module_id;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_8091FD04_anon_74726 */
#ifndef ZIG_STRUCT_zT_80943B9B_anon_74734
#define ZIG_STRUCT_zT_80943B9B_anon_74734
struct zT_80943B9B_anon_74734 {
	unsigned int name_id;
	unsigned int module_id;
	unsigned int value;
};
#endif /* ZIG_STRUCT_zT_80943B9B_anon_74734 */
#ifndef ZIG_STRUCT_zT_7C94354F_anon_74738
#define ZIG_STRUCT_zT_7C94354F_anon_74738
struct zT_7C94354F_anon_74738 {
	unsigned int string_id;
};
#endif /* ZIG_STRUCT_zT_7C94354F_anon_74738 */
#ifndef ZIG_STRUCT_zT_8082F27A_anon_74746
#define ZIG_STRUCT_zT_8082F27A_anon_74746
struct zT_8082F27A_anon_74746 {
	unsigned int value;
	unsigned int type_id;
	unsigned char fmt;
};
#endif /* ZIG_STRUCT_zT_8082F27A_anon_74746 */
#ifndef ZIG_STRUCT_zT_80853111_anon_74750
#define ZIG_STRUCT_zT_80853111_anon_74750
struct zT_80853111_anon_74750 {
	unsigned int value;
};
#endif /* ZIG_STRUCT_zT_80853111_anon_74750 */
#ifndef ZIG_STRUCT_zT_82853437_anon_74756
#define ZIG_STRUCT_zT_82853437_anon_74756
struct zT_82853437_anon_74756 {
	unsigned int ptr;
	unsigned int len;
};
#endif /* ZIG_STRUCT_zT_82853437_anon_74756 */
#ifndef ZIG_STRUCT_zT_04883F74_anon_74762
#define ZIG_STRUCT_zT_04883F74_anon_74762
struct zT_04883F74_anon_74762 {
	unsigned int ptr;
	unsigned int len;
};
#endif /* ZIG_STRUCT_zT_04883F74_anon_74762 */
#ifndef ZIG_STRUCT_zT_00883928_anon_74766
#define ZIG_STRUCT_zT_00883928_anon_74766
struct zT_00883928_anon_74766 {
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_00883928_anon_74766 */
#ifndef ZIG_STRUCT_zT_EC8A5843_anon_74770
#define ZIG_STRUCT_zT_EC8A5843_anon_74770
struct zT_EC8A5843_anon_74770 {
	unsigned int value;
};
#endif /* ZIG_STRUCT_zT_EC8A5843_anon_74770 */
#ifndef ZIG_STRUCT_zT_F08A5E8F_anon_74774
#define ZIG_STRUCT_zT_F08A5E8F_anon_74774
struct zT_F08A5E8F_anon_74774 {
	unsigned int value;
};
#endif /* ZIG_STRUCT_zT_F08A5E8F_anon_74774 */
#ifndef ZIG_STRUCT_zT_047934EA_anon_74782
#define ZIG_STRUCT_zT_047934EA_anon_74782
struct zT_047934EA_anon_74782 {
	unsigned int x;
	unsigned int y;
};
#endif /* ZIG_STRUCT_zT_047934EA_anon_74782 */
#ifndef ZIG_STRUCT_zT_FA79252C_anon_74788
#define ZIG_STRUCT_zT_FA79252C_anon_74788
struct zT_FA79252C_anon_74788 {
	unsigned int fg;
	unsigned int bg;
};
#endif /* ZIG_STRUCT_zT_FA79252C_anon_74788 */
#ifndef ZIG_STRUCT_zT_E88C3713_anon_74802
#define ZIG_STRUCT_zT_E88C3713_anon_74802
struct zT_E88C3713_anon_74802 {
	unsigned int base;
	unsigned int result;
	unsigned int name_id;
	unsigned int bit_offset;
	unsigned int bit_width;
};
#endif /* ZIG_STRUCT_zT_E88C3713_anon_74802 */
#ifndef ZIG_STRUCT_zT_E689F556_anon_74812
#define ZIG_STRUCT_zT_E689F556_anon_74812
struct zT_E689F556_anon_74812 {
	unsigned int base;
	unsigned int value;
	unsigned int bit_offset;
	unsigned int bit_width;
};
#endif /* ZIG_STRUCT_zT_E689F556_anon_74812 */
#ifndef ZIG_STRUCT_zT_769193CB_anon_74820
#define ZIG_STRUCT_zT_769193CB_anon_74820
struct zT_769193CB_anon_74820 {
	unsigned int cond;
	unsigned char kind;
};
#endif /* ZIG_STRUCT_zT_769193CB_anon_74820 */
#ifndef ZIG_STRUCT_zT_6C8F4576_anon_74834
#define ZIG_STRUCT_zT_6C8F4576_anon_74834
struct zT_6C8F4576_anon_74834 {
	unsigned int lhs;
	unsigned int rhs;
	unsigned int result;
	unsigned int result_type;
	unsigned char width;
	unsigned char is_signed;
};
#endif /* ZIG_STRUCT_zT_6C8F4576_anon_74834 */
#ifndef ZIG_STRUCT_zT_7A961745_anon_74848
#define ZIG_STRUCT_zT_7A961745_anon_74848
struct zT_7A961745_anon_74848 {
	unsigned int lhs;
	unsigned int rhs;
	unsigned int result;
	unsigned int result_type;
	unsigned char width;
	unsigned char is_signed;
};
#endif /* ZIG_STRUCT_zT_7A961745_anon_74848 */
#ifndef ZIG_STRUCT_zT_F09B4E35_anon_74862
#define ZIG_STRUCT_zT_F09B4E35_anon_74862
struct zT_F09B4E35_anon_74862 {
	unsigned int lhs;
	unsigned int rhs;
	unsigned int result;
	unsigned int result_type;
	unsigned char width;
	unsigned char is_signed;
};
#endif /* ZIG_STRUCT_zT_F09B4E35_anon_74862 */
#ifndef ZIG_STRUCT_zT_EA99062C_anon_74876
#define ZIG_STRUCT_zT_EA99062C_anon_74876
struct zT_EA99062C_anon_74876 {
	unsigned int lhs;
	unsigned int rhs;
	unsigned int result;
	unsigned int result_type;
	unsigned char width;
	unsigned char is_signed;
};
#endif /* ZIG_STRUCT_zT_EA99062C_anon_74876 */
#ifndef ZIG_STRUCT_zT_72A09809_anon_74888
#define ZIG_STRUCT_zT_72A09809_anon_74888
struct zT_72A09809_anon_74888 {
	unsigned int value;
	unsigned int result;
	unsigned int result_type;
	unsigned char width;
	unsigned char is_signed;
};
#endif /* ZIG_STRUCT_zT_72A09809_anon_74888 */
#ifndef ZIG_STRUCT_zT_8F078A1A_anon_74904
#define ZIG_STRUCT_zT_8F078A1A_anon_74904
struct zT_8F078A1A_anon_74904 {
	unsigned int lhs;
	unsigned int rhs;
	unsigned int result;
	unsigned int result_type;
	unsigned char op;
	unsigned char width;
	unsigned char is_signed;
};
#endif /* ZIG_STRUCT_zT_8F078A1A_anon_74904 */
#ifndef ZIG_STRUCT_zT_9109CBD7_anon_74910
#define ZIG_STRUCT_zT_9109CBD7_anon_74910
struct zT_9109CBD7_anon_74910 {
	unsigned int value;
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_9109CBD7_anon_74910 */
#ifndef ZIG_STRUCT_zT_8D09C58B_anon_74914
#define ZIG_STRUCT_zT_8D09C58B_anon_74914
struct zT_8D09C58B_anon_74914 {
	unsigned int result;
};
#endif /* ZIG_STRUCT_zT_8D09C58B_anon_74914 */
#ifndef ZIG_STRUCT_zT_05047245_anon_74930
#define ZIG_STRUCT_zT_05047245_anon_74930
struct zT_05047245_anon_74930 {
	unsigned int value;
	unsigned int target;
	unsigned int result;
	unsigned char src_signed;
	unsigned char src_width;
	unsigned char dst_signed;
	unsigned char dst_width;
};
#endif /* ZIG_STRUCT_zT_05047245_anon_74930 */
#ifndef ZIG_STRUCT_zT_90FCFFE4_anon_74942
#define ZIG_STRUCT_zT_90FCFFE4_anon_74942
struct zT_90FCFFE4_anon_74942 {
	unsigned int value;
	unsigned int result;
	unsigned int result_type;
	unsigned char width;
	unsigned char is_signed;
};
#endif /* ZIG_STRUCT_zT_90FCFFE4_anon_74942 */
#ifndef ZIG_ARRAY_zT_C1AB0454_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_C1AB0454_Arr_unsigned_char_8
typedef unsigned char zT_C1AB0454_Arr_unsigned_char_8[8];
#endif /* ZIG_ARRAY_zT_C1AB0454_Arr_unsigned_char_8 */
#ifndef ZIG_OPTIONAL_zT_7334F4FE_Opt_225
#define ZIG_OPTIONAL_zT_7334F4FE_Opt_225
typedef struct { zT_F85C5DED_DiagnosticCollector* value; int has_value; } zT_7334F4FE_Opt_225;
#endif /* ZIG_OPTIONAL_zT_7334F4FE_Opt_225 */
#ifndef ZIG_OPTIONAL_zT_F8B96B9C_Opt_393
#define ZIG_OPTIONAL_zT_F8B96B9C_Opt_393
typedef struct { zT_E2DF2801_LocalConstScope* value; int has_value; } zT_F8B96B9C_Opt_393;
#endif /* ZIG_OPTIONAL_zT_F8B96B9C_Opt_393 */
#ifndef ZIG_OPTIONAL_zT_05CE5599_Opt_400
#define ZIG_OPTIONAL_zT_05CE5599_Opt_400
typedef struct { void* value; int has_value; } zT_05CE5599_Opt_400;
#endif /* ZIG_OPTIONAL_zT_05CE5599_Opt_400 */
#ifndef ZIG_OPTIONAL_zT_DC28CE56_Opt_272
#define ZIG_OPTIONAL_zT_DC28CE56_Opt_272
typedef struct { zT_2C0927B0_StateMap* value; int has_value; } zT_DC28CE56_Opt_272;
#endif /* ZIG_OPTIONAL_zT_DC28CE56_Opt_272 */
#ifndef ZIG_FNPTR_zT_2AAA8C87_FN_void_int_unsigne
#define ZIG_FNPTR_zT_2AAA8C87_FN_void_int_unsigne
#endif /* ZIG_FNPTR_zT_2AAA8C87_FN_void_int_unsigne */
#ifndef ZIG_FNPTR_zT_B4BBB399_FN_void_zT_5AB29387
#define ZIG_FNPTR_zT_B4BBB399_FN_void_zT_5AB29387
#endif /* ZIG_FNPTR_zT_B4BBB399_FN_void_zT_5AB29387 */
#ifndef ZIG_FNPTR_zT_0D68699D_FN_void_zT_21D3708C
#define ZIG_FNPTR_zT_0D68699D_FN_void_zT_21D3708C
#endif /* ZIG_FNPTR_zT_0D68699D_FN_void_zT_21D3708C */
#ifndef ZIG_FNPTR_zT_54BF50F3_FN_zT_C98AF326_Comp
#define ZIG_FNPTR_zT_54BF50F3_FN_zT_C98AF326_Comp
#endif /* ZIG_FNPTR_zT_54BF50F3_FN_zT_C98AF326_Comp */
#ifndef ZIG_FNPTR_zT_AF899B2F_FN_int_zT_8F083A69_
#define ZIG_FNPTR_zT_AF899B2F_FN_int_zT_8F083A69_
#endif /* ZIG_FNPTR_zT_AF899B2F_FN_int_zT_8F083A69_ */
#ifndef ZIG_FNPTR_zT_913BBBBF_FN_int_zT_8F083A69_
#define ZIG_FNPTR_zT_913BBBBF_FN_int_zT_8F083A69_
#endif /* ZIG_FNPTR_zT_913BBBBF_FN_int_zT_8F083A69_ */
#ifndef ZIG_FNPTR_zT_B4F22F0F_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_B4F22F0F_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_B4F22F0F_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_17891801_FN_unsigned_int_uns
#define ZIG_FNPTR_zT_17891801_FN_unsigned_int_uns
#endif /* ZIG_FNPTR_zT_17891801_FN_unsigned_int_uns */
#ifndef ZIG_FNPTR_zT_3E51D5B7_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_3E51D5B7_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_3E51D5B7_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_B908FD10_FN_zT_CAF40AAB_Colo
#define ZIG_FNPTR_zT_B908FD10_FN_zT_CAF40AAB_Colo
#endif /* ZIG_FNPTR_zT_B908FD10_FN_zT_CAF40AAB_Colo */
#ifndef ZIG_FNPTR_zT_89D72814_FN_zT_A4FB690E_Erro
#define ZIG_FNPTR_zT_89D72814_FN_zT_A4FB690E_Erro
#endif /* ZIG_FNPTR_zT_89D72814_FN_zT_A4FB690E_Erro */
#ifndef ZIG_FNPTR_zT_1FD6E2A9_FN_int_unsigned_cha
#define ZIG_FNPTR_zT_1FD6E2A9_FN_int_unsigned_cha
#endif /* ZIG_FNPTR_zT_1FD6E2A9_FN_int_unsigned_cha */
#ifndef ZIG_FNPTR_zT_4E007ECC_FN_void_unsigned_in
#define ZIG_FNPTR_zT_4E007ECC_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_4E007ECC_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_9EF551F0_FN_void
#define ZIG_FNPTR_zT_9EF551F0_FN_void
#endif /* ZIG_FNPTR_zT_9EF551F0_FN_void */
#ifndef ZIG_FNPTR_zT_F6E437D2_FN_zT_3E40CD83_Sand
#define ZIG_FNPTR_zT_F6E437D2_FN_zT_3E40CD83_Sand
#endif /* ZIG_FNPTR_zT_F6E437D2_FN_zT_3E40CD83_Sand */
#ifndef ZIG_ERRORUNION_zT_C6536882_EU_532
#define ZIG_ERRORUNION_zT_C6536882_EU_532
typedef struct { union { unsigned char* payload; int err; } data; int is_error; } zT_C6536882_EU_532;
#endif /* ZIG_ERRORUNION_zT_C6536882_EU_532 */
#ifndef ZIG_FNPTR_zT_45952FF4_FN_zT_C6536882_EU_5
#define ZIG_FNPTR_zT_45952FF4_FN_zT_C6536882_EU_5
#endif /* ZIG_FNPTR_zT_45952FF4_FN_zT_C6536882_EU_5 */
#ifndef ZIG_FNPTR_zT_779C71EA_FN_void_zT_3E40CD83
#define ZIG_FNPTR_zT_779C71EA_FN_void_zT_3E40CD83
#endif /* ZIG_FNPTR_zT_779C71EA_FN_void_zT_3E40CD83 */
#ifndef ZIG_FNPTR_zT_4E926DC4_FN_void_zT_7D82FE60
#define ZIG_FNPTR_zT_4E926DC4_FN_void_zT_7D82FE60
#endif /* ZIG_FNPTR_zT_4E926DC4_FN_void_zT_7D82FE60 */
#ifndef ZIG_FNPTR_zT_621CA24A_FN_int_zT_7D82FE60_
#define ZIG_FNPTR_zT_621CA24A_FN_int_zT_7D82FE60_
#endif /* ZIG_FNPTR_zT_621CA24A_FN_int_zT_7D82FE60_ */
#ifndef ZIG_FNPTR_zT_774813FA_FN_zT_6A32A83C_Opt_
#define ZIG_FNPTR_zT_774813FA_FN_zT_6A32A83C_Opt_
#endif /* ZIG_FNPTR_zT_774813FA_FN_zT_6A32A83C_Opt_ */
#ifndef ZIG_FNPTR_zT_C3E89304_FN_void_zT_8F083A69
#define ZIG_FNPTR_zT_C3E89304_FN_void_zT_8F083A69
#endif /* ZIG_FNPTR_zT_C3E89304_FN_void_zT_8F083A69 */
#ifndef ZIG_OPTIONAL_zT_6F32B01B_Opt_235
#define ZIG_OPTIONAL_zT_6F32B01B_Opt_235
typedef struct { unsigned char* value; int has_value; } zT_6F32B01B_Opt_235;
#endif /* ZIG_OPTIONAL_zT_6F32B01B_Opt_235 */
#ifndef ZIG_FNPTR_zT_3C01E17C_FN_zT_6F32B01B_Opt_
#define ZIG_FNPTR_zT_3C01E17C_FN_zT_6F32B01B_Opt_
#endif /* ZIG_FNPTR_zT_3C01E17C_FN_zT_6F32B01B_Opt_ */
#ifndef ZIG_ARRAY_zT_5B44B793_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_5B44B793_Arr_unsigned_char_2
typedef unsigned char zT_5B44B793_Arr_unsigned_char_2[268435456];
#endif /* ZIG_ARRAY_zT_5B44B793_Arr_unsigned_char_2 */
#ifndef ZIG_FNPTR_zT_56B0E46B_FN_zT_3E40CD83_Sand
#define ZIG_FNPTR_zT_56B0E46B_FN_zT_3E40CD83_Sand
#endif /* ZIG_FNPTR_zT_56B0E46B_FN_zT_3E40CD83_Sand */
#ifndef ZIG_FNPTR_zT_20F27B47_FN_unsigned_int
#define ZIG_FNPTR_zT_20F27B47_FN_unsigned_int
#endif /* ZIG_FNPTR_zT_20F27B47_FN_unsigned_int */
#ifndef ZIG_FNPTR_zT_CFE67B62_FN_zT_69057089_Comp
#define ZIG_FNPTR_zT_CFE67B62_FN_zT_69057089_Comp
#endif /* ZIG_FNPTR_zT_CFE67B62_FN_zT_69057089_Comp */
#ifndef ZIG_FNPTR_zT_0D527D28_FN_void_zT_69057089
#define ZIG_FNPTR_zT_0D527D28_FN_void_zT_69057089
#endif /* ZIG_FNPTR_zT_0D527D28_FN_void_zT_69057089 */
#ifndef ZIG_FNPTR_zT_C44462F1_FN_zT_36103E01_Trac
#define ZIG_FNPTR_zT_C44462F1_FN_zT_36103E01_Trac
#endif /* ZIG_FNPTR_zT_C44462F1_FN_zT_36103E01_Trac */
#ifndef ZIG_FNPTR_zT_2EE7D239_FN_zT_C6536882_EU_5
#define ZIG_FNPTR_zT_2EE7D239_FN_zT_C6536882_EU_5
#endif /* ZIG_FNPTR_zT_2EE7D239_FN_zT_C6536882_EU_5 */
#ifndef ZIG_FNPTR_zT_D15AF893_FN_void_zT_36103E01
#define ZIG_FNPTR_zT_D15AF893_FN_void_zT_36103E01
#endif /* ZIG_FNPTR_zT_D15AF893_FN_void_zT_36103E01 */
#ifndef ZIG_FNPTR_zT_ABA8AA8E_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_ABA8AA8E_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_ABA8AA8E_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_4C036772_FN_zT_5FDE47EF_Trac
#define ZIG_FNPTR_zT_4C036772_FN_zT_5FDE47EF_Trac
#endif /* ZIG_FNPTR_zT_4C036772_FN_zT_5FDE47EF_Trac */
#ifndef ZIG_FNPTR_zT_47BA4FCC_FN_void_unsigned_in
#define ZIG_FNPTR_zT_47BA4FCC_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_47BA4FCC_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_22D4BC6E_FN_void_zT_EABC94D3
#define ZIG_FNPTR_zT_22D4BC6E_FN_void_zT_EABC94D3
#endif /* ZIG_FNPTR_zT_22D4BC6E_FN_void_zT_EABC94D3 */
#ifndef ZIG_FNPTR_zT_3A14A879_FN_void_zT_EABC94D3
#define ZIG_FNPTR_zT_3A14A879_FN_void_zT_EABC94D3
#endif /* ZIG_FNPTR_zT_3A14A879_FN_void_zT_EABC94D3 */
#ifndef ZIG_FNPTR_zT_D106D872_FN_zT_D3EB6303_Stri
#define ZIG_FNPTR_zT_D106D872_FN_zT_D3EB6303_Stri
#endif /* ZIG_FNPTR_zT_D106D872_FN_zT_D3EB6303_Stri */
#ifndef ZIG_FNPTR_zT_C2D50F03_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_C2D50F03_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_C2D50F03_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_4C2E7523_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_4C2E7523_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_4C2E7523_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_DF96B7CB_FN_unsigned_char__z
#define ZIG_FNPTR_zT_DF96B7CB_FN_unsigned_char__z
#endif /* ZIG_FNPTR_zT_DF96B7CB_FN_unsigned_char__z */
#ifndef ZIG_FNPTR_zT_3EA125F4_FN_void_zT_D3EB6303
#define ZIG_FNPTR_zT_3EA125F4_FN_void_zT_D3EB6303
#endif /* ZIG_FNPTR_zT_3EA125F4_FN_void_zT_D3EB6303 */
#ifndef ZIG_FNPTR_zT_325B9EF4_FN_zT_6B45117F_Sour
#define ZIG_FNPTR_zT_325B9EF4_FN_zT_6B45117F_Sour
#endif /* ZIG_FNPTR_zT_325B9EF4_FN_zT_6B45117F_Sour */
#ifndef ZIG_FNPTR_zT_8B7D2ED8_FN_void_zT_6B45117F
#define ZIG_FNPTR_zT_8B7D2ED8_FN_void_zT_6B45117F
#endif /* ZIG_FNPTR_zT_8B7D2ED8_FN_void_zT_6B45117F */
#ifndef ZIG_FNPTR_zT_213529D3_FN_void_zT_6B45117F
#define ZIG_FNPTR_zT_213529D3_FN_void_zT_6B45117F
#endif /* ZIG_FNPTR_zT_213529D3_FN_void_zT_6B45117F */
#ifndef ZIG_SLICE_zT_1D6CA09C_Slice_zT_ED18556E_S
#define ZIG_SLICE_zT_1D6CA09C_Slice_zT_ED18556E_S
typedef struct { zT_ED18556E_SourceFile* ptr; unsigned int len; } zT_1D6CA09C_Slice_zT_ED18556E_S;
#endif /* ZIG_SLICE_zT_1D6CA09C_Slice_zT_ED18556E_S */
#ifndef ZIG_FNPTR_zT_660816A6_FN_zT_1D6CA09C_Slic
#define ZIG_FNPTR_zT_660816A6_FN_zT_1D6CA09C_Slic
#endif /* ZIG_FNPTR_zT_660816A6_FN_zT_1D6CA09C_Slic */
#ifndef ZIG_FNPTR_zT_367D7DE6_FN_zT_227EDE07_Sour
#define ZIG_FNPTR_zT_367D7DE6_FN_zT_227EDE07_Sour
#endif /* ZIG_FNPTR_zT_367D7DE6_FN_zT_227EDE07_Sour */
#ifndef ZIG_FNPTR_zT_FE795838_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_FE795838_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_FE795838_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_F7AE6816_FN_void_zT_227EDE07
#define ZIG_FNPTR_zT_F7AE6816_FN_void_zT_227EDE07
#endif /* ZIG_FNPTR_zT_F7AE6816_FN_void_zT_227EDE07 */
#ifndef ZIG_FNPTR_zT_1BFE9892_FN_void_zT_227EDE07
#define ZIG_FNPTR_zT_1BFE9892_FN_void_zT_227EDE07
#endif /* ZIG_FNPTR_zT_1BFE9892_FN_void_zT_227EDE07 */
#ifndef ZIG_FNPTR_zT_2F5F4343_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_2F5F4343_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_2F5F4343_FN_zT_8F083A69_Slic */
#ifndef ZIG_SLICE_zT_3CB0179A_Slice_zT_05F374B1_u
#define ZIG_SLICE_zT_3CB0179A_Slice_zT_05F374B1_u
typedef struct { unsigned int* ptr; unsigned int len; } zT_3CB0179A_Slice_zT_05F374B1_u;
#endif /* ZIG_SLICE_zT_3CB0179A_Slice_zT_05F374B1_u */
#ifndef ZIG_FNPTR_zT_1A82B686_FN_zT_3CB0179A_Slic
#define ZIG_FNPTR_zT_1A82B686_FN_zT_3CB0179A_Slic
#endif /* ZIG_FNPTR_zT_1A82B686_FN_zT_3CB0179A_Slic */
#ifndef ZIG_FNPTR_zT_5BF1E7E4_FN_zT_5BC08DC6_Loca
#define ZIG_FNPTR_zT_5BF1E7E4_FN_zT_5BC08DC6_Loca
#endif /* ZIG_FNPTR_zT_5BF1E7E4_FN_zT_5BC08DC6_Loca */
#ifndef ZIG_FNPTR_zT_C39C920F_FN_unsigned_char__z
#define ZIG_FNPTR_zT_C39C920F_FN_unsigned_char__z
#endif /* ZIG_FNPTR_zT_C39C920F_FN_unsigned_char__z */
#ifndef ZIG_FNPTR_zT_AB467A4A_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_AB467A4A_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_AB467A4A_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_E62CF041_FN_unsigned_int_uns
#define ZIG_FNPTR_zT_E62CF041_FN_unsigned_int_uns
#endif /* ZIG_FNPTR_zT_E62CF041_FN_unsigned_int_uns */
#ifndef ZIG_FNPTR_zT_85125EC4_FN_void_zT_8F083A69
#define ZIG_FNPTR_zT_85125EC4_FN_void_zT_8F083A69
#endif /* ZIG_FNPTR_zT_85125EC4_FN_void_zT_8F083A69 */
#ifndef ZIG_FNPTR_zT_79E16A0F_FN_int_zT_50FBF81E_
#define ZIG_FNPTR_zT_79E16A0F_FN_int_zT_50FBF81E_
#endif /* ZIG_FNPTR_zT_79E16A0F_FN_int_zT_50FBF81E_ */
#ifndef ZIG_SLICE_zT_8D25846A_Slice_zT_50FBF81E_D
#define ZIG_SLICE_zT_8D25846A_Slice_zT_50FBF81E_D
typedef struct { zT_50FBF81E_Diagnostic* ptr; unsigned int len; } zT_8D25846A_Slice_zT_50FBF81E_D;
#endif /* ZIG_SLICE_zT_8D25846A_Slice_zT_50FBF81E_D */
#ifndef ZIG_FNPTR_zT_6F5A4B17_FN_void_zT_8D25846A
#define ZIG_FNPTR_zT_6F5A4B17_FN_void_zT_8D25846A
#endif /* ZIG_FNPTR_zT_6F5A4B17_FN_void_zT_8D25846A */
#ifndef ZIG_FNPTR_zT_A34E8A26_FN_zT_C0B2E5AF_Diag
#define ZIG_FNPTR_zT_A34E8A26_FN_zT_C0B2E5AF_Diag
#endif /* ZIG_FNPTR_zT_A34E8A26_FN_zT_C0B2E5AF_Diag */
#ifndef ZIG_FNPTR_zT_77ECE8C2_FN_void_zT_C0B2E5AF
#define ZIG_FNPTR_zT_77ECE8C2_FN_void_zT_C0B2E5AF
#endif /* ZIG_FNPTR_zT_77ECE8C2_FN_void_zT_C0B2E5AF */
#ifndef ZIG_FNPTR_zT_CFA402BF_FN_void_zT_C0B2E5AF
#define ZIG_FNPTR_zT_CFA402BF_FN_void_zT_C0B2E5AF
#endif /* ZIG_FNPTR_zT_CFA402BF_FN_void_zT_C0B2E5AF */
#ifndef ZIG_FNPTR_zT_FF6071B0_FN_zT_8D25846A_Slic
#define ZIG_FNPTR_zT_FF6071B0_FN_zT_8D25846A_Slic
#endif /* ZIG_FNPTR_zT_FF6071B0_FN_zT_8D25846A_Slic */
#ifndef ZIG_FNPTR_zT_23C309CA_FN_zT_F85C5DED_Diag
#define ZIG_FNPTR_zT_23C309CA_FN_zT_F85C5DED_Diag
#endif /* ZIG_FNPTR_zT_23C309CA_FN_zT_F85C5DED_Diag */
#ifndef ZIG_FNPTR_zT_47E855BD_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_47E855BD_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_47E855BD_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_64F494AB_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_64F494AB_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_64F494AB_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_078D2475_FN_int_zT_F85C5DED_
#define ZIG_FNPTR_zT_078D2475_FN_int_zT_F85C5DED_
#endif /* ZIG_FNPTR_zT_078D2475_FN_int_zT_F85C5DED_ */
#ifndef ZIG_FNPTR_zT_1B64B25D_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_1B64B25D_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_1B64B25D_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_6DCA1F67_FN_int_zT_F85C5DED_
#define ZIG_FNPTR_zT_6DCA1F67_FN_int_zT_F85C5DED_
#endif /* ZIG_FNPTR_zT_6DCA1F67_FN_int_zT_F85C5DED_ */
#ifndef ZIG_FNPTR_zT_94516914_FN_void_zT_F85C5DED
#define ZIG_FNPTR_zT_94516914_FN_void_zT_F85C5DED
#endif /* ZIG_FNPTR_zT_94516914_FN_void_zT_F85C5DED */
#ifndef ZIG_FNPTR_zT_BE8B8B97_FN_void_zT_F85C5DED
#define ZIG_FNPTR_zT_BE8B8B97_FN_void_zT_F85C5DED
#endif /* ZIG_FNPTR_zT_BE8B8B97_FN_void_zT_F85C5DED */
#ifndef ZIG_FNPTR_zT_71E19A20_FN_void_zT_F85C5DED
#define ZIG_FNPTR_zT_71E19A20_FN_void_zT_F85C5DED
#endif /* ZIG_FNPTR_zT_71E19A20_FN_void_zT_F85C5DED */
#ifndef ZIG_FNPTR_zT_6AE0011A_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_6AE0011A_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_6AE0011A_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_EB3396DC_FN_void_zT_F85C5DED
#define ZIG_FNPTR_zT_EB3396DC_FN_void_zT_F85C5DED
#endif /* ZIG_FNPTR_zT_EB3396DC_FN_void_zT_F85C5DED */
#ifndef ZIG_FNPTR_zT_38DD48DF_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_38DD48DF_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_38DD48DF_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_ABBFAEF8_FN_zT_CEC2984A_Name
#define ZIG_FNPTR_zT_ABBFAEF8_FN_zT_CEC2984A_Name
#endif /* ZIG_FNPTR_zT_ABBFAEF8_FN_zT_CEC2984A_Name */
#ifndef ZIG_SLICE_zT_F4F52502_Slice_zT_C1009AE8_K
#define ZIG_SLICE_zT_F4F52502_Slice_zT_C1009AE8_K
typedef struct { zT_C1009AE8_KeywordEntry* ptr; unsigned int len; } zT_F4F52502_Slice_zT_C1009AE8_K;
#endif /* ZIG_SLICE_zT_F4F52502_Slice_zT_C1009AE8_K */
#ifndef ZIG_FNPTR_zT_ECAF94D7_FN_zT_ACDCBA03_Opt_
#define ZIG_FNPTR_zT_ECAF94D7_FN_zT_ACDCBA03_Opt_
#endif /* ZIG_FNPTR_zT_ECAF94D7_FN_zT_ACDCBA03_Opt_ */
#ifndef ZIG_FNPTR_zT_DB2E0BFE_FN_zT_138FFB41_Lexe
#define ZIG_FNPTR_zT_DB2E0BFE_FN_zT_138FFB41_Lexe
#endif /* ZIG_FNPTR_zT_DB2E0BFE_FN_zT_138FFB41_Lexe */
#ifndef ZIG_FNPTR_zT_FDF5BBD3_FN_zT_3A355BD2_Toke
#define ZIG_FNPTR_zT_FDF5BBD3_FN_zT_3A355BD2_Toke
#endif /* ZIG_FNPTR_zT_FDF5BBD3_FN_zT_3A355BD2_Toke */
#ifndef ZIG_FNPTR_zT_8D10A8BB_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_8D10A8BB_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_8D10A8BB_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_6BF63415_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_6BF63415_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_6BF63415_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_01486A38_FN_int_zT_138FFB41_
#define ZIG_FNPTR_zT_01486A38_FN_int_zT_138FFB41_
#endif /* ZIG_FNPTR_zT_01486A38_FN_int_zT_138FFB41_ */
#ifndef ZIG_FNPTR_zT_A7AAD7D3_FN_int_zT_138FFB41_
#define ZIG_FNPTR_zT_A7AAD7D3_FN_int_zT_138FFB41_
#endif /* ZIG_FNPTR_zT_A7AAD7D3_FN_int_zT_138FFB41_ */
#ifndef ZIG_FNPTR_zT_935341CD_FN_void_zT_138FFB41
#define ZIG_FNPTR_zT_935341CD_FN_void_zT_138FFB41
#endif /* ZIG_FNPTR_zT_935341CD_FN_void_zT_138FFB41 */
#ifndef ZIG_FNPTR_zT_B3D5D568_FN_zT_3A355BD2_Toke
#define ZIG_FNPTR_zT_B3D5D568_FN_zT_3A355BD2_Toke
#endif /* ZIG_FNPTR_zT_B3D5D568_FN_zT_3A355BD2_Toke */
#ifndef ZIG_FNPTR_zT_8A6406AD_FN_zT_3A355BD2_Toke
#define ZIG_FNPTR_zT_8A6406AD_FN_zT_3A355BD2_Toke
#endif /* ZIG_FNPTR_zT_8A6406AD_FN_zT_3A355BD2_Toke */
#ifndef ZIG_FNPTR_zT_D663AD22_FN_zT_3A355BD2_Toke
#define ZIG_FNPTR_zT_D663AD22_FN_zT_3A355BD2_Toke
#endif /* ZIG_FNPTR_zT_D663AD22_FN_zT_3A355BD2_Toke */
#ifndef ZIG_FNPTR_zT_774C200C_FN_int_unsigned_cha
#define ZIG_FNPTR_zT_774C200C_FN_int_unsigned_cha
#endif /* ZIG_FNPTR_zT_774C200C_FN_int_unsigned_cha */
#ifndef ZIG_FNPTR_zT_ED6A61ED_FN_unsigned_char_un
#define ZIG_FNPTR_zT_ED6A61ED_FN_unsigned_char_un
#endif /* ZIG_FNPTR_zT_ED6A61ED_FN_unsigned_char_un */
#ifndef ZIG_FNPTR_zT_6EB3A827_FN_int_unsigned_cha
#define ZIG_FNPTR_zT_6EB3A827_FN_int_unsigned_cha
#endif /* ZIG_FNPTR_zT_6EB3A827_FN_int_unsigned_cha */
#ifndef ZIG_FNPTR_zT_B3F8F956_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_B3F8F956_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_B3F8F956_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_25EAD0EB_FN_double_zT_8F083A
#define ZIG_FNPTR_zT_25EAD0EB_FN_double_zT_8F083A
#endif /* ZIG_FNPTR_zT_25EAD0EB_FN_double_zT_8F083A */
#ifndef ZIG_FNPTR_zT_3C78C238_FN_void_int_int_uns
#define ZIG_FNPTR_zT_3C78C238_FN_void_int_int_uns
#endif /* ZIG_FNPTR_zT_3C78C238_FN_void_int_int_uns */
#ifndef ZIG_FNPTR_zT_F810CEAC_FN_void_unsigned_in
#define ZIG_FNPTR_zT_F810CEAC_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_F810CEAC_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_129E17F4_FN_void_unsigned_ch
#define ZIG_FNPTR_zT_129E17F4_FN_void_unsigned_ch
#endif /* ZIG_FNPTR_zT_129E17F4_FN_void_unsigned_ch */
#ifndef ZIG_FNPTR_zT_60DFAF2C_FN_void_zT_EAC3E484
#define ZIG_FNPTR_zT_60DFAF2C_FN_void_zT_EAC3E484
#endif /* ZIG_FNPTR_zT_60DFAF2C_FN_void_zT_EAC3E484 */
#ifndef ZIG_FNPTR_zT_5E512969_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_5E512969_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_5E512969_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_1D77F853_FN_zT_05CE5599_Opt_
#define ZIG_FNPTR_zT_1D77F853_FN_zT_05CE5599_Opt_
#endif /* ZIG_FNPTR_zT_1D77F853_FN_zT_05CE5599_Opt_ */
#ifndef ZIG_FNPTR_zT_6071C90D_FN_unsigned_int_uns
#define ZIG_FNPTR_zT_6071C90D_FN_unsigned_int_uns
#endif /* ZIG_FNPTR_zT_6071C90D_FN_unsigned_int_uns */
#ifndef ZIG_FNPTR_zT_C296BD8F_FN_int_void_
#define ZIG_FNPTR_zT_C296BD8F_FN_int_void_
#endif /* ZIG_FNPTR_zT_C296BD8F_FN_int_void_ */
#ifndef ZIG_FNPTR_zT_C5544763_FN_int_void__int_in
#define ZIG_FNPTR_zT_C5544763_FN_int_void__int_in
#endif /* ZIG_FNPTR_zT_C5544763_FN_int_void__int_in */
#ifndef ZIG_FNPTR_zT_E9D1F286_FN_void_int
#define ZIG_FNPTR_zT_E9D1F286_FN_void_int
#endif /* ZIG_FNPTR_zT_E9D1F286_FN_void_int */
#ifndef ZIG_FNPTR_zT_6D7D6AE3_FN_unsigned_int_uns
#define ZIG_FNPTR_zT_6D7D6AE3_FN_unsigned_int_uns
#endif /* ZIG_FNPTR_zT_6D7D6AE3_FN_unsigned_int_uns */
#ifndef ZIG_FNPTR_zT_A369D2D5_FN_int_unsigned_int
#define ZIG_FNPTR_zT_A369D2D5_FN_int_unsigned_int
#endif /* ZIG_FNPTR_zT_A369D2D5_FN_int_unsigned_int */
#ifndef ZIG_FNPTR_zT_09F6D341_FN_int_unsigned_int
#define ZIG_FNPTR_zT_09F6D341_FN_int_unsigned_int
#endif /* ZIG_FNPTR_zT_09F6D341_FN_int_unsigned_int */
#ifndef ZIG_FNPTR_zT_7B20297B_FN_int_unsigned_cha
#define ZIG_FNPTR_zT_7B20297B_FN_int_unsigned_cha
#endif /* ZIG_FNPTR_zT_7B20297B_FN_int_unsigned_cha */
#ifndef ZIG_FNPTR_zT_67050892_FN_zT_05D09430_Opt_
#define ZIG_FNPTR_zT_67050892_FN_zT_05D09430_Opt_
#endif /* ZIG_FNPTR_zT_67050892_FN_zT_05D09430_Opt_ */
#ifndef ZIG_FNPTR_zT_B881F5D9_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_B881F5D9_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_B881F5D9_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_5669B798_FN_void_unsigned_in
#define ZIG_FNPTR_zT_5669B798_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_5669B798_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_23D8BB69_FN_zT_05CE5599_Opt_
#define ZIG_FNPTR_zT_23D8BB69_FN_zT_05CE5599_Opt_
#endif /* ZIG_FNPTR_zT_23D8BB69_FN_zT_05CE5599_Opt_ */
#ifndef ZIG_FNPTR_zT_2FED1C58_FN_void_void_
#define ZIG_FNPTR_zT_2FED1C58_FN_void_void_
#endif /* ZIG_FNPTR_zT_2FED1C58_FN_void_void_ */
#ifndef ZIG_FNPTR_zT_F63C95AC_FN_void_void__zT_8F
#define ZIG_FNPTR_zT_F63C95AC_FN_void_void__zT_8F
#endif /* ZIG_FNPTR_zT_F63C95AC_FN_void_void__zT_8F */
#ifndef ZIG_FNPTR_zT_C9A72C9E_FN_void_void__int
#define ZIG_FNPTR_zT_C9A72C9E_FN_void_void__int
#endif /* ZIG_FNPTR_zT_C9A72C9E_FN_void_void__int */
#ifndef ZIG_FNPTR_zT_D3EB464B_FN_void_unsigned_ch
#define ZIG_FNPTR_zT_D3EB464B_FN_void_unsigned_ch
#endif /* ZIG_FNPTR_zT_D3EB464B_FN_void_unsigned_ch */
#ifndef ZIG_FNPTR_zT_4C83B0AF_FN_int
#define ZIG_FNPTR_zT_4C83B0AF_FN_int
#endif /* ZIG_FNPTR_zT_4C83B0AF_FN_int */
#ifndef ZIG_FNPTR_zT_48E71761_FN_unsigned_char__i
#define ZIG_FNPTR_zT_48E71761_FN_unsigned_char__i
#endif /* ZIG_FNPTR_zT_48E71761_FN_unsigned_char__i */
#ifndef ZIG_FNPTR_zT_3FEF1248_FN_void_zT_8F083A69
#define ZIG_FNPTR_zT_3FEF1248_FN_void_zT_8F083A69
#endif /* ZIG_FNPTR_zT_3FEF1248_FN_void_zT_8F083A69 */
#ifndef ZIG_FNPTR_zT_E69F4054_FN_void_zT_8F083A69
#define ZIG_FNPTR_zT_E69F4054_FN_void_zT_8F083A69
#endif /* ZIG_FNPTR_zT_E69F4054_FN_void_zT_8F083A69 */
#ifndef ZIG_FNPTR_zT_57CE0709_FN_zT_B559F9DA_Pars
#define ZIG_FNPTR_zT_57CE0709_FN_zT_B559F9DA_Pars
#endif /* ZIG_FNPTR_zT_57CE0709_FN_zT_B559F9DA_Pars */
#ifndef ZIG_SLICE_zT_F020719E_Slice_zT_3A355BD2_T
#define ZIG_SLICE_zT_F020719E_Slice_zT_3A355BD2_T
typedef struct { zT_3A355BD2_Token* ptr; unsigned int len; } zT_F020719E_Slice_zT_3A355BD2_T;
#endif /* ZIG_SLICE_zT_F020719E_Slice_zT_3A355BD2_T */
#ifndef ZIG_FNPTR_zT_9FF0102F_FN_zT_B559F9DA_Pars
#define ZIG_FNPTR_zT_9FF0102F_FN_zT_B559F9DA_Pars
#endif /* ZIG_FNPTR_zT_9FF0102F_FN_zT_B559F9DA_Pars */
#ifndef ZIG_FNPTR_zT_50DF4F60_FN_zT_B559F9DA_Pars
#define ZIG_FNPTR_zT_50DF4F60_FN_zT_B559F9DA_Pars
#endif /* ZIG_FNPTR_zT_50DF4F60_FN_zT_B559F9DA_Pars */
#ifndef ZIG_FNPTR_zT_3E59F771_FN_void_zT_B559F9DA
#define ZIG_FNPTR_zT_3E59F771_FN_void_zT_B559F9DA
#endif /* ZIG_FNPTR_zT_3E59F771_FN_void_zT_B559F9DA */
#ifndef ZIG_FNPTR_zT_D3D4FE98_FN_void_zT_B559F9DA
#define ZIG_FNPTR_zT_D3D4FE98_FN_void_zT_B559F9DA
#endif /* ZIG_FNPTR_zT_D3D4FE98_FN_void_zT_B559F9DA */
#ifndef ZIG_FNPTR_zT_A717F14D_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_A717F14D_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_A717F14D_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_15C83436_FN_void_zT_B559F9DA
#define ZIG_FNPTR_zT_15C83436_FN_void_zT_B559F9DA
#endif /* ZIG_FNPTR_zT_15C83436_FN_void_zT_B559F9DA */
#ifndef ZIG_FNPTR_zT_F875A680_FN_zT_3A355BD2_Toke
#define ZIG_FNPTR_zT_F875A680_FN_zT_3A355BD2_Toke
#endif /* ZIG_FNPTR_zT_F875A680_FN_zT_3A355BD2_Toke */
#ifndef ZIG_FNPTR_zT_63205F1C_FN_zT_3A355BD2_Toke
#define ZIG_FNPTR_zT_63205F1C_FN_zT_3A355BD2_Toke
#endif /* ZIG_FNPTR_zT_63205F1C_FN_zT_3A355BD2_Toke */
#ifndef ZIG_FNPTR_zT_9A670898_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_9A670898_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_9A670898_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_A7636D27_FN_zT_CB78802F_EU_4
#define ZIG_FNPTR_zT_A7636D27_FN_zT_CB78802F_EU_4
#endif /* ZIG_FNPTR_zT_A7636D27_FN_zT_CB78802F_EU_4 */
#ifndef ZIG_FNPTR_zT_7F1C2FD9_FN_void_zT_B559F9DA
#define ZIG_FNPTR_zT_7F1C2FD9_FN_void_zT_B559F9DA
#endif /* ZIG_FNPTR_zT_7F1C2FD9_FN_void_zT_B559F9DA */
#ifndef ZIG_ERRORUNION_zT_3B6EA323_EU_01
#define ZIG_ERRORUNION_zT_3B6EA323_EU_01
typedef struct { union { unsigned int payload; int err; } data; int is_error; } zT_3B6EA323_EU_01;
#endif /* ZIG_ERRORUNION_zT_3B6EA323_EU_01 */
#ifndef ZIG_FNPTR_zT_2B9B0075_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_2B9B0075_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_2B9B0075_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_46F29FF8_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_46F29FF8_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_46F29FF8_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_B851DC9F_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_B851DC9F_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_B851DC9F_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_82F37BB1_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_82F37BB1_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_82F37BB1_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_7D51A128_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_7D51A128_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_7D51A128_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_450ED620_FN_void_zT_B559F9DA
#define ZIG_FNPTR_zT_450ED620_FN_void_zT_B559F9DA
#endif /* ZIG_FNPTR_zT_450ED620_FN_void_zT_B559F9DA */
#ifndef ZIG_FNPTR_zT_CAE654CF_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_CAE654CF_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_CAE654CF_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_2E3C05F8_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_2E3C05F8_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_2E3C05F8_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_8D5AB168_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_8D5AB168_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_8D5AB168_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_B7A4999C_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_B7A4999C_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_B7A4999C_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_6512B292_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_6512B292_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_6512B292_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_226D0D47_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_226D0D47_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_226D0D47_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_6BB5B85C_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_6BB5B85C_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_6BB5B85C_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_49020210_FN_void_zT_B559F9DA
#define ZIG_FNPTR_zT_49020210_FN_void_zT_B559F9DA
#endif /* ZIG_FNPTR_zT_49020210_FN_void_zT_B559F9DA */
#ifndef ZIG_FNPTR_zT_95E71F51_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_95E71F51_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_95E71F51_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_3C920EC4_FN_zT_3B6EA323_EU_0
#define ZIG_FNPTR_zT_3C920EC4_FN_zT_3B6EA323_EU_0
#endif /* ZIG_FNPTR_zT_3C920EC4_FN_zT_3B6EA323_EU_0 */
#ifndef ZIG_FNPTR_zT_F51A315E_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_F51A315E_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_F51A315E_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_414D00FC_FN_zT_2B10107F_Prec
#define ZIG_FNPTR_zT_414D00FC_FN_zT_2B10107F_Prec
#endif /* ZIG_FNPTR_zT_414D00FC_FN_zT_2B10107F_Prec */
#ifndef ZIG_FNPTR_zT_15A95FFD_FN_zT_ADDA7CFF_Opt_
#define ZIG_FNPTR_zT_15A95FFD_FN_zT_ADDA7CFF_Opt_
#endif /* ZIG_FNPTR_zT_15A95FFD_FN_zT_ADDA7CFF_Opt_ */
#ifndef ZIG_FNPTR_zT_84232CAC_FN_void_zT_79FAE712
#define ZIG_FNPTR_zT_84232CAC_FN_void_zT_79FAE712
#endif /* ZIG_FNPTR_zT_84232CAC_FN_void_zT_79FAE712 */
#ifndef ZIG_FNPTR_zT_1F0EFC3C_FN_void_double___un
#define ZIG_FNPTR_zT_1F0EFC3C_FN_void_double___un
#endif /* ZIG_FNPTR_zT_1F0EFC3C_FN_void_double___un */
#ifndef ZIG_FNPTR_zT_475598C0_FN_void_zT_243D6A41
#define ZIG_FNPTR_zT_475598C0_FN_void_zT_243D6A41
#endif /* ZIG_FNPTR_zT_475598C0_FN_void_zT_243D6A41 */
#ifndef ZIG_FNPTR_zT_B57D7B4E_FN_zT_6B0A7D14_AstS
#define ZIG_FNPTR_zT_B57D7B4E_FN_zT_6B0A7D14_AstS
#endif /* ZIG_FNPTR_zT_B57D7B4E_FN_zT_6B0A7D14_AstS */
#ifndef ZIG_FNPTR_zT_AD2ABF18_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_AD2ABF18_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_AD2ABF18_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_27DC3FEC_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_27DC3FEC_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_27DC3FEC_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_5A68D2BA_FN_void_zT_01BE9D46
#define ZIG_FNPTR_zT_5A68D2BA_FN_void_zT_01BE9D46
#endif /* ZIG_FNPTR_zT_5A68D2BA_FN_void_zT_01BE9D46 */
#ifndef ZIG_FNPTR_zT_16C67F60_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_16C67F60_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_16C67F60_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_BDBA91D6_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_BDBA91D6_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_BDBA91D6_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_94C693DD_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_94C693DD_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_94C693DD_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_D634F78B_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_D634F78B_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_D634F78B_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_8FDFA981_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_8FDFA981_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_8FDFA981_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_B38420ED_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_B38420ED_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_B38420ED_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_4423ADDF_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_4423ADDF_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_4423ADDF_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_EF21617A_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_EF21617A_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_EF21617A_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_A7093C2A_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_A7093C2A_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_A7093C2A_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_1B5B74D4_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_1B5B74D4_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_1B5B74D4_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_00BF2498_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_00BF2498_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_00BF2498_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_242E0B13_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_242E0B13_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_242E0B13_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_5D94EEB5_FN_zT_22A7C88B_AstN
#define ZIG_FNPTR_zT_5D94EEB5_FN_zT_22A7C88B_AstN
#endif /* ZIG_FNPTR_zT_5D94EEB5_FN_zT_22A7C88B_AstN */
#ifndef ZIG_FNPTR_zT_4B981B06_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_4B981B06_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_4B981B06_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_B0DAF52B_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_B0DAF52B_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_B0DAF52B_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_B639EE45_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_B639EE45_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_B639EE45_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_E6FB4E4E_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_E6FB4E4E_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_E6FB4E4E_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_D6EF028F_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_D6EF028F_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_D6EF028F_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_C57C643F_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_C57C643F_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_C57C643F_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_C3AC5B88_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_C3AC5B88_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_C3AC5B88_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_3B711DB7_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_3B711DB7_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_3B711DB7_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_BC17901D_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_BC17901D_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_BC17901D_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_8E5880D1_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_8E5880D1_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_8E5880D1_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_F579E6C7_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_F579E6C7_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_F579E6C7_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_2967593D_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_2967593D_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_2967593D_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_EFBE175F_FN_int_zT_8143F551_
#define ZIG_FNPTR_zT_EFBE175F_FN_int_zT_8143F551_
#endif /* ZIG_FNPTR_zT_EFBE175F_FN_int_zT_8143F551_ */
#ifndef ZIG_FNPTR_zT_9DB8895C_FN_int_zT_8143F551_
#define ZIG_FNPTR_zT_9DB8895C_FN_int_zT_8143F551_
#endif /* ZIG_FNPTR_zT_9DB8895C_FN_int_zT_8143F551_ */
#ifndef ZIG_FNPTR_zT_EEDBD622_FP_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_EEDBD622_FP_void_zT_6B0A7D14
typedef void (*zT_EEDBD622_FP_void_zT_6B0A7D14)(zT_6B0A7D14_AstStore*, unsigned int);
#endif /* ZIG_FNPTR_zT_EEDBD622_FP_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_367F3814_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_367F3814_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_367F3814_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_C690768D_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_C690768D_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_C690768D_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_92DCAEEF_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_92DCAEEF_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_92DCAEEF_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_4CB5FF77_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_4CB5FF77_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_4CB5FF77_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_4E1BB469_FN_zT_7734FB4A_Opt_
#define ZIG_FNPTR_zT_4E1BB469_FN_zT_7734FB4A_Opt_
#endif /* ZIG_FNPTR_zT_4E1BB469_FN_zT_7734FB4A_Opt_ */
#ifndef ZIG_FNPTR_zT_45C5AD8F_FN_zT_E41AEC18_Modu
#define ZIG_FNPTR_zT_45C5AD8F_FN_zT_E41AEC18_Modu
#endif /* ZIG_FNPTR_zT_45C5AD8F_FN_zT_E41AEC18_Modu */
#ifndef ZIG_FNPTR_zT_76665215_FN_void_zT_E41AEC18
#define ZIG_FNPTR_zT_76665215_FN_void_zT_E41AEC18
#endif /* ZIG_FNPTR_zT_76665215_FN_void_zT_E41AEC18 */
#ifndef ZIG_FNPTR_zT_526B95E9_FN_void_zT_E41AEC18
#define ZIG_FNPTR_zT_526B95E9_FN_void_zT_E41AEC18
#endif /* ZIG_FNPTR_zT_526B95E9_FN_void_zT_E41AEC18 */
#ifndef ZIG_SLICE_zT_DDCD424B_Slice_zT_6E8D187B_M
#define ZIG_SLICE_zT_DDCD424B_Slice_zT_6E8D187B_M
typedef struct { zT_6E8D187B_ModuleEntry* ptr; unsigned int len; } zT_DDCD424B_Slice_zT_6E8D187B_M;
#endif /* ZIG_SLICE_zT_DDCD424B_Slice_zT_6E8D187B_M */
#ifndef ZIG_FNPTR_zT_68E9FE0D_FN_zT_DDCD424B_Slic
#define ZIG_FNPTR_zT_68E9FE0D_FN_zT_DDCD424B_Slic
#endif /* ZIG_FNPTR_zT_68E9FE0D_FN_zT_DDCD424B_Slic */
#ifndef ZIG_FNPTR_zT_C7E1EEE0_FN_void_zT_4EA49A91
#define ZIG_FNPTR_zT_C7E1EEE0_FN_void_zT_4EA49A91
#endif /* ZIG_FNPTR_zT_C7E1EEE0_FN_void_zT_4EA49A91 */
#ifndef ZIG_FNPTR_zT_D558D6D2_FN_zT_7734FB4A_Opt_
#define ZIG_FNPTR_zT_D558D6D2_FN_zT_7734FB4A_Opt_
#endif /* ZIG_FNPTR_zT_D558D6D2_FN_zT_7734FB4A_Opt_ */
#ifndef ZIG_FNPTR_zT_09555815_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_09555815_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_09555815_FN_zT_8F083A69_Slic */
#ifndef ZIG_OPTIONAL_zT_BAEE192E_Opt_10
#define ZIG_OPTIONAL_zT_BAEE192E_Opt_10
typedef struct { unsigned int value; int has_value; } zT_BAEE192E_Opt_10;
#endif /* ZIG_OPTIONAL_zT_BAEE192E_Opt_10 */
#ifndef ZIG_FNPTR_zT_86CEB27F_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_86CEB27F_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_86CEB27F_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_329B4BDF_FN_zT_4DB1475B_Modu
#define ZIG_FNPTR_zT_329B4BDF_FN_zT_4DB1475B_Modu
#endif /* ZIG_FNPTR_zT_329B4BDF_FN_zT_4DB1475B_Modu */
#ifndef ZIG_FNPTR_zT_6F2ACAD7_FN_void_zT_4DB1475B
#define ZIG_FNPTR_zT_6F2ACAD7_FN_void_zT_4DB1475B
#endif /* ZIG_FNPTR_zT_6F2ACAD7_FN_void_zT_4DB1475B */
#ifndef ZIG_FNPTR_zT_00B7340D_FN_zT_072B53A6_Modu
#define ZIG_FNPTR_zT_00B7340D_FN_zT_072B53A6_Modu
#endif /* ZIG_FNPTR_zT_00B7340D_FN_zT_072B53A6_Modu */
#ifndef ZIG_FNPTR_zT_2B3747E1_FN_void_zT_072B53A6
#define ZIG_FNPTR_zT_2B3747E1_FN_void_zT_072B53A6
#endif /* ZIG_FNPTR_zT_2B3747E1_FN_void_zT_072B53A6 */
#ifndef ZIG_FNPTR_zT_3F6781AA_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_3F6781AA_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_3F6781AA_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_7269700F_FN_zT_DDCD424B_Slic
#define ZIG_FNPTR_zT_7269700F_FN_zT_DDCD424B_Slic
#endif /* ZIG_FNPTR_zT_7269700F_FN_zT_DDCD424B_Slic */
#ifndef ZIG_FNPTR_zT_0A2B63CD_FN_void_zT_072B53A6
#define ZIG_FNPTR_zT_0A2B63CD_FN_void_zT_072B53A6
#endif /* ZIG_FNPTR_zT_0A2B63CD_FN_void_zT_072B53A6 */
#ifndef ZIG_FNPTR_zT_BB3D0731_FN_void_zT_072B53A6
#define ZIG_FNPTR_zT_BB3D0731_FN_void_zT_072B53A6
#endif /* ZIG_FNPTR_zT_BB3D0731_FN_void_zT_072B53A6 */
#ifndef ZIG_FNPTR_zT_123833CA_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_123833CA_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_123833CA_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_7ED0AFE9_FN_void_zT_D21A8776
#define ZIG_FNPTR_zT_7ED0AFE9_FN_void_zT_D21A8776
#endif /* ZIG_FNPTR_zT_7ED0AFE9_FN_void_zT_D21A8776 */
#ifndef ZIG_FNPTR_zT_34CB0028_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_34CB0028_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_34CB0028_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_AEA506C8_FN_void_zT_D21A8776
#define ZIG_FNPTR_zT_AEA506C8_FN_void_zT_D21A8776
#endif /* ZIG_FNPTR_zT_AEA506C8_FN_void_zT_D21A8776 */
#ifndef ZIG_FNPTR_zT_09125F8D_FN_void_zT_072B53A6
#define ZIG_FNPTR_zT_09125F8D_FN_void_zT_072B53A6
#endif /* ZIG_FNPTR_zT_09125F8D_FN_void_zT_072B53A6 */
#ifndef ZIG_FNPTR_zT_5658EE8C_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_5658EE8C_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_5658EE8C_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_3619A388_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_3619A388_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_3619A388_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_0ABB9BE8_FN_zT_47A5CDFB_Impo
#define ZIG_FNPTR_zT_0ABB9BE8_FN_zT_47A5CDFB_Impo
#endif /* ZIG_FNPTR_zT_0ABB9BE8_FN_zT_47A5CDFB_Impo */
#ifndef ZIG_FNPTR_zT_4BE681EC_FN_void_zT_47A5CDFB
#define ZIG_FNPTR_zT_4BE681EC_FN_void_zT_47A5CDFB
#endif /* ZIG_FNPTR_zT_4BE681EC_FN_void_zT_47A5CDFB */
#ifndef ZIG_FNPTR_zT_43B71227_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_43B71227_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_43B71227_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_7DD8788D_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_7DD8788D_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_7DD8788D_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_3D408685_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_3D408685_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_3D408685_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_47AF29CD_FN_void_zT_072B53A6
#define ZIG_FNPTR_zT_47AF29CD_FN_void_zT_072B53A6
#endif /* ZIG_FNPTR_zT_47AF29CD_FN_void_zT_072B53A6 */
#ifndef ZIG_FNPTR_zT_C74097E8_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_C74097E8_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_C74097E8_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_B5D91B8F_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_B5D91B8F_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_B5D91B8F_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_AAB68AE7_FN_void_zT_7E2F335A
#define ZIG_FNPTR_zT_AAB68AE7_FN_void_zT_7E2F335A
#endif /* ZIG_FNPTR_zT_AAB68AE7_FN_void_zT_7E2F335A */
#ifndef ZIG_FNPTR_zT_93FC3CEE_FN_int_zT_7E2F335A_
#define ZIG_FNPTR_zT_93FC3CEE_FN_int_zT_7E2F335A_
#endif /* ZIG_FNPTR_zT_93FC3CEE_FN_int_zT_7E2F335A_ */
#ifndef ZIG_FNPTR_zT_334E6F87_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_334E6F87_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_334E6F87_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_E52682F5_FN_void_zT_7E2F335A
#define ZIG_FNPTR_zT_E52682F5_FN_void_zT_7E2F335A
#endif /* ZIG_FNPTR_zT_E52682F5_FN_void_zT_7E2F335A */
#ifndef ZIG_FNPTR_zT_B43A8F1B_FN_void_zT_7E2F335A
#define ZIG_FNPTR_zT_B43A8F1B_FN_void_zT_7E2F335A
#endif /* ZIG_FNPTR_zT_B43A8F1B_FN_void_zT_7E2F335A */
#ifndef ZIG_FNPTR_zT_22B0F76D_FN_void_zT_7E2F335A
#define ZIG_FNPTR_zT_22B0F76D_FN_void_zT_7E2F335A
#endif /* ZIG_FNPTR_zT_22B0F76D_FN_void_zT_7E2F335A */
#ifndef ZIG_FNPTR_zT_BA2A37BF_FN_void_zT_7E2F335A
#define ZIG_FNPTR_zT_BA2A37BF_FN_void_zT_7E2F335A
#endif /* ZIG_FNPTR_zT_BA2A37BF_FN_void_zT_7E2F335A */
#ifndef ZIG_FNPTR_zT_77D8D05E_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_77D8D05E_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_77D8D05E_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_5125583B_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_5125583B_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_5125583B_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_2A591A0A_FN_zT_D0D475FB_Opt_
#define ZIG_FNPTR_zT_2A591A0A_FN_zT_D0D475FB_Opt_
#endif /* ZIG_FNPTR_zT_2A591A0A_FN_zT_D0D475FB_Opt_ */
#ifndef ZIG_FNPTR_zT_D0CE4A94_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_D0CE4A94_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_D0CE4A94_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_C9F389AC_FN_void_zT_7E2F335A
#define ZIG_FNPTR_zT_C9F389AC_FN_void_zT_7E2F335A
#endif /* ZIG_FNPTR_zT_C9F389AC_FN_void_zT_7E2F335A */
#ifndef ZIG_FNPTR_zT_6EAF87C4_FN_void_zT_7E2F335A
#define ZIG_FNPTR_zT_6EAF87C4_FN_void_zT_7E2F335A
#endif /* ZIG_FNPTR_zT_6EAF87C4_FN_void_zT_7E2F335A */
#ifndef ZIG_FNPTR_zT_DD07E1C3_FN_zT_060CD1EB_Symb
#define ZIG_FNPTR_zT_DD07E1C3_FN_zT_060CD1EB_Symb
#endif /* ZIG_FNPTR_zT_DD07E1C3_FN_zT_060CD1EB_Symb */
#ifndef ZIG_FNPTR_zT_A4A9DEAB_FN_void_zT_060CD1EB
#define ZIG_FNPTR_zT_A4A9DEAB_FN_void_zT_060CD1EB
#endif /* ZIG_FNPTR_zT_A4A9DEAB_FN_void_zT_060CD1EB */
#ifndef ZIG_FNPTR_zT_1E1744C7_FN_int_zT_060CD1EB_
#define ZIG_FNPTR_zT_1E1744C7_FN_int_zT_060CD1EB_
#endif /* ZIG_FNPTR_zT_1E1744C7_FN_int_zT_060CD1EB_ */
#ifndef ZIG_OPTIONAL_zT_D2761632_Opt_856
#define ZIG_OPTIONAL_zT_D2761632_Opt_856
typedef struct { zT_3A105EF1_Symbol* value; int has_value; } zT_D2761632_Opt_856;
#endif /* ZIG_OPTIONAL_zT_D2761632_Opt_856 */
#ifndef ZIG_FNPTR_zT_91DF7B25_FN_zT_D2761632_Opt_
#define ZIG_FNPTR_zT_91DF7B25_FN_zT_D2761632_Opt_
#endif /* ZIG_FNPTR_zT_91DF7B25_FN_zT_D2761632_Opt_ */
#ifndef ZIG_FNPTR_zT_55DA66CC_FN_void_zT_3D7259E2
#define ZIG_FNPTR_zT_55DA66CC_FN_void_zT_3D7259E2
#endif /* ZIG_FNPTR_zT_55DA66CC_FN_void_zT_3D7259E2 */
#ifndef ZIG_FNPTR_zT_19353D6E_FN_zT_3D7259E2_Symb
#define ZIG_FNPTR_zT_19353D6E_FN_zT_3D7259E2_Symb
#endif /* ZIG_FNPTR_zT_19353D6E_FN_zT_3D7259E2_Symb */
#ifndef ZIG_FNPTR_zT_A29C3A02_FN_zT_060CD1EB_Symb
#define ZIG_FNPTR_zT_A29C3A02_FN_zT_060CD1EB_Symb
#endif /* ZIG_FNPTR_zT_A29C3A02_FN_zT_060CD1EB_Symb */
#ifndef ZIG_FNPTR_zT_D81E0C57_FN_int_zT_3A105EF1_
#define ZIG_FNPTR_zT_D81E0C57_FN_int_zT_3A105EF1_
#endif /* ZIG_FNPTR_zT_D81E0C57_FN_int_zT_3A105EF1_ */
#ifndef ZIG_FNPTR_zT_85CA9D96_FN_zT_D2761632_Opt_
#define ZIG_FNPTR_zT_85CA9D96_FN_zT_D2761632_Opt_
#endif /* ZIG_FNPTR_zT_85CA9D96_FN_zT_D2761632_Opt_ */
#ifndef ZIG_FNPTR_zT_3377B5D0_FN_void_unsigned_in
#define ZIG_FNPTR_zT_3377B5D0_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_3377B5D0_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_74B627B5_FN_void_unsigned_ch
#define ZIG_FNPTR_zT_74B627B5_FN_void_unsigned_ch
#endif /* ZIG_FNPTR_zT_74B627B5_FN_void_unsigned_ch */
#ifndef ZIG_FNPTR_zT_AD43A6A7_FN_void_unsigned_ch
#define ZIG_FNPTR_zT_AD43A6A7_FN_void_unsigned_ch
#endif /* ZIG_FNPTR_zT_AD43A6A7_FN_void_unsigned_ch */
#ifndef ZIG_FNPTR_zT_81759F04_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_81759F04_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_81759F04_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_EFE3D6D5_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_EFE3D6D5_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_EFE3D6D5_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_8C98F367_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_8C98F367_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_8C98F367_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_25B97B09_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_25B97B09_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_25B97B09_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_AF7142DA_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_AF7142DA_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_AF7142DA_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_AE0831D1_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_AE0831D1_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_AE0831D1_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_251665AE_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_251665AE_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_251665AE_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_0C6E25F6_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_0C6E25F6_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_0C6E25F6_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_81184C06_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_81184C06_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_81184C06_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_0276B9A8_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_0276B9A8_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_0276B9A8_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_62A3B218_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_62A3B218_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_62A3B218_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_FD32F1FA_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_FD32F1FA_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_FD32F1FA_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_A3455244_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_A3455244_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_A3455244_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_871B681A_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_871B681A_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_871B681A_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_1F624FD7_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_1F624FD7_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_1F624FD7_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_3F1A1FF1_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_3F1A1FF1_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_3F1A1FF1_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_EA90EB7A_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_EA90EB7A_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_EA90EB7A_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_2C3095B9_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_2C3095B9_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_2C3095B9_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_0FF2C32B_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_0FF2C32B_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_0FF2C32B_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_610EE08C_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_610EE08C_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_610EE08C_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_9D364DEE_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_9D364DEE_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_9D364DEE_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_0581FAE9_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_0581FAE9_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_0581FAE9_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_82473703_FN_unsigned_int_uns
#define ZIG_FNPTR_zT_82473703_FN_unsigned_int_uns
#endif /* ZIG_FNPTR_zT_82473703_FN_unsigned_int_uns */
#ifndef ZIG_FNPTR_zT_B8BD6B05_FN_void_unsigned_ch
#define ZIG_FNPTR_zT_B8BD6B05_FN_void_unsigned_ch
#endif /* ZIG_FNPTR_zT_B8BD6B05_FN_void_unsigned_ch */
#ifndef ZIG_FNPTR_zT_FF6B0FD6_FN_zT_338B7C76_Type
#define ZIG_FNPTR_zT_FF6B0FD6_FN_zT_338B7C76_Type
#endif /* ZIG_FNPTR_zT_FF6B0FD6_FN_zT_338B7C76_Type */
#ifndef ZIG_FNPTR_zT_745C352D_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_745C352D_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_745C352D_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_0CE16CFC_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_0CE16CFC_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_0CE16CFC_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_420886B7_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_420886B7_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_420886B7_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_5932B6D9_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_5932B6D9_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_5932B6D9_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_C518C18D_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_C518C18D_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_C518C18D_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_82C4EEDF_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_82C4EEDF_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_82C4EEDF_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_94BA05E8_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_94BA05E8_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_94BA05E8_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_66666F57_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_66666F57_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_66666F57_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_133C9648_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_133C9648_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_133C9648_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_BA773B70_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_BA773B70_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_BA773B70_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_FA9581F2_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_FA9581F2_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_FA9581F2_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_1650E4FB_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_1650E4FB_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_1650E4FB_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_DCF27A05_FN_int_zT_338B7C76_
#define ZIG_FNPTR_zT_DCF27A05_FN_int_zT_338B7C76_
#endif /* ZIG_FNPTR_zT_DCF27A05_FN_int_zT_338B7C76_ */
#ifndef ZIG_FNPTR_zT_F39855A6_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_F39855A6_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_F39855A6_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_43AB2D09_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_43AB2D09_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_43AB2D09_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_B47BCA99_FN_int_zT_33EF6BFB_
#define ZIG_FNPTR_zT_B47BCA99_FN_int_zT_33EF6BFB_
#endif /* ZIG_FNPTR_zT_B47BCA99_FN_int_zT_33EF6BFB_ */
#ifndef ZIG_FNPTR_zT_F1E0DBBB_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_F1E0DBBB_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_F1E0DBBB_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_SLICE_zT_BF2E90D8_Slice_zT_2DF01B61_F
#define ZIG_SLICE_zT_BF2E90D8_Slice_zT_2DF01B61_F
typedef struct { zT_2DF01B61_FieldEntry* ptr; unsigned int len; } zT_BF2E90D8_Slice_zT_2DF01B61_F;
#endif /* ZIG_SLICE_zT_BF2E90D8_Slice_zT_2DF01B61_F */
#ifndef ZIG_FNPTR_zT_6FAFBD77_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_6FAFBD77_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_6FAFBD77_FN_void_zT_338B7C76 */
#ifndef ZIG_SLICE_zT_BCF34E4D_Slice_zT_E276DDD0_P
#define ZIG_SLICE_zT_BCF34E4D_Slice_zT_E276DDD0_P
typedef struct { zT_E276DDD0_PackedBitField* ptr; unsigned int len; } zT_BCF34E4D_Slice_zT_E276DDD0_P;
#endif /* ZIG_SLICE_zT_BCF34E4D_Slice_zT_E276DDD0_P */
#ifndef ZIG_FNPTR_zT_94F9402F_FN_int_zT_338B7C76_
#define ZIG_FNPTR_zT_94F9402F_FN_int_zT_338B7C76_
#endif /* ZIG_FNPTR_zT_94F9402F_FN_int_zT_338B7C76_ */
#ifndef ZIG_FNPTR_zT_4C1522A4_FN_int_unsigned_cha
#define ZIG_FNPTR_zT_4C1522A4_FN_int_unsigned_cha
#endif /* ZIG_FNPTR_zT_4C1522A4_FN_int_unsigned_cha */
#ifndef ZIG_FNPTR_zT_810A4777_FN_int_zT_338B7C76_
#define ZIG_FNPTR_zT_810A4777_FN_int_zT_338B7C76_
#endif /* ZIG_FNPTR_zT_810A4777_FN_int_zT_338B7C76_ */
#ifndef ZIG_FNPTR_zT_F95339B5_FN_int_zT_C69B2266_
#define ZIG_FNPTR_zT_F95339B5_FN_int_zT_C69B2266_
#endif /* ZIG_FNPTR_zT_F95339B5_FN_int_zT_C69B2266_ */
#ifndef ZIG_FNPTR_zT_3039CBD5_FN_zT_63BE4FF5_Buff
#define ZIG_FNPTR_zT_3039CBD5_FN_zT_63BE4FF5_Buff
#endif /* ZIG_FNPTR_zT_3039CBD5_FN_zT_63BE4FF5_Buff */
#ifndef ZIG_FNPTR_zT_BDBD4FC7_FN_zT_63BE4FF5_Buff
#define ZIG_FNPTR_zT_BDBD4FC7_FN_zT_63BE4FF5_Buff
#endif /* ZIG_FNPTR_zT_BDBD4FC7_FN_zT_63BE4FF5_Buff */
#ifndef ZIG_FNPTR_zT_D7FA39CB_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_D7FA39CB_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_D7FA39CB_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_38C39FF3_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_38C39FF3_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_38C39FF3_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_3D478938_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_3D478938_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_3D478938_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_EE0E3865_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_EE0E3865_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_EE0E3865_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_94306E27_FN_void_zT_8F083A69
#define ZIG_FNPTR_zT_94306E27_FN_void_zT_8F083A69
#endif /* ZIG_FNPTR_zT_94306E27_FN_void_zT_8F083A69 */
#ifndef ZIG_FNPTR_zT_2EF6560E_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_2EF6560E_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_2EF6560E_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_0E0608A0_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_0E0608A0_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_0E0608A0_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_9D207940_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_9D207940_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_9D207940_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_BC01CA69_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_BC01CA69_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_BC01CA69_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_31532D83_FN_int_zT_72C4E2ED_
#define ZIG_FNPTR_zT_31532D83_FN_int_zT_72C4E2ED_
#endif /* ZIG_FNPTR_zT_31532D83_FN_int_zT_72C4E2ED_ */
#ifndef ZIG_FNPTR_zT_154E079D_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_154E079D_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_154E079D_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_2E9C2469_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_2E9C2469_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_2E9C2469_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_B10F327B_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_B10F327B_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_B10F327B_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_56F9B292_FN_void_zT_CEC2984A
#define ZIG_FNPTR_zT_56F9B292_FN_void_zT_CEC2984A
#endif /* ZIG_FNPTR_zT_56F9B292_FN_void_zT_CEC2984A */
#ifndef ZIG_FNPTR_zT_014EFC8A_FN_zT_CEC2984A_Name
#define ZIG_FNPTR_zT_014EFC8A_FN_zT_CEC2984A_Name
#endif /* ZIG_FNPTR_zT_014EFC8A_FN_zT_CEC2984A_Name */
#ifndef ZIG_FNPTR_zT_10BF3486_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_10BF3486_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_10BF3486_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_36742814_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_36742814_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_36742814_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_247C95F2_FN_zT_72C4E2ED_C89E
#define ZIG_FNPTR_zT_247C95F2_FN_zT_72C4E2ED_C89E
#endif /* ZIG_FNPTR_zT_247C95F2_FN_zT_72C4E2ED_C89E */
#ifndef ZIG_FNPTR_zT_FF973B53_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_FF973B53_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_FF973B53_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_36F91A4B_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_36F91A4B_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_36F91A4B_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_532C2107_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_532C2107_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_532C2107_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_E9BB3DA2_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_E9BB3DA2_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_E9BB3DA2_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_1033C809_FN_int_zT_338B7C76_
#define ZIG_FNPTR_zT_1033C809_FN_int_zT_338B7C76_
#endif /* ZIG_FNPTR_zT_1033C809_FN_int_zT_338B7C76_ */
#ifndef ZIG_FNPTR_zT_45E1BA67_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_45E1BA67_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_45E1BA67_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_0619F64A_FN_unsigned_int__zT
#define ZIG_FNPTR_zT_0619F64A_FN_unsigned_int__zT
#endif /* ZIG_FNPTR_zT_0619F64A_FN_unsigned_int__zT */
#ifndef ZIG_FNPTR_zT_8FAFAB0D_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_8FAFAB0D_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_8FAFAB0D_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_F22FCAA0_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_F22FCAA0_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_F22FCAA0_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_ECF5DD57_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_ECF5DD57_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_ECF5DD57_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_84C28132_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_84C28132_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_84C28132_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_FD678D86_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_FD678D86_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_FD678D86_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_55049FB2_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_55049FB2_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_55049FB2_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_230E9E89_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_230E9E89_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_230E9E89_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_11CB2E9A_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_11CB2E9A_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_11CB2E9A_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_71CB6516_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_71CB6516_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_71CB6516_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_D451ADF1_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_D451ADF1_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_D451ADF1_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_238454B4_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_238454B4_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_238454B4_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_0AB60133_FN_zT_BBC23664_LirF
#define ZIG_FNPTR_zT_0AB60133_FN_zT_BBC23664_LirF
#endif /* ZIG_FNPTR_zT_0AB60133_FN_zT_BBC23664_LirF */
#ifndef ZIG_FNPTR_zT_B6B5607C_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_B6B5607C_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_B6B5607C_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_B3D347E7_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_B3D347E7_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_B3D347E7_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_7A40DE15_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_7A40DE15_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_7A40DE15_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_468D4016_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_468D4016_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_468D4016_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_4DD9FBF5_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_4DD9FBF5_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_4DD9FBF5_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_5A398DA2_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_5A398DA2_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_5A398DA2_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_CC1D2BEF_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_CC1D2BEF_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_CC1D2BEF_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_176927B6_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_176927B6_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_176927B6_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_3036A981_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_3036A981_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_3036A981_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_E19C0A6B_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_E19C0A6B_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_E19C0A6B_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_2E42B21F_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_2E42B21F_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_2E42B21F_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_3AA55A96_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_3AA55A96_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_3AA55A96_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_827B1467_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_827B1467_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_827B1467_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_60AD1B69_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_60AD1B69_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_60AD1B69_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_1B0E5225_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_1B0E5225_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_1B0E5225_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_32C4D99D_FN_signed_char_zT_3
#define ZIG_FNPTR_zT_32C4D99D_FN_signed_char_zT_3
#endif /* ZIG_FNPTR_zT_32C4D99D_FN_signed_char_zT_3 */
#ifndef ZIG_FNPTR_zT_4CE2FD31_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_4CE2FD31_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_4CE2FD31_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_BAA5E2D7_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_BAA5E2D7_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_BAA5E2D7_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_38D75701_FN_int_zT_72C4E2ED_
#define ZIG_FNPTR_zT_38D75701_FN_int_zT_72C4E2ED_
#endif /* ZIG_FNPTR_zT_38D75701_FN_int_zT_72C4E2ED_ */
#ifndef ZIG_FNPTR_zT_37C9D5B3_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_37C9D5B3_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_37C9D5B3_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_1BB08B7D_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_1BB08B7D_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_1BB08B7D_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_428EB743_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_428EB743_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_428EB743_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_B90F3BFB_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_B90F3BFB_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_B90F3BFB_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_62814F88_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_62814F88_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_62814F88_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_D7CA2499_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_D7CA2499_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_D7CA2499_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_53ADE49C_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_53ADE49C_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_53ADE49C_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_401CE6C3_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_401CE6C3_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_401CE6C3_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_42BC4C26_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_42BC4C26_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_42BC4C26_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_8C223FA6_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_8C223FA6_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_8C223FA6_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_DB9C00F9_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_DB9C00F9_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_DB9C00F9_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_0C147E9E_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_0C147E9E_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_0C147E9E_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_1819AEEF_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_1819AEEF_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_1819AEEF_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_5EB84AAC_FN_void_unsigned_in
#define ZIG_FNPTR_zT_5EB84AAC_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_5EB84AAC_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_04B9CA29_FN_void_unsigned_in
#define ZIG_FNPTR_zT_04B9CA29_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_04B9CA29_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_CC6B4F2A_FN_int_zT_338B7C76_
#define ZIG_FNPTR_zT_CC6B4F2A_FN_int_zT_338B7C76_
#endif /* ZIG_FNPTR_zT_CC6B4F2A_FN_int_zT_338B7C76_ */
#ifndef ZIG_FNPTR_zT_DD75F67E_FN_int_zT_338B7C76_
#define ZIG_FNPTR_zT_DD75F67E_FN_int_zT_338B7C76_
#endif /* ZIG_FNPTR_zT_DD75F67E_FN_int_zT_338B7C76_ */
#ifndef ZIG_FNPTR_zT_46431260_FN_void_zT_BBC23664
#define ZIG_FNPTR_zT_46431260_FN_void_zT_BBC23664
#endif /* ZIG_FNPTR_zT_46431260_FN_void_zT_BBC23664 */
#ifndef ZIG_FNPTR_zT_1531D429_FN_int_zT_338B7C76_
#define ZIG_FNPTR_zT_1531D429_FN_int_zT_338B7C76_
#endif /* ZIG_FNPTR_zT_1531D429_FN_int_zT_338B7C76_ */
#ifndef ZIG_FNPTR_zT_C8C24ACE_FN_void_zT_BBC23664
#define ZIG_FNPTR_zT_C8C24ACE_FN_void_zT_BBC23664
#endif /* ZIG_FNPTR_zT_C8C24ACE_FN_void_zT_BBC23664 */
#ifndef ZIG_FNPTR_zT_BAF21B05_FN_unsigned_int_uns
#define ZIG_FNPTR_zT_BAF21B05_FN_unsigned_int_uns
#endif /* ZIG_FNPTR_zT_BAF21B05_FN_unsigned_int_uns */
#ifndef ZIG_FNPTR_zT_6605D351_FN_void_unsigned_in
#define ZIG_FNPTR_zT_6605D351_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_6605D351_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_D5FBB52F_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_D5FBB52F_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_D5FBB52F_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_5CE12BB2_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_5CE12BB2_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_5CE12BB2_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_F3A7F928_FN_void_zT_72C4E2ED
#define ZIG_FNPTR_zT_F3A7F928_FN_void_zT_72C4E2ED
#endif /* ZIG_FNPTR_zT_F3A7F928_FN_void_zT_72C4E2ED */
#ifndef ZIG_FNPTR_zT_7BBDF340_FN_zT_A528929E_Defe
#define ZIG_FNPTR_zT_7BBDF340_FN_zT_A528929E_Defe
#endif /* ZIG_FNPTR_zT_7BBDF340_FN_zT_A528929E_Defe */
#ifndef ZIG_FNPTR_zT_2EB2F950_FN_void_zT_A528929E
#define ZIG_FNPTR_zT_2EB2F950_FN_void_zT_A528929E
#endif /* ZIG_FNPTR_zT_2EB2F950_FN_void_zT_A528929E */
#ifndef ZIG_FNPTR_zT_7A295148_FN_void_zT_A528929E
#define ZIG_FNPTR_zT_7A295148_FN_void_zT_A528929E
#endif /* ZIG_FNPTR_zT_7A295148_FN_void_zT_A528929E */
#ifndef ZIG_SLICE_zT_D51BEFA9_Slice_zT_CE6A1A99_D
#define ZIG_SLICE_zT_D51BEFA9_Slice_zT_CE6A1A99_D
typedef struct { zT_CE6A1A99_DeferAction* ptr; unsigned int len; } zT_D51BEFA9_Slice_zT_CE6A1A99_D;
#endif /* ZIG_SLICE_zT_D51BEFA9_Slice_zT_CE6A1A99_D */
#ifndef ZIG_FNPTR_zT_DA916D3D_FN_zT_D51BEFA9_Slic
#define ZIG_FNPTR_zT_DA916D3D_FN_zT_D51BEFA9_Slic
#endif /* ZIG_FNPTR_zT_DA916D3D_FN_zT_D51BEFA9_Slic */
#ifndef ZIG_FNPTR_zT_FF9EFC3A_FN_zT_5819C854_Loop
#define ZIG_FNPTR_zT_FF9EFC3A_FN_zT_5819C854_Loop
#endif /* ZIG_FNPTR_zT_FF9EFC3A_FN_zT_5819C854_Loop */
#ifndef ZIG_FNPTR_zT_CE2C617A_FN_void_zT_5819C854
#define ZIG_FNPTR_zT_CE2C617A_FN_void_zT_5819C854
#endif /* ZIG_FNPTR_zT_CE2C617A_FN_void_zT_5819C854 */
#ifndef ZIG_FNPTR_zT_3439A93E_FN_void_zT_5819C854
#define ZIG_FNPTR_zT_3439A93E_FN_void_zT_5819C854
#endif /* ZIG_FNPTR_zT_3439A93E_FN_void_zT_5819C854 */
#ifndef ZIG_SLICE_zT_D170EC13_Slice_zT_78074DEF_L
#define ZIG_SLICE_zT_D170EC13_Slice_zT_78074DEF_L
typedef struct { zT_78074DEF_LoopInfo* ptr; unsigned int len; } zT_D170EC13_Slice_zT_78074DEF_L;
#endif /* ZIG_SLICE_zT_D170EC13_Slice_zT_78074DEF_L */
#ifndef ZIG_FNPTR_zT_90BEB998_FN_zT_D170EC13_Slic
#define ZIG_FNPTR_zT_90BEB998_FN_zT_D170EC13_Slic
#endif /* ZIG_FNPTR_zT_90BEB998_FN_zT_D170EC13_Slic */
#ifndef ZIG_FNPTR_zT_D3126A12_FN_zT_347CB10E_Swit
#define ZIG_FNPTR_zT_D3126A12_FN_zT_347CB10E_Swit
#endif /* ZIG_FNPTR_zT_D3126A12_FN_zT_347CB10E_Swit */
#ifndef ZIG_FNPTR_zT_428FDE1A_FN_void_zT_347CB10E
#define ZIG_FNPTR_zT_428FDE1A_FN_void_zT_347CB10E
#endif /* ZIG_FNPTR_zT_428FDE1A_FN_void_zT_347CB10E */
#ifndef ZIG_FNPTR_zT_198F6E4D_FN_void_zT_347CB10E
#define ZIG_FNPTR_zT_198F6E4D_FN_void_zT_347CB10E
#endif /* ZIG_FNPTR_zT_198F6E4D_FN_void_zT_347CB10E */
#ifndef ZIG_SLICE_zT_CDB18CF4_Slice_zT_6996DA09_S
#define ZIG_SLICE_zT_CDB18CF4_Slice_zT_6996DA09_S
typedef struct { zT_6996DA09_SwitchInfo* ptr; unsigned int len; } zT_CDB18CF4_Slice_zT_6996DA09_S;
#endif /* ZIG_SLICE_zT_CDB18CF4_Slice_zT_6996DA09_S */
#ifndef ZIG_FNPTR_zT_4526469D_FN_zT_CDB18CF4_Slic
#define ZIG_FNPTR_zT_4526469D_FN_zT_CDB18CF4_Slic
#endif /* ZIG_FNPTR_zT_4526469D_FN_zT_CDB18CF4_Slic */
#ifndef ZIG_FNPTR_zT_6EEE195C_FN_zT_2F2F63D8_Scop
#define ZIG_FNPTR_zT_6EEE195C_FN_zT_2F2F63D8_Scop
#endif /* ZIG_FNPTR_zT_6EEE195C_FN_zT_2F2F63D8_Scop */
#ifndef ZIG_FNPTR_zT_5009A2CA_FN_void_zT_2F2F63D8
#define ZIG_FNPTR_zT_5009A2CA_FN_void_zT_2F2F63D8
#endif /* ZIG_FNPTR_zT_5009A2CA_FN_void_zT_2F2F63D8 */
#ifndef ZIG_FNPTR_zT_6318A3BD_FN_void_zT_2F2F63D8
#define ZIG_FNPTR_zT_6318A3BD_FN_void_zT_2F2F63D8
#endif /* ZIG_FNPTR_zT_6318A3BD_FN_void_zT_2F2F63D8 */
#ifndef ZIG_FNPTR_zT_85282E45_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_85282E45_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_85282E45_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_A343DDB7_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_A343DDB7_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_A343DDB7_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_37347F66_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_37347F66_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_37347F66_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_C387BF87_FN_zT_02EB57B2_LirL
#define ZIG_FNPTR_zT_C387BF87_FN_zT_02EB57B2_LirL
#endif /* ZIG_FNPTR_zT_C387BF87_FN_zT_02EB57B2_LirL */
#ifndef ZIG_FNPTR_zT_C81DFB09_FN_void_zT_1CF28CA3
#define ZIG_FNPTR_zT_C81DFB09_FN_void_zT_1CF28CA3
#endif /* ZIG_FNPTR_zT_C81DFB09_FN_void_zT_1CF28CA3 */
#ifndef ZIG_FNPTR_zT_4B73F4CF_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_4B73F4CF_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_4B73F4CF_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_29E4DA12_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_29E4DA12_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_29E4DA12_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_B254DC96_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_B254DC96_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_B254DC96_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_A5D438E0_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_A5D438E0_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_A5D438E0_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_F61F80D9_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_F61F80D9_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_F61F80D9_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_48044C79_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_48044C79_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_48044C79_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_9B073F02_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_9B073F02_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_9B073F02_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_593F51B3_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_593F51B3_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_593F51B3_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_D4C1AFE1_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_D4C1AFE1_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_D4C1AFE1_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_47B3CD62_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_47B3CD62_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_47B3CD62_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_BF4EAF7A_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_BF4EAF7A_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_BF4EAF7A_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_995D7E32_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_995D7E32_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_995D7E32_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_9ED34C49_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_9ED34C49_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_9ED34C49_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_94534332_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_94534332_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_94534332_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_36993078_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_36993078_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_36993078_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_27164BF1_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_27164BF1_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_27164BF1_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_F5051D9D_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_F5051D9D_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_F5051D9D_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_6DC5FE78_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_6DC5FE78_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_6DC5FE78_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_C9379D18_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_C9379D18_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_C9379D18_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_251E3ED2_FN_zT_64DB3977_SrcI
#define ZIG_FNPTR_zT_251E3ED2_FN_zT_64DB3977_SrcI
#endif /* ZIG_FNPTR_zT_251E3ED2_FN_zT_64DB3977_SrcI */
#ifndef ZIG_FNPTR_zT_46091072_FN_zT_64DB3977_SrcI
#define ZIG_FNPTR_zT_46091072_FN_zT_64DB3977_SrcI
#endif /* ZIG_FNPTR_zT_46091072_FN_zT_64DB3977_SrcI */
#ifndef ZIG_FNPTR_zT_39732762_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_39732762_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_39732762_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_512D6A69_FN_zT_CED6B16C_Opt_
#define ZIG_FNPTR_zT_512D6A69_FN_zT_CED6B16C_Opt_
#endif /* ZIG_FNPTR_zT_512D6A69_FN_zT_CED6B16C_Opt_ */
#ifndef ZIG_FNPTR_zT_E9D05241_FN_int_zT_02EB57B2_
#define ZIG_FNPTR_zT_E9D05241_FN_int_zT_02EB57B2_
#endif /* ZIG_FNPTR_zT_E9D05241_FN_int_zT_02EB57B2_ */
#ifndef ZIG_FNPTR_zT_5A21A5AF_FN_int_zT_02EB57B2_
#define ZIG_FNPTR_zT_5A21A5AF_FN_int_zT_02EB57B2_
#endif /* ZIG_FNPTR_zT_5A21A5AF_FN_int_zT_02EB57B2_ */
#ifndef ZIG_FNPTR_zT_ECB7789C_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_ECB7789C_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_ECB7789C_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_05AD828D_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_05AD828D_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_05AD828D_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_F2ED0F04_FN_int_zT_02EB57B2_
#define ZIG_FNPTR_zT_F2ED0F04_FN_int_zT_02EB57B2_
#endif /* ZIG_FNPTR_zT_F2ED0F04_FN_int_zT_02EB57B2_ */
#ifndef ZIG_FNPTR_zT_D87D1A86_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_D87D1A86_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_D87D1A86_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_3E12AA53_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_3E12AA53_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_3E12AA53_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_E4875EAA_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_E4875EAA_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_E4875EAA_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_6D41AF73_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_6D41AF73_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_6D41AF73_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_D2454AC2_FN_zT_D0D6B492_Opt_
#define ZIG_FNPTR_zT_D2454AC2_FN_zT_D0D6B492_Opt_
#endif /* ZIG_FNPTR_zT_D2454AC2_FN_zT_D0D6B492_Opt_ */
#ifndef ZIG_FNPTR_zT_7DC3F1D9_FN_void_zT_02EB57B2
#define ZIG_FNPTR_zT_7DC3F1D9_FN_void_zT_02EB57B2
#endif /* ZIG_FNPTR_zT_7DC3F1D9_FN_void_zT_02EB57B2 */
#ifndef ZIG_FNPTR_zT_E4C6A15F_FN_zT_BBC23664_LirF
#define ZIG_FNPTR_zT_E4C6A15F_FN_zT_BBC23664_LirF
#endif /* ZIG_FNPTR_zT_E4C6A15F_FN_zT_BBC23664_LirF */
#ifndef ZIG_FNPTR_zT_7A818371_FN_zT_BBC23664_LirF
#define ZIG_FNPTR_zT_7A818371_FN_zT_BBC23664_LirF
#endif /* ZIG_FNPTR_zT_7A818371_FN_zT_BBC23664_LirF */
#ifndef ZIG_FNPTR_zT_C6E6010B_FN_zT_AC00B5F6_LirS
#define ZIG_FNPTR_zT_C6E6010B_FN_zT_AC00B5F6_LirS
#endif /* ZIG_FNPTR_zT_C6E6010B_FN_zT_AC00B5F6_LirS */
#ifndef ZIG_FNPTR_zT_56181F8F_FN_void_zT_AC00B5F6
#define ZIG_FNPTR_zT_56181F8F_FN_void_zT_AC00B5F6
#endif /* ZIG_FNPTR_zT_56181F8F_FN_void_zT_AC00B5F6 */
#ifndef ZIG_FNPTR_zT_367028BF_FN_void_zT_AC00B5F6
#define ZIG_FNPTR_zT_367028BF_FN_void_zT_AC00B5F6
#endif /* ZIG_FNPTR_zT_367028BF_FN_void_zT_AC00B5F6 */
#ifndef ZIG_SLICE_zT_99DE57BF_Slice_zT_A8A5B231_L
#define ZIG_SLICE_zT_99DE57BF_Slice_zT_A8A5B231_L
typedef struct { zT_A8A5B231_LirSideEntry* ptr; unsigned int len; } zT_99DE57BF_Slice_zT_A8A5B231_L;
#endif /* ZIG_SLICE_zT_99DE57BF_Slice_zT_A8A5B231_L */
#ifndef ZIG_FNPTR_zT_AFA0A786_FN_zT_99DE57BF_Slic
#define ZIG_FNPTR_zT_AFA0A786_FN_zT_99DE57BF_Slic
#endif /* ZIG_FNPTR_zT_AFA0A786_FN_zT_99DE57BF_Slic */
#ifndef ZIG_FNPTR_zT_05743AB8_FN_zT_DAE4631D_LirI
#define ZIG_FNPTR_zT_05743AB8_FN_zT_DAE4631D_LirI
#endif /* ZIG_FNPTR_zT_05743AB8_FN_zT_DAE4631D_LirI */
#ifndef ZIG_FNPTR_zT_1892FA9A_FN_void_zT_DAE4631D
#define ZIG_FNPTR_zT_1892FA9A_FN_void_zT_DAE4631D
#endif /* ZIG_FNPTR_zT_1892FA9A_FN_void_zT_DAE4631D */
#ifndef ZIG_FNPTR_zT_44584727_FN_void_zT_DAE4631D
#define ZIG_FNPTR_zT_44584727_FN_void_zT_DAE4631D
#endif /* ZIG_FNPTR_zT_44584727_FN_void_zT_DAE4631D */
#ifndef ZIG_SLICE_zT_804A8058_Slice_zT_6BA597BC_L
#define ZIG_SLICE_zT_804A8058_Slice_zT_6BA597BC_L
typedef struct { zT_6BA597BC_LirInst* ptr; unsigned int len; } zT_804A8058_Slice_zT_6BA597BC_L;
#endif /* ZIG_SLICE_zT_804A8058_Slice_zT_6BA597BC_L */
#ifndef ZIG_FNPTR_zT_CC1B3DBE_FN_zT_804A8058_Slic
#define ZIG_FNPTR_zT_CC1B3DBE_FN_zT_804A8058_Slic
#endif /* ZIG_FNPTR_zT_CC1B3DBE_FN_zT_804A8058_Slic */
#ifndef ZIG_FNPTR_zT_F1078611_FN_zT_1CF28CA3_Basi
#define ZIG_FNPTR_zT_F1078611_FN_zT_1CF28CA3_Basi
#endif /* ZIG_FNPTR_zT_F1078611_FN_zT_1CF28CA3_Basi */
#ifndef ZIG_FNPTR_zT_951F59B6_FN_void_zT_1CF28CA3
#define ZIG_FNPTR_zT_951F59B6_FN_void_zT_1CF28CA3
#endif /* ZIG_FNPTR_zT_951F59B6_FN_void_zT_1CF28CA3 */
#ifndef ZIG_SLICE_zT_A12E931C_Slice_zT_88A68B1A_B
#define ZIG_SLICE_zT_A12E931C_Slice_zT_88A68B1A_B
typedef struct { zT_88A68B1A_BasicBlock* ptr; unsigned int len; } zT_A12E931C_Slice_zT_88A68B1A_B;
#endif /* ZIG_SLICE_zT_A12E931C_Slice_zT_88A68B1A_B */
#ifndef ZIG_FNPTR_zT_F722FECC_FN_zT_A12E931C_Slic
#define ZIG_FNPTR_zT_F722FECC_FN_zT_A12E931C_Slic
#endif /* ZIG_FNPTR_zT_F722FECC_FN_zT_A12E931C_Slic */
#ifndef ZIG_FNPTR_zT_948699EB_FN_zT_CFE23D0A_LirP
#define ZIG_FNPTR_zT_948699EB_FN_zT_CFE23D0A_LirP
#endif /* ZIG_FNPTR_zT_948699EB_FN_zT_CFE23D0A_LirP */
#ifndef ZIG_FNPTR_zT_B06A0FB3_FN_void_zT_CFE23D0A
#define ZIG_FNPTR_zT_B06A0FB3_FN_void_zT_CFE23D0A
#endif /* ZIG_FNPTR_zT_B06A0FB3_FN_void_zT_CFE23D0A */
#ifndef ZIG_FNPTR_zT_BE97619C_FN_void_zT_CFE23D0A
#define ZIG_FNPTR_zT_BE97619C_FN_void_zT_CFE23D0A
#endif /* ZIG_FNPTR_zT_BE97619C_FN_void_zT_CFE23D0A */
#ifndef ZIG_SLICE_zT_2F054080_Slice_zT_8779209D_L
#define ZIG_SLICE_zT_2F054080_Slice_zT_8779209D_L
typedef struct { zT_8779209D_LirParam* ptr; unsigned int len; } zT_2F054080_Slice_zT_8779209D_L;
#endif /* ZIG_SLICE_zT_2F054080_Slice_zT_8779209D_L */
#ifndef ZIG_FNPTR_zT_E416490F_FN_zT_2F054080_Slic
#define ZIG_FNPTR_zT_E416490F_FN_zT_2F054080_Slic
#endif /* ZIG_FNPTR_zT_E416490F_FN_zT_2F054080_Slic */
#ifndef ZIG_FNPTR_zT_204C3D31_FN_zT_5D72FBF8_Temp
#define ZIG_FNPTR_zT_204C3D31_FN_zT_5D72FBF8_Temp
#endif /* ZIG_FNPTR_zT_204C3D31_FN_zT_5D72FBF8_Temp */
#ifndef ZIG_FNPTR_zT_BB21790D_FN_void_zT_5D72FBF8
#define ZIG_FNPTR_zT_BB21790D_FN_void_zT_5D72FBF8
#endif /* ZIG_FNPTR_zT_BB21790D_FN_void_zT_5D72FBF8 */
#ifndef ZIG_FNPTR_zT_7B9B2B81_FN_void_zT_5D72FBF8
#define ZIG_FNPTR_zT_7B9B2B81_FN_void_zT_5D72FBF8
#endif /* ZIG_FNPTR_zT_7B9B2B81_FN_void_zT_5D72FBF8 */
#ifndef ZIG_SLICE_zT_732DFD13_Slice_zT_1937645B_T
#define ZIG_SLICE_zT_732DFD13_Slice_zT_1937645B_T
typedef struct { zT_1937645B_TempDecl* ptr; unsigned int len; } zT_732DFD13_Slice_zT_1937645B_T;
#endif /* ZIG_SLICE_zT_732DFD13_Slice_zT_1937645B_T */
#ifndef ZIG_FNPTR_zT_34598787_FN_zT_732DFD13_Slic
#define ZIG_FNPTR_zT_34598787_FN_zT_732DFD13_Slic
#endif /* ZIG_FNPTR_zT_34598787_FN_zT_732DFD13_Slic */
#ifndef ZIG_FNPTR_zT_A13FFF7D_FN_zT_9F514E82_Swit
#define ZIG_FNPTR_zT_A13FFF7D_FN_zT_9F514E82_Swit
#endif /* ZIG_FNPTR_zT_A13FFF7D_FN_zT_9F514E82_Swit */
#ifndef ZIG_FNPTR_zT_6C0E3179_FN_void_zT_9F514E82
#define ZIG_FNPTR_zT_6C0E3179_FN_void_zT_9F514E82
#endif /* ZIG_FNPTR_zT_6C0E3179_FN_void_zT_9F514E82 */
#ifndef ZIG_FNPTR_zT_E710FA90_FN_void_zT_9F514E82
#define ZIG_FNPTR_zT_E710FA90_FN_void_zT_9F514E82
#endif /* ZIG_FNPTR_zT_E710FA90_FN_void_zT_9F514E82 */
#ifndef ZIG_SLICE_zT_11D00852_Slice_zT_4BD97095_S
#define ZIG_SLICE_zT_11D00852_Slice_zT_4BD97095_S
typedef struct { zT_4BD97095_SwitchCase* ptr; unsigned int len; } zT_11D00852_Slice_zT_4BD97095_S;
#endif /* ZIG_SLICE_zT_11D00852_Slice_zT_4BD97095_S */
#ifndef ZIG_FNPTR_zT_997B5B52_FN_zT_11D00852_Slic
#define ZIG_FNPTR_zT_997B5B52_FN_zT_11D00852_Slic
#endif /* ZIG_FNPTR_zT_997B5B52_FN_zT_11D00852_Slic */
#ifndef ZIG_FNPTR_zT_84FFAB96_FN_zT_CA01C129_LirS
#define ZIG_FNPTR_zT_84FFAB96_FN_zT_CA01C129_LirS
#endif /* ZIG_FNPTR_zT_84FFAB96_FN_zT_CA01C129_LirS */
#ifndef ZIG_FNPTR_zT_C8FBBEF0_FN_void_zT_CA01C129
#define ZIG_FNPTR_zT_C8FBBEF0_FN_void_zT_CA01C129
#endif /* ZIG_FNPTR_zT_C8FBBEF0_FN_void_zT_CA01C129 */
#ifndef ZIG_FNPTR_zT_71620FAA_FN_void_zT_CA01C129
#define ZIG_FNPTR_zT_71620FAA_FN_void_zT_CA01C129
#endif /* ZIG_FNPTR_zT_71620FAA_FN_void_zT_CA01C129 */
#ifndef ZIG_SLICE_zT_E44058BB_Slice_zT_E7714190_L
#define ZIG_SLICE_zT_E44058BB_Slice_zT_E7714190_L
typedef struct { zT_E7714190_LirSlot* ptr; unsigned int len; } zT_E44058BB_Slice_zT_E7714190_L;
#endif /* ZIG_SLICE_zT_E44058BB_Slice_zT_E7714190_L */
#ifndef ZIG_FNPTR_zT_03899015_FN_zT_E44058BB_Slic
#define ZIG_FNPTR_zT_03899015_FN_zT_E44058BB_Slic
#endif /* ZIG_FNPTR_zT_03899015_FN_zT_E44058BB_Slic */
#ifndef ZIG_FNPTR_zT_61D8DC2A_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_61D8DC2A_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_61D8DC2A_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_9C71FB70_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_9C71FB70_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_9C71FB70_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_C679D0F6_FN_zT_3BFB1E70_Call
#define ZIG_FNPTR_zT_C679D0F6_FN_zT_3BFB1E70_Call
#endif /* ZIG_FNPTR_zT_C679D0F6_FN_zT_3BFB1E70_Call */
#ifndef ZIG_FNPTR_zT_DB5B51C8_FN_zT_0624AC1B_Tail
#define ZIG_FNPTR_zT_DB5B51C8_FN_zT_0624AC1B_Tail
#endif /* ZIG_FNPTR_zT_DB5B51C8_FN_zT_0624AC1B_Tail */
#ifndef ZIG_FNPTR_zT_3ED2BF38_FN_zT_E1A783EF_Glob
#define ZIG_FNPTR_zT_3ED2BF38_FN_zT_E1A783EF_Glob
#endif /* ZIG_FNPTR_zT_3ED2BF38_FN_zT_E1A783EF_Glob */
#ifndef ZIG_FNPTR_zT_A50EA8C0_FN_void_zT_E1A783EF
#define ZIG_FNPTR_zT_A50EA8C0_FN_void_zT_E1A783EF
#endif /* ZIG_FNPTR_zT_A50EA8C0_FN_void_zT_E1A783EF */
#ifndef ZIG_FNPTR_zT_F48CD515_FN_void_zT_E1A783EF
#define ZIG_FNPTR_zT_F48CD515_FN_void_zT_E1A783EF
#endif /* ZIG_FNPTR_zT_F48CD515_FN_void_zT_E1A783EF */
#ifndef ZIG_SLICE_zT_23133B1E_Slice_zT_54906056_M
#define ZIG_SLICE_zT_23133B1E_Slice_zT_54906056_M
typedef struct { zT_54906056_ModuleGlobalDecl* ptr; unsigned int len; } zT_23133B1E_Slice_zT_54906056_M;
#endif /* ZIG_SLICE_zT_23133B1E_Slice_zT_54906056_M */
#ifndef ZIG_FNPTR_zT_7AD1DB87_FN_zT_23133B1E_Slic
#define ZIG_FNPTR_zT_7AD1DB87_FN_zT_23133B1E_Slic
#endif /* ZIG_FNPTR_zT_7AD1DB87_FN_zT_23133B1E_Slic */
#ifndef ZIG_FNPTR_zT_0E680E78_FN_zT_7E7544E4_LirS
#define ZIG_FNPTR_zT_0E680E78_FN_zT_7E7544E4_LirS
#endif /* ZIG_FNPTR_zT_0E680E78_FN_zT_7E7544E4_LirS */
#ifndef ZIG_FNPTR_zT_1AD4CBDC_FN_void_zT_7E7544E4
#define ZIG_FNPTR_zT_1AD4CBDC_FN_void_zT_7E7544E4
#endif /* ZIG_FNPTR_zT_1AD4CBDC_FN_void_zT_7E7544E4 */
#ifndef ZIG_FNPTR_zT_9D48777E_FN_void_zT_7E7544E4
#define ZIG_FNPTR_zT_9D48777E_FN_void_zT_7E7544E4
#endif /* ZIG_FNPTR_zT_9D48777E_FN_void_zT_7E7544E4 */
#ifndef ZIG_FNPTR_zT_905E2E10_FN_void_zT_7E7544E4
#define ZIG_FNPTR_zT_905E2E10_FN_void_zT_7E7544E4
#endif /* ZIG_FNPTR_zT_905E2E10_FN_void_zT_7E7544E4 */
#ifndef ZIG_FNPTR_zT_334FF22A_FN_void_zT_7E7544E4
#define ZIG_FNPTR_zT_334FF22A_FN_void_zT_7E7544E4
#endif /* ZIG_FNPTR_zT_334FF22A_FN_void_zT_7E7544E4 */
#ifndef ZIG_FNPTR_zT_7E3BD6A1_FN_void_zT_7E7544E4
#define ZIG_FNPTR_zT_7E3BD6A1_FN_void_zT_7E7544E4
#endif /* ZIG_FNPTR_zT_7E3BD6A1_FN_void_zT_7E7544E4 */
#ifndef ZIG_FNPTR_zT_DC8425BE_FN_void_zT_7E7544E4
#define ZIG_FNPTR_zT_DC8425BE_FN_void_zT_7E7544E4
#endif /* ZIG_FNPTR_zT_DC8425BE_FN_void_zT_7E7544E4 */
#ifndef ZIG_FNPTR_zT_7903C57B_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_7903C57B_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_7903C57B_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_BC15B3BC_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_BC15B3BC_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_BC15B3BC_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_57E23295_FN_zT_E7714190_LirS
#define ZIG_FNPTR_zT_57E23295_FN_zT_E7714190_LirS
#endif /* ZIG_FNPTR_zT_57E23295_FN_zT_E7714190_LirS */
#ifndef ZIG_FNPTR_zT_FCB3A5E5_FN_zT_BBC23664_LirF
#define ZIG_FNPTR_zT_FCB3A5E5_FN_zT_BBC23664_LirF
#endif /* ZIG_FNPTR_zT_FCB3A5E5_FN_zT_BBC23664_LirF */
#ifndef ZIG_FNPTR_zT_27141A83_FN_zT_BBC23664_LirF
#define ZIG_FNPTR_zT_27141A83_FN_zT_BBC23664_LirF
#endif /* ZIG_FNPTR_zT_27141A83_FN_zT_BBC23664_LirF */
#ifndef ZIG_FNPTR_zT_7674B4FC_FN_zT_8EED1867_Reso
#define ZIG_FNPTR_zT_7674B4FC_FN_zT_8EED1867_Reso
#endif /* ZIG_FNPTR_zT_7674B4FC_FN_zT_8EED1867_Reso */
#ifndef ZIG_FNPTR_zT_E2A715BC_FN_void_zT_8EED1867
#define ZIG_FNPTR_zT_E2A715BC_FN_void_zT_8EED1867
#endif /* ZIG_FNPTR_zT_E2A715BC_FN_void_zT_8EED1867 */
#ifndef ZIG_FNPTR_zT_09BE1559_FN_unsigned_int_uns
#define ZIG_FNPTR_zT_09BE1559_FN_unsigned_int_uns
#endif /* ZIG_FNPTR_zT_09BE1559_FN_unsigned_int_uns */
#ifndef ZIG_FNPTR_zT_2BD95548_FN_void_zT_8EED1867
#define ZIG_FNPTR_zT_2BD95548_FN_void_zT_8EED1867
#endif /* ZIG_FNPTR_zT_2BD95548_FN_void_zT_8EED1867 */
#ifndef ZIG_FNPTR_zT_EC06BC04_FN_void_zT_8EED1867
#define ZIG_FNPTR_zT_EC06BC04_FN_void_zT_8EED1867
#endif /* ZIG_FNPTR_zT_EC06BC04_FN_void_zT_8EED1867 */
#ifndef ZIG_FNPTR_zT_A322C667_FN_unsigned_char__z
#define ZIG_FNPTR_zT_A322C667_FN_unsigned_char__z
#endif /* ZIG_FNPTR_zT_A322C667_FN_unsigned_char__z */
#ifndef ZIG_FNPTR_zT_D671CADF_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_D671CADF_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_D671CADF_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_249D502B_FN_unsigned_int_uns
#define ZIG_FNPTR_zT_249D502B_FN_unsigned_int_uns
#endif /* ZIG_FNPTR_zT_249D502B_FN_unsigned_int_uns */
#ifndef ZIG_FNPTR_zT_2C80C6DC_FN_void_unsigned_ch
#define ZIG_FNPTR_zT_2C80C6DC_FN_void_unsigned_ch
#endif /* ZIG_FNPTR_zT_2C80C6DC_FN_void_unsigned_ch */
#ifndef ZIG_FNPTR_zT_6201F088_FN_void_zT_8EED1867
#define ZIG_FNPTR_zT_6201F088_FN_void_zT_8EED1867
#endif /* ZIG_FNPTR_zT_6201F088_FN_void_zT_8EED1867 */
#ifndef ZIG_FNPTR_zT_A0FB32F1_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_A0FB32F1_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_A0FB32F1_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_86F1B5F9_FN_zT_21D3708C_U32T
#define ZIG_FNPTR_zT_86F1B5F9_FN_zT_21D3708C_U32T
#endif /* ZIG_FNPTR_zT_86F1B5F9_FN_zT_21D3708C_U32T */
#ifndef ZIG_FNPTR_zT_3B921C23_FN_zT_21D3708C_U32T
#define ZIG_FNPTR_zT_3B921C23_FN_zT_21D3708C_U32T
#endif /* ZIG_FNPTR_zT_3B921C23_FN_zT_21D3708C_U32T */
#ifndef ZIG_FNPTR_zT_35934718_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_35934718_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_35934718_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_2912D46F_FN_void_zT_21D3708C
#define ZIG_FNPTR_zT_2912D46F_FN_void_zT_21D3708C
#endif /* ZIG_FNPTR_zT_2912D46F_FN_void_zT_21D3708C */
#ifndef ZIG_FNPTR_zT_A8A51CE6_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_A8A51CE6_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_A8A51CE6_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_9A25262B_FN_void_zT_21D3708C
#define ZIG_FNPTR_zT_9A25262B_FN_void_zT_21D3708C
#endif /* ZIG_FNPTR_zT_9A25262B_FN_void_zT_21D3708C */
#ifndef ZIG_FNPTR_zT_1DE6AF68_FN_zT_A4CE86B7_U64T
#define ZIG_FNPTR_zT_1DE6AF68_FN_zT_A4CE86B7_U64T
#endif /* ZIG_FNPTR_zT_1DE6AF68_FN_zT_A4CE86B7_U64T */
#ifndef ZIG_FNPTR_zT_42102624_FN_zT_A4CE86B7_U64T
#define ZIG_FNPTR_zT_42102624_FN_zT_A4CE86B7_U64T
#endif /* ZIG_FNPTR_zT_42102624_FN_zT_A4CE86B7_U64T */
#ifndef ZIG_FNPTR_zT_B775C6E3_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_B775C6E3_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_B775C6E3_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_23BE94A0_FN_void_zT_A4CE86B7
#define ZIG_FNPTR_zT_23BE94A0_FN_void_zT_A4CE86B7
#endif /* ZIG_FNPTR_zT_23BE94A0_FN_void_zT_A4CE86B7 */
#ifndef ZIG_FNPTR_zT_136A3664_FN_void_zT_A4CE86B7
#define ZIG_FNPTR_zT_136A3664_FN_void_zT_A4CE86B7
#endif /* ZIG_FNPTR_zT_136A3664_FN_void_zT_A4CE86B7 */
#ifndef ZIG_FNPTR_zT_A53EDB61_FN_zT_89877D19_U32T
#define ZIG_FNPTR_zT_A53EDB61_FN_zT_89877D19_U32T
#endif /* ZIG_FNPTR_zT_A53EDB61_FN_zT_89877D19_U32T */
#ifndef ZIG_FNPTR_zT_821C068B_FN_zT_89877D19_U32T
#define ZIG_FNPTR_zT_821C068B_FN_zT_89877D19_U32T
#endif /* ZIG_FNPTR_zT_821C068B_FN_zT_89877D19_U32T */
#ifndef ZIG_OPTIONAL_zT_BBEE1AC1_Opt_11
#define ZIG_OPTIONAL_zT_BBEE1AC1_Opt_11
typedef struct { zT_79FAE712_u64 value; int has_value; } zT_BBEE1AC1_Opt_11;
#endif /* ZIG_OPTIONAL_zT_BBEE1AC1_Opt_11 */
#ifndef ZIG_FNPTR_zT_8BDDD61F_FN_zT_BBEE1AC1_Opt_
#define ZIG_FNPTR_zT_8BDDD61F_FN_zT_BBEE1AC1_Opt_
#endif /* ZIG_FNPTR_zT_8BDDD61F_FN_zT_BBEE1AC1_Opt_ */
#ifndef ZIG_FNPTR_zT_A07CF68F_FN_void_zT_89877D19
#define ZIG_FNPTR_zT_A07CF68F_FN_void_zT_89877D19
#endif /* ZIG_FNPTR_zT_A07CF68F_FN_void_zT_89877D19 */
#ifndef ZIG_FNPTR_zT_4926569D_FN_void_zT_89877D19
#define ZIG_FNPTR_zT_4926569D_FN_void_zT_89877D19
#endif /* ZIG_FNPTR_zT_4926569D_FN_void_zT_89877D19 */
#ifndef ZIG_FNPTR_zT_BE5F4E21_FN_zT_B687BB96_U32A
#define ZIG_FNPTR_zT_BE5F4E21_FN_zT_B687BB96_U32A
#endif /* ZIG_FNPTR_zT_BE5F4E21_FN_zT_B687BB96_U32A */
#ifndef ZIG_FNPTR_zT_6D99428B_FN_void_zT_B687BB96
#define ZIG_FNPTR_zT_6D99428B_FN_void_zT_B687BB96
#endif /* ZIG_FNPTR_zT_6D99428B_FN_void_zT_B687BB96 */
#ifndef ZIG_FNPTR_zT_E0FF92EC_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_E0FF92EC_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_E0FF92EC_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_B16E7D71_FN_zT_3CB0179A_Slic
#define ZIG_FNPTR_zT_B16E7D71_FN_zT_3CB0179A_Slic
#endif /* ZIG_FNPTR_zT_B16E7D71_FN_zT_3CB0179A_Slic */
#ifndef ZIG_FNPTR_zT_903F4E9D_FN_zT_47B162D1_U8Ar
#define ZIG_FNPTR_zT_903F4E9D_FN_zT_47B162D1_U8Ar
#endif /* ZIG_FNPTR_zT_903F4E9D_FN_zT_47B162D1_U8Ar */
#ifndef ZIG_FNPTR_zT_E6F665B5_FN_void_zT_47B162D1
#define ZIG_FNPTR_zT_E6F665B5_FN_void_zT_47B162D1
#endif /* ZIG_FNPTR_zT_E6F665B5_FN_void_zT_47B162D1 */
#ifndef ZIG_FNPTR_zT_C277C368_FN_void_zT_47B162D1
#define ZIG_FNPTR_zT_C277C368_FN_void_zT_47B162D1
#endif /* ZIG_FNPTR_zT_C277C368_FN_void_zT_47B162D1 */
#ifndef ZIG_FNPTR_zT_DF549AC8_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_DF549AC8_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_DF549AC8_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_D57E689A_FN_zT_1386C3E8_AstN
#define ZIG_FNPTR_zT_D57E689A_FN_zT_1386C3E8_AstN
#endif /* ZIG_FNPTR_zT_D57E689A_FN_zT_1386C3E8_AstN */
#ifndef ZIG_FNPTR_zT_B4CA22A0_FN_void_zT_1386C3E8
#define ZIG_FNPTR_zT_B4CA22A0_FN_void_zT_1386C3E8
#endif /* ZIG_FNPTR_zT_B4CA22A0_FN_void_zT_1386C3E8 */
#ifndef ZIG_FNPTR_zT_9EAD3BF2_FN_void_zT_1386C3E8
#define ZIG_FNPTR_zT_9EAD3BF2_FN_void_zT_1386C3E8
#endif /* ZIG_FNPTR_zT_9EAD3BF2_FN_void_zT_1386C3E8 */
#ifndef ZIG_SLICE_zT_8FBDC967_Slice_zT_22A7C88B_A
#define ZIG_SLICE_zT_8FBDC967_Slice_zT_22A7C88B_A
typedef struct { zT_22A7C88B_AstNode* ptr; unsigned int len; } zT_8FBDC967_Slice_zT_22A7C88B_A;
#endif /* ZIG_SLICE_zT_8FBDC967_Slice_zT_22A7C88B_A */
#ifndef ZIG_FNPTR_zT_E28F4AA2_FN_zT_8FBDC967_Slic
#define ZIG_FNPTR_zT_E28F4AA2_FN_zT_8FBDC967_Slic
#endif /* ZIG_FNPTR_zT_E28F4AA2_FN_zT_8FBDC967_Slic */
#ifndef ZIG_FNPTR_zT_6043B496_FN_zT_C4A0A7DB_U64A
#define ZIG_FNPTR_zT_6043B496_FN_zT_C4A0A7DB_U64A
#endif /* ZIG_FNPTR_zT_6043B496_FN_zT_C4A0A7DB_U64A */
#ifndef ZIG_FNPTR_zT_73D0A140_FN_void_zT_C4A0A7DB
#define ZIG_FNPTR_zT_73D0A140_FN_void_zT_C4A0A7DB
#endif /* ZIG_FNPTR_zT_73D0A140_FN_void_zT_C4A0A7DB */
#ifndef ZIG_FNPTR_zT_9189D69C_FN_void_zT_C4A0A7DB
#define ZIG_FNPTR_zT_9189D69C_FN_void_zT_C4A0A7DB
#endif /* ZIG_FNPTR_zT_9189D69C_FN_void_zT_C4A0A7DB */
#ifndef ZIG_SLICE_zT_A62C5D8D_Slice_zT_79FAE712_u
#define ZIG_SLICE_zT_A62C5D8D_Slice_zT_79FAE712_u
typedef struct { zT_79FAE712_u64* ptr; unsigned int len; } zT_A62C5D8D_Slice_zT_79FAE712_u;
#endif /* ZIG_SLICE_zT_A62C5D8D_Slice_zT_79FAE712_u */
#ifndef ZIG_FNPTR_zT_0DCD33B7_FN_zT_A62C5D8D_Slic
#define ZIG_FNPTR_zT_0DCD33B7_FN_zT_A62C5D8D_Slic
#endif /* ZIG_FNPTR_zT_0DCD33B7_FN_zT_A62C5D8D_Slic */
#ifndef ZIG_FNPTR_zT_ED9698BA_FN_zT_AB1FE668_F64A
#define ZIG_FNPTR_zT_ED9698BA_FN_zT_AB1FE668_F64A
#endif /* ZIG_FNPTR_zT_ED9698BA_FN_zT_AB1FE668_F64A */
#ifndef ZIG_FNPTR_zT_950BB254_FN_void_zT_AB1FE668
#define ZIG_FNPTR_zT_950BB254_FN_void_zT_AB1FE668
#endif /* ZIG_FNPTR_zT_950BB254_FN_void_zT_AB1FE668 */
#ifndef ZIG_FNPTR_zT_2AAE1F88_FN_void_zT_AB1FE668
#define ZIG_FNPTR_zT_2AAE1F88_FN_void_zT_AB1FE668
#endif /* ZIG_FNPTR_zT_2AAE1F88_FN_void_zT_AB1FE668 */
#ifndef ZIG_SLICE_zT_ACF60AF6_Slice_zT_00435AEB_f
#define ZIG_SLICE_zT_ACF60AF6_Slice_zT_00435AEB_f
typedef struct { double* ptr; unsigned int len; } zT_ACF60AF6_Slice_zT_00435AEB_f;
#endif /* ZIG_SLICE_zT_ACF60AF6_Slice_zT_00435AEB_f */
#ifndef ZIG_FNPTR_zT_4238D172_FN_zT_ACF60AF6_Slic
#define ZIG_FNPTR_zT_4238D172_FN_zT_ACF60AF6_Slic
#endif /* ZIG_FNPTR_zT_4238D172_FN_zT_ACF60AF6_Slic */
#ifndef ZIG_FNPTR_zT_39953B77_FN_zT_CCB21906_FnPr
#define ZIG_FNPTR_zT_39953B77_FN_zT_CCB21906_FnPr
#endif /* ZIG_FNPTR_zT_39953B77_FN_zT_CCB21906_FnPr */
#ifndef ZIG_FNPTR_zT_C35BD4FB_FN_void_zT_CCB21906
#define ZIG_FNPTR_zT_C35BD4FB_FN_void_zT_CCB21906
#endif /* ZIG_FNPTR_zT_C35BD4FB_FN_void_zT_CCB21906 */
#ifndef ZIG_FNPTR_zT_8C8C0203_FN_void_zT_CCB21906
#define ZIG_FNPTR_zT_8C8C0203_FN_void_zT_CCB21906
#endif /* ZIG_FNPTR_zT_8C8C0203_FN_void_zT_CCB21906 */
#ifndef ZIG_SLICE_zT_91F8F99F_Slice_zT_243D6A41_F
#define ZIG_SLICE_zT_91F8F99F_Slice_zT_243D6A41_F
typedef struct { zT_243D6A41_FnProto* ptr; unsigned int len; } zT_91F8F99F_Slice_zT_243D6A41_F;
#endif /* ZIG_SLICE_zT_91F8F99F_Slice_zT_243D6A41_F */
#ifndef ZIG_FNPTR_zT_B3320229_FN_zT_91F8F99F_Slic
#define ZIG_FNPTR_zT_B3320229_FN_zT_91F8F99F_Slic
#endif /* ZIG_FNPTR_zT_B3320229_FN_zT_91F8F99F_Slic */
#ifndef ZIG_FNPTR_zT_77440D21_FN_void_zT_66E7D2EF
#define ZIG_FNPTR_zT_77440D21_FN_void_zT_66E7D2EF
#endif /* ZIG_FNPTR_zT_77440D21_FN_void_zT_66E7D2EF */
#ifndef ZIG_FNPTR_zT_927A1EE1_FN_zT_66E7D2EF_Coer
#define ZIG_FNPTR_zT_927A1EE1_FN_zT_66E7D2EF_Coer
#endif /* ZIG_FNPTR_zT_927A1EE1_FN_zT_66E7D2EF_Coer */
#ifndef ZIG_FNPTR_zT_8E3FC47D_FN_void_zT_66E7D2EF
#define ZIG_FNPTR_zT_8E3FC47D_FN_void_zT_66E7D2EF
#endif /* ZIG_FNPTR_zT_8E3FC47D_FN_void_zT_66E7D2EF */
#ifndef ZIG_FNPTR_zT_A23BE7C2_FN_zT_5CC037A7_Opt_
#define ZIG_FNPTR_zT_A23BE7C2_FN_zT_5CC037A7_Opt_
#endif /* ZIG_FNPTR_zT_A23BE7C2_FN_zT_5CC037A7_Opt_ */
#ifndef ZIG_FNPTR_zT_03D4FA6F_FN_zT_0FB7FB13_Coer
#define ZIG_FNPTR_zT_03D4FA6F_FN_zT_0FB7FB13_Coer
#endif /* ZIG_FNPTR_zT_03D4FA6F_FN_zT_0FB7FB13_Coer */
#ifndef ZIG_FNPTR_zT_D5FDA749_FN_zT_38C12417_Sema
#define ZIG_FNPTR_zT_D5FDA749_FN_zT_38C12417_Sema
#endif /* ZIG_FNPTR_zT_D5FDA749_FN_zT_38C12417_Sema */
#ifndef ZIG_FNPTR_zT_B128AA9A_FN_int_zT_38C12417_
#define ZIG_FNPTR_zT_B128AA9A_FN_int_zT_38C12417_
#endif /* ZIG_FNPTR_zT_B128AA9A_FN_int_zT_38C12417_ */
#ifndef ZIG_FNPTR_zT_0A22341E_FN_int_zT_38C12417_
#define ZIG_FNPTR_zT_0A22341E_FN_int_zT_38C12417_
#endif /* ZIG_FNPTR_zT_0A22341E_FN_int_zT_38C12417_ */
#ifndef ZIG_FNPTR_zT_E3FAA27B_FN_void_zT_38C12417
#define ZIG_FNPTR_zT_E3FAA27B_FN_void_zT_38C12417
#endif /* ZIG_FNPTR_zT_E3FAA27B_FN_void_zT_38C12417 */
#ifndef ZIG_FNPTR_zT_C800DF91_FN_void_zT_38C12417
#define ZIG_FNPTR_zT_C800DF91_FN_void_zT_38C12417
#endif /* ZIG_FNPTR_zT_C800DF91_FN_void_zT_38C12417 */
#ifndef ZIG_FNPTR_zT_178240D5_FN_void_zT_38C12417
#define ZIG_FNPTR_zT_178240D5_FN_void_zT_38C12417
#endif /* ZIG_FNPTR_zT_178240D5_FN_void_zT_38C12417 */
#ifndef ZIG_FNPTR_zT_310E0722_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_310E0722_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_310E0722_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_6F2600D2_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_6F2600D2_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_6F2600D2_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_B7C61C10_FN_int_zT_38C12417_
#define ZIG_FNPTR_zT_B7C61C10_FN_int_zT_38C12417_
#endif /* ZIG_FNPTR_zT_B7C61C10_FN_int_zT_38C12417_ */
#ifndef ZIG_FNPTR_zT_F0664EC7_FN_void_zT_38C12417
#define ZIG_FNPTR_zT_F0664EC7_FN_void_zT_38C12417
#endif /* ZIG_FNPTR_zT_F0664EC7_FN_void_zT_38C12417 */
#ifndef ZIG_FNPTR_zT_582AD82A_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_582AD82A_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_582AD82A_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_D310E37E_FN_int_zT_38C12417_
#define ZIG_FNPTR_zT_D310E37E_FN_int_zT_38C12417_
#endif /* ZIG_FNPTR_zT_D310E37E_FN_int_zT_38C12417_ */
#ifndef ZIG_FNPTR_zT_E7F2B62A_FN_int_zT_38C12417_
#define ZIG_FNPTR_zT_E7F2B62A_FN_int_zT_38C12417_
#endif /* ZIG_FNPTR_zT_E7F2B62A_FN_int_zT_38C12417_ */
#ifndef ZIG_FNPTR_zT_2C0CE075_FN_int_zT_0FB7FB13_
#define ZIG_FNPTR_zT_2C0CE075_FN_int_zT_0FB7FB13_
#endif /* ZIG_FNPTR_zT_2C0CE075_FN_int_zT_0FB7FB13_ */
#ifndef ZIG_FNPTR_zT_C66BFC9C_FN_int_zT_38C12417_
#define ZIG_FNPTR_zT_C66BFC9C_FN_int_zT_38C12417_
#endif /* ZIG_FNPTR_zT_C66BFC9C_FN_int_zT_38C12417_ */
#ifndef ZIG_FNPTR_zT_D23B5F36_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_D23B5F36_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_D23B5F36_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_CCB47F81_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_CCB47F81_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_CCB47F81_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_183C6322_FN_zT_E2DF2801_Loca
#define ZIG_FNPTR_zT_183C6322_FN_zT_E2DF2801_Loca
#endif /* ZIG_FNPTR_zT_183C6322_FN_zT_E2DF2801_Loca */
#ifndef ZIG_FNPTR_zT_AC5F9412_FN_void_zT_E2DF2801
#define ZIG_FNPTR_zT_AC5F9412_FN_void_zT_E2DF2801
#endif /* ZIG_FNPTR_zT_AC5F9412_FN_void_zT_E2DF2801 */
#ifndef ZIG_FNPTR_zT_6DD42EB7_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_6DD42EB7_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_6DD42EB7_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_78C6162C_FN_void_zT_C890C8CB
#define ZIG_FNPTR_zT_78C6162C_FN_void_zT_C890C8CB
#endif /* ZIG_FNPTR_zT_78C6162C_FN_void_zT_C890C8CB */
#ifndef ZIG_FNPTR_zT_FF081C0C_FN_void_zT_C890C8CB
#define ZIG_FNPTR_zT_FF081C0C_FN_void_zT_C890C8CB
#endif /* ZIG_FNPTR_zT_FF081C0C_FN_void_zT_C890C8CB */
#ifndef ZIG_FNPTR_zT_C2A4B030_FN_void_zT_C890C8CB
#define ZIG_FNPTR_zT_C2A4B030_FN_void_zT_C890C8CB
#endif /* ZIG_FNPTR_zT_C2A4B030_FN_void_zT_C890C8CB */
#ifndef ZIG_FNPTR_zT_28E33191_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_28E33191_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_28E33191_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_A3E49C6D_FN_zT_C890C8CB_Type
#define ZIG_FNPTR_zT_A3E49C6D_FN_zT_C890C8CB_Type
#endif /* ZIG_FNPTR_zT_A3E49C6D_FN_zT_C890C8CB_Type */
#ifndef ZIG_FNPTR_zT_77D4130C_FN_void_zT_C890C8CB
#define ZIG_FNPTR_zT_77D4130C_FN_void_zT_C890C8CB
#endif /* ZIG_FNPTR_zT_77D4130C_FN_void_zT_C890C8CB */
#ifndef ZIG_FNPTR_zT_5576352D_FN_void_zT_C890C8CB
#define ZIG_FNPTR_zT_5576352D_FN_void_zT_C890C8CB
#endif /* ZIG_FNPTR_zT_5576352D_FN_void_zT_C890C8CB */
#ifndef ZIG_FNPTR_zT_7790FA9F_FN_zT_010C8DF0_Clas
#define ZIG_FNPTR_zT_7790FA9F_FN_zT_010C8DF0_Clas
#endif /* ZIG_FNPTR_zT_7790FA9F_FN_zT_010C8DF0_Clas */
#ifndef ZIG_FNPTR_zT_18A45DF1_FN_void_zT_3E40CD83
#define ZIG_FNPTR_zT_18A45DF1_FN_void_zT_3E40CD83
#endif /* ZIG_FNPTR_zT_18A45DF1_FN_void_zT_3E40CD83 */
#ifndef ZIG_FNPTR_zT_33BDB87C_FN_zT_3CB0179A_Slic
#define ZIG_FNPTR_zT_33BDB87C_FN_zT_3CB0179A_Slic
#endif /* ZIG_FNPTR_zT_33BDB87C_FN_zT_3CB0179A_Slic */
#ifndef ZIG_FNPTR_zT_3870E0BF_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_3870E0BF_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_3870E0BF_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_70200651_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_70200651_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_70200651_FN_unsigned_int_zT_ */
#ifndef ZIG_OPTIONAL_zT_44E16D78_Opt_7
#define ZIG_OPTIONAL_zT_44E16D78_Opt_7
typedef struct { zT_C69B2266_i64 value; int has_value; } zT_44E16D78_Opt_7;
#endif /* ZIG_OPTIONAL_zT_44E16D78_Opt_7 */
#ifndef ZIG_FNPTR_zT_75BEAA40_FN_zT_44E16D78_Opt_
#define ZIG_FNPTR_zT_75BEAA40_FN_zT_44E16D78_Opt_
#endif /* ZIG_FNPTR_zT_75BEAA40_FN_zT_44E16D78_Opt_ */
#ifndef ZIG_FNPTR_zT_99B4C5D0_FN_zT_D2761632_Opt_
#define ZIG_FNPTR_zT_99B4C5D0_FN_zT_D2761632_Opt_
#endif /* ZIG_FNPTR_zT_99B4C5D0_FN_zT_D2761632_Opt_ */
#ifndef ZIG_FNPTR_zT_FCA85CB2_FN_void_zT_ABC1EBBE
#define ZIG_FNPTR_zT_FCA85CB2_FN_void_zT_ABC1EBBE
#endif /* ZIG_FNPTR_zT_FCA85CB2_FN_void_zT_ABC1EBBE */
#ifndef ZIG_FNPTR_zT_9429C941_FN_void_zT_ABC1EBBE
#define ZIG_FNPTR_zT_9429C941_FN_void_zT_ABC1EBBE
#endif /* ZIG_FNPTR_zT_9429C941_FN_void_zT_ABC1EBBE */
#ifndef ZIG_FNPTR_zT_D29FE60A_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_D29FE60A_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_D29FE60A_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_7813CEF4_FN_void_zT_ABC1EBBE
#define ZIG_FNPTR_zT_7813CEF4_FN_void_zT_ABC1EBBE
#endif /* ZIG_FNPTR_zT_7813CEF4_FN_void_zT_ABC1EBBE */
#ifndef ZIG_FNPTR_zT_AB62DA21_FN_void_zT_ABC1EBBE
#define ZIG_FNPTR_zT_AB62DA21_FN_void_zT_ABC1EBBE
#endif /* ZIG_FNPTR_zT_AB62DA21_FN_void_zT_ABC1EBBE */
#ifndef ZIG_FNPTR_zT_F259323C_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_F259323C_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_F259323C_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_691DDF33_FN_zT_DA663F79_Comp
#define ZIG_FNPTR_zT_691DDF33_FN_zT_DA663F79_Comp
#endif /* ZIG_FNPTR_zT_691DDF33_FN_zT_DA663F79_Comp */
#ifndef ZIG_FNPTR_zT_D1B30F0B_FN_zT_E33A227C_Opt_
#define ZIG_FNPTR_zT_D1B30F0B_FN_zT_E33A227C_Opt_
#endif /* ZIG_FNPTR_zT_D1B30F0B_FN_zT_E33A227C_Opt_ */
#ifndef ZIG_FNPTR_zT_9DBFE503_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_9DBFE503_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_9DBFE503_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_455DA2BF_FN_zT_E33A227C_Opt_
#define ZIG_FNPTR_zT_455DA2BF_FN_zT_E33A227C_Opt_
#endif /* ZIG_FNPTR_zT_455DA2BF_FN_zT_E33A227C_Opt_ */
#ifndef ZIG_FNPTR_zT_449A106D_FN_zT_E33A227C_Opt_
#define ZIG_FNPTR_zT_449A106D_FN_zT_E33A227C_Opt_
#endif /* ZIG_FNPTR_zT_449A106D_FN_zT_E33A227C_Opt_ */
#ifndef ZIG_FNPTR_zT_6CF9255A_FN_zT_4D61441E_DepG
#define ZIG_FNPTR_zT_6CF9255A_FN_zT_4D61441E_DepG
#endif /* ZIG_FNPTR_zT_6CF9255A_FN_zT_4D61441E_DepG */
#ifndef ZIG_FNPTR_zT_DE638680_FN_void_zT_4D61441E
#define ZIG_FNPTR_zT_DE638680_FN_void_zT_4D61441E
#endif /* ZIG_FNPTR_zT_DE638680_FN_void_zT_4D61441E */
#ifndef ZIG_FNPTR_zT_79CEE760_FN_void_zT_4D61441E
#define ZIG_FNPTR_zT_79CEE760_FN_void_zT_4D61441E
#endif /* ZIG_FNPTR_zT_79CEE760_FN_void_zT_4D61441E */
#ifndef ZIG_FNPTR_zT_3505FF1C_FN_void_zT_4D61441E
#define ZIG_FNPTR_zT_3505FF1C_FN_void_zT_4D61441E
#endif /* ZIG_FNPTR_zT_3505FF1C_FN_void_zT_4D61441E */
#ifndef ZIG_FNPTR_zT_7804CBA8_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_7804CBA8_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_7804CBA8_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_D06528B4_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_D06528B4_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_D06528B4_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_5650C290_FN_void_zT_3D7259E2
#define ZIG_FNPTR_zT_5650C290_FN_void_zT_3D7259E2
#endif /* ZIG_FNPTR_zT_5650C290_FN_void_zT_3D7259E2 */
#ifndef ZIG_FNPTR_zT_A7692339_FN_void_zT_072B53A6
#define ZIG_FNPTR_zT_A7692339_FN_void_zT_072B53A6
#endif /* ZIG_FNPTR_zT_A7692339_FN_void_zT_072B53A6 */
#ifndef ZIG_FNPTR_zT_17D444DF_FN_void_zT_3E40CD83
#define ZIG_FNPTR_zT_17D444DF_FN_void_zT_3E40CD83
#endif /* ZIG_FNPTR_zT_17D444DF_FN_void_zT_3E40CD83 */
#ifndef ZIG_FNPTR_zT_D486EB0C_FN_void_zT_3D7259E2
#define ZIG_FNPTR_zT_D486EB0C_FN_void_zT_3D7259E2
#endif /* ZIG_FNPTR_zT_D486EB0C_FN_void_zT_3D7259E2 */
#ifndef ZIG_FNPTR_zT_5E036296_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_5E036296_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_5E036296_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_D6C1A573_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_D6C1A573_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_D6C1A573_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_DAB32D6E_FN_void_zT_6DCFC8DB
#define ZIG_FNPTR_zT_DAB32D6E_FN_void_zT_6DCFC8DB
#endif /* ZIG_FNPTR_zT_DAB32D6E_FN_void_zT_6DCFC8DB */
#ifndef ZIG_FNPTR_zT_7FFBD20E_FN_void_zT_6DCFC8DB
#define ZIG_FNPTR_zT_7FFBD20E_FN_void_zT_6DCFC8DB
#endif /* ZIG_FNPTR_zT_7FFBD20E_FN_void_zT_6DCFC8DB */
#ifndef ZIG_FNPTR_zT_745532CB_FN_void_zT_6DCFC8DB
#define ZIG_FNPTR_zT_745532CB_FN_void_zT_6DCFC8DB
#endif /* ZIG_FNPTR_zT_745532CB_FN_void_zT_6DCFC8DB */
#ifndef ZIG_FNPTR_zT_2A18B24D_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_2A18B24D_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_2A18B24D_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_C00B1DD1_FN_int_zT_A4CE86B7_
#define ZIG_FNPTR_zT_C00B1DD1_FN_int_zT_A4CE86B7_
#endif /* ZIG_FNPTR_zT_C00B1DD1_FN_int_zT_A4CE86B7_ */
#ifndef ZIG_FNPTR_zT_B02F3A87_FN_zT_BAEE192E_Opt_
#define ZIG_FNPTR_zT_B02F3A87_FN_zT_BAEE192E_Opt_
#endif /* ZIG_FNPTR_zT_B02F3A87_FN_zT_BAEE192E_Opt_ */
#ifndef ZIG_FNPTR_zT_1620B3B6_FN_unsigned_int__zT
#define ZIG_FNPTR_zT_1620B3B6_FN_unsigned_int__zT
#endif /* ZIG_FNPTR_zT_1620B3B6_FN_unsigned_int__zT */
#ifndef ZIG_FNPTR_zT_D43D08BC_FN_zT_BBEE1AC1_Opt_
#define ZIG_FNPTR_zT_D43D08BC_FN_zT_BBEE1AC1_Opt_
#endif /* ZIG_FNPTR_zT_D43D08BC_FN_zT_BBEE1AC1_Opt_ */
#ifndef ZIG_FNPTR_zT_9F2949A8_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_9F2949A8_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_9F2949A8_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_A87733D8_FN_void_zT_79FAE712
#define ZIG_FNPTR_zT_A87733D8_FN_void_zT_79FAE712
#endif /* ZIG_FNPTR_zT_A87733D8_FN_void_zT_79FAE712 */
#ifndef ZIG_FNPTR_zT_9221C6D5_FN_void_zT_3E40CD83
#define ZIG_FNPTR_zT_9221C6D5_FN_void_zT_3E40CD83
#endif /* ZIG_FNPTR_zT_9221C6D5_FN_void_zT_3E40CD83 */
#ifndef ZIG_FNPTR_zT_3A582628_FN_void_zT_338B7C76
#define ZIG_FNPTR_zT_3A582628_FN_void_zT_338B7C76
#endif /* ZIG_FNPTR_zT_3A582628_FN_void_zT_338B7C76 */
#ifndef ZIG_FNPTR_zT_3014FB79_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_3014FB79_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_3014FB79_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_BB0EC907_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_BB0EC907_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_BB0EC907_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_2C33C112_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_2C33C112_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_2C33C112_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_E5503342_FN_void_zT_6B0A7D14
#define ZIG_FNPTR_zT_E5503342_FN_void_zT_6B0A7D14
#endif /* ZIG_FNPTR_zT_E5503342_FN_void_zT_6B0A7D14 */
#ifndef ZIG_FNPTR_zT_149EB49F_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_149EB49F_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_149EB49F_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_9C57BFB3_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_9C57BFB3_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_9C57BFB3_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_1ED52294_FN_void_zT_79FAE712
#define ZIG_FNPTR_zT_1ED52294_FN_void_zT_79FAE712
#endif /* ZIG_FNPTR_zT_1ED52294_FN_void_zT_79FAE712 */
#ifndef ZIG_FNPTR_zT_4D64A19D_FN_void_zT_3E40CD83
#define ZIG_FNPTR_zT_4D64A19D_FN_void_zT_3E40CD83
#endif /* ZIG_FNPTR_zT_4D64A19D_FN_void_zT_3E40CD83 */
#ifndef ZIG_FNPTR_zT_2BE2DB46_FN_zT_2CF63CE1_Asyn
#define ZIG_FNPTR_zT_2BE2DB46_FN_zT_2CF63CE1_Asyn
#endif /* ZIG_FNPTR_zT_2BE2DB46_FN_zT_2CF63CE1_Asyn */
#ifndef ZIG_FNPTR_zT_A0FC0ECE_FN_void_zT_2CF63CE1
#define ZIG_FNPTR_zT_A0FC0ECE_FN_void_zT_2CF63CE1
#endif /* ZIG_FNPTR_zT_A0FC0ECE_FN_void_zT_2CF63CE1 */
#ifndef ZIG_FNPTR_zT_2C033D5C_FN_void_zT_2CF63CE1
#define ZIG_FNPTR_zT_2C033D5C_FN_void_zT_2CF63CE1
#endif /* ZIG_FNPTR_zT_2C033D5C_FN_void_zT_2CF63CE1 */
#ifndef ZIG_FNPTR_zT_383B14A2_FN_unsigned_int__zT
#define ZIG_FNPTR_zT_383B14A2_FN_unsigned_int__zT
#endif /* ZIG_FNPTR_zT_383B14A2_FN_unsigned_int__zT */
#ifndef ZIG_FNPTR_zT_85808107_FN_unsigned_char__z
#define ZIG_FNPTR_zT_85808107_FN_unsigned_char__z
#endif /* ZIG_FNPTR_zT_85808107_FN_unsigned_char__z */
#ifndef ZIG_FNPTR_zT_A7575384_FN_unsigned_char__z
#define ZIG_FNPTR_zT_A7575384_FN_unsigned_char__z
#endif /* ZIG_FNPTR_zT_A7575384_FN_unsigned_char__z */
#ifndef ZIG_FNPTR_zT_8EA20C86_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_8EA20C86_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_8EA20C86_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_343C21A7_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_343C21A7_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_343C21A7_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_4A8A821A_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_4A8A821A_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_4A8A821A_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_94908451_FN_int_zT_6D148508_
#define ZIG_FNPTR_zT_94908451_FN_int_zT_6D148508_
#endif /* ZIG_FNPTR_zT_94908451_FN_int_zT_6D148508_ */
#ifndef ZIG_FNPTR_zT_121B30DD_FN_int_zT_6D148508_
#define ZIG_FNPTR_zT_121B30DD_FN_int_zT_6D148508_
#endif /* ZIG_FNPTR_zT_121B30DD_FN_int_zT_6D148508_ */
#ifndef ZIG_FNPTR_zT_A2B9D5B2_FN_int_zT_6D148508_
#define ZIG_FNPTR_zT_A2B9D5B2_FN_int_zT_6D148508_
#endif /* ZIG_FNPTR_zT_A2B9D5B2_FN_int_zT_6D148508_ */
#ifndef ZIG_FNPTR_zT_4818DB76_FN_void_zT_6D148508
#define ZIG_FNPTR_zT_4818DB76_FN_void_zT_6D148508
#endif /* ZIG_FNPTR_zT_4818DB76_FN_void_zT_6D148508 */
#ifndef ZIG_FNPTR_zT_97AB05F7_FN_void_zT_2CF63CE1
#define ZIG_FNPTR_zT_97AB05F7_FN_void_zT_2CF63CE1
#endif /* ZIG_FNPTR_zT_97AB05F7_FN_void_zT_2CF63CE1 */
#ifndef ZIG_FNPTR_zT_1B16509D_FN_zT_3F3BF87A_Asyn
#define ZIG_FNPTR_zT_1B16509D_FN_zT_3F3BF87A_Asyn
#endif /* ZIG_FNPTR_zT_1B16509D_FN_zT_3F3BF87A_Asyn */
#ifndef ZIG_FNPTR_zT_34457ECB_FN_void_zT_3E40CD83
#define ZIG_FNPTR_zT_34457ECB_FN_void_zT_3E40CD83
#endif /* ZIG_FNPTR_zT_34457ECB_FN_void_zT_3E40CD83 */
#ifndef ZIG_OPTIONAL_zT_03B97CED_Opt_398
#define ZIG_OPTIONAL_zT_03B97CED_Opt_398
typedef struct { zT_3F3BF87A_AsyncFrameLayout* value; int has_value; } zT_03B97CED_Opt_398;
#endif /* ZIG_OPTIONAL_zT_03B97CED_Opt_398 */
#ifndef ZIG_FNPTR_zT_BBB3B341_FN_zT_03B97CED_Opt_
#define ZIG_FNPTR_zT_BBB3B341_FN_zT_03B97CED_Opt_
#endif /* ZIG_FNPTR_zT_BBB3B341_FN_zT_03B97CED_Opt_ */
#ifndef ZIG_FNPTR_zT_7F434219_FN_unsigned_char__z
#define ZIG_FNPTR_zT_7F434219_FN_unsigned_char__z
#endif /* ZIG_FNPTR_zT_7F434219_FN_unsigned_char__z */
#ifndef ZIG_FNPTR_zT_39BBAE95_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_39BBAE95_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_39BBAE95_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_31F54703_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_31F54703_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_31F54703_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_78A80B47_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_78A80B47_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_78A80B47_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_2BA4DE32_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_2BA4DE32_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_2BA4DE32_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_11151AC1_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_11151AC1_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_11151AC1_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_813D6347_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_813D6347_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_813D6347_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_48DDF711_FN_void_zT_95967543
#define ZIG_FNPTR_zT_48DDF711_FN_void_zT_95967543
#endif /* ZIG_FNPTR_zT_48DDF711_FN_void_zT_95967543 */
#ifndef ZIG_FNPTR_zT_0573195D_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_0573195D_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_0573195D_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_E4675F03_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_E4675F03_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_E4675F03_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_79C03450_FN_void_zT_95967543
#define ZIG_FNPTR_zT_79C03450_FN_void_zT_95967543
#endif /* ZIG_FNPTR_zT_79C03450_FN_void_zT_95967543 */
#ifndef ZIG_FNPTR_zT_CDA62E4C_FN_void_zT_95967543
#define ZIG_FNPTR_zT_CDA62E4C_FN_void_zT_95967543
#endif /* ZIG_FNPTR_zT_CDA62E4C_FN_void_zT_95967543 */
#ifndef ZIG_FNPTR_zT_1953DA71_FN_void_zT_95967543
#define ZIG_FNPTR_zT_1953DA71_FN_void_zT_95967543
#endif /* ZIG_FNPTR_zT_1953DA71_FN_void_zT_95967543 */
#ifndef ZIG_FNPTR_zT_6594C4FF_FN_zT_6BA597BC_LirI
#define ZIG_FNPTR_zT_6594C4FF_FN_zT_6BA597BC_LirI
#endif /* ZIG_FNPTR_zT_6594C4FF_FN_zT_6BA597BC_LirI */
#ifndef ZIG_FNPTR_zT_2DCEF9F2_FN_void_zT_95967543
#define ZIG_FNPTR_zT_2DCEF9F2_FN_void_zT_95967543
#endif /* ZIG_FNPTR_zT_2DCEF9F2_FN_void_zT_95967543 */
#ifndef ZIG_FNPTR_zT_9A3A8072_FN_int_zT_5839647A_
#define ZIG_FNPTR_zT_9A3A8072_FN_int_zT_5839647A_
#endif /* ZIG_FNPTR_zT_9A3A8072_FN_int_zT_5839647A_ */
#ifndef ZIG_FNPTR_zT_5F312021_FN_zT_79D145D1_Asyn
#define ZIG_FNPTR_zT_5F312021_FN_zT_79D145D1_Asyn
#endif /* ZIG_FNPTR_zT_5F312021_FN_zT_79D145D1_Asyn */
#ifndef ZIG_FNPTR_zT_FCF12144_FN_void_zT_BBC23664
#define ZIG_FNPTR_zT_FCF12144_FN_void_zT_BBC23664
#endif /* ZIG_FNPTR_zT_FCF12144_FN_void_zT_BBC23664 */
#ifndef ZIG_FNPTR_zT_4F61DFE3_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_4F61DFE3_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_4F61DFE3_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_7C1DF661_FN_void_zT_BBC23664
#define ZIG_FNPTR_zT_7C1DF661_FN_void_zT_BBC23664
#endif /* ZIG_FNPTR_zT_7C1DF661_FN_void_zT_BBC23664 */
#ifndef ZIG_SLICE_zT_577163E8_Slice_zT_C72CD5DD_F
#define ZIG_SLICE_zT_577163E8_Slice_zT_C72CD5DD_F
typedef struct { zT_C72CD5DD_FrameInitParam* ptr; unsigned int len; } zT_577163E8_Slice_zT_C72CD5DD_F;
#endif /* ZIG_SLICE_zT_577163E8_Slice_zT_C72CD5DD_F */
#ifndef ZIG_FNPTR_zT_575A97FB_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_575A97FB_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_575A97FB_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_E126C55D_FN_void_zT_5839647A
#define ZIG_FNPTR_zT_E126C55D_FN_void_zT_5839647A
#endif /* ZIG_FNPTR_zT_E126C55D_FN_void_zT_5839647A */
#ifndef ZIG_FNPTR_zT_7650DB4C_FN_int_zT_BBC23664_
#define ZIG_FNPTR_zT_7650DB4C_FN_int_zT_BBC23664_
#endif /* ZIG_FNPTR_zT_7650DB4C_FN_int_zT_BBC23664_ */
#ifndef ZIG_FNPTR_zT_947A7B23_FN_zT_3CB0179A_Slic
#define ZIG_FNPTR_zT_947A7B23_FN_zT_3CB0179A_Slic
#endif /* ZIG_FNPTR_zT_947A7B23_FN_zT_3CB0179A_Slic */
#ifndef ZIG_FNPTR_zT_529AC0FC_FN_zT_0426DCE7_Spil
#define ZIG_FNPTR_zT_529AC0FC_FN_zT_0426DCE7_Spil
#endif /* ZIG_FNPTR_zT_529AC0FC_FN_zT_0426DCE7_Spil */
#ifndef ZIG_FNPTR_zT_BDD043A9_FN_zT_D21A8776_Spil
#define ZIG_FNPTR_zT_BDD043A9_FN_zT_D21A8776_Spil
#endif /* ZIG_FNPTR_zT_BDD043A9_FN_zT_D21A8776_Spil */
#ifndef ZIG_FNPTR_zT_A5164977_FN_void_zT_D21A8776
#define ZIG_FNPTR_zT_A5164977_FN_void_zT_D21A8776
#endif /* ZIG_FNPTR_zT_A5164977_FN_void_zT_D21A8776 */
#ifndef ZIG_FNPTR_zT_0FFCEA57_FN_void_zT_D21A8776
#define ZIG_FNPTR_zT_0FFCEA57_FN_void_zT_D21A8776
#endif /* ZIG_FNPTR_zT_0FFCEA57_FN_void_zT_D21A8776 */
#ifndef ZIG_FNPTR_zT_326AD1B1_FN_void_zT_D21A8776
#define ZIG_FNPTR_zT_326AD1B1_FN_void_zT_D21A8776
#endif /* ZIG_FNPTR_zT_326AD1B1_FN_void_zT_D21A8776 */
#ifndef ZIG_FNPTR_zT_AE1E5E8C_FN_void_zT_8F083A69
#define ZIG_FNPTR_zT_AE1E5E8C_FN_void_zT_8F083A69
#endif /* ZIG_FNPTR_zT_AE1E5E8C_FN_void_zT_8F083A69 */
#ifndef ZIG_FNPTR_zT_FE7C6B55_FN_void_zT_8F083A69
#define ZIG_FNPTR_zT_FE7C6B55_FN_void_zT_8F083A69
#endif /* ZIG_FNPTR_zT_FE7C6B55_FN_void_zT_8F083A69 */
#ifndef ZIG_FNPTR_zT_21BB499B_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_21BB499B_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_21BB499B_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_30AAF3FD_FN_int_double
#define ZIG_FNPTR_zT_30AAF3FD_FN_int_double
#endif /* ZIG_FNPTR_zT_30AAF3FD_FN_int_double */
#ifndef ZIG_FNPTR_zT_93E8DCE5_FN_zT_8F083A69_Slic
#define ZIG_FNPTR_zT_93E8DCE5_FN_zT_8F083A69_Slic
#endif /* ZIG_FNPTR_zT_93E8DCE5_FN_zT_8F083A69_Slic */
#ifndef ZIG_FNPTR_zT_DB10E72E_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_DB10E72E_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_DB10E72E_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_413DD1AA_FN_unsigned_char
#define ZIG_FNPTR_zT_413DD1AA_FN_unsigned_char
#endif /* ZIG_FNPTR_zT_413DD1AA_FN_unsigned_char */
#ifndef ZIG_FNPTR_zT_37D9C3CE_FN_unsigned_char_un
#define ZIG_FNPTR_zT_37D9C3CE_FN_unsigned_char_un
#endif /* ZIG_FNPTR_zT_37D9C3CE_FN_unsigned_char_un */
#ifndef ZIG_FNPTR_zT_318009D0_FN_void_unsigned_in
#define ZIG_FNPTR_zT_318009D0_FN_void_unsigned_in
#endif /* ZIG_FNPTR_zT_318009D0_FN_void_unsigned_in */
#ifndef ZIG_FNPTR_zT_B3085373_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_B3085373_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_B3085373_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_AC940AE1_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_AC940AE1_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_AC940AE1_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_DA646395_FN_unsigned_int__zT
#define ZIG_FNPTR_zT_DA646395_FN_unsigned_int__zT
#endif /* ZIG_FNPTR_zT_DA646395_FN_unsigned_int__zT */
#ifndef ZIG_FNPTR_zT_8C5E20DF_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_8C5E20DF_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_8C5E20DF_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_66DD7612_FN_unsigned_char__z
#define ZIG_FNPTR_zT_66DD7612_FN_unsigned_char__z
#endif /* ZIG_FNPTR_zT_66DD7612_FN_unsigned_char__z */
#ifndef ZIG_FNPTR_zT_946987A3_FN_void_zT_5EDE903E
#define ZIG_FNPTR_zT_946987A3_FN_void_zT_5EDE903E
#endif /* ZIG_FNPTR_zT_946987A3_FN_void_zT_5EDE903E */
#ifndef ZIG_FNPTR_zT_AE343021_FN_void_zT_5EDE903E
#define ZIG_FNPTR_zT_AE343021_FN_void_zT_5EDE903E
#endif /* ZIG_FNPTR_zT_AE343021_FN_void_zT_5EDE903E */
#ifndef ZIG_FNPTR_zT_AB54417D_FN_void_zT_5EDE903E
#define ZIG_FNPTR_zT_AB54417D_FN_void_zT_5EDE903E
#endif /* ZIG_FNPTR_zT_AB54417D_FN_void_zT_5EDE903E */
#ifndef ZIG_FNPTR_zT_9EA526E1_FN_void_zT_5EDE903E
#define ZIG_FNPTR_zT_9EA526E1_FN_void_zT_5EDE903E
#endif /* ZIG_FNPTR_zT_9EA526E1_FN_void_zT_5EDE903E */
#ifndef ZIG_FNPTR_zT_8A16D512_FN_void_zT_5EDE903E
#define ZIG_FNPTR_zT_8A16D512_FN_void_zT_5EDE903E
#endif /* ZIG_FNPTR_zT_8A16D512_FN_void_zT_5EDE903E */
#ifndef ZIG_FNPTR_zT_62A45553_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_62A45553_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_62A45553_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_B836347D_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_B836347D_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_B836347D_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_0F70B3FE_FN_void_zT_5EDE903E
#define ZIG_FNPTR_zT_0F70B3FE_FN_void_zT_5EDE903E
#endif /* ZIG_FNPTR_zT_0F70B3FE_FN_void_zT_5EDE903E */
#ifndef ZIG_FNPTR_zT_0EA48227_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_0EA48227_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_0EA48227_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_ED2201D0_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_ED2201D0_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_ED2201D0_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_5B47BBCA_FN_unsigned_int_zT_
#define ZIG_FNPTR_zT_5B47BBCA_FN_unsigned_int_zT_
#endif /* ZIG_FNPTR_zT_5B47BBCA_FN_unsigned_int_zT_ */
#ifndef ZIG_FNPTR_zT_A223172E_FN_zT_6BA597BC_LirI
#define ZIG_FNPTR_zT_A223172E_FN_zT_6BA597BC_LirI
#endif /* ZIG_FNPTR_zT_A223172E_FN_zT_6BA597BC_LirI */
#ifndef ZIG_FNPTR_zT_5AE85635_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_5AE85635_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_5AE85635_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_CD3C1315_FN_zT_6BA597BC_LirI
#define ZIG_FNPTR_zT_CD3C1315_FN_zT_6BA597BC_LirI
#endif /* ZIG_FNPTR_zT_CD3C1315_FN_zT_6BA597BC_LirI */
#ifndef ZIG_FNPTR_zT_60EAA4BE_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_60EAA4BE_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_60EAA4BE_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_3C048F9E_FN_void_zT_79FAE712
#define ZIG_FNPTR_zT_3C048F9E_FN_void_zT_79FAE712
#endif /* ZIG_FNPTR_zT_3C048F9E_FN_void_zT_79FAE712 */
#ifndef ZIG_FNPTR_zT_0B7021A9_FN_signed_char_zT_7
#define ZIG_FNPTR_zT_0B7021A9_FN_signed_char_zT_7
#endif /* ZIG_FNPTR_zT_0B7021A9_FN_signed_char_zT_7 */
#ifndef ZIG_FNPTR_zT_207FA21F_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_207FA21F_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_207FA21F_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_4EE20FE5_FN_unsigned_char_zT
#define ZIG_FNPTR_zT_4EE20FE5_FN_unsigned_char_zT
#endif /* ZIG_FNPTR_zT_4EE20FE5_FN_unsigned_char_zT */
#ifndef ZIG_FNPTR_zT_F5E2993D_FN_void_zT_3E40CD83
#define ZIG_FNPTR_zT_F5E2993D_FN_void_zT_3E40CD83
#endif /* ZIG_FNPTR_zT_F5E2993D_FN_void_zT_3E40CD83 */
#ifndef ZIG_FNPTR_zT_A2C63518_FN_zT_79FAE712_u64_
#define ZIG_FNPTR_zT_A2C63518_FN_zT_79FAE712_u64_
#endif /* ZIG_FNPTR_zT_A2C63518_FN_zT_79FAE712_u64_ */
#ifndef ZIG_FNPTR_zT_033270C5_FN_void_zT_63BE4FF5
#define ZIG_FNPTR_zT_033270C5_FN_void_zT_63BE4FF5
#endif /* ZIG_FNPTR_zT_033270C5_FN_void_zT_63BE4FF5 */
#ifndef ZIG_FNPTR_zT_6B26C77E_FN_zT_2C0927B0_Stat
#define ZIG_FNPTR_zT_6B26C77E_FN_zT_2C0927B0_Stat
#endif /* ZIG_FNPTR_zT_6B26C77E_FN_zT_2C0927B0_Stat */
#ifndef ZIG_FNPTR_zT_BCF04134_FN_void_zT_2C0927B0
#define ZIG_FNPTR_zT_BCF04134_FN_void_zT_2C0927B0
#endif /* ZIG_FNPTR_zT_BCF04134_FN_void_zT_2C0927B0 */
#ifndef ZIG_OPTIONAL_zT_43E16BE5_Opt_8
#define ZIG_OPTIONAL_zT_43E16BE5_Opt_8
typedef struct { unsigned char value; int has_value; } zT_43E16BE5_Opt_8;
#endif /* ZIG_OPTIONAL_zT_43E16BE5_Opt_8 */
#ifndef ZIG_FNPTR_zT_1D87EBA3_FN_zT_43E16BE5_Opt_
#define ZIG_FNPTR_zT_1D87EBA3_FN_zT_43E16BE5_Opt_
#endif /* ZIG_FNPTR_zT_1D87EBA3_FN_zT_43E16BE5_Opt_ */
#ifndef ZIG_FNPTR_zT_C40C006F_FN_void_zT_2C0927B0
#define ZIG_FNPTR_zT_C40C006F_FN_void_zT_2C0927B0
#endif /* ZIG_FNPTR_zT_C40C006F_FN_void_zT_2C0927B0 */
#ifndef ZIG_FNPTR_zT_B01D5D83_FN_zT_2C0927B0_Stat
#define ZIG_FNPTR_zT_B01D5D83_FN_zT_2C0927B0_Stat
#endif /* ZIG_FNPTR_zT_B01D5D83_FN_zT_2C0927B0_Stat */
#ifndef ZIG_FNPTR_zT_654797F3_FN_void_zT_2C0927B0
#define ZIG_FNPTR_zT_654797F3_FN_void_zT_2C0927B0
#endif /* ZIG_FNPTR_zT_654797F3_FN_void_zT_2C0927B0 */
#ifndef ZIG_SLICE_zT_92FBD55B_Slice_zT_6B392E0E_S
#define ZIG_SLICE_zT_92FBD55B_Slice_zT_6B392E0E_S
typedef struct { zT_6B392E0E_StateEntry* ptr; unsigned int len; } zT_92FBD55B_Slice_zT_6B392E0E_S;
#endif /* ZIG_SLICE_zT_92FBD55B_Slice_zT_6B392E0E_S */
#ifndef ZIG_FNPTR_zT_6DFE9A33_FN_zT_92FBD55B_Slic
#define ZIG_FNPTR_zT_6DFE9A33_FN_zT_92FBD55B_Slic
#endif /* ZIG_FNPTR_zT_6DFE9A33_FN_zT_92FBD55B_Slic */
#ifndef ZIG_FNPTR_zT_F3BD2755_FN_int_int_unsigned
#define ZIG_FNPTR_zT_F3BD2755_FN_int_int_unsigned
#endif /* ZIG_FNPTR_zT_F3BD2755_FN_int_int_unsigned */
#ifndef ZIG_FNPTR_zT_AF5F517C_FN_void_unsigned_ch
#define ZIG_FNPTR_zT_AF5F517C_FN_void_unsigned_ch
#endif /* ZIG_FNPTR_zT_AF5F517C_FN_void_unsigned_ch */
#ifndef ZIG_ARRAY_zT_69AC43E8_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_69AC43E8_Arr_unsigned_char_3
typedef unsigned char zT_69AC43E8_Arr_unsigned_char_3[32768];
#endif /* ZIG_ARRAY_zT_69AC43E8_Arr_unsigned_char_3 */
#ifndef ZIG_FNPTR_zT_9981D851_FN_zT_138FFB41_Lexe
#define ZIG_FNPTR_zT_9981D851_FN_zT_138FFB41_Lexe
#endif /* ZIG_FNPTR_zT_9981D851_FN_zT_138FFB41_Lexe */
#ifndef ZIG_FNPTR_zT_95E658AC_FN_void_zT_79FAE712
#define ZIG_FNPTR_zT_95E658AC_FN_void_zT_79FAE712
#endif /* ZIG_FNPTR_zT_95E658AC_FN_void_zT_79FAE712 */
#ifndef ZIG_FNPTR_zT_48AAE465_FN_zT_EAC3E484_Toke
#define ZIG_FNPTR_zT_48AAE465_FN_zT_EAC3E484_Toke
#endif /* ZIG_FNPTR_zT_48AAE465_FN_zT_EAC3E484_Toke */
#ifndef ZIG_OPTIONAL_zT_ACDCBA03_Opt_84
#define ZIG_OPTIONAL_zT_ACDCBA03_Opt_84
typedef struct { zT_EAC3E484_TokenKind value; int has_value; } zT_ACDCBA03_Opt_84;
#endif /* ZIG_OPTIONAL_zT_ACDCBA03_Opt_84 */
#ifndef ZIG_ARRAY_zT_B06C33DA_Arr_zT_8F083A69_Sli
#define ZIG_ARRAY_zT_B06C33DA_Arr_zT_8F083A69_Sli
typedef zT_8F083A69_Slice_zT_0B42B2F8_u zT_B06C33DA_Arr_zT_8F083A69_Sli[16];
#endif /* ZIG_ARRAY_zT_B06C33DA_Arr_zT_8F083A69_Sli */
#ifndef ZIG_OPTIONAL_zT_7734FB4A_Opt_221
#define ZIG_OPTIONAL_zT_7734FB4A_Opt_221
typedef struct { zT_8F083A69_Slice_zT_0B42B2F8_u value; int has_value; } zT_7734FB4A_Opt_221;
#endif /* ZIG_OPTIONAL_zT_7734FB4A_Opt_221 */
#ifndef ZIG_STRUCT_zT_3E40CD83_Sand
#define ZIG_STRUCT_zT_3E40CD83_Sand
struct zT_3E40CD83_Sand {
	unsigned char* start;
	unsigned int pos;
	unsigned int end;
	unsigned int peak;
	zT_8F083A69_Slice_zT_0B42B2F8_u name;
	zT_7032B1AE_Opt_236 growable;
};
#endif /* ZIG_STRUCT_zT_3E40CD83_Sand */
#ifndef ZIG_STRUCT_zT_C59F83AC_SandSegment
#define ZIG_STRUCT_zT_C59F83AC_SandSegment
struct zT_C59F83AC_SandSegment {
	unsigned char* start;
	unsigned int size;
	unsigned int end;
	zT_6A32A83C_Opt_238 next;
};
#endif /* ZIG_STRUCT_zT_C59F83AC_SandSegment */
#ifndef ZIG_OPTIONAL_zT_05D09430_Opt_436
#define ZIG_OPTIONAL_zT_05D09430_Opt_436
typedef struct { zT_8F083A69_Slice_zT_0B42B2F8_u value; int has_value; } zT_05D09430_Opt_436;
#endif /* ZIG_OPTIONAL_zT_05D09430_Opt_436 */
#ifndef ZIG_ARRAY_zT_BBAAFAE2_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_BBAAFAE2_Arr_unsigned_char_2
typedef unsigned char zT_BBAAFAE2_Arr_unsigned_char_2[2];
#endif /* ZIG_ARRAY_zT_BBAAFAE2_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_493A2FE2_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_493A2FE2_Arr_unsigned_char_9
typedef unsigned char zT_493A2FE2_Arr_unsigned_char_9[91];
#endif /* ZIG_ARRAY_zT_493A2FE2_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_BCAAFC75_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_BCAAFC75_Arr_unsigned_char_3
typedef unsigned char zT_BCAAFC75_Arr_unsigned_char_3[3];
#endif /* ZIG_ARRAY_zT_BCAAFC75_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_B7AAF496_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_B7AAF496_Arr_unsigned_char_6
typedef unsigned char zT_B7AAF496_Arr_unsigned_char_6[6];
#endif /* ZIG_ARRAY_zT_B7AAF496_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_4D2B2BA4_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_4D2B2BA4_Arr_unsigned_char_3
typedef unsigned char zT_4D2B2BA4_Arr_unsigned_char_3[39];
#endif /* ZIG_ARRAY_zT_4D2B2BA4_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_3C19C7C0_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_3C19C7C0_Arr_unsigned_char_4
typedef unsigned char zT_3C19C7C0_Arr_unsigned_char_4[40];
#endif /* ZIG_ARRAY_zT_3C19C7C0_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_BAAAF94F_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_BAAAF94F_Arr_unsigned_char_1
typedef unsigned char zT_BAAAF94F_Arr_unsigned_char_1[1];
#endif /* ZIG_ARRAY_zT_BAAAF94F_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_472B2232_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_472B2232_Arr_unsigned_char_3
typedef unsigned char zT_472B2232_Arr_unsigned_char_3[33];
#endif /* ZIG_ARRAY_zT_472B2232_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_B8AAF629_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_B8AAF629_Arr_unsigned_char_7
typedef unsigned char zT_B8AAF629_Arr_unsigned_char_7[7];
#endif /* ZIG_ARRAY_zT_B8AAF629_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_5726BE34_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5726BE34_Arr_unsigned_char_1
typedef unsigned char zT_5726BE34_Arr_unsigned_char_1[13];
#endif /* ZIG_ARRAY_zT_5726BE34_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_5626BCA1_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5626BCA1_Arr_unsigned_char_1
typedef unsigned char zT_5626BCA1_Arr_unsigned_char_1[14];
#endif /* ZIG_ARRAY_zT_5626BCA1_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_5326B7E8_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5326B7E8_Arr_unsigned_char_1
typedef unsigned char zT_5326B7E8_Arr_unsigned_char_1[17];
#endif /* ZIG_ARRAY_zT_5326B7E8_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_5226B655_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5226B655_Arr_unsigned_char_1
typedef unsigned char zT_5226B655_Arr_unsigned_char_1[18];
#endif /* ZIG_ARRAY_zT_5226B655_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_5126B4C2_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5126B4C2_Arr_unsigned_char_1
typedef unsigned char zT_5126B4C2_Arr_unsigned_char_1[19];
#endif /* ZIG_ARRAY_zT_5126B4C2_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_5A26C2ED_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5A26C2ED_Arr_unsigned_char_1
typedef unsigned char zT_5A26C2ED_Arr_unsigned_char_1[10];
#endif /* ZIG_ARRAY_zT_5A26C2ED_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_4028D896_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_4028D896_Arr_unsigned_char_2
typedef unsigned char zT_4028D896_Arr_unsigned_char_2[20];
#endif /* ZIG_ARRAY_zT_4028D896_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_B5AAF170_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_B5AAF170_Arr_unsigned_char_4
typedef unsigned char zT_B5AAF170_Arr_unsigned_char_4[4];
#endif /* ZIG_ARRAY_zT_B5AAF170_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_452B1F0C_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_452B1F0C_Arr_unsigned_char_3
typedef unsigned char zT_452B1F0C_Arr_unsigned_char_3[31];
#endif /* ZIG_ARRAY_zT_452B1F0C_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_482B23C5_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_482B23C5_Arr_unsigned_char_3
typedef unsigned char zT_482B23C5_Arr_unsigned_char_3[32];
#endif /* ZIG_ARRAY_zT_482B23C5_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_5826BFC7_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5826BFC7_Arr_unsigned_char_1
typedef unsigned char zT_5826BFC7_Arr_unsigned_char_1[12];
#endif /* ZIG_ARRAY_zT_5826BFC7_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_B9AAF7BC_Arr_unsigned_char_0
#define ZIG_ARRAY_zT_B9AAF7BC_Arr_unsigned_char_0
typedef unsigned char zT_B9AAF7BC_Arr_unsigned_char_0[1];
#endif /* ZIG_ARRAY_zT_B9AAF7BC_Arr_unsigned_char_0 */
#ifndef ZIG_ARRAY_zT_C2AB05E7_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_C2AB05E7_Arr_unsigned_char_9
typedef unsigned char zT_C2AB05E7_Arr_unsigned_char_9[9];
#endif /* ZIG_ARRAY_zT_C2AB05E7_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_5526BB0E_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5526BB0E_Arr_unsigned_char_1
typedef unsigned char zT_5526BB0E_Arr_unsigned_char_1[15];
#endif /* ZIG_ARRAY_zT_5526BB0E_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_C61CDF95_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_C61CDF95_Arr_unsigned_char_5
typedef unsigned char zT_C61CDF95_Arr_unsigned_char_5[54];
#endif /* ZIG_ARRAY_zT_C61CDF95_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_4637EC92_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4637EC92_Arr_unsigned_char_8
typedef unsigned char zT_4637EC92_Arr_unsigned_char_8[82];
#endif /* ZIG_ARRAY_zT_4637EC92_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_C6215CC3_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_C6215CC3_Arr_unsigned_char_7
typedef unsigned char zT_C6215CC3_Arr_unsigned_char_7[78];
#endif /* ZIG_ARRAY_zT_C6215CC3_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_B6AAF303_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_B6AAF303_Arr_unsigned_char_5
typedef unsigned char zT_B6AAF303_Arr_unsigned_char_5[5];
#endif /* ZIG_ARRAY_zT_B6AAF303_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_4119CF9F_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_4119CF9F_Arr_unsigned_char_4
typedef unsigned char zT_4119CF9F_Arr_unsigned_char_4[45];
#endif /* ZIG_ARRAY_zT_4119CF9F_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_5426B97B_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5426B97B_Arr_unsigned_char_1
typedef unsigned char zT_5426B97B_Arr_unsigned_char_1[16];
#endif /* ZIG_ARRAY_zT_5426B97B_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_D01F2DEA_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_D01F2DEA_Arr_unsigned_char_6
typedef unsigned char zT_D01F2DEA_Arr_unsigned_char_6[68];
#endif /* ZIG_ARRAY_zT_D01F2DEA_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_4737EE25_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4737EE25_Arr_unsigned_char_8
typedef unsigned char zT_4737EE25_Arr_unsigned_char_8[83];
#endif /* ZIG_ARRAY_zT_4737EE25_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_4237E646_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4237E646_Arr_unsigned_char_8
typedef unsigned char zT_4237E646_Arr_unsigned_char_8[86];
#endif /* ZIG_ARRAY_zT_4237E646_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_463A2B29_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_463A2B29_Arr_unsigned_char_9
typedef unsigned char zT_463A2B29_Arr_unsigned_char_9[94];
#endif /* ZIG_ARRAY_zT_463A2B29_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_C61F1E2C_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_C61F1E2C_Arr_unsigned_char_6
typedef unsigned char zT_C61F1E2C_Arr_unsigned_char_6[62];
#endif /* ZIG_ARRAY_zT_C61F1E2C_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_C51F1C99_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_C51F1C99_Arr_unsigned_char_6
typedef unsigned char zT_C51F1C99_Arr_unsigned_char_6[65];
#endif /* ZIG_ARRAY_zT_C51F1C99_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_4519D5EB_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_4519D5EB_Arr_unsigned_char_4
typedef unsigned char zT_4519D5EB_Arr_unsigned_char_4[49];
#endif /* ZIG_ARRAY_zT_4519D5EB_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_422B1A53_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_422B1A53_Arr_unsigned_char_3
typedef unsigned char zT_422B1A53_Arr_unsigned_char_3[34];
#endif /* ZIG_ARRAY_zT_422B1A53_Arr_unsigned_char_3 */
#ifndef ZIG_SLICE_zT_0B638573_Slice_zT_EABC94D3_I
#define ZIG_SLICE_zT_0B638573_Slice_zT_EABC94D3_I
typedef struct { zT_EABC94D3_InternEntry* ptr; unsigned int len; } zT_0B638573_Slice_zT_EABC94D3_I;
#endif /* ZIG_SLICE_zT_0B638573_Slice_zT_EABC94D3_I */
#ifndef ZIG_ARRAY_zT_949EEA93_Arr_unsigned_int_0
#define ZIG_ARRAY_zT_949EEA93_Arr_unsigned_int_0
typedef unsigned int zT_949EEA93_Arr_unsigned_int_0[1];
#endif /* ZIG_ARRAY_zT_949EEA93_Arr_unsigned_int_0 */
#ifndef ZIG_ARRAY_zT_4528E075_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_4528E075_Arr_unsigned_char_2
typedef unsigned char zT_4528E075_Arr_unsigned_char_2[25];
#endif /* ZIG_ARRAY_zT_4528E075_Arr_unsigned_char_2 */
#ifndef ZIG_SLICE_zT_1E07C3E5_Slice_zT_B258D528_R
#define ZIG_SLICE_zT_1E07C3E5_Slice_zT_B258D528_R
typedef struct { zT_B258D528_RelatedSpan* ptr; unsigned int len; } zT_1E07C3E5_Slice_zT_B258D528_R;
#endif /* ZIG_SLICE_zT_1E07C3E5_Slice_zT_B258D528_R */
#ifndef ZIG_ARRAY_zT_4328DD4F_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_4328DD4F_Arr_unsigned_char_2
typedef unsigned char zT_4328DD4F_Arr_unsigned_char_2[27];
#endif /* ZIG_ARRAY_zT_4328DD4F_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_22590979_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_22590979_Arr_unsigned_char_2
typedef unsigned char zT_22590979_Arr_unsigned_char_2[256];
#endif /* ZIG_ARRAY_zT_22590979_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_5926C15A_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_5926C15A_Arr_unsigned_char_1
typedef unsigned char zT_5926C15A_Arr_unsigned_char_1[11];
#endif /* ZIG_ARRAY_zT_5926C15A_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_C81F2152_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_C81F2152_Arr_unsigned_char_6
typedef unsigned char zT_C81F2152_Arr_unsigned_char_6[60];
#endif /* ZIG_ARRAY_zT_C81F2152_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_4228DBBC_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_4228DBBC_Arr_unsigned_char_2
typedef unsigned char zT_4228DBBC_Arr_unsigned_char_2[26];
#endif /* ZIG_ARRAY_zT_4228DBBC_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_3F28D703_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_3F28D703_Arr_unsigned_char_2
typedef unsigned char zT_3F28D703_Arr_unsigned_char_2[23];
#endif /* ZIG_ARRAY_zT_3F28D703_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_3D19C953_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_3D19C953_Arr_unsigned_char_4
typedef unsigned char zT_3D19C953_Arr_unsigned_char_4[41];
#endif /* ZIG_ARRAY_zT_3D19C953_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_3E28D570_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_3E28D570_Arr_unsigned_char_2
typedef unsigned char zT_3E28D570_Arr_unsigned_char_2[22];
#endif /* ZIG_ARRAY_zT_3E28D570_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_4428DEE2_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_4428DEE2_Arr_unsigned_char_2
typedef unsigned char zT_4428DEE2_Arr_unsigned_char_2[24];
#endif /* ZIG_ARRAY_zT_4428DEE2_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_4019CE0C_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_4019CE0C_Arr_unsigned_char_4
typedef unsigned char zT_4019CE0C_Arr_unsigned_char_4[44];
#endif /* ZIG_ARRAY_zT_4019CE0C_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_115D5880_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_115D5880_Arr_unsigned_char_8
typedef unsigned char zT_115D5880_Arr_unsigned_char_8[8192];
#endif /* ZIG_ARRAY_zT_115D5880_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_3F19CC79_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_3F19CC79_Arr_unsigned_char_4
typedef unsigned char zT_3F19CC79_Arr_unsigned_char_4[43];
#endif /* ZIG_ARRAY_zT_3F19CC79_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_C41F1B06_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_C41F1B06_Arr_unsigned_char_6
typedef unsigned char zT_C41F1B06_Arr_unsigned_char_6[64];
#endif /* ZIG_ARRAY_zT_C41F1B06_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_4828E52E_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_4828E52E_Arr_unsigned_char_2
typedef unsigned char zT_4828E52E_Arr_unsigned_char_2[28];
#endif /* ZIG_ARRAY_zT_4828E52E_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_3E19CAE6_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_3E19CAE6_Arr_unsigned_char_4
typedef unsigned char zT_3E19CAE6_Arr_unsigned_char_4[42];
#endif /* ZIG_ARRAY_zT_3E19CAE6_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_4E2B2D37_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_4E2B2D37_Arr_unsigned_char_3
typedef unsigned char zT_4E2B2D37_Arr_unsigned_char_3[38];
#endif /* ZIG_ARRAY_zT_4E2B2D37_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_D2216FA7_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_D2216FA7_Arr_unsigned_char_7
typedef unsigned char zT_D2216FA7_Arr_unsigned_char_7[74];
#endif /* ZIG_ARRAY_zT_D2216FA7_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_C21CD949_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_C21CD949_Arr_unsigned_char_5
typedef unsigned char zT_C21CD949_Arr_unsigned_char_5[50];
#endif /* ZIG_ARRAY_zT_C21CD949_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_993A6923_Arr_unsigned_int_64
#define ZIG_ARRAY_zT_993A6923_Arr_unsigned_int_64
typedef unsigned int zT_993A6923_Arr_unsigned_int_64[64];
#endif /* ZIG_ARRAY_zT_993A6923_Arr_unsigned_int_64 */
#ifndef ZIG_ARRAY_zT_C21F17E0_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_C21F17E0_Arr_unsigned_char_6
typedef unsigned char zT_C21F17E0_Arr_unsigned_char_6[66];
#endif /* ZIG_ARRAY_zT_C21F17E0_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_894C14AF_Arr_unsigned_int_51
#define ZIG_ARRAY_zT_894C14AF_Arr_unsigned_int_51
typedef unsigned int zT_894C14AF_Arr_unsigned_int_51[512];
#endif /* ZIG_ARRAY_zT_894C14AF_Arr_unsigned_int_51 */
#ifndef ZIG_ARRAY_zT_D321713A_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_D321713A_Arr_unsigned_char_7
typedef unsigned char zT_D321713A_Arr_unsigned_char_7[77];
#endif /* ZIG_ARRAY_zT_D321713A_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_4D37F797_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4D37F797_Arr_unsigned_char_8
typedef unsigned char zT_4D37F797_Arr_unsigned_char_8[89];
#endif /* ZIG_ARRAY_zT_4D37F797_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_453A2996_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_453A2996_Arr_unsigned_char_9
typedef unsigned char zT_453A2996_Arr_unsigned_char_9[95];
#endif /* ZIG_ARRAY_zT_453A2996_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_D0216C81_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_D0216C81_Arr_unsigned_char_7
typedef unsigned char zT_D0216C81_Arr_unsigned_char_7[72];
#endif /* ZIG_ARRAY_zT_D0216C81_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_157C0A16_Arr_unsigned_int_25
#define ZIG_ARRAY_zT_157C0A16_Arr_unsigned_int_25
typedef unsigned int zT_157C0A16_Arr_unsigned_int_25[256];
#endif /* ZIG_ARRAY_zT_157C0A16_Arr_unsigned_int_25 */
#ifndef ZIG_ARRAY_zT_442B1D79_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_442B1D79_Arr_unsigned_char_3
typedef unsigned char zT_442B1D79_Arr_unsigned_char_3[36];
#endif /* ZIG_ARRAY_zT_442B1D79_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_4319D2C5_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_4319D2C5_Arr_unsigned_char_4
typedef unsigned char zT_4319D2C5_Arr_unsigned_char_4[47];
#endif /* ZIG_ARRAY_zT_4319D2C5_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_462B209F_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_462B209F_Arr_unsigned_char_3
typedef unsigned char zT_462B209F_Arr_unsigned_char_3[30];
#endif /* ZIG_ARRAY_zT_462B209F_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_432B1BE6_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_432B1BE6_Arr_unsigned_char_3
typedef unsigned char zT_432B1BE6_Arr_unsigned_char_3[37];
#endif /* ZIG_ARRAY_zT_432B1BE6_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_412B18C0_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_412B18C0_Arr_unsigned_char_3
typedef unsigned char zT_412B18C0_Arr_unsigned_char_3[35];
#endif /* ZIG_ARRAY_zT_412B18C0_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_C4003E6D_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C4003E6D_Arr_unsigned_char_1
typedef unsigned char zT_C4003E6D_Arr_unsigned_char_1[128];
#endif /* ZIG_ARRAY_zT_C4003E6D_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_CA1CE5E1_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_CA1CE5E1_Arr_unsigned_char_5
typedef unsigned char zT_CA1CE5E1_Arr_unsigned_char_5[58];
#endif /* ZIG_ARRAY_zT_CA1CE5E1_Arr_unsigned_char_5 */
#ifndef ZIG_SLICE_zT_E0618270_Slice_zT_3A105EF1_S
#define ZIG_SLICE_zT_E0618270_Slice_zT_3A105EF1_S
typedef struct { zT_3A105EF1_Symbol* ptr; unsigned int len; } zT_E0618270_Slice_zT_3A105EF1_S;
#endif /* ZIG_SLICE_zT_E0618270_Slice_zT_3A105EF1_S */
#ifndef ZIG_SLICE_zT_DD67D991_Slice_zT_060CD1EB_S
#define ZIG_SLICE_zT_DD67D991_Slice_zT_060CD1EB_S
typedef struct { zT_060CD1EB_SymbolTable* ptr; unsigned int len; } zT_DD67D991_Slice_zT_060CD1EB_S;
#endif /* ZIG_SLICE_zT_DD67D991_Slice_zT_060CD1EB_S */
#ifndef ZIG_SLICE_zT_6BDC94CF_Slice_zT_D155D06D_T
#define ZIG_SLICE_zT_6BDC94CF_Slice_zT_D155D06D_T
typedef struct { zT_D155D06D_Type* ptr; unsigned int len; } zT_6BDC94CF_Slice_zT_D155D06D_T;
#endif /* ZIG_SLICE_zT_6BDC94CF_Slice_zT_D155D06D_T */
#ifndef ZIG_ARRAY_zT_939EE900_Arr_unsigned_int_1
#define ZIG_ARRAY_zT_939EE900_Arr_unsigned_int_1
typedef unsigned int zT_939EE900_Arr_unsigned_int_1[1];
#endif /* ZIG_ARRAY_zT_939EE900_Arr_unsigned_int_1 */
#ifndef ZIG_ARRAY_zT_443A2803_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_443A2803_Arr_unsigned_char_9
typedef unsigned char zT_443A2803_Arr_unsigned_char_9[96];
#endif /* ZIG_ARRAY_zT_443A2803_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_4128DA29_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_4128DA29_Arr_unsigned_char_2
typedef unsigned char zT_4128DA29_Arr_unsigned_char_2[21];
#endif /* ZIG_ARRAY_zT_4128DA29_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_E596AE8E_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_E596AE8E_Arr_unsigned_char_7
typedef unsigned char zT_E596AE8E_Arr_unsigned_char_7[712];
#endif /* ZIG_ARRAY_zT_E596AE8E_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_3254A57B_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_3254A57B_Arr_unsigned_char_2
typedef unsigned char zT_3254A57B_Arr_unsigned_char_2[276];
#endif /* ZIG_ARRAY_zT_3254A57B_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_30FAD9D6_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_30FAD9D6_Arr_unsigned_char_1
typedef unsigned char zT_30FAD9D6_Arr_unsigned_char_1[143];
#endif /* ZIG_ARRAY_zT_30FAD9D6_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_BDF36908_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_BDF36908_Arr_unsigned_char_1
typedef unsigned char zT_BDF36908_Arr_unsigned_char_1[170];
#endif /* ZIG_ARRAY_zT_BDF36908_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_A44F48C3_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_A44F48C3_Arr_unsigned_char_2
typedef unsigned char zT_A44F48C3_Arr_unsigned_char_2[218];
#endif /* ZIG_ARRAY_zT_A44F48C3_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_A14D0573_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_A14D0573_Arr_unsigned_char_2
typedef unsigned char zT_A14D0573_Arr_unsigned_char_2[207];
#endif /* ZIG_ARRAY_zT_A14D0573_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_1CF7EE9D_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_1CF7EE9D_Arr_unsigned_char_3
typedef unsigned char zT_1CF7EE9D_Arr_unsigned_char_3[388];
#endif /* ZIG_ARRAY_zT_1CF7EE9D_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_10F59D22_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_10F59D22_Arr_unsigned_char_3
typedef unsigned char zT_10F59D22_Arr_unsigned_char_3[392];
#endif /* ZIG_ARRAY_zT_10F59D22_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_11F59EB5_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_11F59EB5_Arr_unsigned_char_3
typedef unsigned char zT_11F59EB5_Arr_unsigned_char_3[393];
#endif /* ZIG_ARRAY_zT_11F59EB5_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_C00276B8_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C00276B8_Arr_unsigned_char_1
typedef unsigned char zT_C00276B8_Arr_unsigned_char_1[112];
#endif /* ZIG_ARRAY_zT_C00276B8_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_A34F4730_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_A34F4730_Arr_unsigned_char_2
typedef unsigned char zT_A34F4730_Arr_unsigned_char_2[219];
#endif /* ZIG_ARRAY_zT_A34F4730_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_0D6A5B0E_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_0D6A5B0E_Arr_unsigned_char_5
typedef unsigned char zT_0D6A5B0E_Arr_unsigned_char_5[503];
#endif /* ZIG_ARRAY_zT_0D6A5B0E_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_C3027B71_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C3027B71_Arr_unsigned_char_1
typedef unsigned char zT_C3027B71_Arr_unsigned_char_1[111];
#endif /* ZIG_ARRAY_zT_C3027B71_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_17994603_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_17994603_Arr_unsigned_char_9
typedef unsigned char zT_17994603_Arr_unsigned_char_9[913];
#endif /* ZIG_ARRAY_zT_17994603_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_148A36C0_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_148A36C0_Arr_unsigned_char_9
typedef unsigned char zT_148A36C0_Arr_unsigned_char_9[970];
#endif /* ZIG_ARRAY_zT_148A36C0_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_16E21EDC_Arr_unsigned_char_3
#define ZIG_ARRAY_zT_16E21EDC_Arr_unsigned_char_3
typedef unsigned char zT_16E21EDC_Arr_unsigned_char_3[318];
#endif /* ZIG_ARRAY_zT_16E21EDC_Arr_unsigned_char_3 */
#ifndef ZIG_ARRAY_zT_B3F11AB3_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_B3F11AB3_Arr_unsigned_char_1
typedef unsigned char zT_B3F11AB3_Arr_unsigned_char_1[184];
#endif /* ZIG_ARRAY_zT_B3F11AB3_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_AA5190CC_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_AA5190CC_Arr_unsigned_char_2
typedef unsigned char zT_AA5190CC_Arr_unsigned_char_2[268];
#endif /* ZIG_ARRAY_zT_AA5190CC_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_C91CE44E_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_C91CE44E_Arr_unsigned_char_5
typedef unsigned char zT_C91CE44E_Arr_unsigned_char_5[59];
#endif /* ZIG_ARRAY_zT_C91CE44E_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_C51CDE02_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_C51CDE02_Arr_unsigned_char_5
typedef unsigned char zT_C51CDE02_Arr_unsigned_char_5[55];
#endif /* ZIG_ARRAY_zT_C51CDE02_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_C31CDADC_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_C31CDADC_Arr_unsigned_char_5
typedef unsigned char zT_C31CDADC_Arr_unsigned_char_5[57];
#endif /* ZIG_ARRAY_zT_C31CDADC_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_473A2CBC_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_473A2CBC_Arr_unsigned_char_9
typedef unsigned char zT_473A2CBC_Arr_unsigned_char_9[93];
#endif /* ZIG_ARRAY_zT_473A2CBC_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_CF216AEE_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_CF216AEE_Arr_unsigned_char_7
typedef unsigned char zT_CF216AEE_Arr_unsigned_char_7[73];
#endif /* ZIG_ARRAY_zT_CF216AEE_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_C71F1FBF_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_C71F1FBF_Arr_unsigned_char_6
typedef unsigned char zT_C71F1FBF_Arr_unsigned_char_6[63];
#endif /* ZIG_ARRAY_zT_C71F1FBF_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_4928E6C1_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_4928E6C1_Arr_unsigned_char_2
typedef unsigned char zT_4928E6C1_Arr_unsigned_char_2[29];
#endif /* ZIG_ARRAY_zT_4928E6C1_Arr_unsigned_char_2 */
#ifndef ZIG_ARRAY_zT_C5215B30_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_C5215B30_Arr_unsigned_char_7
typedef unsigned char zT_C5215B30_Arr_unsigned_char_7[79];
#endif /* ZIG_ARRAY_zT_C5215B30_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_C31F1973_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_C31F1973_Arr_unsigned_char_6
typedef unsigned char zT_C31F1973_Arr_unsigned_char_6[67];
#endif /* ZIG_ARRAY_zT_C31F1973_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_CD2167C8_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_CD2167C8_Arr_unsigned_char_7
typedef unsigned char zT_CD2167C8_Arr_unsigned_char_7[71];
#endif /* ZIG_ARRAY_zT_CD2167C8_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_C4027D04_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C4027D04_Arr_unsigned_char_1
typedef unsigned char zT_C4027D04_Arr_unsigned_char_1[116];
#endif /* ZIG_ARRAY_zT_C4027D04_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_BA002EAF_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_BA002EAF_Arr_unsigned_char_1
typedef unsigned char zT_BA002EAF_Arr_unsigned_char_1[122];
#endif /* ZIG_ARRAY_zT_BA002EAF_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_C01CD623_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_C01CD623_Arr_unsigned_char_5
typedef unsigned char zT_C01CD623_Arr_unsigned_char_5[52];
#endif /* ZIG_ARRAY_zT_C01CD623_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_BF1CD490_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_BF1CD490_Arr_unsigned_char_5
typedef unsigned char zT_BF1CD490_Arr_unsigned_char_5[53];
#endif /* ZIG_ARRAY_zT_BF1CD490_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_C41CDC6F_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_C41CDC6F_Arr_unsigned_char_5
typedef unsigned char zT_C41CDC6F_Arr_unsigned_char_5[56];
#endif /* ZIG_ARRAY_zT_C41CDC6F_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_D1216E14_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_D1216E14_Arr_unsigned_char_7
typedef unsigned char zT_D1216E14_Arr_unsigned_char_7[75];
#endif /* ZIG_ARRAY_zT_D1216E14_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_4C37F604_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4C37F604_Arr_unsigned_char_8
typedef unsigned char zT_4C37F604_Arr_unsigned_char_8[88];
#endif /* ZIG_ARRAY_zT_4C37F604_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_C91F22E5_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_C91F22E5_Arr_unsigned_char_6
typedef unsigned char zT_C91F22E5_Arr_unsigned_char_6[61];
#endif /* ZIG_ARRAY_zT_C91F22E5_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_C11CD7B6_Arr_unsigned_char_5
#define ZIG_ARRAY_zT_C11CD7B6_Arr_unsigned_char_5
typedef unsigned char zT_C11CD7B6_Arr_unsigned_char_5[51];
#endif /* ZIG_ARRAY_zT_C11CD7B6_Arr_unsigned_char_5 */
#ifndef ZIG_ARRAY_zT_D11F2F7D_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_D11F2F7D_Arr_unsigned_char_6
typedef unsigned char zT_D11F2F7D_Arr_unsigned_char_6[69];
#endif /* ZIG_ARRAY_zT_D11F2F7D_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_1D9B8E0C_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_1D9B8E0C_Arr_unsigned_char_9
typedef unsigned char zT_1D9B8E0C_Arr_unsigned_char_9[901];
#endif /* ZIG_ARRAY_zT_1D9B8E0C_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_C3F3727A_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C3F3727A_Arr_unsigned_char_1
typedef unsigned char zT_C3F3727A_Arr_unsigned_char_1[176];
#endif /* ZIG_ARRAY_zT_C3F3727A_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_31FD1A00_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_31FD1A00_Arr_unsigned_char_1
typedef unsigned char zT_31FD1A00_Arr_unsigned_char_1[134];
#endif /* ZIG_ARRAY_zT_31FD1A00_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_B4F11C46_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_B4F11C46_Arr_unsigned_char_1
typedef unsigned char zT_B4F11C46_Arr_unsigned_char_1[187];
#endif /* ZIG_ARRAY_zT_B4F11C46_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_FFFC67A7_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_FFFC67A7_Arr_unsigned_char_6
typedef unsigned char zT_FFFC67A7_Arr_unsigned_char_6[621];
#endif /* ZIG_ARRAY_zT_FFFC67A7_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_BB003042_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_BB003042_Arr_unsigned_char_1
typedef unsigned char zT_BB003042_Arr_unsigned_char_1[121];
#endif /* ZIG_ARRAY_zT_BB003042_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_6D03CF03_Arr_unsigned_char_6
#define ZIG_ARRAY_zT_6D03CF03_Arr_unsigned_char_6
typedef unsigned char zT_6D03CF03_Arr_unsigned_char_6[614];
#endif /* ZIG_ARRAY_zT_6D03CF03_Arr_unsigned_char_6 */
#ifndef ZIG_ARRAY_zT_AFEED5D0_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_AFEED5D0_Arr_unsigned_char_1
typedef unsigned char zT_AFEED5D0_Arr_unsigned_char_1[192];
#endif /* ZIG_ARRAY_zT_AFEED5D0_Arr_unsigned_char_1 */
#ifndef ZIG_SLICE_zT_8253866A_Slice_zT_FEED5D3B_S
#define ZIG_SLICE_zT_8253866A_Slice_zT_FEED5D3B_S
typedef struct { zT_FEED5D3B_ScopeNode* ptr; unsigned int len; } zT_8253866A_Slice_zT_FEED5D3B_S;
#endif /* ZIG_SLICE_zT_8253866A_Slice_zT_FEED5D3B_S */
#ifndef ZIG_ARRAY_zT_99292002_Arr_unsigned_int_16
#define ZIG_ARRAY_zT_99292002_Arr_unsigned_int_16
typedef unsigned int zT_99292002_Arr_unsigned_int_16[16];
#endif /* ZIG_ARRAY_zT_99292002_Arr_unsigned_int_16 */
#ifndef ZIG_ARRAY_zT_C604BEC1_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C604BEC1_Arr_unsigned_char_1
typedef unsigned char zT_C604BEC1_Arr_unsigned_char_1[106];
#endif /* ZIG_ARRAY_zT_C604BEC1_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_C304BA08_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C304BA08_Arr_unsigned_char_1
typedef unsigned char zT_C304BA08_Arr_unsigned_char_1[105];
#endif /* ZIG_ARRAY_zT_C304BA08_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_B9002D1C_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_B9002D1C_Arr_unsigned_char_1
typedef unsigned char zT_B9002D1C_Arr_unsigned_char_1[123];
#endif /* ZIG_ARRAY_zT_B9002D1C_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_523A3E0D_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_523A3E0D_Arr_unsigned_char_9
typedef unsigned char zT_523A3E0D_Arr_unsigned_char_9[98];
#endif /* ZIG_ARRAY_zT_523A3E0D_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_513A3C7A_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_513A3C7A_Arr_unsigned_char_9
typedef unsigned char zT_513A3C7A_Arr_unsigned_char_9[99];
#endif /* ZIG_ARRAY_zT_513A3C7A_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_989EF0DF_Arr_unsigned_int_4
#define ZIG_ARRAY_zT_989EF0DF_Arr_unsigned_int_4
typedef unsigned int zT_989EF0DF_Arr_unsigned_int_4[4];
#endif /* ZIG_ARRAY_zT_989EF0DF_Arr_unsigned_int_4 */
#ifndef ZIG_ARRAY_zT_B2425549_Arr_unsigned_char_2
#define ZIG_ARRAY_zT_B2425549_Arr_unsigned_char_2
typedef unsigned char zT_B2425549_Arr_unsigned_char_2[2045];
#endif /* ZIG_ARRAY_zT_B2425549_Arr_unsigned_char_2 */
#ifndef ZIG_SLICE_zT_5B0DCA45_Slice_zT_9CDC9863_C
#define ZIG_SLICE_zT_5B0DCA45_Slice_zT_9CDC9863_C
typedef struct { zT_9CDC9863_CoercionEntry* ptr; unsigned int len; } zT_5B0DCA45_Slice_zT_9CDC9863_C;
#endif /* ZIG_SLICE_zT_5B0DCA45_Slice_zT_9CDC9863_C */
#ifndef ZIG_ARRAY_zT_4419D458_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_4419D458_Arr_unsigned_char_4
typedef unsigned char zT_4419D458_Arr_unsigned_char_4[48];
#endif /* ZIG_ARRAY_zT_4419D458_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_BF04B3BC_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_BF04B3BC_Arr_unsigned_char_1
typedef unsigned char zT_BF04B3BC_Arr_unsigned_char_1[109];
#endif /* ZIG_ARRAY_zT_BF04B3BC_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_4037E320_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4037E320_Arr_unsigned_char_8
typedef unsigned char zT_4037E320_Arr_unsigned_char_8[84];
#endif /* ZIG_ARRAY_zT_4037E320_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_C804C1E7_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C804C1E7_Arr_unsigned_char_1
typedef unsigned char zT_C804C1E7_Arr_unsigned_char_1[100];
#endif /* ZIG_ARRAY_zT_C804C1E7_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_C704C054_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C704C054_Arr_unsigned_char_1
typedef unsigned char zT_C704C054_Arr_unsigned_char_1[101];
#endif /* ZIG_ARRAY_zT_C704C054_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_D42172CD_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_D42172CD_Arr_unsigned_char_7
typedef unsigned char zT_D42172CD_Arr_unsigned_char_7[76];
#endif /* ZIG_ARRAY_zT_D42172CD_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_4437E96C_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4437E96C_Arr_unsigned_char_8
typedef unsigned char zT_4437E96C_Arr_unsigned_char_8[80];
#endif /* ZIG_ARRAY_zT_4437E96C_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_4A3A3175_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_4A3A3175_Arr_unsigned_char_9
typedef unsigned char zT_4A3A3175_Arr_unsigned_char_9[90];
#endif /* ZIG_ARRAY_zT_4A3A3175_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_CA04C50D_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_CA04C50D_Arr_unsigned_char_1
typedef unsigned char zT_CA04C50D_Arr_unsigned_char_1[102];
#endif /* ZIG_ARRAY_zT_CA04C50D_Arr_unsigned_char_1 */
#ifndef ZIG_SLICE_zT_D868CF46_Slice_zT_52CDA6EF_D
#define ZIG_SLICE_zT_D868CF46_Slice_zT_52CDA6EF_D
typedef struct { zT_52CDA6EF_DepEdge* ptr; unsigned int len; } zT_D868CF46_Slice_zT_52CDA6EF_D;
#endif /* ZIG_SLICE_zT_D868CF46_Slice_zT_52CDA6EF_D */
#ifndef ZIG_ARRAY_zT_9D2DA37C_Arr_unsigned_int_32
#define ZIG_ARRAY_zT_9D2DA37C_Arr_unsigned_int_32
typedef unsigned int zT_9D2DA37C_Arr_unsigned_int_32[32];
#endif /* ZIG_ARRAY_zT_9D2DA37C_Arr_unsigned_int_32 */
#ifndef ZIG_ARRAY_zT_EDD37787_Arr_unsigned_short_
#define ZIG_ARRAY_zT_EDD37787_Arr_unsigned_short_
typedef unsigned short zT_EDD37787_Arr_unsigned_short_[1];
#endif /* ZIG_ARRAY_zT_EDD37787_Arr_unsigned_short_ */
#ifndef ZIG_ARRAY_zT_4537EAFF_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4537EAFF_Arr_unsigned_char_8
typedef unsigned char zT_4537EAFF_Arr_unsigned_char_8[81];
#endif /* ZIG_ARRAY_zT_4537EAFF_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_CE21695B_Arr_unsigned_char_7
#define ZIG_ARRAY_zT_CE21695B_Arr_unsigned_char_7
typedef unsigned char zT_CE21695B_Arr_unsigned_char_7[70];
#endif /* ZIG_ARRAY_zT_CE21695B_Arr_unsigned_char_7 */
#ifndef ZIG_ARRAY_zT_C904C37A_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C904C37A_Arr_unsigned_char_1
typedef unsigned char zT_C904C37A_Arr_unsigned_char_1[103];
#endif /* ZIG_ARRAY_zT_C904C37A_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_4219D132_Arr_unsigned_char_4
#define ZIG_ARRAY_zT_4219D132_Arr_unsigned_char_4
typedef unsigned char zT_4219D132_Arr_unsigned_char_4[46];
#endif /* ZIG_ARRAY_zT_4219D132_Arr_unsigned_char_4 */
#ifndef ZIG_ARRAY_zT_433A2670_Arr_unsigned_char_9
#define ZIG_ARRAY_zT_433A2670_Arr_unsigned_char_9
typedef unsigned char zT_433A2670_Arr_unsigned_char_9[97];
#endif /* ZIG_ARRAY_zT_433A2670_Arr_unsigned_char_9 */
#ifndef ZIG_ARRAY_zT_4337E7D9_Arr_unsigned_char_8
#define ZIG_ARRAY_zT_4337E7D9_Arr_unsigned_char_8
typedef unsigned char zT_4337E7D9_Arr_unsigned_char_8[87];
#endif /* ZIG_ARRAY_zT_4337E7D9_Arr_unsigned_char_8 */
#ifndef ZIG_ARRAY_zT_BC0031D5_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_BC0031D5_Arr_unsigned_char_1
typedef unsigned char zT_BC0031D5_Arr_unsigned_char_1[120];
#endif /* ZIG_ARRAY_zT_BC0031D5_Arr_unsigned_char_1 */
#ifndef ZIG_ARRAY_zT_C504BD2E_Arr_unsigned_char_1
#define ZIG_ARRAY_zT_C504BD2E_Arr_unsigned_char_1
typedef unsigned char zT_C504BD2E_Arr_unsigned_char_1[107];
#endif /* ZIG_ARRAY_zT_C504BD2E_Arr_unsigned_char_1 */
#ifndef ZIG_STRUCT_zT_2B3424E9_ParseToken
#define ZIG_STRUCT_zT_2B3424E9_ParseToken
struct zT_2B3424E9_ParseToken {
	zT_EAC3E484_TokenKind kind;
	unsigned int span_start;
	unsigned short span_len;
};
#endif /* ZIG_STRUCT_zT_2B3424E9_ParseToken */
#ifndef ZIG_STRUCT_zT_3A355BD2_Token
#define ZIG_STRUCT_zT_3A355BD2_Token
struct zT_3A355BD2_Token {
	zT_EAC3E484_TokenKind kind;
	unsigned int span_start;
	unsigned short span_len;
	zT_85CBA4DB_TokenValue value;
};
#endif /* ZIG_STRUCT_zT_3A355BD2_Token */
#ifndef ZIG_STRUCT_zT_F4EBEA72_OpInfo
#define ZIG_STRUCT_zT_F4EBEA72_OpInfo
struct zT_F4EBEA72_OpInfo {
	zT_2B10107F_Prec prec;
	int right_assoc;
};
#endif /* ZIG_STRUCT_zT_F4EBEA72_OpInfo */
#ifndef ZIG_STRUCT_zT_22A7C88B_AstNode
#define ZIG_STRUCT_zT_22A7C88B_AstNode
struct zT_22A7C88B_AstNode {
	zT_8143F551_AstKind kind;
	unsigned char flags;
	unsigned int span_len;
	unsigned int span_start;
	unsigned int child_0;
	unsigned int child_1;
	unsigned int child_2;
};
#endif /* ZIG_STRUCT_zT_22A7C88B_AstNode */
#ifndef ZIG_ARRAY_zT_6C253597_Arr_zT_6DD0D007_Ast
#define ZIG_ARRAY_zT_6C253597_Arr_zT_6DD0D007_Ast
typedef zT_6DD0D007_AstSlot zT_6C253597_Arr_zT_6DD0D007_Ast[8];
#endif /* ZIG_ARRAY_zT_6C253597_Arr_zT_6DD0D007_Ast */
#ifndef ZIG_STRUCT_zT_4DB1475B_ModuleResolver
#define ZIG_STRUCT_zT_4DB1475B_ModuleResolver
struct zT_4DB1475B_ModuleResolver {
	zT_4EA49A91_SearchDirArrayList search_dirs;
	zT_D3EB6303_StringInterner* interner;
	zT_F85C5DED_DiagnosticCollector* diag;
};
#endif /* ZIG_STRUCT_zT_4DB1475B_ModuleResolver */
#ifndef ZIG_OPTIONAL_zT_D0D475FB_Opt_118
#define ZIG_OPTIONAL_zT_D0D475FB_Opt_118
typedef struct { zT_438E6589_NullGuard value; int has_value; } zT_D0D475FB_Opt_118;
#endif /* ZIG_OPTIONAL_zT_D0D475FB_Opt_118 */
#ifndef ZIG_STRUCT_zT_3A105EF1_Symbol
#define ZIG_STRUCT_zT_3A105EF1_Symbol
struct zT_3A105EF1_Symbol {
	unsigned int name_id;
	unsigned int type_id;
	zT_3C598AEF_SymbolKind kind;
	unsigned short flags;
	unsigned int decl_node;
	unsigned int module_id;
	unsigned int scope_level;
};
#endif /* ZIG_STRUCT_zT_3A105EF1_Symbol */
#ifndef ZIG_STRUCT_zT_D155D06D_Type
#define ZIG_STRUCT_zT_D155D06D_Type
struct zT_D155D06D_Type {
	zT_33EF6BFB_TypeKind kind;
	unsigned char state;
	unsigned char flags;
	unsigned char is_signed;
	unsigned char width_bits;
	unsigned int size;
	unsigned int alignment;
	unsigned int name_id;
	unsigned int c_name_id;
	unsigned int module_id;
	unsigned int payload_idx;
};
#endif /* ZIG_STRUCT_zT_D155D06D_Type */
#ifndef ZIG_OPTIONAL_zT_CED6B16C_Opt_160
#define ZIG_OPTIONAL_zT_CED6B16C_Opt_160
typedef struct { zT_573A3319_LocalBinding value; int has_value; } zT_CED6B16C_Opt_160;
#endif /* ZIG_OPTIONAL_zT_CED6B16C_Opt_160 */
#ifndef ZIG_OPTIONAL_zT_D0D6B492_Opt_162
#define ZIG_OPTIONAL_zT_D0D6B492_Opt_162
typedef struct { zT_DCBFE211_CallInfo value; int has_value; } zT_D0D6B492_Opt_162;
#endif /* ZIG_OPTIONAL_zT_D0D6B492_Opt_162 */
#ifndef ZIG_UNION_zT_A8A5B231_LirSideEntry
#define ZIG_UNION_zT_A8A5B231_LirSideEntry
union zT_A8A5B231_LirSideEntry {
	zT_3BFB1E70_CallDirectData call_direct;
	zT_0624AC1B_TailCallData tail_call;
};
#endif /* ZIG_UNION_zT_A8A5B231_LirSideEntry */
#ifndef ZIG_STRUCT_zT_88A68B1A_BasicBlock
#define ZIG_STRUCT_zT_88A68B1A_BasicBlock
struct zT_88A68B1A_BasicBlock {
	unsigned int id;
	zT_DAE4631D_LirInstArrayList insts;
	unsigned char is_terminated;
};
#endif /* ZIG_STRUCT_zT_88A68B1A_BasicBlock */
#ifndef ZIG_STRUCT_zT_02EB57B2_LirLowerer
#define ZIG_STRUCT_zT_02EB57B2_LirLowerer
struct zT_02EB57B2_LirLowerer {
	zT_6B356268_SemanticContext* ctx;
	zT_BBC23664_LirFunction* func;
	unsigned int current_bb;
	unsigned int temp_counter;
	zT_A528929E_DeferActionArrayLis defer_stack;
	zT_5819C854_LoopInfoArrayList loop_stack;
	zT_347CB10E_SwitchInfoArrayList switch_stack;
	zT_5D72FBF8_TempDeclArrayList hoisted_temps;
	zT_3E40CD83_Sand* alloc;
	unsigned int scope_depth;
	unsigned char block_terminated;
	unsigned char suppress_fnref_ban;
	unsigned int module_id;
	zT_072B53A6_ModuleRegistry* module_reg;
	unsigned int intcast_name_id;
	unsigned int inttofloat_name_id;
	unsigned int print_fn_id;
	unsigned int ptrcast_name_id;
	unsigned int volatilecast_name_id;
	unsigned int ptrtoint_name_id;
	unsigned int inttoptr_name_id;
	unsigned int int_from_ptr_name_id;
	unsigned int ptr_from_int_name_id;
	unsigned int field_parent_ptr_name_id;
	unsigned int enumtoint_name_id;
	unsigned int inttoenum_name_id;
	unsigned int as_name_id;
	unsigned int bitcast_name_id;
	unsigned int size_of_name_id;
	unsigned int align_of_name_id;
	unsigned int offset_of_name_id;
	unsigned int bit_size_of_name_id;
	unsigned int bit_offset_of_name_id;
	unsigned int cvastart_name_id;
	unsigned int cvaarg_name_id;
	unsigned int cvaend_name_id;
	unsigned int putchar_name_id;
	unsigned int stdout_write_name_id;
	unsigned int stderr_write_name_id;
	unsigned int getchar_name_id;
	unsigned int exit_name_id;
	unsigned int panic_name_id;
	unsigned int sleep_ms_name_id;
	unsigned int is_windows_name_id;
	unsigned int console_clear_name_id;
	unsigned int console_gotoxy_name_id;
	unsigned int console_set_color_name_id;
	unsigned int async_frame_size_name_id;
	unsigned int async_init_name_id;
	unsigned int async_resume_name_id;
	unsigned int async_suspend_name_id;
	unsigned int* local_decl_names;
	unsigned int* local_decl_src_names;
	unsigned int* local_decl_types;
	unsigned int* local_decl_temps;
	unsigned char* local_decl_kinds;
	unsigned char* local_decl_is_capture;
	unsigned int* local_decl_scopes;
	unsigned int* local_decl_scope_nodes;
	unsigned int* local_decl_fn;
	unsigned int local_decl_cap;
	zT_21D3708C_U32ToU32Map local_decl_name_map;
	unsigned int local_decl_count;
	zT_2F2F63D8_ScopeNodeArrayList scope_nodes;
	unsigned int cur_scope;
	unsigned int pending_scope;
	unsigned int fn_seq;
	unsigned int _fn_ret_type;
	unsigned int _ctx_node_idx;
	unsigned int _ctx_node_kind;
	zT_21D3708C_U32ToU32Map capture_shadow;
	unsigned int synth_name_counter;
	unsigned int current_label;
};
#endif /* ZIG_STRUCT_zT_02EB57B2_LirLowerer */
#ifndef ZIG_STRUCT_zT_BBC23664_LirFunction
#define ZIG_STRUCT_zT_BBC23664_LirFunction
struct zT_BBC23664_LirFunction {
	unsigned int name_id;
	unsigned int module_id;
	unsigned int return_type;
	zT_CFE23D0A_LirParamArrayList params;
	zT_1CF28CA3_BasicBlockArrayList blocks;
	zT_5D72FBF8_TempDeclArrayList hoisted_temps;
	zT_9F514E82_SwitchCaseArrayList switch_cases;
	zT_AC00B5F6_LirSideEntryArrayLi side_table;
	zT_21D3708C_U32ToU32Map temp_variant_sub_field;
	unsigned char is_extern;
	unsigned char is_pub;
	unsigned char is_variadic;
	unsigned char call_conv;
	unsigned char poison_uninit;
	unsigned char is_export;
};
#endif /* ZIG_STRUCT_zT_BBC23664_LirFunction */
#ifndef ZIG_STRUCT_zT_66E7D2EF_CoercionTable
#define ZIG_STRUCT_zT_66E7D2EF_CoercionTable
struct zT_66E7D2EF_CoercionTable {
	zT_9CDC9863_CoercionEntry* entries_items;
	unsigned int entries_len;
	unsigned int entries_cap;
	zT_3E40CD83_Sand* entries_alloc;
	zT_21D3708C_U32ToU32Map index;
};
#endif /* ZIG_STRUCT_zT_66E7D2EF_CoercionTable */
#ifndef ZIG_STRUCT_zT_338B7C76_TypeRegistry
#define ZIG_STRUCT_zT_338B7C76_TypeRegistry
struct zT_338B7C76_TypeRegistry {
	zT_D155D06D_Type* types_items;
	unsigned int types_len;
	unsigned int types_cap;
	zT_3E40CD83_Sand* types_alloc;
	zT_D3EB6303_StringInterner* interner;
	zT_112BF819_PtrPayload* ptr_items;
	unsigned int ptr_len;
	unsigned int ptr_cap;
	zT_E834303C_ArrayPayload* array_items;
	unsigned int array_len;
	unsigned int array_cap;
	zT_0BB2A741_SlicePayload* slice_items;
	unsigned int slice_len;
	unsigned int slice_cap;
	zT_0B10E8E9_OptionalPayload* opt_items;
	unsigned int opt_len;
	unsigned int opt_cap;
	zT_42C2D6BF_EUPayload* eu_items;
	unsigned int eu_len;
	unsigned int eu_cap;
	zT_0B73C507_ErrorSetPayload* es_items;
	unsigned int es_len;
	unsigned int es_cap;
	zT_0317B1D5_FnPayload* fn_items;
	unsigned int fn_len;
	unsigned int fn_cap;
	zT_406493CE_StructPayload* st_items;
	unsigned int st_len;
	unsigned int st_cap;
	zT_457ECFEE_EnumPayload* en_items;
	unsigned int en_len;
	unsigned int en_cap;
	zT_AF9231A2_UnionPayload* un_items;
	unsigned int un_len;
	unsigned int un_cap;
	zT_54FF90FA_TaggedUnionPayload* tu_items;
	unsigned int tu_len;
	unsigned int tu_cap;
	zT_666DC2E1_TuplePayload* tup_items;
	unsigned int tup_len;
	unsigned int tup_cap;
	zT_42E798B0_UnresolvedPayload* unr_items;
	unsigned int unr_len;
	unsigned int unr_cap;
	zT_2DF01B61_FieldEntry* fe_items;
	unsigned int fe_len;
	unsigned int fe_cap;
	zT_D96DCDF2_EnumMember* em_items;
	unsigned int em_len;
	unsigned int em_cap;
	unsigned int* xt_items;
	unsigned int xt_len;
	unsigned int xt_cap;
	unsigned int* xn_items;
	unsigned int xn_len;
	unsigned int xn_cap;
	zT_E276DDD0_PackedBitField* pk_items;
	unsigned int pk_len;
	unsigned int pk_cap;
	zT_FA398D58_PackedStructInfo* pk_struct_items;
	unsigned int pk_struct_len;
	unsigned int pk_struct_cap;
	zT_FA398D58_PackedStructInfo* pk_un_items;
	unsigned int pk_un_len;
	unsigned int pk_un_cap;
	zT_A4CE86B7_U64ToU32Map ptr_cache;
	zT_A4CE86B7_U64ToU32Map many_ptr_cache;
	zT_A4CE86B7_U64ToU32Map slice_cache;
	zT_21D3708C_U32ToU32Map optional_cache;
	zT_A4CE86B7_U64ToU32Map array_cache;
	zT_A4CE86B7_U64ToU32Map eu_cache;
	zT_A4CE86B7_U64ToU32Map es_cache;
	zT_A4CE86B7_U64ToU32Map name_cache;
};
#endif /* ZIG_STRUCT_zT_338B7C76_TypeRegistry */
#ifndef ZIG_STRUCT_zT_6E8D187B_ModuleEntry
#define ZIG_STRUCT_zT_6E8D187B_ModuleEntry
struct zT_6E8D187B_ModuleEntry {
	unsigned int id;
	unsigned int path_id;
	unsigned int source_file_id;
	zT_9FE1BFFE_ModuleState state;
	unsigned int ast_root;
	unsigned int import_count;
	unsigned int imports_start;
	unsigned int symbol_table;
	unsigned int type_offset;
	zT_B687BB96_U32ArrayList c_includes;
};
#endif /* ZIG_STRUCT_zT_6E8D187B_ModuleEntry */
#ifndef ZIG_STRUCT_zT_9CDC9863_CoercionEntry
#define ZIG_STRUCT_zT_9CDC9863_CoercionEntry
struct zT_9CDC9863_CoercionEntry {
	unsigned int node_idx;
	zT_0FB7FB13_CoercionKind kind;
	unsigned int target_type;
};
#endif /* ZIG_STRUCT_zT_9CDC9863_CoercionEntry */
#ifndef ZIG_STRUCT_zT_38C12417_SemanticAnalyzer
#define ZIG_STRUCT_zT_38C12417_SemanticAnalyzer
struct zT_38C12417_SemanticAnalyzer {
	zT_8EED1867_ResolvedTypeTable* type_table;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_338B7C76_TypeRegistry* registry;
	zT_3D7259E2_SymbolRegistry* symbols;
	zT_6B0A7D14_AstStore* store;
	unsigned int module_id;
	unsigned int source_file_id;
	unsigned int* expected_type_stack_items;
	unsigned int expected_type_stack_len;
	unsigned int expected_type_stack_cap;
	zT_3E40CD83_Sand* expected_type_stack_alloc;
	unsigned int* stmt_work_items;
	unsigned int stmt_work_len;
	unsigned int stmt_work_cap;
	unsigned int current_fn_return;
	unsigned int current_fn_name;
	zT_66E7D2EF_CoercionTable* coercion_table;
	zT_21D3708C_U32ToU32Map* enum_value_table;
	zT_21D3708C_U32ToU32Map* error_code_registry;
	zT_21D3708C_U32ToU32Map* call_arg_types;
	zT_21D3708C_U32ToU32Map* call_param_map;
	unsigned int current_switch_cond_tu;
	unsigned int switch_depth;
	unsigned int defer_depth;
	unsigned int* local_decl_names;
	unsigned int* local_decl_types;
	unsigned int local_decl_count;
	unsigned int local_decl_cap;
	zT_E2DF2801_LocalConstScope local_consts;
	unsigned int* packed_gate_items;
	unsigned int packed_gate_len;
	unsigned int packed_gate_cap;
	unsigned int* packed_struct_tids;
	unsigned int* packed_struct_decl_nodes;
	unsigned int packed_struct_cache_len;
	unsigned int packed_struct_cache_cap;
	unsigned int* checked_struct_tids;
	unsigned int checked_struct_tids_len;
	unsigned int checked_struct_tids_cap;
	unsigned int _stub_0;
	unsigned int _stub_1;
	zT_D3EB6303_StringInterner* interner;
	unsigned int ptrcast_name_id;
	unsigned int volatilecast_name_id;
	unsigned int ptrtoint_name_id;
	unsigned int inttoptr_name_id;
	unsigned int int_from_ptr_name_id;
	unsigned int ptr_from_int_name_id;
	unsigned int field_parent_ptr_name_id;
	unsigned int bitcast_name_id;
	unsigned int intcast_name_id;
	unsigned int floatcast_name_id;
	unsigned int inttofloat_name_id;
	unsigned int inttoenum_name_id;
	unsigned int enumtoint_name_id;
	unsigned int as_name_id;
	unsigned int size_of_name_id;
	unsigned int align_of_name_id;
	unsigned int offset_of_name_id;
	unsigned int bit_size_of_name_id;
	unsigned int bit_offset_of_name_id;
	unsigned int putchar_name_id;
	unsigned int stdout_write_name_id;
	unsigned int stderr_write_name_id;
	unsigned int getchar_name_id;
	unsigned int exit_name_id;
	unsigned int panic_name_id;
	unsigned int sleep_ms_name_id;
	unsigned int is_windows_name_id;
	unsigned int console_clear_name_id;
	unsigned int console_gotoxy_name_id;
	unsigned int console_set_color_name_id;
	unsigned int async_frame_size_name_id;
	unsigned int async_init_name_id;
	unsigned int async_resume_name_id;
	unsigned int async_suspend_name_id;
	int async_analysis_ready;
	zT_072B53A6_ModuleRegistry* module_reg;
	zT_A4CE86B7_U64ToU32Map* suspending_fns;
};
#endif /* ZIG_STRUCT_zT_38C12417_SemanticAnalyzer */
#ifndef ZIG_OPTIONAL_zT_E33A227C_Opt_201
#define ZIG_OPTIONAL_zT_E33A227C_Opt_201
typedef struct { zT_89B1DDDA_ComptimeVal value; int has_value; } zT_E33A227C_Opt_201;
#endif /* ZIG_OPTIONAL_zT_E33A227C_Opt_201 */
#ifndef ZIG_STRUCT_zT_3F3BF87A_AsyncFrameLayout
#define ZIG_STRUCT_zT_3F3BF87A_AsyncFrameLayout
struct zT_3F3BF87A_AsyncFrameLayout {
	zT_2CF63CE1_AsyncFrameFieldArra fields;
	unsigned int layout_size;
};
#endif /* ZIG_STRUCT_zT_3F3BF87A_AsyncFrameLayout */
#ifndef ZIG_STRUCT_zT_C1009AE8_KeywordEntry
#define ZIG_STRUCT_zT_C1009AE8_KeywordEntry
struct zT_C1009AE8_KeywordEntry {
	zT_8F083A69_Slice_zT_0B42B2F8_u name;
	zT_EAC3E484_TokenKind kind;
};
#endif /* ZIG_STRUCT_zT_C1009AE8_KeywordEntry */
#ifndef ZIG_ARRAY_zT_4C214FEE_Arr_zT_8F083A69_Sli
#define ZIG_ARRAY_zT_4C214FEE_Arr_zT_8F083A69_Sli
typedef zT_8F083A69_Slice_zT_0B42B2F8_u zT_4C214FEE_Arr_zT_8F083A69_Sli[3];
#endif /* ZIG_ARRAY_zT_4C214FEE_Arr_zT_8F083A69_Sli */
#ifndef ZIG_ARRAY_zT_4F2154A7_Arr_zT_8F083A69_Sli
#define ZIG_ARRAY_zT_4F2154A7_Arr_zT_8F083A69_Sli
typedef zT_8F083A69_Slice_zT_0B42B2F8_u zT_4F2154A7_Arr_zT_8F083A69_Sli[4];
#endif /* ZIG_ARRAY_zT_4F2154A7_Arr_zT_8F083A69_Sli */
#ifndef ZIG_ARRAY_zT_4A214CC8_Arr_zT_8F083A69_Sli
#define ZIG_ARRAY_zT_4A214CC8_Arr_zT_8F083A69_Sli
typedef zT_8F083A69_Slice_zT_0B42B2F8_u zT_4A214CC8_Arr_zT_8F083A69_Sli[1];
#endif /* ZIG_ARRAY_zT_4A214CC8_Arr_zT_8F083A69_Sli */
#ifndef ZIG_ARRAY_zT_5021563A_Arr_zT_8F083A69_Sli
#define ZIG_ARRAY_zT_5021563A_Arr_zT_8F083A69_Sli
typedef zT_8F083A69_Slice_zT_0B42B2F8_u zT_5021563A_Arr_zT_8F083A69_Sli[7];
#endif /* ZIG_ARRAY_zT_5021563A_Arr_zT_8F083A69_Sli */
#ifndef ZIG_STRUCT_zT_50FBF81E_Diagnostic
#define ZIG_STRUCT_zT_50FBF81E_Diagnostic
struct zT_50FBF81E_Diagnostic {
	unsigned char level;
	unsigned short code;
	unsigned int file_id;
	unsigned int span_start;
	unsigned int span_end;
	unsigned int message_id;
	unsigned char note_count;
	zT_959EEC26_Arr_unsigned_int_3 note_ids;
	unsigned short related_span_idx;
};
#endif /* ZIG_STRUCT_zT_50FBF81E_Diagnostic */
#ifndef ZIG_STRUCT_zT_63BE4FF5_BufferedWriter
#define ZIG_STRUCT_zT_63BE4FF5_BufferedWriter
struct zT_63BE4FF5_BufferedWriter {
	zT_47D166B7_Arr_unsigned_char_4 buf;
	unsigned int pos;
	unsigned int fd;
};
#endif /* ZIG_STRUCT_zT_63BE4FF5_BufferedWriter */
#ifndef ZIG_STRUCT_zT_CEC2984A_NameMangler_1
#define ZIG_STRUCT_zT_CEC2984A_NameMangler_1
struct zT_CEC2984A_NameMangler_1 {
	unsigned int hash_seed;
	zT_A4CE86B7_U64ToU32Map cache;
	zT_21D3708C_U32ToU32Map keyword_set;
	zT_21D3708C_U32ToU32Map collision_mod;
	zT_21D3708C_U32ToU32Map collision_name;
	zT_D3EB6303_StringInterner* interner;
	zT_F04B8014_Opt_296 exported;
};
#endif /* ZIG_STRUCT_zT_CEC2984A_NameMangler_1 */
#ifndef ZIG_STRUCT_zT_6BA597BC_LirInst
#define ZIG_STRUCT_zT_6BA597BC_LirInst
#define zT_6BA597BC_LirInst_decl_temp 0
#define zT_6BA597BC_LirInst_decl_local 1
#define zT_6BA597BC_LirInst_assign 2
#define zT_6BA597BC_LirInst_assign_field 3
#define zT_6BA597BC_LirInst_assign_index 4
#define zT_6BA597BC_LirInst_jump 5
#define zT_6BA597BC_LirInst_branch 6
#define zT_6BA597BC_LirInst_switch_br 7
#define zT_6BA597BC_LirInst_loop_header 8
#define zT_6BA597BC_LirInst_ret 9
#define zT_6BA597BC_LirInst_ret_void 10
#define zT_6BA597BC_LirInst_label 11
#define zT_6BA597BC_LirInst_binary 12
#define zT_6BA597BC_LirInst_unary 13
#define zT_6BA597BC_LirInst_call 14
#define zT_6BA597BC_LirInst_load_field 15
#define zT_6BA597BC_LirInst_store_field 16
#define zT_6BA597BC_LirInst_load_index 17
#define zT_6BA597BC_LirInst_load 18
#define zT_6BA597BC_LirInst_store 19
#define zT_6BA597BC_LirInst_addr_of 20
#define zT_6BA597BC_LirInst_addr_of_field 21
#define zT_6BA597BC_LirInst_wrap_optional 22
#define zT_6BA597BC_LirInst_call_direct 23
#define zT_6BA597BC_LirInst_va_start 24
#define zT_6BA597BC_LirInst_va_arg 25
#define zT_6BA597BC_LirInst_va_end 26
#define zT_6BA597BC_LirInst_tail_call 27
#define zT_6BA597BC_LirInst_func_ref 28
#define zT_6BA597BC_LirInst_unwrap_optional 29
#define zT_6BA597BC_LirInst_unwrap_optional_abi 30
#define zT_6BA597BC_LirInst_check_optional 31
#define zT_6BA597BC_LirInst_wrap_error_ok 32
#define zT_6BA597BC_LirInst_wrap_error_err 33
#define zT_6BA597BC_LirInst_unwrap_error_payload 34
#define zT_6BA597BC_LirInst_unwrap_error_code 35
#define zT_6BA597BC_LirInst_check_error 36
#define zT_6BA597BC_LirInst_make_slice 37
#define zT_6BA597BC_LirInst_int_cast 38
#define zT_6BA597BC_LirInst_float_cast 39
#define zT_6BA597BC_LirInst_ptr_cast 40
#define zT_6BA597BC_LirInst_int_to_float 41
#define zT_6BA597BC_LirInst_ptr_to_int 42
#define zT_6BA597BC_LirInst_int_to_ptr 43
#define zT_6BA597BC_LirInst_int_const 44
#define zT_6BA597BC_LirInst_float_const 45
#define zT_6BA597BC_LirInst_string_const 46
#define zT_6BA597BC_LirInst_null_const 47
#define zT_6BA597BC_LirInst_set_optional_null 48
#define zT_6BA597BC_LirInst_bool_const 49
#define zT_6BA597BC_LirInst_undefined_const 50
#define zT_6BA597BC_LirInst_enum_const 51
#define zT_6BA597BC_LirInst_load_local 52
#define zT_6BA597BC_LirInst_store_local 53
#define zT_6BA597BC_LirInst_load_global 54
#define zT_6BA597BC_LirInst_store_global 55
#define zT_6BA597BC_LirInst_print_str 56
#define zT_6BA597BC_LirInst_print_val 57
#define zT_6BA597BC_LirInst_builtin_put_char 58
#define zT_6BA597BC_LirInst_builtin_stdout_write 59
#define zT_6BA597BC_LirInst_builtin_stderr_write 60
#define zT_6BA597BC_LirInst_builtin_get_char 61
#define zT_6BA597BC_LirInst_builtin_exit 62
#define zT_6BA597BC_LirInst_builtin_sleep_ms 63
#define zT_6BA597BC_LirInst_builtin_console_clear 64
#define zT_6BA597BC_LirInst_builtin_console_gotoxy 65
#define zT_6BA597BC_LirInst_builtin_console_set_color 66
#define zT_6BA597BC_LirInst_nop 67
#define zT_6BA597BC_LirInst_load_bitfield 68
#define zT_6BA597BC_LirInst_store_bitfield 69
#define zT_6BA597BC_LirInst_trap 70
#define zT_6BA597BC_LirInst_check_trap 71
#define zT_6BA597BC_LirInst_add_with_overflow 72
#define zT_6BA597BC_LirInst_sub_with_overflow 73
#define zT_6BA597BC_LirInst_mul_with_overflow 74
#define zT_6BA597BC_LirInst_shl_with_overflow 75
#define zT_6BA597BC_LirInst_neg_with_overflow 76
#define zT_6BA597BC_LirInst_overflow_flag 77
#define zT_6BA597BC_LirInst_unwrap_optional_checked 78
#define zT_6BA597BC_LirInst_poison_init 79
#define zT_6BA597BC_LirInst_int_cast_checked 80
#define zT_6BA597BC_LirInst_width_wrap 81
struct zT_6BA597BC_LirInst {
	unsigned int tag;
	union {
		char _dummy;
		struct { zT_3B0148B6_anon_74360 _0; } decl_temp;
		struct { zT_4301554E_anon_74368 _0; } decl_local;
		struct { zT_3F038D99_anon_74376 _0; } assign;
		struct { zT_4D05E23A_anon_74386 _0; } assign_field;
		struct { zT_4F0823F7_anon_74396 _0; } assign_index;
		struct { unsigned int _0; } jump;
		struct { zT_C940E31B_anon_74406 _0; } branch;
		struct { zT_C73EA15E_anon_74416 _0; } switch_br;
		struct { unsigned int _0; } loop_header;
		struct { unsigned int _0; } ret;
		struct { unsigned int _0; } label;
		struct { zT_3943D202_anon_74434 _0; } binary;
		struct { zT_3536FFC3_anon_74442 _0; } unary;
		struct { zT_3334BE06_anon_74452 _0; } call;
		struct { zT_C53C5FA1_anon_74462 _0; } load_field;
		struct { zT_3B3947CC_anon_74472 _0; } store_field;
		struct { zT_3B551E49_anon_74484 _0; } load_index;
		struct { zT_B952130C_anon_74490 _0; } load;
		struct { zT_B7520FE6_anon_74496 _0; } store;
		struct { zT_4D6C4EBC_anon_74502 _0; } addr_of;
		struct { zT_556E99EB_anon_74510 _0; } addr_of_field;
		struct { zT_4D6E8D53_anon_74518 _0; } wrap_optional;
		struct { unsigned int _0; } call_direct;
		struct { zT_4967CB42_anon_74526 _0; } va_start;
		struct { zT_4D6A1025_anon_74534 _0; } va_arg;
		struct { zT_516A1671_anon_74538 _0; } va_end;
		struct { unsigned int _0; } tail_call;
		struct { zT_CF7615BE_anon_74548 _0; } func_ref;
		struct { zT_49791463_anon_74554 _0; } unwrap_optional;
		struct { zT_DB71AB74_anon_74560 _0; } unwrap_optional_abi;
		struct { zT_D971A84E_anon_74566 _0; } check_optional;
		struct { zT_DD73ED31_anon_74574 _0; } wrap_error_ok;
		struct { zT_5D7FEFA4_anon_74582 _0; } wrap_error_err;
		struct { zT_577FE632_anon_74588 _0; } unwrap_error_payload;
		struct { zT_C982D83F_anon_74594 _0; } unwrap_error_code;
		struct { zT_71240677_anon_74600 _0; } check_error;
		struct { zT_6B21BE6E_anon_74610 _0; } make_slice;
		struct { zT_6321B1D6_anon_74618 _0; } int_cast;
		struct { zT_5F1F6CF3_anon_74626 _0; } float_cast;
		struct { zT_5B1D2810_anon_74634 _0; } ptr_cast;
		struct { zT_DB1A1FF9_anon_74642 _0; } int_to_float;
		struct { zT_E11A296B_anon_74648 _0; } ptr_to_int;
		struct { zT_ED17FDB8_anon_74656 _0; } int_to_ptr;
		struct { zT_EB15BBFB_anon_74662 _0; } int_const;
		struct { zT_E515B289_anon_74668 _0; } float_const;
		struct { zT_6B12B3E4_anon_74674 _0; } string_const;
		struct { zT_5F12A100_anon_74678 _0; } null_const;
		struct { zT_5D105F43_anon_74684 _0; } set_optional_null;
		struct { zT_5B0E1D86_anon_74690 _0; } bool_const;
		struct { zT_5D0E20AC_anon_74696 _0; } undefined_const;
		struct { zT_F08C9D26_anon_74706 _0; } enum_const;
		struct { zT_768FAEAF_anon_74712 _0; } load_local;
		struct { zT_808FBE6D_anon_74718 _0; } store_local;
		struct { zT_8091FD04_anon_74726 _0; } load_global;
		struct { zT_80943B9B_anon_74734 _0; } store_global;
		struct { zT_7C94354F_anon_74738 _0; } print_str;
		struct { zT_8082F27A_anon_74746 _0; } print_val;
		struct { zT_80853111_anon_74750 _0; } builtin_put_char;
		struct { zT_82853437_anon_74756 _0; } builtin_stdout_write;
		struct { zT_04883F74_anon_74762 _0; } builtin_stderr_write;
		struct { zT_00883928_anon_74766 _0; } builtin_get_char;
		struct { zT_EC8A5843_anon_74770 _0; } builtin_exit;
		struct { zT_F08A5E8F_anon_74774 _0; } builtin_sleep_ms;
		struct { zT_047934EA_anon_74782 _0; } builtin_console_gotoxy;
		struct { zT_FA79252C_anon_74788 _0; } builtin_console_set_color;
		struct { zT_E88C3713_anon_74802 _0; } load_bitfield;
		struct { zT_E689F556_anon_74812 _0; } store_bitfield;
		struct { zT_769193CB_anon_74820 _0; } check_trap;
		struct { zT_6C8F4576_anon_74834 _0; } add_with_overflow;
		struct { zT_7A961745_anon_74848 _0; } sub_with_overflow;
		struct { zT_F09B4E35_anon_74862 _0; } mul_with_overflow;
		struct { zT_EA99062C_anon_74876 _0; } shl_with_overflow;
		struct { zT_72A09809_anon_74888 _0; } neg_with_overflow;
		struct { zT_8F078A1A_anon_74904 _0; } overflow_flag;
		struct { zT_9109CBD7_anon_74910 _0; } unwrap_optional_checked;
		struct { zT_8D09C58B_anon_74914 _0; } poison_init;
		struct { zT_05047245_anon_74930 _0; } int_cast_checked;
		struct { zT_90FCFFE4_anon_74942 _0; } width_wrap;
	} payload;
};
#endif /* ZIG_STRUCT_zT_6BA597BC_LirInst */
#ifndef ZIG_STRUCT_zT_D21A8776_SpillStore
#define ZIG_STRUCT_zT_D21A8776_SpillStore
struct zT_D21A8776_SpillStore {
	zT_0426DCE7_SpillBackend backend;
	unsigned char opened;
	zT_05CE5599_Opt_400 handle;
	unsigned char* buf;
	unsigned int cap;
	unsigned int len;
	unsigned int cur;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_D21A8776_SpillStore */
#ifndef ZIG_ERRORUNION_zT_CB78802F_EU_49
#define ZIG_ERRORUNION_zT_CB78802F_EU_49
typedef struct { union { zT_2B3424E9_ParseToken payload; int err; } data; int is_error; } zT_CB78802F_EU_49;
#endif /* ZIG_ERRORUNION_zT_CB78802F_EU_49 */
#ifndef ZIG_ARRAY_zT_A9570799_Arr_zT_3A355BD2_Tok
#define ZIG_ARRAY_zT_A9570799_Arr_zT_3A355BD2_Tok
typedef zT_3A355BD2_Token zT_A9570799_Arr_zT_3A355BD2_Tok[3];
#endif /* ZIG_ARRAY_zT_A9570799_Arr_zT_3A355BD2_Tok */
#ifndef ZIG_OPTIONAL_zT_ADDA7CFF_Opt_97
#define ZIG_OPTIONAL_zT_ADDA7CFF_Opt_97
typedef struct { zT_F4EBEA72_OpInfo value; int has_value; } zT_ADDA7CFF_Opt_97;
#endif /* ZIG_OPTIONAL_zT_ADDA7CFF_Opt_97 */
#ifndef ZIG_OPTIONAL_zT_5CC037A7_Opt_194
#define ZIG_OPTIONAL_zT_5CC037A7_Opt_194
typedef struct { zT_9CDC9863_CoercionEntry value; int has_value; } zT_5CC037A7_Opt_194;
#endif /* ZIG_OPTIONAL_zT_5CC037A7_Opt_194 */
#ifndef ZIG_STRUCT_zT_C98AF326_CompilerCli
#define ZIG_STRUCT_zT_C98AF326_CompilerCli
struct zT_C98AF326_CompilerCli {
	zT_8F083A69_Slice_zT_0B42B2F8_u input_file;
	zT_8F083A69_Slice_zT_0B42B2F8_u output_dir;
	int output_dir_set;
	int dump_types;
	int dump_lir;
	int dump_c89;
	unsigned int max_mem;
	unsigned int spill_level;
	unsigned int max_errors;
	zT_CAF40AAB_ColorMode color;
	zT_A4FB690E_ErrorFormat error_format;
	int warnings_as_errors;
	int quiet;
	int test_mode;
	int sanity_test_mode;
	int track_memory;
	int no_null_check;
	int no_lifetime_check;
	int no_leak_check;
	int safe_checks;
	int warn_all;
	int warn_error;
	int show_markers;
	zT_B06C33DA_Arr_zT_8F083A69_Sli include_dirs;
	unsigned int include_count;
	int target_is_windows;
};
#endif /* ZIG_STRUCT_zT_C98AF326_CompilerCli */
#ifndef ZIG_STRUCT_zT_69057089_CompilerAlloc
#define ZIG_STRUCT_zT_69057089_CompilerAlloc
struct zT_69057089_CompilerAlloc {
	zT_3E40CD83_Sand permanent;
	zT_3E40CD83_Sand module;
	zT_3E40CD83_Sand scratch;
	zT_3E40CD83_Sand lir_read;
	zT_3E40CD83_Sand emission;
	unsigned int max_mem;
};
#endif /* ZIG_STRUCT_zT_69057089_CompilerAlloc */
#ifndef ZIG_STRUCT_zT_7D82FE60_GrowableSand
#define ZIG_STRUCT_zT_7D82FE60_GrowableSand
struct zT_7D82FE60_GrowableSand {
	zT_C59F83AC_SandSegment first;
	zT_C59F83AC_SandSegment* last;
	zT_3E40CD83_Sand* backing;
	zT_3E40CD83_Sand view;
};
#endif /* ZIG_STRUCT_zT_7D82FE60_GrowableSand */
#ifndef ZIG_STRUCT_zT_72C4E2ED_C89Emitter
#define ZIG_STRUCT_zT_72C4E2ED_C89Emitter
struct zT_72C4E2ED_C89Emitter {
	zT_63BE4FF5_BufferedWriter writer;
	unsigned int indent;
	zT_3E40CD83_Sand* alloc;
	zT_3E40CD83_Sand* persist_alloc;
	zT_338B7C76_TypeRegistry* registry;
	zT_D3EB6303_StringInterner* interner;
	zT_CEC2984A_NameMangler_1* mangler;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_9F514E82_SwitchCaseArrayList* switch_cases;
	zT_B687BB96_U32ArrayList* call_args;
	zT_BBC23664_LirFunction* current_fn;
	zT_7E7544E4_LirStream* spill;
	zT_E7714190_LirSlot* fn_slots;
	unsigned int fn_slots_start;
	unsigned int fn_slots_len;
	zT_3E40CD83_Sand* spill_arena;
	unsigned int* d4_wtype;
	unsigned char* d4_wflag;
	unsigned int* d4_t2p;
	unsigned char* d4_dead;
	unsigned int d4_max_temp;
	unsigned char* d4_local;
	unsigned char* d4_nodecl;
	unsigned char* d4_lread;
	unsigned char* bb_used;
	unsigned int bb_used_count;
	unsigned char dl_hoisted;
	unsigned char nest_ok;
	unsigned int nest_max;
	unsigned char* nest_inl;
	zT_21D3708C_U32ToU32Map emitted_type_set;
	zT_21D3708C_U32ToU32Map fwd_decl_set;
	zT_21D3708C_U32ToU32Map pointer_only_map;
	zT_21D3708C_U32ToU32Map shared_set;
	zT_072B53A6_ModuleRegistry* module_reg;
	zT_21D3708C_U32ToU32Map reachable;
	unsigned char prune_active;
	zT_21D3708C_U32ToU32Map* error_code_registry;
	unsigned int* dedup_names;
	unsigned int dedup_cap;
	unsigned int dedup_count;
	unsigned int* fl_name_ids;
	unsigned int* fl_temps;
	unsigned int fl_count;
	zT_21D3708C_U32ToU32Map temp_global_map;
	zT_21D3708C_U32ToU32Map ts_ref_set;
	zT_54906056_ModuleGlobalDecl* global_decls;
	unsigned int global_decls_len;
	int safe_checks;
};
#endif /* ZIG_STRUCT_zT_72C4E2ED_C89Emitter */
#ifndef ZIG_STRUCT_zT_01BE9D46_AstValuePool
#define ZIG_STRUCT_zT_01BE9D46_AstValuePool
struct zT_01BE9D46_AstValuePool {
	unsigned int len;
	unsigned int elem_bytes;
	unsigned int elems_per_block;
	unsigned int block_shift;
	unsigned int block_mask;
	unsigned char* head_buf;
	unsigned int head_cap;
	unsigned int head_elems;
	unsigned int cur_block;
	unsigned char* cache_buf;
	unsigned char cache_allocated;
	zT_9C9EF72B_Arr_unsigned_int_8 slot_block;
	unsigned int ring_next;
	zT_D21A8776_SpillStore spill;
	zT_846744CC_Arr_unsigned_char_5 spill_path;
	unsigned int spill_path_len;
	unsigned char is_extra;
};
#endif /* ZIG_STRUCT_zT_01BE9D46_AstValuePool */
#ifndef ZIG_STRUCT_zT_072B53A6_ModuleRegistry
#define ZIG_STRUCT_zT_072B53A6_ModuleRegistry
struct zT_072B53A6_ModuleRegistry {
	zT_E41AEC18_ModuleEntryArrayLis modules;
	unsigned int* import_edges_items;
	unsigned int import_edges_len;
	unsigned int import_edges_cap;
	zT_3E40CD83_Sand* import_edges_alloc;
	zT_4DB1475B_ModuleResolver resolver;
	zT_D3EB6303_StringInterner* interner;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_227EDE07_SourceManager* source_man;
	zT_3E40CD83_Sand* alloc;
	unsigned int next_id;
	zT_21D3708C_U32ToU32Map path_to_id;
	zT_21D3708C_U32ToU32Map content_to_id;
	zT_846744CC_Arr_unsigned_char_5 hash_spill_path;
	unsigned int hash_spill_path_len;
	zT_D21A8776_SpillStore spill;
	zT_ABD0FF08_HashMapSpillMeta path_to_id_spill;
	zT_ABD0FF08_HashMapSpillMeta content_to_id_spill;
	zT_47A5CDFB_ImportQueue import_queue;
};
#endif /* ZIG_STRUCT_zT_072B53A6_ModuleRegistry */
#ifndef ZIG_STRUCT_zT_7E7544E4_LirStream
#define ZIG_STRUCT_zT_7E7544E4_LirStream
struct zT_7E7544E4_LirStream {
	zT_D21A8776_SpillStore spill;
	zT_846744CC_Arr_unsigned_char_5 path;
	unsigned int path_len;
	unsigned int write_offset;
};
#endif /* ZIG_STRUCT_zT_7E7544E4_LirStream */
#ifndef ZIG_STRUCT_zT_8EED1867_ResolvedTypeTable
#define ZIG_STRUCT_zT_8EED1867_ResolvedTypeTable
struct zT_8EED1867_ResolvedTypeTable {
	unsigned int cap;
	zT_3E40CD83_Sand* entries_alloc;
	zT_D21A8776_SpillStore spill;
	zT_846744CC_Arr_unsigned_char_5 spill_path;
	unsigned int spill_path_len;
	unsigned char* cache_buf;
	unsigned char cache_allocated;
	zT_9C9EF72B_Arr_unsigned_int_8 slot_block;
	zT_C1AB0454_Arr_unsigned_char_8 slot_dirty;
	unsigned int ring_next;
	zT_21D3708C_U32ToU32Map src_map;
};
#endif /* ZIG_STRUCT_zT_8EED1867_ResolvedTypeTable */
#ifndef ZIG_STRUCT_zT_B559F9DA_Parser
#define ZIG_STRUCT_zT_B559F9DA_Parser
struct zT_B559F9DA_Parser {
	int use_lex;
	zT_138FFB41_Lexer* lex;
	zT_3A355BD2_Token* tokens_ptr;
	unsigned int tokens_len;
	unsigned char* source_ptr;
	unsigned int source_len;
	unsigned int pos;
	zT_A9570799_Arr_zT_3A355BD2_Tok la;
	unsigned int la_len;
	int at_eof;
	zT_3A355BD2_Token eof_tok;
	zT_6B0A7D14_AstStore* store;
	zT_D3EB6303_StringInterner* interner;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_3E40CD83_Sand* allocator;
	unsigned int* child_buf_items;
	unsigned int child_buf_len;
	unsigned int child_buf_capacity;
	unsigned int last_end;
	zT_3A355BD2_Token last_tok;
	int last_tok_valid;
	unsigned int* decl_buf_items;
	unsigned int decl_buf_len;
	unsigned int decl_buf_capacity;
	unsigned int builtin_import_id;
	unsigned int catch_capture;
	unsigned int expr_depth;
	zT_7034F045_Opt_228 module_reg;
	zT_6C306CCB_Opt_240 import_scratch;
	unsigned int current_module_id;
	unsigned int file_id;
};
#endif /* ZIG_STRUCT_zT_B559F9DA_Parser */
#ifndef ZIG_STRUCT_zT_6B0A7D14_AstStore
#define ZIG_STRUCT_zT_6B0A7D14_AstStore
struct zT_6B0A7D14_AstStore {
	zT_8DDC796C_anon_225780 nodes;
	zT_01BE9D46_AstValuePool extra_children;
	zT_01BE9D46_AstValuePool identifiers;
	zT_01BE9D46_AstValuePool int_values;
	zT_8EDEB996_anon_225795 float_values;
	zT_4B5CDF4D_anon_225804 string_values;
	zT_445A95B1_anon_225813 fn_protos;
	zT_485A9BFD_anon_225817 payload;
	zT_01BE9D46_AstValuePool extra_ranges;
	zT_3E40CD83_Sand* allocator;
	zT_4E5F229D_anon_225831 block_table;
	zT_6C253597_Arr_zT_6DD0D007_Ast slots;
	zT_9C9EF72B_Arr_unsigned_int_8 slot_block;
	unsigned int cur_block;
	unsigned int cur_block_len;
	unsigned int ring_next;
	zT_D21A8776_SpillStore spill;
	zT_846744CC_Arr_unsigned_char_5 spill_path;
	unsigned int spill_path_len;
};
#endif /* ZIG_STRUCT_zT_6B0A7D14_AstStore */
#ifndef ZIG_STRUCT_zT_5AB29387_CompilerContext
#define ZIG_STRUCT_zT_5AB29387_CompilerContext
struct zT_5AB29387_CompilerContext {
	zT_C98AF326_CompilerCli cli;
	zT_69057089_CompilerAlloc* alloc;
	zT_D3EB6303_StringInterner* interner;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_227EDE07_SourceManager* source_man;
	zT_CEC2984A_NameMangler* name_mangler;
	zT_072B53A6_ModuleRegistry* module_reg;
	zT_338B7C76_TypeRegistry* typereg;
	zT_6B0A7D14_AstStore* store;
	zT_3D7259E2_SymbolRegistry* symbol_reg;
	zT_8EED1867_ResolvedTypeTable* resolved_types;
	zT_66E7D2EF_CoercionTable* coercion_table;
	zT_4D61441E_DepGraph* dep_graph;
	zT_CA01C129_LirSlotArrayList lir_slots;
	zT_7E7544E4_LirStream lir_stream;
	zT_21D3708C_U32ToU32Map enum_value_table;
	zT_21D3708C_U32ToU32Map error_code_registry;
	zT_21D3708C_U32ToU32Map call_arg_types;
	zT_21D3708C_U32ToU32Map call_param_map;
	zT_89877D19_U32ToU64Map comptime_values;
	unsigned int* pointer_only_ids;
	unsigned int pointer_only_len;
	zT_E1A783EF_GlobalDeclArrayList global_decls;
	zT_A4CE86B7_U64ToU32Map exported;
	zT_A4CE86B7_U64ToU32Map suspending_fns;
	zT_A4CE86B7_U64ToU32Map frame_sizes;
	zT_A4CE86B7_U64ToU32Map state_widths;
	zT_A4CE86B7_U64ToU32Map awaited_fns;
	zT_A4CE86B7_U64ToU32Map async_hidden_fns;
	zT_A4CE86B7_U64ToU32Map driver_targets;
	zT_B687BB96_U32ArrayList parent_result_type_list;
	zT_A4CE86B7_U64ToU32Map parent_result_start;
	zT_A4CE86B7_U64ToU32Map parent_result_count;
	zT_A4CE86B7_U64ToU32Map async_layouts;
};
#endif /* ZIG_STRUCT_zT_5AB29387_CompilerContext */
#endif /* ZIG_SPECIAL_TYPES_H */
