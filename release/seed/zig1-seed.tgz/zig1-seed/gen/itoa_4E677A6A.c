#include "itoa_4E677A6A.h"
/* itoa */
unsigned int zF_A7504564_itoa(unsigned int value, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_4;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned char zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    int zT_13;
    int zT_15;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    int zT_21;
    int zT_23;
    int zT_24;
    int zT_27;
    unsigned int zT_28;
    int zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned int zT_33;
    unsigned char zT_35;
    unsigned char zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    unsigned int zT_40;
    int zT_43;
    unsigned int i;
    unsigned int v;
    unsigned int digit;
    zT_4 = buf.len;
    zT_6 = 1;
    zT_7 = (unsigned int)((unsigned int)zT_4) - zT_6;
    i = zT_7;
    zT_8 = 0;
    zT_9 = (unsigned char)zT_8;
    zT_10 = buf.ptr;
    zT_11 = (unsigned int)i;
    zT_10[zT_11] = zT_9;
    v = value;
    zT_13 = 0;
    if ((int)(v == (unsigned int)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 1;
    zT_17 = i - (unsigned int)((unsigned int)zT_15);
    i = zT_17;
    zT_18 = 48;
    zT_19 = buf.ptr;
    zT_20 = (unsigned int)i;
    zT_19[zT_20] = zT_18;
    goto z_bb_2;
    z_bb_2:
    zT_40 = buf.len;
    zT_43 = 1;
    return (unsigned int)((unsigned int)((unsigned int)((unsigned int)zT_40) - i) - zT_43);
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_21 = 0;
    if ((int)(v > (unsigned int)zT_21)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_27 = 10;
    zT_28 = v % zT_27;
    digit = zT_28;
    zT_29 = 10;
    zT_30 = v / zT_29;
    v = zT_30;
    zT_31 = 1;
    zT_33 = i - (unsigned int)((unsigned int)zT_31);
    i = zT_33;
    zT_35 = __bootstrap_u8_from_u32(digit);
    zT_36 = (unsigned char)(48) + zT_35;
    zT_37 = buf.ptr;
    zT_38 = (unsigned int)i;
    zT_37[zT_38] = zT_36;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_24 = 0;
    zT_23 = i > (unsigned int)zT_24;
    goto z_bb_10;
    z_bb_9:
    zT_23 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_23) goto z_bb_5; else goto z_bb_6;
}

/* itoa64 */
unsigned int zF_A3999586_itoa64(zT_79FAE712_u64 value, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_4;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned char zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    int zT_13;
    int zT_15;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    int zT_21;
    int zT_23;
    int zT_24;
    int zT_27;
    zT_79FAE712_u64 zT_28;
    int zT_29;
    zT_79FAE712_u64 zT_30;
    int zT_31;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned char zT_36;
    unsigned char zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    int zT_44;
    unsigned int i;
    zT_79FAE712_u64 v;
    zT_79FAE712_u64 digit;
    zT_4 = buf.len;
    zT_6 = 1;
    zT_7 = (unsigned int)((unsigned int)zT_4) - zT_6;
    i = zT_7;
    zT_8 = 0;
    zT_9 = (unsigned char)zT_8;
    zT_10 = buf.ptr;
    zT_11 = (unsigned int)i;
    zT_10[zT_11] = zT_9;
    v = value;
    zT_13 = 0;
    if ((int)(v == (zT_79FAE712_u64)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 1;
    zT_17 = i - (unsigned int)((unsigned int)zT_15);
    i = zT_17;
    zT_18 = 48;
    zT_19 = buf.ptr;
    zT_20 = (unsigned int)i;
    zT_19[zT_20] = zT_18;
    goto z_bb_2;
    z_bb_2:
    zT_41 = buf.len;
    zT_44 = 1;
    return (unsigned int)((unsigned int)((unsigned int)((unsigned int)zT_41) - i) - zT_44);
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_21 = 0;
    if ((int)(v > (zT_79FAE712_u64)zT_21)) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    zT_27 = 10;
    zT_28 = v % zT_27;
    digit = zT_28;
    zT_29 = 10;
    zT_30 = v / zT_29;
    v = zT_30;
    zT_31 = 1;
    zT_33 = i - (unsigned int)((unsigned int)zT_31);
    i = zT_33;
    zT_35 = __bootstrap_u32_from_u64(digit);
    zT_36 = __bootstrap_u8_from_u32(zT_35);
    zT_37 = (unsigned char)(48) + zT_36;
    zT_38 = buf.ptr;
    zT_39 = (unsigned int)i;
    zT_38[zT_39] = zT_37;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_24 = 0;
    zT_23 = i > (unsigned int)zT_24;
    goto z_bb_10;
    z_bb_9:
    zT_23 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_23) goto z_bb_5; else goto z_bb_6;
}

/* EOF */
