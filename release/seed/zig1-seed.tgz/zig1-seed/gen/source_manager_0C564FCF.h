#ifndef ZIG_MODULE_SOURCE_MANAGER_0C564FCF_H
#define ZIG_MODULE_SOURCE_MANAGER_0C564FCF_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "growable_array_6014E5AF.h"
#include "mem_19CC4C40.h"
#include "pal_388A8A1B.h"

#ifndef ZIG_STRUCT_zT_6B45117F_SourceFileArrayList
#define ZIG_STRUCT_zT_6B45117F_SourceFileArrayList
struct zT_6B45117F_SourceFileArrayList {
	zT_ED18556E_SourceFile* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_6B45117F_SourceFileArrayList */
#ifndef ZIG_STRUCT_zT_5BC08DC6_Location
#define ZIG_STRUCT_zT_5BC08DC6_Location
struct zT_5BC08DC6_Location {
	unsigned int file_id;
	unsigned int line;
	unsigned int col;
};
#endif /* ZIG_STRUCT_zT_5BC08DC6_Location */
#ifndef ZIG_STRUCT_zT_227EDE07_SourceManager
#define ZIG_STRUCT_zT_227EDE07_SourceManager
struct zT_227EDE07_SourceManager {
	zT_6B45117F_SourceFileArrayList* files;
	zT_3E40CD83_Sand* allocator;
	zT_7D82FE60_GrowableSand* fault;
	int fault_ready;
};
#endif /* ZIG_STRUCT_zT_227EDE07_SourceManager */
#ifndef ZIG_STRUCT_zT_ED18556E_SourceFile
#define ZIG_STRUCT_zT_ED18556E_SourceFile
struct zT_ED18556E_SourceFile {
	zT_8F083A69_Slice_zT_0B42B2F8_u filename;
	zT_8F083A69_Slice_zT_0B42B2F8_u content;
	zT_B687BB96_U32ArrayList* line_offsets;
	unsigned int len;
	int loaded;
};
#endif /* ZIG_STRUCT_zT_ED18556E_SourceFile */

/* Forward declarations */
zT_6B45117F_SourceFileArrayList zF_EB529E39_sourceFileArrayList(zT_3E40CD83_Sand*);
void zF_9E523C79_sourceFileArrayList(zT_6B45117F_SourceFileArrayList*, unsigned int);
void zF_5368F9F7_sourceFileArrayList(zT_6B45117F_SourceFileArrayList*, zT_ED18556E_SourceFile);
zT_1D6CA09C_Slice_zT_ED18556E_S zF_276A1E3D_sourceFileArrayList(zT_6B45117F_SourceFileArrayList*);
zT_227EDE07_SourceManager zF_01351F51_sourceManagerInit(zT_3E40CD83_Sand*);
unsigned int zF_3A49F0F4_sourceManagerAddFil(zT_227EDE07_SourceManager*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_55F5B402_sourceManagerAddFil(zT_227EDE07_SourceManager*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_088D3002_sourceManagerFaultI(zT_227EDE07_SourceManager*, unsigned int);
void zF_196FDF3B_sourceManagerResetF(zT_227EDE07_SourceManager*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_B7076474_sourceManagerGetFil(zT_227EDE07_SourceManager*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_FFE72B39_sourceManagerGetSou(zT_227EDE07_SourceManager*, unsigned int);
zT_3CB0179A_Slice_zT_05F374B1_u zF_5041A561_sourceManagerGetLin(zT_227EDE07_SourceManager*, unsigned int);
zT_5BC08DC6_Location zF_4966CE4A_sourceManagerGetLoc(zT_227EDE07_SourceManager*, unsigned int, unsigned int);
unsigned char* zF_B158E4F2_sourceManagerCopyTo(zT_227EDE07_SourceManager*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_780653D2___module_init_2(void);
/* Storage globals (extern decls) */
extern zT_227EDE07_SourceManager zG_227EDE07_SourceManager;

#endif /* ZIG_MODULE_SOURCE_MANAGER_0C564FCF_H */
