#ifndef ZIG_MODULE_C89_EMIT_7CEF756E_H
#define ZIG_MODULE_C89_EMIT_7CEF756E_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "pal_388A8A1B.h"
#include "type_registry_8EE489B8.h"
#include "string_interner_51340A9F.h"
#include "diagnostics_B9C6175E.h"
#include "lir_64CB5435.h"
#include "growable_array_6014E5AF.h"
#include "hash_02AFCD13.h"
#include "allocator_E75B7A0B.h"
#include "module_registry_03A5D1FC.h"
#include "type_resolver_7446D285.h"
#include "itoa_4E677A6A.h"
#include "format_0AEF880C.h"
#include "mem_19CC4C40.h"
#include "symbol_registrator_757C4BC5.h"
#include "lir_stream_0760A6EE.h"
#include "lir_opt_pass_3842C861.h"
#include "emit_support_51C949E9.h"


/* Forward declarations */
zT_63BE4FF5_BufferedWriter zF_F9E678C3_bufferedWriterInit(void);
zT_63BE4FF5_BufferedWriter zF_E00097E1_bufferedWriterInitF(unsigned int);
void zF_B35650AD_bufferedWriterFlush(zT_63BE4FF5_BufferedWriter*);
void zF_5D54388C_bufferedWriterWrite(zT_63BE4FF5_BufferedWriter*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_FC232E46_bufferedWriterWrite(zT_63BE4FF5_BufferedWriter*, unsigned char);
void zF_C53C449A_bufferedWriterWrite(zT_63BE4FF5_BufferedWriter*, unsigned int);
void zF_0EC07EFB_dbgPrintU32(unsigned int);
void zF_8F8DE819_writeHex(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int*, unsigned int);
unsigned char zF_F2F86D29_isTempOrBuiltin(zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_5412D014_isC89Keyword(zT_CEC2984A_NameMangler_1*, unsigned int);
unsigned char zF_AB1DFFC4_isBasePtrToArray(zT_72C4E2ED_C89Emitter*, unsigned int);
zT_79FAE712_u64 zF_EDCE5CD5_globvarTypeScalarSi(zT_72C4E2ED_C89Emitter*, unsigned int);
int zF_AD106DDE_isLargeModuleVarArr(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_5B52B030_emitBaseIdxAccess(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char);
void zF_FFE9ACA7_emitFieldAssign(zT_63BE4FF5_BufferedWriter*, unsigned int, zT_338B7C76_TypeRegistry*, zT_CEC2984A_NameMangler_1*, zT_D3EB6303_StringInterner*, zT_BBC23664_LirFunction*, zT_1937645B_TempDecl*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, zT_72C4E2ED_C89Emitter*);
unsigned int zF_C3DD2126_mangleC89Keyword(zT_CEC2984A_NameMangler_1*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_F82AFAD8_nameManglerPopulate(zT_CEC2984A_NameMangler_1*);
zT_CEC2984A_NameMangler_1 zF_27DA3900_nameManglerInit_1(zT_D3EB6303_StringInterner*, zT_3E40CD83_Sand*, unsigned int);
unsigned int zF_713D1938_nameManglerMangle(zT_CEC2984A_NameMangler_1*, unsigned int, unsigned char, unsigned int);
unsigned int zF_027E7C4F_nameManglerMangleGl(zT_CEC2984A_NameMangler_1*, zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned int);
zT_72C4E2ED_C89Emitter zF_63D58A2B_c89EmitterInit(zT_338B7C76_TypeRegistry*, zT_D3EB6303_StringInterner*, zT_CEC2984A_NameMangler_1*, zT_F85C5DED_DiagnosticCollector*, zT_9F514E82_SwitchCaseArrayList*, zT_B687BB96_U32ArrayList*, zT_3E40CD83_Sand*, zT_3E40CD83_Sand*, zT_21D3708C_U32ToU32Map*, unsigned int, int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_22D5D03B_aggregateKeyword(zT_33EF6BFB_TypeKind);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_E736A0CF_getCTypeName(zT_338B7C76_TypeRegistry*, zT_CEC2984A_NameMangler_1*, unsigned int);
unsigned int zF_77F75044_getTempTypeByIndex(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_225796FB_emitIncludes(zT_63BE4FF5_BufferedWriter*);
void zF_5CA77922_emitZigCompatH(zT_63BE4FF5_BufferedWriter*);
unsigned int zF_FC1E0517_openSupportOutputFi(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_AB1E9CD4_emitSupportFiles(zT_72C4E2ED_C89Emitter*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_EE6A0766_emitZigPalC(zT_63BE4FF5_BufferedWriter*);
int zF_78716C04_c89NeedsEmitEdge(zT_33EF6BFB_TypeKind);
int zF_C2C2A00D_tstSeenInRange(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned int);
unsigned int zF_39833EF5_tstEdgesCount(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_C434CA0B_tstEdgesFill(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int*, unsigned int);
int zF_577F419D_tstIsDep(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned int* zF_1DD26D63_tstTopologicalSort(zT_338B7C76_TypeRegistry*, zT_3E40CD83_Sand*);
void zF_2144501E_ctypeGuardWrite(zT_63BE4FF5_BufferedWriter*, zT_33EF6BFB_TypeKind);
void zF_0DED2F55_computeSharedSet(zT_338B7C76_TypeRegistry*, zT_72C4E2ED_C89Emitter*, zT_3E40CD83_Sand*);
void zF_62841416_emitSharedHeader(zT_72C4E2ED_C89Emitter*, zT_338B7C76_TypeRegistry*, unsigned int*);
void zF_B83F606E_emitSpecialTypes(zT_72C4E2ED_C89Emitter*, zT_338B7C76_TypeRegistry*, unsigned int*);
void zF_DA98954D_emitTaggedUnionType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_D187FBB7_emitStructType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_114226D1_emitUnionType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_6409BA53_emitArrayType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_A087781B_emitTypeDefinition(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_40577C70_emitFnPtrType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_5D14D70C_emitErrorSetType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_B33595EC_emitErrorCodeProlog(zT_72C4E2ED_C89Emitter*);
void zF_3B2D5AA3_emitEnumType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_D64A81D9_emitInt64Type(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_F54D3174_emitUint64Type(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_56C9AC18_emitSliceType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_24083B72_emitOptionalType(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_1458D413_emitErrorUnionType(zT_72C4E2ED_C89Emitter*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_32A25C91_mangleLocalName(zT_CEC2984A_NameMangler_1*, zT_D3EB6303_StringInterner*, unsigned int);
void zF_DAEF34AC_emitCallConv(zT_72C4E2ED_C89Emitter*, unsigned char);
unsigned int zF_2FF8A165_findCalleeFnTypeId(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int, unsigned char);
unsigned int zF_C536E5D2_tempFnTypeId(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_CF76CBDB_emitCalleeExpr(zT_72C4E2ED_C89Emitter*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_3D0F6C34_emitFunctionSignatu(zT_72C4E2ED_C89Emitter*, zT_BBC23664_LirFunction*);
void zF_96BE4A6F_emitFunctionForward(zT_72C4E2ED_C89Emitter*, zT_BBC23664_LirFunction);
zT_BBC23664_LirFunction zF_C0F09404_faultIn(zT_72C4E2ED_C89Emitter*, unsigned int);
unsigned char zF_75438B9B_moduleHasVaInsts(zT_72C4E2ED_C89Emitter*);
void zF_E325E01B_emitStdargInclude(zT_72C4E2ED_C89Emitter*);
unsigned char zF_B153AE33_moduleHasStdioBuilt(zT_72C4E2ED_C89Emitter*);
unsigned char zF_03AA5E12_moduleHasExitBuilti(zT_72C4E2ED_C89Emitter*);
unsigned char zF_6238F659_moduleHasSleepBuilt(zT_72C4E2ED_C89Emitter*);
unsigned char zF_9517784F_moduleHasConsoleBui(zT_72C4E2ED_C89Emitter*);
void zF_C65843D4_emitBuiltinIncludes(zT_72C4E2ED_C89Emitter*);
void zF_ECBD2097_emitModuleHeader(zT_72C4E2ED_C89Emitter*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3CB0179A_Slice_zT_05F374B1_u);
void zF_EFD577C1_emitModuleFooter(zT_72C4E2ED_C89Emitter*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_E295413A_moduleQualifiedName(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_1AF3E3A9_emitModuleHeaderFil(zT_72C4E2ED_C89Emitter*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3CB0179A_Slice_zT_05F374B1_u, zT_3CB0179A_Slice_zT_05F374B1_u, unsigned int*);
void zF_503E3056_emitModule(zT_72C4E2ED_C89Emitter*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3CB0179A_Slice_zT_05F374B1_u, unsigned int*, unsigned int);
void zF_7FC51012_emitMainWrapper(zT_72C4E2ED_C89Emitter*, zT_BBC23664_LirFunction);
void zF_B51F684A_emitGlobalDecls(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned char);
int zF_34E786BB_moduleHasRuntimeIni(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_5C4733ED_emitModuleInitCalls(zT_72C4E2ED_C89Emitter*);
void zF_7B8B9B90_emitModuleFile(zT_72C4E2ED_C89Emitter*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_637D947E_mangleTempName(zT_D3EB6303_StringInterner*, unsigned int);
void zF_6DBC5735_emitHoistedDecls(zT_72C4E2ED_C89Emitter*, zT_BBC23664_LirFunction*);
unsigned int zF_4B4AE5DF_nestScalarEffTid(zT_72C4E2ED_C89Emitter*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_5AD9F687_nestEffCType(zT_72C4E2ED_C89Emitter*, unsigned int);
unsigned int zF_091F0B0D_nestDefTempId(zT_6BA597BC_LirInst);
unsigned char zF_66AF83FE_nestShapeOk(zT_72C4E2ED_C89Emitter*, zT_6BA597BC_LirInst, unsigned int);
unsigned char zF_543DA98E_nestConsumerWired(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_E493AB7D_emitNestCompute(zT_72C4E2ED_C89Emitter*, zT_BBC23664_LirFunction*);
void zF_F2909187_nestFail(zT_72C4E2ED_C89Emitter*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_36C162D8_emitValueExpr(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int);
void zF_39D285C4_nestEmitDefRvalue(zT_72C4E2ED_C89Emitter*, zT_6BA597BC_LirInst, unsigned int);
void zF_BD60376A_nestEmitBinExpr(zT_72C4E2ED_C89Emitter*, unsigned char, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_0448B34C_nestEmitUnaryExpr(zT_72C4E2ED_C89Emitter*, unsigned char, unsigned int, unsigned int, unsigned int);
void zF_74203919_nestWriteIntConstRv(zT_72C4E2ED_C89Emitter*, zT_79FAE712_u64, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_ACDC5D52_arrLoopDeclSigned(unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_37E68E5B_arrLoopDeclSignedK(unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_03922632_arrLoopDeclOpenSign(unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_313B889A_getBinOpStr(unsigned char);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8EC5FFA6_getUnOpStr(unsigned char);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_66E0834A_intLitSuffixUns(zT_79FAE712_u64);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_F6748FC8_intLitSuffixNeg(zT_79FAE712_u64);
unsigned int zF_79EE56F9_intConstTypeForValu(zT_338B7C76_TypeRegistry*, zT_79FAE712_u64, unsigned int);
int zF_3F4A997A_isAtomicCOperand(zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_E324316A_getUnsignedCTypeNam(zT_338B7C76_TypeRegistry*, zT_CEC2984A_NameMangler_1*, unsigned int);
signed char zF_BABF27D3_classifyIntSignedne(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_B2CEFBB1_intTypeNeedsWidthWr(zT_338B7C76_TypeRegistry*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_79474D9D_writeSatNegDecimal(zT_79FAE712_u64, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_86EF7447_writeSatUnsDecimal(zT_79FAE712_u64, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8C1E4475_writeSatSignedMaxDe(zT_79FAE712_u64, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_13194D2C_satMaxLitBound(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_9BBE6E1A_satMinLitBound(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
int zF_51546220_writeMinSignedIntLi(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int, zT_79FAE712_u64);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_CE4D28BF_satMinMagLitBound(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_78CEF681_satMaxULitBound(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_13EB3449_writeWidthMaskStrin(zT_63BE4FF5_BufferedWriter*, unsigned int);
void zF_706D59C5_writeWidthSignBitSt(zT_63BE4FF5_BufferedWriter*, unsigned int);
unsigned int zF_4D585710_intTypeByteWidth(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_CB492898_typeIsIntKind(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_7E6F9E59_retTypeIsScalarC(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_C01C7D5F_typeIsPtrKind(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_6422F8D3_isLocalPosUsed(zT_72C4E2ED_C89Emitter*, unsigned int);
unsigned char zF_7C288455_isDeadLocalName(zT_72C4E2ED_C89Emitter*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_B8A337C2_ptrCTypeNameFromEle(zT_338B7C76_TypeRegistry*, zT_CEC2984A_NameMangler_1*, unsigned int);
unsigned char zF_ED7597B0_getTempEffType(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int*, unsigned char*);
unsigned char zF_17A21E2F_getTempTypeInfoReso(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int*, unsigned char*);
void zF_6AF04C61_getTempTypeInfo(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int, unsigned int, unsigned int*, unsigned char*);
void zF_D550E1F7_emitSatBinary(zT_72C4E2ED_C89Emitter*, unsigned char, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, unsigned char);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_DF351BCC_getCheckedCastFnNam(zT_338B7C76_TypeRegistry*, unsigned int);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_FD35C3C9_getPrintFnName(zT_338B7C76_TypeRegistry*, unsigned int, unsigned char);
void zF_4401B8E5_emitCStringLiteral(zT_63BE4FF5_BufferedWriter*, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_30D20516_resolveTempName(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_21842D03_emitFwriteCall(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int, unsigned char);
void zF_B207201C_emitConsoleClear(zT_72C4E2ED_C89Emitter*);
void zF_FC378C7B_emitConsoleGotoxy(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int);
void zF_D676C7F4_emitConsoleSetColor(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int);
void zF_36A97692_bfWriteU32(zT_63BE4FF5_BufferedWriter*, unsigned int);
void zF_B21EB02B_bfByteRefWrite(zT_63BE4FF5_BufferedWriter*, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char, unsigned int);
unsigned char zF_32155E18_emitterTempIsPacked(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_A3B64FFA_emitPackedStoreBitf(zT_72C4E2ED_C89Emitter*, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char, unsigned int, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_20F60DA7_emitPackedLoadBitfi(zT_72C4E2ED_C89Emitter*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char, unsigned int, unsigned int, unsigned char);
void zF_03741531_emitCastToC(zT_72C4E2ED_C89Emitter*, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
void zF_F2F7278D_emitUintLiteral(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_C44E60B9_emitWrapOp(zT_72C4E2ED_C89Emitter*, unsigned char, unsigned int, unsigned int, unsigned int, unsigned char, unsigned char);
void zF_78AF5D28_emitWrapNeg(zT_72C4E2ED_C89Emitter*, unsigned int, unsigned int, unsigned char, unsigned char);
void zF_4CCF1B23_emitFlagOp(zT_72C4E2ED_C89Emitter*, unsigned char, unsigned int, unsigned int, unsigned int, unsigned char, unsigned char);
void zF_2BFFB972_emitInst(zT_72C4E2ED_C89Emitter*, zT_6BA597BC_LirInst);
int zF_B7332B93_dceTempIsDead(zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_5EC7DB98_dceMarkReadPos(unsigned int, unsigned int*, unsigned int*, unsigned int);
void zF_2B8B6FF2_dceReleaseReadPos(unsigned int, unsigned int*, unsigned int*, unsigned int);
void zF_DBE1C164_dceProtectPos(unsigned int, unsigned int*, unsigned char*, unsigned int);
void zF_9ABC7A12_dceNoDeclPos(unsigned int, unsigned int*, unsigned char*, unsigned int);
int zF_0CFB522A_dceFieldIsArray(zT_338B7C76_TypeRegistry*, zT_BBC23664_LirFunction*, unsigned int, unsigned int);
int zF_914177A2_dceTempIsArray(zT_338B7C76_TypeRegistry*, zT_BBC23664_LirFunction*, unsigned int);
void zF_1D6170D7_dceMarkLoadGlobalAl(zT_BBC23664_LirFunction*, unsigned int, unsigned int*, unsigned char*);
int zF_0998EFA2_dceBaseEscapes(zT_338B7C76_TypeRegistry*, zT_BBC23664_LirFunction*, unsigned int, unsigned int*, unsigned char*, unsigned int);
void zF_BE5A1A76_dceMarkAllReads(zT_BBC23664_LirFunction*, unsigned int, unsigned int*, unsigned int*, unsigned char*, unsigned char*, zT_338B7C76_TypeRegistry*);
void zF_EE6AB5CC_dceMarkAllWritten(zT_BBC23664_LirFunction*, unsigned int, unsigned int*, unsigned char*);
unsigned int zF_80628BDC_dceResultPos(unsigned int, unsigned int*, zT_6BA597BC_LirInst);
void zF_B93233AE_dceReleaseOperands(unsigned int, unsigned int*, unsigned int*, zT_6BA597BC_LirInst);
void zF_A634DD52_emitFunctionBody(zT_72C4E2ED_C89Emitter*, zT_BBC23664_LirFunction*);
void zF_EC4B54F1_emitZigRuntimeC(zT_63BE4FF5_BufferedWriter*);
unsigned char zF_F873D0B7_moduleHasNetPrelude(zT_72C4E2ED_C89Emitter*, unsigned int);
unsigned char zF_E4C54F83_scriptNetEmitted(zT_72C4E2ED_C89Emitter*);
void zF_5B6C3E2D_writeModuleStem(zT_63BE4FF5_BufferedWriter*, zT_72C4E2ED_C89Emitter*, unsigned int);
void zF_482930D8_emitBuildTargetSh(zT_63BE4FF5_BufferedWriter*, zT_72C4E2ED_C89Emitter*, unsigned char);
void zF_72D68F16_emitBuildTargetBat(zT_63BE4FF5_BufferedWriter*, zT_72C4E2ED_C89Emitter*, unsigned char);
void zF_9851AA0C_emitBuildOwcBat(zT_63BE4FF5_BufferedWriter*, zT_72C4E2ED_C89Emitter*, unsigned char);
void zF_A62DB57E_emitBuildScripts(zT_72C4E2ED_C89Emitter*, zT_8F083A69_Slice_zT_0B42B2F8_u, int);
void zF_780653D2___module_init_11(void);
/* Storage globals (extern decls) */
extern zT_63BE4FF5_BufferedWriter zG_63BE4FF5_BufferedWriter;

#endif /* ZIG_MODULE_C89_EMIT_7CEF756E_H */
