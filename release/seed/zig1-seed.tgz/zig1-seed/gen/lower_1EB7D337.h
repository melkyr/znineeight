#ifndef ZIG_MODULE_LOWER_1EB7D337_H
#define ZIG_MODULE_LOWER_1EB7D337_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "lir_64CB5435.h"
#include "type_registry_8EE489B8.h"
#include "ast_2FA12982.h"
#include "symbol_table_74081C75.h"
#include "type_resolver_7446D285.h"
#include "resolved_type_table_5F22E794.h"
#include "coercion_F654E5FA.h"
#include "diagnostics_B9C6175E.h"
#include "allocator_E75B7A0B.h"
#include "module_registry_03A5D1FC.h"
#include "pal_388A8A1B.h"
#include "string_interner_51340A9F.h"
#include "format_0AEF880C.h"
#include "itoa_4E677A6A.h"
#include "hash_02AFCD13.h"

#ifndef ZIG_ENUM_zT_64DB3977_SrcIntent
#define ZIG_ENUM_zT_64DB3977_SrcIntent
typedef unsigned char zT_64DB3977_SrcIntent;
#define zT_64DB3977_SrcIntent_value 0
#define zT_64DB3977_SrcIntent_null_src 1
#define zT_64DB3977_SrcIntent_error_src 2

#endif /* ZIG_ENUM_zT_64DB3977_SrcIntent */
#ifndef ZIG_STRUCT_zT_CE6A1A99_DeferAction
#define ZIG_STRUCT_zT_CE6A1A99_DeferAction
struct zT_CE6A1A99_DeferAction {
	unsigned char kind;
	unsigned int ast_node;
	unsigned int scope_depth;
};
#endif /* ZIG_STRUCT_zT_CE6A1A99_DeferAction */
#ifndef ZIG_STRUCT_zT_78074DEF_LoopInfo
#define ZIG_STRUCT_zT_78074DEF_LoopInfo
struct zT_78074DEF_LoopInfo {
	unsigned int header_bb;
	unsigned int exit_bb;
	unsigned int scope_depth;
	unsigned int label_id;
	unsigned char is_loop;
};
#endif /* ZIG_STRUCT_zT_78074DEF_LoopInfo */
#ifndef ZIG_STRUCT_zT_6996DA09_SwitchInfo
#define ZIG_STRUCT_zT_6996DA09_SwitchInfo
struct zT_6996DA09_SwitchInfo {
	unsigned int exit_bb;
	unsigned int scope_depth;
};
#endif /* ZIG_STRUCT_zT_6996DA09_SwitchInfo */
#ifndef ZIG_STRUCT_zT_6B356268_SemanticContext
#define ZIG_STRUCT_zT_6B356268_SemanticContext
struct zT_6B356268_SemanticContext {
	zT_6B0A7D14_AstStore* store;
	zT_338B7C76_TypeRegistry* registry;
	zT_3D7259E2_SymbolRegistry* symbol_tables;
	zT_8EED1867_ResolvedTypeTable* resolved_types;
	zT_66E7D2EF_CoercionTable* coercions;
	zT_F85C5DED_DiagnosticCollector* diag;
	unsigned char has_symbols;
	zT_21D3708C_U32ToU32Map* enum_value_table;
	zT_21D3708C_U32ToU32Map* error_code_registry;
	zT_21D3708C_U32ToU32Map* call_arg_types;
	zT_89877D19_U32ToU64Map* comptime_values;
	unsigned int source_file_id;
	int safe_checks;
};
#endif /* ZIG_STRUCT_zT_6B356268_SemanticContext */
#ifndef ZIG_STRUCT_zT_FEED5D3B_ScopeNode
#define ZIG_STRUCT_zT_FEED5D3B_ScopeNode
struct zT_FEED5D3B_ScopeNode {
	unsigned int parent;
};
#endif /* ZIG_STRUCT_zT_FEED5D3B_ScopeNode */

/* Forward declarations */
zT_A528929E_DeferActionArrayLis zF_D7E63884_deferActionArrayLis(zT_3E40CD83_Sand*);
void zF_9A52C31C_deferActionArrayLis(zT_A528929E_DeferActionArrayLis*, unsigned int);
void zF_34324FBA_deferActionArrayLis(zT_A528929E_DeferActionArrayLis*, zT_CE6A1A99_DeferAction);
zT_D51BEFA9_Slice_zT_CE6A1A99_D zF_8EEF5430_deferActionArrayLis(zT_A528929E_DeferActionArrayLis*);
zT_5819C854_LoopInfoArrayList zF_BFDDD9F6_loopInfoArrayListIn(zT_3E40CD83_Sand*);
void zF_B3C859C6_loopInfoArrayListEn(zT_5819C854_LoopInfoArrayList*, unsigned int);
void zF_777F5414_loopInfoArrayListAp(zT_5819C854_LoopInfoArrayList*, zT_78074DEF_LoopInfo);
zT_D170EC13_Slice_zT_78074DEF_L zF_D557AEF2_loopInfoArrayListGe(zT_5819C854_LoopInfoArrayList*);
zT_347CB10E_SwitchInfoArrayList zF_CDA9E994_switchInfoArrayList(zT_3E40CD83_Sand*);
void zF_29F5730C_switchInfoArrayList(zT_347CB10E_SwitchInfoArrayList*, unsigned int);
void zF_7CCA342A_switchInfoArrayList(zT_347CB10E_SwitchInfoArrayList*, zT_6996DA09_SwitchInfo);
zT_CDB18CF4_Slice_zT_6996DA09_S zF_D08F52A0_switchInfoArrayList(zT_347CB10E_SwitchInfoArrayList*);
zT_2F2F63D8_ScopeNodeArrayList zF_185B250A_scopeNodeArrayListI(zT_3E40CD83_Sand*);
void zF_741A4582_scopeNodeArrayListE(zT_2F2F63D8_ScopeNodeArrayList*, unsigned int);
void zF_B9EDEF00_scopeNodeArrayListA(zT_2F2F63D8_ScopeNodeArrayList*, zT_FEED5D3B_ScopeNode);
unsigned int zF_EC8EDEA3_pushScope(zT_02EB57B2_LirLowerer*);
unsigned int zF_A647AFBB_createChildScope(zT_02EB57B2_LirLowerer*);
unsigned int zF_065C93D7_scopeNodeForDepth(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_FA65D3CC_pushScopeDepth(zT_02EB57B2_LirLowerer*);
void zF_8B8F7529_popScopeDepth(zT_02EB57B2_LirLowerer*);
void zF_0EC07EFB_dbgPrintU32_1(unsigned int);
zT_02EB57B2_LirLowerer zF_ADD4254B_lowererInit(zT_6B356268_SemanticContext*, zT_3E40CD83_Sand*);
void zF_32876AA1_markTerminated(zT_1CF28CA3_BasicBlockArrayList*, unsigned int);
void zF_2BFFB972_emitInst_1(zT_02EB57B2_LirLowerer*, zT_6BA597BC_LirInst);
unsigned char zF_5D365D2D_lowerTypeNeedsWidth(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_4C922328_maybeEmitWidthWrap(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_6FE4CEEE_nextTemp(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_7ECBEEB8_emitSafeCheckDivMod(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_EEA1A49D_emitUnwrapOptional(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_B8ED3823_emitSafeCheckShift(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned char zF_0347FA42_ovfTypeInfo(zT_02EB57B2_LirLowerer*, unsigned int, unsigned char*, unsigned char*);
void zF_1CDF5BA3_emitOverflowTrap(zT_02EB57B2_LirLowerer*, unsigned char, unsigned int, unsigned int, unsigned int, unsigned char, unsigned char);
void zF_5CB5DF8C_emitArith(zT_02EB57B2_LirLowerer*, unsigned char, unsigned char, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_CB14177A_emitArithNeg(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_F1AD6B87_materializeShiftLhs(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_91BEB32F_indexStaticLenForTy(zT_338B7C76_TypeRegistry*, unsigned int);
zT_BAEE192E_Opt_10 zF_FFA0B5C6_fieldStaticLenForBa(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_EB93517F_emitSafeCheckIndex(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_8798E89A_createBlock(zT_02EB57B2_LirLowerer*);
unsigned int zF_8901A261_lowerPrintCall(zT_02EB57B2_LirLowerer*, zT_3CB0179A_Slice_zT_05F374B1_u);
void zF_2B3F26D0_lowerPrintFmt(zT_02EB57B2_LirLowerer*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3CB0179A_Slice_zT_05F374B1_u);
unsigned int zF_6AC3874D_lowerExpr(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_91F40AA6_growLocalDecls(zT_02EB57B2_LirLowerer*);
void zF_01FA3083_addLocalDecl(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
void zF_53CD7E07_addLocalDeclRenamed(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
unsigned int zF_DBC54612_synthName(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_51219CC4_maybeDisambiguateCa(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_C33CF0E4_maybeDisambiguateCa(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_CD813FE1_iceInvalidIndex(zT_02EB57B2_LirLowerer*, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, unsigned int);
void zF_68907DF1_iceUnresolvedCompti(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_6ECD6705_iceSliceUnsupported(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_6DC54698_iceFieldStoreUnsupp(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_79B8C60B_iceAssignLValueUnsu(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_C8434936_iceAddrOfLValueUnsu(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_B3048E04_lowerLValueAddr(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_D1C5621B_lowerDerefStore(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_C0120437_lowerCompoundLValue(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
void zF_11EEF462_lowerAssignLValue(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned char zF_A603DDB6_lowerContainerOfAcc(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int*);
unsigned char zF_B4271A89_lowerPackedChainAna(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);
unsigned int zF_77D836E4_lowerTryNestedPacke(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_3F4B4E11_lowerTryNestedPacke(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
void zF_DEFDCF1F_lowerFieldStore(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
void zF_553B9A11_lowerAppendSwitchCa(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, zT_BAEE192E_Opt_10);
unsigned int zF_548C4299_getTempType(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_E93DD891_intCastTypeBits(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_62A7083D_intCastTypeIsSigned(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_75E39DC2_euPayloadOf(zT_02EB57B2_LirLowerer*, unsigned int);
zT_64DB3977_SrcIntent zF_26E51D42_srcIntentFor(zT_02EB57B2_LirLowerer*, zT_9CDC9863_CoercionEntry);
zT_64DB3977_SrcIntent zF_49F28A3E_srcIntentForNode(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_FFD1D48C_materializeInto(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, zT_64DB3977_SrcIntent);
unsigned int zF_8376227C_nameMapGet(zT_02EB57B2_LirLowerer*, unsigned int);
zT_5DDE4E4E_Opt_157 zF_437D3712_resolveLocal(zT_02EB57B2_LirLowerer*, unsigned int);
zT_BAEE192E_Opt_10 zF_BC67CF4B_findLocalTemp(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_EA729A13_resolveLocalSrcName(zT_02EB57B2_LirLowerer*, unsigned int);
int zF_48F3EEFE_captureShadowShould(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_EC7C7CAA_vaListArgTemp(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_A7800A44_maybeExtractSlicePt(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_6A464452_literalTempType(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_A0227773_emitTaggedUnionInit(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_9027C4CC_bindOptionalCapture(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
int zF_1941E6B1_isStorageGlobal(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_6512D642_lowerGlobalRef(zT_02EB57B2_LirLowerer*, zT_3A105EF1_Symbol, unsigned int);
unsigned int zF_941073CF_lowerExprImpl(zT_02EB57B2_LirLowerer*, unsigned int);
int zF_227F9586_lowerIsNoValueStmtK(zT_8143F551_AstKind);
unsigned int zF_FF2C7452_lowerIfArmValue(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_EA923F55_lowerExprOrBlock(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_8BA757D8_lowerStmtBody(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_A68D45DC_lowerStmt(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_88982963_pushDefer(zT_02EB57B2_LirLowerer*, unsigned char, unsigned int);
void zF_F1FD01D4_expandDefers(zT_02EB57B2_LirLowerer*, unsigned int, unsigned char, unsigned char);
void zF_6C953D7B_hoistTemps(zT_02EB57B2_LirLowerer*);
unsigned int zF_8CCBF5AD_applyNoneCoercion(zT_02EB57B2_LirLowerer*, unsigned int, zT_9CDC9863_CoercionEntry);
unsigned int zF_81D28EAB_applyCoercion(zT_02EB57B2_LirLowerer*, unsigned int, zT_9CDC9863_CoercionEntry);
unsigned char zF_B6098C2E_lowerDeclCallConvFl(zT_6B0A7D14_AstStore*, unsigned int);
zT_57DE44DC_Opt_159 zF_F5DD470C_findTailCall(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_0DAF32F1_zeroChainInsts(zT_02EB57B2_LirLowerer*, unsigned int);
int zF_E93020AC_hasOtherConsumers(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_26D1289F_zeroCallCFG(zT_02EB57B2_LirLowerer*, zT_DCBFE211_CallInfo, unsigned int);
void zF_000ED9B0_emitValuelessReturn(zT_02EB57B2_LirLowerer*);
zT_BBC23664_LirFunction zF_B53F5F2E_lowerFn(zT_02EB57B2_LirLowerer*, unsigned int);
zT_BBC23664_LirFunction zF_552B231C_lowerModuleInit(zT_02EB57B2_LirLowerer*, zT_3CB0179A_Slice_zT_05F374B1_u, unsigned int);
void zF_780653D2___module_init_12(void);
/* Storage globals (extern decls) */
extern zT_6B356268_SemanticContext zG_6B356268_SemanticContext;
extern zT_02EB57B2_LirLowerer zG_02EB57B2_LirLowerer;
extern unsigned char zG_665BA216_BIN_ADD;
extern unsigned char zG_B123C9B7_BIN_SUB;
extern unsigned char zG_C5DCA623_BIN_MUL;
extern unsigned char zG_B3BA5106_BIN_DIV;
extern unsigned char zG_B1EB9131_BIN_MOD;
extern unsigned char zG_526A8D24_BIN_AND;
extern unsigned char zG_9608E9F2_BIN_OR;
extern unsigned char zG_A635FC78_BIN_XOR;
extern unsigned char zG_C1038F3C_BIN_SHL;
extern unsigned char zG_B7037F7E_BIN_SHR;
extern unsigned char zG_D0FA3C49_BIN_EQ;
extern unsigned char zG_C50B7286_BIN_NE;
extern unsigned char zG_A2114B9B_BIN_LT;
extern unsigned char zG_911130D8_BIN_LE;
extern unsigned char zG_DFF5D6B8_BIN_GT;
extern unsigned char zG_F0F5F17B_BIN_GE;
extern unsigned char zG_5456A137_BIN_WADD;
extern unsigned char zG_F8B4657E_BIN_WSUB;
extern unsigned char zG_9231FA9A_BIN_WMUL;
extern unsigned char zG_485EFCA3_BIN_SADD;
extern unsigned char zG_F37F9902_BIN_SSUB;
extern unsigned char zG_0BB5117E_BIN_SMUL;
extern unsigned char zG_FB3CBFAD_BIN_SSHL;
extern unsigned char zG_B40FF1EF_UN_NEG;
extern unsigned char zG_A11EDE90_UN_NOT;
extern unsigned char zG_AA86A848_UN_BNOT;
extern unsigned char zG_D4685406_UN_WNEG;

#endif /* ZIG_MODULE_LOWER_1EB7D337_H */
