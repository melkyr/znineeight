#ifndef ZIG_MODULE_LOWER_1EB7D337_H
#define ZIG_MODULE_LOWER_1EB7D337_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "lir_64CB5435.h"
#include "type_registry_8EE489B8.h"
#include "ast_2FA12982.h"
#include "symbol_table_74081C75.h"
#include "type_resolver_7446D285.h"
#include "resolved_type_table_5F22E794.h"
#include "coercion_F654E5FA.h"
#include "diagnostics_B9C6175E.h"
#include "allocator_E75B7A0B.h"
#include "module_registry_03A5D1FC.h"
#include "pal_388A8A1B.h"
#include "string_interner_51340A9F.h"
#include "format_0AEF880C.h"
#include "itoa_4E677A6A.h"
#include "hash_02AFCD13.h"
#include "async_analysis_A8747991.h"
#include "async_state_machine_A730A7D6.h"
#include "comptime_eval_02C4526F.h"
#include "const_init_eval_283ED887.h"
#include "growable_array_6014E5AF.h"

#ifndef ZIG_STRUCT_zT_CE6A1A99_DeferAction
#define ZIG_STRUCT_zT_CE6A1A99_DeferAction
struct zT_CE6A1A99_DeferAction {
	unsigned char kind;
	unsigned int ast_node;
	unsigned int scope_depth;
};
#endif /* ZIG_STRUCT_zT_CE6A1A99_DeferAction */
#ifndef ZIG_STRUCT_zT_78074DEF_LoopInfo
#define ZIG_STRUCT_zT_78074DEF_LoopInfo
struct zT_78074DEF_LoopInfo {
	unsigned int header_bb;
	unsigned int exit_bb;
	unsigned int scope_depth;
	unsigned int label_id;
	unsigned char is_loop;
};
#endif /* ZIG_STRUCT_zT_78074DEF_LoopInfo */
#ifndef ZIG_STRUCT_zT_6996DA09_SwitchInfo
#define ZIG_STRUCT_zT_6996DA09_SwitchInfo
struct zT_6996DA09_SwitchInfo {
	unsigned int exit_bb;
	unsigned int scope_depth;
};
#endif /* ZIG_STRUCT_zT_6996DA09_SwitchInfo */
#ifndef ZIG_STRUCT_zT_6B356268_SemanticContext
#define ZIG_STRUCT_zT_6B356268_SemanticContext
struct zT_6B356268_SemanticContext {
	zT_6B0A7D14_AstStore* store;
	zT_338B7C76_TypeRegistry* registry;
	zT_3D7259E2_SymbolRegistry* symbol_tables;
	zT_8EED1867_ResolvedTypeTable* resolved_types;
	zT_66E7D2EF_CoercionTable* coercions;
	zT_F85C5DED_DiagnosticCollector* diag;
	unsigned char has_symbols;
	zT_21D3708C_U32ToU32Map* enum_value_table;
	zT_21D3708C_U32ToU32Map* tuple_index_table;
	zT_21D3708C_U32ToU32Map* error_code_registry;
	zT_21D3708C_U32ToU32Map* call_arg_types;
	zT_77F6F59C_ComptimeFoldTable* comptime_folds;
	zT_4065182A_ConstInitTable* const_inits;
	unsigned int source_file_id;
	unsigned char safe_checks;
	zT_A4CE86B7_U64ToU32Map* suspending_fns;
	zT_A4CE86B7_U64ToU32Map* frame_sizes;
	zT_A4CE86B7_U64ToU32Map* state_widths;
	unsigned char print_value_lowered;
};
#endif /* ZIG_STRUCT_zT_6B356268_SemanticContext */
#ifndef ZIG_STRUCT_zT_E43B433F_ExprFrame
#define ZIG_STRUCT_zT_E43B433F_ExprFrame
struct zT_E43B433F_ExprFrame {
	unsigned int node_idx;
	unsigned short phase;
	unsigned int kind;
	unsigned int slot0;
	unsigned int slot1;
	unsigned int slot2;
	unsigned int slot3;
	unsigned int slot4;
	unsigned int slot5;
	unsigned int slot6;
	unsigned int slot7;
};
#endif /* ZIG_STRUCT_zT_E43B433F_ExprFrame */
#ifndef ZIG_STRUCT_zT_541B8B10_StmtFrame
#define ZIG_STRUCT_zT_541B8B10_StmtFrame
struct zT_541B8B10_StmtFrame {
	unsigned int node_idx;
	unsigned short phase;
	unsigned short fk;
	unsigned int kind;
	unsigned int slot0;
	unsigned int slot1;
	unsigned int slot2;
	unsigned int slot3;
	unsigned int slot4;
	unsigned int slot5;
	unsigned int slot6;
	unsigned int slot7;
};
#endif /* ZIG_STRUCT_zT_541B8B10_StmtFrame */
#ifndef ZIG_STRUCT_zT_FEED5D3B_ScopeNode
#define ZIG_STRUCT_zT_FEED5D3B_ScopeNode
struct zT_FEED5D3B_ScopeNode {
	unsigned int parent;
};
#endif /* ZIG_STRUCT_zT_FEED5D3B_ScopeNode */
#ifndef ZIG_STRUCT_zT_9E19433B_LowerFieldRecord
#define ZIG_STRUCT_zT_9E19433B_LowerFieldRecord
struct zT_9E19433B_LowerFieldRecord {
	unsigned int name_id;
	unsigned int type_id;
};
#endif /* ZIG_STRUCT_zT_9E19433B_LowerFieldRecord */
#ifndef ZIG_STRUCT_zT_9FADB13D_IndexAddrResult
#define ZIG_STRUCT_zT_9FADB13D_IndexAddrResult
struct zT_9FADB13D_IndexAddrResult {
	unsigned int addr;
	unsigned int orig_base;
	unsigned int ptr;
	unsigned int idx;
	unsigned int tuple_bt;
	unsigned int tuple_ord;
	unsigned char is_tuple;
};
#endif /* ZIG_STRUCT_zT_9FADB13D_IndexAddrResult */

/* Forward declarations */
unsigned char* zF_BAE19223_arrayListEnsureCapa(zT_3E40CD83_Sand*, unsigned char*, unsigned int, unsigned int*, unsigned int, unsigned int);
zT_A528929E_DeferActionArrayLis zF_D7E63884_deferActionArrayLis(zT_3E40CD83_Sand*);
void zF_9A52C31C_deferActionArrayLis(zT_A528929E_DeferActionArrayLis*, unsigned int);
void zF_34324FBA_deferActionArrayLis(zT_A528929E_DeferActionArrayLis*, zT_CE6A1A99_DeferAction);
zT_D51BEFA9_Slice_zT_CE6A1A99_D zF_8EEF5430_deferActionArrayLis(zT_A528929E_DeferActionArrayLis*);
zT_7516B2E4_ExprFrameArrayList zF_8345CBA6_exprFrameArrayListI(zT_3E40CD83_Sand*);
void zF_1D8FC096_exprFrameArrayListE(zT_7516B2E4_ExprFrameArrayList*, unsigned int);
void zF_3CE3BCE4_exprFrameArrayListA(zT_7516B2E4_ExprFrameArrayList*, zT_E43B433F_ExprFrame);
zT_660D886E_Slice_zT_E43B433F_E zF_BE0C6E82_exprFrameArrayListG(zT_7516B2E4_ExprFrameArrayList*);
zT_D2C585A9_StmtFrameArrayList zF_B030E177_stmtFrameArrayListI(zT_3E40CD83_Sand*);
void zF_53B6F4CF_stmtFrameArrayListE(zT_D2C585A9_StmtFrameArrayList*, unsigned int);
void zF_1DE5B9FD_stmtFrameArrayListA(zT_D2C585A9_StmtFrameArrayList*, zT_541B8B10_StmtFrame);
zT_5819C854_LoopInfoArrayList zF_BFDDD9F6_loopInfoArrayListIn(zT_3E40CD83_Sand*);
void zF_B3C859C6_loopInfoArrayListEn(zT_5819C854_LoopInfoArrayList*, unsigned int);
void zF_777F5414_loopInfoArrayListAp(zT_5819C854_LoopInfoArrayList*, zT_78074DEF_LoopInfo);
zT_D170EC13_Slice_zT_78074DEF_L zF_D557AEF2_loopInfoArrayListGe(zT_5819C854_LoopInfoArrayList*);
zT_347CB10E_SwitchInfoArrayList zF_CDA9E994_switchInfoArrayList(zT_3E40CD83_Sand*);
void zF_29F5730C_switchInfoArrayList(zT_347CB10E_SwitchInfoArrayList*, unsigned int);
void zF_7CCA342A_switchInfoArrayList(zT_347CB10E_SwitchInfoArrayList*, zT_6996DA09_SwitchInfo);
zT_CDB18CF4_Slice_zT_6996DA09_S zF_D08F52A0_switchInfoArrayList(zT_347CB10E_SwitchInfoArrayList*);
zT_2F2F63D8_ScopeNodeArrayList zF_185B250A_scopeNodeArrayListI(zT_3E40CD83_Sand*);
void zF_741A4582_scopeNodeArrayListE(zT_2F2F63D8_ScopeNodeArrayList*, unsigned int);
void zF_B9EDEF00_scopeNodeArrayListA(zT_2F2F63D8_ScopeNodeArrayList*, zT_FEED5D3B_ScopeNode);
unsigned int zF_EC8EDEA3_pushScope(zT_02EB57B2_LirLowerer*);
unsigned int zF_A647AFBB_createChildScope(zT_02EB57B2_LirLowerer*);
unsigned int zF_065C93D7_scopeNodeForDepth(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_FA65D3CC_pushScopeDepth(zT_02EB57B2_LirLowerer*);
void zF_8B8F7529_popScopeDepth(zT_02EB57B2_LirLowerer*);
void zF_0EC07EFB_dbgPrintU32_1(unsigned int);
zT_02EB57B2_LirLowerer zF_ADD4254B_lowererInit(zT_6B356268_SemanticContext*, zT_3E40CD83_Sand*);
void zF_32876AA1_markTerminated(zT_1CF28CA3_BasicBlockArrayList*, unsigned int);
void zF_2BFFB972_emitInst_1(zT_02EB57B2_LirLowerer*, zT_6BA597BC_LirInst);
unsigned int zF_4E3882BD_lowerFieldRecordNon(void);
zT_9E19433B_LowerFieldRecord zF_ADFADB9B_lowerFieldRecord(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_F6E8D87C_lowerTempSemanticTy(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_08CD9E05_lowerSemIsSigned(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_833BA372_lowerBinSemType(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned char);
zT_6BA597BC_LirInst zF_9F18756E_lowerRecordFacts(zT_02EB57B2_LirLowerer*, zT_6BA597BC_LirInst);
zT_ABC1EBBE_TypeResolveEnv zF_5C16E02D_lowerTypeResolveEnv(zT_02EB57B2_LirLowerer*, zT_622E1E76_Opt_254);
unsigned char zF_5D365D2D_lowerTypeNeedsWidth(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_4C922328_maybeEmitWidthWrap(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_6FE4CEEE_nextTemp(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_7ECBEEB8_emitSafeCheckDivMod(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_EEA1A49D_emitUnwrapOptional(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_B8ED3823_emitSafeCheckShift(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned char zF_0347FA42_ovfTypeInfo(zT_02EB57B2_LirLowerer*, unsigned int, unsigned char*, unsigned char*);
void zF_1CDF5BA3_emitOverflowTrap(zT_02EB57B2_LirLowerer*, unsigned char, unsigned int, unsigned int, unsigned int, unsigned char, unsigned char);
void zF_5CB5DF8C_emitArith(zT_02EB57B2_LirLowerer*, unsigned char, unsigned char, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_CB14177A_emitArithNeg(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_F1AD6B87_materializeShiftLhs(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_91BEB32F_indexStaticLenForTy(zT_338B7C76_TypeRegistry*, unsigned int);
zT_BAEE192E_Opt_10 zF_FFA0B5C6_fieldStaticLenForBa(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_EB93517F_emitSafeCheckIndex(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
void zF_EA594D51_emitSafeBoundLeTrap(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_BC465F49_sliceBaseStaticLen(zT_02EB57B2_LirLowerer*, unsigned int);
zT_44E16D78_Opt_7 zF_B549356E_sliceBoundComptimeI(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_B7A124FA_emitSafeCheckSliceR(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned char, zT_44E16D78_Opt_7, zT_44E16D78_Opt_7);
void zF_966312B1_emitSafeCheckSliceO(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char, zT_44E16D78_Opt_7);
unsigned int zF_ADAE26AF_indexBaseAfterArray(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_8798E89A_createBlock(zT_02EB57B2_LirLowerer*);
unsigned char zF_69D4A0D8_printFmtReject(zT_02EB57B2_LirLowerer*, unsigned int, unsigned short, unsigned char);
unsigned char zF_AB3D03AA_printFmtKindIsInteg(zT_33EF6BFB_TypeKind);
unsigned char zF_81C7D464_printFmtKindIsAggre(zT_33EF6BFB_TypeKind);
unsigned char zF_7DD0EC26_printFmtArgIsTypeVa(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_0060D14B_printFmtPtrPointeeO(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned char zF_103A3DFE_printFmtPtrRouteOk(zT_338B7C76_TypeRegistry*, zT_33EF6BFB_TypeKind, unsigned int, unsigned int, unsigned char);
unsigned char zF_DB96A738_printFmtPointeeName(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned int zF_9FEE2B90_printFmtU32DecLen(unsigned int);
unsigned int zF_EAD4F764_printFmtQualsLen(unsigned char);
unsigned char zF_52FCB125_printFmtPointeeName(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned int*);
unsigned char zF_E643E474_printFmtAggFieldKin(zT_338B7C76_TypeRegistry*, unsigned int, unsigned char, unsigned int);
unsigned char zF_81F205DB_printFmtAggFieldsOk(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
unsigned char zF_476C7265_printFmtCheck(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char, unsigned char);
unsigned char zF_46CA06A7_lowerUntypedIntFact(zT_02EB57B2_LirLowerer*, zT_0163D9A4_ComptimeInt, unsigned char*, unsigned char*);
void zF_3FAB82B5_emitIntConstFacts(zT_02EB57B2_LirLowerer*, zT_79FAE712_u64, unsigned int, unsigned char, unsigned char);
void zF_33E5F11E_emitIntConst(zT_02EB57B2_LirLowerer*, zT_79FAE712_u64, unsigned int);
zT_7534F824_Opt_223 zF_779DA2DB_foldPrintArgIntExac(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_9BE9CDE6_lowerExactIntArg(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_DBECFF2D_printFmtContainerRe(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_0803E8B9_lowerPrintArityReje(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_2B3F26D0_lowerPrintFmt(zT_02EB57B2_LirLowerer*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
void zF_CB95F33B_lowerExprDepthGuard(zT_02EB57B2_LirLowerer*);
void zF_02936025_lowerExprLexMarkers(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_D1BCAE89_lowerExprCoerceResu(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_B1304DF7_lowerExprDriver(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_531F688D_lowerExprPushChild(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned int, unsigned short);
void zF_AA6AB210_lowerExprPrologue(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_4087A32B_lowerAddStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_7E02E7B0_lowerAddLikeStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char, unsigned char);
unsigned int zF_A1A3B319_lowerDivModStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned char);
unsigned int zF_0B20275D_lowerShlStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_F37122DB_lowerShrStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_AA986959_lowerBinaryArmStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned char);
unsigned int zF_D7F0A91E_lowerCmpSimpleStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned char);
unsigned int zF_5BA57B4A_lowerCmpEqStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_F1B6805E_lowerNegateStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_9923BEAA_lowerWrapNegateStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_E806E0C1_lowerBoolNotStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_621DA828_lowerBitNotStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_D614A638_lowerDerefStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_F35B08B6_lowerTryExprRest(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_4ED1C2CA_lowerTryExprStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_50302B14_lowerCompoundAssign(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned char, unsigned char, unsigned char, unsigned char);
unsigned int zF_0024A205_lowerPlainAssignSte(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_E93A928A_lowerIndexAccessSte(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_2742AFEA_lowerFieldAccessSte(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_DD71EF66_lowerBlockValueStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned char zF_745F042D_lowerBuiltinIsCastP(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_88F32A54_lowerBuiltinCastSte(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_14E6D2E9_lowerBoolOrStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_213C512D_lowerBoolAndStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_EAD33257_lowerFnCallATail(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
unsigned int zF_8388C702_lowerFnCallBTail(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned int zF_81308D39_lowerFnCallCTail(zT_02EB57B2_LirLowerer*, unsigned int, zT_6B0A7D14_AstStore*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
unsigned int zF_F32F5314_lowerFnCallDTail(zT_02EB57B2_LirLowerer*, unsigned int, zT_6B0A7D14_AstStore*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
unsigned int zF_42F9D033_lowerFnCallETail(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_8A0E1070_lowerFnCallStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_9B239FC5_lowerFnCallStep7(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_942394C0_lowerFnCallStep0(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_8AC8EF54_lowerCatchExprStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_CF62824B_lowerOrElseExprStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_19E7F440_lowerOrElseOkJoin(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned int zF_70F9FE7B_lowerIfExprThenRest(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned int);
unsigned int zF_8E8806B5_lowerIfExprElseRest(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned int);
unsigned int zF_06F696C4_lowerIfExprStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_D0D23D0D_lowerLabeledStmtSte(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
void zF_F9086C75_lowerStructInitFiel(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char, unsigned int);
unsigned int zF_7D056D17_lowerStructInitLoop(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned char, unsigned int);
unsigned int zF_0C006623_lowerStructInitStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_FDE26F46_lowerArrayElemLoop(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned char, unsigned int);
unsigned int zF_CDF7C60F_lowerArrayInitStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_AECC80D1_lowerTupleLiteralLo(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned char, unsigned int);
unsigned int zF_C1B7F381_lowerTupleLiteralSt(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_7C6B78AB_lowerSwtExLoop(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned char, unsigned int);
unsigned int zF_65C1DD4F_lowerSwtExStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_AB1CD9E3_lowerSliceEndTail(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned int zF_AF94D2DA_lowerSliceOpenTail(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*, unsigned int);
unsigned int zF_60CF60F5_lowerSliceExprStep(zT_02EB57B2_LirLowerer*, zT_E43B433F_ExprFrame*);
unsigned int zF_4626C377_lowerExprStep(zT_02EB57B2_LirLowerer*);
unsigned int zF_6AC3874D_lowerExpr(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_91F40AA6_growLocalDecls(zT_02EB57B2_LirLowerer*);
void zF_09973D64_localDeclMarkMarker(unsigned int, unsigned int, unsigned int);
void zF_C7A3D934_localDeclPushRow(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
void zF_01FA3083_addLocalDecl(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
void zF_53CD7E07_addLocalDeclRenamed(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
unsigned int zF_DBC54612_synthName(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_51219CC4_maybeDisambiguateCa(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_C33CF0E4_maybeDisambiguateCa(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_CD813FE1_iceInvalidIndex(zT_02EB57B2_LirLowerer*, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, unsigned int);
void zF_8DBCE456_iceReportNode(zT_02EB57B2_LirLowerer*, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
void zF_6ECD6705_iceSliceUnsupported(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_6DC54698_iceFieldStoreUnsupp(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_79B8C60B_iceAssignLValueUnsu(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_C8434936_iceAddrOfLValueUnsu(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_523B73AB_tempTypeIsPtrToArra(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_FFC0D80B_lowerTupleElemRead(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_4A0FC023_lowerArrayElemTuple(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_6E329C0C_lowerFindFieldOrdin(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char);
zT_9FADB13D_IndexAddrResult zF_F03117EE_lowerIndexElemAddr(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
unsigned int zF_B3048E04_lowerLValueAddr(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_D1C5621B_lowerDerefStore(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_A23CDBF0_lowerLoopOpen(zT_02EB57B2_LirLowerer*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);
void zF_1DAA9024_lowerLoopBranchBody(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
void zF_E7CA436B_lowerLoopToStep(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_80B404DC_lowerLoopClose(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_695756C4_lowerCompoundAssign(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned char, unsigned char, unsigned char, unsigned char);
unsigned int zF_C9518CD6_lowerFieldAccessRes(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_A497B776_lowerIndexAccessRes(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned int zF_7CF420C9_lowerPlainAssignRes(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char);
unsigned int zF_336C90E6_lowerCompoundAssign(zT_02EB57B2_LirLowerer*, unsigned int, unsigned char, unsigned char, unsigned char, unsigned char);
void zF_C0120437_lowerCompoundLValue(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
void zF_11EEF462_lowerAssignLValue(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_01E895C4_d5IndexAssignArrayT(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_AF9C6CE0_d5BaseChainHasIndex(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_A603DDB6_lowerContainerOfAcc(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int*);
unsigned char zF_B4271A89_lowerPackedChainAna(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);
unsigned int zF_77D836E4_lowerTryNestedPacke(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_B2F1B500_lowerPackedWholeCop(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned char zF_04B993A3_lowerTempIsPackedAg(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_3F4B4E11_lowerTryNestedPacke(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned char zF_534BD35D_lowerPackedMemberSt(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_E2C707F0_lowerPackedMemberLo(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_DEFDCF1F_lowerFieldStore(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
zT_BBEE1AC1_Opt_11 zF_FC7512B2_lowerSwitchCaseItem(zT_02EB57B2_LirLowerer*, unsigned int, zT_BAEE192E_Opt_10);
zT_BBEE1AC1_Opt_11 zF_2A9A26A8_lowerSwitchCaseItem(zT_02EB57B2_LirLowerer*, unsigned int, zT_BAEE192E_Opt_10);
zT_BBEE1AC1_Opt_11 zF_3A610D05_lowerSwitchCaseItem(zT_02EB57B2_LirLowerer*, unsigned int, zT_BAEE192E_Opt_10);
zT_BBEE1AC1_Opt_11 zF_63FB2E96_lowerSwitchCaseItem(zT_02EB57B2_LirLowerer*, unsigned int, zT_BAEE192E_Opt_10, unsigned int);
zT_BAEE192E_Opt_10 zF_6F684980_lowerSwitchCaseItem(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_1A509083_lowerSwitchCaseItem(zT_3A105EF1_Symbol*);
void zF_553B9A11_lowerAppendSwitchCa(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, zT_BAEE192E_Opt_10);
void zF_FC4B418C_lowerSwitchDispatch(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, zT_BAEE192E_Opt_10, unsigned int*, unsigned int*, unsigned int*, unsigned int*, unsigned int*);
unsigned int zF_548C4299_getTempType(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_C1A02528_lowerUnionPayloadIs(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_E93DD891_intCastTypeBits(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned char zF_62A7083D_intCastTypeIsSigned(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_A49FFF10_euTypeOfTemp(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_75E39DC2_euPayloadOf(zT_02EB57B2_LirLowerer*, unsigned int);
zT_64DB3977_SrcIntent zF_26E51D42_srcIntentFor(zT_02EB57B2_LirLowerer*, zT_9CDC9863_CoercionEntry);
zT_64DB3977_SrcIntent zF_49F28A3E_srcIntentForNode(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_DF5C4BE6_reportComptimeIntFi(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_AA37E401_scalarTargetOf(zT_02EB57B2_LirLowerer*, unsigned int);
zT_7534F824_Opt_223 zF_8783BA36_foldNodeIntExact(zT_02EB57B2_LirLowerer*, unsigned int, unsigned char);
void zF_B9B7A0AF_checkIntFitsMode(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char);
void zF_13324B12_checkFoldedIntFits(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_6276E364_checkArgReturnIntFi(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_9994AAAD_checkDeclInitFits(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
zT_49E17557_Opt_2 zF_BC8B3F88_comptimeFoldBool(zT_02EB57B2_LirLowerer*, unsigned int);
zT_BAEE192E_Opt_10 zF_8FBEFC00_lowerFoldedIntConst(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char);
unsigned int zF_FFD1D48C_materializeInto(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, zT_64DB3977_SrcIntent, unsigned int);
unsigned int zF_8376227C_nameMapGet(zT_02EB57B2_LirLowerer*, unsigned int);
zT_D7D6BF97_Opt_169 zF_437D3712_resolveLocal(zT_02EB57B2_LirLowerer*, unsigned int);
zT_BAEE192E_Opt_10 zF_BC67CF4B_findLocalTemp(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_EA729A13_resolveLocalSrcName(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_48F3EEFE_captureShadowShould(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_EC7C7CAA_vaListArgTemp(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_A7800A44_maybeExtractSlicePt(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_6A464452_literalTempType(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_A0227773_emitTaggedUnionInit(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_7673B8F8_resolveRtypeOrU32(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_D4CC5B7B_lowerBinaryArm(zT_02EB57B2_LirLowerer*, unsigned int, unsigned char);
unsigned char zF_616D6777_lowerWrapArithOp(zT_8143F551_AstKind);
unsigned char zF_0E9A2DD7_lowerSatArithOp(zT_8143F551_AstKind);
unsigned int zF_29D90A35_lowerPreallocArgs(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_9D33686C_bindCapture(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned int zF_0D4500CD_lowerCallArgMateria(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
unsigned int zF_B8A2A7AB_lowerCallArgMateria(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_9027C4CC_bindOptionalCapture(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned char zF_43F85A55_symbolIsStorageGlob(zT_3A105EF1_Symbol*);
unsigned char zF_EAEB5357_symbolIsConstGlobal(zT_3A105EF1_Symbol*);
unsigned int zF_9A74B249_foldConstTreeScalar(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned char zF_1941E6B1_isStorageGlobal(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_6512D642_lowerGlobalRef(zT_02EB57B2_LirLowerer*, zT_3A105EF1_Symbol, unsigned int);
unsigned int zF_A44E46D7_materializeFnRef(zT_02EB57B2_LirLowerer*, zT_3A105EF1_Symbol*);
unsigned char zF_E9D80BCA_asyncFindProto(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, zT_243D6A41_FnProto*);
void zF_998B4F70_asyncEmitStoreAt(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned int zF_24E02D85_asyncEmitLoadAt(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_58BF6612_resolveModuleBase(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_D29C6DC1_lowerModuleMemberVa(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
unsigned int zF_941073CF_lowerExprImpl(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_3E942A8E_lowerExprLit(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_58BF6DF4_lowerExprBinary(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_B8321ECF_lowerExprCmp(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_0B7F8015_lowerExprBool(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_9D1C5448_lowerExprUnary(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_424DBF33_lowerExprIndex(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_D717244D_lowerExprIdent(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_26EFB63F_lowerExprField(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_4C3A6791_lowerExprCall(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_97EB0FAC_lowerExprCallFieldP(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_FA367AD8_lowerExprBuiltin(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_E74761AC_lowerExprBuiltinAsy(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_46B4CBA9_lowerExprTryCatch(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_7C92131E_lowerExprIf(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_FEC7525A_lowerExprStructInit(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_C341D799_lowerExprSwitch(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_CD1E9029_lowerExprSlice(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_86A5A211_lowerExprMisc(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_1989E5B1_lowerIsAssignmentKi(zT_8143F551_AstKind);
unsigned char zF_C21F9F9E_lowerBodyIsValueles(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_227F9586_lowerIsNoValueStmtK(zT_8143F551_AstKind);
void zF_F76B1D56_lowerStmtDriverRoot(zT_02EB57B2_LirLowerer*, unsigned int, unsigned short);
void zF_0637173E_lowerStmtPushChild(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*, unsigned int, unsigned short, unsigned short);
void zF_6BCBBFF9_lowerStmtPrologue(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_C7BBF571_lowerStmtBlcMarker(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_8648ADEE_lowerStmtStep(zT_02EB57B2_LirLowerer*);
void zF_532868FA_lowerStmtBodyStep(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
void zF_CFDDD673_lowerBlockStmtStep(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
void zF_9A5D7639_lowerStmtLabeledSte(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
void zF_F9FF0451_lowerIfStmtStep(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
void zF_17F29BD3_lowerWhileStmtStep(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
void zF_CA181365_lowerForStmtStep(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
void zF_515E863D_lowerSwtProngBegin(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
void zF_E7E41B0C_lowerSwtStmtStep(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
void zF_82D92DE1_lowerExprStmtStep(zT_02EB57B2_LirLowerer*, zT_541B8B10_StmtFrame*);
unsigned int zF_FF2C7452_lowerIfArmValue(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned int zF_EA923F55_lowerExprOrBlock(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_8BA757D8_lowerStmtBody(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_A68D45DC_lowerStmt(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_1F77E9D6_lowerStmtLeafStep(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_BA974C5D_lowerStmtLeafBlock(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_9D917923_lowerStmtLeafIf(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_6E175AF9_lowerStmtLeafWhile(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_C06B63BB_lowerStmtLeafFor(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_0FC24B10_lowerStmtLeafSwitch(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_0C67CA5A_lowerStmtLeafReturn(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_530FB030_lowerStmtLeafJump(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_8D06E68D_lowerStmtLeafVarDec(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_A5752FE4_lowerStmtLeafMisc(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_88982963_pushDefer(zT_02EB57B2_LirLowerer*, unsigned char, unsigned int);
void zF_F1FD01D4_expandDefers(zT_02EB57B2_LirLowerer*, unsigned int, unsigned char, unsigned char);
void zF_6C953D7B_hoistTemps(zT_02EB57B2_LirLowerer*);
unsigned int zF_8CCBF5AD_applyNoneCoercion(zT_02EB57B2_LirLowerer*, unsigned int, zT_9CDC9863_CoercionEntry);
unsigned int zF_C78022F0_applyTupleToTuple(zT_02EB57B2_LirLowerer*, unsigned int, zT_9CDC9863_CoercionEntry);
unsigned int zF_81D28EAB_applyCoercion(zT_02EB57B2_LirLowerer*, unsigned int, zT_9CDC9863_CoercionEntry);
unsigned char zF_B6098C2E_lowerDeclCallConvFl(zT_6B0A7D14_AstStore*, unsigned int);
unsigned int zF_82CFCE45_lowerCalleeFnTypeId(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned char);
zT_D1D8F4BC_Opt_173 zF_F5DD470C_findTailCall(zT_02EB57B2_LirLowerer*, unsigned int);
void zF_0DAF32F1_zeroChainInsts(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_E93020AC_hasOtherConsumers(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int);
void zF_26D1289F_zeroCallCFG(zT_02EB57B2_LirLowerer*, zT_DCBFE211_CallInfo, unsigned int);
void zF_000ED9B0_emitValuelessReturn(zT_02EB57B2_LirLowerer*);
void zF_4BBBF787_lirFunctionInitHead(zT_02EB57B2_LirLowerer*, zT_BBC23664_LirFunction*);
zT_BBC23664_LirFunction zF_B53F5F2E_lowerFn(zT_02EB57B2_LirLowerer*, unsigned int);
unsigned char zF_9AC07CAC_lowerInitIsImportAl(zT_6B0A7D14_AstStore*, unsigned int);
unsigned int zF_A1FFC760_lowerModuleAliasIni(zT_02EB57B2_LirLowerer*, unsigned int);
zT_BBC23664_LirFunction zF_552B231C_lowerModuleInit(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, zT_A4CE86B7_U64ToU32Map*);
unsigned char zF_6EFFA421_lowerInitKindHasExt(zT_8143F551_AstKind);
void zF_94BF5FD5_lowerInitDepAppend(unsigned int*, unsigned int*, unsigned int, unsigned int);
void zF_4333799C_lowerInitDepScan(zT_02EB57B2_LirLowerer*, unsigned int, unsigned int, unsigned int*, unsigned int*, unsigned int);
/* Storage globals (extern decls) */
extern zT_6B356268_SemanticContext zG_6B356268_SemanticContext;
extern zT_02EB57B2_LirLowerer zG_02EB57B2_LirLowerer;

#endif /* ZIG_MODULE_LOWER_1EB7D337_H */
