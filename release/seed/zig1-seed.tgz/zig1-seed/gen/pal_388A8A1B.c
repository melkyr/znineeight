#include "pal_388A8A1B.h"
unsigned char* zG_970FEF1B_MODE_READ;
unsigned int zG_CC81CC5F_INVALID_FD;
int zG_F46B0200_saved_argc;
unsigned char** zG_096B230F_saved_argv;
unsigned int zG_EE253928_g_markers_enabled;
/* readFile */
zT_05D09430_Opt_436 zF_5B859C63_readFile(zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc) {
    zT_846744CC_Arr_unsigned_char_5 zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_10;
    int zT_11;
    unsigned char* zT_13;
    unsigned char zT_14;
    int zT_15;
    unsigned int zT_17;
    int zT_18;
    zT_05D09430_Opt_436 zT_20 = {0};
    int zT_21;
    unsigned char zT_22;
    unsigned char* zT_24;
    unsigned char* zT_25;
    int zT_26;
    unsigned char* zT_27;
    zT_05CE5599_Opt_400 zT_29 = {0};
    unsigned char zT_30;
    void* zT_31;
    zT_05D09430_Opt_436 zT_32 = {0};
    void* zT_34;
    int zT_36;
    int zT_37;
    unsigned int zT_39;
    int zT_40 = 0;
    void* zT_42;
    int zT_43 = 0;
    int zT_44;
    void* zT_46;
    int zT_47 = 0;
    zT_05D09430_Opt_436 zT_48 = {0};
    void* zT_49;
    int zT_51;
    int zT_52;
    unsigned int zT_54;
    int zT_55 = 0;
    unsigned int zT_57;
    zT_3E40CD83_Sand* zT_59;
    zT_C6536882_EU_532 zT_64 = {0};
    unsigned char zT_65;
    unsigned char* zT_66;
    void* zT_67;
    int zT_68 = 0;
    zT_05D09430_Opt_436 zT_69 = {0};
    unsigned char* zT_72;
    unsigned char* zT_74;
    unsigned int zT_76;
    void* zT_77;
    int zT_78;
    unsigned int zT_80 = 0;
    void* zT_81;
    int zT_82 = 0;
    zT_05D09430_Opt_436 zT_84 = {0};
    int zT_85;
    unsigned char* zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    zT_05D09430_Opt_436 zT_89;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    void* f;
    int size;
    unsigned int sz;
    unsigned char* raw;
    unsigned char* buf;
    unsigned int read;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_8 = path.len;
    if ((int)(i < zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_13 = path.ptr;
    zT_14 = zT_13[i];
    c_path[i] = zT_14;
    zT_15 = 1;
    zT_17 = i + (unsigned int)((unsigned int)zT_15);
    i = zT_17;
    goto z_bb_4;
    z_bb_3:
    zT_18 = 511;
    if ((int)(i >= (unsigned int)zT_18)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = 511;
    zT_10 = i < (unsigned int)zT_11;
    goto z_bb_7;
    z_bb_6:
    zT_10 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_10) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_9:
    zT_21 = 0;
    zT_22 = (unsigned char)zT_21;
    c_path[i] = zT_22;
    zT_26 = 0;
    zT_27 = c_path + zT_26;
    zT_24 = zT_27;
    zT_25 = zG_970FEF1B_MODE_READ;
        zT_29.value = (void*)fopen(zT_24, zT_25);
    zT_29.has_value = zT_29.value != 0;
    zT_30 = zT_29.has_value;
    if (zT_30) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_11:
    zT_31 = zT_29.value;
    goto z_bb_12;
    z_bb_12:
    f = zT_31;
    zT_34 = f;
    zT_37 = 0;
    zT_39 = 2;
    zT_36 = zT_39;
    zT_40 = fseek(zT_34, (int)((int)zT_37), zT_36);
    (void)zT_40;
    zT_42 = f;
    zT_43 = ftell(zT_42);
    size = zT_43;
    zT_44 = 0;
    if ((int)(size <= zT_44)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = f;
    zT_47 = fclose(zT_46);
    (void)zT_47;
    zT_48.has_value = 0;
    return zT_48;
    z_bb_14:
    zT_49 = f;
    zT_52 = 0;
    zT_54 = 0;
    zT_51 = zT_54;
    zT_55 = fseek(zT_49, (int)((int)zT_52), zT_51);
    (void)zT_55;
    zT_57 = (unsigned int)size;
    sz = zT_57;
    zT_59 = alloc;
    zT_64 = zF_1395EB68_sandAlloc(zT_59, (unsigned int)((unsigned int)sz), (unsigned int)(1));
    zT_65 = zT_64.is_error;
    if (zT_65) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_67 = f;
    zT_68 = fclose(zT_67);
    (void)zT_68;
    zT_69.has_value = 0;
    return zT_69;
    z_bb_16:
    zT_66 = zT_64.data.payload;
    goto z_bb_17;
    z_bb_17:
    raw = zT_66;
    zT_72 = (unsigned char*)raw;
    buf = zT_72;
    zT_74 = buf;
    zT_78 = 1;
    zT_76 = sz;
    zT_77 = f;
    zT_80 = fread(zT_74, (unsigned int)((unsigned int)zT_78), zT_76, zT_77);
    read = zT_80;
    zT_81 = f;
    zT_82 = fclose(zT_81);
    (void)zT_82;
    if ((int)(read != sz)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_84.has_value = 0;
    return zT_84;
    z_bb_19:
    zT_85 = 0;
    zT_86 = buf + zT_85;
    zT_87 = sz - zT_85;
    zT_88.ptr = zT_86;
    zT_88.len = zT_87;
    zT_89.has_value = 1;
    zT_89.value = zT_88;
    return zT_89;
}

/* fileExists */
int zF_852C5C93_fileExists(zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    zT_846744CC_Arr_unsigned_char_5 zT_2;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    int zT_9;
    int zT_10;
    unsigned char* zT_12;
    unsigned char zT_13;
    int zT_14;
    unsigned int zT_16;
    int zT_17;
    int zT_20;
    unsigned char zT_21;
    unsigned char* zT_23;
    unsigned char* zT_24;
    int zT_25;
    unsigned char* zT_26;
    zT_05CE5599_Opt_400 zT_28 = {0};
    unsigned char zT_29;
    void* zT_30;
    void* zT_33;
    int zT_34 = 0;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    void* f;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = path.len;
    if ((int)(i < zT_7)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_12 = path.ptr;
    zT_13 = zT_12[i];
    c_path[i] = zT_13;
    zT_14 = 1;
    zT_16 = i + (unsigned int)((unsigned int)zT_14);
    i = zT_16;
    goto z_bb_4;
    z_bb_3:
    zT_17 = 511;
    if ((int)(i >= (unsigned int)zT_17)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_10 = 511;
    zT_9 = i < (unsigned int)zT_10;
    goto z_bb_7;
    z_bb_6:
    zT_9 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    return (int)(0);
    z_bb_9:
    zT_20 = 0;
    zT_21 = (unsigned char)zT_20;
    c_path[i] = zT_21;
    zT_25 = 0;
    zT_26 = c_path + zT_25;
    zT_23 = zT_26;
    zT_24 = zG_970FEF1B_MODE_READ;
        zT_28.value = (void*)fopen(zT_23, zT_24);
    zT_28.has_value = zT_28.value != 0;
    zT_29 = zT_28.has_value;
    if (zT_29) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    return (int)(0);
    z_bb_11:
    zT_30 = zT_28.value;
    goto z_bb_12;
    z_bb_12:
    f = zT_30;
    zT_33 = f;
    zT_34 = fclose(zT_33);
    (void)zT_34;
    return (int)(1);
}

/* dirExists */
int zF_8CC05F84_dirExists(zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    zT_846744CC_Arr_unsigned_char_5 zT_2;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    int zT_9;
    int zT_10;
    unsigned char* zT_12;
    unsigned char zT_13;
    int zT_14;
    unsigned int zT_16;
    int zT_17;
    int zT_20;
    unsigned char zT_21;
    unsigned char* zT_22;
    int zT_23;
    unsigned char* zT_24;
    int zT_25 = 0;
    int zT_26;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = path.len;
    if ((int)(i < zT_7)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_12 = path.ptr;
    zT_13 = zT_12[i];
    c_path[i] = zT_13;
    zT_14 = 1;
    zT_16 = i + (unsigned int)((unsigned int)zT_14);
    i = zT_16;
    goto z_bb_4;
    z_bb_3:
    zT_17 = 511;
    if ((int)(i >= (unsigned int)zT_17)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_10 = 511;
    zT_9 = i < (unsigned int)zT_10;
    goto z_bb_7;
    z_bb_6:
    zT_9 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    return (int)(0);
    z_bb_9:
    zT_20 = 0;
    zT_21 = (unsigned char)zT_20;
    c_path[i] = zT_21;
    zT_23 = 0;
    zT_24 = c_path + zT_23;
    zT_22 = zT_24;
    zT_25 = pal_dir_exists(zT_22);
    zT_26 = 0;
    return (int)(zT_25 != zT_26);
}

/* stdout_write */
void zF_D3019AEE_stdout_write(zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    unsigned char* zT_2;
    int zT_4;
    unsigned char* zT_7;
    unsigned int zT_9;
    int zT_11 = 0;
    zT_4 = 1;
    zT_7 = msg.ptr;
    zT_2 = zT_7;
    zT_9 = msg.len;
    zT_11 = write((int)((int)zT_4), zT_2, (int)((int)zT_9));
    (void)zT_11;
    return;
}

/* stderr_write */
void zF_E4B2EF19_stderr_write(zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    unsigned char* zT_2;
    int zT_4;
    unsigned char* zT_7;
    unsigned int zT_9;
    int zT_11 = 0;
    zT_4 = 2;
    zT_7 = msg.ptr;
    zT_2 = zT_7;
    zT_9 = msg.len;
    zT_11 = write((int)((int)zT_4), zT_2, (int)((int)zT_9));
    (void)zT_11;
    return;
}

/* fileOpen */
unsigned int zF_39FE21EF_fileOpen(zT_8F083A69_Slice_zT_0B42B2F8_u path, int flags) {
    zT_846744CC_Arr_unsigned_char_5 zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_10;
    int zT_11;
    unsigned char* zT_13;
    unsigned char zT_14;
    int zT_15;
    unsigned int zT_17;
    int zT_18;
    int zT_21;
    unsigned char zT_22;
    unsigned char* zT_23;
    int zT_24;
    int zT_25;
    unsigned char* zT_26;
    unsigned int zT_27 = 0;
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_8 = path.len;
    if ((int)(i < zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_13 = path.ptr;
    zT_14 = zT_13[i];
    c_path[i] = zT_14;
    zT_15 = 1;
    zT_17 = i + (unsigned int)((unsigned int)zT_15);
    i = zT_17;
    goto z_bb_4;
    z_bb_3:
    zT_18 = 511;
    if ((int)(i >= (unsigned int)zT_18)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = 511;
    zT_10 = i < (unsigned int)zT_11;
    goto z_bb_7;
    z_bb_6:
    zT_10 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_10) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    return zG_CC81CC5F_INVALID_FD;
    z_bb_9:
    zT_21 = 0;
    zT_22 = (unsigned char)zT_21;
    c_path[i] = zT_22;
    zT_25 = 0;
    zT_26 = c_path + zT_25;
    zT_23 = zT_26;
    zT_24 = flags;
    zT_27 = pal_file_open(zT_23, zT_24);
    return zT_27;
}

/* fileWrite */
void zF_3276D7B6_fileWrite(unsigned int fd, zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    unsigned int zT_2;
    unsigned char* zT_3;
    unsigned char* zT_6;
    unsigned int zT_8;
    int zT_10 = 0;
    zT_2 = fd;
    zT_6 = msg.ptr;
    zT_3 = zT_6;
    zT_8 = msg.len;
    zT_10 = pal_file_write(zT_2, zT_3, (unsigned int)((unsigned int)zT_8));
    (void)zT_10;
    return;
}

/* fileRead */
unsigned int zF_7579A8D7_fileRead(unsigned int fd, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_3;
    unsigned char* zT_4;
    unsigned char* zT_7;
    unsigned int zT_9;
    int zT_11 = 0;
    int zT_12;
    int got;
    zT_3 = fd;
    zT_7 = buf.ptr;
    zT_4 = zT_7;
    zT_9 = buf.len;
    zT_11 = pal_file_read(zT_3, zT_4, (unsigned int)((unsigned int)zT_9));
    got = zT_11;
    zT_12 = 0;
    if ((int)(got < zT_12)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return zG_CC81CC5F_INVALID_FD;
    z_bb_2:
    return (unsigned int)((unsigned int)got);
}

/* fileClose */
void zF_B30B1D79_fileClose(unsigned int fd) {
    unsigned int zT_1;
    int zT_2 = 0;
    zT_1 = fd;
    zT_2 = pal_file_close(zT_1);
    (void)zT_2;
    return;
}

/* streamOpen */
zT_05CE5599_Opt_400 zF_A1EF0C49_streamOpen(zT_8F083A69_Slice_zT_0B42B2F8_u path, unsigned char* mode) {
    zT_846744CC_Arr_unsigned_char_5 zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_8;
    int zT_10;
    int zT_11;
    unsigned char* zT_13;
    unsigned char zT_14;
    int zT_15;
    unsigned int zT_17;
    int zT_18;
    zT_05CE5599_Opt_400 zT_20 = {0};
    int zT_21;
    unsigned char zT_22;
    unsigned char* zT_24;
    unsigned char* zT_25;
    int zT_26;
    unsigned char* zT_27;
    zT_05CE5599_Opt_400 zT_28 = {0};
    zT_846744CC_Arr_unsigned_char_5 c_path;
    unsigned int i;
    zT_05CE5599_Opt_400 f;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        c_path[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_8 = path.len;
    if ((int)(i < zT_8)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_13 = path.ptr;
    zT_14 = zT_13[i];
    c_path[i] = zT_14;
    zT_15 = 1;
    zT_17 = i + (unsigned int)((unsigned int)zT_15);
    i = zT_17;
    goto z_bb_4;
    z_bb_3:
    zT_18 = 511;
    if ((int)(i >= (unsigned int)zT_18)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = 511;
    zT_10 = i < (unsigned int)zT_11;
    goto z_bb_7;
    z_bb_6:
    zT_10 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_10) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_9:
    zT_21 = 0;
    zT_22 = (unsigned char)zT_21;
    c_path[i] = zT_22;
    zT_26 = 0;
    zT_27 = c_path + zT_26;
    zT_24 = zT_27;
    zT_25 = mode;
        zT_28.value = (void*)fopen(zT_24, zT_25);
    zT_28.has_value = zT_28.value != 0;
    f = zT_28;
    return f;
}

/* streamClose */
void zF_D4EBC9A3_streamClose(void* file) {
    void* zT_1;
    int zT_2 = 0;
    zT_1 = file;
    zT_2 = fclose(zT_1);
    (void)zT_2;
    return;
}

/* streamWrite */
void zF_6B472DDC_streamWrite(void* file, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_3;
    unsigned char* zT_7;
    void* zT_10;
    unsigned char* zT_12;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    unsigned int zT_19;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_33;
    unsigned int wrote;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = buf.len;
    if ((int)(zT_3 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = buf.ptr;
    zT_7 = zT_12;
    zT_15 = buf.len;
    zT_10 = file;
    zT_17 = fwrite(zT_7, (unsigned int)(1), (unsigned int)((unsigned int)zT_15), zT_10);
    wrote = zT_17;
    zT_19 = buf.len;
    if ((int)(wrote != (unsigned int)((unsigned int)zT_19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_23 = "short write on spill stream (streamWrite)";
    zT_25 = 41;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    emsg = zT_24;
    zT_27 = "pal.zig";
    zT_29 = 7;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    ef = zT_28;
    zT_30 = emsg;
    zT_31 = ef;
    zT_33 = 120;
    zF_6D97D338_panicHandler(zT_30, zT_31, (unsigned int)((unsigned int)zT_33));
    goto z_bb_4;
    z_bb_4:
    return;
}

/* streamRead */
void zF_9D6FEB45_streamRead(void* file, zT_8F083A69_Slice_zT_0B42B2F8_u buf) {
    unsigned int zT_3;
    unsigned char* zT_7;
    void* zT_10;
    unsigned char* zT_12;
    unsigned int zT_15;
    unsigned int zT_17 = 0;
    unsigned int zT_19;
    unsigned char* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_33;
    unsigned int got;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = buf.len;
    if ((int)(zT_3 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_12 = buf.ptr;
    zT_7 = zT_12;
    zT_15 = buf.len;
    zT_10 = file;
    zT_17 = fread(zT_7, (unsigned int)(1), (unsigned int)((unsigned int)zT_15), zT_10);
    got = zT_17;
    zT_19 = buf.len;
    if ((int)(got != (unsigned int)((unsigned int)zT_19))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_23 = "short read on spill stream (streamRead)";
    zT_25 = 39;
    zT_24.ptr = zT_23;
    zT_24.len = zT_25;
    emsg = zT_24;
    zT_27 = "pal.zig";
    zT_29 = 7;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    ef = zT_28;
    zT_30 = emsg;
    zT_31 = ef;
    zT_33 = 130;
    zF_6D97D338_panicHandler(zT_30, zT_31, (unsigned int)((unsigned int)zT_33));
    goto z_bb_4;
    z_bb_4:
    return;
}

/* streamSeek */
void zF_25D60F31_streamSeek(void* file, int offset) {
    void* zT_3;
    int zT_4;
    int zT_5;
    unsigned int zT_6;
    int zT_7 = 0;
    int zT_8;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    unsigned char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    int zT_21;
    int rc;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = file;
    zT_4 = offset;
    zT_6 = 0;
    zT_5 = zT_6;
    zT_7 = fseek(zT_3, zT_4, zT_5);
    rc = zT_7;
    zT_8 = 0;
    if ((int)(rc != zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = "fseek failed on spill stream (streamSeek)";
    zT_13 = 41;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    emsg = zT_12;
    zT_15 = "pal.zig";
    zT_17 = 7;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    ef = zT_16;
    zT_18 = emsg;
    zT_19 = ef;
    zT_21 = 139;
    zF_6D97D338_panicHandler(zT_18, zT_19, (unsigned int)((unsigned int)zT_21));
    goto z_bb_2;
    z_bb_2:
    return;
}

/* getDefaultLibPath */
int zF_BEB0BFA8_getDefaultLibPath(unsigned char* buf, int bufsize) {
    unsigned char* zT_2;
    int zT_3;
    int zT_4 = 0;
    zT_2 = buf;
    zT_3 = bufsize;
    zT_4 = pal_get_default_lib_path(zT_2, zT_3);
    return zT_4;
}

/* exit */
void zF_CDED1A85_exit(unsigned char code) {
    c_exit((int)((int)code));
    goto z_bb_1;
    z_bb_1:
    if ((int)(1)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
}

/* initArgs */
void zF_4DE8E0A6_initArgs(int argc, unsigned char** argv) {
    zG_F46B0200_saved_argc = argc;
    zG_096B230F_saved_argv = argv;
    return;
}

/* argCount */
int zF_EEF840BE_argCount(void) {
    return zG_F46B0200_saved_argc;
}

/* argGet */
unsigned char* zF_70B5BFF1_argGet(int i) {
    unsigned int zT_2;
    unsigned char* zT_3;
    zT_2 = (unsigned int)i;
    zT_3 = zG_096B230F_saved_argv[zT_2];
    return zT_3;
}

/* markersEnabled */
void zF_3C88665D_markersEnabled(unsigned int on) {
    zG_EE253928_g_markers_enabled = on;
    return;
}

/* isMarkersEnabled */
int zF_F632D1ED_isMarkersEnabled(void) {
    int zT_1;
    zT_1 = 0;
    return (int)(zG_EE253928_g_markers_enabled != (unsigned int)zT_1);
}

/* markerWrite */
void zF_48AC7B3A_markerWrite(zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    if ((int)(0)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((int)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    zT_7 = msg;
    zF_E4B2EF19_stderr_write(zT_7);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
}

/* markerWriteInt */
void zF_C914CB83_markerWriteInt(zT_8F083A69_Slice_zT_0B42B2F8_u prefix, unsigned int value) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_5826BFC7_Arr_unsigned_char_1 zT_11;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21 = 0;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned char* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_p;
    zT_5826BFC7_Arr_unsigned_char_1 buf;
    unsigned int vlen;
    unsigned int start;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((int)(0)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((int)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    s_p = prefix;
    zT_9 = s_p;
    zF_48AC7B3A_markerWrite(zT_9);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_11[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        buf[_i] = zT_11[_i];
        _i++;
    }
}
    zT_13 = value;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_14 = zT_20;
    zT_21 = zF_A7504564_itoa(zT_13, zT_14);
    vlen = zT_21;
    zT_27 = (unsigned int)((unsigned int)(12) - (unsigned int)((unsigned int)vlen)) - (unsigned int)(1);
    start = zT_27;
    zT_32 = (unsigned char*)((unsigned char*)buf) + start;
    zT_33 = (unsigned int)(11) - start;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_28 = zT_34;
    zF_48AC7B3A_markerWrite(zT_28);
    zT_36 = "\n";
    zT_38 = 1;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    s_nl = zT_37;
    zT_39 = s_nl;
    zF_48AC7B3A_markerWrite(zT_39);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
}

/* markerWriteInt64 */
void zF_C405AFC1_markerWriteInt64(zT_8F083A69_Slice_zT_0B42B2F8_u prefix, zT_79FAE712_u64 value) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_4428DEE2_Arr_unsigned_char_2 zT_11;
    zT_79FAE712_u64 zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21 = 0;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned char* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned char* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_p;
    zT_4428DEE2_Arr_unsigned_char_2 buf;
    unsigned int vlen;
    unsigned int start;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((int)(0)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((int)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    s_p = prefix;
    zT_9 = s_p;
    zF_48AC7B3A_markerWrite(zT_9);
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_11[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        buf[_i] = zT_11[_i];
        _i++;
    }
}
    zT_13 = value;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)buf) + zT_17;
    zT_19 = (unsigned int)(24) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_14 = zT_20;
    zT_21 = zF_A3999586_itoa64(zT_13, zT_14);
    vlen = zT_21;
    zT_27 = (unsigned int)((unsigned int)(24) - (unsigned int)((unsigned int)vlen)) - (unsigned int)(1);
    start = zT_27;
    zT_32 = (unsigned char*)((unsigned char*)buf) + start;
    zT_33 = (unsigned int)(23) - start;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_28 = zT_34;
    zF_48AC7B3A_markerWrite(zT_28);
    zT_36 = "\n";
    zT_38 = 1;
    zT_37.ptr = zT_36;
    zT_37.len = zT_38;
    s_nl = zT_37;
    zT_39 = s_nl;
    zF_48AC7B3A_markerWrite(zT_39);
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
}

/* measureMarkerWrite */
void zF_B5478454_measureMarkerWrite(zT_8F083A69_Slice_zT_0B42B2F8_u msg) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    if ((int)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* measureMarkerWriteInt */
void zF_95B5C5CD_measureMarkerWriteI(zT_8F083A69_Slice_zT_0B42B2F8_u prefix, unsigned int value) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_5826BFC7_Arr_unsigned_char_1 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18 = 0;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned char* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_p;
    zT_5826BFC7_Arr_unsigned_char_1 buf;
    unsigned int vlen;
    unsigned int start;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((int)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s_p = prefix;
    zT_6 = s_p;
    zF_B5478454_measureMarkerWrite(zT_6);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        buf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_10 = value;
    zT_14 = 0;
    zT_15 = (unsigned char*)((unsigned char*)buf) + zT_14;
    zT_16 = (unsigned int)(12) - zT_14;
    zT_17.ptr = zT_15;
    zT_17.len = zT_16;
    zT_11 = zT_17;
    zT_18 = zF_A7504564_itoa(zT_10, zT_11);
    vlen = zT_18;
    zT_24 = (unsigned int)((unsigned int)(12) - (unsigned int)((unsigned int)vlen)) - (unsigned int)(1);
    start = zT_24;
    zT_29 = (unsigned char*)((unsigned char*)buf) + start;
    zT_30 = (unsigned int)(11) - start;
    zT_31.ptr = zT_29;
    zT_31.len = zT_30;
    zT_25 = zT_31;
    zF_B5478454_measureMarkerWrite(zT_25);
    zT_33 = "\n";
    zT_35 = 1;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    s_nl = zT_34;
    zT_36 = s_nl;
    zF_B5478454_measureMarkerWrite(zT_36);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* measureMarkerWriteInt64 */
void zF_C9DDBF0F_measureMarkerWriteI(zT_8F083A69_Slice_zT_0B42B2F8_u prefix, zT_79FAE712_u64 value) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_4428DEE2_Arr_unsigned_char_2 zT_8;
    zT_79FAE712_u64 zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18 = 0;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned char* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_p;
    zT_4428DEE2_Arr_unsigned_char_2 buf;
    unsigned int vlen;
    unsigned int start;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((int)(zG_EE253928_g_markers_enabled != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s_p = prefix;
    zT_6 = s_p;
    zF_B5478454_measureMarkerWrite(zT_6);
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        buf[_i] = zT_8[_i];
        _i++;
    }
}
    zT_10 = value;
    zT_14 = 0;
    zT_15 = (unsigned char*)((unsigned char*)buf) + zT_14;
    zT_16 = (unsigned int)(24) - zT_14;
    zT_17.ptr = zT_15;
    zT_17.len = zT_16;
    zT_11 = zT_17;
    zT_18 = zF_A3999586_itoa64(zT_10, zT_11);
    vlen = zT_18;
    zT_24 = (unsigned int)((unsigned int)(24) - (unsigned int)((unsigned int)vlen)) - (unsigned int)(1);
    start = zT_24;
    zT_29 = (unsigned char*)((unsigned char*)buf) + start;
    zT_30 = (unsigned int)(23) - start;
    zT_31.ptr = zT_29;
    zT_31.len = zT_30;
    zT_25 = zT_31;
    zF_B5478454_measureMarkerWrite(zT_25);
    zT_33 = "\n";
    zT_35 = 1;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    s_nl = zT_34;
    zT_36 = s_nl;
    zF_B5478454_measureMarkerWrite(zT_36);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* __module_init */
void zF_780653D2___module_init_6(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    unsigned char* zT_1;
    int zT_3;
    int zT_5;
    zG_3E40CD83_Sand = zT_0;
    zT_1 = "rb";
    zG_970FEF1B_MODE_READ = zT_1;
    zG_CC81CC5F_INVALID_FD = (unsigned int)(4294967295u);
    zT_3 = 0;
    zG_F46B0200_saved_argc = (int)((int)zT_3);
    zT_5 = 0;
    zG_EE253928_g_markers_enabled = (unsigned int)((unsigned int)zT_5);
    return;
}

/* EOF */
