#include "lir_stream_0760A6EE.h"
unsigned char* zG_4417A8F5_READ_MODE;
unsigned char* zG_82B6E276_WRITE_MODE;
/* lirStreamInit */
zT_7E7544E4_LirStream zF_E9CBFCA6_lirStreamInit(void) {
    zT_7E7544E4_LirStream zT_0;
    zT_D21A8776_SpillStore zT_1 = {0};
    unsigned int zT_2;
    unsigned int zT_3;
    zT_1 = zF_22C79E6C_spillStoreInit();
    zT_0.spill = zT_1;
    zT_2 = 0;
    zT_0.path_len = zT_2;
    zT_3 = 0;
    zT_0.write_offset = zT_3;
    return zT_0;
}

/* lirStreamBeginWrite */
void zF_B0B74E20_lirStreamBeginWrite(zT_7E7544E4_LirStream* s, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_8;
    int zT_10;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    zT_D21A8776_SpillStore* zT_19;
    zT_0426DCE7_SpillBackend zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_3E40CD83_Sand* zT_22;
    unsigned char* zT_23;
    zT_D21A8776_SpillStore* zT_24;
    zT_F12DA458_SpillId zT_25;
    zT_F12DA458_SpillId zT_28;
    zT_0426DCE7_SpillBackend zT_29 = 0;
    unsigned char* zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int i;
    zT_4 = 0;
    i = zT_4;
    i = zT_4;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = path.len;
    if ((int)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_11 = path.ptr;
    zT_12 = zT_11[i];
    zT_13 = s->path;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    s->path_len = i;
    zT_16 = 0;
    zT_17 = s->path;
    zT_17[i] = zT_16;
    s->write_offset = (unsigned int)(0);
    zT_24 = &s->spill;
    zT_19 = zT_24;
    zT_28 = zT_F12DA458_SpillId_s_lir;
    zT_25 = zT_28;
    zT_29 = zF_1AA39172_spillBackendFor(zT_25);
    zT_20 = zT_29;
    zT_30 = s->path;
    zT_31 = s->path_len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_21 = zT_35;
    zT_22 = alloc;
    zT_23 = zG_82B6E276_WRITE_MODE;
    zF_8AF94F71_spillOpen(zT_19, zT_20, zT_21, zT_22, zT_23);
    return;
    z_bb_4:
    zT_15 = i + (unsigned int)(1);
    i = zT_15;
    i = zT_15;
    goto z_bb_1;
    z_bb_5:
    zT_10 = i < (unsigned int)(511);
    zT_8 = zT_10;
    goto z_bb_7;
    z_bb_6:
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* lirStreamFinishWrite */
void zF_256E5B86_lirStreamFinishWrit(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_D21A8776_SpillStore* zT_2;
    zT_2 = &s->spill;
    zT_1 = zT_2;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* lirStreamBeginRead */
void zF_72DA7B39_lirStreamBeginRead(zT_7E7544E4_LirStream* s, zT_3E40CD83_Sand* alloc) {
    zT_D21A8776_SpillStore zT_2;
    zT_0426DCE7_SpillBackend zT_3;
    zT_D21A8776_SpillStore* zT_9;
    zT_D21A8776_SpillStore* zT_10;
    zT_0426DCE7_SpillBackend zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_3E40CD83_Sand* zT_13;
    unsigned char* zT_14;
    zT_D21A8776_SpillStore* zT_15;
    zT_0426DCE7_SpillBackend zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_2 = s->spill;
    zT_3 = zT_2.backend;
    if ((int)(zT_3 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = &s->spill;
    zT_9->cur = (unsigned int)(0);
    return;
    z_bb_2:
    zT_15 = &s->spill;
    zT_10 = zT_15;
    zT_18 = zT_0426DCE7_SpillBackend_disk;
    zT_11 = zT_18;
    zT_19 = s->path;
    zT_20 = s->path_len;
    zT_21 = 0;
    zT_22 = zT_19 + zT_21;
    zT_23 = zT_20 - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_12 = zT_24;
    zT_13 = alloc;
    zT_14 = zG_4417A8F5_READ_MODE;
    zF_8AF94F71_spillOpen(zT_10, zT_11, zT_12, zT_13, zT_14);
    return;
}

/* lirStreamEndRead */
void zF_9427AE59_lirStreamEndRead(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_D21A8776_SpillStore* zT_2;
    zT_2 = &s->spill;
    zT_1 = zT_2;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* wU32 */
void zF_FB050204_wU32(zT_7E7544E4_LirStream* s, unsigned int v) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned int zT_11;
    unsigned char zT_12;
    int zT_13;
    unsigned int zT_17;
    unsigned char zT_18;
    int zT_19;
    unsigned int zT_23;
    unsigned char zT_24;
    int zT_25;
    zT_D21A8776_SpillStore* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_D21A8776_SpillStore* zT_29;
    unsigned int zT_30;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = v & (unsigned int)(255);
    zT_6 = __bootstrap_u8_from_u32(zT_5);
    zT_7 = 0;
    b[zT_7] = zT_6;
    zT_11 = (unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255);
    zT_12 = __bootstrap_u8_from_u32(zT_11);
    zT_13 = 1;
    b[zT_13] = zT_12;
    zT_17 = (unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255);
    zT_18 = __bootstrap_u8_from_u32(zT_17);
    zT_19 = 2;
    b[zT_19] = zT_18;
    zT_23 = (unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255);
    zT_24 = __bootstrap_u8_from_u32(zT_23);
    zT_25 = 3;
    b[zT_25] = zT_24;
    zT_29 = &s->spill;
    zT_26 = zT_29;
    zT_30 = s->write_offset;
    zT_27 = zT_30;
    zT_33 = 0;
    zT_34 = (unsigned char*)((unsigned char*)b) + zT_33;
    zT_35 = (unsigned int)(4) - zT_33;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_28 = zT_36;
    zF_BFB33631_spillWriteAt(zT_26, zT_27, zT_28);
    zT_37 = s->write_offset;
    s->write_offset = (unsigned int)(zT_37 + (unsigned int)(4));
    return;
}

/* wU8 */
void zF_56013A33_wU8(zT_7E7544E4_LirStream* s, unsigned char v) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_3;
    int zT_4;
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_D21A8776_SpillStore* zT_8;
    unsigned int zT_9;
    int zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 0;
    b[zT_4] = v;
    zT_8 = &s->spill;
    zT_5 = zT_8;
    zT_9 = s->write_offset;
    zT_6 = zT_9;
    zT_12 = 0;
    zT_13 = (unsigned char*)((unsigned char*)b) + zT_12;
    zT_14 = (unsigned int)(1) - zT_12;
    zT_15.ptr = zT_13;
    zT_15.len = zT_14;
    zT_7 = zT_15;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_16 = s->write_offset;
    s->write_offset = (unsigned int)(zT_16 + (unsigned int)(1));
    return;
}

/* wBytes */
void zF_C2661A7D_wBytes(zT_7E7544E4_LirStream* s, unsigned char* ptr, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_D21A8776_SpillStore* zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    if ((int)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = &s->spill;
    zT_5 = zT_8;
    zT_9 = s->write_offset;
    zT_6 = zT_9;
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    zT_7 = zT_13;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_14 = s->write_offset;
    s->write_offset = (unsigned int)(zT_14 + (unsigned int)((unsigned int)len));
    return;
}

/* rU32 */
unsigned int zF_3E695161_rU32(zT_7E7544E4_LirStream* s) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore* zT_6;
    zT_D21A8776_SpillStore zT_7;
    unsigned int zT_8;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16;
    int zT_17;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned char zT_22;
    unsigned int zT_26;
    int zT_27;
    unsigned char zT_28;
    unsigned int zT_32;
    int zT_33;
    unsigned char zT_34;
    unsigned int zT_38;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    unsigned int v;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_6 = &s->spill;
    zT_3 = zT_6;
    zT_7 = s->spill;
    zT_8 = zT_7.cur;
    zT_4 = zT_8;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(4) - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_16 = 0;
    v = zT_16;
    v = zT_16;
    v = zT_16;
    zT_17 = 0;
    zT_18 = b[zT_17];
    zT_20 = v | (unsigned int)((unsigned int)zT_18);
    v = zT_20;
    v = zT_20;
    zT_21 = 1;
    zT_22 = b[zT_21];
    zT_26 = v | (unsigned int)((unsigned int)((unsigned int)zT_22) << (unsigned int)(8));
    v = zT_26;
    v = zT_26;
    zT_27 = 2;
    zT_28 = b[zT_27];
    zT_32 = v | (unsigned int)((unsigned int)((unsigned int)zT_28) << (unsigned int)(16));
    v = zT_32;
    v = zT_32;
    zT_33 = 3;
    zT_34 = b[zT_33];
    zT_38 = v | (unsigned int)((unsigned int)((unsigned int)zT_34) << (unsigned int)(24));
    v = zT_38;
    v = zT_38;
    return v;
}

/* rU8 */
unsigned char zF_747E1168_rU8(zT_7E7544E4_LirStream* s) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore* zT_6;
    zT_D21A8776_SpillStore zT_7;
    unsigned int zT_8;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_15;
    unsigned char zT_16;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_6 = &s->spill;
    zT_3 = zT_6;
    zT_7 = s->spill;
    zT_8 = zT_7.cur;
    zT_4 = zT_8;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(1) - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_15 = 0;
    zT_16 = b[zT_15];
    return zT_16;
}

/* rBytes */
void zF_CF6758F4_rBytes(zT_7E7544E4_LirStream* s, unsigned char* dst, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_D21A8776_SpillStore* zT_8;
    zT_D21A8776_SpillStore zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    if ((int)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = &s->spill;
    zT_5 = zT_8;
    zT_9 = s->spill;
    zT_10 = zT_9.cur;
    zT_6 = zT_10;
    zT_11 = 0;
    zT_12 = dst + zT_11;
    zT_13 = len - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_7 = zT_14;
    zF_E9F67450_spillReadAt(zT_5, zT_6, zT_7);
    return;
}

/* lirStreamAppend */
zT_E7714190_LirSlot zF_9F47D5E4_lirStreamAppend(zT_7E7544E4_LirStream* s, zT_BBC23664_LirFunction src_fn) {
    unsigned int zT_3;
    zT_7E7544E4_LirStream* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_7E7544E4_LirStream* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_7E7544E4_LirStream* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_7E7544E4_LirStream* zT_13;
    unsigned char zT_14;
    unsigned char zT_15;
    zT_7E7544E4_LirStream* zT_16;
    unsigned char zT_17;
    unsigned char zT_18;
    zT_7E7544E4_LirStream* zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    zT_7E7544E4_LirStream* zT_22;
    unsigned char zT_23;
    unsigned char zT_24;
    zT_7E7544E4_LirStream* zT_25;
    unsigned int zT_26;
    zT_CFE23D0A_LirParamArrayList zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_7E7544E4_LirStream* zT_30;
    unsigned int zT_31;
    zT_1CF28CA3_BasicBlockArrayList zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_7E7544E4_LirStream* zT_35;
    unsigned int zT_36;
    zT_5D72FBF8_TempDeclArrayList zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_7E7544E4_LirStream* zT_40;
    unsigned int zT_41;
    zT_9F514E82_SwitchCaseArrayList zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_7E7544E4_LirStream* zT_45;
    unsigned int zT_46;
    zT_AC00B5F6_LirSideEntryArrayLi zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_7E7544E4_LirStream* zT_50;
    unsigned int zT_51;
    zT_21D3708C_U32ToU32Map zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_7E7544E4_LirStream* zT_55;
    unsigned int zT_56;
    zT_21D3708C_U32ToU32Map zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    zT_CFE23D0A_LirParamArrayList zT_60;
    unsigned int zT_61;
    zT_7E7544E4_LirStream* zT_64;
    unsigned char* zT_65;
    unsigned int zT_66;
    zT_CFE23D0A_LirParamArrayList zT_67;
    zT_8779209D_LirParam* zT_68;
    unsigned char* zT_69;
    zT_CFE23D0A_LirParamArrayList zT_70;
    unsigned int zT_71;
    unsigned int zT_73;
    unsigned int zT_75;
    zT_1CF28CA3_BasicBlockArrayList zT_76;
    unsigned int zT_77;
    zT_1CF28CA3_BasicBlockArrayList zT_80;
    zT_88A68B1A_BasicBlock* zT_81;
    zT_88A68B1A_BasicBlock* zT_82;
    zT_7E7544E4_LirStream* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_7E7544E4_LirStream* zT_86;
    unsigned char zT_87;
    unsigned char zT_88;
    zT_7E7544E4_LirStream* zT_89;
    unsigned char zT_90;
    unsigned char zT_91;
    zT_7E7544E4_LirStream* zT_92;
    unsigned char zT_93;
    unsigned char zT_94;
    zT_7E7544E4_LirStream* zT_95;
    unsigned char zT_96;
    unsigned char zT_97;
    zT_7E7544E4_LirStream* zT_98;
    unsigned int zT_99;
    zT_DAE4631D_LirInstArrayList zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_DAE4631D_LirInstArrayList zT_103;
    unsigned int zT_104;
    zT_7E7544E4_LirStream* zT_107;
    unsigned char* zT_108;
    unsigned int zT_109;
    zT_DAE4631D_LirInstArrayList zT_110;
    zT_6BA597BC_LirInst* zT_111;
    unsigned char* zT_112;
    zT_DAE4631D_LirInstArrayList zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned int zT_118;
    zT_5D72FBF8_TempDeclArrayList zT_119;
    unsigned int zT_120;
    zT_7E7544E4_LirStream* zT_123;
    unsigned char* zT_124;
    unsigned int zT_125;
    zT_5D72FBF8_TempDeclArrayList zT_126;
    zT_1937645B_TempDecl* zT_127;
    unsigned char* zT_128;
    zT_5D72FBF8_TempDeclArrayList zT_129;
    unsigned int zT_130;
    unsigned int zT_132;
    zT_9F514E82_SwitchCaseArrayList zT_133;
    unsigned int zT_134;
    zT_7E7544E4_LirStream* zT_137;
    unsigned char* zT_138;
    unsigned int zT_139;
    zT_9F514E82_SwitchCaseArrayList zT_140;
    zT_4BD97095_SwitchCase* zT_141;
    unsigned char* zT_142;
    zT_9F514E82_SwitchCaseArrayList zT_143;
    unsigned int zT_144;
    unsigned int zT_146;
    zT_AC00B5F6_LirSideEntryArrayLi zT_147;
    unsigned int zT_148;
    zT_7E7544E4_LirStream* zT_151;
    unsigned char* zT_152;
    unsigned int zT_153;
    zT_AC00B5F6_LirSideEntryArrayLi zT_154;
    zT_A8A5B231_LirSideEntry* zT_155;
    unsigned char* zT_156;
    zT_AC00B5F6_LirSideEntryArrayLi zT_157;
    unsigned int zT_158;
    unsigned int zT_160;
    zT_21D3708C_U32ToU32Map zT_161;
    unsigned int zT_162;
    zT_21D3708C_U32ToU32Map zT_166;
    unsigned int zT_167;
    zT_7E7544E4_LirStream* zT_168;
    unsigned char* zT_169;
    unsigned int zT_170;
    zT_21D3708C_U32ToU32Map zT_171;
    unsigned int* zT_172;
    unsigned char* zT_173;
    unsigned int zT_175;
    zT_7E7544E4_LirStream* zT_176;
    unsigned char* zT_177;
    unsigned int zT_178;
    zT_21D3708C_U32ToU32Map zT_179;
    unsigned int* zT_180;
    unsigned char* zT_181;
    unsigned int zT_183;
    zT_7E7544E4_LirStream* zT_184;
    unsigned char* zT_185;
    unsigned int zT_186;
    zT_21D3708C_U32ToU32Map zT_187;
    unsigned char* zT_188;
    unsigned char* zT_189;
    unsigned int zT_191;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_E7714190_LirSlot zT_195;
    unsigned int zT_196;
    unsigned int start;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int cap;
    unsigned int byte_len;
    zT_3 = s->write_offset;
    start = zT_3;
    start = zT_3;
    start = zT_3;
    zT_4 = s;
    zT_6 = src_fn.name_id;
    zT_5 = zT_6;
    zF_FB050204_wU32(zT_4, zT_5);
    zT_7 = s;
    zT_9 = src_fn.module_id;
    zT_8 = zT_9;
    zF_FB050204_wU32(zT_7, zT_8);
    zT_10 = s;
    zT_12 = src_fn.return_type;
    zT_11 = zT_12;
    zF_FB050204_wU32(zT_10, zT_11);
    zT_13 = s;
    zT_15 = src_fn.is_extern;
    zT_14 = zT_15;
    zF_56013A33_wU8(zT_13, zT_14);
    zT_16 = s;
    zT_18 = src_fn.is_pub;
    zT_17 = zT_18;
    zF_56013A33_wU8(zT_16, zT_17);
    zT_19 = s;
    zT_21 = src_fn.is_variadic;
    zT_20 = zT_21;
    zF_56013A33_wU8(zT_19, zT_20);
    zT_22 = s;
    zT_24 = 0;
    zT_23 = zT_24;
    zF_56013A33_wU8(zT_22, zT_23);
    zT_25 = s;
    zT_27 = src_fn.params;
    zT_28 = zT_27.len;
    zT_29 = (unsigned int)zT_28;
    zT_26 = zT_29;
    zF_FB050204_wU32(zT_25, zT_26);
    zT_30 = s;
    zT_32 = src_fn.blocks;
    zT_33 = zT_32.len;
    zT_34 = (unsigned int)zT_33;
    zT_31 = zT_34;
    zF_FB050204_wU32(zT_30, zT_31);
    zT_35 = s;
    zT_37 = src_fn.hoisted_temps;
    zT_38 = zT_37.len;
    zT_39 = (unsigned int)zT_38;
    zT_36 = zT_39;
    zF_FB050204_wU32(zT_35, zT_36);
    zT_40 = s;
    zT_42 = src_fn.switch_cases;
    zT_43 = zT_42.len;
    zT_44 = (unsigned int)zT_43;
    zT_41 = zT_44;
    zF_FB050204_wU32(zT_40, zT_41);
    zT_45 = s;
    zT_47 = src_fn.side_table;
    zT_48 = zT_47.len;
    zT_49 = (unsigned int)zT_48;
    zT_46 = zT_49;
    zF_FB050204_wU32(zT_45, zT_46);
    zT_50 = s;
    zT_52 = src_fn.temp_variant_sub_field;
    zT_53 = zT_52.capacity;
    zT_54 = (unsigned int)zT_53;
    zT_51 = zT_54;
    zF_FB050204_wU32(zT_50, zT_51);
    zT_55 = s;
    zT_57 = src_fn.temp_variant_sub_field;
    zT_58 = zT_57.count;
    zT_59 = (unsigned int)zT_58;
    zT_56 = zT_59;
    zF_FB050204_wU32(zT_55, zT_56);
    zT_60 = src_fn.params;
    zT_61 = zT_60.len;
    if ((int)(zT_61 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_64 = s;
    zT_67 = src_fn.params;
    zT_68 = zT_67.items;
    zT_69 = (unsigned char*)zT_68;
    zT_65 = zT_69;
    zT_70 = src_fn.params;
    zT_71 = zT_70.len;
    zT_73 = zT_71 * (unsigned int)(12);
    zT_66 = zT_73;
    zF_C2661A7D_wBytes(zT_64, zT_65, zT_66);
    goto z_bb_2;
    z_bb_2:
    zT_75 = 0;
    bi = zT_75;
    bi = zT_75;
    bi = zT_75;
    goto z_bb_3;
    z_bb_3:
    zT_76 = src_fn.blocks;
    zT_77 = zT_76.len;
    if ((int)(bi < zT_77)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_80 = src_fn.blocks;
    zT_81 = zT_80.items;
    zT_82 = zT_81 + bi;
    bb = zT_82;
    bb = zT_82;
    bb = zT_82;
    zT_83 = s;
    zT_85 = bb->id;
    zT_84 = zT_85;
    zF_FB050204_wU32(zT_83, zT_84);
    zT_86 = s;
    zT_88 = bb->is_terminated;
    zT_87 = zT_88;
    zF_56013A33_wU8(zT_86, zT_87);
    zT_89 = s;
    zT_91 = 0;
    zT_90 = zT_91;
    zF_56013A33_wU8(zT_89, zT_90);
    zT_92 = s;
    zT_94 = 0;
    zT_93 = zT_94;
    zF_56013A33_wU8(zT_92, zT_93);
    zT_95 = s;
    zT_97 = 0;
    zT_96 = zT_97;
    zF_56013A33_wU8(zT_95, zT_96);
    zT_98 = s;
    zT_100 = bb->insts;
    zT_101 = zT_100.len;
    zT_102 = (unsigned int)zT_101;
    zT_99 = zT_102;
    zF_FB050204_wU32(zT_98, zT_99);
    zT_103 = bb->insts;
    zT_104 = zT_103.len;
    if ((int)(zT_104 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_119 = src_fn.hoisted_temps;
    zT_120 = zT_119.len;
    if ((int)(zT_120 > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_118 = bi + (unsigned int)(1);
    bi = zT_118;
    bi = zT_118;
    goto z_bb_3;
    z_bb_7:
    zT_107 = s;
    zT_110 = bb->insts;
    zT_111 = zT_110.items;
    zT_112 = (unsigned char*)zT_111;
    zT_108 = zT_112;
    zT_113 = bb->insts;
    zT_114 = zT_113.len;
    zT_116 = zT_114 * (unsigned int)(32);
    zT_109 = zT_116;
    zF_C2661A7D_wBytes(zT_107, zT_108, zT_109);
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_123 = s;
    zT_126 = src_fn.hoisted_temps;
    zT_127 = zT_126.items;
    zT_128 = (unsigned char*)zT_127;
    zT_124 = zT_128;
    zT_129 = src_fn.hoisted_temps;
    zT_130 = zT_129.len;
    zT_132 = zT_130 * (unsigned int)(8);
    zT_125 = zT_132;
    zF_C2661A7D_wBytes(zT_123, zT_124, zT_125);
    goto z_bb_10;
    z_bb_10:
    zT_133 = src_fn.switch_cases;
    zT_134 = zT_133.len;
    if ((int)(zT_134 > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_137 = s;
    zT_140 = src_fn.switch_cases;
    zT_141 = zT_140.items;
    zT_142 = (unsigned char*)zT_141;
    zT_138 = zT_142;
    zT_143 = src_fn.switch_cases;
    zT_144 = zT_143.len;
    zT_146 = zT_144 * (unsigned int)(16);
    zT_139 = zT_146;
    zF_C2661A7D_wBytes(zT_137, zT_138, zT_139);
    goto z_bb_12;
    z_bb_12:
    zT_147 = src_fn.side_table;
    zT_148 = zT_147.len;
    if ((int)(zT_148 > (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_151 = s;
    zT_154 = src_fn.side_table;
    zT_155 = zT_154.items;
    zT_156 = (unsigned char*)zT_155;
    zT_152 = zT_156;
    zT_157 = src_fn.side_table;
    zT_158 = zT_157.len;
    zT_160 = zT_158 * (unsigned int)(28);
    zT_153 = zT_160;
    zF_C2661A7D_wBytes(zT_151, zT_152, zT_153);
    goto z_bb_14;
    z_bb_14:
    zT_161 = src_fn.temp_variant_sub_field;
    zT_162 = zT_161.capacity;
    if ((int)(zT_162 > (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_166 = src_fn.temp_variant_sub_field;
    zT_167 = zT_166.capacity;
    cap = zT_167;
    cap = zT_167;
    cap = zT_167;
    zT_168 = s;
    zT_171 = src_fn.temp_variant_sub_field;
    zT_172 = zT_171.keys;
    zT_173 = (unsigned char*)zT_172;
    zT_169 = zT_173;
    zT_175 = cap * (unsigned int)(4);
    zT_170 = zT_175;
    zF_C2661A7D_wBytes(zT_168, zT_169, zT_170);
    zT_176 = s;
    zT_179 = src_fn.temp_variant_sub_field;
    zT_180 = zT_179.values;
    zT_181 = (unsigned char*)zT_180;
    zT_177 = zT_181;
    zT_183 = cap * (unsigned int)(4);
    zT_178 = zT_183;
    zF_C2661A7D_wBytes(zT_176, zT_177, zT_178);
    zT_184 = s;
    zT_187 = src_fn.temp_variant_sub_field;
    zT_188 = zT_187.occupied;
    zT_189 = (unsigned char*)zT_188;
    zT_185 = zT_189;
    zT_191 = cap * (unsigned int)(1);
    zT_186 = zT_191;
    zF_C2661A7D_wBytes(zT_184, zT_185, zT_186);
    goto z_bb_16;
    z_bb_16:
    zT_193 = s->write_offset;
    zT_194 = zT_193 - start;
    byte_len = zT_194;
    byte_len = zT_194;
    byte_len = zT_194;
    zT_196 = src_fn.module_id;
    zT_195.module_id = zT_196;
    zT_195.disk_offset = start;
    zT_195.byte_len = byte_len;
    return zT_195;
}

/* emptyLirFunction */
zT_BBC23664_LirFunction zF_FAE9AF21_emptyLirFunction(zT_3E40CD83_Sand* dst) {
    zT_BBC23664_LirFunction zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_CFE23D0A_LirParamArrayList zT_6 = {0};
    zT_3E40CD83_Sand* zT_7;
    zT_1CF28CA3_BasicBlockArrayList zT_8 = {0};
    zT_3E40CD83_Sand* zT_9;
    zT_5D72FBF8_TempDeclArrayList zT_10 = {0};
    zT_3E40CD83_Sand* zT_11;
    zT_9F514E82_SwitchCaseArrayList zT_12 = {0};
    zT_3E40CD83_Sand* zT_13;
    zT_AC00B5F6_LirSideEntryArrayLi zT_14 = {0};
    zT_3E40CD83_Sand* zT_15;
    zT_21D3708C_U32ToU32Map zT_16 = {0};
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    zT_2 = 0;
    zT_1.name_id = zT_2;
    zT_3 = 0;
    zT_1.module_id = zT_3;
    zT_4 = 0;
    zT_1.return_type = zT_4;
    zT_5 = dst;
    zT_6 = zF_0ED358C0_lirParamArrayListIn(zT_5);
    zT_1.params = zT_6;
    zT_7 = dst;
    zT_8 = zF_2B78727D_basicBlockArrayList(zT_7);
    zT_1.blocks = zT_8;
    zT_9 = dst;
    zT_10 = zF_DE63156A_tempDeclArrayListIn(zT_9);
    zT_1.hoisted_temps = zT_10;
    zT_11 = dst;
    zT_12 = zF_64707188_switchCaseArrayList(zT_11);
    zT_1.switch_cases = zT_12;
    zT_13 = dst;
    zT_14 = zF_4231AD2C_lirSideEntryArrayLi(zT_13);
    zT_1.side_table = zT_14;
    zT_15 = dst;
    zT_16 = zF_58BDA2DE_u32ToU32MapInit(zT_15);
    zT_1.temp_variant_sub_field = zT_16;
    zT_17 = 0;
    zT_1.is_extern = zT_17;
    zT_18 = 0;
    zT_1.is_pub = zT_18;
    zT_19 = 0;
    zT_1.is_variadic = zT_19;
    return zT_1;
}

/* lirStreamReadFunction */
zT_BBC23664_LirFunction zF_1B7118E0_lirStreamReadFuncti(zT_7E7544E4_LirStream* s, zT_E7714190_LirSlot slot, zT_3E40CD83_Sand* dst) {
    zT_3E40CD83_Sand* zT_3;
    zT_D21A8776_SpillStore* zT_4;
    unsigned int zT_5;
    zT_D21A8776_SpillStore* zT_6;
    unsigned int zT_7;
    zT_7E7544E4_LirStream* zT_9;
    unsigned int zT_10 = 0;
    zT_7E7544E4_LirStream* zT_12;
    unsigned int zT_13 = 0;
    zT_7E7544E4_LirStream* zT_15;
    unsigned int zT_16 = 0;
    zT_7E7544E4_LirStream* zT_18;
    unsigned char zT_19 = 0;
    zT_7E7544E4_LirStream* zT_21;
    unsigned char zT_22 = 0;
    zT_7E7544E4_LirStream* zT_24;
    unsigned char zT_25 = 0;
    zT_7E7544E4_LirStream* zT_26;
    unsigned char zT_27 = 0;
    zT_7E7544E4_LirStream* zT_29;
    unsigned int zT_30 = 0;
    zT_7E7544E4_LirStream* zT_32;
    unsigned int zT_33 = 0;
    zT_7E7544E4_LirStream* zT_35;
    unsigned int zT_36 = 0;
    zT_7E7544E4_LirStream* zT_38;
    unsigned int zT_39 = 0;
    zT_7E7544E4_LirStream* zT_41;
    unsigned int zT_42 = 0;
    zT_7E7544E4_LirStream* zT_44;
    unsigned int zT_45 = 0;
    zT_7E7544E4_LirStream* zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_50;
    unsigned int zT_53;
    unsigned int zT_56;
    unsigned int zT_59;
    unsigned int zT_62;
    unsigned int zT_65;
    unsigned int zT_70;
    zT_3E40CD83_Sand* zT_72;
    zT_CFE23D0A_LirParamArrayList zT_73 = {0};
    zT_3E40CD83_Sand* zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_0F51E4CA_EU_222 zT_84 = {0};
    unsigned char zT_85;
    unsigned char* zT_86;
    unsigned char* zT_87;
    zT_7E7544E4_LirStream* zT_91;
    unsigned char* zT_92;
    unsigned int zT_93;
    zT_8779209D_LirParam* zT_94;
    unsigned char* zT_95;
    unsigned int zT_98;
    zT_3E40CD83_Sand* zT_100;
    zT_1CF28CA3_BasicBlockArrayList zT_101 = {0};
    zT_3E40CD83_Sand* zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_0F51E4CA_EU_222 zT_112 = {0};
    unsigned char zT_113;
    unsigned char* zT_114;
    unsigned char* zT_115;
    zT_88A68B1A_BasicBlock* zT_117;
    unsigned int zT_121;
    zT_7E7544E4_LirStream* zT_125;
    unsigned int zT_126 = 0;
    zT_7E7544E4_LirStream* zT_128;
    unsigned char zT_129 = 0;
    zT_7E7544E4_LirStream* zT_130;
    unsigned char zT_131 = 0;
    zT_7E7544E4_LirStream* zT_132;
    unsigned char zT_133 = 0;
    zT_7E7544E4_LirStream* zT_134;
    unsigned char zT_135 = 0;
    zT_7E7544E4_LirStream* zT_137;
    unsigned int zT_138 = 0;
    unsigned int zT_141;
    zT_3E40CD83_Sand* zT_143;
    zT_DAE4631D_LirInstArrayList zT_144 = {0};
    zT_3E40CD83_Sand* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_153;
    unsigned int zT_154;
    zT_0F51E4CA_EU_222 zT_155 = {0};
    unsigned char zT_156;
    unsigned char* zT_157;
    unsigned char* zT_158;
    zT_7E7544E4_LirStream* zT_162;
    unsigned char* zT_163;
    unsigned int zT_164;
    zT_6BA597BC_LirInst* zT_165;
    unsigned char* zT_166;
    unsigned int zT_169;
    zT_88A68B1A_BasicBlock zT_170;
    unsigned int zT_172;
    zT_3E40CD83_Sand* zT_174;
    zT_5D72FBF8_TempDeclArrayList zT_175 = {0};
    zT_3E40CD83_Sand* zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_184;
    unsigned int zT_185;
    zT_0F51E4CA_EU_222 zT_186 = {0};
    unsigned char zT_187;
    unsigned char* zT_188;
    unsigned char* zT_189;
    zT_7E7544E4_LirStream* zT_193;
    unsigned char* zT_194;
    unsigned int zT_195;
    zT_1937645B_TempDecl* zT_196;
    unsigned char* zT_197;
    unsigned int zT_200;
    zT_3E40CD83_Sand* zT_202;
    zT_9F514E82_SwitchCaseArrayList zT_203 = {0};
    zT_3E40CD83_Sand* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_212;
    unsigned int zT_213;
    zT_0F51E4CA_EU_222 zT_214 = {0};
    unsigned char zT_215;
    unsigned char* zT_216;
    unsigned char* zT_217;
    zT_7E7544E4_LirStream* zT_221;
    unsigned char* zT_222;
    unsigned int zT_223;
    zT_4BD97095_SwitchCase* zT_224;
    unsigned char* zT_225;
    unsigned int zT_228;
    zT_3E40CD83_Sand* zT_230;
    zT_AC00B5F6_LirSideEntryArrayLi zT_231 = {0};
    zT_3E40CD83_Sand* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_0F51E4CA_EU_222 zT_242 = {0};
    unsigned char zT_243;
    unsigned char* zT_244;
    unsigned char* zT_245;
    zT_7E7544E4_LirStream* zT_249;
    unsigned char* zT_250;
    unsigned int zT_251;
    zT_A8A5B231_LirSideEntry* zT_252;
    unsigned char* zT_253;
    unsigned int zT_256;
    zT_3E40CD83_Sand* zT_258;
    zT_21D3708C_U32ToU32Map zT_259 = {0};
    unsigned int zT_263;
    zT_3E40CD83_Sand* zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int zT_269;
    unsigned int zT_270;
    zT_0F51E4CA_EU_222 zT_271 = {0};
    unsigned char zT_272;
    unsigned char* zT_273;
    unsigned char* zT_274;
    zT_3E40CD83_Sand* zT_276;
    unsigned int zT_277;
    unsigned int zT_278;
    unsigned int zT_280;
    unsigned int zT_281;
    zT_0F51E4CA_EU_222 zT_282 = {0};
    unsigned char zT_283;
    unsigned char* zT_284;
    unsigned char* zT_285;
    zT_3E40CD83_Sand* zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    unsigned int zT_291;
    unsigned int zT_292;
    zT_0F51E4CA_EU_222 zT_293 = {0};
    unsigned char zT_294;
    unsigned char* zT_295;
    unsigned char* zT_296;
    zT_7E7544E4_LirStream* zT_301;
    unsigned char* zT_302;
    unsigned int zT_303;
    unsigned int* zT_304;
    unsigned char* zT_305;
    unsigned int zT_307;
    zT_7E7544E4_LirStream* zT_308;
    unsigned char* zT_309;
    unsigned int zT_310;
    unsigned int* zT_311;
    unsigned char* zT_312;
    unsigned int zT_314;
    zT_7E7544E4_LirStream* zT_315;
    unsigned char* zT_316;
    unsigned int zT_317;
    unsigned char* zT_318;
    unsigned char* zT_319;
    unsigned int zT_321;
    unsigned int zT_322;
    char* zT_325;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_326;
    unsigned int zT_327;
    char* zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    unsigned int zT_331;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    int zT_335;
    unsigned int zT_336;
    zT_3E40CD83_Sand* zT_337;
    zT_BBC23664_LirFunction zT_338 = {0};
    zT_BBC23664_LirFunction zT_339;
    unsigned int name_id;
    unsigned int module_id;
    unsigned int return_type;
    unsigned char is_extern;
    unsigned char is_pub;
    unsigned char is_variadic;
    unsigned int params_count;
    unsigned int blocks_count;
    unsigned int hoisted_temps_count;
    unsigned int switch_cases_count;
    unsigned int side_table_count;
    unsigned int tvsf_capacity;
    unsigned int tvsf_count;
    unsigned int expected_len;
    zT_CFE23D0A_LirParamArrayList params;
    unsigned char* raw;
    zT_1CF28CA3_BasicBlockArrayList blocks;
    unsigned char* braw;
    zT_5D72FBF8_TempDeclArrayList hoisted_temps;
    zT_88A68B1A_BasicBlock* bitems;
    unsigned int bi;
    unsigned int bb_id;
    unsigned char bb_term;
    unsigned int insts_count;
    zT_DAE4631D_LirInstArrayList binsts;
    unsigned char* iraw;
    zT_9F514E82_SwitchCaseArrayList switch_cases;
    zT_AC00B5F6_LirSideEntryArrayLi side_table;
    zT_21D3708C_U32ToU32Map tvsf;
    unsigned int cap;
    unsigned char* kraw;
    unsigned char* vraw;
    unsigned char* oraw;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = dst;
    zF_F1B3F8C2_sandReset(zT_3);
    zT_6 = &s->spill;
    zT_4 = zT_6;
    zT_7 = slot.disk_offset;
    zT_5 = zT_7;
    zF_56A911A9_spillSeek(zT_4, zT_5);
    zT_9 = s;
    zT_10 = zF_3E695161_rU32(zT_9);
    name_id = zT_10;
    name_id = zT_10;
    name_id = zT_10;
    zT_12 = s;
    zT_13 = zF_3E695161_rU32(zT_12);
    module_id = zT_13;
    module_id = zT_13;
    module_id = zT_13;
    zT_15 = s;
    zT_16 = zF_3E695161_rU32(zT_15);
    return_type = zT_16;
    return_type = zT_16;
    return_type = zT_16;
    zT_18 = s;
    zT_19 = zF_747E1168_rU8(zT_18);
    is_extern = zT_19;
    is_extern = zT_19;
    is_extern = zT_19;
    zT_21 = s;
    zT_22 = zF_747E1168_rU8(zT_21);
    is_pub = zT_22;
    is_pub = zT_22;
    is_pub = zT_22;
    zT_24 = s;
    zT_25 = zF_747E1168_rU8(zT_24);
    is_variadic = zT_25;
    is_variadic = zT_25;
    is_variadic = zT_25;
    zT_26 = s;
    zT_27 = zF_747E1168_rU8(zT_26);
    (void)zT_27;
    zT_29 = s;
    zT_30 = zF_3E695161_rU32(zT_29);
    params_count = zT_30;
    params_count = zT_30;
    params_count = zT_30;
    zT_32 = s;
    zT_33 = zF_3E695161_rU32(zT_32);
    blocks_count = zT_33;
    blocks_count = zT_33;
    blocks_count = zT_33;
    zT_35 = s;
    zT_36 = zF_3E695161_rU32(zT_35);
    hoisted_temps_count = zT_36;
    hoisted_temps_count = zT_36;
    hoisted_temps_count = zT_36;
    zT_38 = s;
    zT_39 = zF_3E695161_rU32(zT_38);
    switch_cases_count = zT_39;
    switch_cases_count = zT_39;
    switch_cases_count = zT_39;
    zT_41 = s;
    zT_42 = zF_3E695161_rU32(zT_41);
    side_table_count = zT_42;
    side_table_count = zT_42;
    side_table_count = zT_42;
    zT_44 = s;
    zT_45 = zF_3E695161_rU32(zT_44);
    tvsf_capacity = zT_45;
    tvsf_capacity = zT_45;
    tvsf_capacity = zT_45;
    zT_47 = s;
    zT_48 = zF_3E695161_rU32(zT_47);
    tvsf_count = zT_48;
    tvsf_count = zT_48;
    tvsf_count = zT_48;
    zT_50 = 44;
    expected_len = zT_50;
    expected_len = zT_50;
    expected_len = zT_50;
    zT_53 = expected_len + (unsigned int)(params_count * (unsigned int)(12));
    expected_len = zT_53;
    expected_len = zT_53;
    zT_56 = expected_len + (unsigned int)(blocks_count * (unsigned int)(12));
    expected_len = zT_56;
    expected_len = zT_56;
    zT_59 = expected_len + (unsigned int)(hoisted_temps_count * (unsigned int)(8));
    expected_len = zT_59;
    expected_len = zT_59;
    zT_62 = expected_len + (unsigned int)(switch_cases_count * (unsigned int)(16));
    expected_len = zT_62;
    expected_len = zT_62;
    zT_65 = expected_len + (unsigned int)(side_table_count * (unsigned int)(28));
    expected_len = zT_65;
    expected_len = zT_65;
    if ((int)(tvsf_capacity > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_70 = expected_len + (unsigned int)(tvsf_capacity * (unsigned int)(9));
    expected_len = zT_70;
    expected_len = zT_70;
    goto z_bb_2;
    z_bb_2:
    zT_72 = dst;
    zT_73 = zF_0ED358C0_lirParamArrayListIn(zT_72);
    params = zT_73;
    params = zT_73;
    params = zT_73;
    if ((int)(params_count > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_77 = dst;
    zT_82 = (unsigned int)((unsigned int)params_count) * (unsigned int)(12);
    zT_78 = zT_82;
    zT_83 = 4;
    zT_79 = zT_83;
    zT_84 = zF_1395EB68_sandAlloc(zT_77, zT_78, zT_79);
    zT_85 = zT_84.is_error;
    if (zT_85) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_100 = dst;
    zT_101 = zF_2B78727D_basicBlockArrayList(zT_100);
    blocks = zT_101;
    blocks = zT_101;
    blocks = zT_101;
    if ((int)(blocks_count > (unsigned int)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    z_bb_6:
    zT_87 = zT_84.data.payload;
    zT_86 = zT_87;
    goto z_bb_7;
    z_bb_7:
    raw = zT_86;
    raw = zT_86;
    raw = zT_86;
    params.items = (zT_8779209D_LirParam*)((zT_8779209D_LirParam*)raw);
    params.len = (unsigned int)((unsigned int)params_count);
    params.capacity = (unsigned int)((unsigned int)params_count);
    zT_91 = s;
    zT_94 = params.items;
    zT_95 = (unsigned char*)zT_94;
    zT_92 = zT_95;
    zT_98 = (unsigned int)((unsigned int)params_count) * (unsigned int)(12);
    zT_93 = zT_98;
    zF_CF6758F4_rBytes(zT_91, zT_92, zT_93);
    goto z_bb_4;
    z_bb_8:
    zT_105 = dst;
    zT_110 = (unsigned int)((unsigned int)blocks_count) * (unsigned int)(24);
    zT_106 = zT_110;
    zT_111 = 4;
    zT_107 = zT_111;
    zT_112 = zF_1395EB68_sandAlloc(zT_105, zT_106, zT_107);
    zT_113 = zT_112.is_error;
    if (zT_113) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_174 = dst;
    zT_175 = zF_DE63156A_tempDeclArrayListIn(zT_174);
    hoisted_temps = zT_175;
    hoisted_temps = zT_175;
    hoisted_temps = zT_175;
    if ((int)(hoisted_temps_count > (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_10:
    z_bb_11:
    zT_115 = zT_112.data.payload;
    zT_114 = zT_115;
    goto z_bb_12;
    z_bb_12:
    braw = zT_114;
    braw = zT_114;
    braw = zT_114;
    zT_117 = (zT_88A68B1A_BasicBlock*)braw;
    bitems = zT_117;
    bitems = zT_117;
    bitems = zT_117;
    blocks.items = bitems;
    blocks.len = (unsigned int)((unsigned int)blocks_count);
    blocks.capacity = (unsigned int)((unsigned int)blocks_count);
    zT_121 = 0;
    bi = zT_121;
    bi = zT_121;
    bi = zT_121;
    goto z_bb_13;
    z_bb_13:
    if ((int)(bi < (unsigned int)((unsigned int)blocks_count))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_125 = s;
    zT_126 = zF_3E695161_rU32(zT_125);
    bb_id = zT_126;
    bb_id = zT_126;
    bb_id = zT_126;
    zT_128 = s;
    zT_129 = zF_747E1168_rU8(zT_128);
    bb_term = zT_129;
    bb_term = zT_129;
    bb_term = zT_129;
    zT_130 = s;
    zT_131 = zF_747E1168_rU8(zT_130);
    (void)zT_131;
    zT_132 = s;
    zT_133 = zF_747E1168_rU8(zT_132);
    (void)zT_133;
    zT_134 = s;
    zT_135 = zF_747E1168_rU8(zT_134);
    (void)zT_135;
    zT_137 = s;
    zT_138 = zF_3E695161_rU32(zT_137);
    insts_count = zT_138;
    insts_count = zT_138;
    insts_count = zT_138;
    zT_141 = expected_len + (unsigned int)(insts_count * (unsigned int)(32));
    expected_len = zT_141;
    expected_len = zT_141;
    zT_143 = dst;
    zT_144 = zF_C6E3B5BB_lirInstArrayListIni(zT_143);
    binsts = zT_144;
    binsts = zT_144;
    binsts = zT_144;
    if ((int)(insts_count > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_172 = bi + (unsigned int)(1);
    bi = zT_172;
    bi = zT_172;
    goto z_bb_13;
    z_bb_17:
    zT_148 = dst;
    zT_153 = (unsigned int)((unsigned int)insts_count) * (unsigned int)(32);
    zT_149 = zT_153;
    zT_154 = 4;
    zT_150 = zT_154;
    zT_155 = zF_1395EB68_sandAlloc(zT_148, zT_149, zT_150);
    zT_156 = zT_155.is_error;
    if (zT_156) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_170.id = bb_id;
    zT_170.insts = binsts;
    zT_170.is_terminated = bb_term;
    bitems[bi] = zT_170;
    goto z_bb_16;
    z_bb_19:
    z_bb_20:
    zT_158 = zT_155.data.payload;
    zT_157 = zT_158;
    goto z_bb_21;
    z_bb_21:
    iraw = zT_157;
    iraw = zT_157;
    iraw = zT_157;
    binsts.items = (zT_6BA597BC_LirInst*)((zT_6BA597BC_LirInst*)iraw);
    binsts.len = (unsigned int)((unsigned int)insts_count);
    binsts.capacity = (unsigned int)((unsigned int)insts_count);
    zT_162 = s;
    zT_165 = binsts.items;
    zT_166 = (unsigned char*)zT_165;
    zT_163 = zT_166;
    zT_169 = (unsigned int)((unsigned int)insts_count) * (unsigned int)(32);
    zT_164 = zT_169;
    zF_CF6758F4_rBytes(zT_162, zT_163, zT_164);
    goto z_bb_18;
    z_bb_22:
    zT_179 = dst;
    zT_184 = (unsigned int)((unsigned int)hoisted_temps_count) * (unsigned int)(8);
    zT_180 = zT_184;
    zT_185 = 4;
    zT_181 = zT_185;
    zT_186 = zF_1395EB68_sandAlloc(zT_179, zT_180, zT_181);
    zT_187 = zT_186.is_error;
    if (zT_187) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_202 = dst;
    zT_203 = zF_64707188_switchCaseArrayList(zT_202);
    switch_cases = zT_203;
    switch_cases = zT_203;
    switch_cases = zT_203;
    if ((int)(switch_cases_count > (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    z_bb_25:
    zT_189 = zT_186.data.payload;
    zT_188 = zT_189;
    goto z_bb_26;
    z_bb_26:
    raw = zT_188;
    raw = zT_188;
    raw = zT_188;
    hoisted_temps.items = (zT_1937645B_TempDecl*)((zT_1937645B_TempDecl*)raw);
    hoisted_temps.len = (unsigned int)((unsigned int)hoisted_temps_count);
    hoisted_temps.capacity = (unsigned int)((unsigned int)hoisted_temps_count);
    zT_193 = s;
    zT_196 = hoisted_temps.items;
    zT_197 = (unsigned char*)zT_196;
    zT_194 = zT_197;
    zT_200 = (unsigned int)((unsigned int)hoisted_temps_count) * (unsigned int)(8);
    zT_195 = zT_200;
    zF_CF6758F4_rBytes(zT_193, zT_194, zT_195);
    goto z_bb_23;
    z_bb_27:
    zT_207 = dst;
    zT_212 = (unsigned int)((unsigned int)switch_cases_count) * (unsigned int)(16);
    zT_208 = zT_212;
    zT_213 = 4;
    zT_209 = zT_213;
    zT_214 = zF_1395EB68_sandAlloc(zT_207, zT_208, zT_209);
    zT_215 = zT_214.is_error;
    if (zT_215) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_230 = dst;
    zT_231 = zF_4231AD2C_lirSideEntryArrayLi(zT_230);
    side_table = zT_231;
    side_table = zT_231;
    side_table = zT_231;
    if ((int)(side_table_count > (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    z_bb_30:
    zT_217 = zT_214.data.payload;
    zT_216 = zT_217;
    goto z_bb_31;
    z_bb_31:
    raw = zT_216;
    raw = zT_216;
    raw = zT_216;
    switch_cases.items = (zT_4BD97095_SwitchCase*)((zT_4BD97095_SwitchCase*)raw);
    switch_cases.len = (unsigned int)((unsigned int)switch_cases_count);
    switch_cases.capacity = (unsigned int)((unsigned int)switch_cases_count);
    zT_221 = s;
    zT_224 = switch_cases.items;
    zT_225 = (unsigned char*)zT_224;
    zT_222 = zT_225;
    zT_228 = (unsigned int)((unsigned int)switch_cases_count) * (unsigned int)(16);
    zT_223 = zT_228;
    zF_CF6758F4_rBytes(zT_221, zT_222, zT_223);
    goto z_bb_28;
    z_bb_32:
    zT_235 = dst;
    zT_240 = (unsigned int)((unsigned int)side_table_count) * (unsigned int)(28);
    zT_236 = zT_240;
    zT_241 = 4;
    zT_237 = zT_241;
    zT_242 = zF_1395EB68_sandAlloc(zT_235, zT_236, zT_237);
    zT_243 = zT_242.is_error;
    if (zT_243) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_258 = dst;
    zT_259 = zF_58BDA2DE_u32ToU32MapInit(zT_258);
    tvsf = zT_259;
    tvsf = zT_259;
    tvsf = zT_259;
    if ((int)(tvsf_capacity > (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    z_bb_35:
    zT_245 = zT_242.data.payload;
    zT_244 = zT_245;
    goto z_bb_36;
    z_bb_36:
    raw = zT_244;
    raw = zT_244;
    raw = zT_244;
    side_table.items = (zT_A8A5B231_LirSideEntry*)((zT_A8A5B231_LirSideEntry*)raw);
    side_table.len = (unsigned int)((unsigned int)side_table_count);
    side_table.capacity = (unsigned int)((unsigned int)side_table_count);
    zT_249 = s;
    zT_252 = side_table.items;
    zT_253 = (unsigned char*)zT_252;
    zT_250 = zT_253;
    zT_256 = (unsigned int)((unsigned int)side_table_count) * (unsigned int)(28);
    zT_251 = zT_256;
    zF_CF6758F4_rBytes(zT_249, zT_250, zT_251);
    goto z_bb_33;
    z_bb_37:
    zT_263 = (unsigned int)tvsf_capacity;
    cap = zT_263;
    cap = zT_263;
    cap = zT_263;
    zT_265 = dst;
    zT_269 = (unsigned int)(4) * cap;
    zT_266 = zT_269;
    zT_270 = 4;
    zT_267 = zT_270;
    zT_271 = zF_1395EB68_sandAlloc(zT_265, zT_266, zT_267);
    zT_272 = zT_271.is_error;
    if (zT_272) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_322 = slot.byte_len;
    if ((int)(expected_len != zT_322)) goto z_bb_48; else goto z_bb_49;
    z_bb_39:
    z_bb_40:
    zT_274 = zT_271.data.payload;
    zT_273 = zT_274;
    goto z_bb_41;
    z_bb_41:
    kraw = zT_273;
    kraw = zT_273;
    kraw = zT_273;
    zT_276 = dst;
    zT_280 = (unsigned int)(4) * cap;
    zT_277 = zT_280;
    zT_281 = 4;
    zT_278 = zT_281;
    zT_282 = zF_1395EB68_sandAlloc(zT_276, zT_277, zT_278);
    zT_283 = zT_282.is_error;
    if (zT_283) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    z_bb_43:
    zT_285 = zT_282.data.payload;
    zT_284 = zT_285;
    goto z_bb_44;
    z_bb_44:
    vraw = zT_284;
    vraw = zT_284;
    vraw = zT_284;
    zT_287 = dst;
    zT_291 = (unsigned int)(1) * cap;
    zT_288 = zT_291;
    zT_292 = 4;
    zT_289 = zT_292;
    zT_293 = zF_1395EB68_sandAlloc(zT_287, zT_288, zT_289);
    zT_294 = zT_293.is_error;
    if (zT_294) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    z_bb_46:
    zT_296 = zT_293.data.payload;
    zT_295 = zT_296;
    goto z_bb_47;
    z_bb_47:
    oraw = zT_295;
    oraw = zT_295;
    oraw = zT_295;
    tvsf.keys = (unsigned int*)((unsigned int*)kraw);
    tvsf.values = (unsigned int*)((unsigned int*)vraw);
    tvsf.occupied = (unsigned char*)((unsigned char*)oraw);
    tvsf.capacity = cap;
    tvsf.count = (unsigned int)((unsigned int)tvsf_count);
    zT_301 = s;
    zT_304 = tvsf.keys;
    zT_305 = (unsigned char*)zT_304;
    zT_302 = zT_305;
    zT_307 = (unsigned int)(4) * cap;
    zT_303 = zT_307;
    zF_CF6758F4_rBytes(zT_301, zT_302, zT_303);
    zT_308 = s;
    zT_311 = tvsf.values;
    zT_312 = (unsigned char*)zT_311;
    zT_309 = zT_312;
    zT_314 = (unsigned int)(4) * cap;
    zT_310 = zT_314;
    zF_CF6758F4_rBytes(zT_308, zT_309, zT_310);
    zT_315 = s;
    zT_318 = tvsf.occupied;
    zT_319 = (unsigned char*)zT_318;
    zT_316 = zT_319;
    zT_321 = (unsigned int)(1) * cap;
    zT_317 = zT_321;
    zF_CF6758F4_rBytes(zT_315, zT_316, zT_317);
    goto z_bb_38;
    z_bb_48:
    zT_325 = "S-LIR byte_len mismatch on fault-in read";
    zT_327 = 40;
    zT_326.ptr = zT_325;
    zT_326.len = zT_327;
    emsg = zT_326;
    emsg = zT_326;
    emsg = zT_326;
    zT_329 = "lir_stream.zig";
    zT_331 = 14;
    zT_330.ptr = zT_329;
    zT_330.len = zT_331;
    ef = zT_330;
    ef = zT_330;
    ef = zT_330;
    zT_332 = emsg;
    zT_333 = ef;
    zT_335 = 306;
    zT_336 = (unsigned int)zT_335;
    zT_334 = zT_336;
    zF_6D97D338_panicHandler(zT_332, zT_333, zT_334);
    zT_337 = dst;
    zT_338 = zF_FAE9AF21_emptyLirFunction(zT_337);
    return zT_338;
    z_bb_49:
    zT_339.name_id = name_id;
    zT_339.module_id = module_id;
    zT_339.return_type = return_type;
    zT_339.params = params;
    zT_339.blocks = blocks;
    zT_339.hoisted_temps = hoisted_temps;
    zT_339.switch_cases = switch_cases;
    zT_339.side_table = side_table;
    zT_339.temp_variant_sub_field = tvsf;
    zT_339.is_extern = is_extern;
    zT_339.is_pub = is_pub;
    zT_339.is_variadic = is_variadic;
    return zT_339;
}

/* __module_init */
void zF_780653D2___module_init_13(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_BBC23664_LirFunction zT_1 = {0};
    zT_E7714190_LirSlot zT_2 = {0};
    char* zT_3;
    char* zT_4;
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_E7714190_LirSlot = zT_2;
    zT_3 = "rb";
    zG_4417A8F5_READ_MODE = zT_3;
    zT_4 = "wb";
    zG_82B6E276_WRITE_MODE = zT_4;
    return;
}

/* EOF */
