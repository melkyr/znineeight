#include "lir_stream_0760A6EE.h"
unsigned char* zG_4417A8F5_READ_MODE;
unsigned char* zG_82B6E276_WRITE_MODE;
/* lirStreamInit */
zT_7E7544E4_LirStream zF_E9CBFCA6_lirStreamInit(void) {
    zT_7E7544E4_LirStream zT_0;
    zT_D21A8776_SpillStore zT_1 = {0};
    unsigned int zT_2;
    unsigned int zT_3;
    zT_1 = zF_22C79E6C_spillStoreInit();
    zT_0.spill = zT_1;
    zT_2 = 0;
    zT_0.path_len = zT_2;
    zT_3 = 0;
    zT_0.write_offset = zT_3;
    return zT_0;
}

/* lirStreamBeginWrite */
void zF_B0B74E20_lirStreamBeginWrite(zT_7E7544E4_LirStream* s, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned char zT_8;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    zT_D21A8776_SpillStore* zT_19;
    zT_0426DCE7_SpillBackend zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_3E40CD83_Sand* zT_22;
    unsigned char* zT_23;
    zT_0426DCE7_SpillBackend zT_28 = 0;
    unsigned char* zT_29;
    unsigned int zT_30;
    int zT_31;
    unsigned char* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int i;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = path.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_11 = path.ptr;
    zT_12 = zT_11[i];
    zT_13 = s->path;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    s->path_len = i;
    zT_16 = 0;
    zT_17 = s->path;
    zT_17[i] = zT_16;
    s->write_offset = (unsigned int)(0);
    zT_19 = &s->spill;
    zT_28 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_lir));
    zT_20 = zT_28;
    zT_29 = s->path;
    zT_30 = s->path_len;
    zT_31 = 0;
    zT_32 = zT_29 + zT_31;
    zT_33 = zT_30 - zT_31;
    zT_34.ptr = zT_32;
    zT_34.len = zT_33;
    zT_21 = zT_34;
    zT_22 = alloc;
    zT_23 = zG_82B6E276_WRITE_MODE;
    zF_8AF94F71_spillOpen(zT_19, zT_20, zT_21, zT_22, zT_23);
    return;
    z_bb_4:
    zT_15 = i + (unsigned int)(1);
    i = zT_15;
    goto z_bb_1;
    z_bb_5:
    zT_8 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* lirStreamFinishWrite */
void zF_256E5B86_lirStreamFinishWrit(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_1 = &s->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* lirStreamBeginRead */
void zF_72DA7B39_lirStreamBeginRead(zT_7E7544E4_LirStream* s, zT_3E40CD83_Sand* alloc) {
    zT_D21A8776_SpillStore zT_2;
    zT_0426DCE7_SpillBackend zT_3;
    zT_D21A8776_SpillStore* zT_8;
    zT_D21A8776_SpillStore* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    zT_3E40CD83_Sand* zT_12;
    unsigned char* zT_13;
    unsigned char* zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned char* zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_2 = s->spill;
    zT_3 = zT_2.backend;
    if ((unsigned char)(zT_3 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = &s->spill;
    zT_8->cur = (unsigned int)(0);
    return;
    z_bb_2:
    zT_9 = &s->spill;
    zT_17 = s->path;
    zT_18 = s->path_len;
    zT_19 = 0;
    zT_20 = zT_17 + zT_19;
    zT_21 = zT_18 - zT_19;
    zT_22.ptr = zT_20;
    zT_22.len = zT_21;
    zT_11 = zT_22;
    zT_12 = alloc;
    zT_13 = zG_4417A8F5_READ_MODE;
    zF_8AF94F71_spillOpen(zT_9, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_11, zT_12, zT_13);
    return;
}

/* lirStreamEndRead */
void zF_9427AE59_lirStreamEndRead(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_1 = &s->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* wU32 */
void zF_FB050204_wU32(zT_7E7544E4_LirStream* s, unsigned int v) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_12;
    int zT_13;
    unsigned char zT_18;
    int zT_19;
    unsigned char zT_24;
    int zT_25;
    zT_D21A8776_SpillStore* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_6 = (unsigned char)(unsigned int)(v & (unsigned int)(255));
    zT_7 = 0;
    b[zT_7] = zT_6;
    zT_12 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255));
    zT_13 = 1;
    b[zT_13] = zT_12;
    zT_18 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255));
    zT_19 = 2;
    b[zT_19] = zT_18;
    zT_24 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255));
    zT_25 = 3;
    b[zT_25] = zT_24;
    zT_26 = &s->spill;
    zT_27 = s->write_offset;
    zT_33 = 0;
    zT_34 = (unsigned char*)((unsigned char*)b) + zT_33;
    zT_35 = (unsigned int)(4) - zT_33;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_28 = zT_36;
    zF_BFB33631_spillWriteAt(zT_26, zT_27, zT_28);
    zT_37 = s->write_offset;
    s->write_offset = (unsigned int)(zT_37 + (unsigned int)(4));
    return;
}

/* wU8 */
void zF_56013A33_wU8(zT_7E7544E4_LirStream* s, unsigned char v) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_3;
    int zT_4;
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 0;
    b[zT_4] = v;
    zT_5 = &s->spill;
    zT_6 = s->write_offset;
    zT_12 = 0;
    zT_13 = (unsigned char*)((unsigned char*)b) + zT_12;
    zT_14 = (unsigned int)(1) - zT_12;
    zT_15.ptr = zT_13;
    zT_15.len = zT_14;
    zT_7 = zT_15;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_16 = s->write_offset;
    s->write_offset = (unsigned int)(zT_16 + (unsigned int)(1));
    return;
}

/* wBytes */
void zF_C2661A7D_wBytes(zT_7E7544E4_LirStream* s, unsigned char* ptr, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    if ((unsigned char)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &s->spill;
    zT_6 = s->write_offset;
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    zT_7 = zT_13;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_14 = s->write_offset;
    s->write_offset = (unsigned int)(zT_14 + (unsigned int)((unsigned int)len));
    return;
}

/* rU32 */
unsigned int zF_3E695161_rU32(zT_7E7544E4_LirStream* s) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore zT_7;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16;
    int zT_17;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned char zT_22;
    unsigned int zT_26;
    int zT_27;
    unsigned char zT_28;
    unsigned int zT_32;
    int zT_33;
    unsigned char zT_34;
    unsigned int zT_38;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    unsigned int v;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = &s->spill;
    zT_7 = s->spill;
    zT_4 = zT_7.cur;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(4) - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_16 = 0;
    v = zT_16;
    zT_17 = 0;
    zT_18 = b[zT_17];
    zT_20 = v | (unsigned int)((unsigned int)zT_18);
    v = zT_20;
    zT_21 = 1;
    zT_22 = b[zT_21];
    zT_26 = v | (unsigned int)((unsigned int)((unsigned int)zT_22) << (unsigned int)(8));
    v = zT_26;
    zT_27 = 2;
    zT_28 = b[zT_27];
    zT_32 = v | (unsigned int)((unsigned int)((unsigned int)zT_28) << (unsigned int)(16));
    v = zT_32;
    zT_33 = 3;
    zT_34 = b[zT_33];
    zT_38 = v | (unsigned int)((unsigned int)((unsigned int)zT_34) << (unsigned int)(24));
    v = zT_38;
    return v;
}

/* rU8 */
unsigned char zF_747E1168_rU8(zT_7E7544E4_LirStream* s) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore zT_7;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_15;
    unsigned char zT_16;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = &s->spill;
    zT_7 = s->spill;
    zT_4 = zT_7.cur;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(1) - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_15 = 0;
    zT_16 = b[zT_15];
    return zT_16;
}

/* rBytes */
void zF_CF6758F4_rBytes(zT_7E7544E4_LirStream* s, unsigned char* dst, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_D21A8776_SpillStore zT_9;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    if ((unsigned char)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &s->spill;
    zT_9 = s->spill;
    zT_6 = zT_9.cur;
    zT_11 = 0;
    zT_12 = dst + zT_11;
    zT_13 = len - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_7 = zT_14;
    zF_E9F67450_spillReadAt(zT_5, zT_6, zT_7);
    return;
}

/* lirStreamAppend */
zT_E7714190_LirSlot zF_9F47D5E4_lirStreamAppend(zT_7E7544E4_LirStream* s, zT_BBC23664_LirFunction src_fn) {
    unsigned int zT_3;
    zT_7E7544E4_LirStream* zT_4;
    unsigned int zT_5;
    zT_7E7544E4_LirStream* zT_7;
    unsigned int zT_8;
    zT_7E7544E4_LirStream* zT_10;
    unsigned int zT_11;
    zT_7E7544E4_LirStream* zT_13;
    unsigned char zT_14;
    zT_7E7544E4_LirStream* zT_16;
    unsigned char zT_17;
    zT_7E7544E4_LirStream* zT_19;
    unsigned char zT_20;
    zT_7E7544E4_LirStream* zT_22;
    unsigned char zT_23;
    zT_7E7544E4_LirStream* zT_25;
    unsigned char zT_26;
    zT_7E7544E4_LirStream* zT_28;
    unsigned char zT_29;
    zT_7E7544E4_LirStream* zT_31;
    zT_CFE23D0A_LirParamArrayList zT_33;
    unsigned int zT_34;
    zT_7E7544E4_LirStream* zT_36;
    zT_1CF28CA3_BasicBlockArrayList zT_38;
    unsigned int zT_39;
    zT_7E7544E4_LirStream* zT_41;
    zT_5D72FBF8_TempDeclArrayList zT_43;
    unsigned int zT_44;
    zT_7E7544E4_LirStream* zT_46;
    zT_9F514E82_SwitchCaseArrayList zT_48;
    unsigned int zT_49;
    zT_7E7544E4_LirStream* zT_51;
    zT_AC00B5F6_LirSideEntryArrayLi zT_53;
    unsigned int zT_54;
    zT_7E7544E4_LirStream* zT_56;
    zT_21D3708C_U32ToU32Map zT_58;
    unsigned int zT_59;
    zT_7E7544E4_LirStream* zT_61;
    zT_21D3708C_U32ToU32Map zT_63;
    unsigned int zT_64;
    zT_CFE23D0A_LirParamArrayList zT_66;
    unsigned int zT_67;
    zT_7E7544E4_LirStream* zT_70;
    zT_CFE23D0A_LirParamArrayList zT_73;
    zT_8779209D_LirParam* zT_74;
    zT_CFE23D0A_LirParamArrayList zT_76;
    unsigned int zT_77;
    unsigned int zT_81;
    zT_1CF28CA3_BasicBlockArrayList zT_82;
    unsigned int zT_83;
    zT_1CF28CA3_BasicBlockArrayList zT_86;
    zT_88A68B1A_BasicBlock* zT_87;
    zT_88A68B1A_BasicBlock* zT_88;
    zT_7E7544E4_LirStream* zT_89;
    unsigned int zT_90;
    zT_7E7544E4_LirStream* zT_92;
    unsigned char zT_93;
    zT_7E7544E4_LirStream* zT_95;
    zT_7E7544E4_LirStream* zT_98;
    zT_7E7544E4_LirStream* zT_101;
    zT_7E7544E4_LirStream* zT_104;
    zT_DAE4631D_LirInstArrayList zT_106;
    unsigned int zT_107;
    zT_DAE4631D_LirInstArrayList zT_109;
    unsigned int zT_110;
    zT_7E7544E4_LirStream* zT_113;
    zT_DAE4631D_LirInstArrayList zT_116;
    zT_6BA597BC_LirInst* zT_117;
    zT_DAE4631D_LirInstArrayList zT_119;
    unsigned int zT_120;
    unsigned int zT_124;
    zT_5D72FBF8_TempDeclArrayList zT_125;
    unsigned int zT_126;
    zT_7E7544E4_LirStream* zT_129;
    zT_5D72FBF8_TempDeclArrayList zT_132;
    zT_1937645B_TempDecl* zT_133;
    zT_5D72FBF8_TempDeclArrayList zT_135;
    unsigned int zT_136;
    zT_9F514E82_SwitchCaseArrayList zT_139;
    unsigned int zT_140;
    zT_7E7544E4_LirStream* zT_143;
    zT_9F514E82_SwitchCaseArrayList zT_146;
    zT_4BD97095_SwitchCase* zT_147;
    zT_9F514E82_SwitchCaseArrayList zT_149;
    unsigned int zT_150;
    zT_AC00B5F6_LirSideEntryArrayLi zT_153;
    unsigned int zT_154;
    zT_7E7544E4_LirStream* zT_157;
    zT_AC00B5F6_LirSideEntryArrayLi zT_160;
    zT_A8A5B231_LirSideEntry* zT_161;
    zT_AC00B5F6_LirSideEntryArrayLi zT_163;
    unsigned int zT_164;
    zT_21D3708C_U32ToU32Map zT_167;
    unsigned int zT_168;
    zT_21D3708C_U32ToU32Map zT_172;
    unsigned int zT_173;
    zT_7E7544E4_LirStream* zT_174;
    zT_21D3708C_U32ToU32Map zT_177;
    unsigned int* zT_178;
    zT_7E7544E4_LirStream* zT_182;
    zT_21D3708C_U32ToU32Map zT_185;
    unsigned int* zT_186;
    zT_7E7544E4_LirStream* zT_190;
    zT_21D3708C_U32ToU32Map zT_193;
    unsigned char* zT_194;
    unsigned int zT_199;
    unsigned int zT_200;
    zT_E7714190_LirSlot zT_201;
    unsigned int zT_202;
    unsigned int start;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int cap;
    unsigned int byte_len;
    zT_3 = s->write_offset;
    start = zT_3;
    zT_4 = s;
    zT_5 = src_fn.name_id;
    zF_FB050204_wU32(zT_4, zT_5);
    zT_7 = s;
    zT_8 = src_fn.module_id;
    zF_FB050204_wU32(zT_7, zT_8);
    zT_10 = s;
    zT_11 = src_fn.return_type;
    zF_FB050204_wU32(zT_10, zT_11);
    zT_13 = s;
    zT_14 = src_fn.is_extern;
    zF_56013A33_wU8(zT_13, zT_14);
    zT_16 = s;
    zT_17 = src_fn.is_pub;
    zF_56013A33_wU8(zT_16, zT_17);
    zT_19 = s;
    zT_20 = src_fn.is_variadic;
    zF_56013A33_wU8(zT_19, zT_20);
    zT_22 = s;
    zT_23 = src_fn.call_conv;
    zF_56013A33_wU8(zT_22, zT_23);
    zT_25 = s;
    zT_26 = src_fn.poison_uninit;
    zF_56013A33_wU8(zT_25, zT_26);
    zT_28 = s;
    zT_29 = src_fn.is_export;
    zF_56013A33_wU8(zT_28, zT_29);
    zT_31 = s;
    zT_33 = src_fn.params;
    zT_34 = zT_33.len;
    zF_FB050204_wU32(zT_31, (unsigned int)((unsigned int)zT_34));
    zT_36 = s;
    zT_38 = src_fn.blocks;
    zT_39 = zT_38.len;
    zF_FB050204_wU32(zT_36, (unsigned int)((unsigned int)zT_39));
    zT_41 = s;
    zT_43 = src_fn.hoisted_temps;
    zT_44 = zT_43.len;
    zF_FB050204_wU32(zT_41, (unsigned int)((unsigned int)zT_44));
    zT_46 = s;
    zT_48 = src_fn.switch_cases;
    zT_49 = zT_48.len;
    zF_FB050204_wU32(zT_46, (unsigned int)((unsigned int)zT_49));
    zT_51 = s;
    zT_53 = src_fn.side_table;
    zT_54 = zT_53.len;
    zF_FB050204_wU32(zT_51, (unsigned int)((unsigned int)zT_54));
    zT_56 = s;
    zT_58 = src_fn.temp_variant_sub_field;
    zT_59 = zT_58.capacity;
    zF_FB050204_wU32(zT_56, (unsigned int)((unsigned int)zT_59));
    zT_61 = s;
    zT_63 = src_fn.temp_variant_sub_field;
    zT_64 = zT_63.count;
    zF_FB050204_wU32(zT_61, (unsigned int)((unsigned int)zT_64));
    zT_66 = src_fn.params;
    zT_67 = zT_66.len;
    if ((unsigned char)(zT_67 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_70 = s;
    zT_73 = src_fn.params;
    zT_74 = zT_73.items;
    zT_76 = src_fn.params;
    zT_77 = zT_76.len;
    zF_C2661A7D_wBytes(zT_70, (unsigned char*)((unsigned char*)zT_74), (unsigned int)(zT_77 * (unsigned int)(12)));
    goto z_bb_2;
    z_bb_2:
    zT_81 = 0;
    bi = zT_81;
    goto z_bb_3;
    z_bb_3:
    zT_82 = src_fn.blocks;
    zT_83 = zT_82.len;
    if ((unsigned char)(bi < zT_83)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_86 = src_fn.blocks;
    zT_87 = zT_86.items;
    zT_88 = zT_87 + bi;
    bb = zT_88;
    zT_89 = s;
    zT_90 = bb->id;
    zF_FB050204_wU32(zT_89, zT_90);
    zT_92 = s;
    zT_93 = bb->is_terminated;
    zF_56013A33_wU8(zT_92, zT_93);
    zT_95 = s;
    zF_56013A33_wU8(zT_95, (unsigned char)(0));
    zT_98 = s;
    zF_56013A33_wU8(zT_98, (unsigned char)(0));
    zT_101 = s;
    zF_56013A33_wU8(zT_101, (unsigned char)(0));
    zT_104 = s;
    zT_106 = bb->insts;
    zT_107 = zT_106.len;
    zF_FB050204_wU32(zT_104, (unsigned int)((unsigned int)zT_107));
    zT_109 = bb->insts;
    zT_110 = zT_109.len;
    if ((unsigned char)(zT_110 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_125 = src_fn.hoisted_temps;
    zT_126 = zT_125.len;
    if ((unsigned char)(zT_126 > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_124 = bi + (unsigned int)(1);
    bi = zT_124;
    goto z_bb_3;
    z_bb_7:
    zT_113 = s;
    zT_116 = bb->insts;
    zT_117 = zT_116.items;
    zT_119 = bb->insts;
    zT_120 = zT_119.len;
    zF_C2661A7D_wBytes(zT_113, (unsigned char*)((unsigned char*)zT_117), (unsigned int)(zT_120 * (unsigned int)(32)));
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_129 = s;
    zT_132 = src_fn.hoisted_temps;
    zT_133 = zT_132.items;
    zT_135 = src_fn.hoisted_temps;
    zT_136 = zT_135.len;
    zF_C2661A7D_wBytes(zT_129, (unsigned char*)((unsigned char*)zT_133), (unsigned int)(zT_136 * (unsigned int)(8)));
    goto z_bb_10;
    z_bb_10:
    zT_139 = src_fn.switch_cases;
    zT_140 = zT_139.len;
    if ((unsigned char)(zT_140 > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_143 = s;
    zT_146 = src_fn.switch_cases;
    zT_147 = zT_146.items;
    zT_149 = src_fn.switch_cases;
    zT_150 = zT_149.len;
    zF_C2661A7D_wBytes(zT_143, (unsigned char*)((unsigned char*)zT_147), (unsigned int)(zT_150 * (unsigned int)(16)));
    goto z_bb_12;
    z_bb_12:
    zT_153 = src_fn.side_table;
    zT_154 = zT_153.len;
    if ((unsigned char)(zT_154 > (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_157 = s;
    zT_160 = src_fn.side_table;
    zT_161 = zT_160.items;
    zT_163 = src_fn.side_table;
    zT_164 = zT_163.len;
    zF_C2661A7D_wBytes(zT_157, (unsigned char*)((unsigned char*)zT_161), (unsigned int)(zT_164 * (unsigned int)(28)));
    goto z_bb_14;
    z_bb_14:
    zT_167 = src_fn.temp_variant_sub_field;
    zT_168 = zT_167.capacity;
    if ((unsigned char)(zT_168 > (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_172 = src_fn.temp_variant_sub_field;
    zT_173 = zT_172.capacity;
    cap = zT_173;
    zT_174 = s;
    zT_177 = src_fn.temp_variant_sub_field;
    zT_178 = zT_177.keys;
    zF_C2661A7D_wBytes(zT_174, (unsigned char*)((unsigned char*)zT_178), (unsigned int)(cap * (unsigned int)(4)));
    zT_182 = s;
    zT_185 = src_fn.temp_variant_sub_field;
    zT_186 = zT_185.values;
    zF_C2661A7D_wBytes(zT_182, (unsigned char*)((unsigned char*)zT_186), (unsigned int)(cap * (unsigned int)(4)));
    zT_190 = s;
    zT_193 = src_fn.temp_variant_sub_field;
    zT_194 = zT_193.occupied;
    zF_C2661A7D_wBytes(zT_190, (unsigned char*)((unsigned char*)zT_194), (unsigned int)(cap * (unsigned int)(1)));
    goto z_bb_16;
    z_bb_16:
    zT_199 = s->write_offset;
    zT_200 = zT_199 - start;
    byte_len = zT_200;
    zT_202 = src_fn.module_id;
    zT_201.module_id = zT_202;
    zT_201.disk_offset = start;
    zT_201.byte_len = byte_len;
    return zT_201;
}

/* emptyLirFunction */
zT_BBC23664_LirFunction zF_FAE9AF21_emptyLirFunction(zT_3E40CD83_Sand* dst) {
    zT_BBC23664_LirFunction zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_CFE23D0A_LirParamArrayList zT_6 = {0};
    zT_3E40CD83_Sand* zT_7;
    zT_1CF28CA3_BasicBlockArrayList zT_8 = {0};
    zT_3E40CD83_Sand* zT_9;
    zT_5D72FBF8_TempDeclArrayList zT_10 = {0};
    zT_3E40CD83_Sand* zT_11;
    zT_9F514E82_SwitchCaseArrayList zT_12 = {0};
    zT_3E40CD83_Sand* zT_13;
    zT_AC00B5F6_LirSideEntryArrayLi zT_14 = {0};
    zT_3E40CD83_Sand* zT_15;
    zT_21D3708C_U32ToU32Map zT_16 = {0};
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    unsigned char zT_22;
    zT_2 = 0;
    zT_1.name_id = zT_2;
    zT_3 = 0;
    zT_1.module_id = zT_3;
    zT_4 = 0;
    zT_1.return_type = zT_4;
    zT_5 = dst;
    zT_6 = zF_0ED358C0_lirParamArrayListIn(zT_5);
    zT_1.params = zT_6;
    zT_7 = dst;
    zT_8 = zF_2B78727D_basicBlockArrayList(zT_7);
    zT_1.blocks = zT_8;
    zT_9 = dst;
    zT_10 = zF_DE63156A_tempDeclArrayListIn(zT_9);
    zT_1.hoisted_temps = zT_10;
    zT_11 = dst;
    zT_12 = zF_64707188_switchCaseArrayList(zT_11);
    zT_1.switch_cases = zT_12;
    zT_13 = dst;
    zT_14 = zF_4231AD2C_lirSideEntryArrayLi(zT_13);
    zT_1.side_table = zT_14;
    zT_15 = dst;
    zT_16 = zF_58BDA2DE_u32ToU32MapInit(zT_15);
    zT_1.temp_variant_sub_field = zT_16;
    zT_17 = 0;
    zT_1.is_extern = zT_17;
    zT_18 = 0;
    zT_1.is_pub = zT_18;
    zT_19 = 0;
    zT_1.is_variadic = zT_19;
    zT_20 = 0;
    zT_1.call_conv = zT_20;
    zT_21 = 0;
    zT_1.poison_uninit = zT_21;
    zT_22 = 0;
    zT_1.is_export = zT_22;
    return zT_1;
}

/* lirStreamReadFunction */
zT_BBC23664_LirFunction zF_1B7118E0_lirStreamReadFuncti(zT_7E7544E4_LirStream* s, zT_E7714190_LirSlot slot, zT_3E40CD83_Sand* dst) {
    zT_3E40CD83_Sand* zT_3;
    zT_D21A8776_SpillStore* zT_4;
    unsigned int zT_5;
    zT_7E7544E4_LirStream* zT_9;
    unsigned int zT_10 = 0;
    zT_7E7544E4_LirStream* zT_12;
    unsigned int zT_13 = 0;
    zT_7E7544E4_LirStream* zT_15;
    unsigned int zT_16 = 0;
    zT_7E7544E4_LirStream* zT_18;
    unsigned char zT_19 = 0;
    zT_7E7544E4_LirStream* zT_21;
    unsigned char zT_22 = 0;
    zT_7E7544E4_LirStream* zT_24;
    unsigned char zT_25 = 0;
    zT_7E7544E4_LirStream* zT_27;
    unsigned char zT_28 = 0;
    zT_7E7544E4_LirStream* zT_30;
    unsigned char zT_31 = 0;
    zT_7E7544E4_LirStream* zT_33;
    unsigned char zT_34 = 0;
    zT_7E7544E4_LirStream* zT_36;
    unsigned int zT_37 = 0;
    zT_7E7544E4_LirStream* zT_39;
    unsigned int zT_40 = 0;
    zT_7E7544E4_LirStream* zT_42;
    unsigned int zT_43 = 0;
    zT_7E7544E4_LirStream* zT_45;
    unsigned int zT_46 = 0;
    zT_7E7544E4_LirStream* zT_48;
    unsigned int zT_49 = 0;
    zT_7E7544E4_LirStream* zT_51;
    unsigned int zT_52 = 0;
    zT_7E7544E4_LirStream* zT_54;
    unsigned int zT_55 = 0;
    unsigned int zT_57;
    unsigned int zT_60;
    unsigned int zT_63;
    unsigned int zT_66;
    unsigned int zT_69;
    unsigned int zT_72;
    unsigned int zT_77;
    zT_3E40CD83_Sand* zT_79;
    zT_CFE23D0A_LirParamArrayList zT_80 = {0};
    zT_3E40CD83_Sand* zT_84;
    zT_0715C9B9_EU_832 zT_91 = {0};
    unsigned char zT_92;
    unsigned char* zT_93;
    zT_7E7544E4_LirStream* zT_98;
    zT_8779209D_LirParam* zT_101;
    zT_3E40CD83_Sand* zT_107;
    zT_1CF28CA3_BasicBlockArrayList zT_108 = {0};
    zT_3E40CD83_Sand* zT_112;
    zT_0715C9B9_EU_832 zT_119 = {0};
    unsigned char zT_120;
    unsigned char* zT_121;
    zT_88A68B1A_BasicBlock* zT_124;
    unsigned int zT_128;
    zT_7E7544E4_LirStream* zT_132;
    unsigned int zT_133 = 0;
    zT_7E7544E4_LirStream* zT_135;
    unsigned char zT_136 = 0;
    zT_7E7544E4_LirStream* zT_137;
    unsigned char zT_138 = 0;
    zT_7E7544E4_LirStream* zT_139;
    unsigned char zT_140 = 0;
    zT_7E7544E4_LirStream* zT_141;
    unsigned char zT_142 = 0;
    zT_7E7544E4_LirStream* zT_144;
    unsigned int zT_145 = 0;
    unsigned int zT_148;
    zT_3E40CD83_Sand* zT_150;
    zT_DAE4631D_LirInstArrayList zT_151 = {0};
    zT_3E40CD83_Sand* zT_155;
    zT_0715C9B9_EU_832 zT_162 = {0};
    unsigned char zT_163;
    unsigned char* zT_164;
    zT_7E7544E4_LirStream* zT_169;
    zT_6BA597BC_LirInst* zT_172;
    zT_88A68B1A_BasicBlock zT_177;
    unsigned int zT_179;
    zT_3E40CD83_Sand* zT_181;
    zT_5D72FBF8_TempDeclArrayList zT_182 = {0};
    zT_3E40CD83_Sand* zT_186;
    zT_0715C9B9_EU_832 zT_193 = {0};
    unsigned char zT_194;
    unsigned char* zT_195;
    zT_7E7544E4_LirStream* zT_200;
    zT_1937645B_TempDecl* zT_203;
    zT_3E40CD83_Sand* zT_209;
    zT_9F514E82_SwitchCaseArrayList zT_210 = {0};
    zT_3E40CD83_Sand* zT_214;
    zT_0715C9B9_EU_832 zT_221 = {0};
    unsigned char zT_222;
    unsigned char* zT_223;
    zT_7E7544E4_LirStream* zT_228;
    zT_4BD97095_SwitchCase* zT_231;
    zT_3E40CD83_Sand* zT_237;
    zT_AC00B5F6_LirSideEntryArrayLi zT_238 = {0};
    zT_3E40CD83_Sand* zT_242;
    zT_0715C9B9_EU_832 zT_249 = {0};
    unsigned char zT_250;
    unsigned char* zT_251;
    zT_7E7544E4_LirStream* zT_256;
    zT_A8A5B231_LirSideEntry* zT_259;
    zT_3E40CD83_Sand* zT_265;
    zT_21D3708C_U32ToU32Map zT_266 = {0};
    unsigned int zT_270;
    zT_3E40CD83_Sand* zT_272;
    zT_0715C9B9_EU_832 zT_278 = {0};
    unsigned char zT_279;
    unsigned char* zT_280;
    zT_3E40CD83_Sand* zT_283;
    zT_0715C9B9_EU_832 zT_289 = {0};
    unsigned char zT_290;
    unsigned char* zT_291;
    zT_3E40CD83_Sand* zT_294;
    zT_0715C9B9_EU_832 zT_300 = {0};
    unsigned char zT_301;
    unsigned char* zT_302;
    zT_7E7544E4_LirStream* zT_308;
    unsigned int* zT_311;
    zT_7E7544E4_LirStream* zT_315;
    unsigned int* zT_318;
    zT_7E7544E4_LirStream* zT_322;
    unsigned char* zT_325;
    unsigned int zT_329;
    unsigned char* zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    unsigned char* zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    unsigned int zT_338;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_339;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_340;
    int zT_342;
    zT_3E40CD83_Sand* zT_344;
    zT_BBC23664_LirFunction zT_345 = {0};
    zT_BBC23664_LirFunction zT_346;
    unsigned int name_id;
    unsigned int module_id;
    unsigned int return_type;
    unsigned char is_extern;
    unsigned char is_pub;
    unsigned char is_variadic;
    unsigned char call_conv;
    unsigned char poison_uninit;
    unsigned char is_export;
    unsigned int params_count;
    unsigned int blocks_count;
    unsigned int hoisted_temps_count;
    unsigned int switch_cases_count;
    unsigned int side_table_count;
    unsigned int tvsf_capacity;
    unsigned int tvsf_count;
    unsigned int expected_len;
    zT_CFE23D0A_LirParamArrayList params;
    unsigned char* raw;
    zT_1CF28CA3_BasicBlockArrayList blocks;
    unsigned char* braw;
    zT_5D72FBF8_TempDeclArrayList hoisted_temps;
    zT_88A68B1A_BasicBlock* bitems;
    unsigned int bi;
    unsigned int bb_id;
    unsigned char bb_term;
    unsigned int insts_count;
    zT_DAE4631D_LirInstArrayList binsts;
    unsigned char* iraw;
    zT_9F514E82_SwitchCaseArrayList switch_cases;
    zT_AC00B5F6_LirSideEntryArrayLi side_table;
    zT_21D3708C_U32ToU32Map tvsf;
    unsigned int cap;
    unsigned char* kraw;
    unsigned char* vraw;
    unsigned char* oraw;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = dst;
    zF_F1B3F8C2_sandReset(zT_3);
    zT_4 = &s->spill;
    zT_5 = slot.disk_offset;
    zF_56A911A9_spillSeek(zT_4, zT_5);
    zT_9 = s;
    zT_10 = zF_3E695161_rU32(zT_9);
    name_id = zT_10;
    zT_12 = s;
    zT_13 = zF_3E695161_rU32(zT_12);
    module_id = zT_13;
    zT_15 = s;
    zT_16 = zF_3E695161_rU32(zT_15);
    return_type = zT_16;
    zT_18 = s;
    zT_19 = zF_747E1168_rU8(zT_18);
    is_extern = zT_19;
    zT_21 = s;
    zT_22 = zF_747E1168_rU8(zT_21);
    is_pub = zT_22;
    zT_24 = s;
    zT_25 = zF_747E1168_rU8(zT_24);
    is_variadic = zT_25;
    zT_27 = s;
    zT_28 = zF_747E1168_rU8(zT_27);
    call_conv = zT_28;
    zT_30 = s;
    zT_31 = zF_747E1168_rU8(zT_30);
    poison_uninit = zT_31;
    zT_33 = s;
    zT_34 = zF_747E1168_rU8(zT_33);
    is_export = zT_34;
    zT_36 = s;
    zT_37 = zF_3E695161_rU32(zT_36);
    params_count = zT_37;
    zT_39 = s;
    zT_40 = zF_3E695161_rU32(zT_39);
    blocks_count = zT_40;
    zT_42 = s;
    zT_43 = zF_3E695161_rU32(zT_42);
    hoisted_temps_count = zT_43;
    zT_45 = s;
    zT_46 = zF_3E695161_rU32(zT_45);
    switch_cases_count = zT_46;
    zT_48 = s;
    zT_49 = zF_3E695161_rU32(zT_48);
    side_table_count = zT_49;
    zT_51 = s;
    zT_52 = zF_3E695161_rU32(zT_51);
    tvsf_capacity = zT_52;
    zT_54 = s;
    zT_55 = zF_3E695161_rU32(zT_54);
    tvsf_count = zT_55;
    zT_57 = 46;
    expected_len = zT_57;
    zT_60 = expected_len + (unsigned int)(params_count * (unsigned int)(12));
    expected_len = zT_60;
    zT_63 = expected_len + (unsigned int)(blocks_count * (unsigned int)(12));
    expected_len = zT_63;
    zT_66 = expected_len + (unsigned int)(hoisted_temps_count * (unsigned int)(8));
    expected_len = zT_66;
    zT_69 = expected_len + (unsigned int)(switch_cases_count * (unsigned int)(16));
    expected_len = zT_69;
    zT_72 = expected_len + (unsigned int)(side_table_count * (unsigned int)(28));
    expected_len = zT_72;
    if ((unsigned char)(tvsf_capacity > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_77 = expected_len + (unsigned int)(tvsf_capacity * (unsigned int)(9));
    expected_len = zT_77;
    goto z_bb_2;
    z_bb_2:
    zT_79 = dst;
    zT_80 = zF_0ED358C0_lirParamArrayListIn(zT_79);
    params = zT_80;
    if ((unsigned char)(params_count > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_84 = dst;
    zT_91 = zF_1395EB68_sandAlloc(zT_84, (unsigned int)((unsigned int)((unsigned int)params_count) * (unsigned int)(12)), (unsigned int)(4));
    zT_92 = zT_91.is_error;
    if (zT_92) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_107 = dst;
    zT_108 = zF_2B78727D_basicBlockArrayList(zT_107);
    blocks = zT_108;
    if ((unsigned char)(blocks_count > (unsigned int)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_93 = zT_91.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_93;
    params.items = (zT_8779209D_LirParam*)((zT_8779209D_LirParam*)raw);
    params.len = (unsigned int)((unsigned int)params_count);
    params.capacity = (unsigned int)((unsigned int)params_count);
    zT_98 = s;
    zT_101 = params.items;
    zF_CF6758F4_rBytes(zT_98, (unsigned char*)((unsigned char*)zT_101), (unsigned int)((unsigned int)((unsigned int)params_count) * (unsigned int)(12)));
    goto z_bb_4;
    z_bb_8:
    zT_112 = dst;
    zT_119 = zF_1395EB68_sandAlloc(zT_112, (unsigned int)((unsigned int)((unsigned int)blocks_count) * (unsigned int)(24)), (unsigned int)(4));
    zT_120 = zT_119.is_error;
    if (zT_120) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_181 = dst;
    zT_182 = zF_DE63156A_tempDeclArrayListIn(zT_181);
    hoisted_temps = zT_182;
    if ((unsigned char)(hoisted_temps_count > (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_121 = zT_119.data.payload;
    goto z_bb_12;
    z_bb_12:
    braw = zT_121;
    zT_124 = (zT_88A68B1A_BasicBlock*)braw;
    bitems = zT_124;
    blocks.items = bitems;
    blocks.len = (unsigned int)((unsigned int)blocks_count);
    blocks.capacity = (unsigned int)((unsigned int)blocks_count);
    zT_128 = 0;
    bi = zT_128;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(bi < (unsigned int)((unsigned int)blocks_count))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_132 = s;
    zT_133 = zF_3E695161_rU32(zT_132);
    bb_id = zT_133;
    zT_135 = s;
    zT_136 = zF_747E1168_rU8(zT_135);
    bb_term = zT_136;
    zT_137 = s;
    zT_138 = zF_747E1168_rU8(zT_137);
    (void)zT_138;
    zT_139 = s;
    zT_140 = zF_747E1168_rU8(zT_139);
    (void)zT_140;
    zT_141 = s;
    zT_142 = zF_747E1168_rU8(zT_141);
    (void)zT_142;
    zT_144 = s;
    zT_145 = zF_3E695161_rU32(zT_144);
    insts_count = zT_145;
    zT_148 = expected_len + (unsigned int)(insts_count * (unsigned int)(32));
    expected_len = zT_148;
    zT_150 = dst;
    zT_151 = zF_C6E3B5BB_lirInstArrayListIni(zT_150);
    binsts = zT_151;
    if ((unsigned char)(insts_count > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_179 = bi + (unsigned int)(1);
    bi = zT_179;
    goto z_bb_13;
    z_bb_17:
    zT_155 = dst;
    zT_162 = zF_1395EB68_sandAlloc(zT_155, (unsigned int)((unsigned int)((unsigned int)insts_count) * (unsigned int)(32)), (unsigned int)(4));
    zT_163 = zT_162.is_error;
    if (zT_163) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_177.id = bb_id;
    zT_177.insts = binsts;
    zT_177.is_terminated = bb_term;
    bitems[bi] = zT_177;
    goto z_bb_16;
    z_bb_19:
    pal_trap();
    z_bb_20:
    zT_164 = zT_162.data.payload;
    goto z_bb_21;
    z_bb_21:
    iraw = zT_164;
    binsts.items = (zT_6BA597BC_LirInst*)((zT_6BA597BC_LirInst*)iraw);
    binsts.len = (unsigned int)((unsigned int)insts_count);
    binsts.capacity = (unsigned int)((unsigned int)insts_count);
    zT_169 = s;
    zT_172 = binsts.items;
    zF_CF6758F4_rBytes(zT_169, (unsigned char*)((unsigned char*)zT_172), (unsigned int)((unsigned int)((unsigned int)insts_count) * (unsigned int)(32)));
    goto z_bb_18;
    z_bb_22:
    zT_186 = dst;
    zT_193 = zF_1395EB68_sandAlloc(zT_186, (unsigned int)((unsigned int)((unsigned int)hoisted_temps_count) * (unsigned int)(8)), (unsigned int)(4));
    zT_194 = zT_193.is_error;
    if (zT_194) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_209 = dst;
    zT_210 = zF_64707188_switchCaseArrayList(zT_209);
    switch_cases = zT_210;
    if ((unsigned char)(switch_cases_count > (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    pal_trap();
    z_bb_25:
    zT_195 = zT_193.data.payload;
    goto z_bb_26;
    z_bb_26:
    raw = zT_195;
    hoisted_temps.items = (zT_1937645B_TempDecl*)((zT_1937645B_TempDecl*)raw);
    hoisted_temps.len = (unsigned int)((unsigned int)hoisted_temps_count);
    hoisted_temps.capacity = (unsigned int)((unsigned int)hoisted_temps_count);
    zT_200 = s;
    zT_203 = hoisted_temps.items;
    zF_CF6758F4_rBytes(zT_200, (unsigned char*)((unsigned char*)zT_203), (unsigned int)((unsigned int)((unsigned int)hoisted_temps_count) * (unsigned int)(8)));
    goto z_bb_23;
    z_bb_27:
    zT_214 = dst;
    zT_221 = zF_1395EB68_sandAlloc(zT_214, (unsigned int)((unsigned int)((unsigned int)switch_cases_count) * (unsigned int)(16)), (unsigned int)(4));
    zT_222 = zT_221.is_error;
    if (zT_222) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_237 = dst;
    zT_238 = zF_4231AD2C_lirSideEntryArrayLi(zT_237);
    side_table = zT_238;
    if ((unsigned char)(side_table_count > (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    pal_trap();
    z_bb_30:
    zT_223 = zT_221.data.payload;
    goto z_bb_31;
    z_bb_31:
    raw = zT_223;
    switch_cases.items = (zT_4BD97095_SwitchCase*)((zT_4BD97095_SwitchCase*)raw);
    switch_cases.len = (unsigned int)((unsigned int)switch_cases_count);
    switch_cases.capacity = (unsigned int)((unsigned int)switch_cases_count);
    zT_228 = s;
    zT_231 = switch_cases.items;
    zF_CF6758F4_rBytes(zT_228, (unsigned char*)((unsigned char*)zT_231), (unsigned int)((unsigned int)((unsigned int)switch_cases_count) * (unsigned int)(16)));
    goto z_bb_28;
    z_bb_32:
    zT_242 = dst;
    zT_249 = zF_1395EB68_sandAlloc(zT_242, (unsigned int)((unsigned int)((unsigned int)side_table_count) * (unsigned int)(28)), (unsigned int)(4));
    zT_250 = zT_249.is_error;
    if (zT_250) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_265 = dst;
    zT_266 = zF_58BDA2DE_u32ToU32MapInit(zT_265);
    tvsf = zT_266;
    if ((unsigned char)(tvsf_capacity > (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    pal_trap();
    z_bb_35:
    zT_251 = zT_249.data.payload;
    goto z_bb_36;
    z_bb_36:
    raw = zT_251;
    side_table.items = (zT_A8A5B231_LirSideEntry*)((zT_A8A5B231_LirSideEntry*)raw);
    side_table.len = (unsigned int)((unsigned int)side_table_count);
    side_table.capacity = (unsigned int)((unsigned int)side_table_count);
    zT_256 = s;
    zT_259 = side_table.items;
    zF_CF6758F4_rBytes(zT_256, (unsigned char*)((unsigned char*)zT_259), (unsigned int)((unsigned int)((unsigned int)side_table_count) * (unsigned int)(28)));
    goto z_bb_33;
    z_bb_37:
    zT_270 = (unsigned int)tvsf_capacity;
    cap = zT_270;
    zT_272 = dst;
    zT_278 = zF_1395EB68_sandAlloc(zT_272, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_279 = zT_278.is_error;
    if (zT_279) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_329 = slot.byte_len;
    if ((unsigned char)(expected_len != zT_329)) goto z_bb_48; else goto z_bb_49;
    z_bb_39:
    pal_trap();
    z_bb_40:
    zT_280 = zT_278.data.payload;
    goto z_bb_41;
    z_bb_41:
    kraw = zT_280;
    zT_283 = dst;
    zT_289 = zF_1395EB68_sandAlloc(zT_283, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_290 = zT_289.is_error;
    if (zT_290) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    pal_trap();
    z_bb_43:
    zT_291 = zT_289.data.payload;
    goto z_bb_44;
    z_bb_44:
    vraw = zT_291;
    zT_294 = dst;
    zT_300 = zF_1395EB68_sandAlloc(zT_294, (unsigned int)((unsigned int)(1) * cap), (unsigned int)(4));
    zT_301 = zT_300.is_error;
    if (zT_301) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    pal_trap();
    z_bb_46:
    zT_302 = zT_300.data.payload;
    goto z_bb_47;
    z_bb_47:
    oraw = zT_302;
    tvsf.keys = (unsigned int*)((unsigned int*)kraw);
    tvsf.values = (unsigned int*)((unsigned int*)vraw);
    tvsf.occupied = (unsigned char*)((unsigned char*)oraw);
    tvsf.capacity = cap;
    tvsf.count = (unsigned int)((unsigned int)tvsf_count);
    zT_308 = s;
    zT_311 = tvsf.keys;
    zF_CF6758F4_rBytes(zT_308, (unsigned char*)((unsigned char*)zT_311), (unsigned int)((unsigned int)(4) * cap));
    zT_315 = s;
    zT_318 = tvsf.values;
    zF_CF6758F4_rBytes(zT_315, (unsigned char*)((unsigned char*)zT_318), (unsigned int)((unsigned int)(4) * cap));
    zT_322 = s;
    zT_325 = tvsf.occupied;
    zF_CF6758F4_rBytes(zT_322, (unsigned char*)((unsigned char*)zT_325), (unsigned int)((unsigned int)(1) * cap));
    goto z_bb_38;
    z_bb_48:
    zT_332 = "S-LIR byte_len mismatch on fault-in read";
    zT_334 = 40;
    zT_333.ptr = zT_332;
    zT_333.len = zT_334;
    emsg = zT_333;
    zT_336 = "lir_stream.zig";
    zT_338 = 14;
    zT_337.ptr = zT_336;
    zT_337.len = zT_338;
    ef = zT_337;
    zT_339 = emsg;
    zT_340 = ef;
    zT_342 = 306;
    zF_6D97D338_panicHandler(zT_339, zT_340, (unsigned int)((unsigned int)zT_342));
    zT_344 = dst;
    zT_345 = zF_FAE9AF21_emptyLirFunction(zT_344);
    return zT_345;
    z_bb_49:
    zT_346.name_id = name_id;
    zT_346.module_id = module_id;
    zT_346.return_type = return_type;
    zT_346.params = params;
    zT_346.blocks = blocks;
    zT_346.hoisted_temps = hoisted_temps;
    zT_346.switch_cases = switch_cases;
    zT_346.side_table = side_table;
    zT_346.temp_variant_sub_field = tvsf;
    zT_346.is_extern = is_extern;
    zT_346.is_pub = is_pub;
    zT_346.is_variadic = is_variadic;
    zT_346.call_conv = call_conv;
    zT_346.poison_uninit = poison_uninit;
    zT_346.is_export = is_export;
    return zT_346;
}

/* __module_init */
void zF_780653D2___module_init_14(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_BBC23664_LirFunction zT_1 = {0};
    zT_E7714190_LirSlot zT_2 = {0};
    unsigned char* zT_3;
    unsigned char* zT_4;
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_E7714190_LirSlot = zT_2;
    zT_3 = "rb";
    zG_4417A8F5_READ_MODE = zT_3;
    zT_4 = "wb";
    zG_82B6E276_WRITE_MODE = zT_4;
    return;
}

/* EOF */
