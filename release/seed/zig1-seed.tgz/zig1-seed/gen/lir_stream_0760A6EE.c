#include "lir_stream_0760A6EE.h"
unsigned char* zG_4417A8F5_READ_MODE;
unsigned char* zG_82B6E276_WRITE_MODE;
/* lirStreamInit */
zT_7E7544E4_LirStream zF_E9CBFCA6_lirStreamInit(void) {
    zT_7E7544E4_LirStream zT_0;
    zT_D21A8776_SpillStore zT_1 = {0};
    unsigned int zT_2;
    unsigned int zT_3;
    zT_1 = zF_22C79E6C_spillStoreInit();
    zT_0.spill = zT_1;
    zT_2 = 0;
    zT_0.path_len = zT_2;
    zT_3 = 0;
    zT_0.write_offset = zT_3;
    return zT_0;
}

/* lirStreamBeginWrite */
void zF_B0B74E20_lirStreamBeginWrite(zT_7E7544E4_LirStream* s, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_8;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    zT_D21A8776_SpillStore* zT_19;
    zT_0426DCE7_SpillBackend zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_3E40CD83_Sand* zT_22;
    unsigned char* zT_23;
    zT_0426DCE7_SpillBackend zT_29 = 0;
    unsigned char* zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int i;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = path.len;
    if ((int)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_11 = path.ptr;
    zT_12 = zT_11[i];
    zT_13 = s->path;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    s->path_len = i;
    zT_16 = 0;
    zT_17 = s->path;
    zT_17[i] = zT_16;
    s->write_offset = (unsigned int)(0);
    zT_19 = &s->spill;
    zT_29 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_lir));
    zT_20 = zT_29;
    zT_30 = s->path;
    zT_31 = s->path_len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_21 = zT_35;
    zT_22 = alloc;
    zT_23 = zG_82B6E276_WRITE_MODE;
    zF_8AF94F71_spillOpen(zT_19, zT_20, zT_21, zT_22, zT_23);
    return;
    z_bb_4:
    zT_15 = i + (unsigned int)(1);
    i = zT_15;
    goto z_bb_1;
    z_bb_5:
    zT_8 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* lirStreamFinishWrite */
void zF_256E5B86_lirStreamFinishWrit(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_1 = &s->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* lirStreamBeginRead */
void zF_72DA7B39_lirStreamBeginRead(zT_7E7544E4_LirStream* s, zT_3E40CD83_Sand* alloc) {
    zT_D21A8776_SpillStore zT_2;
    zT_0426DCE7_SpillBackend zT_3;
    zT_D21A8776_SpillStore* zT_9;
    zT_D21A8776_SpillStore* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_3E40CD83_Sand* zT_13;
    unsigned char* zT_14;
    unsigned char* zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_2 = s->spill;
    zT_3 = zT_2.backend;
    if ((int)(zT_3 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = &s->spill;
    zT_9->cur = (unsigned int)(0);
    return;
    z_bb_2:
    zT_10 = &s->spill;
    zT_19 = s->path;
    zT_20 = s->path_len;
    zT_21 = 0;
    zT_22 = zT_19 + zT_21;
    zT_23 = zT_20 - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_12 = zT_24;
    zT_13 = alloc;
    zT_14 = zG_4417A8F5_READ_MODE;
    zF_8AF94F71_spillOpen(zT_10, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_12, zT_13, zT_14);
    return;
}

/* lirStreamEndRead */
void zF_9427AE59_lirStreamEndRead(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_1 = &s->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* wU32 */
void zF_FB050204_wU32(zT_7E7544E4_LirStream* s, unsigned int v) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_12;
    int zT_13;
    unsigned char zT_18;
    int zT_19;
    unsigned char zT_24;
    int zT_25;
    zT_D21A8776_SpillStore* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_6 = (unsigned char)(unsigned int)(v & (unsigned int)(255));
    zT_7 = 0;
    b[zT_7] = zT_6;
    zT_12 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255));
    zT_13 = 1;
    b[zT_13] = zT_12;
    zT_18 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255));
    zT_19 = 2;
    b[zT_19] = zT_18;
    zT_24 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255));
    zT_25 = 3;
    b[zT_25] = zT_24;
    zT_26 = &s->spill;
    zT_27 = s->write_offset;
    zT_33 = 0;
    zT_34 = (unsigned char*)((unsigned char*)b) + zT_33;
    zT_35 = (unsigned int)(4) - zT_33;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_28 = zT_36;
    zF_BFB33631_spillWriteAt(zT_26, zT_27, zT_28);
    zT_37 = s->write_offset;
    s->write_offset = (unsigned int)(zT_37 + (unsigned int)(4));
    return;
}

/* wU8 */
void zF_56013A33_wU8(zT_7E7544E4_LirStream* s, unsigned char v) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_3;
    int zT_4;
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 0;
    b[zT_4] = v;
    zT_5 = &s->spill;
    zT_6 = s->write_offset;
    zT_12 = 0;
    zT_13 = (unsigned char*)((unsigned char*)b) + zT_12;
    zT_14 = (unsigned int)(1) - zT_12;
    zT_15.ptr = zT_13;
    zT_15.len = zT_14;
    zT_7 = zT_15;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_16 = s->write_offset;
    s->write_offset = (unsigned int)(zT_16 + (unsigned int)(1));
    return;
}

/* wBytes */
void zF_C2661A7D_wBytes(zT_7E7544E4_LirStream* s, unsigned char* ptr, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    if ((int)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &s->spill;
    zT_6 = s->write_offset;
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    zT_7 = zT_13;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_14 = s->write_offset;
    s->write_offset = (unsigned int)(zT_14 + (unsigned int)((unsigned int)len));
    return;
}

/* rU32 */
unsigned int zF_3E695161_rU32(zT_7E7544E4_LirStream* s) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore zT_7;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16;
    int zT_17;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned char zT_22;
    unsigned int zT_26;
    int zT_27;
    unsigned char zT_28;
    unsigned int zT_32;
    int zT_33;
    unsigned char zT_34;
    unsigned int zT_38;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    unsigned int v;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = &s->spill;
    zT_7 = s->spill;
    zT_4 = zT_7.cur;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(4) - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_16 = 0;
    v = zT_16;
    zT_17 = 0;
    zT_18 = b[zT_17];
    zT_20 = v | (unsigned int)((unsigned int)zT_18);
    v = zT_20;
    zT_21 = 1;
    zT_22 = b[zT_21];
    zT_26 = v | (unsigned int)((unsigned int)((unsigned int)zT_22) << (unsigned int)(8));
    v = zT_26;
    zT_27 = 2;
    zT_28 = b[zT_27];
    zT_32 = v | (unsigned int)((unsigned int)((unsigned int)zT_28) << (unsigned int)(16));
    v = zT_32;
    zT_33 = 3;
    zT_34 = b[zT_33];
    zT_38 = v | (unsigned int)((unsigned int)((unsigned int)zT_34) << (unsigned int)(24));
    v = zT_38;
    return v;
}

/* rU8 */
unsigned char zF_747E1168_rU8(zT_7E7544E4_LirStream* s) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore zT_7;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_15;
    unsigned char zT_16;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = &s->spill;
    zT_7 = s->spill;
    zT_4 = zT_7.cur;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(1) - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_15 = 0;
    zT_16 = b[zT_15];
    return zT_16;
}

/* rBytes */
void zF_CF6758F4_rBytes(zT_7E7544E4_LirStream* s, unsigned char* dst, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_D21A8776_SpillStore zT_9;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    if ((int)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &s->spill;
    zT_9 = s->spill;
    zT_6 = zT_9.cur;
    zT_11 = 0;
    zT_12 = dst + zT_11;
    zT_13 = len - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_7 = zT_14;
    zF_E9F67450_spillReadAt(zT_5, zT_6, zT_7);
    return;
}

/* lirStreamAppend */
zT_E7714190_LirSlot zF_9F47D5E4_lirStreamAppend(zT_7E7544E4_LirStream* s, zT_BBC23664_LirFunction src_fn) {
    unsigned int zT_3;
    zT_7E7544E4_LirStream* zT_4;
    unsigned int zT_5;
    zT_7E7544E4_LirStream* zT_7;
    unsigned int zT_8;
    zT_7E7544E4_LirStream* zT_10;
    unsigned int zT_11;
    zT_7E7544E4_LirStream* zT_13;
    unsigned char zT_14;
    zT_7E7544E4_LirStream* zT_16;
    unsigned char zT_17;
    zT_7E7544E4_LirStream* zT_19;
    unsigned char zT_20;
    zT_7E7544E4_LirStream* zT_22;
    unsigned char zT_23;
    zT_7E7544E4_LirStream* zT_25;
    zT_CFE23D0A_LirParamArrayList zT_27;
    unsigned int zT_28;
    zT_7E7544E4_LirStream* zT_30;
    zT_1CF28CA3_BasicBlockArrayList zT_32;
    unsigned int zT_33;
    zT_7E7544E4_LirStream* zT_35;
    zT_5D72FBF8_TempDeclArrayList zT_37;
    unsigned int zT_38;
    zT_7E7544E4_LirStream* zT_40;
    zT_9F514E82_SwitchCaseArrayList zT_42;
    unsigned int zT_43;
    zT_7E7544E4_LirStream* zT_45;
    zT_AC00B5F6_LirSideEntryArrayLi zT_47;
    unsigned int zT_48;
    zT_7E7544E4_LirStream* zT_50;
    zT_21D3708C_U32ToU32Map zT_52;
    unsigned int zT_53;
    zT_7E7544E4_LirStream* zT_55;
    zT_21D3708C_U32ToU32Map zT_57;
    unsigned int zT_58;
    zT_CFE23D0A_LirParamArrayList zT_60;
    unsigned int zT_61;
    zT_7E7544E4_LirStream* zT_64;
    zT_CFE23D0A_LirParamArrayList zT_67;
    zT_8779209D_LirParam* zT_68;
    zT_CFE23D0A_LirParamArrayList zT_70;
    unsigned int zT_71;
    unsigned int zT_75;
    zT_1CF28CA3_BasicBlockArrayList zT_76;
    unsigned int zT_77;
    zT_1CF28CA3_BasicBlockArrayList zT_80;
    zT_88A68B1A_BasicBlock* zT_81;
    zT_88A68B1A_BasicBlock* zT_82;
    zT_7E7544E4_LirStream* zT_83;
    unsigned int zT_84;
    zT_7E7544E4_LirStream* zT_86;
    unsigned char zT_87;
    zT_7E7544E4_LirStream* zT_89;
    zT_7E7544E4_LirStream* zT_92;
    zT_7E7544E4_LirStream* zT_95;
    zT_7E7544E4_LirStream* zT_98;
    zT_DAE4631D_LirInstArrayList zT_100;
    unsigned int zT_101;
    zT_DAE4631D_LirInstArrayList zT_103;
    unsigned int zT_104;
    zT_7E7544E4_LirStream* zT_107;
    zT_DAE4631D_LirInstArrayList zT_110;
    zT_6BA597BC_LirInst* zT_111;
    zT_DAE4631D_LirInstArrayList zT_113;
    unsigned int zT_114;
    unsigned int zT_118;
    zT_5D72FBF8_TempDeclArrayList zT_119;
    unsigned int zT_120;
    zT_7E7544E4_LirStream* zT_123;
    zT_5D72FBF8_TempDeclArrayList zT_126;
    zT_1937645B_TempDecl* zT_127;
    zT_5D72FBF8_TempDeclArrayList zT_129;
    unsigned int zT_130;
    zT_9F514E82_SwitchCaseArrayList zT_133;
    unsigned int zT_134;
    zT_7E7544E4_LirStream* zT_137;
    zT_9F514E82_SwitchCaseArrayList zT_140;
    zT_4BD97095_SwitchCase* zT_141;
    zT_9F514E82_SwitchCaseArrayList zT_143;
    unsigned int zT_144;
    zT_AC00B5F6_LirSideEntryArrayLi zT_147;
    unsigned int zT_148;
    zT_7E7544E4_LirStream* zT_151;
    zT_AC00B5F6_LirSideEntryArrayLi zT_154;
    zT_A8A5B231_LirSideEntry* zT_155;
    zT_AC00B5F6_LirSideEntryArrayLi zT_157;
    unsigned int zT_158;
    zT_21D3708C_U32ToU32Map zT_161;
    unsigned int zT_162;
    zT_21D3708C_U32ToU32Map zT_166;
    unsigned int zT_167;
    zT_7E7544E4_LirStream* zT_168;
    zT_21D3708C_U32ToU32Map zT_171;
    unsigned int* zT_172;
    zT_7E7544E4_LirStream* zT_176;
    zT_21D3708C_U32ToU32Map zT_179;
    unsigned int* zT_180;
    zT_7E7544E4_LirStream* zT_184;
    zT_21D3708C_U32ToU32Map zT_187;
    unsigned char* zT_188;
    unsigned int zT_193;
    unsigned int zT_194;
    zT_E7714190_LirSlot zT_195;
    unsigned int zT_196;
    unsigned int start;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int cap;
    unsigned int byte_len;
    zT_3 = s->write_offset;
    start = zT_3;
    zT_4 = s;
    zT_5 = src_fn.name_id;
    zF_FB050204_wU32(zT_4, zT_5);
    zT_7 = s;
    zT_8 = src_fn.module_id;
    zF_FB050204_wU32(zT_7, zT_8);
    zT_10 = s;
    zT_11 = src_fn.return_type;
    zF_FB050204_wU32(zT_10, zT_11);
    zT_13 = s;
    zT_14 = src_fn.is_extern;
    zF_56013A33_wU8(zT_13, zT_14);
    zT_16 = s;
    zT_17 = src_fn.is_pub;
    zF_56013A33_wU8(zT_16, zT_17);
    zT_19 = s;
    zT_20 = src_fn.is_variadic;
    zF_56013A33_wU8(zT_19, zT_20);
    zT_22 = s;
    zT_23 = src_fn.poison_uninit;
    zF_56013A33_wU8(zT_22, zT_23);
    zT_25 = s;
    zT_27 = src_fn.params;
    zT_28 = zT_27.len;
    zF_FB050204_wU32(zT_25, (unsigned int)((unsigned int)zT_28));
    zT_30 = s;
    zT_32 = src_fn.blocks;
    zT_33 = zT_32.len;
    zF_FB050204_wU32(zT_30, (unsigned int)((unsigned int)zT_33));
    zT_35 = s;
    zT_37 = src_fn.hoisted_temps;
    zT_38 = zT_37.len;
    zF_FB050204_wU32(zT_35, (unsigned int)((unsigned int)zT_38));
    zT_40 = s;
    zT_42 = src_fn.switch_cases;
    zT_43 = zT_42.len;
    zF_FB050204_wU32(zT_40, (unsigned int)((unsigned int)zT_43));
    zT_45 = s;
    zT_47 = src_fn.side_table;
    zT_48 = zT_47.len;
    zF_FB050204_wU32(zT_45, (unsigned int)((unsigned int)zT_48));
    zT_50 = s;
    zT_52 = src_fn.temp_variant_sub_field;
    zT_53 = zT_52.capacity;
    zF_FB050204_wU32(zT_50, (unsigned int)((unsigned int)zT_53));
    zT_55 = s;
    zT_57 = src_fn.temp_variant_sub_field;
    zT_58 = zT_57.count;
    zF_FB050204_wU32(zT_55, (unsigned int)((unsigned int)zT_58));
    zT_60 = src_fn.params;
    zT_61 = zT_60.len;
    if ((int)(zT_61 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_64 = s;
    zT_67 = src_fn.params;
    zT_68 = zT_67.items;
    zT_70 = src_fn.params;
    zT_71 = zT_70.len;
    zF_C2661A7D_wBytes(zT_64, (unsigned char*)((unsigned char*)zT_68), (unsigned int)(zT_71 * (unsigned int)(12)));
    goto z_bb_2;
    z_bb_2:
    zT_75 = 0;
    bi = zT_75;
    goto z_bb_3;
    z_bb_3:
    zT_76 = src_fn.blocks;
    zT_77 = zT_76.len;
    if ((int)(bi < zT_77)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_80 = src_fn.blocks;
    zT_81 = zT_80.items;
    zT_82 = zT_81 + bi;
    bb = zT_82;
    zT_83 = s;
    zT_84 = bb->id;
    zF_FB050204_wU32(zT_83, zT_84);
    zT_86 = s;
    zT_87 = bb->is_terminated;
    zF_56013A33_wU8(zT_86, zT_87);
    zT_89 = s;
    zF_56013A33_wU8(zT_89, (unsigned char)(0));
    zT_92 = s;
    zF_56013A33_wU8(zT_92, (unsigned char)(0));
    zT_95 = s;
    zF_56013A33_wU8(zT_95, (unsigned char)(0));
    zT_98 = s;
    zT_100 = bb->insts;
    zT_101 = zT_100.len;
    zF_FB050204_wU32(zT_98, (unsigned int)((unsigned int)zT_101));
    zT_103 = bb->insts;
    zT_104 = zT_103.len;
    if ((int)(zT_104 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_119 = src_fn.hoisted_temps;
    zT_120 = zT_119.len;
    if ((int)(zT_120 > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_118 = bi + (unsigned int)(1);
    bi = zT_118;
    goto z_bb_3;
    z_bb_7:
    zT_107 = s;
    zT_110 = bb->insts;
    zT_111 = zT_110.items;
    zT_113 = bb->insts;
    zT_114 = zT_113.len;
    zF_C2661A7D_wBytes(zT_107, (unsigned char*)((unsigned char*)zT_111), (unsigned int)(zT_114 * (unsigned int)(32)));
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_123 = s;
    zT_126 = src_fn.hoisted_temps;
    zT_127 = zT_126.items;
    zT_129 = src_fn.hoisted_temps;
    zT_130 = zT_129.len;
    zF_C2661A7D_wBytes(zT_123, (unsigned char*)((unsigned char*)zT_127), (unsigned int)(zT_130 * (unsigned int)(8)));
    goto z_bb_10;
    z_bb_10:
    zT_133 = src_fn.switch_cases;
    zT_134 = zT_133.len;
    if ((int)(zT_134 > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_137 = s;
    zT_140 = src_fn.switch_cases;
    zT_141 = zT_140.items;
    zT_143 = src_fn.switch_cases;
    zT_144 = zT_143.len;
    zF_C2661A7D_wBytes(zT_137, (unsigned char*)((unsigned char*)zT_141), (unsigned int)(zT_144 * (unsigned int)(16)));
    goto z_bb_12;
    z_bb_12:
    zT_147 = src_fn.side_table;
    zT_148 = zT_147.len;
    if ((int)(zT_148 > (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_151 = s;
    zT_154 = src_fn.side_table;
    zT_155 = zT_154.items;
    zT_157 = src_fn.side_table;
    zT_158 = zT_157.len;
    zF_C2661A7D_wBytes(zT_151, (unsigned char*)((unsigned char*)zT_155), (unsigned int)(zT_158 * (unsigned int)(28)));
    goto z_bb_14;
    z_bb_14:
    zT_161 = src_fn.temp_variant_sub_field;
    zT_162 = zT_161.capacity;
    if ((int)(zT_162 > (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_166 = src_fn.temp_variant_sub_field;
    zT_167 = zT_166.capacity;
    cap = zT_167;
    zT_168 = s;
    zT_171 = src_fn.temp_variant_sub_field;
    zT_172 = zT_171.keys;
    zF_C2661A7D_wBytes(zT_168, (unsigned char*)((unsigned char*)zT_172), (unsigned int)(cap * (unsigned int)(4)));
    zT_176 = s;
    zT_179 = src_fn.temp_variant_sub_field;
    zT_180 = zT_179.values;
    zF_C2661A7D_wBytes(zT_176, (unsigned char*)((unsigned char*)zT_180), (unsigned int)(cap * (unsigned int)(4)));
    zT_184 = s;
    zT_187 = src_fn.temp_variant_sub_field;
    zT_188 = zT_187.occupied;
    zF_C2661A7D_wBytes(zT_184, (unsigned char*)((unsigned char*)zT_188), (unsigned int)(cap * (unsigned int)(1)));
    goto z_bb_16;
    z_bb_16:
    zT_193 = s->write_offset;
    zT_194 = zT_193 - start;
    byte_len = zT_194;
    zT_196 = src_fn.module_id;
    zT_195.module_id = zT_196;
    zT_195.disk_offset = start;
    zT_195.byte_len = byte_len;
    return zT_195;
}

/* emptyLirFunction */
zT_BBC23664_LirFunction zF_FAE9AF21_emptyLirFunction(zT_3E40CD83_Sand* dst) {
    zT_BBC23664_LirFunction zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_CFE23D0A_LirParamArrayList zT_6 = {0};
    zT_3E40CD83_Sand* zT_7;
    zT_1CF28CA3_BasicBlockArrayList zT_8 = {0};
    zT_3E40CD83_Sand* zT_9;
    zT_5D72FBF8_TempDeclArrayList zT_10 = {0};
    zT_3E40CD83_Sand* zT_11;
    zT_9F514E82_SwitchCaseArrayList zT_12 = {0};
    zT_3E40CD83_Sand* zT_13;
    zT_AC00B5F6_LirSideEntryArrayLi zT_14 = {0};
    zT_3E40CD83_Sand* zT_15;
    zT_21D3708C_U32ToU32Map zT_16 = {0};
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    zT_2 = 0;
    zT_1.name_id = zT_2;
    zT_3 = 0;
    zT_1.module_id = zT_3;
    zT_4 = 0;
    zT_1.return_type = zT_4;
    zT_5 = dst;
    zT_6 = zF_0ED358C0_lirParamArrayListIn(zT_5);
    zT_1.params = zT_6;
    zT_7 = dst;
    zT_8 = zF_2B78727D_basicBlockArrayList(zT_7);
    zT_1.blocks = zT_8;
    zT_9 = dst;
    zT_10 = zF_DE63156A_tempDeclArrayListIn(zT_9);
    zT_1.hoisted_temps = zT_10;
    zT_11 = dst;
    zT_12 = zF_64707188_switchCaseArrayList(zT_11);
    zT_1.switch_cases = zT_12;
    zT_13 = dst;
    zT_14 = zF_4231AD2C_lirSideEntryArrayLi(zT_13);
    zT_1.side_table = zT_14;
    zT_15 = dst;
    zT_16 = zF_58BDA2DE_u32ToU32MapInit(zT_15);
    zT_1.temp_variant_sub_field = zT_16;
    zT_17 = 0;
    zT_1.is_extern = zT_17;
    zT_18 = 0;
    zT_1.is_pub = zT_18;
    zT_19 = 0;
    zT_1.is_variadic = zT_19;
    zT_20 = 0;
    zT_1.poison_uninit = zT_20;
    return zT_1;
}

/* lirStreamReadFunction */
zT_BBC23664_LirFunction zF_1B7118E0_lirStreamReadFuncti(zT_7E7544E4_LirStream* s, zT_E7714190_LirSlot slot, zT_3E40CD83_Sand* dst) {
    zT_3E40CD83_Sand* zT_3;
    zT_D21A8776_SpillStore* zT_4;
    unsigned int zT_5;
    zT_7E7544E4_LirStream* zT_9;
    unsigned int zT_10 = 0;
    zT_7E7544E4_LirStream* zT_12;
    unsigned int zT_13 = 0;
    zT_7E7544E4_LirStream* zT_15;
    unsigned int zT_16 = 0;
    zT_7E7544E4_LirStream* zT_18;
    unsigned char zT_19 = 0;
    zT_7E7544E4_LirStream* zT_21;
    unsigned char zT_22 = 0;
    zT_7E7544E4_LirStream* zT_24;
    unsigned char zT_25 = 0;
    zT_7E7544E4_LirStream* zT_27;
    unsigned char zT_28 = 0;
    zT_7E7544E4_LirStream* zT_30;
    unsigned int zT_31 = 0;
    zT_7E7544E4_LirStream* zT_33;
    unsigned int zT_34 = 0;
    zT_7E7544E4_LirStream* zT_36;
    unsigned int zT_37 = 0;
    zT_7E7544E4_LirStream* zT_39;
    unsigned int zT_40 = 0;
    zT_7E7544E4_LirStream* zT_42;
    unsigned int zT_43 = 0;
    zT_7E7544E4_LirStream* zT_45;
    unsigned int zT_46 = 0;
    zT_7E7544E4_LirStream* zT_48;
    unsigned int zT_49 = 0;
    unsigned int zT_51;
    unsigned int zT_54;
    unsigned int zT_57;
    unsigned int zT_60;
    unsigned int zT_63;
    unsigned int zT_66;
    unsigned int zT_71;
    zT_3E40CD83_Sand* zT_73;
    zT_CFE23D0A_LirParamArrayList zT_74 = {0};
    zT_3E40CD83_Sand* zT_78;
    zT_65F39959_EU_322 zT_85 = {0};
    unsigned char zT_86;
    unsigned char* zT_87;
    zT_7E7544E4_LirStream* zT_92;
    zT_8779209D_LirParam* zT_95;
    zT_3E40CD83_Sand* zT_101;
    zT_1CF28CA3_BasicBlockArrayList zT_102 = {0};
    zT_3E40CD83_Sand* zT_106;
    zT_65F39959_EU_322 zT_113 = {0};
    unsigned char zT_114;
    unsigned char* zT_115;
    zT_88A68B1A_BasicBlock* zT_118;
    unsigned int zT_122;
    zT_7E7544E4_LirStream* zT_126;
    unsigned int zT_127 = 0;
    zT_7E7544E4_LirStream* zT_129;
    unsigned char zT_130 = 0;
    zT_7E7544E4_LirStream* zT_131;
    unsigned char zT_132 = 0;
    zT_7E7544E4_LirStream* zT_133;
    unsigned char zT_134 = 0;
    zT_7E7544E4_LirStream* zT_135;
    unsigned char zT_136 = 0;
    zT_7E7544E4_LirStream* zT_138;
    unsigned int zT_139 = 0;
    unsigned int zT_142;
    zT_3E40CD83_Sand* zT_144;
    zT_DAE4631D_LirInstArrayList zT_145 = {0};
    zT_3E40CD83_Sand* zT_149;
    zT_65F39959_EU_322 zT_156 = {0};
    unsigned char zT_157;
    unsigned char* zT_158;
    zT_7E7544E4_LirStream* zT_163;
    zT_6BA597BC_LirInst* zT_166;
    zT_88A68B1A_BasicBlock zT_171;
    unsigned int zT_173;
    zT_3E40CD83_Sand* zT_175;
    zT_5D72FBF8_TempDeclArrayList zT_176 = {0};
    zT_3E40CD83_Sand* zT_180;
    zT_65F39959_EU_322 zT_187 = {0};
    unsigned char zT_188;
    unsigned char* zT_189;
    zT_7E7544E4_LirStream* zT_194;
    zT_1937645B_TempDecl* zT_197;
    zT_3E40CD83_Sand* zT_203;
    zT_9F514E82_SwitchCaseArrayList zT_204 = {0};
    zT_3E40CD83_Sand* zT_208;
    zT_65F39959_EU_322 zT_215 = {0};
    unsigned char zT_216;
    unsigned char* zT_217;
    zT_7E7544E4_LirStream* zT_222;
    zT_4BD97095_SwitchCase* zT_225;
    zT_3E40CD83_Sand* zT_231;
    zT_AC00B5F6_LirSideEntryArrayLi zT_232 = {0};
    zT_3E40CD83_Sand* zT_236;
    zT_65F39959_EU_322 zT_243 = {0};
    unsigned char zT_244;
    unsigned char* zT_245;
    zT_7E7544E4_LirStream* zT_250;
    zT_A8A5B231_LirSideEntry* zT_253;
    zT_3E40CD83_Sand* zT_259;
    zT_21D3708C_U32ToU32Map zT_260 = {0};
    unsigned int zT_264;
    zT_3E40CD83_Sand* zT_266;
    zT_65F39959_EU_322 zT_272 = {0};
    unsigned char zT_273;
    unsigned char* zT_274;
    zT_3E40CD83_Sand* zT_277;
    zT_65F39959_EU_322 zT_283 = {0};
    unsigned char zT_284;
    unsigned char* zT_285;
    zT_3E40CD83_Sand* zT_288;
    zT_65F39959_EU_322 zT_294 = {0};
    unsigned char zT_295;
    unsigned char* zT_296;
    zT_7E7544E4_LirStream* zT_302;
    unsigned int* zT_305;
    zT_7E7544E4_LirStream* zT_309;
    unsigned int* zT_312;
    zT_7E7544E4_LirStream* zT_316;
    unsigned char* zT_319;
    unsigned int zT_323;
    char* zT_326;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_327;
    unsigned int zT_328;
    char* zT_330;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_331;
    unsigned int zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    int zT_336;
    zT_3E40CD83_Sand* zT_338;
    zT_BBC23664_LirFunction zT_339 = {0};
    zT_BBC23664_LirFunction zT_340;
    unsigned int name_id;
    unsigned int module_id;
    unsigned int return_type;
    unsigned char is_extern;
    unsigned char is_pub;
    unsigned char is_variadic;
    unsigned char poison_uninit;
    unsigned int params_count;
    unsigned int blocks_count;
    unsigned int hoisted_temps_count;
    unsigned int switch_cases_count;
    unsigned int side_table_count;
    unsigned int tvsf_capacity;
    unsigned int tvsf_count;
    unsigned int expected_len;
    zT_CFE23D0A_LirParamArrayList params;
    unsigned char* raw;
    zT_1CF28CA3_BasicBlockArrayList blocks;
    unsigned char* braw;
    zT_5D72FBF8_TempDeclArrayList hoisted_temps;
    zT_88A68B1A_BasicBlock* bitems;
    unsigned int bi;
    unsigned int bb_id;
    unsigned char bb_term;
    unsigned int insts_count;
    zT_DAE4631D_LirInstArrayList binsts;
    unsigned char* iraw;
    zT_9F514E82_SwitchCaseArrayList switch_cases;
    zT_AC00B5F6_LirSideEntryArrayLi side_table;
    zT_21D3708C_U32ToU32Map tvsf;
    unsigned int cap;
    unsigned char* kraw;
    unsigned char* vraw;
    unsigned char* oraw;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = dst;
    zF_F1B3F8C2_sandReset(zT_3);
    zT_4 = &s->spill;
    zT_5 = slot.disk_offset;
    zF_56A911A9_spillSeek(zT_4, zT_5);
    zT_9 = s;
    zT_10 = zF_3E695161_rU32(zT_9);
    name_id = zT_10;
    zT_12 = s;
    zT_13 = zF_3E695161_rU32(zT_12);
    module_id = zT_13;
    zT_15 = s;
    zT_16 = zF_3E695161_rU32(zT_15);
    return_type = zT_16;
    zT_18 = s;
    zT_19 = zF_747E1168_rU8(zT_18);
    is_extern = zT_19;
    zT_21 = s;
    zT_22 = zF_747E1168_rU8(zT_21);
    is_pub = zT_22;
    zT_24 = s;
    zT_25 = zF_747E1168_rU8(zT_24);
    is_variadic = zT_25;
    zT_27 = s;
    zT_28 = zF_747E1168_rU8(zT_27);
    poison_uninit = zT_28;
    zT_30 = s;
    zT_31 = zF_3E695161_rU32(zT_30);
    params_count = zT_31;
    zT_33 = s;
    zT_34 = zF_3E695161_rU32(zT_33);
    blocks_count = zT_34;
    zT_36 = s;
    zT_37 = zF_3E695161_rU32(zT_36);
    hoisted_temps_count = zT_37;
    zT_39 = s;
    zT_40 = zF_3E695161_rU32(zT_39);
    switch_cases_count = zT_40;
    zT_42 = s;
    zT_43 = zF_3E695161_rU32(zT_42);
    side_table_count = zT_43;
    zT_45 = s;
    zT_46 = zF_3E695161_rU32(zT_45);
    tvsf_capacity = zT_46;
    zT_48 = s;
    zT_49 = zF_3E695161_rU32(zT_48);
    tvsf_count = zT_49;
    zT_51 = 44;
    expected_len = zT_51;
    zT_54 = expected_len + (unsigned int)(params_count * (unsigned int)(12));
    expected_len = zT_54;
    zT_57 = expected_len + (unsigned int)(blocks_count * (unsigned int)(12));
    expected_len = zT_57;
    zT_60 = expected_len + (unsigned int)(hoisted_temps_count * (unsigned int)(8));
    expected_len = zT_60;
    zT_63 = expected_len + (unsigned int)(switch_cases_count * (unsigned int)(16));
    expected_len = zT_63;
    zT_66 = expected_len + (unsigned int)(side_table_count * (unsigned int)(28));
    expected_len = zT_66;
    if ((int)(tvsf_capacity > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_71 = expected_len + (unsigned int)(tvsf_capacity * (unsigned int)(9));
    expected_len = zT_71;
    goto z_bb_2;
    z_bb_2:
    zT_73 = dst;
    zT_74 = zF_0ED358C0_lirParamArrayListIn(zT_73);
    params = zT_74;
    if ((int)(params_count > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_78 = dst;
    zT_85 = zF_1395EB68_sandAlloc(zT_78, (unsigned int)((unsigned int)((unsigned int)params_count) * (unsigned int)(12)), (unsigned int)(4));
    zT_86 = zT_85.is_error;
    if (zT_86) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_101 = dst;
    zT_102 = zF_2B78727D_basicBlockArrayList(zT_101);
    blocks = zT_102;
    if ((int)(blocks_count > (unsigned int)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_87 = zT_85.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_87;
    params.items = (zT_8779209D_LirParam*)((zT_8779209D_LirParam*)raw);
    params.len = (unsigned int)((unsigned int)params_count);
    params.capacity = (unsigned int)((unsigned int)params_count);
    zT_92 = s;
    zT_95 = params.items;
    zF_CF6758F4_rBytes(zT_92, (unsigned char*)((unsigned char*)zT_95), (unsigned int)((unsigned int)((unsigned int)params_count) * (unsigned int)(12)));
    goto z_bb_4;
    z_bb_8:
    zT_106 = dst;
    zT_113 = zF_1395EB68_sandAlloc(zT_106, (unsigned int)((unsigned int)((unsigned int)blocks_count) * (unsigned int)(24)), (unsigned int)(4));
    zT_114 = zT_113.is_error;
    if (zT_114) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_175 = dst;
    zT_176 = zF_DE63156A_tempDeclArrayListIn(zT_175);
    hoisted_temps = zT_176;
    if ((int)(hoisted_temps_count > (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_115 = zT_113.data.payload;
    goto z_bb_12;
    z_bb_12:
    braw = zT_115;
    zT_118 = (zT_88A68B1A_BasicBlock*)braw;
    bitems = zT_118;
    blocks.items = bitems;
    blocks.len = (unsigned int)((unsigned int)blocks_count);
    blocks.capacity = (unsigned int)((unsigned int)blocks_count);
    zT_122 = 0;
    bi = zT_122;
    goto z_bb_13;
    z_bb_13:
    if ((int)(bi < (unsigned int)((unsigned int)blocks_count))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_126 = s;
    zT_127 = zF_3E695161_rU32(zT_126);
    bb_id = zT_127;
    zT_129 = s;
    zT_130 = zF_747E1168_rU8(zT_129);
    bb_term = zT_130;
    zT_131 = s;
    zT_132 = zF_747E1168_rU8(zT_131);
    (void)zT_132;
    zT_133 = s;
    zT_134 = zF_747E1168_rU8(zT_133);
    (void)zT_134;
    zT_135 = s;
    zT_136 = zF_747E1168_rU8(zT_135);
    (void)zT_136;
    zT_138 = s;
    zT_139 = zF_3E695161_rU32(zT_138);
    insts_count = zT_139;
    zT_142 = expected_len + (unsigned int)(insts_count * (unsigned int)(32));
    expected_len = zT_142;
    zT_144 = dst;
    zT_145 = zF_C6E3B5BB_lirInstArrayListIni(zT_144);
    binsts = zT_145;
    if ((int)(insts_count > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_173 = bi + (unsigned int)(1);
    bi = zT_173;
    goto z_bb_13;
    z_bb_17:
    zT_149 = dst;
    zT_156 = zF_1395EB68_sandAlloc(zT_149, (unsigned int)((unsigned int)((unsigned int)insts_count) * (unsigned int)(32)), (unsigned int)(4));
    zT_157 = zT_156.is_error;
    if (zT_157) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_171.id = bb_id;
    zT_171.insts = binsts;
    zT_171.is_terminated = bb_term;
    bitems[bi] = zT_171;
    goto z_bb_16;
    z_bb_19:
    pal_trap();
    z_bb_20:
    zT_158 = zT_156.data.payload;
    goto z_bb_21;
    z_bb_21:
    iraw = zT_158;
    binsts.items = (zT_6BA597BC_LirInst*)((zT_6BA597BC_LirInst*)iraw);
    binsts.len = (unsigned int)((unsigned int)insts_count);
    binsts.capacity = (unsigned int)((unsigned int)insts_count);
    zT_163 = s;
    zT_166 = binsts.items;
    zF_CF6758F4_rBytes(zT_163, (unsigned char*)((unsigned char*)zT_166), (unsigned int)((unsigned int)((unsigned int)insts_count) * (unsigned int)(32)));
    goto z_bb_18;
    z_bb_22:
    zT_180 = dst;
    zT_187 = zF_1395EB68_sandAlloc(zT_180, (unsigned int)((unsigned int)((unsigned int)hoisted_temps_count) * (unsigned int)(8)), (unsigned int)(4));
    zT_188 = zT_187.is_error;
    if (zT_188) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_203 = dst;
    zT_204 = zF_64707188_switchCaseArrayList(zT_203);
    switch_cases = zT_204;
    if ((int)(switch_cases_count > (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    pal_trap();
    z_bb_25:
    zT_189 = zT_187.data.payload;
    goto z_bb_26;
    z_bb_26:
    raw = zT_189;
    hoisted_temps.items = (zT_1937645B_TempDecl*)((zT_1937645B_TempDecl*)raw);
    hoisted_temps.len = (unsigned int)((unsigned int)hoisted_temps_count);
    hoisted_temps.capacity = (unsigned int)((unsigned int)hoisted_temps_count);
    zT_194 = s;
    zT_197 = hoisted_temps.items;
    zF_CF6758F4_rBytes(zT_194, (unsigned char*)((unsigned char*)zT_197), (unsigned int)((unsigned int)((unsigned int)hoisted_temps_count) * (unsigned int)(8)));
    goto z_bb_23;
    z_bb_27:
    zT_208 = dst;
    zT_215 = zF_1395EB68_sandAlloc(zT_208, (unsigned int)((unsigned int)((unsigned int)switch_cases_count) * (unsigned int)(16)), (unsigned int)(4));
    zT_216 = zT_215.is_error;
    if (zT_216) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_231 = dst;
    zT_232 = zF_4231AD2C_lirSideEntryArrayLi(zT_231);
    side_table = zT_232;
    if ((int)(side_table_count > (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    pal_trap();
    z_bb_30:
    zT_217 = zT_215.data.payload;
    goto z_bb_31;
    z_bb_31:
    raw = zT_217;
    switch_cases.items = (zT_4BD97095_SwitchCase*)((zT_4BD97095_SwitchCase*)raw);
    switch_cases.len = (unsigned int)((unsigned int)switch_cases_count);
    switch_cases.capacity = (unsigned int)((unsigned int)switch_cases_count);
    zT_222 = s;
    zT_225 = switch_cases.items;
    zF_CF6758F4_rBytes(zT_222, (unsigned char*)((unsigned char*)zT_225), (unsigned int)((unsigned int)((unsigned int)switch_cases_count) * (unsigned int)(16)));
    goto z_bb_28;
    z_bb_32:
    zT_236 = dst;
    zT_243 = zF_1395EB68_sandAlloc(zT_236, (unsigned int)((unsigned int)((unsigned int)side_table_count) * (unsigned int)(28)), (unsigned int)(4));
    zT_244 = zT_243.is_error;
    if (zT_244) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_259 = dst;
    zT_260 = zF_58BDA2DE_u32ToU32MapInit(zT_259);
    tvsf = zT_260;
    if ((int)(tvsf_capacity > (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    pal_trap();
    z_bb_35:
    zT_245 = zT_243.data.payload;
    goto z_bb_36;
    z_bb_36:
    raw = zT_245;
    side_table.items = (zT_A8A5B231_LirSideEntry*)((zT_A8A5B231_LirSideEntry*)raw);
    side_table.len = (unsigned int)((unsigned int)side_table_count);
    side_table.capacity = (unsigned int)((unsigned int)side_table_count);
    zT_250 = s;
    zT_253 = side_table.items;
    zF_CF6758F4_rBytes(zT_250, (unsigned char*)((unsigned char*)zT_253), (unsigned int)((unsigned int)((unsigned int)side_table_count) * (unsigned int)(28)));
    goto z_bb_33;
    z_bb_37:
    zT_264 = (unsigned int)tvsf_capacity;
    cap = zT_264;
    zT_266 = dst;
    zT_272 = zF_1395EB68_sandAlloc(zT_266, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_273 = zT_272.is_error;
    if (zT_273) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_323 = slot.byte_len;
    if ((int)(expected_len != zT_323)) goto z_bb_48; else goto z_bb_49;
    z_bb_39:
    pal_trap();
    z_bb_40:
    zT_274 = zT_272.data.payload;
    goto z_bb_41;
    z_bb_41:
    kraw = zT_274;
    zT_277 = dst;
    zT_283 = zF_1395EB68_sandAlloc(zT_277, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_284 = zT_283.is_error;
    if (zT_284) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    pal_trap();
    z_bb_43:
    zT_285 = zT_283.data.payload;
    goto z_bb_44;
    z_bb_44:
    vraw = zT_285;
    zT_288 = dst;
    zT_294 = zF_1395EB68_sandAlloc(zT_288, (unsigned int)((unsigned int)(1) * cap), (unsigned int)(4));
    zT_295 = zT_294.is_error;
    if (zT_295) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    pal_trap();
    z_bb_46:
    zT_296 = zT_294.data.payload;
    goto z_bb_47;
    z_bb_47:
    oraw = zT_296;
    tvsf.keys = (unsigned int*)((unsigned int*)kraw);
    tvsf.values = (unsigned int*)((unsigned int*)vraw);
    tvsf.occupied = (unsigned char*)((unsigned char*)oraw);
    tvsf.capacity = cap;
    tvsf.count = (unsigned int)((unsigned int)tvsf_count);
    zT_302 = s;
    zT_305 = tvsf.keys;
    zF_CF6758F4_rBytes(zT_302, (unsigned char*)((unsigned char*)zT_305), (unsigned int)((unsigned int)(4) * cap));
    zT_309 = s;
    zT_312 = tvsf.values;
    zF_CF6758F4_rBytes(zT_309, (unsigned char*)((unsigned char*)zT_312), (unsigned int)((unsigned int)(4) * cap));
    zT_316 = s;
    zT_319 = tvsf.occupied;
    zF_CF6758F4_rBytes(zT_316, (unsigned char*)((unsigned char*)zT_319), (unsigned int)((unsigned int)(1) * cap));
    goto z_bb_38;
    z_bb_48:
    zT_326 = "S-LIR byte_len mismatch on fault-in read";
    zT_328 = 40;
    zT_327.ptr = zT_326;
    zT_327.len = zT_328;
    emsg = zT_327;
    zT_330 = "lir_stream.zig";
    zT_332 = 14;
    zT_331.ptr = zT_330;
    zT_331.len = zT_332;
    ef = zT_331;
    zT_333 = emsg;
    zT_334 = ef;
    zT_336 = 306;
    zF_6D97D338_panicHandler(zT_333, zT_334, (unsigned int)((unsigned int)zT_336));
    zT_338 = dst;
    zT_339 = zF_FAE9AF21_emptyLirFunction(zT_338);
    return zT_339;
    z_bb_49:
    zT_340.name_id = name_id;
    zT_340.module_id = module_id;
    zT_340.return_type = return_type;
    zT_340.params = params;
    zT_340.blocks = blocks;
    zT_340.hoisted_temps = hoisted_temps;
    zT_340.switch_cases = switch_cases;
    zT_340.side_table = side_table;
    zT_340.temp_variant_sub_field = tvsf;
    zT_340.is_extern = is_extern;
    zT_340.is_pub = is_pub;
    zT_340.is_variadic = is_variadic;
    zT_340.poison_uninit = poison_uninit;
    return zT_340;
}

/* __module_init */
void zF_780653D2___module_init_14(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_BBC23664_LirFunction zT_1 = {0};
    zT_E7714190_LirSlot zT_2 = {0};
    char* zT_3;
    char* zT_4;
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_E7714190_LirSlot = zT_2;
    zT_3 = "rb";
    zG_4417A8F5_READ_MODE = zT_3;
    zT_4 = "wb";
    zG_82B6E276_WRITE_MODE = zT_4;
    return;
}

/* EOF */
