#include "lir_stream_0760A6EE.h"
unsigned char* zG_4417A8F5_READ_MODE;
unsigned char* zG_82B6E276_WRITE_MODE;
/* lirStreamInit */
zT_7E7544E4_LirStream zF_E9CBFCA6_lirStreamInit(void) {
    zT_7E7544E4_LirStream zT_0;
    zT_D21A8776_SpillStore zT_1 = {0};
    unsigned int zT_2;
    unsigned int zT_3;
    zT_1 = zF_22C79E6C_spillStoreInit();
    zT_0.spill = zT_1;
    zT_2 = 0;
    zT_0.path_len = zT_2;
    zT_3 = 0;
    zT_0.write_offset = zT_3;
    return zT_0;
}

/* lirStreamBeginWrite */
void zF_B0B74E20_lirStreamBeginWrite(zT_7E7544E4_LirStream* s, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_8;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    zT_D21A8776_SpillStore* zT_19;
    zT_0426DCE7_SpillBackend zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_3E40CD83_Sand* zT_22;
    unsigned char* zT_23;
    zT_0426DCE7_SpillBackend zT_29 = 0;
    unsigned char* zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int i;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = path.len;
    if ((int)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_11 = path.ptr;
    zT_12 = zT_11[i];
    zT_13 = s->path;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    s->path_len = i;
    zT_16 = 0;
    zT_17 = s->path;
    zT_17[i] = zT_16;
    s->write_offset = (unsigned int)(0);
    zT_19 = &s->spill;
    zT_29 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_lir));
    zT_20 = zT_29;
    zT_30 = s->path;
    zT_31 = s->path_len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_21 = zT_35;
    zT_22 = alloc;
    zT_23 = zG_82B6E276_WRITE_MODE;
    zF_8AF94F71_spillOpen(zT_19, zT_20, zT_21, zT_22, zT_23);
    return;
    z_bb_4:
    zT_15 = i + (unsigned int)(1);
    i = zT_15;
    goto z_bb_1;
    z_bb_5:
    zT_8 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* lirStreamFinishWrite */
void zF_256E5B86_lirStreamFinishWrit(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_1 = &s->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* lirStreamBeginRead */
void zF_72DA7B39_lirStreamBeginRead(zT_7E7544E4_LirStream* s, zT_3E40CD83_Sand* alloc) {
    zT_D21A8776_SpillStore zT_2;
    zT_0426DCE7_SpillBackend zT_3;
    zT_D21A8776_SpillStore* zT_9;
    zT_D21A8776_SpillStore* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_3E40CD83_Sand* zT_13;
    unsigned char* zT_14;
    unsigned char* zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned char* zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_2 = s->spill;
    zT_3 = zT_2.backend;
    if ((int)(zT_3 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = &s->spill;
    zT_9->cur = (unsigned int)(0);
    return;
    z_bb_2:
    zT_10 = &s->spill;
    zT_19 = s->path;
    zT_20 = s->path_len;
    zT_21 = 0;
    zT_22 = zT_19 + zT_21;
    zT_23 = zT_20 - zT_21;
    zT_24.ptr = zT_22;
    zT_24.len = zT_23;
    zT_12 = zT_24;
    zT_13 = alloc;
    zT_14 = zG_4417A8F5_READ_MODE;
    zF_8AF94F71_spillOpen(zT_10, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_12, zT_13, zT_14);
    return;
}

/* lirStreamEndRead */
void zF_9427AE59_lirStreamEndRead(zT_7E7544E4_LirStream* s) {
    zT_D21A8776_SpillStore* zT_1;
    zT_1 = &s->spill;
    zF_DB2CDC3B_spillClose(zT_1);
    return;
}

/* wU32 */
void zF_FB050204_wU32(zT_7E7544E4_LirStream* s, unsigned int v) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_12;
    int zT_13;
    unsigned char zT_18;
    int zT_19;
    unsigned char zT_24;
    int zT_25;
    zT_D21A8776_SpillStore* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_6 = (unsigned char)(unsigned int)(v & (unsigned int)(255));
    zT_7 = 0;
    b[zT_7] = zT_6;
    zT_12 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255));
    zT_13 = 1;
    b[zT_13] = zT_12;
    zT_18 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255));
    zT_19 = 2;
    b[zT_19] = zT_18;
    zT_24 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255));
    zT_25 = 3;
    b[zT_25] = zT_24;
    zT_26 = &s->spill;
    zT_27 = s->write_offset;
    zT_33 = 0;
    zT_34 = (unsigned char*)((unsigned char*)b) + zT_33;
    zT_35 = (unsigned int)(4) - zT_33;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_28 = zT_36;
    zF_BFB33631_spillWriteAt(zT_26, zT_27, zT_28);
    zT_37 = s->write_offset;
    s->write_offset = (unsigned int)(zT_37 + (unsigned int)(4));
    return;
}

/* wU8 */
void zF_56013A33_wU8(zT_7E7544E4_LirStream* s, unsigned char v) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_3;
    int zT_4;
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_12;
    unsigned char* zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 0;
    b[zT_4] = v;
    zT_5 = &s->spill;
    zT_6 = s->write_offset;
    zT_12 = 0;
    zT_13 = (unsigned char*)((unsigned char*)b) + zT_12;
    zT_14 = (unsigned int)(1) - zT_12;
    zT_15.ptr = zT_13;
    zT_15.len = zT_14;
    zT_7 = zT_15;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_16 = s->write_offset;
    s->write_offset = (unsigned int)(zT_16 + (unsigned int)(1));
    return;
}

/* wBytes */
void zF_C2661A7D_wBytes(zT_7E7544E4_LirStream* s, unsigned char* ptr, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    if ((int)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &s->spill;
    zT_6 = s->write_offset;
    zT_10 = 0;
    zT_11 = ptr + zT_10;
    zT_12 = len - zT_10;
    zT_13.ptr = zT_11;
    zT_13.len = zT_12;
    zT_7 = zT_13;
    zF_BFB33631_spillWriteAt(zT_5, zT_6, zT_7);
    zT_14 = s->write_offset;
    s->write_offset = (unsigned int)(zT_14 + (unsigned int)((unsigned int)len));
    return;
}

/* rU32 */
unsigned int zF_3E695161_rU32(zT_7E7544E4_LirStream* s) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore zT_7;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_16;
    int zT_17;
    unsigned char zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned char zT_22;
    unsigned int zT_26;
    int zT_27;
    unsigned char zT_28;
    unsigned int zT_32;
    int zT_33;
    unsigned char zT_34;
    unsigned int zT_38;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    unsigned int v;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = &s->spill;
    zT_7 = s->spill;
    zT_4 = zT_7.cur;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(4) - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_16 = 0;
    v = zT_16;
    zT_17 = 0;
    zT_18 = b[zT_17];
    zT_20 = v | (unsigned int)((unsigned int)zT_18);
    v = zT_20;
    zT_21 = 1;
    zT_22 = b[zT_21];
    zT_26 = v | (unsigned int)((unsigned int)((unsigned int)zT_22) << (unsigned int)(8));
    v = zT_26;
    zT_27 = 2;
    zT_28 = b[zT_27];
    zT_32 = v | (unsigned int)((unsigned int)((unsigned int)zT_28) << (unsigned int)(16));
    v = zT_32;
    zT_33 = 3;
    zT_34 = b[zT_33];
    zT_38 = v | (unsigned int)((unsigned int)((unsigned int)zT_34) << (unsigned int)(24));
    v = zT_38;
    return v;
}

/* rU8 */
unsigned char zF_747E1168_rU8(zT_7E7544E4_LirStream* s) {
    zT_BAAAF94F_Arr_unsigned_char_1 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_D21A8776_SpillStore zT_7;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_15;
    unsigned char zT_16;
    zT_BAAAF94F_Arr_unsigned_char_1 b;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 1) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = &s->spill;
    zT_7 = s->spill;
    zT_4 = zT_7.cur;
    zT_11 = 0;
    zT_12 = (unsigned char*)((unsigned char*)b) + zT_11;
    zT_13 = (unsigned int)(1) - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_5 = zT_14;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_15 = 0;
    zT_16 = b[zT_15];
    return zT_16;
}

/* rBytes */
void zF_CF6758F4_rBytes(zT_7E7544E4_LirStream* s, unsigned char* dst, unsigned int len) {
    zT_D21A8776_SpillStore* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_D21A8776_SpillStore zT_9;
    int zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    if ((int)(len == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &s->spill;
    zT_9 = s->spill;
    zT_6 = zT_9.cur;
    zT_11 = 0;
    zT_12 = dst + zT_11;
    zT_13 = len - zT_11;
    zT_14.ptr = zT_12;
    zT_14.len = zT_13;
    zT_7 = zT_14;
    zF_E9F67450_spillReadAt(zT_5, zT_6, zT_7);
    return;
}

/* lirStreamAppend */
zT_E7714190_LirSlot zF_9F47D5E4_lirStreamAppend(zT_7E7544E4_LirStream* s, zT_BBC23664_LirFunction src_fn) {
    unsigned int zT_3;
    zT_7E7544E4_LirStream* zT_4;
    unsigned int zT_5;
    zT_7E7544E4_LirStream* zT_7;
    unsigned int zT_8;
    zT_7E7544E4_LirStream* zT_10;
    unsigned int zT_11;
    zT_7E7544E4_LirStream* zT_13;
    unsigned char zT_14;
    zT_7E7544E4_LirStream* zT_16;
    unsigned char zT_17;
    zT_7E7544E4_LirStream* zT_19;
    unsigned char zT_20;
    zT_7E7544E4_LirStream* zT_22;
    unsigned char zT_23;
    zT_7E7544E4_LirStream* zT_25;
    unsigned char zT_26;
    zT_7E7544E4_LirStream* zT_28;
    zT_CFE23D0A_LirParamArrayList zT_30;
    unsigned int zT_31;
    zT_7E7544E4_LirStream* zT_33;
    zT_1CF28CA3_BasicBlockArrayList zT_35;
    unsigned int zT_36;
    zT_7E7544E4_LirStream* zT_38;
    zT_5D72FBF8_TempDeclArrayList zT_40;
    unsigned int zT_41;
    zT_7E7544E4_LirStream* zT_43;
    zT_9F514E82_SwitchCaseArrayList zT_45;
    unsigned int zT_46;
    zT_7E7544E4_LirStream* zT_48;
    zT_AC00B5F6_LirSideEntryArrayLi zT_50;
    unsigned int zT_51;
    zT_7E7544E4_LirStream* zT_53;
    zT_21D3708C_U32ToU32Map zT_55;
    unsigned int zT_56;
    zT_7E7544E4_LirStream* zT_58;
    zT_21D3708C_U32ToU32Map zT_60;
    unsigned int zT_61;
    zT_CFE23D0A_LirParamArrayList zT_63;
    unsigned int zT_64;
    zT_7E7544E4_LirStream* zT_67;
    zT_CFE23D0A_LirParamArrayList zT_70;
    zT_8779209D_LirParam* zT_71;
    zT_CFE23D0A_LirParamArrayList zT_73;
    unsigned int zT_74;
    unsigned int zT_78;
    zT_1CF28CA3_BasicBlockArrayList zT_79;
    unsigned int zT_80;
    zT_1CF28CA3_BasicBlockArrayList zT_83;
    zT_88A68B1A_BasicBlock* zT_84;
    zT_88A68B1A_BasicBlock* zT_85;
    zT_7E7544E4_LirStream* zT_86;
    unsigned int zT_87;
    zT_7E7544E4_LirStream* zT_89;
    unsigned char zT_90;
    zT_7E7544E4_LirStream* zT_92;
    zT_7E7544E4_LirStream* zT_95;
    zT_7E7544E4_LirStream* zT_98;
    zT_7E7544E4_LirStream* zT_101;
    zT_DAE4631D_LirInstArrayList zT_103;
    unsigned int zT_104;
    zT_DAE4631D_LirInstArrayList zT_106;
    unsigned int zT_107;
    zT_7E7544E4_LirStream* zT_110;
    zT_DAE4631D_LirInstArrayList zT_113;
    zT_6BA597BC_LirInst* zT_114;
    zT_DAE4631D_LirInstArrayList zT_116;
    unsigned int zT_117;
    unsigned int zT_121;
    zT_5D72FBF8_TempDeclArrayList zT_122;
    unsigned int zT_123;
    zT_7E7544E4_LirStream* zT_126;
    zT_5D72FBF8_TempDeclArrayList zT_129;
    zT_1937645B_TempDecl* zT_130;
    zT_5D72FBF8_TempDeclArrayList zT_132;
    unsigned int zT_133;
    zT_9F514E82_SwitchCaseArrayList zT_136;
    unsigned int zT_137;
    zT_7E7544E4_LirStream* zT_140;
    zT_9F514E82_SwitchCaseArrayList zT_143;
    zT_4BD97095_SwitchCase* zT_144;
    zT_9F514E82_SwitchCaseArrayList zT_146;
    unsigned int zT_147;
    zT_AC00B5F6_LirSideEntryArrayLi zT_150;
    unsigned int zT_151;
    zT_7E7544E4_LirStream* zT_154;
    zT_AC00B5F6_LirSideEntryArrayLi zT_157;
    zT_A8A5B231_LirSideEntry* zT_158;
    zT_AC00B5F6_LirSideEntryArrayLi zT_160;
    unsigned int zT_161;
    zT_21D3708C_U32ToU32Map zT_164;
    unsigned int zT_165;
    zT_21D3708C_U32ToU32Map zT_169;
    unsigned int zT_170;
    zT_7E7544E4_LirStream* zT_171;
    zT_21D3708C_U32ToU32Map zT_174;
    unsigned int* zT_175;
    zT_7E7544E4_LirStream* zT_179;
    zT_21D3708C_U32ToU32Map zT_182;
    unsigned int* zT_183;
    zT_7E7544E4_LirStream* zT_187;
    zT_21D3708C_U32ToU32Map zT_190;
    unsigned char* zT_191;
    unsigned int zT_196;
    unsigned int zT_197;
    zT_E7714190_LirSlot zT_198;
    unsigned int zT_199;
    unsigned int start;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int cap;
    unsigned int byte_len;
    zT_3 = s->write_offset;
    start = zT_3;
    zT_4 = s;
    zT_5 = src_fn.name_id;
    zF_FB050204_wU32(zT_4, zT_5);
    zT_7 = s;
    zT_8 = src_fn.module_id;
    zF_FB050204_wU32(zT_7, zT_8);
    zT_10 = s;
    zT_11 = src_fn.return_type;
    zF_FB050204_wU32(zT_10, zT_11);
    zT_13 = s;
    zT_14 = src_fn.is_extern;
    zF_56013A33_wU8(zT_13, zT_14);
    zT_16 = s;
    zT_17 = src_fn.is_pub;
    zF_56013A33_wU8(zT_16, zT_17);
    zT_19 = s;
    zT_20 = src_fn.is_variadic;
    zF_56013A33_wU8(zT_19, zT_20);
    zT_22 = s;
    zT_23 = src_fn.call_conv;
    zF_56013A33_wU8(zT_22, zT_23);
    zT_25 = s;
    zT_26 = src_fn.poison_uninit;
    zF_56013A33_wU8(zT_25, zT_26);
    zT_28 = s;
    zT_30 = src_fn.params;
    zT_31 = zT_30.len;
    zF_FB050204_wU32(zT_28, (unsigned int)((unsigned int)zT_31));
    zT_33 = s;
    zT_35 = src_fn.blocks;
    zT_36 = zT_35.len;
    zF_FB050204_wU32(zT_33, (unsigned int)((unsigned int)zT_36));
    zT_38 = s;
    zT_40 = src_fn.hoisted_temps;
    zT_41 = zT_40.len;
    zF_FB050204_wU32(zT_38, (unsigned int)((unsigned int)zT_41));
    zT_43 = s;
    zT_45 = src_fn.switch_cases;
    zT_46 = zT_45.len;
    zF_FB050204_wU32(zT_43, (unsigned int)((unsigned int)zT_46));
    zT_48 = s;
    zT_50 = src_fn.side_table;
    zT_51 = zT_50.len;
    zF_FB050204_wU32(zT_48, (unsigned int)((unsigned int)zT_51));
    zT_53 = s;
    zT_55 = src_fn.temp_variant_sub_field;
    zT_56 = zT_55.capacity;
    zF_FB050204_wU32(zT_53, (unsigned int)((unsigned int)zT_56));
    zT_58 = s;
    zT_60 = src_fn.temp_variant_sub_field;
    zT_61 = zT_60.count;
    zF_FB050204_wU32(zT_58, (unsigned int)((unsigned int)zT_61));
    zT_63 = src_fn.params;
    zT_64 = zT_63.len;
    if ((int)(zT_64 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_67 = s;
    zT_70 = src_fn.params;
    zT_71 = zT_70.items;
    zT_73 = src_fn.params;
    zT_74 = zT_73.len;
    zF_C2661A7D_wBytes(zT_67, (unsigned char*)((unsigned char*)zT_71), (unsigned int)(zT_74 * (unsigned int)(12)));
    goto z_bb_2;
    z_bb_2:
    zT_78 = 0;
    bi = zT_78;
    goto z_bb_3;
    z_bb_3:
    zT_79 = src_fn.blocks;
    zT_80 = zT_79.len;
    if ((int)(bi < zT_80)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_83 = src_fn.blocks;
    zT_84 = zT_83.items;
    zT_85 = zT_84 + bi;
    bb = zT_85;
    zT_86 = s;
    zT_87 = bb->id;
    zF_FB050204_wU32(zT_86, zT_87);
    zT_89 = s;
    zT_90 = bb->is_terminated;
    zF_56013A33_wU8(zT_89, zT_90);
    zT_92 = s;
    zF_56013A33_wU8(zT_92, (unsigned char)(0));
    zT_95 = s;
    zF_56013A33_wU8(zT_95, (unsigned char)(0));
    zT_98 = s;
    zF_56013A33_wU8(zT_98, (unsigned char)(0));
    zT_101 = s;
    zT_103 = bb->insts;
    zT_104 = zT_103.len;
    zF_FB050204_wU32(zT_101, (unsigned int)((unsigned int)zT_104));
    zT_106 = bb->insts;
    zT_107 = zT_106.len;
    if ((int)(zT_107 > (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_122 = src_fn.hoisted_temps;
    zT_123 = zT_122.len;
    if ((int)(zT_123 > (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_6:
    zT_121 = bi + (unsigned int)(1);
    bi = zT_121;
    goto z_bb_3;
    z_bb_7:
    zT_110 = s;
    zT_113 = bb->insts;
    zT_114 = zT_113.items;
    zT_116 = bb->insts;
    zT_117 = zT_116.len;
    zF_C2661A7D_wBytes(zT_110, (unsigned char*)((unsigned char*)zT_114), (unsigned int)(zT_117 * (unsigned int)(32)));
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_126 = s;
    zT_129 = src_fn.hoisted_temps;
    zT_130 = zT_129.items;
    zT_132 = src_fn.hoisted_temps;
    zT_133 = zT_132.len;
    zF_C2661A7D_wBytes(zT_126, (unsigned char*)((unsigned char*)zT_130), (unsigned int)(zT_133 * (unsigned int)(8)));
    goto z_bb_10;
    z_bb_10:
    zT_136 = src_fn.switch_cases;
    zT_137 = zT_136.len;
    if ((int)(zT_137 > (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_140 = s;
    zT_143 = src_fn.switch_cases;
    zT_144 = zT_143.items;
    zT_146 = src_fn.switch_cases;
    zT_147 = zT_146.len;
    zF_C2661A7D_wBytes(zT_140, (unsigned char*)((unsigned char*)zT_144), (unsigned int)(zT_147 * (unsigned int)(16)));
    goto z_bb_12;
    z_bb_12:
    zT_150 = src_fn.side_table;
    zT_151 = zT_150.len;
    if ((int)(zT_151 > (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_154 = s;
    zT_157 = src_fn.side_table;
    zT_158 = zT_157.items;
    zT_160 = src_fn.side_table;
    zT_161 = zT_160.len;
    zF_C2661A7D_wBytes(zT_154, (unsigned char*)((unsigned char*)zT_158), (unsigned int)(zT_161 * (unsigned int)(28)));
    goto z_bb_14;
    z_bb_14:
    zT_164 = src_fn.temp_variant_sub_field;
    zT_165 = zT_164.capacity;
    if ((int)(zT_165 > (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_169 = src_fn.temp_variant_sub_field;
    zT_170 = zT_169.capacity;
    cap = zT_170;
    zT_171 = s;
    zT_174 = src_fn.temp_variant_sub_field;
    zT_175 = zT_174.keys;
    zF_C2661A7D_wBytes(zT_171, (unsigned char*)((unsigned char*)zT_175), (unsigned int)(cap * (unsigned int)(4)));
    zT_179 = s;
    zT_182 = src_fn.temp_variant_sub_field;
    zT_183 = zT_182.values;
    zF_C2661A7D_wBytes(zT_179, (unsigned char*)((unsigned char*)zT_183), (unsigned int)(cap * (unsigned int)(4)));
    zT_187 = s;
    zT_190 = src_fn.temp_variant_sub_field;
    zT_191 = zT_190.occupied;
    zF_C2661A7D_wBytes(zT_187, (unsigned char*)((unsigned char*)zT_191), (unsigned int)(cap * (unsigned int)(1)));
    goto z_bb_16;
    z_bb_16:
    zT_196 = s->write_offset;
    zT_197 = zT_196 - start;
    byte_len = zT_197;
    zT_199 = src_fn.module_id;
    zT_198.module_id = zT_199;
    zT_198.disk_offset = start;
    zT_198.byte_len = byte_len;
    return zT_198;
}

/* emptyLirFunction */
zT_BBC23664_LirFunction zF_FAE9AF21_emptyLirFunction(zT_3E40CD83_Sand* dst) {
    zT_BBC23664_LirFunction zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_CFE23D0A_LirParamArrayList zT_6 = {0};
    zT_3E40CD83_Sand* zT_7;
    zT_1CF28CA3_BasicBlockArrayList zT_8 = {0};
    zT_3E40CD83_Sand* zT_9;
    zT_5D72FBF8_TempDeclArrayList zT_10 = {0};
    zT_3E40CD83_Sand* zT_11;
    zT_9F514E82_SwitchCaseArrayList zT_12 = {0};
    zT_3E40CD83_Sand* zT_13;
    zT_AC00B5F6_LirSideEntryArrayLi zT_14 = {0};
    zT_3E40CD83_Sand* zT_15;
    zT_21D3708C_U32ToU32Map zT_16 = {0};
    unsigned char zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    unsigned char zT_20;
    unsigned char zT_21;
    zT_2 = 0;
    zT_1.name_id = zT_2;
    zT_3 = 0;
    zT_1.module_id = zT_3;
    zT_4 = 0;
    zT_1.return_type = zT_4;
    zT_5 = dst;
    zT_6 = zF_0ED358C0_lirParamArrayListIn(zT_5);
    zT_1.params = zT_6;
    zT_7 = dst;
    zT_8 = zF_2B78727D_basicBlockArrayList(zT_7);
    zT_1.blocks = zT_8;
    zT_9 = dst;
    zT_10 = zF_DE63156A_tempDeclArrayListIn(zT_9);
    zT_1.hoisted_temps = zT_10;
    zT_11 = dst;
    zT_12 = zF_64707188_switchCaseArrayList(zT_11);
    zT_1.switch_cases = zT_12;
    zT_13 = dst;
    zT_14 = zF_4231AD2C_lirSideEntryArrayLi(zT_13);
    zT_1.side_table = zT_14;
    zT_15 = dst;
    zT_16 = zF_58BDA2DE_u32ToU32MapInit(zT_15);
    zT_1.temp_variant_sub_field = zT_16;
    zT_17 = 0;
    zT_1.is_extern = zT_17;
    zT_18 = 0;
    zT_1.is_pub = zT_18;
    zT_19 = 0;
    zT_1.is_variadic = zT_19;
    zT_20 = 0;
    zT_1.call_conv = zT_20;
    zT_21 = 0;
    zT_1.poison_uninit = zT_21;
    return zT_1;
}

/* lirStreamReadFunction */
zT_BBC23664_LirFunction zF_1B7118E0_lirStreamReadFuncti(zT_7E7544E4_LirStream* s, zT_E7714190_LirSlot slot, zT_3E40CD83_Sand* dst) {
    zT_3E40CD83_Sand* zT_3;
    zT_D21A8776_SpillStore* zT_4;
    unsigned int zT_5;
    zT_7E7544E4_LirStream* zT_9;
    unsigned int zT_10 = 0;
    zT_7E7544E4_LirStream* zT_12;
    unsigned int zT_13 = 0;
    zT_7E7544E4_LirStream* zT_15;
    unsigned int zT_16 = 0;
    zT_7E7544E4_LirStream* zT_18;
    unsigned char zT_19 = 0;
    zT_7E7544E4_LirStream* zT_21;
    unsigned char zT_22 = 0;
    zT_7E7544E4_LirStream* zT_24;
    unsigned char zT_25 = 0;
    zT_7E7544E4_LirStream* zT_27;
    unsigned char zT_28 = 0;
    zT_7E7544E4_LirStream* zT_30;
    unsigned char zT_31 = 0;
    zT_7E7544E4_LirStream* zT_33;
    unsigned int zT_34 = 0;
    zT_7E7544E4_LirStream* zT_36;
    unsigned int zT_37 = 0;
    zT_7E7544E4_LirStream* zT_39;
    unsigned int zT_40 = 0;
    zT_7E7544E4_LirStream* zT_42;
    unsigned int zT_43 = 0;
    zT_7E7544E4_LirStream* zT_45;
    unsigned int zT_46 = 0;
    zT_7E7544E4_LirStream* zT_48;
    unsigned int zT_49 = 0;
    zT_7E7544E4_LirStream* zT_51;
    unsigned int zT_52 = 0;
    unsigned int zT_54;
    unsigned int zT_57;
    unsigned int zT_60;
    unsigned int zT_63;
    unsigned int zT_66;
    unsigned int zT_69;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_76;
    zT_CFE23D0A_LirParamArrayList zT_77 = {0};
    zT_3E40CD83_Sand* zT_81;
    zT_9154F007_EU_232 zT_88 = {0};
    unsigned char zT_89;
    unsigned char* zT_90;
    zT_7E7544E4_LirStream* zT_95;
    zT_8779209D_LirParam* zT_98;
    zT_3E40CD83_Sand* zT_104;
    zT_1CF28CA3_BasicBlockArrayList zT_105 = {0};
    zT_3E40CD83_Sand* zT_109;
    zT_9154F007_EU_232 zT_116 = {0};
    unsigned char zT_117;
    unsigned char* zT_118;
    zT_88A68B1A_BasicBlock* zT_121;
    unsigned int zT_125;
    zT_7E7544E4_LirStream* zT_129;
    unsigned int zT_130 = 0;
    zT_7E7544E4_LirStream* zT_132;
    unsigned char zT_133 = 0;
    zT_7E7544E4_LirStream* zT_134;
    unsigned char zT_135 = 0;
    zT_7E7544E4_LirStream* zT_136;
    unsigned char zT_137 = 0;
    zT_7E7544E4_LirStream* zT_138;
    unsigned char zT_139 = 0;
    zT_7E7544E4_LirStream* zT_141;
    unsigned int zT_142 = 0;
    unsigned int zT_145;
    zT_3E40CD83_Sand* zT_147;
    zT_DAE4631D_LirInstArrayList zT_148 = {0};
    zT_3E40CD83_Sand* zT_152;
    zT_9154F007_EU_232 zT_159 = {0};
    unsigned char zT_160;
    unsigned char* zT_161;
    zT_7E7544E4_LirStream* zT_166;
    zT_6BA597BC_LirInst* zT_169;
    zT_88A68B1A_BasicBlock zT_174;
    unsigned int zT_176;
    zT_3E40CD83_Sand* zT_178;
    zT_5D72FBF8_TempDeclArrayList zT_179 = {0};
    zT_3E40CD83_Sand* zT_183;
    zT_9154F007_EU_232 zT_190 = {0};
    unsigned char zT_191;
    unsigned char* zT_192;
    zT_7E7544E4_LirStream* zT_197;
    zT_1937645B_TempDecl* zT_200;
    zT_3E40CD83_Sand* zT_206;
    zT_9F514E82_SwitchCaseArrayList zT_207 = {0};
    zT_3E40CD83_Sand* zT_211;
    zT_9154F007_EU_232 zT_218 = {0};
    unsigned char zT_219;
    unsigned char* zT_220;
    zT_7E7544E4_LirStream* zT_225;
    zT_4BD97095_SwitchCase* zT_228;
    zT_3E40CD83_Sand* zT_234;
    zT_AC00B5F6_LirSideEntryArrayLi zT_235 = {0};
    zT_3E40CD83_Sand* zT_239;
    zT_9154F007_EU_232 zT_246 = {0};
    unsigned char zT_247;
    unsigned char* zT_248;
    zT_7E7544E4_LirStream* zT_253;
    zT_A8A5B231_LirSideEntry* zT_256;
    zT_3E40CD83_Sand* zT_262;
    zT_21D3708C_U32ToU32Map zT_263 = {0};
    unsigned int zT_267;
    zT_3E40CD83_Sand* zT_269;
    zT_9154F007_EU_232 zT_275 = {0};
    unsigned char zT_276;
    unsigned char* zT_277;
    zT_3E40CD83_Sand* zT_280;
    zT_9154F007_EU_232 zT_286 = {0};
    unsigned char zT_287;
    unsigned char* zT_288;
    zT_3E40CD83_Sand* zT_291;
    zT_9154F007_EU_232 zT_297 = {0};
    unsigned char zT_298;
    unsigned char* zT_299;
    zT_7E7544E4_LirStream* zT_305;
    unsigned int* zT_308;
    zT_7E7544E4_LirStream* zT_312;
    unsigned int* zT_315;
    zT_7E7544E4_LirStream* zT_319;
    unsigned char* zT_322;
    unsigned int zT_326;
    char* zT_329;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_330;
    unsigned int zT_331;
    char* zT_333;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_334;
    unsigned int zT_335;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_336;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_337;
    int zT_339;
    zT_3E40CD83_Sand* zT_341;
    zT_BBC23664_LirFunction zT_342 = {0};
    zT_BBC23664_LirFunction zT_343;
    unsigned int name_id;
    unsigned int module_id;
    unsigned int return_type;
    unsigned char is_extern;
    unsigned char is_pub;
    unsigned char is_variadic;
    unsigned char call_conv;
    unsigned char poison_uninit;
    unsigned int params_count;
    unsigned int blocks_count;
    unsigned int hoisted_temps_count;
    unsigned int switch_cases_count;
    unsigned int side_table_count;
    unsigned int tvsf_capacity;
    unsigned int tvsf_count;
    unsigned int expected_len;
    zT_CFE23D0A_LirParamArrayList params;
    unsigned char* raw;
    zT_1CF28CA3_BasicBlockArrayList blocks;
    unsigned char* braw;
    zT_5D72FBF8_TempDeclArrayList hoisted_temps;
    zT_88A68B1A_BasicBlock* bitems;
    unsigned int bi;
    unsigned int bb_id;
    unsigned char bb_term;
    unsigned int insts_count;
    zT_DAE4631D_LirInstArrayList binsts;
    unsigned char* iraw;
    zT_9F514E82_SwitchCaseArrayList switch_cases;
    zT_AC00B5F6_LirSideEntryArrayLi side_table;
    zT_21D3708C_U32ToU32Map tvsf;
    unsigned int cap;
    unsigned char* kraw;
    unsigned char* vraw;
    unsigned char* oraw;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = dst;
    zF_F1B3F8C2_sandReset(zT_3);
    zT_4 = &s->spill;
    zT_5 = slot.disk_offset;
    zF_56A911A9_spillSeek(zT_4, zT_5);
    zT_9 = s;
    zT_10 = zF_3E695161_rU32(zT_9);
    name_id = zT_10;
    zT_12 = s;
    zT_13 = zF_3E695161_rU32(zT_12);
    module_id = zT_13;
    zT_15 = s;
    zT_16 = zF_3E695161_rU32(zT_15);
    return_type = zT_16;
    zT_18 = s;
    zT_19 = zF_747E1168_rU8(zT_18);
    is_extern = zT_19;
    zT_21 = s;
    zT_22 = zF_747E1168_rU8(zT_21);
    is_pub = zT_22;
    zT_24 = s;
    zT_25 = zF_747E1168_rU8(zT_24);
    is_variadic = zT_25;
    zT_27 = s;
    zT_28 = zF_747E1168_rU8(zT_27);
    call_conv = zT_28;
    zT_30 = s;
    zT_31 = zF_747E1168_rU8(zT_30);
    poison_uninit = zT_31;
    zT_33 = s;
    zT_34 = zF_3E695161_rU32(zT_33);
    params_count = zT_34;
    zT_36 = s;
    zT_37 = zF_3E695161_rU32(zT_36);
    blocks_count = zT_37;
    zT_39 = s;
    zT_40 = zF_3E695161_rU32(zT_39);
    hoisted_temps_count = zT_40;
    zT_42 = s;
    zT_43 = zF_3E695161_rU32(zT_42);
    switch_cases_count = zT_43;
    zT_45 = s;
    zT_46 = zF_3E695161_rU32(zT_45);
    side_table_count = zT_46;
    zT_48 = s;
    zT_49 = zF_3E695161_rU32(zT_48);
    tvsf_capacity = zT_49;
    zT_51 = s;
    zT_52 = zF_3E695161_rU32(zT_51);
    tvsf_count = zT_52;
    zT_54 = 45;
    expected_len = zT_54;
    zT_57 = expected_len + (unsigned int)(params_count * (unsigned int)(12));
    expected_len = zT_57;
    zT_60 = expected_len + (unsigned int)(blocks_count * (unsigned int)(12));
    expected_len = zT_60;
    zT_63 = expected_len + (unsigned int)(hoisted_temps_count * (unsigned int)(8));
    expected_len = zT_63;
    zT_66 = expected_len + (unsigned int)(switch_cases_count * (unsigned int)(16));
    expected_len = zT_66;
    zT_69 = expected_len + (unsigned int)(side_table_count * (unsigned int)(28));
    expected_len = zT_69;
    if ((int)(tvsf_capacity > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_74 = expected_len + (unsigned int)(tvsf_capacity * (unsigned int)(9));
    expected_len = zT_74;
    goto z_bb_2;
    z_bb_2:
    zT_76 = dst;
    zT_77 = zF_0ED358C0_lirParamArrayListIn(zT_76);
    params = zT_77;
    if ((int)(params_count > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_81 = dst;
    zT_88 = zF_1395EB68_sandAlloc(zT_81, (unsigned int)((unsigned int)((unsigned int)params_count) * (unsigned int)(12)), (unsigned int)(4));
    zT_89 = zT_88.is_error;
    if (zT_89) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_104 = dst;
    zT_105 = zF_2B78727D_basicBlockArrayList(zT_104);
    blocks = zT_105;
    if ((int)(blocks_count > (unsigned int)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_90 = zT_88.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_90;
    params.items = (zT_8779209D_LirParam*)((zT_8779209D_LirParam*)raw);
    params.len = (unsigned int)((unsigned int)params_count);
    params.capacity = (unsigned int)((unsigned int)params_count);
    zT_95 = s;
    zT_98 = params.items;
    zF_CF6758F4_rBytes(zT_95, (unsigned char*)((unsigned char*)zT_98), (unsigned int)((unsigned int)((unsigned int)params_count) * (unsigned int)(12)));
    goto z_bb_4;
    z_bb_8:
    zT_109 = dst;
    zT_116 = zF_1395EB68_sandAlloc(zT_109, (unsigned int)((unsigned int)((unsigned int)blocks_count) * (unsigned int)(24)), (unsigned int)(4));
    zT_117 = zT_116.is_error;
    if (zT_117) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_178 = dst;
    zT_179 = zF_DE63156A_tempDeclArrayListIn(zT_178);
    hoisted_temps = zT_179;
    if ((int)(hoisted_temps_count > (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_118 = zT_116.data.payload;
    goto z_bb_12;
    z_bb_12:
    braw = zT_118;
    zT_121 = (zT_88A68B1A_BasicBlock*)braw;
    bitems = zT_121;
    blocks.items = bitems;
    blocks.len = (unsigned int)((unsigned int)blocks_count);
    blocks.capacity = (unsigned int)((unsigned int)blocks_count);
    zT_125 = 0;
    bi = zT_125;
    goto z_bb_13;
    z_bb_13:
    if ((int)(bi < (unsigned int)((unsigned int)blocks_count))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_129 = s;
    zT_130 = zF_3E695161_rU32(zT_129);
    bb_id = zT_130;
    zT_132 = s;
    zT_133 = zF_747E1168_rU8(zT_132);
    bb_term = zT_133;
    zT_134 = s;
    zT_135 = zF_747E1168_rU8(zT_134);
    (void)zT_135;
    zT_136 = s;
    zT_137 = zF_747E1168_rU8(zT_136);
    (void)zT_137;
    zT_138 = s;
    zT_139 = zF_747E1168_rU8(zT_138);
    (void)zT_139;
    zT_141 = s;
    zT_142 = zF_3E695161_rU32(zT_141);
    insts_count = zT_142;
    zT_145 = expected_len + (unsigned int)(insts_count * (unsigned int)(32));
    expected_len = zT_145;
    zT_147 = dst;
    zT_148 = zF_C6E3B5BB_lirInstArrayListIni(zT_147);
    binsts = zT_148;
    if ((int)(insts_count > (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_176 = bi + (unsigned int)(1);
    bi = zT_176;
    goto z_bb_13;
    z_bb_17:
    zT_152 = dst;
    zT_159 = zF_1395EB68_sandAlloc(zT_152, (unsigned int)((unsigned int)((unsigned int)insts_count) * (unsigned int)(32)), (unsigned int)(4));
    zT_160 = zT_159.is_error;
    if (zT_160) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_174.id = bb_id;
    zT_174.insts = binsts;
    zT_174.is_terminated = bb_term;
    bitems[bi] = zT_174;
    goto z_bb_16;
    z_bb_19:
    pal_trap();
    z_bb_20:
    zT_161 = zT_159.data.payload;
    goto z_bb_21;
    z_bb_21:
    iraw = zT_161;
    binsts.items = (zT_6BA597BC_LirInst*)((zT_6BA597BC_LirInst*)iraw);
    binsts.len = (unsigned int)((unsigned int)insts_count);
    binsts.capacity = (unsigned int)((unsigned int)insts_count);
    zT_166 = s;
    zT_169 = binsts.items;
    zF_CF6758F4_rBytes(zT_166, (unsigned char*)((unsigned char*)zT_169), (unsigned int)((unsigned int)((unsigned int)insts_count) * (unsigned int)(32)));
    goto z_bb_18;
    z_bb_22:
    zT_183 = dst;
    zT_190 = zF_1395EB68_sandAlloc(zT_183, (unsigned int)((unsigned int)((unsigned int)hoisted_temps_count) * (unsigned int)(8)), (unsigned int)(4));
    zT_191 = zT_190.is_error;
    if (zT_191) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_206 = dst;
    zT_207 = zF_64707188_switchCaseArrayList(zT_206);
    switch_cases = zT_207;
    if ((int)(switch_cases_count > (unsigned int)(0))) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    pal_trap();
    z_bb_25:
    zT_192 = zT_190.data.payload;
    goto z_bb_26;
    z_bb_26:
    raw = zT_192;
    hoisted_temps.items = (zT_1937645B_TempDecl*)((zT_1937645B_TempDecl*)raw);
    hoisted_temps.len = (unsigned int)((unsigned int)hoisted_temps_count);
    hoisted_temps.capacity = (unsigned int)((unsigned int)hoisted_temps_count);
    zT_197 = s;
    zT_200 = hoisted_temps.items;
    zF_CF6758F4_rBytes(zT_197, (unsigned char*)((unsigned char*)zT_200), (unsigned int)((unsigned int)((unsigned int)hoisted_temps_count) * (unsigned int)(8)));
    goto z_bb_23;
    z_bb_27:
    zT_211 = dst;
    zT_218 = zF_1395EB68_sandAlloc(zT_211, (unsigned int)((unsigned int)((unsigned int)switch_cases_count) * (unsigned int)(16)), (unsigned int)(4));
    zT_219 = zT_218.is_error;
    if (zT_219) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_234 = dst;
    zT_235 = zF_4231AD2C_lirSideEntryArrayLi(zT_234);
    side_table = zT_235;
    if ((int)(side_table_count > (unsigned int)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_29:
    pal_trap();
    z_bb_30:
    zT_220 = zT_218.data.payload;
    goto z_bb_31;
    z_bb_31:
    raw = zT_220;
    switch_cases.items = (zT_4BD97095_SwitchCase*)((zT_4BD97095_SwitchCase*)raw);
    switch_cases.len = (unsigned int)((unsigned int)switch_cases_count);
    switch_cases.capacity = (unsigned int)((unsigned int)switch_cases_count);
    zT_225 = s;
    zT_228 = switch_cases.items;
    zF_CF6758F4_rBytes(zT_225, (unsigned char*)((unsigned char*)zT_228), (unsigned int)((unsigned int)((unsigned int)switch_cases_count) * (unsigned int)(16)));
    goto z_bb_28;
    z_bb_32:
    zT_239 = dst;
    zT_246 = zF_1395EB68_sandAlloc(zT_239, (unsigned int)((unsigned int)((unsigned int)side_table_count) * (unsigned int)(28)), (unsigned int)(4));
    zT_247 = zT_246.is_error;
    if (zT_247) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_262 = dst;
    zT_263 = zF_58BDA2DE_u32ToU32MapInit(zT_262);
    tvsf = zT_263;
    if ((int)(tvsf_capacity > (unsigned int)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_34:
    pal_trap();
    z_bb_35:
    zT_248 = zT_246.data.payload;
    goto z_bb_36;
    z_bb_36:
    raw = zT_248;
    side_table.items = (zT_A8A5B231_LirSideEntry*)((zT_A8A5B231_LirSideEntry*)raw);
    side_table.len = (unsigned int)((unsigned int)side_table_count);
    side_table.capacity = (unsigned int)((unsigned int)side_table_count);
    zT_253 = s;
    zT_256 = side_table.items;
    zF_CF6758F4_rBytes(zT_253, (unsigned char*)((unsigned char*)zT_256), (unsigned int)((unsigned int)((unsigned int)side_table_count) * (unsigned int)(28)));
    goto z_bb_33;
    z_bb_37:
    zT_267 = (unsigned int)tvsf_capacity;
    cap = zT_267;
    zT_269 = dst;
    zT_275 = zF_1395EB68_sandAlloc(zT_269, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_276 = zT_275.is_error;
    if (zT_276) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_326 = slot.byte_len;
    if ((int)(expected_len != zT_326)) goto z_bb_48; else goto z_bb_49;
    z_bb_39:
    pal_trap();
    z_bb_40:
    zT_277 = zT_275.data.payload;
    goto z_bb_41;
    z_bb_41:
    kraw = zT_277;
    zT_280 = dst;
    zT_286 = zF_1395EB68_sandAlloc(zT_280, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_287 = zT_286.is_error;
    if (zT_287) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    pal_trap();
    z_bb_43:
    zT_288 = zT_286.data.payload;
    goto z_bb_44;
    z_bb_44:
    vraw = zT_288;
    zT_291 = dst;
    zT_297 = zF_1395EB68_sandAlloc(zT_291, (unsigned int)((unsigned int)(1) * cap), (unsigned int)(4));
    zT_298 = zT_297.is_error;
    if (zT_298) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    pal_trap();
    z_bb_46:
    zT_299 = zT_297.data.payload;
    goto z_bb_47;
    z_bb_47:
    oraw = zT_299;
    tvsf.keys = (unsigned int*)((unsigned int*)kraw);
    tvsf.values = (unsigned int*)((unsigned int*)vraw);
    tvsf.occupied = (unsigned char*)((unsigned char*)oraw);
    tvsf.capacity = cap;
    tvsf.count = (unsigned int)((unsigned int)tvsf_count);
    zT_305 = s;
    zT_308 = tvsf.keys;
    zF_CF6758F4_rBytes(zT_305, (unsigned char*)((unsigned char*)zT_308), (unsigned int)((unsigned int)(4) * cap));
    zT_312 = s;
    zT_315 = tvsf.values;
    zF_CF6758F4_rBytes(zT_312, (unsigned char*)((unsigned char*)zT_315), (unsigned int)((unsigned int)(4) * cap));
    zT_319 = s;
    zT_322 = tvsf.occupied;
    zF_CF6758F4_rBytes(zT_319, (unsigned char*)((unsigned char*)zT_322), (unsigned int)((unsigned int)(1) * cap));
    goto z_bb_38;
    z_bb_48:
    zT_329 = "S-LIR byte_len mismatch on fault-in read";
    zT_331 = 40;
    zT_330.ptr = zT_329;
    zT_330.len = zT_331;
    emsg = zT_330;
    zT_333 = "lir_stream.zig";
    zT_335 = 14;
    zT_334.ptr = zT_333;
    zT_334.len = zT_335;
    ef = zT_334;
    zT_336 = emsg;
    zT_337 = ef;
    zT_339 = 306;
    zF_6D97D338_panicHandler(zT_336, zT_337, (unsigned int)((unsigned int)zT_339));
    zT_341 = dst;
    zT_342 = zF_FAE9AF21_emptyLirFunction(zT_341);
    return zT_342;
    z_bb_49:
    zT_343.name_id = name_id;
    zT_343.module_id = module_id;
    zT_343.return_type = return_type;
    zT_343.params = params;
    zT_343.blocks = blocks;
    zT_343.hoisted_temps = hoisted_temps;
    zT_343.switch_cases = switch_cases;
    zT_343.side_table = side_table;
    zT_343.temp_variant_sub_field = tvsf;
    zT_343.is_extern = is_extern;
    zT_343.is_pub = is_pub;
    zT_343.is_variadic = is_variadic;
    zT_343.call_conv = call_conv;
    zT_343.poison_uninit = poison_uninit;
    return zT_343;
}

/* __module_init */
void zF_780653D2___module_init_14(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_BBC23664_LirFunction zT_1 = {0};
    zT_E7714190_LirSlot zT_2 = {0};
    char* zT_3;
    char* zT_4;
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_E7714190_LirSlot = zT_2;
    zT_3 = "rb";
    zG_4417A8F5_READ_MODE = zT_3;
    zT_4 = "wb";
    zG_82B6E276_WRITE_MODE = zT_4;
    return;
}

/* EOF */
