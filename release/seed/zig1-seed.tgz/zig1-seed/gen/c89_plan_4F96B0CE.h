#ifndef ZIG_MODULE_C89_PLAN_4F96B0CE_H
#define ZIG_MODULE_C89_PLAN_4F96B0CE_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "type_registry_8EE489B8.h"
#include "lir_64CB5435.h"
#include "hash_02AFCD13.h"
#include "allocator_E75B7A0B.h"


/* Forward declarations */
unsigned int zF_453BF522_carrierFromFacts(unsigned char, unsigned char);
unsigned int zF_48A5B64F_deriveConstCarrier(zT_338B7C76_TypeRegistry*, unsigned int, zT_79FAE712_u64, unsigned char, unsigned char);
unsigned int zF_DD416DF8_spellInstOrd(zT_BBC23664_LirFunction*, unsigned int, unsigned int);
void zF_E2B88A09_spellPlanGrow(zT_1317DCD6_C89SpellPlan*, zT_3E40CD83_Sand*);
void zF_D67A348C_spellPlanInit(zT_1317DCD6_C89SpellPlan*, zT_3E40CD83_Sand*, unsigned int);
void zF_72205F3D_spellPlanPlanFn(zT_1317DCD6_C89SpellPlan*, zT_3E40CD83_Sand*, zT_338B7C76_TypeRegistry*, unsigned int, zT_BBC23664_LirFunction*);
unsigned int zF_F9C1339C_hoistedEffType(zT_BBC23664_LirFunction*, unsigned int*, unsigned int, unsigned int);
unsigned char zF_12E895CF_uacPromoteSide(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_54BC5F51_spellPlanUac(zT_1317DCD6_C89SpellPlan*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_1AA43196_spellPlanCarrier(zT_1317DCD6_C89SpellPlan*, unsigned int, unsigned int);
unsigned int* zF_1DD26D63_tstTopologicalSort(zT_338B7C76_TypeRegistry*, zT_3E40CD83_Sand*);
void zF_869C84A7_spellPlanPlanTypeOr(zT_1317DCD6_C89SpellPlan*, zT_3E40CD83_Sand*, zT_338B7C76_TypeRegistry*);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_C89_PLAN_4F96B0CE_H */
