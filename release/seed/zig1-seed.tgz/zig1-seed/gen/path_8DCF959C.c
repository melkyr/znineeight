#include "path_8DCF959C.h"
/* normalizePath */
zT_DF3A1C30_Opt_205 zF_36F0DB6B_normalizePath(zT_8F083A69_Slice_zT_0B42B2F8_u buf, zT_8F083A69_Slice_zT_0B42B2F8_u src) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_6;
    zT_DF3A1C30_Opt_205 zT_7 = {0};
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_21;
    int zT_23;
    unsigned int zT_24;
    int zT_26;
    unsigned int zT_27;
    int zT_28;
    int zT_29;
    int zT_30;
    unsigned char* zT_31;
    int zT_32;
    unsigned char zT_33;
    unsigned char zT_34;
    int zT_35;
    int zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    unsigned char* zT_39;
    int zT_40;
    int zT_41;
    unsigned int zT_42;
    zT_894C14AF_Arr_unsigned_int_51 zT_44;
    int zT_46;
    unsigned int zT_47;
    int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    int zT_55;
    int zT_57;
    unsigned int zT_58;
    int zT_59;
    int zT_60;
    unsigned int zT_61;
    unsigned char* zT_62;
    unsigned char zT_63;
    unsigned char zT_64;
    int zT_65;
    int zT_66;
    unsigned int zT_67;
    int zT_68;
    int zT_69;
    unsigned int zT_71;
    int zT_72;
    int zT_73;
    int zT_75;
    unsigned int zT_76;
    int zT_78;
    unsigned int zT_79;
    int zT_80;
    int zT_81;
    int zT_82;
    unsigned char* zT_83;
    unsigned char zT_84;
    unsigned char zT_85;
    int zT_86;
    int zT_87;
    unsigned int zT_88;
    int zT_89;
    int zT_90;
    int zT_91;
    unsigned char* zT_92;
    unsigned char zT_93;
    unsigned char zT_94;
    int zT_95;
    int zT_96;
    unsigned char* zT_97;
    int zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    unsigned char zT_101;
    int zT_102;
    int zT_103;
    unsigned int zT_104;
    int zT_105;
    int zT_106;
    int zT_107;
    int zT_108;
    int zT_109;
    int zT_110;
    int zT_111;
    int zT_112;
    unsigned char* zT_113;
    int zT_114;
    unsigned int zT_115;
    unsigned char zT_116;
    unsigned char zT_117;
    int zT_118;
    unsigned char zT_119;
    unsigned char* zT_120;
    int zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    int zT_124;
    int zT_125;
    int zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    int zT_130;
    unsigned int zT_131;
    int zT_132;
    unsigned char* zT_133;
    unsigned int zT_134;
    unsigned char zT_135;
    unsigned char* zT_136;
    unsigned int zT_137;
    int zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    int zT_141;
    int zT_142;
    int zT_143;
    int zT_144;
    int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    int zT_149;
    int zT_150;
    unsigned char* zT_151;
    int zT_152;
    unsigned int zT_153;
    unsigned char zT_154;
    unsigned char zT_155;
    int zT_156;
    int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    int zT_160;
    int zT_161;
    int zT_162;
    int zT_163;
    int zT_164;
    unsigned char* zT_165;
    int zT_166;
    unsigned int zT_167;
    unsigned char zT_168;
    unsigned char zT_169;
    int zT_170;
    unsigned char zT_171;
    unsigned char* zT_172;
    int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned char zT_176;
    unsigned char* zT_177;
    int zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    unsigned char zT_181;
    unsigned char* zT_182;
    int zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    int zT_186;
    unsigned int zT_187;
    int zT_188;
    unsigned int zT_189;
    int zT_190;
    int zT_191;
    int zT_192;
    unsigned char* zT_193;
    int zT_194;
    unsigned int zT_195;
    unsigned char zT_196;
    unsigned char zT_197;
    int zT_198;
    int zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    int zT_202;
    int zT_203;
    int zT_204;
    int zT_205;
    unsigned char zT_206;
    unsigned char* zT_207;
    int zT_208;
    int zT_209;
    unsigned int zT_210;
    unsigned char zT_211;
    unsigned char* zT_212;
    int zT_213;
    int zT_214;
    unsigned int zT_215;
    unsigned char* zT_216;
    int zT_218;
    unsigned char* zT_219;
    unsigned int zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    zT_DF3A1C30_Opt_205 zT_222;
    unsigned int i;
    unsigned int len;
    unsigned int out_len;
    unsigned int is_abs;
    zT_894C14AF_Arr_unsigned_int_51 stack;
    unsigned int stack_len;
    unsigned int seg_start;
    unsigned int pos;
    unsigned int is_sep;
    unsigned int seg_len;
    unsigned int is_dot;
    unsigned int is_dotdot;
    unsigned int k;
    zT_3 = buf.len;
    zT_5 = src.len;
    zT_6 = zT_3 < zT_5;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7.has_value = 0;
    return zT_7;
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    i = zT_10;
    i = zT_10;
    i = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = src.len;
    zT_13 = i < zT_12;
    if (zT_13) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = src.ptr;
    zT_15 = zT_14[i];
    zT_16 = buf.ptr;
    zT_16[i] = zT_15;
    goto z_bb_6;
    z_bb_5:
    zT_21 = src.len;
    len = zT_21;
    len = zT_21;
    len = zT_21;
    zT_23 = 0;
    zT_24 = (unsigned int)zT_23;
    out_len = zT_24;
    out_len = zT_24;
    out_len = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    is_abs = zT_27;
    is_abs = zT_27;
    is_abs = zT_27;
    zT_28 = 0;
    zT_29 = len > (unsigned int)zT_28;
    if (zT_29) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_17 = 1;
    zT_18 = i + zT_17;
    i = zT_18;
    i = zT_18;
    goto z_bb_3;
    z_bb_7:
    zT_31 = buf.ptr;
    zT_32 = 0;
    zT_33 = zT_31[zT_32];
    zT_34 = 47;
    zT_35 = zT_33 == zT_34;
    zT_30 = zT_35;
    goto z_bb_9;
    z_bb_8:
    zT_30 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_30) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_36 = 1;
    zT_37 = (unsigned int)zT_36;
    is_abs = zT_37;
    is_abs = zT_37;
    zT_38 = 47;
    zT_39 = buf.ptr;
    zT_40 = 0;
    zT_39[zT_40] = zT_38;
    zT_41 = 1;
    zT_42 = (unsigned int)zT_41;
    out_len = zT_42;
    out_len = zT_42;
    goto z_bb_11;
    z_bb_11:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        stack[_i] = zT_44[_i];
        _i++;
    }
}
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    stack_len = zT_47;
    stack_len = zT_47;
    stack_len = zT_47;
    zT_49 = 1;
    zT_50 = is_abs == (unsigned int)zT_49;
    if (zT_50) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_52 = 1;
    zT_51 = zT_52;
    goto z_bb_14;
    z_bb_13:
    zT_53 = 0;
    zT_51 = zT_53;
    goto z_bb_14;
    z_bb_14:
    seg_start = zT_51;
    seg_start = zT_51;
    seg_start = zT_51;
    pos = seg_start;
    pos = seg_start;
    pos = seg_start;
    goto z_bb_15;
    z_bb_15:
    zT_55 = pos <= len;
    if (zT_55) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    is_sep = zT_58;
    is_sep = zT_58;
    is_sep = zT_58;
    zT_59 = pos == len;
    if (zT_59) goto z_bb_19; else goto z_bb_21;
    z_bb_17:
    goto z_bb_75;
    z_bb_18:
    zT_188 = 1;
    zT_189 = pos + zT_188;
    pos = zT_189;
    pos = zT_189;
    goto z_bb_15;
    z_bb_19:
    zT_60 = 1;
    zT_61 = (unsigned int)zT_60;
    is_sep = zT_61;
    is_sep = zT_61;
    goto z_bb_20;
    z_bb_20:
    zT_68 = 1;
    zT_69 = is_sep == (unsigned int)zT_68;
    if (zT_69) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_62 = buf.ptr;
    zT_63 = zT_62[pos];
    zT_64 = 47;
    zT_65 = zT_63 == zT_64;
    if (zT_65) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_66 = 1;
    zT_67 = (unsigned int)zT_66;
    is_sep = zT_67;
    is_sep = zT_67;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_71 = pos - seg_start;
    seg_len = zT_71;
    seg_len = zT_71;
    seg_len = zT_71;
    zT_72 = 0;
    zT_73 = seg_len > (unsigned int)zT_72;
    if (zT_73) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_18;
    z_bb_26:
    zT_75 = 0;
    zT_76 = (unsigned int)zT_75;
    is_dot = zT_76;
    is_dot = zT_76;
    is_dot = zT_76;
    zT_78 = 0;
    zT_79 = (unsigned int)zT_78;
    is_dotdot = zT_79;
    is_dotdot = zT_79;
    is_dotdot = zT_79;
    zT_80 = 1;
    zT_81 = seg_len == (unsigned int)zT_80;
    if (zT_81) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_186 = 1;
    zT_187 = pos + zT_186;
    seg_start = zT_187;
    seg_start = zT_187;
    goto z_bb_25;
    z_bb_28:
    zT_83 = buf.ptr;
    zT_84 = zT_83[seg_start];
    zT_85 = 46;
    zT_86 = zT_84 == zT_85;
    zT_82 = zT_86;
    goto z_bb_30;
    z_bb_29:
    zT_82 = 0;
    goto z_bb_30;
    z_bb_30:
    if (zT_82) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_87 = 1;
    zT_88 = (unsigned int)zT_87;
    is_dot = zT_88;
    is_dot = zT_88;
    goto z_bb_32;
    z_bb_32:
    zT_89 = 2;
    zT_90 = seg_len == (unsigned int)zT_89;
    if (zT_90) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_92 = buf.ptr;
    zT_93 = zT_92[seg_start];
    zT_94 = 46;
    zT_95 = zT_93 == zT_94;
    zT_91 = zT_95;
    goto z_bb_35;
    z_bb_34:
    zT_91 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_91) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_97 = buf.ptr;
    zT_98 = 1;
    zT_99 = seg_start + zT_98;
    zT_100 = zT_97[zT_99];
    zT_101 = 46;
    zT_102 = zT_100 == zT_101;
    zT_96 = zT_102;
    goto z_bb_38;
    z_bb_37:
    zT_96 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_96) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_103 = 1;
    zT_104 = (unsigned int)zT_103;
    is_dotdot = zT_104;
    is_dotdot = zT_104;
    goto z_bb_40;
    z_bb_40:
    zT_105 = 0;
    zT_106 = is_dot == (unsigned int)zT_105;
    if (zT_106) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_108 = 0;
    zT_109 = is_dotdot == (unsigned int)zT_108;
    zT_107 = zT_109;
    goto z_bb_43;
    z_bb_42:
    zT_107 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_107) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_110 = 0;
    zT_111 = out_len > (unsigned int)zT_110;
    if (zT_111) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_27;
    z_bb_46:
    zT_141 = 1;
    zT_142 = is_dotdot == (unsigned int)zT_141;
    if (zT_142) goto z_bb_58; else goto z_bb_59;
    z_bb_47:
    zT_113 = buf.ptr;
    zT_114 = 1;
    zT_115 = out_len - zT_114;
    zT_116 = zT_113[zT_115];
    zT_117 = 47;
    zT_118 = zT_116 != zT_117;
    zT_112 = zT_118;
    goto z_bb_49;
    z_bb_48:
    zT_112 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_112) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_119 = 47;
    zT_120 = buf.ptr;
    zT_120[out_len] = zT_119;
    zT_121 = 1;
    zT_122 = (unsigned int)zT_121;
    zT_123 = out_len + zT_122;
    out_len = zT_123;
    out_len = zT_123;
    goto z_bb_51;
    z_bb_51:
    zT_124 = 512;
    zT_125 = stack_len < (unsigned int)zT_124;
    if (zT_125) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    stack[stack_len] = out_len;
    zT_126 = 1;
    zT_127 = (unsigned int)zT_126;
    zT_128 = stack_len + zT_127;
    stack_len = zT_128;
    stack_len = zT_128;
    goto z_bb_53;
    z_bb_53:
    zT_130 = 0;
    zT_131 = (unsigned int)zT_130;
    k = zT_131;
    k = zT_131;
    k = zT_131;
    goto z_bb_54;
    z_bb_54:
    zT_132 = k < seg_len;
    if (zT_132) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_133 = buf.ptr;
    zT_134 = seg_start + k;
    zT_135 = zT_133[zT_134];
    zT_136 = buf.ptr;
    zT_137 = out_len + k;
    zT_136[zT_137] = zT_135;
    goto z_bb_57;
    z_bb_56:
    zT_140 = out_len + seg_len;
    out_len = zT_140;
    out_len = zT_140;
    goto z_bb_45;
    z_bb_57:
    zT_138 = 1;
    zT_139 = k + zT_138;
    k = zT_139;
    k = zT_139;
    goto z_bb_54;
    z_bb_58:
    zT_143 = 0;
    zT_144 = stack_len > (unsigned int)zT_143;
    if (zT_144) goto z_bb_60; else goto z_bb_62;
    z_bb_59:
    goto z_bb_45;
    z_bb_60:
    zT_145 = 1;
    zT_146 = (unsigned int)zT_145;
    zT_147 = stack_len - zT_146;
    stack_len = zT_147;
    stack_len = zT_147;
    zT_148 = stack[stack_len];
    out_len = zT_148;
    out_len = zT_148;
    zT_149 = out_len > is_abs;
    if (zT_149) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    zT_160 = 0;
    zT_161 = is_abs == (unsigned int)zT_160;
    if (zT_161) goto z_bb_68; else goto z_bb_69;
    z_bb_63:
    zT_151 = buf.ptr;
    zT_152 = 1;
    zT_153 = out_len - zT_152;
    zT_154 = zT_151[zT_153];
    zT_155 = 47;
    zT_156 = zT_154 == zT_155;
    zT_150 = zT_156;
    goto z_bb_65;
    z_bb_64:
    zT_150 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_150) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_157 = 1;
    zT_158 = (unsigned int)zT_157;
    zT_159 = out_len - zT_158;
    out_len = zT_159;
    out_len = zT_159;
    goto z_bb_67;
    z_bb_67:
    goto z_bb_61;
    z_bb_68:
    zT_162 = 0;
    zT_163 = out_len > (unsigned int)zT_162;
    if (zT_163) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    goto z_bb_61;
    z_bb_70:
    zT_165 = buf.ptr;
    zT_166 = 1;
    zT_167 = out_len - zT_166;
    zT_168 = zT_165[zT_167];
    zT_169 = 47;
    zT_170 = zT_168 != zT_169;
    zT_164 = zT_170;
    goto z_bb_72;
    z_bb_71:
    zT_164 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_164) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_171 = 47;
    zT_172 = buf.ptr;
    zT_172[out_len] = zT_171;
    zT_173 = 1;
    zT_174 = (unsigned int)zT_173;
    zT_175 = out_len + zT_174;
    out_len = zT_175;
    out_len = zT_175;
    goto z_bb_74;
    z_bb_74:
    zT_176 = 46;
    zT_177 = buf.ptr;
    zT_177[out_len] = zT_176;
    zT_178 = 1;
    zT_179 = (unsigned int)zT_178;
    zT_180 = out_len + zT_179;
    out_len = zT_180;
    out_len = zT_180;
    zT_181 = 46;
    zT_182 = buf.ptr;
    zT_182[out_len] = zT_181;
    zT_183 = 1;
    zT_184 = (unsigned int)zT_183;
    zT_185 = out_len + zT_184;
    out_len = zT_185;
    out_len = zT_185;
    goto z_bb_69;
    z_bb_75:
    zT_190 = 1;
    zT_191 = out_len > (unsigned int)zT_190;
    if (zT_191) goto z_bb_79; else goto z_bb_80;
    z_bb_76:
    zT_199 = 1;
    zT_200 = (unsigned int)zT_199;
    zT_201 = out_len - zT_200;
    out_len = zT_201;
    out_len = zT_201;
    goto z_bb_78;
    z_bb_77:
    zT_202 = 0;
    zT_203 = out_len == (unsigned int)zT_202;
    if (zT_203) goto z_bb_82; else goto z_bb_83;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    zT_193 = buf.ptr;
    zT_194 = 1;
    zT_195 = out_len - zT_194;
    zT_196 = zT_193[zT_195];
    zT_197 = 47;
    zT_198 = zT_196 == zT_197;
    zT_192 = zT_198;
    goto z_bb_81;
    z_bb_80:
    zT_192 = 0;
    goto z_bb_81;
    z_bb_81:
    if (zT_192) goto z_bb_76; else goto z_bb_77;
    z_bb_82:
    zT_204 = 1;
    zT_205 = is_abs == (unsigned int)zT_204;
    if (zT_205) goto z_bb_84; else goto z_bb_86;
    z_bb_83:
    zT_216 = buf.ptr;
    zT_218 = 0;
    zT_219 = zT_216 + zT_218;
    zT_220 = out_len - zT_218;
    zT_221.ptr = zT_219;
    zT_221.len = zT_220;
    zT_222.has_value = 1;
    zT_222.value = zT_221;
    return zT_222;
    z_bb_84:
    zT_206 = 47;
    zT_207 = buf.ptr;
    zT_208 = 0;
    zT_207[zT_208] = zT_206;
    zT_209 = 1;
    zT_210 = (unsigned int)zT_209;
    out_len = zT_210;
    out_len = zT_210;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_83;
    z_bb_86:
    zT_211 = 46;
    zT_212 = buf.ptr;
    zT_213 = 0;
    zT_212[zT_213] = zT_211;
    zT_214 = 1;
    zT_215 = (unsigned int)zT_214;
    out_len = zT_215;
    out_len = zT_215;
    goto z_bb_85;
}

/* EOF */
