#include "path_8DCF959C.h"
/* normalizePath */
zT_E137E0BF_Opt_217 zF_36F0DB6B_normalizePath(zT_8F083A69_Slice_zT_0B42B2F8_u buf, zT_8F083A69_Slice_zT_0B42B2F8_u src) {
    unsigned int zT_3;
    unsigned int zT_5;
    zT_E137E0BF_Opt_217 zT_7 = {0};
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_21;
    int zT_23;
    unsigned int zT_24;
    int zT_26;
    unsigned int zT_27;
    int zT_28;
    int zT_30;
    unsigned char* zT_31;
    int zT_32;
    unsigned char zT_33;
    int zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    unsigned char* zT_39;
    int zT_40;
    int zT_41;
    unsigned int zT_42;
    zT_894C14AF_Arr_unsigned_int_51 zT_44;
    int zT_46;
    unsigned int zT_47;
    int zT_49;
    unsigned int zT_51;
    int zT_57;
    unsigned int zT_58;
    int zT_60;
    unsigned int zT_61;
    unsigned char* zT_62;
    unsigned char zT_63;
    int zT_66;
    unsigned int zT_67;
    int zT_68;
    unsigned int zT_71;
    int zT_72;
    int zT_75;
    unsigned int zT_76;
    int zT_78;
    unsigned int zT_79;
    int zT_80;
    int zT_82;
    unsigned char* zT_83;
    unsigned char zT_84;
    int zT_87;
    unsigned int zT_88;
    int zT_89;
    int zT_91;
    unsigned char* zT_92;
    unsigned char zT_93;
    int zT_96;
    unsigned char* zT_97;
    int zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    int zT_103;
    unsigned int zT_104;
    int zT_105;
    int zT_107;
    int zT_108;
    int zT_110;
    int zT_112;
    unsigned char* zT_113;
    int zT_114;
    unsigned int zT_115;
    unsigned char zT_116;
    unsigned char zT_119;
    unsigned char* zT_120;
    int zT_121;
    unsigned int zT_123;
    int zT_124;
    int zT_126;
    unsigned int zT_128;
    int zT_130;
    unsigned int zT_131;
    unsigned char* zT_133;
    unsigned int zT_134;
    unsigned char zT_135;
    unsigned char* zT_136;
    unsigned int zT_137;
    int zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    int zT_141;
    int zT_143;
    int zT_145;
    unsigned int zT_147;
    unsigned int zT_148;
    int zT_150;
    unsigned char* zT_151;
    int zT_152;
    unsigned int zT_153;
    unsigned char zT_154;
    int zT_157;
    unsigned int zT_159;
    int zT_160;
    int zT_162;
    int zT_164;
    unsigned char* zT_165;
    int zT_166;
    unsigned int zT_167;
    unsigned char zT_168;
    unsigned char zT_171;
    unsigned char* zT_172;
    int zT_173;
    unsigned int zT_175;
    unsigned char zT_176;
    unsigned char* zT_177;
    int zT_178;
    unsigned int zT_180;
    unsigned char zT_181;
    unsigned char* zT_182;
    int zT_183;
    unsigned int zT_185;
    int zT_186;
    unsigned int zT_187;
    int zT_188;
    unsigned int zT_189;
    int zT_190;
    int zT_192;
    unsigned char* zT_193;
    int zT_194;
    unsigned int zT_195;
    unsigned char zT_196;
    int zT_199;
    unsigned int zT_201;
    int zT_202;
    int zT_204;
    unsigned char zT_206;
    unsigned char* zT_207;
    int zT_208;
    int zT_209;
    unsigned int zT_210;
    unsigned char zT_211;
    unsigned char* zT_212;
    int zT_213;
    int zT_214;
    unsigned int zT_215;
    unsigned char* zT_216;
    int zT_218;
    unsigned char* zT_219;
    unsigned int zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    zT_E137E0BF_Opt_217 zT_222;
    unsigned int i;
    unsigned int len;
    unsigned int out_len;
    unsigned int is_abs;
    zT_894C14AF_Arr_unsigned_int_51 stack;
    unsigned int stack_len;
    unsigned int seg_start;
    unsigned int pos;
    unsigned int is_sep;
    unsigned int seg_len;
    unsigned int is_dot;
    unsigned int is_dotdot;
    unsigned int k;
    zT_3 = buf.len;
    zT_5 = src.len;
    if ((int)(zT_3 < zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7.has_value = 0;
    return zT_7;
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    i = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = src.len;
    if ((int)(i < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = src.ptr;
    zT_15 = zT_14[i];
    zT_16 = buf.ptr;
    zT_16[i] = zT_15;
    goto z_bb_6;
    z_bb_5:
    zT_21 = src.len;
    len = zT_21;
    zT_23 = 0;
    zT_24 = (unsigned int)zT_23;
    out_len = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    is_abs = zT_27;
    zT_28 = 0;
    if ((int)(len > (unsigned int)zT_28)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_17 = 1;
    zT_18 = i + zT_17;
    i = zT_18;
    goto z_bb_3;
    z_bb_7:
    zT_31 = buf.ptr;
    zT_32 = 0;
    zT_33 = zT_31[zT_32];
    zT_30 = zT_33 == (unsigned char)(47);
    goto z_bb_9;
    z_bb_8:
    zT_30 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_30) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_36 = 1;
    zT_37 = (unsigned int)zT_36;
    is_abs = zT_37;
    zT_38 = 47;
    zT_39 = buf.ptr;
    zT_40 = 0;
    zT_39[zT_40] = zT_38;
    zT_41 = 1;
    zT_42 = (unsigned int)zT_41;
    out_len = zT_42;
    goto z_bb_11;
    z_bb_11:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_44[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        stack[_i] = zT_44[_i];
        _i++;
    }
}
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    stack_len = zT_47;
    zT_49 = 1;
    if ((int)(is_abs == (unsigned int)zT_49)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_51 = 1;
    goto z_bb_14;
    z_bb_13:
    zT_51 = 0;
    goto z_bb_14;
    z_bb_14:
    seg_start = zT_51;
    pos = seg_start;
    goto z_bb_15;
    z_bb_15:
    if ((int)(pos <= len)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    is_sep = zT_58;
    if ((int)(pos == len)) goto z_bb_19; else goto z_bb_21;
    z_bb_17:
    goto z_bb_75;
    z_bb_18:
    zT_188 = 1;
    zT_189 = pos + zT_188;
    pos = zT_189;
    goto z_bb_15;
    z_bb_19:
    zT_60 = 1;
    zT_61 = (unsigned int)zT_60;
    is_sep = zT_61;
    goto z_bb_20;
    z_bb_20:
    zT_68 = 1;
    if ((int)(is_sep == (unsigned int)zT_68)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_62 = buf.ptr;
    zT_63 = zT_62[pos];
    if ((int)(zT_63 == (unsigned char)(47))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_66 = 1;
    zT_67 = (unsigned int)zT_66;
    is_sep = zT_67;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_71 = pos - seg_start;
    seg_len = zT_71;
    zT_72 = 0;
    if ((int)(seg_len > (unsigned int)zT_72)) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_18;
    z_bb_26:
    zT_75 = 0;
    zT_76 = (unsigned int)zT_75;
    is_dot = zT_76;
    zT_78 = 0;
    zT_79 = (unsigned int)zT_78;
    is_dotdot = zT_79;
    zT_80 = 1;
    if ((int)(seg_len == (unsigned int)zT_80)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_186 = 1;
    zT_187 = pos + zT_186;
    seg_start = zT_187;
    goto z_bb_25;
    z_bb_28:
    zT_83 = buf.ptr;
    zT_84 = zT_83[seg_start];
    zT_82 = zT_84 == (unsigned char)(46);
    goto z_bb_30;
    z_bb_29:
    zT_82 = 0;
    goto z_bb_30;
    z_bb_30:
    if (zT_82) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_87 = 1;
    zT_88 = (unsigned int)zT_87;
    is_dot = zT_88;
    goto z_bb_32;
    z_bb_32:
    zT_89 = 2;
    if ((int)(seg_len == (unsigned int)zT_89)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_92 = buf.ptr;
    zT_93 = zT_92[seg_start];
    zT_91 = zT_93 == (unsigned char)(46);
    goto z_bb_35;
    z_bb_34:
    zT_91 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_91) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_97 = buf.ptr;
    zT_98 = 1;
    zT_99 = seg_start + zT_98;
    zT_100 = zT_97[zT_99];
    zT_96 = zT_100 == (unsigned char)(46);
    goto z_bb_38;
    z_bb_37:
    zT_96 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_96) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_103 = 1;
    zT_104 = (unsigned int)zT_103;
    is_dotdot = zT_104;
    goto z_bb_40;
    z_bb_40:
    zT_105 = 0;
    if ((int)(is_dot == (unsigned int)zT_105)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_108 = 0;
    zT_107 = is_dotdot == (unsigned int)zT_108;
    goto z_bb_43;
    z_bb_42:
    zT_107 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_107) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_110 = 0;
    if ((int)(out_len > (unsigned int)zT_110)) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_27;
    z_bb_46:
    zT_141 = 1;
    if ((int)(is_dotdot == (unsigned int)zT_141)) goto z_bb_58; else goto z_bb_59;
    z_bb_47:
    zT_113 = buf.ptr;
    zT_114 = 1;
    zT_115 = out_len - zT_114;
    zT_116 = zT_113[zT_115];
    zT_112 = zT_116 != (unsigned char)(47);
    goto z_bb_49;
    z_bb_48:
    zT_112 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_112) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_119 = 47;
    zT_120 = buf.ptr;
    zT_120[out_len] = zT_119;
    zT_121 = 1;
    zT_123 = out_len + (unsigned int)((unsigned int)zT_121);
    out_len = zT_123;
    goto z_bb_51;
    z_bb_51:
    zT_124 = 512;
    if ((int)(stack_len < (unsigned int)zT_124)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    stack[stack_len] = out_len;
    zT_126 = 1;
    zT_128 = stack_len + (unsigned int)((unsigned int)zT_126);
    stack_len = zT_128;
    goto z_bb_53;
    z_bb_53:
    zT_130 = 0;
    zT_131 = (unsigned int)zT_130;
    k = zT_131;
    goto z_bb_54;
    z_bb_54:
    if ((int)(k < seg_len)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_133 = buf.ptr;
    zT_134 = seg_start + k;
    zT_135 = zT_133[zT_134];
    zT_136 = buf.ptr;
    zT_137 = out_len + k;
    zT_136[zT_137] = zT_135;
    goto z_bb_57;
    z_bb_56:
    zT_140 = out_len + seg_len;
    out_len = zT_140;
    goto z_bb_45;
    z_bb_57:
    zT_138 = 1;
    zT_139 = k + zT_138;
    k = zT_139;
    goto z_bb_54;
    z_bb_58:
    zT_143 = 0;
    if ((int)(stack_len > (unsigned int)zT_143)) goto z_bb_60; else goto z_bb_62;
    z_bb_59:
    goto z_bb_45;
    z_bb_60:
    zT_145 = 1;
    zT_147 = stack_len - (unsigned int)((unsigned int)zT_145);
    stack_len = zT_147;
    zT_148 = stack[stack_len];
    out_len = zT_148;
    if ((int)(out_len > is_abs)) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    zT_160 = 0;
    if ((int)(is_abs == (unsigned int)zT_160)) goto z_bb_68; else goto z_bb_69;
    z_bb_63:
    zT_151 = buf.ptr;
    zT_152 = 1;
    zT_153 = out_len - zT_152;
    zT_154 = zT_151[zT_153];
    zT_150 = zT_154 == (unsigned char)(47);
    goto z_bb_65;
    z_bb_64:
    zT_150 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_150) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_157 = 1;
    zT_159 = out_len - (unsigned int)((unsigned int)zT_157);
    out_len = zT_159;
    goto z_bb_67;
    z_bb_67:
    goto z_bb_61;
    z_bb_68:
    zT_162 = 0;
    if ((int)(out_len > (unsigned int)zT_162)) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    goto z_bb_61;
    z_bb_70:
    zT_165 = buf.ptr;
    zT_166 = 1;
    zT_167 = out_len - zT_166;
    zT_168 = zT_165[zT_167];
    zT_164 = zT_168 != (unsigned char)(47);
    goto z_bb_72;
    z_bb_71:
    zT_164 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_164) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_171 = 47;
    zT_172 = buf.ptr;
    zT_172[out_len] = zT_171;
    zT_173 = 1;
    zT_175 = out_len + (unsigned int)((unsigned int)zT_173);
    out_len = zT_175;
    goto z_bb_74;
    z_bb_74:
    zT_176 = 46;
    zT_177 = buf.ptr;
    zT_177[out_len] = zT_176;
    zT_178 = 1;
    zT_180 = out_len + (unsigned int)((unsigned int)zT_178);
    out_len = zT_180;
    zT_181 = 46;
    zT_182 = buf.ptr;
    zT_182[out_len] = zT_181;
    zT_183 = 1;
    zT_185 = out_len + (unsigned int)((unsigned int)zT_183);
    out_len = zT_185;
    goto z_bb_69;
    z_bb_75:
    zT_190 = 1;
    if ((int)(out_len > (unsigned int)zT_190)) goto z_bb_79; else goto z_bb_80;
    z_bb_76:
    zT_199 = 1;
    zT_201 = out_len - (unsigned int)((unsigned int)zT_199);
    out_len = zT_201;
    goto z_bb_78;
    z_bb_77:
    zT_202 = 0;
    if ((int)(out_len == (unsigned int)zT_202)) goto z_bb_82; else goto z_bb_83;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    zT_193 = buf.ptr;
    zT_194 = 1;
    zT_195 = out_len - zT_194;
    zT_196 = zT_193[zT_195];
    zT_192 = zT_196 == (unsigned char)(47);
    goto z_bb_81;
    z_bb_80:
    zT_192 = 0;
    goto z_bb_81;
    z_bb_81:
    if (zT_192) goto z_bb_76; else goto z_bb_77;
    z_bb_82:
    zT_204 = 1;
    if ((int)(is_abs == (unsigned int)zT_204)) goto z_bb_84; else goto z_bb_86;
    z_bb_83:
    zT_216 = buf.ptr;
    zT_218 = 0;
    zT_219 = zT_216 + zT_218;
    zT_220 = out_len - zT_218;
    zT_221.ptr = zT_219;
    zT_221.len = zT_220;
    zT_222.has_value = 1;
    zT_222.value = zT_221;
    return zT_222;
    z_bb_84:
    zT_206 = 47;
    zT_207 = buf.ptr;
    zT_208 = 0;
    zT_207[zT_208] = zT_206;
    zT_209 = 1;
    zT_210 = (unsigned int)zT_209;
    out_len = zT_210;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_83;
    z_bb_86:
    zT_211 = 46;
    zT_212 = buf.ptr;
    zT_213 = 0;
    zT_212[zT_213] = zT_211;
    zT_214 = 1;
    zT_215 = (unsigned int)zT_214;
    out_len = zT_215;
    goto z_bb_85;
}

/* EOF */
