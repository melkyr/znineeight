#include "path_8DCF959C.h"
/* normalizePath */
zT_7434F691_Opt_224 zF_36F0DB6B_normalizePath(zT_8F083A69_Slice_zT_0B42B2F8_u buf, zT_8F083A69_Slice_zT_0B42B2F8_u src) {
    unsigned int zT_3;
    unsigned int zT_5;
    zT_7434F691_Opt_224 zT_7 = {0};
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char* zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_22;
    int zT_24;
    unsigned int zT_25;
    int zT_27;
    unsigned int zT_28;
    int zT_29;
    unsigned char zT_31;
    unsigned char* zT_32;
    int zT_33;
    unsigned char zT_34;
    int zT_37;
    unsigned int zT_38;
    unsigned char zT_39;
    unsigned char* zT_40;
    int zT_41;
    int zT_42;
    unsigned int zT_43;
    zT_894C14AF_Arr_unsigned_int_51 zT_45;
    int zT_47;
    unsigned int zT_48;
    int zT_50;
    unsigned int zT_52;
    int zT_58;
    unsigned int zT_59;
    int zT_61;
    unsigned int zT_62;
    unsigned char* zT_63;
    unsigned char zT_64;
    int zT_67;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_72;
    int zT_73;
    int zT_76;
    unsigned int zT_77;
    int zT_79;
    unsigned int zT_80;
    int zT_81;
    unsigned char zT_83;
    unsigned char* zT_84;
    unsigned char zT_85;
    int zT_88;
    unsigned int zT_89;
    int zT_90;
    unsigned char zT_92;
    unsigned char* zT_93;
    unsigned char zT_94;
    unsigned char zT_97;
    unsigned char* zT_98;
    int zT_99;
    unsigned int zT_100;
    unsigned char zT_101;
    int zT_104;
    unsigned int zT_105;
    int zT_106;
    unsigned char zT_108;
    int zT_109;
    int zT_111;
    unsigned char zT_113;
    unsigned char* zT_114;
    int zT_115;
    unsigned int zT_116;
    unsigned char zT_117;
    unsigned char zT_120;
    unsigned char* zT_121;
    int zT_122;
    unsigned int zT_124;
    int zT_125;
    int zT_127;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    unsigned char* zT_134;
    unsigned int zT_135;
    unsigned char zT_136;
    unsigned char* zT_137;
    unsigned int zT_138;
    int zT_139;
    unsigned int zT_141;
    unsigned int zT_142;
    int zT_143;
    int zT_145;
    int zT_147;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned char zT_152;
    unsigned char* zT_153;
    int zT_154;
    unsigned int zT_155;
    unsigned char zT_156;
    int zT_159;
    unsigned int zT_161;
    int zT_162;
    int zT_164;
    unsigned char zT_166;
    unsigned char* zT_167;
    int zT_168;
    unsigned int zT_169;
    unsigned char zT_170;
    unsigned char zT_173;
    unsigned char* zT_174;
    int zT_175;
    unsigned int zT_177;
    unsigned char zT_178;
    unsigned char* zT_179;
    int zT_180;
    unsigned int zT_182;
    unsigned char zT_183;
    unsigned char* zT_184;
    int zT_185;
    unsigned int zT_187;
    int zT_188;
    unsigned int zT_189;
    int zT_190;
    unsigned int zT_192;
    int zT_193;
    unsigned char zT_195;
    unsigned char* zT_196;
    int zT_197;
    unsigned int zT_198;
    unsigned char zT_199;
    int zT_202;
    unsigned int zT_204;
    int zT_205;
    int zT_207;
    unsigned char zT_209;
    unsigned char* zT_210;
    int zT_211;
    int zT_212;
    unsigned int zT_213;
    unsigned char zT_214;
    unsigned char* zT_215;
    int zT_216;
    int zT_217;
    unsigned int zT_218;
    unsigned char* zT_219;
    int zT_221;
    unsigned char* zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    zT_7434F691_Opt_224 zT_225;
    unsigned int i;
    unsigned int len;
    unsigned int out_len;
    unsigned int is_abs;
    zT_894C14AF_Arr_unsigned_int_51 stack;
    unsigned int stack_len;
    unsigned int seg_start;
    unsigned int pos;
    unsigned int is_sep;
    unsigned int seg_len;
    unsigned int is_dot;
    unsigned int is_dotdot;
    unsigned int k;
    zT_3 = buf.len;
    zT_5 = src.len;
    if ((unsigned char)(zT_3 < zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7.has_value = 0;
    return zT_7;
    z_bb_2:
    zT_9 = 0;
    zT_10 = (unsigned int)zT_9;
    i = zT_10;
    goto z_bb_3;
    z_bb_3:
    zT_12 = src.len;
    if ((unsigned char)(i < zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_14 = src.ptr;
    zT_15 = zT_14[i];
    zT_16 = buf.ptr;
    zT_16[i] = zT_15;
    goto z_bb_6;
    z_bb_5:
    zT_22 = src.len;
    len = zT_22;
    zT_24 = 0;
    zT_25 = (unsigned int)zT_24;
    out_len = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    is_abs = zT_28;
    zT_29 = 0;
    if ((unsigned char)(len > (unsigned int)zT_29)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_3;
    z_bb_7:
    zT_32 = buf.ptr;
    zT_33 = 0;
    zT_34 = zT_32[zT_33];
    zT_31 = zT_34 == (unsigned char)(47);
    goto z_bb_9;
    z_bb_8:
    zT_31 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_31) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = 1;
    zT_38 = (unsigned int)zT_37;
    is_abs = zT_38;
    zT_39 = 47;
    zT_40 = buf.ptr;
    zT_41 = 0;
    zT_40[zT_41] = zT_39;
    zT_42 = 1;
    zT_43 = (unsigned int)zT_42;
    out_len = zT_43;
    goto z_bb_11;
    z_bb_11:
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_45[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        stack[_i] = zT_45[_i];
        _i++;
    }
}
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    stack_len = zT_48;
    zT_50 = 1;
    if ((unsigned char)(is_abs == (unsigned int)zT_50)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_52 = 1;
    goto z_bb_14;
    z_bb_13:
    zT_52 = 0;
    goto z_bb_14;
    z_bb_14:
    seg_start = zT_52;
    pos = seg_start;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(pos <= len)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_58 = 0;
    zT_59 = (unsigned int)zT_58;
    is_sep = zT_59;
    if ((unsigned char)(pos == len)) goto z_bb_19; else goto z_bb_21;
    z_bb_17:
    goto z_bb_75;
    z_bb_18:
    zT_190 = 1;
    zT_192 = pos + (unsigned int)((unsigned int)zT_190);
    pos = zT_192;
    goto z_bb_15;
    z_bb_19:
    zT_61 = 1;
    zT_62 = (unsigned int)zT_61;
    is_sep = zT_62;
    goto z_bb_20;
    z_bb_20:
    zT_69 = 1;
    if ((unsigned char)(is_sep == (unsigned int)zT_69)) goto z_bb_24; else goto z_bb_25;
    z_bb_21:
    zT_63 = buf.ptr;
    zT_64 = zT_63[pos];
    if ((unsigned char)(zT_64 == (unsigned char)(47))) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_67 = 1;
    zT_68 = (unsigned int)zT_67;
    is_sep = zT_68;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_72 = pos - seg_start;
    seg_len = zT_72;
    zT_73 = 0;
    if ((unsigned char)(seg_len > (unsigned int)zT_73)) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_18;
    z_bb_26:
    zT_76 = 0;
    zT_77 = (unsigned int)zT_76;
    is_dot = zT_77;
    zT_79 = 0;
    zT_80 = (unsigned int)zT_79;
    is_dotdot = zT_80;
    zT_81 = 1;
    if ((unsigned char)(seg_len == (unsigned int)zT_81)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_188 = 1;
    zT_189 = pos + zT_188;
    seg_start = zT_189;
    goto z_bb_25;
    z_bb_28:
    zT_84 = buf.ptr;
    zT_85 = zT_84[seg_start];
    zT_83 = zT_85 == (unsigned char)(46);
    goto z_bb_30;
    z_bb_29:
    zT_83 = 0;
    goto z_bb_30;
    z_bb_30:
    if (zT_83) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_88 = 1;
    zT_89 = (unsigned int)zT_88;
    is_dot = zT_89;
    goto z_bb_32;
    z_bb_32:
    zT_90 = 2;
    if ((unsigned char)(seg_len == (unsigned int)zT_90)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_93 = buf.ptr;
    zT_94 = zT_93[seg_start];
    zT_92 = zT_94 == (unsigned char)(46);
    goto z_bb_35;
    z_bb_34:
    zT_92 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_92) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_98 = buf.ptr;
    zT_99 = 1;
    zT_100 = seg_start + zT_99;
    zT_101 = zT_98[zT_100];
    zT_97 = zT_101 == (unsigned char)(46);
    goto z_bb_38;
    z_bb_37:
    zT_97 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_97) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_104 = 1;
    zT_105 = (unsigned int)zT_104;
    is_dotdot = zT_105;
    goto z_bb_40;
    z_bb_40:
    zT_106 = 0;
    if ((unsigned char)(is_dot == (unsigned int)zT_106)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_109 = 0;
    zT_108 = is_dotdot == (unsigned int)zT_109;
    goto z_bb_43;
    z_bb_42:
    zT_108 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_108) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_111 = 0;
    if ((unsigned char)(out_len > (unsigned int)zT_111)) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_27;
    z_bb_46:
    zT_143 = 1;
    if ((unsigned char)(is_dotdot == (unsigned int)zT_143)) goto z_bb_58; else goto z_bb_59;
    z_bb_47:
    zT_114 = buf.ptr;
    zT_115 = 1;
    zT_116 = out_len - zT_115;
    zT_117 = zT_114[zT_116];
    zT_113 = zT_117 != (unsigned char)(47);
    goto z_bb_49;
    z_bb_48:
    zT_113 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_113) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_120 = 47;
    zT_121 = buf.ptr;
    zT_121[out_len] = zT_120;
    zT_122 = 1;
    zT_124 = out_len + (unsigned int)((unsigned int)zT_122);
    out_len = zT_124;
    goto z_bb_51;
    z_bb_51:
    zT_125 = 512;
    if ((unsigned char)(stack_len < (unsigned int)zT_125)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    stack[stack_len] = out_len;
    zT_127 = 1;
    zT_129 = stack_len + (unsigned int)((unsigned int)zT_127);
    stack_len = zT_129;
    goto z_bb_53;
    z_bb_53:
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    k = zT_132;
    goto z_bb_54;
    z_bb_54:
    if ((unsigned char)(k < seg_len)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_134 = buf.ptr;
    zT_135 = seg_start + k;
    zT_136 = zT_134[zT_135];
    zT_137 = buf.ptr;
    zT_138 = out_len + k;
    zT_137[zT_138] = zT_136;
    goto z_bb_57;
    z_bb_56:
    zT_142 = out_len + seg_len;
    out_len = zT_142;
    goto z_bb_45;
    z_bb_57:
    zT_139 = 1;
    zT_141 = k + (unsigned int)((unsigned int)zT_139);
    k = zT_141;
    goto z_bb_54;
    z_bb_58:
    zT_145 = 0;
    if ((unsigned char)(stack_len > (unsigned int)zT_145)) goto z_bb_60; else goto z_bb_62;
    z_bb_59:
    goto z_bb_45;
    z_bb_60:
    zT_147 = 1;
    zT_149 = stack_len - (unsigned int)((unsigned int)zT_147);
    stack_len = zT_149;
    zT_150 = stack[stack_len];
    out_len = zT_150;
    if ((unsigned char)(out_len > is_abs)) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    goto z_bb_59;
    z_bb_62:
    zT_162 = 0;
    if ((unsigned char)(is_abs == (unsigned int)zT_162)) goto z_bb_68; else goto z_bb_69;
    z_bb_63:
    zT_153 = buf.ptr;
    zT_154 = 1;
    zT_155 = out_len - zT_154;
    zT_156 = zT_153[zT_155];
    zT_152 = zT_156 == (unsigned char)(47);
    goto z_bb_65;
    z_bb_64:
    zT_152 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_152) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_159 = 1;
    zT_161 = out_len - (unsigned int)((unsigned int)zT_159);
    out_len = zT_161;
    goto z_bb_67;
    z_bb_67:
    goto z_bb_61;
    z_bb_68:
    zT_164 = 0;
    if ((unsigned char)(out_len > (unsigned int)zT_164)) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    goto z_bb_61;
    z_bb_70:
    zT_167 = buf.ptr;
    zT_168 = 1;
    zT_169 = out_len - zT_168;
    zT_170 = zT_167[zT_169];
    zT_166 = zT_170 != (unsigned char)(47);
    goto z_bb_72;
    z_bb_71:
    zT_166 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_166) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_173 = 47;
    zT_174 = buf.ptr;
    zT_174[out_len] = zT_173;
    zT_175 = 1;
    zT_177 = out_len + (unsigned int)((unsigned int)zT_175);
    out_len = zT_177;
    goto z_bb_74;
    z_bb_74:
    zT_178 = 46;
    zT_179 = buf.ptr;
    zT_179[out_len] = zT_178;
    zT_180 = 1;
    zT_182 = out_len + (unsigned int)((unsigned int)zT_180);
    out_len = zT_182;
    zT_183 = 46;
    zT_184 = buf.ptr;
    zT_184[out_len] = zT_183;
    zT_185 = 1;
    zT_187 = out_len + (unsigned int)((unsigned int)zT_185);
    out_len = zT_187;
    goto z_bb_69;
    z_bb_75:
    zT_193 = 1;
    if ((unsigned char)(out_len > (unsigned int)zT_193)) goto z_bb_79; else goto z_bb_80;
    z_bb_76:
    zT_202 = 1;
    zT_204 = out_len - (unsigned int)((unsigned int)zT_202);
    out_len = zT_204;
    goto z_bb_78;
    z_bb_77:
    zT_205 = 0;
    if ((unsigned char)(out_len == (unsigned int)zT_205)) goto z_bb_82; else goto z_bb_83;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    zT_196 = buf.ptr;
    zT_197 = 1;
    zT_198 = out_len - zT_197;
    zT_199 = zT_196[zT_198];
    zT_195 = zT_199 == (unsigned char)(47);
    goto z_bb_81;
    z_bb_80:
    zT_195 = 0;
    goto z_bb_81;
    z_bb_81:
    if (zT_195) goto z_bb_76; else goto z_bb_77;
    z_bb_82:
    zT_207 = 1;
    if ((unsigned char)(is_abs == (unsigned int)zT_207)) goto z_bb_84; else goto z_bb_86;
    z_bb_83:
    zT_219 = buf.ptr;
    zT_221 = 0;
    zT_222 = zT_219 + zT_221;
    zT_223 = out_len - zT_221;
    zT_224.ptr = zT_222;
    zT_224.len = zT_223;
    zT_225.has_value = 1;
    zT_225.value = zT_224;
    return zT_225;
    z_bb_84:
    zT_209 = 47;
    zT_210 = buf.ptr;
    zT_211 = 0;
    zT_210[zT_211] = zT_209;
    zT_212 = 1;
    zT_213 = (unsigned int)zT_212;
    out_len = zT_213;
    goto z_bb_85;
    z_bb_85:
    goto z_bb_83;
    z_bb_86:
    zT_214 = 46;
    zT_215 = buf.ptr;
    zT_216 = 0;
    zT_215[zT_216] = zT_214;
    zT_217 = 1;
    zT_218 = (unsigned int)zT_217;
    out_len = zT_218;
    goto z_bb_85;
}

/* EOF */
