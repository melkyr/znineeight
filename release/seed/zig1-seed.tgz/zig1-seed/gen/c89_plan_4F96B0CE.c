#include "c89_plan_4F96B0CE.h"
/* carrierFromFacts */
unsigned int zF_453BF522_carrierFromFacts(unsigned char width_bits, unsigned char is_signed) {
    if ((unsigned char)(width_bits == (unsigned char)(32))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(is_signed != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(is_signed != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(6);
    z_bb_4:
    return (unsigned int)(10);
    z_bb_5:
    return (unsigned int)(7);
    z_bb_6:
    return (unsigned int)(11);
}

/* deriveConstCarrier */
unsigned int zF_48A5B64F_deriveConstCarrier(zT_338B7C76_TypeRegistry* reg, unsigned int semantic_tid, zT_79FAE712_u64 value, unsigned char width_bits, unsigned char is_signed) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_33EF6BFB_TypeKind zT_9;
    unsigned char zT_15;
    unsigned char zT_16;
    unsigned int zT_17 = 0;
    zT_D155D06D_Type hty;
    zT_6 = reg->types_items;
    zT_7 = (unsigned int)semantic_tid;
    zT_8 = zT_6[zT_7];
    hty = zT_8;
    zT_9 = hty.kind;
    if ((unsigned char)(zT_9 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((unsigned char)(width_bits != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(semantic_tid == (unsigned int)(18))) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_15 = width_bits;
    zT_16 = is_signed;
    zT_17 = zF_453BF522_carrierFromFacts(zT_15, zT_16);
    return zT_17;
    z_bb_4:
    if ((unsigned char)(value <= (zT_79FAE712_u64)(2147483647))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned int)(6);
    z_bb_6:
    if ((unsigned char)(value <= (zT_79FAE712_u64)(4294967295u))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(10);
    z_bb_8:
    return (unsigned int)(11);
    z_bb_9:
    return (unsigned int)(13);
    z_bb_10:
    return semantic_tid;
}

/* spellInstOrd */
unsigned int zF_DD416DF8_spellInstOrd(zT_BBC23664_LirFunction* lir_fn, unsigned int bb_idx, unsigned int ii) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_8;
    zT_88A68B1A_BasicBlock* zT_9;
    zT_88A68B1A_BasicBlock zT_10;
    zT_DAE4631D_LirInstArrayList zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int ord;
    unsigned int bi;
    zT_4 = 0;
    ord = zT_4;
    zT_6 = 0;
    bi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(bi < bb_idx)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = lir_fn->blocks;
    zT_9 = zT_8.items;
    zT_10 = zT_9[bi];
    zT_11 = zT_10.insts;
    zT_12 = zT_11.len;
    zT_13 = ord + zT_12;
    ord = zT_13;
    goto z_bb_4;
    z_bb_3:
    zT_16 = ord + ii;
    ord = zT_16;
    return (unsigned int)((unsigned int)ord);
    z_bb_4:
    zT_15 = bi + (unsigned int)(1);
    bi = zT_15;
    goto z_bb_1;
}

/* spellPlanGrow */
void zF_E2B88A09_spellPlanGrow(zT_1317DCD6_C89SpellPlan* plan, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_12;
    zT_E1B9232E_EU_442 zT_18 = {0};
    unsigned char zT_19;
    unsigned char* zT_20;
    zT_3E40CD83_Sand* zT_23;
    zT_E1B9232E_EU_442 zT_29 = {0};
    unsigned char zT_30;
    unsigned char* zT_31;
    zT_3E40CD83_Sand* zT_34;
    zT_E1B9232E_EU_442 zT_40 = {0};
    unsigned char zT_41;
    unsigned char* zT_42;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int* zT_48;
    unsigned int zT_49;
    unsigned int* zT_50;
    zT_21D3708C_U32ToU32Map* zT_51;
    zT_21D3708C_U32ToU32Map zT_52;
    zT_21D3708C_U32ToU32Map* zT_53;
    zT_21D3708C_U32ToU32Map* zT_54;
    zT_21D3708C_U32ToU32Map zT_55;
    zT_21D3708C_U32ToU32Map* zT_56;
    unsigned int zT_58;
    unsigned int new_cap;
    unsigned char* raw_keys;
    unsigned char* raw_maps;
    unsigned char* raw_uac;
    unsigned int ndi;
    zT_3 = plan->fn_cap;
    if ((unsigned char)(zT_3 < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_8 = plan->fn_cap;
    zT_6 = zT_8 * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_6;
    zT_12 = alloc;
    zT_18 = zF_1395EB68_sandAlloc(zT_12, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_19 = zT_18.is_error;
    if (zT_19) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_20 = zT_18.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_keys = zT_20;
    zT_23 = alloc;
    zT_29 = zF_1395EB68_sandAlloc(zT_23, (unsigned int)((unsigned int)(24) * new_cap), (unsigned int)(4));
    zT_30 = zT_29.is_error;
    if (zT_30) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_31 = zT_29.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_maps = zT_31;
    zT_34 = alloc;
    zT_40 = zF_1395EB68_sandAlloc(zT_34, (unsigned int)((unsigned int)(24) * new_cap), (unsigned int)(4));
    zT_41 = zT_40.is_error;
    if (zT_41) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_42 = zT_40.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_uac = zT_42;
    zT_45 = 0;
    ndi = zT_45;
    goto z_bb_13;
    z_bb_13:
    zT_46 = plan->fn_count;
    if ((unsigned char)(ndi < zT_46)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_48 = plan->fn_keys;
    zT_49 = zT_48[ndi];
    zT_50 = (unsigned int*)raw_keys;
    zT_50[ndi] = zT_49;
    zT_51 = plan->fn_maps;
    zT_52 = zT_51[ndi];
    zT_53 = (zT_21D3708C_U32ToU32Map*)raw_maps;
    zT_53[ndi] = zT_52;
    zT_54 = plan->uac_maps;
    zT_55 = zT_54[ndi];
    zT_56 = (zT_21D3708C_U32ToU32Map*)raw_uac;
    zT_56[ndi] = zT_55;
    goto z_bb_16;
    z_bb_15:
    plan->fn_keys = (unsigned int*)((unsigned int*)raw_keys);
    plan->fn_maps = (zT_21D3708C_U32ToU32Map*)((zT_21D3708C_U32ToU32Map*)raw_maps);
    plan->uac_maps = (zT_21D3708C_U32ToU32Map*)((zT_21D3708C_U32ToU32Map*)raw_uac);
    plan->fn_cap = new_cap;
    return;
    z_bb_16:
    zT_58 = ndi + (unsigned int)(1);
    ndi = zT_58;
    goto z_bb_13;
}

/* spellPlanInit */
void zF_D67A348C_spellPlanInit(zT_1317DCD6_C89SpellPlan* plan, zT_3E40CD83_Sand* alloc, unsigned int fn_hint) {
    int zT_3;
    int zT_4;
    int zT_5;
    int zT_8;
    zT_3E40CD83_Sand* zT_10;
    zT_21D3708C_U32ToU32Map zT_14 = {0};
    zT_3E40CD83_Sand* zT_18;
    zT_E1B9232E_EU_442 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_3E40CD83_Sand* zT_29;
    zT_E1B9232E_EU_442 zT_35 = {0};
    unsigned char zT_36;
    unsigned char* zT_37;
    zT_3E40CD83_Sand* zT_40;
    zT_E1B9232E_EU_442 zT_46 = {0};
    unsigned char zT_47;
    unsigned char* zT_48;
    unsigned char* raw_keys;
    unsigned char* raw_maps;
    unsigned char* raw_uac;
    zT_3 = 0;
    plan->fn_keys = (unsigned int*)zT_3;
    zT_4 = 0;
    plan->fn_maps = (zT_21D3708C_U32ToU32Map*)zT_4;
    zT_5 = 0;
    plan->uac_maps = (zT_21D3708C_U32ToU32Map*)zT_5;
    plan->fn_count = (unsigned int)(0);
    plan->fn_cap = (unsigned int)(0);
    zT_8 = 0;
    plan->typedef_order = (unsigned int*)zT_8;
    plan->typedef_order_len = (unsigned int)(0);
    zT_10 = alloc;
    zT_14 = zF_619D56E6_u32ToU32MapInitCap(zT_10, (unsigned int)(fn_hint + (unsigned int)(8)));
    plan->fn_key_index = zT_14;
    if ((unsigned char)(fn_hint != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_18, (unsigned int)((unsigned int)(4) * fn_hint), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_26 = zT_24.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw_keys = zT_26;
    zT_29 = alloc;
    zT_35 = zF_1395EB68_sandAlloc(zT_29, (unsigned int)((unsigned int)(24) * fn_hint), (unsigned int)(4));
    zT_36 = zT_35.is_error;
    if (zT_36) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_37 = zT_35.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_maps = zT_37;
    zT_40 = alloc;
    zT_46 = zF_1395EB68_sandAlloc(zT_40, (unsigned int)((unsigned int)(24) * fn_hint), (unsigned int)(4));
    zT_47 = zT_46.is_error;
    if (zT_47) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_48 = zT_46.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_uac = zT_48;
    plan->fn_keys = (unsigned int*)((unsigned int*)raw_keys);
    plan->fn_maps = (zT_21D3708C_U32ToU32Map*)((zT_21D3708C_U32ToU32Map*)raw_maps);
    plan->uac_maps = (zT_21D3708C_U32ToU32Map*)((zT_21D3708C_U32ToU32Map*)raw_uac);
    plan->fn_cap = fn_hint;
    goto z_bb_2;
}

/* spellPlanPlanFn */
void zF_72205F3D_spellPlanPlanFn(zT_1317DCD6_C89SpellPlan* plan, zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg, unsigned int fn_key, zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_5;
    unsigned int zT_6;
    zT_1317DCD6_C89SpellPlan* zT_8;
    zT_3E40CD83_Sand* zT_9;
    unsigned int zT_11;
    unsigned int* zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_5D72FBF8_TempDeclArrayList zT_15;
    unsigned int zT_16;
    zT_21D3708C_U32ToU32Map zT_19 = {0};
    zT_21D3708C_U32ToU32Map* zT_20;
    zT_3E40CD83_Sand* zT_21;
    zT_5D72FBF8_TempDeclArrayList zT_23;
    unsigned int zT_24;
    zT_21D3708C_U32ToU32Map zT_27 = {0};
    zT_21D3708C_U32ToU32Map* zT_28;
    zT_21D3708C_U32ToU32Map* zT_31;
    unsigned int zT_32;
    zT_BAEE192E_Opt_10 zT_34 = {0};
    unsigned char zT_35;
    zT_21D3708C_U32ToU32Map* zT_37;
    unsigned int zT_38;
    unsigned int zT_43;
    unsigned int zT_45;
    zT_5D72FBF8_TempDeclArrayList zT_46;
    unsigned int zT_47;
    zT_5D72FBF8_TempDeclArrayList zT_50;
    zT_1937645B_TempDecl* zT_51;
    zT_1937645B_TempDecl zT_52;
    unsigned int zT_53;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned int zT_59;
    zT_3E40CD83_Sand* zT_61;
    zT_E1B9232E_EU_442 zT_68 = {0};
    unsigned char zT_69;
    unsigned char* zT_70;
    unsigned int* zT_73;
    unsigned int zT_75;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_80;
    unsigned int zT_81;
    zT_5D72FBF8_TempDeclArrayList zT_82;
    unsigned int zT_83;
    zT_5D72FBF8_TempDeclArrayList zT_86;
    zT_1937645B_TempDecl* zT_87;
    zT_1937645B_TempDecl zT_88;
    unsigned int zT_89;
    unsigned char zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned int zT_101;
    unsigned int zT_103;
    unsigned int zT_105;
    zT_1CF28CA3_BasicBlockArrayList zT_106;
    unsigned int zT_107;
    zT_1CF28CA3_BasicBlockArrayList zT_110;
    zT_88A68B1A_BasicBlock* zT_111;
    zT_88A68B1A_BasicBlock* zT_112;
    unsigned int zT_114;
    zT_DAE4631D_LirInstArrayList zT_115;
    unsigned int zT_116;
    zT_DAE4631D_LirInstArrayList zT_119;
    zT_6BA597BC_LirInst* zT_120;
    zT_6BA597BC_LirInst zT_121;
    unsigned int zT_123;
    zT_79FAE712_u64 zT_125;
    unsigned char zT_127;
    unsigned char zT_129;
    unsigned char zT_131;
    unsigned char zT_133;
    unsigned char zT_135;
    unsigned int zT_137;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_142;
    zT_79FAE712_u64 zT_143;
    unsigned char zT_144;
    unsigned char zT_145;
    unsigned char zT_146;
    unsigned int zT_148;
    unsigned char zT_149;
    unsigned char zT_150;
    unsigned char zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_155;
    unsigned char zT_156;
    unsigned int zT_158;
    unsigned char zT_159;
    unsigned char zT_162;
    unsigned int zT_166;
    unsigned int zT_169;
    unsigned int zT_170;
    zT_5D72FBF8_TempDeclArrayList zT_173;
    zT_1937645B_TempDecl* zT_174;
    unsigned int zT_175;
    zT_1937645B_TempDecl zT_176;
    unsigned int zT_177;
    zT_338B7C76_TypeRegistry* zT_181;
    unsigned int zT_182;
    zT_79FAE712_u64 zT_183;
    unsigned char zT_184;
    unsigned char zT_185;
    unsigned int zT_186 = 0;
    unsigned int zT_189;
    zT_21D3708C_U32ToU32Map* zT_190;
    unsigned char zT_195;
    unsigned char zT_198;
    zT_BBC23664_LirFunction* zT_202;
    unsigned int* zT_203;
    unsigned int zT_204;
    unsigned int zT_205;
    unsigned int zT_206 = 0;
    zT_BBC23664_LirFunction* zT_208;
    unsigned int* zT_209;
    unsigned int zT_210;
    unsigned int zT_211;
    unsigned int zT_212 = 0;
    zT_338B7C76_TypeRegistry* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    unsigned char zT_217 = 0;
    zT_21D3708C_U32ToU32Map* zT_223;
    unsigned int zT_228;
    unsigned int zT_230;
    unsigned int zT_232;
    unsigned int fi;
    unsigned int t2pos_max;
    unsigned int tm_i;
    zT_1937645B_TempDecl tm_td;
    unsigned char* t2pos_raw;
    unsigned int* t2pos;
    unsigned int tpi;
    unsigned int ord;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    unsigned int result;
    zT_79FAE712_u64 value;
    unsigned char ic_width;
    unsigned char ic_signed;
    unsigned char plan_kind;
    unsigned char uac_kind;
    unsigned char uac_op;
    unsigned int uac_lhs;
    unsigned int uac_rhs;
    zT_3B233392_anon_103516 ic;
    zT_B5BA9371_anon_103272 b;
    zT_29D1105C_anon_103280 u;
    zT_CF919E50_anon_103468 c;
    unsigned int ht;
    unsigned int hpos;
    unsigned int carrier;
    unsigned int l_tyid;
    unsigned int r_tyid;
    unsigned char prom_side;
    zT_5 = plan->fn_count;
    zT_6 = plan->fn_cap;
    if ((unsigned char)(zT_5 >= zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = plan;
    zT_9 = alloc;
    zF_E2B88A09_spellPlanGrow(zT_8, zT_9);
    goto z_bb_2;
    z_bb_2:
    zT_11 = plan->fn_count;
    fi = zT_11;
    zT_12 = plan->fn_keys;
    zT_12[fi] = fn_key;
    zT_13 = alloc;
    zT_15 = lir_fn->hoisted_temps;
    zT_16 = zT_15.len;
    zT_19 = zF_619D56E6_u32ToU32MapInitCap(zT_13, (unsigned int)(zT_16 + (unsigned int)(16)));
    zT_20 = plan->fn_maps;
    zT_20[fi] = zT_19;
    zT_21 = alloc;
    zT_23 = lir_fn->hoisted_temps;
    zT_24 = zT_23.len;
    zT_27 = zF_619D56E6_u32ToU32MapInitCap(zT_21, (unsigned int)(zT_24 + (unsigned int)(16)));
    zT_28 = plan->uac_maps;
    zT_28[fi] = zT_27;
    plan->fn_count = (unsigned int)(fi + (unsigned int)(1));
    zT_31 = &plan->fn_key_index;
    zT_32 = fn_key;
    zT_34 = zF_F3EE5998_u32ToU32MapGet(zT_31, zT_32);
    zT_35 = zT_34.has_value;
    if ((unsigned char)(!zT_35)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_37 = &plan->fn_key_index;
    zT_38 = fn_key;
    zF_26476265_u32ToU32MapPut(zT_37, zT_38, (unsigned int)((unsigned int)fi));
    goto z_bb_4;
    z_bb_4:
    zT_43 = 1;
    t2pos_max = zT_43;
    zT_45 = 0;
    tm_i = zT_45;
    goto z_bb_5;
    z_bb_5:
    zT_46 = lir_fn->hoisted_temps;
    zT_47 = zT_46.len;
    if ((unsigned char)(tm_i < zT_47)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_50 = lir_fn->hoisted_temps;
    zT_51 = zT_50.items;
    zT_52 = zT_51[tm_i];
    tm_td = zT_52;
    zT_53 = tm_td.temp_id;
    if ((unsigned char)(zT_53 >= t2pos_max)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_61 = alloc;
    zT_68 = zF_1395EB68_sandAlloc(zT_61, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)t2pos_max)), (unsigned int)(4));
    zT_69 = zT_68.is_error;
    if (zT_69) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_59 = tm_i + (unsigned int)(1);
    tm_i = zT_59;
    goto z_bb_5;
    z_bb_9:
    zT_55 = tm_td.temp_id;
    zT_57 = zT_55 + (unsigned int)(1);
    t2pos_max = zT_57;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_70 = zT_68.data.payload;
    goto z_bb_13;
    z_bb_13:
    t2pos_raw = zT_70;
    zT_73 = (unsigned int*)t2pos_raw;
    t2pos = zT_73;
    zT_75 = 0;
    tpi = zT_75;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(tpi < t2pos_max)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_77 = 4294967295u;
    zT_78 = (unsigned int)tpi;
    t2pos[zT_78] = zT_77;
    goto z_bb_17;
    z_bb_16:
    zT_81 = 0;
    tm_i = zT_81;
    goto z_bb_18;
    z_bb_17:
    zT_80 = tpi + (unsigned int)(1);
    tpi = zT_80;
    goto z_bb_14;
    z_bb_18:
    zT_82 = lir_fn->hoisted_temps;
    zT_83 = zT_82.len;
    if ((unsigned char)(tm_i < zT_83)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_86 = lir_fn->hoisted_temps;
    zT_87 = zT_86.items;
    zT_88 = zT_87[tm_i];
    tm_td = zT_88;
    zT_89 = tm_td.temp_id;
    if ((unsigned char)(zT_89 < t2pos_max)) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    zT_103 = 0;
    ord = zT_103;
    zT_105 = 0;
    bi = zT_105;
    goto z_bb_27;
    z_bb_21:
    zT_101 = tm_i + (unsigned int)(1);
    tm_i = zT_101;
    goto z_bb_18;
    z_bb_22:
    zT_92 = tm_td.temp_id;
    zT_93 = (unsigned int)zT_92;
    zT_94 = t2pos[zT_93];
    zT_91 = zT_94 == (unsigned int)(4294967295u);
    goto z_bb_24;
    z_bb_23:
    zT_91 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_91) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_97 = (unsigned int)tm_i;
    zT_98 = tm_td.temp_id;
    zT_99 = (unsigned int)zT_98;
    t2pos[zT_99] = zT_97;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_106 = lir_fn->blocks;
    zT_107 = zT_106.len;
    if ((unsigned char)(bi < zT_107)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_110 = lir_fn->blocks;
    zT_111 = zT_110.items;
    zT_112 = zT_111 + bi;
    bb = zT_112;
    zT_114 = 0;
    ii = zT_114;
    goto z_bb_31;
    z_bb_29:
    return;
    z_bb_30:
    zT_232 = bi + (unsigned int)(1);
    bi = zT_232;
    goto z_bb_27;
    z_bb_31:
    zT_115 = bb->insts;
    zT_116 = zT_115.len;
    if ((unsigned char)(ii < zT_116)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_119 = bb->insts;
    zT_120 = zT_119.items;
    zT_121 = zT_120[ii];
    inst = zT_121;
    zT_123 = 4294967295u;
    result = zT_123;
    zT_125 = 0;
    value = zT_125;
    zT_127 = 0;
    ic_width = zT_127;
    zT_129 = 0;
    ic_signed = zT_129;
    zT_131 = 0;
    plan_kind = zT_131;
    zT_133 = 0;
    uac_kind = zT_133;
    zT_135 = 0;
    uac_op = zT_135;
    zT_137 = 0;
    uac_lhs = zT_137;
    zT_139 = 0;
    uac_rhs = zT_139;
    zT_140 = inst.tag;
switch (zT_140) {
case 44: goto z_bb_35;
case 12: goto z_bb_36;
case 13: goto z_bb_37;
case 38: goto z_bb_38;
default: goto z_bb_39;
}
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_230 = ii + (unsigned int)(1);
    ii = zT_230;
    goto z_bb_31;
    z_bb_35:
    ic = inst.payload.int_const._0;
    zT_142 = ic.result;
    result = zT_142;
    zT_143 = ic.value;
    value = zT_143;
    zT_144 = ic.width_bits;
    ic_width = zT_144;
    zT_145 = ic.is_signed;
    ic_signed = zT_145;
    zT_146 = 1;
    plan_kind = zT_146;
    goto z_bb_41;
    z_bb_36:
    b = inst.payload.binary._0;
    zT_148 = b.result;
    result = zT_148;
    zT_149 = 1;
    plan_kind = zT_149;
    zT_150 = 1;
    uac_kind = zT_150;
    zT_151 = b.op;
    uac_op = zT_151;
    zT_152 = b.lhs;
    uac_lhs = zT_152;
    zT_153 = b.rhs;
    uac_rhs = zT_153;
    goto z_bb_41;
    z_bb_37:
    u = inst.payload.unary._0;
    zT_155 = u.result;
    result = zT_155;
    zT_156 = 1;
    plan_kind = zT_156;
    goto z_bb_41;
    z_bb_38:
    c = inst.payload.int_cast._0;
    zT_158 = c.result;
    result = zT_158;
    zT_159 = 1;
    plan_kind = zT_159;
    goto z_bb_41;
    z_bb_39:
    goto z_bb_41;
    z_bb_41:
    if ((unsigned char)(plan_kind != (unsigned char)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_162 = result != (unsigned int)(4294967295u);
    goto z_bb_44;
    z_bb_43:
    zT_162 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_162) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_166 = 4294967295u;
    ht = zT_166;
    if ((unsigned char)(result < t2pos_max)) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    if ((unsigned char)(uac_kind != (unsigned char)(0))) goto z_bb_53; else goto z_bb_54;
    z_bb_47:
    zT_169 = (unsigned int)result;
    zT_170 = t2pos[zT_169];
    hpos = zT_170;
    if ((unsigned char)(hpos != (unsigned int)(4294967295u))) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    if ((unsigned char)(ht != (unsigned int)(4294967295u))) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    zT_173 = lir_fn->hoisted_temps;
    zT_174 = zT_173.items;
    zT_175 = (unsigned int)hpos;
    zT_176 = zT_174[zT_175];
    zT_177 = zT_176.type_id;
    ht = zT_177;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_181 = reg;
    zT_182 = ht;
    zT_183 = value;
    zT_184 = ic_width;
    zT_185 = ic_signed;
    zT_186 = zF_48A5B64F_deriveConstCarrier(zT_181, zT_182, zT_183, zT_184, zT_185);
    carrier = zT_186;
    zT_190 = plan->fn_maps;
    zT_189 = carrier;
    zF_26476265_u32ToU32MapPut((zT_21D3708C_U32ToU32Map*)(zT_190 + fi), (unsigned int)((unsigned int)ord), zT_189);
    goto z_bb_52;
    z_bb_52:
    goto z_bb_46;
    z_bb_53:
    zT_195 = uac_op >= (unsigned char)(10);
    goto z_bb_55;
    z_bb_54:
    zT_195 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_195) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_198 = uac_op < (unsigned char)(16);
    goto z_bb_58;
    z_bb_57:
    zT_198 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_198) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_202 = lir_fn;
    zT_203 = t2pos;
    zT_204 = t2pos_max;
    zT_205 = uac_lhs;
    zT_206 = zF_F9C1339C_hoistedEffType(zT_202, zT_203, zT_204, zT_205);
    l_tyid = zT_206;
    zT_208 = lir_fn;
    zT_209 = t2pos;
    zT_210 = t2pos_max;
    zT_211 = uac_rhs;
    zT_212 = zF_F9C1339C_hoistedEffType(zT_208, zT_209, zT_210, zT_211);
    r_tyid = zT_212;
    zT_214 = reg;
    zT_215 = l_tyid;
    zT_216 = r_tyid;
    zT_217 = zF_12E895CF_uacPromoteSide(zT_214, zT_215, zT_216);
    prom_side = zT_217;
    if ((unsigned char)(prom_side < (unsigned char)(2))) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    zT_228 = ord + (unsigned int)(1);
    ord = zT_228;
    goto z_bb_34;
    z_bb_61:
    zT_223 = plan->uac_maps;
    zF_26476265_u32ToU32MapPut((zT_21D3708C_U32ToU32Map*)(zT_223 + fi), (unsigned int)((unsigned int)ord), (unsigned int)((unsigned int)prom_side));
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
}

/* hoistedEffType */
unsigned int zF_F9C1339C_hoistedEffType(zT_BBC23664_LirFunction* lir_fn, unsigned int* t2pos, unsigned int t2pos_max, unsigned int temp_id) {
    unsigned int zT_7;
    unsigned int zT_8;
    zT_5D72FBF8_TempDeclArrayList zT_13;
    zT_1937645B_TempDecl* zT_14;
    unsigned int zT_15;
    zT_1937645B_TempDecl zT_16;
    unsigned int zT_17;
    unsigned char zT_20;
    unsigned int p;
    unsigned int eff;
    if ((unsigned char)(temp_id >= t2pos_max)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_7 = (unsigned int)temp_id;
    zT_8 = t2pos[zT_7];
    p = zT_8;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_13 = lir_fn->hoisted_temps;
    zT_14 = zT_13.items;
    zT_15 = (unsigned int)p;
    zT_16 = zT_14[zT_15];
    zT_17 = zT_16.type_id;
    eff = zT_17;
    if ((unsigned char)(eff != (unsigned int)(4294967295u))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = eff != (unsigned int)(1);
    goto z_bb_7;
    z_bb_6:
    zT_20 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_20) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return eff;
    z_bb_9:
    return (unsigned int)(0);
}

/* uacPromoteSide */
unsigned char zF_12E895CF_uacPromoteSide(zT_338B7C76_TypeRegistry* reg, unsigned int l_tyid, unsigned int r_tyid) {
    signed char zT_4;
    signed char zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    signed char zT_11 = 0;
    zT_338B7C76_TypeRegistry* zT_14;
    unsigned int zT_15;
    signed char zT_16 = 0;
    unsigned char zT_19;
    zT_338B7C76_TypeRegistry* zT_22;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned int zT_27 = 0;
    unsigned char zT_32;
    zT_338B7C76_TypeRegistry* zT_35;
    unsigned int zT_36;
    unsigned int zT_37 = 0;
    zT_338B7C76_TypeRegistry* zT_38;
    unsigned int zT_39;
    unsigned int zT_40 = 0;
    signed char l_sgn;
    signed char r_sgn;
    zT_4 = (signed char)-1;
    l_sgn = zT_4;
    zT_6 = (signed char)-1;
    r_sgn = zT_6;
    if ((unsigned char)(l_tyid != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = reg;
    zT_10 = l_tyid;
    zT_11 = zF_DE90B14C_typeRegistryIntSign(zT_9, zT_10);
    l_sgn = zT_11;
    goto z_bb_2;
    z_bb_2:
    if ((unsigned char)(r_tyid != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = reg;
    zT_15 = r_tyid;
    zT_16 = zF_DE90B14C_typeRegistryIntSign(zT_14, zT_15);
    r_sgn = zT_16;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(l_sgn == (signed char)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = r_sgn == (signed char)(0);
    goto z_bb_7;
    z_bb_6:
    zT_19 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_19) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_22 = reg;
    zT_23 = r_tyid;
    zT_24 = zF_47244FDF_typeRegistryIntByte(zT_22, zT_23);
    zT_25 = reg;
    zT_26 = l_tyid;
    zT_27 = zF_47244FDF_typeRegistryIntByte(zT_25, zT_26);
    if ((unsigned char)(zT_24 >= zT_27)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return (unsigned char)(2);
    z_bb_10:
    if ((unsigned char)(l_sgn == (signed char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_32 = r_sgn == (signed char)(1);
    goto z_bb_15;
    z_bb_14:
    zT_32 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_32) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_35 = reg;
    zT_36 = l_tyid;
    zT_37 = zF_47244FDF_typeRegistryIntByte(zT_35, zT_36);
    zT_38 = reg;
    zT_39 = r_tyid;
    zT_40 = zF_47244FDF_typeRegistryIntByte(zT_38, zT_39);
    if ((unsigned char)(zT_37 >= zT_40)) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_9;
    z_bb_18:
    return (unsigned char)(1);
    z_bb_19:
    goto z_bb_17;
}

/* spellPlanUac */
zT_BAEE192E_Opt_10 zF_54BC5F51_spellPlanUac(zT_1317DCD6_C89SpellPlan* plan, unsigned int fn_key, unsigned int inst_ord) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_10;
    zT_21D3708C_U32ToU32Map* zT_11;
    zT_BAEE192E_Opt_10 zT_14 = {0};
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned int fi_v;
    zT_3 = &plan->fn_key_index;
    zT_4 = fn_key;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    fi_v = zT_6.value;
    zT_11 = plan->uac_maps;
    zT_10 = inst_ord;
    zT_14 = zF_F3EE5998_u32ToU32MapGet((zT_21D3708C_U32ToU32Map*)(zT_11 + (unsigned int)((unsigned int)fi_v)), zT_10);
    return zT_14;
    z_bb_2:
    zT_15.has_value = 0;
    return zT_15;
}

/* spellPlanCarrier */
zT_BAEE192E_Opt_10 zF_1AA43196_spellPlanCarrier(zT_1317DCD6_C89SpellPlan* plan, unsigned int fn_key, unsigned int inst_ord) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    unsigned int zT_10;
    zT_21D3708C_U32ToU32Map* zT_11;
    zT_BAEE192E_Opt_10 zT_14 = {0};
    zT_BAEE192E_Opt_10 zT_15 = {0};
    unsigned int fi_v;
    zT_3 = &plan->fn_key_index;
    zT_4 = fn_key;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    fi_v = zT_6.value;
    zT_11 = plan->fn_maps;
    zT_10 = inst_ord;
    zT_14 = zF_F3EE5998_u32ToU32MapGet((zT_21D3708C_U32ToU32Map*)(zT_11 + (unsigned int)((unsigned int)fi_v)), zT_10);
    return zT_14;
    z_bb_2:
    zT_15.has_value = 0;
    return zT_15;
}

/* tstTopologicalSort */
unsigned int* zF_1DD26D63_tstTopologicalSort(zT_338B7C76_TypeRegistry* reg, zT_3E40CD83_Sand* alloc) {
    unsigned int zT_3;
    zT_3E40CD83_Sand* zT_5;
    int zT_8;
    int zT_10;
    zT_E1B9232E_EU_442 zT_12 = {0};
    unsigned char zT_13;
    unsigned char* zT_14;
    unsigned int* zT_17;
    unsigned int zT_19;
    zT_3E40CD83_Sand* zT_21;
    int zT_24;
    int zT_26;
    zT_E1B9232E_EU_442 zT_28 = {0};
    unsigned char zT_29;
    unsigned char* zT_30;
    unsigned int* zT_33;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    unsigned int* zT_38;
    unsigned int zT_39 = 0;
    unsigned int zT_40;
    int zT_41;
    unsigned int zT_43;
    zT_3E40CD83_Sand* zT_45;
    int zT_48;
    int zT_50;
    zT_E1B9232E_EU_442 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int* zT_57;
    zT_3E40CD83_Sand* zT_59;
    int zT_62;
    int zT_64;
    zT_E1B9232E_EU_442 zT_66 = {0};
    unsigned char zT_67;
    unsigned char* zT_68;
    unsigned int* zT_71;
    zT_3E40CD83_Sand* zT_73;
    int zT_76;
    int zT_78;
    zT_E1B9232E_EU_442 zT_80 = {0};
    unsigned char zT_81;
    unsigned char* zT_82;
    unsigned char* zT_85;
    unsigned int zT_87;
    unsigned char zT_89;
    int zT_90;
    unsigned int zT_92;
    int zT_94;
    unsigned int zT_95;
    int zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned int zT_102;
    unsigned int zT_103;
    int zT_104;
    int zT_106;
    unsigned int zT_108;
    int zT_109;
    unsigned int zT_111;
    int zT_113;
    unsigned int zT_114;
    unsigned int zT_117;
    int zT_118;
    unsigned int zT_120;
    int zT_121;
    unsigned int zT_123;
    unsigned char zT_124;
    unsigned int zT_125;
    unsigned int zT_127;
    zT_338B7C76_TypeRegistry* zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned char zT_133 = 0;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_138;
    unsigned int zT_139;
    int zT_140;
    int zT_142;
    unsigned int zT_144;
    int zT_145;
    unsigned int zT_147;
    unsigned int zT_149;
    unsigned char zT_151;
    unsigned int zT_154;
    int zT_155;
    unsigned int zT_157;
    int zT_158;
    unsigned int zT_160;
    unsigned int tl;
    unsigned char* indegree_raw;
    unsigned int* indegree;
    unsigned int ti;
    unsigned char* edge_raw;
    unsigned int* edge_buf;
    unsigned char* result_raw;
    unsigned int* result;
    unsigned char* queue_raw;
    unsigned int* queue;
    unsigned char* popped_raw;
    unsigned char* popped;
    unsigned int zi;
    unsigned int qhead;
    unsigned int qtail;
    unsigned int ri;
    unsigned int cur;
    unsigned int tj;
    unsigned int ai;
    unsigned int idx;
    zT_3 = reg->types_len;
    tl = zT_3;
    zT_5 = alloc;
    zT_8 = 4;
    zT_10 = 4;
    zT_12 = zF_1395EB68_sandAlloc(zT_5, (unsigned int)(zT_8 * tl), (unsigned int)((unsigned int)zT_10));
    zT_13 = zT_12.is_error;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_14 = zT_12.data.payload;
    goto z_bb_3;
    z_bb_3:
    indegree_raw = zT_14;
    zT_17 = (unsigned int*)indegree_raw;
    indegree = zT_17;
    zT_19 = 0;
    ti = zT_19;
    zT_21 = alloc;
    zT_24 = 4;
    zT_26 = 4;
    zT_28 = zF_1395EB68_sandAlloc(zT_21, (unsigned int)(zT_24 * tl), (unsigned int)((unsigned int)zT_26));
    zT_29 = zT_28.is_error;
    if (zT_29) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_30 = zT_28.data.payload;
    goto z_bb_6;
    z_bb_6:
    edge_raw = zT_30;
    zT_33 = (unsigned int*)edge_raw;
    edge_buf = zT_33;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)((unsigned int)((unsigned int)ti) < tl)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_36 = reg;
    zT_37 = ti;
    zT_38 = edge_buf;
    zT_39 = zF_F41AC8EB_typeRefs(zT_36, zT_37, zT_38);
    zT_40 = (unsigned int)ti;
    indegree[zT_40] = zT_39;
    goto z_bb_10;
    z_bb_9:
    zT_45 = alloc;
    zT_48 = 4;
    zT_50 = 4;
    zT_52 = zF_1395EB68_sandAlloc(zT_45, (unsigned int)(zT_48 * tl), (unsigned int)((unsigned int)zT_50));
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_41 = 1;
    zT_43 = ti + (unsigned int)((unsigned int)zT_41);
    ti = zT_43;
    goto z_bb_7;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_54 = zT_52.data.payload;
    goto z_bb_13;
    z_bb_13:
    result_raw = zT_54;
    zT_57 = (unsigned int*)result_raw;
    result = zT_57;
    zT_59 = alloc;
    zT_62 = 4;
    zT_64 = 4;
    zT_66 = zF_1395EB68_sandAlloc(zT_59, (unsigned int)(zT_62 * tl), (unsigned int)((unsigned int)zT_64));
    zT_67 = zT_66.is_error;
    if (zT_67) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    pal_trap();
    z_bb_15:
    zT_68 = zT_66.data.payload;
    goto z_bb_16;
    z_bb_16:
    queue_raw = zT_68;
    zT_71 = (unsigned int*)queue_raw;
    queue = zT_71;
    zT_73 = alloc;
    zT_76 = 1;
    zT_78 = 1;
    zT_80 = zF_1395EB68_sandAlloc(zT_73, (unsigned int)(zT_76 * tl), (unsigned int)((unsigned int)zT_78));
    zT_81 = zT_80.is_error;
    if (zT_81) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    pal_trap();
    z_bb_18:
    zT_82 = zT_80.data.payload;
    goto z_bb_19;
    z_bb_19:
    popped_raw = zT_82;
    zT_85 = (unsigned char*)popped_raw;
    popped = zT_85;
    zT_87 = 0;
    zi = zT_87;
    goto z_bb_20;
    z_bb_20:
    if ((unsigned char)(zi < tl)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_89 = 0;
    popped[zi] = zT_89;
    goto z_bb_23;
    z_bb_22:
    zT_94 = 0;
    zT_95 = (unsigned int)zT_94;
    qhead = zT_95;
    zT_97 = 0;
    zT_98 = (unsigned int)zT_97;
    qtail = zT_98;
    zT_99 = 0;
    ti = zT_99;
    goto z_bb_24;
    z_bb_23:
    zT_90 = 1;
    zT_92 = zi + (unsigned int)((unsigned int)zT_90);
    zi = zT_92;
    goto z_bb_20;
    z_bb_24:
    if ((unsigned char)((unsigned int)((unsigned int)ti) < tl)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_102 = (unsigned int)ti;
    zT_103 = indegree[zT_102];
    zT_104 = 0;
    if ((unsigned char)(zT_103 == (unsigned int)zT_104)) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_113 = 0;
    zT_114 = (unsigned int)zT_113;
    ri = zT_114;
    goto z_bb_30;
    z_bb_27:
    zT_109 = 1;
    zT_111 = ti + (unsigned int)((unsigned int)zT_109);
    ti = zT_111;
    goto z_bb_24;
    z_bb_28:
    queue[qtail] = ti;
    zT_106 = 1;
    zT_108 = qtail + (unsigned int)((unsigned int)zT_106);
    qtail = zT_108;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    if ((unsigned char)(qhead < qtail)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_117 = queue[qhead];
    cur = zT_117;
    zT_118 = 1;
    zT_120 = qhead + (unsigned int)((unsigned int)zT_118);
    qhead = zT_120;
    result[ri] = cur;
    zT_121 = 1;
    zT_123 = ri + (unsigned int)((unsigned int)zT_121);
    ri = zT_123;
    zT_124 = 1;
    zT_125 = (unsigned int)cur;
    popped[zT_125] = zT_124;
    zT_127 = 0;
    tj = zT_127;
    goto z_bb_34;
    z_bb_32:
    zT_149 = 0;
    ai = zT_149;
    goto z_bb_42;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    if ((unsigned char)((unsigned int)((unsigned int)tj) < tl)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_130 = reg;
    zT_131 = tj;
    zT_132 = cur;
    zT_133 = zF_8A421992_typeRefsContains(zT_130, zT_131, zT_132);
    if (zT_133) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_33;
    z_bb_37:
    zT_145 = 1;
    zT_147 = tj + (unsigned int)((unsigned int)zT_145);
    tj = zT_147;
    goto z_bb_34;
    z_bb_38:
    zT_135 = (unsigned int)tj;
    idx = zT_135;
    zT_136 = indegree[idx];
    zT_138 = zT_136 - (unsigned int)(1);
    indegree[idx] = zT_138;
    zT_139 = indegree[idx];
    zT_140 = 0;
    if ((unsigned char)(zT_139 == (unsigned int)zT_140)) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_37;
    z_bb_40:
    queue[qtail] = tj;
    zT_142 = 1;
    zT_144 = qtail + (unsigned int)((unsigned int)zT_142);
    qtail = zT_144;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    if ((unsigned char)(ai < tl)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_151 = popped[ai];
    if ((unsigned char)(zT_151 == (unsigned char)(0))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    return result;
    z_bb_45:
    zT_158 = 1;
    zT_160 = ai + (unsigned int)((unsigned int)zT_158);
    ai = zT_160;
    goto z_bb_42;
    z_bb_46:
    zT_154 = (unsigned int)ai;
    result[ri] = zT_154;
    zT_155 = 1;
    zT_157 = ri + (unsigned int)((unsigned int)zT_155);
    ri = zT_157;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_45;
}

/* spellPlanPlanTypeOrder */
void zF_869C84A7_spellPlanPlanTypeOr(zT_1317DCD6_C89SpellPlan* plan, zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg) {
    zT_338B7C76_TypeRegistry* zT_3;
    zT_3E40CD83_Sand* zT_4;
    unsigned int* zT_5 = 0;
    unsigned int zT_6;
    zT_3 = reg;
    zT_4 = alloc;
    zT_5 = zF_1DD26D63_tstTopologicalSort(zT_3, zT_4);
    plan->typedef_order = zT_5;
    zT_6 = reg->types_len;
    plan->typedef_order_len = zT_6;
    return;
}

/* EOF */
