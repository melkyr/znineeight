#include "lexer_23F0DAD4.h"
#include <stdio.h>
zT_138FFB41_Lexer zG_138FFB41_Lexer;
/* lexerInit */
zT_138FFB41_Lexer zF_151E643F_lexerInit(zT_8F083A69_Slice_zT_0B42B2F8_u source, unsigned int file_id, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_3E40CD83_Sand* zT_6;
    zT_C6536882_EU_532 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    zT_47B162D1_U8ArrayList* zT_16;
    zT_3E40CD83_Sand* zT_17;
    zT_47B162D1_U8ArrayList zT_18 = {0};
    zT_138FFB41_Lexer zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    int zT_23;
    unsigned char* sb_raw;
    zT_47B162D1_U8ArrayList* sb_ptr;
    zT_6 = alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(16), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    sb_raw = zT_13;
    zT_16 = (zT_47B162D1_U8ArrayList*)sb_raw;
    sb_ptr = zT_16;
    zT_17 = alloc;
    zT_18 = zF_E9FF0E66_byteArrayListInit(zT_17);
    *sb_ptr = zT_18;
    zT_19.source = source;
    zT_20 = 0;
    zT_19.pos = zT_20;
    zT_21 = 1;
    zT_19.line = zT_21;
    zT_22 = 1;
    zT_19.col = zT_22;
    zT_19.file_id = file_id;
    zT_19.interner = interner;
    zT_19.diag = diag;
    zT_19.string_buf = sb_ptr;
    zT_23 = 0;
    zT_19.count_only = zT_23;
    return zT_19;
}

/* lexerNextToken */
zT_3A355BD2_Token zF_B976BEC9_lexerNextToken(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    zT_138FFB41_Lexer* zT_2;
    int zT_3 = 0;
    zT_138FFB41_Lexer* zT_4;
    unsigned int zT_6;
    zT_85CBA4DB_TokenValue zT_7;
    zT_85CBA4DB_TokenValue zT_12 = {0};
    zT_3A355BD2_Token zT_14 = {0};
    unsigned int zT_16;
    zT_138FFB41_Lexer* zT_18;
    unsigned char zT_19 = 0;
    zT_138FFB41_Lexer* zT_20;
    unsigned int zT_22;
    zT_85CBA4DB_TokenValue zT_23;
    zT_85CBA4DB_TokenValue zT_27 = {0};
    zT_3A355BD2_Token zT_29 = {0};
    zT_138FFB41_Lexer* zT_30;
    unsigned int zT_32;
    zT_85CBA4DB_TokenValue zT_33;
    zT_85CBA4DB_TokenValue zT_37 = {0};
    zT_3A355BD2_Token zT_39 = {0};
    zT_138FFB41_Lexer* zT_40;
    unsigned int zT_42;
    zT_85CBA4DB_TokenValue zT_43;
    zT_85CBA4DB_TokenValue zT_47 = {0};
    zT_3A355BD2_Token zT_49 = {0};
    zT_138FFB41_Lexer* zT_50;
    unsigned int zT_52;
    zT_85CBA4DB_TokenValue zT_53;
    zT_85CBA4DB_TokenValue zT_57 = {0};
    zT_3A355BD2_Token zT_59 = {0};
    zT_138FFB41_Lexer* zT_60;
    unsigned int zT_62;
    zT_85CBA4DB_TokenValue zT_63;
    zT_85CBA4DB_TokenValue zT_67 = {0};
    zT_3A355BD2_Token zT_69 = {0};
    zT_138FFB41_Lexer* zT_70;
    unsigned int zT_72;
    zT_85CBA4DB_TokenValue zT_73;
    zT_85CBA4DB_TokenValue zT_77 = {0};
    zT_3A355BD2_Token zT_79 = {0};
    zT_138FFB41_Lexer* zT_80;
    unsigned int zT_82;
    zT_85CBA4DB_TokenValue zT_83;
    zT_85CBA4DB_TokenValue zT_87 = {0};
    zT_3A355BD2_Token zT_89 = {0};
    zT_138FFB41_Lexer* zT_90;
    unsigned int zT_92;
    zT_85CBA4DB_TokenValue zT_93;
    zT_85CBA4DB_TokenValue zT_97 = {0};
    zT_3A355BD2_Token zT_99 = {0};
    zT_138FFB41_Lexer* zT_100;
    unsigned int zT_102;
    zT_85CBA4DB_TokenValue zT_103;
    zT_85CBA4DB_TokenValue zT_107 = {0};
    zT_3A355BD2_Token zT_109 = {0};
    zT_138FFB41_Lexer* zT_110;
    int zT_113 = 0;
    zT_138FFB41_Lexer* zT_114;
    int zT_117 = 0;
    zT_138FFB41_Lexer* zT_118;
    unsigned int zT_120;
    zT_85CBA4DB_TokenValue zT_121;
    zT_85CBA4DB_TokenValue zT_125 = {0};
    zT_3A355BD2_Token zT_127 = {0};
    zT_138FFB41_Lexer* zT_128;
    unsigned int zT_130;
    zT_85CBA4DB_TokenValue zT_131;
    zT_85CBA4DB_TokenValue zT_135 = {0};
    zT_3A355BD2_Token zT_137 = {0};
    zT_138FFB41_Lexer* zT_138;
    int zT_141 = 0;
    zT_138FFB41_Lexer* zT_142;
    unsigned int zT_144;
    zT_85CBA4DB_TokenValue zT_145;
    zT_85CBA4DB_TokenValue zT_149 = {0};
    zT_3A355BD2_Token zT_151 = {0};
    zT_138FFB41_Lexer* zT_152;
    int zT_155 = 0;
    zT_138FFB41_Lexer* zT_156;
    unsigned int zT_158;
    zT_85CBA4DB_TokenValue zT_159;
    zT_85CBA4DB_TokenValue zT_163 = {0};
    zT_3A355BD2_Token zT_165 = {0};
    zT_138FFB41_Lexer* zT_166;
    unsigned int zT_168;
    zT_85CBA4DB_TokenValue zT_169;
    zT_85CBA4DB_TokenValue zT_173 = {0};
    zT_3A355BD2_Token zT_175 = {0};
    zT_138FFB41_Lexer* zT_176;
    int zT_179 = 0;
    zT_138FFB41_Lexer* zT_180;
    int zT_183 = 0;
    zT_138FFB41_Lexer* zT_184;
    unsigned int zT_186;
    zT_85CBA4DB_TokenValue zT_187;
    zT_85CBA4DB_TokenValue zT_191 = {0};
    zT_3A355BD2_Token zT_193 = {0};
    zT_138FFB41_Lexer* zT_194;
    unsigned int zT_196;
    zT_85CBA4DB_TokenValue zT_197;
    zT_85CBA4DB_TokenValue zT_201 = {0};
    zT_3A355BD2_Token zT_203 = {0};
    zT_138FFB41_Lexer* zT_204;
    int zT_207 = 0;
    zT_138FFB41_Lexer* zT_208;
    int zT_211 = 0;
    zT_138FFB41_Lexer* zT_212;
    unsigned int zT_214;
    zT_85CBA4DB_TokenValue zT_215;
    zT_85CBA4DB_TokenValue zT_219 = {0};
    zT_3A355BD2_Token zT_221 = {0};
    zT_138FFB41_Lexer* zT_222;
    unsigned int zT_224;
    zT_85CBA4DB_TokenValue zT_225;
    zT_85CBA4DB_TokenValue zT_229 = {0};
    zT_3A355BD2_Token zT_231 = {0};
    zT_138FFB41_Lexer* zT_232;
    int zT_235 = 0;
    zT_138FFB41_Lexer* zT_236;
    unsigned int zT_238;
    zT_85CBA4DB_TokenValue zT_239;
    zT_85CBA4DB_TokenValue zT_243 = {0};
    zT_3A355BD2_Token zT_245 = {0};
    zT_138FFB41_Lexer* zT_246;
    unsigned int zT_248;
    zT_85CBA4DB_TokenValue zT_249;
    zT_85CBA4DB_TokenValue zT_253 = {0};
    zT_3A355BD2_Token zT_255 = {0};
    zT_138FFB41_Lexer* zT_256;
    int zT_259 = 0;
    zT_138FFB41_Lexer* zT_260;
    int zT_263 = 0;
    zT_138FFB41_Lexer* zT_264;
    unsigned int zT_266;
    zT_85CBA4DB_TokenValue zT_267;
    zT_85CBA4DB_TokenValue zT_271 = {0};
    zT_3A355BD2_Token zT_273 = {0};
    zT_138FFB41_Lexer* zT_274;
    unsigned int zT_276;
    zT_85CBA4DB_TokenValue zT_277;
    zT_85CBA4DB_TokenValue zT_281 = {0};
    zT_3A355BD2_Token zT_283 = {0};
    zT_138FFB41_Lexer* zT_284;
    int zT_287 = 0;
    zT_138FFB41_Lexer* zT_288;
    int zT_291 = 0;
    zT_138FFB41_Lexer* zT_292;
    unsigned int zT_294;
    zT_85CBA4DB_TokenValue zT_295;
    zT_85CBA4DB_TokenValue zT_299 = {0};
    zT_3A355BD2_Token zT_301 = {0};
    zT_138FFB41_Lexer* zT_302;
    unsigned int zT_304;
    zT_85CBA4DB_TokenValue zT_305;
    zT_85CBA4DB_TokenValue zT_309 = {0};
    zT_3A355BD2_Token zT_311 = {0};
    zT_138FFB41_Lexer* zT_312;
    int zT_315 = 0;
    zT_138FFB41_Lexer* zT_316;
    unsigned int zT_318;
    zT_85CBA4DB_TokenValue zT_319;
    zT_85CBA4DB_TokenValue zT_323 = {0};
    zT_3A355BD2_Token zT_325 = {0};
    zT_138FFB41_Lexer* zT_326;
    unsigned int zT_328;
    zT_85CBA4DB_TokenValue zT_329;
    zT_85CBA4DB_TokenValue zT_333 = {0};
    zT_3A355BD2_Token zT_335 = {0};
    zT_138FFB41_Lexer* zT_336;
    int zT_339 = 0;
    zT_138FFB41_Lexer* zT_340;
    int zT_343 = 0;
    zT_138FFB41_Lexer* zT_344;
    unsigned int zT_346;
    zT_85CBA4DB_TokenValue zT_347;
    zT_85CBA4DB_TokenValue zT_351 = {0};
    zT_3A355BD2_Token zT_353 = {0};
    zT_138FFB41_Lexer* zT_354;
    unsigned int zT_356;
    zT_85CBA4DB_TokenValue zT_357;
    zT_85CBA4DB_TokenValue zT_361 = {0};
    zT_3A355BD2_Token zT_363 = {0};
    zT_138FFB41_Lexer* zT_364;
    int zT_367 = 0;
    zT_138FFB41_Lexer* zT_368;
    int zT_371 = 0;
    zT_138FFB41_Lexer* zT_372;
    unsigned int zT_374;
    zT_85CBA4DB_TokenValue zT_375;
    zT_85CBA4DB_TokenValue zT_379 = {0};
    zT_3A355BD2_Token zT_381 = {0};
    zT_138FFB41_Lexer* zT_382;
    unsigned int zT_384;
    zT_85CBA4DB_TokenValue zT_385;
    zT_85CBA4DB_TokenValue zT_389 = {0};
    zT_3A355BD2_Token zT_391 = {0};
    zT_138FFB41_Lexer* zT_392;
    int zT_395 = 0;
    zT_138FFB41_Lexer* zT_396;
    unsigned int zT_398;
    zT_85CBA4DB_TokenValue zT_399;
    zT_85CBA4DB_TokenValue zT_403 = {0};
    zT_3A355BD2_Token zT_405 = {0};
    zT_138FFB41_Lexer* zT_406;
    unsigned int zT_408;
    zT_85CBA4DB_TokenValue zT_409;
    zT_85CBA4DB_TokenValue zT_413 = {0};
    zT_3A355BD2_Token zT_415 = {0};
    zT_138FFB41_Lexer* zT_416;
    int zT_419 = 0;
    zT_138FFB41_Lexer* zT_420;
    unsigned int zT_422;
    zT_85CBA4DB_TokenValue zT_423;
    zT_85CBA4DB_TokenValue zT_427 = {0};
    zT_3A355BD2_Token zT_429 = {0};
    zT_138FFB41_Lexer* zT_430;
    unsigned int zT_432;
    zT_85CBA4DB_TokenValue zT_433;
    zT_85CBA4DB_TokenValue zT_437 = {0};
    zT_3A355BD2_Token zT_439 = {0};
    zT_138FFB41_Lexer* zT_440;
    int zT_443 = 0;
    zT_138FFB41_Lexer* zT_444;
    unsigned int zT_446;
    zT_85CBA4DB_TokenValue zT_447;
    zT_85CBA4DB_TokenValue zT_451 = {0};
    zT_3A355BD2_Token zT_453 = {0};
    zT_138FFB41_Lexer* zT_454;
    unsigned int zT_456;
    zT_85CBA4DB_TokenValue zT_457;
    zT_85CBA4DB_TokenValue zT_461 = {0};
    zT_3A355BD2_Token zT_463 = {0};
    zT_138FFB41_Lexer* zT_464;
    int zT_467 = 0;
    zT_138FFB41_Lexer* zT_468;
    unsigned int zT_470;
    zT_85CBA4DB_TokenValue zT_471;
    zT_85CBA4DB_TokenValue zT_475 = {0};
    zT_3A355BD2_Token zT_477 = {0};
    zT_138FFB41_Lexer* zT_478;
    unsigned int zT_480;
    zT_85CBA4DB_TokenValue zT_481;
    zT_85CBA4DB_TokenValue zT_485 = {0};
    zT_3A355BD2_Token zT_487 = {0};
    zT_138FFB41_Lexer* zT_488;
    int zT_491 = 0;
    zT_138FFB41_Lexer* zT_492;
    unsigned int zT_494;
    zT_85CBA4DB_TokenValue zT_495;
    zT_85CBA4DB_TokenValue zT_499 = {0};
    zT_3A355BD2_Token zT_501 = {0};
    zT_138FFB41_Lexer* zT_502;
    unsigned int zT_504;
    zT_85CBA4DB_TokenValue zT_505;
    zT_85CBA4DB_TokenValue zT_509 = {0};
    zT_3A355BD2_Token zT_511 = {0};
    zT_138FFB41_Lexer* zT_512;
    int zT_515 = 0;
    zT_138FFB41_Lexer* zT_516;
    unsigned int zT_518;
    zT_85CBA4DB_TokenValue zT_519;
    zT_85CBA4DB_TokenValue zT_523 = {0};
    zT_3A355BD2_Token zT_525 = {0};
    zT_138FFB41_Lexer* zT_526;
    int zT_529 = 0;
    zT_138FFB41_Lexer* zT_530;
    unsigned int zT_532;
    zT_85CBA4DB_TokenValue zT_533;
    zT_85CBA4DB_TokenValue zT_537 = {0};
    zT_3A355BD2_Token zT_539 = {0};
    zT_138FFB41_Lexer* zT_540;
    unsigned int zT_542;
    zT_85CBA4DB_TokenValue zT_543;
    zT_85CBA4DB_TokenValue zT_547 = {0};
    zT_3A355BD2_Token zT_549 = {0};
    zT_138FFB41_Lexer* zT_550;
    int zT_553 = 0;
    zT_138FFB41_Lexer* zT_554;
    unsigned int zT_556;
    zT_85CBA4DB_TokenValue zT_557;
    zT_85CBA4DB_TokenValue zT_561 = {0};
    zT_3A355BD2_Token zT_563 = {0};
    zT_138FFB41_Lexer* zT_564;
    unsigned int zT_566;
    zT_85CBA4DB_TokenValue zT_567;
    zT_85CBA4DB_TokenValue zT_571 = {0};
    zT_3A355BD2_Token zT_573 = {0};
    zT_138FFB41_Lexer* zT_574;
    int zT_577 = 0;
    zT_138FFB41_Lexer* zT_578;
    int zT_581 = 0;
    zT_138FFB41_Lexer* zT_582;
    int zT_585 = 0;
    zT_138FFB41_Lexer* zT_586;
    unsigned int zT_588;
    zT_85CBA4DB_TokenValue zT_589;
    zT_85CBA4DB_TokenValue zT_593 = {0};
    zT_3A355BD2_Token zT_595 = {0};
    zT_138FFB41_Lexer* zT_596;
    unsigned int zT_598;
    zT_85CBA4DB_TokenValue zT_599;
    zT_85CBA4DB_TokenValue zT_603 = {0};
    zT_3A355BD2_Token zT_605 = {0};
    zT_138FFB41_Lexer* zT_606;
    int zT_609 = 0;
    zT_138FFB41_Lexer* zT_610;
    unsigned int zT_612;
    zT_85CBA4DB_TokenValue zT_613;
    zT_85CBA4DB_TokenValue zT_617 = {0};
    zT_3A355BD2_Token zT_619 = {0};
    zT_138FFB41_Lexer* zT_620;
    unsigned int zT_622;
    zT_85CBA4DB_TokenValue zT_623;
    zT_85CBA4DB_TokenValue zT_627 = {0};
    zT_3A355BD2_Token zT_629 = {0};
    zT_138FFB41_Lexer* zT_630;
    int zT_633 = 0;
    zT_138FFB41_Lexer* zT_634;
    unsigned int zT_636;
    zT_85CBA4DB_TokenValue zT_637;
    zT_85CBA4DB_TokenValue zT_641 = {0};
    zT_3A355BD2_Token zT_643 = {0};
    zT_138FFB41_Lexer* zT_644;
    unsigned int zT_646;
    zT_85CBA4DB_TokenValue zT_647;
    zT_85CBA4DB_TokenValue zT_651 = {0};
    zT_3A355BD2_Token zT_653 = {0};
    zT_138FFB41_Lexer* zT_654;
    int zT_657 = 0;
    zT_138FFB41_Lexer* zT_658;
    int zT_661 = 0;
    zT_138FFB41_Lexer* zT_662;
    unsigned int zT_664;
    zT_85CBA4DB_TokenValue zT_665;
    zT_85CBA4DB_TokenValue zT_669 = {0};
    zT_3A355BD2_Token zT_671 = {0};
    zT_138FFB41_Lexer* zT_672;
    unsigned int zT_674;
    zT_85CBA4DB_TokenValue zT_675;
    zT_85CBA4DB_TokenValue zT_679 = {0};
    zT_3A355BD2_Token zT_681 = {0};
    zT_138FFB41_Lexer* zT_682;
    int zT_685 = 0;
    zT_138FFB41_Lexer* zT_686;
    unsigned int zT_688;
    zT_85CBA4DB_TokenValue zT_689;
    zT_85CBA4DB_TokenValue zT_693 = {0};
    zT_3A355BD2_Token zT_695 = {0};
    zT_138FFB41_Lexer* zT_696;
    unsigned int zT_698;
    zT_85CBA4DB_TokenValue zT_699;
    zT_85CBA4DB_TokenValue zT_703 = {0};
    zT_3A355BD2_Token zT_705 = {0};
    zT_138FFB41_Lexer* zT_706;
    int zT_709 = 0;
    zT_138FFB41_Lexer* zT_710;
    unsigned int zT_712;
    zT_85CBA4DB_TokenValue zT_713;
    zT_85CBA4DB_TokenValue zT_717 = {0};
    zT_3A355BD2_Token zT_719 = {0};
    zT_138FFB41_Lexer* zT_720;
    unsigned int zT_722;
    zT_85CBA4DB_TokenValue zT_723;
    zT_85CBA4DB_TokenValue zT_727 = {0};
    zT_3A355BD2_Token zT_729 = {0};
    zT_138FFB41_Lexer* zT_730;
    unsigned int zT_732;
    zT_85CBA4DB_TokenValue zT_733;
    zT_85CBA4DB_TokenValue zT_737 = {0};
    zT_3A355BD2_Token zT_739 = {0};
    zT_138FFB41_Lexer* zT_740;
    unsigned int zT_742;
    zT_85CBA4DB_TokenValue zT_743;
    zT_85CBA4DB_TokenValue zT_747 = {0};
    zT_3A355BD2_Token zT_749 = {0};
    unsigned char zT_750;
    zT_138FFB41_Lexer* zT_751;
    unsigned char zT_752 = 0;
    int zT_753 = 0;
    zT_138FFB41_Lexer* zT_754;
    unsigned int zT_755;
    zT_3A355BD2_Token zT_756 = {0};
    unsigned char* zT_758;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_759;
    unsigned int zT_760;
    int zT_761;
    zT_F85C5DED_DiagnosticCollector* zT_763;
    unsigned int zT_766;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    int zT_771;
    unsigned int zT_776;
    zT_138FFB41_Lexer* zT_779;
    unsigned int zT_780;
    zT_3A355BD2_Token zT_781 = {0};
    zT_138FFB41_Lexer* zT_782;
    unsigned int zT_783;
    zT_3A355BD2_Token zT_784 = {0};
    zT_138FFB41_Lexer* zT_785;
    unsigned int zT_786;
    zT_3A355BD2_Token zT_787 = {0};
    unsigned char zT_788;
    int zT_789 = 0;
    int zT_790;
    zT_138FFB41_Lexer* zT_793;
    unsigned int zT_794;
    zT_3A355BD2_Token zT_795 = {0};
    unsigned char zT_796;
    int zT_797 = 0;
    zT_138FFB41_Lexer* zT_798;
    unsigned int zT_799;
    unsigned char zT_800;
    zT_3A355BD2_Token zT_801 = {0};
    int zT_802;
    unsigned char* zT_805;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_806;
    unsigned int zT_807;
    zT_BBAAFAE2_Arr_unsigned_char_2 zT_809;
    int zT_810;
    unsigned char zT_811;
    int zT_812;
    unsigned char* zT_814;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_815;
    unsigned int zT_816;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_818;
    unsigned int zT_819;
    int zT_822;
    int zT_823;
    unsigned char* zT_824;
    unsigned int zT_825;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_826;
    unsigned int zT_827;
    unsigned int zT_828;
    zT_D3EB6303_StringInterner* zT_830;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_831;
    zT_F85C5DED_DiagnosticCollector* zT_833;
    int zT_835;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_836;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_838 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_839;
    unsigned int zT_842;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_845;
    int zT_847;
    unsigned int zT_852;
    zT_138FFB41_Lexer* zT_855;
    unsigned int zT_856;
    zT_3A355BD2_Token zT_857 = {0};
    unsigned int start;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u bare_at_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u up1;
    zT_BBAAFAE2_Arr_unsigned_char_2 char_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u up3;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u unrecognized_msg;
    zT_1 = self;
    zF_F7949B41_lexerSkipWSC(zT_1);
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self;
    zT_6 = self->pos;
    zT_7 = zT_12;
    zT_14 = zF_369DD718_lexerMakeToken(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof), zT_6, zT_7);
    return zT_14;
    z_bb_2:
    zT_16 = self->pos;
    start = zT_16;
    zT_18 = self;
    zT_19 = zF_7C2FDD01_lexerAdvance(zT_18);
    c = zT_19;
switch (c) {
case 40: goto z_bb_3;
case 41: goto z_bb_4;
case 91: goto z_bb_5;
case 93: goto z_bb_6;
case 123: goto z_bb_7;
case 125: goto z_bb_8;
case 59: goto z_bb_9;
case 58: goto z_bb_10;
case 44: goto z_bb_11;
case 46: goto z_bb_12;
case 43: goto z_bb_13;
case 45: goto z_bb_14;
case 42: goto z_bb_15;
case 47: goto z_bb_16;
case 37: goto z_bb_17;
case 38: goto z_bb_18;
case 124: goto z_bb_19;
case 61: goto z_bb_20;
case 33: goto z_bb_21;
case 60: goto z_bb_22;
case 62: goto z_bb_23;
case 94: goto z_bb_24;
case 126: goto z_bb_25;
case 63: goto z_bb_26;
case 64: goto z_bb_27;
case 34: goto z_bb_28;
case 39: goto z_bb_29;
default: goto z_bb_30;
}
    z_bb_3:
    zT_20 = self;
    zT_22 = start;
    zT_23 = zT_27;
    zT_29 = zF_369DD718_lexerMakeToken(zT_20, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen), zT_22, zT_23);
    return zT_29;
    z_bb_4:
    zT_30 = self;
    zT_32 = start;
    zT_33 = zT_37;
    zT_39 = zF_369DD718_lexerMakeToken(zT_30, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen), zT_32, zT_33);
    return zT_39;
    z_bb_5:
    zT_40 = self;
    zT_42 = start;
    zT_43 = zT_47;
    zT_49 = zF_369DD718_lexerMakeToken(zT_40, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket), zT_42, zT_43);
    return zT_49;
    z_bb_6:
    zT_50 = self;
    zT_52 = start;
    zT_53 = zT_57;
    zT_59 = zF_369DD718_lexerMakeToken(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket), zT_52, zT_53);
    return zT_59;
    z_bb_7:
    zT_60 = self;
    zT_62 = start;
    zT_63 = zT_67;
    zT_69 = zF_369DD718_lexerMakeToken(zT_60, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace), zT_62, zT_63);
    return zT_69;
    z_bb_8:
    zT_70 = self;
    zT_72 = start;
    zT_73 = zT_77;
    zT_79 = zF_369DD718_lexerMakeToken(zT_70, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace), zT_72, zT_73);
    return zT_79;
    z_bb_9:
    zT_80 = self;
    zT_82 = start;
    zT_83 = zT_87;
    zT_89 = zF_369DD718_lexerMakeToken(zT_80, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon), zT_82, zT_83);
    return zT_89;
    z_bb_10:
    zT_90 = self;
    zT_92 = start;
    zT_93 = zT_97;
    zT_99 = zF_369DD718_lexerMakeToken(zT_90, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon), zT_92, zT_93);
    return zT_99;
    z_bb_11:
    zT_100 = self;
    zT_102 = start;
    zT_103 = zT_107;
    zT_109 = zF_369DD718_lexerMakeToken(zT_100, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma), zT_102, zT_103);
    return zT_109;
    z_bb_12:
    zT_110 = self;
    zT_113 = zF_8A07967A_lexerMatch(zT_110, (unsigned char)(46));
    if (zT_113) goto z_bb_33; else goto z_bb_34;
    z_bb_13:
    zT_176 = self;
    zT_179 = zF_8A07967A_lexerMatch(zT_176, (unsigned char)(37));
    if (zT_179) goto z_bb_41; else goto z_bb_42;
    z_bb_14:
    zT_256 = self;
    zT_259 = zF_8A07967A_lexerMatch(zT_256, (unsigned char)(37));
    if (zT_259) goto z_bb_51; else goto z_bb_52;
    z_bb_15:
    zT_336 = self;
    zT_339 = zF_8A07967A_lexerMatch(zT_336, (unsigned char)(37));
    if (zT_339) goto z_bb_61; else goto z_bb_62;
    z_bb_16:
    zT_416 = self;
    zT_419 = zF_8A07967A_lexerMatch(zT_416, (unsigned char)(61));
    if (zT_419) goto z_bb_71; else goto z_bb_72;
    z_bb_17:
    zT_440 = self;
    zT_443 = zF_8A07967A_lexerMatch(zT_440, (unsigned char)(61));
    if (zT_443) goto z_bb_73; else goto z_bb_74;
    z_bb_18:
    zT_464 = self;
    zT_467 = zF_8A07967A_lexerMatch(zT_464, (unsigned char)(61));
    if (zT_467) goto z_bb_75; else goto z_bb_76;
    z_bb_19:
    zT_488 = self;
    zT_491 = zF_8A07967A_lexerMatch(zT_488, (unsigned char)(61));
    if (zT_491) goto z_bb_77; else goto z_bb_78;
    z_bb_20:
    zT_512 = self;
    zT_515 = zF_8A07967A_lexerMatch(zT_512, (unsigned char)(61));
    if (zT_515) goto z_bb_79; else goto z_bb_80;
    z_bb_21:
    zT_550 = self;
    zT_553 = zF_8A07967A_lexerMatch(zT_550, (unsigned char)(61));
    if (zT_553) goto z_bb_83; else goto z_bb_84;
    z_bb_22:
    zT_574 = self;
    zT_577 = zF_8A07967A_lexerMatch(zT_574, (unsigned char)(60));
    if (zT_577) goto z_bb_85; else goto z_bb_86;
    z_bb_23:
    zT_654 = self;
    zT_657 = zF_8A07967A_lexerMatch(zT_654, (unsigned char)(62));
    if (zT_657) goto z_bb_95; else goto z_bb_96;
    z_bb_24:
    zT_706 = self;
    zT_709 = zF_8A07967A_lexerMatch(zT_706, (unsigned char)(61));
    if (zT_709) goto z_bb_101; else goto z_bb_102;
    z_bb_25:
    zT_730 = self;
    zT_732 = start;
    zT_733 = zT_737;
    zT_739 = zF_369DD718_lexerMakeToken(zT_730, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde), zT_732, zT_733);
    return zT_739;
    z_bb_26:
    zT_740 = self;
    zT_742 = start;
    zT_743 = zT_747;
    zT_749 = zF_369DD718_lexerMakeToken(zT_740, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark), zT_742, zT_743);
    return zT_749;
    z_bb_27:
    zT_751 = self;
    zT_752 = zF_6ACB12FA_lexerPeek(zT_751);
    zT_750 = zT_752;
    zT_753 = zF_0D29E41B_isAlpha(zT_750);
    if (zT_753) goto z_bb_103; else goto z_bb_104;
    z_bb_28:
    zT_782 = self;
    zT_783 = start;
    zT_784 = zF_D28972ED_lexerScanString(zT_782, zT_783);
    return zT_784;
    z_bb_29:
    zT_785 = self;
    zT_786 = start;
    zT_787 = zF_616D7368_lexerScanChar(zT_785, zT_786);
    return zT_787;
    z_bb_30:
    zT_788 = c;
    zT_789 = zF_0D29E41B_isAlpha(zT_788);
    if (zT_789) goto z_bb_108; else goto z_bb_107;
    { zT_3A355BD2_Token zT_ret_void = {0}; return zT_ret_void; }
    z_bb_33:
    zT_114 = self;
    zT_117 = zF_8A07967A_lexerMatch(zT_114, (unsigned char)(46));
    if (zT_117) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_138 = self;
    zT_141 = zF_8A07967A_lexerMatch(zT_138, (unsigned char)(123));
    if (zT_141) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_118 = self;
    zT_120 = start;
    zT_121 = zT_125;
    zT_127 = zF_369DD718_lexerMakeToken(zT_118, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot), zT_120, zT_121);
    return zT_127;
    z_bb_36:
    zT_128 = self;
    zT_130 = start;
    zT_131 = zT_135;
    zT_137 = zF_369DD718_lexerMakeToken(zT_128, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot), zT_130, zT_131);
    return zT_137;
    z_bb_37:
    zT_142 = self;
    zT_144 = start;
    zT_145 = zT_149;
    zT_151 = zF_369DD718_lexerMakeToken(zT_142, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace), zT_144, zT_145);
    return zT_151;
    z_bb_38:
    zT_152 = self;
    zT_155 = zF_8A07967A_lexerMatch(zT_152, (unsigned char)(42));
    if (zT_155) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_156 = self;
    zT_158 = start;
    zT_159 = zT_163;
    zT_165 = zF_369DD718_lexerMakeToken(zT_156, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star), zT_158, zT_159);
    return zT_165;
    z_bb_40:
    zT_166 = self;
    zT_168 = start;
    zT_169 = zT_173;
    zT_175 = zF_369DD718_lexerMakeToken(zT_166, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot), zT_168, zT_169);
    return zT_175;
    z_bb_41:
    zT_180 = self;
    zT_183 = zF_8A07967A_lexerMatch(zT_180, (unsigned char)(61));
    if (zT_183) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_204 = self;
    zT_207 = zF_8A07967A_lexerMatch(zT_204, (unsigned char)(124));
    if (zT_207) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    zT_184 = self;
    zT_186 = start;
    zT_187 = zT_191;
    zT_193 = zF_369DD718_lexerMakeToken(zT_184, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct_eq), zT_186, zT_187);
    return zT_193;
    z_bb_44:
    zT_194 = self;
    zT_196 = start;
    zT_197 = zT_201;
    zT_203 = zF_369DD718_lexerMakeToken(zT_194, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct), zT_196, zT_197);
    return zT_203;
    z_bb_45:
    zT_208 = self;
    zT_211 = zF_8A07967A_lexerMatch(zT_208, (unsigned char)(61));
    if (zT_211) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_232 = self;
    zT_235 = zF_8A07967A_lexerMatch(zT_232, (unsigned char)(61));
    if (zT_235) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    zT_212 = self;
    zT_214 = start;
    zT_215 = zT_219;
    zT_221 = zF_369DD718_lexerMakeToken(zT_212, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe_eq), zT_214, zT_215);
    return zT_221;
    z_bb_48:
    zT_222 = self;
    zT_224 = start;
    zT_225 = zT_229;
    zT_231 = zF_369DD718_lexerMakeToken(zT_222, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe), zT_224, zT_225);
    return zT_231;
    z_bb_49:
    zT_236 = self;
    zT_238 = start;
    zT_239 = zT_243;
    zT_245 = zF_369DD718_lexerMakeToken(zT_236, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_eq), zT_238, zT_239);
    return zT_245;
    z_bb_50:
    zT_246 = self;
    zT_248 = start;
    zT_249 = zT_253;
    zT_255 = zF_369DD718_lexerMakeToken(zT_246, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus), zT_248, zT_249);
    return zT_255;
    z_bb_51:
    zT_260 = self;
    zT_263 = zF_8A07967A_lexerMatch(zT_260, (unsigned char)(61));
    if (zT_263) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_284 = self;
    zT_287 = zF_8A07967A_lexerMatch(zT_284, (unsigned char)(124));
    if (zT_287) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_264 = self;
    zT_266 = start;
    zT_267 = zT_271;
    zT_273 = zF_369DD718_lexerMakeToken(zT_264, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct_eq), zT_266, zT_267);
    return zT_273;
    z_bb_54:
    zT_274 = self;
    zT_276 = start;
    zT_277 = zT_281;
    zT_283 = zF_369DD718_lexerMakeToken(zT_274, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct), zT_276, zT_277);
    return zT_283;
    z_bb_55:
    zT_288 = self;
    zT_291 = zF_8A07967A_lexerMatch(zT_288, (unsigned char)(61));
    if (zT_291) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    zT_312 = self;
    zT_315 = zF_8A07967A_lexerMatch(zT_312, (unsigned char)(61));
    if (zT_315) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_292 = self;
    zT_294 = start;
    zT_295 = zT_299;
    zT_301 = zF_369DD718_lexerMakeToken(zT_292, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe_eq), zT_294, zT_295);
    return zT_301;
    z_bb_58:
    zT_302 = self;
    zT_304 = start;
    zT_305 = zT_309;
    zT_311 = zF_369DD718_lexerMakeToken(zT_302, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe), zT_304, zT_305);
    return zT_311;
    z_bb_59:
    zT_316 = self;
    zT_318 = start;
    zT_319 = zT_323;
    zT_325 = zF_369DD718_lexerMakeToken(zT_316, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_eq), zT_318, zT_319);
    return zT_325;
    z_bb_60:
    zT_326 = self;
    zT_328 = start;
    zT_329 = zT_333;
    zT_335 = zF_369DD718_lexerMakeToken(zT_326, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus), zT_328, zT_329);
    return zT_335;
    z_bb_61:
    zT_340 = self;
    zT_343 = zF_8A07967A_lexerMatch(zT_340, (unsigned char)(61));
    if (zT_343) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_364 = self;
    zT_367 = zF_8A07967A_lexerMatch(zT_364, (unsigned char)(124));
    if (zT_367) goto z_bb_65; else goto z_bb_66;
    z_bb_63:
    zT_344 = self;
    zT_346 = start;
    zT_347 = zT_351;
    zT_353 = zF_369DD718_lexerMakeToken(zT_344, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct_eq), zT_346, zT_347);
    return zT_353;
    z_bb_64:
    zT_354 = self;
    zT_356 = start;
    zT_357 = zT_361;
    zT_363 = zF_369DD718_lexerMakeToken(zT_354, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct), zT_356, zT_357);
    return zT_363;
    z_bb_65:
    zT_368 = self;
    zT_371 = zF_8A07967A_lexerMatch(zT_368, (unsigned char)(61));
    if (zT_371) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    zT_392 = self;
    zT_395 = zF_8A07967A_lexerMatch(zT_392, (unsigned char)(61));
    if (zT_395) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    zT_372 = self;
    zT_374 = start;
    zT_375 = zT_379;
    zT_381 = zF_369DD718_lexerMakeToken(zT_372, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe_eq), zT_374, zT_375);
    return zT_381;
    z_bb_68:
    zT_382 = self;
    zT_384 = start;
    zT_385 = zT_389;
    zT_391 = zF_369DD718_lexerMakeToken(zT_382, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe), zT_384, zT_385);
    return zT_391;
    z_bb_69:
    zT_396 = self;
    zT_398 = start;
    zT_399 = zT_403;
    zT_405 = zF_369DD718_lexerMakeToken(zT_396, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_eq), zT_398, zT_399);
    return zT_405;
    z_bb_70:
    zT_406 = self;
    zT_408 = start;
    zT_409 = zT_413;
    zT_415 = zF_369DD718_lexerMakeToken(zT_406, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star), zT_408, zT_409);
    return zT_415;
    z_bb_71:
    zT_420 = self;
    zT_422 = start;
    zT_423 = zT_427;
    zT_429 = zF_369DD718_lexerMakeToken(zT_420, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash_eq), zT_422, zT_423);
    return zT_429;
    z_bb_72:
    zT_430 = self;
    zT_432 = start;
    zT_433 = zT_437;
    zT_439 = zF_369DD718_lexerMakeToken(zT_430, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash), zT_432, zT_433);
    return zT_439;
    z_bb_73:
    zT_444 = self;
    zT_446 = start;
    zT_447 = zT_451;
    zT_453 = zF_369DD718_lexerMakeToken(zT_444, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent_eq), zT_446, zT_447);
    return zT_453;
    z_bb_74:
    zT_454 = self;
    zT_456 = start;
    zT_457 = zT_461;
    zT_463 = zF_369DD718_lexerMakeToken(zT_454, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent), zT_456, zT_457);
    return zT_463;
    z_bb_75:
    zT_468 = self;
    zT_470 = start;
    zT_471 = zT_475;
    zT_477 = zF_369DD718_lexerMakeToken(zT_468, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand_eq), zT_470, zT_471);
    return zT_477;
    z_bb_76:
    zT_478 = self;
    zT_480 = start;
    zT_481 = zT_485;
    zT_487 = zF_369DD718_lexerMakeToken(zT_478, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand), zT_480, zT_481);
    return zT_487;
    z_bb_77:
    zT_492 = self;
    zT_494 = start;
    zT_495 = zT_499;
    zT_501 = zF_369DD718_lexerMakeToken(zT_492, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe_eq), zT_494, zT_495);
    return zT_501;
    z_bb_78:
    zT_502 = self;
    zT_504 = start;
    zT_505 = zT_509;
    zT_511 = zF_369DD718_lexerMakeToken(zT_502, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe), zT_504, zT_505);
    return zT_511;
    z_bb_79:
    zT_516 = self;
    zT_518 = start;
    zT_519 = zT_523;
    zT_525 = zF_369DD718_lexerMakeToken(zT_516, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq_eq), zT_518, zT_519);
    return zT_525;
    z_bb_80:
    zT_526 = self;
    zT_529 = zF_8A07967A_lexerMatch(zT_526, (unsigned char)(62));
    if (zT_529) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_530 = self;
    zT_532 = start;
    zT_533 = zT_537;
    zT_539 = zF_369DD718_lexerMakeToken(zT_530, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow), zT_532, zT_533);
    return zT_539;
    z_bb_82:
    zT_540 = self;
    zT_542 = start;
    zT_543 = zT_547;
    zT_549 = zF_369DD718_lexerMakeToken(zT_540, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq), zT_542, zT_543);
    return zT_549;
    z_bb_83:
    zT_554 = self;
    zT_556 = start;
    zT_557 = zT_561;
    zT_563 = zF_369DD718_lexerMakeToken(zT_554, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang_eq), zT_556, zT_557);
    return zT_563;
    z_bb_84:
    zT_564 = self;
    zT_566 = start;
    zT_567 = zT_571;
    zT_573 = zF_369DD718_lexerMakeToken(zT_564, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang), zT_566, zT_567);
    return zT_573;
    z_bb_85:
    zT_578 = self;
    zT_581 = zF_8A07967A_lexerMatch(zT_578, (unsigned char)(124));
    if (zT_581) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    zT_630 = self;
    zT_633 = zF_8A07967A_lexerMatch(zT_630, (unsigned char)(61));
    if (zT_633) goto z_bb_93; else goto z_bb_94;
    z_bb_87:
    zT_582 = self;
    zT_585 = zF_8A07967A_lexerMatch(zT_582, (unsigned char)(61));
    if (zT_585) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_606 = self;
    zT_609 = zF_8A07967A_lexerMatch(zT_606, (unsigned char)(61));
    if (zT_609) goto z_bb_91; else goto z_bb_92;
    z_bb_89:
    zT_586 = self;
    zT_588 = start;
    zT_589 = zT_593;
    zT_595 = zF_369DD718_lexerMakeToken(zT_586, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe_eq), zT_588, zT_589);
    return zT_595;
    z_bb_90:
    zT_596 = self;
    zT_598 = start;
    zT_599 = zT_603;
    zT_605 = zF_369DD718_lexerMakeToken(zT_596, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe), zT_598, zT_599);
    return zT_605;
    z_bb_91:
    zT_610 = self;
    zT_612 = start;
    zT_613 = zT_617;
    zT_619 = zF_369DD718_lexerMakeToken(zT_610, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_eq), zT_612, zT_613);
    return zT_619;
    z_bb_92:
    zT_620 = self;
    zT_622 = start;
    zT_623 = zT_627;
    zT_629 = zF_369DD718_lexerMakeToken(zT_620, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl), zT_622, zT_623);
    return zT_629;
    z_bb_93:
    zT_634 = self;
    zT_636 = start;
    zT_637 = zT_641;
    zT_643 = zF_369DD718_lexerMakeToken(zT_634, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less_eq), zT_636, zT_637);
    return zT_643;
    z_bb_94:
    zT_644 = self;
    zT_646 = start;
    zT_647 = zT_651;
    zT_653 = zF_369DD718_lexerMakeToken(zT_644, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less), zT_646, zT_647);
    return zT_653;
    z_bb_95:
    zT_658 = self;
    zT_661 = zF_8A07967A_lexerMatch(zT_658, (unsigned char)(61));
    if (zT_661) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    zT_682 = self;
    zT_685 = zF_8A07967A_lexerMatch(zT_682, (unsigned char)(61));
    if (zT_685) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    zT_662 = self;
    zT_664 = start;
    zT_665 = zT_669;
    zT_671 = zF_369DD718_lexerMakeToken(zT_662, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr_eq), zT_664, zT_665);
    return zT_671;
    z_bb_98:
    zT_672 = self;
    zT_674 = start;
    zT_675 = zT_679;
    zT_681 = zF_369DD718_lexerMakeToken(zT_672, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr), zT_674, zT_675);
    return zT_681;
    z_bb_99:
    zT_686 = self;
    zT_688 = start;
    zT_689 = zT_693;
    zT_695 = zF_369DD718_lexerMakeToken(zT_686, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater_eq), zT_688, zT_689);
    return zT_695;
    z_bb_100:
    zT_696 = self;
    zT_698 = start;
    zT_699 = zT_703;
    zT_705 = zF_369DD718_lexerMakeToken(zT_696, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater), zT_698, zT_699);
    return zT_705;
    z_bb_101:
    zT_710 = self;
    zT_712 = start;
    zT_713 = zT_717;
    zT_719 = zF_369DD718_lexerMakeToken(zT_710, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret_eq), zT_712, zT_713);
    return zT_719;
    z_bb_102:
    zT_720 = self;
    zT_722 = start;
    zT_723 = zT_727;
    zT_729 = zF_369DD718_lexerMakeToken(zT_720, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret), zT_722, zT_723);
    return zT_729;
    z_bb_103:
    zT_754 = self;
    zT_755 = start;
    zT_756 = zF_9C3BDAA8_lexerScanBuiltinIde(zT_754, zT_755);
    return zT_756;
    z_bb_104:
    zT_758 = "bare '@' is not valid; expected builtin name (e.g., @sizeOf)";
    zT_760 = 60;
    zT_759.ptr = zT_758;
    zT_759.len = zT_760;
    bare_at_msg = zT_759;
    zT_761 = self->count_only;
    if ((int)(!zT_761)) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_763 = self->diag;
    zT_771 = 0;
    zT_766 = self->file_id;
    zT_776 = self->pos;
    zT_769 = bare_at_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_763, (unsigned char)((unsigned char)zT_771), (unsigned short)(4), zT_766, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_776), zT_769);
    goto z_bb_106;
    z_bb_106:
    zT_779 = self;
    zT_780 = start;
    zT_781 = zF_19A0FF20_lexerMakeErrorToken(zT_779, zT_780);
    return zT_781;
    z_bb_107:
    zT_790 = c == (unsigned char)(95);
    goto z_bb_109;
    z_bb_108:
    zT_790 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_790) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_793 = self;
    zT_794 = start;
    zT_795 = zF_EC7F12C5_lexerScanIdentifier(zT_793, zT_794);
    return zT_795;
    z_bb_111:
    zT_796 = c;
    zT_797 = zF_C95A8EC6_isDigit(zT_796);
    if (zT_797) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    zT_798 = self;
    zT_799 = start;
    zT_800 = c;
    zT_801 = zF_EF8134BD_lexerScanNumber(zT_798, zT_799, zT_800);
    return zT_801;
    z_bb_113:
    zT_802 = self->count_only;
    if ((int)(!zT_802)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_805 = "unrecognized character: '";
    zT_807 = 25;
    zT_806.ptr = zT_805;
    zT_806.len = zT_807;
    up1 = zT_806;
    {
    unsigned int _i = 0;
    while (_i < 2) {
        zT_809[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 2) {
        char_buf[_i] = zT_809[_i];
        _i++;
    }
}
    zT_810 = 0;
    char_buf[zT_810] = c;
    zT_811 = 0;
    zT_812 = 1;
    char_buf[zT_812] = zT_811;
    zT_814 = "'";
    zT_816 = 1;
    zT_815.ptr = zT_814;
    zT_815.len = zT_816;
    up3 = zT_815;
    zT_819 = 0;
    zT_818[zT_819] = up1;
    zT_822 = 1;
    zT_823 = 0;
    zT_824 = (unsigned char*)((unsigned char*)char_buf) + zT_823;
    zT_825 = zT_822 - zT_823;
    zT_826.ptr = zT_824;
    zT_826.len = zT_825;
    zT_827 = 1;
    zT_818[zT_827] = zT_826;
    zT_828 = 2;
    zT_818[zT_828] = up3;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uparts[_i] = zT_818[_i];
        _i++;
    }
}
    zT_833 = self->diag;
    zT_830 = zT_833->interner;
    zT_835 = 0;
    zT_836 = uparts + zT_835;
    zT_831 = zT_836;
    zT_838 = zF_8C4BFF7C_diagnosticBuilderMa(zT_830, zT_831, (unsigned int)(3));
    unrecognized_msg = zT_838;
    zT_839 = self->diag;
    zT_847 = 0;
    zT_842 = self->file_id;
    zT_852 = self->pos;
    zT_845 = unrecognized_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_839, (unsigned char)((unsigned char)zT_847), (unsigned short)(5), zT_842, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_852), zT_845);
    goto z_bb_115;
    z_bb_115:
    zT_855 = self;
    zT_856 = start;
    zT_857 = zF_19A0FF20_lexerMakeErrorToken(zT_855, zT_856);
    return zT_857;
}

/* lexerAdvance */
unsigned char zF_7C2FDD01_lexerAdvance(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned char* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_18;
    int zT_19;
    int zT_22;
    unsigned int zT_24;
    int zT_25;
    unsigned char c;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    if ((int)(zT_1 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->source;
    zT_9 = zT_8.ptr;
    zT_10 = self->pos;
    zT_11 = zT_9[zT_10];
    c = zT_11;
    zT_12 = self->pos;
    zT_13 = 1;
    self->pos = (unsigned int)(zT_12 + (unsigned int)((unsigned int)zT_13));
    if ((int)(c == (unsigned char)(10))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_18 = self->line;
    zT_19 = 1;
    self->line = (unsigned int)(zT_18 + (unsigned int)((unsigned int)zT_19));
    zT_22 = 1;
    self->col = (unsigned int)((unsigned int)zT_22);
    goto z_bb_4;
    z_bb_4:
    return c;
    z_bb_5:
    zT_24 = self->col;
    zT_25 = 1;
    self->col = (unsigned int)(zT_24 + (unsigned int)((unsigned int)zT_25));
    goto z_bb_4;
}

/* lexerPeek */
unsigned char zF_6ACB12FA_lexerPeek(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned char* zT_8;
    unsigned int zT_9;
    unsigned char zT_10;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    if ((int)(zT_1 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->source;
    zT_8 = zT_7.ptr;
    zT_9 = self->pos;
    zT_10 = zT_8[zT_9];
    return zT_10;
}

/* lexerPeekN */
unsigned char zF_D1AE715C_lexerPeekN(zT_138FFB41_Lexer* self, unsigned int n) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned int idx;
    zT_3 = self->pos;
    zT_4 = zT_3 + n;
    idx = zT_4;
    zT_5 = self->source;
    zT_7 = zT_5.len;
    if ((int)(idx >= zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_10 = self->source;
    zT_11 = zT_10.ptr;
    zT_12 = zT_11[idx];
    return zT_12;
}

/* lexerIsAtEnd */
int zF_07BC1EA1_lexerIsAtEnd(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    return (int)(zT_1 >= zT_4);
}

/* lexerMatch */
int zF_8A07967A_lexerMatch(zT_138FFB41_Lexer* self, unsigned char expected) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3 = 0;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7 = 0;
    zT_2 = self;
    zT_3 = zF_6ACB12FA_lexerPeek(zT_2);
    if ((int)(zT_3 != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_7C2FDD01_lexerAdvance(zT_6);
    (void)zT_7;
    return (int)(1);
}

/* lexerSkipWSC */
void zF_F7949B41_lexerSkipWSC(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    int zT_2 = 0;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6 = 0;
    zT_138FFB41_Lexer* zT_7;
    unsigned char zT_8 = 0;
    zT_138FFB41_Lexer* zT_9;
    int zT_11;
    unsigned char zT_13 = 0;
    zT_138FFB41_Lexer* zT_16;
    unsigned char zT_17 = 0;
    zT_138FFB41_Lexer* zT_18;
    unsigned char zT_19 = 0;
    zT_138FFB41_Lexer* zT_20;
    int zT_21 = 0;
    int zT_23;
    zT_138FFB41_Lexer* zT_24;
    unsigned char zT_25 = 0;
    zT_138FFB41_Lexer* zT_28;
    unsigned char zT_29 = 0;
    zT_138FFB41_Lexer* zT_30;
    int zT_32;
    unsigned char zT_34 = 0;
    zT_138FFB41_Lexer* zT_37;
    unsigned char zT_38 = 0;
    zT_138FFB41_Lexer* zT_39;
    unsigned char zT_40 = 0;
    int zT_42;
    unsigned int zT_43;
    zT_138FFB41_Lexer* zT_44;
    int zT_45 = 0;
    int zT_47;
    int zT_48;
    zT_138FFB41_Lexer* zT_50;
    unsigned char zT_51 = 0;
    int zT_54;
    zT_138FFB41_Lexer* zT_55;
    int zT_57;
    unsigned char zT_59 = 0;
    zT_138FFB41_Lexer* zT_62;
    unsigned char zT_63 = 0;
    zT_138FFB41_Lexer* zT_64;
    unsigned char zT_65 = 0;
    int zT_66;
    unsigned int zT_68;
    zT_138FFB41_Lexer* zT_69;
    unsigned char zT_70 = 0;
    int zT_73;
    zT_138FFB41_Lexer* zT_74;
    int zT_76;
    unsigned char zT_78 = 0;
    zT_138FFB41_Lexer* zT_81;
    unsigned char zT_82 = 0;
    zT_138FFB41_Lexer* zT_83;
    unsigned char zT_84 = 0;
    int zT_85;
    unsigned int zT_87;
    zT_138FFB41_Lexer* zT_88;
    unsigned char zT_89 = 0;
    int zT_90;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    int zT_96;
    zT_F85C5DED_DiagnosticCollector* zT_98;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    int zT_106;
    unsigned int zT_110;
    unsigned int zT_112;
    unsigned char c;
    unsigned int depth;
    zT_8F083A69_Slice_zT_0B42B2F8_u unterminated_block_msg;
    goto z_bb_1;
    z_bb_1:
    zT_1 = self;
    zT_2 = zF_07BC1EA1_lexerIsAtEnd(zT_1);
    if ((int)(!zT_2)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_6ACB12FA_lexerPeek(zT_5);
    c = zT_6;
switch (c) {
case 32: goto z_bb_5;
case 9: goto z_bb_5;
case 10: goto z_bb_5;
case 13: goto z_bb_5;
case 47: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_7 = self;
    zT_8 = zF_7C2FDD01_lexerAdvance(zT_7);
    (void)zT_8;
    goto z_bb_9;
    z_bb_6:
    zT_9 = self;
    zT_11 = 1;
    zT_13 = zF_D1AE715C_lexerPeekN(zT_9, (unsigned int)((unsigned int)zT_11));
    if ((int)(zT_13 == (unsigned char)(47))) goto z_bb_10; else goto z_bb_12;
    z_bb_7:
    return;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_16 = self;
    zT_17 = zF_7C2FDD01_lexerAdvance(zT_16);
    (void)zT_17;
    zT_18 = self;
    zT_19 = zF_7C2FDD01_lexerAdvance(zT_18);
    (void)zT_19;
    goto z_bb_13;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    zT_30 = self;
    zT_32 = 1;
    zT_34 = zF_D1AE715C_lexerPeekN(zT_30, (unsigned int)((unsigned int)zT_32));
    if ((int)(zT_34 == (unsigned char)(42))) goto z_bb_20; else goto z_bb_22;
    z_bb_13:
    zT_20 = self;
    zT_21 = zF_07BC1EA1_lexerIsAtEnd(zT_20);
    if ((int)(!zT_21)) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    zT_28 = self;
    zT_29 = zF_7C2FDD01_lexerAdvance(zT_28);
    (void)zT_29;
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_24 = self;
    zT_25 = zF_6ACB12FA_lexerPeek(zT_24);
    zT_23 = zT_25 != (unsigned char)(10);
    goto z_bb_19;
    z_bb_18:
    zT_23 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_23) goto z_bb_14; else goto z_bb_15;
    z_bb_20:
    zT_37 = self;
    zT_38 = zF_7C2FDD01_lexerAdvance(zT_37);
    (void)zT_38;
    zT_39 = self;
    zT_40 = zF_7C2FDD01_lexerAdvance(zT_39);
    (void)zT_40;
    zT_42 = 1;
    zT_43 = (unsigned int)zT_42;
    depth = zT_43;
    goto z_bb_23;
    z_bb_21:
    goto z_bb_11;
    z_bb_22:
    return;
    z_bb_23:
    zT_44 = self;
    zT_45 = zF_07BC1EA1_lexerIsAtEnd(zT_44);
    if ((int)(!zT_45)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_50 = self;
    zT_51 = zF_6ACB12FA_lexerPeek(zT_50);
    if ((int)(zT_51 == (unsigned char)(42))) goto z_bb_30; else goto z_bb_31;
    z_bb_25:
    zT_90 = 0;
    if ((int)(depth > (unsigned int)zT_90)) goto z_bb_42; else goto z_bb_43;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_48 = 0;
    zT_47 = depth > (unsigned int)zT_48;
    goto z_bb_29;
    z_bb_28:
    zT_47 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_47) goto z_bb_24; else goto z_bb_25;
    z_bb_30:
    zT_55 = self;
    zT_57 = 1;
    zT_59 = zF_D1AE715C_lexerPeekN(zT_55, (unsigned int)((unsigned int)zT_57));
    zT_54 = zT_59 == (unsigned char)(47);
    goto z_bb_32;
    z_bb_31:
    zT_54 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_54) goto z_bb_33; else goto z_bb_35;
    z_bb_33:
    zT_62 = self;
    zT_63 = zF_7C2FDD01_lexerAdvance(zT_62);
    (void)zT_63;
    zT_64 = self;
    zT_65 = zF_7C2FDD01_lexerAdvance(zT_64);
    (void)zT_65;
    zT_66 = 1;
    zT_68 = depth - (unsigned int)((unsigned int)zT_66);
    depth = zT_68;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_26;
    z_bb_35:
    zT_69 = self;
    zT_70 = zF_6ACB12FA_lexerPeek(zT_69);
    if ((int)(zT_70 == (unsigned char)(47))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_74 = self;
    zT_76 = 1;
    zT_78 = zF_D1AE715C_lexerPeekN(zT_74, (unsigned int)((unsigned int)zT_76));
    zT_73 = zT_78 == (unsigned char)(42);
    goto z_bb_38;
    z_bb_37:
    zT_73 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_73) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_81 = self;
    zT_82 = zF_7C2FDD01_lexerAdvance(zT_81);
    (void)zT_82;
    zT_83 = self;
    zT_84 = zF_7C2FDD01_lexerAdvance(zT_83);
    (void)zT_84;
    zT_85 = 1;
    zT_87 = depth + (unsigned int)((unsigned int)zT_85);
    depth = zT_87;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_34;
    z_bb_41:
    zT_88 = self;
    zT_89 = zF_7C2FDD01_lexerAdvance(zT_88);
    (void)zT_89;
    goto z_bb_40;
    z_bb_42:
    zT_93 = "unterminated block comment";
    zT_95 = 26;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    unterminated_block_msg = zT_94;
    zT_96 = self->count_only;
    if ((int)(!zT_96)) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    goto z_bb_21;
    z_bb_44:
    zT_98 = self->diag;
    zT_106 = 0;
    zT_101 = self->file_id;
    zT_110 = self->pos;
    zT_112 = self->pos;
    zT_104 = unterminated_block_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_98, (unsigned char)((unsigned char)zT_106), (unsigned short)(1), zT_101, (unsigned int)((unsigned int)zT_110), (unsigned int)((unsigned int)zT_112), zT_104);
    goto z_bb_45;
    z_bb_45:
    goto z_bb_43;
}

/* lexerMakeToken */
zT_3A355BD2_Token zF_369DD718_lexerMakeToken(zT_138FFB41_Lexer* self, zT_EAC3E484_TokenKind kind, unsigned int start, zT_85CBA4DB_TokenValue value) {
    unsigned int zT_5;
    unsigned short zT_7;
    zT_3A355BD2_Token zT_8;
    unsigned int zT_9;
    unsigned short zT_10;
    unsigned short span_len;
    zT_5 = self->pos;
    zT_7 = (unsigned short)(unsigned int)(zT_5 - start);
    span_len = zT_7;
    zT_8.kind = kind;
    zT_9 = (unsigned int)start;
    zT_8.span_start = zT_9;
    zT_10 = (unsigned short)span_len;
    zT_8.span_len = zT_10;
    zT_8.value = value;
    return zT_8;
}

/* lexerMakeErrorToken */
zT_3A355BD2_Token zF_19A0FF20_lexerMakeErrorToken(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_3A355BD2_Token zT_2;
    zT_EAC3E484_TokenKind zT_5;
    unsigned int zT_6;
    unsigned short zT_7;
    zT_85CBA4DB_TokenValue zT_8 = {0};
    (void)self;
    zT_5 = zT_EAC3E484_TokenKind_err_token;
    zT_2.kind = zT_5;
    zT_6 = (unsigned int)start;
    zT_2.span_start = zT_6;
    zT_7 = 1;
    zT_2.span_len = zT_7;
    zT_2.value = zT_8;
    return zT_2;
}

/* lexerScanString */
zT_3A355BD2_Token zF_D28972ED_lexerScanString(zT_138FFB41_Lexer* self, unsigned int start) {
    int zT_2;
    int zT_4;
    zT_47B162D1_U8ArrayList* zT_6;
    zT_138FFB41_Lexer* zT_7;
    int zT_8 = 0;
    zT_138FFB41_Lexer* zT_11;
    unsigned char zT_12 = 0;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16 = 0;
    int zT_17;
    zT_3A355BD2_Token zT_18;
    zT_EAC3E484_TokenKind zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned short zT_25;
    zT_85CBA4DB_TokenValue zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29 = {0};
    zT_47B162D1_U8ArrayList* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33 = {0};
    unsigned int zT_35;
    int zT_36;
    unsigned char* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    zT_D3EB6303_StringInterner* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_46 = 0;
    zT_3A355BD2_Token zT_47;
    zT_EAC3E484_TokenKind zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned short zT_54;
    zT_85CBA4DB_TokenValue zT_55;
    int zT_58;
    int zT_59;
    int zT_61;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_F85C5DED_DiagnosticCollector* zT_67;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    int zT_75;
    unsigned int zT_80;
    zT_138FFB41_Lexer* zT_83;
    unsigned int zT_84;
    zT_3A355BD2_Token zT_85 = {0};
    zT_138FFB41_Lexer* zT_86;
    unsigned char zT_87 = 0;
    int zT_90;
    zT_47B162D1_U8ArrayList* zT_92;
    unsigned char zT_93;
    zT_138FFB41_Lexer* zT_95;
    unsigned char zT_96 = 0;
    zT_138FFB41_Lexer* zT_97;
    unsigned char zT_98 = 0;
    int zT_99;
    zT_47B162D1_U8ArrayList* zT_101;
    unsigned char zT_102;
    zT_138FFB41_Lexer* zT_104;
    unsigned int zT_105;
    zT_3A355BD2_Token zT_106 = {0};
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_8F083A69_Slice_zT_0B42B2F8_u sb_slice;
    unsigned int id;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u unterminated_string_msg;
    zT_2 = self->count_only;
    if ((int)(!zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 0;
    zT_6 = self->string_buf;
    zT_6->len = (unsigned int)((unsigned int)zT_4);
    goto z_bb_2;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_7 = self;
    zT_8 = zF_07BC1EA1_lexerIsAtEnd(zT_7);
    if ((int)(!zT_8)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = self;
    zT_12 = zF_6ACB12FA_lexerPeek(zT_11);
    c = zT_12;
    if ((int)(c == (unsigned char)(34))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_104 = self;
    zT_105 = start;
    zT_106 = zF_19A0FF20_lexerMakeErrorToken(zT_104, zT_105);
    return zT_106;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_15 = self;
    zT_16 = zF_7C2FDD01_lexerAdvance(zT_15);
    (void)zT_16;
    zT_17 = self->count_only;
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((int)(c == (unsigned char)(10))) goto z_bb_15; else goto z_bb_14;
    z_bb_9:
    zT_21 = zT_EAC3E484_TokenKind_string_literal;
    zT_18.kind = zT_21;
    zT_22 = (unsigned int)start;
    zT_18.span_start = zT_22;
    zT_23 = self->pos;
    zT_25 = (unsigned short)(unsigned int)(zT_23 - start);
    zT_18.span_len = zT_25;
    zT_27 = 0;
    zT_26.string_id = zT_27;
    zT_18.value = zT_26;
    return zT_18;
    z_bb_10:
    text = zT_29;
    zT_31 = self->string_buf;
    zT_33 = zF_2ADA0742_byteArrayListGetSli(zT_31);
    sb_slice = zT_33;
    zT_35 = sb_slice.len;
    zT_36 = 0;
    if ((int)(zT_35 > (unsigned int)zT_36)) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    text = sb_slice;
    goto z_bb_12;
    z_bb_12:
    zT_43 = self->interner;
    zT_44 = text;
    zT_46 = zF_50C274AF_stringInternerInter(zT_43, zT_44);
    id = zT_46;
    zT_50 = zT_EAC3E484_TokenKind_string_literal;
    zT_47.kind = zT_50;
    zT_51 = (unsigned int)start;
    zT_47.span_start = zT_51;
    zT_52 = self->pos;
    zT_54 = (unsigned short)(unsigned int)(zT_52 - start);
    zT_47.span_len = zT_54;
    zT_55.string_id = id;
    zT_47.value = zT_55;
    return zT_47;
    z_bb_13:
    zT_39 = "";
    zT_41 = 0;
    zT_40.ptr = zT_39;
    zT_40.len = zT_41;
    empty_str = zT_40;
    text = empty_str;
    goto z_bb_12;
    z_bb_14:
    zT_59 = 0;
    zT_58 = c == zT_59;
    goto z_bb_16;
    z_bb_15:
    zT_58 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_58) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_61 = self->count_only;
    if ((int)(!zT_61)) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_86 = self;
    zT_87 = zF_7C2FDD01_lexerAdvance(zT_86);
    (void)zT_87;
    if ((int)(c == (unsigned char)(92))) goto z_bb_21; else goto z_bb_23;
    z_bb_19:
    zT_64 = "unterminated string literal";
    zT_66 = 27;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    unterminated_string_msg = zT_65;
    zT_67 = self->diag;
    zT_75 = 0;
    zT_70 = self->file_id;
    zT_80 = self->pos;
    zT_73 = unterminated_string_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_67, (unsigned char)((unsigned char)zT_75), (unsigned short)(0), zT_70, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_80), zT_73);
    goto z_bb_20;
    z_bb_20:
    zT_83 = self;
    zT_84 = start;
    zT_85 = zF_19A0FF20_lexerMakeErrorToken(zT_83, zT_84);
    return zT_85;
    z_bb_21:
    zT_90 = self->count_only;
    if ((int)(!zT_90)) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_6;
    z_bb_23:
    zT_99 = self->count_only;
    if ((int)(!zT_99)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_92 = self->string_buf;
    zT_95 = self;
    zT_96 = zF_7D4EA30A_lexerParseEscapeSeq(zT_95);
    zT_93 = zT_96;
    zF_463FE7A4_byteArrayListAppend(zT_92, zT_93);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_97 = self;
    zT_98 = zF_7D4EA30A_lexerParseEscapeSeq(zT_97);
    (void)zT_98;
    goto z_bb_25;
    z_bb_27:
    zT_101 = self->string_buf;
    zT_102 = c;
    zF_463FE7A4_byteArrayListAppend(zT_101, zT_102);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_22;
}

/* lexerScanChar */
zT_3A355BD2_Token zF_616D7368_lexerScanChar(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    int zT_3 = 0;
    int zT_4;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6 = 0;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_15;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    int zT_23;
    unsigned int zT_28;
    zT_138FFB41_Lexer* zT_31;
    unsigned char zT_32 = 0;
    zT_138FFB41_Lexer* zT_35;
    unsigned char zT_36 = 0;
    zT_138FFB41_Lexer* zT_37;
    unsigned int zT_39;
    zT_85CBA4DB_TokenValue zT_40;
    zT_85CBA4DB_TokenValue zT_44;
    zT_79FAE712_u64 zT_45;
    zT_3A355BD2_Token zT_46 = {0};
    int zT_48;
    unsigned int zT_49;
    zT_138FFB41_Lexer* zT_51;
    unsigned char zT_52 = 0;
    zT_138FFB41_Lexer* zT_55;
    unsigned char zT_56 = 0;
    unsigned int zT_57;
    unsigned int zT_58;
    zT_138FFB41_Lexer* zT_59;
    unsigned char zT_60 = 0;
    unsigned char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    int zT_67;
    zT_F85C5DED_DiagnosticCollector* zT_69;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    int zT_77;
    unsigned int zT_82;
    zT_138FFB41_Lexer* zT_85;
    unsigned char zT_86 = 0;
    zT_3A355BD2_Token zT_87;
    zT_EAC3E484_TokenKind zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned short zT_94;
    zT_85CBA4DB_TokenValue zT_95;
    zT_79FAE712_u64 zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_char_msg;
    unsigned int value;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u expected_close_msg;
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if (zT_3) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = self;
    zT_6 = zF_6ACB12FA_lexerPeek(zT_5);
    zT_4 = zT_6 == (unsigned char)(39);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = "empty character literal";
    zT_12 = 23;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    empty_char_msg = zT_11;
    zT_13 = self->count_only;
    if ((int)(!zT_13)) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_48 = 0;
    zT_49 = (unsigned int)zT_48;
    value = zT_49;
    zT_51 = self;
    zT_52 = zF_7C2FDD01_lexerAdvance(zT_51);
    c = zT_52;
    if ((int)(c == (unsigned char)(92))) goto z_bb_10; else goto z_bb_12;
    z_bb_6:
    zT_15 = self->diag;
    zT_23 = 0;
    zT_18 = self->file_id;
    zT_28 = self->pos;
    zT_21 = empty_char_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_15, (unsigned char)((unsigned char)zT_23), (unsigned short)(2), zT_18, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_28), zT_21);
    goto z_bb_7;
    z_bb_7:
    zT_31 = self;
    zT_32 = zF_6ACB12FA_lexerPeek(zT_31);
    if ((int)(zT_32 == (unsigned char)(39))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self;
    zT_36 = zF_7C2FDD01_lexerAdvance(zT_35);
    (void)zT_36;
    goto z_bb_9;
    z_bb_9:
    zT_37 = self;
    zT_39 = start;
    zT_45 = 0;
    zT_44.int_val = zT_45;
    zT_40 = zT_44;
    zT_46 = zF_369DD718_lexerMakeToken(zT_37, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), zT_39, zT_40);
    return zT_46;
    z_bb_10:
    zT_55 = self;
    zT_56 = zF_7D4EA30A_lexerParseEscapeSeq(zT_55);
    zT_57 = (unsigned int)zT_56;
    value = zT_57;
    goto z_bb_11;
    z_bb_11:
    zT_59 = self;
    zT_60 = zF_6ACB12FA_lexerPeek(zT_59);
    if ((int)(zT_60 != (unsigned char)(39))) goto z_bb_13; else goto z_bb_15;
    z_bb_12:
    zT_58 = (unsigned int)c;
    value = zT_58;
    goto z_bb_11;
    z_bb_13:
    zT_64 = "expected closing ' in character literal";
    zT_66 = 39;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    expected_close_msg = zT_65;
    zT_67 = self->count_only;
    if ((int)(!zT_67)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_90 = zT_EAC3E484_TokenKind_char_literal;
    zT_87.kind = zT_90;
    zT_91 = (unsigned int)start;
    zT_87.span_start = zT_91;
    zT_92 = self->pos;
    zT_94 = (unsigned short)(unsigned int)(zT_92 - start);
    zT_87.span_len = zT_94;
    zT_96 = (zT_79FAE712_u64)value;
    zT_95.int_val = zT_96;
    zT_87.value = zT_95;
    return zT_87;
    z_bb_15:
    zT_85 = self;
    zT_86 = zF_7C2FDD01_lexerAdvance(zT_85);
    (void)zT_86;
    goto z_bb_14;
    z_bb_16:
    zT_69 = self->diag;
    zT_77 = 0;
    zT_72 = self->file_id;
    zT_82 = self->pos;
    zT_75 = expected_close_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_69, (unsigned char)((unsigned char)zT_77), (unsigned short)(2), zT_72, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_82), zT_75);
    goto z_bb_17;
    z_bb_17:
    goto z_bb_14;
}

/* lexerScanNumber */
zT_3A355BD2_Token zF_EF8134BD_lexerScanNumber(zT_138FFB41_Lexer* self, unsigned int start, unsigned char first) {
    int zT_4;
    int zT_6;
    unsigned char zT_7;
    int zT_10;
    zT_138FFB41_Lexer* zT_11;
    int zT_12 = 0;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16 = 0;
    int zT_19;
    int zT_22;
    unsigned char zT_23;
    zT_138FFB41_Lexer* zT_24;
    unsigned char zT_25 = 0;
    int zT_28;
    int zT_31;
    unsigned char zT_32;
    zT_138FFB41_Lexer* zT_33;
    unsigned char zT_34 = 0;
    int zT_37;
    int zT_40;
    unsigned char zT_41;
    zT_138FFB41_Lexer* zT_42;
    unsigned char zT_43 = 0;
    zT_138FFB41_Lexer* zT_44;
    int zT_45 = 0;
    zT_138FFB41_Lexer* zT_48;
    unsigned char zT_49 = 0;
    zT_138FFB41_Lexer* zT_52;
    unsigned char zT_53 = 0;
    unsigned char zT_54;
    unsigned char zT_55;
    int zT_56 = 0;
    zT_138FFB41_Lexer* zT_58;
    unsigned char zT_59 = 0;
    int zT_60;
    int zT_62;
    zT_138FFB41_Lexer* zT_63;
    unsigned char zT_64 = 0;
    int zT_67;
    zT_138FFB41_Lexer* zT_68;
    int zT_70;
    unsigned char zT_72 = 0;
    zT_138FFB41_Lexer* zT_75;
    unsigned char zT_76 = 0;
    int zT_77;
    zT_138FFB41_Lexer* zT_78;
    int zT_79 = 0;
    zT_138FFB41_Lexer* zT_82;
    unsigned char zT_83 = 0;
    zT_138FFB41_Lexer* zT_86;
    unsigned char zT_87 = 0;
    unsigned char zT_88;
    int zT_89 = 0;
    zT_138FFB41_Lexer* zT_91;
    unsigned char zT_92 = 0;
    int zT_93;
    int zT_95;
    zT_138FFB41_Lexer* zT_96;
    unsigned char zT_97 = 0;
    int zT_100;
    zT_138FFB41_Lexer* zT_101;
    unsigned char zT_102 = 0;
    zT_138FFB41_Lexer* zT_105;
    unsigned char zT_106 = 0;
    zT_138FFB41_Lexer* zT_107;
    unsigned char zT_108 = 0;
    int zT_111;
    zT_138FFB41_Lexer* zT_112;
    unsigned char zT_113 = 0;
    zT_138FFB41_Lexer* zT_116;
    unsigned char zT_117 = 0;
    zT_138FFB41_Lexer* zT_118;
    int zT_119 = 0;
    int zT_121;
    unsigned char zT_122;
    zT_138FFB41_Lexer* zT_123;
    unsigned char zT_124 = 0;
    int zT_125 = 0;
    zT_138FFB41_Lexer* zT_126;
    unsigned char zT_127 = 0;
    int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned char* zT_131;
    unsigned int zT_133;
    unsigned char* zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    double zT_139 = 0;
    zT_138FFB41_Lexer* zT_140;
    unsigned int zT_142;
    zT_85CBA4DB_TokenValue zT_143;
    zT_85CBA4DB_TokenValue zT_147;
    zT_3A355BD2_Token zT_148 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_150;
    unsigned char zT_151;
    zT_79FAE712_u64 zT_152 = 0;
    zT_79FAE712_u64 zT_153;
    int zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    int zT_157 = 0;
    unsigned char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    int zT_163;
    zT_F85C5DED_DiagnosticCollector* zT_165;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    int zT_173;
    unsigned int zT_178;
    zT_138FFB41_Lexer* zT_181;
    unsigned int zT_183;
    zT_85CBA4DB_TokenValue zT_184;
    zT_85CBA4DB_TokenValue zT_188;
    zT_3A355BD2_Token zT_189 = {0};
    int is_float;
    unsigned char base;
    unsigned char next;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    double value;
    zT_79FAE712_u64 value_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u overflow_msg;
    zT_4 = 0;
    is_float = zT_4;
    zT_6 = 10;
    zT_7 = (unsigned char)zT_6;
    base = zT_7;
    if ((int)(first == (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = zF_07BC1EA1_lexerIsAtEnd(zT_11);
    zT_10 = !zT_12;
    goto z_bb_3;
    z_bb_2:
    zT_10 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = self;
    zT_16 = zF_6ACB12FA_lexerPeek(zT_15);
    next = zT_16;
    if ((int)(next == (unsigned char)(120))) goto z_bb_7; else goto z_bb_6;
    z_bb_5:
    goto z_bb_23;
    z_bb_6:
    zT_19 = next == (unsigned char)(88);
    goto z_bb_8;
    z_bb_7:
    zT_19 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_19) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_22 = 16;
    zT_23 = (unsigned char)zT_22;
    base = zT_23;
    zT_24 = self;
    zT_25 = zF_7C2FDD01_lexerAdvance(zT_24);
    (void)zT_25;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_5;
    z_bb_11:
    if ((int)(next == (unsigned char)(98))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_28 = next == (unsigned char)(66);
    goto z_bb_14;
    z_bb_13:
    zT_28 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_28) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_31 = 2;
    zT_32 = (unsigned char)zT_31;
    base = zT_32;
    zT_33 = self;
    zT_34 = zF_7C2FDD01_lexerAdvance(zT_33);
    (void)zT_34;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    if ((int)(next == (unsigned char)(111))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_37 = next == (unsigned char)(79);
    goto z_bb_20;
    z_bb_19:
    zT_37 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_37) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_40 = 8;
    zT_41 = (unsigned char)zT_40;
    base = zT_41;
    zT_42 = self;
    zT_43 = zF_7C2FDD01_lexerAdvance(zT_42);
    (void)zT_43;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_16;
    z_bb_23:
    zT_44 = self;
    zT_45 = zF_07BC1EA1_lexerIsAtEnd(zT_44);
    if ((int)(!zT_45)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_48 = self;
    zT_49 = zF_6ACB12FA_lexerPeek(zT_48);
    c = zT_49;
    if ((int)(c == (unsigned char)(95))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_60 = 10;
    if ((int)(base == zT_60)) goto z_bb_31; else goto z_bb_32;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_52 = self;
    zT_53 = zF_7C2FDD01_lexerAdvance(zT_52);
    (void)zT_53;
    goto z_bb_26;
    z_bb_28:
    zT_54 = c;
    zT_55 = base;
    zT_56 = zF_C5E3A034_isDigitInBase(zT_54, zT_55);
    if ((int)(!zT_56)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_58 = self;
    zT_59 = zF_7C2FDD01_lexerAdvance(zT_58);
    (void)zT_59;
    goto z_bb_26;
    z_bb_31:
    zT_63 = self;
    zT_64 = zF_6ACB12FA_lexerPeek(zT_63);
    zT_62 = zT_64 == (unsigned char)(46);
    goto z_bb_33;
    z_bb_32:
    zT_62 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_62) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_68 = self;
    zT_70 = 1;
    zT_72 = zF_D1AE715C_lexerPeekN(zT_68, (unsigned int)((unsigned int)zT_70));
    zT_67 = zT_72 != (unsigned char)(46);
    goto z_bb_36;
    z_bb_35:
    zT_67 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_67) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_75 = self;
    zT_76 = zF_7C2FDD01_lexerAdvance(zT_75);
    (void)zT_76;
    zT_77 = 1;
    is_float = zT_77;
    goto z_bb_39;
    z_bb_38:
    zT_93 = 10;
    if ((int)(base == zT_93)) goto z_bb_47; else goto z_bb_48;
    z_bb_39:
    zT_78 = self;
    zT_79 = zF_07BC1EA1_lexerIsAtEnd(zT_78);
    if ((int)(!zT_79)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_82 = self;
    zT_83 = zF_6ACB12FA_lexerPeek(zT_82);
    c = zT_83;
    if ((int)(c == (unsigned char)(95))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_86 = self;
    zT_87 = zF_7C2FDD01_lexerAdvance(zT_86);
    (void)zT_87;
    goto z_bb_42;
    z_bb_44:
    zT_88 = c;
    zT_89 = zF_C95A8EC6_isDigit(zT_88);
    if ((int)(!zT_89)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_91 = self;
    zT_92 = zF_7C2FDD01_lexerAdvance(zT_91);
    (void)zT_92;
    goto z_bb_42;
    z_bb_47:
    zT_96 = self;
    zT_97 = zF_6ACB12FA_lexerPeek(zT_96);
    if ((int)(zT_97 == (unsigned char)(101))) goto z_bb_51; else goto z_bb_50;
    z_bb_48:
    zT_95 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_95) goto z_bb_53; else goto z_bb_54;
    z_bb_50:
    zT_101 = self;
    zT_102 = zF_6ACB12FA_lexerPeek(zT_101);
    zT_100 = zT_102 == (unsigned char)(69);
    goto z_bb_52;
    z_bb_51:
    zT_100 = 1;
    goto z_bb_52;
    z_bb_52:
    zT_95 = zT_100;
    goto z_bb_49;
    z_bb_53:
    zT_105 = self;
    zT_106 = zF_7C2FDD01_lexerAdvance(zT_105);
    (void)zT_106;
    zT_107 = self;
    zT_108 = zF_6ACB12FA_lexerPeek(zT_107);
    if ((int)(zT_108 == (unsigned char)(43))) goto z_bb_56; else goto z_bb_55;
    z_bb_54:
    zT_130 = self->source;
    zT_131 = zT_130.ptr;
    zT_133 = self->pos;
    zT_134 = zT_131 + start;
    zT_135 = zT_133 - start;
    zT_136.ptr = zT_134;
    zT_136.len = zT_135;
    text = zT_136;
    if (is_float) goto z_bb_67; else goto z_bb_69;
    z_bb_55:
    zT_112 = self;
    zT_113 = zF_6ACB12FA_lexerPeek(zT_112);
    zT_111 = zT_113 == (unsigned char)(45);
    goto z_bb_57;
    z_bb_56:
    zT_111 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_111) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_116 = self;
    zT_117 = zF_7C2FDD01_lexerAdvance(zT_116);
    (void)zT_117;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_60;
    z_bb_60:
    zT_118 = self;
    zT_119 = zF_07BC1EA1_lexerIsAtEnd(zT_118);
    if ((int)(!zT_119)) goto z_bb_64; else goto z_bb_65;
    z_bb_61:
    zT_126 = self;
    zT_127 = zF_7C2FDD01_lexerAdvance(zT_126);
    (void)zT_127;
    goto z_bb_63;
    z_bb_62:
    zT_128 = 1;
    is_float = zT_128;
    goto z_bb_54;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_123 = self;
    zT_124 = zF_6ACB12FA_lexerPeek(zT_123);
    zT_122 = zT_124;
    zT_125 = zF_C95A8EC6_isDigit(zT_122);
    zT_121 = zT_125;
    goto z_bb_66;
    z_bb_65:
    zT_121 = 0;
    goto z_bb_66;
    z_bb_66:
    if (zT_121) goto z_bb_61; else goto z_bb_62;
    z_bb_67:
    zT_138 = text;
    zT_139 = zF_37CDE8A4_parseF64(zT_138);
    value = zT_139;
    zT_140 = self;
    zT_142 = start;
    zT_147.float_val = value;
    zT_143 = zT_147;
    zT_148 = zF_369DD718_lexerMakeToken(zT_140, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), zT_142, zT_143);
    return zT_148;
    { zT_3A355BD2_Token zT_ret_void = {0}; return zT_ret_void; }
    z_bb_69:
    zT_150 = text;
    zT_151 = base;
    zT_152 = zF_8EC79679_parseU64(zT_150, zT_151);
    value_1 = zT_152;
    zT_153 = 18446744073709551615ULL;
    if ((int)(value_1 == (zT_79FAE712_u64)zT_153)) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_156 = text;
    zT_157 = zF_6E4D822B_isU64MaxLiteral(zT_156);
    zT_155 = !zT_157;
    goto z_bb_72;
    z_bb_71:
    zT_155 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_155) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_160 = "integer literal overflow; value truncated";
    zT_162 = 41;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    overflow_msg = zT_161;
    zT_163 = self->count_only;
    if ((int)(!zT_163)) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    zT_181 = self;
    zT_183 = start;
    zT_188.int_val = value_1;
    zT_184 = zT_188;
    zT_189 = zF_369DD718_lexerMakeToken(zT_181, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), zT_183, zT_184);
    return zT_189;
    z_bb_75:
    zT_165 = self->diag;
    zT_173 = 1;
    zT_168 = self->file_id;
    zT_178 = self->pos;
    zT_171 = overflow_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_165, (unsigned char)((unsigned char)zT_173), (unsigned short)(7), zT_168, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_178), zT_171);
    goto z_bb_76;
    z_bb_76:
    goto z_bb_74;
}

/* lexerScanIdentifierOrKeyword */
zT_3A355BD2_Token zF_EC7F12C5_lexerScanIdentifier(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    int zT_3 = 0;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7 = 0;
    unsigned char zT_8;
    int zT_9 = 0;
    int zT_11;
    unsigned char zT_12;
    int zT_13 = 0;
    int zT_15;
    zT_138FFB41_Lexer* zT_18;
    unsigned char zT_19 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned char* zT_22;
    unsigned int zT_24;
    unsigned char* zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_29;
    int zT_30;
    int zT_32;
    unsigned char* zT_33;
    int zT_34;
    unsigned char zT_35;
    int zT_39;
    unsigned int zT_40;
    int zT_41;
    zT_D3EB6303_StringInterner* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_46 = 0;
    zT_138FFB41_Lexer* zT_47;
    unsigned int zT_49;
    zT_85CBA4DB_TokenValue zT_50;
    zT_85CBA4DB_TokenValue zT_54;
    zT_3A355BD2_Token zT_55 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    zT_ACDCBA03_Opt_84 zT_57 = {0};
    unsigned char zT_58;
    zT_138FFB41_Lexer* zT_60;
    zT_EAC3E484_TokenKind zT_61;
    unsigned int zT_62;
    zT_85CBA4DB_TokenValue zT_63;
    zT_85CBA4DB_TokenValue zT_64 = {0};
    zT_3A355BD2_Token zT_66 = {0};
    int zT_68;
    unsigned int zT_69;
    int zT_70;
    zT_D3EB6303_StringInterner* zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned int zT_75 = 0;
    unsigned int zT_77;
    unsigned char* zT_80;
    unsigned int zT_81;
    unsigned char zT_82;
    int zT_85;
    unsigned char* zT_86;
    unsigned int zT_87;
    unsigned char zT_88;
    int zT_91;
    unsigned char* zT_92;
    unsigned int zT_93;
    unsigned char zT_94;
    int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    int zT_103;
    unsigned char* zT_104;
    unsigned int zT_105;
    unsigned char zT_106;
    int zT_109;
    unsigned char* zT_110;
    unsigned int zT_111;
    unsigned char zT_112;
    int zT_115;
    unsigned char* zT_116;
    unsigned int zT_117;
    unsigned char zT_118;
    int zT_121;
    unsigned char* zT_122;
    unsigned int zT_123;
    unsigned char zT_124;
    int zT_127;
    unsigned char* zT_128;
    unsigned int zT_129;
    unsigned char zT_130;
    int zT_133;
    unsigned char* zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_137;
    unsigned int zT_138;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_139;
    zT_138FFB41_Lexer* zT_140;
    unsigned int zT_142;
    zT_85CBA4DB_TokenValue zT_143;
    zT_85CBA4DB_TokenValue zT_147;
    zT_3A355BD2_Token zT_148 = {0};
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int string_id;
    zT_EAC3E484_TokenKind kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u lxm;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if ((int)(!zT_3)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_6ACB12FA_lexerPeek(zT_6);
    c = zT_7;
    zT_8 = c;
    zT_9 = zF_0D29E41B_isAlpha(zT_8);
    if ((int)(!zT_9)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_21 = self->source;
    zT_22 = zT_21.ptr;
    zT_24 = self->pos;
    zT_25 = zT_22 + start;
    zT_26 = zT_24 - start;
    zT_27.ptr = zT_25;
    zT_27.len = zT_26;
    text = zT_27;
    zT_29 = text.len;
    zT_30 = 1;
    if ((int)(zT_29 == (unsigned int)zT_30)) goto z_bb_13; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_12 = c;
    zT_13 = zF_C95A8EC6_isDigit(zT_12);
    zT_11 = !zT_13;
    goto z_bb_7;
    z_bb_6:
    zT_11 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_11) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_15 = c != (unsigned char)(95);
    goto z_bb_10;
    z_bb_9:
    zT_15 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_15) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    goto z_bb_3;
    z_bb_12:
    zT_18 = self;
    zT_19 = zF_7C2FDD01_lexerAdvance(zT_18);
    (void)zT_19;
    goto z_bb_4;
    z_bb_13:
    zT_33 = text.ptr;
    zT_34 = 0;
    zT_35 = zT_33[zT_34];
    zT_32 = zT_35 == (unsigned char)(95);
    goto z_bb_15;
    z_bb_14:
    zT_32 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_32) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    string_id = zT_40;
    zT_41 = self->count_only;
    if ((int)(!zT_41)) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_56 = text;
    zT_57 = zF_6FF3ED46_lookupKeyword(zT_56);
    zT_58 = zT_57.has_value;
    if (zT_58) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_43 = self->interner;
    zT_44 = text;
    zT_46 = zF_50C274AF_stringInternerInter(zT_43, zT_44);
    string_id = zT_46;
    goto z_bb_19;
    z_bb_19:
    zT_47 = self;
    zT_49 = start;
    zT_54.string_id = string_id;
    zT_50 = zT_54;
    zT_55 = zF_369DD718_lexerMakeToken(zT_47, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore), zT_49, zT_50);
    return zT_55;
    z_bb_20:
    kind = zT_57.value;
    zT_60 = self;
    zT_61 = kind;
    zT_62 = start;
    zT_63 = zT_64;
    zT_66 = zF_369DD718_lexerMakeToken(zT_60, zT_61, zT_62, zT_63);
    return zT_66;
    z_bb_21:
    zT_68 = 0;
    zT_69 = (unsigned int)zT_68;
    string_id = zT_69;
    zT_70 = self->count_only;
    if ((int)(!zT_70)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_72 = self->interner;
    zT_73 = text;
    zT_75 = zF_50C274AF_stringInternerInter(zT_72, zT_73);
    string_id = zT_75;
    goto z_bb_23;
    z_bb_23:
    zT_77 = text.len;
    if ((int)(zT_77 == (unsigned int)(9))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_80 = text.ptr;
    zT_81 = 0;
    zT_82 = zT_80[zT_81];
    if ((int)(zT_82 == (unsigned char)(110))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    zT_140 = self;
    zT_142 = start;
    zT_147.string_id = string_id;
    zT_143 = zT_147;
    zT_148 = zF_369DD718_lexerMakeToken(zT_140, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier), zT_142, zT_143);
    return zT_148;
    z_bb_26:
    zT_86 = text.ptr;
    zT_87 = 1;
    zT_88 = zT_86[zT_87];
    zT_85 = zT_88 == (unsigned char)(101);
    goto z_bb_28;
    z_bb_27:
    zT_85 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_85) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_92 = text.ptr;
    zT_93 = 2;
    zT_94 = zT_92[zT_93];
    zT_91 = zT_94 == (unsigned char)(105);
    goto z_bb_31;
    z_bb_30:
    zT_91 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_91) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_98 = text.ptr;
    zT_99 = 3;
    zT_100 = zT_98[zT_99];
    zT_97 = zT_100 == (unsigned char)(103);
    goto z_bb_34;
    z_bb_33:
    zT_97 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_97) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_104 = text.ptr;
    zT_105 = 4;
    zT_106 = zT_104[zT_105];
    zT_103 = zT_106 == (unsigned char)(104);
    goto z_bb_37;
    z_bb_36:
    zT_103 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_103) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_110 = text.ptr;
    zT_111 = 5;
    zT_112 = zT_110[zT_111];
    zT_109 = zT_112 == (unsigned char)(98);
    goto z_bb_40;
    z_bb_39:
    zT_109 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_109) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_116 = text.ptr;
    zT_117 = 6;
    zT_118 = zT_116[zT_117];
    zT_115 = zT_118 == (unsigned char)(111);
    goto z_bb_43;
    z_bb_42:
    zT_115 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_115) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_122 = text.ptr;
    zT_123 = 7;
    zT_124 = zT_122[zT_123];
    zT_121 = zT_124 == (unsigned char)(114);
    goto z_bb_46;
    z_bb_45:
    zT_121 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_121) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_128 = text.ptr;
    zT_129 = 8;
    zT_130 = zT_128[zT_129];
    zT_127 = zT_130 == (unsigned char)(115);
    goto z_bb_49;
    z_bb_48:
    zT_127 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_127) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_133 = self->count_only;
    if ((int)(!zT_133)) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    goto z_bb_25;
    z_bb_52:
    zT_136 = "LEX";
    zT_138 = 3;
    zT_137.ptr = zT_136;
    zT_137.len = zT_138;
    lxm = zT_137;
    zT_139 = lxm;
    zF_E4B2EF19_stderr_write(zT_139);
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
}

/* lexerScanBuiltinIdentifier */
zT_3A355BD2_Token zF_9C3BDAA8_lexerScanBuiltinIde(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    int zT_3 = 0;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7 = 0;
    unsigned char zT_8;
    int zT_9 = 0;
    int zT_11;
    zT_138FFB41_Lexer* zT_14;
    unsigned char zT_15 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char* zT_18;
    unsigned int zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    int zT_25;
    unsigned int zT_26;
    int zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_32 = 0;
    unsigned int zT_34;
    unsigned char* zT_37;
    unsigned int zT_38;
    unsigned char zT_39;
    int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    unsigned char zT_45;
    int zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    unsigned char zT_57;
    int zT_60;
    unsigned char* zT_61;
    unsigned int zT_62;
    unsigned char zT_63;
    int zT_66;
    unsigned char* zT_67;
    unsigned int zT_68;
    unsigned char zT_69;
    int zT_72;
    unsigned char* zT_73;
    unsigned int zT_74;
    unsigned char zT_75;
    int zT_78;
    unsigned char* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    int zT_84;
    unsigned char* zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    zT_138FFB41_Lexer* zT_90;
    unsigned int zT_92;
    zT_85CBA4DB_TokenValue zT_93;
    zT_85CBA4DB_TokenValue zT_97;
    zT_3A355BD2_Token zT_98 = {0};
    zT_138FFB41_Lexer* zT_99;
    unsigned int zT_101;
    zT_85CBA4DB_TokenValue zT_102;
    zT_85CBA4DB_TokenValue zT_106;
    zT_3A355BD2_Token zT_107 = {0};
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int string_id;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if ((int)(!zT_3)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_6ACB12FA_lexerPeek(zT_6);
    c = zT_7;
    zT_8 = c;
    zT_9 = zF_97170599_isAlphaNum(zT_8);
    if ((int)(!zT_9)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17 = self->source;
    zT_18 = zT_17.ptr;
    zT_20 = self->pos;
    zT_21 = zT_18 + start;
    zT_22 = zT_20 - start;
    zT_23.ptr = zT_21;
    zT_23.len = zT_22;
    text = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    string_id = zT_26;
    zT_27 = self->count_only;
    if ((int)(!zT_27)) goto z_bb_10; else goto z_bb_11;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = c != (unsigned char)(95);
    goto z_bb_7;
    z_bb_6:
    zT_11 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_11) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_14 = self;
    zT_15 = zF_7C2FDD01_lexerAdvance(zT_14);
    (void)zT_15;
    goto z_bb_4;
    z_bb_10:
    zT_29 = self->interner;
    zT_30 = text;
    zT_32 = zF_50C274AF_stringInternerInter(zT_29, zT_30);
    string_id = zT_32;
    goto z_bb_11;
    z_bb_11:
    zT_34 = text.len;
    if ((int)(zT_34 == (unsigned int)(9))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_37 = text.ptr;
    zT_38 = 0;
    zT_39 = zT_37[zT_38];
    if ((int)(zT_39 == (unsigned char)(64))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_99 = self;
    zT_101 = start;
    zT_106.string_id = string_id;
    zT_102 = zT_106;
    zT_107 = zF_369DD718_lexerMakeToken(zT_99, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier), zT_101, zT_102);
    return zT_107;
    z_bb_14:
    zT_43 = text.ptr;
    zT_44 = 1;
    zT_45 = zT_43[zT_44];
    zT_42 = zT_45 == (unsigned char)(99);
    goto z_bb_16;
    z_bb_15:
    zT_42 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_49 = text.ptr;
    zT_50 = 2;
    zT_51 = zT_49[zT_50];
    zT_48 = zT_51 == (unsigned char)(73);
    goto z_bb_19;
    z_bb_18:
    zT_48 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_48) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_55 = text.ptr;
    zT_56 = 3;
    zT_57 = zT_55[zT_56];
    zT_54 = zT_57 == (unsigned char)(110);
    goto z_bb_22;
    z_bb_21:
    zT_54 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_54) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_61 = text.ptr;
    zT_62 = 4;
    zT_63 = zT_61[zT_62];
    zT_60 = zT_63 == (unsigned char)(99);
    goto z_bb_25;
    z_bb_24:
    zT_60 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_60) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_67 = text.ptr;
    zT_68 = 5;
    zT_69 = zT_67[zT_68];
    zT_66 = zT_69 == (unsigned char)(108);
    goto z_bb_28;
    z_bb_27:
    zT_66 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_66) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_73 = text.ptr;
    zT_74 = 6;
    zT_75 = zT_73[zT_74];
    zT_72 = zT_75 == (unsigned char)(117);
    goto z_bb_31;
    z_bb_30:
    zT_72 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_72) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_79 = text.ptr;
    zT_80 = 7;
    zT_81 = zT_79[zT_80];
    zT_78 = zT_81 == (unsigned char)(100);
    goto z_bb_34;
    z_bb_33:
    zT_78 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_78) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_85 = text.ptr;
    zT_86 = 8;
    zT_87 = zT_85[zT_86];
    zT_84 = zT_87 == (unsigned char)(101);
    goto z_bb_37;
    z_bb_36:
    zT_84 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_84) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_90 = self;
    zT_92 = start;
    zT_97.string_id = string_id;
    zT_93 = zT_97;
    zT_98 = zF_369DD718_lexerMakeToken(zT_90, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_c_include_builtin), zT_92, zT_93);
    return zT_98;
    z_bb_39:
    goto z_bb_13;
}

/* isAlpha */
int zF_0D29E41B_isAlpha(unsigned char c) {
    int zT_3;
    int zT_6;
    int zT_9;
    int zT_12;
    if ((int)(c >= (unsigned char)(97))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(122);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    if ((int)(c >= (unsigned char)(65))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_11; else goto z_bb_10;
    z_bb_7:
    zT_9 = c <= (unsigned char)(90);
    goto z_bb_9;
    z_bb_8:
    zT_9 = 0;
    goto z_bb_9;
    z_bb_9:
    zT_6 = zT_9;
    goto z_bb_6;
    z_bb_10:
    zT_12 = c == (unsigned char)(95);
    goto z_bb_12;
    z_bb_11:
    zT_12 = 1;
    goto z_bb_12;
    z_bb_12:
    return zT_12;
}

/* isDigit */
int zF_C95A8EC6_isDigit(unsigned char c) {
    int zT_3;
    if ((int)(c >= (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(57);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    return zT_3;
}

/* isAlphaNum */
int zF_97170599_isAlphaNum(unsigned char c) {
    unsigned char zT_1;
    int zT_2 = 0;
    int zT_3;
    unsigned char zT_4;
    int zT_5 = 0;
    zT_1 = c;
    zT_2 = zF_0D29E41B_isAlpha(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = c;
    zT_5 = zF_C95A8EC6_isDigit(zT_4);
    zT_3 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_3;
}

/* hexDigitValue */
unsigned char zF_24E4C5BC_hexDigitValue(unsigned char c) {
    int zT_3;
    int zT_10;
    int zT_15;
    int zT_19;
    int zT_24;
    if ((int)(c >= (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(57);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(c - (unsigned char)(48));
    z_bb_5:
    if ((int)(c >= (unsigned char)(97))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_10 = c <= (unsigned char)(102);
    goto z_bb_8;
    z_bb_7:
    zT_10 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_10) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_15 = 10;
    return (unsigned char)((unsigned char)(c - (unsigned char)(97)) + zT_15);
    z_bb_10:
    if ((int)(c >= (unsigned char)(65))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_19 = c <= (unsigned char)(70);
    goto z_bb_13;
    z_bb_12:
    zT_19 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_19) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_24 = 10;
    return (unsigned char)((unsigned char)(c - (unsigned char)(65)) + zT_24);
    z_bb_15:
    return (unsigned char)(255);
}

/* lexerParseHexEscape */
unsigned char zF_3EAE09C6_lexerParseHexEscape(zT_138FFB41_Lexer* self) {
    int zT_2;
    unsigned char zT_3;
    int zT_5;
    unsigned char zT_6;
    int zT_7;
    int zT_9;
    zT_138FFB41_Lexer* zT_10;
    int zT_11 = 0;
    unsigned char zT_14;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16 = 0;
    unsigned char zT_17 = 0;
    int zT_18;
    int zT_20;
    unsigned char zT_22;
    zT_138FFB41_Lexer* zT_23;
    unsigned char zT_24 = 0;
    int zT_25;
    unsigned char zT_27;
    int zT_28;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    int zT_34;
    zT_F85C5DED_DiagnosticCollector* zT_36;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    int zT_44;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_52;
    unsigned char value;
    unsigned char count;
    unsigned char digit;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hex;
    zT_2 = 0;
    zT_3 = (unsigned char)zT_2;
    value = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned char)zT_5;
    count = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = 2;
    if ((int)(count < zT_7)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_15 = self;
    zT_16 = zF_6ACB12FA_lexerPeek(zT_15);
    zT_14 = zT_16;
    zT_17 = zF_24E4C5BC_hexDigitValue(zT_14);
    digit = zT_17;
    zT_18 = 255;
    if ((int)(digit == zT_18)) goto z_bb_8; else goto z_bb_9;
    z_bb_3:
    zT_28 = 0;
    if ((int)(count == zT_28)) goto z_bb_10; else goto z_bb_11;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_10 = self;
    zT_11 = zF_07BC1EA1_lexerIsAtEnd(zT_10);
    zT_9 = !zT_11;
    goto z_bb_7;
    z_bb_6:
    zT_9 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_20 = 16;
    zT_22 = (unsigned char)(value * zT_20) + digit;
    value = zT_22;
    zT_23 = self;
    zT_24 = zF_7C2FDD01_lexerAdvance(zT_23);
    (void)zT_24;
    zT_25 = 1;
    zT_27 = count + (unsigned char)((unsigned char)zT_25);
    count = zT_27;
    goto z_bb_4;
    z_bb_10:
    zT_31 = "\\x requires at least one hex digit";
    zT_33 = 34;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_hex = zT_32;
    zT_34 = self->count_only;
    if ((int)(!zT_34)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return value;
    z_bb_12:
    zT_36 = self->diag;
    zT_44 = 0;
    zT_39 = self->file_id;
    zT_48 = self->pos;
    zT_49 = 2;
    zT_52 = self->pos;
    zT_42 = s_hex;
    (void)zF_C82559AC_diagnosticCollector(zT_36, (unsigned char)((unsigned char)zT_44), (unsigned short)(3), zT_39, (unsigned int)((unsigned int)(unsigned int)(zT_48 - zT_49)), (unsigned int)((unsigned int)zT_52), zT_42);
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
}

/* lexerParseEscapeSequence */
unsigned char zF_7D4EA30A_lexerParseEscapeSeq(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    int zT_2 = 0;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6 = 0;
    zT_138FFB41_Lexer* zT_14;
    unsigned char zT_15 = 0;
    int zT_16;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_BBAAFAE2_Arr_unsigned_char_2 zT_23;
    int zT_24;
    unsigned char zT_25;
    int zT_26;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_32;
    unsigned int zT_33;
    int zT_36;
    int zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_D3EB6303_StringInterner* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_45;
    zT_F85C5DED_DiagnosticCollector* zT_47;
    int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    int zT_61;
    unsigned int zT_65;
    int zT_66;
    unsigned int zT_69;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u ue1;
    zT_BBAAFAE2_Arr_unsigned_char_2 ue_char_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u ue3;
    zT_4C214FEE_Arr_zT_8F083A69_Sli ueparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_unesc;
    zT_1 = self;
    zT_2 = zF_07BC1EA1_lexerIsAtEnd(zT_1);
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(92);
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_7C2FDD01_lexerAdvance(zT_5);
    c = zT_6;
switch (c) {
case 110: goto z_bb_3;
case 116: goto z_bb_4;
case 114: goto z_bb_5;
case 92: goto z_bb_6;
case 34: goto z_bb_7;
case 39: goto z_bb_8;
case 48: goto z_bb_9;
case 120: goto z_bb_10;
default: goto z_bb_11;
}
    z_bb_3:
    return (unsigned char)(10);
    z_bb_4:
    return (unsigned char)(9);
    z_bb_5:
    return (unsigned char)(13);
    z_bb_6:
    return (unsigned char)(92);
    z_bb_7:
    return (unsigned char)(34);
    z_bb_8:
    return (unsigned char)(39);
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_14 = self;
    zT_15 = zF_3EAE09C6_lexerParseHexEscape(zT_14);
    return zT_15;
    z_bb_11:
    zT_16 = self->count_only;
    if ((int)(!zT_16)) goto z_bb_14; else goto z_bb_15;
    return 0;
    z_bb_14:
    zT_19 = "unrecognized escape sequence: '\\";
    zT_21 = 32;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    ue1 = zT_20;
    {
    unsigned int _i = 0;
    while (_i < 2) {
        zT_23[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 2) {
        ue_char_buf[_i] = zT_23[_i];
        _i++;
    }
}
    zT_24 = 0;
    ue_char_buf[zT_24] = c;
    zT_25 = 0;
    zT_26 = 1;
    ue_char_buf[zT_26] = zT_25;
    zT_28 = "'";
    zT_30 = 1;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    ue3 = zT_29;
    zT_33 = 0;
    zT_32[zT_33] = ue1;
    zT_36 = 1;
    zT_37 = 0;
    zT_38 = (unsigned char*)((unsigned char*)ue_char_buf) + zT_37;
    zT_39 = zT_36 - zT_37;
    zT_40.ptr = zT_38;
    zT_40.len = zT_39;
    zT_41 = 1;
    zT_32[zT_41] = zT_40;
    zT_42 = 2;
    zT_32[zT_42] = ue3;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        ueparts[_i] = zT_32[_i];
        _i++;
    }
}
    zT_47 = self->diag;
    zT_44 = zT_47->interner;
    zT_49 = 0;
    zT_50 = ueparts + zT_49;
    zT_45 = zT_50;
    zT_52 = zF_8C4BFF7C_diagnosticBuilderMa(zT_44, zT_45, (unsigned int)(3));
    s_unesc = zT_52;
    zT_53 = self->diag;
    zT_61 = 1;
    zT_56 = self->file_id;
    zT_65 = self->pos;
    zT_66 = 2;
    zT_69 = self->pos;
    zT_59 = s_unesc;
    (void)zF_C82559AC_diagnosticCollector(zT_53, (unsigned char)((unsigned char)zT_61), (unsigned short)(6), zT_56, (unsigned int)((unsigned int)(unsigned int)(zT_65 - zT_66)), (unsigned int)((unsigned int)zT_69), zT_59);
    goto z_bb_15;
    z_bb_15:
    return c;
}

/* isDigitInBase */
int zF_C5E3A034_isDigitInBase(unsigned char c, unsigned char base) {
    int zT_4;
    int zT_9;
    int zT_14;
    int zT_19;
    int zT_22;
    int zT_25;
    int zT_28;
    int zT_31;
switch (base) {
case 2: goto z_bb_1;
case 8: goto z_bb_2;
case 10: goto z_bb_3;
case 16: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_1:
    if ((int)(c >= (unsigned char)(48))) goto z_bb_8; else goto z_bb_9;
    z_bb_2:
    if ((int)(c >= (unsigned char)(48))) goto z_bb_11; else goto z_bb_12;
    z_bb_3:
    if ((int)(c >= (unsigned char)(48))) goto z_bb_14; else goto z_bb_15;
    z_bb_4:
    if ((int)(c >= (unsigned char)(48))) goto z_bb_17; else goto z_bb_18;
    z_bb_5:
    return (int)(0);
    return 0;
    z_bb_8:
    zT_4 = c <= (unsigned char)(49);
    goto z_bb_10;
    z_bb_9:
    zT_4 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_4;
    z_bb_11:
    zT_9 = c <= (unsigned char)(55);
    goto z_bb_13;
    z_bb_12:
    zT_9 = 0;
    goto z_bb_13;
    z_bb_13:
    return zT_9;
    z_bb_14:
    zT_14 = c <= (unsigned char)(57);
    goto z_bb_16;
    z_bb_15:
    zT_14 = 0;
    goto z_bb_16;
    z_bb_16:
    return zT_14;
    z_bb_17:
    zT_19 = c <= (unsigned char)(57);
    goto z_bb_19;
    z_bb_18:
    zT_19 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_19) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    if ((int)(c >= (unsigned char)(97))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    zT_22 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_22) goto z_bb_27; else goto z_bb_26;
    z_bb_23:
    zT_25 = c <= (unsigned char)(102);
    goto z_bb_25;
    z_bb_24:
    zT_25 = 0;
    goto z_bb_25;
    z_bb_25:
    zT_22 = zT_25;
    goto z_bb_22;
    z_bb_26:
    if ((int)(c >= (unsigned char)(65))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_28 = 1;
    goto z_bb_28;
    z_bb_28:
    return zT_28;
    z_bb_29:
    zT_31 = c <= (unsigned char)(70);
    goto z_bb_31;
    z_bb_30:
    zT_31 = 0;
    goto z_bb_31;
    z_bb_31:
    zT_28 = zT_31;
    goto z_bb_28;
}

/* parseU64 */
zT_79FAE712_u64 zF_8EC79679_parseU64(zT_8F083A69_Slice_zT_0B42B2F8_u text, unsigned char base) {
    int zT_3;
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    int zT_10;
    int zT_12;
    unsigned char* zT_13;
    int zT_14;
    unsigned char zT_15;
    unsigned char* zT_19;
    int zT_20;
    unsigned char zT_21;
    int zT_24;
    int zT_27;
    int zT_30;
    int zT_33;
    int zT_36;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned char* zT_45;
    unsigned char zT_46;
    int zT_47;
    unsigned int zT_49;
    int zT_53;
    zT_79FAE712_u64 zT_54;
    int zT_56;
    int zT_59;
    zT_79FAE712_u64 zT_64;
    int zT_67;
    int zT_72;
    zT_79FAE712_u64 zT_74;
    int zT_77;
    int zT_82;
    zT_79FAE712_u64 zT_84;
    int zT_85;
    zT_79FAE712_u64 zT_89;
    zT_79FAE712_u64 zT_92;
    int zT_93;
    zT_79FAE712_u64 zT_95;
    zT_79FAE712_u64 zT_97;
    zT_79FAE712_u64 zT_99;
    zT_79FAE712_u64 zT_103;
    zT_79FAE712_u64 result;
    unsigned int i;
    unsigned char p;
    unsigned char c;
    zT_79FAE712_u64 digit;
    int found_digit;
    zT_79FAE712_u64 base_u64;
    zT_79FAE712_u64 max_u64;
    zT_79FAE712_u64 max_before_mul;
    zT_79FAE712_u64 after_mul;
    zT_3 = 0;
    zT_4 = (zT_79FAE712_u64)zT_3;
    result = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    i = zT_7;
    zT_9 = text.len;
    zT_10 = 2;
    if ((int)(zT_9 > (unsigned int)zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = text.ptr;
    zT_14 = 0;
    zT_15 = zT_13[zT_14];
    zT_12 = zT_15 == (unsigned char)(48);
    goto z_bb_3;
    z_bb_2:
    zT_12 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = text.ptr;
    zT_20 = 1;
    zT_21 = zT_19[zT_20];
    p = zT_21;
    if ((int)(p == (unsigned char)(120))) goto z_bb_7; else goto z_bb_6;
    z_bb_5:
    goto z_bb_23;
    z_bb_6:
    zT_24 = p == (unsigned char)(88);
    goto z_bb_8;
    z_bb_7:
    zT_24 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_24) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_27 = p == (unsigned char)(98);
    goto z_bb_11;
    z_bb_10:
    zT_27 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_27) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_30 = p == (unsigned char)(66);
    goto z_bb_14;
    z_bb_13:
    zT_30 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_30) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_33 = p == (unsigned char)(111);
    goto z_bb_17;
    z_bb_16:
    zT_33 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_33) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_36 = p == (unsigned char)(79);
    goto z_bb_20;
    z_bb_19:
    zT_36 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_36) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_39 = 2;
    zT_40 = (unsigned int)zT_39;
    i = zT_40;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_5;
    z_bb_23:
    zT_42 = text.len;
    if ((int)(i < zT_42)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_45 = text.ptr;
    zT_46 = zT_45[i];
    c = zT_46;
    zT_47 = 1;
    zT_49 = i + (unsigned int)((unsigned int)zT_47);
    i = zT_49;
    if ((int)(c == (unsigned char)(95))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    return result;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    goto z_bb_26;
    z_bb_28:
    zT_53 = 0;
    zT_54 = (zT_79FAE712_u64)zT_53;
    digit = zT_54;
    zT_56 = 1;
    found_digit = zT_56;
    if ((int)(c >= (unsigned char)(48))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_59 = c <= (unsigned char)(57);
    goto z_bb_31;
    z_bb_30:
    zT_59 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_59) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_64 = (zT_79FAE712_u64)(unsigned char)(c - (unsigned char)(48));
    digit = zT_64;
    goto z_bb_33;
    z_bb_33:
    if ((int)(!found_digit)) goto z_bb_47; else goto z_bb_48;
    z_bb_34:
    if ((int)(c >= (unsigned char)(97))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_67 = c <= (unsigned char)(102);
    goto z_bb_37;
    z_bb_36:
    zT_67 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_67) goto z_bb_38; else goto z_bb_40;
    z_bb_38:
    zT_72 = 10;
    zT_74 = (zT_79FAE712_u64)(unsigned char)((unsigned char)(c - (unsigned char)(97)) + zT_72);
    digit = zT_74;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_33;
    z_bb_40:
    if ((int)(c >= (unsigned char)(65))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_77 = c <= (unsigned char)(70);
    goto z_bb_43;
    z_bb_42:
    zT_77 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_77) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_82 = 10;
    zT_84 = (zT_79FAE712_u64)(unsigned char)((unsigned char)(c - (unsigned char)(65)) + zT_82);
    digit = zT_84;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_39;
    z_bb_46:
    zT_85 = 0;
    found_digit = zT_85;
    goto z_bb_45;
    z_bb_47:
    goto z_bb_25;
    z_bb_48:
    zT_89 = (zT_79FAE712_u64)(unsigned int)((unsigned int)base);
    base_u64 = zT_89;
    if ((int)(digit >= base_u64)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_25;
    z_bb_50:
    zT_92 = 0;
    max_u64 = zT_92;
    zT_93 = 1;
    zT_95 = max_u64 - (zT_79FAE712_u64)((zT_79FAE712_u64)zT_93);
    max_u64 = zT_95;
    zT_97 = max_u64 / base_u64;
    max_before_mul = zT_97;
    if ((int)(result > max_before_mul)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return max_u64;
    z_bb_52:
    zT_99 = result * base_u64;
    result = zT_99;
    after_mul = result;
    if ((int)(after_mul > (zT_79FAE712_u64)(max_u64 - digit))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return max_u64;
    z_bb_54:
    zT_103 = result + digit;
    result = zT_103;
    goto z_bb_26;
}

/* parseF64 */
double zF_37CDE8A4_parseF64(zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    double zT_2;
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned int zT_9;
    int zT_11;
    unsigned char* zT_12;
    unsigned char zT_13;
    int zT_16;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_21;
    int zT_23;
    unsigned char* zT_24;
    unsigned char zT_25;
    int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned char* zT_35;
    unsigned char zT_36;
    int zT_37;
    unsigned int zT_39;
    int zT_44;
    int zT_47;
    int zT_50;
    unsigned int zT_52;
    unsigned char zT_53;
    int zT_54 = 0;
    int zT_56;
    unsigned int zT_58;
    int zT_62;
    double zT_66;
    unsigned int zT_68;
    int zT_70;
    unsigned char* zT_71;
    unsigned char zT_72;
    int zT_75;
    unsigned int zT_77;
    double zT_79;
    unsigned int zT_81;
    unsigned char* zT_84;
    unsigned char zT_85;
    int zT_86;
    unsigned int zT_88;
    int zT_93;
    unsigned char zT_96;
    int zT_97 = 0;
    int zT_102;
    double zT_105;
    double zT_107;
    unsigned int zT_109;
    int zT_111;
    unsigned char* zT_112;
    unsigned char zT_113;
    int zT_116;
    unsigned char* zT_117;
    unsigned char zT_118;
    int zT_121;
    unsigned int zT_123;
    int zT_125;
    unsigned int zT_127;
    int zT_129;
    unsigned char* zT_130;
    unsigned char zT_131;
    int zT_134;
    int zT_135;
    unsigned int zT_137;
    unsigned int zT_139;
    int zT_141;
    unsigned char* zT_142;
    unsigned char zT_143;
    int zT_146;
    unsigned int zT_148;
    int zT_150;
    int zT_151;
    unsigned int zT_153;
    int zT_155;
    unsigned char zT_156;
    unsigned char* zT_157;
    int zT_159 = 0;
    int zT_160;
    unsigned char* zT_162;
    unsigned char zT_163;
    int zT_167;
    int zT_168;
    unsigned int zT_170;
    double zT_172;
    double zT_177;
    unsigned int zT_179;
    double zT_180;
    double zT_181;
    double zT_182;
    double result;
    unsigned int i;
    int negative;
    unsigned char c;
    int dg;
    double frac_mul;
    int dg2;
    int exp_neg;
    int exp;
    double power;
    unsigned int _;
    zT_2 = 0;
    result = zT_2;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    zT_7 = 0;
    negative = zT_7;
    zT_9 = text.len;
    if ((int)(i < zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = text.ptr;
    zT_13 = zT_12[i];
    zT_11 = zT_13 == (unsigned char)(45);
    goto z_bb_3;
    z_bb_2:
    zT_11 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = 1;
    negative = zT_16;
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_5;
    z_bb_5:
    zT_21 = text.len;
    if ((int)(i < zT_21)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_24 = text.ptr;
    zT_25 = zT_24[i];
    zT_23 = zT_25 == (unsigned char)(43);
    goto z_bb_8;
    z_bb_7:
    zT_23 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_23) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_28 = 1;
    zT_30 = i + (unsigned int)((unsigned int)zT_28);
    i = zT_30;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_11;
    z_bb_11:
    zT_32 = text.len;
    if ((int)(i < zT_32)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_35 = text.ptr;
    zT_36 = zT_35[i];
    c = zT_36;
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    if ((int)(c == (unsigned char)(95))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_68 = text.len;
    if ((int)(i < zT_68)) goto z_bb_27; else goto z_bb_28;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    if ((int)(c == (unsigned char)(46))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_44 = c == (unsigned char)(101);
    goto z_bb_19;
    z_bb_18:
    zT_44 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_44) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_47 = c == (unsigned char)(69);
    goto z_bb_22;
    z_bb_21:
    zT_47 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_47) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_50 = 1;
    zT_52 = i - (unsigned int)((unsigned int)zT_50);
    i = zT_52;
    goto z_bb_13;
    z_bb_24:
    zT_53 = c;
    zT_54 = zF_C95A8EC6_isDigit(zT_53);
    if ((int)(!zT_54)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_56 = 1;
    zT_58 = i - (unsigned int)((unsigned int)zT_56);
    i = zT_58;
    goto z_bb_13;
    z_bb_26:
    zT_62 = (int)(unsigned char)(c - (unsigned char)(48));
    dg = zT_62;
    zT_66 = (double)(result * (double)(1e+1)) + (double)((double)dg);
    result = zT_66;
    goto z_bb_14;
    z_bb_27:
    zT_71 = text.ptr;
    zT_72 = zT_71[i];
    zT_70 = zT_72 == (unsigned char)(46);
    goto z_bb_29;
    z_bb_28:
    zT_70 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_70) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_75 = 1;
    zT_77 = i + (unsigned int)((unsigned int)zT_75);
    i = zT_77;
    zT_79 = 1.0000000000000001e-1;
    frac_mul = zT_79;
    goto z_bb_32;
    z_bb_31:
    zT_109 = text.len;
    if ((int)(i < zT_109)) goto z_bb_45; else goto z_bb_46;
    z_bb_32:
    zT_81 = text.len;
    if ((int)(i < zT_81)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_84 = text.ptr;
    zT_85 = zT_84[i];
    c = zT_85;
    zT_86 = 1;
    zT_88 = i + (unsigned int)((unsigned int)zT_86);
    i = zT_88;
    if ((int)(c == (unsigned char)(95))) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    goto z_bb_35;
    z_bb_37:
    if ((int)(c == (unsigned char)(101))) goto z_bb_39; else goto z_bb_38;
    z_bb_38:
    zT_93 = c == (unsigned char)(69);
    goto z_bb_40;
    z_bb_39:
    zT_93 = 1;
    goto z_bb_40;
    z_bb_40:
    if (zT_93) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_34;
    z_bb_42:
    zT_96 = c;
    zT_97 = zF_C95A8EC6_isDigit(zT_96);
    if ((int)(!zT_97)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    goto z_bb_34;
    z_bb_44:
    zT_102 = (int)(unsigned char)(c - (unsigned char)(48));
    dg2 = zT_102;
    zT_105 = result + (double)((double)((double)dg2) * frac_mul);
    result = zT_105;
    zT_107 = frac_mul * (double)(1.0000000000000001e-1);
    frac_mul = zT_107;
    goto z_bb_35;
    z_bb_45:
    zT_112 = text.ptr;
    zT_113 = zT_112[i];
    if ((int)(zT_113 == (unsigned char)(101))) goto z_bb_49; else goto z_bb_48;
    z_bb_46:
    zT_111 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_111) goto z_bb_51; else goto z_bb_52;
    z_bb_48:
    zT_117 = text.ptr;
    zT_118 = zT_117[i];
    zT_116 = zT_118 == (unsigned char)(69);
    goto z_bb_50;
    z_bb_49:
    zT_116 = 1;
    goto z_bb_50;
    z_bb_50:
    zT_111 = zT_116;
    goto z_bb_47;
    z_bb_51:
    zT_121 = 1;
    zT_123 = i + (unsigned int)((unsigned int)zT_121);
    i = zT_123;
    zT_125 = 0;
    exp_neg = zT_125;
    zT_127 = text.len;
    if ((int)(i < zT_127)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    if (negative) goto z_bb_76; else goto z_bb_77;
    z_bb_53:
    zT_130 = text.ptr;
    zT_131 = zT_130[i];
    zT_129 = zT_131 == (unsigned char)(45);
    goto z_bb_55;
    z_bb_54:
    zT_129 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_129) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_134 = 1;
    exp_neg = zT_134;
    zT_135 = 1;
    zT_137 = i + (unsigned int)((unsigned int)zT_135);
    i = zT_137;
    goto z_bb_57;
    z_bb_57:
    zT_139 = text.len;
    if ((int)(i < zT_139)) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_142 = text.ptr;
    zT_143 = zT_142[i];
    zT_141 = zT_143 == (unsigned char)(43);
    goto z_bb_60;
    z_bb_59:
    zT_141 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_141) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_146 = 1;
    zT_148 = i + (unsigned int)((unsigned int)zT_146);
    i = zT_148;
    goto z_bb_62;
    z_bb_62:
    zT_150 = 0;
    zT_151 = (int)zT_150;
    exp = zT_151;
    goto z_bb_63;
    z_bb_63:
    zT_153 = text.len;
    if ((int)(i < zT_153)) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_160 = 10;
    zT_162 = text.ptr;
    zT_163 = zT_162[i];
    zT_167 = (int)(exp * zT_160) + (int)((int)(unsigned char)(zT_163 - (unsigned char)(48)));
    exp = zT_167;
    zT_168 = 1;
    zT_170 = i + (unsigned int)((unsigned int)zT_168);
    i = zT_170;
    goto z_bb_66;
    z_bb_65:
    zT_172 = 1e+0;
    power = zT_172;
    _ = 0;
    goto z_bb_70;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_157 = text.ptr;
    zT_156 = zT_157[i];
    zT_159 = zF_C95A8EC6_isDigit(zT_156);
    zT_155 = zT_159;
    goto z_bb_69;
    z_bb_68:
    zT_155 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_155) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    if ((int)((unsigned int)_ < (unsigned int)((unsigned int)exp))) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_177 = power * (double)(1e+1);
    power = zT_177;
    zT_179 = _ + (unsigned int)(1);
    _ = zT_179;
    goto z_bb_70;
    z_bb_72:
    if (exp_neg) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_180 = result / power;
    result = zT_180;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_52;
    z_bb_75:
    zT_181 = result * power;
    result = zT_181;
    goto z_bb_74;
    z_bb_76:
    zT_182 = -result;
    result = zT_182;
    goto z_bb_77;
    z_bb_77:
    return result;
}

/* isU64MaxLiteral */
int zF_6E4D822B_isU64MaxLiteral(zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_2;
    int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_9;
    zT_79FAE712_u64 zT_11 = 0;
    zT_79FAE712_u64 zT_12;
    zT_79FAE712_u64 val;
    zT_2 = text.len;
    zT_3 = 2;
    if ((int)(zT_2 < (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = text;
    zT_9 = 16;
    zT_11 = zF_8EC79679_parseU64(zT_7, (unsigned char)((unsigned char)zT_9));
    val = zT_11;
    zT_12 = 18446744073709551615ULL;
    return (int)(val == (zT_79FAE712_u64)zT_12);
}

/* assertEqBool */
void zF_F0A50871_assertEqBool(int actual, int expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_exp;
    zT_8F083A69_Slice_zT_0B42B2F8_u str_true;
    zT_8F083A69_Slice_zT_0B42B2F8_u str_false;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_got;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((int)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected ";
    zT_27 = 11;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    s_exp = zT_26;
    zT_28 = s_exp;
    zF_E4B2EF19_stderr_write(zT_28);
    zT_30 = "true";
    zT_32 = 4;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    str_true = zT_31;
    zT_34 = "false";
    zT_36 = 5;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    str_false = zT_35;
    if (expected) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_37 = str_true;
    zF_E4B2EF19_stderr_write(zT_37);
    goto z_bb_4;
    z_bb_4:
    zT_40 = ", got ";
    zT_42 = 6;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    s_got = zT_41;
    zT_43 = s_got;
    zF_E4B2EF19_stderr_write(zT_43);
    if (actual) goto z_bb_6; else goto z_bb_8;
    z_bb_5:
    zT_38 = str_false;
    zF_E4B2EF19_stderr_write(zT_38);
    goto z_bb_4;
    z_bb_6:
    zT_44 = str_true;
    zF_E4B2EF19_stderr_write(zT_44);
    goto z_bb_7;
    z_bb_7:
    zT_47 = "\n";
    zT_49 = 1;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    s_nl = zT_48;
    zT_50 = s_nl;
    zF_E4B2EF19_stderr_write(zT_50);
    goto z_bb_2;
    z_bb_8:
    zT_45 = str_false;
    zF_E4B2EF19_stderr_write(zT_45);
    goto z_bb_7;
}

/* assertEqU32 */
void zF_EFB8936D_assertEqU32(unsigned int actual, unsigned int expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41 = {0};
    unsigned char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    int zT_53;
    unsigned char* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59 = {0};
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_exp;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_got;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((int)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected ";
    zT_27 = 11;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    s_exp = zT_26;
    zT_28 = s_exp;
    zF_E4B2EF19_stderr_write(zT_28);
    zT_30 = expected;
    zT_35 = 0;
    zT_36 = (unsigned char*)((unsigned char*)fmt_buf) + zT_35;
    zT_37 = (unsigned int)(12) - zT_35;
    zT_38.ptr = zT_36;
    zT_38.len = zT_37;
    zT_31 = zT_38;
    zT_39 = 12;
    zT_41 = zF_2FED9490_formatU32_1(zT_30, zT_31, (unsigned int)((unsigned int)zT_39));
    zT_29 = zT_41;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_43 = ", got ";
    zT_45 = 6;
    zT_44.ptr = zT_43;
    zT_44.len = zT_45;
    s_got = zT_44;
    zT_46 = s_got;
    zF_E4B2EF19_stderr_write(zT_46);
    zT_48 = actual;
    zT_53 = 0;
    zT_54 = (unsigned char*)((unsigned char*)fmt_buf) + zT_53;
    zT_55 = (unsigned int)(12) - zT_53;
    zT_56.ptr = zT_54;
    zT_56.len = zT_55;
    zT_49 = zT_56;
    zT_57 = 12;
    zT_59 = zF_2FED9490_formatU32_1(zT_48, zT_49, (unsigned int)((unsigned int)zT_57));
    zT_47 = zT_59;
    zF_E4B2EF19_stderr_write(zT_47);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    s_nl = zT_62;
    zT_64 = s_nl;
    zF_E4B2EF19_stderr_write(zT_64);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* assertEqU8 */
void zF_8856257C_assertEqU8(unsigned char actual, unsigned char expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_msg;
    if ((int)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected char\n";
    zT_27 = 16;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    s_msg = zT_26;
    zT_28 = s_msg;
    zF_E4B2EF19_stderr_write(zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* assertEqTokenKind */
void zF_1058D9A8_assertEqTokenKind(zT_EAC3E484_TokenKind actual, zT_EAC3E484_TokenKind expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    if ((int)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    msg1 = zT_8;
    zT_10 = msg1;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": token kind mismatch\n";
    zT_27 = 22;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    msg2 = zT_26;
    zT_28 = msg2;
    zF_E4B2EF19_stderr_write(zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* formatU32 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_1(unsigned int val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_26;
    unsigned char* zT_27;
    int zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned char* zT_36;
    int zT_38;
    unsigned char* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int idx;
    unsigned int v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((int)(v == (unsigned int)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_34 = 1;
    zT_35 = idx + zT_34;
    start = zT_35;
    zT_36 = buf.ptr;
    zT_38 = 1;
    zT_40 = zT_36 + start;
    zT_41 = (unsigned int)(buf_len - zT_38) - start;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    return zT_42;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((int)(v > (unsigned int)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_26 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(v % zT_23));
    zT_27 = buf.ptr;
    zT_27[idx] = zT_26;
    zT_28 = 10;
    zT_29 = v / zT_28;
    v = zT_29;
    zT_30 = 1;
    zT_32 = idx - (unsigned int)((unsigned int)zT_30);
    idx = zT_32;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* lexerRunAllTests */
void zF_C3A6E90A_lexerRunAllTests(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_1 = "Running lexer tests...\n";
    zT_3 = 23;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    msg1 = zT_2;
    zT_4 = msg1;
    zF_E4B2EF19_stderr_write(zT_4);
    zF_6492230E_lexerTestHelpers();
    zF_BF88F19A_lexerTestSkipWhites();
    zF_9AA3D1F6_lexerTestOperators();
    zF_4CB82885_lexerTestScanNumber();
    zF_A76AF035_lexerTestScanString();
    zF_13791BA0_lexerTestScanChar();
    zF_B8F07D3E_lexerTestIdentifier();
    zF_1C8729CF_lexerTestBuiltinIde();
    zF_6836167B_lexerTestDiagnostic();
    zF_4B029FD3_runLexerUnitTests();
    zT_6 = "All lexer tests passed.\n";
    zT_8 = 24;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    msg2 = zT_7;
    zT_9 = msg2;
    zF_E4B2EF19_stderr_write(zT_9);
    return;
}

/* lexerTestSanityCheck */
void zF_519E4401_lexerTestSanityChec(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    char* zT_5;
    unsigned int zT_6;
    char* zT_7;
    unsigned int zT_8;
    char* zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_1 = "Running lexer sanity check (should fail)...\n";
    zT_3 = 44;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_5 = "panic: ";
    zT_6 = 7;
    fwrite(zT_5, 1, zT_6, stderr);
    zT_7 = "intentional sanity check failure";
    zT_8 = 32;
    fwrite(zT_7, 1, zT_8, stderr);
    zT_9 = "\n";
    zT_10 = 1;
    fwrite(zT_9, 1, zT_10, stderr);
    pal_trap();
}

/* lexerTestHelpers */
void zF_6492230E_lexerTestHelpers(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    int zT_46;
    zT_138FFB41_Lexer* zT_49;
    int zT_51 = 0;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_62;
    int zT_66;
    unsigned int zT_69;
    int zT_73;
    unsigned char zT_76;
    zT_138FFB41_Lexer* zT_79;
    unsigned char zT_81 = 0;
    unsigned char zT_84;
    zT_138FFB41_Lexer* zT_87;
    unsigned char zT_89 = 0;
    unsigned char zT_92;
    zT_138FFB41_Lexer* zT_95;
    int zT_98;
    unsigned char zT_100 = 0;
    int zT_103;
    zT_138FFB41_Lexer* zT_106;
    int zT_108 = 0;
    unsigned char zT_111;
    zT_138FFB41_Lexer* zT_114;
    unsigned char zT_116 = 0;
    unsigned char zT_119;
    zT_138FFB41_Lexer* zT_122;
    unsigned char zT_124 = 0;
    int zT_127;
    zT_138FFB41_Lexer* zT_130;
    int zT_132 = 0;
    unsigned char zT_135;
    zT_138FFB41_Lexer* zT_138;
    unsigned char zT_140 = 0;
    int zT_141;
    unsigned char zT_144;
    zT_138FFB41_Lexer* zT_147;
    unsigned char zT_149 = 0;
    int zT_150;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    zT_D3EB6303_StringInterner* zT_160;
    zT_F85C5DED_DiagnosticCollector* zT_161;
    zT_3E40CD83_Sand* zT_162;
    int zT_163;
    zT_138FFB41_Lexer zT_168 = {0};
    int zT_169;
    zT_138FFB41_Lexer* zT_172;
    int zT_176 = 0;
    int zT_179;
    zT_138FFB41_Lexer* zT_182;
    int zT_186 = 0;
    int zT_189;
    zT_138FFB41_Lexer* zT_192;
    int zT_196 = 0;
    unsigned char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    zT_D3EB6303_StringInterner* zT_206;
    zT_F85C5DED_DiagnosticCollector* zT_207;
    zT_3E40CD83_Sand* zT_208;
    int zT_209;
    zT_138FFB41_Lexer zT_214 = {0};
    zT_138FFB41_Lexer* zT_215;
    unsigned char zT_217 = 0;
    unsigned int zT_218;
    int zT_222;
    unsigned int zT_225;
    int zT_229;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u test_src;
    zT_138FFB41_Lexer lexer;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ab;
    zT_138FFB41_Lexer lexer2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    zT_138FFB41_Lexer lexer3;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "abc";
    zT_33 = 3;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    test_src = zT_32;
    zT_35 = test_src;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    lexer = zT_45;
    zT_49 = &lexer;
    zT_51 = zF_07BC1EA1_lexerIsAtEnd(zT_49);
    zT_46 = zT_51;
    zF_F0A50871_assertEqBool(zT_46, (int)(0), (unsigned int)(0));
    zT_57 = lexer.pos;
    zT_59 = 0;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_57), (unsigned int)((unsigned int)zT_59), (unsigned int)(0));
    zT_62 = lexer.line;
    zT_66 = 1;
    zF_EFB8936D_assertEqU32(zT_62, (unsigned int)((unsigned int)zT_66), (unsigned int)(0));
    zT_69 = lexer.col;
    zT_73 = 1;
    zF_EFB8936D_assertEqU32(zT_69, (unsigned int)((unsigned int)zT_73), (unsigned int)(0));
    zT_79 = &lexer;
    zT_81 = zF_7C2FDD01_lexerAdvance(zT_79);
    zT_76 = zT_81;
    zF_8856257C_assertEqU8(zT_76, (unsigned char)(97), (unsigned int)(0));
    zT_87 = &lexer;
    zT_89 = zF_6ACB12FA_lexerPeek(zT_87);
    zT_84 = zT_89;
    zF_8856257C_assertEqU8(zT_84, (unsigned char)(98), (unsigned int)(0));
    zT_95 = &lexer;
    zT_98 = 1;
    zT_100 = zF_D1AE715C_lexerPeekN(zT_95, (unsigned int)((unsigned int)zT_98));
    zT_92 = zT_100;
    zF_8856257C_assertEqU8(zT_92, (unsigned char)(99), (unsigned int)(0));
    zT_106 = &lexer;
    zT_108 = zF_07BC1EA1_lexerIsAtEnd(zT_106);
    zT_103 = zT_108;
    zF_F0A50871_assertEqBool(zT_103, (int)(0), (unsigned int)(0));
    zT_114 = &lexer;
    zT_116 = zF_7C2FDD01_lexerAdvance(zT_114);
    zT_111 = zT_116;
    zF_8856257C_assertEqU8(zT_111, (unsigned char)(98), (unsigned int)(0));
    zT_122 = &lexer;
    zT_124 = zF_7C2FDD01_lexerAdvance(zT_122);
    zT_119 = zT_124;
    zF_8856257C_assertEqU8(zT_119, (unsigned char)(99), (unsigned int)(0));
    zT_130 = &lexer;
    zT_132 = zF_07BC1EA1_lexerIsAtEnd(zT_130);
    zT_127 = zT_132;
    zF_F0A50871_assertEqBool(zT_127, (int)(1), (unsigned int)(0));
    zT_138 = &lexer;
    zT_140 = zF_7C2FDD01_lexerAdvance(zT_138);
    zT_135 = zT_140;
    zT_141 = 0;
    zF_8856257C_assertEqU8(zT_135, (unsigned char)((unsigned char)zT_141), (unsigned int)(0));
    zT_147 = &lexer;
    zT_149 = zF_6ACB12FA_lexerPeek(zT_147);
    zT_144 = zT_149;
    zT_150 = 0;
    zF_8856257C_assertEqU8(zT_144, (unsigned char)((unsigned char)zT_150), (unsigned int)(0));
    zT_154 = "ab";
    zT_156 = 2;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    s_ab = zT_155;
    zT_158 = s_ab;
    zT_163 = 0;
    zT_160 = &interner;
    zT_161 = &diag;
    zT_162 = &sand;
    zT_168 = zF_151E643F_lexerInit(zT_158, (unsigned int)((unsigned int)zT_163), zT_160, zT_161, zT_162);
    lexer2 = zT_168;
    zT_172 = &lexer2;
    zT_176 = zF_8A07967A_lexerMatch(zT_172, (unsigned char)(97));
    zT_169 = zT_176;
    zF_F0A50871_assertEqBool(zT_169, (int)(1), (unsigned int)(0));
    zT_182 = &lexer2;
    zT_186 = zF_8A07967A_lexerMatch(zT_182, (unsigned char)(120));
    zT_179 = zT_186;
    zF_F0A50871_assertEqBool(zT_179, (int)(0), (unsigned int)(0));
    zT_192 = &lexer2;
    zT_196 = zF_8A07967A_lexerMatch(zT_192, (unsigned char)(98));
    zT_189 = zT_196;
    zF_F0A50871_assertEqBool(zT_189, (int)(1), (unsigned int)(0));
    zT_200 = "\n";
    zT_202 = 1;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    s_nl = zT_201;
    zT_204 = s_nl;
    zT_209 = 0;
    zT_206 = &interner;
    zT_207 = &diag;
    zT_208 = &sand;
    zT_214 = zF_151E643F_lexerInit(zT_204, (unsigned int)((unsigned int)zT_209), zT_206, zT_207, zT_208);
    lexer3 = zT_214;
    zT_215 = &lexer3;
    zT_217 = zF_7C2FDD01_lexerAdvance(zT_215);
    (void)zT_217;
    zT_218 = lexer3.line;
    zT_222 = 2;
    zF_EFB8936D_assertEqU32(zT_218, (unsigned int)((unsigned int)zT_222), (unsigned int)(0));
    zT_225 = lexer3.col;
    zT_229 = 1;
    zF_EFB8936D_assertEqU32(zT_225, (unsigned int)((unsigned int)zT_229), (unsigned int)(0));
    return;
}

/* lexerTestSkipWhitespaceAndComments */
void zF_BF88F19A_lexerTestSkipWhites(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_46;
    unsigned char zT_48;
    zT_138FFB41_Lexer* zT_51;
    unsigned char zT_53 = 0;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_spaces;
    zT_138FFB41_Lexer lexer;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "  \t  abc";
    zT_33 = 8;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_spaces = zT_32;
    zT_35 = s_spaces;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    lexer = zT_45;
    zT_46 = &lexer;
    zF_F7949B41_lexerSkipWSC(zT_46);
    zT_51 = &lexer;
    zT_53 = zF_6ACB12FA_lexerPeek(zT_51);
    zT_48 = zT_53;
    zF_8856257C_assertEqU8(zT_48, (unsigned char)(97), (unsigned int)(0));
    return;
}

/* lexerTestOperators */
void zF_9AA3D1F6_lexerTestOperators(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    zT_138FFB41_Lexer* zT_49;
    zT_3A355BD2_Token zT_51 = {0};
    zT_EAC3E484_TokenKind zT_57;
    zT_138FFB41_Lexer* zT_60;
    zT_3A355BD2_Token zT_62 = {0};
    zT_EAC3E484_TokenKind zT_68;
    zT_138FFB41_Lexer* zT_71;
    zT_3A355BD2_Token zT_73 = {0};
    zT_EAC3E484_TokenKind zT_79;
    zT_138FFB41_Lexer* zT_82;
    zT_3A355BD2_Token zT_84 = {0};
    zT_EAC3E484_TokenKind zT_90;
    zT_138FFB41_Lexer* zT_93;
    zT_3A355BD2_Token zT_95 = {0};
    zT_EAC3E484_TokenKind zT_101;
    zT_138FFB41_Lexer* zT_104;
    zT_3A355BD2_Token zT_106 = {0};
    zT_EAC3E484_TokenKind zT_112;
    zT_138FFB41_Lexer* zT_115;
    zT_3A355BD2_Token zT_117 = {0};
    unsigned char* zT_124;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_128;
    zT_D3EB6303_StringInterner* zT_130;
    zT_F85C5DED_DiagnosticCollector* zT_131;
    zT_3E40CD83_Sand* zT_132;
    int zT_133;
    zT_138FFB41_Lexer zT_138 = {0};
    zT_EAC3E484_TokenKind zT_139;
    zT_138FFB41_Lexer* zT_142;
    zT_3A355BD2_Token zT_144 = {0};
    zT_EAC3E484_TokenKind zT_150;
    zT_138FFB41_Lexer* zT_153;
    zT_3A355BD2_Token zT_155 = {0};
    zT_EAC3E484_TokenKind zT_161;
    zT_138FFB41_Lexer* zT_164;
    zT_3A355BD2_Token zT_166 = {0};
    zT_EAC3E484_TokenKind zT_172;
    zT_138FFB41_Lexer* zT_175;
    zT_3A355BD2_Token zT_177 = {0};
    zT_EAC3E484_TokenKind zT_183;
    zT_138FFB41_Lexer* zT_186;
    zT_3A355BD2_Token zT_188 = {0};
    zT_EAC3E484_TokenKind zT_194;
    zT_138FFB41_Lexer* zT_197;
    zT_3A355BD2_Token zT_199 = {0};
    zT_EAC3E484_TokenKind zT_205;
    zT_138FFB41_Lexer* zT_208;
    zT_3A355BD2_Token zT_210 = {0};
    zT_EAC3E484_TokenKind zT_216;
    zT_138FFB41_Lexer* zT_219;
    zT_3A355BD2_Token zT_221 = {0};
    zT_EAC3E484_TokenKind zT_227;
    zT_138FFB41_Lexer* zT_230;
    zT_3A355BD2_Token zT_232 = {0};
    zT_EAC3E484_TokenKind zT_238;
    zT_138FFB41_Lexer* zT_241;
    zT_3A355BD2_Token zT_243 = {0};
    zT_EAC3E484_TokenKind zT_249;
    zT_138FFB41_Lexer* zT_252;
    zT_3A355BD2_Token zT_254 = {0};
    zT_EAC3E484_TokenKind zT_260;
    zT_138FFB41_Lexer* zT_263;
    zT_3A355BD2_Token zT_265 = {0};
    zT_EAC3E484_TokenKind zT_271;
    zT_138FFB41_Lexer* zT_274;
    zT_3A355BD2_Token zT_276 = {0};
    zT_EAC3E484_TokenKind zT_282;
    zT_138FFB41_Lexer* zT_285;
    zT_3A355BD2_Token zT_287 = {0};
    unsigned char* zT_294;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_295;
    unsigned int zT_296;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_298;
    zT_D3EB6303_StringInterner* zT_300;
    zT_F85C5DED_DiagnosticCollector* zT_301;
    zT_3E40CD83_Sand* zT_302;
    int zT_303;
    zT_138FFB41_Lexer zT_308 = {0};
    zT_EAC3E484_TokenKind zT_309;
    zT_138FFB41_Lexer* zT_312;
    zT_3A355BD2_Token zT_314 = {0};
    zT_EAC3E484_TokenKind zT_320;
    zT_138FFB41_Lexer* zT_323;
    zT_3A355BD2_Token zT_325 = {0};
    zT_EAC3E484_TokenKind zT_331;
    zT_138FFB41_Lexer* zT_334;
    zT_3A355BD2_Token zT_336 = {0};
    zT_EAC3E484_TokenKind zT_342;
    zT_138FFB41_Lexer* zT_345;
    zT_3A355BD2_Token zT_347 = {0};
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_parens;
    zT_138FFB41_Lexer l1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ops;
    zT_138FFB41_Lexer l2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_compound;
    zT_138FFB41_Lexer l3;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "()[]{}";
    zT_33 = 6;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_parens = zT_32;
    zT_35 = s_parens;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_49 = &l1;
    zT_51 = zF_B976BEC9_lexerNextToken(zT_49);
    zT_46 = zT_51.kind;
    zF_1058D9A8_assertEqTokenKind(zT_46, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen), (unsigned int)(0));
    zT_60 = &l1;
    zT_62 = zF_B976BEC9_lexerNextToken(zT_60);
    zT_57 = zT_62.kind;
    zF_1058D9A8_assertEqTokenKind(zT_57, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen), (unsigned int)(0));
    zT_71 = &l1;
    zT_73 = zF_B976BEC9_lexerNextToken(zT_71);
    zT_68 = zT_73.kind;
    zF_1058D9A8_assertEqTokenKind(zT_68, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket), (unsigned int)(0));
    zT_82 = &l1;
    zT_84 = zF_B976BEC9_lexerNextToken(zT_82);
    zT_79 = zT_84.kind;
    zF_1058D9A8_assertEqTokenKind(zT_79, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket), (unsigned int)(0));
    zT_93 = &l1;
    zT_95 = zF_B976BEC9_lexerNextToken(zT_93);
    zT_90 = zT_95.kind;
    zF_1058D9A8_assertEqTokenKind(zT_90, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace), (unsigned int)(0));
    zT_104 = &l1;
    zT_106 = zF_B976BEC9_lexerNextToken(zT_104);
    zT_101 = zT_106.kind;
    zF_1058D9A8_assertEqTokenKind(zT_101, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace), (unsigned int)(0));
    zT_115 = &l1;
    zT_117 = zF_B976BEC9_lexerNextToken(zT_115);
    zT_112 = zT_117.kind;
    zF_1058D9A8_assertEqTokenKind(zT_112, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof), (unsigned int)(0));
    zT_124 = "+-*/%&|^~!?;:,";
    zT_126 = 14;
    zT_125.ptr = zT_124;
    zT_125.len = zT_126;
    s_ops = zT_125;
    zT_128 = s_ops;
    zT_133 = 0;
    zT_130 = &interner;
    zT_131 = &diag;
    zT_132 = &sand;
    zT_138 = zF_151E643F_lexerInit(zT_128, (unsigned int)((unsigned int)zT_133), zT_130, zT_131, zT_132);
    l2 = zT_138;
    zT_142 = &l2;
    zT_144 = zF_B976BEC9_lexerNextToken(zT_142);
    zT_139 = zT_144.kind;
    zF_1058D9A8_assertEqTokenKind(zT_139, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus), (unsigned int)(0));
    zT_153 = &l2;
    zT_155 = zF_B976BEC9_lexerNextToken(zT_153);
    zT_150 = zT_155.kind;
    zF_1058D9A8_assertEqTokenKind(zT_150, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus), (unsigned int)(0));
    zT_164 = &l2;
    zT_166 = zF_B976BEC9_lexerNextToken(zT_164);
    zT_161 = zT_166.kind;
    zF_1058D9A8_assertEqTokenKind(zT_161, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star), (unsigned int)(0));
    zT_175 = &l2;
    zT_177 = zF_B976BEC9_lexerNextToken(zT_175);
    zT_172 = zT_177.kind;
    zF_1058D9A8_assertEqTokenKind(zT_172, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash), (unsigned int)(0));
    zT_186 = &l2;
    zT_188 = zF_B976BEC9_lexerNextToken(zT_186);
    zT_183 = zT_188.kind;
    zF_1058D9A8_assertEqTokenKind(zT_183, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent), (unsigned int)(0));
    zT_197 = &l2;
    zT_199 = zF_B976BEC9_lexerNextToken(zT_197);
    zT_194 = zT_199.kind;
    zF_1058D9A8_assertEqTokenKind(zT_194, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand), (unsigned int)(0));
    zT_208 = &l2;
    zT_210 = zF_B976BEC9_lexerNextToken(zT_208);
    zT_205 = zT_210.kind;
    zF_1058D9A8_assertEqTokenKind(zT_205, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe), (unsigned int)(0));
    zT_219 = &l2;
    zT_221 = zF_B976BEC9_lexerNextToken(zT_219);
    zT_216 = zT_221.kind;
    zF_1058D9A8_assertEqTokenKind(zT_216, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret), (unsigned int)(0));
    zT_230 = &l2;
    zT_232 = zF_B976BEC9_lexerNextToken(zT_230);
    zT_227 = zT_232.kind;
    zF_1058D9A8_assertEqTokenKind(zT_227, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde), (unsigned int)(0));
    zT_241 = &l2;
    zT_243 = zF_B976BEC9_lexerNextToken(zT_241);
    zT_238 = zT_243.kind;
    zF_1058D9A8_assertEqTokenKind(zT_238, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang), (unsigned int)(0));
    zT_252 = &l2;
    zT_254 = zF_B976BEC9_lexerNextToken(zT_252);
    zT_249 = zT_254.kind;
    zF_1058D9A8_assertEqTokenKind(zT_249, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark), (unsigned int)(0));
    zT_263 = &l2;
    zT_265 = zF_B976BEC9_lexerNextToken(zT_263);
    zT_260 = zT_265.kind;
    zF_1058D9A8_assertEqTokenKind(zT_260, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon), (unsigned int)(0));
    zT_274 = &l2;
    zT_276 = zF_B976BEC9_lexerNextToken(zT_274);
    zT_271 = zT_276.kind;
    zF_1058D9A8_assertEqTokenKind(zT_271, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon), (unsigned int)(0));
    zT_285 = &l2;
    zT_287 = zF_B976BEC9_lexerNextToken(zT_285);
    zT_282 = zT_287.kind;
    zF_1058D9A8_assertEqTokenKind(zT_282, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma), (unsigned int)(0));
    zT_294 = ".. ... .{ .* == => != <= >= << >> += -= *= /= %= &= |= ^= <<= >>=";
    zT_296 = 65;
    zT_295.ptr = zT_294;
    zT_295.len = zT_296;
    s_compound = zT_295;
    zT_298 = s_compound;
    zT_303 = 0;
    zT_300 = &interner;
    zT_301 = &diag;
    zT_302 = &sand;
    zT_308 = zF_151E643F_lexerInit(zT_298, (unsigned int)((unsigned int)zT_303), zT_300, zT_301, zT_302);
    l3 = zT_308;
    zT_312 = &l3;
    zT_314 = zF_B976BEC9_lexerNextToken(zT_312);
    zT_309 = zT_314.kind;
    zF_1058D9A8_assertEqTokenKind(zT_309, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot), (unsigned int)(0));
    zT_323 = &l3;
    zT_325 = zF_B976BEC9_lexerNextToken(zT_323);
    zT_320 = zT_325.kind;
    zF_1058D9A8_assertEqTokenKind(zT_320, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot), (unsigned int)(0));
    zT_334 = &l3;
    zT_336 = zF_B976BEC9_lexerNextToken(zT_334);
    zT_331 = zT_336.kind;
    zF_1058D9A8_assertEqTokenKind(zT_331, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace), (unsigned int)(0));
    zT_345 = &l3;
    zT_347 = zF_B976BEC9_lexerNextToken(zT_345);
    zT_342 = zT_347.kind;
    zF_1058D9A8_assertEqTokenKind(zT_342, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star), (unsigned int)(0));
    return;
}

/* lexerTestScanNumber */
void zF_4CB82885_lexerTestScanNumber(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned int zT_61;
    int zT_63;
    unsigned short zT_69;
    int zT_71;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zT_D3EB6303_StringInterner* zT_81;
    zT_F85C5DED_DiagnosticCollector* zT_82;
    zT_3E40CD83_Sand* zT_83;
    int zT_84;
    zT_138FFB41_Lexer zT_89 = {0};
    zT_138FFB41_Lexer* zT_91;
    zT_3A355BD2_Token zT_93 = {0};
    zT_EAC3E484_TokenKind zT_94;
    unsigned char* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    unsigned int zT_105;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    zT_D3EB6303_StringInterner* zT_109;
    zT_F85C5DED_DiagnosticCollector* zT_110;
    zT_3E40CD83_Sand* zT_111;
    int zT_112;
    zT_138FFB41_Lexer zT_117 = {0};
    zT_138FFB41_Lexer* zT_119;
    zT_3A355BD2_Token zT_121 = {0};
    zT_EAC3E484_TokenKind zT_122;
    unsigned char* zT_131;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    unsigned int zT_133;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_135;
    zT_D3EB6303_StringInterner* zT_137;
    zT_F85C5DED_DiagnosticCollector* zT_138;
    zT_3E40CD83_Sand* zT_139;
    int zT_140;
    zT_138FFB41_Lexer zT_145 = {0};
    zT_138FFB41_Lexer* zT_147;
    zT_3A355BD2_Token zT_149 = {0};
    zT_EAC3E484_TokenKind zT_150;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    zT_D3EB6303_StringInterner* zT_165;
    zT_F85C5DED_DiagnosticCollector* zT_166;
    zT_3E40CD83_Sand* zT_167;
    int zT_168;
    zT_138FFB41_Lexer zT_173 = {0};
    zT_138FFB41_Lexer* zT_175;
    zT_3A355BD2_Token zT_177 = {0};
    zT_EAC3E484_TokenKind zT_178;
    unsigned char* zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    unsigned int zT_189;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_191;
    zT_D3EB6303_StringInterner* zT_193;
    zT_F85C5DED_DiagnosticCollector* zT_194;
    zT_3E40CD83_Sand* zT_195;
    int zT_196;
    zT_138FFB41_Lexer zT_201 = {0};
    zT_138FFB41_Lexer* zT_203;
    zT_3A355BD2_Token zT_205 = {0};
    zT_EAC3E484_TokenKind zT_206;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dec;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hex;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bin;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_oct;
    zT_138FFB41_Lexer l4;
    zT_3A355BD2_Token t4;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_float;
    zT_138FFB41_Lexer l5;
    zT_3A355BD2_Token t5;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sci;
    zT_138FFB41_Lexer l6;
    zT_3A355BD2_Token t6;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "42";
    zT_33 = 2;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_dec = zT_32;
    zT_35 = s_dec;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_61 = t1.span_start;
    zT_63 = 0;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_61), (unsigned int)((unsigned int)zT_63), (unsigned int)(0));
    zT_69 = t1.span_len;
    zT_71 = 2;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_69), (unsigned int)((unsigned int)zT_71), (unsigned int)(0));
    zT_75 = "0xFF";
    zT_77 = 4;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    s_hex = zT_76;
    zT_79 = s_hex;
    zT_84 = 0;
    zT_81 = &interner;
    zT_82 = &diag;
    zT_83 = &sand;
    zT_89 = zF_151E643F_lexerInit(zT_79, (unsigned int)((unsigned int)zT_84), zT_81, zT_82, zT_83);
    l2 = zT_89;
    zT_91 = &l2;
    zT_93 = zF_B976BEC9_lexerNextToken(zT_91);
    t2 = zT_93;
    zT_94 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_94, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_103 = "0b1010";
    zT_105 = 6;
    zT_104.ptr = zT_103;
    zT_104.len = zT_105;
    s_bin = zT_104;
    zT_107 = s_bin;
    zT_112 = 0;
    zT_109 = &interner;
    zT_110 = &diag;
    zT_111 = &sand;
    zT_117 = zF_151E643F_lexerInit(zT_107, (unsigned int)((unsigned int)zT_112), zT_109, zT_110, zT_111);
    l3 = zT_117;
    zT_119 = &l3;
    zT_121 = zF_B976BEC9_lexerNextToken(zT_119);
    t3 = zT_121;
    zT_122 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_122, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_131 = "0o77";
    zT_133 = 4;
    zT_132.ptr = zT_131;
    zT_132.len = zT_133;
    s_oct = zT_132;
    zT_135 = s_oct;
    zT_140 = 0;
    zT_137 = &interner;
    zT_138 = &diag;
    zT_139 = &sand;
    zT_145 = zF_151E643F_lexerInit(zT_135, (unsigned int)((unsigned int)zT_140), zT_137, zT_138, zT_139);
    l4 = zT_145;
    zT_147 = &l4;
    zT_149 = zF_B976BEC9_lexerNextToken(zT_147);
    t4 = zT_149;
    zT_150 = t4.kind;
    zF_1058D9A8_assertEqTokenKind(zT_150, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_159 = "3.14";
    zT_161 = 4;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    s_float = zT_160;
    zT_163 = s_float;
    zT_168 = 0;
    zT_165 = &interner;
    zT_166 = &diag;
    zT_167 = &sand;
    zT_173 = zF_151E643F_lexerInit(zT_163, (unsigned int)((unsigned int)zT_168), zT_165, zT_166, zT_167);
    l5 = zT_173;
    zT_175 = &l5;
    zT_177 = zF_B976BEC9_lexerNextToken(zT_175);
    t5 = zT_177;
    zT_178 = t5.kind;
    zF_1058D9A8_assertEqTokenKind(zT_178, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), (unsigned int)(0));
    zT_187 = "1.5e10";
    zT_189 = 6;
    zT_188.ptr = zT_187;
    zT_188.len = zT_189;
    s_sci = zT_188;
    zT_191 = s_sci;
    zT_196 = 0;
    zT_193 = &interner;
    zT_194 = &diag;
    zT_195 = &sand;
    zT_201 = zF_151E643F_lexerInit(zT_191, (unsigned int)((unsigned int)zT_196), zT_193, zT_194, zT_195);
    l6 = zT_201;
    zT_203 = &l6;
    zT_205 = zF_B976BEC9_lexerNextToken(zT_203);
    t6 = zT_205;
    zT_206 = t6.kind;
    zF_1058D9A8_assertEqTokenKind(zT_206, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), (unsigned int)(0));
    return;
}

/* lexerTestScanString */
void zF_A76AF035_lexerTestScanString(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_D3EB6303_StringInterner* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    int zT_68;
    zT_138FFB41_Lexer zT_73 = {0};
    zT_138FFB41_Lexer* zT_75;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_D3EB6303_StringInterner* zT_93;
    zT_F85C5DED_DiagnosticCollector* zT_94;
    zT_3E40CD83_Sand* zT_95;
    int zT_96;
    zT_138FFB41_Lexer zT_101 = {0};
    zT_138FFB41_Lexer* zT_103;
    zT_3A355BD2_Token zT_105 = {0};
    zT_EAC3E484_TokenKind zT_106;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hello;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_esc;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_unterm;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "\"hello\"";
    zT_33 = 7;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_hello = zT_32;
    zT_35 = s_hello;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal), (unsigned int)(0));
    zT_59 = "\"hello\\nworld\"";
    zT_61 = 14;
    zT_60.ptr = zT_59;
    zT_60.len = zT_61;
    s_esc = zT_60;
    zT_63 = s_esc;
    zT_68 = 0;
    zT_65 = &interner;
    zT_66 = &diag;
    zT_67 = &sand;
    zT_73 = zF_151E643F_lexerInit(zT_63, (unsigned int)((unsigned int)zT_68), zT_65, zT_66, zT_67);
    l2 = zT_73;
    zT_75 = &l2;
    zT_77 = zF_B976BEC9_lexerNextToken(zT_75);
    t2 = zT_77;
    zT_78 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_78, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal), (unsigned int)(0));
    zT_87 = "\"unterminated";
    zT_89 = 13;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    s_unterm = zT_88;
    zT_91 = s_unterm;
    zT_96 = 0;
    zT_93 = &interner;
    zT_94 = &diag;
    zT_95 = &sand;
    zT_101 = zF_151E643F_lexerInit(zT_91, (unsigned int)((unsigned int)zT_96), zT_93, zT_94, zT_95);
    l3 = zT_101;
    zT_103 = &l3;
    zT_105 = zF_B976BEC9_lexerNextToken(zT_103);
    t3 = zT_105;
    zT_106 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_106, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* lexerTestScanChar */
void zF_13791BA0_lexerTestScanChar(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_D3EB6303_StringInterner* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    int zT_68;
    zT_138FFB41_Lexer zT_73 = {0};
    zT_138FFB41_Lexer* zT_75;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_D3EB6303_StringInterner* zT_93;
    zT_F85C5DED_DiagnosticCollector* zT_94;
    zT_3E40CD83_Sand* zT_95;
    int zT_96;
    zT_138FFB41_Lexer zT_101 = {0};
    zT_138FFB41_Lexer* zT_103;
    zT_3A355BD2_Token zT_105 = {0};
    zT_EAC3E484_TokenKind zT_106;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_char;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_cesc;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_cempty;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "'a'";
    zT_33 = 3;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_char = zT_32;
    zT_35 = s_char;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    zT_59 = "'\\n'";
    zT_61 = 4;
    zT_60.ptr = zT_59;
    zT_60.len = zT_61;
    s_cesc = zT_60;
    zT_63 = s_cesc;
    zT_68 = 0;
    zT_65 = &interner;
    zT_66 = &diag;
    zT_67 = &sand;
    zT_73 = zF_151E643F_lexerInit(zT_63, (unsigned int)((unsigned int)zT_68), zT_65, zT_66, zT_67);
    l2 = zT_73;
    zT_75 = &l2;
    zT_77 = zF_B976BEC9_lexerNextToken(zT_75);
    t2 = zT_77;
    zT_78 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_78, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    zT_87 = "''";
    zT_89 = 2;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    s_cempty = zT_88;
    zT_91 = s_cempty;
    zT_96 = 0;
    zT_93 = &interner;
    zT_94 = &diag;
    zT_95 = &sand;
    zT_101 = zF_151E643F_lexerInit(zT_91, (unsigned int)((unsigned int)zT_96), zT_93, zT_94, zT_95);
    l3 = zT_101;
    zT_103 = &l3;
    zT_105 = zF_B976BEC9_lexerNextToken(zT_103);
    t3 = zT_105;
    zT_106 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_106, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    return;
}

/* lexerTestIdentifierKeywords */
void zF_B8F07D3E_lexerTestIdentifier(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_D3EB6303_StringInterner* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    int zT_68;
    zT_138FFB41_Lexer zT_73 = {0};
    zT_138FFB41_Lexer* zT_75;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    unsigned char* zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    zT_D3EB6303_StringInterner* zT_93;
    zT_F85C5DED_DiagnosticCollector* zT_94;
    zT_3E40CD83_Sand* zT_95;
    int zT_96;
    zT_138FFB41_Lexer zT_101 = {0};
    zT_138FFB41_Lexer* zT_103;
    zT_3A355BD2_Token zT_105 = {0};
    zT_EAC3E484_TokenKind zT_106;
    unsigned char* zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    unsigned int zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    zT_D3EB6303_StringInterner* zT_121;
    zT_F85C5DED_DiagnosticCollector* zT_122;
    zT_3E40CD83_Sand* zT_123;
    int zT_124;
    zT_138FFB41_Lexer zT_129 = {0};
    zT_138FFB41_Lexer* zT_131;
    zT_3A355BD2_Token zT_133 = {0};
    zT_EAC3E484_TokenKind zT_134;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_under;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ident;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_kw_const;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_kw_fn;
    zT_138FFB41_Lexer l4;
    zT_3A355BD2_Token t4;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "_";
    zT_33 = 1;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_under = zT_32;
    zT_35 = s_under;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore), (unsigned int)(0));
    zT_59 = "myVar";
    zT_61 = 5;
    zT_60.ptr = zT_59;
    zT_60.len = zT_61;
    s_ident = zT_60;
    zT_63 = s_ident;
    zT_68 = 0;
    zT_65 = &interner;
    zT_66 = &diag;
    zT_67 = &sand;
    zT_73 = zF_151E643F_lexerInit(zT_63, (unsigned int)((unsigned int)zT_68), zT_65, zT_66, zT_67);
    l2 = zT_73;
    zT_75 = &l2;
    zT_77 = zF_B976BEC9_lexerNextToken(zT_75);
    t2 = zT_77;
    zT_78 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_78, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier), (unsigned int)(0));
    zT_87 = "const";
    zT_89 = 5;
    zT_88.ptr = zT_87;
    zT_88.len = zT_89;
    s_kw_const = zT_88;
    zT_91 = s_kw_const;
    zT_96 = 0;
    zT_93 = &interner;
    zT_94 = &diag;
    zT_95 = &sand;
    zT_101 = zF_151E643F_lexerInit(zT_91, (unsigned int)((unsigned int)zT_96), zT_93, zT_94, zT_95);
    l3 = zT_101;
    zT_103 = &l3;
    zT_105 = zF_B976BEC9_lexerNextToken(zT_103);
    t3 = zT_105;
    zT_106 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_106, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const), (unsigned int)(0));
    zT_115 = "fn";
    zT_117 = 2;
    zT_116.ptr = zT_115;
    zT_116.len = zT_117;
    s_kw_fn = zT_116;
    zT_119 = s_kw_fn;
    zT_124 = 0;
    zT_121 = &interner;
    zT_122 = &diag;
    zT_123 = &sand;
    zT_129 = zF_151E643F_lexerInit(zT_119, (unsigned int)((unsigned int)zT_124), zT_121, zT_122, zT_123);
    l4 = zT_129;
    zT_131 = &l4;
    zT_133 = zF_B976BEC9_lexerNextToken(zT_131);
    t4 = zT_133;
    zT_134 = t4.kind;
    zF_1058D9A8_assertEqTokenKind(zT_134, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn), (unsigned int)(0));
    return;
}

/* lexerTestBuiltinIdentifier */
void zF_1C8729CF_lexerTestBuiltinIde(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_D3EB6303_StringInterner* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    int zT_68;
    zT_138FFB41_Lexer zT_73 = {0};
    zT_138FFB41_Lexer* zT_75;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sizeof;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bare_at;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "@sizeOf";
    zT_33 = 7;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_sizeof = zT_32;
    zT_35 = s_sizeof;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier), (unsigned int)(0));
    zT_59 = "@";
    zT_61 = 1;
    zT_60.ptr = zT_59;
    zT_60.len = zT_61;
    s_bare_at = zT_60;
    zT_63 = s_bare_at;
    zT_68 = 0;
    zT_65 = &interner;
    zT_66 = &diag;
    zT_67 = &sand;
    zT_73 = zF_151E643F_lexerInit(zT_63, (unsigned int)((unsigned int)zT_68), zT_65, zT_66, zT_67);
    l2 = zT_73;
    zT_75 = &l2;
    zT_77 = zF_B976BEC9_lexerNextToken(zT_75);
    t2 = zT_77;
    zT_78 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_78, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* lexerTestDiagnostics */
void zF_6836167B_lexerTestDiagnostic(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    zT_D3EB6303_StringInterner* zT_65;
    zT_F85C5DED_DiagnosticCollector* zT_66;
    zT_3E40CD83_Sand* zT_67;
    int zT_68;
    zT_138FFB41_Lexer zT_73 = {0};
    zT_138FFB41_Lexer* zT_75;
    zT_3A355BD2_Token zT_77 = {0};
    zT_EAC3E484_TokenKind zT_78;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_backtick;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_at_backtick;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "`";
    zT_33 = 1;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_backtick = zT_32;
    zT_35 = s_backtick;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    zT_59 = "@`";
    zT_61 = 2;
    zT_60.ptr = zT_59;
    zT_60.len = zT_61;
    s_at_backtick = zT_60;
    zT_63 = s_at_backtick;
    zT_68 = 0;
    zT_65 = &interner;
    zT_66 = &diag;
    zT_67 = &sand;
    zT_73 = zF_151E643F_lexerInit(zT_63, (unsigned int)((unsigned int)zT_68), zT_65, zT_66, zT_67);
    l2 = zT_73;
    zT_75 = &l2;
    zT_77 = zF_B976BEC9_lexerNextToken(zT_75);
    t2 = zT_77;
    zT_78 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_78, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* __module_init */
void zF_780653D2___module_init_5(void) {
    zT_3A355BD2_Token zT_0 = {0};
    zT_EAC3E484_TokenKind zT_1 = 0;
    zT_85CBA4DB_TokenValue zT_2 = {0};
    zT_47B162D1_U8ArrayList zT_3 = {0};
    zG_3A355BD2_Token = zT_0;
    zG_EAC3E484_TokenKind = zT_1;
    zG_85CBA4DB_TokenValue = zT_2;
    zG_47B162D1_U8ArrayList = zT_3;
    return;
}

/* EOF */
