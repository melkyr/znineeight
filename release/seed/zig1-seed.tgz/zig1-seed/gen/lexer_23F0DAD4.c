#include "lexer_23F0DAD4.h"
#include <stdio.h>
zT_138FFB41_Lexer zG_138FFB41_Lexer;
/* lexerInit */
zT_138FFB41_Lexer zF_151E643F_lexerInit(zT_8F083A69_Slice_zT_0B42B2F8_u source, unsigned int file_id, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_3E40CD83_Sand* zT_6;
    zT_0715C9B9_EU_832 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    zT_47B162D1_U8ArrayList* zT_16;
    zT_3E40CD83_Sand* zT_17;
    zT_47B162D1_U8ArrayList zT_18 = {0};
    zT_138FFB41_Lexer zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned char* sb_raw;
    zT_47B162D1_U8ArrayList* sb_ptr;
    zT_6 = alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(16), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    sb_raw = zT_13;
    zT_16 = (zT_47B162D1_U8ArrayList*)sb_raw;
    sb_ptr = zT_16;
    zT_17 = alloc;
    zT_18 = zF_E9FF0E66_byteArrayListInit(zT_17);
    *sb_ptr = zT_18;
    zT_19.source = source;
    zT_20 = 0;
    zT_19.pos = zT_20;
    zT_21 = 1;
    zT_19.line = zT_21;
    zT_22 = 1;
    zT_19.col = zT_22;
    zT_19.file_id = file_id;
    zT_19.interner = interner;
    zT_19.diag = diag;
    zT_19.string_buf = sb_ptr;
    zT_23 = 0;
    zT_19.count_only = zT_23;
    return zT_19;
}

/* lexerNextToken */
zT_3A355BD2_Token zF_B976BEC9_lexerNextToken(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3 = 0;
    zT_138FFB41_Lexer* zT_4;
    unsigned int zT_6;
    zT_85CBA4DB_TokenValue zT_7;
    zT_85CBA4DB_TokenValue zT_11 = {0};
    zT_3A355BD2_Token zT_13 = {0};
    unsigned int zT_15;
    zT_138FFB41_Lexer* zT_17;
    unsigned char zT_18 = 0;
    zT_138FFB41_Lexer* zT_19;
    unsigned int zT_21;
    zT_85CBA4DB_TokenValue zT_22;
    zT_85CBA4DB_TokenValue zT_25 = {0};
    zT_3A355BD2_Token zT_27 = {0};
    zT_138FFB41_Lexer* zT_28;
    unsigned int zT_30;
    zT_85CBA4DB_TokenValue zT_31;
    zT_85CBA4DB_TokenValue zT_34 = {0};
    zT_3A355BD2_Token zT_36 = {0};
    zT_138FFB41_Lexer* zT_37;
    unsigned int zT_39;
    zT_85CBA4DB_TokenValue zT_40;
    zT_85CBA4DB_TokenValue zT_43 = {0};
    zT_3A355BD2_Token zT_45 = {0};
    zT_138FFB41_Lexer* zT_46;
    unsigned int zT_48;
    zT_85CBA4DB_TokenValue zT_49;
    zT_85CBA4DB_TokenValue zT_52 = {0};
    zT_3A355BD2_Token zT_54 = {0};
    zT_138FFB41_Lexer* zT_55;
    unsigned int zT_57;
    zT_85CBA4DB_TokenValue zT_58;
    zT_85CBA4DB_TokenValue zT_61 = {0};
    zT_3A355BD2_Token zT_63 = {0};
    zT_138FFB41_Lexer* zT_64;
    unsigned int zT_66;
    zT_85CBA4DB_TokenValue zT_67;
    zT_85CBA4DB_TokenValue zT_70 = {0};
    zT_3A355BD2_Token zT_72 = {0};
    zT_138FFB41_Lexer* zT_73;
    unsigned int zT_75;
    zT_85CBA4DB_TokenValue zT_76;
    zT_85CBA4DB_TokenValue zT_79 = {0};
    zT_3A355BD2_Token zT_81 = {0};
    zT_138FFB41_Lexer* zT_82;
    unsigned int zT_84;
    zT_85CBA4DB_TokenValue zT_85;
    zT_85CBA4DB_TokenValue zT_88 = {0};
    zT_3A355BD2_Token zT_90 = {0};
    zT_138FFB41_Lexer* zT_91;
    unsigned int zT_93;
    zT_85CBA4DB_TokenValue zT_94;
    zT_85CBA4DB_TokenValue zT_97 = {0};
    zT_3A355BD2_Token zT_99 = {0};
    zT_138FFB41_Lexer* zT_100;
    unsigned char zT_103 = 0;
    zT_138FFB41_Lexer* zT_104;
    unsigned char zT_107 = 0;
    zT_138FFB41_Lexer* zT_108;
    unsigned int zT_110;
    zT_85CBA4DB_TokenValue zT_111;
    zT_85CBA4DB_TokenValue zT_114 = {0};
    zT_3A355BD2_Token zT_116 = {0};
    zT_138FFB41_Lexer* zT_117;
    unsigned int zT_119;
    zT_85CBA4DB_TokenValue zT_120;
    zT_85CBA4DB_TokenValue zT_123 = {0};
    zT_3A355BD2_Token zT_125 = {0};
    zT_138FFB41_Lexer* zT_126;
    unsigned char zT_129 = 0;
    zT_138FFB41_Lexer* zT_130;
    unsigned int zT_132;
    zT_85CBA4DB_TokenValue zT_133;
    zT_85CBA4DB_TokenValue zT_136 = {0};
    zT_3A355BD2_Token zT_138 = {0};
    zT_138FFB41_Lexer* zT_139;
    unsigned char zT_142 = 0;
    zT_138FFB41_Lexer* zT_143;
    unsigned int zT_145;
    zT_85CBA4DB_TokenValue zT_146;
    zT_85CBA4DB_TokenValue zT_149 = {0};
    zT_3A355BD2_Token zT_151 = {0};
    zT_138FFB41_Lexer* zT_152;
    unsigned int zT_154;
    zT_85CBA4DB_TokenValue zT_155;
    zT_85CBA4DB_TokenValue zT_158 = {0};
    zT_3A355BD2_Token zT_160 = {0};
    zT_138FFB41_Lexer* zT_161;
    unsigned char zT_164 = 0;
    zT_138FFB41_Lexer* zT_165;
    unsigned char zT_168 = 0;
    zT_138FFB41_Lexer* zT_169;
    unsigned int zT_171;
    zT_85CBA4DB_TokenValue zT_172;
    zT_85CBA4DB_TokenValue zT_175 = {0};
    zT_3A355BD2_Token zT_177 = {0};
    zT_138FFB41_Lexer* zT_178;
    unsigned int zT_180;
    zT_85CBA4DB_TokenValue zT_181;
    zT_85CBA4DB_TokenValue zT_184 = {0};
    zT_3A355BD2_Token zT_186 = {0};
    zT_138FFB41_Lexer* zT_187;
    unsigned char zT_190 = 0;
    zT_138FFB41_Lexer* zT_191;
    unsigned char zT_194 = 0;
    zT_138FFB41_Lexer* zT_195;
    unsigned int zT_197;
    zT_85CBA4DB_TokenValue zT_198;
    zT_85CBA4DB_TokenValue zT_201 = {0};
    zT_3A355BD2_Token zT_203 = {0};
    zT_138FFB41_Lexer* zT_204;
    unsigned int zT_206;
    zT_85CBA4DB_TokenValue zT_207;
    zT_85CBA4DB_TokenValue zT_210 = {0};
    zT_3A355BD2_Token zT_212 = {0};
    zT_138FFB41_Lexer* zT_213;
    unsigned char zT_216 = 0;
    zT_138FFB41_Lexer* zT_217;
    unsigned int zT_219;
    zT_85CBA4DB_TokenValue zT_220;
    zT_85CBA4DB_TokenValue zT_223 = {0};
    zT_3A355BD2_Token zT_225 = {0};
    zT_138FFB41_Lexer* zT_226;
    unsigned int zT_228;
    zT_85CBA4DB_TokenValue zT_229;
    zT_85CBA4DB_TokenValue zT_232 = {0};
    zT_3A355BD2_Token zT_234 = {0};
    zT_138FFB41_Lexer* zT_235;
    unsigned char zT_238 = 0;
    zT_138FFB41_Lexer* zT_239;
    unsigned char zT_242 = 0;
    zT_138FFB41_Lexer* zT_243;
    unsigned int zT_245;
    zT_85CBA4DB_TokenValue zT_246;
    zT_85CBA4DB_TokenValue zT_249 = {0};
    zT_3A355BD2_Token zT_251 = {0};
    zT_138FFB41_Lexer* zT_252;
    unsigned int zT_254;
    zT_85CBA4DB_TokenValue zT_255;
    zT_85CBA4DB_TokenValue zT_258 = {0};
    zT_3A355BD2_Token zT_260 = {0};
    zT_138FFB41_Lexer* zT_261;
    unsigned char zT_264 = 0;
    zT_138FFB41_Lexer* zT_265;
    unsigned char zT_268 = 0;
    zT_138FFB41_Lexer* zT_269;
    unsigned int zT_271;
    zT_85CBA4DB_TokenValue zT_272;
    zT_85CBA4DB_TokenValue zT_275 = {0};
    zT_3A355BD2_Token zT_277 = {0};
    zT_138FFB41_Lexer* zT_278;
    unsigned int zT_280;
    zT_85CBA4DB_TokenValue zT_281;
    zT_85CBA4DB_TokenValue zT_284 = {0};
    zT_3A355BD2_Token zT_286 = {0};
    zT_138FFB41_Lexer* zT_287;
    unsigned char zT_290 = 0;
    zT_138FFB41_Lexer* zT_291;
    unsigned int zT_293;
    zT_85CBA4DB_TokenValue zT_294;
    zT_85CBA4DB_TokenValue zT_297 = {0};
    zT_3A355BD2_Token zT_299 = {0};
    zT_138FFB41_Lexer* zT_300;
    unsigned int zT_302;
    zT_85CBA4DB_TokenValue zT_303;
    zT_85CBA4DB_TokenValue zT_306 = {0};
    zT_3A355BD2_Token zT_308 = {0};
    zT_138FFB41_Lexer* zT_309;
    unsigned char zT_312 = 0;
    zT_138FFB41_Lexer* zT_313;
    unsigned char zT_316 = 0;
    zT_138FFB41_Lexer* zT_317;
    unsigned int zT_319;
    zT_85CBA4DB_TokenValue zT_320;
    zT_85CBA4DB_TokenValue zT_323 = {0};
    zT_3A355BD2_Token zT_325 = {0};
    zT_138FFB41_Lexer* zT_326;
    unsigned int zT_328;
    zT_85CBA4DB_TokenValue zT_329;
    zT_85CBA4DB_TokenValue zT_332 = {0};
    zT_3A355BD2_Token zT_334 = {0};
    zT_138FFB41_Lexer* zT_335;
    unsigned char zT_338 = 0;
    zT_138FFB41_Lexer* zT_339;
    unsigned char zT_342 = 0;
    zT_138FFB41_Lexer* zT_343;
    unsigned int zT_345;
    zT_85CBA4DB_TokenValue zT_346;
    zT_85CBA4DB_TokenValue zT_349 = {0};
    zT_3A355BD2_Token zT_351 = {0};
    zT_138FFB41_Lexer* zT_352;
    unsigned int zT_354;
    zT_85CBA4DB_TokenValue zT_355;
    zT_85CBA4DB_TokenValue zT_358 = {0};
    zT_3A355BD2_Token zT_360 = {0};
    zT_138FFB41_Lexer* zT_361;
    unsigned char zT_364 = 0;
    zT_138FFB41_Lexer* zT_365;
    unsigned int zT_367;
    zT_85CBA4DB_TokenValue zT_368;
    zT_85CBA4DB_TokenValue zT_371 = {0};
    zT_3A355BD2_Token zT_373 = {0};
    zT_138FFB41_Lexer* zT_374;
    unsigned int zT_376;
    zT_85CBA4DB_TokenValue zT_377;
    zT_85CBA4DB_TokenValue zT_380 = {0};
    zT_3A355BD2_Token zT_382 = {0};
    zT_138FFB41_Lexer* zT_383;
    unsigned char zT_386 = 0;
    zT_138FFB41_Lexer* zT_387;
    unsigned int zT_389;
    zT_85CBA4DB_TokenValue zT_390;
    zT_85CBA4DB_TokenValue zT_393 = {0};
    zT_3A355BD2_Token zT_395 = {0};
    zT_138FFB41_Lexer* zT_396;
    unsigned int zT_398;
    zT_85CBA4DB_TokenValue zT_399;
    zT_85CBA4DB_TokenValue zT_402 = {0};
    zT_3A355BD2_Token zT_404 = {0};
    zT_138FFB41_Lexer* zT_405;
    unsigned char zT_408 = 0;
    zT_138FFB41_Lexer* zT_409;
    unsigned int zT_411;
    zT_85CBA4DB_TokenValue zT_412;
    zT_85CBA4DB_TokenValue zT_415 = {0};
    zT_3A355BD2_Token zT_417 = {0};
    zT_138FFB41_Lexer* zT_418;
    unsigned int zT_420;
    zT_85CBA4DB_TokenValue zT_421;
    zT_85CBA4DB_TokenValue zT_424 = {0};
    zT_3A355BD2_Token zT_426 = {0};
    zT_138FFB41_Lexer* zT_427;
    unsigned char zT_430 = 0;
    zT_138FFB41_Lexer* zT_431;
    unsigned int zT_433;
    zT_85CBA4DB_TokenValue zT_434;
    zT_85CBA4DB_TokenValue zT_437 = {0};
    zT_3A355BD2_Token zT_439 = {0};
    zT_138FFB41_Lexer* zT_440;
    unsigned int zT_442;
    zT_85CBA4DB_TokenValue zT_443;
    zT_85CBA4DB_TokenValue zT_446 = {0};
    zT_3A355BD2_Token zT_448 = {0};
    zT_138FFB41_Lexer* zT_449;
    unsigned char zT_452 = 0;
    zT_138FFB41_Lexer* zT_453;
    unsigned int zT_455;
    zT_85CBA4DB_TokenValue zT_456;
    zT_85CBA4DB_TokenValue zT_459 = {0};
    zT_3A355BD2_Token zT_461 = {0};
    zT_138FFB41_Lexer* zT_462;
    unsigned int zT_464;
    zT_85CBA4DB_TokenValue zT_465;
    zT_85CBA4DB_TokenValue zT_468 = {0};
    zT_3A355BD2_Token zT_470 = {0};
    zT_138FFB41_Lexer* zT_471;
    unsigned char zT_474 = 0;
    zT_138FFB41_Lexer* zT_475;
    unsigned int zT_477;
    zT_85CBA4DB_TokenValue zT_478;
    zT_85CBA4DB_TokenValue zT_481 = {0};
    zT_3A355BD2_Token zT_483 = {0};
    zT_138FFB41_Lexer* zT_484;
    unsigned char zT_487 = 0;
    zT_138FFB41_Lexer* zT_488;
    unsigned int zT_490;
    zT_85CBA4DB_TokenValue zT_491;
    zT_85CBA4DB_TokenValue zT_494 = {0};
    zT_3A355BD2_Token zT_496 = {0};
    zT_138FFB41_Lexer* zT_497;
    unsigned int zT_499;
    zT_85CBA4DB_TokenValue zT_500;
    zT_85CBA4DB_TokenValue zT_503 = {0};
    zT_3A355BD2_Token zT_505 = {0};
    zT_138FFB41_Lexer* zT_506;
    unsigned char zT_509 = 0;
    zT_138FFB41_Lexer* zT_510;
    unsigned int zT_512;
    zT_85CBA4DB_TokenValue zT_513;
    zT_85CBA4DB_TokenValue zT_516 = {0};
    zT_3A355BD2_Token zT_518 = {0};
    zT_138FFB41_Lexer* zT_519;
    unsigned int zT_521;
    zT_85CBA4DB_TokenValue zT_522;
    zT_85CBA4DB_TokenValue zT_525 = {0};
    zT_3A355BD2_Token zT_527 = {0};
    zT_138FFB41_Lexer* zT_528;
    unsigned char zT_531 = 0;
    zT_138FFB41_Lexer* zT_532;
    unsigned char zT_535 = 0;
    zT_138FFB41_Lexer* zT_536;
    unsigned char zT_539 = 0;
    zT_138FFB41_Lexer* zT_540;
    unsigned int zT_542;
    zT_85CBA4DB_TokenValue zT_543;
    zT_85CBA4DB_TokenValue zT_546 = {0};
    zT_3A355BD2_Token zT_548 = {0};
    zT_138FFB41_Lexer* zT_549;
    unsigned int zT_551;
    zT_85CBA4DB_TokenValue zT_552;
    zT_85CBA4DB_TokenValue zT_555 = {0};
    zT_3A355BD2_Token zT_557 = {0};
    zT_138FFB41_Lexer* zT_558;
    unsigned char zT_561 = 0;
    zT_138FFB41_Lexer* zT_562;
    unsigned int zT_564;
    zT_85CBA4DB_TokenValue zT_565;
    zT_85CBA4DB_TokenValue zT_568 = {0};
    zT_3A355BD2_Token zT_570 = {0};
    zT_138FFB41_Lexer* zT_571;
    unsigned int zT_573;
    zT_85CBA4DB_TokenValue zT_574;
    zT_85CBA4DB_TokenValue zT_577 = {0};
    zT_3A355BD2_Token zT_579 = {0};
    zT_138FFB41_Lexer* zT_580;
    unsigned char zT_583 = 0;
    zT_138FFB41_Lexer* zT_584;
    unsigned int zT_586;
    zT_85CBA4DB_TokenValue zT_587;
    zT_85CBA4DB_TokenValue zT_590 = {0};
    zT_3A355BD2_Token zT_592 = {0};
    zT_138FFB41_Lexer* zT_593;
    unsigned int zT_595;
    zT_85CBA4DB_TokenValue zT_596;
    zT_85CBA4DB_TokenValue zT_599 = {0};
    zT_3A355BD2_Token zT_601 = {0};
    zT_138FFB41_Lexer* zT_602;
    unsigned char zT_605 = 0;
    zT_138FFB41_Lexer* zT_606;
    unsigned char zT_609 = 0;
    zT_138FFB41_Lexer* zT_610;
    unsigned int zT_612;
    zT_85CBA4DB_TokenValue zT_613;
    zT_85CBA4DB_TokenValue zT_616 = {0};
    zT_3A355BD2_Token zT_618 = {0};
    zT_138FFB41_Lexer* zT_619;
    unsigned int zT_621;
    zT_85CBA4DB_TokenValue zT_622;
    zT_85CBA4DB_TokenValue zT_625 = {0};
    zT_3A355BD2_Token zT_627 = {0};
    zT_138FFB41_Lexer* zT_628;
    unsigned char zT_631 = 0;
    zT_138FFB41_Lexer* zT_632;
    unsigned int zT_634;
    zT_85CBA4DB_TokenValue zT_635;
    zT_85CBA4DB_TokenValue zT_638 = {0};
    zT_3A355BD2_Token zT_640 = {0};
    zT_138FFB41_Lexer* zT_641;
    unsigned int zT_643;
    zT_85CBA4DB_TokenValue zT_644;
    zT_85CBA4DB_TokenValue zT_647 = {0};
    zT_3A355BD2_Token zT_649 = {0};
    zT_138FFB41_Lexer* zT_650;
    unsigned char zT_653 = 0;
    zT_138FFB41_Lexer* zT_654;
    unsigned int zT_656;
    zT_85CBA4DB_TokenValue zT_657;
    zT_85CBA4DB_TokenValue zT_660 = {0};
    zT_3A355BD2_Token zT_662 = {0};
    zT_138FFB41_Lexer* zT_663;
    unsigned int zT_665;
    zT_85CBA4DB_TokenValue zT_666;
    zT_85CBA4DB_TokenValue zT_669 = {0};
    zT_3A355BD2_Token zT_671 = {0};
    zT_138FFB41_Lexer* zT_672;
    unsigned int zT_674;
    zT_85CBA4DB_TokenValue zT_675;
    zT_85CBA4DB_TokenValue zT_678 = {0};
    zT_3A355BD2_Token zT_680 = {0};
    zT_138FFB41_Lexer* zT_681;
    unsigned int zT_683;
    zT_85CBA4DB_TokenValue zT_684;
    zT_85CBA4DB_TokenValue zT_687 = {0};
    zT_3A355BD2_Token zT_689 = {0};
    unsigned char zT_690;
    zT_138FFB41_Lexer* zT_691;
    unsigned char zT_692 = 0;
    unsigned char zT_693 = 0;
    zT_138FFB41_Lexer* zT_694;
    unsigned int zT_695;
    zT_3A355BD2_Token zT_696 = {0};
    unsigned char* zT_698;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_699;
    unsigned int zT_700;
    unsigned char zT_701;
    zT_F85C5DED_DiagnosticCollector* zT_703;
    unsigned int zT_706;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_709;
    int zT_711;
    unsigned int zT_716;
    zT_138FFB41_Lexer* zT_719;
    unsigned int zT_720;
    zT_3A355BD2_Token zT_721 = {0};
    zT_138FFB41_Lexer* zT_722;
    unsigned int zT_723;
    zT_3A355BD2_Token zT_724 = {0};
    zT_138FFB41_Lexer* zT_725;
    unsigned int zT_726;
    zT_3A355BD2_Token zT_727 = {0};
    unsigned char zT_728;
    unsigned char zT_729 = 0;
    unsigned char zT_730;
    zT_138FFB41_Lexer* zT_733;
    unsigned int zT_734;
    zT_3A355BD2_Token zT_735 = {0};
    unsigned char zT_736;
    unsigned char zT_737 = 0;
    zT_138FFB41_Lexer* zT_738;
    unsigned int zT_739;
    unsigned char zT_740;
    zT_3A355BD2_Token zT_741 = {0};
    unsigned char zT_742;
    unsigned char* zT_745;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_746;
    unsigned int zT_747;
    zT_BBAAFAE2_Arr_unsigned_char_2 zT_749;
    int zT_750;
    unsigned char zT_751;
    int zT_752;
    unsigned char* zT_754;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_755;
    unsigned int zT_756;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_758;
    unsigned int zT_759;
    int zT_762;
    int zT_763;
    unsigned char* zT_764;
    unsigned int zT_765;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_766;
    unsigned int zT_767;
    unsigned int zT_768;
    zT_D3EB6303_StringInterner* zT_770;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_771;
    zT_F85C5DED_DiagnosticCollector* zT_773;
    int zT_775;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_776;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_778 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_779;
    unsigned int zT_782;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_785;
    int zT_787;
    unsigned int zT_792;
    zT_138FFB41_Lexer* zT_795;
    unsigned int zT_796;
    zT_3A355BD2_Token zT_797 = {0};
    unsigned int start;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u bare_at_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u up1;
    zT_BBAAFAE2_Arr_unsigned_char_2 char_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u up3;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u unrecognized_msg;
    zT_1 = self;
    zF_F7949B41_lexerSkipWSC(zT_1);
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = self;
    zT_6 = self->pos;
    zT_7 = zT_11;
    zT_13 = zF_369DD718_lexerMakeToken(zT_4, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof), zT_6, zT_7);
    return zT_13;
    z_bb_2:
    zT_15 = self->pos;
    start = zT_15;
    zT_17 = self;
    zT_18 = zF_7C2FDD01_lexerAdvance(zT_17);
    c = zT_18;
switch (c) {
case 40: goto z_bb_3;
case 41: goto z_bb_4;
case 91: goto z_bb_5;
case 93: goto z_bb_6;
case 123: goto z_bb_7;
case 125: goto z_bb_8;
case 59: goto z_bb_9;
case 58: goto z_bb_10;
case 44: goto z_bb_11;
case 46: goto z_bb_12;
case 43: goto z_bb_13;
case 45: goto z_bb_14;
case 42: goto z_bb_15;
case 47: goto z_bb_16;
case 37: goto z_bb_17;
case 38: goto z_bb_18;
case 124: goto z_bb_19;
case 61: goto z_bb_20;
case 33: goto z_bb_21;
case 60: goto z_bb_22;
case 62: goto z_bb_23;
case 94: goto z_bb_24;
case 126: goto z_bb_25;
case 63: goto z_bb_26;
case 64: goto z_bb_27;
case 34: goto z_bb_28;
case 39: goto z_bb_29;
default: goto z_bb_30;
}
    z_bb_3:
    zT_19 = self;
    zT_21 = start;
    zT_22 = zT_25;
    zT_27 = zF_369DD718_lexerMakeToken(zT_19, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen), zT_21, zT_22);
    return zT_27;
    z_bb_4:
    zT_28 = self;
    zT_30 = start;
    zT_31 = zT_34;
    zT_36 = zF_369DD718_lexerMakeToken(zT_28, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen), zT_30, zT_31);
    return zT_36;
    z_bb_5:
    zT_37 = self;
    zT_39 = start;
    zT_40 = zT_43;
    zT_45 = zF_369DD718_lexerMakeToken(zT_37, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket), zT_39, zT_40);
    return zT_45;
    z_bb_6:
    zT_46 = self;
    zT_48 = start;
    zT_49 = zT_52;
    zT_54 = zF_369DD718_lexerMakeToken(zT_46, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket), zT_48, zT_49);
    return zT_54;
    z_bb_7:
    zT_55 = self;
    zT_57 = start;
    zT_58 = zT_61;
    zT_63 = zF_369DD718_lexerMakeToken(zT_55, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace), zT_57, zT_58);
    return zT_63;
    z_bb_8:
    zT_64 = self;
    zT_66 = start;
    zT_67 = zT_70;
    zT_72 = zF_369DD718_lexerMakeToken(zT_64, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace), zT_66, zT_67);
    return zT_72;
    z_bb_9:
    zT_73 = self;
    zT_75 = start;
    zT_76 = zT_79;
    zT_81 = zF_369DD718_lexerMakeToken(zT_73, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon), zT_75, zT_76);
    return zT_81;
    z_bb_10:
    zT_82 = self;
    zT_84 = start;
    zT_85 = zT_88;
    zT_90 = zF_369DD718_lexerMakeToken(zT_82, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon), zT_84, zT_85);
    return zT_90;
    z_bb_11:
    zT_91 = self;
    zT_93 = start;
    zT_94 = zT_97;
    zT_99 = zF_369DD718_lexerMakeToken(zT_91, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma), zT_93, zT_94);
    return zT_99;
    z_bb_12:
    zT_100 = self;
    zT_103 = zF_8A07967A_lexerMatch(zT_100, (unsigned char)(46));
    if (zT_103) goto z_bb_33; else goto z_bb_34;
    z_bb_13:
    zT_161 = self;
    zT_164 = zF_8A07967A_lexerMatch(zT_161, (unsigned char)(37));
    if (zT_164) goto z_bb_41; else goto z_bb_42;
    z_bb_14:
    zT_235 = self;
    zT_238 = zF_8A07967A_lexerMatch(zT_235, (unsigned char)(37));
    if (zT_238) goto z_bb_51; else goto z_bb_52;
    z_bb_15:
    zT_309 = self;
    zT_312 = zF_8A07967A_lexerMatch(zT_309, (unsigned char)(37));
    if (zT_312) goto z_bb_61; else goto z_bb_62;
    z_bb_16:
    zT_383 = self;
    zT_386 = zF_8A07967A_lexerMatch(zT_383, (unsigned char)(61));
    if (zT_386) goto z_bb_71; else goto z_bb_72;
    z_bb_17:
    zT_405 = self;
    zT_408 = zF_8A07967A_lexerMatch(zT_405, (unsigned char)(61));
    if (zT_408) goto z_bb_73; else goto z_bb_74;
    z_bb_18:
    zT_427 = self;
    zT_430 = zF_8A07967A_lexerMatch(zT_427, (unsigned char)(61));
    if (zT_430) goto z_bb_75; else goto z_bb_76;
    z_bb_19:
    zT_449 = self;
    zT_452 = zF_8A07967A_lexerMatch(zT_449, (unsigned char)(61));
    if (zT_452) goto z_bb_77; else goto z_bb_78;
    z_bb_20:
    zT_471 = self;
    zT_474 = zF_8A07967A_lexerMatch(zT_471, (unsigned char)(61));
    if (zT_474) goto z_bb_79; else goto z_bb_80;
    z_bb_21:
    zT_506 = self;
    zT_509 = zF_8A07967A_lexerMatch(zT_506, (unsigned char)(61));
    if (zT_509) goto z_bb_83; else goto z_bb_84;
    z_bb_22:
    zT_528 = self;
    zT_531 = zF_8A07967A_lexerMatch(zT_528, (unsigned char)(60));
    if (zT_531) goto z_bb_85; else goto z_bb_86;
    z_bb_23:
    zT_602 = self;
    zT_605 = zF_8A07967A_lexerMatch(zT_602, (unsigned char)(62));
    if (zT_605) goto z_bb_95; else goto z_bb_96;
    z_bb_24:
    zT_650 = self;
    zT_653 = zF_8A07967A_lexerMatch(zT_650, (unsigned char)(61));
    if (zT_653) goto z_bb_101; else goto z_bb_102;
    z_bb_25:
    zT_672 = self;
    zT_674 = start;
    zT_675 = zT_678;
    zT_680 = zF_369DD718_lexerMakeToken(zT_672, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde), zT_674, zT_675);
    return zT_680;
    z_bb_26:
    zT_681 = self;
    zT_683 = start;
    zT_684 = zT_687;
    zT_689 = zF_369DD718_lexerMakeToken(zT_681, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark), zT_683, zT_684);
    return zT_689;
    z_bb_27:
    zT_691 = self;
    zT_692 = zF_6ACB12FA_lexerPeek(zT_691);
    zT_690 = zT_692;
    zT_693 = zF_0D29E41B_isAlpha(zT_690);
    if (zT_693) goto z_bb_103; else goto z_bb_104;
    z_bb_28:
    zT_722 = self;
    zT_723 = start;
    zT_724 = zF_D28972ED_lexerScanString(zT_722, zT_723);
    return zT_724;
    z_bb_29:
    zT_725 = self;
    zT_726 = start;
    zT_727 = zF_616D7368_lexerScanChar(zT_725, zT_726);
    return zT_727;
    z_bb_30:
    zT_728 = c;
    zT_729 = zF_0D29E41B_isAlpha(zT_728);
    if (zT_729) goto z_bb_108; else goto z_bb_107;
    { zT_3A355BD2_Token zT_ret_void = {0}; return zT_ret_void; }
    z_bb_33:
    zT_104 = self;
    zT_107 = zF_8A07967A_lexerMatch(zT_104, (unsigned char)(46));
    if (zT_107) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_126 = self;
    zT_129 = zF_8A07967A_lexerMatch(zT_126, (unsigned char)(123));
    if (zT_129) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    zT_108 = self;
    zT_110 = start;
    zT_111 = zT_114;
    zT_116 = zF_369DD718_lexerMakeToken(zT_108, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot), zT_110, zT_111);
    return zT_116;
    z_bb_36:
    zT_117 = self;
    zT_119 = start;
    zT_120 = zT_123;
    zT_125 = zF_369DD718_lexerMakeToken(zT_117, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot), zT_119, zT_120);
    return zT_125;
    z_bb_37:
    zT_130 = self;
    zT_132 = start;
    zT_133 = zT_136;
    zT_138 = zF_369DD718_lexerMakeToken(zT_130, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace), zT_132, zT_133);
    return zT_138;
    z_bb_38:
    zT_139 = self;
    zT_142 = zF_8A07967A_lexerMatch(zT_139, (unsigned char)(42));
    if (zT_142) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_143 = self;
    zT_145 = start;
    zT_146 = zT_149;
    zT_151 = zF_369DD718_lexerMakeToken(zT_143, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star), zT_145, zT_146);
    return zT_151;
    z_bb_40:
    zT_152 = self;
    zT_154 = start;
    zT_155 = zT_158;
    zT_160 = zF_369DD718_lexerMakeToken(zT_152, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot), zT_154, zT_155);
    return zT_160;
    z_bb_41:
    zT_165 = self;
    zT_168 = zF_8A07967A_lexerMatch(zT_165, (unsigned char)(61));
    if (zT_168) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_187 = self;
    zT_190 = zF_8A07967A_lexerMatch(zT_187, (unsigned char)(124));
    if (zT_190) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    zT_169 = self;
    zT_171 = start;
    zT_172 = zT_175;
    zT_177 = zF_369DD718_lexerMakeToken(zT_169, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct_eq), zT_171, zT_172);
    return zT_177;
    z_bb_44:
    zT_178 = self;
    zT_180 = start;
    zT_181 = zT_184;
    zT_186 = zF_369DD718_lexerMakeToken(zT_178, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pct), zT_180, zT_181);
    return zT_186;
    z_bb_45:
    zT_191 = self;
    zT_194 = zF_8A07967A_lexerMatch(zT_191, (unsigned char)(61));
    if (zT_194) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_213 = self;
    zT_216 = zF_8A07967A_lexerMatch(zT_213, (unsigned char)(61));
    if (zT_216) goto z_bb_49; else goto z_bb_50;
    z_bb_47:
    zT_195 = self;
    zT_197 = start;
    zT_198 = zT_201;
    zT_203 = zF_369DD718_lexerMakeToken(zT_195, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe_eq), zT_197, zT_198);
    return zT_203;
    z_bb_48:
    zT_204 = self;
    zT_206 = start;
    zT_207 = zT_210;
    zT_212 = zF_369DD718_lexerMakeToken(zT_204, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_pipe), zT_206, zT_207);
    return zT_212;
    z_bb_49:
    zT_217 = self;
    zT_219 = start;
    zT_220 = zT_223;
    zT_225 = zF_369DD718_lexerMakeToken(zT_217, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus_eq), zT_219, zT_220);
    return zT_225;
    z_bb_50:
    zT_226 = self;
    zT_228 = start;
    zT_229 = zT_232;
    zT_234 = zF_369DD718_lexerMakeToken(zT_226, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus), zT_228, zT_229);
    return zT_234;
    z_bb_51:
    zT_239 = self;
    zT_242 = zF_8A07967A_lexerMatch(zT_239, (unsigned char)(61));
    if (zT_242) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_261 = self;
    zT_264 = zF_8A07967A_lexerMatch(zT_261, (unsigned char)(124));
    if (zT_264) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_243 = self;
    zT_245 = start;
    zT_246 = zT_249;
    zT_251 = zF_369DD718_lexerMakeToken(zT_243, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct_eq), zT_245, zT_246);
    return zT_251;
    z_bb_54:
    zT_252 = self;
    zT_254 = start;
    zT_255 = zT_258;
    zT_260 = zF_369DD718_lexerMakeToken(zT_252, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pct), zT_254, zT_255);
    return zT_260;
    z_bb_55:
    zT_265 = self;
    zT_268 = zF_8A07967A_lexerMatch(zT_265, (unsigned char)(61));
    if (zT_268) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    zT_287 = self;
    zT_290 = zF_8A07967A_lexerMatch(zT_287, (unsigned char)(61));
    if (zT_290) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_269 = self;
    zT_271 = start;
    zT_272 = zT_275;
    zT_277 = zF_369DD718_lexerMakeToken(zT_269, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe_eq), zT_271, zT_272);
    return zT_277;
    z_bb_58:
    zT_278 = self;
    zT_280 = start;
    zT_281 = zT_284;
    zT_286 = zF_369DD718_lexerMakeToken(zT_278, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_pipe), zT_280, zT_281);
    return zT_286;
    z_bb_59:
    zT_291 = self;
    zT_293 = start;
    zT_294 = zT_297;
    zT_299 = zF_369DD718_lexerMakeToken(zT_291, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus_eq), zT_293, zT_294);
    return zT_299;
    z_bb_60:
    zT_300 = self;
    zT_302 = start;
    zT_303 = zT_306;
    zT_308 = zF_369DD718_lexerMakeToken(zT_300, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus), zT_302, zT_303);
    return zT_308;
    z_bb_61:
    zT_313 = self;
    zT_316 = zF_8A07967A_lexerMatch(zT_313, (unsigned char)(61));
    if (zT_316) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_335 = self;
    zT_338 = zF_8A07967A_lexerMatch(zT_335, (unsigned char)(124));
    if (zT_338) goto z_bb_65; else goto z_bb_66;
    z_bb_63:
    zT_317 = self;
    zT_319 = start;
    zT_320 = zT_323;
    zT_325 = zF_369DD718_lexerMakeToken(zT_317, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct_eq), zT_319, zT_320);
    return zT_325;
    z_bb_64:
    zT_326 = self;
    zT_328 = start;
    zT_329 = zT_332;
    zT_334 = zF_369DD718_lexerMakeToken(zT_326, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pct), zT_328, zT_329);
    return zT_334;
    z_bb_65:
    zT_339 = self;
    zT_342 = zF_8A07967A_lexerMatch(zT_339, (unsigned char)(61));
    if (zT_342) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    zT_361 = self;
    zT_364 = zF_8A07967A_lexerMatch(zT_361, (unsigned char)(61));
    if (zT_364) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    zT_343 = self;
    zT_345 = start;
    zT_346 = zT_349;
    zT_351 = zF_369DD718_lexerMakeToken(zT_343, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe_eq), zT_345, zT_346);
    return zT_351;
    z_bb_68:
    zT_352 = self;
    zT_354 = start;
    zT_355 = zT_358;
    zT_360 = zF_369DD718_lexerMakeToken(zT_352, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_pipe), zT_354, zT_355);
    return zT_360;
    z_bb_69:
    zT_365 = self;
    zT_367 = start;
    zT_368 = zT_371;
    zT_373 = zF_369DD718_lexerMakeToken(zT_365, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star_eq), zT_367, zT_368);
    return zT_373;
    z_bb_70:
    zT_374 = self;
    zT_376 = start;
    zT_377 = zT_380;
    zT_382 = zF_369DD718_lexerMakeToken(zT_374, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star), zT_376, zT_377);
    return zT_382;
    z_bb_71:
    zT_387 = self;
    zT_389 = start;
    zT_390 = zT_393;
    zT_395 = zF_369DD718_lexerMakeToken(zT_387, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash_eq), zT_389, zT_390);
    return zT_395;
    z_bb_72:
    zT_396 = self;
    zT_398 = start;
    zT_399 = zT_402;
    zT_404 = zF_369DD718_lexerMakeToken(zT_396, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash), zT_398, zT_399);
    return zT_404;
    z_bb_73:
    zT_409 = self;
    zT_411 = start;
    zT_412 = zT_415;
    zT_417 = zF_369DD718_lexerMakeToken(zT_409, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent_eq), zT_411, zT_412);
    return zT_417;
    z_bb_74:
    zT_418 = self;
    zT_420 = start;
    zT_421 = zT_424;
    zT_426 = zF_369DD718_lexerMakeToken(zT_418, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent), zT_420, zT_421);
    return zT_426;
    z_bb_75:
    zT_431 = self;
    zT_433 = start;
    zT_434 = zT_437;
    zT_439 = zF_369DD718_lexerMakeToken(zT_431, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand_eq), zT_433, zT_434);
    return zT_439;
    z_bb_76:
    zT_440 = self;
    zT_442 = start;
    zT_443 = zT_446;
    zT_448 = zF_369DD718_lexerMakeToken(zT_440, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand), zT_442, zT_443);
    return zT_448;
    z_bb_77:
    zT_453 = self;
    zT_455 = start;
    zT_456 = zT_459;
    zT_461 = zF_369DD718_lexerMakeToken(zT_453, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe_eq), zT_455, zT_456);
    return zT_461;
    z_bb_78:
    zT_462 = self;
    zT_464 = start;
    zT_465 = zT_468;
    zT_470 = zF_369DD718_lexerMakeToken(zT_462, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe), zT_464, zT_465);
    return zT_470;
    z_bb_79:
    zT_475 = self;
    zT_477 = start;
    zT_478 = zT_481;
    zT_483 = zF_369DD718_lexerMakeToken(zT_475, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq_eq), zT_477, zT_478);
    return zT_483;
    z_bb_80:
    zT_484 = self;
    zT_487 = zF_8A07967A_lexerMatch(zT_484, (unsigned char)(62));
    if (zT_487) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_488 = self;
    zT_490 = start;
    zT_491 = zT_494;
    zT_496 = zF_369DD718_lexerMakeToken(zT_488, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_fat_arrow), zT_490, zT_491);
    return zT_496;
    z_bb_82:
    zT_497 = self;
    zT_499 = start;
    zT_500 = zT_503;
    zT_505 = zF_369DD718_lexerMakeToken(zT_497, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eq), zT_499, zT_500);
    return zT_505;
    z_bb_83:
    zT_510 = self;
    zT_512 = start;
    zT_513 = zT_516;
    zT_518 = zF_369DD718_lexerMakeToken(zT_510, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang_eq), zT_512, zT_513);
    return zT_518;
    z_bb_84:
    zT_519 = self;
    zT_521 = start;
    zT_522 = zT_525;
    zT_527 = zF_369DD718_lexerMakeToken(zT_519, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang), zT_521, zT_522);
    return zT_527;
    z_bb_85:
    zT_532 = self;
    zT_535 = zF_8A07967A_lexerMatch(zT_532, (unsigned char)(124));
    if (zT_535) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    zT_580 = self;
    zT_583 = zF_8A07967A_lexerMatch(zT_580, (unsigned char)(61));
    if (zT_583) goto z_bb_93; else goto z_bb_94;
    z_bb_87:
    zT_536 = self;
    zT_539 = zF_8A07967A_lexerMatch(zT_536, (unsigned char)(61));
    if (zT_539) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_558 = self;
    zT_561 = zF_8A07967A_lexerMatch(zT_558, (unsigned char)(61));
    if (zT_561) goto z_bb_91; else goto z_bb_92;
    z_bb_89:
    zT_540 = self;
    zT_542 = start;
    zT_543 = zT_546;
    zT_548 = zF_369DD718_lexerMakeToken(zT_540, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe_eq), zT_542, zT_543);
    return zT_548;
    z_bb_90:
    zT_549 = self;
    zT_551 = start;
    zT_552 = zT_555;
    zT_557 = zF_369DD718_lexerMakeToken(zT_549, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_pipe), zT_551, zT_552);
    return zT_557;
    z_bb_91:
    zT_562 = self;
    zT_564 = start;
    zT_565 = zT_568;
    zT_570 = zF_369DD718_lexerMakeToken(zT_562, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl_eq), zT_564, zT_565);
    return zT_570;
    z_bb_92:
    zT_571 = self;
    zT_573 = start;
    zT_574 = zT_577;
    zT_579 = zF_369DD718_lexerMakeToken(zT_571, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shl), zT_573, zT_574);
    return zT_579;
    z_bb_93:
    zT_584 = self;
    zT_586 = start;
    zT_587 = zT_590;
    zT_592 = zF_369DD718_lexerMakeToken(zT_584, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less_eq), zT_586, zT_587);
    return zT_592;
    z_bb_94:
    zT_593 = self;
    zT_595 = start;
    zT_596 = zT_599;
    zT_601 = zF_369DD718_lexerMakeToken(zT_593, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_less), zT_595, zT_596);
    return zT_601;
    z_bb_95:
    zT_606 = self;
    zT_609 = zF_8A07967A_lexerMatch(zT_606, (unsigned char)(61));
    if (zT_609) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    zT_628 = self;
    zT_631 = zF_8A07967A_lexerMatch(zT_628, (unsigned char)(61));
    if (zT_631) goto z_bb_99; else goto z_bb_100;
    z_bb_97:
    zT_610 = self;
    zT_612 = start;
    zT_613 = zT_616;
    zT_618 = zF_369DD718_lexerMakeToken(zT_610, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr_eq), zT_612, zT_613);
    return zT_618;
    z_bb_98:
    zT_619 = self;
    zT_621 = start;
    zT_622 = zT_625;
    zT_627 = zF_369DD718_lexerMakeToken(zT_619, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_shr), zT_621, zT_622);
    return zT_627;
    z_bb_99:
    zT_632 = self;
    zT_634 = start;
    zT_635 = zT_638;
    zT_640 = zF_369DD718_lexerMakeToken(zT_632, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater_eq), zT_634, zT_635);
    return zT_640;
    z_bb_100:
    zT_641 = self;
    zT_643 = start;
    zT_644 = zT_647;
    zT_649 = zF_369DD718_lexerMakeToken(zT_641, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_greater), zT_643, zT_644);
    return zT_649;
    z_bb_101:
    zT_654 = self;
    zT_656 = start;
    zT_657 = zT_660;
    zT_662 = zF_369DD718_lexerMakeToken(zT_654, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret_eq), zT_656, zT_657);
    return zT_662;
    z_bb_102:
    zT_663 = self;
    zT_665 = start;
    zT_666 = zT_669;
    zT_671 = zF_369DD718_lexerMakeToken(zT_663, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret), zT_665, zT_666);
    return zT_671;
    z_bb_103:
    zT_694 = self;
    zT_695 = start;
    zT_696 = zF_9C3BDAA8_lexerScanBuiltinIde(zT_694, zT_695);
    return zT_696;
    z_bb_104:
    zT_698 = "bare '@' is not valid; expected builtin name (e.g., @sizeOf)";
    zT_700 = 60;
    zT_699.ptr = zT_698;
    zT_699.len = zT_700;
    bare_at_msg = zT_699;
    zT_701 = self->count_only;
    if ((unsigned char)(!zT_701)) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_703 = self->diag;
    zT_711 = 0;
    zT_706 = self->file_id;
    zT_716 = self->pos;
    zT_709 = bare_at_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_703, (unsigned char)((unsigned char)zT_711), (unsigned short)(4), zT_706, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_716), zT_709);
    goto z_bb_106;
    z_bb_106:
    zT_719 = self;
    zT_720 = start;
    zT_721 = zF_19A0FF20_lexerMakeErrorToken(zT_719, zT_720);
    return zT_721;
    z_bb_107:
    zT_730 = c == (unsigned char)(95);
    goto z_bb_109;
    z_bb_108:
    zT_730 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_730) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_733 = self;
    zT_734 = start;
    zT_735 = zF_EC7F12C5_lexerScanIdentifier(zT_733, zT_734);
    return zT_735;
    z_bb_111:
    zT_736 = c;
    zT_737 = zF_C95A8EC6_isDigit(zT_736);
    if (zT_737) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    zT_738 = self;
    zT_739 = start;
    zT_740 = c;
    zT_741 = zF_EF8134BD_lexerScanNumber(zT_738, zT_739, zT_740);
    return zT_741;
    z_bb_113:
    zT_742 = self->count_only;
    if ((unsigned char)(!zT_742)) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_745 = "unrecognized character: '";
    zT_747 = 25;
    zT_746.ptr = zT_745;
    zT_746.len = zT_747;
    up1 = zT_746;
    {
    unsigned int _i = 0;
    while (_i < 2) {
        zT_749[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 2) {
        char_buf[_i] = zT_749[_i];
        _i++;
    }
}
    zT_750 = 0;
    char_buf[zT_750] = c;
    zT_751 = 0;
    zT_752 = 1;
    char_buf[zT_752] = zT_751;
    zT_754 = "'";
    zT_756 = 1;
    zT_755.ptr = zT_754;
    zT_755.len = zT_756;
    up3 = zT_755;
    zT_759 = 0;
    zT_758[zT_759] = up1;
    zT_762 = 1;
    zT_763 = 0;
    zT_764 = (unsigned char*)((unsigned char*)char_buf) + zT_763;
    zT_765 = zT_762 - zT_763;
    zT_766.ptr = zT_764;
    zT_766.len = zT_765;
    zT_767 = 1;
    zT_758[zT_767] = zT_766;
    zT_768 = 2;
    zT_758[zT_768] = up3;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uparts[_i] = zT_758[_i];
        _i++;
    }
}
    zT_773 = self->diag;
    zT_770 = zT_773->interner;
    zT_775 = 0;
    zT_776 = uparts + zT_775;
    zT_771 = zT_776;
    zT_778 = zF_8C4BFF7C_diagnosticBuilderMa(zT_770, zT_771, (unsigned int)(3));
    unrecognized_msg = zT_778;
    zT_779 = self->diag;
    zT_787 = 0;
    zT_782 = self->file_id;
    zT_792 = self->pos;
    zT_785 = unrecognized_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_779, (unsigned char)((unsigned char)zT_787), (unsigned short)(5), zT_782, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_792), zT_785);
    goto z_bb_115;
    z_bb_115:
    zT_795 = self;
    zT_796 = start;
    zT_797 = zF_19A0FF20_lexerMakeErrorToken(zT_795, zT_796);
    return zT_797;
}

/* lexerAdvance */
unsigned char zF_7C2FDD01_lexerAdvance(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned char* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_18;
    int zT_19;
    int zT_22;
    unsigned int zT_24;
    int zT_25;
    unsigned char c;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    if ((unsigned char)(zT_1 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = self->source;
    zT_9 = zT_8.ptr;
    zT_10 = self->pos;
    zT_11 = zT_9[zT_10];
    c = zT_11;
    zT_12 = self->pos;
    zT_13 = 1;
    self->pos = (unsigned int)(zT_12 + (unsigned int)((unsigned int)zT_13));
    if ((unsigned char)(c == (unsigned char)(10))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_18 = self->line;
    zT_19 = 1;
    self->line = (unsigned int)(zT_18 + (unsigned int)((unsigned int)zT_19));
    zT_22 = 1;
    self->col = (unsigned int)((unsigned int)zT_22);
    goto z_bb_4;
    z_bb_4:
    return c;
    z_bb_5:
    zT_24 = self->col;
    zT_25 = 1;
    self->col = (unsigned int)(zT_24 + (unsigned int)((unsigned int)zT_25));
    goto z_bb_4;
}

/* lexerPeek */
unsigned char zF_6ACB12FA_lexerPeek(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned char* zT_8;
    unsigned int zT_9;
    unsigned char zT_10;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    if ((unsigned char)(zT_1 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = self->source;
    zT_8 = zT_7.ptr;
    zT_9 = self->pos;
    zT_10 = zT_8[zT_9];
    return zT_10;
}

/* lexerPeekN */
unsigned char zF_D1AE715C_lexerPeekN(zT_138FFB41_Lexer* self, unsigned int n) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned int idx;
    zT_3 = self->pos;
    zT_4 = zT_3 + n;
    idx = zT_4;
    zT_5 = self->source;
    zT_7 = zT_5.len;
    if ((unsigned char)(idx >= zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_10 = self->source;
    zT_11 = zT_10.ptr;
    zT_12 = zT_11[idx];
    return zT_12;
}

/* lexerIsAtEnd */
unsigned char zF_07BC1EA1_lexerIsAtEnd(zT_138FFB41_Lexer* self) {
    unsigned int zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_4;
    zT_1 = self->pos;
    zT_2 = self->source;
    zT_4 = zT_2.len;
    return (unsigned char)(zT_1 >= zT_4);
}

/* lexerMatch */
unsigned char zF_8A07967A_lexerMatch(zT_138FFB41_Lexer* self, unsigned char expected) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3 = 0;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7 = 0;
    zT_2 = self;
    zT_3 = zF_6ACB12FA_lexerPeek(zT_2);
    if ((unsigned char)(zT_3 != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_7C2FDD01_lexerAdvance(zT_6);
    (void)zT_7;
    return (unsigned char)(1);
}

/* lexerSkipWSC */
void zF_F7949B41_lexerSkipWSC(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    unsigned char zT_2 = 0;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6 = 0;
    zT_138FFB41_Lexer* zT_7;
    unsigned char zT_8 = 0;
    zT_138FFB41_Lexer* zT_9;
    int zT_11;
    unsigned char zT_13 = 0;
    zT_138FFB41_Lexer* zT_16;
    unsigned char zT_17 = 0;
    zT_138FFB41_Lexer* zT_18;
    unsigned char zT_19 = 0;
    zT_138FFB41_Lexer* zT_20;
    unsigned char zT_21 = 0;
    unsigned char zT_23;
    zT_138FFB41_Lexer* zT_24;
    unsigned char zT_25 = 0;
    zT_138FFB41_Lexer* zT_28;
    unsigned char zT_29 = 0;
    zT_138FFB41_Lexer* zT_30;
    int zT_32;
    unsigned char zT_34 = 0;
    zT_138FFB41_Lexer* zT_37;
    unsigned char zT_38 = 0;
    zT_138FFB41_Lexer* zT_39;
    unsigned char zT_40 = 0;
    int zT_42;
    unsigned int zT_43;
    zT_138FFB41_Lexer* zT_44;
    unsigned char zT_45 = 0;
    unsigned char zT_47;
    int zT_48;
    zT_138FFB41_Lexer* zT_50;
    unsigned char zT_51 = 0;
    unsigned char zT_54;
    zT_138FFB41_Lexer* zT_55;
    int zT_57;
    unsigned char zT_59 = 0;
    zT_138FFB41_Lexer* zT_62;
    unsigned char zT_63 = 0;
    zT_138FFB41_Lexer* zT_64;
    unsigned char zT_65 = 0;
    int zT_66;
    unsigned int zT_68;
    zT_138FFB41_Lexer* zT_69;
    unsigned char zT_70 = 0;
    unsigned char zT_73;
    zT_138FFB41_Lexer* zT_74;
    int zT_76;
    unsigned char zT_78 = 0;
    zT_138FFB41_Lexer* zT_81;
    unsigned char zT_82 = 0;
    zT_138FFB41_Lexer* zT_83;
    unsigned char zT_84 = 0;
    int zT_85;
    unsigned int zT_87;
    zT_138FFB41_Lexer* zT_88;
    unsigned char zT_89 = 0;
    int zT_90;
    unsigned char* zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    unsigned int zT_95;
    unsigned char zT_96;
    zT_F85C5DED_DiagnosticCollector* zT_98;
    unsigned int zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    int zT_106;
    unsigned int zT_110;
    unsigned int zT_112;
    unsigned char c;
    unsigned int depth;
    zT_8F083A69_Slice_zT_0B42B2F8_u unterminated_block_msg;
    goto z_bb_1;
    z_bb_1:
    zT_1 = self;
    zT_2 = zF_07BC1EA1_lexerIsAtEnd(zT_1);
    if ((unsigned char)(!zT_2)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_6ACB12FA_lexerPeek(zT_5);
    c = zT_6;
switch (c) {
case 32: goto z_bb_5;
case 9: goto z_bb_5;
case 10: goto z_bb_5;
case 13: goto z_bb_5;
case 47: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_7 = self;
    zT_8 = zF_7C2FDD01_lexerAdvance(zT_7);
    (void)zT_8;
    goto z_bb_9;
    z_bb_6:
    zT_9 = self;
    zT_11 = 1;
    zT_13 = zF_D1AE715C_lexerPeekN(zT_9, (unsigned int)((unsigned int)zT_11));
    if ((unsigned char)(zT_13 == (unsigned char)(47))) goto z_bb_10; else goto z_bb_12;
    z_bb_7:
    return;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_16 = self;
    zT_17 = zF_7C2FDD01_lexerAdvance(zT_16);
    (void)zT_17;
    zT_18 = self;
    zT_19 = zF_7C2FDD01_lexerAdvance(zT_18);
    (void)zT_19;
    goto z_bb_13;
    z_bb_11:
    goto z_bb_9;
    z_bb_12:
    zT_30 = self;
    zT_32 = 1;
    zT_34 = zF_D1AE715C_lexerPeekN(zT_30, (unsigned int)((unsigned int)zT_32));
    if ((unsigned char)(zT_34 == (unsigned char)(42))) goto z_bb_20; else goto z_bb_22;
    z_bb_13:
    zT_20 = self;
    zT_21 = zF_07BC1EA1_lexerIsAtEnd(zT_20);
    if ((unsigned char)(!zT_21)) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    zT_28 = self;
    zT_29 = zF_7C2FDD01_lexerAdvance(zT_28);
    (void)zT_29;
    goto z_bb_16;
    z_bb_15:
    goto z_bb_11;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_24 = self;
    zT_25 = zF_6ACB12FA_lexerPeek(zT_24);
    zT_23 = zT_25 != (unsigned char)(10);
    goto z_bb_19;
    z_bb_18:
    zT_23 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_23) goto z_bb_14; else goto z_bb_15;
    z_bb_20:
    zT_37 = self;
    zT_38 = zF_7C2FDD01_lexerAdvance(zT_37);
    (void)zT_38;
    zT_39 = self;
    zT_40 = zF_7C2FDD01_lexerAdvance(zT_39);
    (void)zT_40;
    zT_42 = 1;
    zT_43 = (unsigned int)zT_42;
    depth = zT_43;
    goto z_bb_23;
    z_bb_21:
    goto z_bb_11;
    z_bb_22:
    return;
    z_bb_23:
    zT_44 = self;
    zT_45 = zF_07BC1EA1_lexerIsAtEnd(zT_44);
    if ((unsigned char)(!zT_45)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_50 = self;
    zT_51 = zF_6ACB12FA_lexerPeek(zT_50);
    if ((unsigned char)(zT_51 == (unsigned char)(42))) goto z_bb_30; else goto z_bb_31;
    z_bb_25:
    zT_90 = 0;
    if ((unsigned char)(depth > (unsigned int)zT_90)) goto z_bb_42; else goto z_bb_43;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_48 = 0;
    zT_47 = depth > (unsigned int)zT_48;
    goto z_bb_29;
    z_bb_28:
    zT_47 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_47) goto z_bb_24; else goto z_bb_25;
    z_bb_30:
    zT_55 = self;
    zT_57 = 1;
    zT_59 = zF_D1AE715C_lexerPeekN(zT_55, (unsigned int)((unsigned int)zT_57));
    zT_54 = zT_59 == (unsigned char)(47);
    goto z_bb_32;
    z_bb_31:
    zT_54 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_54) goto z_bb_33; else goto z_bb_35;
    z_bb_33:
    zT_62 = self;
    zT_63 = zF_7C2FDD01_lexerAdvance(zT_62);
    (void)zT_63;
    zT_64 = self;
    zT_65 = zF_7C2FDD01_lexerAdvance(zT_64);
    (void)zT_65;
    zT_66 = 1;
    zT_68 = depth - (unsigned int)((unsigned int)zT_66);
    depth = zT_68;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_26;
    z_bb_35:
    zT_69 = self;
    zT_70 = zF_6ACB12FA_lexerPeek(zT_69);
    if ((unsigned char)(zT_70 == (unsigned char)(47))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_74 = self;
    zT_76 = 1;
    zT_78 = zF_D1AE715C_lexerPeekN(zT_74, (unsigned int)((unsigned int)zT_76));
    zT_73 = zT_78 == (unsigned char)(42);
    goto z_bb_38;
    z_bb_37:
    zT_73 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_73) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_81 = self;
    zT_82 = zF_7C2FDD01_lexerAdvance(zT_81);
    (void)zT_82;
    zT_83 = self;
    zT_84 = zF_7C2FDD01_lexerAdvance(zT_83);
    (void)zT_84;
    zT_85 = 1;
    zT_87 = depth + (unsigned int)((unsigned int)zT_85);
    depth = zT_87;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_34;
    z_bb_41:
    zT_88 = self;
    zT_89 = zF_7C2FDD01_lexerAdvance(zT_88);
    (void)zT_89;
    goto z_bb_40;
    z_bb_42:
    zT_93 = "unterminated block comment";
    zT_95 = 26;
    zT_94.ptr = zT_93;
    zT_94.len = zT_95;
    unterminated_block_msg = zT_94;
    zT_96 = self->count_only;
    if ((unsigned char)(!zT_96)) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    goto z_bb_21;
    z_bb_44:
    zT_98 = self->diag;
    zT_106 = 0;
    zT_101 = self->file_id;
    zT_110 = self->pos;
    zT_112 = self->pos;
    zT_104 = unterminated_block_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_98, (unsigned char)((unsigned char)zT_106), (unsigned short)(1), zT_101, (unsigned int)((unsigned int)zT_110), (unsigned int)((unsigned int)zT_112), zT_104);
    goto z_bb_45;
    z_bb_45:
    goto z_bb_43;
}

/* lexerMakeToken */
zT_3A355BD2_Token zF_369DD718_lexerMakeToken(zT_138FFB41_Lexer* self, zT_EAC3E484_TokenKind kind, unsigned int start, zT_85CBA4DB_TokenValue value) {
    unsigned int zT_5;
    unsigned short zT_7;
    zT_3A355BD2_Token zT_8;
    unsigned int zT_9;
    unsigned short zT_10;
    unsigned short span_len;
    zT_5 = self->pos;
    zT_7 = (unsigned short)(unsigned int)(zT_5 - start);
    span_len = zT_7;
    zT_8.kind = kind;
    zT_9 = (unsigned int)start;
    zT_8.span_start = zT_9;
    zT_10 = (unsigned short)span_len;
    zT_8.span_len = zT_10;
    zT_8.value = value;
    return zT_8;
}

/* lexerMakeErrorToken */
zT_3A355BD2_Token zF_19A0FF20_lexerMakeErrorToken(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_3A355BD2_Token zT_2;
    zT_EAC3E484_TokenKind zT_4;
    unsigned int zT_5;
    unsigned short zT_6;
    zT_85CBA4DB_TokenValue zT_7 = {0};
    (void)self;
    zT_4 = zT_EAC3E484_TokenKind_err_token;
    zT_2.kind = zT_4;
    zT_5 = (unsigned int)start;
    zT_2.span_start = zT_5;
    zT_6 = 1;
    zT_2.span_len = zT_6;
    zT_2.value = zT_7;
    return zT_2;
}

/* lexerScanString */
zT_3A355BD2_Token zF_D28972ED_lexerScanString(zT_138FFB41_Lexer* self, unsigned int start) {
    unsigned char zT_2;
    int zT_4;
    zT_47B162D1_U8ArrayList* zT_6;
    zT_138FFB41_Lexer* zT_7;
    unsigned char zT_8 = 0;
    zT_138FFB41_Lexer* zT_11;
    unsigned char zT_12 = 0;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16 = 0;
    unsigned char zT_17;
    zT_3A355BD2_Token zT_18;
    zT_EAC3E484_TokenKind zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned short zT_24;
    zT_85CBA4DB_TokenValue zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28 = {0};
    zT_47B162D1_U8ArrayList* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32 = {0};
    unsigned int zT_34;
    int zT_35;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    zT_D3EB6303_StringInterner* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_45 = 0;
    zT_3A355BD2_Token zT_46;
    zT_EAC3E484_TokenKind zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned short zT_52;
    zT_85CBA4DB_TokenValue zT_53;
    unsigned char zT_56;
    int zT_57;
    unsigned char zT_59;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    int zT_73;
    unsigned int zT_78;
    zT_138FFB41_Lexer* zT_81;
    unsigned int zT_82;
    zT_3A355BD2_Token zT_83 = {0};
    zT_138FFB41_Lexer* zT_84;
    unsigned char zT_85 = 0;
    unsigned char zT_88;
    zT_47B162D1_U8ArrayList* zT_90;
    unsigned char zT_91;
    zT_138FFB41_Lexer* zT_93;
    unsigned char zT_94 = 0;
    zT_138FFB41_Lexer* zT_95;
    unsigned char zT_96 = 0;
    unsigned char zT_97;
    zT_47B162D1_U8ArrayList* zT_99;
    unsigned char zT_100;
    zT_138FFB41_Lexer* zT_102;
    unsigned int zT_103;
    zT_3A355BD2_Token zT_104 = {0};
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    zT_8F083A69_Slice_zT_0B42B2F8_u sb_slice;
    unsigned int id;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_8F083A69_Slice_zT_0B42B2F8_u unterminated_string_msg;
    zT_2 = self->count_only;
    if ((unsigned char)(!zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 0;
    zT_6 = self->string_buf;
    zT_6->len = (unsigned int)((unsigned int)zT_4);
    goto z_bb_2;
    z_bb_2:
    goto z_bb_3;
    z_bb_3:
    zT_7 = self;
    zT_8 = zF_07BC1EA1_lexerIsAtEnd(zT_7);
    if ((unsigned char)(!zT_8)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = self;
    zT_12 = zF_6ACB12FA_lexerPeek(zT_11);
    c = zT_12;
    if ((unsigned char)(c == (unsigned char)(34))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_102 = self;
    zT_103 = start;
    zT_104 = zF_19A0FF20_lexerMakeErrorToken(zT_102, zT_103);
    return zT_104;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_15 = self;
    zT_16 = zF_7C2FDD01_lexerAdvance(zT_15);
    (void)zT_16;
    zT_17 = self->count_only;
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(c == (unsigned char)(10))) goto z_bb_15; else goto z_bb_14;
    z_bb_9:
    zT_20 = zT_EAC3E484_TokenKind_string_literal;
    zT_18.kind = zT_20;
    zT_21 = (unsigned int)start;
    zT_18.span_start = zT_21;
    zT_22 = self->pos;
    zT_24 = (unsigned short)(unsigned int)(zT_22 - start);
    zT_18.span_len = zT_24;
    zT_26 = 0;
    zT_25.string_id = zT_26;
    zT_18.value = zT_25;
    return zT_18;
    z_bb_10:
    text = zT_28;
    zT_30 = self->string_buf;
    zT_32 = zF_2ADA0742_byteArrayListGetSli(zT_30);
    sb_slice = zT_32;
    zT_34 = sb_slice.len;
    zT_35 = 0;
    if ((unsigned char)(zT_34 > (unsigned int)zT_35)) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    text = sb_slice;
    goto z_bb_12;
    z_bb_12:
    zT_42 = self->interner;
    zT_43 = text;
    zT_45 = zF_50C274AF_stringInternerInter(zT_42, zT_43);
    id = zT_45;
    zT_48 = zT_EAC3E484_TokenKind_string_literal;
    zT_46.kind = zT_48;
    zT_49 = (unsigned int)start;
    zT_46.span_start = zT_49;
    zT_50 = self->pos;
    zT_52 = (unsigned short)(unsigned int)(zT_50 - start);
    zT_46.span_len = zT_52;
    zT_53.string_id = id;
    zT_46.value = zT_53;
    return zT_46;
    z_bb_13:
    zT_38 = "";
    zT_40 = 0;
    zT_39.ptr = zT_38;
    zT_39.len = zT_40;
    empty_str = zT_39;
    text = empty_str;
    goto z_bb_12;
    z_bb_14:
    zT_57 = 0;
    zT_56 = c == zT_57;
    goto z_bb_16;
    z_bb_15:
    zT_56 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_56) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_59 = self->count_only;
    if ((unsigned char)(!zT_59)) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_84 = self;
    zT_85 = zF_7C2FDD01_lexerAdvance(zT_84);
    (void)zT_85;
    if ((unsigned char)(c == (unsigned char)(92))) goto z_bb_21; else goto z_bb_23;
    z_bb_19:
    zT_62 = "unterminated string literal";
    zT_64 = 27;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    unterminated_string_msg = zT_63;
    zT_65 = self->diag;
    zT_73 = 0;
    zT_68 = self->file_id;
    zT_78 = self->pos;
    zT_71 = unterminated_string_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_65, (unsigned char)((unsigned char)zT_73), (unsigned short)(0), zT_68, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_78), zT_71);
    goto z_bb_20;
    z_bb_20:
    zT_81 = self;
    zT_82 = start;
    zT_83 = zF_19A0FF20_lexerMakeErrorToken(zT_81, zT_82);
    return zT_83;
    z_bb_21:
    zT_88 = self->count_only;
    if ((unsigned char)(!zT_88)) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_6;
    z_bb_23:
    zT_97 = self->count_only;
    if ((unsigned char)(!zT_97)) goto z_bb_27; else goto z_bb_28;
    z_bb_24:
    zT_90 = self->string_buf;
    zT_93 = self;
    zT_94 = zF_7D4EA30A_lexerParseEscapeSeq(zT_93);
    zT_91 = zT_94;
    zF_463FE7A4_byteArrayListAppend(zT_90, zT_91);
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_95 = self;
    zT_96 = zF_7D4EA30A_lexerParseEscapeSeq(zT_95);
    (void)zT_96;
    goto z_bb_25;
    z_bb_27:
    zT_99 = self->string_buf;
    zT_100 = c;
    zF_463FE7A4_byteArrayListAppend(zT_99, zT_100);
    goto z_bb_28;
    z_bb_28:
    goto z_bb_22;
}

/* lexerScanChar */
zT_3A355BD2_Token zF_616D7368_lexerScanChar(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3 = 0;
    unsigned char zT_4;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6 = 0;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_15;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    int zT_23;
    unsigned int zT_28;
    zT_138FFB41_Lexer* zT_31;
    unsigned char zT_32 = 0;
    zT_138FFB41_Lexer* zT_35;
    unsigned char zT_36 = 0;
    zT_138FFB41_Lexer* zT_37;
    unsigned int zT_39;
    zT_85CBA4DB_TokenValue zT_40;
    zT_85CBA4DB_TokenValue zT_43;
    zT_79FAE712_u64 zT_44;
    zT_3A355BD2_Token zT_45 = {0};
    int zT_47;
    unsigned int zT_48;
    zT_138FFB41_Lexer* zT_50;
    unsigned char zT_51 = 0;
    zT_138FFB41_Lexer* zT_54;
    unsigned char zT_55 = 0;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_138FFB41_Lexer* zT_58;
    unsigned char zT_59 = 0;
    unsigned char* zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    unsigned char zT_66;
    zT_F85C5DED_DiagnosticCollector* zT_68;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    int zT_76;
    unsigned int zT_81;
    zT_138FFB41_Lexer* zT_84;
    unsigned char zT_85 = 0;
    zT_3A355BD2_Token zT_86;
    zT_EAC3E484_TokenKind zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned short zT_92;
    zT_85CBA4DB_TokenValue zT_93;
    zT_79FAE712_u64 zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_char_msg;
    unsigned int value;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u expected_close_msg;
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if (zT_3) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = self;
    zT_6 = zF_6ACB12FA_lexerPeek(zT_5);
    zT_4 = zT_6 == (unsigned char)(39);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = "empty character literal";
    zT_12 = 23;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    empty_char_msg = zT_11;
    zT_13 = self->count_only;
    if ((unsigned char)(!zT_13)) goto z_bb_6; else goto z_bb_7;
    z_bb_5:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    value = zT_48;
    zT_50 = self;
    zT_51 = zF_7C2FDD01_lexerAdvance(zT_50);
    c = zT_51;
    if ((unsigned char)(c == (unsigned char)(92))) goto z_bb_10; else goto z_bb_12;
    z_bb_6:
    zT_15 = self->diag;
    zT_23 = 0;
    zT_18 = self->file_id;
    zT_28 = self->pos;
    zT_21 = empty_char_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_15, (unsigned char)((unsigned char)zT_23), (unsigned short)(2), zT_18, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_28), zT_21);
    goto z_bb_7;
    z_bb_7:
    zT_31 = self;
    zT_32 = zF_6ACB12FA_lexerPeek(zT_31);
    if ((unsigned char)(zT_32 == (unsigned char)(39))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = self;
    zT_36 = zF_7C2FDD01_lexerAdvance(zT_35);
    (void)zT_36;
    goto z_bb_9;
    z_bb_9:
    zT_37 = self;
    zT_39 = start;
    zT_44 = 0;
    zT_43.int_val = zT_44;
    zT_40 = zT_43;
    zT_45 = zF_369DD718_lexerMakeToken(zT_37, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), zT_39, zT_40);
    return zT_45;
    z_bb_10:
    zT_54 = self;
    zT_55 = zF_7D4EA30A_lexerParseEscapeSeq(zT_54);
    zT_56 = (unsigned int)zT_55;
    value = zT_56;
    goto z_bb_11;
    z_bb_11:
    zT_58 = self;
    zT_59 = zF_6ACB12FA_lexerPeek(zT_58);
    if ((unsigned char)(zT_59 != (unsigned char)(39))) goto z_bb_13; else goto z_bb_15;
    z_bb_12:
    zT_57 = (unsigned int)c;
    value = zT_57;
    goto z_bb_11;
    z_bb_13:
    zT_63 = "expected closing ' in character literal";
    zT_65 = 39;
    zT_64.ptr = zT_63;
    zT_64.len = zT_65;
    expected_close_msg = zT_64;
    zT_66 = self->count_only;
    if ((unsigned char)(!zT_66)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    zT_88 = zT_EAC3E484_TokenKind_char_literal;
    zT_86.kind = zT_88;
    zT_89 = (unsigned int)start;
    zT_86.span_start = zT_89;
    zT_90 = self->pos;
    zT_92 = (unsigned short)(unsigned int)(zT_90 - start);
    zT_86.span_len = zT_92;
    zT_94 = (zT_79FAE712_u64)value;
    zT_93.int_val = zT_94;
    zT_86.value = zT_93;
    return zT_86;
    z_bb_15:
    zT_84 = self;
    zT_85 = zF_7C2FDD01_lexerAdvance(zT_84);
    (void)zT_85;
    goto z_bb_14;
    z_bb_16:
    zT_68 = self->diag;
    zT_76 = 0;
    zT_71 = self->file_id;
    zT_81 = self->pos;
    zT_74 = expected_close_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_68, (unsigned char)((unsigned char)zT_76), (unsigned short)(2), zT_71, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_81), zT_74);
    goto z_bb_17;
    z_bb_17:
    goto z_bb_14;
}

/* lexerScanNumber */
zT_3A355BD2_Token zF_EF8134BD_lexerScanNumber(zT_138FFB41_Lexer* self, unsigned int start, unsigned char first) {
    unsigned char zT_4;
    int zT_6;
    unsigned char zT_7;
    unsigned char zT_10;
    zT_138FFB41_Lexer* zT_11;
    unsigned char zT_12 = 0;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16 = 0;
    unsigned char zT_19;
    int zT_22;
    unsigned char zT_23;
    zT_138FFB41_Lexer* zT_24;
    unsigned char zT_25 = 0;
    unsigned char zT_28;
    int zT_31;
    unsigned char zT_32;
    zT_138FFB41_Lexer* zT_33;
    unsigned char zT_34 = 0;
    unsigned char zT_37;
    int zT_40;
    unsigned char zT_41;
    zT_138FFB41_Lexer* zT_42;
    unsigned char zT_43 = 0;
    zT_138FFB41_Lexer* zT_44;
    unsigned char zT_45 = 0;
    zT_138FFB41_Lexer* zT_48;
    unsigned char zT_49 = 0;
    zT_138FFB41_Lexer* zT_52;
    unsigned char zT_53 = 0;
    unsigned char zT_54;
    unsigned char zT_55;
    unsigned char zT_56 = 0;
    zT_138FFB41_Lexer* zT_58;
    unsigned char zT_59 = 0;
    int zT_60;
    unsigned char zT_62;
    zT_138FFB41_Lexer* zT_63;
    unsigned char zT_64 = 0;
    unsigned char zT_67;
    zT_138FFB41_Lexer* zT_68;
    int zT_70;
    unsigned char zT_72 = 0;
    zT_138FFB41_Lexer* zT_75;
    unsigned char zT_76 = 0;
    unsigned char zT_77;
    zT_138FFB41_Lexer* zT_78;
    unsigned char zT_79 = 0;
    zT_138FFB41_Lexer* zT_82;
    unsigned char zT_83 = 0;
    zT_138FFB41_Lexer* zT_86;
    unsigned char zT_87 = 0;
    unsigned char zT_88;
    unsigned char zT_89 = 0;
    zT_138FFB41_Lexer* zT_91;
    unsigned char zT_92 = 0;
    int zT_93;
    unsigned char zT_95;
    zT_138FFB41_Lexer* zT_96;
    unsigned char zT_97 = 0;
    unsigned char zT_100;
    zT_138FFB41_Lexer* zT_101;
    unsigned char zT_102 = 0;
    zT_138FFB41_Lexer* zT_105;
    unsigned char zT_106 = 0;
    zT_138FFB41_Lexer* zT_107;
    unsigned char zT_108 = 0;
    unsigned char zT_111;
    zT_138FFB41_Lexer* zT_112;
    unsigned char zT_113 = 0;
    zT_138FFB41_Lexer* zT_116;
    unsigned char zT_117 = 0;
    zT_138FFB41_Lexer* zT_118;
    unsigned char zT_119 = 0;
    unsigned char zT_121;
    unsigned char zT_122;
    zT_138FFB41_Lexer* zT_123;
    unsigned char zT_124 = 0;
    unsigned char zT_125 = 0;
    zT_138FFB41_Lexer* zT_126;
    unsigned char zT_127 = 0;
    unsigned char zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_130;
    unsigned char* zT_131;
    unsigned int zT_133;
    unsigned char* zT_134;
    unsigned int zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    double zT_139 = 0;
    zT_138FFB41_Lexer* zT_140;
    unsigned int zT_142;
    zT_85CBA4DB_TokenValue zT_143;
    zT_85CBA4DB_TokenValue zT_146;
    zT_3A355BD2_Token zT_147 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_149;
    unsigned char zT_150;
    zT_79FAE712_u64 zT_151 = 0;
    zT_79FAE712_u64 zT_152;
    unsigned char zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned char zT_156 = 0;
    unsigned char* zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_160;
    unsigned int zT_161;
    unsigned char zT_162;
    zT_F85C5DED_DiagnosticCollector* zT_164;
    unsigned int zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    int zT_172;
    unsigned int zT_177;
    zT_138FFB41_Lexer* zT_180;
    unsigned int zT_182;
    zT_85CBA4DB_TokenValue zT_183;
    zT_85CBA4DB_TokenValue zT_186;
    zT_3A355BD2_Token zT_187 = {0};
    unsigned char is_float;
    unsigned char base;
    unsigned char next;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    double value;
    zT_79FAE712_u64 value_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u overflow_msg;
    zT_4 = 0;
    is_float = zT_4;
    zT_6 = 10;
    zT_7 = (unsigned char)zT_6;
    base = zT_7;
    if ((unsigned char)(first == (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self;
    zT_12 = zF_07BC1EA1_lexerIsAtEnd(zT_11);
    zT_10 = !zT_12;
    goto z_bb_3;
    z_bb_2:
    zT_10 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_10) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = self;
    zT_16 = zF_6ACB12FA_lexerPeek(zT_15);
    next = zT_16;
    if ((unsigned char)(next == (unsigned char)(120))) goto z_bb_7; else goto z_bb_6;
    z_bb_5:
    goto z_bb_23;
    z_bb_6:
    zT_19 = next == (unsigned char)(88);
    goto z_bb_8;
    z_bb_7:
    zT_19 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_19) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_22 = 16;
    zT_23 = (unsigned char)zT_22;
    base = zT_23;
    zT_24 = self;
    zT_25 = zF_7C2FDD01_lexerAdvance(zT_24);
    (void)zT_25;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_5;
    z_bb_11:
    if ((unsigned char)(next == (unsigned char)(98))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_28 = next == (unsigned char)(66);
    goto z_bb_14;
    z_bb_13:
    zT_28 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_28) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_31 = 2;
    zT_32 = (unsigned char)zT_31;
    base = zT_32;
    zT_33 = self;
    zT_34 = zF_7C2FDD01_lexerAdvance(zT_33);
    (void)zT_34;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    if ((unsigned char)(next == (unsigned char)(111))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_37 = next == (unsigned char)(79);
    goto z_bb_20;
    z_bb_19:
    zT_37 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_37) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_40 = 8;
    zT_41 = (unsigned char)zT_40;
    base = zT_41;
    zT_42 = self;
    zT_43 = zF_7C2FDD01_lexerAdvance(zT_42);
    (void)zT_43;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_16;
    z_bb_23:
    zT_44 = self;
    zT_45 = zF_07BC1EA1_lexerIsAtEnd(zT_44);
    if ((unsigned char)(!zT_45)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_48 = self;
    zT_49 = zF_6ACB12FA_lexerPeek(zT_48);
    c = zT_49;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_60 = 10;
    if ((unsigned char)(base == zT_60)) goto z_bb_31; else goto z_bb_32;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_52 = self;
    zT_53 = zF_7C2FDD01_lexerAdvance(zT_52);
    (void)zT_53;
    goto z_bb_26;
    z_bb_28:
    zT_54 = c;
    zT_55 = base;
    zT_56 = zF_C5E3A034_isDigitInBase(zT_54, zT_55);
    if ((unsigned char)(!zT_56)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_58 = self;
    zT_59 = zF_7C2FDD01_lexerAdvance(zT_58);
    (void)zT_59;
    goto z_bb_26;
    z_bb_31:
    zT_63 = self;
    zT_64 = zF_6ACB12FA_lexerPeek(zT_63);
    zT_62 = zT_64 == (unsigned char)(46);
    goto z_bb_33;
    z_bb_32:
    zT_62 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_62) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_68 = self;
    zT_70 = 1;
    zT_72 = zF_D1AE715C_lexerPeekN(zT_68, (unsigned int)((unsigned int)zT_70));
    zT_67 = zT_72 != (unsigned char)(46);
    goto z_bb_36;
    z_bb_35:
    zT_67 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_67) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_75 = self;
    zT_76 = zF_7C2FDD01_lexerAdvance(zT_75);
    (void)zT_76;
    zT_77 = 1;
    is_float = zT_77;
    goto z_bb_39;
    z_bb_38:
    zT_93 = 10;
    if ((unsigned char)(base == zT_93)) goto z_bb_47; else goto z_bb_48;
    z_bb_39:
    zT_78 = self;
    zT_79 = zF_07BC1EA1_lexerIsAtEnd(zT_78);
    if ((unsigned char)(!zT_79)) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_82 = self;
    zT_83 = zF_6ACB12FA_lexerPeek(zT_82);
    c = zT_83;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_86 = self;
    zT_87 = zF_7C2FDD01_lexerAdvance(zT_86);
    (void)zT_87;
    goto z_bb_42;
    z_bb_44:
    zT_88 = c;
    zT_89 = zF_C95A8EC6_isDigit(zT_88);
    if ((unsigned char)(!zT_89)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    goto z_bb_41;
    z_bb_46:
    zT_91 = self;
    zT_92 = zF_7C2FDD01_lexerAdvance(zT_91);
    (void)zT_92;
    goto z_bb_42;
    z_bb_47:
    zT_96 = self;
    zT_97 = zF_6ACB12FA_lexerPeek(zT_96);
    if ((unsigned char)(zT_97 == (unsigned char)(101))) goto z_bb_51; else goto z_bb_50;
    z_bb_48:
    zT_95 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_95) goto z_bb_53; else goto z_bb_54;
    z_bb_50:
    zT_101 = self;
    zT_102 = zF_6ACB12FA_lexerPeek(zT_101);
    zT_100 = zT_102 == (unsigned char)(69);
    goto z_bb_52;
    z_bb_51:
    zT_100 = 1;
    goto z_bb_52;
    z_bb_52:
    zT_95 = zT_100;
    goto z_bb_49;
    z_bb_53:
    zT_105 = self;
    zT_106 = zF_7C2FDD01_lexerAdvance(zT_105);
    (void)zT_106;
    zT_107 = self;
    zT_108 = zF_6ACB12FA_lexerPeek(zT_107);
    if ((unsigned char)(zT_108 == (unsigned char)(43))) goto z_bb_56; else goto z_bb_55;
    z_bb_54:
    zT_130 = self->source;
    zT_131 = zT_130.ptr;
    zT_133 = self->pos;
    zT_134 = zT_131 + start;
    zT_135 = zT_133 - start;
    zT_136.ptr = zT_134;
    zT_136.len = zT_135;
    text = zT_136;
    if (is_float) goto z_bb_67; else goto z_bb_69;
    z_bb_55:
    zT_112 = self;
    zT_113 = zF_6ACB12FA_lexerPeek(zT_112);
    zT_111 = zT_113 == (unsigned char)(45);
    goto z_bb_57;
    z_bb_56:
    zT_111 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_111) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_116 = self;
    zT_117 = zF_7C2FDD01_lexerAdvance(zT_116);
    (void)zT_117;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_60;
    z_bb_60:
    zT_118 = self;
    zT_119 = zF_07BC1EA1_lexerIsAtEnd(zT_118);
    if ((unsigned char)(!zT_119)) goto z_bb_64; else goto z_bb_65;
    z_bb_61:
    zT_126 = self;
    zT_127 = zF_7C2FDD01_lexerAdvance(zT_126);
    (void)zT_127;
    goto z_bb_63;
    z_bb_62:
    zT_128 = 1;
    is_float = zT_128;
    goto z_bb_54;
    z_bb_63:
    goto z_bb_60;
    z_bb_64:
    zT_123 = self;
    zT_124 = zF_6ACB12FA_lexerPeek(zT_123);
    zT_122 = zT_124;
    zT_125 = zF_C95A8EC6_isDigit(zT_122);
    zT_121 = zT_125;
    goto z_bb_66;
    z_bb_65:
    zT_121 = 0;
    goto z_bb_66;
    z_bb_66:
    if (zT_121) goto z_bb_61; else goto z_bb_62;
    z_bb_67:
    zT_138 = text;
    zT_139 = zF_37CDE8A4_parseF64(zT_138);
    value = zT_139;
    zT_140 = self;
    zT_142 = start;
    zT_146.float_val = value;
    zT_143 = zT_146;
    zT_147 = zF_369DD718_lexerMakeToken(zT_140, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), zT_142, zT_143);
    return zT_147;
    { zT_3A355BD2_Token zT_ret_void = {0}; return zT_ret_void; }
    z_bb_69:
    zT_149 = text;
    zT_150 = base;
    zT_151 = zF_8EC79679_parseU64(zT_149, zT_150);
    value_1 = zT_151;
    zT_152 = 18446744073709551615ULL;
    if ((unsigned char)(value_1 == (zT_79FAE712_u64)zT_152)) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_155 = text;
    zT_156 = zF_6E4D822B_isU64MaxLiteral(zT_155);
    zT_154 = !zT_156;
    goto z_bb_72;
    z_bb_71:
    zT_154 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_154) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_159 = "integer literal overflow; value truncated";
    zT_161 = 41;
    zT_160.ptr = zT_159;
    zT_160.len = zT_161;
    overflow_msg = zT_160;
    zT_162 = self->count_only;
    if ((unsigned char)(!zT_162)) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    zT_180 = self;
    zT_182 = start;
    zT_186.int_val = value_1;
    zT_183 = zT_186;
    zT_187 = zF_369DD718_lexerMakeToken(zT_180, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), zT_182, zT_183);
    return zT_187;
    z_bb_75:
    zT_164 = self->diag;
    zT_172 = 1;
    zT_167 = self->file_id;
    zT_177 = self->pos;
    zT_170 = overflow_msg;
    (void)zF_C82559AC_diagnosticCollector(zT_164, (unsigned char)((unsigned char)zT_172), (unsigned short)(7), zT_167, (unsigned int)((unsigned int)start), (unsigned int)((unsigned int)zT_177), zT_170);
    goto z_bb_76;
    z_bb_76:
    goto z_bb_74;
}

/* lexerScanIdentifierOrKeyword */
zT_3A355BD2_Token zF_EC7F12C5_lexerScanIdentifier(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3 = 0;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7 = 0;
    unsigned char zT_8;
    unsigned char zT_9 = 0;
    unsigned char zT_11;
    unsigned char zT_12;
    unsigned char zT_13 = 0;
    unsigned char zT_15;
    zT_138FFB41_Lexer* zT_18;
    unsigned char zT_19 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned char* zT_22;
    unsigned int zT_24;
    unsigned char* zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_29;
    int zT_30;
    unsigned char zT_32;
    unsigned char* zT_33;
    int zT_34;
    unsigned char zT_35;
    int zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    zT_D3EB6303_StringInterner* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_46 = 0;
    zT_138FFB41_Lexer* zT_47;
    unsigned int zT_49;
    zT_85CBA4DB_TokenValue zT_50;
    zT_85CBA4DB_TokenValue zT_53;
    zT_3A355BD2_Token zT_54 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    zT_ACDCBA03_Opt_84 zT_56 = {0};
    unsigned char zT_57;
    zT_138FFB41_Lexer* zT_59;
    zT_EAC3E484_TokenKind zT_60;
    unsigned int zT_61;
    zT_85CBA4DB_TokenValue zT_62;
    zT_85CBA4DB_TokenValue zT_63 = {0};
    zT_3A355BD2_Token zT_65 = {0};
    int zT_67;
    unsigned int zT_68;
    unsigned char zT_69;
    zT_D3EB6303_StringInterner* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_74 = 0;
    unsigned int zT_76;
    unsigned char* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    unsigned char zT_84;
    unsigned char* zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    unsigned char zT_90;
    unsigned char* zT_91;
    unsigned int zT_92;
    unsigned char zT_93;
    unsigned char zT_96;
    unsigned char* zT_97;
    unsigned int zT_98;
    unsigned char zT_99;
    unsigned char zT_102;
    unsigned char* zT_103;
    unsigned int zT_104;
    unsigned char zT_105;
    unsigned char zT_108;
    unsigned char* zT_109;
    unsigned int zT_110;
    unsigned char zT_111;
    unsigned char zT_114;
    unsigned char* zT_115;
    unsigned int zT_116;
    unsigned char zT_117;
    unsigned char zT_120;
    unsigned char* zT_121;
    unsigned int zT_122;
    unsigned char zT_123;
    unsigned char zT_126;
    unsigned char* zT_127;
    unsigned int zT_128;
    unsigned char zT_129;
    unsigned char zT_132;
    unsigned char* zT_135;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_136;
    unsigned int zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    zT_138FFB41_Lexer* zT_139;
    unsigned int zT_141;
    zT_85CBA4DB_TokenValue zT_142;
    zT_85CBA4DB_TokenValue zT_145;
    zT_3A355BD2_Token zT_146 = {0};
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int string_id;
    zT_EAC3E484_TokenKind kind;
    zT_8F083A69_Slice_zT_0B42B2F8_u lxm;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if ((unsigned char)(!zT_3)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_6ACB12FA_lexerPeek(zT_6);
    c = zT_7;
    zT_8 = c;
    zT_9 = zF_0D29E41B_isAlpha(zT_8);
    if ((unsigned char)(!zT_9)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_21 = self->source;
    zT_22 = zT_21.ptr;
    zT_24 = self->pos;
    zT_25 = zT_22 + start;
    zT_26 = zT_24 - start;
    zT_27.ptr = zT_25;
    zT_27.len = zT_26;
    text = zT_27;
    zT_29 = text.len;
    zT_30 = 1;
    if ((unsigned char)(zT_29 == (unsigned int)zT_30)) goto z_bb_13; else goto z_bb_14;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_12 = c;
    zT_13 = zF_C95A8EC6_isDigit(zT_12);
    zT_11 = !zT_13;
    goto z_bb_7;
    z_bb_6:
    zT_11 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_11) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_15 = c != (unsigned char)(95);
    goto z_bb_10;
    z_bb_9:
    zT_15 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_15) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    goto z_bb_3;
    z_bb_12:
    zT_18 = self;
    zT_19 = zF_7C2FDD01_lexerAdvance(zT_18);
    (void)zT_19;
    goto z_bb_4;
    z_bb_13:
    zT_33 = text.ptr;
    zT_34 = 0;
    zT_35 = zT_33[zT_34];
    zT_32 = zT_35 == (unsigned char)(95);
    goto z_bb_15;
    z_bb_14:
    zT_32 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_32) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    string_id = zT_40;
    zT_41 = self->count_only;
    if ((unsigned char)(!zT_41)) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_55 = text;
    zT_56 = zF_6FF3ED46_lookupKeyword(zT_55);
    zT_57 = zT_56.has_value;
    if (zT_57) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_43 = self->interner;
    zT_44 = text;
    zT_46 = zF_50C274AF_stringInternerInter(zT_43, zT_44);
    string_id = zT_46;
    goto z_bb_19;
    z_bb_19:
    zT_47 = self;
    zT_49 = start;
    zT_53.string_id = string_id;
    zT_50 = zT_53;
    zT_54 = zF_369DD718_lexerMakeToken(zT_47, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore), zT_49, zT_50);
    return zT_54;
    z_bb_20:
    kind = zT_56.value;
    zT_59 = self;
    zT_60 = kind;
    zT_61 = start;
    zT_62 = zT_63;
    zT_65 = zF_369DD718_lexerMakeToken(zT_59, zT_60, zT_61, zT_62);
    return zT_65;
    z_bb_21:
    zT_67 = 0;
    zT_68 = (unsigned int)zT_67;
    string_id = zT_68;
    zT_69 = self->count_only;
    if ((unsigned char)(!zT_69)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_71 = self->interner;
    zT_72 = text;
    zT_74 = zF_50C274AF_stringInternerInter(zT_71, zT_72);
    string_id = zT_74;
    goto z_bb_23;
    z_bb_23:
    zT_76 = text.len;
    if ((unsigned char)(zT_76 == (unsigned int)(9))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_79 = text.ptr;
    zT_80 = 0;
    zT_81 = zT_79[zT_80];
    if ((unsigned char)(zT_81 == (unsigned char)(110))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    zT_139 = self;
    zT_141 = start;
    zT_145.string_id = string_id;
    zT_142 = zT_145;
    zT_146 = zF_369DD718_lexerMakeToken(zT_139, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier), zT_141, zT_142);
    return zT_146;
    z_bb_26:
    zT_85 = text.ptr;
    zT_86 = 1;
    zT_87 = zT_85[zT_86];
    zT_84 = zT_87 == (unsigned char)(101);
    goto z_bb_28;
    z_bb_27:
    zT_84 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_84) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_91 = text.ptr;
    zT_92 = 2;
    zT_93 = zT_91[zT_92];
    zT_90 = zT_93 == (unsigned char)(105);
    goto z_bb_31;
    z_bb_30:
    zT_90 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_90) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_97 = text.ptr;
    zT_98 = 3;
    zT_99 = zT_97[zT_98];
    zT_96 = zT_99 == (unsigned char)(103);
    goto z_bb_34;
    z_bb_33:
    zT_96 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_96) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_103 = text.ptr;
    zT_104 = 4;
    zT_105 = zT_103[zT_104];
    zT_102 = zT_105 == (unsigned char)(104);
    goto z_bb_37;
    z_bb_36:
    zT_102 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_102) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_109 = text.ptr;
    zT_110 = 5;
    zT_111 = zT_109[zT_110];
    zT_108 = zT_111 == (unsigned char)(98);
    goto z_bb_40;
    z_bb_39:
    zT_108 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_108) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_115 = text.ptr;
    zT_116 = 6;
    zT_117 = zT_115[zT_116];
    zT_114 = zT_117 == (unsigned char)(111);
    goto z_bb_43;
    z_bb_42:
    zT_114 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_114) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_121 = text.ptr;
    zT_122 = 7;
    zT_123 = zT_121[zT_122];
    zT_120 = zT_123 == (unsigned char)(114);
    goto z_bb_46;
    z_bb_45:
    zT_120 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_120) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_127 = text.ptr;
    zT_128 = 8;
    zT_129 = zT_127[zT_128];
    zT_126 = zT_129 == (unsigned char)(115);
    goto z_bb_49;
    z_bb_48:
    zT_126 = 0;
    goto z_bb_49;
    z_bb_49:
    if (zT_126) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_132 = self->count_only;
    if ((unsigned char)(!zT_132)) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    goto z_bb_25;
    z_bb_52:
    zT_135 = "LEX";
    zT_137 = 3;
    zT_136.ptr = zT_135;
    zT_136.len = zT_137;
    lxm = zT_136;
    zT_138 = lxm;
    zF_E4B2EF19_stderr_write(zT_138);
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
}

/* lexerScanBuiltinIdentifier */
zT_3A355BD2_Token zF_9C3BDAA8_lexerScanBuiltinIde(zT_138FFB41_Lexer* self, unsigned int start) {
    zT_138FFB41_Lexer* zT_2;
    unsigned char zT_3 = 0;
    zT_138FFB41_Lexer* zT_6;
    unsigned char zT_7 = 0;
    unsigned char zT_8;
    unsigned char zT_9 = 0;
    unsigned char zT_11;
    zT_138FFB41_Lexer* zT_14;
    unsigned char zT_15 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char* zT_18;
    unsigned int zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    int zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_D3EB6303_StringInterner* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_32 = 0;
    unsigned int zT_34;
    unsigned char* zT_37;
    unsigned int zT_38;
    unsigned char zT_39;
    unsigned char zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    unsigned char zT_45;
    unsigned char zT_48;
    unsigned char* zT_49;
    unsigned int zT_50;
    unsigned char zT_51;
    unsigned char zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    unsigned char zT_57;
    unsigned char zT_60;
    unsigned char* zT_61;
    unsigned int zT_62;
    unsigned char zT_63;
    unsigned char zT_66;
    unsigned char* zT_67;
    unsigned int zT_68;
    unsigned char zT_69;
    unsigned char zT_72;
    unsigned char* zT_73;
    unsigned int zT_74;
    unsigned char zT_75;
    unsigned char zT_78;
    unsigned char* zT_79;
    unsigned int zT_80;
    unsigned char zT_81;
    unsigned char zT_84;
    unsigned char* zT_85;
    unsigned int zT_86;
    unsigned char zT_87;
    zT_138FFB41_Lexer* zT_90;
    unsigned int zT_92;
    zT_85CBA4DB_TokenValue zT_93;
    zT_85CBA4DB_TokenValue zT_96;
    zT_3A355BD2_Token zT_97 = {0};
    zT_138FFB41_Lexer* zT_98;
    unsigned int zT_100;
    zT_85CBA4DB_TokenValue zT_101;
    zT_85CBA4DB_TokenValue zT_104;
    zT_3A355BD2_Token zT_105 = {0};
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int string_id;
    goto z_bb_1;
    z_bb_1:
    zT_2 = self;
    zT_3 = zF_07BC1EA1_lexerIsAtEnd(zT_2);
    if ((unsigned char)(!zT_3)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = self;
    zT_7 = zF_6ACB12FA_lexerPeek(zT_6);
    c = zT_7;
    zT_8 = c;
    zT_9 = zF_97170599_isAlphaNum(zT_8);
    if ((unsigned char)(!zT_9)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17 = self->source;
    zT_18 = zT_17.ptr;
    zT_20 = self->pos;
    zT_21 = zT_18 + start;
    zT_22 = zT_20 - start;
    zT_23.ptr = zT_21;
    zT_23.len = zT_22;
    text = zT_23;
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    string_id = zT_26;
    zT_27 = self->count_only;
    if ((unsigned char)(!zT_27)) goto z_bb_10; else goto z_bb_11;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = c != (unsigned char)(95);
    goto z_bb_7;
    z_bb_6:
    zT_11 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_11) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_14 = self;
    zT_15 = zF_7C2FDD01_lexerAdvance(zT_14);
    (void)zT_15;
    goto z_bb_4;
    z_bb_10:
    zT_29 = self->interner;
    zT_30 = text;
    zT_32 = zF_50C274AF_stringInternerInter(zT_29, zT_30);
    string_id = zT_32;
    goto z_bb_11;
    z_bb_11:
    zT_34 = text.len;
    if ((unsigned char)(zT_34 == (unsigned int)(9))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_37 = text.ptr;
    zT_38 = 0;
    zT_39 = zT_37[zT_38];
    if ((unsigned char)(zT_39 == (unsigned char)(64))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_98 = self;
    zT_100 = start;
    zT_104.string_id = string_id;
    zT_101 = zT_104;
    zT_105 = zF_369DD718_lexerMakeToken(zT_98, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier), zT_100, zT_101);
    return zT_105;
    z_bb_14:
    zT_43 = text.ptr;
    zT_44 = 1;
    zT_45 = zT_43[zT_44];
    zT_42 = zT_45 == (unsigned char)(99);
    goto z_bb_16;
    z_bb_15:
    zT_42 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_42) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_49 = text.ptr;
    zT_50 = 2;
    zT_51 = zT_49[zT_50];
    zT_48 = zT_51 == (unsigned char)(73);
    goto z_bb_19;
    z_bb_18:
    zT_48 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_48) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_55 = text.ptr;
    zT_56 = 3;
    zT_57 = zT_55[zT_56];
    zT_54 = zT_57 == (unsigned char)(110);
    goto z_bb_22;
    z_bb_21:
    zT_54 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_54) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_61 = text.ptr;
    zT_62 = 4;
    zT_63 = zT_61[zT_62];
    zT_60 = zT_63 == (unsigned char)(99);
    goto z_bb_25;
    z_bb_24:
    zT_60 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_60) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_67 = text.ptr;
    zT_68 = 5;
    zT_69 = zT_67[zT_68];
    zT_66 = zT_69 == (unsigned char)(108);
    goto z_bb_28;
    z_bb_27:
    zT_66 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_66) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_73 = text.ptr;
    zT_74 = 6;
    zT_75 = zT_73[zT_74];
    zT_72 = zT_75 == (unsigned char)(117);
    goto z_bb_31;
    z_bb_30:
    zT_72 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_72) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_79 = text.ptr;
    zT_80 = 7;
    zT_81 = zT_79[zT_80];
    zT_78 = zT_81 == (unsigned char)(100);
    goto z_bb_34;
    z_bb_33:
    zT_78 = 0;
    goto z_bb_34;
    z_bb_34:
    if (zT_78) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_85 = text.ptr;
    zT_86 = 8;
    zT_87 = zT_85[zT_86];
    zT_84 = zT_87 == (unsigned char)(101);
    goto z_bb_37;
    z_bb_36:
    zT_84 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_84) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_90 = self;
    zT_92 = start;
    zT_96.string_id = string_id;
    zT_93 = zT_96;
    zT_97 = zF_369DD718_lexerMakeToken(zT_90, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_c_include_builtin), zT_92, zT_93);
    return zT_97;
    z_bb_39:
    goto z_bb_13;
}

/* isAlpha */
unsigned char zF_0D29E41B_isAlpha(unsigned char c) {
    unsigned char zT_3;
    unsigned char zT_6;
    unsigned char zT_9;
    unsigned char zT_12;
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(122);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_6 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_6) goto z_bb_11; else goto z_bb_10;
    z_bb_7:
    zT_9 = c <= (unsigned char)(90);
    goto z_bb_9;
    z_bb_8:
    zT_9 = 0;
    goto z_bb_9;
    z_bb_9:
    zT_6 = zT_9;
    goto z_bb_6;
    z_bb_10:
    zT_12 = c == (unsigned char)(95);
    goto z_bb_12;
    z_bb_11:
    zT_12 = 1;
    goto z_bb_12;
    z_bb_12:
    return zT_12;
}

/* isDigit */
unsigned char zF_C95A8EC6_isDigit(unsigned char c) {
    unsigned char zT_3;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(57);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    return zT_3;
}

/* isAlphaNum */
unsigned char zF_97170599_isAlphaNum(unsigned char c) {
    unsigned char zT_1;
    unsigned char zT_2 = 0;
    unsigned char zT_3;
    unsigned char zT_4;
    unsigned char zT_5 = 0;
    zT_1 = c;
    zT_2 = zF_0D29E41B_isAlpha(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = c;
    zT_5 = zF_C95A8EC6_isDigit(zT_4);
    zT_3 = zT_5;
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    return zT_3;
}

/* hexDigitValue */
unsigned char zF_24E4C5BC_hexDigitValue(unsigned char c) {
    unsigned char zT_3;
    unsigned char zT_10;
    int zT_15;
    unsigned char zT_19;
    int zT_24;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = c <= (unsigned char)(57);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(c - (unsigned char)(48));
    z_bb_5:
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_10 = c <= (unsigned char)(102);
    goto z_bb_8;
    z_bb_7:
    zT_10 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_10) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_15 = 10;
    return (unsigned char)((unsigned char)(c - (unsigned char)(97)) + zT_15);
    z_bb_10:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_19 = c <= (unsigned char)(70);
    goto z_bb_13;
    z_bb_12:
    zT_19 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_19) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_24 = 10;
    return (unsigned char)((unsigned char)(c - (unsigned char)(65)) + zT_24);
    z_bb_15:
    return (unsigned char)(255);
}

/* lexerParseHexEscape */
unsigned char zF_3EAE09C6_lexerParseHexEscape(zT_138FFB41_Lexer* self) {
    int zT_2;
    unsigned char zT_3;
    int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_9;
    zT_138FFB41_Lexer* zT_10;
    unsigned char zT_11 = 0;
    unsigned char zT_14;
    zT_138FFB41_Lexer* zT_15;
    unsigned char zT_16 = 0;
    unsigned char zT_17 = 0;
    int zT_18;
    int zT_20;
    unsigned char zT_22;
    zT_138FFB41_Lexer* zT_23;
    unsigned char zT_24 = 0;
    int zT_25;
    unsigned char zT_27;
    int zT_28;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    zT_F85C5DED_DiagnosticCollector* zT_36;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    int zT_44;
    unsigned int zT_48;
    int zT_49;
    unsigned int zT_52;
    unsigned char value;
    unsigned char count;
    unsigned char digit;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hex;
    zT_2 = 0;
    zT_3 = (unsigned char)zT_2;
    value = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned char)zT_5;
    count = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = 2;
    if ((unsigned char)(count < zT_7)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_15 = self;
    zT_16 = zF_6ACB12FA_lexerPeek(zT_15);
    zT_14 = zT_16;
    zT_17 = zF_24E4C5BC_hexDigitValue(zT_14);
    digit = zT_17;
    zT_18 = 255;
    if ((unsigned char)(digit == zT_18)) goto z_bb_8; else goto z_bb_9;
    z_bb_3:
    zT_28 = 0;
    if ((unsigned char)(count == zT_28)) goto z_bb_10; else goto z_bb_11;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_10 = self;
    zT_11 = zF_07BC1EA1_lexerIsAtEnd(zT_10);
    zT_9 = !zT_11;
    goto z_bb_7;
    z_bb_6:
    zT_9 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_9) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    goto z_bb_3;
    z_bb_9:
    zT_20 = 16;
    zT_22 = (unsigned char)(value * zT_20) + digit;
    value = zT_22;
    zT_23 = self;
    zT_24 = zF_7C2FDD01_lexerAdvance(zT_23);
    (void)zT_24;
    zT_25 = 1;
    zT_27 = count + (unsigned char)((unsigned char)zT_25);
    count = zT_27;
    goto z_bb_4;
    z_bb_10:
    zT_31 = "\\x requires at least one hex digit";
    zT_33 = 34;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_hex = zT_32;
    zT_34 = self->count_only;
    if ((unsigned char)(!zT_34)) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return value;
    z_bb_12:
    zT_36 = self->diag;
    zT_44 = 0;
    zT_39 = self->file_id;
    zT_48 = self->pos;
    zT_49 = 2;
    zT_52 = self->pos;
    zT_42 = s_hex;
    (void)zF_C82559AC_diagnosticCollector(zT_36, (unsigned char)((unsigned char)zT_44), (unsigned short)(3), zT_39, (unsigned int)((unsigned int)(unsigned int)(zT_48 - zT_49)), (unsigned int)((unsigned int)zT_52), zT_42);
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
}

/* lexerParseEscapeSequence */
unsigned char zF_7D4EA30A_lexerParseEscapeSeq(zT_138FFB41_Lexer* self) {
    zT_138FFB41_Lexer* zT_1;
    unsigned char zT_2 = 0;
    zT_138FFB41_Lexer* zT_5;
    unsigned char zT_6 = 0;
    zT_138FFB41_Lexer* zT_14;
    unsigned char zT_15 = 0;
    unsigned char zT_16;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_BBAAFAE2_Arr_unsigned_char_2 zT_23;
    int zT_24;
    unsigned char zT_25;
    int zT_26;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_32;
    unsigned int zT_33;
    int zT_36;
    int zT_37;
    unsigned char* zT_38;
    unsigned int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_D3EB6303_StringInterner* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_45;
    zT_F85C5DED_DiagnosticCollector* zT_47;
    int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    int zT_61;
    unsigned int zT_65;
    int zT_66;
    unsigned int zT_69;
    unsigned char c;
    zT_8F083A69_Slice_zT_0B42B2F8_u ue1;
    zT_BBAAFAE2_Arr_unsigned_char_2 ue_char_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u ue3;
    zT_4C214FEE_Arr_zT_8F083A69_Sli ueparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_unesc;
    zT_1 = self;
    zT_2 = zF_07BC1EA1_lexerIsAtEnd(zT_1);
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(92);
    z_bb_2:
    zT_5 = self;
    zT_6 = zF_7C2FDD01_lexerAdvance(zT_5);
    c = zT_6;
switch (c) {
case 110: goto z_bb_3;
case 116: goto z_bb_4;
case 114: goto z_bb_5;
case 92: goto z_bb_6;
case 34: goto z_bb_7;
case 39: goto z_bb_8;
case 48: goto z_bb_9;
case 120: goto z_bb_10;
default: goto z_bb_11;
}
    z_bb_3:
    return (unsigned char)(10);
    z_bb_4:
    return (unsigned char)(9);
    z_bb_5:
    return (unsigned char)(13);
    z_bb_6:
    return (unsigned char)(92);
    z_bb_7:
    return (unsigned char)(34);
    z_bb_8:
    return (unsigned char)(39);
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_14 = self;
    zT_15 = zF_3EAE09C6_lexerParseHexEscape(zT_14);
    return zT_15;
    z_bb_11:
    zT_16 = self->count_only;
    if ((unsigned char)(!zT_16)) goto z_bb_14; else goto z_bb_15;
    return 0;
    z_bb_14:
    zT_19 = "unrecognized escape sequence: '\\";
    zT_21 = 32;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    ue1 = zT_20;
    {
    unsigned int _i = 0;
    while (_i < 2) {
        zT_23[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 2) {
        ue_char_buf[_i] = zT_23[_i];
        _i++;
    }
}
    zT_24 = 0;
    ue_char_buf[zT_24] = c;
    zT_25 = 0;
    zT_26 = 1;
    ue_char_buf[zT_26] = zT_25;
    zT_28 = "'";
    zT_30 = 1;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    ue3 = zT_29;
    zT_33 = 0;
    zT_32[zT_33] = ue1;
    zT_36 = 1;
    zT_37 = 0;
    zT_38 = (unsigned char*)((unsigned char*)ue_char_buf) + zT_37;
    zT_39 = zT_36 - zT_37;
    zT_40.ptr = zT_38;
    zT_40.len = zT_39;
    zT_41 = 1;
    zT_32[zT_41] = zT_40;
    zT_42 = 2;
    zT_32[zT_42] = ue3;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        ueparts[_i] = zT_32[_i];
        _i++;
    }
}
    zT_47 = self->diag;
    zT_44 = zT_47->interner;
    zT_49 = 0;
    zT_50 = ueparts + zT_49;
    zT_45 = zT_50;
    zT_52 = zF_8C4BFF7C_diagnosticBuilderMa(zT_44, zT_45, (unsigned int)(3));
    s_unesc = zT_52;
    zT_53 = self->diag;
    zT_61 = 1;
    zT_56 = self->file_id;
    zT_65 = self->pos;
    zT_66 = 2;
    zT_69 = self->pos;
    zT_59 = s_unesc;
    (void)zF_C82559AC_diagnosticCollector(zT_53, (unsigned char)((unsigned char)zT_61), (unsigned short)(6), zT_56, (unsigned int)((unsigned int)(unsigned int)(zT_65 - zT_66)), (unsigned int)((unsigned int)zT_69), zT_59);
    goto z_bb_15;
    z_bb_15:
    return c;
}

/* isDigitInBase */
unsigned char zF_C5E3A034_isDigitInBase(unsigned char c, unsigned char base) {
    unsigned char zT_4;
    unsigned char zT_9;
    unsigned char zT_14;
    unsigned char zT_19;
    unsigned char zT_22;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_31;
switch (base) {
case 2: goto z_bb_1;
case 8: goto z_bb_2;
case 10: goto z_bb_3;
case 16: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_1:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_8; else goto z_bb_9;
    z_bb_2:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_11; else goto z_bb_12;
    z_bb_3:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_14; else goto z_bb_15;
    z_bb_4:
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_17; else goto z_bb_18;
    z_bb_5:
    return (unsigned char)(0);
    return 0;
    z_bb_8:
    zT_4 = c <= (unsigned char)(49);
    goto z_bb_10;
    z_bb_9:
    zT_4 = 0;
    goto z_bb_10;
    z_bb_10:
    return zT_4;
    z_bb_11:
    zT_9 = c <= (unsigned char)(55);
    goto z_bb_13;
    z_bb_12:
    zT_9 = 0;
    goto z_bb_13;
    z_bb_13:
    return zT_9;
    z_bb_14:
    zT_14 = c <= (unsigned char)(57);
    goto z_bb_16;
    z_bb_15:
    zT_14 = 0;
    goto z_bb_16;
    z_bb_16:
    return zT_14;
    z_bb_17:
    zT_19 = c <= (unsigned char)(57);
    goto z_bb_19;
    z_bb_18:
    zT_19 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_19) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    zT_22 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_22) goto z_bb_27; else goto z_bb_26;
    z_bb_23:
    zT_25 = c <= (unsigned char)(102);
    goto z_bb_25;
    z_bb_24:
    zT_25 = 0;
    goto z_bb_25;
    z_bb_25:
    zT_22 = zT_25;
    goto z_bb_22;
    z_bb_26:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_28 = 1;
    goto z_bb_28;
    z_bb_28:
    return zT_28;
    z_bb_29:
    zT_31 = c <= (unsigned char)(70);
    goto z_bb_31;
    z_bb_30:
    zT_31 = 0;
    goto z_bb_31;
    z_bb_31:
    zT_28 = zT_31;
    goto z_bb_28;
}

/* parseU64 */
zT_79FAE712_u64 zF_8EC79679_parseU64(zT_8F083A69_Slice_zT_0B42B2F8_u text, unsigned char base) {
    int zT_3;
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    int zT_10;
    unsigned char zT_12;
    unsigned char* zT_13;
    int zT_14;
    unsigned char zT_15;
    unsigned char* zT_19;
    int zT_20;
    unsigned char zT_21;
    unsigned char zT_24;
    unsigned char zT_27;
    unsigned char zT_30;
    unsigned char zT_33;
    unsigned char zT_36;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned char* zT_45;
    unsigned char zT_46;
    int zT_47;
    unsigned int zT_49;
    int zT_53;
    zT_79FAE712_u64 zT_54;
    unsigned char zT_56;
    unsigned char zT_59;
    zT_79FAE712_u64 zT_64;
    unsigned char zT_67;
    int zT_72;
    zT_79FAE712_u64 zT_74;
    unsigned char zT_77;
    int zT_82;
    zT_79FAE712_u64 zT_84;
    unsigned char zT_85;
    zT_79FAE712_u64 zT_89;
    zT_79FAE712_u64 zT_92;
    int zT_93;
    zT_79FAE712_u64 zT_95;
    zT_79FAE712_u64 zT_97;
    zT_79FAE712_u64 zT_99;
    zT_79FAE712_u64 zT_103;
    zT_79FAE712_u64 result;
    unsigned int i;
    unsigned char p;
    unsigned char c;
    zT_79FAE712_u64 digit;
    unsigned char found_digit;
    zT_79FAE712_u64 base_u64;
    zT_79FAE712_u64 max_u64;
    zT_79FAE712_u64 max_before_mul;
    zT_79FAE712_u64 after_mul;
    zT_3 = 0;
    zT_4 = (zT_79FAE712_u64)zT_3;
    result = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    i = zT_7;
    zT_9 = text.len;
    zT_10 = 2;
    if ((unsigned char)(zT_9 > (unsigned int)zT_10)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = text.ptr;
    zT_14 = 0;
    zT_15 = zT_13[zT_14];
    zT_12 = zT_15 == (unsigned char)(48);
    goto z_bb_3;
    z_bb_2:
    zT_12 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_12) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_19 = text.ptr;
    zT_20 = 1;
    zT_21 = zT_19[zT_20];
    p = zT_21;
    if ((unsigned char)(p == (unsigned char)(120))) goto z_bb_7; else goto z_bb_6;
    z_bb_5:
    goto z_bb_23;
    z_bb_6:
    zT_24 = p == (unsigned char)(88);
    goto z_bb_8;
    z_bb_7:
    zT_24 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_24) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_27 = p == (unsigned char)(98);
    goto z_bb_11;
    z_bb_10:
    zT_27 = 1;
    goto z_bb_11;
    z_bb_11:
    if (zT_27) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_30 = p == (unsigned char)(66);
    goto z_bb_14;
    z_bb_13:
    zT_30 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_30) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_33 = p == (unsigned char)(111);
    goto z_bb_17;
    z_bb_16:
    zT_33 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_33) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_36 = p == (unsigned char)(79);
    goto z_bb_20;
    z_bb_19:
    zT_36 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_36) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_39 = 2;
    zT_40 = (unsigned int)zT_39;
    i = zT_40;
    goto z_bb_22;
    z_bb_22:
    goto z_bb_5;
    z_bb_23:
    zT_42 = text.len;
    if ((unsigned char)(i < zT_42)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_45 = text.ptr;
    zT_46 = zT_45[i];
    c = zT_46;
    zT_47 = 1;
    zT_49 = i + (unsigned int)((unsigned int)zT_47);
    i = zT_49;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    return result;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    goto z_bb_26;
    z_bb_28:
    zT_53 = 0;
    zT_54 = (zT_79FAE712_u64)zT_53;
    digit = zT_54;
    zT_56 = 1;
    found_digit = zT_56;
    if ((unsigned char)(c >= (unsigned char)(48))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_59 = c <= (unsigned char)(57);
    goto z_bb_31;
    z_bb_30:
    zT_59 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_59) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    zT_64 = (zT_79FAE712_u64)(unsigned char)(c - (unsigned char)(48));
    digit = zT_64;
    goto z_bb_33;
    z_bb_33:
    if ((unsigned char)(!found_digit)) goto z_bb_47; else goto z_bb_48;
    z_bb_34:
    if ((unsigned char)(c >= (unsigned char)(97))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_67 = c <= (unsigned char)(102);
    goto z_bb_37;
    z_bb_36:
    zT_67 = 0;
    goto z_bb_37;
    z_bb_37:
    if (zT_67) goto z_bb_38; else goto z_bb_40;
    z_bb_38:
    zT_72 = 10;
    zT_74 = (zT_79FAE712_u64)(unsigned char)((unsigned char)(c - (unsigned char)(97)) + zT_72);
    digit = zT_74;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_33;
    z_bb_40:
    if ((unsigned char)(c >= (unsigned char)(65))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_77 = c <= (unsigned char)(70);
    goto z_bb_43;
    z_bb_42:
    zT_77 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_77) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_82 = 10;
    zT_84 = (zT_79FAE712_u64)(unsigned char)((unsigned char)(c - (unsigned char)(65)) + zT_82);
    digit = zT_84;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_39;
    z_bb_46:
    zT_85 = 0;
    found_digit = zT_85;
    goto z_bb_45;
    z_bb_47:
    goto z_bb_25;
    z_bb_48:
    zT_89 = (zT_79FAE712_u64)(unsigned int)((unsigned int)base);
    base_u64 = zT_89;
    if ((unsigned char)(digit >= base_u64)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_25;
    z_bb_50:
    zT_92 = 0;
    max_u64 = zT_92;
    zT_93 = 1;
    zT_95 = max_u64 - (zT_79FAE712_u64)((zT_79FAE712_u64)zT_93);
    max_u64 = zT_95;
    zT_97 = max_u64 / base_u64;
    max_before_mul = zT_97;
    if ((unsigned char)(result > max_before_mul)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return max_u64;
    z_bb_52:
    zT_99 = result * base_u64;
    result = zT_99;
    after_mul = result;
    if ((unsigned char)(after_mul > (zT_79FAE712_u64)(max_u64 - digit))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    return max_u64;
    z_bb_54:
    zT_103 = result + digit;
    result = zT_103;
    goto z_bb_26;
}

/* parseF64 */
double zF_37CDE8A4_parseF64(zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    double zT_2;
    int zT_4;
    unsigned int zT_5;
    unsigned char zT_7;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned char zT_23;
    unsigned char* zT_24;
    unsigned char zT_25;
    int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned char* zT_35;
    unsigned char zT_36;
    int zT_37;
    unsigned int zT_39;
    unsigned char zT_44;
    unsigned char zT_47;
    int zT_50;
    unsigned int zT_52;
    unsigned char zT_53;
    unsigned char zT_54 = 0;
    int zT_56;
    unsigned int zT_58;
    int zT_62;
    double zT_66;
    unsigned int zT_68;
    unsigned char zT_70;
    unsigned char* zT_71;
    unsigned char zT_72;
    int zT_75;
    unsigned int zT_77;
    double zT_79;
    unsigned int zT_81;
    unsigned char* zT_84;
    unsigned char zT_85;
    int zT_86;
    unsigned int zT_88;
    unsigned char zT_93;
    int zT_96;
    unsigned int zT_98;
    unsigned char zT_99;
    unsigned char zT_100 = 0;
    int zT_105;
    double zT_108;
    double zT_110;
    unsigned int zT_112;
    unsigned char zT_114;
    unsigned char* zT_115;
    unsigned char zT_116;
    unsigned char zT_119;
    unsigned char* zT_120;
    unsigned char zT_121;
    int zT_124;
    unsigned int zT_126;
    unsigned char zT_128;
    unsigned int zT_130;
    unsigned char zT_132;
    unsigned char* zT_133;
    unsigned char zT_134;
    unsigned char zT_137;
    int zT_138;
    unsigned int zT_140;
    unsigned int zT_142;
    unsigned char zT_144;
    unsigned char* zT_145;
    unsigned char zT_146;
    int zT_149;
    unsigned int zT_151;
    int zT_153;
    int zT_154;
    unsigned int zT_156;
    unsigned char zT_158;
    unsigned char zT_159;
    unsigned char* zT_160;
    unsigned char zT_162 = 0;
    int zT_163;
    unsigned char* zT_165;
    unsigned char zT_166;
    int zT_170;
    int zT_171;
    unsigned int zT_173;
    double zT_175;
    double zT_180;
    unsigned int zT_182;
    double zT_183;
    double zT_184;
    double zT_185;
    double result;
    unsigned int i;
    unsigned char negative;
    unsigned char c;
    int dg;
    double frac_mul;
    int dg2;
    unsigned char exp_neg;
    int exp;
    double power;
    unsigned int _;
    zT_2 = 0;
    result = zT_2;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    zT_7 = 0;
    negative = zT_7;
    zT_9 = text.len;
    if ((unsigned char)(i < zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = text.ptr;
    zT_13 = zT_12[i];
    zT_11 = zT_13 == (unsigned char)(45);
    goto z_bb_3;
    z_bb_2:
    zT_11 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_11) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_16 = 1;
    negative = zT_16;
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_5;
    z_bb_5:
    zT_21 = text.len;
    if ((unsigned char)(i < zT_21)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_24 = text.ptr;
    zT_25 = zT_24[i];
    zT_23 = zT_25 == (unsigned char)(43);
    goto z_bb_8;
    z_bb_7:
    zT_23 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_23) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_28 = 1;
    zT_30 = i + (unsigned int)((unsigned int)zT_28);
    i = zT_30;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_11;
    z_bb_11:
    zT_32 = text.len;
    if ((unsigned char)(i < zT_32)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_35 = text.ptr;
    zT_36 = zT_35[i];
    c = zT_36;
    zT_37 = 1;
    zT_39 = i + (unsigned int)((unsigned int)zT_37);
    i = zT_39;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_68 = text.len;
    if ((unsigned char)(i < zT_68)) goto z_bb_27; else goto z_bb_28;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    if ((unsigned char)(c == (unsigned char)(46))) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_44 = c == (unsigned char)(101);
    goto z_bb_19;
    z_bb_18:
    zT_44 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_44) goto z_bb_21; else goto z_bb_20;
    z_bb_20:
    zT_47 = c == (unsigned char)(69);
    goto z_bb_22;
    z_bb_21:
    zT_47 = 1;
    goto z_bb_22;
    z_bb_22:
    if (zT_47) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_50 = 1;
    zT_52 = i - (unsigned int)((unsigned int)zT_50);
    i = zT_52;
    goto z_bb_13;
    z_bb_24:
    zT_53 = c;
    zT_54 = zF_C95A8EC6_isDigit(zT_53);
    if ((unsigned char)(!zT_54)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_56 = 1;
    zT_58 = i - (unsigned int)((unsigned int)zT_56);
    i = zT_58;
    goto z_bb_13;
    z_bb_26:
    zT_62 = (int)(unsigned char)(c - (unsigned char)(48));
    dg = zT_62;
    zT_66 = (double)(result * (double)(1e+1)) + (double)((double)dg);
    result = zT_66;
    goto z_bb_14;
    z_bb_27:
    zT_71 = text.ptr;
    zT_72 = zT_71[i];
    zT_70 = zT_72 == (unsigned char)(46);
    goto z_bb_29;
    z_bb_28:
    zT_70 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_70) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_75 = 1;
    zT_77 = i + (unsigned int)((unsigned int)zT_75);
    i = zT_77;
    zT_79 = 1.0000000000000001e-1;
    frac_mul = zT_79;
    goto z_bb_32;
    z_bb_31:
    zT_112 = text.len;
    if ((unsigned char)(i < zT_112)) goto z_bb_45; else goto z_bb_46;
    z_bb_32:
    zT_81 = text.len;
    if ((unsigned char)(i < zT_81)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_84 = text.ptr;
    zT_85 = zT_84[i];
    c = zT_85;
    zT_86 = 1;
    zT_88 = i + (unsigned int)((unsigned int)zT_86);
    i = zT_88;
    if ((unsigned char)(c == (unsigned char)(95))) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    goto z_bb_35;
    z_bb_37:
    if ((unsigned char)(c == (unsigned char)(101))) goto z_bb_39; else goto z_bb_38;
    z_bb_38:
    zT_93 = c == (unsigned char)(69);
    goto z_bb_40;
    z_bb_39:
    zT_93 = 1;
    goto z_bb_40;
    z_bb_40:
    if (zT_93) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_96 = 1;
    zT_98 = i - (unsigned int)((unsigned int)zT_96);
    i = zT_98;
    goto z_bb_34;
    z_bb_42:
    zT_99 = c;
    zT_100 = zF_C95A8EC6_isDigit(zT_99);
    if ((unsigned char)(!zT_100)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    goto z_bb_34;
    z_bb_44:
    zT_105 = (int)(unsigned char)(c - (unsigned char)(48));
    dg2 = zT_105;
    zT_108 = result + (double)((double)((double)dg2) * frac_mul);
    result = zT_108;
    zT_110 = frac_mul * (double)(1.0000000000000001e-1);
    frac_mul = zT_110;
    goto z_bb_35;
    z_bb_45:
    zT_115 = text.ptr;
    zT_116 = zT_115[i];
    if ((unsigned char)(zT_116 == (unsigned char)(101))) goto z_bb_49; else goto z_bb_48;
    z_bb_46:
    zT_114 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_114) goto z_bb_51; else goto z_bb_52;
    z_bb_48:
    zT_120 = text.ptr;
    zT_121 = zT_120[i];
    zT_119 = zT_121 == (unsigned char)(69);
    goto z_bb_50;
    z_bb_49:
    zT_119 = 1;
    goto z_bb_50;
    z_bb_50:
    zT_114 = zT_119;
    goto z_bb_47;
    z_bb_51:
    zT_124 = 1;
    zT_126 = i + (unsigned int)((unsigned int)zT_124);
    i = zT_126;
    zT_128 = 0;
    exp_neg = zT_128;
    zT_130 = text.len;
    if ((unsigned char)(i < zT_130)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    if (negative) goto z_bb_77; else goto z_bb_78;
    z_bb_53:
    zT_133 = text.ptr;
    zT_134 = zT_133[i];
    zT_132 = zT_134 == (unsigned char)(45);
    goto z_bb_55;
    z_bb_54:
    zT_132 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_132) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_137 = 1;
    exp_neg = zT_137;
    zT_138 = 1;
    zT_140 = i + (unsigned int)((unsigned int)zT_138);
    i = zT_140;
    goto z_bb_57;
    z_bb_57:
    zT_142 = text.len;
    if ((unsigned char)(i < zT_142)) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_145 = text.ptr;
    zT_146 = zT_145[i];
    zT_144 = zT_146 == (unsigned char)(43);
    goto z_bb_60;
    z_bb_59:
    zT_144 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_144) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_149 = 1;
    zT_151 = i + (unsigned int)((unsigned int)zT_149);
    i = zT_151;
    goto z_bb_62;
    z_bb_62:
    zT_153 = 0;
    zT_154 = (int)zT_153;
    exp = zT_154;
    goto z_bb_63;
    z_bb_63:
    zT_156 = text.len;
    if ((unsigned char)(i < zT_156)) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_163 = 10;
    zT_165 = text.ptr;
    zT_166 = zT_165[i];
    zT_170 = (int)(exp * zT_163) + (int)((int)(unsigned char)(zT_166 - (unsigned char)(48)));
    exp = zT_170;
    zT_171 = 1;
    zT_173 = i + (unsigned int)((unsigned int)zT_171);
    i = zT_173;
    goto z_bb_66;
    z_bb_65:
    zT_175 = 1e+0;
    power = zT_175;
    _ = 0;
    goto z_bb_70;
    z_bb_66:
    goto z_bb_63;
    z_bb_67:
    zT_160 = text.ptr;
    zT_159 = zT_160[i];
    zT_162 = zF_C95A8EC6_isDigit(zT_159);
    zT_158 = zT_162;
    goto z_bb_69;
    z_bb_68:
    zT_158 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_158) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    if ((unsigned char)((unsigned int)_ < (unsigned int)((unsigned int)exp))) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_180 = power * (double)(1e+1);
    power = zT_180;
    goto z_bb_73;
    z_bb_72:
    if (exp_neg) goto z_bb_74; else goto z_bb_76;
    z_bb_73:
    zT_182 = _ + (unsigned int)(1);
    _ = zT_182;
    goto z_bb_70;
    z_bb_74:
    zT_183 = result / power;
    result = zT_183;
    goto z_bb_75;
    z_bb_75:
    goto z_bb_52;
    z_bb_76:
    zT_184 = result * power;
    result = zT_184;
    goto z_bb_75;
    z_bb_77:
    zT_185 = -result;
    result = zT_185;
    goto z_bb_78;
    z_bb_78:
    return result;
}

/* isU64MaxLiteral */
unsigned char zF_6E4D822B_isU64MaxLiteral(zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned int zT_2;
    int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    int zT_9;
    zT_79FAE712_u64 zT_11 = 0;
    zT_79FAE712_u64 zT_12;
    zT_79FAE712_u64 val;
    zT_2 = text.len;
    zT_3 = 2;
    if ((unsigned char)(zT_2 < (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = text;
    zT_9 = 16;
    zT_11 = zF_8EC79679_parseU64(zT_7, (unsigned char)((unsigned char)zT_9));
    val = zT_11;
    zT_12 = 18446744073709551615ULL;
    return (unsigned char)(val == (zT_79FAE712_u64)zT_12);
}

/* assertEqBool */
void zF_F0A50871_assertEqBool(unsigned char actual, unsigned char expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_exp;
    zT_8F083A69_Slice_zT_0B42B2F8_u str_true;
    zT_8F083A69_Slice_zT_0B42B2F8_u str_false;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_got;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((unsigned char)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected ";
    zT_27 = 11;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    s_exp = zT_26;
    zT_28 = s_exp;
    zF_E4B2EF19_stderr_write(zT_28);
    zT_30 = "true";
    zT_32 = 4;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    str_true = zT_31;
    zT_34 = "false";
    zT_36 = 5;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    str_false = zT_35;
    if (expected) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_37 = str_true;
    zF_E4B2EF19_stderr_write(zT_37);
    goto z_bb_4;
    z_bb_4:
    zT_40 = ", got ";
    zT_42 = 6;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    s_got = zT_41;
    zT_43 = s_got;
    zF_E4B2EF19_stderr_write(zT_43);
    if (actual) goto z_bb_6; else goto z_bb_8;
    z_bb_5:
    zT_38 = str_false;
    zF_E4B2EF19_stderr_write(zT_38);
    goto z_bb_4;
    z_bb_6:
    zT_44 = str_true;
    zF_E4B2EF19_stderr_write(zT_44);
    goto z_bb_7;
    z_bb_7:
    zT_47 = "\n";
    zT_49 = 1;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    s_nl = zT_48;
    zT_50 = s_nl;
    zF_E4B2EF19_stderr_write(zT_50);
    goto z_bb_2;
    z_bb_8:
    zT_45 = str_false;
    zF_E4B2EF19_stderr_write(zT_45);
    goto z_bb_7;
}

/* assertEqU32 */
void zF_EFB8936D_assertEqU32(unsigned int actual, unsigned int expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    int zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    int zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41 = {0};
    unsigned char* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    int zT_53;
    unsigned char* zT_54;
    unsigned int zT_55;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    int zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59 = {0};
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_exp;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_got;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    if ((unsigned char)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected ";
    zT_27 = 11;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    s_exp = zT_26;
    zT_28 = s_exp;
    zF_E4B2EF19_stderr_write(zT_28);
    zT_30 = expected;
    zT_35 = 0;
    zT_36 = (unsigned char*)((unsigned char*)fmt_buf) + zT_35;
    zT_37 = (unsigned int)(12) - zT_35;
    zT_38.ptr = zT_36;
    zT_38.len = zT_37;
    zT_31 = zT_38;
    zT_39 = 12;
    zT_41 = zF_2FED9490_formatU32_1(zT_30, zT_31, (unsigned int)((unsigned int)zT_39));
    zT_29 = zT_41;
    zF_E4B2EF19_stderr_write(zT_29);
    zT_43 = ", got ";
    zT_45 = 6;
    zT_44.ptr = zT_43;
    zT_44.len = zT_45;
    s_got = zT_44;
    zT_46 = s_got;
    zF_E4B2EF19_stderr_write(zT_46);
    zT_48 = actual;
    zT_53 = 0;
    zT_54 = (unsigned char*)((unsigned char*)fmt_buf) + zT_53;
    zT_55 = (unsigned int)(12) - zT_53;
    zT_56.ptr = zT_54;
    zT_56.len = zT_55;
    zT_49 = zT_56;
    zT_57 = 12;
    zT_59 = zF_2FED9490_formatU32_1(zT_48, zT_49, (unsigned int)((unsigned int)zT_57));
    zT_47 = zT_59;
    zF_E4B2EF19_stderr_write(zT_47);
    zT_61 = "\n";
    zT_63 = 1;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    s_nl = zT_62;
    zT_64 = s_nl;
    zF_E4B2EF19_stderr_write(zT_64);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* assertEqU8 */
void zF_8856257C_assertEqU8(unsigned char actual, unsigned char expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fail;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_msg;
    if ((unsigned char)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    s_fail = zT_8;
    zT_10 = s_fail;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": expected char\n";
    zT_27 = 16;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    s_msg = zT_26;
    zT_28 = s_msg;
    zF_E4B2EF19_stderr_write(zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* assertEqTokenKind */
void zF_1058D9A8_assertEqTokenKind(zT_EAC3E484_TokenKind actual, zT_EAC3E484_TokenKind expected, unsigned int line) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_5;
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23 = {0};
    unsigned char* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_5826BFC7_Arr_unsigned_char_1 fmt_buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    if ((unsigned char)(actual != expected)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fmt_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = "FAIL line ";
    zT_9 = 10;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    msg1 = zT_8;
    zT_10 = msg1;
    zF_E4B2EF19_stderr_write(zT_10);
    zT_12 = line;
    zT_17 = 0;
    zT_18 = (unsigned char*)((unsigned char*)fmt_buf) + zT_17;
    zT_19 = (unsigned int)(12) - zT_17;
    zT_20.ptr = zT_18;
    zT_20.len = zT_19;
    zT_13 = zT_20;
    zT_21 = 12;
    zT_23 = zF_2FED9490_formatU32_1(zT_12, zT_13, (unsigned int)((unsigned int)zT_21));
    zT_11 = zT_23;
    zF_E4B2EF19_stderr_write(zT_11);
    zT_25 = ": token kind mismatch\n";
    zT_27 = 22;
    zT_26.ptr = zT_25;
    zT_26.len = zT_27;
    msg2 = zT_26;
    zT_28 = msg2;
    zF_E4B2EF19_stderr_write(zT_28);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* formatU32 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_1(unsigned int val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_26;
    unsigned char* zT_27;
    int zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned char* zT_36;
    int zT_38;
    unsigned char* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int idx;
    unsigned int v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((unsigned char)(v == (unsigned int)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_34 = 1;
    zT_35 = idx + zT_34;
    start = zT_35;
    zT_36 = buf.ptr;
    zT_38 = 1;
    zT_40 = zT_36 + start;
    zT_41 = (unsigned int)(buf_len - zT_38) - start;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    return zT_42;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((unsigned char)(v > (unsigned int)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_26 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(v % zT_23));
    zT_27 = buf.ptr;
    zT_27[idx] = zT_26;
    zT_28 = 10;
    zT_29 = v / zT_28;
    v = zT_29;
    zT_30 = 1;
    zT_32 = idx - (unsigned int)((unsigned int)zT_30);
    idx = zT_32;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* lexerRunAllTests */
void zF_C3A6E90A_lexerRunAllTests(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg1;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg2;
    zT_1 = "Running lexer tests...\n";
    zT_3 = 23;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    msg1 = zT_2;
    zT_4 = msg1;
    zF_E4B2EF19_stderr_write(zT_4);
    zF_6492230E_lexerTestHelpers();
    zF_BF88F19A_lexerTestSkipWhites();
    zF_9AA3D1F6_lexerTestOperators();
    zF_4CB82885_lexerTestScanNumber();
    zF_A76AF035_lexerTestScanString();
    zF_13791BA0_lexerTestScanChar();
    zF_B8F07D3E_lexerTestIdentifier();
    zF_1C8729CF_lexerTestBuiltinIde();
    zF_6836167B_lexerTestDiagnostic();
    zF_4B029FD3_runLexerUnitTests();
    zT_6 = "All lexer tests passed.\n";
    zT_8 = 24;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    msg2 = zT_7;
    zT_9 = msg2;
    zF_E4B2EF19_stderr_write(zT_9);
    return;
}

/* lexerTestSanityCheck */
void zF_519E4401_lexerTestSanityChec(void) {
    unsigned char* zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_2;
    unsigned int zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    char* zT_5;
    unsigned int zT_6;
    char* zT_7;
    unsigned int zT_8;
    char* zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_1 = "Running lexer sanity check (should fail)...\n";
    zT_3 = 44;
    zT_2.ptr = zT_1;
    zT_2.len = zT_3;
    msg = zT_2;
    zT_4 = msg;
    zF_E4B2EF19_stderr_write(zT_4);
    zT_5 = "panic: ";
    zT_6 = 7;
    fwrite(zT_5, 1, zT_6, stderr);
    zT_7 = "intentional sanity check failure";
    zT_8 = 32;
    fwrite(zT_7, 1, zT_8, stderr);
    zT_9 = "\n";
    zT_10 = 1;
    fwrite(zT_9, 1, zT_10, stderr);
    pal_trap();
}

/* lexerTestHelpers */
void zF_6492230E_lexerTestHelpers(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    unsigned char zT_46;
    zT_138FFB41_Lexer* zT_49;
    unsigned char zT_51 = 0;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_62;
    int zT_66;
    unsigned int zT_69;
    int zT_73;
    unsigned char zT_76;
    zT_138FFB41_Lexer* zT_79;
    unsigned char zT_81 = 0;
    unsigned char zT_84;
    zT_138FFB41_Lexer* zT_87;
    unsigned char zT_89 = 0;
    unsigned char zT_92;
    zT_138FFB41_Lexer* zT_95;
    int zT_98;
    unsigned char zT_100 = 0;
    unsigned char zT_103;
    zT_138FFB41_Lexer* zT_106;
    unsigned char zT_108 = 0;
    unsigned char zT_111;
    zT_138FFB41_Lexer* zT_114;
    unsigned char zT_116 = 0;
    unsigned char zT_119;
    zT_138FFB41_Lexer* zT_122;
    unsigned char zT_124 = 0;
    unsigned char zT_127;
    zT_138FFB41_Lexer* zT_130;
    unsigned char zT_132 = 0;
    unsigned char zT_135;
    zT_138FFB41_Lexer* zT_138;
    unsigned char zT_140 = 0;
    int zT_141;
    unsigned char zT_144;
    zT_138FFB41_Lexer* zT_147;
    unsigned char zT_149 = 0;
    int zT_150;
    unsigned char* zT_154;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_155;
    unsigned int zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    zT_D3EB6303_StringInterner* zT_160;
    zT_F85C5DED_DiagnosticCollector* zT_161;
    zT_3E40CD83_Sand* zT_162;
    int zT_163;
    zT_138FFB41_Lexer zT_168 = {0};
    unsigned char zT_169;
    zT_138FFB41_Lexer* zT_172;
    unsigned char zT_176 = 0;
    unsigned char zT_179;
    zT_138FFB41_Lexer* zT_182;
    unsigned char zT_186 = 0;
    unsigned char zT_189;
    zT_138FFB41_Lexer* zT_192;
    unsigned char zT_196 = 0;
    unsigned char* zT_200;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_201;
    unsigned int zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_204;
    zT_D3EB6303_StringInterner* zT_206;
    zT_F85C5DED_DiagnosticCollector* zT_207;
    zT_3E40CD83_Sand* zT_208;
    int zT_209;
    zT_138FFB41_Lexer zT_214 = {0};
    zT_138FFB41_Lexer* zT_215;
    unsigned char zT_217 = 0;
    unsigned int zT_218;
    int zT_222;
    unsigned int zT_225;
    int zT_229;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u test_src;
    zT_138FFB41_Lexer lexer;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ab;
    zT_138FFB41_Lexer lexer2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_nl;
    zT_138FFB41_Lexer lexer3;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "abc";
    zT_33 = 3;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    test_src = zT_32;
    zT_35 = test_src;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    lexer = zT_45;
    zT_49 = &lexer;
    zT_51 = zF_07BC1EA1_lexerIsAtEnd(zT_49);
    zT_46 = zT_51;
    zF_F0A50871_assertEqBool(zT_46, (unsigned char)(0), (unsigned int)(0));
    zT_57 = lexer.pos;
    zT_59 = 0;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_57), (unsigned int)((unsigned int)zT_59), (unsigned int)(0));
    zT_62 = lexer.line;
    zT_66 = 1;
    zF_EFB8936D_assertEqU32(zT_62, (unsigned int)((unsigned int)zT_66), (unsigned int)(0));
    zT_69 = lexer.col;
    zT_73 = 1;
    zF_EFB8936D_assertEqU32(zT_69, (unsigned int)((unsigned int)zT_73), (unsigned int)(0));
    zT_79 = &lexer;
    zT_81 = zF_7C2FDD01_lexerAdvance(zT_79);
    zT_76 = zT_81;
    zF_8856257C_assertEqU8(zT_76, (unsigned char)(97), (unsigned int)(0));
    zT_87 = &lexer;
    zT_89 = zF_6ACB12FA_lexerPeek(zT_87);
    zT_84 = zT_89;
    zF_8856257C_assertEqU8(zT_84, (unsigned char)(98), (unsigned int)(0));
    zT_95 = &lexer;
    zT_98 = 1;
    zT_100 = zF_D1AE715C_lexerPeekN(zT_95, (unsigned int)((unsigned int)zT_98));
    zT_92 = zT_100;
    zF_8856257C_assertEqU8(zT_92, (unsigned char)(99), (unsigned int)(0));
    zT_106 = &lexer;
    zT_108 = zF_07BC1EA1_lexerIsAtEnd(zT_106);
    zT_103 = zT_108;
    zF_F0A50871_assertEqBool(zT_103, (unsigned char)(0), (unsigned int)(0));
    zT_114 = &lexer;
    zT_116 = zF_7C2FDD01_lexerAdvance(zT_114);
    zT_111 = zT_116;
    zF_8856257C_assertEqU8(zT_111, (unsigned char)(98), (unsigned int)(0));
    zT_122 = &lexer;
    zT_124 = zF_7C2FDD01_lexerAdvance(zT_122);
    zT_119 = zT_124;
    zF_8856257C_assertEqU8(zT_119, (unsigned char)(99), (unsigned int)(0));
    zT_130 = &lexer;
    zT_132 = zF_07BC1EA1_lexerIsAtEnd(zT_130);
    zT_127 = zT_132;
    zF_F0A50871_assertEqBool(zT_127, (unsigned char)(1), (unsigned int)(0));
    zT_138 = &lexer;
    zT_140 = zF_7C2FDD01_lexerAdvance(zT_138);
    zT_135 = zT_140;
    zT_141 = 0;
    zF_8856257C_assertEqU8(zT_135, (unsigned char)((unsigned char)zT_141), (unsigned int)(0));
    zT_147 = &lexer;
    zT_149 = zF_6ACB12FA_lexerPeek(zT_147);
    zT_144 = zT_149;
    zT_150 = 0;
    zF_8856257C_assertEqU8(zT_144, (unsigned char)((unsigned char)zT_150), (unsigned int)(0));
    zT_154 = "ab";
    zT_156 = 2;
    zT_155.ptr = zT_154;
    zT_155.len = zT_156;
    s_ab = zT_155;
    zT_158 = s_ab;
    zT_163 = 0;
    zT_160 = &interner;
    zT_161 = &diag;
    zT_162 = &sand;
    zT_168 = zF_151E643F_lexerInit(zT_158, (unsigned int)((unsigned int)zT_163), zT_160, zT_161, zT_162);
    lexer2 = zT_168;
    zT_172 = &lexer2;
    zT_176 = zF_8A07967A_lexerMatch(zT_172, (unsigned char)(97));
    zT_169 = zT_176;
    zF_F0A50871_assertEqBool(zT_169, (unsigned char)(1), (unsigned int)(0));
    zT_182 = &lexer2;
    zT_186 = zF_8A07967A_lexerMatch(zT_182, (unsigned char)(120));
    zT_179 = zT_186;
    zF_F0A50871_assertEqBool(zT_179, (unsigned char)(0), (unsigned int)(0));
    zT_192 = &lexer2;
    zT_196 = zF_8A07967A_lexerMatch(zT_192, (unsigned char)(98));
    zT_189 = zT_196;
    zF_F0A50871_assertEqBool(zT_189, (unsigned char)(1), (unsigned int)(0));
    zT_200 = "\n";
    zT_202 = 1;
    zT_201.ptr = zT_200;
    zT_201.len = zT_202;
    s_nl = zT_201;
    zT_204 = s_nl;
    zT_209 = 0;
    zT_206 = &interner;
    zT_207 = &diag;
    zT_208 = &sand;
    zT_214 = zF_151E643F_lexerInit(zT_204, (unsigned int)((unsigned int)zT_209), zT_206, zT_207, zT_208);
    lexer3 = zT_214;
    zT_215 = &lexer3;
    zT_217 = zF_7C2FDD01_lexerAdvance(zT_215);
    (void)zT_217;
    zT_218 = lexer3.line;
    zT_222 = 2;
    zF_EFB8936D_assertEqU32(zT_218, (unsigned int)((unsigned int)zT_222), (unsigned int)(0));
    zT_225 = lexer3.col;
    zT_229 = 1;
    zF_EFB8936D_assertEqU32(zT_225, (unsigned int)((unsigned int)zT_229), (unsigned int)(0));
    return;
}

/* lexerTestSkipWhitespaceAndComments */
void zF_BF88F19A_lexerTestSkipWhites(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_46;
    unsigned char zT_48;
    zT_138FFB41_Lexer* zT_51;
    unsigned char zT_53 = 0;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_spaces;
    zT_138FFB41_Lexer lexer;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "  \t  abc";
    zT_33 = 8;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_spaces = zT_32;
    zT_35 = s_spaces;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    lexer = zT_45;
    zT_46 = &lexer;
    zF_F7949B41_lexerSkipWSC(zT_46);
    zT_51 = &lexer;
    zT_53 = zF_6ACB12FA_lexerPeek(zT_51);
    zT_48 = zT_53;
    zF_8856257C_assertEqU8(zT_48, (unsigned char)(97), (unsigned int)(0));
    return;
}

/* lexerTestOperators */
void zF_9AA3D1F6_lexerTestOperators(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_EAC3E484_TokenKind zT_46;
    zT_138FFB41_Lexer* zT_49;
    zT_3A355BD2_Token zT_51 = {0};
    zT_EAC3E484_TokenKind zT_56;
    zT_138FFB41_Lexer* zT_59;
    zT_3A355BD2_Token zT_61 = {0};
    zT_EAC3E484_TokenKind zT_66;
    zT_138FFB41_Lexer* zT_69;
    zT_3A355BD2_Token zT_71 = {0};
    zT_EAC3E484_TokenKind zT_76;
    zT_138FFB41_Lexer* zT_79;
    zT_3A355BD2_Token zT_81 = {0};
    zT_EAC3E484_TokenKind zT_86;
    zT_138FFB41_Lexer* zT_89;
    zT_3A355BD2_Token zT_91 = {0};
    zT_EAC3E484_TokenKind zT_96;
    zT_138FFB41_Lexer* zT_99;
    zT_3A355BD2_Token zT_101 = {0};
    zT_EAC3E484_TokenKind zT_106;
    zT_138FFB41_Lexer* zT_109;
    zT_3A355BD2_Token zT_111 = {0};
    unsigned char* zT_117;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_118;
    unsigned int zT_119;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    zT_D3EB6303_StringInterner* zT_123;
    zT_F85C5DED_DiagnosticCollector* zT_124;
    zT_3E40CD83_Sand* zT_125;
    int zT_126;
    zT_138FFB41_Lexer zT_131 = {0};
    zT_EAC3E484_TokenKind zT_132;
    zT_138FFB41_Lexer* zT_135;
    zT_3A355BD2_Token zT_137 = {0};
    zT_EAC3E484_TokenKind zT_142;
    zT_138FFB41_Lexer* zT_145;
    zT_3A355BD2_Token zT_147 = {0};
    zT_EAC3E484_TokenKind zT_152;
    zT_138FFB41_Lexer* zT_155;
    zT_3A355BD2_Token zT_157 = {0};
    zT_EAC3E484_TokenKind zT_162;
    zT_138FFB41_Lexer* zT_165;
    zT_3A355BD2_Token zT_167 = {0};
    zT_EAC3E484_TokenKind zT_172;
    zT_138FFB41_Lexer* zT_175;
    zT_3A355BD2_Token zT_177 = {0};
    zT_EAC3E484_TokenKind zT_182;
    zT_138FFB41_Lexer* zT_185;
    zT_3A355BD2_Token zT_187 = {0};
    zT_EAC3E484_TokenKind zT_192;
    zT_138FFB41_Lexer* zT_195;
    zT_3A355BD2_Token zT_197 = {0};
    zT_EAC3E484_TokenKind zT_202;
    zT_138FFB41_Lexer* zT_205;
    zT_3A355BD2_Token zT_207 = {0};
    zT_EAC3E484_TokenKind zT_212;
    zT_138FFB41_Lexer* zT_215;
    zT_3A355BD2_Token zT_217 = {0};
    zT_EAC3E484_TokenKind zT_222;
    zT_138FFB41_Lexer* zT_225;
    zT_3A355BD2_Token zT_227 = {0};
    zT_EAC3E484_TokenKind zT_232;
    zT_138FFB41_Lexer* zT_235;
    zT_3A355BD2_Token zT_237 = {0};
    zT_EAC3E484_TokenKind zT_242;
    zT_138FFB41_Lexer* zT_245;
    zT_3A355BD2_Token zT_247 = {0};
    zT_EAC3E484_TokenKind zT_252;
    zT_138FFB41_Lexer* zT_255;
    zT_3A355BD2_Token zT_257 = {0};
    zT_EAC3E484_TokenKind zT_262;
    zT_138FFB41_Lexer* zT_265;
    zT_3A355BD2_Token zT_267 = {0};
    unsigned char* zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    zT_D3EB6303_StringInterner* zT_279;
    zT_F85C5DED_DiagnosticCollector* zT_280;
    zT_3E40CD83_Sand* zT_281;
    int zT_282;
    zT_138FFB41_Lexer zT_287 = {0};
    zT_EAC3E484_TokenKind zT_288;
    zT_138FFB41_Lexer* zT_291;
    zT_3A355BD2_Token zT_293 = {0};
    zT_EAC3E484_TokenKind zT_298;
    zT_138FFB41_Lexer* zT_301;
    zT_3A355BD2_Token zT_303 = {0};
    zT_EAC3E484_TokenKind zT_308;
    zT_138FFB41_Lexer* zT_311;
    zT_3A355BD2_Token zT_313 = {0};
    zT_EAC3E484_TokenKind zT_318;
    zT_138FFB41_Lexer* zT_321;
    zT_3A355BD2_Token zT_323 = {0};
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_parens;
    zT_138FFB41_Lexer l1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ops;
    zT_138FFB41_Lexer l2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_compound;
    zT_138FFB41_Lexer l3;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "()[]{}";
    zT_33 = 6;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_parens = zT_32;
    zT_35 = s_parens;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_49 = &l1;
    zT_51 = zF_B976BEC9_lexerNextToken(zT_49);
    zT_46 = zT_51.kind;
    zF_1058D9A8_assertEqTokenKind(zT_46, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lparen), (unsigned int)(0));
    zT_59 = &l1;
    zT_61 = zF_B976BEC9_lexerNextToken(zT_59);
    zT_56 = zT_61.kind;
    zF_1058D9A8_assertEqTokenKind(zT_56, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rparen), (unsigned int)(0));
    zT_69 = &l1;
    zT_71 = zF_B976BEC9_lexerNextToken(zT_69);
    zT_66 = zT_71.kind;
    zF_1058D9A8_assertEqTokenKind(zT_66, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbracket), (unsigned int)(0));
    zT_79 = &l1;
    zT_81 = zF_B976BEC9_lexerNextToken(zT_79);
    zT_76 = zT_81.kind;
    zF_1058D9A8_assertEqTokenKind(zT_76, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbracket), (unsigned int)(0));
    zT_89 = &l1;
    zT_91 = zF_B976BEC9_lexerNextToken(zT_89);
    zT_86 = zT_91.kind;
    zF_1058D9A8_assertEqTokenKind(zT_86, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_lbrace), (unsigned int)(0));
    zT_99 = &l1;
    zT_101 = zF_B976BEC9_lexerNextToken(zT_99);
    zT_96 = zT_101.kind;
    zF_1058D9A8_assertEqTokenKind(zT_96, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_rbrace), (unsigned int)(0));
    zT_109 = &l1;
    zT_111 = zF_B976BEC9_lexerNextToken(zT_109);
    zT_106 = zT_111.kind;
    zF_1058D9A8_assertEqTokenKind(zT_106, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_eof), (unsigned int)(0));
    zT_117 = "+-*/%&|^~!?;:,";
    zT_119 = 14;
    zT_118.ptr = zT_117;
    zT_118.len = zT_119;
    s_ops = zT_118;
    zT_121 = s_ops;
    zT_126 = 0;
    zT_123 = &interner;
    zT_124 = &diag;
    zT_125 = &sand;
    zT_131 = zF_151E643F_lexerInit(zT_121, (unsigned int)((unsigned int)zT_126), zT_123, zT_124, zT_125);
    l2 = zT_131;
    zT_135 = &l2;
    zT_137 = zF_B976BEC9_lexerNextToken(zT_135);
    zT_132 = zT_137.kind;
    zF_1058D9A8_assertEqTokenKind(zT_132, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_plus), (unsigned int)(0));
    zT_145 = &l2;
    zT_147 = zF_B976BEC9_lexerNextToken(zT_145);
    zT_142 = zT_147.kind;
    zF_1058D9A8_assertEqTokenKind(zT_142, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_minus), (unsigned int)(0));
    zT_155 = &l2;
    zT_157 = zF_B976BEC9_lexerNextToken(zT_155);
    zT_152 = zT_157.kind;
    zF_1058D9A8_assertEqTokenKind(zT_152, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_star), (unsigned int)(0));
    zT_165 = &l2;
    zT_167 = zF_B976BEC9_lexerNextToken(zT_165);
    zT_162 = zT_167.kind;
    zF_1058D9A8_assertEqTokenKind(zT_162, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_slash), (unsigned int)(0));
    zT_175 = &l2;
    zT_177 = zF_B976BEC9_lexerNextToken(zT_175);
    zT_172 = zT_177.kind;
    zF_1058D9A8_assertEqTokenKind(zT_172, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_percent), (unsigned int)(0));
    zT_185 = &l2;
    zT_187 = zF_B976BEC9_lexerNextToken(zT_185);
    zT_182 = zT_187.kind;
    zF_1058D9A8_assertEqTokenKind(zT_182, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_ampersand), (unsigned int)(0));
    zT_195 = &l2;
    zT_197 = zF_B976BEC9_lexerNextToken(zT_195);
    zT_192 = zT_197.kind;
    zF_1058D9A8_assertEqTokenKind(zT_192, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_pipe), (unsigned int)(0));
    zT_205 = &l2;
    zT_207 = zF_B976BEC9_lexerNextToken(zT_205);
    zT_202 = zT_207.kind;
    zF_1058D9A8_assertEqTokenKind(zT_202, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_caret), (unsigned int)(0));
    zT_215 = &l2;
    zT_217 = zF_B976BEC9_lexerNextToken(zT_215);
    zT_212 = zT_217.kind;
    zF_1058D9A8_assertEqTokenKind(zT_212, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_tilde), (unsigned int)(0));
    zT_225 = &l2;
    zT_227 = zF_B976BEC9_lexerNextToken(zT_225);
    zT_222 = zT_227.kind;
    zF_1058D9A8_assertEqTokenKind(zT_222, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_bang), (unsigned int)(0));
    zT_235 = &l2;
    zT_237 = zF_B976BEC9_lexerNextToken(zT_235);
    zT_232 = zT_237.kind;
    zF_1058D9A8_assertEqTokenKind(zT_232, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_question_mark), (unsigned int)(0));
    zT_245 = &l2;
    zT_247 = zF_B976BEC9_lexerNextToken(zT_245);
    zT_242 = zT_247.kind;
    zF_1058D9A8_assertEqTokenKind(zT_242, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_semicolon), (unsigned int)(0));
    zT_255 = &l2;
    zT_257 = zF_B976BEC9_lexerNextToken(zT_255);
    zT_252 = zT_257.kind;
    zF_1058D9A8_assertEqTokenKind(zT_252, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_colon), (unsigned int)(0));
    zT_265 = &l2;
    zT_267 = zF_B976BEC9_lexerNextToken(zT_265);
    zT_262 = zT_267.kind;
    zF_1058D9A8_assertEqTokenKind(zT_262, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_comma), (unsigned int)(0));
    zT_273 = ".. ... .{ .* == => != <= >= << >> += -= *= /= %= &= |= ^= <<= >>=";
    zT_275 = 65;
    zT_274.ptr = zT_273;
    zT_274.len = zT_275;
    s_compound = zT_274;
    zT_277 = s_compound;
    zT_282 = 0;
    zT_279 = &interner;
    zT_280 = &diag;
    zT_281 = &sand;
    zT_287 = zF_151E643F_lexerInit(zT_277, (unsigned int)((unsigned int)zT_282), zT_279, zT_280, zT_281);
    l3 = zT_287;
    zT_291 = &l3;
    zT_293 = zF_B976BEC9_lexerNextToken(zT_291);
    zT_288 = zT_293.kind;
    zF_1058D9A8_assertEqTokenKind(zT_288, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot), (unsigned int)(0));
    zT_301 = &l3;
    zT_303 = zF_B976BEC9_lexerNextToken(zT_301);
    zT_298 = zT_303.kind;
    zF_1058D9A8_assertEqTokenKind(zT_298, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_dot_dot), (unsigned int)(0));
    zT_311 = &l3;
    zT_313 = zF_B976BEC9_lexerNextToken(zT_311);
    zT_308 = zT_313.kind;
    zF_1058D9A8_assertEqTokenKind(zT_308, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_lbrace), (unsigned int)(0));
    zT_321 = &l3;
    zT_323 = zF_B976BEC9_lexerNextToken(zT_321);
    zT_318 = zT_323.kind;
    zF_1058D9A8_assertEqTokenKind(zT_318, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_dot_star), (unsigned int)(0));
    return;
}

/* lexerTestScanNumber */
void zF_4CB82885_lexerTestScanNumber(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned int zT_60;
    int zT_62;
    unsigned short zT_68;
    int zT_70;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_D3EB6303_StringInterner* zT_80;
    zT_F85C5DED_DiagnosticCollector* zT_81;
    zT_3E40CD83_Sand* zT_82;
    int zT_83;
    zT_138FFB41_Lexer zT_88 = {0};
    zT_138FFB41_Lexer* zT_90;
    zT_3A355BD2_Token zT_92 = {0};
    zT_EAC3E484_TokenKind zT_93;
    unsigned char* zT_101;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_102;
    unsigned int zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_105;
    zT_D3EB6303_StringInterner* zT_107;
    zT_F85C5DED_DiagnosticCollector* zT_108;
    zT_3E40CD83_Sand* zT_109;
    int zT_110;
    zT_138FFB41_Lexer zT_115 = {0};
    zT_138FFB41_Lexer* zT_117;
    zT_3A355BD2_Token zT_119 = {0};
    zT_EAC3E484_TokenKind zT_120;
    unsigned char* zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    unsigned int zT_130;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_132;
    zT_D3EB6303_StringInterner* zT_134;
    zT_F85C5DED_DiagnosticCollector* zT_135;
    zT_3E40CD83_Sand* zT_136;
    int zT_137;
    zT_138FFB41_Lexer zT_142 = {0};
    zT_138FFB41_Lexer* zT_144;
    zT_3A355BD2_Token zT_146 = {0};
    zT_EAC3E484_TokenKind zT_147;
    unsigned char* zT_155;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_156;
    unsigned int zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    zT_D3EB6303_StringInterner* zT_161;
    zT_F85C5DED_DiagnosticCollector* zT_162;
    zT_3E40CD83_Sand* zT_163;
    int zT_164;
    zT_138FFB41_Lexer zT_169 = {0};
    zT_138FFB41_Lexer* zT_171;
    zT_3A355BD2_Token zT_173 = {0};
    zT_EAC3E484_TokenKind zT_174;
    unsigned char* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_183;
    unsigned int zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    zT_D3EB6303_StringInterner* zT_188;
    zT_F85C5DED_DiagnosticCollector* zT_189;
    zT_3E40CD83_Sand* zT_190;
    int zT_191;
    zT_138FFB41_Lexer zT_196 = {0};
    zT_138FFB41_Lexer* zT_198;
    zT_3A355BD2_Token zT_200 = {0};
    zT_EAC3E484_TokenKind zT_201;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_dec;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hex;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bin;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_oct;
    zT_138FFB41_Lexer l4;
    zT_3A355BD2_Token t4;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_float;
    zT_138FFB41_Lexer l5;
    zT_3A355BD2_Token t5;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sci;
    zT_138FFB41_Lexer l6;
    zT_3A355BD2_Token t6;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "42";
    zT_33 = 2;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_dec = zT_32;
    zT_35 = s_dec;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_60 = t1.span_start;
    zT_62 = 0;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_60), (unsigned int)((unsigned int)zT_62), (unsigned int)(0));
    zT_68 = t1.span_len;
    zT_70 = 2;
    zF_EFB8936D_assertEqU32((unsigned int)((unsigned int)zT_68), (unsigned int)((unsigned int)zT_70), (unsigned int)(0));
    zT_74 = "0xFF";
    zT_76 = 4;
    zT_75.ptr = zT_74;
    zT_75.len = zT_76;
    s_hex = zT_75;
    zT_78 = s_hex;
    zT_83 = 0;
    zT_80 = &interner;
    zT_81 = &diag;
    zT_82 = &sand;
    zT_88 = zF_151E643F_lexerInit(zT_78, (unsigned int)((unsigned int)zT_83), zT_80, zT_81, zT_82);
    l2 = zT_88;
    zT_90 = &l2;
    zT_92 = zF_B976BEC9_lexerNextToken(zT_90);
    t2 = zT_92;
    zT_93 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_93, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_101 = "0b1010";
    zT_103 = 6;
    zT_102.ptr = zT_101;
    zT_102.len = zT_103;
    s_bin = zT_102;
    zT_105 = s_bin;
    zT_110 = 0;
    zT_107 = &interner;
    zT_108 = &diag;
    zT_109 = &sand;
    zT_115 = zF_151E643F_lexerInit(zT_105, (unsigned int)((unsigned int)zT_110), zT_107, zT_108, zT_109);
    l3 = zT_115;
    zT_117 = &l3;
    zT_119 = zF_B976BEC9_lexerNextToken(zT_117);
    t3 = zT_119;
    zT_120 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_120, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_128 = "0o77";
    zT_130 = 4;
    zT_129.ptr = zT_128;
    zT_129.len = zT_130;
    s_oct = zT_129;
    zT_132 = s_oct;
    zT_137 = 0;
    zT_134 = &interner;
    zT_135 = &diag;
    zT_136 = &sand;
    zT_142 = zF_151E643F_lexerInit(zT_132, (unsigned int)((unsigned int)zT_137), zT_134, zT_135, zT_136);
    l4 = zT_142;
    zT_144 = &l4;
    zT_146 = zF_B976BEC9_lexerNextToken(zT_144);
    t4 = zT_146;
    zT_147 = t4.kind;
    zF_1058D9A8_assertEqTokenKind(zT_147, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_integer_literal), (unsigned int)(0));
    zT_155 = "3.14";
    zT_157 = 4;
    zT_156.ptr = zT_155;
    zT_156.len = zT_157;
    s_float = zT_156;
    zT_159 = s_float;
    zT_164 = 0;
    zT_161 = &interner;
    zT_162 = &diag;
    zT_163 = &sand;
    zT_169 = zF_151E643F_lexerInit(zT_159, (unsigned int)((unsigned int)zT_164), zT_161, zT_162, zT_163);
    l5 = zT_169;
    zT_171 = &l5;
    zT_173 = zF_B976BEC9_lexerNextToken(zT_171);
    t5 = zT_173;
    zT_174 = t5.kind;
    zF_1058D9A8_assertEqTokenKind(zT_174, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), (unsigned int)(0));
    zT_182 = "1.5e10";
    zT_184 = 6;
    zT_183.ptr = zT_182;
    zT_183.len = zT_184;
    s_sci = zT_183;
    zT_186 = s_sci;
    zT_191 = 0;
    zT_188 = &interner;
    zT_189 = &diag;
    zT_190 = &sand;
    zT_196 = zF_151E643F_lexerInit(zT_186, (unsigned int)((unsigned int)zT_191), zT_188, zT_189, zT_190);
    l6 = zT_196;
    zT_198 = &l6;
    zT_200 = zF_B976BEC9_lexerNextToken(zT_198);
    t6 = zT_200;
    zT_201 = t6.kind;
    zF_1058D9A8_assertEqTokenKind(zT_201, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_float_literal), (unsigned int)(0));
    return;
}

/* lexerTestScanString */
void zF_A76AF035_lexerTestScanString(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72 = {0};
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76 = {0};
    zT_EAC3E484_TokenKind zT_77;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_D3EB6303_StringInterner* zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    zT_3E40CD83_Sand* zT_93;
    int zT_94;
    zT_138FFB41_Lexer zT_99 = {0};
    zT_138FFB41_Lexer* zT_101;
    zT_3A355BD2_Token zT_103 = {0};
    zT_EAC3E484_TokenKind zT_104;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_hello;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_esc;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_unterm;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "\"hello\"";
    zT_33 = 7;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_hello = zT_32;
    zT_35 = s_hello;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal), (unsigned int)(0));
    zT_58 = "\"hello\\nworld\"";
    zT_60 = 14;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_esc = zT_59;
    zT_62 = s_esc;
    zT_67 = 0;
    zT_64 = &interner;
    zT_65 = &diag;
    zT_66 = &sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = &l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_string_literal), (unsigned int)(0));
    zT_85 = "\"unterminated";
    zT_87 = 13;
    zT_86.ptr = zT_85;
    zT_86.len = zT_87;
    s_unterm = zT_86;
    zT_89 = s_unterm;
    zT_94 = 0;
    zT_91 = &interner;
    zT_92 = &diag;
    zT_93 = &sand;
    zT_99 = zF_151E643F_lexerInit(zT_89, (unsigned int)((unsigned int)zT_94), zT_91, zT_92, zT_93);
    l3 = zT_99;
    zT_101 = &l3;
    zT_103 = zF_B976BEC9_lexerNextToken(zT_101);
    t3 = zT_103;
    zT_104 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_104, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* lexerTestScanChar */
void zF_13791BA0_lexerTestScanChar(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72 = {0};
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76 = {0};
    zT_EAC3E484_TokenKind zT_77;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_D3EB6303_StringInterner* zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    zT_3E40CD83_Sand* zT_93;
    int zT_94;
    zT_138FFB41_Lexer zT_99 = {0};
    zT_138FFB41_Lexer* zT_101;
    zT_3A355BD2_Token zT_103 = {0};
    zT_EAC3E484_TokenKind zT_104;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_char;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_cesc;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_cempty;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "'a'";
    zT_33 = 3;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_char = zT_32;
    zT_35 = s_char;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    zT_58 = "'\\n'";
    zT_60 = 4;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_cesc = zT_59;
    zT_62 = s_cesc;
    zT_67 = 0;
    zT_64 = &interner;
    zT_65 = &diag;
    zT_66 = &sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = &l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    zT_85 = "''";
    zT_87 = 2;
    zT_86.ptr = zT_85;
    zT_86.len = zT_87;
    s_cempty = zT_86;
    zT_89 = s_cempty;
    zT_94 = 0;
    zT_91 = &interner;
    zT_92 = &diag;
    zT_93 = &sand;
    zT_99 = zF_151E643F_lexerInit(zT_89, (unsigned int)((unsigned int)zT_94), zT_91, zT_92, zT_93);
    l3 = zT_99;
    zT_101 = &l3;
    zT_103 = zF_B976BEC9_lexerNextToken(zT_101);
    t3 = zT_103;
    zT_104 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_104, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_char_literal), (unsigned int)(0));
    return;
}

/* lexerTestIdentifierKeywords */
void zF_B8F07D3E_lexerTestIdentifier(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72 = {0};
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76 = {0};
    zT_EAC3E484_TokenKind zT_77;
    unsigned char* zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    zT_D3EB6303_StringInterner* zT_91;
    zT_F85C5DED_DiagnosticCollector* zT_92;
    zT_3E40CD83_Sand* zT_93;
    int zT_94;
    zT_138FFB41_Lexer zT_99 = {0};
    zT_138FFB41_Lexer* zT_101;
    zT_3A355BD2_Token zT_103 = {0};
    zT_EAC3E484_TokenKind zT_104;
    unsigned char* zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_116;
    zT_D3EB6303_StringInterner* zT_118;
    zT_F85C5DED_DiagnosticCollector* zT_119;
    zT_3E40CD83_Sand* zT_120;
    int zT_121;
    zT_138FFB41_Lexer zT_126 = {0};
    zT_138FFB41_Lexer* zT_128;
    zT_3A355BD2_Token zT_130 = {0};
    zT_EAC3E484_TokenKind zT_131;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_under;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_ident;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_kw_const;
    zT_138FFB41_Lexer l3;
    zT_3A355BD2_Token t3;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_kw_fn;
    zT_138FFB41_Lexer l4;
    zT_3A355BD2_Token t4;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "_";
    zT_33 = 1;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_under = zT_32;
    zT_35 = s_under;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_underscore), (unsigned int)(0));
    zT_58 = "myVar";
    zT_60 = 5;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_ident = zT_59;
    zT_62 = s_ident;
    zT_67 = 0;
    zT_64 = &interner;
    zT_65 = &diag;
    zT_66 = &sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = &l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_identifier), (unsigned int)(0));
    zT_85 = "const";
    zT_87 = 5;
    zT_86.ptr = zT_85;
    zT_86.len = zT_87;
    s_kw_const = zT_86;
    zT_89 = s_kw_const;
    zT_94 = 0;
    zT_91 = &interner;
    zT_92 = &diag;
    zT_93 = &sand;
    zT_99 = zF_151E643F_lexerInit(zT_89, (unsigned int)((unsigned int)zT_94), zT_91, zT_92, zT_93);
    l3 = zT_99;
    zT_101 = &l3;
    zT_103 = zF_B976BEC9_lexerNextToken(zT_101);
    t3 = zT_103;
    zT_104 = t3.kind;
    zF_1058D9A8_assertEqTokenKind(zT_104, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_const), (unsigned int)(0));
    zT_112 = "fn";
    zT_114 = 2;
    zT_113.ptr = zT_112;
    zT_113.len = zT_114;
    s_kw_fn = zT_113;
    zT_116 = s_kw_fn;
    zT_121 = 0;
    zT_118 = &interner;
    zT_119 = &diag;
    zT_120 = &sand;
    zT_126 = zF_151E643F_lexerInit(zT_116, (unsigned int)((unsigned int)zT_121), zT_118, zT_119, zT_120);
    l4 = zT_126;
    zT_128 = &l4;
    zT_130 = zF_B976BEC9_lexerNextToken(zT_128);
    t4 = zT_130;
    zT_131 = t4.kind;
    zF_1058D9A8_assertEqTokenKind(zT_131, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_kw_fn), (unsigned int)(0));
    return;
}

/* lexerTestBuiltinIdentifier */
void zF_1C8729CF_lexerTestBuiltinIde(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72 = {0};
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76 = {0};
    zT_EAC3E484_TokenKind zT_77;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_sizeof;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bare_at;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "@sizeOf";
    zT_33 = 7;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_sizeof = zT_32;
    zT_35 = s_sizeof;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_builtin_identifier), (unsigned int)(0));
    zT_58 = "@";
    zT_60 = 1;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_bare_at = zT_59;
    zT_62 = s_bare_at;
    zT_67 = 0;
    zT_64 = &interner;
    zT_65 = &diag;
    zT_66 = &sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = &l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* lexerTestDiagnostics */
void zF_6836167B_lexerTestDiagnostic(void) {
    zT_115D5880_Arr_unsigned_char_8 zT_1;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    int zT_6;
    unsigned char* zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    zT_3E40CD83_Sand zT_10 = {0};
    zT_3E40CD83_Sand* zT_12;
    int zT_15;
    zT_D3EB6303_StringInterner zT_17 = {0};
    zT_3E40CD83_Sand* zT_19;
    zT_227EDE07_SourceManager zT_21 = {0};
    zT_3E40CD83_Sand* zT_23;
    zT_227EDE07_SourceManager* zT_24;
    zT_D3EB6303_StringInterner* zT_25;
    zT_F85C5DED_DiagnosticCollector zT_29 = {0};
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D3EB6303_StringInterner* zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    zT_3E40CD83_Sand* zT_39;
    int zT_40;
    zT_138FFB41_Lexer zT_45 = {0};
    zT_138FFB41_Lexer* zT_47;
    zT_3A355BD2_Token zT_49 = {0};
    zT_EAC3E484_TokenKind zT_50;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_D3EB6303_StringInterner* zT_64;
    zT_F85C5DED_DiagnosticCollector* zT_65;
    zT_3E40CD83_Sand* zT_66;
    int zT_67;
    zT_138FFB41_Lexer zT_72 = {0};
    zT_138FFB41_Lexer* zT_74;
    zT_3A355BD2_Token zT_76 = {0};
    zT_EAC3E484_TokenKind zT_77;
    zT_115D5880_Arr_unsigned_char_8 arena_buf;
    zT_3E40CD83_Sand sand;
    zT_D3EB6303_StringInterner interner;
    zT_227EDE07_SourceManager source_man;
    zT_F85C5DED_DiagnosticCollector diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_backtick;
    zT_138FFB41_Lexer l1;
    zT_3A355BD2_Token t1;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_at_backtick;
    zT_138FFB41_Lexer l2;
    zT_3A355BD2_Token t2;
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        zT_1[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8192) {
        arena_buf[_i] = zT_1[_i];
        _i++;
    }
}
    zT_6 = 0;
    zT_7 = (unsigned char*)((unsigned char*)arena_buf) + zT_6;
    zT_8 = (unsigned int)(8192) - zT_6;
    zT_9.ptr = zT_7;
    zT_9.len = zT_8;
    zT_3 = zT_9;
    zT_10 = zF_CE0A77DD_sandInit(zT_3);
    sand = zT_10;
    zT_12 = &sand;
    zT_15 = 4;
    zT_17 = zF_FB2E811D_stringInternerInit(zT_12, (unsigned int)((unsigned int)zT_15));
    interner = zT_17;
    zT_19 = &sand;
    zT_21 = zF_01351F51_sourceManagerInit(zT_19);
    source_man = zT_21;
    zT_23 = &sand;
    zT_24 = &source_man;
    zT_25 = &interner;
    zT_29 = zF_C7BA7DAB_diagnosticCollector(zT_23, zT_24, zT_25);
    diag = zT_29;
    zT_31 = "`";
    zT_33 = 1;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    s_backtick = zT_32;
    zT_35 = s_backtick;
    zT_40 = 0;
    zT_37 = &interner;
    zT_38 = &diag;
    zT_39 = &sand;
    zT_45 = zF_151E643F_lexerInit(zT_35, (unsigned int)((unsigned int)zT_40), zT_37, zT_38, zT_39);
    l1 = zT_45;
    zT_47 = &l1;
    zT_49 = zF_B976BEC9_lexerNextToken(zT_47);
    t1 = zT_49;
    zT_50 = t1.kind;
    zF_1058D9A8_assertEqTokenKind(zT_50, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    zT_58 = "@`";
    zT_60 = 2;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    s_at_backtick = zT_59;
    zT_62 = s_at_backtick;
    zT_67 = 0;
    zT_64 = &interner;
    zT_65 = &diag;
    zT_66 = &sand;
    zT_72 = zF_151E643F_lexerInit(zT_62, (unsigned int)((unsigned int)zT_67), zT_64, zT_65, zT_66);
    l2 = zT_72;
    zT_74 = &l2;
    zT_76 = zF_B976BEC9_lexerNextToken(zT_74);
    t2 = zT_76;
    zT_77 = t2.kind;
    zF_1058D9A8_assertEqTokenKind(zT_77, (zT_EAC3E484_TokenKind)(zT_EAC3E484_TokenKind_err_token), (unsigned int)(0));
    return;
}

/* __module_init */
void zF_780653D2___module_init_5(void) {
    zT_3A355BD2_Token zT_0 = {0};
    zT_EAC3E484_TokenKind zT_1 = 0;
    zT_85CBA4DB_TokenValue zT_2 = {0};
    zT_47B162D1_U8ArrayList zT_3 = {0};
    zG_3A355BD2_Token = zT_0;
    zG_EAC3E484_TokenKind = zT_1;
    zG_85CBA4DB_TokenValue = zT_2;
    zG_47B162D1_U8ArrayList = zT_3;
    return;
}

/* EOF */
