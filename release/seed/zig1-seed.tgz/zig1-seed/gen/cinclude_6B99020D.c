#include "cinclude_6B99020D.h"
/* cincludeUnionAll */
zT_3CB0179A_Slice_zT_05F374B1_u zF_1E2E8788_cincludeUnionAll(zT_072B53A6_ModuleRegistry* module_reg, zT_3E40CD83_Sand* alloc) {
    zT_3E40CD83_Sand* zT_3;
    zT_B687BB96_U32ArrayList zT_4 = {0};
    zT_072B53A6_ModuleRegistry* zT_6;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_7 = {0};
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_13;
    int zT_14;
    zT_B687BB96_U32ArrayList* zT_16;
    zT_6E8D187B_ModuleEntry* zT_17;
    zT_6E8D187B_ModuleEntry* zT_18;
    zT_B687BB96_U32ArrayList* zT_19;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_20 = {0};
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_3E40CD83_Sand* zT_27;
    unsigned int zT_28;
    zT_21D3708C_U32ToU32Map zT_29 = {0};
    unsigned int zT_31;
    unsigned int zT_33;
    int zT_34;
    zT_B687BB96_U32ArrayList* zT_36;
    zT_6E8D187B_ModuleEntry* zT_37;
    zT_6E8D187B_ModuleEntry* zT_38;
    zT_B687BB96_U32ArrayList* zT_39;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_40 = {0};
    unsigned int zT_42;
    unsigned int zT_44;
    int zT_45;
    unsigned int* zT_47;
    unsigned int zT_48;
    zT_21D3708C_U32ToU32Map* zT_49;
    unsigned int zT_50;
    zT_21D3708C_U32ToU32Map* zT_51;
    zT_BAEE192E_Opt_10 zT_52 = {0};
    unsigned char zT_53;
    zT_21D3708C_U32ToU32Map* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_21D3708C_U32ToU32Map* zT_58;
    unsigned int zT_59;
    zT_B687BB96_U32ArrayList* zT_60;
    unsigned int zT_61;
    zT_B687BB96_U32ArrayList* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_B687BB96_U32ArrayList* zT_67;
    zT_B687BB96_U32ArrayList* zT_68;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_69 = {0};
    zT_B687BB96_U32ArrayList temp;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int hint;
    unsigned int hi;
    zT_3CB0179A_Slice_zT_05F374B1_u m_incs_h;
    zT_21D3708C_U32ToU32Map seen;
    unsigned int mi;
    zT_3CB0179A_Slice_zT_05F374B1_u m_incs;
    unsigned int ci;
    unsigned int name_id;
    zT_3 = alloc;
    zT_4 = zF_8E537D0C_u32ArrayListInit(zT_3);
    temp = zT_4;
    temp = zT_4;
    temp = zT_4;
    zT_6 = module_reg;
    zT_7 = zF_3452C137_moduleRegistryGetMo(zT_6);
    mods = zT_7;
    mods = zT_7;
    mods = zT_7;
    zT_9 = 0;
    hint = zT_9;
    hint = zT_9;
    hint = zT_9;
    zT_11 = 0;
    hi = zT_11;
    hi = zT_11;
    hi = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_13 = mods.len;
    zT_14 = hi < zT_13;
    if (zT_14) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_17 = mods.ptr;
    zT_18 = zT_17 + hi;
    zT_19 = &zT_18->c_includes;
    zT_16 = zT_19;
    zT_20 = zF_281E4968_u32ArrayListGetSlic(zT_16);
    m_incs_h = zT_20;
    m_incs_h = zT_20;
    m_incs_h = zT_20;
    zT_22 = m_incs_h.len;
    zT_23 = hint + zT_22;
    hint = zT_23;
    hint = zT_23;
    goto z_bb_4;
    z_bb_3:
    zT_27 = alloc;
    zT_28 = hint;
    zT_29 = zF_619D56E6_u32ToU32MapInitCap(zT_27, zT_28);
    seen = zT_29;
    seen = zT_29;
    seen = zT_29;
    zT_31 = 0;
    mi = zT_31;
    mi = zT_31;
    mi = zT_31;
    goto z_bb_5;
    z_bb_4:
    zT_24 = 1;
    zT_25 = hi + zT_24;
    hi = zT_25;
    hi = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_33 = mods.len;
    zT_34 = mi < zT_33;
    if (zT_34) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_37 = mods.ptr;
    zT_38 = zT_37 + mi;
    zT_39 = &zT_38->c_includes;
    zT_36 = zT_39;
    zT_40 = zF_281E4968_u32ArrayListGetSlic(zT_36);
    m_incs = zT_40;
    m_incs = zT_40;
    m_incs = zT_40;
    zT_42 = 0;
    ci = zT_42;
    ci = zT_42;
    ci = zT_42;
    goto z_bb_9;
    z_bb_7:
    zT_68 = &temp;
    zT_67 = zT_68;
    zT_69 = zF_281E4968_u32ArrayListGetSlic(zT_67);
    return zT_69;
    z_bb_8:
    zT_65 = 1;
    zT_66 = mi + zT_65;
    mi = zT_66;
    mi = zT_66;
    goto z_bb_5;
    z_bb_9:
    zT_44 = m_incs.len;
    zT_45 = ci < zT_44;
    if (zT_45) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_47 = m_incs.ptr;
    zT_48 = zT_47[ci];
    name_id = zT_48;
    name_id = zT_48;
    name_id = zT_48;
    zT_51 = &seen;
    zT_49 = zT_51;
    zT_50 = name_id;
    zT_52 = zF_F3EE5998_u32ToU32MapGet(zT_49, zT_50);
    zT_53 = zT_52.has_value;
    if (zT_53) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_63 = 1;
    zT_64 = ci + zT_63;
    ci = zT_64;
    ci = zT_64;
    goto z_bb_9;
    z_bb_13:
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_58 = &seen;
    zT_55 = zT_58;
    zT_56 = name_id;
    zT_59 = 1;
    zT_57 = zT_59;
    zF_26476265_u32ToU32MapPut(zT_55, zT_56, zT_57);
    zT_62 = &temp;
    zT_60 = zT_62;
    zT_61 = name_id;
    zF_62F717A2_u32ArrayListAppend(zT_60, zT_61);
    goto z_bb_14;
}

/* __module_init */
void zF_780653D2___module_init_20(void) {
    zT_072B53A6_ModuleRegistry zT_0 = {0};
    zG_072B53A6_ModuleRegistry = zT_0;
    return;
}

/* EOF */
