#include "const_alias_prepass_A733A209.h"
/* resolveWellKnownTypeName */
unsigned int zF_0D410D69_resolveWellKnownTyp(zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned int zT_2;
    int zT_3;
    unsigned char* zT_5;
    int zT_6;
    unsigned char zT_7;
    unsigned char zT_10;
    unsigned char* zT_11;
    int zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    unsigned char* zT_17;
    int zT_18;
    unsigned char zT_19;
    unsigned char zT_22;
    unsigned char* zT_23;
    int zT_24;
    unsigned char zT_25;
    unsigned char* zT_29;
    int zT_30;
    unsigned char zT_31;
    unsigned char zT_34;
    unsigned char* zT_35;
    int zT_36;
    unsigned char zT_37;
    unsigned char zT_40;
    unsigned char* zT_41;
    int zT_42;
    unsigned char zT_43;
    unsigned char zT_46;
    unsigned char* zT_47;
    int zT_48;
    unsigned char zT_49;
    unsigned int zT_54;
    int zT_55;
    unsigned char* zT_57;
    int zT_58;
    unsigned char zT_59;
    unsigned char zT_62;
    unsigned char* zT_63;
    int zT_64;
    unsigned char zT_65;
    unsigned char* zT_68;
    int zT_69;
    unsigned char zT_70;
    unsigned char* zT_74;
    int zT_75;
    unsigned char zT_76;
    unsigned char zT_79;
    unsigned char* zT_80;
    int zT_81;
    unsigned char zT_82;
    unsigned char* zT_85;
    int zT_86;
    unsigned char zT_87;
    unsigned char* zT_91;
    int zT_92;
    unsigned char zT_93;
    unsigned char zT_96;
    unsigned char* zT_97;
    int zT_98;
    unsigned char zT_99;
    unsigned char zT_102;
    unsigned char* zT_103;
    int zT_104;
    unsigned char zT_105;
    unsigned char* zT_109;
    int zT_110;
    unsigned char zT_111;
    unsigned char zT_114;
    unsigned char* zT_115;
    int zT_116;
    unsigned char zT_117;
    unsigned char zT_120;
    unsigned char* zT_121;
    int zT_122;
    unsigned char zT_123;
    unsigned char* zT_127;
    int zT_128;
    unsigned char zT_129;
    unsigned char zT_132;
    unsigned char* zT_133;
    int zT_134;
    unsigned char zT_135;
    unsigned char* zT_138;
    int zT_139;
    unsigned char zT_140;
    unsigned char* zT_144;
    int zT_145;
    unsigned char zT_146;
    unsigned int zT_151;
    int zT_152;
    unsigned char* zT_154;
    int zT_155;
    unsigned char zT_156;
    unsigned char zT_159;
    unsigned char* zT_160;
    int zT_161;
    unsigned char zT_162;
    unsigned char* zT_166;
    int zT_167;
    unsigned char zT_168;
    unsigned char zT_171;
    unsigned char* zT_172;
    int zT_173;
    unsigned char zT_174;
    unsigned int zT_179;
    int zT_180;
    unsigned char* zT_182;
    int zT_183;
    unsigned char zT_184;
    unsigned char zT_187;
    unsigned char* zT_188;
    int zT_189;
    unsigned char zT_190;
    unsigned char zT_193;
    unsigned char* zT_194;
    int zT_195;
    unsigned char zT_196;
    unsigned char zT_199;
    unsigned char* zT_200;
    int zT_201;
    unsigned char zT_202;
    unsigned char zT_205;
    unsigned char* zT_206;
    int zT_207;
    unsigned char zT_208;
    unsigned char* zT_212;
    int zT_213;
    unsigned char zT_214;
    unsigned char zT_217;
    unsigned char* zT_218;
    int zT_219;
    unsigned char zT_220;
    unsigned char zT_223;
    unsigned char* zT_224;
    int zT_225;
    unsigned char zT_226;
    unsigned char zT_229;
    unsigned char* zT_230;
    int zT_231;
    unsigned char zT_232;
    unsigned char zT_235;
    unsigned char* zT_236;
    int zT_237;
    unsigned char zT_238;
    zT_2 = name.len;
    zT_3 = 4;
    if ((unsigned char)(zT_2 == (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = name.ptr;
    zT_6 = 0;
    zT_7 = zT_5[zT_6];
    if ((unsigned char)(zT_7 == (unsigned char)(118))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_54 = name.len;
    zT_55 = 3;
    if ((unsigned char)(zT_54 == (unsigned int)zT_55)) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    zT_11 = name.ptr;
    zT_12 = 1;
    zT_13 = zT_11[zT_12];
    zT_10 = zT_13 == (unsigned char)(111);
    goto z_bb_5;
    z_bb_4:
    zT_10 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_10) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = name.ptr;
    zT_18 = 2;
    zT_19 = zT_17[zT_18];
    zT_16 = zT_19 == (unsigned char)(105);
    goto z_bb_8;
    z_bb_7:
    zT_16 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_16) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_23 = name.ptr;
    zT_24 = 3;
    zT_25 = zT_23[zT_24];
    zT_22 = zT_25 == (unsigned char)(100);
    goto z_bb_11;
    z_bb_10:
    zT_22 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_22) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_29 = name.ptr;
    zT_30 = 0;
    zT_31 = zT_29[zT_30];
    if ((unsigned char)(zT_31 == (unsigned char)(98))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_35 = name.ptr;
    zT_36 = 1;
    zT_37 = zT_35[zT_36];
    zT_34 = zT_37 == (unsigned char)(111);
    goto z_bb_16;
    z_bb_15:
    zT_34 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_34) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_41 = name.ptr;
    zT_42 = 2;
    zT_43 = zT_41[zT_42];
    zT_40 = zT_43 == (unsigned char)(111);
    goto z_bb_19;
    z_bb_18:
    zT_40 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_40) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_47 = name.ptr;
    zT_48 = 3;
    zT_49 = zT_47[zT_48];
    zT_46 = zT_49 == (unsigned char)(108);
    goto z_bb_22;
    z_bb_21:
    zT_46 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_46) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned int)(2);
    z_bb_24:
    goto z_bb_2;
    z_bb_25:
    zT_57 = name.ptr;
    zT_58 = 0;
    zT_59 = zT_57[zT_58];
    if ((unsigned char)(zT_59 == (unsigned char)(105))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_151 = name.len;
    zT_152 = 2;
    if ((unsigned char)(zT_151 == (unsigned int)zT_152)) goto z_bb_66; else goto z_bb_67;
    z_bb_27:
    zT_63 = name.ptr;
    zT_64 = 2;
    zT_65 = zT_63[zT_64];
    zT_62 = zT_65 == (unsigned char)(50);
    goto z_bb_29;
    z_bb_28:
    zT_62 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_62) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_68 = name.ptr;
    zT_69 = 1;
    zT_70 = zT_68[zT_69];
    if ((unsigned char)(zT_70 == (unsigned char)(51))) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_74 = name.ptr;
    zT_75 = 0;
    zT_76 = zT_74[zT_75];
    if ((unsigned char)(zT_76 == (unsigned char)(117))) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    return (unsigned int)(6);
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    zT_80 = name.ptr;
    zT_81 = 2;
    zT_82 = zT_80[zT_81];
    zT_79 = zT_82 == (unsigned char)(50);
    goto z_bb_36;
    z_bb_35:
    zT_79 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_79) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_85 = name.ptr;
    zT_86 = 1;
    zT_87 = zT_85[zT_86];
    if ((unsigned char)(zT_87 == (unsigned char)(51))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_91 = name.ptr;
    zT_92 = 0;
    zT_93 = zT_91[zT_92];
    if ((unsigned char)(zT_93 == (unsigned char)(117))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    return (unsigned int)(10);
    z_bb_40:
    goto z_bb_38;
    z_bb_41:
    zT_97 = name.ptr;
    zT_98 = 1;
    zT_99 = zT_97[zT_98];
    zT_96 = zT_99 == (unsigned char)(54);
    goto z_bb_43;
    z_bb_42:
    zT_96 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_96) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_103 = name.ptr;
    zT_104 = 2;
    zT_105 = zT_103[zT_104];
    zT_102 = zT_105 == (unsigned char)(52);
    goto z_bb_46;
    z_bb_45:
    zT_102 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_102) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned int)(11);
    z_bb_48:
    zT_109 = name.ptr;
    zT_110 = 0;
    zT_111 = zT_109[zT_110];
    if ((unsigned char)(zT_111 == (unsigned char)(105))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_115 = name.ptr;
    zT_116 = 1;
    zT_117 = zT_115[zT_116];
    zT_114 = zT_117 == (unsigned char)(54);
    goto z_bb_51;
    z_bb_50:
    zT_114 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_114) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_121 = name.ptr;
    zT_122 = 2;
    zT_123 = zT_121[zT_122];
    zT_120 = zT_123 == (unsigned char)(52);
    goto z_bb_54;
    z_bb_53:
    zT_120 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_120) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (unsigned int)(7);
    z_bb_56:
    zT_127 = name.ptr;
    zT_128 = 0;
    zT_129 = zT_127[zT_128];
    if ((unsigned char)(zT_129 == (unsigned char)(102))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_133 = name.ptr;
    zT_134 = 2;
    zT_135 = zT_133[zT_134];
    zT_132 = zT_135 == (unsigned char)(50);
    goto z_bb_59;
    z_bb_58:
    zT_132 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_132) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_138 = name.ptr;
    zT_139 = 1;
    zT_140 = zT_138[zT_139];
    if ((unsigned char)(zT_140 == (unsigned char)(51))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    goto z_bb_26;
    z_bb_62:
    return (unsigned int)(15);
    z_bb_63:
    zT_144 = name.ptr;
    zT_145 = 1;
    zT_146 = zT_144[zT_145];
    if ((unsigned char)(zT_146 == (unsigned char)(54))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    return (unsigned int)(16);
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_154 = name.ptr;
    zT_155 = 0;
    zT_156 = zT_154[zT_155];
    if ((unsigned char)(zT_156 == (unsigned char)(105))) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    zT_179 = name.len;
    zT_180 = 5;
    if ((unsigned char)(zT_179 == (unsigned int)zT_180)) goto z_bb_78; else goto z_bb_79;
    z_bb_68:
    zT_160 = name.ptr;
    zT_161 = 1;
    zT_162 = zT_160[zT_161];
    zT_159 = zT_162 == (unsigned char)(56);
    goto z_bb_70;
    z_bb_69:
    zT_159 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_159) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    return (unsigned int)(4);
    z_bb_72:
    zT_166 = name.ptr;
    zT_167 = 0;
    zT_168 = zT_166[zT_167];
    if ((unsigned char)(zT_168 == (unsigned char)(117))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_172 = name.ptr;
    zT_173 = 1;
    zT_174 = zT_172[zT_173];
    zT_171 = zT_174 == (unsigned char)(56);
    goto z_bb_75;
    z_bb_74:
    zT_171 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_171) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    return (unsigned int)(8);
    z_bb_77:
    goto z_bb_67;
    z_bb_78:
    zT_182 = name.ptr;
    zT_183 = 0;
    zT_184 = zT_182[zT_183];
    if ((unsigned char)(zT_184 == (unsigned char)(117))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    return (unsigned int)(18);
    z_bb_80:
    zT_188 = name.ptr;
    zT_189 = 1;
    zT_190 = zT_188[zT_189];
    zT_187 = zT_190 == (unsigned char)(115);
    goto z_bb_82;
    z_bb_81:
    zT_187 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_187) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_194 = name.ptr;
    zT_195 = 2;
    zT_196 = zT_194[zT_195];
    zT_193 = zT_196 == (unsigned char)(105);
    goto z_bb_85;
    z_bb_84:
    zT_193 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_193) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_200 = name.ptr;
    zT_201 = 3;
    zT_202 = zT_200[zT_201];
    zT_199 = zT_202 == (unsigned char)(122);
    goto z_bb_88;
    z_bb_87:
    zT_199 = 0;
    goto z_bb_88;
    z_bb_88:
    if (zT_199) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_206 = name.ptr;
    zT_207 = 4;
    zT_208 = zT_206[zT_207];
    zT_205 = zT_208 == (unsigned char)(101);
    goto z_bb_91;
    z_bb_90:
    zT_205 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_205) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    return (unsigned int)(13);
    z_bb_93:
    zT_212 = name.ptr;
    zT_213 = 0;
    zT_214 = zT_212[zT_213];
    if ((unsigned char)(zT_214 == (unsigned char)(105))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_218 = name.ptr;
    zT_219 = 1;
    zT_220 = zT_218[zT_219];
    zT_217 = zT_220 == (unsigned char)(115);
    goto z_bb_96;
    z_bb_95:
    zT_217 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_217) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_224 = name.ptr;
    zT_225 = 2;
    zT_226 = zT_224[zT_225];
    zT_223 = zT_226 == (unsigned char)(105);
    goto z_bb_99;
    z_bb_98:
    zT_223 = 0;
    goto z_bb_99;
    z_bb_99:
    if (zT_223) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_230 = name.ptr;
    zT_231 = 3;
    zT_232 = zT_230[zT_231];
    zT_229 = zT_232 == (unsigned char)(122);
    goto z_bb_102;
    z_bb_101:
    zT_229 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_229) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_236 = name.ptr;
    zT_237 = 4;
    zT_238 = zT_236[zT_237];
    zT_235 = zT_238 == (unsigned char)(101);
    goto z_bb_105;
    z_bb_104:
    zT_235 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_235) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    return (unsigned int)(12);
    z_bb_107:
    goto z_bb_79;
}

/* growDep */
void zF_62CBE4C7_growDep(zT_3E40CD83_Sand* perm, unsigned int** to_ptr, unsigned int** next_ptr, unsigned int* cap_ptr) {
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    int zT_10;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_13;
    zT_C6536882_EU_532 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_C6536882_EU_532 zT_34 = {0};
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_52;
    unsigned int nc;
    unsigned char* ntr;
    unsigned int* nto;
    unsigned char* nnr;
    unsigned int* nno;
    unsigned int ci;
    zT_5 = *cap_ptr;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    nc = zT_7;
    zT_8 = 16;
    if ((unsigned char)(nc < (unsigned int)zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = 16;
    zT_11 = (unsigned int)zT_10;
    nc = zT_11;
    goto z_bb_2;
    z_bb_2:
    zT_13 = perm;
    zT_20 = zF_1395EB68_sandAlloc(zT_13, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)nc)), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_22 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    ntr = zT_22;
    zT_25 = (unsigned int*)ntr;
    nto = zT_25;
    zT_27 = perm;
    zT_34 = zF_1395EB68_sandAlloc(zT_27, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)nc)), (unsigned int)(4));
    zT_35 = zT_34.is_error;
    if (zT_35) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_36 = zT_34.data.payload;
    goto z_bb_8;
    z_bb_8:
    nnr = zT_36;
    zT_39 = (unsigned int*)nnr;
    nno = zT_39;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ci = zT_42;
    goto z_bb_9;
    z_bb_9:
    zT_43 = *cap_ptr;
    if ((unsigned char)(ci < (unsigned int)((unsigned int)zT_43))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = *to_ptr;
    zT_47 = zT_46[ci];
    nto[ci] = zT_47;
    zT_48 = *next_ptr;
    zT_49 = zT_48[ci];
    nno[ci] = zT_49;
    goto z_bb_12;
    z_bb_11:
    *to_ptr = nto;
    *next_ptr = nno;
    *cap_ptr = nc;
    return;
    z_bb_12:
    zT_50 = 1;
    zT_52 = ci + (unsigned int)((unsigned int)zT_50);
    ci = zT_52;
    goto z_bb_9;
}

/* constAliasPrepass */
void zF_EF7F7D3C_constAliasPrepass(zT_3D7259E2_SymbolRegistry* symbol_reg, zT_338B7C76_TypeRegistry* registry, zT_D3EB6303_StringInterner* interner, zT_6B0A7D14_AstStore* store, zT_3E40CD83_Sand* perm_alloc) {
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    int zT_11;
    unsigned int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_060CD1EB_SymbolTable* zT_18;
    zT_060CD1EB_SymbolTable zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_49;
    zT_C6536882_EU_532 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int* zT_57;
    zT_3E40CD83_Sand* zT_59;
    unsigned int zT_61;
    zT_C6536882_EU_532 zT_64 = {0};
    unsigned char zT_65;
    unsigned char* zT_66;
    unsigned int* zT_69;
    unsigned int zT_71;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_76;
    unsigned int zT_78;
    zT_C6536882_EU_532 zT_80 = {0};
    unsigned char zT_81;
    unsigned char* zT_82;
    unsigned int* zT_85;
    int zT_87;
    unsigned int zT_88;
    int zT_90;
    unsigned int zT_92;
    int zT_94;
    unsigned int zT_95;
    zT_3E40CD83_Sand* zT_97;
    unsigned int zT_99;
    zT_C6536882_EU_532 zT_102 = {0};
    unsigned char zT_103;
    unsigned char* zT_104;
    unsigned int* zT_107;
    int zT_109;
    unsigned int zT_110;
    zT_3E40CD83_Sand* zT_112;
    unsigned int zT_114;
    zT_C6536882_EU_532 zT_117 = {0};
    unsigned char zT_118;
    unsigned char* zT_119;
    unsigned int* zT_122;
    zT_3E40CD83_Sand* zT_124;
    unsigned int zT_126;
    int zT_129;
    zT_C6536882_EU_532 zT_131 = {0};
    unsigned char zT_132;
    unsigned char* zT_133;
    unsigned int* zT_136;
    int zT_138;
    unsigned int zT_139;
    int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_060CD1EB_SymbolTable* zT_146;
    zT_060CD1EB_SymbolTable zT_147;
    int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_3A105EF1_Symbol* zT_154;
    zT_3A105EF1_Symbol* zT_155;
    zT_3C598AEF_SymbolKind zT_156;
    unsigned char* zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_165;
    unsigned int zT_166;
    unsigned int zT_168;
    int zT_169;
    unsigned char* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    unsigned int zT_174;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    zT_22A7C88B_AstNode zT_180 = {0};
    zT_8143F551_AstKind zT_181;
    int zT_182;
    unsigned char* zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    unsigned int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_188;
    zT_8143F551_AstKind zT_190;
    unsigned int zT_192;
    int zT_193;
    unsigned char* zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_198;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_199;
    zT_6B0A7D14_AstStore* zT_201;
    unsigned int zT_202;
    zT_22A7C88B_AstNode zT_204 = {0};
    unsigned char* zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    unsigned int zT_208;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_209;
    zT_8143F551_AstKind zT_211;
    zT_8143F551_AstKind zT_213;
    int zT_214;
    zT_6B0A7D14_AstStore* zT_217;
    unsigned int zT_218;
    unsigned int zT_220 = 0;
    unsigned char* zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_225;
    unsigned int zT_226;
    zT_D3EB6303_StringInterner* zT_228;
    unsigned int zT_229;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_230 = {0};
    zT_D3EB6303_StringInterner* zT_232;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_233;
    unsigned int zT_234 = 0;
    unsigned int zT_235;
    unsigned int zT_236;
    int zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    int zT_242;
    int zT_244;
    unsigned int zT_245;
    zT_3E40CD83_Sand* zT_247;
    unsigned int** zT_248;
    unsigned int** zT_249;
    unsigned int* zT_250;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    int zT_259;
    unsigned int zT_261;
    int zT_262;
    unsigned int zT_264;
    int zT_265;
    unsigned int zT_267;
    int zT_268;
    unsigned int zT_270;
    unsigned char* zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned int zT_274;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_275;
    unsigned int zT_276;
    int zT_277;
    unsigned char* zT_280;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_281;
    unsigned int zT_282;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_283;
    int zT_285;
    unsigned int zT_286;
    unsigned int zT_289;
    unsigned int zT_290;
    int zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    int zT_298;
    int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    zT_060CD1EB_SymbolTable* zT_304;
    unsigned int zT_305;
    zT_060CD1EB_SymbolTable zT_306;
    zT_3A105EF1_Symbol* zT_308;
    zT_3A105EF1_Symbol* zT_310;
    unsigned int zT_313;
    zT_79FAE712_u64 zT_319;
    zT_338B7C76_TypeRegistry* zT_320;
    zT_79FAE712_u64 zT_321;
    zT_BAEE192E_Opt_10 zT_322 = {0};
    unsigned char zT_323;
    zT_338B7C76_TypeRegistry* zT_327;
    zT_BAEE192E_Opt_10 zT_330 = {0};
    unsigned char zT_331;
    int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    zT_79FAE712_u64 zT_345;
    zT_338B7C76_TypeRegistry* zT_346;
    zT_79FAE712_u64 zT_347;
    zT_BAEE192E_Opt_10 zT_348 = {0};
    unsigned char zT_349;
    int zT_351;
    unsigned int zT_353;
    zT_D3EB6303_StringInterner* zT_357;
    unsigned int zT_358;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_360;
    unsigned int zT_361 = 0;
    zT_79FAE712_u64 zT_372;
    zT_338B7C76_TypeRegistry* zT_373;
    zT_79FAE712_u64 zT_374;
    unsigned int zT_375;
    unsigned int zT_376;
    int zT_377;
    unsigned int zT_379;
    int zT_380;
    unsigned int zT_382;
    unsigned char* zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    unsigned int zT_386;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_387;
    int zT_388;
    int zT_390;
    unsigned int zT_392;
    unsigned int zT_394;
    unsigned int zT_395;
    int zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    zT_060CD1EB_SymbolTable* zT_402;
    unsigned int zT_403;
    zT_060CD1EB_SymbolTable zT_404;
    zT_3A105EF1_Symbol* zT_406;
    int zT_408;
    int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    zT_3A105EF1_Symbol* zT_414;
    unsigned int zT_416;
    zT_6B0A7D14_AstStore* zT_418;
    unsigned int zT_419;
    zT_22A7C88B_AstNode zT_421 = {0};
    zT_6B0A7D14_AstStore* zT_423;
    unsigned int zT_424;
    unsigned int zT_426 = 0;
    zT_D3EB6303_StringInterner* zT_428;
    unsigned int zT_429;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_430 = {0};
    zT_D3EB6303_StringInterner* zT_432;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_433;
    unsigned int zT_434 = 0;
    unsigned int zT_436;
    unsigned int zT_437;
    unsigned int zT_440;
    unsigned int zT_441;
    int zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    int zT_449;
    int zT_451;
    unsigned int zT_452;
    unsigned int zT_453;
    zT_060CD1EB_SymbolTable* zT_455;
    unsigned int zT_456;
    zT_060CD1EB_SymbolTable zT_457;
    zT_3A105EF1_Symbol* zT_459;
    zT_3A105EF1_Symbol* zT_461;
    unsigned int zT_462;
    int zT_463;
    unsigned int zT_469;
    unsigned int zT_470;
    zT_79FAE712_u64 zT_476;
    zT_338B7C76_TypeRegistry* zT_477;
    zT_79FAE712_u64 zT_478;
    unsigned int zT_479;
    unsigned int zT_480;
    int zT_481;
    unsigned int zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    unsigned char* zT_487;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_488;
    unsigned int zT_489;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_490;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_m;
    unsigned int tl;
    unsigned int cti;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_tm;
    unsigned int SZ_U32;
    unsigned int U32_MAX;
    unsigned int dep_cap;
    unsigned char* dep_to_raw;
    unsigned int* dep_to;
    unsigned char* dep_next_raw;
    unsigned int* dep_next;
    unsigned int head_cap;
    unsigned char* dep_head_raw;
    unsigned int* dep_head;
    unsigned int si0;
    unsigned int dep_count;
    unsigned char* wl_raw;
    unsigned int* wl;
    unsigned int wl_len;
    unsigned char* alias_name_raw;
    unsigned int* alias_name;
    unsigned char* alias_sym_raw;
    unsigned int* alias_sym_id;
    unsigned int alias_count;
    unsigned int mi;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_acm;
    zT_3A105EF1_Symbol* sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u g0_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u g1_m;
    zT_22A7C88B_AstNode decl_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u g2_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u g3_m;
    zT_22A7C88B_AstNode init;
    zT_8F083A69_Slice_zT_0B42B2F8_u c1_m;
    unsigned int dep_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u c2_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u dep_text;
    unsigned int dep_canonical;
    unsigned int ai;
    unsigned int mod_id;
    unsigned int sym_idx;
    unsigned int resolved;
    zT_79FAE712_u64 mod_key;
    zT_8F083A69_Slice_zT_0B42B2F8_u kst_m;
    unsigned int tid;
    unsigned int cmi;
    zT_79FAE712_u64 ckey;
    zT_8F083A69_Slice_zT_0B42B2F8_u name_str;
    unsigned int resolved_idx;
    unsigned int resolved_mod;
    zT_060CD1EB_SymbolTable resolved_table;
    zT_3A105EF1_Symbol* resolved_sym;
    unsigned int rt;
    unsigned int alias_own_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u alias_own_text;
    unsigned int alias_own_canonical;
    unsigned int edge_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u ken_m;
    unsigned int dep_alias_idx;
    unsigned int dep_mod;
    unsigned int dep_sym_idx;
    zT_060CD1EB_SymbolTable dep_table;
    zT_3A105EF1_Symbol* dep_sym;
    zT_79FAE712_u64 dkey;
    zT_6 = "CAP:ent\n";
    zT_8 = 8;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    cap_m = zT_7;
    zT_9 = cap_m;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    tl = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    cti = zT_15;
    goto z_bb_1;
    z_bb_1:
    zT_16 = symbol_reg->tables_len;
    if ((unsigned char)(cti < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_18 = symbol_reg->tables_items;
    zT_19 = zT_18[cti];
    zT_20 = zT_19.len;
    zT_22 = tl + (unsigned int)((unsigned int)zT_20);
    tl = zT_22;
    goto z_bb_4;
    z_bb_3:
    zT_27 = "CAP:tlm";
    zT_29 = 7;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    cap_tm = zT_28;
    zT_30 = cap_tm;
    zT_31 = tl;
    zF_C914CB83_markerWriteInt(zT_30, zT_31);
    zT_32 = 0;
    if ((unsigned char)(tl == (unsigned int)zT_32)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_25 = cti + (unsigned int)((unsigned int)zT_23);
    cti = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_35 = "CAP:tl0\n";
    zT_37 = 8;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    cap_m = zT_36;
    zT_38 = cap_m;
    zF_48AC7B3A_markerWrite(zT_38);
    return;
    z_bb_6:
    zT_40 = 4;
    zT_41 = (unsigned int)zT_40;
    SZ_U32 = zT_41;
    zT_43 = 4294967295u;
    zT_44 = (unsigned int)zT_43;
    U32_MAX = zT_44;
    dep_cap = tl;
    zT_47 = perm_alloc;
    zT_49 = SZ_U32;
    zT_52 = zF_1395EB68_sandAlloc(zT_47, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_49);
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_54 = zT_52.data.payload;
    goto z_bb_9;
    z_bb_9:
    dep_to_raw = zT_54;
    zT_57 = (unsigned int*)dep_to_raw;
    dep_to = zT_57;
    zT_59 = perm_alloc;
    zT_61 = SZ_U32;
    zT_64 = zF_1395EB68_sandAlloc(zT_59, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_61);
    zT_65 = zT_64.is_error;
    if (zT_65) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_66 = zT_64.data.payload;
    goto z_bb_12;
    z_bb_12:
    dep_next_raw = zT_66;
    zT_69 = (unsigned int*)dep_next_raw;
    dep_next = zT_69;
    zT_71 = interner->entries_len;
    head_cap = zT_71;
    if ((unsigned char)(head_cap < (unsigned int)((unsigned int)tl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_74 = (unsigned int)tl;
    head_cap = zT_74;
    goto z_bb_14;
    z_bb_14:
    zT_76 = perm_alloc;
    zT_78 = SZ_U32;
    zT_80 = zF_1395EB68_sandAlloc(zT_76, (unsigned int)(SZ_U32 * head_cap), zT_78);
    zT_81 = zT_80.is_error;
    if (zT_81) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    pal_trap();
    z_bb_16:
    zT_82 = zT_80.data.payload;
    goto z_bb_17;
    z_bb_17:
    dep_head_raw = zT_82;
    zT_85 = (unsigned int*)dep_head_raw;
    dep_head = zT_85;
    zT_87 = 0;
    zT_88 = (unsigned int)zT_87;
    si0 = zT_88;
    goto z_bb_18;
    z_bb_18:
    if ((unsigned char)(si0 < head_cap)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    dep_head[si0] = U32_MAX;
    goto z_bb_21;
    z_bb_20:
    zT_94 = 0;
    zT_95 = (unsigned int)zT_94;
    dep_count = zT_95;
    zT_97 = perm_alloc;
    zT_99 = SZ_U32;
    zT_102 = zF_1395EB68_sandAlloc(zT_97, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_99);
    zT_103 = zT_102.is_error;
    if (zT_103) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_90 = 1;
    zT_92 = si0 + (unsigned int)((unsigned int)zT_90);
    si0 = zT_92;
    goto z_bb_18;
    z_bb_22:
    pal_trap();
    z_bb_23:
    zT_104 = zT_102.data.payload;
    goto z_bb_24;
    z_bb_24:
    wl_raw = zT_104;
    zT_107 = (unsigned int*)wl_raw;
    wl = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    wl_len = zT_110;
    zT_112 = perm_alloc;
    zT_114 = SZ_U32;
    zT_117 = zF_1395EB68_sandAlloc(zT_112, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_114);
    zT_118 = zT_117.is_error;
    if (zT_118) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    pal_trap();
    z_bb_26:
    zT_119 = zT_117.data.payload;
    goto z_bb_27;
    z_bb_27:
    alias_name_raw = zT_119;
    zT_122 = (unsigned int*)alias_name_raw;
    alias_name = zT_122;
    zT_124 = perm_alloc;
    zT_129 = 2;
    zT_126 = SZ_U32;
    zT_131 = zF_1395EB68_sandAlloc(zT_124, (unsigned int)((unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)) * zT_129), zT_126);
    zT_132 = zT_131.is_error;
    if (zT_132) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    pal_trap();
    z_bb_29:
    zT_133 = zT_131.data.payload;
    goto z_bb_30;
    z_bb_30:
    alias_sym_raw = zT_133;
    zT_136 = (unsigned int*)alias_sym_raw;
    alias_sym_id = zT_136;
    zT_138 = 0;
    zT_139 = (unsigned int)zT_138;
    alias_count = zT_139;
    zT_141 = 0;
    zT_142 = (unsigned int)zT_141;
    mi = zT_142;
    goto z_bb_31;
    z_bb_31:
    zT_143 = symbol_reg->tables_len;
    if ((unsigned char)(mi < zT_143)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_146 = symbol_reg->tables_items;
    zT_147 = zT_146[mi];
    table = zT_147;
    zT_149 = 0;
    zT_150 = (unsigned int)zT_149;
    si = zT_150;
    goto z_bb_35;
    z_bb_33:
    zT_272 = "CAP:ac";
    zT_274 = 6;
    zT_273.ptr = zT_272;
    zT_273.len = zT_274;
    cap_acm = zT_273;
    zT_275 = cap_acm;
    zT_276 = alias_count;
    zF_C914CB83_markerWriteInt(zT_275, zT_276);
    zT_277 = 0;
    if ((unsigned char)(alias_count == (unsigned int)zT_277)) goto z_bb_51; else goto z_bb_52;
    z_bb_34:
    zT_268 = 1;
    zT_270 = mi + (unsigned int)((unsigned int)zT_268);
    mi = zT_270;
    goto z_bb_31;
    z_bb_35:
    zT_151 = table.len;
    if ((unsigned char)(si < zT_151)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_154 = table.items;
    zT_155 = zT_154 + si;
    sym = zT_155;
    zT_156 = sym->kind;
    if ((unsigned char)(zT_156 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_265 = 1;
    zT_267 = si + (unsigned int)((unsigned int)zT_265);
    si = zT_267;
    goto z_bb_35;
    z_bb_39:
    goto z_bb_38;
    z_bb_40:
    zT_162 = "GATE:g0";
    zT_164 = 7;
    zT_163.ptr = zT_162;
    zT_163.len = zT_164;
    g0_m = zT_163;
    zT_165 = g0_m;
    zT_166 = sym->type_id;
    zF_C914CB83_markerWriteInt(zT_165, zT_166);
    zT_168 = sym->type_id;
    zT_169 = 0;
    if ((unsigned char)(zT_168 != (unsigned int)zT_169)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_172 = "GATE:g1\n";
    zT_174 = 8;
    zT_173.ptr = zT_172;
    zT_173.len = zT_174;
    g1_m = zT_173;
    zT_175 = g1_m;
    zF_48AC7B3A_markerWrite(zT_175);
    zT_177 = store;
    zT_178 = sym->decl_node;
    zT_180 = zF_FCDD1D35_astStoreNodeAt(zT_177, zT_178);
    decl_node = zT_180;
    zT_181 = decl_node.kind;
    zT_182 = 1;
    if ((unsigned char)(zT_181 != zT_182)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_185 = "GATE:g2";
    zT_187 = 7;
    zT_186.ptr = zT_185;
    zT_186.len = zT_187;
    g2_m = zT_186;
    zT_188 = g2_m;
    zT_190 = decl_node.kind;
    zF_C914CB83_markerWriteInt(zT_188, (unsigned int)((unsigned int)zT_190));
    goto z_bb_38;
    z_bb_44:
    zT_192 = decl_node.child_1;
    zT_193 = 0;
    if ((unsigned char)(zT_192 == (unsigned int)zT_193)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_196 = "GATE:g3\n";
    zT_198 = 8;
    zT_197.ptr = zT_196;
    zT_197.len = zT_198;
    g3_m = zT_197;
    zT_199 = g3_m;
    zF_48AC7B3A_markerWrite(zT_199);
    goto z_bb_38;
    z_bb_46:
    zT_201 = store;
    zT_202 = decl_node.child_1;
    zT_204 = zF_FCDD1D35_astStoreNodeAt(zT_201, zT_202);
    init = zT_204;
    zT_206 = "CAT:ik";
    zT_208 = 6;
    zT_207.ptr = zT_206;
    zT_207.len = zT_208;
    c1_m = zT_207;
    zT_209 = c1_m;
    zT_211 = init.kind;
    zF_C914CB83_markerWriteInt(zT_209, (unsigned int)((unsigned int)zT_211));
    zT_213 = init.kind;
    zT_214 = 24;
    if ((unsigned char)(zT_213 != zT_214)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_38;
    z_bb_48:
    zT_217 = store;
    zT_218 = decl_node.child_1;
    zT_220 = zF_53458827_astStoreIdentifier(zT_217, zT_218);
    dep_name = zT_220;
    zT_222 = "CAT:dn";
    zT_224 = 6;
    zT_223.ptr = zT_222;
    zT_223.len = zT_224;
    c2_m = zT_223;
    zT_225 = c2_m;
    zT_226 = dep_name;
    zF_C914CB83_markerWriteInt(zT_225, zT_226);
    zT_228 = interner;
    zT_229 = dep_name;
    zT_230 = zF_9134020D_stringInternerGet(zT_228, zT_229);
    dep_text = zT_230;
    zT_232 = interner;
    zT_233 = dep_text;
    zT_234 = zF_50C274AF_stringInternerInter(zT_232, zT_233);
    dep_canonical = zT_234;
    zT_235 = (unsigned int)alias_count;
    alias_name[zT_235] = dep_canonical;
    zT_236 = (unsigned int)mi;
    zT_238 = 2;
    zT_239 = (unsigned int)((unsigned int)alias_count) * zT_238;
    alias_sym_id[zT_239] = zT_236;
    zT_240 = (unsigned int)si;
    zT_242 = 2;
    zT_244 = 1;
    zT_245 = (unsigned int)((unsigned int)((unsigned int)alias_count) * zT_242) + zT_244;
    alias_sym_id[zT_245] = zT_240;
    if ((unsigned char)(dep_count >= dep_cap)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_247 = perm_alloc;
    zT_248 = &dep_to;
    zT_249 = &dep_next;
    zT_250 = &dep_cap;
    zF_62CBE4C7_growDep(zT_247, zT_248, zT_249, zT_250);
    goto z_bb_50;
    z_bb_50:
    zT_254 = (unsigned int)dep_count;
    dep_to[zT_254] = alias_count;
    zT_255 = (unsigned int)dep_canonical;
    zT_256 = dep_head[zT_255];
    zT_257 = (unsigned int)dep_count;
    dep_next[zT_257] = zT_256;
    zT_258 = (unsigned int)dep_canonical;
    dep_head[zT_258] = dep_count;
    zT_259 = 1;
    zT_261 = dep_count + (unsigned int)((unsigned int)zT_259);
    dep_count = zT_261;
    zT_262 = 1;
    zT_264 = alias_count + (unsigned int)((unsigned int)zT_262);
    alias_count = zT_264;
    goto z_bb_38;
    z_bb_51:
    zT_280 = "CAP:ac0\n";
    zT_282 = 8;
    zT_281.ptr = zT_280;
    zT_281.len = zT_282;
    cap_m = zT_281;
    zT_283 = cap_m;
    zF_48AC7B3A_markerWrite(zT_283);
    return;
    z_bb_52:
    zT_285 = 0;
    zT_286 = (unsigned int)zT_285;
    ai = zT_286;
    goto z_bb_53;
    z_bb_53:
    if ((unsigned char)(ai < alias_count)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_289 = (unsigned int)ai;
    zT_290 = alias_name[zT_289];
    dep_name = zT_290;
    zT_293 = 2;
    zT_294 = (unsigned int)((unsigned int)ai) * zT_293;
    zT_295 = alias_sym_id[zT_294];
    mod_id = zT_295;
    zT_298 = 2;
    zT_300 = 1;
    zT_301 = (unsigned int)((unsigned int)((unsigned int)ai) * zT_298) + zT_300;
    zT_302 = alias_sym_id[zT_301];
    sym_idx = zT_302;
    zT_304 = symbol_reg->tables_items;
    zT_305 = (unsigned int)mod_id;
    zT_306 = zT_304[zT_305];
    table = zT_306;
    zT_308 = table.items;
    zT_310 = zT_308 + (unsigned int)((unsigned int)sym_idx);
    sym = zT_310;
    zT_313 = 18;
    resolved = zT_313;
    zT_319 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    mod_key = zT_319;
    zT_320 = registry;
    zT_321 = mod_key;
    zT_322 = zF_0EB68360_nameCacheGet(zT_320, zT_321);
    zT_323 = zT_322.has_value;
    if (zT_323) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    zT_384 = "KAHN:start\n";
    zT_386 = 11;
    zT_385.ptr = zT_384;
    zT_385.len = zT_386;
    kst_m = zT_385;
    zT_387 = kst_m;
    zF_48AC7B3A_markerWrite(zT_387);
    goto z_bb_75;
    z_bb_56:
    zT_380 = 1;
    zT_382 = ai + (unsigned int)((unsigned int)zT_380);
    ai = zT_382;
    goto z_bb_53;
    z_bb_57:
    tid = zT_322.value;
    resolved = tid;
    goto z_bb_58;
    z_bb_58:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_327 = registry;
    zT_330 = zF_0EB68360_nameCacheGet(zT_327, (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name));
    zT_331 = zT_330.has_value;
    if (zT_331) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    tid = zT_330.value;
    resolved = tid;
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_336 = 0;
    zT_337 = (unsigned int)zT_336;
    cmi = zT_337;
    goto z_bb_65;
    z_bb_64:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_71; else goto z_bb_72;
    z_bb_65:
    zT_338 = symbol_reg->tables_len;
    if ((unsigned char)(cmi < zT_338)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_345 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)cmi) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    ckey = zT_345;
    zT_346 = registry;
    zT_347 = ckey;
    zT_348 = zF_0EB68360_nameCacheGet(zT_346, zT_347);
    zT_349 = zT_348.has_value;
    if (zT_349) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_351 = 1;
    zT_353 = cmi + (unsigned int)((unsigned int)zT_351);
    cmi = zT_353;
    goto z_bb_65;
    z_bb_69:
    tid = zT_348.value;
    resolved = tid;
    goto z_bb_67;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_357 = interner;
    zT_358 = dep_name;
    zT_359 = zF_9134020D_stringInternerGet(zT_357, zT_358);
    name_str = zT_359;
    zT_360 = name_str;
    zT_361 = zF_0D410D69_resolveWellKnownTyp(zT_360);
    resolved = zT_361;
    goto z_bb_72;
    z_bb_72:
    if ((unsigned char)(resolved != (unsigned int)(18))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    sym->type_id = resolved;
    sym->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_372 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    ckey = zT_372;
    zT_373 = registry;
    zT_374 = ckey;
    zT_375 = resolved;
    zF_5E95558D_nameCachePut(zT_373, zT_374, zT_375);
    zT_376 = (unsigned int)wl_len;
    wl[zT_376] = ai;
    zT_377 = 1;
    zT_379 = wl_len + (unsigned int)((unsigned int)zT_377);
    wl_len = zT_379;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_56;
    z_bb_75:
    zT_388 = 0;
    if ((unsigned char)(wl_len > (unsigned int)zT_388)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_390 = 1;
    zT_392 = wl_len - (unsigned int)((unsigned int)zT_390);
    wl_len = zT_392;
    zT_394 = (unsigned int)wl_len;
    zT_395 = wl[zT_394];
    resolved_idx = zT_395;
    zT_398 = 2;
    zT_399 = (unsigned int)((unsigned int)resolved_idx) * zT_398;
    zT_400 = alias_sym_id[zT_399];
    resolved_mod = zT_400;
    zT_402 = symbol_reg->tables_items;
    zT_403 = (unsigned int)resolved_mod;
    zT_404 = zT_402[zT_403];
    resolved_table = zT_404;
    zT_406 = resolved_table.items;
    zT_408 = 2;
    zT_410 = 1;
    zT_411 = (unsigned int)((unsigned int)((unsigned int)resolved_idx) * zT_408) + zT_410;
    zT_412 = alias_sym_id[zT_411];
    zT_414 = zT_406 + (unsigned int)((unsigned int)zT_412);
    resolved_sym = zT_414;
    zT_416 = resolved_sym->type_id;
    rt = zT_416;
    zT_418 = store;
    zT_419 = resolved_sym->decl_node;
    zT_421 = zF_FCDD1D35_astStoreNodeAt(zT_418, zT_419);
    decl_node = zT_421;
    zT_423 = store;
    zT_424 = resolved_sym->decl_node;
    zT_426 = zF_8BA26B9E_astStoreNodePayload(zT_423, zT_424);
    alias_own_name = zT_426;
    zT_428 = interner;
    zT_429 = alias_own_name;
    zT_430 = zF_9134020D_stringInternerGet(zT_428, zT_429);
    alias_own_text = zT_430;
    zT_432 = interner;
    zT_433 = alias_own_text;
    zT_434 = zF_50C274AF_stringInternerInter(zT_432, zT_433);
    alias_own_canonical = zT_434;
    zT_436 = (unsigned int)alias_own_canonical;
    zT_437 = dep_head[zT_436];
    edge_idx = zT_437;
    goto z_bb_79;
    z_bb_77:
    zT_487 = "KAHN:end\n";
    zT_489 = 9;
    zT_488.ptr = zT_487;
    zT_488.len = zT_489;
    ken_m = zT_488;
    zT_490 = ken_m;
    zF_48AC7B3A_markerWrite(zT_490);
    return;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    if ((unsigned char)(edge_idx != U32_MAX)) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_440 = (unsigned int)edge_idx;
    zT_441 = dep_to[zT_440];
    dep_alias_idx = zT_441;
    zT_444 = 2;
    zT_445 = (unsigned int)((unsigned int)dep_alias_idx) * zT_444;
    zT_446 = alias_sym_id[zT_445];
    dep_mod = zT_446;
    zT_449 = 2;
    zT_451 = 1;
    zT_452 = (unsigned int)((unsigned int)((unsigned int)dep_alias_idx) * zT_449) + zT_451;
    zT_453 = alias_sym_id[zT_452];
    dep_sym_idx = zT_453;
    zT_455 = symbol_reg->tables_items;
    zT_456 = (unsigned int)dep_mod;
    zT_457 = zT_455[zT_456];
    dep_table = zT_457;
    zT_459 = dep_table.items;
    zT_461 = zT_459 + (unsigned int)((unsigned int)dep_sym_idx);
    dep_sym = zT_461;
    zT_462 = dep_sym->type_id;
    zT_463 = 0;
    if ((unsigned char)(zT_462 == (unsigned int)zT_463)) goto z_bb_83; else goto z_bb_84;
    z_bb_81:
    goto z_bb_78;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    dep_sym->type_id = rt;
    dep_sym->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_469 = (unsigned int)dep_alias_idx;
    zT_470 = alias_name[zT_469];
    dep_name = zT_470;
    zT_476 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)dep_mod) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    dkey = zT_476;
    zT_477 = registry;
    zT_478 = dkey;
    zT_479 = rt;
    zF_5E95558D_nameCachePut(zT_477, zT_478, zT_479);
    zT_480 = (unsigned int)wl_len;
    wl[zT_480] = dep_alias_idx;
    zT_481 = 1;
    zT_483 = wl_len + (unsigned int)((unsigned int)zT_481);
    wl_len = zT_483;
    goto z_bb_84;
    z_bb_84:
    zT_484 = (unsigned int)edge_idx;
    zT_485 = dep_next[zT_484];
    edge_idx = zT_485;
    goto z_bb_82;
}

/* __module_init */
void zF_780653D2___module_init_20(void) {
    zT_3D7259E2_SymbolRegistry zT_0 = {0};
    zT_060CD1EB_SymbolTable zT_1 = {0};
    zT_338B7C76_TypeRegistry zT_2 = {0};
    zT_D3EB6303_StringInterner zT_3 = {0};
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_060CD1EB_SymbolTable = zT_1;
    zG_338B7C76_TypeRegistry = zT_2;
    zG_D3EB6303_StringInterner = zT_3;
    return;
}

/* EOF */
