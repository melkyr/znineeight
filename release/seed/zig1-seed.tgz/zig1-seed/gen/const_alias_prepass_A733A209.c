#include "const_alias_prepass_A733A209.h"
/* resolveWellKnownTypeName */
unsigned int zF_0D410D69_resolveWellKnownTyp(zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned int zT_2;
    int zT_3;
    unsigned char* zT_5;
    int zT_6;
    unsigned char zT_7;
    unsigned char zT_10;
    unsigned char* zT_11;
    int zT_12;
    unsigned char zT_13;
    unsigned char zT_16;
    unsigned char* zT_17;
    int zT_18;
    unsigned char zT_19;
    unsigned char zT_22;
    unsigned char* zT_23;
    int zT_24;
    unsigned char zT_25;
    unsigned char* zT_29;
    int zT_30;
    unsigned char zT_31;
    unsigned char zT_34;
    unsigned char* zT_35;
    int zT_36;
    unsigned char zT_37;
    unsigned char zT_40;
    unsigned char* zT_41;
    int zT_42;
    unsigned char zT_43;
    unsigned char zT_46;
    unsigned char* zT_47;
    int zT_48;
    unsigned char zT_49;
    unsigned int zT_54;
    int zT_55;
    unsigned char* zT_57;
    int zT_58;
    unsigned char zT_59;
    unsigned char zT_62;
    unsigned char* zT_63;
    int zT_64;
    unsigned char zT_65;
    unsigned char* zT_68;
    int zT_69;
    unsigned char zT_70;
    unsigned char* zT_74;
    int zT_75;
    unsigned char zT_76;
    unsigned char zT_79;
    unsigned char* zT_80;
    int zT_81;
    unsigned char zT_82;
    unsigned char* zT_85;
    int zT_86;
    unsigned char zT_87;
    unsigned char* zT_91;
    int zT_92;
    unsigned char zT_93;
    unsigned char zT_96;
    unsigned char* zT_97;
    int zT_98;
    unsigned char zT_99;
    unsigned char zT_102;
    unsigned char* zT_103;
    int zT_104;
    unsigned char zT_105;
    unsigned char* zT_109;
    int zT_110;
    unsigned char zT_111;
    unsigned char zT_114;
    unsigned char* zT_115;
    int zT_116;
    unsigned char zT_117;
    unsigned char zT_120;
    unsigned char* zT_121;
    int zT_122;
    unsigned char zT_123;
    unsigned char* zT_127;
    int zT_128;
    unsigned char zT_129;
    unsigned char zT_132;
    unsigned char* zT_133;
    int zT_134;
    unsigned char zT_135;
    unsigned char* zT_138;
    int zT_139;
    unsigned char zT_140;
    unsigned char* zT_144;
    int zT_145;
    unsigned char zT_146;
    unsigned int zT_151;
    int zT_152;
    unsigned char* zT_154;
    int zT_155;
    unsigned char zT_156;
    unsigned char zT_159;
    unsigned char* zT_160;
    int zT_161;
    unsigned char zT_162;
    unsigned char* zT_166;
    int zT_167;
    unsigned char zT_168;
    unsigned char zT_171;
    unsigned char* zT_172;
    int zT_173;
    unsigned char zT_174;
    unsigned int zT_179;
    int zT_180;
    unsigned char* zT_182;
    int zT_183;
    unsigned char zT_184;
    unsigned char zT_187;
    unsigned char* zT_188;
    int zT_189;
    unsigned char zT_190;
    unsigned char zT_193;
    unsigned char* zT_194;
    int zT_195;
    unsigned char zT_196;
    unsigned char zT_199;
    unsigned char* zT_200;
    int zT_201;
    unsigned char zT_202;
    unsigned char zT_205;
    unsigned char* zT_206;
    int zT_207;
    unsigned char zT_208;
    unsigned char* zT_212;
    int zT_213;
    unsigned char zT_214;
    unsigned char zT_217;
    unsigned char* zT_218;
    int zT_219;
    unsigned char zT_220;
    unsigned char zT_223;
    unsigned char* zT_224;
    int zT_225;
    unsigned char zT_226;
    unsigned char zT_229;
    unsigned char* zT_230;
    int zT_231;
    unsigned char zT_232;
    unsigned char zT_235;
    unsigned char* zT_236;
    int zT_237;
    unsigned char zT_238;
    zT_2 = name.len;
    zT_3 = 4;
    if ((unsigned char)(zT_2 == (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = name.ptr;
    zT_6 = 0;
    zT_7 = zT_5[zT_6];
    if ((unsigned char)(zT_7 == (unsigned char)(118))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_54 = name.len;
    zT_55 = 3;
    if ((unsigned char)(zT_54 == (unsigned int)zT_55)) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    zT_11 = name.ptr;
    zT_12 = 1;
    zT_13 = zT_11[zT_12];
    zT_10 = zT_13 == (unsigned char)(111);
    goto z_bb_5;
    z_bb_4:
    zT_10 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_10) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = name.ptr;
    zT_18 = 2;
    zT_19 = zT_17[zT_18];
    zT_16 = zT_19 == (unsigned char)(105);
    goto z_bb_8;
    z_bb_7:
    zT_16 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_16) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_23 = name.ptr;
    zT_24 = 3;
    zT_25 = zT_23[zT_24];
    zT_22 = zT_25 == (unsigned char)(100);
    goto z_bb_11;
    z_bb_10:
    zT_22 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_22) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_29 = name.ptr;
    zT_30 = 0;
    zT_31 = zT_29[zT_30];
    if ((unsigned char)(zT_31 == (unsigned char)(98))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_35 = name.ptr;
    zT_36 = 1;
    zT_37 = zT_35[zT_36];
    zT_34 = zT_37 == (unsigned char)(111);
    goto z_bb_16;
    z_bb_15:
    zT_34 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_34) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_41 = name.ptr;
    zT_42 = 2;
    zT_43 = zT_41[zT_42];
    zT_40 = zT_43 == (unsigned char)(111);
    goto z_bb_19;
    z_bb_18:
    zT_40 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_40) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_47 = name.ptr;
    zT_48 = 3;
    zT_49 = zT_47[zT_48];
    zT_46 = zT_49 == (unsigned char)(108);
    goto z_bb_22;
    z_bb_21:
    zT_46 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_46) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned int)(2);
    z_bb_24:
    goto z_bb_2;
    z_bb_25:
    zT_57 = name.ptr;
    zT_58 = 0;
    zT_59 = zT_57[zT_58];
    if ((unsigned char)(zT_59 == (unsigned char)(105))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_151 = name.len;
    zT_152 = 2;
    if ((unsigned char)(zT_151 == (unsigned int)zT_152)) goto z_bb_66; else goto z_bb_67;
    z_bb_27:
    zT_63 = name.ptr;
    zT_64 = 2;
    zT_65 = zT_63[zT_64];
    zT_62 = zT_65 == (unsigned char)(50);
    goto z_bb_29;
    z_bb_28:
    zT_62 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_62) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_68 = name.ptr;
    zT_69 = 1;
    zT_70 = zT_68[zT_69];
    if ((unsigned char)(zT_70 == (unsigned char)(51))) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_74 = name.ptr;
    zT_75 = 0;
    zT_76 = zT_74[zT_75];
    if ((unsigned char)(zT_76 == (unsigned char)(117))) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    return (unsigned int)(6);
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    zT_80 = name.ptr;
    zT_81 = 2;
    zT_82 = zT_80[zT_81];
    zT_79 = zT_82 == (unsigned char)(50);
    goto z_bb_36;
    z_bb_35:
    zT_79 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_79) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_85 = name.ptr;
    zT_86 = 1;
    zT_87 = zT_85[zT_86];
    if ((unsigned char)(zT_87 == (unsigned char)(51))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_91 = name.ptr;
    zT_92 = 0;
    zT_93 = zT_91[zT_92];
    if ((unsigned char)(zT_93 == (unsigned char)(117))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    return (unsigned int)(10);
    z_bb_40:
    goto z_bb_38;
    z_bb_41:
    zT_97 = name.ptr;
    zT_98 = 1;
    zT_99 = zT_97[zT_98];
    zT_96 = zT_99 == (unsigned char)(54);
    goto z_bb_43;
    z_bb_42:
    zT_96 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_96) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_103 = name.ptr;
    zT_104 = 2;
    zT_105 = zT_103[zT_104];
    zT_102 = zT_105 == (unsigned char)(52);
    goto z_bb_46;
    z_bb_45:
    zT_102 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_102) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned int)(11);
    z_bb_48:
    zT_109 = name.ptr;
    zT_110 = 0;
    zT_111 = zT_109[zT_110];
    if ((unsigned char)(zT_111 == (unsigned char)(105))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_115 = name.ptr;
    zT_116 = 1;
    zT_117 = zT_115[zT_116];
    zT_114 = zT_117 == (unsigned char)(54);
    goto z_bb_51;
    z_bb_50:
    zT_114 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_114) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_121 = name.ptr;
    zT_122 = 2;
    zT_123 = zT_121[zT_122];
    zT_120 = zT_123 == (unsigned char)(52);
    goto z_bb_54;
    z_bb_53:
    zT_120 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_120) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (unsigned int)(7);
    z_bb_56:
    zT_127 = name.ptr;
    zT_128 = 0;
    zT_129 = zT_127[zT_128];
    if ((unsigned char)(zT_129 == (unsigned char)(102))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_133 = name.ptr;
    zT_134 = 2;
    zT_135 = zT_133[zT_134];
    zT_132 = zT_135 == (unsigned char)(50);
    goto z_bb_59;
    z_bb_58:
    zT_132 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_132) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_138 = name.ptr;
    zT_139 = 1;
    zT_140 = zT_138[zT_139];
    if ((unsigned char)(zT_140 == (unsigned char)(51))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    goto z_bb_26;
    z_bb_62:
    return (unsigned int)(15);
    z_bb_63:
    zT_144 = name.ptr;
    zT_145 = 1;
    zT_146 = zT_144[zT_145];
    if ((unsigned char)(zT_146 == (unsigned char)(54))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    return (unsigned int)(16);
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_154 = name.ptr;
    zT_155 = 0;
    zT_156 = zT_154[zT_155];
    if ((unsigned char)(zT_156 == (unsigned char)(105))) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    zT_179 = name.len;
    zT_180 = 5;
    if ((unsigned char)(zT_179 == (unsigned int)zT_180)) goto z_bb_78; else goto z_bb_79;
    z_bb_68:
    zT_160 = name.ptr;
    zT_161 = 1;
    zT_162 = zT_160[zT_161];
    zT_159 = zT_162 == (unsigned char)(56);
    goto z_bb_70;
    z_bb_69:
    zT_159 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_159) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    return (unsigned int)(4);
    z_bb_72:
    zT_166 = name.ptr;
    zT_167 = 0;
    zT_168 = zT_166[zT_167];
    if ((unsigned char)(zT_168 == (unsigned char)(117))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_172 = name.ptr;
    zT_173 = 1;
    zT_174 = zT_172[zT_173];
    zT_171 = zT_174 == (unsigned char)(56);
    goto z_bb_75;
    z_bb_74:
    zT_171 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_171) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    return (unsigned int)(8);
    z_bb_77:
    goto z_bb_67;
    z_bb_78:
    zT_182 = name.ptr;
    zT_183 = 0;
    zT_184 = zT_182[zT_183];
    if ((unsigned char)(zT_184 == (unsigned char)(117))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    return (unsigned int)(18);
    z_bb_80:
    zT_188 = name.ptr;
    zT_189 = 1;
    zT_190 = zT_188[zT_189];
    zT_187 = zT_190 == (unsigned char)(115);
    goto z_bb_82;
    z_bb_81:
    zT_187 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_187) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_194 = name.ptr;
    zT_195 = 2;
    zT_196 = zT_194[zT_195];
    zT_193 = zT_196 == (unsigned char)(105);
    goto z_bb_85;
    z_bb_84:
    zT_193 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_193) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_200 = name.ptr;
    zT_201 = 3;
    zT_202 = zT_200[zT_201];
    zT_199 = zT_202 == (unsigned char)(122);
    goto z_bb_88;
    z_bb_87:
    zT_199 = 0;
    goto z_bb_88;
    z_bb_88:
    if (zT_199) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_206 = name.ptr;
    zT_207 = 4;
    zT_208 = zT_206[zT_207];
    zT_205 = zT_208 == (unsigned char)(101);
    goto z_bb_91;
    z_bb_90:
    zT_205 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_205) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    return (unsigned int)(13);
    z_bb_93:
    zT_212 = name.ptr;
    zT_213 = 0;
    zT_214 = zT_212[zT_213];
    if ((unsigned char)(zT_214 == (unsigned char)(105))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_218 = name.ptr;
    zT_219 = 1;
    zT_220 = zT_218[zT_219];
    zT_217 = zT_220 == (unsigned char)(115);
    goto z_bb_96;
    z_bb_95:
    zT_217 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_217) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_224 = name.ptr;
    zT_225 = 2;
    zT_226 = zT_224[zT_225];
    zT_223 = zT_226 == (unsigned char)(105);
    goto z_bb_99;
    z_bb_98:
    zT_223 = 0;
    goto z_bb_99;
    z_bb_99:
    if (zT_223) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_230 = name.ptr;
    zT_231 = 3;
    zT_232 = zT_230[zT_231];
    zT_229 = zT_232 == (unsigned char)(122);
    goto z_bb_102;
    z_bb_101:
    zT_229 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_229) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_236 = name.ptr;
    zT_237 = 4;
    zT_238 = zT_236[zT_237];
    zT_235 = zT_238 == (unsigned char)(101);
    goto z_bb_105;
    z_bb_104:
    zT_235 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_235) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    return (unsigned int)(12);
    z_bb_107:
    goto z_bb_79;
}

/* growDep */
void zF_62CBE4C7_growDep(zT_3E40CD83_Sand* perm, unsigned int** to_ptr, unsigned int** next_ptr, unsigned int* cap_ptr) {
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    int zT_10;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_13;
    zT_ACA03DB3_EU_632 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_ACA03DB3_EU_632 zT_34 = {0};
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_52;
    unsigned int nc;
    unsigned char* ntr;
    unsigned int* nto;
    unsigned char* nnr;
    unsigned int* nno;
    unsigned int ci;
    zT_5 = *cap_ptr;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    nc = zT_7;
    zT_8 = 16;
    if ((unsigned char)(nc < (unsigned int)zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = 16;
    zT_11 = (unsigned int)zT_10;
    nc = zT_11;
    goto z_bb_2;
    z_bb_2:
    zT_13 = perm;
    zT_20 = zF_1395EB68_sandAlloc(zT_13, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)nc)), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_22 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    ntr = zT_22;
    zT_25 = (unsigned int*)ntr;
    nto = zT_25;
    zT_27 = perm;
    zT_34 = zF_1395EB68_sandAlloc(zT_27, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)nc)), (unsigned int)(4));
    zT_35 = zT_34.is_error;
    if (zT_35) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_36 = zT_34.data.payload;
    goto z_bb_8;
    z_bb_8:
    nnr = zT_36;
    zT_39 = (unsigned int*)nnr;
    nno = zT_39;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ci = zT_42;
    goto z_bb_9;
    z_bb_9:
    zT_43 = *cap_ptr;
    if ((unsigned char)(ci < (unsigned int)((unsigned int)zT_43))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = *to_ptr;
    zT_47 = zT_46[ci];
    nto[ci] = zT_47;
    zT_48 = *next_ptr;
    zT_49 = zT_48[ci];
    nno[ci] = zT_49;
    goto z_bb_12;
    z_bb_11:
    *to_ptr = nto;
    *next_ptr = nno;
    *cap_ptr = nc;
    return;
    z_bb_12:
    zT_50 = 1;
    zT_52 = ci + (unsigned int)((unsigned int)zT_50);
    ci = zT_52;
    goto z_bb_9;
}

/* constAliasPrepass */
void zF_EF7F7D3C_constAliasPrepass(zT_3D7259E2_SymbolRegistry* symbol_reg, zT_338B7C76_TypeRegistry* registry, zT_D3EB6303_StringInterner* interner, zT_6B0A7D14_AstStore* store, zT_3E40CD83_Sand* perm_alloc) {
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    int zT_11;
    unsigned int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_060CD1EB_SymbolTable* zT_18;
    zT_060CD1EB_SymbolTable zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_3E40CD83_Sand* zT_47;
    unsigned int zT_49;
    zT_ACA03DB3_EU_632 zT_52 = {0};
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned int* zT_57;
    zT_3E40CD83_Sand* zT_59;
    unsigned int zT_61;
    zT_ACA03DB3_EU_632 zT_64 = {0};
    unsigned char zT_65;
    unsigned char* zT_66;
    unsigned int* zT_69;
    unsigned int zT_71;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_76;
    unsigned int zT_78;
    zT_ACA03DB3_EU_632 zT_80 = {0};
    unsigned char zT_81;
    unsigned char* zT_82;
    unsigned int* zT_85;
    int zT_87;
    unsigned int zT_88;
    int zT_90;
    unsigned int zT_92;
    int zT_94;
    unsigned int zT_95;
    zT_3E40CD83_Sand* zT_97;
    unsigned int zT_99;
    zT_ACA03DB3_EU_632 zT_102 = {0};
    unsigned char zT_103;
    unsigned char* zT_104;
    unsigned int* zT_107;
    int zT_109;
    unsigned int zT_110;
    zT_3E40CD83_Sand* zT_112;
    unsigned int zT_114;
    zT_ACA03DB3_EU_632 zT_117 = {0};
    unsigned char zT_118;
    unsigned char* zT_119;
    unsigned int* zT_122;
    zT_3E40CD83_Sand* zT_124;
    unsigned int zT_126;
    int zT_129;
    zT_ACA03DB3_EU_632 zT_131 = {0};
    unsigned char zT_132;
    unsigned char* zT_133;
    unsigned int* zT_136;
    int zT_138;
    unsigned int zT_139;
    int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_060CD1EB_SymbolTable* zT_146;
    zT_060CD1EB_SymbolTable zT_147;
    int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_3A105EF1_Symbol* zT_154;
    zT_3A105EF1_Symbol* zT_155;
    zT_3C598AEF_SymbolKind zT_156;
    unsigned char* zT_161;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165;
    unsigned int zT_167;
    int zT_168;
    unsigned char* zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    unsigned int zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    zT_6B0A7D14_AstStore* zT_176;
    unsigned int zT_177;
    zT_22A7C88B_AstNode zT_179 = {0};
    zT_8143F551_AstKind zT_180;
    int zT_181;
    unsigned char* zT_184;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_185;
    unsigned int zT_186;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_187;
    zT_8143F551_AstKind zT_189;
    unsigned int zT_191;
    int zT_192;
    unsigned char* zT_195;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_196;
    unsigned int zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    zT_6B0A7D14_AstStore* zT_200;
    unsigned int zT_201;
    zT_22A7C88B_AstNode zT_203 = {0};
    unsigned char* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    zT_8143F551_AstKind zT_210;
    zT_8143F551_AstKind zT_212;
    int zT_213;
    zT_6B0A7D14_AstStore* zT_216;
    unsigned int zT_217;
    unsigned int zT_219 = 0;
    unsigned char* zT_221;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_222;
    unsigned int zT_223;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_224;
    unsigned int zT_225;
    zT_D3EB6303_StringInterner* zT_227;
    unsigned int zT_228;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_229 = {0};
    zT_D3EB6303_StringInterner* zT_231;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_232;
    unsigned int zT_233 = 0;
    unsigned int zT_234;
    unsigned int zT_235;
    int zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    int zT_241;
    int zT_243;
    unsigned int zT_244;
    zT_3E40CD83_Sand* zT_246;
    unsigned int** zT_247;
    unsigned int** zT_248;
    unsigned int* zT_249;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    int zT_258;
    unsigned int zT_260;
    int zT_261;
    unsigned int zT_263;
    int zT_264;
    unsigned int zT_266;
    int zT_267;
    unsigned int zT_269;
    unsigned char* zT_271;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_272;
    unsigned int zT_273;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_274;
    unsigned int zT_275;
    int zT_276;
    unsigned char* zT_279;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_280;
    unsigned int zT_281;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_282;
    int zT_284;
    unsigned int zT_285;
    unsigned int zT_288;
    unsigned int zT_289;
    int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    int zT_297;
    int zT_299;
    unsigned int zT_300;
    unsigned int zT_301;
    zT_060CD1EB_SymbolTable* zT_303;
    unsigned int zT_304;
    zT_060CD1EB_SymbolTable zT_305;
    zT_3A105EF1_Symbol* zT_307;
    zT_3A105EF1_Symbol* zT_309;
    unsigned int zT_312;
    zT_79FAE712_u64 zT_318;
    zT_338B7C76_TypeRegistry* zT_319;
    zT_79FAE712_u64 zT_320;
    zT_BAEE192E_Opt_10 zT_321 = {0};
    unsigned char zT_322;
    zT_338B7C76_TypeRegistry* zT_326;
    zT_BAEE192E_Opt_10 zT_329 = {0};
    unsigned char zT_330;
    int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    zT_79FAE712_u64 zT_344;
    zT_338B7C76_TypeRegistry* zT_345;
    zT_79FAE712_u64 zT_346;
    zT_BAEE192E_Opt_10 zT_347 = {0};
    unsigned char zT_348;
    int zT_350;
    unsigned int zT_352;
    zT_D3EB6303_StringInterner* zT_356;
    unsigned int zT_357;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_358 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_359;
    unsigned int zT_360 = 0;
    zT_79FAE712_u64 zT_370;
    zT_338B7C76_TypeRegistry* zT_371;
    zT_79FAE712_u64 zT_372;
    unsigned int zT_373;
    unsigned int zT_374;
    int zT_375;
    unsigned int zT_377;
    int zT_378;
    unsigned int zT_380;
    unsigned char* zT_382;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_383;
    unsigned int zT_384;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_385;
    int zT_386;
    int zT_388;
    unsigned int zT_390;
    unsigned int zT_392;
    unsigned int zT_393;
    int zT_396;
    unsigned int zT_397;
    unsigned int zT_398;
    zT_060CD1EB_SymbolTable* zT_400;
    unsigned int zT_401;
    zT_060CD1EB_SymbolTable zT_402;
    zT_3A105EF1_Symbol* zT_404;
    int zT_406;
    int zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    zT_3A105EF1_Symbol* zT_412;
    unsigned int zT_414;
    zT_6B0A7D14_AstStore* zT_416;
    unsigned int zT_417;
    zT_22A7C88B_AstNode zT_419 = {0};
    zT_6B0A7D14_AstStore* zT_421;
    unsigned int zT_422;
    unsigned int zT_424 = 0;
    zT_D3EB6303_StringInterner* zT_426;
    unsigned int zT_427;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_428 = {0};
    zT_D3EB6303_StringInterner* zT_430;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_431;
    unsigned int zT_432 = 0;
    unsigned int zT_434;
    unsigned int zT_435;
    unsigned int zT_438;
    unsigned int zT_439;
    int zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    int zT_447;
    int zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    zT_060CD1EB_SymbolTable* zT_453;
    unsigned int zT_454;
    zT_060CD1EB_SymbolTable zT_455;
    zT_3A105EF1_Symbol* zT_457;
    zT_3A105EF1_Symbol* zT_459;
    unsigned int zT_460;
    int zT_461;
    unsigned int zT_466;
    unsigned int zT_467;
    zT_79FAE712_u64 zT_473;
    zT_338B7C76_TypeRegistry* zT_474;
    zT_79FAE712_u64 zT_475;
    unsigned int zT_476;
    unsigned int zT_477;
    int zT_478;
    unsigned int zT_480;
    unsigned int zT_481;
    unsigned int zT_482;
    unsigned char* zT_484;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_485;
    unsigned int zT_486;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_487;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_m;
    unsigned int tl;
    unsigned int cti;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_tm;
    unsigned int SZ_U32;
    unsigned int U32_MAX;
    unsigned int dep_cap;
    unsigned char* dep_to_raw;
    unsigned int* dep_to;
    unsigned char* dep_next_raw;
    unsigned int* dep_next;
    unsigned int head_cap;
    unsigned char* dep_head_raw;
    unsigned int* dep_head;
    unsigned int si0;
    unsigned int dep_count;
    unsigned char* wl_raw;
    unsigned int* wl;
    unsigned int wl_len;
    unsigned char* alias_name_raw;
    unsigned int* alias_name;
    unsigned char* alias_sym_raw;
    unsigned int* alias_sym_id;
    unsigned int alias_count;
    unsigned int mi;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_acm;
    zT_3A105EF1_Symbol* sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u g0_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u g1_m;
    zT_22A7C88B_AstNode decl_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u g2_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u g3_m;
    zT_22A7C88B_AstNode init;
    zT_8F083A69_Slice_zT_0B42B2F8_u c1_m;
    unsigned int dep_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u c2_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u dep_text;
    unsigned int dep_canonical;
    unsigned int ai;
    unsigned int mod_id;
    unsigned int sym_idx;
    unsigned int resolved;
    zT_79FAE712_u64 mod_key;
    zT_8F083A69_Slice_zT_0B42B2F8_u kst_m;
    unsigned int tid;
    unsigned int cmi;
    zT_79FAE712_u64 ckey;
    zT_8F083A69_Slice_zT_0B42B2F8_u name_str;
    unsigned int resolved_idx;
    unsigned int resolved_mod;
    zT_060CD1EB_SymbolTable resolved_table;
    zT_3A105EF1_Symbol* resolved_sym;
    unsigned int rt;
    unsigned int alias_own_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u alias_own_text;
    unsigned int alias_own_canonical;
    unsigned int edge_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u ken_m;
    unsigned int dep_alias_idx;
    unsigned int dep_mod;
    unsigned int dep_sym_idx;
    zT_060CD1EB_SymbolTable dep_table;
    zT_3A105EF1_Symbol* dep_sym;
    zT_79FAE712_u64 dkey;
    zT_6 = "CAP:ent\n";
    zT_8 = 8;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    cap_m = zT_7;
    zT_9 = cap_m;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    tl = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    cti = zT_15;
    goto z_bb_1;
    z_bb_1:
    zT_16 = symbol_reg->tables_len;
    if ((unsigned char)(cti < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_18 = symbol_reg->tables_items;
    zT_19 = zT_18[cti];
    zT_20 = zT_19.len;
    zT_22 = tl + (unsigned int)((unsigned int)zT_20);
    tl = zT_22;
    goto z_bb_4;
    z_bb_3:
    zT_27 = "CAP:tlm";
    zT_29 = 7;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    cap_tm = zT_28;
    zT_30 = cap_tm;
    zT_31 = tl;
    zF_C914CB83_markerWriteInt(zT_30, zT_31);
    zT_32 = 0;
    if ((unsigned char)(tl == (unsigned int)zT_32)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_25 = cti + (unsigned int)((unsigned int)zT_23);
    cti = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_35 = "CAP:tl0\n";
    zT_37 = 8;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    cap_m = zT_36;
    zT_38 = cap_m;
    zF_48AC7B3A_markerWrite(zT_38);
    return;
    z_bb_6:
    zT_40 = 4;
    zT_41 = (unsigned int)zT_40;
    SZ_U32 = zT_41;
    zT_43 = 4294967295u;
    zT_44 = (unsigned int)zT_43;
    U32_MAX = zT_44;
    dep_cap = tl;
    zT_47 = perm_alloc;
    zT_49 = SZ_U32;
    zT_52 = zF_1395EB68_sandAlloc(zT_47, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_49);
    zT_53 = zT_52.is_error;
    if (zT_53) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_54 = zT_52.data.payload;
    goto z_bb_9;
    z_bb_9:
    dep_to_raw = zT_54;
    zT_57 = (unsigned int*)dep_to_raw;
    dep_to = zT_57;
    zT_59 = perm_alloc;
    zT_61 = SZ_U32;
    zT_64 = zF_1395EB68_sandAlloc(zT_59, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_61);
    zT_65 = zT_64.is_error;
    if (zT_65) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_66 = zT_64.data.payload;
    goto z_bb_12;
    z_bb_12:
    dep_next_raw = zT_66;
    zT_69 = (unsigned int*)dep_next_raw;
    dep_next = zT_69;
    zT_71 = interner->entries_len;
    head_cap = zT_71;
    if ((unsigned char)(head_cap < (unsigned int)((unsigned int)tl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_74 = (unsigned int)tl;
    head_cap = zT_74;
    goto z_bb_14;
    z_bb_14:
    zT_76 = perm_alloc;
    zT_78 = SZ_U32;
    zT_80 = zF_1395EB68_sandAlloc(zT_76, (unsigned int)(SZ_U32 * head_cap), zT_78);
    zT_81 = zT_80.is_error;
    if (zT_81) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    pal_trap();
    z_bb_16:
    zT_82 = zT_80.data.payload;
    goto z_bb_17;
    z_bb_17:
    dep_head_raw = zT_82;
    zT_85 = (unsigned int*)dep_head_raw;
    dep_head = zT_85;
    zT_87 = 0;
    zT_88 = (unsigned int)zT_87;
    si0 = zT_88;
    goto z_bb_18;
    z_bb_18:
    if ((unsigned char)(si0 < head_cap)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    dep_head[si0] = U32_MAX;
    goto z_bb_21;
    z_bb_20:
    zT_94 = 0;
    zT_95 = (unsigned int)zT_94;
    dep_count = zT_95;
    zT_97 = perm_alloc;
    zT_99 = SZ_U32;
    zT_102 = zF_1395EB68_sandAlloc(zT_97, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_99);
    zT_103 = zT_102.is_error;
    if (zT_103) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_90 = 1;
    zT_92 = si0 + (unsigned int)((unsigned int)zT_90);
    si0 = zT_92;
    goto z_bb_18;
    z_bb_22:
    pal_trap();
    z_bb_23:
    zT_104 = zT_102.data.payload;
    goto z_bb_24;
    z_bb_24:
    wl_raw = zT_104;
    zT_107 = (unsigned int*)wl_raw;
    wl = zT_107;
    zT_109 = 0;
    zT_110 = (unsigned int)zT_109;
    wl_len = zT_110;
    zT_112 = perm_alloc;
    zT_114 = SZ_U32;
    zT_117 = zF_1395EB68_sandAlloc(zT_112, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_114);
    zT_118 = zT_117.is_error;
    if (zT_118) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    pal_trap();
    z_bb_26:
    zT_119 = zT_117.data.payload;
    goto z_bb_27;
    z_bb_27:
    alias_name_raw = zT_119;
    zT_122 = (unsigned int*)alias_name_raw;
    alias_name = zT_122;
    zT_124 = perm_alloc;
    zT_129 = 2;
    zT_126 = SZ_U32;
    zT_131 = zF_1395EB68_sandAlloc(zT_124, (unsigned int)((unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)) * zT_129), zT_126);
    zT_132 = zT_131.is_error;
    if (zT_132) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    pal_trap();
    z_bb_29:
    zT_133 = zT_131.data.payload;
    goto z_bb_30;
    z_bb_30:
    alias_sym_raw = zT_133;
    zT_136 = (unsigned int*)alias_sym_raw;
    alias_sym_id = zT_136;
    zT_138 = 0;
    zT_139 = (unsigned int)zT_138;
    alias_count = zT_139;
    zT_141 = 0;
    zT_142 = (unsigned int)zT_141;
    mi = zT_142;
    goto z_bb_31;
    z_bb_31:
    zT_143 = symbol_reg->tables_len;
    if ((unsigned char)(mi < zT_143)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_146 = symbol_reg->tables_items;
    zT_147 = zT_146[mi];
    table = zT_147;
    zT_149 = 0;
    zT_150 = (unsigned int)zT_149;
    si = zT_150;
    goto z_bb_35;
    z_bb_33:
    zT_271 = "CAP:ac";
    zT_273 = 6;
    zT_272.ptr = zT_271;
    zT_272.len = zT_273;
    cap_acm = zT_272;
    zT_274 = cap_acm;
    zT_275 = alias_count;
    zF_C914CB83_markerWriteInt(zT_274, zT_275);
    zT_276 = 0;
    if ((unsigned char)(alias_count == (unsigned int)zT_276)) goto z_bb_51; else goto z_bb_52;
    z_bb_34:
    zT_267 = 1;
    zT_269 = mi + (unsigned int)((unsigned int)zT_267);
    mi = zT_269;
    goto z_bb_31;
    z_bb_35:
    zT_151 = table.len;
    if ((unsigned char)(si < zT_151)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_154 = table.items;
    zT_155 = zT_154 + si;
    sym = zT_155;
    zT_156 = sym->kind;
    if ((unsigned char)(zT_156 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_264 = 1;
    zT_266 = si + (unsigned int)((unsigned int)zT_264);
    si = zT_266;
    goto z_bb_35;
    z_bb_39:
    goto z_bb_38;
    z_bb_40:
    zT_161 = "GATE:g0";
    zT_163 = 7;
    zT_162.ptr = zT_161;
    zT_162.len = zT_163;
    g0_m = zT_162;
    zT_164 = g0_m;
    zT_165 = sym->type_id;
    zF_C914CB83_markerWriteInt(zT_164, zT_165);
    zT_167 = sym->type_id;
    zT_168 = 0;
    if ((unsigned char)(zT_167 != (unsigned int)zT_168)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_171 = "GATE:g1\n";
    zT_173 = 8;
    zT_172.ptr = zT_171;
    zT_172.len = zT_173;
    g1_m = zT_172;
    zT_174 = g1_m;
    zF_48AC7B3A_markerWrite(zT_174);
    zT_176 = store;
    zT_177 = sym->decl_node;
    zT_179 = zF_FCDD1D35_astStoreNodeAt(zT_176, zT_177);
    decl_node = zT_179;
    zT_180 = decl_node.kind;
    zT_181 = 1;
    if ((unsigned char)(zT_180 != zT_181)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_184 = "GATE:g2";
    zT_186 = 7;
    zT_185.ptr = zT_184;
    zT_185.len = zT_186;
    g2_m = zT_185;
    zT_187 = g2_m;
    zT_189 = decl_node.kind;
    zF_C914CB83_markerWriteInt(zT_187, (unsigned int)((unsigned int)zT_189));
    goto z_bb_38;
    z_bb_44:
    zT_191 = decl_node.child_1;
    zT_192 = 0;
    if ((unsigned char)(zT_191 == (unsigned int)zT_192)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_195 = "GATE:g3\n";
    zT_197 = 8;
    zT_196.ptr = zT_195;
    zT_196.len = zT_197;
    g3_m = zT_196;
    zT_198 = g3_m;
    zF_48AC7B3A_markerWrite(zT_198);
    goto z_bb_38;
    z_bb_46:
    zT_200 = store;
    zT_201 = decl_node.child_1;
    zT_203 = zF_FCDD1D35_astStoreNodeAt(zT_200, zT_201);
    init = zT_203;
    zT_205 = "CAT:ik";
    zT_207 = 6;
    zT_206.ptr = zT_205;
    zT_206.len = zT_207;
    c1_m = zT_206;
    zT_208 = c1_m;
    zT_210 = init.kind;
    zF_C914CB83_markerWriteInt(zT_208, (unsigned int)((unsigned int)zT_210));
    zT_212 = init.kind;
    zT_213 = 24;
    if ((unsigned char)(zT_212 != zT_213)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_38;
    z_bb_48:
    zT_216 = store;
    zT_217 = decl_node.child_1;
    zT_219 = zF_53458827_astStoreIdentifier(zT_216, zT_217);
    dep_name = zT_219;
    zT_221 = "CAT:dn";
    zT_223 = 6;
    zT_222.ptr = zT_221;
    zT_222.len = zT_223;
    c2_m = zT_222;
    zT_224 = c2_m;
    zT_225 = dep_name;
    zF_C914CB83_markerWriteInt(zT_224, zT_225);
    zT_227 = interner;
    zT_228 = dep_name;
    zT_229 = zF_9134020D_stringInternerGet(zT_227, zT_228);
    dep_text = zT_229;
    zT_231 = interner;
    zT_232 = dep_text;
    zT_233 = zF_50C274AF_stringInternerInter(zT_231, zT_232);
    dep_canonical = zT_233;
    zT_234 = (unsigned int)alias_count;
    alias_name[zT_234] = dep_canonical;
    zT_235 = (unsigned int)mi;
    zT_237 = 2;
    zT_238 = (unsigned int)((unsigned int)alias_count) * zT_237;
    alias_sym_id[zT_238] = zT_235;
    zT_239 = (unsigned int)si;
    zT_241 = 2;
    zT_243 = 1;
    zT_244 = (unsigned int)((unsigned int)((unsigned int)alias_count) * zT_241) + zT_243;
    alias_sym_id[zT_244] = zT_239;
    if ((unsigned char)(dep_count >= dep_cap)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_246 = perm_alloc;
    zT_247 = &dep_to;
    zT_248 = &dep_next;
    zT_249 = &dep_cap;
    zF_62CBE4C7_growDep(zT_246, zT_247, zT_248, zT_249);
    goto z_bb_50;
    z_bb_50:
    zT_253 = (unsigned int)dep_count;
    dep_to[zT_253] = alias_count;
    zT_254 = (unsigned int)dep_canonical;
    zT_255 = dep_head[zT_254];
    zT_256 = (unsigned int)dep_count;
    dep_next[zT_256] = zT_255;
    zT_257 = (unsigned int)dep_canonical;
    dep_head[zT_257] = dep_count;
    zT_258 = 1;
    zT_260 = dep_count + (unsigned int)((unsigned int)zT_258);
    dep_count = zT_260;
    zT_261 = 1;
    zT_263 = alias_count + (unsigned int)((unsigned int)zT_261);
    alias_count = zT_263;
    goto z_bb_38;
    z_bb_51:
    zT_279 = "CAP:ac0\n";
    zT_281 = 8;
    zT_280.ptr = zT_279;
    zT_280.len = zT_281;
    cap_m = zT_280;
    zT_282 = cap_m;
    zF_48AC7B3A_markerWrite(zT_282);
    return;
    z_bb_52:
    zT_284 = 0;
    zT_285 = (unsigned int)zT_284;
    ai = zT_285;
    goto z_bb_53;
    z_bb_53:
    if ((unsigned char)(ai < alias_count)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_288 = (unsigned int)ai;
    zT_289 = alias_name[zT_288];
    dep_name = zT_289;
    zT_292 = 2;
    zT_293 = (unsigned int)((unsigned int)ai) * zT_292;
    zT_294 = alias_sym_id[zT_293];
    mod_id = zT_294;
    zT_297 = 2;
    zT_299 = 1;
    zT_300 = (unsigned int)((unsigned int)((unsigned int)ai) * zT_297) + zT_299;
    zT_301 = alias_sym_id[zT_300];
    sym_idx = zT_301;
    zT_303 = symbol_reg->tables_items;
    zT_304 = (unsigned int)mod_id;
    zT_305 = zT_303[zT_304];
    table = zT_305;
    zT_307 = table.items;
    zT_309 = zT_307 + (unsigned int)((unsigned int)sym_idx);
    sym = zT_309;
    zT_312 = 18;
    resolved = zT_312;
    zT_318 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    mod_key = zT_318;
    zT_319 = registry;
    zT_320 = mod_key;
    zT_321 = zF_0EB68360_nameCacheGet(zT_319, zT_320);
    zT_322 = zT_321.has_value;
    if (zT_322) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    zT_382 = "KAHN:start\n";
    zT_384 = 11;
    zT_383.ptr = zT_382;
    zT_383.len = zT_384;
    kst_m = zT_383;
    zT_385 = kst_m;
    zF_48AC7B3A_markerWrite(zT_385);
    goto z_bb_75;
    z_bb_56:
    zT_378 = 1;
    zT_380 = ai + (unsigned int)((unsigned int)zT_378);
    ai = zT_380;
    goto z_bb_53;
    z_bb_57:
    tid = zT_321.value;
    resolved = tid;
    goto z_bb_58;
    z_bb_58:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_326 = registry;
    zT_329 = zF_0EB68360_nameCacheGet(zT_326, (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name));
    zT_330 = zT_329.has_value;
    if (zT_330) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    tid = zT_329.value;
    resolved = tid;
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_335 = 0;
    zT_336 = (unsigned int)zT_335;
    cmi = zT_336;
    goto z_bb_65;
    z_bb_64:
    if ((unsigned char)(resolved == (unsigned int)(18))) goto z_bb_71; else goto z_bb_72;
    z_bb_65:
    zT_337 = symbol_reg->tables_len;
    if ((unsigned char)(cmi < zT_337)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_344 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)cmi) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    ckey = zT_344;
    zT_345 = registry;
    zT_346 = ckey;
    zT_347 = zF_0EB68360_nameCacheGet(zT_345, zT_346);
    zT_348 = zT_347.has_value;
    if (zT_348) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_350 = 1;
    zT_352 = cmi + (unsigned int)((unsigned int)zT_350);
    cmi = zT_352;
    goto z_bb_65;
    z_bb_69:
    tid = zT_347.value;
    resolved = tid;
    goto z_bb_67;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_356 = interner;
    zT_357 = dep_name;
    zT_358 = zF_9134020D_stringInternerGet(zT_356, zT_357);
    name_str = zT_358;
    zT_359 = name_str;
    zT_360 = zF_0D410D69_resolveWellKnownTyp(zT_359);
    resolved = zT_360;
    goto z_bb_72;
    z_bb_72:
    if ((unsigned char)(resolved != (unsigned int)(18))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    sym->type_id = resolved;
    sym->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_370 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    ckey = zT_370;
    zT_371 = registry;
    zT_372 = ckey;
    zT_373 = resolved;
    zF_5E95558D_nameCachePut(zT_371, zT_372, zT_373);
    zT_374 = (unsigned int)wl_len;
    wl[zT_374] = ai;
    zT_375 = 1;
    zT_377 = wl_len + (unsigned int)((unsigned int)zT_375);
    wl_len = zT_377;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_56;
    z_bb_75:
    zT_386 = 0;
    if ((unsigned char)(wl_len > (unsigned int)zT_386)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_388 = 1;
    zT_390 = wl_len - (unsigned int)((unsigned int)zT_388);
    wl_len = zT_390;
    zT_392 = (unsigned int)wl_len;
    zT_393 = wl[zT_392];
    resolved_idx = zT_393;
    zT_396 = 2;
    zT_397 = (unsigned int)((unsigned int)resolved_idx) * zT_396;
    zT_398 = alias_sym_id[zT_397];
    resolved_mod = zT_398;
    zT_400 = symbol_reg->tables_items;
    zT_401 = (unsigned int)resolved_mod;
    zT_402 = zT_400[zT_401];
    resolved_table = zT_402;
    zT_404 = resolved_table.items;
    zT_406 = 2;
    zT_408 = 1;
    zT_409 = (unsigned int)((unsigned int)((unsigned int)resolved_idx) * zT_406) + zT_408;
    zT_410 = alias_sym_id[zT_409];
    zT_412 = zT_404 + (unsigned int)((unsigned int)zT_410);
    resolved_sym = zT_412;
    zT_414 = resolved_sym->type_id;
    rt = zT_414;
    zT_416 = store;
    zT_417 = resolved_sym->decl_node;
    zT_419 = zF_FCDD1D35_astStoreNodeAt(zT_416, zT_417);
    decl_node = zT_419;
    zT_421 = store;
    zT_422 = resolved_sym->decl_node;
    zT_424 = zF_8BA26B9E_astStoreNodePayload(zT_421, zT_422);
    alias_own_name = zT_424;
    zT_426 = interner;
    zT_427 = alias_own_name;
    zT_428 = zF_9134020D_stringInternerGet(zT_426, zT_427);
    alias_own_text = zT_428;
    zT_430 = interner;
    zT_431 = alias_own_text;
    zT_432 = zF_50C274AF_stringInternerInter(zT_430, zT_431);
    alias_own_canonical = zT_432;
    zT_434 = (unsigned int)alias_own_canonical;
    zT_435 = dep_head[zT_434];
    edge_idx = zT_435;
    goto z_bb_79;
    z_bb_77:
    zT_484 = "KAHN:end\n";
    zT_486 = 9;
    zT_485.ptr = zT_484;
    zT_485.len = zT_486;
    ken_m = zT_485;
    zT_487 = ken_m;
    zF_48AC7B3A_markerWrite(zT_487);
    return;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    if ((unsigned char)(edge_idx != U32_MAX)) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_438 = (unsigned int)edge_idx;
    zT_439 = dep_to[zT_438];
    dep_alias_idx = zT_439;
    zT_442 = 2;
    zT_443 = (unsigned int)((unsigned int)dep_alias_idx) * zT_442;
    zT_444 = alias_sym_id[zT_443];
    dep_mod = zT_444;
    zT_447 = 2;
    zT_449 = 1;
    zT_450 = (unsigned int)((unsigned int)((unsigned int)dep_alias_idx) * zT_447) + zT_449;
    zT_451 = alias_sym_id[zT_450];
    dep_sym_idx = zT_451;
    zT_453 = symbol_reg->tables_items;
    zT_454 = (unsigned int)dep_mod;
    zT_455 = zT_453[zT_454];
    dep_table = zT_455;
    zT_457 = dep_table.items;
    zT_459 = zT_457 + (unsigned int)((unsigned int)dep_sym_idx);
    dep_sym = zT_459;
    zT_460 = dep_sym->type_id;
    zT_461 = 0;
    if ((unsigned char)(zT_460 == (unsigned int)zT_461)) goto z_bb_83; else goto z_bb_84;
    z_bb_81:
    goto z_bb_78;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    dep_sym->type_id = rt;
    dep_sym->kind = (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_type_alias);
    zT_466 = (unsigned int)dep_alias_idx;
    zT_467 = alias_name[zT_466];
    dep_name = zT_467;
    zT_473 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)dep_mod) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    dkey = zT_473;
    zT_474 = registry;
    zT_475 = dkey;
    zT_476 = rt;
    zF_5E95558D_nameCachePut(zT_474, zT_475, zT_476);
    zT_477 = (unsigned int)wl_len;
    wl[zT_477] = dep_alias_idx;
    zT_478 = 1;
    zT_480 = wl_len + (unsigned int)((unsigned int)zT_478);
    wl_len = zT_480;
    goto z_bb_84;
    z_bb_84:
    zT_481 = (unsigned int)edge_idx;
    zT_482 = dep_next[zT_481];
    edge_idx = zT_482;
    goto z_bb_82;
}

/* __module_init */
void zF_780653D2___module_init_20(void) {
    zT_3D7259E2_SymbolRegistry zT_0 = {0};
    zT_060CD1EB_SymbolTable zT_1 = {0};
    zT_338B7C76_TypeRegistry zT_2 = {0};
    zT_D3EB6303_StringInterner zT_3 = {0};
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_060CD1EB_SymbolTable = zT_1;
    zG_338B7C76_TypeRegistry = zT_2;
    zG_D3EB6303_StringInterner = zT_3;
    return;
}

/* EOF */
