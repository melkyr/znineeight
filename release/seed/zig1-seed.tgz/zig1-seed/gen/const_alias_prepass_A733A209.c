#include "const_alias_prepass_A733A209.h"
/* resolveWellKnownTypeName */
unsigned int zF_0D410D69_resolveWellKnownTyp(zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned int zT_2;
    int zT_3;
    unsigned char* zT_5;
    int zT_6;
    unsigned char zT_7;
    int zT_10;
    unsigned char* zT_11;
    int zT_12;
    unsigned char zT_13;
    int zT_16;
    unsigned char* zT_17;
    int zT_18;
    unsigned char zT_19;
    int zT_22;
    unsigned char* zT_23;
    int zT_24;
    unsigned char zT_25;
    unsigned char* zT_29;
    int zT_30;
    unsigned char zT_31;
    int zT_34;
    unsigned char* zT_35;
    int zT_36;
    unsigned char zT_37;
    int zT_40;
    unsigned char* zT_41;
    int zT_42;
    unsigned char zT_43;
    int zT_46;
    unsigned char* zT_47;
    int zT_48;
    unsigned char zT_49;
    unsigned int zT_54;
    int zT_55;
    unsigned char* zT_57;
    int zT_58;
    unsigned char zT_59;
    int zT_62;
    unsigned char* zT_63;
    int zT_64;
    unsigned char zT_65;
    unsigned char* zT_68;
    int zT_69;
    unsigned char zT_70;
    unsigned char* zT_74;
    int zT_75;
    unsigned char zT_76;
    int zT_79;
    unsigned char* zT_80;
    int zT_81;
    unsigned char zT_82;
    unsigned char* zT_85;
    int zT_86;
    unsigned char zT_87;
    unsigned char* zT_91;
    int zT_92;
    unsigned char zT_93;
    int zT_96;
    unsigned char* zT_97;
    int zT_98;
    unsigned char zT_99;
    int zT_102;
    unsigned char* zT_103;
    int zT_104;
    unsigned char zT_105;
    unsigned char* zT_109;
    int zT_110;
    unsigned char zT_111;
    int zT_114;
    unsigned char* zT_115;
    int zT_116;
    unsigned char zT_117;
    int zT_120;
    unsigned char* zT_121;
    int zT_122;
    unsigned char zT_123;
    unsigned char* zT_127;
    int zT_128;
    unsigned char zT_129;
    int zT_132;
    unsigned char* zT_133;
    int zT_134;
    unsigned char zT_135;
    unsigned char* zT_138;
    int zT_139;
    unsigned char zT_140;
    unsigned char* zT_144;
    int zT_145;
    unsigned char zT_146;
    unsigned int zT_151;
    int zT_152;
    unsigned char* zT_154;
    int zT_155;
    unsigned char zT_156;
    int zT_159;
    unsigned char* zT_160;
    int zT_161;
    unsigned char zT_162;
    unsigned char* zT_166;
    int zT_167;
    unsigned char zT_168;
    int zT_171;
    unsigned char* zT_172;
    int zT_173;
    unsigned char zT_174;
    unsigned int zT_179;
    int zT_180;
    unsigned char* zT_182;
    int zT_183;
    unsigned char zT_184;
    int zT_187;
    unsigned char* zT_188;
    int zT_189;
    unsigned char zT_190;
    int zT_193;
    unsigned char* zT_194;
    int zT_195;
    unsigned char zT_196;
    int zT_199;
    unsigned char* zT_200;
    int zT_201;
    unsigned char zT_202;
    int zT_205;
    unsigned char* zT_206;
    int zT_207;
    unsigned char zT_208;
    unsigned char* zT_212;
    int zT_213;
    unsigned char zT_214;
    int zT_217;
    unsigned char* zT_218;
    int zT_219;
    unsigned char zT_220;
    int zT_223;
    unsigned char* zT_224;
    int zT_225;
    unsigned char zT_226;
    int zT_229;
    unsigned char* zT_230;
    int zT_231;
    unsigned char zT_232;
    int zT_235;
    unsigned char* zT_236;
    int zT_237;
    unsigned char zT_238;
    zT_2 = name.len;
    zT_3 = 4;
    if ((int)(zT_2 == (unsigned int)zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = name.ptr;
    zT_6 = 0;
    zT_7 = zT_5[zT_6];
    if ((int)(zT_7 == (unsigned char)(118))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_54 = name.len;
    zT_55 = 3;
    if ((int)(zT_54 == (unsigned int)zT_55)) goto z_bb_25; else goto z_bb_26;
    z_bb_3:
    zT_11 = name.ptr;
    zT_12 = 1;
    zT_13 = zT_11[zT_12];
    zT_10 = zT_13 == (unsigned char)(111);
    goto z_bb_5;
    z_bb_4:
    zT_10 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_10) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = name.ptr;
    zT_18 = 2;
    zT_19 = zT_17[zT_18];
    zT_16 = zT_19 == (unsigned char)(105);
    goto z_bb_8;
    z_bb_7:
    zT_16 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_16) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_23 = name.ptr;
    zT_24 = 3;
    zT_25 = zT_23[zT_24];
    zT_22 = zT_25 == (unsigned char)(100);
    goto z_bb_11;
    z_bb_10:
    zT_22 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_22) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned int)(1);
    z_bb_13:
    zT_29 = name.ptr;
    zT_30 = 0;
    zT_31 = zT_29[zT_30];
    if ((int)(zT_31 == (unsigned char)(98))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_35 = name.ptr;
    zT_36 = 1;
    zT_37 = zT_35[zT_36];
    zT_34 = zT_37 == (unsigned char)(111);
    goto z_bb_16;
    z_bb_15:
    zT_34 = 0;
    goto z_bb_16;
    z_bb_16:
    if (zT_34) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_41 = name.ptr;
    zT_42 = 2;
    zT_43 = zT_41[zT_42];
    zT_40 = zT_43 == (unsigned char)(111);
    goto z_bb_19;
    z_bb_18:
    zT_40 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_40) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_47 = name.ptr;
    zT_48 = 3;
    zT_49 = zT_47[zT_48];
    zT_46 = zT_49 == (unsigned char)(108);
    goto z_bb_22;
    z_bb_21:
    zT_46 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_46) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned int)(2);
    z_bb_24:
    goto z_bb_2;
    z_bb_25:
    zT_57 = name.ptr;
    zT_58 = 0;
    zT_59 = zT_57[zT_58];
    if ((int)(zT_59 == (unsigned char)(105))) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_151 = name.len;
    zT_152 = 2;
    if ((int)(zT_151 == (unsigned int)zT_152)) goto z_bb_66; else goto z_bb_67;
    z_bb_27:
    zT_63 = name.ptr;
    zT_64 = 2;
    zT_65 = zT_63[zT_64];
    zT_62 = zT_65 == (unsigned char)(50);
    goto z_bb_29;
    z_bb_28:
    zT_62 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_62) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_68 = name.ptr;
    zT_69 = 1;
    zT_70 = zT_68[zT_69];
    if ((int)(zT_70 == (unsigned char)(51))) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_74 = name.ptr;
    zT_75 = 0;
    zT_76 = zT_74[zT_75];
    if ((int)(zT_76 == (unsigned char)(117))) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    return (unsigned int)(6);
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    zT_80 = name.ptr;
    zT_81 = 2;
    zT_82 = zT_80[zT_81];
    zT_79 = zT_82 == (unsigned char)(50);
    goto z_bb_36;
    z_bb_35:
    zT_79 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_79) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_85 = name.ptr;
    zT_86 = 1;
    zT_87 = zT_85[zT_86];
    if ((int)(zT_87 == (unsigned char)(51))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_91 = name.ptr;
    zT_92 = 0;
    zT_93 = zT_91[zT_92];
    if ((int)(zT_93 == (unsigned char)(117))) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    return (unsigned int)(10);
    z_bb_40:
    goto z_bb_38;
    z_bb_41:
    zT_97 = name.ptr;
    zT_98 = 1;
    zT_99 = zT_97[zT_98];
    zT_96 = zT_99 == (unsigned char)(54);
    goto z_bb_43;
    z_bb_42:
    zT_96 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_96) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_103 = name.ptr;
    zT_104 = 2;
    zT_105 = zT_103[zT_104];
    zT_102 = zT_105 == (unsigned char)(52);
    goto z_bb_46;
    z_bb_45:
    zT_102 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_102) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned int)(11);
    z_bb_48:
    zT_109 = name.ptr;
    zT_110 = 0;
    zT_111 = zT_109[zT_110];
    if ((int)(zT_111 == (unsigned char)(105))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_115 = name.ptr;
    zT_116 = 1;
    zT_117 = zT_115[zT_116];
    zT_114 = zT_117 == (unsigned char)(54);
    goto z_bb_51;
    z_bb_50:
    zT_114 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_114) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_121 = name.ptr;
    zT_122 = 2;
    zT_123 = zT_121[zT_122];
    zT_120 = zT_123 == (unsigned char)(52);
    goto z_bb_54;
    z_bb_53:
    zT_120 = 0;
    goto z_bb_54;
    z_bb_54:
    if (zT_120) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    return (unsigned int)(7);
    z_bb_56:
    zT_127 = name.ptr;
    zT_128 = 0;
    zT_129 = zT_127[zT_128];
    if ((int)(zT_129 == (unsigned char)(102))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_133 = name.ptr;
    zT_134 = 2;
    zT_135 = zT_133[zT_134];
    zT_132 = zT_135 == (unsigned char)(50);
    goto z_bb_59;
    z_bb_58:
    zT_132 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_132) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_138 = name.ptr;
    zT_139 = 1;
    zT_140 = zT_138[zT_139];
    if ((int)(zT_140 == (unsigned char)(51))) goto z_bb_62; else goto z_bb_63;
    z_bb_61:
    goto z_bb_26;
    z_bb_62:
    return (unsigned int)(15);
    z_bb_63:
    zT_144 = name.ptr;
    zT_145 = 1;
    zT_146 = zT_144[zT_145];
    if ((int)(zT_146 == (unsigned char)(54))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    return (unsigned int)(16);
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_154 = name.ptr;
    zT_155 = 0;
    zT_156 = zT_154[zT_155];
    if ((int)(zT_156 == (unsigned char)(105))) goto z_bb_68; else goto z_bb_69;
    z_bb_67:
    zT_179 = name.len;
    zT_180 = 5;
    if ((int)(zT_179 == (unsigned int)zT_180)) goto z_bb_78; else goto z_bb_79;
    z_bb_68:
    zT_160 = name.ptr;
    zT_161 = 1;
    zT_162 = zT_160[zT_161];
    zT_159 = zT_162 == (unsigned char)(56);
    goto z_bb_70;
    z_bb_69:
    zT_159 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_159) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    return (unsigned int)(4);
    z_bb_72:
    zT_166 = name.ptr;
    zT_167 = 0;
    zT_168 = zT_166[zT_167];
    if ((int)(zT_168 == (unsigned char)(117))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_172 = name.ptr;
    zT_173 = 1;
    zT_174 = zT_172[zT_173];
    zT_171 = zT_174 == (unsigned char)(56);
    goto z_bb_75;
    z_bb_74:
    zT_171 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_171) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    return (unsigned int)(8);
    z_bb_77:
    goto z_bb_67;
    z_bb_78:
    zT_182 = name.ptr;
    zT_183 = 0;
    zT_184 = zT_182[zT_183];
    if ((int)(zT_184 == (unsigned char)(117))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    return (unsigned int)(18);
    z_bb_80:
    zT_188 = name.ptr;
    zT_189 = 1;
    zT_190 = zT_188[zT_189];
    zT_187 = zT_190 == (unsigned char)(115);
    goto z_bb_82;
    z_bb_81:
    zT_187 = 0;
    goto z_bb_82;
    z_bb_82:
    if (zT_187) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_194 = name.ptr;
    zT_195 = 2;
    zT_196 = zT_194[zT_195];
    zT_193 = zT_196 == (unsigned char)(105);
    goto z_bb_85;
    z_bb_84:
    zT_193 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_193) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_200 = name.ptr;
    zT_201 = 3;
    zT_202 = zT_200[zT_201];
    zT_199 = zT_202 == (unsigned char)(122);
    goto z_bb_88;
    z_bb_87:
    zT_199 = 0;
    goto z_bb_88;
    z_bb_88:
    if (zT_199) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_206 = name.ptr;
    zT_207 = 4;
    zT_208 = zT_206[zT_207];
    zT_205 = zT_208 == (unsigned char)(101);
    goto z_bb_91;
    z_bb_90:
    zT_205 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_205) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    return (unsigned int)(13);
    z_bb_93:
    zT_212 = name.ptr;
    zT_213 = 0;
    zT_214 = zT_212[zT_213];
    if ((int)(zT_214 == (unsigned char)(105))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_218 = name.ptr;
    zT_219 = 1;
    zT_220 = zT_218[zT_219];
    zT_217 = zT_220 == (unsigned char)(115);
    goto z_bb_96;
    z_bb_95:
    zT_217 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_217) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_224 = name.ptr;
    zT_225 = 2;
    zT_226 = zT_224[zT_225];
    zT_223 = zT_226 == (unsigned char)(105);
    goto z_bb_99;
    z_bb_98:
    zT_223 = 0;
    goto z_bb_99;
    z_bb_99:
    if (zT_223) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_230 = name.ptr;
    zT_231 = 3;
    zT_232 = zT_230[zT_231];
    zT_229 = zT_232 == (unsigned char)(122);
    goto z_bb_102;
    z_bb_101:
    zT_229 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_229) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_236 = name.ptr;
    zT_237 = 4;
    zT_238 = zT_236[zT_237];
    zT_235 = zT_238 == (unsigned char)(101);
    goto z_bb_105;
    z_bb_104:
    zT_235 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_235) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    return (unsigned int)(12);
    z_bb_107:
    goto z_bb_79;
}

/* growDep */
void zF_62CBE4C7_growDep(zT_3E40CD83_Sand* perm, unsigned int** to_ptr, unsigned int** next_ptr, unsigned int* cap_ptr) {
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    int zT_10;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_13;
    zT_0F51E4CA_EU_222 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    unsigned int* zT_25;
    zT_3E40CD83_Sand* zT_27;
    zT_0F51E4CA_EU_222 zT_34 = {0};
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int nc;
    unsigned char* ntr;
    unsigned int* nto;
    unsigned char* nnr;
    unsigned int* nno;
    unsigned int ci;
    zT_5 = *cap_ptr;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    nc = zT_7;
    zT_8 = 16;
    if ((int)(nc < (unsigned int)zT_8)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = 16;
    zT_11 = (unsigned int)zT_10;
    nc = zT_11;
    goto z_bb_2;
    z_bb_2:
    zT_13 = perm;
    zT_20 = zF_1395EB68_sandAlloc(zT_13, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)nc)), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    z_bb_4:
    zT_22 = zT_20.data.payload;
    goto z_bb_5;
    z_bb_5:
    ntr = zT_22;
    zT_25 = (unsigned int*)ntr;
    nto = zT_25;
    zT_27 = perm;
    zT_34 = zF_1395EB68_sandAlloc(zT_27, (unsigned int)((unsigned int)(4) * (unsigned int)((unsigned int)nc)), (unsigned int)(4));
    zT_35 = zT_34.is_error;
    if (zT_35) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    z_bb_7:
    zT_36 = zT_34.data.payload;
    goto z_bb_8;
    z_bb_8:
    nnr = zT_36;
    zT_39 = (unsigned int*)nnr;
    nno = zT_39;
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ci = zT_42;
    goto z_bb_9;
    z_bb_9:
    zT_43 = *cap_ptr;
    if ((int)(ci < (unsigned int)((unsigned int)zT_43))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_46 = *to_ptr;
    zT_47 = zT_46[ci];
    nto[ci] = zT_47;
    zT_48 = *next_ptr;
    zT_49 = zT_48[ci];
    nno[ci] = zT_49;
    goto z_bb_12;
    z_bb_11:
    *to_ptr = nto;
    *next_ptr = nno;
    *cap_ptr = nc;
    return;
    z_bb_12:
    zT_50 = 1;
    zT_51 = ci + zT_50;
    ci = zT_51;
    goto z_bb_9;
}

/* constAliasPrepass */
void zF_EF7F7D3C_constAliasPrepass(zT_3D7259E2_SymbolRegistry* symbol_reg, zT_338B7C76_TypeRegistry* registry, zT_D3EB6303_StringInterner* interner, zT_6B0A7D14_AstStore* store, zT_3E40CD83_Sand* perm_alloc) {
    char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    int zT_11;
    unsigned int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_060CD1EB_SymbolTable* zT_18;
    zT_060CD1EB_SymbolTable zT_19;
    unsigned int zT_20;
    unsigned int zT_22;
    int zT_23;
    unsigned int zT_24;
    char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    int zT_31;
    char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_3E40CD83_Sand* zT_46;
    unsigned int zT_48;
    zT_0F51E4CA_EU_222 zT_51 = {0};
    unsigned char zT_52;
    unsigned char* zT_53;
    unsigned int* zT_56;
    zT_3E40CD83_Sand* zT_58;
    unsigned int zT_60;
    zT_0F51E4CA_EU_222 zT_63 = {0};
    unsigned char zT_64;
    unsigned char* zT_65;
    unsigned int* zT_68;
    unsigned int zT_70;
    unsigned int zT_73;
    zT_3E40CD83_Sand* zT_75;
    unsigned int zT_77;
    zT_0F51E4CA_EU_222 zT_79 = {0};
    unsigned char zT_80;
    unsigned char* zT_81;
    unsigned int* zT_84;
    int zT_86;
    unsigned int zT_87;
    int zT_89;
    unsigned int zT_90;
    int zT_92;
    unsigned int zT_93;
    zT_3E40CD83_Sand* zT_95;
    unsigned int zT_97;
    zT_0F51E4CA_EU_222 zT_100 = {0};
    unsigned char zT_101;
    unsigned char* zT_102;
    unsigned int* zT_105;
    int zT_107;
    unsigned int zT_108;
    zT_3E40CD83_Sand* zT_110;
    unsigned int zT_112;
    zT_0F51E4CA_EU_222 zT_115 = {0};
    unsigned char zT_116;
    unsigned char* zT_117;
    unsigned int* zT_120;
    zT_3E40CD83_Sand* zT_122;
    unsigned int zT_124;
    int zT_127;
    zT_0F51E4CA_EU_222 zT_129 = {0};
    unsigned char zT_130;
    unsigned char* zT_131;
    unsigned int* zT_134;
    int zT_136;
    unsigned int zT_137;
    int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    zT_060CD1EB_SymbolTable* zT_144;
    zT_060CD1EB_SymbolTable zT_145;
    int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_3A105EF1_Symbol* zT_152;
    zT_3A105EF1_Symbol* zT_153;
    zT_3C598AEF_SymbolKind zT_154;
    char* zT_160;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_161;
    unsigned int zT_162;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_163;
    unsigned int zT_164;
    unsigned int zT_166;
    int zT_167;
    char* zT_170;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_171;
    unsigned int zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    zT_6B0A7D14_AstStore* zT_175;
    unsigned int zT_176;
    zT_22A7C88B_AstNode zT_178 = {0};
    zT_8143F551_AstKind zT_179;
    int zT_180;
    char* zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    unsigned int zT_185;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_186;
    zT_8143F551_AstKind zT_188;
    unsigned int zT_190;
    int zT_191;
    char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    zT_6B0A7D14_AstStore* zT_199;
    unsigned int zT_200;
    zT_22A7C88B_AstNode zT_202 = {0};
    char* zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned int zT_206;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_207;
    zT_8143F551_AstKind zT_209;
    zT_8143F551_AstKind zT_211;
    int zT_212;
    zT_6B0A7D14_AstStore* zT_215;
    unsigned int zT_216;
    unsigned int zT_218 = 0;
    char* zT_220;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_221;
    unsigned int zT_222;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_223;
    unsigned int zT_224;
    zT_D3EB6303_StringInterner* zT_226;
    unsigned int zT_227;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_228 = {0};
    zT_D3EB6303_StringInterner* zT_230;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_231;
    unsigned int zT_232 = 0;
    unsigned int zT_233;
    unsigned int zT_234;
    int zT_236;
    unsigned int zT_237;
    unsigned int zT_238;
    int zT_240;
    int zT_242;
    unsigned int zT_243;
    zT_3E40CD83_Sand* zT_245;
    unsigned int** zT_246;
    unsigned int** zT_247;
    unsigned int* zT_248;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    int zT_257;
    unsigned int zT_259;
    int zT_260;
    unsigned int zT_262;
    int zT_263;
    unsigned int zT_264;
    int zT_265;
    unsigned int zT_266;
    char* zT_268;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_269;
    unsigned int zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    int zT_273;
    char* zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    int zT_281;
    unsigned int zT_282;
    unsigned int zT_285;
    unsigned int zT_286;
    int zT_289;
    unsigned int zT_290;
    unsigned int zT_291;
    int zT_294;
    int zT_296;
    unsigned int zT_297;
    unsigned int zT_298;
    zT_060CD1EB_SymbolTable* zT_300;
    unsigned int zT_301;
    zT_060CD1EB_SymbolTable zT_302;
    zT_3A105EF1_Symbol* zT_304;
    zT_3A105EF1_Symbol* zT_306;
    unsigned int zT_309;
    zT_79FAE712_u64 zT_315;
    zT_338B7C76_TypeRegistry* zT_316;
    zT_79FAE712_u64 zT_317;
    zT_BAEE192E_Opt_10 zT_318 = {0};
    unsigned char zT_319;
    zT_338B7C76_TypeRegistry* zT_323;
    zT_BAEE192E_Opt_10 zT_326 = {0};
    unsigned char zT_327;
    int zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    zT_79FAE712_u64 zT_341;
    zT_338B7C76_TypeRegistry* zT_342;
    zT_79FAE712_u64 zT_343;
    zT_BAEE192E_Opt_10 zT_344 = {0};
    unsigned char zT_345;
    int zT_347;
    unsigned int zT_348;
    zT_D3EB6303_StringInterner* zT_352;
    unsigned int zT_353;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_354 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_355;
    unsigned int zT_356 = 0;
    zT_79FAE712_u64 zT_364;
    zT_338B7C76_TypeRegistry* zT_365;
    zT_79FAE712_u64 zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    int zT_369;
    unsigned int zT_371;
    int zT_372;
    unsigned int zT_373;
    char* zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    unsigned int zT_377;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_378;
    int zT_379;
    int zT_381;
    unsigned int zT_383;
    unsigned int zT_385;
    unsigned int zT_386;
    int zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    zT_060CD1EB_SymbolTable* zT_393;
    unsigned int zT_394;
    zT_060CD1EB_SymbolTable zT_395;
    zT_3A105EF1_Symbol* zT_397;
    int zT_399;
    int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    zT_3A105EF1_Symbol* zT_405;
    unsigned int zT_407;
    zT_6B0A7D14_AstStore* zT_409;
    unsigned int zT_410;
    zT_22A7C88B_AstNode zT_412 = {0};
    zT_6B0A7D14_AstStore* zT_414;
    unsigned int zT_415;
    unsigned int zT_417 = 0;
    zT_D3EB6303_StringInterner* zT_419;
    unsigned int zT_420;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_421 = {0};
    zT_D3EB6303_StringInterner* zT_423;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_424;
    unsigned int zT_425 = 0;
    unsigned int zT_427;
    unsigned int zT_428;
    unsigned int zT_431;
    unsigned int zT_432;
    int zT_435;
    unsigned int zT_436;
    unsigned int zT_437;
    int zT_440;
    int zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    zT_060CD1EB_SymbolTable* zT_446;
    unsigned int zT_447;
    zT_060CD1EB_SymbolTable zT_448;
    zT_3A105EF1_Symbol* zT_450;
    zT_3A105EF1_Symbol* zT_452;
    unsigned int zT_453;
    int zT_454;
    unsigned int zT_457;
    unsigned int zT_458;
    zT_79FAE712_u64 zT_464;
    zT_338B7C76_TypeRegistry* zT_465;
    zT_79FAE712_u64 zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    int zT_469;
    unsigned int zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    char* zT_475;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_476;
    unsigned int zT_477;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_478;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_m;
    unsigned int tl;
    unsigned int cti;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_tm;
    unsigned int SZ_U32;
    unsigned int U32_MAX;
    unsigned int dep_cap;
    unsigned char* dep_to_raw;
    unsigned int* dep_to;
    unsigned char* dep_next_raw;
    unsigned int* dep_next;
    unsigned int head_cap;
    unsigned char* dep_head_raw;
    unsigned int* dep_head;
    unsigned int si0;
    unsigned int dep_count;
    unsigned char* wl_raw;
    unsigned int* wl;
    unsigned int wl_len;
    unsigned char* alias_name_raw;
    unsigned int* alias_name;
    unsigned char* alias_sym_raw;
    unsigned int* alias_sym_id;
    unsigned int alias_count;
    unsigned int mi;
    zT_060CD1EB_SymbolTable table;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u cap_acm;
    zT_3A105EF1_Symbol* sym;
    zT_8F083A69_Slice_zT_0B42B2F8_u g0_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u g1_m;
    zT_22A7C88B_AstNode decl_node;
    zT_8F083A69_Slice_zT_0B42B2F8_u g2_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u g3_m;
    zT_22A7C88B_AstNode init;
    zT_8F083A69_Slice_zT_0B42B2F8_u c1_m;
    unsigned int dep_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u c2_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u dep_text;
    unsigned int dep_canonical;
    unsigned int ai;
    unsigned int mod_id;
    unsigned int sym_idx;
    unsigned int resolved;
    zT_79FAE712_u64 mod_key;
    zT_8F083A69_Slice_zT_0B42B2F8_u kst_m;
    unsigned int tid;
    unsigned int cmi;
    zT_79FAE712_u64 ckey;
    zT_8F083A69_Slice_zT_0B42B2F8_u name_str;
    unsigned int resolved_idx;
    unsigned int resolved_mod;
    zT_060CD1EB_SymbolTable resolved_table;
    zT_3A105EF1_Symbol* resolved_sym;
    unsigned int rt;
    unsigned int alias_own_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u alias_own_text;
    unsigned int alias_own_canonical;
    unsigned int edge_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u ken_m;
    unsigned int dep_alias_idx;
    unsigned int dep_mod;
    unsigned int dep_sym_idx;
    zT_060CD1EB_SymbolTable dep_table;
    zT_3A105EF1_Symbol* dep_sym;
    zT_79FAE712_u64 dkey;
    zT_6 = "CAP:ent\n";
    zT_8 = 8;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    cap_m = zT_7;
    zT_9 = cap_m;
    zF_48AC7B3A_markerWrite(zT_9);
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    tl = zT_12;
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    cti = zT_15;
    goto z_bb_1;
    z_bb_1:
    zT_16 = symbol_reg->tables_len;
    if ((int)(cti < zT_16)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_18 = symbol_reg->tables_items;
    zT_19 = zT_18[cti];
    zT_20 = zT_19.len;
    zT_22 = tl + (unsigned int)((unsigned int)zT_20);
    tl = zT_22;
    goto z_bb_4;
    z_bb_3:
    zT_26 = "CAP:tlm";
    zT_28 = 7;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    cap_tm = zT_27;
    zT_29 = cap_tm;
    zT_30 = tl;
    zF_C914CB83_markerWriteInt(zT_29, zT_30);
    zT_31 = 0;
    if ((int)(tl == (unsigned int)zT_31)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_23 = 1;
    zT_24 = cti + zT_23;
    cti = zT_24;
    goto z_bb_1;
    z_bb_5:
    zT_34 = "CAP:tl0\n";
    zT_36 = 8;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    cap_m = zT_35;
    zT_37 = cap_m;
    zF_48AC7B3A_markerWrite(zT_37);
    return;
    z_bb_6:
    zT_39 = 4;
    zT_40 = (unsigned int)zT_39;
    SZ_U32 = zT_40;
    zT_42 = 4294967295u;
    zT_43 = (unsigned int)zT_42;
    U32_MAX = zT_43;
    dep_cap = tl;
    zT_46 = perm_alloc;
    zT_48 = SZ_U32;
    zT_51 = zF_1395EB68_sandAlloc(zT_46, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_48);
    zT_52 = zT_51.is_error;
    if (zT_52) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    z_bb_8:
    zT_53 = zT_51.data.payload;
    goto z_bb_9;
    z_bb_9:
    dep_to_raw = zT_53;
    zT_56 = (unsigned int*)dep_to_raw;
    dep_to = zT_56;
    zT_58 = perm_alloc;
    zT_60 = SZ_U32;
    zT_63 = zF_1395EB68_sandAlloc(zT_58, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_60);
    zT_64 = zT_63.is_error;
    if (zT_64) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    z_bb_11:
    zT_65 = zT_63.data.payload;
    goto z_bb_12;
    z_bb_12:
    dep_next_raw = zT_65;
    zT_68 = (unsigned int*)dep_next_raw;
    dep_next = zT_68;
    zT_70 = interner->entries_len;
    head_cap = zT_70;
    if ((int)(head_cap < (unsigned int)((unsigned int)tl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_73 = (unsigned int)tl;
    head_cap = zT_73;
    goto z_bb_14;
    z_bb_14:
    zT_75 = perm_alloc;
    zT_77 = SZ_U32;
    zT_79 = zF_1395EB68_sandAlloc(zT_75, (unsigned int)(SZ_U32 * head_cap), zT_77);
    zT_80 = zT_79.is_error;
    if (zT_80) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    z_bb_16:
    zT_81 = zT_79.data.payload;
    goto z_bb_17;
    z_bb_17:
    dep_head_raw = zT_81;
    zT_84 = (unsigned int*)dep_head_raw;
    dep_head = zT_84;
    zT_86 = 0;
    zT_87 = (unsigned int)zT_86;
    si0 = zT_87;
    goto z_bb_18;
    z_bb_18:
    if ((int)(si0 < head_cap)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    dep_head[si0] = U32_MAX;
    goto z_bb_21;
    z_bb_20:
    zT_92 = 0;
    zT_93 = (unsigned int)zT_92;
    dep_count = zT_93;
    zT_95 = perm_alloc;
    zT_97 = SZ_U32;
    zT_100 = zF_1395EB68_sandAlloc(zT_95, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_97);
    zT_101 = zT_100.is_error;
    if (zT_101) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_89 = 1;
    zT_90 = si0 + zT_89;
    si0 = zT_90;
    goto z_bb_18;
    z_bb_22:
    z_bb_23:
    zT_102 = zT_100.data.payload;
    goto z_bb_24;
    z_bb_24:
    wl_raw = zT_102;
    zT_105 = (unsigned int*)wl_raw;
    wl = zT_105;
    zT_107 = 0;
    zT_108 = (unsigned int)zT_107;
    wl_len = zT_108;
    zT_110 = perm_alloc;
    zT_112 = SZ_U32;
    zT_115 = zF_1395EB68_sandAlloc(zT_110, (unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)), zT_112);
    zT_116 = zT_115.is_error;
    if (zT_116) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    z_bb_26:
    zT_117 = zT_115.data.payload;
    goto z_bb_27;
    z_bb_27:
    alias_name_raw = zT_117;
    zT_120 = (unsigned int*)alias_name_raw;
    alias_name = zT_120;
    zT_122 = perm_alloc;
    zT_127 = 2;
    zT_124 = SZ_U32;
    zT_129 = zF_1395EB68_sandAlloc(zT_122, (unsigned int)((unsigned int)(SZ_U32 * (unsigned int)((unsigned int)tl)) * zT_127), zT_124);
    zT_130 = zT_129.is_error;
    if (zT_130) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    z_bb_29:
    zT_131 = zT_129.data.payload;
    goto z_bb_30;
    z_bb_30:
    alias_sym_raw = zT_131;
    zT_134 = (unsigned int*)alias_sym_raw;
    alias_sym_id = zT_134;
    zT_136 = 0;
    zT_137 = (unsigned int)zT_136;
    alias_count = zT_137;
    zT_139 = 0;
    zT_140 = (unsigned int)zT_139;
    mi = zT_140;
    goto z_bb_31;
    z_bb_31:
    zT_141 = symbol_reg->tables_len;
    if ((int)(mi < zT_141)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_144 = symbol_reg->tables_items;
    zT_145 = zT_144[mi];
    table = zT_145;
    zT_147 = 0;
    zT_148 = (unsigned int)zT_147;
    si = zT_148;
    goto z_bb_35;
    z_bb_33:
    zT_268 = "CAP:ac";
    zT_270 = 6;
    zT_269.ptr = zT_268;
    zT_269.len = zT_270;
    cap_acm = zT_269;
    zT_271 = cap_acm;
    zT_272 = alias_count;
    zF_C914CB83_markerWriteInt(zT_271, zT_272);
    zT_273 = 0;
    if ((int)(alias_count == (unsigned int)zT_273)) goto z_bb_51; else goto z_bb_52;
    z_bb_34:
    zT_265 = 1;
    zT_266 = mi + zT_265;
    mi = zT_266;
    goto z_bb_31;
    z_bb_35:
    zT_149 = table.len;
    if ((int)(si < zT_149)) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_152 = table.items;
    zT_153 = zT_152 + si;
    sym = zT_153;
    zT_154 = sym->kind;
    if ((int)(zT_154 != (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_global))) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_263 = 1;
    zT_264 = si + zT_263;
    si = zT_264;
    goto z_bb_35;
    z_bb_39:
    goto z_bb_38;
    z_bb_40:
    zT_160 = "GATE:g0";
    zT_162 = 7;
    zT_161.ptr = zT_160;
    zT_161.len = zT_162;
    g0_m = zT_161;
    zT_163 = g0_m;
    zT_164 = sym->type_id;
    zF_C914CB83_markerWriteInt(zT_163, zT_164);
    zT_166 = sym->type_id;
    zT_167 = 0;
    if ((int)(zT_166 != (unsigned int)zT_167)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_170 = "GATE:g1\n";
    zT_172 = 8;
    zT_171.ptr = zT_170;
    zT_171.len = zT_172;
    g1_m = zT_171;
    zT_173 = g1_m;
    zF_48AC7B3A_markerWrite(zT_173);
    zT_175 = store;
    zT_176 = sym->decl_node;
    zT_178 = zF_FCDD1D35_astStoreNodeAt(zT_175, zT_176);
    decl_node = zT_178;
    zT_179 = decl_node.kind;
    zT_180 = 1;
    if ((int)(zT_179 != zT_180)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_183 = "GATE:g2";
    zT_185 = 7;
    zT_184.ptr = zT_183;
    zT_184.len = zT_185;
    g2_m = zT_184;
    zT_186 = g2_m;
    zT_188 = decl_node.kind;
    zF_C914CB83_markerWriteInt(zT_186, (unsigned int)((unsigned int)zT_188));
    goto z_bb_38;
    z_bb_44:
    zT_190 = decl_node.child_1;
    zT_191 = 0;
    if ((int)(zT_190 == (unsigned int)zT_191)) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_194 = "GATE:g3\n";
    zT_196 = 8;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    g3_m = zT_195;
    zT_197 = g3_m;
    zF_48AC7B3A_markerWrite(zT_197);
    goto z_bb_38;
    z_bb_46:
    zT_199 = store;
    zT_200 = decl_node.child_1;
    zT_202 = zF_FCDD1D35_astStoreNodeAt(zT_199, zT_200);
    init = zT_202;
    zT_204 = "CAT:ik";
    zT_206 = 6;
    zT_205.ptr = zT_204;
    zT_205.len = zT_206;
    c1_m = zT_205;
    zT_207 = c1_m;
    zT_209 = init.kind;
    zF_C914CB83_markerWriteInt(zT_207, (unsigned int)((unsigned int)zT_209));
    zT_211 = init.kind;
    zT_212 = 24;
    if ((int)(zT_211 != zT_212)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_38;
    z_bb_48:
    zT_215 = store;
    zT_216 = decl_node.child_1;
    zT_218 = zF_53458827_astStoreIdentifier(zT_215, zT_216);
    dep_name = zT_218;
    zT_220 = "CAT:dn";
    zT_222 = 6;
    zT_221.ptr = zT_220;
    zT_221.len = zT_222;
    c2_m = zT_221;
    zT_223 = c2_m;
    zT_224 = dep_name;
    zF_C914CB83_markerWriteInt(zT_223, zT_224);
    zT_226 = interner;
    zT_227 = dep_name;
    zT_228 = zF_9134020D_stringInternerGet(zT_226, zT_227);
    dep_text = zT_228;
    zT_230 = interner;
    zT_231 = dep_text;
    zT_232 = zF_50C274AF_stringInternerInter(zT_230, zT_231);
    dep_canonical = zT_232;
    zT_233 = (unsigned int)alias_count;
    alias_name[zT_233] = dep_canonical;
    zT_234 = (unsigned int)mi;
    zT_236 = 2;
    zT_237 = (unsigned int)((unsigned int)alias_count) * zT_236;
    alias_sym_id[zT_237] = zT_234;
    zT_238 = (unsigned int)si;
    zT_240 = 2;
    zT_242 = 1;
    zT_243 = (unsigned int)((unsigned int)((unsigned int)alias_count) * zT_240) + zT_242;
    alias_sym_id[zT_243] = zT_238;
    if ((int)(dep_count >= dep_cap)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_245 = perm_alloc;
    zT_246 = &dep_to;
    zT_247 = &dep_next;
    zT_248 = &dep_cap;
    zF_62CBE4C7_growDep(zT_245, zT_246, zT_247, zT_248);
    goto z_bb_50;
    z_bb_50:
    zT_252 = (unsigned int)dep_count;
    dep_to[zT_252] = alias_count;
    zT_253 = (unsigned int)dep_canonical;
    zT_254 = dep_head[zT_253];
    zT_255 = (unsigned int)dep_count;
    dep_next[zT_255] = zT_254;
    zT_256 = (unsigned int)dep_canonical;
    dep_head[zT_256] = dep_count;
    zT_257 = 1;
    zT_259 = dep_count + (unsigned int)((unsigned int)zT_257);
    dep_count = zT_259;
    zT_260 = 1;
    zT_262 = alias_count + (unsigned int)((unsigned int)zT_260);
    alias_count = zT_262;
    goto z_bb_38;
    z_bb_51:
    zT_276 = "CAP:ac0\n";
    zT_278 = 8;
    zT_277.ptr = zT_276;
    zT_277.len = zT_278;
    cap_m = zT_277;
    zT_279 = cap_m;
    zF_48AC7B3A_markerWrite(zT_279);
    return;
    z_bb_52:
    zT_281 = 0;
    zT_282 = (unsigned int)zT_281;
    ai = zT_282;
    goto z_bb_53;
    z_bb_53:
    if ((int)(ai < alias_count)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_285 = (unsigned int)ai;
    zT_286 = alias_name[zT_285];
    dep_name = zT_286;
    zT_289 = 2;
    zT_290 = (unsigned int)((unsigned int)ai) * zT_289;
    zT_291 = alias_sym_id[zT_290];
    mod_id = zT_291;
    zT_294 = 2;
    zT_296 = 1;
    zT_297 = (unsigned int)((unsigned int)((unsigned int)ai) * zT_294) + zT_296;
    zT_298 = alias_sym_id[zT_297];
    sym_idx = zT_298;
    zT_300 = symbol_reg->tables_items;
    zT_301 = (unsigned int)mod_id;
    zT_302 = zT_300[zT_301];
    table = zT_302;
    zT_304 = table.items;
    zT_306 = zT_304 + (unsigned int)((unsigned int)sym_idx);
    sym = zT_306;
    zT_309 = 18;
    resolved = zT_309;
    zT_315 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    mod_key = zT_315;
    zT_316 = registry;
    zT_317 = mod_key;
    zT_318 = zF_0EB68360_nameCacheGet(zT_316, zT_317);
    zT_319 = zT_318.has_value;
    if (zT_319) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    zT_375 = "KAHN:start\n";
    zT_377 = 11;
    zT_376.ptr = zT_375;
    zT_376.len = zT_377;
    kst_m = zT_376;
    zT_378 = kst_m;
    zF_48AC7B3A_markerWrite(zT_378);
    goto z_bb_75;
    z_bb_56:
    zT_372 = 1;
    zT_373 = ai + zT_372;
    ai = zT_373;
    goto z_bb_53;
    z_bb_57:
    tid = zT_318.value;
    resolved = tid;
    goto z_bb_58;
    z_bb_58:
    if ((int)(resolved == (unsigned int)(18))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_323 = registry;
    zT_326 = zF_0EB68360_nameCacheGet(zT_323, (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name));
    zT_327 = zT_326.has_value;
    if (zT_327) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    if ((int)(resolved == (unsigned int)(18))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    tid = zT_326.value;
    resolved = tid;
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_332 = 0;
    zT_333 = (unsigned int)zT_332;
    cmi = zT_333;
    goto z_bb_65;
    z_bb_64:
    if ((int)(resolved == (unsigned int)(18))) goto z_bb_71; else goto z_bb_72;
    z_bb_65:
    zT_334 = symbol_reg->tables_len;
    if ((int)(cmi < zT_334)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_341 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)cmi) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    ckey = zT_341;
    zT_342 = registry;
    zT_343 = ckey;
    zT_344 = zF_0EB68360_nameCacheGet(zT_342, zT_343);
    zT_345 = zT_344.has_value;
    if (zT_345) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_347 = 1;
    zT_348 = cmi + zT_347;
    cmi = zT_348;
    goto z_bb_65;
    z_bb_69:
    tid = zT_344.value;
    resolved = tid;
    goto z_bb_67;
    z_bb_70:
    goto z_bb_68;
    z_bb_71:
    zT_352 = interner;
    zT_353 = dep_name;
    zT_354 = zF_9134020D_stringInternerGet(zT_352, zT_353);
    name_str = zT_354;
    zT_355 = name_str;
    zT_356 = zF_0D410D69_resolveWellKnownTyp(zT_355);
    resolved = zT_356;
    goto z_bb_72;
    z_bb_72:
    if ((int)(resolved != (unsigned int)(18))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    sym->type_id = resolved;
    zT_364 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    ckey = zT_364;
    zT_365 = registry;
    zT_366 = ckey;
    zT_367 = resolved;
    zF_5E95558D_nameCachePut(zT_365, zT_366, zT_367);
    zT_368 = (unsigned int)wl_len;
    wl[zT_368] = ai;
    zT_369 = 1;
    zT_371 = wl_len + (unsigned int)((unsigned int)zT_369);
    wl_len = zT_371;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_56;
    z_bb_75:
    zT_379 = 0;
    if ((int)(wl_len > (unsigned int)zT_379)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_381 = 1;
    zT_383 = wl_len - (unsigned int)((unsigned int)zT_381);
    wl_len = zT_383;
    zT_385 = (unsigned int)wl_len;
    zT_386 = wl[zT_385];
    resolved_idx = zT_386;
    zT_389 = 2;
    zT_390 = (unsigned int)((unsigned int)resolved_idx) * zT_389;
    zT_391 = alias_sym_id[zT_390];
    resolved_mod = zT_391;
    zT_393 = symbol_reg->tables_items;
    zT_394 = (unsigned int)resolved_mod;
    zT_395 = zT_393[zT_394];
    resolved_table = zT_395;
    zT_397 = resolved_table.items;
    zT_399 = 2;
    zT_401 = 1;
    zT_402 = (unsigned int)((unsigned int)((unsigned int)resolved_idx) * zT_399) + zT_401;
    zT_403 = alias_sym_id[zT_402];
    zT_405 = zT_397 + (unsigned int)((unsigned int)zT_403);
    resolved_sym = zT_405;
    zT_407 = resolved_sym->type_id;
    rt = zT_407;
    zT_409 = store;
    zT_410 = resolved_sym->decl_node;
    zT_412 = zF_FCDD1D35_astStoreNodeAt(zT_409, zT_410);
    decl_node = zT_412;
    zT_414 = store;
    zT_415 = resolved_sym->decl_node;
    zT_417 = zF_8BA26B9E_astStoreNodePayload(zT_414, zT_415);
    alias_own_name = zT_417;
    zT_419 = interner;
    zT_420 = alias_own_name;
    zT_421 = zF_9134020D_stringInternerGet(zT_419, zT_420);
    alias_own_text = zT_421;
    zT_423 = interner;
    zT_424 = alias_own_text;
    zT_425 = zF_50C274AF_stringInternerInter(zT_423, zT_424);
    alias_own_canonical = zT_425;
    zT_427 = (unsigned int)alias_own_canonical;
    zT_428 = dep_head[zT_427];
    edge_idx = zT_428;
    goto z_bb_79;
    z_bb_77:
    zT_475 = "KAHN:end\n";
    zT_477 = 9;
    zT_476.ptr = zT_475;
    zT_476.len = zT_477;
    ken_m = zT_476;
    zT_478 = ken_m;
    zF_48AC7B3A_markerWrite(zT_478);
    return;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    if ((int)(edge_idx != U32_MAX)) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_431 = (unsigned int)edge_idx;
    zT_432 = dep_to[zT_431];
    dep_alias_idx = zT_432;
    zT_435 = 2;
    zT_436 = (unsigned int)((unsigned int)dep_alias_idx) * zT_435;
    zT_437 = alias_sym_id[zT_436];
    dep_mod = zT_437;
    zT_440 = 2;
    zT_442 = 1;
    zT_443 = (unsigned int)((unsigned int)((unsigned int)dep_alias_idx) * zT_440) + zT_442;
    zT_444 = alias_sym_id[zT_443];
    dep_sym_idx = zT_444;
    zT_446 = symbol_reg->tables_items;
    zT_447 = (unsigned int)dep_mod;
    zT_448 = zT_446[zT_447];
    dep_table = zT_448;
    zT_450 = dep_table.items;
    zT_452 = zT_450 + (unsigned int)((unsigned int)dep_sym_idx);
    dep_sym = zT_452;
    zT_453 = dep_sym->type_id;
    zT_454 = 0;
    if ((int)(zT_453 == (unsigned int)zT_454)) goto z_bb_83; else goto z_bb_84;
    z_bb_81:
    goto z_bb_78;
    z_bb_82:
    goto z_bb_79;
    z_bb_83:
    dep_sym->type_id = rt;
    zT_457 = (unsigned int)dep_alias_idx;
    zT_458 = alias_name[zT_457];
    dep_name = zT_458;
    zT_464 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)dep_mod) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)dep_name);
    dkey = zT_464;
    zT_465 = registry;
    zT_466 = dkey;
    zT_467 = rt;
    zF_5E95558D_nameCachePut(zT_465, zT_466, zT_467);
    zT_468 = (unsigned int)wl_len;
    wl[zT_468] = dep_alias_idx;
    zT_469 = 1;
    zT_471 = wl_len + (unsigned int)((unsigned int)zT_469);
    wl_len = zT_471;
    goto z_bb_84;
    z_bb_84:
    zT_472 = (unsigned int)edge_idx;
    zT_473 = dep_next[zT_472];
    edge_idx = zT_473;
    goto z_bb_82;
}

/* __module_init */
void zF_780653D2___module_init_18(void) {
    zT_3D7259E2_SymbolRegistry zT_0 = {0};
    zT_060CD1EB_SymbolTable zT_1 = {0};
    zT_338B7C76_TypeRegistry zT_2 = {0};
    zT_D3EB6303_StringInterner zT_3 = {0};
    zG_3D7259E2_SymbolRegistry = zT_0;
    zG_060CD1EB_SymbolTable = zT_1;
    zG_338B7C76_TypeRegistry = zT_2;
    zG_D3EB6303_StringInterner = zT_3;
    return;
}

/* EOF */
