#ifndef ZIG_MODULE_PAL_388A8A1B_H
#define ZIG_MODULE_PAL_388A8A1B_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "panic_CE239B25.h"
#include "extern_c_856786C2.h"
#include "itoa_4E677A6A.h"


/* Forward declarations */
zT_99D838F1_Opt_444 zF_5B859C63_readFile(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*);
unsigned char zF_852C5C93_fileExists(zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_8CC05F84_dirExists(zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_D3019AEE_stdout_write(zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_E4B2EF19_stderr_write(zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_39FE21EF_fileOpen(zT_8F083A69_Slice_zT_0B42B2F8_u, int);
void zF_3276D7B6_fileWrite(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_7579A8D7_fileRead(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_B30B1D79_fileClose(unsigned int);
zT_0DCE6231_Opt_408 zF_A1EF0C49_streamOpen(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char*);
void zF_D4EBC9A3_streamClose(void*);
void zF_6B472DDC_streamWrite(void*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_9D6FEB45_streamRead(void*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_25D60F31_streamSeek(void*, int);
int zF_BEB0BFA8_getDefaultLibPath(unsigned char*, int);
void zF_CDED1A85_exit(unsigned char);
void zF_4DE8E0A6_initArgs(int, unsigned char**);
int zF_EEF840BE_argCount(void);
unsigned char* zF_70B5BFF1_argGet(int);
void zF_3C88665D_markersEnabled(unsigned int);
unsigned char zF_F632D1ED_isMarkersEnabled(void);
void zF_48AC7B3A_markerWrite(zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_C914CB83_markerWriteInt(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
void zF_C405AFC1_markerWriteInt64(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_79FAE712_u64);
void zF_B5478454_measureMarkerWrite(zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_95B5C5CD_measureMarkerWriteI(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int);
void zF_C9DDBF0F_measureMarkerWriteI(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_79FAE712_u64);
void zF_780653D2___module_init_6(void);
/* Storage globals (extern decls) */
extern unsigned char* zG_970FEF1B_MODE_READ;
extern unsigned int zG_CC81CC5F_INVALID_FD;
extern int zG_F46B0200_saved_argc;
extern unsigned char** zG_096B230F_saved_argv;
extern unsigned int zG_EE253928_g_markers_enabled;

#endif /* ZIG_MODULE_PAL_388A8A1B_H */
