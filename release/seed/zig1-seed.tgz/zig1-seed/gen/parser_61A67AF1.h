#ifndef ZIG_MODULE_PARSER_61A67AF1_H
#define ZIG_MODULE_PARSER_61A67AF1_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "token_76C7CBBF.h"
#include "token_76C7CBBF.h"
#include "ast_2FA12982.h"
#include "allocator_E75B7A0B.h"
#include "allocator_E75B7A0B.h"
#include "diagnostics_B9C6175E.h"
#include "string_interner_51340A9F.h"
#include "growable_array_6014E5AF.h"
#include "growable_array_6014E5AF.h"
#include "ast_2FA12982.h"
#include "ast_2FA12982.h"
#include "ast_2FA12982.h"
#include "string_interner_51340A9F.h"
#include "pal_388A8A1B.h"
#include "itoa_4E677A6A.h"
#include "format_0AEF880C.h"
#include "module_registry_03A5D1FC.h"
#include "lexer_23F0DAD4.h"
#include "lexer_23F0DAD4.h"

#ifndef ZIG_ERROR_SET_zT_DBF3575C_ParserError
#define ZIG_ERROR_SET_zT_DBF3575C_ParserError
typedef int zT_DBF3575C_ParserError;
#define zT_DBF3575C_ParserError_UnexpectedToken 1

#endif /* ZIG_ERROR_SET_zT_DBF3575C_ParserError */

/* Forward declarations */
zT_B559F9DA_Parser zF_EDAEEEE9_parserInitCommon(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_6B0A7D14_AstStore*, zT_D3EB6303_StringInterner*, zT_F85C5DED_DiagnosticCollector*, zT_3E40CD83_Sand*, unsigned int);
zT_B559F9DA_Parser zF_74A05BF0_parserInit(zT_F020719E_Slice_zT_3A355BD2_T, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_6B0A7D14_AstStore*, zT_D3EB6303_StringInterner*, zT_F85C5DED_DiagnosticCollector*, zT_3E40CD83_Sand*);
zT_B559F9DA_Parser zF_9E9ED878_parserInitStreaming(zT_138FFB41_Lexer*, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_6B0A7D14_AstStore*, zT_D3EB6303_StringInterner*, zT_F85C5DED_DiagnosticCollector*, zT_3E40CD83_Sand*);
void zF_15960D31_parserSetModuleCont(zT_B559F9DA_Parser*, zT_072B53A6_ModuleRegistry*, unsigned int);
void zF_C8F08D73_parserSetImportScra(zT_B559F9DA_Parser*, zT_3E40CD83_Sand*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_08D61E58_parserTokenText(zT_B559F9DA_Parser*, zT_2B3424E9_ParseToken);
void zF_7C3FD09B_parserPullOne(zT_B559F9DA_Parser*);
void zF_2DCC9581_parserConsumeCurren(zT_B559F9DA_Parser*);
zT_3A355BD2_Token zF_068A2DE5_parserPeek(zT_B559F9DA_Parser*);
zT_3A355BD2_Token zF_F685E431_parserPeekN(zT_B559F9DA_Parser*, unsigned int);
zT_3A355BD2_Token zF_C241B2C4_parserAdvance(zT_B559F9DA_Parser*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_77B50062_tokenKindLabel(zT_EAC3E484_TokenKind);
zT_4770F49E_EU_19 zF_5578C74F_parserExpect(zT_B559F9DA_Parser*, zT_EAC3E484_TokenKind);
void zF_17DF2CA5_parserAddError(zT_B559F9DA_Parser*, zT_3A355BD2_Token, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_4190C400_parserSynchronize(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_F07C1F04_parserParseExprPrec(zT_B559F9DA_Parser*, zT_2B10107F_Prec);
zT_3B6EA323_EU_01 zF_E702AE30_parserAddBinary(zT_B559F9DA_Parser*, zT_3A355BD2_Token, unsigned int, unsigned int);
zT_3B6EA323_EU_01 zF_565DCE21_parserParsePrimary(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_77AD89E7_parserParsePostfixC(zT_B559F9DA_Parser*, unsigned int);
zT_3B6EA323_EU_01 zF_86B17ABA_parserParseDotAcces(zT_B559F9DA_Parser*, unsigned int);
zT_3B6EA323_EU_01 zF_8B5A7E08_parserParseIndexOrS(zT_B559F9DA_Parser*, unsigned int);
zT_3B6EA323_EU_01 zF_3FC58691_parserParseFnCall(zT_B559F9DA_Parser*, unsigned int);
zT_3B6EA323_EU_01 zF_95DDA8C7_parserParseCatchRHS(zT_B559F9DA_Parser*, zT_2B10107F_Prec, unsigned int*);
zT_3B6EA323_EU_01 zF_A059028C_parserParseOrelseRH(zT_B559F9DA_Parser*, zT_2B10107F_Prec);
zT_3B6EA323_EU_01 zF_D1EA41E6_parserParseFieldIni(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_EFD340BA_parserParseStructIn(zT_B559F9DA_Parser*, unsigned int);
void zF_8B163A32_u32ArrayListAppendI(unsigned int**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int);
void zF_0F1462F8_parserPushU32(zT_B559F9DA_Parser*, unsigned int**, unsigned int*, unsigned int*, unsigned int);
zT_3B6EA323_EU_01 zF_4D06854D_parserParseIntLiter(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_FB72DD9C_parserParseFloatLit(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_397D4BBF_parserParseStringLi(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_F509A7F4_parserParseCharLite(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_0E221A14_parserParseBoolLite(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_A18ECFB6_parserParseSingleTo(zT_B559F9DA_Parser*, zT_8143F551_AstKind);
zT_3B6EA323_EU_01 zF_F5EAD186_parserParseIdentExp(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_BE192524_parserParsePrefixUn(zT_B559F9DA_Parser*, zT_8143F551_AstKind);
zT_3B6EA323_EU_01 zF_C5DF83EE_parserParseGroupedE(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_5D650338_parserParseBuiltinC(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_D258E86B_parserParseImportEx(zT_B559F9DA_Parser*, zT_3A355BD2_Token);
zT_3B6EA323_EU_01 zF_C531682A_parserParseCInclude(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_AC24A2A0_parserParseErrorLit(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_59C88921_parserParseTryExpr(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_9A508F9D_parserParseAnonymou(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_BD525F87_parserParseEnumLite(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_DE101A45_parserParseArrayLit(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_79089D39_parserParseIfExpr(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_A9AC92CA_parserParseSwitchEx(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_CB4EC4E3_parserParseSwitchPr(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_CBDBFE85_parserParseType(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_08083D09_parserParsePtrType(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_2BC32683_parserParseBracketT(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_F9036399_parserParseOptional(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_33E5ECC8_parserParseErrorUni(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_B5C9B665_parserParseFnType(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_BFAD1973_parserParseErrorSet(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_2C55CABB_parserParseErrorSet(zT_B559F9DA_Parser*, zT_3A355BD2_Token);
zT_3B6EA323_EU_01 zF_3530D6C0_parserParseStructTy(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_63EC2480_parserParseEnumType(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_0881F8E4_parserParseUnionTyp(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_C8A1E2C6_parserParseTypeName(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_462FC60E_parserParseStatemen(zT_B559F9DA_Parser*);
unsigned int zF_8A97D8C1_parserEmitErrorNode(zT_B559F9DA_Parser*, zT_3A355BD2_Token, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_3B6EA323_EU_01 zF_224ED3B5_parserParseModuleRo(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_907B11F0_parserParseExprStmt(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_BF6ABAB2_parserParseLabeledS(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_532B277E_parserParseLabeledB(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_7D11B416_parserParseVarDecl(zT_B559F9DA_Parser*, int, int, int, int);
zT_3B6EA323_EU_01 zF_A8314C30_parserParsePubDecl(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_A0D31A63_parserParseExternDe(zT_B559F9DA_Parser*, int);
zT_3B6EA323_EU_01 zF_C3CD8237_parserParseExportDe(zT_B559F9DA_Parser*, int);
zT_3B6EA323_EU_01 zF_3D879A25_parserParseFnDecl(zT_B559F9DA_Parser*, int, int, int, int);
zT_3B6EA323_EU_01 zF_DB819578_parserParseIfStmt(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_4E7AD820_parserParseWhileStm(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_54BCF0C6_parserParseForStmt(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_3A6F34C7_parserParseSwitchSt(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_224C1394_parserParseReturnEx(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_C69B6287_parserParseBreakExp(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_73B42F4B_parserParseContinue(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_76F5B9F1_parserParseReturnSt(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_6DA396FE_parserParseBreakStm(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_E13A9822_parserParseContinue(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_3B25AFD5_parserParseDeferStm(zT_B559F9DA_Parser*, zT_8143F551_AstKind);
zT_3B6EA323_EU_01 zF_6C2E50E6_parserParseErrdefer(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_15A196A5_parserParseTestDecl(zT_B559F9DA_Parser*);
zT_3B6EA323_EU_01 zF_0A0E9C6C_parserParseContaine(zT_B559F9DA_Parser*, zT_8143F551_AstKind);
zT_3B6EA323_EU_01 zF_365CA04A_parserParseBlock(zT_B559F9DA_Parser*);
unsigned char zF_F312BDA3_precToInt(zT_2B10107F_Prec);
zT_2B10107F_Prec zF_860100DC_precFromInt(unsigned char);
zT_AEDA7E92_Opt_94 zF_1E2936C3_getInfixInfo(zT_EAC3E484_TokenKind);
void zF_780653D2___module_init_7(void);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_PARSER_61A67AF1_H */
