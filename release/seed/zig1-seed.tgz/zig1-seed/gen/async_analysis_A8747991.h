#ifndef ZIG_MODULE_ASYNC_ANALYSIS_A8747991_H
#define ZIG_MODULE_ASYNC_ANALYSIS_A8747991_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "ast_2FA12982.h"
#include "growable_array_6014E5AF.h"
#include "hash_02AFCD13.h"
#include "itoa_4E677A6A.h"
#include "module_registry_03A5D1FC.h"
#include "pal_388A8A1B.h"
#include "resolved_type_table_5F22E794.h"
#include "string_interner_51340A9F.h"
#include "symbol_table_74081C75.h"
#include "type_registry_8EE489B8.h"


/* Forward declarations */
zT_79FAE712_u64 zF_9D041EB6_asyncKey(unsigned int, unsigned int);
unsigned char zF_7C7E43BF_asyncIsSuspending(zT_A4CE86B7_U64ToU32Map*, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_D3D61AC0_asyncFrameSizeOf(zT_A4CE86B7_U64ToU32Map*, unsigned int, unsigned int);
unsigned int* zF_43BEEDA4_allocU32(zT_3E40CD83_Sand*, unsigned int);
zT_BBEE1AC1_Opt_11 zF_860C82EC_resolveCalleeKey(zT_6B0A7D14_AstStore*, zT_3D7259E2_SymbolRegistry*, unsigned int, unsigned int);
void zF_32651930_scanFunction(zT_6B0A7D14_AstStore*, zT_3D7259E2_SymbolRegistry*, unsigned int, unsigned int, unsigned int, zT_B687BB96_U32ArrayList*, zT_B687BB96_U32ArrayList*, zT_B687BB96_U32ArrayList*, zT_47B162D1_U8ArrayList*, zT_A4CE86B7_U64ToU32Map*, unsigned int);
void zF_76D5E8D3_emitSuspMarker(zT_79FAE712_u64);
void zF_790061E7_suspensionAnalysisR(zT_3E40CD83_Sand*, zT_6B0A7D14_AstStore*, zT_3D7259E2_SymbolRegistry*, zT_072B53A6_ModuleRegistry*, zT_D3EB6303_StringInterner*, zT_A4CE86B7_U64ToU32Map*);
unsigned int zF_978D7C93_alignUpU32(unsigned int, unsigned int);
void zF_816D1610_frameFieldSizeAlign(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int*, unsigned int*);
unsigned int zF_769CB99B_addFrameField(zT_338B7C76_TypeRegistry*, unsigned int, unsigned int*, unsigned int*);
unsigned char zF_5049D2D3_typeIsPtrVoid(zT_338B7C76_TypeRegistry*, unsigned int);
unsigned int zF_436F92E0_frameLocalTypeId(zT_8EED1867_ResolvedTypeTable*, zT_22A7C88B_AstNode);
void zF_68BD38B1_scanFrameLocals(zT_6B0A7D14_AstStore*, unsigned int, zT_B687BB96_U32ArrayList*, zT_338B7C76_TypeRegistry*, zT_8EED1867_ResolvedTypeTable*, unsigned int*, unsigned int*);
void zF_D62E4E4C_scanImplicitAwaits(zT_6B0A7D14_AstStore*, zT_3D7259E2_SymbolRegistry*, unsigned int, zT_79FAE712_u64, unsigned int, zT_B687BB96_U32ArrayList*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_B687BB96_U32ArrayList*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*);
unsigned int zF_74FC996E_asyncStateTypeForCo(unsigned int);
unsigned int zF_0782A438_scanSuspensionCount(zT_6B0A7D14_AstStore*, zT_3D7259E2_SymbolRegistry*, unsigned int, unsigned int, zT_B687BB96_U32ArrayList*, zT_A4CE86B7_U64ToU32Map*, unsigned int, unsigned int);
unsigned int zF_FF3C4865_asyncPtrVoid(zT_338B7C76_TypeRegistry*);
void zF_7011AA79_emitFrameMarker(zT_79FAE712_u64, unsigned int);
void zF_7DBA21B2_asyncFrameSizeRun(zT_3E40CD83_Sand*, zT_6B0A7D14_AstStore*, zT_3D7259E2_SymbolRegistry*, zT_D3EB6303_StringInterner*, zT_072B53A6_ModuleRegistry*, zT_338B7C76_TypeRegistry*, zT_8EED1867_ResolvedTypeTable*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*, zT_B687BB96_U32ArrayList*, zT_A4CE86B7_U64ToU32Map*, zT_A4CE86B7_U64ToU32Map*);
void zF_780653D2___module_init_22(void);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_ASYNC_ANALYSIS_A8747991_H */
