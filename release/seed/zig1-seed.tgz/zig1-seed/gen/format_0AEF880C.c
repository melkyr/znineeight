#include "format_0AEF880C.h"
static unsigned int const zG_346F9833_FMT_BN_LIMBS = (unsigned int)(128);
/* copyStr */
void zF_D67017F3_copyStr(zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int* idx, zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned char* zT_9;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = s.len;
    if ((unsigned char)(i < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = s.ptr;
    zT_10 = zT_9[i];
    zT_11 = buf.ptr;
    zT_12 = *idx;
    zT_11[zT_12] = zT_10;
    zT_13 = *idx;
    zT_14 = 1;
    *idx = (unsigned int)(zT_13 + (unsigned int)((unsigned int)zT_14));
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
}

/* formatU32 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_2(unsigned int val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_26;
    unsigned char* zT_27;
    int zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned char* zT_36;
    int zT_38;
    unsigned char* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int idx;
    unsigned int v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((unsigned char)(v == (unsigned int)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_34 = 1;
    zT_35 = idx + zT_34;
    start = zT_35;
    zT_36 = buf.ptr;
    zT_38 = 1;
    zT_40 = zT_36 + start;
    zT_41 = (unsigned int)(buf_len - zT_38) - start;
    zT_42.ptr = (unsigned char*)zT_40;
    zT_42.len = zT_41;
    return zT_42;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((unsigned char)(v > (unsigned int)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_26 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(v % zT_23));
    zT_27 = buf.ptr;
    zT_27[idx] = zT_26;
    zT_28 = 10;
    zT_29 = v / zT_28;
    v = zT_29;
    zT_30 = 1;
    zT_32 = idx - (unsigned int)((unsigned int)zT_30);
    idx = zT_32;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* formatU64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C3E62EC7_formatU64(zT_79FAE712_u64 val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_27;
    unsigned char* zT_28;
    int zT_29;
    zT_79FAE712_u64 zT_30;
    int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned char* zT_37;
    int zT_39;
    unsigned char* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int idx;
    zT_79FAE712_u64 v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((unsigned char)(v == (zT_79FAE712_u64)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_35 = 1;
    zT_36 = idx + zT_35;
    start = zT_36;
    zT_37 = buf.ptr;
    zT_39 = 1;
    zT_41 = zT_37 + start;
    zT_42 = (unsigned int)(buf_len - zT_39) - start;
    zT_43.ptr = (unsigned char*)zT_41;
    zT_43.len = zT_42;
    return zT_43;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((unsigned char)(v > (zT_79FAE712_u64)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_27 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(zT_79FAE712_u64)(v % zT_23)));
    zT_28 = buf.ptr;
    zT_28[idx] = zT_27;
    zT_29 = 10;
    zT_30 = v / zT_29;
    v = zT_30;
    zT_31 = 1;
    zT_33 = idx - (unsigned int)((unsigned int)zT_31);
    idx = zT_33;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* fmtBnMulSmall */
void zF_350AF0DD_fmtBnMulSmall(zT_5DB33A8A_Arr_unsigned_int_12* a, unsigned int* nlimbs, unsigned int mul) {
    int zT_4;
    zT_79FAE712_u64 zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_12;
    zT_79FAE712_u64 zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    zT_79FAE712_u64 zT_21;
    int zT_22;
    unsigned int zT_24;
    int zT_25;
    int zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_79FAE712_u64 zT_32;
    unsigned int zT_33;
    int zT_34;
    zT_79FAE712_u64 carry;
    unsigned int i;
    zT_79FAE712_u64 p;
    zT_4 = 0;
    zT_5 = (zT_79FAE712_u64)zT_4;
    carry = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_9 = *nlimbs;
    if ((unsigned char)(i < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_12 = (*a)[i];
    zT_16 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_12) * (zT_79FAE712_u64)((zT_79FAE712_u64)mul)) + carry;
    p = zT_16;
    zT_17 = 1000000000;
    zT_19 = (unsigned int)(zT_79FAE712_u64)(p % zT_17);
    (*a)[i] = zT_19;
    zT_20 = 1000000000;
    zT_21 = p / zT_20;
    carry = zT_21;
    zT_22 = 1;
    zT_24 = i + (unsigned int)((unsigned int)zT_22);
    i = zT_24;
    goto z_bb_4;
    z_bb_3:
    goto z_bb_5;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_25 = 0;
    if ((unsigned char)(carry > (zT_79FAE712_u64)zT_25)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_27 = 1000000000;
    zT_29 = (unsigned int)(zT_79FAE712_u64)(carry % zT_27);
    zT_30 = *nlimbs;
    (*a)[zT_30] = zT_29;
    zT_31 = 1000000000;
    zT_32 = carry / zT_31;
    carry = zT_32;
    zT_33 = *nlimbs;
    zT_34 = 1;
    *nlimbs = (unsigned int)(zT_33 + (unsigned int)((unsigned int)zT_34));
    goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    goto z_bb_5;
}

/* fmtCopyOut */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_11ACB4EF_fmtCopyOut(zT_8F083A69_Slice_zT_0B42B2F8_u src, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int cap) {
    unsigned int zT_5;
    int zT_6;
    int zT_9;
    unsigned int zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned char* zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    int zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned char zT_22;
    unsigned char* zT_23;
    unsigned char* zT_24;
    int zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int n;
    unsigned int i;
    zT_5 = src.len;
    n = zT_5;
    zT_6 = 1;
    if ((unsigned char)(n > (unsigned int)(cap - zT_6))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 1;
    zT_10 = cap - zT_9;
    n = zT_10;
    goto z_bb_2;
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    i = zT_13;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(i < n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = src.ptr;
    zT_16 = zT_15[i];
    zT_17 = buf.ptr;
    zT_17[i] = zT_16;
    zT_18 = 1;
    zT_20 = i + (unsigned int)((unsigned int)zT_18);
    i = zT_20;
    goto z_bb_6;
    z_bb_5:
    zT_21 = 0;
    zT_22 = (unsigned char)zT_21;
    zT_23 = buf.ptr;
    zT_23[n] = zT_22;
    zT_24 = buf.ptr;
    zT_26 = 0;
    zT_27 = zT_24 + zT_26;
    zT_28 = n - zT_26;
    zT_29.ptr = (unsigned char*)zT_27;
    zT_29.len = zT_28;
    return zT_29;
    z_bb_6:
    goto z_bb_3;
}

/* formatF64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4CAEBE7E_formatF64(zT_00435AEB_f64 val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned char* zT_11;
    int zT_13;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_C41F1B06_Arr_unsigned_char_6 zT_19;
    int zT_21;
    unsigned int zT_22;
    unsigned char zT_25;
    int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    int zT_32;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_41;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    unsigned int zT_53;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64 = {0};
    int zT_66;
    unsigned char zT_67;
    int zT_71;
    unsigned char zT_72;
    zT_00435AEB_f64 zT_73;
    int zT_75;
    int zT_76;
    zT_00435AEB_f64 zT_80;
    int zT_81;
    int zT_83;
    zT_00435AEB_f64 zT_87;
    int zT_88;
    int zT_90;
    zT_79FAE712_u64 zT_94;
    int zT_96;
    int zT_97;
    zT_5DB33A8A_Arr_unsigned_int_12 zT_99;
    int zT_101;
    unsigned int zT_102;
    int zT_104;
    int zT_106;
    unsigned int zT_108;
    int zT_109;
    zT_79FAE712_u64 zT_110;
    int zT_111;
    unsigned int zT_113;
    int zT_115;
    int zT_116;
    int zT_117;
    int zT_120;
    int zT_121;
    zT_5DB33A8A_Arr_unsigned_int_12* zT_123;
    unsigned int* zT_124;
    int zT_128;
    int zT_130;
    int zT_132;
    int zT_133;
    int zT_134;
    int zT_136;
    int zT_137;
    int zT_139;
    int zT_140;
    zT_5DB33A8A_Arr_unsigned_int_12* zT_142;
    unsigned int* zT_143;
    int zT_147;
    int zT_149;
    int zT_151;
    int zT_153;
    unsigned int zT_154;
    unsigned int zT_156;
    int zT_158;
    unsigned int zT_159;
    int zT_160;
    int zT_162;
    unsigned int zT_164;
    int zT_165;
    unsigned int zT_166;
    int zT_168;
    int zT_172;
    int zT_174;
    int zT_176;
    int zT_178;
    zT_79FAE712_u64 zT_179;
    int zT_181;
    unsigned int zT_182;
    int zT_184;
    unsigned int zT_185;
    int zT_187;
    int zT_188;
    unsigned int zT_191;
    unsigned int zT_192;
    int zT_194;
    unsigned int zT_195;
    zT_C2AB05E7_Arr_unsigned_char_9 zT_199;
    int zT_202;
    int zT_203;
    int zT_204;
    int zT_207;
    unsigned char zT_210;
    unsigned int zT_211;
    int zT_212;
    unsigned int zT_213;
    int zT_214;
    int zT_216;
    int zT_218;
    unsigned int zT_220;
    int zT_222;
    unsigned char zT_225;
    unsigned int zT_228;
    int zT_229;
    int zT_231;
    zT_79FAE712_u64 zT_234;
    int zT_235;
    unsigned int zT_237;
    int zT_238;
    int zT_240;
    unsigned int zT_242;
    int zT_243;
    unsigned int zT_245;
    int zT_246;
    int zT_248;
    int zT_249;
    int zT_251;
    zT_79FAE712_u64 zT_252;
    int zT_253;
    unsigned int zT_255;
    int zT_256;
    int zT_258;
    zT_79FAE712_u64 zT_260;
    zT_79FAE712_u64 zT_261;
    int zT_263;
    zT_79FAE712_u64 zT_264;
    int zT_265;
    int zT_267;
    int zT_268;
    unsigned char zT_270;
    int zT_271;
    unsigned int zT_273;
    zT_79FAE712_u64 zT_275;
    zT_79FAE712_u64 zT_276;
    zT_79FAE712_u64 zT_278;
    zT_79FAE712_u64 zT_279;
    unsigned char zT_283;
    int zT_284;
    unsigned int zT_286;
    zT_5426B97B_Arr_unsigned_char_1 zT_288;
    int zT_290;
    int zT_291;
    int zT_292;
    int zT_295;
    unsigned char zT_299;
    unsigned int zT_300;
    int zT_301;
    zT_79FAE712_u64 zT_302;
    int zT_303;
    int zT_305;
    int zT_307;
    unsigned int zT_308;
    int zT_309;
    unsigned char zT_311;
    int zT_312;
    unsigned int zT_313;
    unsigned char zT_314;
    int zT_317;
    unsigned int zT_319;
    int zT_320;
    unsigned char zT_322;
    int zT_323;
    unsigned int zT_325;
    int zT_327;
    unsigned int zT_328;
    unsigned char zT_330;
    int zT_331;
    unsigned int zT_333;
    int zT_334;
    unsigned int zT_336;
    unsigned char zT_337;
    int zT_338;
    unsigned int zT_340;
    int zT_342;
    unsigned char zT_344;
    int zT_345;
    unsigned int zT_347;
    int zT_348;
    int zT_349;
    unsigned char zT_350;
    int zT_351;
    unsigned int zT_353;
    int zT_354;
    unsigned char zT_356;
    int zT_357;
    unsigned int zT_359;
    zT_C1AB0454_Arr_unsigned_char_8 zT_361;
    int zT_363;
    unsigned int zT_364;
    int zT_366;
    int zT_369;
    unsigned char zT_373;
    int zT_374;
    int zT_375;
    int zT_376;
    unsigned int zT_378;
    int zT_379;
    int zT_381;
    unsigned int zT_383;
    unsigned char zT_384;
    int zT_385;
    unsigned int zT_387;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_388;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_389;
    unsigned int zT_390;
    int zT_393;
    unsigned char* zT_394;
    unsigned int zT_395;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_396;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_397 = {0};
    unsigned int cap;
    zT_C41F1B06_Arr_unsigned_char_6 sb;
    unsigned int bi;
    unsigned char neg;
    zT_00435AEB_f64 v;
    int e2;
    zT_79FAE712_u64 m;
    int e;
    zT_5DB33A8A_Arr_unsigned_int_12 a;
    unsigned int nlimbs;
    zT_79FAE712_u64 mm;
    int offset;
    int k;
    unsigned int top;
    unsigned int tv;
    unsigned int topdig;
    int f;
    int k2;
    int nd;
    int dexp;
    zT_79FAE712_u64 q;
    unsigned int collected;
    unsigned int d18;
    int li;
    unsigned int limb;
    unsigned int dcnt;
    zT_C2AB05E7_Arr_unsigned_char_9 tmp;
    unsigned int tt;
    int k3;
    unsigned int start;
    unsigned int j;
    unsigned int dg;
    zT_79FAE712_u64 d1;
    zT_79FAE712_u64 rest;
    zT_5426B97B_Arr_unsigned_char_1 fdig;
    int fi;
    unsigned int flen;
    unsigned int fj;
    int ae;
    zT_C1AB0454_Arr_unsigned_char_8 eb;
    unsigned int en;
    int av;
    cap = buf_len;
    zT_5 = buf.len;
    if ((unsigned char)(cap > zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = buf.len;
    cap = zT_8;
    goto z_bb_2;
    z_bb_2:
    zT_9 = 0;
    if ((unsigned char)(cap == (unsigned int)zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = buf.ptr;
    zT_13 = 0;
    zT_14 = 0;
    zT_15 = zT_11 + zT_14;
    zT_16 = zT_13 - zT_14;
    zT_17.ptr = (unsigned char*)zT_15;
    zT_17.len = zT_16;
    return zT_17;
    z_bb_4:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_19[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        sb[_i] = zT_19[_i];
        _i++;
    }
}
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    bi = zT_22;
    if ((unsigned char)(val == (zT_00435AEB_f64)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = 48;
    zT_26 = 0;
    sb[zT_26] = zT_25;
    zT_32 = 1;
    zT_33 = 0;
    zT_34 = (unsigned char*)((unsigned char*)sb) + zT_33;
    zT_35 = zT_32 - zT_33;
    zT_36.ptr = (unsigned char*)zT_34;
    zT_36.len = zT_35;
    zT_27 = zT_36;
    zT_28 = buf;
    zT_29 = cap;
    zT_37 = zF_11ACB4EF_fmtCopyOut(zT_27, zT_28, zT_29);
    return zT_37;
    z_bb_6:
    if ((unsigned char)(val != val)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_42 = "Z98_NAN";
    zT_44 = 7;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    zT_39 = zT_43;
    zT_40 = buf;
    zT_41 = cap;
    zT_45 = zF_11ACB4EF_fmtCopyOut(zT_39, zT_40, zT_41);
    return zT_45;
    z_bb_8:
    if ((unsigned char)((zT_00435AEB_f64)(val * (zT_00435AEB_f64)(2e+0)) == val)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    if ((unsigned char)(val > (zT_00435AEB_f64)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_66 = 0;
    zT_67 = (unsigned char)zT_66;
    neg = zT_67;
    v = val;
    if ((unsigned char)(v < (zT_00435AEB_f64)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_54 = "Z98_INF";
    zT_56 = 7;
    zT_55.ptr = (unsigned char*)zT_54;
    zT_55.len = zT_56;
    zT_51 = zT_55;
    zT_52 = buf;
    zT_53 = cap;
    zT_57 = zF_11ACB4EF_fmtCopyOut(zT_51, zT_52, zT_53);
    return zT_57;
    z_bb_12:
    zT_61 = "Z98_NEGINF";
    zT_63 = 10;
    zT_62.ptr = (unsigned char*)zT_61;
    zT_62.len = zT_63;
    zT_58 = zT_62;
    zT_59 = buf;
    zT_60 = cap;
    zT_64 = zF_11ACB4EF_fmtCopyOut(zT_58, zT_59, zT_60);
    return zT_64;
    z_bb_13:
    zT_71 = 1;
    zT_72 = (unsigned char)zT_71;
    neg = zT_72;
    zT_73 = -v;
    v = zT_73;
    goto z_bb_14;
    z_bb_14:
    zT_75 = 0;
    zT_76 = (int)zT_75;
    e2 = zT_76;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(v >= (zT_00435AEB_f64)(2e+0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_80 = v / (zT_00435AEB_f64)(2e+0);
    v = zT_80;
    zT_81 = 1;
    zT_83 = e2 + (int)((int)zT_81);
    e2 = zT_83;
    goto z_bb_18;
    z_bb_17:
    goto z_bb_19;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    if ((unsigned char)(v < (zT_00435AEB_f64)(1e+0))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_87 = v * (zT_00435AEB_f64)(2e+0);
    v = zT_87;
    zT_88 = 1;
    zT_90 = e2 - (int)((int)zT_88);
    e2 = zT_90;
    goto z_bb_22;
    z_bb_21:
    zT_94 = (zT_79FAE712_u64)(zT_00435AEB_f64)(v * (zT_00435AEB_f64)(4.503599627370496e+15));
    m = zT_94;
    zT_96 = 52;
    zT_97 = e2 - zT_96;
    e = zT_97;
    {
    unsigned int _i = 0;
    while (_i < 128) {
        zT_99[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 128) {
        a[_i] = zT_99[_i];
        _i++;
    }
}
    zT_101 = 0;
    zT_102 = (unsigned int)zT_101;
    nlimbs = zT_102;
    mm = m;
    goto z_bb_23;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_104 = 0;
    if ((unsigned char)(mm > (zT_79FAE712_u64)zT_104)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_106 = 1000000000;
    zT_108 = (unsigned int)(zT_79FAE712_u64)(mm % zT_106);
    a[nlimbs] = zT_108;
    zT_109 = 1000000000;
    zT_110 = mm / zT_109;
    mm = zT_110;
    zT_111 = 1;
    zT_113 = nlimbs + (unsigned int)((unsigned int)zT_111);
    nlimbs = zT_113;
    goto z_bb_26;
    z_bb_25:
    zT_115 = 0;
    zT_116 = (int)zT_115;
    offset = zT_116;
    zT_117 = 0;
    if ((unsigned char)(e >= zT_117)) goto z_bb_27; else goto z_bb_29;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_120 = 0;
    zT_121 = (int)zT_120;
    k = zT_121;
    goto z_bb_30;
    z_bb_28:
    zT_153 = 1;
    zT_154 = nlimbs - zT_153;
    top = zT_154;
    zT_156 = a[top];
    tv = zT_156;
    zT_158 = 0;
    zT_159 = (unsigned int)zT_158;
    topdig = zT_159;
    goto z_bb_38;
    z_bb_29:
    zT_136 = 0;
    zT_137 = zT_136 - e;
    f = zT_137;
    zT_139 = 0;
    zT_140 = (int)zT_139;
    k2 = zT_140;
    goto z_bb_34;
    z_bb_30:
    if ((unsigned char)(k < e)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_123 = (zT_5DB33A8A_Arr_unsigned_int_12*)&a;
    zT_124 = (unsigned int*)&nlimbs;
    zT_128 = 2;
    zF_350AF0DD_fmtBnMulSmall(zT_123, zT_124, (unsigned int)((unsigned int)zT_128));
    zT_130 = 1;
    zT_132 = k + (int)((int)zT_130);
    k = zT_132;
    goto z_bb_33;
    z_bb_32:
    zT_133 = 0;
    zT_134 = (int)zT_133;
    offset = zT_134;
    goto z_bb_28;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    if ((unsigned char)(k2 < f)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_142 = (zT_5DB33A8A_Arr_unsigned_int_12*)&a;
    zT_143 = (unsigned int*)&nlimbs;
    zT_147 = 5;
    zF_350AF0DD_fmtBnMulSmall(zT_142, zT_143, (unsigned int)((unsigned int)zT_147));
    zT_149 = 1;
    zT_151 = k2 + (int)((int)zT_149);
    k2 = zT_151;
    goto z_bb_37;
    z_bb_36:
    offset = e;
    goto z_bb_28;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_160 = 0;
    if ((unsigned char)(tv > (unsigned int)zT_160)) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_162 = 1;
    zT_164 = topdig + (unsigned int)((unsigned int)zT_162);
    topdig = zT_164;
    zT_165 = 10;
    zT_166 = tv / zT_165;
    tv = zT_166;
    goto z_bb_41;
    z_bb_40:
    zT_168 = 9;
    zT_172 = (int)((int)(unsigned int)(top * zT_168)) + (int)((int)topdig);
    nd = zT_172;
    zT_174 = 1;
    zT_176 = (int)(nd - zT_174) + offset;
    dexp = zT_176;
    zT_178 = 0;
    zT_179 = (zT_79FAE712_u64)zT_178;
    q = zT_179;
    zT_181 = 0;
    zT_182 = (unsigned int)zT_181;
    collected = zT_182;
    zT_184 = 0;
    zT_185 = (unsigned int)zT_184;
    d18 = zT_185;
    zT_187 = (int)top;
    li = zT_187;
    goto z_bb_42;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_188 = 0;
    if ((unsigned char)(li >= zT_188)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_191 = (unsigned int)li;
    zT_192 = a[zT_191];
    limb = zT_192;
    zT_194 = 9;
    zT_195 = (unsigned int)zT_194;
    dcnt = zT_195;
    if ((unsigned char)(li == (int)((int)top))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_61;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    dcnt = topdig;
    goto z_bb_47;
    z_bb_47:
    {
    unsigned int _i = 0;
    while (_i < 9) {
        zT_199[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 9) {
        tmp[_i] = zT_199[_i];
        _i++;
    }
}
    tt = limb;
    zT_202 = 8;
    zT_203 = (int)zT_202;
    k3 = zT_203;
    goto z_bb_48;
    z_bb_48:
    zT_204 = 0;
    if ((unsigned char)(k3 >= zT_204)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_207 = 10;
    zT_210 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(tt % zT_207));
    zT_211 = (unsigned int)k3;
    tmp[zT_211] = zT_210;
    zT_212 = 10;
    zT_213 = tt / zT_212;
    tt = zT_213;
    zT_214 = 1;
    zT_216 = k3 - (int)((int)zT_214);
    k3 = zT_216;
    goto z_bb_51;
    z_bb_50:
    zT_218 = 9;
    zT_220 = zT_218 - (unsigned int)((unsigned int)dcnt);
    start = zT_220;
    j = start;
    goto z_bb_52;
    z_bb_51:
    goto z_bb_48;
    z_bb_52:
    zT_222 = 9;
    if ((unsigned char)(j < (unsigned int)zT_222)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_225 = tmp[j];
    zT_228 = (unsigned int)(unsigned char)(zT_225 - (unsigned char)(48));
    dg = zT_228;
    zT_229 = 17;
    if ((unsigned char)(collected < (unsigned int)zT_229)) goto z_bb_56; else goto z_bb_58;
    z_bb_54:
    zT_246 = 1;
    zT_248 = li - (int)((int)zT_246);
    li = zT_248;
    goto z_bb_45;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_231 = 10;
    zT_234 = (zT_79FAE712_u64)(q * zT_231) + (zT_79FAE712_u64)((zT_79FAE712_u64)dg);
    q = zT_234;
    zT_235 = 1;
    zT_237 = collected + (unsigned int)((unsigned int)zT_235);
    collected = zT_237;
    goto z_bb_57;
    z_bb_57:
    zT_243 = 1;
    zT_245 = j + (unsigned int)((unsigned int)zT_243);
    j = zT_245;
    goto z_bb_55;
    z_bb_58:
    zT_238 = 17;
    if ((unsigned char)(collected == (unsigned int)zT_238)) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    d18 = dg;
    zT_240 = 1;
    zT_242 = collected + (unsigned int)((unsigned int)zT_240);
    collected = zT_242;
    goto z_bb_60;
    z_bb_60:
    goto z_bb_57;
    z_bb_61:
    zT_249 = 17;
    if ((unsigned char)(collected < (unsigned int)zT_249)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_251 = 10;
    zT_252 = q * zT_251;
    q = zT_252;
    zT_253 = 1;
    zT_255 = collected + (unsigned int)((unsigned int)zT_253);
    collected = zT_255;
    goto z_bb_64;
    z_bb_63:
    zT_256 = 5;
    if ((unsigned char)(d18 >= (unsigned int)zT_256)) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_258 = 1;
    zT_260 = q + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_258);
    q = zT_260;
    goto z_bb_66;
    z_bb_66:
    zT_261 = Z98_U64_C(100000000000000000);
    if ((unsigned char)(q >= (zT_79FAE712_u64)zT_261)) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_263 = 10;
    zT_264 = q / zT_263;
    q = zT_264;
    zT_265 = 1;
    zT_267 = dexp + (int)((int)zT_265);
    dexp = zT_267;
    goto z_bb_68;
    z_bb_68:
    zT_268 = 0;
    if ((unsigned char)(neg != zT_268)) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    zT_270 = 45;
    sb[bi] = zT_270;
    zT_271 = 1;
    zT_273 = bi + (unsigned int)((unsigned int)zT_271);
    bi = zT_273;
    goto z_bb_70;
    z_bb_70:
    zT_275 = Z98_U64_C(10000000000000000);
    zT_276 = q / zT_275;
    d1 = zT_276;
    zT_278 = Z98_U64_C(10000000000000000);
    zT_279 = q % zT_278;
    rest = zT_279;
    zT_283 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)d1));
    sb[bi] = zT_283;
    zT_284 = 1;
    zT_286 = bi + (unsigned int)((unsigned int)zT_284);
    bi = zT_286;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_288[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fdig[_i] = zT_288[_i];
        _i++;
    }
}
    zT_290 = 15;
    zT_291 = (int)zT_290;
    fi = zT_291;
    goto z_bb_71;
    z_bb_71:
    zT_292 = 0;
    if ((unsigned char)(fi >= zT_292)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_295 = 10;
    zT_299 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(zT_79FAE712_u64)(rest % zT_295)));
    zT_300 = (unsigned int)fi;
    fdig[zT_300] = zT_299;
    zT_301 = 10;
    zT_302 = rest / zT_301;
    rest = zT_302;
    zT_303 = 1;
    zT_305 = fi - (int)((int)zT_303);
    fi = zT_305;
    goto z_bb_74;
    z_bb_73:
    zT_307 = 16;
    zT_308 = (unsigned int)zT_307;
    flen = zT_308;
    goto z_bb_75;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_309 = 0;
    if ((unsigned char)(flen > (unsigned int)zT_309)) goto z_bb_79; else goto z_bb_80;
    z_bb_76:
    zT_317 = 1;
    zT_319 = flen - (unsigned int)((unsigned int)zT_317);
    flen = zT_319;
    goto z_bb_78;
    z_bb_77:
    zT_320 = 0;
    if ((unsigned char)(flen > (unsigned int)zT_320)) goto z_bb_82; else goto z_bb_83;
    z_bb_78:
    goto z_bb_75;
    z_bb_79:
    zT_312 = 1;
    zT_313 = flen - zT_312;
    zT_314 = fdig[zT_313];
    zT_311 = zT_314 == (unsigned char)(48);
    goto z_bb_81;
    z_bb_80:
    zT_311 = 0;
    goto z_bb_81;
    z_bb_81:
    if (zT_311) goto z_bb_76; else goto z_bb_77;
    z_bb_82:
    zT_322 = 46;
    sb[bi] = zT_322;
    zT_323 = 1;
    zT_325 = bi + (unsigned int)((unsigned int)zT_323);
    bi = zT_325;
    zT_327 = 0;
    zT_328 = (unsigned int)zT_327;
    fj = zT_328;
    goto z_bb_84;
    z_bb_83:
    zT_337 = 101;
    sb[bi] = zT_337;
    zT_338 = 1;
    zT_340 = bi + (unsigned int)((unsigned int)zT_338);
    bi = zT_340;
    ae = dexp;
    zT_342 = 0;
    if ((unsigned char)(ae < zT_342)) goto z_bb_88; else goto z_bb_90;
    z_bb_84:
    if ((unsigned char)(fj < flen)) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_330 = fdig[fj];
    sb[bi] = zT_330;
    zT_331 = 1;
    zT_333 = bi + (unsigned int)((unsigned int)zT_331);
    bi = zT_333;
    zT_334 = 1;
    zT_336 = fj + (unsigned int)((unsigned int)zT_334);
    fj = zT_336;
    goto z_bb_87;
    z_bb_86:
    goto z_bb_83;
    z_bb_87:
    goto z_bb_84;
    z_bb_88:
    zT_344 = 45;
    sb[bi] = zT_344;
    zT_345 = 1;
    zT_347 = bi + (unsigned int)((unsigned int)zT_345);
    bi = zT_347;
    zT_348 = 0;
    zT_349 = zT_348 - ae;
    ae = zT_349;
    goto z_bb_89;
    z_bb_89:
    zT_354 = 0;
    if ((unsigned char)(ae == zT_354)) goto z_bb_91; else goto z_bb_93;
    z_bb_90:
    zT_350 = 43;
    sb[bi] = zT_350;
    zT_351 = 1;
    zT_353 = bi + (unsigned int)((unsigned int)zT_351);
    bi = zT_353;
    goto z_bb_89;
    z_bb_91:
    zT_356 = 48;
    sb[bi] = zT_356;
    zT_357 = 1;
    zT_359 = bi + (unsigned int)((unsigned int)zT_357);
    bi = zT_359;
    goto z_bb_92;
    z_bb_92:
    zT_393 = 0;
    zT_394 = (unsigned char*)((unsigned char*)sb) + zT_393;
    zT_395 = bi - zT_393;
    zT_396.ptr = (unsigned char*)zT_394;
    zT_396.len = zT_395;
    zT_388 = zT_396;
    zT_389 = buf;
    zT_390 = cap;
    zT_397 = zF_11ACB4EF_fmtCopyOut(zT_388, zT_389, zT_390);
    return zT_397;
    z_bb_93:
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_361[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        eb[_i] = zT_361[_i];
        _i++;
    }
}
    zT_363 = 0;
    zT_364 = (unsigned int)zT_363;
    en = zT_364;
    av = ae;
    goto z_bb_94;
    z_bb_94:
    zT_366 = 0;
    if ((unsigned char)(av > zT_366)) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    zT_369 = 10;
    zT_373 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(int)(av % zT_369)));
    eb[en] = zT_373;
    zT_374 = 10;
    zT_375 = av / zT_374;
    av = zT_375;
    zT_376 = 1;
    zT_378 = en + (unsigned int)((unsigned int)zT_376);
    en = zT_378;
    goto z_bb_97;
    z_bb_96:
    goto z_bb_98;
    z_bb_97:
    goto z_bb_94;
    z_bb_98:
    zT_379 = 0;
    if ((unsigned char)(en > (unsigned int)zT_379)) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_381 = 1;
    zT_383 = en - (unsigned int)((unsigned int)zT_381);
    en = zT_383;
    zT_384 = eb[en];
    sb[bi] = zT_384;
    zT_385 = 1;
    zT_387 = bi + (unsigned int)((unsigned int)zT_385);
    bi = zT_387;
    goto z_bb_101;
    z_bb_100:
    goto z_bb_92;
    z_bb_101:
    goto z_bb_98;
}

/* EOF */
