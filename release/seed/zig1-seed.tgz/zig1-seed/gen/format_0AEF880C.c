#include "format_0AEF880C.h"
/* copyStr */
void zF_D67017F3_copyStr(zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int* idx, zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned char* zT_9;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = s.len;
    if ((int)(i < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = s.ptr;
    zT_10 = zT_9[i];
    zT_11 = buf.ptr;
    zT_12 = *idx;
    zT_11[zT_12] = zT_10;
    zT_13 = *idx;
    zT_14 = 1;
    *idx = (unsigned int)(zT_13 + (unsigned int)((unsigned int)zT_14));
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
}

/* formatU32 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_2(unsigned int val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_26;
    unsigned char* zT_27;
    int zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned char* zT_36;
    int zT_38;
    unsigned char* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int idx;
    unsigned int v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((int)(v == (unsigned int)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_34 = 1;
    zT_35 = idx + zT_34;
    start = zT_35;
    zT_36 = buf.ptr;
    zT_38 = 1;
    zT_40 = zT_36 + start;
    zT_41 = (unsigned int)(buf_len - zT_38) - start;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    return zT_42;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((int)(v > (unsigned int)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_26 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(v % zT_23));
    zT_27 = buf.ptr;
    zT_27[idx] = zT_26;
    zT_28 = 10;
    zT_29 = v / zT_28;
    v = zT_29;
    zT_30 = 1;
    zT_32 = idx - (unsigned int)((unsigned int)zT_30);
    idx = zT_32;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* formatU64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C3E62EC7_formatU64(zT_79FAE712_u64 val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_27;
    unsigned char* zT_28;
    int zT_29;
    zT_79FAE712_u64 zT_30;
    int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned char* zT_37;
    int zT_39;
    unsigned char* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int idx;
    zT_79FAE712_u64 v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((int)(v == (zT_79FAE712_u64)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_35 = 1;
    zT_36 = idx + zT_35;
    start = zT_36;
    zT_37 = buf.ptr;
    zT_39 = 1;
    zT_41 = zT_37 + start;
    zT_42 = (unsigned int)(buf_len - zT_39) - start;
    zT_43.ptr = zT_41;
    zT_43.len = zT_42;
    return zT_43;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((int)(v > (zT_79FAE712_u64)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_27 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(zT_79FAE712_u64)(v % zT_23)));
    zT_28 = buf.ptr;
    zT_28[idx] = zT_27;
    zT_29 = 10;
    zT_30 = v / zT_29;
    v = zT_30;
    zT_31 = 1;
    zT_33 = idx - (unsigned int)((unsigned int)zT_31);
    idx = zT_33;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* fmtBnMulSmall */
void zF_350AF0DD_fmtBnMulSmall(zT_5DB33A8A_Arr_unsigned_int_12* a, unsigned int* nlimbs, unsigned int mul) {
    int zT_4;
    zT_79FAE712_u64 zT_5;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_12;
    zT_79FAE712_u64 zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    zT_79FAE712_u64 zT_21;
    int zT_22;
    unsigned int zT_24;
    int zT_25;
    int zT_27;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_31;
    zT_79FAE712_u64 zT_32;
    unsigned int zT_33;
    int zT_34;
    zT_79FAE712_u64 carry;
    unsigned int i;
    zT_79FAE712_u64 p;
    zT_4 = 0;
    zT_5 = (zT_79FAE712_u64)zT_4;
    carry = zT_5;
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_9 = *nlimbs;
    if ((int)(i < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_12 = (*a)[i];
    zT_16 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_12) * (zT_79FAE712_u64)((zT_79FAE712_u64)mul)) + carry;
    p = zT_16;
    zT_17 = 1000000000;
    zT_19 = (unsigned int)(zT_79FAE712_u64)(p % zT_17);
    (*a)[i] = zT_19;
    zT_20 = 1000000000;
    zT_21 = p / zT_20;
    carry = zT_21;
    zT_22 = 1;
    zT_24 = i + (unsigned int)((unsigned int)zT_22);
    i = zT_24;
    goto z_bb_4;
    z_bb_3:
    goto z_bb_5;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_25 = 0;
    if ((int)(carry > (zT_79FAE712_u64)zT_25)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_27 = 1000000000;
    zT_29 = (unsigned int)(zT_79FAE712_u64)(carry % zT_27);
    zT_30 = *nlimbs;
    (*a)[zT_30] = zT_29;
    zT_31 = 1000000000;
    zT_32 = carry / zT_31;
    carry = zT_32;
    zT_33 = *nlimbs;
    zT_34 = 1;
    *nlimbs = (unsigned int)(zT_33 + (unsigned int)((unsigned int)zT_34));
    goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    goto z_bb_5;
}

/* fmtCopyOut */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_11ACB4EF_fmtCopyOut(zT_8F083A69_Slice_zT_0B42B2F8_u src, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int cap) {
    unsigned int zT_5;
    int zT_6;
    int zT_9;
    unsigned int zT_10;
    int zT_12;
    unsigned int zT_13;
    unsigned char* zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    int zT_18;
    unsigned int zT_20;
    int zT_21;
    unsigned char zT_22;
    unsigned char* zT_23;
    unsigned char* zT_24;
    int zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int n;
    unsigned int i;
    zT_5 = src.len;
    n = zT_5;
    zT_6 = 1;
    if ((int)(n > (unsigned int)(cap - zT_6))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 1;
    zT_10 = cap - zT_9;
    n = zT_10;
    goto z_bb_2;
    z_bb_2:
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    i = zT_13;
    goto z_bb_3;
    z_bb_3:
    if ((int)(i < n)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = src.ptr;
    zT_16 = zT_15[i];
    zT_17 = buf.ptr;
    zT_17[i] = zT_16;
    zT_18 = 1;
    zT_20 = i + (unsigned int)((unsigned int)zT_18);
    i = zT_20;
    goto z_bb_6;
    z_bb_5:
    zT_21 = 0;
    zT_22 = (unsigned char)zT_21;
    zT_23 = buf.ptr;
    zT_23[n] = zT_22;
    zT_24 = buf.ptr;
    zT_26 = 0;
    zT_27 = zT_24 + zT_26;
    zT_28 = n - zT_26;
    zT_29.ptr = zT_27;
    zT_29.len = zT_28;
    return zT_29;
    z_bb_6:
    goto z_bb_3;
}

/* formatF64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4CAEBE7E_formatF64(double val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned char* zT_11;
    int zT_13;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    zT_C41F1B06_Arr_unsigned_char_6 zT_19;
    int zT_21;
    unsigned int zT_22;
    unsigned char zT_25;
    int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    int zT_32;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    unsigned char zT_39;
    int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43;
    int zT_46;
    int zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51 = {0};
    unsigned char zT_55;
    int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    int zT_62;
    int zT_63;
    unsigned char* zT_64;
    unsigned int zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67 = {0};
    int zT_69;
    unsigned char zT_70;
    int zT_74;
    unsigned char zT_75;
    double zT_76;
    int zT_78;
    int zT_79;
    double zT_83;
    int zT_84;
    int zT_86;
    double zT_90;
    int zT_91;
    int zT_93;
    zT_79FAE712_u64 zT_97;
    int zT_99;
    int zT_100;
    zT_5DB33A8A_Arr_unsigned_int_12 zT_102;
    int zT_104;
    unsigned int zT_105;
    int zT_107;
    int zT_109;
    unsigned int zT_111;
    int zT_112;
    zT_79FAE712_u64 zT_113;
    int zT_114;
    unsigned int zT_116;
    int zT_118;
    int zT_119;
    int zT_120;
    int zT_123;
    int zT_124;
    zT_5DB33A8A_Arr_unsigned_int_12* zT_126;
    unsigned int* zT_127;
    int zT_131;
    int zT_133;
    int zT_135;
    int zT_136;
    int zT_137;
    int zT_139;
    int zT_140;
    int zT_142;
    int zT_143;
    zT_5DB33A8A_Arr_unsigned_int_12* zT_145;
    unsigned int* zT_146;
    int zT_150;
    int zT_152;
    int zT_154;
    int zT_156;
    unsigned int zT_157;
    unsigned int zT_159;
    int zT_161;
    unsigned int zT_162;
    int zT_163;
    int zT_165;
    unsigned int zT_167;
    int zT_168;
    unsigned int zT_169;
    int zT_171;
    int zT_175;
    int zT_177;
    int zT_179;
    int zT_181;
    zT_79FAE712_u64 zT_182;
    int zT_184;
    unsigned int zT_185;
    int zT_187;
    unsigned int zT_188;
    int zT_190;
    int zT_191;
    unsigned int zT_194;
    unsigned int zT_195;
    int zT_197;
    unsigned int zT_198;
    zT_C2AB05E7_Arr_unsigned_char_9 zT_202;
    int zT_205;
    int zT_206;
    int zT_207;
    int zT_210;
    unsigned char zT_213;
    unsigned int zT_214;
    int zT_215;
    unsigned int zT_216;
    int zT_217;
    int zT_219;
    int zT_221;
    unsigned int zT_223;
    int zT_225;
    unsigned char zT_228;
    unsigned int zT_231;
    int zT_232;
    int zT_234;
    zT_79FAE712_u64 zT_237;
    int zT_238;
    unsigned int zT_240;
    int zT_241;
    int zT_243;
    unsigned int zT_245;
    int zT_246;
    unsigned int zT_248;
    int zT_249;
    int zT_251;
    int zT_252;
    int zT_254;
    zT_79FAE712_u64 zT_255;
    int zT_256;
    unsigned int zT_258;
    int zT_259;
    int zT_261;
    zT_79FAE712_u64 zT_263;
    zT_79FAE712_u64 zT_264;
    int zT_266;
    zT_79FAE712_u64 zT_267;
    int zT_268;
    int zT_270;
    int zT_271;
    unsigned char zT_273;
    int zT_274;
    unsigned int zT_276;
    zT_79FAE712_u64 zT_278;
    zT_79FAE712_u64 zT_279;
    zT_79FAE712_u64 zT_281;
    zT_79FAE712_u64 zT_282;
    unsigned char zT_286;
    int zT_287;
    unsigned int zT_289;
    zT_5426B97B_Arr_unsigned_char_1 zT_291;
    int zT_293;
    int zT_294;
    int zT_295;
    int zT_298;
    unsigned char zT_302;
    unsigned int zT_303;
    int zT_304;
    zT_79FAE712_u64 zT_305;
    int zT_306;
    int zT_308;
    int zT_310;
    unsigned int zT_311;
    int zT_312;
    int zT_314;
    int zT_315;
    unsigned int zT_316;
    unsigned char zT_317;
    int zT_320;
    unsigned int zT_322;
    int zT_323;
    unsigned char zT_325;
    int zT_326;
    unsigned int zT_328;
    int zT_330;
    unsigned int zT_331;
    unsigned char zT_333;
    int zT_334;
    unsigned int zT_336;
    int zT_337;
    unsigned int zT_339;
    unsigned char zT_340;
    int zT_341;
    unsigned int zT_343;
    int zT_345;
    unsigned char zT_347;
    int zT_348;
    unsigned int zT_350;
    int zT_351;
    int zT_352;
    unsigned char zT_353;
    int zT_354;
    unsigned int zT_356;
    int zT_357;
    unsigned char zT_359;
    int zT_360;
    unsigned int zT_362;
    zT_C1AB0454_Arr_unsigned_char_8 zT_364;
    int zT_366;
    unsigned int zT_367;
    int zT_369;
    int zT_372;
    unsigned char zT_376;
    int zT_377;
    int zT_378;
    int zT_379;
    unsigned int zT_381;
    int zT_382;
    int zT_384;
    unsigned int zT_386;
    unsigned char zT_387;
    int zT_388;
    unsigned int zT_390;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_391;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_392;
    unsigned int zT_393;
    int zT_396;
    unsigned char* zT_397;
    unsigned int zT_398;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_399;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_400 = {0};
    unsigned int cap;
    zT_C41F1B06_Arr_unsigned_char_6 sb;
    unsigned int bi;
    unsigned char neg;
    double v;
    int e2;
    zT_79FAE712_u64 m;
    int e;
    zT_5DB33A8A_Arr_unsigned_int_12 a;
    unsigned int nlimbs;
    zT_79FAE712_u64 mm;
    int offset;
    int k;
    unsigned int top;
    unsigned int tv;
    unsigned int topdig;
    int f;
    int k2;
    int nd;
    int dexp;
    zT_79FAE712_u64 q;
    unsigned int collected;
    unsigned int d18;
    int li;
    unsigned int limb;
    unsigned int dcnt;
    zT_C2AB05E7_Arr_unsigned_char_9 tmp;
    unsigned int tt;
    int k3;
    unsigned int start;
    unsigned int j;
    unsigned int dg;
    zT_79FAE712_u64 d1;
    zT_79FAE712_u64 rest;
    zT_5426B97B_Arr_unsigned_char_1 fdig;
    int fi;
    unsigned int flen;
    unsigned int fj;
    int ae;
    zT_C1AB0454_Arr_unsigned_char_8 eb;
    unsigned int en;
    int av;
    cap = buf_len;
    zT_5 = buf.len;
    if ((int)(cap > zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_8 = buf.len;
    cap = zT_8;
    goto z_bb_2;
    z_bb_2:
    zT_9 = 0;
    if ((int)(cap == (unsigned int)zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = buf.ptr;
    zT_13 = 0;
    zT_14 = 0;
    zT_15 = zT_11 + zT_14;
    zT_16 = zT_13 - zT_14;
    zT_17.ptr = zT_15;
    zT_17.len = zT_16;
    return zT_17;
    z_bb_4:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_19[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        sb[_i] = zT_19[_i];
        _i++;
    }
}
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    bi = zT_22;
    if ((int)(val == (double)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = 48;
    zT_26 = 0;
    sb[zT_26] = zT_25;
    zT_32 = 1;
    zT_33 = 0;
    zT_34 = (unsigned char*)((unsigned char*)sb) + zT_33;
    zT_35 = zT_32 - zT_33;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_27 = zT_36;
    zT_28 = buf;
    zT_29 = cap;
    zT_37 = zF_11ACB4EF_fmtCopyOut(zT_27, zT_28, zT_29);
    return zT_37;
    z_bb_6:
    if ((int)(val != val)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_39 = 48;
    zT_40 = 0;
    sb[zT_40] = zT_39;
    zT_46 = 1;
    zT_47 = 0;
    zT_48 = (unsigned char*)((unsigned char*)sb) + zT_47;
    zT_49 = zT_46 - zT_47;
    zT_50.ptr = zT_48;
    zT_50.len = zT_49;
    zT_41 = zT_50;
    zT_42 = buf;
    zT_43 = cap;
    zT_51 = zF_11ACB4EF_fmtCopyOut(zT_41, zT_42, zT_43);
    return zT_51;
    z_bb_8:
    if ((int)((double)(val * (double)(2e+0)) == val)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_55 = 48;
    zT_56 = 0;
    sb[zT_56] = zT_55;
    zT_62 = 1;
    zT_63 = 0;
    zT_64 = (unsigned char*)((unsigned char*)sb) + zT_63;
    zT_65 = zT_62 - zT_63;
    zT_66.ptr = zT_64;
    zT_66.len = zT_65;
    zT_57 = zT_66;
    zT_58 = buf;
    zT_59 = cap;
    zT_67 = zF_11ACB4EF_fmtCopyOut(zT_57, zT_58, zT_59);
    return zT_67;
    z_bb_10:
    zT_69 = 0;
    zT_70 = (unsigned char)zT_69;
    neg = zT_70;
    v = val;
    if ((int)(v < (double)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_74 = 1;
    zT_75 = (unsigned char)zT_74;
    neg = zT_75;
    zT_76 = -v;
    v = zT_76;
    goto z_bb_12;
    z_bb_12:
    zT_78 = 0;
    zT_79 = (int)zT_78;
    e2 = zT_79;
    goto z_bb_13;
    z_bb_13:
    if ((int)(v >= (double)(2e+0))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_83 = v / (double)(2e+0);
    v = zT_83;
    zT_84 = 1;
    zT_86 = e2 + (int)((int)zT_84);
    e2 = zT_86;
    goto z_bb_16;
    z_bb_15:
    goto z_bb_17;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((int)(v < (double)(1e+0))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_90 = v * (double)(2e+0);
    v = zT_90;
    zT_91 = 1;
    zT_93 = e2 - (int)((int)zT_91);
    e2 = zT_93;
    goto z_bb_20;
    z_bb_19:
    zT_97 = (zT_79FAE712_u64)(double)(v * (double)(4.503599627370496e+15));
    m = zT_97;
    zT_99 = 52;
    zT_100 = e2 - zT_99;
    e = zT_100;
    {
    unsigned int _i = 0;
    while (_i < 128) {
        zT_102[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 128) {
        a[_i] = zT_102[_i];
        _i++;
    }
}
    zT_104 = 0;
    zT_105 = (unsigned int)zT_104;
    nlimbs = zT_105;
    mm = m;
    goto z_bb_21;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_107 = 0;
    if ((int)(mm > (zT_79FAE712_u64)zT_107)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_109 = 1000000000;
    zT_111 = (unsigned int)(zT_79FAE712_u64)(mm % zT_109);
    a[nlimbs] = zT_111;
    zT_112 = 1000000000;
    zT_113 = mm / zT_112;
    mm = zT_113;
    zT_114 = 1;
    zT_116 = nlimbs + (unsigned int)((unsigned int)zT_114);
    nlimbs = zT_116;
    goto z_bb_24;
    z_bb_23:
    zT_118 = 0;
    zT_119 = (int)zT_118;
    offset = zT_119;
    zT_120 = 0;
    if ((int)(e >= zT_120)) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_123 = 0;
    zT_124 = (int)zT_123;
    k = zT_124;
    goto z_bb_28;
    z_bb_26:
    zT_156 = 1;
    zT_157 = nlimbs - zT_156;
    top = zT_157;
    zT_159 = a[top];
    tv = zT_159;
    zT_161 = 0;
    zT_162 = (unsigned int)zT_161;
    topdig = zT_162;
    goto z_bb_36;
    z_bb_27:
    zT_139 = 0;
    zT_140 = zT_139 - e;
    f = zT_140;
    zT_142 = 0;
    zT_143 = (int)zT_142;
    k2 = zT_143;
    goto z_bb_32;
    z_bb_28:
    if ((int)(k < e)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_126 = &a;
    zT_127 = &nlimbs;
    zT_131 = 2;
    zF_350AF0DD_fmtBnMulSmall(zT_126, zT_127, (unsigned int)((unsigned int)zT_131));
    zT_133 = 1;
    zT_135 = k + (int)((int)zT_133);
    k = zT_135;
    goto z_bb_31;
    z_bb_30:
    zT_136 = 0;
    zT_137 = (int)zT_136;
    offset = zT_137;
    goto z_bb_26;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    if ((int)(k2 < f)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_145 = &a;
    zT_146 = &nlimbs;
    zT_150 = 5;
    zF_350AF0DD_fmtBnMulSmall(zT_145, zT_146, (unsigned int)((unsigned int)zT_150));
    zT_152 = 1;
    zT_154 = k2 + (int)((int)zT_152);
    k2 = zT_154;
    goto z_bb_35;
    z_bb_34:
    offset = e;
    goto z_bb_26;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_163 = 0;
    if ((int)(tv > (unsigned int)zT_163)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_165 = 1;
    zT_167 = topdig + (unsigned int)((unsigned int)zT_165);
    topdig = zT_167;
    zT_168 = 10;
    zT_169 = tv / zT_168;
    tv = zT_169;
    goto z_bb_39;
    z_bb_38:
    zT_171 = 9;
    zT_175 = (int)((int)(unsigned int)(top * zT_171)) + (int)((int)topdig);
    nd = zT_175;
    zT_177 = 1;
    zT_179 = (int)(nd - zT_177) + offset;
    dexp = zT_179;
    zT_181 = 0;
    zT_182 = (zT_79FAE712_u64)zT_181;
    q = zT_182;
    zT_184 = 0;
    zT_185 = (unsigned int)zT_184;
    collected = zT_185;
    zT_187 = 0;
    zT_188 = (unsigned int)zT_187;
    d18 = zT_188;
    zT_190 = (int)top;
    li = zT_190;
    goto z_bb_40;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_191 = 0;
    if ((int)(li >= zT_191)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_194 = (unsigned int)li;
    zT_195 = a[zT_194];
    limb = zT_195;
    zT_197 = 9;
    zT_198 = (unsigned int)zT_197;
    dcnt = zT_198;
    if ((int)(li == (int)((int)top))) goto z_bb_44; else goto z_bb_45;
    z_bb_42:
    goto z_bb_59;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    dcnt = topdig;
    goto z_bb_45;
    z_bb_45:
    {
    unsigned int _i = 0;
    while (_i < 9) {
        zT_202[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 9) {
        tmp[_i] = zT_202[_i];
        _i++;
    }
}
    tt = limb;
    zT_205 = 8;
    zT_206 = (int)zT_205;
    k3 = zT_206;
    goto z_bb_46;
    z_bb_46:
    zT_207 = 0;
    if ((int)(k3 >= zT_207)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_210 = 10;
    zT_213 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(tt % zT_210));
    zT_214 = (unsigned int)k3;
    tmp[zT_214] = zT_213;
    zT_215 = 10;
    zT_216 = tt / zT_215;
    tt = zT_216;
    zT_217 = 1;
    zT_219 = k3 - (int)((int)zT_217);
    k3 = zT_219;
    goto z_bb_49;
    z_bb_48:
    zT_221 = 9;
    zT_223 = zT_221 - (unsigned int)((unsigned int)dcnt);
    start = zT_223;
    j = start;
    goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_225 = 9;
    if ((int)(j < (unsigned int)zT_225)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_228 = tmp[j];
    zT_231 = (unsigned int)(unsigned char)(zT_228 - (unsigned char)(48));
    dg = zT_231;
    zT_232 = 17;
    if ((int)(collected < (unsigned int)zT_232)) goto z_bb_54; else goto z_bb_56;
    z_bb_52:
    zT_249 = 1;
    zT_251 = li - (int)((int)zT_249);
    li = zT_251;
    goto z_bb_43;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    zT_234 = 10;
    zT_237 = (zT_79FAE712_u64)(q * zT_234) + (zT_79FAE712_u64)((zT_79FAE712_u64)dg);
    q = zT_237;
    zT_238 = 1;
    zT_240 = collected + (unsigned int)((unsigned int)zT_238);
    collected = zT_240;
    goto z_bb_55;
    z_bb_55:
    zT_246 = 1;
    zT_248 = j + (unsigned int)((unsigned int)zT_246);
    j = zT_248;
    goto z_bb_53;
    z_bb_56:
    zT_241 = 17;
    if ((int)(collected == (unsigned int)zT_241)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    d18 = dg;
    zT_243 = 1;
    zT_245 = collected + (unsigned int)((unsigned int)zT_243);
    collected = zT_245;
    goto z_bb_58;
    z_bb_58:
    goto z_bb_55;
    z_bb_59:
    zT_252 = 17;
    if ((int)(collected < (unsigned int)zT_252)) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_254 = 10;
    zT_255 = q * zT_254;
    q = zT_255;
    zT_256 = 1;
    zT_258 = collected + (unsigned int)((unsigned int)zT_256);
    collected = zT_258;
    goto z_bb_62;
    z_bb_61:
    zT_259 = 5;
    if ((int)(d18 >= (unsigned int)zT_259)) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_59;
    z_bb_63:
    zT_261 = 1;
    zT_263 = q + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_261);
    q = zT_263;
    goto z_bb_64;
    z_bb_64:
    zT_264 = 100000000000000000ULL;
    if ((int)(q >= (zT_79FAE712_u64)zT_264)) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_266 = 10;
    zT_267 = q / zT_266;
    q = zT_267;
    zT_268 = 1;
    zT_270 = dexp + (int)((int)zT_268);
    dexp = zT_270;
    goto z_bb_66;
    z_bb_66:
    zT_271 = 0;
    if ((int)(neg != zT_271)) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_273 = 45;
    sb[bi] = zT_273;
    zT_274 = 1;
    zT_276 = bi + (unsigned int)((unsigned int)zT_274);
    bi = zT_276;
    goto z_bb_68;
    z_bb_68:
    zT_278 = 10000000000000000ULL;
    zT_279 = q / zT_278;
    d1 = zT_279;
    zT_281 = 10000000000000000ULL;
    zT_282 = q % zT_281;
    rest = zT_282;
    zT_286 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)d1));
    sb[bi] = zT_286;
    zT_287 = 1;
    zT_289 = bi + (unsigned int)((unsigned int)zT_287);
    bi = zT_289;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_291[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fdig[_i] = zT_291[_i];
        _i++;
    }
}
    zT_293 = 15;
    zT_294 = (int)zT_293;
    fi = zT_294;
    goto z_bb_69;
    z_bb_69:
    zT_295 = 0;
    if ((int)(fi >= zT_295)) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_298 = 10;
    zT_302 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(zT_79FAE712_u64)(rest % zT_298)));
    zT_303 = (unsigned int)fi;
    fdig[zT_303] = zT_302;
    zT_304 = 10;
    zT_305 = rest / zT_304;
    rest = zT_305;
    zT_306 = 1;
    zT_308 = fi - (int)((int)zT_306);
    fi = zT_308;
    goto z_bb_72;
    z_bb_71:
    zT_310 = 16;
    zT_311 = (unsigned int)zT_310;
    flen = zT_311;
    goto z_bb_73;
    z_bb_72:
    goto z_bb_69;
    z_bb_73:
    zT_312 = 0;
    if ((int)(flen > (unsigned int)zT_312)) goto z_bb_77; else goto z_bb_78;
    z_bb_74:
    zT_320 = 1;
    zT_322 = flen - (unsigned int)((unsigned int)zT_320);
    flen = zT_322;
    goto z_bb_76;
    z_bb_75:
    zT_323 = 0;
    if ((int)(flen > (unsigned int)zT_323)) goto z_bb_80; else goto z_bb_81;
    z_bb_76:
    goto z_bb_73;
    z_bb_77:
    zT_315 = 1;
    zT_316 = flen - zT_315;
    zT_317 = fdig[zT_316];
    zT_314 = zT_317 == (unsigned char)(48);
    goto z_bb_79;
    z_bb_78:
    zT_314 = 0;
    goto z_bb_79;
    z_bb_79:
    if (zT_314) goto z_bb_74; else goto z_bb_75;
    z_bb_80:
    zT_325 = 46;
    sb[bi] = zT_325;
    zT_326 = 1;
    zT_328 = bi + (unsigned int)((unsigned int)zT_326);
    bi = zT_328;
    zT_330 = 0;
    zT_331 = (unsigned int)zT_330;
    fj = zT_331;
    goto z_bb_82;
    z_bb_81:
    zT_340 = 101;
    sb[bi] = zT_340;
    zT_341 = 1;
    zT_343 = bi + (unsigned int)((unsigned int)zT_341);
    bi = zT_343;
    ae = dexp;
    zT_345 = 0;
    if ((int)(ae < zT_345)) goto z_bb_86; else goto z_bb_88;
    z_bb_82:
    if ((int)(fj < flen)) goto z_bb_83; else goto z_bb_84;
    z_bb_83:
    zT_333 = fdig[fj];
    sb[bi] = zT_333;
    zT_334 = 1;
    zT_336 = bi + (unsigned int)((unsigned int)zT_334);
    bi = zT_336;
    zT_337 = 1;
    zT_339 = fj + (unsigned int)((unsigned int)zT_337);
    fj = zT_339;
    goto z_bb_85;
    z_bb_84:
    goto z_bb_81;
    z_bb_85:
    goto z_bb_82;
    z_bb_86:
    zT_347 = 45;
    sb[bi] = zT_347;
    zT_348 = 1;
    zT_350 = bi + (unsigned int)((unsigned int)zT_348);
    bi = zT_350;
    zT_351 = 0;
    zT_352 = zT_351 - ae;
    ae = zT_352;
    goto z_bb_87;
    z_bb_87:
    zT_357 = 0;
    if ((int)(ae == zT_357)) goto z_bb_89; else goto z_bb_91;
    z_bb_88:
    zT_353 = 43;
    sb[bi] = zT_353;
    zT_354 = 1;
    zT_356 = bi + (unsigned int)((unsigned int)zT_354);
    bi = zT_356;
    goto z_bb_87;
    z_bb_89:
    zT_359 = 48;
    sb[bi] = zT_359;
    zT_360 = 1;
    zT_362 = bi + (unsigned int)((unsigned int)zT_360);
    bi = zT_362;
    goto z_bb_90;
    z_bb_90:
    zT_396 = 0;
    zT_397 = (unsigned char*)((unsigned char*)sb) + zT_396;
    zT_398 = bi - zT_396;
    zT_399.ptr = zT_397;
    zT_399.len = zT_398;
    zT_391 = zT_399;
    zT_392 = buf;
    zT_393 = cap;
    zT_400 = zF_11ACB4EF_fmtCopyOut(zT_391, zT_392, zT_393);
    return zT_400;
    z_bb_91:
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_364[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        eb[_i] = zT_364[_i];
        _i++;
    }
}
    zT_366 = 0;
    zT_367 = (unsigned int)zT_366;
    en = zT_367;
    av = ae;
    goto z_bb_92;
    z_bb_92:
    zT_369 = 0;
    if ((int)(av > zT_369)) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_372 = 10;
    zT_376 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(int)(av % zT_372)));
    eb[en] = zT_376;
    zT_377 = 10;
    zT_378 = av / zT_377;
    av = zT_378;
    zT_379 = 1;
    zT_381 = en + (unsigned int)((unsigned int)zT_379);
    en = zT_381;
    goto z_bb_95;
    z_bb_94:
    goto z_bb_96;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_382 = 0;
    if ((int)(en > (unsigned int)zT_382)) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_384 = 1;
    zT_386 = en - (unsigned int)((unsigned int)zT_384);
    en = zT_386;
    zT_387 = eb[en];
    sb[bi] = zT_387;
    zT_388 = 1;
    zT_390 = bi + (unsigned int)((unsigned int)zT_388);
    bi = zT_390;
    goto z_bb_99;
    z_bb_98:
    goto z_bb_90;
    z_bb_99:
    goto z_bb_96;
}

/* EOF */
