#include "format_0AEF880C.h"
/* copyStr */
void zF_D67017F3_copyStr(zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int* idx, zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned char* zT_9;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = s.len;
    if ((int)(i < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = s.ptr;
    zT_10 = zT_9[i];
    zT_11 = buf.ptr;
    zT_12 = *idx;
    zT_11[zT_12] = zT_10;
    zT_13 = *idx;
    zT_14 = 1;
    *idx = (unsigned int)(zT_13 + (unsigned int)((unsigned int)zT_14));
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
}

/* formatU32 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_2(unsigned int val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_26;
    unsigned char* zT_27;
    int zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned char* zT_36;
    int zT_38;
    unsigned char* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int idx;
    unsigned int v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((int)(v == (unsigned int)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_34 = 1;
    zT_35 = idx + zT_34;
    start = zT_35;
    zT_36 = buf.ptr;
    zT_38 = 1;
    zT_40 = zT_36 + start;
    zT_41 = (unsigned int)(buf_len - zT_38) - start;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    return zT_42;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((int)(v > (unsigned int)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_26 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(v % zT_23));
    zT_27 = buf.ptr;
    zT_27[idx] = zT_26;
    zT_28 = 10;
    zT_29 = v / zT_28;
    v = zT_29;
    zT_30 = 1;
    zT_32 = idx - (unsigned int)((unsigned int)zT_30);
    idx = zT_32;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* formatU64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C3E62EC7_formatU64(zT_79FAE712_u64 val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_27;
    unsigned char* zT_28;
    int zT_29;
    zT_79FAE712_u64 zT_30;
    int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned char* zT_37;
    int zT_39;
    unsigned char* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int idx;
    zT_79FAE712_u64 v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((int)(v == (zT_79FAE712_u64)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_35 = 1;
    zT_36 = idx + zT_35;
    start = zT_36;
    zT_37 = buf.ptr;
    zT_39 = 1;
    zT_41 = zT_37 + start;
    zT_42 = (unsigned int)(buf_len - zT_39) - start;
    zT_43.ptr = zT_41;
    zT_43.len = zT_42;
    return zT_43;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((int)(v > (zT_79FAE712_u64)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_27 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(zT_79FAE712_u64)(v % zT_23)));
    zT_28 = buf.ptr;
    zT_28[idx] = zT_27;
    zT_29 = 10;
    zT_30 = v / zT_29;
    v = zT_30;
    zT_31 = 1;
    zT_33 = idx - (unsigned int)((unsigned int)zT_31);
    idx = zT_33;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* extractDigit */
int zF_4EC5758B_extractDigit(double v) {
    int zT_3;
    int zT_7;
    int zT_11;
    int zT_15;
    int zT_19;
    int zT_23;
    int zT_27;
    int zT_31;
    int zT_35;
    int zT_37;
    if ((int)(v >= (double)(9))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = 9;
    return (int)((int)zT_3);
    z_bb_2:
    if ((int)(v >= (double)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 8;
    return (int)((int)zT_7);
    z_bb_4:
    if ((int)(v >= (double)(7))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_11 = 7;
    return (int)((int)zT_11);
    z_bb_6:
    if ((int)(v >= (double)(6))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_15 = 6;
    return (int)((int)zT_15);
    z_bb_8:
    if ((int)(v >= (double)(5))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_19 = 5;
    return (int)((int)zT_19);
    z_bb_10:
    if ((int)(v >= (double)(4))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_23 = 4;
    return (int)((int)zT_23);
    z_bb_12:
    if ((int)(v >= (double)(3))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_27 = 3;
    return (int)((int)zT_27);
    z_bb_14:
    if ((int)(v >= (double)(2))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_31 = 2;
    return (int)((int)zT_31);
    z_bb_16:
    if ((int)(v >= (double)(1))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_35 = 1;
    return (int)((int)zT_35);
    z_bb_18:
    zT_37 = 0;
    return (int)((int)zT_37);
}

/* formatF64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4CAEBE7E_formatF64(double val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned char zT_5;
    int zT_7;
    int zT_9;
    unsigned char zT_10;
    double zT_11;
    int zT_13;
    int zT_14;
    int zT_17;
    double zT_23;
    int zT_24;
    int zT_26;
    int zT_29;
    double zT_33;
    int zT_34;
    int zT_36;
    zT_C41F1B06_Arr_unsigned_char_6 zT_38;
    int zT_40;
    int zT_41;
    int zT_43;
    double zT_46;
    int zT_47 = 0;
    unsigned char zT_51;
    unsigned int zT_52;
    int zT_53;
    int zT_55;
    double zT_59;
    int zT_61;
    int zT_62;
    int zT_63;
    unsigned char zT_65;
    unsigned char* zT_66;
    unsigned int zT_67;
    int zT_68;
    int zT_70;
    int zT_72;
    int zT_73;
    unsigned int zT_74;
    unsigned char zT_75;
    unsigned char* zT_76;
    unsigned int zT_77;
    int zT_78;
    int zT_80;
    int zT_81;
    int zT_83;
    int zT_85;
    unsigned char zT_86;
    int zT_87;
    unsigned int zT_89;
    unsigned char zT_90;
    int zT_93;
    unsigned char zT_94;
    int zT_95;
    int zT_97;
    int zT_98;
    unsigned char zT_100;
    unsigned char* zT_101;
    unsigned int zT_102;
    int zT_103;
    int zT_105;
    int zT_106;
    int zT_107;
    int zT_108;
    unsigned int zT_110;
    unsigned char zT_111;
    unsigned char* zT_112;
    unsigned int zT_113;
    int zT_114;
    int zT_116;
    int zT_117;
    int zT_119;
    int zT_120;
    unsigned char zT_122;
    unsigned char* zT_123;
    unsigned int zT_124;
    int zT_125;
    int zT_127;
    int zT_128;
    int zT_129;
    int zT_130;
    unsigned int zT_132;
    unsigned char zT_133;
    unsigned char* zT_134;
    unsigned int zT_135;
    int zT_136;
    int zT_138;
    int zT_139;
    int zT_141;
    int zT_142;
    unsigned char zT_144;
    unsigned char* zT_145;
    unsigned int zT_146;
    int zT_147;
    int zT_149;
    int zT_150;
    unsigned char zT_152;
    unsigned char* zT_153;
    unsigned int zT_154;
    int zT_155;
    int zT_157;
    int zT_158;
    unsigned char zT_159;
    unsigned char* zT_160;
    unsigned int zT_161;
    int zT_162;
    int zT_164;
    zT_C1AB0454_Arr_unsigned_char_8 zT_166;
    int zT_168;
    int zT_169;
    int zT_170;
    unsigned char zT_171;
    unsigned int zT_172;
    int zT_173;
    int zT_175;
    int zT_177;
    int zT_180;
    unsigned char zT_184;
    unsigned int zT_185;
    int zT_186;
    int zT_187;
    int zT_188;
    int zT_190;
    int zT_191;
    int zT_193;
    int zT_195;
    unsigned int zT_197;
    unsigned char zT_198;
    unsigned char* zT_199;
    unsigned int zT_200;
    int zT_201;
    int zT_203;
    int zT_204;
    int zT_206;
    int zT_207;
    unsigned char zT_208;
    unsigned char* zT_209;
    unsigned int zT_210;
    unsigned char* zT_211;
    int zT_214;
    unsigned char* zT_215;
    unsigned int zT_216;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_217;
    unsigned char is_neg;
    double v;
    int exp;
    zT_C41F1B06_Arr_unsigned_char_6 fmt_buf;
    int fi;
    double rem;
    int digit;
    int bi;
    int di;
    unsigned char has_frac;
    zT_C1AB0454_Arr_unsigned_char_8 exp_buf;
    int ei;
    int expv;
    (void)buf_len;
    zT_4 = 0;
    zT_5 = (unsigned char)zT_4;
    is_neg = zT_5;
    v = val;
    zT_7 = 0;
    if ((int)(v < zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = 1;
    zT_10 = (unsigned char)zT_9;
    is_neg = zT_10;
    zT_11 = -v;
    v = zT_11;
    goto z_bb_2;
    z_bb_2:
    zT_13 = 0;
    zT_14 = (int)zT_13;
    exp = zT_14;
    if ((int)(v >= (double)(1.00000e+1))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_17 = v < (double)(1);
    goto z_bb_5;
    z_bb_4:
    zT_17 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_17) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_38[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        fmt_buf[_i] = zT_38[_i];
        _i++;
    }
}
    zT_40 = 0;
    zT_41 = (int)zT_40;
    fi = zT_41;
    rem = v;
    goto z_bb_19;
    z_bb_8:
    if ((int)(v >= (double)(1.00000e+1))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_23 = v / (double)(1.00000e+1);
    v = zT_23;
    zT_24 = 1;
    zT_26 = exp + (int)((int)zT_24);
    exp = zT_26;
    goto z_bb_11;
    z_bb_10:
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    if ((int)(v < (double)(1))) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_33 = v * (double)(1.00000e+1);
    v = zT_33;
    zT_34 = 1;
    zT_36 = exp - (int)((int)zT_34);
    exp = zT_36;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_7;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_29 = v != (double)(0);
    goto z_bb_18;
    z_bb_17:
    zT_29 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_29) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    zT_43 = 6;
    if ((int)(fi < zT_43)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_46 = rem;
    zT_47 = zF_4EC5758B_extractDigit(zT_46);
    digit = zT_47;
    zT_51 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)digit));
    zT_52 = (unsigned int)fi;
    fmt_buf[zT_52] = zT_51;
    zT_53 = 1;
    zT_55 = fi + (int)((int)zT_53);
    fi = zT_55;
    zT_59 = (double)(rem - (double)((double)digit)) * (double)(1.00000e+1);
    rem = zT_59;
    goto z_bb_22;
    z_bb_21:
    zT_61 = 0;
    zT_62 = (int)zT_61;
    bi = zT_62;
    zT_63 = 0;
    if ((int)(is_neg != zT_63)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_65 = 45;
    zT_66 = buf.ptr;
    zT_67 = (unsigned int)bi;
    zT_66[zT_67] = zT_65;
    zT_68 = 1;
    zT_70 = bi + (int)((int)zT_68);
    bi = zT_70;
    goto z_bb_24;
    z_bb_24:
    zT_72 = 0;
    zT_73 = (int)zT_72;
    di = zT_73;
    zT_74 = (unsigned int)di;
    zT_75 = fmt_buf[zT_74];
    zT_76 = buf.ptr;
    zT_77 = (unsigned int)bi;
    zT_76[zT_77] = zT_75;
    zT_78 = 1;
    zT_80 = bi + (int)((int)zT_78);
    bi = zT_80;
    zT_81 = 1;
    zT_83 = di + (int)((int)zT_81);
    di = zT_83;
    zT_85 = 0;
    zT_86 = (unsigned char)zT_85;
    has_frac = zT_86;
    goto z_bb_25;
    z_bb_25:
    zT_87 = 6;
    if ((int)(di < zT_87)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_89 = (unsigned int)di;
    zT_90 = fmt_buf[zT_89];
    if ((int)(zT_90 != (unsigned char)(48))) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_98 = 0;
    if ((int)(has_frac != zT_98)) goto z_bb_31; else goto z_bb_33;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_93 = 1;
    zT_94 = (unsigned char)zT_93;
    has_frac = zT_94;
    goto z_bb_30;
    z_bb_30:
    zT_95 = 1;
    zT_97 = di + (int)((int)zT_95);
    di = zT_97;
    goto z_bb_28;
    z_bb_31:
    zT_100 = 46;
    zT_101 = buf.ptr;
    zT_102 = (unsigned int)bi;
    zT_101[zT_102] = zT_100;
    zT_103 = 1;
    zT_105 = bi + (int)((int)zT_103);
    bi = zT_105;
    zT_106 = 1;
    zT_107 = (int)zT_106;
    di = zT_107;
    goto z_bb_34;
    z_bb_32:
    zT_142 = 0;
    if ((int)(exp != zT_142)) goto z_bb_44; else goto z_bb_45;
    z_bb_33:
    zT_120 = 0;
    if ((int)(exp != zT_120)) goto z_bb_38; else goto z_bb_39;
    z_bb_34:
    zT_108 = 6;
    if ((int)(di < zT_108)) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_110 = (unsigned int)di;
    zT_111 = fmt_buf[zT_110];
    zT_112 = buf.ptr;
    zT_113 = (unsigned int)bi;
    zT_112[zT_113] = zT_111;
    zT_114 = 1;
    zT_116 = bi + (int)((int)zT_114);
    bi = zT_116;
    zT_117 = 1;
    zT_119 = di + (int)((int)zT_117);
    di = zT_119;
    goto z_bb_37;
    z_bb_36:
    goto z_bb_32;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_122 = 46;
    zT_123 = buf.ptr;
    zT_124 = (unsigned int)bi;
    zT_123[zT_124] = zT_122;
    zT_125 = 1;
    zT_127 = bi + (int)((int)zT_125);
    bi = zT_127;
    zT_128 = 1;
    zT_129 = (int)zT_128;
    di = zT_129;
    goto z_bb_40;
    z_bb_39:
    goto z_bb_32;
    z_bb_40:
    zT_130 = 6;
    if ((int)(di < zT_130)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_132 = (unsigned int)di;
    zT_133 = fmt_buf[zT_132];
    zT_134 = buf.ptr;
    zT_135 = (unsigned int)bi;
    zT_134[zT_135] = zT_133;
    zT_136 = 1;
    zT_138 = bi + (int)((int)zT_136);
    bi = zT_138;
    zT_139 = 1;
    zT_141 = di + (int)((int)zT_139);
    di = zT_141;
    goto z_bb_43;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_144 = 101;
    zT_145 = buf.ptr;
    zT_146 = (unsigned int)bi;
    zT_145[zT_146] = zT_144;
    zT_147 = 1;
    zT_149 = bi + (int)((int)zT_147);
    bi = zT_149;
    zT_150 = 0;
    if ((int)(exp < zT_150)) goto z_bb_46; else goto z_bb_48;
    z_bb_45:
    zT_207 = 0;
    zT_208 = (unsigned char)zT_207;
    zT_209 = buf.ptr;
    zT_210 = (unsigned int)bi;
    zT_209[zT_210] = zT_208;
    zT_211 = buf.ptr;
    zT_214 = 0;
    zT_215 = zT_211 + zT_214;
    zT_216 = (unsigned int)((unsigned int)bi) - zT_214;
    zT_217.ptr = zT_215;
    zT_217.len = zT_216;
    return zT_217;
    z_bb_46:
    zT_152 = 45;
    zT_153 = buf.ptr;
    zT_154 = (unsigned int)bi;
    zT_153[zT_154] = zT_152;
    zT_155 = 1;
    zT_157 = bi + (int)((int)zT_155);
    bi = zT_157;
    zT_158 = -exp;
    exp = zT_158;
    goto z_bb_47;
    z_bb_47:
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_166[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        exp_buf[_i] = zT_166[_i];
        _i++;
    }
}
    zT_168 = 7;
    zT_169 = (int)zT_168;
    ei = zT_169;
    zT_170 = 0;
    zT_171 = (unsigned char)zT_170;
    zT_172 = (unsigned int)ei;
    exp_buf[zT_172] = zT_171;
    zT_173 = 1;
    zT_175 = ei - (int)((int)zT_173);
    ei = zT_175;
    expv = exp;
    goto z_bb_49;
    z_bb_48:
    zT_159 = 43;
    zT_160 = buf.ptr;
    zT_161 = (unsigned int)bi;
    zT_160[zT_161] = zT_159;
    zT_162 = 1;
    zT_164 = bi + (int)((int)zT_162);
    bi = zT_164;
    goto z_bb_47;
    z_bb_49:
    zT_177 = 0;
    if ((int)(expv > zT_177)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_180 = 10;
    zT_184 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(int)(expv % zT_180)));
    zT_185 = (unsigned int)ei;
    exp_buf[zT_185] = zT_184;
    zT_186 = 10;
    zT_187 = expv / zT_186;
    expv = zT_187;
    zT_188 = 1;
    zT_190 = ei - (int)((int)zT_188);
    ei = zT_190;
    goto z_bb_52;
    z_bb_51:
    zT_191 = 1;
    zT_193 = ei + (int)((int)zT_191);
    ei = zT_193;
    goto z_bb_53;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_195 = 7;
    if ((int)((unsigned int)((unsigned int)ei) < (unsigned int)zT_195)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_197 = (unsigned int)ei;
    zT_198 = exp_buf[zT_197];
    zT_199 = buf.ptr;
    zT_200 = (unsigned int)bi;
    zT_199[zT_200] = zT_198;
    zT_201 = 1;
    zT_203 = bi + (int)((int)zT_201);
    bi = zT_203;
    zT_204 = 1;
    zT_206 = ei + (int)((int)zT_204);
    ei = zT_206;
    goto z_bb_56;
    z_bb_55:
    goto z_bb_45;
    z_bb_56:
    goto z_bb_53;
}

/* EOF */
