#include "format_0AEF880C.h"
/* copyStr */
void zF_D67017F3_copyStr(zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int* idx, zT_8F083A69_Slice_zT_0B42B2F8_u s) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned char* zT_9;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = s.len;
    if ((int)(i < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = s.ptr;
    zT_10 = zT_9[i];
    zT_11 = buf.ptr;
    zT_12 = *idx;
    zT_11[zT_12] = zT_10;
    zT_13 = *idx;
    zT_14 = 1;
    *idx = (unsigned int)(zT_13 + (unsigned int)((unsigned int)zT_14));
    zT_17 = 1;
    zT_19 = i + (unsigned int)((unsigned int)zT_17);
    i = zT_19;
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
}

/* formatU32 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2FED9490_formatU32_2(unsigned int val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_26;
    unsigned char* zT_27;
    int zT_28;
    unsigned int zT_29;
    int zT_30;
    unsigned int zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned char* zT_36;
    int zT_38;
    unsigned char* zT_40;
    unsigned int zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int idx;
    unsigned int v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((int)(v == (unsigned int)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_34 = 1;
    zT_35 = idx + zT_34;
    start = zT_35;
    zT_36 = buf.ptr;
    zT_38 = 1;
    zT_40 = zT_36 + start;
    zT_41 = (unsigned int)(buf_len - zT_38) - start;
    zT_42.ptr = zT_40;
    zT_42.len = zT_41;
    return zT_42;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((int)(v > (unsigned int)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_26 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)(v % zT_23));
    zT_27 = buf.ptr;
    zT_27[idx] = zT_26;
    zT_28 = 10;
    zT_29 = v / zT_28;
    v = zT_29;
    zT_30 = 1;
    zT_32 = idx - (unsigned int)((unsigned int)zT_30);
    idx = zT_32;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* formatU64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C3E62EC7_formatU64(zT_79FAE712_u64 val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    int zT_4;
    unsigned int zT_5;
    int zT_7;
    unsigned char zT_8;
    unsigned char* zT_9;
    int zT_10;
    unsigned int zT_12;
    int zT_13;
    unsigned char zT_15;
    unsigned char* zT_16;
    int zT_17;
    unsigned int zT_19;
    int zT_20;
    int zT_23;
    unsigned char zT_27;
    unsigned char* zT_28;
    int zT_29;
    zT_79FAE712_u64 zT_30;
    int zT_31;
    unsigned int zT_33;
    int zT_35;
    unsigned int zT_36;
    unsigned char* zT_37;
    int zT_39;
    unsigned char* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int idx;
    zT_79FAE712_u64 v;
    unsigned int start;
    zT_4 = 1;
    zT_5 = buf_len - zT_4;
    idx = zT_5;
    v = val;
    zT_7 = 0;
    zT_8 = (unsigned char)zT_7;
    zT_9 = buf.ptr;
    zT_9[idx] = zT_8;
    zT_10 = 1;
    zT_12 = idx - (unsigned int)((unsigned int)zT_10);
    idx = zT_12;
    zT_13 = 0;
    if ((int)(v == (zT_79FAE712_u64)zT_13)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_15 = 48;
    zT_16 = buf.ptr;
    zT_16[idx] = zT_15;
    zT_17 = 1;
    zT_19 = idx - (unsigned int)((unsigned int)zT_17);
    idx = zT_19;
    goto z_bb_2;
    z_bb_2:
    zT_35 = 1;
    zT_36 = idx + zT_35;
    start = zT_36;
    zT_37 = buf.ptr;
    zT_39 = 1;
    zT_41 = zT_37 + start;
    zT_42 = (unsigned int)(buf_len - zT_39) - start;
    zT_43.ptr = zT_41;
    zT_43.len = zT_42;
    return zT_43;
    z_bb_3:
    goto z_bb_4;
    z_bb_4:
    zT_20 = 0;
    if ((int)(v > (zT_79FAE712_u64)zT_20)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_23 = 10;
    zT_27 = (unsigned char)(unsigned int)((unsigned int)(48) + (unsigned int)((unsigned int)(zT_79FAE712_u64)(v % zT_23)));
    zT_28 = buf.ptr;
    zT_28[idx] = zT_27;
    zT_29 = 10;
    zT_30 = v / zT_29;
    v = zT_30;
    zT_31 = 1;
    zT_33 = idx - (unsigned int)((unsigned int)zT_31);
    idx = zT_33;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_2;
    z_bb_7:
    goto z_bb_4;
}

/* extractDigit */
int zF_4EC5758B_extractDigit(double v) {
    int zT_3;
    int zT_7;
    int zT_11;
    int zT_15;
    int zT_19;
    int zT_23;
    int zT_27;
    int zT_31;
    int zT_35;
    int zT_37;
    if ((int)(v >= (double)(9))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = 9;
    return (int)((int)zT_3);
    z_bb_2:
    if ((int)(v >= (double)(8))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 8;
    return (int)((int)zT_7);
    z_bb_4:
    if ((int)(v >= (double)(7))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_11 = 7;
    return (int)((int)zT_11);
    z_bb_6:
    if ((int)(v >= (double)(6))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_15 = 6;
    return (int)((int)zT_15);
    z_bb_8:
    if ((int)(v >= (double)(5))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_19 = 5;
    return (int)((int)zT_19);
    z_bb_10:
    if ((int)(v >= (double)(4))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_23 = 4;
    return (int)((int)zT_23);
    z_bb_12:
    if ((int)(v >= (double)(3))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_27 = 3;
    return (int)((int)zT_27);
    z_bb_14:
    if ((int)(v >= (double)(2))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_31 = 2;
    return (int)((int)zT_31);
    z_bb_16:
    if ((int)(v >= (double)(1))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_35 = 1;
    return (int)((int)zT_35);
    z_bb_18:
    zT_37 = 0;
    return (int)((int)zT_37);
}

/* formatF64 */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_4CAEBE7E_formatF64(double val, zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int buf_len) {
    zT_C41F1B06_Arr_unsigned_char_6 zT_4;
    double zT_5;
    unsigned char* zT_7;
    int zT_9;
    unsigned char* zT_10;
    int zT_12;
    unsigned int zT_13;
    int zT_16;
    unsigned char zT_17;
    int zT_18;
    int zT_20;
    unsigned int zT_22;
    unsigned int zT_25;
    unsigned int zT_28;
    int zT_29;
    unsigned char* zT_31;
    int zT_33;
    int zT_34;
    unsigned char* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    int zT_38;
    int zT_41;
    unsigned int zT_42;
    int zT_44;
    unsigned int zT_45;
    unsigned char zT_47;
    unsigned char* zT_48;
    int zT_49;
    unsigned int zT_51;
    int zT_52;
    unsigned char zT_53;
    unsigned char* zT_54;
    unsigned char* zT_55;
    int zT_57;
    unsigned char* zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    zT_C41F1B06_Arr_unsigned_char_6 tmp;
    unsigned int n;
    unsigned int cap;
    unsigned int i;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_4[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        tmp[_i] = zT_4[_i];
        _i++;
    }
}
    zT_5 = val;
    zT_9 = 0;
    zT_10 = tmp + zT_9;
    zT_7 = zT_10;
    gcvt(zT_5, (int)(17), zT_7);
    zT_12 = 0;
    zT_13 = (unsigned int)zT_12;
    n = zT_13;
    goto z_bb_1;
    z_bb_1:
    if ((int)(n < (unsigned int)(64))) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    goto z_bb_4;
    z_bb_3:
    cap = buf_len;
    zT_25 = buf.len;
    if ((int)(cap > zT_25)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    zT_20 = 1;
    zT_22 = n + (unsigned int)((unsigned int)zT_20);
    n = zT_22;
    goto z_bb_1;
    z_bb_5:
    zT_17 = tmp[n];
    zT_18 = 0;
    zT_16 = zT_17 != zT_18;
    goto z_bb_7;
    z_bb_6:
    zT_16 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_16) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_28 = buf.len;
    cap = zT_28;
    goto z_bb_9;
    z_bb_9:
    zT_29 = 0;
    if ((int)(cap == (unsigned int)zT_29)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_31 = buf.ptr;
    zT_33 = 0;
    zT_34 = 0;
    zT_35 = zT_31 + zT_34;
    zT_36 = zT_33 - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    return zT_37;
    z_bb_11:
    zT_38 = 1;
    if ((int)(n > (unsigned int)(cap - zT_38))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_41 = 1;
    zT_42 = cap - zT_41;
    n = zT_42;
    goto z_bb_13;
    z_bb_13:
    zT_44 = 0;
    zT_45 = (unsigned int)zT_44;
    i = zT_45;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < n)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_47 = tmp[i];
    zT_48 = buf.ptr;
    zT_48[i] = zT_47;
    goto z_bb_17;
    z_bb_16:
    zT_52 = 0;
    zT_53 = (unsigned char)zT_52;
    zT_54 = buf.ptr;
    zT_54[n] = zT_53;
    zT_55 = buf.ptr;
    zT_57 = 0;
    zT_58 = zT_55 + zT_57;
    zT_59 = n - zT_57;
    zT_60.ptr = zT_58;
    zT_60.len = zT_59;
    return zT_60;
    z_bb_17:
    zT_49 = 1;
    zT_51 = i + (unsigned int)((unsigned int)zT_49);
    i = zT_51;
    goto z_bb_14;
}

/* EOF */
