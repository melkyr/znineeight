#include "lir_opt_pass_3842C861.h"
unsigned int zG_8D933C0A_kCopyPropMaxIter;
unsigned char zG_78C2C6B4_g_nest_active;
unsigned int zG_14E10714_g_nest_max;
unsigned char* zG_30D934F4_g_nest_cand;
unsigned char* zG_7DE170EB_g_nest_depth;
unsigned int* zG_32175378_g_nest_dfbb;
unsigned int* zG_5501C442_g_nest_dfii;
unsigned int* zG_46632058_g_nest_rdbb;
unsigned int* zG_694BFE22_g_nest_rdii;
/* lirOptNestActive */
unsigned char zF_829B1D9D_lirOptNestActive(void) {
    return zG_78C2C6B4_g_nest_active;
}

/* nestInRange */
unsigned char zF_0670982D_nestInRange(unsigned int t) {
    if ((unsigned char)(zG_78C2C6B4_g_nest_active == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(t >= zG_14E10714_g_nest_max)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    return (unsigned char)(1);
}

/* lirOptNestCandidate */
unsigned char zF_0740DD14_lirOptNestCandidate(unsigned int t) {
    unsigned int zT_1;
    unsigned char zT_2 = 0;
    unsigned int zT_7;
    unsigned char zT_8;
    zT_1 = t;
    zT_2 = zF_0670982D_nestInRange(zT_1);
    if ((unsigned char)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = (unsigned int)t;
    zT_8 = zG_30D934F4_g_nest_cand[zT_7];
    return zT_8;
}

/* lirOptNestDepthOf */
unsigned char zF_03D891BD_lirOptNestDepthOf(unsigned int t) {
    unsigned int zT_1;
    unsigned char zT_2 = 0;
    unsigned int zT_7;
    unsigned char zT_8;
    zT_1 = t;
    zT_2 = zF_0670982D_nestInRange(zT_1);
    if ((unsigned char)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = (unsigned int)t;
    zT_8 = zG_7DE170EB_g_nest_depth[zT_7];
    return zT_8;
}

/* lirOptNestDefLoc */
void zF_79BC1D14_lirOptNestDefLoc(unsigned int t, unsigned int* out_bb, unsigned int* out_ii) {
    unsigned int zT_3;
    unsigned char zT_4 = 0;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_3 = t;
    zT_4 = zF_0670982D_nestInRange(zT_3);
    if ((unsigned char)(zT_4 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *out_bb = (unsigned int)(4294967295u);
    *out_ii = (unsigned int)(4294967295u);
    return;
    z_bb_2:
    zT_10 = (unsigned int)t;
    zT_11 = zG_32175378_g_nest_dfbb[zT_10];
    *out_bb = zT_11;
    zT_13 = (unsigned int)t;
    zT_14 = zG_5501C442_g_nest_dfii[zT_13];
    *out_ii = zT_14;
    return;
}

/* lirOptNestConsLoc */
void zF_9CF3FC28_lirOptNestConsLoc(unsigned int t, unsigned int* out_bb, unsigned int* out_ii) {
    unsigned int zT_3;
    unsigned char zT_4 = 0;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_3 = t;
    zT_4 = zF_0670982D_nestInRange(zT_3);
    if ((unsigned char)(zT_4 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *out_bb = (unsigned int)(4294967295u);
    *out_ii = (unsigned int)(4294967295u);
    return;
    z_bb_2:
    zT_10 = (unsigned int)t;
    zT_11 = zG_46632058_g_nest_rdbb[zT_10];
    *out_bb = zT_11;
    zT_13 = (unsigned int)t;
    zT_14 = zG_694BFE22_g_nest_rdii[zT_13];
    *out_ii = zT_14;
    return;
}

/* lowMask */
zT_79FAE712_u64 zF_5E3CE23D_lowMask(unsigned int w) {
    if ((unsigned char)(w >= (unsigned int)(64))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_79FAE712_u64)(18446744073709551615ULL);
    z_bb_2:
    return (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)w)) - (zT_79FAE712_u64)(1));
}

/* sigBit */
zT_79FAE712_u64 zF_3794934D_sigBit(unsigned int w) {
    return (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(w - (unsigned int)(1))));
}

/* intKindWidth */
unsigned int zF_90DDF69C_intKindWidth(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_5;
    unsigned char zT_15;
    unsigned char zT_25;
    unsigned char zT_30;
    unsigned char zT_35;
    unsigned char zT_45;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(8);
    z_bb_5:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_15 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    goto z_bb_8;
    z_bb_7:
    zT_15 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_15) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(16);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_25 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    goto z_bb_13;
    z_bb_12:
    zT_25 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_25) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_30 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_16;
    z_bb_15:
    zT_30 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_30) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_35 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    goto z_bb_19;
    z_bb_18:
    zT_35 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_35) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned int)(32);
    z_bb_21:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_45 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_24;
    z_bb_23:
    zT_45 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_45) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned int)(64);
    z_bb_26:
    return (unsigned int)(0);
}

/* intKindSigned */
unsigned char zF_D4EA92B8_intKindSigned(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_5;
    unsigned char zT_10;
    unsigned char zT_15;
    unsigned char zT_20;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_10 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    goto z_bb_6;
    z_bb_5:
    zT_10 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_10) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_15 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    goto z_bb_9;
    z_bb_8:
    zT_15 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_15) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    goto z_bb_12;
    z_bb_11:
    zT_20 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_20) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    return (unsigned char)(0);
}

/* copyScalarKindOk */
unsigned char zF_B7E1584C_copyScalarKindOk(zT_33EF6BFB_TypeKind kind) {
    int zT_5;
    int zT_11;
    int zT_17;
    int zT_23;
    int zT_29;
    int zT_35;
    int zT_41;
    int zT_47;
    int zT_53;
    int zT_59;
    int zT_65;
    int zT_71;
    int zT_77;
    int zT_83;
    int zT_89;
    int zT_95;
    int zT_101;
    int zT_107;
    int zT_113;
    int zT_119;
    int zT_125;
    int zT_131;
    int zT_133;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    return (unsigned char)((unsigned char)zT_5);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = 1;
    return (unsigned char)((unsigned char)zT_11);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 1;
    return (unsigned char)((unsigned char)zT_17);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_23 = 1;
    return (unsigned char)((unsigned char)zT_23);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_29 = 1;
    return (unsigned char)((unsigned char)zT_29);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_35 = 1;
    return (unsigned char)((unsigned char)zT_35);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_41 = 1;
    return (unsigned char)((unsigned char)zT_41);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_47 = 1;
    return (unsigned char)((unsigned char)zT_47);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_53 = 1;
    return (unsigned char)((unsigned char)zT_53);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_59 = 1;
    return (unsigned char)((unsigned char)zT_59);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_65 = 1;
    return (unsigned char)((unsigned char)zT_65);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_71 = 1;
    return (unsigned char)((unsigned char)zT_71);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_77 = 1;
    return (unsigned char)((unsigned char)zT_77);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_83 = 1;
    return (unsigned char)((unsigned char)zT_83);
    z_bb_28:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_89 = 1;
    return (unsigned char)((unsigned char)zT_89);
    z_bb_30:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_95 = 1;
    return (unsigned char)((unsigned char)zT_95);
    z_bb_32:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_101 = 1;
    return (unsigned char)((unsigned char)zT_101);
    z_bb_34:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_107 = 1;
    return (unsigned char)((unsigned char)zT_107);
    z_bb_36:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_113 = 1;
    return (unsigned char)((unsigned char)zT_113);
    z_bb_38:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_119 = 1;
    return (unsigned char)((unsigned char)zT_119);
    z_bb_40:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_125 = 1;
    return (unsigned char)((unsigned char)zT_125);
    z_bb_42:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_131 = 1;
    return (unsigned char)((unsigned char)zT_131);
    z_bb_44:
    zT_133 = 0;
    return (unsigned char)((unsigned char)zT_133);
}

/* allocU32 */
unsigned int* zF_43BEEDA4_allocU32_1(zT_5EDE903E_Ctx* c, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    zT_C6536882_EU_532 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned char* raw;
    zT_3 = c->alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)((unsigned int)((unsigned int)n) * (unsigned int)(4)), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    return (unsigned int*)((unsigned int*)raw);
}

/* allocU64 */
zT_79FAE712_u64* zF_3FCBB34B_allocU64(zT_5EDE903E_Ctx* c, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    zT_C6536882_EU_532 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned char* raw;
    zT_3 = c->alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)((unsigned int)((unsigned int)n) * (unsigned int)(8)), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    return (zT_79FAE712_u64*)((zT_79FAE712_u64*)raw);
}

/* allocU8 */
unsigned char* zF_76A96453_allocU8(zT_5EDE903E_Ctx* c, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    zT_C6536882_EU_532 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned char* raw;
    zT_3 = c->alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)((unsigned int)((unsigned int)n) * (unsigned int)(1)), (unsigned int)(1));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    return (unsigned char*)((unsigned char*)raw);
}

/* maxTempOf */
unsigned int zF_005F8966_maxTempOf_1(zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_2;
    unsigned int zT_4;
    zT_5D72FBF8_TempDeclArrayList zT_5;
    unsigned int zT_6;
    zT_5D72FBF8_TempDeclArrayList zT_9;
    zT_1937645B_TempDecl* zT_10;
    zT_1937645B_TempDecl zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int m;
    unsigned int i;
    zT_1937645B_TempDecl td;
    zT_2 = 0;
    m = zT_2;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = lir_fn->hoisted_temps;
    zT_6 = zT_5.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = lir_fn->hoisted_temps;
    zT_10 = zT_9.items;
    zT_11 = zT_10[i];
    td = zT_11;
    zT_12 = td.temp_id;
    if ((unsigned char)(zT_12 >= m)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return m;
    z_bb_4:
    zT_18 = i + (unsigned int)(1);
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = td.temp_id;
    zT_16 = zT_14 + (unsigned int)(1);
    m = zT_16;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* resetScratch */
void zF_D6CE151A_resetScratch(zT_5EDE903E_Ctx* c) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int* zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned char zT_29;
    unsigned char* zT_30;
    unsigned int zT_31;
    zT_79FAE712_u64 zT_32;
    zT_79FAE712_u64* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int* zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int* zT_54;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned int t;
    zT_2 = 0;
    t = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_3 = c->max_temp;
    if ((unsigned char)(t < zT_3)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    zT_6 = c->rc;
    zT_7 = (unsigned int)t;
    zT_6[zT_7] = zT_5;
    zT_8 = 0;
    zT_9 = c->wc;
    zT_10 = (unsigned int)t;
    zT_9[zT_10] = zT_8;
    zT_11 = 0;
    zT_12 = c->at;
    zT_13 = (unsigned int)t;
    zT_12[zT_13] = zT_11;
    zT_14 = 0;
    zT_15 = c->ex;
    zT_16 = (unsigned int)t;
    zT_15[zT_16] = zT_14;
    zT_17 = 0;
    zT_18 = c->dp;
    zT_19 = (unsigned int)t;
    zT_18[zT_19] = zT_17;
    zT_20 = 0;
    zT_21 = c->rd_bb;
    zT_22 = (unsigned int)t;
    zT_21[zT_22] = zT_20;
    zT_23 = 0;
    zT_24 = c->rd_ii;
    zT_25 = (unsigned int)t;
    zT_24[zT_25] = zT_23;
    zT_26 = 0;
    zT_27 = c->rar;
    zT_28 = (unsigned int)t;
    zT_27[zT_28] = zT_26;
    zT_29 = 0;
    zT_30 = c->cf;
    zT_31 = (unsigned int)t;
    zT_30[zT_31] = zT_29;
    zT_32 = 0;
    zT_33 = c->cv;
    zT_34 = (unsigned int)t;
    zT_33[zT_34] = zT_32;
    zT_35 = 4294967295u;
    zT_36 = c->ren;
    zT_37 = (unsigned int)t;
    zT_36[zT_37] = zT_35;
    zT_38 = 0;
    zT_39 = c->cand;
    zT_40 = (unsigned int)t;
    zT_39[zT_40] = zT_38;
    zT_41 = 0;
    zT_42 = c->depth;
    zT_43 = (unsigned int)t;
    zT_42[zT_43] = zT_41;
    zT_44 = 0;
    zT_45 = c->ga;
    zT_46 = (unsigned int)t;
    zT_45[zT_46] = zT_44;
    zT_47 = 0;
    zT_48 = c->gam;
    zT_49 = (unsigned int)t;
    zT_48[zT_49] = zT_47;
    zT_50 = 4294967295u;
    zT_51 = c->df_bb;
    zT_52 = (unsigned int)t;
    zT_51[zT_52] = zT_50;
    zT_53 = 4294967295u;
    zT_54 = c->df_ii;
    zT_55 = (unsigned int)t;
    zT_54[zT_55] = zT_53;
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_57 = t + (unsigned int)(1);
    t = zT_57;
    goto z_bb_1;
}

/* markRead */
void zF_20F1A7B4_markRead(zT_5EDE903E_Ctx* c, unsigned int t, unsigned int bb_idx, unsigned int ii) {
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_13;
    unsigned int* zT_14;
    unsigned int zT_15;
    unsigned int* zT_18;
    unsigned int* zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int* zT_24;
    unsigned int p;
    unsigned int pos;
    zT_4 = c->max_temp;
    if ((unsigned char)(t >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = c->t2p;
    zT_8 = (unsigned int)t;
    zT_9 = zT_7[zT_8];
    p = zT_9;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_13 = (unsigned int)p;
    pos = zT_13;
    zT_14 = c->rc;
    zT_15 = zT_14[pos];
    if ((unsigned char)(zT_15 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_18 = c->rd_bb;
    zT_18[pos] = bb_idx;
    zT_19 = c->rd_ii;
    zT_19[pos] = ii;
    goto z_bb_6;
    z_bb_6:
    zT_20 = c->rc;
    zT_21 = zT_20[pos];
    zT_23 = zT_21 + (unsigned int)(1);
    zT_24 = c->rc;
    zT_24[pos] = zT_23;
    return;
}

/* markArgRead */
void zF_8ABC4310_markArgRead(zT_5EDE903E_Ctx* c, unsigned int t, unsigned int bb_idx, unsigned int ii) {
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int* zT_20;
    unsigned int* zT_21;
    unsigned int* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int* zT_26;
    unsigned int p;
    unsigned int pos;
    zT_4 = c->max_temp;
    if ((unsigned char)(t >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = c->t2p;
    zT_8 = (unsigned int)t;
    zT_9 = zT_7[zT_8];
    p = zT_9;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_13 = (unsigned int)p;
    pos = zT_13;
    zT_14 = 1;
    zT_15 = c->rar;
    zT_15[pos] = zT_14;
    zT_16 = c->rc;
    zT_17 = zT_16[pos];
    if ((unsigned char)(zT_17 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = c->rd_bb;
    zT_20[pos] = bb_idx;
    zT_21 = c->rd_ii;
    zT_21[pos] = ii;
    goto z_bb_6;
    z_bb_6:
    zT_22 = c->rc;
    zT_23 = zT_22[pos];
    zT_25 = zT_23 + (unsigned int)(1);
    zT_26 = c->rc;
    zT_26[pos] = zT_25;
    return;
}

/* markAddrTaken */
void zF_0A9E889A_markAddrTaken(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int p;
    zT_2 = c->max_temp;
    if ((unsigned char)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = c->t2p;
    zT_6 = (unsigned int)t;
    zT_7 = zT_5[zT_6];
    p = zT_7;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_10 = 1;
    zT_11 = c->at;
    zT_12 = (unsigned int)p;
    zT_11[zT_12] = zT_10;
    return;
}

/* markExcluded */
void zF_2CDB40DA_markExcluded(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int p;
    zT_2 = c->max_temp;
    if ((unsigned char)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = c->t2p;
    zT_6 = (unsigned int)t;
    zT_7 = zT_5[zT_6];
    p = zT_7;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_10 = 1;
    zT_11 = c->ex;
    zT_12 = (unsigned int)p;
    zT_11[zT_12] = zT_10;
    return;
}

/* markGaSource */
void zF_323EFAF9_markGaSource(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int p;
    zT_2 = c->max_temp;
    if ((unsigned char)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = c->t2p;
    zT_6 = (unsigned int)t;
    zT_7 = zT_5[zT_6];
    p = zT_7;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_10 = 1;
    zT_11 = c->ga;
    zT_12 = (unsigned int)p;
    zT_11[zT_12] = zT_10;
    return;
}

/* recordConst */
void zF_83868A0F_recordConst(zT_5EDE903E_Ctx* c, unsigned int t, zT_79FAE712_u64 v) {
    unsigned int zT_3;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_79FAE712_u64* zT_14;
    unsigned int zT_15;
    unsigned int p;
    zT_3 = c->max_temp;
    if ((unsigned char)(t >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)t;
    zT_8 = zT_6[zT_7];
    p = zT_8;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_11 = 1;
    zT_12 = c->cf;
    zT_13 = (unsigned int)p;
    zT_12[zT_13] = zT_11;
    zT_14 = c->cv;
    zT_15 = (unsigned int)p;
    zT_14[zT_15] = v;
    return;
}

/* markDef */
void zF_AAEF59B7_markDef(zT_5EDE903E_Ctx* c, unsigned int t, unsigned char is_pure) {
    unsigned int zT_3;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned int p;
    zT_3 = c->max_temp;
    if ((unsigned char)(t >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)t;
    zT_8 = zT_6[zT_7];
    p = zT_8;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_11 = c->wc;
    zT_12 = (unsigned int)p;
    zT_13 = zT_11[zT_12];
    zT_15 = zT_13 + (unsigned int)(1);
    zT_16 = c->wc;
    zT_17 = (unsigned int)p;
    zT_16[zT_17] = zT_15;
    if ((unsigned char)(is_pure != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 1;
    zT_21 = c->dp;
    zT_22 = (unsigned int)p;
    zT_21[zT_22] = zT_20;
    goto z_bb_6;
    z_bb_6:
    return;
}

/* defInfoPure */
unsigned char zF_A5E11466_defInfoPure(zT_6BA597BC_LirInst inst) {
    unsigned int zT_1;
    zT_1 = inst.tag;
switch (zT_1) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 49: goto z_bb_5;
case 47: goto z_bb_6;
case 46: goto z_bb_7;
case 50: goto z_bb_8;
case 51: goto z_bb_9;
case 48: goto z_bb_10;
case 38: goto z_bb_11;
case 80: goto z_bb_12;
case 81: goto z_bb_13;
case 39: goto z_bb_14;
case 40: goto z_bb_15;
case 41: goto z_bb_16;
case 43: goto z_bb_17;
case 42: goto z_bb_18;
case 37: goto z_bb_19;
case 20: goto z_bb_20;
case 21: goto z_bb_21;
case 28: goto z_bb_22;
case 22: goto z_bb_23;
case 32: goto z_bb_24;
case 33: goto z_bb_25;
case 29: goto z_bb_26;
case 78: goto z_bb_27;
case 30: goto z_bb_28;
case 31: goto z_bb_29;
case 34: goto z_bb_30;
case 35: goto z_bb_31;
case 36: goto z_bb_32;
case 18: goto z_bb_33;
case 15: goto z_bb_34;
case 68: goto z_bb_35;
case 17: goto z_bb_36;
case 52: goto z_bb_37;
case 54: goto z_bb_38;
case 72: goto z_bb_39;
case 73: goto z_bb_40;
case 74: goto z_bb_41;
case 75: goto z_bb_42;
case 76: goto z_bb_43;
case 77: goto z_bb_44;
default: goto z_bb_45;
}
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    return (unsigned char)(1);
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    return (unsigned char)(1);
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    return (unsigned char)(1);
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    return (unsigned char)(1);
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    return (unsigned char)(1);
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    return (unsigned char)(1);
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    return (unsigned char)(1);
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    return (unsigned char)(1);
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    return (unsigned char)(1);
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    return (unsigned char)(1);
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    return (unsigned char)(1);
    z_bb_29:
    return (unsigned char)(1);
    z_bb_30:
    return (unsigned char)(1);
    z_bb_31:
    return (unsigned char)(1);
    z_bb_32:
    return (unsigned char)(1);
    z_bb_33:
    return (unsigned char)(1);
    z_bb_34:
    return (unsigned char)(1);
    z_bb_35:
    return (unsigned char)(1);
    z_bb_36:
    return (unsigned char)(1);
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    return (unsigned char)(1);
    z_bb_39:
    return (unsigned char)(1);
    z_bb_40:
    return (unsigned char)(1);
    z_bb_41:
    return (unsigned char)(1);
    z_bb_42:
    return (unsigned char)(1);
    z_bb_43:
    return (unsigned char)(1);
    z_bb_44:
    return (unsigned char)(1);
    z_bb_45:
    return (unsigned char)(0);
    return 0;
}

/* defResultTemp */
unsigned int zF_CFED20F7_defResultTemp_1(zT_6BA597BC_LirInst inst, zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_2;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_66;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_72;
    unsigned int zT_74;
    unsigned int zT_76;
    unsigned int zT_78;
    unsigned int zT_80;
    unsigned int zT_82;
    unsigned int zT_84;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_BBC23664_LirFunction* zT_91;
    unsigned int zT_92;
    zT_3BFB1E70_CallDirectData zT_93 = {0};
    unsigned int zT_94;
    zT_BBC23664_LirFunction* zT_97;
    unsigned int zT_98;
    zT_0624AC1B_TailCallData zT_99 = {0};
    unsigned int zT_100;
    unsigned int zT_102;
    unsigned int zT_104;
    unsigned int zT_106;
    unsigned int zT_108;
    unsigned int zT_110;
    unsigned int zT_112;
    unsigned int zT_114;
    unsigned int zT_116;
    zT_176BF348_anon_77099 b;
    zT_11ECC358_anon_77107 u;
    zT_A7CB4D30_anon_77327 ic;
    zT_ABC914E5_anon_77333 fc;
    zT_B1C91E57_anon_77339 sc;
    zT_A3C6C9B6_anon_77343 nc;
    zT_A9C6D328_anon_77349 sn;
    zT_39C3E441_anon_77355 bc;
    zT_35C19F5E_anon_77361 uc;
    zT_D4AE0C19_anon_77579 pi;
    zT_31BF5A7B_anon_77371 ec;
    zT_4F25184D_anon_77283 ic_1;
    zT_CC8B6D3F_anon_77595 ic_2;
    zT_879E24B5_anon_77607 ww;
    zT_51275A0A_anon_77291 fc_3;
    zT_49274D72_anon_77299 pc;
    zT_37D0AD0E_anon_77307 itf;
    zT_ADCB56A2_anon_77321 itp;
    zT_B3CD9EAB_anon_77313 pti;
    zT_39363ECC_anon_77275 ms;
    zT_11E8462A_anon_77167 a;
    zT_03E5F189_anon_77175 a_4;
    zT_BF3B8EEC_anon_77213 fr;
    zT_860101AC_anon_77183 w;
    zT_C540158C_anon_77239 w_5;
    zT_CB2ED5DD_anon_77247 w_6;
    zT_C93B9EAA_anon_77219 u_7;
    zT_E0AE1EFD_anon_77575 u_8;
    zT_CD3DE38D_anon_77225 u_9;
    zT_CD402224_anon_77231 ch;
    zT_4731D7A8_anon_77253 u_10;
    zT_4131CE36_anon_77259 u_11;
    zT_4D341FB1_anon_77265 ch_12;
    zT_7FE0A48F_anon_77155 l;
    zT_81F1F0D6_anon_77127 lf;
    zT_E0BE7755_anon_77467 lb;
    zT_87E2EFBE_anon_77149 li;
    zT_37BF63ED_anon_77377 ll;
    zT_A5BA00E9_anon_77391 lg;
    zT_935FEA89_anon_77041 a_13;
    zT_97622F6C_anon_77051 a_14;
    zT_275AC357_anon_77061 a_15;
    zT_11EA84C1_anon_77117 cl;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    unsigned int slot_16;
    zT_0624AC1B_TailCallData tc;
    zT_8BFECC87_anon_77199 va;
    zT_76CA9C6A_anon_77431 bgc;
    zT_EAE357EC_anon_77499 o;
    zT_DA9F0B01_anon_77513 o_17;
    zT_4EA67D62_anon_77527 o_18;
    zT_D4ABCD82_anon_77541 o_19;
    zT_52A8C245_anon_77553 o_20;
    zT_D8B050FC_anon_77569 o_21;
    zT_2 = inst.tag;
switch (zT_2) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 46: goto z_bb_5;
case 47: goto z_bb_6;
case 48: goto z_bb_7;
case 49: goto z_bb_8;
case 50: goto z_bb_9;
case 79: goto z_bb_10;
case 51: goto z_bb_11;
case 38: goto z_bb_12;
case 80: goto z_bb_13;
case 81: goto z_bb_14;
case 39: goto z_bb_15;
case 40: goto z_bb_16;
case 41: goto z_bb_17;
case 43: goto z_bb_18;
case 42: goto z_bb_19;
case 37: goto z_bb_20;
case 20: goto z_bb_21;
case 21: goto z_bb_22;
case 28: goto z_bb_23;
case 22: goto z_bb_24;
case 32: goto z_bb_25;
case 33: goto z_bb_26;
case 29: goto z_bb_27;
case 78: goto z_bb_28;
case 30: goto z_bb_29;
case 31: goto z_bb_30;
case 34: goto z_bb_31;
case 35: goto z_bb_32;
case 36: goto z_bb_33;
case 18: goto z_bb_34;
case 15: goto z_bb_35;
case 68: goto z_bb_36;
case 17: goto z_bb_37;
case 52: goto z_bb_38;
case 54: goto z_bb_39;
case 2: goto z_bb_40;
case 3: goto z_bb_41;
case 4: goto z_bb_42;
case 14: goto z_bb_43;
case 23: goto z_bb_44;
case 27: goto z_bb_45;
case 25: goto z_bb_46;
case 61: goto z_bb_47;
case 72: goto z_bb_48;
case 73: goto z_bb_49;
case 74: goto z_bb_50;
case 75: goto z_bb_51;
case 76: goto z_bb_52;
case 77: goto z_bb_53;
default: goto z_bb_54;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_4 = b.result;
    return zT_4;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_6 = u.result;
    return zT_6;
    z_bb_3:
    ic = inst.payload.int_const._0;
    zT_8 = ic.result;
    return zT_8;
    z_bb_4:
    fc = inst.payload.float_const._0;
    zT_10 = fc.result;
    return zT_10;
    z_bb_5:
    sc = inst.payload.string_const._0;
    zT_12 = sc.result;
    return zT_12;
    z_bb_6:
    nc = inst.payload.null_const._0;
    zT_14 = nc.result;
    return zT_14;
    z_bb_7:
    sn = inst.payload.set_optional_null._0;
    zT_16 = sn.result;
    return zT_16;
    z_bb_8:
    bc = inst.payload.bool_const._0;
    zT_18 = bc.result;
    return zT_18;
    z_bb_9:
    uc = inst.payload.undefined_const._0;
    zT_20 = uc.result;
    return zT_20;
    z_bb_10:
    pi = inst.payload.poison_init._0;
    zT_22 = pi.result;
    return zT_22;
    z_bb_11:
    ec = inst.payload.enum_const._0;
    zT_24 = ec.result;
    return zT_24;
    z_bb_12:
    ic_1 = inst.payload.int_cast._0;
    zT_26 = ic_1.result;
    return zT_26;
    z_bb_13:
    ic_2 = inst.payload.int_cast_checked._0;
    zT_28 = ic_2.result;
    return zT_28;
    z_bb_14:
    ww = inst.payload.width_wrap._0;
    zT_30 = ww.result;
    return zT_30;
    z_bb_15:
    fc_3 = inst.payload.float_cast._0;
    zT_32 = fc_3.result;
    return zT_32;
    z_bb_16:
    pc = inst.payload.ptr_cast._0;
    zT_34 = pc.result;
    return zT_34;
    z_bb_17:
    itf = inst.payload.int_to_float._0;
    zT_36 = itf.result;
    return zT_36;
    z_bb_18:
    itp = inst.payload.int_to_ptr._0;
    zT_38 = itp.result;
    return zT_38;
    z_bb_19:
    pti = inst.payload.ptr_to_int._0;
    zT_40 = pti.result;
    return zT_40;
    z_bb_20:
    ms = inst.payload.make_slice._0;
    zT_42 = ms.result;
    return zT_42;
    z_bb_21:
    a = inst.payload.addr_of._0;
    zT_44 = a.result;
    return zT_44;
    z_bb_22:
    a_4 = inst.payload.addr_of_field._0;
    zT_46 = a_4.result;
    return zT_46;
    z_bb_23:
    fr = inst.payload.func_ref._0;
    zT_48 = fr.result;
    return zT_48;
    z_bb_24:
    w = inst.payload.wrap_optional._0;
    zT_50 = w.result;
    return zT_50;
    z_bb_25:
    w_5 = inst.payload.wrap_error_ok._0;
    zT_52 = w_5.result;
    return zT_52;
    z_bb_26:
    w_6 = inst.payload.wrap_error_err._0;
    zT_54 = w_6.result;
    return zT_54;
    z_bb_27:
    u_7 = inst.payload.unwrap_optional._0;
    zT_56 = u_7.result;
    return zT_56;
    z_bb_28:
    u_8 = inst.payload.unwrap_optional_checked._0;
    zT_58 = u_8.result;
    return zT_58;
    z_bb_29:
    u_9 = inst.payload.unwrap_optional_abi._0;
    zT_60 = u_9.result;
    return zT_60;
    z_bb_30:
    ch = inst.payload.check_optional._0;
    zT_62 = ch.result;
    return zT_62;
    z_bb_31:
    u_10 = inst.payload.unwrap_error_payload._0;
    zT_64 = u_10.result;
    return zT_64;
    z_bb_32:
    u_11 = inst.payload.unwrap_error_code._0;
    zT_66 = u_11.result;
    return zT_66;
    z_bb_33:
    ch_12 = inst.payload.check_error._0;
    zT_68 = ch_12.result;
    return zT_68;
    z_bb_34:
    l = inst.payload.load._0;
    zT_70 = l.result;
    return zT_70;
    z_bb_35:
    lf = inst.payload.load_field._0;
    zT_72 = lf.result;
    return zT_72;
    z_bb_36:
    lb = inst.payload.load_bitfield._0;
    zT_74 = lb.result;
    return zT_74;
    z_bb_37:
    li = inst.payload.load_index._0;
    zT_76 = li.result;
    return zT_76;
    z_bb_38:
    ll = inst.payload.load_local._0;
    zT_78 = ll.result;
    return zT_78;
    z_bb_39:
    lg = inst.payload.load_global._0;
    zT_80 = lg.result;
    return zT_80;
    z_bb_40:
    a_13 = inst.payload.assign._0;
    zT_82 = a_13.dst;
    return zT_82;
    z_bb_41:
    a_14 = inst.payload.assign_field._0;
    zT_84 = a_14.base;
    return zT_84;
    z_bb_42:
    a_15 = inst.payload.assign_index._0;
    zT_86 = a_15.base;
    return zT_86;
    z_bb_43:
    cl = inst.payload.call._0;
    zT_88 = cl.result;
    return zT_88;
    z_bb_44:
    slot = inst.payload.jump._0;
    zT_91 = lir_fn;
    zT_92 = slot;
    zT_93 = zF_75DE985C_lirSideGetCallDirec(zT_91, zT_92);
    cd = zT_93;
    zT_94 = cd.result;
    return zT_94;
    z_bb_45:
    slot_16 = inst.payload.jump._0;
    zT_97 = lir_fn;
    zT_98 = slot_16;
    zT_99 = zF_1AB3807F_lirSideGetTailCall(zT_97, zT_98);
    tc = zT_99;
    zT_100 = tc.result;
    return zT_100;
    z_bb_46:
    va = inst.payload.va_arg._0;
    zT_102 = va.result;
    return zT_102;
    z_bb_47:
    bgc = inst.payload.builtin_get_char._0;
    zT_104 = bgc.result;
    return zT_104;
    z_bb_48:
    o = inst.payload.add_with_overflow._0;
    zT_106 = o.result;
    return zT_106;
    z_bb_49:
    o_17 = inst.payload.sub_with_overflow._0;
    zT_108 = o_17.result;
    return zT_108;
    z_bb_50:
    o_18 = inst.payload.mul_with_overflow._0;
    zT_110 = o_18.result;
    return zT_110;
    z_bb_51:
    o_19 = inst.payload.shl_with_overflow._0;
    zT_112 = o_19.result;
    return zT_112;
    z_bb_52:
    o_20 = inst.payload.neg_with_overflow._0;
    zT_114 = o_20.result;
    return zT_114;
    z_bb_53:
    o_21 = inst.payload.overflow_flag._0;
    zT_116 = o_21.result;
    return zT_116;
    z_bb_54:
    return (unsigned int)(4294967295u);
    return 0;
}

/* scanInst */
void zF_85F6BDD8_scanInst(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst, unsigned int bb_idx, unsigned int ii) {
    zT_6BA597BC_LirInst zT_5;
    zT_BBC23664_LirFunction* zT_6;
    unsigned int zT_8 = 0;
    unsigned int zT_11;
    unsigned int* zT_13;
    unsigned int zT_14;
    unsigned int* zT_15;
    unsigned int zT_16;
    zT_5EDE903E_Ctx* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    zT_6BA597BC_LirInst zT_20;
    unsigned char zT_21 = 0;
    unsigned int zT_22;
    zT_5EDE903E_Ctx* zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_29;
    zT_5EDE903E_Ctx* zT_32;
    unsigned int zT_33;
    zT_5EDE903E_Ctx* zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_5EDE903E_Ctx* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_5EDE903E_Ctx* zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_5EDE903E_Ctx* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_5EDE903E_Ctx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    zT_5EDE903E_Ctx* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_5EDE903E_Ctx* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_5EDE903E_Ctx* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    zT_5EDE903E_Ctx* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_5EDE903E_Ctx* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    zT_5EDE903E_Ctx* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    zT_5EDE903E_Ctx* zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    zT_5EDE903E_Ctx* zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_5EDE903E_Ctx* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_5EDE903E_Ctx* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    zT_5EDE903E_Ctx* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    zT_5EDE903E_Ctx* zT_124;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_5EDE903E_Ctx* zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    zT_5EDE903E_Ctx* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    zT_5EDE903E_Ctx* zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    zT_5EDE903E_Ctx* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_5EDE903E_Ctx* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    zT_5EDE903E_Ctx* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_164;
    unsigned int zT_165;
    zT_5EDE903E_Ctx* zT_167;
    unsigned int zT_169;
    unsigned int zT_170;
    unsigned int zT_171;
    unsigned int zT_174;
    zT_5EDE903E_Ctx* zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    zT_5EDE903E_Ctx* zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    zT_5EDE903E_Ctx* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_5EDE903E_Ctx* zT_193;
    unsigned int zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    zT_5EDE903E_Ctx* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    zT_5EDE903E_Ctx* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    zT_5EDE903E_Ctx* zT_210;
    unsigned int zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    zT_5EDE903E_Ctx* zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    zT_5EDE903E_Ctx* zT_221;
    unsigned int zT_222;
    unsigned int zT_223;
    unsigned int zT_224;
    zT_5EDE903E_Ctx* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_230;
    zT_5EDE903E_Ctx* zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    zT_5EDE903E_Ctx* zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_5EDE903E_Ctx* zT_243;
    unsigned int zT_244;
    zT_5EDE903E_Ctx* zT_247;
    unsigned int zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    zT_5EDE903E_Ctx* zT_252;
    unsigned int zT_253;
    zT_5EDE903E_Ctx* zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_259;
    zT_BBC23664_LirFunction* zT_263;
    unsigned int zT_264;
    zT_3BFB1E70_CallDirectData zT_266 = {0};
    unsigned int zT_268;
    unsigned int zT_269;
    zT_5EDE903E_Ctx* zT_271;
    unsigned int zT_273;
    unsigned int zT_274;
    unsigned int zT_275;
    unsigned int zT_278;
    zT_5EDE903E_Ctx* zT_280;
    unsigned int zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    zT_5EDE903E_Ctx* zT_285;
    unsigned int zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    zT_5EDE903E_Ctx* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    zT_5EDE903E_Ctx* zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    unsigned int zT_300;
    zT_BBC23664_LirFunction* zT_304;
    unsigned int zT_305;
    zT_0624AC1B_TailCallData zT_307 = {0};
    unsigned char zT_308;
    zT_5EDE903E_Ctx* zT_311;
    unsigned int zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    unsigned int zT_317;
    unsigned int zT_318;
    zT_5EDE903E_Ctx* zT_320;
    unsigned int zT_322;
    unsigned int zT_323;
    unsigned int zT_324;
    unsigned int zT_327;
    zT_5EDE903E_Ctx* zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    zT_5EDE903E_Ctx* zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    zT_5EDE903E_Ctx* zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    unsigned int zT_344;
    zT_5EDE903E_Ctx* zT_347;
    unsigned int zT_348;
    unsigned int zT_349;
    unsigned int zT_350;
    zT_5EDE903E_Ctx* zT_353;
    unsigned int zT_354;
    unsigned int zT_355;
    unsigned int zT_356;
    zT_5EDE903E_Ctx* zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    zT_5EDE903E_Ctx* zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned int zT_368;
    zT_5EDE903E_Ctx* zT_371;
    unsigned int zT_372;
    unsigned int zT_373;
    unsigned int zT_374;
    zT_5EDE903E_Ctx* zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    unsigned int zT_380;
    zT_5EDE903E_Ctx* zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned int zT_386;
    zT_5EDE903E_Ctx* zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    zT_5EDE903E_Ctx* zT_394;
    unsigned int zT_395;
    unsigned int zT_396;
    unsigned int zT_397;
    zT_5EDE903E_Ctx* zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    unsigned int zT_403;
    zT_5EDE903E_Ctx* zT_406;
    unsigned int zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    zT_5EDE903E_Ctx* zT_412;
    unsigned int zT_413;
    unsigned int zT_414;
    unsigned int zT_415;
    zT_5EDE903E_Ctx* zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    zT_5EDE903E_Ctx* zT_424;
    unsigned int zT_425;
    unsigned int zT_426;
    unsigned int zT_427;
    zT_5EDE903E_Ctx* zT_430;
    unsigned int zT_431;
    unsigned int zT_432;
    unsigned int zT_433;
    zT_5EDE903E_Ctx* zT_436;
    unsigned int zT_437;
    unsigned int zT_438;
    unsigned int zT_439;
    zT_5EDE903E_Ctx* zT_442;
    unsigned int zT_443;
    unsigned int zT_444;
    unsigned int zT_445;
    zT_5EDE903E_Ctx* zT_448;
    unsigned int zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    zT_5EDE903E_Ctx* zT_454;
    unsigned int zT_455;
    unsigned int zT_456;
    unsigned int zT_457;
    zT_5EDE903E_Ctx* zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    unsigned int zT_463;
    zT_5EDE903E_Ctx* zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    unsigned int zT_469;
    zT_5EDE903E_Ctx* zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    zT_5EDE903E_Ctx* zT_477;
    unsigned int zT_478;
    unsigned int zT_479;
    unsigned int zT_480;
    zT_5EDE903E_Ctx* zT_482;
    unsigned int zT_483;
    unsigned int zT_484;
    unsigned int zT_485;
    zT_5EDE903E_Ctx* zT_488;
    unsigned int zT_489;
    unsigned int zT_490;
    unsigned int zT_491;
    zT_5EDE903E_Ctx* zT_494;
    unsigned int zT_495;
    unsigned int zT_496;
    unsigned int zT_497;
    zT_5EDE903E_Ctx* zT_500;
    unsigned int zT_501;
    unsigned int zT_502;
    unsigned int zT_503;
    zT_5EDE903E_Ctx* zT_505;
    unsigned int zT_506;
    unsigned int zT_507;
    unsigned int zT_508;
    zT_5EDE903E_Ctx* zT_511;
    unsigned int zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    zT_5EDE903E_Ctx* zT_516;
    unsigned int zT_517;
    unsigned int zT_518;
    unsigned int zT_519;
    zT_5EDE903E_Ctx* zT_522;
    unsigned int zT_523;
    zT_5EDE903E_Ctx* zT_525;
    unsigned int zT_526;
    zT_5EDE903E_Ctx* zT_529;
    unsigned int zT_530;
    zT_5EDE903E_Ctx* zT_533;
    unsigned int zT_534;
    zT_79FAE712_u64 zT_535;
    zT_5EDE903E_Ctx* zT_539;
    unsigned int zT_540;
    unsigned char zT_543;
    zT_5EDE903E_Ctx* zT_546;
    unsigned int zT_547;
    unsigned int zT_548;
    unsigned int zT_549;
    unsigned int rp;
    zT_935FEA89_anon_77041 a;
    zT_97622F6C_anon_77051 a_1;
    zT_275AC357_anon_77061 a_2;
    zT_2B5D083A_anon_77071 b;
    zT_2B69D42D_anon_77081 s;
    unsigned int v;
    zT_176BF348_anon_77099 b_3;
    zT_11ECC358_anon_77107 u;
    zT_EAE357EC_anon_77499 o;
    zT_DA9F0B01_anon_77513 o_4;
    zT_4EA67D62_anon_77527 o_5;
    zT_D4ABCD82_anon_77541 o_6;
    zT_52A8C245_anon_77553 o_7;
    zT_D8B050FC_anon_77569 o_8;
    zT_11EA84C1_anon_77117 cl;
    unsigned int ai;
    zT_81F1F0D6_anon_77127 lf;
    zT_E0BE7755_anon_77467 lb;
    zT_81EFB23F_anon_77137 sf;
    zT_E0C0B5EC_anon_77477 sb;
    zT_87E2EFBE_anon_77149 li;
    zT_7FE0A48F_anon_77155 l;
    zT_0BE83CB8_anon_77161 st;
    zT_11E8462A_anon_77167 a_9;
    zT_03E5F189_anon_77175 a_10;
    zT_860101AC_anon_77183 w;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_83FEBFEF_anon_77191 vs;
    zT_8BFECC87_anon_77199 va;
    zT_BF395055_anon_77203 ve;
    unsigned int slot_11;
    zT_0624AC1B_TailCallData tc;
    zT_C93B9EAA_anon_77219 u_12;
    zT_E0AE1EFD_anon_77575 u_13;
    zT_CD3DE38D_anon_77225 u_14;
    zT_CD402224_anon_77231 ch;
    zT_C540158C_anon_77239 w_15;
    zT_CB2ED5DD_anon_77247 w_16;
    zT_4731D7A8_anon_77253 u_17;
    zT_4131CE36_anon_77259 u_18;
    zT_4D341FB1_anon_77265 ch_19;
    zT_39363ECC_anon_77275 ms;
    zT_4F25184D_anon_77283 ic;
    zT_CC8B6D3F_anon_77595 ic_20;
    zT_879E24B5_anon_77607 ww;
    zT_51275A0A_anon_77291 fc;
    zT_49274D72_anon_77299 pc;
    zT_37D0AD0E_anon_77307 itf;
    zT_B3CD9EAB_anon_77313 pti;
    zT_ADCB56A2_anon_77321 itp;
    zT_ABBC48F2_anon_77383 sl;
    zT_ADBA0D81_anon_77399 sg;
    zT_E2CFC39C_anon_77411 pv;
    zT_DECFBD50_anon_77415 bpc;
    zT_72C85787_anon_77421 b_21;
    zT_70C85461_anon_77427 b_22;
    zT_72CA961E_anon_77435 be;
    zT_6ECA8FD2_anon_77439 bsm;
    zT_E0C2F483_anon_77447 bcg;
    zT_ECC545FE_anon_77453 bcc;
    zT_A5BA00E9_anon_77391 lg;
    zT_91531B70_anon_77033 dl;
    zT_A7CB4D30_anon_77327 ic_23;
    zT_39C3E441_anon_77355 bc;
    zT_F2E125ED_anon_77485 ct;
    zT_5 = inst;
    zT_6 = c->lir_fn;
    zT_8 = zF_CFED20F7_defResultTemp_1(zT_5, zT_6);
    rp = zT_8;
    if ((unsigned char)(rp != (unsigned int)(4294967295u))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = c->max_temp;
    if ((unsigned char)(rp < zT_11)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_22 = inst.tag;
switch (zT_22) {
case 2: goto z_bb_5;
case 3: goto z_bb_6;
case 4: goto z_bb_7;
case 6: goto z_bb_8;
case 7: goto z_bb_9;
case 9: goto z_bb_10;
case 12: goto z_bb_11;
case 13: goto z_bb_12;
case 72: goto z_bb_13;
case 73: goto z_bb_14;
case 74: goto z_bb_15;
case 75: goto z_bb_16;
case 76: goto z_bb_17;
case 77: goto z_bb_18;
case 14: goto z_bb_19;
case 15: goto z_bb_20;
case 68: goto z_bb_21;
case 16: goto z_bb_22;
case 69: goto z_bb_23;
case 17: goto z_bb_24;
case 18: goto z_bb_25;
case 19: goto z_bb_26;
case 20: goto z_bb_27;
case 21: goto z_bb_28;
case 22: goto z_bb_29;
case 23: goto z_bb_30;
case 24: goto z_bb_31;
case 25: goto z_bb_32;
case 26: goto z_bb_33;
case 27: goto z_bb_34;
case 29: goto z_bb_35;
case 78: goto z_bb_36;
case 30: goto z_bb_37;
case 31: goto z_bb_38;
case 32: goto z_bb_39;
case 33: goto z_bb_40;
case 34: goto z_bb_41;
case 35: goto z_bb_42;
case 36: goto z_bb_43;
case 37: goto z_bb_44;
case 38: goto z_bb_45;
case 80: goto z_bb_46;
case 81: goto z_bb_47;
case 39: goto z_bb_48;
case 40: goto z_bb_49;
case 41: goto z_bb_50;
case 42: goto z_bb_51;
case 43: goto z_bb_52;
case 53: goto z_bb_53;
case 55: goto z_bb_54;
case 57: goto z_bb_55;
case 58: goto z_bb_56;
case 59: goto z_bb_57;
case 60: goto z_bb_58;
case 62: goto z_bb_59;
case 63: goto z_bb_60;
case 65: goto z_bb_61;
case 66: goto z_bb_62;
case 54: goto z_bb_63;
case 1: goto z_bb_64;
case 44: goto z_bb_65;
case 49: goto z_bb_66;
case 71: goto z_bb_67;
default: goto z_bb_68;
}
    z_bb_3:
    zT_13 = c->df_bb;
    zT_14 = (unsigned int)rp;
    zT_13[zT_14] = bb_idx;
    zT_15 = c->df_ii;
    zT_16 = (unsigned int)rp;
    zT_15[zT_16] = ii;
    goto z_bb_4;
    z_bb_4:
    zT_17 = c;
    zT_18 = rp;
    zT_20 = inst;
    zT_21 = zF_A5E11466_defInfoPure(zT_20);
    zT_19 = zT_21;
    zF_AAEF59B7_markDef(zT_17, zT_18, zT_19);
    goto z_bb_2;
    z_bb_5:
    a = inst.payload.assign._0;
    zT_24 = c;
    zT_25 = a.src;
    zT_26 = bb_idx;
    zT_27 = ii;
    zF_20F1A7B4_markRead(zT_24, zT_25, zT_26, zT_27);
    zT_29 = a.name_id;
    if ((unsigned char)(zT_29 != (unsigned int)(0))) goto z_bb_71; else goto z_bb_72;
    z_bb_6:
    a_1 = inst.payload.assign_field._0;
    zT_36 = c;
    zT_37 = a_1.base;
    zT_38 = bb_idx;
    zT_39 = ii;
    zF_20F1A7B4_markRead(zT_36, zT_37, zT_38, zT_39);
    zT_41 = c;
    zT_42 = a_1.src;
    zT_43 = bb_idx;
    zT_44 = ii;
    zF_20F1A7B4_markRead(zT_41, zT_42, zT_43, zT_44);
    goto z_bb_70;
    z_bb_7:
    a_2 = inst.payload.assign_index._0;
    zT_47 = c;
    zT_48 = a_2.base;
    zT_49 = bb_idx;
    zT_50 = ii;
    zF_20F1A7B4_markRead(zT_47, zT_48, zT_49, zT_50);
    zT_52 = c;
    zT_53 = a_2.index;
    zT_54 = bb_idx;
    zT_55 = ii;
    zF_20F1A7B4_markRead(zT_52, zT_53, zT_54, zT_55);
    zT_57 = c;
    zT_58 = a_2.src;
    zT_59 = bb_idx;
    zT_60 = ii;
    zF_20F1A7B4_markRead(zT_57, zT_58, zT_59, zT_60);
    goto z_bb_70;
    z_bb_8:
    b = inst.payload.branch._0;
    zT_63 = c;
    zT_64 = b.cond;
    zT_65 = bb_idx;
    zT_66 = ii;
    zF_20F1A7B4_markRead(zT_63, zT_64, zT_65, zT_66);
    goto z_bb_70;
    z_bb_9:
    s = inst.payload.switch_br._0;
    zT_69 = c;
    zT_70 = s.cond;
    zT_71 = bb_idx;
    zT_72 = ii;
    zF_20F1A7B4_markRead(zT_69, zT_70, zT_71, zT_72);
    goto z_bb_70;
    z_bb_10:
    v = inst.payload.jump._0;
    zT_75 = c;
    zT_76 = v;
    zT_77 = bb_idx;
    zT_78 = ii;
    zF_20F1A7B4_markRead(zT_75, zT_76, zT_77, zT_78);
    goto z_bb_70;
    z_bb_11:
    b_3 = inst.payload.binary._0;
    zT_80 = c;
    zT_81 = b_3.lhs;
    zT_82 = bb_idx;
    zT_83 = ii;
    zF_20F1A7B4_markRead(zT_80, zT_81, zT_82, zT_83);
    zT_85 = c;
    zT_86 = b_3.rhs;
    zT_87 = bb_idx;
    zT_88 = ii;
    zF_20F1A7B4_markRead(zT_85, zT_86, zT_87, zT_88);
    goto z_bb_70;
    z_bb_12:
    u = inst.payload.unary._0;
    zT_91 = c;
    zT_92 = u.operand;
    zT_93 = bb_idx;
    zT_94 = ii;
    zF_20F1A7B4_markRead(zT_91, zT_92, zT_93, zT_94);
    goto z_bb_70;
    z_bb_13:
    o = inst.payload.add_with_overflow._0;
    zT_97 = c;
    zT_98 = o.lhs;
    zT_99 = bb_idx;
    zT_100 = ii;
    zF_20F1A7B4_markRead(zT_97, zT_98, zT_99, zT_100);
    zT_102 = c;
    zT_103 = o.rhs;
    zT_104 = bb_idx;
    zT_105 = ii;
    zF_20F1A7B4_markRead(zT_102, zT_103, zT_104, zT_105);
    goto z_bb_70;
    z_bb_14:
    o_4 = inst.payload.sub_with_overflow._0;
    zT_108 = c;
    zT_109 = o_4.lhs;
    zT_110 = bb_idx;
    zT_111 = ii;
    zF_20F1A7B4_markRead(zT_108, zT_109, zT_110, zT_111);
    zT_113 = c;
    zT_114 = o_4.rhs;
    zT_115 = bb_idx;
    zT_116 = ii;
    zF_20F1A7B4_markRead(zT_113, zT_114, zT_115, zT_116);
    goto z_bb_70;
    z_bb_15:
    o_5 = inst.payload.mul_with_overflow._0;
    zT_119 = c;
    zT_120 = o_5.lhs;
    zT_121 = bb_idx;
    zT_122 = ii;
    zF_20F1A7B4_markRead(zT_119, zT_120, zT_121, zT_122);
    zT_124 = c;
    zT_125 = o_5.rhs;
    zT_126 = bb_idx;
    zT_127 = ii;
    zF_20F1A7B4_markRead(zT_124, zT_125, zT_126, zT_127);
    goto z_bb_70;
    z_bb_16:
    o_6 = inst.payload.shl_with_overflow._0;
    zT_130 = c;
    zT_131 = o_6.lhs;
    zT_132 = bb_idx;
    zT_133 = ii;
    zF_20F1A7B4_markRead(zT_130, zT_131, zT_132, zT_133);
    zT_135 = c;
    zT_136 = o_6.rhs;
    zT_137 = bb_idx;
    zT_138 = ii;
    zF_20F1A7B4_markRead(zT_135, zT_136, zT_137, zT_138);
    goto z_bb_70;
    z_bb_17:
    o_7 = inst.payload.neg_with_overflow._0;
    zT_141 = c;
    zT_142 = o_7.value;
    zT_143 = bb_idx;
    zT_144 = ii;
    zF_20F1A7B4_markRead(zT_141, zT_142, zT_143, zT_144);
    goto z_bb_70;
    z_bb_18:
    o_8 = inst.payload.overflow_flag._0;
    zT_147 = c;
    zT_148 = o_8.lhs;
    zT_149 = bb_idx;
    zT_150 = ii;
    zF_20F1A7B4_markRead(zT_147, zT_148, zT_149, zT_150);
    zT_152 = c;
    zT_153 = o_8.rhs;
    zT_154 = bb_idx;
    zT_155 = ii;
    zF_20F1A7B4_markRead(zT_152, zT_153, zT_154, zT_155);
    goto z_bb_70;
    z_bb_19:
    cl = inst.payload.call._0;
    zT_158 = c;
    zT_159 = cl.callee;
    zT_160 = bb_idx;
    zT_161 = ii;
    zF_20F1A7B4_markRead(zT_158, zT_159, zT_160, zT_161);
    zT_164 = 0;
    ai = zT_164;
    goto z_bb_73;
    z_bb_20:
    lf = inst.payload.load_field._0;
    zT_176 = c;
    zT_177 = lf.base;
    zT_178 = bb_idx;
    zT_179 = ii;
    zF_20F1A7B4_markRead(zT_176, zT_177, zT_178, zT_179);
    goto z_bb_70;
    z_bb_21:
    lb = inst.payload.load_bitfield._0;
    zT_182 = c;
    zT_183 = lb.base;
    zT_184 = bb_idx;
    zT_185 = ii;
    zF_20F1A7B4_markRead(zT_182, zT_183, zT_184, zT_185);
    goto z_bb_70;
    z_bb_22:
    sf = inst.payload.store_field._0;
    zT_188 = c;
    zT_189 = sf.base;
    zT_190 = bb_idx;
    zT_191 = ii;
    zF_20F1A7B4_markRead(zT_188, zT_189, zT_190, zT_191);
    zT_193 = c;
    zT_194 = sf.value;
    zT_195 = bb_idx;
    zT_196 = ii;
    zF_20F1A7B4_markRead(zT_193, zT_194, zT_195, zT_196);
    goto z_bb_70;
    z_bb_23:
    sb = inst.payload.store_bitfield._0;
    zT_199 = c;
    zT_200 = sb.base;
    zT_201 = bb_idx;
    zT_202 = ii;
    zF_20F1A7B4_markRead(zT_199, zT_200, zT_201, zT_202);
    zT_204 = c;
    zT_205 = sb.value;
    zT_206 = bb_idx;
    zT_207 = ii;
    zF_20F1A7B4_markRead(zT_204, zT_205, zT_206, zT_207);
    goto z_bb_70;
    z_bb_24:
    li = inst.payload.load_index._0;
    zT_210 = c;
    zT_211 = li.base;
    zT_212 = bb_idx;
    zT_213 = ii;
    zF_20F1A7B4_markRead(zT_210, zT_211, zT_212, zT_213);
    zT_215 = c;
    zT_216 = li.index;
    zT_217 = bb_idx;
    zT_218 = ii;
    zF_20F1A7B4_markRead(zT_215, zT_216, zT_217, zT_218);
    goto z_bb_70;
    z_bb_25:
    l = inst.payload.load._0;
    zT_221 = c;
    zT_222 = l.ptr;
    zT_223 = bb_idx;
    zT_224 = ii;
    zF_20F1A7B4_markRead(zT_221, zT_222, zT_223, zT_224);
    goto z_bb_70;
    z_bb_26:
    st = inst.payload.store._0;
    zT_227 = c;
    zT_228 = st.ptr;
    zT_229 = bb_idx;
    zT_230 = ii;
    zF_20F1A7B4_markRead(zT_227, zT_228, zT_229, zT_230);
    zT_232 = c;
    zT_233 = st.value;
    zT_234 = bb_idx;
    zT_235 = ii;
    zF_20F1A7B4_markRead(zT_232, zT_233, zT_234, zT_235);
    goto z_bb_70;
    z_bb_27:
    a_9 = inst.payload.addr_of._0;
    zT_238 = c;
    zT_239 = a_9.operand;
    zT_240 = bb_idx;
    zT_241 = ii;
    zF_20F1A7B4_markRead(zT_238, zT_239, zT_240, zT_241);
    zT_243 = c;
    zT_244 = a_9.operand;
    zF_0A9E889A_markAddrTaken(zT_243, zT_244);
    goto z_bb_70;
    z_bb_28:
    a_10 = inst.payload.addr_of_field._0;
    zT_247 = c;
    zT_248 = a_10.base;
    zT_249 = bb_idx;
    zT_250 = ii;
    zF_20F1A7B4_markRead(zT_247, zT_248, zT_249, zT_250);
    zT_252 = c;
    zT_253 = a_10.base;
    zF_0A9E889A_markAddrTaken(zT_252, zT_253);
    goto z_bb_70;
    z_bb_29:
    w = inst.payload.wrap_optional._0;
    zT_256 = c;
    zT_257 = w.value;
    zT_258 = bb_idx;
    zT_259 = ii;
    zF_20F1A7B4_markRead(zT_256, zT_257, zT_258, zT_259);
    goto z_bb_70;
    z_bb_30:
    slot = inst.payload.jump._0;
    zT_263 = c->lir_fn;
    zT_264 = slot;
    zT_266 = zF_75DE985C_lirSideGetCallDirec(zT_263, zT_264);
    cd = zT_266;
    zT_268 = 0;
    ai = zT_268;
    goto z_bb_77;
    z_bb_31:
    vs = inst.payload.va_start._0;
    zT_280 = c;
    zT_281 = vs.va_list_temp;
    zT_282 = bb_idx;
    zT_283 = ii;
    zF_20F1A7B4_markRead(zT_280, zT_281, zT_282, zT_283);
    zT_285 = c;
    zT_286 = vs.last_param_temp;
    zT_287 = bb_idx;
    zT_288 = ii;
    zF_20F1A7B4_markRead(zT_285, zT_286, zT_287, zT_288);
    goto z_bb_70;
    z_bb_32:
    va = inst.payload.va_arg._0;
    zT_291 = c;
    zT_292 = va.va_list_temp;
    zT_293 = bb_idx;
    zT_294 = ii;
    zF_20F1A7B4_markRead(zT_291, zT_292, zT_293, zT_294);
    goto z_bb_70;
    z_bb_33:
    ve = inst.payload.va_end._0;
    zT_297 = c;
    zT_298 = ve.va_list_temp;
    zT_299 = bb_idx;
    zT_300 = ii;
    zF_20F1A7B4_markRead(zT_297, zT_298, zT_299, zT_300);
    goto z_bb_70;
    z_bb_34:
    slot_11 = inst.payload.jump._0;
    zT_304 = c->lir_fn;
    zT_305 = slot_11;
    zT_307 = zF_1AB3807F_lirSideGetTailCall(zT_304, zT_305);
    tc = zT_307;
    zT_308 = tc.is_indirect;
    if ((unsigned char)(zT_308 != (unsigned char)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_35:
    u_12 = inst.payload.unwrap_optional._0;
    zT_329 = c;
    zT_330 = u_12.value;
    zT_331 = bb_idx;
    zT_332 = ii;
    zF_20F1A7B4_markRead(zT_329, zT_330, zT_331, zT_332);
    goto z_bb_70;
    z_bb_36:
    u_13 = inst.payload.unwrap_optional_checked._0;
    zT_335 = c;
    zT_336 = u_13.value;
    zT_337 = bb_idx;
    zT_338 = ii;
    zF_20F1A7B4_markRead(zT_335, zT_336, zT_337, zT_338);
    goto z_bb_70;
    z_bb_37:
    u_14 = inst.payload.unwrap_optional_abi._0;
    zT_341 = c;
    zT_342 = u_14.value;
    zT_343 = bb_idx;
    zT_344 = ii;
    zF_20F1A7B4_markRead(zT_341, zT_342, zT_343, zT_344);
    goto z_bb_70;
    z_bb_38:
    ch = inst.payload.check_optional._0;
    zT_347 = c;
    zT_348 = ch.value;
    zT_349 = bb_idx;
    zT_350 = ii;
    zF_20F1A7B4_markRead(zT_347, zT_348, zT_349, zT_350);
    goto z_bb_70;
    z_bb_39:
    w_15 = inst.payload.wrap_error_ok._0;
    zT_353 = c;
    zT_354 = w_15.value;
    zT_355 = bb_idx;
    zT_356 = ii;
    zF_20F1A7B4_markRead(zT_353, zT_354, zT_355, zT_356);
    goto z_bb_70;
    z_bb_40:
    w_16 = inst.payload.wrap_error_err._0;
    zT_359 = c;
    zT_360 = w_16.value;
    zT_361 = bb_idx;
    zT_362 = ii;
    zF_20F1A7B4_markRead(zT_359, zT_360, zT_361, zT_362);
    goto z_bb_70;
    z_bb_41:
    u_17 = inst.payload.unwrap_error_payload._0;
    zT_365 = c;
    zT_366 = u_17.value;
    zT_367 = bb_idx;
    zT_368 = ii;
    zF_20F1A7B4_markRead(zT_365, zT_366, zT_367, zT_368);
    goto z_bb_70;
    z_bb_42:
    u_18 = inst.payload.unwrap_error_code._0;
    zT_371 = c;
    zT_372 = u_18.value;
    zT_373 = bb_idx;
    zT_374 = ii;
    zF_20F1A7B4_markRead(zT_371, zT_372, zT_373, zT_374);
    goto z_bb_70;
    z_bb_43:
    ch_19 = inst.payload.check_error._0;
    zT_377 = c;
    zT_378 = ch_19.value;
    zT_379 = bb_idx;
    zT_380 = ii;
    zF_20F1A7B4_markRead(zT_377, zT_378, zT_379, zT_380);
    goto z_bb_70;
    z_bb_44:
    ms = inst.payload.make_slice._0;
    zT_383 = c;
    zT_384 = ms.ptr;
    zT_385 = bb_idx;
    zT_386 = ii;
    zF_20F1A7B4_markRead(zT_383, zT_384, zT_385, zT_386);
    zT_388 = c;
    zT_389 = ms.len;
    zT_390 = bb_idx;
    zT_391 = ii;
    zF_20F1A7B4_markRead(zT_388, zT_389, zT_390, zT_391);
    goto z_bb_70;
    z_bb_45:
    ic = inst.payload.int_cast._0;
    zT_394 = c;
    zT_395 = ic.value;
    zT_396 = bb_idx;
    zT_397 = ii;
    zF_20F1A7B4_markRead(zT_394, zT_395, zT_396, zT_397);
    goto z_bb_70;
    z_bb_46:
    ic_20 = inst.payload.int_cast_checked._0;
    zT_400 = c;
    zT_401 = ic_20.value;
    zT_402 = bb_idx;
    zT_403 = ii;
    zF_20F1A7B4_markRead(zT_400, zT_401, zT_402, zT_403);
    goto z_bb_70;
    z_bb_47:
    ww = inst.payload.width_wrap._0;
    zT_406 = c;
    zT_407 = ww.value;
    zT_408 = bb_idx;
    zT_409 = ii;
    zF_20F1A7B4_markRead(zT_406, zT_407, zT_408, zT_409);
    goto z_bb_70;
    z_bb_48:
    fc = inst.payload.float_cast._0;
    zT_412 = c;
    zT_413 = fc.value;
    zT_414 = bb_idx;
    zT_415 = ii;
    zF_20F1A7B4_markRead(zT_412, zT_413, zT_414, zT_415);
    goto z_bb_70;
    z_bb_49:
    pc = inst.payload.ptr_cast._0;
    zT_418 = c;
    zT_419 = pc.value;
    zT_420 = bb_idx;
    zT_421 = ii;
    zF_20F1A7B4_markRead(zT_418, zT_419, zT_420, zT_421);
    goto z_bb_70;
    z_bb_50:
    itf = inst.payload.int_to_float._0;
    zT_424 = c;
    zT_425 = itf.value;
    zT_426 = bb_idx;
    zT_427 = ii;
    zF_20F1A7B4_markRead(zT_424, zT_425, zT_426, zT_427);
    goto z_bb_70;
    z_bb_51:
    pti = inst.payload.ptr_to_int._0;
    zT_430 = c;
    zT_431 = pti.value;
    zT_432 = bb_idx;
    zT_433 = ii;
    zF_20F1A7B4_markRead(zT_430, zT_431, zT_432, zT_433);
    goto z_bb_70;
    z_bb_52:
    itp = inst.payload.int_to_ptr._0;
    zT_436 = c;
    zT_437 = itp.value;
    zT_438 = bb_idx;
    zT_439 = ii;
    zF_20F1A7B4_markRead(zT_436, zT_437, zT_438, zT_439);
    goto z_bb_70;
    z_bb_53:
    sl = inst.payload.store_local._0;
    zT_442 = c;
    zT_443 = sl.value;
    zT_444 = bb_idx;
    zT_445 = ii;
    zF_20F1A7B4_markRead(zT_442, zT_443, zT_444, zT_445);
    goto z_bb_70;
    z_bb_54:
    sg = inst.payload.store_global._0;
    zT_448 = c;
    zT_449 = sg.value;
    zT_450 = bb_idx;
    zT_451 = ii;
    zF_20F1A7B4_markRead(zT_448, zT_449, zT_450, zT_451);
    goto z_bb_70;
    z_bb_55:
    pv = inst.payload.print_val._0;
    zT_454 = c;
    zT_455 = pv.value;
    zT_456 = bb_idx;
    zT_457 = ii;
    zF_20F1A7B4_markRead(zT_454, zT_455, zT_456, zT_457);
    goto z_bb_70;
    z_bb_56:
    bpc = inst.payload.builtin_put_char._0;
    zT_460 = c;
    zT_461 = bpc.value;
    zT_462 = bb_idx;
    zT_463 = ii;
    zF_20F1A7B4_markRead(zT_460, zT_461, zT_462, zT_463);
    goto z_bb_70;
    z_bb_57:
    b_21 = inst.payload.builtin_stdout_write._0;
    zT_466 = c;
    zT_467 = b_21.ptr;
    zT_468 = bb_idx;
    zT_469 = ii;
    zF_20F1A7B4_markRead(zT_466, zT_467, zT_468, zT_469);
    zT_471 = c;
    zT_472 = b_21.len;
    zT_473 = bb_idx;
    zT_474 = ii;
    zF_20F1A7B4_markRead(zT_471, zT_472, zT_473, zT_474);
    goto z_bb_70;
    z_bb_58:
    b_22 = inst.payload.builtin_stderr_write._0;
    zT_477 = c;
    zT_478 = b_22.ptr;
    zT_479 = bb_idx;
    zT_480 = ii;
    zF_20F1A7B4_markRead(zT_477, zT_478, zT_479, zT_480);
    zT_482 = c;
    zT_483 = b_22.len;
    zT_484 = bb_idx;
    zT_485 = ii;
    zF_20F1A7B4_markRead(zT_482, zT_483, zT_484, zT_485);
    goto z_bb_70;
    z_bb_59:
    be = inst.payload.builtin_exit._0;
    zT_488 = c;
    zT_489 = be.value;
    zT_490 = bb_idx;
    zT_491 = ii;
    zF_20F1A7B4_markRead(zT_488, zT_489, zT_490, zT_491);
    goto z_bb_70;
    z_bb_60:
    bsm = inst.payload.builtin_sleep_ms._0;
    zT_494 = c;
    zT_495 = bsm.value;
    zT_496 = bb_idx;
    zT_497 = ii;
    zF_20F1A7B4_markRead(zT_494, zT_495, zT_496, zT_497);
    goto z_bb_70;
    z_bb_61:
    bcg = inst.payload.builtin_console_gotoxy._0;
    zT_500 = c;
    zT_501 = bcg.x;
    zT_502 = bb_idx;
    zT_503 = ii;
    zF_20F1A7B4_markRead(zT_500, zT_501, zT_502, zT_503);
    zT_505 = c;
    zT_506 = bcg.y;
    zT_507 = bb_idx;
    zT_508 = ii;
    zF_20F1A7B4_markRead(zT_505, zT_506, zT_507, zT_508);
    goto z_bb_70;
    z_bb_62:
    bcc = inst.payload.builtin_console_set_color._0;
    zT_511 = c;
    zT_512 = bcc.fg;
    zT_513 = bb_idx;
    zT_514 = ii;
    zF_20F1A7B4_markRead(zT_511, zT_512, zT_513, zT_514);
    zT_516 = c;
    zT_517 = bcc.bg;
    zT_518 = bb_idx;
    zT_519 = ii;
    zF_20F1A7B4_markRead(zT_516, zT_517, zT_518, zT_519);
    goto z_bb_70;
    z_bb_63:
    lg = inst.payload.load_global._0;
    zT_522 = c;
    zT_523 = lg.result;
    zF_2CDB40DA_markExcluded(zT_522, zT_523);
    zT_525 = c;
    zT_526 = lg.result;
    zF_323EFAF9_markGaSource(zT_525, zT_526);
    goto z_bb_70;
    z_bb_64:
    dl = inst.payload.decl_local._0;
    zT_529 = c;
    zT_530 = dl.temp;
    zF_2CDB40DA_markExcluded(zT_529, zT_530);
    goto z_bb_70;
    z_bb_65:
    ic_23 = inst.payload.int_const._0;
    zT_533 = c;
    zT_534 = ic_23.result;
    zT_535 = ic_23.value;
    zF_83868A0F_recordConst(zT_533, zT_534, zT_535);
    goto z_bb_70;
    z_bb_66:
    bc = inst.payload.bool_const._0;
    zT_539 = c;
    zT_540 = bc.result;
    zT_543 = bc.value;
    zF_83868A0F_recordConst(zT_539, zT_540, (zT_79FAE712_u64)((zT_79FAE712_u64)zT_543));
    goto z_bb_70;
    z_bb_67:
    ct = inst.payload.check_trap._0;
    zT_546 = c;
    zT_547 = ct.cond;
    zT_548 = bb_idx;
    zT_549 = ii;
    zF_20F1A7B4_markRead(zT_546, zT_547, zT_548, zT_549);
    goto z_bb_70;
    z_bb_68:
    goto z_bb_70;
    z_bb_70:
    return;
    z_bb_71:
    zT_32 = c;
    zT_33 = a.dst;
    zF_2CDB40DA_markExcluded(zT_32, zT_33);
    goto z_bb_72;
    z_bb_72:
    goto z_bb_70;
    z_bb_73:
    zT_165 = cl.args_count;
    if ((unsigned char)(ai < zT_165)) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_167 = c;
    zT_171 = cl.args_start;
    zT_169 = bb_idx;
    zT_170 = ii;
    zF_8ABC4310_markArgRead(zT_167, (unsigned int)(zT_171 + ai), zT_169, zT_170);
    goto z_bb_76;
    z_bb_75:
    goto z_bb_70;
    z_bb_76:
    zT_174 = ai + (unsigned int)(1);
    ai = zT_174;
    goto z_bb_73;
    z_bb_77:
    zT_269 = cd.args_count;
    if ((unsigned char)(ai < zT_269)) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_271 = c;
    zT_275 = cd.args_start;
    zT_273 = bb_idx;
    zT_274 = ii;
    zF_8ABC4310_markArgRead(zT_271, (unsigned int)(zT_275 + ai), zT_273, zT_274);
    goto z_bb_80;
    z_bb_79:
    goto z_bb_70;
    z_bb_80:
    zT_278 = ai + (unsigned int)(1);
    ai = zT_278;
    goto z_bb_77;
    z_bb_81:
    zT_311 = c;
    zT_312 = tc.callee;
    zT_313 = bb_idx;
    zT_314 = ii;
    zF_8ABC4310_markArgRead(zT_311, zT_312, zT_313, zT_314);
    goto z_bb_82;
    z_bb_82:
    zT_317 = 0;
    ai = zT_317;
    goto z_bb_83;
    z_bb_83:
    zT_318 = tc.args_count;
    if ((unsigned char)(ai < zT_318)) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_320 = c;
    zT_324 = tc.args_start;
    zT_322 = bb_idx;
    zT_323 = ii;
    zF_8ABC4310_markArgRead(zT_320, (unsigned int)(zT_324 + ai), zT_322, zT_323);
    goto z_bb_86;
    z_bb_85:
    goto z_bb_70;
    z_bb_86:
    zT_327 = ai + (unsigned int)(1);
    ai = zT_327;
    goto z_bb_83;
}

/* scanAll */
void zF_6A60FAEB_scanAll(zT_5EDE903E_Ctx* c) {
    zT_5EDE903E_Ctx* zT_1;
    unsigned int zT_3;
    zT_BBC23664_LirFunction* zT_4;
    zT_1CF28CA3_BasicBlockArrayList zT_5;
    unsigned int zT_6;
    zT_BBC23664_LirFunction* zT_9;
    zT_1CF28CA3_BasicBlockArrayList zT_10;
    zT_88A68B1A_BasicBlock* zT_11;
    zT_88A68B1A_BasicBlock* zT_12;
    unsigned int zT_14;
    zT_DAE4631D_LirInstArrayList zT_15;
    unsigned int zT_16;
    zT_5EDE903E_Ctx* zT_18;
    zT_6BA597BC_LirInst zT_19;
    zT_DAE4631D_LirInstArrayList zT_22;
    zT_6BA597BC_LirInst* zT_23;
    zT_6BA597BC_LirInst zT_24;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_BBC23664_LirFunction* zT_33;
    zT_CFE23D0A_LirParamArrayList zT_34;
    unsigned int zT_35;
    zT_5EDE903E_Ctx* zT_37;
    unsigned int zT_38;
    zT_BBC23664_LirFunction* zT_39;
    zT_CFE23D0A_LirParamArrayList zT_40;
    zT_8779209D_LirParam* zT_41;
    zT_8779209D_LirParam zT_42;
    unsigned int zT_45;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    unsigned int pi;
    zT_1 = c;
    zF_D6CE151A_resetScratch(zT_1);
    zT_3 = 0;
    bi = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = c->lir_fn;
    zT_5 = zT_4->blocks;
    zT_6 = zT_5.len;
    if ((unsigned char)(bi < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = c->lir_fn;
    zT_10 = zT_9->blocks;
    zT_11 = zT_10.items;
    zT_12 = zT_11 + bi;
    bb = zT_12;
    zT_14 = 0;
    ii = zT_14;
    goto z_bb_5;
    z_bb_3:
    zT_32 = 0;
    pi = zT_32;
    goto z_bb_9;
    z_bb_4:
    zT_30 = bi + (unsigned int)(1);
    bi = zT_30;
    goto z_bb_1;
    z_bb_5:
    zT_15 = bb->insts;
    zT_16 = zT_15.len;
    if ((unsigned char)(ii < zT_16)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_18 = c;
    zT_22 = bb->insts;
    zT_23 = zT_22.items;
    zT_24 = zT_23[ii];
    zT_19 = zT_24;
    zF_85F6BDD8_scanInst(zT_18, zT_19, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_28 = ii + (unsigned int)(1);
    ii = zT_28;
    goto z_bb_5;
    z_bb_9:
    zT_33 = c->lir_fn;
    zT_34 = zT_33->params;
    zT_35 = zT_34.len;
    if ((unsigned char)(pi < zT_35)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = c;
    zT_39 = c->lir_fn;
    zT_40 = zT_39->params;
    zT_41 = zT_40.items;
    zT_42 = zT_41[pi];
    zT_38 = zT_42.temp_id;
    zF_2CDB40DA_markExcluded(zT_37, zT_38);
    goto z_bb_12;
    z_bb_11:
    return;
    z_bb_12:
    zT_45 = pi + (unsigned int)(1);
    pi = zT_45;
    goto z_bb_9;
}

/* depthOfTemp */
unsigned char zF_122C0CBD_depthOfTemp(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char* zT_19;
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    unsigned int* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    zT_BBC23664_LirFunction* zT_41;
    zT_1CF28CA3_BasicBlockArrayList zT_42;
    zT_88A68B1A_BasicBlock* zT_43;
    zT_88A68B1A_BasicBlock* zT_45;
    zT_DAE4631D_LirInstArrayList zT_47;
    zT_6BA597BC_LirInst* zT_48;
    unsigned int* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_6BA597BC_LirInst zT_53;
    zT_5EDE903E_Ctx* zT_55;
    zT_6BA597BC_LirInst zT_56;
    unsigned char zT_57 = 0;
    unsigned int zT_61;
    unsigned int zT_64;
    unsigned char zT_65;
    unsigned char* zT_66;
    unsigned int zT_67;
    unsigned char* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    unsigned int pos;
    unsigned char d;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    zT_6BA597BC_LirInst inst;
    unsigned char mx;
    unsigned int r;
    zT_2 = c->max_temp;
    if ((unsigned char)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)t;
    zT_8 = zT_6[zT_7];
    pos = zT_8;
    if ((unsigned char)(pos == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_12 = c->cand;
    zT_13 = (unsigned int)t;
    zT_14 = zT_12[zT_13];
    if ((unsigned char)(zT_14 == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_19 = c->depth;
    zT_20 = (unsigned int)t;
    zT_21 = zT_19[zT_20];
    d = zT_21;
    if ((unsigned char)(d == (unsigned char)(255))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(255);
    z_bb_8:
    if ((unsigned char)(d != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return d;
    z_bb_10:
    zT_27 = 255;
    zT_28 = c->depth;
    zT_29 = (unsigned int)t;
    zT_28[zT_29] = zT_27;
    zT_31 = c->df_bb;
    zT_32 = (unsigned int)t;
    zT_33 = zT_31[zT_32];
    bi = zT_33;
    if ((unsigned char)(bi == (unsigned int)(4294967295u))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_36 = 1;
    zT_37 = c->depth;
    zT_38 = (unsigned int)t;
    zT_37[zT_38] = zT_36;
    return (unsigned char)(1);
    z_bb_12:
    zT_41 = c->lir_fn;
    zT_42 = zT_41->blocks;
    zT_43 = zT_42.items;
    zT_45 = zT_43 + (unsigned int)((unsigned int)bi);
    bb = zT_45;
    zT_47 = bb->insts;
    zT_48 = zT_47.items;
    zT_49 = c->df_ii;
    zT_50 = (unsigned int)t;
    zT_51 = zT_49[zT_50];
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_48[zT_52];
    inst = zT_53;
    zT_55 = c;
    zT_56 = inst;
    zT_57 = zF_B27E2943_maxOperandDepth(zT_55, zT_56);
    mx = zT_57;
    zT_61 = (unsigned int)((unsigned int)mx) + (unsigned int)(1);
    r = zT_61;
    if ((unsigned char)(r > (unsigned int)(255))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_64 = 255;
    r = zT_64;
    goto z_bb_14;
    z_bb_14:
    zT_65 = (unsigned char)r;
    zT_66 = c->depth;
    zT_67 = (unsigned int)t;
    zT_66[zT_67] = zT_65;
    zT_68 = c->depth;
    zT_69 = (unsigned int)t;
    zT_70 = zT_68[zT_69];
    return zT_70;
}

/* maxOperandDepth */
unsigned char zF_B27E2943_maxOperandDepth(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst) {
    unsigned char zT_3;
    unsigned int zT_4;
    zT_5EDE903E_Ctx* zT_6;
    unsigned int zT_7;
    unsigned char zT_9 = 0;
    zT_5EDE903E_Ctx* zT_11;
    unsigned int zT_12;
    unsigned char zT_14 = 0;
    zT_5EDE903E_Ctx* zT_17;
    unsigned int zT_18;
    unsigned char zT_20 = 0;
    zT_5EDE903E_Ctx* zT_22;
    unsigned int zT_23;
    unsigned char zT_25 = 0;
    zT_5EDE903E_Ctx* zT_27;
    unsigned int zT_28;
    unsigned char zT_30 = 0;
    zT_5EDE903E_Ctx* zT_33;
    unsigned int zT_34;
    unsigned char zT_36 = 0;
    zT_5EDE903E_Ctx* zT_38;
    unsigned int zT_39;
    unsigned char zT_41 = 0;
    zT_5EDE903E_Ctx* zT_44;
    unsigned int zT_45;
    unsigned char zT_47 = 0;
    zT_5EDE903E_Ctx* zT_49;
    unsigned int zT_50;
    unsigned char zT_52 = 0;
    zT_5EDE903E_Ctx* zT_55;
    unsigned int zT_56;
    unsigned char zT_58 = 0;
    zT_5EDE903E_Ctx* zT_60;
    unsigned int zT_61;
    unsigned char zT_63 = 0;
    zT_5EDE903E_Ctx* zT_66;
    unsigned int zT_67;
    unsigned char zT_69 = 0;
    zT_5EDE903E_Ctx* zT_71;
    unsigned int zT_72;
    unsigned char zT_74 = 0;
    zT_5EDE903E_Ctx* zT_76;
    unsigned int zT_77;
    unsigned char zT_79 = 0;
    zT_5EDE903E_Ctx* zT_82;
    unsigned int zT_83;
    unsigned char zT_85 = 0;
    zT_5EDE903E_Ctx* zT_87;
    unsigned int zT_88;
    unsigned char zT_90 = 0;
    zT_5EDE903E_Ctx* zT_92;
    unsigned int zT_93;
    unsigned char zT_95 = 0;
    zT_5EDE903E_Ctx* zT_97;
    unsigned int zT_98;
    unsigned char zT_100 = 0;
    zT_5EDE903E_Ctx* zT_102;
    unsigned int zT_103;
    unsigned char zT_105 = 0;
    zT_5EDE903E_Ctx* zT_107;
    unsigned int zT_108;
    unsigned char zT_110 = 0;
    zT_5EDE903E_Ctx* zT_112;
    unsigned int zT_113;
    unsigned char zT_115 = 0;
    zT_5EDE903E_Ctx* zT_117;
    unsigned int zT_118;
    unsigned char zT_120 = 0;
    zT_5EDE903E_Ctx* zT_122;
    unsigned int zT_123;
    unsigned char zT_125 = 0;
    zT_5EDE903E_Ctx* zT_127;
    unsigned int zT_128;
    unsigned char zT_130 = 0;
    zT_5EDE903E_Ctx* zT_133;
    unsigned int zT_134;
    unsigned char zT_136 = 0;
    zT_5EDE903E_Ctx* zT_138;
    unsigned int zT_139;
    unsigned char zT_141 = 0;
    zT_5EDE903E_Ctx* zT_143;
    unsigned int zT_144;
    unsigned char zT_146 = 0;
    zT_5EDE903E_Ctx* zT_148;
    unsigned int zT_149;
    unsigned char zT_151 = 0;
    zT_5EDE903E_Ctx* zT_153;
    unsigned int zT_154;
    unsigned char zT_156 = 0;
    zT_5EDE903E_Ctx* zT_158;
    unsigned int zT_159;
    unsigned char zT_161 = 0;
    zT_5EDE903E_Ctx* zT_163;
    unsigned int zT_164;
    unsigned char zT_166 = 0;
    zT_5EDE903E_Ctx* zT_168;
    unsigned int zT_169;
    unsigned char zT_171 = 0;
    zT_5EDE903E_Ctx* zT_173;
    unsigned int zT_174;
    unsigned char zT_176 = 0;
    zT_5EDE903E_Ctx* zT_178;
    unsigned int zT_179;
    unsigned char zT_181 = 0;
    zT_5EDE903E_Ctx* zT_183;
    unsigned int zT_184;
    unsigned char zT_186 = 0;
    zT_5EDE903E_Ctx* zT_188;
    unsigned int zT_189;
    unsigned char zT_191 = 0;
    zT_5EDE903E_Ctx* zT_193;
    unsigned int zT_194;
    unsigned char zT_196 = 0;
    zT_5EDE903E_Ctx* zT_198;
    unsigned int zT_199;
    unsigned char zT_201 = 0;
    zT_5EDE903E_Ctx* zT_203;
    unsigned int zT_204;
    unsigned char zT_206 = 0;
    zT_5EDE903E_Ctx* zT_208;
    unsigned int zT_209;
    unsigned char zT_211 = 0;
    zT_5EDE903E_Ctx* zT_213;
    unsigned int zT_214;
    unsigned char zT_216 = 0;
    unsigned char mx;
    zT_176BF348_anon_77099 b;
    unsigned char r;
    zT_11ECC358_anon_77107 u;
    zT_EAE357EC_anon_77499 o;
    zT_DA9F0B01_anon_77513 o_1;
    zT_4EA67D62_anon_77527 o_2;
    zT_D4ABCD82_anon_77541 o_3;
    zT_52A8C245_anon_77553 o_4;
    zT_D8B050FC_anon_77569 o_5;
    zT_4F25184D_anon_77283 ic;
    zT_CC8B6D3F_anon_77595 ic_6;
    zT_879E24B5_anon_77607 ww;
    zT_51275A0A_anon_77291 fc;
    zT_49274D72_anon_77299 pc;
    zT_37D0AD0E_anon_77307 itf;
    zT_B3CD9EAB_anon_77313 pti;
    zT_ADCB56A2_anon_77321 itp;
    zT_39363ECC_anon_77275 ms;
    zT_11E8462A_anon_77167 a;
    zT_03E5F189_anon_77175 a_7;
    zT_860101AC_anon_77183 w;
    zT_C540158C_anon_77239 w_8;
    zT_CB2ED5DD_anon_77247 w_9;
    zT_C93B9EAA_anon_77219 u_10;
    zT_E0AE1EFD_anon_77575 u_11;
    zT_CD3DE38D_anon_77225 u_12;
    zT_CD402224_anon_77231 ch;
    zT_4731D7A8_anon_77253 u_13;
    zT_4131CE36_anon_77259 u_14;
    zT_4D341FB1_anon_77265 ch_15;
    zT_7FE0A48F_anon_77155 l;
    zT_81F1F0D6_anon_77127 lf;
    zT_E0BE7755_anon_77467 lb;
    zT_87E2EFBE_anon_77149 li;
    zT_3 = 0;
    mx = zT_3;
    zT_4 = inst.tag;
switch (zT_4) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 72: goto z_bb_3;
case 73: goto z_bb_4;
case 74: goto z_bb_5;
case 75: goto z_bb_6;
case 76: goto z_bb_7;
case 77: goto z_bb_8;
case 38: goto z_bb_9;
case 80: goto z_bb_10;
case 81: goto z_bb_11;
case 39: goto z_bb_12;
case 40: goto z_bb_13;
case 41: goto z_bb_14;
case 42: goto z_bb_15;
case 43: goto z_bb_16;
case 37: goto z_bb_17;
case 20: goto z_bb_18;
case 21: goto z_bb_19;
case 22: goto z_bb_20;
case 32: goto z_bb_21;
case 33: goto z_bb_22;
case 29: goto z_bb_23;
case 78: goto z_bb_24;
case 30: goto z_bb_25;
case 31: goto z_bb_26;
case 34: goto z_bb_27;
case 35: goto z_bb_28;
case 36: goto z_bb_29;
case 18: goto z_bb_30;
case 15: goto z_bb_31;
case 68: goto z_bb_32;
case 17: goto z_bb_33;
default: goto z_bb_34;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_6 = c;
    zT_7 = b.lhs;
    zT_9 = zF_122C0CBD_depthOfTemp(zT_6, zT_7);
    mx = zT_9;
    zT_11 = c;
    zT_12 = b.rhs;
    zT_14 = zF_122C0CBD_depthOfTemp(zT_11, zT_12);
    r = zT_14;
    if ((unsigned char)(r > mx)) goto z_bb_37; else goto z_bb_38;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_17 = c;
    zT_18 = u.operand;
    zT_20 = zF_122C0CBD_depthOfTemp(zT_17, zT_18);
    mx = zT_20;
    goto z_bb_36;
    z_bb_3:
    o = inst.payload.add_with_overflow._0;
    zT_22 = c;
    zT_23 = o.lhs;
    zT_25 = zF_122C0CBD_depthOfTemp(zT_22, zT_23);
    mx = zT_25;
    zT_27 = c;
    zT_28 = o.rhs;
    zT_30 = zF_122C0CBD_depthOfTemp(zT_27, zT_28);
    r = zT_30;
    if ((unsigned char)(r > mx)) goto z_bb_39; else goto z_bb_40;
    z_bb_4:
    o_1 = inst.payload.sub_with_overflow._0;
    zT_33 = c;
    zT_34 = o_1.lhs;
    zT_36 = zF_122C0CBD_depthOfTemp(zT_33, zT_34);
    mx = zT_36;
    zT_38 = c;
    zT_39 = o_1.rhs;
    zT_41 = zF_122C0CBD_depthOfTemp(zT_38, zT_39);
    r = zT_41;
    if ((unsigned char)(r > mx)) goto z_bb_41; else goto z_bb_42;
    z_bb_5:
    o_2 = inst.payload.mul_with_overflow._0;
    zT_44 = c;
    zT_45 = o_2.lhs;
    zT_47 = zF_122C0CBD_depthOfTemp(zT_44, zT_45);
    mx = zT_47;
    zT_49 = c;
    zT_50 = o_2.rhs;
    zT_52 = zF_122C0CBD_depthOfTemp(zT_49, zT_50);
    r = zT_52;
    if ((unsigned char)(r > mx)) goto z_bb_43; else goto z_bb_44;
    z_bb_6:
    o_3 = inst.payload.shl_with_overflow._0;
    zT_55 = c;
    zT_56 = o_3.lhs;
    zT_58 = zF_122C0CBD_depthOfTemp(zT_55, zT_56);
    mx = zT_58;
    zT_60 = c;
    zT_61 = o_3.rhs;
    zT_63 = zF_122C0CBD_depthOfTemp(zT_60, zT_61);
    r = zT_63;
    if ((unsigned char)(r > mx)) goto z_bb_45; else goto z_bb_46;
    z_bb_7:
    o_4 = inst.payload.neg_with_overflow._0;
    zT_66 = c;
    zT_67 = o_4.value;
    zT_69 = zF_122C0CBD_depthOfTemp(zT_66, zT_67);
    mx = zT_69;
    goto z_bb_36;
    z_bb_8:
    o_5 = inst.payload.overflow_flag._0;
    zT_71 = c;
    zT_72 = o_5.lhs;
    zT_74 = zF_122C0CBD_depthOfTemp(zT_71, zT_72);
    mx = zT_74;
    zT_76 = c;
    zT_77 = o_5.rhs;
    zT_79 = zF_122C0CBD_depthOfTemp(zT_76, zT_77);
    r = zT_79;
    if ((unsigned char)(r > mx)) goto z_bb_47; else goto z_bb_48;
    z_bb_9:
    ic = inst.payload.int_cast._0;
    zT_82 = c;
    zT_83 = ic.value;
    zT_85 = zF_122C0CBD_depthOfTemp(zT_82, zT_83);
    mx = zT_85;
    goto z_bb_36;
    z_bb_10:
    ic_6 = inst.payload.int_cast_checked._0;
    zT_87 = c;
    zT_88 = ic_6.value;
    zT_90 = zF_122C0CBD_depthOfTemp(zT_87, zT_88);
    mx = zT_90;
    goto z_bb_36;
    z_bb_11:
    ww = inst.payload.width_wrap._0;
    zT_92 = c;
    zT_93 = ww.value;
    zT_95 = zF_122C0CBD_depthOfTemp(zT_92, zT_93);
    mx = zT_95;
    goto z_bb_36;
    z_bb_12:
    fc = inst.payload.float_cast._0;
    zT_97 = c;
    zT_98 = fc.value;
    zT_100 = zF_122C0CBD_depthOfTemp(zT_97, zT_98);
    mx = zT_100;
    goto z_bb_36;
    z_bb_13:
    pc = inst.payload.ptr_cast._0;
    zT_102 = c;
    zT_103 = pc.value;
    zT_105 = zF_122C0CBD_depthOfTemp(zT_102, zT_103);
    mx = zT_105;
    goto z_bb_36;
    z_bb_14:
    itf = inst.payload.int_to_float._0;
    zT_107 = c;
    zT_108 = itf.value;
    zT_110 = zF_122C0CBD_depthOfTemp(zT_107, zT_108);
    mx = zT_110;
    goto z_bb_36;
    z_bb_15:
    pti = inst.payload.ptr_to_int._0;
    zT_112 = c;
    zT_113 = pti.value;
    zT_115 = zF_122C0CBD_depthOfTemp(zT_112, zT_113);
    mx = zT_115;
    goto z_bb_36;
    z_bb_16:
    itp = inst.payload.int_to_ptr._0;
    zT_117 = c;
    zT_118 = itp.value;
    zT_120 = zF_122C0CBD_depthOfTemp(zT_117, zT_118);
    mx = zT_120;
    goto z_bb_36;
    z_bb_17:
    ms = inst.payload.make_slice._0;
    zT_122 = c;
    zT_123 = ms.ptr;
    zT_125 = zF_122C0CBD_depthOfTemp(zT_122, zT_123);
    mx = zT_125;
    zT_127 = c;
    zT_128 = ms.len;
    zT_130 = zF_122C0CBD_depthOfTemp(zT_127, zT_128);
    r = zT_130;
    if ((unsigned char)(r > mx)) goto z_bb_49; else goto z_bb_50;
    z_bb_18:
    a = inst.payload.addr_of._0;
    zT_133 = c;
    zT_134 = a.operand;
    zT_136 = zF_122C0CBD_depthOfTemp(zT_133, zT_134);
    mx = zT_136;
    goto z_bb_36;
    z_bb_19:
    a_7 = inst.payload.addr_of_field._0;
    zT_138 = c;
    zT_139 = a_7.base;
    zT_141 = zF_122C0CBD_depthOfTemp(zT_138, zT_139);
    mx = zT_141;
    goto z_bb_36;
    z_bb_20:
    w = inst.payload.wrap_optional._0;
    zT_143 = c;
    zT_144 = w.value;
    zT_146 = zF_122C0CBD_depthOfTemp(zT_143, zT_144);
    mx = zT_146;
    goto z_bb_36;
    z_bb_21:
    w_8 = inst.payload.wrap_error_ok._0;
    zT_148 = c;
    zT_149 = w_8.value;
    zT_151 = zF_122C0CBD_depthOfTemp(zT_148, zT_149);
    mx = zT_151;
    goto z_bb_36;
    z_bb_22:
    w_9 = inst.payload.wrap_error_err._0;
    zT_153 = c;
    zT_154 = w_9.value;
    zT_156 = zF_122C0CBD_depthOfTemp(zT_153, zT_154);
    mx = zT_156;
    goto z_bb_36;
    z_bb_23:
    u_10 = inst.payload.unwrap_optional._0;
    zT_158 = c;
    zT_159 = u_10.value;
    zT_161 = zF_122C0CBD_depthOfTemp(zT_158, zT_159);
    mx = zT_161;
    goto z_bb_36;
    z_bb_24:
    u_11 = inst.payload.unwrap_optional_checked._0;
    zT_163 = c;
    zT_164 = u_11.value;
    zT_166 = zF_122C0CBD_depthOfTemp(zT_163, zT_164);
    mx = zT_166;
    goto z_bb_36;
    z_bb_25:
    u_12 = inst.payload.unwrap_optional_abi._0;
    zT_168 = c;
    zT_169 = u_12.value;
    zT_171 = zF_122C0CBD_depthOfTemp(zT_168, zT_169);
    mx = zT_171;
    goto z_bb_36;
    z_bb_26:
    ch = inst.payload.check_optional._0;
    zT_173 = c;
    zT_174 = ch.value;
    zT_176 = zF_122C0CBD_depthOfTemp(zT_173, zT_174);
    mx = zT_176;
    goto z_bb_36;
    z_bb_27:
    u_13 = inst.payload.unwrap_error_payload._0;
    zT_178 = c;
    zT_179 = u_13.value;
    zT_181 = zF_122C0CBD_depthOfTemp(zT_178, zT_179);
    mx = zT_181;
    goto z_bb_36;
    z_bb_28:
    u_14 = inst.payload.unwrap_error_code._0;
    zT_183 = c;
    zT_184 = u_14.value;
    zT_186 = zF_122C0CBD_depthOfTemp(zT_183, zT_184);
    mx = zT_186;
    goto z_bb_36;
    z_bb_29:
    ch_15 = inst.payload.check_error._0;
    zT_188 = c;
    zT_189 = ch_15.value;
    zT_191 = zF_122C0CBD_depthOfTemp(zT_188, zT_189);
    mx = zT_191;
    goto z_bb_36;
    z_bb_30:
    l = inst.payload.load._0;
    zT_193 = c;
    zT_194 = l.ptr;
    zT_196 = zF_122C0CBD_depthOfTemp(zT_193, zT_194);
    mx = zT_196;
    goto z_bb_36;
    z_bb_31:
    lf = inst.payload.load_field._0;
    zT_198 = c;
    zT_199 = lf.base;
    zT_201 = zF_122C0CBD_depthOfTemp(zT_198, zT_199);
    mx = zT_201;
    goto z_bb_36;
    z_bb_32:
    lb = inst.payload.load_bitfield._0;
    zT_203 = c;
    zT_204 = lb.base;
    zT_206 = zF_122C0CBD_depthOfTemp(zT_203, zT_204);
    mx = zT_206;
    goto z_bb_36;
    z_bb_33:
    li = inst.payload.load_index._0;
    zT_208 = c;
    zT_209 = li.base;
    zT_211 = zF_122C0CBD_depthOfTemp(zT_208, zT_209);
    mx = zT_211;
    zT_213 = c;
    zT_214 = li.index;
    zT_216 = zF_122C0CBD_depthOfTemp(zT_213, zT_214);
    r = zT_216;
    if ((unsigned char)(r > mx)) goto z_bb_51; else goto z_bb_52;
    z_bb_34:
    goto z_bb_36;
    z_bb_36:
    return mx;
    z_bb_37:
    mx = r;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    mx = r;
    goto z_bb_40;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    mx = r;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_36;
    z_bb_43:
    mx = r;
    goto z_bb_44;
    z_bb_44:
    goto z_bb_36;
    z_bb_45:
    mx = r;
    goto z_bb_46;
    z_bb_46:
    goto z_bb_36;
    z_bb_47:
    mx = r;
    goto z_bb_48;
    z_bb_48:
    goto z_bb_36;
    z_bb_49:
    mx = r;
    goto z_bb_50;
    z_bb_50:
    goto z_bb_36;
    z_bb_51:
    mx = r;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_36;
}

/* defReadsMemory */
unsigned char zF_53018302_defReadsMemory(zT_6BA597BC_LirInst inst) {
    unsigned int zT_1;
    zT_1 = inst.tag;
switch (zT_1) {
case 18: goto z_bb_1;
case 15: goto z_bb_2;
case 68: goto z_bb_3;
case 17: goto z_bb_4;
case 52: goto z_bb_5;
case 54: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    return (unsigned char)(1);
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    return (unsigned char)(1);
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    return (unsigned char)(0);
    return 0;
}

/* instOrdered */
unsigned char zF_EB2642CA_instOrdered(zT_6BA597BC_LirInst inst) {
    zT_6BA597BC_LirInst zT_1;
    unsigned char zT_2 = 0;
    zT_1 = inst;
    zT_2 = zF_A5E11466_defInfoPure(zT_1);
    if ((unsigned char)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    return (unsigned char)(1);
}

/* tempReachesGlobalAlias */
unsigned char zF_0CED9F5B_tempReachesGlobalAl(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned char* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    unsigned char zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    unsigned int zT_35;
    unsigned char zT_36;
    unsigned char zT_39;
    unsigned char* zT_40;
    unsigned int zT_41;
    unsigned int* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned char zT_53;
    unsigned char zT_56;
    unsigned char* zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned char* zT_61;
    unsigned int zT_62;
    zT_BBC23664_LirFunction* zT_64;
    zT_1CF28CA3_BasicBlockArrayList zT_65;
    zT_88A68B1A_BasicBlock* zT_66;
    unsigned int zT_67;
    zT_88A68B1A_BasicBlock zT_68;
    zT_DAE4631D_LirInstArrayList zT_69;
    zT_6BA597BC_LirInst* zT_70;
    unsigned int zT_71;
    zT_6BA597BC_LirInst zT_72;
    zT_5EDE903E_Ctx* zT_74;
    zT_6BA597BC_LirInst zT_75;
    unsigned char zT_76 = 0;
    unsigned char zT_79;
    unsigned char* zT_80;
    unsigned int zT_81;
    unsigned char zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    unsigned int pos;
    unsigned char m;
    unsigned int bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    unsigned char r;
    zT_2 = c->max_temp;
    if ((unsigned char)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)t;
    zT_8 = zT_6[zT_7];
    pos = zT_8;
    if ((unsigned char)(pos == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_13 = c->gam;
    zT_14 = (unsigned int)pos;
    zT_15 = zT_13[zT_14];
    m = zT_15;
    if ((unsigned char)(m == (unsigned char)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(m == (unsigned char)(2))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(m == (unsigned char)(255))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_25 = c->ga;
    zT_26 = (unsigned int)pos;
    zT_27 = zT_25[zT_26];
    if ((unsigned char)(zT_27 == (unsigned char)(1))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 1;
    zT_31 = c->gam;
    zT_32 = (unsigned int)pos;
    zT_31[zT_32] = zT_30;
    return (unsigned char)(1);
    z_bb_12:
    zT_34 = c->cand;
    zT_35 = (unsigned int)pos;
    zT_36 = zT_34[zT_35];
    if ((unsigned char)(zT_36 == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_39 = 2;
    zT_40 = c->gam;
    zT_41 = (unsigned int)pos;
    zT_40[zT_41] = zT_39;
    return (unsigned char)(0);
    z_bb_14:
    zT_44 = c->df_bb;
    zT_45 = (unsigned int)t;
    zT_46 = zT_44[zT_45];
    bb = zT_46;
    zT_48 = c->df_ii;
    zT_49 = (unsigned int)t;
    zT_50 = zT_48[zT_49];
    ii = zT_50;
    if ((unsigned char)(bb == (unsigned int)(4294967295u))) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_53 = ii == (unsigned int)(4294967295u);
    goto z_bb_17;
    z_bb_16:
    zT_53 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_53) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_56 = 2;
    zT_57 = c->gam;
    zT_58 = (unsigned int)pos;
    zT_57[zT_58] = zT_56;
    return (unsigned char)(0);
    z_bb_19:
    zT_60 = 255;
    zT_61 = c->gam;
    zT_62 = (unsigned int)pos;
    zT_61[zT_62] = zT_60;
    zT_64 = c->lir_fn;
    zT_65 = zT_64->blocks;
    zT_66 = zT_65.items;
    zT_67 = (unsigned int)bb;
    zT_68 = zT_66[zT_67];
    zT_69 = zT_68.insts;
    zT_70 = zT_69.items;
    zT_71 = (unsigned int)ii;
    zT_72 = zT_70[zT_71];
    inst = zT_72;
    zT_74 = c;
    zT_75 = inst;
    zT_76 = zF_CDC9F097_instOperandsReachGl(zT_74, zT_75);
    r = zT_76;
    if ((unsigned char)(r != (unsigned char)(0))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_79 = 1;
    zT_80 = c->gam;
    zT_81 = (unsigned int)pos;
    zT_80[zT_81] = zT_79;
    goto z_bb_21;
    z_bb_21:
    return r;
    z_bb_22:
    zT_82 = 2;
    zT_83 = c->gam;
    zT_84 = (unsigned int)pos;
    zT_83[zT_84] = zT_82;
    goto z_bb_21;
}

/* instOperandsReachGlobalAlias */
unsigned char zF_CDC9F097_instOperandsReachGl(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst) {
    unsigned int zT_2;
    zT_5EDE903E_Ctx* zT_4;
    unsigned int zT_5;
    unsigned char zT_7 = 0;
    zT_5EDE903E_Ctx* zT_11;
    unsigned int zT_12;
    unsigned char zT_14 = 0;
    zT_5EDE903E_Ctx* zT_16;
    unsigned int zT_17;
    unsigned char zT_19 = 0;
    zT_5EDE903E_Ctx* zT_21;
    unsigned int zT_22;
    unsigned char zT_24 = 0;
    zT_5EDE903E_Ctx* zT_28;
    unsigned int zT_29;
    unsigned char zT_31 = 0;
    zT_5EDE903E_Ctx* zT_33;
    unsigned int zT_34;
    unsigned char zT_36 = 0;
    zT_5EDE903E_Ctx* zT_40;
    unsigned int zT_41;
    unsigned char zT_43 = 0;
    zT_5EDE903E_Ctx* zT_45;
    unsigned int zT_46;
    unsigned char zT_48 = 0;
    zT_5EDE903E_Ctx* zT_52;
    unsigned int zT_53;
    unsigned char zT_55 = 0;
    zT_5EDE903E_Ctx* zT_57;
    unsigned int zT_58;
    unsigned char zT_60 = 0;
    zT_5EDE903E_Ctx* zT_64;
    unsigned int zT_65;
    unsigned char zT_67 = 0;
    zT_5EDE903E_Ctx* zT_69;
    unsigned int zT_70;
    unsigned char zT_72 = 0;
    zT_5EDE903E_Ctx* zT_74;
    unsigned int zT_75;
    unsigned char zT_77 = 0;
    zT_5EDE903E_Ctx* zT_81;
    unsigned int zT_82;
    unsigned char zT_84 = 0;
    zT_5EDE903E_Ctx* zT_86;
    unsigned int zT_87;
    unsigned char zT_89 = 0;
    zT_5EDE903E_Ctx* zT_91;
    unsigned int zT_92;
    unsigned char zT_94 = 0;
    zT_5EDE903E_Ctx* zT_96;
    unsigned int zT_97;
    unsigned char zT_99 = 0;
    zT_5EDE903E_Ctx* zT_101;
    unsigned int zT_102;
    unsigned char zT_104 = 0;
    zT_5EDE903E_Ctx* zT_106;
    unsigned int zT_107;
    unsigned char zT_109 = 0;
    zT_5EDE903E_Ctx* zT_111;
    unsigned int zT_112;
    unsigned char zT_114 = 0;
    zT_5EDE903E_Ctx* zT_116;
    unsigned int zT_117;
    unsigned char zT_119 = 0;
    zT_5EDE903E_Ctx* zT_121;
    unsigned int zT_122;
    unsigned char zT_124 = 0;
    zT_5EDE903E_Ctx* zT_126;
    unsigned int zT_127;
    unsigned char zT_129 = 0;
    zT_5EDE903E_Ctx* zT_133;
    unsigned int zT_134;
    unsigned char zT_136 = 0;
    zT_5EDE903E_Ctx* zT_138;
    unsigned int zT_139;
    unsigned char zT_141 = 0;
    zT_5EDE903E_Ctx* zT_143;
    unsigned int zT_144;
    unsigned char zT_146 = 0;
    zT_5EDE903E_Ctx* zT_148;
    unsigned int zT_149;
    unsigned char zT_151 = 0;
    zT_5EDE903E_Ctx* zT_153;
    unsigned int zT_154;
    unsigned char zT_156 = 0;
    zT_5EDE903E_Ctx* zT_158;
    unsigned int zT_159;
    unsigned char zT_161 = 0;
    zT_5EDE903E_Ctx* zT_163;
    unsigned int zT_164;
    unsigned char zT_166 = 0;
    zT_5EDE903E_Ctx* zT_168;
    unsigned int zT_169;
    unsigned char zT_171 = 0;
    zT_5EDE903E_Ctx* zT_173;
    unsigned int zT_174;
    unsigned char zT_176 = 0;
    zT_5EDE903E_Ctx* zT_178;
    unsigned int zT_179;
    unsigned char zT_181 = 0;
    zT_5EDE903E_Ctx* zT_183;
    unsigned int zT_184;
    unsigned char zT_186 = 0;
    zT_5EDE903E_Ctx* zT_188;
    unsigned int zT_189;
    unsigned char zT_191 = 0;
    zT_5EDE903E_Ctx* zT_193;
    unsigned int zT_194;
    unsigned char zT_196 = 0;
    zT_5EDE903E_Ctx* zT_198;
    unsigned int zT_199;
    unsigned char zT_201 = 0;
    zT_5EDE903E_Ctx* zT_203;
    unsigned int zT_204;
    unsigned char zT_206 = 0;
    zT_5EDE903E_Ctx* zT_208;
    unsigned int zT_209;
    unsigned char zT_211 = 0;
    zT_5EDE903E_Ctx* zT_213;
    unsigned int zT_214;
    unsigned char zT_216 = 0;
    zT_5EDE903E_Ctx* zT_220;
    unsigned int zT_221;
    unsigned char zT_223 = 0;
    zT_176BF348_anon_77099 b;
    zT_11ECC358_anon_77107 u;
    zT_EAE357EC_anon_77499 o;
    zT_DA9F0B01_anon_77513 o_1;
    zT_4EA67D62_anon_77527 o_2;
    zT_D4ABCD82_anon_77541 o_3;
    zT_52A8C245_anon_77553 o_4;
    zT_D8B050FC_anon_77569 o_5;
    zT_4F25184D_anon_77283 ic;
    zT_CC8B6D3F_anon_77595 ic_6;
    zT_879E24B5_anon_77607 ww;
    zT_51275A0A_anon_77291 fc;
    zT_49274D72_anon_77299 pc;
    zT_37D0AD0E_anon_77307 itf;
    zT_B3CD9EAB_anon_77313 pti;
    zT_ADCB56A2_anon_77321 itp;
    zT_39363ECC_anon_77275 ms;
    zT_11E8462A_anon_77167 a;
    zT_03E5F189_anon_77175 a_7;
    zT_860101AC_anon_77183 w;
    zT_C540158C_anon_77239 w_8;
    zT_CB2ED5DD_anon_77247 w_9;
    zT_C93B9EAA_anon_77219 u_10;
    zT_E0AE1EFD_anon_77575 u_11;
    zT_CD3DE38D_anon_77225 u_12;
    zT_CD402224_anon_77231 ch;
    zT_4731D7A8_anon_77253 u_13;
    zT_4131CE36_anon_77259 u_14;
    zT_4D341FB1_anon_77265 ch_15;
    zT_7FE0A48F_anon_77155 l;
    zT_81F1F0D6_anon_77127 lf;
    zT_E0BE7755_anon_77467 lb;
    zT_87E2EFBE_anon_77149 li;
    zT_2 = inst.tag;
switch (zT_2) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 72: goto z_bb_3;
case 73: goto z_bb_4;
case 74: goto z_bb_5;
case 75: goto z_bb_6;
case 76: goto z_bb_7;
case 77: goto z_bb_8;
case 38: goto z_bb_9;
case 80: goto z_bb_10;
case 81: goto z_bb_11;
case 39: goto z_bb_12;
case 40: goto z_bb_13;
case 41: goto z_bb_14;
case 42: goto z_bb_15;
case 43: goto z_bb_16;
case 37: goto z_bb_17;
case 20: goto z_bb_18;
case 21: goto z_bb_19;
case 22: goto z_bb_20;
case 32: goto z_bb_21;
case 33: goto z_bb_22;
case 29: goto z_bb_23;
case 78: goto z_bb_24;
case 30: goto z_bb_25;
case 31: goto z_bb_26;
case 34: goto z_bb_27;
case 35: goto z_bb_28;
case 36: goto z_bb_29;
case 18: goto z_bb_30;
case 15: goto z_bb_31;
case 68: goto z_bb_32;
case 17: goto z_bb_33;
default: goto z_bb_34;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_4 = c;
    zT_5 = b.lhs;
    zT_7 = zF_0CED9F5B_tempReachesGlobalAl(zT_4, zT_5);
    if ((unsigned char)(zT_7 != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_16 = c;
    zT_17 = u.operand;
    zT_19 = zF_0CED9F5B_tempReachesGlobalAl(zT_16, zT_17);
    return zT_19;
    z_bb_3:
    o = inst.payload.add_with_overflow._0;
    zT_21 = c;
    zT_22 = o.lhs;
    zT_24 = zF_0CED9F5B_tempReachesGlobalAl(zT_21, zT_22);
    if ((unsigned char)(zT_24 != (unsigned char)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_4:
    o_1 = inst.payload.sub_with_overflow._0;
    zT_33 = c;
    zT_34 = o_1.lhs;
    zT_36 = zF_0CED9F5B_tempReachesGlobalAl(zT_33, zT_34);
    if ((unsigned char)(zT_36 != (unsigned char)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_5:
    o_2 = inst.payload.mul_with_overflow._0;
    zT_45 = c;
    zT_46 = o_2.lhs;
    zT_48 = zF_0CED9F5B_tempReachesGlobalAl(zT_45, zT_46);
    if ((unsigned char)(zT_48 != (unsigned char)(0))) goto z_bb_43; else goto z_bb_44;
    z_bb_6:
    o_3 = inst.payload.shl_with_overflow._0;
    zT_57 = c;
    zT_58 = o_3.lhs;
    zT_60 = zF_0CED9F5B_tempReachesGlobalAl(zT_57, zT_58);
    if ((unsigned char)(zT_60 != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_7:
    o_4 = inst.payload.neg_with_overflow._0;
    zT_69 = c;
    zT_70 = o_4.value;
    zT_72 = zF_0CED9F5B_tempReachesGlobalAl(zT_69, zT_70);
    return zT_72;
    z_bb_8:
    o_5 = inst.payload.overflow_flag._0;
    zT_74 = c;
    zT_75 = o_5.lhs;
    zT_77 = zF_0CED9F5B_tempReachesGlobalAl(zT_74, zT_75);
    if ((unsigned char)(zT_77 != (unsigned char)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_9:
    ic = inst.payload.int_cast._0;
    zT_86 = c;
    zT_87 = ic.value;
    zT_89 = zF_0CED9F5B_tempReachesGlobalAl(zT_86, zT_87);
    return zT_89;
    z_bb_10:
    ic_6 = inst.payload.int_cast_checked._0;
    zT_91 = c;
    zT_92 = ic_6.value;
    zT_94 = zF_0CED9F5B_tempReachesGlobalAl(zT_91, zT_92);
    return zT_94;
    z_bb_11:
    ww = inst.payload.width_wrap._0;
    zT_96 = c;
    zT_97 = ww.value;
    zT_99 = zF_0CED9F5B_tempReachesGlobalAl(zT_96, zT_97);
    return zT_99;
    z_bb_12:
    fc = inst.payload.float_cast._0;
    zT_101 = c;
    zT_102 = fc.value;
    zT_104 = zF_0CED9F5B_tempReachesGlobalAl(zT_101, zT_102);
    return zT_104;
    z_bb_13:
    pc = inst.payload.ptr_cast._0;
    zT_106 = c;
    zT_107 = pc.value;
    zT_109 = zF_0CED9F5B_tempReachesGlobalAl(zT_106, zT_107);
    return zT_109;
    z_bb_14:
    itf = inst.payload.int_to_float._0;
    zT_111 = c;
    zT_112 = itf.value;
    zT_114 = zF_0CED9F5B_tempReachesGlobalAl(zT_111, zT_112);
    return zT_114;
    z_bb_15:
    pti = inst.payload.ptr_to_int._0;
    zT_116 = c;
    zT_117 = pti.value;
    zT_119 = zF_0CED9F5B_tempReachesGlobalAl(zT_116, zT_117);
    return zT_119;
    z_bb_16:
    itp = inst.payload.int_to_ptr._0;
    zT_121 = c;
    zT_122 = itp.value;
    zT_124 = zF_0CED9F5B_tempReachesGlobalAl(zT_121, zT_122);
    return zT_124;
    z_bb_17:
    ms = inst.payload.make_slice._0;
    zT_126 = c;
    zT_127 = ms.ptr;
    zT_129 = zF_0CED9F5B_tempReachesGlobalAl(zT_126, zT_127);
    if ((unsigned char)(zT_129 != (unsigned char)(0))) goto z_bb_49; else goto z_bb_50;
    z_bb_18:
    a = inst.payload.addr_of._0;
    zT_138 = c;
    zT_139 = a.operand;
    zT_141 = zF_0CED9F5B_tempReachesGlobalAl(zT_138, zT_139);
    return zT_141;
    z_bb_19:
    a_7 = inst.payload.addr_of_field._0;
    zT_143 = c;
    zT_144 = a_7.base;
    zT_146 = zF_0CED9F5B_tempReachesGlobalAl(zT_143, zT_144);
    return zT_146;
    z_bb_20:
    w = inst.payload.wrap_optional._0;
    zT_148 = c;
    zT_149 = w.value;
    zT_151 = zF_0CED9F5B_tempReachesGlobalAl(zT_148, zT_149);
    return zT_151;
    z_bb_21:
    w_8 = inst.payload.wrap_error_ok._0;
    zT_153 = c;
    zT_154 = w_8.value;
    zT_156 = zF_0CED9F5B_tempReachesGlobalAl(zT_153, zT_154);
    return zT_156;
    z_bb_22:
    w_9 = inst.payload.wrap_error_err._0;
    zT_158 = c;
    zT_159 = w_9.value;
    zT_161 = zF_0CED9F5B_tempReachesGlobalAl(zT_158, zT_159);
    return zT_161;
    z_bb_23:
    u_10 = inst.payload.unwrap_optional._0;
    zT_163 = c;
    zT_164 = u_10.value;
    zT_166 = zF_0CED9F5B_tempReachesGlobalAl(zT_163, zT_164);
    return zT_166;
    z_bb_24:
    u_11 = inst.payload.unwrap_optional_checked._0;
    zT_168 = c;
    zT_169 = u_11.value;
    zT_171 = zF_0CED9F5B_tempReachesGlobalAl(zT_168, zT_169);
    return zT_171;
    z_bb_25:
    u_12 = inst.payload.unwrap_optional_abi._0;
    zT_173 = c;
    zT_174 = u_12.value;
    zT_176 = zF_0CED9F5B_tempReachesGlobalAl(zT_173, zT_174);
    return zT_176;
    z_bb_26:
    ch = inst.payload.check_optional._0;
    zT_178 = c;
    zT_179 = ch.value;
    zT_181 = zF_0CED9F5B_tempReachesGlobalAl(zT_178, zT_179);
    return zT_181;
    z_bb_27:
    u_13 = inst.payload.unwrap_error_payload._0;
    zT_183 = c;
    zT_184 = u_13.value;
    zT_186 = zF_0CED9F5B_tempReachesGlobalAl(zT_183, zT_184);
    return zT_186;
    z_bb_28:
    u_14 = inst.payload.unwrap_error_code._0;
    zT_188 = c;
    zT_189 = u_14.value;
    zT_191 = zF_0CED9F5B_tempReachesGlobalAl(zT_188, zT_189);
    return zT_191;
    z_bb_29:
    ch_15 = inst.payload.check_error._0;
    zT_193 = c;
    zT_194 = ch_15.value;
    zT_196 = zF_0CED9F5B_tempReachesGlobalAl(zT_193, zT_194);
    return zT_196;
    z_bb_30:
    l = inst.payload.load._0;
    zT_198 = c;
    zT_199 = l.ptr;
    zT_201 = zF_0CED9F5B_tempReachesGlobalAl(zT_198, zT_199);
    return zT_201;
    z_bb_31:
    lf = inst.payload.load_field._0;
    zT_203 = c;
    zT_204 = lf.base;
    zT_206 = zF_0CED9F5B_tempReachesGlobalAl(zT_203, zT_204);
    return zT_206;
    z_bb_32:
    lb = inst.payload.load_bitfield._0;
    zT_208 = c;
    zT_209 = lb.base;
    zT_211 = zF_0CED9F5B_tempReachesGlobalAl(zT_208, zT_209);
    return zT_211;
    z_bb_33:
    li = inst.payload.load_index._0;
    zT_213 = c;
    zT_214 = li.base;
    zT_216 = zF_0CED9F5B_tempReachesGlobalAl(zT_213, zT_214);
    if ((unsigned char)(zT_216 != (unsigned char)(0))) goto z_bb_51; else goto z_bb_52;
    z_bb_34:
    goto z_bb_36;
    z_bb_36:
    return (unsigned char)(0);
    z_bb_37:
    return (unsigned char)(1);
    z_bb_38:
    zT_11 = c;
    zT_12 = b.rhs;
    zT_14 = zF_0CED9F5B_tempReachesGlobalAl(zT_11, zT_12);
    return zT_14;
    z_bb_39:
    return (unsigned char)(1);
    z_bb_40:
    zT_28 = c;
    zT_29 = o.rhs;
    zT_31 = zF_0CED9F5B_tempReachesGlobalAl(zT_28, zT_29);
    return zT_31;
    z_bb_41:
    return (unsigned char)(1);
    z_bb_42:
    zT_40 = c;
    zT_41 = o_1.rhs;
    zT_43 = zF_0CED9F5B_tempReachesGlobalAl(zT_40, zT_41);
    return zT_43;
    z_bb_43:
    return (unsigned char)(1);
    z_bb_44:
    zT_52 = c;
    zT_53 = o_2.rhs;
    zT_55 = zF_0CED9F5B_tempReachesGlobalAl(zT_52, zT_53);
    return zT_55;
    z_bb_45:
    return (unsigned char)(1);
    z_bb_46:
    zT_64 = c;
    zT_65 = o_3.rhs;
    zT_67 = zF_0CED9F5B_tempReachesGlobalAl(zT_64, zT_65);
    return zT_67;
    z_bb_47:
    return (unsigned char)(1);
    z_bb_48:
    zT_81 = c;
    zT_82 = o_5.rhs;
    zT_84 = zF_0CED9F5B_tempReachesGlobalAl(zT_81, zT_82);
    return zT_84;
    z_bb_49:
    return (unsigned char)(1);
    z_bb_50:
    zT_133 = c;
    zT_134 = ms.len;
    zT_136 = zF_0CED9F5B_tempReachesGlobalAl(zT_133, zT_134);
    return zT_136;
    z_bb_51:
    return (unsigned char)(1);
    z_bb_52:
    zT_220 = c;
    zT_221 = li.index;
    zT_223 = zF_0CED9F5B_tempReachesGlobalAl(zT_220, zT_221);
    return zT_223;
}

/* computeNestMetadata */
void zF_02672451_computeNestMetadata(zT_5EDE903E_Ctx* c) {
    unsigned int zT_2;
    zT_BBC23664_LirFunction* zT_3;
    zT_1CF28CA3_BasicBlockArrayList zT_4;
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_8;
    zT_1CF28CA3_BasicBlockArrayList zT_9;
    zT_88A68B1A_BasicBlock* zT_10;
    zT_88A68B1A_BasicBlock* zT_11;
    zT_DAE4631D_LirInstArrayList zT_13;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    unsigned int* zT_22 = 0;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_29;
    zT_6BA597BC_LirInst zT_30;
    zT_DAE4631D_LirInstArrayList zT_31;
    zT_6BA597BC_LirInst* zT_32;
    zT_6BA597BC_LirInst zT_33;
    unsigned char zT_34 = 0;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_43;
    unsigned int zT_45;
    unsigned int zT_47;
    zT_DAE4631D_LirInstArrayList zT_50;
    zT_6BA597BC_LirInst* zT_51;
    zT_6BA597BC_LirInst zT_52;
    zT_6BA597BC_LirInst zT_54;
    zT_BBC23664_LirFunction* zT_55;
    unsigned int zT_57 = 0;
    unsigned int zT_60;
    unsigned int* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_68;
    unsigned int* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int* zT_72;
    unsigned int zT_73;
    unsigned int* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned char zT_79;
    unsigned int* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned char zT_85;
    unsigned char* zT_86;
    unsigned int zT_87;
    unsigned char zT_88;
    unsigned char zT_91;
    unsigned char* zT_92;
    unsigned int zT_93;
    unsigned char zT_94;
    unsigned char zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    zT_6BA597BC_LirInst zT_103;
    unsigned char zT_104 = 0;
    unsigned int* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned char zT_117;
    unsigned char zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_125;
    unsigned int zT_126;
    unsigned char zT_128;
    unsigned char* zT_129;
    unsigned int zT_130;
    unsigned char zT_131;
    unsigned char* zT_132;
    unsigned int zT_133;
    unsigned int zT_135;
    unsigned int zT_137;
    unsigned int zT_139;
    zT_BBC23664_LirFunction* zT_140;
    zT_1CF28CA3_BasicBlockArrayList zT_141;
    unsigned int zT_142;
    zT_BBC23664_LirFunction* zT_145;
    zT_1CF28CA3_BasicBlockArrayList zT_146;
    zT_88A68B1A_BasicBlock* zT_147;
    zT_88A68B1A_BasicBlock* zT_148;
    zT_DAE4631D_LirInstArrayList zT_150;
    unsigned int zT_151;
    zT_3E40CD83_Sand* zT_153;
    unsigned int* zT_159 = 0;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_163;
    unsigned int zT_166;
    zT_6BA597BC_LirInst zT_167;
    zT_DAE4631D_LirInstArrayList zT_168;
    zT_6BA597BC_LirInst* zT_169;
    zT_6BA597BC_LirInst zT_170;
    unsigned char zT_171 = 0;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_180;
    unsigned int zT_182;
    unsigned int zT_184;
    zT_DAE4631D_LirInstArrayList zT_187;
    zT_6BA597BC_LirInst* zT_188;
    zT_6BA597BC_LirInst zT_189;
    zT_6BA597BC_LirInst zT_191;
    zT_BBC23664_LirFunction* zT_192;
    unsigned int zT_194 = 0;
    unsigned int zT_197;
    unsigned int* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned char* zT_205;
    unsigned int zT_206;
    unsigned char zT_207;
    zT_6BA597BC_LirInst zT_210;
    unsigned char zT_211 = 0;
    zT_5EDE903E_Ctx* zT_214;
    zT_6BA597BC_LirInst zT_215;
    unsigned char zT_216 = 0;
    unsigned int* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int* zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned char zT_229;
    unsigned char zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_237;
    unsigned int zT_238;
    unsigned char zT_240;
    unsigned char* zT_241;
    unsigned int zT_242;
    unsigned char zT_243;
    unsigned char* zT_244;
    unsigned int zT_245;
    unsigned int zT_247;
    unsigned int zT_249;
    unsigned int zT_251;
    zT_BBC23664_LirFunction* zT_252;
    zT_1CF28CA3_BasicBlockArrayList zT_253;
    unsigned int zT_254;
    zT_BBC23664_LirFunction* zT_257;
    zT_1CF28CA3_BasicBlockArrayList zT_258;
    zT_88A68B1A_BasicBlock* zT_259;
    zT_88A68B1A_BasicBlock* zT_260;
    unsigned int zT_262;
    zT_DAE4631D_LirInstArrayList zT_263;
    unsigned int zT_264;
    zT_6BA597BC_LirInst zT_267;
    zT_BBC23664_LirFunction* zT_268;
    zT_DAE4631D_LirInstArrayList zT_269;
    zT_6BA597BC_LirInst* zT_270;
    zT_6BA597BC_LirInst zT_271;
    unsigned int zT_273 = 0;
    unsigned int zT_276;
    unsigned char* zT_278;
    unsigned int zT_279;
    unsigned char zT_280;
    unsigned char* zT_283;
    unsigned int zT_284;
    unsigned char zT_285;
    zT_5EDE903E_Ctx* zT_288;
    unsigned int zT_289;
    unsigned char zT_290 = 0;
    unsigned int zT_292;
    unsigned int zT_294;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int n;
    unsigned int* ord_pref;
    unsigned int k;
    unsigned int bi3;
    unsigned int ord;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    unsigned int rp;
    unsigned int pos;
    unsigned int cb;
    unsigned int ci;
    zT_88A68B1A_BasicBlock* bb3;
    unsigned int n3;
    unsigned int* ord3;
    unsigned int k3;
    unsigned int bi2;
    unsigned int o3;
    unsigned int ii3;
    zT_6BA597BC_LirInst inst3;
    unsigned int rp3;
    unsigned int pos3;
    unsigned int cb3;
    unsigned int ci3;
    zT_2 = 0;
    bi = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_3 = c->lir_fn;
    zT_4 = zT_3->blocks;
    zT_5 = zT_4.len;
    if ((unsigned char)(bi < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = c->lir_fn;
    zT_9 = zT_8->blocks;
    zT_10 = zT_9.items;
    zT_11 = zT_10 + bi;
    bb = zT_11;
    zT_13 = bb->insts;
    zT_14 = zT_13.len;
    n = zT_14;
    zT_16 = c->alloc;
    zT_22 = zF_730A6C2A_allocU32Raw(zT_16, (unsigned int)((unsigned int)(unsigned int)(n + (unsigned int)(1))));
    ord_pref = zT_22;
    zT_23 = 0;
    zT_24 = 0;
    ord_pref[zT_24] = zT_23;
    zT_26 = 0;
    k = zT_26;
    goto z_bb_5;
    z_bb_3:
    zT_139 = 0;
    bi3 = zT_139;
    goto z_bb_46;
    z_bb_4:
    zT_137 = bi + (unsigned int)(1);
    bi = zT_137;
    goto z_bb_1;
    z_bb_5:
    if ((unsigned char)(k < n)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    ord = zT_29;
    zT_31 = bb->insts;
    zT_32 = zT_31.items;
    zT_33 = zT_32[k];
    zT_30 = zT_33;
    zT_34 = zF_EB2642CA_instOrdered(zT_30);
    if ((unsigned char)(zT_34 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_47 = 0;
    ii = zT_47;
    goto z_bb_11;
    z_bb_8:
    zT_45 = k + (unsigned int)(1);
    k = zT_45;
    goto z_bb_5;
    z_bb_9:
    zT_37 = 1;
    ord = zT_37;
    goto z_bb_10;
    z_bb_10:
    zT_38 = (unsigned int)k;
    zT_39 = ord_pref[zT_38];
    zT_40 = zT_39 + ord;
    zT_43 = (unsigned int)(unsigned int)(k + (unsigned int)(1));
    ord_pref[zT_43] = zT_40;
    goto z_bb_8;
    z_bb_11:
    if ((unsigned char)(ii < n)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_50 = bb->insts;
    zT_51 = zT_50.items;
    zT_52 = zT_51[ii];
    inst = zT_52;
    zT_54 = inst;
    zT_55 = c->lir_fn;
    zT_57 = zF_CFED20F7_defResultTemp_1(zT_54, zT_55);
    rp = zT_57;
    if ((unsigned char)(rp == (unsigned int)(4294967295u))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_4;
    z_bb_14:
    zT_135 = ii + (unsigned int)(1);
    ii = zT_135;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    zT_60 = c->max_temp;
    if ((unsigned char)(rp >= zT_60)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_63 = c->t2p;
    zT_64 = (unsigned int)rp;
    zT_65 = zT_63[zT_64];
    pos = zT_65;
    if ((unsigned char)(pos == (unsigned int)(4294967295u))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_68 = (unsigned int)bi;
    zT_69 = c->df_bb;
    zT_70 = (unsigned int)rp;
    zT_69[zT_70] = zT_68;
    zT_71 = (unsigned int)ii;
    zT_72 = c->df_ii;
    zT_73 = (unsigned int)rp;
    zT_72[zT_73] = zT_71;
    zT_74 = c->wc;
    zT_75 = (unsigned int)pos;
    zT_76 = zT_74[zT_75];
    if ((unsigned char)(zT_76 == (unsigned int)(1))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_80 = c->rc;
    zT_81 = (unsigned int)pos;
    zT_82 = zT_80[zT_81];
    zT_79 = zT_82 == (unsigned int)(1);
    goto z_bb_23;
    z_bb_22:
    zT_79 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_79) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_86 = c->at;
    zT_87 = (unsigned int)pos;
    zT_88 = zT_86[zT_87];
    zT_85 = zT_88 == (unsigned char)(0);
    goto z_bb_26;
    z_bb_25:
    zT_85 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_85) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_92 = c->ex;
    zT_93 = (unsigned int)pos;
    zT_94 = zT_92[zT_93];
    zT_91 = zT_94 == (unsigned char)(0);
    goto z_bb_29;
    z_bb_28:
    zT_91 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_91) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_98 = c->dp;
    zT_99 = (unsigned int)pos;
    zT_100 = zT_98[zT_99];
    zT_97 = zT_100 == (unsigned char)(1);
    goto z_bb_32;
    z_bb_31:
    zT_97 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_97) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_103 = inst;
    zT_104 = zF_53018302_defReadsMemory(zT_103);
    if ((unsigned char)(zT_104 != (unsigned char)(0))) goto z_bb_35; else goto z_bb_37;
    z_bb_34:
    goto z_bb_14;
    z_bb_35:
    zT_108 = c->rd_bb;
    zT_109 = (unsigned int)pos;
    zT_110 = zT_108[zT_109];
    cb = zT_110;
    zT_112 = c->rd_ii;
    zT_113 = (unsigned int)pos;
    zT_114 = zT_112[zT_113];
    ci = zT_114;
    if ((unsigned char)(cb == (unsigned int)((unsigned int)bi))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_131 = 1;
    zT_132 = c->cand;
    zT_133 = (unsigned int)rp;
    zT_132[zT_133] = zT_131;
    goto z_bb_36;
    z_bb_38:
    zT_117 = ci > (unsigned int)((unsigned int)ii);
    goto z_bb_40;
    z_bb_39:
    zT_117 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_117) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_121 = (unsigned int)ci;
    zT_122 = ord_pref[zT_121];
    zT_125 = (unsigned int)(unsigned int)(ii + (unsigned int)(1));
    zT_126 = ord_pref[zT_125];
    zT_120 = zT_122 == zT_126;
    goto z_bb_43;
    z_bb_42:
    zT_120 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_120) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_128 = 1;
    zT_129 = c->cand;
    zT_130 = (unsigned int)rp;
    zT_129[zT_130] = zT_128;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_36;
    z_bb_46:
    zT_140 = c->lir_fn;
    zT_141 = zT_140->blocks;
    zT_142 = zT_141.len;
    if ((unsigned char)(bi3 < zT_142)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_145 = c->lir_fn;
    zT_146 = zT_145->blocks;
    zT_147 = zT_146.items;
    zT_148 = zT_147 + bi3;
    bb3 = zT_148;
    zT_150 = bb3->insts;
    zT_151 = zT_150.len;
    n3 = zT_151;
    zT_153 = c->alloc;
    zT_159 = zF_730A6C2A_allocU32Raw(zT_153, (unsigned int)((unsigned int)(unsigned int)(n3 + (unsigned int)(1))));
    ord3 = zT_159;
    zT_160 = 0;
    zT_161 = 0;
    ord3[zT_161] = zT_160;
    zT_163 = 0;
    k3 = zT_163;
    goto z_bb_50;
    z_bb_48:
    zT_251 = 0;
    bi2 = zT_251;
    goto z_bb_80;
    z_bb_49:
    zT_249 = bi3 + (unsigned int)(1);
    bi3 = zT_249;
    goto z_bb_46;
    z_bb_50:
    if ((unsigned char)(k3 < n3)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_166 = 0;
    o3 = zT_166;
    zT_168 = bb3->insts;
    zT_169 = zT_168.items;
    zT_170 = zT_169[k3];
    zT_167 = zT_170;
    zT_171 = zF_EB2642CA_instOrdered(zT_167);
    if ((unsigned char)(zT_171 != (unsigned char)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_184 = 0;
    ii3 = zT_184;
    goto z_bb_56;
    z_bb_53:
    zT_182 = k3 + (unsigned int)(1);
    k3 = zT_182;
    goto z_bb_50;
    z_bb_54:
    zT_174 = 1;
    o3 = zT_174;
    goto z_bb_55;
    z_bb_55:
    zT_175 = (unsigned int)k3;
    zT_176 = ord3[zT_175];
    zT_177 = zT_176 + o3;
    zT_180 = (unsigned int)(unsigned int)(k3 + (unsigned int)(1));
    ord3[zT_180] = zT_177;
    goto z_bb_53;
    z_bb_56:
    if ((unsigned char)(ii3 < n3)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_187 = bb3->insts;
    zT_188 = zT_187.items;
    zT_189 = zT_188[ii3];
    inst3 = zT_189;
    zT_191 = inst3;
    zT_192 = c->lir_fn;
    zT_194 = zF_CFED20F7_defResultTemp_1(zT_191, zT_192);
    rp3 = zT_194;
    if ((unsigned char)(rp3 == (unsigned int)(4294967295u))) goto z_bb_60; else goto z_bb_61;
    z_bb_58:
    goto z_bb_49;
    z_bb_59:
    zT_247 = ii3 + (unsigned int)(1);
    ii3 = zT_247;
    goto z_bb_56;
    z_bb_60:
    goto z_bb_59;
    z_bb_61:
    zT_197 = c->max_temp;
    if ((unsigned char)(rp3 >= zT_197)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    goto z_bb_59;
    z_bb_63:
    zT_200 = c->t2p;
    zT_201 = (unsigned int)rp3;
    zT_202 = zT_200[zT_201];
    pos3 = zT_202;
    if ((unsigned char)(pos3 == (unsigned int)(4294967295u))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    goto z_bb_59;
    z_bb_65:
    zT_205 = c->cand;
    zT_206 = (unsigned int)pos3;
    zT_207 = zT_205[zT_206];
    if ((unsigned char)(zT_207 == (unsigned char)(0))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    goto z_bb_59;
    z_bb_67:
    zT_210 = inst3;
    zT_211 = zF_53018302_defReadsMemory(zT_210);
    if ((unsigned char)(zT_211 != (unsigned char)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    goto z_bb_59;
    z_bb_69:
    zT_214 = c;
    zT_215 = inst3;
    zT_216 = zF_CDC9F097_instOperandsReachGl(zT_214, zT_215);
    if ((unsigned char)(zT_216 == (unsigned char)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    goto z_bb_59;
    z_bb_71:
    zT_220 = c->rd_bb;
    zT_221 = (unsigned int)pos3;
    zT_222 = zT_220[zT_221];
    cb3 = zT_222;
    zT_224 = c->rd_ii;
    zT_225 = (unsigned int)pos3;
    zT_226 = zT_224[zT_225];
    ci3 = zT_226;
    if ((unsigned char)(cb3 == (unsigned int)((unsigned int)bi3))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_229 = ci3 > (unsigned int)((unsigned int)ii3);
    goto z_bb_74;
    z_bb_73:
    zT_229 = 0;
    goto z_bb_74;
    z_bb_74:
    if (zT_229) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_233 = (unsigned int)ci3;
    zT_234 = ord3[zT_233];
    zT_237 = (unsigned int)(unsigned int)(ii3 + (unsigned int)(1));
    zT_238 = ord3[zT_237];
    zT_232 = zT_234 == zT_238;
    goto z_bb_77;
    z_bb_76:
    zT_232 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_232) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    goto z_bb_59;
    z_bb_79:
    zT_240 = 0;
    zT_241 = c->cand;
    zT_242 = (unsigned int)rp3;
    zT_241[zT_242] = zT_240;
    zT_243 = 0;
    zT_244 = c->gam;
    zT_245 = (unsigned int)pos3;
    zT_244[zT_245] = zT_243;
    goto z_bb_59;
    z_bb_80:
    zT_252 = c->lir_fn;
    zT_253 = zT_252->blocks;
    zT_254 = zT_253.len;
    if ((unsigned char)(bi2 < zT_254)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_257 = c->lir_fn;
    zT_258 = zT_257->blocks;
    zT_259 = zT_258.items;
    zT_260 = zT_259 + bi2;
    bb = zT_260;
    zT_262 = 0;
    ii = zT_262;
    goto z_bb_84;
    z_bb_82:
    return;
    z_bb_83:
    zT_294 = bi2 + (unsigned int)(1);
    bi2 = zT_294;
    goto z_bb_80;
    z_bb_84:
    zT_263 = bb->insts;
    zT_264 = zT_263.len;
    if ((unsigned char)(ii < zT_264)) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_269 = bb->insts;
    zT_270 = zT_269.items;
    zT_271 = zT_270[ii];
    zT_267 = zT_271;
    zT_268 = c->lir_fn;
    zT_273 = zF_CFED20F7_defResultTemp_1(zT_267, zT_268);
    rp = zT_273;
    if ((unsigned char)(rp == (unsigned int)(4294967295u))) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    goto z_bb_83;
    z_bb_87:
    zT_292 = ii + (unsigned int)(1);
    ii = zT_292;
    goto z_bb_84;
    z_bb_88:
    goto z_bb_87;
    z_bb_89:
    zT_276 = c->max_temp;
    if ((unsigned char)(rp >= zT_276)) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    goto z_bb_87;
    z_bb_91:
    zT_278 = c->cand;
    zT_279 = (unsigned int)rp;
    zT_280 = zT_278[zT_279];
    if ((unsigned char)(zT_280 == (unsigned char)(0))) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    goto z_bb_87;
    z_bb_93:
    zT_283 = c->depth;
    zT_284 = (unsigned int)rp;
    zT_285 = zT_283[zT_284];
    if ((unsigned char)(zT_285 != (unsigned char)(0))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    goto z_bb_87;
    z_bb_95:
    zT_288 = c;
    zT_289 = rp;
    zT_290 = zF_122C0CBD_depthOfTemp(zT_288, zT_289);
    (void)zT_290;
    goto z_bb_87;
}

/* maybeR */
unsigned int zF_8B8DBDFB_maybeR(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int r;
    zT_2 = c->max_temp;
    if ((unsigned char)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return t;
    z_bb_2:
    zT_5 = c->ren;
    zT_6 = (unsigned int)t;
    zT_7 = zT_5[zT_6];
    r = zT_7;
    if ((unsigned char)(r == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return t;
    z_bb_4:
    return r;
}

/* rewriteInstOperands */
zT_6BA597BC_LirInst zF_0E3ACCAD_rewriteInstOperands(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst) {
    unsigned int zT_2;
    zT_5EDE903E_Ctx* zT_5;
    unsigned int zT_6;
    unsigned int zT_8 = 0;
    zT_6BA597BC_LirInst zT_9;
    unsigned int zT_10;
    zT_5EDE903E_Ctx* zT_13;
    unsigned int zT_14;
    unsigned int zT_16 = 0;
    zT_5EDE903E_Ctx* zT_17;
    unsigned int zT_18;
    unsigned int zT_20 = 0;
    zT_6BA597BC_LirInst zT_21;
    unsigned int zT_22;
    zT_5EDE903E_Ctx* zT_25;
    unsigned int zT_26;
    unsigned int zT_28 = 0;
    zT_5EDE903E_Ctx* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_5EDE903E_Ctx* zT_33;
    unsigned int zT_34;
    unsigned int zT_36 = 0;
    zT_6BA597BC_LirInst zT_37;
    unsigned int zT_38;
    zT_5EDE903E_Ctx* zT_41;
    unsigned int zT_42;
    unsigned int zT_44 = 0;
    zT_6BA597BC_LirInst zT_45;
    unsigned int zT_46;
    zT_5EDE903E_Ctx* zT_49;
    unsigned int zT_50;
    unsigned int zT_52 = 0;
    zT_6BA597BC_LirInst zT_53;
    unsigned int zT_54;
    zT_6BA597BC_LirInst zT_56;
    zT_5EDE903E_Ctx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    unsigned int zT_60;
    zT_5EDE903E_Ctx* zT_63;
    unsigned int zT_64;
    unsigned int zT_66 = 0;
    zT_5EDE903E_Ctx* zT_67;
    unsigned int zT_68;
    unsigned int zT_70 = 0;
    zT_6BA597BC_LirInst zT_71;
    unsigned int zT_72;
    zT_5EDE903E_Ctx* zT_75;
    unsigned int zT_76;
    unsigned int zT_78 = 0;
    zT_6BA597BC_LirInst zT_79;
    unsigned int zT_80;
    zT_5EDE903E_Ctx* zT_83;
    unsigned int zT_84;
    unsigned int zT_86 = 0;
    zT_6BA597BC_LirInst zT_87;
    unsigned int zT_88;
    zT_5EDE903E_Ctx* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    zT_6BA597BC_LirInst zT_95;
    unsigned int zT_96;
    zT_5EDE903E_Ctx* zT_99;
    unsigned int zT_100;
    unsigned int zT_102 = 0;
    zT_6BA597BC_LirInst zT_103;
    unsigned int zT_104;
    zT_5EDE903E_Ctx* zT_107;
    unsigned int zT_108;
    unsigned int zT_110 = 0;
    zT_5EDE903E_Ctx* zT_111;
    unsigned int zT_112;
    unsigned int zT_114 = 0;
    zT_6BA597BC_LirInst zT_115;
    unsigned int zT_116;
    zT_5EDE903E_Ctx* zT_119;
    unsigned int zT_120;
    unsigned int zT_122 = 0;
    zT_5EDE903E_Ctx* zT_123;
    unsigned int zT_124;
    unsigned int zT_126 = 0;
    zT_6BA597BC_LirInst zT_127;
    unsigned int zT_128;
    zT_5EDE903E_Ctx* zT_131;
    unsigned int zT_132;
    unsigned int zT_134 = 0;
    zT_5EDE903E_Ctx* zT_135;
    unsigned int zT_136;
    unsigned int zT_138 = 0;
    zT_6BA597BC_LirInst zT_139;
    unsigned int zT_140;
    zT_5EDE903E_Ctx* zT_143;
    unsigned int zT_144;
    unsigned int zT_146 = 0;
    zT_6BA597BC_LirInst zT_147;
    unsigned int zT_148;
    zT_5EDE903E_Ctx* zT_151;
    unsigned int zT_152;
    unsigned int zT_154 = 0;
    zT_5EDE903E_Ctx* zT_155;
    unsigned int zT_156;
    unsigned int zT_158 = 0;
    zT_6BA597BC_LirInst zT_159;
    unsigned int zT_160;
    zT_5EDE903E_Ctx* zT_163;
    unsigned int zT_164;
    unsigned int zT_166 = 0;
    zT_6BA597BC_LirInst zT_167;
    unsigned int zT_168;
    zT_5EDE903E_Ctx* zT_171;
    unsigned int zT_172;
    unsigned int zT_174 = 0;
    zT_6BA597BC_LirInst zT_175;
    unsigned int zT_176;
    zT_5EDE903E_Ctx* zT_179;
    unsigned int zT_180;
    unsigned int zT_182 = 0;
    zT_6BA597BC_LirInst zT_183;
    unsigned int zT_184;
    zT_5EDE903E_Ctx* zT_187;
    unsigned int zT_188;
    unsigned int zT_190 = 0;
    zT_5EDE903E_Ctx* zT_191;
    unsigned int zT_192;
    unsigned int zT_194 = 0;
    zT_6BA597BC_LirInst zT_195;
    unsigned int zT_196;
    zT_5EDE903E_Ctx* zT_199;
    unsigned int zT_200;
    unsigned int zT_202 = 0;
    zT_6BA597BC_LirInst zT_203;
    unsigned int zT_204;
    zT_5EDE903E_Ctx* zT_207;
    unsigned int zT_208;
    unsigned int zT_210 = 0;
    zT_6BA597BC_LirInst zT_211;
    unsigned int zT_212;
    zT_5EDE903E_Ctx* zT_215;
    unsigned int zT_216;
    unsigned int zT_218 = 0;
    zT_6BA597BC_LirInst zT_219;
    unsigned int zT_220;
    zT_5EDE903E_Ctx* zT_223;
    unsigned int zT_224;
    unsigned int zT_226 = 0;
    zT_6BA597BC_LirInst zT_227;
    unsigned int zT_228;
    zT_5EDE903E_Ctx* zT_231;
    unsigned int zT_232;
    unsigned int zT_234 = 0;
    zT_6BA597BC_LirInst zT_235;
    unsigned int zT_236;
    zT_5EDE903E_Ctx* zT_239;
    unsigned int zT_240;
    unsigned int zT_242 = 0;
    zT_6BA597BC_LirInst zT_243;
    unsigned int zT_244;
    zT_5EDE903E_Ctx* zT_247;
    unsigned int zT_248;
    unsigned int zT_250 = 0;
    zT_6BA597BC_LirInst zT_251;
    unsigned int zT_252;
    zT_5EDE903E_Ctx* zT_255;
    unsigned int zT_256;
    unsigned int zT_258 = 0;
    zT_6BA597BC_LirInst zT_259;
    unsigned int zT_260;
    zT_5EDE903E_Ctx* zT_263;
    unsigned int zT_264;
    unsigned int zT_266 = 0;
    zT_6BA597BC_LirInst zT_267;
    unsigned int zT_268;
    zT_5EDE903E_Ctx* zT_271;
    unsigned int zT_272;
    unsigned int zT_274 = 0;
    zT_6BA597BC_LirInst zT_275;
    unsigned int zT_276;
    zT_5EDE903E_Ctx* zT_279;
    unsigned int zT_280;
    unsigned int zT_282 = 0;
    zT_6BA597BC_LirInst zT_283;
    unsigned int zT_284;
    zT_5EDE903E_Ctx* zT_287;
    unsigned int zT_288;
    unsigned int zT_290 = 0;
    zT_5EDE903E_Ctx* zT_291;
    unsigned int zT_292;
    unsigned int zT_294 = 0;
    zT_6BA597BC_LirInst zT_295;
    unsigned int zT_296;
    zT_5EDE903E_Ctx* zT_299;
    unsigned int zT_300;
    unsigned int zT_302 = 0;
    zT_5EDE903E_Ctx* zT_303;
    unsigned int zT_304;
    unsigned int zT_306 = 0;
    zT_6BA597BC_LirInst zT_307;
    unsigned int zT_308;
    zT_5EDE903E_Ctx* zT_311;
    unsigned int zT_312;
    unsigned int zT_314 = 0;
    zT_5EDE903E_Ctx* zT_315;
    unsigned int zT_316;
    unsigned int zT_318 = 0;
    zT_6BA597BC_LirInst zT_319;
    unsigned int zT_320;
    zT_5EDE903E_Ctx* zT_323;
    unsigned int zT_324;
    unsigned int zT_326 = 0;
    zT_5EDE903E_Ctx* zT_327;
    unsigned int zT_328;
    unsigned int zT_330 = 0;
    zT_6BA597BC_LirInst zT_331;
    unsigned int zT_332;
    zT_5EDE903E_Ctx* zT_335;
    unsigned int zT_336;
    unsigned int zT_338 = 0;
    zT_6BA597BC_LirInst zT_339;
    unsigned int zT_340;
    zT_5EDE903E_Ctx* zT_343;
    unsigned int zT_344;
    unsigned int zT_346 = 0;
    zT_5EDE903E_Ctx* zT_347;
    unsigned int zT_348;
    unsigned int zT_350 = 0;
    zT_6BA597BC_LirInst zT_351;
    unsigned int zT_352;
    zT_5EDE903E_Ctx* zT_355;
    unsigned int zT_356;
    unsigned int zT_358 = 0;
    zT_5EDE903E_Ctx* zT_359;
    unsigned int zT_360;
    unsigned int zT_362 = 0;
    zT_6BA597BC_LirInst zT_363;
    unsigned int zT_364;
    zT_5EDE903E_Ctx* zT_367;
    unsigned int zT_368;
    unsigned int zT_370 = 0;
    zT_6BA597BC_LirInst zT_371;
    unsigned int zT_372;
    zT_5EDE903E_Ctx* zT_375;
    unsigned int zT_376;
    unsigned int zT_378 = 0;
    zT_6BA597BC_LirInst zT_379;
    unsigned int zT_380;
    zT_5EDE903E_Ctx* zT_383;
    unsigned int zT_384;
    unsigned int zT_386 = 0;
    zT_6BA597BC_LirInst zT_387;
    unsigned int zT_388;
    zT_5EDE903E_Ctx* zT_391;
    unsigned int zT_392;
    unsigned int zT_394 = 0;
    zT_6BA597BC_LirInst zT_395;
    unsigned int zT_396;
    zT_5EDE903E_Ctx* zT_399;
    unsigned int zT_400;
    unsigned int zT_402 = 0;
    zT_6BA597BC_LirInst zT_403;
    unsigned int zT_404;
    zT_5EDE903E_Ctx* zT_407;
    unsigned int zT_408;
    unsigned int zT_410 = 0;
    zT_6BA597BC_LirInst zT_411;
    unsigned int zT_412;
    zT_5EDE903E_Ctx* zT_415;
    unsigned int zT_416;
    unsigned int zT_418 = 0;
    zT_6BA597BC_LirInst zT_419;
    unsigned int zT_420;
    zT_5EDE903E_Ctx* zT_423;
    unsigned int zT_424;
    unsigned int zT_426 = 0;
    zT_6BA597BC_LirInst zT_427;
    unsigned int zT_428;
    zT_5EDE903E_Ctx* zT_431;
    unsigned int zT_432;
    unsigned int zT_434 = 0;
    zT_6BA597BC_LirInst zT_435;
    unsigned int zT_436;
    zT_5EDE903E_Ctx* zT_439;
    unsigned int zT_440;
    unsigned int zT_442 = 0;
    zT_6BA597BC_LirInst zT_443;
    unsigned int zT_444;
    zT_5EDE903E_Ctx* zT_447;
    unsigned int zT_448;
    unsigned int zT_450 = 0;
    zT_6BA597BC_LirInst zT_451;
    unsigned int zT_452;
    zT_5EDE903E_Ctx* zT_455;
    unsigned int zT_456;
    unsigned int zT_458 = 0;
    zT_6BA597BC_LirInst zT_459;
    unsigned int zT_460;
    zT_5EDE903E_Ctx* zT_463;
    unsigned int zT_464;
    unsigned int zT_466 = 0;
    zT_5EDE903E_Ctx* zT_467;
    unsigned int zT_468;
    unsigned int zT_470 = 0;
    zT_6BA597BC_LirInst zT_471;
    unsigned int zT_472;
    zT_5EDE903E_Ctx* zT_475;
    unsigned int zT_476;
    unsigned int zT_478 = 0;
    zT_5EDE903E_Ctx* zT_479;
    unsigned int zT_480;
    unsigned int zT_482 = 0;
    zT_6BA597BC_LirInst zT_483;
    unsigned int zT_484;
    zT_5EDE903E_Ctx* zT_487;
    unsigned int zT_488;
    unsigned int zT_490 = 0;
    zT_6BA597BC_LirInst zT_491;
    unsigned int zT_492;
    zT_5EDE903E_Ctx* zT_495;
    unsigned int zT_496;
    unsigned int zT_498 = 0;
    zT_6BA597BC_LirInst zT_499;
    unsigned int zT_500;
    zT_5EDE903E_Ctx* zT_503;
    unsigned int zT_504;
    unsigned int zT_506 = 0;
    zT_5EDE903E_Ctx* zT_507;
    unsigned int zT_508;
    unsigned int zT_510 = 0;
    zT_6BA597BC_LirInst zT_511;
    unsigned int zT_512;
    zT_5EDE903E_Ctx* zT_515;
    unsigned int zT_516;
    unsigned int zT_518 = 0;
    zT_5EDE903E_Ctx* zT_519;
    unsigned int zT_520;
    unsigned int zT_522 = 0;
    zT_6BA597BC_LirInst zT_523;
    unsigned int zT_524;
    zT_5EDE903E_Ctx* zT_527;
    unsigned int zT_528;
    unsigned int zT_530 = 0;
    zT_6BA597BC_LirInst zT_531;
    unsigned int zT_532;
    zT_935FEA89_anon_77041 a;
    zT_935FEA89_anon_77041 na;
    zT_97622F6C_anon_77051 a_1;
    zT_97622F6C_anon_77051 na_2;
    zT_275AC357_anon_77061 a_3;
    zT_275AC357_anon_77061 na_4;
    zT_2B5D083A_anon_77071 b;
    zT_2B5D083A_anon_77071 nb;
    zT_2B69D42D_anon_77081 s;
    zT_2B69D42D_anon_77081 ns;
    unsigned int v;
    zT_176BF348_anon_77099 b_5;
    zT_176BF348_anon_77099 nb_6;
    zT_11ECC358_anon_77107 u;
    zT_11ECC358_anon_77107 nu;
    zT_11EA84C1_anon_77117 cl;
    zT_11EA84C1_anon_77117 nc;
    zT_81F1F0D6_anon_77127 lf;
    zT_81F1F0D6_anon_77127 nl;
    zT_E0BE7755_anon_77467 lb;
    zT_E0BE7755_anon_77467 nl_7;
    zT_81EFB23F_anon_77137 sf;
    zT_81EFB23F_anon_77137 ns_8;
    zT_E0C0B5EC_anon_77477 sb;
    zT_E0C0B5EC_anon_77477 ns_9;
    zT_87E2EFBE_anon_77149 li;
    zT_87E2EFBE_anon_77149 nl_10;
    zT_7FE0A48F_anon_77155 l;
    zT_7FE0A48F_anon_77155 nl_11;
    zT_0BE83CB8_anon_77161 st;
    zT_0BE83CB8_anon_77161 ns_12;
    zT_11E8462A_anon_77167 a_13;
    zT_11E8462A_anon_77167 na_14;
    zT_03E5F189_anon_77175 a_15;
    zT_03E5F189_anon_77175 na_16;
    zT_860101AC_anon_77183 w;
    zT_860101AC_anon_77183 nw;
    zT_83FEBFEF_anon_77191 vs;
    zT_83FEBFEF_anon_77191 nv;
    zT_8BFECC87_anon_77199 va;
    zT_8BFECC87_anon_77199 nv_17;
    zT_BF395055_anon_77203 ve;
    zT_BF395055_anon_77203 nv_18;
    zT_C93B9EAA_anon_77219 u_19;
    zT_C93B9EAA_anon_77219 nu_20;
    zT_E0AE1EFD_anon_77575 u_21;
    zT_E0AE1EFD_anon_77575 nu_22;
    zT_CD3DE38D_anon_77225 u_23;
    zT_CD3DE38D_anon_77225 nu_24;
    zT_CD402224_anon_77231 ch;
    zT_CD402224_anon_77231 nc_25;
    zT_C540158C_anon_77239 w_26;
    zT_C540158C_anon_77239 nw_27;
    zT_CB2ED5DD_anon_77247 w_28;
    zT_CB2ED5DD_anon_77247 nw_29;
    zT_4731D7A8_anon_77253 u_30;
    zT_4731D7A8_anon_77253 nu_31;
    zT_4131CE36_anon_77259 u_32;
    zT_4131CE36_anon_77259 nu_33;
    zT_4D341FB1_anon_77265 ch_34;
    zT_4D341FB1_anon_77265 nc_35;
    zT_EAE357EC_anon_77499 o;
    zT_EAE357EC_anon_77499 no;
    zT_DA9F0B01_anon_77513 o_36;
    zT_DA9F0B01_anon_77513 no_37;
    zT_4EA67D62_anon_77527 o_38;
    zT_4EA67D62_anon_77527 no_39;
    zT_D4ABCD82_anon_77541 o_40;
    zT_D4ABCD82_anon_77541 no_41;
    zT_52A8C245_anon_77553 o_42;
    zT_52A8C245_anon_77553 no_43;
    zT_D8B050FC_anon_77569 o_44;
    zT_D8B050FC_anon_77569 no_45;
    zT_39363ECC_anon_77275 ms;
    zT_39363ECC_anon_77275 nm;
    zT_4F25184D_anon_77283 ic;
    zT_4F25184D_anon_77283 ni;
    zT_CC8B6D3F_anon_77595 ic_46;
    zT_CC8B6D3F_anon_77595 ni_47;
    zT_879E24B5_anon_77607 ww;
    zT_879E24B5_anon_77607 nw_48;
    zT_51275A0A_anon_77291 fc;
    zT_51275A0A_anon_77291 nf;
    zT_49274D72_anon_77299 pc;
    zT_49274D72_anon_77299 np;
    zT_37D0AD0E_anon_77307 itf;
    zT_37D0AD0E_anon_77307 nt;
    zT_B3CD9EAB_anon_77313 pti;
    zT_B3CD9EAB_anon_77313 nt_49;
    zT_ADCB56A2_anon_77321 itp;
    zT_ADCB56A2_anon_77321 nt_50;
    zT_ABBC48F2_anon_77383 sl;
    zT_ABBC48F2_anon_77383 ns_51;
    zT_ADBA0D81_anon_77399 sg;
    zT_ADBA0D81_anon_77399 ns_52;
    zT_E2CFC39C_anon_77411 pv;
    zT_E2CFC39C_anon_77411 np_53;
    zT_DECFBD50_anon_77415 bpc;
    zT_DECFBD50_anon_77415 nb_54;
    zT_72C85787_anon_77421 b_55;
    zT_72C85787_anon_77421 nb_56;
    zT_70C85461_anon_77427 b_57;
    zT_70C85461_anon_77427 nb_58;
    zT_72CA961E_anon_77435 be;
    zT_72CA961E_anon_77435 nb_59;
    zT_6ECA8FD2_anon_77439 bsm;
    zT_6ECA8FD2_anon_77439 nb_60;
    zT_E0C2F483_anon_77447 bcg;
    zT_E0C2F483_anon_77447 nb_61;
    zT_ECC545FE_anon_77453 bcc;
    zT_ECC545FE_anon_77453 nb_62;
    zT_F2E125ED_anon_77485 ct;
    zT_F2E125ED_anon_77485 nc_63;
    zT_2 = inst.tag;
switch (zT_2) {
case 2: goto z_bb_1;
case 3: goto z_bb_2;
case 4: goto z_bb_3;
case 6: goto z_bb_4;
case 7: goto z_bb_5;
case 9: goto z_bb_6;
case 12: goto z_bb_7;
case 13: goto z_bb_8;
case 14: goto z_bb_9;
case 15: goto z_bb_10;
case 68: goto z_bb_11;
case 16: goto z_bb_12;
case 69: goto z_bb_13;
case 17: goto z_bb_14;
case 18: goto z_bb_15;
case 19: goto z_bb_16;
case 20: goto z_bb_17;
case 21: goto z_bb_18;
case 22: goto z_bb_19;
case 24: goto z_bb_20;
case 25: goto z_bb_21;
case 26: goto z_bb_22;
case 29: goto z_bb_23;
case 78: goto z_bb_24;
case 30: goto z_bb_25;
case 31: goto z_bb_26;
case 32: goto z_bb_27;
case 33: goto z_bb_28;
case 34: goto z_bb_29;
case 35: goto z_bb_30;
case 36: goto z_bb_31;
case 72: goto z_bb_32;
case 73: goto z_bb_33;
case 74: goto z_bb_34;
case 75: goto z_bb_35;
case 76: goto z_bb_36;
case 77: goto z_bb_37;
case 37: goto z_bb_38;
case 38: goto z_bb_39;
case 80: goto z_bb_40;
case 81: goto z_bb_41;
case 39: goto z_bb_42;
case 40: goto z_bb_43;
case 41: goto z_bb_44;
case 42: goto z_bb_45;
case 43: goto z_bb_46;
case 53: goto z_bb_47;
case 55: goto z_bb_48;
case 57: goto z_bb_49;
case 58: goto z_bb_50;
case 59: goto z_bb_51;
case 60: goto z_bb_52;
case 62: goto z_bb_53;
case 63: goto z_bb_54;
case 65: goto z_bb_55;
case 66: goto z_bb_56;
case 71: goto z_bb_57;
default: goto z_bb_58;
}
    z_bb_1:
    a = inst.payload.assign._0;
    na = a;
    zT_5 = c;
    zT_6 = na.src;
    zT_8 = zF_8B8DBDFB_maybeR(zT_5, zT_6);
    na.src = zT_8;
    zT_10 = 2;
    zT_9.tag = zT_10;
    zT_9.payload.assign._0 = na;
    return zT_9;
    z_bb_2:
    a_1 = inst.payload.assign_field._0;
    na_2 = a_1;
    zT_13 = c;
    zT_14 = na_2.base;
    zT_16 = zF_8B8DBDFB_maybeR(zT_13, zT_14);
    na_2.base = zT_16;
    zT_17 = c;
    zT_18 = na_2.src;
    zT_20 = zF_8B8DBDFB_maybeR(zT_17, zT_18);
    na_2.src = zT_20;
    zT_22 = 3;
    zT_21.tag = zT_22;
    zT_21.payload.assign_field._0 = na_2;
    return zT_21;
    z_bb_3:
    a_3 = inst.payload.assign_index._0;
    na_4 = a_3;
    zT_25 = c;
    zT_26 = na_4.base;
    zT_28 = zF_8B8DBDFB_maybeR(zT_25, zT_26);
    na_4.base = zT_28;
    zT_29 = c;
    zT_30 = na_4.index;
    zT_32 = zF_8B8DBDFB_maybeR(zT_29, zT_30);
    na_4.index = zT_32;
    zT_33 = c;
    zT_34 = na_4.src;
    zT_36 = zF_8B8DBDFB_maybeR(zT_33, zT_34);
    na_4.src = zT_36;
    zT_38 = 4;
    zT_37.tag = zT_38;
    zT_37.payload.assign_index._0 = na_4;
    return zT_37;
    z_bb_4:
    b = inst.payload.branch._0;
    nb = b;
    zT_41 = c;
    zT_42 = nb.cond;
    zT_44 = zF_8B8DBDFB_maybeR(zT_41, zT_42);
    nb.cond = zT_44;
    zT_46 = 6;
    zT_45.tag = zT_46;
    zT_45.payload.branch._0 = nb;
    return zT_45;
    z_bb_5:
    s = inst.payload.switch_br._0;
    ns = s;
    zT_49 = c;
    zT_50 = ns.cond;
    zT_52 = zF_8B8DBDFB_maybeR(zT_49, zT_50);
    ns.cond = zT_52;
    zT_54 = 7;
    zT_53.tag = zT_54;
    zT_53.payload.switch_br._0 = ns;
    return zT_53;
    z_bb_6:
    v = inst.payload.jump._0;
    zT_57 = c;
    zT_58 = v;
    zT_59 = zF_8B8DBDFB_maybeR(zT_57, zT_58);
    zT_60 = 9;
    zT_56.tag = zT_60;
    zT_56.payload.jump._0 = zT_59;
    return zT_56;
    z_bb_7:
    b_5 = inst.payload.binary._0;
    nb_6 = b_5;
    zT_63 = c;
    zT_64 = nb_6.lhs;
    zT_66 = zF_8B8DBDFB_maybeR(zT_63, zT_64);
    nb_6.lhs = zT_66;
    zT_67 = c;
    zT_68 = nb_6.rhs;
    zT_70 = zF_8B8DBDFB_maybeR(zT_67, zT_68);
    nb_6.rhs = zT_70;
    zT_72 = 12;
    zT_71.tag = zT_72;
    zT_71.payload.binary._0 = nb_6;
    return zT_71;
    z_bb_8:
    u = inst.payload.unary._0;
    nu = u;
    zT_75 = c;
    zT_76 = nu.operand;
    zT_78 = zF_8B8DBDFB_maybeR(zT_75, zT_76);
    nu.operand = zT_78;
    zT_80 = 13;
    zT_79.tag = zT_80;
    zT_79.payload.unary._0 = nu;
    return zT_79;
    z_bb_9:
    cl = inst.payload.call._0;
    nc = cl;
    zT_83 = c;
    zT_84 = nc.callee;
    zT_86 = zF_8B8DBDFB_maybeR(zT_83, zT_84);
    nc.callee = zT_86;
    zT_88 = 14;
    zT_87.tag = zT_88;
    zT_87.payload.call._0 = nc;
    return zT_87;
    z_bb_10:
    lf = inst.payload.load_field._0;
    nl = lf;
    zT_91 = c;
    zT_92 = nl.base;
    zT_94 = zF_8B8DBDFB_maybeR(zT_91, zT_92);
    nl.base = zT_94;
    zT_96 = 15;
    zT_95.tag = zT_96;
    zT_95.payload.load_field._0 = nl;
    return zT_95;
    z_bb_11:
    lb = inst.payload.load_bitfield._0;
    nl_7 = lb;
    zT_99 = c;
    zT_100 = nl_7.base;
    zT_102 = zF_8B8DBDFB_maybeR(zT_99, zT_100);
    nl_7.base = zT_102;
    zT_104 = 68;
    zT_103.tag = zT_104;
    zT_103.payload.load_bitfield._0 = nl_7;
    return zT_103;
    z_bb_12:
    sf = inst.payload.store_field._0;
    ns_8 = sf;
    zT_107 = c;
    zT_108 = ns_8.base;
    zT_110 = zF_8B8DBDFB_maybeR(zT_107, zT_108);
    ns_8.base = zT_110;
    zT_111 = c;
    zT_112 = ns_8.value;
    zT_114 = zF_8B8DBDFB_maybeR(zT_111, zT_112);
    ns_8.value = zT_114;
    zT_116 = 16;
    zT_115.tag = zT_116;
    zT_115.payload.store_field._0 = ns_8;
    return zT_115;
    z_bb_13:
    sb = inst.payload.store_bitfield._0;
    ns_9 = sb;
    zT_119 = c;
    zT_120 = ns_9.base;
    zT_122 = zF_8B8DBDFB_maybeR(zT_119, zT_120);
    ns_9.base = zT_122;
    zT_123 = c;
    zT_124 = ns_9.value;
    zT_126 = zF_8B8DBDFB_maybeR(zT_123, zT_124);
    ns_9.value = zT_126;
    zT_128 = 69;
    zT_127.tag = zT_128;
    zT_127.payload.store_bitfield._0 = ns_9;
    return zT_127;
    z_bb_14:
    li = inst.payload.load_index._0;
    nl_10 = li;
    zT_131 = c;
    zT_132 = nl_10.base;
    zT_134 = zF_8B8DBDFB_maybeR(zT_131, zT_132);
    nl_10.base = zT_134;
    zT_135 = c;
    zT_136 = nl_10.index;
    zT_138 = zF_8B8DBDFB_maybeR(zT_135, zT_136);
    nl_10.index = zT_138;
    zT_140 = 17;
    zT_139.tag = zT_140;
    zT_139.payload.load_index._0 = nl_10;
    return zT_139;
    z_bb_15:
    l = inst.payload.load._0;
    nl_11 = l;
    zT_143 = c;
    zT_144 = nl_11.ptr;
    zT_146 = zF_8B8DBDFB_maybeR(zT_143, zT_144);
    nl_11.ptr = zT_146;
    zT_148 = 18;
    zT_147.tag = zT_148;
    zT_147.payload.load._0 = nl_11;
    return zT_147;
    z_bb_16:
    st = inst.payload.store._0;
    ns_12 = st;
    zT_151 = c;
    zT_152 = ns_12.ptr;
    zT_154 = zF_8B8DBDFB_maybeR(zT_151, zT_152);
    ns_12.ptr = zT_154;
    zT_155 = c;
    zT_156 = ns_12.value;
    zT_158 = zF_8B8DBDFB_maybeR(zT_155, zT_156);
    ns_12.value = zT_158;
    zT_160 = 19;
    zT_159.tag = zT_160;
    zT_159.payload.store._0 = ns_12;
    return zT_159;
    z_bb_17:
    a_13 = inst.payload.addr_of._0;
    na_14 = a_13;
    zT_163 = c;
    zT_164 = na_14.operand;
    zT_166 = zF_8B8DBDFB_maybeR(zT_163, zT_164);
    na_14.operand = zT_166;
    zT_168 = 20;
    zT_167.tag = zT_168;
    zT_167.payload.addr_of._0 = na_14;
    return zT_167;
    z_bb_18:
    a_15 = inst.payload.addr_of_field._0;
    na_16 = a_15;
    zT_171 = c;
    zT_172 = na_16.base;
    zT_174 = zF_8B8DBDFB_maybeR(zT_171, zT_172);
    na_16.base = zT_174;
    zT_176 = 21;
    zT_175.tag = zT_176;
    zT_175.payload.addr_of_field._0 = na_16;
    return zT_175;
    z_bb_19:
    w = inst.payload.wrap_optional._0;
    nw = w;
    zT_179 = c;
    zT_180 = nw.value;
    zT_182 = zF_8B8DBDFB_maybeR(zT_179, zT_180);
    nw.value = zT_182;
    zT_184 = 22;
    zT_183.tag = zT_184;
    zT_183.payload.wrap_optional._0 = nw;
    return zT_183;
    z_bb_20:
    vs = inst.payload.va_start._0;
    nv = vs;
    zT_187 = c;
    zT_188 = nv.va_list_temp;
    zT_190 = zF_8B8DBDFB_maybeR(zT_187, zT_188);
    nv.va_list_temp = zT_190;
    zT_191 = c;
    zT_192 = nv.last_param_temp;
    zT_194 = zF_8B8DBDFB_maybeR(zT_191, zT_192);
    nv.last_param_temp = zT_194;
    zT_196 = 24;
    zT_195.tag = zT_196;
    zT_195.payload.va_start._0 = nv;
    return zT_195;
    z_bb_21:
    va = inst.payload.va_arg._0;
    nv_17 = va;
    zT_199 = c;
    zT_200 = nv_17.va_list_temp;
    zT_202 = zF_8B8DBDFB_maybeR(zT_199, zT_200);
    nv_17.va_list_temp = zT_202;
    zT_204 = 25;
    zT_203.tag = zT_204;
    zT_203.payload.va_arg._0 = nv_17;
    return zT_203;
    z_bb_22:
    ve = inst.payload.va_end._0;
    nv_18 = ve;
    zT_207 = c;
    zT_208 = nv_18.va_list_temp;
    zT_210 = zF_8B8DBDFB_maybeR(zT_207, zT_208);
    nv_18.va_list_temp = zT_210;
    zT_212 = 26;
    zT_211.tag = zT_212;
    zT_211.payload.va_end._0 = nv_18;
    return zT_211;
    z_bb_23:
    u_19 = inst.payload.unwrap_optional._0;
    nu_20 = u_19;
    zT_215 = c;
    zT_216 = nu_20.value;
    zT_218 = zF_8B8DBDFB_maybeR(zT_215, zT_216);
    nu_20.value = zT_218;
    zT_220 = 29;
    zT_219.tag = zT_220;
    zT_219.payload.unwrap_optional._0 = nu_20;
    return zT_219;
    z_bb_24:
    u_21 = inst.payload.unwrap_optional_checked._0;
    nu_22 = u_21;
    zT_223 = c;
    zT_224 = nu_22.value;
    zT_226 = zF_8B8DBDFB_maybeR(zT_223, zT_224);
    nu_22.value = zT_226;
    zT_228 = 78;
    zT_227.tag = zT_228;
    zT_227.payload.unwrap_optional_checked._0 = nu_22;
    return zT_227;
    z_bb_25:
    u_23 = inst.payload.unwrap_optional_abi._0;
    nu_24 = u_23;
    zT_231 = c;
    zT_232 = nu_24.value;
    zT_234 = zF_8B8DBDFB_maybeR(zT_231, zT_232);
    nu_24.value = zT_234;
    zT_236 = 30;
    zT_235.tag = zT_236;
    zT_235.payload.unwrap_optional_abi._0 = nu_24;
    return zT_235;
    z_bb_26:
    ch = inst.payload.check_optional._0;
    nc_25 = ch;
    zT_239 = c;
    zT_240 = nc_25.value;
    zT_242 = zF_8B8DBDFB_maybeR(zT_239, zT_240);
    nc_25.value = zT_242;
    zT_244 = 31;
    zT_243.tag = zT_244;
    zT_243.payload.check_optional._0 = nc_25;
    return zT_243;
    z_bb_27:
    w_26 = inst.payload.wrap_error_ok._0;
    nw_27 = w_26;
    zT_247 = c;
    zT_248 = nw_27.value;
    zT_250 = zF_8B8DBDFB_maybeR(zT_247, zT_248);
    nw_27.value = zT_250;
    zT_252 = 32;
    zT_251.tag = zT_252;
    zT_251.payload.wrap_error_ok._0 = nw_27;
    return zT_251;
    z_bb_28:
    w_28 = inst.payload.wrap_error_err._0;
    nw_29 = w_28;
    zT_255 = c;
    zT_256 = nw_29.value;
    zT_258 = zF_8B8DBDFB_maybeR(zT_255, zT_256);
    nw_29.value = zT_258;
    zT_260 = 33;
    zT_259.tag = zT_260;
    zT_259.payload.wrap_error_err._0 = nw_29;
    return zT_259;
    z_bb_29:
    u_30 = inst.payload.unwrap_error_payload._0;
    nu_31 = u_30;
    zT_263 = c;
    zT_264 = nu_31.value;
    zT_266 = zF_8B8DBDFB_maybeR(zT_263, zT_264);
    nu_31.value = zT_266;
    zT_268 = 34;
    zT_267.tag = zT_268;
    zT_267.payload.unwrap_error_payload._0 = nu_31;
    return zT_267;
    z_bb_30:
    u_32 = inst.payload.unwrap_error_code._0;
    nu_33 = u_32;
    zT_271 = c;
    zT_272 = nu_33.value;
    zT_274 = zF_8B8DBDFB_maybeR(zT_271, zT_272);
    nu_33.value = zT_274;
    zT_276 = 35;
    zT_275.tag = zT_276;
    zT_275.payload.unwrap_error_code._0 = nu_33;
    return zT_275;
    z_bb_31:
    ch_34 = inst.payload.check_error._0;
    nc_35 = ch_34;
    zT_279 = c;
    zT_280 = nc_35.value;
    zT_282 = zF_8B8DBDFB_maybeR(zT_279, zT_280);
    nc_35.value = zT_282;
    zT_284 = 36;
    zT_283.tag = zT_284;
    zT_283.payload.check_error._0 = nc_35;
    return zT_283;
    z_bb_32:
    o = inst.payload.add_with_overflow._0;
    no = o;
    zT_287 = c;
    zT_288 = no.lhs;
    zT_290 = zF_8B8DBDFB_maybeR(zT_287, zT_288);
    no.lhs = zT_290;
    zT_291 = c;
    zT_292 = no.rhs;
    zT_294 = zF_8B8DBDFB_maybeR(zT_291, zT_292);
    no.rhs = zT_294;
    zT_296 = 72;
    zT_295.tag = zT_296;
    zT_295.payload.add_with_overflow._0 = no;
    return zT_295;
    z_bb_33:
    o_36 = inst.payload.sub_with_overflow._0;
    no_37 = o_36;
    zT_299 = c;
    zT_300 = no_37.lhs;
    zT_302 = zF_8B8DBDFB_maybeR(zT_299, zT_300);
    no_37.lhs = zT_302;
    zT_303 = c;
    zT_304 = no_37.rhs;
    zT_306 = zF_8B8DBDFB_maybeR(zT_303, zT_304);
    no_37.rhs = zT_306;
    zT_308 = 73;
    zT_307.tag = zT_308;
    zT_307.payload.sub_with_overflow._0 = no_37;
    return zT_307;
    z_bb_34:
    o_38 = inst.payload.mul_with_overflow._0;
    no_39 = o_38;
    zT_311 = c;
    zT_312 = no_39.lhs;
    zT_314 = zF_8B8DBDFB_maybeR(zT_311, zT_312);
    no_39.lhs = zT_314;
    zT_315 = c;
    zT_316 = no_39.rhs;
    zT_318 = zF_8B8DBDFB_maybeR(zT_315, zT_316);
    no_39.rhs = zT_318;
    zT_320 = 74;
    zT_319.tag = zT_320;
    zT_319.payload.mul_with_overflow._0 = no_39;
    return zT_319;
    z_bb_35:
    o_40 = inst.payload.shl_with_overflow._0;
    no_41 = o_40;
    zT_323 = c;
    zT_324 = no_41.lhs;
    zT_326 = zF_8B8DBDFB_maybeR(zT_323, zT_324);
    no_41.lhs = zT_326;
    zT_327 = c;
    zT_328 = no_41.rhs;
    zT_330 = zF_8B8DBDFB_maybeR(zT_327, zT_328);
    no_41.rhs = zT_330;
    zT_332 = 75;
    zT_331.tag = zT_332;
    zT_331.payload.shl_with_overflow._0 = no_41;
    return zT_331;
    z_bb_36:
    o_42 = inst.payload.neg_with_overflow._0;
    no_43 = o_42;
    zT_335 = c;
    zT_336 = no_43.value;
    zT_338 = zF_8B8DBDFB_maybeR(zT_335, zT_336);
    no_43.value = zT_338;
    zT_340 = 76;
    zT_339.tag = zT_340;
    zT_339.payload.neg_with_overflow._0 = no_43;
    return zT_339;
    z_bb_37:
    o_44 = inst.payload.overflow_flag._0;
    no_45 = o_44;
    zT_343 = c;
    zT_344 = no_45.lhs;
    zT_346 = zF_8B8DBDFB_maybeR(zT_343, zT_344);
    no_45.lhs = zT_346;
    zT_347 = c;
    zT_348 = no_45.rhs;
    zT_350 = zF_8B8DBDFB_maybeR(zT_347, zT_348);
    no_45.rhs = zT_350;
    zT_352 = 77;
    zT_351.tag = zT_352;
    zT_351.payload.overflow_flag._0 = no_45;
    return zT_351;
    z_bb_38:
    ms = inst.payload.make_slice._0;
    nm = ms;
    zT_355 = c;
    zT_356 = nm.ptr;
    zT_358 = zF_8B8DBDFB_maybeR(zT_355, zT_356);
    nm.ptr = zT_358;
    zT_359 = c;
    zT_360 = nm.len;
    zT_362 = zF_8B8DBDFB_maybeR(zT_359, zT_360);
    nm.len = zT_362;
    zT_364 = 37;
    zT_363.tag = zT_364;
    zT_363.payload.make_slice._0 = nm;
    return zT_363;
    z_bb_39:
    ic = inst.payload.int_cast._0;
    ni = ic;
    zT_367 = c;
    zT_368 = ni.value;
    zT_370 = zF_8B8DBDFB_maybeR(zT_367, zT_368);
    ni.value = zT_370;
    zT_372 = 38;
    zT_371.tag = zT_372;
    zT_371.payload.int_cast._0 = ni;
    return zT_371;
    z_bb_40:
    ic_46 = inst.payload.int_cast_checked._0;
    ni_47 = ic_46;
    zT_375 = c;
    zT_376 = ni_47.value;
    zT_378 = zF_8B8DBDFB_maybeR(zT_375, zT_376);
    ni_47.value = zT_378;
    zT_380 = 80;
    zT_379.tag = zT_380;
    zT_379.payload.int_cast_checked._0 = ni_47;
    return zT_379;
    z_bb_41:
    ww = inst.payload.width_wrap._0;
    nw_48 = ww;
    zT_383 = c;
    zT_384 = nw_48.value;
    zT_386 = zF_8B8DBDFB_maybeR(zT_383, zT_384);
    nw_48.value = zT_386;
    zT_388 = 81;
    zT_387.tag = zT_388;
    zT_387.payload.width_wrap._0 = nw_48;
    return zT_387;
    z_bb_42:
    fc = inst.payload.float_cast._0;
    nf = fc;
    zT_391 = c;
    zT_392 = nf.value;
    zT_394 = zF_8B8DBDFB_maybeR(zT_391, zT_392);
    nf.value = zT_394;
    zT_396 = 39;
    zT_395.tag = zT_396;
    zT_395.payload.float_cast._0 = nf;
    return zT_395;
    z_bb_43:
    pc = inst.payload.ptr_cast._0;
    np = pc;
    zT_399 = c;
    zT_400 = np.value;
    zT_402 = zF_8B8DBDFB_maybeR(zT_399, zT_400);
    np.value = zT_402;
    zT_404 = 40;
    zT_403.tag = zT_404;
    zT_403.payload.ptr_cast._0 = np;
    return zT_403;
    z_bb_44:
    itf = inst.payload.int_to_float._0;
    nt = itf;
    zT_407 = c;
    zT_408 = nt.value;
    zT_410 = zF_8B8DBDFB_maybeR(zT_407, zT_408);
    nt.value = zT_410;
    zT_412 = 41;
    zT_411.tag = zT_412;
    zT_411.payload.int_to_float._0 = nt;
    return zT_411;
    z_bb_45:
    pti = inst.payload.ptr_to_int._0;
    nt_49 = pti;
    zT_415 = c;
    zT_416 = nt_49.value;
    zT_418 = zF_8B8DBDFB_maybeR(zT_415, zT_416);
    nt_49.value = zT_418;
    zT_420 = 42;
    zT_419.tag = zT_420;
    zT_419.payload.ptr_to_int._0 = nt_49;
    return zT_419;
    z_bb_46:
    itp = inst.payload.int_to_ptr._0;
    nt_50 = itp;
    zT_423 = c;
    zT_424 = nt_50.value;
    zT_426 = zF_8B8DBDFB_maybeR(zT_423, zT_424);
    nt_50.value = zT_426;
    zT_428 = 43;
    zT_427.tag = zT_428;
    zT_427.payload.int_to_ptr._0 = nt_50;
    return zT_427;
    z_bb_47:
    sl = inst.payload.store_local._0;
    ns_51 = sl;
    zT_431 = c;
    zT_432 = ns_51.value;
    zT_434 = zF_8B8DBDFB_maybeR(zT_431, zT_432);
    ns_51.value = zT_434;
    zT_436 = 53;
    zT_435.tag = zT_436;
    zT_435.payload.store_local._0 = ns_51;
    return zT_435;
    z_bb_48:
    sg = inst.payload.store_global._0;
    ns_52 = sg;
    zT_439 = c;
    zT_440 = ns_52.value;
    zT_442 = zF_8B8DBDFB_maybeR(zT_439, zT_440);
    ns_52.value = zT_442;
    zT_444 = 55;
    zT_443.tag = zT_444;
    zT_443.payload.store_global._0 = ns_52;
    return zT_443;
    z_bb_49:
    pv = inst.payload.print_val._0;
    np_53 = pv;
    zT_447 = c;
    zT_448 = np_53.value;
    zT_450 = zF_8B8DBDFB_maybeR(zT_447, zT_448);
    np_53.value = zT_450;
    zT_452 = 57;
    zT_451.tag = zT_452;
    zT_451.payload.print_val._0 = np_53;
    return zT_451;
    z_bb_50:
    bpc = inst.payload.builtin_put_char._0;
    nb_54 = bpc;
    zT_455 = c;
    zT_456 = nb_54.value;
    zT_458 = zF_8B8DBDFB_maybeR(zT_455, zT_456);
    nb_54.value = zT_458;
    zT_460 = 58;
    zT_459.tag = zT_460;
    zT_459.payload.builtin_put_char._0 = nb_54;
    return zT_459;
    z_bb_51:
    b_55 = inst.payload.builtin_stdout_write._0;
    nb_56 = b_55;
    zT_463 = c;
    zT_464 = nb_56.ptr;
    zT_466 = zF_8B8DBDFB_maybeR(zT_463, zT_464);
    nb_56.ptr = zT_466;
    zT_467 = c;
    zT_468 = nb_56.len;
    zT_470 = zF_8B8DBDFB_maybeR(zT_467, zT_468);
    nb_56.len = zT_470;
    zT_472 = 59;
    zT_471.tag = zT_472;
    zT_471.payload.builtin_stdout_write._0 = nb_56;
    return zT_471;
    z_bb_52:
    b_57 = inst.payload.builtin_stderr_write._0;
    nb_58 = b_57;
    zT_475 = c;
    zT_476 = nb_58.ptr;
    zT_478 = zF_8B8DBDFB_maybeR(zT_475, zT_476);
    nb_58.ptr = zT_478;
    zT_479 = c;
    zT_480 = nb_58.len;
    zT_482 = zF_8B8DBDFB_maybeR(zT_479, zT_480);
    nb_58.len = zT_482;
    zT_484 = 60;
    zT_483.tag = zT_484;
    zT_483.payload.builtin_stderr_write._0 = nb_58;
    return zT_483;
    z_bb_53:
    be = inst.payload.builtin_exit._0;
    nb_59 = be;
    zT_487 = c;
    zT_488 = nb_59.value;
    zT_490 = zF_8B8DBDFB_maybeR(zT_487, zT_488);
    nb_59.value = zT_490;
    zT_492 = 62;
    zT_491.tag = zT_492;
    zT_491.payload.builtin_exit._0 = nb_59;
    return zT_491;
    z_bb_54:
    bsm = inst.payload.builtin_sleep_ms._0;
    nb_60 = bsm;
    zT_495 = c;
    zT_496 = nb_60.value;
    zT_498 = zF_8B8DBDFB_maybeR(zT_495, zT_496);
    nb_60.value = zT_498;
    zT_500 = 63;
    zT_499.tag = zT_500;
    zT_499.payload.builtin_sleep_ms._0 = nb_60;
    return zT_499;
    z_bb_55:
    bcg = inst.payload.builtin_console_gotoxy._0;
    nb_61 = bcg;
    zT_503 = c;
    zT_504 = nb_61.x;
    zT_506 = zF_8B8DBDFB_maybeR(zT_503, zT_504);
    nb_61.x = zT_506;
    zT_507 = c;
    zT_508 = nb_61.y;
    zT_510 = zF_8B8DBDFB_maybeR(zT_507, zT_508);
    nb_61.y = zT_510;
    zT_512 = 65;
    zT_511.tag = zT_512;
    zT_511.payload.builtin_console_gotoxy._0 = nb_61;
    return zT_511;
    z_bb_56:
    bcc = inst.payload.builtin_console_set_color._0;
    nb_62 = bcc;
    zT_515 = c;
    zT_516 = nb_62.fg;
    zT_518 = zF_8B8DBDFB_maybeR(zT_515, zT_516);
    nb_62.fg = zT_518;
    zT_519 = c;
    zT_520 = nb_62.bg;
    zT_522 = zF_8B8DBDFB_maybeR(zT_519, zT_520);
    nb_62.bg = zT_522;
    zT_524 = 66;
    zT_523.tag = zT_524;
    zT_523.payload.builtin_console_set_color._0 = nb_62;
    return zT_523;
    z_bb_57:
    ct = inst.payload.check_trap._0;
    nc_63 = ct;
    zT_527 = c;
    zT_528 = nc_63.cond;
    zT_530 = zF_8B8DBDFB_maybeR(zT_527, zT_528);
    nc_63.cond = zT_530;
    zT_532 = 71;
    zT_531.tag = zT_532;
    zT_531.payload.check_trap._0 = nc_63;
    return zT_531;
    z_bb_58:
    return inst;
    { zT_6BA597BC_LirInst zT_ret_void = {0}; return zT_ret_void; }
}

/* copyPropagate */
unsigned char zF_4AE99A73_copyPropagate(zT_5EDE903E_Ctx* c) {
    unsigned int zT_2;
    unsigned char zT_4;
    zT_5EDE903E_Ctx* zT_7;
    unsigned char zT_9;
    unsigned int zT_11;
    zT_BBC23664_LirFunction* zT_12;
    zT_1CF28CA3_BasicBlockArrayList zT_13;
    unsigned int zT_14;
    zT_BBC23664_LirFunction* zT_17;
    zT_1CF28CA3_BasicBlockArrayList zT_18;
    zT_88A68B1A_BasicBlock* zT_19;
    zT_88A68B1A_BasicBlock* zT_20;
    unsigned int zT_22;
    zT_DAE4631D_LirInstArrayList zT_23;
    unsigned int zT_24;
    zT_DAE4631D_LirInstArrayList zT_27;
    zT_6BA597BC_LirInst* zT_28;
    zT_6BA597BC_LirInst zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_55;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned char* zT_62;
    unsigned char zT_63;
    unsigned char* zT_66;
    unsigned char zT_67;
    unsigned char* zT_70;
    unsigned char zT_71;
    unsigned char* zT_74;
    unsigned char zT_75;
    unsigned int* zT_78;
    unsigned int zT_79;
    unsigned int* zT_82;
    unsigned int zT_83;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned char* zT_90;
    unsigned char zT_91;
    unsigned int* zT_94;
    unsigned int zT_95;
    unsigned char* zT_98;
    unsigned char zT_99;
    unsigned int* zT_102;
    unsigned int zT_103;
    unsigned int* zT_106;
    unsigned int zT_107;
    unsigned int* zT_111;
    unsigned int zT_112;
    unsigned int* zT_114;
    unsigned int zT_115;
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int zT_118;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type* zT_123;
    unsigned int zT_124;
    zT_D155D06D_Type zT_125;
    zT_33EF6BFB_TypeKind zT_126;
    unsigned char zT_128 = 0;
    unsigned int* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int* zT_136;
    unsigned int zT_137;
    zT_6BA597BC_LirInst zT_138;
    unsigned int zT_140;
    zT_DAE4631D_LirInstArrayList zT_141;
    zT_6BA597BC_LirInst* zT_142;
    unsigned char zT_143;
    unsigned int zT_145;
    unsigned int zT_147;
    unsigned char zT_150;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_162;
    unsigned char zT_165;
    unsigned int zT_166;
    unsigned char zT_168;
    unsigned int* zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned char zT_177;
    unsigned int zT_180;
    unsigned int* zT_181;
    unsigned int zT_182;
    unsigned int zT_184;
    unsigned int zT_186;
    zT_BBC23664_LirFunction* zT_187;
    zT_1CF28CA3_BasicBlockArrayList zT_188;
    unsigned int zT_189;
    zT_BBC23664_LirFunction* zT_192;
    zT_1CF28CA3_BasicBlockArrayList zT_193;
    zT_88A68B1A_BasicBlock* zT_194;
    zT_88A68B1A_BasicBlock* zT_195;
    unsigned int zT_197;
    zT_DAE4631D_LirInstArrayList zT_198;
    unsigned int zT_199;
    zT_5EDE903E_Ctx* zT_201;
    zT_6BA597BC_LirInst zT_202;
    zT_DAE4631D_LirInstArrayList zT_203;
    zT_6BA597BC_LirInst* zT_204;
    zT_6BA597BC_LirInst zT_205;
    zT_6BA597BC_LirInst zT_206 = {0};
    zT_DAE4631D_LirInstArrayList zT_207;
    zT_6BA597BC_LirInst* zT_208;
    unsigned int zT_210;
    unsigned int zT_212;
    unsigned int zT_214;
    unsigned int iter;
    unsigned char changed_total;
    unsigned char changed;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    zT_935FEA89_anon_77041 a;
    unsigned int dst;
    unsigned int src;
    unsigned int dp;
    unsigned int sp;
    unsigned int dpos;
    unsigned int spos;
    unsigned int dt;
    unsigned int st;
    zT_D155D06D_Type dty;
    unsigned int t;
    unsigned int cur;
    unsigned int rbi;
    unsigned int guard;
    unsigned int next;
    unsigned int rii;
    zT_2 = 0;
    iter = zT_2;
    zT_4 = 0;
    changed_total = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(iter < zG_8D933C0A_kCopyPropMaxIter)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = c;
    zF_6A60FAEB_scanAll(zT_7);
    zT_9 = 0;
    changed = zT_9;
    zT_11 = 0;
    bi = zT_11;
    goto z_bb_5;
    z_bb_3:
    return changed_total;
    z_bb_4:
    zT_214 = iter + (unsigned int)(1);
    iter = zT_214;
    goto z_bb_1;
    z_bb_5:
    zT_12 = c->lir_fn;
    zT_13 = zT_12->blocks;
    zT_14 = zT_13.len;
    if ((unsigned char)(bi < zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = c->lir_fn;
    zT_18 = zT_17->blocks;
    zT_19 = zT_18.items;
    zT_20 = zT_19 + bi;
    bb = zT_20;
    zT_22 = 0;
    ii = zT_22;
    goto z_bb_9;
    z_bb_7:
    if ((unsigned char)(changed == (unsigned char)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_8:
    zT_147 = bi + (unsigned int)(1);
    bi = zT_147;
    goto z_bb_5;
    z_bb_9:
    zT_23 = bb->insts;
    zT_24 = zT_23.len;
    if ((unsigned char)(ii < zT_24)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_27 = bb->insts;
    zT_28 = zT_27.items;
    zT_29 = zT_28[ii];
    inst = zT_29;
    zT_30 = inst.tag;
switch (zT_30) {
case 2: goto z_bb_13;
default: goto z_bb_14;
}
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_145 = ii + (unsigned int)(1);
    ii = zT_145;
    goto z_bb_9;
    z_bb_13:
    a = inst.payload.assign._0;
    zT_32 = a.name_id;
    if ((unsigned char)(zT_32 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    goto z_bb_12;
    z_bb_18:
    zT_36 = a.dst;
    dst = zT_36;
    zT_38 = a.src;
    src = zT_38;
    if ((unsigned char)(dst == src)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_12;
    z_bb_20:
    zT_40 = c->max_temp;
    if ((unsigned char)(dst >= zT_40)) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_43 = c->max_temp;
    zT_42 = src >= zT_43;
    goto z_bb_23;
    z_bb_22:
    zT_42 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_42) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    goto z_bb_12;
    z_bb_25:
    zT_46 = c->t2p;
    zT_47 = (unsigned int)dst;
    zT_48 = zT_46[zT_47];
    dp = zT_48;
    zT_50 = c->t2p;
    zT_51 = (unsigned int)src;
    zT_52 = zT_50[zT_51];
    sp = zT_52;
    if ((unsigned char)(dp == (unsigned int)(4294967295u))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_55 = sp == (unsigned int)(4294967295u);
    goto z_bb_28;
    z_bb_27:
    zT_55 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_55) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    goto z_bb_12;
    z_bb_30:
    zT_59 = (unsigned int)dp;
    dpos = zT_59;
    zT_61 = (unsigned int)sp;
    spos = zT_61;
    zT_62 = c->ex;
    zT_63 = zT_62[dpos];
    if ((unsigned char)(zT_63 != (unsigned char)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_12;
    z_bb_32:
    zT_66 = c->ex;
    zT_67 = zT_66[spos];
    if ((unsigned char)(zT_67 != (unsigned char)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    goto z_bb_12;
    z_bb_34:
    zT_70 = c->at;
    zT_71 = zT_70[dpos];
    if ((unsigned char)(zT_71 != (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    goto z_bb_12;
    z_bb_36:
    zT_74 = c->at;
    zT_75 = zT_74[spos];
    if ((unsigned char)(zT_75 != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    goto z_bb_12;
    z_bb_38:
    zT_78 = c->wc;
    zT_79 = zT_78[dpos];
    if ((unsigned char)(zT_79 != (unsigned int)(1))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_12;
    z_bb_40:
    zT_82 = c->wc;
    zT_83 = zT_82[spos];
    if ((unsigned char)(zT_83 != (unsigned int)(1))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_12;
    z_bb_42:
    zT_86 = c->rc;
    zT_87 = zT_86[dpos];
    if ((unsigned char)(zT_87 != (unsigned int)(1))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    goto z_bb_12;
    z_bb_44:
    zT_90 = c->rar;
    zT_91 = zT_90[dpos];
    if ((unsigned char)(zT_91 != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    goto z_bb_12;
    z_bb_46:
    zT_94 = c->rc;
    zT_95 = zT_94[spos];
    if ((unsigned char)(zT_95 != (unsigned int)(1))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_12;
    z_bb_48:
    zT_98 = c->dp;
    zT_99 = zT_98[spos];
    if ((unsigned char)(zT_99 != (unsigned char)(1))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_12;
    z_bb_50:
    zT_102 = c->rd_bb;
    zT_103 = zT_102[dpos];
    if ((unsigned char)(zT_103 != (unsigned int)((unsigned int)bi))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    goto z_bb_12;
    z_bb_52:
    zT_106 = c->rd_ii;
    zT_107 = zT_106[dpos];
    if ((unsigned char)(zT_107 <= (unsigned int)((unsigned int)ii))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    goto z_bb_12;
    z_bb_54:
    zT_111 = c->ttype;
    zT_112 = zT_111[dpos];
    dt = zT_112;
    zT_114 = c->ttype;
    zT_115 = zT_114[spos];
    st = zT_115;
    if ((unsigned char)(dt != st)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    goto z_bb_12;
    z_bb_56:
    zT_117 = c->reg;
    zT_118 = zT_117->types_len;
    if ((unsigned char)(dt >= (unsigned int)((unsigned int)zT_118))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    goto z_bb_12;
    z_bb_58:
    zT_122 = c->reg;
    zT_123 = zT_122->types_items;
    zT_124 = (unsigned int)dt;
    zT_125 = zT_123[zT_124];
    dty = zT_125;
    zT_126 = dty.kind;
    zT_128 = zF_B7E1584C_copyScalarKindOk(zT_126);
    if ((unsigned char)(zT_128 == (unsigned char)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    goto z_bb_12;
    z_bb_60:
    zT_131 = c->ren;
    zT_132 = (unsigned int)dst;
    zT_133 = zT_131[zT_132];
    if ((unsigned char)(zT_133 != (unsigned int)(4294967295u))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    goto z_bb_12;
    z_bb_62:
    zT_136 = c->ren;
    zT_137 = (unsigned int)dst;
    zT_136[zT_137] = src;
    zT_140 = 67;
    zT_138.tag = zT_140;
    zT_141 = bb->insts;
    zT_142 = zT_141.items;
    zT_142[ii] = zT_138;
    zT_143 = 1;
    changed = zT_143;
    goto z_bb_16;
    z_bb_63:
    goto z_bb_3;
    z_bb_64:
    zT_150 = 1;
    changed_total = zT_150;
    zT_152 = 0;
    t = zT_152;
    goto z_bb_65;
    z_bb_65:
    zT_153 = c->max_temp;
    if ((unsigned char)(t < zT_153)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_156 = c->ren;
    zT_157 = (unsigned int)t;
    zT_158 = zT_156[zT_157];
    cur = zT_158;
    if ((unsigned char)(cur == (unsigned int)(4294967295u))) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    zT_186 = 0;
    rbi = zT_186;
    goto z_bb_86;
    z_bb_68:
    zT_184 = t + (unsigned int)(1);
    t = zT_184;
    goto z_bb_65;
    z_bb_69:
    goto z_bb_68;
    z_bb_70:
    zT_162 = 0;
    guard = zT_162;
    goto z_bb_71;
    z_bb_71:
    if ((unsigned char)(cur != (unsigned int)(4294967295u))) goto z_bb_75; else goto z_bb_76;
    z_bb_72:
    zT_172 = c->ren;
    zT_173 = (unsigned int)cur;
    zT_174 = zT_172[zT_173];
    next = zT_174;
    if ((unsigned char)(next == (unsigned int)(4294967295u))) goto z_bb_82; else goto z_bb_81;
    z_bb_73:
    zT_181 = c->ren;
    zT_182 = (unsigned int)t;
    zT_181[zT_182] = cur;
    goto z_bb_68;
    z_bb_74:
    zT_180 = guard + (unsigned int)(1);
    guard = zT_180;
    goto z_bb_71;
    z_bb_75:
    zT_166 = c->max_temp;
    zT_165 = cur < zT_166;
    goto z_bb_77;
    z_bb_76:
    zT_165 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_165) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_168 = guard < zG_8D933C0A_kCopyPropMaxIter;
    goto z_bb_80;
    z_bb_79:
    zT_168 = 0;
    goto z_bb_80;
    z_bb_80:
    if (zT_168) goto z_bb_72; else goto z_bb_73;
    z_bb_81:
    zT_177 = next == cur;
    goto z_bb_83;
    z_bb_82:
    zT_177 = 1;
    goto z_bb_83;
    z_bb_83:
    if (zT_177) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    goto z_bb_73;
    z_bb_85:
    cur = next;
    goto z_bb_74;
    z_bb_86:
    zT_187 = c->lir_fn;
    zT_188 = zT_187->blocks;
    zT_189 = zT_188.len;
    if ((unsigned char)(rbi < zT_189)) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_192 = c->lir_fn;
    zT_193 = zT_192->blocks;
    zT_194 = zT_193.items;
    zT_195 = zT_194 + rbi;
    bb = zT_195;
    zT_197 = 0;
    rii = zT_197;
    goto z_bb_90;
    z_bb_88:
    goto z_bb_4;
    z_bb_89:
    zT_212 = rbi + (unsigned int)(1);
    rbi = zT_212;
    goto z_bb_86;
    z_bb_90:
    zT_198 = bb->insts;
    zT_199 = zT_198.len;
    if ((unsigned char)(rii < zT_199)) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_201 = c;
    zT_203 = bb->insts;
    zT_204 = zT_203.items;
    zT_205 = zT_204[rii];
    zT_202 = zT_205;
    zT_206 = zF_0E3ACCAD_rewriteInstOperands(zT_201, zT_202);
    zT_207 = bb->insts;
    zT_208 = zT_207.items;
    zT_208[rii] = zT_206;
    goto z_bb_93;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_210 = rii + (unsigned int)(1);
    rii = zT_210;
    goto z_bb_90;
}

/* retargetDefResult */
zT_6BA597BC_LirInst zF_015226D9_retargetDefResult(zT_6BA597BC_LirInst inst, unsigned int newr, unsigned char* ok) {
    unsigned int zT_3;
    zT_6BA597BC_LirInst zT_6;
    unsigned int zT_7;
    zT_6BA597BC_LirInst zT_10;
    unsigned int zT_11;
    zT_6BA597BC_LirInst zT_14;
    unsigned int zT_15;
    zT_6BA597BC_LirInst zT_18;
    unsigned int zT_19;
    zT_6BA597BC_LirInst zT_22;
    unsigned int zT_23;
    zT_6BA597BC_LirInst zT_26;
    unsigned int zT_27;
    zT_6BA597BC_LirInst zT_30;
    unsigned int zT_31;
    zT_6BA597BC_LirInst zT_34;
    unsigned int zT_35;
    zT_6BA597BC_LirInst zT_38;
    unsigned int zT_39;
    zT_6BA597BC_LirInst zT_42;
    unsigned int zT_43;
    zT_6BA597BC_LirInst zT_46;
    unsigned int zT_47;
    zT_6BA597BC_LirInst zT_50;
    unsigned int zT_51;
    zT_6BA597BC_LirInst zT_54;
    unsigned int zT_55;
    zT_6BA597BC_LirInst zT_58;
    unsigned int zT_59;
    zT_6BA597BC_LirInst zT_62;
    unsigned int zT_63;
    zT_6BA597BC_LirInst zT_66;
    unsigned int zT_67;
    zT_6BA597BC_LirInst zT_70;
    unsigned int zT_71;
    zT_6BA597BC_LirInst zT_74;
    unsigned int zT_75;
    zT_6BA597BC_LirInst zT_78;
    unsigned int zT_79;
    zT_6BA597BC_LirInst zT_82;
    unsigned int zT_83;
    zT_6BA597BC_LirInst zT_86;
    unsigned int zT_87;
    zT_6BA597BC_LirInst zT_90;
    unsigned int zT_91;
    zT_6BA597BC_LirInst zT_94;
    unsigned int zT_95;
    zT_6BA597BC_LirInst zT_98;
    unsigned int zT_99;
    zT_6BA597BC_LirInst zT_102;
    unsigned int zT_103;
    zT_6BA597BC_LirInst zT_106;
    unsigned int zT_107;
    zT_6BA597BC_LirInst zT_110;
    unsigned int zT_111;
    zT_6BA597BC_LirInst zT_114;
    unsigned int zT_115;
    zT_6BA597BC_LirInst zT_118;
    unsigned int zT_119;
    zT_6BA597BC_LirInst zT_122;
    unsigned int zT_123;
    zT_6BA597BC_LirInst zT_126;
    unsigned int zT_127;
    zT_6BA597BC_LirInst zT_130;
    unsigned int zT_131;
    zT_6BA597BC_LirInst zT_134;
    unsigned int zT_135;
    zT_6BA597BC_LirInst zT_138;
    unsigned int zT_139;
    zT_6BA597BC_LirInst zT_142;
    unsigned int zT_143;
    zT_6BA597BC_LirInst zT_146;
    unsigned int zT_147;
    zT_6BA597BC_LirInst zT_150;
    unsigned int zT_151;
    zT_6BA597BC_LirInst zT_154;
    unsigned int zT_155;
    zT_176BF348_anon_77099 b;
    zT_176BF348_anon_77099 nb;
    zT_11ECC358_anon_77107 u;
    zT_11ECC358_anon_77107 nu;
    zT_A7CB4D30_anon_77327 ic;
    zT_A7CB4D30_anon_77327 ni;
    zT_ABC914E5_anon_77333 fc;
    zT_ABC914E5_anon_77333 nf;
    zT_B1C91E57_anon_77339 sc;
    zT_B1C91E57_anon_77339 ns;
    zT_A3C6C9B6_anon_77343 nc;
    zT_A3C6C9B6_anon_77343 nn;
    zT_A9C6D328_anon_77349 sn;
    zT_A9C6D328_anon_77349 ns_1;
    zT_39C3E441_anon_77355 bc;
    zT_39C3E441_anon_77355 nb_2;
    zT_35C19F5E_anon_77361 uc;
    zT_35C19F5E_anon_77361 nu_3;
    zT_31BF5A7B_anon_77371 ec;
    zT_31BF5A7B_anon_77371 ne;
    zT_4F25184D_anon_77283 ic_4;
    zT_4F25184D_anon_77283 ni_5;
    zT_CC8B6D3F_anon_77595 ic_6;
    zT_CC8B6D3F_anon_77595 ni_7;
    zT_879E24B5_anon_77607 ww;
    zT_879E24B5_anon_77607 nw;
    zT_51275A0A_anon_77291 fc_8;
    zT_51275A0A_anon_77291 nf_9;
    zT_49274D72_anon_77299 pc;
    zT_49274D72_anon_77299 np;
    zT_37D0AD0E_anon_77307 itf;
    zT_37D0AD0E_anon_77307 nt;
    zT_ADCB56A2_anon_77321 itp;
    zT_ADCB56A2_anon_77321 nt_10;
    zT_B3CD9EAB_anon_77313 pti;
    zT_B3CD9EAB_anon_77313 nt_11;
    zT_39363ECC_anon_77275 ms;
    zT_39363ECC_anon_77275 nm;
    zT_11E8462A_anon_77167 a;
    zT_11E8462A_anon_77167 na;
    zT_03E5F189_anon_77175 a_12;
    zT_03E5F189_anon_77175 na_13;
    zT_BF3B8EEC_anon_77213 fr;
    zT_BF3B8EEC_anon_77213 nf_14;
    zT_860101AC_anon_77183 w;
    zT_860101AC_anon_77183 nw_15;
    zT_C540158C_anon_77239 w_16;
    zT_C540158C_anon_77239 nw_17;
    zT_CB2ED5DD_anon_77247 w_18;
    zT_CB2ED5DD_anon_77247 nw_19;
    zT_C93B9EAA_anon_77219 u_20;
    zT_C93B9EAA_anon_77219 nu_21;
    zT_E0AE1EFD_anon_77575 u_22;
    zT_E0AE1EFD_anon_77575 nu_23;
    zT_CD3DE38D_anon_77225 u_24;
    zT_CD3DE38D_anon_77225 nu_25;
    zT_CD402224_anon_77231 ch;
    zT_CD402224_anon_77231 nc_26;
    zT_4731D7A8_anon_77253 u_27;
    zT_4731D7A8_anon_77253 nu_28;
    zT_4131CE36_anon_77259 u_29;
    zT_4131CE36_anon_77259 nu_30;
    zT_4D341FB1_anon_77265 ch_31;
    zT_4D341FB1_anon_77265 nc_32;
    zT_7FE0A48F_anon_77155 l;
    zT_7FE0A48F_anon_77155 nl;
    zT_81F1F0D6_anon_77127 lf;
    zT_81F1F0D6_anon_77127 nl_33;
    zT_E0BE7755_anon_77467 lb;
    zT_E0BE7755_anon_77467 nl_34;
    zT_87E2EFBE_anon_77149 li;
    zT_87E2EFBE_anon_77149 nl_35;
    zT_37BF63ED_anon_77377 ll;
    zT_37BF63ED_anon_77377 nl_36;
    zT_A5BA00E9_anon_77391 lg;
    zT_A5BA00E9_anon_77391 nl_37;
    zT_3 = inst.tag;
switch (zT_3) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 46: goto z_bb_5;
case 47: goto z_bb_6;
case 48: goto z_bb_7;
case 49: goto z_bb_8;
case 50: goto z_bb_9;
case 51: goto z_bb_10;
case 38: goto z_bb_11;
case 80: goto z_bb_12;
case 81: goto z_bb_13;
case 39: goto z_bb_14;
case 40: goto z_bb_15;
case 41: goto z_bb_16;
case 43: goto z_bb_17;
case 42: goto z_bb_18;
case 37: goto z_bb_19;
case 20: goto z_bb_20;
case 21: goto z_bb_21;
case 28: goto z_bb_22;
case 22: goto z_bb_23;
case 32: goto z_bb_24;
case 33: goto z_bb_25;
case 29: goto z_bb_26;
case 78: goto z_bb_27;
case 30: goto z_bb_28;
case 31: goto z_bb_29;
case 34: goto z_bb_30;
case 35: goto z_bb_31;
case 36: goto z_bb_32;
case 18: goto z_bb_33;
case 15: goto z_bb_34;
case 68: goto z_bb_35;
case 17: goto z_bb_36;
case 52: goto z_bb_37;
case 54: goto z_bb_38;
default: goto z_bb_39;
}
    z_bb_1:
    b = inst.payload.binary._0;
    nb = b;
    nb.result = newr;
    zT_7 = 12;
    zT_6.tag = zT_7;
    zT_6.payload.binary._0 = nb;
    return zT_6;
    z_bb_2:
    u = inst.payload.unary._0;
    nu = u;
    nu.result = newr;
    zT_11 = 13;
    zT_10.tag = zT_11;
    zT_10.payload.unary._0 = nu;
    return zT_10;
    z_bb_3:
    ic = inst.payload.int_const._0;
    ni = ic;
    ni.result = newr;
    zT_15 = 44;
    zT_14.tag = zT_15;
    zT_14.payload.int_const._0 = ni;
    return zT_14;
    z_bb_4:
    fc = inst.payload.float_const._0;
    nf = fc;
    nf.result = newr;
    zT_19 = 45;
    zT_18.tag = zT_19;
    zT_18.payload.float_const._0 = nf;
    return zT_18;
    z_bb_5:
    sc = inst.payload.string_const._0;
    ns = sc;
    ns.result = newr;
    zT_23 = 46;
    zT_22.tag = zT_23;
    zT_22.payload.string_const._0 = ns;
    return zT_22;
    z_bb_6:
    nc = inst.payload.null_const._0;
    nn = nc;
    nn.result = newr;
    zT_27 = 47;
    zT_26.tag = zT_27;
    zT_26.payload.null_const._0 = nn;
    return zT_26;
    z_bb_7:
    sn = inst.payload.set_optional_null._0;
    ns_1 = sn;
    ns_1.result = newr;
    zT_31 = 48;
    zT_30.tag = zT_31;
    zT_30.payload.set_optional_null._0 = ns_1;
    return zT_30;
    z_bb_8:
    bc = inst.payload.bool_const._0;
    nb_2 = bc;
    nb_2.result = newr;
    zT_35 = 49;
    zT_34.tag = zT_35;
    zT_34.payload.bool_const._0 = nb_2;
    return zT_34;
    z_bb_9:
    uc = inst.payload.undefined_const._0;
    nu_3 = uc;
    nu_3.result = newr;
    zT_39 = 50;
    zT_38.tag = zT_39;
    zT_38.payload.undefined_const._0 = nu_3;
    return zT_38;
    z_bb_10:
    ec = inst.payload.enum_const._0;
    ne = ec;
    ne.result = newr;
    zT_43 = 51;
    zT_42.tag = zT_43;
    zT_42.payload.enum_const._0 = ne;
    return zT_42;
    z_bb_11:
    ic_4 = inst.payload.int_cast._0;
    ni_5 = ic_4;
    ni_5.result = newr;
    zT_47 = 38;
    zT_46.tag = zT_47;
    zT_46.payload.int_cast._0 = ni_5;
    return zT_46;
    z_bb_12:
    ic_6 = inst.payload.int_cast_checked._0;
    ni_7 = ic_6;
    ni_7.result = newr;
    zT_51 = 80;
    zT_50.tag = zT_51;
    zT_50.payload.int_cast_checked._0 = ni_7;
    return zT_50;
    z_bb_13:
    ww = inst.payload.width_wrap._0;
    nw = ww;
    nw.result = newr;
    nw.value = newr;
    zT_55 = 81;
    zT_54.tag = zT_55;
    zT_54.payload.width_wrap._0 = nw;
    return zT_54;
    z_bb_14:
    fc_8 = inst.payload.float_cast._0;
    nf_9 = fc_8;
    nf_9.result = newr;
    zT_59 = 39;
    zT_58.tag = zT_59;
    zT_58.payload.float_cast._0 = nf_9;
    return zT_58;
    z_bb_15:
    pc = inst.payload.ptr_cast._0;
    np = pc;
    np.result = newr;
    zT_63 = 40;
    zT_62.tag = zT_63;
    zT_62.payload.ptr_cast._0 = np;
    return zT_62;
    z_bb_16:
    itf = inst.payload.int_to_float._0;
    nt = itf;
    nt.result = newr;
    zT_67 = 41;
    zT_66.tag = zT_67;
    zT_66.payload.int_to_float._0 = nt;
    return zT_66;
    z_bb_17:
    itp = inst.payload.int_to_ptr._0;
    nt_10 = itp;
    nt_10.result = newr;
    zT_71 = 43;
    zT_70.tag = zT_71;
    zT_70.payload.int_to_ptr._0 = nt_10;
    return zT_70;
    z_bb_18:
    pti = inst.payload.ptr_to_int._0;
    nt_11 = pti;
    nt_11.result = newr;
    zT_75 = 42;
    zT_74.tag = zT_75;
    zT_74.payload.ptr_to_int._0 = nt_11;
    return zT_74;
    z_bb_19:
    ms = inst.payload.make_slice._0;
    nm = ms;
    nm.result = newr;
    zT_79 = 37;
    zT_78.tag = zT_79;
    zT_78.payload.make_slice._0 = nm;
    return zT_78;
    z_bb_20:
    a = inst.payload.addr_of._0;
    na = a;
    na.result = newr;
    zT_83 = 20;
    zT_82.tag = zT_83;
    zT_82.payload.addr_of._0 = na;
    return zT_82;
    z_bb_21:
    a_12 = inst.payload.addr_of_field._0;
    na_13 = a_12;
    na_13.result = newr;
    zT_87 = 21;
    zT_86.tag = zT_87;
    zT_86.payload.addr_of_field._0 = na_13;
    return zT_86;
    z_bb_22:
    fr = inst.payload.func_ref._0;
    nf_14 = fr;
    nf_14.result = newr;
    zT_91 = 28;
    zT_90.tag = zT_91;
    zT_90.payload.func_ref._0 = nf_14;
    return zT_90;
    z_bb_23:
    w = inst.payload.wrap_optional._0;
    nw_15 = w;
    nw_15.result = newr;
    zT_95 = 22;
    zT_94.tag = zT_95;
    zT_94.payload.wrap_optional._0 = nw_15;
    return zT_94;
    z_bb_24:
    w_16 = inst.payload.wrap_error_ok._0;
    nw_17 = w_16;
    nw_17.result = newr;
    zT_99 = 32;
    zT_98.tag = zT_99;
    zT_98.payload.wrap_error_ok._0 = nw_17;
    return zT_98;
    z_bb_25:
    w_18 = inst.payload.wrap_error_err._0;
    nw_19 = w_18;
    nw_19.result = newr;
    zT_103 = 33;
    zT_102.tag = zT_103;
    zT_102.payload.wrap_error_err._0 = nw_19;
    return zT_102;
    z_bb_26:
    u_20 = inst.payload.unwrap_optional._0;
    nu_21 = u_20;
    nu_21.result = newr;
    zT_107 = 29;
    zT_106.tag = zT_107;
    zT_106.payload.unwrap_optional._0 = nu_21;
    return zT_106;
    z_bb_27:
    u_22 = inst.payload.unwrap_optional_checked._0;
    nu_23 = u_22;
    nu_23.result = newr;
    zT_111 = 78;
    zT_110.tag = zT_111;
    zT_110.payload.unwrap_optional_checked._0 = nu_23;
    return zT_110;
    z_bb_28:
    u_24 = inst.payload.unwrap_optional_abi._0;
    nu_25 = u_24;
    nu_25.result = newr;
    zT_115 = 30;
    zT_114.tag = zT_115;
    zT_114.payload.unwrap_optional_abi._0 = nu_25;
    return zT_114;
    z_bb_29:
    ch = inst.payload.check_optional._0;
    nc_26 = ch;
    nc_26.result = newr;
    zT_119 = 31;
    zT_118.tag = zT_119;
    zT_118.payload.check_optional._0 = nc_26;
    return zT_118;
    z_bb_30:
    u_27 = inst.payload.unwrap_error_payload._0;
    nu_28 = u_27;
    nu_28.result = newr;
    zT_123 = 34;
    zT_122.tag = zT_123;
    zT_122.payload.unwrap_error_payload._0 = nu_28;
    return zT_122;
    z_bb_31:
    u_29 = inst.payload.unwrap_error_code._0;
    nu_30 = u_29;
    nu_30.result = newr;
    zT_127 = 35;
    zT_126.tag = zT_127;
    zT_126.payload.unwrap_error_code._0 = nu_30;
    return zT_126;
    z_bb_32:
    ch_31 = inst.payload.check_error._0;
    nc_32 = ch_31;
    nc_32.result = newr;
    zT_131 = 36;
    zT_130.tag = zT_131;
    zT_130.payload.check_error._0 = nc_32;
    return zT_130;
    z_bb_33:
    l = inst.payload.load._0;
    nl = l;
    nl.result = newr;
    zT_135 = 18;
    zT_134.tag = zT_135;
    zT_134.payload.load._0 = nl;
    return zT_134;
    z_bb_34:
    lf = inst.payload.load_field._0;
    nl_33 = lf;
    nl_33.result = newr;
    zT_139 = 15;
    zT_138.tag = zT_139;
    zT_138.payload.load_field._0 = nl_33;
    return zT_138;
    z_bb_35:
    lb = inst.payload.load_bitfield._0;
    nl_34 = lb;
    nl_34.result = newr;
    zT_143 = 68;
    zT_142.tag = zT_143;
    zT_142.payload.load_bitfield._0 = nl_34;
    return zT_142;
    z_bb_36:
    li = inst.payload.load_index._0;
    nl_35 = li;
    nl_35.result = newr;
    zT_147 = 17;
    zT_146.tag = zT_147;
    zT_146.payload.load_index._0 = nl_35;
    return zT_146;
    z_bb_37:
    ll = inst.payload.load_local._0;
    nl_36 = ll;
    nl_36.result = newr;
    zT_151 = 52;
    zT_150.tag = zT_151;
    zT_150.payload.load_local._0 = nl_36;
    return zT_150;
    z_bb_38:
    lg = inst.payload.load_global._0;
    nl_37 = lg;
    nl_37.result = newr;
    zT_155 = 54;
    zT_154.tag = zT_155;
    zT_154.payload.load_global._0 = nl_37;
    return zT_154;
    z_bb_39:
    *ok = (unsigned char)(0);
    return inst;
    { zT_6BA597BC_LirInst zT_ret_void = {0}; return zT_ret_void; }
}

/* coalesceArgCopies */
unsigned char zF_E96AD22F_coalesceArgCopies(zT_5EDE903E_Ctx* c) {
    unsigned int zT_2;
    unsigned char zT_4;
    zT_5EDE903E_Ctx* zT_7;
    unsigned char zT_9;
    unsigned int zT_11;
    zT_BBC23664_LirFunction* zT_12;
    zT_1CF28CA3_BasicBlockArrayList zT_13;
    unsigned int zT_14;
    zT_BBC23664_LirFunction* zT_17;
    zT_1CF28CA3_BasicBlockArrayList zT_18;
    zT_88A68B1A_BasicBlock* zT_19;
    zT_88A68B1A_BasicBlock* zT_20;
    unsigned int zT_22;
    zT_DAE4631D_LirInstArrayList zT_23;
    unsigned int zT_24;
    zT_DAE4631D_LirInstArrayList zT_27;
    zT_6BA597BC_LirInst* zT_28;
    zT_6BA597BC_LirInst zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_55;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned char* zT_62;
    unsigned char zT_63;
    unsigned char* zT_66;
    unsigned char zT_67;
    unsigned char* zT_70;
    unsigned char zT_71;
    unsigned char* zT_74;
    unsigned char zT_75;
    unsigned char* zT_78;
    unsigned char zT_79;
    unsigned int* zT_82;
    unsigned int zT_83;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned int* zT_90;
    unsigned int zT_91;
    unsigned int* zT_94;
    unsigned int zT_95;
    unsigned char* zT_98;
    unsigned char zT_99;
    unsigned int* zT_102;
    unsigned int zT_103;
    unsigned int* zT_106;
    unsigned int zT_107;
    unsigned int* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned char zT_120;
    unsigned int* zT_128;
    unsigned int zT_129;
    unsigned int* zT_131;
    unsigned int zT_132;
    zT_338B7C76_TypeRegistry* zT_134;
    unsigned int zT_135;
    zT_338B7C76_TypeRegistry* zT_139;
    zT_D155D06D_Type* zT_140;
    unsigned int zT_141;
    zT_D155D06D_Type zT_142;
    zT_33EF6BFB_TypeKind zT_143;
    unsigned char zT_145 = 0;
    zT_DAE4631D_LirInstArrayList zT_149;
    zT_6BA597BC_LirInst* zT_150;
    unsigned int zT_151;
    zT_6BA597BC_LirInst zT_152;
    unsigned char zT_154;
    zT_6BA597BC_LirInst zT_156;
    unsigned int zT_157;
    unsigned char* zT_158;
    zT_6BA597BC_LirInst zT_160 = {0};
    zT_DAE4631D_LirInstArrayList zT_163;
    zT_6BA597BC_LirInst* zT_164;
    unsigned int zT_165;
    zT_6BA597BC_LirInst zT_166;
    unsigned int zT_168;
    zT_DAE4631D_LirInstArrayList zT_169;
    zT_6BA597BC_LirInst* zT_170;
    unsigned char zT_171;
    unsigned int zT_173;
    unsigned int zT_175;
    unsigned char zT_178;
    unsigned int zT_180;
    unsigned int iter;
    unsigned char changed_total;
    unsigned char changed;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    zT_935FEA89_anon_77041 a;
    unsigned int dst;
    unsigned int src;
    unsigned int dp;
    unsigned int sp;
    unsigned int dpos;
    unsigned int spos;
    unsigned int pbb;
    unsigned int pii;
    unsigned int dt;
    unsigned int st;
    zT_D155D06D_Type dty;
    zT_6BA597BC_LirInst pinst;
    unsigned char pok;
    zT_6BA597BC_LirInst npinst;
    zT_2 = 0;
    iter = zT_2;
    zT_4 = 0;
    changed_total = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(iter < zG_8D933C0A_kCopyPropMaxIter)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = c;
    zF_6A60FAEB_scanAll(zT_7);
    zT_9 = 0;
    changed = zT_9;
    zT_11 = 0;
    bi = zT_11;
    goto z_bb_5;
    z_bb_3:
    return changed_total;
    z_bb_4:
    zT_180 = iter + (unsigned int)(1);
    iter = zT_180;
    goto z_bb_1;
    z_bb_5:
    zT_12 = c->lir_fn;
    zT_13 = zT_12->blocks;
    zT_14 = zT_13.len;
    if ((unsigned char)(bi < zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = c->lir_fn;
    zT_18 = zT_17->blocks;
    zT_19 = zT_18.items;
    zT_20 = zT_19 + bi;
    bb = zT_20;
    zT_22 = 0;
    ii = zT_22;
    goto z_bb_9;
    z_bb_7:
    if ((unsigned char)(changed == (unsigned char)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_8:
    zT_175 = bi + (unsigned int)(1);
    bi = zT_175;
    goto z_bb_5;
    z_bb_9:
    zT_23 = bb->insts;
    zT_24 = zT_23.len;
    if ((unsigned char)(ii < zT_24)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_27 = bb->insts;
    zT_28 = zT_27.items;
    zT_29 = zT_28[ii];
    inst = zT_29;
    zT_30 = inst.tag;
switch (zT_30) {
case 2: goto z_bb_13;
default: goto z_bb_14;
}
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_173 = ii + (unsigned int)(1);
    ii = zT_173;
    goto z_bb_9;
    z_bb_13:
    a = inst.payload.assign._0;
    zT_32 = a.name_id;
    if ((unsigned char)(zT_32 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    goto z_bb_12;
    z_bb_18:
    zT_36 = a.dst;
    dst = zT_36;
    zT_38 = a.src;
    src = zT_38;
    if ((unsigned char)(dst == src)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_12;
    z_bb_20:
    zT_40 = c->max_temp;
    if ((unsigned char)(dst >= zT_40)) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_43 = c->max_temp;
    zT_42 = src >= zT_43;
    goto z_bb_23;
    z_bb_22:
    zT_42 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_42) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    goto z_bb_12;
    z_bb_25:
    zT_46 = c->t2p;
    zT_47 = (unsigned int)dst;
    zT_48 = zT_46[zT_47];
    dp = zT_48;
    zT_50 = c->t2p;
    zT_51 = (unsigned int)src;
    zT_52 = zT_50[zT_51];
    sp = zT_52;
    if ((unsigned char)(dp == (unsigned int)(4294967295u))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_55 = sp == (unsigned int)(4294967295u);
    goto z_bb_28;
    z_bb_27:
    zT_55 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_55) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    goto z_bb_12;
    z_bb_30:
    zT_59 = (unsigned int)dp;
    dpos = zT_59;
    zT_61 = (unsigned int)sp;
    spos = zT_61;
    zT_62 = c->rar;
    zT_63 = zT_62[dpos];
    if ((unsigned char)(zT_63 == (unsigned char)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_12;
    z_bb_32:
    zT_66 = c->ex;
    zT_67 = zT_66[dpos];
    if ((unsigned char)(zT_67 != (unsigned char)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    goto z_bb_12;
    z_bb_34:
    zT_70 = c->ex;
    zT_71 = zT_70[spos];
    if ((unsigned char)(zT_71 != (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    goto z_bb_12;
    z_bb_36:
    zT_74 = c->at;
    zT_75 = zT_74[dpos];
    if ((unsigned char)(zT_75 != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    goto z_bb_12;
    z_bb_38:
    zT_78 = c->at;
    zT_79 = zT_78[spos];
    if ((unsigned char)(zT_79 != (unsigned char)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_12;
    z_bb_40:
    zT_82 = c->wc;
    zT_83 = zT_82[dpos];
    if ((unsigned char)(zT_83 != (unsigned int)(1))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_12;
    z_bb_42:
    zT_86 = c->wc;
    zT_87 = zT_86[spos];
    if ((unsigned char)(zT_87 != (unsigned int)(1))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    goto z_bb_12;
    z_bb_44:
    zT_90 = c->rc;
    zT_91 = zT_90[dpos];
    if ((unsigned char)(zT_91 != (unsigned int)(1))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    goto z_bb_12;
    z_bb_46:
    zT_94 = c->rc;
    zT_95 = zT_94[spos];
    if ((unsigned char)(zT_95 != (unsigned int)(1))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_12;
    z_bb_48:
    zT_98 = c->dp;
    zT_99 = zT_98[spos];
    if ((unsigned char)(zT_99 != (unsigned char)(1))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_12;
    z_bb_50:
    zT_102 = c->rd_bb;
    zT_103 = zT_102[dpos];
    if ((unsigned char)(zT_103 != (unsigned int)((unsigned int)bi))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    goto z_bb_12;
    z_bb_52:
    zT_106 = c->rd_ii;
    zT_107 = zT_106[dpos];
    if ((unsigned char)(zT_107 <= (unsigned int)((unsigned int)ii))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    goto z_bb_12;
    z_bb_54:
    zT_111 = c->df_bb;
    zT_112 = (unsigned int)src;
    zT_113 = zT_111[zT_112];
    pbb = zT_113;
    zT_115 = c->df_ii;
    zT_116 = (unsigned int)src;
    zT_117 = zT_115[zT_116];
    pii = zT_117;
    if ((unsigned char)(pbb == (unsigned int)(4294967295u))) goto z_bb_56; else goto z_bb_55;
    z_bb_55:
    zT_120 = pii == (unsigned int)(4294967295u);
    goto z_bb_57;
    z_bb_56:
    zT_120 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_120) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    goto z_bb_12;
    z_bb_59:
    if ((unsigned char)(pbb != (unsigned int)((unsigned int)bi))) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    goto z_bb_12;
    z_bb_61:
    if ((unsigned char)(pii >= (unsigned int)((unsigned int)ii))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    goto z_bb_12;
    z_bb_63:
    zT_128 = c->ttype;
    zT_129 = zT_128[dpos];
    dt = zT_129;
    zT_131 = c->ttype;
    zT_132 = zT_131[spos];
    st = zT_132;
    if ((unsigned char)(dt != st)) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    goto z_bb_12;
    z_bb_65:
    zT_134 = c->reg;
    zT_135 = zT_134->types_len;
    if ((unsigned char)(dt >= (unsigned int)((unsigned int)zT_135))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    goto z_bb_12;
    z_bb_67:
    zT_139 = c->reg;
    zT_140 = zT_139->types_items;
    zT_141 = (unsigned int)dt;
    zT_142 = zT_140[zT_141];
    dty = zT_142;
    zT_143 = dty.kind;
    zT_145 = zF_B7E1584C_copyScalarKindOk(zT_143);
    if ((unsigned char)(zT_145 == (unsigned char)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    goto z_bb_12;
    z_bb_69:
    zT_149 = bb->insts;
    zT_150 = zT_149.items;
    zT_151 = (unsigned int)pii;
    zT_152 = zT_150[zT_151];
    pinst = zT_152;
    zT_154 = 1;
    pok = zT_154;
    zT_156 = pinst;
    zT_157 = dst;
    zT_158 = &pok;
    zT_160 = zF_015226D9_retargetDefResult(zT_156, zT_157, zT_158);
    npinst = zT_160;
    if ((unsigned char)(pok == (unsigned char)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    goto z_bb_12;
    z_bb_71:
    zT_163 = bb->insts;
    zT_164 = zT_163.items;
    zT_165 = (unsigned int)pii;
    zT_164[zT_165] = npinst;
    zT_168 = 67;
    zT_166.tag = zT_168;
    zT_169 = bb->insts;
    zT_170 = zT_169.items;
    zT_170[ii] = zT_166;
    zT_171 = 1;
    changed = zT_171;
    goto z_bb_16;
    z_bb_72:
    goto z_bb_3;
    z_bb_73:
    zT_178 = 1;
    changed_total = zT_178;
    goto z_bb_4;
}

/* coalesceJoinCopies */
unsigned char zF_99BE285B_coalesceJoinCopies(zT_5EDE903E_Ctx* c) {
    unsigned int zT_2;
    unsigned char zT_4;
    zT_5EDE903E_Ctx* zT_7;
    unsigned char zT_9;
    unsigned int zT_11;
    zT_BBC23664_LirFunction* zT_12;
    zT_1CF28CA3_BasicBlockArrayList zT_13;
    unsigned int zT_14;
    zT_BBC23664_LirFunction* zT_17;
    zT_1CF28CA3_BasicBlockArrayList zT_18;
    zT_88A68B1A_BasicBlock* zT_19;
    zT_88A68B1A_BasicBlock* zT_20;
    unsigned int zT_22;
    zT_DAE4631D_LirInstArrayList zT_23;
    unsigned int zT_24;
    zT_DAE4631D_LirInstArrayList zT_27;
    zT_6BA597BC_LirInst* zT_28;
    zT_6BA597BC_LirInst zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned char zT_42;
    unsigned int zT_43;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    unsigned char zT_55;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned char* zT_62;
    unsigned char zT_63;
    unsigned char* zT_66;
    unsigned char zT_67;
    unsigned char* zT_70;
    unsigned char zT_71;
    unsigned char* zT_74;
    unsigned char zT_75;
    unsigned char* zT_78;
    unsigned char zT_79;
    unsigned int* zT_82;
    unsigned int zT_83;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned char* zT_90;
    unsigned char zT_91;
    unsigned int* zT_94;
    unsigned int zT_95;
    unsigned int* zT_98;
    unsigned int zT_99;
    unsigned int zT_103;
    unsigned int zT_105;
    zT_DAE4631D_LirInstArrayList zT_106;
    unsigned int zT_107;
    zT_6BA597BC_LirInst zT_110;
    zT_BBC23664_LirFunction* zT_111;
    zT_DAE4631D_LirInstArrayList zT_112;
    zT_6BA597BC_LirInst* zT_113;
    zT_6BA597BC_LirInst zT_114;
    unsigned int zT_116 = 0;
    unsigned int zT_119;
    unsigned int zT_121;
    unsigned int* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    unsigned int* zT_129;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned char zT_134;
    unsigned int* zT_142;
    unsigned int zT_143;
    unsigned int* zT_145;
    unsigned int zT_146;
    zT_338B7C76_TypeRegistry* zT_148;
    unsigned int zT_149;
    zT_338B7C76_TypeRegistry* zT_153;
    zT_D155D06D_Type* zT_154;
    unsigned int zT_155;
    zT_D155D06D_Type zT_156;
    zT_33EF6BFB_TypeKind zT_157;
    unsigned char zT_159 = 0;
    zT_DAE4631D_LirInstArrayList zT_163;
    zT_6BA597BC_LirInst* zT_164;
    unsigned int zT_165;
    zT_6BA597BC_LirInst zT_166;
    unsigned char zT_168;
    zT_6BA597BC_LirInst zT_170;
    unsigned int zT_171;
    unsigned char* zT_172;
    zT_6BA597BC_LirInst zT_174 = {0};
    zT_DAE4631D_LirInstArrayList zT_177;
    zT_6BA597BC_LirInst* zT_178;
    unsigned int zT_179;
    zT_6BA597BC_LirInst zT_180;
    unsigned int zT_182;
    zT_DAE4631D_LirInstArrayList zT_183;
    zT_6BA597BC_LirInst* zT_184;
    unsigned char zT_185;
    unsigned int zT_187;
    unsigned int zT_189;
    unsigned char zT_192;
    unsigned int zT_194;
    unsigned int iter;
    unsigned char changed_total;
    unsigned char changed;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    zT_935FEA89_anon_77041 a;
    unsigned int dst;
    unsigned int src;
    unsigned int dp;
    unsigned int sp;
    unsigned int dpos;
    unsigned int spos;
    unsigned int di;
    unsigned int ddefs;
    unsigned int ri;
    unsigned int pbb;
    unsigned int pii;
    unsigned int dt;
    unsigned int st;
    zT_D155D06D_Type dty;
    zT_6BA597BC_LirInst pinst;
    unsigned char pok;
    zT_6BA597BC_LirInst npinst;
    zT_2 = 0;
    iter = zT_2;
    zT_4 = 0;
    changed_total = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(iter < zG_8D933C0A_kCopyPropMaxIter)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = c;
    zF_6A60FAEB_scanAll(zT_7);
    zT_9 = 0;
    changed = zT_9;
    zT_11 = 0;
    bi = zT_11;
    goto z_bb_5;
    z_bb_3:
    return changed_total;
    z_bb_4:
    zT_194 = iter + (unsigned int)(1);
    iter = zT_194;
    goto z_bb_1;
    z_bb_5:
    zT_12 = c->lir_fn;
    zT_13 = zT_12->blocks;
    zT_14 = zT_13.len;
    if ((unsigned char)(bi < zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = c->lir_fn;
    zT_18 = zT_17->blocks;
    zT_19 = zT_18.items;
    zT_20 = zT_19 + bi;
    bb = zT_20;
    zT_22 = 0;
    ii = zT_22;
    goto z_bb_9;
    z_bb_7:
    if ((unsigned char)(changed == (unsigned char)(0))) goto z_bb_76; else goto z_bb_77;
    z_bb_8:
    zT_189 = bi + (unsigned int)(1);
    bi = zT_189;
    goto z_bb_5;
    z_bb_9:
    zT_23 = bb->insts;
    zT_24 = zT_23.len;
    if ((unsigned char)(ii < zT_24)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_27 = bb->insts;
    zT_28 = zT_27.items;
    zT_29 = zT_28[ii];
    inst = zT_29;
    zT_30 = inst.tag;
switch (zT_30) {
case 2: goto z_bb_13;
default: goto z_bb_14;
}
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_187 = ii + (unsigned int)(1);
    ii = zT_187;
    goto z_bb_9;
    z_bb_13:
    a = inst.payload.assign._0;
    zT_32 = a.name_id;
    if ((unsigned char)(zT_32 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    goto z_bb_12;
    z_bb_18:
    zT_36 = a.dst;
    dst = zT_36;
    zT_38 = a.src;
    src = zT_38;
    if ((unsigned char)(dst == src)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_12;
    z_bb_20:
    zT_40 = c->max_temp;
    if ((unsigned char)(dst >= zT_40)) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_43 = c->max_temp;
    zT_42 = src >= zT_43;
    goto z_bb_23;
    z_bb_22:
    zT_42 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_42) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    goto z_bb_12;
    z_bb_25:
    zT_46 = c->t2p;
    zT_47 = (unsigned int)dst;
    zT_48 = zT_46[zT_47];
    dp = zT_48;
    zT_50 = c->t2p;
    zT_51 = (unsigned int)src;
    zT_52 = zT_50[zT_51];
    sp = zT_52;
    if ((unsigned char)(dp == (unsigned int)(4294967295u))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_55 = sp == (unsigned int)(4294967295u);
    goto z_bb_28;
    z_bb_27:
    zT_55 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_55) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    goto z_bb_12;
    z_bb_30:
    zT_59 = (unsigned int)dp;
    dpos = zT_59;
    zT_61 = (unsigned int)sp;
    spos = zT_61;
    zT_62 = c->rar;
    zT_63 = zT_62[dpos];
    if ((unsigned char)(zT_63 != (unsigned char)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_12;
    z_bb_32:
    zT_66 = c->ex;
    zT_67 = zT_66[dpos];
    if ((unsigned char)(zT_67 != (unsigned char)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    goto z_bb_12;
    z_bb_34:
    zT_70 = c->ex;
    zT_71 = zT_70[spos];
    if ((unsigned char)(zT_71 != (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    goto z_bb_12;
    z_bb_36:
    zT_74 = c->at;
    zT_75 = zT_74[dpos];
    if ((unsigned char)(zT_75 != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    goto z_bb_12;
    z_bb_38:
    zT_78 = c->at;
    zT_79 = zT_78[spos];
    if ((unsigned char)(zT_79 != (unsigned char)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_12;
    z_bb_40:
    zT_82 = c->wc;
    zT_83 = zT_82[spos];
    if ((unsigned char)(zT_83 != (unsigned int)(1))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_12;
    z_bb_42:
    zT_86 = c->rc;
    zT_87 = zT_86[spos];
    if ((unsigned char)(zT_87 != (unsigned int)(1))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    goto z_bb_12;
    z_bb_44:
    zT_90 = c->dp;
    zT_91 = zT_90[spos];
    if ((unsigned char)(zT_91 != (unsigned char)(1))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    goto z_bb_12;
    z_bb_46:
    zT_94 = c->rc;
    zT_95 = zT_94[dpos];
    if ((unsigned char)(zT_95 != (unsigned int)(1))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_12;
    z_bb_48:
    zT_98 = c->rd_bb;
    zT_99 = zT_98[dpos];
    if ((unsigned char)(zT_99 == (unsigned int)((unsigned int)bi))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_12;
    z_bb_50:
    zT_103 = 0;
    di = zT_103;
    zT_105 = 0;
    ddefs = zT_105;
    goto z_bb_51;
    z_bb_51:
    zT_106 = bb->insts;
    zT_107 = zT_106.len;
    if ((unsigned char)(di < zT_107)) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_112 = bb->insts;
    zT_113 = zT_112.items;
    zT_114 = zT_113[di];
    zT_110 = zT_114;
    zT_111 = c->lir_fn;
    zT_116 = zF_CFED20F7_defResultTemp_1(zT_110, zT_111);
    ri = zT_116;
    if ((unsigned char)(ri == dst)) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    if ((unsigned char)(ddefs != (unsigned int)(1))) goto z_bb_57; else goto z_bb_58;
    z_bb_54:
    zT_121 = di + (unsigned int)(1);
    di = zT_121;
    goto z_bb_51;
    z_bb_55:
    zT_119 = ddefs + (unsigned int)(1);
    ddefs = zT_119;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_54;
    z_bb_57:
    goto z_bb_12;
    z_bb_58:
    zT_125 = c->df_bb;
    zT_126 = (unsigned int)src;
    zT_127 = zT_125[zT_126];
    pbb = zT_127;
    zT_129 = c->df_ii;
    zT_130 = (unsigned int)src;
    zT_131 = zT_129[zT_130];
    pii = zT_131;
    if ((unsigned char)(pbb == (unsigned int)(4294967295u))) goto z_bb_60; else goto z_bb_59;
    z_bb_59:
    zT_134 = pii == (unsigned int)(4294967295u);
    goto z_bb_61;
    z_bb_60:
    zT_134 = 1;
    goto z_bb_61;
    z_bb_61:
    if (zT_134) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    goto z_bb_12;
    z_bb_63:
    if ((unsigned char)(pbb != (unsigned int)((unsigned int)bi))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    goto z_bb_12;
    z_bb_65:
    if ((unsigned char)(pii >= (unsigned int)((unsigned int)ii))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    goto z_bb_12;
    z_bb_67:
    zT_142 = c->ttype;
    zT_143 = zT_142[dpos];
    dt = zT_143;
    zT_145 = c->ttype;
    zT_146 = zT_145[spos];
    st = zT_146;
    if ((unsigned char)(dt != st)) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    goto z_bb_12;
    z_bb_69:
    zT_148 = c->reg;
    zT_149 = zT_148->types_len;
    if ((unsigned char)(dt >= (unsigned int)((unsigned int)zT_149))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    goto z_bb_12;
    z_bb_71:
    zT_153 = c->reg;
    zT_154 = zT_153->types_items;
    zT_155 = (unsigned int)dt;
    zT_156 = zT_154[zT_155];
    dty = zT_156;
    zT_157 = dty.kind;
    zT_159 = zF_B7E1584C_copyScalarKindOk(zT_157);
    if ((unsigned char)(zT_159 == (unsigned char)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    goto z_bb_12;
    z_bb_73:
    zT_163 = bb->insts;
    zT_164 = zT_163.items;
    zT_165 = (unsigned int)pii;
    zT_166 = zT_164[zT_165];
    pinst = zT_166;
    zT_168 = 1;
    pok = zT_168;
    zT_170 = pinst;
    zT_171 = dst;
    zT_172 = &pok;
    zT_174 = zF_015226D9_retargetDefResult(zT_170, zT_171, zT_172);
    npinst = zT_174;
    if ((unsigned char)(pok == (unsigned char)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    goto z_bb_12;
    z_bb_75:
    zT_177 = bb->insts;
    zT_178 = zT_177.items;
    zT_179 = (unsigned int)pii;
    zT_178[zT_179] = npinst;
    zT_182 = 67;
    zT_180.tag = zT_182;
    zT_183 = bb->insts;
    zT_184 = zT_183.items;
    zT_184[ii] = zT_180;
    zT_185 = 1;
    changed = zT_185;
    goto z_bb_16;
    z_bb_76:
    goto z_bb_3;
    z_bb_77:
    zT_192 = 1;
    changed_total = zT_192;
    goto z_bb_4;
}

/* resDeclIntType */
unsigned char zF_2ECBA7DA_resDeclIntType(zT_5EDE903E_Ctx* c, unsigned int temp, unsigned int* out_w, unsigned char* out_s) {
    unsigned int zT_4;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    unsigned int* zT_22;
    unsigned int zT_23;
    zT_338B7C76_TypeRegistry* zT_24;
    unsigned int zT_25;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_D155D06D_Type* zT_31;
    unsigned int zT_32;
    zT_D155D06D_Type zT_33;
    zT_33EF6BFB_TypeKind zT_35;
    unsigned int zT_37 = 0;
    zT_33EF6BFB_TypeKind zT_41;
    unsigned char zT_43 = 0;
    unsigned int p;
    unsigned int pos;
    unsigned int tid;
    zT_D155D06D_Type ty;
    unsigned int w;
    zT_4 = c->max_temp;
    if ((unsigned char)(temp >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = c->t2p;
    zT_9 = (unsigned int)temp;
    zT_10 = zT_8[zT_9];
    p = zT_10;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = (unsigned int)p;
    pos = zT_15;
    zT_16 = c->ex;
    zT_17 = zT_16[pos];
    if ((unsigned char)(zT_17 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_22 = c->ttype;
    zT_23 = zT_22[pos];
    tid = zT_23;
    zT_24 = c->reg;
    zT_25 = zT_24->types_len;
    if ((unsigned char)(tid >= (unsigned int)((unsigned int)zT_25))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_30 = c->reg;
    zT_31 = zT_30->types_items;
    zT_32 = (unsigned int)tid;
    zT_33 = zT_31[zT_32];
    ty = zT_33;
    zT_35 = ty.kind;
    zT_37 = zF_90DDF69C_intKindWidth(zT_35);
    w = zT_37;
    if ((unsigned char)(w == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    *out_w = w;
    zT_41 = ty.kind;
    zT_43 = zF_D4EA92B8_intKindSigned(zT_41);
    *out_s = zT_43;
    return (unsigned char)(1);
}

/* constOperandIntType */
unsigned char zF_86D6C86A_constOperandIntType(zT_5EDE903E_Ctx* c, unsigned int temp, unsigned int* out_w, unsigned char* out_s) {
    unsigned int zT_4;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    unsigned char* zT_21;
    unsigned char zT_22;
    unsigned int* zT_26;
    unsigned int zT_27;
    unsigned char* zT_31;
    unsigned char zT_32;
    unsigned int* zT_37;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type* zT_46;
    unsigned int zT_47;
    zT_D155D06D_Type zT_48;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned int zT_52 = 0;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char zT_58 = 0;
    unsigned int p;
    unsigned int pos;
    unsigned int tid;
    zT_D155D06D_Type ty;
    unsigned int w;
    zT_4 = c->max_temp;
    if ((unsigned char)(temp >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = c->t2p;
    zT_9 = (unsigned int)temp;
    zT_10 = zT_8[zT_9];
    p = zT_10;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = (unsigned int)p;
    pos = zT_15;
    zT_16 = c->ex;
    zT_17 = zT_16[pos];
    if ((unsigned char)(zT_17 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = c->at;
    zT_22 = zT_21[pos];
    if ((unsigned char)(zT_22 != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_26 = c->wc;
    zT_27 = zT_26[pos];
    if ((unsigned char)(zT_27 != (unsigned int)(1))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_31 = c->cf;
    zT_32 = zT_31[pos];
    if ((unsigned char)(zT_32 != (unsigned char)(1))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_37 = c->ttype;
    zT_38 = zT_37[pos];
    tid = zT_38;
    zT_39 = c->reg;
    zT_40 = zT_39->types_len;
    if ((unsigned char)(tid >= (unsigned int)((unsigned int)zT_40))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_45 = c->reg;
    zT_46 = zT_45->types_items;
    zT_47 = (unsigned int)tid;
    zT_48 = zT_46[zT_47];
    ty = zT_48;
    zT_50 = ty.kind;
    zT_52 = zF_90DDF69C_intKindWidth(zT_50);
    w = zT_52;
    if ((unsigned char)(w == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    *out_w = w;
    zT_56 = ty.kind;
    zT_58 = zF_D4EA92B8_intKindSigned(zT_56);
    *out_s = zT_58;
    return (unsigned char)(1);
}

/* tempDeclTypeId */
unsigned int zF_D835BE2E_tempDeclTypeId(zT_5EDE903E_Ctx* c, unsigned int temp) {
    unsigned int zT_2;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int p;
    zT_2 = c->max_temp;
    if ((unsigned char)(temp >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)temp;
    zT_8 = zT_6[zT_7];
    p = zT_8;
    if ((unsigned char)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_12 = c->ttype;
    zT_13 = (unsigned int)p;
    zT_14 = zT_12[zT_13];
    return zT_14;
}

/* signMagnitude */
void zF_28365D82_signMagnitude(zT_79FAE712_u64 bits, unsigned int w, unsigned char s, unsigned char* out_neg, zT_79FAE712_u64* out_mag) {
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_79FAE712_u64 zT_9;
    unsigned int zT_13;
    zT_79FAE712_u64 zT_14 = 0;
    zT_79FAE712_u64 m;
    zT_79FAE712_u64 b;
    zT_6 = w;
    zT_7 = zF_5E3CE23D_lowMask(zT_6);
    m = zT_7;
    zT_9 = bits & m;
    b = zT_9;
    if ((unsigned char)(s == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *out_neg = (unsigned char)(0);
    *out_mag = b;
    return;
    z_bb_2:
    zT_13 = w;
    zT_14 = zF_3794934D_sigBit(zT_13);
    if ((unsigned char)((zT_79FAE712_u64)(b & zT_14) == (zT_79FAE712_u64)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    *out_neg = (unsigned char)(0);
    *out_mag = b;
    return;
    z_bb_4:
    *out_neg = (unsigned char)(1);
    *out_mag = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)(~b) & m) + (zT_79FAE712_u64)(1));
    return;
}

/* cmpBitsSigned */
signed char zF_0B35676F_cmpBitsSigned(zT_79FAE712_u64 a, zT_79FAE712_u64 b, unsigned int w) {
    unsigned int zT_4;
    zT_79FAE712_u64 zT_5 = 0;
    zT_79FAE712_u64 zT_7;
    zT_79FAE712_u64 zT_9;
    unsigned int zT_11;
    zT_79FAE712_u64 zT_12 = 0;
    unsigned char zT_15;
    unsigned int zT_17;
    zT_79FAE712_u64 zT_18 = 0;
    unsigned char zT_21;
    zT_79FAE712_u64 zT_35;
    zT_79FAE712_u64 zT_40;
    zT_79FAE712_u64 m;
    zT_79FAE712_u64 ab;
    zT_79FAE712_u64 bb;
    unsigned char asb;
    unsigned char bsb;
    zT_79FAE712_u64 ma;
    zT_79FAE712_u64 mb;
    zT_4 = w;
    zT_5 = zF_5E3CE23D_lowMask(zT_4);
    m = zT_5;
    zT_7 = a & m;
    ab = zT_7;
    zT_9 = b & m;
    bb = zT_9;
    zT_11 = w;
    zT_12 = zF_3794934D_sigBit(zT_11);
    zT_15 = (zT_79FAE712_u64)(ab & zT_12) != (zT_79FAE712_u64)(0);
    asb = zT_15;
    zT_17 = w;
    zT_18 = zF_3794934D_sigBit(zT_17);
    zT_21 = (zT_79FAE712_u64)(bb & zT_18) != (zT_79FAE712_u64)(0);
    bsb = zT_21;
    if ((unsigned char)(asb != bsb)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (asb) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(!asb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (signed char)((signed char)-1);
    z_bb_4:
    return (signed char)(1);
    z_bb_5:
    if ((unsigned char)(ab < bb)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_35 = (zT_79FAE712_u64)((zT_79FAE712_u64)(~ab) & m) + (zT_79FAE712_u64)(1);
    ma = zT_35;
    zT_40 = (zT_79FAE712_u64)((zT_79FAE712_u64)(~bb) & m) + (zT_79FAE712_u64)(1);
    mb = zT_40;
    if ((unsigned char)(ma > mb)) goto z_bb_11; else goto z_bb_12;
    z_bb_7:
    return (signed char)((signed char)-1);
    z_bb_8:
    if ((unsigned char)(ab > bb)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (signed char)(1);
    z_bb_10:
    return (signed char)(0);
    z_bb_11:
    return (signed char)((signed char)-1);
    z_bb_12:
    if ((unsigned char)(ma < mb)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (signed char)(1);
    z_bb_14:
    return (signed char)(0);
}

/* tryFoldBinaryOp */
unsigned char zF_EEEDCAC3_tryFoldBinaryOp(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst, zT_79FAE712_u64* out_value, unsigned char* out_is_bool) {
    unsigned int zT_5;
    unsigned char zT_7;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_5EDE903E_Ctx* zT_34;
    unsigned int zT_35;
    unsigned int* zT_36;
    unsigned char* zT_37;
    unsigned char zT_40 = 0;
    unsigned int* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_79FAE712_u64* zT_49;
    unsigned int zT_50;
    zT_79FAE712_u64 zT_51;
    unsigned int zT_53;
    zT_79FAE712_u64 zT_54 = 0;
    zT_79FAE712_u64 zT_56;
    zT_5EDE903E_Ctx* zT_58;
    unsigned int zT_59;
    unsigned int zT_60 = 0;
    zT_79FAE712_u64 zT_72;
    unsigned int zT_78;
    unsigned char zT_80;
    zT_5EDE903E_Ctx* zT_81;
    unsigned int zT_82;
    unsigned int* zT_83;
    unsigned char* zT_84;
    unsigned char zT_87 = 0;
    unsigned char zT_92;
    unsigned char zT_97;
    zT_79FAE712_u64 zT_103;
    zT_79FAE712_u64 zT_110;
    unsigned int zT_115;
    unsigned char zT_117;
    unsigned int zT_119;
    unsigned char zT_121;
    zT_5EDE903E_Ctx* zT_122;
    unsigned int zT_123;
    unsigned int* zT_124;
    unsigned char* zT_125;
    unsigned char zT_128 = 0;
    zT_5EDE903E_Ctx* zT_132;
    unsigned int zT_133;
    unsigned int* zT_134;
    unsigned char* zT_135;
    unsigned char zT_138 = 0;
    unsigned char zT_143;
    unsigned char zT_149;
    unsigned char zT_152;
    unsigned char zT_155;
    zT_5EDE903E_Ctx* zT_157;
    unsigned int zT_158;
    unsigned int zT_159 = 0;
    unsigned int zT_168;
    unsigned char zT_170;
    zT_5EDE903E_Ctx* zT_171;
    unsigned int zT_172;
    unsigned int* zT_173;
    unsigned char* zT_174;
    unsigned char zT_177 = 0;
    unsigned char zT_182;
    unsigned int zT_189;
    unsigned char zT_191;
    zT_5EDE903E_Ctx* zT_192;
    unsigned int zT_193;
    unsigned int* zT_194;
    unsigned char* zT_195;
    unsigned char zT_198 = 0;
    unsigned char zT_203;
    unsigned int* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int* zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    zT_79FAE712_u64* zT_215;
    unsigned int zT_216;
    zT_79FAE712_u64 zT_217;
    zT_79FAE712_u64* zT_219;
    unsigned int zT_220;
    zT_79FAE712_u64 zT_221;
    unsigned int zT_223;
    zT_79FAE712_u64 zT_224 = 0;
    zT_79FAE712_u64 zT_226;
    zT_79FAE712_u64 zT_228;
    zT_79FAE712_u64 zT_230;
    unsigned char zT_233;
    zT_79FAE712_u64 zT_237;
    unsigned char zT_240;
    zT_79FAE712_u64 zT_244;
    unsigned char zT_247;
    zT_79FAE712_u64 zT_251;
    zT_79FAE712_u64 zT_261;
    zT_79FAE712_u64 zT_271;
    zT_79FAE712_u64 zT_274;
    zT_79FAE712_u64 zT_277;
    zT_79FAE712_u64 zT_280;
    zT_79FAE712_u64 zT_290;
    zT_79FAE712_u64 zT_299;
    zT_79FAE712_u64 zT_303;
    zT_79FAE712_u64 zT_309;
    zT_79FAE712_u64 zT_316;
    zT_79FAE712_u64 zT_317;
    unsigned int zT_318;
    signed char zT_319 = 0;
    int zT_320;
    zT_79FAE712_u64 zT_322;
    zT_79FAE712_u64 zT_326;
    zT_79FAE712_u64 zT_333;
    zT_79FAE712_u64 zT_334;
    unsigned int zT_335;
    signed char zT_336 = 0;
    int zT_337;
    zT_79FAE712_u64 zT_339;
    zT_79FAE712_u64 zT_343;
    zT_79FAE712_u64 zT_350;
    zT_79FAE712_u64 zT_351;
    unsigned int zT_352;
    signed char zT_353 = 0;
    int zT_354;
    zT_79FAE712_u64 zT_356;
    zT_79FAE712_u64 zT_360;
    zT_79FAE712_u64 zT_367;
    zT_79FAE712_u64 zT_368;
    unsigned int zT_369;
    signed char zT_370 = 0;
    int zT_371;
    zT_79FAE712_u64 zT_373;
    zT_79FAE712_u64 zT_377;
    unsigned char zT_383;
    unsigned int res;
    unsigned char op;
    unsigned int lhs;
    unsigned int rhs;
    unsigned int operand;
    unsigned char is_unary;
    zT_176BF348_anon_77099 b;
    zT_11ECC358_anon_77107 u;
    unsigned int ow;
    unsigned char os;
    unsigned int lw;
    unsigned char ls;
    unsigned int rw2;
    unsigned char rs2;
    unsigned int opnd_pos;
    zT_79FAE712_u64 ob;
    zT_79FAE712_u64 om;
    zT_79FAE712_u64 obits;
    unsigned int rt;
    unsigned int rw;
    unsigned char rs;
    zT_79FAE712_u64 v;
    unsigned int w;
    unsigned char z_signed;
    unsigned char is_cmp;
    unsigned int rt3;
    unsigned int lp;
    unsigned int rp2;
    zT_79FAE712_u64 la;
    zT_79FAE712_u64 rb;
    zT_79FAE712_u64 m;
    zT_79FAE712_u64 ab;
    zT_79FAE712_u64 bb;
    unsigned int rw3;
    unsigned char rs3;
    unsigned int rw4;
    unsigned char rs4;
    zT_5 = 4294967295u;
    res = zT_5;
    zT_7 = 255;
    op = zT_7;
    zT_9 = 4294967295u;
    lhs = zT_9;
    zT_11 = 4294967295u;
    rhs = zT_11;
    zT_13 = 4294967295u;
    operand = zT_13;
    zT_15 = 0;
    is_unary = zT_15;
    zT_16 = inst.tag;
switch (zT_16) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
default: goto z_bb_3;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_18 = b.result;
    res = zT_18;
    zT_19 = b.op;
    op = zT_19;
    zT_20 = b.lhs;
    lhs = zT_20;
    zT_21 = b.rhs;
    rhs = zT_21;
    goto z_bb_5;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_23 = u.result;
    res = zT_23;
    zT_24 = u.op;
    op = zT_24;
    zT_25 = u.operand;
    operand = zT_25;
    zT_26 = 1;
    is_unary = zT_26;
    goto z_bb_5;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_5:
    if ((unsigned char)(is_unary != (unsigned char)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_31 = 0;
    ow = zT_31;
    zT_33 = 0;
    os = zT_33;
    zT_34 = c;
    zT_35 = operand;
    zT_36 = &ow;
    zT_37 = &os;
    zT_40 = zF_86D6C86A_constOperandIntType(zT_34, zT_35, zT_36, zT_37);
    if ((unsigned char)(zT_40 == (unsigned char)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_115 = 0;
    lw = zT_115;
    zT_117 = 0;
    ls = zT_117;
    zT_119 = 0;
    rw2 = zT_119;
    zT_121 = 0;
    rs2 = zT_121;
    zT_122 = c;
    zT_123 = lhs;
    zT_124 = &lw;
    zT_125 = &ls;
    zT_128 = zF_86D6C86A_constOperandIntType(zT_122, zT_123, zT_124, zT_125);
    if ((unsigned char)(zT_128 == (unsigned char)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_45 = c->t2p;
    zT_46 = (unsigned int)operand;
    zT_47 = zT_45[zT_46];
    opnd_pos = zT_47;
    zT_49 = c->cv;
    zT_50 = (unsigned int)opnd_pos;
    zT_51 = zT_49[zT_50];
    ob = zT_51;
    zT_53 = ow;
    zT_54 = zF_5E3CE23D_lowMask(zT_53);
    om = zT_54;
    zT_56 = ob & om;
    obits = zT_56;
    zT_58 = c;
    zT_59 = res;
    zT_60 = zF_D835BE2E_tempDeclTypeId(zT_58, zT_59);
    rt = zT_60;
    if ((unsigned char)(rt == (unsigned int)(4294967295u))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(0);
    z_bb_11:
    if ((unsigned char)(op == (unsigned char)(1))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    if ((unsigned char)(rt != (unsigned int)(2))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_78 = 0;
    rw = zT_78;
    zT_80 = 0;
    rs = zT_80;
    zT_81 = c;
    zT_82 = res;
    zT_83 = &rw;
    zT_84 = &rs;
    zT_87 = zF_2ECBA7DA_resDeclIntType(zT_81, zT_82, zT_83, zT_84);
    if ((unsigned char)(zT_87 == (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_14:
    return (unsigned char)(0);
    z_bb_15:
    if ((unsigned char)(obits == (zT_79FAE712_u64)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_72 = 1;
    goto z_bb_18;
    z_bb_17:
    zT_72 = 0;
    goto z_bb_18;
    z_bb_18:
    v = zT_72;
    *out_value = v;
    *out_is_bool = (unsigned char)(1);
    return (unsigned char)(1);
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    if ((unsigned char)(rw != ow)) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_92 = rs != os;
    goto z_bb_23;
    z_bb_22:
    zT_92 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_92) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (unsigned char)(0);
    z_bb_25:
    if ((unsigned char)(op == (unsigned char)(0))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_97 = op == (unsigned char)(3);
    goto z_bb_28;
    z_bb_27:
    zT_97 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_97) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_103 = (zT_79FAE712_u64)((zT_79FAE712_u64)(0) - obits) & om;
    v = zT_103;
    *out_value = v;
    *out_is_bool = (unsigned char)(0);
    return (unsigned char)(1);
    z_bb_30:
    if ((unsigned char)(op == (unsigned char)(2))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_110 = (zT_79FAE712_u64)(~obits) & om;
    v = zT_110;
    *out_value = v;
    *out_is_bool = (unsigned char)(0);
    return (unsigned char)(1);
    z_bb_32:
    return (unsigned char)(0);
    z_bb_33:
    return (unsigned char)(0);
    z_bb_34:
    zT_132 = c;
    zT_133 = rhs;
    zT_134 = &rw2;
    zT_135 = &rs2;
    zT_138 = zF_86D6C86A_constOperandIntType(zT_132, zT_133, zT_134, zT_135);
    if ((unsigned char)(zT_138 == (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned char)(0);
    z_bb_36:
    if ((unsigned char)(lw != rw2)) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_143 = ls != rs2;
    goto z_bb_39;
    z_bb_38:
    zT_143 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_143) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    return (unsigned char)(0);
    z_bb_41:
    w = lw;
    z_signed = ls;
    zT_149 = 0;
    is_cmp = zT_149;
    if ((unsigned char)(op >= (unsigned char)(10))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_152 = op <= (unsigned char)(15);
    goto z_bb_44;
    z_bb_43:
    zT_152 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_152) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_155 = 1;
    is_cmp = zT_155;
    goto z_bb_46;
    z_bb_46:
    zT_157 = c;
    zT_158 = res;
    zT_159 = zF_D835BE2E_tempDeclTypeId(zT_157, zT_158);
    rt3 = zT_159;
    if ((unsigned char)(rt3 == (unsigned int)(4294967295u))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned char)(0);
    z_bb_48:
    if ((unsigned char)(is_cmp != (unsigned char)(0))) goto z_bb_49; else goto z_bb_51;
    z_bb_49:
    if ((unsigned char)(rt3 != (unsigned int)(2))) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    zT_207 = c->t2p;
    zT_208 = (unsigned int)lhs;
    zT_209 = zT_207[zT_208];
    lp = zT_209;
    zT_211 = c->t2p;
    zT_212 = (unsigned int)rhs;
    zT_213 = zT_211[zT_212];
    rp2 = zT_213;
    zT_215 = c->cv;
    zT_216 = (unsigned int)lp;
    zT_217 = zT_215[zT_216];
    la = zT_217;
    zT_219 = c->cv;
    zT_220 = (unsigned int)rp2;
    zT_221 = zT_219[zT_220];
    rb = zT_221;
    zT_223 = w;
    zT_224 = zF_5E3CE23D_lowMask(zT_223);
    m = zT_224;
    zT_226 = la & m;
    ab = zT_226;
    zT_228 = rb & m;
    bb = zT_228;
    zT_230 = 0;
    v = zT_230;
    if ((unsigned char)(op == (unsigned char)(0))) goto z_bb_71; else goto z_bb_70;
    z_bb_51:
    if ((unsigned char)(rt3 == (unsigned int)(2))) goto z_bb_61; else goto z_bb_62;
    z_bb_52:
    zT_168 = 0;
    rw3 = zT_168;
    zT_170 = 0;
    rs3 = zT_170;
    zT_171 = c;
    zT_172 = res;
    zT_173 = &rw3;
    zT_174 = &rs3;
    zT_177 = zF_2ECBA7DA_resDeclIntType(zT_171, zT_172, zT_173, zT_174);
    if ((unsigned char)(zT_177 == (unsigned char)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    return (unsigned char)(0);
    z_bb_55:
    if ((unsigned char)(rw3 != w)) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_182 = rs3 != z_signed;
    goto z_bb_58;
    z_bb_57:
    zT_182 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_182) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (unsigned char)(0);
    z_bb_60:
    goto z_bb_53;
    z_bb_61:
    return (unsigned char)(0);
    z_bb_62:
    zT_189 = 0;
    rw4 = zT_189;
    zT_191 = 0;
    rs4 = zT_191;
    zT_192 = c;
    zT_193 = res;
    zT_194 = &rw4;
    zT_195 = &rs4;
    zT_198 = zF_2ECBA7DA_resDeclIntType(zT_192, zT_193, zT_194, zT_195);
    if ((unsigned char)(zT_198 == (unsigned char)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (unsigned char)(0);
    z_bb_64:
    if ((unsigned char)(rw4 != w)) goto z_bb_66; else goto z_bb_65;
    z_bb_65:
    zT_203 = rs4 != z_signed;
    goto z_bb_67;
    z_bb_66:
    zT_203 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_203) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    return (unsigned char)(0);
    z_bb_69:
    goto z_bb_50;
    z_bb_70:
    zT_233 = op == (unsigned char)(16);
    goto z_bb_72;
    z_bb_71:
    zT_233 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_233) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_237 = (zT_79FAE712_u64)(ab + bb) & m;
    v = zT_237;
    goto z_bb_74;
    z_bb_74:
    *out_value = v;
    if ((unsigned char)(rt3 == (unsigned int)(2))) goto z_bb_185; else goto z_bb_186;
    z_bb_75:
    if ((unsigned char)(op == (unsigned char)(1))) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_240 = op == (unsigned char)(17);
    goto z_bb_78;
    z_bb_77:
    zT_240 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_240) goto z_bb_79; else goto z_bb_81;
    z_bb_79:
    zT_244 = (zT_79FAE712_u64)(ab - bb) & m;
    v = zT_244;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_74;
    z_bb_81:
    if ((unsigned char)(op == (unsigned char)(2))) goto z_bb_83; else goto z_bb_82;
    z_bb_82:
    zT_247 = op == (unsigned char)(18);
    goto z_bb_84;
    z_bb_83:
    zT_247 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_247) goto z_bb_85; else goto z_bb_87;
    z_bb_85:
    zT_251 = (zT_79FAE712_u64)(ab * bb) & m;
    v = zT_251;
    goto z_bb_86;
    z_bb_86:
    goto z_bb_80;
    z_bb_87:
    if ((unsigned char)(op == (unsigned char)(3))) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    if ((unsigned char)(z_signed != (unsigned char)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_89:
    goto z_bb_86;
    z_bb_90:
    if ((unsigned char)(op == (unsigned char)(4))) goto z_bb_95; else goto z_bb_97;
    z_bb_91:
    return (unsigned char)(0);
    z_bb_92:
    if ((unsigned char)(bb == (zT_79FAE712_u64)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned char)(0);
    z_bb_94:
    zT_261 = (zT_79FAE712_u64)(ab / bb) & m;
    v = zT_261;
    goto z_bb_89;
    z_bb_95:
    if ((unsigned char)(z_signed != (unsigned char)(0))) goto z_bb_98; else goto z_bb_99;
    z_bb_96:
    goto z_bb_89;
    z_bb_97:
    if ((unsigned char)(op == (unsigned char)(5))) goto z_bb_102; else goto z_bb_104;
    z_bb_98:
    return (unsigned char)(0);
    z_bb_99:
    if ((unsigned char)(bb == (zT_79FAE712_u64)(0))) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    return (unsigned char)(0);
    z_bb_101:
    zT_271 = (zT_79FAE712_u64)(ab % bb) & m;
    v = zT_271;
    goto z_bb_96;
    z_bb_102:
    zT_274 = ab & bb;
    v = zT_274;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_96;
    z_bb_104:
    if ((unsigned char)(op == (unsigned char)(6))) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    zT_277 = ab | bb;
    v = zT_277;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    if ((unsigned char)(op == (unsigned char)(7))) goto z_bb_108; else goto z_bb_110;
    z_bb_108:
    zT_280 = ab ^ bb;
    v = zT_280;
    goto z_bb_109;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    if ((unsigned char)(op == (unsigned char)(8))) goto z_bb_111; else goto z_bb_113;
    z_bb_111:
    if ((unsigned char)(z_signed != (unsigned char)(0))) goto z_bb_114; else goto z_bb_115;
    z_bb_112:
    goto z_bb_109;
    z_bb_113:
    if ((unsigned char)(op == (unsigned char)(9))) goto z_bb_118; else goto z_bb_120;
    z_bb_114:
    return (unsigned char)(0);
    z_bb_115:
    if ((unsigned char)(bb >= (zT_79FAE712_u64)((zT_79FAE712_u64)w))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    return (unsigned char)(0);
    z_bb_117:
    zT_290 = (zT_79FAE712_u64)(ab << bb) & m;
    v = zT_290;
    goto z_bb_112;
    z_bb_118:
    if ((unsigned char)(z_signed != (unsigned char)(0))) goto z_bb_121; else goto z_bb_122;
    z_bb_119:
    goto z_bb_112;
    z_bb_120:
    if ((unsigned char)(op == (unsigned char)(10))) goto z_bb_125; else goto z_bb_127;
    z_bb_121:
    return (unsigned char)(0);
    z_bb_122:
    if ((unsigned char)(bb >= (zT_79FAE712_u64)((zT_79FAE712_u64)w))) goto z_bb_123; else goto z_bb_124;
    z_bb_123:
    return (unsigned char)(0);
    z_bb_124:
    zT_299 = ab >> bb;
    v = zT_299;
    goto z_bb_119;
    z_bb_125:
    if ((unsigned char)(ab == bb)) goto z_bb_128; else goto z_bb_129;
    z_bb_126:
    goto z_bb_119;
    z_bb_127:
    if ((unsigned char)(op == (unsigned char)(11))) goto z_bb_131; else goto z_bb_133;
    z_bb_128:
    zT_303 = 1;
    goto z_bb_130;
    z_bb_129:
    zT_303 = 0;
    goto z_bb_130;
    z_bb_130:
    v = zT_303;
    goto z_bb_126;
    z_bb_131:
    if ((unsigned char)(ab != bb)) goto z_bb_134; else goto z_bb_135;
    z_bb_132:
    goto z_bb_126;
    z_bb_133:
    if ((unsigned char)(op == (unsigned char)(12))) goto z_bb_137; else goto z_bb_139;
    z_bb_134:
    zT_309 = 1;
    goto z_bb_136;
    z_bb_135:
    zT_309 = 0;
    goto z_bb_136;
    z_bb_136:
    v = zT_309;
    goto z_bb_132;
    z_bb_137:
    if ((unsigned char)(z_signed != (unsigned char)(0))) goto z_bb_140; else goto z_bb_142;
    z_bb_138:
    goto z_bb_132;
    z_bb_139:
    if ((unsigned char)(op == (unsigned char)(13))) goto z_bb_149; else goto z_bb_151;
    z_bb_140:
    zT_316 = ab;
    zT_317 = bb;
    zT_318 = w;
    zT_319 = zF_0B35676F_cmpBitsSigned(zT_316, zT_317, zT_318);
    zT_320 = 0;
    if ((unsigned char)(zT_319 < zT_320)) goto z_bb_143; else goto z_bb_144;
    z_bb_141:
    goto z_bb_138;
    z_bb_142:
    if ((unsigned char)(ab < bb)) goto z_bb_146; else goto z_bb_147;
    z_bb_143:
    zT_322 = 1;
    goto z_bb_145;
    z_bb_144:
    zT_322 = 0;
    goto z_bb_145;
    z_bb_145:
    v = zT_322;
    goto z_bb_141;
    z_bb_146:
    zT_326 = 1;
    goto z_bb_148;
    z_bb_147:
    zT_326 = 0;
    goto z_bb_148;
    z_bb_148:
    v = zT_326;
    goto z_bb_141;
    z_bb_149:
    if ((unsigned char)(z_signed != (unsigned char)(0))) goto z_bb_152; else goto z_bb_154;
    z_bb_150:
    goto z_bb_138;
    z_bb_151:
    if ((unsigned char)(op == (unsigned char)(14))) goto z_bb_161; else goto z_bb_163;
    z_bb_152:
    zT_333 = ab;
    zT_334 = bb;
    zT_335 = w;
    zT_336 = zF_0B35676F_cmpBitsSigned(zT_333, zT_334, zT_335);
    zT_337 = 0;
    if ((unsigned char)(zT_336 <= zT_337)) goto z_bb_155; else goto z_bb_156;
    z_bb_153:
    goto z_bb_150;
    z_bb_154:
    if ((unsigned char)(ab <= bb)) goto z_bb_158; else goto z_bb_159;
    z_bb_155:
    zT_339 = 1;
    goto z_bb_157;
    z_bb_156:
    zT_339 = 0;
    goto z_bb_157;
    z_bb_157:
    v = zT_339;
    goto z_bb_153;
    z_bb_158:
    zT_343 = 1;
    goto z_bb_160;
    z_bb_159:
    zT_343 = 0;
    goto z_bb_160;
    z_bb_160:
    v = zT_343;
    goto z_bb_153;
    z_bb_161:
    if ((unsigned char)(z_signed != (unsigned char)(0))) goto z_bb_164; else goto z_bb_166;
    z_bb_162:
    goto z_bb_150;
    z_bb_163:
    if ((unsigned char)(op == (unsigned char)(15))) goto z_bb_173; else goto z_bb_175;
    z_bb_164:
    zT_350 = ab;
    zT_351 = bb;
    zT_352 = w;
    zT_353 = zF_0B35676F_cmpBitsSigned(zT_350, zT_351, zT_352);
    zT_354 = 0;
    if ((unsigned char)(zT_353 > zT_354)) goto z_bb_167; else goto z_bb_168;
    z_bb_165:
    goto z_bb_162;
    z_bb_166:
    if ((unsigned char)(ab > bb)) goto z_bb_170; else goto z_bb_171;
    z_bb_167:
    zT_356 = 1;
    goto z_bb_169;
    z_bb_168:
    zT_356 = 0;
    goto z_bb_169;
    z_bb_169:
    v = zT_356;
    goto z_bb_165;
    z_bb_170:
    zT_360 = 1;
    goto z_bb_172;
    z_bb_171:
    zT_360 = 0;
    goto z_bb_172;
    z_bb_172:
    v = zT_360;
    goto z_bb_165;
    z_bb_173:
    if ((unsigned char)(z_signed != (unsigned char)(0))) goto z_bb_176; else goto z_bb_178;
    z_bb_174:
    goto z_bb_162;
    z_bb_175:
    return (unsigned char)(0);
    z_bb_176:
    zT_367 = ab;
    zT_368 = bb;
    zT_369 = w;
    zT_370 = zF_0B35676F_cmpBitsSigned(zT_367, zT_368, zT_369);
    zT_371 = 0;
    if ((unsigned char)(zT_370 >= zT_371)) goto z_bb_179; else goto z_bb_180;
    z_bb_177:
    goto z_bb_174;
    z_bb_178:
    if ((unsigned char)(ab >= bb)) goto z_bb_182; else goto z_bb_183;
    z_bb_179:
    zT_373 = 1;
    goto z_bb_181;
    z_bb_180:
    zT_373 = 0;
    goto z_bb_181;
    z_bb_181:
    v = zT_373;
    goto z_bb_177;
    z_bb_182:
    zT_377 = 1;
    goto z_bb_184;
    z_bb_183:
    zT_377 = 0;
    goto z_bb_184;
    z_bb_184:
    v = zT_377;
    goto z_bb_177;
    z_bb_185:
    zT_383 = 1;
    goto z_bb_187;
    z_bb_186:
    zT_383 = 0;
    goto z_bb_187;
    z_bb_187:
    *out_is_bool = zT_383;
    return (unsigned char)(1);
}

/* tryFoldIntCast */
unsigned char zF_2EC2B21D_tryFoldIntCast(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst, zT_79FAE712_u64* out_value) {
    unsigned int zT_3;
    unsigned int zT_6;
    unsigned int zT_8;
    zT_5EDE903E_Ctx* zT_10;
    unsigned int zT_11;
    unsigned int zT_12 = 0;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned char zT_22;
    zT_5EDE903E_Ctx* zT_23;
    unsigned int zT_24;
    unsigned int* zT_25;
    unsigned char* zT_26;
    unsigned char zT_29 = 0;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_39;
    zT_D155D06D_Type* zT_40;
    unsigned int zT_41;
    zT_D155D06D_Type zT_42;
    zT_33EF6BFB_TypeKind zT_44;
    unsigned int zT_46 = 0;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned char zT_53 = 0;
    unsigned int* zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_79FAE712_u64* zT_59;
    unsigned int zT_60;
    zT_79FAE712_u64 zT_61;
    unsigned int zT_63;
    zT_79FAE712_u64 zT_64 = 0;
    zT_79FAE712_u64 zT_66;
    unsigned char zT_68;
    zT_79FAE712_u64 zT_70;
    zT_79FAE712_u64 zT_71;
    unsigned int zT_72;
    unsigned char zT_73;
    unsigned char* zT_74;
    zT_79FAE712_u64* zT_75;
    unsigned char zT_79;
    unsigned int zT_85;
    zT_79FAE712_u64 zT_86 = 0;
    unsigned char zT_88;
    unsigned int zT_90;
    zT_79FAE712_u64 zT_91 = 0;
    unsigned char zT_95;
    unsigned char zT_97;
    unsigned int zT_102;
    zT_79FAE712_u64 zT_103 = 0;
    zT_79FAE712_u64 zT_105;
    zT_79FAE712_u64 zT_110;
    zT_79FAE712_u64 zT_111;
    zT_4F25184D_anon_77283 ic;
    unsigned int res;
    unsigned int val_t;
    unsigned int rt;
    unsigned int ow;
    unsigned char os;
    zT_D155D06D_Type ty;
    unsigned int tw;
    unsigned char ts;
    unsigned int vp;
    zT_79FAE712_u64 bits;
    zT_79FAE712_u64 m;
    zT_79FAE712_u64 b;
    unsigned char is_neg;
    zT_79FAE712_u64 mag;
    unsigned char ok;
    zT_79FAE712_u64 mag_lim;
    zT_79FAE712_u64 ub;
    zT_79FAE712_u64 tm;
    zT_79FAE712_u64 v;
    zT_3 = inst.tag;
switch (zT_3) {
case 38: goto z_bb_1;
default: goto z_bb_2;
}
    z_bb_1:
    ic = inst.payload.int_cast._0;
    zT_6 = ic.result;
    res = zT_6;
    zT_8 = ic.value;
    val_t = zT_8;
    zT_10 = c;
    zT_11 = res;
    zT_12 = zF_D835BE2E_tempDeclTypeId(zT_10, zT_11);
    rt = zT_12;
    if ((unsigned char)(rt == (unsigned int)(4294967295u))) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    return (unsigned char)(0);
    return 0;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_16 = ic.target;
    if ((unsigned char)(rt != zT_16)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_20 = 0;
    ow = zT_20;
    zT_22 = 0;
    os = zT_22;
    zT_23 = c;
    zT_24 = val_t;
    zT_25 = &ow;
    zT_26 = &os;
    zT_29 = zF_86D6C86A_constOperandIntType(zT_23, zT_24, zT_25, zT_26);
    if ((unsigned char)(zT_29 == (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_33 = c->reg;
    zT_34 = zT_33->types_len;
    if ((unsigned char)(rt >= (unsigned int)((unsigned int)zT_34))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_39 = c->reg;
    zT_40 = zT_39->types_items;
    zT_41 = (unsigned int)rt;
    zT_42 = zT_40[zT_41];
    ty = zT_42;
    zT_44 = ty.kind;
    zT_46 = zF_90DDF69C_intKindWidth(zT_44);
    tw = zT_46;
    if ((unsigned char)(tw == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_51 = ty.kind;
    zT_53 = zF_D4EA92B8_intKindSigned(zT_51);
    ts = zT_53;
    zT_55 = c->t2p;
    zT_56 = (unsigned int)val_t;
    zT_57 = zT_55[zT_56];
    vp = zT_57;
    zT_59 = c->cv;
    zT_60 = (unsigned int)vp;
    zT_61 = zT_59[zT_60];
    bits = zT_61;
    zT_63 = ow;
    zT_64 = zF_5E3CE23D_lowMask(zT_63);
    m = zT_64;
    zT_66 = bits & m;
    b = zT_66;
    zT_68 = 0;
    is_neg = zT_68;
    zT_70 = 0;
    mag = zT_70;
    zT_71 = b;
    zT_72 = ow;
    zT_73 = os;
    zT_74 = &is_neg;
    zT_75 = &mag;
    zF_28365D82_signMagnitude(zT_71, zT_72, zT_73, zT_74, zT_75);
    zT_79 = 0;
    ok = zT_79;
    if ((unsigned char)(ts == (unsigned char)(0))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    if ((unsigned char)(is_neg == (unsigned char)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    if ((unsigned char)(ok == (unsigned char)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_17:
    zT_90 = tw;
    zT_91 = zF_3794934D_sigBit(zT_90);
    mag_lim = zT_91;
    if ((unsigned char)(is_neg != (unsigned char)(0))) goto z_bb_22; else goto z_bb_24;
    z_bb_18:
    zT_85 = tw;
    zT_86 = zF_5E3CE23D_lowMask(zT_85);
    ub = zT_86;
    if ((unsigned char)(mag <= ub)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_88 = 1;
    ok = zT_88;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    if ((unsigned char)(mag <= mag_lim)) goto z_bb_25; else goto z_bb_26;
    z_bb_23:
    goto z_bb_16;
    z_bb_24:
    if ((unsigned char)(mag < mag_lim)) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_95 = 1;
    ok = zT_95;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_97 = 1;
    ok = zT_97;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    return (unsigned char)(0);
    z_bb_30:
    zT_102 = tw;
    zT_103 = zF_5E3CE23D_lowMask(zT_102);
    tm = zT_103;
    zT_105 = 0;
    v = zT_105;
    if ((unsigned char)(is_neg != (unsigned char)(0))) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_110 = (zT_79FAE712_u64)((zT_79FAE712_u64)(0) - mag) & tm;
    v = zT_110;
    goto z_bb_32;
    z_bb_32:
    *out_value = v;
    return (unsigned char)(1);
    z_bb_33:
    zT_111 = mag & tm;
    v = zT_111;
    goto z_bb_32;
}

/* runConstFold */
unsigned char zF_7C7AB1D6_runConstFold(zT_5EDE903E_Ctx* c) {
    unsigned char zT_2;
    unsigned int zT_4;
    zT_BBC23664_LirFunction* zT_5;
    zT_1CF28CA3_BasicBlockArrayList zT_6;
    unsigned int zT_7;
    zT_BBC23664_LirFunction* zT_10;
    zT_1CF28CA3_BasicBlockArrayList zT_11;
    zT_88A68B1A_BasicBlock* zT_12;
    zT_88A68B1A_BasicBlock* zT_13;
    unsigned int zT_15;
    zT_DAE4631D_LirInstArrayList zT_16;
    unsigned int zT_17;
    zT_DAE4631D_LirInstArrayList zT_20;
    zT_6BA597BC_LirInst* zT_21;
    zT_6BA597BC_LirInst zT_22;
    unsigned int zT_23;
    zT_79FAE712_u64 zT_26;
    unsigned char zT_28;
    zT_5EDE903E_Ctx* zT_29;
    zT_6BA597BC_LirInst zT_30;
    zT_79FAE712_u64* zT_31;
    unsigned char* zT_32;
    unsigned char zT_35 = 0;
    unsigned char zT_43;
    zT_6BA597BC_LirInst zT_46;
    zT_39C3E441_anon_77355 zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_DAE4631D_LirInstArrayList zT_50;
    zT_6BA597BC_LirInst* zT_51;
    zT_6BA597BC_LirInst zT_52;
    zT_A7CB4D30_anon_77327 zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_DAE4631D_LirInstArrayList zT_56;
    zT_6BA597BC_LirInst* zT_57;
    unsigned char zT_58;
    zT_79FAE712_u64 zT_61;
    unsigned char zT_63;
    zT_5EDE903E_Ctx* zT_64;
    zT_6BA597BC_LirInst zT_65;
    zT_79FAE712_u64* zT_66;
    unsigned char* zT_67;
    unsigned char zT_70 = 0;
    unsigned char zT_78;
    zT_6BA597BC_LirInst zT_81;
    zT_39C3E441_anon_77355 zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_DAE4631D_LirInstArrayList zT_85;
    zT_6BA597BC_LirInst* zT_86;
    zT_6BA597BC_LirInst zT_87;
    zT_A7CB4D30_anon_77327 zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_DAE4631D_LirInstArrayList zT_91;
    zT_6BA597BC_LirInst* zT_92;
    unsigned char zT_93;
    zT_79FAE712_u64 zT_96;
    zT_5EDE903E_Ctx* zT_97;
    zT_6BA597BC_LirInst zT_98;
    zT_79FAE712_u64* zT_99;
    unsigned char zT_101 = 0;
    zT_6BA597BC_LirInst zT_104;
    zT_A7CB4D30_anon_77327 zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_DAE4631D_LirInstArrayList zT_108;
    zT_6BA597BC_LirInst* zT_109;
    unsigned char zT_110;
    unsigned int zT_112;
    unsigned int zT_114;
    unsigned char changed;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    zT_176BF348_anon_77099 b;
    zT_79FAE712_u64 v;
    unsigned char is_bool;
    zT_11ECC358_anon_77107 u;
    zT_4F25184D_anon_77283 ic;
    unsigned char bv;
    zT_2 = 0;
    changed = zT_2;
    zT_4 = 0;
    bi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = c->lir_fn;
    zT_6 = zT_5->blocks;
    zT_7 = zT_6.len;
    if ((unsigned char)(bi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = c->lir_fn;
    zT_11 = zT_10->blocks;
    zT_12 = zT_11.items;
    zT_13 = zT_12 + bi;
    bb = zT_13;
    zT_15 = 0;
    ii = zT_15;
    goto z_bb_5;
    z_bb_3:
    return changed;
    z_bb_4:
    zT_114 = bi + (unsigned int)(1);
    bi = zT_114;
    goto z_bb_1;
    z_bb_5:
    zT_16 = bb->insts;
    zT_17 = zT_16.len;
    if ((unsigned char)(ii < zT_17)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = bb->insts;
    zT_21 = zT_20.items;
    zT_22 = zT_21[ii];
    inst = zT_22;
    zT_23 = inst.tag;
switch (zT_23) {
case 12: goto z_bb_9;
case 13: goto z_bb_10;
case 38: goto z_bb_11;
default: goto z_bb_12;
}
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_112 = ii + (unsigned int)(1);
    ii = zT_112;
    goto z_bb_5;
    z_bb_9:
    b = inst.payload.binary._0;
    zT_26 = 0;
    v = zT_26;
    zT_28 = 0;
    is_bool = zT_28;
    zT_29 = c;
    zT_30 = inst;
    zT_31 = &v;
    zT_32 = &is_bool;
    zT_35 = zF_EEEDCAC3_tryFoldBinaryOp(zT_29, zT_30, zT_31, zT_32);
    if ((unsigned char)(zT_35 == (unsigned char)(1))) goto z_bb_15; else goto z_bb_16;
    z_bb_10:
    u = inst.payload.unary._0;
    zT_61 = 0;
    v = zT_61;
    zT_63 = 0;
    is_bool = zT_63;
    zT_64 = c;
    zT_65 = inst;
    zT_66 = &v;
    zT_67 = &is_bool;
    zT_70 = zF_EEEDCAC3_tryFoldBinaryOp(zT_64, zT_65, zT_66, zT_67);
    if ((unsigned char)(zT_70 == (unsigned char)(1))) goto z_bb_23; else goto z_bb_24;
    z_bb_11:
    ic = inst.payload.int_cast._0;
    zT_96 = 0;
    v = zT_96;
    zT_97 = c;
    zT_98 = inst;
    zT_99 = &v;
    zT_101 = zF_2EC2B21D_tryFoldIntCast(zT_97, zT_98, zT_99);
    if ((unsigned char)(zT_101 == (unsigned char)(1))) goto z_bb_31; else goto z_bb_32;
    z_bb_12:
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    if ((unsigned char)(is_bool != (unsigned char)(0))) goto z_bb_17; else goto z_bb_19;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    if ((unsigned char)(v != (zT_79FAE712_u64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_58 = 1;
    changed = zT_58;
    goto z_bb_16;
    z_bb_19:
    zT_53.value = v;
    zT_54 = b.result;
    zT_53.result = zT_54;
    zT_55 = 44;
    zT_52.tag = zT_55;
    zT_52.payload.int_const._0 = zT_53;
    zT_56 = bb->insts;
    zT_57 = zT_56.items;
    zT_57[ii] = zT_52;
    goto z_bb_18;
    z_bb_20:
    zT_43 = 1;
    goto z_bb_22;
    z_bb_21:
    zT_43 = 0;
    goto z_bb_22;
    z_bb_22:
    bv = zT_43;
    zT_47.value = bv;
    zT_48 = b.result;
    zT_47.result = zT_48;
    zT_49 = 49;
    zT_46.tag = zT_49;
    zT_46.payload.bool_const._0 = zT_47;
    zT_50 = bb->insts;
    zT_51 = zT_50.items;
    zT_51[ii] = zT_46;
    goto z_bb_18;
    z_bb_23:
    if ((unsigned char)(is_bool != (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    goto z_bb_14;
    z_bb_25:
    if ((unsigned char)(v != (zT_79FAE712_u64)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_93 = 1;
    changed = zT_93;
    goto z_bb_24;
    z_bb_27:
    zT_88.value = v;
    zT_89 = u.result;
    zT_88.result = zT_89;
    zT_90 = 44;
    zT_87.tag = zT_90;
    zT_87.payload.int_const._0 = zT_88;
    zT_91 = bb->insts;
    zT_92 = zT_91.items;
    zT_92[ii] = zT_87;
    goto z_bb_26;
    z_bb_28:
    zT_78 = 1;
    goto z_bb_30;
    z_bb_29:
    zT_78 = 0;
    goto z_bb_30;
    z_bb_30:
    bv = zT_78;
    zT_82.value = bv;
    zT_83 = u.result;
    zT_82.result = zT_83;
    zT_84 = 49;
    zT_81.tag = zT_84;
    zT_81.payload.bool_const._0 = zT_82;
    zT_85 = bb->insts;
    zT_86 = zT_85.items;
    zT_86[ii] = zT_81;
    goto z_bb_26;
    z_bb_31:
    zT_105.value = v;
    zT_106 = ic.result;
    zT_105.result = zT_106;
    zT_107 = 44;
    zT_104.tag = zT_107;
    zT_104.payload.int_const._0 = zT_105;
    zT_108 = bb->insts;
    zT_109 = zT_108.items;
    zT_109[ii] = zT_104;
    zT_110 = 1;
    changed = zT_110;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_14;
}

/* lirOptRun */
void zF_37363942_lirOptRun(zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg, zT_BBC23664_LirFunction* lir_fn) {
    zT_BBC23664_LirFunction* zT_5;
    unsigned int zT_6 = 0;
    zT_5EDE903E_Ctx zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    unsigned int* zT_15 = 0;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    unsigned int* zT_20 = 0;
    zT_3E40CD83_Sand* zT_21;
    unsigned int zT_22;
    unsigned int* zT_23 = 0;
    zT_3E40CD83_Sand* zT_24;
    unsigned int zT_25;
    unsigned int* zT_26 = 0;
    zT_3E40CD83_Sand* zT_27;
    unsigned int zT_28;
    unsigned char* zT_29 = 0;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_31;
    unsigned char* zT_32 = 0;
    zT_3E40CD83_Sand* zT_33;
    unsigned int zT_34;
    unsigned char* zT_35 = 0;
    zT_3E40CD83_Sand* zT_36;
    unsigned int zT_37;
    unsigned int* zT_38 = 0;
    zT_3E40CD83_Sand* zT_39;
    unsigned int zT_40;
    unsigned int* zT_41 = 0;
    zT_3E40CD83_Sand* zT_42;
    unsigned int zT_43;
    unsigned char* zT_44 = 0;
    zT_3E40CD83_Sand* zT_45;
    unsigned int zT_46;
    unsigned char* zT_47 = 0;
    zT_3E40CD83_Sand* zT_48;
    unsigned int zT_49;
    zT_79FAE712_u64* zT_50 = 0;
    zT_3E40CD83_Sand* zT_51;
    unsigned int zT_52;
    unsigned int* zT_55 = 0;
    zT_3E40CD83_Sand* zT_56;
    unsigned int zT_57;
    unsigned char* zT_58 = 0;
    zT_3E40CD83_Sand* zT_59;
    unsigned int zT_60;
    unsigned char* zT_61 = 0;
    zT_3E40CD83_Sand* zT_62;
    unsigned int zT_63;
    unsigned int* zT_64 = 0;
    zT_3E40CD83_Sand* zT_65;
    unsigned int zT_66;
    unsigned int* zT_67 = 0;
    zT_3E40CD83_Sand* zT_68;
    unsigned int zT_69;
    unsigned char* zT_70 = 0;
    zT_3E40CD83_Sand* zT_71;
    unsigned int zT_72;
    unsigned char* zT_73 = 0;
    unsigned int zT_75;
    zT_5D72FBF8_TempDeclArrayList zT_76;
    unsigned int zT_77;
    zT_5D72FBF8_TempDeclArrayList zT_80;
    zT_1937645B_TempDecl* zT_81;
    zT_1937645B_TempDecl zT_82;
    unsigned int zT_83;
    unsigned int zT_85;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_94;
    zT_5EDE903E_Ctx* zT_95;
    zT_5EDE903E_Ctx* zT_97;
    unsigned char zT_99 = 0;
    zT_5EDE903E_Ctx* zT_100;
    zT_5EDE903E_Ctx* zT_102;
    unsigned char zT_104 = 0;
    zT_5EDE903E_Ctx* zT_105;
    unsigned char zT_107 = 0;
    zT_5EDE903E_Ctx* zT_108;
    unsigned char zT_110 = 0;
    zT_5EDE903E_Ctx* zT_111;
    zT_5EDE903E_Ctx* zT_113;
    unsigned char* zT_116;
    unsigned char* zT_117;
    unsigned int* zT_118;
    unsigned int* zT_119;
    unsigned int* zT_120;
    unsigned int* zT_121;
    unsigned int max_temp;
    zT_5EDE903E_Ctx c;
    unsigned int hti;
    zT_1937645B_TempDecl td;
    zG_78C2C6B4_g_nest_active = (unsigned char)(0);
    zT_5 = lir_fn;
    zT_6 = zF_005F8966_maxTempOf_1(zT_5);
    max_temp = zT_6;
    if ((unsigned char)(max_temp == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10.alloc = alloc;
    zT_10.reg = reg;
    zT_10.lir_fn = lir_fn;
    zT_10.max_temp = max_temp;
    zT_11 = alloc;
    zT_12 = max_temp;
    zT_15 = zF_82E88BBC_allocU32With_1(zT_11, zT_12, (unsigned int)(4294967295u));
    zT_10.t2p = zT_15;
    zT_16 = alloc;
    zT_17 = max_temp;
    zT_20 = zF_82E88BBC_allocU32With_1(zT_16, zT_17, (unsigned int)(18));
    zT_10.ttype = zT_20;
    zT_21 = alloc;
    zT_22 = max_temp;
    zT_23 = zF_730A6C2A_allocU32Raw(zT_21, zT_22);
    zT_10.rc = zT_23;
    zT_24 = alloc;
    zT_25 = max_temp;
    zT_26 = zF_730A6C2A_allocU32Raw(zT_24, zT_25);
    zT_10.wc = zT_26;
    zT_27 = alloc;
    zT_28 = max_temp;
    zT_29 = zF_F15DB413_allocU8Raw_1(zT_27, zT_28);
    zT_10.at = zT_29;
    zT_30 = alloc;
    zT_31 = max_temp;
    zT_32 = zF_F15DB413_allocU8Raw_1(zT_30, zT_31);
    zT_10.ex = zT_32;
    zT_33 = alloc;
    zT_34 = max_temp;
    zT_35 = zF_F15DB413_allocU8Raw_1(zT_33, zT_34);
    zT_10.dp = zT_35;
    zT_36 = alloc;
    zT_37 = max_temp;
    zT_38 = zF_730A6C2A_allocU32Raw(zT_36, zT_37);
    zT_10.rd_bb = zT_38;
    zT_39 = alloc;
    zT_40 = max_temp;
    zT_41 = zF_730A6C2A_allocU32Raw(zT_39, zT_40);
    zT_10.rd_ii = zT_41;
    zT_42 = alloc;
    zT_43 = max_temp;
    zT_44 = zF_F15DB413_allocU8Raw_1(zT_42, zT_43);
    zT_10.rar = zT_44;
    zT_45 = alloc;
    zT_46 = max_temp;
    zT_47 = zF_F15DB413_allocU8Raw_1(zT_45, zT_46);
    zT_10.cf = zT_47;
    zT_48 = alloc;
    zT_49 = max_temp;
    zT_50 = zF_1A0C0ABB_allocU64Raw(zT_48, zT_49);
    zT_10.cv = zT_50;
    zT_51 = alloc;
    zT_52 = max_temp;
    zT_55 = zF_82E88BBC_allocU32With_1(zT_51, zT_52, (unsigned int)(4294967295u));
    zT_10.ren = zT_55;
    zT_56 = alloc;
    zT_57 = max_temp;
    zT_58 = zF_F15DB413_allocU8Raw_1(zT_56, zT_57);
    zT_10.cand = zT_58;
    zT_59 = alloc;
    zT_60 = max_temp;
    zT_61 = zF_F15DB413_allocU8Raw_1(zT_59, zT_60);
    zT_10.depth = zT_61;
    zT_62 = alloc;
    zT_63 = max_temp;
    zT_64 = zF_730A6C2A_allocU32Raw(zT_62, zT_63);
    zT_10.df_bb = zT_64;
    zT_65 = alloc;
    zT_66 = max_temp;
    zT_67 = zF_730A6C2A_allocU32Raw(zT_65, zT_66);
    zT_10.df_ii = zT_67;
    zT_68 = alloc;
    zT_69 = max_temp;
    zT_70 = zF_F15DB413_allocU8Raw_1(zT_68, zT_69);
    zT_10.ga = zT_70;
    zT_71 = alloc;
    zT_72 = max_temp;
    zT_73 = zF_F15DB413_allocU8Raw_1(zT_71, zT_72);
    zT_10.gam = zT_73;
    c = zT_10;
    zT_75 = 0;
    hti = zT_75;
    goto z_bb_3;
    z_bb_3:
    zT_76 = lir_fn->hoisted_temps;
    zT_77 = zT_76.len;
    if ((unsigned char)(hti < zT_77)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_80 = lir_fn->hoisted_temps;
    zT_81 = zT_80.items;
    zT_82 = zT_81[hti];
    td = zT_82;
    zT_83 = td.temp_id;
    if ((unsigned char)(zT_83 < max_temp)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_95 = &c;
    zF_D6CE151A_resetScratch(zT_95);
    zT_97 = &c;
    zT_99 = zF_4AE99A73_copyPropagate(zT_97);
    (void)zT_99;
    zT_100 = &c;
    zF_6A60FAEB_scanAll(zT_100);
    zT_102 = &c;
    zT_104 = zF_7C7AB1D6_runConstFold(zT_102);
    (void)zT_104;
    zT_105 = &c;
    zT_107 = zF_E96AD22F_coalesceArgCopies(zT_105);
    (void)zT_107;
    zT_108 = &c;
    zT_110 = zF_99BE285B_coalesceJoinCopies(zT_108);
    (void)zT_110;
    zT_111 = &c;
    zF_6A60FAEB_scanAll(zT_111);
    zT_113 = &c;
    zF_02672451_computeNestMetadata(zT_113);
    zG_78C2C6B4_g_nest_active = (unsigned char)(1);
    zG_14E10714_g_nest_max = max_temp;
    zT_116 = c.cand;
    zG_30D934F4_g_nest_cand = zT_116;
    zT_117 = c.depth;
    zG_7DE170EB_g_nest_depth = zT_117;
    zT_118 = c.df_bb;
    zG_32175378_g_nest_dfbb = zT_118;
    zT_119 = c.df_ii;
    zG_5501C442_g_nest_dfii = zT_119;
    zT_120 = c.rd_bb;
    zG_46632058_g_nest_rdbb = zT_120;
    zT_121 = c.rd_ii;
    zG_694BFE22_g_nest_rdii = zT_121;
    return;
    z_bb_6:
    zT_94 = hti + (unsigned int)(1);
    hti = zT_94;
    goto z_bb_3;
    z_bb_7:
    zT_85 = (unsigned int)hti;
    zT_86 = c.t2p;
    zT_87 = td.temp_id;
    zT_88 = (unsigned int)zT_87;
    zT_86[zT_88] = zT_85;
    zT_89 = td.type_id;
    zT_90 = c.ttype;
    zT_91 = td.temp_id;
    zT_92 = (unsigned int)zT_91;
    zT_90[zT_92] = zT_89;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* allocU32With */
unsigned int* zF_82E88BBC_allocU32With_1(zT_3E40CD83_Sand* alloc, unsigned int n, unsigned int fill) {
    zT_3E40CD83_Sand* zT_4;
    zT_C6536882_EU_532 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned int* zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned char* raw;
    unsigned int* a;
    unsigned int i;
    zT_4 = alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_4, (unsigned int)((unsigned int)((unsigned int)n) * (unsigned int)(4)), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    zT_16 = (unsigned int*)raw;
    a = zT_16;
    zT_18 = 0;
    i = zT_18;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < n)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = (unsigned int)i;
    a[zT_20] = fill;
    goto z_bb_7;
    z_bb_6:
    return a;
    z_bb_7:
    zT_22 = i + (unsigned int)(1);
    i = zT_22;
    goto z_bb_4;
}

/* allocU32Raw */
unsigned int* zF_730A6C2A_allocU32Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    zT_C6536882_EU_532 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* raw;
    zT_3 = alloc;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)((unsigned int)((unsigned int)n) * (unsigned int)(4)), (unsigned int)(4));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_12 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    return (unsigned int*)((unsigned int*)raw);
}

/* allocU64Raw */
zT_79FAE712_u64* zF_1A0C0ABB_allocU64Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    zT_C6536882_EU_532 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* raw;
    zT_3 = alloc;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)((unsigned int)((unsigned int)n) * (unsigned int)(8)), (unsigned int)(4));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_12 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    return (zT_79FAE712_u64*)((zT_79FAE712_u64*)raw);
}

/* allocU8Raw */
unsigned char* zF_F15DB413_allocU8Raw_1(zT_3E40CD83_Sand* alloc, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    zT_C6536882_EU_532 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* raw;
    zT_3 = alloc;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)((unsigned int)((unsigned int)n) * (unsigned int)(1)), (unsigned int)(1));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_12 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    return (unsigned char*)((unsigned char*)raw);
}

/* __module_init */
void zF_780653D2___module_init_27(void) {
    int zT_1;
    int zT_3;
    zG_8D933C0A_kCopyPropMaxIter = (unsigned int)(128);
    zT_1 = 0;
    zG_78C2C6B4_g_nest_active = (unsigned char)((unsigned char)zT_1);
    zT_3 = 0;
    zG_14E10714_g_nest_max = (unsigned int)((unsigned int)zT_3);
    return;
}

/* EOF */
