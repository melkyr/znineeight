#include "lir_opt_pass_3842C861.h"
unsigned int zG_8D933C0A_kCopyPropMaxIter;
unsigned char zG_78C2C6B4_g_nest_active;
unsigned int zG_14E10714_g_nest_max;
unsigned char* zG_30D934F4_g_nest_cand;
unsigned char* zG_7DE170EB_g_nest_depth;
unsigned int* zG_32175378_g_nest_dfbb;
unsigned int* zG_5501C442_g_nest_dfii;
unsigned int* zG_46632058_g_nest_rdbb;
unsigned int* zG_694BFE22_g_nest_rdii;
/* lirOptNestActive */
unsigned char zF_829B1D9D_lirOptNestActive(void) {
    return zG_78C2C6B4_g_nest_active;
}

/* nestInRange */
unsigned char zF_0670982D_nestInRange(unsigned int t) {
    if ((int)(zG_78C2C6B4_g_nest_active == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((int)(t >= zG_14E10714_g_nest_max)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    return (unsigned char)(1);
}

/* lirOptNestCandidate */
unsigned char zF_0740DD14_lirOptNestCandidate(unsigned int t) {
    unsigned int zT_1;
    unsigned char zT_2 = 0;
    unsigned int zT_7;
    unsigned char zT_8;
    zT_1 = t;
    zT_2 = zF_0670982D_nestInRange(zT_1);
    if ((int)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = (unsigned int)t;
    zT_8 = zG_30D934F4_g_nest_cand[zT_7];
    return zT_8;
}

/* lirOptNestDepthOf */
unsigned char zF_03D891BD_lirOptNestDepthOf(unsigned int t) {
    unsigned int zT_1;
    unsigned char zT_2 = 0;
    unsigned int zT_7;
    unsigned char zT_8;
    zT_1 = t;
    zT_2 = zF_0670982D_nestInRange(zT_1);
    if ((int)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = (unsigned int)t;
    zT_8 = zG_7DE170EB_g_nest_depth[zT_7];
    return zT_8;
}

/* lirOptNestDefLoc */
void zF_79BC1D14_lirOptNestDefLoc(unsigned int t, unsigned int* out_bb, unsigned int* out_ii) {
    unsigned int zT_3;
    unsigned char zT_4 = 0;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_3 = t;
    zT_4 = zF_0670982D_nestInRange(zT_3);
    if ((int)(zT_4 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *out_bb = (unsigned int)(4294967295u);
    *out_ii = (unsigned int)(4294967295u);
    return;
    z_bb_2:
    zT_10 = (unsigned int)t;
    zT_11 = zG_32175378_g_nest_dfbb[zT_10];
    *out_bb = zT_11;
    zT_13 = (unsigned int)t;
    zT_14 = zG_5501C442_g_nest_dfii[zT_13];
    *out_ii = zT_14;
    return;
}

/* lirOptNestConsLoc */
void zF_9CF3FC28_lirOptNestConsLoc(unsigned int t, unsigned int* out_bb, unsigned int* out_ii) {
    unsigned int zT_3;
    unsigned char zT_4 = 0;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_14;
    zT_3 = t;
    zT_4 = zF_0670982D_nestInRange(zT_3);
    if ((int)(zT_4 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *out_bb = (unsigned int)(4294967295u);
    *out_ii = (unsigned int)(4294967295u);
    return;
    z_bb_2:
    zT_10 = (unsigned int)t;
    zT_11 = zG_46632058_g_nest_rdbb[zT_10];
    *out_bb = zT_11;
    zT_13 = (unsigned int)t;
    zT_14 = zG_694BFE22_g_nest_rdii[zT_13];
    *out_ii = zT_14;
    return;
}

/* lowMask */
zT_79FAE712_u64 zF_5E3CE23D_lowMask(unsigned int w) {
    if ((int)(w >= (unsigned int)(64))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_79FAE712_u64)(18446744073709551615ULL);
    z_bb_2:
    return (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)w)) - (zT_79FAE712_u64)(1));
}

/* sigBit */
zT_79FAE712_u64 zF_3794934D_sigBit(unsigned int w) {
    return (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(w - (unsigned int)(1))));
}

/* intKindWidth */
unsigned int zF_90DDF69C_intKindWidth(zT_33EF6BFB_TypeKind kind) {
    int zT_5;
    int zT_9;
    int zT_15;
    int zT_19;
    int zT_25;
    int zT_29;
    int zT_30;
    int zT_34;
    int zT_35;
    int zT_39;
    int zT_45;
    int zT_49;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_9 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type);
    zT_5 = zT_9;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned int)(8);
    z_bb_5:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_19 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type);
    zT_15 = zT_19;
    goto z_bb_8;
    z_bb_7:
    zT_15 = 1;
    goto z_bb_8;
    z_bb_8:
    if (zT_15) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(16);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_29 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type);
    zT_25 = zT_29;
    goto z_bb_13;
    z_bb_12:
    zT_25 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_25) goto z_bb_15; else goto z_bb_14;
    z_bb_14:
    zT_34 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    zT_30 = zT_34;
    goto z_bb_16;
    z_bb_15:
    zT_30 = 1;
    goto z_bb_16;
    z_bb_16:
    if (zT_30) goto z_bb_18; else goto z_bb_17;
    z_bb_17:
    zT_39 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type);
    zT_35 = zT_39;
    goto z_bb_19;
    z_bb_18:
    zT_35 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_35) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    return (unsigned int)(32);
    z_bb_21:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_23; else goto z_bb_22;
    z_bb_22:
    zT_49 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    zT_45 = zT_49;
    goto z_bb_24;
    z_bb_23:
    zT_45 = 1;
    goto z_bb_24;
    z_bb_24:
    if (zT_45) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned int)(64);
    z_bb_26:
    return (unsigned int)(0);
}

/* intKindSigned */
unsigned char zF_D4EA92B8_intKindSigned(zT_33EF6BFB_TypeKind kind) {
    int zT_5;
    int zT_9;
    int zT_10;
    int zT_14;
    int zT_15;
    int zT_19;
    int zT_20;
    int zT_24;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_9 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type);
    zT_5 = zT_9;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_14 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type);
    zT_10 = zT_14;
    goto z_bb_6;
    z_bb_5:
    zT_10 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_10) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_19 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type);
    zT_15 = zT_19;
    goto z_bb_9;
    z_bb_8:
    zT_15 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_15) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_24 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type);
    zT_20 = zT_24;
    goto z_bb_12;
    z_bb_11:
    zT_20 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_20) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    return (unsigned char)(0);
}

/* copyScalarKindOk */
unsigned char zF_B7E1584C_copyScalarKindOk(zT_33EF6BFB_TypeKind kind) {
    int zT_5;
    int zT_11;
    int zT_17;
    int zT_23;
    int zT_29;
    int zT_35;
    int zT_41;
    int zT_47;
    int zT_53;
    int zT_59;
    int zT_65;
    int zT_71;
    int zT_77;
    int zT_83;
    int zT_89;
    int zT_95;
    int zT_101;
    int zT_107;
    int zT_113;
    int zT_119;
    int zT_125;
    int zT_131;
    int zT_133;
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i8_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    return (unsigned char)((unsigned char)zT_5);
    z_bb_2:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i16_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = 1;
    return (unsigned char)((unsigned char)zT_11);
    z_bb_4:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i32_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 1;
    return (unsigned char)((unsigned char)zT_17);
    z_bb_6:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_23 = 1;
    return (unsigned char)((unsigned char)zT_23);
    z_bb_8:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u8_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_29 = 1;
    return (unsigned char)((unsigned char)zT_29);
    z_bb_10:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u16_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_35 = 1;
    return (unsigned char)((unsigned char)zT_35);
    z_bb_12:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u32_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_41 = 1;
    return (unsigned char)((unsigned char)zT_41);
    z_bb_14:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_47 = 1;
    return (unsigned char)((unsigned char)zT_47);
    z_bb_16:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_isize_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_53 = 1;
    return (unsigned char)((unsigned char)zT_53);
    z_bb_18:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_usize_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_59 = 1;
    return (unsigned char)((unsigned char)zT_59);
    z_bb_20:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_c_char_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_65 = 1;
    return (unsigned char)((unsigned char)zT_65);
    z_bb_22:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_71 = 1;
    return (unsigned char)((unsigned char)zT_71);
    z_bb_24:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f32_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_77 = 1;
    return (unsigned char)((unsigned char)zT_77);
    z_bb_26:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_83 = 1;
    return (unsigned char)((unsigned char)zT_83);
    z_bb_28:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_89 = 1;
    return (unsigned char)((unsigned char)zT_89);
    z_bb_30:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_95 = 1;
    return (unsigned char)((unsigned char)zT_95);
    z_bb_32:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_101 = 1;
    return (unsigned char)((unsigned char)zT_101);
    z_bb_34:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_107 = 1;
    return (unsigned char)((unsigned char)zT_107);
    z_bb_36:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_113 = 1;
    return (unsigned char)((unsigned char)zT_113);
    z_bb_38:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_uint_type))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_119 = 1;
    return (unsigned char)((unsigned char)zT_119);
    z_bb_40:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_arb_int_type))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_125 = 1;
    return (unsigned char)((unsigned char)zT_125);
    z_bb_42:
    if ((int)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_131 = 1;
    return (unsigned char)((unsigned char)zT_131);
    z_bb_44:
    zT_133 = 0;
    return (unsigned char)((unsigned char)zT_133);
}

/* allocU32 */
unsigned int* zF_43BEEDA4_allocU32(zT_5EDE903E_Ctx* c, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_0F51E4CA_EU_222 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned char* zT_14;
    unsigned char* raw;
    zT_6 = c->alloc;
    zT_3 = zT_6;
    zT_9 = (unsigned int)((unsigned int)n) * (unsigned int)(4);
    zT_4 = zT_9;
    zT_10 = 4;
    zT_5 = zT_10;
    zT_11 = zF_1395EB68_sandAlloc(zT_3, zT_4, zT_5);
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_14 = zT_11.data.payload;
    zT_13 = zT_14;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    raw = zT_13;
    raw = zT_13;
    return (unsigned int*)((unsigned int*)raw);
}

/* allocU64 */
zT_79FAE712_u64* zF_3FCBB34B_allocU64(zT_5EDE903E_Ctx* c, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_0F51E4CA_EU_222 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned char* zT_14;
    unsigned char* raw;
    zT_6 = c->alloc;
    zT_3 = zT_6;
    zT_9 = (unsigned int)((unsigned int)n) * (unsigned int)(8);
    zT_4 = zT_9;
    zT_10 = 4;
    zT_5 = zT_10;
    zT_11 = zF_1395EB68_sandAlloc(zT_3, zT_4, zT_5);
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_14 = zT_11.data.payload;
    zT_13 = zT_14;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    raw = zT_13;
    raw = zT_13;
    return (zT_79FAE712_u64*)((zT_79FAE712_u64*)raw);
}

/* allocU8 */
unsigned char* zF_76A96453_allocU8(zT_5EDE903E_Ctx* c, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_0F51E4CA_EU_222 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned char* zT_14;
    unsigned char* raw;
    zT_6 = c->alloc;
    zT_3 = zT_6;
    zT_9 = (unsigned int)((unsigned int)n) * (unsigned int)(1);
    zT_4 = zT_9;
    zT_10 = 1;
    zT_5 = zT_10;
    zT_11 = zF_1395EB68_sandAlloc(zT_3, zT_4, zT_5);
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_14 = zT_11.data.payload;
    zT_13 = zT_14;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    raw = zT_13;
    raw = zT_13;
    return (unsigned char*)((unsigned char*)raw);
}

/* maxTempOf */
unsigned int zF_005F8966_maxTempOf(zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_2;
    unsigned int zT_4;
    zT_5D72FBF8_TempDeclArrayList zT_5;
    unsigned int zT_6;
    zT_5D72FBF8_TempDeclArrayList zT_9;
    zT_1937645B_TempDecl* zT_10;
    zT_1937645B_TempDecl zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int m;
    unsigned int i;
    zT_1937645B_TempDecl td;
    zT_2 = 0;
    m = zT_2;
    m = zT_2;
    m = zT_2;
    zT_4 = 0;
    i = zT_4;
    i = zT_4;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = lir_fn->hoisted_temps;
    zT_6 = zT_5.len;
    if ((int)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = lir_fn->hoisted_temps;
    zT_10 = zT_9.items;
    zT_11 = zT_10[i];
    td = zT_11;
    td = zT_11;
    td = zT_11;
    zT_12 = td.temp_id;
    if ((int)(zT_12 >= m)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return m;
    z_bb_4:
    zT_18 = i + (unsigned int)(1);
    i = zT_18;
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = td.temp_id;
    zT_16 = zT_14 + (unsigned int)(1);
    m = zT_16;
    m = zT_16;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* resetScratch */
void zF_D6CE151A_resetScratch(zT_5EDE903E_Ctx* c) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    unsigned char zT_17;
    unsigned char* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int* zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned char zT_29;
    unsigned char* zT_30;
    unsigned int zT_31;
    zT_79FAE712_u64 zT_32;
    zT_79FAE712_u64* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int* zT_36;
    unsigned int zT_37;
    unsigned char zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    unsigned char zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int* zT_54;
    unsigned int zT_55;
    unsigned int zT_57;
    unsigned int t;
    zT_2 = 0;
    t = zT_2;
    t = zT_2;
    t = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_3 = c->max_temp;
    if ((int)(t < zT_3)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    zT_6 = c->rc;
    zT_7 = (unsigned int)t;
    zT_6[zT_7] = zT_5;
    zT_8 = 0;
    zT_9 = c->wc;
    zT_10 = (unsigned int)t;
    zT_9[zT_10] = zT_8;
    zT_11 = 0;
    zT_12 = c->at;
    zT_13 = (unsigned int)t;
    zT_12[zT_13] = zT_11;
    zT_14 = 0;
    zT_15 = c->ex;
    zT_16 = (unsigned int)t;
    zT_15[zT_16] = zT_14;
    zT_17 = 0;
    zT_18 = c->dp;
    zT_19 = (unsigned int)t;
    zT_18[zT_19] = zT_17;
    zT_20 = 0;
    zT_21 = c->rd_bb;
    zT_22 = (unsigned int)t;
    zT_21[zT_22] = zT_20;
    zT_23 = 0;
    zT_24 = c->rd_ii;
    zT_25 = (unsigned int)t;
    zT_24[zT_25] = zT_23;
    zT_26 = 0;
    zT_27 = c->rar;
    zT_28 = (unsigned int)t;
    zT_27[zT_28] = zT_26;
    zT_29 = 0;
    zT_30 = c->cf;
    zT_31 = (unsigned int)t;
    zT_30[zT_31] = zT_29;
    zT_32 = 0;
    zT_33 = c->cv;
    zT_34 = (unsigned int)t;
    zT_33[zT_34] = zT_32;
    zT_35 = 4294967295u;
    zT_36 = c->ren;
    zT_37 = (unsigned int)t;
    zT_36[zT_37] = zT_35;
    zT_38 = 0;
    zT_39 = c->cand;
    zT_40 = (unsigned int)t;
    zT_39[zT_40] = zT_38;
    zT_41 = 0;
    zT_42 = c->depth;
    zT_43 = (unsigned int)t;
    zT_42[zT_43] = zT_41;
    zT_44 = 0;
    zT_45 = c->ga;
    zT_46 = (unsigned int)t;
    zT_45[zT_46] = zT_44;
    zT_47 = 0;
    zT_48 = c->gam;
    zT_49 = (unsigned int)t;
    zT_48[zT_49] = zT_47;
    zT_50 = 4294967295u;
    zT_51 = c->df_bb;
    zT_52 = (unsigned int)t;
    zT_51[zT_52] = zT_50;
    zT_53 = 4294967295u;
    zT_54 = c->df_ii;
    zT_55 = (unsigned int)t;
    zT_54[zT_55] = zT_53;
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_57 = t + (unsigned int)(1);
    t = zT_57;
    t = zT_57;
    goto z_bb_1;
}

/* markRead */
void zF_20F1A7B4_markRead(zT_5EDE903E_Ctx* c, unsigned int t, unsigned int bb_idx, unsigned int ii) {
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_13;
    unsigned int* zT_14;
    unsigned int zT_15;
    unsigned int* zT_18;
    unsigned int* zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int* zT_24;
    unsigned int p;
    unsigned int pos;
    zT_4 = c->max_temp;
    if ((int)(t >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = c->t2p;
    zT_8 = (unsigned int)t;
    zT_9 = zT_7[zT_8];
    p = zT_9;
    p = zT_9;
    p = zT_9;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_13 = (unsigned int)p;
    pos = zT_13;
    pos = zT_13;
    pos = zT_13;
    zT_14 = c->rc;
    zT_15 = zT_14[pos];
    if ((int)(zT_15 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_18 = c->rd_bb;
    zT_18[pos] = bb_idx;
    zT_19 = c->rd_ii;
    zT_19[pos] = ii;
    goto z_bb_6;
    z_bb_6:
    zT_20 = c->rc;
    zT_21 = zT_20[pos];
    zT_23 = zT_21 + (unsigned int)(1);
    zT_24 = c->rc;
    zT_24[pos] = zT_23;
    return;
}

/* markArgRead */
void zF_8ABC4310_markArgRead(zT_5EDE903E_Ctx* c, unsigned int t, unsigned int bb_idx, unsigned int ii) {
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned int* zT_20;
    unsigned int* zT_21;
    unsigned int* zT_22;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int* zT_26;
    unsigned int p;
    unsigned int pos;
    zT_4 = c->max_temp;
    if ((int)(t >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = c->t2p;
    zT_8 = (unsigned int)t;
    zT_9 = zT_7[zT_8];
    p = zT_9;
    p = zT_9;
    p = zT_9;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_13 = (unsigned int)p;
    pos = zT_13;
    pos = zT_13;
    pos = zT_13;
    zT_14 = 1;
    zT_15 = c->rar;
    zT_15[pos] = zT_14;
    zT_16 = c->rc;
    zT_17 = zT_16[pos];
    if ((int)(zT_17 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = c->rd_bb;
    zT_20[pos] = bb_idx;
    zT_21 = c->rd_ii;
    zT_21[pos] = ii;
    goto z_bb_6;
    z_bb_6:
    zT_22 = c->rc;
    zT_23 = zT_22[pos];
    zT_25 = zT_23 + (unsigned int)(1);
    zT_26 = c->rc;
    zT_26[pos] = zT_25;
    return;
}

/* markAddrTaken */
void zF_0A9E889A_markAddrTaken(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int p;
    zT_2 = c->max_temp;
    if ((int)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = c->t2p;
    zT_6 = (unsigned int)t;
    zT_7 = zT_5[zT_6];
    p = zT_7;
    p = zT_7;
    p = zT_7;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_10 = 1;
    zT_11 = c->at;
    zT_12 = (unsigned int)p;
    zT_11[zT_12] = zT_10;
    return;
}

/* markExcluded */
void zF_2CDB40DA_markExcluded(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int p;
    zT_2 = c->max_temp;
    if ((int)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = c->t2p;
    zT_6 = (unsigned int)t;
    zT_7 = zT_5[zT_6];
    p = zT_7;
    p = zT_7;
    p = zT_7;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_10 = 1;
    zT_11 = c->ex;
    zT_12 = (unsigned int)p;
    zT_11[zT_12] = zT_10;
    return;
}

/* markGaSource */
void zF_323EFAF9_markGaSource(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned char zT_10;
    unsigned char* zT_11;
    unsigned int zT_12;
    unsigned int p;
    zT_2 = c->max_temp;
    if ((int)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = c->t2p;
    zT_6 = (unsigned int)t;
    zT_7 = zT_5[zT_6];
    p = zT_7;
    p = zT_7;
    p = zT_7;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_10 = 1;
    zT_11 = c->ga;
    zT_12 = (unsigned int)p;
    zT_11[zT_12] = zT_10;
    return;
}

/* recordConst */
void zF_83868A0F_recordConst(zT_5EDE903E_Ctx* c, unsigned int t, zT_79FAE712_u64 v) {
    unsigned int zT_3;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_13;
    zT_79FAE712_u64* zT_14;
    unsigned int zT_15;
    unsigned int p;
    zT_3 = c->max_temp;
    if ((int)(t >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)t;
    zT_8 = zT_6[zT_7];
    p = zT_8;
    p = zT_8;
    p = zT_8;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_11 = 1;
    zT_12 = c->cf;
    zT_13 = (unsigned int)p;
    zT_12[zT_13] = zT_11;
    zT_14 = c->cv;
    zT_15 = (unsigned int)p;
    zT_14[zT_15] = v;
    return;
}

/* markDef */
void zF_AAEF59B7_markDef(zT_5EDE903E_Ctx* c, unsigned int t, unsigned char is_pure) {
    unsigned int zT_3;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int* zT_16;
    unsigned int zT_17;
    unsigned char zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned int p;
    zT_3 = c->max_temp;
    if ((int)(t >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)t;
    zT_8 = zT_6[zT_7];
    p = zT_8;
    p = zT_8;
    p = zT_8;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_11 = c->wc;
    zT_12 = (unsigned int)p;
    zT_13 = zT_11[zT_12];
    zT_15 = zT_13 + (unsigned int)(1);
    zT_16 = c->wc;
    zT_17 = (unsigned int)p;
    zT_16[zT_17] = zT_15;
    if ((int)(is_pure != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = 1;
    zT_21 = c->dp;
    zT_22 = (unsigned int)p;
    zT_21[zT_22] = zT_20;
    goto z_bb_6;
    z_bb_6:
    return;
}

/* defInfoPure */
unsigned char zF_A5E11466_defInfoPure(zT_6BA597BC_LirInst inst) {
    unsigned int zT_1;
    zT_1 = inst.tag;
switch (zT_1) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 49: goto z_bb_5;
case 47: goto z_bb_6;
case 46: goto z_bb_7;
case 50: goto z_bb_8;
case 51: goto z_bb_9;
case 48: goto z_bb_10;
case 38: goto z_bb_11;
case 39: goto z_bb_12;
case 40: goto z_bb_13;
case 41: goto z_bb_14;
case 43: goto z_bb_15;
case 42: goto z_bb_16;
case 37: goto z_bb_17;
case 20: goto z_bb_18;
case 21: goto z_bb_19;
case 28: goto z_bb_20;
case 22: goto z_bb_21;
case 32: goto z_bb_22;
case 33: goto z_bb_23;
case 29: goto z_bb_24;
case 30: goto z_bb_25;
case 31: goto z_bb_26;
case 34: goto z_bb_27;
case 35: goto z_bb_28;
case 36: goto z_bb_29;
case 18: goto z_bb_30;
case 15: goto z_bb_31;
case 68: goto z_bb_32;
case 17: goto z_bb_33;
case 52: goto z_bb_34;
case 54: goto z_bb_35;
default: goto z_bb_36;
}
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    return (unsigned char)(1);
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    return (unsigned char)(1);
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    return (unsigned char)(1);
    z_bb_8:
    return (unsigned char)(1);
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    return (unsigned char)(1);
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    return (unsigned char)(1);
    z_bb_13:
    return (unsigned char)(1);
    z_bb_14:
    return (unsigned char)(1);
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(1);
    z_bb_18:
    return (unsigned char)(1);
    z_bb_19:
    return (unsigned char)(1);
    z_bb_20:
    return (unsigned char)(1);
    z_bb_21:
    return (unsigned char)(1);
    z_bb_22:
    return (unsigned char)(1);
    z_bb_23:
    return (unsigned char)(1);
    z_bb_24:
    return (unsigned char)(1);
    z_bb_25:
    return (unsigned char)(1);
    z_bb_26:
    return (unsigned char)(1);
    z_bb_27:
    return (unsigned char)(1);
    z_bb_28:
    return (unsigned char)(1);
    z_bb_29:
    return (unsigned char)(1);
    z_bb_30:
    return (unsigned char)(1);
    z_bb_31:
    return (unsigned char)(1);
    z_bb_32:
    return (unsigned char)(1);
    z_bb_33:
    return (unsigned char)(1);
    z_bb_34:
    return (unsigned char)(1);
    z_bb_35:
    return (unsigned char)(1);
    z_bb_36:
    return (unsigned char)(0);
    return 0;
}

/* defResultTemp */
unsigned int zF_CFED20F7_defResultTemp(zT_6BA597BC_LirInst inst, zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_2;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_66;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_72;
    unsigned int zT_74;
    unsigned int zT_76;
    unsigned int zT_78;
    unsigned int zT_80;
    zT_BBC23664_LirFunction* zT_83;
    unsigned int zT_84;
    zT_3BFB1E70_CallDirectData zT_85 = {0};
    unsigned int zT_86;
    zT_BBC23664_LirFunction* zT_89;
    unsigned int zT_90;
    zT_0624AC1B_TailCallData zT_91 = {0};
    unsigned int zT_92;
    unsigned int zT_94;
    unsigned int zT_96;
    zT_F5475070_anon_49111 b;
    zT_FD475D08_anon_49119 u;
    zT_2AE01EA4_anon_49339 ic;
    zT_1ECEC29F_anon_49345 fc;
    zT_9ED1CAB6_anon_49351 sc;
    zT_A2D1D102_anon_49355 nc;
    zT_A6D415E5_anon_49361 sn;
    zT_A0D40C73_anon_49367 bc;
    zT_ACD65DEE_anon_49373 uc;
    zT_24ECE125_anon_49383 ec;
    zT_9F82026D_anon_49295 ic_1;
    zT_B4D8A91D_anon_49303 fc_2;
    zT_36DBB45A_anon_49311 pc;
    zT_2EDBA7C2_anon_49319 itf;
    zT_24E01532_anon_49333 itp;
    zT_22DDD375_anon_49325 pti;
    zT_9B843AB8_anon_49285 ms;
    zT_7B4CA090_anon_49177 a;
    zT_7D30CD39_anon_49185 a_3;
    zT_216B75C4_anon_49223 fr;
    zT_0733E50E_anon_49193 w;
    zT_8F6612C0_anon_49249 w_4;
    zT_8D63D103_anon_49257 w_5;
    zT_1B6B6C52_anon_49229 u_6;
    zT_1B692DBB_anon_49235 u_7;
    zT_97661F58_anon_49241 ch;
    zT_89618C20_anon_49263 u_8;
    zT_93619BDE_anon_49269 u_9;
    zT_8B5F50AF_anon_49275 ch_10;
    zT_F9499553_anon_49165 l;
    zT_81421CA6_anon_49139 lf;
    zT_3A4E1531_anon_49479 lb;
    zT_85512D7C_anon_49159 li;
    zT_2AECEA97_anon_49389 ll;
    zT_30413980_anon_49403 lg;
    zT_73CFAC11_anon_49053 a_11;
    zT_E3D71826_anon_49063 a_12;
    zT_FBD4FF57_anon_49073 a_13;
    zT_7D3FD7C3_anon_49129 cl;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    unsigned int slot_14;
    zT_0624AC1B_TailCallData tc;
    zT_9770ACB4_anon_49209 va;
    zT_C84B2324_anon_49443 bgc;
    zT_2 = inst.tag;
switch (zT_2) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 46: goto z_bb_5;
case 47: goto z_bb_6;
case 48: goto z_bb_7;
case 49: goto z_bb_8;
case 50: goto z_bb_9;
case 51: goto z_bb_10;
case 38: goto z_bb_11;
case 39: goto z_bb_12;
case 40: goto z_bb_13;
case 41: goto z_bb_14;
case 43: goto z_bb_15;
case 42: goto z_bb_16;
case 37: goto z_bb_17;
case 20: goto z_bb_18;
case 21: goto z_bb_19;
case 28: goto z_bb_20;
case 22: goto z_bb_21;
case 32: goto z_bb_22;
case 33: goto z_bb_23;
case 29: goto z_bb_24;
case 30: goto z_bb_25;
case 31: goto z_bb_26;
case 34: goto z_bb_27;
case 35: goto z_bb_28;
case 36: goto z_bb_29;
case 18: goto z_bb_30;
case 15: goto z_bb_31;
case 68: goto z_bb_32;
case 17: goto z_bb_33;
case 52: goto z_bb_34;
case 54: goto z_bb_35;
case 2: goto z_bb_36;
case 3: goto z_bb_37;
case 4: goto z_bb_38;
case 14: goto z_bb_39;
case 23: goto z_bb_40;
case 27: goto z_bb_41;
case 25: goto z_bb_42;
case 61: goto z_bb_43;
default: goto z_bb_44;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_4 = b.result;
    return zT_4;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_6 = u.result;
    return zT_6;
    z_bb_3:
    ic = inst.payload.int_const._0;
    zT_8 = ic.result;
    return zT_8;
    z_bb_4:
    fc = inst.payload.float_const._0;
    zT_10 = fc.result;
    return zT_10;
    z_bb_5:
    sc = inst.payload.string_const._0;
    zT_12 = sc.result;
    return zT_12;
    z_bb_6:
    nc = inst.payload.null_const._0;
    zT_14 = nc.result;
    return zT_14;
    z_bb_7:
    sn = inst.payload.set_optional_null._0;
    zT_16 = sn.result;
    return zT_16;
    z_bb_8:
    bc = inst.payload.bool_const._0;
    zT_18 = bc.result;
    return zT_18;
    z_bb_9:
    uc = inst.payload.undefined_const._0;
    zT_20 = uc.result;
    return zT_20;
    z_bb_10:
    ec = inst.payload.enum_const._0;
    zT_22 = ec.result;
    return zT_22;
    z_bb_11:
    ic_1 = inst.payload.int_cast._0;
    zT_24 = ic_1.result;
    return zT_24;
    z_bb_12:
    fc_2 = inst.payload.float_cast._0;
    zT_26 = fc_2.result;
    return zT_26;
    z_bb_13:
    pc = inst.payload.ptr_cast._0;
    zT_28 = pc.result;
    return zT_28;
    z_bb_14:
    itf = inst.payload.int_to_float._0;
    zT_30 = itf.result;
    return zT_30;
    z_bb_15:
    itp = inst.payload.int_to_ptr._0;
    zT_32 = itp.result;
    return zT_32;
    z_bb_16:
    pti = inst.payload.ptr_to_int._0;
    zT_34 = pti.result;
    return zT_34;
    z_bb_17:
    ms = inst.payload.make_slice._0;
    zT_36 = ms.result;
    return zT_36;
    z_bb_18:
    a = inst.payload.addr_of._0;
    zT_38 = a.result;
    return zT_38;
    z_bb_19:
    a_3 = inst.payload.addr_of_field._0;
    zT_40 = a_3.result;
    return zT_40;
    z_bb_20:
    fr = inst.payload.func_ref._0;
    zT_42 = fr.result;
    return zT_42;
    z_bb_21:
    w = inst.payload.wrap_optional._0;
    zT_44 = w.result;
    return zT_44;
    z_bb_22:
    w_4 = inst.payload.wrap_error_ok._0;
    zT_46 = w_4.result;
    return zT_46;
    z_bb_23:
    w_5 = inst.payload.wrap_error_err._0;
    zT_48 = w_5.result;
    return zT_48;
    z_bb_24:
    u_6 = inst.payload.unwrap_optional._0;
    zT_50 = u_6.result;
    return zT_50;
    z_bb_25:
    u_7 = inst.payload.unwrap_optional_abi._0;
    zT_52 = u_7.result;
    return zT_52;
    z_bb_26:
    ch = inst.payload.check_optional._0;
    zT_54 = ch.result;
    return zT_54;
    z_bb_27:
    u_8 = inst.payload.unwrap_error_payload._0;
    zT_56 = u_8.result;
    return zT_56;
    z_bb_28:
    u_9 = inst.payload.unwrap_error_code._0;
    zT_58 = u_9.result;
    return zT_58;
    z_bb_29:
    ch_10 = inst.payload.check_error._0;
    zT_60 = ch_10.result;
    return zT_60;
    z_bb_30:
    l = inst.payload.load._0;
    zT_62 = l.result;
    return zT_62;
    z_bb_31:
    lf = inst.payload.load_field._0;
    zT_64 = lf.result;
    return zT_64;
    z_bb_32:
    lb = inst.payload.load_bitfield._0;
    zT_66 = lb.result;
    return zT_66;
    z_bb_33:
    li = inst.payload.load_index._0;
    zT_68 = li.result;
    return zT_68;
    z_bb_34:
    ll = inst.payload.load_local._0;
    zT_70 = ll.result;
    return zT_70;
    z_bb_35:
    lg = inst.payload.load_global._0;
    zT_72 = lg.result;
    return zT_72;
    z_bb_36:
    a_11 = inst.payload.assign._0;
    zT_74 = a_11.dst;
    return zT_74;
    z_bb_37:
    a_12 = inst.payload.assign_field._0;
    zT_76 = a_12.base;
    return zT_76;
    z_bb_38:
    a_13 = inst.payload.assign_index._0;
    zT_78 = a_13.base;
    return zT_78;
    z_bb_39:
    cl = inst.payload.call._0;
    zT_80 = cl.result;
    return zT_80;
    z_bb_40:
    slot = inst.payload.jump._0;
    zT_83 = lir_fn;
    zT_84 = slot;
    zT_85 = zF_75DE985C_lirSideGetCallDirec(zT_83, zT_84);
    cd = zT_85;
    cd = zT_85;
    cd = zT_85;
    zT_86 = cd.result;
    return zT_86;
    z_bb_41:
    slot_14 = inst.payload.jump._0;
    zT_89 = lir_fn;
    zT_90 = slot_14;
    zT_91 = zF_1AB3807F_lirSideGetTailCall(zT_89, zT_90);
    tc = zT_91;
    tc = zT_91;
    tc = zT_91;
    zT_92 = tc.result;
    return zT_92;
    z_bb_42:
    va = inst.payload.va_arg._0;
    zT_94 = va.result;
    return zT_94;
    z_bb_43:
    bgc = inst.payload.builtin_get_char._0;
    zT_96 = bgc.result;
    return zT_96;
    z_bb_44:
    return (unsigned int)(4294967295u);
    return 0;
}

/* scanInst */
void zF_85F6BDD8_scanInst(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst, unsigned int bb_idx, unsigned int ii) {
    zT_6BA597BC_LirInst zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_BBC23664_LirFunction* zT_7;
    unsigned int zT_8 = 0;
    zT_5EDE903E_Ctx* zT_11;
    unsigned int zT_12;
    unsigned char zT_13;
    zT_6BA597BC_LirInst zT_14;
    unsigned char zT_15 = 0;
    unsigned int zT_16;
    zT_5EDE903E_Ctx* zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_5EDE903E_Ctx* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_5EDE903E_Ctx* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_5EDE903E_Ctx* zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_5EDE903E_Ctx* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    zT_5EDE903E_Ctx* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_5EDE903E_Ctx* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_5EDE903E_Ctx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_5EDE903E_Ctx* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    zT_5EDE903E_Ctx* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_5EDE903E_Ctx* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    zT_5EDE903E_Ctx* zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    zT_5EDE903E_Ctx* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    zT_5EDE903E_Ctx* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_97;
    unsigned int zT_98;
    zT_5EDE903E_Ctx* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    unsigned int zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned int zT_107;
    zT_5EDE903E_Ctx* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    zT_5EDE903E_Ctx* zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    zT_5EDE903E_Ctx* zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_5EDE903E_Ctx* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    zT_5EDE903E_Ctx* zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    zT_5EDE903E_Ctx* zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    zT_5EDE903E_Ctx* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_5EDE903E_Ctx* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    zT_5EDE903E_Ctx* zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    zT_5EDE903E_Ctx* zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned int zT_164;
    zT_5EDE903E_Ctx* zT_165;
    unsigned int zT_166;
    unsigned int zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_5EDE903E_Ctx* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    zT_5EDE903E_Ctx* zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    zT_5EDE903E_Ctx* zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    zT_5EDE903E_Ctx* zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    zT_5EDE903E_Ctx* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    zT_BBC23664_LirFunction* zT_196;
    unsigned int zT_197;
    zT_BBC23664_LirFunction* zT_198;
    zT_3BFB1E70_CallDirectData zT_199 = {0};
    unsigned int zT_201;
    unsigned int zT_202;
    zT_5EDE903E_Ctx* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_211;
    zT_5EDE903E_Ctx* zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    zT_5EDE903E_Ctx* zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_5EDE903E_Ctx* zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    zT_5EDE903E_Ctx* zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    zT_BBC23664_LirFunction* zT_237;
    unsigned int zT_238;
    zT_BBC23664_LirFunction* zT_239;
    zT_0624AC1B_TailCallData zT_240 = {0};
    unsigned char zT_241;
    zT_5EDE903E_Ctx* zT_244;
    unsigned int zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned int zT_248;
    unsigned int zT_250;
    unsigned int zT_251;
    zT_5EDE903E_Ctx* zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    unsigned int zT_260;
    zT_5EDE903E_Ctx* zT_262;
    unsigned int zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    zT_5EDE903E_Ctx* zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int zT_271;
    unsigned int zT_272;
    zT_5EDE903E_Ctx* zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    unsigned int zT_278;
    zT_5EDE903E_Ctx* zT_280;
    unsigned int zT_281;
    unsigned int zT_282;
    unsigned int zT_283;
    unsigned int zT_284;
    zT_5EDE903E_Ctx* zT_286;
    unsigned int zT_287;
    unsigned int zT_288;
    unsigned int zT_289;
    unsigned int zT_290;
    zT_5EDE903E_Ctx* zT_292;
    unsigned int zT_293;
    unsigned int zT_294;
    unsigned int zT_295;
    unsigned int zT_296;
    zT_5EDE903E_Ctx* zT_298;
    unsigned int zT_299;
    unsigned int zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    zT_5EDE903E_Ctx* zT_304;
    unsigned int zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    zT_5EDE903E_Ctx* zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    zT_5EDE903E_Ctx* zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    zT_5EDE903E_Ctx* zT_321;
    unsigned int zT_322;
    unsigned int zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    zT_5EDE903E_Ctx* zT_327;
    unsigned int zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    zT_5EDE903E_Ctx* zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    unsigned int zT_336;
    unsigned int zT_337;
    zT_5EDE903E_Ctx* zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    zT_5EDE903E_Ctx* zT_345;
    unsigned int zT_346;
    unsigned int zT_347;
    unsigned int zT_348;
    unsigned int zT_349;
    zT_5EDE903E_Ctx* zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    unsigned int zT_354;
    unsigned int zT_355;
    zT_5EDE903E_Ctx* zT_357;
    unsigned int zT_358;
    unsigned int zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    zT_5EDE903E_Ctx* zT_363;
    unsigned int zT_364;
    unsigned int zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    zT_5EDE903E_Ctx* zT_369;
    unsigned int zT_370;
    unsigned int zT_371;
    unsigned int zT_372;
    unsigned int zT_373;
    zT_5EDE903E_Ctx* zT_375;
    unsigned int zT_376;
    unsigned int zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    zT_5EDE903E_Ctx* zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    zT_5EDE903E_Ctx* zT_386;
    unsigned int zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    zT_5EDE903E_Ctx* zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    unsigned int zT_395;
    unsigned int zT_396;
    zT_5EDE903E_Ctx* zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    unsigned int zT_400;
    unsigned int zT_401;
    zT_5EDE903E_Ctx* zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned int zT_406;
    unsigned int zT_407;
    zT_5EDE903E_Ctx* zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    zT_5EDE903E_Ctx* zT_415;
    unsigned int zT_416;
    unsigned int zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    zT_5EDE903E_Ctx* zT_420;
    unsigned int zT_421;
    unsigned int zT_422;
    unsigned int zT_423;
    unsigned int zT_424;
    zT_5EDE903E_Ctx* zT_426;
    unsigned int zT_427;
    unsigned int zT_428;
    unsigned int zT_429;
    unsigned int zT_430;
    zT_5EDE903E_Ctx* zT_431;
    unsigned int zT_432;
    unsigned int zT_433;
    unsigned int zT_434;
    unsigned int zT_435;
    zT_5EDE903E_Ctx* zT_437;
    unsigned int zT_438;
    unsigned int zT_439;
    zT_5EDE903E_Ctx* zT_440;
    unsigned int zT_441;
    unsigned int zT_442;
    zT_5EDE903E_Ctx* zT_444;
    unsigned int zT_445;
    unsigned int zT_446;
    zT_5EDE903E_Ctx* zT_448;
    unsigned int zT_449;
    zT_79FAE712_u64 zT_450;
    unsigned int zT_451;
    zT_79FAE712_u64 zT_452;
    zT_5EDE903E_Ctx* zT_454;
    unsigned int zT_455;
    zT_79FAE712_u64 zT_456;
    unsigned int zT_457;
    unsigned char zT_458;
    zT_79FAE712_u64 zT_459;
    unsigned int rp;
    zT_73CFAC11_anon_49053 a;
    zT_E3D71826_anon_49063 a_1;
    zT_FBD4FF57_anon_49073 a_2;
    zT_FBC83364_anon_49083 b;
    zT_FBC5F4CD_anon_49093 s;
    unsigned int v;
    zT_F5475070_anon_49111 b_3;
    zT_FD475D08_anon_49119 u;
    zT_7D3FD7C3_anon_49129 cl;
    unsigned int ai;
    zT_81421CA6_anon_49139 lf;
    zT_3A4E1531_anon_49479 lb;
    zT_814EE899_anon_49149 sf;
    zT_BA559A76_anon_49489 sb;
    zT_85512D7C_anon_49159 li;
    zT_F9499553_anon_49165 l;
    zT_814CAA02_anon_49171 st;
    zT_7B4CA090_anon_49177 a_4;
    zT_7D30CD39_anon_49185 a_5;
    zT_0733E50E_anon_49193 w;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_8F70A01C_anon_49201 vs;
    zT_9770ACB4_anon_49209 va;
    zT_096D8E93_anon_49213 ve;
    unsigned int slot_6;
    zT_0624AC1B_TailCallData tc;
    zT_1B6B6C52_anon_49229 u_7;
    zT_1B692DBB_anon_49235 u_8;
    zT_97661F58_anon_49241 ch;
    zT_8F6612C0_anon_49249 w_9;
    zT_8D63D103_anon_49257 w_10;
    zT_89618C20_anon_49263 u_11;
    zT_93619BDE_anon_49269 u_12;
    zT_8B5F50AF_anon_49275 ch_13;
    zT_9B843AB8_anon_49285 ms;
    zT_9F82026D_anon_49295 ic;
    zT_B4D8A91D_anon_49303 fc;
    zT_36DBB45A_anon_49311 pc;
    zT_2EDBA7C2_anon_49319 itf;
    zT_22DDD375_anon_49325 pti;
    zT_24E01532_anon_49333 itp;
    zT_22EF1C96_anon_49395 sl;
    zT_2E3EF7C3_anon_49411 sg;
    zT_C046995E_anon_49423 pv;
    zT_C4469FAA_anon_49427 bpc;
    zT_B8444E2F_anon_49433 b_14;
    zT_C2445DED_anon_49439 b_15;
    zT_C44B1CD8_anon_49447 be;
    zT_C648E167_anon_49451 bsm;
    zT_BE48D4CF_anon_49459 bcg;
    zT_32504730_anon_49465 bcc;
    zT_30413980_anon_49403 lg;
    zT_F9D2BD9A_anon_49045 dl;
    zT_2AE01EA4_anon_49339 ic_16;
    zT_A0D40C73_anon_49367 bc;
    zT_5 = inst;
    zT_7 = c->lir_fn;
    zT_6 = zT_7;
    zT_8 = zF_CFED20F7_defResultTemp(zT_5, zT_6);
    rp = zT_8;
    rp = zT_8;
    rp = zT_8;
    if ((int)(rp != (unsigned int)(4294967295u))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = c;
    zT_12 = rp;
    zT_14 = inst;
    zT_15 = zF_A5E11466_defInfoPure(zT_14);
    zT_13 = zT_15;
    zF_AAEF59B7_markDef(zT_11, zT_12, zT_13);
    goto z_bb_2;
    z_bb_2:
    zT_16 = inst.tag;
switch (zT_16) {
case 2: goto z_bb_3;
case 3: goto z_bb_4;
case 4: goto z_bb_5;
case 6: goto z_bb_6;
case 7: goto z_bb_7;
case 9: goto z_bb_8;
case 12: goto z_bb_9;
case 13: goto z_bb_10;
case 14: goto z_bb_11;
case 15: goto z_bb_12;
case 68: goto z_bb_13;
case 16: goto z_bb_14;
case 69: goto z_bb_15;
case 17: goto z_bb_16;
case 18: goto z_bb_17;
case 19: goto z_bb_18;
case 20: goto z_bb_19;
case 21: goto z_bb_20;
case 22: goto z_bb_21;
case 23: goto z_bb_22;
case 24: goto z_bb_23;
case 25: goto z_bb_24;
case 26: goto z_bb_25;
case 27: goto z_bb_26;
case 29: goto z_bb_27;
case 30: goto z_bb_28;
case 31: goto z_bb_29;
case 32: goto z_bb_30;
case 33: goto z_bb_31;
case 34: goto z_bb_32;
case 35: goto z_bb_33;
case 36: goto z_bb_34;
case 37: goto z_bb_35;
case 38: goto z_bb_36;
case 39: goto z_bb_37;
case 40: goto z_bb_38;
case 41: goto z_bb_39;
case 42: goto z_bb_40;
case 43: goto z_bb_41;
case 53: goto z_bb_42;
case 55: goto z_bb_43;
case 57: goto z_bb_44;
case 58: goto z_bb_45;
case 59: goto z_bb_46;
case 60: goto z_bb_47;
case 62: goto z_bb_48;
case 63: goto z_bb_49;
case 65: goto z_bb_50;
case 66: goto z_bb_51;
case 54: goto z_bb_52;
case 1: goto z_bb_53;
case 44: goto z_bb_54;
case 49: goto z_bb_55;
default: goto z_bb_56;
}
    z_bb_3:
    a = inst.payload.assign._0;
    zT_18 = c;
    zT_22 = a.src;
    zT_19 = zT_22;
    zT_20 = bb_idx;
    zT_21 = ii;
    zF_20F1A7B4_markRead(zT_18, zT_19, zT_20, zT_21);
    zT_23 = a.name_id;
    if ((int)(zT_23 != (unsigned int)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_4:
    a_1 = inst.payload.assign_field._0;
    zT_30 = c;
    zT_34 = a_1.base;
    zT_31 = zT_34;
    zT_32 = bb_idx;
    zT_33 = ii;
    zF_20F1A7B4_markRead(zT_30, zT_31, zT_32, zT_33);
    zT_35 = c;
    zT_39 = a_1.src;
    zT_36 = zT_39;
    zT_37 = bb_idx;
    zT_38 = ii;
    zF_20F1A7B4_markRead(zT_35, zT_36, zT_37, zT_38);
    goto z_bb_58;
    z_bb_5:
    a_2 = inst.payload.assign_index._0;
    zT_41 = c;
    zT_45 = a_2.base;
    zT_42 = zT_45;
    zT_43 = bb_idx;
    zT_44 = ii;
    zF_20F1A7B4_markRead(zT_41, zT_42, zT_43, zT_44);
    zT_46 = c;
    zT_50 = a_2.index;
    zT_47 = zT_50;
    zT_48 = bb_idx;
    zT_49 = ii;
    zF_20F1A7B4_markRead(zT_46, zT_47, zT_48, zT_49);
    zT_51 = c;
    zT_55 = a_2.src;
    zT_52 = zT_55;
    zT_53 = bb_idx;
    zT_54 = ii;
    zF_20F1A7B4_markRead(zT_51, zT_52, zT_53, zT_54);
    goto z_bb_58;
    z_bb_6:
    b = inst.payload.branch._0;
    zT_57 = c;
    zT_61 = b.cond;
    zT_58 = zT_61;
    zT_59 = bb_idx;
    zT_60 = ii;
    zF_20F1A7B4_markRead(zT_57, zT_58, zT_59, zT_60);
    goto z_bb_58;
    z_bb_7:
    s = inst.payload.switch_br._0;
    zT_63 = c;
    zT_67 = s.cond;
    zT_64 = zT_67;
    zT_65 = bb_idx;
    zT_66 = ii;
    zF_20F1A7B4_markRead(zT_63, zT_64, zT_65, zT_66);
    goto z_bb_58;
    z_bb_8:
    v = inst.payload.jump._0;
    zT_69 = c;
    zT_70 = v;
    zT_71 = bb_idx;
    zT_72 = ii;
    zF_20F1A7B4_markRead(zT_69, zT_70, zT_71, zT_72);
    goto z_bb_58;
    z_bb_9:
    b_3 = inst.payload.binary._0;
    zT_74 = c;
    zT_78 = b_3.lhs;
    zT_75 = zT_78;
    zT_76 = bb_idx;
    zT_77 = ii;
    zF_20F1A7B4_markRead(zT_74, zT_75, zT_76, zT_77);
    zT_79 = c;
    zT_83 = b_3.rhs;
    zT_80 = zT_83;
    zT_81 = bb_idx;
    zT_82 = ii;
    zF_20F1A7B4_markRead(zT_79, zT_80, zT_81, zT_82);
    goto z_bb_58;
    z_bb_10:
    u = inst.payload.unary._0;
    zT_85 = c;
    zT_89 = u.operand;
    zT_86 = zT_89;
    zT_87 = bb_idx;
    zT_88 = ii;
    zF_20F1A7B4_markRead(zT_85, zT_86, zT_87, zT_88);
    goto z_bb_58;
    z_bb_11:
    cl = inst.payload.call._0;
    zT_91 = c;
    zT_95 = cl.callee;
    zT_92 = zT_95;
    zT_93 = bb_idx;
    zT_94 = ii;
    zF_20F1A7B4_markRead(zT_91, zT_92, zT_93, zT_94);
    zT_97 = 0;
    ai = zT_97;
    ai = zT_97;
    ai = zT_97;
    goto z_bb_61;
    z_bb_12:
    lf = inst.payload.load_field._0;
    zT_109 = c;
    zT_113 = lf.base;
    zT_110 = zT_113;
    zT_111 = bb_idx;
    zT_112 = ii;
    zF_20F1A7B4_markRead(zT_109, zT_110, zT_111, zT_112);
    goto z_bb_58;
    z_bb_13:
    lb = inst.payload.load_bitfield._0;
    zT_115 = c;
    zT_119 = lb.base;
    zT_116 = zT_119;
    zT_117 = bb_idx;
    zT_118 = ii;
    zF_20F1A7B4_markRead(zT_115, zT_116, zT_117, zT_118);
    goto z_bb_58;
    z_bb_14:
    sf = inst.payload.store_field._0;
    zT_121 = c;
    zT_125 = sf.base;
    zT_122 = zT_125;
    zT_123 = bb_idx;
    zT_124 = ii;
    zF_20F1A7B4_markRead(zT_121, zT_122, zT_123, zT_124);
    zT_126 = c;
    zT_130 = sf.value;
    zT_127 = zT_130;
    zT_128 = bb_idx;
    zT_129 = ii;
    zF_20F1A7B4_markRead(zT_126, zT_127, zT_128, zT_129);
    goto z_bb_58;
    z_bb_15:
    sb = inst.payload.store_bitfield._0;
    zT_132 = c;
    zT_136 = sb.base;
    zT_133 = zT_136;
    zT_134 = bb_idx;
    zT_135 = ii;
    zF_20F1A7B4_markRead(zT_132, zT_133, zT_134, zT_135);
    zT_137 = c;
    zT_141 = sb.value;
    zT_138 = zT_141;
    zT_139 = bb_idx;
    zT_140 = ii;
    zF_20F1A7B4_markRead(zT_137, zT_138, zT_139, zT_140);
    goto z_bb_58;
    z_bb_16:
    li = inst.payload.load_index._0;
    zT_143 = c;
    zT_147 = li.base;
    zT_144 = zT_147;
    zT_145 = bb_idx;
    zT_146 = ii;
    zF_20F1A7B4_markRead(zT_143, zT_144, zT_145, zT_146);
    zT_148 = c;
    zT_152 = li.index;
    zT_149 = zT_152;
    zT_150 = bb_idx;
    zT_151 = ii;
    zF_20F1A7B4_markRead(zT_148, zT_149, zT_150, zT_151);
    goto z_bb_58;
    z_bb_17:
    l = inst.payload.load._0;
    zT_154 = c;
    zT_158 = l.ptr;
    zT_155 = zT_158;
    zT_156 = bb_idx;
    zT_157 = ii;
    zF_20F1A7B4_markRead(zT_154, zT_155, zT_156, zT_157);
    goto z_bb_58;
    z_bb_18:
    st = inst.payload.store._0;
    zT_160 = c;
    zT_164 = st.ptr;
    zT_161 = zT_164;
    zT_162 = bb_idx;
    zT_163 = ii;
    zF_20F1A7B4_markRead(zT_160, zT_161, zT_162, zT_163);
    zT_165 = c;
    zT_169 = st.value;
    zT_166 = zT_169;
    zT_167 = bb_idx;
    zT_168 = ii;
    zF_20F1A7B4_markRead(zT_165, zT_166, zT_167, zT_168);
    goto z_bb_58;
    z_bb_19:
    a_4 = inst.payload.addr_of._0;
    zT_171 = c;
    zT_175 = a_4.operand;
    zT_172 = zT_175;
    zT_173 = bb_idx;
    zT_174 = ii;
    zF_20F1A7B4_markRead(zT_171, zT_172, zT_173, zT_174);
    zT_176 = c;
    zT_178 = a_4.operand;
    zT_177 = zT_178;
    zF_0A9E889A_markAddrTaken(zT_176, zT_177);
    goto z_bb_58;
    z_bb_20:
    a_5 = inst.payload.addr_of_field._0;
    zT_180 = c;
    zT_184 = a_5.base;
    zT_181 = zT_184;
    zT_182 = bb_idx;
    zT_183 = ii;
    zF_20F1A7B4_markRead(zT_180, zT_181, zT_182, zT_183);
    zT_185 = c;
    zT_187 = a_5.base;
    zT_186 = zT_187;
    zF_0A9E889A_markAddrTaken(zT_185, zT_186);
    goto z_bb_58;
    z_bb_21:
    w = inst.payload.wrap_optional._0;
    zT_189 = c;
    zT_193 = w.value;
    zT_190 = zT_193;
    zT_191 = bb_idx;
    zT_192 = ii;
    zF_20F1A7B4_markRead(zT_189, zT_190, zT_191, zT_192);
    goto z_bb_58;
    z_bb_22:
    slot = inst.payload.jump._0;
    zT_198 = c->lir_fn;
    zT_196 = zT_198;
    zT_197 = slot;
    zT_199 = zF_75DE985C_lirSideGetCallDirec(zT_196, zT_197);
    cd = zT_199;
    cd = zT_199;
    cd = zT_199;
    zT_201 = 0;
    ai = zT_201;
    ai = zT_201;
    ai = zT_201;
    goto z_bb_65;
    z_bb_23:
    vs = inst.payload.va_start._0;
    zT_213 = c;
    zT_217 = vs.va_list_temp;
    zT_214 = zT_217;
    zT_215 = bb_idx;
    zT_216 = ii;
    zF_20F1A7B4_markRead(zT_213, zT_214, zT_215, zT_216);
    zT_218 = c;
    zT_222 = vs.last_param_temp;
    zT_219 = zT_222;
    zT_220 = bb_idx;
    zT_221 = ii;
    zF_20F1A7B4_markRead(zT_218, zT_219, zT_220, zT_221);
    goto z_bb_58;
    z_bb_24:
    va = inst.payload.va_arg._0;
    zT_224 = c;
    zT_228 = va.va_list_temp;
    zT_225 = zT_228;
    zT_226 = bb_idx;
    zT_227 = ii;
    zF_20F1A7B4_markRead(zT_224, zT_225, zT_226, zT_227);
    goto z_bb_58;
    z_bb_25:
    ve = inst.payload.va_end._0;
    zT_230 = c;
    zT_234 = ve.va_list_temp;
    zT_231 = zT_234;
    zT_232 = bb_idx;
    zT_233 = ii;
    zF_20F1A7B4_markRead(zT_230, zT_231, zT_232, zT_233);
    goto z_bb_58;
    z_bb_26:
    slot_6 = inst.payload.jump._0;
    zT_239 = c->lir_fn;
    zT_237 = zT_239;
    zT_238 = slot_6;
    zT_240 = zF_1AB3807F_lirSideGetTailCall(zT_237, zT_238);
    tc = zT_240;
    tc = zT_240;
    tc = zT_240;
    zT_241 = tc.is_indirect;
    if ((int)(zT_241 != (unsigned char)(0))) goto z_bb_69; else goto z_bb_70;
    z_bb_27:
    u_7 = inst.payload.unwrap_optional._0;
    zT_262 = c;
    zT_266 = u_7.value;
    zT_263 = zT_266;
    zT_264 = bb_idx;
    zT_265 = ii;
    zF_20F1A7B4_markRead(zT_262, zT_263, zT_264, zT_265);
    goto z_bb_58;
    z_bb_28:
    u_8 = inst.payload.unwrap_optional_abi._0;
    zT_268 = c;
    zT_272 = u_8.value;
    zT_269 = zT_272;
    zT_270 = bb_idx;
    zT_271 = ii;
    zF_20F1A7B4_markRead(zT_268, zT_269, zT_270, zT_271);
    goto z_bb_58;
    z_bb_29:
    ch = inst.payload.check_optional._0;
    zT_274 = c;
    zT_278 = ch.value;
    zT_275 = zT_278;
    zT_276 = bb_idx;
    zT_277 = ii;
    zF_20F1A7B4_markRead(zT_274, zT_275, zT_276, zT_277);
    goto z_bb_58;
    z_bb_30:
    w_9 = inst.payload.wrap_error_ok._0;
    zT_280 = c;
    zT_284 = w_9.value;
    zT_281 = zT_284;
    zT_282 = bb_idx;
    zT_283 = ii;
    zF_20F1A7B4_markRead(zT_280, zT_281, zT_282, zT_283);
    goto z_bb_58;
    z_bb_31:
    w_10 = inst.payload.wrap_error_err._0;
    zT_286 = c;
    zT_290 = w_10.value;
    zT_287 = zT_290;
    zT_288 = bb_idx;
    zT_289 = ii;
    zF_20F1A7B4_markRead(zT_286, zT_287, zT_288, zT_289);
    goto z_bb_58;
    z_bb_32:
    u_11 = inst.payload.unwrap_error_payload._0;
    zT_292 = c;
    zT_296 = u_11.value;
    zT_293 = zT_296;
    zT_294 = bb_idx;
    zT_295 = ii;
    zF_20F1A7B4_markRead(zT_292, zT_293, zT_294, zT_295);
    goto z_bb_58;
    z_bb_33:
    u_12 = inst.payload.unwrap_error_code._0;
    zT_298 = c;
    zT_302 = u_12.value;
    zT_299 = zT_302;
    zT_300 = bb_idx;
    zT_301 = ii;
    zF_20F1A7B4_markRead(zT_298, zT_299, zT_300, zT_301);
    goto z_bb_58;
    z_bb_34:
    ch_13 = inst.payload.check_error._0;
    zT_304 = c;
    zT_308 = ch_13.value;
    zT_305 = zT_308;
    zT_306 = bb_idx;
    zT_307 = ii;
    zF_20F1A7B4_markRead(zT_304, zT_305, zT_306, zT_307);
    goto z_bb_58;
    z_bb_35:
    ms = inst.payload.make_slice._0;
    zT_310 = c;
    zT_314 = ms.ptr;
    zT_311 = zT_314;
    zT_312 = bb_idx;
    zT_313 = ii;
    zF_20F1A7B4_markRead(zT_310, zT_311, zT_312, zT_313);
    zT_315 = c;
    zT_319 = ms.len;
    zT_316 = zT_319;
    zT_317 = bb_idx;
    zT_318 = ii;
    zF_20F1A7B4_markRead(zT_315, zT_316, zT_317, zT_318);
    goto z_bb_58;
    z_bb_36:
    ic = inst.payload.int_cast._0;
    zT_321 = c;
    zT_325 = ic.value;
    zT_322 = zT_325;
    zT_323 = bb_idx;
    zT_324 = ii;
    zF_20F1A7B4_markRead(zT_321, zT_322, zT_323, zT_324);
    goto z_bb_58;
    z_bb_37:
    fc = inst.payload.float_cast._0;
    zT_327 = c;
    zT_331 = fc.value;
    zT_328 = zT_331;
    zT_329 = bb_idx;
    zT_330 = ii;
    zF_20F1A7B4_markRead(zT_327, zT_328, zT_329, zT_330);
    goto z_bb_58;
    z_bb_38:
    pc = inst.payload.ptr_cast._0;
    zT_333 = c;
    zT_337 = pc.value;
    zT_334 = zT_337;
    zT_335 = bb_idx;
    zT_336 = ii;
    zF_20F1A7B4_markRead(zT_333, zT_334, zT_335, zT_336);
    goto z_bb_58;
    z_bb_39:
    itf = inst.payload.int_to_float._0;
    zT_339 = c;
    zT_343 = itf.value;
    zT_340 = zT_343;
    zT_341 = bb_idx;
    zT_342 = ii;
    zF_20F1A7B4_markRead(zT_339, zT_340, zT_341, zT_342);
    goto z_bb_58;
    z_bb_40:
    pti = inst.payload.ptr_to_int._0;
    zT_345 = c;
    zT_349 = pti.value;
    zT_346 = zT_349;
    zT_347 = bb_idx;
    zT_348 = ii;
    zF_20F1A7B4_markRead(zT_345, zT_346, zT_347, zT_348);
    goto z_bb_58;
    z_bb_41:
    itp = inst.payload.int_to_ptr._0;
    zT_351 = c;
    zT_355 = itp.value;
    zT_352 = zT_355;
    zT_353 = bb_idx;
    zT_354 = ii;
    zF_20F1A7B4_markRead(zT_351, zT_352, zT_353, zT_354);
    goto z_bb_58;
    z_bb_42:
    sl = inst.payload.store_local._0;
    zT_357 = c;
    zT_361 = sl.value;
    zT_358 = zT_361;
    zT_359 = bb_idx;
    zT_360 = ii;
    zF_20F1A7B4_markRead(zT_357, zT_358, zT_359, zT_360);
    goto z_bb_58;
    z_bb_43:
    sg = inst.payload.store_global._0;
    zT_363 = c;
    zT_367 = sg.value;
    zT_364 = zT_367;
    zT_365 = bb_idx;
    zT_366 = ii;
    zF_20F1A7B4_markRead(zT_363, zT_364, zT_365, zT_366);
    goto z_bb_58;
    z_bb_44:
    pv = inst.payload.print_val._0;
    zT_369 = c;
    zT_373 = pv.value;
    zT_370 = zT_373;
    zT_371 = bb_idx;
    zT_372 = ii;
    zF_20F1A7B4_markRead(zT_369, zT_370, zT_371, zT_372);
    goto z_bb_58;
    z_bb_45:
    bpc = inst.payload.builtin_put_char._0;
    zT_375 = c;
    zT_379 = bpc.value;
    zT_376 = zT_379;
    zT_377 = bb_idx;
    zT_378 = ii;
    zF_20F1A7B4_markRead(zT_375, zT_376, zT_377, zT_378);
    goto z_bb_58;
    z_bb_46:
    b_14 = inst.payload.builtin_stdout_write._0;
    zT_381 = c;
    zT_385 = b_14.ptr;
    zT_382 = zT_385;
    zT_383 = bb_idx;
    zT_384 = ii;
    zF_20F1A7B4_markRead(zT_381, zT_382, zT_383, zT_384);
    zT_386 = c;
    zT_390 = b_14.len;
    zT_387 = zT_390;
    zT_388 = bb_idx;
    zT_389 = ii;
    zF_20F1A7B4_markRead(zT_386, zT_387, zT_388, zT_389);
    goto z_bb_58;
    z_bb_47:
    b_15 = inst.payload.builtin_stderr_write._0;
    zT_392 = c;
    zT_396 = b_15.ptr;
    zT_393 = zT_396;
    zT_394 = bb_idx;
    zT_395 = ii;
    zF_20F1A7B4_markRead(zT_392, zT_393, zT_394, zT_395);
    zT_397 = c;
    zT_401 = b_15.len;
    zT_398 = zT_401;
    zT_399 = bb_idx;
    zT_400 = ii;
    zF_20F1A7B4_markRead(zT_397, zT_398, zT_399, zT_400);
    goto z_bb_58;
    z_bb_48:
    be = inst.payload.builtin_exit._0;
    zT_403 = c;
    zT_407 = be.value;
    zT_404 = zT_407;
    zT_405 = bb_idx;
    zT_406 = ii;
    zF_20F1A7B4_markRead(zT_403, zT_404, zT_405, zT_406);
    goto z_bb_58;
    z_bb_49:
    bsm = inst.payload.builtin_sleep_ms._0;
    zT_409 = c;
    zT_413 = bsm.value;
    zT_410 = zT_413;
    zT_411 = bb_idx;
    zT_412 = ii;
    zF_20F1A7B4_markRead(zT_409, zT_410, zT_411, zT_412);
    goto z_bb_58;
    z_bb_50:
    bcg = inst.payload.builtin_console_gotoxy._0;
    zT_415 = c;
    zT_419 = bcg.x;
    zT_416 = zT_419;
    zT_417 = bb_idx;
    zT_418 = ii;
    zF_20F1A7B4_markRead(zT_415, zT_416, zT_417, zT_418);
    zT_420 = c;
    zT_424 = bcg.y;
    zT_421 = zT_424;
    zT_422 = bb_idx;
    zT_423 = ii;
    zF_20F1A7B4_markRead(zT_420, zT_421, zT_422, zT_423);
    goto z_bb_58;
    z_bb_51:
    bcc = inst.payload.builtin_console_set_color._0;
    zT_426 = c;
    zT_430 = bcc.fg;
    zT_427 = zT_430;
    zT_428 = bb_idx;
    zT_429 = ii;
    zF_20F1A7B4_markRead(zT_426, zT_427, zT_428, zT_429);
    zT_431 = c;
    zT_435 = bcc.bg;
    zT_432 = zT_435;
    zT_433 = bb_idx;
    zT_434 = ii;
    zF_20F1A7B4_markRead(zT_431, zT_432, zT_433, zT_434);
    goto z_bb_58;
    z_bb_52:
    lg = inst.payload.load_global._0;
    zT_437 = c;
    zT_439 = lg.result;
    zT_438 = zT_439;
    zF_2CDB40DA_markExcluded(zT_437, zT_438);
    zT_440 = c;
    zT_442 = lg.result;
    zT_441 = zT_442;
    zF_323EFAF9_markGaSource(zT_440, zT_441);
    goto z_bb_58;
    z_bb_53:
    dl = inst.payload.decl_local._0;
    zT_444 = c;
    zT_446 = dl.temp;
    zT_445 = zT_446;
    zF_2CDB40DA_markExcluded(zT_444, zT_445);
    goto z_bb_58;
    z_bb_54:
    ic_16 = inst.payload.int_const._0;
    zT_448 = c;
    zT_451 = ic_16.result;
    zT_449 = zT_451;
    zT_452 = ic_16.value;
    zT_450 = zT_452;
    zF_83868A0F_recordConst(zT_448, zT_449, zT_450);
    goto z_bb_58;
    z_bb_55:
    bc = inst.payload.bool_const._0;
    zT_454 = c;
    zT_457 = bc.result;
    zT_455 = zT_457;
    zT_458 = bc.value;
    zT_459 = (zT_79FAE712_u64)zT_458;
    zT_456 = zT_459;
    zF_83868A0F_recordConst(zT_454, zT_455, zT_456);
    goto z_bb_58;
    z_bb_56:
    goto z_bb_58;
    z_bb_58:
    return;
    z_bb_59:
    zT_26 = c;
    zT_28 = a.dst;
    zT_27 = zT_28;
    zF_2CDB40DA_markExcluded(zT_26, zT_27);
    goto z_bb_60;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    zT_98 = cl.args_count;
    if ((int)(ai < zT_98)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_100 = c;
    zT_104 = cl.args_start;
    zT_105 = zT_104 + ai;
    zT_101 = zT_105;
    zT_102 = bb_idx;
    zT_103 = ii;
    zF_8ABC4310_markArgRead(zT_100, zT_101, zT_102, zT_103);
    goto z_bb_64;
    z_bb_63:
    goto z_bb_58;
    z_bb_64:
    zT_107 = ai + (unsigned int)(1);
    ai = zT_107;
    ai = zT_107;
    goto z_bb_61;
    z_bb_65:
    zT_202 = cd.args_count;
    if ((int)(ai < zT_202)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_204 = c;
    zT_208 = cd.args_start;
    zT_209 = zT_208 + ai;
    zT_205 = zT_209;
    zT_206 = bb_idx;
    zT_207 = ii;
    zF_8ABC4310_markArgRead(zT_204, zT_205, zT_206, zT_207);
    goto z_bb_68;
    z_bb_67:
    goto z_bb_58;
    z_bb_68:
    zT_211 = ai + (unsigned int)(1);
    ai = zT_211;
    ai = zT_211;
    goto z_bb_65;
    z_bb_69:
    zT_244 = c;
    zT_248 = tc.callee;
    zT_245 = zT_248;
    zT_246 = bb_idx;
    zT_247 = ii;
    zF_8ABC4310_markArgRead(zT_244, zT_245, zT_246, zT_247);
    goto z_bb_70;
    z_bb_70:
    zT_250 = 0;
    ai = zT_250;
    ai = zT_250;
    ai = zT_250;
    goto z_bb_71;
    z_bb_71:
    zT_251 = tc.args_count;
    if ((int)(ai < zT_251)) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_253 = c;
    zT_257 = tc.args_start;
    zT_258 = zT_257 + ai;
    zT_254 = zT_258;
    zT_255 = bb_idx;
    zT_256 = ii;
    zF_8ABC4310_markArgRead(zT_253, zT_254, zT_255, zT_256);
    goto z_bb_74;
    z_bb_73:
    goto z_bb_58;
    z_bb_74:
    zT_260 = ai + (unsigned int)(1);
    ai = zT_260;
    ai = zT_260;
    goto z_bb_71;
}

/* scanAll */
void zF_6A60FAEB_scanAll(zT_5EDE903E_Ctx* c) {
    zT_5EDE903E_Ctx* zT_1;
    unsigned int zT_3;
    zT_BBC23664_LirFunction* zT_4;
    zT_1CF28CA3_BasicBlockArrayList zT_5;
    unsigned int zT_6;
    zT_BBC23664_LirFunction* zT_9;
    zT_1CF28CA3_BasicBlockArrayList zT_10;
    zT_88A68B1A_BasicBlock* zT_11;
    zT_88A68B1A_BasicBlock* zT_12;
    unsigned int zT_14;
    zT_DAE4631D_LirInstArrayList zT_15;
    unsigned int zT_16;
    zT_5EDE903E_Ctx* zT_18;
    zT_6BA597BC_LirInst zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_DAE4631D_LirInstArrayList zT_22;
    zT_6BA597BC_LirInst* zT_23;
    zT_6BA597BC_LirInst zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    zT_BBC23664_LirFunction* zT_33;
    zT_CFE23D0A_LirParamArrayList zT_34;
    unsigned int zT_35;
    zT_5EDE903E_Ctx* zT_37;
    unsigned int zT_38;
    zT_BBC23664_LirFunction* zT_39;
    zT_CFE23D0A_LirParamArrayList zT_40;
    zT_8779209D_LirParam* zT_41;
    zT_8779209D_LirParam zT_42;
    unsigned int zT_43;
    unsigned int zT_45;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    unsigned int pi;
    zT_1 = c;
    zF_D6CE151A_resetScratch(zT_1);
    zT_3 = 0;
    bi = zT_3;
    bi = zT_3;
    bi = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = c->lir_fn;
    zT_5 = zT_4->blocks;
    zT_6 = zT_5.len;
    if ((int)(bi < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = c->lir_fn;
    zT_10 = zT_9->blocks;
    zT_11 = zT_10.items;
    zT_12 = zT_11 + bi;
    bb = zT_12;
    bb = zT_12;
    bb = zT_12;
    zT_14 = 0;
    ii = zT_14;
    ii = zT_14;
    ii = zT_14;
    goto z_bb_5;
    z_bb_3:
    zT_32 = 0;
    pi = zT_32;
    pi = zT_32;
    pi = zT_32;
    goto z_bb_9;
    z_bb_4:
    zT_30 = bi + (unsigned int)(1);
    bi = zT_30;
    bi = zT_30;
    goto z_bb_1;
    z_bb_5:
    zT_15 = bb->insts;
    zT_16 = zT_15.len;
    if ((int)(ii < zT_16)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_18 = c;
    zT_22 = bb->insts;
    zT_23 = zT_22.items;
    zT_24 = zT_23[ii];
    zT_19 = zT_24;
    zT_25 = (unsigned int)bi;
    zT_20 = zT_25;
    zT_26 = (unsigned int)ii;
    zT_21 = zT_26;
    zF_85F6BDD8_scanInst(zT_18, zT_19, zT_20, zT_21);
    goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_28 = ii + (unsigned int)(1);
    ii = zT_28;
    ii = zT_28;
    goto z_bb_5;
    z_bb_9:
    zT_33 = c->lir_fn;
    zT_34 = zT_33->params;
    zT_35 = zT_34.len;
    if ((int)(pi < zT_35)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_37 = c;
    zT_39 = c->lir_fn;
    zT_40 = zT_39->params;
    zT_41 = zT_40.items;
    zT_42 = zT_41[pi];
    zT_43 = zT_42.temp_id;
    zT_38 = zT_43;
    zF_2CDB40DA_markExcluded(zT_37, zT_38);
    goto z_bb_12;
    z_bb_11:
    return;
    z_bb_12:
    zT_45 = pi + (unsigned int)(1);
    pi = zT_45;
    pi = zT_45;
    goto z_bb_9;
}

/* depthOfTemp */
unsigned char zF_122C0CBD_depthOfTemp(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char* zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned char* zT_19;
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    unsigned int* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    zT_BBC23664_LirFunction* zT_41;
    zT_1CF28CA3_BasicBlockArrayList zT_42;
    zT_88A68B1A_BasicBlock* zT_43;
    zT_88A68B1A_BasicBlock* zT_45;
    zT_DAE4631D_LirInstArrayList zT_47;
    zT_6BA597BC_LirInst* zT_48;
    unsigned int* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_6BA597BC_LirInst zT_53;
    zT_5EDE903E_Ctx* zT_55;
    zT_6BA597BC_LirInst zT_56;
    unsigned char zT_57 = 0;
    unsigned int zT_61;
    unsigned int zT_64;
    unsigned char zT_65;
    unsigned char* zT_66;
    unsigned int zT_67;
    unsigned char* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    unsigned int pos;
    unsigned char d;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    zT_6BA597BC_LirInst inst;
    unsigned char mx;
    unsigned int r;
    zT_2 = c->max_temp;
    if ((int)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)t;
    zT_8 = zT_6[zT_7];
    pos = zT_8;
    pos = zT_8;
    pos = zT_8;
    if ((int)(pos == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_12 = c->cand;
    zT_13 = (unsigned int)t;
    zT_14 = zT_12[zT_13];
    if ((int)(zT_14 == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_19 = c->depth;
    zT_20 = (unsigned int)t;
    zT_21 = zT_19[zT_20];
    d = zT_21;
    d = zT_21;
    d = zT_21;
    if ((int)(d == (unsigned char)(255))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(255);
    z_bb_8:
    if ((int)(d != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return d;
    z_bb_10:
    zT_27 = 255;
    zT_28 = c->depth;
    zT_29 = (unsigned int)t;
    zT_28[zT_29] = zT_27;
    zT_31 = c->df_bb;
    zT_32 = (unsigned int)t;
    zT_33 = zT_31[zT_32];
    bi = zT_33;
    bi = zT_33;
    bi = zT_33;
    if ((int)(bi == (unsigned int)(4294967295u))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_36 = 1;
    zT_37 = c->depth;
    zT_38 = (unsigned int)t;
    zT_37[zT_38] = zT_36;
    return (unsigned char)(1);
    z_bb_12:
    zT_41 = c->lir_fn;
    zT_42 = zT_41->blocks;
    zT_43 = zT_42.items;
    zT_45 = zT_43 + (unsigned int)((unsigned int)bi);
    bb = zT_45;
    bb = zT_45;
    bb = zT_45;
    zT_47 = bb->insts;
    zT_48 = zT_47.items;
    zT_49 = c->df_ii;
    zT_50 = (unsigned int)t;
    zT_51 = zT_49[zT_50];
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_48[zT_52];
    inst = zT_53;
    inst = zT_53;
    inst = zT_53;
    zT_55 = c;
    zT_56 = inst;
    zT_57 = zF_B27E2943_maxOperandDepth(zT_55, zT_56);
    mx = zT_57;
    mx = zT_57;
    mx = zT_57;
    zT_61 = (unsigned int)((unsigned int)mx) + (unsigned int)(1);
    r = zT_61;
    r = zT_61;
    r = zT_61;
    if ((int)(r > (unsigned int)(255))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_64 = 255;
    r = zT_64;
    r = zT_64;
    goto z_bb_14;
    z_bb_14:
    zT_65 = __bootstrap_u8_from_u32(r);
    zT_66 = c->depth;
    zT_67 = (unsigned int)t;
    zT_66[zT_67] = zT_65;
    zT_68 = c->depth;
    zT_69 = (unsigned int)t;
    zT_70 = zT_68[zT_69];
    return zT_70;
}

/* maxOperandDepth */
unsigned char zF_B27E2943_maxOperandDepth(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst) {
    unsigned char zT_3;
    unsigned int zT_4;
    zT_5EDE903E_Ctx* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char zT_9 = 0;
    zT_5EDE903E_Ctx* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_14 = 0;
    zT_5EDE903E_Ctx* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned char zT_20 = 0;
    zT_5EDE903E_Ctx* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_25 = 0;
    zT_5EDE903E_Ctx* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned char zT_30 = 0;
    zT_5EDE903E_Ctx* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned char zT_35 = 0;
    zT_5EDE903E_Ctx* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_40 = 0;
    zT_5EDE903E_Ctx* zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned char zT_45 = 0;
    zT_5EDE903E_Ctx* zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned char zT_50 = 0;
    zT_5EDE903E_Ctx* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char zT_55 = 0;
    zT_5EDE903E_Ctx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned char zT_60 = 0;
    zT_5EDE903E_Ctx* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_66 = 0;
    zT_5EDE903E_Ctx* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_71 = 0;
    zT_5EDE903E_Ctx* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned char zT_76 = 0;
    zT_5EDE903E_Ctx* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_81 = 0;
    zT_5EDE903E_Ctx* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_86 = 0;
    zT_5EDE903E_Ctx* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned char zT_91 = 0;
    zT_5EDE903E_Ctx* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned char zT_96 = 0;
    zT_5EDE903E_Ctx* zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned char zT_101 = 0;
    zT_5EDE903E_Ctx* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_106 = 0;
    zT_5EDE903E_Ctx* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned char zT_111 = 0;
    zT_5EDE903E_Ctx* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned char zT_116 = 0;
    zT_5EDE903E_Ctx* zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned char zT_121 = 0;
    zT_5EDE903E_Ctx* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned char zT_126 = 0;
    zT_5EDE903E_Ctx* zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned char zT_131 = 0;
    zT_5EDE903E_Ctx* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned char zT_136 = 0;
    zT_5EDE903E_Ctx* zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned char zT_141 = 0;
    unsigned char mx;
    zT_F5475070_anon_49111 b;
    unsigned char r;
    zT_FD475D08_anon_49119 u;
    zT_9F82026D_anon_49295 ic;
    zT_B4D8A91D_anon_49303 fc;
    zT_36DBB45A_anon_49311 pc;
    zT_2EDBA7C2_anon_49319 itf;
    zT_22DDD375_anon_49325 pti;
    zT_24E01532_anon_49333 itp;
    zT_9B843AB8_anon_49285 ms;
    zT_7B4CA090_anon_49177 a;
    zT_7D30CD39_anon_49185 a_1;
    zT_0733E50E_anon_49193 w;
    zT_8F6612C0_anon_49249 w_2;
    zT_8D63D103_anon_49257 w_3;
    zT_1B6B6C52_anon_49229 u_4;
    zT_1B692DBB_anon_49235 u_5;
    zT_97661F58_anon_49241 ch;
    zT_89618C20_anon_49263 u_6;
    zT_93619BDE_anon_49269 u_7;
    zT_8B5F50AF_anon_49275 ch_8;
    zT_F9499553_anon_49165 l;
    zT_81421CA6_anon_49139 lf;
    zT_3A4E1531_anon_49479 lb;
    zT_85512D7C_anon_49159 li;
    zT_3 = 0;
    mx = zT_3;
    mx = zT_3;
    mx = zT_3;
    zT_4 = inst.tag;
switch (zT_4) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 38: goto z_bb_3;
case 39: goto z_bb_4;
case 40: goto z_bb_5;
case 41: goto z_bb_6;
case 42: goto z_bb_7;
case 43: goto z_bb_8;
case 37: goto z_bb_9;
case 20: goto z_bb_10;
case 21: goto z_bb_11;
case 22: goto z_bb_12;
case 32: goto z_bb_13;
case 33: goto z_bb_14;
case 29: goto z_bb_15;
case 30: goto z_bb_16;
case 31: goto z_bb_17;
case 34: goto z_bb_18;
case 35: goto z_bb_19;
case 36: goto z_bb_20;
case 18: goto z_bb_21;
case 15: goto z_bb_22;
case 68: goto z_bb_23;
case 17: goto z_bb_24;
default: goto z_bb_25;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_6 = c;
    zT_8 = b.lhs;
    zT_7 = zT_8;
    zT_9 = zF_122C0CBD_depthOfTemp(zT_6, zT_7);
    mx = zT_9;
    mx = zT_9;
    zT_11 = c;
    zT_13 = b.rhs;
    zT_12 = zT_13;
    zT_14 = zF_122C0CBD_depthOfTemp(zT_11, zT_12);
    r = zT_14;
    r = zT_14;
    r = zT_14;
    if ((int)(r > mx)) goto z_bb_28; else goto z_bb_29;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_17 = c;
    zT_19 = u.operand;
    zT_18 = zT_19;
    zT_20 = zF_122C0CBD_depthOfTemp(zT_17, zT_18);
    mx = zT_20;
    mx = zT_20;
    goto z_bb_27;
    z_bb_3:
    ic = inst.payload.int_cast._0;
    zT_22 = c;
    zT_24 = ic.value;
    zT_23 = zT_24;
    zT_25 = zF_122C0CBD_depthOfTemp(zT_22, zT_23);
    mx = zT_25;
    mx = zT_25;
    goto z_bb_27;
    z_bb_4:
    fc = inst.payload.float_cast._0;
    zT_27 = c;
    zT_29 = fc.value;
    zT_28 = zT_29;
    zT_30 = zF_122C0CBD_depthOfTemp(zT_27, zT_28);
    mx = zT_30;
    mx = zT_30;
    goto z_bb_27;
    z_bb_5:
    pc = inst.payload.ptr_cast._0;
    zT_32 = c;
    zT_34 = pc.value;
    zT_33 = zT_34;
    zT_35 = zF_122C0CBD_depthOfTemp(zT_32, zT_33);
    mx = zT_35;
    mx = zT_35;
    goto z_bb_27;
    z_bb_6:
    itf = inst.payload.int_to_float._0;
    zT_37 = c;
    zT_39 = itf.value;
    zT_38 = zT_39;
    zT_40 = zF_122C0CBD_depthOfTemp(zT_37, zT_38);
    mx = zT_40;
    mx = zT_40;
    goto z_bb_27;
    z_bb_7:
    pti = inst.payload.ptr_to_int._0;
    zT_42 = c;
    zT_44 = pti.value;
    zT_43 = zT_44;
    zT_45 = zF_122C0CBD_depthOfTemp(zT_42, zT_43);
    mx = zT_45;
    mx = zT_45;
    goto z_bb_27;
    z_bb_8:
    itp = inst.payload.int_to_ptr._0;
    zT_47 = c;
    zT_49 = itp.value;
    zT_48 = zT_49;
    zT_50 = zF_122C0CBD_depthOfTemp(zT_47, zT_48);
    mx = zT_50;
    mx = zT_50;
    goto z_bb_27;
    z_bb_9:
    ms = inst.payload.make_slice._0;
    zT_52 = c;
    zT_54 = ms.ptr;
    zT_53 = zT_54;
    zT_55 = zF_122C0CBD_depthOfTemp(zT_52, zT_53);
    mx = zT_55;
    mx = zT_55;
    zT_57 = c;
    zT_59 = ms.len;
    zT_58 = zT_59;
    zT_60 = zF_122C0CBD_depthOfTemp(zT_57, zT_58);
    r = zT_60;
    r = zT_60;
    r = zT_60;
    if ((int)(r > mx)) goto z_bb_30; else goto z_bb_31;
    z_bb_10:
    a = inst.payload.addr_of._0;
    zT_63 = c;
    zT_65 = a.operand;
    zT_64 = zT_65;
    zT_66 = zF_122C0CBD_depthOfTemp(zT_63, zT_64);
    mx = zT_66;
    mx = zT_66;
    goto z_bb_27;
    z_bb_11:
    a_1 = inst.payload.addr_of_field._0;
    zT_68 = c;
    zT_70 = a_1.base;
    zT_69 = zT_70;
    zT_71 = zF_122C0CBD_depthOfTemp(zT_68, zT_69);
    mx = zT_71;
    mx = zT_71;
    goto z_bb_27;
    z_bb_12:
    w = inst.payload.wrap_optional._0;
    zT_73 = c;
    zT_75 = w.value;
    zT_74 = zT_75;
    zT_76 = zF_122C0CBD_depthOfTemp(zT_73, zT_74);
    mx = zT_76;
    mx = zT_76;
    goto z_bb_27;
    z_bb_13:
    w_2 = inst.payload.wrap_error_ok._0;
    zT_78 = c;
    zT_80 = w_2.value;
    zT_79 = zT_80;
    zT_81 = zF_122C0CBD_depthOfTemp(zT_78, zT_79);
    mx = zT_81;
    mx = zT_81;
    goto z_bb_27;
    z_bb_14:
    w_3 = inst.payload.wrap_error_err._0;
    zT_83 = c;
    zT_85 = w_3.value;
    zT_84 = zT_85;
    zT_86 = zF_122C0CBD_depthOfTemp(zT_83, zT_84);
    mx = zT_86;
    mx = zT_86;
    goto z_bb_27;
    z_bb_15:
    u_4 = inst.payload.unwrap_optional._0;
    zT_88 = c;
    zT_90 = u_4.value;
    zT_89 = zT_90;
    zT_91 = zF_122C0CBD_depthOfTemp(zT_88, zT_89);
    mx = zT_91;
    mx = zT_91;
    goto z_bb_27;
    z_bb_16:
    u_5 = inst.payload.unwrap_optional_abi._0;
    zT_93 = c;
    zT_95 = u_5.value;
    zT_94 = zT_95;
    zT_96 = zF_122C0CBD_depthOfTemp(zT_93, zT_94);
    mx = zT_96;
    mx = zT_96;
    goto z_bb_27;
    z_bb_17:
    ch = inst.payload.check_optional._0;
    zT_98 = c;
    zT_100 = ch.value;
    zT_99 = zT_100;
    zT_101 = zF_122C0CBD_depthOfTemp(zT_98, zT_99);
    mx = zT_101;
    mx = zT_101;
    goto z_bb_27;
    z_bb_18:
    u_6 = inst.payload.unwrap_error_payload._0;
    zT_103 = c;
    zT_105 = u_6.value;
    zT_104 = zT_105;
    zT_106 = zF_122C0CBD_depthOfTemp(zT_103, zT_104);
    mx = zT_106;
    mx = zT_106;
    goto z_bb_27;
    z_bb_19:
    u_7 = inst.payload.unwrap_error_code._0;
    zT_108 = c;
    zT_110 = u_7.value;
    zT_109 = zT_110;
    zT_111 = zF_122C0CBD_depthOfTemp(zT_108, zT_109);
    mx = zT_111;
    mx = zT_111;
    goto z_bb_27;
    z_bb_20:
    ch_8 = inst.payload.check_error._0;
    zT_113 = c;
    zT_115 = ch_8.value;
    zT_114 = zT_115;
    zT_116 = zF_122C0CBD_depthOfTemp(zT_113, zT_114);
    mx = zT_116;
    mx = zT_116;
    goto z_bb_27;
    z_bb_21:
    l = inst.payload.load._0;
    zT_118 = c;
    zT_120 = l.ptr;
    zT_119 = zT_120;
    zT_121 = zF_122C0CBD_depthOfTemp(zT_118, zT_119);
    mx = zT_121;
    mx = zT_121;
    goto z_bb_27;
    z_bb_22:
    lf = inst.payload.load_field._0;
    zT_123 = c;
    zT_125 = lf.base;
    zT_124 = zT_125;
    zT_126 = zF_122C0CBD_depthOfTemp(zT_123, zT_124);
    mx = zT_126;
    mx = zT_126;
    goto z_bb_27;
    z_bb_23:
    lb = inst.payload.load_bitfield._0;
    zT_128 = c;
    zT_130 = lb.base;
    zT_129 = zT_130;
    zT_131 = zF_122C0CBD_depthOfTemp(zT_128, zT_129);
    mx = zT_131;
    mx = zT_131;
    goto z_bb_27;
    z_bb_24:
    li = inst.payload.load_index._0;
    zT_133 = c;
    zT_135 = li.base;
    zT_134 = zT_135;
    zT_136 = zF_122C0CBD_depthOfTemp(zT_133, zT_134);
    mx = zT_136;
    mx = zT_136;
    zT_138 = c;
    zT_140 = li.index;
    zT_139 = zT_140;
    zT_141 = zF_122C0CBD_depthOfTemp(zT_138, zT_139);
    r = zT_141;
    r = zT_141;
    r = zT_141;
    if ((int)(r > mx)) goto z_bb_32; else goto z_bb_33;
    z_bb_25:
    goto z_bb_27;
    z_bb_27:
    return mx;
    z_bb_28:
    mx = r;
    mx = r;
    goto z_bb_29;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    mx = r;
    mx = r;
    goto z_bb_31;
    z_bb_31:
    goto z_bb_27;
    z_bb_32:
    mx = r;
    mx = r;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_27;
}

/* defReadsMemory */
unsigned char zF_53018302_defReadsMemory(zT_6BA597BC_LirInst inst) {
    unsigned int zT_1;
    zT_1 = inst.tag;
switch (zT_1) {
case 18: goto z_bb_1;
case 15: goto z_bb_2;
case 68: goto z_bb_3;
case 17: goto z_bb_4;
case 52: goto z_bb_5;
case 54: goto z_bb_6;
default: goto z_bb_7;
}
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    return (unsigned char)(1);
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    return (unsigned char)(1);
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    return (unsigned char)(0);
    return 0;
}

/* instOrdered */
unsigned char zF_EB2642CA_instOrdered(zT_6BA597BC_LirInst inst) {
    zT_6BA597BC_LirInst zT_1;
    unsigned char zT_2 = 0;
    zT_1 = inst;
    zT_2 = zF_A5E11466_defInfoPure(zT_1);
    if ((int)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    return (unsigned char)(1);
}

/* tempReachesGlobalAlias */
unsigned char zF_0CED9F5B_tempReachesGlobalAl(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned char* zT_13;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned char* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    unsigned char zT_30;
    unsigned char* zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    unsigned int zT_35;
    unsigned char zT_36;
    unsigned char zT_39;
    unsigned char* zT_40;
    unsigned int zT_41;
    unsigned int* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    unsigned int* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    int zT_53;
    int zT_55;
    unsigned char zT_56;
    unsigned char* zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned char* zT_61;
    unsigned int zT_62;
    zT_BBC23664_LirFunction* zT_64;
    zT_1CF28CA3_BasicBlockArrayList zT_65;
    zT_88A68B1A_BasicBlock* zT_66;
    unsigned int zT_67;
    zT_88A68B1A_BasicBlock zT_68;
    zT_DAE4631D_LirInstArrayList zT_69;
    zT_6BA597BC_LirInst* zT_70;
    unsigned int zT_71;
    zT_6BA597BC_LirInst zT_72;
    zT_5EDE903E_Ctx* zT_74;
    zT_6BA597BC_LirInst zT_75;
    unsigned char zT_76 = 0;
    unsigned char zT_79;
    unsigned char* zT_80;
    unsigned int zT_81;
    unsigned char zT_82;
    unsigned char* zT_83;
    unsigned int zT_84;
    unsigned int pos;
    unsigned char m;
    unsigned int bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    unsigned char r;
    zT_2 = c->max_temp;
    if ((int)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)t;
    zT_8 = zT_6[zT_7];
    pos = zT_8;
    pos = zT_8;
    pos = zT_8;
    if ((int)(pos == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_13 = c->gam;
    zT_14 = (unsigned int)pos;
    zT_15 = zT_13[zT_14];
    m = zT_15;
    m = zT_15;
    m = zT_15;
    if ((int)(m == (unsigned char)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((int)(m == (unsigned char)(2))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((int)(m == (unsigned char)(255))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(1);
    z_bb_10:
    zT_25 = c->ga;
    zT_26 = (unsigned int)pos;
    zT_27 = zT_25[zT_26];
    if ((int)(zT_27 == (unsigned char)(1))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = 1;
    zT_31 = c->gam;
    zT_32 = (unsigned int)pos;
    zT_31[zT_32] = zT_30;
    return (unsigned char)(1);
    z_bb_12:
    zT_34 = c->cand;
    zT_35 = (unsigned int)pos;
    zT_36 = zT_34[zT_35];
    if ((int)(zT_36 == (unsigned char)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_39 = 2;
    zT_40 = c->gam;
    zT_41 = (unsigned int)pos;
    zT_40[zT_41] = zT_39;
    return (unsigned char)(0);
    z_bb_14:
    zT_44 = c->df_bb;
    zT_45 = (unsigned int)t;
    zT_46 = zT_44[zT_45];
    bb = zT_46;
    bb = zT_46;
    bb = zT_46;
    zT_48 = c->df_ii;
    zT_49 = (unsigned int)t;
    zT_50 = zT_48[zT_49];
    ii = zT_50;
    ii = zT_50;
    ii = zT_50;
    if ((int)(bb == (unsigned int)(4294967295u))) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_55 = ii == (unsigned int)(4294967295u);
    zT_53 = zT_55;
    goto z_bb_17;
    z_bb_16:
    zT_53 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_53) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_56 = 2;
    zT_57 = c->gam;
    zT_58 = (unsigned int)pos;
    zT_57[zT_58] = zT_56;
    return (unsigned char)(0);
    z_bb_19:
    zT_60 = 255;
    zT_61 = c->gam;
    zT_62 = (unsigned int)pos;
    zT_61[zT_62] = zT_60;
    zT_64 = c->lir_fn;
    zT_65 = zT_64->blocks;
    zT_66 = zT_65.items;
    zT_67 = (unsigned int)bb;
    zT_68 = zT_66[zT_67];
    zT_69 = zT_68.insts;
    zT_70 = zT_69.items;
    zT_71 = (unsigned int)ii;
    zT_72 = zT_70[zT_71];
    inst = zT_72;
    inst = zT_72;
    inst = zT_72;
    zT_74 = c;
    zT_75 = inst;
    zT_76 = zF_CDC9F097_instOperandsReachGl(zT_74, zT_75);
    r = zT_76;
    r = zT_76;
    r = zT_76;
    if ((int)(r != (unsigned char)(0))) goto z_bb_20; else goto z_bb_22;
    z_bb_20:
    zT_79 = 1;
    zT_80 = c->gam;
    zT_81 = (unsigned int)pos;
    zT_80[zT_81] = zT_79;
    goto z_bb_21;
    z_bb_21:
    return r;
    z_bb_22:
    zT_82 = 2;
    zT_83 = c->gam;
    zT_84 = (unsigned int)pos;
    zT_83[zT_84] = zT_82;
    goto z_bb_21;
}

/* instOperandsReachGlobalAlias */
unsigned char zF_CDC9F097_instOperandsReachGl(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst) {
    unsigned int zT_2;
    zT_5EDE903E_Ctx* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned char zT_7 = 0;
    zT_5EDE903E_Ctx* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned char zT_14 = 0;
    zT_5EDE903E_Ctx* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned char zT_19 = 0;
    zT_5EDE903E_Ctx* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned char zT_24 = 0;
    zT_5EDE903E_Ctx* zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned char zT_29 = 0;
    zT_5EDE903E_Ctx* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_34 = 0;
    zT_5EDE903E_Ctx* zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_39 = 0;
    zT_5EDE903E_Ctx* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned char zT_44 = 0;
    zT_5EDE903E_Ctx* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned char zT_49 = 0;
    zT_5EDE903E_Ctx* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned char zT_54 = 0;
    zT_5EDE903E_Ctx* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char zT_61 = 0;
    zT_5EDE903E_Ctx* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_66 = 0;
    zT_5EDE903E_Ctx* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_71 = 0;
    zT_5EDE903E_Ctx* zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    unsigned char zT_76 = 0;
    zT_5EDE903E_Ctx* zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned char zT_81 = 0;
    zT_5EDE903E_Ctx* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_86 = 0;
    zT_5EDE903E_Ctx* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned char zT_91 = 0;
    zT_5EDE903E_Ctx* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned char zT_96 = 0;
    zT_5EDE903E_Ctx* zT_98;
    unsigned int zT_99;
    unsigned int zT_100;
    unsigned char zT_101 = 0;
    zT_5EDE903E_Ctx* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    unsigned char zT_106 = 0;
    zT_5EDE903E_Ctx* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned char zT_111 = 0;
    zT_5EDE903E_Ctx* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned char zT_116 = 0;
    zT_5EDE903E_Ctx* zT_118;
    unsigned int zT_119;
    unsigned int zT_120;
    unsigned char zT_121 = 0;
    zT_5EDE903E_Ctx* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned char zT_126 = 0;
    zT_5EDE903E_Ctx* zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    unsigned char zT_131 = 0;
    zT_5EDE903E_Ctx* zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned char zT_136 = 0;
    zT_5EDE903E_Ctx* zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned char zT_143 = 0;
    zT_F5475070_anon_49111 b;
    zT_FD475D08_anon_49119 u;
    zT_9F82026D_anon_49295 ic;
    zT_B4D8A91D_anon_49303 fc;
    zT_36DBB45A_anon_49311 pc;
    zT_2EDBA7C2_anon_49319 itf;
    zT_22DDD375_anon_49325 pti;
    zT_24E01532_anon_49333 itp;
    zT_9B843AB8_anon_49285 ms;
    zT_7B4CA090_anon_49177 a;
    zT_7D30CD39_anon_49185 a_1;
    zT_0733E50E_anon_49193 w;
    zT_8F6612C0_anon_49249 w_2;
    zT_8D63D103_anon_49257 w_3;
    zT_1B6B6C52_anon_49229 u_4;
    zT_1B692DBB_anon_49235 u_5;
    zT_97661F58_anon_49241 ch;
    zT_89618C20_anon_49263 u_6;
    zT_93619BDE_anon_49269 u_7;
    zT_8B5F50AF_anon_49275 ch_8;
    zT_F9499553_anon_49165 l;
    zT_81421CA6_anon_49139 lf;
    zT_3A4E1531_anon_49479 lb;
    zT_85512D7C_anon_49159 li;
    zT_2 = inst.tag;
switch (zT_2) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 38: goto z_bb_3;
case 39: goto z_bb_4;
case 40: goto z_bb_5;
case 41: goto z_bb_6;
case 42: goto z_bb_7;
case 43: goto z_bb_8;
case 37: goto z_bb_9;
case 20: goto z_bb_10;
case 21: goto z_bb_11;
case 22: goto z_bb_12;
case 32: goto z_bb_13;
case 33: goto z_bb_14;
case 29: goto z_bb_15;
case 30: goto z_bb_16;
case 31: goto z_bb_17;
case 34: goto z_bb_18;
case 35: goto z_bb_19;
case 36: goto z_bb_20;
case 18: goto z_bb_21;
case 15: goto z_bb_22;
case 68: goto z_bb_23;
case 17: goto z_bb_24;
default: goto z_bb_25;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_4 = c;
    zT_6 = b.lhs;
    zT_5 = zT_6;
    zT_7 = zF_0CED9F5B_tempReachesGlobalAl(zT_4, zT_5);
    if ((int)(zT_7 != (unsigned char)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_16 = c;
    zT_18 = u.operand;
    zT_17 = zT_18;
    zT_19 = zF_0CED9F5B_tempReachesGlobalAl(zT_16, zT_17);
    return zT_19;
    z_bb_3:
    ic = inst.payload.int_cast._0;
    zT_21 = c;
    zT_23 = ic.value;
    zT_22 = zT_23;
    zT_24 = zF_0CED9F5B_tempReachesGlobalAl(zT_21, zT_22);
    return zT_24;
    z_bb_4:
    fc = inst.payload.float_cast._0;
    zT_26 = c;
    zT_28 = fc.value;
    zT_27 = zT_28;
    zT_29 = zF_0CED9F5B_tempReachesGlobalAl(zT_26, zT_27);
    return zT_29;
    z_bb_5:
    pc = inst.payload.ptr_cast._0;
    zT_31 = c;
    zT_33 = pc.value;
    zT_32 = zT_33;
    zT_34 = zF_0CED9F5B_tempReachesGlobalAl(zT_31, zT_32);
    return zT_34;
    z_bb_6:
    itf = inst.payload.int_to_float._0;
    zT_36 = c;
    zT_38 = itf.value;
    zT_37 = zT_38;
    zT_39 = zF_0CED9F5B_tempReachesGlobalAl(zT_36, zT_37);
    return zT_39;
    z_bb_7:
    pti = inst.payload.ptr_to_int._0;
    zT_41 = c;
    zT_43 = pti.value;
    zT_42 = zT_43;
    zT_44 = zF_0CED9F5B_tempReachesGlobalAl(zT_41, zT_42);
    return zT_44;
    z_bb_8:
    itp = inst.payload.int_to_ptr._0;
    zT_46 = c;
    zT_48 = itp.value;
    zT_47 = zT_48;
    zT_49 = zF_0CED9F5B_tempReachesGlobalAl(zT_46, zT_47);
    return zT_49;
    z_bb_9:
    ms = inst.payload.make_slice._0;
    zT_51 = c;
    zT_53 = ms.ptr;
    zT_52 = zT_53;
    zT_54 = zF_0CED9F5B_tempReachesGlobalAl(zT_51, zT_52);
    if ((int)(zT_54 != (unsigned char)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_10:
    a = inst.payload.addr_of._0;
    zT_63 = c;
    zT_65 = a.operand;
    zT_64 = zT_65;
    zT_66 = zF_0CED9F5B_tempReachesGlobalAl(zT_63, zT_64);
    return zT_66;
    z_bb_11:
    a_1 = inst.payload.addr_of_field._0;
    zT_68 = c;
    zT_70 = a_1.base;
    zT_69 = zT_70;
    zT_71 = zF_0CED9F5B_tempReachesGlobalAl(zT_68, zT_69);
    return zT_71;
    z_bb_12:
    w = inst.payload.wrap_optional._0;
    zT_73 = c;
    zT_75 = w.value;
    zT_74 = zT_75;
    zT_76 = zF_0CED9F5B_tempReachesGlobalAl(zT_73, zT_74);
    return zT_76;
    z_bb_13:
    w_2 = inst.payload.wrap_error_ok._0;
    zT_78 = c;
    zT_80 = w_2.value;
    zT_79 = zT_80;
    zT_81 = zF_0CED9F5B_tempReachesGlobalAl(zT_78, zT_79);
    return zT_81;
    z_bb_14:
    w_3 = inst.payload.wrap_error_err._0;
    zT_83 = c;
    zT_85 = w_3.value;
    zT_84 = zT_85;
    zT_86 = zF_0CED9F5B_tempReachesGlobalAl(zT_83, zT_84);
    return zT_86;
    z_bb_15:
    u_4 = inst.payload.unwrap_optional._0;
    zT_88 = c;
    zT_90 = u_4.value;
    zT_89 = zT_90;
    zT_91 = zF_0CED9F5B_tempReachesGlobalAl(zT_88, zT_89);
    return zT_91;
    z_bb_16:
    u_5 = inst.payload.unwrap_optional_abi._0;
    zT_93 = c;
    zT_95 = u_5.value;
    zT_94 = zT_95;
    zT_96 = zF_0CED9F5B_tempReachesGlobalAl(zT_93, zT_94);
    return zT_96;
    z_bb_17:
    ch = inst.payload.check_optional._0;
    zT_98 = c;
    zT_100 = ch.value;
    zT_99 = zT_100;
    zT_101 = zF_0CED9F5B_tempReachesGlobalAl(zT_98, zT_99);
    return zT_101;
    z_bb_18:
    u_6 = inst.payload.unwrap_error_payload._0;
    zT_103 = c;
    zT_105 = u_6.value;
    zT_104 = zT_105;
    zT_106 = zF_0CED9F5B_tempReachesGlobalAl(zT_103, zT_104);
    return zT_106;
    z_bb_19:
    u_7 = inst.payload.unwrap_error_code._0;
    zT_108 = c;
    zT_110 = u_7.value;
    zT_109 = zT_110;
    zT_111 = zF_0CED9F5B_tempReachesGlobalAl(zT_108, zT_109);
    return zT_111;
    z_bb_20:
    ch_8 = inst.payload.check_error._0;
    zT_113 = c;
    zT_115 = ch_8.value;
    zT_114 = zT_115;
    zT_116 = zF_0CED9F5B_tempReachesGlobalAl(zT_113, zT_114);
    return zT_116;
    z_bb_21:
    l = inst.payload.load._0;
    zT_118 = c;
    zT_120 = l.ptr;
    zT_119 = zT_120;
    zT_121 = zF_0CED9F5B_tempReachesGlobalAl(zT_118, zT_119);
    return zT_121;
    z_bb_22:
    lf = inst.payload.load_field._0;
    zT_123 = c;
    zT_125 = lf.base;
    zT_124 = zT_125;
    zT_126 = zF_0CED9F5B_tempReachesGlobalAl(zT_123, zT_124);
    return zT_126;
    z_bb_23:
    lb = inst.payload.load_bitfield._0;
    zT_128 = c;
    zT_130 = lb.base;
    zT_129 = zT_130;
    zT_131 = zF_0CED9F5B_tempReachesGlobalAl(zT_128, zT_129);
    return zT_131;
    z_bb_24:
    li = inst.payload.load_index._0;
    zT_133 = c;
    zT_135 = li.base;
    zT_134 = zT_135;
    zT_136 = zF_0CED9F5B_tempReachesGlobalAl(zT_133, zT_134);
    if ((int)(zT_136 != (unsigned char)(0))) goto z_bb_32; else goto z_bb_33;
    z_bb_25:
    goto z_bb_27;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    return (unsigned char)(1);
    z_bb_29:
    zT_11 = c;
    zT_13 = b.rhs;
    zT_12 = zT_13;
    zT_14 = zF_0CED9F5B_tempReachesGlobalAl(zT_11, zT_12);
    return zT_14;
    z_bb_30:
    return (unsigned char)(1);
    z_bb_31:
    zT_58 = c;
    zT_60 = ms.len;
    zT_59 = zT_60;
    zT_61 = zF_0CED9F5B_tempReachesGlobalAl(zT_58, zT_59);
    return zT_61;
    z_bb_32:
    return (unsigned char)(1);
    z_bb_33:
    zT_140 = c;
    zT_142 = li.index;
    zT_141 = zT_142;
    zT_143 = zF_0CED9F5B_tempReachesGlobalAl(zT_140, zT_141);
    return zT_143;
}

/* computeNestMetadata */
void zF_02672451_computeNestMetadata(zT_5EDE903E_Ctx* c) {
    unsigned int zT_2;
    zT_BBC23664_LirFunction* zT_3;
    zT_1CF28CA3_BasicBlockArrayList zT_4;
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_8;
    zT_1CF28CA3_BasicBlockArrayList zT_9;
    zT_88A68B1A_BasicBlock* zT_10;
    zT_88A68B1A_BasicBlock* zT_11;
    zT_DAE4631D_LirInstArrayList zT_13;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    zT_3E40CD83_Sand* zT_18;
    unsigned int zT_21;
    unsigned int* zT_22 = 0;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_29;
    zT_6BA597BC_LirInst zT_30;
    zT_DAE4631D_LirInstArrayList zT_31;
    zT_6BA597BC_LirInst* zT_32;
    zT_6BA597BC_LirInst zT_33;
    unsigned char zT_34 = 0;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_43;
    unsigned int zT_45;
    unsigned int zT_47;
    zT_DAE4631D_LirInstArrayList zT_50;
    zT_6BA597BC_LirInst* zT_51;
    zT_6BA597BC_LirInst zT_52;
    zT_6BA597BC_LirInst zT_54;
    zT_BBC23664_LirFunction* zT_55;
    zT_BBC23664_LirFunction* zT_56;
    unsigned int zT_57 = 0;
    unsigned int zT_60;
    unsigned int* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_68;
    unsigned int* zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int* zT_72;
    unsigned int zT_73;
    unsigned int* zT_74;
    unsigned int zT_75;
    unsigned int zT_76;
    int zT_79;
    unsigned int* zT_80;
    unsigned int zT_81;
    unsigned int zT_82;
    int zT_84;
    int zT_85;
    unsigned char* zT_86;
    unsigned int zT_87;
    unsigned char zT_88;
    int zT_90;
    int zT_91;
    unsigned char* zT_92;
    unsigned int zT_93;
    unsigned char zT_94;
    int zT_96;
    int zT_97;
    unsigned char* zT_98;
    unsigned int zT_99;
    unsigned char zT_100;
    int zT_102;
    zT_6BA597BC_LirInst zT_103;
    unsigned char zT_104 = 0;
    unsigned int* zT_108;
    unsigned int zT_109;
    unsigned int zT_110;
    unsigned int* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    int zT_117;
    int zT_119;
    int zT_120;
    unsigned int zT_121;
    unsigned int zT_122;
    unsigned int zT_125;
    unsigned int zT_126;
    int zT_127;
    unsigned char zT_128;
    unsigned char* zT_129;
    unsigned int zT_130;
    unsigned char zT_131;
    unsigned char* zT_132;
    unsigned int zT_133;
    unsigned int zT_135;
    unsigned int zT_137;
    unsigned int zT_139;
    zT_BBC23664_LirFunction* zT_140;
    zT_1CF28CA3_BasicBlockArrayList zT_141;
    unsigned int zT_142;
    zT_BBC23664_LirFunction* zT_145;
    zT_1CF28CA3_BasicBlockArrayList zT_146;
    zT_88A68B1A_BasicBlock* zT_147;
    zT_88A68B1A_BasicBlock* zT_148;
    zT_DAE4631D_LirInstArrayList zT_150;
    unsigned int zT_151;
    zT_3E40CD83_Sand* zT_153;
    unsigned int zT_154;
    zT_3E40CD83_Sand* zT_155;
    unsigned int zT_158;
    unsigned int* zT_159 = 0;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_163;
    unsigned int zT_166;
    zT_6BA597BC_LirInst zT_167;
    zT_DAE4631D_LirInstArrayList zT_168;
    zT_6BA597BC_LirInst* zT_169;
    zT_6BA597BC_LirInst zT_170;
    unsigned char zT_171 = 0;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_177;
    unsigned int zT_180;
    unsigned int zT_182;
    unsigned int zT_184;
    zT_DAE4631D_LirInstArrayList zT_187;
    zT_6BA597BC_LirInst* zT_188;
    zT_6BA597BC_LirInst zT_189;
    zT_6BA597BC_LirInst zT_191;
    zT_BBC23664_LirFunction* zT_192;
    zT_BBC23664_LirFunction* zT_193;
    unsigned int zT_194 = 0;
    unsigned int zT_197;
    unsigned int* zT_200;
    unsigned int zT_201;
    unsigned int zT_202;
    unsigned char* zT_205;
    unsigned int zT_206;
    unsigned char zT_207;
    zT_6BA597BC_LirInst zT_210;
    unsigned char zT_211 = 0;
    zT_5EDE903E_Ctx* zT_214;
    zT_6BA597BC_LirInst zT_215;
    unsigned char zT_216 = 0;
    unsigned int* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    unsigned int* zT_224;
    unsigned int zT_225;
    unsigned int zT_226;
    int zT_229;
    int zT_231;
    int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_237;
    unsigned int zT_238;
    int zT_239;
    unsigned char zT_240;
    unsigned char* zT_241;
    unsigned int zT_242;
    unsigned char zT_243;
    unsigned char* zT_244;
    unsigned int zT_245;
    unsigned int zT_247;
    unsigned int zT_249;
    unsigned int zT_251;
    zT_BBC23664_LirFunction* zT_252;
    zT_1CF28CA3_BasicBlockArrayList zT_253;
    unsigned int zT_254;
    zT_BBC23664_LirFunction* zT_257;
    zT_1CF28CA3_BasicBlockArrayList zT_258;
    zT_88A68B1A_BasicBlock* zT_259;
    zT_88A68B1A_BasicBlock* zT_260;
    unsigned int zT_262;
    zT_DAE4631D_LirInstArrayList zT_263;
    unsigned int zT_264;
    zT_6BA597BC_LirInst zT_267;
    zT_BBC23664_LirFunction* zT_268;
    zT_DAE4631D_LirInstArrayList zT_269;
    zT_6BA597BC_LirInst* zT_270;
    zT_6BA597BC_LirInst zT_271;
    zT_BBC23664_LirFunction* zT_272;
    unsigned int zT_273 = 0;
    unsigned int zT_276;
    unsigned char* zT_278;
    unsigned int zT_279;
    unsigned char zT_280;
    unsigned char* zT_283;
    unsigned int zT_284;
    unsigned char zT_285;
    zT_5EDE903E_Ctx* zT_288;
    unsigned int zT_289;
    unsigned char zT_290 = 0;
    unsigned int zT_292;
    unsigned int zT_294;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int n;
    unsigned int* ord_pref;
    unsigned int k;
    unsigned int bi3;
    unsigned int ord;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    unsigned int rp;
    unsigned int pos;
    unsigned int cb;
    unsigned int ci;
    zT_88A68B1A_BasicBlock* bb3;
    unsigned int n3;
    unsigned int* ord3;
    unsigned int k3;
    unsigned int bi2;
    unsigned int o3;
    unsigned int ii3;
    zT_6BA597BC_LirInst inst3;
    unsigned int rp3;
    unsigned int pos3;
    unsigned int cb3;
    unsigned int ci3;
    zT_2 = 0;
    bi = zT_2;
    bi = zT_2;
    bi = zT_2;
    goto z_bb_1;
    z_bb_1:
    zT_3 = c->lir_fn;
    zT_4 = zT_3->blocks;
    zT_5 = zT_4.len;
    if ((int)(bi < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = c->lir_fn;
    zT_9 = zT_8->blocks;
    zT_10 = zT_9.items;
    zT_11 = zT_10 + bi;
    bb = zT_11;
    bb = zT_11;
    bb = zT_11;
    zT_13 = bb->insts;
    zT_14 = zT_13.len;
    n = zT_14;
    n = zT_14;
    n = zT_14;
    zT_18 = c->alloc;
    zT_16 = zT_18;
    zT_21 = (unsigned int)(unsigned int)(n + (unsigned int)(1));
    zT_17 = zT_21;
    zT_22 = zF_730A6C2A_allocU32Raw(zT_16, zT_17);
    ord_pref = zT_22;
    ord_pref = zT_22;
    ord_pref = zT_22;
    zT_23 = 0;
    zT_24 = 0;
    ord_pref[zT_24] = zT_23;
    zT_26 = 0;
    k = zT_26;
    k = zT_26;
    k = zT_26;
    goto z_bb_5;
    z_bb_3:
    zT_139 = 0;
    bi3 = zT_139;
    bi3 = zT_139;
    bi3 = zT_139;
    goto z_bb_46;
    z_bb_4:
    zT_137 = bi + (unsigned int)(1);
    bi = zT_137;
    bi = zT_137;
    goto z_bb_1;
    z_bb_5:
    if ((int)(k < n)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_29 = 0;
    ord = zT_29;
    ord = zT_29;
    ord = zT_29;
    zT_31 = bb->insts;
    zT_32 = zT_31.items;
    zT_33 = zT_32[k];
    zT_30 = zT_33;
    zT_34 = zF_EB2642CA_instOrdered(zT_30);
    if ((int)(zT_34 != (unsigned char)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_47 = 0;
    ii = zT_47;
    ii = zT_47;
    ii = zT_47;
    goto z_bb_11;
    z_bb_8:
    zT_45 = k + (unsigned int)(1);
    k = zT_45;
    k = zT_45;
    goto z_bb_5;
    z_bb_9:
    zT_37 = 1;
    ord = zT_37;
    ord = zT_37;
    goto z_bb_10;
    z_bb_10:
    zT_38 = (unsigned int)k;
    zT_39 = ord_pref[zT_38];
    zT_40 = zT_39 + ord;
    zT_43 = (unsigned int)(unsigned int)(k + (unsigned int)(1));
    ord_pref[zT_43] = zT_40;
    goto z_bb_8;
    z_bb_11:
    if ((int)(ii < n)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_50 = bb->insts;
    zT_51 = zT_50.items;
    zT_52 = zT_51[ii];
    inst = zT_52;
    inst = zT_52;
    inst = zT_52;
    zT_54 = inst;
    zT_56 = c->lir_fn;
    zT_55 = zT_56;
    zT_57 = zF_CFED20F7_defResultTemp(zT_54, zT_55);
    rp = zT_57;
    rp = zT_57;
    rp = zT_57;
    if ((int)(rp == (unsigned int)(4294967295u))) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_4;
    z_bb_14:
    zT_135 = ii + (unsigned int)(1);
    ii = zT_135;
    ii = zT_135;
    goto z_bb_11;
    z_bb_15:
    goto z_bb_14;
    z_bb_16:
    zT_60 = c->max_temp;
    if ((int)(rp >= zT_60)) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_63 = c->t2p;
    zT_64 = (unsigned int)rp;
    zT_65 = zT_63[zT_64];
    pos = zT_65;
    pos = zT_65;
    pos = zT_65;
    if ((int)(pos == (unsigned int)(4294967295u))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_14;
    z_bb_20:
    zT_68 = (unsigned int)bi;
    zT_69 = c->df_bb;
    zT_70 = (unsigned int)rp;
    zT_69[zT_70] = zT_68;
    zT_71 = (unsigned int)ii;
    zT_72 = c->df_ii;
    zT_73 = (unsigned int)rp;
    zT_72[zT_73] = zT_71;
    zT_74 = c->wc;
    zT_75 = (unsigned int)pos;
    zT_76 = zT_74[zT_75];
    if ((int)(zT_76 == (unsigned int)(1))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_80 = c->rc;
    zT_81 = (unsigned int)pos;
    zT_82 = zT_80[zT_81];
    zT_84 = zT_82 == (unsigned int)(1);
    zT_79 = zT_84;
    goto z_bb_23;
    z_bb_22:
    zT_79 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_79) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_86 = c->at;
    zT_87 = (unsigned int)pos;
    zT_88 = zT_86[zT_87];
    zT_90 = zT_88 == (unsigned char)(0);
    zT_85 = zT_90;
    goto z_bb_26;
    z_bb_25:
    zT_85 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_85) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_92 = c->ex;
    zT_93 = (unsigned int)pos;
    zT_94 = zT_92[zT_93];
    zT_96 = zT_94 == (unsigned char)(0);
    zT_91 = zT_96;
    goto z_bb_29;
    z_bb_28:
    zT_91 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_91) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_98 = c->dp;
    zT_99 = (unsigned int)pos;
    zT_100 = zT_98[zT_99];
    zT_102 = zT_100 == (unsigned char)(1);
    zT_97 = zT_102;
    goto z_bb_32;
    z_bb_31:
    zT_97 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_97) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_103 = inst;
    zT_104 = zF_53018302_defReadsMemory(zT_103);
    if ((int)(zT_104 != (unsigned char)(0))) goto z_bb_35; else goto z_bb_37;
    z_bb_34:
    goto z_bb_14;
    z_bb_35:
    zT_108 = c->rd_bb;
    zT_109 = (unsigned int)pos;
    zT_110 = zT_108[zT_109];
    cb = zT_110;
    cb = zT_110;
    cb = zT_110;
    zT_112 = c->rd_ii;
    zT_113 = (unsigned int)pos;
    zT_114 = zT_112[zT_113];
    ci = zT_114;
    ci = zT_114;
    ci = zT_114;
    if ((int)(cb == (unsigned int)((unsigned int)bi))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_131 = 1;
    zT_132 = c->cand;
    zT_133 = (unsigned int)rp;
    zT_132[zT_133] = zT_131;
    goto z_bb_36;
    z_bb_38:
    zT_119 = ci > (unsigned int)((unsigned int)ii);
    zT_117 = zT_119;
    goto z_bb_40;
    z_bb_39:
    zT_117 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_117) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_121 = (unsigned int)ci;
    zT_122 = ord_pref[zT_121];
    zT_125 = (unsigned int)(unsigned int)(ii + (unsigned int)(1));
    zT_126 = ord_pref[zT_125];
    zT_127 = zT_122 == zT_126;
    zT_120 = zT_127;
    goto z_bb_43;
    z_bb_42:
    zT_120 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_120) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_128 = 1;
    zT_129 = c->cand;
    zT_130 = (unsigned int)rp;
    zT_129[zT_130] = zT_128;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_36;
    z_bb_46:
    zT_140 = c->lir_fn;
    zT_141 = zT_140->blocks;
    zT_142 = zT_141.len;
    if ((int)(bi3 < zT_142)) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_145 = c->lir_fn;
    zT_146 = zT_145->blocks;
    zT_147 = zT_146.items;
    zT_148 = zT_147 + bi3;
    bb3 = zT_148;
    bb3 = zT_148;
    bb3 = zT_148;
    zT_150 = bb3->insts;
    zT_151 = zT_150.len;
    n3 = zT_151;
    n3 = zT_151;
    n3 = zT_151;
    zT_155 = c->alloc;
    zT_153 = zT_155;
    zT_158 = (unsigned int)(unsigned int)(n3 + (unsigned int)(1));
    zT_154 = zT_158;
    zT_159 = zF_730A6C2A_allocU32Raw(zT_153, zT_154);
    ord3 = zT_159;
    ord3 = zT_159;
    ord3 = zT_159;
    zT_160 = 0;
    zT_161 = 0;
    ord3[zT_161] = zT_160;
    zT_163 = 0;
    k3 = zT_163;
    k3 = zT_163;
    k3 = zT_163;
    goto z_bb_50;
    z_bb_48:
    zT_251 = 0;
    bi2 = zT_251;
    bi2 = zT_251;
    bi2 = zT_251;
    goto z_bb_80;
    z_bb_49:
    zT_249 = bi3 + (unsigned int)(1);
    bi3 = zT_249;
    bi3 = zT_249;
    goto z_bb_46;
    z_bb_50:
    if ((int)(k3 < n3)) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_166 = 0;
    o3 = zT_166;
    o3 = zT_166;
    o3 = zT_166;
    zT_168 = bb3->insts;
    zT_169 = zT_168.items;
    zT_170 = zT_169[k3];
    zT_167 = zT_170;
    zT_171 = zF_EB2642CA_instOrdered(zT_167);
    if ((int)(zT_171 != (unsigned char)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_184 = 0;
    ii3 = zT_184;
    ii3 = zT_184;
    ii3 = zT_184;
    goto z_bb_56;
    z_bb_53:
    zT_182 = k3 + (unsigned int)(1);
    k3 = zT_182;
    k3 = zT_182;
    goto z_bb_50;
    z_bb_54:
    zT_174 = 1;
    o3 = zT_174;
    o3 = zT_174;
    goto z_bb_55;
    z_bb_55:
    zT_175 = (unsigned int)k3;
    zT_176 = ord3[zT_175];
    zT_177 = zT_176 + o3;
    zT_180 = (unsigned int)(unsigned int)(k3 + (unsigned int)(1));
    ord3[zT_180] = zT_177;
    goto z_bb_53;
    z_bb_56:
    if ((int)(ii3 < n3)) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_187 = bb3->insts;
    zT_188 = zT_187.items;
    zT_189 = zT_188[ii3];
    inst3 = zT_189;
    inst3 = zT_189;
    inst3 = zT_189;
    zT_191 = inst3;
    zT_193 = c->lir_fn;
    zT_192 = zT_193;
    zT_194 = zF_CFED20F7_defResultTemp(zT_191, zT_192);
    rp3 = zT_194;
    rp3 = zT_194;
    rp3 = zT_194;
    if ((int)(rp3 == (unsigned int)(4294967295u))) goto z_bb_60; else goto z_bb_61;
    z_bb_58:
    goto z_bb_49;
    z_bb_59:
    zT_247 = ii3 + (unsigned int)(1);
    ii3 = zT_247;
    ii3 = zT_247;
    goto z_bb_56;
    z_bb_60:
    goto z_bb_59;
    z_bb_61:
    zT_197 = c->max_temp;
    if ((int)(rp3 >= zT_197)) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    goto z_bb_59;
    z_bb_63:
    zT_200 = c->t2p;
    zT_201 = (unsigned int)rp3;
    zT_202 = zT_200[zT_201];
    pos3 = zT_202;
    pos3 = zT_202;
    pos3 = zT_202;
    if ((int)(pos3 == (unsigned int)(4294967295u))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    goto z_bb_59;
    z_bb_65:
    zT_205 = c->cand;
    zT_206 = (unsigned int)pos3;
    zT_207 = zT_205[zT_206];
    if ((int)(zT_207 == (unsigned char)(0))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    goto z_bb_59;
    z_bb_67:
    zT_210 = inst3;
    zT_211 = zF_53018302_defReadsMemory(zT_210);
    if ((int)(zT_211 != (unsigned char)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    goto z_bb_59;
    z_bb_69:
    zT_214 = c;
    zT_215 = inst3;
    zT_216 = zF_CDC9F097_instOperandsReachGl(zT_214, zT_215);
    if ((int)(zT_216 == (unsigned char)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    goto z_bb_59;
    z_bb_71:
    zT_220 = c->rd_bb;
    zT_221 = (unsigned int)pos3;
    zT_222 = zT_220[zT_221];
    cb3 = zT_222;
    cb3 = zT_222;
    cb3 = zT_222;
    zT_224 = c->rd_ii;
    zT_225 = (unsigned int)pos3;
    zT_226 = zT_224[zT_225];
    ci3 = zT_226;
    ci3 = zT_226;
    ci3 = zT_226;
    if ((int)(cb3 == (unsigned int)((unsigned int)bi3))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_231 = ci3 > (unsigned int)((unsigned int)ii3);
    zT_229 = zT_231;
    goto z_bb_74;
    z_bb_73:
    zT_229 = 0;
    goto z_bb_74;
    z_bb_74:
    if (zT_229) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_233 = (unsigned int)ci3;
    zT_234 = ord3[zT_233];
    zT_237 = (unsigned int)(unsigned int)(ii3 + (unsigned int)(1));
    zT_238 = ord3[zT_237];
    zT_239 = zT_234 == zT_238;
    zT_232 = zT_239;
    goto z_bb_77;
    z_bb_76:
    zT_232 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_232) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    goto z_bb_59;
    z_bb_79:
    zT_240 = 0;
    zT_241 = c->cand;
    zT_242 = (unsigned int)rp3;
    zT_241[zT_242] = zT_240;
    zT_243 = 0;
    zT_244 = c->gam;
    zT_245 = (unsigned int)pos3;
    zT_244[zT_245] = zT_243;
    goto z_bb_59;
    z_bb_80:
    zT_252 = c->lir_fn;
    zT_253 = zT_252->blocks;
    zT_254 = zT_253.len;
    if ((int)(bi2 < zT_254)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_257 = c->lir_fn;
    zT_258 = zT_257->blocks;
    zT_259 = zT_258.items;
    zT_260 = zT_259 + bi2;
    bb = zT_260;
    bb = zT_260;
    bb = zT_260;
    zT_262 = 0;
    ii = zT_262;
    ii = zT_262;
    ii = zT_262;
    goto z_bb_84;
    z_bb_82:
    return;
    z_bb_83:
    zT_294 = bi2 + (unsigned int)(1);
    bi2 = zT_294;
    bi2 = zT_294;
    goto z_bb_80;
    z_bb_84:
    zT_263 = bb->insts;
    zT_264 = zT_263.len;
    if ((int)(ii < zT_264)) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_269 = bb->insts;
    zT_270 = zT_269.items;
    zT_271 = zT_270[ii];
    zT_267 = zT_271;
    zT_272 = c->lir_fn;
    zT_268 = zT_272;
    zT_273 = zF_CFED20F7_defResultTemp(zT_267, zT_268);
    rp = zT_273;
    rp = zT_273;
    rp = zT_273;
    if ((int)(rp == (unsigned int)(4294967295u))) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    goto z_bb_83;
    z_bb_87:
    zT_292 = ii + (unsigned int)(1);
    ii = zT_292;
    ii = zT_292;
    goto z_bb_84;
    z_bb_88:
    goto z_bb_87;
    z_bb_89:
    zT_276 = c->max_temp;
    if ((int)(rp >= zT_276)) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    goto z_bb_87;
    z_bb_91:
    zT_278 = c->cand;
    zT_279 = (unsigned int)rp;
    zT_280 = zT_278[zT_279];
    if ((int)(zT_280 == (unsigned char)(0))) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    goto z_bb_87;
    z_bb_93:
    zT_283 = c->depth;
    zT_284 = (unsigned int)rp;
    zT_285 = zT_283[zT_284];
    if ((int)(zT_285 != (unsigned char)(0))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    goto z_bb_87;
    z_bb_95:
    zT_288 = c;
    zT_289 = rp;
    zT_290 = zF_122C0CBD_depthOfTemp(zT_288, zT_289);
    (void)zT_290;
    goto z_bb_87;
}

/* maybeR */
unsigned int zF_8B8DBDFB_maybeR(zT_5EDE903E_Ctx* c, unsigned int t) {
    unsigned int zT_2;
    unsigned int* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int r;
    zT_2 = c->max_temp;
    if ((int)(t >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return t;
    z_bb_2:
    zT_5 = c->ren;
    zT_6 = (unsigned int)t;
    zT_7 = zT_5[zT_6];
    r = zT_7;
    r = zT_7;
    r = zT_7;
    if ((int)(r == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return t;
    z_bb_4:
    return r;
}

/* rewriteInstOperands */
zT_6BA597BC_LirInst zF_0E3ACCAD_rewriteInstOperands(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst) {
    unsigned int zT_2;
    zT_5EDE903E_Ctx* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8 = 0;
    zT_6BA597BC_LirInst zT_9;
    unsigned int zT_10;
    zT_5EDE903E_Ctx* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    zT_5EDE903E_Ctx* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20 = 0;
    zT_6BA597BC_LirInst zT_21;
    unsigned int zT_22;
    zT_5EDE903E_Ctx* zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28 = 0;
    zT_5EDE903E_Ctx* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32 = 0;
    zT_5EDE903E_Ctx* zT_33;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned int zT_36 = 0;
    zT_6BA597BC_LirInst zT_37;
    unsigned int zT_38;
    zT_5EDE903E_Ctx* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44 = 0;
    zT_6BA597BC_LirInst zT_45;
    unsigned int zT_46;
    zT_5EDE903E_Ctx* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52 = 0;
    zT_6BA597BC_LirInst zT_53;
    unsigned int zT_54;
    zT_6BA597BC_LirInst zT_56;
    zT_5EDE903E_Ctx* zT_57;
    unsigned int zT_58;
    unsigned int zT_59 = 0;
    unsigned int zT_60;
    zT_5EDE903E_Ctx* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66 = 0;
    zT_5EDE903E_Ctx* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned int zT_70 = 0;
    zT_6BA597BC_LirInst zT_71;
    unsigned int zT_72;
    zT_5EDE903E_Ctx* zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned int zT_78 = 0;
    zT_6BA597BC_LirInst zT_79;
    unsigned int zT_80;
    zT_5EDE903E_Ctx* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned int zT_86 = 0;
    zT_6BA597BC_LirInst zT_87;
    unsigned int zT_88;
    zT_5EDE903E_Ctx* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    unsigned int zT_94 = 0;
    zT_6BA597BC_LirInst zT_95;
    unsigned int zT_96;
    zT_5EDE903E_Ctx* zT_99;
    unsigned int zT_100;
    unsigned int zT_101;
    unsigned int zT_102 = 0;
    zT_6BA597BC_LirInst zT_103;
    unsigned int zT_104;
    zT_5EDE903E_Ctx* zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned int zT_110 = 0;
    zT_5EDE903E_Ctx* zT_111;
    unsigned int zT_112;
    unsigned int zT_113;
    unsigned int zT_114 = 0;
    zT_6BA597BC_LirInst zT_115;
    unsigned int zT_116;
    zT_5EDE903E_Ctx* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    unsigned int zT_122 = 0;
    zT_5EDE903E_Ctx* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    unsigned int zT_126 = 0;
    zT_6BA597BC_LirInst zT_127;
    unsigned int zT_128;
    zT_5EDE903E_Ctx* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134 = 0;
    zT_5EDE903E_Ctx* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138 = 0;
    zT_6BA597BC_LirInst zT_139;
    unsigned int zT_140;
    zT_5EDE903E_Ctx* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146 = 0;
    zT_6BA597BC_LirInst zT_147;
    unsigned int zT_148;
    zT_5EDE903E_Ctx* zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154 = 0;
    zT_5EDE903E_Ctx* zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158 = 0;
    zT_6BA597BC_LirInst zT_159;
    unsigned int zT_160;
    zT_5EDE903E_Ctx* zT_163;
    unsigned int zT_164;
    unsigned int zT_165;
    unsigned int zT_166 = 0;
    zT_6BA597BC_LirInst zT_167;
    unsigned int zT_168;
    zT_5EDE903E_Ctx* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174 = 0;
    zT_6BA597BC_LirInst zT_175;
    unsigned int zT_176;
    zT_5EDE903E_Ctx* zT_179;
    unsigned int zT_180;
    unsigned int zT_181;
    unsigned int zT_182 = 0;
    zT_6BA597BC_LirInst zT_183;
    unsigned int zT_184;
    zT_5EDE903E_Ctx* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    unsigned int zT_190 = 0;
    zT_5EDE903E_Ctx* zT_191;
    unsigned int zT_192;
    unsigned int zT_193;
    unsigned int zT_194 = 0;
    zT_6BA597BC_LirInst zT_195;
    unsigned int zT_196;
    zT_5EDE903E_Ctx* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    unsigned int zT_202 = 0;
    zT_6BA597BC_LirInst zT_203;
    unsigned int zT_204;
    zT_5EDE903E_Ctx* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int zT_210 = 0;
    zT_6BA597BC_LirInst zT_211;
    unsigned int zT_212;
    zT_5EDE903E_Ctx* zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    unsigned int zT_218 = 0;
    zT_6BA597BC_LirInst zT_219;
    unsigned int zT_220;
    zT_5EDE903E_Ctx* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    unsigned int zT_226 = 0;
    zT_6BA597BC_LirInst zT_227;
    unsigned int zT_228;
    zT_5EDE903E_Ctx* zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234 = 0;
    zT_6BA597BC_LirInst zT_235;
    unsigned int zT_236;
    zT_5EDE903E_Ctx* zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    unsigned int zT_242 = 0;
    zT_6BA597BC_LirInst zT_243;
    unsigned int zT_244;
    zT_5EDE903E_Ctx* zT_247;
    unsigned int zT_248;
    unsigned int zT_249;
    unsigned int zT_250 = 0;
    zT_6BA597BC_LirInst zT_251;
    unsigned int zT_252;
    zT_5EDE903E_Ctx* zT_255;
    unsigned int zT_256;
    unsigned int zT_257;
    unsigned int zT_258 = 0;
    zT_6BA597BC_LirInst zT_259;
    unsigned int zT_260;
    zT_5EDE903E_Ctx* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    unsigned int zT_266 = 0;
    zT_6BA597BC_LirInst zT_267;
    unsigned int zT_268;
    zT_5EDE903E_Ctx* zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    unsigned int zT_274 = 0;
    zT_6BA597BC_LirInst zT_275;
    unsigned int zT_276;
    zT_5EDE903E_Ctx* zT_279;
    unsigned int zT_280;
    unsigned int zT_281;
    unsigned int zT_282 = 0;
    zT_5EDE903E_Ctx* zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    unsigned int zT_286 = 0;
    zT_6BA597BC_LirInst zT_287;
    unsigned int zT_288;
    zT_5EDE903E_Ctx* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    unsigned int zT_294 = 0;
    zT_6BA597BC_LirInst zT_295;
    unsigned int zT_296;
    zT_5EDE903E_Ctx* zT_299;
    unsigned int zT_300;
    unsigned int zT_301;
    unsigned int zT_302 = 0;
    zT_6BA597BC_LirInst zT_303;
    unsigned int zT_304;
    zT_5EDE903E_Ctx* zT_307;
    unsigned int zT_308;
    unsigned int zT_309;
    unsigned int zT_310 = 0;
    zT_6BA597BC_LirInst zT_311;
    unsigned int zT_312;
    zT_5EDE903E_Ctx* zT_315;
    unsigned int zT_316;
    unsigned int zT_317;
    unsigned int zT_318 = 0;
    zT_6BA597BC_LirInst zT_319;
    unsigned int zT_320;
    zT_5EDE903E_Ctx* zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    unsigned int zT_326 = 0;
    zT_6BA597BC_LirInst zT_327;
    unsigned int zT_328;
    zT_5EDE903E_Ctx* zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned int zT_334 = 0;
    zT_6BA597BC_LirInst zT_335;
    unsigned int zT_336;
    zT_5EDE903E_Ctx* zT_339;
    unsigned int zT_340;
    unsigned int zT_341;
    unsigned int zT_342 = 0;
    zT_6BA597BC_LirInst zT_343;
    unsigned int zT_344;
    zT_5EDE903E_Ctx* zT_347;
    unsigned int zT_348;
    unsigned int zT_349;
    unsigned int zT_350 = 0;
    zT_6BA597BC_LirInst zT_351;
    unsigned int zT_352;
    zT_5EDE903E_Ctx* zT_355;
    unsigned int zT_356;
    unsigned int zT_357;
    unsigned int zT_358 = 0;
    zT_6BA597BC_LirInst zT_359;
    unsigned int zT_360;
    zT_5EDE903E_Ctx* zT_363;
    unsigned int zT_364;
    unsigned int zT_365;
    unsigned int zT_366 = 0;
    zT_6BA597BC_LirInst zT_367;
    unsigned int zT_368;
    zT_5EDE903E_Ctx* zT_371;
    unsigned int zT_372;
    unsigned int zT_373;
    unsigned int zT_374 = 0;
    zT_5EDE903E_Ctx* zT_375;
    unsigned int zT_376;
    unsigned int zT_377;
    unsigned int zT_378 = 0;
    zT_6BA597BC_LirInst zT_379;
    unsigned int zT_380;
    zT_5EDE903E_Ctx* zT_383;
    unsigned int zT_384;
    unsigned int zT_385;
    unsigned int zT_386 = 0;
    zT_5EDE903E_Ctx* zT_387;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390 = 0;
    zT_6BA597BC_LirInst zT_391;
    unsigned int zT_392;
    zT_5EDE903E_Ctx* zT_395;
    unsigned int zT_396;
    unsigned int zT_397;
    unsigned int zT_398 = 0;
    zT_6BA597BC_LirInst zT_399;
    unsigned int zT_400;
    zT_5EDE903E_Ctx* zT_403;
    unsigned int zT_404;
    unsigned int zT_405;
    unsigned int zT_406 = 0;
    zT_6BA597BC_LirInst zT_407;
    unsigned int zT_408;
    zT_5EDE903E_Ctx* zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    unsigned int zT_414 = 0;
    zT_5EDE903E_Ctx* zT_415;
    unsigned int zT_416;
    unsigned int zT_417;
    unsigned int zT_418 = 0;
    zT_6BA597BC_LirInst zT_419;
    unsigned int zT_420;
    zT_5EDE903E_Ctx* zT_423;
    unsigned int zT_424;
    unsigned int zT_425;
    unsigned int zT_426 = 0;
    zT_5EDE903E_Ctx* zT_427;
    unsigned int zT_428;
    unsigned int zT_429;
    unsigned int zT_430 = 0;
    zT_6BA597BC_LirInst zT_431;
    unsigned int zT_432;
    zT_73CFAC11_anon_49053 a;
    zT_73CFAC11_anon_49053 na;
    zT_E3D71826_anon_49063 a_1;
    zT_E3D71826_anon_49063 na_2;
    zT_FBD4FF57_anon_49073 a_3;
    zT_FBD4FF57_anon_49073 na_4;
    zT_FBC83364_anon_49083 b;
    zT_FBC83364_anon_49083 nb;
    zT_FBC5F4CD_anon_49093 s;
    zT_FBC5F4CD_anon_49093 ns;
    unsigned int v;
    zT_F5475070_anon_49111 b_5;
    zT_F5475070_anon_49111 nb_6;
    zT_FD475D08_anon_49119 u;
    zT_FD475D08_anon_49119 nu;
    zT_7D3FD7C3_anon_49129 cl;
    zT_7D3FD7C3_anon_49129 nc;
    zT_81421CA6_anon_49139 lf;
    zT_81421CA6_anon_49139 nl;
    zT_3A4E1531_anon_49479 lb;
    zT_3A4E1531_anon_49479 nl_7;
    zT_814EE899_anon_49149 sf;
    zT_814EE899_anon_49149 ns_8;
    zT_BA559A76_anon_49489 sb;
    zT_BA559A76_anon_49489 ns_9;
    zT_85512D7C_anon_49159 li;
    zT_85512D7C_anon_49159 nl_10;
    zT_F9499553_anon_49165 l;
    zT_F9499553_anon_49165 nl_11;
    zT_814CAA02_anon_49171 st;
    zT_814CAA02_anon_49171 ns_12;
    zT_7B4CA090_anon_49177 a_13;
    zT_7B4CA090_anon_49177 na_14;
    zT_7D30CD39_anon_49185 a_15;
    zT_7D30CD39_anon_49185 na_16;
    zT_0733E50E_anon_49193 w;
    zT_0733E50E_anon_49193 nw;
    zT_8F70A01C_anon_49201 vs;
    zT_8F70A01C_anon_49201 nv;
    zT_9770ACB4_anon_49209 va;
    zT_9770ACB4_anon_49209 nv_17;
    zT_096D8E93_anon_49213 ve;
    zT_096D8E93_anon_49213 nv_18;
    zT_1B6B6C52_anon_49229 u_19;
    zT_1B6B6C52_anon_49229 nu_20;
    zT_1B692DBB_anon_49235 u_21;
    zT_1B692DBB_anon_49235 nu_22;
    zT_97661F58_anon_49241 ch;
    zT_97661F58_anon_49241 nc_23;
    zT_8F6612C0_anon_49249 w_24;
    zT_8F6612C0_anon_49249 nw_25;
    zT_8D63D103_anon_49257 w_26;
    zT_8D63D103_anon_49257 nw_27;
    zT_89618C20_anon_49263 u_28;
    zT_89618C20_anon_49263 nu_29;
    zT_93619BDE_anon_49269 u_30;
    zT_93619BDE_anon_49269 nu_31;
    zT_8B5F50AF_anon_49275 ch_32;
    zT_8B5F50AF_anon_49275 nc_33;
    zT_9B843AB8_anon_49285 ms;
    zT_9B843AB8_anon_49285 nm;
    zT_9F82026D_anon_49295 ic;
    zT_9F82026D_anon_49295 ni;
    zT_B4D8A91D_anon_49303 fc;
    zT_B4D8A91D_anon_49303 nf;
    zT_36DBB45A_anon_49311 pc;
    zT_36DBB45A_anon_49311 np;
    zT_2EDBA7C2_anon_49319 itf;
    zT_2EDBA7C2_anon_49319 nt;
    zT_22DDD375_anon_49325 pti;
    zT_22DDD375_anon_49325 nt_34;
    zT_24E01532_anon_49333 itp;
    zT_24E01532_anon_49333 nt_35;
    zT_22EF1C96_anon_49395 sl;
    zT_22EF1C96_anon_49395 ns_36;
    zT_2E3EF7C3_anon_49411 sg;
    zT_2E3EF7C3_anon_49411 ns_37;
    zT_C046995E_anon_49423 pv;
    zT_C046995E_anon_49423 np_38;
    zT_C4469FAA_anon_49427 bpc;
    zT_C4469FAA_anon_49427 nb_39;
    zT_B8444E2F_anon_49433 b_40;
    zT_B8444E2F_anon_49433 nb_41;
    zT_C2445DED_anon_49439 b_42;
    zT_C2445DED_anon_49439 nb_43;
    zT_C44B1CD8_anon_49447 be;
    zT_C44B1CD8_anon_49447 nb_44;
    zT_C648E167_anon_49451 bsm;
    zT_C648E167_anon_49451 nb_45;
    zT_BE48D4CF_anon_49459 bcg;
    zT_BE48D4CF_anon_49459 nb_46;
    zT_32504730_anon_49465 bcc;
    zT_32504730_anon_49465 nb_47;
    zT_2 = inst.tag;
switch (zT_2) {
case 2: goto z_bb_1;
case 3: goto z_bb_2;
case 4: goto z_bb_3;
case 6: goto z_bb_4;
case 7: goto z_bb_5;
case 9: goto z_bb_6;
case 12: goto z_bb_7;
case 13: goto z_bb_8;
case 14: goto z_bb_9;
case 15: goto z_bb_10;
case 68: goto z_bb_11;
case 16: goto z_bb_12;
case 69: goto z_bb_13;
case 17: goto z_bb_14;
case 18: goto z_bb_15;
case 19: goto z_bb_16;
case 20: goto z_bb_17;
case 21: goto z_bb_18;
case 22: goto z_bb_19;
case 24: goto z_bb_20;
case 25: goto z_bb_21;
case 26: goto z_bb_22;
case 29: goto z_bb_23;
case 30: goto z_bb_24;
case 31: goto z_bb_25;
case 32: goto z_bb_26;
case 33: goto z_bb_27;
case 34: goto z_bb_28;
case 35: goto z_bb_29;
case 36: goto z_bb_30;
case 37: goto z_bb_31;
case 38: goto z_bb_32;
case 39: goto z_bb_33;
case 40: goto z_bb_34;
case 41: goto z_bb_35;
case 42: goto z_bb_36;
case 43: goto z_bb_37;
case 53: goto z_bb_38;
case 55: goto z_bb_39;
case 57: goto z_bb_40;
case 58: goto z_bb_41;
case 59: goto z_bb_42;
case 60: goto z_bb_43;
case 62: goto z_bb_44;
case 63: goto z_bb_45;
case 65: goto z_bb_46;
case 66: goto z_bb_47;
default: goto z_bb_48;
}
    z_bb_1:
    a = inst.payload.assign._0;
    na = a;
    na = a;
    na = a;
    zT_5 = c;
    zT_7 = na.src;
    zT_6 = zT_7;
    zT_8 = zF_8B8DBDFB_maybeR(zT_5, zT_6);
    na.src = zT_8;
    zT_10 = 2;
    zT_9.tag = zT_10;
    zT_9.payload.assign._0 = na;
    return zT_9;
    z_bb_2:
    a_1 = inst.payload.assign_field._0;
    na_2 = a_1;
    na_2 = a_1;
    na_2 = a_1;
    zT_13 = c;
    zT_15 = na_2.base;
    zT_14 = zT_15;
    zT_16 = zF_8B8DBDFB_maybeR(zT_13, zT_14);
    na_2.base = zT_16;
    zT_17 = c;
    zT_19 = na_2.src;
    zT_18 = zT_19;
    zT_20 = zF_8B8DBDFB_maybeR(zT_17, zT_18);
    na_2.src = zT_20;
    zT_22 = 3;
    zT_21.tag = zT_22;
    zT_21.payload.assign_field._0 = na_2;
    return zT_21;
    z_bb_3:
    a_3 = inst.payload.assign_index._0;
    na_4 = a_3;
    na_4 = a_3;
    na_4 = a_3;
    zT_25 = c;
    zT_27 = na_4.base;
    zT_26 = zT_27;
    zT_28 = zF_8B8DBDFB_maybeR(zT_25, zT_26);
    na_4.base = zT_28;
    zT_29 = c;
    zT_31 = na_4.index;
    zT_30 = zT_31;
    zT_32 = zF_8B8DBDFB_maybeR(zT_29, zT_30);
    na_4.index = zT_32;
    zT_33 = c;
    zT_35 = na_4.src;
    zT_34 = zT_35;
    zT_36 = zF_8B8DBDFB_maybeR(zT_33, zT_34);
    na_4.src = zT_36;
    zT_38 = 4;
    zT_37.tag = zT_38;
    zT_37.payload.assign_index._0 = na_4;
    return zT_37;
    z_bb_4:
    b = inst.payload.branch._0;
    nb = b;
    nb = b;
    nb = b;
    zT_41 = c;
    zT_43 = nb.cond;
    zT_42 = zT_43;
    zT_44 = zF_8B8DBDFB_maybeR(zT_41, zT_42);
    nb.cond = zT_44;
    zT_46 = 6;
    zT_45.tag = zT_46;
    zT_45.payload.branch._0 = nb;
    return zT_45;
    z_bb_5:
    s = inst.payload.switch_br._0;
    ns = s;
    ns = s;
    ns = s;
    zT_49 = c;
    zT_51 = ns.cond;
    zT_50 = zT_51;
    zT_52 = zF_8B8DBDFB_maybeR(zT_49, zT_50);
    ns.cond = zT_52;
    zT_54 = 7;
    zT_53.tag = zT_54;
    zT_53.payload.switch_br._0 = ns;
    return zT_53;
    z_bb_6:
    v = inst.payload.jump._0;
    zT_57 = c;
    zT_58 = v;
    zT_59 = zF_8B8DBDFB_maybeR(zT_57, zT_58);
    zT_60 = 9;
    zT_56.tag = zT_60;
    zT_56.payload.jump._0 = zT_59;
    return zT_56;
    z_bb_7:
    b_5 = inst.payload.binary._0;
    nb_6 = b_5;
    nb_6 = b_5;
    nb_6 = b_5;
    zT_63 = c;
    zT_65 = nb_6.lhs;
    zT_64 = zT_65;
    zT_66 = zF_8B8DBDFB_maybeR(zT_63, zT_64);
    nb_6.lhs = zT_66;
    zT_67 = c;
    zT_69 = nb_6.rhs;
    zT_68 = zT_69;
    zT_70 = zF_8B8DBDFB_maybeR(zT_67, zT_68);
    nb_6.rhs = zT_70;
    zT_72 = 12;
    zT_71.tag = zT_72;
    zT_71.payload.binary._0 = nb_6;
    return zT_71;
    z_bb_8:
    u = inst.payload.unary._0;
    nu = u;
    nu = u;
    nu = u;
    zT_75 = c;
    zT_77 = nu.operand;
    zT_76 = zT_77;
    zT_78 = zF_8B8DBDFB_maybeR(zT_75, zT_76);
    nu.operand = zT_78;
    zT_80 = 13;
    zT_79.tag = zT_80;
    zT_79.payload.unary._0 = nu;
    return zT_79;
    z_bb_9:
    cl = inst.payload.call._0;
    nc = cl;
    nc = cl;
    nc = cl;
    zT_83 = c;
    zT_85 = nc.callee;
    zT_84 = zT_85;
    zT_86 = zF_8B8DBDFB_maybeR(zT_83, zT_84);
    nc.callee = zT_86;
    zT_88 = 14;
    zT_87.tag = zT_88;
    zT_87.payload.call._0 = nc;
    return zT_87;
    z_bb_10:
    lf = inst.payload.load_field._0;
    nl = lf;
    nl = lf;
    nl = lf;
    zT_91 = c;
    zT_93 = nl.base;
    zT_92 = zT_93;
    zT_94 = zF_8B8DBDFB_maybeR(zT_91, zT_92);
    nl.base = zT_94;
    zT_96 = 15;
    zT_95.tag = zT_96;
    zT_95.payload.load_field._0 = nl;
    return zT_95;
    z_bb_11:
    lb = inst.payload.load_bitfield._0;
    nl_7 = lb;
    nl_7 = lb;
    nl_7 = lb;
    zT_99 = c;
    zT_101 = nl_7.base;
    zT_100 = zT_101;
    zT_102 = zF_8B8DBDFB_maybeR(zT_99, zT_100);
    nl_7.base = zT_102;
    zT_104 = 68;
    zT_103.tag = zT_104;
    zT_103.payload.load_bitfield._0 = nl_7;
    return zT_103;
    z_bb_12:
    sf = inst.payload.store_field._0;
    ns_8 = sf;
    ns_8 = sf;
    ns_8 = sf;
    zT_107 = c;
    zT_109 = ns_8.base;
    zT_108 = zT_109;
    zT_110 = zF_8B8DBDFB_maybeR(zT_107, zT_108);
    ns_8.base = zT_110;
    zT_111 = c;
    zT_113 = ns_8.value;
    zT_112 = zT_113;
    zT_114 = zF_8B8DBDFB_maybeR(zT_111, zT_112);
    ns_8.value = zT_114;
    zT_116 = 16;
    zT_115.tag = zT_116;
    zT_115.payload.store_field._0 = ns_8;
    return zT_115;
    z_bb_13:
    sb = inst.payload.store_bitfield._0;
    ns_9 = sb;
    ns_9 = sb;
    ns_9 = sb;
    zT_119 = c;
    zT_121 = ns_9.base;
    zT_120 = zT_121;
    zT_122 = zF_8B8DBDFB_maybeR(zT_119, zT_120);
    ns_9.base = zT_122;
    zT_123 = c;
    zT_125 = ns_9.value;
    zT_124 = zT_125;
    zT_126 = zF_8B8DBDFB_maybeR(zT_123, zT_124);
    ns_9.value = zT_126;
    zT_128 = 69;
    zT_127.tag = zT_128;
    zT_127.payload.store_bitfield._0 = ns_9;
    return zT_127;
    z_bb_14:
    li = inst.payload.load_index._0;
    nl_10 = li;
    nl_10 = li;
    nl_10 = li;
    zT_131 = c;
    zT_133 = nl_10.base;
    zT_132 = zT_133;
    zT_134 = zF_8B8DBDFB_maybeR(zT_131, zT_132);
    nl_10.base = zT_134;
    zT_135 = c;
    zT_137 = nl_10.index;
    zT_136 = zT_137;
    zT_138 = zF_8B8DBDFB_maybeR(zT_135, zT_136);
    nl_10.index = zT_138;
    zT_140 = 17;
    zT_139.tag = zT_140;
    zT_139.payload.load_index._0 = nl_10;
    return zT_139;
    z_bb_15:
    l = inst.payload.load._0;
    nl_11 = l;
    nl_11 = l;
    nl_11 = l;
    zT_143 = c;
    zT_145 = nl_11.ptr;
    zT_144 = zT_145;
    zT_146 = zF_8B8DBDFB_maybeR(zT_143, zT_144);
    nl_11.ptr = zT_146;
    zT_148 = 18;
    zT_147.tag = zT_148;
    zT_147.payload.load._0 = nl_11;
    return zT_147;
    z_bb_16:
    st = inst.payload.store._0;
    ns_12 = st;
    ns_12 = st;
    ns_12 = st;
    zT_151 = c;
    zT_153 = ns_12.ptr;
    zT_152 = zT_153;
    zT_154 = zF_8B8DBDFB_maybeR(zT_151, zT_152);
    ns_12.ptr = zT_154;
    zT_155 = c;
    zT_157 = ns_12.value;
    zT_156 = zT_157;
    zT_158 = zF_8B8DBDFB_maybeR(zT_155, zT_156);
    ns_12.value = zT_158;
    zT_160 = 19;
    zT_159.tag = zT_160;
    zT_159.payload.store._0 = ns_12;
    return zT_159;
    z_bb_17:
    a_13 = inst.payload.addr_of._0;
    na_14 = a_13;
    na_14 = a_13;
    na_14 = a_13;
    zT_163 = c;
    zT_165 = na_14.operand;
    zT_164 = zT_165;
    zT_166 = zF_8B8DBDFB_maybeR(zT_163, zT_164);
    na_14.operand = zT_166;
    zT_168 = 20;
    zT_167.tag = zT_168;
    zT_167.payload.addr_of._0 = na_14;
    return zT_167;
    z_bb_18:
    a_15 = inst.payload.addr_of_field._0;
    na_16 = a_15;
    na_16 = a_15;
    na_16 = a_15;
    zT_171 = c;
    zT_173 = na_16.base;
    zT_172 = zT_173;
    zT_174 = zF_8B8DBDFB_maybeR(zT_171, zT_172);
    na_16.base = zT_174;
    zT_176 = 21;
    zT_175.tag = zT_176;
    zT_175.payload.addr_of_field._0 = na_16;
    return zT_175;
    z_bb_19:
    w = inst.payload.wrap_optional._0;
    nw = w;
    nw = w;
    nw = w;
    zT_179 = c;
    zT_181 = nw.value;
    zT_180 = zT_181;
    zT_182 = zF_8B8DBDFB_maybeR(zT_179, zT_180);
    nw.value = zT_182;
    zT_184 = 22;
    zT_183.tag = zT_184;
    zT_183.payload.wrap_optional._0 = nw;
    return zT_183;
    z_bb_20:
    vs = inst.payload.va_start._0;
    nv = vs;
    nv = vs;
    nv = vs;
    zT_187 = c;
    zT_189 = nv.va_list_temp;
    zT_188 = zT_189;
    zT_190 = zF_8B8DBDFB_maybeR(zT_187, zT_188);
    nv.va_list_temp = zT_190;
    zT_191 = c;
    zT_193 = nv.last_param_temp;
    zT_192 = zT_193;
    zT_194 = zF_8B8DBDFB_maybeR(zT_191, zT_192);
    nv.last_param_temp = zT_194;
    zT_196 = 24;
    zT_195.tag = zT_196;
    zT_195.payload.va_start._0 = nv;
    return zT_195;
    z_bb_21:
    va = inst.payload.va_arg._0;
    nv_17 = va;
    nv_17 = va;
    nv_17 = va;
    zT_199 = c;
    zT_201 = nv_17.va_list_temp;
    zT_200 = zT_201;
    zT_202 = zF_8B8DBDFB_maybeR(zT_199, zT_200);
    nv_17.va_list_temp = zT_202;
    zT_204 = 25;
    zT_203.tag = zT_204;
    zT_203.payload.va_arg._0 = nv_17;
    return zT_203;
    z_bb_22:
    ve = inst.payload.va_end._0;
    nv_18 = ve;
    nv_18 = ve;
    nv_18 = ve;
    zT_207 = c;
    zT_209 = nv_18.va_list_temp;
    zT_208 = zT_209;
    zT_210 = zF_8B8DBDFB_maybeR(zT_207, zT_208);
    nv_18.va_list_temp = zT_210;
    zT_212 = 26;
    zT_211.tag = zT_212;
    zT_211.payload.va_end._0 = nv_18;
    return zT_211;
    z_bb_23:
    u_19 = inst.payload.unwrap_optional._0;
    nu_20 = u_19;
    nu_20 = u_19;
    nu_20 = u_19;
    zT_215 = c;
    zT_217 = nu_20.value;
    zT_216 = zT_217;
    zT_218 = zF_8B8DBDFB_maybeR(zT_215, zT_216);
    nu_20.value = zT_218;
    zT_220 = 29;
    zT_219.tag = zT_220;
    zT_219.payload.unwrap_optional._0 = nu_20;
    return zT_219;
    z_bb_24:
    u_21 = inst.payload.unwrap_optional_abi._0;
    nu_22 = u_21;
    nu_22 = u_21;
    nu_22 = u_21;
    zT_223 = c;
    zT_225 = nu_22.value;
    zT_224 = zT_225;
    zT_226 = zF_8B8DBDFB_maybeR(zT_223, zT_224);
    nu_22.value = zT_226;
    zT_228 = 30;
    zT_227.tag = zT_228;
    zT_227.payload.unwrap_optional_abi._0 = nu_22;
    return zT_227;
    z_bb_25:
    ch = inst.payload.check_optional._0;
    nc_23 = ch;
    nc_23 = ch;
    nc_23 = ch;
    zT_231 = c;
    zT_233 = nc_23.value;
    zT_232 = zT_233;
    zT_234 = zF_8B8DBDFB_maybeR(zT_231, zT_232);
    nc_23.value = zT_234;
    zT_236 = 31;
    zT_235.tag = zT_236;
    zT_235.payload.check_optional._0 = nc_23;
    return zT_235;
    z_bb_26:
    w_24 = inst.payload.wrap_error_ok._0;
    nw_25 = w_24;
    nw_25 = w_24;
    nw_25 = w_24;
    zT_239 = c;
    zT_241 = nw_25.value;
    zT_240 = zT_241;
    zT_242 = zF_8B8DBDFB_maybeR(zT_239, zT_240);
    nw_25.value = zT_242;
    zT_244 = 32;
    zT_243.tag = zT_244;
    zT_243.payload.wrap_error_ok._0 = nw_25;
    return zT_243;
    z_bb_27:
    w_26 = inst.payload.wrap_error_err._0;
    nw_27 = w_26;
    nw_27 = w_26;
    nw_27 = w_26;
    zT_247 = c;
    zT_249 = nw_27.value;
    zT_248 = zT_249;
    zT_250 = zF_8B8DBDFB_maybeR(zT_247, zT_248);
    nw_27.value = zT_250;
    zT_252 = 33;
    zT_251.tag = zT_252;
    zT_251.payload.wrap_error_err._0 = nw_27;
    return zT_251;
    z_bb_28:
    u_28 = inst.payload.unwrap_error_payload._0;
    nu_29 = u_28;
    nu_29 = u_28;
    nu_29 = u_28;
    zT_255 = c;
    zT_257 = nu_29.value;
    zT_256 = zT_257;
    zT_258 = zF_8B8DBDFB_maybeR(zT_255, zT_256);
    nu_29.value = zT_258;
    zT_260 = 34;
    zT_259.tag = zT_260;
    zT_259.payload.unwrap_error_payload._0 = nu_29;
    return zT_259;
    z_bb_29:
    u_30 = inst.payload.unwrap_error_code._0;
    nu_31 = u_30;
    nu_31 = u_30;
    nu_31 = u_30;
    zT_263 = c;
    zT_265 = nu_31.value;
    zT_264 = zT_265;
    zT_266 = zF_8B8DBDFB_maybeR(zT_263, zT_264);
    nu_31.value = zT_266;
    zT_268 = 35;
    zT_267.tag = zT_268;
    zT_267.payload.unwrap_error_code._0 = nu_31;
    return zT_267;
    z_bb_30:
    ch_32 = inst.payload.check_error._0;
    nc_33 = ch_32;
    nc_33 = ch_32;
    nc_33 = ch_32;
    zT_271 = c;
    zT_273 = nc_33.value;
    zT_272 = zT_273;
    zT_274 = zF_8B8DBDFB_maybeR(zT_271, zT_272);
    nc_33.value = zT_274;
    zT_276 = 36;
    zT_275.tag = zT_276;
    zT_275.payload.check_error._0 = nc_33;
    return zT_275;
    z_bb_31:
    ms = inst.payload.make_slice._0;
    nm = ms;
    nm = ms;
    nm = ms;
    zT_279 = c;
    zT_281 = nm.ptr;
    zT_280 = zT_281;
    zT_282 = zF_8B8DBDFB_maybeR(zT_279, zT_280);
    nm.ptr = zT_282;
    zT_283 = c;
    zT_285 = nm.len;
    zT_284 = zT_285;
    zT_286 = zF_8B8DBDFB_maybeR(zT_283, zT_284);
    nm.len = zT_286;
    zT_288 = 37;
    zT_287.tag = zT_288;
    zT_287.payload.make_slice._0 = nm;
    return zT_287;
    z_bb_32:
    ic = inst.payload.int_cast._0;
    ni = ic;
    ni = ic;
    ni = ic;
    zT_291 = c;
    zT_293 = ni.value;
    zT_292 = zT_293;
    zT_294 = zF_8B8DBDFB_maybeR(zT_291, zT_292);
    ni.value = zT_294;
    zT_296 = 38;
    zT_295.tag = zT_296;
    zT_295.payload.int_cast._0 = ni;
    return zT_295;
    z_bb_33:
    fc = inst.payload.float_cast._0;
    nf = fc;
    nf = fc;
    nf = fc;
    zT_299 = c;
    zT_301 = nf.value;
    zT_300 = zT_301;
    zT_302 = zF_8B8DBDFB_maybeR(zT_299, zT_300);
    nf.value = zT_302;
    zT_304 = 39;
    zT_303.tag = zT_304;
    zT_303.payload.float_cast._0 = nf;
    return zT_303;
    z_bb_34:
    pc = inst.payload.ptr_cast._0;
    np = pc;
    np = pc;
    np = pc;
    zT_307 = c;
    zT_309 = np.value;
    zT_308 = zT_309;
    zT_310 = zF_8B8DBDFB_maybeR(zT_307, zT_308);
    np.value = zT_310;
    zT_312 = 40;
    zT_311.tag = zT_312;
    zT_311.payload.ptr_cast._0 = np;
    return zT_311;
    z_bb_35:
    itf = inst.payload.int_to_float._0;
    nt = itf;
    nt = itf;
    nt = itf;
    zT_315 = c;
    zT_317 = nt.value;
    zT_316 = zT_317;
    zT_318 = zF_8B8DBDFB_maybeR(zT_315, zT_316);
    nt.value = zT_318;
    zT_320 = 41;
    zT_319.tag = zT_320;
    zT_319.payload.int_to_float._0 = nt;
    return zT_319;
    z_bb_36:
    pti = inst.payload.ptr_to_int._0;
    nt_34 = pti;
    nt_34 = pti;
    nt_34 = pti;
    zT_323 = c;
    zT_325 = nt_34.value;
    zT_324 = zT_325;
    zT_326 = zF_8B8DBDFB_maybeR(zT_323, zT_324);
    nt_34.value = zT_326;
    zT_328 = 42;
    zT_327.tag = zT_328;
    zT_327.payload.ptr_to_int._0 = nt_34;
    return zT_327;
    z_bb_37:
    itp = inst.payload.int_to_ptr._0;
    nt_35 = itp;
    nt_35 = itp;
    nt_35 = itp;
    zT_331 = c;
    zT_333 = nt_35.value;
    zT_332 = zT_333;
    zT_334 = zF_8B8DBDFB_maybeR(zT_331, zT_332);
    nt_35.value = zT_334;
    zT_336 = 43;
    zT_335.tag = zT_336;
    zT_335.payload.int_to_ptr._0 = nt_35;
    return zT_335;
    z_bb_38:
    sl = inst.payload.store_local._0;
    ns_36 = sl;
    ns_36 = sl;
    ns_36 = sl;
    zT_339 = c;
    zT_341 = ns_36.value;
    zT_340 = zT_341;
    zT_342 = zF_8B8DBDFB_maybeR(zT_339, zT_340);
    ns_36.value = zT_342;
    zT_344 = 53;
    zT_343.tag = zT_344;
    zT_343.payload.store_local._0 = ns_36;
    return zT_343;
    z_bb_39:
    sg = inst.payload.store_global._0;
    ns_37 = sg;
    ns_37 = sg;
    ns_37 = sg;
    zT_347 = c;
    zT_349 = ns_37.value;
    zT_348 = zT_349;
    zT_350 = zF_8B8DBDFB_maybeR(zT_347, zT_348);
    ns_37.value = zT_350;
    zT_352 = 55;
    zT_351.tag = zT_352;
    zT_351.payload.store_global._0 = ns_37;
    return zT_351;
    z_bb_40:
    pv = inst.payload.print_val._0;
    np_38 = pv;
    np_38 = pv;
    np_38 = pv;
    zT_355 = c;
    zT_357 = np_38.value;
    zT_356 = zT_357;
    zT_358 = zF_8B8DBDFB_maybeR(zT_355, zT_356);
    np_38.value = zT_358;
    zT_360 = 57;
    zT_359.tag = zT_360;
    zT_359.payload.print_val._0 = np_38;
    return zT_359;
    z_bb_41:
    bpc = inst.payload.builtin_put_char._0;
    nb_39 = bpc;
    nb_39 = bpc;
    nb_39 = bpc;
    zT_363 = c;
    zT_365 = nb_39.value;
    zT_364 = zT_365;
    zT_366 = zF_8B8DBDFB_maybeR(zT_363, zT_364);
    nb_39.value = zT_366;
    zT_368 = 58;
    zT_367.tag = zT_368;
    zT_367.payload.builtin_put_char._0 = nb_39;
    return zT_367;
    z_bb_42:
    b_40 = inst.payload.builtin_stdout_write._0;
    nb_41 = b_40;
    nb_41 = b_40;
    nb_41 = b_40;
    zT_371 = c;
    zT_373 = nb_41.ptr;
    zT_372 = zT_373;
    zT_374 = zF_8B8DBDFB_maybeR(zT_371, zT_372);
    nb_41.ptr = zT_374;
    zT_375 = c;
    zT_377 = nb_41.len;
    zT_376 = zT_377;
    zT_378 = zF_8B8DBDFB_maybeR(zT_375, zT_376);
    nb_41.len = zT_378;
    zT_380 = 59;
    zT_379.tag = zT_380;
    zT_379.payload.builtin_stdout_write._0 = nb_41;
    return zT_379;
    z_bb_43:
    b_42 = inst.payload.builtin_stderr_write._0;
    nb_43 = b_42;
    nb_43 = b_42;
    nb_43 = b_42;
    zT_383 = c;
    zT_385 = nb_43.ptr;
    zT_384 = zT_385;
    zT_386 = zF_8B8DBDFB_maybeR(zT_383, zT_384);
    nb_43.ptr = zT_386;
    zT_387 = c;
    zT_389 = nb_43.len;
    zT_388 = zT_389;
    zT_390 = zF_8B8DBDFB_maybeR(zT_387, zT_388);
    nb_43.len = zT_390;
    zT_392 = 60;
    zT_391.tag = zT_392;
    zT_391.payload.builtin_stderr_write._0 = nb_43;
    return zT_391;
    z_bb_44:
    be = inst.payload.builtin_exit._0;
    nb_44 = be;
    nb_44 = be;
    nb_44 = be;
    zT_395 = c;
    zT_397 = nb_44.value;
    zT_396 = zT_397;
    zT_398 = zF_8B8DBDFB_maybeR(zT_395, zT_396);
    nb_44.value = zT_398;
    zT_400 = 62;
    zT_399.tag = zT_400;
    zT_399.payload.builtin_exit._0 = nb_44;
    return zT_399;
    z_bb_45:
    bsm = inst.payload.builtin_sleep_ms._0;
    nb_45 = bsm;
    nb_45 = bsm;
    nb_45 = bsm;
    zT_403 = c;
    zT_405 = nb_45.value;
    zT_404 = zT_405;
    zT_406 = zF_8B8DBDFB_maybeR(zT_403, zT_404);
    nb_45.value = zT_406;
    zT_408 = 63;
    zT_407.tag = zT_408;
    zT_407.payload.builtin_sleep_ms._0 = nb_45;
    return zT_407;
    z_bb_46:
    bcg = inst.payload.builtin_console_gotoxy._0;
    nb_46 = bcg;
    nb_46 = bcg;
    nb_46 = bcg;
    zT_411 = c;
    zT_413 = nb_46.x;
    zT_412 = zT_413;
    zT_414 = zF_8B8DBDFB_maybeR(zT_411, zT_412);
    nb_46.x = zT_414;
    zT_415 = c;
    zT_417 = nb_46.y;
    zT_416 = zT_417;
    zT_418 = zF_8B8DBDFB_maybeR(zT_415, zT_416);
    nb_46.y = zT_418;
    zT_420 = 65;
    zT_419.tag = zT_420;
    zT_419.payload.builtin_console_gotoxy._0 = nb_46;
    return zT_419;
    z_bb_47:
    bcc = inst.payload.builtin_console_set_color._0;
    nb_47 = bcc;
    nb_47 = bcc;
    nb_47 = bcc;
    zT_423 = c;
    zT_425 = nb_47.fg;
    zT_424 = zT_425;
    zT_426 = zF_8B8DBDFB_maybeR(zT_423, zT_424);
    nb_47.fg = zT_426;
    zT_427 = c;
    zT_429 = nb_47.bg;
    zT_428 = zT_429;
    zT_430 = zF_8B8DBDFB_maybeR(zT_427, zT_428);
    nb_47.bg = zT_430;
    zT_432 = 66;
    zT_431.tag = zT_432;
    zT_431.payload.builtin_console_set_color._0 = nb_47;
    return zT_431;
    z_bb_48:
    return inst;
    { zT_6BA597BC_LirInst zT_ret_void = {0}; return zT_ret_void; }
}

/* copyPropagate */
unsigned char zF_4AE99A73_copyPropagate(zT_5EDE903E_Ctx* c) {
    unsigned int zT_2;
    unsigned char zT_4;
    zT_5EDE903E_Ctx* zT_7;
    unsigned char zT_9;
    unsigned int zT_11;
    zT_BBC23664_LirFunction* zT_12;
    zT_1CF28CA3_BasicBlockArrayList zT_13;
    unsigned int zT_14;
    zT_BBC23664_LirFunction* zT_17;
    zT_1CF28CA3_BasicBlockArrayList zT_18;
    zT_88A68B1A_BasicBlock* zT_19;
    zT_88A68B1A_BasicBlock* zT_20;
    unsigned int zT_22;
    zT_DAE4631D_LirInstArrayList zT_23;
    unsigned int zT_24;
    zT_DAE4631D_LirInstArrayList zT_27;
    zT_6BA597BC_LirInst* zT_28;
    zT_6BA597BC_LirInst zT_29;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    int zT_42;
    unsigned int zT_43;
    int zT_44;
    unsigned int* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    unsigned int* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    int zT_55;
    int zT_57;
    unsigned int zT_59;
    unsigned int zT_61;
    unsigned char* zT_62;
    unsigned char zT_63;
    unsigned char* zT_66;
    unsigned char zT_67;
    unsigned char* zT_70;
    unsigned char zT_71;
    unsigned char* zT_74;
    unsigned char zT_75;
    unsigned int* zT_78;
    unsigned int zT_79;
    unsigned int* zT_82;
    unsigned int zT_83;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned char* zT_90;
    unsigned char zT_91;
    unsigned int* zT_94;
    unsigned int zT_95;
    unsigned char* zT_98;
    unsigned char zT_99;
    unsigned int* zT_102;
    unsigned int zT_103;
    unsigned int* zT_106;
    unsigned int zT_107;
    unsigned int* zT_111;
    unsigned int zT_112;
    unsigned int* zT_114;
    unsigned int zT_115;
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int zT_118;
    zT_338B7C76_TypeRegistry* zT_122;
    zT_D155D06D_Type* zT_123;
    unsigned int zT_124;
    zT_D155D06D_Type zT_125;
    zT_33EF6BFB_TypeKind zT_126;
    zT_33EF6BFB_TypeKind zT_127;
    unsigned char zT_128 = 0;
    unsigned int* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int* zT_136;
    unsigned int zT_137;
    zT_6BA597BC_LirInst zT_138;
    unsigned int zT_140;
    zT_DAE4631D_LirInstArrayList zT_141;
    zT_6BA597BC_LirInst* zT_142;
    unsigned char zT_143;
    unsigned int zT_145;
    unsigned int zT_147;
    unsigned char zT_150;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_162;
    int zT_165;
    unsigned int zT_166;
    int zT_167;
    int zT_168;
    int zT_170;
    unsigned int* zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    int zT_177;
    int zT_178;
    unsigned int zT_180;
    unsigned int* zT_181;
    unsigned int zT_182;
    unsigned int zT_184;
    unsigned int zT_186;
    zT_BBC23664_LirFunction* zT_187;
    zT_1CF28CA3_BasicBlockArrayList zT_188;
    unsigned int zT_189;
    zT_BBC23664_LirFunction* zT_192;
    zT_1CF28CA3_BasicBlockArrayList zT_193;
    zT_88A68B1A_BasicBlock* zT_194;
    zT_88A68B1A_BasicBlock* zT_195;
    unsigned int zT_197;
    zT_DAE4631D_LirInstArrayList zT_198;
    unsigned int zT_199;
    zT_5EDE903E_Ctx* zT_201;
    zT_6BA597BC_LirInst zT_202;
    zT_DAE4631D_LirInstArrayList zT_203;
    zT_6BA597BC_LirInst* zT_204;
    zT_6BA597BC_LirInst zT_205;
    zT_6BA597BC_LirInst zT_206 = {0};
    zT_DAE4631D_LirInstArrayList zT_207;
    zT_6BA597BC_LirInst* zT_208;
    unsigned int zT_210;
    unsigned int zT_212;
    unsigned int zT_214;
    unsigned int iter;
    unsigned char changed_total;
    unsigned char changed;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    zT_73CFAC11_anon_49053 a;
    unsigned int dst;
    unsigned int src;
    unsigned int dp;
    unsigned int sp;
    unsigned int dpos;
    unsigned int spos;
    unsigned int dt;
    unsigned int st;
    zT_D155D06D_Type dty;
    unsigned int t;
    unsigned int cur;
    unsigned int rbi;
    unsigned int guard;
    unsigned int next;
    unsigned int rii;
    zT_2 = 0;
    iter = zT_2;
    iter = zT_2;
    iter = zT_2;
    zT_4 = 0;
    changed_total = zT_4;
    changed_total = zT_4;
    changed_total = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((int)(iter < zG_8D933C0A_kCopyPropMaxIter)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = c;
    zF_6A60FAEB_scanAll(zT_7);
    zT_9 = 0;
    changed = zT_9;
    changed = zT_9;
    changed = zT_9;
    zT_11 = 0;
    bi = zT_11;
    bi = zT_11;
    bi = zT_11;
    goto z_bb_5;
    z_bb_3:
    return changed_total;
    z_bb_4:
    zT_214 = iter + (unsigned int)(1);
    iter = zT_214;
    iter = zT_214;
    goto z_bb_1;
    z_bb_5:
    zT_12 = c->lir_fn;
    zT_13 = zT_12->blocks;
    zT_14 = zT_13.len;
    if ((int)(bi < zT_14)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = c->lir_fn;
    zT_18 = zT_17->blocks;
    zT_19 = zT_18.items;
    zT_20 = zT_19 + bi;
    bb = zT_20;
    bb = zT_20;
    bb = zT_20;
    zT_22 = 0;
    ii = zT_22;
    ii = zT_22;
    ii = zT_22;
    goto z_bb_9;
    z_bb_7:
    if ((int)(changed == (unsigned char)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_8:
    zT_147 = bi + (unsigned int)(1);
    bi = zT_147;
    bi = zT_147;
    goto z_bb_5;
    z_bb_9:
    zT_23 = bb->insts;
    zT_24 = zT_23.len;
    if ((int)(ii < zT_24)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_27 = bb->insts;
    zT_28 = zT_27.items;
    zT_29 = zT_28[ii];
    inst = zT_29;
    inst = zT_29;
    inst = zT_29;
    zT_30 = inst.tag;
switch (zT_30) {
case 2: goto z_bb_13;
default: goto z_bb_14;
}
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_145 = ii + (unsigned int)(1);
    ii = zT_145;
    ii = zT_145;
    goto z_bb_9;
    z_bb_13:
    a = inst.payload.assign._0;
    zT_32 = a.name_id;
    if ((int)(zT_32 != (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_14:
    goto z_bb_16;
    z_bb_16:
    goto z_bb_12;
    z_bb_17:
    goto z_bb_12;
    z_bb_18:
    zT_36 = a.dst;
    dst = zT_36;
    dst = zT_36;
    dst = zT_36;
    zT_38 = a.src;
    src = zT_38;
    src = zT_38;
    src = zT_38;
    if ((int)(dst == src)) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    goto z_bb_12;
    z_bb_20:
    zT_40 = c->max_temp;
    if ((int)(dst >= zT_40)) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_43 = c->max_temp;
    zT_44 = src >= zT_43;
    zT_42 = zT_44;
    goto z_bb_23;
    z_bb_22:
    zT_42 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_42) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    goto z_bb_12;
    z_bb_25:
    zT_46 = c->t2p;
    zT_47 = (unsigned int)dst;
    zT_48 = zT_46[zT_47];
    dp = zT_48;
    dp = zT_48;
    dp = zT_48;
    zT_50 = c->t2p;
    zT_51 = (unsigned int)src;
    zT_52 = zT_50[zT_51];
    sp = zT_52;
    sp = zT_52;
    sp = zT_52;
    if ((int)(dp == (unsigned int)(4294967295u))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_57 = sp == (unsigned int)(4294967295u);
    zT_55 = zT_57;
    goto z_bb_28;
    z_bb_27:
    zT_55 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_55) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    goto z_bb_12;
    z_bb_30:
    zT_59 = (unsigned int)dp;
    dpos = zT_59;
    dpos = zT_59;
    dpos = zT_59;
    zT_61 = (unsigned int)sp;
    spos = zT_61;
    spos = zT_61;
    spos = zT_61;
    zT_62 = c->ex;
    zT_63 = zT_62[dpos];
    if ((int)(zT_63 != (unsigned char)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_12;
    z_bb_32:
    zT_66 = c->ex;
    zT_67 = zT_66[spos];
    if ((int)(zT_67 != (unsigned char)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    goto z_bb_12;
    z_bb_34:
    zT_70 = c->at;
    zT_71 = zT_70[dpos];
    if ((int)(zT_71 != (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    goto z_bb_12;
    z_bb_36:
    zT_74 = c->at;
    zT_75 = zT_74[spos];
    if ((int)(zT_75 != (unsigned char)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    goto z_bb_12;
    z_bb_38:
    zT_78 = c->wc;
    zT_79 = zT_78[dpos];
    if ((int)(zT_79 != (unsigned int)(1))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    goto z_bb_12;
    z_bb_40:
    zT_82 = c->wc;
    zT_83 = zT_82[spos];
    if ((int)(zT_83 != (unsigned int)(1))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    goto z_bb_12;
    z_bb_42:
    zT_86 = c->rc;
    zT_87 = zT_86[dpos];
    if ((int)(zT_87 != (unsigned int)(1))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    goto z_bb_12;
    z_bb_44:
    zT_90 = c->rar;
    zT_91 = zT_90[dpos];
    if ((int)(zT_91 != (unsigned char)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    goto z_bb_12;
    z_bb_46:
    zT_94 = c->rc;
    zT_95 = zT_94[spos];
    if ((int)(zT_95 != (unsigned int)(1))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    goto z_bb_12;
    z_bb_48:
    zT_98 = c->dp;
    zT_99 = zT_98[spos];
    if ((int)(zT_99 != (unsigned char)(1))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_12;
    z_bb_50:
    zT_102 = c->rd_bb;
    zT_103 = zT_102[dpos];
    if ((int)(zT_103 != (unsigned int)((unsigned int)bi))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    goto z_bb_12;
    z_bb_52:
    zT_106 = c->rd_ii;
    zT_107 = zT_106[dpos];
    if ((int)(zT_107 <= (unsigned int)((unsigned int)ii))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    goto z_bb_12;
    z_bb_54:
    zT_111 = c->ttype;
    zT_112 = zT_111[dpos];
    dt = zT_112;
    dt = zT_112;
    dt = zT_112;
    zT_114 = c->ttype;
    zT_115 = zT_114[spos];
    st = zT_115;
    st = zT_115;
    st = zT_115;
    if ((int)(dt != st)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    goto z_bb_12;
    z_bb_56:
    zT_117 = c->reg;
    zT_118 = zT_117->types_len;
    if ((int)(dt >= (unsigned int)((unsigned int)zT_118))) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    goto z_bb_12;
    z_bb_58:
    zT_122 = c->reg;
    zT_123 = zT_122->types_items;
    zT_124 = (unsigned int)dt;
    zT_125 = zT_123[zT_124];
    dty = zT_125;
    dty = zT_125;
    dty = zT_125;
    zT_127 = dty.kind;
    zT_126 = zT_127;
    zT_128 = zF_B7E1584C_copyScalarKindOk(zT_126);
    if ((int)(zT_128 == (unsigned char)(0))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    goto z_bb_12;
    z_bb_60:
    zT_131 = c->ren;
    zT_132 = (unsigned int)dst;
    zT_133 = zT_131[zT_132];
    if ((int)(zT_133 != (unsigned int)(4294967295u))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    goto z_bb_12;
    z_bb_62:
    zT_136 = c->ren;
    zT_137 = (unsigned int)dst;
    zT_136[zT_137] = src;
    zT_140 = 67;
    zT_138.tag = zT_140;
    zT_141 = bb->insts;
    zT_142 = zT_141.items;
    zT_142[ii] = zT_138;
    zT_143 = 1;
    changed = zT_143;
    changed = zT_143;
    goto z_bb_16;
    z_bb_63:
    goto z_bb_3;
    z_bb_64:
    zT_150 = 1;
    changed_total = zT_150;
    changed_total = zT_150;
    zT_152 = 0;
    t = zT_152;
    t = zT_152;
    t = zT_152;
    goto z_bb_65;
    z_bb_65:
    zT_153 = c->max_temp;
    if ((int)(t < zT_153)) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_156 = c->ren;
    zT_157 = (unsigned int)t;
    zT_158 = zT_156[zT_157];
    cur = zT_158;
    cur = zT_158;
    cur = zT_158;
    if ((int)(cur == (unsigned int)(4294967295u))) goto z_bb_69; else goto z_bb_70;
    z_bb_67:
    zT_186 = 0;
    rbi = zT_186;
    rbi = zT_186;
    rbi = zT_186;
    goto z_bb_86;
    z_bb_68:
    zT_184 = t + (unsigned int)(1);
    t = zT_184;
    t = zT_184;
    goto z_bb_65;
    z_bb_69:
    goto z_bb_68;
    z_bb_70:
    zT_162 = 0;
    guard = zT_162;
    guard = zT_162;
    guard = zT_162;
    goto z_bb_71;
    z_bb_71:
    if ((int)(cur != (unsigned int)(4294967295u))) goto z_bb_75; else goto z_bb_76;
    z_bb_72:
    zT_172 = c->ren;
    zT_173 = (unsigned int)cur;
    zT_174 = zT_172[zT_173];
    next = zT_174;
    next = zT_174;
    next = zT_174;
    if ((int)(next == (unsigned int)(4294967295u))) goto z_bb_82; else goto z_bb_81;
    z_bb_73:
    zT_181 = c->ren;
    zT_182 = (unsigned int)t;
    zT_181[zT_182] = cur;
    goto z_bb_68;
    z_bb_74:
    zT_180 = guard + (unsigned int)(1);
    guard = zT_180;
    guard = zT_180;
    goto z_bb_71;
    z_bb_75:
    zT_166 = c->max_temp;
    zT_167 = cur < zT_166;
    zT_165 = zT_167;
    goto z_bb_77;
    z_bb_76:
    zT_165 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_165) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_170 = guard < zG_8D933C0A_kCopyPropMaxIter;
    zT_168 = zT_170;
    goto z_bb_80;
    z_bb_79:
    zT_168 = 0;
    goto z_bb_80;
    z_bb_80:
    if (zT_168) goto z_bb_72; else goto z_bb_73;
    z_bb_81:
    zT_178 = next == cur;
    zT_177 = zT_178;
    goto z_bb_83;
    z_bb_82:
    zT_177 = 1;
    goto z_bb_83;
    z_bb_83:
    if (zT_177) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    goto z_bb_73;
    z_bb_85:
    cur = next;
    cur = next;
    goto z_bb_74;
    z_bb_86:
    zT_187 = c->lir_fn;
    zT_188 = zT_187->blocks;
    zT_189 = zT_188.len;
    if ((int)(rbi < zT_189)) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_192 = c->lir_fn;
    zT_193 = zT_192->blocks;
    zT_194 = zT_193.items;
    zT_195 = zT_194 + rbi;
    bb = zT_195;
    bb = zT_195;
    bb = zT_195;
    zT_197 = 0;
    rii = zT_197;
    rii = zT_197;
    rii = zT_197;
    goto z_bb_90;
    z_bb_88:
    goto z_bb_4;
    z_bb_89:
    zT_212 = rbi + (unsigned int)(1);
    rbi = zT_212;
    rbi = zT_212;
    goto z_bb_86;
    z_bb_90:
    zT_198 = bb->insts;
    zT_199 = zT_198.len;
    if ((int)(rii < zT_199)) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    zT_201 = c;
    zT_203 = bb->insts;
    zT_204 = zT_203.items;
    zT_205 = zT_204[rii];
    zT_202 = zT_205;
    zT_206 = zF_0E3ACCAD_rewriteInstOperands(zT_201, zT_202);
    zT_207 = bb->insts;
    zT_208 = zT_207.items;
    zT_208[rii] = zT_206;
    goto z_bb_93;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_210 = rii + (unsigned int)(1);
    rii = zT_210;
    rii = zT_210;
    goto z_bb_90;
}

/* resDeclIntType */
unsigned char zF_2ECBA7DA_resDeclIntType(zT_5EDE903E_Ctx* c, unsigned int temp, unsigned int* out_w, unsigned char* out_s) {
    unsigned int zT_4;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    unsigned int* zT_22;
    unsigned int zT_23;
    zT_338B7C76_TypeRegistry* zT_24;
    unsigned int zT_25;
    zT_338B7C76_TypeRegistry* zT_30;
    zT_D155D06D_Type* zT_31;
    unsigned int zT_32;
    zT_D155D06D_Type zT_33;
    zT_33EF6BFB_TypeKind zT_35;
    zT_33EF6BFB_TypeKind zT_36;
    unsigned int zT_37 = 0;
    zT_33EF6BFB_TypeKind zT_41;
    zT_33EF6BFB_TypeKind zT_42;
    unsigned char zT_43 = 0;
    unsigned int p;
    unsigned int pos;
    unsigned int tid;
    zT_D155D06D_Type ty;
    unsigned int w;
    zT_4 = c->max_temp;
    if ((int)(temp >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = c->t2p;
    zT_9 = (unsigned int)temp;
    zT_10 = zT_8[zT_9];
    p = zT_10;
    p = zT_10;
    p = zT_10;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = (unsigned int)p;
    pos = zT_15;
    pos = zT_15;
    pos = zT_15;
    zT_16 = c->ex;
    zT_17 = zT_16[pos];
    if ((int)(zT_17 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_22 = c->ttype;
    zT_23 = zT_22[pos];
    tid = zT_23;
    tid = zT_23;
    tid = zT_23;
    zT_24 = c->reg;
    zT_25 = zT_24->types_len;
    if ((int)(tid >= (unsigned int)((unsigned int)zT_25))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_30 = c->reg;
    zT_31 = zT_30->types_items;
    zT_32 = (unsigned int)tid;
    zT_33 = zT_31[zT_32];
    ty = zT_33;
    ty = zT_33;
    ty = zT_33;
    zT_36 = ty.kind;
    zT_35 = zT_36;
    zT_37 = zF_90DDF69C_intKindWidth(zT_35);
    w = zT_37;
    w = zT_37;
    w = zT_37;
    if ((int)(w == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    *out_w = w;
    zT_42 = ty.kind;
    zT_41 = zT_42;
    zT_43 = zF_D4EA92B8_intKindSigned(zT_41);
    *out_s = zT_43;
    return (unsigned char)(1);
}

/* constOperandIntType */
unsigned char zF_86D6C86A_constOperandIntType(zT_5EDE903E_Ctx* c, unsigned int temp, unsigned int* out_w, unsigned char* out_s) {
    unsigned int zT_4;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    unsigned char* zT_21;
    unsigned char zT_22;
    unsigned int* zT_26;
    unsigned int zT_27;
    unsigned char* zT_31;
    unsigned char zT_32;
    unsigned int* zT_37;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type* zT_46;
    unsigned int zT_47;
    zT_D155D06D_Type zT_48;
    zT_33EF6BFB_TypeKind zT_50;
    zT_33EF6BFB_TypeKind zT_51;
    unsigned int zT_52 = 0;
    zT_33EF6BFB_TypeKind zT_56;
    zT_33EF6BFB_TypeKind zT_57;
    unsigned char zT_58 = 0;
    unsigned int p;
    unsigned int pos;
    unsigned int tid;
    zT_D155D06D_Type ty;
    unsigned int w;
    zT_4 = c->max_temp;
    if ((int)(temp >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_8 = c->t2p;
    zT_9 = (unsigned int)temp;
    zT_10 = zT_8[zT_9];
    p = zT_10;
    p = zT_10;
    p = zT_10;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = (unsigned int)p;
    pos = zT_15;
    pos = zT_15;
    pos = zT_15;
    zT_16 = c->ex;
    zT_17 = zT_16[pos];
    if ((int)(zT_17 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = c->at;
    zT_22 = zT_21[pos];
    if ((int)(zT_22 != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_26 = c->wc;
    zT_27 = zT_26[pos];
    if ((int)(zT_27 != (unsigned int)(1))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_31 = c->cf;
    zT_32 = zT_31[pos];
    if ((int)(zT_32 != (unsigned char)(1))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_37 = c->ttype;
    zT_38 = zT_37[pos];
    tid = zT_38;
    tid = zT_38;
    tid = zT_38;
    zT_39 = c->reg;
    zT_40 = zT_39->types_len;
    if ((int)(tid >= (unsigned int)((unsigned int)zT_40))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_45 = c->reg;
    zT_46 = zT_45->types_items;
    zT_47 = (unsigned int)tid;
    zT_48 = zT_46[zT_47];
    ty = zT_48;
    ty = zT_48;
    ty = zT_48;
    zT_51 = ty.kind;
    zT_50 = zT_51;
    zT_52 = zF_90DDF69C_intKindWidth(zT_50);
    w = zT_52;
    w = zT_52;
    w = zT_52;
    if ((int)(w == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    *out_w = w;
    zT_57 = ty.kind;
    zT_56 = zT_57;
    zT_58 = zF_D4EA92B8_intKindSigned(zT_56);
    *out_s = zT_58;
    return (unsigned char)(1);
}

/* tempDeclTypeId */
unsigned int zF_D835BE2E_tempDeclTypeId(zT_5EDE903E_Ctx* c, unsigned int temp) {
    unsigned int zT_2;
    unsigned int* zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int p;
    zT_2 = c->max_temp;
    if ((int)(temp >= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_6 = c->t2p;
    zT_7 = (unsigned int)temp;
    zT_8 = zT_6[zT_7];
    p = zT_8;
    p = zT_8;
    p = zT_8;
    if ((int)(p == (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_12 = c->ttype;
    zT_13 = (unsigned int)p;
    zT_14 = zT_12[zT_13];
    return zT_14;
}

/* signMagnitude */
void zF_28365D82_signMagnitude(zT_79FAE712_u64 bits, unsigned int w, unsigned char s, unsigned char* out_neg, zT_79FAE712_u64* out_mag) {
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_79FAE712_u64 zT_9;
    unsigned int zT_13;
    zT_79FAE712_u64 zT_14 = 0;
    zT_79FAE712_u64 m;
    zT_79FAE712_u64 b;
    zT_6 = w;
    zT_7 = zF_5E3CE23D_lowMask(zT_6);
    m = zT_7;
    m = zT_7;
    m = zT_7;
    zT_9 = bits & m;
    b = zT_9;
    b = zT_9;
    b = zT_9;
    if ((int)(s == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *out_neg = (unsigned char)(0);
    *out_mag = b;
    return;
    z_bb_2:
    zT_13 = w;
    zT_14 = zF_3794934D_sigBit(zT_13);
    if ((int)((zT_79FAE712_u64)(b & zT_14) == (zT_79FAE712_u64)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    *out_neg = (unsigned char)(0);
    *out_mag = b;
    return;
    z_bb_4:
    *out_neg = (unsigned char)(1);
    *out_mag = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)(~b) & m) + (zT_79FAE712_u64)(1));
    return;
}

/* cmpBitsSigned */
signed char zF_0B35676F_cmpBitsSigned(zT_79FAE712_u64 a, zT_79FAE712_u64 b, unsigned int w) {
    unsigned int zT_4;
    zT_79FAE712_u64 zT_5 = 0;
    zT_79FAE712_u64 zT_7;
    zT_79FAE712_u64 zT_9;
    unsigned int zT_11;
    zT_79FAE712_u64 zT_12 = 0;
    int zT_15;
    unsigned int zT_17;
    zT_79FAE712_u64 zT_18 = 0;
    int zT_21;
    zT_79FAE712_u64 zT_35;
    zT_79FAE712_u64 zT_40;
    zT_79FAE712_u64 m;
    zT_79FAE712_u64 ab;
    zT_79FAE712_u64 bb;
    int asb;
    int bsb;
    zT_79FAE712_u64 ma;
    zT_79FAE712_u64 mb;
    zT_4 = w;
    zT_5 = zF_5E3CE23D_lowMask(zT_4);
    m = zT_5;
    m = zT_5;
    m = zT_5;
    zT_7 = a & m;
    ab = zT_7;
    ab = zT_7;
    ab = zT_7;
    zT_9 = b & m;
    bb = zT_9;
    bb = zT_9;
    bb = zT_9;
    zT_11 = w;
    zT_12 = zF_3794934D_sigBit(zT_11);
    zT_15 = (zT_79FAE712_u64)(ab & zT_12) != (zT_79FAE712_u64)(0);
    asb = zT_15;
    asb = zT_15;
    asb = zT_15;
    zT_17 = w;
    zT_18 = zF_3794934D_sigBit(zT_17);
    zT_21 = (zT_79FAE712_u64)(bb & zT_18) != (zT_79FAE712_u64)(0);
    bsb = zT_21;
    bsb = zT_21;
    bsb = zT_21;
    if ((int)(asb != bsb)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if (asb) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((int)(!asb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (signed char)((signed char)-1);
    z_bb_4:
    return (signed char)(1);
    z_bb_5:
    if ((int)(ab < bb)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_35 = (zT_79FAE712_u64)((zT_79FAE712_u64)(~ab) & m) + (zT_79FAE712_u64)(1);
    ma = zT_35;
    ma = zT_35;
    ma = zT_35;
    zT_40 = (zT_79FAE712_u64)((zT_79FAE712_u64)(~bb) & m) + (zT_79FAE712_u64)(1);
    mb = zT_40;
    mb = zT_40;
    mb = zT_40;
    if ((int)(ma > mb)) goto z_bb_11; else goto z_bb_12;
    z_bb_7:
    return (signed char)((signed char)-1);
    z_bb_8:
    if ((int)(ab > bb)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (signed char)(1);
    z_bb_10:
    return (signed char)(0);
    z_bb_11:
    return (signed char)((signed char)-1);
    z_bb_12:
    if ((int)(ma < mb)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (signed char)(1);
    z_bb_14:
    return (signed char)(0);
}

/* tryFoldBinaryOp */
unsigned char zF_EEEDCAC3_tryFoldBinaryOp(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst, zT_79FAE712_u64* out_value, unsigned char* out_is_bool) {
    unsigned int zT_5;
    unsigned char zT_7;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned char zT_15;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    unsigned int zT_31;
    unsigned char zT_33;
    zT_5EDE903E_Ctx* zT_34;
    unsigned int zT_35;
    unsigned int* zT_36;
    unsigned char* zT_37;
    unsigned int* zT_38;
    unsigned char* zT_39;
    unsigned char zT_40 = 0;
    unsigned int* zT_45;
    unsigned int zT_46;
    unsigned int zT_47;
    zT_79FAE712_u64* zT_49;
    unsigned int zT_50;
    zT_79FAE712_u64 zT_51;
    unsigned int zT_53;
    zT_79FAE712_u64 zT_54 = 0;
    zT_79FAE712_u64 zT_56;
    zT_5EDE903E_Ctx* zT_58;
    unsigned int zT_59;
    unsigned int zT_60 = 0;
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    zT_79FAE712_u64 zT_74;
    unsigned int zT_78;
    unsigned char zT_80;
    zT_5EDE903E_Ctx* zT_81;
    unsigned int zT_82;
    unsigned int* zT_83;
    unsigned char* zT_84;
    unsigned int* zT_85;
    unsigned char* zT_86;
    unsigned char zT_87 = 0;
    int zT_92;
    int zT_93;
    int zT_97;
    int zT_99;
    zT_79FAE712_u64 zT_103;
    zT_79FAE712_u64 zT_110;
    unsigned int zT_115;
    unsigned char zT_117;
    unsigned int zT_119;
    unsigned char zT_121;
    zT_5EDE903E_Ctx* zT_122;
    unsigned int zT_123;
    unsigned int* zT_124;
    unsigned char* zT_125;
    unsigned int* zT_126;
    unsigned char* zT_127;
    unsigned char zT_128 = 0;
    zT_5EDE903E_Ctx* zT_132;
    unsigned int zT_133;
    unsigned int* zT_134;
    unsigned char* zT_135;
    unsigned int* zT_136;
    unsigned char* zT_137;
    unsigned char zT_138 = 0;
    int zT_143;
    int zT_144;
    unsigned char zT_149;
    int zT_152;
    int zT_154;
    unsigned char zT_155;
    zT_5EDE903E_Ctx* zT_157;
    unsigned int zT_158;
    unsigned int zT_159 = 0;
    unsigned int zT_168;
    unsigned char zT_170;
    zT_5EDE903E_Ctx* zT_171;
    unsigned int zT_172;
    unsigned int* zT_173;
    unsigned char* zT_174;
    unsigned int* zT_175;
    unsigned char* zT_176;
    unsigned char zT_177 = 0;
    int zT_182;
    int zT_183;
    unsigned int zT_189;
    unsigned char zT_191;
    zT_5EDE903E_Ctx* zT_192;
    unsigned int zT_193;
    unsigned int* zT_194;
    unsigned char* zT_195;
    unsigned int* zT_196;
    unsigned char* zT_197;
    unsigned char zT_198 = 0;
    int zT_203;
    int zT_204;
    unsigned int* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    unsigned int* zT_211;
    unsigned int zT_212;
    unsigned int zT_213;
    zT_79FAE712_u64* zT_215;
    unsigned int zT_216;
    zT_79FAE712_u64 zT_217;
    zT_79FAE712_u64* zT_219;
    unsigned int zT_220;
    zT_79FAE712_u64 zT_221;
    unsigned int zT_223;
    zT_79FAE712_u64 zT_224 = 0;
    zT_79FAE712_u64 zT_226;
    zT_79FAE712_u64 zT_228;
    zT_79FAE712_u64 zT_230;
    int zT_233;
    int zT_235;
    zT_79FAE712_u64 zT_237;
    int zT_240;
    int zT_242;
    zT_79FAE712_u64 zT_244;
    int zT_247;
    int zT_249;
    zT_79FAE712_u64 zT_251;
    zT_79FAE712_u64 zT_261;
    zT_79FAE712_u64 zT_271;
    zT_79FAE712_u64 zT_274;
    zT_79FAE712_u64 zT_277;
    zT_79FAE712_u64 zT_280;
    zT_79FAE712_u64 zT_290;
    zT_79FAE712_u64 zT_299;
    zT_79FAE712_u64 zT_303;
    zT_79FAE712_u64 zT_304;
    zT_79FAE712_u64 zT_305;
    zT_79FAE712_u64 zT_309;
    zT_79FAE712_u64 zT_310;
    zT_79FAE712_u64 zT_311;
    zT_79FAE712_u64 zT_316;
    zT_79FAE712_u64 zT_317;
    unsigned int zT_318;
    signed char zT_319 = 0;
    int zT_320;
    zT_79FAE712_u64 zT_322;
    zT_79FAE712_u64 zT_323;
    zT_79FAE712_u64 zT_324;
    zT_79FAE712_u64 zT_326;
    zT_79FAE712_u64 zT_327;
    zT_79FAE712_u64 zT_328;
    zT_79FAE712_u64 zT_333;
    zT_79FAE712_u64 zT_334;
    unsigned int zT_335;
    signed char zT_336 = 0;
    int zT_337;
    zT_79FAE712_u64 zT_339;
    zT_79FAE712_u64 zT_340;
    zT_79FAE712_u64 zT_341;
    zT_79FAE712_u64 zT_343;
    zT_79FAE712_u64 zT_344;
    zT_79FAE712_u64 zT_345;
    zT_79FAE712_u64 zT_350;
    zT_79FAE712_u64 zT_351;
    unsigned int zT_352;
    signed char zT_353 = 0;
    int zT_354;
    zT_79FAE712_u64 zT_356;
    zT_79FAE712_u64 zT_357;
    zT_79FAE712_u64 zT_358;
    zT_79FAE712_u64 zT_360;
    zT_79FAE712_u64 zT_361;
    zT_79FAE712_u64 zT_362;
    zT_79FAE712_u64 zT_367;
    zT_79FAE712_u64 zT_368;
    unsigned int zT_369;
    signed char zT_370 = 0;
    int zT_371;
    zT_79FAE712_u64 zT_373;
    zT_79FAE712_u64 zT_374;
    zT_79FAE712_u64 zT_375;
    zT_79FAE712_u64 zT_377;
    zT_79FAE712_u64 zT_378;
    zT_79FAE712_u64 zT_379;
    unsigned char zT_383;
    unsigned char zT_384;
    unsigned char zT_385;
    unsigned int res;
    unsigned char op;
    unsigned int lhs;
    unsigned int rhs;
    unsigned int operand;
    unsigned char is_unary;
    zT_F5475070_anon_49111 b;
    zT_FD475D08_anon_49119 u;
    unsigned int ow;
    unsigned char os;
    unsigned int lw;
    unsigned char ls;
    unsigned int rw2;
    unsigned char rs2;
    unsigned int opnd_pos;
    zT_79FAE712_u64 ob;
    zT_79FAE712_u64 om;
    zT_79FAE712_u64 obits;
    unsigned int rt;
    unsigned int rw;
    unsigned char rs;
    zT_79FAE712_u64 v;
    unsigned int w;
    unsigned char z_signed;
    unsigned char is_cmp;
    unsigned int rt3;
    unsigned int lp;
    unsigned int rp2;
    zT_79FAE712_u64 la;
    zT_79FAE712_u64 rb;
    zT_79FAE712_u64 m;
    zT_79FAE712_u64 ab;
    zT_79FAE712_u64 bb;
    unsigned int rw3;
    unsigned char rs3;
    unsigned int rw4;
    unsigned char rs4;
    zT_5 = 4294967295u;
    res = zT_5;
    res = zT_5;
    res = zT_5;
    zT_7 = 255;
    op = zT_7;
    op = zT_7;
    op = zT_7;
    zT_9 = 4294967295u;
    lhs = zT_9;
    lhs = zT_9;
    lhs = zT_9;
    zT_11 = 4294967295u;
    rhs = zT_11;
    rhs = zT_11;
    rhs = zT_11;
    zT_13 = 4294967295u;
    operand = zT_13;
    operand = zT_13;
    operand = zT_13;
    zT_15 = 0;
    is_unary = zT_15;
    is_unary = zT_15;
    is_unary = zT_15;
    zT_16 = inst.tag;
switch (zT_16) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
default: goto z_bb_3;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_18 = b.result;
    res = zT_18;
    res = zT_18;
    zT_19 = b.op;
    op = zT_19;
    op = zT_19;
    zT_20 = b.lhs;
    lhs = zT_20;
    lhs = zT_20;
    zT_21 = b.rhs;
    rhs = zT_21;
    rhs = zT_21;
    goto z_bb_5;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_23 = u.result;
    res = zT_23;
    res = zT_23;
    zT_24 = u.op;
    op = zT_24;
    op = zT_24;
    zT_25 = u.operand;
    operand = zT_25;
    operand = zT_25;
    zT_26 = 1;
    is_unary = zT_26;
    is_unary = zT_26;
    goto z_bb_5;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_5:
    if ((int)(is_unary != (unsigned char)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_31 = 0;
    ow = zT_31;
    ow = zT_31;
    ow = zT_31;
    zT_33 = 0;
    os = zT_33;
    os = zT_33;
    os = zT_33;
    zT_34 = c;
    zT_35 = operand;
    zT_38 = &ow;
    zT_36 = zT_38;
    zT_39 = &os;
    zT_37 = zT_39;
    zT_40 = zF_86D6C86A_constOperandIntType(zT_34, zT_35, zT_36, zT_37);
    if ((int)(zT_40 == (unsigned char)(0))) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_115 = 0;
    lw = zT_115;
    lw = zT_115;
    lw = zT_115;
    zT_117 = 0;
    ls = zT_117;
    ls = zT_117;
    ls = zT_117;
    zT_119 = 0;
    rw2 = zT_119;
    rw2 = zT_119;
    rw2 = zT_119;
    zT_121 = 0;
    rs2 = zT_121;
    rs2 = zT_121;
    rs2 = zT_121;
    zT_122 = c;
    zT_123 = lhs;
    zT_126 = &lw;
    zT_124 = zT_126;
    zT_127 = &ls;
    zT_125 = zT_127;
    zT_128 = zF_86D6C86A_constOperandIntType(zT_122, zT_123, zT_124, zT_125);
    if ((int)(zT_128 == (unsigned char)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_45 = c->t2p;
    zT_46 = (unsigned int)operand;
    zT_47 = zT_45[zT_46];
    opnd_pos = zT_47;
    opnd_pos = zT_47;
    opnd_pos = zT_47;
    zT_49 = c->cv;
    zT_50 = (unsigned int)opnd_pos;
    zT_51 = zT_49[zT_50];
    ob = zT_51;
    ob = zT_51;
    ob = zT_51;
    zT_53 = ow;
    zT_54 = zF_5E3CE23D_lowMask(zT_53);
    om = zT_54;
    om = zT_54;
    om = zT_54;
    zT_56 = ob & om;
    obits = zT_56;
    obits = zT_56;
    obits = zT_56;
    zT_58 = c;
    zT_59 = res;
    zT_60 = zF_D835BE2E_tempDeclTypeId(zT_58, zT_59);
    rt = zT_60;
    rt = zT_60;
    rt = zT_60;
    if ((int)(rt == (unsigned int)(4294967295u))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(0);
    z_bb_11:
    if ((int)(op == (unsigned char)(1))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    if ((int)(rt != (unsigned int)(2))) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_78 = 0;
    rw = zT_78;
    rw = zT_78;
    rw = zT_78;
    zT_80 = 0;
    rs = zT_80;
    rs = zT_80;
    rs = zT_80;
    zT_81 = c;
    zT_82 = res;
    zT_85 = &rw;
    zT_83 = zT_85;
    zT_86 = &rs;
    zT_84 = zT_86;
    zT_87 = zF_2ECBA7DA_resDeclIntType(zT_81, zT_82, zT_83, zT_84);
    if ((int)(zT_87 == (unsigned char)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_14:
    return (unsigned char)(0);
    z_bb_15:
    if ((int)(obits == (zT_79FAE712_u64)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_73 = 1;
    zT_72 = zT_73;
    goto z_bb_18;
    z_bb_17:
    zT_74 = 0;
    zT_72 = zT_74;
    goto z_bb_18;
    z_bb_18:
    v = zT_72;
    v = zT_72;
    v = zT_72;
    *out_value = v;
    *out_is_bool = (unsigned char)(1);
    return (unsigned char)(1);
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    if ((int)(rw != ow)) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_93 = rs != os;
    zT_92 = zT_93;
    goto z_bb_23;
    z_bb_22:
    zT_92 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_92) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (unsigned char)(0);
    z_bb_25:
    if ((int)(op == (unsigned char)(0))) goto z_bb_27; else goto z_bb_26;
    z_bb_26:
    zT_99 = op == (unsigned char)(3);
    zT_97 = zT_99;
    goto z_bb_28;
    z_bb_27:
    zT_97 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_97) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_103 = (zT_79FAE712_u64)((zT_79FAE712_u64)(0) - obits) & om;
    v = zT_103;
    v = zT_103;
    v = zT_103;
    *out_value = v;
    *out_is_bool = (unsigned char)(0);
    return (unsigned char)(1);
    z_bb_30:
    if ((int)(op == (unsigned char)(2))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_110 = (zT_79FAE712_u64)(~obits) & om;
    v = zT_110;
    v = zT_110;
    v = zT_110;
    *out_value = v;
    *out_is_bool = (unsigned char)(0);
    return (unsigned char)(1);
    z_bb_32:
    return (unsigned char)(0);
    z_bb_33:
    return (unsigned char)(0);
    z_bb_34:
    zT_132 = c;
    zT_133 = rhs;
    zT_136 = &rw2;
    zT_134 = zT_136;
    zT_137 = &rs2;
    zT_135 = zT_137;
    zT_138 = zF_86D6C86A_constOperandIntType(zT_132, zT_133, zT_134, zT_135);
    if ((int)(zT_138 == (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned char)(0);
    z_bb_36:
    if ((int)(lw != rw2)) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_144 = ls != rs2;
    zT_143 = zT_144;
    goto z_bb_39;
    z_bb_38:
    zT_143 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_143) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    return (unsigned char)(0);
    z_bb_41:
    w = lw;
    w = lw;
    w = lw;
    z_signed = ls;
    z_signed = ls;
    z_signed = ls;
    zT_149 = 0;
    is_cmp = zT_149;
    is_cmp = zT_149;
    is_cmp = zT_149;
    if ((int)(op >= (unsigned char)(10))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_154 = op <= (unsigned char)(15);
    zT_152 = zT_154;
    goto z_bb_44;
    z_bb_43:
    zT_152 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_152) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_155 = 1;
    is_cmp = zT_155;
    is_cmp = zT_155;
    goto z_bb_46;
    z_bb_46:
    zT_157 = c;
    zT_158 = res;
    zT_159 = zF_D835BE2E_tempDeclTypeId(zT_157, zT_158);
    rt3 = zT_159;
    rt3 = zT_159;
    rt3 = zT_159;
    if ((int)(rt3 == (unsigned int)(4294967295u))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (unsigned char)(0);
    z_bb_48:
    if ((int)(is_cmp != (unsigned char)(0))) goto z_bb_49; else goto z_bb_51;
    z_bb_49:
    if ((int)(rt3 != (unsigned int)(2))) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    zT_207 = c->t2p;
    zT_208 = (unsigned int)lhs;
    zT_209 = zT_207[zT_208];
    lp = zT_209;
    lp = zT_209;
    lp = zT_209;
    zT_211 = c->t2p;
    zT_212 = (unsigned int)rhs;
    zT_213 = zT_211[zT_212];
    rp2 = zT_213;
    rp2 = zT_213;
    rp2 = zT_213;
    zT_215 = c->cv;
    zT_216 = (unsigned int)lp;
    zT_217 = zT_215[zT_216];
    la = zT_217;
    la = zT_217;
    la = zT_217;
    zT_219 = c->cv;
    zT_220 = (unsigned int)rp2;
    zT_221 = zT_219[zT_220];
    rb = zT_221;
    rb = zT_221;
    rb = zT_221;
    zT_223 = w;
    zT_224 = zF_5E3CE23D_lowMask(zT_223);
    m = zT_224;
    m = zT_224;
    m = zT_224;
    zT_226 = la & m;
    ab = zT_226;
    ab = zT_226;
    ab = zT_226;
    zT_228 = rb & m;
    bb = zT_228;
    bb = zT_228;
    bb = zT_228;
    zT_230 = 0;
    v = zT_230;
    v = zT_230;
    v = zT_230;
    if ((int)(op == (unsigned char)(0))) goto z_bb_71; else goto z_bb_70;
    z_bb_51:
    if ((int)(rt3 == (unsigned int)(2))) goto z_bb_61; else goto z_bb_62;
    z_bb_52:
    zT_168 = 0;
    rw3 = zT_168;
    rw3 = zT_168;
    rw3 = zT_168;
    zT_170 = 0;
    rs3 = zT_170;
    rs3 = zT_170;
    rs3 = zT_170;
    zT_171 = c;
    zT_172 = res;
    zT_175 = &rw3;
    zT_173 = zT_175;
    zT_176 = &rs3;
    zT_174 = zT_176;
    zT_177 = zF_2ECBA7DA_resDeclIntType(zT_171, zT_172, zT_173, zT_174);
    if ((int)(zT_177 == (unsigned char)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    return (unsigned char)(0);
    z_bb_55:
    if ((int)(rw3 != w)) goto z_bb_57; else goto z_bb_56;
    z_bb_56:
    zT_183 = rs3 != z_signed;
    zT_182 = zT_183;
    goto z_bb_58;
    z_bb_57:
    zT_182 = 1;
    goto z_bb_58;
    z_bb_58:
    if (zT_182) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return (unsigned char)(0);
    z_bb_60:
    goto z_bb_53;
    z_bb_61:
    return (unsigned char)(0);
    z_bb_62:
    zT_189 = 0;
    rw4 = zT_189;
    rw4 = zT_189;
    rw4 = zT_189;
    zT_191 = 0;
    rs4 = zT_191;
    rs4 = zT_191;
    rs4 = zT_191;
    zT_192 = c;
    zT_193 = res;
    zT_196 = &rw4;
    zT_194 = zT_196;
    zT_197 = &rs4;
    zT_195 = zT_197;
    zT_198 = zF_2ECBA7DA_resDeclIntType(zT_192, zT_193, zT_194, zT_195);
    if ((int)(zT_198 == (unsigned char)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    return (unsigned char)(0);
    z_bb_64:
    if ((int)(rw4 != w)) goto z_bb_66; else goto z_bb_65;
    z_bb_65:
    zT_204 = rs4 != z_signed;
    zT_203 = zT_204;
    goto z_bb_67;
    z_bb_66:
    zT_203 = 1;
    goto z_bb_67;
    z_bb_67:
    if (zT_203) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    return (unsigned char)(0);
    z_bb_69:
    goto z_bb_50;
    z_bb_70:
    zT_235 = op == (unsigned char)(16);
    zT_233 = zT_235;
    goto z_bb_72;
    z_bb_71:
    zT_233 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_233) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_237 = (zT_79FAE712_u64)(ab + bb) & m;
    v = zT_237;
    v = zT_237;
    goto z_bb_74;
    z_bb_74:
    *out_value = v;
    if ((int)(rt3 == (unsigned int)(2))) goto z_bb_185; else goto z_bb_186;
    z_bb_75:
    if ((int)(op == (unsigned char)(1))) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_242 = op == (unsigned char)(17);
    zT_240 = zT_242;
    goto z_bb_78;
    z_bb_77:
    zT_240 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_240) goto z_bb_79; else goto z_bb_81;
    z_bb_79:
    zT_244 = (zT_79FAE712_u64)(ab - bb) & m;
    v = zT_244;
    v = zT_244;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_74;
    z_bb_81:
    if ((int)(op == (unsigned char)(2))) goto z_bb_83; else goto z_bb_82;
    z_bb_82:
    zT_249 = op == (unsigned char)(18);
    zT_247 = zT_249;
    goto z_bb_84;
    z_bb_83:
    zT_247 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_247) goto z_bb_85; else goto z_bb_87;
    z_bb_85:
    zT_251 = (zT_79FAE712_u64)(ab * bb) & m;
    v = zT_251;
    v = zT_251;
    goto z_bb_86;
    z_bb_86:
    goto z_bb_80;
    z_bb_87:
    if ((int)(op == (unsigned char)(3))) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    if ((int)(z_signed != (unsigned char)(0))) goto z_bb_91; else goto z_bb_92;
    z_bb_89:
    goto z_bb_86;
    z_bb_90:
    if ((int)(op == (unsigned char)(4))) goto z_bb_95; else goto z_bb_97;
    z_bb_91:
    return (unsigned char)(0);
    z_bb_92:
    if ((int)(bb == (zT_79FAE712_u64)(0))) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    return (unsigned char)(0);
    z_bb_94:
    zT_261 = (zT_79FAE712_u64)(ab / bb) & m;
    v = zT_261;
    v = zT_261;
    goto z_bb_89;
    z_bb_95:
    if ((int)(z_signed != (unsigned char)(0))) goto z_bb_98; else goto z_bb_99;
    z_bb_96:
    goto z_bb_89;
    z_bb_97:
    if ((int)(op == (unsigned char)(5))) goto z_bb_102; else goto z_bb_104;
    z_bb_98:
    return (unsigned char)(0);
    z_bb_99:
    if ((int)(bb == (zT_79FAE712_u64)(0))) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    return (unsigned char)(0);
    z_bb_101:
    zT_271 = (zT_79FAE712_u64)(ab % bb) & m;
    v = zT_271;
    v = zT_271;
    goto z_bb_96;
    z_bb_102:
    zT_274 = ab & bb;
    v = zT_274;
    v = zT_274;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_96;
    z_bb_104:
    if ((int)(op == (unsigned char)(6))) goto z_bb_105; else goto z_bb_107;
    z_bb_105:
    zT_277 = ab | bb;
    v = zT_277;
    v = zT_277;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    if ((int)(op == (unsigned char)(7))) goto z_bb_108; else goto z_bb_110;
    z_bb_108:
    zT_280 = ab ^ bb;
    v = zT_280;
    v = zT_280;
    goto z_bb_109;
    z_bb_109:
    goto z_bb_106;
    z_bb_110:
    if ((int)(op == (unsigned char)(8))) goto z_bb_111; else goto z_bb_113;
    z_bb_111:
    if ((int)(z_signed != (unsigned char)(0))) goto z_bb_114; else goto z_bb_115;
    z_bb_112:
    goto z_bb_109;
    z_bb_113:
    if ((int)(op == (unsigned char)(9))) goto z_bb_118; else goto z_bb_120;
    z_bb_114:
    return (unsigned char)(0);
    z_bb_115:
    if ((int)(bb >= (zT_79FAE712_u64)((zT_79FAE712_u64)w))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    return (unsigned char)(0);
    z_bb_117:
    zT_290 = (zT_79FAE712_u64)(ab << bb) & m;
    v = zT_290;
    v = zT_290;
    goto z_bb_112;
    z_bb_118:
    if ((int)(z_signed != (unsigned char)(0))) goto z_bb_121; else goto z_bb_122;
    z_bb_119:
    goto z_bb_112;
    z_bb_120:
    if ((int)(op == (unsigned char)(10))) goto z_bb_125; else goto z_bb_127;
    z_bb_121:
    return (unsigned char)(0);
    z_bb_122:
    if ((int)(bb >= (zT_79FAE712_u64)((zT_79FAE712_u64)w))) goto z_bb_123; else goto z_bb_124;
    z_bb_123:
    return (unsigned char)(0);
    z_bb_124:
    zT_299 = ab >> bb;
    v = zT_299;
    v = zT_299;
    goto z_bb_119;
    z_bb_125:
    if ((int)(ab == bb)) goto z_bb_128; else goto z_bb_129;
    z_bb_126:
    goto z_bb_119;
    z_bb_127:
    if ((int)(op == (unsigned char)(11))) goto z_bb_131; else goto z_bb_133;
    z_bb_128:
    zT_304 = 1;
    zT_303 = zT_304;
    goto z_bb_130;
    z_bb_129:
    zT_305 = 0;
    zT_303 = zT_305;
    goto z_bb_130;
    z_bb_130:
    v = zT_303;
    v = zT_303;
    goto z_bb_126;
    z_bb_131:
    if ((int)(ab != bb)) goto z_bb_134; else goto z_bb_135;
    z_bb_132:
    goto z_bb_126;
    z_bb_133:
    if ((int)(op == (unsigned char)(12))) goto z_bb_137; else goto z_bb_139;
    z_bb_134:
    zT_310 = 1;
    zT_309 = zT_310;
    goto z_bb_136;
    z_bb_135:
    zT_311 = 0;
    zT_309 = zT_311;
    goto z_bb_136;
    z_bb_136:
    v = zT_309;
    v = zT_309;
    goto z_bb_132;
    z_bb_137:
    if ((int)(z_signed != (unsigned char)(0))) goto z_bb_140; else goto z_bb_142;
    z_bb_138:
    goto z_bb_132;
    z_bb_139:
    if ((int)(op == (unsigned char)(13))) goto z_bb_149; else goto z_bb_151;
    z_bb_140:
    zT_316 = ab;
    zT_317 = bb;
    zT_318 = w;
    zT_319 = zF_0B35676F_cmpBitsSigned(zT_316, zT_317, zT_318);
    zT_320 = 0;
    if ((int)(zT_319 < zT_320)) goto z_bb_143; else goto z_bb_144;
    z_bb_141:
    goto z_bb_138;
    z_bb_142:
    if ((int)(ab < bb)) goto z_bb_146; else goto z_bb_147;
    z_bb_143:
    zT_323 = 1;
    zT_322 = zT_323;
    goto z_bb_145;
    z_bb_144:
    zT_324 = 0;
    zT_322 = zT_324;
    goto z_bb_145;
    z_bb_145:
    v = zT_322;
    v = zT_322;
    goto z_bb_141;
    z_bb_146:
    zT_327 = 1;
    zT_326 = zT_327;
    goto z_bb_148;
    z_bb_147:
    zT_328 = 0;
    zT_326 = zT_328;
    goto z_bb_148;
    z_bb_148:
    v = zT_326;
    v = zT_326;
    goto z_bb_141;
    z_bb_149:
    if ((int)(z_signed != (unsigned char)(0))) goto z_bb_152; else goto z_bb_154;
    z_bb_150:
    goto z_bb_138;
    z_bb_151:
    if ((int)(op == (unsigned char)(14))) goto z_bb_161; else goto z_bb_163;
    z_bb_152:
    zT_333 = ab;
    zT_334 = bb;
    zT_335 = w;
    zT_336 = zF_0B35676F_cmpBitsSigned(zT_333, zT_334, zT_335);
    zT_337 = 0;
    if ((int)(zT_336 <= zT_337)) goto z_bb_155; else goto z_bb_156;
    z_bb_153:
    goto z_bb_150;
    z_bb_154:
    if ((int)(ab <= bb)) goto z_bb_158; else goto z_bb_159;
    z_bb_155:
    zT_340 = 1;
    zT_339 = zT_340;
    goto z_bb_157;
    z_bb_156:
    zT_341 = 0;
    zT_339 = zT_341;
    goto z_bb_157;
    z_bb_157:
    v = zT_339;
    v = zT_339;
    goto z_bb_153;
    z_bb_158:
    zT_344 = 1;
    zT_343 = zT_344;
    goto z_bb_160;
    z_bb_159:
    zT_345 = 0;
    zT_343 = zT_345;
    goto z_bb_160;
    z_bb_160:
    v = zT_343;
    v = zT_343;
    goto z_bb_153;
    z_bb_161:
    if ((int)(z_signed != (unsigned char)(0))) goto z_bb_164; else goto z_bb_166;
    z_bb_162:
    goto z_bb_150;
    z_bb_163:
    if ((int)(op == (unsigned char)(15))) goto z_bb_173; else goto z_bb_175;
    z_bb_164:
    zT_350 = ab;
    zT_351 = bb;
    zT_352 = w;
    zT_353 = zF_0B35676F_cmpBitsSigned(zT_350, zT_351, zT_352);
    zT_354 = 0;
    if ((int)(zT_353 > zT_354)) goto z_bb_167; else goto z_bb_168;
    z_bb_165:
    goto z_bb_162;
    z_bb_166:
    if ((int)(ab > bb)) goto z_bb_170; else goto z_bb_171;
    z_bb_167:
    zT_357 = 1;
    zT_356 = zT_357;
    goto z_bb_169;
    z_bb_168:
    zT_358 = 0;
    zT_356 = zT_358;
    goto z_bb_169;
    z_bb_169:
    v = zT_356;
    v = zT_356;
    goto z_bb_165;
    z_bb_170:
    zT_361 = 1;
    zT_360 = zT_361;
    goto z_bb_172;
    z_bb_171:
    zT_362 = 0;
    zT_360 = zT_362;
    goto z_bb_172;
    z_bb_172:
    v = zT_360;
    v = zT_360;
    goto z_bb_165;
    z_bb_173:
    if ((int)(z_signed != (unsigned char)(0))) goto z_bb_176; else goto z_bb_178;
    z_bb_174:
    goto z_bb_162;
    z_bb_175:
    return (unsigned char)(0);
    z_bb_176:
    zT_367 = ab;
    zT_368 = bb;
    zT_369 = w;
    zT_370 = zF_0B35676F_cmpBitsSigned(zT_367, zT_368, zT_369);
    zT_371 = 0;
    if ((int)(zT_370 >= zT_371)) goto z_bb_179; else goto z_bb_180;
    z_bb_177:
    goto z_bb_174;
    z_bb_178:
    if ((int)(ab >= bb)) goto z_bb_182; else goto z_bb_183;
    z_bb_179:
    zT_374 = 1;
    zT_373 = zT_374;
    goto z_bb_181;
    z_bb_180:
    zT_375 = 0;
    zT_373 = zT_375;
    goto z_bb_181;
    z_bb_181:
    v = zT_373;
    v = zT_373;
    goto z_bb_177;
    z_bb_182:
    zT_378 = 1;
    zT_377 = zT_378;
    goto z_bb_184;
    z_bb_183:
    zT_379 = 0;
    zT_377 = zT_379;
    goto z_bb_184;
    z_bb_184:
    v = zT_377;
    v = zT_377;
    goto z_bb_177;
    z_bb_185:
    zT_384 = 1;
    zT_383 = zT_384;
    goto z_bb_187;
    z_bb_186:
    zT_385 = 0;
    zT_383 = zT_385;
    goto z_bb_187;
    z_bb_187:
    *out_is_bool = zT_383;
    return (unsigned char)(1);
}

/* tryFoldIntCast */
unsigned char zF_2EC2B21D_tryFoldIntCast(zT_5EDE903E_Ctx* c, zT_6BA597BC_LirInst inst, zT_79FAE712_u64* out_value) {
    unsigned int zT_3;
    unsigned char zT_5;
    unsigned int zT_10;
    unsigned int zT_12;
    zT_5EDE903E_Ctx* zT_14;
    unsigned int zT_15;
    unsigned int zT_16 = 0;
    unsigned int zT_20;
    unsigned int zT_24;
    unsigned char zT_26;
    zT_5EDE903E_Ctx* zT_27;
    unsigned int zT_28;
    unsigned int* zT_29;
    unsigned char* zT_30;
    unsigned int* zT_31;
    unsigned char* zT_32;
    unsigned char zT_33 = 0;
    zT_338B7C76_TypeRegistry* zT_37;
    unsigned int zT_38;
    zT_338B7C76_TypeRegistry* zT_43;
    zT_D155D06D_Type* zT_44;
    unsigned int zT_45;
    zT_D155D06D_Type zT_46;
    zT_33EF6BFB_TypeKind zT_48;
    zT_33EF6BFB_TypeKind zT_49;
    unsigned int zT_50 = 0;
    zT_33EF6BFB_TypeKind zT_55;
    zT_33EF6BFB_TypeKind zT_56;
    unsigned char zT_57 = 0;
    unsigned int* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_79FAE712_u64* zT_63;
    unsigned int zT_64;
    zT_79FAE712_u64 zT_65;
    unsigned int zT_67;
    zT_79FAE712_u64 zT_68 = 0;
    zT_79FAE712_u64 zT_70;
    unsigned char zT_72;
    zT_79FAE712_u64 zT_74;
    zT_79FAE712_u64 zT_75;
    unsigned int zT_76;
    unsigned char zT_77;
    unsigned char* zT_78;
    zT_79FAE712_u64* zT_79;
    unsigned char* zT_80;
    zT_79FAE712_u64* zT_81;
    unsigned char zT_83;
    unsigned int zT_89;
    zT_79FAE712_u64 zT_90 = 0;
    unsigned char zT_92;
    unsigned int zT_94;
    zT_79FAE712_u64 zT_95 = 0;
    unsigned char zT_99;
    unsigned char zT_101;
    unsigned int zT_106;
    zT_79FAE712_u64 zT_107 = 0;
    zT_79FAE712_u64 zT_109;
    zT_79FAE712_u64 zT_114;
    zT_79FAE712_u64 zT_115;
    zT_9F82026D_anon_49295 ic;
    unsigned int res;
    unsigned int val_t;
    unsigned int rt;
    unsigned int ow;
    unsigned char os;
    zT_D155D06D_Type ty;
    unsigned int tw;
    unsigned char ts;
    unsigned int vp;
    zT_79FAE712_u64 bits;
    zT_79FAE712_u64 m;
    zT_79FAE712_u64 b;
    unsigned char is_neg;
    zT_79FAE712_u64 mag;
    unsigned char ok;
    zT_79FAE712_u64 mag_lim;
    zT_79FAE712_u64 ub;
    zT_79FAE712_u64 tm;
    zT_79FAE712_u64 v;
    zT_3 = inst.tag;
switch (zT_3) {
case 38: goto z_bb_1;
default: goto z_bb_2;
}
    z_bb_1:
    ic = inst.payload.int_cast._0;
    zT_5 = ic.is_checked;
    if ((int)(zT_5 != (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    return (unsigned char)(0);
    return 0;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_10 = ic.result;
    res = zT_10;
    res = zT_10;
    res = zT_10;
    zT_12 = ic.value;
    val_t = zT_12;
    val_t = zT_12;
    val_t = zT_12;
    zT_14 = c;
    zT_15 = res;
    zT_16 = zF_D835BE2E_tempDeclTypeId(zT_14, zT_15);
    rt = zT_16;
    rt = zT_16;
    rt = zT_16;
    if ((int)(rt == (unsigned int)(4294967295u))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_20 = ic.target;
    if ((int)(rt != zT_20)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_24 = 0;
    ow = zT_24;
    ow = zT_24;
    ow = zT_24;
    zT_26 = 0;
    os = zT_26;
    os = zT_26;
    os = zT_26;
    zT_27 = c;
    zT_28 = val_t;
    zT_31 = &ow;
    zT_29 = zT_31;
    zT_32 = &os;
    zT_30 = zT_32;
    zT_33 = zF_86D6C86A_constOperandIntType(zT_27, zT_28, zT_29, zT_30);
    if ((int)(zT_33 == (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_37 = c->reg;
    zT_38 = zT_37->types_len;
    if ((int)(rt >= (unsigned int)((unsigned int)zT_38))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_43 = c->reg;
    zT_44 = zT_43->types_items;
    zT_45 = (unsigned int)rt;
    zT_46 = zT_44[zT_45];
    ty = zT_46;
    ty = zT_46;
    ty = zT_46;
    zT_49 = ty.kind;
    zT_48 = zT_49;
    zT_50 = zF_90DDF69C_intKindWidth(zT_48);
    tw = zT_50;
    tw = zT_50;
    tw = zT_50;
    if ((int)(tw == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_56 = ty.kind;
    zT_55 = zT_56;
    zT_57 = zF_D4EA92B8_intKindSigned(zT_55);
    ts = zT_57;
    ts = zT_57;
    ts = zT_57;
    zT_59 = c->t2p;
    zT_60 = (unsigned int)val_t;
    zT_61 = zT_59[zT_60];
    vp = zT_61;
    vp = zT_61;
    vp = zT_61;
    zT_63 = c->cv;
    zT_64 = (unsigned int)vp;
    zT_65 = zT_63[zT_64];
    bits = zT_65;
    bits = zT_65;
    bits = zT_65;
    zT_67 = ow;
    zT_68 = zF_5E3CE23D_lowMask(zT_67);
    m = zT_68;
    m = zT_68;
    m = zT_68;
    zT_70 = bits & m;
    b = zT_70;
    b = zT_70;
    b = zT_70;
    zT_72 = 0;
    is_neg = zT_72;
    is_neg = zT_72;
    is_neg = zT_72;
    zT_74 = 0;
    mag = zT_74;
    mag = zT_74;
    mag = zT_74;
    zT_75 = b;
    zT_76 = ow;
    zT_77 = os;
    zT_80 = &is_neg;
    zT_78 = zT_80;
    zT_81 = &mag;
    zT_79 = zT_81;
    zF_28365D82_signMagnitude(zT_75, zT_76, zT_77, zT_78, zT_79);
    zT_83 = 0;
    ok = zT_83;
    ok = zT_83;
    ok = zT_83;
    if ((int)(ts == (unsigned char)(0))) goto z_bb_17; else goto z_bb_19;
    z_bb_17:
    if ((int)(is_neg == (unsigned char)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    if ((int)(ok == (unsigned char)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_19:
    zT_94 = tw;
    zT_95 = zF_3794934D_sigBit(zT_94);
    mag_lim = zT_95;
    mag_lim = zT_95;
    mag_lim = zT_95;
    if ((int)(is_neg != (unsigned char)(0))) goto z_bb_24; else goto z_bb_26;
    z_bb_20:
    zT_89 = tw;
    zT_90 = zF_5E3CE23D_lowMask(zT_89);
    ub = zT_90;
    ub = zT_90;
    ub = zT_90;
    if ((int)(mag <= ub)) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_92 = 1;
    ok = zT_92;
    ok = zT_92;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    if ((int)(mag <= mag_lim)) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    goto z_bb_18;
    z_bb_26:
    if ((int)(mag < mag_lim)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_99 = 1;
    ok = zT_99;
    ok = zT_99;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_25;
    z_bb_29:
    zT_101 = 1;
    ok = zT_101;
    ok = zT_101;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_25;
    z_bb_31:
    return (unsigned char)(0);
    z_bb_32:
    zT_106 = tw;
    zT_107 = zF_5E3CE23D_lowMask(zT_106);
    tm = zT_107;
    tm = zT_107;
    tm = zT_107;
    zT_109 = 0;
    v = zT_109;
    v = zT_109;
    v = zT_109;
    if ((int)(is_neg != (unsigned char)(0))) goto z_bb_33; else goto z_bb_35;
    z_bb_33:
    zT_114 = (zT_79FAE712_u64)((zT_79FAE712_u64)(0) - mag) & tm;
    v = zT_114;
    v = zT_114;
    goto z_bb_34;
    z_bb_34:
    *out_value = v;
    return (unsigned char)(1);
    z_bb_35:
    zT_115 = mag & tm;
    v = zT_115;
    v = zT_115;
    goto z_bb_34;
}

/* runConstFold */
unsigned char zF_7C7AB1D6_runConstFold(zT_5EDE903E_Ctx* c) {
    unsigned char zT_2;
    unsigned int zT_4;
    zT_BBC23664_LirFunction* zT_5;
    zT_1CF28CA3_BasicBlockArrayList zT_6;
    unsigned int zT_7;
    zT_BBC23664_LirFunction* zT_10;
    zT_1CF28CA3_BasicBlockArrayList zT_11;
    zT_88A68B1A_BasicBlock* zT_12;
    zT_88A68B1A_BasicBlock* zT_13;
    unsigned int zT_15;
    zT_DAE4631D_LirInstArrayList zT_16;
    unsigned int zT_17;
    zT_DAE4631D_LirInstArrayList zT_20;
    zT_6BA597BC_LirInst* zT_21;
    zT_6BA597BC_LirInst zT_22;
    unsigned int zT_23;
    zT_79FAE712_u64 zT_26;
    unsigned char zT_28;
    zT_5EDE903E_Ctx* zT_29;
    zT_6BA597BC_LirInst zT_30;
    zT_79FAE712_u64* zT_31;
    unsigned char* zT_32;
    zT_79FAE712_u64* zT_33;
    unsigned char* zT_34;
    unsigned char zT_35 = 0;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    zT_6BA597BC_LirInst zT_46;
    zT_A0D40C73_anon_49367 zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_DAE4631D_LirInstArrayList zT_50;
    zT_6BA597BC_LirInst* zT_51;
    zT_6BA597BC_LirInst zT_52;
    zT_2AE01EA4_anon_49339 zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_DAE4631D_LirInstArrayList zT_56;
    zT_6BA597BC_LirInst* zT_57;
    unsigned char zT_58;
    zT_79FAE712_u64 zT_61;
    unsigned char zT_63;
    zT_5EDE903E_Ctx* zT_64;
    zT_6BA597BC_LirInst zT_65;
    zT_79FAE712_u64* zT_66;
    unsigned char* zT_67;
    zT_79FAE712_u64* zT_68;
    unsigned char* zT_69;
    unsigned char zT_70 = 0;
    unsigned char zT_78;
    unsigned char zT_79;
    unsigned char zT_80;
    zT_6BA597BC_LirInst zT_81;
    zT_A0D40C73_anon_49367 zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_DAE4631D_LirInstArrayList zT_85;
    zT_6BA597BC_LirInst* zT_86;
    zT_6BA597BC_LirInst zT_87;
    zT_2AE01EA4_anon_49339 zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_DAE4631D_LirInstArrayList zT_91;
    zT_6BA597BC_LirInst* zT_92;
    unsigned char zT_93;
    zT_79FAE712_u64 zT_96;
    zT_5EDE903E_Ctx* zT_97;
    zT_6BA597BC_LirInst zT_98;
    zT_79FAE712_u64* zT_99;
    zT_79FAE712_u64* zT_100;
    unsigned char zT_101 = 0;
    zT_6BA597BC_LirInst zT_104;
    zT_2AE01EA4_anon_49339 zT_105;
    unsigned int zT_106;
    unsigned int zT_107;
    zT_DAE4631D_LirInstArrayList zT_108;
    zT_6BA597BC_LirInst* zT_109;
    unsigned char zT_110;
    unsigned int zT_112;
    unsigned int zT_114;
    unsigned char changed;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_6BA597BC_LirInst inst;
    zT_F5475070_anon_49111 b;
    zT_79FAE712_u64 v;
    unsigned char is_bool;
    zT_FD475D08_anon_49119 u;
    zT_9F82026D_anon_49295 ic;
    unsigned char bv;
    zT_2 = 0;
    changed = zT_2;
    changed = zT_2;
    changed = zT_2;
    zT_4 = 0;
    bi = zT_4;
    bi = zT_4;
    bi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = c->lir_fn;
    zT_6 = zT_5->blocks;
    zT_7 = zT_6.len;
    if ((int)(bi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = c->lir_fn;
    zT_11 = zT_10->blocks;
    zT_12 = zT_11.items;
    zT_13 = zT_12 + bi;
    bb = zT_13;
    bb = zT_13;
    bb = zT_13;
    zT_15 = 0;
    ii = zT_15;
    ii = zT_15;
    ii = zT_15;
    goto z_bb_5;
    z_bb_3:
    return changed;
    z_bb_4:
    zT_114 = bi + (unsigned int)(1);
    bi = zT_114;
    bi = zT_114;
    goto z_bb_1;
    z_bb_5:
    zT_16 = bb->insts;
    zT_17 = zT_16.len;
    if ((int)(ii < zT_17)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = bb->insts;
    zT_21 = zT_20.items;
    zT_22 = zT_21[ii];
    inst = zT_22;
    inst = zT_22;
    inst = zT_22;
    zT_23 = inst.tag;
switch (zT_23) {
case 12: goto z_bb_9;
case 13: goto z_bb_10;
case 38: goto z_bb_11;
default: goto z_bb_12;
}
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_112 = ii + (unsigned int)(1);
    ii = zT_112;
    ii = zT_112;
    goto z_bb_5;
    z_bb_9:
    b = inst.payload.binary._0;
    zT_26 = 0;
    v = zT_26;
    v = zT_26;
    v = zT_26;
    zT_28 = 0;
    is_bool = zT_28;
    is_bool = zT_28;
    is_bool = zT_28;
    zT_29 = c;
    zT_30 = inst;
    zT_33 = &v;
    zT_31 = zT_33;
    zT_34 = &is_bool;
    zT_32 = zT_34;
    zT_35 = zF_EEEDCAC3_tryFoldBinaryOp(zT_29, zT_30, zT_31, zT_32);
    if ((int)(zT_35 == (unsigned char)(1))) goto z_bb_15; else goto z_bb_16;
    z_bb_10:
    u = inst.payload.unary._0;
    zT_61 = 0;
    v = zT_61;
    v = zT_61;
    v = zT_61;
    zT_63 = 0;
    is_bool = zT_63;
    is_bool = zT_63;
    is_bool = zT_63;
    zT_64 = c;
    zT_65 = inst;
    zT_68 = &v;
    zT_66 = zT_68;
    zT_69 = &is_bool;
    zT_67 = zT_69;
    zT_70 = zF_EEEDCAC3_tryFoldBinaryOp(zT_64, zT_65, zT_66, zT_67);
    if ((int)(zT_70 == (unsigned char)(1))) goto z_bb_23; else goto z_bb_24;
    z_bb_11:
    ic = inst.payload.int_cast._0;
    zT_96 = 0;
    v = zT_96;
    v = zT_96;
    v = zT_96;
    zT_97 = c;
    zT_98 = inst;
    zT_100 = &v;
    zT_99 = zT_100;
    zT_101 = zF_2EC2B21D_tryFoldIntCast(zT_97, zT_98, zT_99);
    if ((int)(zT_101 == (unsigned char)(1))) goto z_bb_31; else goto z_bb_32;
    z_bb_12:
    goto z_bb_14;
    z_bb_14:
    goto z_bb_8;
    z_bb_15:
    if ((int)(is_bool != (unsigned char)(0))) goto z_bb_17; else goto z_bb_19;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    if ((int)(v != (zT_79FAE712_u64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_58 = 1;
    changed = zT_58;
    changed = zT_58;
    goto z_bb_16;
    z_bb_19:
    zT_53.value = v;
    zT_54 = b.result;
    zT_53.result = zT_54;
    zT_55 = 44;
    zT_52.tag = zT_55;
    zT_52.payload.int_const._0 = zT_53;
    zT_56 = bb->insts;
    zT_57 = zT_56.items;
    zT_57[ii] = zT_52;
    goto z_bb_18;
    z_bb_20:
    zT_44 = 1;
    zT_43 = zT_44;
    goto z_bb_22;
    z_bb_21:
    zT_45 = 0;
    zT_43 = zT_45;
    goto z_bb_22;
    z_bb_22:
    bv = zT_43;
    bv = zT_43;
    bv = zT_43;
    zT_47.value = bv;
    zT_48 = b.result;
    zT_47.result = zT_48;
    zT_49 = 49;
    zT_46.tag = zT_49;
    zT_46.payload.bool_const._0 = zT_47;
    zT_50 = bb->insts;
    zT_51 = zT_50.items;
    zT_51[ii] = zT_46;
    goto z_bb_18;
    z_bb_23:
    if ((int)(is_bool != (unsigned char)(0))) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    goto z_bb_14;
    z_bb_25:
    if ((int)(v != (zT_79FAE712_u64)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_93 = 1;
    changed = zT_93;
    changed = zT_93;
    goto z_bb_24;
    z_bb_27:
    zT_88.value = v;
    zT_89 = u.result;
    zT_88.result = zT_89;
    zT_90 = 44;
    zT_87.tag = zT_90;
    zT_87.payload.int_const._0 = zT_88;
    zT_91 = bb->insts;
    zT_92 = zT_91.items;
    zT_92[ii] = zT_87;
    goto z_bb_26;
    z_bb_28:
    zT_79 = 1;
    zT_78 = zT_79;
    goto z_bb_30;
    z_bb_29:
    zT_80 = 0;
    zT_78 = zT_80;
    goto z_bb_30;
    z_bb_30:
    bv = zT_78;
    bv = zT_78;
    bv = zT_78;
    zT_82.value = bv;
    zT_83 = u.result;
    zT_82.result = zT_83;
    zT_84 = 49;
    zT_81.tag = zT_84;
    zT_81.payload.bool_const._0 = zT_82;
    zT_85 = bb->insts;
    zT_86 = zT_85.items;
    zT_86[ii] = zT_81;
    goto z_bb_26;
    z_bb_31:
    zT_105.value = v;
    zT_106 = ic.result;
    zT_105.result = zT_106;
    zT_107 = 44;
    zT_104.tag = zT_107;
    zT_104.payload.int_const._0 = zT_105;
    zT_108 = bb->insts;
    zT_109 = zT_108.items;
    zT_109[ii] = zT_104;
    zT_110 = 1;
    changed = zT_110;
    changed = zT_110;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_14;
}

/* lirOptRun */
void zF_37363942_lirOptRun(zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg, zT_BBC23664_LirFunction* lir_fn) {
    zT_BBC23664_LirFunction* zT_5;
    unsigned int zT_6 = 0;
    zT_5EDE903E_Ctx zT_10;
    zT_3E40CD83_Sand* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int* zT_15 = 0;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int* zT_20 = 0;
    zT_3E40CD83_Sand* zT_21;
    unsigned int zT_22;
    unsigned int* zT_23 = 0;
    zT_3E40CD83_Sand* zT_24;
    unsigned int zT_25;
    unsigned int* zT_26 = 0;
    zT_3E40CD83_Sand* zT_27;
    unsigned int zT_28;
    unsigned char* zT_29 = 0;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_31;
    unsigned char* zT_32 = 0;
    zT_3E40CD83_Sand* zT_33;
    unsigned int zT_34;
    unsigned char* zT_35 = 0;
    zT_3E40CD83_Sand* zT_36;
    unsigned int zT_37;
    unsigned int* zT_38 = 0;
    zT_3E40CD83_Sand* zT_39;
    unsigned int zT_40;
    unsigned int* zT_41 = 0;
    zT_3E40CD83_Sand* zT_42;
    unsigned int zT_43;
    unsigned char* zT_44 = 0;
    zT_3E40CD83_Sand* zT_45;
    unsigned int zT_46;
    unsigned char* zT_47 = 0;
    zT_3E40CD83_Sand* zT_48;
    unsigned int zT_49;
    zT_79FAE712_u64* zT_50 = 0;
    zT_3E40CD83_Sand* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int* zT_55 = 0;
    zT_3E40CD83_Sand* zT_56;
    unsigned int zT_57;
    unsigned char* zT_58 = 0;
    zT_3E40CD83_Sand* zT_59;
    unsigned int zT_60;
    unsigned char* zT_61 = 0;
    zT_3E40CD83_Sand* zT_62;
    unsigned int zT_63;
    unsigned int* zT_64 = 0;
    zT_3E40CD83_Sand* zT_65;
    unsigned int zT_66;
    unsigned int* zT_67 = 0;
    zT_3E40CD83_Sand* zT_68;
    unsigned int zT_69;
    unsigned char* zT_70 = 0;
    zT_3E40CD83_Sand* zT_71;
    unsigned int zT_72;
    unsigned char* zT_73 = 0;
    unsigned int zT_75;
    zT_5D72FBF8_TempDeclArrayList zT_76;
    unsigned int zT_77;
    zT_5D72FBF8_TempDeclArrayList zT_80;
    zT_1937645B_TempDecl* zT_81;
    zT_1937645B_TempDecl zT_82;
    unsigned int zT_83;
    unsigned int zT_85;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    unsigned int* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    unsigned int zT_94;
    zT_5EDE903E_Ctx* zT_95;
    zT_5EDE903E_Ctx* zT_96;
    zT_5EDE903E_Ctx* zT_97;
    zT_5EDE903E_Ctx* zT_98;
    unsigned char zT_99 = 0;
    zT_5EDE903E_Ctx* zT_100;
    zT_5EDE903E_Ctx* zT_101;
    zT_5EDE903E_Ctx* zT_102;
    zT_5EDE903E_Ctx* zT_103;
    unsigned char zT_104 = 0;
    zT_5EDE903E_Ctx* zT_105;
    zT_5EDE903E_Ctx* zT_106;
    zT_5EDE903E_Ctx* zT_107;
    zT_5EDE903E_Ctx* zT_108;
    unsigned char* zT_110;
    unsigned char* zT_111;
    unsigned int* zT_112;
    unsigned int* zT_113;
    unsigned int* zT_114;
    unsigned int* zT_115;
    unsigned int max_temp;
    zT_5EDE903E_Ctx c;
    unsigned int hti;
    zT_1937645B_TempDecl td;
    zG_78C2C6B4_g_nest_active = (unsigned char)(0);
    zT_5 = lir_fn;
    zT_6 = zF_005F8966_maxTempOf(zT_5);
    max_temp = zT_6;
    max_temp = zT_6;
    max_temp = zT_6;
    if ((int)(max_temp == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_10.alloc = alloc;
    zT_10.reg = reg;
    zT_10.lir_fn = lir_fn;
    zT_10.max_temp = max_temp;
    zT_11 = alloc;
    zT_12 = max_temp;
    zT_14 = 4294967295u;
    zT_13 = zT_14;
    zT_15 = zF_82E88BBC_allocU32With(zT_11, zT_12, zT_13);
    zT_10.t2p = zT_15;
    zT_16 = alloc;
    zT_17 = max_temp;
    zT_19 = 18;
    zT_18 = zT_19;
    zT_20 = zF_82E88BBC_allocU32With(zT_16, zT_17, zT_18);
    zT_10.ttype = zT_20;
    zT_21 = alloc;
    zT_22 = max_temp;
    zT_23 = zF_730A6C2A_allocU32Raw(zT_21, zT_22);
    zT_10.rc = zT_23;
    zT_24 = alloc;
    zT_25 = max_temp;
    zT_26 = zF_730A6C2A_allocU32Raw(zT_24, zT_25);
    zT_10.wc = zT_26;
    zT_27 = alloc;
    zT_28 = max_temp;
    zT_29 = zF_F15DB413_allocU8Raw(zT_27, zT_28);
    zT_10.at = zT_29;
    zT_30 = alloc;
    zT_31 = max_temp;
    zT_32 = zF_F15DB413_allocU8Raw(zT_30, zT_31);
    zT_10.ex = zT_32;
    zT_33 = alloc;
    zT_34 = max_temp;
    zT_35 = zF_F15DB413_allocU8Raw(zT_33, zT_34);
    zT_10.dp = zT_35;
    zT_36 = alloc;
    zT_37 = max_temp;
    zT_38 = zF_730A6C2A_allocU32Raw(zT_36, zT_37);
    zT_10.rd_bb = zT_38;
    zT_39 = alloc;
    zT_40 = max_temp;
    zT_41 = zF_730A6C2A_allocU32Raw(zT_39, zT_40);
    zT_10.rd_ii = zT_41;
    zT_42 = alloc;
    zT_43 = max_temp;
    zT_44 = zF_F15DB413_allocU8Raw(zT_42, zT_43);
    zT_10.rar = zT_44;
    zT_45 = alloc;
    zT_46 = max_temp;
    zT_47 = zF_F15DB413_allocU8Raw(zT_45, zT_46);
    zT_10.cf = zT_47;
    zT_48 = alloc;
    zT_49 = max_temp;
    zT_50 = zF_1A0C0ABB_allocU64Raw(zT_48, zT_49);
    zT_10.cv = zT_50;
    zT_51 = alloc;
    zT_52 = max_temp;
    zT_54 = 4294967295u;
    zT_53 = zT_54;
    zT_55 = zF_82E88BBC_allocU32With(zT_51, zT_52, zT_53);
    zT_10.ren = zT_55;
    zT_56 = alloc;
    zT_57 = max_temp;
    zT_58 = zF_F15DB413_allocU8Raw(zT_56, zT_57);
    zT_10.cand = zT_58;
    zT_59 = alloc;
    zT_60 = max_temp;
    zT_61 = zF_F15DB413_allocU8Raw(zT_59, zT_60);
    zT_10.depth = zT_61;
    zT_62 = alloc;
    zT_63 = max_temp;
    zT_64 = zF_730A6C2A_allocU32Raw(zT_62, zT_63);
    zT_10.df_bb = zT_64;
    zT_65 = alloc;
    zT_66 = max_temp;
    zT_67 = zF_730A6C2A_allocU32Raw(zT_65, zT_66);
    zT_10.df_ii = zT_67;
    zT_68 = alloc;
    zT_69 = max_temp;
    zT_70 = zF_F15DB413_allocU8Raw(zT_68, zT_69);
    zT_10.ga = zT_70;
    zT_71 = alloc;
    zT_72 = max_temp;
    zT_73 = zF_F15DB413_allocU8Raw(zT_71, zT_72);
    zT_10.gam = zT_73;
    c = zT_10;
    c = zT_10;
    c = zT_10;
    zT_75 = 0;
    hti = zT_75;
    hti = zT_75;
    hti = zT_75;
    goto z_bb_3;
    z_bb_3:
    zT_76 = lir_fn->hoisted_temps;
    zT_77 = zT_76.len;
    if ((int)(hti < zT_77)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_80 = lir_fn->hoisted_temps;
    zT_81 = zT_80.items;
    zT_82 = zT_81[hti];
    td = zT_82;
    td = zT_82;
    td = zT_82;
    zT_83 = td.temp_id;
    if ((int)(zT_83 < max_temp)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_96 = &c;
    zT_95 = zT_96;
    zF_D6CE151A_resetScratch(zT_95);
    zT_98 = &c;
    zT_97 = zT_98;
    zT_99 = zF_4AE99A73_copyPropagate(zT_97);
    (void)zT_99;
    zT_101 = &c;
    zT_100 = zT_101;
    zF_6A60FAEB_scanAll(zT_100);
    zT_103 = &c;
    zT_102 = zT_103;
    zT_104 = zF_7C7AB1D6_runConstFold(zT_102);
    (void)zT_104;
    zT_106 = &c;
    zT_105 = zT_106;
    zF_6A60FAEB_scanAll(zT_105);
    zT_108 = &c;
    zT_107 = zT_108;
    zF_02672451_computeNestMetadata(zT_107);
    zG_78C2C6B4_g_nest_active = (unsigned char)(1);
    zG_14E10714_g_nest_max = max_temp;
    zT_110 = c.cand;
    zG_30D934F4_g_nest_cand = zT_110;
    zT_111 = c.depth;
    zG_7DE170EB_g_nest_depth = zT_111;
    zT_112 = c.df_bb;
    zG_32175378_g_nest_dfbb = zT_112;
    zT_113 = c.df_ii;
    zG_5501C442_g_nest_dfii = zT_113;
    zT_114 = c.rd_bb;
    zG_46632058_g_nest_rdbb = zT_114;
    zT_115 = c.rd_ii;
    zG_694BFE22_g_nest_rdii = zT_115;
    return;
    z_bb_6:
    zT_94 = hti + (unsigned int)(1);
    hti = zT_94;
    hti = zT_94;
    goto z_bb_3;
    z_bb_7:
    zT_85 = (unsigned int)hti;
    zT_86 = c.t2p;
    zT_87 = td.temp_id;
    zT_88 = (unsigned int)zT_87;
    zT_86[zT_88] = zT_85;
    zT_89 = td.type_id;
    zT_90 = c.ttype;
    zT_91 = td.temp_id;
    zT_92 = (unsigned int)zT_91;
    zT_90[zT_92] = zT_89;
    goto z_bb_8;
    z_bb_8:
    goto z_bb_6;
}

/* allocU32With */
unsigned int* zF_82E88BBC_allocU32With(zT_3E40CD83_Sand* alloc, unsigned int n, unsigned int fill) {
    zT_3E40CD83_Sand* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_0F51E4CA_EU_222 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    unsigned char* zT_14;
    unsigned int* zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned char* raw;
    unsigned int* a;
    unsigned int i;
    zT_4 = alloc;
    zT_9 = (unsigned int)((unsigned int)n) * (unsigned int)(4);
    zT_5 = zT_9;
    zT_10 = 4;
    zT_6 = zT_10;
    zT_11 = zF_1395EB68_sandAlloc(zT_4, zT_5, zT_6);
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_14 = zT_11.data.payload;
    zT_13 = zT_14;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    raw = zT_13;
    raw = zT_13;
    zT_16 = (unsigned int*)raw;
    a = zT_16;
    a = zT_16;
    a = zT_16;
    zT_18 = 0;
    i = zT_18;
    i = zT_18;
    i = zT_18;
    goto z_bb_4;
    z_bb_4:
    if ((int)(i < n)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_20 = (unsigned int)i;
    a[zT_20] = fill;
    goto z_bb_7;
    z_bb_6:
    return a;
    z_bb_7:
    zT_22 = i + (unsigned int)(1);
    i = zT_22;
    i = zT_22;
    goto z_bb_4;
}

/* allocU32Raw */
unsigned int* zF_730A6C2A_allocU32Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_0F51E4CA_EU_222 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* zT_13;
    unsigned char* raw;
    zT_3 = alloc;
    zT_8 = (unsigned int)((unsigned int)n) * (unsigned int)(4);
    zT_4 = zT_8;
    zT_9 = 4;
    zT_5 = zT_9;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, zT_4, zT_5);
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_13 = zT_10.data.payload;
    zT_12 = zT_13;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    raw = zT_12;
    raw = zT_12;
    return (unsigned int*)((unsigned int*)raw);
}

/* allocU64Raw */
zT_79FAE712_u64* zF_1A0C0ABB_allocU64Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_0F51E4CA_EU_222 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* zT_13;
    unsigned char* raw;
    zT_3 = alloc;
    zT_8 = (unsigned int)((unsigned int)n) * (unsigned int)(8);
    zT_4 = zT_8;
    zT_9 = 4;
    zT_5 = zT_9;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, zT_4, zT_5);
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_13 = zT_10.data.payload;
    zT_12 = zT_13;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    raw = zT_12;
    raw = zT_12;
    return (zT_79FAE712_u64*)((zT_79FAE712_u64*)raw);
}

/* allocU8Raw */
unsigned char* zF_F15DB413_allocU8Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_0F51E4CA_EU_222 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* zT_13;
    unsigned char* raw;
    zT_3 = alloc;
    zT_8 = (unsigned int)((unsigned int)n) * (unsigned int)(1);
    zT_4 = zT_8;
    zT_9 = 1;
    zT_5 = zT_9;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, zT_4, zT_5);
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_13 = zT_10.data.payload;
    zT_12 = zT_13;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    raw = zT_12;
    raw = zT_12;
    return (unsigned char*)((unsigned char*)raw);
}

/* __module_init */
void zF_780653D2___module_init_22(void) {
    int zT_1;
    int zT_3;
    zG_8D933C0A_kCopyPropMaxIter = (unsigned int)(128);
    zT_1 = 0;
    zG_78C2C6B4_g_nest_active = (unsigned char)((unsigned char)zT_1);
    zT_3 = 0;
    zG_14E10714_g_nest_max = (unsigned int)((unsigned int)zT_3);
    return;
}

/* EOF */
