#ifndef ZIG_MODULE_GROWABLE_ARRAY_6014E5AF_H
#define ZIG_MODULE_GROWABLE_ARRAY_6014E5AF_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "ast_2FA12982.h"

#ifndef ZIG_STRUCT_zT_47B162D1_U8ArrayList
#define ZIG_STRUCT_zT_47B162D1_U8ArrayList
struct zT_47B162D1_U8ArrayList {
	unsigned char* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_47B162D1_U8ArrayList */
#ifndef ZIG_STRUCT_zT_1386C3E8_AstNodeArrayList
#define ZIG_STRUCT_zT_1386C3E8_AstNodeArrayList
struct zT_1386C3E8_AstNodeArrayList {
	zT_22A7C88B_AstNode* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_1386C3E8_AstNodeArrayList */
#ifndef ZIG_STRUCT_zT_C4A0A7DB_U64ArrayList
#define ZIG_STRUCT_zT_C4A0A7DB_U64ArrayList
struct zT_C4A0A7DB_U64ArrayList {
	zT_79FAE712_u64* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_C4A0A7DB_U64ArrayList */
#ifndef ZIG_STRUCT_zT_AB1FE668_F64ArrayList
#define ZIG_STRUCT_zT_AB1FE668_F64ArrayList
struct zT_AB1FE668_F64ArrayList {
	double* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_AB1FE668_F64ArrayList */
#ifndef ZIG_STRUCT_zT_CCB21906_FnProtoArrayList
#define ZIG_STRUCT_zT_CCB21906_FnProtoArrayList
struct zT_CCB21906_FnProtoArrayList {
	zT_243D6A41_FnProto* items;
	unsigned int len;
	unsigned int capacity;
	zT_3E40CD83_Sand* allocator;
};
#endif /* ZIG_STRUCT_zT_CCB21906_FnProtoArrayList */

/* Forward declarations */
zT_B687BB96_U32ArrayList zF_8E537D0C_u32ArrayListInit(zT_3E40CD83_Sand*);
void zF_1580F084_u32ArrayListEnsureC(zT_B687BB96_U32ArrayList*, unsigned int);
void zF_62F717A2_u32ArrayListAppend(zT_B687BB96_U32ArrayList*, unsigned int);
zT_BAEE192E_Opt_10 zF_3F5916E1_u32ArrayListPopOrNu(zT_B687BB96_U32ArrayList*);
zT_3CB0179A_Slice_zT_05F374B1_u zF_281E4968_u32ArrayListGetSlic(zT_B687BB96_U32ArrayList*);
zT_47B162D1_U8ArrayList zF_E9FF0E66_byteArrayListInit(zT_3E40CD83_Sand*);
void zF_59A66857_byteArrayListGrow(zT_47B162D1_U8ArrayList*, unsigned int);
void zF_463FE7A4_byteArrayListAppend(zT_47B162D1_U8ArrayList*, unsigned char);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2ADA0742_byteArrayListGetSli(zT_47B162D1_U8ArrayList*);
zT_1386C3E8_AstNodeArrayList zF_6F8101FA_astNodeArrayListIni(zT_3E40CD83_Sand*, unsigned int);
void zF_BA440392_astNodeArrayListEns(zT_1386C3E8_AstNodeArrayList*, unsigned int);
void zF_FFA68CD0_astNodeArrayListApp(zT_1386C3E8_AstNodeArrayList*, zT_22A7C88B_AstNode);
zT_8FBDC967_Slice_zT_22A7C88B_A zF_BD2D926E_astNodeArrayListGet(zT_1386C3E8_AstNodeArrayList*);
zT_C4A0A7DB_U64ArrayList zF_477F0605_u64ArrayListInit(zT_3E40CD83_Sand*, unsigned int);
void zF_111B1CFD_u64ArrayListEnsureC(zT_C4A0A7DB_U64ArrayList*, unsigned int);
void zF_A553AD3B_u64ArrayListAppend(zT_C4A0A7DB_U64ArrayList*, zT_79FAE712_u64);
zT_A62C5D8D_Slice_zT_79FAE712_u zF_87EC4681_u64ArrayListGetSlic(zT_C4A0A7DB_U64ArrayList*);
zT_AB1FE668_F64ArrayList zF_5950A33A_f64ArrayListInit(zT_3E40CD83_Sand*, unsigned int);
void zF_7F2FDCD2_f64ArrayListEnsureC(zT_AB1FE668_F64ArrayList*, unsigned int);
void zF_0317E610_f64ArrayListAppend(zT_AB1FE668_F64ArrayList*, double);
zT_ACF60AF6_Slice_zT_00435AEB_f zF_96EB7CAE_f64ArrayListGetSlic(zT_AB1FE668_F64ArrayList*);
zT_CCB21906_FnProtoArrayList zF_315F8F5C_fnProtoArrayListIni(zT_3E40CD83_Sand*, unsigned int);
void zF_D57F7CF4_fnProtoArrayListEns(zT_CCB21906_FnProtoArrayList*, unsigned int);
void zF_919D3F12_fnProtoArrayListApp(zT_CCB21906_FnProtoArrayList*, zT_243D6A41_FnProto);
zT_91F8F99F_Slice_zT_243D6A41_F zF_A4813F98_fnProtoArrayListGet(zT_CCB21906_FnProtoArrayList*);
/* Storage globals (extern decls) */
extern zT_B687BB96_U32ArrayList zG_B687BB96_U32ArrayList;
extern zT_47B162D1_U8ArrayList zG_47B162D1_U8ArrayList;

#endif /* ZIG_MODULE_GROWABLE_ARRAY_6014E5AF_H */
