#ifndef ZIG_MODULE_CINCLUDE_6B99020D_H
#define ZIG_MODULE_CINCLUDE_6B99020D_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "module_registry_03A5D1FC.h"
#include "allocator_E75B7A0B.h"
#include "growable_array_6014E5AF.h"
#include "hash_02AFCD13.h"
#include "string_interner_51340A9F.h"
#include "spill_store_AC8E76BA.h"


/* Forward declarations */
unsigned char zF_62212E6D_cincludeStrEql(zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_2C4C41C7_cincludeIsPosixOnly(zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_3CB0179A_Slice_zT_05F374B1_u zF_1E2E8788_cincludeUnionAll(zT_072B53A6_ModuleRegistry*, zT_3E40CD83_Sand*, unsigned char);
void zF_780653D2___module_init_20(void);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_CINCLUDE_6B99020D_H */
