#include "async_frame_layout_08B81337.h"
#include <stdio.h>
zT_3F3BF87A_AsyncFrameLayout zG_3F3BF87A_AsyncFrameLayout;
/* fieldArrayListInit */
zT_2CF63CE1_AsyncFrameFieldArra zF_1BFB52BE_fieldArrayListInit(zT_3E40CD83_Sand* alloc, unsigned int capacity) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_C6536882_EU_532 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    zT_2CF63CE1_AsyncFrameFieldArra zT_17;
    zT_902E38E8_AsyncFrameField* zT_18;
    unsigned int zT_19;
    unsigned int cap;
    unsigned char* raw;
    cap = capacity;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    cap = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = alloc;
    zT_13 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)(cap * (unsigned int)(28)), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    zT_18 = (zT_902E38E8_AsyncFrameField*)raw;
    zT_17.items = zT_18;
    zT_19 = 0;
    zT_17.len = zT_19;
    zT_17.capacity = cap;
    zT_17.allocator = alloc;
    return zT_17;
}

/* fieldArrayListEnsureCapacity */
void zF_FB5EC98E_fieldArrayListEnsur(zT_2CF63CE1_AsyncFrameFieldArra* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_C6536882_EU_532 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_902E38E8_AsyncFrameField* zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_902E38E8_AsyncFrameField* zT_33;
    zT_902E38E8_AsyncFrameField zT_34;
    unsigned int zT_36;
    unsigned int new_cap;
    unsigned char* raw;
    zT_902E38E8_AsyncFrameField* new_items;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    if ((unsigned char)(new_cap < (unsigned int)(zT_5 * (unsigned int)(2)))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_11 = zT_9 * (unsigned int)(2);
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(new_cap * (unsigned int)(28)), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_902E38E8_AsyncFrameField*)raw;
    new_items = zT_28;
    zT_30 = 0;
    i = zT_30;
    goto z_bb_10;
    z_bb_10:
    zT_31 = self->len;
    if ((unsigned char)(i < zT_31)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->items;
    zT_34 = zT_33[i];
    new_items[i] = zT_34;
    goto z_bb_13;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13:
    zT_36 = i + (unsigned int)(1);
    i = zT_36;
    goto z_bb_10;
}

/* fieldArrayListAppend */
void zF_92FA7DBC_fieldArrayListAppen(zT_2CF63CE1_AsyncFrameFieldArra* self, zT_902E38E8_AsyncFrameField value) {
    zT_2CF63CE1_AsyncFrameFieldArra* zT_2;
    unsigned int zT_4;
    zT_902E38E8_AsyncFrameField* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_2 = self;
    zT_4 = self->len;
    zF_FB5EC98E_fieldArrayListEnsur(zT_2, (unsigned int)(zT_4 + (unsigned int)(1)));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    self->len = (unsigned int)(zT_9 + (unsigned int)(1));
    return;
}

/* allocU32With */
unsigned int* zF_82E88BBC_allocU32With(zT_3E40CD83_Sand* alloc, unsigned int n, unsigned int fill) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    zT_C6536882_EU_532 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned int* zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int count;
    unsigned char* raw;
    unsigned int* a;
    unsigned int i;
    count = n;
    if ((unsigned char)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 1;
    count = zT_6;
    goto z_bb_2;
    z_bb_2:
    zT_8 = alloc;
    zT_15 = zF_1395EB68_sandAlloc(zT_8, (unsigned int)((unsigned int)((unsigned int)count) * (unsigned int)(4)), (unsigned int)(4));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_17 = zT_15.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_17;
    zT_20 = (unsigned int*)raw;
    a = zT_20;
    zT_22 = 0;
    i = zT_22;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = (unsigned int)i;
    a[zT_24] = fill;
    goto z_bb_9;
    z_bb_8:
    return a;
    z_bb_9:
    zT_26 = i + (unsigned int)(1);
    i = zT_26;
    goto z_bb_6;
}

/* allocU8Raw */
unsigned char* zF_F15DB413_allocU8Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_C6536882_EU_532 zT_14 = {0};
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned int count;
    unsigned char* raw;
    count = n;
    if ((unsigned char)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    count = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = alloc;
    zT_14 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)((unsigned int)((unsigned int)count) * (unsigned int)(1)), (unsigned int)(1));
    zT_15 = zT_14.is_error;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_16 = zT_14.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_16;
    return (unsigned char*)((unsigned char*)raw);
}

/* allocU8With */
unsigned char* zF_9C85B07B_allocU8With(zT_3E40CD83_Sand* alloc, unsigned int n, unsigned char fill) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    zT_C6536882_EU_532 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned char* zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int count;
    unsigned char* raw;
    unsigned char* a;
    unsigned int i;
    count = n;
    if ((unsigned char)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 1;
    count = zT_6;
    goto z_bb_2;
    z_bb_2:
    zT_8 = alloc;
    zT_15 = zF_1395EB68_sandAlloc(zT_8, (unsigned int)((unsigned int)((unsigned int)count) * (unsigned int)(1)), (unsigned int)(1));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_17 = zT_15.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_17;
    zT_20 = (unsigned char*)raw;
    a = zT_20;
    zT_22 = 0;
    i = zT_22;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = (unsigned int)i;
    a[zT_24] = fill;
    goto z_bb_9;
    z_bb_8:
    return a;
    z_bb_9:
    zT_26 = i + (unsigned int)(1);
    i = zT_26;
    goto z_bb_6;
}

/* maxTempOf */
unsigned int zF_005F8966_maxTempOf(zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_2;
    unsigned int zT_4;
    zT_5D72FBF8_TempDeclArrayList zT_5;
    unsigned int zT_6;
    zT_5D72FBF8_TempDeclArrayList zT_9;
    zT_1937645B_TempDecl* zT_10;
    zT_1937645B_TempDecl zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int m;
    unsigned int i;
    zT_1937645B_TempDecl td;
    zT_2 = 0;
    m = zT_2;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = lir_fn->hoisted_temps;
    zT_6 = zT_5.len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = lir_fn->hoisted_temps;
    zT_10 = zT_9.items;
    zT_11 = zT_10[i];
    td = zT_11;
    zT_12 = td.temp_id;
    if ((unsigned char)(zT_12 >= m)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return m;
    z_bb_4:
    zT_18 = i + (unsigned int)(1);
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = td.temp_id;
    zT_16 = zT_14 + (unsigned int)(1);
    m = zT_16;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* defResultTemp */
unsigned int zF_CFED20F7_defResultTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst) {
    unsigned int zT_2;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_66;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_72;
    unsigned int zT_74;
    unsigned int zT_76;
    unsigned int zT_78;
    unsigned int zT_80;
    unsigned int zT_82;
    unsigned int zT_84;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_BBC23664_LirFunction* zT_91;
    unsigned int zT_92;
    zT_3BFB1E70_CallDirectData zT_94 = {0};
    unsigned int zT_95;
    zT_BBC23664_LirFunction* zT_98;
    unsigned int zT_99;
    zT_0624AC1B_TailCallData zT_101 = {0};
    unsigned int zT_102;
    unsigned int zT_104;
    unsigned int zT_106;
    unsigned int zT_108;
    unsigned int zT_110;
    unsigned int zT_112;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned int zT_118;
    zT_085D7AC7_anon_76574 b;
    zT_FC732E32_anon_76582 u;
    zT_D787BF51_anon_76802 ic;
    zT_CD87AF93_anon_76808 fc;
    zT_CB856DD6_anon_76814 sc;
    zT_D78580BA_anon_76818 nc;
    zT_CD833265_anon_76824 sn;
    zT_C380E410_anon_76830 bc;
    zT_C980ED82_anon_76836 uc;
    zT_94622AB3_anon_77054 pi;
    zT_CB9239C9_anon_76846 ec;
    zT_DD9B12AF_anon_76758 ic_1;
    zT_2C5D09CD_anon_77070 ic_2;
    zT_2869CF74_anon_77082 ww;
    zT_51937A86_anon_76766 fc_3;
    zT_5595BF69_anon_76774 pc;
    zT_D57AB26C_anon_76782 itf;
    zT_E37D070D_anon_76796 itp;
    zT_DF7AC22A_anon_76788 pti;
    zT_E59B1F47_anon_76750 ms;
    zT_CC1BCFDB_anon_76642 a;
    zT_C8198AF8_anon_76650 a_4;
    zT_4E120F25_anon_76688 fr;
    zT_C0197E60_anon_76658 w;
    zT_51913BEF_anon_76714 w_5;
    zT_DD89C98E_anon_76722 w_6;
    zT_4C0FCD68_anon_76694 u_7;
    zT_986230FF_anon_77050 u_8;
    zT_E78E567A_anon_76700 u_9;
    zT_E18E4D08_anon_76706 ch;
    zT_D389B9D0_anon_76728 u_10;
    zT_E58C14BD_anon_76734 u_11;
    zT_5F980DBE_anon_76740 ch_12;
    zT_CC289BCE_anon_76630 l;
    zT_4425871F_anon_76602 lf;
    zT_F0FA42CA_anon_76942 lb;
    zT_CE2ADD8B_anon_76624 li;
    zT_458F2840_anon_76852 ll;
    zT_5B8D0C4B_anon_76866 lg;
    zT_0A61FB1B_anon_76516 a_13;
    zT_7864E6DC_anon_76526 a_14;
    zT_7A672899_anon_76536 a_15;
    zT_7E76396F_anon_76592 cl;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    unsigned int slot_16;
    zT_0624AC1B_TailCallData tc;
    zT_D01E14BE_anon_76674 va;
    zT_5CF05F72_anon_76906 bgc;
    zT_5D01A893_anon_76974 o;
    zT_DF04B3D0_anon_76988 o_17;
    zT_9855650C_anon_77002 o_18;
    zT_2658832D_anon_77016 o_19;
    zT_9650E4B8_anon_77028 o_20;
    zT_965FEF42_anon_77044 o_21;
    zT_2 = inst.tag;
switch (zT_2) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 46: goto z_bb_5;
case 47: goto z_bb_6;
case 48: goto z_bb_7;
case 49: goto z_bb_8;
case 50: goto z_bb_9;
case 79: goto z_bb_10;
case 51: goto z_bb_11;
case 38: goto z_bb_12;
case 80: goto z_bb_13;
case 81: goto z_bb_14;
case 39: goto z_bb_15;
case 40: goto z_bb_16;
case 41: goto z_bb_17;
case 43: goto z_bb_18;
case 42: goto z_bb_19;
case 37: goto z_bb_20;
case 20: goto z_bb_21;
case 21: goto z_bb_22;
case 28: goto z_bb_23;
case 22: goto z_bb_24;
case 32: goto z_bb_25;
case 33: goto z_bb_26;
case 29: goto z_bb_27;
case 78: goto z_bb_28;
case 30: goto z_bb_29;
case 31: goto z_bb_30;
case 34: goto z_bb_31;
case 35: goto z_bb_32;
case 36: goto z_bb_33;
case 18: goto z_bb_34;
case 15: goto z_bb_35;
case 68: goto z_bb_36;
case 17: goto z_bb_37;
case 52: goto z_bb_38;
case 54: goto z_bb_39;
case 2: goto z_bb_40;
case 3: goto z_bb_41;
case 4: goto z_bb_42;
case 14: goto z_bb_43;
case 23: goto z_bb_44;
case 27: goto z_bb_45;
case 25: goto z_bb_46;
case 61: goto z_bb_47;
case 72: goto z_bb_48;
case 73: goto z_bb_49;
case 74: goto z_bb_50;
case 75: goto z_bb_51;
case 76: goto z_bb_52;
case 77: goto z_bb_53;
default: goto z_bb_54;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_4 = b.result;
    return zT_4;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_6 = u.result;
    return zT_6;
    z_bb_3:
    ic = inst.payload.int_const._0;
    zT_8 = ic.result;
    return zT_8;
    z_bb_4:
    fc = inst.payload.float_const._0;
    zT_10 = fc.result;
    return zT_10;
    z_bb_5:
    sc = inst.payload.string_const._0;
    zT_12 = sc.result;
    return zT_12;
    z_bb_6:
    nc = inst.payload.null_const._0;
    zT_14 = nc.result;
    return zT_14;
    z_bb_7:
    sn = inst.payload.set_optional_null._0;
    zT_16 = sn.result;
    return zT_16;
    z_bb_8:
    bc = inst.payload.bool_const._0;
    zT_18 = bc.result;
    return zT_18;
    z_bb_9:
    uc = inst.payload.undefined_const._0;
    zT_20 = uc.result;
    return zT_20;
    z_bb_10:
    pi = inst.payload.poison_init._0;
    zT_22 = pi.result;
    return zT_22;
    z_bb_11:
    ec = inst.payload.enum_const._0;
    zT_24 = ec.result;
    return zT_24;
    z_bb_12:
    ic_1 = inst.payload.int_cast._0;
    zT_26 = ic_1.result;
    return zT_26;
    z_bb_13:
    ic_2 = inst.payload.int_cast_checked._0;
    zT_28 = ic_2.result;
    return zT_28;
    z_bb_14:
    ww = inst.payload.width_wrap._0;
    zT_30 = ww.result;
    return zT_30;
    z_bb_15:
    fc_3 = inst.payload.float_cast._0;
    zT_32 = fc_3.result;
    return zT_32;
    z_bb_16:
    pc = inst.payload.ptr_cast._0;
    zT_34 = pc.result;
    return zT_34;
    z_bb_17:
    itf = inst.payload.int_to_float._0;
    zT_36 = itf.result;
    return zT_36;
    z_bb_18:
    itp = inst.payload.int_to_ptr._0;
    zT_38 = itp.result;
    return zT_38;
    z_bb_19:
    pti = inst.payload.ptr_to_int._0;
    zT_40 = pti.result;
    return zT_40;
    z_bb_20:
    ms = inst.payload.make_slice._0;
    zT_42 = ms.result;
    return zT_42;
    z_bb_21:
    a = inst.payload.addr_of._0;
    zT_44 = a.result;
    return zT_44;
    z_bb_22:
    a_4 = inst.payload.addr_of_field._0;
    zT_46 = a_4.result;
    return zT_46;
    z_bb_23:
    fr = inst.payload.func_ref._0;
    zT_48 = fr.result;
    return zT_48;
    z_bb_24:
    w = inst.payload.wrap_optional._0;
    zT_50 = w.result;
    return zT_50;
    z_bb_25:
    w_5 = inst.payload.wrap_error_ok._0;
    zT_52 = w_5.result;
    return zT_52;
    z_bb_26:
    w_6 = inst.payload.wrap_error_err._0;
    zT_54 = w_6.result;
    return zT_54;
    z_bb_27:
    u_7 = inst.payload.unwrap_optional._0;
    zT_56 = u_7.result;
    return zT_56;
    z_bb_28:
    u_8 = inst.payload.unwrap_optional_checked._0;
    zT_58 = u_8.result;
    return zT_58;
    z_bb_29:
    u_9 = inst.payload.unwrap_optional_abi._0;
    zT_60 = u_9.result;
    return zT_60;
    z_bb_30:
    ch = inst.payload.check_optional._0;
    zT_62 = ch.result;
    return zT_62;
    z_bb_31:
    u_10 = inst.payload.unwrap_error_payload._0;
    zT_64 = u_10.result;
    return zT_64;
    z_bb_32:
    u_11 = inst.payload.unwrap_error_code._0;
    zT_66 = u_11.result;
    return zT_66;
    z_bb_33:
    ch_12 = inst.payload.check_error._0;
    zT_68 = ch_12.result;
    return zT_68;
    z_bb_34:
    l = inst.payload.load._0;
    zT_70 = l.result;
    return zT_70;
    z_bb_35:
    lf = inst.payload.load_field._0;
    zT_72 = lf.result;
    return zT_72;
    z_bb_36:
    lb = inst.payload.load_bitfield._0;
    zT_74 = lb.result;
    return zT_74;
    z_bb_37:
    li = inst.payload.load_index._0;
    zT_76 = li.result;
    return zT_76;
    z_bb_38:
    ll = inst.payload.load_local._0;
    zT_78 = ll.result;
    return zT_78;
    z_bb_39:
    lg = inst.payload.load_global._0;
    zT_80 = lg.result;
    return zT_80;
    z_bb_40:
    a_13 = inst.payload.assign._0;
    zT_82 = a_13.dst;
    return zT_82;
    z_bb_41:
    a_14 = inst.payload.assign_field._0;
    zT_84 = a_14.base;
    return zT_84;
    z_bb_42:
    a_15 = inst.payload.assign_index._0;
    zT_86 = a_15.base;
    return zT_86;
    z_bb_43:
    cl = inst.payload.call._0;
    zT_88 = cl.result;
    return zT_88;
    z_bb_44:
    slot = inst.payload.jump._0;
    zT_91 = c->lir_fn;
    zT_92 = slot;
    zT_94 = zF_75DE985C_lirSideGetCallDirec(zT_91, zT_92);
    cd = zT_94;
    zT_95 = cd.result;
    return zT_95;
    z_bb_45:
    slot_16 = inst.payload.jump._0;
    zT_98 = c->lir_fn;
    zT_99 = slot_16;
    zT_101 = zF_1AB3807F_lirSideGetTailCall(zT_98, zT_99);
    tc = zT_101;
    zT_102 = tc.result;
    return zT_102;
    z_bb_46:
    va = inst.payload.va_arg._0;
    zT_104 = va.result;
    return zT_104;
    z_bb_47:
    bgc = inst.payload.builtin_get_char._0;
    zT_106 = bgc.result;
    return zT_106;
    z_bb_48:
    o = inst.payload.add_with_overflow._0;
    zT_108 = o.result;
    return zT_108;
    z_bb_49:
    o_17 = inst.payload.sub_with_overflow._0;
    zT_110 = o_17.result;
    return zT_110;
    z_bb_50:
    o_18 = inst.payload.mul_with_overflow._0;
    zT_112 = o_18.result;
    return zT_112;
    z_bb_51:
    o_19 = inst.payload.shl_with_overflow._0;
    zT_114 = o_19.result;
    return zT_114;
    z_bb_52:
    o_20 = inst.payload.neg_with_overflow._0;
    zT_116 = o_20.result;
    return zT_116;
    z_bb_53:
    o_21 = inst.payload.overflow_flag._0;
    zT_118 = o_21.result;
    return zT_118;
    z_bb_54:
    return (unsigned int)(4294967295u);
    return 0;
}

/* localStorage */
unsigned int zF_CD424A09_localStorage(zT_6D148508_Scan* c, unsigned int name_id) {
    zT_21D3708C_U32ToU32Map* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    unsigned int t;
    if ((unsigned char)(name_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_5 = c->locals;
    zT_6 = name_id;
    zT_8 = zF_F3EE5998_u32ToU32MapGet(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    t = zT_8.value;
    return t;
    z_bb_4:
    return (unsigned int)(4294967295u);
}

/* instDefsTemp */
unsigned char zF_1FF90D33_instDefsTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, unsigned int v) {
    zT_6D148508_Scan* zT_3;
    zT_6BA597BC_LirInst zT_4;
    unsigned int zT_5 = 0;
    unsigned int zT_8;
    zT_6D148508_Scan* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    zT_4F8F37FE_anon_76858 sl;
    zT_3 = c;
    zT_4 = inst;
    zT_5 = zF_CFED20F7_defResultTemp(zT_3, zT_4);
    if ((unsigned char)(zT_5 == v)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_8 = inst.tag;
switch (zT_8) {
case 53: goto z_bb_3;
case 55: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_3:
    sl = inst.payload.store_local._0;
    zT_10 = c;
    zT_11 = sl.name_id;
    zT_13 = zF_CD424A09_localStorage(zT_10, zT_11);
    if ((unsigned char)(zT_13 == v)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_7;
    z_bb_5:
    goto z_bb_7;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    return (unsigned char)(1);
    z_bb_9:
    goto z_bb_7;
}

/* instReadsTemp */
unsigned char zF_E4C3429C_instReadsTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, unsigned int v) {
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned char zT_11;
    unsigned int zT_12;
    unsigned int zT_16;
    unsigned char zT_18;
    unsigned int zT_19;
    unsigned char zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_30;
    unsigned int zT_37;
    unsigned char zT_39;
    unsigned int zT_40;
    unsigned int zT_44;
    unsigned int zT_48;
    unsigned char zT_50;
    unsigned int zT_51;
    unsigned int zT_55;
    unsigned char zT_57;
    unsigned int zT_58;
    unsigned int zT_62;
    unsigned char zT_64;
    unsigned int zT_65;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned int zT_72;
    unsigned int zT_76;
    unsigned int zT_80;
    unsigned char zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    unsigned int zT_90;
    unsigned char zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_99;
    unsigned int zT_103;
    unsigned int zT_107;
    unsigned char zT_109;
    unsigned int zT_110;
    unsigned int zT_114;
    unsigned char zT_116;
    unsigned int zT_117;
    unsigned int zT_121;
    unsigned char zT_123;
    unsigned int zT_124;
    unsigned int zT_128;
    unsigned int zT_132;
    unsigned char zT_134;
    unsigned int zT_135;
    unsigned int zT_139;
    unsigned int zT_143;
    unsigned int zT_147;
    zT_BBC23664_LirFunction* zT_152;
    unsigned int zT_153;
    zT_3BFB1E70_CallDirectData zT_155 = {0};
    unsigned int zT_156;
    unsigned char zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_165;
    unsigned char zT_167;
    unsigned int zT_168;
    unsigned int zT_172;
    unsigned int zT_176;
    zT_BBC23664_LirFunction* zT_181;
    unsigned int zT_182;
    zT_0624AC1B_TailCallData zT_184 = {0};
    unsigned char zT_185;
    unsigned char zT_188;
    unsigned int zT_189;
    unsigned int zT_192;
    unsigned char zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned int zT_201;
    unsigned int zT_205;
    unsigned int zT_209;
    unsigned int zT_213;
    unsigned int zT_217;
    unsigned int zT_221;
    unsigned int zT_225;
    unsigned int zT_229;
    unsigned int zT_233;
    unsigned int zT_237;
    unsigned char zT_239;
    unsigned int zT_240;
    unsigned int zT_244;
    unsigned int zT_248;
    unsigned int zT_252;
    unsigned int zT_256;
    unsigned int zT_260;
    unsigned int zT_264;
    unsigned int zT_268;
    unsigned int zT_272;
    zT_6D148508_Scan* zT_276;
    unsigned int zT_277;
    unsigned int zT_279 = 0;
    unsigned int zT_283;
    unsigned int zT_287;
    unsigned int zT_291;
    unsigned int zT_295;
    unsigned int zT_299;
    unsigned char zT_301;
    unsigned int zT_302;
    unsigned int zT_306;
    unsigned char zT_308;
    unsigned int zT_309;
    unsigned int zT_313;
    unsigned int zT_317;
    unsigned int zT_321;
    unsigned char zT_323;
    unsigned int zT_324;
    unsigned int zT_328;
    unsigned char zT_330;
    unsigned int zT_331;
    unsigned int zT_335;
    zT_0A61FB1B_anon_76516 a;
    zT_7864E6DC_anon_76526 a_1;
    zT_7A672899_anon_76536 a_2;
    zT_7855DC52_anon_76546 b;
    zT_7A581E0F_anon_76556 s;
    unsigned int r;
    zT_085D7AC7_anon_76574 b_3;
    zT_FC732E32_anon_76582 u;
    zT_5D01A893_anon_76974 o;
    zT_DF04B3D0_anon_76988 o_4;
    zT_9855650C_anon_77002 o_5;
    zT_2658832D_anon_77016 o_6;
    zT_9650E4B8_anon_77028 o_7;
    zT_965FEF42_anon_77044 o_8;
    zT_7E76396F_anon_76592 cl;
    zT_4425871F_anon_76602 lf;
    zT_F0FA42CA_anon_76942 lb;
    zT_42234562_anon_76612 sf;
    zT_72FD4E07_anon_76952 sb;
    zT_CE2ADD8B_anon_76624 li;
    zT_CC289BCE_anon_76630 l;
    zT_CE289EF4_anon_76636 st;
    zT_CC1BCFDB_anon_76642 a_9;
    zT_C8198AF8_anon_76650 a_10;
    zT_C0197E60_anon_76658 w;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_402103A5_anon_76666 vs;
    zT_D01E14BE_anon_76674 va;
    zT_CC1E0E72_anon_76678 ve;
    unsigned int slot_11;
    zT_0624AC1B_TailCallData tc;
    zT_4C0FCD68_anon_76694 u_12;
    zT_986230FF_anon_77050 u_13;
    zT_E78E567A_anon_76700 u_14;
    zT_E18E4D08_anon_76706 ch;
    zT_51913BEF_anon_76714 w_15;
    zT_DD89C98E_anon_76722 w_16;
    zT_D389B9D0_anon_76728 u_17;
    zT_E58C14BD_anon_76734 u_18;
    zT_5F980DBE_anon_76740 ch_19;
    zT_E59B1F47_anon_76750 ms;
    zT_DD9B12AF_anon_76758 ic;
    zT_2C5D09CD_anon_77070 ic_20;
    zT_2869CF74_anon_77082 ww;
    zT_51937A86_anon_76766 fc;
    zT_5595BF69_anon_76774 pc;
    zT_D57AB26C_anon_76782 itf;
    zT_DF7AC22A_anon_76788 pti;
    zT_E37D070D_anon_76796 itp;
    zT_458F2840_anon_76852 ll;
    zT_4F8F37FE_anon_76858 sl;
    zT_578AC768_anon_76874 sg;
    zT_4B9BFDA5_anon_76886 pv;
    zT_DF99150A_anon_76890 bpc;
    zT_D9990B98_anon_76896 b_21;
    zT_58F05926_anon_76902 b_22;
    zT_DCF36789_anon_76910 be;
    zT_E0F36DD5_anon_76914 bsm;
    zT_E0F5AC6C_anon_76922 bcg;
    zT_EAF5BC2A_anon_76928 bcc;
    zT_5AFF66D6_anon_76960 ct;
    zT_3 = inst.tag;
switch (zT_3) {
case 2: goto z_bb_1;
case 3: goto z_bb_2;
case 4: goto z_bb_3;
case 6: goto z_bb_4;
case 7: goto z_bb_5;
case 9: goto z_bb_6;
case 12: goto z_bb_7;
case 13: goto z_bb_8;
case 72: goto z_bb_9;
case 73: goto z_bb_10;
case 74: goto z_bb_11;
case 75: goto z_bb_12;
case 76: goto z_bb_13;
case 77: goto z_bb_14;
case 14: goto z_bb_15;
case 15: goto z_bb_16;
case 68: goto z_bb_17;
case 16: goto z_bb_18;
case 69: goto z_bb_19;
case 17: goto z_bb_20;
case 18: goto z_bb_21;
case 19: goto z_bb_22;
case 20: goto z_bb_23;
case 21: goto z_bb_24;
case 22: goto z_bb_25;
case 23: goto z_bb_26;
case 24: goto z_bb_27;
case 25: goto z_bb_28;
case 26: goto z_bb_29;
case 27: goto z_bb_30;
case 29: goto z_bb_31;
case 78: goto z_bb_32;
case 30: goto z_bb_33;
case 31: goto z_bb_34;
case 32: goto z_bb_35;
case 33: goto z_bb_36;
case 34: goto z_bb_37;
case 35: goto z_bb_38;
case 36: goto z_bb_39;
case 37: goto z_bb_40;
case 38: goto z_bb_41;
case 80: goto z_bb_42;
case 81: goto z_bb_43;
case 39: goto z_bb_44;
case 40: goto z_bb_45;
case 41: goto z_bb_46;
case 42: goto z_bb_47;
case 43: goto z_bb_48;
case 52: goto z_bb_49;
case 53: goto z_bb_50;
case 55: goto z_bb_51;
case 57: goto z_bb_52;
case 58: goto z_bb_53;
case 59: goto z_bb_54;
case 60: goto z_bb_55;
case 62: goto z_bb_56;
case 63: goto z_bb_57;
case 65: goto z_bb_58;
case 66: goto z_bb_59;
case 71: goto z_bb_60;
default: goto z_bb_61;
}
    z_bb_1:
    a = inst.payload.assign._0;
    zT_5 = a.src;
    if ((unsigned char)(zT_5 == v)) goto z_bb_64; else goto z_bb_65;
    z_bb_2:
    a_1 = inst.payload.assign_field._0;
    zT_9 = a_1.base;
    if ((unsigned char)(zT_9 == v)) goto z_bb_67; else goto z_bb_66;
    z_bb_3:
    a_2 = inst.payload.assign_index._0;
    zT_16 = a_2.base;
    if ((unsigned char)(zT_16 == v)) goto z_bb_72; else goto z_bb_71;
    z_bb_4:
    b = inst.payload.branch._0;
    zT_26 = b.cond;
    if ((unsigned char)(zT_26 == v)) goto z_bb_79; else goto z_bb_80;
    z_bb_5:
    s = inst.payload.switch_br._0;
    zT_30 = s.cond;
    if ((unsigned char)(zT_30 == v)) goto z_bb_81; else goto z_bb_82;
    z_bb_6:
    r = inst.payload.jump._0;
    if ((unsigned char)(r == v)) goto z_bb_83; else goto z_bb_84;
    z_bb_7:
    b_3 = inst.payload.binary._0;
    zT_37 = b_3.lhs;
    if ((unsigned char)(zT_37 == v)) goto z_bb_86; else goto z_bb_85;
    z_bb_8:
    u = inst.payload.unary._0;
    zT_44 = u.operand;
    if ((unsigned char)(zT_44 == v)) goto z_bb_90; else goto z_bb_91;
    z_bb_9:
    o = inst.payload.add_with_overflow._0;
    zT_48 = o.lhs;
    if ((unsigned char)(zT_48 == v)) goto z_bb_93; else goto z_bb_92;
    z_bb_10:
    o_4 = inst.payload.sub_with_overflow._0;
    zT_55 = o_4.lhs;
    if ((unsigned char)(zT_55 == v)) goto z_bb_98; else goto z_bb_97;
    z_bb_11:
    o_5 = inst.payload.mul_with_overflow._0;
    zT_62 = o_5.lhs;
    if ((unsigned char)(zT_62 == v)) goto z_bb_103; else goto z_bb_102;
    z_bb_12:
    o_6 = inst.payload.shl_with_overflow._0;
    zT_69 = o_6.lhs;
    if ((unsigned char)(zT_69 == v)) goto z_bb_108; else goto z_bb_107;
    z_bb_13:
    o_7 = inst.payload.neg_with_overflow._0;
    zT_76 = o_7.value;
    if ((unsigned char)(zT_76 == v)) goto z_bb_112; else goto z_bb_113;
    z_bb_14:
    o_8 = inst.payload.overflow_flag._0;
    zT_80 = o_8.lhs;
    if ((unsigned char)(zT_80 == v)) goto z_bb_115; else goto z_bb_114;
    z_bb_15:
    cl = inst.payload.call._0;
    zT_87 = cl.callee;
    if ((unsigned char)(zT_87 == v)) goto z_bb_119; else goto z_bb_120;
    z_bb_16:
    lf = inst.payload.load_field._0;
    zT_99 = lf.base;
    if ((unsigned char)(zT_99 == v)) goto z_bb_126; else goto z_bb_127;
    z_bb_17:
    lb = inst.payload.load_bitfield._0;
    zT_103 = lb.base;
    if ((unsigned char)(zT_103 == v)) goto z_bb_128; else goto z_bb_129;
    z_bb_18:
    sf = inst.payload.store_field._0;
    zT_107 = sf.base;
    if ((unsigned char)(zT_107 == v)) goto z_bb_131; else goto z_bb_130;
    z_bb_19:
    sb = inst.payload.store_bitfield._0;
    zT_114 = sb.base;
    if ((unsigned char)(zT_114 == v)) goto z_bb_136; else goto z_bb_135;
    z_bb_20:
    li = inst.payload.load_index._0;
    zT_121 = li.base;
    if ((unsigned char)(zT_121 == v)) goto z_bb_141; else goto z_bb_140;
    z_bb_21:
    l = inst.payload.load._0;
    zT_128 = l.ptr;
    if ((unsigned char)(zT_128 == v)) goto z_bb_145; else goto z_bb_146;
    z_bb_22:
    st = inst.payload.store._0;
    zT_132 = st.ptr;
    if ((unsigned char)(zT_132 == v)) goto z_bb_148; else goto z_bb_147;
    z_bb_23:
    a_9 = inst.payload.addr_of._0;
    zT_139 = a_9.operand;
    if ((unsigned char)(zT_139 == v)) goto z_bb_152; else goto z_bb_153;
    z_bb_24:
    a_10 = inst.payload.addr_of_field._0;
    zT_143 = a_10.base;
    if ((unsigned char)(zT_143 == v)) goto z_bb_154; else goto z_bb_155;
    z_bb_25:
    w = inst.payload.wrap_optional._0;
    zT_147 = w.value;
    if ((unsigned char)(zT_147 == v)) goto z_bb_156; else goto z_bb_157;
    z_bb_26:
    slot = inst.payload.jump._0;
    zT_152 = c->lir_fn;
    zT_153 = slot;
    zT_155 = zF_75DE985C_lirSideGetCallDirec(zT_152, zT_153);
    cd = zT_155;
    zT_156 = cd.args_start;
    if ((unsigned char)(v >= zT_156)) goto z_bb_158; else goto z_bb_159;
    z_bb_27:
    vs = inst.payload.va_start._0;
    zT_165 = vs.va_list_temp;
    if ((unsigned char)(zT_165 == v)) goto z_bb_164; else goto z_bb_163;
    z_bb_28:
    va = inst.payload.va_arg._0;
    zT_172 = va.va_list_temp;
    if ((unsigned char)(zT_172 == v)) goto z_bb_168; else goto z_bb_169;
    z_bb_29:
    ve = inst.payload.va_end._0;
    zT_176 = ve.va_list_temp;
    if ((unsigned char)(zT_176 == v)) goto z_bb_170; else goto z_bb_171;
    z_bb_30:
    slot_11 = inst.payload.jump._0;
    zT_181 = c->lir_fn;
    zT_182 = slot_11;
    zT_184 = zF_1AB3807F_lirSideGetTailCall(zT_181, zT_182);
    tc = zT_184;
    zT_185 = tc.is_indirect;
    if ((unsigned char)(zT_185 != (unsigned char)(0))) goto z_bb_172; else goto z_bb_173;
    z_bb_31:
    u_12 = inst.payload.unwrap_optional._0;
    zT_201 = u_12.value;
    if ((unsigned char)(zT_201 == v)) goto z_bb_182; else goto z_bb_183;
    z_bb_32:
    u_13 = inst.payload.unwrap_optional_checked._0;
    zT_205 = u_13.value;
    if ((unsigned char)(zT_205 == v)) goto z_bb_184; else goto z_bb_185;
    z_bb_33:
    u_14 = inst.payload.unwrap_optional_abi._0;
    zT_209 = u_14.value;
    if ((unsigned char)(zT_209 == v)) goto z_bb_186; else goto z_bb_187;
    z_bb_34:
    ch = inst.payload.check_optional._0;
    zT_213 = ch.value;
    if ((unsigned char)(zT_213 == v)) goto z_bb_188; else goto z_bb_189;
    z_bb_35:
    w_15 = inst.payload.wrap_error_ok._0;
    zT_217 = w_15.value;
    if ((unsigned char)(zT_217 == v)) goto z_bb_190; else goto z_bb_191;
    z_bb_36:
    w_16 = inst.payload.wrap_error_err._0;
    zT_221 = w_16.value;
    if ((unsigned char)(zT_221 == v)) goto z_bb_192; else goto z_bb_193;
    z_bb_37:
    u_17 = inst.payload.unwrap_error_payload._0;
    zT_225 = u_17.value;
    if ((unsigned char)(zT_225 == v)) goto z_bb_194; else goto z_bb_195;
    z_bb_38:
    u_18 = inst.payload.unwrap_error_code._0;
    zT_229 = u_18.value;
    if ((unsigned char)(zT_229 == v)) goto z_bb_196; else goto z_bb_197;
    z_bb_39:
    ch_19 = inst.payload.check_error._0;
    zT_233 = ch_19.value;
    if ((unsigned char)(zT_233 == v)) goto z_bb_198; else goto z_bb_199;
    z_bb_40:
    ms = inst.payload.make_slice._0;
    zT_237 = ms.ptr;
    if ((unsigned char)(zT_237 == v)) goto z_bb_201; else goto z_bb_200;
    z_bb_41:
    ic = inst.payload.int_cast._0;
    zT_244 = ic.value;
    if ((unsigned char)(zT_244 == v)) goto z_bb_205; else goto z_bb_206;
    z_bb_42:
    ic_20 = inst.payload.int_cast_checked._0;
    zT_248 = ic_20.value;
    if ((unsigned char)(zT_248 == v)) goto z_bb_207; else goto z_bb_208;
    z_bb_43:
    ww = inst.payload.width_wrap._0;
    zT_252 = ww.value;
    if ((unsigned char)(zT_252 == v)) goto z_bb_209; else goto z_bb_210;
    z_bb_44:
    fc = inst.payload.float_cast._0;
    zT_256 = fc.value;
    if ((unsigned char)(zT_256 == v)) goto z_bb_211; else goto z_bb_212;
    z_bb_45:
    pc = inst.payload.ptr_cast._0;
    zT_260 = pc.value;
    if ((unsigned char)(zT_260 == v)) goto z_bb_213; else goto z_bb_214;
    z_bb_46:
    itf = inst.payload.int_to_float._0;
    zT_264 = itf.value;
    if ((unsigned char)(zT_264 == v)) goto z_bb_215; else goto z_bb_216;
    z_bb_47:
    pti = inst.payload.ptr_to_int._0;
    zT_268 = pti.value;
    if ((unsigned char)(zT_268 == v)) goto z_bb_217; else goto z_bb_218;
    z_bb_48:
    itp = inst.payload.int_to_ptr._0;
    zT_272 = itp.value;
    if ((unsigned char)(zT_272 == v)) goto z_bb_219; else goto z_bb_220;
    z_bb_49:
    ll = inst.payload.load_local._0;
    zT_276 = c;
    zT_277 = ll.name_id;
    zT_279 = zF_CD424A09_localStorage(zT_276, zT_277);
    if ((unsigned char)(zT_279 == v)) goto z_bb_221; else goto z_bb_222;
    z_bb_50:
    sl = inst.payload.store_local._0;
    zT_283 = sl.value;
    if ((unsigned char)(zT_283 == v)) goto z_bb_223; else goto z_bb_224;
    z_bb_51:
    sg = inst.payload.store_global._0;
    zT_287 = sg.value;
    if ((unsigned char)(zT_287 == v)) goto z_bb_225; else goto z_bb_226;
    z_bb_52:
    pv = inst.payload.print_val._0;
    zT_291 = pv.value;
    if ((unsigned char)(zT_291 == v)) goto z_bb_227; else goto z_bb_228;
    z_bb_53:
    bpc = inst.payload.builtin_put_char._0;
    zT_295 = bpc.value;
    if ((unsigned char)(zT_295 == v)) goto z_bb_229; else goto z_bb_230;
    z_bb_54:
    b_21 = inst.payload.builtin_stdout_write._0;
    zT_299 = b_21.ptr;
    if ((unsigned char)(zT_299 == v)) goto z_bb_232; else goto z_bb_231;
    z_bb_55:
    b_22 = inst.payload.builtin_stderr_write._0;
    zT_306 = b_22.ptr;
    if ((unsigned char)(zT_306 == v)) goto z_bb_237; else goto z_bb_236;
    z_bb_56:
    be = inst.payload.builtin_exit._0;
    zT_313 = be.value;
    if ((unsigned char)(zT_313 == v)) goto z_bb_241; else goto z_bb_242;
    z_bb_57:
    bsm = inst.payload.builtin_sleep_ms._0;
    zT_317 = bsm.value;
    if ((unsigned char)(zT_317 == v)) goto z_bb_243; else goto z_bb_244;
    z_bb_58:
    bcg = inst.payload.builtin_console_gotoxy._0;
    zT_321 = bcg.x;
    if ((unsigned char)(zT_321 == v)) goto z_bb_246; else goto z_bb_245;
    z_bb_59:
    bcc = inst.payload.builtin_console_set_color._0;
    zT_328 = bcc.fg;
    if ((unsigned char)(zT_328 == v)) goto z_bb_251; else goto z_bb_250;
    z_bb_60:
    ct = inst.payload.check_trap._0;
    zT_335 = ct.cond;
    if ((unsigned char)(zT_335 == v)) goto z_bb_255; else goto z_bb_256;
    z_bb_61:
    goto z_bb_63;
    z_bb_63:
    return (unsigned char)(0);
    z_bb_64:
    return (unsigned char)(1);
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    zT_12 = a_1.src;
    zT_11 = zT_12 == v;
    goto z_bb_68;
    z_bb_67:
    zT_11 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_11) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    return (unsigned char)(1);
    z_bb_70:
    goto z_bb_63;
    z_bb_71:
    zT_19 = a_2.index;
    zT_18 = zT_19 == v;
    goto z_bb_73;
    z_bb_72:
    zT_18 = 1;
    goto z_bb_73;
    z_bb_73:
    if (zT_18) goto z_bb_75; else goto z_bb_74;
    z_bb_74:
    zT_22 = a_2.src;
    zT_21 = zT_22 == v;
    goto z_bb_76;
    z_bb_75:
    zT_21 = 1;
    goto z_bb_76;
    z_bb_76:
    if (zT_21) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    return (unsigned char)(1);
    z_bb_78:
    goto z_bb_63;
    z_bb_79:
    return (unsigned char)(1);
    z_bb_80:
    goto z_bb_63;
    z_bb_81:
    return (unsigned char)(1);
    z_bb_82:
    goto z_bb_63;
    z_bb_83:
    return (unsigned char)(1);
    z_bb_84:
    goto z_bb_63;
    z_bb_85:
    zT_40 = b_3.rhs;
    zT_39 = zT_40 == v;
    goto z_bb_87;
    z_bb_86:
    zT_39 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_39) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    return (unsigned char)(1);
    z_bb_89:
    goto z_bb_63;
    z_bb_90:
    return (unsigned char)(1);
    z_bb_91:
    goto z_bb_63;
    z_bb_92:
    zT_51 = o.rhs;
    zT_50 = zT_51 == v;
    goto z_bb_94;
    z_bb_93:
    zT_50 = 1;
    goto z_bb_94;
    z_bb_94:
    if (zT_50) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    return (unsigned char)(1);
    z_bb_96:
    goto z_bb_63;
    z_bb_97:
    zT_58 = o_4.rhs;
    zT_57 = zT_58 == v;
    goto z_bb_99;
    z_bb_98:
    zT_57 = 1;
    goto z_bb_99;
    z_bb_99:
    if (zT_57) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    return (unsigned char)(1);
    z_bb_101:
    goto z_bb_63;
    z_bb_102:
    zT_65 = o_5.rhs;
    zT_64 = zT_65 == v;
    goto z_bb_104;
    z_bb_103:
    zT_64 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_64) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    return (unsigned char)(1);
    z_bb_106:
    goto z_bb_63;
    z_bb_107:
    zT_72 = o_6.rhs;
    zT_71 = zT_72 == v;
    goto z_bb_109;
    z_bb_108:
    zT_71 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_71) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    return (unsigned char)(1);
    z_bb_111:
    goto z_bb_63;
    z_bb_112:
    return (unsigned char)(1);
    z_bb_113:
    goto z_bb_63;
    z_bb_114:
    zT_83 = o_8.rhs;
    zT_82 = zT_83 == v;
    goto z_bb_116;
    z_bb_115:
    zT_82 = 1;
    goto z_bb_116;
    z_bb_116:
    if (zT_82) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    return (unsigned char)(1);
    z_bb_118:
    goto z_bb_63;
    z_bb_119:
    return (unsigned char)(1);
    z_bb_120:
    zT_90 = cl.args_start;
    if ((unsigned char)(v >= zT_90)) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_93 = cl.args_start;
    zT_94 = cl.args_count;
    zT_92 = v < (unsigned int)(zT_93 + zT_94);
    goto z_bb_123;
    z_bb_122:
    zT_92 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_92) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    return (unsigned char)(1);
    z_bb_125:
    goto z_bb_63;
    z_bb_126:
    return (unsigned char)(1);
    z_bb_127:
    goto z_bb_63;
    z_bb_128:
    return (unsigned char)(1);
    z_bb_129:
    goto z_bb_63;
    z_bb_130:
    zT_110 = sf.value;
    zT_109 = zT_110 == v;
    goto z_bb_132;
    z_bb_131:
    zT_109 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_109) goto z_bb_133; else goto z_bb_134;
    z_bb_133:
    return (unsigned char)(1);
    z_bb_134:
    goto z_bb_63;
    z_bb_135:
    zT_117 = sb.value;
    zT_116 = zT_117 == v;
    goto z_bb_137;
    z_bb_136:
    zT_116 = 1;
    goto z_bb_137;
    z_bb_137:
    if (zT_116) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    return (unsigned char)(1);
    z_bb_139:
    goto z_bb_63;
    z_bb_140:
    zT_124 = li.index;
    zT_123 = zT_124 == v;
    goto z_bb_142;
    z_bb_141:
    zT_123 = 1;
    goto z_bb_142;
    z_bb_142:
    if (zT_123) goto z_bb_143; else goto z_bb_144;
    z_bb_143:
    return (unsigned char)(1);
    z_bb_144:
    goto z_bb_63;
    z_bb_145:
    return (unsigned char)(1);
    z_bb_146:
    goto z_bb_63;
    z_bb_147:
    zT_135 = st.value;
    zT_134 = zT_135 == v;
    goto z_bb_149;
    z_bb_148:
    zT_134 = 1;
    goto z_bb_149;
    z_bb_149:
    if (zT_134) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    return (unsigned char)(1);
    z_bb_151:
    goto z_bb_63;
    z_bb_152:
    return (unsigned char)(1);
    z_bb_153:
    goto z_bb_63;
    z_bb_154:
    return (unsigned char)(1);
    z_bb_155:
    goto z_bb_63;
    z_bb_156:
    return (unsigned char)(1);
    z_bb_157:
    goto z_bb_63;
    z_bb_158:
    zT_159 = cd.args_start;
    zT_160 = cd.args_count;
    zT_158 = v < (unsigned int)(zT_159 + zT_160);
    goto z_bb_160;
    z_bb_159:
    zT_158 = 0;
    goto z_bb_160;
    z_bb_160:
    if (zT_158) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    return (unsigned char)(1);
    z_bb_162:
    goto z_bb_63;
    z_bb_163:
    zT_168 = vs.last_param_temp;
    zT_167 = zT_168 == v;
    goto z_bb_165;
    z_bb_164:
    zT_167 = 1;
    goto z_bb_165;
    z_bb_165:
    if (zT_167) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    return (unsigned char)(1);
    z_bb_167:
    goto z_bb_63;
    z_bb_168:
    return (unsigned char)(1);
    z_bb_169:
    goto z_bb_63;
    z_bb_170:
    return (unsigned char)(1);
    z_bb_171:
    goto z_bb_63;
    z_bb_172:
    zT_189 = tc.callee;
    zT_188 = zT_189 == v;
    goto z_bb_174;
    z_bb_173:
    zT_188 = 0;
    goto z_bb_174;
    z_bb_174:
    if (zT_188) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    return (unsigned char)(1);
    z_bb_176:
    zT_192 = tc.args_start;
    if ((unsigned char)(v >= zT_192)) goto z_bb_177; else goto z_bb_178;
    z_bb_177:
    zT_195 = tc.args_start;
    zT_196 = tc.args_count;
    zT_194 = v < (unsigned int)(zT_195 + zT_196);
    goto z_bb_179;
    z_bb_178:
    zT_194 = 0;
    goto z_bb_179;
    z_bb_179:
    if (zT_194) goto z_bb_180; else goto z_bb_181;
    z_bb_180:
    return (unsigned char)(1);
    z_bb_181:
    goto z_bb_63;
    z_bb_182:
    return (unsigned char)(1);
    z_bb_183:
    goto z_bb_63;
    z_bb_184:
    return (unsigned char)(1);
    z_bb_185:
    goto z_bb_63;
    z_bb_186:
    return (unsigned char)(1);
    z_bb_187:
    goto z_bb_63;
    z_bb_188:
    return (unsigned char)(1);
    z_bb_189:
    goto z_bb_63;
    z_bb_190:
    return (unsigned char)(1);
    z_bb_191:
    goto z_bb_63;
    z_bb_192:
    return (unsigned char)(1);
    z_bb_193:
    goto z_bb_63;
    z_bb_194:
    return (unsigned char)(1);
    z_bb_195:
    goto z_bb_63;
    z_bb_196:
    return (unsigned char)(1);
    z_bb_197:
    goto z_bb_63;
    z_bb_198:
    return (unsigned char)(1);
    z_bb_199:
    goto z_bb_63;
    z_bb_200:
    zT_240 = ms.len;
    zT_239 = zT_240 == v;
    goto z_bb_202;
    z_bb_201:
    zT_239 = 1;
    goto z_bb_202;
    z_bb_202:
    if (zT_239) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    return (unsigned char)(1);
    z_bb_204:
    goto z_bb_63;
    z_bb_205:
    return (unsigned char)(1);
    z_bb_206:
    goto z_bb_63;
    z_bb_207:
    return (unsigned char)(1);
    z_bb_208:
    goto z_bb_63;
    z_bb_209:
    return (unsigned char)(1);
    z_bb_210:
    goto z_bb_63;
    z_bb_211:
    return (unsigned char)(1);
    z_bb_212:
    goto z_bb_63;
    z_bb_213:
    return (unsigned char)(1);
    z_bb_214:
    goto z_bb_63;
    z_bb_215:
    return (unsigned char)(1);
    z_bb_216:
    goto z_bb_63;
    z_bb_217:
    return (unsigned char)(1);
    z_bb_218:
    goto z_bb_63;
    z_bb_219:
    return (unsigned char)(1);
    z_bb_220:
    goto z_bb_63;
    z_bb_221:
    return (unsigned char)(1);
    z_bb_222:
    goto z_bb_63;
    z_bb_223:
    return (unsigned char)(1);
    z_bb_224:
    goto z_bb_63;
    z_bb_225:
    return (unsigned char)(1);
    z_bb_226:
    goto z_bb_63;
    z_bb_227:
    return (unsigned char)(1);
    z_bb_228:
    goto z_bb_63;
    z_bb_229:
    return (unsigned char)(1);
    z_bb_230:
    goto z_bb_63;
    z_bb_231:
    zT_302 = b_21.len;
    zT_301 = zT_302 == v;
    goto z_bb_233;
    z_bb_232:
    zT_301 = 1;
    goto z_bb_233;
    z_bb_233:
    if (zT_301) goto z_bb_234; else goto z_bb_235;
    z_bb_234:
    return (unsigned char)(1);
    z_bb_235:
    goto z_bb_63;
    z_bb_236:
    zT_309 = b_22.len;
    zT_308 = zT_309 == v;
    goto z_bb_238;
    z_bb_237:
    zT_308 = 1;
    goto z_bb_238;
    z_bb_238:
    if (zT_308) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    return (unsigned char)(1);
    z_bb_240:
    goto z_bb_63;
    z_bb_241:
    return (unsigned char)(1);
    z_bb_242:
    goto z_bb_63;
    z_bb_243:
    return (unsigned char)(1);
    z_bb_244:
    goto z_bb_63;
    z_bb_245:
    zT_324 = bcg.y;
    zT_323 = zT_324 == v;
    goto z_bb_247;
    z_bb_246:
    zT_323 = 1;
    goto z_bb_247;
    z_bb_247:
    if (zT_323) goto z_bb_248; else goto z_bb_249;
    z_bb_248:
    return (unsigned char)(1);
    z_bb_249:
    goto z_bb_63;
    z_bb_250:
    zT_331 = bcc.bg;
    zT_330 = zT_331 == v;
    goto z_bb_252;
    z_bb_251:
    zT_330 = 1;
    goto z_bb_252;
    z_bb_252:
    if (zT_330) goto z_bb_253; else goto z_bb_254;
    z_bb_253:
    return (unsigned char)(1);
    z_bb_254:
    goto z_bb_63;
    z_bb_255:
    return (unsigned char)(1);
    z_bb_256:
    goto z_bb_63;
}

/* instIsSuspendPoint */
unsigned char zF_1AAC25A7_instIsSuspendPoint(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned int zT_3;
    zT_BBC23664_LirFunction* zT_6;
    unsigned int zT_7;
    zT_3BFB1E70_CallDirectData zT_9 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned char zT_15 = 0;
    zT_79FAE712_u64 zT_17;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned char zT_32 = 0;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_D787BF51_anon_76802 ic;
    zT_3 = inst.tag;
switch (zT_3) {
case 23: goto z_bb_1;
case 44: goto z_bb_2;
default: goto z_bb_3;
}
    z_bb_1:
    slot = inst.payload.jump._0;
    zT_6 = c->lir_fn;
    zT_7 = slot;
    zT_9 = zF_75DE985C_lirSideGetCallDirec(zT_6, zT_7);
    cd = zT_9;
    zT_10 = suspending_fns;
    zT_11 = cd.module_id;
    zT_12 = cd.name_id;
    zT_15 = zF_7C7E43BF_asyncIsSuspending(zT_10, zT_11, zT_12);
    return zT_15;
    z_bb_2:
    ic = inst.payload.int_const._0;
    zT_17 = ic.value;
    if ((unsigned char)(zT_17 != (zT_79FAE712_u64)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    return (unsigned char)(0);
    return 0;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_21 = ic.result;
    zT_22 = c->max_temp;
    if ((unsigned char)(zT_21 >= zT_22)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_25 = c->reg;
    zT_28 = c->ttype;
    zT_29 = ic.result;
    zT_30 = (unsigned int)zT_29;
    zT_26 = zT_28[zT_30];
    zT_32 = zF_5049D2D3_typeIsPtrVoid(zT_25, zT_26);
    return zT_32;
}

/* hasDefBefore */
unsigned char zF_93E9604D_hasDefBefore(zT_6D148508_Scan* c, unsigned int v, unsigned int sbb, unsigned int sii) {
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_7;
    unsigned int zT_8;
    zT_BBC23664_LirFunction* zT_13;
    zT_1CF28CA3_BasicBlockArrayList zT_14;
    zT_88A68B1A_BasicBlock* zT_15;
    zT_88A68B1A_BasicBlock* zT_16;
    unsigned int zT_18;
    zT_DAE4631D_LirInstArrayList zT_19;
    unsigned int zT_20;
    unsigned char zT_24;
    zT_6D148508_Scan* zT_27;
    zT_6BA597BC_LirInst zT_28;
    unsigned int zT_29;
    zT_DAE4631D_LirInstArrayList zT_30;
    zT_6BA597BC_LirInst* zT_31;
    zT_6BA597BC_LirInst zT_32;
    unsigned char zT_33 = 0;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_5 = 0;
    bi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = c->lir_fn;
    zT_7 = zT_6->blocks;
    zT_8 = zT_7.len;
    if ((unsigned char)(bi < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    if ((unsigned char)((unsigned int)((unsigned int)bi) > sbb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_38 = bi + (unsigned int)(1);
    bi = zT_38;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    zT_13 = c->lir_fn;
    zT_14 = zT_13->blocks;
    zT_15 = zT_14.items;
    zT_16 = zT_15 + bi;
    bb = zT_16;
    zT_18 = 0;
    ii = zT_18;
    goto z_bb_7;
    z_bb_7:
    zT_19 = bb->insts;
    zT_20 = zT_19.len;
    if ((unsigned char)(ii < zT_20)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    if ((unsigned char)((unsigned int)((unsigned int)bi) == sbb)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_36 = ii + (unsigned int)(1);
    ii = zT_36;
    goto z_bb_7;
    z_bb_11:
    zT_24 = (unsigned int)((unsigned int)ii) >= sii;
    goto z_bb_13;
    z_bb_12:
    zT_24 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_24) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_27 = c;
    zT_30 = bb->insts;
    zT_31 = zT_30.items;
    zT_32 = zT_31[ii];
    zT_28 = zT_32;
    zT_29 = v;
    zT_33 = zF_1FF90D33_instDefsTemp(zT_27, zT_28, zT_29);
    if (zT_33) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    goto z_bb_10;
}

/* cfgPushSuccessors */
void zF_D7490A6E_cfgPushSuccessors(zT_6D148508_Scan* c, unsigned int b, unsigned int* sp) {
    zT_BBC23664_LirFunction* zT_4;
    zT_1CF28CA3_BasicBlockArrayList zT_5;
    zT_88A68B1A_BasicBlock* zT_6;
    zT_88A68B1A_BasicBlock* zT_8;
    unsigned char zT_10;
    unsigned int zT_12;
    zT_DAE4631D_LirInstArrayList zT_13;
    unsigned int zT_14;
    zT_DAE4631D_LirInstArrayList zT_16;
    zT_6BA597BC_LirInst* zT_17;
    zT_6BA597BC_LirInst zT_18;
    unsigned int zT_19;
    unsigned int* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned char zT_27;
    unsigned int zT_29;
    unsigned int* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned char zT_43;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_BBC23664_LirFunction* zT_53;
    zT_9F514E82_SwitchCaseArrayList zT_54;
    zT_4BD97095_SwitchCase* zT_55;
    unsigned int zT_56;
    zT_4BD97095_SwitchCase zT_57;
    unsigned int zT_58;
    unsigned int* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int zT_66;
    unsigned int zT_67;
    unsigned int* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned char zT_74;
    unsigned char zT_75;
    unsigned int zT_77;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_88;
    zT_88A68B1A_BasicBlock* bb;
    unsigned char terminated;
    unsigned int ii;
    unsigned int jb;
    zT_7855DC52_anon_76546 br;
    zT_7A581E0F_anon_76556 sw;
    unsigned int si;
    unsigned int se;
    zT_4BD97095_SwitchCase sc;
    unsigned int nxt;
    zT_4 = c->lir_fn;
    zT_5 = zT_4->blocks;
    zT_6 = zT_5.items;
    zT_8 = zT_6 + (unsigned int)((unsigned int)b);
    bb = zT_8;
    zT_10 = bb->is_terminated;
    terminated = zT_10;
    zT_12 = 0;
    ii = zT_12;
    goto z_bb_1;
    z_bb_1:
    zT_13 = bb->insts;
    zT_14 = zT_13.len;
    if ((unsigned char)(ii < zT_14)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = bb->insts;
    zT_17 = zT_16.items;
    zT_18 = zT_17[ii];
    zT_19 = zT_18.tag;
switch (zT_19) {
case 5: goto z_bb_5;
case 6: goto z_bb_6;
case 7: goto z_bb_7;
case 9: goto z_bb_8;
case 10: goto z_bb_8;
case 70: goto z_bb_8;
default: goto z_bb_9;
}
    z_bb_3:
    if ((unsigned char)(terminated == (unsigned char)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_4:
    zT_77 = ii + (unsigned int)(1);
    ii = zT_77;
    goto z_bb_1;
    z_bb_5:
    jb = zT_18.payload.jump._0;
    zT_21 = c->work;
    zT_22 = *sp;
    zT_23 = (unsigned int)zT_22;
    zT_21[zT_23] = jb;
    zT_24 = *sp;
    *sp = (unsigned int)(zT_24 + (unsigned int)(1));
    zT_27 = 1;
    terminated = zT_27;
    goto z_bb_11;
    z_bb_6:
    br = zT_18.payload.branch._0;
    zT_29 = br.then_bb;
    zT_30 = c->work;
    zT_31 = *sp;
    zT_32 = (unsigned int)zT_31;
    zT_30[zT_32] = zT_29;
    zT_33 = *sp;
    *sp = (unsigned int)(zT_33 + (unsigned int)(1));
    zT_36 = br.else_bb;
    zT_37 = c->work;
    zT_38 = *sp;
    zT_39 = (unsigned int)zT_38;
    zT_37[zT_39] = zT_36;
    zT_40 = *sp;
    *sp = (unsigned int)(zT_40 + (unsigned int)(1));
    zT_43 = 1;
    terminated = zT_43;
    goto z_bb_11;
    z_bb_7:
    sw = zT_18.payload.switch_br._0;
    zT_46 = sw.cases_start;
    si = zT_46;
    zT_48 = sw.cases_start;
    zT_49 = sw.cases_count;
    zT_50 = zT_48 + zT_49;
    se = zT_50;
    goto z_bb_12;
    z_bb_8:
    zT_75 = 1;
    terminated = zT_75;
    goto z_bb_11;
    z_bb_9:
    goto z_bb_11;
    z_bb_11:
    goto z_bb_4;
    z_bb_12:
    if ((unsigned char)(si < se)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_53 = c->lir_fn;
    zT_54 = zT_53->switch_cases;
    zT_55 = zT_54.items;
    zT_56 = (unsigned int)si;
    zT_57 = zT_55[zT_56];
    sc = zT_57;
    zT_58 = sc.target_bb;
    zT_59 = c->work;
    zT_60 = *sp;
    zT_61 = (unsigned int)zT_60;
    zT_59[zT_61] = zT_58;
    zT_62 = *sp;
    *sp = (unsigned int)(zT_62 + (unsigned int)(1));
    goto z_bb_15;
    z_bb_14:
    zT_67 = sw.else_bb;
    zT_68 = c->work;
    zT_69 = *sp;
    zT_70 = (unsigned int)zT_69;
    zT_68[zT_70] = zT_67;
    zT_71 = *sp;
    *sp = (unsigned int)(zT_71 + (unsigned int)(1));
    zT_74 = 1;
    terminated = zT_74;
    goto z_bb_11;
    z_bb_15:
    zT_66 = si + (unsigned int)(1);
    si = zT_66;
    goto z_bb_12;
    z_bb_16:
    zT_82 = b + (unsigned int)(1);
    nxt = zT_82;
    zT_83 = c->nblocks;
    if ((unsigned char)(nxt < zT_83)) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    return;
    z_bb_18:
    zT_85 = c->work;
    zT_86 = *sp;
    zT_87 = (unsigned int)zT_86;
    zT_85[zT_87] = nxt;
    zT_88 = *sp;
    *sp = (unsigned int)(zT_88 + (unsigned int)(1));
    goto z_bb_19;
    z_bb_19:
    goto z_bb_17;
}

/* hasReadAfter */
unsigned char zF_4CED5DFF_hasReadAfter(zT_6D148508_Scan* c, unsigned int v, unsigned int sbb, unsigned int sii) {
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_7;
    unsigned int zT_8;
    zT_BBC23664_LirFunction* zT_11;
    zT_1CF28CA3_BasicBlockArrayList zT_12;
    zT_88A68B1A_BasicBlock* zT_13;
    zT_88A68B1A_BasicBlock* zT_14;
    unsigned int zT_16;
    unsigned int zT_21;
    zT_DAE4631D_LirInstArrayList zT_22;
    unsigned int zT_23;
    zT_6D148508_Scan* zT_25;
    zT_6BA597BC_LirInst zT_26;
    unsigned int zT_27;
    zT_DAE4631D_LirInstArrayList zT_28;
    zT_6BA597BC_LirInst* zT_29;
    zT_6BA597BC_LirInst zT_30;
    unsigned char zT_31 = 0;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned char zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    unsigned int zT_45;
    unsigned int zT_47;
    zT_6D148508_Scan* zT_48;
    unsigned int zT_49;
    unsigned int* zT_50;
    unsigned int zT_55;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    unsigned int zT_63;
    unsigned char zT_64;
    unsigned char zT_67;
    unsigned char* zT_68;
    unsigned int zT_69;
    zT_BBC23664_LirFunction* zT_71;
    zT_1CF28CA3_BasicBlockArrayList zT_72;
    zT_88A68B1A_BasicBlock* zT_73;
    zT_88A68B1A_BasicBlock* zT_75;
    unsigned int zT_77;
    zT_DAE4631D_LirInstArrayList zT_78;
    unsigned int zT_79;
    unsigned char zT_82;
    zT_6D148508_Scan* zT_85;
    zT_6BA597BC_LirInst zT_86;
    unsigned int zT_87;
    zT_DAE4631D_LirInstArrayList zT_88;
    zT_6BA597BC_LirInst* zT_89;
    zT_6BA597BC_LirInst zT_90;
    unsigned char zT_91 = 0;
    unsigned int zT_94;
    zT_6D148508_Scan* zT_95;
    unsigned int zT_96;
    unsigned int* zT_97;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    unsigned int z;
    unsigned int sp;
    unsigned int b;
    zT_88A68B1A_BasicBlock* bb2;
    unsigned int ii2;
    zT_5 = (unsigned int)sbb;
    bi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = c->lir_fn;
    zT_7 = zT_6->blocks;
    zT_8 = zT_7.len;
    if ((unsigned char)(bi < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = c->lir_fn;
    zT_12 = zT_11->blocks;
    zT_13 = zT_12.items;
    zT_14 = zT_13 + bi;
    bb = zT_14;
    zT_16 = 0;
    ii = zT_16;
    if ((unsigned char)((unsigned int)((unsigned int)bi) == sbb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_38 = 0;
    z = zT_38;
    goto z_bb_13;
    z_bb_4:
    zT_36 = bi + (unsigned int)(1);
    bi = zT_36;
    goto z_bb_1;
    z_bb_5:
    zT_21 = (unsigned int)((unsigned int)sii) + (unsigned int)(1);
    ii = zT_21;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_7;
    z_bb_7:
    zT_22 = bb->insts;
    zT_23 = zT_22.len;
    if ((unsigned char)(ii < zT_23)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = c;
    zT_28 = bb->insts;
    zT_29 = zT_28.items;
    zT_30 = zT_29[ii];
    zT_26 = zT_30;
    zT_27 = v;
    zT_31 = zF_E4C3429C_instReadsTemp(zT_25, zT_26, zT_27);
    if (zT_31) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_34 = ii + (unsigned int)(1);
    ii = zT_34;
    goto z_bb_7;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_39 = c->nblocks;
    if ((unsigned char)(z < zT_39)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_41 = 0;
    zT_42 = c->visited;
    zT_43 = (unsigned int)z;
    zT_42[zT_43] = zT_41;
    goto z_bb_16;
    z_bb_15:
    zT_47 = 0;
    sp = zT_47;
    zT_48 = c;
    zT_49 = sbb;
    zT_50 = &sp;
    zF_D7490A6E_cfgPushSuccessors(zT_48, zT_49, zT_50);
    goto z_bb_17;
    z_bb_16:
    zT_45 = z + (unsigned int)(1);
    z = zT_45;
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(sp > (unsigned int)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_55 = sp - (unsigned int)(1);
    sp = zT_55;
    zT_57 = c->work;
    zT_58 = (unsigned int)sp;
    zT_59 = zT_57[zT_58];
    b = zT_59;
    zT_60 = c->nblocks;
    if ((unsigned char)(b >= zT_60)) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    goto z_bb_20;
    z_bb_22:
    zT_62 = c->visited;
    zT_63 = (unsigned int)b;
    zT_64 = zT_62[zT_63];
    if ((unsigned char)(zT_64 != (unsigned char)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_67 = 1;
    zT_68 = c->visited;
    zT_69 = (unsigned int)b;
    zT_68[zT_69] = zT_67;
    zT_71 = c->lir_fn;
    zT_72 = zT_71->blocks;
    zT_73 = zT_72.items;
    zT_75 = zT_73 + (unsigned int)((unsigned int)b);
    bb2 = zT_75;
    zT_77 = 0;
    ii2 = zT_77;
    goto z_bb_25;
    z_bb_25:
    zT_78 = bb2->insts;
    zT_79 = zT_78.len;
    if ((unsigned char)(ii2 < zT_79)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    if ((unsigned char)(b == sbb)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    zT_95 = c;
    zT_96 = b;
    zT_97 = &sp;
    zF_D7490A6E_cfgPushSuccessors(zT_95, zT_96, zT_97);
    goto z_bb_20;
    z_bb_28:
    zT_94 = ii2 + (unsigned int)(1);
    ii2 = zT_94;
    goto z_bb_25;
    z_bb_29:
    zT_82 = (unsigned int)((unsigned int)ii2) == sii;
    goto z_bb_31;
    z_bb_30:
    zT_82 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_82) goto z_bb_32; else goto z_bb_34;
    z_bb_32:
    goto z_bb_33;
    z_bb_33:
    goto z_bb_28;
    z_bb_34:
    zT_85 = c;
    zT_88 = bb2->insts;
    zT_89 = zT_88.items;
    zT_90 = zT_89[ii2];
    zT_86 = zT_90;
    zT_87 = v;
    zT_91 = zF_E4C3429C_instReadsTemp(zT_85, zT_86, zT_87);
    if (zT_91) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    return (unsigned char)(1);
    z_bb_36:
    goto z_bb_33;
}

/* addField */
void zF_F2801F08_addField(zT_2CF63CE1_AsyncFrameFieldArra* fields, zT_338B7C76_TypeRegistry* reg, unsigned char kind, unsigned int name_id, unsigned int temp_id, unsigned int type_id, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_9;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int* zT_14;
    unsigned int* zT_15;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int* zT_22;
    unsigned int zT_23 = 0;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_24;
    zT_902E38E8_AsyncFrameField zT_25;
    zT_902E38E8_AsyncFrameField zT_26;
    unsigned int size;
    unsigned int alignment;
    unsigned int at;
    zT_9 = 0;
    size = zT_9;
    zT_11 = 0;
    alignment = zT_11;
    zT_12 = reg;
    zT_13 = type_id;
    zT_14 = &size;
    zT_15 = &alignment;
    zF_816D1610_frameFieldSizeAlign(zT_12, zT_13, zT_14, zT_15);
    zT_19 = reg;
    zT_20 = type_id;
    zT_21 = offset;
    zT_22 = max_align;
    zT_23 = zF_769CB99B_addFrameField(zT_19, zT_20, zT_21, zT_22);
    at = zT_23;
    zT_24 = fields;
    zT_26.kind = kind;
    zT_26.name_id = name_id;
    zT_26.temp_id = temp_id;
    zT_26.type_id = type_id;
    zT_26.offset = at;
    zT_26.size = size;
    zT_26.alignment = alignment;
    zT_25 = zT_26;
    zF_92FA7DBC_fieldArrayListAppen(zT_24, zT_25);
    return;
}

/* emitLayoutMarker */
void zF_2B302EFE_emitLayoutMarker(unsigned int module_id, unsigned int name_id, unsigned int size) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_5826BFC7_Arr_unsigned_char_1 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned char* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_5826BFC7_Arr_unsigned_char_1 zT_38;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char* zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    zT_5826BFC7_Arr_unsigned_char_1 zT_67;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    int zT_73;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77 = 0;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_4 = "LAYOUT:m";
    zT_6 = 8;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    m1 = zT_5;
    zT_7 = m1;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = module_id;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)b1) + zT_15;
    zT_17 = (unsigned int)(12) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    l1 = zT_19;
    zT_24 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_24;
    zT_29 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_30 = (unsigned int)(11) - s1;
    zT_31.ptr = zT_29;
    zT_31.len = zT_30;
    zT_25 = zT_31;
    zF_48AC7B3A_markerWrite(zT_25);
    zT_33 = ":n";
    zT_35 = 2;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    m2 = zT_34;
    zT_36 = m2;
    zF_48AC7B3A_markerWrite(zT_36);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_38[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_38[_i];
        _i++;
    }
}
    zT_40 = name_id;
    zT_44 = 0;
    zT_45 = (unsigned char*)((unsigned char*)b2) + zT_44;
    zT_46 = (unsigned int)(12) - zT_44;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_41 = zT_47;
    zT_48 = zF_A7504564_itoa(zT_40, zT_41);
    l2 = zT_48;
    zT_53 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_53;
    zT_58 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_59 = (unsigned int)(11) - s2;
    zT_60.ptr = zT_58;
    zT_60.len = zT_59;
    zT_54 = zT_60;
    zF_48AC7B3A_markerWrite(zT_54);
    zT_62 = ":s";
    zT_64 = 2;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    m3 = zT_63;
    zT_65 = m3;
    zF_48AC7B3A_markerWrite(zT_65);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_67[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_67[_i];
        _i++;
    }
}
    zT_69 = size;
    zT_73 = 0;
    zT_74 = (unsigned char*)((unsigned char*)b3) + zT_73;
    zT_75 = (unsigned int)(12) - zT_73;
    zT_76.ptr = zT_74;
    zT_76.len = zT_75;
    zT_70 = zT_76;
    zT_77 = zF_A7504564_itoa(zT_69, zT_70);
    l3 = zT_77;
    zT_82 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l3));
    s3 = zT_82;
    zT_87 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_88 = (unsigned int)(11) - s3;
    zT_89.ptr = zT_87;
    zT_89.len = zT_88;
    zT_83 = zT_89;
    zF_48AC7B3A_markerWrite(zT_83);
    zT_91 = "\n";
    zT_93 = 1;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    m4 = zT_92;
    zT_94 = m4;
    zF_48AC7B3A_markerWrite(zT_94);
    return;
}

/* asyncLayoutFrame */
zT_3F3BF87A_AsyncFrameLayout zF_28031796_asyncLayoutFrame(zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg, zT_BBC23664_LirFunction* lir_fn, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* state_widths, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_A4CE86B7_U64ToU32Map* driver_targets, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    zT_BBC23664_LirFunction* zT_13;
    unsigned int zT_14 = 0;
    zT_3E40CD83_Sand* zT_16;
    zT_CFE23D0A_LirParamArrayList zT_18;
    unsigned int zT_19;
    zT_5D72FBF8_TempDeclArrayList zT_20;
    unsigned int zT_21;
    zT_2CF63CE1_AsyncFrameFieldArra zT_25 = {0};
    zT_3E40CD83_Sand* zT_27;
    zT_21D3708C_U32ToU32Map zT_28 = {0};
    zT_1CF28CA3_BasicBlockArrayList zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_3E40CD83_Sand* zT_34;
    unsigned int zT_35;
    unsigned char* zT_36 = 0;
    zT_3E40CD83_Sand* zT_38;
    zT_9F514E82_SwitchCaseArrayList zT_43;
    unsigned int zT_44;
    unsigned int* zT_50 = 0;
    zT_6D148508_Scan zT_52;
    zT_3E40CD83_Sand* zT_53;
    unsigned int zT_54;
    unsigned int* zT_57 = 0;
    zT_21D3708C_U32ToU32Map* zT_58;
    unsigned int zT_60;
    zT_5D72FBF8_TempDeclArrayList zT_61;
    unsigned int zT_62;
    zT_5D72FBF8_TempDeclArrayList zT_65;
    zT_1937645B_TempDecl* zT_66;
    zT_1937645B_TempDecl zT_67;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int* zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    unsigned int zT_75;
    unsigned int zT_77;
    zT_CFE23D0A_LirParamArrayList zT_78;
    unsigned int zT_79;
    zT_CFE23D0A_LirParamArrayList zT_82;
    zT_8779209D_LirParam* zT_83;
    zT_8779209D_LirParam zT_84;
    zT_21D3708C_U32ToU32Map* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    unsigned int zT_92;
    unsigned int zT_94;
    zT_1CF28CA3_BasicBlockArrayList zT_95;
    unsigned int zT_96;
    zT_1CF28CA3_BasicBlockArrayList zT_99;
    zT_88A68B1A_BasicBlock* zT_100;
    zT_88A68B1A_BasicBlock* zT_101;
    unsigned int zT_103;
    zT_DAE4631D_LirInstArrayList zT_104;
    unsigned int zT_105;
    zT_DAE4631D_LirInstArrayList zT_107;
    zT_6BA597BC_LirInst* zT_108;
    zT_6BA597BC_LirInst zT_109;
    unsigned int zT_110;
    zT_21D3708C_U32ToU32Map* zT_112;
    unsigned int zT_113;
    unsigned int zT_114;
    unsigned int zT_119;
    unsigned int zT_121;
    zT_3E40CD83_Sand* zT_123;
    unsigned int zT_124;
    unsigned char* zT_127 = 0;
    unsigned int zT_128;
    zT_CFE23D0A_LirParamArrayList zT_129;
    unsigned int zT_130;
    zT_CFE23D0A_LirParamArrayList zT_133;
    zT_8779209D_LirParam* zT_134;
    zT_8779209D_LirParam zT_135;
    unsigned int zT_136;
    unsigned char zT_138;
    unsigned int zT_139;
    unsigned int zT_141;
    zT_3E40CD83_Sand* zT_143;
    unsigned int zT_144;
    unsigned char* zT_145 = 0;
    unsigned int zT_147;
    unsigned char zT_149;
    unsigned int zT_150;
    unsigned int zT_152;
    unsigned int zT_153;
    zT_1CF28CA3_BasicBlockArrayList zT_154;
    unsigned int zT_155;
    zT_1CF28CA3_BasicBlockArrayList zT_158;
    zT_88A68B1A_BasicBlock* zT_159;
    zT_88A68B1A_BasicBlock* zT_160;
    unsigned int zT_162;
    zT_DAE4631D_LirInstArrayList zT_163;
    unsigned int zT_164;
    zT_DAE4631D_LirInstArrayList zT_167;
    zT_6BA597BC_LirInst* zT_168;
    zT_6BA597BC_LirInst zT_169;
    zT_6D148508_Scan* zT_170;
    zT_6BA597BC_LirInst zT_171;
    zT_A4CE86B7_U64ToU32Map* zT_172;
    unsigned char zT_174 = 0;
    unsigned int zT_175;
    unsigned int zT_178;
    unsigned char zT_179;
    zT_6D148508_Scan* zT_182;
    unsigned int zT_183;
    unsigned char zT_189 = 0;
    zT_6D148508_Scan* zT_191;
    unsigned int zT_192;
    unsigned char zT_198 = 0;
    unsigned char zT_199;
    unsigned int zT_201;
    unsigned int zT_203;
    unsigned int zT_205;
    unsigned int zT_207;
    unsigned int zT_209;
    unsigned int zT_211;
    zT_A4CE86B7_U64ToU32Map* zT_212;
    zT_79FAE712_u64 zT_213;
    unsigned int zT_214;
    unsigned int zT_215;
    zT_79FAE712_u64 zT_218 = 0;
    zT_BAEE192E_Opt_10 zT_219 = {0};
    unsigned char zT_220;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_222;
    zT_338B7C76_TypeRegistry* zT_223;
    unsigned char zT_224;
    unsigned int* zT_228;
    unsigned int* zT_229;
    unsigned int zT_231;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_237;
    zT_338B7C76_TypeRegistry* zT_238;
    unsigned char zT_239;
    unsigned int* zT_243;
    unsigned int* zT_244;
    unsigned int zT_246;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_252;
    zT_338B7C76_TypeRegistry* zT_253;
    unsigned char zT_254;
    unsigned int zT_257;
    unsigned int* zT_258;
    unsigned int* zT_259;
    unsigned int zT_261;
    unsigned int zT_266;
    zT_CFE23D0A_LirParamArrayList zT_267;
    unsigned int zT_268;
    zT_CFE23D0A_LirParamArrayList zT_271;
    zT_8779209D_LirParam* zT_272;
    zT_8779209D_LirParam zT_273;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_274;
    zT_338B7C76_TypeRegistry* zT_275;
    unsigned char zT_276;
    unsigned int zT_277;
    unsigned int zT_278;
    unsigned int zT_279;
    unsigned int* zT_280;
    unsigned int* zT_281;
    unsigned int zT_283;
    unsigned int zT_290;
    unsigned int zT_291;
    unsigned int zT_294;
    unsigned char zT_295;
    unsigned char zT_298;
    unsigned char zT_299;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_302;
    zT_338B7C76_TypeRegistry* zT_303;
    unsigned char zT_304;
    unsigned int zT_306;
    unsigned int zT_307;
    unsigned int* zT_308;
    unsigned int* zT_309;
    unsigned int zT_311;
    unsigned int* zT_313;
    unsigned int zT_318;
    unsigned int zT_320;
    unsigned int zT_322;
    unsigned int zT_323;
    zT_79FAE712_u64 zT_326 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_327;
    zT_79FAE712_u64 zT_328;
    zT_BAEE192E_Opt_10 zT_329 = {0};
    unsigned char zT_330;
    zT_338B7C76_TypeRegistry* zT_333;
    unsigned int zT_338 = 0;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_343;
    zT_338B7C76_TypeRegistry* zT_344;
    unsigned char zT_345;
    unsigned int zT_348;
    unsigned int* zT_349;
    unsigned int* zT_350;
    unsigned int zT_352;
    zT_A4CE86B7_U64ToU32Map* zT_357;
    zT_79FAE712_u64 zT_358;
    zT_BAEE192E_Opt_10 zT_359 = {0};
    unsigned char zT_360;
    unsigned char zT_361;
    zT_A4CE86B7_U64ToU32Map* zT_362;
    zT_79FAE712_u64 zT_363;
    zT_BAEE192E_Opt_10 zT_364 = {0};
    unsigned char zT_365;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_366;
    zT_338B7C76_TypeRegistry* zT_367;
    unsigned char zT_368;
    unsigned int zT_371;
    unsigned int* zT_372;
    unsigned int* zT_373;
    unsigned int zT_375;
    unsigned int zT_385;
    zT_A4CE86B7_U64ToU32Map* zT_386;
    zT_79FAE712_u64 zT_387;
    zT_BAEE192E_Opt_10 zT_388 = {0};
    unsigned char zT_389;
    unsigned int zT_392;
    zT_A4CE86B7_U64ToU32Map* zT_393;
    zT_79FAE712_u64 zT_394;
    zT_BAEE192E_Opt_10 zT_395 = {0};
    unsigned char zT_396;
    unsigned int zT_399;
    unsigned int* zT_402;
    unsigned int zT_404;
    unsigned int zT_405;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_406;
    zT_338B7C76_TypeRegistry* zT_407;
    unsigned char zT_408;
    unsigned int zT_411;
    unsigned int* zT_412;
    unsigned int* zT_413;
    unsigned int zT_415;
    unsigned int zT_421;
    unsigned int zT_423;
    unsigned int zT_424;
    unsigned int zT_425 = 0;
    unsigned int zT_428;
    unsigned int zT_429;
    unsigned int zT_432 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_434;
    unsigned int zT_435;
    unsigned int zT_436;
    zT_BAEE192E_Opt_10 zT_439 = {0};
    unsigned char zT_441;
    char* zT_444;
    unsigned int zT_445;
    char* zT_446;
    unsigned int zT_447;
    char* zT_448;
    unsigned int zT_449;
    char* zT_451;
    unsigned int zT_452;
    char* zT_453;
    unsigned int zT_454;
    char* zT_455;
    unsigned int zT_456;
    unsigned int zT_458;
    unsigned int zT_459;
    unsigned int zT_460;
    zT_3F3BF87A_AsyncFrameLayout zT_463;
    unsigned int max_temp;
    zT_2CF63CE1_AsyncFrameFieldArra fields;
    zT_21D3708C_U32ToU32Map locals;
    unsigned int nblocks;
    unsigned char* visited;
    unsigned int* work;
    zT_6D148508_Scan c;
    unsigned int hti;
    zT_1937645B_TempDecl td;
    unsigned int pi;
    zT_8779209D_LirParam p;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    unsigned char* is_param;
    zT_025FAFEC_anon_76508 dl;
    unsigned int pt;
    unsigned char* live;
    unsigned int t;
    unsigned int offset;
    unsigned int max_align;
    unsigned int state_type;
    zT_6BA597BC_LirInst inst;
    unsigned int tu;
    unsigned int sw;
    unsigned int hid;
    zT_79FAE712_u64 lay_key;
    unsigned int h;
    unsigned int lay_ptr_void;
    unsigned int pstart;
    unsigned int precise;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_BAEE192E_Opt_10 frame_size;
    unsigned int padded;
    unsigned int fs;
    zT_13 = lir_fn;
    zT_14 = zF_005F8966_maxTempOf(zT_13);
    max_temp = zT_14;
    zT_16 = alloc;
    zT_18 = lir_fn->params;
    zT_19 = zT_18.len;
    zT_20 = lir_fn->hoisted_temps;
    zT_21 = zT_20.len;
    zT_25 = zF_1BFB52BE_fieldArrayListInit(zT_16, (unsigned int)((unsigned int)(zT_19 + zT_21) + (unsigned int)(2)));
    fields = zT_25;
    zT_27 = alloc;
    zT_28 = zF_58BDA2DE_u32ToU32MapInit(zT_27);
    locals = zT_28;
    zT_30 = lir_fn->blocks;
    zT_31 = zT_30.len;
    zT_32 = (unsigned int)zT_31;
    nblocks = zT_32;
    zT_34 = alloc;
    zT_35 = nblocks;
    zT_36 = zF_F15DB413_allocU8Raw(zT_34, zT_35);
    visited = zT_36;
    zT_38 = alloc;
    zT_43 = lir_fn->switch_cases;
    zT_44 = zT_43.len;
    zT_50 = zF_82E88BBC_allocU32With(zT_38, (unsigned int)((unsigned int)((unsigned int)(nblocks * (unsigned int)(2)) + (unsigned int)((unsigned int)zT_44)) + (unsigned int)(4)), (unsigned int)(0));
    work = zT_50;
    zT_52.lir_fn = lir_fn;
    zT_52.reg = reg;
    zT_52.max_temp = max_temp;
    zT_53 = alloc;
    zT_54 = max_temp;
    zT_57 = zF_82E88BBC_allocU32With(zT_53, zT_54, (unsigned int)(18));
    zT_52.ttype = zT_57;
    zT_58 = &locals;
    zT_52.locals = zT_58;
    zT_52.alloc = alloc;
    zT_52.nblocks = nblocks;
    zT_52.visited = visited;
    zT_52.work = work;
    c = zT_52;
    zT_60 = 0;
    hti = zT_60;
    goto z_bb_1;
    z_bb_1:
    zT_61 = lir_fn->hoisted_temps;
    zT_62 = zT_61.len;
    if ((unsigned char)(hti < zT_62)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_65 = lir_fn->hoisted_temps;
    zT_66 = zT_65.items;
    zT_67 = zT_66[hti];
    td = zT_67;
    zT_68 = td.temp_id;
    if ((unsigned char)(zT_68 < max_temp)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_77 = 0;
    pi = zT_77;
    goto z_bb_7;
    z_bb_4:
    zT_75 = hti + (unsigned int)(1);
    hti = zT_75;
    goto z_bb_1;
    z_bb_5:
    zT_70 = td.type_id;
    zT_71 = c.ttype;
    zT_72 = td.temp_id;
    zT_73 = (unsigned int)zT_72;
    zT_71[zT_73] = zT_70;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_78 = lir_fn->params;
    zT_79 = zT_78.len;
    if ((unsigned char)(pi < zT_79)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_82 = lir_fn->params;
    zT_83 = zT_82.items;
    zT_84 = zT_83[pi];
    p = zT_84;
    zT_85 = &locals;
    zT_86 = p.name_id;
    zT_87 = p.temp_id;
    zF_26476265_u32ToU32MapPut(zT_85, zT_86, zT_87);
    (void)alloc;
    goto z_bb_10;
    z_bb_9:
    zT_94 = 0;
    bi = zT_94;
    goto z_bb_11;
    z_bb_10:
    zT_92 = pi + (unsigned int)(1);
    pi = zT_92;
    goto z_bb_7;
    z_bb_11:
    zT_95 = lir_fn->blocks;
    zT_96 = zT_95.len;
    if ((unsigned char)(bi < zT_96)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_99 = lir_fn->blocks;
    zT_100 = zT_99.items;
    zT_101 = zT_100 + bi;
    bb = zT_101;
    zT_103 = 0;
    ii = zT_103;
    goto z_bb_15;
    z_bb_13:
    zT_123 = alloc;
    zT_124 = max_temp;
    zT_127 = zF_9C85B07B_allocU8With(zT_123, zT_124, (unsigned char)(0));
    is_param = zT_127;
    zT_128 = 0;
    pi = zT_128;
    goto z_bb_23;
    z_bb_14:
    zT_121 = bi + (unsigned int)(1);
    bi = zT_121;
    goto z_bb_11;
    z_bb_15:
    zT_104 = bb->insts;
    zT_105 = zT_104.len;
    if ((unsigned char)(ii < zT_105)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_107 = bb->insts;
    zT_108 = zT_107.items;
    zT_109 = zT_108[ii];
    zT_110 = zT_109.tag;
switch (zT_110) {
case 1: goto z_bb_19;
default: goto z_bb_20;
}
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_119 = ii + (unsigned int)(1);
    ii = zT_119;
    goto z_bb_15;
    z_bb_19:
    dl = zT_109.payload.decl_local._0;
    zT_112 = &locals;
    zT_113 = dl.name_id;
    zT_114 = dl.temp;
    zF_26476265_u32ToU32MapPut(zT_112, zT_113, zT_114);
    (void)alloc;
    goto z_bb_22;
    z_bb_20:
    goto z_bb_22;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_129 = lir_fn->params;
    zT_130 = zT_129.len;
    if ((unsigned char)(pi < zT_130)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_133 = lir_fn->params;
    zT_134 = zT_133.items;
    zT_135 = zT_134[pi];
    zT_136 = zT_135.temp_id;
    pt = zT_136;
    if ((unsigned char)(pt < max_temp)) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_143 = alloc;
    zT_144 = max_temp;
    zT_145 = zF_F15DB413_allocU8Raw(zT_143, zT_144);
    live = zT_145;
    zT_147 = 0;
    t = zT_147;
    goto z_bb_29;
    z_bb_26:
    zT_141 = pi + (unsigned int)(1);
    pi = zT_141;
    goto z_bb_23;
    z_bb_27:
    zT_138 = 1;
    zT_139 = (unsigned int)pt;
    is_param[zT_139] = zT_138;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    if ((unsigned char)(t < max_temp)) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_149 = 0;
    zT_150 = (unsigned int)t;
    live[zT_150] = zT_149;
    goto z_bb_32;
    z_bb_31:
    zT_153 = 0;
    bi = zT_153;
    goto z_bb_33;
    z_bb_32:
    zT_152 = t + (unsigned int)(1);
    t = zT_152;
    goto z_bb_29;
    z_bb_33:
    zT_154 = lir_fn->blocks;
    zT_155 = zT_154.len;
    if ((unsigned char)(bi < zT_155)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_158 = lir_fn->blocks;
    zT_159 = zT_158.items;
    zT_160 = zT_159 + bi;
    bb = zT_160;
    zT_162 = 0;
    ii = zT_162;
    goto z_bb_37;
    z_bb_35:
    zT_207 = 0;
    offset = zT_207;
    zT_209 = 1;
    max_align = zT_209;
    zT_211 = 8;
    state_type = zT_211;
    zT_212 = state_widths;
    zT_214 = lir_fn->module_id;
    zT_215 = lir_fn->name_id;
    zT_218 = zF_9D041EB6_asyncKey(zT_214, zT_215);
    zT_213 = zT_218;
    zT_219 = zF_A05A7BE1_u64ToU32MapGet(zT_212, zT_213);
    zT_220 = zT_219.has_value;
    if (zT_220) goto z_bb_53; else goto z_bb_54;
    z_bb_36:
    zT_205 = bi + (unsigned int)(1);
    bi = zT_205;
    goto z_bb_33;
    z_bb_37:
    zT_163 = bb->insts;
    zT_164 = zT_163.len;
    if ((unsigned char)(ii < zT_164)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_167 = bb->insts;
    zT_168 = zT_167.items;
    zT_169 = zT_168[ii];
    inst = zT_169;
    zT_170 = &c;
    zT_171 = inst;
    zT_172 = suspending_fns;
    zT_174 = zF_1AAC25A7_instIsSuspendPoint(zT_170, zT_171, zT_172);
    if (zT_174) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_203 = ii + (unsigned int)(1);
    ii = zT_203;
    goto z_bb_37;
    z_bb_41:
    zT_175 = 0;
    t = zT_175;
    goto z_bb_43;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    if ((unsigned char)(t < max_temp)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_178 = (unsigned int)t;
    tu = zT_178;
    zT_179 = is_param[tu];
    if ((unsigned char)(zT_179 != (unsigned char)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_201 = t + (unsigned int)(1);
    t = zT_201;
    goto z_bb_43;
    z_bb_47:
    goto z_bb_46;
    z_bb_48:
    zT_182 = &c;
    zT_183 = t;
    zT_189 = zF_93E9604D_hasDefBefore(zT_182, zT_183, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    if ((unsigned char)(!zT_189)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_191 = &c;
    zT_192 = t;
    zT_198 = zF_4CED5DFF_hasReadAfter(zT_191, zT_192, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    if (zT_198) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_199 = 1;
    live[tu] = zT_199;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_46;
    z_bb_53:
    sw = zT_219.value;
    state_type = sw;
    goto z_bb_54;
    z_bb_54:
    zT_222 = &fields;
    zT_223 = reg;
    zT_231 = 4;
    zT_224 = zT_231;
    zT_228 = &offset;
    zT_229 = &max_align;
    zF_F2801F08_addField(zT_222, zT_223, zT_224, (unsigned int)(0), (unsigned int)(0), (unsigned int)(13), zT_228, zT_229);
    zT_237 = &fields;
    zT_238 = reg;
    zT_246 = 0;
    zT_239 = zT_246;
    zT_243 = &offset;
    zT_244 = &max_align;
    zF_F2801F08_addField(zT_237, zT_238, zT_239, (unsigned int)(0), (unsigned int)(0), (unsigned int)(13), zT_243, zT_244);
    zT_252 = &fields;
    zT_253 = reg;
    zT_261 = 1;
    zT_254 = zT_261;
    zT_257 = state_type;
    zT_258 = &offset;
    zT_259 = &max_align;
    zF_F2801F08_addField(zT_252, zT_253, zT_254, (unsigned int)(0), (unsigned int)(0), zT_257, zT_258, zT_259);
    zT_266 = 0;
    pi = zT_266;
    goto z_bb_55;
    z_bb_55:
    zT_267 = lir_fn->params;
    zT_268 = zT_267.len;
    if ((unsigned char)(pi < zT_268)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_271 = lir_fn->params;
    zT_272 = zT_271.items;
    zT_273 = zT_272[pi];
    p = zT_273;
    zT_274 = &fields;
    zT_275 = reg;
    zT_283 = 2;
    zT_276 = zT_283;
    zT_277 = p.name_id;
    zT_278 = p.temp_id;
    zT_279 = p.type_id;
    zT_280 = &offset;
    zT_281 = &max_align;
    zF_F2801F08_addField(zT_274, zT_275, zT_276, zT_277, zT_278, zT_279, zT_280, zT_281);
    goto z_bb_58;
    z_bb_57:
    zT_291 = 0;
    t = zT_291;
    goto z_bb_59;
    z_bb_58:
    zT_290 = pi + (unsigned int)(1);
    pi = zT_290;
    goto z_bb_55;
    z_bb_59:
    if ((unsigned char)(t < max_temp)) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_294 = (unsigned int)t;
    tu = zT_294;
    zT_295 = live[tu];
    if ((unsigned char)(zT_295 != (unsigned char)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    zT_320 = 0;
    hid = zT_320;
    zT_322 = lir_fn->module_id;
    zT_323 = lir_fn->name_id;
    zT_326 = zF_9D041EB6_asyncKey(zT_322, zT_323);
    lay_key = zT_326;
    zT_327 = async_hidden_fns;
    zT_328 = lay_key;
    zT_329 = zF_A05A7BE1_u64ToU32MapGet(zT_327, zT_328);
    zT_330 = zT_329.has_value;
    if (zT_330) goto z_bb_68; else goto z_bb_69;
    z_bb_62:
    zT_318 = t + (unsigned int)(1);
    t = zT_318;
    goto z_bb_59;
    z_bb_63:
    zT_299 = is_param[tu];
    zT_298 = zT_299 == (unsigned char)(0);
    goto z_bb_65;
    z_bb_64:
    zT_298 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_298) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_302 = &fields;
    zT_303 = reg;
    zT_311 = 3;
    zT_304 = zT_311;
    zT_306 = t;
    zT_313 = c.ttype;
    zT_307 = zT_313[tu];
    zT_308 = &offset;
    zT_309 = &max_align;
    zF_F2801F08_addField(zT_302, zT_303, zT_304, (unsigned int)(0), zT_306, zT_307, zT_308, zT_309);
    goto z_bb_67;
    z_bb_67:
    goto z_bb_62;
    z_bb_68:
    h = zT_329.value;
    hid = h;
    goto z_bb_69;
    z_bb_69:
    zT_333 = reg;
    zT_338 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_333, (unsigned int)(1), (unsigned char)(0));
    lay_ptr_void = zT_338;
    if ((unsigned char)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_343 = &fields;
    zT_344 = reg;
    zT_352 = 5;
    zT_345 = zT_352;
    zT_348 = lay_ptr_void;
    zT_349 = &offset;
    zT_350 = &max_align;
    zF_F2801F08_addField(zT_343, zT_344, zT_345, (unsigned int)(0), (unsigned int)(0), zT_348, zT_349, zT_350);
    goto z_bb_71;
    z_bb_71:
    zT_357 = awaited_fns;
    zT_358 = lay_key;
    zT_359 = zF_A05A7BE1_u64ToU32MapGet(zT_357, zT_358);
    zT_360 = zT_359.has_value;
    if (zT_360) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_362 = driver_targets;
    zT_363 = lay_key;
    zT_364 = zF_A05A7BE1_u64ToU32MapGet(zT_362, zT_363);
    zT_365 = zT_364.has_value;
    zT_361 = zT_365;
    goto z_bb_74;
    z_bb_73:
    zT_361 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_361) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_366 = &fields;
    zT_367 = reg;
    zT_375 = 6;
    zT_368 = zT_375;
    zT_371 = lay_ptr_void;
    zT_372 = &offset;
    zT_373 = &max_align;
    zF_F2801F08_addField(zT_366, zT_367, zT_368, (unsigned int)(0), (unsigned int)(0), zT_371, zT_372, zT_373);
    goto z_bb_76;
    z_bb_76:
    if ((unsigned char)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_385 = 0;
    pstart = zT_385;
    zT_386 = parent_result_start;
    zT_387 = lay_key;
    zT_388 = zF_A05A7BE1_u64ToU32MapGet(zT_386, zT_387);
    zT_389 = zT_388.has_value;
    if (zT_389) goto z_bb_79; else goto z_bb_80;
    z_bb_78:
    zT_423 = offset;
    zT_424 = max_align;
    zT_425 = zF_978D7C93_alignUpU32(zT_423, zT_424);
    precise = zT_425;
    if ((unsigned char)(precise == (unsigned int)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_79:
    ps = zT_388.value;
    pstart = ps;
    goto z_bb_80;
    z_bb_80:
    zT_392 = 0;
    pcount = zT_392;
    zT_393 = parent_result_count;
    zT_394 = lay_key;
    zT_395 = zF_A05A7BE1_u64ToU32MapGet(zT_393, zT_394);
    zT_396 = zT_395.has_value;
    if (zT_396) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    pc = zT_395.value;
    pcount = pc;
    goto z_bb_82;
    z_bb_82:
    zT_399 = 0;
    pk = zT_399;
    goto z_bb_83;
    z_bb_83:
    if ((unsigned char)(pk < pcount)) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_402 = parent_result_type_list->items;
    zT_404 = (unsigned int)(unsigned int)(pstart + pk);
    zT_405 = zT_402[zT_404];
    prt = zT_405;
    zT_406 = &fields;
    zT_407 = reg;
    zT_415 = 7;
    zT_408 = zT_415;
    zT_411 = prt;
    zT_412 = &offset;
    zT_413 = &max_align;
    zF_F2801F08_addField(zT_406, zT_407, zT_408, (unsigned int)(0), (unsigned int)(0), zT_411, zT_412, zT_413);
    goto z_bb_86;
    z_bb_85:
    goto z_bb_78;
    z_bb_86:
    zT_421 = pk + (unsigned int)(1);
    pk = zT_421;
    goto z_bb_83;
    z_bb_87:
    zT_428 = 1;
    precise = zT_428;
    goto z_bb_88;
    z_bb_88:
    zT_429 = precise;
    zT_432 = zF_978D7C93_alignUpU32(zT_429, (unsigned int)(8));
    precise = zT_432;
    zT_434 = frame_sizes;
    zT_435 = lir_fn->module_id;
    zT_436 = lir_fn->name_id;
    zT_439 = zF_D3D61AC0_asyncFrameSizeOf(zT_434, zT_435, zT_436);
    frame_size = zT_439;
    padded = precise;
    zT_441 = frame_size.has_value;
    if (zT_441) goto z_bb_89; else goto z_bb_91;
    z_bb_89:
    fs = frame_size.value;
    if ((unsigned char)(precise > fs)) goto z_bb_92; else goto z_bb_93;
    z_bb_90:
    zT_458 = lir_fn->module_id;
    zT_459 = lir_fn->name_id;
    zT_460 = padded;
    zF_2B302EFE_emitLayoutMarker(zT_458, zT_459, zT_460);
    zT_463.fields = fields;
    zT_463.layout_size = padded;
    return zT_463;
    z_bb_91:
    zT_451 = "panic: ";
    zT_452 = 7;
    fwrite(zT_451, 1, zT_452, stderr);
    zT_453 = "async frame layout: missing authoritative frame size";
    zT_454 = 52;
    fwrite(zT_453, 1, zT_454, stderr);
    zT_455 = "\n";
    zT_456 = 1;
    fwrite(zT_455, 1, zT_456, stderr);
    pal_trap();
    z_bb_92:
    zT_444 = "panic: ";
    zT_445 = 7;
    fwrite(zT_444, 1, zT_445, stderr);
    zT_446 = "async frame layout exceeds authoritative frame size";
    zT_447 = 51;
    fwrite(zT_446, 1, zT_447, stderr);
    zT_448 = "\n";
    zT_449 = 1;
    fwrite(zT_448, 1, zT_449, stderr);
    pal_trap();
    z_bb_93:
    padded = fs;
    goto z_bb_90;
}

/* asyncLayoutPublish */
void zF_17324878_asyncLayoutPublish(zT_3E40CD83_Sand* alloc, zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id, zT_3F3BF87A_AsyncFrameLayout layout) {
    zT_3E40CD83_Sand* zT_6;
    zT_C6536882_EU_532 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    zT_3F3BF87A_AsyncFrameLayout* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_79FAE712_u64 zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_79FAE712_u64 zT_22 = 0;
    unsigned char* raw;
    zT_3F3BF87A_AsyncFrameLayout* p;
    zT_6 = alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(20), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    zT_16 = (zT_3F3BF87A_AsyncFrameLayout*)raw;
    p = zT_16;
    *p = layout;
    zT_17 = map;
    zT_20 = module_id;
    zT_21 = name_id;
    zT_22 = zF_9D041EB6_asyncKey(zT_20, zT_21);
    zT_18 = zT_22;
    zF_B6EB812C_u64ToU32MapPut(zT_17, zT_18, (unsigned int)((unsigned int)(unsigned int)((unsigned int)p)));
    (void)alloc;
    return;
}

/* asyncLayoutLookup */
zT_05CE5599_Opt_400 zF_A1F56FFB_asyncLayoutLookup(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    zT_3F3BF87A_AsyncFrameLayout* zT_12;
    zT_05CE5599_Opt_400 zT_13;
    zT_05CE5599_Opt_400 zT_14 = {0};
    unsigned int v;
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    v = zT_8.value;
    zT_12 = (zT_3F3BF87A_AsyncFrameLayout*)(unsigned int)(unsigned int)((unsigned int)v);
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_2:
    zT_14.has_value = 0;
    return zT_14;
}

/* __module_init */
void zF_780653D2___module_init_23(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_BBC23664_LirFunction zT_1 = {0};
    zT_6BA597BC_LirInst zT_2 = {0};
    zT_338B7C76_TypeRegistry zT_3 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_6BA597BC_LirInst = zT_2;
    zG_338B7C76_TypeRegistry = zT_3;
    return;
}

/* EOF */
