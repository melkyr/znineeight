#include "async_frame_layout_08B81337.h"
#include <stdio.h>
zT_3F3BF87A_AsyncFrameLayout zG_3F3BF87A_AsyncFrameLayout;
/* fieldArrayListInit */
zT_2CF63CE1_AsyncFrameFieldArra zF_1BFB52BE_fieldArrayListInit(zT_3E40CD83_Sand* alloc, unsigned int capacity) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_9154F007_EU_232 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    zT_2CF63CE1_AsyncFrameFieldArra zT_17;
    zT_902E38E8_AsyncFrameField* zT_18;
    unsigned int zT_19;
    unsigned int cap;
    unsigned char* raw;
    cap = capacity;
    if ((int)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    cap = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = alloc;
    zT_13 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)(cap * (unsigned int)(28)), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    zT_18 = (zT_902E38E8_AsyncFrameField*)raw;
    zT_17.items = zT_18;
    zT_19 = 0;
    zT_17.len = zT_19;
    zT_17.capacity = cap;
    zT_17.allocator = alloc;
    return zT_17;
}

/* fieldArrayListEnsureCapacity */
void zF_FB5EC98E_fieldArrayListEnsur(zT_2CF63CE1_AsyncFrameFieldArra* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_9154F007_EU_232 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_902E38E8_AsyncFrameField* zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_902E38E8_AsyncFrameField* zT_33;
    zT_902E38E8_AsyncFrameField zT_34;
    unsigned int zT_36;
    unsigned int new_cap;
    unsigned char* raw;
    zT_902E38E8_AsyncFrameField* new_items;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    if ((int)(new_cap < (unsigned int)(zT_5 * (unsigned int)(2)))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_11 = zT_9 * (unsigned int)(2);
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((int)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(new_cap * (unsigned int)(28)), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_902E38E8_AsyncFrameField*)raw;
    new_items = zT_28;
    zT_30 = 0;
    i = zT_30;
    goto z_bb_10;
    z_bb_10:
    zT_31 = self->len;
    if ((int)(i < zT_31)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->items;
    zT_34 = zT_33[i];
    new_items[i] = zT_34;
    goto z_bb_13;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13:
    zT_36 = i + (unsigned int)(1);
    i = zT_36;
    goto z_bb_10;
}

/* fieldArrayListAppend */
void zF_92FA7DBC_fieldArrayListAppen(zT_2CF63CE1_AsyncFrameFieldArra* self, zT_902E38E8_AsyncFrameField value) {
    zT_2CF63CE1_AsyncFrameFieldArra* zT_2;
    unsigned int zT_4;
    zT_902E38E8_AsyncFrameField* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_2 = self;
    zT_4 = self->len;
    zF_FB5EC98E_fieldArrayListEnsur(zT_2, (unsigned int)(zT_4 + (unsigned int)(1)));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    self->len = (unsigned int)(zT_9 + (unsigned int)(1));
    return;
}

/* allocU32With */
unsigned int* zF_82E88BBC_allocU32With(zT_3E40CD83_Sand* alloc, unsigned int n, unsigned int fill) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    zT_9154F007_EU_232 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned int* zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int count;
    unsigned char* raw;
    unsigned int* a;
    unsigned int i;
    count = n;
    if ((int)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 1;
    count = zT_6;
    goto z_bb_2;
    z_bb_2:
    zT_8 = alloc;
    zT_15 = zF_1395EB68_sandAlloc(zT_8, (unsigned int)((unsigned int)((unsigned int)count) * (unsigned int)(4)), (unsigned int)(4));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_17 = zT_15.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_17;
    zT_20 = (unsigned int*)raw;
    a = zT_20;
    zT_22 = 0;
    i = zT_22;
    goto z_bb_6;
    z_bb_6:
    if ((int)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = (unsigned int)i;
    a[zT_24] = fill;
    goto z_bb_9;
    z_bb_8:
    return a;
    z_bb_9:
    zT_26 = i + (unsigned int)(1);
    i = zT_26;
    goto z_bb_6;
}

/* allocU8Raw */
unsigned char* zF_F15DB413_allocU8Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_9154F007_EU_232 zT_14 = {0};
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned int count;
    unsigned char* raw;
    count = n;
    if ((int)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    count = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = alloc;
    zT_14 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)((unsigned int)((unsigned int)count) * (unsigned int)(1)), (unsigned int)(1));
    zT_15 = zT_14.is_error;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_16 = zT_14.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_16;
    return (unsigned char*)((unsigned char*)raw);
}

/* maxTempOf */
unsigned int zF_005F8966_maxTempOf(zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_2;
    unsigned int zT_4;
    zT_5D72FBF8_TempDeclArrayList zT_5;
    unsigned int zT_6;
    zT_5D72FBF8_TempDeclArrayList zT_9;
    zT_1937645B_TempDecl* zT_10;
    zT_1937645B_TempDecl zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int m;
    unsigned int i;
    zT_1937645B_TempDecl td;
    zT_2 = 0;
    m = zT_2;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = lir_fn->hoisted_temps;
    zT_6 = zT_5.len;
    if ((int)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = lir_fn->hoisted_temps;
    zT_10 = zT_9.items;
    zT_11 = zT_10[i];
    td = zT_11;
    zT_12 = td.temp_id;
    if ((int)(zT_12 >= m)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return m;
    z_bb_4:
    zT_18 = i + (unsigned int)(1);
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = td.temp_id;
    zT_16 = zT_14 + (unsigned int)(1);
    m = zT_16;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* defResultTemp */
unsigned int zF_CFED20F7_defResultTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst) {
    unsigned int zT_2;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_66;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_72;
    unsigned int zT_74;
    unsigned int zT_76;
    unsigned int zT_78;
    unsigned int zT_80;
    unsigned int zT_82;
    unsigned int zT_84;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_BBC23664_LirFunction* zT_91;
    unsigned int zT_92;
    zT_3BFB1E70_CallDirectData zT_94 = {0};
    unsigned int zT_95;
    zT_BBC23664_LirFunction* zT_98;
    unsigned int zT_99;
    zT_0624AC1B_TailCallData zT_101 = {0};
    unsigned int zT_102;
    unsigned int zT_104;
    unsigned int zT_106;
    unsigned int zT_108;
    unsigned int zT_110;
    unsigned int zT_112;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned int zT_118;
    zT_1173487A_anon_68466 b;
    zT_15758D5D_anon_68474 u;
    zT_25052563_anon_68692 ic;
    zT_2F053521_anon_68698 fc;
    zT_93ADBB7F_anon_68704 sc;
    zT_97ADC1CB_anon_68708 nc;
    zT_25AACFBE_anon_68714 sn;
    zT_23A88E01_anon_68720 bc;
    zT_25A89127_anon_68726 uc;
    zT_BE74A0C5_anon_68944 pi;
    zT_23A64F6A_anon_68736 ec;
    zT_B1204544_anon_68648 ic_1;
    zT_4679F40B_anon_68960 ic_2;
    zT_3E77A8DC_anon_68972 ww;
    zT_A9227743_anon_68656 fc_3;
    zT_B924CF0A_anon_68664 pc;
    zT_3D27DD6D_anon_68672 itf;
    zT_A7022072_anon_68686 itp;
    zT_3327CDAF_anon_68678 pti;
    zT_A92038AC_anon_68640 ms;
    zT_F1CCE02C_anon_68532 a;
    zT_85D484ED_anon_68540 a_4;
    zT_73D6A72E_anon_68578 fr;
    zT_7DD47855_anon_68548 w;
    zT_351687B4_anon_68604 w_5;
    zT_3518C64B_anon_68612 w_6;
    zT_01DE427D_anon_68584 u_7;
    zT_BA749A79_anon_68940 u_8;
    zT_F7DBF428_anon_68590 u_9;
    zT_FDDBFD9A_anon_68596 ch;
    zT_2F18BCD9_anon_68618 u_10;
    zT_391B0B2E_anon_68624 u_11;
    zT_A31DF0A3_anon_68630 ch_12;
    zT_F9CF2B5B_anon_68520 l;
    zT_0170F0B3_anon_68494 lf;
    zT_CBE4D2C3_anon_68832 lb;
    zT_6BC7900C_anon_68514 li;
    zT_29B7A1FD_anon_68742 ll;
    zT_23B559F4_anon_68756 lg;
    zT_07824346_anon_68408 a_13;
    zT_0D848B4F_anon_68418 a_14;
    zT_8B7D02E4_anon_68428 a_15;
    zT_036EB542_anon_68484 cl;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    unsigned int slot_16;
    zT_0624AC1B_TailCallData tc;
    zT_6DD8DC53_anon_68564 va;
    zT_13972BB0_anon_68796 bgc;
    zT_5BEC7138_anon_68864 o;
    zT_5DEEB2F5_anon_68878 o_17;
    zT_4BFDA129_anon_68892 o_18;
    zT_4C7E7AAB_anon_68906 o_19;
    zT_447C2F7C_anon_68918 o_20;
    zT_BC816992_anon_68934 o_21;
    zT_2 = inst.tag;
switch (zT_2) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 46: goto z_bb_5;
case 47: goto z_bb_6;
case 48: goto z_bb_7;
case 49: goto z_bb_8;
case 50: goto z_bb_9;
case 79: goto z_bb_10;
case 51: goto z_bb_11;
case 38: goto z_bb_12;
case 80: goto z_bb_13;
case 81: goto z_bb_14;
case 39: goto z_bb_15;
case 40: goto z_bb_16;
case 41: goto z_bb_17;
case 43: goto z_bb_18;
case 42: goto z_bb_19;
case 37: goto z_bb_20;
case 20: goto z_bb_21;
case 21: goto z_bb_22;
case 28: goto z_bb_23;
case 22: goto z_bb_24;
case 32: goto z_bb_25;
case 33: goto z_bb_26;
case 29: goto z_bb_27;
case 78: goto z_bb_28;
case 30: goto z_bb_29;
case 31: goto z_bb_30;
case 34: goto z_bb_31;
case 35: goto z_bb_32;
case 36: goto z_bb_33;
case 18: goto z_bb_34;
case 15: goto z_bb_35;
case 68: goto z_bb_36;
case 17: goto z_bb_37;
case 52: goto z_bb_38;
case 54: goto z_bb_39;
case 2: goto z_bb_40;
case 3: goto z_bb_41;
case 4: goto z_bb_42;
case 14: goto z_bb_43;
case 23: goto z_bb_44;
case 27: goto z_bb_45;
case 25: goto z_bb_46;
case 61: goto z_bb_47;
case 72: goto z_bb_48;
case 73: goto z_bb_49;
case 74: goto z_bb_50;
case 75: goto z_bb_51;
case 76: goto z_bb_52;
case 77: goto z_bb_53;
default: goto z_bb_54;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_4 = b.result;
    return zT_4;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_6 = u.result;
    return zT_6;
    z_bb_3:
    ic = inst.payload.int_const._0;
    zT_8 = ic.result;
    return zT_8;
    z_bb_4:
    fc = inst.payload.float_const._0;
    zT_10 = fc.result;
    return zT_10;
    z_bb_5:
    sc = inst.payload.string_const._0;
    zT_12 = sc.result;
    return zT_12;
    z_bb_6:
    nc = inst.payload.null_const._0;
    zT_14 = nc.result;
    return zT_14;
    z_bb_7:
    sn = inst.payload.set_optional_null._0;
    zT_16 = sn.result;
    return zT_16;
    z_bb_8:
    bc = inst.payload.bool_const._0;
    zT_18 = bc.result;
    return zT_18;
    z_bb_9:
    uc = inst.payload.undefined_const._0;
    zT_20 = uc.result;
    return zT_20;
    z_bb_10:
    pi = inst.payload.poison_init._0;
    zT_22 = pi.result;
    return zT_22;
    z_bb_11:
    ec = inst.payload.enum_const._0;
    zT_24 = ec.result;
    return zT_24;
    z_bb_12:
    ic_1 = inst.payload.int_cast._0;
    zT_26 = ic_1.result;
    return zT_26;
    z_bb_13:
    ic_2 = inst.payload.int_cast_checked._0;
    zT_28 = ic_2.result;
    return zT_28;
    z_bb_14:
    ww = inst.payload.width_wrap._0;
    zT_30 = ww.result;
    return zT_30;
    z_bb_15:
    fc_3 = inst.payload.float_cast._0;
    zT_32 = fc_3.result;
    return zT_32;
    z_bb_16:
    pc = inst.payload.ptr_cast._0;
    zT_34 = pc.result;
    return zT_34;
    z_bb_17:
    itf = inst.payload.int_to_float._0;
    zT_36 = itf.result;
    return zT_36;
    z_bb_18:
    itp = inst.payload.int_to_ptr._0;
    zT_38 = itp.result;
    return zT_38;
    z_bb_19:
    pti = inst.payload.ptr_to_int._0;
    zT_40 = pti.result;
    return zT_40;
    z_bb_20:
    ms = inst.payload.make_slice._0;
    zT_42 = ms.result;
    return zT_42;
    z_bb_21:
    a = inst.payload.addr_of._0;
    zT_44 = a.result;
    return zT_44;
    z_bb_22:
    a_4 = inst.payload.addr_of_field._0;
    zT_46 = a_4.result;
    return zT_46;
    z_bb_23:
    fr = inst.payload.func_ref._0;
    zT_48 = fr.result;
    return zT_48;
    z_bb_24:
    w = inst.payload.wrap_optional._0;
    zT_50 = w.result;
    return zT_50;
    z_bb_25:
    w_5 = inst.payload.wrap_error_ok._0;
    zT_52 = w_5.result;
    return zT_52;
    z_bb_26:
    w_6 = inst.payload.wrap_error_err._0;
    zT_54 = w_6.result;
    return zT_54;
    z_bb_27:
    u_7 = inst.payload.unwrap_optional._0;
    zT_56 = u_7.result;
    return zT_56;
    z_bb_28:
    u_8 = inst.payload.unwrap_optional_checked._0;
    zT_58 = u_8.result;
    return zT_58;
    z_bb_29:
    u_9 = inst.payload.unwrap_optional_abi._0;
    zT_60 = u_9.result;
    return zT_60;
    z_bb_30:
    ch = inst.payload.check_optional._0;
    zT_62 = ch.result;
    return zT_62;
    z_bb_31:
    u_10 = inst.payload.unwrap_error_payload._0;
    zT_64 = u_10.result;
    return zT_64;
    z_bb_32:
    u_11 = inst.payload.unwrap_error_code._0;
    zT_66 = u_11.result;
    return zT_66;
    z_bb_33:
    ch_12 = inst.payload.check_error._0;
    zT_68 = ch_12.result;
    return zT_68;
    z_bb_34:
    l = inst.payload.load._0;
    zT_70 = l.result;
    return zT_70;
    z_bb_35:
    lf = inst.payload.load_field._0;
    zT_72 = lf.result;
    return zT_72;
    z_bb_36:
    lb = inst.payload.load_bitfield._0;
    zT_74 = lb.result;
    return zT_74;
    z_bb_37:
    li = inst.payload.load_index._0;
    zT_76 = li.result;
    return zT_76;
    z_bb_38:
    ll = inst.payload.load_local._0;
    zT_78 = ll.result;
    return zT_78;
    z_bb_39:
    lg = inst.payload.load_global._0;
    zT_80 = lg.result;
    return zT_80;
    z_bb_40:
    a_13 = inst.payload.assign._0;
    zT_82 = a_13.dst;
    return zT_82;
    z_bb_41:
    a_14 = inst.payload.assign_field._0;
    zT_84 = a_14.base;
    return zT_84;
    z_bb_42:
    a_15 = inst.payload.assign_index._0;
    zT_86 = a_15.base;
    return zT_86;
    z_bb_43:
    cl = inst.payload.call._0;
    zT_88 = cl.result;
    return zT_88;
    z_bb_44:
    slot = inst.payload.jump._0;
    zT_91 = c->lir_fn;
    zT_92 = slot;
    zT_94 = zF_75DE985C_lirSideGetCallDirec(zT_91, zT_92);
    cd = zT_94;
    zT_95 = cd.result;
    return zT_95;
    z_bb_45:
    slot_16 = inst.payload.jump._0;
    zT_98 = c->lir_fn;
    zT_99 = slot_16;
    zT_101 = zF_1AB3807F_lirSideGetTailCall(zT_98, zT_99);
    tc = zT_101;
    zT_102 = tc.result;
    return zT_102;
    z_bb_46:
    va = inst.payload.va_arg._0;
    zT_104 = va.result;
    return zT_104;
    z_bb_47:
    bgc = inst.payload.builtin_get_char._0;
    zT_106 = bgc.result;
    return zT_106;
    z_bb_48:
    o = inst.payload.add_with_overflow._0;
    zT_108 = o.result;
    return zT_108;
    z_bb_49:
    o_17 = inst.payload.sub_with_overflow._0;
    zT_110 = o_17.result;
    return zT_110;
    z_bb_50:
    o_18 = inst.payload.mul_with_overflow._0;
    zT_112 = o_18.result;
    return zT_112;
    z_bb_51:
    o_19 = inst.payload.shl_with_overflow._0;
    zT_114 = o_19.result;
    return zT_114;
    z_bb_52:
    o_20 = inst.payload.neg_with_overflow._0;
    zT_116 = o_20.result;
    return zT_116;
    z_bb_53:
    o_21 = inst.payload.overflow_flag._0;
    zT_118 = o_21.result;
    return zT_118;
    z_bb_54:
    return (unsigned int)(4294967295u);
    return 0;
}

/* localStorage */
unsigned int zF_CD424A09_localStorage(zT_6D148508_Scan* c, unsigned int name_id) {
    zT_21D3708C_U32ToU32Map* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    unsigned int t;
    if ((int)(name_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_5 = c->locals;
    zT_6 = name_id;
    zT_8 = zF_F3EE5998_u32ToU32MapGet(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    t = zT_8.value;
    return t;
    z_bb_4:
    return (unsigned int)(4294967295u);
}

/* instDefsTemp */
int zF_1FF90D33_instDefsTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, unsigned int v) {
    zT_6D148508_Scan* zT_3;
    zT_6BA597BC_LirInst zT_4;
    unsigned int zT_5 = 0;
    unsigned int zT_8;
    zT_6D148508_Scan* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    zT_1FB7923F_anon_68748 sl;
    zT_3 = c;
    zT_4 = inst;
    zT_5 = zF_CFED20F7_defResultTemp(zT_3, zT_4);
    if ((int)(zT_5 == v)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_8 = inst.tag;
switch (zT_8) {
case 53: goto z_bb_3;
case 55: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_3:
    sl = inst.payload.store_local._0;
    zT_10 = c;
    zT_11 = sl.name_id;
    zT_13 = zF_CD424A09_localStorage(zT_10, zT_11);
    if ((int)(zT_13 == v)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_7;
    z_bb_5:
    goto z_bb_7;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    return (int)(1);
    z_bb_9:
    goto z_bb_7;
}

/* instReadsTemp */
int zF_E4C3429C_instReadsTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, unsigned int v) {
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_16;
    int zT_18;
    unsigned int zT_19;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_30;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_44;
    unsigned int zT_48;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_55;
    int zT_57;
    unsigned int zT_58;
    unsigned int zT_62;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_69;
    int zT_71;
    unsigned int zT_72;
    unsigned int zT_76;
    unsigned int zT_80;
    int zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    unsigned int zT_90;
    int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_99;
    unsigned int zT_103;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    unsigned int zT_114;
    int zT_116;
    unsigned int zT_117;
    unsigned int zT_121;
    int zT_123;
    unsigned int zT_124;
    unsigned int zT_128;
    unsigned int zT_132;
    int zT_134;
    unsigned int zT_135;
    unsigned int zT_139;
    unsigned int zT_143;
    unsigned int zT_147;
    zT_BBC23664_LirFunction* zT_152;
    unsigned int zT_153;
    zT_3BFB1E70_CallDirectData zT_155 = {0};
    unsigned int zT_156;
    int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_165;
    int zT_167;
    unsigned int zT_168;
    unsigned int zT_172;
    unsigned int zT_176;
    zT_BBC23664_LirFunction* zT_181;
    unsigned int zT_182;
    zT_0624AC1B_TailCallData zT_184 = {0};
    unsigned char zT_185;
    int zT_188;
    unsigned int zT_189;
    unsigned int zT_192;
    int zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned int zT_201;
    unsigned int zT_205;
    unsigned int zT_209;
    unsigned int zT_213;
    unsigned int zT_217;
    unsigned int zT_221;
    unsigned int zT_225;
    unsigned int zT_229;
    unsigned int zT_233;
    unsigned int zT_237;
    int zT_239;
    unsigned int zT_240;
    unsigned int zT_244;
    unsigned int zT_248;
    unsigned int zT_252;
    unsigned int zT_256;
    unsigned int zT_260;
    unsigned int zT_264;
    unsigned int zT_268;
    unsigned int zT_272;
    zT_6D148508_Scan* zT_276;
    unsigned int zT_277;
    unsigned int zT_279 = 0;
    unsigned int zT_283;
    unsigned int zT_287;
    unsigned int zT_291;
    unsigned int zT_295;
    unsigned int zT_299;
    int zT_301;
    unsigned int zT_302;
    unsigned int zT_306;
    int zT_308;
    unsigned int zT_309;
    unsigned int zT_313;
    unsigned int zT_317;
    unsigned int zT_321;
    int zT_323;
    unsigned int zT_324;
    unsigned int zT_328;
    int zT_330;
    unsigned int zT_331;
    unsigned int zT_335;
    zT_07824346_anon_68408 a;
    zT_0D848B4F_anon_68418 a_1;
    zT_8B7D02E4_anon_68428 a_2;
    zT_1180146D_anon_68438 b;
    zT_8F788C02_anon_68448 s;
    unsigned int r;
    zT_1173487A_anon_68466 b_3;
    zT_15758D5D_anon_68474 u;
    zT_5BEC7138_anon_68864 o;
    zT_5DEEB2F5_anon_68878 o_4;
    zT_4BFDA129_anon_68892 o_5;
    zT_4C7E7AAB_anon_68906 o_6;
    zT_447C2F7C_anon_68918 o_7;
    zT_BC816992_anon_68934 o_8;
    zT_036EB542_anon_68484 cl;
    zT_0170F0B3_anon_68494 lf;
    zT_CBE4D2C3_anon_68832 lb;
    zT_F1CAA195_anon_68504 sf;
    zT_C9F19B90_anon_68842 sb;
    zT_6BC7900C_anon_68514 li;
    zT_F9CF2B5B_anon_68520 l;
    zT_FFCF34CD_anon_68526 st;
    zT_F1CCE02C_anon_68532 a_9;
    zT_85D484ED_anon_68540 a_10;
    zT_7DD47855_anon_68548 w;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_FDD1703E_anon_68556 vs;
    zT_6DD8DC53_anon_68564 va;
    zT_79D8EF37_anon_68568 ve;
    unsigned int slot_11;
    zT_0624AC1B_TailCallData tc;
    zT_01DE427D_anon_68584 u_12;
    zT_BA749A79_anon_68940 u_13;
    zT_F7DBF428_anon_68590 u_14;
    zT_FDDBFD9A_anon_68596 ch;
    zT_351687B4_anon_68604 w_15;
    zT_3518C64B_anon_68612 w_16;
    zT_2F18BCD9_anon_68618 u_17;
    zT_391B0B2E_anon_68624 u_18;
    zT_A31DF0A3_anon_68630 ch_19;
    zT_A92038AC_anon_68640 ms;
    zT_B1204544_anon_68648 ic;
    zT_4679F40B_anon_68960 ic_20;
    zT_3E77A8DC_anon_68972 ww;
    zT_A9227743_anon_68656 fc;
    zT_B924CF0A_anon_68664 pc;
    zT_3D27DD6D_anon_68672 itf;
    zT_3327CDAF_anon_68678 pti;
    zT_A7022072_anon_68686 itp;
    zT_29B7A1FD_anon_68742 ll;
    zT_1FB7923F_anon_68748 sl;
    zT_97B23EF9_anon_68764 sg;
    zT_93AFFA16_anon_68776 pv;
    zT_1F997D2B_anon_68780 bpc;
    zT_2599869D_anon_68786 b_21;
    zT_179731FC_anon_68792 b_22;
    zT_D3E71DF2_anon_68800 be;
    zT_CFE717A6_anon_68804 bsm;
    zT_5BEA32A1_anon_68812 bcg;
    zT_51EA22E3_anon_68818 bcc;
    zT_D1F3E6BF_anon_68850 ct;
    zT_3 = inst.tag;
switch (zT_3) {
case 2: goto z_bb_1;
case 3: goto z_bb_2;
case 4: goto z_bb_3;
case 6: goto z_bb_4;
case 7: goto z_bb_5;
case 9: goto z_bb_6;
case 12: goto z_bb_7;
case 13: goto z_bb_8;
case 72: goto z_bb_9;
case 73: goto z_bb_10;
case 74: goto z_bb_11;
case 75: goto z_bb_12;
case 76: goto z_bb_13;
case 77: goto z_bb_14;
case 14: goto z_bb_15;
case 15: goto z_bb_16;
case 68: goto z_bb_17;
case 16: goto z_bb_18;
case 69: goto z_bb_19;
case 17: goto z_bb_20;
case 18: goto z_bb_21;
case 19: goto z_bb_22;
case 20: goto z_bb_23;
case 21: goto z_bb_24;
case 22: goto z_bb_25;
case 23: goto z_bb_26;
case 24: goto z_bb_27;
case 25: goto z_bb_28;
case 26: goto z_bb_29;
case 27: goto z_bb_30;
case 29: goto z_bb_31;
case 78: goto z_bb_32;
case 30: goto z_bb_33;
case 31: goto z_bb_34;
case 32: goto z_bb_35;
case 33: goto z_bb_36;
case 34: goto z_bb_37;
case 35: goto z_bb_38;
case 36: goto z_bb_39;
case 37: goto z_bb_40;
case 38: goto z_bb_41;
case 80: goto z_bb_42;
case 81: goto z_bb_43;
case 39: goto z_bb_44;
case 40: goto z_bb_45;
case 41: goto z_bb_46;
case 42: goto z_bb_47;
case 43: goto z_bb_48;
case 52: goto z_bb_49;
case 53: goto z_bb_50;
case 55: goto z_bb_51;
case 57: goto z_bb_52;
case 58: goto z_bb_53;
case 59: goto z_bb_54;
case 60: goto z_bb_55;
case 62: goto z_bb_56;
case 63: goto z_bb_57;
case 65: goto z_bb_58;
case 66: goto z_bb_59;
case 71: goto z_bb_60;
default: goto z_bb_61;
}
    z_bb_1:
    a = inst.payload.assign._0;
    zT_5 = a.src;
    if ((int)(zT_5 == v)) goto z_bb_64; else goto z_bb_65;
    z_bb_2:
    a_1 = inst.payload.assign_field._0;
    zT_9 = a_1.base;
    if ((int)(zT_9 == v)) goto z_bb_67; else goto z_bb_66;
    z_bb_3:
    a_2 = inst.payload.assign_index._0;
    zT_16 = a_2.base;
    if ((int)(zT_16 == v)) goto z_bb_72; else goto z_bb_71;
    z_bb_4:
    b = inst.payload.branch._0;
    zT_26 = b.cond;
    if ((int)(zT_26 == v)) goto z_bb_79; else goto z_bb_80;
    z_bb_5:
    s = inst.payload.switch_br._0;
    zT_30 = s.cond;
    if ((int)(zT_30 == v)) goto z_bb_81; else goto z_bb_82;
    z_bb_6:
    r = inst.payload.jump._0;
    if ((int)(r == v)) goto z_bb_83; else goto z_bb_84;
    z_bb_7:
    b_3 = inst.payload.binary._0;
    zT_37 = b_3.lhs;
    if ((int)(zT_37 == v)) goto z_bb_86; else goto z_bb_85;
    z_bb_8:
    u = inst.payload.unary._0;
    zT_44 = u.operand;
    if ((int)(zT_44 == v)) goto z_bb_90; else goto z_bb_91;
    z_bb_9:
    o = inst.payload.add_with_overflow._0;
    zT_48 = o.lhs;
    if ((int)(zT_48 == v)) goto z_bb_93; else goto z_bb_92;
    z_bb_10:
    o_4 = inst.payload.sub_with_overflow._0;
    zT_55 = o_4.lhs;
    if ((int)(zT_55 == v)) goto z_bb_98; else goto z_bb_97;
    z_bb_11:
    o_5 = inst.payload.mul_with_overflow._0;
    zT_62 = o_5.lhs;
    if ((int)(zT_62 == v)) goto z_bb_103; else goto z_bb_102;
    z_bb_12:
    o_6 = inst.payload.shl_with_overflow._0;
    zT_69 = o_6.lhs;
    if ((int)(zT_69 == v)) goto z_bb_108; else goto z_bb_107;
    z_bb_13:
    o_7 = inst.payload.neg_with_overflow._0;
    zT_76 = o_7.value;
    if ((int)(zT_76 == v)) goto z_bb_112; else goto z_bb_113;
    z_bb_14:
    o_8 = inst.payload.overflow_flag._0;
    zT_80 = o_8.lhs;
    if ((int)(zT_80 == v)) goto z_bb_115; else goto z_bb_114;
    z_bb_15:
    cl = inst.payload.call._0;
    zT_87 = cl.callee;
    if ((int)(zT_87 == v)) goto z_bb_119; else goto z_bb_120;
    z_bb_16:
    lf = inst.payload.load_field._0;
    zT_99 = lf.base;
    if ((int)(zT_99 == v)) goto z_bb_126; else goto z_bb_127;
    z_bb_17:
    lb = inst.payload.load_bitfield._0;
    zT_103 = lb.base;
    if ((int)(zT_103 == v)) goto z_bb_128; else goto z_bb_129;
    z_bb_18:
    sf = inst.payload.store_field._0;
    zT_107 = sf.base;
    if ((int)(zT_107 == v)) goto z_bb_131; else goto z_bb_130;
    z_bb_19:
    sb = inst.payload.store_bitfield._0;
    zT_114 = sb.base;
    if ((int)(zT_114 == v)) goto z_bb_136; else goto z_bb_135;
    z_bb_20:
    li = inst.payload.load_index._0;
    zT_121 = li.base;
    if ((int)(zT_121 == v)) goto z_bb_141; else goto z_bb_140;
    z_bb_21:
    l = inst.payload.load._0;
    zT_128 = l.ptr;
    if ((int)(zT_128 == v)) goto z_bb_145; else goto z_bb_146;
    z_bb_22:
    st = inst.payload.store._0;
    zT_132 = st.ptr;
    if ((int)(zT_132 == v)) goto z_bb_148; else goto z_bb_147;
    z_bb_23:
    a_9 = inst.payload.addr_of._0;
    zT_139 = a_9.operand;
    if ((int)(zT_139 == v)) goto z_bb_152; else goto z_bb_153;
    z_bb_24:
    a_10 = inst.payload.addr_of_field._0;
    zT_143 = a_10.base;
    if ((int)(zT_143 == v)) goto z_bb_154; else goto z_bb_155;
    z_bb_25:
    w = inst.payload.wrap_optional._0;
    zT_147 = w.value;
    if ((int)(zT_147 == v)) goto z_bb_156; else goto z_bb_157;
    z_bb_26:
    slot = inst.payload.jump._0;
    zT_152 = c->lir_fn;
    zT_153 = slot;
    zT_155 = zF_75DE985C_lirSideGetCallDirec(zT_152, zT_153);
    cd = zT_155;
    zT_156 = cd.args_start;
    if ((int)(v >= zT_156)) goto z_bb_158; else goto z_bb_159;
    z_bb_27:
    vs = inst.payload.va_start._0;
    zT_165 = vs.va_list_temp;
    if ((int)(zT_165 == v)) goto z_bb_164; else goto z_bb_163;
    z_bb_28:
    va = inst.payload.va_arg._0;
    zT_172 = va.va_list_temp;
    if ((int)(zT_172 == v)) goto z_bb_168; else goto z_bb_169;
    z_bb_29:
    ve = inst.payload.va_end._0;
    zT_176 = ve.va_list_temp;
    if ((int)(zT_176 == v)) goto z_bb_170; else goto z_bb_171;
    z_bb_30:
    slot_11 = inst.payload.jump._0;
    zT_181 = c->lir_fn;
    zT_182 = slot_11;
    zT_184 = zF_1AB3807F_lirSideGetTailCall(zT_181, zT_182);
    tc = zT_184;
    zT_185 = tc.is_indirect;
    if ((int)(zT_185 != (unsigned char)(0))) goto z_bb_172; else goto z_bb_173;
    z_bb_31:
    u_12 = inst.payload.unwrap_optional._0;
    zT_201 = u_12.value;
    if ((int)(zT_201 == v)) goto z_bb_182; else goto z_bb_183;
    z_bb_32:
    u_13 = inst.payload.unwrap_optional_checked._0;
    zT_205 = u_13.value;
    if ((int)(zT_205 == v)) goto z_bb_184; else goto z_bb_185;
    z_bb_33:
    u_14 = inst.payload.unwrap_optional_abi._0;
    zT_209 = u_14.value;
    if ((int)(zT_209 == v)) goto z_bb_186; else goto z_bb_187;
    z_bb_34:
    ch = inst.payload.check_optional._0;
    zT_213 = ch.value;
    if ((int)(zT_213 == v)) goto z_bb_188; else goto z_bb_189;
    z_bb_35:
    w_15 = inst.payload.wrap_error_ok._0;
    zT_217 = w_15.value;
    if ((int)(zT_217 == v)) goto z_bb_190; else goto z_bb_191;
    z_bb_36:
    w_16 = inst.payload.wrap_error_err._0;
    zT_221 = w_16.value;
    if ((int)(zT_221 == v)) goto z_bb_192; else goto z_bb_193;
    z_bb_37:
    u_17 = inst.payload.unwrap_error_payload._0;
    zT_225 = u_17.value;
    if ((int)(zT_225 == v)) goto z_bb_194; else goto z_bb_195;
    z_bb_38:
    u_18 = inst.payload.unwrap_error_code._0;
    zT_229 = u_18.value;
    if ((int)(zT_229 == v)) goto z_bb_196; else goto z_bb_197;
    z_bb_39:
    ch_19 = inst.payload.check_error._0;
    zT_233 = ch_19.value;
    if ((int)(zT_233 == v)) goto z_bb_198; else goto z_bb_199;
    z_bb_40:
    ms = inst.payload.make_slice._0;
    zT_237 = ms.ptr;
    if ((int)(zT_237 == v)) goto z_bb_201; else goto z_bb_200;
    z_bb_41:
    ic = inst.payload.int_cast._0;
    zT_244 = ic.value;
    if ((int)(zT_244 == v)) goto z_bb_205; else goto z_bb_206;
    z_bb_42:
    ic_20 = inst.payload.int_cast_checked._0;
    zT_248 = ic_20.value;
    if ((int)(zT_248 == v)) goto z_bb_207; else goto z_bb_208;
    z_bb_43:
    ww = inst.payload.width_wrap._0;
    zT_252 = ww.value;
    if ((int)(zT_252 == v)) goto z_bb_209; else goto z_bb_210;
    z_bb_44:
    fc = inst.payload.float_cast._0;
    zT_256 = fc.value;
    if ((int)(zT_256 == v)) goto z_bb_211; else goto z_bb_212;
    z_bb_45:
    pc = inst.payload.ptr_cast._0;
    zT_260 = pc.value;
    if ((int)(zT_260 == v)) goto z_bb_213; else goto z_bb_214;
    z_bb_46:
    itf = inst.payload.int_to_float._0;
    zT_264 = itf.value;
    if ((int)(zT_264 == v)) goto z_bb_215; else goto z_bb_216;
    z_bb_47:
    pti = inst.payload.ptr_to_int._0;
    zT_268 = pti.value;
    if ((int)(zT_268 == v)) goto z_bb_217; else goto z_bb_218;
    z_bb_48:
    itp = inst.payload.int_to_ptr._0;
    zT_272 = itp.value;
    if ((int)(zT_272 == v)) goto z_bb_219; else goto z_bb_220;
    z_bb_49:
    ll = inst.payload.load_local._0;
    zT_276 = c;
    zT_277 = ll.name_id;
    zT_279 = zF_CD424A09_localStorage(zT_276, zT_277);
    if ((int)(zT_279 == v)) goto z_bb_221; else goto z_bb_222;
    z_bb_50:
    sl = inst.payload.store_local._0;
    zT_283 = sl.value;
    if ((int)(zT_283 == v)) goto z_bb_223; else goto z_bb_224;
    z_bb_51:
    sg = inst.payload.store_global._0;
    zT_287 = sg.value;
    if ((int)(zT_287 == v)) goto z_bb_225; else goto z_bb_226;
    z_bb_52:
    pv = inst.payload.print_val._0;
    zT_291 = pv.value;
    if ((int)(zT_291 == v)) goto z_bb_227; else goto z_bb_228;
    z_bb_53:
    bpc = inst.payload.builtin_put_char._0;
    zT_295 = bpc.value;
    if ((int)(zT_295 == v)) goto z_bb_229; else goto z_bb_230;
    z_bb_54:
    b_21 = inst.payload.builtin_stdout_write._0;
    zT_299 = b_21.ptr;
    if ((int)(zT_299 == v)) goto z_bb_232; else goto z_bb_231;
    z_bb_55:
    b_22 = inst.payload.builtin_stderr_write._0;
    zT_306 = b_22.ptr;
    if ((int)(zT_306 == v)) goto z_bb_237; else goto z_bb_236;
    z_bb_56:
    be = inst.payload.builtin_exit._0;
    zT_313 = be.value;
    if ((int)(zT_313 == v)) goto z_bb_241; else goto z_bb_242;
    z_bb_57:
    bsm = inst.payload.builtin_sleep_ms._0;
    zT_317 = bsm.value;
    if ((int)(zT_317 == v)) goto z_bb_243; else goto z_bb_244;
    z_bb_58:
    bcg = inst.payload.builtin_console_gotoxy._0;
    zT_321 = bcg.x;
    if ((int)(zT_321 == v)) goto z_bb_246; else goto z_bb_245;
    z_bb_59:
    bcc = inst.payload.builtin_console_set_color._0;
    zT_328 = bcc.fg;
    if ((int)(zT_328 == v)) goto z_bb_251; else goto z_bb_250;
    z_bb_60:
    ct = inst.payload.check_trap._0;
    zT_335 = ct.cond;
    if ((int)(zT_335 == v)) goto z_bb_255; else goto z_bb_256;
    z_bb_61:
    goto z_bb_63;
    z_bb_63:
    return (int)(0);
    z_bb_64:
    return (int)(1);
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    zT_12 = a_1.src;
    zT_11 = zT_12 == v;
    goto z_bb_68;
    z_bb_67:
    zT_11 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_11) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    return (int)(1);
    z_bb_70:
    goto z_bb_63;
    z_bb_71:
    zT_19 = a_2.index;
    zT_18 = zT_19 == v;
    goto z_bb_73;
    z_bb_72:
    zT_18 = 1;
    goto z_bb_73;
    z_bb_73:
    if (zT_18) goto z_bb_75; else goto z_bb_74;
    z_bb_74:
    zT_22 = a_2.src;
    zT_21 = zT_22 == v;
    goto z_bb_76;
    z_bb_75:
    zT_21 = 1;
    goto z_bb_76;
    z_bb_76:
    if (zT_21) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    return (int)(1);
    z_bb_78:
    goto z_bb_63;
    z_bb_79:
    return (int)(1);
    z_bb_80:
    goto z_bb_63;
    z_bb_81:
    return (int)(1);
    z_bb_82:
    goto z_bb_63;
    z_bb_83:
    return (int)(1);
    z_bb_84:
    goto z_bb_63;
    z_bb_85:
    zT_40 = b_3.rhs;
    zT_39 = zT_40 == v;
    goto z_bb_87;
    z_bb_86:
    zT_39 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_39) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    return (int)(1);
    z_bb_89:
    goto z_bb_63;
    z_bb_90:
    return (int)(1);
    z_bb_91:
    goto z_bb_63;
    z_bb_92:
    zT_51 = o.rhs;
    zT_50 = zT_51 == v;
    goto z_bb_94;
    z_bb_93:
    zT_50 = 1;
    goto z_bb_94;
    z_bb_94:
    if (zT_50) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    return (int)(1);
    z_bb_96:
    goto z_bb_63;
    z_bb_97:
    zT_58 = o_4.rhs;
    zT_57 = zT_58 == v;
    goto z_bb_99;
    z_bb_98:
    zT_57 = 1;
    goto z_bb_99;
    z_bb_99:
    if (zT_57) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    return (int)(1);
    z_bb_101:
    goto z_bb_63;
    z_bb_102:
    zT_65 = o_5.rhs;
    zT_64 = zT_65 == v;
    goto z_bb_104;
    z_bb_103:
    zT_64 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_64) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    return (int)(1);
    z_bb_106:
    goto z_bb_63;
    z_bb_107:
    zT_72 = o_6.rhs;
    zT_71 = zT_72 == v;
    goto z_bb_109;
    z_bb_108:
    zT_71 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_71) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    return (int)(1);
    z_bb_111:
    goto z_bb_63;
    z_bb_112:
    return (int)(1);
    z_bb_113:
    goto z_bb_63;
    z_bb_114:
    zT_83 = o_8.rhs;
    zT_82 = zT_83 == v;
    goto z_bb_116;
    z_bb_115:
    zT_82 = 1;
    goto z_bb_116;
    z_bb_116:
    if (zT_82) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    return (int)(1);
    z_bb_118:
    goto z_bb_63;
    z_bb_119:
    return (int)(1);
    z_bb_120:
    zT_90 = cl.args_start;
    if ((int)(v >= zT_90)) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_93 = cl.args_start;
    zT_94 = cl.args_count;
    zT_92 = v < (unsigned int)(zT_93 + zT_94);
    goto z_bb_123;
    z_bb_122:
    zT_92 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_92) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    return (int)(1);
    z_bb_125:
    goto z_bb_63;
    z_bb_126:
    return (int)(1);
    z_bb_127:
    goto z_bb_63;
    z_bb_128:
    return (int)(1);
    z_bb_129:
    goto z_bb_63;
    z_bb_130:
    zT_110 = sf.value;
    zT_109 = zT_110 == v;
    goto z_bb_132;
    z_bb_131:
    zT_109 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_109) goto z_bb_133; else goto z_bb_134;
    z_bb_133:
    return (int)(1);
    z_bb_134:
    goto z_bb_63;
    z_bb_135:
    zT_117 = sb.value;
    zT_116 = zT_117 == v;
    goto z_bb_137;
    z_bb_136:
    zT_116 = 1;
    goto z_bb_137;
    z_bb_137:
    if (zT_116) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    return (int)(1);
    z_bb_139:
    goto z_bb_63;
    z_bb_140:
    zT_124 = li.index;
    zT_123 = zT_124 == v;
    goto z_bb_142;
    z_bb_141:
    zT_123 = 1;
    goto z_bb_142;
    z_bb_142:
    if (zT_123) goto z_bb_143; else goto z_bb_144;
    z_bb_143:
    return (int)(1);
    z_bb_144:
    goto z_bb_63;
    z_bb_145:
    return (int)(1);
    z_bb_146:
    goto z_bb_63;
    z_bb_147:
    zT_135 = st.value;
    zT_134 = zT_135 == v;
    goto z_bb_149;
    z_bb_148:
    zT_134 = 1;
    goto z_bb_149;
    z_bb_149:
    if (zT_134) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    return (int)(1);
    z_bb_151:
    goto z_bb_63;
    z_bb_152:
    return (int)(1);
    z_bb_153:
    goto z_bb_63;
    z_bb_154:
    return (int)(1);
    z_bb_155:
    goto z_bb_63;
    z_bb_156:
    return (int)(1);
    z_bb_157:
    goto z_bb_63;
    z_bb_158:
    zT_159 = cd.args_start;
    zT_160 = cd.args_count;
    zT_158 = v < (unsigned int)(zT_159 + zT_160);
    goto z_bb_160;
    z_bb_159:
    zT_158 = 0;
    goto z_bb_160;
    z_bb_160:
    if (zT_158) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    return (int)(1);
    z_bb_162:
    goto z_bb_63;
    z_bb_163:
    zT_168 = vs.last_param_temp;
    zT_167 = zT_168 == v;
    goto z_bb_165;
    z_bb_164:
    zT_167 = 1;
    goto z_bb_165;
    z_bb_165:
    if (zT_167) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    return (int)(1);
    z_bb_167:
    goto z_bb_63;
    z_bb_168:
    return (int)(1);
    z_bb_169:
    goto z_bb_63;
    z_bb_170:
    return (int)(1);
    z_bb_171:
    goto z_bb_63;
    z_bb_172:
    zT_189 = tc.callee;
    zT_188 = zT_189 == v;
    goto z_bb_174;
    z_bb_173:
    zT_188 = 0;
    goto z_bb_174;
    z_bb_174:
    if (zT_188) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    return (int)(1);
    z_bb_176:
    zT_192 = tc.args_start;
    if ((int)(v >= zT_192)) goto z_bb_177; else goto z_bb_178;
    z_bb_177:
    zT_195 = tc.args_start;
    zT_196 = tc.args_count;
    zT_194 = v < (unsigned int)(zT_195 + zT_196);
    goto z_bb_179;
    z_bb_178:
    zT_194 = 0;
    goto z_bb_179;
    z_bb_179:
    if (zT_194) goto z_bb_180; else goto z_bb_181;
    z_bb_180:
    return (int)(1);
    z_bb_181:
    goto z_bb_63;
    z_bb_182:
    return (int)(1);
    z_bb_183:
    goto z_bb_63;
    z_bb_184:
    return (int)(1);
    z_bb_185:
    goto z_bb_63;
    z_bb_186:
    return (int)(1);
    z_bb_187:
    goto z_bb_63;
    z_bb_188:
    return (int)(1);
    z_bb_189:
    goto z_bb_63;
    z_bb_190:
    return (int)(1);
    z_bb_191:
    goto z_bb_63;
    z_bb_192:
    return (int)(1);
    z_bb_193:
    goto z_bb_63;
    z_bb_194:
    return (int)(1);
    z_bb_195:
    goto z_bb_63;
    z_bb_196:
    return (int)(1);
    z_bb_197:
    goto z_bb_63;
    z_bb_198:
    return (int)(1);
    z_bb_199:
    goto z_bb_63;
    z_bb_200:
    zT_240 = ms.len;
    zT_239 = zT_240 == v;
    goto z_bb_202;
    z_bb_201:
    zT_239 = 1;
    goto z_bb_202;
    z_bb_202:
    if (zT_239) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    return (int)(1);
    z_bb_204:
    goto z_bb_63;
    z_bb_205:
    return (int)(1);
    z_bb_206:
    goto z_bb_63;
    z_bb_207:
    return (int)(1);
    z_bb_208:
    goto z_bb_63;
    z_bb_209:
    return (int)(1);
    z_bb_210:
    goto z_bb_63;
    z_bb_211:
    return (int)(1);
    z_bb_212:
    goto z_bb_63;
    z_bb_213:
    return (int)(1);
    z_bb_214:
    goto z_bb_63;
    z_bb_215:
    return (int)(1);
    z_bb_216:
    goto z_bb_63;
    z_bb_217:
    return (int)(1);
    z_bb_218:
    goto z_bb_63;
    z_bb_219:
    return (int)(1);
    z_bb_220:
    goto z_bb_63;
    z_bb_221:
    return (int)(1);
    z_bb_222:
    goto z_bb_63;
    z_bb_223:
    return (int)(1);
    z_bb_224:
    goto z_bb_63;
    z_bb_225:
    return (int)(1);
    z_bb_226:
    goto z_bb_63;
    z_bb_227:
    return (int)(1);
    z_bb_228:
    goto z_bb_63;
    z_bb_229:
    return (int)(1);
    z_bb_230:
    goto z_bb_63;
    z_bb_231:
    zT_302 = b_21.len;
    zT_301 = zT_302 == v;
    goto z_bb_233;
    z_bb_232:
    zT_301 = 1;
    goto z_bb_233;
    z_bb_233:
    if (zT_301) goto z_bb_234; else goto z_bb_235;
    z_bb_234:
    return (int)(1);
    z_bb_235:
    goto z_bb_63;
    z_bb_236:
    zT_309 = b_22.len;
    zT_308 = zT_309 == v;
    goto z_bb_238;
    z_bb_237:
    zT_308 = 1;
    goto z_bb_238;
    z_bb_238:
    if (zT_308) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    return (int)(1);
    z_bb_240:
    goto z_bb_63;
    z_bb_241:
    return (int)(1);
    z_bb_242:
    goto z_bb_63;
    z_bb_243:
    return (int)(1);
    z_bb_244:
    goto z_bb_63;
    z_bb_245:
    zT_324 = bcg.y;
    zT_323 = zT_324 == v;
    goto z_bb_247;
    z_bb_246:
    zT_323 = 1;
    goto z_bb_247;
    z_bb_247:
    if (zT_323) goto z_bb_248; else goto z_bb_249;
    z_bb_248:
    return (int)(1);
    z_bb_249:
    goto z_bb_63;
    z_bb_250:
    zT_331 = bcc.bg;
    zT_330 = zT_331 == v;
    goto z_bb_252;
    z_bb_251:
    zT_330 = 1;
    goto z_bb_252;
    z_bb_252:
    if (zT_330) goto z_bb_253; else goto z_bb_254;
    z_bb_253:
    return (int)(1);
    z_bb_254:
    goto z_bb_63;
    z_bb_255:
    return (int)(1);
    z_bb_256:
    goto z_bb_63;
}

/* typeIsPtrVoid */
int zF_5049D2D3_typeIsPtrVoid(zT_338B7C76_TypeRegistry* reg, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_112BF819_PtrPayload* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_112BF819_PtrPayload zT_20;
    unsigned int zT_21;
    zT_D155D06D_Type t;
    unsigned int base;
    zT_3 = reg->types_len;
    if ((int)((unsigned int)((unsigned int)tid) >= zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(0);
    z_bb_2:
    zT_7 = reg->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    t = zT_9;
    zT_10 = t.kind;
    if ((int)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_17 = reg->ptr_items;
    zT_18 = t.payload_idx;
    zT_19 = (unsigned int)zT_18;
    zT_20 = zT_17[zT_19];
    zT_21 = zT_20.base;
    base = zT_21;
    return (int)(base == (unsigned int)(1));
}

/* instIsSuspendPoint */
int zF_1AAC25A7_instIsSuspendPoint(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned int zT_3;
    zT_BBC23664_LirFunction* zT_6;
    unsigned int zT_7;
    zT_3BFB1E70_CallDirectData zT_9 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_15 = 0;
    zT_79FAE712_u64 zT_17;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_32 = 0;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_25052563_anon_68692 ic;
    zT_3 = inst.tag;
switch (zT_3) {
case 23: goto z_bb_1;
case 44: goto z_bb_2;
default: goto z_bb_3;
}
    z_bb_1:
    slot = inst.payload.jump._0;
    zT_6 = c->lir_fn;
    zT_7 = slot;
    zT_9 = zF_75DE985C_lirSideGetCallDirec(zT_6, zT_7);
    cd = zT_9;
    zT_10 = suspending_fns;
    zT_11 = cd.module_id;
    zT_12 = cd.name_id;
    zT_15 = zF_7C7E43BF_asyncIsSuspending(zT_10, zT_11, zT_12);
    return zT_15;
    z_bb_2:
    ic = inst.payload.int_const._0;
    zT_17 = ic.value;
    if ((int)(zT_17 != (zT_79FAE712_u64)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    return (int)(0);
    return 0;
    z_bb_6:
    return (int)(0);
    z_bb_7:
    zT_21 = ic.result;
    zT_22 = c->max_temp;
    if ((int)(zT_21 >= zT_22)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (int)(0);
    z_bb_9:
    zT_25 = c->reg;
    zT_28 = c->ttype;
    zT_29 = ic.result;
    zT_30 = (unsigned int)zT_29;
    zT_26 = zT_28[zT_30];
    zT_32 = zF_5049D2D3_typeIsPtrVoid(zT_25, zT_26);
    return zT_32;
}

/* hasDefBefore */
int zF_93E9604D_hasDefBefore(zT_6D148508_Scan* c, unsigned int v, unsigned int sbb, unsigned int sii) {
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_7;
    unsigned int zT_8;
    zT_BBC23664_LirFunction* zT_13;
    zT_1CF28CA3_BasicBlockArrayList zT_14;
    zT_88A68B1A_BasicBlock* zT_15;
    zT_88A68B1A_BasicBlock* zT_16;
    unsigned int zT_18;
    zT_DAE4631D_LirInstArrayList zT_19;
    unsigned int zT_20;
    int zT_24;
    zT_6D148508_Scan* zT_27;
    zT_6BA597BC_LirInst zT_28;
    unsigned int zT_29;
    zT_DAE4631D_LirInstArrayList zT_30;
    zT_6BA597BC_LirInst* zT_31;
    zT_6BA597BC_LirInst zT_32;
    int zT_33 = 0;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_5 = 0;
    bi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = c->lir_fn;
    zT_7 = zT_6->blocks;
    zT_8 = zT_7.len;
    if ((int)(bi < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    if ((int)((unsigned int)((unsigned int)bi) > sbb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_38 = bi + (unsigned int)(1);
    bi = zT_38;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    zT_13 = c->lir_fn;
    zT_14 = zT_13->blocks;
    zT_15 = zT_14.items;
    zT_16 = zT_15 + bi;
    bb = zT_16;
    zT_18 = 0;
    ii = zT_18;
    goto z_bb_7;
    z_bb_7:
    zT_19 = bb->insts;
    zT_20 = zT_19.len;
    if ((int)(ii < zT_20)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    if ((int)((unsigned int)((unsigned int)bi) == sbb)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_36 = ii + (unsigned int)(1);
    ii = zT_36;
    goto z_bb_7;
    z_bb_11:
    zT_24 = (unsigned int)((unsigned int)ii) >= sii;
    goto z_bb_13;
    z_bb_12:
    zT_24 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_24) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_27 = c;
    zT_30 = bb->insts;
    zT_31 = zT_30.items;
    zT_32 = zT_31[ii];
    zT_28 = zT_32;
    zT_29 = v;
    zT_33 = zF_1FF90D33_instDefsTemp(zT_27, zT_28, zT_29);
    if (zT_33) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return (int)(1);
    z_bb_17:
    goto z_bb_10;
}

/* hasReadAfter */
int zF_4CED5DFF_hasReadAfter(zT_6D148508_Scan* c, unsigned int v, unsigned int sbb, unsigned int sii) {
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_7;
    unsigned int zT_8;
    zT_BBC23664_LirFunction* zT_11;
    zT_1CF28CA3_BasicBlockArrayList zT_12;
    zT_88A68B1A_BasicBlock* zT_13;
    zT_88A68B1A_BasicBlock* zT_14;
    unsigned int zT_16;
    unsigned int zT_21;
    zT_DAE4631D_LirInstArrayList zT_22;
    unsigned int zT_23;
    zT_6D148508_Scan* zT_25;
    zT_6BA597BC_LirInst zT_26;
    unsigned int zT_27;
    zT_DAE4631D_LirInstArrayList zT_28;
    zT_6BA597BC_LirInst* zT_29;
    zT_6BA597BC_LirInst zT_30;
    int zT_31 = 0;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_5 = (unsigned int)sbb;
    bi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = c->lir_fn;
    zT_7 = zT_6->blocks;
    zT_8 = zT_7.len;
    if ((int)(bi < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = c->lir_fn;
    zT_12 = zT_11->blocks;
    zT_13 = zT_12.items;
    zT_14 = zT_13 + bi;
    bb = zT_14;
    zT_16 = 0;
    ii = zT_16;
    if ((int)((unsigned int)((unsigned int)bi) == sbb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_36 = bi + (unsigned int)(1);
    bi = zT_36;
    goto z_bb_1;
    z_bb_5:
    zT_21 = (unsigned int)((unsigned int)sii) + (unsigned int)(1);
    ii = zT_21;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_7;
    z_bb_7:
    zT_22 = bb->insts;
    zT_23 = zT_22.len;
    if ((int)(ii < zT_23)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = c;
    zT_28 = bb->insts;
    zT_29 = zT_28.items;
    zT_30 = zT_29[ii];
    zT_26 = zT_30;
    zT_27 = v;
    zT_31 = zF_E4C3429C_instReadsTemp(zT_25, zT_26, zT_27);
    if (zT_31) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_34 = ii + (unsigned int)(1);
    ii = zT_34;
    goto z_bb_7;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    goto z_bb_10;
}

/* alignUpU32 */
unsigned int zF_978D7C93_alignUpU32_1(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* typeSizeAlign */
void zF_A2A36191_typeSizeAlign(zT_338B7C76_TypeRegistry* reg, unsigned int tid, unsigned int* out_size, unsigned int* out_align) {
    unsigned int zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    zT_D155D06D_Type* zT_12;
    unsigned int zT_13;
    zT_D155D06D_Type zT_14;
    unsigned int zT_15;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_22;
    unsigned int sz;
    unsigned int al;
    zT_D155D06D_Type t;
    zT_5 = 4;
    sz = zT_5;
    zT_7 = 4;
    al = zT_7;
    zT_9 = reg->types_len;
    if ((int)((unsigned int)((unsigned int)tid) < zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = reg->types_items;
    zT_13 = (unsigned int)tid;
    zT_14 = zT_12[zT_13];
    t = zT_14;
    zT_15 = t.size;
    if ((int)(zT_15 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    *out_size = sz;
    *out_align = al;
    return;
    z_bb_3:
    zT_18 = t.size;
    sz = zT_18;
    goto z_bb_4;
    z_bb_4:
    zT_19 = t.alignment;
    if ((int)(zT_19 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_22 = t.alignment;
    al = zT_22;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_2;
}

/* addField */
void zF_F2801F08_addField(zT_2CF63CE1_AsyncFrameFieldArra* fields, zT_338B7C76_TypeRegistry* reg, unsigned char kind, unsigned int name_id, unsigned int temp_id, unsigned int type_id, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_9;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int* zT_14;
    unsigned int* zT_15;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_21 = 0;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_22;
    zT_902E38E8_AsyncFrameField zT_23;
    zT_902E38E8_AsyncFrameField zT_24;
    unsigned int zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int size;
    unsigned int alignment;
    zT_9 = 0;
    size = zT_9;
    zT_11 = 0;
    alignment = zT_11;
    zT_12 = reg;
    zT_13 = type_id;
    zT_14 = &size;
    zT_15 = &alignment;
    zF_A2A36191_typeSizeAlign(zT_12, zT_13, zT_14, zT_15);
    zT_18 = *offset;
    zT_19 = alignment;
    zT_21 = zF_978D7C93_alignUpU32_1(zT_18, zT_19);
    *offset = zT_21;
    zT_22 = fields;
    zT_24.kind = kind;
    zT_24.name_id = name_id;
    zT_24.temp_id = temp_id;
    zT_24.type_id = type_id;
    zT_25 = *offset;
    zT_24.offset = zT_25;
    zT_24.size = size;
    zT_24.alignment = alignment;
    zT_23 = zT_24;
    zF_92FA7DBC_fieldArrayListAppen(zT_22, zT_23);
    zT_26 = *offset;
    *offset = (unsigned int)(zT_26 + size);
    zT_28 = *max_align;
    if ((int)(alignment > zT_28)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    *max_align = alignment;
    goto z_bb_2;
    z_bb_2:
    return;
}

/* emitLayoutMarker */
void zF_2B302EFE_emitLayoutMarker(unsigned int module_id, unsigned int name_id, unsigned int size) {
    char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_5826BFC7_Arr_unsigned_char_1 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned char* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_5826BFC7_Arr_unsigned_char_1 zT_38;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char* zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    zT_5826BFC7_Arr_unsigned_char_1 zT_67;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    int zT_73;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77 = 0;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_4 = "LAYOUT:m";
    zT_6 = 8;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    m1 = zT_5;
    zT_7 = m1;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = module_id;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)b1) + zT_15;
    zT_17 = (unsigned int)(12) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    l1 = zT_19;
    zT_24 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_24;
    zT_29 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_30 = (unsigned int)(11) - s1;
    zT_31.ptr = zT_29;
    zT_31.len = zT_30;
    zT_25 = zT_31;
    zF_48AC7B3A_markerWrite(zT_25);
    zT_33 = ":n";
    zT_35 = 2;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    m2 = zT_34;
    zT_36 = m2;
    zF_48AC7B3A_markerWrite(zT_36);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_38[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_38[_i];
        _i++;
    }
}
    zT_40 = name_id;
    zT_44 = 0;
    zT_45 = (unsigned char*)((unsigned char*)b2) + zT_44;
    zT_46 = (unsigned int)(12) - zT_44;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_41 = zT_47;
    zT_48 = zF_A7504564_itoa(zT_40, zT_41);
    l2 = zT_48;
    zT_53 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_53;
    zT_58 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_59 = (unsigned int)(11) - s2;
    zT_60.ptr = zT_58;
    zT_60.len = zT_59;
    zT_54 = zT_60;
    zF_48AC7B3A_markerWrite(zT_54);
    zT_62 = ":s";
    zT_64 = 2;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    m3 = zT_63;
    zT_65 = m3;
    zF_48AC7B3A_markerWrite(zT_65);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_67[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_67[_i];
        _i++;
    }
}
    zT_69 = size;
    zT_73 = 0;
    zT_74 = (unsigned char*)((unsigned char*)b3) + zT_73;
    zT_75 = (unsigned int)(12) - zT_73;
    zT_76.ptr = zT_74;
    zT_76.len = zT_75;
    zT_70 = zT_76;
    zT_77 = zF_A7504564_itoa(zT_69, zT_70);
    l3 = zT_77;
    zT_82 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l3));
    s3 = zT_82;
    zT_87 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_88 = (unsigned int)(11) - s3;
    zT_89.ptr = zT_87;
    zT_89.len = zT_88;
    zT_83 = zT_89;
    zF_48AC7B3A_markerWrite(zT_83);
    zT_91 = "\n";
    zT_93 = 1;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    m4 = zT_92;
    zT_94 = m4;
    zF_48AC7B3A_markerWrite(zT_94);
    return;
}

/* asyncLayoutFrame */
zT_3F3BF87A_AsyncFrameLayout zF_28031796_asyncLayoutFrame(zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg, zT_BBC23664_LirFunction* lir_fn, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    zT_BBC23664_LirFunction* zT_11;
    unsigned int zT_12 = 0;
    zT_3E40CD83_Sand* zT_14;
    zT_CFE23D0A_LirParamArrayList zT_16;
    unsigned int zT_17;
    zT_5D72FBF8_TempDeclArrayList zT_18;
    unsigned int zT_19;
    zT_2CF63CE1_AsyncFrameFieldArra zT_23 = {0};
    zT_3E40CD83_Sand* zT_25;
    zT_21D3708C_U32ToU32Map zT_26 = {0};
    zT_6D148508_Scan zT_28;
    zT_3E40CD83_Sand* zT_29;
    unsigned int zT_30;
    unsigned int* zT_33 = 0;
    zT_21D3708C_U32ToU32Map* zT_34;
    unsigned int zT_36;
    zT_5D72FBF8_TempDeclArrayList zT_37;
    unsigned int zT_38;
    zT_5D72FBF8_TempDeclArrayList zT_41;
    zT_1937645B_TempDecl* zT_42;
    zT_1937645B_TempDecl zT_43;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int* zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    unsigned int zT_51;
    unsigned int zT_53;
    zT_CFE23D0A_LirParamArrayList zT_54;
    unsigned int zT_55;
    zT_CFE23D0A_LirParamArrayList zT_58;
    zT_8779209D_LirParam* zT_59;
    zT_8779209D_LirParam zT_60;
    zT_21D3708C_U32ToU32Map* zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_68;
    unsigned int zT_70;
    zT_1CF28CA3_BasicBlockArrayList zT_71;
    unsigned int zT_72;
    zT_1CF28CA3_BasicBlockArrayList zT_75;
    zT_88A68B1A_BasicBlock* zT_76;
    zT_88A68B1A_BasicBlock* zT_77;
    unsigned int zT_79;
    zT_DAE4631D_LirInstArrayList zT_80;
    unsigned int zT_81;
    zT_DAE4631D_LirInstArrayList zT_83;
    zT_6BA597BC_LirInst* zT_84;
    zT_6BA597BC_LirInst zT_85;
    unsigned int zT_86;
    zT_21D3708C_U32ToU32Map* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    unsigned int zT_95;
    unsigned int zT_97;
    zT_3E40CD83_Sand* zT_99;
    unsigned int zT_100;
    unsigned char* zT_101 = 0;
    unsigned int zT_102;
    zT_CFE23D0A_LirParamArrayList zT_103;
    unsigned int zT_104;
    zT_CFE23D0A_LirParamArrayList zT_107;
    zT_8779209D_LirParam* zT_108;
    zT_8779209D_LirParam zT_109;
    unsigned int zT_110;
    unsigned char zT_112;
    unsigned int zT_113;
    unsigned int zT_115;
    zT_3E40CD83_Sand* zT_117;
    unsigned int zT_118;
    unsigned char* zT_119 = 0;
    unsigned int zT_121;
    unsigned char zT_123;
    unsigned int zT_124;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_1CF28CA3_BasicBlockArrayList zT_128;
    unsigned int zT_129;
    zT_1CF28CA3_BasicBlockArrayList zT_132;
    zT_88A68B1A_BasicBlock* zT_133;
    zT_88A68B1A_BasicBlock* zT_134;
    unsigned int zT_136;
    zT_DAE4631D_LirInstArrayList zT_137;
    unsigned int zT_138;
    zT_DAE4631D_LirInstArrayList zT_141;
    zT_6BA597BC_LirInst* zT_142;
    zT_6BA597BC_LirInst zT_143;
    zT_6D148508_Scan* zT_144;
    zT_6BA597BC_LirInst zT_145;
    zT_A4CE86B7_U64ToU32Map* zT_146;
    int zT_148 = 0;
    unsigned int zT_149;
    unsigned int zT_152;
    unsigned char zT_153;
    zT_6D148508_Scan* zT_156;
    unsigned int zT_157;
    int zT_163 = 0;
    zT_6D148508_Scan* zT_165;
    unsigned int zT_166;
    int zT_172 = 0;
    unsigned char zT_173;
    unsigned int zT_175;
    unsigned int zT_177;
    unsigned int zT_179;
    unsigned int zT_181;
    unsigned int zT_183;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_184;
    zT_338B7C76_TypeRegistry* zT_185;
    unsigned char zT_186;
    unsigned int* zT_190;
    unsigned int* zT_191;
    unsigned int zT_193;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_199;
    zT_338B7C76_TypeRegistry* zT_200;
    unsigned char zT_201;
    unsigned int* zT_205;
    unsigned int* zT_206;
    unsigned int zT_208;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_214;
    zT_338B7C76_TypeRegistry* zT_215;
    unsigned char zT_216;
    unsigned int* zT_220;
    unsigned int* zT_221;
    unsigned int zT_223;
    unsigned int zT_229;
    zT_CFE23D0A_LirParamArrayList zT_230;
    unsigned int zT_231;
    zT_CFE23D0A_LirParamArrayList zT_234;
    zT_8779209D_LirParam* zT_235;
    zT_8779209D_LirParam zT_236;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_237;
    zT_338B7C76_TypeRegistry* zT_238;
    unsigned char zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    unsigned int* zT_243;
    unsigned int* zT_244;
    unsigned int zT_246;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_257;
    unsigned char zT_258;
    int zT_261;
    unsigned char zT_262;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_265;
    zT_338B7C76_TypeRegistry* zT_266;
    unsigned char zT_267;
    unsigned int zT_269;
    unsigned int zT_270;
    unsigned int* zT_271;
    unsigned int* zT_272;
    unsigned int zT_274;
    unsigned int* zT_276;
    unsigned int zT_281;
    unsigned int zT_283;
    unsigned int zT_285;
    unsigned int zT_286;
    zT_79FAE712_u64 zT_289 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_290;
    zT_79FAE712_u64 zT_291;
    zT_BAEE192E_Opt_10 zT_292 = {0};
    unsigned char zT_293;
    zT_338B7C76_TypeRegistry* zT_296;
    unsigned int zT_301 = 0;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_306;
    zT_338B7C76_TypeRegistry* zT_307;
    unsigned char zT_308;
    unsigned int zT_311;
    unsigned int* zT_312;
    unsigned int* zT_313;
    unsigned int zT_315;
    zT_A4CE86B7_U64ToU32Map* zT_320;
    zT_79FAE712_u64 zT_321;
    zT_BAEE192E_Opt_10 zT_322 = {0};
    unsigned char zT_323;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_324;
    zT_338B7C76_TypeRegistry* zT_325;
    unsigned char zT_326;
    unsigned int zT_329;
    unsigned int* zT_330;
    unsigned int* zT_331;
    unsigned int zT_333;
    unsigned int zT_343;
    zT_A4CE86B7_U64ToU32Map* zT_344;
    zT_79FAE712_u64 zT_345;
    zT_BAEE192E_Opt_10 zT_346 = {0};
    unsigned char zT_347;
    unsigned int zT_350;
    zT_A4CE86B7_U64ToU32Map* zT_351;
    zT_79FAE712_u64 zT_352;
    zT_BAEE192E_Opt_10 zT_353 = {0};
    unsigned char zT_354;
    unsigned int zT_357;
    unsigned int* zT_360;
    unsigned int zT_362;
    unsigned int zT_363;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_364;
    zT_338B7C76_TypeRegistry* zT_365;
    unsigned char zT_366;
    unsigned int zT_369;
    unsigned int* zT_370;
    unsigned int* zT_371;
    unsigned int zT_373;
    unsigned int zT_379;
    unsigned int zT_381;
    unsigned int zT_382;
    unsigned int zT_383 = 0;
    unsigned int zT_386;
    zT_A4CE86B7_U64ToU32Map* zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    zT_BAEE192E_Opt_10 zT_393 = {0};
    unsigned char zT_395;
    char* zT_398;
    unsigned int zT_399;
    char* zT_400;
    unsigned int zT_401;
    char* zT_402;
    unsigned int zT_403;
    char* zT_405;
    unsigned int zT_406;
    char* zT_407;
    unsigned int zT_408;
    char* zT_409;
    unsigned int zT_410;
    unsigned int zT_412;
    unsigned int zT_413;
    unsigned int zT_414;
    zT_3F3BF87A_AsyncFrameLayout zT_417;
    unsigned int max_temp;
    zT_2CF63CE1_AsyncFrameFieldArra fields;
    zT_21D3708C_U32ToU32Map locals;
    zT_6D148508_Scan c;
    unsigned int hti;
    zT_1937645B_TempDecl td;
    unsigned int pi;
    zT_8779209D_LirParam p;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    unsigned char* is_param;
    zT_0F824FDE_anon_68400 dl;
    unsigned int pt;
    unsigned char* live;
    unsigned int t;
    unsigned int offset;
    unsigned int max_align;
    zT_6BA597BC_LirInst inst;
    unsigned int tu;
    unsigned int hid;
    zT_79FAE712_u64 lay_key;
    unsigned int h;
    unsigned int lay_ptr_void;
    unsigned int pstart;
    unsigned int precise;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_BAEE192E_Opt_10 frame_size;
    unsigned int padded;
    unsigned int fs;
    zT_11 = lir_fn;
    zT_12 = zF_005F8966_maxTempOf(zT_11);
    max_temp = zT_12;
    zT_14 = alloc;
    zT_16 = lir_fn->params;
    zT_17 = zT_16.len;
    zT_18 = lir_fn->hoisted_temps;
    zT_19 = zT_18.len;
    zT_23 = zF_1BFB52BE_fieldArrayListInit(zT_14, (unsigned int)((unsigned int)(zT_17 + zT_19) + (unsigned int)(2)));
    fields = zT_23;
    zT_25 = alloc;
    zT_26 = zF_58BDA2DE_u32ToU32MapInit(zT_25);
    locals = zT_26;
    zT_28.lir_fn = lir_fn;
    zT_28.reg = reg;
    zT_28.max_temp = max_temp;
    zT_29 = alloc;
    zT_30 = max_temp;
    zT_33 = zF_82E88BBC_allocU32With(zT_29, zT_30, (unsigned int)(18));
    zT_28.ttype = zT_33;
    zT_34 = &locals;
    zT_28.locals = zT_34;
    c = zT_28;
    zT_36 = 0;
    hti = zT_36;
    goto z_bb_1;
    z_bb_1:
    zT_37 = lir_fn->hoisted_temps;
    zT_38 = zT_37.len;
    if ((int)(hti < zT_38)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_41 = lir_fn->hoisted_temps;
    zT_42 = zT_41.items;
    zT_43 = zT_42[hti];
    td = zT_43;
    zT_44 = td.temp_id;
    if ((int)(zT_44 < max_temp)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_53 = 0;
    pi = zT_53;
    goto z_bb_7;
    z_bb_4:
    zT_51 = hti + (unsigned int)(1);
    hti = zT_51;
    goto z_bb_1;
    z_bb_5:
    zT_46 = td.type_id;
    zT_47 = c.ttype;
    zT_48 = td.temp_id;
    zT_49 = (unsigned int)zT_48;
    zT_47[zT_49] = zT_46;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_54 = lir_fn->params;
    zT_55 = zT_54.len;
    if ((int)(pi < zT_55)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_58 = lir_fn->params;
    zT_59 = zT_58.items;
    zT_60 = zT_59[pi];
    p = zT_60;
    zT_61 = &locals;
    zT_62 = p.name_id;
    zT_63 = p.temp_id;
    zF_26476265_u32ToU32MapPut(zT_61, zT_62, zT_63);
    (void)alloc;
    goto z_bb_10;
    z_bb_9:
    zT_70 = 0;
    bi = zT_70;
    goto z_bb_11;
    z_bb_10:
    zT_68 = pi + (unsigned int)(1);
    pi = zT_68;
    goto z_bb_7;
    z_bb_11:
    zT_71 = lir_fn->blocks;
    zT_72 = zT_71.len;
    if ((int)(bi < zT_72)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_75 = lir_fn->blocks;
    zT_76 = zT_75.items;
    zT_77 = zT_76 + bi;
    bb = zT_77;
    zT_79 = 0;
    ii = zT_79;
    goto z_bb_15;
    z_bb_13:
    zT_99 = alloc;
    zT_100 = max_temp;
    zT_101 = zF_F15DB413_allocU8Raw(zT_99, zT_100);
    is_param = zT_101;
    zT_102 = 0;
    pi = zT_102;
    goto z_bb_23;
    z_bb_14:
    zT_97 = bi + (unsigned int)(1);
    bi = zT_97;
    goto z_bb_11;
    z_bb_15:
    zT_80 = bb->insts;
    zT_81 = zT_80.len;
    if ((int)(ii < zT_81)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_83 = bb->insts;
    zT_84 = zT_83.items;
    zT_85 = zT_84[ii];
    zT_86 = zT_85.tag;
switch (zT_86) {
case 1: goto z_bb_19;
default: goto z_bb_20;
}
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_95 = ii + (unsigned int)(1);
    ii = zT_95;
    goto z_bb_15;
    z_bb_19:
    dl = zT_85.payload.decl_local._0;
    zT_88 = &locals;
    zT_89 = dl.name_id;
    zT_90 = dl.temp;
    zF_26476265_u32ToU32MapPut(zT_88, zT_89, zT_90);
    (void)alloc;
    goto z_bb_22;
    z_bb_20:
    goto z_bb_22;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_103 = lir_fn->params;
    zT_104 = zT_103.len;
    if ((int)(pi < zT_104)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_107 = lir_fn->params;
    zT_108 = zT_107.items;
    zT_109 = zT_108[pi];
    zT_110 = zT_109.temp_id;
    pt = zT_110;
    if ((int)(pt < max_temp)) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_117 = alloc;
    zT_118 = max_temp;
    zT_119 = zF_F15DB413_allocU8Raw(zT_117, zT_118);
    live = zT_119;
    zT_121 = 0;
    t = zT_121;
    goto z_bb_29;
    z_bb_26:
    zT_115 = pi + (unsigned int)(1);
    pi = zT_115;
    goto z_bb_23;
    z_bb_27:
    zT_112 = 1;
    zT_113 = (unsigned int)pt;
    is_param[zT_113] = zT_112;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    if ((int)(t < max_temp)) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_123 = 0;
    zT_124 = (unsigned int)t;
    live[zT_124] = zT_123;
    goto z_bb_32;
    z_bb_31:
    zT_127 = 0;
    bi = zT_127;
    goto z_bb_33;
    z_bb_32:
    zT_126 = t + (unsigned int)(1);
    t = zT_126;
    goto z_bb_29;
    z_bb_33:
    zT_128 = lir_fn->blocks;
    zT_129 = zT_128.len;
    if ((int)(bi < zT_129)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_132 = lir_fn->blocks;
    zT_133 = zT_132.items;
    zT_134 = zT_133 + bi;
    bb = zT_134;
    zT_136 = 0;
    ii = zT_136;
    goto z_bb_37;
    z_bb_35:
    zT_181 = 0;
    offset = zT_181;
    zT_183 = 1;
    max_align = zT_183;
    zT_184 = &fields;
    zT_185 = reg;
    zT_193 = 4;
    zT_186 = zT_193;
    zT_190 = &offset;
    zT_191 = &max_align;
    zF_F2801F08_addField(zT_184, zT_185, zT_186, (unsigned int)(0), (unsigned int)(0), (unsigned int)(13), zT_190, zT_191);
    zT_199 = &fields;
    zT_200 = reg;
    zT_208 = 0;
    zT_201 = zT_208;
    zT_205 = &offset;
    zT_206 = &max_align;
    zF_F2801F08_addField(zT_199, zT_200, zT_201, (unsigned int)(0), (unsigned int)(0), (unsigned int)(13), zT_205, zT_206);
    zT_214 = &fields;
    zT_215 = reg;
    zT_223 = 1;
    zT_216 = zT_223;
    zT_220 = &offset;
    zT_221 = &max_align;
    zF_F2801F08_addField(zT_214, zT_215, zT_216, (unsigned int)(0), (unsigned int)(0), (unsigned int)(8), zT_220, zT_221);
    zT_229 = 0;
    pi = zT_229;
    goto z_bb_53;
    z_bb_36:
    zT_179 = bi + (unsigned int)(1);
    bi = zT_179;
    goto z_bb_33;
    z_bb_37:
    zT_137 = bb->insts;
    zT_138 = zT_137.len;
    if ((int)(ii < zT_138)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_141 = bb->insts;
    zT_142 = zT_141.items;
    zT_143 = zT_142[ii];
    inst = zT_143;
    zT_144 = &c;
    zT_145 = inst;
    zT_146 = suspending_fns;
    zT_148 = zF_1AAC25A7_instIsSuspendPoint(zT_144, zT_145, zT_146);
    if (zT_148) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_177 = ii + (unsigned int)(1);
    ii = zT_177;
    goto z_bb_37;
    z_bb_41:
    zT_149 = 0;
    t = zT_149;
    goto z_bb_43;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    if ((int)(t < max_temp)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_152 = (unsigned int)t;
    tu = zT_152;
    zT_153 = is_param[tu];
    if ((int)(zT_153 != (unsigned char)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_175 = t + (unsigned int)(1);
    t = zT_175;
    goto z_bb_43;
    z_bb_47:
    goto z_bb_46;
    z_bb_48:
    zT_156 = &c;
    zT_157 = t;
    zT_163 = zF_93E9604D_hasDefBefore(zT_156, zT_157, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    if ((int)(!zT_163)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_165 = &c;
    zT_166 = t;
    zT_172 = zF_4CED5DFF_hasReadAfter(zT_165, zT_166, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    if (zT_172) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_173 = 1;
    live[tu] = zT_173;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_46;
    z_bb_53:
    zT_230 = lir_fn->params;
    zT_231 = zT_230.len;
    if ((int)(pi < zT_231)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_234 = lir_fn->params;
    zT_235 = zT_234.items;
    zT_236 = zT_235[pi];
    p = zT_236;
    zT_237 = &fields;
    zT_238 = reg;
    zT_246 = 2;
    zT_239 = zT_246;
    zT_240 = p.name_id;
    zT_241 = p.temp_id;
    zT_242 = p.type_id;
    zT_243 = &offset;
    zT_244 = &max_align;
    zF_F2801F08_addField(zT_237, zT_238, zT_239, zT_240, zT_241, zT_242, zT_243, zT_244);
    goto z_bb_56;
    z_bb_55:
    zT_254 = 0;
    t = zT_254;
    goto z_bb_57;
    z_bb_56:
    zT_253 = pi + (unsigned int)(1);
    pi = zT_253;
    goto z_bb_53;
    z_bb_57:
    if ((int)(t < max_temp)) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_257 = (unsigned int)t;
    tu = zT_257;
    zT_258 = live[tu];
    if ((int)(zT_258 != (unsigned char)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    zT_283 = 0;
    hid = zT_283;
    zT_285 = lir_fn->module_id;
    zT_286 = lir_fn->name_id;
    zT_289 = zF_9D041EB6_asyncKey(zT_285, zT_286);
    lay_key = zT_289;
    zT_290 = async_hidden_fns;
    zT_291 = lay_key;
    zT_292 = zF_A05A7BE1_u64ToU32MapGet(zT_290, zT_291);
    zT_293 = zT_292.has_value;
    if (zT_293) goto z_bb_66; else goto z_bb_67;
    z_bb_60:
    zT_281 = t + (unsigned int)(1);
    t = zT_281;
    goto z_bb_57;
    z_bb_61:
    zT_262 = is_param[tu];
    zT_261 = zT_262 == (unsigned char)(0);
    goto z_bb_63;
    z_bb_62:
    zT_261 = 0;
    goto z_bb_63;
    z_bb_63:
    if (zT_261) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_265 = &fields;
    zT_266 = reg;
    zT_274 = 3;
    zT_267 = zT_274;
    zT_269 = t;
    zT_276 = c.ttype;
    zT_270 = zT_276[tu];
    zT_271 = &offset;
    zT_272 = &max_align;
    zF_F2801F08_addField(zT_265, zT_266, zT_267, (unsigned int)(0), zT_269, zT_270, zT_271, zT_272);
    goto z_bb_65;
    z_bb_65:
    goto z_bb_60;
    z_bb_66:
    h = zT_292.value;
    hid = h;
    goto z_bb_67;
    z_bb_67:
    zT_296 = reg;
    zT_301 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_296, (unsigned int)(1), (int)(0));
    lay_ptr_void = zT_301;
    if ((int)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_306 = &fields;
    zT_307 = reg;
    zT_315 = 5;
    zT_308 = zT_315;
    zT_311 = lay_ptr_void;
    zT_312 = &offset;
    zT_313 = &max_align;
    zF_F2801F08_addField(zT_306, zT_307, zT_308, (unsigned int)(0), (unsigned int)(0), zT_311, zT_312, zT_313);
    goto z_bb_69;
    z_bb_69:
    zT_320 = awaited_fns;
    zT_321 = lay_key;
    zT_322 = zF_A05A7BE1_u64ToU32MapGet(zT_320, zT_321);
    zT_323 = zT_322.has_value;
    if (zT_323) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_324 = &fields;
    zT_325 = reg;
    zT_333 = 6;
    zT_326 = zT_333;
    zT_329 = lay_ptr_void;
    zT_330 = &offset;
    zT_331 = &max_align;
    zF_F2801F08_addField(zT_324, zT_325, zT_326, (unsigned int)(0), (unsigned int)(0), zT_329, zT_330, zT_331);
    goto z_bb_71;
    z_bb_71:
    if ((int)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_343 = 0;
    pstart = zT_343;
    zT_344 = parent_result_start;
    zT_345 = lay_key;
    zT_346 = zF_A05A7BE1_u64ToU32MapGet(zT_344, zT_345);
    zT_347 = zT_346.has_value;
    if (zT_347) goto z_bb_74; else goto z_bb_75;
    z_bb_73:
    zT_381 = offset;
    zT_382 = max_align;
    zT_383 = zF_978D7C93_alignUpU32_1(zT_381, zT_382);
    precise = zT_383;
    if ((int)(precise == (unsigned int)(0))) goto z_bb_82; else goto z_bb_83;
    z_bb_74:
    ps = zT_346.value;
    pstart = ps;
    goto z_bb_75;
    z_bb_75:
    zT_350 = 0;
    pcount = zT_350;
    zT_351 = parent_result_count;
    zT_352 = lay_key;
    zT_353 = zF_A05A7BE1_u64ToU32MapGet(zT_351, zT_352);
    zT_354 = zT_353.has_value;
    if (zT_354) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    pc = zT_353.value;
    pcount = pc;
    goto z_bb_77;
    z_bb_77:
    zT_357 = 0;
    pk = zT_357;
    goto z_bb_78;
    z_bb_78:
    if ((int)(pk < pcount)) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_360 = parent_result_type_list->items;
    zT_362 = (unsigned int)(unsigned int)(pstart + pk);
    zT_363 = zT_360[zT_362];
    prt = zT_363;
    zT_364 = &fields;
    zT_365 = reg;
    zT_373 = 7;
    zT_366 = zT_373;
    zT_369 = prt;
    zT_370 = &offset;
    zT_371 = &max_align;
    zF_F2801F08_addField(zT_364, zT_365, zT_366, (unsigned int)(0), (unsigned int)(0), zT_369, zT_370, zT_371);
    goto z_bb_81;
    z_bb_80:
    goto z_bb_73;
    z_bb_81:
    zT_379 = pk + (unsigned int)(1);
    pk = zT_379;
    goto z_bb_78;
    z_bb_82:
    zT_386 = 1;
    precise = zT_386;
    goto z_bb_83;
    z_bb_83:
    zT_388 = frame_sizes;
    zT_389 = lir_fn->module_id;
    zT_390 = lir_fn->name_id;
    zT_393 = zF_D3D61AC0_asyncFrameSizeOf(zT_388, zT_389, zT_390);
    frame_size = zT_393;
    padded = precise;
    zT_395 = frame_size.has_value;
    if (zT_395) goto z_bb_84; else goto z_bb_86;
    z_bb_84:
    fs = frame_size.value;
    if ((int)(precise > fs)) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    zT_412 = lir_fn->module_id;
    zT_413 = lir_fn->name_id;
    zT_414 = padded;
    zF_2B302EFE_emitLayoutMarker(zT_412, zT_413, zT_414);
    zT_417.fields = fields;
    zT_417.layout_size = padded;
    return zT_417;
    z_bb_86:
    zT_405 = "panic: ";
    zT_406 = 7;
    fwrite(zT_405, 1, zT_406, stderr);
    zT_407 = "async frame layout: missing authoritative frame size";
    zT_408 = 52;
    fwrite(zT_407, 1, zT_408, stderr);
    zT_409 = "\n";
    zT_410 = 1;
    fwrite(zT_409, 1, zT_410, stderr);
    pal_trap();
    z_bb_87:
    zT_398 = "panic: ";
    zT_399 = 7;
    fwrite(zT_398, 1, zT_399, stderr);
    zT_400 = "async frame layout exceeds authoritative frame size";
    zT_401 = 51;
    fwrite(zT_400, 1, zT_401, stderr);
    zT_402 = "\n";
    zT_403 = 1;
    fwrite(zT_402, 1, zT_403, stderr);
    pal_trap();
    z_bb_88:
    padded = fs;
    goto z_bb_85;
}

/* asyncLayoutPublish */
void zF_17324878_asyncLayoutPublish(zT_3E40CD83_Sand* alloc, zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id, zT_3F3BF87A_AsyncFrameLayout layout) {
    zT_3E40CD83_Sand* zT_6;
    zT_9154F007_EU_232 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    zT_3F3BF87A_AsyncFrameLayout* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_79FAE712_u64 zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_79FAE712_u64 zT_22 = 0;
    unsigned char* raw;
    zT_3F3BF87A_AsyncFrameLayout* p;
    zT_6 = alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(20), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    zT_16 = (zT_3F3BF87A_AsyncFrameLayout*)raw;
    p = zT_16;
    *p = layout;
    zT_17 = map;
    zT_20 = module_id;
    zT_21 = name_id;
    zT_22 = zF_9D041EB6_asyncKey(zT_20, zT_21);
    zT_18 = zT_22;
    zF_B6EB812C_u64ToU32MapPut(zT_17, zT_18, (unsigned int)((unsigned int)(unsigned int)((unsigned int)p)));
    (void)alloc;
    return;
}

/* asyncLayoutLookup */
zT_F7B96A09_Opt_394 zF_A1F56FFB_asyncLayoutLookup(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    zT_3F3BF87A_AsyncFrameLayout* zT_12;
    zT_F7B96A09_Opt_394 zT_13;
    zT_F7B96A09_Opt_394 zT_14 = {0};
    unsigned int v;
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    v = zT_8.value;
    zT_12 = (zT_3F3BF87A_AsyncFrameLayout*)(unsigned int)(unsigned int)((unsigned int)v);
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_2:
    zT_14.has_value = 0;
    return zT_14;
}

/* __module_init */
void zF_780653D2___module_init_22(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_BBC23664_LirFunction zT_1 = {0};
    zT_6BA597BC_LirInst zT_2 = {0};
    zT_338B7C76_TypeRegistry zT_3 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_6BA597BC_LirInst = zT_2;
    zG_338B7C76_TypeRegistry = zT_3;
    return;
}

/* EOF */
