#include "async_frame_layout_08B81337.h"
#include <stdio.h>
zT_3F3BF87A_AsyncFrameLayout zG_3F3BF87A_AsyncFrameLayout;
/* fieldArrayListInit */
zT_2CF63CE1_AsyncFrameFieldArra zF_1BFB52BE_fieldArrayListInit(zT_3E40CD83_Sand* alloc, unsigned int capacity) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_9154F007_EU_232 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    zT_2CF63CE1_AsyncFrameFieldArra zT_17;
    zT_902E38E8_AsyncFrameField* zT_18;
    unsigned int zT_19;
    unsigned int cap;
    unsigned char* raw;
    cap = capacity;
    if ((int)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    cap = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = alloc;
    zT_13 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)(cap * (unsigned int)(28)), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    zT_18 = (zT_902E38E8_AsyncFrameField*)raw;
    zT_17.items = zT_18;
    zT_19 = 0;
    zT_17.len = zT_19;
    zT_17.capacity = cap;
    zT_17.allocator = alloc;
    return zT_17;
}

/* fieldArrayListEnsureCapacity */
void zF_FB5EC98E_fieldArrayListEnsur(zT_2CF63CE1_AsyncFrameFieldArra* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_14;
    zT_3E40CD83_Sand* zT_16;
    zT_9154F007_EU_232 zT_23 = {0};
    unsigned char zT_24;
    unsigned char* zT_25;
    zT_902E38E8_AsyncFrameField* zT_28;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_902E38E8_AsyncFrameField* zT_33;
    zT_902E38E8_AsyncFrameField zT_34;
    unsigned int zT_36;
    unsigned int new_cap;
    unsigned char* raw;
    zT_902E38E8_AsyncFrameField* new_items;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    if ((int)(new_cap < (unsigned int)(zT_5 * (unsigned int)(2)))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_11 = zT_9 * (unsigned int)(2);
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    if ((int)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    new_cap = zT_14;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->allocator;
    zT_23 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)(new_cap * (unsigned int)(28)), (unsigned int)(4));
    zT_24 = zT_23.is_error;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_25 = zT_23.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_25;
    zT_28 = (zT_902E38E8_AsyncFrameField*)raw;
    new_items = zT_28;
    zT_30 = 0;
    i = zT_30;
    goto z_bb_10;
    z_bb_10:
    zT_31 = self->len;
    if ((int)(i < zT_31)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_33 = self->items;
    zT_34 = zT_33[i];
    new_items[i] = zT_34;
    goto z_bb_13;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
    z_bb_13:
    zT_36 = i + (unsigned int)(1);
    i = zT_36;
    goto z_bb_10;
}

/* fieldArrayListAppend */
void zF_92FA7DBC_fieldArrayListAppen(zT_2CF63CE1_AsyncFrameFieldArra* self, zT_902E38E8_AsyncFrameField value) {
    zT_2CF63CE1_AsyncFrameFieldArra* zT_2;
    unsigned int zT_4;
    zT_902E38E8_AsyncFrameField* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_2 = self;
    zT_4 = self->len;
    zF_FB5EC98E_fieldArrayListEnsur(zT_2, (unsigned int)(zT_4 + (unsigned int)(1)));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    self->len = (unsigned int)(zT_9 + (unsigned int)(1));
    return;
}

/* allocU32With */
unsigned int* zF_82E88BBC_allocU32With(zT_3E40CD83_Sand* alloc, unsigned int n, unsigned int fill) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    zT_9154F007_EU_232 zT_15 = {0};
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned int* zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int count;
    unsigned char* raw;
    unsigned int* a;
    unsigned int i;
    count = n;
    if ((int)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = 1;
    count = zT_6;
    goto z_bb_2;
    z_bb_2:
    zT_8 = alloc;
    zT_15 = zF_1395EB68_sandAlloc(zT_8, (unsigned int)((unsigned int)((unsigned int)count) * (unsigned int)(4)), (unsigned int)(4));
    zT_16 = zT_15.is_error;
    if (zT_16) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_17 = zT_15.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_17;
    zT_20 = (unsigned int*)raw;
    a = zT_20;
    zT_22 = 0;
    i = zT_22;
    goto z_bb_6;
    z_bb_6:
    if ((int)(i < count)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_24 = (unsigned int)i;
    a[zT_24] = fill;
    goto z_bb_9;
    z_bb_8:
    return a;
    z_bb_9:
    zT_26 = i + (unsigned int)(1);
    i = zT_26;
    goto z_bb_6;
}

/* allocU8Raw */
unsigned char* zF_F15DB413_allocU8Raw(zT_3E40CD83_Sand* alloc, unsigned int n) {
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    zT_9154F007_EU_232 zT_14 = {0};
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned int count;
    unsigned char* raw;
    count = n;
    if ((int)(count == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = 1;
    count = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_7 = alloc;
    zT_14 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)((unsigned int)((unsigned int)count) * (unsigned int)(1)), (unsigned int)(1));
    zT_15 = zT_14.is_error;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_16 = zT_14.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_16;
    return (unsigned char*)((unsigned char*)raw);
}

/* maxTempOf */
unsigned int zF_005F8966_maxTempOf(zT_BBC23664_LirFunction* lir_fn) {
    unsigned int zT_2;
    unsigned int zT_4;
    zT_5D72FBF8_TempDeclArrayList zT_5;
    unsigned int zT_6;
    zT_5D72FBF8_TempDeclArrayList zT_9;
    zT_1937645B_TempDecl* zT_10;
    zT_1937645B_TempDecl zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int m;
    unsigned int i;
    zT_1937645B_TempDecl td;
    zT_2 = 0;
    m = zT_2;
    zT_4 = 0;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = lir_fn->hoisted_temps;
    zT_6 = zT_5.len;
    if ((int)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = lir_fn->hoisted_temps;
    zT_10 = zT_9.items;
    zT_11 = zT_10[i];
    td = zT_11;
    zT_12 = td.temp_id;
    if ((int)(zT_12 >= m)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return m;
    z_bb_4:
    zT_18 = i + (unsigned int)(1);
    i = zT_18;
    goto z_bb_1;
    z_bb_5:
    zT_14 = td.temp_id;
    zT_16 = zT_14 + (unsigned int)(1);
    m = zT_16;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* defResultTemp */
unsigned int zF_CFED20F7_defResultTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst) {
    unsigned int zT_2;
    unsigned int zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned int zT_48;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_64;
    unsigned int zT_66;
    unsigned int zT_68;
    unsigned int zT_70;
    unsigned int zT_72;
    unsigned int zT_74;
    unsigned int zT_76;
    unsigned int zT_78;
    unsigned int zT_80;
    unsigned int zT_82;
    unsigned int zT_84;
    unsigned int zT_86;
    unsigned int zT_88;
    zT_BBC23664_LirFunction* zT_91;
    unsigned int zT_92;
    zT_3BFB1E70_CallDirectData zT_94 = {0};
    unsigned int zT_95;
    zT_BBC23664_LirFunction* zT_98;
    unsigned int zT_99;
    zT_0624AC1B_TailCallData zT_101 = {0};
    unsigned int zT_102;
    unsigned int zT_104;
    unsigned int zT_106;
    unsigned int zT_108;
    unsigned int zT_110;
    unsigned int zT_112;
    unsigned int zT_114;
    unsigned int zT_116;
    unsigned int zT_118;
    zT_BB725D75_anon_68957 b;
    zT_4979F8C4_anon_68965 u;
    zT_54DBC6B1_anon_69183 ic;
    zT_4ADBB6F3_anon_69189 fc;
    zT_5ADE0EBA_anon_69195 sc;
    zT_4EDDFBD6_anon_69199 nc;
    zT_A1CB5A6A_anon_69205 sn;
    zT_99C90F3B_anon_69211 bc;
    zT_9FC918AD_anon_69217 uc;
    zT_E82F7DD3_anon_69435 pi;
    zT_0FD084C2_anon_69227 ec;
    zT_4ACEEB00_anon_69139 ic_1;
    zT_002B266D_anon_69451 ic_2;
    zT_76280E98_anon_69463 ww;
    zT_D8D20921_anon_69147 fc_3;
    zT_DAD44ADE_anon_69155 pc;
    zT_C4D666D3_anon_69163 itf;
    zT_48D97536_anon_69177 itp;
    zT_CED67691_anon_69169 pti;
    zT_52CEF798_anon_69131 ms;
    zT_32975D70_anon_69023 a;
    zT_30951BB3_anon_69031 a_4;
    zT_C4A13DA2_anon_69069 fr;
    zT_3895284B_anon_69039 w;
    zT_C8AE0FE1_anon_69095 w_5;
    zT_44C825C9_anon_69103 w_6;
    zT_C49EFF0B_anon_69075 u_7;
    zT_EC2F841F_anon_69431 u_8;
    zT_B0B028B0_anon_69081 u_9;
    zT_B6B03222_anon_69087 ch;
    zT_4AC82F3B_anon_69109 u_10;
    zT_4ACA6DD2_anon_69115 u_11;
    zT_4ECCB2B5_anon_69121 ch_12;
    zT_3C99ABC5_anon_69011 l;
    zT_BD92B446_anon_68985 lf;
    zT_B72ECD0D_anon_69323 lb;
    zT_C49CC074_anon_69005 li;
    zT_A3CD9C27_anon_69233 ll;
    zT_0FD501F0_anon_69247 lg;
    zT_50FDA908_anon_68899 a_13;
    zT_497E75F2_anon_68909 a_14;
    zT_457C310F_anon_68919 a_15;
    zT_3D77A749_anon_68975 cl;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    unsigned int slot_16;
    zT_0624AC1B_TailCallData tc;
    zT_38A432D5_anon_69055 va;
    zT_8FB7B65C_anon_69287 bgc;
    zT_B12C8504_anon_69355 o;
    zT_2524ECDB_anon_69369 o_17;
    zT_2F478EDB_anon_69383 o_18;
    zT_3349D3BE_anon_69397 o_19;
    zT_743715FC_anon_69409 o_20;
    zT_6C328C36_anon_69425 o_21;
    zT_2 = inst.tag;
switch (zT_2) {
case 12: goto z_bb_1;
case 13: goto z_bb_2;
case 44: goto z_bb_3;
case 45: goto z_bb_4;
case 46: goto z_bb_5;
case 47: goto z_bb_6;
case 48: goto z_bb_7;
case 49: goto z_bb_8;
case 50: goto z_bb_9;
case 79: goto z_bb_10;
case 51: goto z_bb_11;
case 38: goto z_bb_12;
case 80: goto z_bb_13;
case 81: goto z_bb_14;
case 39: goto z_bb_15;
case 40: goto z_bb_16;
case 41: goto z_bb_17;
case 43: goto z_bb_18;
case 42: goto z_bb_19;
case 37: goto z_bb_20;
case 20: goto z_bb_21;
case 21: goto z_bb_22;
case 28: goto z_bb_23;
case 22: goto z_bb_24;
case 32: goto z_bb_25;
case 33: goto z_bb_26;
case 29: goto z_bb_27;
case 78: goto z_bb_28;
case 30: goto z_bb_29;
case 31: goto z_bb_30;
case 34: goto z_bb_31;
case 35: goto z_bb_32;
case 36: goto z_bb_33;
case 18: goto z_bb_34;
case 15: goto z_bb_35;
case 68: goto z_bb_36;
case 17: goto z_bb_37;
case 52: goto z_bb_38;
case 54: goto z_bb_39;
case 2: goto z_bb_40;
case 3: goto z_bb_41;
case 4: goto z_bb_42;
case 14: goto z_bb_43;
case 23: goto z_bb_44;
case 27: goto z_bb_45;
case 25: goto z_bb_46;
case 61: goto z_bb_47;
case 72: goto z_bb_48;
case 73: goto z_bb_49;
case 74: goto z_bb_50;
case 75: goto z_bb_51;
case 76: goto z_bb_52;
case 77: goto z_bb_53;
default: goto z_bb_54;
}
    z_bb_1:
    b = inst.payload.binary._0;
    zT_4 = b.result;
    return zT_4;
    z_bb_2:
    u = inst.payload.unary._0;
    zT_6 = u.result;
    return zT_6;
    z_bb_3:
    ic = inst.payload.int_const._0;
    zT_8 = ic.result;
    return zT_8;
    z_bb_4:
    fc = inst.payload.float_const._0;
    zT_10 = fc.result;
    return zT_10;
    z_bb_5:
    sc = inst.payload.string_const._0;
    zT_12 = sc.result;
    return zT_12;
    z_bb_6:
    nc = inst.payload.null_const._0;
    zT_14 = nc.result;
    return zT_14;
    z_bb_7:
    sn = inst.payload.set_optional_null._0;
    zT_16 = sn.result;
    return zT_16;
    z_bb_8:
    bc = inst.payload.bool_const._0;
    zT_18 = bc.result;
    return zT_18;
    z_bb_9:
    uc = inst.payload.undefined_const._0;
    zT_20 = uc.result;
    return zT_20;
    z_bb_10:
    pi = inst.payload.poison_init._0;
    zT_22 = pi.result;
    return zT_22;
    z_bb_11:
    ec = inst.payload.enum_const._0;
    zT_24 = ec.result;
    return zT_24;
    z_bb_12:
    ic_1 = inst.payload.int_cast._0;
    zT_26 = ic_1.result;
    return zT_26;
    z_bb_13:
    ic_2 = inst.payload.int_cast_checked._0;
    zT_28 = ic_2.result;
    return zT_28;
    z_bb_14:
    ww = inst.payload.width_wrap._0;
    zT_30 = ww.result;
    return zT_30;
    z_bb_15:
    fc_3 = inst.payload.float_cast._0;
    zT_32 = fc_3.result;
    return zT_32;
    z_bb_16:
    pc = inst.payload.ptr_cast._0;
    zT_34 = pc.result;
    return zT_34;
    z_bb_17:
    itf = inst.payload.int_to_float._0;
    zT_36 = itf.result;
    return zT_36;
    z_bb_18:
    itp = inst.payload.int_to_ptr._0;
    zT_38 = itp.result;
    return zT_38;
    z_bb_19:
    pti = inst.payload.ptr_to_int._0;
    zT_40 = pti.result;
    return zT_40;
    z_bb_20:
    ms = inst.payload.make_slice._0;
    zT_42 = ms.result;
    return zT_42;
    z_bb_21:
    a = inst.payload.addr_of._0;
    zT_44 = a.result;
    return zT_44;
    z_bb_22:
    a_4 = inst.payload.addr_of_field._0;
    zT_46 = a_4.result;
    return zT_46;
    z_bb_23:
    fr = inst.payload.func_ref._0;
    zT_48 = fr.result;
    return zT_48;
    z_bb_24:
    w = inst.payload.wrap_optional._0;
    zT_50 = w.result;
    return zT_50;
    z_bb_25:
    w_5 = inst.payload.wrap_error_ok._0;
    zT_52 = w_5.result;
    return zT_52;
    z_bb_26:
    w_6 = inst.payload.wrap_error_err._0;
    zT_54 = w_6.result;
    return zT_54;
    z_bb_27:
    u_7 = inst.payload.unwrap_optional._0;
    zT_56 = u_7.result;
    return zT_56;
    z_bb_28:
    u_8 = inst.payload.unwrap_optional_checked._0;
    zT_58 = u_8.result;
    return zT_58;
    z_bb_29:
    u_9 = inst.payload.unwrap_optional_abi._0;
    zT_60 = u_9.result;
    return zT_60;
    z_bb_30:
    ch = inst.payload.check_optional._0;
    zT_62 = ch.result;
    return zT_62;
    z_bb_31:
    u_10 = inst.payload.unwrap_error_payload._0;
    zT_64 = u_10.result;
    return zT_64;
    z_bb_32:
    u_11 = inst.payload.unwrap_error_code._0;
    zT_66 = u_11.result;
    return zT_66;
    z_bb_33:
    ch_12 = inst.payload.check_error._0;
    zT_68 = ch_12.result;
    return zT_68;
    z_bb_34:
    l = inst.payload.load._0;
    zT_70 = l.result;
    return zT_70;
    z_bb_35:
    lf = inst.payload.load_field._0;
    zT_72 = lf.result;
    return zT_72;
    z_bb_36:
    lb = inst.payload.load_bitfield._0;
    zT_74 = lb.result;
    return zT_74;
    z_bb_37:
    li = inst.payload.load_index._0;
    zT_76 = li.result;
    return zT_76;
    z_bb_38:
    ll = inst.payload.load_local._0;
    zT_78 = ll.result;
    return zT_78;
    z_bb_39:
    lg = inst.payload.load_global._0;
    zT_80 = lg.result;
    return zT_80;
    z_bb_40:
    a_13 = inst.payload.assign._0;
    zT_82 = a_13.dst;
    return zT_82;
    z_bb_41:
    a_14 = inst.payload.assign_field._0;
    zT_84 = a_14.base;
    return zT_84;
    z_bb_42:
    a_15 = inst.payload.assign_index._0;
    zT_86 = a_15.base;
    return zT_86;
    z_bb_43:
    cl = inst.payload.call._0;
    zT_88 = cl.result;
    return zT_88;
    z_bb_44:
    slot = inst.payload.jump._0;
    zT_91 = c->lir_fn;
    zT_92 = slot;
    zT_94 = zF_75DE985C_lirSideGetCallDirec(zT_91, zT_92);
    cd = zT_94;
    zT_95 = cd.result;
    return zT_95;
    z_bb_45:
    slot_16 = inst.payload.jump._0;
    zT_98 = c->lir_fn;
    zT_99 = slot_16;
    zT_101 = zF_1AB3807F_lirSideGetTailCall(zT_98, zT_99);
    tc = zT_101;
    zT_102 = tc.result;
    return zT_102;
    z_bb_46:
    va = inst.payload.va_arg._0;
    zT_104 = va.result;
    return zT_104;
    z_bb_47:
    bgc = inst.payload.builtin_get_char._0;
    zT_106 = bgc.result;
    return zT_106;
    z_bb_48:
    o = inst.payload.add_with_overflow._0;
    zT_108 = o.result;
    return zT_108;
    z_bb_49:
    o_17 = inst.payload.sub_with_overflow._0;
    zT_110 = o_17.result;
    return zT_110;
    z_bb_50:
    o_18 = inst.payload.mul_with_overflow._0;
    zT_112 = o_18.result;
    return zT_112;
    z_bb_51:
    o_19 = inst.payload.shl_with_overflow._0;
    zT_114 = o_19.result;
    return zT_114;
    z_bb_52:
    o_20 = inst.payload.neg_with_overflow._0;
    zT_116 = o_20.result;
    return zT_116;
    z_bb_53:
    o_21 = inst.payload.overflow_flag._0;
    zT_118 = o_21.result;
    return zT_118;
    z_bb_54:
    return (unsigned int)(4294967295u);
    return 0;
}

/* localStorage */
unsigned int zF_CD424A09_localStorage(zT_6D148508_Scan* c, unsigned int name_id) {
    zT_21D3708C_U32ToU32Map* zT_5;
    unsigned int zT_6;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    unsigned int t;
    if ((int)(name_id == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_5 = c->locals;
    zT_6 = name_id;
    zT_8 = zF_F3EE5998_u32ToU32MapGet(zT_5, zT_6);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    t = zT_8.value;
    return t;
    z_bb_4:
    return (unsigned int)(4294967295u);
}

/* instDefsTemp */
int zF_1FF90D33_instDefsTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, unsigned int v) {
    zT_6D148508_Scan* zT_3;
    zT_6BA597BC_LirInst zT_4;
    unsigned int zT_5 = 0;
    unsigned int zT_8;
    zT_6D148508_Scan* zT_10;
    unsigned int zT_11;
    unsigned int zT_13 = 0;
    zT_9DCD92B5_anon_69239 sl;
    zT_3 = c;
    zT_4 = inst;
    zT_5 = zF_CFED20F7_defResultTemp(zT_3, zT_4);
    if ((int)(zT_5 == v)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (int)(1);
    z_bb_2:
    zT_8 = inst.tag;
switch (zT_8) {
case 53: goto z_bb_3;
case 55: goto z_bb_4;
default: goto z_bb_5;
}
    z_bb_3:
    sl = inst.payload.store_local._0;
    zT_10 = c;
    zT_11 = sl.name_id;
    zT_13 = zF_CD424A09_localStorage(zT_10, zT_11);
    if ((int)(zT_13 == v)) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    goto z_bb_7;
    z_bb_5:
    goto z_bb_7;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    return (int)(1);
    z_bb_9:
    goto z_bb_7;
}

/* instReadsTemp */
int zF_E4C3429C_instReadsTemp(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, unsigned int v) {
    unsigned int zT_3;
    unsigned int zT_5;
    unsigned int zT_9;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_16;
    int zT_18;
    unsigned int zT_19;
    int zT_21;
    unsigned int zT_22;
    unsigned int zT_26;
    unsigned int zT_30;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_44;
    unsigned int zT_48;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_55;
    int zT_57;
    unsigned int zT_58;
    unsigned int zT_62;
    int zT_64;
    unsigned int zT_65;
    unsigned int zT_69;
    int zT_71;
    unsigned int zT_72;
    unsigned int zT_76;
    unsigned int zT_80;
    int zT_82;
    unsigned int zT_83;
    unsigned int zT_87;
    unsigned int zT_90;
    int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_99;
    unsigned int zT_103;
    unsigned int zT_107;
    int zT_109;
    unsigned int zT_110;
    unsigned int zT_114;
    int zT_116;
    unsigned int zT_117;
    unsigned int zT_121;
    int zT_123;
    unsigned int zT_124;
    unsigned int zT_128;
    unsigned int zT_132;
    int zT_134;
    unsigned int zT_135;
    unsigned int zT_139;
    unsigned int zT_143;
    unsigned int zT_147;
    zT_BBC23664_LirFunction* zT_152;
    unsigned int zT_153;
    zT_3BFB1E70_CallDirectData zT_155 = {0};
    unsigned int zT_156;
    int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_165;
    int zT_167;
    unsigned int zT_168;
    unsigned int zT_172;
    unsigned int zT_176;
    zT_BBC23664_LirFunction* zT_181;
    unsigned int zT_182;
    zT_0624AC1B_TailCallData zT_184 = {0};
    unsigned char zT_185;
    int zT_188;
    unsigned int zT_189;
    unsigned int zT_192;
    int zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    unsigned int zT_201;
    unsigned int zT_205;
    unsigned int zT_209;
    unsigned int zT_213;
    unsigned int zT_217;
    unsigned int zT_221;
    unsigned int zT_225;
    unsigned int zT_229;
    unsigned int zT_233;
    unsigned int zT_237;
    int zT_239;
    unsigned int zT_240;
    unsigned int zT_244;
    unsigned int zT_248;
    unsigned int zT_252;
    unsigned int zT_256;
    unsigned int zT_260;
    unsigned int zT_264;
    unsigned int zT_268;
    unsigned int zT_272;
    zT_6D148508_Scan* zT_276;
    unsigned int zT_277;
    unsigned int zT_279 = 0;
    unsigned int zT_283;
    unsigned int zT_287;
    unsigned int zT_291;
    unsigned int zT_295;
    unsigned int zT_299;
    int zT_301;
    unsigned int zT_302;
    unsigned int zT_306;
    int zT_308;
    unsigned int zT_309;
    unsigned int zT_313;
    unsigned int zT_317;
    unsigned int zT_321;
    int zT_323;
    unsigned int zT_324;
    unsigned int zT_328;
    int zT_330;
    unsigned int zT_331;
    unsigned int zT_335;
    zT_50FDA908_anon_68899 a;
    zT_497E75F2_anon_68909 a_1;
    zT_457C310F_anon_68919 a_2;
    zT_C583B654_anon_68929 b;
    zT_C1817171_anon_68939 s;
    unsigned int r;
    zT_BB725D75_anon_68957 b_3;
    zT_4979F8C4_anon_68965 u;
    zT_B12C8504_anon_69355 o;
    zT_2524ECDB_anon_69369 o_4;
    zT_2F478EDB_anon_69383 o_5;
    zT_3349D3BE_anon_69397 o_6;
    zT_743715FC_anon_69409 o_7;
    zT_6C328C36_anon_69425 o_8;
    zT_3D77A749_anon_68975 cl;
    zT_BD92B446_anon_68985 lf;
    zT_B72ECD0D_anon_69323 lb;
    zT_B9906F63_anon_68995 sf;
    zT_B7310BA4_anon_69333 sb;
    zT_C49CC074_anon_69005 li;
    zT_3C99ABC5_anon_69011 l;
    zT_3699A253_anon_69017 st;
    zT_32975D70_anon_69023 a_9;
    zT_30951BB3_anon_69031 a_10;
    zT_3895284B_anon_69039 w;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_36A66E46_anon_69047 vs;
    zT_38A432D5_anon_69055 va;
    zT_3CA43921_anon_69059 ve;
    unsigned int slot_11;
    zT_0624AC1B_TailCallData tc;
    zT_C49EFF0B_anon_69075 u_12;
    zT_EC2F841F_anon_69431 u_13;
    zT_B0B028B0_anon_69081 u_14;
    zT_B6B03222_anon_69087 ch;
    zT_C8AE0FE1_anon_69095 w_15;
    zT_44C825C9_anon_69103 w_16;
    zT_4AC82F3B_anon_69109 u_17;
    zT_4ACA6DD2_anon_69115 u_18;
    zT_4ECCB2B5_anon_69121 ch_19;
    zT_52CEF798_anon_69131 ms;
    zT_4ACEEB00_anon_69139 ic;
    zT_002B266D_anon_69451 ic_20;
    zT_76280E98_anon_69463 ww;
    zT_D8D20921_anon_69147 fc;
    zT_DAD44ADE_anon_69155 pc;
    zT_C4D666D3_anon_69163 itf;
    zT_CED67691_anon_69169 pti;
    zT_48D97536_anon_69177 itp;
    zT_A3CD9C27_anon_69233 ll;
    zT_9DCD92B5_anon_69239 sl;
    zT_0DD2C033_anon_69255 sg;
    zT_9FDA61CE_anon_69267 pv;
    zT_1DD75691_anon_69271 bpc;
    zT_1FD759B7_anon_69277 b_21;
    zT_8BB7B010_anon_69283 b_22;
    zT_09B4A4D3_anon_69291 be;
    zT_0DB4AB1F_anon_69295 bsm;
    zT_1F33EDF3_anon_69303 bcg;
    zT_2933FDB1_anon_69309 bcc;
    zT_A92A39D5_anon_69341 ct;
    zT_3 = inst.tag;
switch (zT_3) {
case 2: goto z_bb_1;
case 3: goto z_bb_2;
case 4: goto z_bb_3;
case 6: goto z_bb_4;
case 7: goto z_bb_5;
case 9: goto z_bb_6;
case 12: goto z_bb_7;
case 13: goto z_bb_8;
case 72: goto z_bb_9;
case 73: goto z_bb_10;
case 74: goto z_bb_11;
case 75: goto z_bb_12;
case 76: goto z_bb_13;
case 77: goto z_bb_14;
case 14: goto z_bb_15;
case 15: goto z_bb_16;
case 68: goto z_bb_17;
case 16: goto z_bb_18;
case 69: goto z_bb_19;
case 17: goto z_bb_20;
case 18: goto z_bb_21;
case 19: goto z_bb_22;
case 20: goto z_bb_23;
case 21: goto z_bb_24;
case 22: goto z_bb_25;
case 23: goto z_bb_26;
case 24: goto z_bb_27;
case 25: goto z_bb_28;
case 26: goto z_bb_29;
case 27: goto z_bb_30;
case 29: goto z_bb_31;
case 78: goto z_bb_32;
case 30: goto z_bb_33;
case 31: goto z_bb_34;
case 32: goto z_bb_35;
case 33: goto z_bb_36;
case 34: goto z_bb_37;
case 35: goto z_bb_38;
case 36: goto z_bb_39;
case 37: goto z_bb_40;
case 38: goto z_bb_41;
case 80: goto z_bb_42;
case 81: goto z_bb_43;
case 39: goto z_bb_44;
case 40: goto z_bb_45;
case 41: goto z_bb_46;
case 42: goto z_bb_47;
case 43: goto z_bb_48;
case 52: goto z_bb_49;
case 53: goto z_bb_50;
case 55: goto z_bb_51;
case 57: goto z_bb_52;
case 58: goto z_bb_53;
case 59: goto z_bb_54;
case 60: goto z_bb_55;
case 62: goto z_bb_56;
case 63: goto z_bb_57;
case 65: goto z_bb_58;
case 66: goto z_bb_59;
case 71: goto z_bb_60;
default: goto z_bb_61;
}
    z_bb_1:
    a = inst.payload.assign._0;
    zT_5 = a.src;
    if ((int)(zT_5 == v)) goto z_bb_64; else goto z_bb_65;
    z_bb_2:
    a_1 = inst.payload.assign_field._0;
    zT_9 = a_1.base;
    if ((int)(zT_9 == v)) goto z_bb_67; else goto z_bb_66;
    z_bb_3:
    a_2 = inst.payload.assign_index._0;
    zT_16 = a_2.base;
    if ((int)(zT_16 == v)) goto z_bb_72; else goto z_bb_71;
    z_bb_4:
    b = inst.payload.branch._0;
    zT_26 = b.cond;
    if ((int)(zT_26 == v)) goto z_bb_79; else goto z_bb_80;
    z_bb_5:
    s = inst.payload.switch_br._0;
    zT_30 = s.cond;
    if ((int)(zT_30 == v)) goto z_bb_81; else goto z_bb_82;
    z_bb_6:
    r = inst.payload.jump._0;
    if ((int)(r == v)) goto z_bb_83; else goto z_bb_84;
    z_bb_7:
    b_3 = inst.payload.binary._0;
    zT_37 = b_3.lhs;
    if ((int)(zT_37 == v)) goto z_bb_86; else goto z_bb_85;
    z_bb_8:
    u = inst.payload.unary._0;
    zT_44 = u.operand;
    if ((int)(zT_44 == v)) goto z_bb_90; else goto z_bb_91;
    z_bb_9:
    o = inst.payload.add_with_overflow._0;
    zT_48 = o.lhs;
    if ((int)(zT_48 == v)) goto z_bb_93; else goto z_bb_92;
    z_bb_10:
    o_4 = inst.payload.sub_with_overflow._0;
    zT_55 = o_4.lhs;
    if ((int)(zT_55 == v)) goto z_bb_98; else goto z_bb_97;
    z_bb_11:
    o_5 = inst.payload.mul_with_overflow._0;
    zT_62 = o_5.lhs;
    if ((int)(zT_62 == v)) goto z_bb_103; else goto z_bb_102;
    z_bb_12:
    o_6 = inst.payload.shl_with_overflow._0;
    zT_69 = o_6.lhs;
    if ((int)(zT_69 == v)) goto z_bb_108; else goto z_bb_107;
    z_bb_13:
    o_7 = inst.payload.neg_with_overflow._0;
    zT_76 = o_7.value;
    if ((int)(zT_76 == v)) goto z_bb_112; else goto z_bb_113;
    z_bb_14:
    o_8 = inst.payload.overflow_flag._0;
    zT_80 = o_8.lhs;
    if ((int)(zT_80 == v)) goto z_bb_115; else goto z_bb_114;
    z_bb_15:
    cl = inst.payload.call._0;
    zT_87 = cl.callee;
    if ((int)(zT_87 == v)) goto z_bb_119; else goto z_bb_120;
    z_bb_16:
    lf = inst.payload.load_field._0;
    zT_99 = lf.base;
    if ((int)(zT_99 == v)) goto z_bb_126; else goto z_bb_127;
    z_bb_17:
    lb = inst.payload.load_bitfield._0;
    zT_103 = lb.base;
    if ((int)(zT_103 == v)) goto z_bb_128; else goto z_bb_129;
    z_bb_18:
    sf = inst.payload.store_field._0;
    zT_107 = sf.base;
    if ((int)(zT_107 == v)) goto z_bb_131; else goto z_bb_130;
    z_bb_19:
    sb = inst.payload.store_bitfield._0;
    zT_114 = sb.base;
    if ((int)(zT_114 == v)) goto z_bb_136; else goto z_bb_135;
    z_bb_20:
    li = inst.payload.load_index._0;
    zT_121 = li.base;
    if ((int)(zT_121 == v)) goto z_bb_141; else goto z_bb_140;
    z_bb_21:
    l = inst.payload.load._0;
    zT_128 = l.ptr;
    if ((int)(zT_128 == v)) goto z_bb_145; else goto z_bb_146;
    z_bb_22:
    st = inst.payload.store._0;
    zT_132 = st.ptr;
    if ((int)(zT_132 == v)) goto z_bb_148; else goto z_bb_147;
    z_bb_23:
    a_9 = inst.payload.addr_of._0;
    zT_139 = a_9.operand;
    if ((int)(zT_139 == v)) goto z_bb_152; else goto z_bb_153;
    z_bb_24:
    a_10 = inst.payload.addr_of_field._0;
    zT_143 = a_10.base;
    if ((int)(zT_143 == v)) goto z_bb_154; else goto z_bb_155;
    z_bb_25:
    w = inst.payload.wrap_optional._0;
    zT_147 = w.value;
    if ((int)(zT_147 == v)) goto z_bb_156; else goto z_bb_157;
    z_bb_26:
    slot = inst.payload.jump._0;
    zT_152 = c->lir_fn;
    zT_153 = slot;
    zT_155 = zF_75DE985C_lirSideGetCallDirec(zT_152, zT_153);
    cd = zT_155;
    zT_156 = cd.args_start;
    if ((int)(v >= zT_156)) goto z_bb_158; else goto z_bb_159;
    z_bb_27:
    vs = inst.payload.va_start._0;
    zT_165 = vs.va_list_temp;
    if ((int)(zT_165 == v)) goto z_bb_164; else goto z_bb_163;
    z_bb_28:
    va = inst.payload.va_arg._0;
    zT_172 = va.va_list_temp;
    if ((int)(zT_172 == v)) goto z_bb_168; else goto z_bb_169;
    z_bb_29:
    ve = inst.payload.va_end._0;
    zT_176 = ve.va_list_temp;
    if ((int)(zT_176 == v)) goto z_bb_170; else goto z_bb_171;
    z_bb_30:
    slot_11 = inst.payload.jump._0;
    zT_181 = c->lir_fn;
    zT_182 = slot_11;
    zT_184 = zF_1AB3807F_lirSideGetTailCall(zT_181, zT_182);
    tc = zT_184;
    zT_185 = tc.is_indirect;
    if ((int)(zT_185 != (unsigned char)(0))) goto z_bb_172; else goto z_bb_173;
    z_bb_31:
    u_12 = inst.payload.unwrap_optional._0;
    zT_201 = u_12.value;
    if ((int)(zT_201 == v)) goto z_bb_182; else goto z_bb_183;
    z_bb_32:
    u_13 = inst.payload.unwrap_optional_checked._0;
    zT_205 = u_13.value;
    if ((int)(zT_205 == v)) goto z_bb_184; else goto z_bb_185;
    z_bb_33:
    u_14 = inst.payload.unwrap_optional_abi._0;
    zT_209 = u_14.value;
    if ((int)(zT_209 == v)) goto z_bb_186; else goto z_bb_187;
    z_bb_34:
    ch = inst.payload.check_optional._0;
    zT_213 = ch.value;
    if ((int)(zT_213 == v)) goto z_bb_188; else goto z_bb_189;
    z_bb_35:
    w_15 = inst.payload.wrap_error_ok._0;
    zT_217 = w_15.value;
    if ((int)(zT_217 == v)) goto z_bb_190; else goto z_bb_191;
    z_bb_36:
    w_16 = inst.payload.wrap_error_err._0;
    zT_221 = w_16.value;
    if ((int)(zT_221 == v)) goto z_bb_192; else goto z_bb_193;
    z_bb_37:
    u_17 = inst.payload.unwrap_error_payload._0;
    zT_225 = u_17.value;
    if ((int)(zT_225 == v)) goto z_bb_194; else goto z_bb_195;
    z_bb_38:
    u_18 = inst.payload.unwrap_error_code._0;
    zT_229 = u_18.value;
    if ((int)(zT_229 == v)) goto z_bb_196; else goto z_bb_197;
    z_bb_39:
    ch_19 = inst.payload.check_error._0;
    zT_233 = ch_19.value;
    if ((int)(zT_233 == v)) goto z_bb_198; else goto z_bb_199;
    z_bb_40:
    ms = inst.payload.make_slice._0;
    zT_237 = ms.ptr;
    if ((int)(zT_237 == v)) goto z_bb_201; else goto z_bb_200;
    z_bb_41:
    ic = inst.payload.int_cast._0;
    zT_244 = ic.value;
    if ((int)(zT_244 == v)) goto z_bb_205; else goto z_bb_206;
    z_bb_42:
    ic_20 = inst.payload.int_cast_checked._0;
    zT_248 = ic_20.value;
    if ((int)(zT_248 == v)) goto z_bb_207; else goto z_bb_208;
    z_bb_43:
    ww = inst.payload.width_wrap._0;
    zT_252 = ww.value;
    if ((int)(zT_252 == v)) goto z_bb_209; else goto z_bb_210;
    z_bb_44:
    fc = inst.payload.float_cast._0;
    zT_256 = fc.value;
    if ((int)(zT_256 == v)) goto z_bb_211; else goto z_bb_212;
    z_bb_45:
    pc = inst.payload.ptr_cast._0;
    zT_260 = pc.value;
    if ((int)(zT_260 == v)) goto z_bb_213; else goto z_bb_214;
    z_bb_46:
    itf = inst.payload.int_to_float._0;
    zT_264 = itf.value;
    if ((int)(zT_264 == v)) goto z_bb_215; else goto z_bb_216;
    z_bb_47:
    pti = inst.payload.ptr_to_int._0;
    zT_268 = pti.value;
    if ((int)(zT_268 == v)) goto z_bb_217; else goto z_bb_218;
    z_bb_48:
    itp = inst.payload.int_to_ptr._0;
    zT_272 = itp.value;
    if ((int)(zT_272 == v)) goto z_bb_219; else goto z_bb_220;
    z_bb_49:
    ll = inst.payload.load_local._0;
    zT_276 = c;
    zT_277 = ll.name_id;
    zT_279 = zF_CD424A09_localStorage(zT_276, zT_277);
    if ((int)(zT_279 == v)) goto z_bb_221; else goto z_bb_222;
    z_bb_50:
    sl = inst.payload.store_local._0;
    zT_283 = sl.value;
    if ((int)(zT_283 == v)) goto z_bb_223; else goto z_bb_224;
    z_bb_51:
    sg = inst.payload.store_global._0;
    zT_287 = sg.value;
    if ((int)(zT_287 == v)) goto z_bb_225; else goto z_bb_226;
    z_bb_52:
    pv = inst.payload.print_val._0;
    zT_291 = pv.value;
    if ((int)(zT_291 == v)) goto z_bb_227; else goto z_bb_228;
    z_bb_53:
    bpc = inst.payload.builtin_put_char._0;
    zT_295 = bpc.value;
    if ((int)(zT_295 == v)) goto z_bb_229; else goto z_bb_230;
    z_bb_54:
    b_21 = inst.payload.builtin_stdout_write._0;
    zT_299 = b_21.ptr;
    if ((int)(zT_299 == v)) goto z_bb_232; else goto z_bb_231;
    z_bb_55:
    b_22 = inst.payload.builtin_stderr_write._0;
    zT_306 = b_22.ptr;
    if ((int)(zT_306 == v)) goto z_bb_237; else goto z_bb_236;
    z_bb_56:
    be = inst.payload.builtin_exit._0;
    zT_313 = be.value;
    if ((int)(zT_313 == v)) goto z_bb_241; else goto z_bb_242;
    z_bb_57:
    bsm = inst.payload.builtin_sleep_ms._0;
    zT_317 = bsm.value;
    if ((int)(zT_317 == v)) goto z_bb_243; else goto z_bb_244;
    z_bb_58:
    bcg = inst.payload.builtin_console_gotoxy._0;
    zT_321 = bcg.x;
    if ((int)(zT_321 == v)) goto z_bb_246; else goto z_bb_245;
    z_bb_59:
    bcc = inst.payload.builtin_console_set_color._0;
    zT_328 = bcc.fg;
    if ((int)(zT_328 == v)) goto z_bb_251; else goto z_bb_250;
    z_bb_60:
    ct = inst.payload.check_trap._0;
    zT_335 = ct.cond;
    if ((int)(zT_335 == v)) goto z_bb_255; else goto z_bb_256;
    z_bb_61:
    goto z_bb_63;
    z_bb_63:
    return (int)(0);
    z_bb_64:
    return (int)(1);
    z_bb_65:
    goto z_bb_63;
    z_bb_66:
    zT_12 = a_1.src;
    zT_11 = zT_12 == v;
    goto z_bb_68;
    z_bb_67:
    zT_11 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_11) goto z_bb_69; else goto z_bb_70;
    z_bb_69:
    return (int)(1);
    z_bb_70:
    goto z_bb_63;
    z_bb_71:
    zT_19 = a_2.index;
    zT_18 = zT_19 == v;
    goto z_bb_73;
    z_bb_72:
    zT_18 = 1;
    goto z_bb_73;
    z_bb_73:
    if (zT_18) goto z_bb_75; else goto z_bb_74;
    z_bb_74:
    zT_22 = a_2.src;
    zT_21 = zT_22 == v;
    goto z_bb_76;
    z_bb_75:
    zT_21 = 1;
    goto z_bb_76;
    z_bb_76:
    if (zT_21) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    return (int)(1);
    z_bb_78:
    goto z_bb_63;
    z_bb_79:
    return (int)(1);
    z_bb_80:
    goto z_bb_63;
    z_bb_81:
    return (int)(1);
    z_bb_82:
    goto z_bb_63;
    z_bb_83:
    return (int)(1);
    z_bb_84:
    goto z_bb_63;
    z_bb_85:
    zT_40 = b_3.rhs;
    zT_39 = zT_40 == v;
    goto z_bb_87;
    z_bb_86:
    zT_39 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_39) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    return (int)(1);
    z_bb_89:
    goto z_bb_63;
    z_bb_90:
    return (int)(1);
    z_bb_91:
    goto z_bb_63;
    z_bb_92:
    zT_51 = o.rhs;
    zT_50 = zT_51 == v;
    goto z_bb_94;
    z_bb_93:
    zT_50 = 1;
    goto z_bb_94;
    z_bb_94:
    if (zT_50) goto z_bb_95; else goto z_bb_96;
    z_bb_95:
    return (int)(1);
    z_bb_96:
    goto z_bb_63;
    z_bb_97:
    zT_58 = o_4.rhs;
    zT_57 = zT_58 == v;
    goto z_bb_99;
    z_bb_98:
    zT_57 = 1;
    goto z_bb_99;
    z_bb_99:
    if (zT_57) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    return (int)(1);
    z_bb_101:
    goto z_bb_63;
    z_bb_102:
    zT_65 = o_5.rhs;
    zT_64 = zT_65 == v;
    goto z_bb_104;
    z_bb_103:
    zT_64 = 1;
    goto z_bb_104;
    z_bb_104:
    if (zT_64) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    return (int)(1);
    z_bb_106:
    goto z_bb_63;
    z_bb_107:
    zT_72 = o_6.rhs;
    zT_71 = zT_72 == v;
    goto z_bb_109;
    z_bb_108:
    zT_71 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_71) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    return (int)(1);
    z_bb_111:
    goto z_bb_63;
    z_bb_112:
    return (int)(1);
    z_bb_113:
    goto z_bb_63;
    z_bb_114:
    zT_83 = o_8.rhs;
    zT_82 = zT_83 == v;
    goto z_bb_116;
    z_bb_115:
    zT_82 = 1;
    goto z_bb_116;
    z_bb_116:
    if (zT_82) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    return (int)(1);
    z_bb_118:
    goto z_bb_63;
    z_bb_119:
    return (int)(1);
    z_bb_120:
    zT_90 = cl.args_start;
    if ((int)(v >= zT_90)) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_93 = cl.args_start;
    zT_94 = cl.args_count;
    zT_92 = v < (unsigned int)(zT_93 + zT_94);
    goto z_bb_123;
    z_bb_122:
    zT_92 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_92) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    return (int)(1);
    z_bb_125:
    goto z_bb_63;
    z_bb_126:
    return (int)(1);
    z_bb_127:
    goto z_bb_63;
    z_bb_128:
    return (int)(1);
    z_bb_129:
    goto z_bb_63;
    z_bb_130:
    zT_110 = sf.value;
    zT_109 = zT_110 == v;
    goto z_bb_132;
    z_bb_131:
    zT_109 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_109) goto z_bb_133; else goto z_bb_134;
    z_bb_133:
    return (int)(1);
    z_bb_134:
    goto z_bb_63;
    z_bb_135:
    zT_117 = sb.value;
    zT_116 = zT_117 == v;
    goto z_bb_137;
    z_bb_136:
    zT_116 = 1;
    goto z_bb_137;
    z_bb_137:
    if (zT_116) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    return (int)(1);
    z_bb_139:
    goto z_bb_63;
    z_bb_140:
    zT_124 = li.index;
    zT_123 = zT_124 == v;
    goto z_bb_142;
    z_bb_141:
    zT_123 = 1;
    goto z_bb_142;
    z_bb_142:
    if (zT_123) goto z_bb_143; else goto z_bb_144;
    z_bb_143:
    return (int)(1);
    z_bb_144:
    goto z_bb_63;
    z_bb_145:
    return (int)(1);
    z_bb_146:
    goto z_bb_63;
    z_bb_147:
    zT_135 = st.value;
    zT_134 = zT_135 == v;
    goto z_bb_149;
    z_bb_148:
    zT_134 = 1;
    goto z_bb_149;
    z_bb_149:
    if (zT_134) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    return (int)(1);
    z_bb_151:
    goto z_bb_63;
    z_bb_152:
    return (int)(1);
    z_bb_153:
    goto z_bb_63;
    z_bb_154:
    return (int)(1);
    z_bb_155:
    goto z_bb_63;
    z_bb_156:
    return (int)(1);
    z_bb_157:
    goto z_bb_63;
    z_bb_158:
    zT_159 = cd.args_start;
    zT_160 = cd.args_count;
    zT_158 = v < (unsigned int)(zT_159 + zT_160);
    goto z_bb_160;
    z_bb_159:
    zT_158 = 0;
    goto z_bb_160;
    z_bb_160:
    if (zT_158) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    return (int)(1);
    z_bb_162:
    goto z_bb_63;
    z_bb_163:
    zT_168 = vs.last_param_temp;
    zT_167 = zT_168 == v;
    goto z_bb_165;
    z_bb_164:
    zT_167 = 1;
    goto z_bb_165;
    z_bb_165:
    if (zT_167) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    return (int)(1);
    z_bb_167:
    goto z_bb_63;
    z_bb_168:
    return (int)(1);
    z_bb_169:
    goto z_bb_63;
    z_bb_170:
    return (int)(1);
    z_bb_171:
    goto z_bb_63;
    z_bb_172:
    zT_189 = tc.callee;
    zT_188 = zT_189 == v;
    goto z_bb_174;
    z_bb_173:
    zT_188 = 0;
    goto z_bb_174;
    z_bb_174:
    if (zT_188) goto z_bb_175; else goto z_bb_176;
    z_bb_175:
    return (int)(1);
    z_bb_176:
    zT_192 = tc.args_start;
    if ((int)(v >= zT_192)) goto z_bb_177; else goto z_bb_178;
    z_bb_177:
    zT_195 = tc.args_start;
    zT_196 = tc.args_count;
    zT_194 = v < (unsigned int)(zT_195 + zT_196);
    goto z_bb_179;
    z_bb_178:
    zT_194 = 0;
    goto z_bb_179;
    z_bb_179:
    if (zT_194) goto z_bb_180; else goto z_bb_181;
    z_bb_180:
    return (int)(1);
    z_bb_181:
    goto z_bb_63;
    z_bb_182:
    return (int)(1);
    z_bb_183:
    goto z_bb_63;
    z_bb_184:
    return (int)(1);
    z_bb_185:
    goto z_bb_63;
    z_bb_186:
    return (int)(1);
    z_bb_187:
    goto z_bb_63;
    z_bb_188:
    return (int)(1);
    z_bb_189:
    goto z_bb_63;
    z_bb_190:
    return (int)(1);
    z_bb_191:
    goto z_bb_63;
    z_bb_192:
    return (int)(1);
    z_bb_193:
    goto z_bb_63;
    z_bb_194:
    return (int)(1);
    z_bb_195:
    goto z_bb_63;
    z_bb_196:
    return (int)(1);
    z_bb_197:
    goto z_bb_63;
    z_bb_198:
    return (int)(1);
    z_bb_199:
    goto z_bb_63;
    z_bb_200:
    zT_240 = ms.len;
    zT_239 = zT_240 == v;
    goto z_bb_202;
    z_bb_201:
    zT_239 = 1;
    goto z_bb_202;
    z_bb_202:
    if (zT_239) goto z_bb_203; else goto z_bb_204;
    z_bb_203:
    return (int)(1);
    z_bb_204:
    goto z_bb_63;
    z_bb_205:
    return (int)(1);
    z_bb_206:
    goto z_bb_63;
    z_bb_207:
    return (int)(1);
    z_bb_208:
    goto z_bb_63;
    z_bb_209:
    return (int)(1);
    z_bb_210:
    goto z_bb_63;
    z_bb_211:
    return (int)(1);
    z_bb_212:
    goto z_bb_63;
    z_bb_213:
    return (int)(1);
    z_bb_214:
    goto z_bb_63;
    z_bb_215:
    return (int)(1);
    z_bb_216:
    goto z_bb_63;
    z_bb_217:
    return (int)(1);
    z_bb_218:
    goto z_bb_63;
    z_bb_219:
    return (int)(1);
    z_bb_220:
    goto z_bb_63;
    z_bb_221:
    return (int)(1);
    z_bb_222:
    goto z_bb_63;
    z_bb_223:
    return (int)(1);
    z_bb_224:
    goto z_bb_63;
    z_bb_225:
    return (int)(1);
    z_bb_226:
    goto z_bb_63;
    z_bb_227:
    return (int)(1);
    z_bb_228:
    goto z_bb_63;
    z_bb_229:
    return (int)(1);
    z_bb_230:
    goto z_bb_63;
    z_bb_231:
    zT_302 = b_21.len;
    zT_301 = zT_302 == v;
    goto z_bb_233;
    z_bb_232:
    zT_301 = 1;
    goto z_bb_233;
    z_bb_233:
    if (zT_301) goto z_bb_234; else goto z_bb_235;
    z_bb_234:
    return (int)(1);
    z_bb_235:
    goto z_bb_63;
    z_bb_236:
    zT_309 = b_22.len;
    zT_308 = zT_309 == v;
    goto z_bb_238;
    z_bb_237:
    zT_308 = 1;
    goto z_bb_238;
    z_bb_238:
    if (zT_308) goto z_bb_239; else goto z_bb_240;
    z_bb_239:
    return (int)(1);
    z_bb_240:
    goto z_bb_63;
    z_bb_241:
    return (int)(1);
    z_bb_242:
    goto z_bb_63;
    z_bb_243:
    return (int)(1);
    z_bb_244:
    goto z_bb_63;
    z_bb_245:
    zT_324 = bcg.y;
    zT_323 = zT_324 == v;
    goto z_bb_247;
    z_bb_246:
    zT_323 = 1;
    goto z_bb_247;
    z_bb_247:
    if (zT_323) goto z_bb_248; else goto z_bb_249;
    z_bb_248:
    return (int)(1);
    z_bb_249:
    goto z_bb_63;
    z_bb_250:
    zT_331 = bcc.bg;
    zT_330 = zT_331 == v;
    goto z_bb_252;
    z_bb_251:
    zT_330 = 1;
    goto z_bb_252;
    z_bb_252:
    if (zT_330) goto z_bb_253; else goto z_bb_254;
    z_bb_253:
    return (int)(1);
    z_bb_254:
    goto z_bb_63;
    z_bb_255:
    return (int)(1);
    z_bb_256:
    goto z_bb_63;
}

/* instIsSuspendPoint */
int zF_1AAC25A7_instIsSuspendPoint(zT_6D148508_Scan* c, zT_6BA597BC_LirInst inst, zT_A4CE86B7_U64ToU32Map* suspending_fns) {
    unsigned int zT_3;
    zT_BBC23664_LirFunction* zT_6;
    unsigned int zT_7;
    zT_3BFB1E70_CallDirectData zT_9 = {0};
    zT_A4CE86B7_U64ToU32Map* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_15 = 0;
    zT_79FAE712_u64 zT_17;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    int zT_32 = 0;
    unsigned int slot;
    zT_3BFB1E70_CallDirectData cd;
    zT_54DBC6B1_anon_69183 ic;
    zT_3 = inst.tag;
switch (zT_3) {
case 23: goto z_bb_1;
case 44: goto z_bb_2;
default: goto z_bb_3;
}
    z_bb_1:
    slot = inst.payload.jump._0;
    zT_6 = c->lir_fn;
    zT_7 = slot;
    zT_9 = zF_75DE985C_lirSideGetCallDirec(zT_6, zT_7);
    cd = zT_9;
    zT_10 = suspending_fns;
    zT_11 = cd.module_id;
    zT_12 = cd.name_id;
    zT_15 = zF_7C7E43BF_asyncIsSuspending(zT_10, zT_11, zT_12);
    return zT_15;
    z_bb_2:
    ic = inst.payload.int_const._0;
    zT_17 = ic.value;
    if ((int)(zT_17 != (zT_79FAE712_u64)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_3:
    return (int)(0);
    return 0;
    z_bb_6:
    return (int)(0);
    z_bb_7:
    zT_21 = ic.result;
    zT_22 = c->max_temp;
    if ((int)(zT_21 >= zT_22)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (int)(0);
    z_bb_9:
    zT_25 = c->reg;
    zT_28 = c->ttype;
    zT_29 = ic.result;
    zT_30 = (unsigned int)zT_29;
    zT_26 = zT_28[zT_30];
    zT_32 = zF_5049D2D3_typeIsPtrVoid(zT_25, zT_26);
    return zT_32;
}

/* hasDefBefore */
int zF_93E9604D_hasDefBefore(zT_6D148508_Scan* c, unsigned int v, unsigned int sbb, unsigned int sii) {
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_7;
    unsigned int zT_8;
    zT_BBC23664_LirFunction* zT_13;
    zT_1CF28CA3_BasicBlockArrayList zT_14;
    zT_88A68B1A_BasicBlock* zT_15;
    zT_88A68B1A_BasicBlock* zT_16;
    unsigned int zT_18;
    zT_DAE4631D_LirInstArrayList zT_19;
    unsigned int zT_20;
    int zT_24;
    zT_6D148508_Scan* zT_27;
    zT_6BA597BC_LirInst zT_28;
    unsigned int zT_29;
    zT_DAE4631D_LirInstArrayList zT_30;
    zT_6BA597BC_LirInst* zT_31;
    zT_6BA597BC_LirInst zT_32;
    int zT_33 = 0;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_5 = 0;
    bi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = c->lir_fn;
    zT_7 = zT_6->blocks;
    zT_8 = zT_7.len;
    if ((int)(bi < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    if ((int)((unsigned int)((unsigned int)bi) > sbb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_38 = bi + (unsigned int)(1);
    bi = zT_38;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_3;
    z_bb_6:
    zT_13 = c->lir_fn;
    zT_14 = zT_13->blocks;
    zT_15 = zT_14.items;
    zT_16 = zT_15 + bi;
    bb = zT_16;
    zT_18 = 0;
    ii = zT_18;
    goto z_bb_7;
    z_bb_7:
    zT_19 = bb->insts;
    zT_20 = zT_19.len;
    if ((int)(ii < zT_20)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    if ((int)((unsigned int)((unsigned int)bi) == sbb)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_36 = ii + (unsigned int)(1);
    ii = zT_36;
    goto z_bb_7;
    z_bb_11:
    zT_24 = (unsigned int)((unsigned int)ii) >= sii;
    goto z_bb_13;
    z_bb_12:
    zT_24 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_24) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_27 = c;
    zT_30 = bb->insts;
    zT_31 = zT_30.items;
    zT_32 = zT_31[ii];
    zT_28 = zT_32;
    zT_29 = v;
    zT_33 = zF_1FF90D33_instDefsTemp(zT_27, zT_28, zT_29);
    if (zT_33) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return (int)(1);
    z_bb_17:
    goto z_bb_10;
}

/* hasReadAfter */
int zF_4CED5DFF_hasReadAfter(zT_6D148508_Scan* c, unsigned int v, unsigned int sbb, unsigned int sii) {
    unsigned int zT_5;
    zT_BBC23664_LirFunction* zT_6;
    zT_1CF28CA3_BasicBlockArrayList zT_7;
    unsigned int zT_8;
    zT_BBC23664_LirFunction* zT_11;
    zT_1CF28CA3_BasicBlockArrayList zT_12;
    zT_88A68B1A_BasicBlock* zT_13;
    zT_88A68B1A_BasicBlock* zT_14;
    unsigned int zT_16;
    unsigned int zT_21;
    zT_DAE4631D_LirInstArrayList zT_22;
    unsigned int zT_23;
    zT_6D148508_Scan* zT_25;
    zT_6BA597BC_LirInst zT_26;
    unsigned int zT_27;
    zT_DAE4631D_LirInstArrayList zT_28;
    zT_6BA597BC_LirInst* zT_29;
    zT_6BA597BC_LirInst zT_30;
    int zT_31 = 0;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    zT_5 = (unsigned int)sbb;
    bi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = c->lir_fn;
    zT_7 = zT_6->blocks;
    zT_8 = zT_7.len;
    if ((int)(bi < zT_8)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = c->lir_fn;
    zT_12 = zT_11->blocks;
    zT_13 = zT_12.items;
    zT_14 = zT_13 + bi;
    bb = zT_14;
    zT_16 = 0;
    ii = zT_16;
    if ((int)((unsigned int)((unsigned int)bi) == sbb)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)(0);
    z_bb_4:
    zT_36 = bi + (unsigned int)(1);
    bi = zT_36;
    goto z_bb_1;
    z_bb_5:
    zT_21 = (unsigned int)((unsigned int)sii) + (unsigned int)(1);
    ii = zT_21;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_7;
    z_bb_7:
    zT_22 = bb->insts;
    zT_23 = zT_22.len;
    if ((int)(ii < zT_23)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = c;
    zT_28 = bb->insts;
    zT_29 = zT_28.items;
    zT_30 = zT_29[ii];
    zT_26 = zT_30;
    zT_27 = v;
    zT_31 = zF_E4C3429C_instReadsTemp(zT_25, zT_26, zT_27);
    if (zT_31) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_34 = ii + (unsigned int)(1);
    ii = zT_34;
    goto z_bb_7;
    z_bb_11:
    return (int)(1);
    z_bb_12:
    goto z_bb_10;
}

/* addField */
void zF_F2801F08_addField(zT_2CF63CE1_AsyncFrameFieldArra* fields, zT_338B7C76_TypeRegistry* reg, unsigned char kind, unsigned int name_id, unsigned int temp_id, unsigned int type_id, unsigned int* offset, unsigned int* max_align) {
    unsigned int zT_9;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int* zT_14;
    unsigned int* zT_15;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned int* zT_22;
    unsigned int zT_23 = 0;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_24;
    zT_902E38E8_AsyncFrameField zT_25;
    zT_902E38E8_AsyncFrameField zT_26;
    unsigned int size;
    unsigned int alignment;
    unsigned int at;
    zT_9 = 0;
    size = zT_9;
    zT_11 = 0;
    alignment = zT_11;
    zT_12 = reg;
    zT_13 = type_id;
    zT_14 = &size;
    zT_15 = &alignment;
    zF_816D1610_frameFieldSizeAlign(zT_12, zT_13, zT_14, zT_15);
    zT_19 = reg;
    zT_20 = type_id;
    zT_21 = offset;
    zT_22 = max_align;
    zT_23 = zF_769CB99B_addFrameField(zT_19, zT_20, zT_21, zT_22);
    at = zT_23;
    zT_24 = fields;
    zT_26.kind = kind;
    zT_26.name_id = name_id;
    zT_26.temp_id = temp_id;
    zT_26.type_id = type_id;
    zT_26.offset = at;
    zT_26.size = size;
    zT_26.alignment = alignment;
    zT_25 = zT_26;
    zF_92FA7DBC_fieldArrayListAppen(zT_24, zT_25);
    return;
}

/* emitLayoutMarker */
void zF_2B302EFE_emitLayoutMarker(unsigned int module_id, unsigned int name_id, unsigned int size) {
    char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_5826BFC7_Arr_unsigned_char_1 zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned char* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_5826BFC7_Arr_unsigned_char_1 zT_38;
    unsigned int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned char* zT_58;
    unsigned int zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    zT_5826BFC7_Arr_unsigned_char_1 zT_67;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    int zT_73;
    unsigned char* zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77 = 0;
    unsigned int zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned char* zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    char* zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int zT_93;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u m1;
    zT_5826BFC7_Arr_unsigned_char_1 b1;
    unsigned int l1;
    unsigned int s1;
    zT_8F083A69_Slice_zT_0B42B2F8_u m2;
    zT_5826BFC7_Arr_unsigned_char_1 b2;
    unsigned int l2;
    unsigned int s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u m3;
    zT_5826BFC7_Arr_unsigned_char_1 b3;
    unsigned int l3;
    unsigned int s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u m4;
    zT_4 = "LAYOUT:m";
    zT_6 = 8;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    m1 = zT_5;
    zT_7 = m1;
    zF_48AC7B3A_markerWrite(zT_7);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_9[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b1[_i] = zT_9[_i];
        _i++;
    }
}
    zT_11 = module_id;
    zT_15 = 0;
    zT_16 = (unsigned char*)((unsigned char*)b1) + zT_15;
    zT_17 = (unsigned int)(12) - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    l1 = zT_19;
    zT_24 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l1));
    s1 = zT_24;
    zT_29 = (unsigned char*)((unsigned char*)b1) + s1;
    zT_30 = (unsigned int)(11) - s1;
    zT_31.ptr = zT_29;
    zT_31.len = zT_30;
    zT_25 = zT_31;
    zF_48AC7B3A_markerWrite(zT_25);
    zT_33 = ":n";
    zT_35 = 2;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    m2 = zT_34;
    zT_36 = m2;
    zF_48AC7B3A_markerWrite(zT_36);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_38[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b2[_i] = zT_38[_i];
        _i++;
    }
}
    zT_40 = name_id;
    zT_44 = 0;
    zT_45 = (unsigned char*)((unsigned char*)b2) + zT_44;
    zT_46 = (unsigned int)(12) - zT_44;
    zT_47.ptr = zT_45;
    zT_47.len = zT_46;
    zT_41 = zT_47;
    zT_48 = zF_A7504564_itoa(zT_40, zT_41);
    l2 = zT_48;
    zT_53 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l2));
    s2 = zT_53;
    zT_58 = (unsigned char*)((unsigned char*)b2) + s2;
    zT_59 = (unsigned int)(11) - s2;
    zT_60.ptr = zT_58;
    zT_60.len = zT_59;
    zT_54 = zT_60;
    zF_48AC7B3A_markerWrite(zT_54);
    zT_62 = ":s";
    zT_64 = 2;
    zT_63.ptr = zT_62;
    zT_63.len = zT_64;
    m3 = zT_63;
    zT_65 = m3;
    zF_48AC7B3A_markerWrite(zT_65);
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_67[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b3[_i] = zT_67[_i];
        _i++;
    }
}
    zT_69 = size;
    zT_73 = 0;
    zT_74 = (unsigned char*)((unsigned char*)b3) + zT_73;
    zT_75 = (unsigned int)(12) - zT_73;
    zT_76.ptr = zT_74;
    zT_76.len = zT_75;
    zT_70 = zT_76;
    zT_77 = zF_A7504564_itoa(zT_69, zT_70);
    l3 = zT_77;
    zT_82 = (unsigned int)(11) - (unsigned int)((unsigned int)(unsigned int)((unsigned int)l3));
    s3 = zT_82;
    zT_87 = (unsigned char*)((unsigned char*)b3) + s3;
    zT_88 = (unsigned int)(11) - s3;
    zT_89.ptr = zT_87;
    zT_89.len = zT_88;
    zT_83 = zT_89;
    zF_48AC7B3A_markerWrite(zT_83);
    zT_91 = "\n";
    zT_93 = 1;
    zT_92.ptr = zT_91;
    zT_92.len = zT_93;
    m4 = zT_92;
    zT_94 = m4;
    zF_48AC7B3A_markerWrite(zT_94);
    return;
}

/* asyncLayoutFrame */
zT_3F3BF87A_AsyncFrameLayout zF_28031796_asyncLayoutFrame(zT_3E40CD83_Sand* alloc, zT_338B7C76_TypeRegistry* reg, zT_BBC23664_LirFunction* lir_fn, zT_A4CE86B7_U64ToU32Map* suspending_fns, zT_A4CE86B7_U64ToU32Map* frame_sizes, zT_A4CE86B7_U64ToU32Map* state_widths, zT_A4CE86B7_U64ToU32Map* awaited_fns, zT_A4CE86B7_U64ToU32Map* async_hidden_fns, zT_B687BB96_U32ArrayList* parent_result_type_list, zT_A4CE86B7_U64ToU32Map* parent_result_start, zT_A4CE86B7_U64ToU32Map* parent_result_count) {
    zT_BBC23664_LirFunction* zT_12;
    unsigned int zT_13 = 0;
    zT_3E40CD83_Sand* zT_15;
    zT_CFE23D0A_LirParamArrayList zT_17;
    unsigned int zT_18;
    zT_5D72FBF8_TempDeclArrayList zT_19;
    unsigned int zT_20;
    zT_2CF63CE1_AsyncFrameFieldArra zT_24 = {0};
    zT_3E40CD83_Sand* zT_26;
    zT_21D3708C_U32ToU32Map zT_27 = {0};
    zT_6D148508_Scan zT_29;
    zT_3E40CD83_Sand* zT_30;
    unsigned int zT_31;
    unsigned int* zT_34 = 0;
    zT_21D3708C_U32ToU32Map* zT_35;
    unsigned int zT_37;
    zT_5D72FBF8_TempDeclArrayList zT_38;
    unsigned int zT_39;
    zT_5D72FBF8_TempDeclArrayList zT_42;
    zT_1937645B_TempDecl* zT_43;
    zT_1937645B_TempDecl zT_44;
    unsigned int zT_45;
    unsigned int zT_47;
    unsigned int* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_CFE23D0A_LirParamArrayList zT_55;
    unsigned int zT_56;
    zT_CFE23D0A_LirParamArrayList zT_59;
    zT_8779209D_LirParam* zT_60;
    zT_8779209D_LirParam zT_61;
    zT_21D3708C_U32ToU32Map* zT_62;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_69;
    unsigned int zT_71;
    zT_1CF28CA3_BasicBlockArrayList zT_72;
    unsigned int zT_73;
    zT_1CF28CA3_BasicBlockArrayList zT_76;
    zT_88A68B1A_BasicBlock* zT_77;
    zT_88A68B1A_BasicBlock* zT_78;
    unsigned int zT_80;
    zT_DAE4631D_LirInstArrayList zT_81;
    unsigned int zT_82;
    zT_DAE4631D_LirInstArrayList zT_84;
    zT_6BA597BC_LirInst* zT_85;
    zT_6BA597BC_LirInst zT_86;
    unsigned int zT_87;
    zT_21D3708C_U32ToU32Map* zT_89;
    unsigned int zT_90;
    unsigned int zT_91;
    unsigned int zT_96;
    unsigned int zT_98;
    zT_3E40CD83_Sand* zT_100;
    unsigned int zT_101;
    unsigned char* zT_102 = 0;
    unsigned int zT_103;
    zT_CFE23D0A_LirParamArrayList zT_104;
    unsigned int zT_105;
    zT_CFE23D0A_LirParamArrayList zT_108;
    zT_8779209D_LirParam* zT_109;
    zT_8779209D_LirParam zT_110;
    unsigned int zT_111;
    unsigned char zT_113;
    unsigned int zT_114;
    unsigned int zT_116;
    zT_3E40CD83_Sand* zT_118;
    unsigned int zT_119;
    unsigned char* zT_120 = 0;
    unsigned int zT_122;
    unsigned char zT_124;
    unsigned int zT_125;
    unsigned int zT_127;
    unsigned int zT_128;
    zT_1CF28CA3_BasicBlockArrayList zT_129;
    unsigned int zT_130;
    zT_1CF28CA3_BasicBlockArrayList zT_133;
    zT_88A68B1A_BasicBlock* zT_134;
    zT_88A68B1A_BasicBlock* zT_135;
    unsigned int zT_137;
    zT_DAE4631D_LirInstArrayList zT_138;
    unsigned int zT_139;
    zT_DAE4631D_LirInstArrayList zT_142;
    zT_6BA597BC_LirInst* zT_143;
    zT_6BA597BC_LirInst zT_144;
    zT_6D148508_Scan* zT_145;
    zT_6BA597BC_LirInst zT_146;
    zT_A4CE86B7_U64ToU32Map* zT_147;
    int zT_149 = 0;
    unsigned int zT_150;
    unsigned int zT_153;
    unsigned char zT_154;
    zT_6D148508_Scan* zT_157;
    unsigned int zT_158;
    int zT_164 = 0;
    zT_6D148508_Scan* zT_166;
    unsigned int zT_167;
    int zT_173 = 0;
    unsigned char zT_174;
    unsigned int zT_176;
    unsigned int zT_178;
    unsigned int zT_180;
    unsigned int zT_182;
    unsigned int zT_184;
    unsigned int zT_186;
    zT_A4CE86B7_U64ToU32Map* zT_187;
    zT_79FAE712_u64 zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_79FAE712_u64 zT_193 = 0;
    zT_BAEE192E_Opt_10 zT_194 = {0};
    unsigned char zT_195;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_197;
    zT_338B7C76_TypeRegistry* zT_198;
    unsigned char zT_199;
    unsigned int* zT_203;
    unsigned int* zT_204;
    unsigned int zT_206;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_212;
    zT_338B7C76_TypeRegistry* zT_213;
    unsigned char zT_214;
    unsigned int* zT_218;
    unsigned int* zT_219;
    unsigned int zT_221;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_227;
    zT_338B7C76_TypeRegistry* zT_228;
    unsigned char zT_229;
    unsigned int zT_232;
    unsigned int* zT_233;
    unsigned int* zT_234;
    unsigned int zT_236;
    unsigned int zT_241;
    zT_CFE23D0A_LirParamArrayList zT_242;
    unsigned int zT_243;
    zT_CFE23D0A_LirParamArrayList zT_246;
    zT_8779209D_LirParam* zT_247;
    zT_8779209D_LirParam zT_248;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_249;
    zT_338B7C76_TypeRegistry* zT_250;
    unsigned char zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int* zT_255;
    unsigned int* zT_256;
    unsigned int zT_258;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned int zT_269;
    unsigned char zT_270;
    int zT_273;
    unsigned char zT_274;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_277;
    zT_338B7C76_TypeRegistry* zT_278;
    unsigned char zT_279;
    unsigned int zT_281;
    unsigned int zT_282;
    unsigned int* zT_283;
    unsigned int* zT_284;
    unsigned int zT_286;
    unsigned int* zT_288;
    unsigned int zT_293;
    unsigned int zT_295;
    unsigned int zT_297;
    unsigned int zT_298;
    zT_79FAE712_u64 zT_301 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_302;
    zT_79FAE712_u64 zT_303;
    zT_BAEE192E_Opt_10 zT_304 = {0};
    unsigned char zT_305;
    zT_338B7C76_TypeRegistry* zT_308;
    unsigned int zT_313 = 0;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_318;
    zT_338B7C76_TypeRegistry* zT_319;
    unsigned char zT_320;
    unsigned int zT_323;
    unsigned int* zT_324;
    unsigned int* zT_325;
    unsigned int zT_327;
    zT_A4CE86B7_U64ToU32Map* zT_332;
    zT_79FAE712_u64 zT_333;
    zT_BAEE192E_Opt_10 zT_334 = {0};
    unsigned char zT_335;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_336;
    zT_338B7C76_TypeRegistry* zT_337;
    unsigned char zT_338;
    unsigned int zT_341;
    unsigned int* zT_342;
    unsigned int* zT_343;
    unsigned int zT_345;
    unsigned int zT_355;
    zT_A4CE86B7_U64ToU32Map* zT_356;
    zT_79FAE712_u64 zT_357;
    zT_BAEE192E_Opt_10 zT_358 = {0};
    unsigned char zT_359;
    unsigned int zT_362;
    zT_A4CE86B7_U64ToU32Map* zT_363;
    zT_79FAE712_u64 zT_364;
    zT_BAEE192E_Opt_10 zT_365 = {0};
    unsigned char zT_366;
    unsigned int zT_369;
    unsigned int* zT_372;
    unsigned int zT_374;
    unsigned int zT_375;
    zT_2CF63CE1_AsyncFrameFieldArra* zT_376;
    zT_338B7C76_TypeRegistry* zT_377;
    unsigned char zT_378;
    unsigned int zT_381;
    unsigned int* zT_382;
    unsigned int* zT_383;
    unsigned int zT_385;
    unsigned int zT_391;
    unsigned int zT_393;
    unsigned int zT_394;
    unsigned int zT_395 = 0;
    unsigned int zT_398;
    zT_A4CE86B7_U64ToU32Map* zT_400;
    unsigned int zT_401;
    unsigned int zT_402;
    zT_BAEE192E_Opt_10 zT_405 = {0};
    unsigned char zT_407;
    char* zT_410;
    unsigned int zT_411;
    char* zT_412;
    unsigned int zT_413;
    char* zT_414;
    unsigned int zT_415;
    char* zT_417;
    unsigned int zT_418;
    char* zT_419;
    unsigned int zT_420;
    char* zT_421;
    unsigned int zT_422;
    unsigned int zT_424;
    unsigned int zT_425;
    unsigned int zT_426;
    zT_3F3BF87A_AsyncFrameLayout zT_429;
    unsigned int max_temp;
    zT_2CF63CE1_AsyncFrameFieldArra fields;
    zT_21D3708C_U32ToU32Map locals;
    zT_6D148508_Scan c;
    unsigned int hti;
    zT_1937645B_TempDecl td;
    unsigned int pi;
    zT_8779209D_LirParam p;
    unsigned int bi;
    zT_88A68B1A_BasicBlock* bb;
    unsigned int ii;
    unsigned char* is_param;
    zT_48FD9C70_anon_68891 dl;
    unsigned int pt;
    unsigned char* live;
    unsigned int t;
    unsigned int offset;
    unsigned int max_align;
    unsigned int state_type;
    zT_6BA597BC_LirInst inst;
    unsigned int tu;
    unsigned int sw;
    unsigned int hid;
    zT_79FAE712_u64 lay_key;
    unsigned int h;
    unsigned int lay_ptr_void;
    unsigned int pstart;
    unsigned int precise;
    unsigned int ps;
    unsigned int pcount;
    unsigned int pc;
    unsigned int pk;
    unsigned int prt;
    zT_BAEE192E_Opt_10 frame_size;
    unsigned int padded;
    unsigned int fs;
    zT_12 = lir_fn;
    zT_13 = zF_005F8966_maxTempOf(zT_12);
    max_temp = zT_13;
    zT_15 = alloc;
    zT_17 = lir_fn->params;
    zT_18 = zT_17.len;
    zT_19 = lir_fn->hoisted_temps;
    zT_20 = zT_19.len;
    zT_24 = zF_1BFB52BE_fieldArrayListInit(zT_15, (unsigned int)((unsigned int)(zT_18 + zT_20) + (unsigned int)(2)));
    fields = zT_24;
    zT_26 = alloc;
    zT_27 = zF_58BDA2DE_u32ToU32MapInit(zT_26);
    locals = zT_27;
    zT_29.lir_fn = lir_fn;
    zT_29.reg = reg;
    zT_29.max_temp = max_temp;
    zT_30 = alloc;
    zT_31 = max_temp;
    zT_34 = zF_82E88BBC_allocU32With(zT_30, zT_31, (unsigned int)(18));
    zT_29.ttype = zT_34;
    zT_35 = &locals;
    zT_29.locals = zT_35;
    c = zT_29;
    zT_37 = 0;
    hti = zT_37;
    goto z_bb_1;
    z_bb_1:
    zT_38 = lir_fn->hoisted_temps;
    zT_39 = zT_38.len;
    if ((int)(hti < zT_39)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_42 = lir_fn->hoisted_temps;
    zT_43 = zT_42.items;
    zT_44 = zT_43[hti];
    td = zT_44;
    zT_45 = td.temp_id;
    if ((int)(zT_45 < max_temp)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_54 = 0;
    pi = zT_54;
    goto z_bb_7;
    z_bb_4:
    zT_52 = hti + (unsigned int)(1);
    hti = zT_52;
    goto z_bb_1;
    z_bb_5:
    zT_47 = td.type_id;
    zT_48 = c.ttype;
    zT_49 = td.temp_id;
    zT_50 = (unsigned int)zT_49;
    zT_48[zT_50] = zT_47;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_55 = lir_fn->params;
    zT_56 = zT_55.len;
    if ((int)(pi < zT_56)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_59 = lir_fn->params;
    zT_60 = zT_59.items;
    zT_61 = zT_60[pi];
    p = zT_61;
    zT_62 = &locals;
    zT_63 = p.name_id;
    zT_64 = p.temp_id;
    zF_26476265_u32ToU32MapPut(zT_62, zT_63, zT_64);
    (void)alloc;
    goto z_bb_10;
    z_bb_9:
    zT_71 = 0;
    bi = zT_71;
    goto z_bb_11;
    z_bb_10:
    zT_69 = pi + (unsigned int)(1);
    pi = zT_69;
    goto z_bb_7;
    z_bb_11:
    zT_72 = lir_fn->blocks;
    zT_73 = zT_72.len;
    if ((int)(bi < zT_73)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_76 = lir_fn->blocks;
    zT_77 = zT_76.items;
    zT_78 = zT_77 + bi;
    bb = zT_78;
    zT_80 = 0;
    ii = zT_80;
    goto z_bb_15;
    z_bb_13:
    zT_100 = alloc;
    zT_101 = max_temp;
    zT_102 = zF_F15DB413_allocU8Raw(zT_100, zT_101);
    is_param = zT_102;
    zT_103 = 0;
    pi = zT_103;
    goto z_bb_23;
    z_bb_14:
    zT_98 = bi + (unsigned int)(1);
    bi = zT_98;
    goto z_bb_11;
    z_bb_15:
    zT_81 = bb->insts;
    zT_82 = zT_81.len;
    if ((int)(ii < zT_82)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_84 = bb->insts;
    zT_85 = zT_84.items;
    zT_86 = zT_85[ii];
    zT_87 = zT_86.tag;
switch (zT_87) {
case 1: goto z_bb_19;
default: goto z_bb_20;
}
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_96 = ii + (unsigned int)(1);
    ii = zT_96;
    goto z_bb_15;
    z_bb_19:
    dl = zT_86.payload.decl_local._0;
    zT_89 = &locals;
    zT_90 = dl.name_id;
    zT_91 = dl.temp;
    zF_26476265_u32ToU32MapPut(zT_89, zT_90, zT_91);
    (void)alloc;
    goto z_bb_22;
    z_bb_20:
    goto z_bb_22;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_104 = lir_fn->params;
    zT_105 = zT_104.len;
    if ((int)(pi < zT_105)) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_108 = lir_fn->params;
    zT_109 = zT_108.items;
    zT_110 = zT_109[pi];
    zT_111 = zT_110.temp_id;
    pt = zT_111;
    if ((int)(pt < max_temp)) goto z_bb_27; else goto z_bb_28;
    z_bb_25:
    zT_118 = alloc;
    zT_119 = max_temp;
    zT_120 = zF_F15DB413_allocU8Raw(zT_118, zT_119);
    live = zT_120;
    zT_122 = 0;
    t = zT_122;
    goto z_bb_29;
    z_bb_26:
    zT_116 = pi + (unsigned int)(1);
    pi = zT_116;
    goto z_bb_23;
    z_bb_27:
    zT_113 = 1;
    zT_114 = (unsigned int)pt;
    is_param[zT_114] = zT_113;
    goto z_bb_28;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    if ((int)(t < max_temp)) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_124 = 0;
    zT_125 = (unsigned int)t;
    live[zT_125] = zT_124;
    goto z_bb_32;
    z_bb_31:
    zT_128 = 0;
    bi = zT_128;
    goto z_bb_33;
    z_bb_32:
    zT_127 = t + (unsigned int)(1);
    t = zT_127;
    goto z_bb_29;
    z_bb_33:
    zT_129 = lir_fn->blocks;
    zT_130 = zT_129.len;
    if ((int)(bi < zT_130)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_133 = lir_fn->blocks;
    zT_134 = zT_133.items;
    zT_135 = zT_134 + bi;
    bb = zT_135;
    zT_137 = 0;
    ii = zT_137;
    goto z_bb_37;
    z_bb_35:
    zT_182 = 0;
    offset = zT_182;
    zT_184 = 1;
    max_align = zT_184;
    zT_186 = 8;
    state_type = zT_186;
    zT_187 = state_widths;
    zT_189 = lir_fn->module_id;
    zT_190 = lir_fn->name_id;
    zT_193 = zF_9D041EB6_asyncKey(zT_189, zT_190);
    zT_188 = zT_193;
    zT_194 = zF_A05A7BE1_u64ToU32MapGet(zT_187, zT_188);
    zT_195 = zT_194.has_value;
    if (zT_195) goto z_bb_53; else goto z_bb_54;
    z_bb_36:
    zT_180 = bi + (unsigned int)(1);
    bi = zT_180;
    goto z_bb_33;
    z_bb_37:
    zT_138 = bb->insts;
    zT_139 = zT_138.len;
    if ((int)(ii < zT_139)) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_142 = bb->insts;
    zT_143 = zT_142.items;
    zT_144 = zT_143[ii];
    inst = zT_144;
    zT_145 = &c;
    zT_146 = inst;
    zT_147 = suspending_fns;
    zT_149 = zF_1AAC25A7_instIsSuspendPoint(zT_145, zT_146, zT_147);
    if (zT_149) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_178 = ii + (unsigned int)(1);
    ii = zT_178;
    goto z_bb_37;
    z_bb_41:
    zT_150 = 0;
    t = zT_150;
    goto z_bb_43;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    if ((int)(t < max_temp)) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_153 = (unsigned int)t;
    tu = zT_153;
    zT_154 = is_param[tu];
    if ((int)(zT_154 != (unsigned char)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_176 = t + (unsigned int)(1);
    t = zT_176;
    goto z_bb_43;
    z_bb_47:
    goto z_bb_46;
    z_bb_48:
    zT_157 = &c;
    zT_158 = t;
    zT_164 = zF_93E9604D_hasDefBefore(zT_157, zT_158, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    if ((int)(!zT_164)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_166 = &c;
    zT_167 = t;
    zT_173 = zF_4CED5DFF_hasReadAfter(zT_166, zT_167, (unsigned int)((unsigned int)bi), (unsigned int)((unsigned int)ii));
    if (zT_173) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_174 = 1;
    live[tu] = zT_174;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_46;
    z_bb_53:
    sw = zT_194.value;
    state_type = sw;
    goto z_bb_54;
    z_bb_54:
    zT_197 = &fields;
    zT_198 = reg;
    zT_206 = 4;
    zT_199 = zT_206;
    zT_203 = &offset;
    zT_204 = &max_align;
    zF_F2801F08_addField(zT_197, zT_198, zT_199, (unsigned int)(0), (unsigned int)(0), (unsigned int)(13), zT_203, zT_204);
    zT_212 = &fields;
    zT_213 = reg;
    zT_221 = 0;
    zT_214 = zT_221;
    zT_218 = &offset;
    zT_219 = &max_align;
    zF_F2801F08_addField(zT_212, zT_213, zT_214, (unsigned int)(0), (unsigned int)(0), (unsigned int)(13), zT_218, zT_219);
    zT_227 = &fields;
    zT_228 = reg;
    zT_236 = 1;
    zT_229 = zT_236;
    zT_232 = state_type;
    zT_233 = &offset;
    zT_234 = &max_align;
    zF_F2801F08_addField(zT_227, zT_228, zT_229, (unsigned int)(0), (unsigned int)(0), zT_232, zT_233, zT_234);
    zT_241 = 0;
    pi = zT_241;
    goto z_bb_55;
    z_bb_55:
    zT_242 = lir_fn->params;
    zT_243 = zT_242.len;
    if ((int)(pi < zT_243)) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_246 = lir_fn->params;
    zT_247 = zT_246.items;
    zT_248 = zT_247[pi];
    p = zT_248;
    zT_249 = &fields;
    zT_250 = reg;
    zT_258 = 2;
    zT_251 = zT_258;
    zT_252 = p.name_id;
    zT_253 = p.temp_id;
    zT_254 = p.type_id;
    zT_255 = &offset;
    zT_256 = &max_align;
    zF_F2801F08_addField(zT_249, zT_250, zT_251, zT_252, zT_253, zT_254, zT_255, zT_256);
    goto z_bb_58;
    z_bb_57:
    zT_266 = 0;
    t = zT_266;
    goto z_bb_59;
    z_bb_58:
    zT_265 = pi + (unsigned int)(1);
    pi = zT_265;
    goto z_bb_55;
    z_bb_59:
    if ((int)(t < max_temp)) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_269 = (unsigned int)t;
    tu = zT_269;
    zT_270 = live[tu];
    if ((int)(zT_270 != (unsigned char)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    zT_295 = 0;
    hid = zT_295;
    zT_297 = lir_fn->module_id;
    zT_298 = lir_fn->name_id;
    zT_301 = zF_9D041EB6_asyncKey(zT_297, zT_298);
    lay_key = zT_301;
    zT_302 = async_hidden_fns;
    zT_303 = lay_key;
    zT_304 = zF_A05A7BE1_u64ToU32MapGet(zT_302, zT_303);
    zT_305 = zT_304.has_value;
    if (zT_305) goto z_bb_68; else goto z_bb_69;
    z_bb_62:
    zT_293 = t + (unsigned int)(1);
    t = zT_293;
    goto z_bb_59;
    z_bb_63:
    zT_274 = is_param[tu];
    zT_273 = zT_274 == (unsigned char)(0);
    goto z_bb_65;
    z_bb_64:
    zT_273 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_273) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_277 = &fields;
    zT_278 = reg;
    zT_286 = 3;
    zT_279 = zT_286;
    zT_281 = t;
    zT_288 = c.ttype;
    zT_282 = zT_288[tu];
    zT_283 = &offset;
    zT_284 = &max_align;
    zF_F2801F08_addField(zT_277, zT_278, zT_279, (unsigned int)(0), zT_281, zT_282, zT_283, zT_284);
    goto z_bb_67;
    z_bb_67:
    goto z_bb_62;
    z_bb_68:
    h = zT_304.value;
    hid = h;
    goto z_bb_69;
    z_bb_69:
    zT_308 = reg;
    zT_313 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_308, (unsigned int)(1), (int)(0));
    lay_ptr_void = zT_313;
    if ((int)((unsigned int)(hid & (unsigned int)(1)) != (unsigned int)(0))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_318 = &fields;
    zT_319 = reg;
    zT_327 = 5;
    zT_320 = zT_327;
    zT_323 = lay_ptr_void;
    zT_324 = &offset;
    zT_325 = &max_align;
    zF_F2801F08_addField(zT_318, zT_319, zT_320, (unsigned int)(0), (unsigned int)(0), zT_323, zT_324, zT_325);
    goto z_bb_71;
    z_bb_71:
    zT_332 = awaited_fns;
    zT_333 = lay_key;
    zT_334 = zF_A05A7BE1_u64ToU32MapGet(zT_332, zT_333);
    zT_335 = zT_334.has_value;
    if (zT_335) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_336 = &fields;
    zT_337 = reg;
    zT_345 = 6;
    zT_338 = zT_345;
    zT_341 = lay_ptr_void;
    zT_342 = &offset;
    zT_343 = &max_align;
    zF_F2801F08_addField(zT_336, zT_337, zT_338, (unsigned int)(0), (unsigned int)(0), zT_341, zT_342, zT_343);
    goto z_bb_73;
    z_bb_73:
    if ((int)((unsigned int)(hid & (unsigned int)(2)) != (unsigned int)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_355 = 0;
    pstart = zT_355;
    zT_356 = parent_result_start;
    zT_357 = lay_key;
    zT_358 = zF_A05A7BE1_u64ToU32MapGet(zT_356, zT_357);
    zT_359 = zT_358.has_value;
    if (zT_359) goto z_bb_76; else goto z_bb_77;
    z_bb_75:
    zT_393 = offset;
    zT_394 = max_align;
    zT_395 = zF_978D7C93_alignUpU32(zT_393, zT_394);
    precise = zT_395;
    if ((int)(precise == (unsigned int)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_76:
    ps = zT_358.value;
    pstart = ps;
    goto z_bb_77;
    z_bb_77:
    zT_362 = 0;
    pcount = zT_362;
    zT_363 = parent_result_count;
    zT_364 = lay_key;
    zT_365 = zF_A05A7BE1_u64ToU32MapGet(zT_363, zT_364);
    zT_366 = zT_365.has_value;
    if (zT_366) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    pc = zT_365.value;
    pcount = pc;
    goto z_bb_79;
    z_bb_79:
    zT_369 = 0;
    pk = zT_369;
    goto z_bb_80;
    z_bb_80:
    if ((int)(pk < pcount)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_372 = parent_result_type_list->items;
    zT_374 = (unsigned int)(unsigned int)(pstart + pk);
    zT_375 = zT_372[zT_374];
    prt = zT_375;
    zT_376 = &fields;
    zT_377 = reg;
    zT_385 = 7;
    zT_378 = zT_385;
    zT_381 = prt;
    zT_382 = &offset;
    zT_383 = &max_align;
    zF_F2801F08_addField(zT_376, zT_377, zT_378, (unsigned int)(0), (unsigned int)(0), zT_381, zT_382, zT_383);
    goto z_bb_83;
    z_bb_82:
    goto z_bb_75;
    z_bb_83:
    zT_391 = pk + (unsigned int)(1);
    pk = zT_391;
    goto z_bb_80;
    z_bb_84:
    zT_398 = 1;
    precise = zT_398;
    goto z_bb_85;
    z_bb_85:
    zT_400 = frame_sizes;
    zT_401 = lir_fn->module_id;
    zT_402 = lir_fn->name_id;
    zT_405 = zF_D3D61AC0_asyncFrameSizeOf(zT_400, zT_401, zT_402);
    frame_size = zT_405;
    padded = precise;
    zT_407 = frame_size.has_value;
    if (zT_407) goto z_bb_86; else goto z_bb_88;
    z_bb_86:
    fs = frame_size.value;
    if ((int)(precise > fs)) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    zT_424 = lir_fn->module_id;
    zT_425 = lir_fn->name_id;
    zT_426 = padded;
    zF_2B302EFE_emitLayoutMarker(zT_424, zT_425, zT_426);
    zT_429.fields = fields;
    zT_429.layout_size = padded;
    return zT_429;
    z_bb_88:
    zT_417 = "panic: ";
    zT_418 = 7;
    fwrite(zT_417, 1, zT_418, stderr);
    zT_419 = "async frame layout: missing authoritative frame size";
    zT_420 = 52;
    fwrite(zT_419, 1, zT_420, stderr);
    zT_421 = "\n";
    zT_422 = 1;
    fwrite(zT_421, 1, zT_422, stderr);
    pal_trap();
    z_bb_89:
    zT_410 = "panic: ";
    zT_411 = 7;
    fwrite(zT_410, 1, zT_411, stderr);
    zT_412 = "async frame layout exceeds authoritative frame size";
    zT_413 = 51;
    fwrite(zT_412, 1, zT_413, stderr);
    zT_414 = "\n";
    zT_415 = 1;
    fwrite(zT_414, 1, zT_415, stderr);
    pal_trap();
    z_bb_90:
    padded = fs;
    goto z_bb_87;
}

/* asyncLayoutPublish */
void zF_17324878_asyncLayoutPublish(zT_3E40CD83_Sand* alloc, zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id, zT_3F3BF87A_AsyncFrameLayout layout) {
    zT_3E40CD83_Sand* zT_6;
    zT_9154F007_EU_232 zT_11 = {0};
    unsigned char zT_12;
    unsigned char* zT_13;
    zT_3F3BF87A_AsyncFrameLayout* zT_16;
    zT_A4CE86B7_U64ToU32Map* zT_17;
    zT_79FAE712_u64 zT_18;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_79FAE712_u64 zT_22 = 0;
    unsigned char* raw;
    zT_3F3BF87A_AsyncFrameLayout* p;
    zT_6 = alloc;
    zT_11 = zF_1395EB68_sandAlloc(zT_6, (unsigned int)(20), (unsigned int)(4));
    zT_12 = zT_11.is_error;
    if (zT_12) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_13 = zT_11.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_13;
    zT_16 = (zT_3F3BF87A_AsyncFrameLayout*)raw;
    p = zT_16;
    *p = layout;
    zT_17 = map;
    zT_20 = module_id;
    zT_21 = name_id;
    zT_22 = zF_9D041EB6_asyncKey(zT_20, zT_21);
    zT_18 = zT_22;
    zF_B6EB812C_u64ToU32MapPut(zT_17, zT_18, (unsigned int)((unsigned int)(unsigned int)((unsigned int)p)));
    (void)alloc;
    return;
}

/* asyncLayoutLookup */
zT_F7B96A09_Opt_394 zF_A1F56FFB_asyncLayoutLookup(zT_A4CE86B7_U64ToU32Map* map, unsigned int module_id, unsigned int name_id) {
    zT_A4CE86B7_U64ToU32Map* zT_3;
    zT_79FAE712_u64 zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_79FAE712_u64 zT_7 = 0;
    zT_BAEE192E_Opt_10 zT_8 = {0};
    unsigned char zT_9;
    zT_3F3BF87A_AsyncFrameLayout* zT_12;
    zT_F7B96A09_Opt_394 zT_13;
    zT_F7B96A09_Opt_394 zT_14 = {0};
    unsigned int v;
    zT_3 = map;
    zT_5 = module_id;
    zT_6 = name_id;
    zT_7 = zF_9D041EB6_asyncKey(zT_5, zT_6);
    zT_4 = zT_7;
    zT_8 = zF_A05A7BE1_u64ToU32MapGet(zT_3, zT_4);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    v = zT_8.value;
    zT_12 = (zT_3F3BF87A_AsyncFrameLayout*)(unsigned int)(unsigned int)((unsigned int)v);
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_2:
    zT_14.has_value = 0;
    return zT_14;
}

/* __module_init */
void zF_780653D2___module_init_22(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zT_BBC23664_LirFunction zT_1 = {0};
    zT_6BA597BC_LirInst zT_2 = {0};
    zT_338B7C76_TypeRegistry zT_3 = {0};
    zG_3E40CD83_Sand = zT_0;
    zG_BBC23664_LirFunction = zT_1;
    zG_6BA597BC_LirInst = zT_2;
    zG_338B7C76_TypeRegistry = zT_3;
    return;
}

/* EOF */
