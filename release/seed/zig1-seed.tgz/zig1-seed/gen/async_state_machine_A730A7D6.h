#ifndef ZIG_MODULE_ASYNC_STATE_MACHINE_A730A7D6_H
#define ZIG_MODULE_ASYNC_STATE_MACHINE_A730A7D6_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "async_analysis_A8747991.h"
#include "async_frame_layout_08B81337.h"
#include "diagnostics_B9C6175E.h"
#include "hash_02AFCD13.h"
#include "lir_64CB5435.h"
#include "lir_stream_0760A6EE.h"
#include "string_interner_51340A9F.h"
#include "type_registry_8EE489B8.h"

#ifndef ZIG_STRUCT_zT_5839647A_AsyncTransformCtx
#define ZIG_STRUCT_zT_5839647A_AsyncTransformCtx
struct zT_5839647A_AsyncTransformCtx {
	zT_3E40CD83_Sand* alloc;
	zT_338B7C76_TypeRegistry* registry;
	zT_D3EB6303_StringInterner* interner;
	zT_7E7544E4_LirStream* lir_stream;
	zT_CA01C129_LirSlotArrayList* lir_slots;
	zT_A4CE86B7_U64ToU32Map* suspending_fns;
	zT_3F3BF87A_AsyncFrameLayout* layout;
	unsigned char safe_checks;
	zT_A4CE86B7_U64ToU32Map* frame_sizes;
	zT_A4CE86B7_U64ToU32Map* async_layouts;
	zT_F85C5DED_DiagnosticCollector* diag;
};
#endif /* ZIG_STRUCT_zT_5839647A_AsyncTransformCtx */
#ifndef ZIG_STRUCT_zT_95967543_Build
#define ZIG_STRUCT_zT_95967543_Build
struct zT_95967543_Build {
	zT_BBC23664_LirFunction* step;
	zT_BBC23664_LirFunction* orig;
	zT_5839647A_AsyncTransformCtx* actx;
	zT_338B7C76_TypeRegistry* reg;
	unsigned int base;
	unsigned int frame_temp;
	unsigned int opt;
	unsigned int* block_map;
	unsigned int nblocks;
	unsigned int state_off;
	unsigned int state_type;
	unsigned int child_off;
	unsigned char child_present;
	unsigned int* pr_off;
	unsigned int* pr_ty;
	unsigned int pr_count;
	unsigned char pr_present;
	unsigned int result_off;
	unsigned char result_present;
	unsigned int child_temp;
	unsigned int ret_val_temp;
	unsigned char ret_val_present;
	unsigned int ep_store_id;
	unsigned int ep_dostore_id;
	unsigned int ep_ret_id;
};
#endif /* ZIG_STRUCT_zT_95967543_Build */
#ifndef ZIG_STRUCT_zT_C72CD5DD_FrameInitParam
#define ZIG_STRUCT_zT_C72CD5DD_FrameInitParam
struct zT_C72CD5DD_FrameInitParam {
	unsigned int offset;
	unsigned int type_id;
	unsigned int value_temp;
};
#endif /* ZIG_STRUCT_zT_C72CD5DD_FrameInitParam */
#ifndef ZIG_STRUCT_zT_79D145D1_AsyncFrameHeader
#define ZIG_STRUCT_zT_79D145D1_AsyncFrameHeader
struct zT_79D145D1_AsyncFrameHeader {
	unsigned int step_off;
	unsigned int ctx_off;
	unsigned int state_off;
	unsigned int end_off;
	unsigned int end_align;
};
#endif /* ZIG_STRUCT_zT_79D145D1_AsyncFrameHeader */

/* Forward declarations */
unsigned char* zF_2AFB8CC6_bumpAlloc(zT_3E40CD83_Sand*, unsigned int, unsigned int);
unsigned int* zF_CC1E115D_allocPrArray(zT_3E40CD83_Sand*, unsigned int);
unsigned int zF_07B5C503_asyncStepNameId(zT_D3EB6303_StringInterner*, unsigned int);
unsigned int zF_261A9B15_asyncStepFnType(zT_338B7C76_TypeRegistry*, zT_D3EB6303_StringInterner*, unsigned int, unsigned int);
unsigned int zF_02AC4E66_asyncGenericStepFnT(zT_338B7C76_TypeRegistry*, zT_D3EB6303_StringInterner*);
unsigned int zF_AE5A5E5B_ptrVoid(zT_338B7C76_TypeRegistry*);
unsigned int zF_081DA576_optPtrVoid(zT_338B7C76_TypeRegistry*);
unsigned int zF_DA340CBF_tempType(zT_BBC23664_LirFunction*, unsigned int);
unsigned char zF_2F385545_instSuspendKind(zT_338B7C76_TypeRegistry*, zT_BBC23664_LirFunction*, zT_6BA597BC_LirInst, zT_A4CE86B7_U64ToU32Map*);
unsigned int zF_ACDE0A8B_newTemp(zT_95967543_Build*, unsigned int);
void zF_2D88474A_emit(zT_95967543_Build*, unsigned int, zT_6BA597BC_LirInst);
unsigned int zF_B5FE797E_fieldPtrBase(zT_95967543_Build*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned int zF_6405A853_fieldPtr(zT_95967543_Build*, unsigned int, unsigned int, unsigned int);
unsigned int zF_563DDD2E_loadFieldBase(zT_95967543_Build*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned int zF_6AEBFF63_loadField(zT_95967543_Build*, unsigned int, unsigned int, unsigned int);
void zF_9BF633B7_storeFieldBase(zT_95967543_Build*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_F732521A_storeField(zT_95967543_Build*, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_38445CB2_saveAllFields(zT_95967543_Build*, unsigned int, zT_3F3BF87A_AsyncFrameLayout*);
void zF_50B6012E_reloadAllFields(zT_95967543_Build*, unsigned int, zT_3F3BF87A_AsyncFrameLayout*);
unsigned int zF_5B83E8EA_remapBb(zT_95967543_Build*, unsigned int);
unsigned int zF_58E01BBD_copyCallDirect(zT_95967543_Build*, unsigned int);
unsigned int zF_D3FD6D1A_copyTailCall(zT_95967543_Build*, unsigned int);
zT_6BA597BC_LirInst zF_1976B20E_remapInst(zT_95967543_Build*, zT_6BA597BC_LirInst, unsigned int);
void zF_8A7A5C8C_emitDriveChild(zT_95967543_Build*, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_5CEAC9FC_emitAwait(zT_95967543_Build*, unsigned int, zT_3BFB1E70_CallDirectData, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned char zF_E2908C92_isDriverTarget(zT_5839647A_AsyncTransformCtx*, zT_BBC23664_LirFunction*);
zT_79D145D1_AsyncFrameHeader zF_87F02AB1_asyncFrameHeader(zT_338B7C76_TypeRegistry*, unsigned int);
void zF_0B45DE2B_fiEmit(zT_BBC23664_LirFunction*, unsigned int, zT_6BA597BC_LirInst);
unsigned int zF_4E9BBD8C_fiNewTemp(zT_BBC23664_LirFunction*, zT_5D72FBF8_TempDeclArrayList*, unsigned int*, unsigned int);
unsigned int zF_4AA1602D_fiCreateBlock(zT_BBC23664_LirFunction*);
void zF_68D0856C_fiStoreAt(zT_BBC23664_LirFunction*, zT_5D72FBF8_TempDeclArrayList*, unsigned int*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, zT_338B7C76_TypeRegistry*);
unsigned int zF_4836CE87_asyncEmitFrameInit(zT_BBC23664_LirFunction*, zT_5D72FBF8_TempDeclArrayList*, unsigned int, unsigned int, zT_338B7C76_TypeRegistry*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, zT_577163E8_Slice_zT_C72CD5DD_F);
void zF_FDE62E71_emitMainDriver(zT_5839647A_AsyncTransformCtx*, zT_BBC23664_LirFunction*);
unsigned char zF_7C1ED6D1_asyncTransform(zT_BBC23664_LirFunction*, zT_5839647A_AsyncTransformCtx*);
void zF_780653D2___module_init_24(void);
/* Storage globals (extern decls) */
extern unsigned char zG_665BA216_BIN_ADD_1;
extern unsigned char zG_B123C9B7_BIN_SUB_1;
extern unsigned char zG_526A8D24_BIN_AND_1;
extern unsigned char zG_9608E9F2_BIN_OR_1;
extern unsigned char zG_C50B7286_BIN_NE_1;
extern unsigned char zG_A2114B9B_BIN_LT_1;
extern unsigned char zG_911130D8_BIN_LE_1;
extern unsigned char zG_DFF5D6B8_BIN_GT_1;
extern unsigned int zG_6F24C344_CTX_USED_OFF;
extern unsigned int zG_F13C88BF_CTX_CAP_OFF;
extern unsigned int zG_5AFE8246_CTX_OOM_OFF;
extern unsigned int zG_662115F7_CTX_POOL_OFF;

#endif /* ZIG_MODULE_ASYNC_STATE_MACHINE_A730A7D6_H */
