#ifndef ZIG_MODULE_LIR_OPT_PASS_3842C861_H
#define ZIG_MODULE_LIR_OPT_PASS_3842C861_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "allocator_E75B7A0B.h"
#include "type_registry_8EE489B8.h"
#include "type_registry_8EE489B8.h"
#include "type_registry_8EE489B8.h"
#include "lir_64CB5435.h"
#include "lir_64CB5435.h"
#include "lir_64CB5435.h"

#ifndef ZIG_STRUCT_zT_5EDE903E_Ctx
#define ZIG_STRUCT_zT_5EDE903E_Ctx
struct zT_5EDE903E_Ctx {
	zT_3E40CD83_Sand* alloc;
	zT_338B7C76_TypeRegistry* reg;
	zT_BBC23664_LirFunction* lir_fn;
	unsigned int max_temp;
	unsigned int* t2p;
	unsigned int* ttype;
	unsigned int* rc;
	unsigned int* wc;
	unsigned char* at;
	unsigned char* ex;
	unsigned char* dp;
	unsigned int* rd_bb;
	unsigned int* rd_ii;
	unsigned char* rar;
	unsigned char* cf;
	zT_79FAE712_u64* cv;
	unsigned int* ren;
	unsigned char* cand;
	unsigned char* depth;
	unsigned char* ga;
	unsigned char* gam;
	unsigned int* df_bb;
	unsigned int* df_ii;
};
#endif /* ZIG_STRUCT_zT_5EDE903E_Ctx */

/* Forward declarations */
unsigned char zF_829B1D9D_lirOptNestActive(void);
unsigned char zF_0670982D_nestInRange(unsigned int);
unsigned char zF_0740DD14_lirOptNestCandidate(unsigned int);
unsigned char zF_03D891BD_lirOptNestDepthOf(unsigned int);
void zF_79BC1D14_lirOptNestDefLoc(unsigned int, unsigned int*, unsigned int*);
void zF_9CF3FC28_lirOptNestConsLoc(unsigned int, unsigned int*, unsigned int*);
zT_79FAE712_u64 zF_5E3CE23D_lowMask(unsigned int);
zT_79FAE712_u64 zF_3794934D_sigBit(unsigned int);
unsigned int zF_90DDF69C_intKindWidth(zT_33EF6BFB_TypeKind);
unsigned char zF_D4EA92B8_intKindSigned(zT_33EF6BFB_TypeKind);
unsigned char zF_B7E1584C_copyScalarKindOk(zT_33EF6BFB_TypeKind);
unsigned int* zF_43BEEDA4_allocU32(zT_5EDE903E_Ctx*, unsigned int);
zT_79FAE712_u64* zF_3FCBB34B_allocU64(zT_5EDE903E_Ctx*, unsigned int);
unsigned char* zF_76A96453_allocU8(zT_5EDE903E_Ctx*, unsigned int);
unsigned int zF_005F8966_maxTempOf(zT_BBC23664_LirFunction*);
void zF_D6CE151A_resetScratch(zT_5EDE903E_Ctx*);
void zF_20F1A7B4_markRead(zT_5EDE903E_Ctx*, unsigned int, unsigned int, unsigned int);
void zF_8ABC4310_markArgRead(zT_5EDE903E_Ctx*, unsigned int, unsigned int, unsigned int);
void zF_0A9E889A_markAddrTaken(zT_5EDE903E_Ctx*, unsigned int);
void zF_2CDB40DA_markExcluded(zT_5EDE903E_Ctx*, unsigned int);
void zF_323EFAF9_markGaSource(zT_5EDE903E_Ctx*, unsigned int);
void zF_83868A0F_recordConst(zT_5EDE903E_Ctx*, unsigned int, zT_79FAE712_u64);
void zF_AAEF59B7_markDef(zT_5EDE903E_Ctx*, unsigned int, unsigned char);
unsigned char zF_A5E11466_defInfoPure(zT_6BA597BC_LirInst);
unsigned int zF_CFED20F7_defResultTemp(zT_6BA597BC_LirInst, zT_BBC23664_LirFunction*);
void zF_85F6BDD8_scanInst(zT_5EDE903E_Ctx*, zT_6BA597BC_LirInst, unsigned int, unsigned int);
void zF_6A60FAEB_scanAll(zT_5EDE903E_Ctx*);
unsigned char zF_122C0CBD_depthOfTemp(zT_5EDE903E_Ctx*, unsigned int);
unsigned char zF_B27E2943_maxOperandDepth(zT_5EDE903E_Ctx*, zT_6BA597BC_LirInst);
unsigned char zF_53018302_defReadsMemory(zT_6BA597BC_LirInst);
unsigned char zF_EB2642CA_instOrdered(zT_6BA597BC_LirInst);
unsigned char zF_0CED9F5B_tempReachesGlobalAl(zT_5EDE903E_Ctx*, unsigned int);
unsigned char zF_CDC9F097_instOperandsReachGl(zT_5EDE903E_Ctx*, zT_6BA597BC_LirInst);
void zF_02672451_computeNestMetadata(zT_5EDE903E_Ctx*);
unsigned int zF_8B8DBDFB_maybeR(zT_5EDE903E_Ctx*, unsigned int);
zT_6BA597BC_LirInst zF_0E3ACCAD_rewriteInstOperands(zT_5EDE903E_Ctx*, zT_6BA597BC_LirInst);
unsigned char zF_4AE99A73_copyPropagate(zT_5EDE903E_Ctx*);
unsigned char zF_2ECBA7DA_resDeclIntType(zT_5EDE903E_Ctx*, unsigned int, unsigned int*, unsigned char*);
unsigned char zF_86D6C86A_constOperandIntType(zT_5EDE903E_Ctx*, unsigned int, unsigned int*, unsigned char*);
unsigned int zF_D835BE2E_tempDeclTypeId(zT_5EDE903E_Ctx*, unsigned int);
void zF_28365D82_signMagnitude(zT_79FAE712_u64, unsigned int, unsigned char, unsigned char*, zT_79FAE712_u64*);
signed char zF_0B35676F_cmpBitsSigned(zT_79FAE712_u64, zT_79FAE712_u64, unsigned int);
unsigned char zF_EEEDCAC3_tryFoldBinaryOp(zT_5EDE903E_Ctx*, zT_6BA597BC_LirInst, zT_79FAE712_u64*, unsigned char*);
unsigned char zF_2EC2B21D_tryFoldIntCast(zT_5EDE903E_Ctx*, zT_6BA597BC_LirInst, zT_79FAE712_u64*);
unsigned char zF_7C7AB1D6_runConstFold(zT_5EDE903E_Ctx*);
void zF_37363942_lirOptRun(zT_3E40CD83_Sand*, zT_338B7C76_TypeRegistry*, zT_BBC23664_LirFunction*);
unsigned int* zF_82E88BBC_allocU32With(zT_3E40CD83_Sand*, unsigned int, unsigned int);
unsigned int* zF_730A6C2A_allocU32Raw(zT_3E40CD83_Sand*, unsigned int);
zT_79FAE712_u64* zF_1A0C0ABB_allocU64Raw(zT_3E40CD83_Sand*, unsigned int);
unsigned char* zF_F15DB413_allocU8Raw(zT_3E40CD83_Sand*, unsigned int);
void zF_780653D2___module_init_22(void);
/* Storage globals (extern decls) */
extern unsigned int zG_8D933C0A_kCopyPropMaxIter;
extern unsigned char zG_78C2C6B4_g_nest_active;
extern unsigned int zG_14E10714_g_nest_max;
extern unsigned char* zG_30D934F4_g_nest_cand;
extern unsigned char* zG_7DE170EB_g_nest_depth;
extern unsigned int* zG_32175378_g_nest_dfbb;
extern unsigned int* zG_5501C442_g_nest_dfii;
extern unsigned int* zG_46632058_g_nest_rdbb;
extern unsigned int* zG_694BFE22_g_nest_rdii;

#endif /* ZIG_MODULE_LIR_OPT_PASS_3842C861_H */
