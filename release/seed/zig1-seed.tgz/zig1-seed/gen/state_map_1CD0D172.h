#ifndef ZIG_MODULE_STATE_MAP_1CD0D172_H
#define ZIG_MODULE_STATE_MAP_1CD0D172_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"

#ifndef ZIG_STRUCT_zT_6B392E0E_StateEntry
#define ZIG_STRUCT_zT_6B392E0E_StateEntry
struct zT_6B392E0E_StateEntry {
	unsigned int name_id;
	unsigned char state;
};
#endif /* ZIG_STRUCT_zT_6B392E0E_StateEntry */
#ifndef ZIG_STRUCT_zT_2C0927B0_StateMap
#define ZIG_STRUCT_zT_2C0927B0_StateMap
struct zT_2C0927B0_StateMap {
	zT_6B392E0E_StateEntry* entries_items;
	unsigned int entries_len;
	unsigned int entries_cap;
	zT_3E40CD83_Sand* entries_alloc;
	zT_DD28CFE9_Opt_273 parent;
};
#endif /* ZIG_STRUCT_zT_2C0927B0_StateMap */

/* Forward declarations */
zT_2C0927B0_StateMap zF_14665872_stateMapInit(zT_3E40CD83_Sand*);
void zF_A12CB78A_stateMapEnsureCapac(zT_2C0927B0_StateMap*, unsigned int);
zT_43E16BE5_Opt_8 zF_2EC17ECC_stateMapGet(zT_2C0927B0_StateMap*, unsigned int);
void zF_ACCFA860_stateMapSet(zT_2C0927B0_StateMap*, unsigned int, unsigned char);
zT_2C0927B0_StateMap* zF_77086C9C_stateMapFork(zT_2C0927B0_StateMap*, zT_3E40CD83_Sand*);
void zF_143ACBA6_stateMapMergeStates(zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*, zT_2C0927B0_StateMap*, unsigned char);
zT_92FBD55B_Slice_zT_6B392E0E_S zF_F0E7F434_stateMapGetEntries(zT_2C0927B0_StateMap*);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_STATE_MAP_1CD0D172_H */
