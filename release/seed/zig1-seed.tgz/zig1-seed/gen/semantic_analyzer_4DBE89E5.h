#ifndef ZIG_MODULE_SEMANTIC_ANALYZER_4DBE89E5_H
#define ZIG_MODULE_SEMANTIC_ANALYZER_4DBE89E5_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "type_registry_8EE489B8.h"
#include "resolved_type_table_5F22E794.h"
#include "diagnostics_B9C6175E.h"
#include "symbol_table_74081C75.h"
#include "ast_2FA12982.h"
#include "coercion_F654E5FA.h"
#include "hash_02AFCD13.h"
#include "pal_388A8A1B.h"
#include "itoa_4E677A6A.h"
#include "string_interner_51340A9F.h"
#include "type_resolver_7446D285.h"
#include "module_registry_03A5D1FC.h"
#include "async_analysis_A8747991.h"
#include "comptime_eval_02C4526F.h"


/* Forward declarations */
zT_38C12417_SemanticAnalyzer zF_84ADA681_semanticAnalyzerIni(zT_3E40CD83_Sand*, zT_8EED1867_ResolvedTypeTable*, zT_F85C5DED_DiagnosticCollector*, zT_338B7C76_TypeRegistry*, zT_3D7259E2_SymbolRegistry*, zT_6B0A7D14_AstStore*, unsigned int, unsigned int, zT_66E7D2EF_CoercionTable*, zT_21D3708C_U32ToU32Map*, zT_21D3708C_U32ToU32Map*, zT_21D3708C_U32ToU32Map*, zT_D3EB6303_StringInterner*, zT_21D3708C_U32ToU32Map*, zT_21D3708C_U32ToU32Map*, zT_072B53A6_ModuleRegistry*, zT_A4CE86B7_U64ToU32Map*);
unsigned char zF_3757023F_semanticAnalyzerIsT(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_2ACB4E23_semanticAnalyzerBui(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_CAF1FD28_semanticAnalyzerIsB(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_D4D0798B_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_2EC0CDC8_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_398A7D41_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_A210EB18_ErrorCode, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned char zF_02E8B77C_semanticAnalyzerDef(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_389B3480_semanticAnalyzerDef(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_0D8393D0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_9E06A44F_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_156C79D0_semanticAnalyzerGro(zT_38C12417_SemanticAnalyzer*);
void zF_7BD72017_registerLocalDecl(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_C999EE08_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned char zF_2FC8BE84_semanticAnalyzerPop(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_4679EA8B_semanticAnalyzerNth(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, unsigned int*, unsigned int*);
unsigned int zF_3E251D67_semanticAnalyzerCap(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_9F1ECA79_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
zT_BAEE192E_Opt_10 zF_C2228CF4_semanticAnalyzerArr(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_3F00B75F_semanticAnalyzerArr(zT_38C12417_SemanticAnalyzer*, unsigned int);
zT_BAEE192E_Opt_10 zF_114981C5_semanticAnalyzerSta(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_20B8552F_semanticAnalyzerCom(zT_38C12417_SemanticAnalyzer*, zT_DA663F79_ComptimeEval*, unsigned int, zT_0163D9A4_ComptimeInt*);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_EB5D8D0D_semanticAnalyzerCom(zT_0163D9A4_ComptimeInt, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_47283CC0_semanticAnalyzerU32(unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_4759477D_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_0163D9A4_ComptimeInt, unsigned int);
void zF_0625BE2E_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_0163D9A4_ComptimeInt, unsigned int);
void zF_FEA77D2C_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_0163D9A4_ComptimeInt, zT_0163D9A4_ComptimeInt);
void zF_7BEA5982_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_0163D9A4_ComptimeInt);
void zF_87D290B9_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
void zF_F3DF87F2_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_71D82205_semanticAnalyzerSpe(zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_B373A9D4_semanticAnalyzerSpe(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned int, unsigned int);
void zF_B9419697_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned char);
void zF_2DB15F1D_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_9A830F5F_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_B8256AA6_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_D05E1055_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int*);
void zF_5573DE9B_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_07FB55C2_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_F79AE891_semanticAnalyzerArr(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_5173E2D8_semanticAnalyzerFin(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int*, unsigned int*);
void zF_A55BDC03_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, zT_33EF6BFB_TypeKind, unsigned int);
void zF_D723F35B_semanticAnalyzerRej(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned short, zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_8F083A69_Slice_zT_0B42B2F8_u zF_AEA4723C_semanticAnalyzerInt(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_3406190F_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_04D95C53_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, zT_3A105EF1_Symbol*);
unsigned int zF_DDD991E1_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_151B0DD7_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*);
void zF_E3B2C29D_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_5BBD6EB3_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_86D8CE03_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*);
void zF_2C47D4E0_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_055533B0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*);
void zF_B5A1E8BB_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_E42B9323_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned char);
void zF_C26EF425_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_FC6E31C6_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_6A91A8CC_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_F705063A_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_4E74AE9D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_5EF7F98D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
void zF_E3AF2BA9_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_1BB4D489_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_44006DDD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_8143F551_AstKind);
unsigned int zF_733BCA9C_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_280E1A92_semanticAnalyzerTag(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_4B0CAC92_semanticAnalyzerTag(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned int zF_EB621FF0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_8143F551_AstKind);
unsigned int zF_6F2B8B98_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_09421FDF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_6B59E8AD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_57090266_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_86AAA417_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned char zF_3283D0A4_semanticAnalyzerCon(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_90151159_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_FC6BF0DC_semanticAnalyzerFie(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_3CD1A9C3_semanticAnalyzerCon(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned char zF_807D2FA4_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned char zF_5F2042EA_semanticAnalyzerPtr(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_EC29CB82_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_F6BD8EEF_semanticAnalyzerFlo(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_F9DC142E_semanticAnalyzerFlo(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned char zF_AB3132C7_semanticAnalyzerFlo(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, unsigned int);
unsigned char zF_FAA13FB0_semanticAnalyzerFlo(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_5F8DC051_semanticAnalyzerFlo(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_8DAE60E5_semanticAnalyzerTyp(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, unsigned char);
void zF_DF7434EB_tryRecordCoercion(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned char zF_71304A07_isStringLiteralSlic(zT_0FB7FB13_CoercionKind);
unsigned int zF_FFC95E09_errLitSrcType(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
void zF_F231D87F_resolveReturnStmt(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_FD5F2872_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, unsigned char, unsigned int, unsigned int);
unsigned int zF_CCDFC014_semanticAnalyzerPar(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_21679C82_semanticAnalyzerIsP(zT_33EF6BFB_TypeKind);
unsigned char zF_82E50E0B_semanticAnalyzerCal(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_16A84A03_semanticAnalyzerCal(zT_38C12417_SemanticAnalyzer*, unsigned int);
zT_557B6199_Opt_875 zF_5A5DC8FD_semanticAnalyzerCal(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_87E78775_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_9B9B3C7B_semanticAnalyzerTry(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_8F083A69_Slice_zT_0B42B2F8_u);
unsigned int zF_B78F27CD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_B36961FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
zT_49E17557_Opt_2 zF_FFA59A1A_semanticAnalyzerCon(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_27B72BD2_semanticAnalyzerCon(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_8B8EE70D_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_8C008E53_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_AD7EF126_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_689D82E1_semanticAnalyzerIsL(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_C0551BB8_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_6CE9DDDA_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_B3615C83_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned char);
unsigned int zF_DA7E3897_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_2DB4F186_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_54F95822_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_0573F6A4_semanticAnalyzerFnV(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_3ACACEE8_semanticAnalyzerFnP(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_148F8E19_semanticAnalyzerFnP(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_D728034A_isBShapeMismatch(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned char);
void zF_406A2501_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_15CE7BE8_fnReturnRequiresVal(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_AA164297_astTerminates(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_A3A1FD27_astSwitchTerminates(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_DCF9800F_astSwitchExhaustive(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned char zF_FB2132D0_astWhileTerminates(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_B5177CCC_astSubtreeHasBreak(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_7AB741D8_semanticAnalyzerStm(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_9665A229_pushExpectedType(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_BC478E78_popExpectedType(zT_38C12417_SemanticAnalyzer*);
unsigned int zF_4DE7C2BC_topExpectedType(zT_38C12417_SemanticAnalyzer*);
void zF_64F73ABA_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, unsigned char);
void zF_0324C9A3_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_F20866F5_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_02389538_semanticAnalyzerFor(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_329C131D_semanticAnalyzerRep(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_D366C073_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_8CE01C41_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_10900223_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_10A0DC35_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_DE5079F2_semaTraceStep(zT_38C12417_SemanticAnalyzer*, unsigned int*, unsigned char*);
unsigned int zF_1926BC05_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_F902E73E_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_E794D3E5_semanticAnalyzerTup(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_23FCE3E6_semanticAnalyzerTup(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned char zF_285AD9DD_semanticAnalyzerTup(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_227D2404_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_F3DAABE0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_979B6CFF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_CC4377FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_SEMANTIC_ANALYZER_4DBE89E5_H */
