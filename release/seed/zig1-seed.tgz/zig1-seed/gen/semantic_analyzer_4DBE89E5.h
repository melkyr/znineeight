#ifndef ZIG_MODULE_SEMANTIC_ANALYZER_4DBE89E5_H
#define ZIG_MODULE_SEMANTIC_ANALYZER_4DBE89E5_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "type_registry_8EE489B8.h"
#include "resolved_type_table_5F22E794.h"
#include "diagnostics_B9C6175E.h"
#include "symbol_table_74081C75.h"
#include "ast_2FA12982.h"
#include "coercion_F654E5FA.h"
#include "hash_02AFCD13.h"
#include "pal_388A8A1B.h"
#include "itoa_4E677A6A.h"
#include "string_interner_51340A9F.h"
#include "type_resolver_7446D285.h"
#include "module_registry_03A5D1FC.h"
#include "async_analysis_A8747991.h"

#ifndef ZIG_STRUCT_zT_38C12417_SemanticAnalyzer
#define ZIG_STRUCT_zT_38C12417_SemanticAnalyzer
struct zT_38C12417_SemanticAnalyzer {
	zT_8EED1867_ResolvedTypeTable* type_table;
	zT_F85C5DED_DiagnosticCollector* diag;
	zT_338B7C76_TypeRegistry* registry;
	zT_3D7259E2_SymbolRegistry* symbols;
	zT_6B0A7D14_AstStore* store;
	unsigned int module_id;
	unsigned int source_file_id;
	unsigned int* expected_type_stack_items;
	unsigned int expected_type_stack_len;
	unsigned int expected_type_stack_cap;
	zT_3E40CD83_Sand* expected_type_stack_alloc;
	unsigned int* stmt_work_items;
	unsigned int stmt_work_len;
	unsigned int stmt_work_cap;
	unsigned int current_fn_return;
	unsigned int current_fn_name;
	zT_66E7D2EF_CoercionTable* coercion_table;
	zT_21D3708C_U32ToU32Map* enum_value_table;
	zT_21D3708C_U32ToU32Map* error_code_registry;
	zT_21D3708C_U32ToU32Map* call_arg_types;
	zT_21D3708C_U32ToU32Map* call_param_map;
	unsigned int current_switch_cond_tu;
	unsigned int switch_depth;
	unsigned int* local_decl_names;
	unsigned int* local_decl_types;
	unsigned int local_decl_count;
	unsigned int local_decl_cap;
	unsigned int* packed_gate_items;
	unsigned int packed_gate_len;
	unsigned int packed_gate_cap;
	unsigned int* packed_struct_tids;
	unsigned int* packed_struct_decl_nodes;
	unsigned int packed_struct_cache_len;
	unsigned int packed_struct_cache_cap;
	unsigned int* checked_struct_tids;
	unsigned int checked_struct_tids_len;
	unsigned int checked_struct_tids_cap;
	unsigned int _stub_0;
	unsigned int _stub_1;
	zT_D3EB6303_StringInterner* interner;
	unsigned int ptrcast_name_id;
	unsigned int volatilecast_name_id;
	unsigned int ptrtoint_name_id;
	unsigned int inttoptr_name_id;
	unsigned int int_from_ptr_name_id;
	unsigned int ptr_from_int_name_id;
	unsigned int field_parent_ptr_name_id;
	unsigned int bitcast_name_id;
	unsigned int intcast_name_id;
	unsigned int floatcast_name_id;
	unsigned int inttofloat_name_id;
	unsigned int inttoenum_name_id;
	unsigned int enumtoint_name_id;
	unsigned int as_name_id;
	unsigned int size_of_name_id;
	unsigned int align_of_name_id;
	unsigned int offset_of_name_id;
	unsigned int bit_size_of_name_id;
	unsigned int bit_offset_of_name_id;
	unsigned int putchar_name_id;
	unsigned int stdout_write_name_id;
	unsigned int stderr_write_name_id;
	unsigned int getchar_name_id;
	unsigned int exit_name_id;
	unsigned int panic_name_id;
	unsigned int sleep_ms_name_id;
	unsigned int is_windows_name_id;
	unsigned int console_clear_name_id;
	unsigned int console_gotoxy_name_id;
	unsigned int console_set_color_name_id;
	unsigned int async_frame_size_name_id;
	unsigned int async_init_name_id;
	unsigned int async_resume_name_id;
	unsigned int async_suspend_name_id;
	int async_analysis_ready;
	zT_072B53A6_ModuleRegistry* module_reg;
	zT_A4CE86B7_U64ToU32Map* suspending_fns;
};
#endif /* ZIG_STRUCT_zT_38C12417_SemanticAnalyzer */

/* Forward declarations */
zT_38C12417_SemanticAnalyzer zF_84ADA681_semanticAnalyzerIni(zT_3E40CD83_Sand*, zT_8EED1867_ResolvedTypeTable*, zT_F85C5DED_DiagnosticCollector*, zT_338B7C76_TypeRegistry*, zT_3D7259E2_SymbolRegistry*, zT_6B0A7D14_AstStore*, unsigned int, unsigned int, zT_66E7D2EF_CoercionTable*, zT_21D3708C_U32ToU32Map*, zT_21D3708C_U32ToU32Map*, zT_D3EB6303_StringInterner*, zT_21D3708C_U32ToU32Map*, zT_21D3708C_U32ToU32Map*, zT_072B53A6_ModuleRegistry*, zT_A4CE86B7_U64ToU32Map*);
int zF_3757023F_semanticAnalyzerIsT(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_2ACB4E23_semanticAnalyzerBui(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
int zF_CAF1FD28_semanticAnalyzerIsB(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_D4D0798B_semanticAnalyzerDia(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_156C79D0_semanticAnalyzerGro(zT_38C12417_SemanticAnalyzer*);
void zF_7BD72017_registerLocalDecl(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
unsigned int zF_3E251D67_semanticAnalyzerCap(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_9F1ECA79_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_DDD991E1_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_151B0DD7_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*);
void zF_E3B2C29D_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_5BBD6EB3_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_86D8CE03_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*);
void zF_2C47D4E0_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_055533B0_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*);
void zF_B5A1E8BB_semanticAnalyzerChe(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_E42B9323_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int, int);
void zF_C26EF425_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_FC6E31C6_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_6A91A8CC_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_F705063A_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_4E74AE9D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_5EF7F98D_semanticAnalyzerGat(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_1BB4D489_semanticAnalyzerPac(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_44006DDD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_8143F551_AstKind);
unsigned int zF_733BCA9C_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_EB621FF0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_8143F551_AstKind);
unsigned int zF_6F2B8B98_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_09421FDF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_6B59E8AD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_57090266_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
int zF_86AAA417_semanticAnalyzerMay(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
int zF_5F2042EA_semanticAnalyzerPtr(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
int zF_EC29CB82_semanticAnalyzerVol(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_DF7434EB_tryRecordCoercion(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
unsigned int zF_FFC95E09_errLitSrcType(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int, unsigned int);
void zF_F231D87F_resolveReturnStmt(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_87E78775_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_B78F27CD_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_B36961FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_8B8EE70D_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_8C008E53_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_AD7EF126_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_C0551BB8_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_2DB4F186_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_54F95822_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_148F8E19_semanticAnalyzerFnP(zT_38C12417_SemanticAnalyzer*, unsigned int, unsigned int);
void zF_406A2501_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_15CE7BE8_fnReturnRequiresVal(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_AA164297_astTerminates(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_A3A1FD27_astSwitchTerminates(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_DCF9800F_astSwitchExhaustive(zT_38C12417_SemanticAnalyzer*, unsigned int, zT_3CB0179A_Slice_zT_05F374B1_u);
int zF_FB2132D0_astWhileTerminates(zT_38C12417_SemanticAnalyzer*, unsigned int);
int zF_B5177CCC_astSubtreeHasBreak(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_7AB741D8_semanticAnalyzerStm(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_9665A229_pushExpectedType(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_BC478E78_popExpectedType(zT_38C12417_SemanticAnalyzer*);
unsigned int zF_4DE7C2BC_topExpectedType(zT_38C12417_SemanticAnalyzer*);
void zF_0324C9A3_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_8CE01C41_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_10900223_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_10A0DC35_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_DE5079F2_semaTraceStep(zT_38C12417_SemanticAnalyzer*, unsigned int*, unsigned char*);
unsigned int zF_1926BC05_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_F902E73E_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_227D2404_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_F3DAABE0_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
void zF_979B6CFF_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
unsigned int zF_CC4377FA_semanticAnalyzerRes(zT_38C12417_SemanticAnalyzer*, unsigned int);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_SEMANTIC_ANALYZER_4DBE89E5_H */
