#include "comptime_eval_02C4526F.h"
/* comptimeEvalInit */
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry* registry, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_3D7259E2_SymbolRegistry* symbol_reg) {
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_D3EB6303_StringInterner* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    zT_D3EB6303_StringInterner* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23 = 0;
    zT_D3EB6303_StringInterner* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27 = 0;
    char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_D3EB6303_StringInterner* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43 = 0;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    zT_D3EB6303_StringInterner* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51 = 0;
    char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    zT_D3EB6303_StringInterner* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59 = 0;
    zT_DA663F79_ComptimeEval zT_60;
    int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    unsigned int size_id;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int off_id;
    unsigned int bitsz_id;
    unsigned int bitoff_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_iw;
    unsigned int iw_id;
    zT_5 = "@sizeOf";
    zT_7 = 7;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_size = zT_6;
    s_size = zT_6;
    s_size = zT_6;
    zT_9 = "@alignOf";
    zT_11 = 8;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_align = zT_10;
    s_align = zT_10;
    s_align = zT_10;
    zT_13 = "@intCast";
    zT_15 = 8;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    s_intc = zT_14;
    s_intc = zT_14;
    s_intc = zT_14;
    zT_17 = interner;
    zT_18 = s_intc;
    zT_19 = zF_50C274AF_stringInternerInter(zT_17, zT_18);
    intc_id = zT_19;
    intc_id = zT_19;
    intc_id = zT_19;
    zT_21 = interner;
    zT_22 = s_size;
    zT_23 = zF_50C274AF_stringInternerInter(zT_21, zT_22);
    size_id = zT_23;
    size_id = zT_23;
    size_id = zT_23;
    zT_25 = interner;
    zT_26 = s_align;
    zT_27 = zF_50C274AF_stringInternerInter(zT_25, zT_26);
    align_id = zT_27;
    align_id = zT_27;
    align_id = zT_27;
    zT_29 = "@offsetOf";
    zT_31 = 9;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    s_off = zT_30;
    s_off = zT_30;
    s_off = zT_30;
    zT_33 = "@bitSizeOf";
    zT_35 = 10;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    s_bitsz = zT_34;
    s_bitsz = zT_34;
    s_bitsz = zT_34;
    zT_37 = "@bitOffsetOf";
    zT_39 = 12;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    s_bitoff = zT_38;
    s_bitoff = zT_38;
    s_bitoff = zT_38;
    zT_41 = interner;
    zT_42 = s_off;
    zT_43 = zF_50C274AF_stringInternerInter(zT_41, zT_42);
    off_id = zT_43;
    off_id = zT_43;
    off_id = zT_43;
    zT_45 = interner;
    zT_46 = s_bitsz;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    bitsz_id = zT_47;
    bitsz_id = zT_47;
    bitsz_id = zT_47;
    zT_49 = interner;
    zT_50 = s_bitoff;
    zT_51 = zF_50C274AF_stringInternerInter(zT_49, zT_50);
    bitoff_id = zT_51;
    bitoff_id = zT_51;
    bitoff_id = zT_51;
    zT_53 = "@isWindows";
    zT_55 = 10;
    zT_54.ptr = zT_53;
    zT_54.len = zT_55;
    s_iw = zT_54;
    s_iw = zT_54;
    s_iw = zT_54;
    zT_57 = interner;
    zT_58 = s_iw;
    zT_59 = zF_50C274AF_stringInternerInter(zT_57, zT_58);
    iw_id = zT_59;
    iw_id = zT_59;
    iw_id = zT_59;
    zT_60.registry = registry;
    zT_60.store = store;
    zT_60.interner = interner;
    zT_60.symbol_reg = symbol_reg;
    zT_60.size_of_id = size_id;
    zT_60.align_of_id = align_id;
    zT_60.int_cast_id = intc_id;
    zT_60.offset_of_id = off_id;
    zT_60.bit_size_of_id = bitsz_id;
    zT_60.bit_offset_of_id = bitoff_id;
    zT_60.is_windows_id = iw_id;
    zT_61 = 0;
    zT_60.host_is_windows = zT_61;
    return zT_60;
}

/* comptimeEvalBinOp */
zT_5BBDF77D_Opt_189 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_5BBDF77D_Opt_189 zT_14 = {0};
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_5BBDF77D_Opt_189 zT_20 = {0};
    unsigned char zT_21;
    unsigned char zT_23;
    zT_79FAE712_u64 zT_26;
    zT_79FAE712_u64 zT_28;
    int zT_30;
    int zT_31;
    int zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    int zT_36;
    unsigned int zT_37;
    zT_8143F551_AstKind zT_40;
    int zT_41;
    zT_89B1DDDA_ComptimeVal zT_42;
    zT_79FAE712_u64 zT_43;
    zT_5BBDF77D_Opt_189 zT_44;
    zT_8143F551_AstKind zT_47;
    int zT_48;
    zT_89B1DDDA_ComptimeVal zT_49;
    zT_79FAE712_u64 zT_50;
    zT_5BBDF77D_Opt_189 zT_51;
    zT_8143F551_AstKind zT_54;
    int zT_55;
    zT_89B1DDDA_ComptimeVal zT_56;
    zT_79FAE712_u64 zT_57;
    zT_5BBDF77D_Opt_189 zT_58;
    zT_8143F551_AstKind zT_61;
    int zT_62;
    zT_79FAE712_u64 zT_63;
    int zT_64;
    zT_5BBDF77D_Opt_189 zT_65 = {0};
    zT_79FAE712_u64 zT_67;
    zT_79FAE712_u64 zT_68;
    zT_79FAE712_u64 zT_69;
    zT_79FAE712_u64 zT_70;
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    zT_79FAE712_u64 zT_74;
    zT_79FAE712_u64 zT_75;
    zT_79FAE712_u64 zT_77 = 0;
    zT_79FAE712_u64 zT_79 = 0;
    zT_79FAE712_u64 zT_80;
    int zT_81;
    zT_79FAE712_u64 zT_82;
    zT_79FAE712_u64 zT_83;
    zT_79FAE712_u64 zT_84;
    int zT_85;
    zT_79FAE712_u64 zT_86;
    zT_79FAE712_u64 zT_87;
    zT_79FAE712_u64 zT_89;
    int zT_90;
    zT_79FAE712_u64 zT_91;
    zT_79FAE712_u64 zT_92;
    zT_89B1DDDA_ComptimeVal zT_93;
    int zT_94;
    zT_5BBDF77D_Opt_189 zT_95;
    zT_89B1DDDA_ComptimeVal zT_96;
    zT_79FAE712_u64 zT_97;
    int zT_98;
    zT_5BBDF77D_Opt_189 zT_99;
    zT_8143F551_AstKind zT_102;
    int zT_103;
    zT_79FAE712_u64 zT_104;
    int zT_105;
    zT_5BBDF77D_Opt_189 zT_106 = {0};
    zT_79FAE712_u64 zT_108;
    zT_79FAE712_u64 zT_109;
    zT_79FAE712_u64 zT_110;
    zT_79FAE712_u64 zT_111;
    zT_79FAE712_u64 zT_113;
    zT_79FAE712_u64 zT_114;
    zT_79FAE712_u64 zT_115;
    zT_79FAE712_u64 zT_116;
    zT_79FAE712_u64 zT_118 = 0;
    zT_79FAE712_u64 zT_120 = 0;
    zT_79FAE712_u64 zT_121;
    int zT_122;
    zT_79FAE712_u64 zT_123;
    zT_79FAE712_u64 zT_124;
    zT_79FAE712_u64 zT_125;
    int zT_126;
    zT_79FAE712_u64 zT_127;
    zT_79FAE712_u64 zT_128;
    zT_79FAE712_u64 zT_130;
    zT_79FAE712_u64 zT_131;
    int zT_132;
    zT_79FAE712_u64 zT_133;
    zT_79FAE712_u64 zT_134;
    zT_89B1DDDA_ComptimeVal zT_135;
    int zT_136;
    zT_5BBDF77D_Opt_189 zT_137;
    zT_89B1DDDA_ComptimeVal zT_138;
    zT_79FAE712_u64 zT_139;
    int zT_140;
    zT_5BBDF77D_Opt_189 zT_141;
    zT_8143F551_AstKind zT_144;
    int zT_145;
    zT_89B1DDDA_ComptimeVal zT_146;
    zT_79FAE712_u64 zT_147;
    zT_5BBDF77D_Opt_189 zT_148;
    zT_8143F551_AstKind zT_151;
    int zT_152;
    zT_89B1DDDA_ComptimeVal zT_153;
    zT_79FAE712_u64 zT_154;
    zT_5BBDF77D_Opt_189 zT_155;
    zT_8143F551_AstKind zT_158;
    int zT_159;
    zT_89B1DDDA_ComptimeVal zT_160;
    zT_79FAE712_u64 zT_161;
    zT_5BBDF77D_Opt_189 zT_162;
    zT_8143F551_AstKind zT_165;
    int zT_166;
    zT_79FAE712_u64 zT_167;
    int zT_168;
    zT_5BBDF77D_Opt_189 zT_169 = {0};
    zT_89B1DDDA_ComptimeVal zT_170;
    zT_79FAE712_u64 zT_171;
    zT_5BBDF77D_Opt_189 zT_172;
    zT_8143F551_AstKind zT_175;
    int zT_176;
    zT_79FAE712_u64 zT_177;
    int zT_178;
    zT_5BBDF77D_Opt_189 zT_179 = {0};
    zT_89B1DDDA_ComptimeVal zT_180;
    zT_79FAE712_u64 zT_181;
    zT_5BBDF77D_Opt_189 zT_182;
    zT_5BBDF77D_Opt_189 zT_183 = {0};
    zT_22A7C88B_AstNode node;
    zT_5BBDF77D_Opt_189 lhs;
    zT_5BBDF77D_Opt_189 rhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_89B1DDDA_ComptimeVal r;
    zT_79FAE712_u64 lv;
    zT_79FAE712_u64 rv;
    int use_signed;
    unsigned int maxw;
    zT_79FAE712_u64 sl;
    zT_79FAE712_u64 sr;
    zT_79FAE712_u64 al;
    zT_79FAE712_u64 ar;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 rem;
    zT_7 = self->store;
    zT_5 = zT_7;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    node = zT_8;
    node = zT_8;
    zT_10 = self;
    zT_13 = node.child_0;
    zT_11 = zT_13;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    lhs = zT_14;
    lhs = zT_14;
    zT_16 = self;
    zT_19 = node.child_1;
    zT_17 = zT_19;
    zT_18 = depth;
    zT_20 = zF_4EE17137_comptimeEvalEvaluat(zT_16, zT_17, zT_18);
    rhs = zT_20;
    rhs = zT_20;
    rhs = zT_20;
    zT_21 = lhs.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    l = lhs.value;
    zT_23 = rhs.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_183.has_value = 0;
    return zT_183;
    z_bb_3:
    r = rhs.value;
    zT_26 = l.bits;
    lv = zT_26;
    lv = zT_26;
    lv = zT_26;
    zT_28 = r.bits;
    rv = zT_28;
    rv = zT_28;
    rv = zT_28;
    zT_30 = l.sig;
    if (zT_30) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_32 = r.sig;
    zT_31 = zT_32;
    goto z_bb_7;
    z_bb_6:
    zT_31 = 1;
    goto z_bb_7;
    z_bb_7:
    use_signed = zT_31;
    use_signed = zT_31;
    use_signed = zT_31;
    zT_34 = l.width_bits;
    maxw = zT_34;
    maxw = zT_34;
    maxw = zT_34;
    zT_35 = r.width_bits;
    zT_36 = zT_35 > maxw;
    if (zT_36) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = r.width_bits;
    maxw = zT_37;
    maxw = zT_37;
    goto z_bb_9;
    z_bb_9:
    zT_40 = zT_8143F551_AstKind_add;
    zT_41 = op_kind == zT_40;
    if (zT_41) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_43 = lv + rv;
    zT_42.bits = zT_43;
    zT_42.width_bits = maxw;
    zT_42.sig = use_signed;
    zT_44.has_value = 1;
    zT_44.value = zT_42;
    return zT_44;
    z_bb_11:
    zT_47 = zT_8143F551_AstKind_sub;
    zT_48 = op_kind == zT_47;
    if (zT_48) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_50 = lv - rv;
    zT_49.bits = zT_50;
    zT_49.width_bits = maxw;
    zT_49.sig = use_signed;
    zT_51.has_value = 1;
    zT_51.value = zT_49;
    return zT_51;
    z_bb_13:
    zT_54 = zT_8143F551_AstKind_mul;
    zT_55 = op_kind == zT_54;
    if (zT_55) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_57 = lv * rv;
    zT_56.bits = zT_57;
    zT_56.width_bits = maxw;
    zT_56.sig = use_signed;
    zT_58.has_value = 1;
    zT_58.value = zT_56;
    return zT_58;
    z_bb_15:
    zT_61 = zT_8143F551_AstKind_div;
    zT_62 = op_kind == zT_61;
    if (zT_62) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_63 = 0;
    zT_64 = rv == zT_63;
    if (zT_64) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_102 = zT_8143F551_AstKind_mod_op;
    zT_103 = op_kind == zT_102;
    if (zT_103) goto z_bb_30; else goto z_bb_31;
    z_bb_18:
    zT_65.has_value = 0;
    return zT_65;
    z_bb_19:
    if (use_signed) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_67 = 63;
    zT_68 = lv >> zT_67;
    zT_69 = 1;
    zT_70 = zT_68 & zT_69;
    sl = zT_70;
    sl = zT_70;
    sl = zT_70;
    zT_72 = 63;
    zT_73 = rv >> zT_72;
    zT_74 = 1;
    zT_75 = zT_73 & zT_74;
    sr = zT_75;
    sr = zT_75;
    sr = zT_75;
    al = zT_77;
    ar = zT_79;
    zT_80 = 1;
    zT_81 = sl == zT_80;
    if (zT_81) goto z_bb_22; else goto z_bb_24;
    z_bb_21:
    zT_97 = lv / rv;
    zT_96.bits = zT_97;
    zT_96.width_bits = maxw;
    zT_98 = 0;
    zT_96.sig = zT_98;
    zT_99.has_value = 1;
    zT_99.value = zT_96;
    return zT_99;
    z_bb_22:
    zT_82 = 0;
    zT_83 = zT_82 - lv;
    al = zT_83;
    al = zT_83;
    goto z_bb_23;
    z_bb_23:
    zT_84 = 1;
    zT_85 = sr == zT_84;
    if (zT_85) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    al = lv;
    al = lv;
    goto z_bb_23;
    z_bb_25:
    zT_86 = 0;
    zT_87 = zT_86 - rv;
    ar = zT_87;
    ar = zT_87;
    goto z_bb_26;
    z_bb_26:
    zT_89 = al / ar;
    q = zT_89;
    q = zT_89;
    q = zT_89;
    zT_90 = sl != sr;
    if (zT_90) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    ar = rv;
    ar = rv;
    goto z_bb_26;
    z_bb_28:
    zT_91 = 0;
    zT_92 = zT_91 - q;
    q = zT_92;
    q = zT_92;
    goto z_bb_29;
    z_bb_29:
    zT_93.bits = q;
    zT_93.width_bits = maxw;
    zT_94 = 1;
    zT_93.sig = zT_94;
    zT_95.has_value = 1;
    zT_95.value = zT_93;
    return zT_95;
    z_bb_30:
    zT_104 = 0;
    zT_105 = rv == zT_104;
    if (zT_105) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_144 = zT_8143F551_AstKind_bit_and;
    zT_145 = op_kind == zT_144;
    if (zT_145) goto z_bb_44; else goto z_bb_45;
    z_bb_32:
    zT_106.has_value = 0;
    return zT_106;
    z_bb_33:
    if (use_signed) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_108 = 63;
    zT_109 = lv >> zT_108;
    zT_110 = 1;
    zT_111 = zT_109 & zT_110;
    sl = zT_111;
    sl = zT_111;
    sl = zT_111;
    zT_113 = 63;
    zT_114 = rv >> zT_113;
    zT_115 = 1;
    zT_116 = zT_114 & zT_115;
    sr = zT_116;
    sr = zT_116;
    sr = zT_116;
    al = zT_118;
    ar = zT_120;
    zT_121 = 1;
    zT_122 = sl == zT_121;
    if (zT_122) goto z_bb_36; else goto z_bb_38;
    z_bb_35:
    zT_139 = lv % rv;
    zT_138.bits = zT_139;
    zT_138.width_bits = maxw;
    zT_140 = 0;
    zT_138.sig = zT_140;
    zT_141.has_value = 1;
    zT_141.value = zT_138;
    return zT_141;
    z_bb_36:
    zT_123 = 0;
    zT_124 = zT_123 - lv;
    al = zT_124;
    al = zT_124;
    goto z_bb_37;
    z_bb_37:
    zT_125 = 1;
    zT_126 = sr == zT_125;
    if (zT_126) goto z_bb_39; else goto z_bb_41;
    z_bb_38:
    al = lv;
    al = lv;
    goto z_bb_37;
    z_bb_39:
    zT_127 = 0;
    zT_128 = zT_127 - rv;
    ar = zT_128;
    ar = zT_128;
    goto z_bb_40;
    z_bb_40:
    zT_130 = al % ar;
    rem = zT_130;
    rem = zT_130;
    rem = zT_130;
    zT_131 = 1;
    zT_132 = sl == zT_131;
    if (zT_132) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    ar = rv;
    ar = rv;
    goto z_bb_40;
    z_bb_42:
    zT_133 = 0;
    zT_134 = zT_133 - rem;
    rem = zT_134;
    rem = zT_134;
    goto z_bb_43;
    z_bb_43:
    zT_135.bits = rem;
    zT_135.width_bits = maxw;
    zT_136 = 1;
    zT_135.sig = zT_136;
    zT_137.has_value = 1;
    zT_137.value = zT_135;
    return zT_137;
    z_bb_44:
    zT_147 = lv & rv;
    zT_146.bits = zT_147;
    zT_146.width_bits = maxw;
    zT_146.sig = use_signed;
    zT_148.has_value = 1;
    zT_148.value = zT_146;
    return zT_148;
    z_bb_45:
    zT_151 = zT_8143F551_AstKind_bit_or;
    zT_152 = op_kind == zT_151;
    if (zT_152) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_154 = lv | rv;
    zT_153.bits = zT_154;
    zT_153.width_bits = maxw;
    zT_153.sig = use_signed;
    zT_155.has_value = 1;
    zT_155.value = zT_153;
    return zT_155;
    z_bb_47:
    zT_158 = zT_8143F551_AstKind_bit_xor;
    zT_159 = op_kind == zT_158;
    if (zT_159) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_161 = lv ^ rv;
    zT_160.bits = zT_161;
    zT_160.width_bits = maxw;
    zT_160.sig = use_signed;
    zT_162.has_value = 1;
    zT_162.value = zT_160;
    return zT_162;
    z_bb_49:
    zT_165 = zT_8143F551_AstKind_shl;
    zT_166 = op_kind == zT_165;
    if (zT_166) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_167 = 64;
    zT_168 = rv >= zT_167;
    if (zT_168) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    zT_175 = zT_8143F551_AstKind_shr;
    zT_176 = op_kind == zT_175;
    if (zT_176) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_169.has_value = 0;
    return zT_169;
    z_bb_53:
    zT_171 = lv << rv;
    zT_170.bits = zT_171;
    zT_170.width_bits = maxw;
    zT_170.sig = use_signed;
    zT_172.has_value = 1;
    zT_172.value = zT_170;
    return zT_172;
    z_bb_54:
    zT_177 = 64;
    zT_178 = rv >= zT_177;
    if (zT_178) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_4;
    z_bb_56:
    zT_179.has_value = 0;
    return zT_179;
    z_bb_57:
    zT_181 = lv >> rv;
    zT_180.bits = zT_181;
    zT_180.width_bits = maxw;
    zT_180.sig = use_signed;
    zT_182.has_value = 1;
    zT_182.value = zT_180;
    return zT_182;
}

/* comptimeEvalResolveTypeArg */
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    unsigned int zT_2;
    int zT_3;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    zT_ABC1EBBE_TypeResolveEnv* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_ABC1EBBE_TypeResolveEnv* zT_16;
    unsigned int zT_17;
    unsigned int zT_18 = 0;
    unsigned int zT_19;
    int zT_20;
    zT_BAEE192E_Opt_10 zT_21 = {0};
    zT_BAEE192E_Opt_10 zT_22;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int tid;
    zT_2 = 0;
    zT_3 = node_idx == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_7 = self->store;
    zT_6.store = zT_7;
    zT_8 = self->registry;
    zT_6.typereg = zT_8;
    zT_9 = self->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = self->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    env = zT_6;
    env = zT_6;
    env = zT_6;
    zT_16 = &env;
    zT_13 = zT_16;
    zT_14 = node_idx;
    zT_17 = 0;
    zT_15 = zT_17;
    zT_18 = zF_F2107C15_resolveTypeExprFull(zT_13, zT_14, zT_15);
    tid = zT_18;
    tid = zT_18;
    tid = zT_18;
    zT_19 = 18;
    zT_20 = tid == zT_19;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21.has_value = 0;
    return zT_21;
    z_bb_4:
    zT_22.has_value = 1;
    zT_22.value = tid;
    return zT_22;
}

/* comptimeEvalBuiltin */
zT_5BBDF77D_Opt_189 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_14;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_15 = {0};
    zT_DA663F79_ComptimeEval* zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_BAEE192E_Opt_10 zT_22 = {0};
    unsigned char zT_23;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_D155D06D_Type* zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    int zT_32;
    zT_89B1DDDA_ComptimeVal zT_33;
    unsigned int zT_34;
    zT_79FAE712_u64 zT_35;
    unsigned int zT_36;
    int zT_37;
    zT_5BBDF77D_Opt_189 zT_38;
    zT_5BBDF77D_Opt_189 zT_39 = {0};
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_6B0A7D14_AstStore* zT_46;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_47 = {0};
    zT_DA663F79_ComptimeEval* zT_49;
    unsigned int zT_50;
    unsigned int* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_BAEE192E_Opt_10 zT_54 = {0};
    unsigned char zT_55;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_D155D06D_Type* zT_59;
    unsigned int zT_60;
    zT_D155D06D_Type zT_61;
    unsigned char zT_62;
    unsigned char zT_63;
    int zT_64;
    zT_89B1DDDA_ComptimeVal zT_65;
    unsigned int zT_66;
    zT_79FAE712_u64 zT_67;
    unsigned int zT_68;
    int zT_69;
    zT_5BBDF77D_Opt_189 zT_70;
    zT_5BBDF77D_Opt_189 zT_71 = {0};
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    zT_6B0A7D14_AstStore* zT_82;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_83 = {0};
    unsigned int zT_85;
    unsigned int zT_86;
    int zT_87;
    zT_DA663F79_ComptimeEval* zT_89;
    unsigned int zT_90;
    unsigned int* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_BAEE192E_Opt_10 zT_94 = {0};
    unsigned char zT_95;
    zT_338B7C76_TypeRegistry* zT_98;
    zT_D155D06D_Type* zT_99;
    unsigned int zT_100;
    zT_D155D06D_Type zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    int zT_104;
    int zT_105;
    zT_33EF6BFB_TypeKind zT_106;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_110;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_112 = {0};
    zT_338B7C76_TypeRegistry* zT_113;
    unsigned int zT_114;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_115;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_117;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_119 = {0};
    zT_338B7C76_TypeRegistry* zT_121;
    unsigned int zT_122;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_123;
    zT_338B7C76_TypeRegistry* zT_124;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_125;
    int zT_126 = 0;
    zT_6B0A7D14_AstStore* zT_128;
    unsigned int zT_129;
    zT_6B0A7D14_AstStore* zT_130;
    unsigned int* zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    zT_22A7C88B_AstNode zT_134 = {0};
    zT_8143F551_AstKind zT_135;
    zT_8143F551_AstKind zT_138;
    int zT_139;
    zT_6B0A7D14_AstStore* zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147 = 0;
    zT_6B0A7D14_AstStore* zT_149;
    zT_35D75C01_anon_170050 zT_150;
    unsigned int* zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    int zT_155;
    unsigned int zT_156;
    unsigned int zT_158;
    int zT_159;
    zT_2DF01B61_FieldEntry* zT_160;
    zT_2DF01B61_FieldEntry zT_161;
    unsigned int zT_162;
    int zT_163;
    zT_2DF01B61_FieldEntry* zT_165;
    zT_2DF01B61_FieldEntry zT_166;
    unsigned int zT_167;
    zT_79FAE712_u64 zT_168;
    zT_79FAE712_u64 zT_170;
    unsigned int zT_172;
    int zT_173;
    zT_E276DDD0_PackedBitField* zT_174;
    zT_E276DDD0_PackedBitField zT_175;
    unsigned int zT_176;
    zT_79FAE712_u64 zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    int zT_180;
    zT_79FAE712_u64 zT_181;
    zT_79FAE712_u64 zT_182;
    unsigned int zT_183;
    unsigned int zT_184;
    int zT_185;
    zT_79FAE712_u64 zT_186;
    zT_79FAE712_u64 zT_187;
    zT_89B1DDDA_ComptimeVal zT_188;
    unsigned int zT_189;
    int zT_190;
    zT_5BBDF77D_Opt_189 zT_191;
    int zT_192;
    unsigned int zT_193;
    unsigned char zT_194;
    unsigned char zT_195;
    int zT_196;
    int zT_197;
    zT_33EF6BFB_TypeKind zT_198;
    zT_33EF6BFB_TypeKind zT_201;
    int zT_202;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_204 = {0};
    zT_338B7C76_TypeRegistry* zT_205;
    unsigned int zT_206;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_207;
    zT_338B7C76_TypeRegistry* zT_208;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_209;
    zT_6B0A7D14_AstStore* zT_211;
    unsigned int zT_212;
    zT_6B0A7D14_AstStore* zT_213;
    unsigned int* zT_214;
    unsigned int zT_215;
    unsigned int zT_216;
    zT_22A7C88B_AstNode zT_217 = {0};
    zT_8143F551_AstKind zT_218;
    zT_8143F551_AstKind zT_221;
    int zT_222;
    zT_6B0A7D14_AstStore* zT_224;
    unsigned int zT_225;
    zT_6B0A7D14_AstStore* zT_226;
    unsigned int* zT_227;
    unsigned int zT_228;
    unsigned int zT_229;
    unsigned int zT_230 = 0;
    zT_6B0A7D14_AstStore* zT_232;
    zT_35D75C01_anon_170050 zT_233;
    unsigned int* zT_234;
    unsigned int zT_235;
    unsigned int zT_236;
    int zT_238;
    unsigned int zT_239;
    unsigned int zT_241;
    int zT_242;
    zT_2DF01B61_FieldEntry* zT_243;
    zT_2DF01B61_FieldEntry zT_244;
    unsigned int zT_245;
    int zT_246;
    zT_79FAE712_u64 zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    int zT_251;
    zT_79FAE712_u64 zT_252;
    zT_89B1DDDA_ComptimeVal zT_253;
    unsigned int zT_254;
    int zT_255;
    zT_5BBDF77D_Opt_189 zT_256;
    int zT_257;
    unsigned int zT_258;
    zT_5BBDF77D_Opt_189 zT_259 = {0};
    unsigned int zT_260;
    unsigned int zT_261;
    int zT_262;
    zT_6B0A7D14_AstStore* zT_264;
    unsigned int zT_265;
    zT_6B0A7D14_AstStore* zT_266;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_267 = {0};
    unsigned int zT_269;
    unsigned int zT_270;
    int zT_271;
    zT_DA663F79_ComptimeEval* zT_273;
    unsigned int zT_274;
    unsigned int* zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    zT_BAEE192E_Opt_10 zT_278 = {0};
    unsigned char zT_279;
    zT_338B7C76_TypeRegistry* zT_282;
    zT_D155D06D_Type* zT_283;
    unsigned int zT_284;
    zT_D155D06D_Type zT_285;
    unsigned char zT_286;
    unsigned char zT_287;
    int zT_288;
    unsigned int zT_290;
    zT_79FAE712_u64 zT_291;
    zT_79FAE712_u64 zT_292;
    zT_79FAE712_u64 zT_293;
    zT_33EF6BFB_TypeKind zT_294;
    zT_33EF6BFB_TypeKind zT_297;
    int zT_298;
    int zT_299;
    unsigned char zT_300;
    unsigned char zT_301;
    unsigned char zT_302;
    unsigned char zT_303;
    int zT_304;
    zT_338B7C76_TypeRegistry* zT_305;
    unsigned int zT_306;
    zT_338B7C76_TypeRegistry* zT_307;
    unsigned int zT_308 = 0;
    zT_79FAE712_u64 zT_309;
    zT_33EF6BFB_TypeKind zT_310;
    zT_33EF6BFB_TypeKind zT_313;
    int zT_314;
    zT_338B7C76_TypeRegistry* zT_315;
    unsigned int zT_316;
    zT_338B7C76_TypeRegistry* zT_317;
    unsigned int zT_318 = 0;
    zT_79FAE712_u64 zT_319;
    zT_338B7C76_TypeRegistry* zT_320;
    unsigned int zT_321;
    zT_338B7C76_TypeRegistry* zT_322;
    int zT_323 = 0;
    zT_338B7C76_TypeRegistry* zT_324;
    unsigned int zT_325;
    zT_338B7C76_TypeRegistry* zT_326;
    unsigned char zT_327 = 0;
    zT_79FAE712_u64 zT_328;
    zT_33EF6BFB_TypeKind zT_329;
    zT_33EF6BFB_TypeKind zT_332;
    int zT_333;
    zT_79FAE712_u64 zT_334;
    zT_89B1DDDA_ComptimeVal zT_335;
    unsigned int zT_336;
    int zT_337;
    zT_5BBDF77D_Opt_189 zT_338;
    zT_5BBDF77D_Opt_189 zT_339 = {0};
    unsigned int zT_340;
    unsigned int zT_341;
    int zT_342;
    zT_6B0A7D14_AstStore* zT_344;
    unsigned int zT_345;
    zT_6B0A7D14_AstStore* zT_346;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_347 = {0};
    zT_DA663F79_ComptimeEval* zT_349;
    unsigned int zT_350;
    unsigned int* zT_351;
    unsigned int zT_352;
    unsigned int zT_353;
    zT_BAEE192E_Opt_10 zT_354 = {0};
    zT_DA663F79_ComptimeEval* zT_356;
    unsigned int zT_357;
    unsigned int zT_358;
    unsigned int* zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    zT_5BBDF77D_Opt_189 zT_362 = {0};
    unsigned char zT_363;
    unsigned char zT_365;
    zT_338B7C76_TypeRegistry* zT_368;
    zT_D155D06D_Type* zT_369;
    unsigned int zT_370;
    zT_D155D06D_Type zT_371;
    zT_338B7C76_TypeRegistry* zT_373;
    unsigned int zT_374;
    zT_338B7C76_TypeRegistry* zT_375;
    int zT_376 = 0;
    zT_338B7C76_TypeRegistry* zT_378;
    unsigned int zT_379;
    zT_338B7C76_TypeRegistry* zT_380;
    unsigned char zT_381 = 0;
    unsigned int zT_382;
    zT_338B7C76_TypeRegistry* zT_384;
    unsigned int zT_385;
    zT_338B7C76_TypeRegistry* zT_386;
    int zT_387 = 0;
    int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    int zT_393;
    unsigned int zT_394;
    int zT_395;
    zT_89B1DDDA_ComptimeVal zT_396;
    zT_79FAE712_u64 zT_397;
    zT_5BBDF77D_Opt_189 zT_398;
    zT_79FAE712_u64 zT_400;
    zT_79FAE712_u64 zT_401;
    zT_79FAE712_u64 zT_402;
    zT_79FAE712_u64 zT_403;
    zT_79FAE712_u64 zT_404;
    zT_79FAE712_u64 zT_406;
    zT_79FAE712_u64 zT_407;
    int zT_408;
    zT_79FAE712_u64 zT_409;
    zT_79FAE712_u64 zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    zT_79FAE712_u64 zT_413;
    zT_79FAE712_u64 zT_414;
    zT_79FAE712_u64 zT_415;
    zT_79FAE712_u64 zT_416;
    int zT_417;
    zT_79FAE712_u64 zT_419;
    zT_79FAE712_u64 zT_420;
    zT_79FAE712_u64 zT_421;
    zT_79FAE712_u64 zT_422;
    zT_79FAE712_u64 zT_423;
    zT_79FAE712_u64 zT_424;
    zT_89B1DDDA_ComptimeVal zT_425;
    zT_5BBDF77D_Opt_189 zT_426;
    zT_5BBDF77D_Opt_189 zT_427 = {0};
    unsigned int zT_428;
    unsigned int zT_429;
    int zT_430;
    zT_79FAE712_u64 zT_432;
    int zT_433;
    zT_79FAE712_u64 zT_434;
    zT_89B1DDDA_ComptimeVal zT_435;
    unsigned int zT_436;
    int zT_437;
    zT_5BBDF77D_Opt_189 zT_438;
    zT_5BBDF77D_Opt_189 zT_439 = {0};
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    zT_D155D06D_Type ty;
    zT_3CB0179A_Slice_zT_05F374B1_u ec2;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    int has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    zT_BF2E90D8_Slice_zT_2DF01B61_F u_fields;
    zT_22A7C88B_AstNode fname_node2;
    unsigned int sv_idx2;
    unsigned int want_id2;
    unsigned int fi2;
    zT_79FAE712_u64 ubo;
    zT_3CB0179A_Slice_zT_05F374B1_u ec3;
    zT_BAEE192E_Opt_10 tid2;
    unsigned int t2;
    zT_D155D06D_Type ty2;
    zT_79FAE712_u64 bsz;
    zT_5BBDF77D_Opt_189 inner;
    zT_89B1DDDA_ComptimeVal cv;
    int is_int_t;
    unsigned int wb;
    int sig;
    zT_79FAE712_u64 mask;
    zT_79FAE712_u64 masked;
    zT_79FAE712_u64 not_mask;
    zT_79FAE712_u64 wb2;
    zT_6 = self->store;
    zT_4 = zT_6;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    node = zT_7;
    node = zT_7;
    zT_8 = node.child_0;
    zT_9 = self->size_of_id;
    zT_10 = zT_8 == zT_9;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self->store;
    zT_12 = zT_14;
    zT_13 = node_idx;
    zT_15 = zF_850FDF81_astStoreNodeExtraCh(zT_12, zT_13);
    ec = zT_15;
    ec = zT_15;
    ec = zT_15;
    zT_17 = self;
    zT_19 = ec.ptr;
    zT_20 = 0;
    zT_21 = zT_19[zT_20];
    zT_18 = zT_21;
    zT_22 = zF_BAD6BA5D_comptimeEvalResolve(zT_17, zT_18);
    tid = zT_22;
    tid = zT_22;
    tid = zT_22;
    zT_23 = tid.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_40 = node.child_0;
    zT_41 = self->align_of_id;
    zT_42 = zT_40 == zT_41;
    if (zT_42) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    t = tid.value;
    zT_26 = self->registry;
    zT_27 = zT_26->types_items;
    zT_28 = (unsigned int)t;
    zT_29 = zT_27[zT_28];
    ty = zT_29;
    ty = zT_29;
    ty = zT_29;
    zT_30 = ty.state;
    zT_31 = 2;
    zT_32 = zT_30 == zT_31;
    if (zT_32) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_39.has_value = 0;
    return zT_39;
    z_bb_5:
    zT_34 = ty.size;
    zT_35 = (zT_79FAE712_u64)zT_34;
    zT_33.bits = zT_35;
    zT_36 = 0;
    zT_33.width_bits = zT_36;
    zT_37 = 0;
    zT_33.sig = zT_37;
    zT_38.has_value = 1;
    zT_38.value = zT_33;
    return zT_38;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_46 = self->store;
    zT_44 = zT_46;
    zT_45 = node_idx;
    zT_47 = zF_850FDF81_astStoreNodeExtraCh(zT_44, zT_45);
    ec = zT_47;
    ec = zT_47;
    ec = zT_47;
    zT_49 = self;
    zT_51 = ec.ptr;
    zT_52 = 0;
    zT_53 = zT_51[zT_52];
    zT_50 = zT_53;
    zT_54 = zF_BAD6BA5D_comptimeEvalResolve(zT_49, zT_50);
    tid = zT_54;
    tid = zT_54;
    tid = zT_54;
    zT_55 = tid.has_value;
    if (zT_55) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_72 = node.child_0;
    zT_73 = self->offset_of_id;
    zT_74 = zT_72 == zT_73;
    if (zT_74) goto z_bb_14; else goto z_bb_13;
    z_bb_9:
    t = tid.value;
    zT_58 = self->registry;
    zT_59 = zT_58->types_items;
    zT_60 = (unsigned int)t;
    zT_61 = zT_59[zT_60];
    ty = zT_61;
    ty = zT_61;
    ty = zT_61;
    zT_62 = ty.state;
    zT_63 = 2;
    zT_64 = zT_62 == zT_63;
    if (zT_64) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_71.has_value = 0;
    return zT_71;
    z_bb_11:
    zT_66 = ty.alignment;
    zT_67 = (zT_79FAE712_u64)zT_66;
    zT_65.bits = zT_67;
    zT_68 = 0;
    zT_65.width_bits = zT_68;
    zT_69 = 0;
    zT_65.sig = zT_69;
    zT_70.has_value = 1;
    zT_70.value = zT_65;
    return zT_70;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_76 = node.child_0;
    zT_77 = self->bit_offset_of_id;
    zT_78 = zT_76 == zT_77;
    zT_75 = zT_78;
    goto z_bb_15;
    z_bb_14:
    zT_75 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_75) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_82 = self->store;
    zT_80 = zT_82;
    zT_81 = node_idx;
    zT_83 = zF_850FDF81_astStoreNodeExtraCh(zT_80, zT_81);
    ec2 = zT_83;
    ec2 = zT_83;
    ec2 = zT_83;
    zT_85 = ec2.len;
    zT_86 = 2;
    zT_87 = zT_85 >= zT_86;
    if (zT_87) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_260 = node.child_0;
    zT_261 = self->bit_size_of_id;
    zT_262 = zT_260 == zT_261;
    if (zT_262) goto z_bb_61; else goto z_bb_62;
    z_bb_18:
    zT_89 = self;
    zT_91 = ec2.ptr;
    zT_92 = 0;
    zT_93 = zT_91[zT_92];
    zT_90 = zT_93;
    zT_94 = zF_BAD6BA5D_comptimeEvalResolve(zT_89, zT_90);
    tid = zT_94;
    tid = zT_94;
    tid = zT_94;
    zT_95 = tid.has_value;
    if (zT_95) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_259.has_value = 0;
    return zT_259;
    z_bb_20:
    t = tid.value;
    zT_98 = self->registry;
    zT_99 = zT_98->types_items;
    zT_100 = (unsigned int)t;
    zT_101 = zT_99[zT_100];
    ty = zT_101;
    ty = zT_101;
    ty = zT_101;
    zT_102 = ty.state;
    zT_103 = 2;
    zT_104 = zT_102 == zT_103;
    if (zT_104) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_106 = ty.kind;
    zT_109 = zT_33EF6BFB_TypeKind_struct_type;
    zT_110 = zT_106 == zT_109;
    zT_105 = zT_110;
    goto z_bb_24;
    z_bb_23:
    zT_105 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_105) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    fields = zT_112;
    zT_116 = self->registry;
    zT_113 = zT_116;
    zT_114 = t;
    zT_117 = &fields;
    zT_115 = zT_117;
    zF_5A40A2EE_typeRegistryGetStru(zT_113, zT_114, zT_115);
    packed_fields = zT_119;
    zT_124 = self->registry;
    zT_121 = zT_124;
    zT_122 = t;
    zT_125 = &packed_fields;
    zT_123 = zT_125;
    zT_126 = zF_7D87247C_typeRegistryGetPack(zT_121, zT_122, zT_123);
    has_pk = zT_126;
    has_pk = zT_126;
    has_pk = zT_126;
    zT_130 = self->store;
    zT_128 = zT_130;
    zT_131 = ec2.ptr;
    zT_132 = 1;
    zT_133 = zT_131[zT_132];
    zT_129 = zT_133;
    zT_134 = zF_FCDD1D35_astStoreNodeAt(zT_128, zT_129);
    fname_node = zT_134;
    fname_node = zT_134;
    fname_node = zT_134;
    zT_135 = fname_node.kind;
    zT_138 = zT_8143F551_AstKind_string_literal;
    zT_139 = zT_135 == zT_138;
    if (zT_139) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_194 = ty.state;
    zT_195 = 2;
    zT_196 = zT_194 == zT_195;
    if (zT_196) goto z_bb_46; else goto z_bb_47;
    z_bb_28:
    zT_143 = self->store;
    zT_141 = zT_143;
    zT_144 = ec2.ptr;
    zT_145 = 1;
    zT_146 = zT_144[zT_145];
    zT_142 = zT_146;
    zT_147 = zF_8BA26B9E_astStoreNodePayload(zT_141, zT_142);
    sv_idx = zT_147;
    sv_idx = zT_147;
    sv_idx = zT_147;
    zT_149 = self->store;
    zT_150 = zT_149->string_values;
    zT_151 = zT_150.items;
    zT_152 = (unsigned int)sv_idx;
    zT_153 = zT_151[zT_152];
    want_id = zT_153;
    want_id = zT_153;
    want_id = zT_153;
    zT_155 = 0;
    zT_156 = (unsigned int)zT_155;
    fi = zT_156;
    fi = zT_156;
    fi = zT_156;
    goto z_bb_30;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    zT_158 = fields.len;
    zT_159 = fi < zT_158;
    if (zT_159) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_160 = fields.ptr;
    zT_161 = zT_160[fi];
    zT_162 = zT_161.name_id;
    zT_163 = zT_162 == want_id;
    if (zT_163) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_192 = 1;
    zT_193 = fi + zT_192;
    fi = zT_193;
    fi = zT_193;
    goto z_bb_30;
    z_bb_34:
    zT_165 = fields.ptr;
    zT_166 = zT_165[fi];
    zT_167 = zT_166.offset;
    zT_168 = (zT_79FAE712_u64)zT_167;
    bo = zT_168;
    bo = zT_168;
    bo = zT_168;
    if (has_pk) goto z_bb_36; else goto z_bb_38;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    zT_170 = 0;
    pk_bo = zT_170;
    pk_bo = zT_170;
    pk_bo = zT_170;
    zT_172 = packed_fields.len;
    zT_173 = fi < zT_172;
    if (zT_173) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    zT_188.bits = bo;
    zT_189 = 0;
    zT_188.width_bits = zT_189;
    zT_190 = 0;
    zT_188.sig = zT_190;
    zT_191.has_value = 1;
    zT_191.value = zT_188;
    return zT_191;
    z_bb_38:
    zT_183 = node.child_0;
    zT_184 = self->bit_offset_of_id;
    zT_185 = zT_183 == zT_184;
    if (zT_185) goto z_bb_44; else goto z_bb_45;
    z_bb_39:
    zT_174 = packed_fields.ptr;
    zT_175 = zT_174[fi];
    zT_176 = zT_175.bit_offset;
    zT_177 = (zT_79FAE712_u64)zT_176;
    pk_bo = zT_177;
    pk_bo = zT_177;
    goto z_bb_40;
    z_bb_40:
    zT_178 = node.child_0;
    zT_179 = self->bit_offset_of_id;
    zT_180 = zT_178 == zT_179;
    if (zT_180) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    bo = pk_bo;
    bo = pk_bo;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_37;
    z_bb_43:
    zT_181 = 8;
    zT_182 = pk_bo / zT_181;
    bo = zT_182;
    bo = zT_182;
    goto z_bb_42;
    z_bb_44:
    zT_186 = 8;
    zT_187 = bo * zT_186;
    bo = zT_187;
    bo = zT_187;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_37;
    z_bb_46:
    zT_198 = ty.kind;
    zT_201 = zT_33EF6BFB_TypeKind_packed_union_type;
    zT_202 = zT_198 == zT_201;
    zT_197 = zT_202;
    goto z_bb_48;
    z_bb_47:
    zT_197 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_197) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    u_fields = zT_204;
    zT_208 = self->registry;
    zT_205 = zT_208;
    zT_206 = t;
    zT_209 = &u_fields;
    zT_207 = zT_209;
    zF_15BD2D98_typeRegistryGetUnio(zT_205, zT_206, zT_207);
    zT_213 = self->store;
    zT_211 = zT_213;
    zT_214 = ec2.ptr;
    zT_215 = 1;
    zT_216 = zT_214[zT_215];
    zT_212 = zT_216;
    zT_217 = zF_FCDD1D35_astStoreNodeAt(zT_211, zT_212);
    fname_node2 = zT_217;
    fname_node2 = zT_217;
    fname_node2 = zT_217;
    zT_218 = fname_node2.kind;
    zT_221 = zT_8143F551_AstKind_string_literal;
    zT_222 = zT_218 == zT_221;
    if (zT_222) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_26;
    z_bb_51:
    zT_226 = self->store;
    zT_224 = zT_226;
    zT_227 = ec2.ptr;
    zT_228 = 1;
    zT_229 = zT_227[zT_228];
    zT_225 = zT_229;
    zT_230 = zF_8BA26B9E_astStoreNodePayload(zT_224, zT_225);
    sv_idx2 = zT_230;
    sv_idx2 = zT_230;
    sv_idx2 = zT_230;
    zT_232 = self->store;
    zT_233 = zT_232->string_values;
    zT_234 = zT_233.items;
    zT_235 = (unsigned int)sv_idx2;
    zT_236 = zT_234[zT_235];
    want_id2 = zT_236;
    want_id2 = zT_236;
    want_id2 = zT_236;
    zT_238 = 0;
    zT_239 = (unsigned int)zT_238;
    fi2 = zT_239;
    fi2 = zT_239;
    fi2 = zT_239;
    goto z_bb_53;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    zT_241 = u_fields.len;
    zT_242 = fi2 < zT_241;
    if (zT_242) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_243 = u_fields.ptr;
    zT_244 = zT_243[fi2];
    zT_245 = zT_244.name_id;
    zT_246 = zT_245 == want_id2;
    if (zT_246) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_257 = 1;
    zT_258 = fi2 + zT_257;
    fi2 = zT_258;
    fi2 = zT_258;
    goto z_bb_53;
    z_bb_57:
    zT_248 = 0;
    ubo = zT_248;
    ubo = zT_248;
    ubo = zT_248;
    zT_249 = node.child_0;
    zT_250 = self->offset_of_id;
    zT_251 = zT_249 == zT_250;
    if (zT_251) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    zT_252 = 0;
    ubo = zT_252;
    ubo = zT_252;
    goto z_bb_60;
    z_bb_60:
    zT_253.bits = ubo;
    zT_254 = 0;
    zT_253.width_bits = zT_254;
    zT_255 = 0;
    zT_253.sig = zT_255;
    zT_256.has_value = 1;
    zT_256.value = zT_253;
    return zT_256;
    z_bb_61:
    zT_266 = self->store;
    zT_264 = zT_266;
    zT_265 = node_idx;
    zT_267 = zF_850FDF81_astStoreNodeExtraCh(zT_264, zT_265);
    ec3 = zT_267;
    ec3 = zT_267;
    ec3 = zT_267;
    zT_269 = ec3.len;
    zT_270 = 1;
    zT_271 = zT_269 >= zT_270;
    if (zT_271) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_340 = node.child_0;
    zT_341 = self->int_cast_id;
    zT_342 = zT_340 == zT_341;
    if (zT_342) goto z_bb_80; else goto z_bb_81;
    z_bb_63:
    zT_273 = self;
    zT_275 = ec3.ptr;
    zT_276 = 0;
    zT_277 = zT_275[zT_276];
    zT_274 = zT_277;
    zT_278 = zF_BAD6BA5D_comptimeEvalResolve(zT_273, zT_274);
    tid2 = zT_278;
    tid2 = zT_278;
    tid2 = zT_278;
    zT_279 = tid2.has_value;
    if (zT_279) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_339.has_value = 0;
    return zT_339;
    z_bb_65:
    t2 = tid2.value;
    zT_282 = self->registry;
    zT_283 = zT_282->types_items;
    zT_284 = (unsigned int)t2;
    zT_285 = zT_283[zT_284];
    ty2 = zT_285;
    ty2 = zT_285;
    ty2 = zT_285;
    zT_286 = ty2.state;
    zT_287 = 2;
    zT_288 = zT_286 == zT_287;
    if (zT_288) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_290 = ty2.size;
    zT_291 = (zT_79FAE712_u64)zT_290;
    zT_292 = 8;
    zT_293 = zT_291 * zT_292;
    bsz = zT_293;
    bsz = zT_293;
    bsz = zT_293;
    zT_294 = ty2.kind;
    zT_297 = zT_33EF6BFB_TypeKind_struct_type;
    zT_298 = zT_294 == zT_297;
    if (zT_298) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    goto z_bb_66;
    z_bb_69:
    zT_300 = ty2.flags;
    zT_301 = 16;
    zT_302 = zT_300 & zT_301;
    zT_303 = 0;
    zT_304 = zT_302 != zT_303;
    zT_299 = zT_304;
    goto z_bb_71;
    z_bb_70:
    zT_299 = 0;
    goto z_bb_71;
    z_bb_71:
    if (zT_299) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_307 = self->registry;
    zT_305 = zT_307;
    zT_306 = t2;
    zT_308 = zF_CB27DBA4_typeRegistryGetPack(zT_305, zT_306);
    zT_309 = (zT_79FAE712_u64)zT_308;
    bsz = zT_309;
    bsz = zT_309;
    goto z_bb_73;
    z_bb_73:
    zT_310 = ty2.kind;
    zT_313 = zT_33EF6BFB_TypeKind_packed_union_type;
    zT_314 = zT_310 == zT_313;
    if (zT_314) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_317 = self->registry;
    zT_315 = zT_317;
    zT_316 = t2;
    zT_318 = zF_B80C4365_typeRegistryGetPack(zT_315, zT_316);
    zT_319 = (zT_79FAE712_u64)zT_318;
    bsz = zT_319;
    bsz = zT_319;
    goto z_bb_75;
    z_bb_75:
    zT_322 = self->registry;
    zT_320 = zT_322;
    zT_321 = t2;
    zT_323 = zF_3290E9C4_typeRegistryIsInteg(zT_320, zT_321);
    if (zT_323) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_326 = self->registry;
    zT_324 = zT_326;
    zT_325 = t2;
    zT_327 = zF_655972D5_typeRegistryIntWidt(zT_324, zT_325);
    zT_328 = (zT_79FAE712_u64)zT_327;
    bsz = zT_328;
    bsz = zT_328;
    goto z_bb_77;
    z_bb_77:
    zT_329 = ty2.kind;
    zT_332 = zT_33EF6BFB_TypeKind_bool_type;
    zT_333 = zT_329 == zT_332;
    if (zT_333) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_334 = 1;
    bsz = zT_334;
    bsz = zT_334;
    goto z_bb_79;
    z_bb_79:
    zT_335.bits = bsz;
    zT_336 = 0;
    zT_335.width_bits = zT_336;
    zT_337 = 0;
    zT_335.sig = zT_337;
    zT_338.has_value = 1;
    zT_338.value = zT_335;
    return zT_338;
    z_bb_80:
    zT_346 = self->store;
    zT_344 = zT_346;
    zT_345 = node_idx;
    zT_347 = zF_850FDF81_astStoreNodeExtraCh(zT_344, zT_345);
    ec = zT_347;
    ec = zT_347;
    ec = zT_347;
    zT_349 = self;
    zT_351 = ec.ptr;
    zT_352 = 0;
    zT_353 = zT_351[zT_352];
    zT_350 = zT_353;
    zT_354 = zF_BAD6BA5D_comptimeEvalResolve(zT_349, zT_350);
    tid = zT_354;
    tid = zT_354;
    tid = zT_354;
    zT_356 = self;
    zT_359 = ec.ptr;
    zT_360 = 1;
    zT_361 = zT_359[zT_360];
    zT_357 = zT_361;
    zT_358 = depth;
    zT_362 = zF_4EE17137_comptimeEvalEvaluat(zT_356, zT_357, zT_358);
    inner = zT_362;
    inner = zT_362;
    inner = zT_362;
    zT_363 = tid.has_value;
    if (zT_363) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    zT_428 = node.child_0;
    zT_429 = self->is_windows_id;
    zT_430 = zT_428 == zT_429;
    if (zT_430) goto z_bb_95; else goto z_bb_96;
    z_bb_82:
    t = tid.value;
    zT_365 = inner.has_value;
    if (zT_365) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    zT_427.has_value = 0;
    return zT_427;
    z_bb_84:
    cv = inner.value;
    zT_368 = self->registry;
    zT_369 = zT_368->types_items;
    zT_370 = (unsigned int)t;
    zT_371 = zT_369[zT_370];
    ty = zT_371;
    ty = zT_371;
    ty = zT_371;
    zT_375 = self->registry;
    zT_373 = zT_375;
    zT_374 = t;
    zT_376 = zF_3290E9C4_typeRegistryIsInteg(zT_373, zT_374);
    is_int_t = zT_376;
    is_int_t = zT_376;
    is_int_t = zT_376;
    zT_380 = self->registry;
    zT_378 = zT_380;
    zT_379 = t;
    zT_381 = zF_655972D5_typeRegistryIntWidt(zT_378, zT_379);
    zT_382 = (unsigned int)zT_381;
    wb = zT_382;
    wb = zT_382;
    wb = zT_382;
    zT_386 = self->registry;
    zT_384 = zT_386;
    zT_385 = t;
    zT_387 = zF_01ED6537_typeRegistryIntIsSi(zT_384, zT_385);
    sig = zT_387;
    sig = zT_387;
    sig = zT_387;
    zT_388 = !is_int_t;
    if (zT_388) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    goto z_bb_83;
    z_bb_86:
    zT_389 = ty.size;
    zT_390 = 8;
    zT_391 = zT_389 * zT_390;
    zT_392 = (unsigned int)zT_391;
    wb = zT_392;
    wb = zT_392;
    zT_393 = 0;
    sig = zT_393;
    sig = zT_393;
    goto z_bb_87;
    z_bb_87:
    zT_394 = 64;
    zT_395 = wb >= zT_394;
    if (zT_395) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_397 = cv.bits;
    zT_396.bits = zT_397;
    zT_396.width_bits = wb;
    zT_396.sig = sig;
    zT_398.has_value = 1;
    zT_398.value = zT_396;
    return zT_398;
    z_bb_89:
    zT_400 = 1;
    zT_401 = (zT_79FAE712_u64)wb;
    zT_402 = zT_400 << zT_401;
    zT_403 = 1;
    zT_404 = zT_402 - zT_403;
    mask = zT_404;
    mask = zT_404;
    mask = zT_404;
    zT_406 = cv.bits;
    zT_407 = zT_406 & mask;
    masked = zT_407;
    masked = zT_407;
    masked = zT_407;
    if (sig) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_409 = cv.bits;
    zT_410 = 1;
    zT_411 = 1;
    zT_412 = wb - zT_411;
    zT_413 = (zT_79FAE712_u64)zT_412;
    zT_414 = zT_410 << zT_413;
    zT_415 = zT_409 & zT_414;
    zT_416 = 0;
    zT_417 = zT_415 != zT_416;
    zT_408 = zT_417;
    goto z_bb_92;
    z_bb_91:
    zT_408 = 0;
    goto z_bb_92;
    z_bb_92:
    if (zT_408) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_419 = 0;
    zT_420 = zT_419 - mask;
    zT_421 = 1;
    zT_422 = zT_420 - zT_421;
    not_mask = zT_422;
    not_mask = zT_422;
    not_mask = zT_422;
    zT_423 = cv.bits;
    zT_424 = zT_423 | not_mask;
    masked = zT_424;
    masked = zT_424;
    goto z_bb_94;
    z_bb_94:
    zT_425.bits = masked;
    zT_425.width_bits = wb;
    zT_425.sig = sig;
    zT_426.has_value = 1;
    zT_426.value = zT_425;
    return zT_426;
    z_bb_95:
    zT_432 = 0;
    wb2 = zT_432;
    wb2 = zT_432;
    wb2 = zT_432;
    zT_433 = self->host_is_windows;
    if (zT_433) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    zT_439.has_value = 0;
    return zT_439;
    z_bb_97:
    zT_434 = 1;
    wb2 = zT_434;
    wb2 = zT_434;
    goto z_bb_98;
    z_bb_98:
    zT_435.bits = wb2;
    zT_436 = 1;
    zT_435.width_bits = zT_436;
    zT_437 = 0;
    zT_435.sig = zT_437;
    zT_438.has_value = 1;
    zT_438.value = zT_435;
    return zT_438;
}

/* comptimeEvalEvaluate */
zT_5BBDF77D_Opt_189 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_5BBDF77D_Opt_189 zT_6 = {0};
    zT_2 = self;
    zT_3 = node_idx;
    zT_5 = 0;
    zT_4 = zT_5;
    zT_6 = zF_4EE17137_comptimeEvalEvaluat(zT_2, zT_3, zT_4);
    return zT_6;
}

/* comptimeEvalEvaluateDepth */
zT_5BBDF77D_Opt_189 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    unsigned int zT_3;
    int zT_4;
    zT_5BBDF77D_Opt_189 zT_5 = {0};
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_8143F551_AstKind zT_14;
    int zT_15;
    zT_89B1DDDA_ComptimeVal zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    zT_79FAE712_u64 zT_20 = 0;
    unsigned int zT_21;
    int zT_22;
    zT_5BBDF77D_Opt_189 zT_23;
    zT_8143F551_AstKind zT_24;
    zT_8143F551_AstKind zT_27;
    int zT_28;
    zT_89B1DDDA_ComptimeVal zT_29;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_32;
    zT_79FAE712_u64 zT_33 = 0;
    unsigned int zT_34;
    int zT_35;
    zT_5BBDF77D_Opt_189 zT_36;
    zT_8143F551_AstKind zT_37;
    zT_8143F551_AstKind zT_40;
    int zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    int zT_46;
    zT_89B1DDDA_ComptimeVal zT_47;
    zT_79FAE712_u64 zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_5BBDF77D_Opt_189 zT_51;
    zT_89B1DDDA_ComptimeVal zT_52;
    zT_79FAE712_u64 zT_53;
    unsigned int zT_54;
    int zT_55;
    zT_5BBDF77D_Opt_189 zT_56;
    zT_8143F551_AstKind zT_57;
    zT_8143F551_AstKind zT_60;
    int zT_61;
    zT_DA663F79_ComptimeEval* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_5BBDF77D_Opt_189 zT_67 = {0};
    unsigned char zT_68;
    zT_79FAE712_u64 zT_71;
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    int zT_76;
    unsigned int zT_78;
    unsigned int zT_79;
    int zT_80;
    zT_89B1DDDA_ComptimeVal zT_81;
    int zT_82;
    zT_5BBDF77D_Opt_189 zT_83;
    zT_79FAE712_u64 zT_85;
    zT_79FAE712_u64 zT_86;
    zT_79FAE712_u64 zT_87;
    zT_79FAE712_u64 zT_88;
    zT_79FAE712_u64 zT_89;
    zT_79FAE712_u64 zT_91;
    int zT_92;
    int zT_93;
    zT_79FAE712_u64 zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_79FAE712_u64 zT_97;
    zT_79FAE712_u64 zT_98;
    zT_79FAE712_u64 zT_99;
    zT_79FAE712_u64 zT_100;
    int zT_101;
    zT_79FAE712_u64 zT_103;
    zT_79FAE712_u64 zT_104;
    zT_79FAE712_u64 zT_105;
    zT_79FAE712_u64 zT_106;
    zT_79FAE712_u64 zT_107;
    zT_89B1DDDA_ComptimeVal zT_108;
    int zT_109;
    zT_5BBDF77D_Opt_189 zT_110;
    zT_89B1DDDA_ComptimeVal zT_111;
    unsigned int zT_112;
    int zT_113;
    zT_5BBDF77D_Opt_189 zT_114;
    zT_5BBDF77D_Opt_189 zT_115 = {0};
    zT_8143F551_AstKind zT_116;
    zT_8143F551_AstKind zT_119;
    int zT_120;
    zT_DA663F79_ComptimeEval* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_5BBDF77D_Opt_189 zT_126 = {0};
    unsigned char zT_127;
    zT_79FAE712_u64 zT_130;
    zT_79FAE712_u64 zT_131;
    zT_89B1DDDA_ComptimeVal zT_132;
    unsigned int zT_133;
    int zT_134;
    zT_5BBDF77D_Opt_189 zT_135;
    zT_5BBDF77D_Opt_189 zT_136 = {0};
    zT_8143F551_AstKind zT_137;
    zT_8143F551_AstKind zT_140;
    int zT_141;
    int zT_142;
    zT_8143F551_AstKind zT_143;
    zT_8143F551_AstKind zT_146;
    int zT_147;
    int zT_148;
    zT_8143F551_AstKind zT_149;
    zT_8143F551_AstKind zT_152;
    int zT_153;
    int zT_154;
    zT_8143F551_AstKind zT_155;
    zT_8143F551_AstKind zT_158;
    int zT_159;
    int zT_160;
    zT_8143F551_AstKind zT_161;
    zT_8143F551_AstKind zT_164;
    int zT_165;
    int zT_166;
    zT_8143F551_AstKind zT_167;
    zT_8143F551_AstKind zT_170;
    int zT_171;
    int zT_172;
    zT_8143F551_AstKind zT_173;
    zT_8143F551_AstKind zT_176;
    int zT_177;
    int zT_178;
    zT_8143F551_AstKind zT_179;
    zT_8143F551_AstKind zT_182;
    int zT_183;
    int zT_184;
    zT_8143F551_AstKind zT_185;
    zT_8143F551_AstKind zT_188;
    int zT_189;
    int zT_190;
    zT_8143F551_AstKind zT_191;
    zT_8143F551_AstKind zT_194;
    int zT_195;
    zT_DA663F79_ComptimeEval* zT_196;
    unsigned int zT_197;
    zT_8143F551_AstKind zT_198;
    unsigned int zT_199;
    zT_8143F551_AstKind zT_200;
    zT_5BBDF77D_Opt_189 zT_201 = {0};
    zT_8143F551_AstKind zT_202;
    zT_8143F551_AstKind zT_205;
    int zT_206;
    zT_DA663F79_ComptimeEval* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    zT_5BBDF77D_Opt_189 zT_210 = {0};
    zT_8143F551_AstKind zT_211;
    zT_8143F551_AstKind zT_214;
    int zT_215;
    zT_DA663F79_ComptimeEval* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    zT_8143F551_AstKind zT_221;
    zT_8143F551_AstKind zT_224;
    int zT_225;
    unsigned int zT_226;
    int zT_227;
    zT_5BBDF77D_Opt_189 zT_228 = {0};
    zT_6B0A7D14_AstStore* zT_230;
    unsigned int zT_231;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233 = 0;
    int zT_235;
    unsigned int zT_236;
    zT_3D7259E2_SymbolRegistry* zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    int zT_240;
    zT_3D7259E2_SymbolRegistry* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    zT_3D7259E2_SymbolRegistry* zT_245;
    unsigned int zT_246;
    zT_E68301A1_Opt_804 zT_247 = {0};
    unsigned char zT_248;
    unsigned short zT_250;
    unsigned short zT_251;
    unsigned short zT_252;
    unsigned short zT_253;
    int zT_254;
    zT_6B0A7D14_AstStore* zT_256;
    unsigned int zT_257;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    zT_22A7C88B_AstNode zT_260 = {0};
    unsigned int zT_261;
    unsigned int zT_262;
    int zT_263;
    zT_DA663F79_ComptimeEval* zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    int zT_271;
    unsigned int zT_272;
    zT_5BBDF77D_Opt_189 zT_273 = {0};
    zT_5BBDF77D_Opt_189 zT_274 = {0};
    zT_22A7C88B_AstNode node;
    zT_5BBDF77D_Opt_189 inner;
    zT_89B1DDDA_ComptimeVal cv;
    zT_79FAE712_u64 nv;
    unsigned int wb;
    zT_79FAE712_u64 mask;
    zT_79FAE712_u64 masked;
    zT_79FAE712_u64 not_mask;
    zT_5BBDF77D_Opt_189 bnv;
    zT_89B1DDDA_ComptimeVal bv;
    zT_79FAE712_u64 bnb;
    unsigned int name_id;
    unsigned int mi;
    zT_E68301A1_Opt_804 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    zT_3 = 0;
    zT_4 = node_idx == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_9 = self->store;
    zT_7 = zT_9;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    node = zT_10;
    node = zT_10;
    zT_11 = node.kind;
    zT_14 = zT_8143F551_AstKind_int_literal;
    zT_15 = zT_11 == zT_14;
    if (zT_15) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_19 = self->store;
    zT_17 = zT_19;
    zT_18 = node_idx;
    zT_20 = zF_678B9A72_astStoreIntValue(zT_17, zT_18);
    zT_16.bits = zT_20;
    zT_21 = 0;
    zT_16.width_bits = zT_21;
    zT_22 = 1;
    zT_16.sig = zT_22;
    zT_23.has_value = 1;
    zT_23.value = zT_16;
    return zT_23;
    z_bb_4:
    { zT_5BBDF77D_Opt_189 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_5:
    zT_24 = node.kind;
    zT_27 = zT_8143F551_AstKind_char_literal;
    zT_28 = zT_24 == zT_27;
    if (zT_28) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_32 = self->store;
    zT_30 = zT_32;
    zT_31 = node_idx;
    zT_33 = zF_678B9A72_astStoreIntValue(zT_30, zT_31);
    zT_29.bits = zT_33;
    zT_34 = 8;
    zT_29.width_bits = zT_34;
    zT_35 = 0;
    zT_29.sig = zT_35;
    zT_36.has_value = 1;
    zT_36.value = zT_29;
    return zT_36;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = node.kind;
    zT_40 = zT_8143F551_AstKind_bool_literal;
    zT_41 = zT_37 == zT_40;
    if (zT_41) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_42 = node.flags;
    zT_43 = 1;
    zT_44 = zT_42 & zT_43;
    zT_45 = 0;
    zT_46 = zT_44 != zT_45;
    if (zT_46) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_57 = node.kind;
    zT_60 = zT_8143F551_AstKind_negate;
    zT_61 = zT_57 == zT_60;
    if (zT_61) goto z_bb_14; else goto z_bb_16;
    z_bb_12:
    zT_48 = 1;
    zT_47.bits = zT_48;
    zT_49 = 1;
    zT_47.width_bits = zT_49;
    zT_50 = 0;
    zT_47.sig = zT_50;
    zT_51.has_value = 1;
    zT_51.value = zT_47;
    return zT_51;
    z_bb_13:
    zT_53 = 0;
    zT_52.bits = zT_53;
    zT_54 = 1;
    zT_52.width_bits = zT_54;
    zT_55 = 0;
    zT_52.sig = zT_55;
    zT_56.has_value = 1;
    zT_56.value = zT_52;
    return zT_56;
    z_bb_14:
    zT_63 = self;
    zT_66 = node.child_0;
    zT_64 = zT_66;
    zT_65 = depth;
    zT_67 = zF_4EE17137_comptimeEvalEvaluat(zT_63, zT_64, zT_65);
    inner = zT_67;
    inner = zT_67;
    inner = zT_67;
    zT_68 = inner.has_value;
    if (zT_68) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_116 = node.kind;
    zT_119 = zT_8143F551_AstKind_bit_not;
    zT_120 = zT_116 == zT_119;
    if (zT_120) goto z_bb_28; else goto z_bb_30;
    z_bb_17:
    cv = inner.value;
    zT_71 = 0;
    zT_72 = cv.bits;
    zT_73 = zT_71 - zT_72;
    nv = zT_73;
    nv = zT_73;
    nv = zT_73;
    zT_74 = cv.width_bits;
    zT_75 = 0;
    zT_76 = zT_74 != zT_75;
    if (zT_76) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_115.has_value = 0;
    return zT_115;
    z_bb_19:
    zT_78 = cv.width_bits;
    wb = zT_78;
    wb = zT_78;
    wb = zT_78;
    zT_79 = 64;
    zT_80 = wb >= zT_79;
    if (zT_80) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_111.bits = nv;
    zT_112 = 0;
    zT_111.width_bits = zT_112;
    zT_113 = 1;
    zT_111.sig = zT_113;
    zT_114.has_value = 1;
    zT_114.value = zT_111;
    return zT_114;
    z_bb_21:
    zT_81.bits = nv;
    zT_81.width_bits = wb;
    zT_82 = cv.sig;
    zT_81.sig = zT_82;
    zT_83.has_value = 1;
    zT_83.value = zT_81;
    return zT_83;
    z_bb_22:
    zT_85 = 1;
    zT_86 = (zT_79FAE712_u64)wb;
    zT_87 = zT_85 << zT_86;
    zT_88 = 1;
    zT_89 = zT_87 - zT_88;
    mask = zT_89;
    mask = zT_89;
    mask = zT_89;
    zT_91 = nv & mask;
    masked = zT_91;
    masked = zT_91;
    masked = zT_91;
    zT_92 = cv.sig;
    if (zT_92) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_94 = 1;
    zT_95 = 1;
    zT_96 = wb - zT_95;
    zT_97 = (zT_79FAE712_u64)zT_96;
    zT_98 = zT_94 << zT_97;
    zT_99 = nv & zT_98;
    zT_100 = 0;
    zT_101 = zT_99 != zT_100;
    zT_93 = zT_101;
    goto z_bb_25;
    z_bb_24:
    zT_93 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_93) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_103 = 0;
    zT_104 = zT_103 - mask;
    zT_105 = 1;
    zT_106 = zT_104 - zT_105;
    not_mask = zT_106;
    not_mask = zT_106;
    not_mask = zT_106;
    zT_107 = nv | not_mask;
    masked = zT_107;
    masked = zT_107;
    goto z_bb_27;
    z_bb_27:
    zT_108.bits = masked;
    zT_108.width_bits = wb;
    zT_109 = cv.sig;
    zT_108.sig = zT_109;
    zT_110.has_value = 1;
    zT_110.value = zT_108;
    return zT_110;
    z_bb_28:
    zT_122 = self;
    zT_125 = node.child_0;
    zT_123 = zT_125;
    zT_124 = depth;
    zT_126 = zF_4EE17137_comptimeEvalEvaluat(zT_122, zT_123, zT_124);
    bnv = zT_126;
    bnv = zT_126;
    bnv = zT_126;
    zT_127 = bnv.has_value;
    if (zT_127) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    goto z_bb_15;
    z_bb_30:
    zT_137 = node.kind;
    zT_140 = zT_8143F551_AstKind_add;
    zT_141 = zT_137 == zT_140;
    if (zT_141) goto z_bb_34; else goto z_bb_33;
    z_bb_31:
    bv = bnv.value;
    zT_130 = bv.bits;
    zT_131 = ~zT_130;
    bnb = zT_131;
    bnb = zT_131;
    bnb = zT_131;
    zT_132.bits = bnb;
    zT_133 = bv.width_bits;
    zT_132.width_bits = zT_133;
    zT_134 = 0;
    zT_132.sig = zT_134;
    zT_135.has_value = 1;
    zT_135.value = zT_132;
    return zT_135;
    z_bb_32:
    zT_136.has_value = 0;
    return zT_136;
    z_bb_33:
    zT_143 = node.kind;
    zT_146 = zT_8143F551_AstKind_sub;
    zT_147 = zT_143 == zT_146;
    zT_142 = zT_147;
    goto z_bb_35;
    z_bb_34:
    zT_142 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_142) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_149 = node.kind;
    zT_152 = zT_8143F551_AstKind_mul;
    zT_153 = zT_149 == zT_152;
    zT_148 = zT_153;
    goto z_bb_38;
    z_bb_37:
    zT_148 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_148) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_155 = node.kind;
    zT_158 = zT_8143F551_AstKind_div;
    zT_159 = zT_155 == zT_158;
    zT_154 = zT_159;
    goto z_bb_41;
    z_bb_40:
    zT_154 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_154) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_161 = node.kind;
    zT_164 = zT_8143F551_AstKind_mod_op;
    zT_165 = zT_161 == zT_164;
    zT_160 = zT_165;
    goto z_bb_44;
    z_bb_43:
    zT_160 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_160) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_167 = node.kind;
    zT_170 = zT_8143F551_AstKind_bit_and;
    zT_171 = zT_167 == zT_170;
    zT_166 = zT_171;
    goto z_bb_47;
    z_bb_46:
    zT_166 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_166) goto z_bb_49; else goto z_bb_48;
    z_bb_48:
    zT_173 = node.kind;
    zT_176 = zT_8143F551_AstKind_bit_or;
    zT_177 = zT_173 == zT_176;
    zT_172 = zT_177;
    goto z_bb_50;
    z_bb_49:
    zT_172 = 1;
    goto z_bb_50;
    z_bb_50:
    if (zT_172) goto z_bb_52; else goto z_bb_51;
    z_bb_51:
    zT_179 = node.kind;
    zT_182 = zT_8143F551_AstKind_bit_xor;
    zT_183 = zT_179 == zT_182;
    zT_178 = zT_183;
    goto z_bb_53;
    z_bb_52:
    zT_178 = 1;
    goto z_bb_53;
    z_bb_53:
    if (zT_178) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_185 = node.kind;
    zT_188 = zT_8143F551_AstKind_shl;
    zT_189 = zT_185 == zT_188;
    zT_184 = zT_189;
    goto z_bb_56;
    z_bb_55:
    zT_184 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_184) goto z_bb_58; else goto z_bb_57;
    z_bb_57:
    zT_191 = node.kind;
    zT_194 = zT_8143F551_AstKind_shr;
    zT_195 = zT_191 == zT_194;
    zT_190 = zT_195;
    goto z_bb_59;
    z_bb_58:
    zT_190 = 1;
    goto z_bb_59;
    z_bb_59:
    if (zT_190) goto z_bb_60; else goto z_bb_62;
    z_bb_60:
    zT_196 = self;
    zT_197 = node_idx;
    zT_200 = node.kind;
    zT_198 = zT_200;
    zT_199 = depth;
    zT_201 = zF_B36A4A25_comptimeEvalBinOp(zT_196, zT_197, zT_198, zT_199);
    return zT_201;
    z_bb_61:
    goto z_bb_29;
    z_bb_62:
    zT_202 = node.kind;
    zT_205 = zT_8143F551_AstKind_builtin_call;
    zT_206 = zT_202 == zT_205;
    if (zT_206) goto z_bb_63; else goto z_bb_65;
    z_bb_63:
    zT_207 = self;
    zT_208 = node_idx;
    zT_209 = depth;
    zT_210 = zF_C37A1F7C_comptimeEvalBuiltin(zT_207, zT_208, zT_209);
    return zT_210;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_211 = node.kind;
    zT_214 = zT_8143F551_AstKind_paren_expr;
    zT_215 = zT_211 == zT_214;
    if (zT_215) goto z_bb_66; else goto z_bb_68;
    z_bb_66:
    zT_216 = self;
    zT_219 = node.child_0;
    zT_217 = zT_219;
    zT_218 = depth;
    self = zT_216;
    node_idx = zT_217;
    depth = zT_218;
    goto z_bb_0;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_221 = node.kind;
    zT_224 = zT_8143F551_AstKind_ident_expr;
    zT_225 = zT_221 == zT_224;
    if (zT_225) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    zT_226 = 16;
    zT_227 = depth >= zT_226;
    if (zT_227) goto z_bb_72; else goto z_bb_73;
    goto z_bb_67;
    z_bb_71:
    zT_274.has_value = 0;
    return zT_274;
    z_bb_72:
    zT_228.has_value = 0;
    return zT_228;
    z_bb_73:
    zT_232 = self->store;
    zT_230 = zT_232;
    zT_231 = node_idx;
    zT_233 = zF_53458827_astStoreIdentifier(zT_230, zT_231);
    name_id = zT_233;
    name_id = zT_233;
    name_id = zT_233;
    zT_235 = 0;
    zT_236 = (unsigned int)zT_235;
    mi = zT_236;
    mi = zT_236;
    mi = zT_236;
    goto z_bb_74;
    z_bb_74:
    zT_237 = self->symbol_reg;
    zT_238 = zT_237->tables_len;
    zT_239 = (unsigned int)zT_238;
    zT_240 = mi < zT_239;
    if (zT_240) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_245 = self->symbol_reg;
    zT_242 = zT_245;
    zT_246 = (unsigned int)mi;
    zT_243 = zT_246;
    zT_244 = name_id;
    zT_247 = zF_A398987E_symbolRegistryQuali(zT_242, zT_243, zT_244);
    c_sym = zT_247;
    c_sym = zT_247;
    c_sym = zT_247;
    zT_248 = c_sym.has_value;
    if (zT_248) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    zT_273.has_value = 0;
    return zT_273;
    z_bb_77:
    zT_271 = 1;
    zT_272 = mi + zT_271;
    mi = zT_272;
    mi = zT_272;
    goto z_bb_74;
    z_bb_78:
    cs = c_sym.value;
    zT_250 = cs->flags;
    zT_251 = 1;
    zT_252 = zT_250 & zT_251;
    zT_253 = 0;
    zT_254 = zT_252 == zT_253;
    if (zT_254) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    goto z_bb_77;
    z_bb_80:
    zT_258 = self->store;
    zT_256 = zT_258;
    zT_259 = cs->decl_node;
    zT_257 = zT_259;
    zT_260 = zF_FCDD1D35_astStoreNodeAt(zT_256, zT_257);
    c_decl = zT_260;
    c_decl = zT_260;
    c_decl = zT_260;
    zT_261 = c_decl.child_1;
    zT_262 = 0;
    zT_263 = zT_261 != zT_262;
    if (zT_263) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_264 = self;
    zT_267 = c_decl.child_1;
    zT_265 = zT_267;
    zT_268 = 1;
    zT_269 = depth + zT_268;
    zT_266 = zT_269;
    self = zT_264;
    node_idx = zT_265;
    depth = zT_266;
    goto z_bb_0;
    z_bb_83:
    goto z_bb_81;
}

/* EOF */
