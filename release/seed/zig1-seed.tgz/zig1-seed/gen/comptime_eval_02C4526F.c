#include "comptime_eval_02C4526F.h"
/* comptimeFoldTableInit */
zT_77F6F59C_ComptimeFoldTable zF_9BB9958E_comptimeFoldTableIn(zT_3E40CD83_Sand* alloc) {
    zT_77F6F59C_ComptimeFoldTable zT_1;
    zT_3E40CD83_Sand* zT_2;
    zT_21D3708C_U32ToU32Map zT_3 = {0};
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_2 = alloc;
    zT_3 = zF_58BDA2DE_u32ToU32MapInit(zT_2);
    zT_1.slots = zT_3;
    zT_4 = 0;
    zT_1.vals = (zT_89B1DDDA_ComptimeVal*)zT_4;
    zT_5 = 0;
    zT_1.len = zT_5;
    zT_6 = 0;
    zT_1.capacity = zT_6;
    zT_1.alloc = alloc;
    return zT_1;
}

/* comptimeFoldTableGrow */
void zF_82A38CDF_comptimeFoldTableGr(zT_77F6F59C_ComptimeFoldTable* self) {
    unsigned int zT_2;
    zT_89B1DDDA_ComptimeVal* zT_4;
    unsigned int zT_6;
    unsigned int zT_10;
    zT_3E40CD83_Sand* zT_12;
    zT_36325BAA_EU_042 zT_19 = {0};
    unsigned char zT_20;
    unsigned char* zT_21;
    zT_89B1DDDA_ComptimeVal* zT_24;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_89B1DDDA_ComptimeVal zT_30;
    unsigned int zT_32;
    unsigned int old_cap;
    zT_89B1DDDA_ComptimeVal* old_vals;
    unsigned int new_cap;
    unsigned char* raw;
    zT_89B1DDDA_ComptimeVal* new_vals;
    unsigned int i;
    zT_2 = self->capacity;
    old_cap = zT_2;
    zT_4 = self->vals;
    old_vals = zT_4;
    zT_6 = 16;
    new_cap = zT_6;
    if ((unsigned char)(old_cap >= (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = old_cap * (unsigned int)(2);
    new_cap = zT_10;
    goto z_bb_2;
    z_bb_2:
    zT_12 = self->alloc;
    zT_19 = zF_1395EB68_sandAlloc(zT_12, (unsigned int)((unsigned int)(48) * new_cap), (unsigned int)(8));
    zT_20 = zT_19.is_error;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_21 = zT_19.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_21;
    zT_24 = (zT_89B1DDDA_ComptimeVal*)raw;
    new_vals = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    i = zT_27;
    goto z_bb_6;
    z_bb_6:
    zT_28 = self->len;
    if ((unsigned char)(i < zT_28)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = old_vals[i];
    new_vals[i] = zT_30;
    goto z_bb_9;
    z_bb_8:
    self->vals = new_vals;
    self->capacity = new_cap;
    return;
    z_bb_9:
    zT_32 = i + (unsigned int)(1);
    i = zT_32;
    goto z_bb_6;
}

/* comptimeFoldTablePut */
void zF_376429F5_comptimeFoldTablePu(zT_77F6F59C_ComptimeFoldTable* self, unsigned int node_idx, zT_89B1DDDA_ComptimeVal v) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    zT_89B1DDDA_ComptimeVal* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_77F6F59C_ComptimeFoldTable* zT_14;
    zT_89B1DDDA_ComptimeVal* zT_15;
    unsigned int zT_16;
    zT_21D3708C_U32ToU32Map* zT_17;
    unsigned int zT_18;
    unsigned int zT_21;
    unsigned int zT_23;
    int zT_24;
    unsigned int slot;
    zT_3 = &self->slots;
    zT_4 = node_idx;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    zT_7 = zT_6.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    slot = zT_6.value;
    zT_9 = self->vals;
    zT_10 = (unsigned int)slot;
    zT_9[zT_10] = v;
    return;
    z_bb_2:
    zT_11 = self->len;
    zT_12 = self->capacity;
    if ((unsigned char)(zT_11 >= zT_12)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self;
    zF_82A38CDF_comptimeFoldTableGr(zT_14);
    goto z_bb_4;
    z_bb_4:
    zT_15 = self->vals;
    zT_16 = self->len;
    zT_15[zT_16] = v;
    zT_17 = &self->slots;
    zT_18 = node_idx;
    zT_21 = self->len;
    zF_26476265_u32ToU32MapPut(zT_17, zT_18, (unsigned int)((unsigned int)zT_21));
    zT_23 = self->len;
    zT_24 = 1;
    self->len = (unsigned int)(zT_23 + (unsigned int)((unsigned int)zT_24));
    return;
}

/* comptimeFoldTableGet */
zT_E53A25A2_Opt_203 zF_A230D7A8_comptimeFoldTableGe(zT_77F6F59C_ComptimeFoldTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    unsigned int zT_9;
    zT_89B1DDDA_ComptimeVal* zT_11;
    unsigned int zT_12;
    zT_89B1DDDA_ComptimeVal zT_13;
    zT_E53A25A2_Opt_203 zT_14;
    zT_E53A25A2_Opt_203 zT_15 = {0};
    unsigned int slot;
    zT_2 = &self->slots;
    zT_3 = node_idx;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    slot = zT_5.value;
    zT_9 = self->len;
    if ((unsigned char)((unsigned int)((unsigned int)slot) < zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_15.has_value = 0;
    return zT_15;
    z_bb_3:
    zT_11 = self->vals;
    zT_12 = (unsigned int)slot;
    zT_13 = zT_11[zT_12];
    zT_14.has_value = 1;
    zT_14.value = zT_13;
    return zT_14;
    z_bb_4:
    goto z_bb_2;
}

/* comptimeEvalInit */
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry* registry, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_3D7259E2_SymbolRegistry* symbol_reg) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_D3EB6303_StringInterner* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_D3EB6303_StringInterner* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27 = 0;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_D3EB6303_StringInterner* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35 = 0;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_D3EB6303_StringInterner* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43 = 0;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    zT_D3EB6303_StringInterner* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51 = 0;
    unsigned char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_D3EB6303_StringInterner* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67 = 0;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71 = 0;
    zT_D3EB6303_StringInterner* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75 = 0;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83 = 0;
    zT_DA663F79_ComptimeEval zT_84;
    unsigned char zT_85;
    zT_05CE5599_Opt_400 zT_86 = {0};
    zT_6F34EEB2_Opt_229 zT_87 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_as;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fc;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_itf;
    unsigned int itf_id;
    unsigned int size_id;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int off_id;
    unsigned int bitsz_id;
    unsigned int bitoff_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_iw;
    unsigned int iw_id;
    zT_5 = "@sizeOf";
    zT_7 = 7;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_size = zT_6;
    zT_9 = "@alignOf";
    zT_11 = 8;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_align = zT_10;
    zT_13 = "@intCast";
    zT_15 = 8;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    s_intc = zT_14;
    zT_17 = interner;
    zT_18 = s_intc;
    zT_19 = zF_50C274AF_stringInternerInter(zT_17, zT_18);
    intc_id = zT_19;
    zT_21 = "@as";
    zT_23 = 3;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    s_as = zT_22;
    zT_25 = interner;
    zT_26 = s_as;
    zT_27 = zF_50C274AF_stringInternerInter(zT_25, zT_26);
    as_id = zT_27;
    zT_29 = "@floatCast";
    zT_31 = 10;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    s_fc = zT_30;
    zT_33 = interner;
    zT_34 = s_fc;
    zT_35 = zF_50C274AF_stringInternerInter(zT_33, zT_34);
    fc_id = zT_35;
    zT_37 = "@intToFloat";
    zT_39 = 11;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    s_itf = zT_38;
    zT_41 = interner;
    zT_42 = s_itf;
    zT_43 = zF_50C274AF_stringInternerInter(zT_41, zT_42);
    itf_id = zT_43;
    zT_45 = interner;
    zT_46 = s_size;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    size_id = zT_47;
    zT_49 = interner;
    zT_50 = s_align;
    zT_51 = zF_50C274AF_stringInternerInter(zT_49, zT_50);
    align_id = zT_51;
    zT_53 = "@offsetOf";
    zT_55 = 9;
    zT_54.ptr = zT_53;
    zT_54.len = zT_55;
    s_off = zT_54;
    zT_57 = "@bitSizeOf";
    zT_59 = 10;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    s_bitsz = zT_58;
    zT_61 = "@bitOffsetOf";
    zT_63 = 12;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    s_bitoff = zT_62;
    zT_65 = interner;
    zT_66 = s_off;
    zT_67 = zF_50C274AF_stringInternerInter(zT_65, zT_66);
    off_id = zT_67;
    zT_69 = interner;
    zT_70 = s_bitsz;
    zT_71 = zF_50C274AF_stringInternerInter(zT_69, zT_70);
    bitsz_id = zT_71;
    zT_73 = interner;
    zT_74 = s_bitoff;
    zT_75 = zF_50C274AF_stringInternerInter(zT_73, zT_74);
    bitoff_id = zT_75;
    zT_77 = "@isWindows";
    zT_79 = 10;
    zT_78.ptr = zT_77;
    zT_78.len = zT_79;
    s_iw = zT_78;
    zT_81 = interner;
    zT_82 = s_iw;
    zT_83 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    iw_id = zT_83;
    zT_84.registry = registry;
    zT_84.store = store;
    zT_84.interner = interner;
    zT_84.symbol_reg = symbol_reg;
    zT_84.size_of_id = size_id;
    zT_84.align_of_id = align_id;
    zT_84.int_cast_id = intc_id;
    zT_84.as_id = as_id;
    zT_84.float_cast_id = fc_id;
    zT_84.int_to_float_id = itf_id;
    zT_84.offset_of_id = off_id;
    zT_84.bit_size_of_id = bitsz_id;
    zT_84.bit_offset_of_id = bitoff_id;
    zT_84.is_windows_id = iw_id;
    zT_85 = 0;
    zT_84.host_is_windows = zT_85;
    zT_86.has_value = 0;
    zT_84.local_consts = zT_86;
    zT_87.has_value = 0;
    zT_84.diag = zT_87;
    return zT_84;
}

/* ciZeroInt */
zT_0163D9A4_ComptimeInt zF_DC9B7BC0_ciZeroInt(void) {
    zT_0163D9A4_ComptimeInt zT_0;
    zT_9C9EF72B_Arr_unsigned_int_8 zT_1;
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned char zT_18;
    unsigned char zT_19;
    zT_2 = 0;
    zT_3 = 0;
    zT_1[zT_3] = zT_2;
    zT_4 = 0;
    zT_5 = 1;
    zT_1[zT_5] = zT_4;
    zT_6 = 0;
    zT_7 = 2;
    zT_1[zT_7] = zT_6;
    zT_8 = 0;
    zT_9 = 3;
    zT_1[zT_9] = zT_8;
    zT_10 = 0;
    zT_11 = 4;
    zT_1[zT_11] = zT_10;
    zT_12 = 0;
    zT_13 = 5;
    zT_1[zT_13] = zT_12;
    zT_14 = 0;
    zT_15 = 6;
    zT_1[zT_15] = zT_14;
    zT_16 = 0;
    zT_17 = 7;
    zT_1[zT_17] = zT_16;
    (void)zT_0.mag;
    {
    unsigned int _j = 0;
    while (_j < sizeof(zT_0.mag)) {
        ((unsigned char*)&zT_0.mag)[_j] = ((unsigned char*)&zT_1)[_j];
        _j++;
    }
}
    zT_18 = 0;
    zT_0.len = zT_18;
    zT_19 = 0;
    zT_0.neg = zT_19;
    return zT_0;
}

/* ciFromU64 */
zT_0163D9A4_ComptimeInt zF_1EAA44E6_ciFromU64(zT_79FAE712_u64 x) {
    zT_0163D9A4_ComptimeInt zT_2 = {0};
    unsigned int zT_7;
    unsigned int* zT_8;
    int zT_9;
    unsigned int zT_14;
    unsigned int* zT_15;
    int zT_16;
    unsigned int* zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_0163D9A4_ComptimeInt v;
    zT_2 = zF_DC9B7BC0_ciZeroInt();
    v = zT_2;
    if ((unsigned char)(x == (zT_79FAE712_u64)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return v;
    z_bb_2:
    zT_7 = (unsigned int)(zT_79FAE712_u64)(x & (zT_79FAE712_u64)(4294967295u));
    zT_8 = v.mag;
    zT_9 = 0;
    zT_8[zT_9] = zT_7;
    zT_14 = (unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(x >> (zT_79FAE712_u64)(32)) & (zT_79FAE712_u64)(4294967295u));
    zT_15 = v.mag;
    zT_16 = 1;
    zT_15[zT_16] = zT_14;
    v.len = (unsigned char)(1);
    zT_18 = v.mag;
    zT_19 = 1;
    zT_20 = zT_18[zT_19];
    if ((unsigned char)(zT_20 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    v.len = (unsigned char)(2);
    goto z_bb_4;
    z_bb_4:
    return v;
}

/* ciPow2 */
zT_0163D9A4_ComptimeInt zF_8F225501_ciPow2(unsigned int k) {
    zT_0163D9A4_ComptimeInt zT_2 = {0};
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned int* zT_13;
    zT_0163D9A4_ComptimeInt v;
    unsigned int word;
    unsigned int bit;
    zT_2 = zF_DC9B7BC0_ciZeroInt();
    v = zT_2;
    zT_6 = (unsigned int)(unsigned int)(k / (unsigned int)(32));
    word = zT_6;
    zT_9 = k % (unsigned int)(32);
    bit = zT_9;
    zT_12 = (unsigned int)(1) << (unsigned int)((unsigned int)bit);
    zT_13 = v.mag;
    zT_13[word] = zT_12;
    v.len = (unsigned char)((unsigned char)(unsigned int)(word + (unsigned int)(1)));
    return v;
}

/* ciSet */
void zF_45C2B9E7_ciSet(zT_0163D9A4_ComptimeInt* out, zT_0163D9A4_ComptimeInt src) {
    int zT_3;
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int* zT_9;
    int zT_10;
    unsigned int zT_12;
    unsigned char zT_13;
    unsigned char zT_14;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = src.mag;
    zT_8 = zT_7[i];
    zT_9 = out->mag;
    zT_9[i] = zT_8;
    goto z_bb_4;
    z_bb_3:
    zT_13 = src.len;
    out->len = zT_13;
    zT_14 = src.neg;
    out->neg = zT_14;
    return;
    z_bb_4:
    zT_10 = 1;
    zT_12 = i + (unsigned int)((unsigned int)zT_10);
    i = zT_12;
    goto z_bb_1;
}

/* ciNormalize */
void zF_390E9E58_ciNormalize(zT_0163D9A4_ComptimeInt* v) {
    unsigned char zT_2;
    unsigned int zT_3;
    unsigned char zT_5;
    int zT_7;
    unsigned char zT_9;
    unsigned int* zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_16;
    unsigned int zT_18;
    unsigned char zT_19;
    int zT_21;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_29;
    unsigned int* zT_30;
    int zT_31;
    unsigned int zT_33;
    unsigned int l;
    unsigned char done;
    unsigned int i;
    zT_2 = v->len;
    zT_3 = (unsigned int)zT_2;
    l = zT_3;
    zT_5 = 0;
    done = zT_5;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(!done)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 0;
    if ((unsigned char)(l == (unsigned int)zT_7)) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    v->len = (unsigned char)((unsigned char)l);
    zT_21 = 0;
    if ((unsigned char)(l == (unsigned int)zT_21)) goto z_bb_11; else goto z_bb_12;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_9 = 1;
    done = zT_9;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_10 = v->mag;
    zT_11 = 1;
    zT_12 = l - zT_11;
    zT_13 = zT_10[zT_12];
    if ((unsigned char)(zT_13 == (unsigned int)(0))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_16 = 1;
    zT_18 = l - (unsigned int)((unsigned int)zT_16);
    l = zT_18;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_19 = 1;
    done = zT_19;
    goto z_bb_9;
    z_bb_11:
    v->neg = (unsigned char)(0);
    zT_25 = 0;
    zT_26 = (unsigned int)zT_25;
    i = zT_26;
    goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_29 = 0;
    zT_30 = v->mag;
    zT_30[i] = zT_29;
    goto z_bb_16;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_31 = 1;
    zT_33 = i + (unsigned int)((unsigned int)zT_31);
    i = zT_33;
    goto z_bb_13;
}

/* ciIsZero */
unsigned char zF_0F5FA15F_ciIsZero(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    zT_1 = v.len;
    return (unsigned char)(zT_1 == (unsigned char)(0));
}

/* ciMagCmp */
int zF_0B19E30C_ciMagCmp(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b) {
    unsigned char zT_2;
    unsigned char zT_3;
    unsigned char zT_5;
    unsigned char zT_6;
    unsigned char zT_11;
    unsigned int zT_12;
    int zT_13;
    int zT_15;
    unsigned int zT_17;
    unsigned int* zT_18;
    unsigned int zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int* zT_23;
    unsigned int zT_24;
    unsigned int* zT_25;
    unsigned int zT_26;
    unsigned int i;
    zT_2 = a.len;
    zT_3 = b.len;
    if ((unsigned char)(zT_2 != zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = a.len;
    zT_6 = b.len;
    if ((unsigned char)(zT_5 < zT_6)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_11 = a.len;
    zT_12 = (unsigned int)zT_11;
    i = zT_12;
    goto z_bb_5;
    z_bb_3:
    return (int)((int)-1);
    z_bb_4:
    return (int)(1);
    z_bb_5:
    zT_13 = 0;
    if ((unsigned char)(i > (unsigned int)zT_13)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = 1;
    zT_17 = i - (unsigned int)((unsigned int)zT_15);
    i = zT_17;
    zT_18 = a.mag;
    zT_19 = zT_18[i];
    zT_20 = b.mag;
    zT_21 = zT_20[i];
    if ((unsigned char)(zT_19 != zT_21)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return (int)(0);
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_23 = a.mag;
    zT_24 = zT_23[i];
    zT_25 = b.mag;
    zT_26 = zT_25[i];
    if ((unsigned char)(zT_24 < zT_26)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    return (int)((int)-1);
    z_bb_12:
    return (int)(1);
}

/* ciCmp */
int zF_6408F093_ciCmp(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b) {
    unsigned char zT_2;
    unsigned char zT_3;
    unsigned char zT_5;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt zT_10;
    int zT_11 = 0;
    unsigned char zT_12;
    int zT_14;
    int m;
    zT_2 = a.neg;
    zT_3 = b.neg;
    if ((unsigned char)(zT_2 != zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = a.neg;
    if (zT_5) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_9 = a;
    zT_10 = b;
    zT_11 = zF_0B19E30C_ciMagCmp(zT_9, zT_10);
    m = zT_11;
    zT_12 = a.neg;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (int)((int)-1);
    z_bb_4:
    return (int)(1);
    z_bb_5:
    zT_14 = (int)(0) - m;
    m = zT_14;
    goto z_bb_6;
    z_bb_6:
    return m;
}

/* ciToU64 */
zT_79FAE712_u64 zF_4F2C9C5D_ciToU64(zT_0163D9A4_ComptimeInt v) {
    zT_79FAE712_u64 zT_2;
    unsigned char zT_3;
    unsigned int* zT_6;
    int zT_7;
    unsigned int zT_8;
    zT_79FAE712_u64 zT_9;
    unsigned char zT_10;
    unsigned int* zT_13;
    int zT_14;
    unsigned int zT_15;
    zT_79FAE712_u64 zT_19;
    unsigned char zT_20;
    zT_79FAE712_u64 zT_22;
    zT_79FAE712_u64 m;
    zT_2 = 0;
    m = zT_2;
    zT_3 = v.len;
    if ((unsigned char)(zT_3 > (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = v.mag;
    zT_7 = 0;
    zT_8 = zT_6[zT_7];
    zT_9 = (zT_79FAE712_u64)zT_8;
    m = zT_9;
    goto z_bb_2;
    z_bb_2:
    zT_10 = v.len;
    if ((unsigned char)(zT_10 > (unsigned char)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_13 = v.mag;
    zT_14 = 1;
    zT_15 = zT_13[zT_14];
    zT_19 = m | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_15) << (zT_79FAE712_u64)(32));
    m = zT_19;
    goto z_bb_4;
    z_bb_4:
    zT_20 = v.neg;
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_22 = (zT_79FAE712_u64)(0) - m;
    m = zT_22;
    goto z_bb_6;
    z_bb_6:
    return m;
}

/* ciToF64 */
zT_00435AEB_f64 zF_E6CE9168_ciToF64(zT_0163D9A4_ComptimeInt v) {
    zT_00435AEB_f64 zT_2;
    unsigned char zT_4;
    unsigned int zT_5;
    int zT_6;
    int zT_8;
    unsigned int zT_10;
    unsigned int* zT_13;
    unsigned int zT_14;
    zT_00435AEB_f64 zT_16;
    unsigned char zT_17;
    zT_00435AEB_f64 zT_18;
    zT_00435AEB_f64 fv;
    unsigned int i;
    zT_2 = 0;
    fv = zT_2;
    zT_4 = v.len;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = 0;
    if ((unsigned char)(i > (unsigned int)zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = 1;
    zT_10 = i - (unsigned int)((unsigned int)zT_8);
    i = zT_10;
    zT_13 = v.mag;
    zT_14 = zT_13[i];
    zT_16 = (zT_00435AEB_f64)(fv * (zT_00435AEB_f64)(4.294967296e+9)) + (zT_00435AEB_f64)((zT_00435AEB_f64)zT_14);
    fv = zT_16;
    goto z_bb_4;
    z_bb_3:
    zT_17 = v.neg;
    if (zT_17) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_18 = -fv;
    fv = zT_18;
    goto z_bb_6;
    z_bb_6:
    return fv;
}

/* ciIntVal */
zT_89B1DDDA_ComptimeVal zF_237A4571_ciIntVal(zT_0163D9A4_ComptimeInt v) {
    zT_89B1DDDA_ComptimeVal zT_1;
    unsigned int zT_2;
    zT_79FAE712_u64 zT_3;
    zT_1.v = v;
    zT_2 = 0;
    zT_1.kind = zT_2;
    zT_3 = 0;
    zT_1.float_bits = zT_3;
    return zT_1;
}

/* ciBoolVal */
zT_89B1DDDA_ComptimeVal zF_E867E750_ciBoolVal(unsigned char b) {
    zT_0163D9A4_ComptimeInt zT_2 = {0};
    zT_0163D9A4_ComptimeInt zT_5 = {0};
    zT_89B1DDDA_ComptimeVal zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_8;
    zT_0163D9A4_ComptimeInt v;
    zT_2 = zF_DC9B7BC0_ciZeroInt();
    v = zT_2;
    if (b) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(1));
    v = zT_5;
    goto z_bb_2;
    z_bb_2:
    zT_6.v = v;
    zT_7 = 1;
    zT_6.kind = zT_7;
    zT_8 = 0;
    zT_6.float_bits = zT_8;
    return zT_6;
}

/* ciMagAnd */
void zF_51463AE1_ciMagAnd(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    int zT_4;
    unsigned int zT_5;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int* zT_13;
    int zT_14;
    unsigned int zT_16;
    zT_0163D9A4_ComptimeInt* zT_19;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = a.mag;
    zT_9 = zT_8[i];
    zT_10 = b.mag;
    zT_11 = zT_10[i];
    zT_12 = zT_9 & zT_11;
    zT_13 = out->mag;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_19 = out;
    zF_390E9E58_ciNormalize(zT_19);
    return;
    z_bb_4:
    zT_14 = 1;
    zT_16 = i + (unsigned int)((unsigned int)zT_14);
    i = zT_16;
    goto z_bb_1;
}

/* ciMagOr */
void zF_5F410015_ciMagOr(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    int zT_4;
    unsigned int zT_5;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int* zT_13;
    int zT_14;
    unsigned int zT_16;
    zT_0163D9A4_ComptimeInt* zT_19;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = a.mag;
    zT_9 = zT_8[i];
    zT_10 = b.mag;
    zT_11 = zT_10[i];
    zT_12 = zT_9 | zT_11;
    zT_13 = out->mag;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_19 = out;
    zF_390E9E58_ciNormalize(zT_19);
    return;
    z_bb_4:
    zT_14 = 1;
    zT_16 = i + (unsigned int)((unsigned int)zT_14);
    i = zT_16;
    goto z_bb_1;
}

/* ciMagXor */
void zF_3DC94F2D_ciMagXor(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    int zT_4;
    unsigned int zT_5;
    unsigned int* zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int* zT_13;
    int zT_14;
    unsigned int zT_16;
    zT_0163D9A4_ComptimeInt* zT_19;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = a.mag;
    zT_9 = zT_8[i];
    zT_10 = b.mag;
    zT_11 = zT_10[i];
    zT_12 = zT_9 ^ zT_11;
    zT_13 = out->mag;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_19 = out;
    zF_390E9E58_ciNormalize(zT_19);
    return;
    z_bb_4:
    zT_14 = 1;
    zT_16 = i + (unsigned int)((unsigned int)zT_14);
    i = zT_16;
    goto z_bb_1;
}

/* ciMagNot */
void zF_EBF92AE9_ciMagNot(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    int zT_3;
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    int zT_11;
    unsigned int zT_13;
    zT_0163D9A4_ComptimeInt* zT_16;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = a.mag;
    zT_8 = zT_7[i];
    zT_9 = ~zT_8;
    zT_10 = out->mag;
    zT_10[i] = zT_9;
    goto z_bb_4;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_16 = out;
    zF_390E9E58_ciNormalize(zT_16);
    return;
    z_bb_4:
    zT_11 = 1;
    zT_13 = i + (unsigned int)((unsigned int)zT_11);
    i = zT_13;
    goto z_bb_1;
}

/* ciMagAddInto */
unsigned char zF_29F86241_ciMagAddInto(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_11;
    zT_79FAE712_u64 zT_13;
    unsigned char zT_14;
    unsigned int* zT_17;
    unsigned int zT_18;
    zT_79FAE712_u64 zT_19;
    unsigned char zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    zT_79FAE712_u64 zT_25;
    zT_79FAE712_u64 zT_28;
    unsigned int zT_31;
    unsigned int* zT_32;
    zT_79FAE712_u64 zT_34;
    int zT_35;
    unsigned int zT_37;
    zT_0163D9A4_ComptimeInt* zT_43;
    zT_79FAE712_u64 carry;
    unsigned int i;
    zT_79FAE712_u64 av;
    zT_79FAE712_u64 bv;
    zT_79FAE712_u64 s;
    zT_4 = 0;
    carry = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    i = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = 0;
    av = zT_11;
    zT_13 = 0;
    bv = zT_13;
    zT_14 = a.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    if ((unsigned char)(carry != (zT_79FAE712_u64)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_4:
    zT_35 = 1;
    zT_37 = i + (unsigned int)((unsigned int)zT_35);
    i = zT_37;
    goto z_bb_1;
    z_bb_5:
    zT_17 = a.mag;
    zT_18 = zT_17[i];
    zT_19 = (zT_79FAE712_u64)zT_18;
    av = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = b.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_20))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_23 = b.mag;
    zT_24 = zT_23[i];
    zT_25 = (zT_79FAE712_u64)zT_24;
    bv = zT_25;
    goto z_bb_8;
    z_bb_8:
    zT_28 = (zT_79FAE712_u64)(av + bv) + carry;
    s = zT_28;
    zT_31 = (unsigned int)(zT_79FAE712_u64)(s & (zT_79FAE712_u64)(4294967295u));
    zT_32 = out->mag;
    zT_32[i] = zT_31;
    zT_34 = s >> (zT_79FAE712_u64)(32);
    carry = zT_34;
    goto z_bb_4;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_43 = out;
    zF_390E9E58_ciNormalize(zT_43);
    return (unsigned char)(1);
}

/* ciMagSubInto */
unsigned char zF_965473A4_ciMagSubInto(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    zT_79FAE712_u64 zT_4;
    int zT_6;
    unsigned int zT_7;
    zT_79FAE712_u64 zT_11;
    zT_79FAE712_u64 zT_13;
    unsigned char zT_14;
    unsigned int* zT_17;
    unsigned int zT_18;
    zT_79FAE712_u64 zT_19;
    unsigned char zT_20;
    unsigned int* zT_23;
    unsigned int zT_24;
    zT_79FAE712_u64 zT_25;
    zT_79FAE712_u64 zT_30;
    unsigned int zT_33;
    unsigned int* zT_34;
    zT_79FAE712_u64 zT_37;
    zT_79FAE712_u64 zT_38;
    int zT_39;
    unsigned int zT_41;
    zT_0163D9A4_ComptimeInt* zT_44;
    zT_79FAE712_u64 borrow;
    unsigned int i;
    zT_79FAE712_u64 av;
    zT_79FAE712_u64 bv;
    zT_79FAE712_u64 d;
    zT_4 = 0;
    borrow = zT_4;
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    i = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = 0;
    av = zT_11;
    zT_13 = 0;
    bv = zT_13;
    zT_14 = a.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_14))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_44 = out;
    zF_390E9E58_ciNormalize(zT_44);
    return (unsigned char)(1);
    z_bb_4:
    zT_39 = 1;
    zT_41 = i + (unsigned int)((unsigned int)zT_39);
    i = zT_41;
    goto z_bb_1;
    z_bb_5:
    zT_17 = a.mag;
    zT_18 = zT_17[i];
    zT_19 = (zT_79FAE712_u64)zT_18;
    av = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_20 = b.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_20))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_23 = b.mag;
    zT_24 = zT_23[i];
    zT_25 = (zT_79FAE712_u64)zT_24;
    bv = zT_25;
    goto z_bb_8;
    z_bb_8:
    zT_30 = (zT_79FAE712_u64)((zT_79FAE712_u64)(av + (zT_79FAE712_u64)(4294967296ULL)) - bv) - borrow;
    d = zT_30;
    zT_33 = (unsigned int)(zT_79FAE712_u64)(d & (zT_79FAE712_u64)(4294967295u));
    zT_34 = out->mag;
    zT_34[i] = zT_33;
    if ((unsigned char)(d >= (zT_79FAE712_u64)(4294967296ULL))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_37 = 0;
    borrow = zT_37;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_4;
    z_bb_11:
    zT_38 = 1;
    borrow = zT_38;
    goto z_bb_10;
}

/* ciMagAddOne */
unsigned char zF_962947A9_ciMagAddOne(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    zT_0163D9A4_ComptimeInt zT_5 = {0};
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    zT_0163D9A4_ComptimeInt* zT_8;
    unsigned char zT_9 = 0;
    zT_0163D9A4_ComptimeInt one;
    zT_5 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(1));
    one = zT_5;
    zT_6 = a;
    zT_7 = one;
    zT_8 = out;
    zT_9 = zF_29F86241_ciMagAddInto(zT_6, zT_7, zT_8);
    return zT_9;
}

/* ciMagSubOne */
unsigned char zF_CBDA30A2_ciMagSubOne(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_16;
    unsigned int* zT_17;
    int zT_18;
    unsigned int zT_20;
    zT_0163D9A4_ComptimeInt* zT_23;
    unsigned int borrow;
    unsigned int i;
    unsigned int av;
    unsigned int d;
    zT_3 = 1;
    borrow = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = a.mag;
    zT_11 = zT_10[i];
    av = zT_11;
    zT_13 = av - borrow;
    d = zT_13;
    if ((unsigned char)(av < borrow)) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_23 = out;
    zF_390E9E58_ciNormalize(zT_23);
    return (unsigned char)(1);
    z_bb_4:
    zT_18 = 1;
    zT_20 = i + (unsigned int)((unsigned int)zT_18);
    i = zT_20;
    goto z_bb_1;
    z_bb_5:
    zT_15 = 1;
    borrow = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = out->mag;
    zT_17[i] = d;
    goto z_bb_4;
    z_bb_7:
    zT_16 = 0;
    borrow = zT_16;
    goto z_bb_6;
}

/* ciAdd */
unsigned char zF_8A5DB878_ciAdd(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_4;
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    zT_0163D9A4_ComptimeInt* zT_8;
    unsigned char zT_9 = 0;
    unsigned char zT_12;
    unsigned char zT_13;
    zT_0163D9A4_ComptimeInt zT_19;
    zT_0163D9A4_ComptimeInt zT_20;
    int zT_21 = 0;
    int zT_22;
    zT_0163D9A4_ComptimeInt* zT_24;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt zT_26 = {0};
    int zT_28;
    zT_0163D9A4_ComptimeInt zT_30;
    zT_0163D9A4_ComptimeInt zT_31;
    zT_0163D9A4_ComptimeInt* zT_32;
    unsigned char zT_33 = 0;
    unsigned char zT_36;
    zT_0163D9A4_ComptimeInt zT_38;
    zT_0163D9A4_ComptimeInt zT_39;
    zT_0163D9A4_ComptimeInt* zT_40;
    unsigned char zT_41 = 0;
    unsigned char zT_44;
    int m;
    zT_3 = a.neg;
    zT_4 = b.neg;
    if ((unsigned char)(zT_3 == zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = a;
    zT_7 = b;
    zT_8 = out;
    zT_9 = zF_29F86241_ciMagAddInto(zT_6, zT_7, zT_8);
    if ((unsigned char)(!zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_19 = a;
    zT_20 = b;
    zT_21 = zF_0B19E30C_ciMagCmp(zT_19, zT_20);
    m = zT_21;
    zT_22 = 0;
    if ((unsigned char)(m == zT_22)) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_12 = a.neg;
    out->neg = zT_12;
    zT_13 = out->len;
    if ((unsigned char)(zT_13 == (unsigned char)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    out->neg = (unsigned char)(0);
    goto z_bb_6;
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    zT_24 = out;
    zT_26 = zF_DC9B7BC0_ciZeroInt();
    zT_25 = zT_26;
    zF_45C2B9E7_ciSet(zT_24, zT_25);
    return (unsigned char)(1);
    z_bb_8:
    zT_28 = 0;
    if ((unsigned char)(m > zT_28)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_30 = a;
    zT_31 = b;
    zT_32 = out;
    zT_33 = zF_965473A4_ciMagSubInto(zT_30, zT_31, zT_32);
    if ((unsigned char)(!zT_33)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_38 = b;
    zT_39 = a;
    zT_40 = out;
    zT_41 = zF_965473A4_ciMagSubInto(zT_38, zT_39, zT_40);
    if ((unsigned char)(!zT_41)) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_36 = a.neg;
    out->neg = zT_36;
    return (unsigned char)(1);
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_44 = b.neg;
    out->neg = zT_44;
    return (unsigned char)(1);
}

/* ciSub */
unsigned char zF_539A2D81_ciSub(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    zT_0163D9A4_ComptimeInt zT_4;
    unsigned char zT_5 = 0;
    unsigned char zT_7;
    zT_0163D9A4_ComptimeInt zT_10;
    zT_0163D9A4_ComptimeInt zT_11;
    zT_0163D9A4_ComptimeInt* zT_12;
    unsigned char zT_13 = 0;
    zT_0163D9A4_ComptimeInt nb;
    nb = b;
    zT_4 = nb;
    zT_5 = zF_0F5FA15F_ciIsZero(zT_4);
    if ((unsigned char)(!zT_5)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_7 = nb.neg;
    nb.neg = (unsigned char)(!zT_7);
    goto z_bb_2;
    z_bb_2:
    zT_10 = a;
    zT_11 = nb;
    zT_12 = out;
    zT_13 = zF_8A5DB878_ciAdd(zT_10, zT_11, zT_12);
    return zT_13;
    z_bb_3:
    nb.neg = (unsigned char)(0);
    goto z_bb_2;
}

/* ciNeg */
unsigned char zF_EECBFD7D_ciNeg(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    zT_0163D9A4_ComptimeInt* zT_2;
    zT_0163D9A4_ComptimeInt zT_3;
    zT_0163D9A4_ComptimeInt zT_4;
    unsigned char zT_5 = 0;
    unsigned char zT_7;
    zT_2 = out;
    zT_3 = a;
    zF_45C2B9E7_ciSet(zT_2, zT_3);
    zT_4 = a;
    zT_5 = zF_0F5FA15F_ciIsZero(zT_4);
    if ((unsigned char)(!zT_5)) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_7 = a.neg;
    out->neg = (unsigned char)(!zT_7);
    goto z_bb_2;
    z_bb_2:
    return (unsigned char)(1);
    z_bb_3:
    out->neg = (unsigned char)(0);
    goto z_bb_2;
}

/* ciMul */
unsigned char zF_A3E385DD_ciMul(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    zT_0163D9A4_ComptimeInt zT_3;
    unsigned char zT_4 = 0;
    unsigned char zT_5;
    zT_0163D9A4_ComptimeInt zT_6;
    unsigned char zT_7 = 0;
    zT_0163D9A4_ComptimeInt* zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt zT_10 = {0};
    zT_B0635956_Arr_zT_79FAE712_u64 zT_13;
    int zT_15;
    unsigned int zT_16;
    zT_79FAE712_u64 zT_19;
    int zT_20;
    unsigned int zT_22;
    unsigned char zT_24;
    unsigned int zT_25;
    unsigned char zT_27;
    unsigned int zT_28;
    int zT_30;
    unsigned int zT_31;
    zT_79FAE712_u64 zT_34;
    int zT_36;
    unsigned int zT_37;
    unsigned int* zT_40;
    unsigned int zT_41;
    unsigned int* zT_43;
    unsigned int zT_44;
    unsigned int zT_47;
    zT_79FAE712_u64 zT_48;
    zT_79FAE712_u64 zT_50;
    zT_79FAE712_u64 zT_52;
    unsigned int zT_53;
    zT_79FAE712_u64 zT_55;
    int zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    zT_79FAE712_u64 zT_68;
    zT_79FAE712_u64 zT_69;
    zT_79FAE712_u64 zT_71;
    zT_79FAE712_u64 zT_73;
    int zT_74;
    unsigned int zT_76;
    int zT_77;
    unsigned int zT_79;
    unsigned int zT_81;
    zT_79FAE712_u64 zT_84;
    int zT_88;
    unsigned int zT_90;
    int zT_91;
    unsigned int zT_92;
    zT_79FAE712_u64 zT_95;
    unsigned int zT_96;
    unsigned int* zT_97;
    int zT_98;
    unsigned int zT_100;
    zT_0163D9A4_ComptimeInt* zT_103;
    unsigned char zT_104;
    unsigned char zT_105;
    unsigned char zT_107;
    zT_B0635956_Arr_zT_79FAE712_u64 acc;
    unsigned int zi;
    unsigned int alen;
    unsigned int blen;
    unsigned int i;
    zT_79FAE712_u64 carry;
    unsigned int j;
    unsigned int oi;
    zT_79FAE712_u64 p;
    unsigned int k;
    zT_79FAE712_u64 c2;
    zT_79FAE712_u64 s;
    zT_3 = a;
    zT_4 = zF_0F5FA15F_ciIsZero(zT_3);
    if (zT_4) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_6 = b;
    zT_7 = zF_0F5FA15F_ciIsZero(zT_6);
    zT_5 = zT_7;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = out;
    zT_10 = zF_DC9B7BC0_ciZeroInt();
    zT_9 = zT_10;
    zF_45C2B9E7_ciSet(zT_8, zT_9);
    return (unsigned char)(1);
    z_bb_5:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_13[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        acc[_i] = zT_13[_i];
        _i++;
    }
}
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    zi = zT_16;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(zi < (unsigned int)(16))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_19 = 0;
    acc[zi] = zT_19;
    goto z_bb_9;
    z_bb_8:
    zT_24 = a.len;
    zT_25 = (unsigned int)zT_24;
    alen = zT_25;
    zT_27 = b.len;
    zT_28 = (unsigned int)zT_27;
    blen = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    i = zT_31;
    goto z_bb_10;
    z_bb_9:
    zT_20 = 1;
    zT_22 = zi + (unsigned int)((unsigned int)zT_20);
    zi = zT_22;
    goto z_bb_6;
    z_bb_10:
    if ((unsigned char)(i < alen)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_34 = 0;
    carry = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    j = zT_37;
    goto z_bb_14;
    z_bb_12:
    zT_81 = 8;
    oi = zT_81;
    goto z_bb_24;
    z_bb_13:
    zT_77 = 1;
    zT_79 = i + (unsigned int)((unsigned int)zT_77);
    i = zT_79;
    goto z_bb_10;
    z_bb_14:
    if ((unsigned char)(j < blen)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_40 = a.mag;
    zT_41 = zT_40[i];
    zT_43 = b.mag;
    zT_44 = zT_43[j];
    zT_47 = i + j;
    zT_48 = acc[zT_47];
    zT_50 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_41) * (zT_79FAE712_u64)((zT_79FAE712_u64)zT_44)) + zT_48) + carry;
    p = zT_50;
    zT_52 = p & (zT_79FAE712_u64)(4294967295u);
    zT_53 = i + j;
    acc[zT_53] = zT_52;
    zT_55 = p >> (zT_79FAE712_u64)(32);
    carry = zT_55;
    goto z_bb_17;
    z_bb_16:
    zT_60 = i + blen;
    k = zT_60;
    c2 = carry;
    goto z_bb_18;
    z_bb_17:
    zT_56 = 1;
    zT_58 = j + (unsigned int)((unsigned int)zT_56);
    j = zT_58;
    goto z_bb_14;
    z_bb_18:
    if ((unsigned char)(c2 != (zT_79FAE712_u64)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    if ((unsigned char)(k >= (unsigned int)(16))) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    goto z_bb_13;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_68 = acc[k];
    zT_69 = zT_68 + c2;
    s = zT_69;
    zT_71 = s & (zT_79FAE712_u64)(4294967295u);
    acc[k] = zT_71;
    zT_73 = s >> (zT_79FAE712_u64)(32);
    c2 = zT_73;
    zT_74 = 1;
    zT_76 = k + (unsigned int)((unsigned int)zT_74);
    k = zT_76;
    goto z_bb_21;
    z_bb_24:
    if ((unsigned char)(oi < (unsigned int)(16))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_84 = acc[oi];
    if ((unsigned char)(zT_84 != (zT_79FAE712_u64)(0))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_91 = 0;
    zT_92 = (unsigned int)zT_91;
    i = zT_92;
    goto z_bb_30;
    z_bb_27:
    zT_88 = 1;
    zT_90 = oi + (unsigned int)((unsigned int)zT_88);
    oi = zT_90;
    goto z_bb_24;
    z_bb_28:
    return (unsigned char)(0);
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_95 = acc[i];
    zT_96 = (unsigned int)zT_95;
    zT_97 = out->mag;
    zT_97[i] = zT_96;
    goto z_bb_33;
    z_bb_32:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_103 = out;
    zF_390E9E58_ciNormalize(zT_103);
    zT_104 = a.neg;
    zT_105 = b.neg;
    out->neg = (unsigned char)(zT_104 != zT_105);
    zT_107 = out->len;
    if ((unsigned char)(zT_107 == (unsigned char)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_33:
    zT_98 = 1;
    zT_100 = i + (unsigned int)((unsigned int)zT_98);
    i = zT_100;
    goto z_bb_30;
    z_bb_34:
    out->neg = (unsigned char)(0);
    goto z_bb_35;
    z_bb_35:
    return (unsigned char)(1);
}

/* ciDivMod */
unsigned char zF_25A0EEC0_ciDivMod(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* q, zT_0163D9A4_ComptimeInt* r) {
    zT_0163D9A4_ComptimeInt zT_4;
    unsigned char zT_5 = 0;
    zT_0163D9A4_ComptimeInt zT_7;
    unsigned char zT_8 = 0;
    zT_0163D9A4_ComptimeInt* zT_9;
    zT_0163D9A4_ComptimeInt zT_10;
    zT_0163D9A4_ComptimeInt zT_11 = {0};
    zT_0163D9A4_ComptimeInt* zT_12;
    zT_0163D9A4_ComptimeInt zT_13;
    zT_0163D9A4_ComptimeInt zT_14 = {0};
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_17;
    int zT_18 = 0;
    int zT_19;
    zT_0163D9A4_ComptimeInt* zT_21;
    zT_0163D9A4_ComptimeInt zT_22;
    zT_0163D9A4_ComptimeInt zT_23 = {0};
    zT_0163D9A4_ComptimeInt* zT_24;
    zT_0163D9A4_ComptimeInt zT_25;
    unsigned char zT_26;
    zT_9B9EF598_Arr_unsigned_int_9 zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    int zT_43;
    unsigned int zT_44;
    zT_0163D9A4_ComptimeInt zT_46 = {0};
    int zT_48;
    unsigned int zT_49;
    int zT_50;
    int zT_52;
    unsigned int zT_54;
    unsigned int zT_56;
    int zT_57;
    unsigned int zT_58;
    unsigned int zT_62;
    int zT_63;
    unsigned int zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_68;
    int zT_69;
    unsigned int zT_71;
    int zT_73;
    unsigned int zT_74;
    int zT_76;
    unsigned int zT_78;
    int zT_79;
    unsigned char zT_81;
    unsigned char zT_82;
    unsigned int* zT_86;
    unsigned int zT_87;
    unsigned int zT_91;
    int zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    int zT_95;
    int zT_96;
    unsigned char zT_98;
    unsigned int zT_99;
    int zT_102;
    unsigned int zT_104;
    unsigned char zT_106;
    int zT_107;
    unsigned char zT_109;
    unsigned char zT_110;
    unsigned char zT_113;
    unsigned char zT_114;
    unsigned char zT_118;
    unsigned char zT_120;
    unsigned int zT_121;
    int zT_122;
    unsigned char zT_124;
    int zT_126;
    unsigned int zT_128;
    unsigned int zT_129;
    unsigned int* zT_130;
    unsigned int zT_131;
    unsigned char zT_133;
    unsigned int zT_134;
    unsigned int* zT_135;
    unsigned int zT_136;
    unsigned char zT_138;
    unsigned char zT_139;
    unsigned char zT_141;
    unsigned int zT_143;
    int zT_145;
    unsigned int zT_146;
    unsigned int zT_150;
    unsigned char zT_151;
    unsigned int* zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_163;
    unsigned int zT_164;
    int zT_165;
    unsigned int zT_167;
    int zT_168;
    unsigned int zT_169;
    unsigned char zT_171;
    int zT_172;
    unsigned char zT_174;
    int zT_176;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned char zT_181;
    int zT_182;
    unsigned int zT_184;
    int zT_186;
    unsigned int zT_187;
    int zT_189;
    unsigned int zT_191;
    unsigned int* zT_192;
    unsigned int zT_193;
    unsigned int zT_197;
    unsigned int* zT_198;
    zT_0163D9A4_ComptimeInt* zT_199;
    zT_0163D9A4_ComptimeInt zT_200;
    zT_0163D9A4_ComptimeInt* zT_202;
    unsigned char zT_203;
    unsigned char zT_204;
    unsigned char zT_206;
    int zT_211;
    unsigned int zT_212;
    unsigned int zT_215;
    unsigned int* zT_216;
    int zT_217;
    unsigned int zT_219;
    unsigned char zT_221;
    zT_0163D9A4_ComptimeInt* zT_222;
    unsigned char zT_223;
    zT_9B9EF598_Arr_unsigned_int_9 rem;
    unsigned int k;
    unsigned int rem_len;
    zT_0163D9A4_ComptimeInt qm;
    unsigned int bit;
    unsigned int carry;
    unsigned int nv;
    unsigned int word;
    unsigned int pos;
    unsigned int abit;
    unsigned char ge;
    unsigned char diff_found;
    unsigned int m;
    unsigned int borrow;
    unsigned int m2;
    unsigned int bv;
    unsigned char found;
    unsigned int sub;
    unsigned int diff;
    unsigned int qword;
    unsigned int qpos;
    unsigned int ri;
    zT_4 = b;
    zT_5 = zF_0F5FA15F_ciIsZero(zT_4);
    if (zT_5) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = a;
    zT_8 = zF_0F5FA15F_ciIsZero(zT_7);
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = q;
    zT_11 = zF_DC9B7BC0_ciZeroInt();
    zT_10 = zT_11;
    zF_45C2B9E7_ciSet(zT_9, zT_10);
    zT_12 = r;
    zT_14 = zF_DC9B7BC0_ciZeroInt();
    zT_13 = zT_14;
    zF_45C2B9E7_ciSet(zT_12, zT_13);
    return (unsigned char)(1);
    z_bb_4:
    zT_16 = a;
    zT_17 = b;
    zT_18 = zF_0B19E30C_ciMagCmp(zT_16, zT_17);
    zT_19 = 0;
    if ((unsigned char)(zT_18 < zT_19)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_21 = q;
    zT_23 = zF_DC9B7BC0_ciZeroInt();
    zT_22 = zT_23;
    zF_45C2B9E7_ciSet(zT_21, zT_22);
    zT_24 = r;
    zT_25 = a;
    zF_45C2B9E7_ciSet(zT_24, zT_25);
    zT_26 = r->len;
    if ((unsigned char)(zT_26 == (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 9) {
        zT_32[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 9) {
        rem[_i] = zT_32[_i];
        _i++;
    }
}
    zT_34 = 0;
    zT_35 = (unsigned int)zT_34;
    k = zT_35;
    goto z_bb_9;
    z_bb_7:
    r->neg = (unsigned char)(0);
    goto z_bb_8;
    z_bb_8:
    return (unsigned char)(1);
    z_bb_9:
    if ((unsigned char)(k < (unsigned int)(9))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_38 = 0;
    rem[k] = zT_38;
    goto z_bb_12;
    z_bb_11:
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    rem_len = zT_44;
    zT_46 = zF_DC9B7BC0_ciZeroInt();
    qm = zT_46;
    zT_48 = 256;
    zT_49 = (unsigned int)zT_48;
    bit = zT_49;
    goto z_bb_13;
    z_bb_12:
    zT_39 = 1;
    zT_41 = k + (unsigned int)((unsigned int)zT_39);
    k = zT_41;
    goto z_bb_9;
    z_bb_13:
    zT_50 = 0;
    if ((unsigned char)(bit > (unsigned int)zT_50)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_52 = 1;
    zT_54 = bit - (unsigned int)((unsigned int)zT_52);
    bit = zT_54;
    zT_56 = 0;
    carry = zT_56;
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    k = zT_58;
    goto z_bb_17;
    z_bb_15:
    zT_199 = q;
    zT_200 = qm;
    zF_45C2B9E7_ciSet(zT_199, zT_200);
    q->len = (unsigned char)(8);
    zT_202 = q;
    zF_390E9E58_ciNormalize(zT_202);
    zT_203 = a.neg;
    zT_204 = b.neg;
    q->neg = (unsigned char)(zT_203 != zT_204);
    zT_206 = q->len;
    if ((unsigned char)(zT_206 == (unsigned char)(0))) goto z_bb_74; else goto z_bb_75;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(k < (unsigned int)(9))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_62 = rem[k];
    zT_63 = 1;
    zT_65 = (unsigned int)(zT_62 << zT_63) | carry;
    nv = zT_65;
    zT_66 = rem[k];
    zT_67 = 31;
    zT_68 = zT_66 >> zT_67;
    carry = zT_68;
    rem[k] = nv;
    goto z_bb_20;
    z_bb_19:
    zT_73 = 32;
    zT_74 = bit / zT_73;
    word = zT_74;
    zT_76 = 32;
    zT_78 = (unsigned int)(unsigned int)(bit % zT_76);
    pos = zT_78;
    zT_79 = 8;
    if ((unsigned char)(word < (unsigned int)zT_79)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_69 = 1;
    zT_71 = k + (unsigned int)((unsigned int)zT_69);
    k = zT_71;
    goto z_bb_17;
    z_bb_21:
    zT_82 = a.len;
    zT_81 = word < (unsigned int)((unsigned int)zT_82);
    goto z_bb_23;
    z_bb_22:
    zT_81 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_81) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_86 = a.mag;
    zT_87 = zT_86[word];
    zT_91 = (unsigned int)(zT_87 >> (unsigned int)((unsigned int)pos)) & (unsigned int)(1);
    abit = zT_91;
    zT_92 = 0;
    zT_93 = rem[zT_92];
    zT_94 = zT_93 | abit;
    zT_95 = 0;
    rem[zT_95] = zT_94;
    goto z_bb_25;
    z_bb_25:
    zT_96 = 9;
    if ((unsigned char)(rem_len < (unsigned int)zT_96)) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_99 = rem[rem_len];
    zT_98 = zT_99 != (unsigned int)(0);
    goto z_bb_28;
    z_bb_27:
    zT_98 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_98) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_102 = 1;
    zT_104 = rem_len + (unsigned int)((unsigned int)zT_102);
    rem_len = zT_104;
    goto z_bb_30;
    z_bb_30:
    zT_106 = 0;
    ge = zT_106;
    zT_107 = 9;
    if ((unsigned char)(rem_len == (unsigned int)zT_107)) goto z_bb_31; else goto z_bb_33;
    z_bb_31:
    zT_109 = 1;
    ge = zT_109;
    goto z_bb_32;
    z_bb_32:
    if (ge) goto z_bb_53; else goto z_bb_54;
    z_bb_33:
    zT_110 = b.len;
    if ((unsigned char)(rem_len > (unsigned int)((unsigned int)zT_110))) goto z_bb_34; else goto z_bb_36;
    z_bb_34:
    zT_113 = 1;
    ge = zT_113;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_114 = b.len;
    if ((unsigned char)(rem_len == (unsigned int)((unsigned int)zT_114))) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_118 = 0;
    diff_found = zT_118;
    zT_120 = b.len;
    zT_121 = (unsigned int)zT_120;
    m = zT_121;
    goto z_bb_39;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_122 = 0;
    if ((unsigned char)(m > (unsigned int)zT_122)) goto z_bb_43; else goto z_bb_44;
    z_bb_40:
    zT_126 = 1;
    zT_128 = m - (unsigned int)((unsigned int)zT_126);
    m = zT_128;
    zT_129 = rem[m];
    zT_130 = b.mag;
    zT_131 = zT_130[m];
    if ((unsigned char)(zT_129 != zT_131)) goto z_bb_46; else goto z_bb_47;
    z_bb_41:
    if ((unsigned char)(!diff_found)) goto z_bb_51; else goto z_bb_52;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_124 = !diff_found;
    goto z_bb_45;
    z_bb_44:
    zT_124 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_124) goto z_bb_40; else goto z_bb_41;
    z_bb_46:
    zT_133 = 1;
    diff_found = zT_133;
    zT_134 = rem[m];
    zT_135 = b.mag;
    zT_136 = zT_135[m];
    if ((unsigned char)(zT_134 < zT_136)) goto z_bb_48; else goto z_bb_50;
    z_bb_47:
    goto z_bb_42;
    z_bb_48:
    zT_138 = 0;
    ge = zT_138;
    goto z_bb_49;
    z_bb_49:
    goto z_bb_47;
    z_bb_50:
    zT_139 = 1;
    ge = zT_139;
    goto z_bb_49;
    z_bb_51:
    zT_141 = 1;
    ge = zT_141;
    goto z_bb_52;
    z_bb_52:
    goto z_bb_38;
    z_bb_53:
    zT_143 = 0;
    borrow = zT_143;
    zT_145 = 0;
    zT_146 = (unsigned int)zT_145;
    m2 = zT_146;
    goto z_bb_55;
    z_bb_54:
    goto z_bb_16;
    z_bb_55:
    if ((unsigned char)(m2 < (unsigned int)(9))) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_150 = 0;
    bv = zT_150;
    zT_151 = b.len;
    if ((unsigned char)(m2 < (unsigned int)((unsigned int)zT_151))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_168 = 9;
    zT_169 = (unsigned int)zT_168;
    rem_len = zT_169;
    zT_171 = 0;
    found = zT_171;
    goto z_bb_64;
    z_bb_58:
    zT_165 = 1;
    zT_167 = m2 + (unsigned int)((unsigned int)zT_165);
    m2 = zT_167;
    goto z_bb_55;
    z_bb_59:
    zT_154 = b.mag;
    zT_155 = zT_154[m2];
    bv = zT_155;
    goto z_bb_60;
    z_bb_60:
    zT_157 = bv + borrow;
    sub = zT_157;
    zT_159 = rem[m2];
    zT_160 = zT_159 - sub;
    diff = zT_160;
    zT_161 = rem[m2];
    if ((unsigned char)(zT_161 < sub)) goto z_bb_61; else goto z_bb_63;
    z_bb_61:
    zT_163 = 1;
    borrow = zT_163;
    goto z_bb_62;
    z_bb_62:
    rem[m2] = diff;
    goto z_bb_58;
    z_bb_63:
    zT_164 = 0;
    borrow = zT_164;
    goto z_bb_62;
    z_bb_64:
    zT_172 = 0;
    if ((unsigned char)(rem_len > (unsigned int)zT_172)) goto z_bb_68; else goto z_bb_69;
    z_bb_65:
    zT_176 = 1;
    zT_177 = rem_len - zT_176;
    zT_178 = rem[zT_177];
    if ((unsigned char)(zT_178 != (unsigned int)(0))) goto z_bb_71; else goto z_bb_73;
    z_bb_66:
    zT_186 = 32;
    zT_187 = bit / zT_186;
    qword = zT_187;
    zT_189 = 32;
    zT_191 = (unsigned int)(unsigned int)(bit % zT_189);
    qpos = zT_191;
    zT_192 = qm.mag;
    zT_193 = zT_192[qword];
    zT_197 = zT_193 | (unsigned int)((unsigned int)(1) << (unsigned int)((unsigned int)qpos));
    zT_198 = qm.mag;
    zT_198[qword] = zT_197;
    goto z_bb_54;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_174 = !found;
    goto z_bb_70;
    z_bb_69:
    zT_174 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_174) goto z_bb_65; else goto z_bb_66;
    z_bb_71:
    zT_181 = 1;
    found = zT_181;
    goto z_bb_72;
    z_bb_72:
    goto z_bb_67;
    z_bb_73:
    zT_182 = 1;
    zT_184 = rem_len - (unsigned int)((unsigned int)zT_182);
    rem_len = zT_184;
    goto z_bb_72;
    z_bb_74:
    q->neg = (unsigned char)(0);
    goto z_bb_75;
    z_bb_75:
    zT_211 = 0;
    zT_212 = (unsigned int)zT_211;
    ri = zT_212;
    goto z_bb_76;
    z_bb_76:
    if ((unsigned char)(ri < (unsigned int)(8))) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_215 = rem[ri];
    zT_216 = r->mag;
    zT_216[ri] = zT_215;
    goto z_bb_79;
    z_bb_78:
    r->len = (unsigned char)(8);
    zT_221 = a.neg;
    r->neg = zT_221;
    zT_222 = r;
    zF_390E9E58_ciNormalize(zT_222);
    zT_223 = r->len;
    if ((unsigned char)(zT_223 == (unsigned char)(0))) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_217 = 1;
    zT_219 = ri + (unsigned int)((unsigned int)zT_217);
    ri = zT_219;
    goto z_bb_76;
    z_bb_80:
    r->neg = (unsigned char)(0);
    goto z_bb_81;
    z_bb_81:
    return (unsigned char)(1);
}

/* ciBitAnd */
unsigned char zF_E15DE14D_ciBitAnd(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_5;
    unsigned char zT_6;
    zT_0163D9A4_ComptimeInt zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt* zT_10;
    unsigned char zT_12;
    unsigned char zT_13;
    zT_0163D9A4_ComptimeInt zT_16 = {0};
    zT_0163D9A4_ComptimeInt zT_18 = {0};
    zT_0163D9A4_ComptimeInt zT_19;
    zT_0163D9A4_ComptimeInt* zT_20;
    unsigned char zT_22 = 0;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt* zT_26;
    unsigned char zT_28 = 0;
    zT_0163D9A4_ComptimeInt zT_32 = {0};
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    zT_0163D9A4_ComptimeInt* zT_35;
    zT_0163D9A4_ComptimeInt zT_37;
    zT_0163D9A4_ComptimeInt* zT_38;
    unsigned char zT_39 = 0;
    zT_0163D9A4_ComptimeInt zT_45 = {0};
    zT_0163D9A4_ComptimeInt zT_47 = {0};
    unsigned char zT_48;
    zT_0163D9A4_ComptimeInt zT_49;
    zT_0163D9A4_ComptimeInt* zT_50;
    unsigned char zT_52 = 0;
    zT_0163D9A4_ComptimeInt* zT_55;
    zT_0163D9A4_ComptimeInt zT_56;
    zT_0163D9A4_ComptimeInt zT_58;
    zT_0163D9A4_ComptimeInt* zT_59;
    unsigned char zT_61 = 0;
    zT_0163D9A4_ComptimeInt* zT_64;
    zT_0163D9A4_ComptimeInt zT_65;
    zT_0163D9A4_ComptimeInt zT_68 = {0};
    zT_0163D9A4_ComptimeInt zT_69;
    zT_0163D9A4_ComptimeInt* zT_70;
    zT_0163D9A4_ComptimeInt zT_72;
    zT_0163D9A4_ComptimeInt zT_73;
    zT_0163D9A4_ComptimeInt* zT_74;
    zT_0163D9A4_ComptimeInt am;
    zT_0163D9A4_ComptimeInt bm;
    zT_0163D9A4_ComptimeInt m;
    zT_0163D9A4_ComptimeInt n;
    zT_0163D9A4_ComptimeInt t;
    zT_0163D9A4_ComptimeInt notm;
    zT_3 = a.neg;
    if ((unsigned char)(!zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = b.neg;
    zT_5 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = a;
    zT_9 = b;
    zT_10 = out;
    zF_51463AE1_ciMagAnd(zT_8, zT_9, zT_10);
    return (unsigned char)(1);
    z_bb_5:
    zT_12 = a.neg;
    if (zT_12) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_13 = b.neg;
    goto z_bb_8;
    z_bb_7:
    zT_13 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_13) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_16 = zF_DC9B7BC0_ciZeroInt();
    am = zT_16;
    zT_18 = zF_DC9B7BC0_ciZeroInt();
    bm = zT_18;
    zT_19 = a;
    zT_20 = &am;
    zT_22 = zF_CBDA30A2_ciMagSubOne(zT_19, zT_20);
    if ((unsigned char)(!zT_22)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_45 = zF_DC9B7BC0_ciZeroInt();
    m = zT_45;
    zT_47 = zF_DC9B7BC0_ciZeroInt();
    n = zT_47;
    zT_48 = a.neg;
    if (zT_48) goto z_bb_17; else goto z_bb_19;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_25 = b;
    zT_26 = &bm;
    zT_28 = zF_CBDA30A2_ciMagSubOne(zT_25, zT_26);
    if ((unsigned char)(!zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_32 = zF_DC9B7BC0_ciZeroInt();
    t = zT_32;
    zT_33 = am;
    zT_34 = bm;
    zT_35 = &t;
    zF_5F410015_ciMagOr(zT_33, zT_34, zT_35);
    zT_37 = t;
    zT_38 = out;
    zT_39 = zF_962947A9_ciMagAddOne(zT_37, zT_38);
    if ((unsigned char)(!zT_39)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
    z_bb_17:
    zT_49 = a;
    zT_50 = &m;
    zT_52 = zF_CBDA30A2_ciMagSubOne(zT_49, zT_50);
    if ((unsigned char)(!zT_52)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_68 = zF_DC9B7BC0_ciZeroInt();
    notm = zT_68;
    zT_69 = m;
    zT_70 = &notm;
    zF_EBF92AE9_ciMagNot(zT_69, zT_70);
    zT_72 = notm;
    zT_73 = n;
    zT_74 = out;
    zF_51463AE1_ciMagAnd(zT_72, zT_73, zT_74);
    return (unsigned char)(1);
    z_bb_19:
    zT_58 = b;
    zT_59 = &m;
    zT_61 = zF_CBDA30A2_ciMagSubOne(zT_58, zT_59);
    if ((unsigned char)(!zT_61)) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    zT_55 = &n;
    zT_56 = b;
    zF_45C2B9E7_ciSet(zT_55, zT_56);
    goto z_bb_18;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_64 = &n;
    zT_65 = a;
    zF_45C2B9E7_ciSet(zT_64, zT_65);
    goto z_bb_18;
}

/* ciBitOr */
unsigned char zF_93823331_ciBitOr(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_5;
    unsigned char zT_6;
    zT_0163D9A4_ComptimeInt zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt* zT_10;
    zT_0163D9A4_ComptimeInt zT_13 = {0};
    zT_0163D9A4_ComptimeInt zT_15 = {0};
    unsigned char zT_16;
    unsigned char zT_17;
    zT_0163D9A4_ComptimeInt zT_19;
    zT_0163D9A4_ComptimeInt* zT_20;
    unsigned char zT_22 = 0;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt* zT_26;
    unsigned char zT_28 = 0;
    zT_0163D9A4_ComptimeInt zT_32 = {0};
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    zT_0163D9A4_ComptimeInt* zT_35;
    zT_0163D9A4_ComptimeInt zT_37;
    zT_0163D9A4_ComptimeInt* zT_38;
    unsigned char zT_39 = 0;
    unsigned char zT_44;
    zT_0163D9A4_ComptimeInt zT_45;
    zT_0163D9A4_ComptimeInt* zT_46;
    unsigned char zT_48 = 0;
    zT_0163D9A4_ComptimeInt* zT_51;
    zT_0163D9A4_ComptimeInt zT_52;
    zT_0163D9A4_ComptimeInt zT_54;
    zT_0163D9A4_ComptimeInt* zT_55;
    unsigned char zT_57 = 0;
    zT_0163D9A4_ComptimeInt* zT_60;
    zT_0163D9A4_ComptimeInt zT_61;
    zT_0163D9A4_ComptimeInt zT_64 = {0};
    zT_0163D9A4_ComptimeInt zT_65;
    zT_0163D9A4_ComptimeInt* zT_66;
    zT_0163D9A4_ComptimeInt zT_69 = {0};
    zT_0163D9A4_ComptimeInt zT_70;
    zT_0163D9A4_ComptimeInt zT_71;
    zT_0163D9A4_ComptimeInt* zT_72;
    zT_0163D9A4_ComptimeInt zT_74;
    zT_0163D9A4_ComptimeInt* zT_75;
    unsigned char zT_76 = 0;
    zT_0163D9A4_ComptimeInt m;
    zT_0163D9A4_ComptimeInt n;
    zT_0163D9A4_ComptimeInt t;
    zT_0163D9A4_ComptimeInt notn;
    zT_0163D9A4_ComptimeInt t2;
    zT_3 = a.neg;
    if ((unsigned char)(!zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = b.neg;
    zT_5 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = a;
    zT_9 = b;
    zT_10 = out;
    zF_5F410015_ciMagOr(zT_8, zT_9, zT_10);
    return (unsigned char)(1);
    z_bb_5:
    zT_13 = zF_DC9B7BC0_ciZeroInt();
    m = zT_13;
    zT_15 = zF_DC9B7BC0_ciZeroInt();
    n = zT_15;
    zT_16 = a.neg;
    if (zT_16) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = b.neg;
    goto z_bb_8;
    z_bb_7:
    zT_17 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_19 = a;
    zT_20 = &m;
    zT_22 = zF_CBDA30A2_ciMagSubOne(zT_19, zT_20);
    if ((unsigned char)(!zT_22)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_44 = a.neg;
    if (zT_44) goto z_bb_17; else goto z_bb_19;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_25 = b;
    zT_26 = &n;
    zT_28 = zF_CBDA30A2_ciMagSubOne(zT_25, zT_26);
    if ((unsigned char)(!zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_32 = zF_DC9B7BC0_ciZeroInt();
    t = zT_32;
    zT_33 = m;
    zT_34 = n;
    zT_35 = &t;
    zF_51463AE1_ciMagAnd(zT_33, zT_34, zT_35);
    zT_37 = t;
    zT_38 = out;
    zT_39 = zF_962947A9_ciMagAddOne(zT_37, zT_38);
    if ((unsigned char)(!zT_39)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
    z_bb_17:
    zT_45 = a;
    zT_46 = &m;
    zT_48 = zF_CBDA30A2_ciMagSubOne(zT_45, zT_46);
    if ((unsigned char)(!zT_48)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    zT_64 = zF_DC9B7BC0_ciZeroInt();
    notn = zT_64;
    zT_65 = n;
    zT_66 = &notn;
    zF_EBF92AE9_ciMagNot(zT_65, zT_66);
    zT_69 = zF_DC9B7BC0_ciZeroInt();
    t2 = zT_69;
    zT_70 = m;
    zT_71 = notn;
    zT_72 = &t2;
    zF_51463AE1_ciMagAnd(zT_70, zT_71, zT_72);
    zT_74 = t2;
    zT_75 = out;
    zT_76 = zF_962947A9_ciMagAddOne(zT_74, zT_75);
    if ((unsigned char)(!zT_76)) goto z_bb_24; else goto z_bb_25;
    z_bb_19:
    zT_54 = b;
    zT_55 = &m;
    zT_57 = zF_CBDA30A2_ciMagSubOne(zT_54, zT_55);
    if ((unsigned char)(!zT_57)) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    zT_51 = &n;
    zT_52 = b;
    zF_45C2B9E7_ciSet(zT_51, zT_52);
    goto z_bb_18;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    zT_60 = &n;
    zT_61 = a;
    zF_45C2B9E7_ciSet(zT_60, zT_61);
    goto z_bb_18;
    z_bb_24:
    return (unsigned char)(0);
    z_bb_25:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
}

/* ciBitXor */
unsigned char zF_C592CA21_ciBitXor(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_5;
    unsigned char zT_6;
    zT_0163D9A4_ComptimeInt zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt* zT_10;
    zT_0163D9A4_ComptimeInt zT_13 = {0};
    zT_0163D9A4_ComptimeInt zT_15 = {0};
    unsigned char zT_16;
    unsigned char zT_17;
    zT_0163D9A4_ComptimeInt zT_19;
    zT_0163D9A4_ComptimeInt* zT_20;
    unsigned char zT_22 = 0;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt* zT_26;
    unsigned char zT_28 = 0;
    zT_0163D9A4_ComptimeInt zT_31;
    zT_0163D9A4_ComptimeInt zT_32;
    zT_0163D9A4_ComptimeInt* zT_33;
    unsigned char zT_35;
    zT_0163D9A4_ComptimeInt zT_36;
    zT_0163D9A4_ComptimeInt* zT_37;
    unsigned char zT_39 = 0;
    zT_0163D9A4_ComptimeInt* zT_42;
    zT_0163D9A4_ComptimeInt zT_43;
    zT_0163D9A4_ComptimeInt zT_45;
    zT_0163D9A4_ComptimeInt* zT_46;
    unsigned char zT_48 = 0;
    zT_0163D9A4_ComptimeInt* zT_51;
    zT_0163D9A4_ComptimeInt zT_52;
    zT_0163D9A4_ComptimeInt zT_55 = {0};
    zT_0163D9A4_ComptimeInt zT_56;
    zT_0163D9A4_ComptimeInt zT_57;
    zT_0163D9A4_ComptimeInt* zT_58;
    zT_0163D9A4_ComptimeInt zT_60;
    zT_0163D9A4_ComptimeInt* zT_61;
    unsigned char zT_62 = 0;
    zT_0163D9A4_ComptimeInt m;
    zT_0163D9A4_ComptimeInt n;
    zT_0163D9A4_ComptimeInt t;
    zT_3 = a.neg;
    if ((unsigned char)(!zT_3)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = b.neg;
    zT_5 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_5 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_8 = a;
    zT_9 = b;
    zT_10 = out;
    zF_3DC94F2D_ciMagXor(zT_8, zT_9, zT_10);
    return (unsigned char)(1);
    z_bb_5:
    zT_13 = zF_DC9B7BC0_ciZeroInt();
    m = zT_13;
    zT_15 = zF_DC9B7BC0_ciZeroInt();
    n = zT_15;
    zT_16 = a.neg;
    if (zT_16) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = b.neg;
    goto z_bb_8;
    z_bb_7:
    zT_17 = 0;
    goto z_bb_8;
    z_bb_8:
    if (zT_17) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_19 = a;
    zT_20 = &m;
    zT_22 = zF_CBDA30A2_ciMagSubOne(zT_19, zT_20);
    if ((unsigned char)(!zT_22)) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_35 = a.neg;
    if (zT_35) goto z_bb_15; else goto z_bb_17;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_25 = b;
    zT_26 = &n;
    zT_28 = zF_CBDA30A2_ciMagSubOne(zT_25, zT_26);
    if ((unsigned char)(!zT_28)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_31 = m;
    zT_32 = n;
    zT_33 = out;
    zF_3DC94F2D_ciMagXor(zT_31, zT_32, zT_33);
    return (unsigned char)(1);
    z_bb_15:
    zT_36 = a;
    zT_37 = &m;
    zT_39 = zF_CBDA30A2_ciMagSubOne(zT_36, zT_37);
    if ((unsigned char)(!zT_39)) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    zT_55 = zF_DC9B7BC0_ciZeroInt();
    t = zT_55;
    zT_56 = m;
    zT_57 = n;
    zT_58 = &t;
    zF_3DC94F2D_ciMagXor(zT_56, zT_57, zT_58);
    zT_60 = t;
    zT_61 = out;
    zT_62 = zF_962947A9_ciMagAddOne(zT_60, zT_61);
    if ((unsigned char)(!zT_62)) goto z_bb_22; else goto z_bb_23;
    z_bb_17:
    zT_45 = b;
    zT_46 = &m;
    zT_48 = zF_CBDA30A2_ciMagSubOne(zT_45, zT_46);
    if ((unsigned char)(!zT_48)) goto z_bb_20; else goto z_bb_21;
    z_bb_18:
    return (unsigned char)(0);
    z_bb_19:
    zT_42 = &n;
    zT_43 = b;
    zF_45C2B9E7_ciSet(zT_42, zT_43);
    goto z_bb_16;
    z_bb_20:
    return (unsigned char)(0);
    z_bb_21:
    zT_51 = &n;
    zT_52 = a;
    zF_45C2B9E7_ciSet(zT_51, zT_52);
    goto z_bb_16;
    z_bb_22:
    return (unsigned char)(0);
    z_bb_23:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
}

/* ciBitNot */
unsigned char zF_223ABA6D_ciBitNot(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_2;
    zT_0163D9A4_ComptimeInt zT_3;
    zT_0163D9A4_ComptimeInt* zT_4;
    unsigned char zT_5 = 0;
    zT_0163D9A4_ComptimeInt zT_10;
    zT_0163D9A4_ComptimeInt* zT_11;
    unsigned char zT_12 = 0;
    zT_2 = a.neg;
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = a;
    zT_4 = out;
    zT_5 = zF_CBDA30A2_ciMagSubOne(zT_3, zT_4);
    if ((unsigned char)(!zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_10 = a;
    zT_11 = out;
    zT_12 = zF_962947A9_ciMagAddOne(zT_10, zT_11);
    if ((unsigned char)(!zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    out->neg = (unsigned char)(0);
    return (unsigned char)(1);
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    out->neg = (unsigned char)(1);
    return (unsigned char)(1);
}

/* ciShl */
unsigned char zF_4FDD0D22_ciShl(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_4;
    zT_0163D9A4_ComptimeInt zT_5;
    unsigned char zT_6 = 0;
    unsigned char zT_9;
    zT_0163D9A4_ComptimeInt zT_13;
    unsigned char zT_14 = 0;
    zT_0163D9A4_ComptimeInt* zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_17 = {0};
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned int* zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_33;
    unsigned int zT_36;
    zT_6749E41F_Arr_zT_79FAE712_u64 zT_38;
    int zT_40;
    unsigned int zT_41;
    zT_79FAE712_u64 zT_45;
    unsigned char zT_46;
    unsigned int* zT_49;
    unsigned int zT_50;
    zT_79FAE712_u64 zT_51;
    zT_79FAE712_u64 zT_53;
    zT_79FAE712_u64 zT_54;
    unsigned char zT_57;
    int zT_62;
    unsigned int zT_64;
    zT_79FAE712_u64 zT_66;
    int zT_67;
    unsigned int zT_68;
    unsigned int zT_74;
    zT_79FAE712_u64 zT_77;
    zT_79FAE712_u64 zT_78;
    unsigned int zT_81;
    unsigned int* zT_82;
    zT_79FAE712_u64 zT_84;
    int zT_85;
    unsigned int zT_87;
    zT_0163D9A4_ComptimeInt* zT_93;
    unsigned char zT_94;
    unsigned char zT_95;
    unsigned int sh;
    unsigned int word;
    unsigned int bits;
    zT_6749E41F_Arr_zT_79FAE712_u64 tmp;
    unsigned int i;
    zT_79FAE712_u64 src;
    zT_79FAE712_u64 carry;
    zT_79FAE712_u64 val;
    unsigned int si;
    zT_3 = b.neg;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = b;
    zT_6 = zF_0F5FA15F_ciIsZero(zT_5);
    zT_4 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_9 = b.len;
    if ((unsigned char)(zT_9 > (unsigned char)(1))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_13 = a;
    zT_14 = zF_0F5FA15F_ciIsZero(zT_13);
    if (zT_14) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_15 = out;
    zT_17 = zF_DC9B7BC0_ciZeroInt();
    zT_16 = zT_17;
    zF_45C2B9E7_ciSet(zT_15, zT_16);
    return (unsigned char)(1);
    z_bb_9:
    zT_20 = 0;
    sh = zT_20;
    zT_21 = b.len;
    if ((unsigned char)(zT_21 == (unsigned char)(1))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = b.mag;
    zT_25 = 0;
    zT_26 = zT_24[zT_25];
    sh = zT_26;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(sh >= (unsigned int)(256))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return (unsigned char)(0);
    z_bb_13:
    zT_33 = (unsigned int)(unsigned int)(sh / (unsigned int)(32));
    word = zT_33;
    zT_36 = sh % (unsigned int)(32);
    bits = zT_36;
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_38[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        tmp[_i] = zT_38[_i];
        _i++;
    }
}
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    i = zT_41;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_45 = 0;
    src = zT_45;
    zT_46 = a.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_46))) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    zT_66 = 0;
    carry = zT_66;
    zT_67 = 0;
    zT_68 = (unsigned int)zT_67;
    i = zT_68;
    goto z_bb_25;
    z_bb_17:
    zT_62 = 1;
    zT_64 = i + (unsigned int)((unsigned int)zT_62);
    i = zT_64;
    goto z_bb_14;
    z_bb_18:
    zT_49 = a.mag;
    zT_50 = zT_49[i];
    zT_51 = (zT_79FAE712_u64)zT_50;
    src = zT_51;
    goto z_bb_19;
    z_bb_19:
    zT_53 = src << (zT_79FAE712_u64)((zT_79FAE712_u64)bits);
    tmp[i] = zT_53;
    zT_54 = tmp[i];
    if ((unsigned char)(zT_54 != (zT_79FAE712_u64)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_57 = (unsigned int)(i + word) >= (unsigned int)(8);
    goto z_bb_22;
    z_bb_21:
    zT_57 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_57) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    goto z_bb_17;
    z_bb_25:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    val = carry;
    if ((unsigned char)(i >= word)) goto z_bb_29; else goto z_bb_30;
    z_bb_27:
    if ((unsigned char)(carry != (zT_79FAE712_u64)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_28:
    zT_85 = 1;
    zT_87 = i + (unsigned int)((unsigned int)zT_85);
    i = zT_87;
    goto z_bb_25;
    z_bb_29:
    zT_74 = i - word;
    si = zT_74;
    if ((unsigned char)(si < (unsigned int)(8))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    zT_81 = (unsigned int)(zT_79FAE712_u64)(val & (zT_79FAE712_u64)(4294967295u));
    zT_82 = out->mag;
    zT_82[i] = zT_81;
    zT_84 = val >> (zT_79FAE712_u64)(32);
    carry = zT_84;
    goto z_bb_28;
    z_bb_31:
    zT_77 = tmp[si];
    zT_78 = val + zT_77;
    val = zT_78;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    return (unsigned char)(0);
    z_bb_34:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_93 = out;
    zF_390E9E58_ciNormalize(zT_93);
    zT_94 = a.neg;
    out->neg = zT_94;
    zT_95 = out->len;
    if ((unsigned char)(zT_95 == (unsigned char)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    out->neg = (unsigned char)(0);
    goto z_bb_36;
    z_bb_36:
    return (unsigned char)(1);
}

/* ciShr */
unsigned char zF_41DCF718_ciShr(zT_0163D9A4_ComptimeInt a, zT_0163D9A4_ComptimeInt b, zT_0163D9A4_ComptimeInt* out) {
    unsigned char zT_3;
    unsigned char zT_4;
    zT_0163D9A4_ComptimeInt zT_5;
    unsigned char zT_6 = 0;
    unsigned char zT_9;
    zT_0163D9A4_ComptimeInt zT_13;
    unsigned char zT_14 = 0;
    zT_0163D9A4_ComptimeInt* zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_17 = {0};
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned int* zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned char zT_29;
    zT_0163D9A4_ComptimeInt* zT_30;
    zT_0163D9A4_ComptimeInt zT_31;
    zT_0163D9A4_ComptimeInt zT_34 = {0};
    zT_0163D9A4_ComptimeInt* zT_36;
    zT_0163D9A4_ComptimeInt zT_37;
    zT_0163D9A4_ComptimeInt zT_38 = {0};
    unsigned int zT_43;
    unsigned int zT_46;
    unsigned char zT_48;
    int zT_50;
    unsigned int zT_51;
    unsigned char zT_53;
    unsigned char zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned char zT_61;
    int zT_62;
    unsigned int zT_64;
    unsigned char zT_67;
    unsigned char zT_68;
    unsigned int zT_76;
    unsigned int* zT_77;
    unsigned int zT_78;
    unsigned char zT_82;
    int zT_83;
    unsigned int zT_84;
    unsigned int zT_88;
    zT_79FAE712_u64 zT_90;
    unsigned char zT_91;
    unsigned int* zT_94;
    unsigned int zT_95;
    zT_79FAE712_u64 zT_98;
    zT_79FAE712_u64 zT_100;
    unsigned char zT_103;
    int zT_104;
    unsigned char zT_106;
    unsigned int* zT_109;
    int zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    int zT_114;
    zT_79FAE712_u64 zT_117;
    unsigned int zT_121;
    unsigned int* zT_122;
    int zT_123;
    unsigned int zT_125;
    zT_0163D9A4_ComptimeInt* zT_128;
    unsigned char zT_129;
    zT_79FAE712_u64 zT_131;
    int zT_133;
    unsigned int zT_134;
    unsigned int* zT_138;
    unsigned int zT_139;
    zT_79FAE712_u64 zT_141;
    unsigned int zT_144;
    unsigned int* zT_145;
    zT_79FAE712_u64 zT_147;
    unsigned int zT_150;
    int zT_151;
    unsigned int zT_153;
    zT_0163D9A4_ComptimeInt* zT_158;
    unsigned char zT_159;
    unsigned int sh;
    unsigned int word;
    unsigned int bits;
    unsigned char sticky;
    unsigned int i;
    unsigned int mask;
    unsigned int idx;
    zT_79FAE712_u64 lo;
    zT_79FAE712_u64 hi;
    zT_79FAE712_u64 carry;
    unsigned int k2;
    zT_79FAE712_u64 s;
    zT_3 = b.neg;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = b;
    zT_6 = zF_0F5FA15F_ciIsZero(zT_5);
    zT_4 = !zT_6;
    goto z_bb_3;
    z_bb_2:
    zT_4 = 0;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_9 = b.len;
    if ((unsigned char)(zT_9 > (unsigned char)(1))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_13 = a;
    zT_14 = zF_0F5FA15F_ciIsZero(zT_13);
    if (zT_14) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_15 = out;
    zT_17 = zF_DC9B7BC0_ciZeroInt();
    zT_16 = zT_17;
    zF_45C2B9E7_ciSet(zT_15, zT_16);
    return (unsigned char)(1);
    z_bb_9:
    zT_20 = 0;
    sh = zT_20;
    zT_21 = b.len;
    if ((unsigned char)(zT_21 == (unsigned char)(1))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = b.mag;
    zT_25 = 0;
    zT_26 = zT_24[zT_25];
    sh = zT_26;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(sh >= (unsigned int)(256))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_29 = a.neg;
    if (zT_29) goto z_bb_14; else goto z_bb_16;
    z_bb_13:
    zT_43 = (unsigned int)(unsigned int)(sh / (unsigned int)(32));
    word = zT_43;
    zT_46 = sh % (unsigned int)(32);
    bits = zT_46;
    zT_48 = 0;
    sticky = zT_48;
    zT_50 = 0;
    zT_51 = (unsigned int)zT_50;
    i = zT_51;
    goto z_bb_17;
    z_bb_14:
    zT_30 = out;
    zT_34 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(1));
    zT_31 = zT_34;
    zF_45C2B9E7_ciSet(zT_30, zT_31);
    out->neg = (unsigned char)(1);
    goto z_bb_15;
    z_bb_15:
    return (unsigned char)(1);
    z_bb_16:
    zT_36 = out;
    zT_38 = zF_DC9B7BC0_ciZeroInt();
    zT_37 = zT_38;
    zF_45C2B9E7_ciSet(zT_36, zT_37);
    goto z_bb_15;
    z_bb_17:
    if ((unsigned char)(i < word)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_53 = a.len;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_53))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    if ((unsigned char)(bits > (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_20:
    zT_62 = 1;
    zT_64 = i + (unsigned int)((unsigned int)zT_62);
    i = zT_64;
    goto z_bb_17;
    z_bb_21:
    zT_57 = a.mag;
    zT_58 = zT_57[i];
    zT_56 = zT_58 != (unsigned int)(0);
    goto z_bb_23;
    z_bb_22:
    zT_56 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_56) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_61 = 1;
    sticky = zT_61;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_20;
    z_bb_26:
    zT_68 = a.len;
    zT_67 = word < (unsigned int)((unsigned int)zT_68);
    goto z_bb_28;
    z_bb_27:
    zT_67 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_67) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_76 = (unsigned int)((unsigned int)(1) << (unsigned int)((unsigned int)bits)) - (unsigned int)(1);
    mask = zT_76;
    zT_77 = a.mag;
    zT_78 = zT_77[word];
    if ((unsigned char)((unsigned int)(zT_78 & mask) != (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    zT_83 = 0;
    zT_84 = (unsigned int)zT_83;
    i = zT_84;
    goto z_bb_33;
    z_bb_31:
    zT_82 = 1;
    sticky = zT_82;
    goto z_bb_32;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    if ((unsigned char)(i < (unsigned int)(8))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_88 = i + word;
    idx = zT_88;
    zT_90 = 0;
    lo = zT_90;
    zT_91 = a.len;
    if ((unsigned char)(idx < (unsigned int)((unsigned int)zT_91))) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    out->len = (unsigned char)(8);
    out->neg = (unsigned char)(0);
    zT_128 = out;
    zF_390E9E58_ciNormalize(zT_128);
    zT_129 = a.neg;
    if (zT_129) goto z_bb_44; else goto z_bb_45;
    z_bb_36:
    zT_123 = 1;
    zT_125 = i + (unsigned int)((unsigned int)zT_123);
    i = zT_125;
    goto z_bb_33;
    z_bb_37:
    zT_94 = a.mag;
    zT_95 = zT_94[idx];
    zT_98 = (zT_79FAE712_u64)((zT_79FAE712_u64)zT_95) >> (zT_79FAE712_u64)((zT_79FAE712_u64)bits);
    lo = zT_98;
    goto z_bb_38;
    z_bb_38:
    zT_100 = 0;
    hi = zT_100;
    if ((unsigned char)(bits > (unsigned int)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_104 = 1;
    zT_106 = a.len;
    zT_103 = (unsigned int)(idx + zT_104) < (unsigned int)((unsigned int)zT_106);
    goto z_bb_41;
    z_bb_40:
    zT_103 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_103) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_109 = a.mag;
    zT_110 = 1;
    zT_111 = idx + zT_110;
    zT_112 = zT_109[zT_111];
    zT_114 = 32;
    zT_117 = (zT_79FAE712_u64)((zT_79FAE712_u64)zT_112) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(zT_114 - bits));
    hi = zT_117;
    goto z_bb_43;
    z_bb_43:
    zT_121 = (unsigned int)(zT_79FAE712_u64)((zT_79FAE712_u64)(lo | hi) & (zT_79FAE712_u64)(4294967295u));
    zT_122 = out->mag;
    zT_122[i] = zT_121;
    goto z_bb_36;
    z_bb_44:
    if (sticky) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    return (unsigned char)(1);
    z_bb_46:
    zT_131 = 1;
    carry = zT_131;
    zT_133 = 0;
    zT_134 = (unsigned int)zT_133;
    k2 = zT_134;
    goto z_bb_48;
    z_bb_47:
    zT_159 = out->len;
    if ((unsigned char)(zT_159 != (unsigned char)(0))) goto z_bb_56; else goto z_bb_57;
    z_bb_48:
    if ((unsigned char)(k2 < (unsigned int)(8))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_138 = out->mag;
    zT_139 = zT_138[k2];
    zT_141 = (zT_79FAE712_u64)((zT_79FAE712_u64)zT_139) + carry;
    s = zT_141;
    zT_144 = (unsigned int)(zT_79FAE712_u64)(s & (zT_79FAE712_u64)(4294967295u));
    zT_145 = out->mag;
    zT_145[k2] = zT_144;
    zT_147 = s >> (zT_79FAE712_u64)(32);
    carry = zT_147;
    if ((unsigned char)(carry == (zT_79FAE712_u64)(0))) goto z_bb_52; else goto z_bb_53;
    z_bb_50:
    if ((unsigned char)(carry != (zT_79FAE712_u64)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_51:
    zT_151 = 1;
    zT_153 = k2 + (unsigned int)((unsigned int)zT_151);
    k2 = zT_153;
    goto z_bb_48;
    z_bb_52:
    zT_150 = 8;
    k2 = zT_150;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_51;
    z_bb_54:
    return (unsigned char)(0);
    z_bb_55:
    out->len = (unsigned char)(8);
    zT_158 = out;
    zF_390E9E58_ciNormalize(zT_158);
    goto z_bb_47;
    z_bb_56:
    out->neg = (unsigned char)(1);
    goto z_bb_57;
    z_bb_57:
    goto z_bb_45;
}

/* comptimeEvalBinOp */
zT_E53A25A2_Opt_203 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_E53A25A2_Opt_203 zT_14 = {0};
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_E53A25A2_Opt_203 zT_20 = {0};
    unsigned char zT_21;
    unsigned char zT_23;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_29;
    zT_E53A25A2_Opt_203 zT_32 = {0};
    unsigned int zT_34;
    zT_DA663F79_ComptimeEval* zT_36;
    unsigned int zT_37;
    zT_BAEE192E_Opt_10 zT_39 = {0};
    zT_DA663F79_ComptimeEval* zT_41;
    unsigned int zT_42;
    zT_BAEE192E_Opt_10 zT_44 = {0};
    unsigned char zT_45;
    unsigned char zT_47;
    zT_DA663F79_ComptimeEval* zT_49;
    unsigned int zT_50;
    unsigned int zT_51;
    unsigned int zT_52 = 0;
    unsigned char zT_53;
    unsigned char zT_57;
    zT_338B7C76_TypeRegistry* zT_59;
    zT_0163D9A4_ComptimeInt zT_60;
    unsigned int zT_61;
    zT_0163D9A4_ComptimeInt zT_63;
    unsigned char zT_64 = 0;
    zT_E53A25A2_Opt_203 zT_66 = {0};
    unsigned char zT_67;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_0163D9A4_ComptimeInt zT_70;
    unsigned int zT_71;
    zT_0163D9A4_ComptimeInt zT_73;
    unsigned char zT_74 = 0;
    zT_E53A25A2_Opt_203 zT_76 = {0};
    zT_0163D9A4_ComptimeInt zT_78 = {0};
    zT_0163D9A4_ComptimeInt zT_82;
    zT_0163D9A4_ComptimeInt zT_83;
    zT_0163D9A4_ComptimeInt* zT_84;
    zT_0163D9A4_ComptimeInt zT_85;
    zT_0163D9A4_ComptimeInt zT_86;
    unsigned char zT_88 = 0;
    zT_E53A25A2_Opt_203 zT_90 = {0};
    zT_0163D9A4_ComptimeInt zT_94;
    zT_0163D9A4_ComptimeInt zT_95;
    zT_0163D9A4_ComptimeInt* zT_96;
    zT_0163D9A4_ComptimeInt zT_97;
    zT_0163D9A4_ComptimeInt zT_98;
    unsigned char zT_100 = 0;
    zT_E53A25A2_Opt_203 zT_102 = {0};
    zT_0163D9A4_ComptimeInt zT_106;
    zT_0163D9A4_ComptimeInt zT_107;
    zT_0163D9A4_ComptimeInt* zT_108;
    zT_0163D9A4_ComptimeInt zT_109;
    zT_0163D9A4_ComptimeInt zT_110;
    unsigned char zT_112 = 0;
    zT_E53A25A2_Opt_203 zT_114 = {0};
    zT_0163D9A4_ComptimeInt zT_119 = {0};
    zT_0163D9A4_ComptimeInt zT_120;
    zT_0163D9A4_ComptimeInt zT_121;
    zT_0163D9A4_ComptimeInt* zT_122;
    zT_0163D9A4_ComptimeInt* zT_123;
    zT_0163D9A4_ComptimeInt zT_124;
    zT_0163D9A4_ComptimeInt zT_125;
    unsigned char zT_128 = 0;
    zT_E53A25A2_Opt_203 zT_130 = {0};
    zT_0163D9A4_ComptimeInt zT_135 = {0};
    zT_0163D9A4_ComptimeInt zT_136;
    zT_0163D9A4_ComptimeInt zT_137;
    zT_0163D9A4_ComptimeInt* zT_138;
    zT_0163D9A4_ComptimeInt* zT_139;
    zT_0163D9A4_ComptimeInt zT_140;
    zT_0163D9A4_ComptimeInt zT_141;
    unsigned char zT_144 = 0;
    zT_E53A25A2_Opt_203 zT_146 = {0};
    zT_0163D9A4_ComptimeInt zT_150;
    zT_0163D9A4_ComptimeInt zT_151;
    zT_0163D9A4_ComptimeInt* zT_152;
    zT_0163D9A4_ComptimeInt zT_153;
    zT_0163D9A4_ComptimeInt zT_154;
    unsigned char zT_156 = 0;
    zT_E53A25A2_Opt_203 zT_158 = {0};
    zT_0163D9A4_ComptimeInt zT_162;
    zT_0163D9A4_ComptimeInt zT_163;
    zT_0163D9A4_ComptimeInt* zT_164;
    zT_0163D9A4_ComptimeInt zT_165;
    zT_0163D9A4_ComptimeInt zT_166;
    unsigned char zT_168 = 0;
    zT_E53A25A2_Opt_203 zT_170 = {0};
    zT_0163D9A4_ComptimeInt zT_174;
    zT_0163D9A4_ComptimeInt zT_175;
    zT_0163D9A4_ComptimeInt* zT_176;
    zT_0163D9A4_ComptimeInt zT_177;
    zT_0163D9A4_ComptimeInt zT_178;
    unsigned char zT_180 = 0;
    zT_E53A25A2_Opt_203 zT_182 = {0};
    zT_0163D9A4_ComptimeInt zT_186;
    zT_0163D9A4_ComptimeInt zT_187;
    zT_0163D9A4_ComptimeInt* zT_188;
    zT_0163D9A4_ComptimeInt zT_189;
    zT_0163D9A4_ComptimeInt zT_190;
    unsigned char zT_192 = 0;
    zT_E53A25A2_Opt_203 zT_194 = {0};
    zT_0163D9A4_ComptimeInt zT_198;
    zT_0163D9A4_ComptimeInt zT_199;
    zT_0163D9A4_ComptimeInt* zT_200;
    zT_0163D9A4_ComptimeInt zT_201;
    zT_0163D9A4_ComptimeInt zT_202;
    unsigned char zT_204 = 0;
    zT_E53A25A2_Opt_203 zT_206 = {0};
    zT_E53A25A2_Opt_203 zT_207 = {0};
    zT_338B7C76_TypeRegistry* zT_210;
    zT_0163D9A4_ComptimeInt zT_211;
    unsigned int zT_212;
    unsigned char zT_214 = 0;
    zT_E53A25A2_Opt_203 zT_216 = {0};
    zT_0163D9A4_ComptimeInt zT_217;
    zT_89B1DDDA_ComptimeVal zT_218 = {0};
    zT_E53A25A2_Opt_203 zT_219;
    zT_E53A25A2_Opt_203 zT_220 = {0};
    zT_22A7C88B_AstNode node;
    zT_E53A25A2_Opt_203 lhs;
    zT_E53A25A2_Opt_203 rhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_89B1DDDA_ComptimeVal r;
    unsigned int peer_tid;
    zT_BAEE192E_Opt_10 lt;
    zT_BAEE192E_Opt_10 rt;
    unsigned int lti;
    unsigned int rti;
    unsigned int rti2;
    zT_0163D9A4_ComptimeInt res;
    zT_0163D9A4_ComptimeInt rem;
    zT_0163D9A4_ComptimeInt q2;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    zT_16 = self;
    zT_17 = node.child_1;
    zT_18 = depth;
    zT_20 = zF_4EE17137_comptimeEvalEvaluat(zT_16, zT_17, zT_18);
    rhs = zT_20;
    zT_21 = lhs.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    l = lhs.value;
    zT_23 = rhs.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_220.has_value = 0;
    return zT_220;
    z_bb_3:
    r = rhs.value;
    zT_25 = l.kind;
    if ((unsigned char)(zT_25 != (unsigned int)(0))) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_29 = r.kind;
    zT_28 = zT_29 != (unsigned int)(0);
    goto z_bb_7;
    z_bb_6:
    zT_28 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_28) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_9:
    zT_34 = 0;
    peer_tid = zT_34;
    zT_36 = self;
    zT_37 = node.child_0;
    zT_39 = zF_6B810D4A_comptimeEvalOperand(zT_36, zT_37);
    lt = zT_39;
    zT_41 = self;
    zT_42 = node.child_1;
    zT_44 = zF_6B810D4A_comptimeEvalOperand(zT_41, zT_42);
    rt = zT_44;
    zT_45 = lt.has_value;
    if (zT_45) goto z_bb_10; else goto z_bb_12;
    z_bb_10:
    lti = lt.value;
    zT_47 = rt.has_value;
    if (zT_47) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    if ((unsigned char)(peer_tid != (unsigned int)(0))) goto z_bb_18; else goto z_bb_19;
    z_bb_12:
    zT_53 = rt.has_value;
    if (zT_53) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    rti = rt.value;
    zT_49 = self;
    zT_50 = lti;
    zT_51 = rti;
    zT_52 = zF_CE5A812D_comptimeEvalWiderIn(zT_49, zT_50, zT_51);
    peer_tid = zT_52;
    goto z_bb_14;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    peer_tid = lti;
    goto z_bb_14;
    z_bb_16:
    rti2 = rt.value;
    peer_tid = rti2;
    goto z_bb_17;
    z_bb_17:
    goto z_bb_11;
    z_bb_18:
    zT_57 = lt.has_value;
    if ((unsigned char)(!zT_57)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_78 = zF_DC9B7BC0_ciZeroInt();
    res = zT_78;
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_28; else goto z_bb_30;
    z_bb_20:
    zT_59 = self->registry;
    zT_63 = l.v;
    zT_60 = zT_63;
    zT_61 = peer_tid;
    zT_64 = zF_B28C4720_comptimeIntFitsType(zT_59, zT_60, zT_61);
    if ((unsigned char)(!zT_64)) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_67 = rt.has_value;
    if ((unsigned char)(!zT_67)) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    zT_66.has_value = 0;
    return zT_66;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_69 = self->registry;
    zT_73 = r.v;
    zT_70 = zT_73;
    zT_71 = peer_tid;
    zT_74 = zF_B28C4720_comptimeIntFitsType(zT_69, zT_70, zT_71);
    if ((unsigned char)(!zT_74)) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_19;
    z_bb_26:
    zT_76.has_value = 0;
    return zT_76;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    zT_85 = l.v;
    zT_82 = zT_85;
    zT_86 = r.v;
    zT_83 = zT_86;
    zT_84 = &res;
    zT_88 = zF_8A5DB878_ciAdd(zT_82, zT_83, zT_84);
    if ((unsigned char)(!zT_88)) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    if ((unsigned char)(peer_tid != (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_30:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_33; else goto z_bb_35;
    z_bb_31:
    zT_90.has_value = 0;
    return zT_90;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_97 = l.v;
    zT_94 = zT_97;
    zT_98 = r.v;
    zT_95 = zT_98;
    zT_96 = &res;
    zT_100 = zF_539A2D81_ciSub(zT_94, zT_95, zT_96);
    if ((unsigned char)(!zT_100)) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_29;
    z_bb_35:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_38; else goto z_bb_40;
    z_bb_36:
    zT_102.has_value = 0;
    return zT_102;
    z_bb_37:
    goto z_bb_34;
    z_bb_38:
    zT_109 = l.v;
    zT_106 = zT_109;
    zT_110 = r.v;
    zT_107 = zT_110;
    zT_108 = &res;
    zT_112 = zF_A3E385DD_ciMul(zT_106, zT_107, zT_108);
    if ((unsigned char)(!zT_112)) goto z_bb_41; else goto z_bb_42;
    z_bb_39:
    goto z_bb_34;
    z_bb_40:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_43; else goto z_bb_45;
    z_bb_41:
    zT_114.has_value = 0;
    return zT_114;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_119 = zF_DC9B7BC0_ciZeroInt();
    rem = zT_119;
    zT_124 = l.v;
    zT_120 = zT_124;
    zT_125 = r.v;
    zT_121 = zT_125;
    zT_122 = &res;
    zT_123 = &rem;
    zT_128 = zF_25A0EEC0_ciDivMod(zT_120, zT_121, zT_122, zT_123);
    if ((unsigned char)(!zT_128)) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_39;
    z_bb_45:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op))) goto z_bb_48; else goto z_bb_50;
    z_bb_46:
    zT_130.has_value = 0;
    return zT_130;
    z_bb_47:
    goto z_bb_44;
    z_bb_48:
    zT_135 = zF_DC9B7BC0_ciZeroInt();
    q2 = zT_135;
    zT_140 = l.v;
    zT_136 = zT_140;
    zT_141 = r.v;
    zT_137 = zT_141;
    zT_138 = &q2;
    zT_139 = &res;
    zT_144 = zF_25A0EEC0_ciDivMod(zT_136, zT_137, zT_138, zT_139);
    if ((unsigned char)(!zT_144)) goto z_bb_51; else goto z_bb_52;
    z_bb_49:
    goto z_bb_44;
    z_bb_50:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_53; else goto z_bb_55;
    z_bb_51:
    zT_146.has_value = 0;
    return zT_146;
    z_bb_52:
    goto z_bb_49;
    z_bb_53:
    zT_153 = l.v;
    zT_150 = zT_153;
    zT_154 = r.v;
    zT_151 = zT_154;
    zT_152 = &res;
    zT_156 = zF_E15DE14D_ciBitAnd(zT_150, zT_151, zT_152);
    if ((unsigned char)(!zT_156)) goto z_bb_56; else goto z_bb_57;
    z_bb_54:
    goto z_bb_49;
    z_bb_55:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or))) goto z_bb_58; else goto z_bb_60;
    z_bb_56:
    zT_158.has_value = 0;
    return zT_158;
    z_bb_57:
    goto z_bb_54;
    z_bb_58:
    zT_165 = l.v;
    zT_162 = zT_165;
    zT_166 = r.v;
    zT_163 = zT_166;
    zT_164 = &res;
    zT_168 = zF_93823331_ciBitOr(zT_162, zT_163, zT_164);
    if ((unsigned char)(!zT_168)) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    goto z_bb_54;
    z_bb_60:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor))) goto z_bb_63; else goto z_bb_65;
    z_bb_61:
    zT_170.has_value = 0;
    return zT_170;
    z_bb_62:
    goto z_bb_59;
    z_bb_63:
    zT_177 = l.v;
    zT_174 = zT_177;
    zT_178 = r.v;
    zT_175 = zT_178;
    zT_176 = &res;
    zT_180 = zF_C592CA21_ciBitXor(zT_174, zT_175, zT_176);
    if ((unsigned char)(!zT_180)) goto z_bb_66; else goto z_bb_67;
    z_bb_64:
    goto z_bb_59;
    z_bb_65:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl))) goto z_bb_68; else goto z_bb_70;
    z_bb_66:
    zT_182.has_value = 0;
    return zT_182;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_189 = l.v;
    zT_186 = zT_189;
    zT_190 = r.v;
    zT_187 = zT_190;
    zT_188 = &res;
    zT_192 = zF_4FDD0D22_ciShl(zT_186, zT_187, zT_188);
    if ((unsigned char)(!zT_192)) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    goto z_bb_64;
    z_bb_70:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr))) goto z_bb_73; else goto z_bb_75;
    z_bb_71:
    zT_194.has_value = 0;
    return zT_194;
    z_bb_72:
    goto z_bb_69;
    z_bb_73:
    zT_201 = l.v;
    zT_198 = zT_201;
    zT_202 = r.v;
    zT_199 = zT_202;
    zT_200 = &res;
    zT_204 = zF_41DCF718_ciShr(zT_198, zT_199, zT_200);
    if ((unsigned char)(!zT_204)) goto z_bb_76; else goto z_bb_77;
    z_bb_74:
    goto z_bb_69;
    z_bb_75:
    zT_207.has_value = 0;
    return zT_207;
    z_bb_76:
    zT_206.has_value = 0;
    return zT_206;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_210 = self->registry;
    zT_211 = res;
    zT_212 = peer_tid;
    zT_214 = zF_B28C4720_comptimeIntFitsType(zT_210, zT_211, zT_212);
    if ((unsigned char)(!zT_214)) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    zT_217 = res;
    zT_218 = zF_237A4571_ciIntVal(zT_217);
    zT_219.has_value = 1;
    zT_219.value = zT_218;
    return zT_219;
    z_bb_80:
    zT_216.has_value = 0;
    return zT_216;
    z_bb_81:
    goto z_bb_79;
}

/* comptimeEvalCompare */
zT_E53A25A2_Opt_203 zF_CD4BD838_comptimeEvalCompare(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_E53A25A2_Opt_203 zT_14 = {0};
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_E53A25A2_Opt_203 zT_20 = {0};
    unsigned char zT_21;
    unsigned char zT_23;
    unsigned char zT_25;
    unsigned char zT_28;
    unsigned char zT_29;
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    zT_0163D9A4_ComptimeInt zT_35;
    zT_0163D9A4_ComptimeInt zT_36;
    int zT_37 = 0;
    unsigned char zT_39;
    unsigned char zT_44;
    unsigned char zT_49;
    unsigned char zT_54;
    unsigned char zT_59;
    unsigned char zT_64;
    unsigned char zT_69;
    unsigned char zT_70;
    zT_89B1DDDA_ComptimeVal zT_71 = {0};
    zT_E53A25A2_Opt_203 zT_72;
    zT_DA663F79_ComptimeEval* zT_73;
    unsigned int zT_74;
    zT_8143F551_AstKind zT_75;
    unsigned int zT_76;
    zT_E53A25A2_Opt_203 zT_77 = {0};
    zT_22A7C88B_AstNode node;
    zT_E53A25A2_Opt_203 lhs;
    zT_E53A25A2_Opt_203 rhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_89B1DDDA_ComptimeVal r;
    int c;
    unsigned char res;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    zT_16 = self;
    zT_17 = node.child_1;
    zT_18 = depth;
    zT_20 = zF_4EE17137_comptimeEvalEvaluat(zT_16, zT_17, zT_18);
    rhs = zT_20;
    zT_21 = lhs.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    l = lhs.value;
    zT_23 = rhs.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_73 = self;
    zT_74 = node_idx;
    zT_75 = op_kind;
    zT_76 = depth;
    zT_77 = zF_2B224602_comptimeEvalCompare(zT_73, zT_74, zT_75, zT_76);
    return zT_77;
    z_bb_3:
    r = rhs.value;
    zT_25 = l.kind;
    if ((unsigned char)(zT_25 != (unsigned int)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_29 = r.kind;
    zT_28 = zT_29 != (unsigned int)(2);
    goto z_bb_7;
    z_bb_6:
    zT_28 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_28) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_35 = l.v;
    zT_33 = zT_35;
    zT_36 = r.v;
    zT_34 = zT_36;
    zT_37 = zF_6408F093_ciCmp(zT_33, zT_34);
    c = zT_37;
    zT_39 = 0;
    res = zT_39;
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_44 = c == (int)(0);
    res = zT_44;
    goto z_bb_11;
    z_bb_11:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_49 = c != (int)(0);
    res = zT_49;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_54 = c < (int)(0);
    res = zT_54;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_59 = c <= (int)(0);
    res = zT_59;
    goto z_bb_17;
    z_bb_17:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_64 = c > (int)(0);
    res = zT_64;
    goto z_bb_19;
    z_bb_19:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_69 = c >= (int)(0);
    res = zT_69;
    goto z_bb_21;
    z_bb_21:
    zT_70 = res;
    zT_71 = zF_E867E750_ciBoolVal(zT_70);
    zT_72.has_value = 1;
    zT_72.value = zT_71;
    return zT_72;
}

/* comptimeEvalCompareFloat */
zT_E53A25A2_Opt_203 zF_2B224602_comptimeEvalCompare(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_E23A20E9_Opt_206 zT_14 = {0};
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_E23A20E9_Opt_206 zT_20 = {0};
    unsigned char zT_21;
    unsigned char zT_23;
    unsigned char zT_25;
    unsigned char zT_27;
    unsigned char zT_28;
    zT_E53A25A2_Opt_203 zT_30 = {0};
    unsigned char zT_31;
    unsigned char zT_33;
    unsigned char zT_34;
    zT_E53A25A2_Opt_203 zT_36 = {0};
    unsigned char zT_37;
    unsigned char zT_38;
    zT_E53A25A2_Opt_203 zT_40 = {0};
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned int zT_44;
    unsigned char zT_47;
    unsigned char zT_48;
    unsigned char zT_49;
    unsigned int zT_50;
    unsigned char zT_54;
    unsigned char zT_55;
    unsigned int zT_56;
    unsigned char zT_59;
    unsigned char zT_60;
    unsigned char zT_61;
    unsigned int zT_62;
    unsigned char zT_65;
    unsigned char zT_67;
    unsigned char zT_69;
    unsigned int zT_70;
    zT_E53A25A2_Opt_203 zT_73 = {0};
    unsigned char zT_74;
    unsigned char zT_76;
    unsigned int zT_77;
    zT_E53A25A2_Opt_203 zT_80 = {0};
    unsigned char zT_81;
    unsigned char zT_82;
    unsigned int zT_83;
    unsigned char zT_86;
    zT_00435AEB_f64 zT_87;
    unsigned char zT_89 = 0;
    zT_E53A25A2_Opt_203 zT_91 = {0};
    unsigned char zT_92;
    unsigned char zT_93;
    unsigned int zT_94;
    unsigned char zT_97;
    zT_00435AEB_f64 zT_98;
    unsigned char zT_100 = 0;
    zT_E53A25A2_Opt_203 zT_102 = {0};
    unsigned char zT_103;
    unsigned char zT_105;
    unsigned int zT_106;
    zT_E53A25A2_Opt_203 zT_109 = {0};
    unsigned char zT_110;
    unsigned char zT_112;
    unsigned int zT_113;
    zT_E53A25A2_Opt_203 zT_116 = {0};
    zT_00435AEB_f64 zT_118;
    zT_00435AEB_f64 zT_120;
    unsigned char zT_122;
    unsigned char zT_126;
    unsigned char zT_130;
    unsigned char zT_134;
    unsigned char zT_138;
    unsigned char zT_142;
    unsigned char zT_146;
    unsigned char zT_147;
    zT_89B1DDDA_ComptimeVal zT_148 = {0};
    zT_E53A25A2_Opt_203 zT_149;
    zT_E53A25A2_Opt_203 zT_150 = {0};
    zT_22A7C88B_AstNode node;
    zT_E23A20E9_Opt_206 lop;
    zT_E23A20E9_Opt_206 rop;
    zT_FCC4E7FC_CmpFloatOperand l;
    zT_FCC4E7FC_CmpFloatOperand r;
    unsigned char has_f64;
    unsigned char has_f32;
    zT_00435AEB_f64 lv;
    zT_00435AEB_f64 rv;
    unsigned char res;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_9324B6D5_comptimeEvalCompare(zT_10, zT_11, zT_12);
    lop = zT_14;
    zT_16 = self;
    zT_17 = node.child_1;
    zT_18 = depth;
    zT_20 = zF_9324B6D5_comptimeEvalCompare(zT_16, zT_17, zT_18);
    rop = zT_20;
    zT_21 = lop.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    l = lop.value;
    zT_23 = rop.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_150.has_value = 0;
    return zT_150;
    z_bb_3:
    r = rop.value;
    zT_25 = l.ok;
    if ((unsigned char)(!zT_25)) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_28 = r.ok;
    zT_27 = !zT_28;
    goto z_bb_7;
    z_bb_6:
    zT_27 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_27) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30.has_value = 0;
    return zT_30;
    z_bb_9:
    zT_31 = l.is_float;
    if ((unsigned char)(!zT_31)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_34 = r.is_float;
    zT_33 = !zT_34;
    goto z_bb_12;
    z_bb_11:
    zT_33 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_33) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_36.has_value = 0;
    return zT_36;
    z_bb_14:
    zT_37 = l.is_bool;
    if (zT_37) goto z_bb_16; else goto z_bb_15;
    z_bb_15:
    zT_38 = r.is_bool;
    goto z_bb_17;
    z_bb_16:
    zT_38 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_38) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_40.has_value = 0;
    return zT_40;
    z_bb_19:
    zT_42 = l.is_float;
    if (zT_42) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_44 = l.ftype;
    zT_43 = zT_44 == (unsigned int)(16);
    goto z_bb_22;
    z_bb_21:
    zT_43 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_43) goto z_bb_24; else goto z_bb_23;
    z_bb_23:
    zT_48 = r.is_float;
    if (zT_48) goto z_bb_26; else goto z_bb_27;
    z_bb_24:
    zT_47 = 1;
    goto z_bb_25;
    z_bb_25:
    has_f64 = zT_47;
    zT_54 = l.is_float;
    if (zT_54) goto z_bb_29; else goto z_bb_30;
    z_bb_26:
    zT_50 = r.ftype;
    zT_49 = zT_50 == (unsigned int)(16);
    goto z_bb_28;
    z_bb_27:
    zT_49 = 0;
    goto z_bb_28;
    z_bb_28:
    zT_47 = zT_49;
    goto z_bb_25;
    z_bb_29:
    zT_56 = l.ftype;
    zT_55 = zT_56 == (unsigned int)(15);
    goto z_bb_31;
    z_bb_30:
    zT_55 = 0;
    goto z_bb_31;
    z_bb_31:
    if (zT_55) goto z_bb_33; else goto z_bb_32;
    z_bb_32:
    zT_60 = r.is_float;
    if (zT_60) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    zT_59 = 1;
    goto z_bb_34;
    z_bb_34:
    has_f32 = zT_59;
    if (has_f64) goto z_bb_39; else goto z_bb_38;
    z_bb_35:
    zT_62 = r.ftype;
    zT_61 = zT_62 == (unsigned int)(15);
    goto z_bb_37;
    z_bb_36:
    zT_61 = 0;
    goto z_bb_37;
    z_bb_37:
    zT_59 = zT_61;
    goto z_bb_34;
    z_bb_38:
    zT_65 = !has_f32;
    goto z_bb_40;
    z_bb_39:
    zT_65 = 1;
    goto z_bb_40;
    z_bb_40:
    if (zT_65) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    zT_67 = l.is_float;
    if ((unsigned char)(!zT_67)) goto z_bb_44; else goto z_bb_45;
    z_bb_42:
    zT_118 = l.fval;
    lv = zT_118;
    zT_120 = r.fval;
    rv = zT_120;
    zT_122 = 0;
    res = zT_122;
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_80; else goto z_bb_81;
    z_bb_43:
    zT_81 = l.is_float;
    if (zT_81) goto z_bb_54; else goto z_bb_55;
    z_bb_44:
    zT_70 = l.sig_bits;
    zT_69 = zT_70 > (unsigned int)(53);
    goto z_bb_46;
    z_bb_45:
    zT_69 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_69) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_73.has_value = 0;
    return zT_73;
    z_bb_48:
    zT_74 = r.is_float;
    if ((unsigned char)(!zT_74)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_77 = r.sig_bits;
    zT_76 = zT_77 > (unsigned int)(53);
    goto z_bb_51;
    z_bb_50:
    zT_76 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_76) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_80.has_value = 0;
    return zT_80;
    z_bb_53:
    goto z_bb_42;
    z_bb_54:
    zT_83 = l.ftype;
    zT_82 = zT_83 == (unsigned int)(0);
    goto z_bb_56;
    z_bb_55:
    zT_82 = 0;
    goto z_bb_56;
    z_bb_56:
    if (zT_82) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_87 = l.fval;
    zT_89 = zF_173AF805_comptimeEvalF64IsF3(zT_87);
    zT_86 = !zT_89;
    goto z_bb_59;
    z_bb_58:
    zT_86 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_86) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_91.has_value = 0;
    return zT_91;
    z_bb_61:
    zT_92 = r.is_float;
    if (zT_92) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_94 = r.ftype;
    zT_93 = zT_94 == (unsigned int)(0);
    goto z_bb_64;
    z_bb_63:
    zT_93 = 0;
    goto z_bb_64;
    z_bb_64:
    if (zT_93) goto z_bb_65; else goto z_bb_66;
    z_bb_65:
    zT_98 = r.fval;
    zT_100 = zF_173AF805_comptimeEvalF64IsF3(zT_98);
    zT_97 = !zT_100;
    goto z_bb_67;
    z_bb_66:
    zT_97 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_97) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_102.has_value = 0;
    return zT_102;
    z_bb_69:
    zT_103 = l.is_float;
    if ((unsigned char)(!zT_103)) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_106 = l.sig_bits;
    zT_105 = zT_106 > (unsigned int)(24);
    goto z_bb_72;
    z_bb_71:
    zT_105 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_105) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_109.has_value = 0;
    return zT_109;
    z_bb_74:
    zT_110 = r.is_float;
    if ((unsigned char)(!zT_110)) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_113 = r.sig_bits;
    zT_112 = zT_113 > (unsigned int)(24);
    goto z_bb_77;
    z_bb_76:
    zT_112 = 0;
    goto z_bb_77;
    z_bb_77:
    if (zT_112) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_116.has_value = 0;
    return zT_116;
    z_bb_79:
    goto z_bb_42;
    z_bb_80:
    zT_126 = lv == rv;
    res = zT_126;
    goto z_bb_81;
    z_bb_81:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne))) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_130 = lv != rv;
    res = zT_130;
    goto z_bb_83;
    z_bb_83:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt))) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_134 = lv < rv;
    res = zT_134;
    goto z_bb_85;
    z_bb_85:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le))) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_138 = lv <= rv;
    res = zT_138;
    goto z_bb_87;
    z_bb_87:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt))) goto z_bb_88; else goto z_bb_89;
    z_bb_88:
    zT_142 = lv > rv;
    res = zT_142;
    goto z_bb_89;
    z_bb_89:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge))) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_146 = lv >= rv;
    res = zT_146;
    goto z_bb_91;
    z_bb_91:
    zT_147 = res;
    zT_148 = zF_E867E750_ciBoolVal(zT_147);
    zT_149.has_value = 1;
    zT_149.value = zT_148;
    return zT_149;
}

/* comptimeEvalCompareOperand */
zT_E23A20E9_Opt_206 zF_9324B6D5_comptimeEvalCompare(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_FCC4E7FC_CmpFloatOperand zT_4;
    unsigned char zT_5;
    unsigned char zT_6;
    unsigned char zT_7;
    unsigned int zT_8;
    zT_00435AEB_f64 zT_9;
    unsigned int zT_10;
    zT_DA663F79_ComptimeEval* zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_E53A25A2_Opt_203 zT_14 = {0};
    unsigned char zT_15;
    unsigned char zT_17;
    zT_DA663F79_ComptimeEval* zT_22;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    zT_89B1DDDA_ComptimeVal zT_25;
    zT_00435AEB_f64 zT_26 = 0;
    zT_E23A20E9_Opt_206 zT_27;
    unsigned char zT_28;
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    unsigned char zT_35 = 0;
    zT_E23A20E9_Opt_206 zT_38;
    zT_0163D9A4_ComptimeInt zT_40;
    zT_0163D9A4_ComptimeInt zT_41;
    unsigned int zT_42 = 0;
    zT_0163D9A4_ComptimeInt zT_43;
    zT_0163D9A4_ComptimeInt zT_44;
    zT_00435AEB_f64 zT_45 = 0;
    zT_E23A20E9_Opt_206 zT_46;
    zT_DA663F79_ComptimeEval* zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_BCEE1C54_Opt_16 zT_50 = {0};
    unsigned char zT_51;
    zT_DA663F79_ComptimeEval* zT_55;
    unsigned int zT_56;
    unsigned int zT_57 = 0;
    zT_E23A20E9_Opt_206 zT_58;
    zT_FCC4E7FC_CmpFloatOperand op;
    zT_89B1DDDA_ComptimeVal cv;
    zT_00435AEB_f64 fv;
    zT_5 = 0;
    zT_4.ok = zT_5;
    zT_6 = 0;
    zT_4.is_float = zT_6;
    zT_7 = 0;
    zT_4.is_bool = zT_7;
    zT_8 = 0;
    zT_4.ftype = zT_8;
    zT_9 = 0;
    zT_4.fval = zT_9;
    zT_10 = 0;
    zT_4.sig_bits = zT_10;
    op = zT_4;
    zT_11 = self;
    zT_12 = node_idx;
    zT_13 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_11, zT_12, zT_13);
    zT_15 = zT_14.has_value;
    if (zT_15) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    cv = zT_14.value;
    zT_17 = cv.kind;
    if ((unsigned char)(zT_17 == (unsigned int)(2))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_47 = self;
    zT_48 = node_idx;
    zT_49 = depth;
    zT_50 = zF_B719EB81_comptimeEvalFloat(zT_47, zT_48, zT_49);
    zT_51 = zT_50.has_value;
    if (zT_51) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    op.ok = (unsigned char)(1);
    op.is_float = (unsigned char)(1);
    zT_22 = self;
    zT_23 = node_idx;
    zT_24 = zF_70E6C6F2_comptimeEvalFloatOp(zT_22, zT_23);
    op.ftype = zT_24;
    zT_25 = cv;
    zT_26 = zF_9DD4606D_comptimeEvalFloatBi(zT_25);
    op.fval = zT_26;
    zT_27.has_value = 1;
    zT_27.value = op;
    return zT_27;
    z_bb_4:
    zT_28 = cv.kind;
    if ((unsigned char)(zT_28 == (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    op.ok = (unsigned char)(1);
    op.is_bool = (unsigned char)(1);
    zT_34 = cv.v;
    zT_33 = zT_34;
    zT_35 = zF_0F5FA15F_ciIsZero(zT_33);
    if ((unsigned char)(!zT_35)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    op.ok = (unsigned char)(1);
    zT_41 = cv.v;
    zT_40 = zT_41;
    zT_42 = zF_4372148C_ciSignificantBits(zT_40);
    op.sig_bits = zT_42;
    zT_44 = cv.v;
    zT_43 = zT_44;
    zT_45 = zF_E6CE9168_ciToF64(zT_43);
    op.fval = zT_45;
    zT_46.has_value = 1;
    zT_46.value = op;
    return zT_46;
    z_bb_7:
    op.fval = (zT_00435AEB_f64)(1e+0);
    goto z_bb_8;
    z_bb_8:
    zT_38.has_value = 1;
    zT_38.value = op;
    return zT_38;
    z_bb_9:
    fv = zT_50.value;
    op.ok = (unsigned char)(1);
    op.is_float = (unsigned char)(1);
    zT_55 = self;
    zT_56 = node_idx;
    zT_57 = zF_70E6C6F2_comptimeEvalFloatOp(zT_55, zT_56);
    op.ftype = zT_57;
    op.fval = fv;
    goto z_bb_10;
    z_bb_10:
    zT_58.has_value = 1;
    zT_58.value = op;
    return zT_58;
}

/* comptimeEvalFloatBits */
zT_00435AEB_f64 zF_9DD4606D_comptimeEvalFloatBi(zT_89B1DDDA_ComptimeVal cv) {
    zT_79FAE712_u64 zT_2;
    zT_79FAE712_u64* zT_4;
    zT_00435AEB_f64* zT_5;
    zT_00435AEB_f64 zT_6;
    zT_79FAE712_u64 fb;
    zT_00435AEB_f64* fp;
    zT_2 = cv.float_bits;
    fb = zT_2;
    zT_4 = &fb;
    zT_5 = (zT_00435AEB_f64*)zT_4;
    fp = zT_5;
    zT_6 = *fp;
    return zT_6;
}

/* ciSignificantBits */
unsigned int zF_4372148C_ciSignificantBits(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    unsigned char zT_6;
    unsigned int zT_11;
    unsigned int* zT_13;
    unsigned char zT_14;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned int zT_26;
    unsigned char zT_28;
    unsigned char zT_29;
    unsigned int* zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    unsigned int zT_38;
    unsigned int zT_44;
    unsigned int zT_46;
    unsigned char zT_49;
    unsigned int bits;
    unsigned int top;
    unsigned int tz;
    unsigned char i;
    unsigned int limb;
    zT_1 = v.len;
    if ((unsigned char)(zT_1 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = v.len;
    zT_11 = (unsigned int)((unsigned int)(unsigned char)(zT_6 - (unsigned char)(1))) * (unsigned int)(32);
    bits = zT_11;
    zT_13 = v.mag;
    zT_14 = v.len;
    zT_17 = (unsigned int)(unsigned char)(zT_14 - (unsigned char)(1));
    zT_18 = zT_13[zT_17];
    top = zT_18;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(top != (unsigned int)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_22 = bits + (unsigned int)(1);
    bits = zT_22;
    zT_24 = top >> (unsigned int)(1);
    top = zT_24;
    goto z_bb_6;
    z_bb_5:
    zT_26 = 0;
    tz = zT_26;
    zT_28 = 0;
    i = zT_28;
    goto z_bb_7;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_29 = v.len;
    if ((unsigned char)(i < zT_29)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32 = v.mag;
    zT_33 = (unsigned int)i;
    zT_34 = zT_32[zT_33];
    limb = zT_34;
    if ((unsigned char)(limb == (unsigned int)(0))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    return (unsigned int)(bits - tz);
    z_bb_10:
    zT_49 = i + (unsigned char)(1);
    i = zT_49;
    goto z_bb_7;
    z_bb_11:
    zT_38 = tz + (unsigned int)(32);
    tz = zT_38;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)((unsigned int)(limb & (unsigned int)(1)) == (unsigned int)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_44 = tz + (unsigned int)(1);
    tz = zT_44;
    zT_46 = limb >> (unsigned int)(1);
    limb = zT_46;
    goto z_bb_17;
    z_bb_16:
    return (unsigned int)(bits - tz);
    z_bb_17:
    goto z_bb_14;
}

/* comptimeEvalF64IsF32Exact */
unsigned char zF_173AF805_comptimeEvalF64IsF3(zT_00435AEB_f64 x) {
    float zT_2;
    zT_00435AEB_f64 zT_4;
    float x32;
    zT_00435AEB_f64 back;
    zT_2 = (float)x;
    x32 = zT_2;
    zT_4 = (zT_00435AEB_f64)x32;
    back = zT_4;
    return (unsigned char)(back == x);
}

/* comptimeIntF32Exact */
unsigned char zF_60F34F76_comptimeIntF32Exact(zT_0163D9A4_ComptimeInt v) {
    zT_0163D9A4_ComptimeInt zT_1;
    unsigned int zT_2 = 0;
    zT_00435AEB_f64 zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    zT_00435AEB_f64 zT_8 = 0;
    unsigned char zT_9 = 0;
    zT_1 = v;
    zT_2 = zF_4372148C_ciSignificantBits(zT_1);
    if ((unsigned char)(zT_2 > (unsigned int)(24))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = v;
    zT_8 = zF_E6CE9168_ciToF64(zT_7);
    zT_6 = zT_8;
    zT_9 = zF_173AF805_comptimeEvalF64IsF3(zT_6);
    return zT_9;
}

/* comptimeEvalFloatOperandType */
unsigned int zF_70E6C6F2_comptimeEvalFloatOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    unsigned int zT_6 = 0;
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_82243BAB_comptimeEvalFloatOp(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* comptimeEvalFloatOperandTypeDepth */
unsigned int zF_82243BAB_comptimeEvalFloatOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    unsigned int zT_11;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    zT_22A7C88B_AstNode zT_18 = {0};
    zT_8143F551_AstKind zT_19;
    unsigned int zT_23;
    unsigned int zT_25;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    zT_22A7C88B_AstNode zT_30 = {0};
    zT_8143F551_AstKind zT_31;
    zT_8143F551_AstKind zT_36;
    zT_DA663F79_ComptimeEval* zT_40;
    unsigned int zT_43;
    unsigned int zT_45;
    zT_8143F551_AstKind zT_47;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_55 = 0;
    zT_05CE5599_Opt_400 zT_56;
    unsigned char zT_57;
    zT_E2DF2801_LocalConstScope* zT_59;
    unsigned int zT_60;
    zT_BAEE192E_Opt_10 zT_61 = {0};
    unsigned char zT_62;
    zT_6B0A7D14_AstStore* zT_65;
    unsigned int zT_66;
    zT_22A7C88B_AstNode zT_68 = {0};
    unsigned int zT_69;
    zT_DA663F79_ComptimeEval* zT_72;
    unsigned int zT_73;
    zT_BAEE192E_Opt_10 zT_75 = {0};
    unsigned char zT_76;
    unsigned char zT_80;
    unsigned int zT_84;
    zT_DA663F79_ComptimeEval* zT_87;
    unsigned int zT_90;
    unsigned int zT_92;
    int zT_96;
    unsigned int zT_97;
    zT_3D7259E2_SymbolRegistry* zT_98;
    unsigned int zT_99;
    zT_3D7259E2_SymbolRegistry* zT_103;
    unsigned int zT_105;
    zT_557B6199_Opt_875 zT_108 = {0};
    unsigned char zT_109;
    unsigned short zT_111;
    zT_6B0A7D14_AstStore* zT_117;
    unsigned int zT_118;
    zT_22A7C88B_AstNode zT_121 = {0};
    unsigned int zT_122;
    zT_DA663F79_ComptimeEval* zT_125;
    unsigned int zT_126;
    zT_BAEE192E_Opt_10 zT_128 = {0};
    unsigned char zT_129;
    unsigned char zT_133;
    unsigned int zT_137;
    zT_DA663F79_ComptimeEval* zT_140;
    unsigned int zT_143;
    unsigned int zT_145;
    int zT_147;
    unsigned int zT_149;
    zT_8143F551_AstKind zT_151;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned char zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    zT_DA663F79_ComptimeEval* zT_162;
    unsigned int zT_163;
    zT_6B0A7D14_AstStore* zT_164;
    unsigned int zT_165;
    unsigned int zT_169 = 0;
    zT_BAEE192E_Opt_10 zT_170 = {0};
    unsigned char zT_171;
    unsigned char zT_175;
    unsigned int idx;
    unsigned int guard;
    zT_22A7C88B_AstNode wn;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    unsigned int lt;
    zT_557B6199_Opt_875 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int t;
    unsigned int t2;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    idx = node_idx;
    zT_11 = 0;
    guard = zT_11;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(guard < (unsigned int)(32))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_15 = self->store;
    zT_16 = idx;
    zT_18 = zF_FCDD1D35_astStoreNodeAt(zT_15, zT_16);
    wn = zT_18;
    zT_19 = wn.kind;
    if ((unsigned char)(zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_9; else goto z_bb_11;
    z_bb_7:
    zT_27 = self->store;
    zT_28 = idx;
    zT_30 = zF_FCDD1D35_astStoreNodeAt(zT_27, zT_28);
    node = zT_30;
    zT_31 = node.kind;
    if ((unsigned char)(zT_31 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_12; else goto z_bb_13;
    z_bb_8:
    zT_25 = guard + (unsigned int)(1);
    guard = zT_25;
    goto z_bb_5;
    z_bb_9:
    zT_23 = wn.child_0;
    idx = zT_23;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    goto z_bb_7;
    z_bb_12:
    return (unsigned int)(0);
    z_bb_13:
    zT_36 = node.kind;
    if ((unsigned char)(zT_36 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_40 = self;
    zT_43 = node.child_0;
    zT_45 = depth + (unsigned int)(1);
    self = zT_40;
    node_idx = zT_43;
    depth = zT_45;
    goto z_bb_0;
    z_bb_15:
    zT_47 = node.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_52 = self->store;
    zT_53 = idx;
    zT_55 = zF_53458827_astStoreIdentifier(zT_52, zT_53);
    name_id = zT_55;
    zT_56 = self->local_consts;
    zT_57 = zT_56.has_value;
    if (zT_57) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_151 = node.kind;
    if ((unsigned char)(zT_151 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_52; else goto z_bb_53;
    z_bb_18:
    lcs = zT_56.value;
    zT_59 = lcs;
    zT_60 = name_id;
    zT_61 = zF_6532C387_localConstScopeLook(zT_59, zT_60);
    zT_62 = zT_61.has_value;
    if (zT_62) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_96 = 0;
    zT_97 = (unsigned int)zT_96;
    mi = zT_97;
    goto z_bb_33;
    z_bb_20:
    l_decl_node = zT_61.value;
    zT_65 = self->store;
    zT_66 = l_decl_node;
    zT_68 = zF_FCDD1D35_astStoreNodeAt(zT_65, zT_66);
    l_decl = zT_68;
    zT_69 = l_decl.child_0;
    if ((unsigned char)(zT_69 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_72 = self;
    zT_73 = l_decl.child_0;
    zT_75 = zF_BAD6BA5D_comptimeEvalResolve(zT_72, zT_73);
    zT_76 = zT_75.has_value;
    if (zT_76) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_84 = l_decl.child_1;
    if ((unsigned char)(zT_84 != (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_24:
    lt = zT_75.value;
    if ((unsigned char)(lt == (unsigned int)(15))) goto z_bb_27; else goto z_bb_26;
    z_bb_25:
    return (unsigned int)(0);
    z_bb_26:
    zT_80 = lt == (unsigned int)(16);
    goto z_bb_28;
    z_bb_27:
    zT_80 = 1;
    goto z_bb_28;
    z_bb_28:
    if (zT_80) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    return lt;
    z_bb_30:
    goto z_bb_25;
    z_bb_31:
    zT_87 = self;
    zT_90 = l_decl.child_1;
    zT_92 = depth + (unsigned int)(1);
    self = zT_87;
    node_idx = zT_90;
    depth = zT_92;
    goto z_bb_0;
    z_bb_32:
    return (unsigned int)(0);
    z_bb_33:
    zT_98 = self->symbol_reg;
    zT_99 = zT_98->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_99))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_103 = self->symbol_reg;
    zT_105 = name_id;
    zT_108 = zF_A398987E_symbolRegistryQuali(zT_103, (unsigned int)((unsigned int)mi), zT_105);
    c_sym = zT_108;
    zT_109 = c_sym.has_value;
    if (zT_109) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    return (unsigned int)(0);
    z_bb_36:
    zT_147 = 1;
    zT_149 = mi + (unsigned int)((unsigned int)zT_147);
    mi = zT_149;
    goto z_bb_33;
    z_bb_37:
    cs = c_sym.value;
    zT_111 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_111 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    zT_117 = self->store;
    zT_118 = cs->decl_node;
    zT_121 = zF_FCDD1D35_astStoreNodeAt(zT_117, zT_118);
    c_decl = zT_121;
    zT_122 = c_decl.child_0;
    if ((unsigned char)(zT_122 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    goto z_bb_38;
    z_bb_41:
    zT_125 = self;
    zT_126 = c_decl.child_0;
    zT_128 = zF_BAD6BA5D_comptimeEvalResolve(zT_125, zT_126);
    zT_129 = zT_128.has_value;
    if (zT_129) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    zT_137 = c_decl.child_1;
    if ((unsigned char)(zT_137 != (unsigned int)(0))) goto z_bb_50; else goto z_bb_51;
    z_bb_43:
    t = zT_128.value;
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_46; else goto z_bb_45;
    z_bb_44:
    return (unsigned int)(0);
    z_bb_45:
    zT_133 = t == (unsigned int)(16);
    goto z_bb_47;
    z_bb_46:
    zT_133 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_133) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    return t;
    z_bb_49:
    goto z_bb_44;
    z_bb_50:
    zT_140 = self;
    zT_143 = c_decl.child_1;
    zT_145 = depth + (unsigned int)(1);
    self = zT_140;
    node_idx = zT_143;
    depth = zT_145;
    goto z_bb_0;
    z_bb_51:
    goto z_bb_40;
    z_bb_52:
    zT_155 = node.child_0;
    zT_156 = self->int_to_float_id;
    if ((unsigned char)(zT_155 == zT_156)) goto z_bb_55; else goto z_bb_54;
    z_bb_53:
    return (unsigned int)(0);
    z_bb_54:
    zT_159 = node.child_0;
    zT_160 = self->float_cast_id;
    zT_158 = zT_159 == zT_160;
    goto z_bb_56;
    z_bb_55:
    zT_158 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_158) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_162 = self;
    zT_164 = self->store;
    zT_165 = idx;
    zT_169 = zF_B10B1BC1_astStoreNodeExtraCh(zT_164, zT_165, (unsigned int)(0));
    zT_163 = zT_169;
    zT_170 = zF_BAD6BA5D_comptimeEvalResolve(zT_162, zT_163);
    zT_171 = zT_170.has_value;
    if (zT_171) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    return (unsigned int)(0);
    z_bb_59:
    t2 = zT_170.value;
    if ((unsigned char)(t2 == (unsigned int)(15))) goto z_bb_62; else goto z_bb_61;
    z_bb_60:
    goto z_bb_58;
    z_bb_61:
    zT_175 = t2 == (unsigned int)(16);
    goto z_bb_63;
    z_bb_62:
    zT_175 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_175) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    return t2;
    z_bb_65:
    goto z_bb_60;
}

/* comptimeEvalLogical */
zT_E53A25A2_Opt_203 zF_40F99F20_comptimeEvalLogical(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_E53A25A2_Opt_203 zT_14 = {0};
    unsigned char zT_18;
    unsigned char zT_20;
    zT_E53A25A2_Opt_203 zT_23 = {0};
    unsigned char zT_24;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt zT_26;
    unsigned char zT_27 = 0;
    zT_89B1DDDA_ComptimeVal zT_28 = {0};
    zT_E53A25A2_Opt_203 zT_29;
    zT_E53A25A2_Opt_203 zT_30 = {0};
    unsigned char zT_34;
    unsigned char zT_36;
    zT_E53A25A2_Opt_203 zT_39 = {0};
    zT_0163D9A4_ComptimeInt zT_40;
    zT_0163D9A4_ComptimeInt zT_41;
    unsigned char zT_42 = 0;
    zT_89B1DDDA_ComptimeVal zT_45 = {0};
    zT_E53A25A2_Opt_203 zT_46;
    zT_DA663F79_ComptimeEval* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_E53A25A2_Opt_203 zT_52 = {0};
    unsigned char zT_53;
    unsigned char zT_55;
    zT_E53A25A2_Opt_203 zT_58 = {0};
    zT_0163D9A4_ComptimeInt zT_60;
    zT_0163D9A4_ComptimeInt zT_61;
    unsigned char zT_62 = 0;
    zT_89B1DDDA_ComptimeVal zT_64 = {0};
    zT_E53A25A2_Opt_203 zT_65;
    zT_E53A25A2_Opt_203 zT_66 = {0};
    zT_DA663F79_ComptimeEval* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_E53A25A2_Opt_203 zT_71 = {0};
    unsigned char zT_72;
    unsigned char zT_74;
    zT_E53A25A2_Opt_203 zT_77 = {0};
    zT_0163D9A4_ComptimeInt zT_78;
    zT_0163D9A4_ComptimeInt zT_79;
    unsigned char zT_80 = 0;
    zT_89B1DDDA_ComptimeVal zT_83 = {0};
    zT_E53A25A2_Opt_203 zT_84;
    zT_E53A25A2_Opt_203 zT_85 = {0};
    unsigned char zT_89;
    unsigned char zT_91;
    zT_E53A25A2_Opt_203 zT_94 = {0};
    zT_0163D9A4_ComptimeInt zT_95;
    zT_0163D9A4_ComptimeInt zT_96;
    unsigned char zT_97 = 0;
    zT_89B1DDDA_ComptimeVal zT_101 = {0};
    zT_E53A25A2_Opt_203 zT_102;
    zT_DA663F79_ComptimeEval* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_E53A25A2_Opt_203 zT_108 = {0};
    unsigned char zT_109;
    unsigned char zT_111;
    zT_E53A25A2_Opt_203 zT_114 = {0};
    zT_0163D9A4_ComptimeInt zT_116;
    zT_0163D9A4_ComptimeInt zT_117;
    unsigned char zT_118 = 0;
    zT_89B1DDDA_ComptimeVal zT_120 = {0};
    zT_E53A25A2_Opt_203 zT_121;
    zT_E53A25A2_Opt_203 zT_122 = {0};
    zT_DA663F79_ComptimeEval* zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_E53A25A2_Opt_203 zT_127 = {0};
    unsigned char zT_128;
    unsigned char zT_130;
    zT_E53A25A2_Opt_203 zT_133 = {0};
    zT_0163D9A4_ComptimeInt zT_134;
    zT_0163D9A4_ComptimeInt zT_135;
    unsigned char zT_136 = 0;
    zT_89B1DDDA_ComptimeVal zT_140 = {0};
    zT_E53A25A2_Opt_203 zT_141;
    zT_E53A25A2_Opt_203 zT_142 = {0};
    zT_E53A25A2_Opt_203 zT_143 = {0};
    zT_22A7C88B_AstNode node;
    zT_E53A25A2_Opt_203 lhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_E53A25A2_Opt_203 rhs_a;
    zT_89B1DDDA_ComptimeVal ra;
    zT_89B1DDDA_ComptimeVal ra2;
    zT_E53A25A2_Opt_203 rhs_o;
    zT_89B1DDDA_ComptimeVal ro;
    zT_89B1DDDA_ComptimeVal ro2;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = lhs.has_value;
    if (zT_18) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    l = lhs.value;
    zT_20 = l.kind;
    if ((unsigned char)(zT_20 != (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_30.has_value = 0;
    return zT_30;
    z_bb_5:
    zT_23.has_value = 0;
    return zT_23;
    z_bb_6:
    zT_26 = l.v;
    zT_25 = zT_26;
    zT_27 = zF_0F5FA15F_ciIsZero(zT_25);
    zT_24 = zT_27;
    zT_28 = zF_E867E750_ciBoolVal(zT_24);
    zT_29.has_value = 1;
    zT_29.value = zT_28;
    return zT_29;
    z_bb_7:
    zT_34 = lhs.has_value;
    if (zT_34) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or))) goto z_bb_25; else goto z_bb_26;
    z_bb_9:
    l = lhs.value;
    zT_36 = l.kind;
    if ((unsigned char)(zT_36 != (unsigned int)(1))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_67 = self;
    zT_68 = node.child_1;
    zT_69 = depth;
    zT_71 = zF_4EE17137_comptimeEvalEvaluat(zT_67, zT_68, zT_69);
    zT_72 = zT_71.has_value;
    if (zT_72) goto z_bb_19; else goto z_bb_20;
    z_bb_11:
    zT_39.has_value = 0;
    return zT_39;
    z_bb_12:
    zT_41 = l.v;
    zT_40 = zT_41;
    zT_42 = zF_0F5FA15F_ciIsZero(zT_40);
    if (zT_42) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = zF_E867E750_ciBoolVal((unsigned char)(0));
    zT_46.has_value = 1;
    zT_46.value = zT_45;
    return zT_46;
    z_bb_14:
    zT_48 = self;
    zT_49 = node.child_1;
    zT_50 = depth;
    zT_52 = zF_4EE17137_comptimeEvalEvaluat(zT_48, zT_49, zT_50);
    rhs_a = zT_52;
    zT_53 = rhs_a.has_value;
    if (zT_53) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    ra = rhs_a.value;
    zT_55 = ra.kind;
    if ((unsigned char)(zT_55 != (unsigned int)(1))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_66.has_value = 0;
    return zT_66;
    z_bb_17:
    zT_58.has_value = 0;
    return zT_58;
    z_bb_18:
    zT_61 = ra.v;
    zT_60 = zT_61;
    zT_62 = zF_0F5FA15F_ciIsZero(zT_60);
    zT_64 = zF_E867E750_ciBoolVal((unsigned char)(!zT_62));
    zT_65.has_value = 1;
    zT_65.value = zT_64;
    return zT_65;
    z_bb_19:
    ra2 = zT_71.value;
    zT_74 = ra2.kind;
    if ((unsigned char)(zT_74 != (unsigned int)(1))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_85.has_value = 0;
    return zT_85;
    z_bb_21:
    zT_77.has_value = 0;
    return zT_77;
    z_bb_22:
    zT_79 = ra2.v;
    zT_78 = zT_79;
    zT_80 = zF_0F5FA15F_ciIsZero(zT_78);
    if (zT_80) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_83 = zF_E867E750_ciBoolVal((unsigned char)(0));
    zT_84.has_value = 1;
    zT_84.value = zT_83;
    return zT_84;
    z_bb_24:
    goto z_bb_20;
    z_bb_25:
    zT_89 = lhs.has_value;
    if (zT_89) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    zT_143.has_value = 0;
    return zT_143;
    z_bb_27:
    l = lhs.value;
    zT_91 = l.kind;
    if ((unsigned char)(zT_91 != (unsigned int)(1))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_123 = self;
    zT_124 = node.child_1;
    zT_125 = depth;
    zT_127 = zF_4EE17137_comptimeEvalEvaluat(zT_123, zT_124, zT_125);
    zT_128 = zT_127.has_value;
    if (zT_128) goto z_bb_37; else goto z_bb_38;
    z_bb_29:
    zT_94.has_value = 0;
    return zT_94;
    z_bb_30:
    zT_96 = l.v;
    zT_95 = zT_96;
    zT_97 = zF_0F5FA15F_ciIsZero(zT_95);
    if ((unsigned char)(!zT_97)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_101 = zF_E867E750_ciBoolVal((unsigned char)(1));
    zT_102.has_value = 1;
    zT_102.value = zT_101;
    return zT_102;
    z_bb_32:
    zT_104 = self;
    zT_105 = node.child_1;
    zT_106 = depth;
    zT_108 = zF_4EE17137_comptimeEvalEvaluat(zT_104, zT_105, zT_106);
    rhs_o = zT_108;
    zT_109 = rhs_o.has_value;
    if (zT_109) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    ro = rhs_o.value;
    zT_111 = ro.kind;
    if ((unsigned char)(zT_111 != (unsigned int)(1))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_122.has_value = 0;
    return zT_122;
    z_bb_35:
    zT_114.has_value = 0;
    return zT_114;
    z_bb_36:
    zT_117 = ro.v;
    zT_116 = zT_117;
    zT_118 = zF_0F5FA15F_ciIsZero(zT_116);
    zT_120 = zF_E867E750_ciBoolVal((unsigned char)(!zT_118));
    zT_121.has_value = 1;
    zT_121.value = zT_120;
    return zT_121;
    z_bb_37:
    ro2 = zT_127.value;
    zT_130 = ro2.kind;
    if ((unsigned char)(zT_130 != (unsigned int)(1))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_142.has_value = 0;
    return zT_142;
    z_bb_39:
    zT_133.has_value = 0;
    return zT_133;
    z_bb_40:
    zT_135 = ro2.v;
    zT_134 = zT_135;
    zT_136 = zF_0F5FA15F_ciIsZero(zT_134);
    if ((unsigned char)(!zT_136)) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_140 = zF_E867E750_ciBoolVal((unsigned char)(1));
    zT_141.has_value = 1;
    zT_141.value = zT_140;
    return zT_141;
    z_bb_42:
    goto z_bb_38;
}

/* comptimeEvalOperandType */
zT_BAEE192E_Opt_10 zF_6B810D4A_comptimeEvalOperand(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_F60B0343_comptimeEvalOperand(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* comptimeEvalOperandTypeDepth */
zT_BAEE192E_Opt_10 zF_F60B0343_comptimeEvalOperand(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_BAEE192E_Opt_10 zT_5 = {0};
    zT_BAEE192E_Opt_10 zT_8 = {0};
    int zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_22A7C88B_AstNode zT_19 = {0};
    zT_8143F551_AstKind zT_20;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    zT_22A7C88B_AstNode zT_32 = {0};
    zT_8143F551_AstKind zT_33;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    unsigned int zT_41 = 0;
    zT_05CE5599_Opt_400 zT_42;
    unsigned char zT_43;
    zT_E2DF2801_LocalConstScope* zT_45;
    unsigned int zT_46;
    zT_BAEE192E_Opt_10 zT_47 = {0};
    unsigned char zT_48;
    zT_6B0A7D14_AstStore* zT_51;
    unsigned int zT_52;
    zT_22A7C88B_AstNode zT_54 = {0};
    unsigned int zT_55;
    zT_DA663F79_ComptimeEval* zT_58;
    unsigned int zT_59;
    zT_BAEE192E_Opt_10 zT_61 = {0};
    unsigned char zT_62;
    zT_338B7C76_TypeRegistry* zT_64;
    unsigned int zT_65;
    unsigned char zT_67 = 0;
    zT_BAEE192E_Opt_10 zT_68;
    unsigned int zT_69;
    zT_DA663F79_ComptimeEval* zT_72;
    unsigned int zT_75;
    unsigned int zT_77;
    int zT_80;
    unsigned int zT_81;
    zT_3D7259E2_SymbolRegistry* zT_82;
    unsigned int zT_83;
    zT_3D7259E2_SymbolRegistry* zT_87;
    unsigned int zT_89;
    zT_557B6199_Opt_875 zT_92 = {0};
    unsigned char zT_93;
    unsigned short zT_95;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    zT_22A7C88B_AstNode zT_105 = {0};
    unsigned int zT_106;
    zT_DA663F79_ComptimeEval* zT_109;
    unsigned int zT_110;
    zT_BAEE192E_Opt_10 zT_112 = {0};
    unsigned char zT_113;
    zT_338B7C76_TypeRegistry* zT_115;
    unsigned int zT_116;
    unsigned char zT_118 = 0;
    zT_BAEE192E_Opt_10 zT_119;
    unsigned int zT_120;
    zT_DA663F79_ComptimeEval* zT_123;
    unsigned int zT_126;
    unsigned int zT_128;
    int zT_130;
    unsigned int zT_132;
    zT_BAEE192E_Opt_10 zT_133 = {0};
    zT_8143F551_AstKind zT_134;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned char zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_DA663F79_ComptimeEval* zT_145;
    unsigned int zT_146;
    zT_6B0A7D14_AstStore* zT_147;
    unsigned int zT_148;
    unsigned int zT_152 = 0;
    zT_BAEE192E_Opt_10 zT_153 = {0};
    unsigned char zT_154;
    zT_338B7C76_TypeRegistry* zT_156;
    unsigned int zT_157;
    unsigned char zT_159 = 0;
    zT_BAEE192E_Opt_10 zT_160;
    zT_BAEE192E_Opt_10 zT_161 = {0};
    zT_8143F551_AstKind zT_162;
    unsigned char zT_166;
    zT_8143F551_AstKind zT_167;
    zT_DA663F79_ComptimeEval* zT_171;
    unsigned int zT_174;
    unsigned int zT_176;
    zT_8143F551_AstKind zT_178;
    unsigned char zT_182;
    zT_8143F551_AstKind zT_183;
    unsigned char zT_187;
    zT_8143F551_AstKind zT_188;
    unsigned char zT_192;
    zT_8143F551_AstKind zT_193;
    unsigned char zT_197;
    zT_8143F551_AstKind zT_198;
    unsigned char zT_202;
    zT_8143F551_AstKind zT_203;
    unsigned char zT_207;
    zT_8143F551_AstKind zT_208;
    unsigned char zT_212;
    zT_8143F551_AstKind zT_213;
    unsigned char zT_217;
    zT_8143F551_AstKind zT_218;
    unsigned char zT_222;
    zT_8143F551_AstKind zT_223;
    zT_DA663F79_ComptimeEval* zT_228;
    unsigned int zT_229;
    zT_BAEE192E_Opt_10 zT_234 = {0};
    zT_DA663F79_ComptimeEval* zT_236;
    unsigned int zT_237;
    zT_BAEE192E_Opt_10 zT_242 = {0};
    unsigned char zT_243;
    unsigned char zT_245;
    zT_DA663F79_ComptimeEval* zT_247;
    unsigned int zT_248;
    unsigned int zT_249;
    unsigned int zT_250 = 0;
    zT_BAEE192E_Opt_10 zT_251;
    zT_BAEE192E_Opt_10 zT_252;
    zT_BAEE192E_Opt_10 zT_253 = {0};
    unsigned int idx;
    unsigned int guard;
    zT_22A7C88B_AstNode wn;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    unsigned int lt;
    zT_557B6199_Opt_875 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int t;
    unsigned int t2;
    zT_BAEE192E_Opt_10 lt_1;
    zT_BAEE192E_Opt_10 rt;
    unsigned int ltv;
    unsigned int rtv;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    idx = node_idx;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    guard = zT_12;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(guard < (unsigned int)(32))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_16 = self->store;
    zT_17 = idx;
    zT_19 = zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    wn = zT_19;
    zT_20 = wn.kind;
    if ((unsigned char)(zT_20 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_9; else goto z_bb_11;
    z_bb_7:
    zT_29 = self->store;
    zT_30 = idx;
    zT_32 = zF_FCDD1D35_astStoreNodeAt(zT_29, zT_30);
    node = zT_32;
    zT_33 = node.kind;
    if ((unsigned char)(zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_12; else goto z_bb_13;
    z_bb_8:
    zT_25 = 1;
    zT_27 = guard + (unsigned int)((unsigned int)zT_25);
    guard = zT_27;
    goto z_bb_5;
    z_bb_9:
    zT_24 = wn.child_0;
    idx = zT_24;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    goto z_bb_7;
    z_bb_12:
    zT_38 = self->store;
    zT_39 = idx;
    zT_41 = zF_53458827_astStoreIdentifier(zT_38, zT_39);
    name_id = zT_41;
    zT_42 = self->local_consts;
    zT_43 = zT_42.has_value;
    if (zT_43) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_134 = node.kind;
    if ((unsigned char)(zT_134 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_44; else goto z_bb_45;
    z_bb_14:
    lcs = zT_42.value;
    zT_45 = lcs;
    zT_46 = name_id;
    zT_47 = zF_6532C387_localConstScopeLook(zT_45, zT_46);
    zT_48 = zT_47.has_value;
    if (zT_48) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_80 = 0;
    zT_81 = (unsigned int)zT_80;
    mi = zT_81;
    goto z_bb_27;
    z_bb_16:
    l_decl_node = zT_47.value;
    zT_51 = self->store;
    zT_52 = l_decl_node;
    zT_54 = zF_FCDD1D35_astStoreNodeAt(zT_51, zT_52);
    l_decl = zT_54;
    zT_55 = l_decl.child_0;
    if ((unsigned char)(zT_55 != (unsigned int)(0))) goto z_bb_18; else goto z_bb_20;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_58 = self;
    zT_59 = l_decl.child_0;
    zT_61 = zF_BAD6BA5D_comptimeEvalResolve(zT_58, zT_59);
    zT_62 = zT_61.has_value;
    if (zT_62) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    goto z_bb_17;
    z_bb_20:
    zT_69 = l_decl.child_1;
    if ((unsigned char)(zT_69 != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_21:
    lt = zT_61.value;
    zT_64 = self->registry;
    zT_65 = lt;
    zT_67 = zF_3290E9C4_typeRegistryIsInteg(zT_64, zT_65);
    if (zT_67) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_68.has_value = 1;
    zT_68.value = lt;
    return zT_68;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_72 = self;
    zT_75 = l_decl.child_1;
    zT_77 = depth + (unsigned int)(1);
    self = zT_72;
    node_idx = zT_75;
    depth = zT_77;
    goto z_bb_0;
    z_bb_26:
    goto z_bb_19;
    z_bb_27:
    zT_82 = self->symbol_reg;
    zT_83 = zT_82->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_83))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_87 = self->symbol_reg;
    zT_89 = name_id;
    zT_92 = zF_A398987E_symbolRegistryQuali(zT_87, (unsigned int)((unsigned int)mi), zT_89);
    c_sym = zT_92;
    zT_93 = c_sym.has_value;
    if (zT_93) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    zT_133.has_value = 0;
    return zT_133;
    z_bb_30:
    zT_130 = 1;
    zT_132 = mi + (unsigned int)((unsigned int)zT_130);
    mi = zT_132;
    goto z_bb_27;
    z_bb_31:
    cs = c_sym.value;
    zT_95 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_95 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_101 = self->store;
    zT_102 = cs->decl_node;
    zT_105 = zF_FCDD1D35_astStoreNodeAt(zT_101, zT_102);
    c_decl = zT_105;
    zT_106 = c_decl.child_0;
    if ((unsigned char)(zT_106 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_37;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_109 = self;
    zT_110 = c_decl.child_0;
    zT_112 = zF_BAD6BA5D_comptimeEvalResolve(zT_109, zT_110);
    zT_113 = zT_112.has_value;
    if (zT_113) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_120 = c_decl.child_1;
    if ((unsigned char)(zT_120 != (unsigned int)(0))) goto z_bb_42; else goto z_bb_43;
    z_bb_38:
    t = zT_112.value;
    zT_115 = self->registry;
    zT_116 = t;
    zT_118 = zF_3290E9C4_typeRegistryIsInteg(zT_115, zT_116);
    if (zT_118) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_119.has_value = 1;
    zT_119.value = t;
    return zT_119;
    z_bb_41:
    goto z_bb_39;
    z_bb_42:
    zT_123 = self;
    zT_126 = c_decl.child_1;
    zT_128 = depth + (unsigned int)(1);
    self = zT_123;
    node_idx = zT_126;
    depth = zT_128;
    goto z_bb_0;
    z_bb_43:
    goto z_bb_36;
    z_bb_44:
    zT_138 = node.child_0;
    zT_139 = self->int_cast_id;
    if ((unsigned char)(zT_138 == zT_139)) goto z_bb_47; else goto z_bb_46;
    z_bb_45:
    zT_162 = node.kind;
    if ((unsigned char)(zT_162 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_56; else goto z_bb_55;
    z_bb_46:
    zT_142 = node.child_0;
    zT_143 = self->as_id;
    zT_141 = zT_142 == zT_143;
    goto z_bb_48;
    z_bb_47:
    zT_141 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_141) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_145 = self;
    zT_147 = self->store;
    zT_148 = idx;
    zT_152 = zF_B10B1BC1_astStoreNodeExtraCh(zT_147, zT_148, (unsigned int)(0));
    zT_146 = zT_152;
    zT_153 = zF_BAD6BA5D_comptimeEvalResolve(zT_145, zT_146);
    zT_154 = zT_153.has_value;
    if (zT_154) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_161.has_value = 0;
    return zT_161;
    z_bb_51:
    t2 = zT_153.value;
    zT_156 = self->registry;
    zT_157 = t2;
    zT_159 = zF_3290E9C4_typeRegistryIsInteg(zT_156, zT_157);
    if (zT_159) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    zT_160.has_value = 1;
    zT_160.value = t2;
    return zT_160;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_167 = node.kind;
    zT_166 = zT_167 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not);
    goto z_bb_57;
    z_bb_56:
    zT_166 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_166) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_171 = self;
    zT_174 = node.child_0;
    zT_176 = depth + (unsigned int)(1);
    self = zT_171;
    node_idx = zT_174;
    depth = zT_176;
    goto z_bb_0;
    z_bb_59:
    zT_178 = node.kind;
    if ((unsigned char)(zT_178 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_61; else goto z_bb_60;
    z_bb_60:
    zT_183 = node.kind;
    zT_182 = zT_183 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_62;
    z_bb_61:
    zT_182 = 1;
    goto z_bb_62;
    z_bb_62:
    if (zT_182) goto z_bb_64; else goto z_bb_63;
    z_bb_63:
    zT_188 = node.kind;
    zT_187 = zT_188 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_65;
    z_bb_64:
    zT_187 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_187) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_193 = node.kind;
    zT_192 = zT_193 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_68;
    z_bb_67:
    zT_192 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_192) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_198 = node.kind;
    zT_197 = zT_198 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_71;
    z_bb_70:
    zT_197 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_197) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_203 = node.kind;
    zT_202 = zT_203 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_74;
    z_bb_73:
    zT_202 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_202) goto z_bb_76; else goto z_bb_75;
    z_bb_75:
    zT_208 = node.kind;
    zT_207 = zT_208 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_77;
    z_bb_76:
    zT_207 = 1;
    goto z_bb_77;
    z_bb_77:
    if (zT_207) goto z_bb_79; else goto z_bb_78;
    z_bb_78:
    zT_213 = node.kind;
    zT_212 = zT_213 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_80;
    z_bb_79:
    zT_212 = 1;
    goto z_bb_80;
    z_bb_80:
    if (zT_212) goto z_bb_82; else goto z_bb_81;
    z_bb_81:
    zT_218 = node.kind;
    zT_217 = zT_218 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_83;
    z_bb_82:
    zT_217 = 1;
    goto z_bb_83;
    z_bb_83:
    if (zT_217) goto z_bb_85; else goto z_bb_84;
    z_bb_84:
    zT_223 = node.kind;
    zT_222 = zT_223 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_86;
    z_bb_85:
    zT_222 = 1;
    goto z_bb_86;
    z_bb_86:
    if (zT_222) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    zT_228 = self;
    zT_229 = node.child_0;
    zT_234 = zF_F60B0343_comptimeEvalOperand(zT_228, zT_229, (unsigned int)(depth + (unsigned int)(1)));
    lt_1 = zT_234;
    zT_236 = self;
    zT_237 = node.child_1;
    zT_242 = zF_F60B0343_comptimeEvalOperand(zT_236, zT_237, (unsigned int)(depth + (unsigned int)(1)));
    rt = zT_242;
    zT_243 = lt_1.has_value;
    if (zT_243) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_253.has_value = 0;
    return zT_253;
    z_bb_89:
    ltv = lt_1.value;
    zT_245 = rt.has_value;
    if (zT_245) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    return rt;
    z_bb_91:
    rtv = rt.value;
    zT_247 = self;
    zT_248 = ltv;
    zT_249 = rtv;
    zT_250 = zF_CE5A812D_comptimeEvalWiderIn(zT_247, zT_248, zT_249);
    zT_251.has_value = 1;
    zT_251.value = zT_250;
    return zT_251;
    z_bb_92:
    zT_252.has_value = 1;
    zT_252.value = ltv;
    return zT_252;
}

/* comptimeEvalWiderIntType */
unsigned int zF_CE5A812D_comptimeEvalWiderIn(zT_DA663F79_ComptimeEval* self, unsigned int lt, unsigned int rt) {
    zT_338B7C76_TypeRegistry* zT_5;
    unsigned int zT_6;
    unsigned char zT_8 = 0;
    zT_338B7C76_TypeRegistry* zT_10;
    unsigned int zT_11;
    unsigned char zT_13 = 0;
    unsigned char lw;
    unsigned char rw;
    if ((unsigned char)(lt == rt)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return lt;
    z_bb_2:
    zT_5 = self->registry;
    zT_6 = lt;
    zT_8 = zF_655972D5_typeRegistryIntWidt(zT_5, zT_6);
    lw = zT_8;
    zT_10 = self->registry;
    zT_11 = rt;
    zT_13 = zF_655972D5_typeRegistryIntWidt(zT_10, zT_11);
    rw = zT_13;
    if ((unsigned char)(lw >= rw)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return lt;
    z_bb_4:
    return rt;
}

/* comptimeEvalResolveTypeArg */
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    unsigned int zT_12;
    zT_6F34EEB2_Opt_229 zT_13 = {0};
    zT_05CE5599_Opt_400 zT_14 = {0};
    zT_03CE5273_Opt_402 zT_15 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_17;
    unsigned int zT_18;
    unsigned int zT_22 = 0;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    zT_BAEE192E_Opt_10 zT_26;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int tid;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_7 = self->store;
    zT_6.store = zT_7;
    zT_8 = self->registry;
    zT_6.typereg = zT_8;
    zT_9 = self->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = self->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_12 = 0;
    zT_6.source_file_id = zT_12;
    zT_13.has_value = 0;
    zT_6.diag = zT_13;
    zT_14.has_value = 0;
    zT_6.local_consts = zT_14;
    zT_15.has_value = 0;
    zT_6.local_types = zT_15;
    env = zT_6;
    zT_17 = &env;
    zT_18 = node_idx;
    zT_22 = zF_F2107C15_resolveTypeExprFull(zT_17, zT_18, (unsigned int)(0));
    tid = zT_22;
    if ((unsigned char)(tid == (unsigned int)(18))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_4:
    zT_26.has_value = 1;
    zT_26.value = tid;
    return zT_26;
}

/* comptimeIntFitsType */
unsigned char zF_B28C4720_comptimeIntFitsType(zT_338B7C76_TypeRegistry* registry, zT_0163D9A4_ComptimeInt v, unsigned int t) {
    unsigned int zT_4;
    zT_338B7C76_TypeRegistry* zT_7;
    unsigned int zT_8;
    unsigned char zT_9 = 0;
    zT_338B7C76_TypeRegistry* zT_13;
    unsigned int zT_14;
    unsigned char zT_15 = 0;
    unsigned int zT_16;
    zT_338B7C76_TypeRegistry* zT_21;
    unsigned int zT_22;
    unsigned char zT_23 = 0;
    unsigned char zT_24;
    zT_0163D9A4_ComptimeInt zT_31 = {0};
    zT_0163D9A4_ComptimeInt zT_32;
    zT_0163D9A4_ComptimeInt zT_33;
    int zT_34 = 0;
    int zT_35;
    zT_0163D9A4_ComptimeInt zT_41 = {0};
    zT_0163D9A4_ComptimeInt zT_42;
    zT_0163D9A4_ComptimeInt zT_43;
    int zT_44 = 0;
    int zT_45;
    unsigned int zT_48;
    zT_0163D9A4_ComptimeInt zT_49 = {0};
    zT_0163D9A4_ComptimeInt zT_50;
    zT_0163D9A4_ComptimeInt zT_51;
    int zT_52 = 0;
    int zT_53;
    unsigned int wb;
    unsigned char tsig;
    zT_0163D9A4_ComptimeInt lim;
    zT_0163D9A4_ComptimeInt lim2;
    zT_0163D9A4_ComptimeInt lim3;
    zT_4 = registry->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)t) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = registry;
    zT_8 = t;
    zT_9 = zF_3290E9C4_typeRegistryIsInteg(zT_7, zT_8);
    if ((unsigned char)(!zT_9)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_13 = registry;
    zT_14 = t;
    zT_15 = zF_655972D5_typeRegistryIntWidt(zT_13, zT_14);
    zT_16 = (unsigned int)zT_15;
    wb = zT_16;
    if ((unsigned char)(wb == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_21 = registry;
    zT_22 = t;
    zT_23 = zF_01ED6537_typeRegistryIntIsSi(zT_21, zT_22);
    tsig = zT_23;
    zT_24 = v.neg;
    if (zT_24) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    if ((unsigned char)(!tsig)) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    if (tsig) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_31 = zF_8F225501_ciPow2((unsigned int)(wb - (unsigned int)(1)));
    lim = zT_31;
    zT_32 = v;
    zT_33 = lim;
    zT_34 = zF_0B19E30C_ciMagCmp(zT_32, zT_33);
    zT_35 = 0;
    return (unsigned char)(zT_34 <= zT_35);
    z_bb_11:
    zT_41 = zF_8F225501_ciPow2((unsigned int)(wb - (unsigned int)(1)));
    lim2 = zT_41;
    zT_42 = v;
    zT_43 = lim2;
    zT_44 = zF_0B19E30C_ciMagCmp(zT_42, zT_43);
    zT_45 = 0;
    return (unsigned char)(zT_44 < zT_45);
    z_bb_12:
    zT_48 = wb;
    zT_49 = zF_8F225501_ciPow2(zT_48);
    lim3 = zT_49;
    zT_50 = v;
    zT_51 = lim3;
    zT_52 = zF_0B19E30C_ciMagCmp(zT_50, zT_51);
    zT_53 = 0;
    return (unsigned char)(zT_52 < zT_53);
}

/* comptimeIntMaterialize */
zT_79FAE712_u64 zF_FB88E1A5_comptimeIntMaterial(zT_0163D9A4_ComptimeInt v) {
    zT_0163D9A4_ComptimeInt zT_1;
    zT_79FAE712_u64 zT_2 = 0;
    zT_1 = v;
    zT_2 = zF_4F2C9C5D_ciToU64(zT_1);
    return zT_2;
}

/* comptimeIntFits64 */
unsigned char zF_EF3A264A_comptimeIntFits64(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    zT_0163D9A4_ComptimeInt zT_5 = {0};
    zT_0163D9A4_ComptimeInt zT_6;
    zT_0163D9A4_ComptimeInt zT_7;
    int zT_8 = 0;
    int zT_9;
    zT_0163D9A4_ComptimeInt zT_14 = {0};
    zT_0163D9A4_ComptimeInt zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    int zT_17 = 0;
    int zT_18;
    zT_0163D9A4_ComptimeInt lim;
    zT_0163D9A4_ComptimeInt lim2;
    zT_1 = v.neg;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = zF_8F225501_ciPow2((unsigned int)(63));
    lim = zT_5;
    zT_6 = v;
    zT_7 = lim;
    zT_8 = zF_0B19E30C_ciMagCmp(zT_6, zT_7);
    zT_9 = 0;
    return (unsigned char)(zT_8 <= zT_9);
    z_bb_2:
    zT_14 = zF_8F225501_ciPow2((unsigned int)(64));
    lim2 = zT_14;
    zT_15 = v;
    zT_16 = lim2;
    zT_17 = zF_0B19E30C_ciMagCmp(zT_15, zT_16);
    zT_18 = 0;
    return (unsigned char)(zT_17 < zT_18);
}

/* comptimeIntUntypedType */
zT_BAEE192E_Opt_10 zF_42B163B9_comptimeIntUntypedT(zT_0163D9A4_ComptimeInt v) {
    zT_0163D9A4_ComptimeInt zT_4 = {0};
    zT_0163D9A4_ComptimeInt zT_8 = {0};
    zT_0163D9A4_ComptimeInt zT_12 = {0};
    zT_0163D9A4_ComptimeInt zT_16 = {0};
    unsigned char zT_17;
    zT_0163D9A4_ComptimeInt zT_18;
    zT_0163D9A4_ComptimeInt zT_19;
    int zT_20 = 0;
    int zT_21;
    unsigned int zT_23;
    zT_BAEE192E_Opt_10 zT_24;
    zT_0163D9A4_ComptimeInt zT_25;
    zT_0163D9A4_ComptimeInt zT_26;
    int zT_27 = 0;
    int zT_28;
    unsigned int zT_30;
    zT_BAEE192E_Opt_10 zT_31;
    zT_BAEE192E_Opt_10 zT_32 = {0};
    zT_0163D9A4_ComptimeInt zT_33;
    zT_0163D9A4_ComptimeInt zT_34;
    int zT_35 = 0;
    int zT_36;
    unsigned int zT_38;
    zT_BAEE192E_Opt_10 zT_39;
    zT_0163D9A4_ComptimeInt zT_40;
    zT_0163D9A4_ComptimeInt zT_41;
    int zT_42 = 0;
    int zT_43;
    unsigned int zT_45;
    zT_BAEE192E_Opt_10 zT_46;
    zT_0163D9A4_ComptimeInt zT_47;
    zT_0163D9A4_ComptimeInt zT_48;
    int zT_49 = 0;
    int zT_50;
    unsigned int zT_52;
    zT_BAEE192E_Opt_10 zT_53;
    zT_0163D9A4_ComptimeInt zT_54;
    zT_0163D9A4_ComptimeInt zT_55;
    int zT_56 = 0;
    int zT_57;
    unsigned int zT_59;
    zT_BAEE192E_Opt_10 zT_60;
    zT_BAEE192E_Opt_10 zT_61 = {0};
    zT_0163D9A4_ComptimeInt b31;
    zT_0163D9A4_ComptimeInt b32;
    zT_0163D9A4_ComptimeInt b63;
    zT_0163D9A4_ComptimeInt b64;
    zT_4 = zF_8F225501_ciPow2((unsigned int)(31));
    b31 = zT_4;
    zT_8 = zF_8F225501_ciPow2((unsigned int)(32));
    b32 = zT_8;
    zT_12 = zF_8F225501_ciPow2((unsigned int)(63));
    b63 = zT_12;
    zT_16 = zF_8F225501_ciPow2((unsigned int)(64));
    b64 = zT_16;
    zT_17 = v.neg;
    if (zT_17) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_18 = v;
    zT_19 = b31;
    zT_20 = zF_0B19E30C_ciMagCmp(zT_18, zT_19);
    zT_21 = 0;
    if ((unsigned char)(zT_20 <= zT_21)) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_33 = v;
    zT_34 = b31;
    zT_35 = zF_0B19E30C_ciMagCmp(zT_33, zT_34);
    zT_36 = 0;
    if ((unsigned char)(zT_35 < zT_36)) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    zT_23 = 6;
    zT_24.has_value = 1;
    zT_24.value = zT_23;
    return zT_24;
    z_bb_4:
    zT_25 = v;
    zT_26 = b63;
    zT_27 = zF_0B19E30C_ciMagCmp(zT_25, zT_26);
    zT_28 = 0;
    if ((unsigned char)(zT_27 <= zT_28)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_30 = 7;
    zT_31.has_value = 1;
    zT_31.value = zT_30;
    return zT_31;
    z_bb_6:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_7:
    zT_38 = 6;
    zT_39.has_value = 1;
    zT_39.value = zT_38;
    return zT_39;
    z_bb_8:
    zT_40 = v;
    zT_41 = b32;
    zT_42 = zF_0B19E30C_ciMagCmp(zT_40, zT_41);
    zT_43 = 0;
    if ((unsigned char)(zT_42 < zT_43)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_45 = 10;
    zT_46.has_value = 1;
    zT_46.value = zT_45;
    return zT_46;
    z_bb_10:
    zT_47 = v;
    zT_48 = b63;
    zT_49 = zF_0B19E30C_ciMagCmp(zT_47, zT_48);
    zT_50 = 0;
    if ((unsigned char)(zT_49 < zT_50)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_52 = 7;
    zT_53.has_value = 1;
    zT_53.value = zT_52;
    return zT_53;
    z_bb_12:
    zT_54 = v;
    zT_55 = b64;
    zT_56 = zF_0B19E30C_ciMagCmp(zT_54, zT_55);
    zT_57 = 0;
    if ((unsigned char)(zT_56 < zT_57)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_59 = 11;
    zT_60.has_value = 1;
    zT_60.value = zT_59;
    return zT_60;
    z_bb_14:
    zT_61.has_value = 0;
    return zT_61;
}

/* comptimeValStoreU64 */
zT_BBEE1AC1_Opt_11 zF_E3420380_comptimeValStoreU64(zT_89B1DDDA_ComptimeVal cv) {
    unsigned char zT_1;
    zT_79FAE712_u64 zT_4;
    zT_BBEE1AC1_Opt_11 zT_5;
    unsigned char zT_6;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_0163D9A4_ComptimeInt zT_10;
    unsigned char zT_11 = 0;
    zT_79FAE712_u64 zT_12;
    zT_BBEE1AC1_Opt_11 zT_13;
    zT_79FAE712_u64 zT_14;
    zT_BBEE1AC1_Opt_11 zT_15;
    zT_0163D9A4_ComptimeInt zT_16;
    zT_0163D9A4_ComptimeInt zT_17;
    unsigned char zT_18 = 0;
    zT_BBEE1AC1_Opt_11 zT_20 = {0};
    zT_0163D9A4_ComptimeInt zT_21;
    zT_0163D9A4_ComptimeInt zT_22;
    zT_79FAE712_u64 zT_23 = 0;
    zT_BBEE1AC1_Opt_11 zT_24;
    zT_1 = cv.kind;
    if ((unsigned char)(zT_1 == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = cv.float_bits;
    zT_5.has_value = 1;
    zT_5.value = zT_4;
    return zT_5;
    z_bb_2:
    zT_6 = cv.kind;
    if ((unsigned char)(zT_6 == (unsigned int)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_10 = cv.v;
    zT_9 = zT_10;
    zT_11 = zF_0F5FA15F_ciIsZero(zT_9);
    if (zT_11) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_17 = cv.v;
    zT_16 = zT_17;
    zT_18 = zF_EF3A264A_comptimeIntFits64(zT_16);
    if ((unsigned char)(!zT_18)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_12 = 0;
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
    z_bb_6:
    zT_14 = 1;
    zT_15.has_value = 1;
    zT_15.value = zT_14;
    return zT_15;
    z_bb_7:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_8:
    zT_22 = cv.v;
    zT_21 = zT_22;
    zT_23 = zF_4F2C9C5D_ciToU64(zT_21);
    zT_24.has_value = 1;
    zT_24.value = zT_23;
    return zT_24;
}

/* comptimeEvalBuiltin */
zT_E53A25A2_Opt_203 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    unsigned int zT_14 = 0;
    zT_E53A25A2_Opt_203 zT_17 = {0};
    zT_DA663F79_ComptimeEval* zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_26 = 0;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    unsigned char zT_35;
    zT_0163D9A4_ComptimeInt zT_38;
    unsigned int zT_40;
    zT_0163D9A4_ComptimeInt zT_42 = {0};
    zT_89B1DDDA_ComptimeVal zT_43 = {0};
    zT_E53A25A2_Opt_203 zT_44;
    zT_E53A25A2_Opt_203 zT_45 = {0};
    unsigned int zT_46;
    unsigned int zT_47;
    zT_6B0A7D14_AstStore* zT_49;
    unsigned int zT_50;
    unsigned int zT_52 = 0;
    zT_E53A25A2_Opt_203 zT_55 = {0};
    zT_DA663F79_ComptimeEval* zT_57;
    unsigned int zT_58;
    zT_6B0A7D14_AstStore* zT_59;
    unsigned int zT_60;
    unsigned int zT_64 = 0;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_D155D06D_Type* zT_70;
    unsigned int zT_71;
    zT_D155D06D_Type zT_72;
    unsigned char zT_73;
    zT_0163D9A4_ComptimeInt zT_76;
    unsigned int zT_78;
    zT_0163D9A4_ComptimeInt zT_80 = {0};
    zT_89B1DDDA_ComptimeVal zT_81 = {0};
    zT_E53A25A2_Opt_203 zT_82;
    zT_E53A25A2_Opt_203 zT_83 = {0};
    unsigned int zT_84;
    unsigned int zT_85;
    unsigned char zT_87;
    unsigned int zT_88;
    unsigned int zT_89;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    unsigned int zT_95 = 0;
    zT_DA663F79_ComptimeEval* zT_99;
    unsigned int zT_100;
    zT_6B0A7D14_AstStore* zT_101;
    unsigned int zT_102;
    unsigned int zT_106 = 0;
    zT_BAEE192E_Opt_10 zT_107 = {0};
    unsigned char zT_108;
    zT_338B7C76_TypeRegistry* zT_111;
    zT_D155D06D_Type* zT_112;
    unsigned int zT_113;
    zT_D155D06D_Type zT_114;
    unsigned char zT_115;
    unsigned char zT_118;
    zT_33EF6BFB_TypeKind zT_119;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_124 = {0};
    zT_338B7C76_TypeRegistry* zT_125;
    unsigned int zT_126;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_127;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_131 = {0};
    zT_338B7C76_TypeRegistry* zT_133;
    unsigned int zT_134;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_135;
    unsigned char zT_138 = 0;
    zT_6B0A7D14_AstStore* zT_140;
    unsigned int zT_141;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_148 = 0;
    zT_22A7C88B_AstNode zT_149 = {0};
    zT_8143F551_AstKind zT_150;
    zT_6B0A7D14_AstStore* zT_155;
    unsigned int zT_156;
    zT_6B0A7D14_AstStore* zT_158;
    unsigned int zT_159;
    unsigned int zT_163 = 0;
    unsigned int zT_164 = 0;
    zT_6B0A7D14_AstStore* zT_166;
    zT_4328F7F8_anon_274197 zT_167;
    unsigned int* zT_168;
    unsigned int zT_169;
    unsigned int zT_170;
    int zT_172;
    unsigned int zT_173;
    unsigned int zT_175;
    zT_2DF01B61_FieldEntry* zT_177;
    zT_2DF01B61_FieldEntry zT_178;
    unsigned int zT_179;
    zT_2DF01B61_FieldEntry* zT_182;
    zT_2DF01B61_FieldEntry zT_183;
    unsigned int zT_184;
    zT_79FAE712_u64 zT_185;
    zT_79FAE712_u64 zT_187;
    unsigned int zT_189;
    zT_E276DDD0_PackedBitField* zT_191;
    zT_E276DDD0_PackedBitField zT_192;
    unsigned int zT_193;
    zT_79FAE712_u64 zT_194;
    unsigned int zT_195;
    unsigned int zT_196;
    zT_79FAE712_u64 zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_79FAE712_u64 zT_204;
    zT_0163D9A4_ComptimeInt zT_205;
    zT_79FAE712_u64 zT_206;
    zT_0163D9A4_ComptimeInt zT_207 = {0};
    zT_89B1DDDA_ComptimeVal zT_208 = {0};
    zT_E53A25A2_Opt_203 zT_209;
    int zT_210;
    unsigned int zT_212;
    zT_E53A25A2_Opt_203 zT_213 = {0};
    unsigned int zT_214;
    unsigned int zT_215;
    zT_6B0A7D14_AstStore* zT_218;
    unsigned int zT_219;
    unsigned int zT_221 = 0;
    zT_DA663F79_ComptimeEval* zT_225;
    unsigned int zT_226;
    zT_6B0A7D14_AstStore* zT_227;
    unsigned int zT_228;
    unsigned int zT_232 = 0;
    zT_BAEE192E_Opt_10 zT_233 = {0};
    unsigned char zT_234;
    zT_338B7C76_TypeRegistry* zT_237;
    zT_D155D06D_Type* zT_238;
    unsigned int zT_239;
    zT_D155D06D_Type zT_240;
    unsigned char zT_241;
    unsigned int zT_245;
    zT_79FAE712_u64 zT_248;
    zT_33EF6BFB_TypeKind zT_249;
    unsigned char zT_253;
    unsigned char zT_254;
    zT_338B7C76_TypeRegistry* zT_259;
    unsigned int zT_260;
    unsigned int zT_262 = 0;
    zT_79FAE712_u64 zT_263;
    zT_33EF6BFB_TypeKind zT_264;
    zT_338B7C76_TypeRegistry* zT_268;
    unsigned int zT_269;
    unsigned int zT_271 = 0;
    zT_79FAE712_u64 zT_272;
    zT_338B7C76_TypeRegistry* zT_273;
    unsigned int zT_274;
    unsigned char zT_276 = 0;
    zT_338B7C76_TypeRegistry* zT_277;
    unsigned int zT_278;
    unsigned char zT_280 = 0;
    zT_79FAE712_u64 zT_281;
    zT_33EF6BFB_TypeKind zT_282;
    zT_338B7C76_TypeRegistry* zT_287;
    unsigned int zT_288;
    unsigned int zT_290 = 0;
    zT_338B7C76_TypeRegistry* zT_291;
    unsigned int zT_292;
    unsigned char zT_294 = 0;
    zT_79FAE712_u64 zT_295;
    zT_33EF6BFB_TypeKind zT_296;
    zT_79FAE712_u64 zT_300;
    zT_0163D9A4_ComptimeInt zT_301;
    zT_79FAE712_u64 zT_302;
    zT_0163D9A4_ComptimeInt zT_303 = {0};
    zT_89B1DDDA_ComptimeVal zT_304 = {0};
    zT_E53A25A2_Opt_203 zT_305;
    zT_E53A25A2_Opt_203 zT_306 = {0};
    unsigned int zT_307;
    unsigned int zT_308;
    unsigned char zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    zT_DA663F79_ComptimeEval* zT_315;
    unsigned int zT_316;
    zT_6B0A7D14_AstStore* zT_317;
    unsigned int zT_318;
    unsigned int zT_322 = 0;
    zT_BAEE192E_Opt_10 zT_323 = {0};
    zT_DA663F79_ComptimeEval* zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    zT_6B0A7D14_AstStore* zT_328;
    unsigned int zT_329;
    unsigned int zT_333 = 0;
    zT_E53A25A2_Opt_203 zT_334 = {0};
    unsigned char zT_335;
    unsigned char zT_337;
    unsigned char zT_339;
    zT_E53A25A2_Opt_203 zT_342 = {0};
    zT_338B7C76_TypeRegistry* zT_344;
    unsigned int zT_345;
    unsigned char zT_347 = 0;
    unsigned int zT_348;
    unsigned int zT_349;
    unsigned char zT_351;
    zT_E53A25A2_Opt_203 zT_353 = {0};
    unsigned char zT_354;
    zT_338B7C76_TypeRegistry* zT_355;
    zT_0163D9A4_ComptimeInt zT_356;
    unsigned int zT_357;
    zT_0163D9A4_ComptimeInt zT_359;
    unsigned char zT_360 = 0;
    zT_6F34EEB2_Opt_229 zT_362;
    unsigned char zT_363;
    zT_F85C5DED_DiagnosticCollector* zT_365;
    unsigned int zT_366;
    unsigned char zT_367 = 0;
    unsigned char* zT_369;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_370;
    unsigned int zT_371;
    unsigned int zT_372;
    unsigned int zT_373;
    unsigned char* zT_375;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_376;
    unsigned int zT_377;
    zT_F85C5DED_DiagnosticCollector* zT_378;
    unsigned int zT_382;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned int zT_393 = 0;
    zT_E53A25A2_Opt_203 zT_394 = {0};
    zT_338B7C76_TypeRegistry* zT_397;
    zT_D155D06D_Type* zT_398;
    unsigned int zT_399;
    zT_D155D06D_Type zT_400;
    unsigned int zT_402;
    unsigned int zT_405;
    int zT_406;
    zT_0163D9A4_ComptimeInt zT_409 = {0};
    zT_0163D9A4_ComptimeInt zT_410;
    zT_89B1DDDA_ComptimeVal zT_411 = {0};
    zT_E53A25A2_Opt_203 zT_412;
    zT_0163D9A4_ComptimeInt zT_416;
    zT_0163D9A4_ComptimeInt zT_417;
    zT_79FAE712_u64 zT_418 = 0;
    zT_79FAE712_u64 zT_424;
    zT_79FAE712_u64 zT_425;
    zT_0163D9A4_ComptimeInt zT_426;
    zT_79FAE712_u64 zT_427;
    zT_0163D9A4_ComptimeInt zT_428 = {0};
    zT_89B1DDDA_ComptimeVal zT_429 = {0};
    zT_E53A25A2_Opt_203 zT_430;
    zT_E53A25A2_Opt_203 zT_433;
    zT_E53A25A2_Opt_203 zT_434 = {0};
    unsigned int zT_435;
    unsigned int zT_436;
    unsigned char zT_438;
    zT_89B1DDDA_ComptimeVal zT_441 = {0};
    zT_E53A25A2_Opt_203 zT_442;
    zT_89B1DDDA_ComptimeVal zT_445 = {0};
    zT_E53A25A2_Opt_203 zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    unsigned char zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    zT_DA663F79_ComptimeEval* zT_455;
    unsigned int zT_456;
    unsigned int zT_457;
    zT_BCEE1C54_Opt_16 zT_458 = {0};
    unsigned char zT_459;
    zT_00435AEB_f64* zT_463;
    zT_79FAE712_u64* zT_464;
    zT_89B1DDDA_ComptimeVal zT_465;
    zT_0163D9A4_ComptimeInt zT_466 = {0};
    unsigned int zT_467;
    zT_79FAE712_u64 zT_468;
    zT_E53A25A2_Opt_203 zT_469;
    zT_E53A25A2_Opt_203 zT_470 = {0};
    zT_E53A25A2_Opt_203 zT_471 = {0};
    zT_22A7C88B_AstNode node;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    zT_D155D06D_Type ty;
    unsigned int ec2_n;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    unsigned char has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    unsigned int ec3_n;
    zT_BAEE192E_Opt_10 tid2;
    unsigned int t2;
    zT_D155D06D_Type ty2;
    zT_79FAE712_u64 bsz;
    unsigned int ebt;
    zT_E53A25A2_Opt_203 inner;
    zT_89B1DDDA_ComptimeVal cv;
    unsigned char is_int_t;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_msg;
    zT_D155D06D_Type nty;
    unsigned int nwb;
    zT_89B1DDDA_ComptimeVal outv;
    zT_0163D9A4_ComptimeInt zm;
    zT_79FAE712_u64 npat;
    zT_79FAE712_u64 nmask;
    zT_BCEE1C54_Opt_16 fv;
    zT_00435AEB_f64 v;
    zT_00435AEB_f64 fb;
    zT_79FAE712_u64* fbp;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.child_0;
    zT_9 = self->size_of_id;
    if ((unsigned char)(zT_8 == zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_14 = zF_152E19CB_astStoreNodeExtraCh(zT_11, zT_12);
    if ((unsigned char)(zT_14 != (unsigned int)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_46 = node.child_0;
    zT_47 = self->align_of_id;
    if ((unsigned char)(zT_46 == zT_47)) goto z_bb_9; else goto z_bb_10;
    z_bb_3:
    zT_17.has_value = 0;
    return zT_17;
    z_bb_4:
    zT_19 = self;
    zT_21 = self->store;
    zT_22 = node_idx;
    zT_26 = zF_B10B1BC1_astStoreNodeExtraCh(zT_21, zT_22, (unsigned int)(0));
    zT_20 = zT_26;
    zT_27 = zF_BAD6BA5D_comptimeEvalResolve(zT_19, zT_20);
    tid = zT_27;
    zT_28 = tid.has_value;
    if (zT_28) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    t = tid.value;
    zT_31 = self->registry;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)t;
    zT_34 = zT_32[zT_33];
    ty = zT_34;
    zT_35 = ty.state;
    if ((unsigned char)(zT_35 == (unsigned char)(2))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_45.has_value = 0;
    return zT_45;
    z_bb_7:
    zT_40 = ty.size;
    zT_42 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_40));
    zT_38 = zT_42;
    zT_43 = zF_237A4571_ciIntVal(zT_38);
    zT_44.has_value = 1;
    zT_44.value = zT_43;
    return zT_44;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_49 = self->store;
    zT_50 = node_idx;
    zT_52 = zF_152E19CB_astStoreNodeExtraCh(zT_49, zT_50);
    if ((unsigned char)(zT_52 != (unsigned int)(1))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_84 = node.child_0;
    zT_85 = self->offset_of_id;
    if ((unsigned char)(zT_84 == zT_85)) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    zT_55.has_value = 0;
    return zT_55;
    z_bb_12:
    zT_57 = self;
    zT_59 = self->store;
    zT_60 = node_idx;
    zT_64 = zF_B10B1BC1_astStoreNodeExtraCh(zT_59, zT_60, (unsigned int)(0));
    zT_58 = zT_64;
    zT_65 = zF_BAD6BA5D_comptimeEvalResolve(zT_57, zT_58);
    tid = zT_65;
    zT_66 = tid.has_value;
    if (zT_66) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    t = tid.value;
    zT_69 = self->registry;
    zT_70 = zT_69->types_items;
    zT_71 = (unsigned int)t;
    zT_72 = zT_70[zT_71];
    ty = zT_72;
    zT_73 = ty.state;
    if ((unsigned char)(zT_73 == (unsigned char)(2))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_83.has_value = 0;
    return zT_83;
    z_bb_15:
    zT_78 = ty.alignment;
    zT_80 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_78));
    zT_76 = zT_80;
    zT_81 = zF_237A4571_ciIntVal(zT_76);
    zT_82.has_value = 1;
    zT_82.value = zT_81;
    return zT_82;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_88 = node.child_0;
    zT_89 = self->bit_offset_of_id;
    zT_87 = zT_88 == zT_89;
    goto z_bb_19;
    z_bb_18:
    zT_87 = 1;
    goto z_bb_19;
    z_bb_19:
    if (zT_87) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_92 = self->store;
    zT_93 = node_idx;
    zT_95 = zF_152E19CB_astStoreNodeExtraCh(zT_92, zT_93);
    ec2_n = zT_95;
    if ((unsigned char)(ec2_n == (unsigned int)(2))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_214 = node.child_0;
    zT_215 = self->bit_size_of_id;
    if ((unsigned char)(zT_214 == zT_215)) goto z_bb_49; else goto z_bb_50;
    z_bb_22:
    zT_99 = self;
    zT_101 = self->store;
    zT_102 = node_idx;
    zT_106 = zF_B10B1BC1_astStoreNodeExtraCh(zT_101, zT_102, (unsigned int)(0));
    zT_100 = zT_106;
    zT_107 = zF_BAD6BA5D_comptimeEvalResolve(zT_99, zT_100);
    tid = zT_107;
    zT_108 = tid.has_value;
    if (zT_108) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    zT_213.has_value = 0;
    return zT_213;
    z_bb_24:
    t = tid.value;
    zT_111 = self->registry;
    zT_112 = zT_111->types_items;
    zT_113 = (unsigned int)t;
    zT_114 = zT_112[zT_113];
    ty = zT_114;
    zT_115 = ty.state;
    if ((unsigned char)(zT_115 == (unsigned char)(2))) goto z_bb_26; else goto z_bb_27;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_119 = ty.kind;
    zT_118 = zT_119 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_28;
    z_bb_27:
    zT_118 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_118) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    fields = zT_124;
    zT_125 = self->registry;
    zT_126 = t;
    zT_127 = &fields;
    zF_5A40A2EE_typeRegistryGetStru(zT_125, zT_126, zT_127);
    packed_fields = zT_131;
    zT_133 = self->registry;
    zT_134 = t;
    zT_135 = &packed_fields;
    zT_138 = zF_7D87247C_typeRegistryGetPack(zT_133, zT_134, zT_135);
    has_pk = zT_138;
    zT_140 = self->store;
    zT_143 = self->store;
    zT_144 = node_idx;
    zT_148 = zF_B10B1BC1_astStoreNodeExtraCh(zT_143, zT_144, (unsigned int)(1));
    zT_141 = zT_148;
    zT_149 = zF_FCDD1D35_astStoreNodeAt(zT_140, zT_141);
    fname_node = zT_149;
    zT_150 = fname_node.kind;
    if ((unsigned char)(zT_150 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_25;
    z_bb_31:
    zT_155 = self->store;
    zT_158 = self->store;
    zT_159 = node_idx;
    zT_163 = zF_B10B1BC1_astStoreNodeExtraCh(zT_158, zT_159, (unsigned int)(1));
    zT_156 = zT_163;
    zT_164 = zF_8BA26B9E_astStoreNodePayload(zT_155, zT_156);
    sv_idx = zT_164;
    zT_166 = self->store;
    zT_167 = zT_166->string_values;
    zT_168 = zT_167.items;
    zT_169 = (unsigned int)sv_idx;
    zT_170 = zT_168[zT_169];
    want_id = zT_170;
    zT_172 = 0;
    zT_173 = (unsigned int)zT_172;
    fi = zT_173;
    goto z_bb_33;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_175 = fields.len;
    if ((unsigned char)(fi < zT_175)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_177 = fields.ptr;
    zT_178 = zT_177[fi];
    zT_179 = zT_178.name_id;
    if ((unsigned char)(zT_179 == want_id)) goto z_bb_37; else goto z_bb_38;
    z_bb_35:
    goto z_bb_32;
    z_bb_36:
    zT_210 = 1;
    zT_212 = fi + (unsigned int)((unsigned int)zT_210);
    fi = zT_212;
    goto z_bb_33;
    z_bb_37:
    zT_182 = fields.ptr;
    zT_183 = zT_182[fi];
    zT_184 = zT_183.offset;
    zT_185 = (zT_79FAE712_u64)zT_184;
    bo = zT_185;
    if (has_pk) goto z_bb_39; else goto z_bb_41;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    zT_187 = 0;
    pk_bo = zT_187;
    zT_189 = packed_fields.len;
    if ((unsigned char)(fi < zT_189)) goto z_bb_42; else goto z_bb_43;
    z_bb_40:
    zT_206 = bo;
    zT_207 = zF_1EAA44E6_ciFromU64(zT_206);
    zT_205 = zT_207;
    zT_208 = zF_237A4571_ciIntVal(zT_205);
    zT_209.has_value = 1;
    zT_209.value = zT_208;
    return zT_209;
    z_bb_41:
    zT_200 = node.child_0;
    zT_201 = self->bit_offset_of_id;
    if ((unsigned char)(zT_200 == zT_201)) goto z_bb_47; else goto z_bb_48;
    z_bb_42:
    zT_191 = packed_fields.ptr;
    zT_192 = zT_191[fi];
    zT_193 = zT_192.bit_offset;
    zT_194 = (zT_79FAE712_u64)zT_193;
    pk_bo = zT_194;
    goto z_bb_43;
    z_bb_43:
    zT_195 = node.child_0;
    zT_196 = self->bit_offset_of_id;
    if ((unsigned char)(zT_195 == zT_196)) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    bo = pk_bo;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_40;
    z_bb_46:
    zT_199 = pk_bo / (zT_79FAE712_u64)(8);
    bo = zT_199;
    goto z_bb_45;
    z_bb_47:
    zT_204 = bo * (zT_79FAE712_u64)(8);
    bo = zT_204;
    goto z_bb_48;
    z_bb_48:
    goto z_bb_40;
    z_bb_49:
    zT_218 = self->store;
    zT_219 = node_idx;
    zT_221 = zF_152E19CB_astStoreNodeExtraCh(zT_218, zT_219);
    ec3_n = zT_221;
    if ((unsigned char)(ec3_n >= (unsigned int)(1))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_307 = node.child_0;
    zT_308 = self->int_cast_id;
    if ((unsigned char)(zT_307 == zT_308)) goto z_bb_71; else goto z_bb_70;
    z_bb_51:
    zT_225 = self;
    zT_227 = self->store;
    zT_228 = node_idx;
    zT_232 = zF_B10B1BC1_astStoreNodeExtraCh(zT_227, zT_228, (unsigned int)(0));
    zT_226 = zT_232;
    zT_233 = zF_BAD6BA5D_comptimeEvalResolve(zT_225, zT_226);
    tid2 = zT_233;
    zT_234 = tid2.has_value;
    if (zT_234) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_306.has_value = 0;
    return zT_306;
    z_bb_53:
    t2 = tid2.value;
    zT_237 = self->registry;
    zT_238 = zT_237->types_items;
    zT_239 = (unsigned int)t2;
    zT_240 = zT_238[zT_239];
    ty2 = zT_240;
    zT_241 = ty2.state;
    if ((unsigned char)(zT_241 == (unsigned char)(2))) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_245 = ty2.size;
    zT_248 = (zT_79FAE712_u64)((zT_79FAE712_u64)zT_245) * (zT_79FAE712_u64)(8);
    bsz = zT_248;
    zT_249 = ty2.kind;
    if ((unsigned char)(zT_249 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    goto z_bb_54;
    z_bb_57:
    zT_254 = ty2.flags;
    zT_253 = (unsigned char)(zT_254 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_59;
    z_bb_58:
    zT_253 = 0;
    goto z_bb_59;
    z_bb_59:
    if (zT_253) goto z_bb_60; else goto z_bb_61;
    z_bb_60:
    zT_259 = self->registry;
    zT_260 = t2;
    zT_262 = zF_CB27DBA4_typeRegistryGetPack(zT_259, zT_260);
    zT_263 = (zT_79FAE712_u64)zT_262;
    bsz = zT_263;
    goto z_bb_61;
    z_bb_61:
    zT_264 = ty2.kind;
    if ((unsigned char)(zT_264 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_268 = self->registry;
    zT_269 = t2;
    zT_271 = zF_B80C4365_typeRegistryGetPack(zT_268, zT_269);
    zT_272 = (zT_79FAE712_u64)zT_271;
    bsz = zT_272;
    goto z_bb_63;
    z_bb_63:
    zT_273 = self->registry;
    zT_274 = t2;
    zT_276 = zF_3290E9C4_typeRegistryIsInteg(zT_273, zT_274);
    if (zT_276) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_277 = self->registry;
    zT_278 = t2;
    zT_280 = zF_655972D5_typeRegistryIntWidt(zT_277, zT_278);
    zT_281 = (zT_79FAE712_u64)zT_280;
    bsz = zT_281;
    goto z_bb_65;
    z_bb_65:
    zT_282 = ty2.kind;
    if ((unsigned char)(zT_282 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    zT_287 = self->registry;
    zT_288 = t2;
    zT_290 = zF_014D7530_typeRegistryEnumBac(zT_287, zT_288);
    ebt = zT_290;
    zT_291 = self->registry;
    zT_292 = ebt;
    zT_294 = zF_655972D5_typeRegistryIntWidt(zT_291, zT_292);
    zT_295 = (zT_79FAE712_u64)zT_294;
    bsz = zT_295;
    goto z_bb_67;
    z_bb_67:
    zT_296 = ty2.kind;
    if ((unsigned char)(zT_296 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_300 = 1;
    bsz = zT_300;
    goto z_bb_69;
    z_bb_69:
    zT_302 = bsz;
    zT_303 = zF_1EAA44E6_ciFromU64(zT_302);
    zT_301 = zT_303;
    zT_304 = zF_237A4571_ciIntVal(zT_301);
    zT_305.has_value = 1;
    zT_305.value = zT_304;
    return zT_305;
    z_bb_70:
    zT_311 = node.child_0;
    zT_312 = self->as_id;
    zT_310 = zT_311 == zT_312;
    goto z_bb_72;
    z_bb_71:
    zT_310 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_310) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_315 = self;
    zT_317 = self->store;
    zT_318 = node_idx;
    zT_322 = zF_B10B1BC1_astStoreNodeExtraCh(zT_317, zT_318, (unsigned int)(0));
    zT_316 = zT_322;
    zT_323 = zF_BAD6BA5D_comptimeEvalResolve(zT_315, zT_316);
    tid = zT_323;
    zT_325 = self;
    zT_328 = self->store;
    zT_329 = node_idx;
    zT_333 = zF_B10B1BC1_astStoreNodeExtraCh(zT_328, zT_329, (unsigned int)(1));
    zT_326 = zT_333;
    zT_327 = depth;
    zT_334 = zF_4EE17137_comptimeEvalEvaluat(zT_325, zT_326, zT_327);
    inner = zT_334;
    zT_335 = tid.has_value;
    if (zT_335) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    zT_435 = node.child_0;
    zT_436 = self->is_windows_id;
    if ((unsigned char)(zT_435 == zT_436)) goto z_bb_103; else goto z_bb_104;
    z_bb_75:
    t = tid.value;
    zT_337 = inner.has_value;
    if (zT_337) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    zT_434.has_value = 0;
    return zT_434;
    z_bb_77:
    cv = inner.value;
    zT_339 = cv.kind;
    if ((unsigned char)(zT_339 == (unsigned int)(2))) goto z_bb_79; else goto z_bb_80;
    z_bb_78:
    goto z_bb_76;
    z_bb_79:
    zT_342.has_value = 0;
    return zT_342;
    z_bb_80:
    zT_344 = self->registry;
    zT_345 = t;
    zT_347 = zF_3290E9C4_typeRegistryIsInteg(zT_344, zT_345);
    is_int_t = zT_347;
    zT_348 = node.child_0;
    zT_349 = self->as_id;
    if ((unsigned char)(zT_348 == zT_349)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_351 = !is_int_t;
    goto z_bb_83;
    z_bb_82:
    zT_351 = 0;
    goto z_bb_83;
    z_bb_83:
    if (zT_351) goto z_bb_84; else goto z_bb_85;
    z_bb_84:
    zT_353.has_value = 0;
    return zT_353;
    z_bb_85:
    if (is_int_t) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_355 = self->registry;
    zT_359 = cv.v;
    zT_356 = zT_359;
    zT_357 = t;
    zT_360 = zF_B28C4720_comptimeIntFitsType(zT_355, zT_356, zT_357);
    zT_354 = !zT_360;
    goto z_bb_88;
    z_bb_87:
    zT_354 = 0;
    goto z_bb_88;
    z_bb_88:
    if (zT_354) goto z_bb_89; else goto z_bb_90;
    z_bb_89:
    zT_362 = self->diag;
    zT_363 = zT_362.has_value;
    if (zT_363) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    if ((unsigned char)(!is_int_t)) goto z_bb_97; else goto z_bb_98;
    z_bb_91:
    dg = zT_362.value;
    zT_365 = dg;
    zT_366 = node_idx;
    zT_367 = zF_4DD9DB2D_diagnosticCollector(zT_365, zT_366);
    if (zT_367) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_394.has_value = 0;
    return zT_394;
    z_bb_93:
    zT_369 = "@intCast value does not fit the target type";
    zT_371 = 43;
    zT_370.ptr = zT_369;
    zT_370.len = zT_371;
    ic_msg = zT_370;
    zT_372 = node.child_0;
    zT_373 = self->as_id;
    if ((unsigned char)(zT_372 == zT_373)) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    zT_375 = "@as value does not fit the target type";
    zT_377 = 38;
    zT_376.ptr = zT_375;
    zT_376.len = zT_377;
    ic_msg = zT_376;
    goto z_bb_96;
    z_bb_96:
    zT_378 = dg;
    zT_382 = node.span_start;
    zT_389 = node.span_start;
    zT_390 = node.span_len;
    zT_384 = ic_msg;
    zT_393 = zF_C82559AC_diagnosticCollector(zT_378, (unsigned char)(0), (unsigned short)(3000), (unsigned int)(0), zT_382, (unsigned int)(zT_389 + (unsigned int)((unsigned int)zT_390)), zT_384);
    (void)zT_393;
    goto z_bb_94;
    z_bb_97:
    zT_397 = self->registry;
    zT_398 = zT_397->types_items;
    zT_399 = (unsigned int)t;
    zT_400 = zT_398[zT_399];
    nty = zT_400;
    zT_402 = nty.size;
    zT_405 = (unsigned int)((unsigned int)zT_402) * (unsigned int)(8);
    nwb = zT_405;
    zT_406 = 0;
    if ((unsigned char)(nwb == (unsigned int)zT_406)) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    outv = cv;
    outv.kind = (unsigned int)(0);
    zT_433.has_value = 1;
    zT_433.value = outv;
    return zT_433;
    z_bb_99:
    zT_409 = zF_DC9B7BC0_ciZeroInt();
    zm = zT_409;
    zT_410 = zm;
    zT_411 = zF_237A4571_ciIntVal(zT_410);
    zT_412.has_value = 1;
    zT_412.value = zT_411;
    return zT_412;
    z_bb_100:
    if ((unsigned char)(nwb < (unsigned int)(64))) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_417 = cv.v;
    zT_416 = zT_417;
    zT_418 = zF_4F2C9C5D_ciToU64(zT_416);
    npat = zT_418;
    zT_424 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)nwb)) - (zT_79FAE712_u64)(1);
    nmask = zT_424;
    zT_425 = npat & nmask;
    npat = zT_425;
    zT_427 = npat;
    zT_428 = zF_1EAA44E6_ciFromU64(zT_427);
    zT_426 = zT_428;
    zT_429 = zF_237A4571_ciIntVal(zT_426);
    zT_430.has_value = 1;
    zT_430.value = zT_429;
    return zT_430;
    z_bb_102:
    goto z_bb_98;
    z_bb_103:
    zT_438 = self->host_is_windows;
    if (zT_438) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_447 = node.child_0;
    zT_448 = self->int_to_float_id;
    if ((unsigned char)(zT_447 == zT_448)) goto z_bb_108; else goto z_bb_107;
    z_bb_105:
    zT_441 = zF_E867E750_ciBoolVal((unsigned char)(1));
    zT_442.has_value = 1;
    zT_442.value = zT_441;
    return zT_442;
    z_bb_106:
    zT_445 = zF_E867E750_ciBoolVal((unsigned char)(0));
    zT_446.has_value = 1;
    zT_446.value = zT_445;
    return zT_446;
    z_bb_107:
    zT_451 = node.child_0;
    zT_452 = self->float_cast_id;
    zT_450 = zT_451 == zT_452;
    goto z_bb_109;
    z_bb_108:
    zT_450 = 1;
    goto z_bb_109;
    z_bb_109:
    if (zT_450) goto z_bb_110; else goto z_bb_111;
    z_bb_110:
    zT_455 = self;
    zT_456 = node_idx;
    zT_457 = depth;
    zT_458 = zF_8C4B1954_comptimeEvalFloatBu(zT_455, zT_456, zT_457);
    fv = zT_458;
    zT_459 = fv.has_value;
    if (zT_459) goto z_bb_112; else goto z_bb_113;
    z_bb_111:
    zT_471.has_value = 0;
    return zT_471;
    z_bb_112:
    v = fv.value;
    fb = v;
    zT_463 = &fb;
    zT_464 = (zT_79FAE712_u64*)zT_463;
    fbp = zT_464;
    zT_466 = zF_DC9B7BC0_ciZeroInt();
    zT_465.v = zT_466;
    zT_467 = 2;
    zT_465.kind = zT_467;
    zT_468 = *fbp;
    zT_465.float_bits = zT_468;
    zT_469.has_value = 1;
    zT_469.value = zT_465;
    return zT_469;
    z_bb_113:
    zT_470.has_value = 0;
    return zT_470;
}

/* comptimeEvalFloat */
zT_BCEE1C54_Opt_16 zF_B719EB81_comptimeEvalFloat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_BCEE1C54_Opt_16 zT_5 = {0};
    zT_BCEE1C54_Opt_16 zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_18;
    zT_3C26AE5C_anon_274188 zT_19;
    zT_00435AEB_f64* zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    unsigned int zT_25;
    zT_00435AEB_f64 zT_26;
    zT_BCEE1C54_Opt_16 zT_27;
    zT_8143F551_AstKind zT_28;
    zT_DA663F79_ComptimeEval* zT_33;
    unsigned int zT_34;
    zT_BCEE1C54_Opt_16 zT_39 = {0};
    unsigned char zT_40;
    zT_00435AEB_f64 zT_42;
    zT_BCEE1C54_Opt_16 zT_43;
    zT_BCEE1C54_Opt_16 zT_44 = {0};
    zT_8143F551_AstKind zT_45;
    zT_DA663F79_ComptimeEval* zT_49;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_8143F551_AstKind zT_56;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_DA663F79_ComptimeEval* zT_67;
    unsigned int zT_68;
    zT_BCEE1C54_Opt_16 zT_72 = {0};
    zT_BCEE1C54_Opt_16 zT_73 = {0};
    zT_8143F551_AstKind zT_74;
    zT_6B0A7D14_AstStore* zT_79;
    unsigned int zT_80;
    unsigned int zT_82 = 0;
    zT_05CE5599_Opt_400 zT_83;
    unsigned char zT_84;
    zT_E2DF2801_LocalConstScope* zT_86;
    unsigned int zT_87;
    zT_BAEE192E_Opt_10 zT_88 = {0};
    unsigned char zT_89;
    zT_6B0A7D14_AstStore* zT_92;
    unsigned int zT_93;
    zT_22A7C88B_AstNode zT_95 = {0};
    unsigned int zT_96;
    zT_DA663F79_ComptimeEval* zT_100;
    unsigned int zT_101;
    zT_BCEE1C54_Opt_16 zT_106 = {0};
    unsigned char zT_107;
    zT_DA663F79_ComptimeEval* zT_110;
    unsigned int zT_111;
    zT_BAEE192E_Opt_10 zT_113 = {0};
    unsigned char zT_114;
    float zT_119;
    zT_00435AEB_f64 zT_120;
    zT_BCEE1C54_Opt_16 zT_121;
    zT_BCEE1C54_Opt_16 zT_122;
    zT_BCEE1C54_Opt_16 zT_123 = {0};
    int zT_125;
    unsigned int zT_126;
    zT_3D7259E2_SymbolRegistry* zT_127;
    unsigned int zT_128;
    zT_3D7259E2_SymbolRegistry* zT_132;
    unsigned int zT_134;
    zT_557B6199_Opt_875 zT_137 = {0};
    unsigned char zT_138;
    unsigned short zT_140;
    zT_6B0A7D14_AstStore* zT_146;
    unsigned int zT_147;
    zT_22A7C88B_AstNode zT_150 = {0};
    unsigned int zT_151;
    zT_DA663F79_ComptimeEval* zT_155;
    unsigned int zT_156;
    zT_BCEE1C54_Opt_16 zT_161 = {0};
    unsigned char zT_162;
    zT_DA663F79_ComptimeEval* zT_165;
    unsigned int zT_166;
    zT_BAEE192E_Opt_10 zT_168 = {0};
    unsigned char zT_169;
    float zT_174;
    zT_00435AEB_f64 zT_175;
    zT_BCEE1C54_Opt_16 zT_176;
    zT_BCEE1C54_Opt_16 zT_177;
    zT_BCEE1C54_Opt_16 zT_178 = {0};
    int zT_179;
    unsigned int zT_181;
    zT_BCEE1C54_Opt_16 zT_182 = {0};
    zT_BCEE1C54_Opt_16 zT_183 = {0};
    zT_22A7C88B_AstNode node;
    zT_BCEE1C54_Opt_16 inner;
    zT_00435AEB_f64 fv;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_BCEE1C54_Opt_16 lin;
    zT_00435AEB_f64 lfv;
    zT_BAEE192E_Opt_10 ldt;
    unsigned int lt;
    float lf32;
    zT_557B6199_Opt_875 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_BAEE192E_Opt_10 dt;
    unsigned int t;
    float f32v;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_18 = self->store;
    zT_19 = zT_18->float_values;
    zT_20 = zT_19.items;
    zT_21 = self->store;
    zT_22 = node_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_20[zT_25];
    zT_27.has_value = 1;
    zT_27.value = zT_26;
    return zT_27;
    z_bb_6:
    { zT_BCEE1C54_Opt_16 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_7:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_33 = self;
    zT_34 = node.child_0;
    zT_39 = zF_B719EB81_comptimeEvalFloat(zT_33, zT_34, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_39;
    zT_40 = inner.has_value;
    if (zT_40) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_45 = node.kind;
    if ((unsigned char)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    fv = inner.value;
    zT_42 = -fv;
    zT_43.has_value = 1;
    zT_43.value = zT_42;
    return zT_43;
    z_bb_12:
    zT_44.has_value = 0;
    return zT_44;
    z_bb_13:
    zT_49 = self;
    zT_52 = node.child_0;
    zT_54 = depth + (unsigned int)(1);
    self = zT_49;
    node_idx = zT_52;
    depth = zT_54;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_56 = node.kind;
    if ((unsigned char)(zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_60 = node.child_0;
    zT_61 = self->int_to_float_id;
    if ((unsigned char)(zT_60 == zT_61)) goto z_bb_20; else goto z_bb_19;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_74 = node.kind;
    if ((unsigned char)(zT_74 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_24; else goto z_bb_26;
    z_bb_19:
    zT_64 = node.child_0;
    zT_65 = self->float_cast_id;
    zT_63 = zT_64 == zT_65;
    goto z_bb_21;
    z_bb_20:
    zT_63 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_63) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_67 = self;
    zT_68 = node_idx;
    zT_72 = zF_8C4B1954_comptimeEvalFloatBu(zT_67, zT_68, (unsigned int)(depth + (unsigned int)(1)));
    return zT_72;
    z_bb_23:
    zT_73.has_value = 0;
    return zT_73;
    z_bb_24:
    zT_79 = self->store;
    zT_80 = node_idx;
    zT_82 = zF_53458827_astStoreIdentifier(zT_79, zT_80);
    name_id = zT_82;
    zT_83 = self->local_consts;
    zT_84 = zT_83.has_value;
    if (zT_84) goto z_bb_27; else goto z_bb_28;
    goto z_bb_17;
    z_bb_26:
    zT_183.has_value = 0;
    return zT_183;
    z_bb_27:
    lcs = zT_83.value;
    zT_86 = lcs;
    zT_87 = name_id;
    zT_88 = zF_6532C387_localConstScopeLook(zT_86, zT_87);
    zT_89 = zT_88.has_value;
    if (zT_89) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_125 = 0;
    zT_126 = (unsigned int)zT_125;
    mi = zT_126;
    goto z_bb_39;
    z_bb_29:
    l_decl_node = zT_88.value;
    zT_92 = self->store;
    zT_93 = l_decl_node;
    zT_95 = zF_FCDD1D35_astStoreNodeAt(zT_92, zT_93);
    l_decl = zT_95;
    zT_96 = l_decl.child_1;
    if ((unsigned char)(zT_96 != (unsigned int)(0))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_100 = self;
    zT_101 = l_decl.child_1;
    zT_106 = zF_B719EB81_comptimeEvalFloat(zT_100, zT_101, (unsigned int)(depth + (unsigned int)(1)));
    lin = zT_106;
    zT_107 = lin.has_value;
    if (zT_107) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    lfv = lin.value;
    zT_110 = self;
    zT_111 = l_decl.child_0;
    zT_113 = zF_BAD6BA5D_comptimeEvalResolve(zT_110, zT_111);
    ldt = zT_113;
    zT_114 = ldt.has_value;
    if (zT_114) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_123.has_value = 0;
    return zT_123;
    z_bb_35:
    lt = ldt.value;
    if ((unsigned char)(lt == (unsigned int)(15))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_122.has_value = 1;
    zT_122.value = lfv;
    return zT_122;
    z_bb_37:
    zT_119 = (float)lfv;
    lf32 = zT_119;
    zT_120 = (zT_00435AEB_f64)lf32;
    zT_121.has_value = 1;
    zT_121.value = zT_120;
    return zT_121;
    z_bb_38:
    goto z_bb_36;
    z_bb_39:
    zT_127 = self->symbol_reg;
    zT_128 = zT_127->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_128))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_132 = self->symbol_reg;
    zT_134 = name_id;
    zT_137 = zF_A398987E_symbolRegistryQuali(zT_132, (unsigned int)((unsigned int)mi), zT_134);
    c_sym = zT_137;
    zT_138 = c_sym.has_value;
    if (zT_138) goto z_bb_43; else goto z_bb_44;
    z_bb_41:
    zT_182.has_value = 0;
    return zT_182;
    z_bb_42:
    zT_179 = 1;
    zT_181 = mi + (unsigned int)((unsigned int)zT_179);
    mi = zT_181;
    goto z_bb_39;
    z_bb_43:
    cs = c_sym.value;
    zT_140 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_140 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_146 = self->store;
    zT_147 = cs->decl_node;
    zT_150 = zF_FCDD1D35_astStoreNodeAt(zT_146, zT_147);
    c_decl = zT_150;
    zT_151 = c_decl.child_1;
    if ((unsigned char)(zT_151 != (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_44;
    z_bb_47:
    zT_155 = self;
    zT_156 = c_decl.child_1;
    zT_161 = zF_B719EB81_comptimeEvalFloat(zT_155, zT_156, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_161;
    zT_162 = inner.has_value;
    if (zT_162) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    fv = inner.value;
    zT_165 = self;
    zT_166 = c_decl.child_0;
    zT_168 = zF_BAD6BA5D_comptimeEvalResolve(zT_165, zT_166);
    dt = zT_168;
    zT_169 = dt.has_value;
    if (zT_169) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_178.has_value = 0;
    return zT_178;
    z_bb_51:
    t = dt.value;
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_177.has_value = 1;
    zT_177.value = fv;
    return zT_177;
    z_bb_53:
    zT_174 = (float)fv;
    f32v = zT_174;
    zT_175 = (zT_00435AEB_f64)f32v;
    zT_176.has_value = 1;
    zT_176.value = zT_175;
    return zT_176;
    z_bb_54:
    goto z_bb_52;
}

/* comptimeEvalFloatBuiltin */
zT_BCEE1C54_Opt_16 zF_8C4B1954_comptimeEvalFloatBu(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_DA663F79_ComptimeEval* zT_9;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    unsigned int zT_16 = 0;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    unsigned char zT_18;
    unsigned char zT_22;
    zT_BCEE1C54_Opt_16 zT_25 = {0};
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_32 = 0;
    zT_00435AEB_f64 zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_DA663F79_ComptimeEval* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    zT_E53A25A2_Opt_203 zT_42 = {0};
    unsigned char zT_43;
    unsigned char zT_45;
    zT_BCEE1C54_Opt_16 zT_48 = {0};
    unsigned char zT_49;
    zT_0163D9A4_ComptimeInt zT_52;
    zT_0163D9A4_ComptimeInt zT_53;
    unsigned char zT_54 = 0;
    zT_00435AEB_f64 zT_55;
    zT_00435AEB_f64 zT_56;
    zT_0163D9A4_ComptimeInt zT_57;
    zT_0163D9A4_ComptimeInt zT_58;
    zT_00435AEB_f64 zT_59 = 0;
    zT_BCEE1C54_Opt_16 zT_60 = {0};
    unsigned int zT_61;
    unsigned int zT_62;
    zT_DA663F79_ComptimeEval* zT_65;
    unsigned int zT_66;
    unsigned int zT_67;
    zT_BCEE1C54_Opt_16 zT_68 = {0};
    unsigned char zT_69;
    zT_BCEE1C54_Opt_16 zT_71 = {0};
    zT_BCEE1C54_Opt_16 zT_72 = {0};
    float zT_76;
    zT_00435AEB_f64 zT_77;
    zT_BCEE1C54_Opt_16 zT_78;
    zT_BCEE1C54_Opt_16 zT_79;
    zT_BCEE1C54_Opt_16 zT_80 = {0};
    zT_22A7C88B_AstNode node;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    unsigned int inner_idx;
    zT_00435AEB_f64 fv;
    zT_E53A25A2_Opt_203 iv;
    zT_89B1DDDA_ComptimeVal cv;
    zT_BCEE1C54_Opt_16 xv;
    zT_00435AEB_f64 x;
    float f32v;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_16 = zF_B10B1BC1_astStoreNodeExtraCh(zT_11, zT_12, (unsigned int)(0));
    zT_10 = zT_16;
    zT_17 = zF_BAD6BA5D_comptimeEvalResolve(zT_9, zT_10);
    tid = zT_17;
    zT_18 = tid.has_value;
    if (zT_18) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    t = tid.value;
    if ((unsigned char)(t != (unsigned int)(15))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_80.has_value = 0;
    return zT_80;
    z_bb_3:
    zT_22 = t != (unsigned int)(16);
    goto z_bb_5;
    z_bb_4:
    zT_22 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_22) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_7:
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_32 = zF_B10B1BC1_astStoreNodeExtraCh(zT_27, zT_28, (unsigned int)(1));
    inner_idx = zT_32;
    zT_34 = 0;
    fv = zT_34;
    zT_35 = node.child_0;
    zT_36 = self->int_to_float_id;
    if ((unsigned char)(zT_35 == zT_36)) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_39 = self;
    zT_40 = inner_idx;
    zT_41 = depth;
    zT_42 = zF_4EE17137_comptimeEvalEvaluat(zT_39, zT_40, zT_41);
    iv = zT_42;
    zT_43 = iv.has_value;
    if (zT_43) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_28; else goto z_bb_29;
    z_bb_10:
    zT_61 = node.child_0;
    zT_62 = self->float_cast_id;
    if ((unsigned char)(zT_61 == zT_62)) goto z_bb_22; else goto z_bb_24;
    z_bb_11:
    cv = iv.value;
    zT_45 = cv.kind;
    if ((unsigned char)(zT_45 == (unsigned int)(2))) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_60.has_value = 0;
    return zT_60;
    z_bb_14:
    zT_48.has_value = 0;
    return zT_48;
    z_bb_15:
    zT_49 = cv.kind;
    if ((unsigned char)(zT_49 == (unsigned int)(1))) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_53 = cv.v;
    zT_52 = zT_53;
    zT_54 = zF_0F5FA15F_ciIsZero(zT_52);
    if (zT_54) goto z_bb_19; else goto z_bb_21;
    z_bb_17:
    goto z_bb_12;
    z_bb_18:
    zT_58 = cv.v;
    zT_57 = zT_58;
    zT_59 = zF_E6CE9168_ciToF64(zT_57);
    fv = zT_59;
    goto z_bb_17;
    z_bb_19:
    zT_55 = 0;
    fv = zT_55;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_56 = 1e+0;
    fv = zT_56;
    goto z_bb_20;
    z_bb_22:
    zT_65 = self;
    zT_66 = inner_idx;
    zT_67 = depth;
    zT_68 = zF_B719EB81_comptimeEvalFloat(zT_65, zT_66, zT_67);
    xv = zT_68;
    zT_69 = xv.has_value;
    if (zT_69) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    goto z_bb_9;
    z_bb_24:
    zT_72.has_value = 0;
    return zT_72;
    z_bb_25:
    x = xv.value;
    fv = x;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_23;
    z_bb_27:
    zT_71.has_value = 0;
    return zT_71;
    z_bb_28:
    zT_76 = (float)fv;
    f32v = zT_76;
    zT_77 = (zT_00435AEB_f64)f32v;
    zT_78.has_value = 1;
    zT_78.value = zT_77;
    return zT_78;
    z_bb_29:
    zT_79.has_value = 1;
    zT_79.value = fv;
    return zT_79;
}

/* floatNarrowNone */
zT_66B68F69_FloatNarrowVal zF_6AEE4E20_floatNarrowNone(void) {
    zT_66B68F69_FloatNarrowVal zT_0;
    unsigned char zT_1;
    unsigned char zT_2;
    zT_00435AEB_f64 zT_3;
    zT_1 = 0;
    zT_0.ok = zT_1;
    zT_2 = 0;
    zT_0.typed = zT_2;
    zT_3 = 0;
    zT_0.v = zT_3;
    return zT_0;
}

/* comptimeEvalFloatNarrow */
zT_66B68F69_FloatNarrowVal zF_213A0C7E_comptimeEvalFloatNa(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    zT_66B68F69_FloatNarrowVal zT_6 = {0};
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_0DB56784_floatNarrowProbe(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* floatNarrowProbe */
zT_66B68F69_FloatNarrowVal zF_0DB56784_floatNarrowProbe(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_66B68F69_FloatNarrowVal zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_19;
    zT_3C26AE5C_anon_274188 zT_20;
    zT_00435AEB_f64* zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    unsigned int zT_26;
    zT_00435AEB_f64 zT_27;
    zT_8143F551_AstKind zT_28;
    unsigned char zT_32;
    zT_8143F551_AstKind zT_33;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_79FAE712_u64 zT_41 = 0;
    zT_8143F551_AstKind zT_43;
    unsigned char zT_47;
    zT_8143F551_AstKind zT_48;
    zT_DA663F79_ComptimeEval* zT_52;
    unsigned int zT_53;
    zT_66B68F69_FloatNarrowVal zT_58 = {0};
    unsigned char zT_59;
    zT_8143F551_AstKind zT_61;
    zT_00435AEB_f64 zT_65;
    zT_8143F551_AstKind zT_67;
    unsigned char zT_71;
    zT_8143F551_AstKind zT_72;
    unsigned char zT_76;
    zT_8143F551_AstKind zT_77;
    unsigned char zT_81;
    zT_8143F551_AstKind zT_82;
    zT_DA663F79_ComptimeEval* zT_87;
    unsigned int zT_88;
    zT_66B68F69_FloatNarrowVal zT_93 = {0};
    unsigned char zT_94;
    zT_DA663F79_ComptimeEval* zT_97;
    unsigned int zT_98;
    zT_66B68F69_FloatNarrowVal zT_103 = {0};
    unsigned char zT_104;
    unsigned char zT_107;
    unsigned char zT_108;
    zT_8143F551_AstKind zT_110;
    zT_00435AEB_f64 zT_114;
    zT_00435AEB_f64 zT_115;
    zT_8143F551_AstKind zT_117;
    zT_00435AEB_f64 zT_121;
    zT_00435AEB_f64 zT_122;
    zT_8143F551_AstKind zT_124;
    zT_00435AEB_f64 zT_128;
    zT_00435AEB_f64 zT_129;
    zT_8143F551_AstKind zT_131;
    zT_00435AEB_f64 zT_135;
    zT_66B68F69_FloatNarrowVal zT_138 = {0};
    zT_00435AEB_f64 zT_139;
    zT_00435AEB_f64 zT_140;
    zT_8143F551_AstKind zT_142;
    zT_6B0A7D14_AstStore* zT_147;
    unsigned int zT_148;
    unsigned int zT_150 = 0;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned char zT_156;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned char zT_160;
    unsigned int zT_162;
    unsigned int zT_163;
    unsigned char zT_164;
    unsigned char zT_166;
    unsigned char zT_168;
    unsigned char zT_170;
    zT_DA663F79_ComptimeEval* zT_171;
    unsigned int zT_172;
    zT_BCEE1C54_Opt_16 zT_176 = {0};
    unsigned char zT_177;
    zT_DA663F79_ComptimeEval* zT_182;
    unsigned int zT_183;
    zT_6B0A7D14_AstStore* zT_184;
    unsigned int zT_185;
    unsigned int zT_189 = 0;
    zT_BAEE192E_Opt_10 zT_190 = {0};
    unsigned char zT_191;
    unsigned char zT_195;
    zT_6B0A7D14_AstStore* zT_201;
    unsigned int zT_202;
    unsigned int zT_206 = 0;
    zT_00435AEB_f64 zT_208;
    zT_DA663F79_ComptimeEval* zT_209;
    unsigned int zT_210;
    zT_E53A25A2_Opt_203 zT_214 = {0};
    unsigned char zT_215;
    unsigned char zT_217;
    zT_89B1DDDA_ComptimeVal zT_220;
    zT_00435AEB_f64 zT_221 = 0;
    unsigned char zT_222;
    zT_0163D9A4_ComptimeInt zT_225;
    zT_0163D9A4_ComptimeInt zT_226;
    zT_00435AEB_f64 zT_227 = 0;
    unsigned char zT_228;
    zT_0163D9A4_ComptimeInt zT_231;
    zT_0163D9A4_ComptimeInt zT_232;
    unsigned char zT_233 = 0;
    zT_00435AEB_f64 zT_235;
    zT_DA663F79_ComptimeEval* zT_237;
    unsigned int zT_238;
    zT_66B68F69_FloatNarrowVal zT_242 = {0};
    unsigned char zT_243;
    zT_00435AEB_f64 zT_245;
    float zT_249;
    zT_00435AEB_f64 zT_250;
    zT_8143F551_AstKind zT_253;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    unsigned int zT_261 = 0;
    zT_05CE5599_Opt_400 zT_262;
    unsigned char zT_263;
    zT_E2DF2801_LocalConstScope* zT_265;
    unsigned int zT_266;
    zT_BAEE192E_Opt_10 zT_267 = {0};
    unsigned char zT_268;
    zT_DA663F79_ComptimeEval* zT_270;
    unsigned int zT_271;
    zT_66B68F69_FloatNarrowVal zT_275 = {0};
    int zT_277;
    unsigned int zT_278;
    zT_3D7259E2_SymbolRegistry* zT_279;
    unsigned int zT_280;
    zT_3D7259E2_SymbolRegistry* zT_284;
    unsigned int zT_286;
    zT_557B6199_Opt_875 zT_289 = {0};
    unsigned char zT_290;
    unsigned short zT_292;
    zT_DA663F79_ComptimeEval* zT_297;
    unsigned int zT_298;
    zT_66B68F69_FloatNarrowVal zT_303 = {0};
    int zT_304;
    unsigned int zT_306;
    zT_66B68F69_FloatNarrowVal r;
    zT_22A7C88B_AstNode node;
    zT_66B68F69_FloatNarrowVal l;
    zT_66B68F69_FloatNarrowVal rt;
    unsigned int bc_n;
    unsigned char is_as;
    unsigned char is_fc;
    unsigned char is_itf;
    zT_BAEE192E_Opt_10 tid;
    zT_00435AEB_f64 bv;
    unsigned int t;
    unsigned int inner_idx;
    zT_00435AEB_f64 fv;
    zT_89B1DDDA_ComptimeVal cv;
    zT_66B68F69_FloatNarrowVal iv;
    float f32v;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_557B6199_Opt_875 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_4 = zF_6AEE4E20_floatNarrowNone();
    r = zT_4;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return r;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(20))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return r;
    z_bb_4:
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    r.ok = (unsigned char)(1);
    zT_19 = self->store;
    zT_20 = zT_19->float_values;
    zT_21 = zT_20.items;
    zT_22 = self->store;
    zT_23 = node_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_22, zT_23);
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_21[zT_26];
    r.v = zT_27;
    return r;
    z_bb_6:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_33 = node.kind;
    zT_32 = zT_33 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_9;
    z_bb_8:
    zT_32 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_32) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    r.ok = (unsigned char)(1);
    zT_38 = self->store;
    zT_39 = node_idx;
    zT_41 = zF_678B9A72_astStoreIntValue(zT_38, zT_39);
    r.v = (zT_00435AEB_f64)((zT_00435AEB_f64)zT_41);
    return r;
    z_bb_11:
    zT_43 = node.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_13; else goto z_bb_12;
    z_bb_12:
    zT_48 = node.kind;
    zT_47 = zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr);
    goto z_bb_14;
    z_bb_13:
    zT_47 = 1;
    goto z_bb_14;
    z_bb_14:
    if (zT_47) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_52 = self;
    zT_53 = node.child_0;
    zT_58 = zF_0DB56784_floatNarrowProbe(zT_52, zT_53, (unsigned int)(depth + (unsigned int)(1)));
    r = zT_58;
    zT_59 = r.ok;
    if ((unsigned char)(!zT_59)) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_67 = node.kind;
    if ((unsigned char)(zT_67 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_22; else goto z_bb_21;
    z_bb_17:
    return r;
    z_bb_18:
    zT_61 = node.kind;
    if ((unsigned char)(zT_61 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_65 = r.v;
    r.v = (zT_00435AEB_f64)(-zT_65);
    goto z_bb_20;
    z_bb_20:
    return r;
    z_bb_21:
    zT_72 = node.kind;
    zT_71 = zT_72 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_23;
    z_bb_22:
    zT_71 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_71) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_77 = node.kind;
    zT_76 = zT_77 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_26;
    z_bb_25:
    zT_76 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_76) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_82 = node.kind;
    zT_81 = zT_82 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_29;
    z_bb_28:
    zT_81 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_81) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_87 = self;
    zT_88 = node.child_0;
    zT_93 = zF_0DB56784_floatNarrowProbe(zT_87, zT_88, (unsigned int)(depth + (unsigned int)(1)));
    l = zT_93;
    zT_94 = l.ok;
    if ((unsigned char)(!zT_94)) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_142 = node.kind;
    if ((unsigned char)(zT_142 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_49; else goto z_bb_50;
    z_bb_32:
    return r;
    z_bb_33:
    zT_97 = self;
    zT_98 = node.child_1;
    zT_103 = zF_0DB56784_floatNarrowProbe(zT_97, zT_98, (unsigned int)(depth + (unsigned int)(1)));
    rt = zT_103;
    zT_104 = rt.ok;
    if ((unsigned char)(!zT_104)) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return r;
    z_bb_35:
    r.ok = (unsigned char)(1);
    zT_107 = l.typed;
    if (zT_107) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_108 = rt.typed;
    goto z_bb_38;
    z_bb_37:
    zT_108 = 1;
    goto z_bb_38;
    z_bb_38:
    r.typed = zT_108;
    zT_110 = node.kind;
    if ((unsigned char)(zT_110 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_114 = l.v;
    zT_115 = rt.v;
    r.v = (zT_00435AEB_f64)(zT_114 + zT_115);
    goto z_bb_40;
    z_bb_40:
    zT_117 = node.kind;
    if ((unsigned char)(zT_117 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_121 = l.v;
    zT_122 = rt.v;
    r.v = (zT_00435AEB_f64)(zT_121 - zT_122);
    goto z_bb_42;
    z_bb_42:
    zT_124 = node.kind;
    if ((unsigned char)(zT_124 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_128 = l.v;
    zT_129 = rt.v;
    r.v = (zT_00435AEB_f64)(zT_128 * zT_129);
    goto z_bb_44;
    z_bb_44:
    zT_131 = node.kind;
    if ((unsigned char)(zT_131 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_135 = rt.v;
    if ((unsigned char)(zT_135 == (zT_00435AEB_f64)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    return r;
    z_bb_47:
    zT_138 = zF_6AEE4E20_floatNarrowNone();
    return zT_138;
    z_bb_48:
    zT_139 = l.v;
    zT_140 = rt.v;
    r.v = (zT_00435AEB_f64)(zT_139 / zT_140);
    goto z_bb_46;
    z_bb_49:
    zT_147 = self->store;
    zT_148 = node_idx;
    zT_150 = zF_152E19CB_astStoreNodeExtraCh(zT_147, zT_148);
    bc_n = zT_150;
    if ((unsigned char)(bc_n < (unsigned int)(1))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_253 = node.kind;
    if ((unsigned char)(zT_253 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_95; else goto z_bb_96;
    z_bb_51:
    return r;
    z_bb_52:
    zT_154 = node.child_0;
    zT_155 = self->as_id;
    zT_156 = zT_154 == zT_155;
    is_as = zT_156;
    zT_158 = node.child_0;
    zT_159 = self->float_cast_id;
    zT_160 = zT_158 == zT_159;
    is_fc = zT_160;
    zT_162 = node.child_0;
    zT_163 = self->int_to_float_id;
    zT_164 = zT_162 == zT_163;
    is_itf = zT_164;
    if ((unsigned char)(!is_as)) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_166 = !is_fc;
    goto z_bb_55;
    z_bb_54:
    zT_166 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_166) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_168 = !is_itf;
    goto z_bb_58;
    z_bb_57:
    zT_168 = 0;
    goto z_bb_58;
    z_bb_58:
    if (zT_168) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    return r;
    z_bb_60:
    if (is_fc) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_170 = is_itf;
    goto z_bb_63;
    z_bb_62:
    zT_170 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_170) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_171 = self;
    zT_172 = node_idx;
    zT_176 = zF_8C4B1954_comptimeEvalFloatBu(zT_171, zT_172, (unsigned int)(depth + (unsigned int)(1)));
    zT_177 = zT_176.has_value;
    if (zT_177) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    zT_182 = self;
    zT_184 = self->store;
    zT_185 = node_idx;
    zT_189 = zF_B10B1BC1_astStoreNodeExtraCh(zT_184, zT_185, (unsigned int)(0));
    zT_183 = zT_189;
    zT_190 = zF_BAD6BA5D_comptimeEvalResolve(zT_182, zT_183);
    tid = zT_190;
    zT_191 = tid.has_value;
    if (zT_191) goto z_bb_68; else goto z_bb_69;
    z_bb_66:
    bv = zT_176.value;
    r.ok = (unsigned char)(1);
    r.typed = (unsigned char)(1);
    r.v = bv;
    goto z_bb_67;
    z_bb_67:
    return r;
    z_bb_68:
    t = tid.value;
    if ((unsigned char)(t != (unsigned int)(15))) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    return r;
    z_bb_70:
    zT_195 = t != (unsigned int)(16);
    goto z_bb_72;
    z_bb_71:
    zT_195 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_195) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    return r;
    z_bb_74:
    if ((unsigned char)(bc_n < (unsigned int)(2))) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    return r;
    z_bb_76:
    zT_201 = self->store;
    zT_202 = node_idx;
    zT_206 = zF_B10B1BC1_astStoreNodeExtraCh(zT_201, zT_202, (unsigned int)(1));
    inner_idx = zT_206;
    zT_208 = 0;
    fv = zT_208;
    zT_209 = self;
    zT_210 = inner_idx;
    zT_214 = zF_4EE17137_comptimeEvalEvaluat(zT_209, zT_210, (unsigned int)(depth + (unsigned int)(1)));
    zT_215 = zT_214.has_value;
    if (zT_215) goto z_bb_77; else goto z_bb_79;
    z_bb_77:
    cv = zT_214.value;
    zT_217 = cv.kind;
    if ((unsigned char)(zT_217 == (unsigned int)(2))) goto z_bb_80; else goto z_bb_82;
    z_bb_78:
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_93; else goto z_bb_94;
    z_bb_79:
    zT_237 = self;
    zT_238 = inner_idx;
    zT_242 = zF_0DB56784_floatNarrowProbe(zT_237, zT_238, (unsigned int)(depth + (unsigned int)(1)));
    iv = zT_242;
    zT_243 = iv.ok;
    if ((unsigned char)(!zT_243)) goto z_bb_91; else goto z_bb_92;
    z_bb_80:
    zT_220 = cv;
    zT_221 = zF_9DD4606D_comptimeEvalFloatBi(zT_220);
    fv = zT_221;
    goto z_bb_81;
    z_bb_81:
    goto z_bb_78;
    z_bb_82:
    zT_222 = cv.kind;
    if ((unsigned char)(zT_222 == (unsigned int)(0))) goto z_bb_83; else goto z_bb_85;
    z_bb_83:
    zT_226 = cv.v;
    zT_225 = zT_226;
    zT_227 = zF_E6CE9168_ciToF64(zT_225);
    fv = zT_227;
    goto z_bb_84;
    z_bb_84:
    goto z_bb_81;
    z_bb_85:
    zT_228 = cv.kind;
    if ((unsigned char)(zT_228 == (unsigned int)(1))) goto z_bb_86; else goto z_bb_88;
    z_bb_86:
    zT_232 = cv.v;
    zT_231 = zT_232;
    zT_233 = zF_0F5FA15F_ciIsZero(zT_231);
    if ((unsigned char)(!zT_233)) goto z_bb_89; else goto z_bb_90;
    z_bb_87:
    goto z_bb_84;
    z_bb_88:
    return r;
    z_bb_89:
    zT_235 = 1e+0;
    fv = zT_235;
    goto z_bb_90;
    z_bb_90:
    goto z_bb_87;
    z_bb_91:
    return r;
    z_bb_92:
    zT_245 = iv.v;
    fv = zT_245;
    goto z_bb_78;
    z_bb_93:
    zT_249 = (float)fv;
    f32v = zT_249;
    zT_250 = (zT_00435AEB_f64)f32v;
    fv = zT_250;
    goto z_bb_94;
    z_bb_94:
    r.ok = (unsigned char)(1);
    r.typed = (unsigned char)(1);
    r.v = fv;
    return r;
    z_bb_95:
    zT_258 = self->store;
    zT_259 = node_idx;
    zT_261 = zF_53458827_astStoreIdentifier(zT_258, zT_259);
    name_id = zT_261;
    zT_262 = self->local_consts;
    zT_263 = zT_262.has_value;
    if (zT_263) goto z_bb_97; else goto z_bb_98;
    z_bb_96:
    return r;
    z_bb_97:
    lcs = zT_262.value;
    zT_265 = lcs;
    zT_266 = name_id;
    zT_267 = zF_6532C387_localConstScopeLook(zT_265, zT_266);
    zT_268 = zT_267.has_value;
    if (zT_268) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    zT_277 = 0;
    zT_278 = (unsigned int)zT_277;
    mi = zT_278;
    goto z_bb_101;
    z_bb_99:
    l_decl_node = zT_267.value;
    zT_270 = self;
    zT_271 = l_decl_node;
    zT_275 = zF_25831332_floatNarrowDecl(zT_270, zT_271, (unsigned int)(depth + (unsigned int)(1)));
    return zT_275;
    z_bb_100:
    goto z_bb_98;
    z_bb_101:
    zT_279 = self->symbol_reg;
    zT_280 = zT_279->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_280))) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    zT_284 = self->symbol_reg;
    zT_286 = name_id;
    zT_289 = zF_A398987E_symbolRegistryQuali(zT_284, (unsigned int)((unsigned int)mi), zT_286);
    c_sym = zT_289;
    zT_290 = c_sym.has_value;
    if (zT_290) goto z_bb_105; else goto z_bb_106;
    z_bb_103:
    return r;
    z_bb_104:
    zT_304 = 1;
    zT_306 = mi + (unsigned int)((unsigned int)zT_304);
    mi = zT_306;
    goto z_bb_101;
    z_bb_105:
    cs = c_sym.value;
    zT_292 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_292 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    goto z_bb_104;
    z_bb_107:
    zT_297 = self;
    zT_298 = cs->decl_node;
    zT_303 = zF_25831332_floatNarrowDecl(zT_297, zT_298, (unsigned int)(depth + (unsigned int)(1)));
    return zT_303;
    z_bb_108:
    goto z_bb_106;
}

/* floatNarrowDecl */
zT_66B68F69_FloatNarrowVal zF_25831332_floatNarrowDecl(zT_DA663F79_ComptimeEval* self, unsigned int decl_node, unsigned int depth) {
    zT_66B68F69_FloatNarrowVal zT_4 = {0};
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    unsigned int zT_10;
    zT_DA663F79_ComptimeEval* zT_13;
    unsigned int zT_14;
    zT_66B68F69_FloatNarrowVal zT_19 = {0};
    unsigned char zT_20;
    zT_DA663F79_ComptimeEval* zT_22;
    unsigned int zT_23;
    zT_E53A25A2_Opt_203 zT_28 = {0};
    unsigned char zT_29;
    unsigned char zT_31;
    zT_89B1DDDA_ComptimeVal zT_36;
    zT_00435AEB_f64 zT_37 = 0;
    unsigned char zT_38;
    unsigned char zT_41;
    unsigned char zT_42;
    unsigned int zT_46;
    unsigned char zT_49;
    zT_0163D9A4_ComptimeInt zT_52;
    zT_0163D9A4_ComptimeInt zT_53;
    zT_00435AEB_f64 zT_54 = 0;
    zT_0163D9A4_ComptimeInt zT_55;
    zT_0163D9A4_ComptimeInt zT_56;
    unsigned char zT_57 = 0;
    zT_66B68F69_FloatNarrowVal zT_60 = {0};
    zT_66B68F69_FloatNarrowVal zT_61 = {0};
    unsigned int zT_62;
    zT_DA663F79_ComptimeEval* zT_65;
    unsigned int zT_66;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    unsigned char zT_69;
    zT_00435AEB_f64 zT_74;
    float zT_75;
    zT_338B7C76_TypeRegistry* zT_81;
    unsigned int zT_82;
    unsigned char zT_84 = 0;
    zT_66B68F69_FloatNarrowVal r;
    zT_22A7C88B_AstNode d;
    zT_89B1DDDA_ComptimeVal cv;
    unsigned int t;
    float f32v;
    zT_4 = zF_6AEE4E20_floatNarrowNone();
    r = zT_4;
    zT_6 = self->store;
    zT_7 = decl_node;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    d = zT_9;
    zT_10 = d.child_1;
    if ((unsigned char)(zT_10 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return r;
    z_bb_2:
    zT_13 = self;
    zT_14 = d.child_1;
    zT_19 = zF_0DB56784_floatNarrowProbe(zT_13, zT_14, (unsigned int)(depth + (unsigned int)(1)));
    r = zT_19;
    zT_20 = r.ok;
    if ((unsigned char)(!zT_20)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_22 = self;
    zT_23 = d.child_1;
    zT_28 = zF_4EE17137_comptimeEvalEvaluat(zT_22, zT_23, (unsigned int)(depth + (unsigned int)(1)));
    zT_29 = zT_28.has_value;
    if (zT_29) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    zT_62 = d.child_0;
    if ((unsigned char)(zT_62 != (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_5:
    cv = zT_28.value;
    zT_31 = cv.kind;
    if ((unsigned char)(zT_31 == (unsigned int)(2))) goto z_bb_8; else goto z_bb_10;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_61 = zF_6AEE4E20_floatNarrowNone();
    return zT_61;
    z_bb_8:
    r.ok = (unsigned char)(1);
    r.typed = (unsigned char)(1);
    zT_36 = cv;
    zT_37 = zF_9DD4606D_comptimeEvalFloatBi(zT_36);
    r.v = zT_37;
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_38 = cv.kind;
    if ((unsigned char)(zT_38 == (unsigned int)(0))) goto z_bb_12; else goto z_bb_11;
    z_bb_11:
    zT_42 = cv.kind;
    zT_41 = zT_42 == (unsigned int)(1);
    goto z_bb_13;
    z_bb_12:
    zT_41 = 1;
    goto z_bb_13;
    z_bb_13:
    if (zT_41) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    r.ok = (unsigned char)(1);
    zT_46 = d.child_0;
    r.typed = (unsigned char)(zT_46 != (unsigned int)(0));
    zT_49 = cv.kind;
    if ((unsigned char)(zT_49 == (unsigned int)(0))) goto z_bb_17; else goto z_bb_19;
    z_bb_15:
    goto z_bb_9;
    z_bb_16:
    zT_60 = zF_6AEE4E20_floatNarrowNone();
    return zT_60;
    z_bb_17:
    zT_53 = cv.v;
    zT_52 = zT_53;
    zT_54 = zF_E6CE9168_ciToF64(zT_52);
    r.v = zT_54;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_56 = cv.v;
    zT_55 = zT_56;
    zT_57 = zF_0F5FA15F_ciIsZero(zT_55);
    if ((unsigned char)(!zT_57)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    r.v = (zT_00435AEB_f64)(1e+0);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_18;
    z_bb_22:
    zT_65 = self;
    zT_66 = d.child_0;
    zT_68 = zF_BAD6BA5D_comptimeEvalResolve(zT_65, zT_66);
    zT_69 = zT_68.has_value;
    if (zT_69) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    return r;
    z_bb_24:
    t = zT_68.value;
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_26; else goto z_bb_28;
    z_bb_25:
    goto z_bb_23;
    z_bb_26:
    zT_74 = r.v;
    zT_75 = (float)zT_74;
    f32v = zT_75;
    r.v = (zT_00435AEB_f64)((zT_00435AEB_f64)f32v);
    r.typed = (unsigned char)(1);
    goto z_bb_27;
    z_bb_27:
    goto z_bb_25;
    z_bb_28:
    if ((unsigned char)(t == (unsigned int)(16))) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    r.typed = (unsigned char)(1);
    goto z_bb_30;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_81 = self->registry;
    zT_82 = t;
    zT_84 = zF_3290E9C4_typeRegistryIsInteg(zT_81, zT_82);
    if (zT_84) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    r.typed = (unsigned char)(1);
    goto z_bb_33;
    z_bb_33:
    goto z_bb_30;
}

/* comptimeEvalEvaluate */
zT_E53A25A2_Opt_203 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    zT_E53A25A2_Opt_203 zT_6 = {0};
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_4EE17137_comptimeEvalEvaluat(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* comptimeEvalEvaluateDepth */
zT_E53A25A2_Opt_203 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_E53A25A2_Opt_203 zT_5 = {0};
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_0163D9A4_ComptimeInt zT_15;
    zT_79FAE712_u64 zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_79FAE712_u64 zT_20 = 0;
    zT_0163D9A4_ComptimeInt zT_21 = {0};
    zT_89B1DDDA_ComptimeVal zT_22 = {0};
    zT_E53A25A2_Opt_203 zT_23;
    zT_8143F551_AstKind zT_24;
    zT_0163D9A4_ComptimeInt zT_28;
    zT_79FAE712_u64 zT_29;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_79FAE712_u64 zT_33 = 0;
    zT_0163D9A4_ComptimeInt zT_34 = {0};
    zT_89B1DDDA_ComptimeVal zT_35 = {0};
    zT_E53A25A2_Opt_203 zT_36;
    zT_8143F551_AstKind zT_37;
    unsigned char zT_41;
    zT_89B1DDDA_ComptimeVal zT_48 = {0};
    zT_E53A25A2_Opt_203 zT_49;
    zT_89B1DDDA_ComptimeVal zT_52 = {0};
    zT_E53A25A2_Opt_203 zT_53;
    zT_8143F551_AstKind zT_54;
    zT_DA663F79_ComptimeEval* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_E53A25A2_Opt_203 zT_63 = {0};
    unsigned char zT_64;
    unsigned char zT_66;
    zT_E53A25A2_Opt_203 zT_69 = {0};
    zT_0163D9A4_ComptimeInt zT_71 = {0};
    zT_0163D9A4_ComptimeInt zT_72;
    zT_0163D9A4_ComptimeInt* zT_73;
    zT_0163D9A4_ComptimeInt zT_74;
    unsigned char zT_76 = 0;
    zT_DA663F79_ComptimeEval* zT_78;
    unsigned int zT_79;
    zT_BAEE192E_Opt_10 zT_81 = {0};
    unsigned char zT_82;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_0163D9A4_ComptimeInt zT_85;
    unsigned int zT_86;
    unsigned char zT_88 = 0;
    zT_E53A25A2_Opt_203 zT_90 = {0};
    zT_0163D9A4_ComptimeInt zT_91;
    zT_89B1DDDA_ComptimeVal zT_92 = {0};
    zT_E53A25A2_Opt_203 zT_93;
    zT_E53A25A2_Opt_203 zT_94 = {0};
    zT_8143F551_AstKind zT_95;
    zT_DA663F79_ComptimeEval* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_E53A25A2_Opt_203 zT_104 = {0};
    unsigned char zT_105;
    unsigned char zT_107;
    zT_E53A25A2_Opt_203 zT_110 = {0};
    zT_0163D9A4_ComptimeInt zT_112 = {0};
    zT_0163D9A4_ComptimeInt zT_113;
    zT_0163D9A4_ComptimeInt* zT_114;
    zT_0163D9A4_ComptimeInt zT_115;
    unsigned char zT_117 = 0;
    zT_E53A25A2_Opt_203 zT_119 = {0};
    zT_0163D9A4_ComptimeInt zT_120;
    zT_89B1DDDA_ComptimeVal zT_121 = {0};
    zT_E53A25A2_Opt_203 zT_122;
    zT_E53A25A2_Opt_203 zT_123 = {0};
    zT_8143F551_AstKind zT_124;
    zT_DA663F79_ComptimeEval* zT_128;
    unsigned int zT_129;
    zT_8143F551_AstKind zT_130;
    unsigned int zT_131;
    zT_E53A25A2_Opt_203 zT_133 = {0};
    zT_8143F551_AstKind zT_134;
    unsigned char zT_138;
    zT_8143F551_AstKind zT_139;
    unsigned char zT_143;
    zT_8143F551_AstKind zT_144;
    unsigned char zT_148;
    zT_8143F551_AstKind zT_149;
    unsigned char zT_153;
    zT_8143F551_AstKind zT_154;
    unsigned char zT_158;
    zT_8143F551_AstKind zT_159;
    unsigned char zT_163;
    zT_8143F551_AstKind zT_164;
    unsigned char zT_168;
    zT_8143F551_AstKind zT_169;
    unsigned char zT_173;
    zT_8143F551_AstKind zT_174;
    unsigned char zT_178;
    zT_8143F551_AstKind zT_179;
    zT_DA663F79_ComptimeEval* zT_183;
    unsigned int zT_184;
    zT_8143F551_AstKind zT_185;
    unsigned int zT_186;
    zT_E53A25A2_Opt_203 zT_188 = {0};
    zT_8143F551_AstKind zT_189;
    unsigned char zT_193;
    zT_8143F551_AstKind zT_194;
    unsigned char zT_198;
    zT_8143F551_AstKind zT_199;
    unsigned char zT_203;
    zT_8143F551_AstKind zT_204;
    unsigned char zT_208;
    zT_8143F551_AstKind zT_209;
    unsigned char zT_213;
    zT_8143F551_AstKind zT_214;
    zT_DA663F79_ComptimeEval* zT_218;
    unsigned int zT_219;
    zT_8143F551_AstKind zT_220;
    unsigned int zT_221;
    zT_E53A25A2_Opt_203 zT_223 = {0};
    zT_8143F551_AstKind zT_224;
    unsigned char zT_228;
    zT_8143F551_AstKind zT_229;
    zT_DA663F79_ComptimeEval* zT_233;
    unsigned int zT_234;
    zT_8143F551_AstKind zT_235;
    unsigned int zT_236;
    zT_E53A25A2_Opt_203 zT_238 = {0};
    zT_8143F551_AstKind zT_239;
    zT_DA663F79_ComptimeEval* zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    zT_E53A25A2_Opt_203 zT_246 = {0};
    zT_8143F551_AstKind zT_247;
    zT_DA663F79_ComptimeEval* zT_251;
    unsigned int zT_253;
    unsigned int zT_254;
    zT_8143F551_AstKind zT_256;
    zT_E53A25A2_Opt_203 zT_262 = {0};
    zT_6B0A7D14_AstStore* zT_264;
    unsigned int zT_265;
    unsigned int zT_267 = 0;
    zT_05CE5599_Opt_400 zT_268;
    unsigned char zT_269;
    zT_E2DF2801_LocalConstScope* zT_271;
    unsigned int zT_272;
    zT_BAEE192E_Opt_10 zT_273 = {0};
    unsigned char zT_274;
    zT_6B0A7D14_AstStore* zT_277;
    unsigned int zT_278;
    zT_22A7C88B_AstNode zT_280 = {0};
    unsigned int zT_281;
    zT_DA663F79_ComptimeEval* zT_285;
    unsigned int zT_286;
    zT_E53A25A2_Opt_203 zT_291 = {0};
    unsigned char zT_292;
    zT_DA663F79_ComptimeEval* zT_294;
    unsigned int zT_295;
    zT_89B1DDDA_ComptimeVal zT_296;
    unsigned char zT_297 = 0;
    zT_E53A25A2_Opt_203 zT_299 = {0};
    int zT_301;
    unsigned int zT_302;
    zT_3D7259E2_SymbolRegistry* zT_303;
    unsigned int zT_304;
    zT_3D7259E2_SymbolRegistry* zT_308;
    unsigned int zT_310;
    zT_557B6199_Opt_875 zT_313 = {0};
    unsigned char zT_314;
    unsigned short zT_316;
    zT_6B0A7D14_AstStore* zT_322;
    unsigned int zT_323;
    zT_22A7C88B_AstNode zT_326 = {0};
    unsigned int zT_327;
    zT_DA663F79_ComptimeEval* zT_331;
    unsigned int zT_332;
    zT_E53A25A2_Opt_203 zT_337 = {0};
    unsigned char zT_338;
    zT_DA663F79_ComptimeEval* zT_340;
    unsigned int zT_341;
    zT_89B1DDDA_ComptimeVal zT_342;
    unsigned char zT_344 = 0;
    zT_E53A25A2_Opt_203 zT_346 = {0};
    int zT_347;
    unsigned int zT_349;
    zT_E53A25A2_Opt_203 zT_350 = {0};
    zT_E53A25A2_Opt_203 zT_351 = {0};
    zT_22A7C88B_AstNode node;
    zT_E53A25A2_Opt_203 inner;
    zT_89B1DDDA_ComptimeVal cv;
    zT_0163D9A4_ComptimeInt nv;
    zT_BAEE192E_Opt_10 pt;
    unsigned int ptid;
    zT_E53A25A2_Opt_203 bnv;
    zT_89B1DDDA_ComptimeVal bv;
    zT_0163D9A4_ComptimeInt bnb;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    unsigned int mi;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_E53A25A2_Opt_203 lv;
    zT_89B1DDDA_ComptimeVal lvv;
    zT_557B6199_Opt_875 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_E53A25A2_Opt_203 cv_1;
    zT_89B1DDDA_ComptimeVal cvv;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((unsigned char)(zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_17 = self->store;
    zT_18 = node_idx;
    zT_20 = zF_678B9A72_astStoreIntValue(zT_17, zT_18);
    zT_16 = zT_20;
    zT_21 = zF_1EAA44E6_ciFromU64(zT_16);
    zT_15 = zT_21;
    zT_22 = zF_237A4571_ciIntVal(zT_15);
    zT_23.has_value = 1;
    zT_23.value = zT_22;
    return zT_23;
    z_bb_4:
    { zT_E53A25A2_Opt_203 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_5:
    zT_24 = node.kind;
    if ((unsigned char)(zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_30 = self->store;
    zT_31 = node_idx;
    zT_33 = zF_678B9A72_astStoreIntValue(zT_30, zT_31);
    zT_29 = zT_33;
    zT_34 = zF_1EAA44E6_ciFromU64(zT_29);
    zT_28 = zT_34;
    zT_35 = zF_237A4571_ciIntVal(zT_28);
    zT_36.has_value = 1;
    zT_36.value = zT_35;
    return zT_36;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_41 = node.flags;
    if ((unsigned char)((unsigned char)(zT_41 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_54 = node.kind;
    if ((unsigned char)(zT_54 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_14; else goto z_bb_16;
    z_bb_12:
    zT_48 = zF_E867E750_ciBoolVal((unsigned char)(1));
    zT_49.has_value = 1;
    zT_49.value = zT_48;
    return zT_49;
    z_bb_13:
    zT_52 = zF_E867E750_ciBoolVal((unsigned char)(0));
    zT_53.has_value = 1;
    zT_53.value = zT_52;
    return zT_53;
    z_bb_14:
    zT_59 = self;
    zT_60 = node.child_0;
    zT_61 = depth;
    zT_63 = zF_4EE17137_comptimeEvalEvaluat(zT_59, zT_60, zT_61);
    inner = zT_63;
    zT_64 = inner.has_value;
    if (zT_64) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_95 = node.kind;
    if ((unsigned char)(zT_95 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_25; else goto z_bb_27;
    z_bb_17:
    cv = inner.value;
    zT_66 = cv.kind;
    if ((unsigned char)(zT_66 != (unsigned int)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_94.has_value = 0;
    return zT_94;
    z_bb_19:
    zT_69.has_value = 0;
    return zT_69;
    z_bb_20:
    zT_71 = zF_DC9B7BC0_ciZeroInt();
    nv = zT_71;
    zT_74 = cv.v;
    zT_72 = zT_74;
    zT_73 = &nv;
    zT_76 = zF_EECBFD7D_ciNeg(zT_72, zT_73);
    (void)zT_76;
    zT_78 = self;
    zT_79 = node.child_0;
    zT_81 = zF_6B810D4A_comptimeEvalOperand(zT_78, zT_79);
    pt = zT_81;
    zT_82 = pt.has_value;
    if (zT_82) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    ptid = pt.value;
    zT_84 = self->registry;
    zT_85 = nv;
    zT_86 = ptid;
    zT_88 = zF_B28C4720_comptimeIntFitsType(zT_84, zT_85, zT_86);
    if ((unsigned char)(!zT_88)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_91 = nv;
    zT_92 = zF_237A4571_ciIntVal(zT_91);
    zT_93.has_value = 1;
    zT_93.value = zT_92;
    return zT_93;
    z_bb_23:
    zT_90.has_value = 0;
    return zT_90;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_100 = self;
    zT_101 = node.child_0;
    zT_102 = depth;
    zT_104 = zF_4EE17137_comptimeEvalEvaluat(zT_100, zT_101, zT_102);
    bnv = zT_104;
    zT_105 = bnv.has_value;
    if (zT_105) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    goto z_bb_15;
    z_bb_27:
    zT_124 = node.kind;
    if ((unsigned char)(zT_124 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_not))) goto z_bb_34; else goto z_bb_36;
    z_bb_28:
    bv = bnv.value;
    zT_107 = bv.kind;
    if ((unsigned char)(zT_107 != (unsigned int)(0))) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_123.has_value = 0;
    return zT_123;
    z_bb_30:
    zT_110.has_value = 0;
    return zT_110;
    z_bb_31:
    zT_112 = zF_DC9B7BC0_ciZeroInt();
    bnb = zT_112;
    zT_115 = bv.v;
    zT_113 = zT_115;
    zT_114 = &bnb;
    zT_117 = zF_223ABA6D_ciBitNot(zT_113, zT_114);
    if ((unsigned char)(!zT_117)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_119.has_value = 0;
    return zT_119;
    z_bb_33:
    zT_120 = bnb;
    zT_121 = zF_237A4571_ciIntVal(zT_120);
    zT_122.has_value = 1;
    zT_122.value = zT_121;
    return zT_122;
    z_bb_34:
    zT_128 = self;
    zT_129 = node_idx;
    zT_130 = node.kind;
    zT_131 = depth;
    zT_133 = zF_40F99F20_comptimeEvalLogical(zT_128, zT_129, zT_130, zT_131);
    return zT_133;
    z_bb_35:
    goto z_bb_26;
    z_bb_36:
    zT_134 = node.kind;
    if ((unsigned char)(zT_134 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_139 = node.kind;
    zT_138 = zT_139 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_39;
    z_bb_38:
    zT_138 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_138) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_144 = node.kind;
    zT_143 = zT_144 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_42;
    z_bb_41:
    zT_143 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_143) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_149 = node.kind;
    zT_148 = zT_149 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_45;
    z_bb_44:
    zT_148 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_148) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_154 = node.kind;
    zT_153 = zT_154 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_48;
    z_bb_47:
    zT_153 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_153) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_159 = node.kind;
    zT_158 = zT_159 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_51;
    z_bb_50:
    zT_158 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_158) goto z_bb_53; else goto z_bb_52;
    z_bb_52:
    zT_164 = node.kind;
    zT_163 = zT_164 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_54;
    z_bb_53:
    zT_163 = 1;
    goto z_bb_54;
    z_bb_54:
    if (zT_163) goto z_bb_56; else goto z_bb_55;
    z_bb_55:
    zT_169 = node.kind;
    zT_168 = zT_169 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_57;
    z_bb_56:
    zT_168 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_168) goto z_bb_59; else goto z_bb_58;
    z_bb_58:
    zT_174 = node.kind;
    zT_173 = zT_174 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_60;
    z_bb_59:
    zT_173 = 1;
    goto z_bb_60;
    z_bb_60:
    if (zT_173) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_179 = node.kind;
    zT_178 = zT_179 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_63;
    z_bb_62:
    zT_178 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_178) goto z_bb_64; else goto z_bb_66;
    z_bb_64:
    zT_183 = self;
    zT_184 = node_idx;
    zT_185 = node.kind;
    zT_186 = depth;
    zT_188 = zF_B36A4A25_comptimeEvalBinOp(zT_183, zT_184, zT_185, zT_186);
    return zT_188;
    z_bb_65:
    goto z_bb_35;
    z_bb_66:
    zT_189 = node.kind;
    if ((unsigned char)(zT_189 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_eq))) goto z_bb_68; else goto z_bb_67;
    z_bb_67:
    zT_194 = node.kind;
    zT_193 = zT_194 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ne);
    goto z_bb_69;
    z_bb_68:
    zT_193 = 1;
    goto z_bb_69;
    z_bb_69:
    if (zT_193) goto z_bb_71; else goto z_bb_70;
    z_bb_70:
    zT_199 = node.kind;
    zT_198 = zT_199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_lt);
    goto z_bb_72;
    z_bb_71:
    zT_198 = 1;
    goto z_bb_72;
    z_bb_72:
    if (zT_198) goto z_bb_74; else goto z_bb_73;
    z_bb_73:
    zT_204 = node.kind;
    zT_203 = zT_204 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_le);
    goto z_bb_75;
    z_bb_74:
    zT_203 = 1;
    goto z_bb_75;
    z_bb_75:
    if (zT_203) goto z_bb_77; else goto z_bb_76;
    z_bb_76:
    zT_209 = node.kind;
    zT_208 = zT_209 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_gt);
    goto z_bb_78;
    z_bb_77:
    zT_208 = 1;
    goto z_bb_78;
    z_bb_78:
    if (zT_208) goto z_bb_80; else goto z_bb_79;
    z_bb_79:
    zT_214 = node.kind;
    zT_213 = zT_214 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_cmp_ge);
    goto z_bb_81;
    z_bb_80:
    zT_213 = 1;
    goto z_bb_81;
    z_bb_81:
    if (zT_213) goto z_bb_82; else goto z_bb_84;
    z_bb_82:
    zT_218 = self;
    zT_219 = node_idx;
    zT_220 = node.kind;
    zT_221 = depth;
    zT_223 = zF_CD4BD838_comptimeEvalCompare(zT_218, zT_219, zT_220, zT_221);
    return zT_223;
    z_bb_83:
    goto z_bb_65;
    z_bb_84:
    zT_224 = node.kind;
    if ((unsigned char)(zT_224 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_and))) goto z_bb_86; else goto z_bb_85;
    z_bb_85:
    zT_229 = node.kind;
    zT_228 = zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_or);
    goto z_bb_87;
    z_bb_86:
    zT_228 = 1;
    goto z_bb_87;
    z_bb_87:
    if (zT_228) goto z_bb_88; else goto z_bb_90;
    z_bb_88:
    zT_233 = self;
    zT_234 = node_idx;
    zT_235 = node.kind;
    zT_236 = depth;
    zT_238 = zF_40F99F20_comptimeEvalLogical(zT_233, zT_234, zT_235, zT_236);
    return zT_238;
    z_bb_89:
    goto z_bb_83;
    z_bb_90:
    zT_239 = node.kind;
    if ((unsigned char)(zT_239 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_243 = self;
    zT_244 = node_idx;
    zT_245 = depth;
    zT_246 = zF_C37A1F7C_comptimeEvalBuiltin(zT_243, zT_244, zT_245);
    return zT_246;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_247 = node.kind;
    if ((unsigned char)(zT_247 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_94; else goto z_bb_96;
    z_bb_94:
    zT_251 = self;
    zT_254 = node.child_0;
    zT_253 = depth;
    self = zT_251;
    node_idx = zT_254;
    depth = zT_253;
    goto z_bb_0;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_256 = node.kind;
    if ((unsigned char)(zT_256 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_97; else goto z_bb_99;
    z_bb_97:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_100; else goto z_bb_101;
    goto z_bb_95;
    z_bb_99:
    zT_351.has_value = 0;
    return zT_351;
    z_bb_100:
    zT_262.has_value = 0;
    return zT_262;
    z_bb_101:
    zT_264 = self->store;
    zT_265 = node_idx;
    zT_267 = zF_53458827_astStoreIdentifier(zT_264, zT_265);
    name_id = zT_267;
    zT_268 = self->local_consts;
    zT_269 = zT_268.has_value;
    if (zT_269) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    lcs = zT_268.value;
    zT_271 = lcs;
    zT_272 = name_id;
    zT_273 = zF_6532C387_localConstScopeLook(zT_271, zT_272);
    zT_274 = zT_273.has_value;
    if (zT_274) goto z_bb_104; else goto z_bb_105;
    z_bb_103:
    zT_301 = 0;
    zT_302 = (unsigned int)zT_301;
    mi = zT_302;
    goto z_bb_112;
    z_bb_104:
    l_decl_node = zT_273.value;
    zT_277 = self->store;
    zT_278 = l_decl_node;
    zT_280 = zF_FCDD1D35_astStoreNodeAt(zT_277, zT_278);
    l_decl = zT_280;
    zT_281 = l_decl.child_1;
    if ((unsigned char)(zT_281 != (unsigned int)(0))) goto z_bb_106; else goto z_bb_107;
    z_bb_105:
    goto z_bb_103;
    z_bb_106:
    zT_285 = self;
    zT_286 = l_decl.child_1;
    zT_291 = zF_4EE17137_comptimeEvalEvaluat(zT_285, zT_286, (unsigned int)(depth + (unsigned int)(1)));
    lv = zT_291;
    zT_292 = lv.has_value;
    if (zT_292) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    lvv = lv.value;
    zT_294 = self;
    zT_295 = l_decl_node;
    zT_296 = lvv;
    zT_297 = zF_EFA97F51_comptimeEvalDeclFit(zT_294, zT_295, zT_296);
    if ((unsigned char)(!zT_297)) goto z_bb_110; else goto z_bb_111;
    z_bb_109:
    return lv;
    z_bb_110:
    zT_299.has_value = 0;
    return zT_299;
    z_bb_111:
    goto z_bb_109;
    z_bb_112:
    zT_303 = self->symbol_reg;
    zT_304 = zT_303->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_304))) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_308 = self->symbol_reg;
    zT_310 = name_id;
    zT_313 = zF_A398987E_symbolRegistryQuali(zT_308, (unsigned int)((unsigned int)mi), zT_310);
    c_sym = zT_313;
    zT_314 = c_sym.has_value;
    if (zT_314) goto z_bb_116; else goto z_bb_117;
    z_bb_114:
    zT_350.has_value = 0;
    return zT_350;
    z_bb_115:
    zT_347 = 1;
    zT_349 = mi + (unsigned int)((unsigned int)zT_347);
    mi = zT_349;
    goto z_bb_112;
    z_bb_116:
    cs = c_sym.value;
    zT_316 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_316 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_118; else goto z_bb_119;
    z_bb_117:
    goto z_bb_115;
    z_bb_118:
    zT_322 = self->store;
    zT_323 = cs->decl_node;
    zT_326 = zF_FCDD1D35_astStoreNodeAt(zT_322, zT_323);
    c_decl = zT_326;
    zT_327 = c_decl.child_1;
    if ((unsigned char)(zT_327 != (unsigned int)(0))) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    goto z_bb_117;
    z_bb_120:
    zT_331 = self;
    zT_332 = c_decl.child_1;
    zT_337 = zF_4EE17137_comptimeEvalEvaluat(zT_331, zT_332, (unsigned int)(depth + (unsigned int)(1)));
    cv_1 = zT_337;
    zT_338 = cv_1.has_value;
    if (zT_338) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    cvv = cv_1.value;
    zT_340 = self;
    zT_341 = cs->decl_node;
    zT_342 = cvv;
    zT_344 = zF_EFA97F51_comptimeEvalDeclFit(zT_340, zT_341, zT_342);
    if ((unsigned char)(!zT_344)) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    return cv_1;
    z_bb_124:
    zT_346.has_value = 0;
    return zT_346;
    z_bb_125:
    goto z_bb_123;
}

/* comptimeEvalDeclFits */
unsigned char zF_EFA97F51_comptimeEvalDeclFit(zT_DA663F79_ComptimeEval* self, unsigned int decl_node, zT_89B1DDDA_ComptimeVal v) {
    unsigned char zT_3;
    zT_6B0A7D14_AstStore* zT_8;
    unsigned int zT_9;
    zT_22A7C88B_AstNode zT_11 = {0};
    unsigned int zT_12;
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    zT_BAEE192E_Opt_10 zT_19 = {0};
    unsigned char zT_20;
    zT_338B7C76_TypeRegistry* zT_22;
    unsigned int zT_23;
    unsigned char zT_25 = 0;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_0163D9A4_ComptimeInt zT_27;
    unsigned int zT_28;
    zT_0163D9A4_ComptimeInt zT_30;
    unsigned char zT_31 = 0;
    zT_22A7C88B_AstNode d;
    unsigned int t;
    zT_3 = v.kind;
    if ((unsigned char)(zT_3 != (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_8 = self->store;
    zT_9 = decl_node;
    zT_11 = zF_FCDD1D35_astStoreNodeAt(zT_8, zT_9);
    d = zT_11;
    zT_12 = d.child_0;
    if ((unsigned char)(zT_12 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_16 = self;
    zT_17 = d.child_0;
    zT_19 = zF_BAD6BA5D_comptimeEvalResolve(zT_16, zT_17);
    zT_20 = zT_19.has_value;
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    t = zT_19.value;
    zT_22 = self->registry;
    zT_23 = t;
    zT_25 = zF_3290E9C4_typeRegistryIsInteg(zT_22, zT_23);
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(1);
    z_bb_7:
    zT_26 = self->registry;
    zT_30 = v.v;
    zT_27 = zT_30;
    zT_28 = t;
    zT_31 = zF_B28C4720_comptimeIntFitsType(zT_26, zT_27, zT_28);
    return zT_31;
    z_bb_8:
    goto z_bb_6;
}

/* EOF */
