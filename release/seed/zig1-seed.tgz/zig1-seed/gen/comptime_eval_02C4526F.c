#include "comptime_eval_02C4526F.h"
unsigned int zG_9D6D351A_WIDTH_FLOAT;
/* comptimeEvalInit */
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry* registry, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_3D7259E2_SymbolRegistry* symbol_reg) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_D3EB6303_StringInterner* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_D3EB6303_StringInterner* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27 = 0;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_D3EB6303_StringInterner* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35 = 0;
    unsigned char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_D3EB6303_StringInterner* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43 = 0;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    zT_D3EB6303_StringInterner* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51 = 0;
    unsigned char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    unsigned char* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_D3EB6303_StringInterner* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67 = 0;
    zT_D3EB6303_StringInterner* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71 = 0;
    zT_D3EB6303_StringInterner* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75 = 0;
    unsigned char* zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    unsigned int zT_79;
    zT_D3EB6303_StringInterner* zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    unsigned int zT_83 = 0;
    zT_DA663F79_ComptimeEval zT_84;
    unsigned char zT_85;
    zT_7034F045_Opt_228 zT_86 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_as;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fc;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_itf;
    unsigned int itf_id;
    unsigned int size_id;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int off_id;
    unsigned int bitsz_id;
    unsigned int bitoff_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_iw;
    unsigned int iw_id;
    zT_5 = "@sizeOf";
    zT_7 = 7;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_size = zT_6;
    zT_9 = "@alignOf";
    zT_11 = 8;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_align = zT_10;
    zT_13 = "@intCast";
    zT_15 = 8;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    s_intc = zT_14;
    zT_17 = interner;
    zT_18 = s_intc;
    zT_19 = zF_50C274AF_stringInternerInter(zT_17, zT_18);
    intc_id = zT_19;
    zT_21 = "@as";
    zT_23 = 3;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    s_as = zT_22;
    zT_25 = interner;
    zT_26 = s_as;
    zT_27 = zF_50C274AF_stringInternerInter(zT_25, zT_26);
    as_id = zT_27;
    zT_29 = "@floatCast";
    zT_31 = 10;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    s_fc = zT_30;
    zT_33 = interner;
    zT_34 = s_fc;
    zT_35 = zF_50C274AF_stringInternerInter(zT_33, zT_34);
    fc_id = zT_35;
    zT_37 = "@intToFloat";
    zT_39 = 11;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    s_itf = zT_38;
    zT_41 = interner;
    zT_42 = s_itf;
    zT_43 = zF_50C274AF_stringInternerInter(zT_41, zT_42);
    itf_id = zT_43;
    zT_45 = interner;
    zT_46 = s_size;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    size_id = zT_47;
    zT_49 = interner;
    zT_50 = s_align;
    zT_51 = zF_50C274AF_stringInternerInter(zT_49, zT_50);
    align_id = zT_51;
    zT_53 = "@offsetOf";
    zT_55 = 9;
    zT_54.ptr = zT_53;
    zT_54.len = zT_55;
    s_off = zT_54;
    zT_57 = "@bitSizeOf";
    zT_59 = 10;
    zT_58.ptr = zT_57;
    zT_58.len = zT_59;
    s_bitsz = zT_58;
    zT_61 = "@bitOffsetOf";
    zT_63 = 12;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    s_bitoff = zT_62;
    zT_65 = interner;
    zT_66 = s_off;
    zT_67 = zF_50C274AF_stringInternerInter(zT_65, zT_66);
    off_id = zT_67;
    zT_69 = interner;
    zT_70 = s_bitsz;
    zT_71 = zF_50C274AF_stringInternerInter(zT_69, zT_70);
    bitsz_id = zT_71;
    zT_73 = interner;
    zT_74 = s_bitoff;
    zT_75 = zF_50C274AF_stringInternerInter(zT_73, zT_74);
    bitoff_id = zT_75;
    zT_77 = "@isWindows";
    zT_79 = 10;
    zT_78.ptr = zT_77;
    zT_78.len = zT_79;
    s_iw = zT_78;
    zT_81 = interner;
    zT_82 = s_iw;
    zT_83 = zF_50C274AF_stringInternerInter(zT_81, zT_82);
    iw_id = zT_83;
    zT_84.registry = registry;
    zT_84.store = store;
    zT_84.interner = interner;
    zT_84.symbol_reg = symbol_reg;
    zT_84.size_of_id = size_id;
    zT_84.align_of_id = align_id;
    zT_84.int_cast_id = intc_id;
    zT_84.as_id = as_id;
    zT_84.float_cast_id = fc_id;
    zT_84.int_to_float_id = itf_id;
    zT_84.offset_of_id = off_id;
    zT_84.bit_size_of_id = bitsz_id;
    zT_84.bit_offset_of_id = bitoff_id;
    zT_84.is_windows_id = iw_id;
    zT_85 = 0;
    zT_84.host_is_windows = zT_85;
    zT_86.has_value = 0;
    zT_84.diag = zT_86;
    return zT_84;
}

/* comptimeEvalBinOp */
zT_E53A25A2_Opt_203 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_E53A25A2_Opt_203 zT_14 = {0};
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_E53A25A2_Opt_203 zT_20 = {0};
    unsigned char zT_21;
    unsigned char zT_23;
    unsigned int zT_25;
    unsigned char zT_28;
    unsigned int zT_29;
    zT_E53A25A2_Opt_203 zT_32 = {0};
    zT_79FAE712_u64 zT_34;
    zT_79FAE712_u64 zT_36;
    unsigned char zT_38;
    unsigned char zT_39;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45;
    zT_89B1DDDA_ComptimeVal zT_49;
    zT_79FAE712_u64 zT_50;
    zT_E53A25A2_Opt_203 zT_51;
    zT_89B1DDDA_ComptimeVal zT_55;
    zT_79FAE712_u64 zT_56;
    zT_E53A25A2_Opt_203 zT_57;
    zT_89B1DDDA_ComptimeVal zT_61;
    zT_79FAE712_u64 zT_62;
    zT_E53A25A2_Opt_203 zT_63;
    zT_E53A25A2_Opt_203 zT_69 = {0};
    zT_79FAE712_u64 zT_74;
    zT_79FAE712_u64 zT_79;
    zT_79FAE712_u64 zT_81 = 0;
    zT_79FAE712_u64 zT_83 = 0;
    zT_79FAE712_u64 zT_87;
    zT_79FAE712_u64 zT_91;
    zT_79FAE712_u64 zT_93;
    zT_79FAE712_u64 zT_96;
    zT_89B1DDDA_ComptimeVal zT_97;
    unsigned char zT_98;
    zT_E53A25A2_Opt_203 zT_99;
    zT_89B1DDDA_ComptimeVal zT_100;
    zT_79FAE712_u64 zT_101;
    unsigned char zT_102;
    zT_E53A25A2_Opt_203 zT_103;
    zT_E53A25A2_Opt_203 zT_109 = {0};
    zT_79FAE712_u64 zT_114;
    zT_79FAE712_u64 zT_119;
    zT_79FAE712_u64 zT_121 = 0;
    zT_79FAE712_u64 zT_123 = 0;
    zT_79FAE712_u64 zT_127;
    zT_79FAE712_u64 zT_131;
    zT_79FAE712_u64 zT_133;
    zT_79FAE712_u64 zT_137;
    zT_89B1DDDA_ComptimeVal zT_138;
    unsigned char zT_139;
    zT_E53A25A2_Opt_203 zT_140;
    zT_89B1DDDA_ComptimeVal zT_141;
    zT_79FAE712_u64 zT_142;
    unsigned char zT_143;
    zT_E53A25A2_Opt_203 zT_144;
    zT_89B1DDDA_ComptimeVal zT_148;
    zT_79FAE712_u64 zT_149;
    zT_E53A25A2_Opt_203 zT_150;
    zT_89B1DDDA_ComptimeVal zT_154;
    zT_79FAE712_u64 zT_155;
    zT_E53A25A2_Opt_203 zT_156;
    zT_89B1DDDA_ComptimeVal zT_160;
    zT_79FAE712_u64 zT_161;
    zT_E53A25A2_Opt_203 zT_162;
    zT_E53A25A2_Opt_203 zT_168 = {0};
    zT_89B1DDDA_ComptimeVal zT_169;
    zT_79FAE712_u64 zT_170;
    zT_E53A25A2_Opt_203 zT_171;
    zT_E53A25A2_Opt_203 zT_177 = {0};
    zT_89B1DDDA_ComptimeVal zT_178;
    zT_79FAE712_u64 zT_179;
    zT_E53A25A2_Opt_203 zT_180;
    zT_E53A25A2_Opt_203 zT_181 = {0};
    zT_22A7C88B_AstNode node;
    zT_E53A25A2_Opt_203 lhs;
    zT_E53A25A2_Opt_203 rhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_89B1DDDA_ComptimeVal r;
    zT_79FAE712_u64 lv;
    zT_79FAE712_u64 rv;
    unsigned char use_signed;
    unsigned int maxw;
    zT_79FAE712_u64 sl;
    zT_79FAE712_u64 sr;
    zT_79FAE712_u64 al;
    zT_79FAE712_u64 ar;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 rem;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    zT_16 = self;
    zT_17 = node.child_1;
    zT_18 = depth;
    zT_20 = zF_4EE17137_comptimeEvalEvaluat(zT_16, zT_17, zT_18);
    rhs = zT_20;
    zT_21 = lhs.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    l = lhs.value;
    zT_23 = rhs.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_181.has_value = 0;
    return zT_181;
    z_bb_3:
    r = rhs.value;
    zT_25 = l.width_bits;
    if ((unsigned char)(zT_25 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_29 = r.width_bits;
    zT_28 = zT_29 == zG_9D6D351A_WIDTH_FLOAT;
    goto z_bb_7;
    z_bb_6:
    zT_28 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_28) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_9:
    zT_34 = l.bits;
    lv = zT_34;
    zT_36 = r.bits;
    rv = zT_36;
    zT_38 = l.sig;
    if (zT_38) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_39 = r.sig;
    goto z_bb_12;
    z_bb_11:
    zT_39 = 1;
    goto z_bb_12;
    z_bb_12:
    use_signed = zT_39;
    zT_42 = l.width_bits;
    maxw = zT_42;
    zT_43 = r.width_bits;
    if ((unsigned char)(zT_43 > maxw)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = r.width_bits;
    maxw = zT_45;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_50 = lv + rv;
    zT_49.bits = zT_50;
    zT_49.width_bits = maxw;
    zT_49.sig = use_signed;
    zT_51.has_value = 1;
    zT_51.value = zT_49;
    return zT_51;
    z_bb_16:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_56 = lv - rv;
    zT_55.bits = zT_56;
    zT_55.width_bits = maxw;
    zT_55.sig = use_signed;
    zT_57.has_value = 1;
    zT_57.value = zT_55;
    return zT_57;
    z_bb_18:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_62 = lv * rv;
    zT_61.bits = zT_62;
    zT_61.width_bits = maxw;
    zT_61.sig = use_signed;
    zT_63.has_value = 1;
    zT_63.value = zT_61;
    return zT_63;
    z_bb_20:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    if ((unsigned char)(rv == (zT_79FAE712_u64)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op))) goto z_bb_35; else goto z_bb_36;
    z_bb_23:
    zT_69.has_value = 0;
    return zT_69;
    z_bb_24:
    if (use_signed) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_74 = (zT_79FAE712_u64)(lv >> (zT_79FAE712_u64)(63)) & (zT_79FAE712_u64)(1);
    sl = zT_74;
    zT_79 = (zT_79FAE712_u64)(rv >> (zT_79FAE712_u64)(63)) & (zT_79FAE712_u64)(1);
    sr = zT_79;
    al = zT_81;
    ar = zT_83;
    if ((unsigned char)(sl == (zT_79FAE712_u64)(1))) goto z_bb_27; else goto z_bb_29;
    z_bb_26:
    zT_101 = lv / rv;
    zT_100.bits = zT_101;
    zT_100.width_bits = maxw;
    zT_102 = 0;
    zT_100.sig = zT_102;
    zT_103.has_value = 1;
    zT_103.value = zT_100;
    return zT_103;
    z_bb_27:
    zT_87 = (zT_79FAE712_u64)(0) - lv;
    al = zT_87;
    goto z_bb_28;
    z_bb_28:
    if ((unsigned char)(sr == (zT_79FAE712_u64)(1))) goto z_bb_30; else goto z_bb_32;
    z_bb_29:
    al = lv;
    goto z_bb_28;
    z_bb_30:
    zT_91 = (zT_79FAE712_u64)(0) - rv;
    ar = zT_91;
    goto z_bb_31;
    z_bb_31:
    zT_93 = al / ar;
    q = zT_93;
    if ((unsigned char)(sl != sr)) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    ar = rv;
    goto z_bb_31;
    z_bb_33:
    zT_96 = (zT_79FAE712_u64)(0) - q;
    q = zT_96;
    goto z_bb_34;
    z_bb_34:
    zT_97.bits = q;
    zT_97.width_bits = maxw;
    zT_98 = 1;
    zT_97.sig = zT_98;
    zT_99.has_value = 1;
    zT_99.value = zT_97;
    return zT_99;
    z_bb_35:
    if ((unsigned char)(rv == (zT_79FAE712_u64)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_49; else goto z_bb_50;
    z_bb_37:
    zT_109.has_value = 0;
    return zT_109;
    z_bb_38:
    if (use_signed) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_114 = (zT_79FAE712_u64)(lv >> (zT_79FAE712_u64)(63)) & (zT_79FAE712_u64)(1);
    sl = zT_114;
    zT_119 = (zT_79FAE712_u64)(rv >> (zT_79FAE712_u64)(63)) & (zT_79FAE712_u64)(1);
    sr = zT_119;
    al = zT_121;
    ar = zT_123;
    if ((unsigned char)(sl == (zT_79FAE712_u64)(1))) goto z_bb_41; else goto z_bb_43;
    z_bb_40:
    zT_142 = lv % rv;
    zT_141.bits = zT_142;
    zT_141.width_bits = maxw;
    zT_143 = 0;
    zT_141.sig = zT_143;
    zT_144.has_value = 1;
    zT_144.value = zT_141;
    return zT_144;
    z_bb_41:
    zT_127 = (zT_79FAE712_u64)(0) - lv;
    al = zT_127;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(sr == (zT_79FAE712_u64)(1))) goto z_bb_44; else goto z_bb_46;
    z_bb_43:
    al = lv;
    goto z_bb_42;
    z_bb_44:
    zT_131 = (zT_79FAE712_u64)(0) - rv;
    ar = zT_131;
    goto z_bb_45;
    z_bb_45:
    zT_133 = al % ar;
    rem = zT_133;
    if ((unsigned char)(sl == (zT_79FAE712_u64)(1))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    ar = rv;
    goto z_bb_45;
    z_bb_47:
    zT_137 = (zT_79FAE712_u64)(0) - rem;
    rem = zT_137;
    goto z_bb_48;
    z_bb_48:
    zT_138.bits = rem;
    zT_138.width_bits = maxw;
    zT_139 = 1;
    zT_138.sig = zT_139;
    zT_140.has_value = 1;
    zT_140.value = zT_138;
    return zT_140;
    z_bb_49:
    zT_149 = lv & rv;
    zT_148.bits = zT_149;
    zT_148.width_bits = maxw;
    zT_148.sig = use_signed;
    zT_150.has_value = 1;
    zT_150.value = zT_148;
    return zT_150;
    z_bb_50:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_155 = lv | rv;
    zT_154.bits = zT_155;
    zT_154.width_bits = maxw;
    zT_154.sig = use_signed;
    zT_156.has_value = 1;
    zT_156.value = zT_154;
    return zT_156;
    z_bb_52:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_161 = lv ^ rv;
    zT_160.bits = zT_161;
    zT_160.width_bits = maxw;
    zT_160.sig = use_signed;
    zT_162.has_value = 1;
    zT_162.value = zT_160;
    return zT_162;
    z_bb_54:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    if ((unsigned char)(rv >= (zT_79FAE712_u64)(64))) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_168.has_value = 0;
    return zT_168;
    z_bb_58:
    zT_170 = lv << rv;
    zT_169.bits = zT_170;
    zT_169.width_bits = maxw;
    zT_169.sig = use_signed;
    zT_171.has_value = 1;
    zT_171.value = zT_169;
    return zT_171;
    z_bb_59:
    if ((unsigned char)(rv >= (zT_79FAE712_u64)(64))) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_4;
    z_bb_61:
    zT_177.has_value = 0;
    return zT_177;
    z_bb_62:
    zT_179 = lv >> rv;
    zT_178.bits = zT_179;
    zT_178.width_bits = maxw;
    zT_178.sig = use_signed;
    zT_180.has_value = 1;
    zT_180.value = zT_178;
    return zT_180;
}

/* comptimeEvalResolveTypeArg */
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    unsigned int zT_12;
    zT_7034F045_Opt_228 zT_13 = {0};
    zT_03B97CED_Opt_398 zT_14 = {0};
    zT_05CE5599_Opt_400 zT_15 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_17;
    unsigned int zT_18;
    unsigned int zT_22 = 0;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    zT_BAEE192E_Opt_10 zT_26;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int tid;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_7 = self->store;
    zT_6.store = zT_7;
    zT_8 = self->registry;
    zT_6.typereg = zT_8;
    zT_9 = self->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = self->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_12 = 0;
    zT_6.source_file_id = zT_12;
    zT_13.has_value = 0;
    zT_6.diag = zT_13;
    zT_14.has_value = 0;
    zT_6.local_consts = zT_14;
    zT_15.has_value = 0;
    zT_6.local_types = zT_15;
    env = zT_6;
    zT_17 = &env;
    zT_18 = node_idx;
    zT_22 = zF_F2107C15_resolveTypeExprFull(zT_17, zT_18, (unsigned int)(0));
    tid = zT_22;
    if ((unsigned char)(tid == (unsigned int)(18))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_4:
    zT_26.has_value = 1;
    zT_26.value = tid;
    return zT_26;
}

/* comptimeValFitsType */
unsigned char zF_BB4D792E_comptimeValFitsType(zT_DA663F79_ComptimeEval* self, zT_89B1DDDA_ComptimeVal cv, unsigned int t, unsigned int operand_idx) {
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    unsigned char zT_7 = 0;
    zT_338B7C76_TypeRegistry* zT_11;
    unsigned int zT_12;
    unsigned char zT_14 = 0;
    unsigned int zT_15;
    zT_DA663F79_ComptimeEval* zT_19;
    unsigned int zT_20;
    zT_FEE05D6C_SignClass zT_23 = 0;
    zT_79FAE712_u64 zT_25;
    zT_C69B2266_i64 zT_26;
    zT_338B7C76_TypeRegistry* zT_27;
    unsigned int zT_28;
    unsigned char zT_30 = 0;
    unsigned char zT_33;
    unsigned char zT_40;
    zT_338B7C76_TypeRegistry* zT_49;
    unsigned int zT_50;
    unsigned char zT_52 = 0;
    zT_79FAE712_u64 zT_54;
    zT_C69B2266_i64 zT_55;
    zT_79FAE712_u64 zT_63;
    zT_79FAE712_u64 zT_69;
    zT_79FAE712_u64 zT_78;
    zT_79FAE712_u64 zT_79;
    zT_79FAE712_u64 zT_86;
    zT_79FAE712_u64 zT_87;
    unsigned int wb;
    zT_FEE05D6C_SignClass sc64;
    zT_C69B2266_i64 sval64;
    unsigned char tsig;
    zT_C69B2266_i64 sval;
    zT_79FAE712_u64 mag;
    zT_79FAE712_u64 smin_mag;
    zT_79FAE712_u64 smax;
    zT_79FAE712_u64 umax;
    zT_4 = self->registry;
    zT_5 = t;
    zT_7 = zF_3290E9C4_typeRegistryIsInteg(zT_4, zT_5);
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_11 = self->registry;
    zT_12 = t;
    zT_14 = zF_655972D5_typeRegistryIntWidt(zT_11, zT_12);
    zT_15 = (unsigned int)zT_14;
    wb = zT_15;
    if ((unsigned char)(wb >= (unsigned int)(64))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = self;
    zT_20 = operand_idx;
    zT_23 = zF_E7337520_comptimeEvalSignCla(zT_19, zT_20, (unsigned int)(0));
    sc64 = zT_23;
    zT_25 = cv.bits;
    zT_26 = (zT_C69B2266_i64)zT_25;
    sval64 = zT_26;
    zT_27 = self->registry;
    zT_28 = t;
    zT_30 = zF_01ED6537_typeRegistryIntIsSi(zT_27, zT_28);
    if (zT_30) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    if ((unsigned char)(wb == (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_5:
    if ((unsigned char)(sc64 == (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_non_negative))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    if ((unsigned char)(sc64 == (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_negative))) goto z_bb_12; else goto z_bb_13;
    z_bb_7:
    zT_33 = sval64 < (zT_C69B2266_i64)(0);
    goto z_bb_9;
    z_bb_8:
    zT_33 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_33) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (unsigned char)(0);
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_40 = sval64 < (zT_C69B2266_i64)(0);
    goto z_bb_14;
    z_bb_13:
    zT_40 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_40) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    return (unsigned char)(1);
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    zT_49 = self->registry;
    zT_50 = t;
    zT_52 = zF_01ED6537_typeRegistryIntIsSi(zT_49, zT_50);
    tsig = zT_52;
    zT_54 = cv.bits;
    zT_55 = (zT_C69B2266_i64)zT_54;
    sval = zT_55;
    if ((unsigned char)(sval < (zT_C69B2266_i64)(0))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    if ((unsigned char)(!tsig)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    if (tsig) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    zT_63 = (zT_79FAE712_u64)(zT_C69B2266_i64)((zT_C69B2266_i64)(0) - sval);
    mag = zT_63;
    zT_69 = (zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(wb - (unsigned int)(1)));
    smin_mag = zT_69;
    return (unsigned char)(mag <= smin_mag);
    z_bb_23:
    zT_78 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(wb - (unsigned int)(1)))) - (zT_79FAE712_u64)(1);
    smax = zT_78;
    zT_79 = cv.bits;
    return (unsigned char)(zT_79 <= smax);
    z_bb_24:
    zT_86 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)wb)) - (zT_79FAE712_u64)(1);
    umax = zT_86;
    zT_87 = cv.bits;
    return (unsigned char)(zT_87 <= umax);
}

/* comptimeEvalSignClass */
zT_FEE05D6C_SignClass zF_E7337520_comptimeEvalSignCla(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned char zT_18;
    zT_8143F551_AstKind zT_19;
    unsigned char zT_23;
    zT_8143F551_AstKind zT_24;
    zT_8143F551_AstKind zT_29;
    zT_8143F551_AstKind zT_34;
    zT_DA663F79_ComptimeEval* zT_38;
    unsigned int zT_41;
    unsigned int zT_43;
    zT_8143F551_AstKind zT_45;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    unsigned int zT_53 = 0;
    int zT_55;
    unsigned int zT_56;
    zT_3D7259E2_SymbolRegistry* zT_57;
    unsigned int zT_58;
    zT_3D7259E2_SymbolRegistry* zT_62;
    unsigned int zT_64;
    zT_5F7DAFEE_Opt_863 zT_67 = {0};
    unsigned char zT_68;
    unsigned short zT_70;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    zT_22A7C88B_AstNode zT_80 = {0};
    zT_DA663F79_ComptimeEval* zT_82;
    unsigned int zT_83;
    zT_BAEE192E_Opt_10 zT_85 = {0};
    unsigned char zT_86;
    zT_338B7C76_TypeRegistry* zT_88;
    unsigned int zT_89;
    unsigned char zT_91 = 0;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    unsigned char zT_95 = 0;
    unsigned int zT_98;
    zT_DA663F79_ComptimeEval* zT_101;
    unsigned int zT_104;
    unsigned int zT_106;
    int zT_108;
    unsigned int zT_110;
    zT_8143F551_AstKind zT_112;
    unsigned int zT_116;
    unsigned int zT_117;
    unsigned char zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_DA663F79_ComptimeEval* zT_124;
    unsigned int zT_125;
    zT_6B0A7D14_AstStore* zT_126;
    unsigned int zT_127;
    unsigned int zT_131 = 0;
    zT_BAEE192E_Opt_10 zT_132 = {0};
    unsigned char zT_133;
    zT_338B7C76_TypeRegistry* zT_135;
    unsigned int zT_136;
    unsigned char zT_138 = 0;
    zT_338B7C76_TypeRegistry* zT_139;
    unsigned int zT_140;
    unsigned char zT_142 = 0;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int mi;
    zT_5F7DAFEE_Opt_863 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_BAEE192E_Opt_10 dt;
    unsigned int t;
    zT_BAEE192E_Opt_10 dt2;
    unsigned int t2;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_unknown);
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_unknown);
    z_bb_4:
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_19 = node.kind;
    zT_18 = zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_9; else goto z_bb_8;
    z_bb_8:
    zT_24 = node.kind;
    zT_23 = zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal);
    goto z_bb_10;
    z_bb_9:
    zT_23 = 1;
    goto z_bb_10;
    z_bb_10:
    if (zT_23) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_non_negative);
    z_bb_12:
    zT_29 = node.kind;
    if ((unsigned char)(zT_29 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_negative);
    z_bb_14:
    zT_34 = node.kind;
    if ((unsigned char)(zT_34 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_38 = self;
    zT_41 = node.child_0;
    zT_43 = depth + (unsigned int)(1);
    self = zT_38;
    node_idx = zT_41;
    depth = zT_43;
    goto z_bb_0;
    z_bb_16:
    zT_45 = node.kind;
    if ((unsigned char)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_50 = self->store;
    zT_51 = node_idx;
    zT_53 = zF_53458827_astStoreIdentifier(zT_50, zT_51);
    name_id = zT_53;
    zT_55 = 0;
    zT_56 = (unsigned int)zT_55;
    mi = zT_56;
    goto z_bb_19;
    z_bb_18:
    zT_112 = node.kind;
    if ((unsigned char)(zT_112 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_35; else goto z_bb_36;
    z_bb_19:
    zT_57 = self->symbol_reg;
    zT_58 = zT_57->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_58))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_62 = self->symbol_reg;
    zT_64 = name_id;
    zT_67 = zF_A398987E_symbolRegistryQuali(zT_62, (unsigned int)((unsigned int)mi), zT_64);
    c_sym = zT_67;
    zT_68 = c_sym.has_value;
    if (zT_68) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_unknown);
    z_bb_22:
    zT_108 = 1;
    zT_110 = mi + (unsigned int)((unsigned int)zT_108);
    mi = zT_110;
    goto z_bb_19;
    z_bb_23:
    cs = c_sym.value;
    zT_70 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_70 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_76 = self->store;
    zT_77 = cs->decl_node;
    zT_80 = zF_FCDD1D35_astStoreNodeAt(zT_76, zT_77);
    c_decl = zT_80;
    zT_82 = self;
    zT_83 = c_decl.child_0;
    zT_85 = zF_BAD6BA5D_comptimeEvalResolve(zT_82, zT_83);
    dt = zT_85;
    zT_86 = dt.has_value;
    if (zT_86) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    t = dt.value;
    zT_88 = self->registry;
    zT_89 = t;
    zT_91 = zF_3290E9C4_typeRegistryIsInteg(zT_88, zT_89);
    if (zT_91) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    zT_98 = c_decl.child_1;
    if ((unsigned char)(zT_98 != (unsigned int)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_29:
    zT_92 = self->registry;
    zT_93 = t;
    zT_95 = zF_01ED6537_typeRegistryIntIsSi(zT_92, zT_93);
    if (zT_95) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_negative);
    z_bb_32:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_non_negative);
    z_bb_33:
    zT_101 = self;
    zT_104 = c_decl.child_1;
    zT_106 = depth + (unsigned int)(1);
    self = zT_101;
    node_idx = zT_104;
    depth = zT_106;
    goto z_bb_0;
    z_bb_34:
    goto z_bb_26;
    z_bb_35:
    zT_116 = node.child_0;
    zT_117 = self->int_cast_id;
    if ((unsigned char)(zT_116 == zT_117)) goto z_bb_38; else goto z_bb_37;
    z_bb_36:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_unknown);
    z_bb_37:
    zT_120 = node.child_0;
    zT_121 = self->as_id;
    zT_119 = zT_120 == zT_121;
    goto z_bb_39;
    z_bb_38:
    zT_119 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_119) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_124 = self;
    zT_126 = self->store;
    zT_127 = node_idx;
    zT_131 = zF_B10B1BC1_astStoreNodeExtraCh(zT_126, zT_127, (unsigned int)(0));
    zT_125 = zT_131;
    zT_132 = zF_BAD6BA5D_comptimeEvalResolve(zT_124, zT_125);
    dt2 = zT_132;
    zT_133 = dt2.has_value;
    if (zT_133) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_unknown);
    z_bb_42:
    t2 = dt2.value;
    zT_135 = self->registry;
    zT_136 = t2;
    zT_138 = zF_3290E9C4_typeRegistryIsInteg(zT_135, zT_136);
    if (zT_138) goto z_bb_44; else goto z_bb_45;
    z_bb_43:
    goto z_bb_41;
    z_bb_44:
    zT_139 = self->registry;
    zT_140 = t2;
    zT_142 = zF_01ED6537_typeRegistryIntIsSi(zT_139, zT_140);
    if (zT_142) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_43;
    z_bb_46:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_negative);
    z_bb_47:
    return (zT_FEE05D6C_SignClass)(zT_FEE05D6C_SignClass_non_negative);
}

/* comptimeEvalBuiltin */
zT_E53A25A2_Opt_203 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_DA663F79_ComptimeEval* zT_12;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_19 = 0;
    zT_BAEE192E_Opt_10 zT_20 = {0};
    unsigned char zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_D155D06D_Type* zT_25;
    unsigned int zT_26;
    zT_D155D06D_Type zT_27;
    unsigned char zT_28;
    zT_89B1DDDA_ComptimeVal zT_31;
    unsigned int zT_32;
    zT_79FAE712_u64 zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    zT_E53A25A2_Opt_203 zT_36;
    zT_E53A25A2_Opt_203 zT_37 = {0};
    unsigned int zT_38;
    unsigned int zT_39;
    zT_DA663F79_ComptimeEval* zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    unsigned int zT_49 = 0;
    zT_BAEE192E_Opt_10 zT_50 = {0};
    unsigned char zT_51;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_D155D06D_Type* zT_55;
    unsigned int zT_56;
    zT_D155D06D_Type zT_57;
    unsigned char zT_58;
    zT_89B1DDDA_ComptimeVal zT_61;
    unsigned int zT_62;
    zT_79FAE712_u64 zT_63;
    unsigned int zT_64;
    unsigned char zT_65;
    zT_E53A25A2_Opt_203 zT_66;
    zT_E53A25A2_Opt_203 zT_67 = {0};
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_79 = 0;
    zT_DA663F79_ComptimeEval* zT_83;
    unsigned int zT_84;
    zT_6B0A7D14_AstStore* zT_85;
    unsigned int zT_86;
    unsigned int zT_90 = 0;
    zT_BAEE192E_Opt_10 zT_91 = {0};
    unsigned char zT_92;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_D155D06D_Type* zT_96;
    unsigned int zT_97;
    zT_D155D06D_Type zT_98;
    unsigned char zT_99;
    unsigned char zT_102;
    zT_33EF6BFB_TypeKind zT_103;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_108 = {0};
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int zT_110;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_111;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_115 = {0};
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int zT_118;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_119;
    unsigned char zT_122 = 0;
    zT_6B0A7D14_AstStore* zT_124;
    unsigned int zT_125;
    zT_6B0A7D14_AstStore* zT_127;
    unsigned int zT_128;
    unsigned int zT_132 = 0;
    zT_22A7C88B_AstNode zT_133 = {0};
    zT_8143F551_AstKind zT_134;
    zT_6B0A7D14_AstStore* zT_139;
    unsigned int zT_140;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_143;
    unsigned int zT_147 = 0;
    unsigned int zT_148 = 0;
    zT_6B0A7D14_AstStore* zT_150;
    zT_4CAAFA4A_anon_236175 zT_151;
    unsigned int* zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    int zT_156;
    unsigned int zT_157;
    unsigned int zT_159;
    zT_2DF01B61_FieldEntry* zT_161;
    zT_2DF01B61_FieldEntry zT_162;
    unsigned int zT_163;
    zT_2DF01B61_FieldEntry* zT_166;
    zT_2DF01B61_FieldEntry zT_167;
    unsigned int zT_168;
    zT_79FAE712_u64 zT_169;
    zT_79FAE712_u64 zT_171;
    unsigned int zT_173;
    zT_E276DDD0_PackedBitField* zT_175;
    zT_E276DDD0_PackedBitField zT_176;
    unsigned int zT_177;
    zT_79FAE712_u64 zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_79FAE712_u64 zT_183;
    unsigned int zT_184;
    unsigned int zT_185;
    zT_79FAE712_u64 zT_188;
    zT_89B1DDDA_ComptimeVal zT_189;
    unsigned int zT_190;
    unsigned char zT_191;
    zT_E53A25A2_Opt_203 zT_192;
    int zT_193;
    unsigned int zT_195;
    unsigned char zT_196;
    unsigned char zT_199;
    zT_33EF6BFB_TypeKind zT_200;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_205 = {0};
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_207;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_208;
    zT_6B0A7D14_AstStore* zT_212;
    unsigned int zT_213;
    zT_6B0A7D14_AstStore* zT_215;
    unsigned int zT_216;
    unsigned int zT_220 = 0;
    zT_22A7C88B_AstNode zT_221 = {0};
    zT_8143F551_AstKind zT_222;
    zT_6B0A7D14_AstStore* zT_227;
    unsigned int zT_228;
    zT_6B0A7D14_AstStore* zT_230;
    unsigned int zT_231;
    unsigned int zT_235 = 0;
    unsigned int zT_236 = 0;
    zT_6B0A7D14_AstStore* zT_238;
    zT_4CAAFA4A_anon_236175 zT_239;
    unsigned int* zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    int zT_244;
    unsigned int zT_245;
    unsigned int zT_247;
    zT_2DF01B61_FieldEntry* zT_249;
    zT_2DF01B61_FieldEntry zT_250;
    unsigned int zT_251;
    zT_79FAE712_u64 zT_254;
    unsigned int zT_255;
    unsigned int zT_256;
    zT_79FAE712_u64 zT_258;
    zT_89B1DDDA_ComptimeVal zT_259;
    unsigned int zT_260;
    unsigned char zT_261;
    zT_E53A25A2_Opt_203 zT_262;
    int zT_263;
    unsigned int zT_265;
    zT_E53A25A2_Opt_203 zT_266 = {0};
    unsigned int zT_267;
    unsigned int zT_268;
    zT_6B0A7D14_AstStore* zT_271;
    unsigned int zT_272;
    unsigned int zT_274 = 0;
    zT_DA663F79_ComptimeEval* zT_278;
    unsigned int zT_279;
    zT_6B0A7D14_AstStore* zT_280;
    unsigned int zT_281;
    unsigned int zT_285 = 0;
    zT_BAEE192E_Opt_10 zT_286 = {0};
    unsigned char zT_287;
    zT_338B7C76_TypeRegistry* zT_290;
    zT_D155D06D_Type* zT_291;
    unsigned int zT_292;
    zT_D155D06D_Type zT_293;
    unsigned char zT_294;
    unsigned int zT_298;
    zT_79FAE712_u64 zT_301;
    zT_33EF6BFB_TypeKind zT_302;
    unsigned char zT_306;
    unsigned char zT_307;
    zT_338B7C76_TypeRegistry* zT_312;
    unsigned int zT_313;
    unsigned int zT_315 = 0;
    zT_79FAE712_u64 zT_316;
    zT_33EF6BFB_TypeKind zT_317;
    zT_338B7C76_TypeRegistry* zT_321;
    unsigned int zT_322;
    unsigned int zT_324 = 0;
    zT_79FAE712_u64 zT_325;
    zT_338B7C76_TypeRegistry* zT_326;
    unsigned int zT_327;
    unsigned char zT_329 = 0;
    zT_338B7C76_TypeRegistry* zT_330;
    unsigned int zT_331;
    unsigned char zT_333 = 0;
    zT_79FAE712_u64 zT_334;
    zT_33EF6BFB_TypeKind zT_335;
    zT_338B7C76_TypeRegistry* zT_340;
    unsigned int zT_341;
    unsigned int zT_343 = 0;
    zT_338B7C76_TypeRegistry* zT_344;
    unsigned int zT_345;
    unsigned char zT_347 = 0;
    zT_79FAE712_u64 zT_348;
    zT_33EF6BFB_TypeKind zT_349;
    zT_79FAE712_u64 zT_353;
    zT_89B1DDDA_ComptimeVal zT_354;
    unsigned int zT_355;
    unsigned char zT_356;
    zT_E53A25A2_Opt_203 zT_357;
    zT_E53A25A2_Opt_203 zT_358 = {0};
    unsigned int zT_359;
    unsigned int zT_360;
    unsigned char zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    zT_DA663F79_ComptimeEval* zT_367;
    unsigned int zT_368;
    zT_6B0A7D14_AstStore* zT_369;
    unsigned int zT_370;
    unsigned int zT_374 = 0;
    zT_BAEE192E_Opt_10 zT_375 = {0};
    zT_DA663F79_ComptimeEval* zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    zT_6B0A7D14_AstStore* zT_380;
    unsigned int zT_381;
    unsigned int zT_385 = 0;
    zT_E53A25A2_Opt_203 zT_386 = {0};
    unsigned char zT_387;
    unsigned char zT_389;
    unsigned int zT_391;
    zT_E53A25A2_Opt_203 zT_394 = {0};
    zT_338B7C76_TypeRegistry* zT_396;
    zT_D155D06D_Type* zT_397;
    unsigned int zT_398;
    zT_D155D06D_Type zT_399;
    zT_338B7C76_TypeRegistry* zT_401;
    unsigned int zT_402;
    unsigned char zT_404 = 0;
    zT_338B7C76_TypeRegistry* zT_406;
    unsigned int zT_407;
    unsigned char zT_409 = 0;
    unsigned int zT_410;
    zT_338B7C76_TypeRegistry* zT_412;
    unsigned int zT_413;
    unsigned char zT_415 = 0;
    unsigned int zT_416;
    unsigned int zT_417;
    unsigned char zT_419;
    zT_E53A25A2_Opt_203 zT_421 = {0};
    unsigned int zT_423;
    unsigned int zT_426;
    unsigned char zT_427;
    unsigned char zT_428;
    zT_DA663F79_ComptimeEval* zT_429;
    zT_89B1DDDA_ComptimeVal zT_430;
    unsigned int zT_431;
    unsigned int zT_432;
    zT_6B0A7D14_AstStore* zT_433;
    unsigned int zT_434;
    unsigned int zT_438 = 0;
    unsigned char zT_439 = 0;
    zT_7034F045_Opt_228 zT_441;
    unsigned char zT_442;
    zT_F85C5DED_DiagnosticCollector* zT_444;
    unsigned int zT_445;
    unsigned char zT_446 = 0;
    unsigned char* zT_448;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_449;
    unsigned int zT_450;
    unsigned int zT_451;
    unsigned int zT_452;
    unsigned char* zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455;
    unsigned int zT_456;
    zT_F85C5DED_DiagnosticCollector* zT_457;
    unsigned int zT_461;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_463;
    unsigned int zT_468;
    unsigned int zT_469;
    unsigned int zT_472 = 0;
    zT_E53A25A2_Opt_203 zT_473 = {0};
    zT_89B1DDDA_ComptimeVal zT_476;
    zT_79FAE712_u64 zT_477;
    zT_E53A25A2_Opt_203 zT_478;
    zT_79FAE712_u64 zT_484;
    zT_79FAE712_u64 zT_486;
    zT_79FAE712_u64 zT_487;
    unsigned char zT_488;
    zT_79FAE712_u64 zT_489;
    zT_79FAE712_u64 zT_502;
    zT_79FAE712_u64 zT_503;
    zT_79FAE712_u64 zT_504;
    zT_89B1DDDA_ComptimeVal zT_505;
    zT_E53A25A2_Opt_203 zT_506;
    zT_E53A25A2_Opt_203 zT_507 = {0};
    unsigned int zT_508;
    unsigned int zT_509;
    zT_79FAE712_u64 zT_512;
    unsigned char zT_513;
    zT_79FAE712_u64 zT_514;
    zT_89B1DDDA_ComptimeVal zT_515;
    unsigned int zT_516;
    unsigned char zT_517;
    zT_E53A25A2_Opt_203 zT_518;
    unsigned int zT_519;
    unsigned int zT_520;
    unsigned char zT_522;
    unsigned int zT_523;
    unsigned int zT_524;
    zT_DA663F79_ComptimeEval* zT_527;
    unsigned int zT_528;
    unsigned int zT_529;
    zT_BCEE1C54_Opt_16 zT_530 = {0};
    unsigned char zT_531;
    double* zT_535;
    zT_79FAE712_u64* zT_536;
    zT_89B1DDDA_ComptimeVal zT_537;
    zT_79FAE712_u64 zT_538;
    unsigned char zT_540;
    zT_E53A25A2_Opt_203 zT_541;
    zT_E53A25A2_Opt_203 zT_542 = {0};
    zT_E53A25A2_Opt_203 zT_543 = {0};
    zT_22A7C88B_AstNode node;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    zT_D155D06D_Type ty;
    unsigned int ec2_n;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    unsigned char has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    zT_BF2E90D8_Slice_zT_2DF01B61_F u_fields;
    zT_22A7C88B_AstNode fname_node2;
    unsigned int sv_idx2;
    unsigned int want_id2;
    unsigned int fi2;
    zT_79FAE712_u64 ubo;
    unsigned int ec3_n;
    zT_BAEE192E_Opt_10 tid2;
    unsigned int t2;
    zT_D155D06D_Type ty2;
    zT_79FAE712_u64 bsz;
    unsigned int ebt;
    zT_E53A25A2_Opt_203 inner;
    zT_89B1DDDA_ComptimeVal cv;
    unsigned char is_int_t;
    unsigned int wb;
    unsigned char sig;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_msg;
    zT_79FAE712_u64 mask;
    zT_79FAE712_u64 masked;
    zT_79FAE712_u64 not_mask;
    zT_79FAE712_u64 wb2;
    zT_BCEE1C54_Opt_16 fv;
    double v;
    double fb;
    zT_79FAE712_u64* fbp;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.child_0;
    zT_9 = self->size_of_id;
    if ((unsigned char)(zT_8 == zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_14 = self->store;
    zT_15 = node_idx;
    zT_19 = zF_B10B1BC1_astStoreNodeExtraCh(zT_14, zT_15, (unsigned int)(0));
    zT_13 = zT_19;
    zT_20 = zF_BAD6BA5D_comptimeEvalResolve(zT_12, zT_13);
    tid = zT_20;
    zT_21 = tid.has_value;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_38 = node.child_0;
    zT_39 = self->align_of_id;
    if ((unsigned char)(zT_38 == zT_39)) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    t = tid.value;
    zT_24 = self->registry;
    zT_25 = zT_24->types_items;
    zT_26 = (unsigned int)t;
    zT_27 = zT_25[zT_26];
    ty = zT_27;
    zT_28 = ty.state;
    if ((unsigned char)(zT_28 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_37.has_value = 0;
    return zT_37;
    z_bb_5:
    zT_32 = ty.size;
    zT_33 = (zT_79FAE712_u64)zT_32;
    zT_31.bits = zT_33;
    zT_34 = 0;
    zT_31.width_bits = zT_34;
    zT_35 = 0;
    zT_31.sig = zT_35;
    zT_36.has_value = 1;
    zT_36.value = zT_31;
    return zT_36;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_42 = self;
    zT_44 = self->store;
    zT_45 = node_idx;
    zT_49 = zF_B10B1BC1_astStoreNodeExtraCh(zT_44, zT_45, (unsigned int)(0));
    zT_43 = zT_49;
    zT_50 = zF_BAD6BA5D_comptimeEvalResolve(zT_42, zT_43);
    tid = zT_50;
    zT_51 = tid.has_value;
    if (zT_51) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_68 = node.child_0;
    zT_69 = self->offset_of_id;
    if ((unsigned char)(zT_68 == zT_69)) goto z_bb_14; else goto z_bb_13;
    z_bb_9:
    t = tid.value;
    zT_54 = self->registry;
    zT_55 = zT_54->types_items;
    zT_56 = (unsigned int)t;
    zT_57 = zT_55[zT_56];
    ty = zT_57;
    zT_58 = ty.state;
    if ((unsigned char)(zT_58 == (unsigned char)(2))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_67.has_value = 0;
    return zT_67;
    z_bb_11:
    zT_62 = ty.alignment;
    zT_63 = (zT_79FAE712_u64)zT_62;
    zT_61.bits = zT_63;
    zT_64 = 0;
    zT_61.width_bits = zT_64;
    zT_65 = 0;
    zT_61.sig = zT_65;
    zT_66.has_value = 1;
    zT_66.value = zT_61;
    return zT_66;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_72 = node.child_0;
    zT_73 = self->bit_offset_of_id;
    zT_71 = zT_72 == zT_73;
    goto z_bb_15;
    z_bb_14:
    zT_71 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_71) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_76 = self->store;
    zT_77 = node_idx;
    zT_79 = zF_152E19CB_astStoreNodeExtraCh(zT_76, zT_77);
    ec2_n = zT_79;
    if ((unsigned char)(ec2_n >= (unsigned int)(2))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_267 = node.child_0;
    zT_268 = self->bit_size_of_id;
    if ((unsigned char)(zT_267 == zT_268)) goto z_bb_61; else goto z_bb_62;
    z_bb_18:
    zT_83 = self;
    zT_85 = self->store;
    zT_86 = node_idx;
    zT_90 = zF_B10B1BC1_astStoreNodeExtraCh(zT_85, zT_86, (unsigned int)(0));
    zT_84 = zT_90;
    zT_91 = zF_BAD6BA5D_comptimeEvalResolve(zT_83, zT_84);
    tid = zT_91;
    zT_92 = tid.has_value;
    if (zT_92) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_266.has_value = 0;
    return zT_266;
    z_bb_20:
    t = tid.value;
    zT_95 = self->registry;
    zT_96 = zT_95->types_items;
    zT_97 = (unsigned int)t;
    zT_98 = zT_96[zT_97];
    ty = zT_98;
    zT_99 = ty.state;
    if ((unsigned char)(zT_99 == (unsigned char)(2))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_103 = ty.kind;
    zT_102 = zT_103 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_24;
    z_bb_23:
    zT_102 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_102) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    fields = zT_108;
    zT_109 = self->registry;
    zT_110 = t;
    zT_111 = &fields;
    zF_5A40A2EE_typeRegistryGetStru(zT_109, zT_110, zT_111);
    packed_fields = zT_115;
    zT_117 = self->registry;
    zT_118 = t;
    zT_119 = &packed_fields;
    zT_122 = zF_7D87247C_typeRegistryGetPack(zT_117, zT_118, zT_119);
    has_pk = zT_122;
    zT_124 = self->store;
    zT_127 = self->store;
    zT_128 = node_idx;
    zT_132 = zF_B10B1BC1_astStoreNodeExtraCh(zT_127, zT_128, (unsigned int)(1));
    zT_125 = zT_132;
    zT_133 = zF_FCDD1D35_astStoreNodeAt(zT_124, zT_125);
    fname_node = zT_133;
    zT_134 = fname_node.kind;
    if ((unsigned char)(zT_134 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_196 = ty.state;
    if ((unsigned char)(zT_196 == (unsigned char)(2))) goto z_bb_46; else goto z_bb_47;
    z_bb_28:
    zT_139 = self->store;
    zT_142 = self->store;
    zT_143 = node_idx;
    zT_147 = zF_B10B1BC1_astStoreNodeExtraCh(zT_142, zT_143, (unsigned int)(1));
    zT_140 = zT_147;
    zT_148 = zF_8BA26B9E_astStoreNodePayload(zT_139, zT_140);
    sv_idx = zT_148;
    zT_150 = self->store;
    zT_151 = zT_150->string_values;
    zT_152 = zT_151.items;
    zT_153 = (unsigned int)sv_idx;
    zT_154 = zT_152[zT_153];
    want_id = zT_154;
    zT_156 = 0;
    zT_157 = (unsigned int)zT_156;
    fi = zT_157;
    goto z_bb_30;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    zT_159 = fields.len;
    if ((unsigned char)(fi < zT_159)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_161 = fields.ptr;
    zT_162 = zT_161[fi];
    zT_163 = zT_162.name_id;
    if ((unsigned char)(zT_163 == want_id)) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_193 = 1;
    zT_195 = fi + (unsigned int)((unsigned int)zT_193);
    fi = zT_195;
    goto z_bb_30;
    z_bb_34:
    zT_166 = fields.ptr;
    zT_167 = zT_166[fi];
    zT_168 = zT_167.offset;
    zT_169 = (zT_79FAE712_u64)zT_168;
    bo = zT_169;
    if (has_pk) goto z_bb_36; else goto z_bb_38;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    zT_171 = 0;
    pk_bo = zT_171;
    zT_173 = packed_fields.len;
    if ((unsigned char)(fi < zT_173)) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    zT_189.bits = bo;
    zT_190 = 0;
    zT_189.width_bits = zT_190;
    zT_191 = 0;
    zT_189.sig = zT_191;
    zT_192.has_value = 1;
    zT_192.value = zT_189;
    return zT_192;
    z_bb_38:
    zT_184 = node.child_0;
    zT_185 = self->bit_offset_of_id;
    if ((unsigned char)(zT_184 == zT_185)) goto z_bb_44; else goto z_bb_45;
    z_bb_39:
    zT_175 = packed_fields.ptr;
    zT_176 = zT_175[fi];
    zT_177 = zT_176.bit_offset;
    zT_178 = (zT_79FAE712_u64)zT_177;
    pk_bo = zT_178;
    goto z_bb_40;
    z_bb_40:
    zT_179 = node.child_0;
    zT_180 = self->bit_offset_of_id;
    if ((unsigned char)(zT_179 == zT_180)) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    bo = pk_bo;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_37;
    z_bb_43:
    zT_183 = pk_bo / (zT_79FAE712_u64)(8);
    bo = zT_183;
    goto z_bb_42;
    z_bb_44:
    zT_188 = bo * (zT_79FAE712_u64)(8);
    bo = zT_188;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_37;
    z_bb_46:
    zT_200 = ty.kind;
    zT_199 = zT_200 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_48;
    z_bb_47:
    zT_199 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_199) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    u_fields = zT_205;
    zT_206 = self->registry;
    zT_207 = t;
    zT_208 = &u_fields;
    zF_15BD2D98_typeRegistryGetUnio(zT_206, zT_207, zT_208);
    zT_212 = self->store;
    zT_215 = self->store;
    zT_216 = node_idx;
    zT_220 = zF_B10B1BC1_astStoreNodeExtraCh(zT_215, zT_216, (unsigned int)(1));
    zT_213 = zT_220;
    zT_221 = zF_FCDD1D35_astStoreNodeAt(zT_212, zT_213);
    fname_node2 = zT_221;
    zT_222 = fname_node2.kind;
    if ((unsigned char)(zT_222 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_26;
    z_bb_51:
    zT_227 = self->store;
    zT_230 = self->store;
    zT_231 = node_idx;
    zT_235 = zF_B10B1BC1_astStoreNodeExtraCh(zT_230, zT_231, (unsigned int)(1));
    zT_228 = zT_235;
    zT_236 = zF_8BA26B9E_astStoreNodePayload(zT_227, zT_228);
    sv_idx2 = zT_236;
    zT_238 = self->store;
    zT_239 = zT_238->string_values;
    zT_240 = zT_239.items;
    zT_241 = (unsigned int)sv_idx2;
    zT_242 = zT_240[zT_241];
    want_id2 = zT_242;
    zT_244 = 0;
    zT_245 = (unsigned int)zT_244;
    fi2 = zT_245;
    goto z_bb_53;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    zT_247 = u_fields.len;
    if ((unsigned char)(fi2 < zT_247)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_249 = u_fields.ptr;
    zT_250 = zT_249[fi2];
    zT_251 = zT_250.name_id;
    if ((unsigned char)(zT_251 == want_id2)) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_263 = 1;
    zT_265 = fi2 + (unsigned int)((unsigned int)zT_263);
    fi2 = zT_265;
    goto z_bb_53;
    z_bb_57:
    zT_254 = 0;
    ubo = zT_254;
    zT_255 = node.child_0;
    zT_256 = self->offset_of_id;
    if ((unsigned char)(zT_255 == zT_256)) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    zT_258 = 0;
    ubo = zT_258;
    goto z_bb_60;
    z_bb_60:
    zT_259.bits = ubo;
    zT_260 = 0;
    zT_259.width_bits = zT_260;
    zT_261 = 0;
    zT_259.sig = zT_261;
    zT_262.has_value = 1;
    zT_262.value = zT_259;
    return zT_262;
    z_bb_61:
    zT_271 = self->store;
    zT_272 = node_idx;
    zT_274 = zF_152E19CB_astStoreNodeExtraCh(zT_271, zT_272);
    ec3_n = zT_274;
    if ((unsigned char)(ec3_n >= (unsigned int)(1))) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_359 = node.child_0;
    zT_360 = self->int_cast_id;
    if ((unsigned char)(zT_359 == zT_360)) goto z_bb_83; else goto z_bb_82;
    z_bb_63:
    zT_278 = self;
    zT_280 = self->store;
    zT_281 = node_idx;
    zT_285 = zF_B10B1BC1_astStoreNodeExtraCh(zT_280, zT_281, (unsigned int)(0));
    zT_279 = zT_285;
    zT_286 = zF_BAD6BA5D_comptimeEvalResolve(zT_278, zT_279);
    tid2 = zT_286;
    zT_287 = tid2.has_value;
    if (zT_287) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_358.has_value = 0;
    return zT_358;
    z_bb_65:
    t2 = tid2.value;
    zT_290 = self->registry;
    zT_291 = zT_290->types_items;
    zT_292 = (unsigned int)t2;
    zT_293 = zT_291[zT_292];
    ty2 = zT_293;
    zT_294 = ty2.state;
    if ((unsigned char)(zT_294 == (unsigned char)(2))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_298 = ty2.size;
    zT_301 = (zT_79FAE712_u64)((zT_79FAE712_u64)zT_298) * (zT_79FAE712_u64)(8);
    bsz = zT_301;
    zT_302 = ty2.kind;
    if ((unsigned char)(zT_302 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    goto z_bb_66;
    z_bb_69:
    zT_307 = ty2.flags;
    zT_306 = (unsigned char)(zT_307 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_71;
    z_bb_70:
    zT_306 = 0;
    goto z_bb_71;
    z_bb_71:
    if (zT_306) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_312 = self->registry;
    zT_313 = t2;
    zT_315 = zF_CB27DBA4_typeRegistryGetPack(zT_312, zT_313);
    zT_316 = (zT_79FAE712_u64)zT_315;
    bsz = zT_316;
    goto z_bb_73;
    z_bb_73:
    zT_317 = ty2.kind;
    if ((unsigned char)(zT_317 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_321 = self->registry;
    zT_322 = t2;
    zT_324 = zF_B80C4365_typeRegistryGetPack(zT_321, zT_322);
    zT_325 = (zT_79FAE712_u64)zT_324;
    bsz = zT_325;
    goto z_bb_75;
    z_bb_75:
    zT_326 = self->registry;
    zT_327 = t2;
    zT_329 = zF_3290E9C4_typeRegistryIsInteg(zT_326, zT_327);
    if (zT_329) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_330 = self->registry;
    zT_331 = t2;
    zT_333 = zF_655972D5_typeRegistryIntWidt(zT_330, zT_331);
    zT_334 = (zT_79FAE712_u64)zT_333;
    bsz = zT_334;
    goto z_bb_77;
    z_bb_77:
    zT_335 = ty2.kind;
    if ((unsigned char)(zT_335 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_340 = self->registry;
    zT_341 = t2;
    zT_343 = zF_014D7530_typeRegistryEnumBac(zT_340, zT_341);
    ebt = zT_343;
    zT_344 = self->registry;
    zT_345 = ebt;
    zT_347 = zF_655972D5_typeRegistryIntWidt(zT_344, zT_345);
    zT_348 = (zT_79FAE712_u64)zT_347;
    bsz = zT_348;
    goto z_bb_79;
    z_bb_79:
    zT_349 = ty2.kind;
    if ((unsigned char)(zT_349 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_353 = 1;
    bsz = zT_353;
    goto z_bb_81;
    z_bb_81:
    zT_354.bits = bsz;
    zT_355 = 0;
    zT_354.width_bits = zT_355;
    zT_356 = 0;
    zT_354.sig = zT_356;
    zT_357.has_value = 1;
    zT_357.value = zT_354;
    return zT_357;
    z_bb_82:
    zT_363 = node.child_0;
    zT_364 = self->as_id;
    zT_362 = zT_363 == zT_364;
    goto z_bb_84;
    z_bb_83:
    zT_362 = 1;
    goto z_bb_84;
    z_bb_84:
    if (zT_362) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_367 = self;
    zT_369 = self->store;
    zT_370 = node_idx;
    zT_374 = zF_B10B1BC1_astStoreNodeExtraCh(zT_369, zT_370, (unsigned int)(0));
    zT_368 = zT_374;
    zT_375 = zF_BAD6BA5D_comptimeEvalResolve(zT_367, zT_368);
    tid = zT_375;
    zT_377 = self;
    zT_380 = self->store;
    zT_381 = node_idx;
    zT_385 = zF_B10B1BC1_astStoreNodeExtraCh(zT_380, zT_381, (unsigned int)(1));
    zT_378 = zT_385;
    zT_379 = depth;
    zT_386 = zF_4EE17137_comptimeEvalEvaluat(zT_377, zT_378, zT_379);
    inner = zT_386;
    zT_387 = tid.has_value;
    if (zT_387) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    zT_508 = node.child_0;
    zT_509 = self->is_windows_id;
    if ((unsigned char)(zT_508 == zT_509)) goto z_bb_118; else goto z_bb_119;
    z_bb_87:
    t = tid.value;
    zT_389 = inner.has_value;
    if (zT_389) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    zT_507.has_value = 0;
    return zT_507;
    z_bb_89:
    cv = inner.value;
    zT_391 = cv.width_bits;
    if ((unsigned char)(zT_391 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    goto z_bb_88;
    z_bb_91:
    zT_394.has_value = 0;
    return zT_394;
    z_bb_92:
    zT_396 = self->registry;
    zT_397 = zT_396->types_items;
    zT_398 = (unsigned int)t;
    zT_399 = zT_397[zT_398];
    ty = zT_399;
    zT_401 = self->registry;
    zT_402 = t;
    zT_404 = zF_3290E9C4_typeRegistryIsInteg(zT_401, zT_402);
    is_int_t = zT_404;
    zT_406 = self->registry;
    zT_407 = t;
    zT_409 = zF_655972D5_typeRegistryIntWidt(zT_406, zT_407);
    zT_410 = (unsigned int)zT_409;
    wb = zT_410;
    zT_412 = self->registry;
    zT_413 = t;
    zT_415 = zF_01ED6537_typeRegistryIntIsSi(zT_412, zT_413);
    sig = zT_415;
    zT_416 = node.child_0;
    zT_417 = self->as_id;
    if ((unsigned char)(zT_416 == zT_417)) goto z_bb_93; else goto z_bb_94;
    z_bb_93:
    zT_419 = !is_int_t;
    goto z_bb_95;
    z_bb_94:
    zT_419 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_419) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_421.has_value = 0;
    return zT_421;
    z_bb_97:
    if ((unsigned char)(!is_int_t)) goto z_bb_98; else goto z_bb_99;
    z_bb_98:
    zT_423 = ty.size;
    zT_426 = (unsigned int)(unsigned int)(zT_423 * (unsigned int)(8));
    wb = zT_426;
    zT_427 = 0;
    sig = zT_427;
    goto z_bb_99;
    z_bb_99:
    if (is_int_t) goto z_bb_100; else goto z_bb_101;
    z_bb_100:
    zT_429 = self;
    zT_430 = cv;
    zT_431 = t;
    zT_433 = self->store;
    zT_434 = node_idx;
    zT_438 = zF_B10B1BC1_astStoreNodeExtraCh(zT_433, zT_434, (unsigned int)(1));
    zT_432 = zT_438;
    zT_439 = zF_BB4D792E_comptimeValFitsType(zT_429, zT_430, zT_431, zT_432);
    zT_428 = !zT_439;
    goto z_bb_102;
    z_bb_101:
    zT_428 = 0;
    goto z_bb_102;
    z_bb_102:
    if (zT_428) goto z_bb_103; else goto z_bb_104;
    z_bb_103:
    zT_441 = self->diag;
    zT_442 = zT_441.has_value;
    if (zT_442) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    if ((unsigned char)(wb >= (unsigned int)(64))) goto z_bb_111; else goto z_bb_112;
    z_bb_105:
    dg = zT_441.value;
    zT_444 = dg;
    zT_445 = node_idx;
    zT_446 = zF_4DD9DB2D_diagnosticCollector(zT_444, zT_445);
    if (zT_446) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_473.has_value = 0;
    return zT_473;
    z_bb_107:
    zT_448 = "@intCast value does not fit the target type";
    zT_450 = 43;
    zT_449.ptr = zT_448;
    zT_449.len = zT_450;
    ic_msg = zT_449;
    zT_451 = node.child_0;
    zT_452 = self->as_id;
    if ((unsigned char)(zT_451 == zT_452)) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_454 = "@as value does not fit the target type";
    zT_456 = 38;
    zT_455.ptr = zT_454;
    zT_455.len = zT_456;
    ic_msg = zT_455;
    goto z_bb_110;
    z_bb_110:
    zT_457 = dg;
    zT_461 = node.span_start;
    zT_468 = node.span_start;
    zT_469 = node.span_len;
    zT_463 = ic_msg;
    zT_472 = zF_C82559AC_diagnosticCollector(zT_457, (unsigned char)(0), (unsigned short)(3000), (unsigned int)(0), zT_461, (unsigned int)(zT_468 + (unsigned int)((unsigned int)zT_469)), zT_463);
    (void)zT_472;
    goto z_bb_108;
    z_bb_111:
    zT_477 = cv.bits;
    zT_476.bits = zT_477;
    zT_476.width_bits = wb;
    zT_476.sig = sig;
    zT_478.has_value = 1;
    zT_478.value = zT_476;
    return zT_478;
    z_bb_112:
    zT_484 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)wb)) - (zT_79FAE712_u64)(1);
    mask = zT_484;
    zT_486 = cv.bits;
    zT_487 = zT_486 & mask;
    masked = zT_487;
    if (sig) goto z_bb_113; else goto z_bb_114;
    z_bb_113:
    zT_489 = cv.bits;
    zT_488 = (zT_79FAE712_u64)(zT_489 & (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(wb - (unsigned int)(1))))) != (zT_79FAE712_u64)(0);
    goto z_bb_115;
    z_bb_114:
    zT_488 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_488) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_502 = (zT_79FAE712_u64)((zT_79FAE712_u64)(0) - mask) - (zT_79FAE712_u64)(1);
    not_mask = zT_502;
    zT_503 = cv.bits;
    zT_504 = zT_503 | not_mask;
    masked = zT_504;
    goto z_bb_117;
    z_bb_117:
    zT_505.bits = masked;
    zT_505.width_bits = wb;
    zT_505.sig = sig;
    zT_506.has_value = 1;
    zT_506.value = zT_505;
    return zT_506;
    z_bb_118:
    zT_512 = 0;
    wb2 = zT_512;
    zT_513 = self->host_is_windows;
    if (zT_513) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    zT_519 = node.child_0;
    zT_520 = self->int_to_float_id;
    if ((unsigned char)(zT_519 == zT_520)) goto z_bb_123; else goto z_bb_122;
    z_bb_120:
    zT_514 = 1;
    wb2 = zT_514;
    goto z_bb_121;
    z_bb_121:
    zT_515.bits = wb2;
    zT_516 = 1;
    zT_515.width_bits = zT_516;
    zT_517 = 0;
    zT_515.sig = zT_517;
    zT_518.has_value = 1;
    zT_518.value = zT_515;
    return zT_518;
    z_bb_122:
    zT_523 = node.child_0;
    zT_524 = self->float_cast_id;
    zT_522 = zT_523 == zT_524;
    goto z_bb_124;
    z_bb_123:
    zT_522 = 1;
    goto z_bb_124;
    z_bb_124:
    if (zT_522) goto z_bb_125; else goto z_bb_126;
    z_bb_125:
    zT_527 = self;
    zT_528 = node_idx;
    zT_529 = depth;
    zT_530 = zF_8C4B1954_comptimeEvalFloatBu(zT_527, zT_528, zT_529);
    fv = zT_530;
    zT_531 = fv.has_value;
    if (zT_531) goto z_bb_127; else goto z_bb_128;
    z_bb_126:
    zT_543.has_value = 0;
    return zT_543;
    z_bb_127:
    v = fv.value;
    fb = v;
    zT_535 = &fb;
    zT_536 = (zT_79FAE712_u64*)zT_535;
    fbp = zT_536;
    zT_538 = *fbp;
    zT_537.bits = zT_538;
    zT_537.width_bits = zG_9D6D351A_WIDTH_FLOAT;
    zT_540 = 0;
    zT_537.sig = zT_540;
    zT_541.has_value = 1;
    zT_541.value = zT_537;
    return zT_541;
    z_bb_128:
    zT_542.has_value = 0;
    return zT_542;
}

/* comptimeEvalFloat */
zT_BCEE1C54_Opt_16 zF_B719EB81_comptimeEvalFloat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_BCEE1C54_Opt_16 zT_5 = {0};
    zT_BCEE1C54_Opt_16 zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_18;
    zT_49A8B6FA_anon_236166 zT_19;
    double* zT_20;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    unsigned int zT_25;
    double zT_26;
    zT_BCEE1C54_Opt_16 zT_27;
    zT_8143F551_AstKind zT_28;
    zT_DA663F79_ComptimeEval* zT_33;
    unsigned int zT_34;
    zT_BCEE1C54_Opt_16 zT_39 = {0};
    unsigned char zT_40;
    double zT_42;
    zT_BCEE1C54_Opt_16 zT_43;
    zT_BCEE1C54_Opt_16 zT_44 = {0};
    zT_8143F551_AstKind zT_45;
    zT_DA663F79_ComptimeEval* zT_49;
    unsigned int zT_52;
    unsigned int zT_54;
    zT_8143F551_AstKind zT_56;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned char zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_DA663F79_ComptimeEval* zT_67;
    unsigned int zT_68;
    zT_BCEE1C54_Opt_16 zT_72 = {0};
    zT_BCEE1C54_Opt_16 zT_73 = {0};
    zT_8143F551_AstKind zT_74;
    zT_6B0A7D14_AstStore* zT_79;
    unsigned int zT_80;
    unsigned int zT_82 = 0;
    int zT_84;
    unsigned int zT_85;
    zT_3D7259E2_SymbolRegistry* zT_86;
    unsigned int zT_87;
    zT_3D7259E2_SymbolRegistry* zT_91;
    unsigned int zT_93;
    zT_5F7DAFEE_Opt_863 zT_96 = {0};
    unsigned char zT_97;
    unsigned short zT_99;
    zT_6B0A7D14_AstStore* zT_105;
    unsigned int zT_106;
    zT_22A7C88B_AstNode zT_109 = {0};
    unsigned int zT_110;
    zT_DA663F79_ComptimeEval* zT_114;
    unsigned int zT_115;
    zT_BCEE1C54_Opt_16 zT_120 = {0};
    unsigned char zT_121;
    zT_DA663F79_ComptimeEval* zT_124;
    unsigned int zT_125;
    zT_BAEE192E_Opt_10 zT_127 = {0};
    unsigned char zT_128;
    float zT_133;
    double zT_134;
    zT_BCEE1C54_Opt_16 zT_135;
    zT_BCEE1C54_Opt_16 zT_136;
    zT_BCEE1C54_Opt_16 zT_137 = {0};
    int zT_138;
    unsigned int zT_140;
    zT_BCEE1C54_Opt_16 zT_141 = {0};
    zT_BCEE1C54_Opt_16 zT_142 = {0};
    zT_22A7C88B_AstNode node;
    zT_BCEE1C54_Opt_16 inner;
    double fv;
    unsigned int name_id;
    unsigned int mi;
    zT_5F7DAFEE_Opt_863 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_BAEE192E_Opt_10 dt;
    unsigned int t;
    float f32v;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_18 = self->store;
    zT_19 = zT_18->float_values;
    zT_20 = zT_19.items;
    zT_21 = self->store;
    zT_22 = node_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_20[zT_25];
    zT_27.has_value = 1;
    zT_27.value = zT_26;
    return zT_27;
    z_bb_6:
    { zT_BCEE1C54_Opt_16 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_7:
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_33 = self;
    zT_34 = node.child_0;
    zT_39 = zF_B719EB81_comptimeEvalFloat(zT_33, zT_34, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_39;
    zT_40 = inner.has_value;
    if (zT_40) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_45 = node.kind;
    if ((unsigned char)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    fv = inner.value;
    zT_42 = -fv;
    zT_43.has_value = 1;
    zT_43.value = zT_42;
    return zT_43;
    z_bb_12:
    zT_44.has_value = 0;
    return zT_44;
    z_bb_13:
    zT_49 = self;
    zT_52 = node.child_0;
    zT_54 = depth + (unsigned int)(1);
    self = zT_49;
    node_idx = zT_52;
    depth = zT_54;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_56 = node.kind;
    if ((unsigned char)(zT_56 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_60 = node.child_0;
    zT_61 = self->int_to_float_id;
    if ((unsigned char)(zT_60 == zT_61)) goto z_bb_20; else goto z_bb_19;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_74 = node.kind;
    if ((unsigned char)(zT_74 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_24; else goto z_bb_26;
    z_bb_19:
    zT_64 = node.child_0;
    zT_65 = self->float_cast_id;
    zT_63 = zT_64 == zT_65;
    goto z_bb_21;
    z_bb_20:
    zT_63 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_63) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_67 = self;
    zT_68 = node_idx;
    zT_72 = zF_8C4B1954_comptimeEvalFloatBu(zT_67, zT_68, (unsigned int)(depth + (unsigned int)(1)));
    return zT_72;
    z_bb_23:
    zT_73.has_value = 0;
    return zT_73;
    z_bb_24:
    zT_79 = self->store;
    zT_80 = node_idx;
    zT_82 = zF_53458827_astStoreIdentifier(zT_79, zT_80);
    name_id = zT_82;
    zT_84 = 0;
    zT_85 = (unsigned int)zT_84;
    mi = zT_85;
    goto z_bb_27;
    goto z_bb_17;
    z_bb_26:
    zT_142.has_value = 0;
    return zT_142;
    z_bb_27:
    zT_86 = self->symbol_reg;
    zT_87 = zT_86->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_87))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_91 = self->symbol_reg;
    zT_93 = name_id;
    zT_96 = zF_A398987E_symbolRegistryQuali(zT_91, (unsigned int)((unsigned int)mi), zT_93);
    c_sym = zT_96;
    zT_97 = c_sym.has_value;
    if (zT_97) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    zT_141.has_value = 0;
    return zT_141;
    z_bb_30:
    zT_138 = 1;
    zT_140 = mi + (unsigned int)((unsigned int)zT_138);
    mi = zT_140;
    goto z_bb_27;
    z_bb_31:
    cs = c_sym.value;
    zT_99 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_99 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_105 = self->store;
    zT_106 = cs->decl_node;
    zT_109 = zF_FCDD1D35_astStoreNodeAt(zT_105, zT_106);
    c_decl = zT_109;
    zT_110 = c_decl.child_1;
    if ((unsigned char)(zT_110 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_114 = self;
    zT_115 = c_decl.child_1;
    zT_120 = zF_B719EB81_comptimeEvalFloat(zT_114, zT_115, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_120;
    zT_121 = inner.has_value;
    if (zT_121) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    fv = inner.value;
    zT_124 = self;
    zT_125 = c_decl.child_0;
    zT_127 = zF_BAD6BA5D_comptimeEvalResolve(zT_124, zT_125);
    dt = zT_127;
    zT_128 = dt.has_value;
    if (zT_128) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_137.has_value = 0;
    return zT_137;
    z_bb_39:
    t = dt.value;
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    zT_136.has_value = 1;
    zT_136.value = fv;
    return zT_136;
    z_bb_41:
    zT_133 = (float)fv;
    f32v = zT_133;
    zT_134 = (double)f32v;
    zT_135.has_value = 1;
    zT_135.value = zT_134;
    return zT_135;
    z_bb_42:
    goto z_bb_40;
}

/* comptimeEvalOperandSigned */
unsigned char zF_0D60B956_comptimeEvalOperand(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_89B1DDDA_ComptimeVal cv) {
    int zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_21;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    zT_22A7C88B_AstNode zT_26 = {0};
    zT_8143F551_AstKind zT_27;
    zT_6B0A7D14_AstStore* zT_32;
    unsigned int zT_33;
    unsigned int zT_35 = 0;
    int zT_37;
    unsigned int zT_38;
    zT_3D7259E2_SymbolRegistry* zT_39;
    unsigned int zT_40;
    zT_3D7259E2_SymbolRegistry* zT_44;
    unsigned int zT_46;
    zT_5F7DAFEE_Opt_863 zT_49 = {0};
    unsigned char zT_50;
    unsigned short zT_52;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    zT_22A7C88B_AstNode zT_62 = {0};
    zT_DA663F79_ComptimeEval* zT_64;
    unsigned int zT_65;
    zT_BAEE192E_Opt_10 zT_67 = {0};
    unsigned char zT_68;
    zT_338B7C76_TypeRegistry* zT_70;
    unsigned int zT_71;
    unsigned char zT_73 = 0;
    zT_338B7C76_TypeRegistry* zT_74;
    unsigned int zT_75;
    unsigned char zT_77 = 0;
    int zT_78;
    unsigned int zT_80;
    zT_8143F551_AstKind zT_81;
    zT_79FAE712_u64 zT_85;
    zT_8143F551_AstKind zT_88;
    zT_8143F551_AstKind zT_93;
    unsigned int zT_97;
    unsigned int zT_98;
    unsigned char zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_DA663F79_ComptimeEval* zT_105;
    unsigned int zT_106;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    unsigned int zT_112 = 0;
    zT_BAEE192E_Opt_10 zT_113 = {0};
    unsigned char zT_114;
    zT_338B7C76_TypeRegistry* zT_116;
    unsigned int zT_117;
    unsigned char zT_119 = 0;
    zT_338B7C76_TypeRegistry* zT_120;
    unsigned int zT_121;
    unsigned char zT_123 = 0;
    unsigned char zT_124;
    unsigned int idx;
    unsigned int guard;
    zT_22A7C88B_AstNode wn;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int mi;
    zT_5F7DAFEE_Opt_863 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_BAEE192E_Opt_10 dt;
    unsigned int t;
    zT_BAEE192E_Opt_10 dt2;
    unsigned int t2;
    idx = node_idx;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    guard = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(guard < (unsigned int)(32))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->store;
    zT_11 = idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    wn = zT_13;
    zT_14 = wn.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_23 = self->store;
    zT_24 = idx;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_23, zT_24);
    node = zT_26;
    zT_27 = node.kind;
    if ((unsigned char)(zT_27 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_10;
    z_bb_4:
    zT_19 = 1;
    zT_21 = guard + (unsigned int)((unsigned int)zT_19);
    guard = zT_21;
    goto z_bb_1;
    z_bb_5:
    zT_18 = wn.child_0;
    idx = zT_18;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    goto z_bb_3;
    z_bb_8:
    zT_32 = self->store;
    zT_33 = idx;
    zT_35 = zF_53458827_astStoreIdentifier(zT_32, zT_33);
    name_id = zT_35;
    zT_37 = 0;
    zT_38 = (unsigned int)zT_37;
    mi = zT_38;
    goto z_bb_11;
    z_bb_9:
    zT_124 = cv.sig;
    return zT_124;
    z_bb_10:
    zT_81 = node.kind;
    if ((unsigned char)(zT_81 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_23; else goto z_bb_25;
    z_bb_11:
    zT_39 = self->symbol_reg;
    zT_40 = zT_39->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_40))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_44 = self->symbol_reg;
    zT_46 = name_id;
    zT_49 = zF_A398987E_symbolRegistryQuali(zT_44, (unsigned int)((unsigned int)mi), zT_46);
    c_sym = zT_49;
    zT_50 = c_sym.has_value;
    if (zT_50) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_9;
    z_bb_14:
    zT_78 = 1;
    zT_80 = mi + (unsigned int)((unsigned int)zT_78);
    mi = zT_80;
    goto z_bb_11;
    z_bb_15:
    cs = c_sym.value;
    zT_52 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_52 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_58 = self->store;
    zT_59 = cs->decl_node;
    zT_62 = zF_FCDD1D35_astStoreNodeAt(zT_58, zT_59);
    c_decl = zT_62;
    zT_64 = self;
    zT_65 = c_decl.child_0;
    zT_67 = zF_BAD6BA5D_comptimeEvalResolve(zT_64, zT_65);
    dt = zT_67;
    zT_68 = dt.has_value;
    if (zT_68) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    t = dt.value;
    zT_70 = self->registry;
    zT_71 = t;
    zT_73 = zF_3290E9C4_typeRegistryIsInteg(zT_70, zT_71);
    if (zT_73) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_74 = self->registry;
    zT_75 = t;
    zT_77 = zF_01ED6537_typeRegistryIntIsSi(zT_74, zT_75);
    return zT_77;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_85 = cv.bits;
    return (unsigned char)(zT_85 <= (zT_79FAE712_u64)(9223372036854775807ULL));
    z_bb_24:
    goto z_bb_9;
    z_bb_25:
    zT_88 = node.kind;
    if ((unsigned char)(zT_88 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    return (unsigned char)(0);
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_93 = node.kind;
    if ((unsigned char)(zT_93 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_97 = node.child_0;
    zT_98 = self->int_cast_id;
    if ((unsigned char)(zT_97 == zT_98)) goto z_bb_32; else goto z_bb_31;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_101 = node.child_0;
    zT_102 = self->as_id;
    zT_100 = zT_101 == zT_102;
    goto z_bb_33;
    z_bb_32:
    zT_100 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_100) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_105 = self;
    zT_107 = self->store;
    zT_108 = idx;
    zT_112 = zF_B10B1BC1_astStoreNodeExtraCh(zT_107, zT_108, (unsigned int)(0));
    zT_106 = zT_112;
    zT_113 = zF_BAD6BA5D_comptimeEvalResolve(zT_105, zT_106);
    dt2 = zT_113;
    zT_114 = dt2.has_value;
    if (zT_114) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    t2 = dt2.value;
    zT_116 = self->registry;
    zT_117 = t2;
    zT_119 = zF_3290E9C4_typeRegistryIsInteg(zT_116, zT_117);
    if (zT_119) goto z_bb_38; else goto z_bb_39;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    zT_120 = self->registry;
    zT_121 = t2;
    zT_123 = zF_01ED6537_typeRegistryIntIsSi(zT_120, zT_121);
    return zT_123;
    z_bb_39:
    goto z_bb_37;
}

/* comptimeEvalFloatBuiltin */
zT_BCEE1C54_Opt_16 zF_8C4B1954_comptimeEvalFloatBu(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_DA663F79_ComptimeEval* zT_9;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    unsigned int zT_16 = 0;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    unsigned char zT_18;
    unsigned char zT_22;
    zT_BCEE1C54_Opt_16 zT_25 = {0};
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_32 = 0;
    double zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_DA663F79_ComptimeEval* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    zT_E53A25A2_Opt_203 zT_42 = {0};
    unsigned char zT_43;
    unsigned int zT_45;
    zT_BCEE1C54_Opt_16 zT_48 = {0};
    zT_DA663F79_ComptimeEval* zT_49;
    unsigned int zT_50;
    zT_89B1DDDA_ComptimeVal zT_51;
    unsigned char zT_52 = 0;
    zT_79FAE712_u64 zT_54;
    zT_C69B2266_i64 zT_55;
    double zT_56;
    zT_79FAE712_u64 zT_57;
    double zT_58;
    zT_BCEE1C54_Opt_16 zT_59 = {0};
    unsigned int zT_60;
    unsigned int zT_61;
    zT_DA663F79_ComptimeEval* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_BCEE1C54_Opt_16 zT_67 = {0};
    unsigned char zT_68;
    zT_BCEE1C54_Opt_16 zT_70 = {0};
    zT_BCEE1C54_Opt_16 zT_71 = {0};
    float zT_75;
    double zT_76;
    zT_BCEE1C54_Opt_16 zT_77;
    zT_BCEE1C54_Opt_16 zT_78;
    zT_BCEE1C54_Opt_16 zT_79 = {0};
    zT_22A7C88B_AstNode node;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    unsigned int inner_idx;
    double fv;
    zT_E53A25A2_Opt_203 iv;
    zT_89B1DDDA_ComptimeVal cv;
    zT_C69B2266_i64 sv;
    zT_BCEE1C54_Opt_16 xv;
    double x;
    float f32v;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_16 = zF_B10B1BC1_astStoreNodeExtraCh(zT_11, zT_12, (unsigned int)(0));
    zT_10 = zT_16;
    zT_17 = zF_BAD6BA5D_comptimeEvalResolve(zT_9, zT_10);
    tid = zT_17;
    zT_18 = tid.has_value;
    if (zT_18) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    t = tid.value;
    if ((unsigned char)(t != (unsigned int)(15))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_79.has_value = 0;
    return zT_79;
    z_bb_3:
    zT_22 = t != (unsigned int)(16);
    goto z_bb_5;
    z_bb_4:
    zT_22 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_22) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_7:
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_32 = zF_B10B1BC1_astStoreNodeExtraCh(zT_27, zT_28, (unsigned int)(1));
    inner_idx = zT_32;
    zT_34 = 0;
    fv = zT_34;
    zT_35 = node.child_0;
    zT_36 = self->int_to_float_id;
    if ((unsigned char)(zT_35 == zT_36)) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_39 = self;
    zT_40 = inner_idx;
    zT_41 = depth;
    zT_42 = zF_4EE17137_comptimeEvalEvaluat(zT_39, zT_40, zT_41);
    iv = zT_42;
    zT_43 = iv.has_value;
    if (zT_43) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_25; else goto z_bb_26;
    z_bb_10:
    zT_60 = node.child_0;
    zT_61 = self->float_cast_id;
    if ((unsigned char)(zT_60 == zT_61)) goto z_bb_19; else goto z_bb_21;
    z_bb_11:
    cv = iv.value;
    zT_45 = cv.width_bits;
    if ((unsigned char)(zT_45 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_59.has_value = 0;
    return zT_59;
    z_bb_14:
    zT_48.has_value = 0;
    return zT_48;
    z_bb_15:
    zT_49 = self;
    zT_50 = inner_idx;
    zT_51 = cv;
    zT_52 = zF_0D60B956_comptimeEvalOperand(zT_49, zT_50, zT_51);
    if (zT_52) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_54 = cv.bits;
    zT_55 = (zT_C69B2266_i64)zT_54;
    sv = zT_55;
    zT_56 = (double)sv;
    fv = zT_56;
    goto z_bb_17;
    z_bb_17:
    goto z_bb_12;
    z_bb_18:
    zT_57 = cv.bits;
    zT_58 = (double)zT_57;
    fv = zT_58;
    goto z_bb_17;
    z_bb_19:
    zT_64 = self;
    zT_65 = inner_idx;
    zT_66 = depth;
    zT_67 = zF_B719EB81_comptimeEvalFloat(zT_64, zT_65, zT_66);
    xv = zT_67;
    zT_68 = xv.has_value;
    if (zT_68) goto z_bb_22; else goto z_bb_24;
    z_bb_20:
    goto z_bb_9;
    z_bb_21:
    zT_71.has_value = 0;
    return zT_71;
    z_bb_22:
    x = xv.value;
    fv = x;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_70.has_value = 0;
    return zT_70;
    z_bb_25:
    zT_75 = (float)fv;
    f32v = zT_75;
    zT_76 = (double)f32v;
    zT_77.has_value = 1;
    zT_77.value = zT_76;
    return zT_77;
    z_bb_26:
    zT_78.has_value = 1;
    zT_78.value = fv;
    return zT_78;
}

/* comptimeEvalEvaluate */
zT_E53A25A2_Opt_203 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    zT_E53A25A2_Opt_203 zT_6 = {0};
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_4EE17137_comptimeEvalEvaluat(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* comptimeEvalEvaluateDepth */
zT_E53A25A2_Opt_203 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_E53A25A2_Opt_203 zT_5 = {0};
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_89B1DDDA_ComptimeVal zT_15;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_79FAE712_u64 zT_19 = 0;
    unsigned int zT_20;
    unsigned char zT_21;
    zT_E53A25A2_Opt_203 zT_22;
    zT_8143F551_AstKind zT_23;
    zT_89B1DDDA_ComptimeVal zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    zT_79FAE712_u64 zT_31 = 0;
    unsigned int zT_32;
    unsigned char zT_33;
    zT_E53A25A2_Opt_203 zT_34;
    zT_8143F551_AstKind zT_35;
    unsigned char zT_39;
    zT_89B1DDDA_ComptimeVal zT_44;
    zT_79FAE712_u64 zT_45;
    unsigned int zT_46;
    unsigned char zT_47;
    zT_E53A25A2_Opt_203 zT_48;
    zT_89B1DDDA_ComptimeVal zT_49;
    zT_79FAE712_u64 zT_50;
    unsigned int zT_51;
    unsigned char zT_52;
    zT_E53A25A2_Opt_203 zT_53;
    zT_8143F551_AstKind zT_54;
    zT_DA663F79_ComptimeEval* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    zT_E53A25A2_Opt_203 zT_63 = {0};
    unsigned char zT_64;
    unsigned int zT_66;
    zT_E53A25A2_Opt_203 zT_69 = {0};
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    unsigned int zT_74;
    unsigned int zT_78;
    zT_89B1DDDA_ComptimeVal zT_81;
    unsigned char zT_82;
    zT_E53A25A2_Opt_203 zT_83;
    zT_79FAE712_u64 zT_89;
    zT_79FAE712_u64 zT_91;
    unsigned char zT_92;
    unsigned char zT_93;
    zT_79FAE712_u64 zT_106;
    zT_79FAE712_u64 zT_107;
    zT_89B1DDDA_ComptimeVal zT_108;
    unsigned char zT_109;
    zT_E53A25A2_Opt_203 zT_110;
    zT_89B1DDDA_ComptimeVal zT_111;
    unsigned int zT_112;
    unsigned char zT_113;
    zT_E53A25A2_Opt_203 zT_114;
    zT_E53A25A2_Opt_203 zT_115 = {0};
    zT_8143F551_AstKind zT_116;
    zT_DA663F79_ComptimeEval* zT_121;
    unsigned int zT_122;
    unsigned int zT_123;
    zT_E53A25A2_Opt_203 zT_125 = {0};
    unsigned char zT_126;
    unsigned int zT_128;
    zT_E53A25A2_Opt_203 zT_131 = {0};
    zT_79FAE712_u64 zT_133;
    zT_79FAE712_u64 zT_134;
    zT_89B1DDDA_ComptimeVal zT_135;
    unsigned int zT_136;
    unsigned char zT_137;
    zT_E53A25A2_Opt_203 zT_138;
    zT_E53A25A2_Opt_203 zT_139 = {0};
    zT_8143F551_AstKind zT_140;
    unsigned char zT_144;
    zT_8143F551_AstKind zT_145;
    unsigned char zT_149;
    zT_8143F551_AstKind zT_150;
    unsigned char zT_154;
    zT_8143F551_AstKind zT_155;
    unsigned char zT_159;
    zT_8143F551_AstKind zT_160;
    unsigned char zT_164;
    zT_8143F551_AstKind zT_165;
    unsigned char zT_169;
    zT_8143F551_AstKind zT_170;
    unsigned char zT_174;
    zT_8143F551_AstKind zT_175;
    unsigned char zT_179;
    zT_8143F551_AstKind zT_180;
    unsigned char zT_184;
    zT_8143F551_AstKind zT_185;
    zT_DA663F79_ComptimeEval* zT_189;
    unsigned int zT_190;
    zT_8143F551_AstKind zT_191;
    unsigned int zT_192;
    zT_E53A25A2_Opt_203 zT_194 = {0};
    zT_8143F551_AstKind zT_195;
    zT_DA663F79_ComptimeEval* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_E53A25A2_Opt_203 zT_202 = {0};
    zT_8143F551_AstKind zT_203;
    zT_DA663F79_ComptimeEval* zT_207;
    unsigned int zT_209;
    unsigned int zT_210;
    zT_8143F551_AstKind zT_212;
    zT_E53A25A2_Opt_203 zT_218 = {0};
    zT_6B0A7D14_AstStore* zT_220;
    unsigned int zT_221;
    unsigned int zT_223 = 0;
    int zT_225;
    unsigned int zT_226;
    zT_3D7259E2_SymbolRegistry* zT_227;
    unsigned int zT_228;
    zT_3D7259E2_SymbolRegistry* zT_232;
    unsigned int zT_234;
    zT_5F7DAFEE_Opt_863 zT_237 = {0};
    unsigned char zT_238;
    unsigned short zT_240;
    zT_6B0A7D14_AstStore* zT_246;
    unsigned int zT_247;
    zT_22A7C88B_AstNode zT_250 = {0};
    unsigned int zT_251;
    zT_DA663F79_ComptimeEval* zT_254;
    unsigned int zT_257;
    unsigned int zT_259;
    int zT_261;
    unsigned int zT_263;
    zT_E53A25A2_Opt_203 zT_264 = {0};
    zT_E53A25A2_Opt_203 zT_265 = {0};
    zT_22A7C88B_AstNode node;
    zT_E53A25A2_Opt_203 inner;
    zT_89B1DDDA_ComptimeVal cv;
    zT_79FAE712_u64 nv;
    unsigned int wb;
    zT_79FAE712_u64 mask;
    zT_79FAE712_u64 masked;
    zT_79FAE712_u64 not_mask;
    zT_E53A25A2_Opt_203 bnv;
    zT_89B1DDDA_ComptimeVal bv;
    zT_79FAE712_u64 bnb;
    unsigned int name_id;
    unsigned int mi;
    zT_5F7DAFEE_Opt_863 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((unsigned char)(zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_16 = self->store;
    zT_17 = node_idx;
    zT_19 = zF_678B9A72_astStoreIntValue(zT_16, zT_17);
    zT_15.bits = zT_19;
    zT_20 = 0;
    zT_15.width_bits = zT_20;
    zT_21 = 1;
    zT_15.sig = zT_21;
    zT_22.has_value = 1;
    zT_22.value = zT_15;
    return zT_22;
    z_bb_4:
    { zT_E53A25A2_Opt_203 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_5:
    zT_23 = node.kind;
    if ((unsigned char)(zT_23 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_28 = self->store;
    zT_29 = node_idx;
    zT_31 = zF_678B9A72_astStoreIntValue(zT_28, zT_29);
    zT_27.bits = zT_31;
    zT_32 = 8;
    zT_27.width_bits = zT_32;
    zT_33 = 0;
    zT_27.sig = zT_33;
    zT_34.has_value = 1;
    zT_34.value = zT_27;
    return zT_34;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_35 = node.kind;
    if ((unsigned char)(zT_35 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_39 = node.flags;
    if ((unsigned char)((unsigned char)(zT_39 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_54 = node.kind;
    if ((unsigned char)(zT_54 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_14; else goto z_bb_16;
    z_bb_12:
    zT_45 = 1;
    zT_44.bits = zT_45;
    zT_46 = 1;
    zT_44.width_bits = zT_46;
    zT_47 = 0;
    zT_44.sig = zT_47;
    zT_48.has_value = 1;
    zT_48.value = zT_44;
    return zT_48;
    z_bb_13:
    zT_50 = 0;
    zT_49.bits = zT_50;
    zT_51 = 1;
    zT_49.width_bits = zT_51;
    zT_52 = 0;
    zT_49.sig = zT_52;
    zT_53.has_value = 1;
    zT_53.value = zT_49;
    return zT_53;
    z_bb_14:
    zT_59 = self;
    zT_60 = node.child_0;
    zT_61 = depth;
    zT_63 = zF_4EE17137_comptimeEvalEvaluat(zT_59, zT_60, zT_61);
    inner = zT_63;
    zT_64 = inner.has_value;
    if (zT_64) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_116 = node.kind;
    if ((unsigned char)(zT_116 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_30; else goto z_bb_32;
    z_bb_17:
    cv = inner.value;
    zT_66 = cv.width_bits;
    if ((unsigned char)(zT_66 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_115.has_value = 0;
    return zT_115;
    z_bb_19:
    zT_69.has_value = 0;
    return zT_69;
    z_bb_20:
    zT_72 = cv.bits;
    zT_73 = (zT_79FAE712_u64)(0) - zT_72;
    nv = zT_73;
    zT_74 = cv.width_bits;
    if ((unsigned char)(zT_74 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_78 = cv.width_bits;
    wb = zT_78;
    if ((unsigned char)(wb >= (unsigned int)(64))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_111.bits = nv;
    zT_112 = 0;
    zT_111.width_bits = zT_112;
    zT_113 = 1;
    zT_111.sig = zT_113;
    zT_114.has_value = 1;
    zT_114.value = zT_111;
    return zT_114;
    z_bb_23:
    zT_81.bits = nv;
    zT_81.width_bits = wb;
    zT_82 = cv.sig;
    zT_81.sig = zT_82;
    zT_83.has_value = 1;
    zT_83.value = zT_81;
    return zT_83;
    z_bb_24:
    zT_89 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)wb)) - (zT_79FAE712_u64)(1);
    mask = zT_89;
    zT_91 = nv & mask;
    masked = zT_91;
    zT_92 = cv.sig;
    if (zT_92) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_93 = (zT_79FAE712_u64)(nv & (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(wb - (unsigned int)(1))))) != (zT_79FAE712_u64)(0);
    goto z_bb_27;
    z_bb_26:
    zT_93 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_93) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_106 = (zT_79FAE712_u64)((zT_79FAE712_u64)(0) - mask) - (zT_79FAE712_u64)(1);
    not_mask = zT_106;
    zT_107 = nv | not_mask;
    masked = zT_107;
    goto z_bb_29;
    z_bb_29:
    zT_108.bits = masked;
    zT_108.width_bits = wb;
    zT_109 = cv.sig;
    zT_108.sig = zT_109;
    zT_110.has_value = 1;
    zT_110.value = zT_108;
    return zT_110;
    z_bb_30:
    zT_121 = self;
    zT_122 = node.child_0;
    zT_123 = depth;
    zT_125 = zF_4EE17137_comptimeEvalEvaluat(zT_121, zT_122, zT_123);
    bnv = zT_125;
    zT_126 = bnv.has_value;
    if (zT_126) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_15;
    z_bb_32:
    zT_140 = node.kind;
    if ((unsigned char)(zT_140 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_38; else goto z_bb_37;
    z_bb_33:
    bv = bnv.value;
    zT_128 = bv.width_bits;
    if ((unsigned char)(zT_128 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_139.has_value = 0;
    return zT_139;
    z_bb_35:
    zT_131.has_value = 0;
    return zT_131;
    z_bb_36:
    zT_133 = bv.bits;
    zT_134 = ~zT_133;
    bnb = zT_134;
    zT_135.bits = bnb;
    zT_136 = bv.width_bits;
    zT_135.width_bits = zT_136;
    zT_137 = 0;
    zT_135.sig = zT_137;
    zT_138.has_value = 1;
    zT_138.value = zT_135;
    return zT_138;
    z_bb_37:
    zT_145 = node.kind;
    zT_144 = zT_145 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_39;
    z_bb_38:
    zT_144 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_144) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_150 = node.kind;
    zT_149 = zT_150 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_42;
    z_bb_41:
    zT_149 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_149) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_155 = node.kind;
    zT_154 = zT_155 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_45;
    z_bb_44:
    zT_154 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_154) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_160 = node.kind;
    zT_159 = zT_160 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_48;
    z_bb_47:
    zT_159 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_159) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_165 = node.kind;
    zT_164 = zT_165 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_51;
    z_bb_50:
    zT_164 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_164) goto z_bb_53; else goto z_bb_52;
    z_bb_52:
    zT_170 = node.kind;
    zT_169 = zT_170 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_54;
    z_bb_53:
    zT_169 = 1;
    goto z_bb_54;
    z_bb_54:
    if (zT_169) goto z_bb_56; else goto z_bb_55;
    z_bb_55:
    zT_175 = node.kind;
    zT_174 = zT_175 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_57;
    z_bb_56:
    zT_174 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_174) goto z_bb_59; else goto z_bb_58;
    z_bb_58:
    zT_180 = node.kind;
    zT_179 = zT_180 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_60;
    z_bb_59:
    zT_179 = 1;
    goto z_bb_60;
    z_bb_60:
    if (zT_179) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_185 = node.kind;
    zT_184 = zT_185 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_63;
    z_bb_62:
    zT_184 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_184) goto z_bb_64; else goto z_bb_66;
    z_bb_64:
    zT_189 = self;
    zT_190 = node_idx;
    zT_191 = node.kind;
    zT_192 = depth;
    zT_194 = zF_B36A4A25_comptimeEvalBinOp(zT_189, zT_190, zT_191, zT_192);
    return zT_194;
    z_bb_65:
    goto z_bb_31;
    z_bb_66:
    zT_195 = node.kind;
    if ((unsigned char)(zT_195 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_67; else goto z_bb_69;
    z_bb_67:
    zT_199 = self;
    zT_200 = node_idx;
    zT_201 = depth;
    zT_202 = zF_C37A1F7C_comptimeEvalBuiltin(zT_199, zT_200, zT_201);
    return zT_202;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_203 = node.kind;
    if ((unsigned char)(zT_203 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_70; else goto z_bb_72;
    z_bb_70:
    zT_207 = self;
    zT_210 = node.child_0;
    zT_209 = depth;
    self = zT_207;
    node_idx = zT_210;
    depth = zT_209;
    goto z_bb_0;
    z_bb_71:
    goto z_bb_68;
    z_bb_72:
    zT_212 = node.kind;
    if ((unsigned char)(zT_212 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_76; else goto z_bb_77;
    goto z_bb_71;
    z_bb_75:
    zT_265.has_value = 0;
    return zT_265;
    z_bb_76:
    zT_218.has_value = 0;
    return zT_218;
    z_bb_77:
    zT_220 = self->store;
    zT_221 = node_idx;
    zT_223 = zF_53458827_astStoreIdentifier(zT_220, zT_221);
    name_id = zT_223;
    zT_225 = 0;
    zT_226 = (unsigned int)zT_225;
    mi = zT_226;
    goto z_bb_78;
    z_bb_78:
    zT_227 = self->symbol_reg;
    zT_228 = zT_227->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_228))) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_232 = self->symbol_reg;
    zT_234 = name_id;
    zT_237 = zF_A398987E_symbolRegistryQuali(zT_232, (unsigned int)((unsigned int)mi), zT_234);
    c_sym = zT_237;
    zT_238 = c_sym.has_value;
    if (zT_238) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    zT_264.has_value = 0;
    return zT_264;
    z_bb_81:
    zT_261 = 1;
    zT_263 = mi + (unsigned int)((unsigned int)zT_261);
    mi = zT_263;
    goto z_bb_78;
    z_bb_82:
    cs = c_sym.value;
    zT_240 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_240 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    zT_246 = self->store;
    zT_247 = cs->decl_node;
    zT_250 = zF_FCDD1D35_astStoreNodeAt(zT_246, zT_247);
    c_decl = zT_250;
    zT_251 = c_decl.child_1;
    if ((unsigned char)(zT_251 != (unsigned int)(0))) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    goto z_bb_83;
    z_bb_86:
    zT_254 = self;
    zT_257 = c_decl.child_1;
    zT_259 = depth + (unsigned int)(1);
    self = zT_254;
    node_idx = zT_257;
    depth = zT_259;
    goto z_bb_0;
    z_bb_87:
    goto z_bb_85;
}

/* __module_init */
void zF_780653D2___module_init_18(void) {
    zG_9D6D351A_WIDTH_FLOAT = (unsigned int)(4294967295u);
    return;
}

/* EOF */
