#include "comptime_eval_02C4526F.h"
unsigned int zG_9D6D351A_WIDTH_FLOAT;
/* comptimeEvalInit */
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry* registry, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_3D7259E2_SymbolRegistry* symbol_reg) {
    unsigned char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_D3EB6303_StringInterner* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_D3EB6303_StringInterner* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27 = 0;
    unsigned char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    zT_D3EB6303_StringInterner* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35 = 0;
    zT_D3EB6303_StringInterner* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39 = 0;
    zT_D3EB6303_StringInterner* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43 = 0;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    unsigned char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    zT_D3EB6303_StringInterner* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59 = 0;
    zT_D3EB6303_StringInterner* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63 = 0;
    zT_D3EB6303_StringInterner* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67 = 0;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_D3EB6303_StringInterner* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75 = 0;
    zT_DA663F79_ComptimeEval zT_76;
    unsigned char zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_fc;
    unsigned int fc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_itf;
    unsigned int itf_id;
    unsigned int size_id;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int off_id;
    unsigned int bitsz_id;
    unsigned int bitoff_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_iw;
    unsigned int iw_id;
    zT_5 = "@sizeOf";
    zT_7 = 7;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_size = zT_6;
    zT_9 = "@alignOf";
    zT_11 = 8;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_align = zT_10;
    zT_13 = "@intCast";
    zT_15 = 8;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    s_intc = zT_14;
    zT_17 = interner;
    zT_18 = s_intc;
    zT_19 = zF_50C274AF_stringInternerInter(zT_17, zT_18);
    intc_id = zT_19;
    zT_21 = "@floatCast";
    zT_23 = 10;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    s_fc = zT_22;
    zT_25 = interner;
    zT_26 = s_fc;
    zT_27 = zF_50C274AF_stringInternerInter(zT_25, zT_26);
    fc_id = zT_27;
    zT_29 = "@intToFloat";
    zT_31 = 11;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    s_itf = zT_30;
    zT_33 = interner;
    zT_34 = s_itf;
    zT_35 = zF_50C274AF_stringInternerInter(zT_33, zT_34);
    itf_id = zT_35;
    zT_37 = interner;
    zT_38 = s_size;
    zT_39 = zF_50C274AF_stringInternerInter(zT_37, zT_38);
    size_id = zT_39;
    zT_41 = interner;
    zT_42 = s_align;
    zT_43 = zF_50C274AF_stringInternerInter(zT_41, zT_42);
    align_id = zT_43;
    zT_45 = "@offsetOf";
    zT_47 = 9;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    s_off = zT_46;
    zT_49 = "@bitSizeOf";
    zT_51 = 10;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    s_bitsz = zT_50;
    zT_53 = "@bitOffsetOf";
    zT_55 = 12;
    zT_54.ptr = zT_53;
    zT_54.len = zT_55;
    s_bitoff = zT_54;
    zT_57 = interner;
    zT_58 = s_off;
    zT_59 = zF_50C274AF_stringInternerInter(zT_57, zT_58);
    off_id = zT_59;
    zT_61 = interner;
    zT_62 = s_bitsz;
    zT_63 = zF_50C274AF_stringInternerInter(zT_61, zT_62);
    bitsz_id = zT_63;
    zT_65 = interner;
    zT_66 = s_bitoff;
    zT_67 = zF_50C274AF_stringInternerInter(zT_65, zT_66);
    bitoff_id = zT_67;
    zT_69 = "@isWindows";
    zT_71 = 10;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    s_iw = zT_70;
    zT_73 = interner;
    zT_74 = s_iw;
    zT_75 = zF_50C274AF_stringInternerInter(zT_73, zT_74);
    iw_id = zT_75;
    zT_76.registry = registry;
    zT_76.store = store;
    zT_76.interner = interner;
    zT_76.symbol_reg = symbol_reg;
    zT_76.size_of_id = size_id;
    zT_76.align_of_id = align_id;
    zT_76.int_cast_id = intc_id;
    zT_76.float_cast_id = fc_id;
    zT_76.int_to_float_id = itf_id;
    zT_76.offset_of_id = off_id;
    zT_76.bit_size_of_id = bitsz_id;
    zT_76.bit_offset_of_id = bitoff_id;
    zT_76.is_windows_id = iw_id;
    zT_77 = 0;
    zT_76.host_is_windows = zT_77;
    return zT_76;
}

/* comptimeEvalBinOp */
zT_E33A227C_Opt_201 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_E33A227C_Opt_201 zT_14 = {0};
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_E33A227C_Opt_201 zT_20 = {0};
    unsigned char zT_21;
    unsigned char zT_23;
    unsigned int zT_25;
    unsigned char zT_28;
    unsigned int zT_29;
    zT_E33A227C_Opt_201 zT_32 = {0};
    zT_79FAE712_u64 zT_34;
    zT_79FAE712_u64 zT_36;
    unsigned char zT_38;
    unsigned char zT_39;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_45;
    zT_89B1DDDA_ComptimeVal zT_50;
    zT_79FAE712_u64 zT_51;
    zT_E33A227C_Opt_201 zT_52;
    zT_89B1DDDA_ComptimeVal zT_57;
    zT_79FAE712_u64 zT_58;
    zT_E33A227C_Opt_201 zT_59;
    zT_89B1DDDA_ComptimeVal zT_64;
    zT_79FAE712_u64 zT_65;
    zT_E33A227C_Opt_201 zT_66;
    zT_E33A227C_Opt_201 zT_73 = {0};
    zT_79FAE712_u64 zT_78;
    zT_79FAE712_u64 zT_83;
    zT_79FAE712_u64 zT_85 = 0;
    zT_79FAE712_u64 zT_87 = 0;
    zT_79FAE712_u64 zT_91;
    zT_79FAE712_u64 zT_95;
    zT_79FAE712_u64 zT_97;
    zT_79FAE712_u64 zT_100;
    zT_89B1DDDA_ComptimeVal zT_101;
    unsigned char zT_102;
    zT_E33A227C_Opt_201 zT_103;
    zT_89B1DDDA_ComptimeVal zT_104;
    zT_79FAE712_u64 zT_105;
    unsigned char zT_106;
    zT_E33A227C_Opt_201 zT_107;
    zT_E33A227C_Opt_201 zT_114 = {0};
    zT_79FAE712_u64 zT_119;
    zT_79FAE712_u64 zT_124;
    zT_79FAE712_u64 zT_126 = 0;
    zT_79FAE712_u64 zT_128 = 0;
    zT_79FAE712_u64 zT_132;
    zT_79FAE712_u64 zT_136;
    zT_79FAE712_u64 zT_138;
    zT_79FAE712_u64 zT_142;
    zT_89B1DDDA_ComptimeVal zT_143;
    unsigned char zT_144;
    zT_E33A227C_Opt_201 zT_145;
    zT_89B1DDDA_ComptimeVal zT_146;
    zT_79FAE712_u64 zT_147;
    unsigned char zT_148;
    zT_E33A227C_Opt_201 zT_149;
    zT_89B1DDDA_ComptimeVal zT_154;
    zT_79FAE712_u64 zT_155;
    zT_E33A227C_Opt_201 zT_156;
    zT_89B1DDDA_ComptimeVal zT_161;
    zT_79FAE712_u64 zT_162;
    zT_E33A227C_Opt_201 zT_163;
    zT_89B1DDDA_ComptimeVal zT_168;
    zT_79FAE712_u64 zT_169;
    zT_E33A227C_Opt_201 zT_170;
    zT_E33A227C_Opt_201 zT_177 = {0};
    zT_89B1DDDA_ComptimeVal zT_178;
    zT_79FAE712_u64 zT_179;
    zT_E33A227C_Opt_201 zT_180;
    zT_E33A227C_Opt_201 zT_187 = {0};
    zT_89B1DDDA_ComptimeVal zT_188;
    zT_79FAE712_u64 zT_189;
    zT_E33A227C_Opt_201 zT_190;
    zT_E33A227C_Opt_201 zT_191 = {0};
    zT_22A7C88B_AstNode node;
    zT_E33A227C_Opt_201 lhs;
    zT_E33A227C_Opt_201 rhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_89B1DDDA_ComptimeVal r;
    zT_79FAE712_u64 lv;
    zT_79FAE712_u64 rv;
    unsigned char use_signed;
    unsigned int maxw;
    zT_79FAE712_u64 sl;
    zT_79FAE712_u64 sr;
    zT_79FAE712_u64 al;
    zT_79FAE712_u64 ar;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 rem;
    zT_5 = self->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    zT_10 = self;
    zT_11 = node.child_0;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    zT_16 = self;
    zT_17 = node.child_1;
    zT_18 = depth;
    zT_20 = zF_4EE17137_comptimeEvalEvaluat(zT_16, zT_17, zT_18);
    rhs = zT_20;
    zT_21 = lhs.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    l = lhs.value;
    zT_23 = rhs.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_191.has_value = 0;
    return zT_191;
    z_bb_3:
    r = rhs.value;
    zT_25 = l.width_bits;
    if ((unsigned char)(zT_25 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_29 = r.width_bits;
    zT_28 = zT_29 == zG_9D6D351A_WIDTH_FLOAT;
    goto z_bb_7;
    z_bb_6:
    zT_28 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_28) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_32.has_value = 0;
    return zT_32;
    z_bb_9:
    zT_34 = l.bits;
    lv = zT_34;
    zT_36 = r.bits;
    rv = zT_36;
    zT_38 = l.sig;
    if (zT_38) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_39 = r.sig;
    goto z_bb_12;
    z_bb_11:
    zT_39 = 1;
    goto z_bb_12;
    z_bb_12:
    use_signed = zT_39;
    zT_42 = l.width_bits;
    maxw = zT_42;
    zT_43 = r.width_bits;
    if ((unsigned char)(zT_43 > maxw)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = r.width_bits;
    maxw = zT_45;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_51 = lv + rv;
    zT_50.bits = zT_51;
    zT_50.width_bits = maxw;
    zT_50.sig = use_signed;
    zT_52.has_value = 1;
    zT_52.value = zT_50;
    return zT_52;
    z_bb_16:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_58 = lv - rv;
    zT_57.bits = zT_58;
    zT_57.width_bits = maxw;
    zT_57.sig = use_signed;
    zT_59.has_value = 1;
    zT_59.value = zT_57;
    return zT_59;
    z_bb_18:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_65 = lv * rv;
    zT_64.bits = zT_65;
    zT_64.width_bits = maxw;
    zT_64.sig = use_signed;
    zT_66.has_value = 1;
    zT_66.value = zT_64;
    return zT_66;
    z_bb_20:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    if ((unsigned char)(rv == (zT_79FAE712_u64)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op))) goto z_bb_35; else goto z_bb_36;
    z_bb_23:
    zT_73.has_value = 0;
    return zT_73;
    z_bb_24:
    if (use_signed) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_78 = (zT_79FAE712_u64)(lv >> (zT_79FAE712_u64)(63)) & (zT_79FAE712_u64)(1);
    sl = zT_78;
    zT_83 = (zT_79FAE712_u64)(rv >> (zT_79FAE712_u64)(63)) & (zT_79FAE712_u64)(1);
    sr = zT_83;
    al = zT_85;
    ar = zT_87;
    if ((unsigned char)(sl == (zT_79FAE712_u64)(1))) goto z_bb_27; else goto z_bb_29;
    z_bb_26:
    zT_105 = lv / rv;
    zT_104.bits = zT_105;
    zT_104.width_bits = maxw;
    zT_106 = 0;
    zT_104.sig = zT_106;
    zT_107.has_value = 1;
    zT_107.value = zT_104;
    return zT_107;
    z_bb_27:
    zT_91 = (zT_79FAE712_u64)(0) - lv;
    al = zT_91;
    goto z_bb_28;
    z_bb_28:
    if ((unsigned char)(sr == (zT_79FAE712_u64)(1))) goto z_bb_30; else goto z_bb_32;
    z_bb_29:
    al = lv;
    goto z_bb_28;
    z_bb_30:
    zT_95 = (zT_79FAE712_u64)(0) - rv;
    ar = zT_95;
    goto z_bb_31;
    z_bb_31:
    zT_97 = al / ar;
    q = zT_97;
    if ((unsigned char)(sl != sr)) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    ar = rv;
    goto z_bb_31;
    z_bb_33:
    zT_100 = (zT_79FAE712_u64)(0) - q;
    q = zT_100;
    goto z_bb_34;
    z_bb_34:
    zT_101.bits = q;
    zT_101.width_bits = maxw;
    zT_102 = 1;
    zT_101.sig = zT_102;
    zT_103.has_value = 1;
    zT_103.value = zT_101;
    return zT_103;
    z_bb_35:
    if ((unsigned char)(rv == (zT_79FAE712_u64)(0))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_49; else goto z_bb_50;
    z_bb_37:
    zT_114.has_value = 0;
    return zT_114;
    z_bb_38:
    if (use_signed) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_119 = (zT_79FAE712_u64)(lv >> (zT_79FAE712_u64)(63)) & (zT_79FAE712_u64)(1);
    sl = zT_119;
    zT_124 = (zT_79FAE712_u64)(rv >> (zT_79FAE712_u64)(63)) & (zT_79FAE712_u64)(1);
    sr = zT_124;
    al = zT_126;
    ar = zT_128;
    if ((unsigned char)(sl == (zT_79FAE712_u64)(1))) goto z_bb_41; else goto z_bb_43;
    z_bb_40:
    zT_147 = lv % rv;
    zT_146.bits = zT_147;
    zT_146.width_bits = maxw;
    zT_148 = 0;
    zT_146.sig = zT_148;
    zT_149.has_value = 1;
    zT_149.value = zT_146;
    return zT_149;
    z_bb_41:
    zT_132 = (zT_79FAE712_u64)(0) - lv;
    al = zT_132;
    goto z_bb_42;
    z_bb_42:
    if ((unsigned char)(sr == (zT_79FAE712_u64)(1))) goto z_bb_44; else goto z_bb_46;
    z_bb_43:
    al = lv;
    goto z_bb_42;
    z_bb_44:
    zT_136 = (zT_79FAE712_u64)(0) - rv;
    ar = zT_136;
    goto z_bb_45;
    z_bb_45:
    zT_138 = al % ar;
    rem = zT_138;
    if ((unsigned char)(sl == (zT_79FAE712_u64)(1))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    ar = rv;
    goto z_bb_45;
    z_bb_47:
    zT_142 = (zT_79FAE712_u64)(0) - rem;
    rem = zT_142;
    goto z_bb_48;
    z_bb_48:
    zT_143.bits = rem;
    zT_143.width_bits = maxw;
    zT_144 = 1;
    zT_143.sig = zT_144;
    zT_145.has_value = 1;
    zT_145.value = zT_143;
    return zT_145;
    z_bb_49:
    zT_155 = lv & rv;
    zT_154.bits = zT_155;
    zT_154.width_bits = maxw;
    zT_154.sig = use_signed;
    zT_156.has_value = 1;
    zT_156.value = zT_154;
    return zT_156;
    z_bb_50:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or))) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_162 = lv | rv;
    zT_161.bits = zT_162;
    zT_161.width_bits = maxw;
    zT_161.sig = use_signed;
    zT_163.has_value = 1;
    zT_163.value = zT_161;
    return zT_163;
    z_bb_52:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_169 = lv ^ rv;
    zT_168.bits = zT_169;
    zT_168.width_bits = maxw;
    zT_168.sig = use_signed;
    zT_170.has_value = 1;
    zT_170.value = zT_168;
    return zT_170;
    z_bb_54:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    if ((unsigned char)(rv >= (zT_79FAE712_u64)(64))) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    if ((unsigned char)(op_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_177.has_value = 0;
    return zT_177;
    z_bb_58:
    zT_179 = lv << rv;
    zT_178.bits = zT_179;
    zT_178.width_bits = maxw;
    zT_178.sig = use_signed;
    zT_180.has_value = 1;
    zT_180.value = zT_178;
    return zT_180;
    z_bb_59:
    if ((unsigned char)(rv >= (zT_79FAE712_u64)(64))) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    goto z_bb_4;
    z_bb_61:
    zT_187.has_value = 0;
    return zT_187;
    z_bb_62:
    zT_189 = lv >> rv;
    zT_188.bits = zT_189;
    zT_188.width_bits = maxw;
    zT_188.sig = use_signed;
    zT_190.has_value = 1;
    zT_190.value = zT_188;
    return zT_190;
}

/* comptimeEvalResolveTypeArg */
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    unsigned int zT_12;
    zT_7334F4FE_Opt_225 zT_13 = {0};
    zT_F6B96876_Opt_395 zT_14 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_16;
    unsigned int zT_17;
    unsigned int zT_21 = 0;
    zT_BAEE192E_Opt_10 zT_24 = {0};
    zT_BAEE192E_Opt_10 zT_25;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int tid;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_7 = self->store;
    zT_6.store = zT_7;
    zT_8 = self->registry;
    zT_6.typereg = zT_8;
    zT_9 = self->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = self->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_12 = 0;
    zT_6.source_file_id = zT_12;
    zT_13.has_value = 0;
    zT_6.diag = zT_13;
    zT_14.has_value = 0;
    zT_6.local_consts = zT_14;
    env = zT_6;
    zT_16 = &env;
    zT_17 = node_idx;
    zT_21 = zF_F2107C15_resolveTypeExprFull(zT_16, zT_17, (unsigned int)(0));
    tid = zT_21;
    if ((unsigned char)(tid == (unsigned int)(18))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_24.has_value = 0;
    return zT_24;
    z_bb_4:
    zT_25.has_value = 1;
    zT_25.value = tid;
    return zT_25;
}

/* comptimeEvalBuiltin */
zT_E33A227C_Opt_201 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    zT_DA663F79_ComptimeEval* zT_12;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_14;
    unsigned int zT_15;
    unsigned int zT_19 = 0;
    zT_BAEE192E_Opt_10 zT_20 = {0};
    unsigned char zT_21;
    zT_338B7C76_TypeRegistry* zT_24;
    zT_D155D06D_Type* zT_25;
    unsigned int zT_26;
    zT_D155D06D_Type zT_27;
    unsigned char zT_28;
    zT_89B1DDDA_ComptimeVal zT_31;
    unsigned int zT_32;
    zT_79FAE712_u64 zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    zT_E33A227C_Opt_201 zT_36;
    zT_E33A227C_Opt_201 zT_37 = {0};
    unsigned int zT_38;
    unsigned int zT_39;
    zT_DA663F79_ComptimeEval* zT_42;
    unsigned int zT_43;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    unsigned int zT_49 = 0;
    zT_BAEE192E_Opt_10 zT_50 = {0};
    unsigned char zT_51;
    zT_338B7C76_TypeRegistry* zT_54;
    zT_D155D06D_Type* zT_55;
    unsigned int zT_56;
    zT_D155D06D_Type zT_57;
    unsigned char zT_58;
    zT_89B1DDDA_ComptimeVal zT_61;
    unsigned int zT_62;
    zT_79FAE712_u64 zT_63;
    unsigned int zT_64;
    unsigned char zT_65;
    zT_E33A227C_Opt_201 zT_66;
    zT_E33A227C_Opt_201 zT_67 = {0};
    unsigned int zT_68;
    unsigned int zT_69;
    unsigned char zT_71;
    unsigned int zT_72;
    unsigned int zT_73;
    zT_6B0A7D14_AstStore* zT_76;
    unsigned int zT_77;
    unsigned int zT_79 = 0;
    zT_DA663F79_ComptimeEval* zT_83;
    unsigned int zT_84;
    zT_6B0A7D14_AstStore* zT_85;
    unsigned int zT_86;
    unsigned int zT_90 = 0;
    zT_BAEE192E_Opt_10 zT_91 = {0};
    unsigned char zT_92;
    zT_338B7C76_TypeRegistry* zT_95;
    zT_D155D06D_Type* zT_96;
    unsigned int zT_97;
    zT_D155D06D_Type zT_98;
    unsigned char zT_99;
    unsigned char zT_102;
    zT_33EF6BFB_TypeKind zT_103;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_109 = {0};
    zT_338B7C76_TypeRegistry* zT_110;
    unsigned int zT_111;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_112;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_116 = {0};
    zT_338B7C76_TypeRegistry* zT_118;
    unsigned int zT_119;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_120;
    unsigned char zT_123 = 0;
    zT_6B0A7D14_AstStore* zT_125;
    unsigned int zT_126;
    zT_6B0A7D14_AstStore* zT_128;
    unsigned int zT_129;
    unsigned int zT_133 = 0;
    zT_22A7C88B_AstNode zT_134 = {0};
    zT_8143F551_AstKind zT_135;
    zT_6B0A7D14_AstStore* zT_141;
    unsigned int zT_142;
    zT_6B0A7D14_AstStore* zT_144;
    unsigned int zT_145;
    unsigned int zT_149 = 0;
    unsigned int zT_150 = 0;
    zT_6B0A7D14_AstStore* zT_152;
    zT_C298CD99_anon_232444 zT_153;
    unsigned int* zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    int zT_158;
    unsigned int zT_159;
    unsigned int zT_161;
    zT_2DF01B61_FieldEntry* zT_163;
    zT_2DF01B61_FieldEntry zT_164;
    unsigned int zT_165;
    zT_2DF01B61_FieldEntry* zT_168;
    zT_2DF01B61_FieldEntry zT_169;
    unsigned int zT_170;
    zT_79FAE712_u64 zT_171;
    zT_79FAE712_u64 zT_173;
    unsigned int zT_175;
    zT_E276DDD0_PackedBitField* zT_177;
    zT_E276DDD0_PackedBitField zT_178;
    unsigned int zT_179;
    zT_79FAE712_u64 zT_180;
    unsigned int zT_181;
    unsigned int zT_182;
    zT_79FAE712_u64 zT_185;
    unsigned int zT_186;
    unsigned int zT_187;
    zT_79FAE712_u64 zT_190;
    zT_89B1DDDA_ComptimeVal zT_191;
    unsigned int zT_192;
    unsigned char zT_193;
    zT_E33A227C_Opt_201 zT_194;
    int zT_195;
    unsigned int zT_197;
    unsigned char zT_198;
    unsigned char zT_201;
    zT_33EF6BFB_TypeKind zT_202;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_208 = {0};
    zT_338B7C76_TypeRegistry* zT_209;
    unsigned int zT_210;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_211;
    zT_6B0A7D14_AstStore* zT_215;
    unsigned int zT_216;
    zT_6B0A7D14_AstStore* zT_218;
    unsigned int zT_219;
    unsigned int zT_223 = 0;
    zT_22A7C88B_AstNode zT_224 = {0};
    zT_8143F551_AstKind zT_225;
    zT_6B0A7D14_AstStore* zT_231;
    unsigned int zT_232;
    zT_6B0A7D14_AstStore* zT_234;
    unsigned int zT_235;
    unsigned int zT_239 = 0;
    unsigned int zT_240 = 0;
    zT_6B0A7D14_AstStore* zT_242;
    zT_C298CD99_anon_232444 zT_243;
    unsigned int* zT_244;
    unsigned int zT_245;
    unsigned int zT_246;
    int zT_248;
    unsigned int zT_249;
    unsigned int zT_251;
    zT_2DF01B61_FieldEntry* zT_253;
    zT_2DF01B61_FieldEntry zT_254;
    unsigned int zT_255;
    zT_79FAE712_u64 zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    zT_79FAE712_u64 zT_262;
    zT_89B1DDDA_ComptimeVal zT_263;
    unsigned int zT_264;
    unsigned char zT_265;
    zT_E33A227C_Opt_201 zT_266;
    int zT_267;
    unsigned int zT_269;
    zT_E33A227C_Opt_201 zT_270 = {0};
    unsigned int zT_271;
    unsigned int zT_272;
    zT_6B0A7D14_AstStore* zT_275;
    unsigned int zT_276;
    unsigned int zT_278 = 0;
    zT_DA663F79_ComptimeEval* zT_282;
    unsigned int zT_283;
    zT_6B0A7D14_AstStore* zT_284;
    unsigned int zT_285;
    unsigned int zT_289 = 0;
    zT_BAEE192E_Opt_10 zT_290 = {0};
    unsigned char zT_291;
    zT_338B7C76_TypeRegistry* zT_294;
    zT_D155D06D_Type* zT_295;
    unsigned int zT_296;
    zT_D155D06D_Type zT_297;
    unsigned char zT_298;
    unsigned int zT_302;
    zT_79FAE712_u64 zT_305;
    zT_33EF6BFB_TypeKind zT_306;
    unsigned char zT_311;
    unsigned char zT_312;
    zT_338B7C76_TypeRegistry* zT_317;
    unsigned int zT_318;
    unsigned int zT_320 = 0;
    zT_79FAE712_u64 zT_321;
    zT_33EF6BFB_TypeKind zT_322;
    zT_338B7C76_TypeRegistry* zT_327;
    unsigned int zT_328;
    unsigned int zT_330 = 0;
    zT_79FAE712_u64 zT_331;
    zT_338B7C76_TypeRegistry* zT_332;
    unsigned int zT_333;
    unsigned char zT_335 = 0;
    zT_338B7C76_TypeRegistry* zT_336;
    unsigned int zT_337;
    unsigned char zT_339 = 0;
    zT_79FAE712_u64 zT_340;
    zT_33EF6BFB_TypeKind zT_341;
    zT_338B7C76_TypeRegistry* zT_347;
    unsigned int zT_348;
    unsigned int zT_350 = 0;
    zT_338B7C76_TypeRegistry* zT_351;
    unsigned int zT_352;
    unsigned char zT_354 = 0;
    zT_79FAE712_u64 zT_355;
    zT_33EF6BFB_TypeKind zT_356;
    zT_79FAE712_u64 zT_361;
    zT_89B1DDDA_ComptimeVal zT_362;
    unsigned int zT_363;
    unsigned char zT_364;
    zT_E33A227C_Opt_201 zT_365;
    zT_E33A227C_Opt_201 zT_366 = {0};
    unsigned int zT_367;
    unsigned int zT_368;
    zT_DA663F79_ComptimeEval* zT_371;
    unsigned int zT_372;
    zT_6B0A7D14_AstStore* zT_373;
    unsigned int zT_374;
    unsigned int zT_378 = 0;
    zT_BAEE192E_Opt_10 zT_379 = {0};
    zT_DA663F79_ComptimeEval* zT_381;
    unsigned int zT_382;
    unsigned int zT_383;
    zT_6B0A7D14_AstStore* zT_384;
    unsigned int zT_385;
    unsigned int zT_389 = 0;
    zT_E33A227C_Opt_201 zT_390 = {0};
    unsigned char zT_391;
    unsigned char zT_393;
    unsigned int zT_395;
    zT_E33A227C_Opt_201 zT_398 = {0};
    zT_338B7C76_TypeRegistry* zT_400;
    zT_D155D06D_Type* zT_401;
    unsigned int zT_402;
    zT_D155D06D_Type zT_403;
    zT_338B7C76_TypeRegistry* zT_405;
    unsigned int zT_406;
    unsigned char zT_408 = 0;
    zT_338B7C76_TypeRegistry* zT_410;
    unsigned int zT_411;
    unsigned char zT_413 = 0;
    unsigned int zT_414;
    zT_338B7C76_TypeRegistry* zT_416;
    unsigned int zT_417;
    unsigned char zT_419 = 0;
    unsigned int zT_421;
    unsigned int zT_424;
    unsigned char zT_425;
    zT_89B1DDDA_ComptimeVal zT_428;
    zT_79FAE712_u64 zT_429;
    zT_E33A227C_Opt_201 zT_430;
    zT_79FAE712_u64 zT_436;
    zT_79FAE712_u64 zT_438;
    zT_79FAE712_u64 zT_439;
    unsigned char zT_440;
    zT_79FAE712_u64 zT_441;
    zT_79FAE712_u64 zT_454;
    zT_79FAE712_u64 zT_455;
    zT_79FAE712_u64 zT_456;
    zT_89B1DDDA_ComptimeVal zT_457;
    zT_E33A227C_Opt_201 zT_458;
    zT_E33A227C_Opt_201 zT_459 = {0};
    unsigned int zT_460;
    unsigned int zT_461;
    zT_79FAE712_u64 zT_464;
    unsigned char zT_465;
    zT_79FAE712_u64 zT_466;
    zT_89B1DDDA_ComptimeVal zT_467;
    unsigned int zT_468;
    unsigned char zT_469;
    zT_E33A227C_Opt_201 zT_470;
    unsigned int zT_471;
    unsigned int zT_472;
    unsigned char zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    zT_DA663F79_ComptimeEval* zT_479;
    unsigned int zT_480;
    unsigned int zT_481;
    zT_BCEE1C54_Opt_16 zT_482 = {0};
    unsigned char zT_483;
    double* zT_487;
    zT_79FAE712_u64* zT_488;
    zT_89B1DDDA_ComptimeVal zT_489;
    zT_79FAE712_u64 zT_490;
    unsigned char zT_492;
    zT_E33A227C_Opt_201 zT_493;
    zT_E33A227C_Opt_201 zT_494 = {0};
    zT_E33A227C_Opt_201 zT_495 = {0};
    zT_22A7C88B_AstNode node;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    zT_D155D06D_Type ty;
    unsigned int ec2_n;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    unsigned char has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    zT_BF2E90D8_Slice_zT_2DF01B61_F u_fields;
    zT_22A7C88B_AstNode fname_node2;
    unsigned int sv_idx2;
    unsigned int want_id2;
    unsigned int fi2;
    zT_79FAE712_u64 ubo;
    unsigned int ec3_n;
    zT_BAEE192E_Opt_10 tid2;
    unsigned int t2;
    zT_D155D06D_Type ty2;
    zT_79FAE712_u64 bsz;
    unsigned int ebt;
    zT_E33A227C_Opt_201 inner;
    zT_89B1DDDA_ComptimeVal cv;
    unsigned char is_int_t;
    unsigned int wb;
    unsigned char sig;
    zT_79FAE712_u64 mask;
    zT_79FAE712_u64 masked;
    zT_79FAE712_u64 not_mask;
    zT_79FAE712_u64 wb2;
    zT_BCEE1C54_Opt_16 fv;
    double v;
    double fb;
    zT_79FAE712_u64* fbp;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_8 = node.child_0;
    zT_9 = self->size_of_id;
    if ((unsigned char)(zT_8 == zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_14 = self->store;
    zT_15 = node_idx;
    zT_19 = zF_B10B1BC1_astStoreNodeExtraCh(zT_14, zT_15, (unsigned int)(0));
    zT_13 = zT_19;
    zT_20 = zF_BAD6BA5D_comptimeEvalResolve(zT_12, zT_13);
    tid = zT_20;
    zT_21 = tid.has_value;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_38 = node.child_0;
    zT_39 = self->align_of_id;
    if ((unsigned char)(zT_38 == zT_39)) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    t = tid.value;
    zT_24 = self->registry;
    zT_25 = zT_24->types_items;
    zT_26 = (unsigned int)t;
    zT_27 = zT_25[zT_26];
    ty = zT_27;
    zT_28 = ty.state;
    if ((unsigned char)(zT_28 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_37.has_value = 0;
    return zT_37;
    z_bb_5:
    zT_32 = ty.size;
    zT_33 = (zT_79FAE712_u64)zT_32;
    zT_31.bits = zT_33;
    zT_34 = 0;
    zT_31.width_bits = zT_34;
    zT_35 = 0;
    zT_31.sig = zT_35;
    zT_36.has_value = 1;
    zT_36.value = zT_31;
    return zT_36;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_42 = self;
    zT_44 = self->store;
    zT_45 = node_idx;
    zT_49 = zF_B10B1BC1_astStoreNodeExtraCh(zT_44, zT_45, (unsigned int)(0));
    zT_43 = zT_49;
    zT_50 = zF_BAD6BA5D_comptimeEvalResolve(zT_42, zT_43);
    tid = zT_50;
    zT_51 = tid.has_value;
    if (zT_51) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_68 = node.child_0;
    zT_69 = self->offset_of_id;
    if ((unsigned char)(zT_68 == zT_69)) goto z_bb_14; else goto z_bb_13;
    z_bb_9:
    t = tid.value;
    zT_54 = self->registry;
    zT_55 = zT_54->types_items;
    zT_56 = (unsigned int)t;
    zT_57 = zT_55[zT_56];
    ty = zT_57;
    zT_58 = ty.state;
    if ((unsigned char)(zT_58 == (unsigned char)(2))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_67.has_value = 0;
    return zT_67;
    z_bb_11:
    zT_62 = ty.alignment;
    zT_63 = (zT_79FAE712_u64)zT_62;
    zT_61.bits = zT_63;
    zT_64 = 0;
    zT_61.width_bits = zT_64;
    zT_65 = 0;
    zT_61.sig = zT_65;
    zT_66.has_value = 1;
    zT_66.value = zT_61;
    return zT_66;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_72 = node.child_0;
    zT_73 = self->bit_offset_of_id;
    zT_71 = zT_72 == zT_73;
    goto z_bb_15;
    z_bb_14:
    zT_71 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_71) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_76 = self->store;
    zT_77 = node_idx;
    zT_79 = zF_152E19CB_astStoreNodeExtraCh(zT_76, zT_77);
    ec2_n = zT_79;
    if ((unsigned char)(ec2_n >= (unsigned int)(2))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_271 = node.child_0;
    zT_272 = self->bit_size_of_id;
    if ((unsigned char)(zT_271 == zT_272)) goto z_bb_61; else goto z_bb_62;
    z_bb_18:
    zT_83 = self;
    zT_85 = self->store;
    zT_86 = node_idx;
    zT_90 = zF_B10B1BC1_astStoreNodeExtraCh(zT_85, zT_86, (unsigned int)(0));
    zT_84 = zT_90;
    zT_91 = zF_BAD6BA5D_comptimeEvalResolve(zT_83, zT_84);
    tid = zT_91;
    zT_92 = tid.has_value;
    if (zT_92) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_270.has_value = 0;
    return zT_270;
    z_bb_20:
    t = tid.value;
    zT_95 = self->registry;
    zT_96 = zT_95->types_items;
    zT_97 = (unsigned int)t;
    zT_98 = zT_96[zT_97];
    ty = zT_98;
    zT_99 = ty.state;
    if ((unsigned char)(zT_99 == (unsigned char)(2))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_103 = ty.kind;
    zT_102 = zT_103 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_24;
    z_bb_23:
    zT_102 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_102) goto z_bb_25; else goto z_bb_27;
    z_bb_25:
    fields = zT_109;
    zT_110 = self->registry;
    zT_111 = t;
    zT_112 = &fields;
    zF_5A40A2EE_typeRegistryGetStru(zT_110, zT_111, zT_112);
    packed_fields = zT_116;
    zT_118 = self->registry;
    zT_119 = t;
    zT_120 = &packed_fields;
    zT_123 = zF_7D87247C_typeRegistryGetPack(zT_118, zT_119, zT_120);
    has_pk = zT_123;
    zT_125 = self->store;
    zT_128 = self->store;
    zT_129 = node_idx;
    zT_133 = zF_B10B1BC1_astStoreNodeExtraCh(zT_128, zT_129, (unsigned int)(1));
    zT_126 = zT_133;
    zT_134 = zF_FCDD1D35_astStoreNodeAt(zT_125, zT_126);
    fname_node = zT_134;
    zT_135 = fname_node.kind;
    if ((unsigned char)(zT_135 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_198 = ty.state;
    if ((unsigned char)(zT_198 == (unsigned char)(2))) goto z_bb_46; else goto z_bb_47;
    z_bb_28:
    zT_141 = self->store;
    zT_144 = self->store;
    zT_145 = node_idx;
    zT_149 = zF_B10B1BC1_astStoreNodeExtraCh(zT_144, zT_145, (unsigned int)(1));
    zT_142 = zT_149;
    zT_150 = zF_8BA26B9E_astStoreNodePayload(zT_141, zT_142);
    sv_idx = zT_150;
    zT_152 = self->store;
    zT_153 = zT_152->string_values;
    zT_154 = zT_153.items;
    zT_155 = (unsigned int)sv_idx;
    zT_156 = zT_154[zT_155];
    want_id = zT_156;
    zT_158 = 0;
    zT_159 = (unsigned int)zT_158;
    fi = zT_159;
    goto z_bb_30;
    z_bb_29:
    goto z_bb_26;
    z_bb_30:
    zT_161 = fields.len;
    if ((unsigned char)(fi < zT_161)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_163 = fields.ptr;
    zT_164 = zT_163[fi];
    zT_165 = zT_164.name_id;
    if ((unsigned char)(zT_165 == want_id)) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    goto z_bb_29;
    z_bb_33:
    zT_195 = 1;
    zT_197 = fi + (unsigned int)((unsigned int)zT_195);
    fi = zT_197;
    goto z_bb_30;
    z_bb_34:
    zT_168 = fields.ptr;
    zT_169 = zT_168[fi];
    zT_170 = zT_169.offset;
    zT_171 = (zT_79FAE712_u64)zT_170;
    bo = zT_171;
    if (has_pk) goto z_bb_36; else goto z_bb_38;
    z_bb_35:
    goto z_bb_33;
    z_bb_36:
    zT_173 = 0;
    pk_bo = zT_173;
    zT_175 = packed_fields.len;
    if ((unsigned char)(fi < zT_175)) goto z_bb_39; else goto z_bb_40;
    z_bb_37:
    zT_191.bits = bo;
    zT_192 = 0;
    zT_191.width_bits = zT_192;
    zT_193 = 0;
    zT_191.sig = zT_193;
    zT_194.has_value = 1;
    zT_194.value = zT_191;
    return zT_194;
    z_bb_38:
    zT_186 = node.child_0;
    zT_187 = self->bit_offset_of_id;
    if ((unsigned char)(zT_186 == zT_187)) goto z_bb_44; else goto z_bb_45;
    z_bb_39:
    zT_177 = packed_fields.ptr;
    zT_178 = zT_177[fi];
    zT_179 = zT_178.bit_offset;
    zT_180 = (zT_79FAE712_u64)zT_179;
    pk_bo = zT_180;
    goto z_bb_40;
    z_bb_40:
    zT_181 = node.child_0;
    zT_182 = self->bit_offset_of_id;
    if ((unsigned char)(zT_181 == zT_182)) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    bo = pk_bo;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_37;
    z_bb_43:
    zT_185 = pk_bo / (zT_79FAE712_u64)(8);
    bo = zT_185;
    goto z_bb_42;
    z_bb_44:
    zT_190 = bo * (zT_79FAE712_u64)(8);
    bo = zT_190;
    goto z_bb_45;
    z_bb_45:
    goto z_bb_37;
    z_bb_46:
    zT_202 = ty.kind;
    zT_201 = zT_202 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_48;
    z_bb_47:
    zT_201 = 0;
    goto z_bb_48;
    z_bb_48:
    if (zT_201) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    u_fields = zT_208;
    zT_209 = self->registry;
    zT_210 = t;
    zT_211 = &u_fields;
    zF_15BD2D98_typeRegistryGetUnio(zT_209, zT_210, zT_211);
    zT_215 = self->store;
    zT_218 = self->store;
    zT_219 = node_idx;
    zT_223 = zF_B10B1BC1_astStoreNodeExtraCh(zT_218, zT_219, (unsigned int)(1));
    zT_216 = zT_223;
    zT_224 = zF_FCDD1D35_astStoreNodeAt(zT_215, zT_216);
    fname_node2 = zT_224;
    zT_225 = fname_node2.kind;
    if ((unsigned char)(zT_225 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_26;
    z_bb_51:
    zT_231 = self->store;
    zT_234 = self->store;
    zT_235 = node_idx;
    zT_239 = zF_B10B1BC1_astStoreNodeExtraCh(zT_234, zT_235, (unsigned int)(1));
    zT_232 = zT_239;
    zT_240 = zF_8BA26B9E_astStoreNodePayload(zT_231, zT_232);
    sv_idx2 = zT_240;
    zT_242 = self->store;
    zT_243 = zT_242->string_values;
    zT_244 = zT_243.items;
    zT_245 = (unsigned int)sv_idx2;
    zT_246 = zT_244[zT_245];
    want_id2 = zT_246;
    zT_248 = 0;
    zT_249 = (unsigned int)zT_248;
    fi2 = zT_249;
    goto z_bb_53;
    z_bb_52:
    goto z_bb_50;
    z_bb_53:
    zT_251 = u_fields.len;
    if ((unsigned char)(fi2 < zT_251)) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_253 = u_fields.ptr;
    zT_254 = zT_253[fi2];
    zT_255 = zT_254.name_id;
    if ((unsigned char)(zT_255 == want_id2)) goto z_bb_57; else goto z_bb_58;
    z_bb_55:
    goto z_bb_52;
    z_bb_56:
    zT_267 = 1;
    zT_269 = fi2 + (unsigned int)((unsigned int)zT_267);
    fi2 = zT_269;
    goto z_bb_53;
    z_bb_57:
    zT_258 = 0;
    ubo = zT_258;
    zT_259 = node.child_0;
    zT_260 = self->offset_of_id;
    if ((unsigned char)(zT_259 == zT_260)) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    zT_262 = 0;
    ubo = zT_262;
    goto z_bb_60;
    z_bb_60:
    zT_263.bits = ubo;
    zT_264 = 0;
    zT_263.width_bits = zT_264;
    zT_265 = 0;
    zT_263.sig = zT_265;
    zT_266.has_value = 1;
    zT_266.value = zT_263;
    return zT_266;
    z_bb_61:
    zT_275 = self->store;
    zT_276 = node_idx;
    zT_278 = zF_152E19CB_astStoreNodeExtraCh(zT_275, zT_276);
    ec3_n = zT_278;
    if ((unsigned char)(ec3_n >= (unsigned int)(1))) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    zT_367 = node.child_0;
    zT_368 = self->int_cast_id;
    if ((unsigned char)(zT_367 == zT_368)) goto z_bb_82; else goto z_bb_83;
    z_bb_63:
    zT_282 = self;
    zT_284 = self->store;
    zT_285 = node_idx;
    zT_289 = zF_B10B1BC1_astStoreNodeExtraCh(zT_284, zT_285, (unsigned int)(0));
    zT_283 = zT_289;
    zT_290 = zF_BAD6BA5D_comptimeEvalResolve(zT_282, zT_283);
    tid2 = zT_290;
    zT_291 = tid2.has_value;
    if (zT_291) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_366.has_value = 0;
    return zT_366;
    z_bb_65:
    t2 = tid2.value;
    zT_294 = self->registry;
    zT_295 = zT_294->types_items;
    zT_296 = (unsigned int)t2;
    zT_297 = zT_295[zT_296];
    ty2 = zT_297;
    zT_298 = ty2.state;
    if ((unsigned char)(zT_298 == (unsigned char)(2))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    goto z_bb_64;
    z_bb_67:
    zT_302 = ty2.size;
    zT_305 = (zT_79FAE712_u64)((zT_79FAE712_u64)zT_302) * (zT_79FAE712_u64)(8);
    bsz = zT_305;
    zT_306 = ty2.kind;
    if ((unsigned char)(zT_306 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    goto z_bb_66;
    z_bb_69:
    zT_312 = ty2.flags;
    zT_311 = (unsigned char)(zT_312 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_71;
    z_bb_70:
    zT_311 = 0;
    goto z_bb_71;
    z_bb_71:
    if (zT_311) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    zT_317 = self->registry;
    zT_318 = t2;
    zT_320 = zF_CB27DBA4_typeRegistryGetPack(zT_317, zT_318);
    zT_321 = (zT_79FAE712_u64)zT_320;
    bsz = zT_321;
    goto z_bb_73;
    z_bb_73:
    zT_322 = ty2.kind;
    if ((unsigned char)(zT_322 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_74; else goto z_bb_75;
    z_bb_74:
    zT_327 = self->registry;
    zT_328 = t2;
    zT_330 = zF_B80C4365_typeRegistryGetPack(zT_327, zT_328);
    zT_331 = (zT_79FAE712_u64)zT_330;
    bsz = zT_331;
    goto z_bb_75;
    z_bb_75:
    zT_332 = self->registry;
    zT_333 = t2;
    zT_335 = zF_3290E9C4_typeRegistryIsInteg(zT_332, zT_333);
    if (zT_335) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_336 = self->registry;
    zT_337 = t2;
    zT_339 = zF_655972D5_typeRegistryIntWidt(zT_336, zT_337);
    zT_340 = (zT_79FAE712_u64)zT_339;
    bsz = zT_340;
    goto z_bb_77;
    z_bb_77:
    zT_341 = ty2.kind;
    if ((unsigned char)(zT_341 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_78:
    zT_347 = self->registry;
    zT_348 = t2;
    zT_350 = zF_014D7530_typeRegistryEnumBac(zT_347, zT_348);
    ebt = zT_350;
    zT_351 = self->registry;
    zT_352 = ebt;
    zT_354 = zF_655972D5_typeRegistryIntWidt(zT_351, zT_352);
    zT_355 = (zT_79FAE712_u64)zT_354;
    bsz = zT_355;
    goto z_bb_79;
    z_bb_79:
    zT_356 = ty2.kind;
    if ((unsigned char)(zT_356 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_361 = 1;
    bsz = zT_361;
    goto z_bb_81;
    z_bb_81:
    zT_362.bits = bsz;
    zT_363 = 0;
    zT_362.width_bits = zT_363;
    zT_364 = 0;
    zT_362.sig = zT_364;
    zT_365.has_value = 1;
    zT_365.value = zT_362;
    return zT_365;
    z_bb_82:
    zT_371 = self;
    zT_373 = self->store;
    zT_374 = node_idx;
    zT_378 = zF_B10B1BC1_astStoreNodeExtraCh(zT_373, zT_374, (unsigned int)(0));
    zT_372 = zT_378;
    zT_379 = zF_BAD6BA5D_comptimeEvalResolve(zT_371, zT_372);
    tid = zT_379;
    zT_381 = self;
    zT_384 = self->store;
    zT_385 = node_idx;
    zT_389 = zF_B10B1BC1_astStoreNodeExtraCh(zT_384, zT_385, (unsigned int)(1));
    zT_382 = zT_389;
    zT_383 = depth;
    zT_390 = zF_4EE17137_comptimeEvalEvaluat(zT_381, zT_382, zT_383);
    inner = zT_390;
    zT_391 = tid.has_value;
    if (zT_391) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    zT_460 = node.child_0;
    zT_461 = self->is_windows_id;
    if ((unsigned char)(zT_460 == zT_461)) goto z_bb_99; else goto z_bb_100;
    z_bb_84:
    t = tid.value;
    zT_393 = inner.has_value;
    if (zT_393) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    zT_459.has_value = 0;
    return zT_459;
    z_bb_86:
    cv = inner.value;
    zT_395 = cv.width_bits;
    if ((unsigned char)(zT_395 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_398.has_value = 0;
    return zT_398;
    z_bb_89:
    zT_400 = self->registry;
    zT_401 = zT_400->types_items;
    zT_402 = (unsigned int)t;
    zT_403 = zT_401[zT_402];
    ty = zT_403;
    zT_405 = self->registry;
    zT_406 = t;
    zT_408 = zF_3290E9C4_typeRegistryIsInteg(zT_405, zT_406);
    is_int_t = zT_408;
    zT_410 = self->registry;
    zT_411 = t;
    zT_413 = zF_655972D5_typeRegistryIntWidt(zT_410, zT_411);
    zT_414 = (unsigned int)zT_413;
    wb = zT_414;
    zT_416 = self->registry;
    zT_417 = t;
    zT_419 = zF_01ED6537_typeRegistryIntIsSi(zT_416, zT_417);
    sig = zT_419;
    if ((unsigned char)(!is_int_t)) goto z_bb_90; else goto z_bb_91;
    z_bb_90:
    zT_421 = ty.size;
    zT_424 = (unsigned int)(unsigned int)(zT_421 * (unsigned int)(8));
    wb = zT_424;
    zT_425 = 0;
    sig = zT_425;
    goto z_bb_91;
    z_bb_91:
    if ((unsigned char)(wb >= (unsigned int)(64))) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    zT_429 = cv.bits;
    zT_428.bits = zT_429;
    zT_428.width_bits = wb;
    zT_428.sig = sig;
    zT_430.has_value = 1;
    zT_430.value = zT_428;
    return zT_430;
    z_bb_93:
    zT_436 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)wb)) - (zT_79FAE712_u64)(1);
    mask = zT_436;
    zT_438 = cv.bits;
    zT_439 = zT_438 & mask;
    masked = zT_439;
    if (sig) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_441 = cv.bits;
    zT_440 = (zT_79FAE712_u64)(zT_441 & (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(wb - (unsigned int)(1))))) != (zT_79FAE712_u64)(0);
    goto z_bb_96;
    z_bb_95:
    zT_440 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_440) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_454 = (zT_79FAE712_u64)((zT_79FAE712_u64)(0) - mask) - (zT_79FAE712_u64)(1);
    not_mask = zT_454;
    zT_455 = cv.bits;
    zT_456 = zT_455 | not_mask;
    masked = zT_456;
    goto z_bb_98;
    z_bb_98:
    zT_457.bits = masked;
    zT_457.width_bits = wb;
    zT_457.sig = sig;
    zT_458.has_value = 1;
    zT_458.value = zT_457;
    return zT_458;
    z_bb_99:
    zT_464 = 0;
    wb2 = zT_464;
    zT_465 = self->host_is_windows;
    if (zT_465) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    zT_471 = node.child_0;
    zT_472 = self->int_to_float_id;
    if ((unsigned char)(zT_471 == zT_472)) goto z_bb_104; else goto z_bb_103;
    z_bb_101:
    zT_466 = 1;
    wb2 = zT_466;
    goto z_bb_102;
    z_bb_102:
    zT_467.bits = wb2;
    zT_468 = 1;
    zT_467.width_bits = zT_468;
    zT_469 = 0;
    zT_467.sig = zT_469;
    zT_470.has_value = 1;
    zT_470.value = zT_467;
    return zT_470;
    z_bb_103:
    zT_475 = node.child_0;
    zT_476 = self->float_cast_id;
    zT_474 = zT_475 == zT_476;
    goto z_bb_105;
    z_bb_104:
    zT_474 = 1;
    goto z_bb_105;
    z_bb_105:
    if (zT_474) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    zT_479 = self;
    zT_480 = node_idx;
    zT_481 = depth;
    zT_482 = zF_8C4B1954_comptimeEvalFloatBu(zT_479, zT_480, zT_481);
    fv = zT_482;
    zT_483 = fv.has_value;
    if (zT_483) goto z_bb_108; else goto z_bb_109;
    z_bb_107:
    zT_495.has_value = 0;
    return zT_495;
    z_bb_108:
    v = fv.value;
    fb = v;
    zT_487 = &fb;
    zT_488 = (zT_79FAE712_u64*)zT_487;
    fbp = zT_488;
    zT_490 = *fbp;
    zT_489.bits = zT_490;
    zT_489.width_bits = zG_9D6D351A_WIDTH_FLOAT;
    zT_492 = 0;
    zT_489.sig = zT_492;
    zT_493.has_value = 1;
    zT_493.value = zT_489;
    return zT_493;
    z_bb_109:
    zT_494.has_value = 0;
    return zT_494;
}

/* comptimeEvalFloat */
zT_BCEE1C54_Opt_16 zF_B719EB81_comptimeEvalFloat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_BCEE1C54_Opt_16 zT_5 = {0};
    zT_BCEE1C54_Opt_16 zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    zT_6B0A7D14_AstStore* zT_19;
    zT_51915FF1_anon_232435 zT_20;
    double* zT_21;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_25 = 0;
    unsigned int zT_26;
    double zT_27;
    zT_BCEE1C54_Opt_16 zT_28;
    zT_8143F551_AstKind zT_29;
    zT_DA663F79_ComptimeEval* zT_35;
    unsigned int zT_36;
    zT_BCEE1C54_Opt_16 zT_41 = {0};
    unsigned char zT_42;
    double zT_44;
    zT_BCEE1C54_Opt_16 zT_45;
    zT_BCEE1C54_Opt_16 zT_46 = {0};
    zT_8143F551_AstKind zT_47;
    zT_DA663F79_ComptimeEval* zT_52;
    unsigned int zT_55;
    unsigned int zT_57;
    zT_8143F551_AstKind zT_59;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned char zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_DA663F79_ComptimeEval* zT_71;
    unsigned int zT_72;
    zT_BCEE1C54_Opt_16 zT_76 = {0};
    zT_BCEE1C54_Opt_16 zT_77 = {0};
    zT_8143F551_AstKind zT_78;
    zT_6B0A7D14_AstStore* zT_84;
    unsigned int zT_85;
    unsigned int zT_87 = 0;
    int zT_89;
    unsigned int zT_90;
    zT_3D7259E2_SymbolRegistry* zT_91;
    unsigned int zT_92;
    zT_3D7259E2_SymbolRegistry* zT_96;
    unsigned int zT_98;
    zT_D4761958_Opt_858 zT_101 = {0};
    unsigned char zT_102;
    unsigned short zT_104;
    zT_6B0A7D14_AstStore* zT_110;
    unsigned int zT_111;
    zT_22A7C88B_AstNode zT_114 = {0};
    unsigned int zT_115;
    zT_DA663F79_ComptimeEval* zT_119;
    unsigned int zT_120;
    zT_BCEE1C54_Opt_16 zT_125 = {0};
    unsigned char zT_126;
    zT_DA663F79_ComptimeEval* zT_129;
    unsigned int zT_130;
    zT_BAEE192E_Opt_10 zT_132 = {0};
    unsigned char zT_133;
    float zT_138;
    double zT_139;
    zT_BCEE1C54_Opt_16 zT_140;
    zT_BCEE1C54_Opt_16 zT_141;
    zT_BCEE1C54_Opt_16 zT_142 = {0};
    int zT_143;
    unsigned int zT_145;
    zT_BCEE1C54_Opt_16 zT_146 = {0};
    zT_BCEE1C54_Opt_16 zT_147 = {0};
    zT_22A7C88B_AstNode node;
    zT_BCEE1C54_Opt_16 inner;
    double fv;
    unsigned int name_id;
    unsigned int mi;
    zT_D4761958_Opt_858 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_BAEE192E_Opt_10 dt;
    unsigned int t;
    float f32v;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = self->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_float_literal))) goto z_bb_5; else goto z_bb_7;
    z_bb_5:
    zT_19 = self->store;
    zT_20 = zT_19->float_values;
    zT_21 = zT_20.items;
    zT_22 = self->store;
    zT_23 = node_idx;
    zT_25 = zF_8BA26B9E_astStoreNodePayload(zT_22, zT_23);
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_21[zT_26];
    zT_28.has_value = 1;
    zT_28.value = zT_27;
    return zT_28;
    z_bb_6:
    { zT_BCEE1C54_Opt_16 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_7:
    zT_29 = node.kind;
    if ((unsigned char)(zT_29 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_35 = self;
    zT_36 = node.child_0;
    zT_41 = zF_B719EB81_comptimeEvalFloat(zT_35, zT_36, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_41;
    zT_42 = inner.has_value;
    if (zT_42) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_47 = node.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_13; else goto z_bb_15;
    z_bb_11:
    fv = inner.value;
    zT_44 = -fv;
    zT_45.has_value = 1;
    zT_45.value = zT_44;
    return zT_45;
    z_bb_12:
    zT_46.has_value = 0;
    return zT_46;
    z_bb_13:
    zT_52 = self;
    zT_55 = node.child_0;
    zT_57 = depth + (unsigned int)(1);
    self = zT_52;
    node_idx = zT_55;
    depth = zT_57;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_59 = node.kind;
    if ((unsigned char)(zT_59 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_64 = node.child_0;
    zT_65 = self->int_to_float_id;
    if ((unsigned char)(zT_64 == zT_65)) goto z_bb_20; else goto z_bb_19;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    zT_78 = node.kind;
    if ((unsigned char)(zT_78 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_24; else goto z_bb_26;
    z_bb_19:
    zT_68 = node.child_0;
    zT_69 = self->float_cast_id;
    zT_67 = zT_68 == zT_69;
    goto z_bb_21;
    z_bb_20:
    zT_67 = 1;
    goto z_bb_21;
    z_bb_21:
    if (zT_67) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_71 = self;
    zT_72 = node_idx;
    zT_76 = zF_8C4B1954_comptimeEvalFloatBu(zT_71, zT_72, (unsigned int)(depth + (unsigned int)(1)));
    return zT_76;
    z_bb_23:
    zT_77.has_value = 0;
    return zT_77;
    z_bb_24:
    zT_84 = self->store;
    zT_85 = node_idx;
    zT_87 = zF_53458827_astStoreIdentifier(zT_84, zT_85);
    name_id = zT_87;
    zT_89 = 0;
    zT_90 = (unsigned int)zT_89;
    mi = zT_90;
    goto z_bb_27;
    goto z_bb_17;
    z_bb_26:
    zT_147.has_value = 0;
    return zT_147;
    z_bb_27:
    zT_91 = self->symbol_reg;
    zT_92 = zT_91->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_92))) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_96 = self->symbol_reg;
    zT_98 = name_id;
    zT_101 = zF_A398987E_symbolRegistryQuali(zT_96, (unsigned int)((unsigned int)mi), zT_98);
    c_sym = zT_101;
    zT_102 = c_sym.has_value;
    if (zT_102) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    zT_146.has_value = 0;
    return zT_146;
    z_bb_30:
    zT_143 = 1;
    zT_145 = mi + (unsigned int)((unsigned int)zT_143);
    mi = zT_145;
    goto z_bb_27;
    z_bb_31:
    cs = c_sym.value;
    zT_104 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_104 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_110 = self->store;
    zT_111 = cs->decl_node;
    zT_114 = zF_FCDD1D35_astStoreNodeAt(zT_110, zT_111);
    c_decl = zT_114;
    zT_115 = c_decl.child_1;
    if ((unsigned char)(zT_115 != (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_119 = self;
    zT_120 = c_decl.child_1;
    zT_125 = zF_B719EB81_comptimeEvalFloat(zT_119, zT_120, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_125;
    zT_126 = inner.has_value;
    if (zT_126) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    fv = inner.value;
    zT_129 = self;
    zT_130 = c_decl.child_0;
    zT_132 = zF_BAD6BA5D_comptimeEvalResolve(zT_129, zT_130);
    dt = zT_132;
    zT_133 = dt.has_value;
    if (zT_133) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_142.has_value = 0;
    return zT_142;
    z_bb_39:
    t = dt.value;
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    zT_141.has_value = 1;
    zT_141.value = fv;
    return zT_141;
    z_bb_41:
    zT_138 = (float)fv;
    f32v = zT_138;
    zT_139 = (double)f32v;
    zT_140.has_value = 1;
    zT_140.value = zT_139;
    return zT_140;
    z_bb_42:
    goto z_bb_40;
}

/* comptimeEvalOperandSigned */
unsigned char zF_0D60B956_comptimeEvalOperand(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_89B1DDDA_ComptimeVal cv) {
    int zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_22A7C88B_AstNode zT_27 = {0};
    zT_8143F551_AstKind zT_28;
    zT_6B0A7D14_AstStore* zT_34;
    unsigned int zT_35;
    unsigned int zT_37 = 0;
    int zT_39;
    unsigned int zT_40;
    zT_3D7259E2_SymbolRegistry* zT_41;
    unsigned int zT_42;
    zT_3D7259E2_SymbolRegistry* zT_46;
    unsigned int zT_48;
    zT_D4761958_Opt_858 zT_51 = {0};
    unsigned char zT_52;
    unsigned short zT_54;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_DA663F79_ComptimeEval* zT_66;
    unsigned int zT_67;
    zT_BAEE192E_Opt_10 zT_69 = {0};
    unsigned char zT_70;
    zT_338B7C76_TypeRegistry* zT_72;
    unsigned int zT_73;
    unsigned char zT_75 = 0;
    zT_338B7C76_TypeRegistry* zT_76;
    unsigned int zT_77;
    unsigned char zT_79 = 0;
    int zT_80;
    unsigned int zT_82;
    zT_8143F551_AstKind zT_83;
    zT_79FAE712_u64 zT_88;
    zT_8143F551_AstKind zT_91;
    zT_8143F551_AstKind zT_97;
    unsigned int zT_102;
    unsigned int zT_103;
    zT_DA663F79_ComptimeEval* zT_106;
    unsigned int zT_107;
    zT_6B0A7D14_AstStore* zT_108;
    unsigned int zT_109;
    unsigned int zT_113 = 0;
    zT_BAEE192E_Opt_10 zT_114 = {0};
    unsigned char zT_115;
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int zT_118;
    unsigned char zT_120 = 0;
    zT_338B7C76_TypeRegistry* zT_121;
    unsigned int zT_122;
    unsigned char zT_124 = 0;
    unsigned char zT_125;
    unsigned int idx;
    unsigned int guard;
    zT_22A7C88B_AstNode wn;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int mi;
    zT_D4761958_Opt_858 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    zT_BAEE192E_Opt_10 dt;
    unsigned int t;
    zT_BAEE192E_Opt_10 dt2;
    unsigned int t2;
    idx = node_idx;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    guard = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(guard < (unsigned int)(32))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = self->store;
    zT_11 = idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    wn = zT_13;
    zT_14 = wn.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_24 = self->store;
    zT_25 = idx;
    zT_27 = zF_FCDD1D35_astStoreNodeAt(zT_24, zT_25);
    node = zT_27;
    zT_28 = node.kind;
    if ((unsigned char)(zT_28 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_10;
    z_bb_4:
    zT_20 = 1;
    zT_22 = guard + (unsigned int)((unsigned int)zT_20);
    guard = zT_22;
    goto z_bb_1;
    z_bb_5:
    zT_19 = wn.child_0;
    idx = zT_19;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    goto z_bb_3;
    z_bb_8:
    zT_34 = self->store;
    zT_35 = idx;
    zT_37 = zF_53458827_astStoreIdentifier(zT_34, zT_35);
    name_id = zT_37;
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    mi = zT_40;
    goto z_bb_11;
    z_bb_9:
    zT_125 = cv.sig;
    return zT_125;
    z_bb_10:
    zT_83 = node.kind;
    if ((unsigned char)(zT_83 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_23; else goto z_bb_25;
    z_bb_11:
    zT_41 = self->symbol_reg;
    zT_42 = zT_41->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_42))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_46 = self->symbol_reg;
    zT_48 = name_id;
    zT_51 = zF_A398987E_symbolRegistryQuali(zT_46, (unsigned int)((unsigned int)mi), zT_48);
    c_sym = zT_51;
    zT_52 = c_sym.has_value;
    if (zT_52) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    goto z_bb_9;
    z_bb_14:
    zT_80 = 1;
    zT_82 = mi + (unsigned int)((unsigned int)zT_80);
    mi = zT_82;
    goto z_bb_11;
    z_bb_15:
    cs = c_sym.value;
    zT_54 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_54 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_60 = self->store;
    zT_61 = cs->decl_node;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_60, zT_61);
    c_decl = zT_64;
    zT_66 = self;
    zT_67 = c_decl.child_0;
    zT_69 = zF_BAD6BA5D_comptimeEvalResolve(zT_66, zT_67);
    dt = zT_69;
    zT_70 = dt.has_value;
    if (zT_70) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    goto z_bb_16;
    z_bb_19:
    t = dt.value;
    zT_72 = self->registry;
    zT_73 = t;
    zT_75 = zF_3290E9C4_typeRegistryIsInteg(zT_72, zT_73);
    if (zT_75) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    zT_76 = self->registry;
    zT_77 = t;
    zT_79 = zF_01ED6537_typeRegistryIntIsSi(zT_76, zT_77);
    return zT_79;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_88 = cv.bits;
    return (unsigned char)(zT_88 <= (zT_79FAE712_u64)(9223372036854775807ULL));
    z_bb_24:
    goto z_bb_9;
    z_bb_25:
    zT_91 = node.kind;
    if ((unsigned char)(zT_91 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    return (unsigned char)(0);
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_97 = node.kind;
    if ((unsigned char)(zT_97 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_102 = node.child_0;
    zT_103 = self->int_cast_id;
    if ((unsigned char)(zT_102 == zT_103)) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_106 = self;
    zT_108 = self->store;
    zT_109 = idx;
    zT_113 = zF_B10B1BC1_astStoreNodeExtraCh(zT_108, zT_109, (unsigned int)(0));
    zT_107 = zT_113;
    zT_114 = zF_BAD6BA5D_comptimeEvalResolve(zT_106, zT_107);
    dt2 = zT_114;
    zT_115 = dt2.has_value;
    if (zT_115) goto z_bb_33; else goto z_bb_34;
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    t2 = dt2.value;
    zT_117 = self->registry;
    zT_118 = t2;
    zT_120 = zF_3290E9C4_typeRegistryIsInteg(zT_117, zT_118);
    if (zT_120) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_121 = self->registry;
    zT_122 = t2;
    zT_124 = zF_01ED6537_typeRegistryIntIsSi(zT_121, zT_122);
    return zT_124;
    z_bb_36:
    goto z_bb_34;
}

/* comptimeEvalFloatBuiltin */
zT_BCEE1C54_Opt_16 zF_8C4B1954_comptimeEvalFloatBu(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_DA663F79_ComptimeEval* zT_9;
    unsigned int zT_10;
    zT_6B0A7D14_AstStore* zT_11;
    unsigned int zT_12;
    unsigned int zT_16 = 0;
    zT_BAEE192E_Opt_10 zT_17 = {0};
    unsigned char zT_18;
    unsigned char zT_22;
    zT_BCEE1C54_Opt_16 zT_25 = {0};
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_32 = 0;
    double zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    zT_DA663F79_ComptimeEval* zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    zT_E33A227C_Opt_201 zT_42 = {0};
    unsigned char zT_43;
    unsigned int zT_45;
    zT_BCEE1C54_Opt_16 zT_48 = {0};
    zT_DA663F79_ComptimeEval* zT_49;
    unsigned int zT_50;
    zT_89B1DDDA_ComptimeVal zT_51;
    unsigned char zT_52 = 0;
    zT_79FAE712_u64 zT_54;
    zT_C69B2266_i64 zT_55;
    double zT_56;
    zT_79FAE712_u64 zT_57;
    double zT_58;
    zT_BCEE1C54_Opt_16 zT_59 = {0};
    unsigned int zT_60;
    unsigned int zT_61;
    zT_DA663F79_ComptimeEval* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_BCEE1C54_Opt_16 zT_67 = {0};
    unsigned char zT_68;
    zT_BCEE1C54_Opt_16 zT_70 = {0};
    zT_BCEE1C54_Opt_16 zT_71 = {0};
    float zT_75;
    double zT_76;
    zT_BCEE1C54_Opt_16 zT_77;
    zT_BCEE1C54_Opt_16 zT_78;
    zT_BCEE1C54_Opt_16 zT_79 = {0};
    zT_22A7C88B_AstNode node;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    unsigned int inner_idx;
    double fv;
    zT_E33A227C_Opt_201 iv;
    zT_89B1DDDA_ComptimeVal cv;
    zT_C69B2266_i64 sv;
    zT_BCEE1C54_Opt_16 xv;
    double x;
    float f32v;
    zT_4 = self->store;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    zT_9 = self;
    zT_11 = self->store;
    zT_12 = node_idx;
    zT_16 = zF_B10B1BC1_astStoreNodeExtraCh(zT_11, zT_12, (unsigned int)(0));
    zT_10 = zT_16;
    zT_17 = zF_BAD6BA5D_comptimeEvalResolve(zT_9, zT_10);
    tid = zT_17;
    zT_18 = tid.has_value;
    if (zT_18) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    t = tid.value;
    if ((unsigned char)(t != (unsigned int)(15))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_79.has_value = 0;
    return zT_79;
    z_bb_3:
    zT_22 = t != (unsigned int)(16);
    goto z_bb_5;
    z_bb_4:
    zT_22 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_22) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_25.has_value = 0;
    return zT_25;
    z_bb_7:
    zT_27 = self->store;
    zT_28 = node_idx;
    zT_32 = zF_B10B1BC1_astStoreNodeExtraCh(zT_27, zT_28, (unsigned int)(1));
    inner_idx = zT_32;
    zT_34 = 0;
    fv = zT_34;
    zT_35 = node.child_0;
    zT_36 = self->int_to_float_id;
    if ((unsigned char)(zT_35 == zT_36)) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_39 = self;
    zT_40 = inner_idx;
    zT_41 = depth;
    zT_42 = zF_4EE17137_comptimeEvalEvaluat(zT_39, zT_40, zT_41);
    iv = zT_42;
    zT_43 = iv.has_value;
    if (zT_43) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    if ((unsigned char)(t == (unsigned int)(15))) goto z_bb_25; else goto z_bb_26;
    z_bb_10:
    zT_60 = node.child_0;
    zT_61 = self->float_cast_id;
    if ((unsigned char)(zT_60 == zT_61)) goto z_bb_19; else goto z_bb_21;
    z_bb_11:
    cv = iv.value;
    zT_45 = cv.width_bits;
    if ((unsigned char)(zT_45 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_59.has_value = 0;
    return zT_59;
    z_bb_14:
    zT_48.has_value = 0;
    return zT_48;
    z_bb_15:
    zT_49 = self;
    zT_50 = inner_idx;
    zT_51 = cv;
    zT_52 = zF_0D60B956_comptimeEvalOperand(zT_49, zT_50, zT_51);
    if (zT_52) goto z_bb_16; else goto z_bb_18;
    z_bb_16:
    zT_54 = cv.bits;
    zT_55 = (zT_C69B2266_i64)zT_54;
    sv = zT_55;
    zT_56 = (double)sv;
    fv = zT_56;
    goto z_bb_17;
    z_bb_17:
    goto z_bb_12;
    z_bb_18:
    zT_57 = cv.bits;
    zT_58 = (double)zT_57;
    fv = zT_58;
    goto z_bb_17;
    z_bb_19:
    zT_64 = self;
    zT_65 = inner_idx;
    zT_66 = depth;
    zT_67 = zF_B719EB81_comptimeEvalFloat(zT_64, zT_65, zT_66);
    xv = zT_67;
    zT_68 = xv.has_value;
    if (zT_68) goto z_bb_22; else goto z_bb_24;
    z_bb_20:
    goto z_bb_9;
    z_bb_21:
    zT_71.has_value = 0;
    return zT_71;
    z_bb_22:
    x = xv.value;
    fv = x;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    zT_70.has_value = 0;
    return zT_70;
    z_bb_25:
    zT_75 = (float)fv;
    f32v = zT_75;
    zT_76 = (double)f32v;
    zT_77.has_value = 1;
    zT_77.value = zT_76;
    return zT_77;
    z_bb_26:
    zT_78.has_value = 1;
    zT_78.value = fv;
    return zT_78;
}

/* comptimeEvalEvaluate */
zT_E33A227C_Opt_201 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    zT_E33A227C_Opt_201 zT_6 = {0};
    zT_2 = self;
    zT_3 = node_idx;
    zT_6 = zF_4EE17137_comptimeEvalEvaluat(zT_2, zT_3, (unsigned int)(0));
    return zT_6;
}

/* comptimeEvalEvaluateDepth */
zT_E33A227C_Opt_201 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_E33A227C_Opt_201 zT_5 = {0};
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_89B1DDDA_ComptimeVal zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_79FAE712_u64 zT_20 = 0;
    unsigned int zT_21;
    unsigned char zT_22;
    zT_E33A227C_Opt_201 zT_23;
    zT_8143F551_AstKind zT_24;
    zT_89B1DDDA_ComptimeVal zT_29;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_79FAE712_u64 zT_33 = 0;
    unsigned int zT_34;
    unsigned char zT_35;
    zT_E33A227C_Opt_201 zT_36;
    zT_8143F551_AstKind zT_37;
    unsigned char zT_42;
    zT_89B1DDDA_ComptimeVal zT_47;
    zT_79FAE712_u64 zT_48;
    unsigned int zT_49;
    unsigned char zT_50;
    zT_E33A227C_Opt_201 zT_51;
    zT_89B1DDDA_ComptimeVal zT_52;
    zT_79FAE712_u64 zT_53;
    unsigned int zT_54;
    unsigned char zT_55;
    zT_E33A227C_Opt_201 zT_56;
    zT_8143F551_AstKind zT_57;
    zT_DA663F79_ComptimeEval* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_E33A227C_Opt_201 zT_67 = {0};
    unsigned char zT_68;
    unsigned int zT_70;
    zT_E33A227C_Opt_201 zT_73 = {0};
    zT_79FAE712_u64 zT_76;
    zT_79FAE712_u64 zT_77;
    unsigned int zT_78;
    unsigned int zT_82;
    zT_89B1DDDA_ComptimeVal zT_85;
    unsigned char zT_86;
    zT_E33A227C_Opt_201 zT_87;
    zT_79FAE712_u64 zT_93;
    zT_79FAE712_u64 zT_95;
    unsigned char zT_96;
    unsigned char zT_97;
    zT_79FAE712_u64 zT_110;
    zT_79FAE712_u64 zT_111;
    zT_89B1DDDA_ComptimeVal zT_112;
    unsigned char zT_113;
    zT_E33A227C_Opt_201 zT_114;
    zT_89B1DDDA_ComptimeVal zT_115;
    unsigned int zT_116;
    unsigned char zT_117;
    zT_E33A227C_Opt_201 zT_118;
    zT_E33A227C_Opt_201 zT_119 = {0};
    zT_8143F551_AstKind zT_120;
    zT_DA663F79_ComptimeEval* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    zT_E33A227C_Opt_201 zT_130 = {0};
    unsigned char zT_131;
    unsigned int zT_133;
    zT_E33A227C_Opt_201 zT_136 = {0};
    zT_79FAE712_u64 zT_138;
    zT_79FAE712_u64 zT_139;
    zT_89B1DDDA_ComptimeVal zT_140;
    unsigned int zT_141;
    unsigned char zT_142;
    zT_E33A227C_Opt_201 zT_143;
    zT_E33A227C_Opt_201 zT_144 = {0};
    zT_8143F551_AstKind zT_145;
    unsigned char zT_150;
    zT_8143F551_AstKind zT_151;
    unsigned char zT_156;
    zT_8143F551_AstKind zT_157;
    unsigned char zT_162;
    zT_8143F551_AstKind zT_163;
    unsigned char zT_168;
    zT_8143F551_AstKind zT_169;
    unsigned char zT_174;
    zT_8143F551_AstKind zT_175;
    unsigned char zT_180;
    zT_8143F551_AstKind zT_181;
    unsigned char zT_186;
    zT_8143F551_AstKind zT_187;
    unsigned char zT_192;
    zT_8143F551_AstKind zT_193;
    unsigned char zT_198;
    zT_8143F551_AstKind zT_199;
    zT_DA663F79_ComptimeEval* zT_204;
    unsigned int zT_205;
    zT_8143F551_AstKind zT_206;
    unsigned int zT_207;
    zT_E33A227C_Opt_201 zT_209 = {0};
    zT_8143F551_AstKind zT_210;
    zT_DA663F79_ComptimeEval* zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    zT_E33A227C_Opt_201 zT_218 = {0};
    zT_8143F551_AstKind zT_219;
    zT_DA663F79_ComptimeEval* zT_224;
    unsigned int zT_226;
    unsigned int zT_227;
    zT_8143F551_AstKind zT_229;
    zT_E33A227C_Opt_201 zT_236 = {0};
    zT_6B0A7D14_AstStore* zT_238;
    unsigned int zT_239;
    unsigned int zT_241 = 0;
    int zT_243;
    unsigned int zT_244;
    zT_3D7259E2_SymbolRegistry* zT_245;
    unsigned int zT_246;
    zT_3D7259E2_SymbolRegistry* zT_250;
    unsigned int zT_252;
    zT_D4761958_Opt_858 zT_255 = {0};
    unsigned char zT_256;
    unsigned short zT_258;
    zT_6B0A7D14_AstStore* zT_264;
    unsigned int zT_265;
    zT_22A7C88B_AstNode zT_268 = {0};
    unsigned int zT_269;
    zT_DA663F79_ComptimeEval* zT_272;
    unsigned int zT_275;
    unsigned int zT_277;
    int zT_279;
    unsigned int zT_281;
    zT_E33A227C_Opt_201 zT_282 = {0};
    zT_E33A227C_Opt_201 zT_283 = {0};
    zT_22A7C88B_AstNode node;
    zT_E33A227C_Opt_201 inner;
    zT_89B1DDDA_ComptimeVal cv;
    zT_79FAE712_u64 nv;
    unsigned int wb;
    zT_79FAE712_u64 mask;
    zT_79FAE712_u64 masked;
    zT_79FAE712_u64 not_mask;
    zT_E33A227C_Opt_201 bnv;
    zT_89B1DDDA_ComptimeVal bv;
    zT_79FAE712_u64 bnb;
    unsigned int name_id;
    unsigned int mi;
    zT_D4761958_Opt_858 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_11 = node.kind;
    if ((unsigned char)(zT_11 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_17 = self->store;
    zT_18 = node_idx;
    zT_20 = zF_678B9A72_astStoreIntValue(zT_17, zT_18);
    zT_16.bits = zT_20;
    zT_21 = 0;
    zT_16.width_bits = zT_21;
    zT_22 = 1;
    zT_16.sig = zT_22;
    zT_23.has_value = 1;
    zT_23.value = zT_16;
    return zT_23;
    z_bb_4:
    { zT_E33A227C_Opt_201 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_5:
    zT_24 = node.kind;
    if ((unsigned char)(zT_24 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal))) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_30 = self->store;
    zT_31 = node_idx;
    zT_33 = zF_678B9A72_astStoreIntValue(zT_30, zT_31);
    zT_29.bits = zT_33;
    zT_34 = 8;
    zT_29.width_bits = zT_34;
    zT_35 = 0;
    zT_29.sig = zT_35;
    zT_36.has_value = 1;
    zT_36.value = zT_29;
    return zT_36;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = node.kind;
    if ((unsigned char)(zT_37 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bool_literal))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_42 = node.flags;
    if ((unsigned char)((unsigned char)(zT_42 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_57 = node.kind;
    if ((unsigned char)(zT_57 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_14; else goto z_bb_16;
    z_bb_12:
    zT_48 = 1;
    zT_47.bits = zT_48;
    zT_49 = 1;
    zT_47.width_bits = zT_49;
    zT_50 = 0;
    zT_47.sig = zT_50;
    zT_51.has_value = 1;
    zT_51.value = zT_47;
    return zT_51;
    z_bb_13:
    zT_53 = 0;
    zT_52.bits = zT_53;
    zT_54 = 1;
    zT_52.width_bits = zT_54;
    zT_55 = 0;
    zT_52.sig = zT_55;
    zT_56.has_value = 1;
    zT_56.value = zT_52;
    return zT_56;
    z_bb_14:
    zT_63 = self;
    zT_64 = node.child_0;
    zT_65 = depth;
    zT_67 = zF_4EE17137_comptimeEvalEvaluat(zT_63, zT_64, zT_65);
    inner = zT_67;
    zT_68 = inner.has_value;
    if (zT_68) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_120 = node.kind;
    if ((unsigned char)(zT_120 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_not))) goto z_bb_30; else goto z_bb_32;
    z_bb_17:
    cv = inner.value;
    zT_70 = cv.width_bits;
    if ((unsigned char)(zT_70 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_119.has_value = 0;
    return zT_119;
    z_bb_19:
    zT_73.has_value = 0;
    return zT_73;
    z_bb_20:
    zT_76 = cv.bits;
    zT_77 = (zT_79FAE712_u64)(0) - zT_76;
    nv = zT_77;
    zT_78 = cv.width_bits;
    if ((unsigned char)(zT_78 != (unsigned int)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_82 = cv.width_bits;
    wb = zT_82;
    if ((unsigned char)(wb >= (unsigned int)(64))) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    zT_115.bits = nv;
    zT_116 = 0;
    zT_115.width_bits = zT_116;
    zT_117 = 1;
    zT_115.sig = zT_117;
    zT_118.has_value = 1;
    zT_118.value = zT_115;
    return zT_118;
    z_bb_23:
    zT_85.bits = nv;
    zT_85.width_bits = wb;
    zT_86 = cv.sig;
    zT_85.sig = zT_86;
    zT_87.has_value = 1;
    zT_87.value = zT_85;
    return zT_87;
    z_bb_24:
    zT_93 = (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)wb)) - (zT_79FAE712_u64)(1);
    mask = zT_93;
    zT_95 = nv & mask;
    masked = zT_95;
    zT_96 = cv.sig;
    if (zT_96) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_97 = (zT_79FAE712_u64)(nv & (zT_79FAE712_u64)((zT_79FAE712_u64)(1) << (zT_79FAE712_u64)((zT_79FAE712_u64)(unsigned int)(wb - (unsigned int)(1))))) != (zT_79FAE712_u64)(0);
    goto z_bb_27;
    z_bb_26:
    zT_97 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_97) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_110 = (zT_79FAE712_u64)((zT_79FAE712_u64)(0) - mask) - (zT_79FAE712_u64)(1);
    not_mask = zT_110;
    zT_111 = nv | not_mask;
    masked = zT_111;
    goto z_bb_29;
    z_bb_29:
    zT_112.bits = masked;
    zT_112.width_bits = wb;
    zT_113 = cv.sig;
    zT_112.sig = zT_113;
    zT_114.has_value = 1;
    zT_114.value = zT_112;
    return zT_114;
    z_bb_30:
    zT_126 = self;
    zT_127 = node.child_0;
    zT_128 = depth;
    zT_130 = zF_4EE17137_comptimeEvalEvaluat(zT_126, zT_127, zT_128);
    bnv = zT_130;
    zT_131 = bnv.has_value;
    if (zT_131) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_15;
    z_bb_32:
    zT_145 = node.kind;
    if ((unsigned char)(zT_145 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_38; else goto z_bb_37;
    z_bb_33:
    bv = bnv.value;
    zT_133 = bv.width_bits;
    if ((unsigned char)(zT_133 == zG_9D6D351A_WIDTH_FLOAT)) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    zT_144.has_value = 0;
    return zT_144;
    z_bb_35:
    zT_136.has_value = 0;
    return zT_136;
    z_bb_36:
    zT_138 = bv.bits;
    zT_139 = ~zT_138;
    bnb = zT_139;
    zT_140.bits = bnb;
    zT_141 = bv.width_bits;
    zT_140.width_bits = zT_141;
    zT_142 = 0;
    zT_140.sig = zT_142;
    zT_143.has_value = 1;
    zT_143.value = zT_140;
    return zT_143;
    z_bb_37:
    zT_151 = node.kind;
    zT_150 = zT_151 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_39;
    z_bb_38:
    zT_150 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_150) goto z_bb_41; else goto z_bb_40;
    z_bb_40:
    zT_157 = node.kind;
    zT_156 = zT_157 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_42;
    z_bb_41:
    zT_156 = 1;
    goto z_bb_42;
    z_bb_42:
    if (zT_156) goto z_bb_44; else goto z_bb_43;
    z_bb_43:
    zT_163 = node.kind;
    zT_162 = zT_163 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_45;
    z_bb_44:
    zT_162 = 1;
    goto z_bb_45;
    z_bb_45:
    if (zT_162) goto z_bb_47; else goto z_bb_46;
    z_bb_46:
    zT_169 = node.kind;
    zT_168 = zT_169 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_48;
    z_bb_47:
    zT_168 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_168) goto z_bb_50; else goto z_bb_49;
    z_bb_49:
    zT_175 = node.kind;
    zT_174 = zT_175 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_51;
    z_bb_50:
    zT_174 = 1;
    goto z_bb_51;
    z_bb_51:
    if (zT_174) goto z_bb_53; else goto z_bb_52;
    z_bb_52:
    zT_181 = node.kind;
    zT_180 = zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_54;
    z_bb_53:
    zT_180 = 1;
    goto z_bb_54;
    z_bb_54:
    if (zT_180) goto z_bb_56; else goto z_bb_55;
    z_bb_55:
    zT_187 = node.kind;
    zT_186 = zT_187 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_57;
    z_bb_56:
    zT_186 = 1;
    goto z_bb_57;
    z_bb_57:
    if (zT_186) goto z_bb_59; else goto z_bb_58;
    z_bb_58:
    zT_193 = node.kind;
    zT_192 = zT_193 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_60;
    z_bb_59:
    zT_192 = 1;
    goto z_bb_60;
    z_bb_60:
    if (zT_192) goto z_bb_62; else goto z_bb_61;
    z_bb_61:
    zT_199 = node.kind;
    zT_198 = zT_199 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_63;
    z_bb_62:
    zT_198 = 1;
    goto z_bb_63;
    z_bb_63:
    if (zT_198) goto z_bb_64; else goto z_bb_66;
    z_bb_64:
    zT_204 = self;
    zT_205 = node_idx;
    zT_206 = node.kind;
    zT_207 = depth;
    zT_209 = zF_B36A4A25_comptimeEvalBinOp(zT_204, zT_205, zT_206, zT_207);
    return zT_209;
    z_bb_65:
    goto z_bb_31;
    z_bb_66:
    zT_210 = node.kind;
    if ((unsigned char)(zT_210 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_67; else goto z_bb_69;
    z_bb_67:
    zT_215 = self;
    zT_216 = node_idx;
    zT_217 = depth;
    zT_218 = zF_C37A1F7C_comptimeEvalBuiltin(zT_215, zT_216, zT_217);
    return zT_218;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    zT_219 = node.kind;
    if ((unsigned char)(zT_219 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_70; else goto z_bb_72;
    z_bb_70:
    zT_224 = self;
    zT_227 = node.child_0;
    zT_226 = depth;
    self = zT_224;
    node_idx = zT_227;
    depth = zT_226;
    goto z_bb_0;
    z_bb_71:
    goto z_bb_68;
    z_bb_72:
    zT_229 = node.kind;
    if ((unsigned char)(zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    if ((unsigned char)(depth >= (unsigned int)(16))) goto z_bb_76; else goto z_bb_77;
    goto z_bb_71;
    z_bb_75:
    zT_283.has_value = 0;
    return zT_283;
    z_bb_76:
    zT_236.has_value = 0;
    return zT_236;
    z_bb_77:
    zT_238 = self->store;
    zT_239 = node_idx;
    zT_241 = zF_53458827_astStoreIdentifier(zT_238, zT_239);
    name_id = zT_241;
    zT_243 = 0;
    zT_244 = (unsigned int)zT_243;
    mi = zT_244;
    goto z_bb_78;
    z_bb_78:
    zT_245 = self->symbol_reg;
    zT_246 = zT_245->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_246))) goto z_bb_79; else goto z_bb_80;
    z_bb_79:
    zT_250 = self->symbol_reg;
    zT_252 = name_id;
    zT_255 = zF_A398987E_symbolRegistryQuali(zT_250, (unsigned int)((unsigned int)mi), zT_252);
    c_sym = zT_255;
    zT_256 = c_sym.has_value;
    if (zT_256) goto z_bb_82; else goto z_bb_83;
    z_bb_80:
    zT_282.has_value = 0;
    return zT_282;
    z_bb_81:
    zT_279 = 1;
    zT_281 = mi + (unsigned int)((unsigned int)zT_279);
    mi = zT_281;
    goto z_bb_78;
    z_bb_82:
    cs = c_sym.value;
    zT_258 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_258 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    goto z_bb_81;
    z_bb_84:
    zT_264 = self->store;
    zT_265 = cs->decl_node;
    zT_268 = zF_FCDD1D35_astStoreNodeAt(zT_264, zT_265);
    c_decl = zT_268;
    zT_269 = c_decl.child_1;
    if ((unsigned char)(zT_269 != (unsigned int)(0))) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    goto z_bb_83;
    z_bb_86:
    zT_272 = self;
    zT_275 = c_decl.child_1;
    zT_277 = depth + (unsigned int)(1);
    self = zT_272;
    node_idx = zT_275;
    depth = zT_277;
    goto z_bb_0;
    z_bb_87:
    goto z_bb_85;
}

/* __module_init */
void zF_780653D2___module_init_18(void) {
    zG_9D6D351A_WIDTH_FLOAT = (unsigned int)(4294967295u);
    return;
}

/* EOF */
