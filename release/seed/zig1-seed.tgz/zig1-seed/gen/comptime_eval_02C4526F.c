#include "comptime_eval_02C4526F.h"
/* comptimeEvalInit */
zT_DA663F79_ComptimeEval zF_6D84C2E7_comptimeEvalInit(zT_338B7C76_TypeRegistry* registry, zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, zT_3D7259E2_SymbolRegistry* symbol_reg) {
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_D3EB6303_StringInterner* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    zT_D3EB6303_StringInterner* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23 = 0;
    zT_D3EB6303_StringInterner* zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27 = 0;
    char* zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31;
    char* zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35;
    char* zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_D3EB6303_StringInterner* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    unsigned int zT_43 = 0;
    zT_D3EB6303_StringInterner* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    zT_D3EB6303_StringInterner* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51 = 0;
    char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    zT_D3EB6303_StringInterner* zT_57;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_59 = 0;
    zT_DA663F79_ComptimeEval zT_60;
    int zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    unsigned int size_id;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int off_id;
    unsigned int bitsz_id;
    unsigned int bitoff_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_iw;
    unsigned int iw_id;
    zT_5 = "@sizeOf";
    zT_7 = 7;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    s_size = zT_6;
    s_size = zT_6;
    s_size = zT_6;
    zT_9 = "@alignOf";
    zT_11 = 8;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    s_align = zT_10;
    s_align = zT_10;
    s_align = zT_10;
    zT_13 = "@intCast";
    zT_15 = 8;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    s_intc = zT_14;
    s_intc = zT_14;
    s_intc = zT_14;
    zT_17 = interner;
    zT_18 = s_intc;
    zT_19 = zF_50C274AF_stringInternerInter(zT_17, zT_18);
    intc_id = zT_19;
    intc_id = zT_19;
    intc_id = zT_19;
    zT_21 = interner;
    zT_22 = s_size;
    zT_23 = zF_50C274AF_stringInternerInter(zT_21, zT_22);
    size_id = zT_23;
    size_id = zT_23;
    size_id = zT_23;
    zT_25 = interner;
    zT_26 = s_align;
    zT_27 = zF_50C274AF_stringInternerInter(zT_25, zT_26);
    align_id = zT_27;
    align_id = zT_27;
    align_id = zT_27;
    zT_29 = "@offsetOf";
    zT_31 = 9;
    zT_30.ptr = zT_29;
    zT_30.len = zT_31;
    s_off = zT_30;
    s_off = zT_30;
    s_off = zT_30;
    zT_33 = "@bitSizeOf";
    zT_35 = 10;
    zT_34.ptr = zT_33;
    zT_34.len = zT_35;
    s_bitsz = zT_34;
    s_bitsz = zT_34;
    s_bitsz = zT_34;
    zT_37 = "@bitOffsetOf";
    zT_39 = 12;
    zT_38.ptr = zT_37;
    zT_38.len = zT_39;
    s_bitoff = zT_38;
    s_bitoff = zT_38;
    s_bitoff = zT_38;
    zT_41 = interner;
    zT_42 = s_off;
    zT_43 = zF_50C274AF_stringInternerInter(zT_41, zT_42);
    off_id = zT_43;
    off_id = zT_43;
    off_id = zT_43;
    zT_45 = interner;
    zT_46 = s_bitsz;
    zT_47 = zF_50C274AF_stringInternerInter(zT_45, zT_46);
    bitsz_id = zT_47;
    bitsz_id = zT_47;
    bitsz_id = zT_47;
    zT_49 = interner;
    zT_50 = s_bitoff;
    zT_51 = zF_50C274AF_stringInternerInter(zT_49, zT_50);
    bitoff_id = zT_51;
    bitoff_id = zT_51;
    bitoff_id = zT_51;
    zT_53 = "@isWindows";
    zT_55 = 10;
    zT_54.ptr = zT_53;
    zT_54.len = zT_55;
    s_iw = zT_54;
    s_iw = zT_54;
    s_iw = zT_54;
    zT_57 = interner;
    zT_58 = s_iw;
    zT_59 = zF_50C274AF_stringInternerInter(zT_57, zT_58);
    iw_id = zT_59;
    iw_id = zT_59;
    iw_id = zT_59;
    zT_60.registry = registry;
    zT_60.store = store;
    zT_60.interner = interner;
    zT_60.symbol_reg = symbol_reg;
    zT_60.size_of_id = size_id;
    zT_60.align_of_id = align_id;
    zT_60.int_cast_id = intc_id;
    zT_60.offset_of_id = off_id;
    zT_60.bit_size_of_id = bitsz_id;
    zT_60.bit_offset_of_id = bitoff_id;
    zT_60.is_windows_id = iw_id;
    zT_61 = 0;
    zT_60.host_is_windows = zT_61;
    return zT_60;
}

/* comptimeEvalBinOp */
zT_4DBDE173_Opt_187 zF_B36A4A25_comptimeEvalBinOp(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, zT_8143F551_AstKind op_kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_DA663F79_ComptimeEval* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_4DBDE173_Opt_187 zT_14 = {0};
    zT_DA663F79_ComptimeEval* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_4DBDE173_Opt_187 zT_20 = {0};
    unsigned char zT_21;
    unsigned char zT_23;
    zT_79FAE712_u64 zT_26;
    zT_79FAE712_u64 zT_28;
    int zT_30;
    int zT_31;
    int zT_32;
    unsigned int zT_34;
    unsigned int zT_35;
    int zT_36;
    unsigned int zT_37;
    zT_8143F551_AstKind zT_40;
    int zT_41;
    zT_89B1DDDA_ComptimeVal zT_42;
    zT_79FAE712_u64 zT_43;
    zT_4DBDE173_Opt_187 zT_44;
    zT_8143F551_AstKind zT_47;
    int zT_48;
    zT_89B1DDDA_ComptimeVal zT_49;
    zT_79FAE712_u64 zT_50;
    zT_4DBDE173_Opt_187 zT_51;
    zT_8143F551_AstKind zT_54;
    int zT_55;
    zT_89B1DDDA_ComptimeVal zT_56;
    zT_79FAE712_u64 zT_57;
    zT_4DBDE173_Opt_187 zT_58;
    zT_8143F551_AstKind zT_61;
    int zT_62;
    zT_79FAE712_u64 zT_63;
    int zT_64;
    zT_4DBDE173_Opt_187 zT_65 = {0};
    zT_79FAE712_u64 zT_67;
    zT_79FAE712_u64 zT_68;
    zT_79FAE712_u64 zT_69;
    zT_79FAE712_u64 zT_70;
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    zT_79FAE712_u64 zT_74;
    zT_79FAE712_u64 zT_75;
    zT_79FAE712_u64 zT_77 = 0;
    zT_79FAE712_u64 zT_79 = 0;
    zT_79FAE712_u64 zT_80;
    int zT_81;
    zT_79FAE712_u64 zT_82;
    zT_79FAE712_u64 zT_83;
    zT_79FAE712_u64 zT_84;
    int zT_85;
    zT_79FAE712_u64 zT_86;
    zT_79FAE712_u64 zT_87;
    zT_79FAE712_u64 zT_89;
    int zT_90;
    zT_79FAE712_u64 zT_91;
    zT_79FAE712_u64 zT_92;
    zT_89B1DDDA_ComptimeVal zT_93;
    int zT_94;
    zT_4DBDE173_Opt_187 zT_95;
    zT_89B1DDDA_ComptimeVal zT_96;
    zT_79FAE712_u64 zT_97;
    int zT_98;
    zT_4DBDE173_Opt_187 zT_99;
    zT_8143F551_AstKind zT_102;
    int zT_103;
    zT_79FAE712_u64 zT_104;
    int zT_105;
    zT_4DBDE173_Opt_187 zT_106 = {0};
    zT_79FAE712_u64 zT_108;
    zT_79FAE712_u64 zT_109;
    zT_79FAE712_u64 zT_110;
    zT_79FAE712_u64 zT_111;
    zT_79FAE712_u64 zT_113;
    zT_79FAE712_u64 zT_114;
    zT_79FAE712_u64 zT_115;
    zT_79FAE712_u64 zT_116;
    zT_79FAE712_u64 zT_118 = 0;
    zT_79FAE712_u64 zT_120 = 0;
    zT_79FAE712_u64 zT_121;
    int zT_122;
    zT_79FAE712_u64 zT_123;
    zT_79FAE712_u64 zT_124;
    zT_79FAE712_u64 zT_125;
    int zT_126;
    zT_79FAE712_u64 zT_127;
    zT_79FAE712_u64 zT_128;
    zT_79FAE712_u64 zT_130;
    zT_79FAE712_u64 zT_131;
    int zT_132;
    zT_79FAE712_u64 zT_133;
    zT_79FAE712_u64 zT_134;
    zT_89B1DDDA_ComptimeVal zT_135;
    int zT_136;
    zT_4DBDE173_Opt_187 zT_137;
    zT_89B1DDDA_ComptimeVal zT_138;
    zT_79FAE712_u64 zT_139;
    int zT_140;
    zT_4DBDE173_Opt_187 zT_141;
    zT_8143F551_AstKind zT_144;
    int zT_145;
    zT_89B1DDDA_ComptimeVal zT_146;
    zT_79FAE712_u64 zT_147;
    zT_4DBDE173_Opt_187 zT_148;
    zT_8143F551_AstKind zT_151;
    int zT_152;
    zT_89B1DDDA_ComptimeVal zT_153;
    zT_79FAE712_u64 zT_154;
    zT_4DBDE173_Opt_187 zT_155;
    zT_8143F551_AstKind zT_158;
    int zT_159;
    zT_89B1DDDA_ComptimeVal zT_160;
    zT_79FAE712_u64 zT_161;
    zT_4DBDE173_Opt_187 zT_162;
    zT_8143F551_AstKind zT_165;
    int zT_166;
    zT_79FAE712_u64 zT_167;
    int zT_168;
    zT_4DBDE173_Opt_187 zT_169 = {0};
    zT_89B1DDDA_ComptimeVal zT_170;
    zT_79FAE712_u64 zT_171;
    zT_4DBDE173_Opt_187 zT_172;
    zT_8143F551_AstKind zT_175;
    int zT_176;
    zT_79FAE712_u64 zT_177;
    int zT_178;
    zT_4DBDE173_Opt_187 zT_179 = {0};
    zT_89B1DDDA_ComptimeVal zT_180;
    zT_79FAE712_u64 zT_181;
    zT_4DBDE173_Opt_187 zT_182;
    zT_4DBDE173_Opt_187 zT_183 = {0};
    zT_22A7C88B_AstNode node;
    zT_4DBDE173_Opt_187 lhs;
    zT_4DBDE173_Opt_187 rhs;
    zT_89B1DDDA_ComptimeVal l;
    zT_89B1DDDA_ComptimeVal r;
    zT_79FAE712_u64 lv;
    zT_79FAE712_u64 rv;
    int use_signed;
    unsigned int maxw;
    zT_79FAE712_u64 sl;
    zT_79FAE712_u64 sr;
    zT_79FAE712_u64 al;
    zT_79FAE712_u64 ar;
    zT_79FAE712_u64 q;
    zT_79FAE712_u64 rem;
    zT_7 = self->store;
    zT_5 = zT_7;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    node = zT_8;
    node = zT_8;
    zT_10 = self;
    zT_13 = node.child_0;
    zT_11 = zT_13;
    zT_12 = depth;
    zT_14 = zF_4EE17137_comptimeEvalEvaluat(zT_10, zT_11, zT_12);
    lhs = zT_14;
    lhs = zT_14;
    lhs = zT_14;
    zT_16 = self;
    zT_19 = node.child_1;
    zT_17 = zT_19;
    zT_18 = depth;
    zT_20 = zF_4EE17137_comptimeEvalEvaluat(zT_16, zT_17, zT_18);
    rhs = zT_20;
    rhs = zT_20;
    rhs = zT_20;
    zT_21 = lhs.has_value;
    if (zT_21) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    l = lhs.value;
    zT_23 = rhs.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_183.has_value = 0;
    return zT_183;
    z_bb_3:
    r = rhs.value;
    zT_26 = l.bits;
    lv = zT_26;
    lv = zT_26;
    lv = zT_26;
    zT_28 = r.bits;
    rv = zT_28;
    rv = zT_28;
    rv = zT_28;
    zT_30 = l.sig;
    if (zT_30) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_32 = r.sig;
    zT_31 = zT_32;
    goto z_bb_7;
    z_bb_6:
    zT_31 = 1;
    goto z_bb_7;
    z_bb_7:
    use_signed = zT_31;
    use_signed = zT_31;
    use_signed = zT_31;
    zT_34 = l.width_bits;
    maxw = zT_34;
    maxw = zT_34;
    maxw = zT_34;
    zT_35 = r.width_bits;
    zT_36 = zT_35 > maxw;
    if (zT_36) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = r.width_bits;
    maxw = zT_37;
    maxw = zT_37;
    goto z_bb_9;
    z_bb_9:
    zT_40 = zT_8143F551_AstKind_add;
    zT_41 = op_kind == zT_40;
    if (zT_41) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_43 = lv + rv;
    zT_42.bits = zT_43;
    zT_42.width_bits = maxw;
    zT_42.sig = use_signed;
    zT_44.has_value = 1;
    zT_44.value = zT_42;
    return zT_44;
    z_bb_11:
    zT_47 = zT_8143F551_AstKind_sub;
    zT_48 = op_kind == zT_47;
    if (zT_48) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_50 = lv - rv;
    zT_49.bits = zT_50;
    zT_49.width_bits = maxw;
    zT_49.sig = use_signed;
    zT_51.has_value = 1;
    zT_51.value = zT_49;
    return zT_51;
    z_bb_13:
    zT_54 = zT_8143F551_AstKind_mul;
    zT_55 = op_kind == zT_54;
    if (zT_55) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_57 = lv * rv;
    zT_56.bits = zT_57;
    zT_56.width_bits = maxw;
    zT_56.sig = use_signed;
    zT_58.has_value = 1;
    zT_58.value = zT_56;
    return zT_58;
    z_bb_15:
    zT_61 = zT_8143F551_AstKind_div;
    zT_62 = op_kind == zT_61;
    if (zT_62) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_63 = 0;
    zT_64 = rv == zT_63;
    if (zT_64) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_102 = zT_8143F551_AstKind_mod_op;
    zT_103 = op_kind == zT_102;
    if (zT_103) goto z_bb_30; else goto z_bb_31;
    z_bb_18:
    zT_65.has_value = 0;
    return zT_65;
    z_bb_19:
    if (use_signed) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_67 = 63;
    zT_68 = lv >> zT_67;
    zT_69 = 1;
    zT_70 = zT_68 & zT_69;
    sl = zT_70;
    sl = zT_70;
    sl = zT_70;
    zT_72 = 63;
    zT_73 = rv >> zT_72;
    zT_74 = 1;
    zT_75 = zT_73 & zT_74;
    sr = zT_75;
    sr = zT_75;
    sr = zT_75;
    al = zT_77;
    ar = zT_79;
    zT_80 = 1;
    zT_81 = sl == zT_80;
    if (zT_81) goto z_bb_22; else goto z_bb_24;
    z_bb_21:
    zT_97 = lv / rv;
    zT_96.bits = zT_97;
    zT_96.width_bits = maxw;
    zT_98 = 0;
    zT_96.sig = zT_98;
    zT_99.has_value = 1;
    zT_99.value = zT_96;
    return zT_99;
    z_bb_22:
    zT_82 = 0;
    zT_83 = zT_82 - lv;
    al = zT_83;
    al = zT_83;
    goto z_bb_23;
    z_bb_23:
    zT_84 = 1;
    zT_85 = sr == zT_84;
    if (zT_85) goto z_bb_25; else goto z_bb_27;
    z_bb_24:
    al = lv;
    al = lv;
    goto z_bb_23;
    z_bb_25:
    zT_86 = 0;
    zT_87 = zT_86 - rv;
    ar = zT_87;
    ar = zT_87;
    goto z_bb_26;
    z_bb_26:
    zT_89 = al / ar;
    q = zT_89;
    q = zT_89;
    q = zT_89;
    zT_90 = sl != sr;
    if (zT_90) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    ar = rv;
    ar = rv;
    goto z_bb_26;
    z_bb_28:
    zT_91 = 0;
    zT_92 = zT_91 - q;
    q = zT_92;
    q = zT_92;
    goto z_bb_29;
    z_bb_29:
    zT_93.bits = q;
    zT_93.width_bits = maxw;
    zT_94 = 1;
    zT_93.sig = zT_94;
    zT_95.has_value = 1;
    zT_95.value = zT_93;
    return zT_95;
    z_bb_30:
    zT_104 = 0;
    zT_105 = rv == zT_104;
    if (zT_105) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_144 = zT_8143F551_AstKind_bit_and;
    zT_145 = op_kind == zT_144;
    if (zT_145) goto z_bb_44; else goto z_bb_45;
    z_bb_32:
    zT_106.has_value = 0;
    return zT_106;
    z_bb_33:
    if (use_signed) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_108 = 63;
    zT_109 = lv >> zT_108;
    zT_110 = 1;
    zT_111 = zT_109 & zT_110;
    sl = zT_111;
    sl = zT_111;
    sl = zT_111;
    zT_113 = 63;
    zT_114 = rv >> zT_113;
    zT_115 = 1;
    zT_116 = zT_114 & zT_115;
    sr = zT_116;
    sr = zT_116;
    sr = zT_116;
    al = zT_118;
    ar = zT_120;
    zT_121 = 1;
    zT_122 = sl == zT_121;
    if (zT_122) goto z_bb_36; else goto z_bb_38;
    z_bb_35:
    zT_139 = lv % rv;
    zT_138.bits = zT_139;
    zT_138.width_bits = maxw;
    zT_140 = 0;
    zT_138.sig = zT_140;
    zT_141.has_value = 1;
    zT_141.value = zT_138;
    return zT_141;
    z_bb_36:
    zT_123 = 0;
    zT_124 = zT_123 - lv;
    al = zT_124;
    al = zT_124;
    goto z_bb_37;
    z_bb_37:
    zT_125 = 1;
    zT_126 = sr == zT_125;
    if (zT_126) goto z_bb_39; else goto z_bb_41;
    z_bb_38:
    al = lv;
    al = lv;
    goto z_bb_37;
    z_bb_39:
    zT_127 = 0;
    zT_128 = zT_127 - rv;
    ar = zT_128;
    ar = zT_128;
    goto z_bb_40;
    z_bb_40:
    zT_130 = al % ar;
    rem = zT_130;
    rem = zT_130;
    rem = zT_130;
    zT_131 = 1;
    zT_132 = sl == zT_131;
    if (zT_132) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    ar = rv;
    ar = rv;
    goto z_bb_40;
    z_bb_42:
    zT_133 = 0;
    zT_134 = zT_133 - rem;
    rem = zT_134;
    rem = zT_134;
    goto z_bb_43;
    z_bb_43:
    zT_135.bits = rem;
    zT_135.width_bits = maxw;
    zT_136 = 1;
    zT_135.sig = zT_136;
    zT_137.has_value = 1;
    zT_137.value = zT_135;
    return zT_137;
    z_bb_44:
    zT_147 = lv & rv;
    zT_146.bits = zT_147;
    zT_146.width_bits = maxw;
    zT_146.sig = use_signed;
    zT_148.has_value = 1;
    zT_148.value = zT_146;
    return zT_148;
    z_bb_45:
    zT_151 = zT_8143F551_AstKind_bit_or;
    zT_152 = op_kind == zT_151;
    if (zT_152) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    zT_154 = lv | rv;
    zT_153.bits = zT_154;
    zT_153.width_bits = maxw;
    zT_153.sig = use_signed;
    zT_155.has_value = 1;
    zT_155.value = zT_153;
    return zT_155;
    z_bb_47:
    zT_158 = zT_8143F551_AstKind_bit_xor;
    zT_159 = op_kind == zT_158;
    if (zT_159) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_161 = lv ^ rv;
    zT_160.bits = zT_161;
    zT_160.width_bits = maxw;
    zT_160.sig = use_signed;
    zT_162.has_value = 1;
    zT_162.value = zT_160;
    return zT_162;
    z_bb_49:
    zT_165 = zT_8143F551_AstKind_shl;
    zT_166 = op_kind == zT_165;
    if (zT_166) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_167 = 64;
    zT_168 = rv >= zT_167;
    if (zT_168) goto z_bb_52; else goto z_bb_53;
    z_bb_51:
    zT_175 = zT_8143F551_AstKind_shr;
    zT_176 = op_kind == zT_175;
    if (zT_176) goto z_bb_54; else goto z_bb_55;
    z_bb_52:
    zT_169.has_value = 0;
    return zT_169;
    z_bb_53:
    zT_171 = lv << rv;
    zT_170.bits = zT_171;
    zT_170.width_bits = maxw;
    zT_170.sig = use_signed;
    zT_172.has_value = 1;
    zT_172.value = zT_170;
    return zT_172;
    z_bb_54:
    zT_177 = 64;
    zT_178 = rv >= zT_177;
    if (zT_178) goto z_bb_56; else goto z_bb_57;
    z_bb_55:
    goto z_bb_4;
    z_bb_56:
    zT_179.has_value = 0;
    return zT_179;
    z_bb_57:
    zT_181 = lv >> rv;
    zT_180.bits = zT_181;
    zT_180.width_bits = maxw;
    zT_180.sig = use_signed;
    zT_182.has_value = 1;
    zT_182.value = zT_180;
    return zT_182;
}

/* comptimeEvalResolveTypeArg */
zT_BAEE192E_Opt_10 zF_BAD6BA5D_comptimeEvalResolve(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    unsigned int zT_2;
    int zT_3;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_6;
    zT_6B0A7D14_AstStore* zT_7;
    zT_338B7C76_TypeRegistry* zT_8;
    zT_3D7259E2_SymbolRegistry* zT_9;
    zT_D3EB6303_StringInterner* zT_10;
    zT_ABC1EBBE_TypeResolveEnv* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_ABC1EBBE_TypeResolveEnv* zT_16;
    unsigned int zT_17;
    unsigned int zT_18 = 0;
    unsigned int zT_19;
    int zT_20;
    zT_BAEE192E_Opt_10 zT_21 = {0};
    zT_BAEE192E_Opt_10 zT_22;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int tid;
    zT_2 = 0;
    zT_3 = node_idx == zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_7 = self->store;
    zT_6.store = zT_7;
    zT_8 = self->registry;
    zT_6.typereg = zT_8;
    zT_9 = self->symbol_reg;
    zT_6.symbol_reg = zT_9;
    zT_10 = self->interner;
    zT_6.interner = zT_10;
    zT_6.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    env = zT_6;
    env = zT_6;
    env = zT_6;
    zT_16 = &env;
    zT_13 = zT_16;
    zT_14 = node_idx;
    zT_17 = 0;
    zT_15 = zT_17;
    zT_18 = zF_F2107C15_resolveTypeExprFull(zT_13, zT_14, zT_15);
    tid = zT_18;
    tid = zT_18;
    tid = zT_18;
    zT_19 = 18;
    zT_20 = tid == zT_19;
    if (zT_20) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21.has_value = 0;
    return zT_21;
    z_bb_4:
    zT_22.has_value = 1;
    zT_22.value = tid;
    return zT_22;
}

/* comptimeEvalBuiltin */
zT_4DBDE173_Opt_187 zF_C37A1F7C_comptimeEvalBuiltin(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_6B0A7D14_AstStore* zT_6;
    zT_22A7C88B_AstNode zT_7 = {0};
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    zT_6B0A7D14_AstStore* zT_14;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_15 = {0};
    zT_DA663F79_ComptimeEval* zT_17;
    unsigned int zT_18;
    unsigned int* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_BAEE192E_Opt_10 zT_22 = {0};
    unsigned char zT_23;
    zT_338B7C76_TypeRegistry* zT_26;
    zT_D155D06D_Type* zT_27;
    unsigned int zT_28;
    zT_D155D06D_Type zT_29;
    unsigned char zT_30;
    unsigned char zT_31;
    int zT_32;
    zT_89B1DDDA_ComptimeVal zT_33;
    unsigned int zT_34;
    zT_79FAE712_u64 zT_35;
    unsigned int zT_36;
    int zT_37;
    zT_4DBDE173_Opt_187 zT_38;
    zT_4DBDE173_Opt_187 zT_39 = {0};
    unsigned int zT_40;
    unsigned int zT_41;
    int zT_42;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_6B0A7D14_AstStore* zT_46;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_47 = {0};
    zT_DA663F79_ComptimeEval* zT_49;
    unsigned int zT_50;
    unsigned int* zT_51;
    unsigned int zT_52;
    unsigned int zT_53;
    zT_BAEE192E_Opt_10 zT_54 = {0};
    unsigned char zT_55;
    zT_338B7C76_TypeRegistry* zT_58;
    zT_D155D06D_Type* zT_59;
    unsigned int zT_60;
    zT_D155D06D_Type zT_61;
    unsigned char zT_62;
    unsigned char zT_63;
    int zT_64;
    zT_89B1DDDA_ComptimeVal zT_65;
    unsigned int zT_66;
    zT_79FAE712_u64 zT_67;
    unsigned int zT_68;
    int zT_69;
    zT_4DBDE173_Opt_187 zT_70;
    zT_4DBDE173_Opt_187 zT_71 = {0};
    unsigned int zT_72;
    unsigned int zT_73;
    int zT_74;
    int zT_75;
    unsigned int zT_76;
    unsigned int zT_77;
    int zT_78;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    zT_6B0A7D14_AstStore* zT_82;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_83 = {0};
    unsigned int zT_85;
    unsigned int zT_86;
    int zT_87;
    zT_DA663F79_ComptimeEval* zT_89;
    unsigned int zT_90;
    unsigned int* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_BAEE192E_Opt_10 zT_94 = {0};
    unsigned char zT_95;
    zT_338B7C76_TypeRegistry* zT_98;
    zT_D155D06D_Type* zT_99;
    unsigned int zT_100;
    zT_D155D06D_Type zT_101;
    unsigned char zT_102;
    unsigned char zT_103;
    int zT_104;
    int zT_105;
    zT_33EF6BFB_TypeKind zT_106;
    zT_33EF6BFB_TypeKind zT_109;
    int zT_110;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_112 = {0};
    zT_338B7C76_TypeRegistry* zT_113;
    unsigned int zT_114;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_115;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_117;
    zT_6B0A7D14_AstStore* zT_119;
    unsigned int zT_120;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_22A7C88B_AstNode zT_125 = {0};
    zT_8143F551_AstKind zT_126;
    zT_8143F551_AstKind zT_129;
    int zT_130;
    zT_6B0A7D14_AstStore* zT_132;
    unsigned int zT_133;
    zT_6B0A7D14_AstStore* zT_134;
    unsigned int* zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138 = 0;
    zT_6B0A7D14_AstStore* zT_140;
    zT_EB5A718A_anon_162926 zT_141;
    unsigned int* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    int zT_146;
    unsigned int zT_147;
    unsigned int zT_149;
    int zT_150;
    zT_2DF01B61_FieldEntry* zT_151;
    zT_2DF01B61_FieldEntry zT_152;
    unsigned int zT_153;
    int zT_154;
    zT_2DF01B61_FieldEntry* zT_156;
    zT_2DF01B61_FieldEntry zT_157;
    unsigned int zT_158;
    zT_79FAE712_u64 zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    int zT_162;
    zT_79FAE712_u64 zT_163;
    zT_79FAE712_u64 zT_164;
    zT_89B1DDDA_ComptimeVal zT_165;
    unsigned int zT_166;
    int zT_167;
    zT_4DBDE173_Opt_187 zT_168;
    int zT_169;
    unsigned int zT_170;
    zT_4DBDE173_Opt_187 zT_171 = {0};
    unsigned int zT_172;
    unsigned int zT_173;
    int zT_174;
    zT_6B0A7D14_AstStore* zT_176;
    unsigned int zT_177;
    zT_6B0A7D14_AstStore* zT_178;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_179 = {0};
    unsigned int zT_181;
    unsigned int zT_182;
    int zT_183;
    zT_DA663F79_ComptimeEval* zT_185;
    unsigned int zT_186;
    unsigned int* zT_187;
    unsigned int zT_188;
    unsigned int zT_189;
    zT_BAEE192E_Opt_10 zT_190 = {0};
    unsigned char zT_191;
    zT_338B7C76_TypeRegistry* zT_194;
    zT_D155D06D_Type* zT_195;
    unsigned int zT_196;
    zT_D155D06D_Type zT_197;
    unsigned char zT_198;
    unsigned char zT_199;
    int zT_200;
    unsigned int zT_202;
    zT_79FAE712_u64 zT_203;
    zT_79FAE712_u64 zT_204;
    zT_79FAE712_u64 zT_205;
    zT_338B7C76_TypeRegistry* zT_206;
    unsigned int zT_207;
    zT_338B7C76_TypeRegistry* zT_208;
    int zT_209 = 0;
    zT_338B7C76_TypeRegistry* zT_210;
    unsigned int zT_211;
    zT_338B7C76_TypeRegistry* zT_212;
    unsigned char zT_213 = 0;
    zT_79FAE712_u64 zT_214;
    zT_33EF6BFB_TypeKind zT_215;
    zT_33EF6BFB_TypeKind zT_218;
    int zT_219;
    zT_79FAE712_u64 zT_220;
    zT_89B1DDDA_ComptimeVal zT_221;
    unsigned int zT_222;
    int zT_223;
    zT_4DBDE173_Opt_187 zT_224;
    zT_4DBDE173_Opt_187 zT_225 = {0};
    unsigned int zT_226;
    unsigned int zT_227;
    int zT_228;
    zT_6B0A7D14_AstStore* zT_230;
    unsigned int zT_231;
    zT_6B0A7D14_AstStore* zT_232;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_233 = {0};
    zT_DA663F79_ComptimeEval* zT_235;
    unsigned int zT_236;
    unsigned int* zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    zT_BAEE192E_Opt_10 zT_240 = {0};
    zT_DA663F79_ComptimeEval* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    unsigned int* zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    zT_4DBDE173_Opt_187 zT_248 = {0};
    unsigned char zT_249;
    unsigned char zT_251;
    zT_338B7C76_TypeRegistry* zT_254;
    zT_D155D06D_Type* zT_255;
    unsigned int zT_256;
    zT_D155D06D_Type zT_257;
    zT_338B7C76_TypeRegistry* zT_259;
    unsigned int zT_260;
    zT_338B7C76_TypeRegistry* zT_261;
    int zT_262 = 0;
    zT_338B7C76_TypeRegistry* zT_264;
    unsigned int zT_265;
    zT_338B7C76_TypeRegistry* zT_266;
    unsigned char zT_267 = 0;
    unsigned int zT_268;
    zT_338B7C76_TypeRegistry* zT_270;
    unsigned int zT_271;
    zT_338B7C76_TypeRegistry* zT_272;
    int zT_273 = 0;
    int zT_274;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    unsigned int zT_278;
    int zT_279;
    unsigned int zT_280;
    int zT_281;
    zT_89B1DDDA_ComptimeVal zT_282;
    zT_79FAE712_u64 zT_283;
    zT_4DBDE173_Opt_187 zT_284;
    zT_79FAE712_u64 zT_286;
    zT_79FAE712_u64 zT_287;
    zT_79FAE712_u64 zT_288;
    zT_79FAE712_u64 zT_289;
    zT_79FAE712_u64 zT_290;
    zT_79FAE712_u64 zT_292;
    zT_79FAE712_u64 zT_293;
    int zT_294;
    zT_79FAE712_u64 zT_295;
    zT_79FAE712_u64 zT_296;
    unsigned int zT_297;
    unsigned int zT_298;
    zT_79FAE712_u64 zT_299;
    zT_79FAE712_u64 zT_300;
    zT_79FAE712_u64 zT_301;
    zT_79FAE712_u64 zT_302;
    int zT_303;
    zT_79FAE712_u64 zT_305;
    zT_79FAE712_u64 zT_306;
    zT_79FAE712_u64 zT_307;
    zT_79FAE712_u64 zT_308;
    zT_79FAE712_u64 zT_309;
    zT_79FAE712_u64 zT_310;
    zT_89B1DDDA_ComptimeVal zT_311;
    zT_4DBDE173_Opt_187 zT_312;
    zT_4DBDE173_Opt_187 zT_313 = {0};
    unsigned int zT_314;
    unsigned int zT_315;
    int zT_316;
    zT_79FAE712_u64 zT_318;
    int zT_319;
    zT_79FAE712_u64 zT_320;
    zT_89B1DDDA_ComptimeVal zT_321;
    unsigned int zT_322;
    int zT_323;
    zT_4DBDE173_Opt_187 zT_324;
    zT_4DBDE173_Opt_187 zT_325 = {0};
    zT_22A7C88B_AstNode node;
    zT_3CB0179A_Slice_zT_05F374B1_u ec;
    zT_BAEE192E_Opt_10 tid;
    unsigned int t;
    zT_D155D06D_Type ty;
    zT_3CB0179A_Slice_zT_05F374B1_u ec2;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_3CB0179A_Slice_zT_05F374B1_u ec3;
    zT_BAEE192E_Opt_10 tid2;
    unsigned int t2;
    zT_D155D06D_Type ty2;
    zT_79FAE712_u64 bsz;
    zT_4DBDE173_Opt_187 inner;
    zT_89B1DDDA_ComptimeVal cv;
    int is_int_t;
    unsigned int wb;
    int sig;
    zT_79FAE712_u64 mask;
    zT_79FAE712_u64 masked;
    zT_79FAE712_u64 not_mask;
    zT_79FAE712_u64 wb2;
    zT_6 = self->store;
    zT_4 = zT_6;
    zT_5 = node_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    node = zT_7;
    node = zT_7;
    node = zT_7;
    zT_8 = node.child_0;
    zT_9 = self->size_of_id;
    zT_10 = zT_8 == zT_9;
    if (zT_10) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_14 = self->store;
    zT_12 = zT_14;
    zT_13 = node_idx;
    zT_15 = zF_850FDF81_astStoreNodeExtraCh(zT_12, zT_13);
    ec = zT_15;
    ec = zT_15;
    ec = zT_15;
    zT_17 = self;
    zT_19 = ec.ptr;
    zT_20 = 0;
    zT_21 = zT_19[zT_20];
    zT_18 = zT_21;
    zT_22 = zF_BAD6BA5D_comptimeEvalResolve(zT_17, zT_18);
    tid = zT_22;
    tid = zT_22;
    tid = zT_22;
    zT_23 = tid.has_value;
    if (zT_23) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_40 = node.child_0;
    zT_41 = self->align_of_id;
    zT_42 = zT_40 == zT_41;
    if (zT_42) goto z_bb_7; else goto z_bb_8;
    z_bb_3:
    t = tid.value;
    zT_26 = self->registry;
    zT_27 = zT_26->types_items;
    zT_28 = (unsigned int)t;
    zT_29 = zT_27[zT_28];
    ty = zT_29;
    ty = zT_29;
    ty = zT_29;
    zT_30 = ty.state;
    zT_31 = 2;
    zT_32 = zT_30 == zT_31;
    if (zT_32) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_39.has_value = 0;
    return zT_39;
    z_bb_5:
    zT_34 = ty.size;
    zT_35 = (zT_79FAE712_u64)zT_34;
    zT_33.bits = zT_35;
    zT_36 = 0;
    zT_33.width_bits = zT_36;
    zT_37 = 0;
    zT_33.sig = zT_37;
    zT_38.has_value = 1;
    zT_38.value = zT_33;
    return zT_38;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_46 = self->store;
    zT_44 = zT_46;
    zT_45 = node_idx;
    zT_47 = zF_850FDF81_astStoreNodeExtraCh(zT_44, zT_45);
    ec = zT_47;
    ec = zT_47;
    ec = zT_47;
    zT_49 = self;
    zT_51 = ec.ptr;
    zT_52 = 0;
    zT_53 = zT_51[zT_52];
    zT_50 = zT_53;
    zT_54 = zF_BAD6BA5D_comptimeEvalResolve(zT_49, zT_50);
    tid = zT_54;
    tid = zT_54;
    tid = zT_54;
    zT_55 = tid.has_value;
    if (zT_55) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_72 = node.child_0;
    zT_73 = self->offset_of_id;
    zT_74 = zT_72 == zT_73;
    if (zT_74) goto z_bb_14; else goto z_bb_13;
    z_bb_9:
    t = tid.value;
    zT_58 = self->registry;
    zT_59 = zT_58->types_items;
    zT_60 = (unsigned int)t;
    zT_61 = zT_59[zT_60];
    ty = zT_61;
    ty = zT_61;
    ty = zT_61;
    zT_62 = ty.state;
    zT_63 = 2;
    zT_64 = zT_62 == zT_63;
    if (zT_64) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_71.has_value = 0;
    return zT_71;
    z_bb_11:
    zT_66 = ty.alignment;
    zT_67 = (zT_79FAE712_u64)zT_66;
    zT_65.bits = zT_67;
    zT_68 = 0;
    zT_65.width_bits = zT_68;
    zT_69 = 0;
    zT_65.sig = zT_69;
    zT_70.has_value = 1;
    zT_70.value = zT_65;
    return zT_70;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_76 = node.child_0;
    zT_77 = self->bit_offset_of_id;
    zT_78 = zT_76 == zT_77;
    zT_75 = zT_78;
    goto z_bb_15;
    z_bb_14:
    zT_75 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_75) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_82 = self->store;
    zT_80 = zT_82;
    zT_81 = node_idx;
    zT_83 = zF_850FDF81_astStoreNodeExtraCh(zT_80, zT_81);
    ec2 = zT_83;
    ec2 = zT_83;
    ec2 = zT_83;
    zT_85 = ec2.len;
    zT_86 = 2;
    zT_87 = zT_85 >= zT_86;
    if (zT_87) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    zT_172 = node.child_0;
    zT_173 = self->bit_size_of_id;
    zT_174 = zT_172 == zT_173;
    if (zT_174) goto z_bb_37; else goto z_bb_38;
    z_bb_18:
    zT_89 = self;
    zT_91 = ec2.ptr;
    zT_92 = 0;
    zT_93 = zT_91[zT_92];
    zT_90 = zT_93;
    zT_94 = zF_BAD6BA5D_comptimeEvalResolve(zT_89, zT_90);
    tid = zT_94;
    tid = zT_94;
    tid = zT_94;
    zT_95 = tid.has_value;
    if (zT_95) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    zT_171.has_value = 0;
    return zT_171;
    z_bb_20:
    t = tid.value;
    zT_98 = self->registry;
    zT_99 = zT_98->types_items;
    zT_100 = (unsigned int)t;
    zT_101 = zT_99[zT_100];
    ty = zT_101;
    ty = zT_101;
    ty = zT_101;
    zT_102 = ty.state;
    zT_103 = 2;
    zT_104 = zT_102 == zT_103;
    if (zT_104) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_106 = ty.kind;
    zT_109 = zT_33EF6BFB_TypeKind_struct_type;
    zT_110 = zT_106 == zT_109;
    zT_105 = zT_110;
    goto z_bb_24;
    z_bb_23:
    zT_105 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_105) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    fields = zT_112;
    zT_116 = self->registry;
    zT_113 = zT_116;
    zT_114 = t;
    zT_117 = &fields;
    zT_115 = zT_117;
    zF_5A40A2EE_typeRegistryGetStru(zT_113, zT_114, zT_115);
    zT_121 = self->store;
    zT_119 = zT_121;
    zT_122 = ec2.ptr;
    zT_123 = 1;
    zT_124 = zT_122[zT_123];
    zT_120 = zT_124;
    zT_125 = zF_FCDD1D35_astStoreNodeAt(zT_119, zT_120);
    fname_node = zT_125;
    fname_node = zT_125;
    fname_node = zT_125;
    zT_126 = fname_node.kind;
    zT_129 = zT_8143F551_AstKind_string_literal;
    zT_130 = zT_126 == zT_129;
    if (zT_130) goto z_bb_27; else goto z_bb_28;
    z_bb_26:
    goto z_bb_21;
    z_bb_27:
    zT_134 = self->store;
    zT_132 = zT_134;
    zT_135 = ec2.ptr;
    zT_136 = 1;
    zT_137 = zT_135[zT_136];
    zT_133 = zT_137;
    zT_138 = zF_8BA26B9E_astStoreNodePayload(zT_132, zT_133);
    sv_idx = zT_138;
    sv_idx = zT_138;
    sv_idx = zT_138;
    zT_140 = self->store;
    zT_141 = zT_140->string_values;
    zT_142 = zT_141.items;
    zT_143 = (unsigned int)sv_idx;
    zT_144 = zT_142[zT_143];
    want_id = zT_144;
    want_id = zT_144;
    want_id = zT_144;
    zT_146 = 0;
    zT_147 = (unsigned int)zT_146;
    fi = zT_147;
    fi = zT_147;
    fi = zT_147;
    goto z_bb_29;
    z_bb_28:
    goto z_bb_26;
    z_bb_29:
    zT_149 = fields.len;
    zT_150 = fi < zT_149;
    if (zT_150) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_151 = fields.ptr;
    zT_152 = zT_151[fi];
    zT_153 = zT_152.name_id;
    zT_154 = zT_153 == want_id;
    if (zT_154) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_169 = 1;
    zT_170 = fi + zT_169;
    fi = zT_170;
    fi = zT_170;
    goto z_bb_29;
    z_bb_33:
    zT_156 = fields.ptr;
    zT_157 = zT_156[fi];
    zT_158 = zT_157.offset;
    zT_159 = (zT_79FAE712_u64)zT_158;
    bo = zT_159;
    bo = zT_159;
    bo = zT_159;
    zT_160 = node.child_0;
    zT_161 = self->bit_offset_of_id;
    zT_162 = zT_160 == zT_161;
    if (zT_162) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_163 = 8;
    zT_164 = bo * zT_163;
    bo = zT_164;
    bo = zT_164;
    goto z_bb_36;
    z_bb_36:
    zT_165.bits = bo;
    zT_166 = 0;
    zT_165.width_bits = zT_166;
    zT_167 = 0;
    zT_165.sig = zT_167;
    zT_168.has_value = 1;
    zT_168.value = zT_165;
    return zT_168;
    z_bb_37:
    zT_178 = self->store;
    zT_176 = zT_178;
    zT_177 = node_idx;
    zT_179 = zF_850FDF81_astStoreNodeExtraCh(zT_176, zT_177);
    ec3 = zT_179;
    ec3 = zT_179;
    ec3 = zT_179;
    zT_181 = ec3.len;
    zT_182 = 1;
    zT_183 = zT_181 >= zT_182;
    if (zT_183) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_226 = node.child_0;
    zT_227 = self->int_cast_id;
    zT_228 = zT_226 == zT_227;
    if (zT_228) goto z_bb_49; else goto z_bb_50;
    z_bb_39:
    zT_185 = self;
    zT_187 = ec3.ptr;
    zT_188 = 0;
    zT_189 = zT_187[zT_188];
    zT_186 = zT_189;
    zT_190 = zF_BAD6BA5D_comptimeEvalResolve(zT_185, zT_186);
    tid2 = zT_190;
    tid2 = zT_190;
    tid2 = zT_190;
    zT_191 = tid2.has_value;
    if (zT_191) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    zT_225.has_value = 0;
    return zT_225;
    z_bb_41:
    t2 = tid2.value;
    zT_194 = self->registry;
    zT_195 = zT_194->types_items;
    zT_196 = (unsigned int)t2;
    zT_197 = zT_195[zT_196];
    ty2 = zT_197;
    ty2 = zT_197;
    ty2 = zT_197;
    zT_198 = ty2.state;
    zT_199 = 2;
    zT_200 = zT_198 == zT_199;
    if (zT_200) goto z_bb_43; else goto z_bb_44;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_202 = ty2.size;
    zT_203 = (zT_79FAE712_u64)zT_202;
    zT_204 = 8;
    zT_205 = zT_203 * zT_204;
    bsz = zT_205;
    bsz = zT_205;
    bsz = zT_205;
    zT_208 = self->registry;
    zT_206 = zT_208;
    zT_207 = t2;
    zT_209 = zF_3290E9C4_typeRegistryIsInteg(zT_206, zT_207);
    if (zT_209) goto z_bb_45; else goto z_bb_46;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_212 = self->registry;
    zT_210 = zT_212;
    zT_211 = t2;
    zT_213 = zF_655972D5_typeRegistryIntWidt(zT_210, zT_211);
    zT_214 = (zT_79FAE712_u64)zT_213;
    bsz = zT_214;
    bsz = zT_214;
    goto z_bb_46;
    z_bb_46:
    zT_215 = ty2.kind;
    zT_218 = zT_33EF6BFB_TypeKind_bool_type;
    zT_219 = zT_215 == zT_218;
    if (zT_219) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_220 = 1;
    bsz = zT_220;
    bsz = zT_220;
    goto z_bb_48;
    z_bb_48:
    zT_221.bits = bsz;
    zT_222 = 0;
    zT_221.width_bits = zT_222;
    zT_223 = 0;
    zT_221.sig = zT_223;
    zT_224.has_value = 1;
    zT_224.value = zT_221;
    return zT_224;
    z_bb_49:
    zT_232 = self->store;
    zT_230 = zT_232;
    zT_231 = node_idx;
    zT_233 = zF_850FDF81_astStoreNodeExtraCh(zT_230, zT_231);
    ec = zT_233;
    ec = zT_233;
    ec = zT_233;
    zT_235 = self;
    zT_237 = ec.ptr;
    zT_238 = 0;
    zT_239 = zT_237[zT_238];
    zT_236 = zT_239;
    zT_240 = zF_BAD6BA5D_comptimeEvalResolve(zT_235, zT_236);
    tid = zT_240;
    tid = zT_240;
    tid = zT_240;
    zT_242 = self;
    zT_245 = ec.ptr;
    zT_246 = 1;
    zT_247 = zT_245[zT_246];
    zT_243 = zT_247;
    zT_244 = depth;
    zT_248 = zF_4EE17137_comptimeEvalEvaluat(zT_242, zT_243, zT_244);
    inner = zT_248;
    inner = zT_248;
    inner = zT_248;
    zT_249 = tid.has_value;
    if (zT_249) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    zT_314 = node.child_0;
    zT_315 = self->is_windows_id;
    zT_316 = zT_314 == zT_315;
    if (zT_316) goto z_bb_64; else goto z_bb_65;
    z_bb_51:
    t = tid.value;
    zT_251 = inner.has_value;
    if (zT_251) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_313.has_value = 0;
    return zT_313;
    z_bb_53:
    cv = inner.value;
    zT_254 = self->registry;
    zT_255 = zT_254->types_items;
    zT_256 = (unsigned int)t;
    zT_257 = zT_255[zT_256];
    ty = zT_257;
    ty = zT_257;
    ty = zT_257;
    zT_261 = self->registry;
    zT_259 = zT_261;
    zT_260 = t;
    zT_262 = zF_3290E9C4_typeRegistryIsInteg(zT_259, zT_260);
    is_int_t = zT_262;
    is_int_t = zT_262;
    is_int_t = zT_262;
    zT_266 = self->registry;
    zT_264 = zT_266;
    zT_265 = t;
    zT_267 = zF_655972D5_typeRegistryIntWidt(zT_264, zT_265);
    zT_268 = (unsigned int)zT_267;
    wb = zT_268;
    wb = zT_268;
    wb = zT_268;
    zT_272 = self->registry;
    zT_270 = zT_272;
    zT_271 = t;
    zT_273 = zF_01ED6537_typeRegistryIntIsSi(zT_270, zT_271);
    sig = zT_273;
    sig = zT_273;
    sig = zT_273;
    zT_274 = !is_int_t;
    if (zT_274) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    zT_275 = ty.size;
    zT_276 = 8;
    zT_277 = zT_275 * zT_276;
    zT_278 = (unsigned int)zT_277;
    wb = zT_278;
    wb = zT_278;
    zT_279 = 0;
    sig = zT_279;
    sig = zT_279;
    goto z_bb_56;
    z_bb_56:
    zT_280 = 64;
    zT_281 = wb >= zT_280;
    if (zT_281) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    zT_283 = cv.bits;
    zT_282.bits = zT_283;
    zT_282.width_bits = wb;
    zT_282.sig = sig;
    zT_284.has_value = 1;
    zT_284.value = zT_282;
    return zT_284;
    z_bb_58:
    zT_286 = 1;
    zT_287 = (zT_79FAE712_u64)wb;
    zT_288 = zT_286 << zT_287;
    zT_289 = 1;
    zT_290 = zT_288 - zT_289;
    mask = zT_290;
    mask = zT_290;
    mask = zT_290;
    zT_292 = cv.bits;
    zT_293 = zT_292 & mask;
    masked = zT_293;
    masked = zT_293;
    masked = zT_293;
    if (sig) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_295 = cv.bits;
    zT_296 = 1;
    zT_297 = 1;
    zT_298 = wb - zT_297;
    zT_299 = (zT_79FAE712_u64)zT_298;
    zT_300 = zT_296 << zT_299;
    zT_301 = zT_295 & zT_300;
    zT_302 = 0;
    zT_303 = zT_301 != zT_302;
    zT_294 = zT_303;
    goto z_bb_61;
    z_bb_60:
    zT_294 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_294) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    zT_305 = 0;
    zT_306 = zT_305 - mask;
    zT_307 = 1;
    zT_308 = zT_306 - zT_307;
    not_mask = zT_308;
    not_mask = zT_308;
    not_mask = zT_308;
    zT_309 = cv.bits;
    zT_310 = zT_309 | not_mask;
    masked = zT_310;
    masked = zT_310;
    goto z_bb_63;
    z_bb_63:
    zT_311.bits = masked;
    zT_311.width_bits = wb;
    zT_311.sig = sig;
    zT_312.has_value = 1;
    zT_312.value = zT_311;
    return zT_312;
    z_bb_64:
    zT_318 = 0;
    wb2 = zT_318;
    wb2 = zT_318;
    wb2 = zT_318;
    zT_319 = self->host_is_windows;
    if (zT_319) goto z_bb_66; else goto z_bb_67;
    z_bb_65:
    zT_325.has_value = 0;
    return zT_325;
    z_bb_66:
    zT_320 = 1;
    wb2 = zT_320;
    wb2 = zT_320;
    goto z_bb_67;
    z_bb_67:
    zT_321.bits = wb2;
    zT_322 = 1;
    zT_321.width_bits = zT_322;
    zT_323 = 0;
    zT_321.sig = zT_323;
    zT_324.has_value = 1;
    zT_324.value = zT_321;
    return zT_324;
}

/* comptimeEvalEvaluate */
zT_4DBDE173_Opt_187 zF_EBC0E9BE_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx) {
    zT_DA663F79_ComptimeEval* zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_4DBDE173_Opt_187 zT_6 = {0};
    zT_2 = self;
    zT_3 = node_idx;
    zT_5 = 0;
    zT_4 = zT_5;
    zT_6 = zF_4EE17137_comptimeEvalEvaluat(zT_2, zT_3, zT_4);
    return zT_6;
}

/* comptimeEvalEvaluateDepth */
zT_4DBDE173_Opt_187 zF_4EE17137_comptimeEvalEvaluat(zT_DA663F79_ComptimeEval* self, unsigned int node_idx, unsigned int depth) {
    unsigned int zT_3;
    int zT_4;
    zT_4DBDE173_Opt_187 zT_5 = {0};
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_9;
    zT_22A7C88B_AstNode zT_10 = {0};
    zT_8143F551_AstKind zT_11;
    zT_8143F551_AstKind zT_14;
    int zT_15;
    zT_89B1DDDA_ComptimeVal zT_16;
    zT_6B0A7D14_AstStore* zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_19;
    zT_79FAE712_u64 zT_20 = 0;
    unsigned int zT_21;
    int zT_22;
    zT_4DBDE173_Opt_187 zT_23;
    zT_8143F551_AstKind zT_24;
    zT_8143F551_AstKind zT_27;
    int zT_28;
    zT_89B1DDDA_ComptimeVal zT_29;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_6B0A7D14_AstStore* zT_32;
    zT_79FAE712_u64 zT_33 = 0;
    unsigned int zT_34;
    int zT_35;
    zT_4DBDE173_Opt_187 zT_36;
    zT_8143F551_AstKind zT_37;
    zT_8143F551_AstKind zT_40;
    int zT_41;
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned char zT_44;
    unsigned char zT_45;
    int zT_46;
    zT_89B1DDDA_ComptimeVal zT_47;
    zT_79FAE712_u64 zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_4DBDE173_Opt_187 zT_51;
    zT_89B1DDDA_ComptimeVal zT_52;
    zT_79FAE712_u64 zT_53;
    unsigned int zT_54;
    int zT_55;
    zT_4DBDE173_Opt_187 zT_56;
    zT_8143F551_AstKind zT_57;
    zT_8143F551_AstKind zT_60;
    int zT_61;
    zT_DA663F79_ComptimeEval* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_4DBDE173_Opt_187 zT_67 = {0};
    unsigned char zT_68;
    zT_79FAE712_u64 zT_71;
    zT_79FAE712_u64 zT_72;
    zT_79FAE712_u64 zT_73;
    unsigned int zT_74;
    unsigned int zT_75;
    int zT_76;
    unsigned int zT_78;
    unsigned int zT_79;
    int zT_80;
    zT_89B1DDDA_ComptimeVal zT_81;
    int zT_82;
    zT_4DBDE173_Opt_187 zT_83;
    zT_79FAE712_u64 zT_85;
    zT_79FAE712_u64 zT_86;
    zT_79FAE712_u64 zT_87;
    zT_79FAE712_u64 zT_88;
    zT_79FAE712_u64 zT_89;
    zT_79FAE712_u64 zT_91;
    int zT_92;
    int zT_93;
    zT_79FAE712_u64 zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_79FAE712_u64 zT_97;
    zT_79FAE712_u64 zT_98;
    zT_79FAE712_u64 zT_99;
    zT_79FAE712_u64 zT_100;
    int zT_101;
    zT_79FAE712_u64 zT_103;
    zT_79FAE712_u64 zT_104;
    zT_79FAE712_u64 zT_105;
    zT_79FAE712_u64 zT_106;
    zT_79FAE712_u64 zT_107;
    zT_89B1DDDA_ComptimeVal zT_108;
    int zT_109;
    zT_4DBDE173_Opt_187 zT_110;
    zT_89B1DDDA_ComptimeVal zT_111;
    unsigned int zT_112;
    int zT_113;
    zT_4DBDE173_Opt_187 zT_114;
    zT_4DBDE173_Opt_187 zT_115 = {0};
    zT_8143F551_AstKind zT_116;
    zT_8143F551_AstKind zT_119;
    int zT_120;
    zT_DA663F79_ComptimeEval* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    unsigned int zT_125;
    zT_4DBDE173_Opt_187 zT_126 = {0};
    unsigned char zT_127;
    zT_79FAE712_u64 zT_130;
    zT_79FAE712_u64 zT_131;
    zT_89B1DDDA_ComptimeVal zT_132;
    unsigned int zT_133;
    int zT_134;
    zT_4DBDE173_Opt_187 zT_135;
    zT_4DBDE173_Opt_187 zT_136 = {0};
    zT_8143F551_AstKind zT_137;
    zT_8143F551_AstKind zT_140;
    int zT_141;
    int zT_142;
    zT_8143F551_AstKind zT_143;
    zT_8143F551_AstKind zT_146;
    int zT_147;
    int zT_148;
    zT_8143F551_AstKind zT_149;
    zT_8143F551_AstKind zT_152;
    int zT_153;
    int zT_154;
    zT_8143F551_AstKind zT_155;
    zT_8143F551_AstKind zT_158;
    int zT_159;
    int zT_160;
    zT_8143F551_AstKind zT_161;
    zT_8143F551_AstKind zT_164;
    int zT_165;
    int zT_166;
    zT_8143F551_AstKind zT_167;
    zT_8143F551_AstKind zT_170;
    int zT_171;
    int zT_172;
    zT_8143F551_AstKind zT_173;
    zT_8143F551_AstKind zT_176;
    int zT_177;
    int zT_178;
    zT_8143F551_AstKind zT_179;
    zT_8143F551_AstKind zT_182;
    int zT_183;
    int zT_184;
    zT_8143F551_AstKind zT_185;
    zT_8143F551_AstKind zT_188;
    int zT_189;
    int zT_190;
    zT_8143F551_AstKind zT_191;
    zT_8143F551_AstKind zT_194;
    int zT_195;
    zT_DA663F79_ComptimeEval* zT_196;
    unsigned int zT_197;
    zT_8143F551_AstKind zT_198;
    unsigned int zT_199;
    zT_8143F551_AstKind zT_200;
    zT_4DBDE173_Opt_187 zT_201 = {0};
    zT_8143F551_AstKind zT_202;
    zT_8143F551_AstKind zT_205;
    int zT_206;
    zT_DA663F79_ComptimeEval* zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    zT_4DBDE173_Opt_187 zT_210 = {0};
    zT_8143F551_AstKind zT_211;
    zT_8143F551_AstKind zT_214;
    int zT_215;
    zT_DA663F79_ComptimeEval* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned int zT_219;
    zT_8143F551_AstKind zT_221;
    zT_8143F551_AstKind zT_224;
    int zT_225;
    unsigned int zT_226;
    int zT_227;
    zT_4DBDE173_Opt_187 zT_228 = {0};
    zT_6B0A7D14_AstStore* zT_230;
    unsigned int zT_231;
    zT_6B0A7D14_AstStore* zT_232;
    unsigned int zT_233 = 0;
    int zT_235;
    unsigned int zT_236;
    zT_3D7259E2_SymbolRegistry* zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    int zT_240;
    zT_3D7259E2_SymbolRegistry* zT_242;
    unsigned int zT_243;
    unsigned int zT_244;
    zT_3D7259E2_SymbolRegistry* zT_245;
    unsigned int zT_246;
    zT_4108E5FF_Opt_796 zT_247 = {0};
    unsigned char zT_248;
    unsigned short zT_250;
    unsigned short zT_251;
    unsigned short zT_252;
    unsigned short zT_253;
    int zT_254;
    zT_6B0A7D14_AstStore* zT_256;
    unsigned int zT_257;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    zT_22A7C88B_AstNode zT_260 = {0};
    unsigned int zT_261;
    unsigned int zT_262;
    int zT_263;
    zT_DA663F79_ComptimeEval* zT_264;
    unsigned int zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    int zT_271;
    unsigned int zT_272;
    zT_4DBDE173_Opt_187 zT_273 = {0};
    zT_4DBDE173_Opt_187 zT_274 = {0};
    zT_22A7C88B_AstNode node;
    zT_4DBDE173_Opt_187 inner;
    zT_89B1DDDA_ComptimeVal cv;
    zT_79FAE712_u64 nv;
    unsigned int wb;
    zT_79FAE712_u64 mask;
    zT_79FAE712_u64 masked;
    zT_79FAE712_u64 not_mask;
    zT_4DBDE173_Opt_187 bnv;
    zT_89B1DDDA_ComptimeVal bv;
    zT_79FAE712_u64 bnb;
    unsigned int name_id;
    unsigned int mi;
    zT_4108E5FF_Opt_796 c_sym;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    z_bb_0:
    zT_3 = 0;
    zT_4 = node_idx == zT_3;
    if (zT_4) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_9 = self->store;
    zT_7 = zT_9;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    node = zT_10;
    node = zT_10;
    zT_11 = node.kind;
    zT_14 = zT_8143F551_AstKind_int_literal;
    zT_15 = zT_11 == zT_14;
    if (zT_15) goto z_bb_3; else goto z_bb_5;
    z_bb_3:
    zT_19 = self->store;
    zT_17 = zT_19;
    zT_18 = node_idx;
    zT_20 = zF_678B9A72_astStoreIntValue(zT_17, zT_18);
    zT_16.bits = zT_20;
    zT_21 = 0;
    zT_16.width_bits = zT_21;
    zT_22 = 1;
    zT_16.sig = zT_22;
    zT_23.has_value = 1;
    zT_23.value = zT_16;
    return zT_23;
    z_bb_4:
    { zT_4DBDE173_Opt_187 zT_ret_void = {0}; return zT_ret_void; }
    z_bb_5:
    zT_24 = node.kind;
    zT_27 = zT_8143F551_AstKind_char_literal;
    zT_28 = zT_24 == zT_27;
    if (zT_28) goto z_bb_6; else goto z_bb_8;
    z_bb_6:
    zT_32 = self->store;
    zT_30 = zT_32;
    zT_31 = node_idx;
    zT_33 = zF_678B9A72_astStoreIntValue(zT_30, zT_31);
    zT_29.bits = zT_33;
    zT_34 = 8;
    zT_29.width_bits = zT_34;
    zT_35 = 0;
    zT_29.sig = zT_35;
    zT_36.has_value = 1;
    zT_36.value = zT_29;
    return zT_36;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_37 = node.kind;
    zT_40 = zT_8143F551_AstKind_bool_literal;
    zT_41 = zT_37 == zT_40;
    if (zT_41) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_42 = node.flags;
    zT_43 = 1;
    zT_44 = zT_42 & zT_43;
    zT_45 = 0;
    zT_46 = zT_44 != zT_45;
    if (zT_46) goto z_bb_12; else goto z_bb_13;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_57 = node.kind;
    zT_60 = zT_8143F551_AstKind_negate;
    zT_61 = zT_57 == zT_60;
    if (zT_61) goto z_bb_14; else goto z_bb_16;
    z_bb_12:
    zT_48 = 1;
    zT_47.bits = zT_48;
    zT_49 = 1;
    zT_47.width_bits = zT_49;
    zT_50 = 0;
    zT_47.sig = zT_50;
    zT_51.has_value = 1;
    zT_51.value = zT_47;
    return zT_51;
    z_bb_13:
    zT_53 = 0;
    zT_52.bits = zT_53;
    zT_54 = 1;
    zT_52.width_bits = zT_54;
    zT_55 = 0;
    zT_52.sig = zT_55;
    zT_56.has_value = 1;
    zT_56.value = zT_52;
    return zT_56;
    z_bb_14:
    zT_63 = self;
    zT_66 = node.child_0;
    zT_64 = zT_66;
    zT_65 = depth;
    zT_67 = zF_4EE17137_comptimeEvalEvaluat(zT_63, zT_64, zT_65);
    inner = zT_67;
    inner = zT_67;
    inner = zT_67;
    zT_68 = inner.has_value;
    if (zT_68) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_116 = node.kind;
    zT_119 = zT_8143F551_AstKind_bit_not;
    zT_120 = zT_116 == zT_119;
    if (zT_120) goto z_bb_28; else goto z_bb_30;
    z_bb_17:
    cv = inner.value;
    zT_71 = 0;
    zT_72 = cv.bits;
    zT_73 = zT_71 - zT_72;
    nv = zT_73;
    nv = zT_73;
    nv = zT_73;
    zT_74 = cv.width_bits;
    zT_75 = 0;
    zT_76 = zT_74 != zT_75;
    if (zT_76) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    zT_115.has_value = 0;
    return zT_115;
    z_bb_19:
    zT_78 = cv.width_bits;
    wb = zT_78;
    wb = zT_78;
    wb = zT_78;
    zT_79 = 64;
    zT_80 = wb >= zT_79;
    if (zT_80) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_111.bits = nv;
    zT_112 = 0;
    zT_111.width_bits = zT_112;
    zT_113 = 1;
    zT_111.sig = zT_113;
    zT_114.has_value = 1;
    zT_114.value = zT_111;
    return zT_114;
    z_bb_21:
    zT_81.bits = nv;
    zT_81.width_bits = wb;
    zT_82 = cv.sig;
    zT_81.sig = zT_82;
    zT_83.has_value = 1;
    zT_83.value = zT_81;
    return zT_83;
    z_bb_22:
    zT_85 = 1;
    zT_86 = (zT_79FAE712_u64)wb;
    zT_87 = zT_85 << zT_86;
    zT_88 = 1;
    zT_89 = zT_87 - zT_88;
    mask = zT_89;
    mask = zT_89;
    mask = zT_89;
    zT_91 = nv & mask;
    masked = zT_91;
    masked = zT_91;
    masked = zT_91;
    zT_92 = cv.sig;
    if (zT_92) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    zT_94 = 1;
    zT_95 = 1;
    zT_96 = wb - zT_95;
    zT_97 = (zT_79FAE712_u64)zT_96;
    zT_98 = zT_94 << zT_97;
    zT_99 = nv & zT_98;
    zT_100 = 0;
    zT_101 = zT_99 != zT_100;
    zT_93 = zT_101;
    goto z_bb_25;
    z_bb_24:
    zT_93 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_93) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_103 = 0;
    zT_104 = zT_103 - mask;
    zT_105 = 1;
    zT_106 = zT_104 - zT_105;
    not_mask = zT_106;
    not_mask = zT_106;
    not_mask = zT_106;
    zT_107 = nv | not_mask;
    masked = zT_107;
    masked = zT_107;
    goto z_bb_27;
    z_bb_27:
    zT_108.bits = masked;
    zT_108.width_bits = wb;
    zT_109 = cv.sig;
    zT_108.sig = zT_109;
    zT_110.has_value = 1;
    zT_110.value = zT_108;
    return zT_110;
    z_bb_28:
    zT_122 = self;
    zT_125 = node.child_0;
    zT_123 = zT_125;
    zT_124 = depth;
    zT_126 = zF_4EE17137_comptimeEvalEvaluat(zT_122, zT_123, zT_124);
    bnv = zT_126;
    bnv = zT_126;
    bnv = zT_126;
    zT_127 = bnv.has_value;
    if (zT_127) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    goto z_bb_15;
    z_bb_30:
    zT_137 = node.kind;
    zT_140 = zT_8143F551_AstKind_add;
    zT_141 = zT_137 == zT_140;
    if (zT_141) goto z_bb_34; else goto z_bb_33;
    z_bb_31:
    bv = bnv.value;
    zT_130 = bv.bits;
    zT_131 = ~zT_130;
    bnb = zT_131;
    bnb = zT_131;
    bnb = zT_131;
    zT_132.bits = bnb;
    zT_133 = bv.width_bits;
    zT_132.width_bits = zT_133;
    zT_134 = 0;
    zT_132.sig = zT_134;
    zT_135.has_value = 1;
    zT_135.value = zT_132;
    return zT_135;
    z_bb_32:
    zT_136.has_value = 0;
    return zT_136;
    z_bb_33:
    zT_143 = node.kind;
    zT_146 = zT_8143F551_AstKind_sub;
    zT_147 = zT_143 == zT_146;
    zT_142 = zT_147;
    goto z_bb_35;
    z_bb_34:
    zT_142 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_142) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_149 = node.kind;
    zT_152 = zT_8143F551_AstKind_mul;
    zT_153 = zT_149 == zT_152;
    zT_148 = zT_153;
    goto z_bb_38;
    z_bb_37:
    zT_148 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_148) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_155 = node.kind;
    zT_158 = zT_8143F551_AstKind_div;
    zT_159 = zT_155 == zT_158;
    zT_154 = zT_159;
    goto z_bb_41;
    z_bb_40:
    zT_154 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_154) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_161 = node.kind;
    zT_164 = zT_8143F551_AstKind_mod_op;
    zT_165 = zT_161 == zT_164;
    zT_160 = zT_165;
    goto z_bb_44;
    z_bb_43:
    zT_160 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_160) goto z_bb_46; else goto z_bb_45;
    z_bb_45:
    zT_167 = node.kind;
    zT_170 = zT_8143F551_AstKind_bit_and;
    zT_171 = zT_167 == zT_170;
    zT_166 = zT_171;
    goto z_bb_47;
    z_bb_46:
    zT_166 = 1;
    goto z_bb_47;
    z_bb_47:
    if (zT_166) goto z_bb_49; else goto z_bb_48;
    z_bb_48:
    zT_173 = node.kind;
    zT_176 = zT_8143F551_AstKind_bit_or;
    zT_177 = zT_173 == zT_176;
    zT_172 = zT_177;
    goto z_bb_50;
    z_bb_49:
    zT_172 = 1;
    goto z_bb_50;
    z_bb_50:
    if (zT_172) goto z_bb_52; else goto z_bb_51;
    z_bb_51:
    zT_179 = node.kind;
    zT_182 = zT_8143F551_AstKind_bit_xor;
    zT_183 = zT_179 == zT_182;
    zT_178 = zT_183;
    goto z_bb_53;
    z_bb_52:
    zT_178 = 1;
    goto z_bb_53;
    z_bb_53:
    if (zT_178) goto z_bb_55; else goto z_bb_54;
    z_bb_54:
    zT_185 = node.kind;
    zT_188 = zT_8143F551_AstKind_shl;
    zT_189 = zT_185 == zT_188;
    zT_184 = zT_189;
    goto z_bb_56;
    z_bb_55:
    zT_184 = 1;
    goto z_bb_56;
    z_bb_56:
    if (zT_184) goto z_bb_58; else goto z_bb_57;
    z_bb_57:
    zT_191 = node.kind;
    zT_194 = zT_8143F551_AstKind_shr;
    zT_195 = zT_191 == zT_194;
    zT_190 = zT_195;
    goto z_bb_59;
    z_bb_58:
    zT_190 = 1;
    goto z_bb_59;
    z_bb_59:
    if (zT_190) goto z_bb_60; else goto z_bb_62;
    z_bb_60:
    zT_196 = self;
    zT_197 = node_idx;
    zT_200 = node.kind;
    zT_198 = zT_200;
    zT_199 = depth;
    zT_201 = zF_B36A4A25_comptimeEvalBinOp(zT_196, zT_197, zT_198, zT_199);
    return zT_201;
    z_bb_61:
    goto z_bb_29;
    z_bb_62:
    zT_202 = node.kind;
    zT_205 = zT_8143F551_AstKind_builtin_call;
    zT_206 = zT_202 == zT_205;
    if (zT_206) goto z_bb_63; else goto z_bb_65;
    z_bb_63:
    zT_207 = self;
    zT_208 = node_idx;
    zT_209 = depth;
    zT_210 = zF_C37A1F7C_comptimeEvalBuiltin(zT_207, zT_208, zT_209);
    return zT_210;
    z_bb_64:
    goto z_bb_61;
    z_bb_65:
    zT_211 = node.kind;
    zT_214 = zT_8143F551_AstKind_paren_expr;
    zT_215 = zT_211 == zT_214;
    if (zT_215) goto z_bb_66; else goto z_bb_68;
    z_bb_66:
    zT_216 = self;
    zT_219 = node.child_0;
    zT_217 = zT_219;
    zT_218 = depth;
    self = zT_216;
    node_idx = zT_217;
    depth = zT_218;
    goto z_bb_0;
    z_bb_67:
    goto z_bb_64;
    z_bb_68:
    zT_221 = node.kind;
    zT_224 = zT_8143F551_AstKind_ident_expr;
    zT_225 = zT_221 == zT_224;
    if (zT_225) goto z_bb_69; else goto z_bb_71;
    z_bb_69:
    zT_226 = 16;
    zT_227 = depth >= zT_226;
    if (zT_227) goto z_bb_72; else goto z_bb_73;
    goto z_bb_67;
    z_bb_71:
    zT_274.has_value = 0;
    return zT_274;
    z_bb_72:
    zT_228.has_value = 0;
    return zT_228;
    z_bb_73:
    zT_232 = self->store;
    zT_230 = zT_232;
    zT_231 = node_idx;
    zT_233 = zF_53458827_astStoreIdentifier(zT_230, zT_231);
    name_id = zT_233;
    name_id = zT_233;
    name_id = zT_233;
    zT_235 = 0;
    zT_236 = (unsigned int)zT_235;
    mi = zT_236;
    mi = zT_236;
    mi = zT_236;
    goto z_bb_74;
    z_bb_74:
    zT_237 = self->symbol_reg;
    zT_238 = zT_237->tables_len;
    zT_239 = (unsigned int)zT_238;
    zT_240 = mi < zT_239;
    if (zT_240) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_245 = self->symbol_reg;
    zT_242 = zT_245;
    zT_246 = (unsigned int)mi;
    zT_243 = zT_246;
    zT_244 = name_id;
    zT_247 = zF_A398987E_symbolRegistryQuali(zT_242, zT_243, zT_244);
    c_sym = zT_247;
    c_sym = zT_247;
    c_sym = zT_247;
    zT_248 = c_sym.has_value;
    if (zT_248) goto z_bb_78; else goto z_bb_79;
    z_bb_76:
    zT_273.has_value = 0;
    return zT_273;
    z_bb_77:
    zT_271 = 1;
    zT_272 = mi + zT_271;
    mi = zT_272;
    mi = zT_272;
    goto z_bb_74;
    z_bb_78:
    cs = c_sym.value;
    zT_250 = cs->flags;
    zT_251 = 1;
    zT_252 = zT_250 & zT_251;
    zT_253 = 0;
    zT_254 = zT_252 == zT_253;
    if (zT_254) goto z_bb_80; else goto z_bb_81;
    z_bb_79:
    goto z_bb_77;
    z_bb_80:
    zT_258 = self->store;
    zT_256 = zT_258;
    zT_259 = cs->decl_node;
    zT_257 = zT_259;
    zT_260 = zF_FCDD1D35_astStoreNodeAt(zT_256, zT_257);
    c_decl = zT_260;
    c_decl = zT_260;
    c_decl = zT_260;
    zT_261 = c_decl.child_1;
    zT_262 = 0;
    zT_263 = zT_261 != zT_262;
    if (zT_263) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    goto z_bb_79;
    z_bb_82:
    zT_264 = self;
    zT_267 = c_decl.child_1;
    zT_265 = zT_267;
    zT_268 = 1;
    zT_269 = depth + zT_268;
    zT_266 = zT_269;
    self = zT_264;
    node_idx = zT_265;
    depth = zT_266;
    goto z_bb_0;
    z_bb_83:
    goto z_bb_81;
}

/* EOF */
