#include "hash_02AFCD13.h"
/* mapCapacityFromHint */
unsigned int zF_ADD0ED80_mapCapacityFromHint(unsigned int hint) {
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_15;
    unsigned int needed;
    unsigned int cap;
    if ((unsigned char)(hint == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_10 = (unsigned int)((unsigned int)(hint * (unsigned int)(4)) + (unsigned int)(2)) / (unsigned int)(3);
    needed = zT_10;
    zT_12 = 8;
    cap = zT_12;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(cap < needed)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = cap * (unsigned int)(2);
    cap = zT_15;
    goto z_bb_6;
    z_bb_5:
    return cap;
    z_bb_6:
    goto z_bb_3;
}

/* fnv1a */
unsigned int zF_B22E025B_fnv1a(zT_8F083A69_Slice_zT_0B42B2F8_u data) {
    unsigned int zT_2;
    unsigned int zT_3;
    unsigned char* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned int hash;
    unsigned char byte;
    zT_2 = 2166136261u;
    zT_3 = (unsigned int)zT_2;
    hash = zT_3;
    zT_4 = data.ptr;
    zT_5 = data.len;
    zT_6 = 0;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(zT_6 < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    byte = zT_4[zT_6];
    zT_10 = hash ^ (unsigned int)((unsigned int)byte);
    hash = zT_10;
    zT_11 = 16777619;
    zT_12 = hash * zT_11;
    hash = zT_12;
    zT_14 = zT_6 + (unsigned int)(1);
    zT_6 = zT_14;
    goto z_bb_1;
    z_bb_3:
    return hash;
}

/* u32ToU32MapInit */
zT_21D3708C_U32ToU32Map zF_58BDA2DE_u32ToU32MapInit(zT_3E40CD83_Sand* alloc) {
    zT_21D3708C_U32ToU32Map zT_1;
    int zT_2;
    int zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_2 = 0;
    zT_1.keys = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.values = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.occupied = (unsigned char*)zT_4;
    zT_5 = 0;
    zT_1.capacity = zT_5;
    zT_6 = 0;
    zT_1.count = zT_6;
    zT_1.alloc = alloc;
    return zT_1;
}

/* u32ToU32MapInitCap */
zT_21D3708C_U32ToU32Map zF_619D56E6_u32ToU32MapInitCap(zT_3E40CD83_Sand* alloc, unsigned int hint) {
    unsigned int zT_3;
    unsigned int zT_4 = 0;
    zT_3E40CD83_Sand* zT_7;
    zT_21D3708C_U32ToU32Map zT_8 = {0};
    zT_3E40CD83_Sand* zT_10;
    zT_C6536882_EU_532 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    zT_3E40CD83_Sand* zT_21;
    zT_C6536882_EU_532 zT_27 = {0};
    unsigned char zT_28;
    unsigned char* zT_29;
    zT_3E40CD83_Sand* zT_32;
    zT_C6536882_EU_532 zT_38 = {0};
    unsigned char zT_39;
    unsigned char* zT_40;
    int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    int zT_47;
    unsigned int zT_49;
    zT_21D3708C_U32ToU32Map zT_50;
    unsigned int* zT_51;
    unsigned int* zT_52;
    unsigned char* zT_53;
    unsigned int zT_54;
    unsigned int cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    zT_3 = hint;
    zT_4 = zF_ADD0ED80_mapCapacityFromHint(zT_3);
    cap = zT_4;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = alloc;
    zT_8 = zF_58BDA2DE_u32ToU32MapInit(zT_7);
    return zT_8;
    z_bb_2:
    zT_10 = alloc;
    zT_16 = zF_1395EB68_sandAlloc(zT_10, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw_keys = zT_18;
    zT_21 = alloc;
    zT_27 = zF_1395EB68_sandAlloc(zT_21, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_28 = zT_27.is_error;
    if (zT_28) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_29 = zT_27.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_vals = zT_29;
    zT_32 = alloc;
    zT_38 = zF_1395EB68_sandAlloc(zT_32, (unsigned int)((unsigned int)(1) * cap), (unsigned int)(4));
    zT_39 = zT_38.is_error;
    if (zT_39) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_40 = zT_38.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_occ = zT_40;
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    zi = zT_44;
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(zi < cap)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = 0;
    raw_occ[zi] = zT_46;
    goto z_bb_15;
    z_bb_14:
    zT_51 = (unsigned int*)raw_keys;
    zT_50.keys = zT_51;
    zT_52 = (unsigned int*)raw_vals;
    zT_50.values = zT_52;
    zT_53 = (unsigned char*)raw_occ;
    zT_50.occupied = zT_53;
    zT_50.capacity = cap;
    zT_54 = 0;
    zT_50.count = zT_54;
    zT_50.alloc = alloc;
    return zT_50;
    z_bb_15:
    zT_47 = 1;
    zT_49 = zi + (unsigned int)((unsigned int)zT_47);
    zi = zT_49;
    goto z_bb_12;
}

/* u32ToU32MapGet */
zT_BAEE192E_Opt_10 zF_F3EE5998_u32ToU32MapGet(zT_21D3708C_U32ToU32Map* self, unsigned int key) {
    unsigned int zT_2;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned char* zT_13;
    unsigned char zT_14;
    unsigned int* zT_17;
    unsigned int zT_18;
    unsigned int* zT_20;
    unsigned int zT_21;
    zT_BAEE192E_Opt_10 zT_22;
    unsigned int zT_25;
    zT_BAEE192E_Opt_10 zT_26 = {0};
    unsigned int mask;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->capacity;
    zT_9 = zT_7 - (unsigned int)(1);
    mask = zT_9;
    zT_12 = (unsigned int)((unsigned int)key) & mask;
    i = zT_12;
    goto z_bb_3;
    z_bb_3:
    zT_13 = self->occupied;
    zT_14 = zT_13[i];
    if ((unsigned char)(zT_14 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = self->keys;
    zT_18 = zT_17[i];
    if ((unsigned char)(zT_18 == key)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_26.has_value = 0;
    return zT_26;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_20 = self->values;
    zT_21 = zT_20[i];
    zT_22.has_value = 1;
    zT_22.value = zT_21;
    return zT_22;
    z_bb_8:
    zT_25 = (unsigned int)(i + (unsigned int)(1)) & mask;
    i = zT_25;
    goto z_bb_6;
}

/* u32ToU32MapGrow */
void zF_A54BFE8F_u32ToU32MapGrow(zT_21D3708C_U32ToU32Map* self) {
    unsigned int zT_2;
    unsigned int* zT_4;
    unsigned int* zT_6;
    unsigned char* zT_8;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_17;
    zT_C6536882_EU_532 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_3E40CD83_Sand* zT_29;
    zT_C6536882_EU_532 zT_36 = {0};
    unsigned char zT_37;
    unsigned char* zT_38;
    zT_3E40CD83_Sand* zT_41;
    zT_C6536882_EU_532 zT_48 = {0};
    unsigned char zT_49;
    unsigned char* zT_50;
    int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned char* zT_61;
    int zT_62;
    unsigned int zT_64;
    int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned int zT_73;
    unsigned int zT_75;
    unsigned int zT_78;
    unsigned int zT_81;
    unsigned char* zT_82;
    unsigned char zT_83;
    unsigned int zT_88;
    unsigned int* zT_89;
    unsigned int* zT_90;
    unsigned char zT_91;
    unsigned char* zT_92;
    unsigned int zT_93;
    int zT_94;
    int zT_97;
    unsigned int zT_99;
    unsigned int old_cap;
    unsigned int* old_keys;
    unsigned int* old_values;
    unsigned char* old_occupied;
    unsigned int new_cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    unsigned int ri;
    unsigned int k;
    unsigned int v;
    unsigned int mask2;
    unsigned int idx;
    zT_2 = self->capacity;
    old_cap = zT_2;
    zT_4 = self->keys;
    old_keys = zT_4;
    zT_6 = self->values;
    old_values = zT_6;
    zT_8 = self->occupied;
    old_occupied = zT_8;
    if ((unsigned char)(old_cap < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_12 = old_cap * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_12;
    zT_17 = self->alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_26 = zT_24.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_keys = zT_26;
    zT_29 = self->alloc;
    zT_36 = zF_1395EB68_sandAlloc(zT_29, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_37 = zT_36.is_error;
    if (zT_37) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_38 = zT_36.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_vals = zT_38;
    zT_41 = self->alloc;
    zT_48 = zF_1395EB68_sandAlloc(zT_41, (unsigned int)((unsigned int)(1) * new_cap), (unsigned int)(4));
    zT_49 = zT_48.is_error;
    if (zT_49) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_50 = zT_48.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_occ = zT_50;
    self->keys = (unsigned int*)((unsigned int*)raw_keys);
    self->values = (unsigned int*)((unsigned int*)raw_vals);
    self->occupied = (unsigned char*)((unsigned char*)raw_occ);
    self->capacity = new_cap;
    self->count = (unsigned int)(0);
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    zi = zT_58;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(zi < new_cap)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_60 = 0;
    zT_61 = self->occupied;
    zT_61[zi] = zT_60;
    zT_62 = 1;
    zT_64 = zi + (unsigned int)((unsigned int)zT_62);
    zi = zT_64;
    goto z_bb_16;
    z_bb_15:
    zT_66 = 0;
    zT_67 = (unsigned int)zT_66;
    ri = zT_67;
    goto z_bb_17;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(ri < old_cap)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_69 = old_occupied[ri];
    if ((unsigned char)(zT_69 != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_73 = old_keys[ri];
    k = zT_73;
    zT_75 = old_values[ri];
    v = zT_75;
    zT_78 = new_cap - (unsigned int)(1);
    mask2 = zT_78;
    zT_81 = (unsigned int)((unsigned int)k) & mask2;
    idx = zT_81;
    goto z_bb_23;
    z_bb_22:
    zT_97 = 1;
    zT_99 = ri + (unsigned int)((unsigned int)zT_97);
    ri = zT_99;
    goto z_bb_20;
    z_bb_23:
    zT_82 = self->occupied;
    zT_83 = zT_82[idx];
    if ((unsigned char)(zT_83 != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_88 = (unsigned int)(idx + (unsigned int)(1)) & mask2;
    idx = zT_88;
    goto z_bb_26;
    z_bb_25:
    zT_89 = self->keys;
    zT_89[idx] = k;
    zT_90 = self->values;
    zT_90[idx] = v;
    zT_91 = 1;
    zT_92 = self->occupied;
    zT_92[idx] = zT_91;
    zT_93 = self->count;
    zT_94 = 1;
    self->count = (unsigned int)(zT_93 + (unsigned int)((unsigned int)zT_94));
    goto z_bb_22;
    z_bb_26:
    goto z_bb_23;
}

/* u32ToU32MapGetOrAddDense */
unsigned int zF_8879E7FF_u32ToU32MapGetOrAdd(zT_21D3708C_U32ToU32Map* self, unsigned int key) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    zT_21D3708C_U32ToU32Map* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 got;
    unsigned int v;
    unsigned int code;
    zT_3 = self;
    zT_4 = key;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    got = zT_5;
    zT_6 = got.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    v = got.value;
    return v;
    z_bb_2:
    zT_9 = self->count;
    zT_12 = (unsigned int)((unsigned int)zT_9) + (unsigned int)(1);
    code = zT_12;
    zT_13 = self;
    zT_14 = key;
    zT_15 = code;
    zF_26476265_u32ToU32MapPut(zT_13, zT_14, zT_15);
    return code;
}

/* u32ToU32MapPut */
void zF_26476265_u32ToU32MapPut(zT_21D3708C_U32ToU32Map* self, unsigned int key, unsigned int value) {
    unsigned int zT_3;
    unsigned int zT_6;
    zT_21D3708C_U32ToU32Map* zT_10;
    unsigned int zT_11;
    zT_21D3708C_U32ToU32Map* zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_21;
    unsigned char* zT_22;
    unsigned char zT_23;
    unsigned int* zT_26;
    unsigned int zT_27;
    unsigned int* zT_29;
    unsigned int zT_32;
    unsigned int* zT_33;
    unsigned int* zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned int mask;
    unsigned int i;
    zT_3 = self->count;
    zT_6 = self->capacity;
    if ((unsigned char)((unsigned int)(zT_3 * (unsigned int)(4)) >= (unsigned int)(zT_6 * (unsigned int)(3)))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zF_A54BFE8F_u32ToU32MapGrow(zT_10);
    goto z_bb_2;
    z_bb_2:
    zT_11 = self->capacity;
    if ((unsigned char)(zT_11 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self;
    zF_A54BFE8F_u32ToU32MapGrow(zT_14);
    goto z_bb_4;
    z_bb_4:
    zT_16 = self->capacity;
    zT_18 = zT_16 - (unsigned int)(1);
    mask = zT_18;
    zT_21 = (unsigned int)((unsigned int)key) & mask;
    i = zT_21;
    goto z_bb_5;
    z_bb_5:
    zT_22 = self->occupied;
    zT_23 = zT_22[i];
    if ((unsigned char)(zT_23 != (unsigned char)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_26 = self->keys;
    zT_27 = zT_26[i];
    if ((unsigned char)(zT_27 == key)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_33 = self->keys;
    zT_33[i] = key;
    zT_34 = self->values;
    zT_34[i] = value;
    zT_35 = 1;
    zT_36 = self->occupied;
    zT_36[i] = zT_35;
    zT_37 = self->count;
    zT_38 = 1;
    self->count = (unsigned int)(zT_37 + (unsigned int)((unsigned int)zT_38));
    return;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_29 = self->values;
    zT_29[i] = value;
    return;
    z_bb_10:
    zT_32 = (unsigned int)(i + (unsigned int)(1)) & mask;
    i = zT_32;
    goto z_bb_8;
}

/* u64ToU32MapInit */
zT_A4CE86B7_U64ToU32Map zF_986226E1_u64ToU32MapInit(zT_3E40CD83_Sand* alloc) {
    zT_A4CE86B7_U64ToU32Map zT_1;
    int zT_2;
    int zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_2 = 0;
    zT_1.keys = (zT_79FAE712_u64*)zT_2;
    zT_3 = 0;
    zT_1.values = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.occupied = (unsigned char*)zT_4;
    zT_5 = 0;
    zT_1.capacity = zT_5;
    zT_6 = 0;
    zT_1.count = zT_6;
    zT_1.alloc = alloc;
    return zT_1;
}

/* u64ToU32MapInitCap */
zT_A4CE86B7_U64ToU32Map zF_CE4144CF_u64ToU32MapInitCap(zT_3E40CD83_Sand* alloc, unsigned int hint) {
    unsigned int zT_3;
    unsigned int zT_4 = 0;
    zT_3E40CD83_Sand* zT_7;
    zT_A4CE86B7_U64ToU32Map zT_8 = {0};
    zT_3E40CD83_Sand* zT_10;
    zT_C6536882_EU_532 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    zT_3E40CD83_Sand* zT_21;
    zT_C6536882_EU_532 zT_27 = {0};
    unsigned char zT_28;
    unsigned char* zT_29;
    zT_3E40CD83_Sand* zT_32;
    zT_C6536882_EU_532 zT_38 = {0};
    unsigned char zT_39;
    unsigned char* zT_40;
    int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    int zT_47;
    unsigned int zT_49;
    zT_A4CE86B7_U64ToU32Map zT_50;
    zT_79FAE712_u64* zT_51;
    unsigned int* zT_52;
    unsigned char* zT_53;
    unsigned int zT_54;
    unsigned int cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    zT_3 = hint;
    zT_4 = zF_ADD0ED80_mapCapacityFromHint(zT_3);
    cap = zT_4;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = alloc;
    zT_8 = zF_986226E1_u64ToU32MapInit(zT_7);
    return zT_8;
    z_bb_2:
    zT_10 = alloc;
    zT_16 = zF_1395EB68_sandAlloc(zT_10, (unsigned int)((unsigned int)(8) * cap), (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw_keys = zT_18;
    zT_21 = alloc;
    zT_27 = zF_1395EB68_sandAlloc(zT_21, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_28 = zT_27.is_error;
    if (zT_28) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_29 = zT_27.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_vals = zT_29;
    zT_32 = alloc;
    zT_38 = zF_1395EB68_sandAlloc(zT_32, (unsigned int)((unsigned int)(1) * cap), (unsigned int)(4));
    zT_39 = zT_38.is_error;
    if (zT_39) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_40 = zT_38.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_occ = zT_40;
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    zi = zT_44;
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(zi < cap)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = 0;
    raw_occ[zi] = zT_46;
    goto z_bb_15;
    z_bb_14:
    zT_51 = (zT_79FAE712_u64*)raw_keys;
    zT_50.keys = zT_51;
    zT_52 = (unsigned int*)raw_vals;
    zT_50.values = zT_52;
    zT_53 = (unsigned char*)raw_occ;
    zT_50.occupied = zT_53;
    zT_50.capacity = cap;
    zT_54 = 0;
    zT_50.count = zT_54;
    zT_50.alloc = alloc;
    return zT_50;
    z_bb_15:
    zT_47 = 1;
    zT_49 = zi + (unsigned int)((unsigned int)zT_47);
    zi = zT_49;
    goto z_bb_12;
}

/* u64ToU32MapGet */
zT_BAEE192E_Opt_10 zF_A05A7BE1_u64ToU32MapGet(zT_A4CE86B7_U64ToU32Map* self, zT_79FAE712_u64 key) {
    unsigned int zT_2;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    zT_79FAE712_u64* zT_20;
    zT_79FAE712_u64 zT_21;
    unsigned int* zT_23;
    unsigned int zT_24;
    zT_BAEE192E_Opt_10 zT_25;
    unsigned int zT_28;
    zT_BAEE192E_Opt_10 zT_29 = {0};
    unsigned int mask;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->capacity;
    zT_9 = zT_7 - (unsigned int)(1);
    mask = zT_9;
    zT_15 = (unsigned int)((unsigned int)(unsigned int)((unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u)))) & mask;
    i = zT_15;
    goto z_bb_3;
    z_bb_3:
    zT_16 = self->occupied;
    zT_17 = zT_16[i];
    if ((unsigned char)(zT_17 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_20 = self->keys;
    zT_21 = zT_20[i];
    if ((unsigned char)(zT_21 == key)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_29.has_value = 0;
    return zT_29;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_23 = self->values;
    zT_24 = zT_23[i];
    zT_25.has_value = 1;
    zT_25.value = zT_24;
    return zT_25;
    z_bb_8:
    zT_28 = (unsigned int)(i + (unsigned int)(1)) & mask;
    i = zT_28;
    goto z_bb_6;
}

/* u64ToU32MapGrow */
void zF_FE9D19D4_u64ToU32MapGrow(zT_A4CE86B7_U64ToU32Map* self) {
    unsigned int zT_2;
    zT_79FAE712_u64* zT_4;
    unsigned int* zT_6;
    unsigned char* zT_8;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_17;
    zT_C6536882_EU_532 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_3E40CD83_Sand* zT_29;
    zT_C6536882_EU_532 zT_36 = {0};
    unsigned char zT_37;
    unsigned char* zT_38;
    zT_3E40CD83_Sand* zT_41;
    zT_C6536882_EU_532 zT_48 = {0};
    unsigned char zT_49;
    unsigned char* zT_50;
    int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned char* zT_61;
    int zT_62;
    unsigned int zT_64;
    int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    zT_79FAE712_u64 zT_73;
    unsigned int zT_75;
    unsigned int zT_78;
    unsigned int zT_84;
    unsigned char* zT_85;
    unsigned char zT_86;
    unsigned int zT_91;
    zT_79FAE712_u64* zT_92;
    unsigned int* zT_93;
    unsigned char zT_94;
    unsigned char* zT_95;
    unsigned int zT_96;
    int zT_97;
    int zT_100;
    unsigned int zT_102;
    unsigned int old_cap;
    zT_79FAE712_u64* old_keys;
    unsigned int* old_values;
    unsigned char* old_occupied;
    unsigned int new_cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    unsigned int ri;
    zT_79FAE712_u64 k;
    unsigned int v;
    unsigned int mask2;
    unsigned int idx;
    zT_2 = self->capacity;
    old_cap = zT_2;
    zT_4 = self->keys;
    old_keys = zT_4;
    zT_6 = self->values;
    old_values = zT_6;
    zT_8 = self->occupied;
    old_occupied = zT_8;
    if ((unsigned char)(old_cap < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_12 = old_cap * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_12;
    zT_17 = self->alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(8) * new_cap), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_26 = zT_24.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_keys = zT_26;
    zT_29 = self->alloc;
    zT_36 = zF_1395EB68_sandAlloc(zT_29, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_37 = zT_36.is_error;
    if (zT_37) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_38 = zT_36.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_vals = zT_38;
    zT_41 = self->alloc;
    zT_48 = zF_1395EB68_sandAlloc(zT_41, (unsigned int)((unsigned int)(1) * new_cap), (unsigned int)(4));
    zT_49 = zT_48.is_error;
    if (zT_49) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_50 = zT_48.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_occ = zT_50;
    self->keys = (zT_79FAE712_u64*)((zT_79FAE712_u64*)raw_keys);
    self->values = (unsigned int*)((unsigned int*)raw_vals);
    self->occupied = (unsigned char*)((unsigned char*)raw_occ);
    self->capacity = new_cap;
    self->count = (unsigned int)(0);
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    zi = zT_58;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(zi < new_cap)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_60 = 0;
    zT_61 = self->occupied;
    zT_61[zi] = zT_60;
    zT_62 = 1;
    zT_64 = zi + (unsigned int)((unsigned int)zT_62);
    zi = zT_64;
    goto z_bb_16;
    z_bb_15:
    zT_66 = 0;
    zT_67 = (unsigned int)zT_66;
    ri = zT_67;
    goto z_bb_17;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(ri < old_cap)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_69 = old_occupied[ri];
    if ((unsigned char)(zT_69 != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_73 = old_keys[ri];
    k = zT_73;
    zT_75 = old_values[ri];
    v = zT_75;
    zT_78 = new_cap - (unsigned int)(1);
    mask2 = zT_78;
    zT_84 = (unsigned int)((unsigned int)(unsigned int)((unsigned int)(zT_79FAE712_u64)(k & (zT_79FAE712_u64)(4294967295u)))) & mask2;
    idx = zT_84;
    goto z_bb_23;
    z_bb_22:
    zT_100 = 1;
    zT_102 = ri + (unsigned int)((unsigned int)zT_100);
    ri = zT_102;
    goto z_bb_20;
    z_bb_23:
    zT_85 = self->occupied;
    zT_86 = zT_85[idx];
    if ((unsigned char)(zT_86 != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_91 = (unsigned int)(idx + (unsigned int)(1)) & mask2;
    idx = zT_91;
    goto z_bb_26;
    z_bb_25:
    zT_92 = self->keys;
    zT_92[idx] = k;
    zT_93 = self->values;
    zT_93[idx] = v;
    zT_94 = 1;
    zT_95 = self->occupied;
    zT_95[idx] = zT_94;
    zT_96 = self->count;
    zT_97 = 1;
    self->count = (unsigned int)(zT_96 + (unsigned int)((unsigned int)zT_97));
    goto z_bb_22;
    z_bb_26:
    goto z_bb_23;
}

/* u64ToU32MapPut */
void zF_B6EB812C_u64ToU32MapPut(zT_A4CE86B7_U64ToU32Map* self, zT_79FAE712_u64 key, unsigned int value) {
    unsigned int zT_3;
    unsigned int zT_6;
    zT_A4CE86B7_U64ToU32Map* zT_10;
    unsigned int zT_11;
    zT_A4CE86B7_U64ToU32Map* zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_24;
    unsigned char* zT_25;
    unsigned char zT_26;
    zT_79FAE712_u64* zT_29;
    zT_79FAE712_u64 zT_30;
    unsigned int* zT_32;
    unsigned int zT_35;
    zT_79FAE712_u64* zT_36;
    unsigned int* zT_37;
    unsigned char zT_38;
    unsigned char* zT_39;
    unsigned int zT_40;
    int zT_41;
    unsigned int mask;
    unsigned int i;
    zT_3 = self->count;
    zT_6 = self->capacity;
    if ((unsigned char)((unsigned int)(zT_3 * (unsigned int)(4)) >= (unsigned int)(zT_6 * (unsigned int)(3)))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zF_FE9D19D4_u64ToU32MapGrow(zT_10);
    goto z_bb_2;
    z_bb_2:
    zT_11 = self->capacity;
    if ((unsigned char)(zT_11 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self;
    zF_FE9D19D4_u64ToU32MapGrow(zT_14);
    goto z_bb_4;
    z_bb_4:
    zT_16 = self->capacity;
    zT_18 = zT_16 - (unsigned int)(1);
    mask = zT_18;
    zT_24 = (unsigned int)((unsigned int)(unsigned int)((unsigned int)(zT_79FAE712_u64)(key & (zT_79FAE712_u64)(4294967295u)))) & mask;
    i = zT_24;
    goto z_bb_5;
    z_bb_5:
    zT_25 = self->occupied;
    zT_26 = zT_25[i];
    if ((unsigned char)(zT_26 != (unsigned char)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_29 = self->keys;
    zT_30 = zT_29[i];
    if ((unsigned char)(zT_30 == key)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_36 = self->keys;
    zT_36[i] = key;
    zT_37 = self->values;
    zT_37[i] = value;
    zT_38 = 1;
    zT_39 = self->occupied;
    zT_39[i] = zT_38;
    zT_40 = self->count;
    zT_41 = 1;
    self->count = (unsigned int)(zT_40 + (unsigned int)((unsigned int)zT_41));
    return;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_32 = self->values;
    zT_32[i] = value;
    return;
    z_bb_10:
    zT_35 = (unsigned int)(i + (unsigned int)(1)) & mask;
    i = zT_35;
    goto z_bb_8;
}

/* u32ToU64MapInit */
zT_89877D19_U32ToU64Map zF_A8016047_u32ToU64MapInit(zT_3E40CD83_Sand* alloc) {
    zT_89877D19_U32ToU64Map zT_1;
    int zT_2;
    int zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_2 = 0;
    zT_1.keys = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.values = (zT_79FAE712_u64*)zT_3;
    zT_4 = 0;
    zT_1.occupied = (unsigned char*)zT_4;
    zT_5 = 0;
    zT_1.capacity = zT_5;
    zT_6 = 0;
    zT_1.count = zT_6;
    zT_1.alloc = alloc;
    return zT_1;
}

/* u32ToU64MapInitCap */
zT_89877D19_U32ToU64Map zF_9FD4CEE5_u32ToU64MapInitCap(zT_3E40CD83_Sand* alloc, unsigned int hint) {
    unsigned int zT_3;
    unsigned int zT_4 = 0;
    zT_3E40CD83_Sand* zT_7;
    zT_89877D19_U32ToU64Map zT_8 = {0};
    zT_3E40CD83_Sand* zT_10;
    zT_C6536882_EU_532 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    zT_3E40CD83_Sand* zT_21;
    zT_C6536882_EU_532 zT_27 = {0};
    unsigned char zT_28;
    unsigned char* zT_29;
    zT_3E40CD83_Sand* zT_32;
    zT_C6536882_EU_532 zT_38 = {0};
    unsigned char zT_39;
    unsigned char* zT_40;
    int zT_43;
    unsigned int zT_44;
    unsigned char zT_46;
    int zT_47;
    unsigned int zT_49;
    zT_89877D19_U32ToU64Map zT_50;
    unsigned int* zT_51;
    zT_79FAE712_u64* zT_52;
    unsigned char* zT_53;
    unsigned int zT_54;
    unsigned int cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    zT_3 = hint;
    zT_4 = zF_ADD0ED80_mapCapacityFromHint(zT_3);
    cap = zT_4;
    if ((unsigned char)(cap == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = alloc;
    zT_8 = zF_A8016047_u32ToU64MapInit(zT_7);
    return zT_8;
    z_bb_2:
    zT_10 = alloc;
    zT_16 = zF_1395EB68_sandAlloc(zT_10, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_18 = zT_16.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw_keys = zT_18;
    zT_21 = alloc;
    zT_27 = zF_1395EB68_sandAlloc(zT_21, (unsigned int)((unsigned int)(8) * cap), (unsigned int)(4));
    zT_28 = zT_27.is_error;
    if (zT_28) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    pal_trap();
    z_bb_7:
    zT_29 = zT_27.data.payload;
    goto z_bb_8;
    z_bb_8:
    raw_vals = zT_29;
    zT_32 = alloc;
    zT_38 = zF_1395EB68_sandAlloc(zT_32, (unsigned int)((unsigned int)(1) * cap), (unsigned int)(4));
    zT_39 = zT_38.is_error;
    if (zT_39) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    pal_trap();
    z_bb_10:
    zT_40 = zT_38.data.payload;
    goto z_bb_11;
    z_bb_11:
    raw_occ = zT_40;
    zT_43 = 0;
    zT_44 = (unsigned int)zT_43;
    zi = zT_44;
    goto z_bb_12;
    z_bb_12:
    if ((unsigned char)(zi < cap)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_46 = 0;
    raw_occ[zi] = zT_46;
    goto z_bb_15;
    z_bb_14:
    zT_51 = (unsigned int*)raw_keys;
    zT_50.keys = zT_51;
    zT_52 = (zT_79FAE712_u64*)raw_vals;
    zT_50.values = zT_52;
    zT_53 = (unsigned char*)raw_occ;
    zT_50.occupied = zT_53;
    zT_50.capacity = cap;
    zT_54 = 0;
    zT_50.count = zT_54;
    zT_50.alloc = alloc;
    return zT_50;
    z_bb_15:
    zT_47 = 1;
    zT_49 = zi + (unsigned int)((unsigned int)zT_47);
    zi = zT_49;
    goto z_bb_12;
}

/* u32ToU64MapGet */
zT_BBEE1AC1_Opt_11 zF_6233601B_u32ToU64MapGet(zT_89877D19_U32ToU64Map* self, unsigned int key) {
    unsigned int zT_2;
    zT_BBEE1AC1_Opt_11 zT_5 = {0};
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned char* zT_13;
    unsigned char zT_14;
    unsigned int* zT_17;
    unsigned int zT_18;
    zT_79FAE712_u64* zT_20;
    zT_79FAE712_u64 zT_21;
    zT_BBEE1AC1_Opt_11 zT_22;
    unsigned int zT_25;
    zT_BBEE1AC1_Opt_11 zT_26 = {0};
    unsigned int mask;
    unsigned int i;
    zT_2 = self->capacity;
    if ((unsigned char)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_7 = self->capacity;
    zT_9 = zT_7 - (unsigned int)(1);
    mask = zT_9;
    zT_12 = (unsigned int)((unsigned int)key) & mask;
    i = zT_12;
    goto z_bb_3;
    z_bb_3:
    zT_13 = self->occupied;
    zT_14 = zT_13[i];
    if ((unsigned char)(zT_14 != (unsigned char)(0))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_17 = self->keys;
    zT_18 = zT_17[i];
    if ((unsigned char)(zT_18 == key)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_26.has_value = 0;
    return zT_26;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_20 = self->values;
    zT_21 = zT_20[i];
    zT_22.has_value = 1;
    zT_22.value = zT_21;
    return zT_22;
    z_bb_8:
    zT_25 = (unsigned int)(i + (unsigned int)(1)) & mask;
    i = zT_25;
    goto z_bb_6;
}

/* u32ToU64MapGrow */
void zF_28C8D766_u32ToU64MapGrow(zT_89877D19_U32ToU64Map* self) {
    unsigned int zT_2;
    unsigned int* zT_4;
    zT_79FAE712_u64* zT_6;
    unsigned char* zT_8;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_17;
    zT_C6536882_EU_532 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_3E40CD83_Sand* zT_29;
    zT_C6536882_EU_532 zT_36 = {0};
    unsigned char zT_37;
    unsigned char* zT_38;
    zT_3E40CD83_Sand* zT_41;
    zT_C6536882_EU_532 zT_48 = {0};
    unsigned char zT_49;
    unsigned char* zT_50;
    int zT_57;
    unsigned int zT_58;
    unsigned char zT_60;
    unsigned char* zT_61;
    int zT_62;
    unsigned int zT_64;
    int zT_66;
    unsigned int zT_67;
    unsigned char zT_69;
    unsigned int zT_73;
    zT_79FAE712_u64 zT_75;
    unsigned int zT_78;
    unsigned int zT_81;
    unsigned char* zT_82;
    unsigned char zT_83;
    unsigned int zT_88;
    unsigned int* zT_89;
    zT_79FAE712_u64* zT_90;
    unsigned char zT_91;
    unsigned char* zT_92;
    unsigned int zT_93;
    int zT_94;
    int zT_97;
    unsigned int zT_99;
    unsigned int old_cap;
    unsigned int* old_keys;
    zT_79FAE712_u64* old_values;
    unsigned char* old_occupied;
    unsigned int new_cap;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int zi;
    unsigned int ri;
    unsigned int k;
    zT_79FAE712_u64 v;
    unsigned int mask2;
    unsigned int idx;
    zT_2 = self->capacity;
    old_cap = zT_2;
    zT_4 = self->keys;
    old_keys = zT_4;
    zT_6 = self->values;
    old_values = zT_6;
    zT_8 = self->occupied;
    old_occupied = zT_8;
    if ((unsigned char)(old_cap < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = 8;
    goto z_bb_3;
    z_bb_2:
    zT_12 = old_cap * (unsigned int)(2);
    goto z_bb_3;
    z_bb_3:
    new_cap = zT_12;
    zT_17 = self->alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_26 = zT_24.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_keys = zT_26;
    zT_29 = self->alloc;
    zT_36 = zF_1395EB68_sandAlloc(zT_29, (unsigned int)((unsigned int)(8) * new_cap), (unsigned int)(4));
    zT_37 = zT_36.is_error;
    if (zT_37) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_38 = zT_36.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_vals = zT_38;
    zT_41 = self->alloc;
    zT_48 = zF_1395EB68_sandAlloc(zT_41, (unsigned int)((unsigned int)(1) * new_cap), (unsigned int)(4));
    zT_49 = zT_48.is_error;
    if (zT_49) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_50 = zT_48.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw_occ = zT_50;
    self->keys = (unsigned int*)((unsigned int*)raw_keys);
    self->values = (zT_79FAE712_u64*)((zT_79FAE712_u64*)raw_vals);
    self->occupied = (unsigned char*)((unsigned char*)raw_occ);
    self->capacity = new_cap;
    self->count = (unsigned int)(0);
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    zi = zT_58;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(zi < new_cap)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_60 = 0;
    zT_61 = self->occupied;
    zT_61[zi] = zT_60;
    zT_62 = 1;
    zT_64 = zi + (unsigned int)((unsigned int)zT_62);
    zi = zT_64;
    goto z_bb_16;
    z_bb_15:
    zT_66 = 0;
    zT_67 = (unsigned int)zT_66;
    ri = zT_67;
    goto z_bb_17;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    if ((unsigned char)(ri < old_cap)) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_69 = old_occupied[ri];
    if ((unsigned char)(zT_69 != (unsigned char)(0))) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    return;
    z_bb_20:
    goto z_bb_17;
    z_bb_21:
    zT_73 = old_keys[ri];
    k = zT_73;
    zT_75 = old_values[ri];
    v = zT_75;
    zT_78 = new_cap - (unsigned int)(1);
    mask2 = zT_78;
    zT_81 = (unsigned int)((unsigned int)k) & mask2;
    idx = zT_81;
    goto z_bb_23;
    z_bb_22:
    zT_97 = 1;
    zT_99 = ri + (unsigned int)((unsigned int)zT_97);
    ri = zT_99;
    goto z_bb_20;
    z_bb_23:
    zT_82 = self->occupied;
    zT_83 = zT_82[idx];
    if ((unsigned char)(zT_83 != (unsigned char)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_88 = (unsigned int)(idx + (unsigned int)(1)) & mask2;
    idx = zT_88;
    goto z_bb_26;
    z_bb_25:
    zT_89 = self->keys;
    zT_89[idx] = k;
    zT_90 = self->values;
    zT_90[idx] = v;
    zT_91 = 1;
    zT_92 = self->occupied;
    zT_92[idx] = zT_91;
    zT_93 = self->count;
    zT_94 = 1;
    self->count = (unsigned int)(zT_93 + (unsigned int)((unsigned int)zT_94));
    goto z_bb_22;
    z_bb_26:
    goto z_bb_23;
}

/* u32ToU64MapPut */
void zF_75699BAA_u32ToU64MapPut(zT_89877D19_U32ToU64Map* self, unsigned int key, zT_79FAE712_u64 value) {
    unsigned int zT_3;
    unsigned int zT_6;
    zT_89877D19_U32ToU64Map* zT_10;
    unsigned int zT_11;
    zT_89877D19_U32ToU64Map* zT_14;
    unsigned int zT_16;
    unsigned int zT_18;
    unsigned int zT_21;
    unsigned char* zT_22;
    unsigned char zT_23;
    unsigned int* zT_26;
    unsigned int zT_27;
    zT_79FAE712_u64* zT_29;
    unsigned int zT_32;
    unsigned int* zT_33;
    zT_79FAE712_u64* zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned int mask;
    unsigned int i;
    zT_3 = self->count;
    zT_6 = self->capacity;
    if ((unsigned char)((unsigned int)(zT_3 * (unsigned int)(4)) >= (unsigned int)(zT_6 * (unsigned int)(3)))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_10 = self;
    zF_28C8D766_u32ToU64MapGrow(zT_10);
    goto z_bb_2;
    z_bb_2:
    zT_11 = self->capacity;
    if ((unsigned char)(zT_11 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_14 = self;
    zF_28C8D766_u32ToU64MapGrow(zT_14);
    goto z_bb_4;
    z_bb_4:
    zT_16 = self->capacity;
    zT_18 = zT_16 - (unsigned int)(1);
    mask = zT_18;
    zT_21 = (unsigned int)((unsigned int)key) & mask;
    i = zT_21;
    goto z_bb_5;
    z_bb_5:
    zT_22 = self->occupied;
    zT_23 = zT_22[i];
    if ((unsigned char)(zT_23 != (unsigned char)(0))) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_26 = self->keys;
    zT_27 = zT_26[i];
    if ((unsigned char)(zT_27 == key)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_33 = self->keys;
    zT_33[i] = key;
    zT_34 = self->values;
    zT_34[i] = value;
    zT_35 = 1;
    zT_36 = self->occupied;
    zT_36[i] = zT_35;
    zT_37 = self->count;
    zT_38 = 1;
    self->count = (unsigned int)(zT_37 + (unsigned int)((unsigned int)zT_38));
    return;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_29 = self->values;
    zT_29[i] = value;
    return;
    z_bb_10:
    zT_32 = (unsigned int)(i + (unsigned int)(1)) & mask;
    i = zT_32;
    goto z_bb_8;
}

/* __module_init */
void zF_780653D2___module_init_16(void) {
    zT_3E40CD83_Sand zT_0 = {0};
    zG_3E40CD83_Sand = zT_0;
    return;
}

/* EOF */
