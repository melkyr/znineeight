#ifndef ZIG_MODULE_AST_2FA12982_H
#define ZIG_MODULE_AST_2FA12982_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "pal_388A8A1B.h"
#include "panic_CE239B25.h"
#include "format_0AEF880C.h"
#include "spill_store_AC8E76BA.h"

#ifndef ZIG_STRUCT_zT_243D6A41_FnProto
#define ZIG_STRUCT_zT_243D6A41_FnProto
struct zT_243D6A41_FnProto {
	unsigned int name_id;
	unsigned int params_start;
	unsigned short params_count;
	unsigned char call_conv;
	unsigned int return_type_node;
};
#endif /* ZIG_STRUCT_zT_243D6A41_FnProto */
#ifndef ZIG_STRUCT_zT_E2FE8472_NodeBlockInfo
#define ZIG_STRUCT_zT_E2FE8472_NodeBlockInfo
struct zT_E2FE8472_NodeBlockInfo {
	unsigned int disk_off;
	unsigned char resident;
	unsigned int slot;
};
#endif /* ZIG_STRUCT_zT_E2FE8472_NodeBlockInfo */

/* Forward declarations */
void zF_8B163A32_u32ArrayListAppen_1(unsigned int**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, unsigned int);
void zF_FA105BA5_u64ArrayListAppendI(zT_79FAE712_u64**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, zT_79FAE712_u64);
void zF_51A5BB50_f64ArrayListAppendI(double**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, double);
void zF_F22CE022_fnProtoArrayListApp(zT_243D6A41_FnProto**, unsigned int*, unsigned int*, zT_3E40CD83_Sand*, zT_243D6A41_FnProto);
zT_6B0A7D14_AstStore zF_D9F91436_astStoreInit(zT_3E40CD83_Sand*);
void zF_A0C14FAA_astStoreInitValuePo(zT_6B0A7D14_AstStore*);
void zF_2A507339_astStoreSetSpillPat(zT_6B0A7D14_AstStore*, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_21027FAE_astStoreCloseSpill(zT_6B0A7D14_AstStore*);
void zF_F58FD6FA_valuePoolInit(zT_01BE9D46_AstValuePool*, unsigned int);
void zF_35B9B6EC_astStoreSetValuePoo(zT_6B0A7D14_AstStore*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_E407C3F0_valuePoolOpen(zT_6B0A7D14_AstStore*, zT_01BE9D46_AstValuePool*);
void zF_76A14F48_valuePoolEnsureHead(zT_6B0A7D14_AstStore*, zT_01BE9D46_AstValuePool*);
unsigned int zF_B73DE9D0_valuePoolAppend(zT_6B0A7D14_AstStore*, zT_01BE9D46_AstValuePool*, zT_79FAE712_u64);
void zF_82730D0C_valuePoolEnsureCach(zT_6B0A7D14_AstStore*, zT_01BE9D46_AstValuePool*);
unsigned int zF_73B68926_valuePoolCacheSlot(zT_6B0A7D14_AstStore*, zT_01BE9D46_AstValuePool*, unsigned int);
zT_79FAE712_u64 zF_FDA4EEAD_valuePoolGetValue(zT_6B0A7D14_AstStore*, zT_01BE9D46_AstValuePool*, unsigned int);
void zF_131F3CDC_valuePoolClose(zT_6B0A7D14_AstStore*, zT_01BE9D46_AstValuePool*);
unsigned int zF_53458827_astStoreIdentifier(zT_6B0A7D14_AstStore*, unsigned int);
zT_79FAE712_u64 zF_678B9A72_astStoreIntValue(zT_6B0A7D14_AstStore*, unsigned int);
unsigned int zF_6C9FF72F_astStoreAddNode(zT_6B0A7D14_AstStore*, zT_8143F551_AstKind, unsigned char, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int);
void zF_3A477168_astStoreNodeAppend(zT_6B0A7D14_AstStore*, zT_22A7C88B_AstNode, unsigned int);
void zF_1D4F4DCE_astBlockTableEnsure(zT_6B0A7D14_AstStore*, unsigned int);
void zF_548211A2_astBlockOpenSpill(zT_6B0A7D14_AstStore*);
void zF_D45C652C_astBlockSpillHead(zT_6B0A7D14_AstStore*);
void zF_BA06A188_astBlockAdvanceHead(zT_6B0A7D14_AstStore*, unsigned int);
void zF_420B3B4B_astSlotEnsureNodeCa(zT_6B0A7D14_AstStore*, unsigned int, unsigned int);
void zF_5184AF33_astSlotEnsurePayloa(zT_6B0A7D14_AstStore*, unsigned int, unsigned int);
void zF_8D6C3544_astSlotEnsureFull(zT_6B0A7D14_AstStore*, unsigned int);
unsigned int zF_E0B03A59_astSlotAcquire(zT_6B0A7D14_AstStore*);
void zF_4891718F_astBlockFaultIn(zT_6B0A7D14_AstStore*, unsigned int);
zT_22A7C88B_AstNode zF_FCDD1D35_astStoreNodeAt(zT_6B0A7D14_AstStore*, unsigned int);
unsigned int zF_583E993C_astStoreAddExtraChi(zT_6B0A7D14_AstStore*, zT_3CB0179A_Slice_zT_05F374B1_u);
unsigned int zF_03CE8CAB_astStoreGetExtraChi(zT_6B0A7D14_AstStore*, zT_79FAE712_u64);
unsigned int zF_E5B10421_astStoreGetExtraChi(zT_6B0A7D14_AstStore*, zT_79FAE712_u64, unsigned int);
unsigned int zF_67ADE488_astStoreGetExtraChi(zT_6B0A7D14_AstStore*, zT_79FAE712_u64, zT_3CB0179A_Slice_zT_05F374B1_u);
unsigned int zF_884B7FF9_astStoreExtraChildA(zT_6B0A7D14_AstStore*, unsigned int);
zT_79FAE712_u64 zF_F956A1CA_astStoreExtraRangeA(zT_6B0A7D14_AstStore*, unsigned int);
unsigned int zF_8BA26B9E_astStoreNodePayload(zT_6B0A7D14_AstStore*, unsigned int);
zT_79FAE712_u64 zF_0E4E10C6_astStoreNodePayload(zT_6B0A7D14_AstStore*, unsigned int, zT_8143F551_AstKind);
unsigned int zF_152E19CB_astStoreNodeExtraCh(zT_6B0A7D14_AstStore*, unsigned int);
unsigned int zF_B10B1BC1_astStoreNodeExtraCh(zT_6B0A7D14_AstStore*, unsigned int, unsigned int);
unsigned int zF_111E5D28_astStoreNodeExtraCh(zT_6B0A7D14_AstStore*, unsigned int, zT_3CB0179A_Slice_zT_05F374B1_u);
unsigned int zF_E45552BF_astStoreAddIntLiter(zT_6B0A7D14_AstStore*, zT_79FAE712_u64, unsigned int, unsigned int);
unsigned int zF_2CAC92AE_astStoreAddCharLite(zT_6B0A7D14_AstStore*, zT_79FAE712_u64, unsigned int, unsigned int);
unsigned int zF_0CEAF68A_astStoreAddFloatLit(zT_6B0A7D14_AstStore*, double, unsigned int, unsigned int);
unsigned int zF_042235B9_astStoreAddStringLi(zT_6B0A7D14_AstStore*, unsigned int, unsigned int, unsigned int);
unsigned int zF_1DF77BD4_astStoreAddIdentifi(zT_6B0A7D14_AstStore*, zT_8143F551_AstKind, unsigned int, unsigned int, unsigned int);
unsigned int zF_F1F8D02B_astStoreAddFnProto(zT_6B0A7D14_AstStore*, zT_243D6A41_FnProto);
int zF_A5D7FF20_nodeHasExtraChildre(zT_8143F551_AstKind);
int zF_C395F6FD_nodeChildIsNode(zT_8143F551_AstKind, unsigned char);
int zF_BB9BCB30_nodeHasNodeExtraChi(zT_8143F551_AstKind);
void zF_D5CCA077_visitPreOrder(zT_6B0A7D14_AstStore*, unsigned int, zT_EEDBD622_FP_void_zT_6B0A7D14);
zT_79FAE712_u64 zF_65495966_astStoreComputeMemo(zT_6B0A7D14_AstStore*);
zT_79FAE712_u64 zF_27FFD5B8_valuePoolResident(zT_6B0A7D14_AstStore*, zT_01BE9D46_AstValuePool*);
void zF_780653D2___module_init_8(void);
/* Storage globals (extern decls) */
extern zT_8143F551_AstKind zG_8143F551_AstKind;
extern zT_6B0A7D14_AstStore zG_6B0A7D14_AstStore;
extern unsigned char* zG_CC2D7D2E_zzz_astnode_sz;

#endif /* ZIG_MODULE_AST_2FA12982_H */
