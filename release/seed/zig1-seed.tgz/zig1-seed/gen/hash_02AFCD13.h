#ifndef ZIG_MODULE_HASH_02AFCD13_H
#define ZIG_MODULE_HASH_02AFCD13_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"

#ifndef ZIG_STRUCT_zT_89877D19_U32ToU64Map
#define ZIG_STRUCT_zT_89877D19_U32ToU64Map
struct zT_89877D19_U32ToU64Map {
	unsigned int* keys;
	zT_79FAE712_u64* values;
	unsigned char* occupied;
	unsigned int capacity;
	unsigned int count;
	zT_3E40CD83_Sand* alloc;
};
#endif /* ZIG_STRUCT_zT_89877D19_U32ToU64Map */

/* Forward declarations */
unsigned int zF_ADD0ED80_mapCapacityFromHint(unsigned int);
unsigned int zF_B22E025B_fnv1a(zT_8F083A69_Slice_zT_0B42B2F8_u);
zT_21D3708C_U32ToU32Map zF_58BDA2DE_u32ToU32MapInit(zT_3E40CD83_Sand*);
zT_21D3708C_U32ToU32Map zF_619D56E6_u32ToU32MapInitCap(zT_3E40CD83_Sand*, unsigned int);
zT_BAEE192E_Opt_10 zF_F3EE5998_u32ToU32MapGet(zT_21D3708C_U32ToU32Map*, unsigned int);
void zF_A54BFE8F_u32ToU32MapGrow(zT_21D3708C_U32ToU32Map*);
unsigned int zF_8879E7FF_u32ToU32MapGetOrAdd(zT_21D3708C_U32ToU32Map*, unsigned int);
void zF_26476265_u32ToU32MapPut(zT_21D3708C_U32ToU32Map*, unsigned int, unsigned int);
zT_A4CE86B7_U64ToU32Map zF_986226E1_u64ToU32MapInit(zT_3E40CD83_Sand*);
zT_A4CE86B7_U64ToU32Map zF_CE4144CF_u64ToU32MapInitCap(zT_3E40CD83_Sand*, unsigned int);
zT_BAEE192E_Opt_10 zF_A05A7BE1_u64ToU32MapGet(zT_A4CE86B7_U64ToU32Map*, zT_79FAE712_u64);
void zF_FE9D19D4_u64ToU32MapGrow(zT_A4CE86B7_U64ToU32Map*);
void zF_B6EB812C_u64ToU32MapPut(zT_A4CE86B7_U64ToU32Map*, zT_79FAE712_u64, unsigned int);
zT_89877D19_U32ToU64Map zF_A8016047_u32ToU64MapInit(zT_3E40CD83_Sand*);
zT_89877D19_U32ToU64Map zF_9FD4CEE5_u32ToU64MapInitCap(zT_3E40CD83_Sand*, unsigned int);
zT_BBEE1AC1_Opt_11 zF_6233601B_u32ToU64MapGet(zT_89877D19_U32ToU64Map*, unsigned int);
void zF_28C8D766_u32ToU64MapGrow(zT_89877D19_U32ToU64Map*);
void zF_75699BAA_u32ToU64MapPut(zT_89877D19_U32ToU64Map*, unsigned int, zT_79FAE712_u64);
void zF_780653D2___module_init_16(void);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_HASH_02AFCD13_H */
