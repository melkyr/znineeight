#ifndef ZIG_MODULE_IMPORT_RESOLVER_58BB752E_H
#define ZIG_MODULE_IMPORT_RESOLVER_58BB752E_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "module_registry_03A5D1FC.h"
#include "pal_388A8A1B.h"
#include "lexer_23F0DAD4.h"
#include "parser_61A67AF1.h"
#include "ast_2FA12982.h"
#include "string_interner_51340A9F.h"
#include "diagnostics_B9C6175E.h"
#include "source_manager_0C564FCF.h"
#include "growable_array_6014E5AF.h"
#include "token_76C7CBBF.h"
#include "spill_store_AC8E76BA.h"


/* Forward declarations */
zT_BAEE192E_Opt_10 zF_EEBAC601_moduleRegistryParse(zT_072B53A6_ModuleRegistry*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*, zT_3E40CD83_Sand*, zT_6B0A7D14_AstStore*, zT_3E40CD83_Sand*, zT_3E40CD83_Sand*);
void zF_A46C0B58_moduleRegistryResol(zT_072B53A6_ModuleRegistry*, zT_3E40CD83_Sand*, zT_3E40CD83_Sand*, zT_6B0A7D14_AstStore*);
/* Storage globals (extern decls) */

#endif /* ZIG_MODULE_IMPORT_RESOLVER_58BB752E_H */
