#include "growable_array_6014E5AF.h"
zT_B687BB96_U32ArrayList zG_B687BB96_U32ArrayList;
zT_47B162D1_U8ArrayList zG_47B162D1_U8ArrayList;
/* u32ArrayListInit */
zT_B687BB96_U32ArrayList zF_8E537D0C_u32ArrayListInit(zT_3E40CD83_Sand* allocator) {
    zT_B687BB96_U32ArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* u32ArrayListEnsureCapacity */
void zF_1580F084_u32ArrayListEnsureC(zT_B687BB96_U32ArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_FBF0B3E4_EU_332 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    unsigned int* zT_29;
    unsigned int* zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned int* zT_33;
    unsigned int zT_34;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_35;
    unsigned int* zT_36;
    unsigned int zT_37;
    unsigned int zT_42;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->allocator;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (unsigned int*)raw;
    new_items = zT_29;
    zT_30 = self->items;
    zT_31 = self->len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_36 = zT_35.ptr;
    zT_37 = zT_35.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((int)(i < zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_36[i];
    new_items[i] = item;
    zT_42 = i + (unsigned int)(1);
    i = zT_42;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* u32ArrayListAppend */
void zF_62F717A2_u32ArrayListAppend(zT_B687BB96_U32ArrayList* self, unsigned int value) {
    zT_B687BB96_U32ArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_1580F084_u32ArrayListEnsureC(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* u32ArrayListPopOrNull */
zT_BAEE192E_Opt_10 zF_3F5916E1_u32ArrayListPopOrNu(zT_B687BB96_U32ArrayList* self) {
    unsigned int zT_1;
    int zT_2;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_1 = self->len;
    zT_2 = 0;
    if ((int)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->len;
    zT_6 = 1;
    self->len = (unsigned int)(zT_5 - (unsigned int)((unsigned int)zT_6));
    zT_9 = self->items;
    zT_10 = self->len;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
}

/* u32ArrayListGetSlice */
zT_3CB0179A_Slice_zT_05F374B1_u zF_281E4968_u32ArrayListGetSlic(zT_B687BB96_U32ArrayList* self) {
    unsigned int* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned int* zT_4;
    unsigned int zT_5;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* byteArrayListInit */
zT_47B162D1_U8ArrayList zF_E9FF0E66_byteArrayListInit(zT_3E40CD83_Sand* allocator) {
    zT_47B162D1_U8ArrayList zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_2 = 0;
    zT_1.items = (unsigned char*)zT_2;
    zT_3 = 0;
    zT_1.len = zT_3;
    zT_4 = 0;
    zT_1.capacity = zT_4;
    zT_1.allocator = allocator;
    return zT_1;
}

/* byteArrayListGrow */
void zF_59A66857_byteArrayListGrow(zT_47B162D1_U8ArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    unsigned char* zT_26;
    unsigned int zT_28;
    zT_7532B98D_Opt_233 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_FBF0B3E4_EU_332 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_49;
    unsigned char* zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned char* zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned char* zT_56;
    unsigned int zT_57;
    unsigned int zT_62;
    unsigned int new_cap;
    zT_7532B98D_Opt_233 grown;
    unsigned char* raw;
    unsigned char* new_items;
    unsigned char item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->capacity;
    zT_17 = 0;
    if ((int)(zT_16 > (unsigned int)zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = self->allocator;
    zT_26 = self->items;
    zT_28 = self->capacity;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), (unsigned int)(zT_28 * (unsigned int)(1)), (unsigned int)(new_cap * (unsigned int)(1)), (unsigned int)(1));
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_37 = self->allocator;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(1) * new_cap), (unsigned int)(1));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_46 = zT_44.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    zT_49 = (unsigned char*)raw;
    new_items = zT_49;
    zT_50 = self->items;
    zT_51 = self->len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_62 = i + (unsigned int)(1);
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* byteArrayListAppend */
void zF_463FE7A4_byteArrayListAppend(zT_47B162D1_U8ArrayList* self, unsigned char value) {
    zT_47B162D1_U8ArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    unsigned char* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_59A66857_byteArrayListGrow(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* byteArrayListGetSlice */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_2ADA0742_byteArrayListGetSli(zT_47B162D1_U8ArrayList* self) {
    unsigned char* zT_1;
    unsigned int zT_2;
    int zT_3;
    unsigned char* zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* astNodeArrayListInit */
zT_1386C3E8_AstNodeArrayList zF_6F8101FA_astNodeArrayListIni(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_1386C3E8_AstNodeArrayList zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_1386C3E8_AstNodeArrayList* zT_7;
    unsigned int zT_8;
    zT_1386C3E8_AstNodeArrayList list;
    zT_4 = 0;
    zT_3.items = (zT_22A7C88B_AstNode*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = &list;
    zT_8 = initial_capacity;
    zF_BA440392_astNodeArrayListEns(zT_7, zT_8);
    return list;
}

/* astNodeArrayListEnsureCapacity */
void zF_BA440392_astNodeArrayListEns(zT_1386C3E8_AstNodeArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_FBF0B3E4_EU_332 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_22A7C88B_AstNode* zT_29;
    zT_22A7C88B_AstNode* zT_30;
    unsigned int zT_31;
    int zT_32;
    zT_22A7C88B_AstNode* zT_33;
    unsigned int zT_34;
    zT_8FBDC967_Slice_zT_22A7C88B_A zT_35;
    zT_22A7C88B_AstNode* zT_36;
    unsigned int zT_37;
    unsigned int zT_42;
    unsigned int new_cap;
    unsigned char* raw;
    zT_22A7C88B_AstNode* new_items;
    zT_22A7C88B_AstNode item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->allocator;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(24) * new_cap), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (zT_22A7C88B_AstNode*)raw;
    new_items = zT_29;
    zT_30 = self->items;
    zT_31 = self->len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_36 = zT_35.ptr;
    zT_37 = zT_35.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((int)(i < zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_36[i];
    new_items[i] = item;
    zT_42 = i + (unsigned int)(1);
    i = zT_42;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* astNodeArrayListAppend */
void zF_FFA68CD0_astNodeArrayListApp(zT_1386C3E8_AstNodeArrayList* self, zT_22A7C88B_AstNode value) {
    zT_1386C3E8_AstNodeArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_22A7C88B_AstNode* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_BA440392_astNodeArrayListEns(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* astNodeArrayListGetSlice */
zT_8FBDC967_Slice_zT_22A7C88B_A zF_BD2D926E_astNodeArrayListGet(zT_1386C3E8_AstNodeArrayList* self) {
    zT_22A7C88B_AstNode* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_22A7C88B_AstNode* zT_4;
    unsigned int zT_5;
    zT_8FBDC967_Slice_zT_22A7C88B_A zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* u64ArrayListInit */
zT_C4A0A7DB_U64ArrayList zF_477F0605_u64ArrayListInit(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_C4A0A7DB_U64ArrayList zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_C4A0A7DB_U64ArrayList* zT_7;
    unsigned int zT_8;
    zT_C4A0A7DB_U64ArrayList list;
    zT_4 = 0;
    zT_3.items = (zT_79FAE712_u64*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = &list;
    zT_8 = initial_capacity;
    zF_111B1CFD_u64ArrayListEnsureC(zT_7, zT_8);
    return list;
}

/* u64ArrayListEnsureCapacity */
void zF_111B1CFD_u64ArrayListEnsureC(zT_C4A0A7DB_U64ArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_FBF0B3E4_EU_332 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_79FAE712_u64* zT_29;
    zT_79FAE712_u64* zT_30;
    unsigned int zT_31;
    int zT_32;
    zT_79FAE712_u64* zT_33;
    unsigned int zT_34;
    zT_A62C5D8D_Slice_zT_79FAE712_u zT_35;
    zT_79FAE712_u64* zT_36;
    unsigned int zT_37;
    unsigned int zT_42;
    unsigned int new_cap;
    unsigned char* raw;
    zT_79FAE712_u64* new_items;
    zT_79FAE712_u64 item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->allocator;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(8) * new_cap), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (zT_79FAE712_u64*)raw;
    new_items = zT_29;
    zT_30 = self->items;
    zT_31 = self->len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_36 = zT_35.ptr;
    zT_37 = zT_35.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((int)(i < zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_36[i];
    new_items[i] = item;
    zT_42 = i + (unsigned int)(1);
    i = zT_42;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* u64ArrayListAppend */
void zF_A553AD3B_u64ArrayListAppend(zT_C4A0A7DB_U64ArrayList* self, zT_79FAE712_u64 value) {
    zT_C4A0A7DB_U64ArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_79FAE712_u64* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_111B1CFD_u64ArrayListEnsureC(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* u64ArrayListGetSlice */
zT_A62C5D8D_Slice_zT_79FAE712_u zF_87EC4681_u64ArrayListGetSlic(zT_C4A0A7DB_U64ArrayList* self) {
    zT_79FAE712_u64* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_79FAE712_u64* zT_4;
    unsigned int zT_5;
    zT_A62C5D8D_Slice_zT_79FAE712_u zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* f64ArrayListInit */
zT_AB1FE668_F64ArrayList zF_5950A33A_f64ArrayListInit(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_AB1FE668_F64ArrayList zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_AB1FE668_F64ArrayList* zT_7;
    unsigned int zT_8;
    zT_AB1FE668_F64ArrayList list;
    zT_4 = 0;
    zT_3.items = (double*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = &list;
    zT_8 = initial_capacity;
    zF_7F2FDCD2_f64ArrayListEnsureC(zT_7, zT_8);
    return list;
}

/* f64ArrayListEnsureCapacity */
void zF_7F2FDCD2_f64ArrayListEnsureC(zT_AB1FE668_F64ArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_FBF0B3E4_EU_332 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    double* zT_29;
    double* zT_30;
    unsigned int zT_31;
    int zT_32;
    double* zT_33;
    unsigned int zT_34;
    zT_ACF60AF6_Slice_zT_00435AEB_f zT_35;
    double* zT_36;
    unsigned int zT_37;
    unsigned int zT_42;
    unsigned int new_cap;
    unsigned char* raw;
    double* new_items;
    double item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->allocator;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(8) * new_cap), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (double*)raw;
    new_items = zT_29;
    zT_30 = self->items;
    zT_31 = self->len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_36 = zT_35.ptr;
    zT_37 = zT_35.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((int)(i < zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_36[i];
    new_items[i] = item;
    zT_42 = i + (unsigned int)(1);
    i = zT_42;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* f64ArrayListAppend */
void zF_0317E610_f64ArrayListAppend(zT_AB1FE668_F64ArrayList* self, double value) {
    zT_AB1FE668_F64ArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    double* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_7F2FDCD2_f64ArrayListEnsureC(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* f64ArrayListGetSlice */
zT_ACF60AF6_Slice_zT_00435AEB_f zF_96EB7CAE_f64ArrayListGetSlic(zT_AB1FE668_F64ArrayList* self) {
    double* zT_1;
    unsigned int zT_2;
    int zT_3;
    double* zT_4;
    unsigned int zT_5;
    zT_ACF60AF6_Slice_zT_00435AEB_f zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* fnProtoArrayListInit */
zT_CCB21906_FnProtoArrayList zF_315F8F5C_fnProtoArrayListIni(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_CCB21906_FnProtoArrayList zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_CCB21906_FnProtoArrayList* zT_7;
    unsigned int zT_8;
    zT_CCB21906_FnProtoArrayList list;
    zT_4 = 0;
    zT_3.items = (zT_243D6A41_FnProto*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = &list;
    zT_8 = initial_capacity;
    zF_D57F7CF4_fnProtoArrayListEns(zT_7, zT_8);
    return list;
}

/* fnProtoArrayListEnsureCapacity */
void zF_D57F7CF4_fnProtoArrayListEns(zT_CCB21906_FnProtoArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_FBF0B3E4_EU_332 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_243D6A41_FnProto* zT_29;
    zT_243D6A41_FnProto* zT_30;
    unsigned int zT_31;
    int zT_32;
    zT_243D6A41_FnProto* zT_33;
    unsigned int zT_34;
    zT_91F8F99F_Slice_zT_243D6A41_F zT_35;
    zT_243D6A41_FnProto* zT_36;
    unsigned int zT_37;
    unsigned int zT_42;
    unsigned int new_cap;
    unsigned char* raw;
    zT_243D6A41_FnProto* new_items;
    zT_243D6A41_FnProto item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->allocator;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(16) * new_cap), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (zT_243D6A41_FnProto*)raw;
    new_items = zT_29;
    zT_30 = self->items;
    zT_31 = self->len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_36 = zT_35.ptr;
    zT_37 = zT_35.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((int)(i < zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_36[i];
    new_items[i] = item;
    zT_42 = i + (unsigned int)(1);
    i = zT_42;
    goto z_bb_10;
    z_bb_12:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* fnProtoArrayListAppend */
void zF_919D3F12_fnProtoArrayListApp(zT_CCB21906_FnProtoArrayList* self, zT_243D6A41_FnProto value) {
    zT_CCB21906_FnProtoArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_243D6A41_FnProto* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_D57F7CF4_fnProtoArrayListEns(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* fnProtoArrayListGetSlice */
zT_91F8F99F_Slice_zT_243D6A41_F zF_A4813F98_fnProtoArrayListGet(zT_CCB21906_FnProtoArrayList* self) {
    zT_243D6A41_FnProto* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_243D6A41_FnProto* zT_4;
    unsigned int zT_5;
    zT_91F8F99F_Slice_zT_243D6A41_F zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* EOF */
