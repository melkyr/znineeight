#include "spill_store_AC8E76BA.h"
unsigned char zG_43DA845B_g_s_ast;
unsigned char zG_563B9F3C_g_s_lir;
unsigned char zG_B3E107B1_g_s_hash;
unsigned char zG_43E32C79_g_s_res;
unsigned char zG_189B793E_g_s_side;
/* spillSetLevel */
void zF_4EDF4E7B_spillSetLevel(unsigned int level) {
    unsigned int zT_4;
    unsigned int n;
    n = level;
    if ((int)(n > (unsigned int)(5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = 5;
    n = zT_4;
    goto z_bb_2;
    z_bb_2:
    if ((int)(n >= (unsigned int)(1))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zG_43DA845B_g_s_ast = (unsigned char)(1);
    goto z_bb_4;
    z_bb_4:
    if ((int)(n >= (unsigned int)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zG_563B9F3C_g_s_lir = (unsigned char)(1);
    goto z_bb_6;
    z_bb_6:
    if ((int)(n >= (unsigned int)(3))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zG_B3E107B1_g_s_hash = (unsigned char)(1);
    goto z_bb_8;
    z_bb_8:
    if ((int)(n >= (unsigned int)(4))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zG_43E32C79_g_s_res = (unsigned char)(1);
    goto z_bb_10;
    z_bb_10:
    if ((int)(n >= (unsigned int)(5))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zG_189B793E_g_s_side = (unsigned char)(1);
    goto z_bb_12;
    z_bb_12:
    return;
}

/* spillBackendFor */
zT_0426DCE7_SpillBackend zF_1AA39172_spillBackendFor(zT_F12DA458_SpillId id) {
    if ((int)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_ast))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    if ((int)(zG_43DA845B_g_s_ast != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    if ((int)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_lir))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_4:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_5:
    if ((int)(zG_563B9F3C_g_s_lir != (unsigned char)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    if ((int)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_hash))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_8:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_9:
    if ((int)(zG_B3E107B1_g_s_hash != (unsigned char)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    if ((int)(id == (zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_res))) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_12:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_13:
    if ((int)(zG_43E32C79_g_s_res != (unsigned char)(0))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    if ((int)(zG_189B793E_g_s_side != (unsigned char)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_15:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_16:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
    z_bb_17:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram);
    z_bb_18:
    return (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk);
}

/* spillStoreInit */
zT_D21A8776_SpillStore zF_22C79E6C_spillStoreInit(void) {
    zT_D21A8776_SpillStore zT_0;
    zT_0426DCE7_SpillBackend zT_1;
    unsigned char zT_2;
    zT_7EA0A6A8_Opt_371 zT_3 = {0};
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_1 = zT_0426DCE7_SpillBackend_disk;
    zT_0.backend = zT_1;
    zT_2 = 0;
    zT_0.opened = zT_2;
    zT_3.has_value = 0;
    zT_0.handle = zT_3;
    zT_4 = 0;
    zT_0.buf = (unsigned char*)zT_4;
    zT_5 = 0;
    zT_0.cap = zT_5;
    zT_6 = 0;
    zT_0.len = zT_6;
    zT_7 = 0;
    zT_0.cur = zT_7;
    zT_8 = 0;
    zT_0.alloc = (zT_3E40CD83_Sand*)zT_8;
    return zT_0;
}

/* ramEnsure */
void zF_7BAD89D9_ramEnsure(zT_D21A8776_SpillStore* s, unsigned int need) {
    unsigned int zT_2;
    unsigned int zT_5;
    unsigned int zT_8;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_16;
    zT_0F51E4CA_EU_222 zT_22 = {0};
    unsigned char zT_23;
    unsigned char* zT_24;
    zT_3E40CD83_Sand* zT_27;
    unsigned char* zT_28;
    unsigned int zT_34;
    zT_7634F9B7_Opt_222 zT_38 = {0};
    unsigned char zT_39;
    zT_3E40CD83_Sand* zT_41;
    zT_0F51E4CA_EU_222 zT_47 = {0};
    unsigned char zT_48;
    unsigned char* zT_49;
    int zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned char* zT_57;
    unsigned char zT_58;
    int zT_59;
    unsigned int zT_60;
    unsigned int new_cap;
    unsigned char* raw;
    zT_7634F9B7_Opt_222 grown;
    unsigned int i;
    zT_2 = s->cap;
    if ((int)(need <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = s->cap;
    new_cap = zT_5;
    if ((int)(new_cap == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8 = 65536;
    new_cap = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_5;
    z_bb_5:
    if ((int)(new_cap < need)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    goto z_bb_8;
    z_bb_7:
    zT_12 = s->cap;
    if ((int)(zT_12 == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_11 = new_cap * (unsigned int)(2);
    new_cap = zT_11;
    goto z_bb_5;
    z_bb_9:
    zT_16 = s->alloc;
    zT_22 = zF_1395EB68_sandAlloc(zT_16, (unsigned int)((unsigned int)new_cap), (unsigned int)(4));
    zT_23 = zT_22.is_error;
    if (zT_23) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_27 = s->alloc;
    zT_28 = s->buf;
    zT_34 = s->cap;
    zT_38 = zF_33A3D4F8_sandTryReallocInPla(zT_27, zT_28, (unsigned int)((unsigned int)zT_34), (unsigned int)((unsigned int)new_cap), (unsigned int)(4));
    grown = zT_38;
    zT_39 = grown.has_value;
    if (zT_39) goto z_bb_14; else goto z_bb_15;
    z_bb_11:
    z_bb_12:
    zT_24 = zT_22.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_24;
    s->buf = raw;
    s->cap = new_cap;
    return;
    z_bb_14:
    s->cap = new_cap;
    return;
    z_bb_15:
    zT_41 = s->alloc;
    zT_47 = zF_1395EB68_sandAlloc(zT_41, (unsigned int)((unsigned int)new_cap), (unsigned int)(4));
    zT_48 = zT_47.is_error;
    if (zT_48) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    z_bb_17:
    zT_49 = zT_47.data.payload;
    goto z_bb_18;
    z_bb_18:
    raw = zT_49;
    zT_52 = 0;
    zT_53 = (unsigned int)zT_52;
    i = zT_53;
    goto z_bb_19;
    z_bb_19:
    zT_54 = s->cap;
    if ((int)(i < (unsigned int)((unsigned int)zT_54))) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_57 = s->buf;
    zT_58 = zT_57[i];
    raw[i] = zT_58;
    goto z_bb_22;
    z_bb_21:
    s->buf = raw;
    s->cap = new_cap;
    return;
    z_bb_22:
    zT_59 = 1;
    zT_60 = i + zT_59;
    i = zT_60;
    goto z_bb_19;
}

/* spillOpen */
void zF_8AF94F71_spillOpen(zT_D21A8776_SpillStore* s, zT_0426DCE7_SpillBackend backend, zT_8F083A69_Slice_zT_0B42B2F8_u path, zT_3E40CD83_Sand* alloc, unsigned char* mode) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned char* zT_9;
    zT_7EA0A6A8_Opt_371 zT_10 = {0};
    zT_7EA0A6A8_Opt_371 zT_11;
    unsigned char zT_12;
    char* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_17;
    char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    int zT_25;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    s->backend = backend;
    s->cur = (unsigned int)(0);
    if ((int)(backend == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_8 = path;
    zT_9 = mode;
    zT_10 = zF_A1EF0C49_streamOpen(zT_8, zT_9);
    s->handle = zT_10;
    zT_11 = s->handle;
    zT_12 = zT_11.has_value;
    if ((int)(!zT_12)) goto z_bb_4; else goto z_bb_5;
    z_bb_2:
    s->opened = (unsigned char)(1);
    return;
    z_bb_3:
    s->alloc = alloc;
    goto z_bb_2;
    z_bb_4:
    zT_15 = "spill file open failed (spillOpen)";
    zT_17 = 34;
    zT_16.ptr = zT_15;
    zT_16.len = zT_17;
    emsg = zT_16;
    zT_19 = "spill_store.zig";
    zT_21 = 15;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    ef = zT_20;
    zT_22 = emsg;
    zT_23 = ef;
    zT_25 = 132;
    zF_6D97D338_panicHandler(zT_22, zT_23, (unsigned int)((unsigned int)zT_25));
    return;
    z_bb_5:
    goto z_bb_2;
}

/* spillClose */
void zF_DB2CDC3B_spillClose(zT_D21A8776_SpillStore* s) {
    zT_0426DCE7_SpillBackend zT_1;
    zT_7EA0A6A8_Opt_371 zT_4;
    unsigned char zT_5;
    void* zT_7;
    zT_7EA0A6A8_Opt_371 zT_8 = {0};
    void* h;
    zT_1 = s->backend;
    if ((int)(zT_1 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = s->handle;
    zT_5 = zT_4.has_value;
    if (zT_5) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    s->opened = (unsigned char)(0);
    return;
    z_bb_3:
    h = zT_4.value;
    zT_7 = h;
    zF_D4EBC9A3_streamClose(zT_7);
    zT_8.has_value = 0;
    s->handle = zT_8;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
}

/* spillSeek */
void zF_56A911A9_spillSeek(zT_D21A8776_SpillStore* s, unsigned int off) {
    char* zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_15;
    zT_0426DCE7_SpillBackend zT_17;
    zT_7EA0A6A8_Opt_371 zT_21;
    unsigned char zT_22;
    void* zT_23;
    char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    int zT_36;
    void* zT_39;
    int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    void* h;
    if ((int)(off > (unsigned int)(2147483647))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5 = "spill seek offset exceeds i32 limit (spillSeek)";
    zT_7 = 47;
    zT_6.ptr = zT_5;
    zT_6.len = zT_7;
    emsg = zT_6;
    zT_9 = "spill_store.zig";
    zT_11 = 15;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    ef = zT_10;
    zT_12 = emsg;
    zT_13 = ef;
    zT_15 = 154;
    zF_6D97D338_panicHandler(zT_12, zT_13, (unsigned int)((unsigned int)zT_15));
    return;
    z_bb_2:
    zT_17 = s->backend;
    if ((int)(zT_17 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_21 = s->handle;
    zT_22 = zT_21.has_value;
    if (zT_22) goto z_bb_6; else goto z_bb_5;
    z_bb_4:
    s->cur = off;
    return;
    z_bb_5:
    zT_26 = "spill seek on null handle (spillSeek)";
    zT_28 = 37;
    zT_27.ptr = zT_26;
    zT_27.len = zT_28;
    emsg = zT_27;
    zT_30 = "spill_store.zig";
    zT_32 = 15;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    ef = zT_31;
    zT_33 = emsg;
    zT_34 = ef;
    zT_36 = 160;
    zF_6D97D338_panicHandler(zT_33, zT_34, (unsigned int)((unsigned int)zT_36));
    return;
    z_bb_6:
    zT_23 = zT_21.value;
    goto z_bb_7;
    z_bb_7:
    h = zT_23;
    zT_39 = h;
    zT_40 = __bootstrap_i32_from_u32(off);
    zF_25D60F31_streamSeek(zT_39, zT_40);
    goto z_bb_4;
}

/* spillWriteAt */
void zF_BFB33631_spillWriteAt(zT_D21A8776_SpillStore* s, unsigned int off, zT_8F083A69_Slice_zT_0B42B2F8_u bytes) {
    unsigned int zT_4;
    int zT_9;
    unsigned int zT_11;
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    int zT_27;
    unsigned int zT_31;
    unsigned int zT_33;
    zT_0426DCE7_SpillBackend zT_34;
    zT_D21A8776_SpillStore* zT_37;
    unsigned int zT_38;
    int zT_40;
    unsigned int zT_41;
    unsigned int zT_43;
    unsigned char* zT_45;
    unsigned char zT_46;
    unsigned char* zT_47;
    unsigned int zT_49;
    int zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_7EA0A6A8_Opt_371 zT_55;
    unsigned char zT_56;
    void* zT_57;
    char* zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    char* zT_64;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_65;
    unsigned int zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    int zT_70;
    unsigned int zT_73;
    void* zT_75;
    int zT_76;
    void* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    unsigned int end;
    unsigned int i;
    void* h;
    zT_4 = bytes.len;
    if ((int)(zT_4 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    if ((int)(off > (unsigned int)(2147483647))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_11 = bytes.len;
    zT_9 = zT_11 > (unsigned int)((unsigned int)(2147483647) - (unsigned int)((unsigned int)off));
    goto z_bb_5;
    z_bb_4:
    zT_9 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_9) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = "spill write exceeds i32 seek limit (spillWriteAt)";
    zT_19 = 49;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    emsg = zT_18;
    zT_21 = "spill_store.zig";
    zT_23 = 15;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    ef = zT_22;
    zT_24 = emsg;
    zT_25 = ef;
    zT_27 = 171;
    zF_6D97D338_panicHandler(zT_24, zT_25, (unsigned int)((unsigned int)zT_27));
    return;
    z_bb_7:
    zT_31 = bytes.len;
    zT_33 = off + (unsigned int)((unsigned int)zT_31);
    end = zT_33;
    zT_34 = s->backend;
    if ((int)(zT_34 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_37 = s;
    zT_38 = end;
    zF_7BAD89D9_ramEnsure(zT_37, zT_38);
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    i = zT_41;
    goto z_bb_11;
    z_bb_9:
    return;
    z_bb_10:
    zT_55 = s->handle;
    zT_56 = zT_55.has_value;
    if (zT_56) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    zT_43 = bytes.len;
    if ((int)(i < zT_43)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_45 = bytes.ptr;
    zT_46 = zT_45[i];
    zT_47 = s->buf;
    zT_49 = (unsigned int)((unsigned int)off) + i;
    zT_47[zT_49] = zT_46;
    goto z_bb_14;
    z_bb_13:
    zT_52 = s->len;
    if ((int)(end > zT_52)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    zT_50 = 1;
    zT_51 = i + zT_50;
    i = zT_51;
    goto z_bb_11;
    z_bb_15:
    s->len = end;
    goto z_bb_16;
    z_bb_16:
    s->cur = end;
    goto z_bb_9;
    z_bb_17:
    zT_60 = "spill write on null handle (spillWriteAt)";
    zT_62 = 41;
    zT_61.ptr = zT_60;
    zT_61.len = zT_62;
    emsg = zT_61;
    zT_64 = "spill_store.zig";
    zT_66 = 15;
    zT_65.ptr = zT_64;
    zT_65.len = zT_66;
    ef = zT_65;
    zT_67 = emsg;
    zT_68 = ef;
    zT_70 = 187;
    zF_6D97D338_panicHandler(zT_67, zT_68, (unsigned int)((unsigned int)zT_70));
    return;
    z_bb_18:
    zT_57 = zT_55.value;
    goto z_bb_19;
    z_bb_19:
    h = zT_57;
    zT_73 = s->cur;
    if ((int)(zT_73 != off)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_75 = h;
    zT_76 = __bootstrap_i32_from_u32(off);
    zF_25D60F31_streamSeek(zT_75, zT_76);
    goto z_bb_21;
    z_bb_21:
    zT_78 = h;
    zT_79 = bytes;
    zF_6B472DDC_streamWrite(zT_78, zT_79);
    s->cur = end;
    goto z_bb_9;
}

/* spillReadAt */
void zF_E9F67450_spillReadAt(zT_D21A8776_SpillStore* s, unsigned int off, zT_8F083A69_Slice_zT_0B42B2F8_u dst) {
    unsigned int zT_4;
    int zT_9;
    unsigned int zT_11;
    char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    int zT_27;
    unsigned int zT_31;
    unsigned int zT_33;
    zT_0426DCE7_SpillBackend zT_34;
    unsigned int zT_37;
    char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    int zT_50;
    int zT_53;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned char* zT_58;
    unsigned int zT_60;
    unsigned char zT_61;
    unsigned char* zT_62;
    int zT_63;
    unsigned int zT_64;
    zT_7EA0A6A8_Opt_371 zT_66;
    unsigned char zT_67;
    void* zT_68;
    char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    int zT_81;
    unsigned int zT_84;
    void* zT_86;
    int zT_87;
    void* zT_89;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    unsigned int end;
    void* h;
    unsigned int i;
    zT_4 = dst.len;
    if ((int)(zT_4 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    if ((int)(off > (unsigned int)(2147483647))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_11 = dst.len;
    zT_9 = zT_11 > (unsigned int)((unsigned int)(2147483647) - (unsigned int)((unsigned int)off));
    goto z_bb_5;
    z_bb_4:
    zT_9 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_9) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_17 = "spill read exceeds i32 seek limit (spillReadAt)";
    zT_19 = 47;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    emsg = zT_18;
    zT_21 = "spill_store.zig";
    zT_23 = 15;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    ef = zT_22;
    zT_24 = emsg;
    zT_25 = ef;
    zT_27 = 199;
    zF_6D97D338_panicHandler(zT_24, zT_25, (unsigned int)((unsigned int)zT_27));
    return;
    z_bb_7:
    zT_31 = dst.len;
    zT_33 = off + (unsigned int)((unsigned int)zT_31);
    end = zT_33;
    zT_34 = s->backend;
    if ((int)(zT_34 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_8; else goto z_bb_10;
    z_bb_8:
    zT_37 = s->len;
    if ((int)(end > zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_66 = s->handle;
    zT_67 = zT_66.has_value;
    if (zT_67) goto z_bb_18; else goto z_bb_17;
    z_bb_11:
    zT_40 = "spill read past logical end (spillReadAt)";
    zT_42 = 41;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    emsg = zT_41;
    zT_44 = "spill_store.zig";
    zT_46 = 15;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    ef = zT_45;
    zT_47 = emsg;
    zT_48 = ef;
    zT_50 = 207;
    zF_6D97D338_panicHandler(zT_47, zT_48, (unsigned int)((unsigned int)zT_50));
    return;
    z_bb_12:
    zT_53 = 0;
    zT_54 = (unsigned int)zT_53;
    i = zT_54;
    goto z_bb_13;
    z_bb_13:
    zT_56 = dst.len;
    if ((int)(i < zT_56)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_58 = s->buf;
    zT_60 = (unsigned int)((unsigned int)off) + i;
    zT_61 = zT_58[zT_60];
    zT_62 = dst.ptr;
    zT_62[i] = zT_61;
    goto z_bb_16;
    z_bb_15:
    s->cur = end;
    goto z_bb_9;
    z_bb_16:
    zT_63 = 1;
    zT_64 = i + zT_63;
    i = zT_64;
    goto z_bb_13;
    z_bb_17:
    zT_71 = "spill read on null handle (spillReadAt)";
    zT_73 = 39;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    emsg = zT_72;
    zT_75 = "spill_store.zig";
    zT_77 = 15;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    ef = zT_76;
    zT_78 = emsg;
    zT_79 = ef;
    zT_81 = 221;
    zF_6D97D338_panicHandler(zT_78, zT_79, (unsigned int)((unsigned int)zT_81));
    return;
    z_bb_18:
    zT_68 = zT_66.value;
    goto z_bb_19;
    z_bb_19:
    h = zT_68;
    zT_84 = s->cur;
    if ((int)(zT_84 != off)) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_86 = h;
    zT_87 = __bootstrap_i32_from_u32(off);
    zF_25D60F31_streamSeek(zT_86, zT_87);
    goto z_bb_21;
    z_bb_21:
    zT_89 = h;
    zT_90 = dst;
    zF_9D6FEB45_streamRead(zT_89, zT_90);
    s->cur = end;
    goto z_bb_9;
}

/* __module_init */
void zF_780653D2___module_init_21(void) {
    int zT_0;
    int zT_2;
    int zT_4;
    int zT_6;
    int zT_8;
    zT_0 = 0;
    zG_43DA845B_g_s_ast = (unsigned char)((unsigned char)zT_0);
    zT_2 = 0;
    zG_563B9F3C_g_s_lir = (unsigned char)((unsigned char)zT_2);
    zT_4 = 0;
    zG_B3E107B1_g_s_hash = (unsigned char)((unsigned char)zT_4);
    zT_6 = 0;
    zG_43E32C79_g_s_res = (unsigned char)((unsigned char)zT_6);
    zT_8 = 0;
    zG_189B793E_g_s_side = (unsigned char)((unsigned char)zT_8);
    return;
}

/* EOF */
