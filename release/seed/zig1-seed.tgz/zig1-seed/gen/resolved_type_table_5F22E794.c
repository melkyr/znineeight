#include "resolved_type_table_5F22E794.h"
zT_8EED1867_ResolvedTypeTable zG_8EED1867_ResolvedTypeTable;
unsigned char* zG_82B6E276_WRITE_MODE_1;
/* resolvedTypeTableInit */
zT_8EED1867_ResolvedTypeTable zF_8D0F00B1_resolvedTypeTableIn(zT_3E40CD83_Sand* alloc) {
    zT_8EED1867_ResolvedTypeTable zT_2;
    unsigned int zT_3;
    zT_D21A8776_SpillStore zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned char zT_7;
    unsigned int zT_8;
    zT_21D3708C_U32ToU32Map zT_9;
    int zT_10;
    int zT_11;
    int zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_20;
    unsigned int* zT_21;
    unsigned char zT_22;
    unsigned char* zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned char* zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    unsigned int zT_29;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned char* zT_36;
    unsigned char zT_37;
    unsigned char* zT_38;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    zT_8EED1867_ResolvedTypeTable t;
    unsigned int si;
    zT_8F083A69_Slice_zT_0B42B2F8_u dp;
    unsigned int di;
    zT_3 = 0;
    zT_2.cap = zT_3;
    zT_2.entries_alloc = alloc;
    zT_4 = zF_22C79E6C_spillStoreInit();
    zT_2.spill = zT_4;
    zT_5 = 0;
    zT_2.spill_path_len = zT_5;
    zT_6 = 0;
    zT_2.cache_buf = (unsigned char*)zT_6;
    zT_7 = 0;
    zT_2.cache_allocated = zT_7;
    zT_8 = 0;
    zT_2.ring_next = zT_8;
    zT_10 = 0;
    zT_9.keys = (unsigned int*)zT_10;
    zT_11 = 0;
    zT_9.values = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_9.occupied = (unsigned char*)zT_12;
    zT_13 = 0;
    zT_9.capacity = zT_13;
    zT_14 = 0;
    zT_9.count = zT_14;
    zT_9.alloc = alloc;
    zT_2.src_map = zT_9;
    t = zT_2;
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    si = zT_17;
    goto z_bb_1;
    z_bb_1:
    if ((int)(si < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_20 = 4294967295u;
    zT_21 = t.slot_block;
    zT_21[si] = zT_20;
    zT_22 = 0;
    zT_23 = t.slot_dirty;
    zT_23[si] = zT_22;
    goto z_bb_4;
    z_bb_3:
    zT_27 = ".zig1_res.tmp";
    zT_29 = 13;
    zT_28.ptr = zT_27;
    zT_28.len = zT_29;
    dp = zT_28;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    di = zT_32;
    goto z_bb_5;
    z_bb_4:
    zT_24 = 1;
    zT_25 = si + zT_24;
    si = zT_25;
    goto z_bb_1;
    z_bb_5:
    zT_34 = dp.len;
    if ((int)(di < zT_34)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_36 = dp.ptr;
    zT_37 = zT_36[di];
    zT_38 = t.spill_path;
    zT_38[di] = zT_37;
    goto z_bb_8;
    z_bb_7:
    zT_42 = dp.len;
    t.spill_path_len = zT_42;
    return t;
    z_bb_8:
    zT_39 = 1;
    zT_40 = di + zT_39;
    di = zT_40;
    goto z_bb_5;
}

/* resolvedTypeTableSetSpillPath */
void zF_7238A436_resolvedTypeTableSe(zT_8EED1867_ResolvedTypeTable* self, zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    int zT_8;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned char* zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned char zT_16;
    unsigned char* zT_17;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = path.len;
    if ((int)(i < zT_6)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_11 = path.ptr;
    zT_12 = zT_11[i];
    zT_13 = self->spill_path;
    zT_13[i] = zT_12;
    goto z_bb_4;
    z_bb_3:
    self->spill_path_len = i;
    zT_16 = 0;
    zT_17 = self->spill_path;
    zT_17[i] = zT_16;
    return;
    z_bb_4:
    zT_14 = 1;
    zT_15 = i + zT_14;
    i = zT_15;
    goto z_bb_1;
    z_bb_5:
    zT_8 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_8 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_8) goto z_bb_2; else goto z_bb_3;
}

/* rttAlignedNodes */
unsigned int zF_1CE20124_rttAlignedNodes(unsigned int n) {
    int zT_4;
    unsigned int zT_7;
    unsigned int mult;
    zT_4 = 1;
    zT_7 = (unsigned int)((unsigned int)(n + (unsigned int)(409)) - zT_4) / (unsigned int)(409);
    mult = zT_7;
    return (unsigned int)(mult * (unsigned int)(409));
}

/* rttOpenSpill */
void zF_01066AE9_rttOpenSpill(zT_8EED1867_ResolvedTypeTable* self) {
    zT_D21A8776_SpillStore zT_1;
    unsigned char zT_2;
    zT_D21A8776_SpillStore* zT_5;
    zT_0426DCE7_SpillBackend zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned char* zT_9;
    zT_0426DCE7_SpillBackend zT_15 = 0;
    unsigned char* zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned char* zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_1 = self->spill;
    zT_2 = zT_1.opened;
    if ((int)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = &self->spill;
    zT_15 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_res));
    zT_6 = zT_15;
    zT_16 = self->spill_path;
    zT_17 = self->spill_path_len;
    zT_18 = 0;
    zT_19 = zT_16 + zT_18;
    zT_20 = zT_17 - zT_18;
    zT_21.ptr = zT_19;
    zT_21.len = zT_20;
    zT_7 = zT_21;
    zT_8 = self->entries_alloc;
    zT_9 = zG_82B6E276_WRITE_MODE_1;
    zF_8AF94F71_spillOpen(zT_5, zT_6, zT_7, zT_8, zT_9);
    return;
}

/* rttExtend */
void zF_C592EFE9_rttExtend(zT_8EED1867_ResolvedTypeTable* self, unsigned int new_cap) {
    unsigned int zT_2;
    zT_8EED1867_ResolvedTypeTable* zT_4;
    unsigned int zT_6;
    unsigned int zT_8 = 0;
    unsigned int zT_10;
    unsigned int zT_11 = 0;
    unsigned int zT_16;
    unsigned int zT_20;
    unsigned char* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_26;
    unsigned char* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    int zT_34;
    zT_B2425549_Arr_unsigned_char_2 zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned char zT_43;
    int zT_44;
    unsigned int zT_45;
    unsigned int zT_47;
    zT_D21A8776_SpillStore* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    int zT_58;
    unsigned char* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_63;
    unsigned int zT_65;
    unsigned int old_an;
    unsigned int new_an;
    unsigned int old_bytes;
    unsigned int new_bytes;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_B2425549_Arr_unsigned_char_2 zero_buf;
    unsigned int zi;
    unsigned int to_write;
    unsigned int off;
    zT_2 = self->cap;
    if ((int)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_4 = self;
    zF_01066AE9_rttOpenSpill(zT_4);
    zT_6 = self->cap;
    zT_8 = zF_1CE20124_rttAlignedNodes(zT_6);
    old_an = zT_8;
    zT_10 = new_cap;
    zT_11 = zF_1CE20124_rttAlignedNodes(zT_10);
    new_an = zT_11;
    if ((int)(new_an > old_an)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = (unsigned int)((unsigned int)old_an) * (unsigned int)(5);
    old_bytes = zT_16;
    zT_20 = (unsigned int)((unsigned int)new_an) * (unsigned int)(5);
    new_bytes = zT_20;
    if ((int)(new_bytes > (unsigned int)(2147483647))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    self->cap = new_cap;
    return;
    z_bb_5:
    zT_24 = "resolved-type spill exceeds seek limit (rttExtend)";
    zT_26 = 50;
    zT_25.ptr = zT_24;
    zT_25.len = zT_26;
    emsg = zT_25;
    zT_28 = "resolved_type_table.zig";
    zT_30 = 23;
    zT_29.ptr = zT_28;
    zT_29.len = zT_30;
    ef = zT_29;
    zT_31 = emsg;
    zT_32 = ef;
    zT_34 = 112;
    zF_6D97D338_panicHandler(zT_31, zT_32, (unsigned int)((unsigned int)zT_34));
    return;
    z_bb_6:
    {
    unsigned int _i = 0;
    while (_i < 2045) {
        zT_37[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 2045) {
        zero_buf[_i] = zT_37[_i];
        _i++;
    }
}
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    zi = zT_40;
    goto z_bb_7;
    z_bb_7:
    if ((int)(zi < (unsigned int)(2045))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_43 = 0;
    zero_buf[zi] = zT_43;
    goto z_bb_10;
    z_bb_9:
    zT_47 = new_bytes - old_bytes;
    to_write = zT_47;
    off = old_bytes;
    goto z_bb_11;
    z_bb_10:
    zT_44 = 1;
    zT_45 = zi + zT_44;
    zi = zT_45;
    goto z_bb_7;
    z_bb_11:
    if ((int)(to_write > (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_51 = &self->spill;
    zT_52 = off;
    zT_58 = 0;
    zT_59 = (unsigned char*)((unsigned char*)zero_buf) + zT_58;
    zT_60 = (unsigned int)(2045) - zT_58;
    zT_61.ptr = zT_59;
    zT_61.len = zT_60;
    zT_53 = zT_61;
    zF_BFB33631_spillWriteAt(zT_51, zT_52, zT_53);
    zT_63 = off + (unsigned int)(2045);
    off = zT_63;
    goto z_bb_14;
    z_bb_13:
    goto z_bb_4;
    z_bb_14:
    zT_65 = to_write - (unsigned int)(2045);
    to_write = zT_65;
    goto z_bb_11;
}

/* rttEnsureCache */
void zF_79C87F6B_rttEnsureCache(zT_8EED1867_ResolvedTypeTable* self) {
    unsigned char zT_1;
    zT_3E40CD83_Sand* zT_5;
    zT_C6536882_EU_532 zT_13 = {0};
    unsigned char zT_14;
    unsigned char* zT_15;
    unsigned char* raw;
    zT_1 = self->cache_allocated;
    if ((int)(zT_1 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->entries_alloc;
    zT_13 = zF_1395EB68_sandAlloc(zT_5, (unsigned int)(16360), (unsigned int)(4));
    zT_14 = zT_13.is_error;
    if (zT_14) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_15 = zT_13.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_15;
    self->cache_buf = raw;
    self->cache_allocated = (unsigned char)(1);
    return;
}

/* rttSlotBuf */
unsigned char* zF_8D0C78B6_rttSlotBuf(zT_8EED1867_ResolvedTypeTable* self, unsigned int s) {
    unsigned char* zT_2;
    zT_2 = self->cache_buf;
    return (unsigned char*)(zT_2 + (unsigned int)((unsigned int)((unsigned int)s) * (unsigned int)(2045)));
}

/* rttResidentSlot */
unsigned int zF_5D06B445_rttResidentSlot(zT_8EED1867_ResolvedTypeTable* self, unsigned int block) {
    int zT_3;
    unsigned int zT_4;
    unsigned int* zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    unsigned int s;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    s = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((int)(s < (unsigned int)(8))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->slot_block;
    zT_8 = zT_7[s];
    if ((int)(zT_8 == block)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(8);
    z_bb_4:
    zT_10 = 1;
    zT_11 = s + zT_10;
    s = zT_11;
    goto z_bb_1;
    z_bb_5:
    return s;
    z_bb_6:
    goto z_bb_4;
}

/* rttWriteBack */
void zF_2C4861F7_rttWriteBack(zT_8EED1867_ResolvedTypeTable* self, unsigned int s) {
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    unsigned char* zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    int zT_23;
    zT_D21A8776_SpillStore* zT_25;
    unsigned int zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8EED1867_ResolvedTypeTable* zT_29;
    unsigned int zT_30;
    unsigned char* zT_31 = 0;
    int zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned char zT_37;
    unsigned char* zT_38;
    unsigned int block;
    unsigned int off;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = self->slot_block;
    zT_4 = zT_3[s];
    block = zT_4;
    zT_7 = block * (unsigned int)(2045);
    off = zT_7;
    if ((int)(off > (unsigned int)(2147481602))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_13 = "resolved-type spill exceeds seek limit (rttWriteBack)";
    zT_15 = 53;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    emsg = zT_14;
    zT_17 = "resolved_type_table.zig";
    zT_19 = 23;
    zT_18.ptr = zT_17;
    zT_18.len = zT_19;
    ef = zT_18;
    zT_20 = emsg;
    zT_21 = ef;
    zT_23 = 151;
    zF_6D97D338_panicHandler(zT_20, zT_21, (unsigned int)((unsigned int)zT_23));
    return;
    z_bb_2:
    zT_25 = &self->spill;
    zT_26 = off;
    zT_29 = self;
    zT_30 = s;
    zT_31 = zF_8D0C78B6_rttSlotBuf(zT_29, zT_30);
    zT_33 = 0;
    zT_34 = zT_31 + zT_33;
    zT_35 = (unsigned int)(2045) - zT_33;
    zT_36.ptr = zT_34;
    zT_36.len = zT_35;
    zT_27 = zT_36;
    zF_BFB33631_spillWriteAt(zT_25, zT_26, zT_27);
    zT_37 = 0;
    zT_38 = self->slot_dirty;
    zT_38[s] = zT_37;
    return;
}

/* rttBlockEnsure */
unsigned int zF_41F8466C_rttBlockEnsure(zT_8EED1867_ResolvedTypeTable* self, unsigned int block) {
    zT_8EED1867_ResolvedTypeTable* zT_3;
    unsigned int zT_4;
    unsigned int zT_5 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_8;
    unsigned int zT_10;
    unsigned int* zT_11;
    unsigned int zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned char zT_17;
    zT_8EED1867_ResolvedTypeTable* zT_20;
    unsigned int zT_21;
    zT_8EED1867_ResolvedTypeTable* zT_22;
    unsigned int zT_25;
    unsigned char* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    int zT_41;
    zT_D21A8776_SpillStore* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    zT_8EED1867_ResolvedTypeTable* zT_47;
    unsigned int zT_48;
    unsigned char* zT_49 = 0;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int* zT_55;
    unsigned char zT_56;
    unsigned char* zT_57;
    int zT_58;
    unsigned int zT_60;
    unsigned int r;
    unsigned int v;
    unsigned int off;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_3 = self;
    zT_4 = block;
    zT_5 = zF_5D06B445_rttResidentSlot(zT_3, zT_4);
    r = zT_5;
    if ((int)(r < (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return r;
    z_bb_2:
    zT_8 = self;
    zF_79C87F6B_rttEnsureCache(zT_8);
    zT_10 = self->ring_next;
    v = zT_10;
    zT_11 = self->slot_block;
    zT_12 = zT_11[v];
    if ((int)(zT_12 != (unsigned int)(4294967295u))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_16 = self->slot_dirty;
    zT_17 = zT_16[v];
    zT_15 = zT_17 != (unsigned char)(0);
    goto z_bb_5;
    z_bb_4:
    zT_15 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_15) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_20 = self;
    zT_21 = v;
    zF_2C4861F7_rttWriteBack(zT_20, zT_21);
    goto z_bb_7;
    z_bb_7:
    zT_22 = self;
    zF_01066AE9_rttOpenSpill(zT_22);
    zT_25 = block * (unsigned int)(2045);
    off = zT_25;
    if ((int)(off > (unsigned int)(2147481602))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_31 = "resolved-type spill exceeds seek limit (rttBlockEnsure)";
    zT_33 = 55;
    zT_32.ptr = zT_31;
    zT_32.len = zT_33;
    emsg = zT_32;
    zT_35 = "resolved_type_table.zig";
    zT_37 = 23;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    ef = zT_36;
    zT_38 = emsg;
    zT_39 = ef;
    zT_41 = 174;
    zF_6D97D338_panicHandler(zT_38, zT_39, (unsigned int)((unsigned int)zT_41));
    return v;
    z_bb_9:
    zT_43 = &self->spill;
    zT_44 = off;
    zT_47 = self;
    zT_48 = v;
    zT_49 = zF_8D0C78B6_rttSlotBuf(zT_47, zT_48);
    zT_51 = 0;
    zT_52 = zT_49 + zT_51;
    zT_53 = (unsigned int)(2045) - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    zT_45 = zT_54;
    zF_E9F67450_spillReadAt(zT_43, zT_44, zT_45);
    zT_55 = self->slot_block;
    zT_55[v] = block;
    zT_56 = 0;
    zT_57 = self->slot_dirty;
    zT_57[v] = zT_56;
    zT_58 = 1;
    self->ring_next = (unsigned int)(v + zT_58);
    zT_60 = self->ring_next;
    if ((int)(zT_60 >= (unsigned int)(8))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    self->ring_next = (unsigned int)(0);
    goto z_bb_11;
    z_bb_11:
    return v;
}

/* rttReadU32 */
unsigned int zF_AD4FEE31_rttReadU32(unsigned char* p, unsigned int off) {
    unsigned char zT_3;
    unsigned int zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned char zT_7;
    unsigned int zT_11;
    int zT_12;
    unsigned int zT_13;
    unsigned char zT_14;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    unsigned char zT_21;
    unsigned int zT_25;
    unsigned int v;
    zT_3 = p[off];
    zT_4 = (unsigned int)zT_3;
    v = zT_4;
    zT_5 = 1;
    zT_6 = off + zT_5;
    zT_7 = p[zT_6];
    zT_11 = v | (unsigned int)((unsigned int)((unsigned int)zT_7) << (unsigned int)(8));
    v = zT_11;
    zT_12 = 2;
    zT_13 = off + zT_12;
    zT_14 = p[zT_13];
    zT_18 = v | (unsigned int)((unsigned int)((unsigned int)zT_14) << (unsigned int)(16));
    v = zT_18;
    zT_19 = 3;
    zT_20 = off + zT_19;
    zT_21 = p[zT_20];
    zT_25 = v | (unsigned int)((unsigned int)((unsigned int)zT_21) << (unsigned int)(24));
    v = zT_25;
    return v;
}

/* rttWriteU32 */
void zF_CEEF106E_rttWriteU32(unsigned char* p, unsigned int off, unsigned int v) {
    unsigned char zT_5;
    unsigned char zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned char zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned char zT_24;
    int zT_25;
    unsigned int zT_26;
    zT_5 = (unsigned char)(unsigned int)(v & (unsigned int)(255));
    p[off] = zT_5;
    zT_10 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255));
    zT_11 = 1;
    zT_12 = off + zT_11;
    p[zT_12] = zT_10;
    zT_17 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255));
    zT_18 = 2;
    zT_19 = off + zT_18;
    p[zT_19] = zT_17;
    zT_24 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255));
    zT_25 = 3;
    zT_26 = off + zT_25;
    p[zT_26] = zT_24;
    return;
}

/* resolvedTypeTableReserve */
void zF_75224871_resolvedTypeTableRe(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_count) {
    zT_8EED1867_ResolvedTypeTable* zT_2;
    unsigned int zT_3;
    zT_2 = self;
    zT_3 = node_count;
    zF_C592EFE9_rttExtend(zT_2, zT_3);
    return;
}

/* resolvedTypeTableSet */
void zF_19B4A07D_resolvedTypeTableSe(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_idx, unsigned int type_id) {
    unsigned int zT_4;
    unsigned int zT_5;
    zT_8EED1867_ResolvedTypeTable* zT_7;
    int zT_9;
    unsigned int zT_14;
    zT_8EED1867_ResolvedTypeTable* zT_16;
    unsigned int zT_17;
    unsigned int zT_18 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_20;
    unsigned int zT_21;
    unsigned char* zT_22 = 0;
    unsigned int zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    unsigned char zT_32;
    int zT_33;
    unsigned int zT_34;
    unsigned char zT_35;
    unsigned char* zT_36;
    unsigned int ni;
    unsigned int block;
    unsigned int s;
    unsigned char* buf;
    unsigned int rec_off;
    zT_4 = (unsigned int)node_idx;
    ni = zT_4;
    zT_5 = self->cap;
    if ((int)(ni >= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_7 = self;
    zT_9 = 1;
    zF_C592EFE9_rttExtend(zT_7, (unsigned int)(ni + zT_9));
    goto z_bb_2;
    z_bb_2:
    zT_14 = (unsigned int)(unsigned int)(ni / (unsigned int)(409));
    block = zT_14;
    zT_16 = self;
    zT_17 = block;
    zT_18 = zF_41F8466C_rttBlockEnsure(zT_16, zT_17);
    s = zT_18;
    zT_20 = self;
    zT_21 = s;
    zT_22 = zF_8D0C78B6_rttSlotBuf(zT_20, zT_21);
    buf = zT_22;
    zT_27 = (unsigned int)(ni % (unsigned int)(409)) * (unsigned int)(5);
    rec_off = zT_27;
    zT_28 = buf;
    zT_29 = rec_off;
    zF_CEEF106E_rttWriteU32(zT_28, zT_29, (unsigned int)((unsigned int)type_id));
    zT_32 = 1;
    zT_33 = 4;
    zT_34 = rec_off + zT_33;
    buf[zT_34] = zT_32;
    zT_35 = 1;
    zT_36 = self->slot_dirty;
    zT_36[s] = zT_35;
    return;
}

/* resolvedTypeTableGet */
zT_BAEE192E_Opt_10 zF_999DCF51_resolvedTypeTableGe(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_idx) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned int zT_10;
    zT_8EED1867_ResolvedTypeTable* zT_12;
    unsigned int zT_13;
    unsigned int zT_14 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_16;
    unsigned int zT_17;
    unsigned char* zT_18 = 0;
    unsigned int zT_23;
    int zT_24;
    unsigned int zT_25;
    unsigned char zT_26;
    unsigned char* zT_29;
    unsigned int zT_30;
    unsigned int zT_31 = 0;
    zT_BAEE192E_Opt_10 zT_32;
    zT_BAEE192E_Opt_10 zT_33 = {0};
    unsigned int ni;
    unsigned int block;
    unsigned int s;
    unsigned char* buf;
    unsigned int rec_off;
    zT_3 = (unsigned int)node_idx;
    ni = zT_3;
    zT_4 = self->cap;
    if ((int)(ni >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6.has_value = 0;
    return zT_6;
    z_bb_2:
    zT_10 = (unsigned int)(unsigned int)(ni / (unsigned int)(409));
    block = zT_10;
    zT_12 = self;
    zT_13 = block;
    zT_14 = zF_41F8466C_rttBlockEnsure(zT_12, zT_13);
    s = zT_14;
    zT_16 = self;
    zT_17 = s;
    zT_18 = zF_8D0C78B6_rttSlotBuf(zT_16, zT_17);
    buf = zT_18;
    zT_23 = (unsigned int)(ni % (unsigned int)(409)) * (unsigned int)(5);
    rec_off = zT_23;
    zT_24 = 4;
    zT_25 = rec_off + zT_24;
    zT_26 = buf[zT_25];
    if ((int)(zT_26 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_29 = buf;
    zT_30 = rec_off;
    zT_31 = zF_AD4FEE31_rttReadU32(zT_29, zT_30);
    zT_32.has_value = 1;
    zT_32.value = zT_31;
    return zT_32;
    z_bb_4:
    zT_33.has_value = 0;
    return zT_33;
}

/* resolvedSourceTableSet */
void zF_D976B454_resolvedSourceTable(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_idx, unsigned int source_name_id) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3 = &self->src_map;
    zT_4 = node_idx;
    zT_5 = source_name_id;
    zF_26476265_u32ToU32MapPut(zT_3, zT_4, zT_5);
    return;
}

/* resolvedSourceTableGet */
zT_BAEE192E_Opt_10 zF_F45AE288_resolvedSourceTable(zT_8EED1867_ResolvedTypeTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    zT_2 = &self->src_map;
    zT_3 = node_idx;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    return zT_5;
}

/* resolvedTypeTableClose */
void zF_5209815D_resolvedTypeTableCl(zT_8EED1867_ResolvedTypeTable* self) {
    zT_D21A8776_SpillStore zT_1;
    unsigned char zT_2;
    int zT_6;
    unsigned int zT_7;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_14;
    unsigned char* zT_15;
    unsigned char zT_16;
    zT_8EED1867_ResolvedTypeTable* zT_19;
    unsigned int zT_20;
    int zT_21;
    unsigned int zT_22;
    zT_D21A8776_SpillStore* zT_23;
    unsigned int s;
    zT_1 = self->spill;
    zT_2 = zT_1.opened;
    if ((int)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_6 = 0;
    zT_7 = (unsigned int)zT_6;
    s = zT_7;
    goto z_bb_3;
    z_bb_3:
    if ((int)(s < (unsigned int)(8))) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->slot_block;
    zT_11 = zT_10[s];
    if ((int)(zT_11 != (unsigned int)(4294967295u))) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    zT_23 = &self->spill;
    zF_DB2CDC3B_spillClose(zT_23);
    return;
    z_bb_6:
    zT_21 = 1;
    zT_22 = s + zT_21;
    s = zT_22;
    goto z_bb_3;
    z_bb_7:
    zT_15 = self->slot_dirty;
    zT_16 = zT_15[s];
    zT_14 = zT_16 != (unsigned char)(0);
    goto z_bb_9;
    z_bb_8:
    zT_14 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_14) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_19 = self;
    zT_20 = s;
    zF_2C4861F7_rttWriteBack(zT_19, zT_20);
    goto z_bb_11;
    z_bb_11:
    goto z_bb_6;
}

/* __module_init */
void zF_780653D2___module_init_15(void) {
    unsigned char* zT_0;
    zT_0 = "w+b";
    zG_82B6E276_WRITE_MODE_1 = zT_0;
    return;
}

/* EOF */
