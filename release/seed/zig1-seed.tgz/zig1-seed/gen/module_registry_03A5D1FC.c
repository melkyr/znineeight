#include "module_registry_03A5D1FC.h"
zT_072B53A6_ModuleRegistry zG_072B53A6_ModuleRegistry;
unsigned char zG_E8C23D2C_source_man_stub;
unsigned char* zG_1DDFFDDD_HASH_SPILL_READ_MOD;
unsigned char* zG_034DEF1E_HASH_SPILL_WRITE_MO;
unsigned int zG_0BC1A97F_HASH_SPILL_MAX_MAP_;
/* moduleEntryArrayListInit */
zT_E41AEC18_ModuleEntryArrayLis zF_CD3AB3CA_moduleEntryArrayLis(zT_3E40CD83_Sand* allocator, unsigned int initial_capacity) {
    zT_E41AEC18_ModuleEntryArrayLis zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_E41AEC18_ModuleEntryArrayLis* zT_7;
    unsigned int zT_8;
    zT_E41AEC18_ModuleEntryArrayLis list;
    zT_4 = 0;
    zT_3.items = (zT_6E8D187B_ModuleEntry*)zT_4;
    zT_5 = 0;
    zT_3.len = zT_5;
    zT_6 = 0;
    zT_3.capacity = zT_6;
    zT_3.allocator = allocator;
    list = zT_3;
    zT_7 = &list;
    zT_8 = initial_capacity;
    zF_91E0DA42_moduleEntryArrayLis(zT_7, zT_8);
    return list;
}

/* moduleEntryArrayListEnsureCapacity */
void zF_91E0DA42_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    zT_6E8D187B_ModuleEntry* zT_26;
    unsigned int zT_28;
    zT_6F32B01B_Opt_235 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_C6536882_EU_532 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    zT_6E8D187B_ModuleEntry* zT_49;
    zT_6E8D187B_ModuleEntry* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_6E8D187B_ModuleEntry* zT_53;
    unsigned int zT_54;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_55;
    zT_6E8D187B_ModuleEntry* zT_56;
    unsigned int zT_57;
    unsigned int zT_62;
    unsigned int new_cap;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    zT_6E8D187B_ModuleEntry* new_items;
    zT_6E8D187B_ModuleEntry item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->capacity;
    zT_17 = 0;
    if ((int)(zT_16 > (unsigned int)zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = self->allocator;
    zT_26 = self->items;
    zT_28 = self->capacity;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), (unsigned int)(zT_28 * (unsigned int)(52)), (unsigned int)(new_cap * (unsigned int)(52)), (unsigned int)(4));
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_37 = self->allocator;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(52) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_46 = zT_44.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    zT_49 = (zT_6E8D187B_ModuleEntry*)raw;
    new_items = zT_49;
    zT_50 = self->items;
    zT_51 = self->len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_62 = i + (unsigned int)(1);
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* moduleEntryArrayListAppend */
void zF_ABB1AEC0_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis* self, zT_6E8D187B_ModuleEntry value) {
    zT_E41AEC18_ModuleEntryArrayLis* zT_2;
    unsigned int zT_4;
    int zT_5;
    zT_6E8D187B_ModuleEntry* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_91E0DA42_moduleEntryArrayLis(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* moduleEntryArrayListGetSlice */
zT_DDCD424B_Slice_zT_6E8D187B_M zF_9FE5DB1E_moduleEntryArrayLis(zT_E41AEC18_ModuleEntryArrayLis* self) {
    zT_6E8D187B_ModuleEntry* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_6E8D187B_ModuleEntry* zT_4;
    unsigned int zT_5;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_6;
    zT_1 = self->items;
    zT_2 = self->len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* searchDirArrayListEnsureCapacity */
void zF_529FE8C7_searchDirArrayListE(zT_4EA49A91_SearchDirArrayList* self, unsigned int new_capacity) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    unsigned int* zT_26;
    unsigned int zT_28;
    zT_6F32B01B_Opt_235 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_C6536882_EU_532 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned int* zT_49;
    unsigned int* zT_50;
    unsigned int zT_51;
    int zT_52;
    unsigned int* zT_53;
    unsigned int zT_54;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_55;
    unsigned int* zT_56;
    unsigned int zT_57;
    unsigned int zT_62;
    unsigned int new_cap;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_2 = self->capacity;
    if ((int)(new_capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_5 = self->capacity;
    zT_6 = 2;
    if ((int)(new_cap < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->capacity;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    new_cap = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 2;
    if ((int)(new_cap < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 2;
    zT_15 = (unsigned int)zT_14;
    new_cap = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->capacity;
    zT_17 = 0;
    if ((int)(zT_16 > (unsigned int)zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = self->alloc;
    zT_26 = self->items;
    zT_28 = self->capacity;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), (unsigned int)(zT_28 * (unsigned int)(4)), (unsigned int)(new_cap * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_37 = self->alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(4) * new_cap), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->capacity = new_cap;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_46 = zT_44.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    zT_49 = (unsigned int*)raw;
    new_items = zT_49;
    zT_50 = self->items;
    zT_51 = self->len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_62 = i + (unsigned int)(1);
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->items = new_items;
    self->capacity = new_cap;
    return;
}

/* searchDirArrayListAppend */
void zF_DD10EA35_searchDirArrayListA(zT_4EA49A91_SearchDirArrayList* self, unsigned int value) {
    zT_4EA49A91_SearchDirArrayList* zT_2;
    unsigned int zT_4;
    int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    int zT_10;
    zT_2 = self;
    zT_4 = self->len;
    zT_5 = 1;
    zF_529FE8C7_searchDirArrayListE(zT_2, (unsigned int)(zT_4 + zT_5));
    zT_7 = self->items;
    zT_8 = self->len;
    zT_7[zT_8] = value;
    zT_9 = self->len;
    zT_10 = 1;
    self->len = (unsigned int)(zT_9 + (unsigned int)((unsigned int)zT_10));
    return;
}

/* joinPath */
zT_7734FB4A_Opt_221 zF_05C4CBC2_joinPath(zT_8F083A69_Slice_zT_0B42B2F8_u dir, zT_8F083A69_Slice_zT_0B42B2F8_u rel, zT_3E40CD83_Sand* scratch) {
    unsigned int zT_5;
    unsigned int zT_9;
    unsigned int zT_10;
    zT_3E40CD83_Sand* zT_12;
    unsigned int zT_13;
    zT_C6536882_EU_532 zT_16 = {0};
    unsigned char zT_17;
    unsigned char* zT_18;
    zT_7734FB4A_Opt_221 zT_19 = {0};
    unsigned char* zT_22;
    int zT_24;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned char* zT_29;
    unsigned char zT_30;
    int zT_31;
    unsigned int zT_33;
    unsigned char zT_34;
    int zT_35;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned char* zT_44;
    unsigned char zT_45;
    unsigned int zT_46;
    int zT_47;
    unsigned int zT_49;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_7734FB4A_Opt_221 zT_58 = {0};
    unsigned char zT_59;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_60;
    zT_7734FB4A_Opt_221 zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    zT_7734FB4A_Opt_221 zT_63;
    unsigned int total;
    unsigned char* raw;
    unsigned char* buf;
    unsigned int i;
    unsigned int j;
    zT_8F083A69_Slice_zT_0B42B2F8_u full;
    zT_8F083A69_Slice_zT_0B42B2F8_u norm;
    zT_5 = dir.len;
    zT_9 = rel.len;
    zT_10 = (unsigned int)(zT_5 + (unsigned int)(1)) + zT_9;
    total = zT_10;
    zT_12 = scratch;
    zT_13 = total;
    zT_16 = zF_1395EB68_sandAlloc(zT_12, zT_13, (unsigned int)(1));
    zT_17 = zT_16.is_error;
    if (zT_17) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19.has_value = 0;
    return zT_19;
    z_bb_2:
    zT_18 = zT_16.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_18;
    zT_22 = (unsigned char*)raw;
    buf = zT_22;
    zT_24 = 0;
    zT_25 = (unsigned int)zT_24;
    i = zT_25;
    goto z_bb_4;
    z_bb_4:
    zT_27 = dir.len;
    if ((int)(i < zT_27)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_29 = dir.ptr;
    zT_30 = zT_29[i];
    buf[i] = zT_30;
    zT_31 = 1;
    zT_33 = i + (unsigned int)((unsigned int)zT_31);
    i = zT_33;
    goto z_bb_7;
    z_bb_6:
    zT_34 = 47;
    buf[i] = zT_34;
    zT_35 = 1;
    zT_37 = i + (unsigned int)((unsigned int)zT_35);
    i = zT_37;
    zT_39 = 0;
    zT_40 = (unsigned int)zT_39;
    j = zT_40;
    goto z_bb_8;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_42 = rel.len;
    if ((int)(j < zT_42)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_44 = rel.ptr;
    zT_45 = zT_44[j];
    zT_46 = i + j;
    buf[zT_46] = zT_45;
    zT_47 = 1;
    zT_49 = j + (unsigned int)((unsigned int)zT_47);
    j = zT_49;
    goto z_bb_11;
    z_bb_10:
    zT_51 = 0;
    zT_52 = buf + zT_51;
    zT_53 = total - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    full = zT_54;
    zT_56 = full;
    zT_57 = full;
    zT_58 = zF_36F0DB6B_normalizePath(zT_56, zT_57);
    zT_59 = zT_58.has_value;
    if (zT_59) goto z_bb_13; else goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_61.has_value = 1;
    zT_61.value = full;
    return zT_61;
    z_bb_13:
    zT_62 = zT_58.value;
    zT_60 = zT_62;
    goto z_bb_14;
    z_bb_14:
    norm = zT_60;
    zT_63.has_value = 1;
    zT_63.value = norm;
    return zT_63;
}

/* moduleDirPath */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_75D2520B_moduleDirPath(zT_8F083A69_Slice_zT_0B42B2F8_u path) {
    unsigned int zT_3;
    int zT_4;
    int zT_6;
    unsigned int zT_8;
    unsigned char* zT_9;
    unsigned char zT_10;
    unsigned char* zT_13;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned char* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    unsigned int zT_22;
    unsigned int i;
    zT_8F083A69_Slice_zT_0B42B2F8_u empty_str;
    zT_3 = path.len;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = 0;
    if ((int)(i > (unsigned int)zT_4)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    zT_8 = i - (unsigned int)((unsigned int)zT_6);
    i = zT_8;
    zT_9 = path.ptr;
    zT_10 = zT_9[i];
    if ((int)(zT_10 == (unsigned char)(47))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_20 = "";
    zT_22 = 0;
    zT_21.ptr = zT_20;
    zT_21.len = zT_22;
    empty_str = zT_21;
    return empty_str;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_13 = path.ptr;
    zT_15 = 0;
    zT_16 = zT_13 + zT_15;
    zT_17 = i - zT_15;
    zT_18.ptr = zT_16;
    zT_18.len = zT_17;
    return zT_18;
    z_bb_6:
    goto z_bb_4;
}

/* appendZigExt */
zT_13D0AA3A_Opt_438 zF_64D8041C_appendZigExt(zT_8F083A69_Slice_zT_0B42B2F8_u target, zT_3E40CD83_Sand* scratch) {
    unsigned int zT_4;
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    zT_C6536882_EU_532 zT_12 = {0};
    unsigned char zT_13;
    unsigned char* zT_14;
    zT_13D0AA3A_Opt_438 zT_15 = {0};
    unsigned char* zT_18;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned char* zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned int zT_29;
    unsigned char zT_30;
    int zT_31;
    unsigned int zT_33;
    unsigned char zT_34;
    int zT_35;
    unsigned int zT_37;
    unsigned char zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned char zT_42;
    int zT_43;
    unsigned char* zT_44;
    unsigned int zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    zT_13D0AA3A_Opt_438 zT_47;
    unsigned int total;
    unsigned char* raw;
    unsigned char* buf;
    unsigned int i;
    zT_4 = target.len;
    zT_6 = zT_4 + (unsigned int)(4);
    total = zT_6;
    zT_8 = scratch;
    zT_9 = total;
    zT_12 = zF_1395EB68_sandAlloc(zT_8, zT_9, (unsigned int)(1));
    zT_13 = zT_12.is_error;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15.has_value = 0;
    return zT_15;
    z_bb_2:
    zT_14 = zT_12.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_14;
    zT_18 = (unsigned char*)raw;
    buf = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    i = zT_21;
    goto z_bb_4;
    z_bb_4:
    zT_23 = target.len;
    if ((int)(i < zT_23)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_25 = target.ptr;
    zT_26 = zT_25[i];
    buf[i] = zT_26;
    zT_27 = 1;
    zT_29 = i + (unsigned int)((unsigned int)zT_27);
    i = zT_29;
    goto z_bb_7;
    z_bb_6:
    zT_30 = 46;
    buf[i] = zT_30;
    zT_31 = 1;
    zT_33 = i + (unsigned int)((unsigned int)zT_31);
    i = zT_33;
    zT_34 = 122;
    buf[i] = zT_34;
    zT_35 = 1;
    zT_37 = i + (unsigned int)((unsigned int)zT_35);
    i = zT_37;
    zT_38 = 105;
    buf[i] = zT_38;
    zT_39 = 1;
    zT_41 = i + (unsigned int)((unsigned int)zT_39);
    i = zT_41;
    zT_42 = 103;
    buf[i] = zT_42;
    zT_43 = 0;
    zT_44 = buf + zT_43;
    zT_45 = total - zT_43;
    zT_46.ptr = zT_44;
    zT_46.len = zT_45;
    zT_47.has_value = 1;
    zT_47.value = zT_46;
    return zT_47;
    z_bb_7:
    goto z_bb_4;
}

/* moduleResolverTryDir */
zT_BAEE192E_Opt_10 zF_25488423_moduleResolverTryDi(zT_4DB1475B_ModuleResolver* self, zT_8F083A69_Slice_zT_0B42B2F8_u dir, zT_8F083A69_Slice_zT_0B42B2F8_u target, zT_3E40CD83_Sand* scratch) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    zT_3E40CD83_Sand* zT_7;
    zT_7734FB4A_Opt_221 zT_8 = {0};
    unsigned char zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_BAEE192E_Opt_10 zT_11 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    int zT_14 = 0;
    zT_D3EB6303_StringInterner* zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    unsigned int zT_18 = 0;
    zT_BAEE192E_Opt_10 zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_3E40CD83_Sand* zT_22;
    zT_13D0AA3A_Opt_438 zT_23 = {0};
    unsigned char zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    zT_BAEE192E_Opt_10 zT_26 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    zT_3E40CD83_Sand* zT_31;
    zT_7734FB4A_Opt_221 zT_32 = {0};
    unsigned char zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    zT_BAEE192E_Opt_10 zT_35 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    int zT_38 = 0;
    zT_D3EB6303_StringInterner* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    unsigned int zT_42 = 0;
    zT_BAEE192E_Opt_10 zT_43;
    zT_BAEE192E_Opt_10 zT_44 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u full;
    zT_8F083A69_Slice_zT_0B42B2F8_u tzig;
    zT_8F083A69_Slice_zT_0B42B2F8_u full2;
    zT_5 = dir;
    zT_6 = target;
    zT_7 = scratch;
    zT_8 = zF_05C4CBC2_joinPath(zT_5, zT_6, zT_7);
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_11.has_value = 0;
    return zT_11;
    z_bb_2:
    zT_12 = zT_8.value;
    zT_10 = zT_12;
    goto z_bb_3;
    z_bb_3:
    full = zT_10;
    zT_13 = full;
    zT_14 = zF_852C5C93_fileExists(zT_13);
    if (zT_14) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15 = self->interner;
    zT_16 = full;
    zT_18 = zF_50C274AF_stringInternerInter(zT_15, zT_16);
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
    z_bb_5:
    zT_21 = target;
    zT_22 = scratch;
    zT_23 = zF_64D8041C_appendZigExt(zT_21, zT_22);
    zT_24 = zT_23.has_value;
    if (zT_24) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_26.has_value = 0;
    return zT_26;
    z_bb_7:
    zT_27 = zT_23.value;
    zT_25 = zT_27;
    goto z_bb_8;
    z_bb_8:
    tzig = zT_25;
    zT_29 = dir;
    zT_30 = tzig;
    zT_31 = scratch;
    zT_32 = zF_05C4CBC2_joinPath(zT_29, zT_30, zT_31);
    zT_33 = zT_32.has_value;
    if (zT_33) goto z_bb_10; else goto z_bb_9;
    z_bb_9:
    zT_35.has_value = 0;
    return zT_35;
    z_bb_10:
    zT_36 = zT_32.value;
    zT_34 = zT_36;
    goto z_bb_11;
    z_bb_11:
    full2 = zT_34;
    zT_37 = full2;
    zT_38 = zF_852C5C93_fileExists(zT_37);
    if (zT_38) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_39 = self->interner;
    zT_40 = full2;
    zT_42 = zF_50C274AF_stringInternerInter(zT_39, zT_40);
    zT_43.has_value = 1;
    zT_43.value = zT_42;
    return zT_43;
    z_bb_13:
    zT_44.has_value = 0;
    return zT_44;
}

/* moduleResolverInit */
zT_4DB1475B_ModuleResolver zF_64765145_moduleResolverInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_4DB1475B_ModuleResolver zT_3;
    zT_4EA49A91_SearchDirArrayList zT_4;
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_5 = 0;
    zT_4.items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_4.len = zT_6;
    zT_7 = 0;
    zT_4.capacity = zT_7;
    zT_4.alloc = alloc;
    zT_3.search_dirs = zT_4;
    zT_3.interner = interner;
    zT_3.diag = diag;
    return zT_3;
}

/* moduleResolverAddSearchDir */
void zF_B75A4515_moduleResolverAddSe(zT_4DB1475B_ModuleResolver* self, zT_8F083A69_Slice_zT_0B42B2F8_u dir) {
    zT_846744CC_Arr_unsigned_char_5 zT_3;
    unsigned int zT_6;
    int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_15;
    int zT_16;
    unsigned char* zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_7734FB4A_Opt_221 zT_20 = {0};
    unsigned char zT_21;
    zT_D3EB6303_StringInterner* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    unsigned int zT_27 = 0;
    zT_4EA49A91_SearchDirArrayList* zT_28;
    unsigned int zT_29;
    zT_846744CC_Arr_unsigned_char_5 buf;
    zT_8F083A69_Slice_zT_0B42B2F8_u use_dir;
    zT_7734FB4A_Opt_221 norm;
    unsigned int id;
    zT_8F083A69_Slice_zT_0B42B2F8_u n;
    {
    unsigned int _i = 0;
    while (_i < 512) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 512) {
        buf[_i] = zT_3[_i];
        _i++;
    }
}
    use_dir = dir;
    zT_6 = dir.len;
    zT_7 = 512;
    if ((int)(zT_6 <= (unsigned int)zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = dir.len;
    zT_16 = 0;
    zT_17 = (unsigned char*)((unsigned char*)buf) + zT_16;
    zT_18 = zT_15 - zT_16;
    zT_19.ptr = zT_17;
    zT_19.len = zT_18;
    zT_10 = zT_19;
    zT_11 = dir;
    zT_20 = zF_36F0DB6B_normalizePath(zT_10, zT_11);
    norm = zT_20;
    zT_21 = norm.has_value;
    if (zT_21) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_24 = self->interner;
    zT_25 = use_dir;
    zT_27 = zF_50C274AF_stringInternerInter(zT_24, zT_25);
    id = zT_27;
    zT_28 = &self->search_dirs;
    zT_29 = id;
    zF_DD10EA35_searchDirArrayListA(zT_28, zT_29);
    return;
    z_bb_3:
    n = norm.value;
    use_dir = n;
    goto z_bb_4;
    z_bb_4:
    goto z_bb_2;
}

/* moduleResolverResolve */
zT_BAEE192E_Opt_10 zF_6F148E15_moduleResolverResol(zT_4DB1475B_ModuleResolver* self, zT_8F083A69_Slice_zT_0B42B2F8_u importer_path, zT_8F083A69_Slice_zT_0B42B2F8_u target, zT_3E40CD83_Sand* scratch) {
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6 = {0};
    unsigned int zT_8;
    int zT_9;
    zT_4DB1475B_ModuleResolver* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    zT_3E40CD83_Sand* zT_15;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_BAEE192E_Opt_10 zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_4EA49A91_SearchDirArrayList zT_23;
    unsigned int zT_24;
    zT_D3EB6303_StringInterner* zT_27;
    unsigned int zT_28;
    zT_4EA49A91_SearchDirArrayList zT_30;
    unsigned int* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_33 = {0};
    zT_4DB1475B_ModuleResolver* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    zT_3E40CD83_Sand* zT_38;
    zT_BAEE192E_Opt_10 zT_39 = {0};
    unsigned char zT_40;
    zT_BAEE192E_Opt_10 zT_42;
    int zT_43;
    unsigned int zT_45;
    unsigned char* zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    unsigned int zT_49;
    zT_4DB1475B_ModuleResolver* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_3E40CD83_Sand* zT_54;
    zT_BAEE192E_Opt_10 zT_55 = {0};
    unsigned char zT_56;
    zT_BAEE192E_Opt_10 zT_58;
    zT_BAEE192E_Opt_10 zT_59 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u importer_dir;
    zT_BAEE192E_Opt_10 id;
    unsigned int i;
    unsigned int v;
    zT_8F083A69_Slice_zT_0B42B2F8_u dir;
    zT_8F083A69_Slice_zT_0B42B2F8_u lib_s;
    zT_5 = importer_path;
    zT_6 = zF_75D2520B_moduleDirPath(zT_5);
    importer_dir = zT_6;
    zT_8 = importer_dir.len;
    zT_9 = 0;
    if ((int)(zT_8 > (unsigned int)zT_9)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = self;
    zT_13 = importer_dir;
    zT_14 = target;
    zT_15 = scratch;
    zT_16 = zF_25488423_moduleResolverTryDi(zT_12, zT_13, zT_14, zT_15);
    id = zT_16;
    zT_17 = id.has_value;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    i = zT_22;
    goto z_bb_5;
    z_bb_3:
    v = id.value;
    zT_19.has_value = 1;
    zT_19.value = v;
    return zT_19;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_23 = self->search_dirs;
    zT_24 = zT_23.len;
    if ((int)(i < zT_24)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_27 = self->interner;
    zT_30 = self->search_dirs;
    zT_31 = zT_30.items;
    zT_28 = zT_31[i];
    zT_33 = zF_9134020D_stringInternerGet(zT_27, zT_28);
    dir = zT_33;
    zT_35 = self;
    zT_36 = dir;
    zT_37 = target;
    zT_38 = scratch;
    zT_39 = zF_25488423_moduleResolverTryDi(zT_35, zT_36, zT_37, zT_38);
    id = zT_39;
    zT_40 = id.has_value;
    if (zT_40) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_47 = ".";
    zT_49 = 1;
    zT_48.ptr = zT_47;
    zT_48.len = zT_49;
    lib_s = zT_48;
    zT_51 = self;
    zT_52 = lib_s;
    zT_53 = target;
    zT_54 = scratch;
    zT_55 = zF_25488423_moduleResolverTryDi(zT_51, zT_52, zT_53, zT_54);
    id = zT_55;
    zT_56 = id.has_value;
    if (zT_56) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    v = id.value;
    zT_42.has_value = 1;
    zT_42.value = v;
    return zT_42;
    z_bb_10:
    zT_43 = 1;
    zT_45 = i + (unsigned int)((unsigned int)zT_43);
    i = zT_45;
    goto z_bb_8;
    z_bb_11:
    v = id.value;
    zT_58.has_value = 1;
    zT_58.value = v;
    return zT_58;
    z_bb_12:
    zT_59.has_value = 0;
    return zT_59;
}

/* importEdgesEnsureCapacity */
void zF_11AFB41C_importEdgesEnsureCa(unsigned int** items, unsigned int* len, unsigned int* cap, zT_3E40CD83_Sand* alloc, unsigned int new_cap) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    int zT_15;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_3E40CD83_Sand* zT_23;
    unsigned int* zT_28;
    unsigned int zT_30;
    zT_6F32B01B_Opt_235 zT_36 = {0};
    unsigned char zT_37;
    zT_3E40CD83_Sand* zT_39;
    zT_C6536882_EU_532 zT_45 = {0};
    unsigned char zT_46;
    unsigned char* zT_47;
    unsigned int* zT_50;
    unsigned int* zT_51;
    unsigned int zT_52;
    int zT_53;
    unsigned int* zT_54;
    unsigned int zT_55;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_63;
    unsigned int nc;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_5 = *cap;
    if ((int)(new_cap <= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_8 = *cap;
    zT_9 = 2;
    if ((int)(nc < (unsigned int)(zT_8 * zT_9))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = *cap;
    zT_13 = 2;
    zT_14 = zT_12 * zT_13;
    nc = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_15 = 8;
    if ((int)(nc < (unsigned int)zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 8;
    zT_18 = (unsigned int)zT_17;
    nc = zT_18;
    goto z_bb_6;
    z_bb_6:
    zT_19 = *cap;
    zT_20 = 0;
    if ((int)(zT_19 > (unsigned int)zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_23 = alloc;
    zT_28 = *items;
    zT_30 = *cap;
    zT_36 = zF_33A3D4F8_sandTryReallocInPla(zT_23, (unsigned char*)((unsigned char*)zT_28), (unsigned int)(zT_30 * (unsigned int)(4)), (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_36;
    zT_37 = grown.has_value;
    if (zT_37) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_39 = alloc;
    zT_45 = zF_1395EB68_sandAlloc(zT_39, (unsigned int)((unsigned int)(4) * nc), (unsigned int)(4));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_47 = zT_45.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_47;
    zT_50 = (unsigned int*)raw;
    new_items = zT_50;
    zT_51 = *items;
    zT_52 = *len;
    zT_53 = 0;
    zT_54 = zT_51 + zT_53;
    zT_55 = zT_52 - zT_53;
    zT_56.ptr = zT_54;
    zT_56.len = zT_55;
    zT_57 = zT_56.ptr;
    zT_58 = zT_56.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_58)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_57[i];
    new_items[i] = item;
    zT_63 = i + (unsigned int)(1);
    i = zT_63;
    goto z_bb_14;
    z_bb_16:
    *items = new_items;
    *cap = nc;
    return;
}

/* importEdgesAppend */
void zF_358620BA_importEdgesAppend(unsigned int** items, unsigned int* len, unsigned int* cap, zT_3E40CD83_Sand* alloc, unsigned int value) {
    unsigned int** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    zT_5 = items;
    zT_6 = len;
    zT_7 = cap;
    zT_8 = alloc;
    zT_10 = *len;
    zT_11 = 1;
    zF_11AFB41C_importEdgesEnsureCa(zT_5, zT_6, zT_7, zT_8, (unsigned int)(zT_10 + zT_11));
    zT_13 = *items;
    zT_14 = *len;
    zT_13[zT_14] = value;
    zT_15 = *len;
    zT_16 = 1;
    *len = (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16));
    return;
}

/* moduleRegistryInit */
zT_072B53A6_ModuleRegistry zF_896FAF3C_moduleRegistryInit(zT_3E40CD83_Sand* alloc, zT_D3EB6303_StringInterner* interner, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_072B53A6_ModuleRegistry zT_3;
    zT_3E40CD83_Sand* zT_4;
    int zT_6;
    zT_E41AEC18_ModuleEntryArrayLis zT_8 = {0};
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_3E40CD83_Sand* zT_12;
    zT_D3EB6303_StringInterner* zT_13;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    zT_4DB1475B_ModuleResolver zT_15 = {0};
    unsigned char* zT_17;
    zT_227EDE07_SourceManager* zT_18;
    unsigned int zT_19;
    zT_3E40CD83_Sand* zT_20;
    zT_21D3708C_U32ToU32Map zT_23 = {0};
    zT_3E40CD83_Sand* zT_24;
    zT_21D3708C_U32ToU32Map zT_27 = {0};
    unsigned int zT_28;
    zT_D21A8776_SpillStore zT_29 = {0};
    zT_ABD0FF08_HashMapSpillMeta zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned char zT_34;
    zT_ABD0FF08_HashMapSpillMeta zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_38;
    unsigned char zT_39;
    zT_3E40CD83_Sand* zT_40;
    zT_F85C5DED_DiagnosticCollector* zT_41;
    zT_47A5CDFB_ImportQueue zT_42 = {0};
    zT_4 = alloc;
    zT_6 = 8;
    zT_8 = zF_CD3AB3CA_moduleEntryArrayLis(zT_4, (unsigned int)((unsigned int)zT_6));
    zT_3.modules = zT_8;
    zT_9 = 0;
    zT_3.import_edges_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.import_edges_len = zT_10;
    zT_11 = 0;
    zT_3.import_edges_cap = zT_11;
    zT_3.import_edges_alloc = alloc;
    zT_12 = alloc;
    zT_13 = interner;
    zT_14 = diag;
    zT_15 = zF_64765145_moduleResolverInit(zT_12, zT_13, zT_14);
    zT_3.resolver = zT_15;
    zT_3.interner = interner;
    zT_3.diag = diag;
    zT_17 = &zG_E8C23D2C_source_man_stub;
    zT_18 = (zT_227EDE07_SourceManager*)zT_17;
    zT_3.source_man = zT_18;
    zT_3.alloc = alloc;
    zT_19 = 0;
    zT_3.next_id = zT_19;
    zT_20 = alloc;
    zT_23 = zF_619D56E6_u32ToU32MapInitCap(zT_20, (unsigned int)(32));
    zT_3.path_to_id = zT_23;
    zT_24 = alloc;
    zT_27 = zF_619D56E6_u32ToU32MapInitCap(zT_24, (unsigned int)(32));
    zT_3.content_to_id = zT_27;
    zT_28 = 0;
    zT_3.hash_spill_path_len = zT_28;
    zT_29 = zF_22C79E6C_spillStoreInit();
    zT_3.spill = zT_29;
    zT_31 = 0;
    zT_30.disk_off = zT_31;
    zT_32 = 0;
    zT_30.capacity = zT_32;
    zT_33 = 0;
    zT_30.count = zT_33;
    zT_34 = 0;
    zT_30.spilled = zT_34;
    zT_3.path_to_id_spill = zT_30;
    zT_36 = 0;
    zT_35.disk_off = zT_36;
    zT_37 = 0;
    zT_35.capacity = zT_37;
    zT_38 = 0;
    zT_35.count = zT_38;
    zT_39 = 0;
    zT_35.spilled = zT_39;
    zT_3.content_to_id_spill = zT_35;
    zT_40 = alloc;
    zT_41 = diag;
    zT_42 = zF_4CF3FEA5_importQueueInit(zT_40, zT_41);
    zT_3.import_queue = zT_42;
    return zT_3;
}

/* moduleRegistrySetSourceMan */
void zF_BD2BF0BD_moduleRegistrySetSo(zT_072B53A6_ModuleRegistry* self, zT_227EDE07_SourceManager* sm) {
    self->source_man = sm;
    return;
}

/* moduleRegistryAddModule */
unsigned int zF_E4DCE20D_moduleRegistryAddMo(zT_072B53A6_ModuleRegistry* self, unsigned int path_id) {
    unsigned int zT_3;
    zT_6E8D187B_ModuleEntry zT_5;
    unsigned int zT_6;
    zT_9FE1BFFE_ModuleState zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_3E40CD83_Sand* zT_13;
    zT_B687BB96_U32ArrayList zT_15 = {0};
    zT_E41AEC18_ModuleEntryArrayLis* zT_16;
    zT_6E8D187B_ModuleEntry zT_17;
    unsigned int zT_19;
    int zT_20;
    unsigned int id;
    zT_6E8D187B_ModuleEntry entry;
    zT_3 = self->next_id;
    id = zT_3;
    zT_5.id = id;
    zT_5.path_id = path_id;
    zT_6 = 0;
    zT_5.source_file_id = zT_6;
    zT_7 = zT_9FE1BFFE_ModuleState_pending;
    zT_5.state = zT_7;
    zT_8 = 0;
    zT_5.ast_root = zT_8;
    zT_9 = 0;
    zT_5.import_count = zT_9;
    zT_10 = 0;
    zT_5.imports_start = zT_10;
    zT_11 = 0;
    zT_5.symbol_table = zT_11;
    zT_12 = 0;
    zT_5.type_offset = zT_12;
    zT_13 = self->alloc;
    zT_15 = zF_8E537D0C_u32ArrayListInit(zT_13);
    zT_5.c_includes = zT_15;
    entry = zT_5;
    zT_16 = &self->modules;
    zT_17 = entry;
    zF_ABB1AEC0_moduleEntryArrayLis(zT_16, zT_17);
    zT_19 = self->next_id;
    zT_20 = 1;
    self->next_id = (unsigned int)(zT_19 + (unsigned int)((unsigned int)zT_20));
    return id;
}

/* moduleRegistryGetModules */
zT_DDCD424B_Slice_zT_6E8D187B_M zF_3452C137_moduleRegistryGetMo(zT_072B53A6_ModuleRegistry* self) {
    zT_E41AEC18_ModuleEntryArrayLis zT_1;
    zT_6E8D187B_ModuleEntry* zT_2;
    zT_E41AEC18_ModuleEntryArrayLis zT_3;
    unsigned int zT_4;
    int zT_5;
    zT_6E8D187B_ModuleEntry* zT_6;
    unsigned int zT_7;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_8;
    zT_1 = self->modules;
    zT_2 = zT_1.items;
    zT_3 = self->modules;
    zT_4 = zT_3.len;
    zT_5 = 0;
    zT_6 = zT_2 + zT_5;
    zT_7 = zT_4 - zT_5;
    zT_8.ptr = zT_6;
    zT_8.len = zT_7;
    return zT_8;
}

/* moduleRegistryAssertPathToIdResident */
void zF_D00A7313_moduleRegistryAsser(zT_072B53A6_ModuleRegistry* self) {
    zT_ABD0FF08_HashMapSpillMeta zT_1;
    unsigned char zT_2;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    zT_1 = self->path_to_id_spill;
    zT_2 = zT_1.spilled;
    if ((int)(zT_2 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = "direct path_to_id access after spill; route through moduleRegistryPathToIdGet";
    zT_8 = 77;
    zT_7.ptr = zT_6;
    zT_7.len = zT_8;
    emsg = zT_7;
    zT_10 = "module_registry.zig";
    zT_12 = 19;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    ef = zT_11;
    zT_13 = emsg;
    zT_14 = ef;
    zT_16 = 331;
    zF_6D97D338_panicHandler(zT_13, zT_14, (unsigned int)((unsigned int)zT_16));
    return;
    z_bb_2:
    return;
}

/* moduleRegistryGetOrCreateModule */
unsigned int zF_AEB49EC3_moduleRegistryGetOr(zT_072B53A6_ModuleRegistry* self, unsigned int path_id) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_21D3708C_U32ToU32Map* zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_7 = {0};
    unsigned char zT_8;
    zT_072B53A6_ModuleRegistry* zT_11;
    unsigned int zT_12;
    unsigned int zT_13 = 0;
    zT_21D3708C_U32ToU32Map* zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_BAEE192E_Opt_10 existing;
    unsigned int id;
    unsigned int new_id;
    zT_2 = self;
    zF_D00A7313_moduleRegistryAsser(zT_2);
    zT_4 = &self->path_to_id;
    zT_5 = path_id;
    zT_7 = zF_F3EE5998_u32ToU32MapGet(zT_4, zT_5);
    existing = zT_7;
    zT_8 = existing.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    id = existing.value;
    return id;
    z_bb_2:
    zT_11 = self;
    zT_12 = path_id;
    zT_13 = zF_E4DCE20D_moduleRegistryAddMo(zT_11, zT_12);
    new_id = zT_13;
    zT_14 = &self->path_to_id;
    zT_15 = path_id;
    zT_16 = new_id;
    zF_26476265_u32ToU32MapPut(zT_14, zT_15, zT_16);
    return new_id;
}

/* moduleRegistryAddImport */
void zF_F9E76704_moduleRegistryAddIm(zT_072B53A6_ModuleRegistry* self, unsigned int importer_id, unsigned int imported_id) {
    unsigned int** zT_3;
    unsigned int* zT_4;
    unsigned int* zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_7;
    zT_E41AEC18_ModuleEntryArrayLis zT_13;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_23;
    int zT_24;
    zT_E41AEC18_ModuleEntryArrayLis zT_27;
    zT_6E8D187B_ModuleEntry* zT_28;
    zT_6E8D187B_ModuleEntry entry;
    zT_3 = &self->import_edges_items;
    zT_4 = &self->import_edges_len;
    zT_5 = &self->import_edges_cap;
    zT_6 = self->import_edges_alloc;
    zT_7 = imported_id;
    zF_358620BA_importEdgesAppend(zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_13 = self->modules;
    zT_14 = zT_13.items;
    zT_15 = zT_14[importer_id];
    entry = zT_15;
    zT_16 = entry.import_count;
    if ((int)(zT_16 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = self->import_edges_len;
    zT_20 = 1;
    entry.imports_start = (unsigned int)((unsigned int)(unsigned int)(zT_19 - zT_20));
    goto z_bb_2;
    z_bb_2:
    zT_23 = entry.import_count;
    zT_24 = 1;
    entry.import_count = (unsigned int)(zT_23 + (unsigned int)((unsigned int)zT_24));
    zT_27 = self->modules;
    zT_28 = zT_27.items;
    zT_28[importer_id] = entry;
    return;
}

/* moduleRegistryResolveImport */
zT_BAEE192E_Opt_10 zF_620E3E3B_moduleRegistryResol(zT_072B53A6_ModuleRegistry* self, unsigned int path_id, unsigned int importer_id, zT_3E40CD83_Sand* scratch) {
    zT_072B53A6_ModuleRegistry* zT_4;
    zT_D3EB6303_StringInterner* zT_6;
    unsigned int zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9 = {0};
    zT_D3EB6303_StringInterner* zT_11;
    unsigned int zT_12;
    zT_E41AEC18_ModuleEntryArrayLis zT_14;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18 = {0};
    zT_4DB1475B_ModuleResolver* zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    zT_3E40CD83_Sand* zT_23;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    unsigned int zT_27;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int zT_41;
    zT_D3EB6303_StringInterner* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_44;
    int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_BAEE192E_Opt_10 zT_68 = {0};
    zT_21D3708C_U32ToU32Map* zT_71;
    unsigned int zT_72;
    zT_BAEE192E_Opt_10 zT_74 = {0};
    unsigned char zT_75;
    zT_072B53A6_ModuleRegistry* zT_77;
    unsigned int zT_78;
    unsigned int zT_79;
    zT_47A5CDFB_ImportQueue* zT_80;
    unsigned int zT_81;
    zT_21D3708C_U32ToU32Map* zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_BAEE192E_Opt_10 zT_87;
    zT_D3EB6303_StringInterner* zT_89;
    unsigned int zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_94;
    zT_3E40CD83_Sand* zT_95;
    zT_13D0AA3A_Opt_438 zT_96 = {0};
    unsigned char zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    zT_072B53A6_ModuleRegistry* zT_101;
    unsigned int zT_102;
    unsigned int zT_103 = 0;
    zT_072B53A6_ModuleRegistry* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    zT_47A5CDFB_ImportQueue* zT_107;
    unsigned int zT_108;
    zT_21D3708C_U32ToU32Map* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_BAEE192E_Opt_10 zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_117;
    unsigned int zT_118 = 0;
    zT_21D3708C_U32ToU32Map* zT_120;
    unsigned int zT_121;
    zT_BAEE192E_Opt_10 zT_123 = {0};
    unsigned char zT_124;
    zT_21D3708C_U32ToU32Map* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    zT_072B53A6_ModuleRegistry* zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    zT_47A5CDFB_ImportQueue* zT_133;
    unsigned int zT_134;
    zT_21D3708C_U32ToU32Map* zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    zT_BAEE192E_Opt_10 zT_140;
    zT_072B53A6_ModuleRegistry* zT_142;
    unsigned int zT_143;
    unsigned int zT_144 = 0;
    zT_21D3708C_U32ToU32Map* zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    zT_072B53A6_ModuleRegistry* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_47A5CDFB_ImportQueue* zT_152;
    unsigned int zT_153;
    zT_21D3708C_U32ToU32Map* zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    zT_BAEE192E_Opt_10 zT_159;
    zT_8F083A69_Slice_zT_0B42B2F8_u path_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u importer_path;
    unsigned int resolved_path_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u p1;
    zT_8F083A69_Slice_zT_0B42B2F8_u p2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli parts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_BAEE192E_Opt_10 by_path;
    unsigned int existing_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u resolved_path_s;
    zT_8F083A69_Slice_zT_0B42B2F8_u content;
    unsigned int mod_id;
    unsigned int c_hash;
    zT_BAEE192E_Opt_10 by_content;
    unsigned int target_id;
    zT_4 = self;
    zF_D00A7313_moduleRegistryAsser(zT_4);
    zT_6 = self->interner;
    zT_7 = path_id;
    zT_9 = zF_9134020D_stringInternerGet(zT_6, zT_7);
    path_s = zT_9;
    zT_11 = self->interner;
    zT_14 = self->modules;
    zT_15 = zT_14.items;
    zT_16 = zT_15[importer_id];
    zT_12 = zT_16.path_id;
    zT_18 = zF_9134020D_stringInternerGet(zT_11, zT_12);
    importer_path = zT_18;
    zT_20 = &self->resolver;
    zT_21 = importer_path;
    zT_22 = path_s;
    zT_23 = scratch;
    zT_25 = zF_6F148E15_moduleResolverResol(zT_20, zT_21, zT_22, zT_23);
    zT_26 = zT_25.has_value;
    if (zT_26) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_30 = "could not resolve imported file '";
    zT_32 = 33;
    zT_31.ptr = zT_30;
    zT_31.len = zT_32;
    p1 = zT_31;
    zT_34 = "'";
    zT_36 = 1;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    p2 = zT_35;
    zT_39 = 0;
    zT_38[zT_39] = p1;
    zT_40 = 1;
    zT_38[zT_40] = path_s;
    zT_41 = 2;
    zT_38[zT_41] = p2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        parts[_i] = zT_38[_i];
        _i++;
    }
}
    zT_43 = self->interner;
    zT_47 = 0;
    zT_48 = parts + zT_47;
    zT_44 = zT_48;
    zT_50 = zF_8C4BFF7C_diagnosticBuilderMa(zT_43, zT_44, (unsigned int)(3));
    msg = zT_50;
    zT_51 = self->diag;
    zT_57 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_51, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3048_CANNOT_READ_FILE)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_57);
    zT_68.has_value = 0;
    return zT_68;
    z_bb_2:
    zT_27 = zT_25.value;
    goto z_bb_3;
    z_bb_3:
    resolved_path_id = zT_27;
    zT_71 = &self->path_to_id;
    zT_72 = resolved_path_id;
    zT_74 = zF_F3EE5998_u32ToU32MapGet(zT_71, zT_72);
    by_path = zT_74;
    zT_75 = by_path.has_value;
    if (zT_75) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    existing_id = by_path.value;
    zT_77 = self;
    zT_78 = importer_id;
    zT_79 = existing_id;
    zF_F9E76704_moduleRegistryAddIm(zT_77, zT_78, zT_79);
    zT_80 = &self->import_queue;
    zT_81 = existing_id;
    zF_9BB96D13_importQueueEnqueue(zT_80, zT_81);
    zT_83 = &self->path_to_id;
    zT_84 = path_id;
    zT_85 = existing_id;
    zF_26476265_u32ToU32MapPut(zT_83, zT_84, zT_85);
    (void)self;
    zT_87.has_value = 1;
    zT_87.value = existing_id;
    return zT_87;
    z_bb_5:
    zT_89 = self->interner;
    zT_90 = resolved_path_id;
    zT_92 = zF_9134020D_stringInternerGet(zT_89, zT_90);
    resolved_path_s = zT_92;
    zT_94 = resolved_path_s;
    zT_95 = scratch;
    zT_96 = zF_5B859C63_readFile(zT_94, zT_95);
    zT_97 = zT_96.has_value;
    if (zT_97) goto z_bb_7; else goto z_bb_6;
    z_bb_6:
    zT_101 = self;
    zT_102 = resolved_path_id;
    zT_103 = zF_AEB49EC3_moduleRegistryGetOr(zT_101, zT_102);
    mod_id = zT_103;
    zT_104 = self;
    zT_105 = importer_id;
    zT_106 = mod_id;
    zF_F9E76704_moduleRegistryAddIm(zT_104, zT_105, zT_106);
    zT_107 = &self->import_queue;
    zT_108 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_107, zT_108);
    zT_110 = &self->path_to_id;
    zT_111 = path_id;
    zT_112 = mod_id;
    zF_26476265_u32ToU32MapPut(zT_110, zT_111, zT_112);
    (void)self;
    zT_114.has_value = 1;
    zT_114.value = mod_id;
    return zT_114;
    z_bb_7:
    zT_115 = zT_96.value;
    zT_98 = zT_115;
    goto z_bb_8;
    z_bb_8:
    content = zT_98;
    zT_117 = content;
    zT_118 = zF_B22E025B_fnv1a(zT_117);
    c_hash = zT_118;
    zT_120 = &self->content_to_id;
    zT_121 = c_hash;
    zT_123 = zF_F3EE5998_u32ToU32MapGet(zT_120, zT_121);
    by_content = zT_123;
    zT_124 = by_content.has_value;
    if (zT_124) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    target_id = by_content.value;
    zT_126 = &self->path_to_id;
    zT_127 = resolved_path_id;
    zT_128 = target_id;
    zF_26476265_u32ToU32MapPut(zT_126, zT_127, zT_128);
    (void)self;
    zT_130 = self;
    zT_131 = importer_id;
    zT_132 = target_id;
    zF_F9E76704_moduleRegistryAddIm(zT_130, zT_131, zT_132);
    zT_133 = &self->import_queue;
    zT_134 = target_id;
    zF_9BB96D13_importQueueEnqueue(zT_133, zT_134);
    zT_136 = &self->path_to_id;
    zT_137 = path_id;
    zT_138 = target_id;
    zF_26476265_u32ToU32MapPut(zT_136, zT_137, zT_138);
    (void)self;
    zT_140.has_value = 1;
    zT_140.value = target_id;
    return zT_140;
    z_bb_10:
    zT_142 = self;
    zT_143 = resolved_path_id;
    zT_144 = zF_AEB49EC3_moduleRegistryGetOr(zT_142, zT_143);
    mod_id = zT_144;
    zT_145 = &self->content_to_id;
    zT_146 = c_hash;
    zT_147 = mod_id;
    zF_26476265_u32ToU32MapPut(zT_145, zT_146, zT_147);
    (void)self;
    zT_149 = self;
    zT_150 = importer_id;
    zT_151 = mod_id;
    zF_F9E76704_moduleRegistryAddIm(zT_149, zT_150, zT_151);
    zT_152 = &self->import_queue;
    zT_153 = mod_id;
    zF_9BB96D13_importQueueEnqueue(zT_152, zT_153);
    zT_155 = &self->path_to_id;
    zT_156 = path_id;
    zT_157 = mod_id;
    zF_26476265_u32ToU32MapPut(zT_155, zT_156, zT_157);
    (void)self;
    zT_159.has_value = 1;
    zT_159.value = mod_id;
    return zT_159;
}

/* hashSpillWriteU32 */
void zF_67A3663A_hashSpillWriteU32(zT_D21A8776_SpillStore* s, unsigned int v) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_3;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_12;
    int zT_13;
    unsigned char zT_18;
    int zT_19;
    unsigned char zT_24;
    int zT_25;
    zT_D21A8776_SpillStore* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_3[_i];
        _i++;
    }
}
    zT_6 = (unsigned char)(unsigned int)(v & (unsigned int)(255));
    zT_7 = 0;
    b[zT_7] = zT_6;
    zT_12 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(8)) & (unsigned int)(255));
    zT_13 = 1;
    b[zT_13] = zT_12;
    zT_18 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(16)) & (unsigned int)(255));
    zT_19 = 2;
    b[zT_19] = zT_18;
    zT_24 = (unsigned char)(unsigned int)((unsigned int)(v >> (unsigned int)(24)) & (unsigned int)(255));
    zT_25 = 3;
    b[zT_25] = zT_24;
    zT_26 = s;
    zT_27 = s->cur;
    zT_32 = 0;
    zT_33 = (unsigned char*)((unsigned char*)b) + zT_32;
    zT_34 = (unsigned int)(4) - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_28 = zT_35;
    zF_BFB33631_spillWriteAt(zT_26, zT_27, zT_28);
    return;
}

/* hashSpillReadU32 */
unsigned int zF_C8FC272D_hashSpillReadU32(zT_D21A8776_SpillStore* s) {
    zT_B5AAF170_Arr_unsigned_char_4 zT_2;
    zT_D21A8776_SpillStore* zT_3;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_14;
    int zT_15;
    unsigned char zT_16;
    unsigned int zT_18;
    int zT_19;
    unsigned char zT_20;
    unsigned int zT_24;
    int zT_25;
    unsigned char zT_26;
    unsigned int zT_30;
    int zT_31;
    unsigned char zT_32;
    unsigned int zT_36;
    zT_B5AAF170_Arr_unsigned_char_4 b;
    unsigned int v;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_3 = s;
    zT_4 = s->cur;
    zT_9 = 0;
    zT_10 = (unsigned char*)((unsigned char*)b) + zT_9;
    zT_11 = (unsigned int)(4) - zT_9;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    zT_5 = zT_12;
    zF_E9F67450_spillReadAt(zT_3, zT_4, zT_5);
    zT_14 = 0;
    v = zT_14;
    zT_15 = 0;
    zT_16 = b[zT_15];
    zT_18 = v | (unsigned int)((unsigned int)zT_16);
    v = zT_18;
    zT_19 = 1;
    zT_20 = b[zT_19];
    zT_24 = v | (unsigned int)((unsigned int)((unsigned int)zT_20) << (unsigned int)(8));
    v = zT_24;
    zT_25 = 2;
    zT_26 = b[zT_25];
    zT_30 = v | (unsigned int)((unsigned int)((unsigned int)zT_26) << (unsigned int)(16));
    v = zT_30;
    zT_31 = 3;
    zT_32 = b[zT_31];
    zT_36 = v | (unsigned int)((unsigned int)((unsigned int)zT_32) << (unsigned int)(24));
    v = zT_36;
    return v;
}

/* hashSpillWriteMap */
void zF_090598CE_hashSpillWriteMap(zT_D21A8776_SpillStore* s, zT_21D3708C_U32ToU32Map* m, zT_ABD0FF08_HashMapSpillMeta* meta) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_D21A8776_SpillStore* zT_7;
    unsigned int zT_9;
    zT_D21A8776_SpillStore* zT_11;
    unsigned int zT_13;
    unsigned int zT_15;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int* zT_27;
    unsigned char* zT_28;
    unsigned int* zT_30;
    unsigned char* zT_31;
    unsigned char* zT_33;
    unsigned char* zT_34;
    int zT_36;
    unsigned char* zT_37;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    int zT_41;
    unsigned char* zT_42;
    unsigned int zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_46;
    int zT_47;
    unsigned char* zT_48;
    unsigned int zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    zT_D21A8776_SpillStore* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_D21A8776_SpillStore* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    zT_D21A8776_SpillStore* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int keys_bytes;
    unsigned int vals_bytes;
    unsigned char* keys_ptr;
    unsigned char* vals_ptr;
    unsigned char* occ_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u keys_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u vals_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u occ_slice;
    zT_3 = s->cur;
    meta->disk_off = zT_3;
    zT_4 = m->capacity;
    meta->capacity = zT_4;
    zT_5 = m->count;
    meta->count = zT_5;
    meta->spilled = (unsigned char)(1);
    zT_7 = s;
    zT_9 = m->capacity;
    zF_67A3663A_hashSpillWriteU32(zT_7, (unsigned int)((unsigned int)zT_9));
    zT_11 = s;
    zT_13 = m->count;
    zF_67A3663A_hashSpillWriteU32(zT_11, (unsigned int)((unsigned int)zT_13));
    zT_15 = m->capacity;
    if ((int)(zT_15 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_19 = m->capacity;
    zT_21 = zT_19 * (unsigned int)(4);
    keys_bytes = zT_21;
    zT_23 = m->capacity;
    zT_25 = zT_23 * (unsigned int)(4);
    vals_bytes = zT_25;
    zT_27 = m->keys;
    zT_28 = (unsigned char*)zT_27;
    keys_ptr = zT_28;
    zT_30 = m->values;
    zT_31 = (unsigned char*)zT_30;
    vals_ptr = zT_31;
    zT_33 = m->occupied;
    zT_34 = (unsigned char*)zT_33;
    occ_ptr = zT_34;
    zT_36 = 0;
    zT_37 = keys_ptr + zT_36;
    zT_38 = keys_bytes - zT_36;
    zT_39.ptr = zT_37;
    zT_39.len = zT_38;
    keys_slice = zT_39;
    zT_41 = 0;
    zT_42 = vals_ptr + zT_41;
    zT_43 = vals_bytes - zT_41;
    zT_44.ptr = zT_42;
    zT_44.len = zT_43;
    vals_slice = zT_44;
    zT_46 = m->capacity;
    zT_47 = 0;
    zT_48 = occ_ptr + zT_47;
    zT_49 = zT_46 - zT_47;
    zT_50.ptr = zT_48;
    zT_50.len = zT_49;
    occ_slice = zT_50;
    zT_51 = s;
    zT_52 = s->cur;
    zT_53 = keys_slice;
    zF_BFB33631_spillWriteAt(zT_51, zT_52, zT_53);
    zT_55 = s;
    zT_56 = s->cur;
    zT_57 = vals_slice;
    zF_BFB33631_spillWriteAt(zT_55, zT_56, zT_57);
    zT_59 = s;
    zT_60 = s->cur;
    zT_61 = occ_slice;
    zF_BFB33631_spillWriteAt(zT_59, zT_60, zT_61);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* moduleRegistrySpillHashMaps */
void zF_8767909B_moduleRegistrySpill(zT_072B53A6_ModuleRegistry* self, zT_8F083A69_Slice_zT_0B42B2F8_u spill_path) {
    unsigned int zT_3;
    unsigned int zT_5;
    int zT_7;
    unsigned char* zT_10;
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned int zT_14;
    unsigned char zT_15;
    unsigned char* zT_16;
    zT_0426DCE7_SpillBackend zT_21 = 0;
    zT_D21A8776_SpillStore* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_28;
    zT_3E40CD83_Sand* zT_29;
    unsigned char* zT_30;
    zT_D21A8776_SpillStore* zT_37;
    zT_21D3708C_U32ToU32Map* zT_38;
    zT_ABD0FF08_HashMapSpillMeta* zT_39;
    zT_D21A8776_SpillStore* zT_43;
    zT_21D3708C_U32ToU32Map* zT_44;
    zT_ABD0FF08_HashMapSpillMeta* zT_45;
    zT_D21A8776_SpillStore* zT_49;
    zT_21D3708C_U32ToU32Map* zT_52;
    zT_21D3708C_U32ToU32Map* zT_54;
    int zT_55;
    zT_21D3708C_U32ToU32Map* zT_56;
    int zT_57;
    zT_21D3708C_U32ToU32Map* zT_58;
    int zT_59;
    zT_21D3708C_U32ToU32Map* zT_60;
    zT_21D3708C_U32ToU32Map* zT_62;
    zT_21D3708C_U32ToU32Map* zT_64;
    int zT_65;
    zT_21D3708C_U32ToU32Map* zT_66;
    int zT_67;
    zT_21D3708C_U32ToU32Map* zT_68;
    int zT_69;
    zT_21D3708C_U32ToU32Map* zT_70;
    unsigned int i;
    zT_3 = 0;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_5 = spill_path.len;
    if ((int)(i < zT_5)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_10 = spill_path.ptr;
    zT_11 = zT_10[i];
    zT_12 = self->hash_spill_path;
    zT_12[i] = zT_11;
    goto z_bb_4;
    z_bb_3:
    self->hash_spill_path_len = i;
    zT_15 = 0;
    zT_16 = self->hash_spill_path;
    zT_16[i] = zT_15;
    zT_21 = zF_1AA39172_spillBackendFor((zT_F12DA458_SpillId)(zT_F12DA458_SpillId_s_hash));
    if ((int)(zT_21 == (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_ram))) goto z_bb_8; else goto z_bb_9;
    z_bb_4:
    zT_14 = i + (unsigned int)(1);
    i = zT_14;
    goto z_bb_1;
    z_bb_5:
    zT_7 = i < (unsigned int)(511);
    goto z_bb_7;
    z_bb_6:
    zT_7 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_7) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    return;
    z_bb_9:
    zT_26 = &self->spill;
    zT_28 = spill_path;
    zT_29 = self->alloc;
    zT_30 = zG_034DEF1E_HASH_SPILL_WRITE_MO;
    zF_8AF94F71_spillOpen(zT_26, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_28, zT_29, zT_30);
    zT_37 = &self->spill;
    zT_38 = &self->path_to_id;
    zT_39 = &self->path_to_id_spill;
    zF_090598CE_hashSpillWriteMap(zT_37, zT_38, zT_39);
    zT_43 = &self->spill;
    zT_44 = &self->content_to_id;
    zT_45 = &self->content_to_id_spill;
    zF_090598CE_hashSpillWriteMap(zT_43, zT_44, zT_45);
    zT_49 = &self->spill;
    zF_DB2CDC3B_spillClose(zT_49);
    zT_52 = &self->path_to_id;
    zT_52->capacity = (unsigned int)(0);
    zT_54 = &self->path_to_id;
    zT_54->count = (unsigned int)(0);
    zT_55 = 0;
    zT_56 = &self->path_to_id;
    zT_56->keys = (unsigned int*)zT_55;
    zT_57 = 0;
    zT_58 = &self->path_to_id;
    zT_58->values = (unsigned int*)zT_57;
    zT_59 = 0;
    zT_60 = &self->path_to_id;
    zT_60->occupied = (unsigned char*)zT_59;
    zT_62 = &self->content_to_id;
    zT_62->capacity = (unsigned int)(0);
    zT_64 = &self->content_to_id;
    zT_64->count = (unsigned int)(0);
    zT_65 = 0;
    zT_66 = &self->content_to_id;
    zT_66->keys = (unsigned int*)zT_65;
    zT_67 = 0;
    zT_68 = &self->content_to_id;
    zT_68->values = (unsigned int*)zT_67;
    zT_69 = 0;
    zT_70 = &self->content_to_id;
    zT_70->occupied = (unsigned char*)zT_69;
    return;
}

/* moduleRegistryFaultInPathToId */
void zF_34911396_moduleRegistryFault(zT_072B53A6_ModuleRegistry* self) {
    zT_ABD0FF08_HashMapSpillMeta zT_1;
    unsigned char zT_2;
    unsigned int zT_5;
    unsigned char* zT_9;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10;
    unsigned int zT_11;
    unsigned char* zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned int zT_15;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    int zT_19;
    zT_D21A8776_SpillStore* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_3E40CD83_Sand* zT_24;
    unsigned char* zT_25;
    unsigned char* zT_30;
    unsigned int zT_31;
    int zT_32;
    unsigned char* zT_33;
    unsigned int zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    zT_D21A8776_SpillStore* zT_38;
    unsigned int zT_39;
    zT_ABD0FF08_HashMapSpillMeta zT_41;
    zT_D21A8776_SpillStore* zT_44;
    unsigned int zT_46 = 0;
    unsigned int zT_47;
    zT_D21A8776_SpillStore* zT_49;
    unsigned int zT_51 = 0;
    unsigned int zT_52;
    zT_ABD0FF08_HashMapSpillMeta zT_53;
    unsigned int zT_54;
    int zT_56;
    zT_ABD0FF08_HashMapSpillMeta zT_57;
    unsigned int zT_58;
    unsigned char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    unsigned char* zT_65;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_66;
    unsigned int zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    int zT_71;
    unsigned char* zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    int zT_85;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_98;
    int zT_100;
    zT_3E40CD83_Sand* zT_105;
    zT_21D3708C_U32ToU32Map zT_108;
    zT_C6536882_EU_532 zT_113 = {0};
    unsigned char zT_114;
    unsigned char* zT_115;
    zT_3E40CD83_Sand* zT_118;
    zT_21D3708C_U32ToU32Map zT_121;
    zT_C6536882_EU_532 zT_126 = {0};
    unsigned char zT_127;
    unsigned char* zT_128;
    zT_3E40CD83_Sand* zT_131;
    zT_21D3708C_U32ToU32Map zT_134;
    zT_C6536882_EU_532 zT_139 = {0};
    unsigned char zT_140;
    unsigned char* zT_141;
    unsigned int zT_145;
    unsigned int zT_148;
    unsigned char* zT_150;
    unsigned char* zT_152;
    unsigned char* zT_154;
    int zT_156;
    unsigned char* zT_157;
    unsigned int zT_158;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_159;
    int zT_161;
    unsigned char* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    int zT_166;
    unsigned char* zT_167;
    unsigned int zT_168;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169;
    zT_D21A8776_SpillStore* zT_170;
    unsigned int zT_171;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_172;
    zT_D21A8776_SpillStore zT_174;
    zT_D21A8776_SpillStore* zT_176;
    unsigned int zT_177;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_178;
    zT_D21A8776_SpillStore zT_180;
    zT_D21A8776_SpillStore* zT_182;
    unsigned int zT_183;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_184;
    zT_D21A8776_SpillStore zT_186;
    zT_21D3708C_U32ToU32Map* zT_189;
    zT_21D3708C_U32ToU32Map* zT_191;
    zT_21D3708C_U32ToU32Map* zT_193;
    zT_21D3708C_U32ToU32Map* zT_194;
    zT_21D3708C_U32ToU32Map* zT_195;
    zT_D21A8776_SpillStore* zT_196;
    zT_ABD0FF08_HashMapSpillMeta* zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u emsg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ef;
    unsigned int cap;
    unsigned int cnt;
    unsigned char* raw_keys;
    unsigned char* raw_vals;
    unsigned char* raw_occ;
    unsigned int keys_bytes;
    unsigned int vals_bytes;
    unsigned char* keys_ptr;
    unsigned char* vals_ptr;
    unsigned char* occ_ptr;
    zT_8F083A69_Slice_zT_0B42B2F8_u keys_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u vals_slice;
    zT_8F083A69_Slice_zT_0B42B2F8_u occ_slice;
    zT_1 = self->path_to_id_spill;
    zT_2 = zT_1.spilled;
    if ((int)(zT_2 == (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = self->hash_spill_path_len;
    if ((int)(zT_5 == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = "hash spill state inconsistent: spilled with no spill path (moduleRegistryFaultInPathToId)";
    zT_11 = 89;
    zT_10.ptr = zT_9;
    zT_10.len = zT_11;
    emsg = zT_10;
    zT_13 = "module_registry.zig";
    zT_15 = 19;
    zT_14.ptr = zT_13;
    zT_14.len = zT_15;
    ef = zT_14;
    zT_16 = emsg;
    zT_17 = ef;
    zT_19 = 488;
    zF_6D97D338_panicHandler(zT_16, zT_17, (unsigned int)((unsigned int)zT_19));
    return;
    z_bb_4:
    zT_21 = &self->spill;
    zT_30 = self->hash_spill_path;
    zT_31 = self->hash_spill_path_len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_23 = zT_35;
    zT_24 = self->alloc;
    zT_25 = zG_1DDFFDDD_HASH_SPILL_READ_MOD;
    zF_8AF94F71_spillOpen(zT_21, (zT_0426DCE7_SpillBackend)(zT_0426DCE7_SpillBackend_disk), zT_23, zT_24, zT_25);
    zT_38 = &self->spill;
    zT_41 = self->path_to_id_spill;
    zT_39 = zT_41.disk_off;
    zF_56A911A9_spillSeek(zT_38, zT_39);
    zT_44 = &self->spill;
    zT_46 = zF_C8FC272D_hashSpillReadU32(zT_44);
    zT_47 = (unsigned int)zT_46;
    cap = zT_47;
    zT_49 = &self->spill;
    zT_51 = zF_C8FC272D_hashSpillReadU32(zT_49);
    zT_52 = (unsigned int)zT_51;
    cnt = zT_52;
    zT_53 = self->path_to_id_spill;
    zT_54 = zT_53.capacity;
    if ((int)(cap != zT_54)) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_57 = self->path_to_id_spill;
    zT_58 = zT_57.count;
    zT_56 = cnt != zT_58;
    goto z_bb_7;
    z_bb_6:
    zT_56 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_56) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_61 = "hash spill header cap/count mismatch vs recorded spill metadata (moduleRegistryFaultInPathToId)";
    zT_63 = 95;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    emsg = zT_62;
    zT_65 = "module_registry.zig";
    zT_67 = 19;
    zT_66.ptr = zT_65;
    zT_66.len = zT_67;
    ef = zT_66;
    zT_68 = emsg;
    zT_69 = ef;
    zT_71 = 504;
    zF_6D97D338_panicHandler(zT_68, zT_69, (unsigned int)((unsigned int)zT_71));
    return;
    z_bb_9:
    if ((int)(cnt > cap)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_75 = "hash spill header count exceeds capacity (moduleRegistryFaultInPathToId)";
    zT_77 = 72;
    zT_76.ptr = zT_75;
    zT_76.len = zT_77;
    emsg = zT_76;
    zT_79 = "module_registry.zig";
    zT_81 = 19;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    ef = zT_80;
    zT_82 = emsg;
    zT_83 = ef;
    zT_85 = 510;
    zF_6D97D338_panicHandler(zT_82, zT_83, (unsigned int)((unsigned int)zT_85));
    return;
    z_bb_11:
    if ((int)(cap > zG_0BC1A97F_HASH_SPILL_MAX_MAP_)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_90 = "hash spill header capacity absurd (moduleRegistryFaultInPathToId)";
    zT_92 = 65;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    emsg = zT_91;
    zT_94 = "module_registry.zig";
    zT_96 = 19;
    zT_95.ptr = zT_94;
    zT_95.len = zT_96;
    ef = zT_95;
    zT_97 = emsg;
    zT_98 = ef;
    zT_100 = 516;
    zF_6D97D338_panicHandler(zT_97, zT_98, (unsigned int)((unsigned int)zT_100));
    return;
    z_bb_13:
    if ((int)(cap > (unsigned int)(0))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_108 = self->path_to_id;
    zT_105 = zT_108.alloc;
    zT_113 = zF_1395EB68_sandAlloc(zT_105, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_114 = zT_113.is_error;
    if (zT_114) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_196 = &self->spill;
    zF_DB2CDC3B_spillClose(zT_196);
    zT_199 = &self->path_to_id_spill;
    zT_199->spilled = (unsigned char)(0);
    return;
    z_bb_16:
    pal_trap();
    z_bb_17:
    zT_115 = zT_113.data.payload;
    goto z_bb_18;
    z_bb_18:
    raw_keys = zT_115;
    zT_121 = self->path_to_id;
    zT_118 = zT_121.alloc;
    zT_126 = zF_1395EB68_sandAlloc(zT_118, (unsigned int)((unsigned int)(4) * cap), (unsigned int)(4));
    zT_127 = zT_126.is_error;
    if (zT_127) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    pal_trap();
    z_bb_20:
    zT_128 = zT_126.data.payload;
    goto z_bb_21;
    z_bb_21:
    raw_vals = zT_128;
    zT_134 = self->path_to_id;
    zT_131 = zT_134.alloc;
    zT_139 = zF_1395EB68_sandAlloc(zT_131, (unsigned int)((unsigned int)(1) * cap), (unsigned int)(4));
    zT_140 = zT_139.is_error;
    if (zT_140) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    pal_trap();
    z_bb_23:
    zT_141 = zT_139.data.payload;
    goto z_bb_24;
    z_bb_24:
    raw_occ = zT_141;
    zT_145 = cap * (unsigned int)(4);
    keys_bytes = zT_145;
    zT_148 = cap * (unsigned int)(4);
    vals_bytes = zT_148;
    zT_150 = (unsigned char*)raw_keys;
    keys_ptr = zT_150;
    zT_152 = (unsigned char*)raw_vals;
    vals_ptr = zT_152;
    zT_154 = (unsigned char*)raw_occ;
    occ_ptr = zT_154;
    zT_156 = 0;
    zT_157 = keys_ptr + zT_156;
    zT_158 = keys_bytes - zT_156;
    zT_159.ptr = zT_157;
    zT_159.len = zT_158;
    keys_slice = zT_159;
    zT_161 = 0;
    zT_162 = vals_ptr + zT_161;
    zT_163 = vals_bytes - zT_161;
    zT_164.ptr = zT_162;
    zT_164.len = zT_163;
    vals_slice = zT_164;
    zT_166 = 0;
    zT_167 = occ_ptr + zT_166;
    zT_168 = cap - zT_166;
    zT_169.ptr = zT_167;
    zT_169.len = zT_168;
    occ_slice = zT_169;
    zT_170 = &self->spill;
    zT_174 = self->spill;
    zT_171 = zT_174.cur;
    zT_172 = keys_slice;
    zF_E9F67450_spillReadAt(zT_170, zT_171, zT_172);
    zT_176 = &self->spill;
    zT_180 = self->spill;
    zT_177 = zT_180.cur;
    zT_178 = vals_slice;
    zF_E9F67450_spillReadAt(zT_176, zT_177, zT_178);
    zT_182 = &self->spill;
    zT_186 = self->spill;
    zT_183 = zT_186.cur;
    zT_184 = occ_slice;
    zF_E9F67450_spillReadAt(zT_182, zT_183, zT_184);
    zT_189 = &self->path_to_id;
    zT_189->keys = (unsigned int*)((unsigned int*)raw_keys);
    zT_191 = &self->path_to_id;
    zT_191->values = (unsigned int*)((unsigned int*)raw_vals);
    zT_193 = &self->path_to_id;
    zT_193->occupied = (unsigned char*)((unsigned char*)raw_occ);
    zT_194 = &self->path_to_id;
    zT_194->capacity = cap;
    zT_195 = &self->path_to_id;
    zT_195->count = cnt;
    goto z_bb_15;
}

/* moduleRegistryPathToIdGet */
zT_BAEE192E_Opt_10 zF_A258E183_moduleRegistryPathT(zT_072B53A6_ModuleRegistry* self, unsigned int key) {
    zT_072B53A6_ModuleRegistry* zT_2;
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    zT_2 = self;
    zF_34911396_moduleRegistryFault(zT_2);
    zT_3 = &self->path_to_id;
    zT_4 = key;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    return zT_6;
}

/* importQueuePendingEnsureCapacity */
void zF_DB8D7B50_importQueuePendingE(unsigned int** items, unsigned int* len, unsigned int* cap, zT_3E40CD83_Sand* alloc, unsigned int new_cap) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    int zT_15;
    int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    int zT_20;
    zT_3E40CD83_Sand* zT_23;
    unsigned int* zT_28;
    unsigned int zT_30;
    zT_6F32B01B_Opt_235 zT_36 = {0};
    unsigned char zT_37;
    zT_3E40CD83_Sand* zT_39;
    zT_C6536882_EU_532 zT_45 = {0};
    unsigned char zT_46;
    unsigned char* zT_47;
    unsigned int* zT_50;
    unsigned int* zT_51;
    unsigned int zT_52;
    int zT_53;
    unsigned int* zT_54;
    unsigned int zT_55;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_56;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_63;
    unsigned int nc;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_5 = *cap;
    if ((int)(new_cap <= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_8 = *cap;
    zT_9 = 2;
    if ((int)(nc < (unsigned int)(zT_8 * zT_9))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = *cap;
    zT_13 = 2;
    zT_14 = zT_12 * zT_13;
    nc = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_15 = 8;
    if ((int)(nc < (unsigned int)zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 8;
    zT_18 = (unsigned int)zT_17;
    nc = zT_18;
    goto z_bb_6;
    z_bb_6:
    zT_19 = *cap;
    zT_20 = 0;
    if ((int)(zT_19 > (unsigned int)zT_20)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_23 = alloc;
    zT_28 = *items;
    zT_30 = *cap;
    zT_36 = zF_33A3D4F8_sandTryReallocInPla(zT_23, (unsigned char*)((unsigned char*)zT_28), (unsigned int)(zT_30 * (unsigned int)(4)), (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    grown = zT_36;
    zT_37 = grown.has_value;
    if (zT_37) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_39 = alloc;
    zT_45 = zF_1395EB68_sandAlloc(zT_39, (unsigned int)((unsigned int)(4) * nc), (unsigned int)(4));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    *cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_47 = zT_45.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_47;
    zT_50 = (unsigned int*)raw;
    new_items = zT_50;
    zT_51 = *items;
    zT_52 = *len;
    zT_53 = 0;
    zT_54 = zT_51 + zT_53;
    zT_55 = zT_52 - zT_53;
    zT_56.ptr = zT_54;
    zT_56.len = zT_55;
    zT_57 = zT_56.ptr;
    zT_58 = zT_56.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_58)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_57[i];
    new_items[i] = item;
    zT_63 = i + (unsigned int)(1);
    i = zT_63;
    goto z_bb_14;
    z_bb_16:
    *items = new_items;
    *cap = nc;
    return;
}

/* importQueuePendingAppend */
void zF_1649C2CE_importQueuePendingA(unsigned int** items, unsigned int* len, unsigned int* cap, zT_3E40CD83_Sand* alloc, unsigned int value) {
    unsigned int** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_10;
    int zT_11;
    unsigned int* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    zT_5 = items;
    zT_6 = len;
    zT_7 = cap;
    zT_8 = alloc;
    zT_10 = *len;
    zT_11 = 1;
    zF_DB8D7B50_importQueuePendingE(zT_5, zT_6, zT_7, zT_8, (unsigned int)(zT_10 + zT_11));
    zT_13 = *items;
    zT_14 = *len;
    zT_13[zT_14] = value;
    zT_15 = *len;
    zT_16 = 1;
    *len = (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16));
    return;
}

/* importQueuePendingPop */
zT_BAEE192E_Opt_10 zF_79A6B129_importQueuePendingP(unsigned int** items, unsigned int* len) {
    unsigned int zT_2;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned int zT_6;
    int zT_7;
    unsigned int* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_BAEE192E_Opt_10 zT_13;
    zT_2 = *len;
    if ((int)(zT_2 == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    zT_6 = *len;
    zT_7 = 1;
    *len = (unsigned int)(zT_6 - (unsigned int)((unsigned int)zT_7));
    zT_10 = *items;
    zT_11 = *len;
    zT_12 = zT_10[zT_11];
    zT_13.has_value = 1;
    zT_13.value = zT_12;
    return zT_13;
}

/* importQueueInit */
zT_47A5CDFB_ImportQueue zF_4CF3FEA5_importQueueInit(zT_3E40CD83_Sand* alloc, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_47A5CDFB_ImportQueue zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_47A5CDFB_ImportQueue q;
    zT_4 = 0;
    zT_3.pending_items = (unsigned int*)zT_4;
    zT_5 = 0;
    zT_3.pending_len = zT_5;
    zT_6 = 0;
    zT_3.pending_cap = zT_6;
    zT_3.pending_alloc = alloc;
    zT_3.diag = diag;
    q = zT_3;
    return q;
}

/* importQueueEnqueue */
void zF_9BB96D13_importQueueEnqueue(zT_47A5CDFB_ImportQueue* self, unsigned int module_id) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int* zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_12;
    unsigned int** zT_13;
    unsigned int* zT_14;
    unsigned int* zT_15;
    zT_3E40CD83_Sand* zT_16;
    unsigned int zT_17;
    unsigned int i;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = self->pending_len;
    if ((int)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self->pending_items;
    zT_8 = zT_7[i];
    if ((int)(zT_8 == module_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_13 = &self->pending_items;
    zT_14 = &self->pending_len;
    zT_15 = &self->pending_cap;
    zT_16 = self->pending_alloc;
    zT_17 = module_id;
    zF_1649C2CE_importQueuePendingA(zT_13, zT_14, zT_15, zT_16, zT_17);
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    return;
    z_bb_6:
    zT_10 = 1;
    zT_12 = i + (unsigned int)((unsigned int)zT_10);
    i = zT_12;
    goto z_bb_4;
}

/* importQueueDequeue */
zT_BAEE192E_Opt_10 zF_F8B96877_importQueueDequeue(zT_47A5CDFB_ImportQueue* self) {
    unsigned int** zT_1;
    unsigned int* zT_2;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    zT_1 = &self->pending_items;
    zT_2 = &self->pending_len;
    zT_5 = zF_79A6B129_importQueuePendingP(zT_1, zT_2);
    return zT_5;
}

/* moduleRegistrySortModules */
void zF_30C22573_moduleRegistrySortM(zT_072B53A6_ModuleRegistry* reg) {
    zT_E41AEC18_ModuleEntryArrayLis zT_2;
    unsigned int zT_3;
    zT_157C0A16_Arr_unsigned_int_25 zT_5;
    int zT_7;
    unsigned int zT_8;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    unsigned int zT_14;
    int zT_15;
    unsigned int zT_16;
    zT_E41AEC18_ModuleEntryArrayLis zT_19;
    zT_6E8D187B_ModuleEntry* zT_20;
    zT_6E8D187B_ModuleEntry zT_21;
    zT_9FE1BFFE_ModuleState zT_22;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_28;
    int zT_29;
    unsigned int zT_30;
    zT_157C0A16_Arr_unsigned_int_25 zT_32;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    int zT_38;
    int zT_40;
    zT_E41AEC18_ModuleEntryArrayLis zT_41;
    zT_6E8D187B_ModuleEntry* zT_42;
    zT_6E8D187B_ModuleEntry zT_43;
    zT_9FE1BFFE_ModuleState zT_44;
    unsigned int zT_47;
    int zT_48;
    unsigned int zT_50;
    int zT_51;
    unsigned int zT_53;
    int zT_55;
    unsigned int zT_56;
    int zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_66;
    unsigned int zT_67;
    int zT_68;
    unsigned int zT_70;
    int zT_71;
    unsigned int zT_73;
    int zT_75;
    unsigned int zT_76;
    int zT_77;
    int zT_79;
    unsigned int zT_81;
    unsigned int zT_83;
    unsigned int zT_85;
    zT_E41AEC18_ModuleEntryArrayLis zT_86;
    zT_6E8D187B_ModuleEntry* zT_87;
    zT_6E8D187B_ModuleEntry zT_88;
    zT_9FE1BFFE_ModuleState zT_89;
    zT_E41AEC18_ModuleEntryArrayLis zT_93;
    zT_6E8D187B_ModuleEntry* zT_94;
    zT_6E8D187B_ModuleEntry zT_95;
    zT_E41AEC18_ModuleEntryArrayLis zT_97;
    zT_6E8D187B_ModuleEntry* zT_98;
    int zT_99;
    unsigned int zT_101;
    int zT_103;
    unsigned int zT_104;
    zT_E41AEC18_ModuleEntryArrayLis zT_107;
    zT_6E8D187B_ModuleEntry* zT_108;
    zT_6E8D187B_ModuleEntry zT_109;
    zT_9FE1BFFE_ModuleState zT_110;
    unsigned int zT_114;
    unsigned int zT_115;
    unsigned int zT_117;
    unsigned int zT_119;
    unsigned int* zT_122;
    unsigned int zT_123;
    unsigned int zT_125;
    int zT_126;
    unsigned int zT_128;
    int zT_129;
    unsigned int zT_131;
    unsigned int zT_132;
    int zT_133;
    unsigned int zT_135;
    int zT_136;
    unsigned int zT_138;
    int zT_139;
    unsigned int zT_141;
    int zT_142;
    unsigned int zT_144;
    int zT_148;
    unsigned int zT_149;
    zT_E41AEC18_ModuleEntryArrayLis zT_152;
    zT_6E8D187B_ModuleEntry* zT_153;
    zT_6E8D187B_ModuleEntry zT_154;
    zT_9FE1BFFE_ModuleState zT_155;
    int zT_158;
    unsigned int zT_159;
    int zT_160;
    zT_D3EB6303_StringInterner* zT_163;
    unsigned int zT_164;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_167 = {0};
    unsigned char* zT_169;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_170;
    unsigned int zT_171;
    unsigned char* zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_174;
    unsigned int zT_175;
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_177;
    unsigned int zT_178;
    unsigned int zT_179;
    unsigned int zT_180;
    zT_D3EB6303_StringInterner* zT_182;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_183;
    zT_F85C5DED_DiagnosticCollector* zT_185;
    int zT_187;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_188;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_190 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_191;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    zT_E41AEC18_ModuleEntryArrayLis zT_209;
    zT_6E8D187B_ModuleEntry* zT_210;
    int zT_211;
    unsigned int zT_213;
    zT_072B53A6_ModuleRegistry* zT_214;
    unsigned int mod_count;
    zT_157C0A16_Arr_unsigned_int_25 in_degree;
    unsigned int i;
    zT_6E8D187B_ModuleEntry entry;
    zT_157C0A16_Arr_unsigned_int_25 worklist_items;
    unsigned int worklist_len;
    unsigned int si;
    unsigned int sj;
    unsigned int sorted_count;
    unsigned int tmp;
    unsigned int id;
    unsigned int id_idx;
    unsigned int ii;
    zT_6E8D187B_ModuleEntry imp_entry;
    unsigned int start;
    unsigned int end;
    unsigned int j;
    unsigned int ci;
    zT_8F083A69_Slice_zT_0B42B2F8_u mn;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp1;
    zT_8F083A69_Slice_zT_0B42B2F8_u cp2;
    zT_4C214FEE_Arr_zT_8F083A69_Sli cparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = reg->modules;
    zT_3 = zT_2.len;
    mod_count = zT_3;
    {
    unsigned int _i = 0;
    while (_i < 256) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 256) {
        in_degree[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    if ((int)(i < mod_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    in_degree[i] = zT_11;
    zT_12 = 1;
    zT_14 = i + (unsigned int)((unsigned int)zT_12);
    i = zT_14;
    goto z_bb_4;
    z_bb_3:
    zT_15 = 0;
    zT_16 = (unsigned int)zT_15;
    i = zT_16;
    goto z_bb_5;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    if ((int)(i < mod_count)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_19 = reg->modules;
    zT_20 = zT_19.items;
    zT_21 = zT_20[i];
    entry = zT_21;
    zT_22 = entry.state;
    if ((int)(zT_22 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_29 = 0;
    zT_30 = (unsigned int)zT_29;
    i = zT_30;
    {
    unsigned int _i = 0;
    while (_i < 256) {
        zT_32[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 256) {
        worklist_items[_i] = zT_32[_i];
        _i++;
    }
}
    zT_34 = 0;
    zT_35 = (unsigned int)zT_34;
    worklist_len = zT_35;
    goto z_bb_11;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_25 = entry.import_count;
    in_degree[i] = zT_25;
    goto z_bb_10;
    z_bb_10:
    zT_26 = 1;
    zT_28 = i + (unsigned int)((unsigned int)zT_26);
    i = zT_28;
    goto z_bb_8;
    z_bb_11:
    if ((int)(i < mod_count)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_37 = in_degree[i];
    zT_38 = 0;
    if ((int)(zT_37 == (unsigned int)zT_38)) goto z_bb_15; else goto z_bb_16;
    z_bb_13:
    zT_55 = 0;
    zT_56 = (unsigned int)zT_55;
    si = zT_56;
    goto z_bb_20;
    z_bb_14:
    goto z_bb_11;
    z_bb_15:
    zT_41 = reg->modules;
    zT_42 = zT_41.items;
    zT_43 = zT_42[i];
    zT_44 = zT_43.state;
    zT_40 = zT_44 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed);
    goto z_bb_17;
    z_bb_16:
    zT_40 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_40) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_47 = (unsigned int)i;
    worklist_items[worklist_len] = zT_47;
    zT_48 = 1;
    zT_50 = worklist_len + (unsigned int)((unsigned int)zT_48);
    worklist_len = zT_50;
    goto z_bb_19;
    z_bb_19:
    zT_51 = 1;
    zT_53 = i + (unsigned int)((unsigned int)zT_51);
    i = zT_53;
    goto z_bb_14;
    z_bb_20:
    if ((int)(si < worklist_len)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_59 = 1;
    zT_60 = si + zT_59;
    sj = zT_60;
    goto z_bb_24;
    z_bb_22:
    zT_75 = 0;
    zT_76 = (unsigned int)zT_75;
    sorted_count = zT_76;
    goto z_bb_30;
    z_bb_23:
    goto z_bb_20;
    z_bb_24:
    if ((int)(sj < worklist_len)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_62 = worklist_items[si];
    zT_63 = worklist_items[sj];
    if ((int)(zT_62 > zT_63)) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_71 = 1;
    zT_73 = si + (unsigned int)((unsigned int)zT_71);
    si = zT_73;
    goto z_bb_23;
    z_bb_27:
    goto z_bb_24;
    z_bb_28:
    zT_66 = worklist_items[si];
    tmp = zT_66;
    zT_67 = worklist_items[sj];
    worklist_items[si] = zT_67;
    worklist_items[sj] = tmp;
    goto z_bb_29;
    z_bb_29:
    zT_68 = 1;
    zT_70 = sj + (unsigned int)((unsigned int)zT_68);
    sj = zT_70;
    goto z_bb_27;
    z_bb_30:
    zT_77 = 0;
    if ((int)(worklist_len > (unsigned int)zT_77)) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_79 = 1;
    zT_81 = worklist_len - (unsigned int)((unsigned int)zT_79);
    worklist_len = zT_81;
    zT_83 = worklist_items[worklist_len];
    id = zT_83;
    zT_85 = (unsigned int)id;
    id_idx = zT_85;
    zT_86 = reg->modules;
    zT_87 = zT_86.items;
    zT_88 = zT_87[id_idx];
    zT_89 = zT_88.state;
    if ((int)(zT_89 == (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed))) goto z_bb_34; else goto z_bb_35;
    z_bb_32:
    if ((int)(sorted_count < (unsigned int)((unsigned int)mod_count))) goto z_bb_52; else goto z_bb_53;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    goto z_bb_33;
    z_bb_35:
    zT_93 = reg->modules;
    zT_94 = zT_93.items;
    zT_95 = zT_94[id_idx];
    entry = zT_95;
    entry.state = (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved);
    zT_97 = reg->modules;
    zT_98 = zT_97.items;
    zT_98[id_idx] = entry;
    zT_99 = 1;
    zT_101 = sorted_count + (unsigned int)((unsigned int)zT_99);
    sorted_count = zT_101;
    zT_103 = 0;
    zT_104 = (unsigned int)zT_103;
    ii = zT_104;
    goto z_bb_36;
    z_bb_36:
    if ((int)(ii < mod_count)) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_107 = reg->modules;
    zT_108 = zT_107.items;
    zT_109 = zT_108[ii];
    imp_entry = zT_109;
    zT_110 = imp_entry.state;
    if ((int)(zT_110 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed))) goto z_bb_40; else goto z_bb_41;
    z_bb_38:
    goto z_bb_33;
    z_bb_39:
    goto z_bb_36;
    z_bb_40:
    zT_114 = imp_entry.imports_start;
    zT_115 = (unsigned int)zT_114;
    start = zT_115;
    zT_117 = imp_entry.import_count;
    zT_119 = start + (unsigned int)((unsigned int)zT_117);
    end = zT_119;
    j = start;
    goto z_bb_42;
    z_bb_41:
    zT_142 = 1;
    zT_144 = ii + (unsigned int)((unsigned int)zT_142);
    ii = zT_144;
    goto z_bb_39;
    z_bb_42:
    if ((int)(j < end)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_122 = reg->import_edges_items;
    zT_123 = zT_122[j];
    if ((int)(zT_123 == id)) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    goto z_bb_41;
    z_bb_45:
    goto z_bb_42;
    z_bb_46:
    zT_125 = in_degree[ii];
    zT_126 = 0;
    if ((int)(zT_125 > (unsigned int)zT_126)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    zT_139 = 1;
    zT_141 = j + (unsigned int)((unsigned int)zT_139);
    j = zT_141;
    goto z_bb_45;
    z_bb_48:
    zT_128 = in_degree[ii];
    zT_129 = 1;
    zT_131 = zT_128 - (unsigned int)((unsigned int)zT_129);
    in_degree[ii] = zT_131;
    goto z_bb_49;
    z_bb_49:
    zT_132 = in_degree[ii];
    zT_133 = 0;
    if ((int)(zT_132 == (unsigned int)zT_133)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_135 = (unsigned int)ii;
    worklist_items[worklist_len] = zT_135;
    zT_136 = 1;
    zT_138 = worklist_len + (unsigned int)((unsigned int)zT_136);
    worklist_len = zT_138;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_47;
    z_bb_52:
    zT_148 = 0;
    zT_149 = (unsigned int)zT_148;
    ci = zT_149;
    goto z_bb_54;
    z_bb_53:
    zT_214 = reg;
    zF_F87B71D9_moduleRegistryVerif(zT_214);
    return;
    z_bb_54:
    if ((int)(ci < mod_count)) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_152 = reg->modules;
    zT_153 = zT_152.items;
    zT_154 = zT_153[ci];
    entry = zT_154;
    zT_155 = entry.state;
    if ((int)(zT_155 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    goto z_bb_54;
    z_bb_58:
    zT_159 = in_degree[ci];
    zT_160 = 0;
    zT_158 = zT_159 > (unsigned int)zT_160;
    goto z_bb_60;
    z_bb_59:
    zT_158 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_158) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_163 = reg->interner;
    zT_164 = entry.path_id;
    zT_167 = zF_9134020D_stringInternerGet(zT_163, zT_164);
    mn = zT_167;
    zT_169 = "circular import detected in module '";
    zT_171 = 36;
    zT_170.ptr = zT_169;
    zT_170.len = zT_171;
    cp1 = zT_170;
    zT_173 = "'";
    zT_175 = 1;
    zT_174.ptr = zT_173;
    zT_174.len = zT_175;
    cp2 = zT_174;
    zT_178 = 0;
    zT_177[zT_178] = cp1;
    zT_179 = 1;
    zT_177[zT_179] = mn;
    zT_180 = 2;
    zT_177[zT_180] = cp2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        cparts[_i] = zT_177[_i];
        _i++;
    }
}
    zT_185 = reg->diag;
    zT_182 = zT_185->interner;
    zT_187 = 0;
    zT_188 = cparts + zT_187;
    zT_183 = zT_188;
    zT_190 = zF_8C4BFF7C_diagnosticBuilderMa(zT_182, zT_183, (unsigned int)(3));
    msg = zT_190;
    zT_191 = reg->diag;
    zT_197 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_191, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_197);
    entry.state = (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed);
    zT_209 = reg->modules;
    zT_210 = zT_209.items;
    zT_210[ci] = entry;
    goto z_bb_62;
    z_bb_62:
    zT_211 = 1;
    zT_213 = ci + (unsigned int)((unsigned int)zT_211);
    ci = zT_213;
    goto z_bb_57;
}

/* moduleRegistryVerifyOrder */
void zF_F87B71D9_moduleRegistryVerif(zT_072B53A6_ModuleRegistry* reg) {
    zT_E41AEC18_ModuleEntryArrayLis zT_2;
    unsigned int zT_3;
    int zT_5;
    unsigned int zT_6;
    zT_E41AEC18_ModuleEntryArrayLis zT_9;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    zT_9FE1BFFE_ModuleState zT_12;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int* zT_25;
    unsigned int zT_26;
    zT_E41AEC18_ModuleEntryArrayLis zT_28;
    zT_6E8D187B_ModuleEntry* zT_29;
    unsigned int zT_30;
    zT_6E8D187B_ModuleEntry zT_31;
    zT_9FE1BFFE_ModuleState zT_32;
    int zT_35;
    zT_9FE1BFFE_ModuleState zT_36;
    unsigned char* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_41;
    unsigned int zT_42;
    zT_F85C5DED_DiagnosticCollector* zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    int zT_60;
    unsigned int zT_62;
    int zT_63;
    unsigned int zT_65;
    unsigned int mod_count;
    unsigned int vi;
    zT_6E8D187B_ModuleEntry entry;
    unsigned int start;
    unsigned int end;
    unsigned int vj;
    unsigned int imp_id;
    zT_6E8D187B_ModuleEntry imp;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = reg->modules;
    zT_3 = zT_2.len;
    mod_count = zT_3;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    vi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((int)(vi < mod_count)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = reg->modules;
    zT_10 = zT_9.items;
    zT_11 = zT_10[vi];
    entry = zT_11;
    zT_12 = entry.state;
    if ((int)(zT_12 == (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_16 = entry.imports_start;
    zT_17 = (unsigned int)zT_16;
    start = zT_17;
    zT_19 = entry.import_count;
    zT_21 = start + (unsigned int)((unsigned int)zT_19);
    end = zT_21;
    vj = start;
    goto z_bb_7;
    z_bb_6:
    zT_63 = 1;
    zT_65 = vi + (unsigned int)((unsigned int)zT_63);
    vi = zT_65;
    goto z_bb_4;
    z_bb_7:
    if ((int)(vj < end)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_25 = reg->import_edges_items;
    zT_26 = zT_25[vj];
    imp_id = zT_26;
    zT_28 = reg->modules;
    zT_29 = zT_28.items;
    zT_30 = (unsigned int)imp_id;
    zT_31 = zT_29[zT_30];
    imp = zT_31;
    zT_32 = imp.state;
    if ((int)(zT_32 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_resolved))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    goto z_bb_7;
    z_bb_11:
    zT_36 = imp.state;
    zT_35 = zT_36 != (zT_9FE1BFFE_ModuleState)(zT_9FE1BFFE_ModuleState_failed);
    goto z_bb_13;
    z_bb_12:
    zT_35 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_35) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_40 = "topological sort violation: import not resolved";
    zT_42 = 47;
    zT_41.ptr = zT_40;
    zT_41.len = zT_42;
    msg = zT_41;
    zT_43 = reg->diag;
    zT_49 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_43, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_4000_INVALID_CONTROL_FLOW)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_49);
    goto z_bb_15;
    z_bb_15:
    zT_60 = 1;
    zT_62 = vj + (unsigned int)((unsigned int)zT_60);
    vj = zT_62;
    goto z_bb_10;
}

/* moduleRegistryCollectIncludes */
void zF_7D71E4ED_moduleRegistryColle(zT_6B0A7D14_AstStore* store, unsigned int root_idx, zT_B687BB96_U32ArrayList* c_includes) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    unsigned int zT_6 = 0;
    unsigned int zT_8;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_16 = 0;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_22A7C88B_AstNode zT_20 = {0};
    zT_8143F551_AstKind zT_21;
    zT_B687BB96_U32ArrayList* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_28;
    unsigned int zT_29;
    unsigned int zT_30 = 0;
    zT_8143F551_AstKind zT_31;
    int zT_36;
    unsigned int zT_37;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    zT_22A7C88B_AstNode zT_44 = {0};
    zT_8143F551_AstKind zT_45;
    zT_B687BB96_U32ArrayList* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_52;
    unsigned int zT_53;
    unsigned int zT_55 = 0;
    unsigned int zT_57;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_4 = store;
    zT_5 = root_idx;
    zT_6 = zF_152E19CB_astStoreNodeExtraCh(zT_4, zT_5);
    decls_n = zT_6;
    zT_8 = 0;
    di = zT_8;
    goto z_bb_1;
    z_bb_1:
    if ((int)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_12 = store;
    zT_13 = root_idx;
    zT_16 = zF_B10B1BC1_astStoreNodeExtraCh(zT_12, zT_13, (unsigned int)((unsigned int)di));
    decl_idx = zT_16;
    zT_18 = store;
    zT_19 = decl_idx;
    zT_20 = zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    decl = zT_20;
    zT_21 = decl.kind;
    if ((int)(zT_21 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    return;
    z_bb_4:
    zT_57 = di + (unsigned int)(1);
    di = zT_57;
    goto z_bb_1;
    z_bb_5:
    zT_26 = c_includes;
    zT_28 = store;
    zT_29 = decl_idx;
    zT_30 = zF_8BA26B9E_astStoreNodePayload(zT_28, zT_29);
    zT_27 = zT_30;
    zF_62F717A2_u32ArrayListAppend(zT_26, zT_27);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = decl.kind;
    if ((int)(zT_31 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = decl.child_1;
    zT_36 = zT_37 != (unsigned int)(0);
    goto z_bb_10;
    z_bb_9:
    zT_36 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_36) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_41 = store;
    zT_42 = decl.child_1;
    zT_44 = zF_FCDD1D35_astStoreNodeAt(zT_41, zT_42);
    init = zT_44;
    zT_45 = init.kind;
    if ((int)(zT_45 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_c_include))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_6;
    z_bb_13:
    zT_50 = c_includes;
    zT_52 = store;
    zT_53 = decl.child_1;
    zT_55 = zF_8BA26B9E_astStoreNodePayload(zT_52, zT_53);
    zT_51 = zT_55;
    zF_62F717A2_u32ArrayListAppend(zT_50, zT_51);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
}

/* __module_init */
void zF_780653D2___module_init_9(void) {
    zT_B687BB96_U32ArrayList zT_0 = {0};
    int zT_1;
    unsigned char* zT_3;
    unsigned char* zT_4;
    zG_B687BB96_U32ArrayList = zT_0;
    zT_1 = 0;
    zG_E8C23D2C_source_man_stub = (unsigned char)((unsigned char)zT_1);
    zT_3 = "rb";
    zG_1DDFFDDD_HASH_SPILL_READ_MOD = zT_3;
    zT_4 = "wb";
    zG_034DEF1E_HASH_SPILL_WRITE_MO = zT_4;
    zG_0BC1A97F_HASH_SPILL_MAX_MAP_ = (unsigned int)(4000000);
    return;
}

/* EOF */
