#include "coercion_F654E5FA.h"
zT_66E7D2EF_CoercionTable zG_66E7D2EF_CoercionTable;
zT_0FB7FB13_CoercionKind zG_0FB7FB13_CoercionKind;
/* coercionTableEnsureCapacity */
void zF_E837F929_coercionTableEnsure(zT_66E7D2EF_CoercionTable* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    zT_9CDC9863_CoercionEntry* zT_26;
    unsigned int zT_28;
    zT_6B32A9CF_Opt_239 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_019EE88E_EU_932 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    zT_9CDC9863_CoercionEntry* zT_49;
    zT_9CDC9863_CoercionEntry* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_9CDC9863_CoercionEntry* zT_53;
    unsigned int zT_54;
    zT_5B0DCA45_Slice_zT_9CDC9863_C zT_55;
    zT_9CDC9863_CoercionEntry* zT_56;
    unsigned int zT_57;
    unsigned int zT_62;
    unsigned int nc;
    zT_6B32A9CF_Opt_239 grown;
    unsigned char* raw;
    zT_9CDC9863_CoercionEntry* new_items;
    zT_9CDC9863_CoercionEntry item;
    unsigned int i;
    zT_2 = self->entries_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->entries_cap;
    zT_6 = 2;
    if ((unsigned char)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->entries_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->entries_cap;
    zT_17 = 0;
    if ((unsigned char)(zT_16 > (unsigned int)zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = self->entries_alloc;
    zT_26 = self->entries_items;
    zT_28 = self->entries_cap;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), (unsigned int)(zT_28 * (unsigned int)(12)), (unsigned int)(nc * (unsigned int)(12)), (unsigned int)(4));
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_37 = self->entries_alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(12) * nc), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->entries_cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_46 = zT_44.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    zT_49 = (zT_9CDC9863_CoercionEntry*)raw;
    new_items = zT_49;
    zT_50 = self->entries_items;
    zT_51 = self->entries_len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((unsigned char)(i < zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    goto z_bb_17;
    z_bb_16:
    self->entries_items = new_items;
    self->entries_cap = nc;
    return;
    z_bb_17:
    zT_62 = i + (unsigned int)(1);
    i = zT_62;
    goto z_bb_14;
}

/* coercionTableInit */
zT_66E7D2EF_CoercionTable zF_26B6D809_coercionTableInit(zT_3E40CD83_Sand* alloc) {
    zT_66E7D2EF_CoercionTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_21D3708C_U32ToU32Map zT_6 = {0};
    zT_2 = 0;
    zT_1.entries_items = (zT_9CDC9863_CoercionEntry*)zT_2;
    zT_3 = 0;
    zT_1.entries_len = zT_3;
    zT_4 = 0;
    zT_1.entries_cap = zT_4;
    zT_1.entries_alloc = alloc;
    zT_5 = alloc;
    zT_6 = zF_58BDA2DE_u32ToU32MapInit(zT_5);
    zT_1.index = zT_6;
    return zT_1;
}

/* coercionTableAdd */
void zF_D21AE60A_coercionTableAdd(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx, zT_0FB7FB13_CoercionKind kind, unsigned int target_type) {
    zT_9CDC9863_CoercionEntry zT_5;
    zT_21D3708C_U32ToU32Map* zT_7;
    unsigned int zT_8;
    zT_BAEE192E_Opt_10 zT_10 = {0};
    unsigned char zT_11;
    zT_9CDC9863_CoercionEntry* zT_13;
    unsigned int zT_14;
    zT_66E7D2EF_CoercionTable* zT_15;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_9CDC9863_CoercionEntry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    zT_21D3708C_U32ToU32Map* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_9CDC9863_CoercionEntry entry;
    zT_BAEE192E_Opt_10 existing;
    unsigned int idx;
    zT_5.node_idx = node_idx;
    zT_5.kind = kind;
    zT_5.target_type = target_type;
    entry = zT_5;
    zT_7 = &self->index;
    zT_8 = node_idx;
    zT_10 = zF_F3EE5998_u32ToU32MapGet(zT_7, zT_8);
    existing = zT_10;
    zT_11 = existing.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = existing.value;
    zT_13 = self->entries_items;
    zT_14 = (unsigned int)idx;
    zT_13[zT_14] = entry;
    return;
    z_bb_2:
    zT_15 = self;
    zT_17 = self->entries_len;
    zT_18 = 1;
    zF_E837F929_coercionTableEnsure(zT_15, (unsigned int)(zT_17 + zT_18));
    zT_21 = self->entries_len;
    zT_22 = (unsigned int)zT_21;
    idx = zT_22;
    zT_23 = self->entries_items;
    zT_24 = (unsigned int)idx;
    zT_23[zT_24] = entry;
    zT_25 = self->entries_len;
    zT_26 = 1;
    self->entries_len = (unsigned int)(zT_25 + (unsigned int)((unsigned int)zT_26));
    zT_29 = &self->index;
    zT_30 = node_idx;
    zT_31 = idx;
    zF_26476265_u32ToU32MapPut(zT_29, zT_30, zT_31);
    return;
}

/* coercionTableGet */
zT_5CC037A7_Opt_194 zF_46B66789_coercionTableGet(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    zT_9CDC9863_CoercionEntry* zT_9;
    unsigned int zT_10;
    zT_9CDC9863_CoercionEntry zT_11;
    zT_5CC037A7_Opt_194 zT_12;
    zT_5CC037A7_Opt_194 zT_13 = {0};
    zT_BAEE192E_Opt_10 entry_idx;
    unsigned int idx;
    zT_3 = &self->index;
    zT_4 = node_idx;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    entry_idx = zT_6;
    zT_7 = entry_idx.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = entry_idx.value;
    zT_9 = self->entries_items;
    zT_10 = (unsigned int)idx;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
    z_bb_2:
    zT_13.has_value = 0;
    return zT_13;
}

/* classifyCoercion */
zT_0FB7FB13_CoercionKind zF_713658BF_classifyCoercion(zT_338B7C76_TypeRegistry* reg, unsigned int source, unsigned int target) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_18;
    zT_33EF6BFB_TypeKind zT_23;
    unsigned char zT_27;
    zT_338B7C76_TypeRegistry* zT_28;
    unsigned int zT_29;
    unsigned char zT_30 = 0;
    zT_338B7C76_TypeRegistry* zT_32;
    unsigned int zT_33;
    unsigned char zT_34 = 0;
    unsigned char zT_35;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    unsigned char zT_38 = 0;
    unsigned char zT_39;
    zT_338B7C76_TypeRegistry* zT_42;
    unsigned int zT_43;
    unsigned char zT_44 = 0;
    zT_338B7C76_TypeRegistry* zT_45;
    unsigned int zT_46;
    unsigned char zT_47 = 0;
    unsigned char zT_49;
    zT_338B7C76_TypeRegistry* zT_50;
    unsigned int zT_51;
    unsigned char zT_52 = 0;
    zT_338B7C76_TypeRegistry* zT_53;
    unsigned int zT_54;
    unsigned char zT_55 = 0;
    unsigned char zT_60;
    zT_33EF6BFB_TypeKind zT_64;
    unsigned char* zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_338B7C76_TypeRegistry* zT_74;
    unsigned int zT_75;
    unsigned char zT_76 = 0;
    zT_33EF6BFB_TypeKind zT_78;
    zT_33EF6BFB_TypeKind zT_83;
    zT_33EF6BFB_TypeKind zT_88;
    zT_0B10E8E9_OptionalPayload* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    zT_0B10E8E9_OptionalPayload zT_96;
    zT_338B7C76_TypeRegistry* zT_97;
    unsigned int zT_98;
    unsigned int zT_99;
    unsigned char zT_101 = 0;
    zT_33EF6BFB_TypeKind zT_103;
    zT_33EF6BFB_TypeKind zT_108;
    zT_42C2D6BF_EUPayload* zT_113;
    unsigned int zT_114;
    unsigned int zT_115;
    zT_42C2D6BF_EUPayload zT_116;
    zT_338B7C76_TypeRegistry* zT_117;
    unsigned int zT_118;
    unsigned int zT_119;
    unsigned char zT_121 = 0;
    zT_33EF6BFB_TypeKind zT_123;
    unsigned char zT_127;
    zT_33EF6BFB_TypeKind zT_128;
    zT_33EF6BFB_TypeKind zT_133;
    unsigned char zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_112BF819_PtrPayload* zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    zT_112BF819_PtrPayload zT_146;
    zT_112BF819_PtrPayload* zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    zT_112BF819_PtrPayload zT_151;
    unsigned char zT_153;
    unsigned char zT_154;
    unsigned char zT_159 = 0;
    unsigned int zT_160;
    unsigned char zT_163;
    unsigned int zT_165;
    unsigned char zT_168;
    unsigned char zT_170;
    unsigned char zT_175;
    unsigned char zT_176;
    unsigned int zT_181;
    unsigned int zT_182;
    unsigned char zT_184;
    zT_33EF6BFB_TypeKind zT_186;
    unsigned char zT_190;
    zT_33EF6BFB_TypeKind zT_191;
    unsigned char zT_196;
    unsigned char zT_197;
    unsigned char zT_202 = 0;
    unsigned char zT_203;
    unsigned char zT_208;
    unsigned char zT_209;
    zT_0BB2A741_SlicePayload* zT_215;
    unsigned int zT_216;
    unsigned int zT_217;
    zT_0BB2A741_SlicePayload zT_218;
    zT_0BB2A741_SlicePayload* zT_220;
    unsigned int zT_221;
    unsigned int zT_222;
    zT_0BB2A741_SlicePayload zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    unsigned char zT_227;
    zT_33EF6BFB_TypeKind zT_229;
    unsigned char zT_233;
    zT_33EF6BFB_TypeKind zT_234;
    unsigned char zT_239;
    unsigned char zT_240;
    unsigned char zT_245 = 0;
    unsigned char zT_246;
    unsigned char zT_251;
    unsigned char zT_252;
    zT_112BF819_PtrPayload* zT_258;
    unsigned int zT_259;
    unsigned int zT_260;
    zT_112BF819_PtrPayload zT_261;
    zT_112BF819_PtrPayload* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    zT_112BF819_PtrPayload zT_266;
    unsigned int zT_267;
    unsigned int zT_268;
    unsigned char zT_270;
    zT_33EF6BFB_TypeKind zT_272;
    unsigned char zT_276;
    zT_33EF6BFB_TypeKind zT_277;
    unsigned char zT_282;
    unsigned char zT_283;
    unsigned char zT_288 = 0;
    zT_E834303C_ArrayPayload* zT_290;
    unsigned int zT_291;
    unsigned int zT_292;
    zT_E834303C_ArrayPayload zT_293;
    zT_0BB2A741_SlicePayload* zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    zT_0BB2A741_SlicePayload zT_298;
    unsigned int zT_299;
    unsigned int zT_300;
    unsigned char zT_302;
    unsigned char zT_304;
    unsigned char zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    unsigned char zT_313;
    zT_33EF6BFB_TypeKind zT_315;
    unsigned char zT_319;
    zT_33EF6BFB_TypeKind zT_320;
    unsigned char zT_325;
    unsigned char zT_326;
    unsigned char zT_331 = 0;
    zT_E834303C_ArrayPayload* zT_333;
    unsigned int zT_334;
    unsigned int zT_335;
    zT_E834303C_ArrayPayload zT_336;
    zT_112BF819_PtrPayload* zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    zT_112BF819_PtrPayload zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    unsigned char zT_345;
    zT_33EF6BFB_TypeKind zT_347;
    unsigned char zT_351;
    zT_33EF6BFB_TypeKind zT_352;
    zT_E834303C_ArrayPayload* zT_357;
    unsigned int zT_358;
    unsigned int zT_359;
    zT_E834303C_ArrayPayload zT_360;
    zT_E834303C_ArrayPayload* zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    zT_E834303C_ArrayPayload zT_365;
    unsigned int zT_366;
    unsigned int zT_367;
    unsigned char zT_369;
    unsigned int zT_370;
    unsigned int zT_371;
    zT_33EF6BFB_TypeKind zT_374;
    unsigned char zT_378;
    zT_33EF6BFB_TypeKind zT_379;
    unsigned char zT_384;
    unsigned char zT_385;
    unsigned char zT_390 = 0;
    zT_112BF819_PtrPayload* zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    zT_112BF819_PtrPayload zT_395;
    zT_112BF819_PtrPayload* zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    zT_112BF819_PtrPayload zT_400;
    zT_D155D06D_Type* zT_402;
    unsigned int zT_403;
    unsigned int zT_404;
    zT_D155D06D_Type zT_405;
    zT_33EF6BFB_TypeKind zT_406;
    zT_E834303C_ArrayPayload* zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    zT_E834303C_ArrayPayload zT_414;
    unsigned int zT_415;
    unsigned int zT_416;
    unsigned char zT_418;
    zT_33EF6BFB_TypeKind zT_420;
    unsigned char zT_424;
    zT_33EF6BFB_TypeKind zT_425;
    unsigned char zT_430;
    unsigned char zT_431;
    unsigned char zT_436 = 0;
    zT_0BB2A741_SlicePayload* zT_438;
    unsigned int zT_439;
    unsigned int zT_440;
    zT_0BB2A741_SlicePayload zT_441;
    zT_112BF819_PtrPayload* zT_443;
    unsigned int zT_444;
    unsigned int zT_445;
    zT_112BF819_PtrPayload zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    unsigned char zT_450;
    zT_33EF6BFB_TypeKind zT_452;
    unsigned char zT_456;
    zT_33EF6BFB_TypeKind zT_457;
    zT_0B10E8E9_OptionalPayload* zT_462;
    unsigned int zT_463;
    unsigned int zT_464;
    zT_0B10E8E9_OptionalPayload zT_465;
    zT_D155D06D_Type* zT_467;
    unsigned int zT_468;
    unsigned int zT_469;
    zT_D155D06D_Type zT_470;
    zT_33EF6BFB_TypeKind zT_471;
    zT_338B7C76_TypeRegistry* zT_475;
    unsigned int zT_476;
    unsigned int zT_477;
    unsigned char zT_479 = 0;
    unsigned char zT_483;
    unsigned char zT_486;
    unsigned char zT_489;
    zT_33EF6BFB_TypeKind zT_493;
    unsigned char zT_497;
    zT_33EF6BFB_TypeKind zT_498;
    unsigned char zT_503;
    unsigned char zT_504;
    unsigned char zT_509 = 0;
    zT_112BF819_PtrPayload* zT_511;
    unsigned int zT_512;
    unsigned int zT_513;
    zT_112BF819_PtrPayload zT_514;
    zT_0BB2A741_SlicePayload* zT_516;
    unsigned int zT_517;
    unsigned int zT_518;
    zT_0BB2A741_SlicePayload zT_519;
    unsigned char* zT_521;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_522;
    unsigned int zT_523;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_524;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_526;
    unsigned int zT_528;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_529;
    int zT_533;
    unsigned char* zT_534;
    unsigned int zT_535;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_536;
    unsigned int zT_537 = 0;
    unsigned int zT_541;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_542;
    unsigned char* zT_546;
    unsigned int zT_547;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_548;
    unsigned char* zT_550;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_551;
    unsigned int zT_552;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_553;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_555;
    unsigned int zT_557;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_558;
    int zT_562;
    unsigned char* zT_563;
    unsigned int zT_564;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_565;
    unsigned int zT_566 = 0;
    unsigned int zT_570;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_571;
    unsigned char* zT_575;
    unsigned int zT_576;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_577;
    unsigned char* zT_579;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_580;
    unsigned int zT_581;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_582;
    zT_D155D06D_Type* zT_584;
    unsigned int zT_585;
    unsigned int zT_586;
    zT_D155D06D_Type zT_587;
    zT_33EF6BFB_TypeKind zT_588;
    zT_E834303C_ArrayPayload* zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    zT_E834303C_ArrayPayload zT_596;
    unsigned int zT_597;
    unsigned int zT_598;
    unsigned char zT_600;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_8F083A69_Slice_zT_0B42B2F8_u ccn_m;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    unsigned char qok;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_E834303C_ArrayPayload arr;
    zT_0BB2A741_SlicePayload sl;
    zT_112BF819_PtrPayload pp;
    zT_E834303C_ArrayPayload s_arr;
    zT_E834303C_ArrayPayload t_arr;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload tp;
    zT_D155D06D_Type spo;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_D155D06D_Type opt_ty;
    zT_112BF819_PtrPayload sp2;
    zT_0BB2A741_SlicePayload ts2;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsb;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb2;
    unsigned int clsb2l;
    unsigned int clsb2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clse;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb3;
    unsigned int clsb3l;
    unsigned int clsb3s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsnl;
    zT_D155D06D_Type src_pointee;
    if ((unsigned char)(source == target)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_2:
    zT_6 = reg->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    zT_10 = reg->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    zT_13 = src.kind;
    if ((unsigned char)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_4:
    zT_18 = src.kind;
    if ((unsigned char)(zT_18 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_6:
    zT_23 = src.kind;
    if ((unsigned char)(zT_23 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_28 = reg;
    zT_29 = target;
    zT_30 = zF_3087E0A5_typeRegistryIsNumer(zT_28, zT_29);
    zT_27 = zT_30;
    goto z_bb_9;
    z_bb_8:
    zT_27 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_27) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce);
    z_bb_11:
    zT_32 = reg;
    zT_33 = source;
    zT_34 = zF_3290E9C4_typeRegistryIsInteg(zT_32, zT_33);
    if (zT_34) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_36 = reg;
    zT_37 = target;
    zT_38 = zF_3290E9C4_typeRegistryIsInteg(zT_36, zT_37);
    zT_35 = zT_38;
    goto z_bb_14;
    z_bb_13:
    zT_35 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_35) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_39 = source != (unsigned int)(19);
    goto z_bb_17;
    z_bb_16:
    zT_39 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_39) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_42 = reg;
    zT_43 = source;
    zT_44 = zF_B664AC19_typeRegistryIsUnsig(zT_42, zT_43);
    zT_45 = reg;
    zT_46 = target;
    zT_47 = zF_B664AC19_typeRegistryIsUnsig(zT_45, zT_46);
    if ((unsigned char)(zT_44 == zT_47)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    if ((unsigned char)(source == (unsigned int)(15))) goto z_bb_25; else goto z_bb_26;
    z_bb_20:
    zT_50 = reg;
    zT_51 = source;
    zT_52 = zF_655972D5_typeRegistryIntWidt(zT_50, zT_51);
    zT_53 = reg;
    zT_54 = target;
    zT_55 = zF_655972D5_typeRegistryIntWidt(zT_53, zT_54);
    zT_49 = zT_52 < zT_55;
    goto z_bb_22;
    z_bb_21:
    zT_49 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_49) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_widen);
    z_bb_24:
    goto z_bb_19;
    z_bb_25:
    zT_60 = target == (unsigned int)(16);
    goto z_bb_27;
    z_bb_26:
    zT_60 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_60) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_float_widen);
    z_bb_29:
    zT_64 = src.kind;
    if ((unsigned char)(zT_64 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_69 = "CC:nul";
    zT_71 = 6;
    zT_70.ptr = zT_69;
    zT_70.len = zT_71;
    ccn_m = zT_70;
    zT_72 = ccn_m;
    zT_73 = target;
    zF_C914CB83_markerWriteInt(zT_72, zT_73);
    zT_74 = reg;
    zT_75 = target;
    zT_76 = zF_AD61DB1B_typeRegistryIsPoint(zT_74, zT_75);
    if (zT_76) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_88 = tgt.kind;
    if ((unsigned char)(zT_88 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_38; else goto z_bb_39;
    z_bb_32:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_33:
    zT_78 = tgt.kind;
    if ((unsigned char)(zT_78 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional_null);
    z_bb_35:
    zT_83 = tgt.kind;
    if ((unsigned char)(zT_83 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_37:
    goto z_bb_31;
    z_bb_38:
    zT_93 = reg->opt_items;
    zT_94 = tgt.payload_idx;
    zT_95 = (unsigned int)zT_94;
    zT_96 = zT_93[zT_95];
    opt = zT_96;
    zT_97 = reg;
    zT_98 = source;
    zT_99 = opt.payload;
    zT_101 = zF_683AEB7F_typeRegistryIsAssig(zT_97, zT_98, zT_99);
    if (zT_101) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    zT_108 = tgt.kind;
    if ((unsigned char)(zT_108 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_44; else goto z_bb_45;
    z_bb_40:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional);
    z_bb_41:
    zT_103 = src.kind;
    if ((unsigned char)(zT_103 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_43:
    goto z_bb_39;
    z_bb_44:
    zT_113 = reg->eu_items;
    zT_114 = tgt.payload_idx;
    zT_115 = (unsigned int)zT_114;
    zT_116 = zT_113[zT_115];
    eu = zT_116;
    zT_117 = reg;
    zT_118 = source;
    zT_119 = eu.payload;
    zT_121 = zF_683AEB7F_typeRegistryIsAssig(zT_117, zT_118, zT_119);
    if (zT_121) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    zT_123 = src.kind;
    if ((unsigned char)(zT_123 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_error_success);
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_128 = tgt.kind;
    zT_127 = zT_128 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_50;
    z_bb_49:
    zT_127 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_127) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_error_err);
    z_bb_52:
    zT_133 = src.kind;
    if ((unsigned char)(zT_133 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_138 = tgt.kind;
    zT_137 = zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_55;
    z_bb_54:
    zT_137 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_137) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_143 = reg->ptr_items;
    zT_144 = tgt.payload_idx;
    zT_145 = (unsigned int)zT_144;
    zT_146 = zT_143[zT_145];
    tgt_pp = zT_146;
    zT_148 = reg->ptr_items;
    zT_149 = src.payload_idx;
    zT_150 = (unsigned int)zT_149;
    zT_151 = zT_148[zT_150];
    src_pp = zT_151;
    zT_153 = src.flags;
    zT_154 = tgt.flags;
    zT_159 = zF_08C13644_pointerQualifiersMo(zT_153, zT_154, (unsigned char)(2));
    qok = zT_159;
    zT_160 = tgt_pp.base;
    if ((unsigned char)(zT_160 == (unsigned int)(1))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    zT_186 = tgt.kind;
    if ((unsigned char)(zT_186 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_58:
    zT_163 = qok;
    goto z_bb_60;
    z_bb_59:
    zT_163 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_163) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_62:
    zT_165 = src_pp.base;
    if ((unsigned char)(zT_165 == (unsigned int)(1))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_168 = qok;
    goto z_bb_65;
    z_bb_64:
    zT_168 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_168) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_67:
    zT_170 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_170 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_176 = src.flags;
    zT_175 = (unsigned char)(zT_176 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_70;
    z_bb_69:
    zT_175 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_175) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_181 = src_pp.base;
    zT_182 = tgt_pp.base;
    if ((unsigned char)(zT_181 == zT_182)) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    goto z_bb_57;
    z_bb_73:
    zT_184 = qok;
    goto z_bb_75;
    z_bb_74:
    zT_184 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_184) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_77:
    goto z_bb_72;
    z_bb_78:
    zT_191 = src.kind;
    zT_190 = zT_191 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_80;
    z_bb_79:
    zT_190 = 0;
    goto z_bb_80;
    z_bb_80:
    if (zT_190) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_196 = src.flags;
    zT_197 = tgt.flags;
    zT_202 = zF_08C13644_pointerQualifiersMo(zT_196, zT_197, (unsigned char)(2));
    qok = zT_202;
    zT_203 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_203 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_83; else goto z_bb_84;
    z_bb_82:
    zT_229 = tgt.kind;
    if ((unsigned char)(zT_229 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_93; else goto z_bb_94;
    z_bb_83:
    zT_209 = src.flags;
    zT_208 = (unsigned char)(zT_209 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_85;
    z_bb_84:
    zT_208 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_208) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_215 = reg->slice_items;
    zT_216 = src.payload_idx;
    zT_217 = (unsigned int)zT_216;
    zT_218 = zT_215[zT_217];
    s_sl = zT_218;
    zT_220 = reg->slice_items;
    zT_221 = tgt.payload_idx;
    zT_222 = (unsigned int)zT_221;
    zT_223 = zT_220[zT_222];
    t_sl = zT_223;
    zT_224 = s_sl.elem;
    zT_225 = t_sl.elem;
    if ((unsigned char)(zT_224 == zT_225)) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    goto z_bb_82;
    z_bb_88:
    zT_227 = qok;
    goto z_bb_90;
    z_bb_89:
    zT_227 = 0;
    goto z_bb_90;
    z_bb_90:
    if (zT_227) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_92:
    goto z_bb_87;
    z_bb_93:
    zT_234 = src.kind;
    zT_233 = zT_234 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_95;
    z_bb_94:
    zT_233 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_233) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_239 = src.flags;
    zT_240 = tgt.flags;
    zT_245 = zF_08C13644_pointerQualifiersMo(zT_239, zT_240, (unsigned char)(2));
    qok = zT_245;
    zT_246 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_246 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_98; else goto z_bb_99;
    z_bb_97:
    zT_272 = src.kind;
    if ((unsigned char)(zT_272 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_108; else goto z_bb_109;
    z_bb_98:
    zT_252 = src.flags;
    zT_251 = (unsigned char)(zT_252 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_100;
    z_bb_99:
    zT_251 = 0;
    goto z_bb_100;
    z_bb_100:
    if (zT_251) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_258 = reg->ptr_items;
    zT_259 = src.payload_idx;
    zT_260 = (unsigned int)zT_259;
    zT_261 = zT_258[zT_260];
    s_pp = zT_261;
    zT_263 = reg->ptr_items;
    zT_264 = tgt.payload_idx;
    zT_265 = (unsigned int)zT_264;
    zT_266 = zT_263[zT_265];
    t_pp = zT_266;
    zT_267 = s_pp.base;
    zT_268 = t_pp.base;
    if ((unsigned char)(zT_267 == zT_268)) goto z_bb_103; else goto z_bb_104;
    z_bb_102:
    goto z_bb_97;
    z_bb_103:
    zT_270 = qok;
    goto z_bb_105;
    z_bb_104:
    zT_270 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_270) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_107:
    goto z_bb_102;
    z_bb_108:
    zT_277 = tgt.kind;
    zT_276 = zT_277 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_110;
    z_bb_109:
    zT_276 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_276) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_282 = src.flags;
    zT_283 = tgt.flags;
    zT_288 = zF_08C13644_pointerQualifiersMo(zT_282, zT_283, (unsigned char)(2));
    qok = zT_288;
    zT_290 = reg->array_items;
    zT_291 = src.payload_idx;
    zT_292 = (unsigned int)zT_291;
    zT_293 = zT_290[zT_292];
    arr = zT_293;
    zT_295 = reg->slice_items;
    zT_296 = tgt.payload_idx;
    zT_297 = (unsigned int)zT_296;
    zT_298 = zT_295[zT_297];
    sl = zT_298;
    zT_299 = arr.elem;
    zT_300 = sl.elem;
    if ((unsigned char)(zT_299 == zT_300)) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    zT_315 = src.kind;
    if ((unsigned char)(zT_315 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_113:
    zT_302 = qok;
    goto z_bb_115;
    z_bb_114:
    zT_302 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_302) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_117:
    zT_304 = tgt.flags;
    if ((unsigned char)((unsigned char)(zT_304 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_310 = arr.elem;
    zT_311 = sl.elem;
    zT_309 = zT_310 == zT_311;
    goto z_bb_120;
    z_bb_119:
    zT_309 = 0;
    goto z_bb_120;
    z_bb_120:
    if (zT_309) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_313 = qok;
    goto z_bb_123;
    z_bb_122:
    zT_313 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_313) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_125:
    goto z_bb_112;
    z_bb_126:
    zT_320 = tgt.kind;
    zT_319 = zT_320 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_128;
    z_bb_127:
    zT_319 = 0;
    goto z_bb_128;
    z_bb_128:
    if (zT_319) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    zT_325 = src.flags;
    zT_326 = tgt.flags;
    zT_331 = zF_08C13644_pointerQualifiersMo(zT_325, zT_326, (unsigned char)(2));
    qok = zT_331;
    zT_333 = reg->array_items;
    zT_334 = src.payload_idx;
    zT_335 = (unsigned int)zT_334;
    zT_336 = zT_333[zT_335];
    arr = zT_336;
    zT_338 = reg->ptr_items;
    zT_339 = tgt.payload_idx;
    zT_340 = (unsigned int)zT_339;
    zT_341 = zT_338[zT_340];
    pp = zT_341;
    zT_342 = arr.elem;
    zT_343 = pp.base;
    if ((unsigned char)(zT_342 == zT_343)) goto z_bb_131; else goto z_bb_132;
    z_bb_130:
    zT_347 = src.kind;
    if ((unsigned char)(zT_347 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_136; else goto z_bb_137;
    z_bb_131:
    zT_345 = qok;
    goto z_bb_133;
    z_bb_132:
    zT_345 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_345) goto z_bb_134; else goto z_bb_135;
    z_bb_134:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_many_ptr);
    z_bb_135:
    goto z_bb_130;
    z_bb_136:
    zT_352 = tgt.kind;
    zT_351 = zT_352 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_138;
    z_bb_137:
    zT_351 = 0;
    goto z_bb_138;
    z_bb_138:
    if (zT_351) goto z_bb_139; else goto z_bb_140;
    z_bb_139:
    zT_357 = reg->array_items;
    zT_358 = src.payload_idx;
    zT_359 = (unsigned int)zT_358;
    zT_360 = zT_357[zT_359];
    s_arr = zT_360;
    zT_362 = reg->array_items;
    zT_363 = tgt.payload_idx;
    zT_364 = (unsigned int)zT_363;
    zT_365 = zT_362[zT_364];
    t_arr = zT_365;
    zT_366 = s_arr.elem;
    zT_367 = t_arr.elem;
    if ((unsigned char)(zT_366 == zT_367)) goto z_bb_141; else goto z_bb_142;
    z_bb_140:
    zT_374 = src.kind;
    if ((unsigned char)(zT_374 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_146; else goto z_bb_147;
    z_bb_141:
    zT_370 = s_arr.length;
    zT_371 = t_arr.length;
    zT_369 = zT_370 == zT_371;
    goto z_bb_143;
    z_bb_142:
    zT_369 = 0;
    goto z_bb_143;
    z_bb_143:
    if (zT_369) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_145:
    goto z_bb_140;
    z_bb_146:
    zT_379 = tgt.kind;
    zT_378 = zT_379 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_148;
    z_bb_147:
    zT_378 = 0;
    goto z_bb_148;
    z_bb_148:
    if (zT_378) goto z_bb_149; else goto z_bb_150;
    z_bb_149:
    zT_384 = src.flags;
    zT_385 = tgt.flags;
    zT_390 = zF_08C13644_pointerQualifiersMo(zT_384, zT_385, (unsigned char)(2));
    qok = zT_390;
    zT_392 = reg->ptr_items;
    zT_393 = src.payload_idx;
    zT_394 = (unsigned int)zT_393;
    zT_395 = zT_392[zT_394];
    sp = zT_395;
    zT_397 = reg->ptr_items;
    zT_398 = tgt.payload_idx;
    zT_399 = (unsigned int)zT_398;
    zT_400 = zT_397[zT_399];
    tp = zT_400;
    zT_402 = reg->types_items;
    zT_403 = sp.base;
    zT_404 = (unsigned int)zT_403;
    zT_405 = zT_402[zT_404];
    spo = zT_405;
    zT_406 = spo.kind;
    if ((unsigned char)(zT_406 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_151; else goto z_bb_152;
    z_bb_150:
    zT_420 = src.kind;
    if ((unsigned char)(zT_420 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_158; else goto z_bb_159;
    z_bb_151:
    zT_411 = reg->array_items;
    zT_412 = spo.payload_idx;
    zT_413 = (unsigned int)zT_412;
    zT_414 = zT_411[zT_413];
    arr = zT_414;
    zT_415 = arr.elem;
    zT_416 = tp.base;
    if ((unsigned char)(zT_415 == zT_416)) goto z_bb_153; else goto z_bb_154;
    z_bb_152:
    goto z_bb_150;
    z_bb_153:
    zT_418 = qok;
    goto z_bb_155;
    z_bb_154:
    zT_418 = 0;
    goto z_bb_155;
    z_bb_155:
    if (zT_418) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_157:
    goto z_bb_152;
    z_bb_158:
    zT_425 = tgt.kind;
    zT_424 = zT_425 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_160;
    z_bb_159:
    zT_424 = 0;
    goto z_bb_160;
    z_bb_160:
    if (zT_424) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    zT_430 = src.flags;
    zT_431 = tgt.flags;
    zT_436 = zF_08C13644_pointerQualifiersMo(zT_430, zT_431, (unsigned char)(2));
    qok = zT_436;
    zT_438 = reg->slice_items;
    zT_439 = src.payload_idx;
    zT_440 = (unsigned int)zT_439;
    zT_441 = zT_438[zT_440];
    sl = zT_441;
    zT_443 = reg->ptr_items;
    zT_444 = tgt.payload_idx;
    zT_445 = (unsigned int)zT_444;
    zT_446 = zT_443[zT_445];
    pp = zT_446;
    zT_447 = sl.elem;
    zT_448 = pp.base;
    if ((unsigned char)(zT_447 == zT_448)) goto z_bb_163; else goto z_bb_164;
    z_bb_162:
    zT_452 = src.kind;
    if ((unsigned char)(zT_452 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_168; else goto z_bb_169;
    z_bb_163:
    zT_450 = qok;
    goto z_bb_165;
    z_bb_164:
    zT_450 = 0;
    goto z_bb_165;
    z_bb_165:
    if (zT_450) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_slice_to_many_ptr);
    z_bb_167:
    goto z_bb_162;
    z_bb_168:
    zT_457 = tgt.kind;
    zT_456 = zT_457 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_170;
    z_bb_169:
    zT_456 = 0;
    goto z_bb_170;
    z_bb_170:
    if (zT_456) goto z_bb_171; else goto z_bb_172;
    z_bb_171:
    zT_462 = reg->opt_items;
    zT_463 = tgt.payload_idx;
    zT_464 = (unsigned int)zT_463;
    zT_465 = zT_462[zT_464];
    opt2 = zT_465;
    zT_467 = reg->types_items;
    zT_468 = opt2.payload;
    zT_469 = (unsigned int)zT_468;
    zT_470 = zT_467[zT_469];
    opt_ty = zT_470;
    zT_471 = opt_ty.kind;
    if ((unsigned char)(zT_471 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_173; else goto z_bb_174;
    z_bb_172:
    if ((unsigned char)(source == (unsigned int)(8))) goto z_bb_177; else goto z_bb_178;
    z_bb_173:
    zT_475 = reg;
    zT_476 = source;
    zT_477 = opt2.payload;
    zT_479 = zF_683AEB7F_typeRegistryIsAssig(zT_475, zT_476, zT_477);
    if (zT_479) goto z_bb_175; else goto z_bb_176;
    z_bb_174:
    goto z_bb_172;
    z_bb_175:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_ptr_to_optional_ptr);
    z_bb_176:
    goto z_bb_174;
    z_bb_177:
    zT_483 = target == (unsigned int)(14);
    goto z_bb_179;
    z_bb_178:
    zT_483 = 0;
    goto z_bb_179;
    z_bb_179:
    if (zT_483) goto z_bb_181; else goto z_bb_180;
    z_bb_180:
    if ((unsigned char)(source == (unsigned int)(14))) goto z_bb_183; else goto z_bb_184;
    z_bb_181:
    zT_486 = 1;
    goto z_bb_182;
    z_bb_182:
    if (zT_486) goto z_bb_186; else goto z_bb_187;
    z_bb_183:
    zT_489 = target == (unsigned int)(8);
    goto z_bb_185;
    z_bb_184:
    zT_489 = 0;
    goto z_bb_185;
    z_bb_185:
    zT_486 = zT_489;
    goto z_bb_182;
    z_bb_186:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_187:
    zT_493 = src.kind;
    if ((unsigned char)(zT_493 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_188; else goto z_bb_189;
    z_bb_188:
    zT_498 = tgt.kind;
    zT_497 = zT_498 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_190;
    z_bb_189:
    zT_497 = 0;
    goto z_bb_190;
    z_bb_190:
    if (zT_497) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_503 = src.flags;
    zT_504 = tgt.flags;
    zT_509 = zF_08C13644_pointerQualifiersMo(zT_503, zT_504, (unsigned char)(2));
    qok = zT_509;
    zT_511 = reg->ptr_items;
    zT_512 = src.payload_idx;
    zT_513 = (unsigned int)zT_512;
    zT_514 = zT_511[zT_513];
    sp2 = zT_514;
    zT_516 = reg->slice_items;
    zT_517 = tgt.payload_idx;
    zT_518 = (unsigned int)zT_517;
    zT_519 = zT_516[zT_518];
    ts2 = zT_519;
    zT_521 = "CLS:p";
    zT_523 = 5;
    zT_522.ptr = zT_521;
    zT_522.len = zT_523;
    clsb = zT_522;
    zT_524 = clsb;
    zF_48AC7B3A_markerWrite(zT_524);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_526[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb2[_i] = zT_526[_i];
        _i++;
    }
}
    zT_528 = sp2.base;
    zT_533 = 0;
    zT_534 = (unsigned char*)((unsigned char*)clsb2) + zT_533;
    zT_535 = (unsigned int)(10) - zT_533;
    zT_536.ptr = zT_534;
    zT_536.len = zT_535;
    zT_529 = zT_536;
    zT_537 = zF_A7504564_itoa(zT_528, zT_529);
    clsb2l = zT_537;
    zT_541 = (unsigned int)(9) - (unsigned int)((unsigned int)clsb2l);
    clsb2s = zT_541;
    zT_546 = (unsigned char*)((unsigned char*)clsb2) + clsb2s;
    zT_547 = (unsigned int)(9) - clsb2s;
    zT_548.ptr = zT_546;
    zT_548.len = zT_547;
    zT_542 = zT_548;
    zF_48AC7B3A_markerWrite(zT_542);
    zT_550 = "e";
    zT_552 = 1;
    zT_551.ptr = zT_550;
    zT_551.len = zT_552;
    clse = zT_551;
    zT_553 = clse;
    zF_48AC7B3A_markerWrite(zT_553);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_555[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb3[_i] = zT_555[_i];
        _i++;
    }
}
    zT_557 = ts2.elem;
    zT_562 = 0;
    zT_563 = (unsigned char*)((unsigned char*)clsb3) + zT_562;
    zT_564 = (unsigned int)(10) - zT_562;
    zT_565.ptr = zT_563;
    zT_565.len = zT_564;
    zT_558 = zT_565;
    zT_566 = zF_A7504564_itoa(zT_557, zT_558);
    clsb3l = zT_566;
    zT_570 = (unsigned int)(9) - (unsigned int)((unsigned int)clsb3l);
    clsb3s = zT_570;
    zT_575 = (unsigned char*)((unsigned char*)clsb3) + clsb3s;
    zT_576 = (unsigned int)(9) - clsb3s;
    zT_577.ptr = zT_575;
    zT_577.len = zT_576;
    zT_571 = zT_577;
    zF_48AC7B3A_markerWrite(zT_571);
    zT_579 = "\n";
    zT_581 = 1;
    zT_580.ptr = zT_579;
    zT_580.len = zT_581;
    clsnl = zT_580;
    zT_582 = clsnl;
    zF_48AC7B3A_markerWrite(zT_582);
    zT_584 = reg->types_items;
    zT_585 = sp2.base;
    zT_586 = (unsigned int)zT_585;
    zT_587 = zT_584[zT_586];
    src_pointee = zT_587;
    zT_588 = src_pointee.kind;
    if ((unsigned char)(zT_588 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_193; else goto z_bb_194;
    z_bb_192:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_193:
    zT_593 = reg->array_items;
    zT_594 = src_pointee.payload_idx;
    zT_595 = (unsigned int)zT_594;
    zT_596 = zT_593[zT_595];
    arr = zT_596;
    zT_597 = arr.elem;
    zT_598 = ts2.elem;
    if ((unsigned char)(zT_597 == zT_598)) goto z_bb_195; else goto z_bb_196;
    z_bb_194:
    goto z_bb_192;
    z_bb_195:
    zT_600 = qok;
    goto z_bb_197;
    z_bb_196:
    zT_600 = 0;
    goto z_bb_197;
    z_bb_197:
    if (zT_600) goto z_bb_198; else goto z_bb_199;
    z_bb_198:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_199:
    goto z_bb_194;
}

/* EOF */
