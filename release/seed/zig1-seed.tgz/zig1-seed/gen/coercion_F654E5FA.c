#include "coercion_F654E5FA.h"
zT_66E7D2EF_CoercionTable zG_66E7D2EF_CoercionTable;
zT_0FB7FB13_CoercionKind zG_0FB7FB13_CoercionKind;
/* coercionTableEnsureCapacity */
void zF_E837F929_coercionTableEnsure(zT_66E7D2EF_CoercionTable* self, unsigned int new_cap) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    int zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned char* zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_3E40CD83_Sand* zT_25;
    zT_9CDC9863_CoercionEntry* zT_26;
    unsigned char* zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_E637E89E_Opt_218 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    zT_3E40CD83_Sand* zT_40;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_171165BB_EU_812 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    unsigned char* zT_47;
    zT_9CDC9863_CoercionEntry* zT_49;
    zT_9CDC9863_CoercionEntry* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_9CDC9863_CoercionEntry* zT_53;
    unsigned int zT_54;
    zT_5B0DCA45_Slice_zT_9CDC9863_C zT_55;
    zT_9CDC9863_CoercionEntry* zT_56;
    unsigned int zT_57;
    int zT_59;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned int nc;
    zT_E637E89E_Opt_218 grown;
    unsigned char* raw;
    zT_9CDC9863_CoercionEntry* new_items;
    zT_9CDC9863_CoercionEntry item;
    unsigned int i;
    zT_2 = self->entries_cap;
    zT_3 = new_cap <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    nc = new_cap;
    nc = new_cap;
    zT_5 = self->entries_cap;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = nc < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->entries_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    zT_13 = nc < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->entries_cap;
    zT_17 = 0;
    zT_18 = zT_16 > (unsigned int)zT_17;
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self->entries_alloc;
    zT_20 = zT_25;
    zT_26 = self->entries_items;
    zT_27 = (unsigned char*)zT_26;
    zT_21 = zT_27;
    zT_28 = self->entries_cap;
    zT_29 = 12;
    zT_30 = zT_28 * zT_29;
    zT_22 = zT_30;
    zT_31 = 12;
    zT_32 = nc * zT_31;
    zT_23 = zT_32;
    zT_33 = 4;
    zT_24 = zT_33;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, zT_21, zT_22, zT_23, zT_24);
    grown = zT_34;
    grown = zT_34;
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_40 = self->entries_alloc;
    zT_37 = zT_40;
    zT_41 = 12;
    zT_42 = zT_41 * nc;
    zT_38 = zT_42;
    zT_43 = 4;
    zT_39 = zT_43;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, zT_38, zT_39);
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->entries_cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    z_bb_12:
    zT_47 = zT_44.data.payload;
    zT_46 = zT_47;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    raw = zT_46;
    raw = zT_46;
    zT_49 = (zT_9CDC9863_CoercionEntry*)raw;
    new_items = zT_49;
    new_items = zT_49;
    new_items = zT_49;
    zT_50 = self->entries_items;
    zT_51 = self->entries_len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    zT_59 = i < zT_57;
    if (zT_59) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_61 = 1;
    zT_62 = i + zT_61;
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->entries_items = new_items;
    self->entries_cap = nc;
    return;
}

/* coercionTableInit */
zT_66E7D2EF_CoercionTable zF_26B6D809_coercionTableInit(zT_3E40CD83_Sand* alloc) {
    zT_66E7D2EF_CoercionTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_21D3708C_U32ToU32Map zT_6 = {0};
    zT_2 = 0;
    zT_1.entries_items = (zT_9CDC9863_CoercionEntry*)zT_2;
    zT_3 = 0;
    zT_1.entries_len = zT_3;
    zT_4 = 0;
    zT_1.entries_cap = zT_4;
    zT_1.entries_alloc = alloc;
    zT_5 = alloc;
    zT_6 = zF_58BDA2DE_u32ToU32MapInit(zT_5);
    zT_1.index = zT_6;
    return zT_1;
}

/* coercionTableAdd */
void zF_D21AE60A_coercionTableAdd(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx, zT_0FB7FB13_CoercionKind kind, unsigned int target_type) {
    zT_9CDC9863_CoercionEntry zT_5;
    zT_21D3708C_U32ToU32Map* zT_7;
    unsigned int zT_8;
    zT_21D3708C_U32ToU32Map* zT_9;
    zT_BAEE192E_Opt_10 zT_10 = {0};
    unsigned char zT_11;
    zT_9CDC9863_CoercionEntry* zT_13;
    unsigned int zT_14;
    zT_66E7D2EF_CoercionTable* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_9CDC9863_CoercionEntry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    zT_21D3708C_U32ToU32Map* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_21D3708C_U32ToU32Map* zT_32;
    zT_9CDC9863_CoercionEntry entry;
    zT_BAEE192E_Opt_10 existing;
    unsigned int idx;
    zT_5.node_idx = node_idx;
    zT_5.kind = kind;
    zT_5.target_type = target_type;
    entry = zT_5;
    entry = zT_5;
    entry = zT_5;
    zT_9 = &self->index;
    zT_7 = zT_9;
    zT_8 = node_idx;
    zT_10 = zF_F3EE5998_u32ToU32MapGet(zT_7, zT_8);
    existing = zT_10;
    existing = zT_10;
    existing = zT_10;
    zT_11 = existing.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = existing.value;
    zT_13 = self->entries_items;
    zT_14 = (unsigned int)idx;
    zT_13[zT_14] = entry;
    return;
    z_bb_2:
    zT_15 = self;
    zT_17 = self->entries_len;
    zT_18 = 1;
    zT_19 = zT_17 + zT_18;
    zT_16 = zT_19;
    zF_E837F929_coercionTableEnsure(zT_15, zT_16);
    zT_21 = self->entries_len;
    zT_22 = (unsigned int)zT_21;
    idx = zT_22;
    idx = zT_22;
    idx = zT_22;
    zT_23 = self->entries_items;
    zT_24 = (unsigned int)idx;
    zT_23[zT_24] = entry;
    zT_25 = self->entries_len;
    zT_26 = 1;
    zT_27 = (unsigned int)zT_26;
    zT_28 = zT_25 + zT_27;
    self->entries_len = zT_28;
    zT_32 = &self->index;
    zT_29 = zT_32;
    zT_30 = node_idx;
    zT_31 = idx;
    zF_26476265_u32ToU32MapPut(zT_29, zT_30, zT_31);
    return;
}

/* coercionTableGet */
zT_53BDEAE5_Opt_181 zF_46B66789_coercionTableGet(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_21D3708C_U32ToU32Map* zT_5;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    zT_9CDC9863_CoercionEntry* zT_9;
    unsigned int zT_10;
    zT_9CDC9863_CoercionEntry zT_11;
    zT_53BDEAE5_Opt_181 zT_12;
    zT_53BDEAE5_Opt_181 zT_13 = {0};
    zT_BAEE192E_Opt_10 entry_idx;
    unsigned int idx;
    zT_5 = &self->index;
    zT_3 = zT_5;
    zT_4 = node_idx;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    entry_idx = zT_6;
    entry_idx = zT_6;
    entry_idx = zT_6;
    zT_7 = entry_idx.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = entry_idx.value;
    zT_9 = self->entries_items;
    zT_10 = (unsigned int)idx;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
    z_bb_2:
    zT_13.has_value = 0;
    return zT_13;
}

/* classifyCoercion */
zT_0FB7FB13_CoercionKind zF_713658BF_classifyCoercion(zT_338B7C76_TypeRegistry* reg, unsigned int source, unsigned int target) {
    int zT_3;
    zT_0FB7FB13_CoercionKind zT_4;
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_16;
    int zT_17;
    int zT_18;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    int zT_21 = 0;
    zT_0FB7FB13_CoercionKind zT_22;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    int zT_25 = 0;
    int zT_26;
    zT_338B7C76_TypeRegistry* zT_27;
    unsigned int zT_28;
    int zT_29 = 0;
    int zT_30;
    unsigned int zT_31;
    int zT_32;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    int zT_35 = 0;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    int zT_38 = 0;
    int zT_39;
    int zT_40;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    unsigned char zT_43 = 0;
    zT_338B7C76_TypeRegistry* zT_44;
    unsigned int zT_45;
    unsigned char zT_46 = 0;
    int zT_47;
    zT_0FB7FB13_CoercionKind zT_48;
    unsigned int zT_49;
    int zT_50;
    int zT_51;
    unsigned int zT_52;
    int zT_53;
    zT_0FB7FB13_CoercionKind zT_54;
    zT_33EF6BFB_TypeKind zT_55;
    zT_33EF6BFB_TypeKind zT_58;
    int zT_59;
    char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_338B7C76_TypeRegistry* zT_66;
    unsigned int zT_67;
    int zT_68 = 0;
    zT_0FB7FB13_CoercionKind zT_69;
    zT_33EF6BFB_TypeKind zT_70;
    zT_33EF6BFB_TypeKind zT_73;
    int zT_74;
    zT_0FB7FB13_CoercionKind zT_75;
    zT_33EF6BFB_TypeKind zT_76;
    zT_33EF6BFB_TypeKind zT_79;
    int zT_80;
    zT_0FB7FB13_CoercionKind zT_81;
    zT_33EF6BFB_TypeKind zT_82;
    zT_33EF6BFB_TypeKind zT_85;
    int zT_86;
    zT_0B10E8E9_OptionalPayload* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_0B10E8E9_OptionalPayload zT_91;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    int zT_96 = 0;
    zT_0FB7FB13_CoercionKind zT_97;
    zT_33EF6BFB_TypeKind zT_98;
    zT_33EF6BFB_TypeKind zT_101;
    int zT_102;
    zT_0FB7FB13_CoercionKind zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    zT_33EF6BFB_TypeKind zT_107;
    int zT_108;
    zT_42C2D6BF_EUPayload* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_42C2D6BF_EUPayload zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    unsigned int zT_117;
    int zT_118 = 0;
    zT_0FB7FB13_CoercionKind zT_119;
    zT_33EF6BFB_TypeKind zT_120;
    zT_33EF6BFB_TypeKind zT_123;
    int zT_124;
    int zT_125;
    zT_33EF6BFB_TypeKind zT_126;
    zT_33EF6BFB_TypeKind zT_129;
    int zT_130;
    zT_0FB7FB13_CoercionKind zT_131;
    zT_33EF6BFB_TypeKind zT_132;
    zT_33EF6BFB_TypeKind zT_135;
    int zT_136;
    int zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_33EF6BFB_TypeKind zT_141;
    int zT_142;
    zT_112BF819_PtrPayload* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_112BF819_PtrPayload zT_147;
    zT_112BF819_PtrPayload* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_112BF819_PtrPayload zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    int zT_155;
    zT_0FB7FB13_CoercionKind zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    int zT_159;
    zT_0FB7FB13_CoercionKind zT_160;
    unsigned char zT_161;
    unsigned char zT_162;
    unsigned char zT_163;
    unsigned char zT_164;
    int zT_165;
    int zT_166;
    unsigned char zT_167;
    unsigned char zT_168;
    unsigned char zT_169;
    unsigned char zT_170;
    int zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    int zT_174;
    zT_0FB7FB13_CoercionKind zT_175;
    zT_33EF6BFB_TypeKind zT_176;
    zT_33EF6BFB_TypeKind zT_179;
    int zT_180;
    int zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    zT_33EF6BFB_TypeKind zT_185;
    int zT_186;
    unsigned char zT_187;
    unsigned char zT_188;
    unsigned char zT_189;
    unsigned char zT_190;
    int zT_191;
    int zT_192;
    unsigned char zT_193;
    unsigned char zT_194;
    unsigned char zT_195;
    unsigned char zT_196;
    int zT_197;
    zT_0BB2A741_SlicePayload* zT_199;
    unsigned int zT_200;
    unsigned int zT_201;
    zT_0BB2A741_SlicePayload zT_202;
    zT_0BB2A741_SlicePayload* zT_204;
    unsigned int zT_205;
    unsigned int zT_206;
    zT_0BB2A741_SlicePayload zT_207;
    unsigned int zT_208;
    unsigned int zT_209;
    int zT_210;
    zT_0FB7FB13_CoercionKind zT_211;
    zT_33EF6BFB_TypeKind zT_212;
    zT_33EF6BFB_TypeKind zT_215;
    int zT_216;
    int zT_217;
    zT_33EF6BFB_TypeKind zT_218;
    zT_33EF6BFB_TypeKind zT_221;
    int zT_222;
    unsigned char zT_223;
    unsigned char zT_224;
    unsigned char zT_225;
    unsigned char zT_226;
    int zT_227;
    int zT_228;
    unsigned char zT_229;
    unsigned char zT_230;
    unsigned char zT_231;
    unsigned char zT_232;
    int zT_233;
    zT_112BF819_PtrPayload* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_112BF819_PtrPayload zT_238;
    zT_112BF819_PtrPayload* zT_240;
    unsigned int zT_241;
    unsigned int zT_242;
    zT_112BF819_PtrPayload zT_243;
    unsigned int zT_244;
    unsigned int zT_245;
    int zT_246;
    zT_0FB7FB13_CoercionKind zT_247;
    zT_33EF6BFB_TypeKind zT_248;
    zT_33EF6BFB_TypeKind zT_251;
    int zT_252;
    int zT_253;
    zT_33EF6BFB_TypeKind zT_254;
    zT_33EF6BFB_TypeKind zT_257;
    int zT_258;
    zT_E834303C_ArrayPayload* zT_260;
    unsigned int zT_261;
    unsigned int zT_262;
    zT_E834303C_ArrayPayload zT_263;
    zT_0BB2A741_SlicePayload* zT_265;
    unsigned int zT_266;
    unsigned int zT_267;
    zT_0BB2A741_SlicePayload zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    int zT_271;
    zT_0FB7FB13_CoercionKind zT_272;
    unsigned char zT_273;
    unsigned char zT_274;
    unsigned char zT_275;
    unsigned char zT_276;
    int zT_277;
    int zT_278;
    unsigned int zT_279;
    unsigned int zT_280;
    int zT_281;
    zT_0FB7FB13_CoercionKind zT_282;
    zT_33EF6BFB_TypeKind zT_283;
    zT_33EF6BFB_TypeKind zT_286;
    int zT_287;
    int zT_288;
    zT_33EF6BFB_TypeKind zT_289;
    zT_33EF6BFB_TypeKind zT_292;
    int zT_293;
    zT_E834303C_ArrayPayload* zT_295;
    unsigned int zT_296;
    unsigned int zT_297;
    zT_E834303C_ArrayPayload zT_298;
    zT_112BF819_PtrPayload* zT_300;
    unsigned int zT_301;
    unsigned int zT_302;
    zT_112BF819_PtrPayload zT_303;
    unsigned int zT_304;
    unsigned int zT_305;
    int zT_306;
    zT_0FB7FB13_CoercionKind zT_307;
    zT_33EF6BFB_TypeKind zT_308;
    zT_33EF6BFB_TypeKind zT_311;
    int zT_312;
    int zT_313;
    zT_33EF6BFB_TypeKind zT_314;
    zT_33EF6BFB_TypeKind zT_317;
    int zT_318;
    zT_0BB2A741_SlicePayload* zT_320;
    unsigned int zT_321;
    unsigned int zT_322;
    zT_0BB2A741_SlicePayload zT_323;
    zT_112BF819_PtrPayload* zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    zT_112BF819_PtrPayload zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    int zT_331;
    zT_0FB7FB13_CoercionKind zT_332;
    zT_33EF6BFB_TypeKind zT_333;
    zT_33EF6BFB_TypeKind zT_336;
    int zT_337;
    int zT_338;
    zT_33EF6BFB_TypeKind zT_339;
    zT_33EF6BFB_TypeKind zT_342;
    int zT_343;
    zT_0B10E8E9_OptionalPayload* zT_345;
    unsigned int zT_346;
    unsigned int zT_347;
    zT_0B10E8E9_OptionalPayload zT_348;
    zT_D155D06D_Type* zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    zT_D155D06D_Type zT_353;
    zT_33EF6BFB_TypeKind zT_354;
    zT_33EF6BFB_TypeKind zT_357;
    int zT_358;
    zT_338B7C76_TypeRegistry* zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    unsigned int zT_362;
    int zT_363 = 0;
    zT_0FB7FB13_CoercionKind zT_364;
    unsigned int zT_365;
    int zT_366;
    int zT_367;
    unsigned int zT_368;
    int zT_369;
    int zT_370;
    unsigned int zT_371;
    int zT_372;
    int zT_373;
    unsigned int zT_374;
    int zT_375;
    zT_0FB7FB13_CoercionKind zT_376;
    zT_33EF6BFB_TypeKind zT_377;
    zT_33EF6BFB_TypeKind zT_380;
    int zT_381;
    int zT_382;
    zT_33EF6BFB_TypeKind zT_383;
    zT_33EF6BFB_TypeKind zT_386;
    int zT_387;
    zT_112BF819_PtrPayload* zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    zT_112BF819_PtrPayload zT_392;
    zT_0BB2A741_SlicePayload* zT_394;
    unsigned int zT_395;
    unsigned int zT_396;
    zT_0BB2A741_SlicePayload zT_397;
    char* zT_399;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_400;
    unsigned int zT_401;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_402;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_404;
    unsigned int zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    unsigned int zT_408;
    unsigned char* zT_409;
    unsigned int zT_410;
    int zT_411;
    unsigned char* zT_412;
    unsigned int zT_413;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_414;
    unsigned int zT_415 = 0;
    unsigned int zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_420;
    unsigned char* zT_421;
    unsigned int zT_423;
    unsigned char* zT_424;
    unsigned int zT_425;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_426;
    char* zT_428;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_429;
    unsigned int zT_430;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_431;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_433;
    unsigned int zT_435;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_436;
    unsigned int zT_437;
    unsigned char* zT_438;
    unsigned int zT_439;
    int zT_440;
    unsigned char* zT_441;
    unsigned int zT_442;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_443;
    unsigned int zT_444 = 0;
    unsigned int zT_446;
    unsigned int zT_447;
    unsigned int zT_448;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_449;
    unsigned char* zT_450;
    unsigned int zT_452;
    unsigned char* zT_453;
    unsigned int zT_454;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_455;
    char* zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_458;
    unsigned int zT_459;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_460;
    unsigned int zT_461;
    unsigned int zT_462;
    int zT_463;
    zT_0FB7FB13_CoercionKind zT_464;
    unsigned int zT_465;
    unsigned int zT_466;
    int zT_467;
    int zT_468;
    unsigned int zT_469;
    unsigned int zT_470;
    int zT_471;
    zT_0FB7FB13_CoercionKind zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    int zT_475;
    int zT_476;
    unsigned int zT_477;
    unsigned int zT_478;
    int zT_479;
    zT_0FB7FB13_CoercionKind zT_480;
    zT_D155D06D_Type* zT_482;
    unsigned int zT_483;
    unsigned int zT_484;
    zT_D155D06D_Type zT_485;
    zT_33EF6BFB_TypeKind zT_486;
    zT_33EF6BFB_TypeKind zT_489;
    int zT_490;
    zT_E834303C_ArrayPayload* zT_492;
    unsigned int zT_493;
    unsigned int zT_494;
    zT_E834303C_ArrayPayload zT_495;
    unsigned int zT_496;
    unsigned int zT_497;
    int zT_498;
    zT_0FB7FB13_CoercionKind zT_499;
    zT_0FB7FB13_CoercionKind zT_500;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_8F083A69_Slice_zT_0B42B2F8_u ccn_m;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_E834303C_ArrayPayload arr;
    zT_0BB2A741_SlicePayload sl;
    zT_112BF819_PtrPayload pp;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_D155D06D_Type opt_ty;
    zT_112BF819_PtrPayload sp2;
    zT_0BB2A741_SlicePayload ts2;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsb;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb2;
    unsigned int clsb2l;
    unsigned int clsb2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clse;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb3;
    unsigned int clsb3l;
    unsigned int clsb3s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsnl;
    zT_D155D06D_Type src_pointee;
    zT_3 = source == target;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4 = zT_0FB7FB13_CoercionKind_none;
    return zT_4;
    z_bb_2:
    zT_6 = reg->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    src = zT_8;
    src = zT_8;
    zT_10 = reg->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    tgt = zT_12;
    tgt = zT_12;
    zT_13 = src.kind;
    zT_16 = zT_33EF6BFB_TypeKind_integer_literal_type;
    zT_17 = zT_13 == zT_16;
    if (zT_17) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = reg;
    zT_20 = target;
    zT_21 = zF_3087E0A5_typeRegistryIsNumer(zT_19, zT_20);
    zT_18 = zT_21;
    goto z_bb_5;
    z_bb_4:
    zT_18 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_18) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_22 = zT_0FB7FB13_CoercionKind_int_literal_coerce;
    return zT_22;
    z_bb_7:
    zT_23 = reg;
    zT_24 = source;
    zT_25 = zF_3290E9C4_typeRegistryIsInteg(zT_23, zT_24);
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_27 = reg;
    zT_28 = target;
    zT_29 = zF_3290E9C4_typeRegistryIsInteg(zT_27, zT_28);
    zT_26 = zT_29;
    goto z_bb_10;
    z_bb_9:
    zT_26 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_26) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_31 = 19;
    zT_32 = source != zT_31;
    zT_30 = zT_32;
    goto z_bb_13;
    z_bb_12:
    zT_30 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_30) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_33 = reg;
    zT_34 = source;
    zT_35 = zF_B664AC19_typeRegistryIsUnsig(zT_33, zT_34);
    zT_36 = reg;
    zT_37 = target;
    zT_38 = zF_B664AC19_typeRegistryIsUnsig(zT_36, zT_37);
    zT_39 = zT_35 == zT_38;
    if (zT_39) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_49 = 15;
    zT_50 = source == zT_49;
    if (zT_50) goto z_bb_21; else goto z_bb_22;
    z_bb_16:
    zT_41 = reg;
    zT_42 = source;
    zT_43 = zF_655972D5_typeRegistryIntWidt(zT_41, zT_42);
    zT_44 = reg;
    zT_45 = target;
    zT_46 = zF_655972D5_typeRegistryIntWidt(zT_44, zT_45);
    zT_47 = zT_43 < zT_46;
    zT_40 = zT_47;
    goto z_bb_18;
    z_bb_17:
    zT_40 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_40) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_48 = zT_0FB7FB13_CoercionKind_int_widen;
    return zT_48;
    z_bb_20:
    goto z_bb_15;
    z_bb_21:
    zT_52 = 16;
    zT_53 = target == zT_52;
    zT_51 = zT_53;
    goto z_bb_23;
    z_bb_22:
    zT_51 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_51) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_54 = zT_0FB7FB13_CoercionKind_float_widen;
    return zT_54;
    z_bb_25:
    zT_55 = src.kind;
    zT_58 = zT_33EF6BFB_TypeKind_null_type;
    zT_59 = zT_55 == zT_58;
    if (zT_59) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_61 = "CC:nul";
    zT_63 = 6;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    ccn_m = zT_62;
    ccn_m = zT_62;
    ccn_m = zT_62;
    zT_64 = ccn_m;
    zT_65 = target;
    zF_C914CB83_markerWriteInt(zT_64, zT_65);
    zT_66 = reg;
    zT_67 = target;
    zT_68 = zF_AD61DB1B_typeRegistryIsPoint(zT_66, zT_67);
    if (zT_68) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_82 = tgt.kind;
    zT_85 = zT_33EF6BFB_TypeKind_optional_type;
    zT_86 = zT_82 == zT_85;
    if (zT_86) goto z_bb_34; else goto z_bb_35;
    z_bb_28:
    zT_69 = zT_0FB7FB13_CoercionKind_none;
    return zT_69;
    z_bb_29:
    zT_70 = tgt.kind;
    zT_73 = zT_33EF6BFB_TypeKind_optional_type;
    zT_74 = zT_70 == zT_73;
    if (zT_74) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_75 = zT_0FB7FB13_CoercionKind_wrap_optional_null;
    return zT_75;
    z_bb_31:
    zT_76 = tgt.kind;
    zT_79 = zT_33EF6BFB_TypeKind_fn_type;
    zT_80 = zT_76 == zT_79;
    if (zT_80) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_81 = zT_0FB7FB13_CoercionKind_none;
    return zT_81;
    z_bb_33:
    goto z_bb_27;
    z_bb_34:
    zT_88 = reg->opt_items;
    zT_89 = tgt.payload_idx;
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_88[zT_90];
    opt = zT_91;
    opt = zT_91;
    opt = zT_91;
    zT_92 = reg;
    zT_93 = source;
    zT_95 = opt.payload;
    zT_94 = zT_95;
    zT_96 = zF_683AEB7F_typeRegistryIsAssig(zT_92, zT_93, zT_94);
    if (zT_96) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    zT_104 = tgt.kind;
    zT_107 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_108 = zT_104 == zT_107;
    if (zT_108) goto z_bb_40; else goto z_bb_41;
    z_bb_36:
    zT_97 = zT_0FB7FB13_CoercionKind_wrap_optional;
    return zT_97;
    z_bb_37:
    zT_98 = src.kind;
    zT_101 = zT_33EF6BFB_TypeKind_null_type;
    zT_102 = zT_98 == zT_101;
    if (zT_102) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_103 = zT_0FB7FB13_CoercionKind_none;
    return zT_103;
    z_bb_39:
    goto z_bb_35;
    z_bb_40:
    zT_110 = reg->eu_items;
    zT_111 = tgt.payload_idx;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zT_110[zT_112];
    eu = zT_113;
    eu = zT_113;
    eu = zT_113;
    zT_114 = reg;
    zT_115 = source;
    zT_117 = eu.payload;
    zT_116 = zT_117;
    zT_118 = zF_683AEB7F_typeRegistryIsAssig(zT_114, zT_115, zT_116);
    if (zT_118) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_120 = src.kind;
    zT_123 = zT_33EF6BFB_TypeKind_error_set_type;
    zT_124 = zT_120 == zT_123;
    if (zT_124) goto z_bb_44; else goto z_bb_45;
    z_bb_42:
    zT_119 = zT_0FB7FB13_CoercionKind_wrap_error_success;
    return zT_119;
    z_bb_43:
    goto z_bb_41;
    z_bb_44:
    zT_126 = tgt.kind;
    zT_129 = zT_33EF6BFB_TypeKind_error_union_type;
    zT_130 = zT_126 == zT_129;
    zT_125 = zT_130;
    goto z_bb_46;
    z_bb_45:
    zT_125 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_125) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_131 = zT_0FB7FB13_CoercionKind_wrap_error_err;
    return zT_131;
    z_bb_48:
    zT_132 = src.kind;
    zT_135 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_136 = zT_132 == zT_135;
    if (zT_136) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_138 = tgt.kind;
    zT_141 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_142 = zT_138 == zT_141;
    zT_137 = zT_142;
    goto z_bb_51;
    z_bb_50:
    zT_137 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_137) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_144 = reg->ptr_items;
    zT_145 = tgt.payload_idx;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zT_144[zT_146];
    tgt_pp = zT_147;
    tgt_pp = zT_147;
    tgt_pp = zT_147;
    zT_149 = reg->ptr_items;
    zT_150 = src.payload_idx;
    zT_151 = (unsigned int)zT_150;
    zT_152 = zT_149[zT_151];
    src_pp = zT_152;
    src_pp = zT_152;
    src_pp = zT_152;
    zT_153 = tgt_pp.base;
    zT_154 = 1;
    zT_155 = zT_153 == zT_154;
    if (zT_155) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_176 = tgt.kind;
    zT_179 = zT_33EF6BFB_TypeKind_slice_type;
    zT_180 = zT_176 == zT_179;
    if (zT_180) goto z_bb_65; else goto z_bb_66;
    z_bb_54:
    zT_156 = zT_0FB7FB13_CoercionKind_none;
    return zT_156;
    z_bb_55:
    zT_157 = src_pp.base;
    zT_158 = 1;
    zT_159 = zT_157 == zT_158;
    if (zT_159) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_160 = zT_0FB7FB13_CoercionKind_none;
    return zT_160;
    z_bb_57:
    zT_161 = tgt.flags;
    zT_162 = 1;
    zT_163 = zT_161 & zT_162;
    zT_164 = 0;
    zT_165 = zT_163 != zT_164;
    if (zT_165) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_167 = src.flags;
    zT_168 = 1;
    zT_169 = zT_167 & zT_168;
    zT_170 = 0;
    zT_171 = zT_169 == zT_170;
    zT_166 = zT_171;
    goto z_bb_60;
    z_bb_59:
    zT_166 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_166) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_172 = src_pp.base;
    zT_173 = tgt_pp.base;
    zT_174 = zT_172 == zT_173;
    if (zT_174) goto z_bb_63; else goto z_bb_64;
    z_bb_62:
    goto z_bb_53;
    z_bb_63:
    zT_175 = zT_0FB7FB13_CoercionKind_const_qualify;
    return zT_175;
    z_bb_64:
    goto z_bb_62;
    z_bb_65:
    zT_182 = src.kind;
    zT_185 = zT_33EF6BFB_TypeKind_slice_type;
    zT_186 = zT_182 == zT_185;
    zT_181 = zT_186;
    goto z_bb_67;
    z_bb_66:
    zT_181 = 0;
    goto z_bb_67;
    z_bb_67:
    if (zT_181) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_187 = tgt.flags;
    zT_188 = 1;
    zT_189 = zT_187 & zT_188;
    zT_190 = 0;
    zT_191 = zT_189 != zT_190;
    if (zT_191) goto z_bb_70; else goto z_bb_71;
    z_bb_69:
    zT_212 = tgt.kind;
    zT_215 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_216 = zT_212 == zT_215;
    if (zT_216) goto z_bb_77; else goto z_bb_78;
    z_bb_70:
    zT_193 = src.flags;
    zT_194 = 1;
    zT_195 = zT_193 & zT_194;
    zT_196 = 0;
    zT_197 = zT_195 == zT_196;
    zT_192 = zT_197;
    goto z_bb_72;
    z_bb_71:
    zT_192 = 0;
    goto z_bb_72;
    z_bb_72:
    if (zT_192) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_199 = reg->slice_items;
    zT_200 = src.payload_idx;
    zT_201 = (unsigned int)zT_200;
    zT_202 = zT_199[zT_201];
    s_sl = zT_202;
    s_sl = zT_202;
    s_sl = zT_202;
    zT_204 = reg->slice_items;
    zT_205 = tgt.payload_idx;
    zT_206 = (unsigned int)zT_205;
    zT_207 = zT_204[zT_206];
    t_sl = zT_207;
    t_sl = zT_207;
    t_sl = zT_207;
    zT_208 = s_sl.elem;
    zT_209 = t_sl.elem;
    zT_210 = zT_208 == zT_209;
    if (zT_210) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    goto z_bb_69;
    z_bb_75:
    zT_211 = zT_0FB7FB13_CoercionKind_const_qualify;
    return zT_211;
    z_bb_76:
    goto z_bb_74;
    z_bb_77:
    zT_218 = src.kind;
    zT_221 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_222 = zT_218 == zT_221;
    zT_217 = zT_222;
    goto z_bb_79;
    z_bb_78:
    zT_217 = 0;
    goto z_bb_79;
    z_bb_79:
    if (zT_217) goto z_bb_80; else goto z_bb_81;
    z_bb_80:
    zT_223 = tgt.flags;
    zT_224 = 1;
    zT_225 = zT_223 & zT_224;
    zT_226 = 0;
    zT_227 = zT_225 != zT_226;
    if (zT_227) goto z_bb_82; else goto z_bb_83;
    z_bb_81:
    zT_248 = src.kind;
    zT_251 = zT_33EF6BFB_TypeKind_array_type;
    zT_252 = zT_248 == zT_251;
    if (zT_252) goto z_bb_89; else goto z_bb_90;
    z_bb_82:
    zT_229 = src.flags;
    zT_230 = 1;
    zT_231 = zT_229 & zT_230;
    zT_232 = 0;
    zT_233 = zT_231 == zT_232;
    zT_228 = zT_233;
    goto z_bb_84;
    z_bb_83:
    zT_228 = 0;
    goto z_bb_84;
    z_bb_84:
    if (zT_228) goto z_bb_85; else goto z_bb_86;
    z_bb_85:
    zT_235 = reg->ptr_items;
    zT_236 = src.payload_idx;
    zT_237 = (unsigned int)zT_236;
    zT_238 = zT_235[zT_237];
    s_pp = zT_238;
    s_pp = zT_238;
    s_pp = zT_238;
    zT_240 = reg->ptr_items;
    zT_241 = tgt.payload_idx;
    zT_242 = (unsigned int)zT_241;
    zT_243 = zT_240[zT_242];
    t_pp = zT_243;
    t_pp = zT_243;
    t_pp = zT_243;
    zT_244 = s_pp.base;
    zT_245 = t_pp.base;
    zT_246 = zT_244 == zT_245;
    if (zT_246) goto z_bb_87; else goto z_bb_88;
    z_bb_86:
    goto z_bb_81;
    z_bb_87:
    zT_247 = zT_0FB7FB13_CoercionKind_const_qualify;
    return zT_247;
    z_bb_88:
    goto z_bb_86;
    z_bb_89:
    zT_254 = tgt.kind;
    zT_257 = zT_33EF6BFB_TypeKind_slice_type;
    zT_258 = zT_254 == zT_257;
    zT_253 = zT_258;
    goto z_bb_91;
    z_bb_90:
    zT_253 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_253) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    zT_260 = reg->array_items;
    zT_261 = src.payload_idx;
    zT_262 = (unsigned int)zT_261;
    zT_263 = zT_260[zT_262];
    arr = zT_263;
    arr = zT_263;
    arr = zT_263;
    zT_265 = reg->slice_items;
    zT_266 = tgt.payload_idx;
    zT_267 = (unsigned int)zT_266;
    zT_268 = zT_265[zT_267];
    sl = zT_268;
    sl = zT_268;
    sl = zT_268;
    zT_269 = arr.elem;
    zT_270 = sl.elem;
    zT_271 = zT_269 == zT_270;
    if (zT_271) goto z_bb_94; else goto z_bb_95;
    z_bb_93:
    zT_283 = src.kind;
    zT_286 = zT_33EF6BFB_TypeKind_array_type;
    zT_287 = zT_283 == zT_286;
    if (zT_287) goto z_bb_101; else goto z_bb_102;
    z_bb_94:
    zT_272 = zT_0FB7FB13_CoercionKind_array_to_slice;
    return zT_272;
    z_bb_95:
    zT_273 = tgt.flags;
    zT_274 = 1;
    zT_275 = zT_273 & zT_274;
    zT_276 = 0;
    zT_277 = zT_275 != zT_276;
    if (zT_277) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_279 = arr.elem;
    zT_280 = sl.elem;
    zT_281 = zT_279 == zT_280;
    zT_278 = zT_281;
    goto z_bb_98;
    z_bb_97:
    zT_278 = 0;
    goto z_bb_98;
    z_bb_98:
    if (zT_278) goto z_bb_99; else goto z_bb_100;
    z_bb_99:
    zT_282 = zT_0FB7FB13_CoercionKind_array_to_slice;
    return zT_282;
    z_bb_100:
    goto z_bb_93;
    z_bb_101:
    zT_289 = tgt.kind;
    zT_292 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_293 = zT_289 == zT_292;
    zT_288 = zT_293;
    goto z_bb_103;
    z_bb_102:
    zT_288 = 0;
    goto z_bb_103;
    z_bb_103:
    if (zT_288) goto z_bb_104; else goto z_bb_105;
    z_bb_104:
    zT_295 = reg->array_items;
    zT_296 = src.payload_idx;
    zT_297 = (unsigned int)zT_296;
    zT_298 = zT_295[zT_297];
    arr = zT_298;
    arr = zT_298;
    arr = zT_298;
    zT_300 = reg->ptr_items;
    zT_301 = tgt.payload_idx;
    zT_302 = (unsigned int)zT_301;
    zT_303 = zT_300[zT_302];
    pp = zT_303;
    pp = zT_303;
    pp = zT_303;
    zT_304 = arr.elem;
    zT_305 = pp.base;
    zT_306 = zT_304 == zT_305;
    if (zT_306) goto z_bb_106; else goto z_bb_107;
    z_bb_105:
    zT_308 = src.kind;
    zT_311 = zT_33EF6BFB_TypeKind_slice_type;
    zT_312 = zT_308 == zT_311;
    if (zT_312) goto z_bb_108; else goto z_bb_109;
    z_bb_106:
    zT_307 = zT_0FB7FB13_CoercionKind_array_to_many_ptr;
    return zT_307;
    z_bb_107:
    goto z_bb_105;
    z_bb_108:
    zT_314 = tgt.kind;
    zT_317 = zT_33EF6BFB_TypeKind_many_ptr_type;
    zT_318 = zT_314 == zT_317;
    zT_313 = zT_318;
    goto z_bb_110;
    z_bb_109:
    zT_313 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_313) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_320 = reg->slice_items;
    zT_321 = src.payload_idx;
    zT_322 = (unsigned int)zT_321;
    zT_323 = zT_320[zT_322];
    sl = zT_323;
    sl = zT_323;
    sl = zT_323;
    zT_325 = reg->ptr_items;
    zT_326 = tgt.payload_idx;
    zT_327 = (unsigned int)zT_326;
    zT_328 = zT_325[zT_327];
    pp = zT_328;
    pp = zT_328;
    pp = zT_328;
    zT_329 = sl.elem;
    zT_330 = pp.base;
    zT_331 = zT_329 == zT_330;
    if (zT_331) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    zT_333 = src.kind;
    zT_336 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_337 = zT_333 == zT_336;
    if (zT_337) goto z_bb_115; else goto z_bb_116;
    z_bb_113:
    zT_332 = zT_0FB7FB13_CoercionKind_slice_to_many_ptr;
    return zT_332;
    z_bb_114:
    goto z_bb_112;
    z_bb_115:
    zT_339 = tgt.kind;
    zT_342 = zT_33EF6BFB_TypeKind_optional_type;
    zT_343 = zT_339 == zT_342;
    zT_338 = zT_343;
    goto z_bb_117;
    z_bb_116:
    zT_338 = 0;
    goto z_bb_117;
    z_bb_117:
    if (zT_338) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_345 = reg->opt_items;
    zT_346 = tgt.payload_idx;
    zT_347 = (unsigned int)zT_346;
    zT_348 = zT_345[zT_347];
    opt2 = zT_348;
    opt2 = zT_348;
    opt2 = zT_348;
    zT_350 = reg->types_items;
    zT_351 = opt2.payload;
    zT_352 = (unsigned int)zT_351;
    zT_353 = zT_350[zT_352];
    opt_ty = zT_353;
    opt_ty = zT_353;
    opt_ty = zT_353;
    zT_354 = opt_ty.kind;
    zT_357 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_358 = zT_354 == zT_357;
    if (zT_358) goto z_bb_120; else goto z_bb_121;
    z_bb_119:
    zT_365 = 8;
    zT_366 = source == zT_365;
    if (zT_366) goto z_bb_124; else goto z_bb_125;
    z_bb_120:
    zT_359 = reg;
    zT_360 = source;
    zT_362 = opt2.payload;
    zT_361 = zT_362;
    zT_363 = zF_683AEB7F_typeRegistryIsAssig(zT_359, zT_360, zT_361);
    if (zT_363) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_364 = zT_0FB7FB13_CoercionKind_ptr_to_optional_ptr;
    return zT_364;
    z_bb_123:
    goto z_bb_121;
    z_bb_124:
    zT_368 = 14;
    zT_369 = target == zT_368;
    zT_367 = zT_369;
    goto z_bb_126;
    z_bb_125:
    zT_367 = 0;
    goto z_bb_126;
    z_bb_126:
    if (zT_367) goto z_bb_128; else goto z_bb_127;
    z_bb_127:
    zT_371 = 14;
    zT_372 = source == zT_371;
    if (zT_372) goto z_bb_130; else goto z_bb_131;
    z_bb_128:
    zT_370 = 1;
    goto z_bb_129;
    z_bb_129:
    if (zT_370) goto z_bb_133; else goto z_bb_134;
    z_bb_130:
    zT_374 = 8;
    zT_375 = target == zT_374;
    zT_373 = zT_375;
    goto z_bb_132;
    z_bb_131:
    zT_373 = 0;
    goto z_bb_132;
    z_bb_132:
    zT_370 = zT_373;
    goto z_bb_129;
    z_bb_133:
    zT_376 = zT_0FB7FB13_CoercionKind_none;
    return zT_376;
    z_bb_134:
    zT_377 = src.kind;
    zT_380 = zT_33EF6BFB_TypeKind_ptr_type;
    zT_381 = zT_377 == zT_380;
    if (zT_381) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_383 = tgt.kind;
    zT_386 = zT_33EF6BFB_TypeKind_slice_type;
    zT_387 = zT_383 == zT_386;
    zT_382 = zT_387;
    goto z_bb_137;
    z_bb_136:
    zT_382 = 0;
    goto z_bb_137;
    z_bb_137:
    if (zT_382) goto z_bb_138; else goto z_bb_139;
    z_bb_138:
    zT_389 = reg->ptr_items;
    zT_390 = src.payload_idx;
    zT_391 = (unsigned int)zT_390;
    zT_392 = zT_389[zT_391];
    sp2 = zT_392;
    sp2 = zT_392;
    sp2 = zT_392;
    zT_394 = reg->slice_items;
    zT_395 = tgt.payload_idx;
    zT_396 = (unsigned int)zT_395;
    zT_397 = zT_394[zT_396];
    ts2 = zT_397;
    ts2 = zT_397;
    ts2 = zT_397;
    zT_399 = "CLS:p";
    zT_401 = 5;
    zT_400.ptr = zT_399;
    zT_400.len = zT_401;
    clsb = zT_400;
    clsb = zT_400;
    clsb = zT_400;
    zT_402 = clsb;
    zF_48AC7B3A_markerWrite(zT_402);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_404[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb2[_i] = zT_404[_i];
        _i++;
    }
}
    zT_408 = sp2.base;
    zT_406 = zT_408;
    zT_409 = (unsigned char*)clsb2;
    zT_410 = 10;
    zT_411 = 0;
    zT_412 = zT_409 + zT_411;
    zT_413 = zT_410 - zT_411;
    zT_414.ptr = zT_412;
    zT_414.len = zT_413;
    zT_407 = zT_414;
    zT_415 = zF_A7504564_itoa(zT_406, zT_407);
    clsb2l = zT_415;
    clsb2l = zT_415;
    clsb2l = zT_415;
    zT_417 = 9;
    zT_418 = (unsigned int)clsb2l;
    zT_419 = zT_417 - zT_418;
    clsb2s = zT_419;
    clsb2s = zT_419;
    clsb2s = zT_419;
    zT_421 = (unsigned char*)clsb2;
    zT_423 = 9;
    zT_424 = zT_421 + clsb2s;
    zT_425 = zT_423 - clsb2s;
    zT_426.ptr = zT_424;
    zT_426.len = zT_425;
    zT_420 = zT_426;
    zF_48AC7B3A_markerWrite(zT_420);
    zT_428 = "e";
    zT_430 = 1;
    zT_429.ptr = zT_428;
    zT_429.len = zT_430;
    clse = zT_429;
    clse = zT_429;
    clse = zT_429;
    zT_431 = clse;
    zF_48AC7B3A_markerWrite(zT_431);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_433[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb3[_i] = zT_433[_i];
        _i++;
    }
}
    zT_437 = ts2.elem;
    zT_435 = zT_437;
    zT_438 = (unsigned char*)clsb3;
    zT_439 = 10;
    zT_440 = 0;
    zT_441 = zT_438 + zT_440;
    zT_442 = zT_439 - zT_440;
    zT_443.ptr = zT_441;
    zT_443.len = zT_442;
    zT_436 = zT_443;
    zT_444 = zF_A7504564_itoa(zT_435, zT_436);
    clsb3l = zT_444;
    clsb3l = zT_444;
    clsb3l = zT_444;
    zT_446 = 9;
    zT_447 = (unsigned int)clsb3l;
    zT_448 = zT_446 - zT_447;
    clsb3s = zT_448;
    clsb3s = zT_448;
    clsb3s = zT_448;
    zT_450 = (unsigned char*)clsb3;
    zT_452 = 9;
    zT_453 = zT_450 + clsb3s;
    zT_454 = zT_452 - clsb3s;
    zT_455.ptr = zT_453;
    zT_455.len = zT_454;
    zT_449 = zT_455;
    zF_48AC7B3A_markerWrite(zT_449);
    zT_457 = "\n";
    zT_459 = 1;
    zT_458.ptr = zT_457;
    zT_458.len = zT_459;
    clsnl = zT_458;
    clsnl = zT_458;
    clsnl = zT_458;
    zT_460 = clsnl;
    zF_48AC7B3A_markerWrite(zT_460);
    zT_461 = sp2.base;
    zT_462 = ts2.elem;
    zT_463 = zT_461 == zT_462;
    if (zT_463) goto z_bb_140; else goto z_bb_141;
    z_bb_139:
    zT_500 = zT_0FB7FB13_CoercionKind_none;
    return zT_500;
    z_bb_140:
    zT_464 = zT_0FB7FB13_CoercionKind_string_to_slice;
    return zT_464;
    z_bb_141:
    zT_465 = sp2.base;
    zT_466 = 14;
    zT_467 = zT_465 == zT_466;
    if (zT_467) goto z_bb_142; else goto z_bb_143;
    z_bb_142:
    zT_469 = ts2.elem;
    zT_470 = 8;
    zT_471 = zT_469 == zT_470;
    zT_468 = zT_471;
    goto z_bb_144;
    z_bb_143:
    zT_468 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_468) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_472 = zT_0FB7FB13_CoercionKind_string_to_slice;
    return zT_472;
    z_bb_146:
    zT_473 = sp2.base;
    zT_474 = 8;
    zT_475 = zT_473 == zT_474;
    if (zT_475) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_477 = ts2.elem;
    zT_478 = 14;
    zT_479 = zT_477 == zT_478;
    zT_476 = zT_479;
    goto z_bb_149;
    z_bb_148:
    zT_476 = 0;
    goto z_bb_149;
    z_bb_149:
    if (zT_476) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    zT_480 = zT_0FB7FB13_CoercionKind_string_to_slice;
    return zT_480;
    z_bb_151:
    zT_482 = reg->types_items;
    zT_483 = sp2.base;
    zT_484 = (unsigned int)zT_483;
    zT_485 = zT_482[zT_484];
    src_pointee = zT_485;
    src_pointee = zT_485;
    src_pointee = zT_485;
    zT_486 = src_pointee.kind;
    zT_489 = zT_33EF6BFB_TypeKind_array_type;
    zT_490 = zT_486 == zT_489;
    if (zT_490) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_492 = reg->array_items;
    zT_493 = src_pointee.payload_idx;
    zT_494 = (unsigned int)zT_493;
    zT_495 = zT_492[zT_494];
    arr = zT_495;
    arr = zT_495;
    arr = zT_495;
    zT_496 = arr.elem;
    zT_497 = ts2.elem;
    zT_498 = zT_496 == zT_497;
    if (zT_498) goto z_bb_154; else goto z_bb_155;
    z_bb_153:
    goto z_bb_139;
    z_bb_154:
    zT_499 = zT_0FB7FB13_CoercionKind_array_to_slice;
    return zT_499;
    z_bb_155:
    goto z_bb_153;
}

/* EOF */
