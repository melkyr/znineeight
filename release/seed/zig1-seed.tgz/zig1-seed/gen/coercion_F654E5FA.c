#include "coercion_F654E5FA.h"
zT_66E7D2EF_CoercionTable zG_66E7D2EF_CoercionTable;
zT_0FB7FB13_CoercionKind zG_0FB7FB13_CoercionKind;
/* coercionTableEnsureCapacity */
void zF_E837F929_coercionTableEnsure(zT_66E7D2EF_CoercionTable* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    zT_9CDC9863_CoercionEntry* zT_26;
    unsigned int zT_28;
    zT_7534F824_Opt_223 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_65F39959_EU_322 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    zT_9CDC9863_CoercionEntry* zT_49;
    zT_9CDC9863_CoercionEntry* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_9CDC9863_CoercionEntry* zT_53;
    unsigned int zT_54;
    zT_5B0DCA45_Slice_zT_9CDC9863_C zT_55;
    zT_9CDC9863_CoercionEntry* zT_56;
    unsigned int zT_57;
    unsigned int zT_62;
    unsigned int nc;
    zT_7534F824_Opt_223 grown;
    unsigned char* raw;
    zT_9CDC9863_CoercionEntry* new_items;
    zT_9CDC9863_CoercionEntry item;
    unsigned int i;
    zT_2 = self->entries_cap;
    if ((int)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->entries_cap;
    zT_6 = 2;
    if ((int)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->entries_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->entries_cap;
    zT_17 = 0;
    if ((int)(zT_16 > (unsigned int)zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = self->entries_alloc;
    zT_26 = self->entries_items;
    zT_28 = self->entries_cap;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), (unsigned int)(zT_28 * (unsigned int)(12)), (unsigned int)(nc * (unsigned int)(12)), (unsigned int)(4));
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_37 = self->entries_alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(12) * nc), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->entries_cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_46 = zT_44.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    zT_49 = (zT_9CDC9863_CoercionEntry*)raw;
    new_items = zT_49;
    zT_50 = self->entries_items;
    zT_51 = self->entries_len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_62 = i + (unsigned int)(1);
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->entries_items = new_items;
    self->entries_cap = nc;
    return;
}

/* coercionTableInit */
zT_66E7D2EF_CoercionTable zF_26B6D809_coercionTableInit(zT_3E40CD83_Sand* alloc) {
    zT_66E7D2EF_CoercionTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_21D3708C_U32ToU32Map zT_6 = {0};
    zT_2 = 0;
    zT_1.entries_items = (zT_9CDC9863_CoercionEntry*)zT_2;
    zT_3 = 0;
    zT_1.entries_len = zT_3;
    zT_4 = 0;
    zT_1.entries_cap = zT_4;
    zT_1.entries_alloc = alloc;
    zT_5 = alloc;
    zT_6 = zF_58BDA2DE_u32ToU32MapInit(zT_5);
    zT_1.index = zT_6;
    return zT_1;
}

/* coercionTableAdd */
void zF_D21AE60A_coercionTableAdd(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx, zT_0FB7FB13_CoercionKind kind, unsigned int target_type) {
    zT_9CDC9863_CoercionEntry zT_5;
    zT_21D3708C_U32ToU32Map* zT_7;
    unsigned int zT_8;
    zT_BAEE192E_Opt_10 zT_10 = {0};
    unsigned char zT_11;
    zT_9CDC9863_CoercionEntry* zT_13;
    unsigned int zT_14;
    zT_66E7D2EF_CoercionTable* zT_15;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_9CDC9863_CoercionEntry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    zT_21D3708C_U32ToU32Map* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_9CDC9863_CoercionEntry entry;
    zT_BAEE192E_Opt_10 existing;
    unsigned int idx;
    zT_5.node_idx = node_idx;
    zT_5.kind = kind;
    zT_5.target_type = target_type;
    entry = zT_5;
    zT_7 = &self->index;
    zT_8 = node_idx;
    zT_10 = zF_F3EE5998_u32ToU32MapGet(zT_7, zT_8);
    existing = zT_10;
    zT_11 = existing.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = existing.value;
    zT_13 = self->entries_items;
    zT_14 = (unsigned int)idx;
    zT_13[zT_14] = entry;
    return;
    z_bb_2:
    zT_15 = self;
    zT_17 = self->entries_len;
    zT_18 = 1;
    zF_E837F929_coercionTableEnsure(zT_15, (unsigned int)(zT_17 + zT_18));
    zT_21 = self->entries_len;
    zT_22 = (unsigned int)zT_21;
    idx = zT_22;
    zT_23 = self->entries_items;
    zT_24 = (unsigned int)idx;
    zT_23[zT_24] = entry;
    zT_25 = self->entries_len;
    zT_26 = 1;
    self->entries_len = (unsigned int)(zT_25 + (unsigned int)((unsigned int)zT_26));
    zT_29 = &self->index;
    zT_30 = node_idx;
    zT_31 = idx;
    zF_26476265_u32ToU32MapPut(zT_29, zT_30, zT_31);
    return;
}

/* coercionTableGet */
zT_4FBDE499_Opt_185 zF_46B66789_coercionTableGet(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    zT_9CDC9863_CoercionEntry* zT_9;
    unsigned int zT_10;
    zT_9CDC9863_CoercionEntry zT_11;
    zT_4FBDE499_Opt_185 zT_12;
    zT_4FBDE499_Opt_185 zT_13 = {0};
    zT_BAEE192E_Opt_10 entry_idx;
    unsigned int idx;
    zT_3 = &self->index;
    zT_4 = node_idx;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    entry_idx = zT_6;
    zT_7 = entry_idx.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = entry_idx.value;
    zT_9 = self->entries_items;
    zT_10 = (unsigned int)idx;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
    z_bb_2:
    zT_13.has_value = 0;
    return zT_13;
}

/* classifyCoercion */
zT_0FB7FB13_CoercionKind zF_713658BF_classifyCoercion(zT_338B7C76_TypeRegistry* reg, unsigned int source, unsigned int target) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    int zT_18;
    zT_338B7C76_TypeRegistry* zT_19;
    unsigned int zT_20;
    int zT_21 = 0;
    zT_338B7C76_TypeRegistry* zT_23;
    unsigned int zT_24;
    int zT_25 = 0;
    int zT_26;
    zT_338B7C76_TypeRegistry* zT_27;
    unsigned int zT_28;
    int zT_29 = 0;
    int zT_30;
    zT_338B7C76_TypeRegistry* zT_33;
    unsigned int zT_34;
    int zT_35 = 0;
    zT_338B7C76_TypeRegistry* zT_36;
    unsigned int zT_37;
    int zT_38 = 0;
    int zT_40;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    unsigned char zT_43 = 0;
    zT_338B7C76_TypeRegistry* zT_44;
    unsigned int zT_45;
    unsigned char zT_46 = 0;
    int zT_51;
    zT_33EF6BFB_TypeKind zT_55;
    char* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    unsigned int zT_63;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_64;
    unsigned int zT_65;
    zT_338B7C76_TypeRegistry* zT_66;
    unsigned int zT_67;
    int zT_68 = 0;
    zT_33EF6BFB_TypeKind zT_70;
    zT_33EF6BFB_TypeKind zT_76;
    zT_33EF6BFB_TypeKind zT_82;
    zT_0B10E8E9_OptionalPayload* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_0B10E8E9_OptionalPayload zT_91;
    zT_338B7C76_TypeRegistry* zT_92;
    unsigned int zT_93;
    unsigned int zT_94;
    int zT_96 = 0;
    zT_33EF6BFB_TypeKind zT_98;
    zT_33EF6BFB_TypeKind zT_104;
    zT_42C2D6BF_EUPayload* zT_110;
    unsigned int zT_111;
    unsigned int zT_112;
    zT_42C2D6BF_EUPayload zT_113;
    zT_338B7C76_TypeRegistry* zT_114;
    unsigned int zT_115;
    unsigned int zT_116;
    int zT_118 = 0;
    zT_33EF6BFB_TypeKind zT_120;
    int zT_125;
    zT_33EF6BFB_TypeKind zT_126;
    zT_33EF6BFB_TypeKind zT_132;
    int zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_112BF819_PtrPayload* zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    zT_112BF819_PtrPayload zT_147;
    zT_112BF819_PtrPayload* zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    zT_112BF819_PtrPayload zT_152;
    unsigned char zT_154;
    unsigned char zT_155;
    int zT_160 = 0;
    unsigned int zT_161;
    int zT_164;
    unsigned int zT_166;
    int zT_169;
    unsigned char zT_171;
    int zT_176;
    unsigned char zT_177;
    unsigned int zT_182;
    unsigned int zT_183;
    int zT_185;
    zT_33EF6BFB_TypeKind zT_187;
    int zT_192;
    zT_33EF6BFB_TypeKind zT_193;
    unsigned char zT_199;
    unsigned char zT_200;
    int zT_205 = 0;
    unsigned char zT_206;
    int zT_211;
    unsigned char zT_212;
    zT_0BB2A741_SlicePayload* zT_218;
    unsigned int zT_219;
    unsigned int zT_220;
    zT_0BB2A741_SlicePayload zT_221;
    zT_0BB2A741_SlicePayload* zT_223;
    unsigned int zT_224;
    unsigned int zT_225;
    zT_0BB2A741_SlicePayload zT_226;
    unsigned int zT_227;
    unsigned int zT_228;
    int zT_230;
    zT_33EF6BFB_TypeKind zT_232;
    int zT_237;
    zT_33EF6BFB_TypeKind zT_238;
    unsigned char zT_244;
    unsigned char zT_245;
    int zT_250 = 0;
    unsigned char zT_251;
    int zT_256;
    unsigned char zT_257;
    zT_112BF819_PtrPayload* zT_263;
    unsigned int zT_264;
    unsigned int zT_265;
    zT_112BF819_PtrPayload zT_266;
    zT_112BF819_PtrPayload* zT_268;
    unsigned int zT_269;
    unsigned int zT_270;
    zT_112BF819_PtrPayload zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    int zT_275;
    zT_33EF6BFB_TypeKind zT_277;
    int zT_282;
    zT_33EF6BFB_TypeKind zT_283;
    unsigned char zT_289;
    unsigned char zT_290;
    int zT_295 = 0;
    zT_E834303C_ArrayPayload* zT_297;
    unsigned int zT_298;
    unsigned int zT_299;
    zT_E834303C_ArrayPayload zT_300;
    zT_0BB2A741_SlicePayload* zT_302;
    unsigned int zT_303;
    unsigned int zT_304;
    zT_0BB2A741_SlicePayload zT_305;
    unsigned int zT_306;
    unsigned int zT_307;
    int zT_309;
    unsigned char zT_311;
    int zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    int zT_320;
    zT_33EF6BFB_TypeKind zT_322;
    int zT_327;
    zT_33EF6BFB_TypeKind zT_328;
    unsigned char zT_334;
    unsigned char zT_335;
    int zT_340 = 0;
    zT_E834303C_ArrayPayload* zT_342;
    unsigned int zT_343;
    unsigned int zT_344;
    zT_E834303C_ArrayPayload zT_345;
    zT_112BF819_PtrPayload* zT_347;
    unsigned int zT_348;
    unsigned int zT_349;
    zT_112BF819_PtrPayload zT_350;
    unsigned int zT_351;
    unsigned int zT_352;
    int zT_354;
    zT_33EF6BFB_TypeKind zT_356;
    int zT_361;
    zT_33EF6BFB_TypeKind zT_362;
    zT_E834303C_ArrayPayload* zT_368;
    unsigned int zT_369;
    unsigned int zT_370;
    zT_E834303C_ArrayPayload zT_371;
    zT_E834303C_ArrayPayload* zT_373;
    unsigned int zT_374;
    unsigned int zT_375;
    zT_E834303C_ArrayPayload zT_376;
    unsigned int zT_377;
    unsigned int zT_378;
    int zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    zT_33EF6BFB_TypeKind zT_385;
    int zT_390;
    zT_33EF6BFB_TypeKind zT_391;
    unsigned char zT_397;
    unsigned char zT_398;
    int zT_403 = 0;
    zT_112BF819_PtrPayload* zT_405;
    unsigned int zT_406;
    unsigned int zT_407;
    zT_112BF819_PtrPayload zT_408;
    zT_112BF819_PtrPayload* zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    zT_112BF819_PtrPayload zT_413;
    zT_D155D06D_Type* zT_415;
    unsigned int zT_416;
    unsigned int zT_417;
    zT_D155D06D_Type zT_418;
    zT_33EF6BFB_TypeKind zT_419;
    zT_E834303C_ArrayPayload* zT_425;
    unsigned int zT_426;
    unsigned int zT_427;
    zT_E834303C_ArrayPayload zT_428;
    unsigned int zT_429;
    unsigned int zT_430;
    int zT_432;
    zT_33EF6BFB_TypeKind zT_434;
    int zT_439;
    zT_33EF6BFB_TypeKind zT_440;
    unsigned char zT_446;
    unsigned char zT_447;
    int zT_452 = 0;
    zT_0BB2A741_SlicePayload* zT_454;
    unsigned int zT_455;
    unsigned int zT_456;
    zT_0BB2A741_SlicePayload zT_457;
    zT_112BF819_PtrPayload* zT_459;
    unsigned int zT_460;
    unsigned int zT_461;
    zT_112BF819_PtrPayload zT_462;
    unsigned int zT_463;
    unsigned int zT_464;
    int zT_466;
    zT_33EF6BFB_TypeKind zT_468;
    int zT_473;
    zT_33EF6BFB_TypeKind zT_474;
    zT_0B10E8E9_OptionalPayload* zT_480;
    unsigned int zT_481;
    unsigned int zT_482;
    zT_0B10E8E9_OptionalPayload zT_483;
    zT_D155D06D_Type* zT_485;
    unsigned int zT_486;
    unsigned int zT_487;
    zT_D155D06D_Type zT_488;
    zT_33EF6BFB_TypeKind zT_489;
    zT_338B7C76_TypeRegistry* zT_494;
    unsigned int zT_495;
    unsigned int zT_496;
    int zT_498 = 0;
    int zT_502;
    int zT_505;
    int zT_508;
    zT_33EF6BFB_TypeKind zT_512;
    int zT_517;
    zT_33EF6BFB_TypeKind zT_518;
    unsigned char zT_524;
    unsigned char zT_525;
    int zT_530 = 0;
    zT_112BF819_PtrPayload* zT_532;
    unsigned int zT_533;
    unsigned int zT_534;
    zT_112BF819_PtrPayload zT_535;
    zT_0BB2A741_SlicePayload* zT_537;
    unsigned int zT_538;
    unsigned int zT_539;
    zT_0BB2A741_SlicePayload zT_540;
    char* zT_542;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_543;
    unsigned int zT_544;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_545;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_547;
    unsigned int zT_549;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_550;
    int zT_554;
    unsigned char* zT_555;
    unsigned int zT_556;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_557;
    unsigned int zT_558 = 0;
    unsigned int zT_562;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_563;
    unsigned char* zT_567;
    unsigned int zT_568;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_569;
    char* zT_571;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_572;
    unsigned int zT_573;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_574;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_576;
    unsigned int zT_578;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_579;
    int zT_583;
    unsigned char* zT_584;
    unsigned int zT_585;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_586;
    unsigned int zT_587 = 0;
    unsigned int zT_591;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_592;
    unsigned char* zT_596;
    unsigned int zT_597;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_598;
    char* zT_600;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_601;
    unsigned int zT_602;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_603;
    unsigned int zT_604;
    unsigned int zT_605;
    int zT_607;
    unsigned int zT_609;
    int zT_612;
    unsigned int zT_613;
    int zT_616;
    unsigned int zT_618;
    int zT_621;
    unsigned int zT_622;
    int zT_625;
    zT_D155D06D_Type* zT_628;
    unsigned int zT_629;
    unsigned int zT_630;
    zT_D155D06D_Type zT_631;
    zT_33EF6BFB_TypeKind zT_632;
    zT_E834303C_ArrayPayload* zT_638;
    unsigned int zT_639;
    unsigned int zT_640;
    zT_E834303C_ArrayPayload zT_641;
    unsigned int zT_642;
    unsigned int zT_643;
    int zT_645;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_8F083A69_Slice_zT_0B42B2F8_u ccn_m;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    int qok;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_E834303C_ArrayPayload arr;
    zT_0BB2A741_SlicePayload sl;
    zT_112BF819_PtrPayload pp;
    zT_E834303C_ArrayPayload s_arr;
    zT_E834303C_ArrayPayload t_arr;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload tp;
    zT_D155D06D_Type spo;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_D155D06D_Type opt_ty;
    zT_112BF819_PtrPayload sp2;
    zT_0BB2A741_SlicePayload ts2;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsb;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb2;
    unsigned int clsb2l;
    unsigned int clsb2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clse;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb3;
    unsigned int clsb3l;
    unsigned int clsb3s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsnl;
    zT_D155D06D_Type src_pointee;
    if ((int)(source == target)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_2:
    zT_6 = reg->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    zT_10 = reg->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    zT_13 = src.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = reg;
    zT_20 = target;
    zT_21 = zF_3087E0A5_typeRegistryIsNumer(zT_19, zT_20);
    zT_18 = zT_21;
    goto z_bb_5;
    z_bb_4:
    zT_18 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_18) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce);
    z_bb_7:
    zT_23 = reg;
    zT_24 = source;
    zT_25 = zF_3290E9C4_typeRegistryIsInteg(zT_23, zT_24);
    if (zT_25) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_27 = reg;
    zT_28 = target;
    zT_29 = zF_3290E9C4_typeRegistryIsInteg(zT_27, zT_28);
    zT_26 = zT_29;
    goto z_bb_10;
    z_bb_9:
    zT_26 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_26) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = source != (unsigned int)(19);
    goto z_bb_13;
    z_bb_12:
    zT_30 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_30) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_33 = reg;
    zT_34 = source;
    zT_35 = zF_B664AC19_typeRegistryIsUnsig(zT_33, zT_34);
    zT_36 = reg;
    zT_37 = target;
    zT_38 = zF_B664AC19_typeRegistryIsUnsig(zT_36, zT_37);
    if ((int)(zT_35 == zT_38)) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    if ((int)(source == (unsigned int)(15))) goto z_bb_21; else goto z_bb_22;
    z_bb_16:
    zT_41 = reg;
    zT_42 = source;
    zT_43 = zF_655972D5_typeRegistryIntWidt(zT_41, zT_42);
    zT_44 = reg;
    zT_45 = target;
    zT_46 = zF_655972D5_typeRegistryIntWidt(zT_44, zT_45);
    zT_40 = zT_43 < zT_46;
    goto z_bb_18;
    z_bb_17:
    zT_40 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_40) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_widen);
    z_bb_20:
    goto z_bb_15;
    z_bb_21:
    zT_51 = target == (unsigned int)(16);
    goto z_bb_23;
    z_bb_22:
    zT_51 = 0;
    goto z_bb_23;
    z_bb_23:
    if (zT_51) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_float_widen);
    z_bb_25:
    zT_55 = src.kind;
    if ((int)(zT_55 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_61 = "CC:nul";
    zT_63 = 6;
    zT_62.ptr = zT_61;
    zT_62.len = zT_63;
    ccn_m = zT_62;
    zT_64 = ccn_m;
    zT_65 = target;
    zF_C914CB83_markerWriteInt(zT_64, zT_65);
    zT_66 = reg;
    zT_67 = target;
    zT_68 = zF_AD61DB1B_typeRegistryIsPoint(zT_66, zT_67);
    if (zT_68) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_82 = tgt.kind;
    if ((int)(zT_82 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_34; else goto z_bb_35;
    z_bb_28:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_29:
    zT_70 = tgt.kind;
    if ((int)(zT_70 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional_null);
    z_bb_31:
    zT_76 = tgt.kind;
    if ((int)(zT_76 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_33:
    goto z_bb_27;
    z_bb_34:
    zT_88 = reg->opt_items;
    zT_89 = tgt.payload_idx;
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_88[zT_90];
    opt = zT_91;
    zT_92 = reg;
    zT_93 = source;
    zT_94 = opt.payload;
    zT_96 = zF_683AEB7F_typeRegistryIsAssig(zT_92, zT_93, zT_94);
    if (zT_96) goto z_bb_36; else goto z_bb_37;
    z_bb_35:
    zT_104 = tgt.kind;
    if ((int)(zT_104 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_40; else goto z_bb_41;
    z_bb_36:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional);
    z_bb_37:
    zT_98 = src.kind;
    if ((int)(zT_98 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_39:
    goto z_bb_35;
    z_bb_40:
    zT_110 = reg->eu_items;
    zT_111 = tgt.payload_idx;
    zT_112 = (unsigned int)zT_111;
    zT_113 = zT_110[zT_112];
    eu = zT_113;
    zT_114 = reg;
    zT_115 = source;
    zT_116 = eu.payload;
    zT_118 = zF_683AEB7F_typeRegistryIsAssig(zT_114, zT_115, zT_116);
    if (zT_118) goto z_bb_42; else goto z_bb_43;
    z_bb_41:
    zT_120 = src.kind;
    if ((int)(zT_120 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_44; else goto z_bb_45;
    z_bb_42:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_error_success);
    z_bb_43:
    goto z_bb_41;
    z_bb_44:
    zT_126 = tgt.kind;
    zT_125 = zT_126 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_46;
    z_bb_45:
    zT_125 = 0;
    goto z_bb_46;
    z_bb_46:
    if (zT_125) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_error_err);
    z_bb_48:
    zT_132 = src.kind;
    if ((int)(zT_132 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_138 = tgt.kind;
    zT_137 = zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_51;
    z_bb_50:
    zT_137 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_137) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_144 = reg->ptr_items;
    zT_145 = tgt.payload_idx;
    zT_146 = (unsigned int)zT_145;
    zT_147 = zT_144[zT_146];
    tgt_pp = zT_147;
    zT_149 = reg->ptr_items;
    zT_150 = src.payload_idx;
    zT_151 = (unsigned int)zT_150;
    zT_152 = zT_149[zT_151];
    src_pp = zT_152;
    zT_154 = src.flags;
    zT_155 = tgt.flags;
    zT_160 = zF_08C13644_pointerQualifiersMo(zT_154, zT_155, (unsigned char)(2));
    qok = zT_160;
    zT_161 = tgt_pp.base;
    if ((int)(zT_161 == (unsigned int)(1))) goto z_bb_54; else goto z_bb_55;
    z_bb_53:
    zT_187 = tgt.kind;
    if ((int)(zT_187 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_74; else goto z_bb_75;
    z_bb_54:
    zT_164 = qok;
    goto z_bb_56;
    z_bb_55:
    zT_164 = 0;
    goto z_bb_56;
    z_bb_56:
    if (zT_164) goto z_bb_57; else goto z_bb_58;
    z_bb_57:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_58:
    zT_166 = src_pp.base;
    if ((int)(zT_166 == (unsigned int)(1))) goto z_bb_59; else goto z_bb_60;
    z_bb_59:
    zT_169 = qok;
    goto z_bb_61;
    z_bb_60:
    zT_169 = 0;
    goto z_bb_61;
    z_bb_61:
    if (zT_169) goto z_bb_62; else goto z_bb_63;
    z_bb_62:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_63:
    zT_171 = tgt.flags;
    if ((int)((unsigned char)(zT_171 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_64; else goto z_bb_65;
    z_bb_64:
    zT_177 = src.flags;
    zT_176 = (unsigned char)(zT_177 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_66;
    z_bb_65:
    zT_176 = 0;
    goto z_bb_66;
    z_bb_66:
    if (zT_176) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_182 = src_pp.base;
    zT_183 = tgt_pp.base;
    if ((int)(zT_182 == zT_183)) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    goto z_bb_53;
    z_bb_69:
    zT_185 = qok;
    goto z_bb_71;
    z_bb_70:
    zT_185 = 0;
    goto z_bb_71;
    z_bb_71:
    if (zT_185) goto z_bb_72; else goto z_bb_73;
    z_bb_72:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_73:
    goto z_bb_68;
    z_bb_74:
    zT_193 = src.kind;
    zT_192 = zT_193 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_76;
    z_bb_75:
    zT_192 = 0;
    goto z_bb_76;
    z_bb_76:
    if (zT_192) goto z_bb_77; else goto z_bb_78;
    z_bb_77:
    zT_199 = src.flags;
    zT_200 = tgt.flags;
    zT_205 = zF_08C13644_pointerQualifiersMo(zT_199, zT_200, (unsigned char)(2));
    qok = zT_205;
    zT_206 = tgt.flags;
    if ((int)((unsigned char)(zT_206 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_79; else goto z_bb_80;
    z_bb_78:
    zT_232 = tgt.kind;
    if ((int)(zT_232 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_89; else goto z_bb_90;
    z_bb_79:
    zT_212 = src.flags;
    zT_211 = (unsigned char)(zT_212 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_81;
    z_bb_80:
    zT_211 = 0;
    goto z_bb_81;
    z_bb_81:
    if (zT_211) goto z_bb_82; else goto z_bb_83;
    z_bb_82:
    zT_218 = reg->slice_items;
    zT_219 = src.payload_idx;
    zT_220 = (unsigned int)zT_219;
    zT_221 = zT_218[zT_220];
    s_sl = zT_221;
    zT_223 = reg->slice_items;
    zT_224 = tgt.payload_idx;
    zT_225 = (unsigned int)zT_224;
    zT_226 = zT_223[zT_225];
    t_sl = zT_226;
    zT_227 = s_sl.elem;
    zT_228 = t_sl.elem;
    if ((int)(zT_227 == zT_228)) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    goto z_bb_78;
    z_bb_84:
    zT_230 = qok;
    goto z_bb_86;
    z_bb_85:
    zT_230 = 0;
    goto z_bb_86;
    z_bb_86:
    if (zT_230) goto z_bb_87; else goto z_bb_88;
    z_bb_87:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_88:
    goto z_bb_83;
    z_bb_89:
    zT_238 = src.kind;
    zT_237 = zT_238 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_91;
    z_bb_90:
    zT_237 = 0;
    goto z_bb_91;
    z_bb_91:
    if (zT_237) goto z_bb_92; else goto z_bb_93;
    z_bb_92:
    zT_244 = src.flags;
    zT_245 = tgt.flags;
    zT_250 = zF_08C13644_pointerQualifiersMo(zT_244, zT_245, (unsigned char)(2));
    qok = zT_250;
    zT_251 = tgt.flags;
    if ((int)((unsigned char)(zT_251 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_94; else goto z_bb_95;
    z_bb_93:
    zT_277 = src.kind;
    if ((int)(zT_277 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_104; else goto z_bb_105;
    z_bb_94:
    zT_257 = src.flags;
    zT_256 = (unsigned char)(zT_257 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_96;
    z_bb_95:
    zT_256 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_256) goto z_bb_97; else goto z_bb_98;
    z_bb_97:
    zT_263 = reg->ptr_items;
    zT_264 = src.payload_idx;
    zT_265 = (unsigned int)zT_264;
    zT_266 = zT_263[zT_265];
    s_pp = zT_266;
    zT_268 = reg->ptr_items;
    zT_269 = tgt.payload_idx;
    zT_270 = (unsigned int)zT_269;
    zT_271 = zT_268[zT_270];
    t_pp = zT_271;
    zT_272 = s_pp.base;
    zT_273 = t_pp.base;
    if ((int)(zT_272 == zT_273)) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    goto z_bb_93;
    z_bb_99:
    zT_275 = qok;
    goto z_bb_101;
    z_bb_100:
    zT_275 = 0;
    goto z_bb_101;
    z_bb_101:
    if (zT_275) goto z_bb_102; else goto z_bb_103;
    z_bb_102:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_103:
    goto z_bb_98;
    z_bb_104:
    zT_283 = tgt.kind;
    zT_282 = zT_283 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_106;
    z_bb_105:
    zT_282 = 0;
    goto z_bb_106;
    z_bb_106:
    if (zT_282) goto z_bb_107; else goto z_bb_108;
    z_bb_107:
    zT_289 = src.flags;
    zT_290 = tgt.flags;
    zT_295 = zF_08C13644_pointerQualifiersMo(zT_289, zT_290, (unsigned char)(2));
    qok = zT_295;
    zT_297 = reg->array_items;
    zT_298 = src.payload_idx;
    zT_299 = (unsigned int)zT_298;
    zT_300 = zT_297[zT_299];
    arr = zT_300;
    zT_302 = reg->slice_items;
    zT_303 = tgt.payload_idx;
    zT_304 = (unsigned int)zT_303;
    zT_305 = zT_302[zT_304];
    sl = zT_305;
    zT_306 = arr.elem;
    zT_307 = sl.elem;
    if ((int)(zT_306 == zT_307)) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    zT_322 = src.kind;
    if ((int)(zT_322 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_122; else goto z_bb_123;
    z_bb_109:
    zT_309 = qok;
    goto z_bb_111;
    z_bb_110:
    zT_309 = 0;
    goto z_bb_111;
    z_bb_111:
    if (zT_309) goto z_bb_112; else goto z_bb_113;
    z_bb_112:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_113:
    zT_311 = tgt.flags;
    if ((int)((unsigned char)(zT_311 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_114; else goto z_bb_115;
    z_bb_114:
    zT_317 = arr.elem;
    zT_318 = sl.elem;
    zT_316 = zT_317 == zT_318;
    goto z_bb_116;
    z_bb_115:
    zT_316 = 0;
    goto z_bb_116;
    z_bb_116:
    if (zT_316) goto z_bb_117; else goto z_bb_118;
    z_bb_117:
    zT_320 = qok;
    goto z_bb_119;
    z_bb_118:
    zT_320 = 0;
    goto z_bb_119;
    z_bb_119:
    if (zT_320) goto z_bb_120; else goto z_bb_121;
    z_bb_120:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_121:
    goto z_bb_108;
    z_bb_122:
    zT_328 = tgt.kind;
    zT_327 = zT_328 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_124;
    z_bb_123:
    zT_327 = 0;
    goto z_bb_124;
    z_bb_124:
    if (zT_327) goto z_bb_125; else goto z_bb_126;
    z_bb_125:
    zT_334 = src.flags;
    zT_335 = tgt.flags;
    zT_340 = zF_08C13644_pointerQualifiersMo(zT_334, zT_335, (unsigned char)(2));
    qok = zT_340;
    zT_342 = reg->array_items;
    zT_343 = src.payload_idx;
    zT_344 = (unsigned int)zT_343;
    zT_345 = zT_342[zT_344];
    arr = zT_345;
    zT_347 = reg->ptr_items;
    zT_348 = tgt.payload_idx;
    zT_349 = (unsigned int)zT_348;
    zT_350 = zT_347[zT_349];
    pp = zT_350;
    zT_351 = arr.elem;
    zT_352 = pp.base;
    if ((int)(zT_351 == zT_352)) goto z_bb_127; else goto z_bb_128;
    z_bb_126:
    zT_356 = src.kind;
    if ((int)(zT_356 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_132; else goto z_bb_133;
    z_bb_127:
    zT_354 = qok;
    goto z_bb_129;
    z_bb_128:
    zT_354 = 0;
    goto z_bb_129;
    z_bb_129:
    if (zT_354) goto z_bb_130; else goto z_bb_131;
    z_bb_130:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_many_ptr);
    z_bb_131:
    goto z_bb_126;
    z_bb_132:
    zT_362 = tgt.kind;
    zT_361 = zT_362 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_134;
    z_bb_133:
    zT_361 = 0;
    goto z_bb_134;
    z_bb_134:
    if (zT_361) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_368 = reg->array_items;
    zT_369 = src.payload_idx;
    zT_370 = (unsigned int)zT_369;
    zT_371 = zT_368[zT_370];
    s_arr = zT_371;
    zT_373 = reg->array_items;
    zT_374 = tgt.payload_idx;
    zT_375 = (unsigned int)zT_374;
    zT_376 = zT_373[zT_375];
    t_arr = zT_376;
    zT_377 = s_arr.elem;
    zT_378 = t_arr.elem;
    if ((int)(zT_377 == zT_378)) goto z_bb_137; else goto z_bb_138;
    z_bb_136:
    zT_385 = src.kind;
    if ((int)(zT_385 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_142; else goto z_bb_143;
    z_bb_137:
    zT_381 = s_arr.length;
    zT_382 = t_arr.length;
    zT_380 = zT_381 == zT_382;
    goto z_bb_139;
    z_bb_138:
    zT_380 = 0;
    goto z_bb_139;
    z_bb_139:
    if (zT_380) goto z_bb_140; else goto z_bb_141;
    z_bb_140:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_141:
    goto z_bb_136;
    z_bb_142:
    zT_391 = tgt.kind;
    zT_390 = zT_391 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_144;
    z_bb_143:
    zT_390 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_390) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_397 = src.flags;
    zT_398 = tgt.flags;
    zT_403 = zF_08C13644_pointerQualifiersMo(zT_397, zT_398, (unsigned char)(2));
    qok = zT_403;
    zT_405 = reg->ptr_items;
    zT_406 = src.payload_idx;
    zT_407 = (unsigned int)zT_406;
    zT_408 = zT_405[zT_407];
    sp = zT_408;
    zT_410 = reg->ptr_items;
    zT_411 = tgt.payload_idx;
    zT_412 = (unsigned int)zT_411;
    zT_413 = zT_410[zT_412];
    tp = zT_413;
    zT_415 = reg->types_items;
    zT_416 = sp.base;
    zT_417 = (unsigned int)zT_416;
    zT_418 = zT_415[zT_417];
    spo = zT_418;
    zT_419 = spo.kind;
    if ((int)(zT_419 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_147; else goto z_bb_148;
    z_bb_146:
    zT_434 = src.kind;
    if ((int)(zT_434 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_154; else goto z_bb_155;
    z_bb_147:
    zT_425 = reg->array_items;
    zT_426 = spo.payload_idx;
    zT_427 = (unsigned int)zT_426;
    zT_428 = zT_425[zT_427];
    arr = zT_428;
    zT_429 = arr.elem;
    zT_430 = tp.base;
    if ((int)(zT_429 == zT_430)) goto z_bb_149; else goto z_bb_150;
    z_bb_148:
    goto z_bb_146;
    z_bb_149:
    zT_432 = qok;
    goto z_bb_151;
    z_bb_150:
    zT_432 = 0;
    goto z_bb_151;
    z_bb_151:
    if (zT_432) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_153:
    goto z_bb_148;
    z_bb_154:
    zT_440 = tgt.kind;
    zT_439 = zT_440 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_156;
    z_bb_155:
    zT_439 = 0;
    goto z_bb_156;
    z_bb_156:
    if (zT_439) goto z_bb_157; else goto z_bb_158;
    z_bb_157:
    zT_446 = src.flags;
    zT_447 = tgt.flags;
    zT_452 = zF_08C13644_pointerQualifiersMo(zT_446, zT_447, (unsigned char)(2));
    qok = zT_452;
    zT_454 = reg->slice_items;
    zT_455 = src.payload_idx;
    zT_456 = (unsigned int)zT_455;
    zT_457 = zT_454[zT_456];
    sl = zT_457;
    zT_459 = reg->ptr_items;
    zT_460 = tgt.payload_idx;
    zT_461 = (unsigned int)zT_460;
    zT_462 = zT_459[zT_461];
    pp = zT_462;
    zT_463 = sl.elem;
    zT_464 = pp.base;
    if ((int)(zT_463 == zT_464)) goto z_bb_159; else goto z_bb_160;
    z_bb_158:
    zT_468 = src.kind;
    if ((int)(zT_468 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_164; else goto z_bb_165;
    z_bb_159:
    zT_466 = qok;
    goto z_bb_161;
    z_bb_160:
    zT_466 = 0;
    goto z_bb_161;
    z_bb_161:
    if (zT_466) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_slice_to_many_ptr);
    z_bb_163:
    goto z_bb_158;
    z_bb_164:
    zT_474 = tgt.kind;
    zT_473 = zT_474 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_166;
    z_bb_165:
    zT_473 = 0;
    goto z_bb_166;
    z_bb_166:
    if (zT_473) goto z_bb_167; else goto z_bb_168;
    z_bb_167:
    zT_480 = reg->opt_items;
    zT_481 = tgt.payload_idx;
    zT_482 = (unsigned int)zT_481;
    zT_483 = zT_480[zT_482];
    opt2 = zT_483;
    zT_485 = reg->types_items;
    zT_486 = opt2.payload;
    zT_487 = (unsigned int)zT_486;
    zT_488 = zT_485[zT_487];
    opt_ty = zT_488;
    zT_489 = opt_ty.kind;
    if ((int)(zT_489 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_169; else goto z_bb_170;
    z_bb_168:
    if ((int)(source == (unsigned int)(8))) goto z_bb_173; else goto z_bb_174;
    z_bb_169:
    zT_494 = reg;
    zT_495 = source;
    zT_496 = opt2.payload;
    zT_498 = zF_683AEB7F_typeRegistryIsAssig(zT_494, zT_495, zT_496);
    if (zT_498) goto z_bb_171; else goto z_bb_172;
    z_bb_170:
    goto z_bb_168;
    z_bb_171:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_ptr_to_optional_ptr);
    z_bb_172:
    goto z_bb_170;
    z_bb_173:
    zT_502 = target == (unsigned int)(14);
    goto z_bb_175;
    z_bb_174:
    zT_502 = 0;
    goto z_bb_175;
    z_bb_175:
    if (zT_502) goto z_bb_177; else goto z_bb_176;
    z_bb_176:
    if ((int)(source == (unsigned int)(14))) goto z_bb_179; else goto z_bb_180;
    z_bb_177:
    zT_505 = 1;
    goto z_bb_178;
    z_bb_178:
    if (zT_505) goto z_bb_182; else goto z_bb_183;
    z_bb_179:
    zT_508 = target == (unsigned int)(8);
    goto z_bb_181;
    z_bb_180:
    zT_508 = 0;
    goto z_bb_181;
    z_bb_181:
    zT_505 = zT_508;
    goto z_bb_178;
    z_bb_182:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_183:
    zT_512 = src.kind;
    if ((int)(zT_512 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_184; else goto z_bb_185;
    z_bb_184:
    zT_518 = tgt.kind;
    zT_517 = zT_518 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_186;
    z_bb_185:
    zT_517 = 0;
    goto z_bb_186;
    z_bb_186:
    if (zT_517) goto z_bb_187; else goto z_bb_188;
    z_bb_187:
    zT_524 = src.flags;
    zT_525 = tgt.flags;
    zT_530 = zF_08C13644_pointerQualifiersMo(zT_524, zT_525, (unsigned char)(2));
    qok = zT_530;
    zT_532 = reg->ptr_items;
    zT_533 = src.payload_idx;
    zT_534 = (unsigned int)zT_533;
    zT_535 = zT_532[zT_534];
    sp2 = zT_535;
    zT_537 = reg->slice_items;
    zT_538 = tgt.payload_idx;
    zT_539 = (unsigned int)zT_538;
    zT_540 = zT_537[zT_539];
    ts2 = zT_540;
    zT_542 = "CLS:p";
    zT_544 = 5;
    zT_543.ptr = zT_542;
    zT_543.len = zT_544;
    clsb = zT_543;
    zT_545 = clsb;
    zF_48AC7B3A_markerWrite(zT_545);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_547[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb2[_i] = zT_547[_i];
        _i++;
    }
}
    zT_549 = sp2.base;
    zT_554 = 0;
    zT_555 = (unsigned char*)((unsigned char*)clsb2) + zT_554;
    zT_556 = (unsigned int)(10) - zT_554;
    zT_557.ptr = zT_555;
    zT_557.len = zT_556;
    zT_550 = zT_557;
    zT_558 = zF_A7504564_itoa(zT_549, zT_550);
    clsb2l = zT_558;
    zT_562 = (unsigned int)(9) - (unsigned int)((unsigned int)clsb2l);
    clsb2s = zT_562;
    zT_567 = (unsigned char*)((unsigned char*)clsb2) + clsb2s;
    zT_568 = (unsigned int)(9) - clsb2s;
    zT_569.ptr = zT_567;
    zT_569.len = zT_568;
    zT_563 = zT_569;
    zF_48AC7B3A_markerWrite(zT_563);
    zT_571 = "e";
    zT_573 = 1;
    zT_572.ptr = zT_571;
    zT_572.len = zT_573;
    clse = zT_572;
    zT_574 = clse;
    zF_48AC7B3A_markerWrite(zT_574);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_576[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb3[_i] = zT_576[_i];
        _i++;
    }
}
    zT_578 = ts2.elem;
    zT_583 = 0;
    zT_584 = (unsigned char*)((unsigned char*)clsb3) + zT_583;
    zT_585 = (unsigned int)(10) - zT_583;
    zT_586.ptr = zT_584;
    zT_586.len = zT_585;
    zT_579 = zT_586;
    zT_587 = zF_A7504564_itoa(zT_578, zT_579);
    clsb3l = zT_587;
    zT_591 = (unsigned int)(9) - (unsigned int)((unsigned int)clsb3l);
    clsb3s = zT_591;
    zT_596 = (unsigned char*)((unsigned char*)clsb3) + clsb3s;
    zT_597 = (unsigned int)(9) - clsb3s;
    zT_598.ptr = zT_596;
    zT_598.len = zT_597;
    zT_592 = zT_598;
    zF_48AC7B3A_markerWrite(zT_592);
    zT_600 = "\n";
    zT_602 = 1;
    zT_601.ptr = zT_600;
    zT_601.len = zT_602;
    clsnl = zT_601;
    zT_603 = clsnl;
    zF_48AC7B3A_markerWrite(zT_603);
    zT_604 = sp2.base;
    zT_605 = ts2.elem;
    if ((int)(zT_604 == zT_605)) goto z_bb_189; else goto z_bb_190;
    z_bb_188:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_189:
    zT_607 = qok;
    goto z_bb_191;
    z_bb_190:
    zT_607 = 0;
    goto z_bb_191;
    z_bb_191:
    if (zT_607) goto z_bb_192; else goto z_bb_193;
    z_bb_192:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_string_to_slice);
    z_bb_193:
    zT_609 = sp2.base;
    if ((int)(zT_609 == (unsigned int)(14))) goto z_bb_194; else goto z_bb_195;
    z_bb_194:
    zT_613 = ts2.elem;
    zT_612 = zT_613 == (unsigned int)(8);
    goto z_bb_196;
    z_bb_195:
    zT_612 = 0;
    goto z_bb_196;
    z_bb_196:
    if (zT_612) goto z_bb_197; else goto z_bb_198;
    z_bb_197:
    zT_616 = qok;
    goto z_bb_199;
    z_bb_198:
    zT_616 = 0;
    goto z_bb_199;
    z_bb_199:
    if (zT_616) goto z_bb_200; else goto z_bb_201;
    z_bb_200:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_string_to_slice);
    z_bb_201:
    zT_618 = sp2.base;
    if ((int)(zT_618 == (unsigned int)(8))) goto z_bb_202; else goto z_bb_203;
    z_bb_202:
    zT_622 = ts2.elem;
    zT_621 = zT_622 == (unsigned int)(14);
    goto z_bb_204;
    z_bb_203:
    zT_621 = 0;
    goto z_bb_204;
    z_bb_204:
    if (zT_621) goto z_bb_205; else goto z_bb_206;
    z_bb_205:
    zT_625 = qok;
    goto z_bb_207;
    z_bb_206:
    zT_625 = 0;
    goto z_bb_207;
    z_bb_207:
    if (zT_625) goto z_bb_208; else goto z_bb_209;
    z_bb_208:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_string_to_slice);
    z_bb_209:
    zT_628 = reg->types_items;
    zT_629 = sp2.base;
    zT_630 = (unsigned int)zT_629;
    zT_631 = zT_628[zT_630];
    src_pointee = zT_631;
    zT_632 = src_pointee.kind;
    if ((int)(zT_632 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_210; else goto z_bb_211;
    z_bb_210:
    zT_638 = reg->array_items;
    zT_639 = src_pointee.payload_idx;
    zT_640 = (unsigned int)zT_639;
    zT_641 = zT_638[zT_640];
    arr = zT_641;
    zT_642 = arr.elem;
    zT_643 = ts2.elem;
    if ((int)(zT_642 == zT_643)) goto z_bb_212; else goto z_bb_213;
    z_bb_211:
    goto z_bb_188;
    z_bb_212:
    zT_645 = qok;
    goto z_bb_214;
    z_bb_213:
    zT_645 = 0;
    goto z_bb_214;
    z_bb_214:
    if (zT_645) goto z_bb_215; else goto z_bb_216;
    z_bb_215:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_216:
    goto z_bb_211;
}

/* EOF */
