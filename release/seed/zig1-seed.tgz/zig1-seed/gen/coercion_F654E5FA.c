#include "coercion_F654E5FA.h"
zT_66E7D2EF_CoercionTable zG_66E7D2EF_CoercionTable;
zT_0FB7FB13_CoercionKind zG_0FB7FB13_CoercionKind;
/* coercionTableEnsureCapacity */
void zF_E837F929_coercionTableEnsure(zT_66E7D2EF_CoercionTable* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    int zT_17;
    zT_3E40CD83_Sand* zT_20;
    zT_9CDC9863_CoercionEntry* zT_26;
    unsigned int zT_28;
    zT_6F32B01B_Opt_235 zT_34 = {0};
    unsigned char zT_35;
    zT_3E40CD83_Sand* zT_37;
    zT_C6536882_EU_532 zT_44 = {0};
    unsigned char zT_45;
    unsigned char* zT_46;
    zT_9CDC9863_CoercionEntry* zT_49;
    zT_9CDC9863_CoercionEntry* zT_50;
    unsigned int zT_51;
    int zT_52;
    zT_9CDC9863_CoercionEntry* zT_53;
    unsigned int zT_54;
    zT_5B0DCA45_Slice_zT_9CDC9863_C zT_55;
    zT_9CDC9863_CoercionEntry* zT_56;
    unsigned int zT_57;
    unsigned int zT_62;
    unsigned int nc;
    zT_6F32B01B_Opt_235 grown;
    unsigned char* raw;
    zT_9CDC9863_CoercionEntry* new_items;
    zT_9CDC9863_CoercionEntry item;
    unsigned int i;
    zT_2 = self->entries_cap;
    if ((int)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->entries_cap;
    zT_6 = 2;
    if ((int)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->entries_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((int)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_16 = self->entries_cap;
    zT_17 = 0;
    if ((int)(zT_16 > (unsigned int)zT_17)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_20 = self->entries_alloc;
    zT_26 = self->entries_items;
    zT_28 = self->entries_cap;
    zT_34 = zF_33A3D4F8_sandTryReallocInPla(zT_20, (unsigned char*)((unsigned char*)zT_26), (unsigned int)(zT_28 * (unsigned int)(12)), (unsigned int)(nc * (unsigned int)(12)), (unsigned int)(4));
    grown = zT_34;
    zT_35 = grown.has_value;
    if (zT_35) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_37 = self->entries_alloc;
    zT_44 = zF_1395EB68_sandAlloc(zT_37, (unsigned int)((unsigned int)(12) * nc), (unsigned int)(4));
    zT_45 = zT_44.is_error;
    if (zT_45) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    self->entries_cap = nc;
    return;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    pal_trap();
    z_bb_12:
    zT_46 = zT_44.data.payload;
    goto z_bb_13;
    z_bb_13:
    raw = zT_46;
    zT_49 = (zT_9CDC9863_CoercionEntry*)raw;
    new_items = zT_49;
    zT_50 = self->entries_items;
    zT_51 = self->entries_len;
    zT_52 = 0;
    zT_53 = zT_50 + zT_52;
    zT_54 = zT_51 - zT_52;
    zT_55.ptr = zT_53;
    zT_55.len = zT_54;
    zT_56 = zT_55.ptr;
    zT_57 = zT_55.len;
    i = 0;
    goto z_bb_14;
    z_bb_14:
    if ((int)(i < zT_57)) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    item = zT_56[i];
    new_items[i] = item;
    zT_62 = i + (unsigned int)(1);
    i = zT_62;
    goto z_bb_14;
    z_bb_16:
    self->entries_items = new_items;
    self->entries_cap = nc;
    return;
}

/* coercionTableInit */
zT_66E7D2EF_CoercionTable zF_26B6D809_coercionTableInit(zT_3E40CD83_Sand* alloc) {
    zT_66E7D2EF_CoercionTable zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_5;
    zT_21D3708C_U32ToU32Map zT_6 = {0};
    zT_2 = 0;
    zT_1.entries_items = (zT_9CDC9863_CoercionEntry*)zT_2;
    zT_3 = 0;
    zT_1.entries_len = zT_3;
    zT_4 = 0;
    zT_1.entries_cap = zT_4;
    zT_1.entries_alloc = alloc;
    zT_5 = alloc;
    zT_6 = zF_58BDA2DE_u32ToU32MapInit(zT_5);
    zT_1.index = zT_6;
    return zT_1;
}

/* coercionTableAdd */
void zF_D21AE60A_coercionTableAdd(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx, zT_0FB7FB13_CoercionKind kind, unsigned int target_type) {
    zT_9CDC9863_CoercionEntry zT_5;
    zT_21D3708C_U32ToU32Map* zT_7;
    unsigned int zT_8;
    zT_BAEE192E_Opt_10 zT_10 = {0};
    unsigned char zT_11;
    zT_9CDC9863_CoercionEntry* zT_13;
    unsigned int zT_14;
    zT_66E7D2EF_CoercionTable* zT_15;
    unsigned int zT_17;
    int zT_18;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_9CDC9863_CoercionEntry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    zT_21D3708C_U32ToU32Map* zT_29;
    unsigned int zT_30;
    unsigned int zT_31;
    zT_9CDC9863_CoercionEntry entry;
    zT_BAEE192E_Opt_10 existing;
    unsigned int idx;
    zT_5.node_idx = node_idx;
    zT_5.kind = kind;
    zT_5.target_type = target_type;
    entry = zT_5;
    zT_7 = &self->index;
    zT_8 = node_idx;
    zT_10 = zF_F3EE5998_u32ToU32MapGet(zT_7, zT_8);
    existing = zT_10;
    zT_11 = existing.has_value;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = existing.value;
    zT_13 = self->entries_items;
    zT_14 = (unsigned int)idx;
    zT_13[zT_14] = entry;
    return;
    z_bb_2:
    zT_15 = self;
    zT_17 = self->entries_len;
    zT_18 = 1;
    zF_E837F929_coercionTableEnsure(zT_15, (unsigned int)(zT_17 + zT_18));
    zT_21 = self->entries_len;
    zT_22 = (unsigned int)zT_21;
    idx = zT_22;
    zT_23 = self->entries_items;
    zT_24 = (unsigned int)idx;
    zT_23[zT_24] = entry;
    zT_25 = self->entries_len;
    zT_26 = 1;
    self->entries_len = (unsigned int)(zT_25 + (unsigned int)((unsigned int)zT_26));
    zT_29 = &self->index;
    zT_30 = node_idx;
    zT_31 = idx;
    zF_26476265_u32ToU32MapPut(zT_29, zT_30, zT_31);
    return;
}

/* coercionTableGet */
zT_5CC037A7_Opt_194 zF_46B66789_coercionTableGet(zT_66E7D2EF_CoercionTable* self, unsigned int node_idx) {
    zT_21D3708C_U32ToU32Map* zT_3;
    unsigned int zT_4;
    zT_BAEE192E_Opt_10 zT_6 = {0};
    unsigned char zT_7;
    zT_9CDC9863_CoercionEntry* zT_9;
    unsigned int zT_10;
    zT_9CDC9863_CoercionEntry zT_11;
    zT_5CC037A7_Opt_194 zT_12;
    zT_5CC037A7_Opt_194 zT_13 = {0};
    zT_BAEE192E_Opt_10 entry_idx;
    unsigned int idx;
    zT_3 = &self->index;
    zT_4 = node_idx;
    zT_6 = zF_F3EE5998_u32ToU32MapGet(zT_3, zT_4);
    entry_idx = zT_6;
    zT_7 = entry_idx.has_value;
    if (zT_7) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    idx = entry_idx.value;
    zT_9 = self->entries_items;
    zT_10 = (unsigned int)idx;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
    z_bb_2:
    zT_13.has_value = 0;
    return zT_13;
}

/* classifyCoercion */
zT_0FB7FB13_CoercionKind zF_713658BF_classifyCoercion(zT_338B7C76_TypeRegistry* reg, unsigned int source, unsigned int target) {
    zT_D155D06D_Type* zT_6;
    unsigned int zT_7;
    zT_D155D06D_Type zT_8;
    zT_D155D06D_Type* zT_10;
    unsigned int zT_11;
    zT_D155D06D_Type zT_12;
    zT_33EF6BFB_TypeKind zT_13;
    zT_33EF6BFB_TypeKind zT_19;
    zT_33EF6BFB_TypeKind zT_25;
    int zT_30;
    zT_338B7C76_TypeRegistry* zT_31;
    unsigned int zT_32;
    int zT_33 = 0;
    zT_338B7C76_TypeRegistry* zT_35;
    unsigned int zT_36;
    int zT_37 = 0;
    int zT_38;
    zT_338B7C76_TypeRegistry* zT_39;
    unsigned int zT_40;
    int zT_41 = 0;
    int zT_42;
    zT_338B7C76_TypeRegistry* zT_45;
    unsigned int zT_46;
    int zT_47 = 0;
    zT_338B7C76_TypeRegistry* zT_48;
    unsigned int zT_49;
    int zT_50 = 0;
    int zT_52;
    zT_338B7C76_TypeRegistry* zT_53;
    unsigned int zT_54;
    unsigned char zT_55 = 0;
    zT_338B7C76_TypeRegistry* zT_56;
    unsigned int zT_57;
    unsigned char zT_58 = 0;
    int zT_63;
    zT_33EF6BFB_TypeKind zT_67;
    unsigned char* zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    unsigned int zT_75;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_76;
    unsigned int zT_77;
    zT_338B7C76_TypeRegistry* zT_78;
    unsigned int zT_79;
    int zT_80 = 0;
    zT_33EF6BFB_TypeKind zT_82;
    zT_33EF6BFB_TypeKind zT_88;
    zT_33EF6BFB_TypeKind zT_94;
    zT_0B10E8E9_OptionalPayload* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_0B10E8E9_OptionalPayload zT_103;
    zT_338B7C76_TypeRegistry* zT_104;
    unsigned int zT_105;
    unsigned int zT_106;
    int zT_108 = 0;
    zT_33EF6BFB_TypeKind zT_110;
    zT_33EF6BFB_TypeKind zT_116;
    zT_42C2D6BF_EUPayload* zT_122;
    unsigned int zT_123;
    unsigned int zT_124;
    zT_42C2D6BF_EUPayload zT_125;
    zT_338B7C76_TypeRegistry* zT_126;
    unsigned int zT_127;
    unsigned int zT_128;
    int zT_130 = 0;
    zT_33EF6BFB_TypeKind zT_132;
    int zT_137;
    zT_33EF6BFB_TypeKind zT_138;
    zT_33EF6BFB_TypeKind zT_144;
    int zT_149;
    zT_33EF6BFB_TypeKind zT_150;
    zT_112BF819_PtrPayload* zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    zT_112BF819_PtrPayload zT_159;
    zT_112BF819_PtrPayload* zT_161;
    unsigned int zT_162;
    unsigned int zT_163;
    zT_112BF819_PtrPayload zT_164;
    unsigned char zT_166;
    unsigned char zT_167;
    int zT_172 = 0;
    unsigned int zT_173;
    int zT_176;
    unsigned int zT_178;
    int zT_181;
    unsigned char zT_183;
    int zT_188;
    unsigned char zT_189;
    unsigned int zT_194;
    unsigned int zT_195;
    int zT_197;
    zT_33EF6BFB_TypeKind zT_199;
    int zT_204;
    zT_33EF6BFB_TypeKind zT_205;
    unsigned char zT_211;
    unsigned char zT_212;
    int zT_217 = 0;
    unsigned char zT_218;
    int zT_223;
    unsigned char zT_224;
    zT_0BB2A741_SlicePayload* zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    zT_0BB2A741_SlicePayload zT_233;
    zT_0BB2A741_SlicePayload* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_0BB2A741_SlicePayload zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    int zT_242;
    zT_33EF6BFB_TypeKind zT_244;
    int zT_249;
    zT_33EF6BFB_TypeKind zT_250;
    unsigned char zT_256;
    unsigned char zT_257;
    int zT_262 = 0;
    unsigned char zT_263;
    int zT_268;
    unsigned char zT_269;
    zT_112BF819_PtrPayload* zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    zT_112BF819_PtrPayload zT_278;
    zT_112BF819_PtrPayload* zT_280;
    unsigned int zT_281;
    unsigned int zT_282;
    zT_112BF819_PtrPayload zT_283;
    unsigned int zT_284;
    unsigned int zT_285;
    int zT_287;
    zT_33EF6BFB_TypeKind zT_289;
    int zT_294;
    zT_33EF6BFB_TypeKind zT_295;
    unsigned char zT_301;
    unsigned char zT_302;
    int zT_307 = 0;
    zT_E834303C_ArrayPayload* zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    zT_E834303C_ArrayPayload zT_312;
    zT_0BB2A741_SlicePayload* zT_314;
    unsigned int zT_315;
    unsigned int zT_316;
    zT_0BB2A741_SlicePayload zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    int zT_321;
    unsigned char zT_323;
    int zT_328;
    unsigned int zT_329;
    unsigned int zT_330;
    int zT_332;
    zT_33EF6BFB_TypeKind zT_334;
    int zT_339;
    zT_33EF6BFB_TypeKind zT_340;
    unsigned char zT_346;
    unsigned char zT_347;
    int zT_352 = 0;
    zT_E834303C_ArrayPayload* zT_354;
    unsigned int zT_355;
    unsigned int zT_356;
    zT_E834303C_ArrayPayload zT_357;
    zT_112BF819_PtrPayload* zT_359;
    unsigned int zT_360;
    unsigned int zT_361;
    zT_112BF819_PtrPayload zT_362;
    unsigned int zT_363;
    unsigned int zT_364;
    int zT_366;
    zT_33EF6BFB_TypeKind zT_368;
    int zT_373;
    zT_33EF6BFB_TypeKind zT_374;
    zT_E834303C_ArrayPayload* zT_380;
    unsigned int zT_381;
    unsigned int zT_382;
    zT_E834303C_ArrayPayload zT_383;
    zT_E834303C_ArrayPayload* zT_385;
    unsigned int zT_386;
    unsigned int zT_387;
    zT_E834303C_ArrayPayload zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    int zT_392;
    unsigned int zT_393;
    unsigned int zT_394;
    zT_33EF6BFB_TypeKind zT_397;
    int zT_402;
    zT_33EF6BFB_TypeKind zT_403;
    unsigned char zT_409;
    unsigned char zT_410;
    int zT_415 = 0;
    zT_112BF819_PtrPayload* zT_417;
    unsigned int zT_418;
    unsigned int zT_419;
    zT_112BF819_PtrPayload zT_420;
    zT_112BF819_PtrPayload* zT_422;
    unsigned int zT_423;
    unsigned int zT_424;
    zT_112BF819_PtrPayload zT_425;
    zT_D155D06D_Type* zT_427;
    unsigned int zT_428;
    unsigned int zT_429;
    zT_D155D06D_Type zT_430;
    zT_33EF6BFB_TypeKind zT_431;
    zT_E834303C_ArrayPayload* zT_437;
    unsigned int zT_438;
    unsigned int zT_439;
    zT_E834303C_ArrayPayload zT_440;
    unsigned int zT_441;
    unsigned int zT_442;
    int zT_444;
    zT_33EF6BFB_TypeKind zT_446;
    int zT_451;
    zT_33EF6BFB_TypeKind zT_452;
    unsigned char zT_458;
    unsigned char zT_459;
    int zT_464 = 0;
    zT_0BB2A741_SlicePayload* zT_466;
    unsigned int zT_467;
    unsigned int zT_468;
    zT_0BB2A741_SlicePayload zT_469;
    zT_112BF819_PtrPayload* zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    zT_112BF819_PtrPayload zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    int zT_478;
    zT_33EF6BFB_TypeKind zT_480;
    int zT_485;
    zT_33EF6BFB_TypeKind zT_486;
    zT_0B10E8E9_OptionalPayload* zT_492;
    unsigned int zT_493;
    unsigned int zT_494;
    zT_0B10E8E9_OptionalPayload zT_495;
    zT_D155D06D_Type* zT_497;
    unsigned int zT_498;
    unsigned int zT_499;
    zT_D155D06D_Type zT_500;
    zT_33EF6BFB_TypeKind zT_501;
    zT_338B7C76_TypeRegistry* zT_506;
    unsigned int zT_507;
    unsigned int zT_508;
    int zT_510 = 0;
    int zT_514;
    int zT_517;
    int zT_520;
    zT_33EF6BFB_TypeKind zT_524;
    int zT_529;
    zT_33EF6BFB_TypeKind zT_530;
    unsigned char zT_536;
    unsigned char zT_537;
    int zT_542 = 0;
    zT_112BF819_PtrPayload* zT_544;
    unsigned int zT_545;
    unsigned int zT_546;
    zT_112BF819_PtrPayload zT_547;
    zT_0BB2A741_SlicePayload* zT_549;
    unsigned int zT_550;
    unsigned int zT_551;
    zT_0BB2A741_SlicePayload zT_552;
    unsigned char* zT_554;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_555;
    unsigned int zT_556;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_557;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_559;
    unsigned int zT_561;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_562;
    int zT_566;
    unsigned char* zT_567;
    unsigned int zT_568;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_569;
    unsigned int zT_570 = 0;
    unsigned int zT_574;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_575;
    unsigned char* zT_579;
    unsigned int zT_580;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_581;
    unsigned char* zT_583;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_584;
    unsigned int zT_585;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_586;
    zT_5A26C2ED_Arr_unsigned_char_1 zT_588;
    unsigned int zT_590;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_591;
    int zT_595;
    unsigned char* zT_596;
    unsigned int zT_597;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_598;
    unsigned int zT_599 = 0;
    unsigned int zT_603;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_604;
    unsigned char* zT_608;
    unsigned int zT_609;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_610;
    unsigned char* zT_612;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_613;
    unsigned int zT_614;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_615;
    zT_D155D06D_Type* zT_617;
    unsigned int zT_618;
    unsigned int zT_619;
    zT_D155D06D_Type zT_620;
    zT_33EF6BFB_TypeKind zT_621;
    zT_E834303C_ArrayPayload* zT_627;
    unsigned int zT_628;
    unsigned int zT_629;
    zT_E834303C_ArrayPayload zT_630;
    unsigned int zT_631;
    unsigned int zT_632;
    int zT_634;
    zT_D155D06D_Type src;
    zT_D155D06D_Type tgt;
    zT_8F083A69_Slice_zT_0B42B2F8_u ccn_m;
    zT_0B10E8E9_OptionalPayload opt;
    zT_42C2D6BF_EUPayload eu;
    zT_112BF819_PtrPayload tgt_pp;
    zT_112BF819_PtrPayload src_pp;
    int qok;
    zT_0BB2A741_SlicePayload s_sl;
    zT_0BB2A741_SlicePayload t_sl;
    zT_112BF819_PtrPayload s_pp;
    zT_112BF819_PtrPayload t_pp;
    zT_E834303C_ArrayPayload arr;
    zT_0BB2A741_SlicePayload sl;
    zT_112BF819_PtrPayload pp;
    zT_E834303C_ArrayPayload s_arr;
    zT_E834303C_ArrayPayload t_arr;
    zT_112BF819_PtrPayload sp;
    zT_112BF819_PtrPayload tp;
    zT_D155D06D_Type spo;
    zT_0B10E8E9_OptionalPayload opt2;
    zT_D155D06D_Type opt_ty;
    zT_112BF819_PtrPayload sp2;
    zT_0BB2A741_SlicePayload ts2;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsb;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb2;
    unsigned int clsb2l;
    unsigned int clsb2s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clse;
    zT_5A26C2ED_Arr_unsigned_char_1 clsb3;
    unsigned int clsb3l;
    unsigned int clsb3s;
    zT_8F083A69_Slice_zT_0B42B2F8_u clsnl;
    zT_D155D06D_Type src_pointee;
    if ((int)(source == target)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_2:
    zT_6 = reg->types_items;
    zT_7 = (unsigned int)source;
    zT_8 = zT_6[zT_7];
    src = zT_8;
    zT_10 = reg->types_items;
    zT_11 = (unsigned int)target;
    zT_12 = zT_10[zT_11];
    tgt = zT_12;
    zT_13 = src.kind;
    if ((int)(zT_13 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_4:
    zT_19 = src.kind;
    if ((int)(zT_19 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_6:
    zT_25 = src.kind;
    if ((int)(zT_25 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_31 = reg;
    zT_32 = target;
    zT_33 = zF_3087E0A5_typeRegistryIsNumer(zT_31, zT_32);
    zT_30 = zT_33;
    goto z_bb_9;
    z_bb_8:
    zT_30 = 0;
    goto z_bb_9;
    z_bb_9:
    if (zT_30) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_literal_coerce);
    z_bb_11:
    zT_35 = reg;
    zT_36 = source;
    zT_37 = zF_3290E9C4_typeRegistryIsInteg(zT_35, zT_36);
    if (zT_37) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_39 = reg;
    zT_40 = target;
    zT_41 = zF_3290E9C4_typeRegistryIsInteg(zT_39, zT_40);
    zT_38 = zT_41;
    goto z_bb_14;
    z_bb_13:
    zT_38 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_38) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_42 = source != (unsigned int)(19);
    goto z_bb_17;
    z_bb_16:
    zT_42 = 0;
    goto z_bb_17;
    z_bb_17:
    if (zT_42) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_45 = reg;
    zT_46 = source;
    zT_47 = zF_B664AC19_typeRegistryIsUnsig(zT_45, zT_46);
    zT_48 = reg;
    zT_49 = target;
    zT_50 = zF_B664AC19_typeRegistryIsUnsig(zT_48, zT_49);
    if ((int)(zT_47 == zT_50)) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    if ((int)(source == (unsigned int)(15))) goto z_bb_25; else goto z_bb_26;
    z_bb_20:
    zT_53 = reg;
    zT_54 = source;
    zT_55 = zF_655972D5_typeRegistryIntWidt(zT_53, zT_54);
    zT_56 = reg;
    zT_57 = target;
    zT_58 = zF_655972D5_typeRegistryIntWidt(zT_56, zT_57);
    zT_52 = zT_55 < zT_58;
    goto z_bb_22;
    z_bb_21:
    zT_52 = 0;
    goto z_bb_22;
    z_bb_22:
    if (zT_52) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_int_widen);
    z_bb_24:
    goto z_bb_19;
    z_bb_25:
    zT_63 = target == (unsigned int)(16);
    goto z_bb_27;
    z_bb_26:
    zT_63 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_63) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_float_widen);
    z_bb_29:
    zT_67 = src.kind;
    if ((int)(zT_67 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_73 = "CC:nul";
    zT_75 = 6;
    zT_74.ptr = zT_73;
    zT_74.len = zT_75;
    ccn_m = zT_74;
    zT_76 = ccn_m;
    zT_77 = target;
    zF_C914CB83_markerWriteInt(zT_76, zT_77);
    zT_78 = reg;
    zT_79 = target;
    zT_80 = zF_AD61DB1B_typeRegistryIsPoint(zT_78, zT_79);
    if (zT_80) goto z_bb_32; else goto z_bb_33;
    z_bb_31:
    zT_94 = tgt.kind;
    if ((int)(zT_94 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_38; else goto z_bb_39;
    z_bb_32:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_33:
    zT_82 = tgt.kind;
    if ((int)(zT_82 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional_null);
    z_bb_35:
    zT_88 = tgt.kind;
    if ((int)(zT_88 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_37:
    goto z_bb_31;
    z_bb_38:
    zT_100 = reg->opt_items;
    zT_101 = tgt.payload_idx;
    zT_102 = (unsigned int)zT_101;
    zT_103 = zT_100[zT_102];
    opt = zT_103;
    zT_104 = reg;
    zT_105 = source;
    zT_106 = opt.payload;
    zT_108 = zF_683AEB7F_typeRegistryIsAssig(zT_104, zT_105, zT_106);
    if (zT_108) goto z_bb_40; else goto z_bb_41;
    z_bb_39:
    zT_116 = tgt.kind;
    if ((int)(zT_116 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_44; else goto z_bb_45;
    z_bb_40:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_optional);
    z_bb_41:
    zT_110 = src.kind;
    if ((int)(zT_110 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_43:
    goto z_bb_39;
    z_bb_44:
    zT_122 = reg->eu_items;
    zT_123 = tgt.payload_idx;
    zT_124 = (unsigned int)zT_123;
    zT_125 = zT_122[zT_124];
    eu = zT_125;
    zT_126 = reg;
    zT_127 = source;
    zT_128 = eu.payload;
    zT_130 = zF_683AEB7F_typeRegistryIsAssig(zT_126, zT_127, zT_128);
    if (zT_130) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    zT_132 = src.kind;
    if ((int)(zT_132 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type))) goto z_bb_48; else goto z_bb_49;
    z_bb_46:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_error_success);
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_138 = tgt.kind;
    zT_137 = zT_138 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_50;
    z_bb_49:
    zT_137 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_137) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_wrap_error_err);
    z_bb_52:
    zT_144 = src.kind;
    if ((int)(zT_144 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_150 = tgt.kind;
    zT_149 = zT_150 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type);
    goto z_bb_55;
    z_bb_54:
    zT_149 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_149) goto z_bb_56; else goto z_bb_57;
    z_bb_56:
    zT_156 = reg->ptr_items;
    zT_157 = tgt.payload_idx;
    zT_158 = (unsigned int)zT_157;
    zT_159 = zT_156[zT_158];
    tgt_pp = zT_159;
    zT_161 = reg->ptr_items;
    zT_162 = src.payload_idx;
    zT_163 = (unsigned int)zT_162;
    zT_164 = zT_161[zT_163];
    src_pp = zT_164;
    zT_166 = src.flags;
    zT_167 = tgt.flags;
    zT_172 = zF_08C13644_pointerQualifiersMo(zT_166, zT_167, (unsigned char)(2));
    qok = zT_172;
    zT_173 = tgt_pp.base;
    if ((int)(zT_173 == (unsigned int)(1))) goto z_bb_58; else goto z_bb_59;
    z_bb_57:
    zT_199 = tgt.kind;
    if ((int)(zT_199 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_78; else goto z_bb_79;
    z_bb_58:
    zT_176 = qok;
    goto z_bb_60;
    z_bb_59:
    zT_176 = 0;
    goto z_bb_60;
    z_bb_60:
    if (zT_176) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_62:
    zT_178 = src_pp.base;
    if ((int)(zT_178 == (unsigned int)(1))) goto z_bb_63; else goto z_bb_64;
    z_bb_63:
    zT_181 = qok;
    goto z_bb_65;
    z_bb_64:
    zT_181 = 0;
    goto z_bb_65;
    z_bb_65:
    if (zT_181) goto z_bb_66; else goto z_bb_67;
    z_bb_66:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_67:
    zT_183 = tgt.flags;
    if ((int)((unsigned char)(zT_183 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_68; else goto z_bb_69;
    z_bb_68:
    zT_189 = src.flags;
    zT_188 = (unsigned char)(zT_189 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_70;
    z_bb_69:
    zT_188 = 0;
    goto z_bb_70;
    z_bb_70:
    if (zT_188) goto z_bb_71; else goto z_bb_72;
    z_bb_71:
    zT_194 = src_pp.base;
    zT_195 = tgt_pp.base;
    if ((int)(zT_194 == zT_195)) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    goto z_bb_57;
    z_bb_73:
    zT_197 = qok;
    goto z_bb_75;
    z_bb_74:
    zT_197 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_197) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_77:
    goto z_bb_72;
    z_bb_78:
    zT_205 = src.kind;
    zT_204 = zT_205 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_80;
    z_bb_79:
    zT_204 = 0;
    goto z_bb_80;
    z_bb_80:
    if (zT_204) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_211 = src.flags;
    zT_212 = tgt.flags;
    zT_217 = zF_08C13644_pointerQualifiersMo(zT_211, zT_212, (unsigned char)(2));
    qok = zT_217;
    zT_218 = tgt.flags;
    if ((int)((unsigned char)(zT_218 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_83; else goto z_bb_84;
    z_bb_82:
    zT_244 = tgt.kind;
    if ((int)(zT_244 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type))) goto z_bb_93; else goto z_bb_94;
    z_bb_83:
    zT_224 = src.flags;
    zT_223 = (unsigned char)(zT_224 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_85;
    z_bb_84:
    zT_223 = 0;
    goto z_bb_85;
    z_bb_85:
    if (zT_223) goto z_bb_86; else goto z_bb_87;
    z_bb_86:
    zT_230 = reg->slice_items;
    zT_231 = src.payload_idx;
    zT_232 = (unsigned int)zT_231;
    zT_233 = zT_230[zT_232];
    s_sl = zT_233;
    zT_235 = reg->slice_items;
    zT_236 = tgt.payload_idx;
    zT_237 = (unsigned int)zT_236;
    zT_238 = zT_235[zT_237];
    t_sl = zT_238;
    zT_239 = s_sl.elem;
    zT_240 = t_sl.elem;
    if ((int)(zT_239 == zT_240)) goto z_bb_88; else goto z_bb_89;
    z_bb_87:
    goto z_bb_82;
    z_bb_88:
    zT_242 = qok;
    goto z_bb_90;
    z_bb_89:
    zT_242 = 0;
    goto z_bb_90;
    z_bb_90:
    if (zT_242) goto z_bb_91; else goto z_bb_92;
    z_bb_91:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_92:
    goto z_bb_87;
    z_bb_93:
    zT_250 = src.kind;
    zT_249 = zT_250 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_95;
    z_bb_94:
    zT_249 = 0;
    goto z_bb_95;
    z_bb_95:
    if (zT_249) goto z_bb_96; else goto z_bb_97;
    z_bb_96:
    zT_256 = src.flags;
    zT_257 = tgt.flags;
    zT_262 = zF_08C13644_pointerQualifiersMo(zT_256, zT_257, (unsigned char)(2));
    qok = zT_262;
    zT_263 = tgt.flags;
    if ((int)((unsigned char)(zT_263 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_98; else goto z_bb_99;
    z_bb_97:
    zT_289 = src.kind;
    if ((int)(zT_289 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_108; else goto z_bb_109;
    z_bb_98:
    zT_269 = src.flags;
    zT_268 = (unsigned char)(zT_269 & (unsigned char)(1)) == (unsigned char)(0);
    goto z_bb_100;
    z_bb_99:
    zT_268 = 0;
    goto z_bb_100;
    z_bb_100:
    if (zT_268) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_275 = reg->ptr_items;
    zT_276 = src.payload_idx;
    zT_277 = (unsigned int)zT_276;
    zT_278 = zT_275[zT_277];
    s_pp = zT_278;
    zT_280 = reg->ptr_items;
    zT_281 = tgt.payload_idx;
    zT_282 = (unsigned int)zT_281;
    zT_283 = zT_280[zT_282];
    t_pp = zT_283;
    zT_284 = s_pp.base;
    zT_285 = t_pp.base;
    if ((int)(zT_284 == zT_285)) goto z_bb_103; else goto z_bb_104;
    z_bb_102:
    goto z_bb_97;
    z_bb_103:
    zT_287 = qok;
    goto z_bb_105;
    z_bb_104:
    zT_287 = 0;
    goto z_bb_105;
    z_bb_105:
    if (zT_287) goto z_bb_106; else goto z_bb_107;
    z_bb_106:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_const_qualify);
    z_bb_107:
    goto z_bb_102;
    z_bb_108:
    zT_295 = tgt.kind;
    zT_294 = zT_295 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_110;
    z_bb_109:
    zT_294 = 0;
    goto z_bb_110;
    z_bb_110:
    if (zT_294) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_301 = src.flags;
    zT_302 = tgt.flags;
    zT_307 = zF_08C13644_pointerQualifiersMo(zT_301, zT_302, (unsigned char)(2));
    qok = zT_307;
    zT_309 = reg->array_items;
    zT_310 = src.payload_idx;
    zT_311 = (unsigned int)zT_310;
    zT_312 = zT_309[zT_311];
    arr = zT_312;
    zT_314 = reg->slice_items;
    zT_315 = tgt.payload_idx;
    zT_316 = (unsigned int)zT_315;
    zT_317 = zT_314[zT_316];
    sl = zT_317;
    zT_318 = arr.elem;
    zT_319 = sl.elem;
    if ((int)(zT_318 == zT_319)) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    zT_334 = src.kind;
    if ((int)(zT_334 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_113:
    zT_321 = qok;
    goto z_bb_115;
    z_bb_114:
    zT_321 = 0;
    goto z_bb_115;
    z_bb_115:
    if (zT_321) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_117:
    zT_323 = tgt.flags;
    if ((int)((unsigned char)(zT_323 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_118; else goto z_bb_119;
    z_bb_118:
    zT_329 = arr.elem;
    zT_330 = sl.elem;
    zT_328 = zT_329 == zT_330;
    goto z_bb_120;
    z_bb_119:
    zT_328 = 0;
    goto z_bb_120;
    z_bb_120:
    if (zT_328) goto z_bb_121; else goto z_bb_122;
    z_bb_121:
    zT_332 = qok;
    goto z_bb_123;
    z_bb_122:
    zT_332 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_332) goto z_bb_124; else goto z_bb_125;
    z_bb_124:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_125:
    goto z_bb_112;
    z_bb_126:
    zT_340 = tgt.kind;
    zT_339 = zT_340 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_128;
    z_bb_127:
    zT_339 = 0;
    goto z_bb_128;
    z_bb_128:
    if (zT_339) goto z_bb_129; else goto z_bb_130;
    z_bb_129:
    zT_346 = src.flags;
    zT_347 = tgt.flags;
    zT_352 = zF_08C13644_pointerQualifiersMo(zT_346, zT_347, (unsigned char)(2));
    qok = zT_352;
    zT_354 = reg->array_items;
    zT_355 = src.payload_idx;
    zT_356 = (unsigned int)zT_355;
    zT_357 = zT_354[zT_356];
    arr = zT_357;
    zT_359 = reg->ptr_items;
    zT_360 = tgt.payload_idx;
    zT_361 = (unsigned int)zT_360;
    zT_362 = zT_359[zT_361];
    pp = zT_362;
    zT_363 = arr.elem;
    zT_364 = pp.base;
    if ((int)(zT_363 == zT_364)) goto z_bb_131; else goto z_bb_132;
    z_bb_130:
    zT_368 = src.kind;
    if ((int)(zT_368 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_136; else goto z_bb_137;
    z_bb_131:
    zT_366 = qok;
    goto z_bb_133;
    z_bb_132:
    zT_366 = 0;
    goto z_bb_133;
    z_bb_133:
    if (zT_366) goto z_bb_134; else goto z_bb_135;
    z_bb_134:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_many_ptr);
    z_bb_135:
    goto z_bb_130;
    z_bb_136:
    zT_374 = tgt.kind;
    zT_373 = zT_374 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_138;
    z_bb_137:
    zT_373 = 0;
    goto z_bb_138;
    z_bb_138:
    if (zT_373) goto z_bb_139; else goto z_bb_140;
    z_bb_139:
    zT_380 = reg->array_items;
    zT_381 = src.payload_idx;
    zT_382 = (unsigned int)zT_381;
    zT_383 = zT_380[zT_382];
    s_arr = zT_383;
    zT_385 = reg->array_items;
    zT_386 = tgt.payload_idx;
    zT_387 = (unsigned int)zT_386;
    zT_388 = zT_385[zT_387];
    t_arr = zT_388;
    zT_389 = s_arr.elem;
    zT_390 = t_arr.elem;
    if ((int)(zT_389 == zT_390)) goto z_bb_141; else goto z_bb_142;
    z_bb_140:
    zT_397 = src.kind;
    if ((int)(zT_397 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_146; else goto z_bb_147;
    z_bb_141:
    zT_393 = s_arr.length;
    zT_394 = t_arr.length;
    zT_392 = zT_393 == zT_394;
    goto z_bb_143;
    z_bb_142:
    zT_392 = 0;
    goto z_bb_143;
    z_bb_143:
    if (zT_392) goto z_bb_144; else goto z_bb_145;
    z_bb_144:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_145:
    goto z_bb_140;
    z_bb_146:
    zT_403 = tgt.kind;
    zT_402 = zT_403 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_148;
    z_bb_147:
    zT_402 = 0;
    goto z_bb_148;
    z_bb_148:
    if (zT_402) goto z_bb_149; else goto z_bb_150;
    z_bb_149:
    zT_409 = src.flags;
    zT_410 = tgt.flags;
    zT_415 = zF_08C13644_pointerQualifiersMo(zT_409, zT_410, (unsigned char)(2));
    qok = zT_415;
    zT_417 = reg->ptr_items;
    zT_418 = src.payload_idx;
    zT_419 = (unsigned int)zT_418;
    zT_420 = zT_417[zT_419];
    sp = zT_420;
    zT_422 = reg->ptr_items;
    zT_423 = tgt.payload_idx;
    zT_424 = (unsigned int)zT_423;
    zT_425 = zT_422[zT_424];
    tp = zT_425;
    zT_427 = reg->types_items;
    zT_428 = sp.base;
    zT_429 = (unsigned int)zT_428;
    zT_430 = zT_427[zT_429];
    spo = zT_430;
    zT_431 = spo.kind;
    if ((int)(zT_431 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_151; else goto z_bb_152;
    z_bb_150:
    zT_446 = src.kind;
    if ((int)(zT_446 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_158; else goto z_bb_159;
    z_bb_151:
    zT_437 = reg->array_items;
    zT_438 = spo.payload_idx;
    zT_439 = (unsigned int)zT_438;
    zT_440 = zT_437[zT_439];
    arr = zT_440;
    zT_441 = arr.elem;
    zT_442 = tp.base;
    if ((int)(zT_441 == zT_442)) goto z_bb_153; else goto z_bb_154;
    z_bb_152:
    goto z_bb_150;
    z_bb_153:
    zT_444 = qok;
    goto z_bb_155;
    z_bb_154:
    zT_444 = 0;
    goto z_bb_155;
    z_bb_155:
    if (zT_444) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_157:
    goto z_bb_152;
    z_bb_158:
    zT_452 = tgt.kind;
    zT_451 = zT_452 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_many_ptr_type);
    goto z_bb_160;
    z_bb_159:
    zT_451 = 0;
    goto z_bb_160;
    z_bb_160:
    if (zT_451) goto z_bb_161; else goto z_bb_162;
    z_bb_161:
    zT_458 = src.flags;
    zT_459 = tgt.flags;
    zT_464 = zF_08C13644_pointerQualifiersMo(zT_458, zT_459, (unsigned char)(2));
    qok = zT_464;
    zT_466 = reg->slice_items;
    zT_467 = src.payload_idx;
    zT_468 = (unsigned int)zT_467;
    zT_469 = zT_466[zT_468];
    sl = zT_469;
    zT_471 = reg->ptr_items;
    zT_472 = tgt.payload_idx;
    zT_473 = (unsigned int)zT_472;
    zT_474 = zT_471[zT_473];
    pp = zT_474;
    zT_475 = sl.elem;
    zT_476 = pp.base;
    if ((int)(zT_475 == zT_476)) goto z_bb_163; else goto z_bb_164;
    z_bb_162:
    zT_480 = src.kind;
    if ((int)(zT_480 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_168; else goto z_bb_169;
    z_bb_163:
    zT_478 = qok;
    goto z_bb_165;
    z_bb_164:
    zT_478 = 0;
    goto z_bb_165;
    z_bb_165:
    if (zT_478) goto z_bb_166; else goto z_bb_167;
    z_bb_166:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_slice_to_many_ptr);
    z_bb_167:
    goto z_bb_162;
    z_bb_168:
    zT_486 = tgt.kind;
    zT_485 = zT_486 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_170;
    z_bb_169:
    zT_485 = 0;
    goto z_bb_170;
    z_bb_170:
    if (zT_485) goto z_bb_171; else goto z_bb_172;
    z_bb_171:
    zT_492 = reg->opt_items;
    zT_493 = tgt.payload_idx;
    zT_494 = (unsigned int)zT_493;
    zT_495 = zT_492[zT_494];
    opt2 = zT_495;
    zT_497 = reg->types_items;
    zT_498 = opt2.payload;
    zT_499 = (unsigned int)zT_498;
    zT_500 = zT_497[zT_499];
    opt_ty = zT_500;
    zT_501 = opt_ty.kind;
    if ((int)(zT_501 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_173; else goto z_bb_174;
    z_bb_172:
    if ((int)(source == (unsigned int)(8))) goto z_bb_177; else goto z_bb_178;
    z_bb_173:
    zT_506 = reg;
    zT_507 = source;
    zT_508 = opt2.payload;
    zT_510 = zF_683AEB7F_typeRegistryIsAssig(zT_506, zT_507, zT_508);
    if (zT_510) goto z_bb_175; else goto z_bb_176;
    z_bb_174:
    goto z_bb_172;
    z_bb_175:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_ptr_to_optional_ptr);
    z_bb_176:
    goto z_bb_174;
    z_bb_177:
    zT_514 = target == (unsigned int)(14);
    goto z_bb_179;
    z_bb_178:
    zT_514 = 0;
    goto z_bb_179;
    z_bb_179:
    if (zT_514) goto z_bb_181; else goto z_bb_180;
    z_bb_180:
    if ((int)(source == (unsigned int)(14))) goto z_bb_183; else goto z_bb_184;
    z_bb_181:
    zT_517 = 1;
    goto z_bb_182;
    z_bb_182:
    if (zT_517) goto z_bb_186; else goto z_bb_187;
    z_bb_183:
    zT_520 = target == (unsigned int)(8);
    goto z_bb_185;
    z_bb_184:
    zT_520 = 0;
    goto z_bb_185;
    z_bb_185:
    zT_517 = zT_520;
    goto z_bb_182;
    z_bb_186:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_187:
    zT_524 = src.kind;
    if ((int)(zT_524 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_ptr_type))) goto z_bb_188; else goto z_bb_189;
    z_bb_188:
    zT_530 = tgt.kind;
    zT_529 = zT_530 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type);
    goto z_bb_190;
    z_bb_189:
    zT_529 = 0;
    goto z_bb_190;
    z_bb_190:
    if (zT_529) goto z_bb_191; else goto z_bb_192;
    z_bb_191:
    zT_536 = src.flags;
    zT_537 = tgt.flags;
    zT_542 = zF_08C13644_pointerQualifiersMo(zT_536, zT_537, (unsigned char)(2));
    qok = zT_542;
    zT_544 = reg->ptr_items;
    zT_545 = src.payload_idx;
    zT_546 = (unsigned int)zT_545;
    zT_547 = zT_544[zT_546];
    sp2 = zT_547;
    zT_549 = reg->slice_items;
    zT_550 = tgt.payload_idx;
    zT_551 = (unsigned int)zT_550;
    zT_552 = zT_549[zT_551];
    ts2 = zT_552;
    zT_554 = "CLS:p";
    zT_556 = 5;
    zT_555.ptr = zT_554;
    zT_555.len = zT_556;
    clsb = zT_555;
    zT_557 = clsb;
    zF_48AC7B3A_markerWrite(zT_557);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_559[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb2[_i] = zT_559[_i];
        _i++;
    }
}
    zT_561 = sp2.base;
    zT_566 = 0;
    zT_567 = (unsigned char*)((unsigned char*)clsb2) + zT_566;
    zT_568 = (unsigned int)(10) - zT_566;
    zT_569.ptr = zT_567;
    zT_569.len = zT_568;
    zT_562 = zT_569;
    zT_570 = zF_A7504564_itoa(zT_561, zT_562);
    clsb2l = zT_570;
    zT_574 = (unsigned int)(9) - (unsigned int)((unsigned int)clsb2l);
    clsb2s = zT_574;
    zT_579 = (unsigned char*)((unsigned char*)clsb2) + clsb2s;
    zT_580 = (unsigned int)(9) - clsb2s;
    zT_581.ptr = zT_579;
    zT_581.len = zT_580;
    zT_575 = zT_581;
    zF_48AC7B3A_markerWrite(zT_575);
    zT_583 = "e";
    zT_585 = 1;
    zT_584.ptr = zT_583;
    zT_584.len = zT_585;
    clse = zT_584;
    zT_586 = clse;
    zF_48AC7B3A_markerWrite(zT_586);
    {
    unsigned int _i = 0;
    while (_i < 10) {
        zT_588[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 10) {
        clsb3[_i] = zT_588[_i];
        _i++;
    }
}
    zT_590 = ts2.elem;
    zT_595 = 0;
    zT_596 = (unsigned char*)((unsigned char*)clsb3) + zT_595;
    zT_597 = (unsigned int)(10) - zT_595;
    zT_598.ptr = zT_596;
    zT_598.len = zT_597;
    zT_591 = zT_598;
    zT_599 = zF_A7504564_itoa(zT_590, zT_591);
    clsb3l = zT_599;
    zT_603 = (unsigned int)(9) - (unsigned int)((unsigned int)clsb3l);
    clsb3s = zT_603;
    zT_608 = (unsigned char*)((unsigned char*)clsb3) + clsb3s;
    zT_609 = (unsigned int)(9) - clsb3s;
    zT_610.ptr = zT_608;
    zT_610.len = zT_609;
    zT_604 = zT_610;
    zF_48AC7B3A_markerWrite(zT_604);
    zT_612 = "\n";
    zT_614 = 1;
    zT_613.ptr = zT_612;
    zT_613.len = zT_614;
    clsnl = zT_613;
    zT_615 = clsnl;
    zF_48AC7B3A_markerWrite(zT_615);
    zT_617 = reg->types_items;
    zT_618 = sp2.base;
    zT_619 = (unsigned int)zT_618;
    zT_620 = zT_617[zT_619];
    src_pointee = zT_620;
    zT_621 = src_pointee.kind;
    if ((int)(zT_621 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_193; else goto z_bb_194;
    z_bb_192:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_none);
    z_bb_193:
    zT_627 = reg->array_items;
    zT_628 = src_pointee.payload_idx;
    zT_629 = (unsigned int)zT_628;
    zT_630 = zT_627[zT_629];
    arr = zT_630;
    zT_631 = arr.elem;
    zT_632 = ts2.elem;
    if ((int)(zT_631 == zT_632)) goto z_bb_195; else goto z_bb_196;
    z_bb_194:
    goto z_bb_192;
    z_bb_195:
    zT_634 = qok;
    goto z_bb_197;
    z_bb_196:
    zT_634 = 0;
    goto z_bb_197;
    z_bb_197:
    if (zT_634) goto z_bb_198; else goto z_bb_199;
    z_bb_198:
    return (zT_0FB7FB13_CoercionKind)(zT_0FB7FB13_CoercionKind_array_to_slice);
    z_bb_199:
    goto z_bb_194;
}

/* EOF */
