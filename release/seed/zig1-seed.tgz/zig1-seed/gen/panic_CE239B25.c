#include "panic_CE239B25.h"
/* panicHandler */
void zF_6D97D338_panicHandler(zT_8F083A69_Slice_zT_0B42B2F8_u msg, zT_8F083A69_Slice_zT_0B42B2F8_u file, unsigned int line) {
    unsigned char* zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    zT_5426B97B_Arr_unsigned_char_1 zT_21;
    unsigned int zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    int zT_27;
    unsigned char* zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_31 = 0;
    unsigned int zT_35;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned char* zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned char* zT_45;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_48;
    int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u ice;
    zT_8F083A69_Slice_zT_0B42B2F8_u at;
    zT_8F083A69_Slice_zT_0B42B2F8_u colon;
    zT_5426B97B_Arr_unsigned_char_1 buf;
    unsigned int len;
    unsigned int start;
    unsigned int end;
    zT_8F083A69_Slice_zT_0B42B2F8_u nl;
    zT_4 = "ICE: ";
    zT_6 = 5;
    zT_5.ptr = zT_4;
    zT_5.len = zT_6;
    ice = zT_5;
    zT_7 = ice;
    zF_E4B2EF19_stderr_write(zT_7);
    zT_8 = msg;
    zF_E4B2EF19_stderr_write(zT_8);
    zT_10 = " at ";
    zT_12 = 4;
    zT_11.ptr = zT_10;
    zT_11.len = zT_12;
    at = zT_11;
    zT_13 = at;
    zF_E4B2EF19_stderr_write(zT_13);
    zT_14 = file;
    zF_E4B2EF19_stderr_write(zT_14);
    zT_16 = ":";
    zT_18 = 1;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    colon = zT_17;
    zT_19 = colon;
    zF_E4B2EF19_stderr_write(zT_19);
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_21[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        buf[_i] = zT_21[_i];
        _i++;
    }
}
    zT_23 = line;
    zT_27 = 0;
    zT_28 = (unsigned char*)((unsigned char*)buf) + zT_27;
    zT_29 = (unsigned int)(16) - zT_27;
    zT_30.ptr = zT_28;
    zT_30.len = zT_29;
    zT_24 = zT_30;
    zT_31 = zF_A7504564_itoa(zT_23, zT_24);
    len = zT_31;
    zT_35 = (unsigned int)(15) - (unsigned int)((unsigned int)len);
    start = zT_35;
    zT_37 = 15;
    end = zT_37;
    zT_41 = (unsigned char*)((unsigned char*)buf) + start;
    zT_42 = end - start;
    zT_43.ptr = zT_41;
    zT_43.len = zT_42;
    zT_38 = zT_43;
    zF_E4B2EF19_stderr_write(zT_38);
    zT_45 = "\n";
    zT_47 = 1;
    zT_46.ptr = zT_45;
    zT_46.len = zT_47;
    nl = zT_46;
    zT_48 = nl;
    zF_E4B2EF19_stderr_write(zT_48);
    zT_50 = 3;
    zF_CDED1A85_exit((unsigned char)((unsigned char)zT_50));
    return;
}

/* EOF */
