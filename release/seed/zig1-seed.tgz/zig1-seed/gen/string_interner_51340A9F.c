#include "string_interner_51340A9F.h"
zT_D3EB6303_StringInterner zG_D3EB6303_StringInterner;
/* internerBucketsAllocNarrow */
void zF_9DC2533D_internerBucketsAllo(zT_D3EB6303_StringInterner* self, unsigned int count) {
    zT_3E40CD83_Sand* zT_3;
    zT_FF4D4E6C_EU_242 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* raw;
    zT_3 = self->allocator;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)((unsigned int)(2) * count), (unsigned int)(2));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_12 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    self->buckets_narrow_items = (unsigned short*)((unsigned short*)raw);
    return;
}

/* internerBucketsAllocWide */
void zF_22329EAD_internerBucketsAllo(zT_D3EB6303_StringInterner* self, unsigned int count) {
    zT_3E40CD83_Sand* zT_3;
    zT_FF4D4E6C_EU_242 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* raw;
    zT_3 = self->allocator;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)((unsigned int)(4) * count), (unsigned int)(4));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_12 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    self->buckets_wide_items = (unsigned int*)((unsigned int*)raw);
    return;
}

/* internerBucketGet */
unsigned int zF_6162B7CC_internerBucketGet(zT_D3EB6303_StringInterner* self, unsigned int bucket) {
    unsigned char zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned short* zT_5;
    unsigned short zT_6;
    zT_2 = self->buckets_is_wide;
    if (zT_2) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_3 = self->buckets_wide_items;
    zT_4 = zT_3[bucket];
    return zT_4;
    z_bb_2:
    zT_5 = self->buckets_narrow_items;
    zT_6 = zT_5[bucket];
    return (unsigned int)((unsigned int)zT_6);
}

/* internerBucketSet */
void zF_DF70E160_internerBucketSet(zT_D3EB6303_StringInterner* self, unsigned int bucket, unsigned int value) {
    unsigned char zT_3;
    unsigned int* zT_4;
    unsigned short zT_5;
    unsigned short* zT_6;
    zT_3 = self->buckets_is_wide;
    if (zT_3) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_4 = self->buckets_wide_items;
    zT_4[bucket] = value;
    goto z_bb_2;
    z_bb_2:
    return;
    z_bb_3:
    zT_5 = (unsigned short)value;
    zT_6 = self->buckets_narrow_items;
    zT_6[bucket] = zT_5;
    goto z_bb_2;
}

/* internerBucketZero */
void zF_57DE4452_internerBucketZero(zT_D3EB6303_StringInterner* self, unsigned int bucket) {
    unsigned char zT_2;
    unsigned int zT_3;
    unsigned int* zT_4;
    unsigned short zT_5;
    unsigned short* zT_6;
    zT_2 = self->buckets_is_wide;
    if (zT_2) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_3 = 0;
    zT_4 = self->buckets_wide_items;
    zT_4[bucket] = zT_3;
    goto z_bb_2;
    z_bb_2:
    return;
    z_bb_3:
    zT_5 = 0;
    zT_6 = self->buckets_narrow_items;
    zT_6[bucket] = zT_5;
    goto z_bb_2;
}

/* ensureCapacityEntries */
void zF_FB994A71_ensureCapacityEntri(zT_EABC94D3_InternEntry** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int new_capacity) {
    unsigned int zT_5;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    int zT_15;
    int zT_17;
    unsigned int zT_18;
    zT_3E40CD83_Sand* zT_20;
    zT_FF4D4E6C_EU_242 zT_26 = {0};
    unsigned char zT_27;
    unsigned char* zT_28;
    zT_EABC94D3_InternEntry* zT_31;
    zT_EABC94D3_InternEntry* zT_32;
    unsigned int zT_33;
    int zT_34;
    zT_EABC94D3_InternEntry* zT_35;
    unsigned int zT_36;
    zT_0B638573_Slice_zT_EABC94D3_I zT_37;
    zT_EABC94D3_InternEntry* zT_38;
    unsigned int zT_39;
    unsigned int zT_44;
    unsigned int new_cap;
    unsigned char* raw;
    zT_EABC94D3_InternEntry* new_items;
    zT_EABC94D3_InternEntry item;
    unsigned int i;
    zT_5 = *capacity;
    if ((unsigned char)(new_capacity <= zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    zT_8 = *capacity;
    zT_9 = 2;
    if ((unsigned char)(new_cap < (unsigned int)(zT_8 * zT_9))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = *capacity;
    zT_13 = 2;
    zT_14 = zT_12 * zT_13;
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_15 = 8;
    if ((unsigned char)(new_cap < (unsigned int)zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 8;
    zT_18 = (unsigned int)zT_17;
    new_cap = zT_18;
    goto z_bb_6;
    z_bb_6:
    zT_20 = arena;
    zT_26 = zF_1395EB68_sandAlloc(zT_20, (unsigned int)((unsigned int)(12) * new_cap), (unsigned int)(4));
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_28 = zT_26.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_28;
    zT_31 = (zT_EABC94D3_InternEntry*)raw;
    new_items = zT_31;
    zT_32 = *items;
    zT_33 = *len;
    zT_34 = 0;
    zT_35 = zT_32 + zT_34;
    zT_36 = zT_33 - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_38 = zT_37.ptr;
    zT_39 = zT_37.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_39)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_38[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12:
    *items = new_items;
    *capacity = new_cap;
    return;
    z_bb_13:
    zT_44 = i + (unsigned int)(1);
    i = zT_44;
    goto z_bb_10;
}

/* appendEntry */
void zF_A7C4EDCF_appendEntry(zT_EABC94D3_InternEntry** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, zT_EABC94D3_InternEntry value) {
    zT_EABC94D3_InternEntry** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_10;
    int zT_11;
    zT_EABC94D3_InternEntry* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    zT_5 = items;
    zT_6 = len;
    zT_7 = capacity;
    zT_8 = arena;
    zT_10 = *len;
    zT_11 = 1;
    zF_FB994A71_ensureCapacityEntri(zT_5, zT_6, zT_7, zT_8, (unsigned int)(zT_10 + zT_11));
    zT_13 = *items;
    zT_14 = *len;
    zT_13[zT_14] = value;
    zT_15 = *len;
    zT_16 = 1;
    *len = (unsigned int)(zT_15 + (unsigned int)((unsigned int)zT_16));
    return;
}

/* stringInternerInit */
zT_D3EB6303_StringInterner zF_FB2E811D_stringInternerInit(zT_3E40CD83_Sand* allocator, unsigned int bucket_count) {
    zT_D3EB6303_StringInterner zT_3;
    int zT_4;
    int zT_5;
    unsigned char zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned char zT_19;
    zT_D3EB6303_StringInterner* zT_20;
    unsigned int zT_21;
    zT_D3EB6303_StringInterner* zT_23;
    unsigned int zT_24;
    int zT_27;
    unsigned int zT_28;
    zT_D3EB6303_StringInterner* zT_30;
    unsigned int zT_31;
    unsigned int zT_34;
    unsigned int zT_37;
    unsigned int zT_40;
    zT_3E40CD83_Sand* zT_42;
    zT_FF4D4E6C_EU_242 zT_48 = {0};
    unsigned char zT_49;
    unsigned char* zT_50;
    zT_EABC94D3_InternEntry zT_53;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_EABC94D3_InternEntry* zT_58;
    unsigned int zT_59;
    zT_D3EB6303_StringInterner interner;
    unsigned int bc;
    unsigned int ec;
    unsigned int bi;
    unsigned char* entries_raw;
    zT_4 = 0;
    zT_3.buckets_narrow_items = (unsigned short*)zT_4;
    zT_5 = 0;
    zT_3.buckets_wide_items = (unsigned int*)zT_5;
    zT_6 = 0;
    zT_3.buckets_is_wide = zT_6;
    zT_7 = 0;
    zT_3.buckets_len = zT_7;
    zT_8 = 0;
    zT_3.buckets_capacity = zT_8;
    zT_9 = 0;
    zT_3.entries_items = (zT_EABC94D3_InternEntry*)zT_9;
    zT_10 = 0;
    zT_3.entries_len = zT_10;
    zT_11 = 0;
    zT_3.entries_capacity = zT_11;
    zT_3.entries_allocator = allocator;
    zT_3.allocator = allocator;
    interner = zT_3;
    zT_13 = (unsigned int)bucket_count;
    bc = zT_13;
    if ((unsigned char)(bc > (unsigned int)(131070))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    interner.buckets_is_wide = (unsigned char)(1);
    goto z_bb_2;
    z_bb_2:
    if ((unsigned char)(bc > (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_19 = interner.buckets_is_wide;
    if (zT_19) goto z_bb_5; else goto z_bb_7;
    z_bb_4:
    zT_37 = bc / (unsigned int)(2);
    ec = zT_37;
    if ((unsigned char)(ec < (unsigned int)(8))) goto z_bb_12; else goto z_bb_13;
    z_bb_5:
    zT_20 = &interner;
    zT_21 = bc;
    zF_22329EAD_internerBucketsAllo(zT_20, zT_21);
    goto z_bb_6;
    z_bb_6:
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    bi = zT_28;
    goto z_bb_8;
    z_bb_7:
    zT_23 = &interner;
    zT_24 = bc;
    zF_9DC2533D_internerBucketsAllo(zT_23, zT_24);
    goto z_bb_6;
    z_bb_8:
    if ((unsigned char)(bi < bc)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_30 = &interner;
    zT_31 = bi;
    zF_57DE4452_internerBucketZero(zT_30, zT_31);
    goto z_bb_11;
    z_bb_10:
    interner.buckets_capacity = bc;
    interner.buckets_len = bc;
    goto z_bb_4;
    z_bb_11:
    zT_34 = bi + (unsigned int)(1);
    bi = zT_34;
    goto z_bb_8;
    z_bb_12:
    zT_40 = 8;
    ec = zT_40;
    goto z_bb_13;
    z_bb_13:
    zT_42 = allocator;
    zT_48 = zF_1395EB68_sandAlloc(zT_42, (unsigned int)((unsigned int)(12) * ec), (unsigned int)(4));
    zT_49 = zT_48.is_error;
    if (zT_49) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    pal_trap();
    z_bb_15:
    zT_50 = zT_48.data.payload;
    goto z_bb_16;
    z_bb_16:
    entries_raw = zT_50;
    interner.entries_items = (zT_EABC94D3_InternEntry*)((zT_EABC94D3_InternEntry*)entries_raw);
    interner.entries_capacity = ec;
    zT_54 = "";
    zT_56 = 0;
    zT_55.ptr = zT_54;
    zT_55.len = zT_56;
    zT_53.text = zT_55;
    zT_57 = 0;
    zT_53.next = zT_57;
    zT_58 = interner.entries_items;
    zT_59 = 0;
    zT_58[zT_59] = zT_53;
    interner.entries_len = (unsigned int)(1);
    return interner;
}

/* stringInternerIntern */
unsigned int zF_50C274AF_stringInternerInter(zT_D3EB6303_StringInterner* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    unsigned char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_9;
    unsigned int zT_12;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned char* zT_21;
    int zT_22;
    unsigned char zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27 = 0;
    unsigned int zT_29;
    int zT_30;
    zT_D3EB6303_StringInterner* zT_32;
    int zT_34;
    unsigned int zT_36;
    unsigned int zT_40;
    zT_D3EB6303_StringInterner* zT_42;
    unsigned int zT_43;
    unsigned int zT_44 = 0;
    int zT_45;
    zT_EABC94D3_InternEntry* zT_48;
    zT_EABC94D3_InternEntry* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    unsigned char zT_54 = 0;
    unsigned char* zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_63;
    unsigned char zT_64;
    unsigned char zT_66;
    zT_D3EB6303_StringInterner* zT_69;
    unsigned char* zT_71;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_72;
    unsigned int zT_73;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_74;
    zT_D3EB6303_StringInterner* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char* zT_80 = 0;
    zT_EABC94D3_InternEntry** zT_81;
    unsigned int* zT_82;
    unsigned int* zT_83;
    zT_3E40CD83_Sand* zT_84;
    zT_EABC94D3_InternEntry zT_85;
    zT_EABC94D3_InternEntry zT_90;
    unsigned int zT_92;
    int zT_93;
    unsigned char* zT_94;
    unsigned int zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_96;
    zT_D3EB6303_StringInterner* zT_97;
    unsigned int zT_98;
    unsigned int zT_99 = 0;
    zT_D3EB6303_StringInterner* zT_100;
    unsigned int zT_101;
    unsigned int zT_105;
    int zT_106;
    zT_D3EB6303_StringInterner* zT_109;
    int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u inth_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u inth2_m;
    unsigned int hash;
    unsigned int bucket_count;
    unsigned int bucket;
    unsigned int idx;
    zT_EABC94D3_InternEntry* entry;
    unsigned int new_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u indp_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u innw_m;
    unsigned char* copied;
    unsigned int entry_count;
    zT_3 = "INT:tl";
    zT_5 = 6;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    inth_m = zT_4;
    zT_6 = inth_m;
    zT_9 = text.len;
    zF_C914CB83_markerWriteInt(zT_6, (unsigned int)((unsigned int)zT_9));
    zT_12 = text.len;
    if ((unsigned char)(zT_12 > (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = "INT:t0";
    zT_18 = 6;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    inth2_m = zT_17;
    zT_19 = inth2_m;
    zT_21 = text.ptr;
    zT_22 = 0;
    zT_23 = zT_21[zT_22];
    zF_C914CB83_markerWriteInt(zT_19, (unsigned int)((unsigned int)zT_23));
    goto z_bb_2;
    z_bb_2:
    zT_26 = text;
    zT_27 = zF_B22E025B_fnv1a(zT_26);
    hash = zT_27;
    zT_29 = self->buckets_len;
    bucket_count = zT_29;
    zT_30 = 0;
    if ((unsigned char)(bucket_count == (unsigned int)zT_30)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_32 = self;
    zT_34 = 8;
    zF_3A9E8EDF_stringInternerGrowB(zT_32, (unsigned int)((unsigned int)zT_34));
    zT_36 = self->buckets_len;
    bucket_count = zT_36;
    goto z_bb_4;
    z_bb_4:
    zT_40 = (unsigned int)(unsigned int)(hash % (unsigned int)((unsigned int)bucket_count));
    bucket = zT_40;
    zT_42 = self;
    zT_43 = bucket;
    zT_44 = zF_6162B7CC_internerBucketGet(zT_42, zT_43);
    idx = zT_44;
    goto z_bb_5;
    z_bb_5:
    zT_45 = 0;
    if ((unsigned char)(idx != (unsigned int)zT_45)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_48 = self->entries_items;
    zT_50 = zT_48 + (unsigned int)((unsigned int)idx);
    entry = zT_50;
    zT_53 = entry->text;
    zT_51 = zT_53;
    zT_52 = text;
    zT_54 = zF_B7662C9F_mem_eql(zT_51, zT_52);
    if (zT_54) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_63 = self->entries_len;
    new_idx = zT_63;
    zT_64 = self->buckets_is_wide;
    if ((unsigned char)(!zT_64)) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_56 = "INT:dup";
    zT_58 = 7;
    zT_57.ptr = zT_56;
    zT_57.len = zT_58;
    indp_m = zT_57;
    zT_59 = indp_m;
    zT_60 = idx;
    zF_C914CB83_markerWriteInt(zT_59, zT_60);
    return idx;
    z_bb_10:
    zT_61 = entry->next;
    idx = zT_61;
    goto z_bb_8;
    z_bb_11:
    zT_66 = new_idx > (unsigned int)(65535);
    goto z_bb_13;
    z_bb_12:
    zT_66 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_66) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_69 = self;
    zF_3765B9F7_stringInternerMakeB(zT_69);
    goto z_bb_15;
    z_bb_15:
    zT_71 = "INT:new";
    zT_73 = 7;
    zT_72.ptr = zT_71;
    zT_72.len = zT_73;
    innw_m = zT_72;
    zT_74 = innw_m;
    zF_95B5C5CD_measureMarkerWriteI(zT_74, (unsigned int)((unsigned int)new_idx));
    zT_78 = self;
    zT_79 = text;
    zT_80 = zF_EDFF876E_stringInternerCopyT(zT_78, zT_79);
    copied = zT_80;
    zT_81 = &self->entries_items;
    zT_82 = &self->entries_len;
    zT_83 = &self->entries_capacity;
    zT_84 = self->entries_allocator;
    zT_92 = text.len;
    zT_93 = 0;
    zT_94 = copied + zT_93;
    zT_95 = zT_92 - zT_93;
    zT_96.ptr = zT_94;
    zT_96.len = zT_95;
    zT_90.text = zT_96;
    zT_97 = self;
    zT_98 = bucket;
    zT_99 = zF_6162B7CC_internerBucketGet(zT_97, zT_98);
    zT_90.next = zT_99;
    zT_85 = zT_90;
    zF_A7C4EDCF_appendEntry(zT_81, zT_82, zT_83, zT_84, zT_85);
    zT_100 = self;
    zT_101 = bucket;
    zF_DF70E160_internerBucketSet(zT_100, zT_101, (unsigned int)((unsigned int)new_idx));
    zT_105 = self->entries_len;
    entry_count = zT_105;
    zT_106 = 2;
    if ((unsigned char)((unsigned int)(entry_count * zT_106) > bucket_count)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_109 = self;
    zT_111 = 2;
    zF_3A9E8EDF_stringInternerGrowB(zT_109, (unsigned int)((unsigned int)(unsigned int)(bucket_count * zT_111)));
    goto z_bb_17;
    z_bb_17:
    return (unsigned int)((unsigned int)new_idx);
}

/* stringInternerGet */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_9134020D_stringInternerGet(zT_D3EB6303_StringInterner* self, unsigned int id) {
    zT_EABC94D3_InternEntry* zT_2;
    unsigned int zT_3;
    zT_EABC94D3_InternEntry zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_2 = self->entries_items;
    zT_3 = (unsigned int)id;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.text;
    return zT_5;
}

/* stringInternerCopyToArena */
unsigned char* zF_EDFF876E_stringInternerCopyT(zT_D3EB6303_StringInterner* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    zT_FF4D4E6C_EU_242 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* zT_14;
    unsigned int zT_15;
    unsigned int zT_20;
    unsigned char* raw;
    unsigned char c;
    unsigned int i;
    zT_3 = self->allocator;
    zT_4 = text.len;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, zT_4, (unsigned int)(1));
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_12 = zT_10.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    zT_14 = text.ptr;
    zT_15 = text.len;
    i = 0;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(i < zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    c = zT_14[i];
    raw[i] = c;
    goto z_bb_7;
    z_bb_6:
    return raw;
    z_bb_7:
    zT_20 = i + (unsigned int)(1);
    i = zT_20;
    goto z_bb_4;
}

/* stringInternerMakeBucketsWide */
void zF_3765B9F7_stringInternerMakeB(zT_D3EB6303_StringInterner* self) {
    unsigned char zT_1;
    unsigned int zT_3;
    zT_D3EB6303_StringInterner* zT_4;
    unsigned int zT_5;
    int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int* zT_12;
    unsigned int zT_14;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_EABC94D3_InternEntry* zT_22;
    zT_EABC94D3_InternEntry* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28 = 0;
    unsigned int zT_32;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int* zT_35;
    int zT_36;
    unsigned int zT_38;
    unsigned int count;
    unsigned int wi;
    unsigned int mei;
    zT_EABC94D3_InternEntry* entry;
    unsigned int mh;
    unsigned int mb;
    zT_1 = self->buckets_is_wide;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_3 = self->buckets_len;
    count = zT_3;
    zT_4 = self;
    zT_5 = count;
    zF_22329EAD_internerBucketsAllo(zT_4, zT_5);
    self->buckets_is_wide = (unsigned char)(1);
    zT_8 = 0;
    zT_9 = (unsigned int)zT_8;
    wi = zT_9;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(wi < count)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_11 = 0;
    zT_12 = self->buckets_wide_items;
    zT_12[wi] = zT_11;
    goto z_bb_6;
    z_bb_5:
    zT_16 = 1;
    zT_17 = (unsigned int)zT_16;
    mei = zT_17;
    goto z_bb_7;
    z_bb_6:
    zT_14 = wi + (unsigned int)(1);
    wi = zT_14;
    goto z_bb_3;
    z_bb_7:
    zT_18 = self->entries_len;
    if ((unsigned char)(mei < (unsigned int)((unsigned int)zT_18))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_22 = self->entries_items;
    zT_24 = zT_22 + (unsigned int)((unsigned int)mei);
    entry = zT_24;
    zT_27 = entry->text;
    zT_26 = zT_27;
    zT_28 = zF_B22E025B_fnv1a(zT_26);
    mh = zT_28;
    zT_32 = (unsigned int)(unsigned int)(mh % (unsigned int)((unsigned int)count));
    mb = zT_32;
    zT_33 = self->buckets_wide_items;
    zT_34 = zT_33[mb];
    entry->next = zT_34;
    zT_35 = self->buckets_wide_items;
    zT_35[mb] = mei;
    zT_36 = 1;
    zT_38 = mei + (unsigned int)((unsigned int)zT_36);
    mei = zT_38;
    goto z_bb_10;
    z_bb_9:
    return;
    z_bb_10:
    goto z_bb_7;
}

/* stringInternerGrowBuckets */
void zF_3A9E8EDF_stringInternerGrowB(zT_D3EB6303_StringInterner* self, unsigned int new_bucket_count) {
    unsigned int zT_3;
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_11;
    unsigned int zT_13;
    unsigned int zT_16;
    unsigned char zT_17;
    zT_D3EB6303_StringInterner* zT_18;
    unsigned int zT_19;
    zT_D3EB6303_StringInterner* zT_20;
    unsigned int zT_21;
    int zT_24;
    unsigned int zT_25;
    zT_D3EB6303_StringInterner* zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_EABC94D3_InternEntry* zT_38;
    zT_EABC94D3_InternEntry* zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44 = 0;
    unsigned int zT_48;
    zT_D3EB6303_StringInterner* zT_49;
    unsigned int zT_50;
    unsigned int zT_51 = 0;
    zT_D3EB6303_StringInterner* zT_52;
    unsigned int zT_53;
    int zT_56;
    unsigned int zT_58;
    unsigned int new_count;
    unsigned int new_cap;
    unsigned int i;
    unsigned int ei;
    zT_EABC94D3_InternEntry* entry;
    unsigned int h;
    unsigned int bucket;
    zT_3 = (unsigned int)new_bucket_count;
    new_count = zT_3;
    zT_4 = self->buckets_capacity;
    if ((unsigned char)(new_count > zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    new_cap = new_count;
    zT_7 = self->buckets_capacity;
    if ((unsigned char)(new_cap < (unsigned int)(zT_7 * (unsigned int)(2)))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    self->buckets_len = (unsigned int)(0);
    zT_24 = 0;
    zT_25 = (unsigned int)zT_24;
    i = zT_25;
    goto z_bb_10;
    z_bb_3:
    zT_11 = self->buckets_capacity;
    zT_13 = zT_11 * (unsigned int)(2);
    new_cap = zT_13;
    goto z_bb_4;
    z_bb_4:
    if ((unsigned char)(new_cap < (unsigned int)(8))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_16 = 8;
    new_cap = zT_16;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->buckets_is_wide;
    if (zT_17) goto z_bb_7; else goto z_bb_9;
    z_bb_7:
    zT_18 = self;
    zT_19 = new_cap;
    zF_22329EAD_internerBucketsAllo(zT_18, zT_19);
    goto z_bb_8;
    z_bb_8:
    self->buckets_capacity = new_cap;
    goto z_bb_2;
    z_bb_9:
    zT_20 = self;
    zT_21 = new_cap;
    zF_9DC2533D_internerBucketsAllo(zT_20, zT_21);
    goto z_bb_8;
    z_bb_10:
    if ((unsigned char)(i < new_count)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_27 = self;
    zT_28 = i;
    zF_57DE4452_internerBucketZero(zT_27, zT_28);
    goto z_bb_13;
    z_bb_12:
    self->buckets_len = new_count;
    zT_32 = 1;
    zT_33 = (unsigned int)zT_32;
    ei = zT_33;
    goto z_bb_14;
    z_bb_13:
    zT_30 = i + (unsigned int)(1);
    i = zT_30;
    goto z_bb_10;
    z_bb_14:
    zT_34 = self->entries_len;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_34))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    zT_38 = self->entries_items;
    zT_40 = zT_38 + (unsigned int)((unsigned int)ei);
    entry = zT_40;
    zT_43 = entry->text;
    zT_42 = zT_43;
    zT_44 = zF_B22E025B_fnv1a(zT_42);
    h = zT_44;
    zT_48 = (unsigned int)(unsigned int)(h % (unsigned int)((unsigned int)new_count));
    bucket = zT_48;
    zT_49 = self;
    zT_50 = bucket;
    zT_51 = zF_6162B7CC_internerBucketGet(zT_49, zT_50);
    entry->next = zT_51;
    zT_52 = self;
    zT_53 = bucket;
    zF_DF70E160_internerBucketSet(zT_52, zT_53, (unsigned int)((unsigned int)ei));
    zT_56 = 1;
    zT_58 = ei + (unsigned int)((unsigned int)zT_56);
    ei = zT_58;
    goto z_bb_17;
    z_bb_16:
    return;
    z_bb_17:
    goto z_bb_14;
}

/* EOF */
