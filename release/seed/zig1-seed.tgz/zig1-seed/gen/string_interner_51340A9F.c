#include "string_interner_51340A9F.h"
zT_D3EB6303_StringInterner zG_D3EB6303_StringInterner;
/* ensureCapacityBuckets */
void zF_49E817CE_ensureCapacityBucke(unsigned int** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int new_capacity) {
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    int zT_15;
    int zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_171165BB_EU_812 zT_26 = {0};
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned char* zT_29;
    unsigned int* zT_31;
    unsigned int* zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int* zT_35;
    unsigned int zT_36;
    zT_3CB0179A_Slice_zT_05F374B1_u zT_37;
    unsigned int* zT_38;
    unsigned int zT_39;
    int zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int new_cap;
    unsigned char* raw;
    unsigned int* new_items;
    unsigned int item;
    unsigned int i;
    zT_5 = *capacity;
    zT_6 = new_capacity <= zT_5;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    new_cap = new_capacity;
    new_cap = new_capacity;
    zT_8 = *capacity;
    zT_9 = 2;
    zT_10 = zT_8 * zT_9;
    zT_11 = new_cap < zT_10;
    if (zT_11) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = *capacity;
    zT_13 = 2;
    zT_14 = zT_12 * zT_13;
    new_cap = zT_14;
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_15 = 8;
    zT_16 = new_cap < (unsigned int)zT_15;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 8;
    zT_18 = (unsigned int)zT_17;
    new_cap = zT_18;
    new_cap = zT_18;
    goto z_bb_6;
    z_bb_6:
    zT_20 = arena;
    zT_23 = 4;
    zT_24 = zT_23 * new_cap;
    zT_21 = zT_24;
    zT_25 = 4;
    zT_22 = zT_25;
    zT_26 = zF_1395EB68_sandAlloc(zT_20, zT_21, zT_22);
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    z_bb_8:
    zT_29 = zT_26.data.payload;
    zT_28 = zT_29;
    goto z_bb_9;
    z_bb_9:
    raw = zT_28;
    raw = zT_28;
    raw = zT_28;
    zT_31 = (unsigned int*)raw;
    new_items = zT_31;
    new_items = zT_31;
    new_items = zT_31;
    zT_32 = *items;
    zT_33 = *len;
    zT_34 = 0;
    zT_35 = zT_32 + zT_34;
    zT_36 = zT_33 - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_38 = zT_37.ptr;
    zT_39 = zT_37.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    zT_41 = i < zT_39;
    if (zT_41) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_38[i];
    new_items[i] = item;
    zT_43 = 1;
    zT_44 = i + zT_43;
    i = zT_44;
    goto z_bb_10;
    z_bb_12:
    *items = new_items;
    *capacity = new_cap;
    return;
}

/* ensureCapacityEntries */
void zF_FB994A71_ensureCapacityEntri(zT_EABC94D3_InternEntry** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int new_capacity) {
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_14;
    int zT_15;
    int zT_16;
    int zT_17;
    unsigned int zT_18;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_171165BB_EU_812 zT_26 = {0};
    unsigned char zT_27;
    unsigned char* zT_28;
    unsigned char* zT_29;
    zT_EABC94D3_InternEntry* zT_31;
    zT_EABC94D3_InternEntry* zT_32;
    unsigned int zT_33;
    int zT_34;
    zT_EABC94D3_InternEntry* zT_35;
    unsigned int zT_36;
    zT_0B638573_Slice_zT_EABC94D3_I zT_37;
    zT_EABC94D3_InternEntry* zT_38;
    unsigned int zT_39;
    int zT_41;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int new_cap;
    unsigned char* raw;
    zT_EABC94D3_InternEntry* new_items;
    zT_EABC94D3_InternEntry item;
    unsigned int i;
    zT_5 = *capacity;
    zT_6 = new_capacity <= zT_5;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    new_cap = new_capacity;
    new_cap = new_capacity;
    new_cap = new_capacity;
    zT_8 = *capacity;
    zT_9 = 2;
    zT_10 = zT_8 * zT_9;
    zT_11 = new_cap < zT_10;
    if (zT_11) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_12 = *capacity;
    zT_13 = 2;
    zT_14 = zT_12 * zT_13;
    new_cap = zT_14;
    new_cap = zT_14;
    goto z_bb_4;
    z_bb_4:
    zT_15 = 8;
    zT_16 = new_cap < (unsigned int)zT_15;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_17 = 8;
    zT_18 = (unsigned int)zT_17;
    new_cap = zT_18;
    new_cap = zT_18;
    goto z_bb_6;
    z_bb_6:
    zT_20 = arena;
    zT_23 = 16;
    zT_24 = zT_23 * new_cap;
    zT_21 = zT_24;
    zT_25 = 4;
    zT_22 = zT_25;
    zT_26 = zF_1395EB68_sandAlloc(zT_20, zT_21, zT_22);
    zT_27 = zT_26.is_error;
    if (zT_27) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    z_bb_8:
    zT_29 = zT_26.data.payload;
    zT_28 = zT_29;
    goto z_bb_9;
    z_bb_9:
    raw = zT_28;
    raw = zT_28;
    raw = zT_28;
    zT_31 = (zT_EABC94D3_InternEntry*)raw;
    new_items = zT_31;
    new_items = zT_31;
    new_items = zT_31;
    zT_32 = *items;
    zT_33 = *len;
    zT_34 = 0;
    zT_35 = zT_32 + zT_34;
    zT_36 = zT_33 - zT_34;
    zT_37.ptr = zT_35;
    zT_37.len = zT_36;
    zT_38 = zT_37.ptr;
    zT_39 = zT_37.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    zT_41 = i < zT_39;
    if (zT_41) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_38[i];
    new_items[i] = item;
    zT_43 = 1;
    zT_44 = i + zT_43;
    i = zT_44;
    goto z_bb_10;
    z_bb_12:
    *items = new_items;
    *capacity = new_cap;
    return;
}

/* appendBucket */
void zF_E28214AB_appendBucket(unsigned int** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, unsigned int value) {
    unsigned int** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_5 = items;
    zT_6 = len;
    zT_7 = capacity;
    zT_8 = arena;
    zT_10 = *len;
    zT_11 = 1;
    zT_12 = zT_10 + zT_11;
    zT_9 = zT_12;
    zF_49E817CE_ensureCapacityBucke(zT_5, zT_6, zT_7, zT_8, zT_9);
    zT_13 = *items;
    zT_14 = *len;
    zT_13[zT_14] = value;
    zT_15 = *len;
    zT_16 = 1;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15 + zT_17;
    *len = zT_18;
    return;
}

/* appendEntry */
void zF_A7C4EDCF_appendEntry(zT_EABC94D3_InternEntry** items, unsigned int* len, unsigned int* capacity, zT_3E40CD83_Sand* arena, zT_EABC94D3_InternEntry value) {
    zT_EABC94D3_InternEntry** zT_5;
    unsigned int* zT_6;
    unsigned int* zT_7;
    zT_3E40CD83_Sand* zT_8;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    zT_EABC94D3_InternEntry* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    zT_5 = items;
    zT_6 = len;
    zT_7 = capacity;
    zT_8 = arena;
    zT_10 = *len;
    zT_11 = 1;
    zT_12 = zT_10 + zT_11;
    zT_9 = zT_12;
    zF_FB994A71_ensureCapacityEntri(zT_5, zT_6, zT_7, zT_8, zT_9);
    zT_13 = *items;
    zT_14 = *len;
    zT_13[zT_14] = value;
    zT_15 = *len;
    zT_16 = 1;
    zT_17 = (unsigned int)zT_16;
    zT_18 = zT_15 + zT_17;
    *len = zT_18;
    return;
}

/* stringInternerInit */
zT_D3EB6303_StringInterner zF_FB2E811D_stringInternerInit(zT_3E40CD83_Sand* allocator, unsigned int bucket_count) {
    zT_D3EB6303_StringInterner zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    zT_3E40CD83_Sand* zT_15;
    unsigned int zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    unsigned int zT_20;
    zT_171165BB_EU_812 zT_21 = {0};
    unsigned char zT_22;
    unsigned char* zT_23;
    unsigned char* zT_24;
    unsigned int* zT_25;
    int zT_27;
    unsigned int zT_28;
    int zT_29;
    unsigned int zT_30;
    unsigned int* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_37;
    int zT_38;
    unsigned int zT_39;
    zT_3E40CD83_Sand* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_171165BB_EU_812 zT_47 = {0};
    unsigned char zT_48;
    unsigned char* zT_49;
    unsigned char* zT_50;
    zT_EABC94D3_InternEntry* zT_51;
    zT_EABC94D3_InternEntry zT_52;
    char* zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55;
    unsigned int zT_56;
    unsigned int zT_57;
    zT_EABC94D3_InternEntry* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    zT_D3EB6303_StringInterner interner;
    unsigned int bc;
    unsigned char* buckets_raw;
    unsigned int ec;
    unsigned int bi;
    unsigned char* entries_raw;
    zT_4 = 0;
    zT_3.buckets_items = (unsigned int*)zT_4;
    zT_5 = 0;
    zT_3.buckets_len = zT_5;
    zT_6 = 0;
    zT_3.buckets_capacity = zT_6;
    zT_7 = 0;
    zT_3.entries_items = (zT_EABC94D3_InternEntry*)zT_7;
    zT_8 = 0;
    zT_3.entries_len = zT_8;
    zT_9 = 0;
    zT_3.entries_capacity = zT_9;
    zT_3.entries_allocator = allocator;
    zT_3.allocator = allocator;
    interner = zT_3;
    interner = zT_3;
    interner = zT_3;
    zT_11 = (unsigned int)bucket_count;
    bc = zT_11;
    bc = zT_11;
    bc = zT_11;
    zT_12 = 0;
    zT_13 = bc > zT_12;
    if (zT_13) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_15 = allocator;
    zT_18 = 4;
    zT_19 = zT_18 * bc;
    zT_16 = zT_19;
    zT_20 = 4;
    zT_17 = zT_20;
    zT_21 = zF_1395EB68_sandAlloc(zT_15, zT_16, zT_17);
    zT_22 = zT_21.is_error;
    if (zT_22) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_35 = 2;
    zT_36 = bc / zT_35;
    ec = zT_36;
    ec = zT_36;
    ec = zT_36;
    zT_37 = 8;
    zT_38 = ec < zT_37;
    if (zT_38) goto z_bb_10; else goto z_bb_11;
    z_bb_3:
    z_bb_4:
    zT_24 = zT_21.data.payload;
    zT_23 = zT_24;
    goto z_bb_5;
    z_bb_5:
    buckets_raw = zT_23;
    buckets_raw = zT_23;
    buckets_raw = zT_23;
    zT_25 = (unsigned int*)buckets_raw;
    interner.buckets_items = zT_25;
    zT_27 = 0;
    zT_28 = (unsigned int)zT_27;
    bi = zT_28;
    bi = zT_28;
    bi = zT_28;
    goto z_bb_6;
    z_bb_6:
    zT_29 = bi < bc;
    if (zT_29) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = 0;
    zT_31 = interner.buckets_items;
    zT_31[bi] = zT_30;
    goto z_bb_9;
    z_bb_8:
    interner.buckets_capacity = bc;
    interner.buckets_len = bc;
    goto z_bb_2;
    z_bb_9:
    zT_32 = 1;
    zT_33 = bi + zT_32;
    bi = zT_33;
    bi = zT_33;
    goto z_bb_6;
    z_bb_10:
    zT_39 = 8;
    ec = zT_39;
    ec = zT_39;
    goto z_bb_11;
    z_bb_11:
    zT_41 = allocator;
    zT_44 = 16;
    zT_45 = zT_44 * ec;
    zT_42 = zT_45;
    zT_46 = 4;
    zT_43 = zT_46;
    zT_47 = zF_1395EB68_sandAlloc(zT_41, zT_42, zT_43);
    zT_48 = zT_47.is_error;
    if (zT_48) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    z_bb_13:
    zT_50 = zT_47.data.payload;
    zT_49 = zT_50;
    goto z_bb_14;
    z_bb_14:
    entries_raw = zT_49;
    entries_raw = zT_49;
    entries_raw = zT_49;
    zT_51 = (zT_EABC94D3_InternEntry*)entries_raw;
    interner.entries_items = zT_51;
    interner.entries_capacity = ec;
    zT_53 = "";
    zT_55 = 0;
    zT_54.ptr = zT_53;
    zT_54.len = zT_55;
    zT_52.text = zT_54;
    zT_56 = 0;
    zT_52.hash = zT_56;
    zT_57 = 0;
    zT_52.next = zT_57;
    zT_58 = interner.entries_items;
    zT_59 = 0;
    zT_58[zT_59] = zT_52;
    zT_60 = 1;
    interner.entries_len = zT_60;
    return interner;
}

/* stringInternerIntern */
unsigned int zF_50C274AF_stringInternerInter(zT_D3EB6303_StringInterner* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    char* zT_3;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_4;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_13;
    int zT_14;
    char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_21;
    int zT_22;
    unsigned char zT_23;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_26;
    unsigned int zT_27 = 0;
    unsigned int zT_29;
    int zT_30;
    int zT_31;
    zT_D3EB6303_StringInterner* zT_32;
    unsigned int zT_33;
    int zT_34;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    int zT_44;
    int zT_45;
    zT_EABC94D3_InternEntry* zT_47;
    unsigned int zT_48;
    zT_EABC94D3_InternEntry* zT_49;
    unsigned int zT_50;
    int zT_51;
    int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    int zT_56 = 0;
    char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_61;
    unsigned int zT_62;
    unsigned int zT_63;
    unsigned int zT_65;
    char* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    unsigned int zT_69;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_70;
    unsigned int zT_71;
    unsigned int zT_72;
    zT_D3EB6303_StringInterner* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned char* zT_76 = 0;
    zT_EABC94D3_InternEntry** zT_77;
    unsigned int* zT_78;
    unsigned int* zT_79;
    zT_3E40CD83_Sand* zT_80;
    zT_EABC94D3_InternEntry zT_81;
    zT_EABC94D3_InternEntry** zT_82;
    unsigned int* zT_83;
    unsigned int* zT_84;
    zT_3E40CD83_Sand* zT_85;
    zT_EABC94D3_InternEntry zT_86;
    unsigned int zT_88;
    int zT_89;
    unsigned char* zT_90;
    unsigned int zT_91;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_92;
    unsigned int* zT_93;
    unsigned int zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    unsigned int* zT_97;
    unsigned int zT_98;
    unsigned int zT_100;
    int zT_101;
    unsigned int zT_102;
    int zT_103;
    zT_D3EB6303_StringInterner* zT_104;
    unsigned int zT_105;
    int zT_106;
    unsigned int zT_107;
    unsigned int zT_108;
    unsigned int zT_109;
    zT_8F083A69_Slice_zT_0B42B2F8_u inth_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u inth2_m;
    unsigned int hash;
    unsigned int bucket_count;
    unsigned int bucket;
    unsigned int idx;
    zT_EABC94D3_InternEntry* entry;
    unsigned int new_idx;
    zT_8F083A69_Slice_zT_0B42B2F8_u innw_m;
    unsigned char* copied;
    unsigned int entry_count;
    zT_8F083A69_Slice_zT_0B42B2F8_u indp_m;
    zT_3 = "INT:tl";
    zT_5 = 6;
    zT_4.ptr = zT_3;
    zT_4.len = zT_5;
    inth_m = zT_4;
    inth_m = zT_4;
    inth_m = zT_4;
    zT_6 = inth_m;
    zT_9 = text.len;
    zT_10 = (unsigned int)zT_9;
    zT_7 = zT_10;
    zF_C914CB83_markerWriteInt(zT_6, zT_7);
    zT_12 = text.len;
    zT_13 = 0;
    zT_14 = zT_12 > zT_13;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_16 = "INT:t0";
    zT_18 = 6;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    inth2_m = zT_17;
    inth2_m = zT_17;
    inth2_m = zT_17;
    zT_19 = inth2_m;
    zT_21 = text.ptr;
    zT_22 = 0;
    zT_23 = zT_21[zT_22];
    zT_24 = (unsigned int)zT_23;
    zT_20 = zT_24;
    zF_C914CB83_markerWriteInt(zT_19, zT_20);
    goto z_bb_2;
    z_bb_2:
    zT_26 = text;
    zT_27 = zF_B22E025B_fnv1a(zT_26);
    hash = zT_27;
    hash = zT_27;
    hash = zT_27;
    zT_29 = self->buckets_len;
    bucket_count = zT_29;
    bucket_count = zT_29;
    bucket_count = zT_29;
    zT_30 = 0;
    zT_31 = bucket_count == (unsigned int)zT_30;
    if (zT_31) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_32 = self;
    zT_34 = 8;
    zT_35 = (unsigned int)zT_34;
    zT_33 = zT_35;
    zF_3A9E8EDF_stringInternerGrowB(zT_32, zT_33);
    zT_36 = self->buckets_len;
    bucket_count = zT_36;
    bucket_count = zT_36;
    goto z_bb_4;
    z_bb_4:
    zT_38 = (unsigned int)bucket_count;
    zT_39 = hash % zT_38;
    bucket = zT_39;
    bucket = zT_39;
    bucket = zT_39;
    zT_41 = self->buckets_items;
    zT_42 = (unsigned int)bucket;
    zT_43 = zT_41[zT_42];
    idx = zT_43;
    idx = zT_43;
    idx = zT_43;
    goto z_bb_5;
    z_bb_5:
    zT_44 = 0;
    zT_45 = idx != (unsigned int)zT_44;
    if (zT_45) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_47 = self->entries_items;
    zT_48 = (unsigned int)idx;
    zT_49 = zT_47 + zT_48;
    entry = zT_49;
    entry = zT_49;
    entry = zT_49;
    zT_50 = entry->hash;
    zT_51 = zT_50 == hash;
    if (zT_51) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    zT_65 = self->entries_len;
    new_idx = zT_65;
    new_idx = zT_65;
    new_idx = zT_65;
    zT_67 = "INT:new";
    zT_69 = 7;
    zT_68.ptr = zT_67;
    zT_68.len = zT_69;
    innw_m = zT_68;
    innw_m = zT_68;
    innw_m = zT_68;
    zT_70 = innw_m;
    zT_72 = (unsigned int)new_idx;
    zT_71 = zT_72;
    zF_95B5C5CD_measureMarkerWriteI(zT_70, zT_71);
    zT_74 = self;
    zT_75 = text;
    zT_76 = zF_EDFF876E_stringInternerCopyT(zT_74, zT_75);
    copied = zT_76;
    copied = zT_76;
    copied = zT_76;
    zT_82 = &self->entries_items;
    zT_77 = zT_82;
    zT_83 = &self->entries_len;
    zT_78 = zT_83;
    zT_84 = &self->entries_capacity;
    zT_79 = zT_84;
    zT_85 = self->entries_allocator;
    zT_80 = zT_85;
    zT_88 = text.len;
    zT_89 = 0;
    zT_90 = copied + zT_89;
    zT_91 = zT_88 - zT_89;
    zT_92.ptr = zT_90;
    zT_92.len = zT_91;
    zT_86.text = zT_92;
    zT_86.hash = hash;
    zT_93 = self->buckets_items;
    zT_94 = (unsigned int)bucket;
    zT_95 = zT_93[zT_94];
    zT_86.next = zT_95;
    zT_81 = zT_86;
    zF_A7C4EDCF_appendEntry(zT_77, zT_78, zT_79, zT_80, zT_81);
    zT_96 = (unsigned int)new_idx;
    zT_97 = self->buckets_items;
    zT_98 = (unsigned int)bucket;
    zT_97[zT_98] = zT_96;
    zT_100 = self->entries_len;
    entry_count = zT_100;
    entry_count = zT_100;
    entry_count = zT_100;
    zT_101 = 2;
    zT_102 = entry_count * zT_101;
    zT_103 = zT_102 > bucket_count;
    if (zT_103) goto z_bb_14; else goto z_bb_15;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_55 = entry->text;
    zT_53 = zT_55;
    zT_54 = text;
    zT_56 = zF_B7662C9F_mem_eql(zT_53, zT_54);
    zT_52 = zT_56;
    goto z_bb_11;
    z_bb_10:
    zT_52 = 0;
    goto z_bb_11;
    z_bb_11:
    if (zT_52) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_58 = "INT:dup";
    zT_60 = 7;
    zT_59.ptr = zT_58;
    zT_59.len = zT_60;
    indp_m = zT_59;
    indp_m = zT_59;
    indp_m = zT_59;
    zT_61 = indp_m;
    zT_62 = idx;
    zF_C914CB83_markerWriteInt(zT_61, zT_62);
    return idx;
    z_bb_13:
    zT_63 = entry->next;
    idx = zT_63;
    idx = zT_63;
    goto z_bb_8;
    z_bb_14:
    zT_104 = self;
    zT_106 = 2;
    zT_107 = bucket_count * zT_106;
    zT_108 = (unsigned int)zT_107;
    zT_105 = zT_108;
    zF_3A9E8EDF_stringInternerGrowB(zT_104, zT_105);
    goto z_bb_15;
    z_bb_15:
    zT_109 = (unsigned int)new_idx;
    return zT_109;
}

/* stringInternerGet */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_9134020D_stringInternerGet(zT_D3EB6303_StringInterner* self, unsigned int id) {
    zT_EABC94D3_InternEntry* zT_2;
    unsigned int zT_3;
    zT_EABC94D3_InternEntry zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    zT_2 = self->entries_items;
    zT_3 = (unsigned int)id;
    zT_4 = zT_2[zT_3];
    zT_5 = zT_4.text;
    return zT_5;
}

/* stringInternerCopyToArena */
unsigned char* zF_EDFF876E_stringInternerCopyT(zT_D3EB6303_StringInterner* self, zT_8F083A69_Slice_zT_0B42B2F8_u text) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_171165BB_EU_812 zT_10 = {0};
    unsigned char zT_11;
    unsigned char* zT_12;
    unsigned char* zT_13;
    unsigned char* zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    unsigned char* raw;
    unsigned char c;
    unsigned int i;
    zT_6 = self->allocator;
    zT_3 = zT_6;
    zT_8 = text.len;
    zT_4 = zT_8;
    zT_9 = 1;
    zT_5 = zT_9;
    zT_10 = zF_1395EB68_sandAlloc(zT_3, zT_4, zT_5);
    zT_11 = zT_10.is_error;
    if (zT_11) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_13 = zT_10.data.payload;
    zT_12 = zT_13;
    goto z_bb_3;
    z_bb_3:
    raw = zT_12;
    raw = zT_12;
    raw = zT_12;
    zT_14 = text.ptr;
    zT_15 = text.len;
    i = 0;
    goto z_bb_4;
    z_bb_4:
    zT_17 = i < zT_15;
    if (zT_17) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    c = zT_14[i];
    raw[i] = c;
    zT_19 = 1;
    zT_20 = i + zT_19;
    i = zT_20;
    goto z_bb_4;
    z_bb_6:
    return raw;
}

/* stringInternerGrowBuckets */
void zF_3A9E8EDF_stringInternerGrowB(zT_D3EB6303_StringInterner* self, unsigned int new_bucket_count) {
    unsigned int zT_2;
    unsigned int** zT_3;
    unsigned int* zT_4;
    unsigned int* zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_7;
    unsigned int** zT_8;
    unsigned int* zT_9;
    unsigned int* zT_10;
    zT_3E40CD83_Sand* zT_11;
    int zT_13;
    unsigned int zT_14;
    int zT_15;
    int zT_16;
    unsigned int zT_17;
    unsigned int* zT_18;
    unsigned int zT_19;
    int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int zT_28;
    int zT_29;
    zT_EABC94D3_InternEntry* zT_31;
    unsigned int zT_32;
    zT_EABC94D3_InternEntry* zT_33;
    unsigned int zT_35;
    unsigned int zT_36;
    unsigned int* zT_37;
    unsigned int zT_38;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int* zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    unsigned int zT_45;
    unsigned int i;
    unsigned int ei;
    zT_EABC94D3_InternEntry* entry;
    unsigned int bucket;
    zT_2 = 0;
    self->buckets_len = zT_2;
    zT_8 = &self->buckets_items;
    zT_3 = zT_8;
    zT_9 = &self->buckets_len;
    zT_4 = zT_9;
    zT_10 = &self->buckets_capacity;
    zT_5 = zT_10;
    zT_11 = self->allocator;
    zT_6 = zT_11;
    zT_7 = new_bucket_count;
    zF_49E817CE_ensureCapacityBucke(zT_3, zT_4, zT_5, zT_6, zT_7);
    zT_13 = 0;
    zT_14 = (unsigned int)zT_13;
    i = zT_14;
    i = zT_14;
    i = zT_14;
    goto z_bb_1;
    z_bb_1:
    zT_15 = i < new_bucket_count;
    if (zT_15) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = 0;
    zT_17 = (unsigned int)zT_16;
    zT_18 = self->buckets_items;
    zT_19 = (unsigned int)i;
    zT_18[zT_19] = zT_17;
    zT_20 = 1;
    zT_21 = (unsigned int)zT_20;
    zT_22 = i + zT_21;
    i = zT_22;
    i = zT_22;
    goto z_bb_4;
    z_bb_3:
    zT_23 = (unsigned int)new_bucket_count;
    self->buckets_len = zT_23;
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    ei = zT_26;
    ei = zT_26;
    ei = zT_26;
    goto z_bb_5;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_27 = self->entries_len;
    zT_28 = (unsigned int)zT_27;
    zT_29 = ei < zT_28;
    if (zT_29) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_31 = self->entries_items;
    zT_32 = (unsigned int)ei;
    zT_33 = zT_31 + zT_32;
    entry = zT_33;
    entry = zT_33;
    entry = zT_33;
    zT_35 = entry->hash;
    zT_36 = zT_35 % new_bucket_count;
    bucket = zT_36;
    bucket = zT_36;
    bucket = zT_36;
    zT_37 = self->buckets_items;
    zT_38 = (unsigned int)bucket;
    zT_39 = zT_37[zT_38];
    entry->next = zT_39;
    zT_40 = (unsigned int)ei;
    zT_41 = self->buckets_items;
    zT_42 = (unsigned int)bucket;
    zT_41[zT_42] = zT_40;
    zT_43 = 1;
    zT_44 = (unsigned int)zT_43;
    zT_45 = ei + zT_44;
    ei = zT_45;
    ei = zT_45;
    goto z_bb_8;
    z_bb_7:
    return;
    z_bb_8:
    goto z_bb_5;
}

/* EOF */
