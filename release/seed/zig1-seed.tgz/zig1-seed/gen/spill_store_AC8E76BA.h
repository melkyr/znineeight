#ifndef ZIG_MODULE_SPILL_STORE_AC8E76BA_H
#define ZIG_MODULE_SPILL_STORE_AC8E76BA_H

#include "zig_compat.h"
#include "zig_special_types.h"
#include "allocator_E75B7A0B.h"
#include "pal_388A8A1B.h"
#include "panic_CE239B25.h"

#ifndef ZIG_ENUM_zT_F12DA458_SpillId
#define ZIG_ENUM_zT_F12DA458_SpillId
typedef unsigned char zT_F12DA458_SpillId;
#define zT_F12DA458_SpillId_s_ast 0
#define zT_F12DA458_SpillId_s_lir 1
#define zT_F12DA458_SpillId_s_hash 2
#define zT_F12DA458_SpillId_s_res 3
#define zT_F12DA458_SpillId_s_side 4

#endif /* ZIG_ENUM_zT_F12DA458_SpillId */

/* Forward declarations */
void zF_4EDF4E7B_spillSetLevel(unsigned int);
zT_0426DCE7_SpillBackend zF_1AA39172_spillBackendFor(zT_F12DA458_SpillId);
zT_D21A8776_SpillStore zF_22C79E6C_spillStoreInit(void);
void zF_7BAD89D9_ramEnsure(zT_D21A8776_SpillStore*, unsigned int);
void zF_8AF94F71_spillOpen(zT_D21A8776_SpillStore*, zT_0426DCE7_SpillBackend, zT_8F083A69_Slice_zT_0B42B2F8_u, zT_3E40CD83_Sand*, unsigned char*);
void zF_DB2CDC3B_spillClose(zT_D21A8776_SpillStore*);
void zF_56A911A9_spillSeek(zT_D21A8776_SpillStore*, unsigned int);
void zF_BFB33631_spillWriteAt(zT_D21A8776_SpillStore*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_E9F67450_spillReadAt(zT_D21A8776_SpillStore*, unsigned int, zT_8F083A69_Slice_zT_0B42B2F8_u);
void zF_780653D2___module_init_25(void);
/* Storage globals (extern decls) */
extern unsigned char zG_43DA845B_g_s_ast;
extern unsigned char zG_563B9F3C_g_s_lir;
extern unsigned char zG_B3E107B1_g_s_hash;
extern unsigned char zG_43E32C79_g_s_res;
extern unsigned char zG_189B793E_g_s_side;

#endif /* ZIG_MODULE_SPILL_STORE_AC8E76BA_H */
