#include "name_mangler_27ED89E2.h"
zT_CEC2984A_NameMangler zG_CEC2984A_NameMangler;
/* writeHex */
void zF_8F8DE819_writeHex(zT_8F083A69_Slice_zT_0B42B2F8_u buf, unsigned int* pos, unsigned int value) {
    zT_C1AB0454_Arr_unsigned_char_8 zT_5;
    unsigned int zT_7;
    unsigned int zT_11;
    unsigned int zT_14;
    unsigned char zT_19;
    unsigned int zT_20;
    unsigned char zT_25;
    unsigned int zT_26;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned char zT_33;
    unsigned char* zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    unsigned int zT_39;
    unsigned int zT_40;
    unsigned int v;
    zT_C1AB0454_Arr_unsigned_char_8 hex_buf;
    unsigned int i;
    unsigned int nibble;
    unsigned int j;
    v = value;
    {
    unsigned int _i = 0;
    while (_i < 8) {
        zT_5[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 8) {
        hex_buf[_i] = zT_5[_i];
        _i++;
    }
}
    zT_7 = 8;
    i = zT_7;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = i - (unsigned int)(1);
    i = zT_11;
    zT_14 = v & (unsigned int)(15);
    nibble = zT_14;
    if ((unsigned char)(nibble < (unsigned int)(10))) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_30 = 0;
    j = zT_30;
    goto z_bb_8;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_19 = (unsigned char)(48) + (unsigned char)((unsigned char)nibble);
    zT_20 = (unsigned int)i;
    hex_buf[zT_20] = zT_19;
    goto z_bb_6;
    z_bb_6:
    zT_28 = v >> (unsigned int)(4);
    v = zT_28;
    goto z_bb_4;
    z_bb_7:
    zT_25 = (unsigned char)(65) + (unsigned char)((unsigned char)(unsigned int)(nibble - (unsigned int)(10)));
    zT_26 = (unsigned int)i;
    hex_buf[zT_26] = zT_25;
    goto z_bb_6;
    z_bb_8:
    if ((unsigned char)(j < (unsigned int)(8))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_33 = hex_buf[j];
    zT_34 = buf.ptr;
    zT_35 = *pos;
    zT_37 = (unsigned int)((unsigned int)zT_35) + j;
    zT_34[zT_37] = zT_33;
    goto z_bb_11;
    z_bb_10:
    zT_40 = *pos;
    *pos = (unsigned int)(zT_40 + (unsigned int)(8));
    return;
    z_bb_11:
    zT_39 = j + (unsigned int)(1);
    j = zT_39;
    goto z_bb_8;
}

/* isTempOrBuiltin */
unsigned char zF_F2F86D29_isTempOrBuiltin(zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    unsigned int zT_2;
    unsigned char* zT_6;
    int zT_7;
    unsigned char zT_8;
    unsigned char zT_11;
    unsigned char* zT_12;
    int zT_13;
    unsigned char zT_14;
    unsigned char* zT_18;
    int zT_19;
    unsigned char zT_20;
    unsigned char zT_23;
    unsigned char* zT_24;
    int zT_25;
    unsigned char zT_26;
    unsigned char zT_29;
    unsigned char* zT_30;
    int zT_31;
    unsigned char zT_32;
    unsigned char* zT_36;
    int zT_37;
    unsigned char zT_38;
    unsigned char zT_41;
    unsigned char* zT_42;
    int zT_43;
    unsigned char zT_44;
    unsigned char zT_47;
    unsigned char* zT_48;
    int zT_49;
    unsigned char zT_50;
    unsigned int zT_55;
    unsigned char zT_58;
    unsigned char* zT_59;
    int zT_60;
    unsigned char zT_61;
    unsigned char zT_64;
    unsigned char* zT_65;
    int zT_66;
    unsigned char zT_67;
    unsigned char zT_70;
    unsigned char* zT_71;
    int zT_72;
    unsigned char zT_73;
    unsigned char zT_76;
    unsigned char* zT_77;
    int zT_78;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char* zT_83;
    int zT_84;
    unsigned char zT_85;
    unsigned char zT_88;
    unsigned char* zT_89;
    int zT_90;
    unsigned char zT_91;
    unsigned char zT_94;
    unsigned char* zT_95;
    int zT_96;
    unsigned char zT_97;
    unsigned char zT_100;
    unsigned char* zT_101;
    int zT_102;
    unsigned char zT_103;
    unsigned char zT_106;
    unsigned char* zT_107;
    int zT_108;
    unsigned char zT_109;
    zT_2 = name.len;
    if ((unsigned char)(zT_2 < (unsigned int)(5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = name.ptr;
    zT_7 = 0;
    zT_8 = zT_6[zT_7];
    if ((unsigned char)(zT_8 != (unsigned char)(95))) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    zT_12 = name.ptr;
    zT_13 = 1;
    zT_14 = zT_12[zT_13];
    zT_11 = zT_14 != (unsigned char)(95);
    goto z_bb_5;
    z_bb_4:
    zT_11 = 1;
    goto z_bb_5;
    z_bb_5:
    if (zT_11) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_18 = name.ptr;
    zT_19 = 2;
    zT_20 = zT_18[zT_19];
    if ((unsigned char)(zT_20 == (unsigned char)(116))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_24 = name.ptr;
    zT_25 = 3;
    zT_26 = zT_24[zT_25];
    zT_23 = zT_26 == (unsigned char)(109);
    goto z_bb_10;
    z_bb_9:
    zT_23 = 0;
    goto z_bb_10;
    z_bb_10:
    if (zT_23) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_30 = name.ptr;
    zT_31 = 4;
    zT_32 = zT_30[zT_31];
    zT_29 = zT_32 == (unsigned char)(112);
    goto z_bb_13;
    z_bb_12:
    zT_29 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_29) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return (unsigned char)(1);
    z_bb_15:
    zT_36 = name.ptr;
    zT_37 = 2;
    zT_38 = zT_36[zT_37];
    if ((unsigned char)(zT_38 == (unsigned char)(114))) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_42 = name.ptr;
    zT_43 = 3;
    zT_44 = zT_42[zT_43];
    zT_41 = zT_44 == (unsigned char)(101);
    goto z_bb_18;
    z_bb_17:
    zT_41 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_41) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_48 = name.ptr;
    zT_49 = 4;
    zT_50 = zT_48[zT_49];
    zT_47 = zT_50 == (unsigned char)(116);
    goto z_bb_21;
    z_bb_20:
    zT_47 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_47) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    return (unsigned char)(1);
    z_bb_23:
    zT_55 = name.len;
    if ((unsigned char)(zT_55 >= (unsigned int)(11))) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_59 = name.ptr;
    zT_60 = 2;
    zT_61 = zT_59[zT_60];
    zT_58 = zT_61 == (unsigned char)(98);
    goto z_bb_26;
    z_bb_25:
    zT_58 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_58) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_65 = name.ptr;
    zT_66 = 3;
    zT_67 = zT_65[zT_66];
    zT_64 = zT_67 == (unsigned char)(111);
    goto z_bb_29;
    z_bb_28:
    zT_64 = 0;
    goto z_bb_29;
    z_bb_29:
    if (zT_64) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_71 = name.ptr;
    zT_72 = 4;
    zT_73 = zT_71[zT_72];
    zT_70 = zT_73 == (unsigned char)(111);
    goto z_bb_32;
    z_bb_31:
    zT_70 = 0;
    goto z_bb_32;
    z_bb_32:
    if (zT_70) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_77 = name.ptr;
    zT_78 = 5;
    zT_79 = zT_77[zT_78];
    zT_76 = zT_79 == (unsigned char)(116);
    goto z_bb_35;
    z_bb_34:
    zT_76 = 0;
    goto z_bb_35;
    z_bb_35:
    if (zT_76) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_83 = name.ptr;
    zT_84 = 6;
    zT_85 = zT_83[zT_84];
    zT_82 = zT_85 == (unsigned char)(115);
    goto z_bb_38;
    z_bb_37:
    zT_82 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_82) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_89 = name.ptr;
    zT_90 = 7;
    zT_91 = zT_89[zT_90];
    zT_88 = zT_91 == (unsigned char)(116);
    goto z_bb_41;
    z_bb_40:
    zT_88 = 0;
    goto z_bb_41;
    z_bb_41:
    if (zT_88) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_95 = name.ptr;
    zT_96 = 8;
    zT_97 = zT_95[zT_96];
    zT_94 = zT_97 == (unsigned char)(114);
    goto z_bb_44;
    z_bb_43:
    zT_94 = 0;
    goto z_bb_44;
    z_bb_44:
    if (zT_94) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_101 = name.ptr;
    zT_102 = 9;
    zT_103 = zT_101[zT_102];
    zT_100 = zT_103 == (unsigned char)(97);
    goto z_bb_47;
    z_bb_46:
    zT_100 = 0;
    goto z_bb_47;
    z_bb_47:
    if (zT_100) goto z_bb_48; else goto z_bb_49;
    z_bb_48:
    zT_107 = name.ptr;
    zT_108 = 10;
    zT_109 = zT_107[zT_108];
    zT_106 = zT_109 == (unsigned char)(112);
    goto z_bb_50;
    z_bb_49:
    zT_106 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_106) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    return (unsigned char)(1);
    z_bb_52:
    return (unsigned char)(0);
}

/* isC89Keyword */
unsigned char zF_5412D014_isC89Keyword(zT_CEC2984A_NameMangler* self, unsigned int name_id) {
    zT_21D3708C_U32ToU32Map* zT_2;
    unsigned int zT_3;
    zT_BAEE192E_Opt_10 zT_5 = {0};
    unsigned char zT_6;
    zT_2 = &self->keyword_set;
    zT_3 = name_id;
    zT_5 = zF_F3EE5998_u32ToU32MapGet(zT_2, zT_3);
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    return (unsigned char)(0);
}

/* mangleC89Keyword */
unsigned int zF_C3DD2126_mangleC89Keyword(zT_CEC2984A_NameMangler* self, zT_8F083A69_Slice_zT_0B42B2F8_u name) {
    zT_472B2232_Arr_unsigned_char_3 zT_3;
    unsigned char zT_4;
    int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned char zT_13;
    unsigned char* zT_18;
    unsigned char zT_19;
    unsigned int zT_21;
    unsigned int zT_23;
    zT_D3EB6303_StringInterner* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    int zT_31;
    unsigned char* zT_32;
    unsigned int zT_33;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_34;
    unsigned int zT_35 = 0;
    zT_472B2232_Arr_unsigned_char_3 buf;
    unsigned int i;
    {
    unsigned int _i = 0;
    while (_i < 33) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 33) {
        buf[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 122;
    zT_5 = 0;
    buf[zT_5] = zT_4;
    zT_6 = 95;
    zT_7 = 1;
    buf[zT_7] = zT_6;
    zT_9 = 0;
    i = zT_9;
    goto z_bb_1;
    z_bb_1:
    zT_11 = name.len;
    if ((unsigned char)(i < zT_11)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_18 = name.ptr;
    zT_19 = zT_18[i];
    zT_21 = i + (unsigned int)(2);
    buf[zT_21] = zT_19;
    goto z_bb_4;
    z_bb_3:
    zT_24 = self->interner;
    zT_31 = 0;
    zT_32 = (unsigned char*)((unsigned char*)buf) + zT_31;
    zT_33 = (unsigned int)(i + (unsigned int)(2)) - zT_31;
    zT_34.ptr = (unsigned char*)zT_32;
    zT_34.len = zT_33;
    zT_25 = zT_34;
    zT_35 = zF_50C274AF_stringInternerInter(zT_24, zT_25);
    return zT_35;
    z_bb_4:
    zT_23 = i + (unsigned int)(1);
    i = zT_23;
    goto z_bb_1;
    z_bb_5:
    zT_13 = (unsigned int)(i + (unsigned int)(2)) < (unsigned int)(33);
    goto z_bb_7;
    z_bb_6:
    zT_13 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_13) goto z_bb_2; else goto z_bb_3;
}

/* nameManglerPopulateKeywords */
void zF_F82AFAD8_nameManglerPopulate(zT_CEC2984A_NameMangler* self) {
    unsigned char* zT_2;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_3;
    unsigned int zT_4;
    unsigned char* zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_7;
    unsigned int zT_8;
    unsigned char* zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12;
    unsigned char* zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    unsigned char* zT_26;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_27;
    unsigned int zT_28;
    unsigned char* zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    unsigned char* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_40;
    unsigned char* zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43;
    unsigned int zT_44;
    unsigned char* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48;
    unsigned char* zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_51;
    unsigned int zT_52;
    unsigned char* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_56;
    unsigned char* zT_58;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_59;
    unsigned int zT_60;
    unsigned char* zT_62;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_63;
    unsigned int zT_64;
    unsigned char* zT_66;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_67;
    unsigned int zT_68;
    unsigned char* zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int zT_72;
    unsigned char* zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76;
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    unsigned char* zT_82;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_83;
    unsigned int zT_84;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    unsigned char* zT_94;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_95;
    unsigned int zT_96;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    unsigned char* zT_102;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_103;
    unsigned int zT_104;
    unsigned char* zT_106;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_107;
    unsigned int zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    unsigned char* zT_114;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_115;
    unsigned int zT_116;
    unsigned char* zT_118;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_119;
    unsigned int zT_120;
    unsigned char* zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_B470B754_Arr_zT_8F083A69_Sli zT_130;
    unsigned int zT_131;
    unsigned int zT_132;
    unsigned int zT_133;
    unsigned int zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    unsigned int zT_137;
    unsigned int zT_138;
    unsigned int zT_139;
    unsigned int zT_140;
    unsigned int zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    unsigned int zT_150;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_157;
    unsigned int zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_161;
    unsigned int zT_162;
    unsigned int zT_164;
    zT_21D3708C_U32ToU32Map* zT_168;
    unsigned int zT_169;
    zT_D3EB6303_StringInterner* zT_172;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_173;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_175;
    unsigned int zT_176 = 0;
    unsigned int zT_179;
    zT_8F083A69_Slice_zT_0B42B2F8_u k0;
    zT_8F083A69_Slice_zT_0B42B2F8_u k1;
    zT_8F083A69_Slice_zT_0B42B2F8_u k2;
    zT_8F083A69_Slice_zT_0B42B2F8_u k3;
    zT_8F083A69_Slice_zT_0B42B2F8_u k4;
    zT_8F083A69_Slice_zT_0B42B2F8_u k5;
    zT_8F083A69_Slice_zT_0B42B2F8_u k6;
    zT_8F083A69_Slice_zT_0B42B2F8_u k7;
    zT_8F083A69_Slice_zT_0B42B2F8_u k8;
    zT_8F083A69_Slice_zT_0B42B2F8_u k9;
    zT_8F083A69_Slice_zT_0B42B2F8_u k10;
    zT_8F083A69_Slice_zT_0B42B2F8_u k11;
    zT_8F083A69_Slice_zT_0B42B2F8_u k12;
    zT_8F083A69_Slice_zT_0B42B2F8_u k13;
    zT_8F083A69_Slice_zT_0B42B2F8_u k14;
    zT_8F083A69_Slice_zT_0B42B2F8_u k15;
    zT_8F083A69_Slice_zT_0B42B2F8_u k16;
    zT_8F083A69_Slice_zT_0B42B2F8_u k17;
    zT_8F083A69_Slice_zT_0B42B2F8_u k18;
    zT_8F083A69_Slice_zT_0B42B2F8_u k19;
    zT_8F083A69_Slice_zT_0B42B2F8_u k20;
    zT_8F083A69_Slice_zT_0B42B2F8_u k21;
    zT_8F083A69_Slice_zT_0B42B2F8_u k22;
    zT_8F083A69_Slice_zT_0B42B2F8_u k23;
    zT_8F083A69_Slice_zT_0B42B2F8_u k24;
    zT_8F083A69_Slice_zT_0B42B2F8_u k25;
    zT_8F083A69_Slice_zT_0B42B2F8_u k26;
    zT_8F083A69_Slice_zT_0B42B2F8_u k27;
    zT_8F083A69_Slice_zT_0B42B2F8_u k28;
    zT_8F083A69_Slice_zT_0B42B2F8_u k29;
    zT_8F083A69_Slice_zT_0B42B2F8_u k30;
    zT_8F083A69_Slice_zT_0B42B2F8_u k31;
    zT_B470B754_Arr_zT_8F083A69_Sli keywords;
    unsigned int ki;
    zT_2 = "auto";
    zT_4 = 4;
    zT_3.ptr = (unsigned char*)zT_2;
    zT_3.len = zT_4;
    k0 = zT_3;
    zT_6 = "break";
    zT_8 = 5;
    zT_7.ptr = (unsigned char*)zT_6;
    zT_7.len = zT_8;
    k1 = zT_7;
    zT_10 = "case";
    zT_12 = 4;
    zT_11.ptr = (unsigned char*)zT_10;
    zT_11.len = zT_12;
    k2 = zT_11;
    zT_14 = "char";
    zT_16 = 4;
    zT_15.ptr = (unsigned char*)zT_14;
    zT_15.len = zT_16;
    k3 = zT_15;
    zT_18 = "const";
    zT_20 = 5;
    zT_19.ptr = (unsigned char*)zT_18;
    zT_19.len = zT_20;
    k4 = zT_19;
    zT_22 = "continue";
    zT_24 = 8;
    zT_23.ptr = (unsigned char*)zT_22;
    zT_23.len = zT_24;
    k5 = zT_23;
    zT_26 = "default";
    zT_28 = 7;
    zT_27.ptr = (unsigned char*)zT_26;
    zT_27.len = zT_28;
    k6 = zT_27;
    zT_30 = "do";
    zT_32 = 2;
    zT_31.ptr = (unsigned char*)zT_30;
    zT_31.len = zT_32;
    k7 = zT_31;
    zT_34 = "double";
    zT_36 = 6;
    zT_35.ptr = (unsigned char*)zT_34;
    zT_35.len = zT_36;
    k8 = zT_35;
    zT_38 = "else";
    zT_40 = 4;
    zT_39.ptr = (unsigned char*)zT_38;
    zT_39.len = zT_40;
    k9 = zT_39;
    zT_42 = "enum";
    zT_44 = 4;
    zT_43.ptr = (unsigned char*)zT_42;
    zT_43.len = zT_44;
    k10 = zT_43;
    zT_46 = "extern";
    zT_48 = 6;
    zT_47.ptr = (unsigned char*)zT_46;
    zT_47.len = zT_48;
    k11 = zT_47;
    zT_50 = "float";
    zT_52 = 5;
    zT_51.ptr = (unsigned char*)zT_50;
    zT_51.len = zT_52;
    k12 = zT_51;
    zT_54 = "for";
    zT_56 = 3;
    zT_55.ptr = (unsigned char*)zT_54;
    zT_55.len = zT_56;
    k13 = zT_55;
    zT_58 = "goto";
    zT_60 = 4;
    zT_59.ptr = (unsigned char*)zT_58;
    zT_59.len = zT_60;
    k14 = zT_59;
    zT_62 = "if";
    zT_64 = 2;
    zT_63.ptr = (unsigned char*)zT_62;
    zT_63.len = zT_64;
    k15 = zT_63;
    zT_66 = "int";
    zT_68 = 3;
    zT_67.ptr = (unsigned char*)zT_66;
    zT_67.len = zT_68;
    k16 = zT_67;
    zT_70 = "long";
    zT_72 = 4;
    zT_71.ptr = (unsigned char*)zT_70;
    zT_71.len = zT_72;
    k17 = zT_71;
    zT_74 = "register";
    zT_76 = 8;
    zT_75.ptr = (unsigned char*)zT_74;
    zT_75.len = zT_76;
    k18 = zT_75;
    zT_78 = "return";
    zT_80 = 6;
    zT_79.ptr = (unsigned char*)zT_78;
    zT_79.len = zT_80;
    k19 = zT_79;
    zT_82 = "short";
    zT_84 = 5;
    zT_83.ptr = (unsigned char*)zT_82;
    zT_83.len = zT_84;
    k20 = zT_83;
    zT_86 = "signed";
    zT_88 = 6;
    zT_87.ptr = (unsigned char*)zT_86;
    zT_87.len = zT_88;
    k21 = zT_87;
    zT_90 = "sizeof";
    zT_92 = 6;
    zT_91.ptr = (unsigned char*)zT_90;
    zT_91.len = zT_92;
    k22 = zT_91;
    zT_94 = "static";
    zT_96 = 6;
    zT_95.ptr = (unsigned char*)zT_94;
    zT_95.len = zT_96;
    k23 = zT_95;
    zT_98 = "struct";
    zT_100 = 6;
    zT_99.ptr = (unsigned char*)zT_98;
    zT_99.len = zT_100;
    k24 = zT_99;
    zT_102 = "switch";
    zT_104 = 6;
    zT_103.ptr = (unsigned char*)zT_102;
    zT_103.len = zT_104;
    k25 = zT_103;
    zT_106 = "typedef";
    zT_108 = 7;
    zT_107.ptr = (unsigned char*)zT_106;
    zT_107.len = zT_108;
    k26 = zT_107;
    zT_110 = "union";
    zT_112 = 5;
    zT_111.ptr = (unsigned char*)zT_110;
    zT_111.len = zT_112;
    k27 = zT_111;
    zT_114 = "unsigned";
    zT_116 = 8;
    zT_115.ptr = (unsigned char*)zT_114;
    zT_115.len = zT_116;
    k28 = zT_115;
    zT_118 = "void";
    zT_120 = 4;
    zT_119.ptr = (unsigned char*)zT_118;
    zT_119.len = zT_120;
    k29 = zT_119;
    zT_122 = "volatile";
    zT_124 = 8;
    zT_123.ptr = (unsigned char*)zT_122;
    zT_123.len = zT_124;
    k30 = zT_123;
    zT_126 = "while";
    zT_128 = 5;
    zT_127.ptr = (unsigned char*)zT_126;
    zT_127.len = zT_128;
    k31 = zT_127;
    zT_131 = 0;
    zT_130[zT_131] = k0;
    zT_132 = 1;
    zT_130[zT_132] = k1;
    zT_133 = 2;
    zT_130[zT_133] = k2;
    zT_134 = 3;
    zT_130[zT_134] = k3;
    zT_135 = 4;
    zT_130[zT_135] = k4;
    zT_136 = 5;
    zT_130[zT_136] = k5;
    zT_137 = 6;
    zT_130[zT_137] = k6;
    zT_138 = 7;
    zT_130[zT_138] = k7;
    zT_139 = 8;
    zT_130[zT_139] = k8;
    zT_140 = 9;
    zT_130[zT_140] = k9;
    zT_141 = 10;
    zT_130[zT_141] = k10;
    zT_142 = 11;
    zT_130[zT_142] = k11;
    zT_143 = 12;
    zT_130[zT_143] = k12;
    zT_144 = 13;
    zT_130[zT_144] = k13;
    zT_145 = 14;
    zT_130[zT_145] = k14;
    zT_146 = 15;
    zT_130[zT_146] = k15;
    zT_147 = 16;
    zT_130[zT_147] = k16;
    zT_148 = 17;
    zT_130[zT_148] = k17;
    zT_149 = 18;
    zT_130[zT_149] = k18;
    zT_150 = 19;
    zT_130[zT_150] = k19;
    zT_151 = 20;
    zT_130[zT_151] = k20;
    zT_152 = 21;
    zT_130[zT_152] = k21;
    zT_153 = 22;
    zT_130[zT_153] = k22;
    zT_154 = 23;
    zT_130[zT_154] = k23;
    zT_155 = 24;
    zT_130[zT_155] = k24;
    zT_156 = 25;
    zT_130[zT_156] = k25;
    zT_157 = 26;
    zT_130[zT_157] = k26;
    zT_158 = 27;
    zT_130[zT_158] = k27;
    zT_159 = 28;
    zT_130[zT_159] = k28;
    zT_160 = 29;
    zT_130[zT_160] = k29;
    zT_161 = 30;
    zT_130[zT_161] = k30;
    zT_162 = 31;
    zT_130[zT_162] = k31;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        keywords[_i] = zT_130[_i];
        _i++;
    }
}
    zT_164 = 0;
    ki = zT_164;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(ki < (unsigned int)(32))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_168 = &self->keyword_set;
    zT_172 = self->interner;
    zT_175 = keywords[ki];
    zT_173 = zT_175;
    zT_176 = zF_50C274AF_stringInternerInter(zT_172, zT_173);
    zT_169 = zT_176;
    zF_26476265_u32ToU32MapPut(zT_168, zT_169, (unsigned int)(1));
    goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_179 = ki + (unsigned int)(1);
    ki = zT_179;
    goto z_bb_1;
}

/* nameManglerInit */
zT_CEC2984A_NameMangler zF_27DA3900_nameManglerInit_1(zT_D3EB6303_StringInterner* interner, zT_3E40CD83_Sand* alloc, unsigned int cache_hint) {
    zT_CEC2984A_NameMangler zT_4;
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_6;
    unsigned int zT_7;
    zT_A4CE86B7_U64ToU32Map zT_8 = {0};
    zT_3E40CD83_Sand* zT_9;
    zT_21D3708C_U32ToU32Map zT_12 = {0};
    zT_3E40CD83_Sand* zT_13;
    zT_21D3708C_U32ToU32Map zT_14 = {0};
    zT_3E40CD83_Sand* zT_15;
    zT_21D3708C_U32ToU32Map zT_16 = {0};
    zT_F0990B59_Opt_343 zT_17 = {0};
    zT_3E40CD83_Sand* zT_18;
    zT_A4CE86B7_U64ToU32Map zT_19 = {0};
    zT_3E40CD83_Sand* zT_20;
    zT_A4CE86B7_U64ToU32Map zT_21 = {0};
    zT_3E40CD83_Sand* zT_22;
    zT_A4CE86B7_U64ToU32Map zT_23 = {0};
    zT_3E40CD83_Sand* zT_24;
    zT_A4CE86B7_U64ToU32Map zT_25 = {0};
    zT_3E40CD83_Sand* zT_26;
    zT_A4CE86B7_U64ToU32Map zT_27 = {0};
    zT_3E40CD83_Sand* zT_28;
    zT_A4CE86B7_U64ToU32Map zT_29 = {0};
    zT_CEC2984A_NameMangler* zT_30;
    zT_CEC2984A_NameMangler mangler;
    zT_5 = 0;
    zT_4.hash_seed = zT_5;
    zT_6 = alloc;
    zT_7 = cache_hint;
    zT_8 = zF_CE4144CF_u64ToU32MapInitCap(zT_6, zT_7);
    zT_4.cache = zT_8;
    zT_9 = alloc;
    zT_12 = zF_619D56E6_u32ToU32MapInitCap(zT_9, (unsigned int)(32));
    zT_4.keyword_set = zT_12;
    zT_13 = alloc;
    zT_14 = zF_58BDA2DE_u32ToU32MapInit(zT_13);
    zT_4.collision_mod = zT_14;
    zT_15 = alloc;
    zT_16 = zF_58BDA2DE_u32ToU32MapInit(zT_15);
    zT_4.collision_name = zT_16;
    zT_4.interner = interner;
    zT_17.has_value = 0;
    zT_4.exported = zT_17;
    zT_18 = alloc;
    zT_19 = zF_986226E1_u64ToU32MapInit(zT_18);
    zT_4.raw_cache_local = zT_19;
    zT_20 = alloc;
    zT_21 = zF_986226E1_u64ToU32MapInit(zT_20);
    zT_4.raw_taken_local = zT_21;
    zT_22 = alloc;
    zT_23 = zF_986226E1_u64ToU32MapInit(zT_22);
    zT_4.raw_cache_field = zT_23;
    zT_24 = alloc;
    zT_25 = zF_986226E1_u64ToU32MapInit(zT_24);
    zT_4.raw_taken_field = zT_25;
    zT_26 = alloc;
    zT_27 = zF_986226E1_u64ToU32MapInit(zT_26);
    zT_4.raw_cache_member = zT_27;
    zT_28 = alloc;
    zT_29 = zF_986226E1_u64ToU32MapInit(zT_28);
    zT_4.raw_taken_member = zT_29;
    mangler = zT_4;
    zT_30 = (zT_CEC2984A_NameMangler*)&mangler;
    zF_F82AFAD8_nameManglerPopulate(zT_30);
    return mangler;
}

/* nameManglerMangle */
unsigned int zF_713D1938_nameManglerMangle(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned char kind, unsigned int module_id) {
    zT_D3EB6303_StringInterner* zT_5;
    unsigned int zT_6;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8 = {0};
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_9;
    unsigned char zT_10 = 0;
    zT_CEC2984A_NameMangler* zT_13;
    unsigned int zT_14;
    unsigned char zT_15 = 0;
    zT_CEC2984A_NameMangler* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20 = 0;
    zT_79FAE712_u64 zT_30;
    zT_F0990B59_Opt_343 zT_31;
    unsigned char zT_32;
    zT_A4CE86B7_U64ToU32Map* zT_34;
    zT_79FAE712_u64 zT_35;
    zT_BAEE192E_Opt_10 zT_36 = {0};
    unsigned char zT_37;
    zT_A4CE86B7_U64ToU32Map* zT_39;
    zT_79FAE712_u64 zT_40;
    zT_BAEE192E_Opt_10 zT_42 = {0};
    unsigned char zT_43;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_46;
    unsigned int zT_47 = 0;
    unsigned char zT_49;
    unsigned char zT_52;
    unsigned char zT_55;
    unsigned char zT_58;
    zT_482B23C5_Arr_unsigned_char_3 zT_60;
    unsigned int zT_62;
    unsigned char zT_63;
    unsigned int zT_65;
    unsigned int zT_67;
    unsigned char zT_68;
    unsigned int zT_70;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_71;
    unsigned int* zT_72;
    unsigned int zT_73;
    int zT_76;
    unsigned char* zT_77;
    unsigned int zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned char zT_81;
    unsigned int zT_83;
    unsigned int zT_86;
    unsigned int zT_88;
    unsigned char zT_90;
    unsigned char* zT_93;
    unsigned char zT_94;
    unsigned int zT_96;
    unsigned int zT_98;
    unsigned int zT_101;
    zT_D3EB6303_StringInterner* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    int zT_108;
    unsigned char* zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112 = 0;
    unsigned int zT_114;
    zT_21D3708C_U32ToU32Map* zT_117;
    unsigned int zT_118;
    zT_BAEE192E_Opt_10 zT_120 = {0};
    unsigned char zT_121;
    unsigned int zT_124;
    unsigned int zT_127;
    unsigned int zT_131;
    unsigned int zT_133;
    unsigned int zT_140;
    unsigned int zT_142;
    unsigned int zT_144;
    unsigned char zT_146;
    unsigned char* zT_149;
    unsigned char zT_150;
    unsigned int zT_152;
    unsigned int zT_154;
    unsigned char zT_155;
    unsigned int zT_157;
    zT_B5AAF170_Arr_unsigned_char_4 zT_160;
    unsigned int zT_162;
    unsigned char zT_169;
    unsigned int zT_170;
    unsigned int zT_172;
    unsigned int zT_174;
    unsigned char zT_177;
    unsigned int zT_179;
    unsigned int zT_184;
    unsigned int zT_185;
    unsigned char zT_186;
    unsigned int zT_188;
    unsigned int zT_191;
    zT_D3EB6303_StringInterner* zT_192;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_193;
    int zT_197;
    unsigned char* zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned int zT_201 = 0;
    zT_21D3708C_U32ToU32Map* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    zT_21D3708C_U32ToU32Map* zT_206;
    unsigned int zT_207;
    unsigned int zT_208;
    zT_A4CE86B7_U64ToU32Map* zT_210;
    zT_79FAE712_u64 zT_211;
    unsigned int zT_212;
    zT_8F083A69_Slice_zT_0B42B2F8_u name;
    zT_79FAE712_u64 key;
    zT_A4CE86B7_U64ToU32Map* exp_map;
    unsigned int cached;
    unsigned int hash;
    unsigned char kind_char;
    zT_482B23C5_Arr_unsigned_char_3 buf;
    unsigned int p;
    unsigned int prefix_end;
    unsigned int idx;
    unsigned int mangled_id;
    unsigned int counter;
    zT_BAEE192E_Opt_10 existing_mod;
    unsigned int cnt;
    unsigned int dc;
    unsigned int max_nc;
    unsigned int ci;
    unsigned int cv;
    zT_B5AAF170_Arr_unsigned_char_4 cd;
    unsigned int di;
    unsigned int dk;
    zT_5 = self->interner;
    zT_6 = name_id;
    zT_8 = zF_9134020D_stringInternerGet(zT_5, zT_6);
    name = zT_8;
    zT_9 = name;
    zT_10 = zF_F2F86D29_isTempOrBuiltin(zT_9);
    if ((unsigned char)(zT_10 != (unsigned char)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return name_id;
    z_bb_2:
    zT_13 = self;
    zT_14 = name_id;
    zT_15 = zF_5412D014_isC89Keyword(zT_13, zT_14);
    if ((unsigned char)(zT_15 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_18 = self;
    zT_19 = name;
    zT_20 = zF_C3DD2126_mangleC89Keyword(zT_18, zT_19);
    return zT_20;
    z_bb_4:
    zT_30 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)module_id) << (zT_79FAE712_u64)(35)) | (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)kind) << (zT_79FAE712_u64)(32))) | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    key = zT_30;
    zT_31 = self->exported;
    zT_32 = zT_31.has_value;
    if (zT_32) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    exp_map = zT_31.value;
    zT_34 = exp_map;
    zT_35 = key;
    zT_36 = zF_A05A7BE1_u64ToU32MapGet(zT_34, zT_35);
    zT_37 = zT_36.has_value;
    if (zT_37) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_39 = &self->cache;
    zT_40 = key;
    zT_42 = zF_A05A7BE1_u64ToU32MapGet(zT_39, zT_40);
    zT_43 = zT_42.has_value;
    if (zT_43) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    return name_id;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    cached = zT_42.value;
    return cached;
    z_bb_10:
    zT_46 = name;
    zT_47 = zF_B22E025B_fnv1a(zT_46);
    hash = zT_47;
    zT_49 = 76;
    kind_char = zT_49;
    if ((unsigned char)(kind == (unsigned char)(0))) goto z_bb_11; else goto z_bb_13;
    z_bb_11:
    zT_52 = 70;
    kind_char = zT_52;
    goto z_bb_12;
    z_bb_12:
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_60[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        buf[_i] = zT_60[_i];
        _i++;
    }
}
    zT_62 = 0;
    p = zT_62;
    zT_63 = 122;
    buf[p] = zT_63;
    zT_65 = p + (unsigned int)(1);
    p = zT_65;
    buf[p] = kind_char;
    zT_67 = p + (unsigned int)(1);
    p = zT_67;
    zT_68 = 95;
    buf[p] = zT_68;
    zT_70 = p + (unsigned int)(1);
    p = zT_70;
    zT_76 = 0;
    zT_77 = (unsigned char*)((unsigned char*)buf) + zT_76;
    zT_78 = (unsigned int)(32) - zT_76;
    zT_79.ptr = (unsigned char*)zT_77;
    zT_79.len = zT_78;
    zT_71 = zT_79;
    zT_72 = (unsigned int*)&p;
    zT_73 = hash;
    zF_8F8DE819_writeHex(zT_71, zT_72, zT_73);
    zT_81 = 95;
    buf[p] = zT_81;
    zT_83 = p + (unsigned int)(1);
    p = zT_83;
    prefix_end = p;
    zT_86 = 0;
    idx = zT_86;
    goto z_bb_19;
    z_bb_13:
    if ((unsigned char)(kind == (unsigned char)(1))) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    zT_55 = 71;
    kind_char = zT_55;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    if ((unsigned char)(kind == (unsigned char)(2))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_58 = 84;
    kind_char = zT_58;
    goto z_bb_18;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_88 = name.len;
    if ((unsigned char)(idx < zT_88)) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_93 = name.ptr;
    zT_94 = zT_93[idx];
    buf[p] = zT_94;
    zT_96 = p + (unsigned int)(1);
    p = zT_96;
    goto z_bb_22;
    z_bb_21:
    if ((unsigned char)(p > (unsigned int)(31))) goto z_bb_26; else goto z_bb_27;
    z_bb_22:
    zT_98 = idx + (unsigned int)(1);
    idx = zT_98;
    goto z_bb_19;
    z_bb_23:
    zT_90 = p < (unsigned int)(31);
    goto z_bb_25;
    z_bb_24:
    zT_90 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_90) goto z_bb_20; else goto z_bb_21;
    z_bb_26:
    zT_101 = 31;
    p = zT_101;
    goto z_bb_27;
    z_bb_27:
    zT_103 = self->interner;
    zT_108 = 0;
    zT_109 = (unsigned char*)((unsigned char*)buf) + zT_108;
    zT_110 = p - zT_108;
    zT_111.ptr = (unsigned char*)zT_109;
    zT_111.len = zT_110;
    zT_104 = zT_111;
    zT_112 = zF_50C274AF_stringInternerInter(zT_103, zT_104);
    mangled_id = zT_112;
    zT_114 = 0;
    counter = zT_114;
    goto z_bb_28;
    z_bb_28:
    if ((unsigned char)(1)) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_117 = &self->collision_mod;
    zT_118 = mangled_id;
    zT_120 = zF_F3EE5998_u32ToU32MapGet(zT_117, zT_118);
    existing_mod = zT_120;
    zT_121 = existing_mod.has_value;
    if (zT_121) goto z_bb_32; else goto z_bb_34;
    z_bb_30:
    zT_202 = &self->collision_mod;
    zT_203 = mangled_id;
    zT_204 = module_id;
    zF_26476265_u32ToU32MapPut(zT_202, zT_203, zT_204);
    zT_206 = &self->collision_name;
    zT_207 = mangled_id;
    zT_208 = name_id;
    zF_26476265_u32ToU32MapPut(zT_206, zT_207, zT_208);
    zT_210 = &self->cache;
    zT_211 = key;
    zT_212 = mangled_id;
    zF_B6EB812C_u64ToU32MapPut(zT_210, zT_211, zT_212);
    return mangled_id;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_124 = counter + (unsigned int)(1);
    counter = zT_124;
    p = prefix_end;
    cnt = counter;
    zT_127 = 1;
    dc = zT_127;
    goto z_bb_35;
    z_bb_33:
    goto z_bb_31;
    z_bb_34:
    goto z_bb_30;
    z_bb_35:
    if ((unsigned char)(cnt >= (unsigned int)(10))) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_131 = dc + (unsigned int)(1);
    dc = zT_131;
    goto z_bb_38;
    z_bb_37:
    zT_140 = (unsigned int)((unsigned int)((unsigned int)(31) - prefix_end) - (unsigned int)(1)) - (unsigned int)((unsigned int)dc);
    max_nc = zT_140;
    zT_142 = 0;
    ci = zT_142;
    goto z_bb_39;
    z_bb_38:
    zT_133 = cnt / (unsigned int)(10);
    cnt = zT_133;
    goto z_bb_35;
    z_bb_39:
    zT_144 = name.len;
    if ((unsigned char)(ci < zT_144)) goto z_bb_43; else goto z_bb_44;
    z_bb_40:
    zT_149 = name.ptr;
    zT_150 = zT_149[ci];
    buf[p] = zT_150;
    zT_152 = p + (unsigned int)(1);
    p = zT_152;
    goto z_bb_42;
    z_bb_41:
    zT_155 = 95;
    buf[p] = zT_155;
    zT_157 = p + (unsigned int)(1);
    p = zT_157;
    cv = counter;
    {
    unsigned int _i = 0;
    while (_i < 4) {
        zT_160[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 4) {
        cd[_i] = zT_160[_i];
        _i++;
    }
}
    zT_162 = 0;
    di = zT_162;
    goto z_bb_46;
    z_bb_42:
    zT_154 = ci + (unsigned int)(1);
    ci = zT_154;
    goto z_bb_39;
    z_bb_43:
    zT_146 = p < (unsigned int)(prefix_end + max_nc);
    goto z_bb_45;
    z_bb_44:
    zT_146 = 0;
    goto z_bb_45;
    z_bb_45:
    if (zT_146) goto z_bb_40; else goto z_bb_41;
    z_bb_46:
    if ((unsigned char)(cv > (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_47:
    zT_169 = (unsigned char)(48) + (unsigned char)((unsigned char)(unsigned int)(cv % (unsigned int)(10)));
    zT_170 = (unsigned int)di;
    cd[zT_170] = zT_169;
    zT_172 = cv / (unsigned int)(10);
    cv = zT_172;
    zT_174 = di + (unsigned int)(1);
    di = zT_174;
    goto z_bb_49;
    z_bb_48:
    if ((unsigned char)(di == (unsigned int)(0))) goto z_bb_50; else goto z_bb_52;
    z_bb_49:
    goto z_bb_46;
    z_bb_50:
    zT_177 = 48;
    buf[p] = zT_177;
    zT_179 = p + (unsigned int)(1);
    p = zT_179;
    goto z_bb_51;
    z_bb_51:
    if ((unsigned char)(p > (unsigned int)(31))) goto z_bb_57; else goto z_bb_58;
    z_bb_52:
    dk = di;
    goto z_bb_53;
    z_bb_53:
    if ((unsigned char)(dk > (unsigned int)(0))) goto z_bb_54; else goto z_bb_55;
    z_bb_54:
    zT_184 = dk - (unsigned int)(1);
    dk = zT_184;
    zT_185 = (unsigned int)dk;
    zT_186 = cd[zT_185];
    buf[p] = zT_186;
    zT_188 = p + (unsigned int)(1);
    p = zT_188;
    goto z_bb_56;
    z_bb_55:
    goto z_bb_51;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_191 = 31;
    p = zT_191;
    goto z_bb_58;
    z_bb_58:
    zT_192 = self->interner;
    zT_197 = 0;
    zT_198 = (unsigned char*)((unsigned char*)buf) + zT_197;
    zT_199 = p - zT_197;
    zT_200.ptr = (unsigned char*)zT_198;
    zT_200.len = zT_199;
    zT_193 = zT_200;
    zT_201 = zF_50C274AF_stringInternerInter(zT_192, zT_193);
    mangled_id = zT_201;
    goto z_bb_33;
}

/* nameManglerMangleGlobal */
unsigned int zF_027E7C4F_nameManglerMangle_1(zT_CEC2984A_NameMangler* self, zT_338B7C76_TypeRegistry* registry, unsigned int name_id, unsigned int module_id, unsigned int type_id) {
    unsigned int zT_5;
    zT_D155D06D_Type* zT_9;
    unsigned int zT_10;
    zT_D155D06D_Type zT_11;
    unsigned int zT_12;
    unsigned char zT_15;
    unsigned int zT_16;
    zT_CEC2984A_NameMangler* zT_18;
    unsigned int zT_19;
    unsigned short zT_24;
    unsigned int zT_26 = 0;
    zT_CEC2984A_NameMangler* zT_27;
    unsigned int zT_28;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    zT_D155D06D_Type ty;
    zT_5 = registry->types_len;
    if ((unsigned char)(type_id < (unsigned int)((unsigned int)zT_5))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = registry->types_items;
    zT_10 = (unsigned int)type_id;
    zT_11 = zT_9[zT_10];
    ty = zT_11;
    zT_12 = ty.name_id;
    if ((unsigned char)(zT_12 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    zT_27 = self;
    zT_28 = name_id;
    zT_30 = module_id;
    zT_32 = zF_713D1938_nameManglerMangle(zT_27, zT_28, (unsigned char)(1), zT_30);
    return zT_32;
    z_bb_3:
    zT_16 = ty.name_id;
    zT_15 = zT_16 == name_id;
    goto z_bb_5;
    z_bb_4:
    zT_15 = 0;
    goto z_bb_5;
    z_bb_5:
    if (zT_15) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_18 = self;
    zT_19 = ty.name_id;
    zT_24 = ty.module_id;
    zT_26 = zF_713D1938_nameManglerMangle(zT_18, zT_19, (unsigned char)(1), (unsigned int)((unsigned int)zT_24));
    return zT_26;
    z_bb_7:
    goto z_bb_2;
}

/* nameManglerMintRaw */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_571F0158_nameManglerMintRaw(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned int scope, zT_A4CE86B7_U64ToU32Map* cache, zT_A4CE86B7_U64ToU32Map* taken) {
    zT_79FAE712_u64 zT_10;
    zT_A4CE86B7_U64ToU32Map* zT_11;
    zT_79FAE712_u64 zT_12;
    zT_BAEE192E_Opt_10 zT_13 = {0};
    unsigned char zT_14;
    zT_D3EB6303_StringInterner* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19 = {0};
    zT_D3EB6303_StringInterner* zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24 = {0};
    zT_CEC2984A_NameMangler* zT_26;
    unsigned int zT_27;
    unsigned char zT_28 = 0;
    zT_CEC2984A_NameMangler* zT_31;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_32;
    unsigned int zT_33 = 0;
    unsigned int zT_35;
    zT_79FAE712_u64 zT_42;
    zT_A4CE86B7_U64ToU32Map* zT_43;
    zT_79FAE712_u64 zT_44;
    zT_BAEE192E_Opt_10 zT_45 = {0};
    unsigned char zT_46;
    unsigned int zT_49;
    zT_D3EB6303_StringInterner* zT_51;
    unsigned int zT_52;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54 = {0};
    zT_C4003E6D_Arr_unsigned_char_1 zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned char zT_64;
    unsigned char* zT_67;
    unsigned char zT_68;
    unsigned int zT_70;
    unsigned int zT_72;
    unsigned char zT_73;
    unsigned int zT_75;
    zT_5426B97B_Arr_unsigned_char_1 zT_77;
    unsigned int zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    int zT_83;
    unsigned char* zT_84;
    unsigned int zT_85;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_87 = 0;
    unsigned int zT_91;
    unsigned char zT_95;
    unsigned char zT_98;
    unsigned int zT_100;
    unsigned int zT_102;
    zT_D3EB6303_StringInterner* zT_103;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_104;
    int zT_108;
    unsigned char* zT_109;
    unsigned int zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112 = 0;
    zT_A4CE86B7_U64ToU32Map* zT_113;
    zT_79FAE712_u64 zT_114;
    unsigned int zT_115;
    zT_79FAE712_u64 zT_121;
    zT_A4CE86B7_U64ToU32Map* zT_122;
    zT_79FAE712_u64 zT_123;
    zT_D3EB6303_StringInterner* zT_126;
    unsigned int zT_127;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129 = {0};
    zT_79FAE712_u64 key;
    unsigned int cached;
    zT_8F083A69_Slice_zT_0B42B2F8_u name;
    unsigned int cand_id;
    unsigned int counter;
    zT_79FAE712_u64 tkey;
    zT_79FAE712_u64 done_key;
    zT_8F083A69_Slice_zT_0B42B2F8_u cand;
    zT_C4003E6D_Arr_unsigned_char_1 buf;
    unsigned int p;
    unsigned int ci;
    zT_5426B97B_Arr_unsigned_char_1 db;
    unsigned int dl;
    unsigned int ds;
    unsigned int di;
    zT_10 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)scope) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)name_id);
    key = zT_10;
    zT_11 = cache;
    zT_12 = key;
    zT_13 = zF_A05A7BE1_u64ToU32MapGet(zT_11, zT_12);
    zT_14 = zT_13.has_value;
    if (zT_14) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    cached = zT_13.value;
    zT_16 = self->interner;
    zT_17 = cached;
    zT_19 = zF_9134020D_stringInternerGet(zT_16, zT_17);
    return zT_19;
    z_bb_2:
    zT_21 = self->interner;
    zT_22 = name_id;
    zT_24 = zF_9134020D_stringInternerGet(zT_21, zT_22);
    name = zT_24;
    cand_id = name_id;
    zT_26 = self;
    zT_27 = name_id;
    zT_28 = zF_5412D014_isC89Keyword(zT_26, zT_27);
    if ((unsigned char)(zT_28 != (unsigned char)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_31 = self;
    zT_32 = name;
    zT_33 = zF_C3DD2126_mangleC89Keyword(zT_31, zT_32);
    cand_id = zT_33;
    goto z_bb_4;
    z_bb_4:
    zT_35 = 0;
    counter = zT_35;
    goto z_bb_5;
    z_bb_5:
    if ((unsigned char)(1)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_42 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)scope) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)cand_id);
    tkey = zT_42;
    zT_43 = taken;
    zT_44 = tkey;
    zT_45 = zF_A05A7BE1_u64ToU32MapGet(zT_43, zT_44);
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_9; else goto z_bb_11;
    z_bb_7:
    zT_113 = cache;
    zT_114 = key;
    zT_115 = cand_id;
    zF_B6EB812C_u64ToU32MapPut(zT_113, zT_114, zT_115);
    zT_121 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)scope) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)cand_id);
    done_key = zT_121;
    zT_122 = taken;
    zT_123 = done_key;
    zF_B6EB812C_u64ToU32MapPut(zT_122, zT_123, (unsigned int)(1));
    zT_126 = self->interner;
    zT_127 = cand_id;
    zT_129 = zF_9134020D_stringInternerGet(zT_126, zT_127);
    return zT_129;
    z_bb_8:
    goto z_bb_5;
    z_bb_9:
    zT_49 = counter + (unsigned int)(1);
    counter = zT_49;
    zT_51 = self->interner;
    zT_52 = cand_id;
    zT_54 = zF_9134020D_stringInternerGet(zT_51, zT_52);
    cand = zT_54;
    {
    unsigned int _i = 0;
    while (_i < 128) {
        zT_56[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 128) {
        buf[_i] = zT_56[_i];
        _i++;
    }
}
    zT_58 = 0;
    p = zT_58;
    zT_60 = 0;
    ci = zT_60;
    goto z_bb_12;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    goto z_bb_7;
    z_bb_12:
    zT_62 = cand.len;
    if ((unsigned char)(ci < zT_62)) goto z_bb_16; else goto z_bb_17;
    z_bb_13:
    zT_67 = cand.ptr;
    zT_68 = zT_67[ci];
    buf[p] = zT_68;
    zT_70 = p + (unsigned int)(1);
    p = zT_70;
    goto z_bb_15;
    z_bb_14:
    zT_73 = 95;
    buf[p] = zT_73;
    zT_75 = p + (unsigned int)(1);
    p = zT_75;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_77[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        db[_i] = zT_77[_i];
        _i++;
    }
}
    zT_79 = counter;
    zT_83 = 0;
    zT_84 = (unsigned char*)((unsigned char*)db) + zT_83;
    zT_85 = (unsigned int)(16) - zT_83;
    zT_86.ptr = (unsigned char*)zT_84;
    zT_86.len = zT_85;
    zT_80 = zT_86;
    zT_87 = zF_A7504564_itoa(zT_79, zT_80);
    dl = zT_87;
    zT_91 = (unsigned int)(15) - (unsigned int)((unsigned int)dl);
    ds = zT_91;
    di = ds;
    goto z_bb_19;
    z_bb_15:
    zT_72 = ci + (unsigned int)(1);
    ci = zT_72;
    goto z_bb_12;
    z_bb_16:
    zT_64 = p < (unsigned int)(118);
    goto z_bb_18;
    z_bb_17:
    zT_64 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_64) goto z_bb_13; else goto z_bb_14;
    z_bb_19:
    if ((unsigned char)(di < (unsigned int)(15))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_98 = db[di];
    buf[p] = zT_98;
    zT_100 = p + (unsigned int)(1);
    p = zT_100;
    goto z_bb_22;
    z_bb_21:
    zT_103 = self->interner;
    zT_108 = 0;
    zT_109 = (unsigned char*)((unsigned char*)buf) + zT_108;
    zT_110 = p - zT_108;
    zT_111.ptr = (unsigned char*)zT_109;
    zT_111.len = zT_110;
    zT_104 = zT_111;
    zT_112 = zF_50C274AF_stringInternerInter(zT_103, zT_104);
    cand_id = zT_112;
    goto z_bb_10;
    z_bb_22:
    zT_102 = di + (unsigned int)(1);
    di = zT_102;
    goto z_bb_19;
    z_bb_23:
    zT_95 = p < (unsigned int)(127);
    goto z_bb_25;
    z_bb_24:
    zT_95 = 0;
    goto z_bb_25;
    z_bb_25:
    if (zT_95) goto z_bb_20; else goto z_bb_21;
}

/* nameManglerMintLocal */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_8D2701C5_nameManglerMintLoca(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned int scope) {
    zT_CEC2984A_NameMangler* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_A4CE86B7_U64ToU32Map* zT_6;
    zT_A4CE86B7_U64ToU32Map* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10 = {0};
    zT_3 = self;
    zT_4 = name_id;
    zT_5 = scope;
    zT_6 = &self->raw_cache_local;
    zT_7 = &self->raw_taken_local;
    zT_10 = zF_571F0158_nameManglerMintRaw(zT_3, zT_4, zT_5, zT_6, zT_7);
    return zT_10;
}

/* nameManglerMintField */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_455DE5CA_nameManglerMintFiel(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned int scope) {
    zT_CEC2984A_NameMangler* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_A4CE86B7_U64ToU32Map* zT_6;
    zT_A4CE86B7_U64ToU32Map* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10 = {0};
    zT_3 = self;
    zT_4 = name_id;
    zT_5 = scope;
    zT_6 = &self->raw_cache_field;
    zT_7 = &self->raw_taken_field;
    zT_10 = zF_571F0158_nameManglerMintRaw(zT_3, zT_4, zT_5, zT_6, zT_7);
    return zT_10;
}

/* nameManglerMintMember */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_5EF2DC48_nameManglerMintMemb(zT_CEC2984A_NameMangler* self, unsigned int name_id, unsigned int scope) {
    zT_CEC2984A_NameMangler* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_A4CE86B7_U64ToU32Map* zT_6;
    zT_A4CE86B7_U64ToU32Map* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_10 = {0};
    zT_3 = self;
    zT_4 = name_id;
    zT_5 = scope;
    zT_6 = &self->raw_cache_member;
    zT_7 = &self->raw_taken_member;
    zT_10 = zF_571F0158_nameManglerMintRaw(zT_3, zT_4, zT_5, zT_6, zT_7);
    return zT_10;
}

/* nameManglerFnScope */
unsigned int zF_79CB4DDA_nameManglerFnScope(zT_CEC2984A_NameMangler* self, unsigned int fn_name_id, unsigned int fn_module_id) {
    zT_4428DEE2_Arr_unsigned_char_2 zT_4;
    unsigned int zT_6;
    zT_5426B97B_Arr_unsigned_char_1 zT_8;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    int zT_14;
    unsigned char* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18 = 0;
    unsigned int zT_22;
    unsigned char zT_26;
    unsigned char zT_29;
    unsigned int zT_31;
    unsigned int zT_33;
    unsigned char zT_34;
    unsigned int zT_36;
    unsigned int zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    int zT_42;
    unsigned char* zT_43;
    unsigned int zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46 = 0;
    unsigned int zT_50;
    unsigned char zT_53;
    unsigned char zT_56;
    unsigned int zT_58;
    unsigned int zT_60;
    zT_D3EB6303_StringInterner* zT_61;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62;
    int zT_66;
    unsigned char* zT_67;
    unsigned int zT_68;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_69;
    unsigned int zT_70 = 0;
    zT_4428DEE2_Arr_unsigned_char_2 buf;
    unsigned int p;
    zT_5426B97B_Arr_unsigned_char_1 db;
    unsigned int dl;
    unsigned int ds;
    unsigned int i;
    unsigned int dl2;
    unsigned int ds2;
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_4[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        buf[_i] = zT_4[_i];
        _i++;
    }
}
    zT_6 = 0;
    p = zT_6;
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_8[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        db[_i] = zT_8[_i];
        _i++;
    }
}
    zT_10 = fn_module_id;
    zT_14 = 0;
    zT_15 = (unsigned char*)((unsigned char*)db) + zT_14;
    zT_16 = (unsigned int)(16) - zT_14;
    zT_17.ptr = (unsigned char*)zT_15;
    zT_17.len = zT_16;
    zT_11 = zT_17;
    zT_18 = zF_A7504564_itoa(zT_10, zT_11);
    dl = zT_18;
    zT_22 = (unsigned int)(15) - (unsigned int)((unsigned int)dl);
    ds = zT_22;
    i = ds;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)(15))) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_29 = db[i];
    buf[p] = zT_29;
    zT_31 = p + (unsigned int)(1);
    p = zT_31;
    goto z_bb_4;
    z_bb_3:
    zT_34 = 95;
    buf[p] = zT_34;
    zT_36 = p + (unsigned int)(1);
    p = zT_36;
    zT_38 = fn_name_id;
    zT_42 = 0;
    zT_43 = (unsigned char*)((unsigned char*)db) + zT_42;
    zT_44 = (unsigned int)(16) - zT_42;
    zT_45.ptr = (unsigned char*)zT_43;
    zT_45.len = zT_44;
    zT_39 = zT_45;
    zT_46 = zF_A7504564_itoa(zT_38, zT_39);
    dl2 = zT_46;
    zT_50 = (unsigned int)(15) - (unsigned int)((unsigned int)dl2);
    ds2 = zT_50;
    i = ds2;
    goto z_bb_8;
    z_bb_4:
    zT_33 = i + (unsigned int)(1);
    i = zT_33;
    goto z_bb_1;
    z_bb_5:
    zT_26 = p < (unsigned int)(10);
    goto z_bb_7;
    z_bb_6:
    zT_26 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_26) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    if ((unsigned char)(i < (unsigned int)(15))) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    zT_56 = db[i];
    buf[p] = zT_56;
    zT_58 = p + (unsigned int)(1);
    p = zT_58;
    goto z_bb_11;
    z_bb_10:
    zT_61 = self->interner;
    zT_66 = 0;
    zT_67 = (unsigned char*)((unsigned char*)buf) + zT_66;
    zT_68 = p - zT_66;
    zT_69.ptr = (unsigned char*)zT_67;
    zT_69.len = zT_68;
    zT_62 = zT_69;
    zT_70 = zF_50C274AF_stringInternerInter(zT_61, zT_62);
    return zT_70;
    z_bb_11:
    zT_60 = i + (unsigned int)(1);
    i = zT_60;
    goto z_bb_8;
    z_bb_12:
    zT_53 = p < (unsigned int)(23);
    goto z_bb_14;
    z_bb_13:
    zT_53 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_53) goto z_bb_9; else goto z_bb_10;
}

/* nameManglerMintTemp */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_918A053C_nameManglerMintTemp(zT_CEC2984A_NameMangler* self, unsigned int temp_id) {
    zT_4028D896_Arr_unsigned_char_2 zT_3;
    unsigned char zT_4;
    int zT_5;
    unsigned char zT_6;
    int zT_7;
    unsigned char zT_8;
    int zT_9;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    int zT_15;
    unsigned char* zT_16;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_18;
    unsigned int zT_19 = 0;
    unsigned int zT_23;
    unsigned int zT_25;
    unsigned int zT_27;
    unsigned int zT_30;
    unsigned char zT_31;
    unsigned int zT_32;
    unsigned int zT_34;
    unsigned int zT_37;
    zT_D3EB6303_StringInterner* zT_39;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_40;
    int zT_44;
    unsigned char* zT_45;
    unsigned int zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    unsigned int zT_48 = 0;
    zT_D3EB6303_StringInterner* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52 = {0};
    zT_4028D896_Arr_unsigned_char_2 buf;
    unsigned int len;
    unsigned int dig_start;
    unsigned int di;
    unsigned int i;
    unsigned int end;
    unsigned int mid;
    {
    unsigned int _i = 0;
    while (_i < 20) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 20) {
        buf[_i] = zT_3[_i];
        _i++;
    }
}
    zT_4 = 122;
    zT_5 = 0;
    buf[zT_5] = zT_4;
    zT_6 = 84;
    zT_7 = 1;
    buf[zT_7] = zT_6;
    zT_8 = 95;
    zT_9 = 2;
    buf[zT_9] = zT_8;
    zT_11 = temp_id;
    zT_15 = 3;
    zT_16 = (unsigned char*)((unsigned char*)buf) + zT_15;
    zT_17 = (unsigned int)(20) - zT_15;
    zT_18.ptr = (unsigned char*)zT_16;
    zT_18.len = zT_17;
    zT_12 = zT_18;
    zT_19 = zF_A7504564_itoa(zT_11, zT_12);
    len = zT_19;
    zT_23 = (unsigned int)(19) - (unsigned int)((unsigned int)len);
    dig_start = zT_23;
    zT_25 = 3;
    di = zT_25;
    zT_27 = 0;
    i = zT_27;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)((unsigned int)len))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_30 = dig_start + i;
    zT_31 = buf[zT_30];
    zT_32 = di + i;
    buf[zT_32] = zT_31;
    goto z_bb_4;
    z_bb_3:
    zT_37 = di + (unsigned int)((unsigned int)len);
    end = zT_37;
    zT_39 = self->interner;
    zT_44 = 0;
    zT_45 = (unsigned char*)((unsigned char*)buf) + zT_44;
    zT_46 = end - zT_44;
    zT_47.ptr = (unsigned char*)zT_45;
    zT_47.len = zT_46;
    zT_40 = zT_47;
    zT_48 = zF_50C274AF_stringInternerInter(zT_39, zT_40);
    mid = zT_48;
    zT_49 = self->interner;
    zT_50 = mid;
    zT_52 = zF_9134020D_stringInternerGet(zT_49, zT_50);
    return zT_52;
    z_bb_4:
    zT_34 = i + (unsigned int)(1);
    i = zT_34;
    goto z_bb_1;
}

/* nameManglerMintSyntheticType */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_9DABAED9_nameManglerMintSynt(zT_CEC2984A_NameMangler* self, zT_8F083A69_Slice_zT_0B42B2F8_u prefix, zT_8F083A69_Slice_zT_0B42B2F8_u elem_name, zT_8F083A69_Slice_zT_0B42B2F8_u len_text, unsigned int cap) {
    zT_C4003E6D_Arr_unsigned_char_1 zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned char zT_14;
    unsigned char* zT_16;
    unsigned char zT_17;
    unsigned int zT_19;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_24;
    unsigned char zT_26;
    unsigned char* zT_29;
    unsigned char zT_30;
    unsigned char zT_33;
    unsigned char zT_36;
    unsigned int zT_38;
    unsigned int zT_40;
    unsigned int zT_42;
    unsigned int zT_46;
    unsigned char zT_49;
    unsigned char zT_51;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned int zT_56;
    unsigned char zT_58;
    unsigned char* zT_60;
    unsigned char zT_61;
    unsigned int zT_63;
    unsigned int zT_65;
    zT_D3EB6303_StringInterner* zT_67;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_68;
    int zT_72;
    unsigned char* zT_73;
    unsigned int zT_74;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_75;
    unsigned int zT_76 = 0;
    zT_CEC2984A_NameMangler* zT_78;
    unsigned int zT_79;
    unsigned int zT_84 = 0;
    zT_D3EB6303_StringInterner* zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88 = {0};
    zT_C4003E6D_Arr_unsigned_char_1 buf;
    unsigned int p;
    unsigned int i;
    unsigned char c;
    unsigned int nid;
    unsigned int mid;
    {
    unsigned int _i = 0;
    while (_i < 128) {
        zT_6[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 128) {
        buf[_i] = zT_6[_i];
        _i++;
    }
}
    zT_8 = 0;
    p = zT_8;
    zT_10 = 0;
    i = zT_10;
    goto z_bb_1;
    z_bb_1:
    zT_12 = prefix.len;
    if ((unsigned char)(i < zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_16 = prefix.ptr;
    zT_17 = zT_16[i];
    buf[p] = zT_17;
    zT_19 = p + (unsigned int)(1);
    p = zT_19;
    goto z_bb_4;
    z_bb_3:
    zT_22 = 0;
    i = zT_22;
    goto z_bb_8;
    z_bb_4:
    zT_21 = i + (unsigned int)(1);
    i = zT_21;
    goto z_bb_1;
    z_bb_5:
    zT_14 = p < cap;
    goto z_bb_7;
    z_bb_6:
    zT_14 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_14) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    zT_24 = elem_name.len;
    if ((unsigned char)(i < zT_24)) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    zT_29 = elem_name.ptr;
    zT_30 = zT_29[i];
    c = zT_30;
    if ((unsigned char)(c == (unsigned char)(32))) goto z_bb_16; else goto z_bb_15;
    z_bb_10:
    zT_42 = len_text.len;
    if ((unsigned char)(zT_42 > (unsigned int)(0))) goto z_bb_20; else goto z_bb_21;
    z_bb_11:
    zT_40 = i + (unsigned int)(1);
    i = zT_40;
    goto z_bb_8;
    z_bb_12:
    zT_26 = p < cap;
    goto z_bb_14;
    z_bb_13:
    zT_26 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_26) goto z_bb_9; else goto z_bb_10;
    z_bb_15:
    zT_33 = c == (unsigned char)(42);
    goto z_bb_17;
    z_bb_16:
    zT_33 = 1;
    goto z_bb_17;
    z_bb_17:
    if (zT_33) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_36 = 95;
    c = zT_36;
    goto z_bb_19;
    z_bb_19:
    buf[p] = c;
    zT_38 = p + (unsigned int)(1);
    p = zT_38;
    goto z_bb_11;
    z_bb_20:
    zT_46 = elem_name.len;
    if ((unsigned char)(zT_46 > (unsigned int)(0))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    zT_67 = self->interner;
    zT_72 = 0;
    zT_73 = (unsigned char*)((unsigned char*)buf) + zT_72;
    zT_74 = p - zT_72;
    zT_75.ptr = (unsigned char*)zT_73;
    zT_75.len = zT_74;
    zT_68 = zT_75;
    zT_76 = zF_50C274AF_stringInternerInter(zT_67, zT_68);
    nid = zT_76;
    zT_78 = self;
    zT_79 = nid;
    zT_84 = zF_713D1938_nameManglerMangle(zT_78, zT_79, (unsigned char)(2), (unsigned int)(0));
    mid = zT_84;
    zT_85 = self->interner;
    zT_86 = mid;
    zT_88 = zF_9134020D_stringInternerGet(zT_85, zT_86);
    return zT_88;
    z_bb_22:
    zT_49 = p < cap;
    goto z_bb_24;
    z_bb_23:
    zT_49 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_49) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_51 = 95;
    buf[p] = zT_51;
    zT_53 = p + (unsigned int)(1);
    p = zT_53;
    goto z_bb_26;
    z_bb_26:
    zT_54 = 0;
    i = zT_54;
    goto z_bb_27;
    z_bb_27:
    zT_56 = len_text.len;
    if ((unsigned char)(i < zT_56)) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_60 = len_text.ptr;
    zT_61 = zT_60[i];
    buf[p] = zT_61;
    zT_63 = p + (unsigned int)(1);
    p = zT_63;
    goto z_bb_30;
    z_bb_29:
    goto z_bb_21;
    z_bb_30:
    zT_65 = i + (unsigned int)(1);
    i = zT_65;
    goto z_bb_27;
    z_bb_31:
    zT_58 = p < cap;
    goto z_bb_33;
    z_bb_32:
    zT_58 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_58) goto z_bb_28; else goto z_bb_29;
}

/* nameManglerMintIndexName */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C486DB29_nameManglerMintInde(zT_CEC2984A_NameMangler* self, zT_8F083A69_Slice_zT_0B42B2F8_u prefix, unsigned int n) {
    zT_C41F1B06_Arr_unsigned_char_6 zT_4;
    unsigned int zT_6;
    unsigned int zT_8;
    unsigned int zT_10;
    unsigned char zT_12;
    unsigned char* zT_15;
    unsigned char zT_16;
    unsigned int zT_18;
    unsigned int zT_20;
    zT_5426B97B_Arr_unsigned_char_1 zT_22;
    unsigned int zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_25;
    int zT_28;
    unsigned char* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_32 = 0;
    unsigned int zT_36;
    unsigned char zT_40;
    unsigned char zT_43;
    unsigned int zT_45;
    unsigned int zT_47;
    zT_D3EB6303_StringInterner* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    int zT_54;
    unsigned char* zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_57;
    unsigned int zT_58 = 0;
    zT_D3EB6303_StringInterner* zT_59;
    unsigned int zT_60;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_62 = {0};
    zT_C41F1B06_Arr_unsigned_char_6 buf;
    unsigned int p;
    unsigned int i;
    zT_5426B97B_Arr_unsigned_char_1 db;
    unsigned int dl;
    unsigned int ds;
    unsigned int j;
    unsigned int nid;
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_4[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        buf[_i] = zT_4[_i];
        _i++;
    }
}
    zT_6 = 0;
    p = zT_6;
    zT_8 = 0;
    i = zT_8;
    goto z_bb_1;
    z_bb_1:
    zT_10 = prefix.len;
    if ((unsigned char)(i < zT_10)) goto z_bb_5; else goto z_bb_6;
    z_bb_2:
    zT_15 = prefix.ptr;
    zT_16 = zT_15[i];
    buf[p] = zT_16;
    zT_18 = p + (unsigned int)(1);
    p = zT_18;
    goto z_bb_4;
    z_bb_3:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_22[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        db[_i] = zT_22[_i];
        _i++;
    }
}
    zT_24 = n;
    zT_28 = 0;
    zT_29 = (unsigned char*)((unsigned char*)db) + zT_28;
    zT_30 = (unsigned int)(16) - zT_28;
    zT_31.ptr = (unsigned char*)zT_29;
    zT_31.len = zT_30;
    zT_25 = zT_31;
    zT_32 = zF_A7504564_itoa(zT_24, zT_25);
    dl = zT_32;
    zT_36 = (unsigned int)(15) - (unsigned int)((unsigned int)dl);
    ds = zT_36;
    j = ds;
    goto z_bb_8;
    z_bb_4:
    zT_20 = i + (unsigned int)(1);
    i = zT_20;
    goto z_bb_1;
    z_bb_5:
    zT_12 = p < (unsigned int)(63);
    goto z_bb_7;
    z_bb_6:
    zT_12 = 0;
    goto z_bb_7;
    z_bb_7:
    if (zT_12) goto z_bb_2; else goto z_bb_3;
    z_bb_8:
    if ((unsigned char)(j < (unsigned int)(15))) goto z_bb_12; else goto z_bb_13;
    z_bb_9:
    zT_43 = db[j];
    buf[p] = zT_43;
    zT_45 = p + (unsigned int)(1);
    p = zT_45;
    goto z_bb_11;
    z_bb_10:
    zT_49 = self->interner;
    zT_54 = 0;
    zT_55 = (unsigned char*)((unsigned char*)buf) + zT_54;
    zT_56 = p - zT_54;
    zT_57.ptr = (unsigned char*)zT_55;
    zT_57.len = zT_56;
    zT_50 = zT_57;
    zT_58 = zF_50C274AF_stringInternerInter(zT_49, zT_50);
    nid = zT_58;
    zT_59 = self->interner;
    zT_60 = nid;
    zT_62 = zF_9134020D_stringInternerGet(zT_59, zT_60);
    return zT_62;
    z_bb_11:
    zT_47 = j + (unsigned int)(1);
    j = zT_47;
    goto z_bb_8;
    z_bb_12:
    zT_40 = p < (unsigned int)(63);
    goto z_bb_14;
    z_bb_13:
    zT_40 = 0;
    goto z_bb_14;
    z_bb_14:
    if (zT_40) goto z_bb_9; else goto z_bb_10;
}

/* nameManglerMintModuleStem */
zT_8F083A69_Slice_zT_0B42B2F8_u zF_C4A5232F_nameManglerMintModu(zT_CEC2984A_NameMangler* self, zT_8F083A69_Slice_zT_0B42B2F8_u path_str) {
    unsigned int zT_3;
    unsigned char zT_5;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned char* zT_11;
    unsigned char zT_12;
    unsigned char zT_15;
    unsigned int zT_17;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19 = {0};
    unsigned int zT_24;
    unsigned char* zT_25;
    unsigned int zT_28;
    unsigned char* zT_29;
    unsigned int zT_30;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_31;
    unsigned int zT_34;
    unsigned char zT_37;
    unsigned char* zT_38;
    unsigned int zT_40;
    unsigned char zT_41;
    unsigned char zT_44;
    unsigned char* zT_45;
    unsigned int zT_47;
    unsigned char zT_48;
    unsigned char zT_51;
    unsigned char* zT_52;
    unsigned int zT_54;
    unsigned char zT_55;
    unsigned char zT_58;
    unsigned char* zT_59;
    unsigned int zT_61;
    unsigned char zT_62;
    unsigned int zT_67;
    unsigned char* zT_68;
    int zT_70;
    unsigned char* zT_71;
    unsigned int zT_72;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_73;
    unsigned char zT_76;
    unsigned char* zT_77;
    unsigned int zT_79;
    unsigned char zT_80;
    unsigned char zT_83;
    unsigned char* zT_84;
    unsigned int zT_86;
    unsigned char zT_87;
    unsigned char zT_90;
    unsigned char* zT_91;
    unsigned int zT_93;
    unsigned char zT_94;
    unsigned char zT_97;
    unsigned char* zT_98;
    unsigned int zT_100;
    unsigned char zT_101;
    unsigned int zT_106;
    unsigned char* zT_107;
    int zT_109;
    unsigned char* zT_110;
    unsigned int zT_111;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_112;
    unsigned int zT_114;
    unsigned char* zT_117;
    int zT_120;
    unsigned char* zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_125;
    unsigned int zT_126 = 0;
    zT_443A2803_Arr_unsigned_char_9 zT_128;
    unsigned int zT_130;
    unsigned int zT_132;
    unsigned int zT_134;
    unsigned char* zT_136;
    unsigned char zT_137;
    unsigned int zT_139;
    unsigned int zT_141;
    unsigned char zT_142;
    unsigned int zT_144;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    int zT_150;
    unsigned char* zT_151;
    unsigned int zT_152;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_153;
    zT_D3EB6303_StringInterner* zT_156;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_157;
    int zT_161;
    unsigned char* zT_162;
    unsigned int zT_163;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_164;
    unsigned int zT_165 = 0;
    zT_D3EB6303_StringInterner* zT_166;
    unsigned int zT_167;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_169 = {0};
    unsigned int last_slash;
    unsigned char has_slash;
    unsigned int ps_i;
    zT_8F083A69_Slice_zT_0B42B2F8_u base;
    unsigned int dbl_start;
    unsigned int bl;
    unsigned int bl4;
    unsigned int hash;
    zT_443A2803_Arr_unsigned_char_9 buf;
    unsigned int pos;
    unsigned int bi;
    unsigned int qid;
    zT_3 = 0;
    last_slash = zT_3;
    zT_5 = 0;
    has_slash = zT_5;
    zT_7 = 0;
    ps_i = zT_7;
    goto z_bb_1;
    z_bb_1:
    zT_9 = path_str.len;
    if ((unsigned char)(ps_i < zT_9)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_11 = path_str.ptr;
    zT_12 = zT_11[ps_i];
    if ((unsigned char)(zT_12 == (unsigned char)(47))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    base = zT_19;
    if ((unsigned char)(has_slash != (unsigned char)(0))) goto z_bb_7; else goto z_bb_9;
    z_bb_4:
    zT_17 = ps_i + (unsigned int)(1);
    ps_i = zT_17;
    goto z_bb_1;
    z_bb_5:
    last_slash = ps_i;
    zT_15 = 1;
    has_slash = zT_15;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_24 = last_slash + (unsigned int)(1);
    dbl_start = zT_24;
    zT_25 = path_str.ptr;
    zT_28 = path_str.len;
    zT_29 = zT_25 + dbl_start;
    zT_30 = zT_28 - dbl_start;
    zT_31.ptr = (unsigned char*)zT_29;
    zT_31.len = zT_30;
    base = zT_31;
    goto z_bb_8;
    z_bb_8:
    zT_34 = base.len;
    bl = zT_34;
    if ((unsigned char)(bl >= (unsigned int)(4))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    base = path_str;
    goto z_bb_8;
    z_bb_10:
    zT_38 = base.ptr;
    zT_40 = bl - (unsigned int)(4);
    zT_41 = zT_38[zT_40];
    zT_37 = zT_41 == (unsigned char)(46);
    goto z_bb_12;
    z_bb_11:
    zT_37 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_37) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = base.ptr;
    zT_47 = bl - (unsigned int)(3);
    zT_48 = zT_45[zT_47];
    zT_44 = zT_48 == (unsigned char)(122);
    goto z_bb_15;
    z_bb_14:
    zT_44 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_44) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_52 = base.ptr;
    zT_54 = bl - (unsigned int)(2);
    zT_55 = zT_52[zT_54];
    zT_51 = zT_55 == (unsigned char)(105);
    goto z_bb_18;
    z_bb_17:
    zT_51 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_51) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_59 = base.ptr;
    zT_61 = bl - (unsigned int)(1);
    zT_62 = zT_59[zT_61];
    zT_58 = zT_62 == (unsigned char)(103);
    goto z_bb_21;
    z_bb_20:
    zT_58 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_58) goto z_bb_22; else goto z_bb_24;
    z_bb_22:
    zT_67 = bl - (unsigned int)(4);
    bl4 = zT_67;
    zT_68 = base.ptr;
    zT_70 = 0;
    zT_71 = zT_68 + zT_70;
    zT_72 = bl4 - zT_70;
    zT_73.ptr = (unsigned char*)zT_71;
    zT_73.len = zT_72;
    base = zT_73;
    goto z_bb_23;
    z_bb_23:
    zT_114 = base.len;
    bl = zT_114;
    if ((unsigned char)(bl > (unsigned int)(64))) goto z_bb_39; else goto z_bb_40;
    z_bb_24:
    if ((unsigned char)(bl >= (unsigned int)(4))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_77 = base.ptr;
    zT_79 = bl - (unsigned int)(4);
    zT_80 = zT_77[zT_79];
    zT_76 = zT_80 == (unsigned char)(46);
    goto z_bb_27;
    z_bb_26:
    zT_76 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_76) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_84 = base.ptr;
    zT_86 = bl - (unsigned int)(3);
    zT_87 = zT_84[zT_86];
    zT_83 = zT_87 == (unsigned char)(122);
    goto z_bb_30;
    z_bb_29:
    zT_83 = 0;
    goto z_bb_30;
    z_bb_30:
    if (zT_83) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    zT_91 = base.ptr;
    zT_93 = bl - (unsigned int)(2);
    zT_94 = zT_91[zT_93];
    zT_90 = zT_94 == (unsigned char)(57);
    goto z_bb_33;
    z_bb_32:
    zT_90 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_90) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_98 = base.ptr;
    zT_100 = bl - (unsigned int)(1);
    zT_101 = zT_98[zT_100];
    zT_97 = zT_101 == (unsigned char)(56);
    goto z_bb_36;
    z_bb_35:
    zT_97 = 0;
    goto z_bb_36;
    z_bb_36:
    if (zT_97) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    zT_106 = bl - (unsigned int)(4);
    bl4 = zT_106;
    zT_107 = base.ptr;
    zT_109 = 0;
    zT_110 = zT_107 + zT_109;
    zT_111 = bl4 - zT_109;
    zT_112.ptr = (unsigned char*)zT_110;
    zT_112.len = zT_111;
    base = zT_112;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_23;
    z_bb_39:
    zT_117 = base.ptr;
    zT_120 = 0;
    zT_121 = zT_117 + zT_120;
    zT_122 = (unsigned int)(64) - zT_120;
    zT_123.ptr = (unsigned char*)zT_121;
    zT_123.len = zT_122;
    base = zT_123;
    goto z_bb_40;
    z_bb_40:
    zT_125 = path_str;
    zT_126 = zF_B22E025B_fnv1a(zT_125);
    hash = zT_126;
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_128[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        buf[_i] = zT_128[_i];
        _i++;
    }
}
    zT_130 = 0;
    pos = zT_130;
    zT_132 = 0;
    bi = zT_132;
    goto z_bb_41;
    z_bb_41:
    zT_134 = base.len;
    if ((unsigned char)(bi < zT_134)) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_136 = base.ptr;
    zT_137 = zT_136[bi];
    buf[pos] = zT_137;
    zT_139 = pos + (unsigned int)(1);
    pos = zT_139;
    goto z_bb_44;
    z_bb_43:
    zT_142 = 95;
    buf[pos] = zT_142;
    zT_144 = pos + (unsigned int)(1);
    pos = zT_144;
    zT_150 = 0;
    zT_151 = (unsigned char*)((unsigned char*)buf) + zT_150;
    zT_152 = (unsigned int)(96) - zT_150;
    zT_153.ptr = (unsigned char*)zT_151;
    zT_153.len = zT_152;
    zT_145 = zT_153;
    zT_146 = (unsigned int*)&pos;
    zT_147 = hash;
    zF_8F8DE819_writeHex(zT_145, zT_146, zT_147);
    zT_156 = self->interner;
    zT_161 = 0;
    zT_162 = (unsigned char*)((unsigned char*)buf) + zT_161;
    zT_163 = pos - zT_161;
    zT_164.ptr = (unsigned char*)zT_162;
    zT_164.len = zT_163;
    zT_157 = zT_164;
    zT_165 = zF_50C274AF_stringInternerInter(zT_156, zT_157);
    qid = zT_165;
    zT_166 = self->interner;
    zT_167 = qid;
    zT_169 = zF_9134020D_stringInternerGet(zT_166, zT_167);
    return zT_169;
    z_bb_44:
    zT_141 = bi + (unsigned int)(1);
    bi = zT_141;
    goto z_bb_41;
}

/* EOF */
