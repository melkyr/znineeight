#include "name_mangler_27ED89E2.h"
zT_CEC2984A_NameMangler zG_CEC2984A_NameMangler;
/* nameManglerInit */
zT_CEC2984A_NameMangler zF_27DA3900_nameManglerInit(void) {
    zT_CEC2984A_NameMangler zT_0;
    unsigned int zT_1;
    zT_1 = 0;
    zT_0.counter = zT_1;
    return zT_0;
}

/* EOF */
