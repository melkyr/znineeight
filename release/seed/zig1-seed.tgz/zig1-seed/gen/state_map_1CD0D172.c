#include "state_map_1CD0D172.h"
/* stateMapInit */
zT_2C0927B0_StateMap zF_14665872_stateMapInit(zT_3E40CD83_Sand* alloc) {
    zT_2C0927B0_StateMap zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_E02B1339_Opt_260 zT_5 = {0};
    zT_2 = 0;
    zT_1.entries_items = (zT_6B392E0E_StateEntry*)zT_2;
    zT_3 = 0;
    zT_1.entries_len = zT_3;
    zT_4 = 0;
    zT_1.entries_cap = zT_4;
    zT_1.entries_alloc = alloc;
    zT_5.has_value = 0;
    zT_1.parent = zT_5;
    return zT_1;
}

/* stateMapEnsureCapacity */
void zF_A12CB78A_stateMapEnsureCapac(zT_2C0927B0_StateMap* self, unsigned int new_cap) {
    unsigned int zT_2;
    int zT_3;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_7;
    int zT_8;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_13;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    unsigned int zT_18;
    unsigned int zT_19;
    zT_3E40CD83_Sand* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    unsigned int zT_23;
    zT_A62CFBCC_EU_022 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    unsigned char* zT_27;
    zT_6B392E0E_StateEntry* zT_29;
    zT_6B392E0E_StateEntry* zT_30;
    unsigned int zT_31;
    int zT_32;
    zT_6B392E0E_StateEntry* zT_33;
    unsigned int zT_34;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_35;
    zT_6B392E0E_StateEntry* zT_36;
    unsigned int zT_37;
    int zT_39;
    unsigned int zT_41;
    unsigned int zT_42;
    unsigned int nc;
    unsigned char* raw;
    zT_6B392E0E_StateEntry* new_items;
    zT_6B392E0E_StateEntry item;
    unsigned int i;
    zT_2 = self->entries_cap;
    zT_3 = new_cap <= zT_2;
    if (zT_3) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    nc = new_cap;
    nc = new_cap;
    zT_5 = self->entries_cap;
    zT_6 = 2;
    zT_7 = zT_5 * zT_6;
    zT_8 = nc < zT_7;
    if (zT_8) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->entries_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    zT_13 = nc < (unsigned int)zT_12;
    if (zT_13) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_20 = self->entries_alloc;
    zT_17 = zT_20;
    zT_21 = 8;
    zT_22 = zT_21 * nc;
    zT_18 = zT_22;
    zT_23 = 4;
    zT_19 = zT_23;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, zT_18, zT_19);
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    z_bb_8:
    zT_27 = zT_24.data.payload;
    zT_26 = zT_27;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    raw = zT_26;
    raw = zT_26;
    zT_29 = (zT_6B392E0E_StateEntry*)raw;
    new_items = zT_29;
    new_items = zT_29;
    new_items = zT_29;
    zT_30 = self->entries_items;
    zT_31 = self->entries_len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_36 = zT_35.ptr;
    zT_37 = zT_35.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    zT_39 = i < zT_37;
    if (zT_39) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_36[i];
    new_items[i] = item;
    zT_41 = 1;
    zT_42 = i + zT_41;
    i = zT_42;
    goto z_bb_10;
    z_bb_12:
    self->entries_items = new_items;
    self->entries_cap = nc;
    return;
}

/* stateMapGet */
zT_43E16BE5_Opt_8 zF_2EC17ECC_stateMapGet(zT_2C0927B0_StateMap* self, unsigned int name_id) {
    unsigned int zT_3;
    int zT_4;
    int zT_5;
    int zT_6;
    unsigned int zT_7;
    unsigned int zT_8;
    zT_6B392E0E_StateEntry* zT_9;
    zT_6B392E0E_StateEntry zT_10;
    unsigned int zT_11;
    int zT_12;
    zT_6B392E0E_StateEntry* zT_13;
    zT_6B392E0E_StateEntry zT_14;
    unsigned char zT_15;
    zT_43E16BE5_Opt_8 zT_16;
    zT_E02B1339_Opt_260 zT_17;
    unsigned char zT_18;
    zT_2C0927B0_StateMap* zT_20;
    unsigned int zT_21;
    zT_43E16BE5_Opt_8 zT_23 = {0};
    unsigned int i;
    zT_2C0927B0_StateMap* p;
    z_bb_0:
    zT_3 = self->entries_len;
    i = zT_3;
    i = zT_3;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = 0;
    zT_5 = i > (unsigned int)zT_4;
    if (zT_5) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    zT_7 = (unsigned int)zT_6;
    zT_8 = i - zT_7;
    i = zT_8;
    i = zT_8;
    zT_9 = self->entries_items;
    zT_10 = zT_9[i];
    zT_11 = zT_10.name_id;
    zT_12 = zT_11 == name_id;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17 = self->parent;
    zT_18 = zT_17.has_value;
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_13 = self->entries_items;
    zT_14 = zT_13[i];
    zT_15 = zT_14.state;
    zT_16.has_value = 1;
    zT_16.value = zT_15;
    return zT_16;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    p = zT_17.value;
    zT_20 = p;
    zT_21 = name_id;
    self = zT_20;
    name_id = zT_21;
    goto z_bb_0;
    z_bb_8:
    zT_23.has_value = 0;
    return zT_23;
}

/* stateMapSet */
void zF_ACCFA860_stateMapSet(zT_2C0927B0_StateMap* self, unsigned int name_id, unsigned char state) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    zT_6B392E0E_StateEntry* zT_8;
    zT_6B392E0E_StateEntry zT_9;
    unsigned int zT_10;
    int zT_11;
    zT_6B392E0E_StateEntry* zT_12;
    zT_6B392E0E_StateEntry* zT_13;
    int zT_14;
    unsigned int zT_15;
    zT_2C0927B0_StateMap* zT_16;
    unsigned int zT_17;
    unsigned int zT_18;
    int zT_19;
    unsigned int zT_20;
    zT_6B392E0E_StateEntry zT_21;
    zT_6B392E0E_StateEntry* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    int zT_25;
    unsigned int zT_26;
    unsigned int zT_27;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    i = zT_5;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->entries_len;
    zT_7 = i < zT_6;
    if (zT_7) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->entries_items;
    zT_9 = zT_8[i];
    zT_10 = zT_9.name_id;
    zT_11 = zT_10 == name_id;
    if (zT_11) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_16 = self;
    zT_18 = self->entries_len;
    zT_19 = 1;
    zT_20 = zT_18 + zT_19;
    zT_17 = zT_20;
    zF_A12CB78A_stateMapEnsureCapac(zT_16, zT_17);
    zT_21.name_id = name_id;
    zT_21.state = state;
    zT_22 = self->entries_items;
    zT_23 = self->entries_len;
    zT_22[zT_23] = zT_21;
    zT_24 = self->entries_len;
    zT_25 = 1;
    zT_26 = (unsigned int)zT_25;
    zT_27 = zT_24 + zT_26;
    self->entries_len = zT_27;
    return;
    z_bb_4:
    zT_14 = 1;
    zT_15 = i + zT_14;
    i = zT_15;
    i = zT_15;
    goto z_bb_1;
    z_bb_5:
    zT_12 = self->entries_items;
    zT_13 = zT_12 + i;
    zT_13->state = state;
    return;
    z_bb_6:
    goto z_bb_4;
}

/* stateMapFork */
zT_2C0927B0_StateMap* zF_77086C9C_stateMapFork(zT_2C0927B0_StateMap* self, zT_3E40CD83_Sand* scratch) {
    zT_3E40CD83_Sand* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_A62CFBCC_EU_022 zT_8 = {0};
    unsigned char zT_9;
    unsigned char* zT_10;
    unsigned char* zT_11;
    zT_2C0927B0_StateMap* zT_13;
    int zT_14;
    unsigned int zT_15;
    unsigned int zT_16;
    zT_E02B1339_Opt_260 zT_17;
    unsigned char* raw;
    zT_2C0927B0_StateMap* child;
    zT_3 = scratch;
    zT_6 = 24;
    zT_4 = zT_6;
    zT_7 = 4;
    zT_5 = zT_7;
    zT_8 = zF_1395EB68_sandAlloc(zT_3, zT_4, zT_5);
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    z_bb_2:
    zT_11 = zT_8.data.payload;
    zT_10 = zT_11;
    goto z_bb_3;
    z_bb_3:
    raw = zT_10;
    raw = zT_10;
    raw = zT_10;
    zT_13 = (zT_2C0927B0_StateMap*)raw;
    child = zT_13;
    child = zT_13;
    child = zT_13;
    zT_14 = 0;
    child->entries_items = (zT_6B392E0E_StateEntry*)zT_14;
    zT_15 = 0;
    child->entries_len = zT_15;
    zT_16 = 0;
    child->entries_cap = zT_16;
    child->entries_alloc = scratch;
    zT_17.has_value = 1;
    zT_17.value = self;
    child->parent = zT_17;
    return child;
}

/* stateMapMergeStates */
void zF_143ACBA6_stateMapMergeStates(zT_2C0927B0_StateMap* parent, zT_2C0927B0_StateMap* branch_a, zT_2C0927B0_StateMap* branch_b, unsigned char unknown_state) {
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_6B392E0E_StateEntry* zT_10;
    zT_6B392E0E_StateEntry zT_11;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    unsigned int zT_15;
    zT_43E16BE5_Opt_8 zT_16 = {0};
    unsigned char zT_17;
    unsigned char zT_19;
    int zT_20;
    zT_2C0927B0_StateMap* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    unsigned int zT_24;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    unsigned int zT_28;
    unsigned char zT_29;
    zT_2C0927B0_StateMap* zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    zT_43E16BE5_Opt_8 zT_34 = {0};
    unsigned char zT_35;
    unsigned char zT_37;
    int zT_38;
    zT_2C0927B0_StateMap* zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_44;
    int zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    int zT_49;
    zT_6B392E0E_StateEntry* zT_51;
    zT_6B392E0E_StateEntry zT_52;
    zT_2C0927B0_StateMap* zT_53;
    unsigned int zT_54;
    unsigned int zT_55;
    zT_43E16BE5_Opt_8 zT_56 = {0};
    unsigned char zT_57;
    int zT_58;
    zT_2C0927B0_StateMap* zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    zT_43E16BE5_Opt_8 zT_63 = {0};
    unsigned char zT_64;
    unsigned char zT_66;
    int zT_67;
    zT_2C0927B0_StateMap* zT_68;
    unsigned int zT_69;
    unsigned char zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_73;
    unsigned int i;
    zT_6B392E0E_StateEntry entry;
    zT_43E16BE5_Opt_8 bs;
    unsigned int j;
    unsigned char b_state;
    zT_43E16BE5_Opt_8 ps;
    unsigned char ps_val;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    i = zT_6;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = branch_a->entries_len;
    zT_8 = i < zT_7;
    if (zT_8) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = branch_a->entries_items;
    zT_11 = zT_10[i];
    entry = zT_11;
    entry = zT_11;
    entry = zT_11;
    zT_13 = branch_b;
    zT_15 = entry.name_id;
    zT_14 = zT_15;
    zT_16 = zF_2EC17ECC_stateMapGet(zT_13, zT_14);
    bs = zT_16;
    bs = zT_16;
    bs = zT_16;
    zT_17 = bs.has_value;
    if (zT_17) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_46 = 0;
    zT_47 = (unsigned int)zT_46;
    j = zT_47;
    j = zT_47;
    j = zT_47;
    goto z_bb_15;
    z_bb_4:
    zT_43 = 1;
    zT_44 = i + zT_43;
    i = zT_44;
    i = zT_44;
    goto z_bb_1;
    z_bb_5:
    b_state = bs.value;
    zT_19 = entry.state;
    zT_20 = b_state != zT_19;
    if (zT_20) goto z_bb_8; else goto z_bb_10;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = parent;
    zT_33 = entry.name_id;
    zT_32 = zT_33;
    zT_34 = zF_2EC17ECC_stateMapGet(zT_31, zT_32);
    ps = zT_34;
    ps = zT_34;
    ps = zT_34;
    zT_35 = ps.has_value;
    if (zT_35) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_21 = parent;
    zT_24 = entry.name_id;
    zT_22 = zT_24;
    zT_23 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_21, zT_22, zT_23);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_25 = parent;
    zT_28 = entry.name_id;
    zT_26 = zT_28;
    zT_29 = entry.state;
    zT_27 = zT_29;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    goto z_bb_9;
    z_bb_11:
    ps_val = ps.value;
    zT_37 = entry.state;
    zT_38 = ps_val != zT_37;
    if (zT_38) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_6;
    z_bb_13:
    zT_39 = parent;
    zT_42 = entry.name_id;
    zT_40 = zT_42;
    zT_41 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_39, zT_40, zT_41);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_48 = branch_b->entries_len;
    zT_49 = j < zT_48;
    if (zT_49) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_51 = branch_b->entries_items;
    zT_52 = zT_51[j];
    entry = zT_52;
    entry = zT_52;
    entry = zT_52;
    zT_53 = branch_a;
    zT_55 = entry.name_id;
    zT_54 = zT_55;
    zT_56 = zF_2EC17ECC_stateMapGet(zT_53, zT_54);
    zT_57 = zT_56.has_value;
    zT_58 = !zT_57;
    if (zT_58) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    return;
    z_bb_18:
    zT_72 = 1;
    zT_73 = j + zT_72;
    j = zT_73;
    j = zT_73;
    goto z_bb_15;
    z_bb_19:
    zT_60 = parent;
    zT_62 = entry.name_id;
    zT_61 = zT_62;
    zT_63 = zF_2EC17ECC_stateMapGet(zT_60, zT_61);
    ps = zT_63;
    ps = zT_63;
    ps = zT_63;
    zT_64 = ps.has_value;
    if (zT_64) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    ps_val = ps.value;
    zT_66 = entry.state;
    zT_67 = ps_val != zT_66;
    if (zT_67) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_68 = parent;
    zT_71 = entry.name_id;
    zT_69 = zT_71;
    zT_70 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_68, zT_69, zT_70);
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
}

/* stateMapGetEntries */
zT_92FBD55B_Slice_zT_6B392E0E_S zF_F0E7F434_stateMapGetEntries(zT_2C0927B0_StateMap* self) {
    zT_6B392E0E_StateEntry* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_6B392E0E_StateEntry* zT_4;
    unsigned int zT_5;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_6;
    zT_1 = self->entries_items;
    zT_2 = self->entries_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* EOF */
