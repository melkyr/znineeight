#include "state_map_1CD0D172.h"
/* stateMapInit */
zT_2C0927B0_StateMap zF_14665872_stateMapInit(zT_3E40CD83_Sand* alloc) {
    zT_2C0927B0_StateMap zT_1;
    int zT_2;
    unsigned int zT_3;
    unsigned int zT_4;
    zT_E128D635_Opt_277 zT_5 = {0};
    zT_2 = 0;
    zT_1.entries_items = (zT_6B392E0E_StateEntry*)zT_2;
    zT_3 = 0;
    zT_1.entries_len = zT_3;
    zT_4 = 0;
    zT_1.entries_cap = zT_4;
    zT_1.entries_alloc = alloc;
    zT_5.has_value = 0;
    zT_1.parent = zT_5;
    return zT_1;
}

/* stateMapEnsureCapacity */
void zF_A12CB78A_stateMapEnsureCapac(zT_2C0927B0_StateMap* self, unsigned int new_cap) {
    unsigned int zT_2;
    unsigned int zT_5;
    int zT_6;
    unsigned int zT_9;
    int zT_10;
    unsigned int zT_11;
    int zT_12;
    int zT_14;
    unsigned int zT_15;
    zT_3E40CD83_Sand* zT_17;
    zT_36325BAA_EU_042 zT_24 = {0};
    unsigned char zT_25;
    unsigned char* zT_26;
    zT_6B392E0E_StateEntry* zT_29;
    zT_6B392E0E_StateEntry* zT_30;
    unsigned int zT_31;
    int zT_32;
    zT_6B392E0E_StateEntry* zT_33;
    unsigned int zT_34;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_35;
    zT_6B392E0E_StateEntry* zT_36;
    unsigned int zT_37;
    unsigned int zT_42;
    unsigned int nc;
    unsigned char* raw;
    zT_6B392E0E_StateEntry* new_items;
    zT_6B392E0E_StateEntry item;
    unsigned int i;
    zT_2 = self->entries_cap;
    if ((unsigned char)(new_cap <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = new_cap;
    zT_5 = self->entries_cap;
    zT_6 = 2;
    if ((unsigned char)(nc < (unsigned int)(zT_5 * zT_6))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_9 = self->entries_cap;
    zT_10 = 2;
    zT_11 = zT_9 * zT_10;
    nc = zT_11;
    goto z_bb_4;
    z_bb_4:
    zT_12 = 8;
    if ((unsigned char)(nc < (unsigned int)zT_12)) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_14 = 8;
    zT_15 = (unsigned int)zT_14;
    nc = zT_15;
    goto z_bb_6;
    z_bb_6:
    zT_17 = self->entries_alloc;
    zT_24 = zF_1395EB68_sandAlloc(zT_17, (unsigned int)((unsigned int)(8) * nc), (unsigned int)(4));
    zT_25 = zT_24.is_error;
    if (zT_25) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_26 = zT_24.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw = zT_26;
    zT_29 = (zT_6B392E0E_StateEntry*)raw;
    new_items = zT_29;
    zT_30 = self->entries_items;
    zT_31 = self->entries_len;
    zT_32 = 0;
    zT_33 = zT_30 + zT_32;
    zT_34 = zT_31 - zT_32;
    zT_35.ptr = zT_33;
    zT_35.len = zT_34;
    zT_36 = zT_35.ptr;
    zT_37 = zT_35.len;
    i = 0;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < zT_37)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    item = zT_36[i];
    new_items[i] = item;
    goto z_bb_13;
    z_bb_12:
    self->entries_items = new_items;
    self->entries_cap = nc;
    return;
    z_bb_13:
    zT_42 = i + (unsigned int)(1);
    i = zT_42;
    goto z_bb_10;
}

/* stateMapGet */
zT_43E16BE5_Opt_8 zF_2EC17ECC_stateMapGet(zT_2C0927B0_StateMap* self, unsigned int name_id) {
    unsigned int zT_3;
    int zT_4;
    int zT_6;
    unsigned int zT_8;
    zT_6B392E0E_StateEntry* zT_9;
    zT_6B392E0E_StateEntry zT_10;
    unsigned int zT_11;
    zT_6B392E0E_StateEntry* zT_13;
    zT_6B392E0E_StateEntry zT_14;
    unsigned char zT_15;
    zT_43E16BE5_Opt_8 zT_16;
    zT_E128D635_Opt_277 zT_17;
    unsigned char zT_18;
    zT_2C0927B0_StateMap* zT_20;
    unsigned int zT_21;
    zT_43E16BE5_Opt_8 zT_23 = {0};
    unsigned int i;
    zT_2C0927B0_StateMap* p;
    z_bb_0:
    zT_3 = self->entries_len;
    i = zT_3;
    goto z_bb_1;
    z_bb_1:
    zT_4 = 0;
    if ((unsigned char)(i > (unsigned int)zT_4)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_6 = 1;
    zT_8 = i - (unsigned int)((unsigned int)zT_6);
    i = zT_8;
    zT_9 = self->entries_items;
    zT_10 = zT_9[i];
    zT_11 = zT_10.name_id;
    if ((unsigned char)(zT_11 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17 = self->parent;
    zT_18 = zT_17.has_value;
    if (zT_18) goto z_bb_7; else goto z_bb_8;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_13 = self->entries_items;
    zT_14 = zT_13[i];
    zT_15 = zT_14.state;
    zT_16.has_value = 1;
    zT_16.value = zT_15;
    return zT_16;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    p = zT_17.value;
    zT_20 = p;
    zT_21 = name_id;
    self = zT_20;
    name_id = zT_21;
    goto z_bb_0;
    z_bb_8:
    zT_23.has_value = 0;
    return zT_23;
}

/* stateMapSet */
void zF_ACCFA860_stateMapSet(zT_2C0927B0_StateMap* self, unsigned int name_id, unsigned char state) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_6B392E0E_StateEntry* zT_8;
    zT_6B392E0E_StateEntry zT_9;
    unsigned int zT_10;
    zT_6B392E0E_StateEntry* zT_12;
    zT_6B392E0E_StateEntry* zT_13;
    int zT_14;
    unsigned int zT_16;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_19;
    int zT_20;
    zT_6B392E0E_StateEntry zT_22;
    zT_6B392E0E_StateEntry* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    int zT_26;
    unsigned int i;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    i = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = self->entries_len;
    if ((unsigned char)(i < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = self->entries_items;
    zT_9 = zT_8[i];
    zT_10 = zT_9.name_id;
    if ((unsigned char)(zT_10 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_17 = self;
    zT_19 = self->entries_len;
    zT_20 = 1;
    zF_A12CB78A_stateMapEnsureCapac(zT_17, (unsigned int)(zT_19 + zT_20));
    zT_22.name_id = name_id;
    zT_22.state = state;
    zT_23 = self->entries_items;
    zT_24 = self->entries_len;
    zT_23[zT_24] = zT_22;
    zT_25 = self->entries_len;
    zT_26 = 1;
    self->entries_len = (unsigned int)(zT_25 + (unsigned int)((unsigned int)zT_26));
    return;
    z_bb_4:
    zT_14 = 1;
    zT_16 = i + (unsigned int)((unsigned int)zT_14);
    i = zT_16;
    goto z_bb_1;
    z_bb_5:
    zT_12 = self->entries_items;
    zT_13 = zT_12 + i;
    zT_13->state = state;
    return;
    z_bb_6:
    goto z_bb_4;
}

/* stateMapFork */
zT_2C0927B0_StateMap* zF_77086C9C_stateMapFork(zT_2C0927B0_StateMap* self, zT_3E40CD83_Sand* scratch) {
    zT_3E40CD83_Sand* zT_3;
    zT_36325BAA_EU_042 zT_8 = {0};
    unsigned char zT_9;
    unsigned char* zT_10;
    zT_2C0927B0_StateMap* zT_13;
    int zT_14;
    zT_E128D635_Opt_277 zT_17;
    unsigned char* raw;
    zT_2C0927B0_StateMap* child;
    zT_3 = scratch;
    zT_8 = zF_1395EB68_sandAlloc(zT_3, (unsigned int)(24), (unsigned int)(4));
    zT_9 = zT_8.is_error;
    if (zT_9) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_10 = zT_8.data.payload;
    goto z_bb_3;
    z_bb_3:
    raw = zT_10;
    zT_13 = (zT_2C0927B0_StateMap*)raw;
    child = zT_13;
    zT_14 = 0;
    child->entries_items = (zT_6B392E0E_StateEntry*)zT_14;
    child->entries_len = (unsigned int)(0);
    child->entries_cap = (unsigned int)(0);
    child->entries_alloc = scratch;
    zT_17.has_value = 1;
    zT_17.value = self;
    child->parent = zT_17;
    return child;
}

/* stateMapMergeStates */
void zF_143ACBA6_stateMapMergeStates(zT_2C0927B0_StateMap* parent, zT_2C0927B0_StateMap* branch_a, zT_2C0927B0_StateMap* branch_b, unsigned char unknown_state) {
    int zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    zT_6B392E0E_StateEntry* zT_10;
    zT_6B392E0E_StateEntry zT_11;
    zT_2C0927B0_StateMap* zT_13;
    unsigned int zT_14;
    zT_43E16BE5_Opt_8 zT_16 = {0};
    unsigned char zT_17;
    unsigned char zT_19;
    zT_2C0927B0_StateMap* zT_21;
    unsigned int zT_22;
    unsigned char zT_23;
    zT_2C0927B0_StateMap* zT_25;
    unsigned int zT_26;
    unsigned char zT_27;
    zT_2C0927B0_StateMap* zT_31;
    unsigned int zT_32;
    zT_43E16BE5_Opt_8 zT_34 = {0};
    unsigned char zT_35;
    unsigned char zT_37;
    zT_2C0927B0_StateMap* zT_39;
    unsigned int zT_40;
    unsigned char zT_41;
    int zT_43;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_6B392E0E_StateEntry* zT_52;
    zT_6B392E0E_StateEntry zT_53;
    zT_2C0927B0_StateMap* zT_54;
    unsigned int zT_55;
    zT_43E16BE5_Opt_8 zT_57 = {0};
    unsigned char zT_58;
    zT_2C0927B0_StateMap* zT_61;
    unsigned int zT_62;
    zT_43E16BE5_Opt_8 zT_64 = {0};
    unsigned char zT_65;
    unsigned char zT_67;
    zT_2C0927B0_StateMap* zT_69;
    unsigned int zT_70;
    unsigned char zT_71;
    int zT_73;
    unsigned int zT_75;
    unsigned int i;
    zT_6B392E0E_StateEntry entry;
    zT_43E16BE5_Opt_8 bs;
    unsigned int j;
    unsigned char b_state;
    zT_43E16BE5_Opt_8 ps;
    unsigned char ps_val;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    i = zT_6;
    goto z_bb_1;
    z_bb_1:
    zT_7 = branch_a->entries_len;
    if ((unsigned char)(i < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = branch_a->entries_items;
    zT_11 = zT_10[i];
    entry = zT_11;
    zT_13 = branch_b;
    zT_14 = entry.name_id;
    zT_16 = zF_2EC17ECC_stateMapGet(zT_13, zT_14);
    bs = zT_16;
    zT_17 = bs.has_value;
    if (zT_17) goto z_bb_5; else goto z_bb_7;
    z_bb_3:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    j = zT_48;
    goto z_bb_15;
    z_bb_4:
    zT_43 = 1;
    zT_45 = i + (unsigned int)((unsigned int)zT_43);
    i = zT_45;
    goto z_bb_1;
    z_bb_5:
    b_state = bs.value;
    zT_19 = entry.state;
    if ((unsigned char)(b_state != zT_19)) goto z_bb_8; else goto z_bb_10;
    z_bb_6:
    goto z_bb_4;
    z_bb_7:
    zT_31 = parent;
    zT_32 = entry.name_id;
    zT_34 = zF_2EC17ECC_stateMapGet(zT_31, zT_32);
    ps = zT_34;
    zT_35 = ps.has_value;
    if (zT_35) goto z_bb_11; else goto z_bb_12;
    z_bb_8:
    zT_21 = parent;
    zT_22 = entry.name_id;
    zT_23 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_21, zT_22, zT_23);
    goto z_bb_9;
    z_bb_9:
    goto z_bb_6;
    z_bb_10:
    zT_25 = parent;
    zT_26 = entry.name_id;
    zT_27 = entry.state;
    zF_ACCFA860_stateMapSet(zT_25, zT_26, zT_27);
    goto z_bb_9;
    z_bb_11:
    ps_val = ps.value;
    zT_37 = entry.state;
    if ((unsigned char)(ps_val != zT_37)) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_6;
    z_bb_13:
    zT_39 = parent;
    zT_40 = entry.name_id;
    zT_41 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_39, zT_40, zT_41);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_49 = branch_b->entries_len;
    if ((unsigned char)(j < zT_49)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_52 = branch_b->entries_items;
    zT_53 = zT_52[j];
    entry = zT_53;
    zT_54 = branch_a;
    zT_55 = entry.name_id;
    zT_57 = zF_2EC17ECC_stateMapGet(zT_54, zT_55);
    zT_58 = zT_57.has_value;
    if ((unsigned char)(!zT_58)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    return;
    z_bb_18:
    zT_73 = 1;
    zT_75 = j + (unsigned int)((unsigned int)zT_73);
    j = zT_75;
    goto z_bb_15;
    z_bb_19:
    zT_61 = parent;
    zT_62 = entry.name_id;
    zT_64 = zF_2EC17ECC_stateMapGet(zT_61, zT_62);
    ps = zT_64;
    zT_65 = ps.has_value;
    if (zT_65) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    ps_val = ps.value;
    zT_67 = entry.state;
    if ((unsigned char)(ps_val != zT_67)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_69 = parent;
    zT_70 = entry.name_id;
    zT_71 = unknown_state;
    zF_ACCFA860_stateMapSet(zT_69, zT_70, zT_71);
    goto z_bb_24;
    z_bb_24:
    goto z_bb_22;
}

/* stateMapMergeInsertMissing */
void zF_619C0B6B_stateMapMergeInsert(zT_2C0927B0_StateMap* parent, zT_2C0927B0_StateMap* branch, unsigned char insert_state) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_6B392E0E_StateEntry* zT_9;
    zT_6B392E0E_StateEntry zT_10;
    zT_2C0927B0_StateMap* zT_11;
    unsigned int zT_12;
    zT_43E16BE5_Opt_8 zT_14 = {0};
    unsigned char zT_15;
    zT_2C0927B0_StateMap* zT_17;
    unsigned int zT_18;
    unsigned char zT_19;
    int zT_21;
    unsigned int zT_23;
    unsigned int j;
    zT_6B392E0E_StateEntry entry;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    j = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_6 = branch->entries_len;
    if ((unsigned char)(j < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = branch->entries_items;
    zT_10 = zT_9[j];
    entry = zT_10;
    zT_11 = parent;
    zT_12 = entry.name_id;
    zT_14 = zF_2EC17ECC_stateMapGet(zT_11, zT_12);
    zT_15 = zT_14.has_value;
    if ((unsigned char)(!zT_15)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_21 = 1;
    zT_23 = j + (unsigned int)((unsigned int)zT_21);
    j = zT_23;
    goto z_bb_1;
    z_bb_5:
    zT_17 = parent;
    zT_18 = entry.name_id;
    zT_19 = insert_state;
    zF_ACCFA860_stateMapSet(zT_17, zT_18, zT_19);
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* stateMapGetEntries */
zT_92FBD55B_Slice_zT_6B392E0E_S zF_F0E7F434_stateMapGetEntries(zT_2C0927B0_StateMap* self) {
    zT_6B392E0E_StateEntry* zT_1;
    unsigned int zT_2;
    int zT_3;
    zT_6B392E0E_StateEntry* zT_4;
    unsigned int zT_5;
    zT_92FBD55B_Slice_zT_6B392E0E_S zT_6;
    zT_1 = self->entries_items;
    zT_2 = self->entries_len;
    zT_3 = 0;
    zT_4 = zT_1 + zT_3;
    zT_5 = zT_2 - zT_3;
    zT_6.ptr = zT_4;
    zT_6.len = zT_5;
    return zT_6;
}

/* EOF */
