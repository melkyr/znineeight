#include "type_resolver_7446D285.h"
#include <stdio.h>
zT_C890C8CB_TypeResolver zG_C890C8CB_TypeResolver;
unsigned int zG_E6DB2ACE_MODULE_ID_NONE;
/* localTypeScopeInit */
zT_C8A278E4_LocalTypeScope zF_8A85AA66_localTypeScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_C8A278E4_LocalTypeScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_2 = 0;
    zT_1.names = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.types = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* nameScopeGrowPair */
void zF_F638C869_nameScopeGrowPair(zT_3E40CD83_Sand* alloc, unsigned int** names, unsigned int** values, unsigned int count, unsigned int* cap, unsigned int min_cap) {
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_10;
    int zT_11;
    zT_3E40CD83_Sand* zT_14;
    zT_E1B9232E_EU_442 zT_20 = {0};
    unsigned char zT_21;
    unsigned char* zT_22;
    zT_3E40CD83_Sand* zT_25;
    zT_E1B9232E_EU_442 zT_31 = {0};
    unsigned char zT_32;
    unsigned char* zT_33;
    unsigned int* zT_36;
    unsigned int* zT_38;
    int zT_40;
    unsigned int zT_41;
    unsigned int* zT_43;
    unsigned int zT_44;
    unsigned int* zT_45;
    unsigned int zT_46;
    int zT_47;
    unsigned int zT_49;
    unsigned int nc;
    unsigned char* raw_n;
    unsigned char* raw_v;
    unsigned int* nn;
    unsigned int* nv;
    unsigned int i;
    zT_7 = *cap;
    if ((unsigned char)(zT_7 < min_cap)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = min_cap;
    goto z_bb_3;
    z_bb_2:
    zT_10 = *cap;
    zT_11 = 2;
    zT_9 = zT_10 * zT_11;
    goto z_bb_3;
    z_bb_3:
    nc = zT_9;
    zT_14 = alloc;
    zT_20 = zF_1395EB68_sandAlloc(zT_14, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_21 = zT_20.is_error;
    if (zT_21) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_22 = zT_20.data.payload;
    goto z_bb_6;
    z_bb_6:
    raw_n = zT_22;
    zT_25 = alloc;
    zT_31 = zF_1395EB68_sandAlloc(zT_25, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_33 = zT_31.data.payload;
    goto z_bb_9;
    z_bb_9:
    raw_v = zT_33;
    zT_36 = (unsigned int*)raw_n;
    nn = zT_36;
    zT_38 = (unsigned int*)raw_v;
    nv = zT_38;
    zT_40 = 0;
    zT_41 = (unsigned int)zT_40;
    i = zT_41;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(i < count)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_43 = *names;
    zT_44 = zT_43[i];
    nn[i] = zT_44;
    zT_45 = *values;
    zT_46 = zT_45[i];
    nv[i] = zT_46;
    goto z_bb_13;
    z_bb_12:
    *names = nn;
    *values = nv;
    *cap = nc;
    return;
    z_bb_13:
    zT_47 = 1;
    zT_49 = i + (unsigned int)((unsigned int)zT_47);
    i = zT_49;
    goto z_bb_10;
}

/* nameScopeLookup */
zT_BAEE192E_Opt_10 zF_1B08A8E4_nameScopeLookup(unsigned int* names, unsigned int* values, unsigned int count, unsigned int name_id) {
    unsigned int zT_8;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_BAEE192E_Opt_10 zT_13 = {0};
    unsigned int i;
    i = count;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i > (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_8 = i - (unsigned int)(1);
    i = zT_8;
    zT_9 = names[i];
    if ((unsigned char)(zT_9 == name_id)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_13.has_value = 0;
    return zT_13;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = values[i];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
    z_bb_6:
    goto z_bb_4;
}

/* localTypeScopePush */
void zF_A3A445A0_localTypeScopePush(zT_C8A278E4_LocalTypeScope* scope, unsigned int name_id, unsigned int type_id) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    unsigned int** zT_7;
    unsigned int** zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_18;
    unsigned int zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = scope->alloc;
    zT_7 = &scope->names;
    zT_8 = &scope->types;
    zT_9 = scope->count;
    zT_10 = &scope->cap;
    zF_F638C869_nameScopeGrowPair(zT_6, zT_7, zT_8, zT_9, zT_10, (unsigned int)(8));
    goto z_bb_2;
    z_bb_2:
    zT_18 = scope->names;
    zT_19 = scope->count;
    zT_18[zT_19] = name_id;
    zT_20 = scope->types;
    zT_21 = scope->count;
    zT_20[zT_21] = type_id;
    zT_22 = scope->count;
    scope->count = (unsigned int)(zT_22 + (unsigned int)(1));
    return;
}

/* localTypeScopeLookup */
zT_BAEE192E_Opt_10 zF_C768898A_localTypeScopeLooku(zT_C8A278E4_LocalTypeScope* scope, unsigned int name_id) {
    unsigned int* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    zT_2 = scope->names;
    zT_3 = scope->types;
    zT_4 = scope->count;
    zT_5 = name_id;
    zT_9 = zF_1B08A8E4_nameScopeLookup(zT_2, zT_3, zT_4, zT_5);
    return zT_9;
}

/* localConstScopeInit */
zT_E2DF2801_LocalConstScope zF_F5EBC2FF_localConstScopeInit(zT_3E40CD83_Sand* alloc) {
    zT_E2DF2801_LocalConstScope zT_1;
    int zT_2;
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_2 = 0;
    zT_1.names = (unsigned int*)zT_2;
    zT_3 = 0;
    zT_1.nodes = (unsigned int*)zT_3;
    zT_4 = 0;
    zT_1.count = zT_4;
    zT_5 = 0;
    zT_1.cap = zT_5;
    zT_1.alloc = alloc;
    return zT_1;
}

/* localConstScopePush */
void zF_DA915531_localConstScopePush(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id, unsigned int decl_node) {
    unsigned int zT_3;
    unsigned int zT_4;
    zT_3E40CD83_Sand* zT_6;
    unsigned int** zT_7;
    unsigned int** zT_8;
    unsigned int zT_9;
    unsigned int* zT_10;
    unsigned int* zT_18;
    unsigned int zT_19;
    unsigned int* zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_3 = scope->count;
    zT_4 = scope->cap;
    if ((unsigned char)(zT_3 >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_6 = scope->alloc;
    zT_7 = &scope->names;
    zT_8 = &scope->nodes;
    zT_9 = scope->count;
    zT_10 = &scope->cap;
    zF_F638C869_nameScopeGrowPair(zT_6, zT_7, zT_8, zT_9, zT_10, (unsigned int)(8));
    goto z_bb_2;
    z_bb_2:
    zT_18 = scope->names;
    zT_19 = scope->count;
    zT_18[zT_19] = name_id;
    zT_20 = scope->nodes;
    zT_21 = scope->count;
    zT_20[zT_21] = decl_node;
    zT_22 = scope->count;
    scope->count = (unsigned int)(zT_22 + (unsigned int)(1));
    return;
}

/* localConstScopeLookup */
zT_BAEE192E_Opt_10 zF_6532C387_localConstScopeLook(zT_E2DF2801_LocalConstScope* scope, unsigned int name_id) {
    unsigned int* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_BAEE192E_Opt_10 zT_9 = {0};
    zT_2 = scope->names;
    zT_3 = scope->nodes;
    zT_4 = scope->count;
    zT_5 = name_id;
    zT_9 = zF_1B08A8E4_nameScopeLookup(zT_2, zT_3, zT_4, zT_5);
    return zT_9;
}

/* rawArrayEnsureCapacity */
void zF_BEFE4370_rawArrayEnsureCapac(zT_3E40CD83_Sand* alloc, unsigned char** items, unsigned int len, unsigned int* cap, unsigned int elem_size, unsigned int min_cap) {
    unsigned int zT_6;
    unsigned int zT_9;
    unsigned int zT_11;
    unsigned int zT_12;
    int zT_13;
    unsigned int zT_15;
    int zT_16;
    zT_3E40CD83_Sand* zT_19;
    unsigned char* zT_20;
    unsigned int zT_25;
    zT_70307317_Opt_244 zT_29 = {0};
    unsigned char zT_30;
    zT_3E40CD83_Sand* zT_32;
    zT_E1B9232E_EU_442 zT_37 = {0};
    unsigned char zT_38;
    unsigned char* zT_39;
    int zT_42;
    unsigned int zT_43;
    unsigned char* zT_46;
    unsigned char zT_47;
    int zT_48;
    unsigned int zT_50;
    unsigned int nc;
    zT_70307317_Opt_244 grown;
    unsigned char* raw;
    unsigned int ei;
    zT_6 = *cap;
    if ((unsigned char)(len < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_9 = *cap;
    if ((unsigned char)(zT_9 < min_cap)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_11 = min_cap;
    goto z_bb_5;
    z_bb_4:
    zT_12 = *cap;
    zT_13 = 2;
    zT_11 = zT_12 * zT_13;
    goto z_bb_5;
    z_bb_5:
    nc = zT_11;
    zT_15 = *cap;
    zT_16 = 0;
    if ((unsigned char)(zT_15 > (unsigned int)zT_16)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_19 = alloc;
    zT_20 = *items;
    zT_25 = *cap;
    zT_29 = zF_33A3D4F8_sandTryReallocInPla(zT_19, zT_20, (unsigned int)(zT_25 * elem_size), (unsigned int)(nc * elem_size), (unsigned int)(4));
    grown = zT_29;
    zT_30 = grown.has_value;
    if (zT_30) goto z_bb_8; else goto z_bb_9;
    z_bb_7:
    zT_32 = alloc;
    zT_37 = zF_1395EB68_sandAlloc(zT_32, (unsigned int)(nc * elem_size), (unsigned int)(4));
    zT_38 = zT_37.is_error;
    if (zT_38) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    *cap = nc;
    return;
    z_bb_9:
    goto z_bb_7;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_39 = zT_37.data.payload;
    goto z_bb_12;
    z_bb_12:
    raw = zT_39;
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    ei = zT_43;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(ei < (unsigned int)(len * elem_size))) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_46 = *items;
    zT_47 = zT_46[ei];
    raw[ei] = zT_47;
    goto z_bb_16;
    z_bb_15:
    *items = raw;
    *cap = nc;
    return;
    z_bb_16:
    zT_48 = 1;
    zT_50 = ei + (unsigned int)((unsigned int)zT_48);
    ei = zT_50;
    goto z_bb_13;
}

/* dependEnsureCapacity */
void zF_A2DE06A5_dependEnsureCapacit(zT_C890C8CB_TypeResolver* self) {
    zT_52CDA6EF_DepEdge* zT_2;
    unsigned char* zT_3;
    zT_3E40CD83_Sand* zT_4;
    unsigned char** zT_5;
    unsigned int zT_6;
    unsigned int* zT_7;
    unsigned char* p;
    zT_2 = self->depend_items;
    zT_3 = (unsigned char*)zT_2;
    p = zT_3;
    zT_4 = self->alloc;
    zT_5 = &p;
    zT_6 = self->depend_len;
    zT_7 = &self->depend_cap;
    zF_BEFE4370_rawArrayEnsureCapac(zT_4, zT_5, zT_6, zT_7, (unsigned int)(8), (unsigned int)(8));
    self->depend_items = (zT_52CDA6EF_DepEdge*)((zT_52CDA6EF_DepEdge*)p);
    return;
}

/* typeResolverAddEdge */
void zF_F1D68957_typeResolverAddEdge(zT_C890C8CB_TypeResolver* self, unsigned int from, unsigned int to) {
    zT_C890C8CB_TypeResolver* zT_3;
    zT_52CDA6EF_DepEdge zT_4;
    zT_52CDA6EF_DepEdge* zT_5;
    unsigned int zT_6;
    unsigned int zT_7;
    int zT_8;
    zT_3 = self;
    zF_A2DE06A5_dependEnsureCapacit(zT_3);
    zT_4.from = from;
    zT_4.to = to;
    zT_5 = self->depend_items;
    zT_6 = self->depend_len;
    zT_5[zT_6] = zT_4;
    zT_7 = self->depend_len;
    zT_8 = 1;
    self->depend_len = (unsigned int)(zT_7 + (unsigned int)((unsigned int)zT_8));
    return;
}

/* worklistEnsureCapacity */
void zF_0FC458B2_worklistEnsureCapac(zT_C890C8CB_TypeResolver* self) {
    unsigned int* zT_2;
    unsigned char* zT_3;
    zT_3E40CD83_Sand* zT_4;
    unsigned char** zT_5;
    unsigned int zT_6;
    unsigned int* zT_7;
    unsigned char* p;
    zT_2 = self->worklist_items;
    zT_3 = (unsigned char*)zT_2;
    p = zT_3;
    zT_4 = self->alloc;
    zT_5 = &p;
    zT_6 = self->worklist_len;
    zT_7 = &self->worklist_cap;
    zF_BEFE4370_rawArrayEnsureCapac(zT_4, zT_5, zT_6, zT_7, (unsigned int)(4), (unsigned int)(64));
    self->worklist_items = (unsigned int*)((unsigned int*)p);
    return;
}

/* worklistPush */
void zF_352BC6BC_worklistPush(zT_C890C8CB_TypeResolver* self, unsigned int id) {
    zT_C890C8CB_TypeResolver* zT_2;
    unsigned int* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    int zT_6;
    zT_2 = self;
    zF_0FC458B2_worklistEnsureCapac(zT_2);
    zT_3 = self->worklist_items;
    zT_4 = self->worklist_len;
    zT_3[zT_4] = id;
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 + (unsigned int)((unsigned int)zT_6));
    return;
}

/* worklistPop */
zT_BAEE192E_Opt_10 zF_D7A5282F_worklistPop(zT_C890C8CB_TypeResolver* self) {
    unsigned int zT_1;
    int zT_2;
    zT_BAEE192E_Opt_10 zT_4 = {0};
    unsigned int zT_5;
    int zT_6;
    unsigned int* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_BAEE192E_Opt_10 zT_12;
    zT_1 = self->worklist_len;
    zT_2 = 0;
    if ((unsigned char)(zT_1 == (unsigned int)zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_4.has_value = 0;
    return zT_4;
    z_bb_2:
    zT_5 = self->worklist_len;
    zT_6 = 1;
    self->worklist_len = (unsigned int)(zT_5 - (unsigned int)((unsigned int)zT_6));
    zT_9 = self->worklist_items;
    zT_10 = self->worklist_len;
    zT_11 = zT_9[zT_10];
    zT_12.has_value = 1;
    zT_12.value = zT_11;
    return zT_12;
}

/* inDegreeEnsureCapacity */
void zF_959DB1DC_inDegreeEnsureCapac(zT_C890C8CB_TypeResolver* self, unsigned int capacity) {
    unsigned int zT_2;
    int zT_5;
    int zT_7;
    unsigned int zT_8;
    zT_3E40CD83_Sand* zT_10;
    zT_E1B9232E_EU_442 zT_17 = {0};
    unsigned char zT_18;
    unsigned char* zT_19;
    unsigned int nc;
    unsigned char* raw;
    zT_2 = self->in_degree_cap;
    if ((unsigned char)(capacity <= zT_2)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    nc = capacity;
    zT_5 = 64;
    if ((unsigned char)(nc < (unsigned int)zT_5)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_7 = 64;
    zT_8 = (unsigned int)zT_7;
    nc = zT_8;
    goto z_bb_4;
    z_bb_4:
    zT_10 = self->alloc;
    zT_17 = zF_1395EB68_sandAlloc(zT_10, (unsigned int)(nc * (unsigned int)(4)), (unsigned int)(4));
    zT_18 = zT_17.is_error;
    if (zT_18) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_19 = zT_17.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw = zT_19;
    self->in_degree_items = (unsigned int*)((unsigned int*)raw);
    self->in_degree_cap = nc;
    return;
}

/* alignUp */
unsigned int zF_D2BAC673_alignUp_1(unsigned int v, unsigned int a) {
    return (unsigned int)((unsigned int)((unsigned int)(v + a) - (unsigned int)(1)) & (unsigned int)(~(unsigned int)(a - (unsigned int)(1))));
}

/* markerU32 */
void zF_C8A36147_markerU32(unsigned int value) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_2;
    unsigned int zT_4;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_5;
    int zT_8;
    unsigned char* zT_9;
    unsigned int zT_10;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_11;
    unsigned int zT_12 = 0;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned char* zT_21;
    unsigned int zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    zT_5826BFC7_Arr_unsigned_char_1 b;
    unsigned int l;
    unsigned int s;
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_2[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        b[_i] = zT_2[_i];
        _i++;
    }
}
    zT_4 = value;
    zT_8 = 0;
    zT_9 = (unsigned char*)((unsigned char*)b) + zT_8;
    zT_10 = (unsigned int)(12) - zT_8;
    zT_11.ptr = zT_9;
    zT_11.len = zT_10;
    zT_5 = zT_11;
    zT_12 = zF_A7504564_itoa(zT_4, zT_5);
    l = zT_12;
    zT_16 = (unsigned int)(11) - (unsigned int)((unsigned int)l);
    s = zT_16;
    zT_21 = (unsigned char*)((unsigned char*)b) + s;
    zT_22 = (unsigned int)(11) - s;
    zT_23.ptr = zT_21;
    zT_23.len = zT_22;
    zT_17 = zT_23;
    zF_48AC7B3A_markerWrite(zT_17);
    return;
}

/* layoutCompute */
void zF_0E9E97D8_layoutCompute(zT_338B7C76_TypeRegistry* registry, unsigned int tid) {
    unsigned int zT_3;
    zT_D155D06D_Type* zT_5;
    zT_D155D06D_Type zT_6;
    zT_33EF6BFB_TypeKind zT_7;
    unsigned char zT_11;
    zT_338B7C76_TypeRegistry* zT_16;
    unsigned int zT_17;
    zT_406493CE_StructPayload* zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    zT_406493CE_StructPayload zT_22;
    unsigned int zT_24;
    unsigned int zT_25;
    unsigned short zT_27;
    unsigned int zT_28;
    int zT_30;
    unsigned int zT_31;
    int zT_33;
    unsigned int zT_34;
    int zT_36;
    unsigned int zT_37;
    zT_2DF01B61_FieldEntry* zT_40;
    unsigned int zT_41;
    zT_2DF01B61_FieldEntry zT_42;
    zT_D155D06D_Type* zT_44;
    unsigned int zT_45;
    unsigned int zT_46;
    zT_D155D06D_Type zT_47;
    zT_33EF6BFB_TypeKind zT_48;
    zT_2DF01B61_FieldEntry* zT_52;
    unsigned int zT_53;
    unsigned int zT_54;
    unsigned short zT_56;
    unsigned int zT_58 = 0;
    zT_2DF01B61_FieldEntry* zT_59;
    unsigned int zT_60;
    unsigned int zT_61;
    unsigned int zT_62;
    unsigned short zT_63;
    unsigned short zT_65;
    unsigned int zT_66;
    int zT_67;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned int zT_71;
    unsigned int zT_72 = 0;
    unsigned int zT_74;
    zT_D155D06D_Type* zT_79;
    zT_33EF6BFB_TypeKind zT_80;
    zT_457ECFEE_EnumPayload* zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_457ECFEE_EnumPayload zT_88;
    zT_D155D06D_Type* zT_90;
    unsigned int zT_91;
    unsigned int zT_92;
    zT_D155D06D_Type zT_93;
    unsigned int zT_94;
    unsigned short zT_95;
    zT_D155D06D_Type* zT_97;
    zT_33EF6BFB_TypeKind zT_98;
    zT_AF9231A2_UnionPayload* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_AF9231A2_UnionPayload zT_106;
    unsigned int zT_108;
    unsigned int zT_109;
    unsigned short zT_111;
    unsigned int zT_112;
    int zT_114;
    unsigned int zT_115;
    int zT_117;
    unsigned int zT_118;
    int zT_120;
    unsigned int zT_121;
    zT_2DF01B61_FieldEntry* zT_124;
    unsigned int zT_125;
    zT_2DF01B61_FieldEntry zT_126;
    zT_D155D06D_Type* zT_128;
    unsigned int zT_129;
    unsigned int zT_130;
    zT_D155D06D_Type zT_131;
    zT_33EF6BFB_TypeKind zT_132;
    unsigned int zT_136;
    unsigned int zT_138;
    unsigned short zT_139;
    unsigned short zT_141;
    unsigned int zT_142;
    int zT_143;
    unsigned int zT_145;
    unsigned int zT_146;
    unsigned int zT_147;
    unsigned int zT_148 = 0;
    unsigned int zT_150;
    zT_D155D06D_Type* zT_155;
    zT_33EF6BFB_TypeKind zT_156;
    zT_338B7C76_TypeRegistry* zT_160;
    unsigned int zT_161;
    zT_33EF6BFB_TypeKind zT_162;
    zT_54FF90FA_TaggedUnionPayload* zT_167;
    unsigned int zT_168;
    unsigned int zT_169;
    zT_54FF90FA_TaggedUnionPayload zT_170;
    zT_D155D06D_Type* zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    zT_D155D06D_Type zT_175;
    unsigned int zT_177;
    unsigned int zT_178;
    unsigned short zT_180;
    unsigned int zT_181;
    int zT_183;
    unsigned int zT_184;
    int zT_186;
    unsigned int zT_187;
    int zT_189;
    unsigned int zT_190;
    zT_2DF01B61_FieldEntry* zT_193;
    unsigned int zT_194;
    zT_2DF01B61_FieldEntry zT_195;
    unsigned char* zT_197;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_198;
    unsigned int zT_199;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_200;
    unsigned char* zT_205;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_206;
    unsigned int zT_207;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_208;
    unsigned int zT_209;
    zT_D155D06D_Type* zT_212;
    unsigned int zT_213;
    unsigned int zT_214;
    zT_D155D06D_Type zT_215;
    zT_33EF6BFB_TypeKind zT_216;
    unsigned int zT_220;
    unsigned int zT_222;
    unsigned short zT_223;
    unsigned short zT_225;
    unsigned int zT_226;
    int zT_227;
    unsigned int zT_229;
    unsigned short zT_231;
    unsigned int zT_234;
    unsigned short zT_235;
    unsigned int zT_238;
    unsigned int zT_239;
    unsigned int zT_240;
    unsigned int zT_241 = 0;
    unsigned int zT_242;
    unsigned int zT_243;
    unsigned int zT_244 = 0;
    unsigned int zT_245;
    unsigned int zT_246;
    unsigned int zT_247;
    unsigned int zT_248 = 0;
    zT_D155D06D_Type* zT_250;
    zT_33EF6BFB_TypeKind zT_251;
    zT_0B10E8E9_OptionalPayload* zT_256;
    unsigned int zT_257;
    unsigned int zT_258;
    zT_0B10E8E9_OptionalPayload zT_259;
    zT_D155D06D_Type* zT_261;
    unsigned int zT_262;
    unsigned int zT_263;
    zT_D155D06D_Type zT_264;
    unsigned short zT_266;
    unsigned int zT_270;
    unsigned short zT_271;
    unsigned int zT_275;
    unsigned int zT_276;
    unsigned int zT_280 = 0;
    unsigned int zT_283 = 0;
    zT_D155D06D_Type* zT_285;
    zT_33EF6BFB_TypeKind zT_286;
    zT_42C2D6BF_EUPayload* zT_291;
    unsigned int zT_292;
    unsigned int zT_293;
    zT_42C2D6BF_EUPayload zT_294;
    zT_D155D06D_Type* zT_296;
    unsigned int zT_297;
    unsigned int zT_298;
    zT_D155D06D_Type zT_299;
    unsigned int zT_301;
    unsigned int zT_304;
    unsigned short zT_308;
    unsigned int zT_312;
    unsigned short zT_313;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319 = 0;
    unsigned int zT_320;
    unsigned int zT_323 = 0;
    unsigned int zT_325;
    unsigned int zT_326;
    unsigned int zT_327;
    unsigned int zT_328 = 0;
    zT_D155D06D_Type* zT_330;
    zT_33EF6BFB_TypeKind zT_331;
    zT_E834303C_ArrayPayload* zT_336;
    unsigned int zT_337;
    unsigned int zT_338;
    zT_E834303C_ArrayPayload zT_339;
    zT_D155D06D_Type* zT_341;
    unsigned int zT_342;
    unsigned int zT_343;
    zT_D155D06D_Type zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    unsigned short zT_348;
    zT_D155D06D_Type* zT_350;
    zT_33EF6BFB_TypeKind zT_351;
    zT_666DC2E1_TuplePayload* zT_356;
    unsigned int zT_357;
    unsigned int zT_358;
    zT_666DC2E1_TuplePayload zT_359;
    unsigned int zT_361;
    unsigned int zT_362;
    unsigned short zT_364;
    unsigned int zT_365;
    int zT_367;
    unsigned int zT_368;
    int zT_370;
    unsigned int zT_371;
    int zT_373;
    unsigned int zT_374;
    unsigned int* zT_377;
    unsigned int zT_378;
    unsigned int zT_379;
    zT_D155D06D_Type* zT_381;
    unsigned int zT_382;
    zT_D155D06D_Type zT_383;
    unsigned int zT_384;
    unsigned short zT_386;
    unsigned int zT_388 = 0;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned short zT_391;
    unsigned short zT_393;
    unsigned int zT_394;
    int zT_395;
    unsigned int zT_397;
    unsigned int zT_398;
    unsigned int zT_399;
    unsigned int zT_400 = 0;
    unsigned int zT_402;
    zT_D155D06D_Type* zT_407;
    unsigned int idx;
    zT_D155D06D_Type ty;
    zT_406493CE_StructPayload sp;
    unsigned int fstart;
    unsigned int fcount;
    unsigned int offset;
    unsigned int max_align;
    unsigned int fi;
    zT_2DF01B61_FieldEntry fe;
    zT_D155D06D_Type ft;
    zT_457ECFEE_EnumPayload ep;
    zT_D155D06D_Type bt;
    zT_AF9231A2_UnionPayload up;
    unsigned int max_sz;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_D155D06D_Type tag_ty;
    unsigned int max_ps;
    unsigned int max_pa;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fer_tm;
    unsigned int overall_align;
    unsigned int total;
    zT_0B10E8E9_OptionalPayload op;
    zT_D155D06D_Type pt;
    unsigned int pay_align;
    zT_42C2D6BF_EUPayload ep_1;
    unsigned int union_sz;
    unsigned int union_align;
    zT_E834303C_ArrayPayload ap;
    zT_D155D06D_Type et;
    zT_666DC2E1_TuplePayload tp_2;
    unsigned int estr;
    unsigned int ecount;
    unsigned int ei;
    unsigned int elem_tid;
    zT_3 = (unsigned int)tid;
    idx = zT_3;
    zT_5 = registry->types_items;
    zT_6 = zT_5[idx];
    ty = zT_6;
    zT_7 = ty.kind;
    if ((unsigned char)(zT_7 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_3;
    z_bb_1:
    zT_11 = ty.flags;
    if ((unsigned char)((unsigned char)(zT_11 & (unsigned char)(16)) != (unsigned char)(0))) goto z_bb_4; else goto z_bb_6;
    z_bb_2:
    return;
    z_bb_3:
    zT_80 = ty.kind;
    if ((unsigned char)(zT_80 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_4:
    zT_16 = registry;
    zT_17 = tid;
    zF_331152CD_typeRegistryCompute(zT_16, zT_17);
    goto z_bb_5;
    z_bb_5:
    goto z_bb_2;
    z_bb_6:
    zT_19 = registry->st_items;
    zT_20 = ty.payload_idx;
    zT_21 = (unsigned int)zT_20;
    zT_22 = zT_19[zT_21];
    sp = zT_22;
    zT_24 = sp.fields_start;
    zT_25 = (unsigned int)zT_24;
    fstart = zT_25;
    zT_27 = sp.fields_count;
    zT_28 = (unsigned int)zT_27;
    fcount = zT_28;
    zT_30 = 0;
    zT_31 = (unsigned int)zT_30;
    offset = zT_31;
    zT_33 = 1;
    zT_34 = (unsigned int)zT_33;
    max_align = zT_34;
    zT_36 = 0;
    zT_37 = (unsigned int)zT_36;
    fi = zT_37;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(fi < fcount)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = registry->fe_items;
    zT_41 = fstart + fi;
    zT_42 = zT_40[zT_41];
    fe = zT_42;
    zT_44 = registry->types_items;
    zT_45 = fe.type_id;
    zT_46 = (unsigned int)zT_45;
    zT_47 = zT_44[zT_46];
    ft = zT_47;
    zT_48 = ft.kind;
    if ((unsigned char)(zT_48 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    zT_70 = offset;
    zT_71 = max_align;
    zT_72 = zF_D2BAC673_alignUp_1(zT_70, zT_71);
    ty.size = zT_72;
    ty.alignment = (unsigned short)((unsigned short)max_align);
    zT_74 = ty.size;
    if ((unsigned char)(zT_74 == (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_10:
    zT_67 = 1;
    zT_69 = fi + (unsigned int)((unsigned int)zT_67);
    fi = zT_69;
    goto z_bb_7;
    z_bb_11:
    fe.offset = offset;
    zT_52 = registry->fe_items;
    zT_53 = fstart + fi;
    zT_52[zT_53] = fe;
    goto z_bb_12;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_54 = offset;
    zT_56 = ft.alignment;
    zT_58 = zF_D2BAC673_alignUp_1(zT_54, (unsigned int)((unsigned int)zT_56));
    offset = zT_58;
    fe.offset = offset;
    zT_59 = registry->fe_items;
    zT_60 = fstart + fi;
    zT_59[zT_60] = fe;
    zT_61 = ft.size;
    zT_62 = offset + zT_61;
    offset = zT_62;
    zT_63 = ft.alignment;
    if ((unsigned char)(zT_63 > max_align)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_65 = ft.alignment;
    zT_66 = (unsigned int)zT_65;
    max_align = zT_66;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned short)(1);
    goto z_bb_17;
    z_bb_17:
    zT_79 = registry->types_items;
    zT_79[idx] = ty;
    goto z_bb_5;
    z_bb_18:
    zT_85 = registry->en_items;
    zT_86 = ty.payload_idx;
    zT_87 = (unsigned int)zT_86;
    zT_88 = zT_85[zT_87];
    ep = zT_88;
    zT_90 = registry->types_items;
    zT_91 = ep.backing_type;
    zT_92 = (unsigned int)zT_91;
    zT_93 = zT_90[zT_92];
    bt = zT_93;
    zT_94 = bt.size;
    ty.size = zT_94;
    zT_95 = bt.alignment;
    ty.alignment = (unsigned short)((unsigned short)zT_95);
    zT_97 = registry->types_items;
    zT_97[idx] = ty;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_2;
    z_bb_20:
    zT_98 = ty.kind;
    if ((unsigned char)(zT_98 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_103 = registry->un_items;
    zT_104 = ty.payload_idx;
    zT_105 = (unsigned int)zT_104;
    zT_106 = zT_103[zT_105];
    up = zT_106;
    zT_108 = up.fields_start;
    zT_109 = (unsigned int)zT_108;
    fstart = zT_109;
    zT_111 = up.fields_count;
    zT_112 = (unsigned int)zT_111;
    fcount = zT_112;
    zT_114 = 0;
    zT_115 = (unsigned int)zT_114;
    max_sz = zT_115;
    zT_117 = 1;
    zT_118 = (unsigned int)zT_117;
    max_align = zT_118;
    zT_120 = 0;
    zT_121 = (unsigned int)zT_120;
    fi = zT_121;
    goto z_bb_24;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_156 = ty.kind;
    if ((unsigned char)(zT_156 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_36; else goto z_bb_38;
    z_bb_24:
    if ((unsigned char)(fi < fcount)) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_124 = registry->fe_items;
    zT_125 = fstart + fi;
    zT_126 = zT_124[zT_125];
    fe = zT_126;
    zT_128 = registry->types_items;
    zT_129 = fe.type_id;
    zT_130 = (unsigned int)zT_129;
    zT_131 = zT_128[zT_130];
    ft = zT_131;
    zT_132 = ft.kind;
    if ((unsigned char)(zT_132 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_28; else goto z_bb_29;
    z_bb_26:
    zT_146 = max_sz;
    zT_147 = max_align;
    zT_148 = zF_D2BAC673_alignUp_1(zT_146, zT_147);
    ty.size = zT_148;
    ty.alignment = (unsigned short)((unsigned short)max_align);
    zT_150 = ty.size;
    if ((unsigned char)(zT_150 == (unsigned int)(0))) goto z_bb_34; else goto z_bb_35;
    z_bb_27:
    zT_143 = 1;
    zT_145 = fi + (unsigned int)((unsigned int)zT_143);
    fi = zT_145;
    goto z_bb_24;
    z_bb_28:
    zT_136 = ft.size;
    if ((unsigned char)(zT_136 > max_sz)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    goto z_bb_27;
    z_bb_30:
    zT_138 = ft.size;
    max_sz = zT_138;
    goto z_bb_31;
    z_bb_31:
    zT_139 = ft.alignment;
    if ((unsigned char)(zT_139 > max_align)) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_141 = ft.alignment;
    zT_142 = (unsigned int)zT_141;
    max_align = zT_142;
    goto z_bb_33;
    z_bb_33:
    goto z_bb_29;
    z_bb_34:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned short)(1);
    goto z_bb_35;
    z_bb_35:
    zT_155 = registry->types_items;
    zT_155[idx] = ty;
    goto z_bb_22;
    z_bb_36:
    zT_160 = registry;
    zT_161 = tid;
    zF_62A8E268_typeRegistryCompute(zT_160, zT_161);
    goto z_bb_37;
    z_bb_37:
    goto z_bb_22;
    z_bb_38:
    zT_162 = ty.kind;
    if ((unsigned char)(zT_162 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_167 = registry->tu_items;
    zT_168 = ty.payload_idx;
    zT_169 = (unsigned int)zT_168;
    zT_170 = zT_167[zT_169];
    tp = zT_170;
    zT_172 = registry->types_items;
    zT_173 = tp.tag_type;
    zT_174 = (unsigned int)zT_173;
    zT_175 = zT_172[zT_174];
    tag_ty = zT_175;
    zT_177 = tp.fields_start;
    zT_178 = (unsigned int)zT_177;
    fstart = zT_178;
    zT_180 = tp.fields_count;
    zT_181 = (unsigned int)zT_180;
    fcount = zT_181;
    zT_183 = 0;
    zT_184 = (unsigned int)zT_183;
    max_ps = zT_184;
    zT_186 = 1;
    zT_187 = (unsigned int)zT_186;
    max_pa = zT_187;
    zT_189 = 0;
    zT_190 = (unsigned int)zT_189;
    fi = zT_190;
    goto z_bb_42;
    z_bb_40:
    goto z_bb_37;
    z_bb_41:
    zT_251 = ty.kind;
    if ((unsigned char)(zT_251 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_42:
    if ((unsigned char)(fi < fcount)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_193 = registry->fe_items;
    zT_194 = fstart + fi;
    zT_195 = zT_193[zT_194];
    fe = zT_195;
    zT_197 = "FER:n";
    zT_199 = 5;
    zT_198.ptr = zT_197;
    zT_198.len = zT_199;
    fer_nm = zT_198;
    zT_200 = fer_nm;
    zF_C914CB83_markerWriteInt(zT_200, (unsigned int)((unsigned int)(unsigned int)(fstart + fi)));
    zT_205 = "FER:t";
    zT_207 = 5;
    zT_206.ptr = zT_205;
    zT_206.len = zT_207;
    fer_tm = zT_206;
    zT_208 = fer_tm;
    zT_209 = fe.type_id;
    zF_C914CB83_markerWriteInt(zT_208, zT_209);
    zT_212 = registry->types_items;
    zT_213 = fe.type_id;
    zT_214 = (unsigned int)zT_213;
    zT_215 = zT_212[zT_214];
    ft = zT_215;
    zT_216 = ft.kind;
    if ((unsigned char)(zT_216 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_44:
    zT_231 = tag_ty.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_231) > max_pa)) goto z_bb_52; else goto z_bb_53;
    z_bb_45:
    zT_227 = 1;
    zT_229 = fi + (unsigned int)((unsigned int)zT_227);
    fi = zT_229;
    goto z_bb_42;
    z_bb_46:
    zT_220 = ft.size;
    if ((unsigned char)(zT_220 > max_ps)) goto z_bb_48; else goto z_bb_49;
    z_bb_47:
    goto z_bb_45;
    z_bb_48:
    zT_222 = ft.size;
    max_ps = zT_222;
    goto z_bb_49;
    z_bb_49:
    zT_223 = ft.alignment;
    if ((unsigned char)(zT_223 > max_pa)) goto z_bb_50; else goto z_bb_51;
    z_bb_50:
    zT_225 = ft.alignment;
    zT_226 = (unsigned int)zT_225;
    max_pa = zT_226;
    goto z_bb_51;
    z_bb_51:
    goto z_bb_47;
    z_bb_52:
    zT_235 = tag_ty.alignment;
    zT_234 = (unsigned int)zT_235;
    goto z_bb_54;
    z_bb_53:
    zT_234 = max_pa;
    goto z_bb_54;
    z_bb_54:
    overall_align = zT_234;
    zT_238 = tag_ty.size;
    total = zT_238;
    zT_239 = total;
    zT_240 = max_pa;
    zT_241 = zF_D2BAC673_alignUp_1(zT_239, zT_240);
    total = zT_241;
    zT_242 = max_ps;
    zT_243 = max_pa;
    zT_244 = zF_D2BAC673_alignUp_1(zT_242, zT_243);
    zT_245 = total + zT_244;
    total = zT_245;
    zT_246 = total;
    zT_247 = overall_align;
    zT_248 = zF_D2BAC673_alignUp_1(zT_246, zT_247);
    ty.size = zT_248;
    ty.alignment = (unsigned short)((unsigned short)overall_align);
    zT_250 = registry->types_items;
    zT_250[idx] = ty;
    goto z_bb_40;
    z_bb_55:
    zT_256 = registry->opt_items;
    zT_257 = ty.payload_idx;
    zT_258 = (unsigned int)zT_257;
    zT_259 = zT_256[zT_258];
    op = zT_259;
    zT_261 = registry->types_items;
    zT_262 = op.payload;
    zT_263 = (unsigned int)zT_262;
    zT_264 = zT_261[zT_263];
    pt = zT_264;
    zT_266 = pt.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_266) > (unsigned int)(4))) goto z_bb_58; else goto z_bb_59;
    z_bb_56:
    goto z_bb_40;
    z_bb_57:
    zT_286 = ty.kind;
    if ((unsigned char)(zT_286 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_61; else goto z_bb_63;
    z_bb_58:
    zT_271 = pt.alignment;
    zT_270 = (unsigned int)zT_271;
    goto z_bb_60;
    z_bb_59:
    zT_270 = 4;
    goto z_bb_60;
    z_bb_60:
    pay_align = zT_270;
    zT_276 = pt.size;
    zT_280 = zF_D2BAC673_alignUp_1(zT_276, (unsigned int)(4));
    zT_275 = pay_align;
    zT_283 = zF_D2BAC673_alignUp_1((unsigned int)(zT_280 + (unsigned int)(4)), zT_275);
    ty.size = zT_283;
    ty.alignment = (unsigned short)((unsigned short)pay_align);
    zT_285 = registry->types_items;
    zT_285[idx] = ty;
    goto z_bb_56;
    z_bb_61:
    zT_291 = registry->eu_items;
    zT_292 = ty.payload_idx;
    zT_293 = (unsigned int)zT_292;
    zT_294 = zT_291[zT_293];
    ep_1 = zT_294;
    zT_296 = registry->types_items;
    zT_297 = ep_1.payload;
    zT_298 = (unsigned int)zT_297;
    zT_299 = zT_296[zT_298];
    pt = zT_299;
    zT_301 = pt.size;
    if ((unsigned char)(zT_301 > (unsigned int)(4))) goto z_bb_64; else goto z_bb_65;
    z_bb_62:
    goto z_bb_56;
    z_bb_63:
    zT_331 = ty.kind;
    if ((unsigned char)(zT_331 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_70; else goto z_bb_72;
    z_bb_64:
    zT_304 = pt.size;
    goto z_bb_66;
    z_bb_65:
    zT_304 = 4;
    goto z_bb_66;
    z_bb_66:
    union_sz = zT_304;
    zT_308 = pt.alignment;
    if ((unsigned char)((unsigned int)((unsigned int)zT_308) > (unsigned int)(4))) goto z_bb_67; else goto z_bb_68;
    z_bb_67:
    zT_313 = pt.alignment;
    zT_312 = (unsigned int)zT_313;
    goto z_bb_69;
    z_bb_68:
    zT_312 = 4;
    goto z_bb_69;
    z_bb_69:
    union_align = zT_312;
    zT_317 = union_sz;
    zT_318 = union_align;
    zT_319 = zF_D2BAC673_alignUp_1(zT_317, zT_318);
    total = zT_319;
    zT_320 = total;
    zT_323 = zF_D2BAC673_alignUp_1(zT_320, (unsigned int)(4));
    zT_325 = zT_323 + (unsigned int)(4);
    total = zT_325;
    zT_326 = total;
    zT_327 = union_align;
    zT_328 = zF_D2BAC673_alignUp_1(zT_326, zT_327);
    ty.size = zT_328;
    ty.alignment = (unsigned short)((unsigned short)union_align);
    zT_330 = registry->types_items;
    zT_330[idx] = ty;
    goto z_bb_62;
    z_bb_70:
    zT_336 = registry->array_items;
    zT_337 = ty.payload_idx;
    zT_338 = (unsigned int)zT_337;
    zT_339 = zT_336[zT_338];
    ap = zT_339;
    zT_341 = registry->types_items;
    zT_342 = ap.elem;
    zT_343 = (unsigned int)zT_342;
    zT_344 = zT_341[zT_343];
    et = zT_344;
    zT_345 = et.size;
    zT_346 = ap.length;
    ty.size = (unsigned int)(zT_345 * zT_346);
    zT_348 = et.alignment;
    ty.alignment = (unsigned short)((unsigned short)zT_348);
    zT_350 = registry->types_items;
    zT_350[idx] = ty;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_62;
    z_bb_72:
    zT_351 = ty.kind;
    if ((unsigned char)(zT_351 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_73:
    zT_356 = registry->tup_items;
    zT_357 = ty.payload_idx;
    zT_358 = (unsigned int)zT_357;
    zT_359 = zT_356[zT_358];
    tp_2 = zT_359;
    zT_361 = tp_2.elems_start;
    zT_362 = (unsigned int)zT_361;
    estr = zT_362;
    zT_364 = tp_2.elems_count;
    zT_365 = (unsigned int)zT_364;
    ecount = zT_365;
    zT_367 = 0;
    zT_368 = (unsigned int)zT_367;
    offset = zT_368;
    zT_370 = 1;
    zT_371 = (unsigned int)zT_370;
    max_align = zT_371;
    zT_373 = 0;
    zT_374 = (unsigned int)zT_373;
    ei = zT_374;
    goto z_bb_75;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    if ((unsigned char)(ei < ecount)) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_377 = registry->xt_items;
    zT_378 = estr + ei;
    zT_379 = zT_377[zT_378];
    elem_tid = zT_379;
    zT_381 = registry->types_items;
    zT_382 = (unsigned int)elem_tid;
    zT_383 = zT_381[zT_382];
    et = zT_383;
    zT_384 = offset;
    zT_386 = et.alignment;
    zT_388 = zF_D2BAC673_alignUp_1(zT_384, (unsigned int)((unsigned int)zT_386));
    offset = zT_388;
    zT_389 = et.size;
    zT_390 = offset + zT_389;
    offset = zT_390;
    zT_391 = et.alignment;
    if ((unsigned char)(zT_391 > max_align)) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_398 = offset;
    zT_399 = max_align;
    zT_400 = zF_D2BAC673_alignUp_1(zT_398, zT_399);
    ty.size = zT_400;
    ty.alignment = (unsigned short)((unsigned short)max_align);
    zT_402 = ty.size;
    if ((unsigned char)(zT_402 == (unsigned int)(0))) goto z_bb_81; else goto z_bb_82;
    z_bb_78:
    zT_395 = 1;
    zT_397 = ei + (unsigned int)((unsigned int)zT_395);
    ei = zT_397;
    goto z_bb_75;
    z_bb_79:
    zT_393 = et.alignment;
    zT_394 = (unsigned int)zT_393;
    max_align = zT_394;
    goto z_bb_80;
    z_bb_80:
    goto z_bb_78;
    z_bb_81:
    ty.size = (unsigned int)(1);
    ty.alignment = (unsigned short)(1);
    goto z_bb_82;
    z_bb_82:
    zT_407 = registry->types_items;
    zT_407[idx] = ty;
    goto z_bb_74;
}

/* layoutDepOk */
unsigned char zF_BEEAF73E_layoutDepOk(zT_338B7C76_TypeRegistry* registry, unsigned int dep, unsigned int depth) {
    zT_338B7C76_TypeRegistry* zT_12;
    unsigned int zT_13;
    unsigned int zT_14;
    unsigned char zT_15 = 0;
    if ((unsigned char)(dep == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(dep == (unsigned int)(18))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(dep == (unsigned int)(1))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_12 = registry;
    zT_13 = dep;
    zT_14 = depth;
    zT_15 = zF_3E55D0D5_layoutEnsure(zT_12, zT_13, zT_14);
    return zT_15;
}

/* layoutFieldDepsOk */
unsigned char zF_B32C0425_layoutFieldDepsOk(zT_338B7C76_TypeRegistry* registry, unsigned int fstart, unsigned short fcount, unsigned int depth) {
    int zT_5;
    unsigned int zT_6;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    unsigned int zT_11;
    zT_2DF01B61_FieldEntry* zT_12;
    unsigned int zT_14;
    zT_2DF01B61_FieldEntry zT_15;
    unsigned char zT_17 = 0;
    int zT_20;
    unsigned int zT_22;
    unsigned int fi;
    zT_5 = 0;
    zT_6 = (unsigned int)zT_5;
    fi = zT_6;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(fi < (unsigned int)((unsigned int)fcount))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = registry;
    zT_12 = registry->fe_items;
    zT_14 = (unsigned int)((unsigned int)fstart) + fi;
    zT_15 = zT_12[zT_14];
    zT_10 = zT_15.type_id;
    zT_11 = depth;
    zT_17 = zF_BEEAF73E_layoutDepOk(zT_9, zT_10, zT_11);
    if ((unsigned char)(!zT_17)) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_20 = 1;
    zT_22 = fi + (unsigned int)((unsigned int)zT_20);
    fi = zT_22;
    goto z_bb_1;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    goto z_bb_4;
}

/* layoutEnsure */
unsigned char zF_3E55D0D5_layoutEnsure(zT_338B7C76_TypeRegistry* registry, unsigned int tid, unsigned int depth) {
    unsigned int zT_7;
    zT_D155D06D_Type* zT_11;
    unsigned int zT_12;
    zT_D155D06D_Type zT_13;
    unsigned char zT_14;
    unsigned char zT_22;
    unsigned char zT_24;
    zT_33EF6BFB_TypeKind zT_25;
    zT_406493CE_StructPayload* zT_30;
    unsigned int zT_31;
    unsigned int zT_32;
    zT_406493CE_StructPayload zT_33;
    zT_338B7C76_TypeRegistry* zT_34;
    unsigned int zT_35;
    unsigned short zT_36;
    unsigned char zT_42 = 0;
    zT_33EF6BFB_TypeKind zT_43;
    zT_457ECFEE_EnumPayload* zT_48;
    unsigned int zT_49;
    unsigned int zT_50;
    zT_457ECFEE_EnumPayload zT_51;
    zT_338B7C76_TypeRegistry* zT_52;
    unsigned int zT_53;
    unsigned char zT_58 = 0;
    zT_33EF6BFB_TypeKind zT_59;
    zT_AF9231A2_UnionPayload* zT_64;
    unsigned int zT_65;
    unsigned int zT_66;
    zT_AF9231A2_UnionPayload zT_67;
    zT_338B7C76_TypeRegistry* zT_68;
    unsigned int zT_69;
    unsigned short zT_70;
    unsigned char zT_76 = 0;
    zT_33EF6BFB_TypeKind zT_77;
    zT_AF9231A2_UnionPayload* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_AF9231A2_UnionPayload zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    unsigned int zT_87;
    unsigned short zT_88;
    unsigned char zT_94 = 0;
    zT_33EF6BFB_TypeKind zT_95;
    zT_54FF90FA_TaggedUnionPayload* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_54FF90FA_TaggedUnionPayload zT_103;
    zT_338B7C76_TypeRegistry* zT_104;
    unsigned int zT_105;
    unsigned char zT_110 = 0;
    zT_338B7C76_TypeRegistry* zT_111;
    unsigned int zT_112;
    unsigned short zT_113;
    unsigned char zT_119 = 0;
    zT_33EF6BFB_TypeKind zT_120;
    zT_E834303C_ArrayPayload* zT_125;
    unsigned int zT_126;
    unsigned int zT_127;
    zT_E834303C_ArrayPayload zT_128;
    zT_338B7C76_TypeRegistry* zT_129;
    unsigned int zT_130;
    unsigned char zT_135 = 0;
    zT_33EF6BFB_TypeKind zT_136;
    zT_666DC2E1_TuplePayload* zT_141;
    unsigned int zT_142;
    unsigned int zT_143;
    zT_666DC2E1_TuplePayload zT_144;
    int zT_146;
    unsigned int zT_147;
    unsigned short zT_148;
    zT_338B7C76_TypeRegistry* zT_151;
    unsigned int zT_152;
    unsigned int* zT_154;
    unsigned int zT_155;
    unsigned int zT_157;
    unsigned char zT_161 = 0;
    unsigned char zT_163;
    int zT_164;
    unsigned int zT_166;
    zT_33EF6BFB_TypeKind zT_167;
    zT_0B10E8E9_OptionalPayload* zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    zT_0B10E8E9_OptionalPayload zT_175;
    zT_338B7C76_TypeRegistry* zT_176;
    unsigned int zT_177;
    unsigned char zT_182 = 0;
    zT_33EF6BFB_TypeKind zT_183;
    zT_42C2D6BF_EUPayload* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_42C2D6BF_EUPayload zT_191;
    zT_338B7C76_TypeRegistry* zT_192;
    unsigned int zT_193;
    unsigned char zT_198 = 0;
    unsigned char zT_199;
    zT_338B7C76_TypeRegistry* zT_204;
    unsigned int zT_205;
    zT_D155D06D_Type* zT_207;
    zT_D155D06D_Type* zT_209;
    zT_D155D06D_Type ty;
    unsigned char deps_ok;
    unsigned char handled;
    zT_406493CE_StructPayload sp;
    zT_457ECFEE_EnumPayload ep;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload pup;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_E834303C_ArrayPayload ap;
    zT_666DC2E1_TuplePayload tup;
    unsigned int ei;
    zT_0B10E8E9_OptionalPayload op;
    zT_42C2D6BF_EUPayload eup;
    if ((unsigned char)(tid == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = registry->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_7)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_11 = registry->types_items;
    zT_12 = (unsigned int)tid;
    zT_13 = zT_11[zT_12];
    ty = zT_13;
    zT_14 = ty.state;
    if ((unsigned char)(zT_14 == (unsigned char)(2))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(1);
    z_bb_6:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_22 = 1;
    deps_ok = zT_22;
    zT_24 = 1;
    handled = zT_24;
    zT_25 = ty.kind;
    if ((unsigned char)(zT_25 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_9; else goto z_bb_11;
    z_bb_9:
    zT_30 = registry->st_items;
    zT_31 = ty.payload_idx;
    zT_32 = (unsigned int)zT_31;
    zT_33 = zT_30[zT_32];
    sp = zT_33;
    zT_34 = registry;
    zT_35 = sp.fields_start;
    zT_36 = sp.fields_count;
    zT_42 = zF_B32C0425_layoutFieldDepsOk(zT_34, zT_35, zT_36, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_42;
    goto z_bb_10;
    z_bb_10:
    if ((unsigned char)(!handled)) goto z_bb_44; else goto z_bb_45;
    z_bb_11:
    zT_43 = ty.kind;
    if ((unsigned char)(zT_43 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_12; else goto z_bb_14;
    z_bb_12:
    zT_48 = registry->en_items;
    zT_49 = ty.payload_idx;
    zT_50 = (unsigned int)zT_49;
    zT_51 = zT_48[zT_50];
    ep = zT_51;
    zT_52 = registry;
    zT_53 = ep.backing_type;
    zT_58 = zF_BEEAF73E_layoutDepOk(zT_52, zT_53, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_58;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_59 = ty.kind;
    if ((unsigned char)(zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_15; else goto z_bb_17;
    z_bb_15:
    zT_64 = registry->un_items;
    zT_65 = ty.payload_idx;
    zT_66 = (unsigned int)zT_65;
    zT_67 = zT_64[zT_66];
    up = zT_67;
    zT_68 = registry;
    zT_69 = up.fields_start;
    zT_70 = up.fields_count;
    zT_76 = zF_B32C0425_layoutFieldDepsOk(zT_68, zT_69, zT_70, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_76;
    goto z_bb_16;
    z_bb_16:
    goto z_bb_13;
    z_bb_17:
    zT_77 = ty.kind;
    if ((unsigned char)(zT_77 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_18; else goto z_bb_20;
    z_bb_18:
    zT_82 = registry->un_items;
    zT_83 = ty.payload_idx;
    zT_84 = (unsigned int)zT_83;
    zT_85 = zT_82[zT_84];
    pup = zT_85;
    zT_86 = registry;
    zT_87 = pup.fields_start;
    zT_88 = pup.fields_count;
    zT_94 = zF_B32C0425_layoutFieldDepsOk(zT_86, zT_87, zT_88, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_94;
    goto z_bb_19;
    z_bb_19:
    goto z_bb_16;
    z_bb_20:
    zT_95 = ty.kind;
    if ((unsigned char)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_21; else goto z_bb_23;
    z_bb_21:
    zT_100 = registry->tu_items;
    zT_101 = ty.payload_idx;
    zT_102 = (unsigned int)zT_101;
    zT_103 = zT_100[zT_102];
    tp = zT_103;
    zT_104 = registry;
    zT_105 = tp.tag_type;
    zT_110 = zF_BEEAF73E_layoutDepOk(zT_104, zT_105, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_110;
    if (deps_ok) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_19;
    z_bb_23:
    zT_120 = ty.kind;
    if ((unsigned char)(zT_120 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_26; else goto z_bb_28;
    z_bb_24:
    zT_111 = registry;
    zT_112 = tp.fields_start;
    zT_113 = tp.fields_count;
    zT_119 = zF_B32C0425_layoutFieldDepsOk(zT_111, zT_112, zT_113, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_119;
    goto z_bb_25;
    z_bb_25:
    goto z_bb_22;
    z_bb_26:
    zT_125 = registry->array_items;
    zT_126 = ty.payload_idx;
    zT_127 = (unsigned int)zT_126;
    zT_128 = zT_125[zT_127];
    ap = zT_128;
    zT_129 = registry;
    zT_130 = ap.elem;
    zT_135 = zF_BEEAF73E_layoutDepOk(zT_129, zT_130, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_135;
    goto z_bb_27;
    z_bb_27:
    goto z_bb_22;
    z_bb_28:
    zT_136 = ty.kind;
    if ((unsigned char)(zT_136 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_29; else goto z_bb_31;
    z_bb_29:
    zT_141 = registry->tup_items;
    zT_142 = ty.payload_idx;
    zT_143 = (unsigned int)zT_142;
    zT_144 = zT_141[zT_143];
    tup = zT_144;
    zT_146 = 0;
    zT_147 = (unsigned int)zT_146;
    ei = zT_147;
    goto z_bb_32;
    z_bb_30:
    goto z_bb_27;
    z_bb_31:
    zT_167 = ty.kind;
    if ((unsigned char)(zT_167 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_38; else goto z_bb_40;
    z_bb_32:
    zT_148 = tup.elems_count;
    if ((unsigned char)(ei < (unsigned int)((unsigned int)zT_148))) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_151 = registry;
    zT_154 = registry->xt_items;
    zT_155 = tup.elems_start;
    zT_157 = (unsigned int)((unsigned int)zT_155) + ei;
    zT_152 = zT_154[zT_157];
    zT_161 = zF_BEEAF73E_layoutDepOk(zT_151, zT_152, (unsigned int)(depth + (unsigned int)(1)));
    if ((unsigned char)(!zT_161)) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_30;
    z_bb_35:
    zT_164 = 1;
    zT_166 = ei + (unsigned int)((unsigned int)zT_164);
    ei = zT_166;
    goto z_bb_32;
    z_bb_36:
    zT_163 = 0;
    deps_ok = zT_163;
    goto z_bb_37;
    z_bb_37:
    goto z_bb_35;
    z_bb_38:
    zT_172 = registry->opt_items;
    zT_173 = ty.payload_idx;
    zT_174 = (unsigned int)zT_173;
    zT_175 = zT_172[zT_174];
    op = zT_175;
    zT_176 = registry;
    zT_177 = op.payload;
    zT_182 = zF_BEEAF73E_layoutDepOk(zT_176, zT_177, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_182;
    goto z_bb_39;
    z_bb_39:
    goto z_bb_30;
    z_bb_40:
    zT_183 = ty.kind;
    if ((unsigned char)(zT_183 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_41; else goto z_bb_43;
    z_bb_41:
    zT_188 = registry->eu_items;
    zT_189 = ty.payload_idx;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zT_188[zT_190];
    eup = zT_191;
    zT_192 = registry;
    zT_193 = eup.payload;
    zT_198 = zF_BEEAF73E_layoutDepOk(zT_192, zT_193, (unsigned int)(depth + (unsigned int)(1)));
    deps_ok = zT_198;
    goto z_bb_42;
    z_bb_42:
    goto z_bb_39;
    z_bb_43:
    zT_199 = 0;
    handled = zT_199;
    goto z_bb_42;
    z_bb_44:
    return (unsigned char)(0);
    z_bb_45:
    if ((unsigned char)(!deps_ok)) goto z_bb_46; else goto z_bb_47;
    z_bb_46:
    return (unsigned char)(0);
    z_bb_47:
    zT_204 = registry;
    zT_205 = tid;
    zF_0E9E97D8_layoutCompute(zT_204, zT_205);
    zT_207 = registry->types_items;
    zT_209 = zT_207 + (unsigned int)((unsigned int)tid);
    zT_209->state = (unsigned char)(2);
    return (unsigned char)(1);
}

/* typeResolverResolveLayout */
void zF_3957E0DF_typeResolverResolve(zT_C890C8CB_TypeResolver* self, unsigned int tid) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    unsigned char zT_7 = 0;
    zT_338B7C76_TypeRegistry* zT_9;
    unsigned int zT_10;
    zT_2 = self->registry;
    zT_3 = tid;
    zT_7 = zF_3E55D0D5_layoutEnsure(zT_2, zT_3, (unsigned int)(0));
    if ((unsigned char)(!zT_7)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_9 = self->registry;
    zT_10 = tid;
    zF_0E9E97D8_layoutCompute(zT_9, zT_10);
    goto z_bb_2;
    z_bb_2:
    return;
}

/* typeResolverInit */
zT_C890C8CB_TypeResolver zF_5BFAC855_typeResolverInit(zT_338B7C76_TypeRegistry* registry, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* alloc) {
    zT_C890C8CB_TypeResolver zT_3;
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    int zT_7;
    unsigned int zT_8;
    int zT_9;
    unsigned int zT_10;
    int zT_11;
    unsigned int zT_12;
    unsigned int zT_13;
    zT_3.registry = registry;
    zT_4 = 0;
    zT_3.depend_items = (zT_52CDA6EF_DepEdge*)zT_4;
    zT_5 = 0;
    zT_3.depend_len = zT_5;
    zT_6 = 0;
    zT_3.depend_cap = zT_6;
    zT_7 = 0;
    zT_3.in_degree_items = (unsigned int*)zT_7;
    zT_8 = 0;
    zT_3.in_degree_cap = zT_8;
    zT_9 = 0;
    zT_3.sorted_items = (unsigned int*)zT_9;
    zT_10 = 0;
    zT_3.sorted_len = zT_10;
    zT_11 = 0;
    zT_3.worklist_items = (unsigned int*)zT_11;
    zT_12 = 0;
    zT_3.worklist_len = zT_12;
    zT_13 = 0;
    zT_3.worklist_cap = zT_13;
    zT_3.diag = diag;
    zT_3.alloc = alloc;
    return zT_3;
}

/* typeResolverBuild */
void zF_33272F41_typeResolverBuild(zT_C890C8CB_TypeResolver* self, zT_4D61441E_DepGraph* g) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_C890C8CB_TypeResolver* zT_7;
    unsigned int zT_8;
    unsigned int zT_9;
    zT_52CDA6EF_DepEdge* zT_10;
    zT_52CDA6EF_DepEdge zT_11;
    zT_52CDA6EF_DepEdge* zT_13;
    zT_52CDA6EF_DepEdge zT_14;
    int zT_16;
    unsigned int zT_18;
    zT_338B7C76_TypeRegistry* zT_20;
    unsigned int zT_21;
    zT_C890C8CB_TypeResolver* zT_22;
    unsigned int zT_23;
    zT_3E40CD83_Sand* zT_25;
    zT_E1B9232E_EU_442 zT_32 = {0};
    unsigned char zT_33;
    unsigned char* zT_34;
    int zT_38;
    unsigned int zT_39;
    unsigned int zT_41;
    unsigned int* zT_42;
    int zT_43;
    unsigned int zT_45;
    int zT_47;
    unsigned int zT_48;
    unsigned int zT_49;
    zT_52CDA6EF_DepEdge* zT_52;
    zT_52CDA6EF_DepEdge zT_53;
    unsigned int zT_54;
    unsigned int* zT_57;
    unsigned int zT_58;
    unsigned int zT_59;
    int zT_60;
    unsigned int zT_62;
    unsigned int* zT_63;
    unsigned int zT_64;
    int zT_65;
    unsigned int zT_67;
    unsigned int i;
    unsigned int type_count;
    unsigned char* raw_sorted;
    unsigned int zi;
    unsigned int ei;
    unsigned int target;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    i = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = g->len;
    if ((unsigned char)(i < zT_5)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = self;
    zT_10 = g->items;
    zT_11 = zT_10[i];
    zT_8 = zT_11.from;
    zT_13 = g->items;
    zT_14 = zT_13[i];
    zT_9 = zT_14.to;
    zF_F1D68957_typeResolverAddEdge(zT_7, zT_8, zT_9);
    zT_16 = 1;
    zT_18 = i + (unsigned int)((unsigned int)zT_16);
    i = zT_18;
    goto z_bb_4;
    z_bb_3:
    zT_20 = self->registry;
    zT_21 = zT_20->types_len;
    type_count = zT_21;
    zT_22 = self;
    zT_23 = type_count;
    zF_959DB1DC_inDegreeEnsureCapac(zT_22, zT_23);
    zT_25 = self->alloc;
    zT_32 = zF_1395EB68_sandAlloc(zT_25, (unsigned int)(type_count * (unsigned int)(4)), (unsigned int)(4));
    zT_33 = zT_32.is_error;
    if (zT_33) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    pal_trap();
    z_bb_6:
    zT_34 = zT_32.data.payload;
    goto z_bb_7;
    z_bb_7:
    raw_sorted = zT_34;
    self->sorted_items = (unsigned int*)((unsigned int*)raw_sorted);
    zT_38 = 0;
    zT_39 = (unsigned int)zT_38;
    zi = zT_39;
    goto z_bb_8;
    z_bb_8:
    if ((unsigned char)(zi < type_count)) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_41 = 0;
    zT_42 = self->in_degree_items;
    zT_42[zi] = zT_41;
    zT_43 = 1;
    zT_45 = zi + (unsigned int)((unsigned int)zT_43);
    zi = zT_45;
    goto z_bb_11;
    z_bb_10:
    zT_47 = 0;
    zT_48 = (unsigned int)zT_47;
    ei = zT_48;
    goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_49 = self->depend_len;
    if ((unsigned char)(ei < zT_49)) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_52 = self->depend_items;
    zT_53 = zT_52[ei];
    zT_54 = zT_53.to;
    target = zT_54;
    if ((unsigned char)((unsigned int)((unsigned int)target) < type_count)) goto z_bb_16; else goto z_bb_17;
    z_bb_14:
    return;
    z_bb_15:
    goto z_bb_12;
    z_bb_16:
    zT_57 = self->in_degree_items;
    zT_58 = (unsigned int)target;
    zT_59 = zT_57[zT_58];
    zT_60 = 1;
    zT_62 = zT_59 + (unsigned int)((unsigned int)zT_60);
    zT_63 = self->in_degree_items;
    zT_64 = (unsigned int)target;
    zT_63[zT_64] = zT_62;
    goto z_bb_17;
    z_bb_17:
    zT_65 = 1;
    zT_67 = ei + (unsigned int)((unsigned int)zT_65);
    ei = zT_67;
    goto z_bb_15;
}

/* typeResolverResolve */
void zF_30BE7185_typeResolverResolve(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    int zT_4;
    int zT_7;
    unsigned int zT_8;
    unsigned int* zT_10;
    unsigned int zT_11;
    int zT_12;
    zT_C890C8CB_TypeResolver* zT_14;
    int zT_17;
    unsigned int zT_19;
    unsigned int zT_20;
    int zT_21;
    zT_C890C8CB_TypeResolver* zT_24;
    zT_BAEE192E_Opt_10 zT_25 = {0};
    unsigned char zT_26;
    unsigned int* zT_28;
    unsigned int zT_29;
    unsigned int zT_30;
    zT_C890C8CB_TypeResolver* zT_33;
    unsigned int zT_34;
    zT_338B7C76_TypeRegistry* zT_36;
    zT_D155D06D_Type* zT_37;
    zT_D155D06D_Type* zT_39;
    int zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    zT_52CDA6EF_DepEdge* zT_45;
    zT_52CDA6EF_DepEdge zT_46;
    unsigned int zT_47;
    zT_52CDA6EF_DepEdge* zT_50;
    zT_52CDA6EF_DepEdge zT_51;
    unsigned int zT_52;
    unsigned int zT_54;
    unsigned int* zT_56;
    unsigned int zT_57;
    int zT_58;
    unsigned int* zT_60;
    unsigned int zT_61;
    int zT_62;
    unsigned int zT_64;
    unsigned int* zT_65;
    unsigned int* zT_66;
    unsigned int zT_67;
    int zT_68;
    zT_C890C8CB_TypeResolver* zT_70;
    unsigned int zT_71;
    int zT_72;
    unsigned int zT_74;
    int zT_76;
    unsigned int zT_77;
    zT_338B7C76_TypeRegistry* zT_80;
    zT_D155D06D_Type* zT_81;
    zT_D155D06D_Type zT_82;
    unsigned char zT_83;
    unsigned char zT_86;
    unsigned int* zT_87;
    unsigned int zT_88;
    int zT_89;
    unsigned char* zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    zT_F85C5DED_DiagnosticCollector* zT_95;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_D155D06D_Type* zT_117;
    int zT_118;
    unsigned int zT_120;
    unsigned int type_count;
    unsigned int ti;
    zT_BAEE192E_Opt_10 tid_val;
    unsigned int ci;
    unsigned int tid;
    unsigned int ei;
    unsigned int dep;
    unsigned int dep_idx;
    zT_D155D06D_Type ty;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    type_count = zT_3;
    zT_4 = 0;
    if ((unsigned char)(type_count == (unsigned int)zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = 0;
    zT_8 = (unsigned int)zT_7;
    ti = zT_8;
    goto z_bb_3;
    z_bb_3:
    if ((unsigned char)(ti < type_count)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_10 = self->in_degree_items;
    zT_11 = zT_10[ti];
    zT_12 = 0;
    if ((unsigned char)(zT_11 == (unsigned int)zT_12)) goto z_bb_7; else goto z_bb_8;
    z_bb_5:
    goto z_bb_9;
    z_bb_6:
    goto z_bb_3;
    z_bb_7:
    zT_14 = self;
    zF_352BC6BC_worklistPush(zT_14, (unsigned int)((unsigned int)ti));
    goto z_bb_8;
    z_bb_8:
    zT_17 = 1;
    zT_19 = ti + (unsigned int)((unsigned int)zT_17);
    ti = zT_19;
    goto z_bb_6;
    z_bb_9:
    zT_20 = self->worklist_len;
    zT_21 = 0;
    if ((unsigned char)(zT_20 > (unsigned int)zT_21)) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_24 = self;
    zT_25 = zF_D7A5282F_worklistPop(zT_24);
    tid_val = zT_25;
    zT_26 = tid_val.has_value;
    if (zT_26) goto z_bb_13; else goto z_bb_14;
    z_bb_11:
    zT_76 = 0;
    zT_77 = (unsigned int)zT_76;
    ci = zT_77;
    goto z_bb_27;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    tid = tid_val.value;
    zT_28 = self->sorted_items;
    zT_29 = self->sorted_len;
    zT_28[zT_29] = tid;
    zT_30 = self->sorted_len;
    self->sorted_len = (unsigned int)(zT_30 + (unsigned int)(1));
    zT_33 = self;
    zT_34 = tid;
    zF_3957E0DF_typeResolverResolve(zT_33, zT_34);
    zT_36 = self->registry;
    zT_37 = zT_36->types_items;
    zT_39 = zT_37 + (unsigned int)((unsigned int)tid);
    zT_39->state = (unsigned char)(2);
    zT_41 = 0;
    zT_42 = (unsigned int)zT_41;
    ei = zT_42;
    goto z_bb_15;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_43 = self->depend_len;
    if ((unsigned char)(ei < zT_43)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_45 = self->depend_items;
    zT_46 = zT_45[ei];
    zT_47 = zT_46.from;
    if ((unsigned char)(zT_47 == tid)) goto z_bb_19; else goto z_bb_20;
    z_bb_17:
    goto z_bb_14;
    z_bb_18:
    goto z_bb_15;
    z_bb_19:
    zT_50 = self->depend_items;
    zT_51 = zT_50[ei];
    zT_52 = zT_51.to;
    dep = zT_52;
    zT_54 = (unsigned int)dep;
    dep_idx = zT_54;
    if ((unsigned char)(dep_idx < type_count)) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    zT_72 = 1;
    zT_74 = ei + (unsigned int)((unsigned int)zT_72);
    ei = zT_74;
    goto z_bb_18;
    z_bb_21:
    zT_56 = self->in_degree_items;
    zT_57 = zT_56[dep_idx];
    zT_58 = 0;
    if ((unsigned char)(zT_57 > (unsigned int)zT_58)) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_60 = self->in_degree_items;
    zT_61 = zT_60[dep_idx];
    zT_62 = 1;
    zT_64 = zT_61 - (unsigned int)((unsigned int)zT_62);
    zT_65 = self->in_degree_items;
    zT_65[dep_idx] = zT_64;
    zT_66 = self->in_degree_items;
    zT_67 = zT_66[dep_idx];
    zT_68 = 0;
    if ((unsigned char)(zT_67 == (unsigned int)zT_68)) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_22;
    z_bb_25:
    zT_70 = self;
    zT_71 = dep;
    zF_352BC6BC_worklistPush(zT_70, zT_71);
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    if ((unsigned char)(ci < type_count)) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    zT_80 = self->registry;
    zT_81 = zT_80->types_items;
    zT_82 = zT_81[ci];
    ty = zT_82;
    zT_83 = ty.state;
    if ((unsigned char)(zT_83 != (unsigned char)(2))) goto z_bb_31; else goto z_bb_32;
    z_bb_29:
    return;
    z_bb_30:
    zT_118 = 1;
    zT_120 = ci + (unsigned int)((unsigned int)zT_118);
    ci = zT_120;
    goto z_bb_27;
    z_bb_31:
    zT_87 = self->in_degree_items;
    zT_88 = zT_87[ci];
    zT_89 = 0;
    zT_86 = zT_88 > (unsigned int)zT_89;
    goto z_bb_33;
    z_bb_32:
    zT_86 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_86) goto z_bb_34; else goto z_bb_35;
    z_bb_34:
    zT_92 = "circular type dependency detected (type refers to itself)";
    zT_94 = 57;
    zT_93.ptr = zT_92;
    zT_93.len = zT_94;
    msg = zT_93;
    zT_95 = self->diag;
    zT_101 = msg;
    (void)zF_C82559AC_diagnosticCollector(zT_95, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3005_CIRCULAR_TYPE_DEPENDENCY)), (unsigned int)(0), (unsigned int)(0), (unsigned int)(0), zT_101);
    ty.kind = (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type);
    ty.size = (unsigned int)(0);
    ty.alignment = (unsigned short)(1);
    ty.state = (unsigned char)(2);
    zT_116 = self->registry;
    zT_117 = zT_116->types_items;
    zT_117[ci] = ty;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
}

/* kindIsAggregateCore */
unsigned char zF_95CB1909_kindIsAggregateCore(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    return zT_20;
}

/* fieldEmbedsByValue */
unsigned char zF_A47239A9_fieldEmbedsByValue(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    unsigned char zT_2 = 0;
    unsigned char zT_3;
    unsigned char zT_7;
    zT_1 = kind;
    zT_2 = zF_95CB1909_kindIsAggregateCore(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    return zT_7;
}

/* requiresFullDef */
unsigned char zF_EA3ED3F3_requiresFullDef(zT_33EF6BFB_TypeKind kind) {
    zT_33EF6BFB_TypeKind zT_1;
    unsigned char zT_2 = 0;
    unsigned char zT_3;
    unsigned char zT_7;
    zT_1 = kind;
    zT_2 = zF_95CB1909_kindIsAggregateCore(zT_1);
    if (zT_2) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_3 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_3;
    z_bb_2:
    zT_3 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_3) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_7 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_7 = 1;
    goto z_bb_6;
    z_bb_6:
    return zT_7;
}

/* typeResolverBuildDependencyGraph */
void zF_D5C4530C_typeResolverBuildDe(zT_C890C8CB_TypeResolver* self) {
    zT_338B7C76_TypeRegistry* zT_2;
    unsigned int zT_3;
    zT_3E40CD83_Sand* zT_7;
    zT_E1B9232E_EU_442 zT_14 = {0};
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned int* zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_338B7C76_TypeRegistry* zT_25;
    unsigned int* zT_27;
    unsigned int zT_30 = 0;
    unsigned int zT_32;
    zT_C890C8CB_TypeResolver* zT_34;
    unsigned int zT_35;
    unsigned int zT_37;
    int zT_40;
    unsigned int zT_42;
    int zT_43;
    unsigned int zT_45;
    unsigned int tl;
    unsigned char* raw;
    unsigned int* buf;
    unsigned int ti;
    unsigned int n;
    unsigned int k;
    zT_2 = self->registry;
    zT_3 = zT_2->types_len;
    tl = zT_3;
    if ((unsigned char)(tl == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = self->alloc;
    zT_14 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)(tl * (unsigned int)(4)), (unsigned int)(4));
    zT_15 = zT_14.is_error;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    pal_trap();
    z_bb_4:
    zT_16 = zT_14.data.payload;
    goto z_bb_5;
    z_bb_5:
    raw = zT_16;
    zT_19 = (unsigned int*)raw;
    buf = zT_19;
    zT_21 = 0;
    zT_22 = (unsigned int)zT_21;
    ti = zT_22;
    goto z_bb_6;
    z_bb_6:
    if ((unsigned char)(ti < tl)) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_25 = self->registry;
    zT_27 = buf;
    zT_30 = zF_F41AC8EB_typeRefs(zT_25, (unsigned int)((unsigned int)ti), zT_27);
    n = zT_30;
    zT_32 = 0;
    k = zT_32;
    goto z_bb_10;
    z_bb_8:
    return;
    z_bb_9:
    zT_43 = 1;
    zT_45 = ti + (unsigned int)((unsigned int)zT_43);
    ti = zT_45;
    goto z_bb_6;
    z_bb_10:
    if ((unsigned char)(k < n)) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_34 = self;
    zT_37 = (unsigned int)k;
    zT_35 = buf[zT_37];
    zF_F1D68957_typeResolverAddEdge(zT_34, zT_35, (unsigned int)((unsigned int)ti));
    goto z_bb_13;
    z_bb_12:
    goto z_bb_9;
    z_bb_13:
    zT_40 = 1;
    zT_42 = k + (unsigned int)((unsigned int)zT_40);
    k = zT_42;
    goto z_bb_10;
}

/* classifyTypeEmissionGroups */
void zF_ACC002C8_classifyTypeEmissio(zT_C890C8CB_TypeResolver* self, zT_786E6CF2_EmissionClassificat* classif, zT_3E40CD83_Sand* perm_alloc) {
    zT_338B7C76_TypeRegistry* zT_4;
    unsigned int zT_5;
    zT_3E40CD83_Sand* zT_7;
    int zT_10;
    int zT_12;
    zT_E1B9232E_EU_442 zT_14 = {0};
    unsigned char zT_15;
    unsigned char* zT_16;
    unsigned char* zT_19;
    int zT_21;
    unsigned int zT_22;
    zT_3E40CD83_Sand* zT_24;
    int zT_27;
    int zT_29;
    zT_E1B9232E_EU_442 zT_31 = {0};
    unsigned char zT_32;
    unsigned char* zT_33;
    unsigned int* zT_36;
    zT_3E40CD83_Sand* zT_38;
    int zT_41;
    int zT_43;
    zT_E1B9232E_EU_442 zT_45 = {0};
    unsigned char zT_46;
    unsigned char* zT_47;
    unsigned int* zT_50;
    zT_3E40CD83_Sand* zT_52;
    int zT_55;
    int zT_57;
    zT_E1B9232E_EU_442 zT_59 = {0};
    unsigned char zT_60;
    unsigned char* zT_61;
    unsigned int* zT_64;
    int zT_66;
    unsigned int zT_67;
    unsigned int zT_69;
    int zT_70;
    unsigned int zT_72;
    unsigned int zT_74;
    zT_3E40CD83_Sand* zT_76;
    int zT_79;
    int zT_81;
    zT_E1B9232E_EU_442 zT_83 = {0};
    unsigned char zT_84;
    unsigned char* zT_85;
    unsigned int* zT_88;
    unsigned int zT_90;
    unsigned int zT_92;
    int zT_94;
    unsigned int zT_95;
    zT_338B7C76_TypeRegistry* zT_98;
    zT_D155D06D_Type* zT_99;
    zT_D155D06D_Type zT_100;
    unsigned char zT_102;
    zT_33EF6BFB_TypeKind zT_103;
    zT_338B7C76_TypeRegistry* zT_108;
    zT_406493CE_StructPayload* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_406493CE_StructPayload zT_112;
    int zT_114;
    unsigned int zT_115;
    unsigned short zT_116;
    unsigned char zT_119;
    int zT_120;
    zT_338B7C76_TypeRegistry* zT_123;
    zT_2DF01B61_FieldEntry* zT_124;
    unsigned int zT_125;
    unsigned int zT_127;
    zT_2DF01B61_FieldEntry zT_128;
    unsigned int zT_129;
    zT_338B7C76_TypeRegistry* zT_131;
    zT_D155D06D_Type* zT_132;
    unsigned int zT_133;
    zT_D155D06D_Type zT_134;
    zT_33EF6BFB_TypeKind zT_135;
    unsigned char zT_137 = 0;
    unsigned char zT_138;
    zT_33EF6BFB_TypeKind zT_139;
    zT_3E40CD83_Sand* zT_143;
    unsigned int** zT_144;
    unsigned int** zT_145;
    unsigned int* zT_146;
    unsigned int zT_147;
    unsigned int zT_151;
    unsigned int zT_152;
    unsigned int zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    unsigned int zT_158;
    zT_33EF6BFB_TypeKind zT_159;
    zT_3E40CD83_Sand* zT_163;
    unsigned int** zT_164;
    unsigned int** zT_165;
    unsigned int* zT_166;
    unsigned int zT_167;
    unsigned int zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned int zT_174;
    unsigned int zT_175;
    unsigned int zT_176;
    unsigned int zT_178;
    int zT_179;
    unsigned int zT_181;
    zT_33EF6BFB_TypeKind zT_182;
    zT_338B7C76_TypeRegistry* zT_187;
    zT_54FF90FA_TaggedUnionPayload* zT_188;
    unsigned int zT_189;
    unsigned int zT_190;
    zT_54FF90FA_TaggedUnionPayload zT_191;
    int zT_193;
    unsigned int zT_194;
    unsigned short zT_195;
    unsigned char zT_198;
    int zT_199;
    zT_338B7C76_TypeRegistry* zT_202;
    zT_2DF01B61_FieldEntry* zT_203;
    unsigned int zT_204;
    unsigned int zT_206;
    zT_2DF01B61_FieldEntry zT_207;
    unsigned int zT_208;
    zT_338B7C76_TypeRegistry* zT_210;
    zT_D155D06D_Type* zT_211;
    unsigned int zT_212;
    zT_D155D06D_Type zT_213;
    zT_33EF6BFB_TypeKind zT_214;
    unsigned char zT_216 = 0;
    unsigned char zT_217;
    zT_33EF6BFB_TypeKind zT_218;
    zT_3E40CD83_Sand* zT_222;
    unsigned int** zT_223;
    unsigned int** zT_224;
    unsigned int* zT_225;
    unsigned int zT_226;
    unsigned int zT_230;
    unsigned int zT_231;
    unsigned int zT_232;
    unsigned int zT_233;
    unsigned int zT_234;
    unsigned int zT_235;
    unsigned int zT_237;
    zT_33EF6BFB_TypeKind zT_238;
    zT_3E40CD83_Sand* zT_242;
    unsigned int** zT_243;
    unsigned int** zT_244;
    unsigned int* zT_245;
    unsigned int zT_246;
    unsigned int zT_250;
    unsigned int zT_251;
    unsigned int zT_252;
    unsigned int zT_253;
    unsigned int zT_254;
    unsigned int zT_255;
    unsigned int zT_257;
    int zT_258;
    unsigned int zT_260;
    zT_33EF6BFB_TypeKind zT_261;
    zT_338B7C76_TypeRegistry* zT_266;
    zT_AF9231A2_UnionPayload* zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    zT_AF9231A2_UnionPayload zT_270;
    int zT_272;
    unsigned int zT_273;
    unsigned short zT_274;
    unsigned char zT_277;
    int zT_278;
    zT_338B7C76_TypeRegistry* zT_281;
    zT_2DF01B61_FieldEntry* zT_282;
    unsigned int zT_283;
    unsigned int zT_285;
    zT_2DF01B61_FieldEntry zT_286;
    unsigned int zT_287;
    zT_338B7C76_TypeRegistry* zT_289;
    zT_D155D06D_Type* zT_290;
    unsigned int zT_291;
    zT_D155D06D_Type zT_292;
    zT_33EF6BFB_TypeKind zT_293;
    unsigned char zT_295 = 0;
    unsigned char zT_296;
    zT_33EF6BFB_TypeKind zT_297;
    zT_3E40CD83_Sand* zT_301;
    unsigned int** zT_302;
    unsigned int** zT_303;
    unsigned int* zT_304;
    unsigned int zT_305;
    unsigned int zT_309;
    unsigned int zT_310;
    unsigned int zT_311;
    unsigned int zT_312;
    unsigned int zT_313;
    unsigned int zT_314;
    unsigned int zT_316;
    zT_33EF6BFB_TypeKind zT_317;
    zT_3E40CD83_Sand* zT_321;
    unsigned int** zT_322;
    unsigned int** zT_323;
    unsigned int* zT_324;
    unsigned int zT_325;
    unsigned int zT_329;
    unsigned int zT_330;
    unsigned int zT_331;
    unsigned int zT_332;
    unsigned int zT_333;
    unsigned int zT_334;
    unsigned int zT_336;
    int zT_337;
    unsigned int zT_339;
    zT_33EF6BFB_TypeKind zT_340;
    zT_338B7C76_TypeRegistry* zT_345;
    zT_AF9231A2_UnionPayload* zT_346;
    unsigned int zT_347;
    unsigned int zT_348;
    zT_AF9231A2_UnionPayload zT_349;
    int zT_351;
    unsigned int zT_352;
    unsigned short zT_353;
    unsigned char zT_356;
    int zT_357;
    zT_338B7C76_TypeRegistry* zT_360;
    zT_2DF01B61_FieldEntry* zT_361;
    unsigned int zT_362;
    unsigned int zT_364;
    zT_2DF01B61_FieldEntry zT_365;
    unsigned int zT_366;
    zT_338B7C76_TypeRegistry* zT_368;
    zT_D155D06D_Type* zT_369;
    unsigned int zT_370;
    zT_D155D06D_Type zT_371;
    zT_33EF6BFB_TypeKind zT_372;
    unsigned char zT_374 = 0;
    unsigned char zT_375;
    zT_33EF6BFB_TypeKind zT_376;
    zT_3E40CD83_Sand* zT_380;
    unsigned int** zT_381;
    unsigned int** zT_382;
    unsigned int* zT_383;
    unsigned int zT_384;
    unsigned int zT_388;
    unsigned int zT_389;
    unsigned int zT_390;
    unsigned int zT_391;
    unsigned int zT_392;
    unsigned int zT_393;
    unsigned int zT_395;
    zT_33EF6BFB_TypeKind zT_396;
    zT_3E40CD83_Sand* zT_400;
    unsigned int** zT_401;
    unsigned int** zT_402;
    unsigned int* zT_403;
    unsigned int zT_404;
    unsigned int zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    unsigned int zT_411;
    unsigned int zT_412;
    unsigned int zT_413;
    unsigned int zT_415;
    int zT_416;
    unsigned int zT_418;
    zT_33EF6BFB_TypeKind zT_419;
    zT_338B7C76_TypeRegistry* zT_424;
    zT_E834303C_ArrayPayload* zT_425;
    unsigned int zT_426;
    unsigned int zT_427;
    zT_E834303C_ArrayPayload zT_428;
    unsigned int zT_429;
    zT_338B7C76_TypeRegistry* zT_431;
    zT_D155D06D_Type* zT_432;
    unsigned int zT_433;
    zT_D155D06D_Type zT_434;
    zT_33EF6BFB_TypeKind zT_435;
    unsigned char zT_437 = 0;
    unsigned char zT_438;
    zT_33EF6BFB_TypeKind zT_439;
    zT_3E40CD83_Sand* zT_443;
    unsigned int** zT_444;
    unsigned int** zT_445;
    unsigned int* zT_446;
    unsigned int zT_447;
    unsigned int zT_451;
    unsigned int zT_452;
    unsigned int zT_453;
    unsigned int zT_454;
    unsigned int zT_455;
    unsigned int zT_456;
    unsigned int zT_458;
    zT_33EF6BFB_TypeKind zT_459;
    zT_3E40CD83_Sand* zT_463;
    unsigned int** zT_464;
    unsigned int** zT_465;
    unsigned int* zT_466;
    unsigned int zT_467;
    unsigned int zT_471;
    unsigned int zT_472;
    unsigned int zT_473;
    unsigned int zT_474;
    unsigned int zT_475;
    unsigned int zT_476;
    unsigned int zT_478;
    zT_33EF6BFB_TypeKind zT_479;
    zT_338B7C76_TypeRegistry* zT_484;
    zT_42C2D6BF_EUPayload* zT_485;
    unsigned int zT_486;
    unsigned int zT_487;
    zT_42C2D6BF_EUPayload zT_488;
    unsigned int zT_489;
    zT_338B7C76_TypeRegistry* zT_491;
    zT_D155D06D_Type* zT_492;
    unsigned int zT_493;
    zT_D155D06D_Type zT_494;
    zT_33EF6BFB_TypeKind zT_495;
    unsigned char zT_497 = 0;
    unsigned char zT_498;
    zT_33EF6BFB_TypeKind zT_499;
    zT_3E40CD83_Sand* zT_503;
    unsigned int** zT_504;
    unsigned int** zT_505;
    unsigned int* zT_506;
    unsigned int zT_507;
    unsigned int zT_511;
    unsigned int zT_512;
    unsigned int zT_513;
    unsigned int zT_514;
    unsigned int zT_515;
    unsigned int zT_516;
    unsigned int zT_518;
    zT_33EF6BFB_TypeKind zT_519;
    zT_3E40CD83_Sand* zT_523;
    unsigned int** zT_524;
    unsigned int** zT_525;
    unsigned int* zT_526;
    unsigned int zT_527;
    unsigned int zT_531;
    unsigned int zT_532;
    unsigned int zT_533;
    unsigned int zT_534;
    unsigned int zT_535;
    unsigned int zT_536;
    unsigned int zT_538;
    zT_33EF6BFB_TypeKind zT_539;
    zT_338B7C76_TypeRegistry* zT_544;
    zT_0B10E8E9_OptionalPayload* zT_545;
    unsigned int zT_546;
    unsigned int zT_547;
    zT_0B10E8E9_OptionalPayload zT_548;
    unsigned int zT_549;
    zT_338B7C76_TypeRegistry* zT_551;
    zT_D155D06D_Type* zT_552;
    unsigned int zT_553;
    zT_D155D06D_Type zT_554;
    zT_33EF6BFB_TypeKind zT_555;
    unsigned char zT_557 = 0;
    unsigned char zT_558;
    zT_33EF6BFB_TypeKind zT_559;
    zT_3E40CD83_Sand* zT_563;
    unsigned int** zT_564;
    unsigned int** zT_565;
    unsigned int* zT_566;
    unsigned int zT_567;
    unsigned int zT_571;
    unsigned int zT_572;
    unsigned int zT_573;
    unsigned int zT_574;
    unsigned int zT_575;
    unsigned int zT_576;
    unsigned int zT_578;
    zT_33EF6BFB_TypeKind zT_579;
    zT_3E40CD83_Sand* zT_583;
    unsigned int** zT_584;
    unsigned int** zT_585;
    unsigned int* zT_586;
    unsigned int zT_587;
    unsigned int zT_591;
    unsigned int zT_592;
    unsigned int zT_593;
    unsigned int zT_594;
    unsigned int zT_595;
    unsigned int zT_596;
    unsigned int zT_598;
    unsigned int zT_601;
    unsigned int zT_602;
    unsigned int zT_604;
    int zT_605;
    unsigned int zT_607;
    unsigned int zT_610;
    unsigned int zT_611;
    unsigned int zT_613;
    unsigned int zT_615;
    unsigned int zT_616;
    unsigned int zT_620;
    unsigned int zT_621;
    unsigned int zT_622;
    unsigned char zT_623;
    unsigned char zT_626;
    unsigned int zT_627;
    unsigned int zT_628;
    unsigned int zT_630;
    unsigned int zT_631;
    unsigned int zT_632;
    zT_3E40CD83_Sand* zT_634;
    unsigned int zT_635;
    zT_21D3708C_U32ToU32Map zT_636 = {0};
    zT_3E40CD83_Sand* zT_638;
    unsigned int zT_639;
    zT_21D3708C_U32ToU32Map zT_640 = {0};
    zT_3E40CD83_Sand* zT_642;
    unsigned int zT_643;
    zT_21D3708C_U32ToU32Map zT_644 = {0};
    unsigned int zT_646;
    int zT_647;
    unsigned int zT_648;
    zT_338B7C76_TypeRegistry* zT_651;
    zT_D155D06D_Type* zT_652;
    zT_D155D06D_Type zT_653;
    unsigned char zT_654;
    zT_21D3708C_U32ToU32Map* zT_657;
    unsigned int zT_664;
    zT_D155D06D_Type zT_665;
    unsigned char zT_666 = 0;
    zT_21D3708C_U32ToU32Map* zT_667;
    unsigned char zT_674;
    unsigned int zT_675;
    zT_33EF6BFB_TypeKind zT_678;
    unsigned char zT_680 = 0;
    unsigned char zT_681;
    unsigned char zT_683;
    unsigned char zT_684;
    unsigned char zT_687;
    unsigned char zT_689;
    zT_33EF6BFB_TypeKind zT_690;
    unsigned char zT_694;
    zT_33EF6BFB_TypeKind zT_695;
    unsigned char zT_699;
    zT_33EF6BFB_TypeKind zT_700;
    unsigned char zT_704;
    unsigned char zT_706;
    zT_33EF6BFB_TypeKind zT_707;
    unsigned char zT_711;
    unsigned int zT_712;
    unsigned char zT_715;
    unsigned char zT_718;
    unsigned char zT_721;
    unsigned char zT_724;
    zT_21D3708C_U32ToU32Map* zT_727;
    int zT_733;
    unsigned int zT_735;
    zT_338B7C76_TypeRegistry* zT_736;
    zT_21D3708C_U32ToU32Map* zT_737;
    zT_21D3708C_U32ToU32Map* zT_738;
    unsigned char* zT_743;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_744;
    unsigned int zT_745;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_746;
    unsigned int zT_747;
    unsigned char* zT_749;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_750;
    unsigned int zT_751;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_752;
    int zT_753;
    unsigned int zT_754;
    unsigned char zT_756;
    unsigned char* zT_760;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_761;
    unsigned int zT_762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_763;
    unsigned char* zT_765;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_766;
    unsigned int zT_767;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_768;
    unsigned char* zT_772;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_773;
    unsigned int zT_774;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_775;
    zT_338B7C76_TypeRegistry* zT_777;
    zT_D155D06D_Type* zT_778;
    zT_D155D06D_Type zT_779;
    zT_33EF6BFB_TypeKind zT_780;
    unsigned char* zT_783;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_784;
    unsigned int zT_785;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_786;
    int zT_787;
    unsigned int zT_789;
    unsigned int tl;
    unsigned char* po_raw;
    unsigned char* pointer_only;
    unsigned int wp_edge_cap;
    unsigned char* wp_to_raw;
    unsigned int* wp_to;
    unsigned char* wp_next_raw;
    unsigned int* wp_next;
    unsigned char* wp_head_raw;
    unsigned int* wp_head;
    unsigned int whi;
    unsigned int wp_count;
    unsigned char* wl_raw;
    unsigned int* worklist;
    unsigned int wl_head;
    unsigned int wl_tail;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_po;
    zT_406493CE_StructPayload sp;
    unsigned int fi;
    unsigned int ft_id;
    zT_D155D06D_Type ft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_AF9231A2_UnionPayload up;
    zT_AF9231A2_UnionPayload p_up;
    unsigned int pfi;
    unsigned int et;
    zT_D155D06D_Type et_ty;
    unsigned int eup;
    zT_D155D06D_Type eup_ty;
    unsigned int op_p;
    zT_D155D06D_Type op_ty;
    unsigned int cur;
    unsigned int e;
    zT_21D3708C_U32ToU32Map po_map;
    zT_21D3708C_U32ToU32Map nd_map;
    zT_21D3708C_U32ToU32Map sh_map;
    unsigned int plen;
    unsigned int parent_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u cls_nl;
    unsigned char is_synthetic;
    unsigned char is_clsv;
    unsigned char is_carrier64;
    unsigned char is_fn_named;
    zT_8F083A69_Slice_zT_0B42B2F8_u pfx;
    zT_8F083A69_Slice_zT_0B42B2F8_u ck;
    zT_8F083A69_Slice_zT_0B42B2F8_u cnl;
    zT_4 = self->registry;
    zT_5 = zT_4->types_len;
    tl = zT_5;
    zT_7 = perm_alloc;
    zT_10 = 1;
    zT_12 = 1;
    zT_14 = zF_1395EB68_sandAlloc(zT_7, (unsigned int)(zT_10 * tl), (unsigned int)((unsigned int)zT_12));
    zT_15 = zT_14.is_error;
    if (zT_15) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    pal_trap();
    z_bb_2:
    zT_16 = zT_14.data.payload;
    goto z_bb_3;
    z_bb_3:
    po_raw = zT_16;
    zT_19 = (unsigned char*)po_raw;
    pointer_only = zT_19;
    zT_21 = 4;
    zT_22 = tl * zT_21;
    wp_edge_cap = zT_22;
    zT_24 = perm_alloc;
    zT_27 = 4;
    zT_29 = 4;
    zT_31 = zF_1395EB68_sandAlloc(zT_24, (unsigned int)(zT_27 * wp_edge_cap), (unsigned int)((unsigned int)zT_29));
    zT_32 = zT_31.is_error;
    if (zT_32) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    pal_trap();
    z_bb_5:
    zT_33 = zT_31.data.payload;
    goto z_bb_6;
    z_bb_6:
    wp_to_raw = zT_33;
    zT_36 = (unsigned int*)wp_to_raw;
    wp_to = zT_36;
    zT_38 = perm_alloc;
    zT_41 = 4;
    zT_43 = 4;
    zT_45 = zF_1395EB68_sandAlloc(zT_38, (unsigned int)(zT_41 * wp_edge_cap), (unsigned int)((unsigned int)zT_43));
    zT_46 = zT_45.is_error;
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    pal_trap();
    z_bb_8:
    zT_47 = zT_45.data.payload;
    goto z_bb_9;
    z_bb_9:
    wp_next_raw = zT_47;
    zT_50 = (unsigned int*)wp_next_raw;
    wp_next = zT_50;
    zT_52 = perm_alloc;
    zT_55 = 4;
    zT_57 = 4;
    zT_59 = zF_1395EB68_sandAlloc(zT_52, (unsigned int)(zT_55 * tl), (unsigned int)((unsigned int)zT_57));
    zT_60 = zT_59.is_error;
    if (zT_60) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    pal_trap();
    z_bb_11:
    zT_61 = zT_59.data.payload;
    goto z_bb_12;
    z_bb_12:
    wp_head_raw = zT_61;
    zT_64 = (unsigned int*)wp_head_raw;
    wp_head = zT_64;
    zT_66 = 0;
    zT_67 = (unsigned int)zT_66;
    whi = zT_67;
    goto z_bb_13;
    z_bb_13:
    if ((unsigned char)(whi < tl)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_69 = 4294967295u;
    wp_head[whi] = zT_69;
    goto z_bb_16;
    z_bb_15:
    zT_74 = 0;
    wp_count = zT_74;
    zT_76 = perm_alloc;
    zT_79 = 4;
    zT_81 = 4;
    zT_83 = zF_1395EB68_sandAlloc(zT_76, (unsigned int)(zT_79 * tl), (unsigned int)((unsigned int)zT_81));
    zT_84 = zT_83.is_error;
    if (zT_84) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_70 = 1;
    zT_72 = whi + (unsigned int)((unsigned int)zT_70);
    whi = zT_72;
    goto z_bb_13;
    z_bb_17:
    pal_trap();
    z_bb_18:
    zT_85 = zT_83.data.payload;
    goto z_bb_19;
    z_bb_19:
    wl_raw = zT_85;
    zT_88 = (unsigned int*)wl_raw;
    worklist = zT_88;
    zT_90 = 0;
    wl_head = zT_90;
    zT_92 = 0;
    wl_tail = zT_92;
    zT_94 = 0;
    zT_95 = (unsigned int)zT_94;
    ti = zT_95;
    goto z_bb_20;
    z_bb_20:
    if ((unsigned char)(ti < tl)) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_98 = self->registry;
    zT_99 = zT_98->types_items;
    zT_100 = zT_99[ti];
    ty = zT_100;
    zT_102 = 1;
    is_po = zT_102;
    zT_103 = ty.kind;
    if ((unsigned char)(zT_103 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_24; else goto z_bb_26;
    z_bb_22:
    goto z_bb_130;
    z_bb_23:
    zT_605 = 1;
    zT_607 = ti + (unsigned int)((unsigned int)zT_605);
    ti = zT_607;
    goto z_bb_20;
    z_bb_24:
    zT_108 = self->registry;
    zT_109 = zT_108->st_items;
    zT_110 = ty.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    sp = zT_112;
    zT_114 = 0;
    zT_115 = (unsigned int)zT_114;
    fi = zT_115;
    goto z_bb_27;
    z_bb_25:
    pointer_only[ti] = is_po;
    if ((unsigned char)(is_po == (unsigned char)(0))) goto z_bb_128; else goto z_bb_129;
    z_bb_26:
    zT_182 = ty.kind;
    if ((unsigned char)(zT_182 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_42; else goto z_bb_44;
    z_bb_27:
    zT_116 = sp.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_116))) goto z_bb_31; else goto z_bb_32;
    z_bb_28:
    zT_123 = self->registry;
    zT_124 = zT_123->fe_items;
    zT_125 = sp.fields_start;
    zT_127 = (unsigned int)((unsigned int)zT_125) + fi;
    zT_128 = zT_124[zT_127];
    zT_129 = zT_128.type_id;
    ft_id = zT_129;
    zT_131 = self->registry;
    zT_132 = zT_131->types_items;
    zT_133 = (unsigned int)ft_id;
    zT_134 = zT_132[zT_133];
    ft = zT_134;
    zT_135 = ft.kind;
    zT_137 = zF_A47239A9_fieldEmbedsByValue(zT_135);
    if (zT_137) goto z_bb_34; else goto z_bb_36;
    z_bb_29:
    goto z_bb_25;
    z_bb_30:
    zT_179 = 1;
    zT_181 = fi + (unsigned int)((unsigned int)zT_179);
    fi = zT_181;
    goto z_bb_27;
    z_bb_31:
    zT_120 = 0;
    zT_119 = is_po != zT_120;
    goto z_bb_33;
    z_bb_32:
    zT_119 = 0;
    goto z_bb_33;
    z_bb_33:
    if (zT_119) goto z_bb_28; else goto z_bb_29;
    z_bb_34:
    zT_138 = 0;
    is_po = zT_138;
    goto z_bb_35;
    z_bb_35:
    goto z_bb_30;
    z_bb_36:
    zT_139 = ft.kind;
    if ((unsigned char)(zT_139 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_37; else goto z_bb_39;
    z_bb_37:
    zT_143 = perm_alloc;
    zT_144 = &wp_to;
    zT_145 = &wp_next;
    zT_146 = &wp_edge_cap;
    zT_147 = wp_count;
    zF_25C377BD_growWpEdges(zT_143, zT_144, zT_145, zT_146, zT_147);
    zT_151 = (unsigned int)ti;
    zT_152 = (unsigned int)wp_count;
    wp_to[zT_152] = zT_151;
    zT_153 = (unsigned int)ft_id;
    zT_154 = wp_head[zT_153];
    zT_155 = (unsigned int)wp_count;
    wp_next[zT_155] = zT_154;
    zT_156 = (unsigned int)ft_id;
    wp_head[zT_156] = wp_count;
    zT_158 = wp_count + (unsigned int)(1);
    wp_count = zT_158;
    goto z_bb_38;
    z_bb_38:
    goto z_bb_35;
    z_bb_39:
    zT_159 = ft.kind;
    if ((unsigned char)(zT_159 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_163 = perm_alloc;
    zT_164 = &wp_to;
    zT_165 = &wp_next;
    zT_166 = &wp_edge_cap;
    zT_167 = wp_count;
    zF_25C377BD_growWpEdges(zT_163, zT_164, zT_165, zT_166, zT_167);
    zT_171 = (unsigned int)ti;
    zT_172 = (unsigned int)wp_count;
    wp_to[zT_172] = zT_171;
    zT_173 = (unsigned int)ft_id;
    zT_174 = wp_head[zT_173];
    zT_175 = (unsigned int)wp_count;
    wp_next[zT_175] = zT_174;
    zT_176 = (unsigned int)ft_id;
    wp_head[zT_176] = wp_count;
    zT_178 = wp_count + (unsigned int)(1);
    wp_count = zT_178;
    goto z_bb_41;
    z_bb_41:
    goto z_bb_38;
    z_bb_42:
    zT_187 = self->registry;
    zT_188 = zT_187->tu_items;
    zT_189 = ty.payload_idx;
    zT_190 = (unsigned int)zT_189;
    zT_191 = zT_188[zT_190];
    tp = zT_191;
    zT_193 = 0;
    zT_194 = (unsigned int)zT_193;
    fi = zT_194;
    goto z_bb_45;
    z_bb_43:
    goto z_bb_25;
    z_bb_44:
    zT_261 = ty.kind;
    if ((unsigned char)(zT_261 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_60; else goto z_bb_62;
    z_bb_45:
    zT_195 = tp.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_195))) goto z_bb_49; else goto z_bb_50;
    z_bb_46:
    zT_202 = self->registry;
    zT_203 = zT_202->fe_items;
    zT_204 = tp.fields_start;
    zT_206 = (unsigned int)((unsigned int)zT_204) + fi;
    zT_207 = zT_203[zT_206];
    zT_208 = zT_207.type_id;
    ft_id = zT_208;
    zT_210 = self->registry;
    zT_211 = zT_210->types_items;
    zT_212 = (unsigned int)ft_id;
    zT_213 = zT_211[zT_212];
    ft = zT_213;
    zT_214 = ft.kind;
    zT_216 = zF_A47239A9_fieldEmbedsByValue(zT_214);
    if (zT_216) goto z_bb_52; else goto z_bb_54;
    z_bb_47:
    goto z_bb_43;
    z_bb_48:
    zT_258 = 1;
    zT_260 = fi + (unsigned int)((unsigned int)zT_258);
    fi = zT_260;
    goto z_bb_45;
    z_bb_49:
    zT_199 = 0;
    zT_198 = is_po != zT_199;
    goto z_bb_51;
    z_bb_50:
    zT_198 = 0;
    goto z_bb_51;
    z_bb_51:
    if (zT_198) goto z_bb_46; else goto z_bb_47;
    z_bb_52:
    zT_217 = 0;
    is_po = zT_217;
    goto z_bb_53;
    z_bb_53:
    goto z_bb_48;
    z_bb_54:
    zT_218 = ft.kind;
    if ((unsigned char)(zT_218 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_55; else goto z_bb_57;
    z_bb_55:
    zT_222 = perm_alloc;
    zT_223 = &wp_to;
    zT_224 = &wp_next;
    zT_225 = &wp_edge_cap;
    zT_226 = wp_count;
    zF_25C377BD_growWpEdges(zT_222, zT_223, zT_224, zT_225, zT_226);
    zT_230 = (unsigned int)ti;
    zT_231 = (unsigned int)wp_count;
    wp_to[zT_231] = zT_230;
    zT_232 = (unsigned int)ft_id;
    zT_233 = wp_head[zT_232];
    zT_234 = (unsigned int)wp_count;
    wp_next[zT_234] = zT_233;
    zT_235 = (unsigned int)ft_id;
    wp_head[zT_235] = wp_count;
    zT_237 = wp_count + (unsigned int)(1);
    wp_count = zT_237;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_53;
    z_bb_57:
    zT_238 = ft.kind;
    if ((unsigned char)(zT_238 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_242 = perm_alloc;
    zT_243 = &wp_to;
    zT_244 = &wp_next;
    zT_245 = &wp_edge_cap;
    zT_246 = wp_count;
    zF_25C377BD_growWpEdges(zT_242, zT_243, zT_244, zT_245, zT_246);
    zT_250 = (unsigned int)ti;
    zT_251 = (unsigned int)wp_count;
    wp_to[zT_251] = zT_250;
    zT_252 = (unsigned int)ft_id;
    zT_253 = wp_head[zT_252];
    zT_254 = (unsigned int)wp_count;
    wp_next[zT_254] = zT_253;
    zT_255 = (unsigned int)ft_id;
    wp_head[zT_255] = wp_count;
    zT_257 = wp_count + (unsigned int)(1);
    wp_count = zT_257;
    goto z_bb_59;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_266 = self->registry;
    zT_267 = zT_266->un_items;
    zT_268 = ty.payload_idx;
    zT_269 = (unsigned int)zT_268;
    zT_270 = zT_267[zT_269];
    up = zT_270;
    zT_272 = 0;
    zT_273 = (unsigned int)zT_272;
    fi = zT_273;
    goto z_bb_63;
    z_bb_61:
    goto z_bb_43;
    z_bb_62:
    zT_340 = ty.kind;
    if ((unsigned char)(zT_340 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_78; else goto z_bb_80;
    z_bb_63:
    zT_274 = up.fields_count;
    if ((unsigned char)(fi < (unsigned int)((unsigned int)zT_274))) goto z_bb_67; else goto z_bb_68;
    z_bb_64:
    zT_281 = self->registry;
    zT_282 = zT_281->fe_items;
    zT_283 = up.fields_start;
    zT_285 = (unsigned int)((unsigned int)zT_283) + fi;
    zT_286 = zT_282[zT_285];
    zT_287 = zT_286.type_id;
    ft_id = zT_287;
    zT_289 = self->registry;
    zT_290 = zT_289->types_items;
    zT_291 = (unsigned int)ft_id;
    zT_292 = zT_290[zT_291];
    ft = zT_292;
    zT_293 = ft.kind;
    zT_295 = zF_A47239A9_fieldEmbedsByValue(zT_293);
    if (zT_295) goto z_bb_70; else goto z_bb_72;
    z_bb_65:
    goto z_bb_61;
    z_bb_66:
    zT_337 = 1;
    zT_339 = fi + (unsigned int)((unsigned int)zT_337);
    fi = zT_339;
    goto z_bb_63;
    z_bb_67:
    zT_278 = 0;
    zT_277 = is_po != zT_278;
    goto z_bb_69;
    z_bb_68:
    zT_277 = 0;
    goto z_bb_69;
    z_bb_69:
    if (zT_277) goto z_bb_64; else goto z_bb_65;
    z_bb_70:
    zT_296 = 0;
    is_po = zT_296;
    goto z_bb_71;
    z_bb_71:
    goto z_bb_66;
    z_bb_72:
    zT_297 = ft.kind;
    if ((unsigned char)(zT_297 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_73; else goto z_bb_75;
    z_bb_73:
    zT_301 = perm_alloc;
    zT_302 = &wp_to;
    zT_303 = &wp_next;
    zT_304 = &wp_edge_cap;
    zT_305 = wp_count;
    zF_25C377BD_growWpEdges(zT_301, zT_302, zT_303, zT_304, zT_305);
    zT_309 = (unsigned int)ti;
    zT_310 = (unsigned int)wp_count;
    wp_to[zT_310] = zT_309;
    zT_311 = (unsigned int)ft_id;
    zT_312 = wp_head[zT_311];
    zT_313 = (unsigned int)wp_count;
    wp_next[zT_313] = zT_312;
    zT_314 = (unsigned int)ft_id;
    wp_head[zT_314] = wp_count;
    zT_316 = wp_count + (unsigned int)(1);
    wp_count = zT_316;
    goto z_bb_74;
    z_bb_74:
    goto z_bb_71;
    z_bb_75:
    zT_317 = ft.kind;
    if ((unsigned char)(zT_317 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_76; else goto z_bb_77;
    z_bb_76:
    zT_321 = perm_alloc;
    zT_322 = &wp_to;
    zT_323 = &wp_next;
    zT_324 = &wp_edge_cap;
    zT_325 = wp_count;
    zF_25C377BD_growWpEdges(zT_321, zT_322, zT_323, zT_324, zT_325);
    zT_329 = (unsigned int)ti;
    zT_330 = (unsigned int)wp_count;
    wp_to[zT_330] = zT_329;
    zT_331 = (unsigned int)ft_id;
    zT_332 = wp_head[zT_331];
    zT_333 = (unsigned int)wp_count;
    wp_next[zT_333] = zT_332;
    zT_334 = (unsigned int)ft_id;
    wp_head[zT_334] = wp_count;
    zT_336 = wp_count + (unsigned int)(1);
    wp_count = zT_336;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_74;
    z_bb_78:
    zT_345 = self->registry;
    zT_346 = zT_345->un_items;
    zT_347 = ty.payload_idx;
    zT_348 = (unsigned int)zT_347;
    zT_349 = zT_346[zT_348];
    p_up = zT_349;
    zT_351 = 0;
    zT_352 = (unsigned int)zT_351;
    pfi = zT_352;
    goto z_bb_81;
    z_bb_79:
    goto z_bb_61;
    z_bb_80:
    zT_419 = ty.kind;
    if ((unsigned char)(zT_419 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_96; else goto z_bb_98;
    z_bb_81:
    zT_353 = p_up.fields_count;
    if ((unsigned char)(pfi < (unsigned int)((unsigned int)zT_353))) goto z_bb_85; else goto z_bb_86;
    z_bb_82:
    zT_360 = self->registry;
    zT_361 = zT_360->fe_items;
    zT_362 = p_up.fields_start;
    zT_364 = (unsigned int)((unsigned int)zT_362) + pfi;
    zT_365 = zT_361[zT_364];
    zT_366 = zT_365.type_id;
    ft_id = zT_366;
    zT_368 = self->registry;
    zT_369 = zT_368->types_items;
    zT_370 = (unsigned int)ft_id;
    zT_371 = zT_369[zT_370];
    ft = zT_371;
    zT_372 = ft.kind;
    zT_374 = zF_A47239A9_fieldEmbedsByValue(zT_372);
    if (zT_374) goto z_bb_88; else goto z_bb_90;
    z_bb_83:
    goto z_bb_79;
    z_bb_84:
    zT_416 = 1;
    zT_418 = pfi + (unsigned int)((unsigned int)zT_416);
    pfi = zT_418;
    goto z_bb_81;
    z_bb_85:
    zT_357 = 0;
    zT_356 = is_po != zT_357;
    goto z_bb_87;
    z_bb_86:
    zT_356 = 0;
    goto z_bb_87;
    z_bb_87:
    if (zT_356) goto z_bb_82; else goto z_bb_83;
    z_bb_88:
    zT_375 = 0;
    is_po = zT_375;
    goto z_bb_89;
    z_bb_89:
    goto z_bb_84;
    z_bb_90:
    zT_376 = ft.kind;
    if ((unsigned char)(zT_376 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_91; else goto z_bb_93;
    z_bb_91:
    zT_380 = perm_alloc;
    zT_381 = &wp_to;
    zT_382 = &wp_next;
    zT_383 = &wp_edge_cap;
    zT_384 = wp_count;
    zF_25C377BD_growWpEdges(zT_380, zT_381, zT_382, zT_383, zT_384);
    zT_388 = (unsigned int)ti;
    zT_389 = (unsigned int)wp_count;
    wp_to[zT_389] = zT_388;
    zT_390 = (unsigned int)ft_id;
    zT_391 = wp_head[zT_390];
    zT_392 = (unsigned int)wp_count;
    wp_next[zT_392] = zT_391;
    zT_393 = (unsigned int)ft_id;
    wp_head[zT_393] = wp_count;
    zT_395 = wp_count + (unsigned int)(1);
    wp_count = zT_395;
    goto z_bb_92;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_396 = ft.kind;
    if ((unsigned char)(zT_396 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_94; else goto z_bb_95;
    z_bb_94:
    zT_400 = perm_alloc;
    zT_401 = &wp_to;
    zT_402 = &wp_next;
    zT_403 = &wp_edge_cap;
    zT_404 = wp_count;
    zF_25C377BD_growWpEdges(zT_400, zT_401, zT_402, zT_403, zT_404);
    zT_408 = (unsigned int)ti;
    zT_409 = (unsigned int)wp_count;
    wp_to[zT_409] = zT_408;
    zT_410 = (unsigned int)ft_id;
    zT_411 = wp_head[zT_410];
    zT_412 = (unsigned int)wp_count;
    wp_next[zT_412] = zT_411;
    zT_413 = (unsigned int)ft_id;
    wp_head[zT_413] = wp_count;
    zT_415 = wp_count + (unsigned int)(1);
    wp_count = zT_415;
    goto z_bb_95;
    z_bb_95:
    goto z_bb_92;
    z_bb_96:
    zT_424 = self->registry;
    zT_425 = zT_424->array_items;
    zT_426 = ty.payload_idx;
    zT_427 = (unsigned int)zT_426;
    zT_428 = zT_425[zT_427];
    zT_429 = zT_428.elem;
    et = zT_429;
    zT_431 = self->registry;
    zT_432 = zT_431->types_items;
    zT_433 = (unsigned int)et;
    zT_434 = zT_432[zT_433];
    et_ty = zT_434;
    zT_435 = et_ty.kind;
    zT_437 = zF_A47239A9_fieldEmbedsByValue(zT_435);
    if (zT_437) goto z_bb_99; else goto z_bb_101;
    z_bb_97:
    goto z_bb_79;
    z_bb_98:
    zT_479 = ty.kind;
    if ((unsigned char)(zT_479 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_107; else goto z_bb_109;
    z_bb_99:
    zT_438 = 0;
    is_po = zT_438;
    goto z_bb_100;
    z_bb_100:
    goto z_bb_97;
    z_bb_101:
    zT_439 = et_ty.kind;
    if ((unsigned char)(zT_439 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_102; else goto z_bb_104;
    z_bb_102:
    zT_443 = perm_alloc;
    zT_444 = &wp_to;
    zT_445 = &wp_next;
    zT_446 = &wp_edge_cap;
    zT_447 = wp_count;
    zF_25C377BD_growWpEdges(zT_443, zT_444, zT_445, zT_446, zT_447);
    zT_451 = (unsigned int)ti;
    zT_452 = (unsigned int)wp_count;
    wp_to[zT_452] = zT_451;
    zT_453 = (unsigned int)et;
    zT_454 = wp_head[zT_453];
    zT_455 = (unsigned int)wp_count;
    wp_next[zT_455] = zT_454;
    zT_456 = (unsigned int)et;
    wp_head[zT_456] = wp_count;
    zT_458 = wp_count + (unsigned int)(1);
    wp_count = zT_458;
    goto z_bb_103;
    z_bb_103:
    goto z_bb_100;
    z_bb_104:
    zT_459 = et_ty.kind;
    if ((unsigned char)(zT_459 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_105; else goto z_bb_106;
    z_bb_105:
    zT_463 = perm_alloc;
    zT_464 = &wp_to;
    zT_465 = &wp_next;
    zT_466 = &wp_edge_cap;
    zT_467 = wp_count;
    zF_25C377BD_growWpEdges(zT_463, zT_464, zT_465, zT_466, zT_467);
    zT_471 = (unsigned int)ti;
    zT_472 = (unsigned int)wp_count;
    wp_to[zT_472] = zT_471;
    zT_473 = (unsigned int)et;
    zT_474 = wp_head[zT_473];
    zT_475 = (unsigned int)wp_count;
    wp_next[zT_475] = zT_474;
    zT_476 = (unsigned int)et;
    wp_head[zT_476] = wp_count;
    zT_478 = wp_count + (unsigned int)(1);
    wp_count = zT_478;
    goto z_bb_106;
    z_bb_106:
    goto z_bb_103;
    z_bb_107:
    zT_484 = self->registry;
    zT_485 = zT_484->eu_items;
    zT_486 = ty.payload_idx;
    zT_487 = (unsigned int)zT_486;
    zT_488 = zT_485[zT_487];
    zT_489 = zT_488.payload;
    eup = zT_489;
    zT_491 = self->registry;
    zT_492 = zT_491->types_items;
    zT_493 = (unsigned int)eup;
    zT_494 = zT_492[zT_493];
    eup_ty = zT_494;
    zT_495 = eup_ty.kind;
    zT_497 = zF_A47239A9_fieldEmbedsByValue(zT_495);
    if (zT_497) goto z_bb_110; else goto z_bb_112;
    z_bb_108:
    goto z_bb_97;
    z_bb_109:
    zT_539 = ty.kind;
    if ((unsigned char)(zT_539 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_118; else goto z_bb_119;
    z_bb_110:
    zT_498 = 0;
    is_po = zT_498;
    goto z_bb_111;
    z_bb_111:
    goto z_bb_108;
    z_bb_112:
    zT_499 = eup_ty.kind;
    if ((unsigned char)(zT_499 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_113; else goto z_bb_115;
    z_bb_113:
    zT_503 = perm_alloc;
    zT_504 = &wp_to;
    zT_505 = &wp_next;
    zT_506 = &wp_edge_cap;
    zT_507 = wp_count;
    zF_25C377BD_growWpEdges(zT_503, zT_504, zT_505, zT_506, zT_507);
    zT_511 = (unsigned int)ti;
    zT_512 = (unsigned int)wp_count;
    wp_to[zT_512] = zT_511;
    zT_513 = (unsigned int)eup;
    zT_514 = wp_head[zT_513];
    zT_515 = (unsigned int)wp_count;
    wp_next[zT_515] = zT_514;
    zT_516 = (unsigned int)eup;
    wp_head[zT_516] = wp_count;
    zT_518 = wp_count + (unsigned int)(1);
    wp_count = zT_518;
    goto z_bb_114;
    z_bb_114:
    goto z_bb_111;
    z_bb_115:
    zT_519 = eup_ty.kind;
    if ((unsigned char)(zT_519 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_116; else goto z_bb_117;
    z_bb_116:
    zT_523 = perm_alloc;
    zT_524 = &wp_to;
    zT_525 = &wp_next;
    zT_526 = &wp_edge_cap;
    zT_527 = wp_count;
    zF_25C377BD_growWpEdges(zT_523, zT_524, zT_525, zT_526, zT_527);
    zT_531 = (unsigned int)ti;
    zT_532 = (unsigned int)wp_count;
    wp_to[zT_532] = zT_531;
    zT_533 = (unsigned int)eup;
    zT_534 = wp_head[zT_533];
    zT_535 = (unsigned int)wp_count;
    wp_next[zT_535] = zT_534;
    zT_536 = (unsigned int)eup;
    wp_head[zT_536] = wp_count;
    zT_538 = wp_count + (unsigned int)(1);
    wp_count = zT_538;
    goto z_bb_117;
    z_bb_117:
    goto z_bb_114;
    z_bb_118:
    zT_544 = self->registry;
    zT_545 = zT_544->opt_items;
    zT_546 = ty.payload_idx;
    zT_547 = (unsigned int)zT_546;
    zT_548 = zT_545[zT_547];
    zT_549 = zT_548.payload;
    op_p = zT_549;
    zT_551 = self->registry;
    zT_552 = zT_551->types_items;
    zT_553 = (unsigned int)op_p;
    zT_554 = zT_552[zT_553];
    op_ty = zT_554;
    zT_555 = op_ty.kind;
    zT_557 = zF_EA3ED3F3_requiresFullDef(zT_555);
    if (zT_557) goto z_bb_120; else goto z_bb_122;
    z_bb_119:
    goto z_bb_108;
    z_bb_120:
    zT_558 = 0;
    is_po = zT_558;
    goto z_bb_121;
    z_bb_121:
    goto z_bb_119;
    z_bb_122:
    zT_559 = op_ty.kind;
    if ((unsigned char)(zT_559 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_123; else goto z_bb_125;
    z_bb_123:
    zT_563 = perm_alloc;
    zT_564 = &wp_to;
    zT_565 = &wp_next;
    zT_566 = &wp_edge_cap;
    zT_567 = wp_count;
    zF_25C377BD_growWpEdges(zT_563, zT_564, zT_565, zT_566, zT_567);
    zT_571 = (unsigned int)ti;
    zT_572 = (unsigned int)wp_count;
    wp_to[zT_572] = zT_571;
    zT_573 = (unsigned int)op_p;
    zT_574 = wp_head[zT_573];
    zT_575 = (unsigned int)wp_count;
    wp_next[zT_575] = zT_574;
    zT_576 = (unsigned int)op_p;
    wp_head[zT_576] = wp_count;
    zT_578 = wp_count + (unsigned int)(1);
    wp_count = zT_578;
    goto z_bb_124;
    z_bb_124:
    goto z_bb_121;
    z_bb_125:
    zT_579 = op_ty.kind;
    if ((unsigned char)(zT_579 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_126; else goto z_bb_127;
    z_bb_126:
    zT_583 = perm_alloc;
    zT_584 = &wp_to;
    zT_585 = &wp_next;
    zT_586 = &wp_edge_cap;
    zT_587 = wp_count;
    zF_25C377BD_growWpEdges(zT_583, zT_584, zT_585, zT_586, zT_587);
    zT_591 = (unsigned int)ti;
    zT_592 = (unsigned int)wp_count;
    wp_to[zT_592] = zT_591;
    zT_593 = (unsigned int)op_p;
    zT_594 = wp_head[zT_593];
    zT_595 = (unsigned int)wp_count;
    wp_next[zT_595] = zT_594;
    zT_596 = (unsigned int)op_p;
    wp_head[zT_596] = wp_count;
    zT_598 = wp_count + (unsigned int)(1);
    wp_count = zT_598;
    goto z_bb_127;
    z_bb_127:
    goto z_bb_124;
    z_bb_128:
    zT_601 = (unsigned int)ti;
    zT_602 = (unsigned int)wl_tail;
    worklist[zT_602] = zT_601;
    zT_604 = wl_tail + (unsigned int)(1);
    wl_tail = zT_604;
    goto z_bb_129;
    z_bb_129:
    goto z_bb_23;
    z_bb_130:
    if ((unsigned char)(wl_head < wl_tail)) goto z_bb_131; else goto z_bb_132;
    z_bb_131:
    zT_610 = (unsigned int)wl_head;
    zT_611 = worklist[zT_610];
    cur = zT_611;
    zT_613 = wl_head + (unsigned int)(1);
    wl_head = zT_613;
    zT_615 = (unsigned int)cur;
    zT_616 = wp_head[zT_615];
    e = zT_616;
    goto z_bb_134;
    z_bb_132:
    zT_634 = perm_alloc;
    zT_635 = tl;
    zT_636 = zF_619D56E6_u32ToU32MapInitCap(zT_634, zT_635);
    po_map = zT_636;
    zT_638 = perm_alloc;
    zT_639 = tl;
    zT_640 = zF_619D56E6_u32ToU32MapInitCap(zT_638, zT_639);
    nd_map = zT_640;
    zT_642 = perm_alloc;
    zT_643 = tl;
    zT_644 = zF_619D56E6_u32ToU32MapInitCap(zT_642, zT_643);
    sh_map = zT_644;
    zT_646 = 0;
    plen = zT_646;
    zT_647 = 0;
    zT_648 = (unsigned int)zT_647;
    ti = zT_648;
    goto z_bb_140;
    z_bb_133:
    goto z_bb_130;
    z_bb_134:
    if ((unsigned char)(e != (unsigned int)(4294967295u))) goto z_bb_135; else goto z_bb_136;
    z_bb_135:
    zT_620 = (unsigned int)e;
    zT_621 = wp_to[zT_620];
    parent_tid = zT_621;
    zT_622 = (unsigned int)parent_tid;
    zT_623 = pointer_only[zT_622];
    if ((unsigned char)(zT_623 != (unsigned char)(0))) goto z_bb_138; else goto z_bb_139;
    z_bb_136:
    goto z_bb_133;
    z_bb_137:
    goto z_bb_134;
    z_bb_138:
    zT_626 = 0;
    zT_627 = (unsigned int)parent_tid;
    pointer_only[zT_627] = zT_626;
    zT_628 = (unsigned int)wl_tail;
    worklist[zT_628] = parent_tid;
    zT_630 = wl_tail + (unsigned int)(1);
    wl_tail = zT_630;
    goto z_bb_139;
    z_bb_139:
    zT_631 = (unsigned int)e;
    zT_632 = wp_next[zT_631];
    e = zT_632;
    goto z_bb_137;
    z_bb_140:
    if ((unsigned char)(ti < tl)) goto z_bb_141; else goto z_bb_142;
    z_bb_141:
    zT_651 = self->registry;
    zT_652 = zT_651->types_items;
    zT_653 = zT_652[ti];
    ty = zT_653;
    zT_654 = pointer_only[ti];
    if ((unsigned char)(zT_654 != (unsigned char)(0))) goto z_bb_144; else goto z_bb_145;
    z_bb_142:
    zT_736 = self->registry;
    zT_737 = &sh_map;
    zT_738 = &po_map;
    zF_586B7FD5_classificationShare(zT_736, zT_737, zT_738);
    zT_743 = "CLS:c";
    zT_745 = 5;
    zT_744.ptr = zT_743;
    zT_744.len = zT_745;
    cls_m = zT_744;
    zT_746 = cls_m;
    zF_48AC7B3A_markerWrite(zT_746);
    zT_747 = plen;
    zF_C8A36147_markerU32(zT_747);
    zT_749 = "\n";
    zT_751 = 1;
    zT_750.ptr = zT_749;
    zT_750.len = zT_751;
    cls_nl = zT_750;
    zT_752 = cls_nl;
    zF_48AC7B3A_markerWrite(zT_752);
    zT_753 = 0;
    zT_754 = (unsigned int)zT_753;
    ti = zT_754;
    goto z_bb_178;
    z_bb_143:
    zT_733 = 1;
    zT_735 = ti + (unsigned int)((unsigned int)zT_733);
    ti = zT_735;
    goto z_bb_140;
    z_bb_144:
    zT_657 = &po_map;
    zF_26476265_u32ToU32MapPut(zT_657, (unsigned int)((unsigned int)ti), (unsigned int)(1));
    zT_664 = plen + (unsigned int)(1);
    plen = zT_664;
    goto z_bb_145;
    z_bb_145:
    zT_665 = ty;
    zT_666 = zF_F673DF45_classificationNeeds(zT_665);
    if (zT_666) goto z_bb_146; else goto z_bb_147;
    z_bb_146:
    zT_667 = &nd_map;
    zF_26476265_u32ToU32MapPut(zT_667, (unsigned int)((unsigned int)ti), (unsigned int)(1));
    goto z_bb_147;
    z_bb_147:
    zT_674 = 0;
    is_synthetic = zT_674;
    zT_675 = ty.name_id;
    if ((unsigned char)(zT_675 == (unsigned int)(0))) goto z_bb_148; else goto z_bb_149;
    z_bb_148:
    zT_678 = ty.kind;
    zT_680 = zF_EEDBE6D1_classificationIsSyn(zT_678);
    if (zT_680) goto z_bb_150; else goto z_bb_151;
    z_bb_149:
    zT_683 = 0;
    is_clsv = zT_683;
    zT_684 = pointer_only[ti];
    if ((unsigned char)(zT_684 == (unsigned char)(0))) goto z_bb_152; else goto z_bb_153;
    z_bb_150:
    zT_681 = 1;
    is_synthetic = zT_681;
    goto z_bb_151;
    z_bb_151:
    goto z_bb_149;
    z_bb_152:
    zT_687 = 1;
    is_clsv = zT_687;
    goto z_bb_153;
    z_bb_153:
    zT_689 = 0;
    is_carrier64 = zT_689;
    zT_690 = ty.kind;
    if ((unsigned char)(zT_690 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_155; else goto z_bb_154;
    z_bb_154:
    zT_695 = ty.kind;
    zT_694 = zT_695 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_156;
    z_bb_155:
    zT_694 = 1;
    goto z_bb_156;
    z_bb_156:
    if (zT_694) goto z_bb_158; else goto z_bb_157;
    z_bb_157:
    zT_700 = ty.kind;
    zT_699 = zT_700 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_159;
    z_bb_158:
    zT_699 = 1;
    goto z_bb_159;
    z_bb_159:
    if (zT_699) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_704 = 1;
    is_carrier64 = zT_704;
    goto z_bb_161;
    z_bb_161:
    zT_706 = 0;
    is_fn_named = zT_706;
    zT_707 = ty.kind;
    if ((unsigned char)(zT_707 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    zT_712 = ty.name_id;
    zT_711 = zT_712 != (unsigned int)(0);
    goto z_bb_164;
    z_bb_163:
    zT_711 = 0;
    goto z_bb_164;
    z_bb_164:
    if (zT_711) goto z_bb_165; else goto z_bb_166;
    z_bb_165:
    zT_715 = 1;
    is_fn_named = zT_715;
    goto z_bb_166;
    z_bb_166:
    if ((unsigned char)(is_synthetic != (unsigned char)(0))) goto z_bb_168; else goto z_bb_167;
    z_bb_167:
    zT_718 = is_clsv != (unsigned char)(0);
    goto z_bb_169;
    z_bb_168:
    zT_718 = 1;
    goto z_bb_169;
    z_bb_169:
    if (zT_718) goto z_bb_171; else goto z_bb_170;
    z_bb_170:
    zT_721 = is_carrier64 != (unsigned char)(0);
    goto z_bb_172;
    z_bb_171:
    zT_721 = 1;
    goto z_bb_172;
    z_bb_172:
    if (zT_721) goto z_bb_174; else goto z_bb_173;
    z_bb_173:
    zT_724 = is_fn_named != (unsigned char)(0);
    goto z_bb_175;
    z_bb_174:
    zT_724 = 1;
    goto z_bb_175;
    z_bb_175:
    if (zT_724) goto z_bb_176; else goto z_bb_177;
    z_bb_176:
    zT_727 = &sh_map;
    zF_26476265_u32ToU32MapPut(zT_727, (unsigned int)((unsigned int)ti), (unsigned int)(1));
    goto z_bb_177;
    z_bb_177:
    goto z_bb_143;
    z_bb_178:
    if ((unsigned char)(ti < tl)) goto z_bb_179; else goto z_bb_180;
    z_bb_179:
    zT_756 = pointer_only[ti];
    if ((unsigned char)(zT_756 != (unsigned char)(0))) goto z_bb_182; else goto z_bb_184;
    z_bb_180:
    classif->pointer_only_map = po_map;
    classif->needs_def_map = nd_map;
    classif->shared_set = sh_map;
    return;
    z_bb_181:
    zT_787 = 1;
    zT_789 = ti + (unsigned int)((unsigned int)zT_787);
    ti = zT_789;
    goto z_bb_178;
    z_bb_182:
    zT_760 = "CLS:p";
    zT_762 = 5;
    zT_761.ptr = zT_760;
    zT_761.len = zT_762;
    pfx = zT_761;
    zT_763 = pfx;
    zF_48AC7B3A_markerWrite(zT_763);
    goto z_bb_183;
    z_bb_183:
    zF_C8A36147_markerU32((unsigned int)((unsigned int)ti));
    zT_772 = "k";
    zT_774 = 1;
    zT_773.ptr = zT_772;
    zT_773.len = zT_774;
    ck = zT_773;
    zT_775 = ck;
    zF_48AC7B3A_markerWrite(zT_775);
    zT_777 = self->registry;
    zT_778 = zT_777->types_items;
    zT_779 = zT_778[ti];
    zT_780 = zT_779.kind;
    zF_C8A36147_markerU32((unsigned int)((unsigned int)zT_780));
    zT_783 = "\n";
    zT_785 = 1;
    zT_784.ptr = zT_783;
    zT_784.len = zT_785;
    cnl = zT_784;
    zT_786 = cnl;
    zF_48AC7B3A_markerWrite(zT_786);
    goto z_bb_181;
    z_bb_184:
    zT_765 = "CLS:v";
    zT_767 = 5;
    zT_766.ptr = zT_765;
    zT_766.len = zT_767;
    pfx = zT_766;
    zT_768 = pfx;
    zF_48AC7B3A_markerWrite(zT_768);
    goto z_bb_183;
}

/* classificationIsSyntheticEmittable */
unsigned char zF_EEDBE6D1_classificationIsSyn(zT_33EF6BFB_TypeKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    unsigned char zT_28;
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_20) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_24 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type);
    goto z_bb_18;
    z_bb_17:
    zT_24 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_24) goto z_bb_20; else goto z_bb_19;
    z_bb_19:
    zT_28 = kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type);
    goto z_bb_21;
    z_bb_20:
    zT_28 = 1;
    goto z_bb_21;
    z_bb_21:
    return zT_28;
}

/* classificationNeedsDef */
unsigned char zF_F673DF45_classificationNeeds(zT_D155D06D_Type ty) {
    zT_33EF6BFB_TypeKind zT_1;
    zT_33EF6BFB_TypeKind zT_6;
    zT_33EF6BFB_TypeKind zT_11;
    zT_33EF6BFB_TypeKind zT_16;
    zT_33EF6BFB_TypeKind zT_21;
    zT_33EF6BFB_TypeKind zT_26;
    zT_33EF6BFB_TypeKind zT_31;
    zT_33EF6BFB_TypeKind zT_36;
    unsigned int zT_41;
    zT_33EF6BFB_TypeKind zT_44;
    unsigned char zT_46 = 0;
    zT_1 = ty.kind;
    if ((unsigned char)(zT_1 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_void_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_6 = ty.kind;
    if ((unsigned char)(zT_6 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_11 = ty.kind;
    if ((unsigned char)(zT_11 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_noreturn_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_16 = ty.kind;
    if ((unsigned char)(zT_16 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_null_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_21 = ty.kind;
    if ((unsigned char)(zT_21 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_undefined_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    zT_26 = ty.kind;
    if ((unsigned char)(zT_26 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_integer_literal_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    zT_31 = ty.kind;
    if ((unsigned char)(zT_31 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    zT_36 = ty.kind;
    if ((unsigned char)(zT_36 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    zT_41 = ty.name_id;
    if ((unsigned char)(zT_41 == (unsigned int)(0))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_44 = ty.kind;
    zT_46 = zF_EEDBE6D1_classificationIsSyn(zT_44);
    if ((unsigned char)(!zT_46)) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    return (unsigned char)(1);
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    goto z_bb_18;
}

/* classificationSharedClosure */
void zF_586B7FD5_classificationShare(zT_338B7C76_TypeRegistry* reg, zT_21D3708C_U32ToU32Map* shared, zT_21D3708C_U32ToU32Map* po) {
    unsigned int zT_4;
    unsigned int zT_7;
    unsigned int zT_9;
    unsigned int zT_11;
    zT_D155D06D_Type* zT_14;
    unsigned int zT_15;
    zT_D155D06D_Type zT_16;
    unsigned int zT_17;
    zT_21D3708C_U32ToU32Map* zT_20;
    unsigned int zT_21;
    zT_BAEE192E_Opt_10 zT_22 = {0};
    unsigned char zT_23;
    zT_33EF6BFB_TypeKind zT_24;
    unsigned char zT_28;
    zT_33EF6BFB_TypeKind zT_29;
    unsigned char zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned char zT_38;
    zT_33EF6BFB_TypeKind zT_39;
    unsigned char zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    unsigned char zT_48;
    zT_33EF6BFB_TypeKind zT_49;
    zT_21D3708C_U32ToU32Map* zT_53;
    unsigned int zT_54;
    zT_BAEE192E_Opt_10 zT_55 = {0};
    unsigned char zT_56;
    unsigned int zT_59;
    unsigned int zT_61;
    zT_21D3708C_U32ToU32Map* zT_63;
    unsigned int zT_64;
    zT_BAEE192E_Opt_10 zT_65 = {0};
    unsigned char zT_66;
    zT_338B7C76_TypeRegistry* zT_68;
    unsigned int zT_69;
    unsigned int zT_70;
    unsigned char zT_71 = 0;
    zT_21D3708C_U32ToU32Map* zT_72;
    unsigned int zT_73;
    unsigned int zT_76;
    int zT_77;
    unsigned int zT_79;
    int zT_80;
    unsigned int zT_82;
    unsigned int changed;
    unsigned int ti2;
    zT_D155D06D_Type ty2;
    unsigned int sj;
    zT_4 = 1;
    changed = zT_4;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(changed != (unsigned int)(0))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_7 = 0;
    changed = zT_7;
    zT_9 = 0;
    ti2 = zT_9;
    goto z_bb_5;
    z_bb_3:
    return;
    z_bb_4:
    goto z_bb_1;
    z_bb_5:
    zT_11 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ti2) < zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    zT_14 = reg->types_items;
    zT_15 = (unsigned int)ti2;
    zT_16 = zT_14[zT_15];
    ty2 = zT_16;
    zT_17 = ty2.name_id;
    if ((unsigned char)(zT_17 == (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    goto z_bb_4;
    z_bb_8:
    zT_80 = 1;
    zT_82 = ti2 + (unsigned int)((unsigned int)zT_80);
    ti2 = zT_82;
    goto z_bb_5;
    z_bb_9:
    goto z_bb_8;
    z_bb_10:
    zT_20 = shared;
    zT_21 = ti2;
    zT_22 = zF_F3EE5998_u32ToU32MapGet(zT_20, zT_21);
    zT_23 = zT_22.has_value;
    if (zT_23) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    goto z_bb_8;
    z_bb_12:
    zT_24 = ty2.kind;
    if ((unsigned char)(zT_24 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_29 = ty2.kind;
    zT_28 = zT_29 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_28 = 0;
    goto z_bb_15;
    z_bb_15:
    if (zT_28) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    zT_34 = ty2.kind;
    zT_33 = zT_34 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type);
    goto z_bb_18;
    z_bb_17:
    zT_33 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_33) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_39 = ty2.kind;
    zT_38 = zT_39 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_21;
    z_bb_20:
    zT_38 = 0;
    goto z_bb_21;
    z_bb_21:
    if (zT_38) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    zT_44 = ty2.kind;
    zT_43 = zT_44 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type);
    goto z_bb_24;
    z_bb_23:
    zT_43 = 0;
    goto z_bb_24;
    z_bb_24:
    if (zT_43) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_49 = ty2.kind;
    zT_48 = zT_49 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_set_type);
    goto z_bb_27;
    z_bb_26:
    zT_48 = 0;
    goto z_bb_27;
    z_bb_27:
    if (zT_48) goto z_bb_28; else goto z_bb_29;
    z_bb_28:
    goto z_bb_8;
    z_bb_29:
    zT_53 = po;
    zT_54 = ti2;
    zT_55 = zF_F3EE5998_u32ToU32MapGet(zT_53, zT_54);
    zT_56 = zT_55.has_value;
    if ((unsigned char)(!zT_56)) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    goto z_bb_8;
    z_bb_31:
    zT_59 = 0;
    sj = zT_59;
    goto z_bb_32;
    z_bb_32:
    zT_61 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)sj) < zT_61)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_63 = shared;
    zT_64 = sj;
    zT_65 = zF_F3EE5998_u32ToU32MapGet(zT_63, zT_64);
    zT_66 = zT_65.has_value;
    if ((unsigned char)(!zT_66)) goto z_bb_36; else goto z_bb_37;
    z_bb_34:
    goto z_bb_8;
    z_bb_35:
    zT_77 = 1;
    zT_79 = sj + (unsigned int)((unsigned int)zT_77);
    sj = zT_79;
    goto z_bb_32;
    z_bb_36:
    goto z_bb_35;
    z_bb_37:
    zT_68 = reg;
    zT_69 = sj;
    zT_70 = ti2;
    zT_71 = zF_8A421992_typeRefsContains(zT_68, zT_69, zT_70);
    if (zT_71) goto z_bb_38; else goto z_bb_39;
    z_bb_38:
    zT_72 = shared;
    zT_73 = ti2;
    zF_26476265_u32ToU32MapPut(zT_72, zT_73, (unsigned int)(1));
    zT_76 = 1;
    changed = zT_76;
    goto z_bb_34;
    z_bb_39:
    goto z_bb_35;
}

/* collectNeededTuples */
void zF_7845A68F_collectNeededTuples(zT_338B7C76_TypeRegistry* reg, zT_21D3708C_U32ToU32Map* set, unsigned int tid) {
    unsigned int zT_4;
    zT_D155D06D_Type* zT_7;
    unsigned int zT_8;
    zT_D155D06D_Type zT_9;
    zT_33EF6BFB_TypeKind zT_10;
    zT_21D3708C_U32ToU32Map* zT_14;
    unsigned int zT_15;
    zT_BAEE192E_Opt_10 zT_16 = {0};
    unsigned char zT_17;
    zT_21D3708C_U32ToU32Map* zT_18;
    unsigned int zT_19;
    zT_666DC2E1_TuplePayload* zT_23;
    unsigned int zT_24;
    unsigned int zT_25;
    zT_666DC2E1_TuplePayload zT_26;
    unsigned int zT_28;
    unsigned short zT_29;
    unsigned int* zT_33;
    unsigned int zT_34;
    unsigned int zT_36;
    unsigned int zT_37;
    unsigned int zT_39;
    zT_D155D06D_Type* zT_41;
    unsigned int zT_42;
    zT_D155D06D_Type zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_338B7C76_TypeRegistry* zT_48;
    zT_21D3708C_U32ToU32Map* zT_49;
    unsigned int zT_50;
    int zT_51;
    unsigned int zT_53;
    zT_D155D06D_Type ty;
    zT_666DC2E1_TuplePayload tup;
    unsigned int i;
    unsigned int et;
    zT_4 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_4)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_7 = reg->types_items;
    zT_8 = (unsigned int)tid;
    zT_9 = zT_7[zT_8];
    ty = zT_9;
    zT_10 = ty.kind;
    if ((unsigned char)(zT_10 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_14 = set;
    zT_15 = tid;
    zT_16 = zF_F3EE5998_u32ToU32MapGet(zT_14, zT_15);
    zT_17 = zT_16.has_value;
    if (zT_17) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return;
    z_bb_6:
    zT_18 = set;
    zT_19 = tid;
    zF_26476265_u32ToU32MapPut(zT_18, zT_19, (unsigned int)(1));
    zT_23 = reg->tup_items;
    zT_24 = ty.payload_idx;
    zT_25 = (unsigned int)zT_24;
    zT_26 = zT_23[zT_25];
    tup = zT_26;
    zT_28 = 0;
    i = zT_28;
    goto z_bb_7;
    z_bb_7:
    zT_29 = tup.elems_count;
    if ((unsigned char)(i < (unsigned int)((unsigned int)zT_29))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = reg->xt_items;
    zT_34 = tup.elems_start;
    zT_36 = (unsigned int)((unsigned int)zT_34) + i;
    zT_37 = zT_33[zT_36];
    et = zT_37;
    zT_39 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)et) < zT_39)) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    return;
    z_bb_10:
    zT_51 = 1;
    zT_53 = i + (unsigned int)((unsigned int)zT_51);
    i = zT_53;
    goto z_bb_7;
    z_bb_11:
    zT_41 = reg->types_items;
    zT_42 = (unsigned int)et;
    zT_43 = zT_41[zT_42];
    zT_44 = zT_43.kind;
    if ((unsigned char)(zT_44 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_48 = reg;
    zT_49 = set;
    zT_50 = et;
    zF_7845A68F_collectNeededTuples(zT_48, zT_49, zT_50);
    goto z_bb_14;
    z_bb_14:
    goto z_bb_12;
}

/* classifyTypeEmissionFinalize */
void zF_0DE160E2_classifyTypeEmissio(zT_338B7C76_TypeRegistry* reg, zT_786E6CF2_EmissionClassificat* classif) {
    zT_21D3708C_U32ToU32Map* zT_3;
    zT_21D3708C_U32ToU32Map* zT_5;
    zT_21D3708C_U32ToU32Map* zT_7;
    zT_21D3708C_U32ToU32Map* zT_9;
    unsigned int zT_11;
    unsigned int zT_13;
    zT_D155D06D_Type* zT_16;
    unsigned int zT_17;
    zT_D155D06D_Type zT_18;
    zT_D155D06D_Type zT_19;
    unsigned char zT_20 = 0;
    zT_21D3708C_U32ToU32Map* zT_21;
    unsigned int zT_22;
    unsigned char zT_26;
    unsigned int zT_27;
    zT_33EF6BFB_TypeKind zT_30;
    unsigned char zT_32 = 0;
    unsigned char zT_33;
    zT_33EF6BFB_TypeKind zT_34;
    unsigned char zT_38;
    zT_21D3708C_U32ToU32Map* zT_39;
    unsigned int zT_40;
    zT_BAEE192E_Opt_10 zT_41 = {0};
    unsigned char zT_42;
    unsigned char zT_43;
    unsigned char zT_45;
    zT_21D3708C_U32ToU32Map* zT_46;
    unsigned int zT_47;
    zT_BAEE192E_Opt_10 zT_48 = {0};
    unsigned char zT_49;
    unsigned char zT_51;
    unsigned char zT_53;
    zT_33EF6BFB_TypeKind zT_54;
    unsigned char zT_58;
    zT_33EF6BFB_TypeKind zT_59;
    unsigned char zT_63;
    zT_33EF6BFB_TypeKind zT_64;
    unsigned char zT_68;
    unsigned char zT_70;
    zT_33EF6BFB_TypeKind zT_71;
    unsigned char zT_75;
    unsigned int zT_76;
    unsigned char zT_79;
    unsigned char zT_82;
    unsigned char zT_85;
    unsigned char zT_88;
    zT_21D3708C_U32ToU32Map* zT_91;
    unsigned int zT_92;
    int zT_95;
    unsigned int zT_97;
    zT_338B7C76_TypeRegistry* zT_98;
    zT_21D3708C_U32ToU32Map* zT_99;
    zT_21D3708C_U32ToU32Map* zT_100;
    zT_21D3708C_U32ToU32Map* shared;
    zT_21D3708C_U32ToU32Map* po;
    zT_21D3708C_U32ToU32Map* nd;
    zT_21D3708C_U32ToU32Map* needed;
    unsigned int ti;
    zT_D155D06D_Type ty;
    unsigned char is_synthetic;
    unsigned char is_clsv;
    unsigned char is_carrier64;
    unsigned char is_fn_named;
    zT_3 = &classif->shared_set;
    shared = zT_3;
    zT_5 = &classif->pointer_only_map;
    po = zT_5;
    zT_7 = &classif->needs_def_map;
    nd = zT_7;
    zT_9 = &classif->needed_tuple_set;
    needed = zT_9;
    zT_11 = 0;
    ti = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_13 = reg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)ti) < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = reg->types_items;
    zT_17 = (unsigned int)ti;
    zT_18 = zT_16[zT_17];
    ty = zT_18;
    zT_19 = ty;
    zT_20 = zF_F673DF45_classificationNeeds(zT_19);
    if (zT_20) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_98 = reg;
    zT_99 = shared;
    zT_100 = po;
    zF_586B7FD5_classificationShare(zT_98, zT_99, zT_100);
    return;
    z_bb_4:
    zT_95 = 1;
    zT_97 = ti + (unsigned int)((unsigned int)zT_95);
    ti = zT_97;
    goto z_bb_1;
    z_bb_5:
    zT_21 = nd;
    zT_22 = ti;
    zF_26476265_u32ToU32MapPut(zT_21, zT_22, (unsigned int)(1));
    goto z_bb_6;
    z_bb_6:
    zT_26 = 0;
    is_synthetic = zT_26;
    zT_27 = ty.name_id;
    if ((unsigned char)(zT_27 == (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_30 = ty.kind;
    zT_32 = zF_EEDBE6D1_classificationIsSyn(zT_30);
    if (zT_32) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    zT_45 = 0;
    is_clsv = zT_45;
    zT_46 = po;
    zT_47 = ti;
    zT_48 = zF_F3EE5998_u32ToU32MapGet(zT_46, zT_47);
    zT_49 = zT_48.has_value;
    if ((unsigned char)(!zT_49)) goto z_bb_16; else goto z_bb_17;
    z_bb_9:
    zT_33 = 1;
    is_synthetic = zT_33;
    goto z_bb_10;
    z_bb_10:
    zT_34 = ty.kind;
    if ((unsigned char)(zT_34 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_39 = needed;
    zT_40 = ti;
    zT_41 = zF_F3EE5998_u32ToU32MapGet(zT_39, zT_40);
    zT_42 = zT_41.has_value;
    zT_38 = zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_38) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_43 = 1;
    is_synthetic = zT_43;
    goto z_bb_15;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_51 = 1;
    is_clsv = zT_51;
    goto z_bb_17;
    z_bb_17:
    zT_53 = 0;
    is_carrier64 = zT_53;
    zT_54 = ty.kind;
    if ((unsigned char)(zT_54 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_i64_type))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_59 = ty.kind;
    zT_58 = zT_59 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_u64_type);
    goto z_bb_20;
    z_bb_19:
    zT_58 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_58) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_64 = ty.kind;
    zT_63 = zT_64 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_f64_type);
    goto z_bb_23;
    z_bb_22:
    zT_63 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_63) goto z_bb_24; else goto z_bb_25;
    z_bb_24:
    zT_68 = 1;
    is_carrier64 = zT_68;
    goto z_bb_25;
    z_bb_25:
    zT_70 = 0;
    is_fn_named = zT_70;
    zT_71 = ty.kind;
    if ((unsigned char)(zT_71 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_76 = ty.name_id;
    zT_75 = zT_76 != (unsigned int)(0);
    goto z_bb_28;
    z_bb_27:
    zT_75 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_75) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_79 = 1;
    is_fn_named = zT_79;
    goto z_bb_30;
    z_bb_30:
    if ((unsigned char)(is_synthetic != (unsigned char)(0))) goto z_bb_32; else goto z_bb_31;
    z_bb_31:
    zT_82 = is_clsv != (unsigned char)(0);
    goto z_bb_33;
    z_bb_32:
    zT_82 = 1;
    goto z_bb_33;
    z_bb_33:
    if (zT_82) goto z_bb_35; else goto z_bb_34;
    z_bb_34:
    zT_85 = is_carrier64 != (unsigned char)(0);
    goto z_bb_36;
    z_bb_35:
    zT_85 = 1;
    goto z_bb_36;
    z_bb_36:
    if (zT_85) goto z_bb_38; else goto z_bb_37;
    z_bb_37:
    zT_88 = is_fn_named != (unsigned char)(0);
    goto z_bb_39;
    z_bb_38:
    zT_88 = 1;
    goto z_bb_39;
    z_bb_39:
    if (zT_88) goto z_bb_40; else goto z_bb_41;
    z_bb_40:
    zT_91 = shared;
    zT_92 = ti;
    zF_26476265_u32ToU32MapPut(zT_91, zT_92, (unsigned int)(1));
    goto z_bb_41;
    z_bb_41:
    goto z_bb_4;
}

/* growWpEdges */
void zF_25C377BD_growWpEdges(zT_3E40CD83_Sand* perm_a, unsigned int** wp_to_ptr, unsigned int** wp_next_ptr, unsigned int* cap_ptr, unsigned int count) {
    unsigned int zT_6;
    zT_3E40CD83_Sand* zT_8;
    unsigned int** zT_9;
    unsigned int** zT_10;
    unsigned int* zT_12;
    zT_6 = *cap_ptr;
    if ((unsigned char)((unsigned int)((unsigned int)count) < zT_6)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_8 = perm_a;
    zT_9 = wp_to_ptr;
    zT_10 = wp_next_ptr;
    zT_12 = cap_ptr;
    zF_F638C869_nameScopeGrowPair(zT_8, zT_9, zT_10, (unsigned int)((unsigned int)count), zT_12, (unsigned int)(0));
    return;
}

/* evalConstModuleOfExpr */
unsigned int zF_0E4084E4_evalConstModuleOfEx(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    zT_6B0A7D14_AstStore* zT_15;
    unsigned int zT_16;
    unsigned int zT_18 = 0;
    unsigned int zT_19;
    zT_3D7259E2_SymbolRegistry* zT_22;
    unsigned int zT_23;
    unsigned int zT_24;
    zT_6BEBA1C2_Opt_900 zT_27 = {0};
    unsigned char zT_28;
    zT_3C598AEF_SymbolKind zT_30;
    unsigned int zT_34;
    unsigned int zT_35;
    unsigned char zT_38;
    unsigned int zT_39;
    zT_338B7C76_TypeRegistry* zT_41;
    unsigned int zT_42;
    zT_338B7C76_TypeRegistry* zT_45;
    zT_D155D06D_Type* zT_46;
    unsigned int zT_47;
    unsigned int zT_48;
    zT_D155D06D_Type zT_49;
    zT_33EF6BFB_TypeKind zT_50;
    unsigned short zT_54;
    int zT_57;
    unsigned int zT_58;
    zT_3D7259E2_SymbolRegistry* zT_59;
    unsigned int zT_60;
    zT_3D7259E2_SymbolRegistry* zT_64;
    unsigned int zT_66;
    zT_6BEBA1C2_Opt_900 zT_69 = {0};
    unsigned char zT_70;
    zT_3C598AEF_SymbolKind zT_72;
    unsigned int zT_76;
    unsigned int zT_77;
    unsigned char zT_80;
    unsigned int zT_81;
    zT_338B7C76_TypeRegistry* zT_83;
    unsigned int zT_84;
    zT_338B7C76_TypeRegistry* zT_87;
    zT_D155D06D_Type* zT_88;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_D155D06D_Type zT_91;
    zT_33EF6BFB_TypeKind zT_92;
    unsigned short zT_96;
    int zT_98;
    unsigned int zT_100;
    zT_8143F551_AstKind zT_102;
    zT_ABC1EBBE_TypeResolveEnv* zT_107;
    unsigned int zT_108;
    unsigned int zT_110 = 0;
    zT_6B0A7D14_AstStore* zT_115;
    unsigned int zT_116;
    unsigned int zT_118 = 0;
    zT_3D7259E2_SymbolRegistry* zT_119;
    unsigned int zT_120;
    unsigned int zT_121;
    zT_6BEBA1C2_Opt_900 zT_123 = {0};
    unsigned char zT_124;
    zT_3C598AEF_SymbolKind zT_126;
    unsigned int zT_130;
    unsigned int zT_131;
    unsigned char zT_134;
    unsigned int zT_135;
    zT_338B7C76_TypeRegistry* zT_137;
    unsigned int zT_138;
    zT_338B7C76_TypeRegistry* zT_141;
    zT_D155D06D_Type* zT_142;
    unsigned int zT_143;
    unsigned int zT_144;
    zT_D155D06D_Type zT_145;
    zT_33EF6BFB_TypeKind zT_146;
    unsigned short zT_150;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    unsigned int si;
    zT_3A105EF1_Symbol* s;
    zT_D155D06D_Type sty;
    zT_6BEBA1C2_Opt_900 sym;
    zT_3A105EF1_Symbol* s2;
    zT_D155D06D_Type sty2;
    unsigned int base_mod;
    unsigned int field_name_id;
    zT_3A105EF1_Symbol* msym;
    zT_D155D06D_Type mty;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(0);
    z_bb_2:
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    node = zT_9;
    zT_10 = node.kind;
    if ((unsigned char)(zT_10 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_15 = env->store;
    zT_16 = node_idx;
    zT_18 = zF_53458827_astStoreIdentifier(zT_15, zT_16);
    name_id = zT_18;
    zT_19 = env->module_id;
    if ((unsigned char)(zT_19 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_102 = node.kind;
    if ((unsigned char)(zT_102 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_33; else goto z_bb_34;
    z_bb_5:
    zT_22 = env->symbol_reg;
    zT_23 = env->module_id;
    zT_24 = name_id;
    zT_27 = zF_A398987E_symbolRegistryQuali(zT_22, zT_23, zT_24);
    zT_28 = zT_27.has_value;
    if (zT_28) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_57 = 0;
    zT_58 = (unsigned int)zT_57;
    si = zT_58;
    goto z_bb_18;
    z_bb_7:
    s = zT_27.value;
    zT_30 = s->kind;
    if ((unsigned char)(zT_30 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_34 = s->module_id;
    return zT_34;
    z_bb_10:
    zT_35 = s->type_id;
    if ((unsigned char)(zT_35 != (unsigned int)(0))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    zT_39 = s->type_id;
    zT_41 = env->typereg;
    zT_42 = zT_41->types_len;
    zT_38 = (unsigned int)((unsigned int)zT_39) < zT_42;
    goto z_bb_13;
    z_bb_12:
    zT_38 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_38) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_45 = env->typereg;
    zT_46 = zT_45->types_items;
    zT_47 = s->type_id;
    zT_48 = (unsigned int)zT_47;
    zT_49 = zT_46[zT_48];
    sty = zT_49;
    zT_50 = sty.kind;
    if ((unsigned char)(zT_50 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_8;
    z_bb_16:
    zT_54 = sty.module_id;
    return (unsigned int)((unsigned int)zT_54);
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_59 = env->symbol_reg;
    zT_60 = zT_59->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_60))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_64 = env->symbol_reg;
    zT_66 = name_id;
    zT_69 = zF_A398987E_symbolRegistryQuali(zT_64, (unsigned int)((unsigned int)si), zT_66);
    sym = zT_69;
    zT_70 = sym.has_value;
    if (zT_70) goto z_bb_22; else goto z_bb_23;
    z_bb_20:
    return (unsigned int)(0);
    z_bb_21:
    zT_98 = 1;
    zT_100 = si + (unsigned int)((unsigned int)zT_98);
    si = zT_100;
    goto z_bb_18;
    z_bb_22:
    s2 = sym.value;
    zT_72 = s2->kind;
    if ((unsigned char)(zT_72 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_24; else goto z_bb_25;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    zT_76 = s2->module_id;
    return zT_76;
    z_bb_25:
    zT_77 = s2->type_id;
    if ((unsigned char)(zT_77 != (unsigned int)(0))) goto z_bb_26; else goto z_bb_27;
    z_bb_26:
    zT_81 = s2->type_id;
    zT_83 = env->typereg;
    zT_84 = zT_83->types_len;
    zT_80 = (unsigned int)((unsigned int)zT_81) < zT_84;
    goto z_bb_28;
    z_bb_27:
    zT_80 = 0;
    goto z_bb_28;
    z_bb_28:
    if (zT_80) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_87 = env->typereg;
    zT_88 = zT_87->types_items;
    zT_89 = s2->type_id;
    zT_90 = (unsigned int)zT_89;
    zT_91 = zT_88[zT_90];
    sty2 = zT_91;
    zT_92 = sty2.kind;
    if ((unsigned char)(zT_92 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_30:
    goto z_bb_23;
    z_bb_31:
    zT_96 = sty2.module_id;
    return (unsigned int)((unsigned int)zT_96);
    z_bb_32:
    goto z_bb_30;
    z_bb_33:
    zT_107 = env;
    zT_108 = node.child_0;
    zT_110 = zF_0E4084E4_evalConstModuleOfEx(zT_107, zT_108);
    base_mod = zT_110;
    if ((unsigned char)(base_mod == (unsigned int)(0))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    return (unsigned int)(0);
    z_bb_35:
    return (unsigned int)(0);
    z_bb_36:
    zT_115 = env->store;
    zT_116 = node_idx;
    zT_118 = zF_8BA26B9E_astStoreNodePayload(zT_115, zT_116);
    field_name_id = zT_118;
    zT_119 = env->symbol_reg;
    zT_120 = base_mod;
    zT_121 = field_name_id;
    zT_123 = zF_A398987E_symbolRegistryQuali(zT_119, zT_120, zT_121);
    zT_124 = zT_123.has_value;
    if (zT_124) goto z_bb_37; else goto z_bb_38;
    z_bb_37:
    msym = zT_123.value;
    zT_126 = msym->kind;
    if ((unsigned char)(zT_126 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    return (unsigned int)(0);
    z_bb_39:
    zT_130 = msym->module_id;
    return zT_130;
    z_bb_40:
    zT_131 = msym->type_id;
    if ((unsigned char)(zT_131 != (unsigned int)(0))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_135 = msym->type_id;
    zT_137 = env->typereg;
    zT_138 = zT_137->types_len;
    zT_134 = (unsigned int)((unsigned int)zT_135) < zT_138;
    goto z_bb_43;
    z_bb_42:
    zT_134 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_134) goto z_bb_44; else goto z_bb_45;
    z_bb_44:
    zT_141 = env->typereg;
    zT_142 = zT_141->types_items;
    zT_143 = msym->type_id;
    zT_144 = (unsigned int)zT_143;
    zT_145 = zT_142[zT_144];
    mty = zT_145;
    zT_146 = mty.kind;
    if ((unsigned char)(zT_146 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    goto z_bb_38;
    z_bb_46:
    zT_150 = mty.module_id;
    return (unsigned int)((unsigned int)zT_150);
    z_bb_47:
    goto z_bb_45;
}

/* evalConstScalarKind */
unsigned char zF_6AE4DFFC_evalConstScalarKind(zT_33EF6BFB_TypeKind kind) {
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_slice_type))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_optional_type))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    return (unsigned char)(0);
    z_bb_16:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_error_union_type))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    return (unsigned char)(0);
    z_bb_18:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_fn_type))) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    return (unsigned char)(0);
    z_bb_20:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    return (unsigned char)(0);
    z_bb_22:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_type_type))) goto z_bb_23; else goto z_bb_24;
    z_bb_23:
    return (unsigned char)(0);
    z_bb_24:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_unresolved_name))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    return (unsigned char)(0);
    z_bb_26:
    if ((unsigned char)(kind == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_none_sentinel))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    return (unsigned char)(0);
    z_bb_28:
    return (unsigned char)(1);
}

/* evalConstIntFull */
zT_E23A20E9_Opt_206 zF_382591DE_evalConstIntFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_E23A20E9_Opt_206 zT_5 = {0};
    zT_E23A20E9_Opt_206 zT_8 = {0};
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned char zT_18;
    zT_8143F551_AstKind zT_19;
    zT_79FAE712_u64 zT_23;
    zT_6B0A7D14_AstStore* zT_24;
    unsigned int zT_25;
    zT_79FAE712_u64 zT_27 = 0;
    zT_0163D9A4_ComptimeInt zT_28 = {0};
    zT_E23A20E9_Opt_206 zT_29;
    zT_8143F551_AstKind zT_30;
    unsigned int zT_34;
    zT_ABC1EBBE_TypeResolveEnv* zT_38;
    unsigned int zT_39;
    zT_E23A20E9_Opt_206 zT_44 = {0};
    unsigned char zT_45;
    zT_0163D9A4_ComptimeInt zT_48 = {0};
    zT_0163D9A4_ComptimeInt zT_49;
    zT_0163D9A4_ComptimeInt* zT_50;
    unsigned char zT_52 = 0;
    zT_E23A20E9_Opt_206 zT_53;
    zT_E23A20E9_Opt_206 zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    zT_ABC1EBBE_TypeResolveEnv* zT_59;
    unsigned int zT_62;
    unsigned int zT_64;
    zT_8143F551_AstKind zT_66;
    unsigned char zT_70;
    zT_8143F551_AstKind zT_71;
    unsigned char zT_75;
    zT_8143F551_AstKind zT_76;
    unsigned char zT_80;
    zT_8143F551_AstKind zT_81;
    unsigned char zT_85;
    zT_8143F551_AstKind zT_86;
    unsigned char zT_90;
    zT_8143F551_AstKind zT_91;
    unsigned char zT_95;
    zT_8143F551_AstKind zT_96;
    unsigned char zT_100;
    zT_8143F551_AstKind zT_101;
    unsigned char zT_105;
    zT_8143F551_AstKind zT_106;
    unsigned char zT_110;
    zT_8143F551_AstKind zT_111;
    zT_ABC1EBBE_TypeResolveEnv* zT_116;
    unsigned int zT_117;
    zT_E23A20E9_Opt_206 zT_122 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_124;
    unsigned int zT_125;
    zT_E23A20E9_Opt_206 zT_130 = {0};
    unsigned char zT_131;
    unsigned char zT_133;
    zT_0163D9A4_ComptimeInt zT_136 = {0};
    zT_8143F551_AstKind zT_137;
    zT_0163D9A4_ComptimeInt zT_141;
    zT_0163D9A4_ComptimeInt zT_142;
    zT_0163D9A4_ComptimeInt* zT_143;
    unsigned char zT_145 = 0;
    zT_E23A20E9_Opt_206 zT_147 = {0};
    zT_E23A20E9_Opt_206 zT_148;
    zT_8143F551_AstKind zT_149;
    zT_0163D9A4_ComptimeInt zT_153;
    zT_0163D9A4_ComptimeInt zT_154;
    zT_0163D9A4_ComptimeInt* zT_155;
    unsigned char zT_157 = 0;
    zT_E23A20E9_Opt_206 zT_159 = {0};
    zT_E23A20E9_Opt_206 zT_160;
    zT_8143F551_AstKind zT_161;
    zT_0163D9A4_ComptimeInt zT_165;
    zT_0163D9A4_ComptimeInt zT_166;
    zT_0163D9A4_ComptimeInt* zT_167;
    unsigned char zT_169 = 0;
    zT_E23A20E9_Opt_206 zT_171 = {0};
    zT_E23A20E9_Opt_206 zT_172;
    zT_8143F551_AstKind zT_173;
    zT_0163D9A4_ComptimeInt zT_178 = {0};
    zT_0163D9A4_ComptimeInt zT_179;
    zT_0163D9A4_ComptimeInt zT_180;
    zT_0163D9A4_ComptimeInt* zT_181;
    zT_0163D9A4_ComptimeInt* zT_182;
    unsigned char zT_185 = 0;
    zT_E23A20E9_Opt_206 zT_187 = {0};
    zT_E23A20E9_Opt_206 zT_188;
    zT_8143F551_AstKind zT_189;
    zT_0163D9A4_ComptimeInt zT_194 = {0};
    zT_0163D9A4_ComptimeInt zT_195;
    zT_0163D9A4_ComptimeInt zT_196;
    zT_0163D9A4_ComptimeInt* zT_197;
    zT_0163D9A4_ComptimeInt* zT_198;
    unsigned char zT_201 = 0;
    zT_E23A20E9_Opt_206 zT_203 = {0};
    zT_E23A20E9_Opt_206 zT_204;
    zT_8143F551_AstKind zT_205;
    zT_0163D9A4_ComptimeInt zT_209;
    zT_0163D9A4_ComptimeInt zT_210;
    zT_0163D9A4_ComptimeInt* zT_211;
    unsigned char zT_213 = 0;
    zT_E23A20E9_Opt_206 zT_215 = {0};
    zT_E23A20E9_Opt_206 zT_216;
    zT_8143F551_AstKind zT_217;
    zT_0163D9A4_ComptimeInt zT_221;
    zT_0163D9A4_ComptimeInt zT_222;
    zT_0163D9A4_ComptimeInt* zT_223;
    unsigned char zT_225 = 0;
    zT_E23A20E9_Opt_206 zT_227 = {0};
    zT_E23A20E9_Opt_206 zT_228;
    zT_8143F551_AstKind zT_229;
    zT_0163D9A4_ComptimeInt zT_233;
    zT_0163D9A4_ComptimeInt zT_234;
    zT_0163D9A4_ComptimeInt* zT_235;
    unsigned char zT_237 = 0;
    zT_E23A20E9_Opt_206 zT_239 = {0};
    zT_E23A20E9_Opt_206 zT_240;
    zT_8143F551_AstKind zT_241;
    zT_0163D9A4_ComptimeInt zT_245;
    zT_0163D9A4_ComptimeInt zT_246;
    zT_0163D9A4_ComptimeInt* zT_247;
    unsigned char zT_249 = 0;
    zT_E23A20E9_Opt_206 zT_251 = {0};
    zT_E23A20E9_Opt_206 zT_252;
    zT_0163D9A4_ComptimeInt zT_253;
    zT_0163D9A4_ComptimeInt zT_254;
    zT_0163D9A4_ComptimeInt* zT_255;
    unsigned char zT_257 = 0;
    zT_E23A20E9_Opt_206 zT_259 = {0};
    zT_E23A20E9_Opt_206 zT_260;
    zT_E23A20E9_Opt_206 zT_261 = {0};
    zT_8143F551_AstKind zT_262;
    zT_6B0A7D14_AstStore* zT_267;
    unsigned int zT_268;
    unsigned int zT_270 = 0;
    zT_0DCE6231_Opt_408 zT_271;
    unsigned char zT_272;
    zT_E2DF2801_LocalConstScope* zT_274;
    unsigned int zT_275;
    zT_BAEE192E_Opt_10 zT_276 = {0};
    unsigned char zT_277;
    zT_6B0A7D14_AstStore* zT_280;
    unsigned int zT_281;
    zT_22A7C88B_AstNode zT_283 = {0};
    unsigned int zT_284;
    zT_ABC1EBBE_TypeResolveEnv* zT_287;
    unsigned int zT_290;
    unsigned int zT_292;
    zT_ABC1EBBE_TypeResolveEnv* zT_295;
    unsigned int zT_296;
    zT_6BEBA1C2_Opt_900 zT_297 = {0};
    unsigned char zT_298;
    unsigned short zT_300;
    zT_6B0A7D14_AstStore* zT_306;
    unsigned int zT_307;
    zT_22A7C88B_AstNode zT_310 = {0};
    unsigned int zT_311;
    zT_ABC1EBBE_TypeResolveEnv* zT_314;
    unsigned int zT_317;
    unsigned int zT_319;
    zT_E23A20E9_Opt_206 zT_321 = {0};
    zT_8143F551_AstKind zT_322;
    zT_ABC1EBBE_TypeResolveEnv* zT_327;
    unsigned int zT_328;
    unsigned int zT_330 = 0;
    zT_6B0A7D14_AstStore* zT_334;
    unsigned int zT_335;
    unsigned int zT_337 = 0;
    zT_3D7259E2_SymbolRegistry* zT_338;
    unsigned int zT_339;
    unsigned int zT_340;
    zT_6BEBA1C2_Opt_900 zT_342 = {0};
    unsigned char zT_343;
    zT_ABC1EBBE_TypeResolveEnv* zT_345;
    unsigned int zT_346;
    unsigned int zT_347;
    zT_3A105EF1_Symbol* zT_348;
    unsigned char zT_349 = 0;
    zT_E23A20E9_Opt_206 zT_351 = {0};
    unsigned short zT_352;
    zT_6B0A7D14_AstStore* zT_358;
    unsigned int zT_359;
    zT_22A7C88B_AstNode zT_362 = {0};
    unsigned int zT_363;
    zT_ABC1EBBE_TypeResolveEnv* zT_366;
    unsigned int zT_369;
    unsigned int zT_371;
    zT_E23A20E9_Opt_206 zT_373 = {0};
    zT_8143F551_AstKind zT_374;
    unsigned char* zT_379;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_380;
    unsigned int zT_381;
    zT_D3EB6303_StringInterner* zT_383;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_384;
    unsigned int zT_386 = 0;
    unsigned char* zT_388;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_389;
    unsigned int zT_390;
    zT_D3EB6303_StringInterner* zT_392;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_393;
    unsigned int zT_395 = 0;
    unsigned char* zT_397;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_398;
    unsigned int zT_399;
    zT_D3EB6303_StringInterner* zT_401;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_402;
    unsigned int zT_404 = 0;
    unsigned char* zT_406;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_407;
    unsigned int zT_408;
    zT_D3EB6303_StringInterner* zT_410;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_411;
    unsigned int zT_413 = 0;
    unsigned char* zT_415;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_416;
    unsigned int zT_417;
    zT_D3EB6303_StringInterner* zT_419;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_420;
    unsigned int zT_422 = 0;
    unsigned char* zT_424;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_425;
    unsigned int zT_426;
    zT_D3EB6303_StringInterner* zT_428;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_429;
    unsigned int zT_431 = 0;
    unsigned char* zT_433;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_434;
    unsigned int zT_435;
    zT_D3EB6303_StringInterner* zT_437;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_438;
    unsigned int zT_440 = 0;
    zT_6B0A7D14_AstStore* zT_442;
    unsigned int zT_443;
    unsigned int zT_445 = 0;
    unsigned int zT_446;
    unsigned char zT_448;
    unsigned int zT_449;
    zT_ABC1EBBE_TypeResolveEnv* zT_454;
    unsigned int zT_455;
    zT_6B0A7D14_AstStore* zT_457;
    unsigned int zT_458;
    unsigned int zT_462 = 0;
    unsigned int zT_465 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_469;
    unsigned int zT_470;
    zT_6B0A7D14_AstStore* zT_472;
    unsigned int zT_473;
    unsigned int zT_477 = 0;
    zT_E23A20E9_Opt_206 zT_480 = {0};
    unsigned char zT_481;
    zT_338B7C76_TypeRegistry* zT_483;
    zT_0163D9A4_ComptimeInt zT_484;
    unsigned int zT_485;
    unsigned char zT_487 = 0;
    zT_E23A20E9_Opt_206 zT_488;
    zT_E23A20E9_Opt_206 zT_489 = {0};
    unsigned int zT_490;
    unsigned char zT_492;
    unsigned int zT_493;
    unsigned char zT_495;
    unsigned int zT_496;
    zT_ABC1EBBE_TypeResolveEnv* zT_501;
    unsigned int zT_502;
    zT_6B0A7D14_AstStore* zT_504;
    unsigned int zT_505;
    unsigned int zT_509 = 0;
    unsigned int zT_512 = 0;
    zT_338B7C76_TypeRegistry* zT_516;
    zT_D155D06D_Type* zT_517;
    unsigned int zT_518;
    zT_D155D06D_Type zT_519;
    unsigned char zT_520;
    unsigned char zT_523;
    zT_33EF6BFB_TypeKind zT_524;
    zT_338B7C76_TypeRegistry* zT_528;
    unsigned int zT_529;
    unsigned char zT_533 = 0;
    zT_338B7C76_TypeRegistry* zT_534;
    zT_D155D06D_Type* zT_535;
    unsigned int zT_536;
    zT_D155D06D_Type zT_537;
    zT_33EF6BFB_TypeKind zT_539;
    unsigned char zT_541 = 0;
    zT_33EF6BFB_TypeKind zT_542;
    unsigned char zT_546;
    unsigned char zT_547;
    unsigned char zT_550;
    unsigned int zT_551;
    unsigned int zT_554;
    zT_0163D9A4_ComptimeInt zT_556 = {0};
    zT_E23A20E9_Opt_206 zT_557;
    unsigned int zT_558;
    unsigned short zT_561;
    zT_0163D9A4_ComptimeInt zT_563 = {0};
    zT_E23A20E9_Opt_206 zT_564;
    unsigned int zT_566;
    unsigned int zT_568;
    zT_338B7C76_TypeRegistry* zT_569;
    unsigned int zT_570;
    unsigned char zT_572 = 0;
    zT_338B7C76_TypeRegistry* zT_573;
    unsigned int zT_574;
    unsigned char zT_576 = 0;
    unsigned int zT_577;
    zT_33EF6BFB_TypeKind zT_578;
    zT_338B7C76_TypeRegistry* zT_582;
    unsigned int zT_583;
    zT_338B7C76_TypeRegistry* zT_585;
    unsigned int zT_586;
    unsigned int zT_588 = 0;
    unsigned char zT_589 = 0;
    unsigned int zT_590;
    zT_33EF6BFB_TypeKind zT_591;
    unsigned int zT_595;
    zT_33EF6BFB_TypeKind zT_596;
    unsigned char zT_600;
    unsigned char zT_601;
    zT_338B7C76_TypeRegistry* zT_606;
    unsigned int zT_607;
    unsigned int zT_609 = 0;
    unsigned int zT_610;
    zT_0163D9A4_ComptimeInt zT_613 = {0};
    zT_E23A20E9_Opt_206 zT_614;
    zT_E23A20E9_Opt_206 zT_615 = {0};
    unsigned int zT_616;
    unsigned char zT_618;
    unsigned int zT_619;
    zT_ABC1EBBE_TypeResolveEnv* zT_624;
    unsigned int zT_625;
    zT_6B0A7D14_AstStore* zT_627;
    unsigned int zT_628;
    unsigned int zT_632 = 0;
    unsigned int zT_635 = 0;
    zT_338B7C76_TypeRegistry* zT_639;
    zT_D155D06D_Type* zT_640;
    unsigned int zT_641;
    zT_D155D06D_Type zT_642;
    unsigned char zT_643;
    unsigned char zT_646;
    zT_33EF6BFB_TypeKind zT_647;
    zT_BF2E90D8_Slice_zT_2DF01B61_F zT_652 = {0};
    zT_338B7C76_TypeRegistry* zT_653;
    unsigned int zT_654;
    zT_BF2E90D8_Slice_zT_2DF01B61_F* zT_655;
    zT_BCF34E4D_Slice_zT_E276DDD0_P zT_659 = {0};
    zT_338B7C76_TypeRegistry* zT_661;
    unsigned int zT_662;
    zT_BCF34E4D_Slice_zT_E276DDD0_P* zT_663;
    unsigned char zT_666 = 0;
    zT_6B0A7D14_AstStore* zT_668;
    unsigned int zT_669;
    zT_6B0A7D14_AstStore* zT_671;
    unsigned int zT_672;
    unsigned int zT_676 = 0;
    zT_22A7C88B_AstNode zT_677 = {0};
    zT_8143F551_AstKind zT_678;
    zT_6B0A7D14_AstStore* zT_683;
    unsigned int zT_684;
    zT_6B0A7D14_AstStore* zT_686;
    unsigned int zT_687;
    unsigned int zT_691 = 0;
    unsigned int zT_692 = 0;
    zT_6B0A7D14_AstStore* zT_694;
    zT_5F32162E_anon_263674 zT_695;
    unsigned int* zT_696;
    unsigned int zT_697;
    unsigned int zT_698;
    int zT_700;
    unsigned int zT_701;
    unsigned int zT_703;
    zT_2DF01B61_FieldEntry* zT_705;
    zT_2DF01B61_FieldEntry zT_706;
    unsigned int zT_707;
    zT_2DF01B61_FieldEntry* zT_710;
    zT_2DF01B61_FieldEntry zT_711;
    unsigned int zT_712;
    zT_79FAE712_u64 zT_713;
    zT_79FAE712_u64 zT_715;
    unsigned int zT_717;
    zT_E276DDD0_PackedBitField* zT_719;
    zT_E276DDD0_PackedBitField zT_720;
    unsigned int zT_721;
    zT_79FAE712_u64 zT_722;
    unsigned int zT_723;
    zT_79FAE712_u64 zT_726;
    unsigned int zT_727;
    zT_79FAE712_u64 zT_730;
    zT_79FAE712_u64 zT_731;
    zT_0163D9A4_ComptimeInt zT_732 = {0};
    zT_E23A20E9_Opt_206 zT_733;
    int zT_734;
    unsigned int zT_736;
    zT_E23A20E9_Opt_206 zT_737 = {0};
    zT_E23A20E9_Opt_206 zT_738 = {0};
    zT_E23A20E9_Opt_206 zT_739 = {0};
    zT_22A7C88B_AstNode node;
    zT_E23A20E9_Opt_206 inner;
    zT_0163D9A4_ComptimeInt iv;
    zT_0163D9A4_ComptimeInt nv;
    zT_E23A20E9_Opt_206 l_opt;
    zT_E23A20E9_Opt_206 r_opt;
    zT_0163D9A4_ComptimeInt lv;
    zT_0163D9A4_ComptimeInt rv;
    zT_0163D9A4_ComptimeInt res;
    zT_0163D9A4_ComptimeInt rem;
    zT_0163D9A4_ComptimeInt q;
    unsigned int name_id;
    zT_E2DF2801_LocalConstScope* lcs;
    zT_6BEBA1C2_Opt_900 c_sym;
    unsigned int l_decl_node;
    zT_22A7C88B_AstNode l_decl;
    zT_3A105EF1_Symbol* cs;
    zT_22A7C88B_AstNode c_decl;
    unsigned int fa_mod_id;
    unsigned int fa_field_id;
    zT_3A105EF1_Symbol* fa_sym;
    zT_22A7C88B_AstNode fa_decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_size;
    unsigned int size_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_align;
    unsigned int align_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitsz;
    unsigned int bitsz_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_as;
    unsigned int as_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_off;
    unsigned int off_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_bitoff;
    unsigned int bitoff_id;
    unsigned int bc_n;
    unsigned int ct_tid;
    zT_E23A20E9_Opt_206 cv_opt;
    zT_0163D9A4_ComptimeInt cv;
    unsigned int bt_tid;
    zT_D155D06D_Type bt_ty;
    unsigned char bt_foldable;
    unsigned int bt_bits;
    unsigned int ot_tid;
    zT_D155D06D_Type ot_ty;
    zT_BF2E90D8_Slice_zT_2DF01B61_F fields;
    zT_BCF34E4D_Slice_zT_E276DDD0_P packed_fields;
    unsigned char has_pk;
    zT_22A7C88B_AstNode fname_node;
    unsigned int sv_idx;
    unsigned int want_id;
    unsigned int fi;
    zT_79FAE712_u64 bo;
    zT_79FAE712_u64 pk_bo;
    z_bb_0:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_5.has_value = 0;
    return zT_5;
    z_bb_2:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_8.has_value = 0;
    return zT_8;
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_int_literal))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_19 = node.kind;
    zT_18 = zT_19 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_char_literal);
    goto z_bb_7;
    z_bb_6:
    zT_18 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_18) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_24 = env->store;
    zT_25 = node_idx;
    zT_27 = zF_678B9A72_astStoreIntValue(zT_24, zT_25);
    zT_23 = zT_27;
    zT_28 = zF_1EAA44E6_ciFromU64(zT_23);
    zT_29.has_value = 1;
    zT_29.value = zT_28;
    return zT_29;
    z_bb_9:
    zT_30 = node.kind;
    if ((unsigned char)(zT_30 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_negate))) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    zT_34 = node.child_0;
    if ((unsigned char)(zT_34 != (unsigned int)(0))) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    zT_55 = node.kind;
    if ((unsigned char)(zT_55 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_paren_expr))) goto z_bb_16; else goto z_bb_17;
    z_bb_12:
    zT_38 = env;
    zT_39 = node.child_0;
    zT_44 = zF_382591DE_evalConstIntFull(zT_38, zT_39, (unsigned int)(depth + (unsigned int)(1)));
    inner = zT_44;
    zT_45 = inner.has_value;
    if (zT_45) goto z_bb_14; else goto z_bb_15;
    z_bb_13:
    zT_54.has_value = 0;
    return zT_54;
    z_bb_14:
    iv = inner.value;
    zT_48 = zF_DC9B7BC0_ciZeroInt();
    nv = zT_48;
    zT_49 = iv;
    zT_50 = &nv;
    zT_52 = zF_EECBFD7D_ciNeg(zT_49, zT_50);
    (void)zT_52;
    zT_53.has_value = 1;
    zT_53.value = nv;
    return zT_53;
    z_bb_15:
    goto z_bb_13;
    z_bb_16:
    zT_59 = env;
    zT_62 = node.child_0;
    zT_64 = depth + (unsigned int)(1);
    env = zT_59;
    node_idx = zT_62;
    depth = zT_64;
    goto z_bb_0;
    z_bb_17:
    zT_66 = node.kind;
    if ((unsigned char)(zT_66 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_19; else goto z_bb_18;
    z_bb_18:
    zT_71 = node.kind;
    zT_70 = zT_71 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub);
    goto z_bb_20;
    z_bb_19:
    zT_70 = 1;
    goto z_bb_20;
    z_bb_20:
    if (zT_70) goto z_bb_22; else goto z_bb_21;
    z_bb_21:
    zT_76 = node.kind;
    zT_75 = zT_76 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul);
    goto z_bb_23;
    z_bb_22:
    zT_75 = 1;
    goto z_bb_23;
    z_bb_23:
    if (zT_75) goto z_bb_25; else goto z_bb_24;
    z_bb_24:
    zT_81 = node.kind;
    zT_80 = zT_81 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div);
    goto z_bb_26;
    z_bb_25:
    zT_80 = 1;
    goto z_bb_26;
    z_bb_26:
    if (zT_80) goto z_bb_28; else goto z_bb_27;
    z_bb_27:
    zT_86 = node.kind;
    zT_85 = zT_86 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op);
    goto z_bb_29;
    z_bb_28:
    zT_85 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_85) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_91 = node.kind;
    zT_90 = zT_91 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and);
    goto z_bb_32;
    z_bb_31:
    zT_90 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_90) goto z_bb_34; else goto z_bb_33;
    z_bb_33:
    zT_96 = node.kind;
    zT_95 = zT_96 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or);
    goto z_bb_35;
    z_bb_34:
    zT_95 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_95) goto z_bb_37; else goto z_bb_36;
    z_bb_36:
    zT_101 = node.kind;
    zT_100 = zT_101 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor);
    goto z_bb_38;
    z_bb_37:
    zT_100 = 1;
    goto z_bb_38;
    z_bb_38:
    if (zT_100) goto z_bb_40; else goto z_bb_39;
    z_bb_39:
    zT_106 = node.kind;
    zT_105 = zT_106 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl);
    goto z_bb_41;
    z_bb_40:
    zT_105 = 1;
    goto z_bb_41;
    z_bb_41:
    if (zT_105) goto z_bb_43; else goto z_bb_42;
    z_bb_42:
    zT_111 = node.kind;
    zT_110 = zT_111 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shr);
    goto z_bb_44;
    z_bb_43:
    zT_110 = 1;
    goto z_bb_44;
    z_bb_44:
    if (zT_110) goto z_bb_45; else goto z_bb_46;
    z_bb_45:
    zT_116 = env;
    zT_117 = node.child_0;
    zT_122 = zF_382591DE_evalConstIntFull(zT_116, zT_117, (unsigned int)(depth + (unsigned int)(1)));
    l_opt = zT_122;
    zT_124 = env;
    zT_125 = node.child_1;
    zT_130 = zF_382591DE_evalConstIntFull(zT_124, zT_125, (unsigned int)(depth + (unsigned int)(1)));
    r_opt = zT_130;
    zT_131 = l_opt.has_value;
    if (zT_131) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_262 = node.kind;
    if ((unsigned char)(zT_262 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_89; else goto z_bb_90;
    z_bb_47:
    lv = l_opt.value;
    zT_133 = r_opt.has_value;
    if (zT_133) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    zT_261.has_value = 0;
    return zT_261;
    z_bb_49:
    rv = r_opt.value;
    zT_136 = zF_DC9B7BC0_ciZeroInt();
    res = zT_136;
    zT_137 = node.kind;
    if ((unsigned char)(zT_137 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_add))) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    zT_141 = lv;
    zT_142 = rv;
    zT_143 = &res;
    zT_145 = zF_8A5DB878_ciAdd(zT_141, zT_142, zT_143);
    if ((unsigned char)(!zT_145)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_149 = node.kind;
    if ((unsigned char)(zT_149 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_sub))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    zT_147.has_value = 0;
    return zT_147;
    z_bb_54:
    zT_148.has_value = 1;
    zT_148.value = res;
    return zT_148;
    z_bb_55:
    zT_153 = lv;
    zT_154 = rv;
    zT_155 = &res;
    zT_157 = zF_539A2D81_ciSub(zT_153, zT_154, zT_155);
    if ((unsigned char)(!zT_157)) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    zT_161 = node.kind;
    if ((unsigned char)(zT_161 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mul))) goto z_bb_59; else goto z_bb_60;
    z_bb_57:
    zT_159.has_value = 0;
    return zT_159;
    z_bb_58:
    zT_160.has_value = 1;
    zT_160.value = res;
    return zT_160;
    z_bb_59:
    zT_165 = lv;
    zT_166 = rv;
    zT_167 = &res;
    zT_169 = zF_A3E385DD_ciMul(zT_165, zT_166, zT_167);
    if ((unsigned char)(!zT_169)) goto z_bb_61; else goto z_bb_62;
    z_bb_60:
    zT_173 = node.kind;
    if ((unsigned char)(zT_173 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_div))) goto z_bb_63; else goto z_bb_64;
    z_bb_61:
    zT_171.has_value = 0;
    return zT_171;
    z_bb_62:
    zT_172.has_value = 1;
    zT_172.value = res;
    return zT_172;
    z_bb_63:
    zT_178 = zF_DC9B7BC0_ciZeroInt();
    rem = zT_178;
    zT_179 = lv;
    zT_180 = rv;
    zT_181 = &res;
    zT_182 = &rem;
    zT_185 = zF_25A0EEC0_ciDivMod(zT_179, zT_180, zT_181, zT_182);
    if ((unsigned char)(!zT_185)) goto z_bb_65; else goto z_bb_66;
    z_bb_64:
    zT_189 = node.kind;
    if ((unsigned char)(zT_189 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_mod_op))) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    zT_187.has_value = 0;
    return zT_187;
    z_bb_66:
    zT_188.has_value = 1;
    zT_188.value = res;
    return zT_188;
    z_bb_67:
    zT_194 = zF_DC9B7BC0_ciZeroInt();
    q = zT_194;
    zT_195 = lv;
    zT_196 = rv;
    zT_197 = &q;
    zT_198 = &res;
    zT_201 = zF_25A0EEC0_ciDivMod(zT_195, zT_196, zT_197, zT_198);
    if ((unsigned char)(!zT_201)) goto z_bb_69; else goto z_bb_70;
    z_bb_68:
    zT_205 = node.kind;
    if ((unsigned char)(zT_205 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_and))) goto z_bb_71; else goto z_bb_72;
    z_bb_69:
    zT_203.has_value = 0;
    return zT_203;
    z_bb_70:
    zT_204.has_value = 1;
    zT_204.value = res;
    return zT_204;
    z_bb_71:
    zT_209 = lv;
    zT_210 = rv;
    zT_211 = &res;
    zT_213 = zF_E15DE14D_ciBitAnd(zT_209, zT_210, zT_211);
    if ((unsigned char)(!zT_213)) goto z_bb_73; else goto z_bb_74;
    z_bb_72:
    zT_217 = node.kind;
    if ((unsigned char)(zT_217 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_or))) goto z_bb_75; else goto z_bb_76;
    z_bb_73:
    zT_215.has_value = 0;
    return zT_215;
    z_bb_74:
    zT_216.has_value = 1;
    zT_216.value = res;
    return zT_216;
    z_bb_75:
    zT_221 = lv;
    zT_222 = rv;
    zT_223 = &res;
    zT_225 = zF_93823331_ciBitOr(zT_221, zT_222, zT_223);
    if ((unsigned char)(!zT_225)) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    zT_229 = node.kind;
    if ((unsigned char)(zT_229 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_bit_xor))) goto z_bb_79; else goto z_bb_80;
    z_bb_77:
    zT_227.has_value = 0;
    return zT_227;
    z_bb_78:
    zT_228.has_value = 1;
    zT_228.value = res;
    return zT_228;
    z_bb_79:
    zT_233 = lv;
    zT_234 = rv;
    zT_235 = &res;
    zT_237 = zF_C592CA21_ciBitXor(zT_233, zT_234, zT_235);
    if ((unsigned char)(!zT_237)) goto z_bb_81; else goto z_bb_82;
    z_bb_80:
    zT_241 = node.kind;
    if ((unsigned char)(zT_241 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_shl))) goto z_bb_83; else goto z_bb_84;
    z_bb_81:
    zT_239.has_value = 0;
    return zT_239;
    z_bb_82:
    zT_240.has_value = 1;
    zT_240.value = res;
    return zT_240;
    z_bb_83:
    zT_245 = lv;
    zT_246 = rv;
    zT_247 = &res;
    zT_249 = zF_4FDD0D22_ciShl(zT_245, zT_246, zT_247);
    if ((unsigned char)(!zT_249)) goto z_bb_85; else goto z_bb_86;
    z_bb_84:
    zT_253 = lv;
    zT_254 = rv;
    zT_255 = &res;
    zT_257 = zF_41DCF718_ciShr(zT_253, zT_254, zT_255);
    if ((unsigned char)(!zT_257)) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    zT_251.has_value = 0;
    return zT_251;
    z_bb_86:
    zT_252.has_value = 1;
    zT_252.value = res;
    return zT_252;
    z_bb_87:
    zT_259.has_value = 0;
    return zT_259;
    z_bb_88:
    zT_260.has_value = 1;
    zT_260.value = res;
    return zT_260;
    z_bb_89:
    zT_267 = env->store;
    zT_268 = node_idx;
    zT_270 = zF_53458827_astStoreIdentifier(zT_267, zT_268);
    name_id = zT_270;
    zT_271 = env->local_consts;
    zT_272 = zT_271.has_value;
    if (zT_272) goto z_bb_91; else goto z_bb_92;
    z_bb_90:
    zT_322 = node.kind;
    if ((unsigned char)(zT_322 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_103; else goto z_bb_104;
    z_bb_91:
    lcs = zT_271.value;
    zT_274 = lcs;
    zT_275 = name_id;
    zT_276 = zF_6532C387_localConstScopeLook(zT_274, zT_275);
    zT_277 = zT_276.has_value;
    if (zT_277) goto z_bb_93; else goto z_bb_94;
    z_bb_92:
    zT_295 = env;
    zT_296 = name_id;
    zT_297 = zF_04FED007_symbolLookupAllModu(zT_295, zT_296);
    c_sym = zT_297;
    zT_298 = c_sym.has_value;
    if (zT_298) goto z_bb_97; else goto z_bb_98;
    z_bb_93:
    l_decl_node = zT_276.value;
    zT_280 = env->store;
    zT_281 = l_decl_node;
    zT_283 = zF_FCDD1D35_astStoreNodeAt(zT_280, zT_281);
    l_decl = zT_283;
    zT_284 = l_decl.child_1;
    if ((unsigned char)(zT_284 != (unsigned int)(0))) goto z_bb_95; else goto z_bb_96;
    z_bb_94:
    goto z_bb_92;
    z_bb_95:
    zT_287 = env;
    zT_290 = l_decl.child_1;
    zT_292 = depth + (unsigned int)(1);
    env = zT_287;
    node_idx = zT_290;
    depth = zT_292;
    goto z_bb_0;
    z_bb_96:
    goto z_bb_94;
    z_bb_97:
    cs = c_sym.value;
    zT_300 = cs->flags;
    if ((unsigned char)((unsigned short)(zT_300 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_98:
    zT_321.has_value = 0;
    return zT_321;
    z_bb_99:
    zT_306 = env->store;
    zT_307 = cs->decl_node;
    zT_310 = zF_FCDD1D35_astStoreNodeAt(zT_306, zT_307);
    c_decl = zT_310;
    zT_311 = c_decl.child_1;
    if ((unsigned char)(zT_311 != (unsigned int)(0))) goto z_bb_101; else goto z_bb_102;
    z_bb_100:
    goto z_bb_98;
    z_bb_101:
    zT_314 = env;
    zT_317 = c_decl.child_1;
    zT_319 = depth + (unsigned int)(1);
    env = zT_314;
    node_idx = zT_317;
    depth = zT_319;
    goto z_bb_0;
    z_bb_102:
    goto z_bb_100;
    z_bb_103:
    zT_327 = env;
    zT_328 = node.child_0;
    zT_330 = zF_0E4084E4_evalConstModuleOfEx(zT_327, zT_328);
    fa_mod_id = zT_330;
    if ((unsigned char)(fa_mod_id != (unsigned int)(0))) goto z_bb_105; else goto z_bb_106;
    z_bb_104:
    zT_374 = node.kind;
    if ((unsigned char)(zT_374 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_115; else goto z_bb_116;
    z_bb_105:
    zT_334 = env->store;
    zT_335 = node_idx;
    zT_337 = zF_8BA26B9E_astStoreNodePayload(zT_334, zT_335);
    fa_field_id = zT_337;
    zT_338 = env->symbol_reg;
    zT_339 = fa_mod_id;
    zT_340 = fa_field_id;
    zT_342 = zF_A398987E_symbolRegistryQuali(zT_338, zT_339, zT_340);
    zT_343 = zT_342.has_value;
    if (zT_343) goto z_bb_107; else goto z_bb_108;
    z_bb_106:
    zT_373.has_value = 0;
    return zT_373;
    z_bb_107:
    fa_sym = zT_342.value;
    zT_345 = env;
    zT_346 = node_idx;
    zT_347 = fa_field_id;
    zT_348 = fa_sym;
    zT_349 = zF_D43B245F_typeResolverCheckMe(zT_345, zT_346, zT_347, zT_348);
    if ((unsigned char)(!zT_349)) goto z_bb_109; else goto z_bb_110;
    z_bb_108:
    goto z_bb_106;
    z_bb_109:
    zT_351.has_value = 0;
    return zT_351;
    z_bb_110:
    zT_352 = fa_sym->flags;
    if ((unsigned char)((unsigned short)(zT_352 & (unsigned short)(1)) == (unsigned short)(0))) goto z_bb_111; else goto z_bb_112;
    z_bb_111:
    zT_358 = env->store;
    zT_359 = fa_sym->decl_node;
    zT_362 = zF_FCDD1D35_astStoreNodeAt(zT_358, zT_359);
    fa_decl = zT_362;
    zT_363 = fa_decl.child_1;
    if ((unsigned char)(zT_363 != (unsigned int)(0))) goto z_bb_113; else goto z_bb_114;
    z_bb_112:
    goto z_bb_108;
    z_bb_113:
    zT_366 = env;
    zT_369 = fa_decl.child_1;
    zT_371 = depth + (unsigned int)(1);
    env = zT_366;
    node_idx = zT_369;
    depth = zT_371;
    goto z_bb_0;
    z_bb_114:
    goto z_bb_112;
    z_bb_115:
    zT_379 = "@sizeOf";
    zT_381 = 7;
    zT_380.ptr = zT_379;
    zT_380.len = zT_381;
    s_size = zT_380;
    zT_383 = env->interner;
    zT_384 = s_size;
    zT_386 = zF_50C274AF_stringInternerInter(zT_383, zT_384);
    size_id = zT_386;
    zT_388 = "@alignOf";
    zT_390 = 8;
    zT_389.ptr = zT_388;
    zT_389.len = zT_390;
    s_align = zT_389;
    zT_392 = env->interner;
    zT_393 = s_align;
    zT_395 = zF_50C274AF_stringInternerInter(zT_392, zT_393);
    align_id = zT_395;
    zT_397 = "@bitSizeOf";
    zT_399 = 10;
    zT_398.ptr = zT_397;
    zT_398.len = zT_399;
    s_bitsz = zT_398;
    zT_401 = env->interner;
    zT_402 = s_bitsz;
    zT_404 = zF_50C274AF_stringInternerInter(zT_401, zT_402);
    bitsz_id = zT_404;
    zT_406 = "@intCast";
    zT_408 = 8;
    zT_407.ptr = zT_406;
    zT_407.len = zT_408;
    s_intc = zT_407;
    zT_410 = env->interner;
    zT_411 = s_intc;
    zT_413 = zF_50C274AF_stringInternerInter(zT_410, zT_411);
    intc_id = zT_413;
    zT_415 = "@as";
    zT_417 = 3;
    zT_416.ptr = zT_415;
    zT_416.len = zT_417;
    s_as = zT_416;
    zT_419 = env->interner;
    zT_420 = s_as;
    zT_422 = zF_50C274AF_stringInternerInter(zT_419, zT_420);
    as_id = zT_422;
    zT_424 = "@offsetOf";
    zT_426 = 9;
    zT_425.ptr = zT_424;
    zT_425.len = zT_426;
    s_off = zT_425;
    zT_428 = env->interner;
    zT_429 = s_off;
    zT_431 = zF_50C274AF_stringInternerInter(zT_428, zT_429);
    off_id = zT_431;
    zT_433 = "@bitOffsetOf";
    zT_435 = 12;
    zT_434.ptr = zT_433;
    zT_434.len = zT_435;
    s_bitoff = zT_434;
    zT_437 = env->interner;
    zT_438 = s_bitoff;
    zT_440 = zF_50C274AF_stringInternerInter(zT_437, zT_438);
    bitoff_id = zT_440;
    zT_442 = env->store;
    zT_443 = node_idx;
    zT_445 = zF_152E19CB_astStoreNodeExtraCh(zT_442, zT_443);
    bc_n = zT_445;
    zT_446 = node.child_0;
    if ((unsigned char)(zT_446 == intc_id)) goto z_bb_118; else goto z_bb_117;
    z_bb_116:
    zT_739.has_value = 0;
    return zT_739;
    z_bb_117:
    zT_449 = node.child_0;
    zT_448 = zT_449 == as_id;
    goto z_bb_119;
    z_bb_118:
    zT_448 = 1;
    goto z_bb_119;
    z_bb_119:
    if (zT_448) goto z_bb_120; else goto z_bb_121;
    z_bb_120:
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_122; else goto z_bb_123;
    z_bb_121:
    zT_490 = node.child_0;
    if ((unsigned char)(zT_490 == size_id)) goto z_bb_131; else goto z_bb_130;
    z_bb_122:
    zT_454 = env;
    zT_457 = env->store;
    zT_458 = node_idx;
    zT_462 = zF_B10B1BC1_astStoreNodeExtraCh(zT_457, zT_458, (unsigned int)(0));
    zT_455 = zT_462;
    zT_465 = zF_F2107C15_resolveTypeExprFull(zT_454, zT_455, (unsigned int)(depth + (unsigned int)(1)));
    ct_tid = zT_465;
    if ((unsigned char)(ct_tid != (unsigned int)(18))) goto z_bb_124; else goto z_bb_125;
    z_bb_123:
    zT_489.has_value = 0;
    return zT_489;
    z_bb_124:
    zT_469 = env;
    zT_472 = env->store;
    zT_473 = node_idx;
    zT_477 = zF_B10B1BC1_astStoreNodeExtraCh(zT_472, zT_473, (unsigned int)(1));
    zT_470 = zT_477;
    zT_480 = zF_382591DE_evalConstIntFull(zT_469, zT_470, (unsigned int)(depth + (unsigned int)(1)));
    cv_opt = zT_480;
    zT_481 = cv_opt.has_value;
    if (zT_481) goto z_bb_126; else goto z_bb_127;
    z_bb_125:
    goto z_bb_123;
    z_bb_126:
    cv = cv_opt.value;
    zT_483 = env->typereg;
    zT_484 = cv;
    zT_485 = ct_tid;
    zT_487 = zF_B28C4720_comptimeIntFitsType(zT_483, zT_484, zT_485);
    if (zT_487) goto z_bb_128; else goto z_bb_129;
    z_bb_127:
    goto z_bb_125;
    z_bb_128:
    zT_488.has_value = 1;
    zT_488.value = cv;
    return zT_488;
    z_bb_129:
    goto z_bb_127;
    z_bb_130:
    zT_493 = node.child_0;
    zT_492 = zT_493 == align_id;
    goto z_bb_132;
    z_bb_131:
    zT_492 = 1;
    goto z_bb_132;
    z_bb_132:
    if (zT_492) goto z_bb_134; else goto z_bb_133;
    z_bb_133:
    zT_496 = node.child_0;
    zT_495 = zT_496 == bitsz_id;
    goto z_bb_135;
    z_bb_134:
    zT_495 = 1;
    goto z_bb_135;
    z_bb_135:
    if (zT_495) goto z_bb_136; else goto z_bb_137;
    z_bb_136:
    if ((unsigned char)(bc_n >= (unsigned int)(1))) goto z_bb_138; else goto z_bb_139;
    z_bb_137:
    zT_616 = node.child_0;
    if ((unsigned char)(zT_616 == off_id)) goto z_bb_170; else goto z_bb_169;
    z_bb_138:
    zT_501 = env;
    zT_504 = env->store;
    zT_505 = node_idx;
    zT_509 = zF_B10B1BC1_astStoreNodeExtraCh(zT_504, zT_505, (unsigned int)(0));
    zT_502 = zT_509;
    zT_512 = zF_F2107C15_resolveTypeExprFull(zT_501, zT_502, (unsigned int)(depth + (unsigned int)(1)));
    bt_tid = zT_512;
    if ((unsigned char)(bt_tid != (unsigned int)(18))) goto z_bb_140; else goto z_bb_141;
    z_bb_139:
    zT_615.has_value = 0;
    return zT_615;
    z_bb_140:
    zT_516 = env->typereg;
    zT_517 = zT_516->types_items;
    zT_518 = (unsigned int)bt_tid;
    zT_519 = zT_517[zT_518];
    bt_ty = zT_519;
    zT_520 = bt_ty.state;
    if ((unsigned char)(zT_520 != (unsigned char)(2))) goto z_bb_142; else goto z_bb_143;
    z_bb_141:
    goto z_bb_139;
    z_bb_142:
    zT_524 = bt_ty.kind;
    zT_523 = zT_524 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_144;
    z_bb_143:
    zT_523 = 0;
    goto z_bb_144;
    z_bb_144:
    if (zT_523) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_528 = env->typereg;
    zT_529 = bt_tid;
    zT_533 = zF_3E55D0D5_layoutEnsure(zT_528, zT_529, (unsigned int)(0));
    (void)zT_533;
    zT_534 = env->typereg;
    zT_535 = zT_534->types_items;
    zT_536 = (unsigned int)bt_tid;
    zT_537 = zT_535[zT_536];
    bt_ty = zT_537;
    goto z_bb_146;
    z_bb_146:
    zT_539 = bt_ty.kind;
    zT_541 = zF_6AE4DFFC_evalConstScalarKind(zT_539);
    bt_foldable = zT_541;
    zT_542 = bt_ty.kind;
    if ((unsigned char)(zT_542 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_147; else goto z_bb_148;
    z_bb_147:
    zT_546 = 1;
    bt_foldable = zT_546;
    goto z_bb_148;
    z_bb_148:
    zT_547 = bt_ty.state;
    if ((unsigned char)(zT_547 == (unsigned char)(2))) goto z_bb_149; else goto z_bb_150;
    z_bb_149:
    zT_550 = bt_foldable;
    goto z_bb_151;
    z_bb_150:
    zT_550 = 0;
    goto z_bb_151;
    z_bb_151:
    if (zT_550) goto z_bb_152; else goto z_bb_153;
    z_bb_152:
    zT_551 = node.child_0;
    if ((unsigned char)(zT_551 == size_id)) goto z_bb_154; else goto z_bb_155;
    z_bb_153:
    goto z_bb_141;
    z_bb_154:
    zT_554 = bt_ty.size;
    zT_556 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_554));
    zT_557.has_value = 1;
    zT_557.value = zT_556;
    return zT_557;
    z_bb_155:
    zT_558 = node.child_0;
    if ((unsigned char)(zT_558 == align_id)) goto z_bb_156; else goto z_bb_157;
    z_bb_156:
    zT_561 = bt_ty.alignment;
    zT_563 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)zT_561));
    zT_564.has_value = 1;
    zT_564.value = zT_563;
    return zT_564;
    z_bb_157:
    zT_566 = bt_ty.size;
    zT_568 = zT_566 * (unsigned int)(8);
    bt_bits = zT_568;
    zT_569 = env->typereg;
    zT_570 = bt_tid;
    zT_572 = zF_3290E9C4_typeRegistryIsInteg(zT_569, zT_570);
    if (zT_572) goto z_bb_158; else goto z_bb_159;
    z_bb_158:
    zT_573 = env->typereg;
    zT_574 = bt_tid;
    zT_576 = zF_655972D5_typeRegistryIntWidt(zT_573, zT_574);
    zT_577 = (unsigned int)zT_576;
    bt_bits = zT_577;
    goto z_bb_159;
    z_bb_159:
    zT_578 = bt_ty.kind;
    if ((unsigned char)(zT_578 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_160; else goto z_bb_161;
    z_bb_160:
    zT_582 = env->typereg;
    zT_585 = env->typereg;
    zT_586 = bt_tid;
    zT_588 = zF_014D7530_typeRegistryEnumBac(zT_585, zT_586);
    zT_583 = zT_588;
    zT_589 = zF_655972D5_typeRegistryIntWidt(zT_582, zT_583);
    zT_590 = (unsigned int)zT_589;
    bt_bits = zT_590;
    goto z_bb_161;
    z_bb_161:
    zT_591 = bt_ty.kind;
    if ((unsigned char)(zT_591 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_bool_type))) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    zT_595 = 1;
    bt_bits = zT_595;
    goto z_bb_163;
    z_bb_163:
    zT_596 = bt_ty.kind;
    if ((unsigned char)(zT_596 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_601 = bt_ty.flags;
    zT_600 = (unsigned char)(zT_601 & (unsigned char)(16)) != (unsigned char)(0);
    goto z_bb_166;
    z_bb_165:
    zT_600 = 0;
    goto z_bb_166;
    z_bb_166:
    if (zT_600) goto z_bb_167; else goto z_bb_168;
    z_bb_167:
    zT_606 = env->typereg;
    zT_607 = bt_tid;
    zT_609 = zF_CB27DBA4_typeRegistryGetPack(zT_606, zT_607);
    zT_610 = (unsigned int)zT_609;
    bt_bits = zT_610;
    goto z_bb_168;
    z_bb_168:
    zT_613 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)((zT_79FAE712_u64)bt_bits));
    zT_614.has_value = 1;
    zT_614.value = zT_613;
    return zT_614;
    z_bb_169:
    zT_619 = node.child_0;
    zT_618 = zT_619 == bitoff_id;
    goto z_bb_171;
    z_bb_170:
    zT_618 = 1;
    goto z_bb_171;
    z_bb_171:
    if (zT_618) goto z_bb_172; else goto z_bb_173;
    z_bb_172:
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_174; else goto z_bb_175;
    z_bb_173:
    zT_738.has_value = 0;
    return zT_738;
    z_bb_174:
    zT_624 = env;
    zT_627 = env->store;
    zT_628 = node_idx;
    zT_632 = zF_B10B1BC1_astStoreNodeExtraCh(zT_627, zT_628, (unsigned int)(0));
    zT_625 = zT_632;
    zT_635 = zF_F2107C15_resolveTypeExprFull(zT_624, zT_625, (unsigned int)(depth + (unsigned int)(1)));
    ot_tid = zT_635;
    if ((unsigned char)(ot_tid != (unsigned int)(18))) goto z_bb_176; else goto z_bb_177;
    z_bb_175:
    zT_737.has_value = 0;
    return zT_737;
    z_bb_176:
    zT_639 = env->typereg;
    zT_640 = zT_639->types_items;
    zT_641 = (unsigned int)ot_tid;
    zT_642 = zT_640[zT_641];
    ot_ty = zT_642;
    zT_643 = ot_ty.state;
    if ((unsigned char)(zT_643 == (unsigned char)(2))) goto z_bb_178; else goto z_bb_179;
    z_bb_177:
    goto z_bb_175;
    z_bb_178:
    zT_647 = ot_ty.kind;
    zT_646 = zT_647 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type);
    goto z_bb_180;
    z_bb_179:
    zT_646 = 0;
    goto z_bb_180;
    z_bb_180:
    if (zT_646) goto z_bb_181; else goto z_bb_182;
    z_bb_181:
    fields = zT_652;
    zT_653 = env->typereg;
    zT_654 = ot_tid;
    zT_655 = &fields;
    zF_5A40A2EE_typeRegistryGetStru(zT_653, zT_654, zT_655);
    packed_fields = zT_659;
    zT_661 = env->typereg;
    zT_662 = ot_tid;
    zT_663 = &packed_fields;
    zT_666 = zF_7D87247C_typeRegistryGetPack(zT_661, zT_662, zT_663);
    has_pk = zT_666;
    zT_668 = env->store;
    zT_671 = env->store;
    zT_672 = node_idx;
    zT_676 = zF_B10B1BC1_astStoreNodeExtraCh(zT_671, zT_672, (unsigned int)(1));
    zT_669 = zT_676;
    zT_677 = zF_FCDD1D35_astStoreNodeAt(zT_668, zT_669);
    fname_node = zT_677;
    zT_678 = fname_node.kind;
    if ((unsigned char)(zT_678 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_string_literal))) goto z_bb_183; else goto z_bb_184;
    z_bb_182:
    goto z_bb_177;
    z_bb_183:
    zT_683 = env->store;
    zT_686 = env->store;
    zT_687 = node_idx;
    zT_691 = zF_B10B1BC1_astStoreNodeExtraCh(zT_686, zT_687, (unsigned int)(1));
    zT_684 = zT_691;
    zT_692 = zF_8BA26B9E_astStoreNodePayload(zT_683, zT_684);
    sv_idx = zT_692;
    zT_694 = env->store;
    zT_695 = zT_694->string_values;
    zT_696 = zT_695.items;
    zT_697 = (unsigned int)sv_idx;
    zT_698 = zT_696[zT_697];
    want_id = zT_698;
    zT_700 = 0;
    zT_701 = (unsigned int)zT_700;
    fi = zT_701;
    goto z_bb_185;
    z_bb_184:
    goto z_bb_182;
    z_bb_185:
    zT_703 = fields.len;
    if ((unsigned char)(fi < zT_703)) goto z_bb_186; else goto z_bb_187;
    z_bb_186:
    zT_705 = fields.ptr;
    zT_706 = zT_705[fi];
    zT_707 = zT_706.name_id;
    if ((unsigned char)(zT_707 == want_id)) goto z_bb_189; else goto z_bb_190;
    z_bb_187:
    goto z_bb_184;
    z_bb_188:
    zT_734 = 1;
    zT_736 = fi + (unsigned int)((unsigned int)zT_734);
    fi = zT_736;
    goto z_bb_185;
    z_bb_189:
    zT_710 = fields.ptr;
    zT_711 = zT_710[fi];
    zT_712 = zT_711.offset;
    zT_713 = (zT_79FAE712_u64)zT_712;
    bo = zT_713;
    if (has_pk) goto z_bb_191; else goto z_bb_193;
    z_bb_190:
    goto z_bb_188;
    z_bb_191:
    zT_715 = 0;
    pk_bo = zT_715;
    zT_717 = packed_fields.len;
    if ((unsigned char)(fi < zT_717)) goto z_bb_194; else goto z_bb_195;
    z_bb_192:
    zT_731 = bo;
    zT_732 = zF_1EAA44E6_ciFromU64(zT_731);
    zT_733.has_value = 1;
    zT_733.value = zT_732;
    return zT_733;
    z_bb_193:
    zT_727 = node.child_0;
    if ((unsigned char)(zT_727 == bitoff_id)) goto z_bb_199; else goto z_bb_200;
    z_bb_194:
    zT_719 = packed_fields.ptr;
    zT_720 = zT_719[fi];
    zT_721 = zT_720.bit_offset;
    zT_722 = (zT_79FAE712_u64)zT_721;
    pk_bo = zT_722;
    goto z_bb_195;
    z_bb_195:
    zT_723 = node.child_0;
    if ((unsigned char)(zT_723 == bitoff_id)) goto z_bb_196; else goto z_bb_198;
    z_bb_196:
    bo = pk_bo;
    goto z_bb_197;
    z_bb_197:
    goto z_bb_192;
    z_bb_198:
    zT_726 = pk_bo / (zT_79FAE712_u64)(8);
    bo = zT_726;
    goto z_bb_197;
    z_bb_199:
    zT_730 = bo * (zT_79FAE712_u64)(8);
    bo = zT_730;
    goto z_bb_200;
    z_bb_200:
    goto z_bb_192;
}

/* evalConstIntToSize */
unsigned int zF_5C9D5CFF_evalConstIntToSize(zT_0163D9A4_ComptimeInt v) {
    unsigned char zT_1;
    zT_0163D9A4_ComptimeInt zT_6 = {0};
    zT_0163D9A4_ComptimeInt zT_7;
    zT_0163D9A4_ComptimeInt zT_8;
    int zT_9 = 0;
    int zT_10;
    zT_0163D9A4_ComptimeInt zT_13;
    zT_79FAE712_u64 zT_14 = 0;
    zT_0163D9A4_ComptimeInt lim;
    zT_1 = v.neg;
    if (zT_1) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    zT_6 = zF_1EAA44E6_ciFromU64((zT_79FAE712_u64)(4294967294u));
    lim = zT_6;
    zT_7 = v;
    zT_8 = lim;
    zT_9 = zF_6408F093_ciCmp(zT_7, zT_8);
    zT_10 = 0;
    if ((unsigned char)(zT_9 > zT_10)) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_13 = v;
    zT_14 = zF_4F2C9C5D_ciToU64(zT_13);
    return (unsigned int)((unsigned int)zT_14);
}

/* evalConstU32Full */
unsigned int zF_6D0DD27D_evalConstU32Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_10;
    unsigned int zT_11;
    zT_22A7C88B_AstNode zT_13 = {0};
    zT_8143F551_AstKind zT_14;
    unsigned char* zT_19;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_20;
    unsigned int zT_21;
    zT_D3EB6303_StringInterner* zT_23;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_24;
    unsigned int zT_26 = 0;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_37;
    unsigned int zT_38;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    unsigned int zT_45 = 0;
    unsigned int zT_48 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_50;
    unsigned int zT_51;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    unsigned int zT_58 = 0;
    zT_E23A20E9_Opt_206 zT_61 = {0};
    unsigned char zT_64;
    zT_338B7C76_TypeRegistry* zT_66;
    zT_0163D9A4_ComptimeInt zT_67;
    unsigned int zT_68;
    unsigned char zT_70 = 0;
    zT_6F32B01B_Opt_235 zT_72;
    unsigned char zT_73;
    zT_F85C5DED_DiagnosticCollector* zT_75;
    unsigned int zT_76;
    unsigned char zT_77 = 0;
    unsigned char* zT_79;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_80;
    unsigned int zT_81;
    zT_F85C5DED_DiagnosticCollector* zT_82;
    unsigned int zT_85;
    unsigned int zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_88;
    unsigned int zT_93;
    unsigned int zT_94;
    unsigned int zT_97 = 0;
    zT_0163D9A4_ComptimeInt zT_99;
    unsigned int zT_100 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_103;
    unsigned int zT_104;
    unsigned int zT_105;
    zT_E23A20E9_Opt_206 zT_106 = {0};
    unsigned char zT_107;
    zT_0163D9A4_ComptimeInt zT_108;
    zT_0163D9A4_ComptimeInt zT_110;
    zT_0163D9A4_ComptimeInt zT_111;
    unsigned int zT_112 = 0;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u s_intc;
    unsigned int intc_id;
    zT_0163D9A4_ComptimeInt v;
    unsigned int bc_n;
    unsigned int ic_tid;
    zT_E23A20E9_Opt_206 ic_v;
    zT_0163D9A4_ComptimeInt iv;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ic_msg;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(4294967295u);
    z_bb_2:
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned int)(4294967295u);
    z_bb_4:
    zT_10 = env->store;
    zT_11 = node_idx;
    zT_13 = zF_FCDD1D35_astStoreNodeAt(zT_10, zT_11);
    node = zT_13;
    zT_14 = node.kind;
    if ((unsigned char)(zT_14 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_builtin_call))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    zT_19 = "@intCast";
    zT_21 = 8;
    zT_20.ptr = zT_19;
    zT_20.len = zT_21;
    s_intc = zT_20;
    zT_23 = env->interner;
    zT_24 = s_intc;
    zT_26 = zF_50C274AF_stringInternerInter(zT_23, zT_24);
    intc_id = zT_26;
    zT_27 = node.child_0;
    if ((unsigned char)(zT_27 == intc_id)) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_103 = env;
    zT_104 = node_idx;
    zT_105 = depth;
    zT_106 = zF_382591DE_evalConstIntFull(zT_103, zT_104, zT_105);
    zT_107 = zT_106.has_value;
    if (zT_107) goto z_bb_22; else goto z_bb_21;
    z_bb_7:
    zT_30 = env->store;
    zT_31 = node_idx;
    zT_33 = zF_152E19CB_astStoreNodeExtraCh(zT_30, zT_31);
    bc_n = zT_33;
    if ((unsigned char)(bc_n >= (unsigned int)(2))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_37 = env;
    zT_40 = env->store;
    zT_41 = node_idx;
    zT_45 = zF_B10B1BC1_astStoreNodeExtraCh(zT_40, zT_41, (unsigned int)(0));
    zT_38 = zT_45;
    zT_48 = zF_F2107C15_resolveTypeExprFull(zT_37, zT_38, (unsigned int)(depth + (unsigned int)(1)));
    ic_tid = zT_48;
    zT_50 = env;
    zT_53 = env->store;
    zT_54 = node_idx;
    zT_58 = zF_B10B1BC1_astStoreNodeExtraCh(zT_53, zT_54, (unsigned int)(1));
    zT_51 = zT_58;
    zT_61 = zF_382591DE_evalConstIntFull(zT_50, zT_51, (unsigned int)(depth + (unsigned int)(1)));
    ic_v = zT_61;
    if ((unsigned char)(ic_tid != (unsigned int)(18))) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    return (unsigned int)(4294967295u);
    z_bb_11:
    zT_64 = ic_v.has_value;
    if (zT_64) goto z_bb_13; else goto z_bb_14;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    iv = ic_v.value;
    zT_66 = env->typereg;
    zT_67 = iv;
    zT_68 = ic_tid;
    zT_70 = zF_B28C4720_comptimeIntFitsType(zT_66, zT_67, zT_68);
    if ((unsigned char)(!zT_70)) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_12;
    z_bb_15:
    zT_72 = env->diag;
    zT_73 = zT_72.has_value;
    if (zT_73) goto z_bb_17; else goto z_bb_18;
    z_bb_16:
    zT_99 = iv;
    zT_100 = zF_5C9D5CFF_evalConstIntToSize(zT_99);
    return zT_100;
    z_bb_17:
    dg = zT_72.value;
    zT_75 = dg;
    zT_76 = node_idx;
    zT_77 = zF_4DD9DB2D_diagnosticCollector(zT_75, zT_76);
    if (zT_77) goto z_bb_19; else goto z_bb_20;
    z_bb_18:
    return (unsigned int)(4294967295u);
    z_bb_19:
    zT_79 = "@intCast value does not fit the target type";
    zT_81 = 43;
    zT_80.ptr = zT_79;
    zT_80.len = zT_81;
    ic_msg = zT_80;
    zT_82 = dg;
    zT_85 = env->source_file_id;
    zT_86 = node.span_start;
    zT_93 = node.span_start;
    zT_94 = node.span_len;
    zT_88 = ic_msg;
    zT_97 = zF_C82559AC_diagnosticCollector(zT_82, (unsigned char)(0), (unsigned short)(3000), zT_85, zT_86, (unsigned int)(zT_93 + (unsigned int)((unsigned int)zT_94)), zT_88);
    (void)zT_97;
    goto z_bb_20;
    z_bb_20:
    goto z_bb_18;
    z_bb_21:
    return (unsigned int)(4294967295u);
    z_bb_22:
    zT_110 = zT_106.value;
    zT_108 = zT_110;
    goto z_bb_23;
    z_bb_23:
    v = zT_108;
    zT_111 = v;
    zT_112 = zF_5C9D5CFF_evalConstIntToSize(zT_111);
    return zT_112;
}

/* evalConstI64Full */
zT_44E16D78_Opt_7 zF_FFFAAD16_evalConstI64Full(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_ABC1EBBE_TypeResolveEnv* zT_4;
    unsigned int zT_5;
    unsigned int zT_6;
    zT_E23A20E9_Opt_206 zT_7 = {0};
    unsigned char zT_8;
    zT_0163D9A4_ComptimeInt zT_9;
    zT_44E16D78_Opt_7 zT_10 = {0};
    zT_0163D9A4_ComptimeInt zT_11;
    zT_0163D9A4_ComptimeInt zT_12;
    unsigned char zT_13 = 0;
    zT_44E16D78_Opt_7 zT_15 = {0};
    zT_0163D9A4_ComptimeInt zT_16;
    zT_79FAE712_u64 zT_17 = 0;
    zT_C69B2266_i64 zT_18;
    zT_44E16D78_Opt_7 zT_19;
    zT_0163D9A4_ComptimeInt v;
    zT_4 = env;
    zT_5 = node_idx;
    zT_6 = depth;
    zT_7 = zF_382591DE_evalConstIntFull(zT_4, zT_5, zT_6);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_10.has_value = 0;
    return zT_10;
    z_bb_2:
    zT_11 = zT_7.value;
    zT_9 = zT_11;
    goto z_bb_3;
    z_bb_3:
    v = zT_9;
    zT_12 = v;
    zT_13 = zF_EF3A264A_comptimeIntFits64(zT_12);
    if ((unsigned char)(!zT_13)) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    zT_15.has_value = 0;
    return zT_15;
    z_bb_5:
    zT_16 = v;
    zT_17 = zF_4F2C9C5D_ciToU64(zT_16);
    zT_18 = (zT_C69B2266_i64)zT_17;
    zT_19.has_value = 1;
    zT_19.value = zT_18;
    return zT_19;
}

/* symbolLookupAllModules */
zT_6BEBA1C2_Opt_900 zF_04FED007_symbolLookupAllModu(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_12;
    zT_6BEBA1C2_Opt_900 zT_15 = {0};
    unsigned char zT_16;
    int zT_17;
    unsigned int zT_19;
    zT_6BEBA1C2_Opt_900 zT_20 = {0};
    unsigned int si;
    zT_6BEBA1C2_Opt_900 sym;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_12 = name_id;
    zT_15 = zF_A398987E_symbolRegistryQuali(zT_10, (unsigned int)((unsigned int)si), zT_12);
    sym = zT_15;
    zT_16 = sym.has_value;
    if (zT_16) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    zT_20.has_value = 0;
    return zT_20;
    z_bb_4:
    zT_17 = 1;
    zT_19 = si + (unsigned int)((unsigned int)zT_17);
    si = zT_19;
    goto z_bb_1;
    z_bb_5:
    return sym;
    z_bb_6:
    goto z_bb_4;
}

/* symbolTypeIdOfModule */
unsigned int zF_66C54985_symbolTypeIdOfModul(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int module_id, unsigned int name_id) {
    zT_3D7259E2_SymbolRegistry* zT_3;
    unsigned int zT_4;
    unsigned int zT_5;
    zT_6BEBA1C2_Opt_900 zT_7 = {0};
    unsigned char zT_8;
    unsigned int zT_10;
    unsigned int zT_13;
    zT_3A105EF1_Symbol* s;
    zT_3 = env->symbol_reg;
    zT_4 = module_id;
    zT_5 = name_id;
    zT_7 = zF_A398987E_symbolRegistryQuali(zT_3, zT_4, zT_5);
    zT_8 = zT_7.has_value;
    if (zT_8) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    s = zT_7.value;
    zT_10 = s->type_id;
    if ((unsigned char)(zT_10 != (unsigned int)(0))) goto z_bb_3; else goto z_bb_4;
    z_bb_2:
    return (unsigned int)(0);
    z_bb_3:
    zT_13 = s->type_id;
    return zT_13;
    z_bb_4:
    goto z_bb_2;
}

/* symbolLookupTypeAllModules */
unsigned int zF_DE1472AF_symbolLookupTypeAll(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int name_id) {
    int zT_3;
    unsigned int zT_4;
    zT_3D7259E2_SymbolRegistry* zT_5;
    unsigned int zT_6;
    zT_ABC1EBBE_TypeResolveEnv* zT_10;
    unsigned int zT_12;
    unsigned int zT_14 = 0;
    int zT_17;
    unsigned int zT_19;
    unsigned int si;
    unsigned int t;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    si = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_5 = env->symbol_reg;
    zT_6 = zT_5->tables_len;
    if ((unsigned char)(si < (unsigned int)((unsigned int)zT_6))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = env;
    zT_12 = name_id;
    zT_14 = zF_66C54985_symbolTypeIdOfModul(zT_10, (unsigned int)((unsigned int)si), zT_12);
    t = zT_14;
    if ((unsigned char)(t != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return (unsigned int)(0);
    z_bb_4:
    zT_17 = 1;
    zT_19 = si + (unsigned int)((unsigned int)zT_17);
    si = zT_19;
    goto z_bb_1;
    z_bb_5:
    return t;
    z_bb_6:
    goto z_bb_4;
}

/* enumMembersResolve */
unsigned char zF_0FFDEDBD_enumMembersResolve(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int enum_node, unsigned char append, unsigned int mstart, unsigned char strict, unsigned char check_only, unsigned int* out_count, unsigned int* out_fail_node, unsigned int* out_fail_kind) {
    zT_29C26066_Arr_zT_C69B2266_i64 zT_10;
    zT_6B0A7D14_AstStore* zT_12;
    unsigned int zT_13;
    unsigned int zT_15 = 0;
    zT_C69B2266_i64 zT_17;
    int zT_19;
    unsigned int zT_20;
    int zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_34 = 0;
    zT_22A7C88B_AstNode zT_35 = {0};
    zT_8143F551_AstKind zT_36;
    unsigned int zT_41;
    zT_ABC1EBBE_TypeResolveEnv* zT_45;
    unsigned int zT_46;
    zT_44E16D78_Opt_7 zT_50 = {0};
    unsigned char zT_51;
    unsigned int zT_53;
    unsigned char zT_57;
    unsigned int zT_60;
    int zT_62;
    unsigned int zT_63;
    zT_C69B2266_i64 zT_66 = 0;
    unsigned int zT_67;
    zT_C69B2266_i64 zT_68;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_D96DCDF2_EnumMember* zT_70;
    unsigned int zT_73;
    zT_D96DCDF2_EnumMember zT_74;
    zT_C69B2266_i64 zT_75;
    zT_6B0A7D14_AstStore* zT_77;
    unsigned int zT_78;
    unsigned int zT_82 = 0;
    int zT_85;
    unsigned int zT_87;
    unsigned int zT_90;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_D96DCDF2_EnumMember zT_92;
    zT_D96DCDF2_EnumMember zT_94;
    zT_6B0A7D14_AstStore* zT_95;
    unsigned int zT_96;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_103 = 0;
    unsigned int zT_104 = 0;
    zT_338B7C76_TypeRegistry* zT_105;
    zT_D96DCDF2_EnumMember* zT_106;
    zT_D96DCDF2_EnumMember* zT_110;
    int zT_111;
    unsigned int zT_113;
    zT_C69B2266_i64 zT_115;
    int zT_116;
    unsigned int zT_118;
    zT_29C26066_Arr_zT_C69B2266_i64 seen;
    unsigned int children_n;
    zT_C69B2266_i64 auto_val;
    unsigned int k;
    unsigned int i;
    zT_22A7C88B_AstNode mnode;
    zT_C69B2266_i64 mval;
    zT_44E16D78_Opt_7 ev_opt;
    zT_C69B2266_i64 ev;
    unsigned int dj_lim;
    unsigned int dj;
    zT_C69B2266_i64 prev;
    {
    unsigned int _i = 0;
    while (_i < 256) {
        zT_10[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 256) {
        seen[_i] = zT_10[_i];
        _i++;
    }
}
    zT_12 = env->store;
    zT_13 = enum_node;
    zT_15 = zF_152E19CB_astStoreNodeExtraCh(zT_12, zT_13);
    children_n = zT_15;
    zT_17 = 0;
    auto_val = zT_17;
    zT_19 = 0;
    zT_20 = (unsigned int)zT_19;
    k = zT_20;
    zT_22 = 0;
    zT_23 = (unsigned int)zT_22;
    i = zT_23;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < children_n)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_26 = env->store;
    zT_29 = env->store;
    zT_30 = enum_node;
    zT_34 = zF_B10B1BC1_astStoreNodeExtraCh(zT_29, zT_30, (unsigned int)((unsigned int)i));
    zT_27 = zT_34;
    zT_35 = zF_FCDD1D35_astStoreNodeAt(zT_26, zT_27);
    mnode = zT_35;
    zT_36 = mnode.kind;
    if ((unsigned char)(zT_36 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    *out_count = k;
    return (unsigned char)(1);
    z_bb_4:
    zT_116 = 1;
    zT_118 = i + (unsigned int)((unsigned int)zT_116);
    i = zT_118;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    mval = auto_val;
    zT_41 = mnode.child_1;
    if ((unsigned char)(zT_41 != (unsigned int)(0))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_45 = env;
    zT_46 = mnode.child_1;
    zT_50 = zF_FFFAAD16_evalConstI64Full(zT_45, zT_46, (unsigned int)(0));
    ev_opt = zT_50;
    zT_51 = ev_opt.has_value;
    if (zT_51) goto z_bb_9; else goto z_bb_11;
    z_bb_8:
    if (strict) goto z_bb_14; else goto z_bb_15;
    z_bb_9:
    ev = ev_opt.value;
    mval = ev;
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
    z_bb_11:
    if (strict) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    zT_53 = mnode.child_1;
    *out_fail_node = zT_53;
    *out_fail_kind = (unsigned int)(1);
    *out_count = k;
    return (unsigned char)(0);
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    dj_lim = k;
    if (check_only) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    if (check_only) goto z_bb_30; else goto z_bb_32;
    z_bb_16:
    zT_57 = dj_lim > (unsigned int)(256);
    goto z_bb_18;
    z_bb_17:
    zT_57 = 0;
    goto z_bb_18;
    z_bb_18:
    if (zT_57) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_60 = 256;
    dj_lim = zT_60;
    goto z_bb_20;
    z_bb_20:
    zT_62 = 0;
    zT_63 = (unsigned int)zT_62;
    dj = zT_63;
    goto z_bb_21;
    z_bb_21:
    if ((unsigned char)(dj < dj_lim)) goto z_bb_22; else goto z_bb_23;
    z_bb_22:
    prev = zT_66;
    if (check_only) goto z_bb_25; else goto z_bb_27;
    z_bb_23:
    goto z_bb_15;
    z_bb_24:
    zT_85 = 1;
    zT_87 = dj + (unsigned int)((unsigned int)zT_85);
    dj = zT_87;
    goto z_bb_21;
    z_bb_25:
    zT_67 = (unsigned int)dj;
    zT_68 = seen[zT_67];
    prev = zT_68;
    goto z_bb_26;
    z_bb_26:
    if ((unsigned char)(prev == mval)) goto z_bb_28; else goto z_bb_29;
    z_bb_27:
    zT_69 = env->typereg;
    zT_70 = zT_69->em_items;
    zT_73 = (unsigned int)((unsigned int)mstart) + (unsigned int)((unsigned int)dj);
    zT_74 = zT_70[zT_73];
    zT_75 = zT_74.value;
    prev = zT_75;
    goto z_bb_26;
    z_bb_28:
    zT_77 = env->store;
    zT_78 = enum_node;
    zT_82 = zF_B10B1BC1_astStoreNodeExtraCh(zT_77, zT_78, (unsigned int)((unsigned int)i));
    *out_fail_node = zT_82;
    *out_fail_kind = (unsigned int)(2);
    *out_count = k;
    return (unsigned char)(0);
    z_bb_29:
    goto z_bb_24;
    z_bb_30:
    if ((unsigned char)(k < (unsigned int)(256))) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    zT_111 = 1;
    zT_113 = k + (unsigned int)((unsigned int)zT_111);
    k = zT_113;
    zT_115 = mval + (zT_C69B2266_i64)(1);
    auto_val = zT_115;
    goto z_bb_4;
    z_bb_32:
    if (append) goto z_bb_35; else goto z_bb_37;
    z_bb_33:
    zT_90 = (unsigned int)k;
    seen[zT_90] = mval;
    goto z_bb_34;
    z_bb_34:
    goto z_bb_31;
    z_bb_35:
    zT_91 = env->typereg;
    zT_95 = env->store;
    zT_98 = env->store;
    zT_99 = enum_node;
    zT_103 = zF_B10B1BC1_astStoreNodeExtraCh(zT_98, zT_99, (unsigned int)((unsigned int)i));
    zT_96 = zT_103;
    zT_104 = zF_8BA26B9E_astStoreNodePayload(zT_95, zT_96);
    zT_94.name_id = zT_104;
    zT_94.value = mval;
    zT_92 = zT_94;
    zF_157DA7BF_emAppend(zT_91, zT_92);
    goto z_bb_36;
    z_bb_36:
    goto z_bb_31;
    z_bb_37:
    zT_105 = env->typereg;
    zT_106 = zT_105->em_items;
    zT_110 = zT_106 + (unsigned int)((unsigned int)((unsigned int)mstart) + (unsigned int)((unsigned int)k));
    zT_110->value = mval;
    goto z_bb_36;
}

/* reportEnumWalkFailure */
void zF_52B56F5B_reportEnumWalkFailu(zT_F85C5DED_DiagnosticCollector* diag, zT_6B0A7D14_AstStore* store, unsigned int source_file_id, unsigned int fail_node, unsigned int fail_kind) {
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    zT_22A7C88B_AstNode zT_8 = {0};
    unsigned int zT_10;
    unsigned int zT_12;
    unsigned int zT_14;
    unsigned char* zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17;
    unsigned int zT_18;
    unsigned char* zT_21;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_22;
    unsigned int zT_23;
    zT_F85C5DED_DiagnosticCollector* zT_24;
    unsigned int zT_27;
    unsigned int zT_28;
    unsigned int zT_29;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30;
    unsigned int zT_35 = 0;
    zT_22A7C88B_AstNode fn_;
    unsigned int sp;
    unsigned int ep;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    zT_6 = store;
    zT_7 = fail_node;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_6, zT_7);
    fn_ = zT_8;
    zT_10 = fn_.span_start;
    sp = zT_10;
    zT_12 = fn_.span_len;
    zT_14 = sp + (unsigned int)((unsigned int)zT_12);
    ep = zT_14;
    zT_16 = "enum member value is not a comptime-known integer expression";
    zT_18 = 60;
    zT_17.ptr = zT_16;
    zT_17.len = zT_18;
    msg = zT_17;
    if ((unsigned char)(fail_kind == (unsigned int)(2))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_21 = "duplicate enum tag value (tag values must be unique)";
    zT_23 = 52;
    zT_22.ptr = zT_21;
    zT_22.len = zT_23;
    msg = zT_22;
    goto z_bb_2;
    z_bb_2:
    zT_24 = diag;
    zT_27 = source_file_id;
    zT_28 = sp;
    zT_29 = ep;
    zT_30 = msg;
    zT_35 = zF_C82559AC_diagnosticCollector(zT_24, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3055_ENUM_VALUE_NOT_CONSTANT)), zT_27, zT_28, zT_29, zT_30);
    (void)zT_35;
    return;
}

/* enumReevaluateAll */
void zF_153D24FD_enumReevaluateAll(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag) {
    zT_072B53A6_ModuleRegistry* zT_7;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_8 = {0};
    int zT_10;
    unsigned int zT_11;
    unsigned int zT_13;
    zT_6E8D187B_ModuleEntry* zT_16;
    zT_6E8D187B_ModuleEntry zT_17;
    unsigned int zT_18;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    unsigned int zT_24 = 0;
    int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_34 = 0;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    zT_22A7C88B_AstNode zT_38 = {0};
    unsigned int zT_40;
    unsigned int zT_42;
    zT_8143F551_AstKind zT_43;
    unsigned char zT_47;
    unsigned int zT_48;
    unsigned int zT_51;
    zT_8143F551_AstKind zT_52;
    unsigned char zT_56;
    unsigned int zT_57;
    zT_6B0A7D14_AstStore* zT_61;
    unsigned int zT_62;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_70;
    unsigned int zT_71;
    unsigned int zT_72 = 0;
    zT_6E8D187B_ModuleEntry* zT_76;
    zT_6E8D187B_ModuleEntry zT_77;
    unsigned int zT_78;
    zT_79FAE712_u64 zT_83;
    zT_939EE900_Arr_unsigned_int_1 zT_85;
    unsigned int zT_86;
    unsigned int zT_87;
    zT_338B7C76_TypeRegistry* zT_88;
    zT_79FAE712_u64 zT_89;
    zT_BAEE192E_Opt_10 zT_90 = {0};
    unsigned char zT_91;
    int zT_93;
    int zT_95;
    unsigned int zT_96;
    unsigned int zT_98;
    zT_D155D06D_Type* zT_101;
    unsigned int zT_102;
    zT_D155D06D_Type zT_103;
    zT_33EF6BFB_TypeKind zT_104;
    zT_457ECFEE_EnumPayload* zT_109;
    unsigned int zT_110;
    unsigned int zT_111;
    zT_457ECFEE_EnumPayload zT_112;
    zT_ABC1EBBE_TypeResolveEnv zT_114;
    zT_6E8D187B_ModuleEntry* zT_115;
    zT_6E8D187B_ModuleEntry zT_116;
    unsigned int zT_117;
    zT_6E8D187B_ModuleEntry* zT_118;
    zT_6E8D187B_ModuleEntry zT_119;
    unsigned int zT_120;
    zT_6F32B01B_Opt_235 zT_121;
    zT_0DCE6231_Opt_408 zT_122 = {0};
    zT_FFCC0D90_Opt_410 zT_123 = {0};
    int zT_125;
    unsigned int zT_126;
    int zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_132;
    zT_ABC1EBBE_TypeResolveEnv* zT_133;
    unsigned int zT_134;
    unsigned int zT_136;
    unsigned int* zT_139;
    unsigned int* zT_140;
    unsigned int* zT_141;
    unsigned char zT_150 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_152;
    zT_6B0A7D14_AstStore* zT_153;
    unsigned int zT_154;
    unsigned int zT_155;
    unsigned int zT_156;
    zT_6E8D187B_ModuleEntry* zT_157;
    zT_6E8D187B_ModuleEntry zT_158;
    int zT_160;
    unsigned int zT_162;
    int zT_163;
    unsigned int zT_165;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    unsigned int mi;
    unsigned int ast_root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode dnode;
    unsigned int enum_node;
    unsigned int enum_name_id;
    zT_22A7C88B_AstNode inn;
    zT_79FAE712_u64 key;
    zT_939EE900_Arr_unsigned_int_1 tid_box;
    unsigned int t;
    unsigned int tid;
    zT_D155D06D_Type ety;
    zT_457ECFEE_EnumPayload ep;
    zT_ABC1EBBE_TypeResolveEnv env;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    zT_7 = module_reg;
    zT_8 = zF_3452C137_moduleRegistryGetMo(zT_7);
    mods = zT_8;
    zT_10 = 0;
    zT_11 = (unsigned int)zT_10;
    mi = zT_11;
    goto z_bb_1;
    z_bb_1:
    zT_13 = mods.len;
    if ((unsigned char)(mi < zT_13)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = mods.ptr;
    zT_17 = zT_16[mi];
    zT_18 = zT_17.ast_root;
    ast_root = zT_18;
    if ((unsigned char)(ast_root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_163 = 1;
    zT_165 = mi + (unsigned int)((unsigned int)zT_163);
    mi = zT_165;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_22 = store;
    zT_23 = ast_root;
    zT_24 = zF_152E19CB_astStoreNodeExtraCh(zT_22, zT_23);
    decls_n = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < decls_n)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_30 = store;
    zT_31 = ast_root;
    zT_34 = zF_B10B1BC1_astStoreNodeExtraCh(zT_30, zT_31, (unsigned int)((unsigned int)di));
    decl_idx = zT_34;
    zT_36 = store;
    zT_37 = decl_idx;
    zT_38 = zF_FCDD1D35_astStoreNodeAt(zT_36, zT_37);
    dnode = zT_38;
    zT_40 = 0;
    enum_node = zT_40;
    zT_42 = 0;
    enum_name_id = zT_42;
    zT_43 = dnode.kind;
    if ((unsigned char)(zT_43 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_160 = 1;
    zT_162 = di + (unsigned int)((unsigned int)zT_160);
    di = zT_162;
    goto z_bb_7;
    z_bb_11:
    zT_48 = dnode.child_1;
    zT_47 = zT_48 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_47 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_47) goto z_bb_14; else goto z_bb_16;
    z_bb_14:
    enum_node = decl_idx;
    zT_51 = dnode.child_0;
    enum_name_id = zT_51;
    goto z_bb_15;
    z_bb_15:
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_24; else goto z_bb_25;
    z_bb_16:
    zT_52 = dnode.kind;
    if ((unsigned char)(zT_52 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    zT_57 = dnode.child_1;
    zT_56 = zT_57 != (unsigned int)(0);
    goto z_bb_19;
    z_bb_18:
    zT_56 = 0;
    goto z_bb_19;
    z_bb_19:
    if (zT_56) goto z_bb_20; else goto z_bb_21;
    z_bb_20:
    zT_61 = store;
    zT_62 = dnode.child_1;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_61, zT_62);
    inn = zT_64;
    zT_65 = inn.kind;
    if ((unsigned char)(zT_65 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_22; else goto z_bb_23;
    z_bb_21:
    goto z_bb_15;
    z_bb_22:
    zT_69 = dnode.child_1;
    enum_node = zT_69;
    zT_70 = store;
    zT_71 = decl_idx;
    zT_72 = zF_8BA26B9E_astStoreNodePayload(zT_70, zT_71);
    enum_name_id = zT_72;
    goto z_bb_23;
    z_bb_23:
    goto z_bb_21;
    z_bb_24:
    goto z_bb_10;
    z_bb_25:
    zT_76 = mods.ptr;
    zT_77 = zT_76[mi];
    zT_78 = zT_77.id;
    zT_83 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_78) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)enum_name_id);
    key = zT_83;
    zT_86 = 0;
    zT_87 = 0;
    zT_85[zT_87] = zT_86;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        tid_box[_i] = zT_85[_i];
        _i++;
    }
}
    zT_88 = typereg;
    zT_89 = key;
    zT_90 = zF_0EB68360_nameCacheGet(zT_88, zT_89);
    zT_91 = zT_90.has_value;
    if (zT_91) goto z_bb_26; else goto z_bb_28;
    z_bb_26:
    t = zT_90.value;
    zT_93 = 0;
    tid_box[zT_93] = t;
    goto z_bb_27;
    z_bb_27:
    zT_95 = 0;
    zT_96 = tid_box[zT_95];
    tid = zT_96;
    zT_98 = typereg->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)tid) >= zT_98)) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_10;
    z_bb_29:
    goto z_bb_10;
    z_bb_30:
    zT_101 = typereg->types_items;
    zT_102 = (unsigned int)tid;
    zT_103 = zT_101[zT_102];
    ety = zT_103;
    zT_104 = ety.kind;
    if ((unsigned char)(zT_104 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_enum_type))) goto z_bb_31; else goto z_bb_32;
    z_bb_31:
    goto z_bb_10;
    z_bb_32:
    zT_109 = typereg->en_items;
    zT_110 = ety.payload_idx;
    zT_111 = (unsigned int)zT_110;
    zT_112 = zT_109[zT_111];
    ep = zT_112;
    zT_114.store = store;
    zT_114.typereg = typereg;
    zT_114.symbol_reg = symbol_reg;
    zT_114.interner = interner;
    zT_115 = mods.ptr;
    zT_116 = zT_115[mi];
    zT_117 = zT_116.id;
    zT_114.module_id = zT_117;
    zT_118 = mods.ptr;
    zT_119 = zT_118[mi];
    zT_120 = zT_119.source_file_id;
    zT_114.source_file_id = zT_120;
    zT_121.has_value = 1;
    zT_121.value = diag;
    zT_114.diag = zT_121;
    zT_122.has_value = 0;
    zT_114.local_consts = zT_122;
    zT_123.has_value = 0;
    zT_114.local_types = zT_123;
    env = zT_114;
    zT_125 = 0;
    zT_126 = (unsigned int)zT_125;
    count = zT_126;
    zT_128 = 0;
    zT_129 = (unsigned int)zT_128;
    fail_node = zT_129;
    zT_131 = 0;
    zT_132 = (unsigned int)zT_131;
    fail_kind = zT_132;
    zT_133 = &env;
    zT_134 = enum_node;
    zT_136 = ep.members_start;
    zT_139 = &count;
    zT_140 = &fail_node;
    zT_141 = &fail_kind;
    zT_150 = zF_0FFDEDBD_enumMembersResolve(zT_133, zT_134, (unsigned char)(0), zT_136, (unsigned char)(1), (unsigned char)(0), zT_139, zT_140, zT_141);
    if ((unsigned char)(!zT_150)) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_152 = diag;
    zT_153 = store;
    zT_157 = mods.ptr;
    zT_158 = zT_157[mi];
    zT_154 = zT_158.source_file_id;
    zT_155 = fail_node;
    zT_156 = fail_kind;
    zF_52B56F5B_reportEnumWalkFailu(zT_152, zT_153, zT_154, zT_155, zT_156);
    goto z_bb_34;
    z_bb_34:
    goto z_bb_10;
}

/* containerAnonNameId */
unsigned int zF_27A59B24_containerAnonNameId(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    zT_5826BFC7_Arr_unsigned_char_1 zT_3;
    unsigned int zT_5;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_6;
    int zT_9;
    unsigned char* zT_10;
    unsigned int zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13 = 0;
    unsigned int zT_17;
    zT_4428DEE2_Arr_unsigned_char_2 zT_19;
    unsigned char zT_20;
    int zT_21;
    unsigned char zT_22;
    int zT_23;
    unsigned char zT_24;
    int zT_25;
    unsigned char zT_26;
    int zT_27;
    unsigned char zT_28;
    int zT_29;
    int zT_31;
    unsigned int zT_32;
    unsigned int zT_35;
    unsigned char zT_36;
    unsigned int zT_38;
    int zT_39;
    unsigned int zT_41;
    unsigned int zT_45;
    zT_D3EB6303_StringInterner* zT_46;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_47;
    int zT_51;
    unsigned char* zT_52;
    unsigned int zT_53;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_54;
    unsigned int zT_55 = 0;
    zT_5826BFC7_Arr_unsigned_char_1 idb;
    unsigned int idl;
    unsigned int ids;
    zT_4428DEE2_Arr_unsigned_char_2 nm;
    unsigned int di;
    unsigned int namelen;
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_3[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        idb[_i] = zT_3[_i];
        _i++;
    }
}
    zT_5 = node_idx;
    zT_9 = 0;
    zT_10 = (unsigned char*)((unsigned char*)idb) + zT_9;
    zT_11 = (unsigned int)(12) - zT_9;
    zT_12.ptr = zT_10;
    zT_12.len = zT_11;
    zT_6 = zT_12;
    zT_13 = zF_A7504564_itoa(zT_5, zT_6);
    idl = zT_13;
    zT_17 = (unsigned int)(11) - (unsigned int)((unsigned int)idl);
    ids = zT_17;
    {
    unsigned int _i = 0;
    while (_i < 24) {
        zT_19[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 24) {
        nm[_i] = zT_19[_i];
        _i++;
    }
}
    zT_20 = 97;
    zT_21 = 0;
    nm[zT_21] = zT_20;
    zT_22 = 110;
    zT_23 = 1;
    nm[zT_23] = zT_22;
    zT_24 = 111;
    zT_25 = 2;
    nm[zT_25] = zT_24;
    zT_26 = 110;
    zT_27 = 3;
    nm[zT_27] = zT_26;
    zT_28 = 95;
    zT_29 = 4;
    nm[zT_29] = zT_28;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    di = zT_32;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(di < (unsigned int)((unsigned int)idl))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_35 = ids + di;
    zT_36 = idb[zT_35];
    zT_38 = (unsigned int)(5) + di;
    nm[zT_38] = zT_36;
    goto z_bb_4;
    z_bb_3:
    zT_45 = (unsigned int)(5) + (unsigned int)((unsigned int)idl);
    namelen = zT_45;
    zT_46 = env->interner;
    zT_51 = 0;
    zT_52 = (unsigned char*)((unsigned char*)nm) + zT_51;
    zT_53 = namelen - zT_51;
    zT_54.ptr = zT_52;
    zT_54.len = zT_53;
    zT_47 = zT_54;
    zT_55 = zF_50C274AF_stringInternerInter(zT_46, zT_47);
    return zT_55;
    z_bb_4:
    zT_39 = 1;
    zT_41 = di + (unsigned int)((unsigned int)zT_39);
    di = zT_41;
    goto z_bb_1;
}

/* isContainerDeclKind */
unsigned char zF_82C2F046_isContainerDeclKind(zT_8143F551_AstKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    return zT_12;
}

/* isCompoundTypeExprKind */
unsigned char zF_599C0D79_isCompoundTypeExprK(zT_8143F551_AstKind kind) {
    unsigned char zT_4;
    unsigned char zT_8;
    unsigned char zT_12;
    unsigned char zT_16;
    unsigned char zT_20;
    unsigned char zT_24;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_4 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_3;
    z_bb_2:
    zT_4 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_4) goto z_bb_5; else goto z_bb_4;
    z_bb_4:
    zT_8 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_6;
    z_bb_5:
    zT_8 = 1;
    goto z_bb_6;
    z_bb_6:
    if (zT_8) goto z_bb_8; else goto z_bb_7;
    z_bb_7:
    zT_12 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_9;
    z_bb_8:
    zT_12 = 1;
    goto z_bb_9;
    z_bb_9:
    if (zT_12) goto z_bb_11; else goto z_bb_10;
    z_bb_10:
    zT_16 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_12;
    z_bb_11:
    zT_16 = 1;
    goto z_bb_12;
    z_bb_12:
    if (zT_16) goto z_bb_14; else goto z_bb_13;
    z_bb_13:
    zT_20 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type);
    goto z_bb_15;
    z_bb_14:
    zT_20 = 1;
    goto z_bb_15;
    z_bb_15:
    if (zT_20) goto z_bb_17; else goto z_bb_16;
    z_bb_16:
    zT_24 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type);
    goto z_bb_18;
    z_bb_17:
    zT_24 = 1;
    goto z_bb_18;
    z_bb_18:
    return zT_24;
}

/* containerFieldCount */
unsigned int zF_3B3163AB_containerFieldCount(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx) {
    int zT_3;
    unsigned int zT_4;
    zT_6B0A7D14_AstStore* zT_6;
    unsigned int zT_7;
    unsigned int zT_9 = 0;
    int zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    unsigned int zT_21 = 0;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_25 = {0};
    zT_8143F551_AstKind zT_26;
    int zT_30;
    unsigned int zT_32;
    int zT_33;
    unsigned int zT_35;
    unsigned int count;
    unsigned int children_n;
    unsigned int i;
    unsigned int child;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    count = zT_4;
    zT_6 = env->store;
    zT_7 = node_idx;
    zT_9 = zF_152E19CB_astStoreNodeExtraCh(zT_6, zT_7);
    children_n = zT_9;
    zT_11 = 0;
    zT_12 = (unsigned int)zT_11;
    i = zT_12;
    goto z_bb_1;
    z_bb_1:
    if ((unsigned char)(i < (unsigned int)((unsigned int)children_n))) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_16 = env->store;
    zT_17 = node_idx;
    zT_21 = zF_B10B1BC1_astStoreNodeExtraCh(zT_16, zT_17, (unsigned int)((unsigned int)i));
    child = zT_21;
    zT_22 = env->store;
    zT_23 = child;
    zT_25 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_26 = zT_25.kind;
    if ((unsigned char)(zT_26 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return count;
    z_bb_4:
    zT_33 = 1;
    zT_35 = i + (unsigned int)((unsigned int)zT_33);
    i = zT_35;
    goto z_bb_1;
    z_bb_5:
    zT_30 = 1;
    zT_32 = count + (unsigned int)((unsigned int)zT_30);
    count = zT_32;
    goto z_bb_6;
    z_bb_6:
    goto z_bb_4;
}

/* tupleElemArrayUnsupported */
unsigned char zF_E2A017C6_tupleElemArrayUnsup(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int elem_tid, unsigned int mark_node) {
    unsigned char zT_5;
    zT_338B7C76_TypeRegistry* zT_10;
    unsigned int zT_11;
    zT_338B7C76_TypeRegistry* zT_14;
    zT_D155D06D_Type* zT_15;
    unsigned int zT_16;
    zT_D155D06D_Type zT_17;
    zT_33EF6BFB_TypeKind zT_18;
    zT_6F32B01B_Opt_235 zT_23;
    unsigned char zT_24;
    zT_F85C5DED_DiagnosticCollector* zT_26;
    unsigned int zT_27;
    unsigned char zT_28 = 0;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    zT_22A7C88B_AstNode zT_33 = {0};
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_F85C5DED_DiagnosticCollector* zT_38;
    unsigned int zT_41;
    unsigned int zT_42;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_44;
    unsigned int zT_49;
    unsigned int zT_50;
    unsigned int zT_53 = 0;
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u msg;
    if ((unsigned char)(elem_tid == (unsigned int)(18))) goto z_bb_2; else goto z_bb_1;
    z_bb_1:
    zT_5 = elem_tid == (unsigned int)(1);
    goto z_bb_3;
    z_bb_2:
    zT_5 = 1;
    goto z_bb_3;
    z_bb_3:
    if (zT_5) goto z_bb_4; else goto z_bb_5;
    z_bb_4:
    return (unsigned char)(0);
    z_bb_5:
    zT_10 = env->typereg;
    zT_11 = zT_10->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)elem_tid) >= zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_14 = env->typereg;
    zT_15 = zT_14->types_items;
    zT_16 = (unsigned int)elem_tid;
    zT_17 = zT_15[zT_16];
    zT_18 = zT_17.kind;
    if ((unsigned char)(zT_18 != (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_array_type))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    return (unsigned char)(0);
    z_bb_9:
    zT_23 = env->diag;
    zT_24 = zT_23.has_value;
    if (zT_24) goto z_bb_10; else goto z_bb_11;
    z_bb_10:
    diag = zT_23.value;
    zT_26 = diag;
    zT_27 = mark_node;
    zT_28 = zF_4DD9DB2D_diagnosticCollector(zT_26, zT_27);
    if (zT_28) goto z_bb_12; else goto z_bb_13;
    z_bb_11:
    return (unsigned char)(1);
    z_bb_12:
    zT_30 = env->store;
    zT_31 = mark_node;
    zT_33 = zF_FCDD1D35_astStoreNodeAt(zT_30, zT_31);
    node = zT_33;
    zT_35 = "tuple types with array elements are not supported";
    zT_37 = 49;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    msg = zT_36;
    zT_38 = diag;
    zT_41 = env->source_file_id;
    zT_42 = node.span_start;
    zT_49 = node.span_start;
    zT_50 = node.span_len;
    zT_44 = msg;
    zT_53 = zF_C82559AC_diagnosticCollector(zT_38, (unsigned char)(0), (unsigned short)(3000), zT_41, zT_42, (unsigned int)(zT_49 + (unsigned int)((unsigned int)zT_50)), zT_44);
    (void)zT_53;
    goto z_bb_13;
    z_bb_13:
    goto z_bb_11;
}

/* validateLocalEnum */
void zF_9084D8CB_validateLocalEnum(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int enum_node) {
    zT_6F32B01B_Opt_235 zT_5;
    unsigned char zT_6;
    zT_F85C5DED_DiagnosticCollector* zT_7;
    zT_F85C5DED_DiagnosticCollector* zT_9;
    unsigned int zT_10;
    unsigned char zT_11 = 0;
    int zT_14;
    unsigned int zT_15;
    int zT_17;
    unsigned int zT_18;
    int zT_20;
    unsigned int zT_21;
    zT_ABC1EBBE_TypeResolveEnv* zT_22;
    unsigned int zT_23;
    unsigned int* zT_28;
    unsigned int* zT_29;
    unsigned int* zT_30;
    unsigned char zT_38 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_40;
    zT_6B0A7D14_AstStore* zT_41;
    unsigned int zT_42;
    unsigned int zT_43;
    unsigned int zT_44;
    zT_F85C5DED_DiagnosticCollector* diag;
    unsigned int count;
    unsigned int fail_node;
    unsigned int fail_kind;
    if ((unsigned char)(enum_node == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    zT_5 = env->diag;
    zT_6 = zT_5.has_value;
    if (zT_6) goto z_bb_4; else goto z_bb_3;
    z_bb_3:
    return;
    z_bb_4:
    zT_7 = zT_5.value;
    goto z_bb_5;
    z_bb_5:
    diag = zT_7;
    zT_9 = diag;
    zT_10 = enum_node;
    zT_11 = zF_4DD9DB2D_diagnosticCollector(zT_9, zT_10);
    if ((unsigned char)(!zT_11)) goto z_bb_6; else goto z_bb_7;
    z_bb_6:
    return;
    z_bb_7:
    zT_14 = 0;
    zT_15 = (unsigned int)zT_14;
    count = zT_15;
    zT_17 = 0;
    zT_18 = (unsigned int)zT_17;
    fail_node = zT_18;
    zT_20 = 0;
    zT_21 = (unsigned int)zT_20;
    fail_kind = zT_21;
    zT_22 = env;
    zT_23 = enum_node;
    zT_28 = &count;
    zT_29 = &fail_node;
    zT_30 = &fail_kind;
    zT_38 = zF_0FFDEDBD_enumMembersResolve(zT_22, zT_23, (unsigned char)(0), (unsigned int)(0), (unsigned char)(1), (unsigned char)(1), zT_28, zT_29, zT_30);
    if ((unsigned char)(!zT_38)) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_40 = diag;
    zT_41 = env->store;
    zT_42 = env->source_file_id;
    zT_43 = fail_node;
    zT_44 = fail_kind;
    zF_52B56F5B_reportEnumWalkFailu(zT_40, zT_41, zT_42, zT_43, zT_44);
    goto z_bb_9;
    z_bb_9:
    return;
}

/* registerContainerType */
unsigned int zF_FE81311F_registerContainerTy(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, zT_8143F551_AstKind kind, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_5;
    unsigned int zT_6;
    zT_22A7C88B_AstNode zT_8 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_12;
    unsigned int zT_13;
    zT_ABC1EBBE_TypeResolveEnv* zT_15;
    unsigned int zT_16;
    unsigned int zT_17 = 0;
    zT_338B7C76_TypeRegistry* zT_19;
    zT_BAEE192E_Opt_10 zT_23 = {0};
    unsigned char zT_24;
    unsigned char zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_36 = 0;
    unsigned char zT_39;
    zT_ABC1EBBE_TypeResolveEnv* zT_40;
    unsigned int zT_41;
    unsigned int zT_42 = 0;
    zT_6F32B01B_Opt_235 zT_45;
    unsigned char zT_46;
    unsigned char* zT_49;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_50;
    unsigned int zT_51;
    zT_F85C5DED_DiagnosticCollector* zT_52;
    unsigned int zT_55;
    unsigned int zT_56;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_58;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_67 = 0;
    zT_33EF6BFB_TypeKind zT_70;
    unsigned char zT_71;
    int zT_75;
    zT_33EF6BFB_TypeKind zT_77;
    unsigned char zT_84;
    int zT_88;
    zT_33EF6BFB_TypeKind zT_90;
    unsigned char zT_93;
    int zT_95;
    int zT_97;
    zT_33EF6BFB_TypeKind zT_99;
    zT_338B7C76_TypeRegistry* zT_109;
    unsigned int zT_111;
    zT_33EF6BFB_TypeKind zT_112;
    unsigned int zT_115 = 0;
    unsigned char zT_119;
    unsigned char zT_123;
    unsigned char zT_124;
    zT_338B7C76_TypeRegistry* zT_130;
    unsigned int zT_131;
    unsigned char zT_136;
    unsigned char zT_137;
    int zT_141;
    zT_6B0A7D14_AstStore* zT_143;
    unsigned int zT_144;
    unsigned int zT_146 = 0;
    zT_6B0A7D14_AstStore* zT_150;
    unsigned int zT_151;
    unsigned int zT_153 = 0;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_155;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_157;
    int zT_159;
    unsigned int zT_160;
    int zT_162;
    unsigned int zT_163;
    unsigned char zT_166;
    zT_6B0A7D14_AstStore* zT_170;
    unsigned int zT_171;
    unsigned int zT_175 = 0;
    zT_6B0A7D14_AstStore* zT_177;
    unsigned int zT_178;
    zT_22A7C88B_AstNode zT_180 = {0};
    zT_8143F551_AstKind zT_181;
    zT_ABC1EBBE_TypeResolveEnv* zT_185;
    unsigned int zT_186;
    unsigned int zT_191 = 0;
    int zT_192;
    unsigned int zT_194;
    int zT_195;
    unsigned int zT_197;
    zT_338B7C76_TypeRegistry* zT_201;
    unsigned int zT_202;
    unsigned int zT_203;
    int zT_205;
    unsigned int zT_206;
    zT_ABC1EBBE_TypeResolveEnv* zT_208;
    unsigned int zT_209;
    unsigned int zT_210;
    unsigned char zT_213 = 0;
    zT_338B7C76_TypeRegistry* zT_214;
    unsigned int zT_215;
    int zT_218;
    unsigned int zT_220;
    zT_338B7C76_TypeRegistry* zT_221;
    zT_666DC2E1_TuplePayload zT_222;
    zT_666DC2E1_TuplePayload zT_224;
    unsigned int zT_225;
    unsigned short zT_226;
    zT_338B7C76_TypeRegistry* zT_228;
    unsigned int zT_229;
    unsigned int zT_232;
    zT_338B7C76_TypeRegistry* zT_234;
    zT_D155D06D_Type* zT_235;
    unsigned int zT_236;
    zT_D155D06D_Type zT_237;
    zT_338B7C76_TypeRegistry* zT_238;
    zT_D155D06D_Type* zT_239;
    unsigned int zT_240;
    zT_6B0A7D14_AstStore* zT_244;
    unsigned int zT_245;
    unsigned int zT_247 = 0;
    zT_6B0A7D14_AstStore* zT_251;
    unsigned int zT_252;
    unsigned int zT_254 = 0;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_256;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_258;
    int zT_260;
    unsigned int zT_261;
    int zT_263;
    unsigned int zT_264;
    unsigned char zT_267;
    zT_6B0A7D14_AstStore* zT_271;
    unsigned int zT_272;
    unsigned int zT_276 = 0;
    zT_6B0A7D14_AstStore* zT_278;
    unsigned int zT_279;
    zT_22A7C88B_AstNode zT_281 = {0};
    zT_8143F551_AstKind zT_282;
    zT_ABC1EBBE_TypeResolveEnv* zT_286;
    unsigned int zT_287;
    unsigned int zT_292 = 0;
    zT_6B0A7D14_AstStore* zT_293;
    unsigned int zT_294;
    unsigned int zT_296 = 0;
    int zT_297;
    unsigned int zT_299;
    int zT_300;
    unsigned int zT_302;
    zT_338B7C76_TypeRegistry* zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    int zT_310;
    unsigned int zT_311;
    zT_338B7C76_TypeRegistry* zT_313;
    zT_2DF01B61_FieldEntry zT_314;
    zT_2DF01B61_FieldEntry zT_316;
    unsigned int zT_317;
    unsigned int zT_318;
    unsigned int zT_319;
    int zT_320;
    unsigned int zT_322;
    zT_338B7C76_TypeRegistry* zT_323;
    zT_406493CE_StructPayload zT_324;
    zT_406493CE_StructPayload zT_326;
    unsigned int zT_327;
    unsigned short zT_328;
    zT_338B7C76_TypeRegistry* zT_330;
    unsigned int zT_331;
    unsigned int zT_334;
    zT_338B7C76_TypeRegistry* zT_336;
    zT_D155D06D_Type* zT_337;
    unsigned int zT_338;
    zT_D155D06D_Type zT_339;
    zT_338B7C76_TypeRegistry* zT_340;
    zT_D155D06D_Type* zT_341;
    unsigned int zT_342;
    zT_6B0A7D14_AstStore* zT_346;
    unsigned int zT_347;
    unsigned int zT_349 = 0;
    zT_6B0A7D14_AstStore* zT_353;
    unsigned int zT_354;
    unsigned int zT_356 = 0;
    int zT_357;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_360;
    zT_9D2DA37C_Arr_unsigned_int_32 zT_362;
    int zT_364;
    unsigned int zT_365;
    int zT_367;
    unsigned int zT_368;
    unsigned char zT_371;
    zT_6B0A7D14_AstStore* zT_375;
    unsigned int zT_376;
    unsigned int zT_380 = 0;
    zT_6B0A7D14_AstStore* zT_382;
    unsigned int zT_383;
    zT_22A7C88B_AstNode zT_385 = {0};
    zT_8143F551_AstKind zT_386;
    zT_ABC1EBBE_TypeResolveEnv* zT_390;
    unsigned int zT_391;
    unsigned int zT_396 = 0;
    zT_6B0A7D14_AstStore* zT_397;
    unsigned int zT_398;
    unsigned int zT_400 = 0;
    int zT_401;
    unsigned int zT_403;
    int zT_404;
    unsigned int zT_406;
    zT_338B7C76_TypeRegistry* zT_408;
    unsigned int zT_409;
    unsigned int zT_410;
    int zT_412;
    unsigned int zT_413;
    zT_338B7C76_TypeRegistry* zT_415;
    zT_2DF01B61_FieldEntry zT_416;
    zT_2DF01B61_FieldEntry zT_418;
    unsigned int zT_419;
    unsigned int zT_420;
    unsigned int zT_421;
    int zT_422;
    unsigned int zT_424;
    unsigned char zT_425;
    int zT_427;
    int zT_429;
    zT_338B7C76_TypeRegistry* zT_431;
    zT_54FF90FA_TaggedUnionPayload zT_432;
    zT_54FF90FA_TaggedUnionPayload zT_434;
    unsigned int zT_435;
    unsigned int zT_436;
    unsigned short zT_437;
    zT_338B7C76_TypeRegistry* zT_439;
    unsigned int zT_440;
    unsigned int zT_443;
    zT_338B7C76_TypeRegistry* zT_445;
    zT_D155D06D_Type* zT_446;
    unsigned int zT_447;
    zT_D155D06D_Type zT_448;
    zT_338B7C76_TypeRegistry* zT_449;
    zT_D155D06D_Type* zT_450;
    unsigned int zT_451;
    zT_338B7C76_TypeRegistry* zT_452;
    zT_AF9231A2_UnionPayload zT_453;
    zT_AF9231A2_UnionPayload zT_455;
    unsigned int zT_456;
    unsigned short zT_457;
    unsigned int zT_458;
    zT_338B7C76_TypeRegistry* zT_460;
    unsigned int zT_461;
    unsigned int zT_464;
    zT_338B7C76_TypeRegistry* zT_466;
    zT_D155D06D_Type* zT_467;
    unsigned int zT_468;
    zT_D155D06D_Type zT_469;
    zT_338B7C76_TypeRegistry* zT_470;
    zT_D155D06D_Type* zT_471;
    unsigned int zT_472;
    zT_338B7C76_TypeRegistry* zT_473;
    zT_6B0A7D14_AstStore* zT_474;
    zT_8143F551_AstKind zT_475;
    unsigned int zT_476;
    unsigned int zT_477;
    zT_3D7259E2_SymbolRegistry* zT_478;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_BAEE192E_Opt_10 existing;
    unsigned int e;
    zT_33EF6BFB_TypeKind type_kind;
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_8F083A69_Slice_zT_0B42B2F8_u fc_msg;
    unsigned int tid;
    unsigned int tup_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 tup_ety;
    zT_9D2DA37C_Arr_unsigned_int_32 tup_enode;
    unsigned int tup_ec;
    unsigned int tup_i;
    unsigned int tup_child;
    zT_22A7C88B_AstNode tup_fd;
    unsigned int tup_estart;
    unsigned int tup_j;
    unsigned int tup_tidx;
    zT_D155D06D_Type tup_ty;
    unsigned int sd_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 sd_fnm;
    unsigned int sd_fc;
    unsigned int sd_i;
    unsigned int sd_child;
    zT_22A7C88B_AstNode sd_fd;
    unsigned int sd_fstart;
    unsigned int sd_j;
    unsigned int sd_st_idx;
    zT_D155D06D_Type sd_ty;
    unsigned int un_children_n;
    zT_9D2DA37C_Arr_unsigned_int_32 un_fty;
    zT_9D2DA37C_Arr_unsigned_int_32 un_fnm;
    unsigned int un_fc;
    unsigned int un_i;
    unsigned int un_child;
    zT_22A7C88B_AstNode un_fd;
    unsigned int un_fstart;
    unsigned int un_j;
    unsigned int un_tu_idx;
    zT_D155D06D_Type un_tu_ty;
    unsigned int un_un_idx;
    zT_D155D06D_Type un_un_ty;
    zT_5 = env->store;
    zT_6 = node_idx;
    zT_8 = zF_FCDD1D35_astStoreNodeAt(zT_5, zT_6);
    node = zT_8;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    zT_12 = env;
    zT_13 = node_idx;
    zF_9084D8CB_validateLocalEnum(zT_12, zT_13);
    goto z_bb_2;
    z_bb_2:
    zT_15 = env;
    zT_16 = node_idx;
    zT_17 = zF_27A59B24_containerAnonNameId(zT_15, zT_16);
    name_id = zT_17;
    zT_19 = env->typereg;
    zT_23 = zF_0EB68360_nameCacheGet(zT_19, (zT_79FAE712_u64)((zT_79FAE712_u64)name_id));
    existing = zT_23;
    zT_24 = existing.has_value;
    if (zT_24) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    e = existing.value;
    return e;
    z_bb_4:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    zT_29 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_7;
    z_bb_6:
    zT_29 = 1;
    goto z_bb_7;
    z_bb_7:
    if (zT_29) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = node_idx;
    zT_36 = zF_8BA26B9E_astStoreNodePayload(zT_33, zT_34);
    if ((unsigned char)(zT_36 != (unsigned int)(0))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
switch (kind) {
case 3: goto z_bb_17;
case 4: goto z_bb_18;
case 5: goto z_bb_19;
case 9: goto z_bb_20;
default: goto z_bb_21;
}
    z_bb_10:
    zT_40 = env;
    zT_41 = node_idx;
    zT_42 = zF_3B3163AB_containerFieldCount(zT_40, zT_41);
    zT_39 = zT_42 > (unsigned int)(32);
    goto z_bb_12;
    z_bb_11:
    zT_39 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_39) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_45 = env->diag;
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    diag = zT_45.value;
    zT_49 = "aggregate type has more than 32 fields, which is not supported";
    zT_51 = 62;
    zT_50.ptr = zT_49;
    zT_50.len = zT_51;
    fc_msg = zT_50;
    zT_52 = diag;
    zT_55 = env->source_file_id;
    zT_56 = node.span_start;
    zT_63 = node.span_start;
    zT_64 = node.span_len;
    zT_58 = fc_msg;
    zT_67 = zF_C82559AC_diagnosticCollector(zT_52, (unsigned char)(0), (unsigned short)(3000), zT_55, zT_56, (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64)), zT_58);
    (void)zT_67;
    goto z_bb_16;
    z_bb_16:
    return (unsigned int)(18);
    z_bb_17:
    zT_71 = node.flags;
    zT_75 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_71) & (unsigned short)(32)) != zT_75)) goto z_bb_24; else goto z_bb_25;
    z_bb_18:
    zT_70 = zT_33EF6BFB_TypeKind_enum_type;
    goto z_bb_23;
    z_bb_19:
    zT_84 = node.flags;
    zT_88 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_84) & (unsigned short)(16)) != zT_88)) goto z_bb_27; else goto z_bb_28;
    z_bb_20:
    zT_70 = zT_33EF6BFB_TypeKind_error_set_type;
    goto z_bb_23;
    z_bb_21:
    zT_70 = zT_33EF6BFB_TypeKind_void_type;
    goto z_bb_23;
    z_bb_23:
    type_kind = zT_70;
    zT_109 = env->typereg;
    zT_111 = name_id;
    zT_112 = type_kind;
    zT_115 = zF_3A64E2E0_typeRegistryRegiste(zT_109, (unsigned int)(0), zT_111, zT_112);
    tid = zT_115;
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_34; else goto z_bb_33;
    z_bb_24:
    zT_77 = zT_33EF6BFB_TypeKind_tuple_type;
    goto z_bb_26;
    z_bb_25:
    zT_77 = zT_33EF6BFB_TypeKind_struct_type;
    goto z_bb_26;
    z_bb_26:
    zT_70 = zT_77;
    goto z_bb_23;
    z_bb_27:
    zT_90 = zT_33EF6BFB_TypeKind_packed_union_type;
    goto z_bb_29;
    z_bb_28:
    zT_93 = node.flags;
    zT_95 = 1;
    zT_97 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_93) & zT_95) != zT_97)) goto z_bb_30; else goto z_bb_31;
    z_bb_29:
    zT_70 = zT_90;
    goto z_bb_23;
    z_bb_30:
    zT_99 = zT_33EF6BFB_TypeKind_tagged_union_type;
    goto z_bb_32;
    z_bb_31:
    zT_99 = zT_33EF6BFB_TypeKind_union_type;
    goto z_bb_32;
    z_bb_32:
    zT_90 = zT_99;
    goto z_bb_29;
    z_bb_33:
    zT_119 = kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_35;
    z_bb_34:
    zT_119 = 1;
    goto z_bb_35;
    z_bb_35:
    if (zT_119) goto z_bb_36; else goto z_bb_37;
    z_bb_36:
    zT_124 = node.flags;
    zT_123 = (unsigned short)((unsigned short)((unsigned short)zT_124) & (unsigned short)(16)) != (unsigned short)(0);
    goto z_bb_38;
    z_bb_37:
    zT_123 = 0;
    goto z_bb_38;
    z_bb_38:
    if (zT_123) goto z_bb_39; else goto z_bb_40;
    z_bb_39:
    zT_130 = env->typereg;
    zT_131 = tid;
    zF_52816016_typeRegistrySetPack(zT_130, zT_131);
    goto z_bb_40;
    z_bb_40:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_137 = node.flags;
    zT_141 = 0;
    zT_136 = (unsigned short)((unsigned short)((unsigned short)zT_137) & (unsigned short)(32)) != zT_141;
    goto z_bb_43;
    z_bb_42:
    zT_136 = 0;
    goto z_bb_43;
    z_bb_43:
    if (zT_136) goto z_bb_44; else goto z_bb_46;
    z_bb_44:
    zT_143 = env->store;
    zT_144 = node_idx;
    zT_146 = zF_8BA26B9E_astStoreNodePayload(zT_143, zT_144);
    if ((unsigned char)(zT_146 != (unsigned int)(0))) goto z_bb_47; else goto z_bb_48;
    z_bb_45:
    return tid;
    z_bb_46:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_64; else goto z_bb_66;
    z_bb_47:
    zT_150 = env->store;
    zT_151 = node_idx;
    zT_153 = zF_152E19CB_astStoreNodeExtraCh(zT_150, zT_151);
    tup_children_n = zT_153;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_155[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        tup_ety[_i] = zT_155[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_157[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        tup_enode[_i] = zT_157[_i];
        _i++;
    }
}
    zT_159 = 0;
    zT_160 = (unsigned int)zT_159;
    tup_ec = zT_160;
    zT_162 = 0;
    zT_163 = (unsigned int)zT_162;
    tup_i = zT_163;
    goto z_bb_49;
    z_bb_48:
    goto z_bb_45;
    z_bb_49:
    if ((unsigned char)(tup_i < (unsigned int)((unsigned int)tup_children_n))) goto z_bb_53; else goto z_bb_54;
    z_bb_50:
    zT_170 = env->store;
    zT_171 = node_idx;
    zT_175 = zF_B10B1BC1_astStoreNodeExtraCh(zT_170, zT_171, (unsigned int)((unsigned int)tup_i));
    tup_child = zT_175;
    zT_177 = env->store;
    zT_178 = tup_child;
    zT_180 = zF_FCDD1D35_astStoreNodeAt(zT_177, zT_178);
    tup_fd = zT_180;
    zT_181 = tup_fd.kind;
    if ((unsigned char)(zT_181 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_56; else goto z_bb_57;
    z_bb_51:
    if ((unsigned char)(tup_ec > (unsigned int)(0))) goto z_bb_58; else goto z_bb_59;
    z_bb_52:
    zT_195 = 1;
    zT_197 = tup_i + (unsigned int)((unsigned int)zT_195);
    tup_i = zT_197;
    goto z_bb_49;
    z_bb_53:
    zT_166 = tup_ec < (unsigned int)(32);
    goto z_bb_55;
    z_bb_54:
    zT_166 = 0;
    goto z_bb_55;
    z_bb_55:
    if (zT_166) goto z_bb_50; else goto z_bb_51;
    z_bb_56:
    zT_185 = env;
    zT_186 = tup_fd.child_0;
    zT_191 = zF_F2107C15_resolveTypeExprFull(zT_185, zT_186, (unsigned int)(depth + (unsigned int)(1)));
    tup_ety[tup_ec] = zT_191;
    tup_enode[tup_ec] = tup_child;
    zT_192 = 1;
    zT_194 = tup_ec + (unsigned int)((unsigned int)zT_192);
    tup_ec = zT_194;
    goto z_bb_57;
    z_bb_57:
    goto z_bb_52;
    z_bb_58:
    zT_201 = env->typereg;
    zT_202 = zT_201->xt_len;
    zT_203 = (unsigned int)zT_202;
    tup_estart = zT_203;
    zT_205 = 0;
    zT_206 = (unsigned int)zT_205;
    tup_j = zT_206;
    goto z_bb_60;
    z_bb_59:
    goto z_bb_48;
    z_bb_60:
    if ((unsigned char)(tup_j < tup_ec)) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_208 = env;
    zT_209 = tup_ety[tup_j];
    zT_210 = tup_enode[tup_j];
    zT_213 = zF_E2A017C6_tupleElemArrayUnsup(zT_208, zT_209, zT_210);
    (void)zT_213;
    zT_214 = env->typereg;
    zT_215 = tup_ety[tup_j];
    zF_4C03AE3D_xtAppend(zT_214, zT_215);
    goto z_bb_63;
    z_bb_62:
    zT_221 = env->typereg;
    zT_225 = (unsigned int)tup_estart;
    zT_224.elems_start = zT_225;
    zT_226 = (unsigned short)tup_ec;
    zT_224.elems_count = zT_226;
    zT_222 = zT_224;
    zF_C94DF842_tupAppend(zT_221, zT_222);
    zT_228 = env->typereg;
    zT_229 = zT_228->tup_len;
    zT_232 = (unsigned int)(unsigned int)(zT_229 - (unsigned int)(1));
    tup_tidx = zT_232;
    zT_234 = env->typereg;
    zT_235 = zT_234->types_items;
    zT_236 = (unsigned int)tid;
    zT_237 = zT_235[zT_236];
    tup_ty = zT_237;
    tup_ty.payload_idx = tup_tidx;
    zT_238 = env->typereg;
    zT_239 = zT_238->types_items;
    zT_240 = (unsigned int)tid;
    zT_239[zT_240] = tup_ty;
    goto z_bb_59;
    z_bb_63:
    zT_218 = 1;
    zT_220 = tup_j + (unsigned int)((unsigned int)zT_218);
    tup_j = zT_220;
    goto z_bb_60;
    z_bb_64:
    zT_244 = env->store;
    zT_245 = node_idx;
    zT_247 = zF_8BA26B9E_astStoreNodePayload(zT_244, zT_245);
    if ((unsigned char)(zT_247 != (unsigned int)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_65:
    goto z_bb_45;
    z_bb_66:
    if ((unsigned char)(kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_84; else goto z_bb_86;
    z_bb_67:
    zT_251 = env->store;
    zT_252 = node_idx;
    zT_254 = zF_152E19CB_astStoreNodeExtraCh(zT_251, zT_252);
    sd_children_n = zT_254;
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_256[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fty[_i] = zT_256[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_258[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        sd_fnm[_i] = zT_258[_i];
        _i++;
    }
}
    zT_260 = 0;
    zT_261 = (unsigned int)zT_260;
    sd_fc = zT_261;
    zT_263 = 0;
    zT_264 = (unsigned int)zT_263;
    sd_i = zT_264;
    goto z_bb_69;
    z_bb_68:
    goto z_bb_65;
    z_bb_69:
    if ((unsigned char)(sd_i < (unsigned int)((unsigned int)sd_children_n))) goto z_bb_73; else goto z_bb_74;
    z_bb_70:
    zT_271 = env->store;
    zT_272 = node_idx;
    zT_276 = zF_B10B1BC1_astStoreNodeExtraCh(zT_271, zT_272, (unsigned int)((unsigned int)sd_i));
    sd_child = zT_276;
    zT_278 = env->store;
    zT_279 = sd_child;
    zT_281 = zF_FCDD1D35_astStoreNodeAt(zT_278, zT_279);
    sd_fd = zT_281;
    zT_282 = sd_fd.kind;
    if ((unsigned char)(zT_282 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_76; else goto z_bb_77;
    z_bb_71:
    if ((unsigned char)(sd_fc > (unsigned int)(0))) goto z_bb_78; else goto z_bb_79;
    z_bb_72:
    zT_300 = 1;
    zT_302 = sd_i + (unsigned int)((unsigned int)zT_300);
    sd_i = zT_302;
    goto z_bb_69;
    z_bb_73:
    zT_267 = sd_fc < (unsigned int)(32);
    goto z_bb_75;
    z_bb_74:
    zT_267 = 0;
    goto z_bb_75;
    z_bb_75:
    if (zT_267) goto z_bb_70; else goto z_bb_71;
    z_bb_76:
    zT_286 = env;
    zT_287 = sd_fd.child_0;
    zT_292 = zF_F2107C15_resolveTypeExprFull(zT_286, zT_287, (unsigned int)(depth + (unsigned int)(1)));
    sd_fty[sd_fc] = zT_292;
    zT_293 = env->store;
    zT_294 = sd_child;
    zT_296 = zF_8BA26B9E_astStoreNodePayload(zT_293, zT_294);
    sd_fnm[sd_fc] = zT_296;
    zT_297 = 1;
    zT_299 = sd_fc + (unsigned int)((unsigned int)zT_297);
    sd_fc = zT_299;
    goto z_bb_77;
    z_bb_77:
    goto z_bb_72;
    z_bb_78:
    zT_306 = env->typereg;
    zT_307 = zT_306->fe_len;
    zT_308 = (unsigned int)zT_307;
    sd_fstart = zT_308;
    zT_310 = 0;
    zT_311 = (unsigned int)zT_310;
    sd_j = zT_311;
    goto z_bb_80;
    z_bb_79:
    goto z_bb_68;
    z_bb_80:
    if ((unsigned char)(sd_j < sd_fc)) goto z_bb_81; else goto z_bb_82;
    z_bb_81:
    zT_313 = env->typereg;
    zT_317 = sd_fnm[sd_j];
    zT_316.name_id = zT_317;
    zT_318 = sd_fty[sd_j];
    zT_316.type_id = zT_318;
    zT_319 = 0;
    zT_316.offset = zT_319;
    zT_314 = zT_316;
    zF_701DF154_feAppend(zT_313, zT_314);
    goto z_bb_83;
    z_bb_82:
    zT_323 = env->typereg;
    zT_327 = (unsigned int)sd_fstart;
    zT_326.fields_start = zT_327;
    zT_328 = (unsigned short)sd_fc;
    zT_326.fields_count = zT_328;
    zT_324 = zT_326;
    zF_CF849366_stAppend(zT_323, zT_324);
    zT_330 = env->typereg;
    zT_331 = zT_330->st_len;
    zT_334 = (unsigned int)(unsigned int)(zT_331 - (unsigned int)(1));
    sd_st_idx = zT_334;
    zT_336 = env->typereg;
    zT_337 = zT_336->types_items;
    zT_338 = (unsigned int)tid;
    zT_339 = zT_337[zT_338];
    sd_ty = zT_339;
    sd_ty.payload_idx = sd_st_idx;
    zT_340 = env->typereg;
    zT_341 = zT_340->types_items;
    zT_342 = (unsigned int)tid;
    zT_341[zT_342] = sd_ty;
    goto z_bb_79;
    z_bb_83:
    zT_320 = 1;
    zT_322 = sd_j + (unsigned int)((unsigned int)zT_320);
    sd_j = zT_322;
    goto z_bb_80;
    z_bb_84:
    zT_346 = env->store;
    zT_347 = node_idx;
    zT_349 = zF_8BA26B9E_astStoreNodePayload(zT_346, zT_347);
    if ((unsigned char)(zT_349 != (unsigned int)(0))) goto z_bb_87; else goto z_bb_88;
    z_bb_85:
    goto z_bb_65;
    z_bb_86:
    zT_473 = env->typereg;
    zT_474 = env->store;
    zT_475 = kind;
    zT_476 = node_idx;
    zT_477 = tid;
    zT_478 = env->symbol_reg;
    zF_020995FB_populateTypePayload(zT_473, zT_474, zT_475, zT_476, zT_477, zT_478);
    goto z_bb_85;
    z_bb_87:
    zT_353 = env->store;
    zT_354 = node_idx;
    zT_356 = zF_152E19CB_astStoreNodeExtraCh(zT_353, zT_354);
    un_children_n = zT_356;
    zT_357 = 0;
    if ((unsigned char)(un_children_n != (unsigned int)zT_357)) goto z_bb_89; else goto z_bb_90;
    z_bb_88:
    goto z_bb_85;
    z_bb_89:
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_360[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        un_fty[_i] = zT_360[_i];
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        zT_362[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 32) {
        un_fnm[_i] = zT_362[_i];
        _i++;
    }
}
    zT_364 = 0;
    zT_365 = (unsigned int)zT_364;
    un_fc = zT_365;
    zT_367 = 0;
    zT_368 = (unsigned int)zT_367;
    un_i = zT_368;
    goto z_bb_91;
    z_bb_90:
    goto z_bb_88;
    z_bb_91:
    if ((unsigned char)(un_i < (unsigned int)((unsigned int)un_children_n))) goto z_bb_95; else goto z_bb_96;
    z_bb_92:
    zT_375 = env->store;
    zT_376 = node_idx;
    zT_380 = zF_B10B1BC1_astStoreNodeExtraCh(zT_375, zT_376, (unsigned int)((unsigned int)un_i));
    un_child = zT_380;
    zT_382 = env->store;
    zT_383 = un_child;
    zT_385 = zF_FCDD1D35_astStoreNodeAt(zT_382, zT_383);
    un_fd = zT_385;
    zT_386 = un_fd.kind;
    if ((unsigned char)(zT_386 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_98; else goto z_bb_99;
    z_bb_93:
    zT_408 = env->typereg;
    zT_409 = zT_408->fe_len;
    zT_410 = (unsigned int)zT_409;
    un_fstart = zT_410;
    zT_412 = 0;
    zT_413 = (unsigned int)zT_412;
    un_j = zT_413;
    goto z_bb_100;
    z_bb_94:
    zT_404 = 1;
    zT_406 = un_i + (unsigned int)((unsigned int)zT_404);
    un_i = zT_406;
    goto z_bb_91;
    z_bb_95:
    zT_371 = un_fc < (unsigned int)(32);
    goto z_bb_97;
    z_bb_96:
    zT_371 = 0;
    goto z_bb_97;
    z_bb_97:
    if (zT_371) goto z_bb_92; else goto z_bb_93;
    z_bb_98:
    zT_390 = env;
    zT_391 = un_fd.child_0;
    zT_396 = zF_F2107C15_resolveTypeExprFull(zT_390, zT_391, (unsigned int)(depth + (unsigned int)(1)));
    un_fty[un_fc] = zT_396;
    zT_397 = env->store;
    zT_398 = un_child;
    zT_400 = zF_8BA26B9E_astStoreNodePayload(zT_397, zT_398);
    un_fnm[un_fc] = zT_400;
    zT_401 = 1;
    zT_403 = un_fc + (unsigned int)((unsigned int)zT_401);
    un_fc = zT_403;
    goto z_bb_99;
    z_bb_99:
    goto z_bb_94;
    z_bb_100:
    if ((unsigned char)(un_j < un_fc)) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_415 = env->typereg;
    zT_419 = un_fnm[un_j];
    zT_418.name_id = zT_419;
    zT_420 = un_fty[un_j];
    zT_418.type_id = zT_420;
    zT_421 = 0;
    zT_418.offset = zT_421;
    zT_416 = zT_418;
    zF_701DF154_feAppend(zT_415, zT_416);
    goto z_bb_103;
    z_bb_102:
    zT_425 = node.flags;
    zT_427 = 1;
    zT_429 = 0;
    if ((unsigned char)((unsigned short)((unsigned short)((unsigned short)zT_425) & zT_427) != zT_429)) goto z_bb_104; else goto z_bb_106;
    z_bb_103:
    zT_422 = 1;
    zT_424 = un_j + (unsigned int)((unsigned int)zT_422);
    un_j = zT_424;
    goto z_bb_100;
    z_bb_104:
    zT_431 = env->typereg;
    zT_435 = 10;
    zT_434.tag_type = zT_435;
    zT_436 = (unsigned int)un_fstart;
    zT_434.fields_start = zT_436;
    zT_437 = (unsigned short)un_fc;
    zT_434.fields_count = zT_437;
    zT_432 = zT_434;
    zF_FB6B57C6_tuAppend(zT_431, zT_432);
    zT_439 = env->typereg;
    zT_440 = zT_439->tu_len;
    zT_443 = (unsigned int)(unsigned int)(zT_440 - (unsigned int)(1));
    un_tu_idx = zT_443;
    zT_445 = env->typereg;
    zT_446 = zT_445->types_items;
    zT_447 = (unsigned int)tid;
    zT_448 = zT_446[zT_447];
    un_tu_ty = zT_448;
    un_tu_ty.payload_idx = un_tu_idx;
    zT_449 = env->typereg;
    zT_450 = zT_449->types_items;
    zT_451 = (unsigned int)tid;
    zT_450[zT_451] = un_tu_ty;
    goto z_bb_105;
    z_bb_105:
    goto z_bb_90;
    z_bb_106:
    zT_452 = env->typereg;
    zT_456 = (unsigned int)un_fstart;
    zT_455.fields_start = zT_456;
    zT_457 = (unsigned short)un_fc;
    zT_455.fields_count = zT_457;
    zT_458 = 1;
    zT_455.tag_type = zT_458;
    zT_453 = zT_455;
    zF_1718422E_unAppend(zT_452, zT_453);
    zT_460 = env->typereg;
    zT_461 = zT_460->un_len;
    zT_464 = (unsigned int)(unsigned int)(zT_461 - (unsigned int)(1));
    un_un_idx = zT_464;
    zT_466 = env->typereg;
    zT_467 = zT_466->types_items;
    zT_468 = (unsigned int)tid;
    zT_469 = zT_467[zT_468];
    un_un_ty = zT_469;
    un_un_ty.payload_idx = un_un_idx;
    zT_470 = env->typereg;
    zT_471 = zT_470->types_items;
    zT_472 = (unsigned int)tid;
    zT_471[zT_472] = un_un_ty;
    goto z_bb_105;
}

/* typeResolverCheckMemberVisibility */
unsigned char zF_D43B245F_typeResolverCheckMe(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int name_id, zT_3A105EF1_Symbol* sym) {
    unsigned int zT_4;
    unsigned int zT_5;
    zT_3A105EF1_Symbol* zT_8;
    unsigned char zT_9 = 0;
    zT_6F32B01B_Opt_235 zT_11;
    unsigned char zT_12;
    zT_F85C5DED_DiagnosticCollector* zT_14;
    unsigned int zT_15;
    unsigned char zT_16 = 0;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    unsigned char* zT_22;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_23;
    unsigned int zT_24;
    zT_D3EB6303_StringInterner* zT_26;
    unsigned int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_29 = {0};
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_31;
    unsigned int zT_32;
    unsigned int zT_33;
    unsigned int zT_34;
    zT_D3EB6303_StringInterner* zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_37;
    int zT_40;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_41;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_43 = {0};
    zT_6B0A7D14_AstStore* zT_45;
    unsigned int zT_46;
    zT_22A7C88B_AstNode zT_48 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_50;
    unsigned int zT_53;
    unsigned int zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_56;
    unsigned int zT_63;
    unsigned int zT_64;
    unsigned int zT_67 = 0;
    unsigned int zT_68;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    zT_22A7C88B_AstNode zT_76 = {0};
    unsigned char* zT_78;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_79;
    unsigned int zT_80;
    zT_F85C5DED_DiagnosticCollector* zT_81;
    unsigned int zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_86;
    unsigned int zT_89;
    unsigned int zT_90;
    zT_F85C5DED_DiagnosticCollector* dc;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv1;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv2;
    zT_8F083A69_Slice_zT_0B42B2F8_u tvnm;
    zT_4C214FEE_Arr_zT_8F083A69_Sli tvparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u tvmsg;
    zT_22A7C88B_AstNode tvnode;
    unsigned int tv_di;
    zT_22A7C88B_AstNode tv_decl;
    zT_8F083A69_Slice_zT_0B42B2F8_u tv_note;
    zT_4 = sym->module_id;
    zT_5 = env->module_id;
    if ((unsigned char)(zT_4 == zT_5)) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(1);
    z_bb_2:
    zT_8 = sym;
    zT_9 = zF_C08C479C_symbolIsPublic(zT_8);
    if (zT_9) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(1);
    z_bb_4:
    zT_11 = env->diag;
    zT_12 = zT_11.has_value;
    if (zT_12) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    dc = zT_11.value;
    zT_14 = dc;
    zT_15 = node_idx;
    zT_16 = zF_4DD9DB2D_diagnosticCollector(zT_14, zT_15);
    if (zT_16) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    return (unsigned char)(0);
    z_bb_7:
    zT_18 = "'";
    zT_20 = 1;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    tv1 = zT_19;
    zT_22 = "' is not marked 'pub'";
    zT_24 = 21;
    zT_23.ptr = zT_22;
    zT_23.len = zT_24;
    tv2 = zT_23;
    zT_26 = env->interner;
    zT_27 = name_id;
    zT_29 = zF_9134020D_stringInternerGet(zT_26, zT_27);
    tvnm = zT_29;
    zT_32 = 0;
    zT_31[zT_32] = tv1;
    zT_33 = 1;
    zT_31[zT_33] = tvnm;
    zT_34 = 2;
    zT_31[zT_34] = tv2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        tvparts[_i] = zT_31[_i];
        _i++;
    }
}
    zT_36 = env->interner;
    zT_40 = 0;
    zT_41 = tvparts + zT_40;
    zT_37 = zT_41;
    zT_43 = zF_8C4BFF7C_diagnosticBuilderMa(zT_36, zT_37, (unsigned int)(3));
    tvmsg = zT_43;
    zT_45 = env->store;
    zT_46 = node_idx;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_45, zT_46);
    tvnode = zT_48;
    zT_50 = dc;
    zT_53 = env->source_file_id;
    zT_54 = tvnode.span_start;
    zT_63 = tvnode.span_start;
    zT_64 = tvnode.span_len;
    zT_56 = tvmsg;
    zT_67 = zF_C82559AC_diagnosticCollector(zT_50, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3007_VISIBILITY_VIOLATION)), zT_53, zT_54, (unsigned int)(zT_63 + (unsigned int)((unsigned int)zT_64)), zT_56);
    tv_di = zT_67;
    zT_68 = sym->decl_node;
    if ((unsigned char)(zT_68 != (unsigned int)(0))) goto z_bb_9; else goto z_bb_10;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_72 = env->store;
    zT_73 = sym->decl_node;
    zT_76 = zF_FCDD1D35_astStoreNodeAt(zT_72, zT_73);
    tv_decl = zT_76;
    zT_78 = "declared here";
    zT_80 = 13;
    zT_79.ptr = zT_78;
    zT_79.len = zT_80;
    tv_note = zT_79;
    zT_81 = dc;
    zT_82 = tv_di;
    zT_83 = sym->file_id;
    zT_84 = tv_decl.span_start;
    zT_89 = tv_decl.span_start;
    zT_90 = tv_decl.span_len;
    zT_86 = tv_note;
    zF_A9049B03_diagnosticCollector(zT_81, zT_82, zT_83, zT_84, (unsigned int)(zT_89 + (unsigned int)((unsigned int)zT_90)), zT_86);
    goto z_bb_10;
    z_bb_10:
    goto z_bb_8;
}

/* typeResolverIsInferredLenArray */
unsigned char zF_54996FA4_typeResolverIsInfer(zT_6B0A7D14_AstStore* store, zT_D3EB6303_StringInterner* interner, unsigned int node_idx) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_9 = {0};
    zT_8143F551_AstKind zT_10;
    unsigned int zT_15;
    zT_6B0A7D14_AstStore* zT_20;
    unsigned int zT_21;
    zT_22A7C88B_AstNode zT_23 = {0};
    zT_8143F551_AstKind zT_24;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    zT_D3EB6303_StringInterner* zT_35;
    unsigned int zT_36;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37 = {0};
    unsigned int zT_39;
    unsigned char zT_42;
    unsigned char* zT_43;
    int zT_44;
    unsigned char zT_45;
    zT_22A7C88B_AstNode nd;
    zT_22A7C88B_AstNode sz;
    unsigned int nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tx;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    zT_7 = store;
    zT_8 = node_idx;
    zT_9 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    nd = zT_9;
    zT_10 = nd.kind;
    if ((unsigned char)(zT_10 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    zT_15 = nd.child_1;
    if ((unsigned char)(zT_15 == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    zT_20 = store;
    zT_21 = nd.child_1;
    zT_23 = zF_FCDD1D35_astStoreNodeAt(zT_20, zT_21);
    sz = zT_23;
    zT_24 = sz.kind;
    if ((unsigned char)(zT_24 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    zT_30 = store;
    zT_31 = nd.child_1;
    zT_33 = zF_53458827_astStoreIdentifier(zT_30, zT_31);
    nm = zT_33;
    zT_35 = interner;
    zT_36 = nm;
    zT_37 = zF_9134020D_stringInternerGet(zT_35, zT_36);
    tx = zT_37;
    zT_39 = tx.len;
    if ((unsigned char)(zT_39 == (unsigned int)(1))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    zT_43 = tx.ptr;
    zT_44 = 0;
    zT_45 = zT_43[zT_44];
    zT_42 = zT_45 == (unsigned char)(95);
    goto z_bb_11;
    z_bb_10:
    zT_42 = 0;
    goto z_bb_11;
    z_bb_11:
    return zT_42;
}

/* resolveTypeExprFull */
unsigned int zF_F2107C15_resolveTypeExprFull(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6B0A7D14_AstStore* zT_7;
    unsigned int zT_8;
    zT_22A7C88B_AstNode zT_10 = {0};
    unsigned char* zT_12;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_13;
    unsigned int zT_14;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_15;
    unsigned int zT_16;
    unsigned char* zT_18;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_19;
    unsigned int zT_20;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_21;
    zT_8143F551_AstKind zT_23;
    zT_8143F551_AstKind zT_25;
    zT_6B0A7D14_AstStore* zT_30;
    unsigned int zT_31;
    unsigned int zT_33 = 0;
    unsigned char* zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_36;
    unsigned int zT_37;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_38;
    unsigned int zT_39;
    zT_FFCC0D90_Opt_410 zT_40;
    unsigned char zT_41;
    zT_C8A278E4_LocalTypeScope* zT_43;
    unsigned int zT_44;
    zT_BAEE192E_Opt_10 zT_45 = {0};
    unsigned char zT_46;
    zT_D3EB6303_StringInterner* zT_49;
    unsigned int zT_50;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_52 = {0};
    zT_D3EB6303_StringInterner* zT_54;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_55;
    unsigned int zT_57 = 0;
    unsigned int zT_58;
    unsigned int zT_62;
    zT_79FAE712_u64 zT_67;
    zT_338B7C76_TypeRegistry* zT_69;
    zT_79FAE712_u64 zT_70;
    zT_BAEE192E_Opt_10 zT_72 = {0};
    unsigned char zT_73;
    zT_ABC1EBBE_TypeResolveEnv* zT_76;
    unsigned int zT_77;
    unsigned int zT_78;
    unsigned int zT_80 = 0;
    zT_338B7C76_TypeRegistry* zT_84;
    zT_BAEE192E_Opt_10 zT_88 = {0};
    unsigned char* zT_90;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_91;
    unsigned int zT_92;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_93;
    unsigned int zT_94;
    unsigned char zT_95;
    unsigned char* zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_101;
    int zT_103;
    unsigned int zT_104;
    zT_3D7259E2_SymbolRegistry* zT_105;
    unsigned int zT_106;
    zT_79FAE712_u64 zT_114;
    zT_338B7C76_TypeRegistry* zT_116;
    zT_79FAE712_u64 zT_117;
    zT_BAEE192E_Opt_10 zT_119 = {0};
    unsigned char zT_120;
    int zT_122;
    unsigned int zT_124;
    unsigned char* zT_126;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_127;
    unsigned int zT_128;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_129;
    zT_ABC1EBBE_TypeResolveEnv* zT_131;
    unsigned int zT_132;
    unsigned int zT_133 = 0;
    unsigned char* zT_137;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_138;
    unsigned int zT_139;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_140;
    unsigned int zT_141;
    unsigned char* zT_143;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_144;
    unsigned int zT_145;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_146;
    unsigned int zT_147;
    unsigned char zT_149;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_151;
    unsigned char* zT_152;
    unsigned int zT_154 = 0;
    zT_338B7C76_TypeRegistry* zT_157;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_158;
    unsigned int zT_160 = 0;
    zT_8143F551_AstKind zT_162;
    unsigned char zT_166;
    zT_8143F551_AstKind zT_167;
    unsigned char zT_171;
    zT_8143F551_AstKind zT_172;
    zT_ABC1EBBE_TypeResolveEnv* zT_176;
    unsigned int zT_177;
    zT_8143F551_AstKind zT_178;
    unsigned int zT_179;
    unsigned int zT_181 = 0;
    zT_8143F551_AstKind zT_182;
    unsigned char zT_187;
    zT_ABC1EBBE_TypeResolveEnv* zT_189;
    unsigned int zT_190;
    unsigned int zT_195 = 0;
    zT_6B0A7D14_AstStore* zT_199;
    unsigned int zT_200;
    zT_22A7C88B_AstNode zT_203 = {0};
    zT_8143F551_AstKind zT_204;
    zT_6B0A7D14_AstStore* zT_209;
    unsigned int zT_210;
    unsigned int zT_213 = 0;
    int zT_215;
    unsigned int zT_216;
    zT_3D7259E2_SymbolRegistry* zT_217;
    unsigned int zT_218;
    zT_3D7259E2_SymbolRegistry* zT_222;
    unsigned int zT_224;
    zT_6BEBA1C2_Opt_900 zT_227 = {0};
    unsigned char zT_228;
    zT_3C598AEF_SymbolKind zT_230;
    unsigned int zT_235;
    zT_3D7259E2_SymbolRegistry* zT_237;
    unsigned int zT_238;
    unsigned int zT_239;
    zT_6B0A7D14_AstStore* zT_241;
    unsigned int zT_242;
    unsigned int zT_244 = 0;
    zT_6BEBA1C2_Opt_900 zT_245 = {0};
    unsigned char zT_246;
    zT_ABC1EBBE_TypeResolveEnv* zT_248;
    unsigned int zT_249;
    unsigned int zT_250;
    zT_3A105EF1_Symbol* zT_251;
    zT_6B0A7D14_AstStore* zT_252;
    unsigned int zT_253;
    unsigned int zT_255 = 0;
    unsigned char zT_256 = 0;
    unsigned int zT_259;
    unsigned char zT_262;
    unsigned char* zT_264;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_265;
    unsigned int zT_266;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_267;
    unsigned int zT_268;
    unsigned int zT_270;
    int zT_271;
    unsigned int zT_273;
    unsigned char* zT_275;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_276;
    unsigned int zT_277;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_278;
    unsigned int zT_279;
    zT_338B7C76_TypeRegistry* zT_283;
    zT_D155D06D_Type* zT_284;
    unsigned int zT_285;
    zT_D155D06D_Type zT_286;
    zT_33EF6BFB_TypeKind zT_287;
    unsigned short zT_292;
    zT_3D7259E2_SymbolRegistry* zT_294;
    unsigned int zT_296;
    zT_6B0A7D14_AstStore* zT_299;
    unsigned int zT_300;
    unsigned int zT_302 = 0;
    zT_6BEBA1C2_Opt_900 zT_303 = {0};
    unsigned char zT_304;
    zT_ABC1EBBE_TypeResolveEnv* zT_306;
    unsigned int zT_307;
    unsigned int zT_308;
    zT_3A105EF1_Symbol* zT_309;
    zT_6B0A7D14_AstStore* zT_310;
    unsigned int zT_311;
    unsigned int zT_313 = 0;
    unsigned char zT_314 = 0;
    unsigned int zT_317;
    unsigned char zT_320;
    unsigned char* zT_322;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_323;
    unsigned int zT_324;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_325;
    unsigned int zT_326;
    unsigned int zT_328;
    unsigned char* zT_332;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_333;
    unsigned int zT_334;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_335;
    unsigned int zT_336;
    zT_8143F551_AstKind zT_337;
    zT_939EE900_Arr_unsigned_int_1 zT_342;
    zT_338B7C76_TypeRegistry* zT_343;
    unsigned int zT_344;
    unsigned int zT_345;
    unsigned int zT_346;
    zT_EDD37787_Arr_unsigned_short_ zT_348;
    unsigned short zT_349;
    unsigned int zT_350;
    zT_6B0A7D14_AstStore* zT_351;
    unsigned int zT_352;
    unsigned int zT_354 = 0;
    zT_6B0A7D14_AstStore* zT_358;
    unsigned int zT_359;
    unsigned int zT_361 = 0;
    unsigned short zT_362;
    int zT_363;
    int zT_365;
    unsigned int zT_366;
    zT_338B7C76_TypeRegistry* zT_369;
    unsigned int zT_370;
    zT_6B0A7D14_AstStore* zT_372;
    unsigned int zT_373;
    unsigned int zT_377 = 0;
    int zT_378;
    unsigned int zT_380;
    zT_338B7C76_TypeRegistry* zT_381;
    unsigned int zT_382;
    unsigned short zT_383;
    int zT_385;
    int zT_387;
    unsigned int zT_389 = 0;
    zT_8143F551_AstKind zT_390;
    zT_ABC1EBBE_TypeResolveEnv* zT_395;
    unsigned int zT_396;
    unsigned int zT_401 = 0;
    zT_939EE900_Arr_unsigned_int_1 zT_406;
    unsigned int zT_407;
    unsigned int zT_408;
    unsigned int zT_409;
    int zT_410;
    zT_ABC1EBBE_TypeResolveEnv* zT_413;
    unsigned int zT_414;
    unsigned int zT_419 = 0;
    int zT_423;
    unsigned int zT_424;
    int zT_425;
    zT_338B7C76_TypeRegistry* zT_426;
    unsigned int zT_427;
    unsigned int zT_428;
    int zT_430;
    unsigned int zT_432 = 0;
    zT_8143F551_AstKind zT_433;
    zT_939EE900_Arr_unsigned_int_1 zT_438;
    unsigned int zT_439;
    unsigned int zT_440;
    unsigned int zT_441;
    int zT_442;
    unsigned int zT_443;
    int zT_444;
    zT_ABC1EBBE_TypeResolveEnv* zT_446;
    unsigned int zT_447;
    unsigned int zT_452 = 0;
    int zT_453;
    unsigned char* zT_455;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_456;
    unsigned int zT_457;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_458;
    unsigned int zT_459;
    int zT_460;
    int zT_462;
    unsigned int zT_463;
    zT_99292002_Arr_unsigned_int_16 zT_468;
    unsigned int zT_470;
    zT_6B0A7D14_AstStore* zT_471;
    unsigned int zT_472;
    unsigned int zT_474 = 0;
    zT_6B0A7D14_AstStore* zT_478;
    unsigned int zT_479;
    unsigned int zT_481 = 0;
    unsigned int zT_483;
    unsigned char zT_486;
    zT_ABC1EBBE_TypeResolveEnv* zT_490;
    unsigned int zT_491;
    zT_6B0A7D14_AstStore* zT_493;
    unsigned int zT_494;
    unsigned int zT_498 = 0;
    unsigned int zT_501 = 0;
    unsigned int zT_506;
    unsigned int zT_508;
    unsigned char zT_510;
    unsigned char zT_511;
    unsigned char zT_516;
    zT_443A2803_Arr_unsigned_char_9 zT_518;
    unsigned int zT_520;
    unsigned char* zT_522;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_523;
    unsigned int zT_524;
    unsigned char* zT_527;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_528;
    unsigned int zT_529;
    unsigned int zT_531;
    unsigned int zT_533;
    unsigned char zT_535;
    unsigned char* zT_538;
    unsigned char zT_539;
    unsigned int zT_541;
    unsigned int zT_543;
    zT_5826BFC7_Arr_unsigned_char_1 zT_545;
    unsigned int zT_547;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_548;
    int zT_549;
    int zT_553;
    unsigned char* zT_554;
    unsigned int zT_555;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_556;
    unsigned int zT_557 = 0;
    unsigned int zT_561;
    unsigned char zT_564;
    unsigned char zT_567;
    unsigned int zT_569;
    unsigned int zT_571;
    unsigned int zT_573;
    unsigned char zT_575;
    unsigned char zT_580;
    unsigned int zT_582;
    zT_5826BFC7_Arr_unsigned_char_1 zT_584;
    unsigned int zT_586;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_587;
    int zT_591;
    unsigned char* zT_592;
    unsigned int zT_593;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_594;
    unsigned int zT_595 = 0;
    unsigned int zT_599;
    unsigned char zT_602;
    unsigned char zT_605;
    unsigned int zT_607;
    unsigned int zT_609;
    unsigned int zT_611;
    zT_D3EB6303_StringInterner* zT_613;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_614;
    int zT_618;
    unsigned char* zT_619;
    unsigned int zT_620;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_621;
    unsigned int zT_622 = 0;
    zT_338B7C76_TypeRegistry* zT_624;
    unsigned int zT_625;
    unsigned int zT_626;
    unsigned int zT_628;
    zT_338B7C76_TypeRegistry* zT_630;
    unsigned int zT_631;
    unsigned int zT_635;
    zT_338B7C76_TypeRegistry* zT_637;
    unsigned int zT_638;
    unsigned int zT_644;
    unsigned char zT_645;
    int zT_652;
    unsigned int zT_654 = 0;
    unsigned char* zT_656;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_657;
    unsigned int zT_658;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_659;
    unsigned int zT_660;
    zT_338B7C76_TypeRegistry* zT_661;
    unsigned int zT_662;
    zT_338B7C76_TypeRegistry* zT_664;
    unsigned int zT_665;
    unsigned int zT_669 = 0;
    unsigned int zT_670;
    int zT_671;
    zT_8143F551_AstKind zT_673;
    unsigned char zT_677;
    zT_8143F551_AstKind zT_678;
    unsigned char zT_682;
    zT_8143F551_AstKind zT_683;
    unsigned char zT_687;
    zT_6B0A7D14_AstStore* zT_688;
    zT_D3EB6303_StringInterner* zT_689;
    unsigned int zT_690;
    unsigned char zT_694 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_697;
    unsigned int zT_698;
    unsigned int zT_703 = 0;
    zT_8143F551_AstKind zT_707;
    unsigned char zT_711;
    zT_8143F551_AstKind zT_712;
    unsigned char* zT_717;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_718;
    unsigned int zT_719;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_720;
    unsigned int zT_721;
    unsigned char* zT_723;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_724;
    unsigned int zT_725;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_726;
    zT_8143F551_AstKind zT_728;
    unsigned char* zT_731;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_732;
    unsigned int zT_733;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_734;
    unsigned int zT_735;
    unsigned char zT_737;
    unsigned char zT_741;
    unsigned char zT_743;
    unsigned char zT_747;
    zT_8143F551_AstKind zT_748;
    zT_338B7C76_TypeRegistry* zT_753;
    unsigned int zT_754;
    unsigned char zT_755;
    unsigned char zT_756;
    unsigned int zT_758 = 0;
    unsigned char* zT_760;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_761;
    unsigned int zT_762;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_763;
    unsigned int zT_764;
    unsigned char* zT_766;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_767;
    unsigned int zT_768;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_769;
    zT_338B7C76_TypeRegistry* zT_771;
    unsigned int zT_772;
    unsigned char zT_773;
    unsigned char zT_774;
    unsigned int zT_776 = 0;
    unsigned char* zT_778;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_779;
    unsigned int zT_780;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_781;
    unsigned int zT_782;
    unsigned char* zT_784;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_785;
    unsigned int zT_786;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_787;
    zT_8143F551_AstKind zT_788;
    unsigned char zT_793;
    unsigned char zT_797;
    zT_338B7C76_TypeRegistry* zT_799;
    unsigned int zT_800;
    unsigned char zT_801;
    unsigned int zT_803 = 0;
    unsigned char* zT_805;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_806;
    unsigned int zT_807;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_808;
    unsigned int zT_809;
    unsigned char* zT_811;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_812;
    unsigned int zT_813;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_814;
    unsigned int zT_815;
    unsigned char* zT_817;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_818;
    unsigned int zT_819;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_820;
    zT_8143F551_AstKind zT_821;
    unsigned char* zT_826;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_827;
    unsigned int zT_828;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_829;
    unsigned int zT_830;
    zT_338B7C76_TypeRegistry* zT_832;
    unsigned int zT_833;
    unsigned int zT_835 = 0;
    unsigned char* zT_837;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_838;
    unsigned int zT_839;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_840;
    unsigned int zT_841;
    zT_8143F551_AstKind zT_842;
    unsigned char* zT_847;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_848;
    unsigned int zT_849;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_850;
    unsigned char* zT_852;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_853;
    unsigned int zT_854;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_855;
    unsigned int zT_856;
    unsigned int zT_857;
    int zT_858;
    zT_6B0A7D14_AstStore* zT_861;
    unsigned int zT_862;
    zT_22A7C88B_AstNode zT_865 = {0};
    unsigned int zT_867;
    unsigned char zT_869;
    zT_ABC1EBBE_TypeResolveEnv* zT_871;
    unsigned int zT_872;
    unsigned int zT_876 = 0;
    unsigned char zT_879;
    unsigned char* zT_881;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_882;
    unsigned int zT_883;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_884;
    unsigned int zT_885;
    zT_338B7C76_TypeRegistry* zT_887;
    unsigned int zT_888;
    unsigned int zT_889;
    unsigned int zT_891 = 0;
    unsigned char* zT_893;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_894;
    unsigned int zT_895;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_896;
    unsigned int zT_897;
    unsigned char* zT_901;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_902;
    unsigned int zT_903;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_904;
    unsigned char* zT_906;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_907;
    unsigned int zT_908;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_909;
    unsigned char zT_911;
    zT_8143F551_AstKind zT_912;
    zT_6B0A7D14_AstStore* zT_917;
    unsigned int zT_918;
    unsigned int zT_921 = 0;
    zT_D3EB6303_StringInterner* zT_923;
    unsigned int zT_924;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_926 = {0};
    unsigned int zT_928;
    unsigned char zT_931;
    unsigned char* zT_932;
    int zT_933;
    unsigned char zT_934;
    unsigned char zT_937;
    zT_6F32B01B_Opt_235 zT_938;
    unsigned char zT_939;
    zT_F85C5DED_DiagnosticCollector* zT_941;
    unsigned int zT_942;
    unsigned char zT_943 = 0;
    unsigned char* zT_945;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_946;
    unsigned int zT_947;
    zT_F85C5DED_DiagnosticCollector* zT_948;
    unsigned int zT_951;
    unsigned int zT_952;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_954;
    unsigned int zT_959;
    unsigned int zT_960;
    unsigned int zT_963 = 0;
    zT_6F32B01B_Opt_235 zT_964;
    unsigned char zT_965;
    zT_F85C5DED_DiagnosticCollector* zT_967;
    unsigned int zT_968;
    unsigned char zT_969 = 0;
    unsigned char* zT_971;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_972;
    unsigned int zT_973;
    zT_F85C5DED_DiagnosticCollector* zT_974;
    unsigned int zT_977;
    unsigned int zT_978;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_980;
    unsigned int zT_987;
    unsigned int zT_988;
    unsigned int zT_991 = 0;
    unsigned char* zT_994;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_995;
    unsigned int zT_996;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_997;
    unsigned int zT_998;
    unsigned char* zT_1000;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1001;
    unsigned int zT_1002;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_1003;
    zT_8143F551_AstKind zT_1005;
    zT_22A7C88B_AstNode node;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u rtd_km;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4_m;
    zT_C8A278E4_LocalTypeScope* lts;
    zT_8F083A69_Slice_zT_0B42B2F8_u text;
    unsigned int canonical_id;
    unsigned int lt;
    zT_79FAE712_u64 ck_cur;
    zT_BAEE192E_Opt_10 tc_cur;
    zT_BAEE192E_Opt_10 tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opnc_m;
    unsigned int t;
    unsigned int sym_cur_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u nf;
    unsigned int mi;
    zT_79FAE712_u64 ck;
    zT_BAEE192E_Opt_10 tc;
    zT_8F083A69_Slice_zT_0B42B2F8_u n2;
    unsigned int all_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ops_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm4f_m;
    unsigned char arbu;
    unsigned int arbw;
    unsigned char fah_matched;
    unsigned int base_type;
    zT_22A7C88B_AstNode base_node;
    zT_D155D06D_Type base_ty;
    unsigned int base_name_id;
    unsigned int smi;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam_m;
    zT_6BEBA1C2_Opt_900 base_sym;
    zT_3A105EF1_Symbol* bs;
    unsigned int mod_id;
    zT_6BEBA1C2_Opt_900 payload_sym;
    zT_3A105EF1_Symbol* ps;
    zT_8F083A69_Slice_zT_0B42B2F8_u fam;
    unsigned short mod_id_1;
    zT_6BEBA1C2_Opt_900 sym;
    zT_3A105EF1_Symbol* s;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnm;
    zT_939EE900_Arr_unsigned_int_1 esd_start_box;
    zT_EDD37787_Arr_unsigned_short_ esd_count_box;
    unsigned int esd_children_n;
    unsigned int esd_i;
    unsigned int eu_payload_type;
    zT_939EE900_Arr_unsigned_int_1 eu_es_box;
    unsigned int eu_resolved_es;
    zT_939EE900_Arr_unsigned_int_1 fnt_ret_box;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm2_m;
    zT_99292002_Arr_unsigned_int_16 fnt_ptypes;
    unsigned int fnt_pc;
    unsigned int fnt_extra_n;
    unsigned int fnt_i;
    unsigned char fnt_conv;
    unsigned int fnt_pt;
    zT_443A2803_Arr_unsigned_char_9 fnt_nb;
    unsigned int fnt_np;
    zT_8F083A69_Slice_zT_0B42B2F8_u fnt_pre;
    unsigned int fnt_pri;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_rb;
    unsigned int fnt_rl;
    unsigned int fnt_rs;
    unsigned int fnt_k;
    unsigned int fnt_name_id;
    unsigned int fnt_pstart;
    unsigned int fnt_a;
    zT_5826BFC7_Arr_unsigned_char_1 fnt_pb;
    unsigned int fnt_pl;
    unsigned int fnt_ps;
    unsigned int fnt_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u opm3_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_nm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u und_km;
    unsigned int child_type;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptkm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ptcm;
    unsigned char is_const;
    unsigned char is_volatile;
    unsigned int ptr_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl;
    unsigned int ptr_tid2;
    zT_8F083A69_Slice_zT_0B42B2F8_u ppm2;
    zT_8F083A69_Slice_zT_0B42B2F8_u pnl2;
    unsigned int sl_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u sm;
    zT_8F083A69_Slice_zT_0B42B2F8_u s2;
    zT_8F083A69_Slice_zT_0B42B2F8_u s3;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_m;
    unsigned int optvd_tid;
    zT_8F083A69_Slice_zT_0B42B2F8_u optvd_rm;
    zT_8F083A69_Slice_zT_0B42B2F8_u t0m;
    zT_8F083A69_Slice_zT_0B42B2F8_u t1m;
    zT_22A7C88B_AstNode sz_node;
    unsigned int arr_len;
    unsigned char arr_resolved;
    unsigned int alf;
    zT_8F083A69_Slice_zT_0B42B2F8_u t2m;
    unsigned int at;
    zT_8F083A69_Slice_zT_0B42B2F8_u t3m;
    unsigned char sz_is_inferred;
    zT_8F083A69_Slice_zT_0B42B2F8_u am;
    unsigned int sz_name;
    zT_8F083A69_Slice_zT_0B42B2F8_u sz_text;
    zT_F85C5DED_DiagnosticCollector* dg;
    zT_8F083A69_Slice_zT_0B42B2F8_u ail_msg;
    zT_8F083A69_Slice_zT_0B42B2F8_u asn_msg;
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_7 = env->store;
    zT_8 = node_idx;
    zT_10 = zF_FCDD1D35_astStoreNodeAt(zT_7, zT_8);
    node = zT_10;
    zT_12 = "RTD:n";
    zT_14 = 5;
    zT_13.ptr = zT_12;
    zT_13.len = zT_14;
    rtd_nm = zT_13;
    zT_15 = rtd_nm;
    zT_16 = node_idx;
    zF_C914CB83_markerWriteInt(zT_15, zT_16);
    zT_18 = "RTD:k";
    zT_20 = 5;
    zT_19.ptr = zT_18;
    zT_19.len = zT_20;
    rtd_km = zT_19;
    zT_21 = rtd_km;
    zT_23 = node.kind;
    zF_C914CB83_markerWriteInt(zT_21, (unsigned int)((unsigned int)zT_23));
    zT_25 = node.kind;
    if ((unsigned char)(zT_25 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    zT_30 = env->store;
    zT_31 = node_idx;
    zT_33 = zF_53458827_astStoreIdentifier(zT_30, zT_31);
    name_id = zT_33;
    zT_35 = "OPTVOID:id";
    zT_37 = 10;
    zT_36.ptr = zT_35;
    zT_36.len = zT_37;
    opm4_m = zT_36;
    zT_38 = opm4_m;
    zT_39 = name_id;
    zF_C914CB83_markerWriteInt(zT_38, zT_39);
    zT_40 = env->local_types;
    zT_41 = zT_40.has_value;
    if (zT_41) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    zT_162 = node.kind;
    if ((unsigned char)(zT_162 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_28; else goto z_bb_27;
    z_bb_5:
    lts = zT_40.value;
    zT_43 = lts;
    zT_44 = name_id;
    zT_45 = zF_C768898A_localTypeScopeLooku(zT_43, zT_44);
    zT_46 = zT_45.has_value;
    if (zT_46) goto z_bb_7; else goto z_bb_8;
    z_bb_6:
    zT_49 = env->interner;
    zT_50 = name_id;
    zT_52 = zF_9134020D_stringInternerGet(zT_49, zT_50);
    text = zT_52;
    zT_54 = env->interner;
    zT_55 = text;
    zT_57 = zF_50C274AF_stringInternerInter(zT_54, zT_55);
    canonical_id = zT_57;
    zT_58 = env->module_id;
    if ((unsigned char)(zT_58 != zG_E6DB2ACE_MODULE_ID_NONE)) goto z_bb_9; else goto z_bb_10;
    z_bb_7:
    lt = zT_45.value;
    return lt;
    z_bb_8:
    goto z_bb_6;
    z_bb_9:
    zT_62 = env->module_id;
    zT_67 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_62) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck_cur = zT_67;
    zT_69 = env->typereg;
    zT_70 = ck_cur;
    zT_72 = zF_0EB68360_nameCacheGet(zT_69, zT_70);
    tc_cur = zT_72;
    zT_73 = tc_cur.has_value;
    if (zT_73) goto z_bb_11; else goto z_bb_12;
    z_bb_10:
    zT_84 = env->typereg;
    zT_88 = zF_0EB68360_nameCacheGet(zT_84, (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id));
    tid = zT_88;
    zT_90 = "OPTVOID:nc";
    zT_92 = 10;
    zT_91.ptr = zT_90;
    zT_91.len = zT_92;
    opnc_m = zT_91;
    zT_93 = opnc_m;
    zT_94 = canonical_id;
    zF_C914CB83_markerWriteInt(zT_93, zT_94);
    zT_95 = tid.has_value;
    if (zT_95) goto z_bb_15; else goto z_bb_16;
    z_bb_11:
    t = tc_cur.value;
    return t;
    z_bb_12:
    zT_76 = env;
    zT_77 = env->module_id;
    zT_78 = name_id;
    zT_80 = zF_66C54985_symbolTypeIdOfModul(zT_76, zT_77, zT_78);
    sym_cur_tid = zT_80;
    if ((unsigned char)(sym_cur_tid != (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return sym_cur_tid;
    z_bb_14:
    goto z_bb_10;
    z_bb_15:
    t = tid.value;
    return t;
    z_bb_16:
    zT_98 = "NF";
    zT_100 = 2;
    zT_99.ptr = zT_98;
    zT_99.len = zT_100;
    nf = zT_99;
    zT_101 = nf;
    zF_48AC7B3A_markerWrite(zT_101);
    zT_103 = 0;
    zT_104 = (unsigned int)zT_103;
    mi = zT_104;
    goto z_bb_17;
    z_bb_17:
    zT_105 = env->symbol_reg;
    zT_106 = zT_105->tables_len;
    if ((unsigned char)(mi < (unsigned int)((unsigned int)zT_106))) goto z_bb_18; else goto z_bb_19;
    z_bb_18:
    zT_114 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mi) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)canonical_id);
    ck = zT_114;
    zT_116 = env->typereg;
    zT_117 = ck;
    zT_119 = zF_0EB68360_nameCacheGet(zT_116, zT_117);
    tc = zT_119;
    zT_120 = tc.has_value;
    if (zT_120) goto z_bb_21; else goto z_bb_22;
    z_bb_19:
    zT_126 = "N2";
    zT_128 = 2;
    zT_127.ptr = zT_126;
    zT_127.len = zT_128;
    n2 = zT_127;
    zT_129 = n2;
    zF_48AC7B3A_markerWrite(zT_129);
    zT_131 = env;
    zT_132 = name_id;
    zT_133 = zF_DE1472AF_symbolLookupTypeAll(zT_131, zT_132);
    all_tid = zT_133;
    if ((unsigned char)(all_tid != (unsigned int)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_122 = 1;
    zT_124 = mi + (unsigned int)((unsigned int)zT_122);
    mi = zT_124;
    goto z_bb_17;
    z_bb_21:
    t = tc.value;
    return t;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    zT_137 = "OPTVOID:ids";
    zT_139 = 11;
    zT_138.ptr = zT_137;
    zT_138.len = zT_139;
    ops_m = zT_138;
    zT_140 = ops_m;
    zT_141 = all_tid;
    zF_C914CB83_markerWriteInt(zT_140, zT_141);
    return all_tid;
    z_bb_24:
    zT_143 = "OPTVOID:idF";
    zT_145 = 11;
    zT_144.ptr = zT_143;
    zT_144.len = zT_145;
    opm4f_m = zT_144;
    zT_146 = opm4f_m;
    zT_147 = name_id;
    zF_C914CB83_markerWriteInt(zT_146, zT_147);
    zT_149 = 0;
    arbu = zT_149;
    zT_151 = text;
    zT_152 = &arbu;
    zT_154 = zF_741B5264_parseArbIntWidth(zT_151, zT_152);
    arbw = zT_154;
    if ((unsigned char)(arbw != (unsigned int)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_157 = env->typereg;
    zT_158 = text;
    zT_160 = zF_B8CF3697_typeRegistryGetOrCr(zT_157, zT_158);
    return zT_160;
    z_bb_26:
    return (unsigned int)(18);
    z_bb_27:
    zT_167 = node.kind;
    zT_166 = zT_167 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl);
    goto z_bb_29;
    z_bb_28:
    zT_166 = 1;
    goto z_bb_29;
    z_bb_29:
    if (zT_166) goto z_bb_31; else goto z_bb_30;
    z_bb_30:
    zT_172 = node.kind;
    zT_171 = zT_172 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_32;
    z_bb_31:
    zT_171 = 1;
    goto z_bb_32;
    z_bb_32:
    if (zT_171) goto z_bb_33; else goto z_bb_34;
    z_bb_33:
    zT_176 = env;
    zT_177 = node_idx;
    zT_178 = node.kind;
    zT_179 = depth;
    zT_181 = zF_FE81311F_registerContainerTy(zT_176, zT_177, zT_178, zT_179);
    return zT_181;
    z_bb_34:
    zT_182 = node.kind;
    if ((unsigned char)(zT_182 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_187 = 0;
    fah_matched = zT_187;
    zT_189 = env;
    zT_190 = node.child_0;
    zT_195 = zF_F2107C15_resolveTypeExprFull(zT_189, zT_190, (unsigned int)(depth + (unsigned int)(1)));
    base_type = zT_195;
    if ((unsigned char)(base_type == (unsigned int)(18))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    zT_337 = node.kind;
    if ((unsigned char)(zT_337 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_65; else goto z_bb_66;
    z_bb_37:
    zT_199 = env->store;
    zT_200 = node.child_0;
    zT_203 = zF_FCDD1D35_astStoreNodeAt(zT_199, zT_200);
    base_node = zT_203;
    zT_204 = base_node.kind;
    if ((unsigned char)(zT_204 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    zT_283 = env->typereg;
    zT_284 = zT_283->types_items;
    zT_285 = (unsigned int)base_type;
    zT_286 = zT_284[zT_285];
    base_ty = zT_286;
    zT_287 = base_ty.kind;
    if ((unsigned char)(zT_287 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_55; else goto z_bb_56;
    z_bb_39:
    zT_209 = env->store;
    zT_210 = node.child_0;
    zT_213 = zF_53458827_astStoreIdentifier(zT_209, zT_210);
    base_name_id = zT_213;
    zT_215 = 0;
    zT_216 = (unsigned int)zT_215;
    smi = zT_216;
    goto z_bb_41;
    z_bb_40:
    zT_275 = "FAH:m";
    zT_277 = 5;
    zT_276.ptr = zT_275;
    zT_276.len = zT_277;
    fam_m = zT_276;
    zT_278 = fam_m;
    zT_279 = node.child_0;
    zF_C914CB83_markerWriteInt(zT_278, zT_279);
    return (unsigned int)(18);
    z_bb_41:
    zT_217 = env->symbol_reg;
    zT_218 = zT_217->tables_len;
    if ((unsigned char)(smi < (unsigned int)((unsigned int)zT_218))) goto z_bb_42; else goto z_bb_43;
    z_bb_42:
    zT_222 = env->symbol_reg;
    zT_224 = base_name_id;
    zT_227 = zF_A398987E_symbolRegistryQuali(zT_222, (unsigned int)((unsigned int)smi), zT_224);
    base_sym = zT_227;
    zT_228 = base_sym.has_value;
    if (zT_228) goto z_bb_45; else goto z_bb_46;
    z_bb_43:
    goto z_bb_40;
    z_bb_44:
    zT_271 = 1;
    zT_273 = smi + (unsigned int)((unsigned int)zT_271);
    smi = zT_273;
    goto z_bb_41;
    z_bb_45:
    bs = base_sym.value;
    zT_230 = bs->kind;
    if ((unsigned char)(zT_230 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    goto z_bb_44;
    z_bb_47:
    zT_235 = bs->module_id;
    mod_id = zT_235;
    zT_237 = env->symbol_reg;
    zT_238 = mod_id;
    zT_241 = env->store;
    zT_242 = node_idx;
    zT_244 = zF_8BA26B9E_astStoreNodePayload(zT_241, zT_242);
    zT_239 = zT_244;
    zT_245 = zF_A398987E_symbolRegistryQuali(zT_237, zT_238, zT_239);
    payload_sym = zT_245;
    zT_246 = payload_sym.has_value;
    if (zT_246) goto z_bb_49; else goto z_bb_50;
    z_bb_48:
    goto z_bb_46;
    z_bb_49:
    ps = payload_sym.value;
    zT_248 = env;
    zT_249 = node_idx;
    zT_252 = env->store;
    zT_253 = node_idx;
    zT_255 = zF_8BA26B9E_astStoreNodePayload(zT_252, zT_253);
    zT_250 = zT_255;
    zT_251 = ps;
    zT_256 = zF_D43B245F_typeResolverCheckMe(zT_248, zT_249, zT_250, zT_251);
    if ((unsigned char)(!zT_256)) goto z_bb_51; else goto z_bb_52;
    z_bb_50:
    goto z_bb_48;
    z_bb_51:
    return (unsigned int)(18);
    z_bb_52:
    zT_259 = ps->type_id;
    if ((unsigned char)(zT_259 != (unsigned int)(0))) goto z_bb_53; else goto z_bb_54;
    z_bb_53:
    zT_262 = 1;
    fah_matched = zT_262;
    zT_264 = "FAH:r";
    zT_266 = 5;
    zT_265.ptr = zT_264;
    zT_265.len = zT_266;
    fam = zT_265;
    zT_267 = fam;
    zT_268 = ps->type_id;
    zF_C914CB83_markerWriteInt(zT_267, zT_268);
    zT_270 = ps->type_id;
    return zT_270;
    z_bb_54:
    goto z_bb_50;
    z_bb_55:
    zT_292 = base_ty.module_id;
    mod_id_1 = zT_292;
    zT_294 = env->symbol_reg;
    zT_299 = env->store;
    zT_300 = node_idx;
    zT_302 = zF_8BA26B9E_astStoreNodePayload(zT_299, zT_300);
    zT_296 = zT_302;
    zT_303 = zF_A398987E_symbolRegistryQuali(zT_294, (unsigned int)((unsigned int)mod_id_1), zT_296);
    sym = zT_303;
    zT_304 = sym.has_value;
    if (zT_304) goto z_bb_57; else goto z_bb_58;
    z_bb_56:
    if ((unsigned char)(fah_matched == (unsigned char)(0))) goto z_bb_63; else goto z_bb_64;
    z_bb_57:
    s = sym.value;
    zT_306 = env;
    zT_307 = node_idx;
    zT_310 = env->store;
    zT_311 = node_idx;
    zT_313 = zF_8BA26B9E_astStoreNodePayload(zT_310, zT_311);
    zT_308 = zT_313;
    zT_309 = s;
    zT_314 = zF_D43B245F_typeResolverCheckMe(zT_306, zT_307, zT_308, zT_309);
    if ((unsigned char)(!zT_314)) goto z_bb_59; else goto z_bb_60;
    z_bb_58:
    goto z_bb_56;
    z_bb_59:
    return (unsigned int)(18);
    z_bb_60:
    zT_317 = s->type_id;
    if ((unsigned char)(zT_317 != (unsigned int)(0))) goto z_bb_61; else goto z_bb_62;
    z_bb_61:
    zT_320 = 1;
    fah_matched = zT_320;
    zT_322 = "FAH:r";
    zT_324 = 5;
    zT_323.ptr = zT_322;
    zT_323.len = zT_324;
    fam = zT_323;
    zT_325 = fam;
    zT_326 = s->type_id;
    zF_C914CB83_markerWriteInt(zT_325, zT_326);
    zT_328 = s->type_id;
    return zT_328;
    z_bb_62:
    goto z_bb_58;
    z_bb_63:
    zT_332 = "FAH:N";
    zT_334 = 5;
    zT_333.ptr = zT_332;
    zT_333.len = zT_334;
    fnm = zT_333;
    zT_335 = fnm;
    zT_336 = node_idx;
    zF_C914CB83_markerWriteInt(zT_335, zT_336);
    goto z_bb_64;
    z_bb_64:
    goto z_bb_36;
    z_bb_65:
    zT_343 = env->typereg;
    zT_344 = zT_343->xn_len;
    zT_345 = (unsigned int)zT_344;
    zT_346 = 0;
    zT_342[zT_346] = zT_345;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_start_box[_i] = zT_342[_i];
        _i++;
    }
}
    zT_349 = 0;
    zT_350 = 0;
    zT_348[zT_350] = zT_349;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        esd_count_box[_i] = zT_348[_i];
        _i++;
    }
}
    zT_351 = env->store;
    zT_352 = node_idx;
    zT_354 = zF_8BA26B9E_astStoreNodePayload(zT_351, zT_352);
    if ((unsigned char)(zT_354 != (unsigned int)(0))) goto z_bb_67; else goto z_bb_68;
    z_bb_66:
    zT_390 = node.kind;
    if ((unsigned char)(zT_390 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_73; else goto z_bb_74;
    z_bb_67:
    zT_358 = env->store;
    zT_359 = node_idx;
    zT_361 = zF_152E19CB_astStoreNodeExtraCh(zT_358, zT_359);
    esd_children_n = zT_361;
    zT_362 = (unsigned short)esd_children_n;
    zT_363 = 0;
    esd_count_box[zT_363] = zT_362;
    zT_365 = 0;
    zT_366 = (unsigned int)zT_365;
    esd_i = zT_366;
    goto z_bb_69;
    z_bb_68:
    zT_381 = env->typereg;
    zT_385 = 0;
    zT_382 = esd_start_box[zT_385];
    zT_387 = 0;
    zT_383 = esd_count_box[zT_387];
    zT_389 = zF_1C9ADFFD_typeRegistryGetOrCr(zT_381, zT_382, zT_383);
    return zT_389;
    z_bb_69:
    if ((unsigned char)(esd_i < (unsigned int)((unsigned int)esd_children_n))) goto z_bb_70; else goto z_bb_71;
    z_bb_70:
    zT_369 = env->typereg;
    zT_372 = env->store;
    zT_373 = node_idx;
    zT_377 = zF_B10B1BC1_astStoreNodeExtraCh(zT_372, zT_373, (unsigned int)((unsigned int)esd_i));
    zT_370 = zT_377;
    zF_A648B1CB_xnAppend(zT_369, zT_370);
    goto z_bb_72;
    z_bb_71:
    goto z_bb_68;
    z_bb_72:
    zT_378 = 1;
    zT_380 = esd_i + (unsigned int)((unsigned int)zT_378);
    esd_i = zT_380;
    goto z_bb_69;
    z_bb_73:
    zT_395 = env;
    zT_396 = node.child_1;
    zT_401 = zF_F2107C15_resolveTypeExprFull(zT_395, zT_396, (unsigned int)(depth + (unsigned int)(1)));
    eu_payload_type = zT_401;
    if ((unsigned char)(eu_payload_type == (unsigned int)(18))) goto z_bb_75; else goto z_bb_76;
    z_bb_74:
    zT_433 = node.kind;
    if ((unsigned char)(zT_433 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_82; else goto z_bb_83;
    z_bb_75:
    return (unsigned int)(18);
    z_bb_76:
    zT_407 = 0;
    zT_408 = 0;
    zT_406[zT_408] = zT_407;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        eu_es_box[_i] = zT_406[_i];
        _i++;
    }
}
    zT_409 = node.child_0;
    zT_410 = 0;
    if ((unsigned char)(zT_409 != (unsigned int)zT_410)) goto z_bb_77; else goto z_bb_79;
    z_bb_77:
    zT_413 = env;
    zT_414 = node.child_0;
    zT_419 = zF_F2107C15_resolveTypeExprFull(zT_413, zT_414, (unsigned int)(depth + (unsigned int)(1)));
    eu_resolved_es = zT_419;
    if ((unsigned char)(eu_resolved_es == (unsigned int)(18))) goto z_bb_80; else goto z_bb_81;
    z_bb_78:
    zT_426 = env->typereg;
    zT_427 = eu_payload_type;
    zT_430 = 0;
    zT_428 = eu_es_box[zT_430];
    zT_432 = zF_16D1A6EE_typeRegistryGetOrCr(zT_426, zT_427, zT_428);
    return zT_432;
    z_bb_79:
    zT_424 = 0;
    zT_425 = 0;
    eu_es_box[zT_425] = zT_424;
    goto z_bb_78;
    z_bb_80:
    return (unsigned int)(18);
    z_bb_81:
    zT_423 = 0;
    eu_es_box[zT_423] = eu_resolved_es;
    goto z_bb_78;
    z_bb_82:
    zT_439 = 0;
    zT_440 = 0;
    zT_438[zT_440] = zT_439;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        fnt_ret_box[_i] = zT_438[_i];
        _i++;
    }
}
    zT_441 = 1;
    zT_442 = 0;
    fnt_ret_box[zT_442] = zT_441;
    zT_443 = node.child_0;
    zT_444 = 0;
    if ((unsigned char)(zT_443 != (unsigned int)zT_444)) goto z_bb_84; else goto z_bb_85;
    z_bb_83:
    zT_670 = node.child_0;
    zT_671 = 0;
    if ((unsigned char)(zT_670 != (unsigned int)zT_671)) goto z_bb_137; else goto z_bb_138;
    z_bb_84:
    zT_446 = env;
    zT_447 = node.child_0;
    zT_452 = zF_F2107C15_resolveTypeExprFull(zT_446, zT_447, (unsigned int)(depth + (unsigned int)(1)));
    zT_453 = 0;
    fnt_ret_box[zT_453] = zT_452;
    zT_455 = "OPTVOID:fntR";
    zT_457 = 12;
    zT_456.ptr = zT_455;
    zT_456.len = zT_457;
    opm2_m = zT_456;
    zT_458 = opm2_m;
    zT_460 = 0;
    zT_459 = fnt_ret_box[zT_460];
    zF_C914CB83_markerWriteInt(zT_458, zT_459);
    zT_462 = 0;
    zT_463 = fnt_ret_box[zT_462];
    if ((unsigned char)(zT_463 == (unsigned int)(18))) goto z_bb_86; else goto z_bb_87;
    z_bb_85:
    {
    unsigned int _i = 0;
    while (_i < 16) {
        zT_468[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 16) {
        fnt_ptypes[_i] = zT_468[_i];
        _i++;
    }
}
    zT_470 = 0;
    fnt_pc = zT_470;
    zT_471 = env->store;
    zT_472 = node_idx;
    zT_474 = zF_8BA26B9E_astStoreNodePayload(zT_471, zT_472);
    if ((unsigned char)(zT_474 != (unsigned int)(0))) goto z_bb_88; else goto z_bb_89;
    z_bb_86:
    return (unsigned int)(18);
    z_bb_87:
    goto z_bb_85;
    z_bb_88:
    zT_478 = env->store;
    zT_479 = node_idx;
    zT_481 = zF_152E19CB_astStoreNodeExtraCh(zT_478, zT_479);
    fnt_extra_n = zT_481;
    zT_483 = 0;
    fnt_i = zT_483;
    goto z_bb_90;
    z_bb_89:
    zT_510 = 0;
    fnt_conv = zT_510;
    zT_511 = node.flags;
    if ((unsigned char)((unsigned char)(zT_511 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_99; else goto z_bb_100;
    z_bb_90:
    if ((unsigned char)(fnt_i < (unsigned int)((unsigned int)fnt_extra_n))) goto z_bb_94; else goto z_bb_95;
    z_bb_91:
    zT_490 = env;
    zT_493 = env->store;
    zT_494 = node_idx;
    zT_498 = zF_B10B1BC1_astStoreNodeExtraCh(zT_493, zT_494, (unsigned int)((unsigned int)fnt_i));
    zT_491 = zT_498;
    zT_501 = zF_F2107C15_resolveTypeExprFull(zT_490, zT_491, (unsigned int)(depth + (unsigned int)(1)));
    fnt_pt = zT_501;
    if ((unsigned char)(fnt_pt == (unsigned int)(18))) goto z_bb_97; else goto z_bb_98;
    z_bb_92:
    goto z_bb_89;
    z_bb_93:
    zT_508 = fnt_i + (unsigned int)(1);
    fnt_i = zT_508;
    goto z_bb_90;
    z_bb_94:
    zT_486 = fnt_pc < (unsigned int)(16);
    goto z_bb_96;
    z_bb_95:
    zT_486 = 0;
    goto z_bb_96;
    z_bb_96:
    if (zT_486) goto z_bb_91; else goto z_bb_92;
    z_bb_97:
    return (unsigned int)(18);
    z_bb_98:
    fnt_ptypes[fnt_pc] = fnt_pt;
    zT_506 = fnt_pc + (unsigned int)(1);
    fnt_pc = zT_506;
    goto z_bb_93;
    z_bb_99:
    zT_516 = 1;
    fnt_conv = zT_516;
    goto z_bb_100;
    z_bb_100:
    {
    unsigned int _i = 0;
    while (_i < 96) {
        zT_518[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 96) {
        fnt_nb[_i] = zT_518[_i];
        _i++;
    }
}
    zT_520 = 0;
    fnt_np = zT_520;
    zT_522 = "fnt_";
    zT_524 = 4;
    zT_523.ptr = zT_522;
    zT_523.len = zT_524;
    fnt_pre = zT_523;
    if ((unsigned char)(fnt_conv == (unsigned char)(1))) goto z_bb_101; else goto z_bb_102;
    z_bb_101:
    zT_527 = "fnts_";
    zT_529 = 5;
    zT_528.ptr = zT_527;
    zT_528.len = zT_529;
    fnt_pre = zT_528;
    goto z_bb_102;
    z_bb_102:
    zT_531 = 0;
    fnt_pri = zT_531;
    goto z_bb_103;
    z_bb_103:
    zT_533 = fnt_pre.len;
    if ((unsigned char)(fnt_pri < zT_533)) goto z_bb_107; else goto z_bb_108;
    z_bb_104:
    zT_538 = fnt_pre.ptr;
    zT_539 = zT_538[fnt_pri];
    fnt_nb[fnt_np] = zT_539;
    zT_541 = fnt_np + (unsigned int)(1);
    fnt_np = zT_541;
    goto z_bb_106;
    z_bb_105:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_545[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_rb[_i] = zT_545[_i];
        _i++;
    }
}
    zT_549 = 0;
    zT_547 = fnt_ret_box[zT_549];
    zT_553 = 0;
    zT_554 = (unsigned char*)((unsigned char*)fnt_rb) + zT_553;
    zT_555 = (unsigned int)(12) - zT_553;
    zT_556.ptr = zT_554;
    zT_556.len = zT_555;
    zT_548 = zT_556;
    zT_557 = zF_A7504564_itoa(zT_547, zT_548);
    fnt_rl = zT_557;
    zT_561 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_rl);
    fnt_rs = zT_561;
    goto z_bb_110;
    z_bb_106:
    zT_543 = fnt_pri + (unsigned int)(1);
    fnt_pri = zT_543;
    goto z_bb_103;
    z_bb_107:
    zT_535 = fnt_np < (unsigned int)(95);
    goto z_bb_109;
    z_bb_108:
    zT_535 = 0;
    goto z_bb_109;
    z_bb_109:
    if (zT_535) goto z_bb_104; else goto z_bb_105;
    z_bb_110:
    if ((unsigned char)(fnt_rs < (unsigned int)(11))) goto z_bb_114; else goto z_bb_115;
    z_bb_111:
    zT_567 = fnt_rb[fnt_rs];
    fnt_nb[fnt_np] = zT_567;
    zT_569 = fnt_np + (unsigned int)(1);
    fnt_np = zT_569;
    goto z_bb_113;
    z_bb_112:
    zT_573 = 0;
    fnt_k = zT_573;
    goto z_bb_117;
    z_bb_113:
    zT_571 = fnt_rs + (unsigned int)(1);
    fnt_rs = zT_571;
    goto z_bb_110;
    z_bb_114:
    zT_564 = fnt_np < (unsigned int)(95);
    goto z_bb_116;
    z_bb_115:
    zT_564 = 0;
    goto z_bb_116;
    z_bb_116:
    if (zT_564) goto z_bb_111; else goto z_bb_112;
    z_bb_117:
    if ((unsigned char)(fnt_k < fnt_pc)) goto z_bb_121; else goto z_bb_122;
    z_bb_118:
    if ((unsigned char)(fnt_np < (unsigned int)(95))) goto z_bb_124; else goto z_bb_125;
    z_bb_119:
    zT_613 = env->interner;
    zT_618 = 0;
    zT_619 = (unsigned char*)((unsigned char*)fnt_nb) + zT_618;
    zT_620 = fnt_np - zT_618;
    zT_621.ptr = zT_619;
    zT_621.len = zT_620;
    zT_614 = zT_621;
    zT_622 = zF_50C274AF_stringInternerInter(zT_613, zT_614);
    fnt_name_id = zT_622;
    zT_624 = env->typereg;
    zT_625 = zT_624->xt_len;
    zT_626 = (unsigned int)zT_625;
    fnt_pstart = zT_626;
    zT_628 = 0;
    fnt_a = zT_628;
    goto z_bb_133;
    z_bb_120:
    zT_611 = fnt_k + (unsigned int)(1);
    fnt_k = zT_611;
    goto z_bb_117;
    z_bb_121:
    zT_575 = fnt_np < (unsigned int)(95);
    goto z_bb_123;
    z_bb_122:
    zT_575 = 0;
    goto z_bb_123;
    z_bb_123:
    if (zT_575) goto z_bb_118; else goto z_bb_119;
    z_bb_124:
    zT_580 = 95;
    fnt_nb[fnt_np] = zT_580;
    zT_582 = fnt_np + (unsigned int)(1);
    fnt_np = zT_582;
    goto z_bb_125;
    z_bb_125:
    {
    unsigned int _i = 0;
    while (_i < 12) {
        zT_584[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 12) {
        fnt_pb[_i] = zT_584[_i];
        _i++;
    }
}
    zT_586 = fnt_ptypes[fnt_k];
    zT_591 = 0;
    zT_592 = (unsigned char*)((unsigned char*)fnt_pb) + zT_591;
    zT_593 = (unsigned int)(12) - zT_591;
    zT_594.ptr = zT_592;
    zT_594.len = zT_593;
    zT_587 = zT_594;
    zT_595 = zF_A7504564_itoa(zT_586, zT_587);
    fnt_pl = zT_595;
    zT_599 = (unsigned int)(11) - (unsigned int)((unsigned int)fnt_pl);
    fnt_ps = zT_599;
    goto z_bb_126;
    z_bb_126:
    if ((unsigned char)(fnt_ps < (unsigned int)(11))) goto z_bb_130; else goto z_bb_131;
    z_bb_127:
    zT_605 = fnt_pb[fnt_ps];
    fnt_nb[fnt_np] = zT_605;
    zT_607 = fnt_np + (unsigned int)(1);
    fnt_np = zT_607;
    goto z_bb_129;
    z_bb_128:
    goto z_bb_120;
    z_bb_129:
    zT_609 = fnt_ps + (unsigned int)(1);
    fnt_ps = zT_609;
    goto z_bb_126;
    z_bb_130:
    zT_602 = fnt_np < (unsigned int)(95);
    goto z_bb_132;
    z_bb_131:
    zT_602 = 0;
    goto z_bb_132;
    z_bb_132:
    if (zT_602) goto z_bb_127; else goto z_bb_128;
    z_bb_133:
    if ((unsigned char)(fnt_a < fnt_pc)) goto z_bb_134; else goto z_bb_135;
    z_bb_134:
    zT_630 = env->typereg;
    zT_631 = fnt_ptypes[fnt_a];
    zF_4C03AE3D_xtAppend(zT_630, zT_631);
    goto z_bb_136;
    z_bb_135:
    zT_637 = env->typereg;
    zT_638 = fnt_name_id;
    zT_652 = 0;
    zT_644 = fnt_ret_box[zT_652];
    zT_645 = fnt_conv;
    zT_654 = zF_474336D7_typeRegistryGetOrCr(zT_637, zT_638, (unsigned int)(0), (unsigned char)(0), (unsigned char)(0), (unsigned int)((unsigned int)fnt_pstart), (unsigned short)((unsigned short)fnt_pc), zT_644, zT_645);
    fnt_tid = zT_654;
    zT_656 = "OPTVOID:fntT";
    zT_658 = 12;
    zT_657.ptr = zT_656;
    zT_657.len = zT_658;
    opm3_m = zT_657;
    zT_659 = opm3_m;
    zT_660 = fnt_tid;
    zF_C914CB83_markerWriteInt(zT_659, zT_660);
    zT_661 = env->typereg;
    zT_662 = fnt_tid;
    zF_263F0272_typeRegistryMarkFnP(zT_661, zT_662);
    zT_664 = env->typereg;
    zT_665 = fnt_tid;
    zT_669 = zF_8C0DFBC3_typeRegistryGetOrCr(zT_664, zT_665, (unsigned char)(0));
    return zT_669;
    z_bb_136:
    zT_635 = fnt_a + (unsigned int)(1);
    fnt_a = zT_635;
    goto z_bb_133;
    z_bb_137:
    zT_673 = node.kind;
    if ((unsigned char)(zT_673 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_init))) goto z_bb_140; else goto z_bb_139;
    z_bb_138:
    zT_994 = "UND:n";
    zT_996 = 5;
    zT_995.ptr = zT_994;
    zT_995.len = zT_996;
    und_nm2 = zT_995;
    zT_997 = und_nm2;
    zT_998 = node_idx;
    zF_C914CB83_markerWriteInt(zT_997, zT_998);
    zT_1000 = "UND:k";
    zT_1002 = 5;
    zT_1001.ptr = zT_1000;
    zT_1001.len = zT_1002;
    und_km = zT_1001;
    zT_1003 = und_km;
    zT_1005 = node.kind;
    zF_C914CB83_markerWriteInt(zT_1003, (unsigned int)((unsigned int)zT_1005));
    return (unsigned int)(18);
    z_bb_139:
    zT_678 = node.kind;
    zT_677 = zT_678 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_init);
    goto z_bb_141;
    z_bb_140:
    zT_677 = 1;
    goto z_bb_141;
    z_bb_141:
    if (zT_677) goto z_bb_143; else goto z_bb_142;
    z_bb_142:
    zT_683 = node.kind;
    zT_682 = zT_683 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_tuple_literal);
    goto z_bb_144;
    z_bb_143:
    zT_682 = 1;
    goto z_bb_144;
    z_bb_144:
    if (zT_682) goto z_bb_145; else goto z_bb_146;
    z_bb_145:
    zT_688 = env->store;
    zT_689 = env->interner;
    zT_690 = node.child_0;
    zT_694 = zF_54996FA4_typeResolverIsInfer(zT_688, zT_689, zT_690);
    zT_687 = zT_694;
    goto z_bb_147;
    z_bb_146:
    zT_687 = 0;
    goto z_bb_147;
    z_bb_147:
    if (zT_687) goto z_bb_148; else goto z_bb_149;
    z_bb_148:
    return (unsigned int)(18);
    z_bb_149:
    zT_697 = env;
    zT_698 = node.child_0;
    zT_703 = zF_F2107C15_resolveTypeExprFull(zT_697, zT_698, (unsigned int)(depth + (unsigned int)(1)));
    child_type = zT_703;
    if ((unsigned char)(child_type == (unsigned int)(18))) goto z_bb_150; else goto z_bb_151;
    z_bb_150:
    return (unsigned int)(18);
    z_bb_151:
    zT_707 = node.kind;
    if ((unsigned char)(zT_707 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_153; else goto z_bb_152;
    z_bb_152:
    zT_712 = node.kind;
    zT_711 = zT_712 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_154;
    z_bb_153:
    zT_711 = 1;
    goto z_bb_154;
    z_bb_154:
    if (zT_711) goto z_bb_155; else goto z_bb_156;
    z_bb_155:
    zT_717 = "PTR:i";
    zT_719 = 5;
    zT_718.ptr = zT_717;
    zT_718.len = zT_719;
    ptm = zT_718;
    zT_720 = ptm;
    zF_48AC7B3A_markerWrite(zT_720);
    zT_721 = node_idx;
    zF_C8A36147_markerU32(zT_721);
    zT_723 = "k";
    zT_725 = 1;
    zT_724.ptr = zT_723;
    zT_724.len = zT_725;
    ptkm = zT_724;
    zT_726 = ptkm;
    zF_48AC7B3A_markerWrite(zT_726);
    zT_728 = node.kind;
    zF_C8A36147_markerU32((unsigned int)((unsigned int)zT_728));
    zT_731 = "c";
    zT_733 = 1;
    zT_732.ptr = zT_731;
    zT_732.len = zT_733;
    ptcm = zT_732;
    zT_734 = ptcm;
    zF_48AC7B3A_markerWrite(zT_734);
    zT_735 = child_type;
    zF_C8A36147_markerU32(zT_735);
    zT_737 = node.flags;
    zT_741 = (unsigned char)(zT_737 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_741;
    zT_743 = node.flags;
    zT_747 = (unsigned char)(zT_743 & (unsigned char)(2)) != (unsigned char)(0);
    is_volatile = zT_747;
    zT_748 = node.kind;
    if ((unsigned char)(zT_748 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_157; else goto z_bb_159;
    z_bb_156:
    zT_788 = node.kind;
    if ((unsigned char)(zT_788 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type))) goto z_bb_160; else goto z_bb_161;
    z_bb_157:
    zT_753 = env->typereg;
    zT_754 = child_type;
    zT_755 = is_const;
    zT_756 = is_volatile;
    zT_758 = zF_0C0306D6_typeRegistryGetOrCr(zT_753, zT_754, zT_755, zT_756);
    ptr_tid = zT_758;
    zT_760 = "P";
    zT_762 = 1;
    zT_761.ptr = zT_760;
    zT_761.len = zT_762;
    ppm = zT_761;
    zT_763 = ppm;
    zF_48AC7B3A_markerWrite(zT_763);
    zT_764 = ptr_tid;
    zF_C8A36147_markerU32(zT_764);
    zT_766 = "\n";
    zT_768 = 1;
    zT_767.ptr = zT_766;
    zT_767.len = zT_768;
    pnl = zT_767;
    zT_769 = pnl;
    zF_48AC7B3A_markerWrite(zT_769);
    return ptr_tid;
    goto z_bb_156;
    z_bb_159:
    zT_771 = env->typereg;
    zT_772 = child_type;
    zT_773 = is_const;
    zT_774 = is_volatile;
    zT_776 = zF_827207A1_typeRegistryGetOrCr(zT_771, zT_772, zT_773, zT_774);
    ptr_tid2 = zT_776;
    zT_778 = "M";
    zT_780 = 1;
    zT_779.ptr = zT_778;
    zT_779.len = zT_780;
    ppm2 = zT_779;
    zT_781 = ppm2;
    zF_48AC7B3A_markerWrite(zT_781);
    zT_782 = ptr_tid2;
    zF_C8A36147_markerU32(zT_782);
    zT_784 = "\n";
    zT_786 = 1;
    zT_785.ptr = zT_784;
    zT_785.len = zT_786;
    pnl2 = zT_785;
    zT_787 = pnl2;
    zF_48AC7B3A_markerWrite(zT_787);
    return ptr_tid2;
    z_bb_160:
    zT_793 = node.flags;
    zT_797 = (unsigned char)(zT_793 & (unsigned char)(1)) != (unsigned char)(0);
    is_const = zT_797;
    zT_799 = env->typereg;
    zT_800 = child_type;
    zT_801 = is_const;
    zT_803 = zF_8FC81A87_typeRegistryGetOrCr(zT_799, zT_800, zT_801);
    sl_tid = zT_803;
    zT_805 = "SL:e";
    zT_807 = 4;
    zT_806.ptr = zT_805;
    zT_806.len = zT_807;
    sm = zT_806;
    zT_808 = sm;
    zF_48AC7B3A_markerWrite(zT_808);
    zT_809 = child_type;
    zF_C8A36147_markerU32(zT_809);
    zT_811 = "s";
    zT_813 = 1;
    zT_812.ptr = zT_811;
    zT_812.len = zT_813;
    s2 = zT_812;
    zT_814 = s2;
    zF_48AC7B3A_markerWrite(zT_814);
    zT_815 = sl_tid;
    zF_C8A36147_markerU32(zT_815);
    zT_817 = "\n";
    zT_819 = 1;
    zT_818.ptr = zT_817;
    zT_818.len = zT_819;
    s3 = zT_818;
    zT_820 = s3;
    zF_48AC7B3A_markerWrite(zT_820);
    return sl_tid;
    z_bb_161:
    zT_821 = node.kind;
    if ((unsigned char)(zT_821 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type))) goto z_bb_162; else goto z_bb_163;
    z_bb_162:
    zT_826 = "OPTVOID:opt";
    zT_828 = 11;
    zT_827.ptr = zT_826;
    zT_827.len = zT_828;
    optvd_m = zT_827;
    zT_829 = optvd_m;
    zT_830 = child_type;
    zF_C914CB83_markerWriteInt(zT_829, zT_830);
    zT_832 = env->typereg;
    zT_833 = child_type;
    zT_835 = zF_74A7234F_typeRegistryGetOrCr(zT_832, zT_833);
    optvd_tid = zT_835;
    zT_837 = "OPTVOID:optR";
    zT_839 = 12;
    zT_838.ptr = zT_837;
    zT_838.len = zT_839;
    optvd_rm = zT_838;
    zT_840 = optvd_rm;
    zT_841 = optvd_tid;
    zF_C914CB83_markerWriteInt(zT_840, zT_841);
    return optvd_tid;
    z_bb_163:
    zT_842 = node.kind;
    if ((unsigned char)(zT_842 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type))) goto z_bb_164; else goto z_bb_165;
    z_bb_164:
    zT_847 = "T0";
    zT_849 = 2;
    zT_848.ptr = zT_847;
    zT_848.len = zT_849;
    t0m = zT_848;
    zT_850 = t0m;
    zF_48AC7B3A_markerWrite(zT_850);
    zT_852 = "T1e";
    zT_854 = 3;
    zT_853.ptr = zT_852;
    zT_853.len = zT_854;
    t1m = zT_853;
    zT_855 = t1m;
    zF_48AC7B3A_markerWrite(zT_855);
    zT_856 = child_type;
    zF_C8A36147_markerU32(zT_856);
    zT_857 = node.child_1;
    zT_858 = 0;
    if ((unsigned char)(zT_857 != (unsigned int)zT_858)) goto z_bb_166; else goto z_bb_167;
    z_bb_165:
    goto z_bb_138;
    z_bb_166:
    zT_861 = env->store;
    zT_862 = node.child_1;
    zT_865 = zF_FCDD1D35_astStoreNodeAt(zT_861, zT_862);
    sz_node = zT_865;
    zT_867 = 0;
    arr_len = zT_867;
    zT_869 = 0;
    arr_resolved = zT_869;
    zT_871 = env;
    zT_872 = node.child_1;
    zT_876 = zF_6D0DD27D_evalConstU32Full(zT_871, zT_872, (unsigned int)(0));
    alf = zT_876;
    if ((unsigned char)(alf != (unsigned int)(4294967295u))) goto z_bb_168; else goto z_bb_169;
    z_bb_167:
    return (unsigned int)(18);
    z_bb_168:
    arr_len = alf;
    zT_879 = 1;
    arr_resolved = zT_879;
    goto z_bb_169;
    z_bb_169:
    zT_881 = "T2L";
    zT_883 = 3;
    zT_882.ptr = zT_881;
    zT_882.len = zT_883;
    t2m = zT_882;
    zT_884 = t2m;
    zF_48AC7B3A_markerWrite(zT_884);
    zT_885 = arr_len;
    zF_C8A36147_markerU32(zT_885);
    if (arr_resolved) goto z_bb_170; else goto z_bb_171;
    z_bb_170:
    zT_887 = env->typereg;
    zT_888 = child_type;
    zT_889 = arr_len;
    zT_891 = zF_BA693C74_typeRegistryGetOrCr(zT_887, zT_888, zT_889);
    at = zT_891;
    zT_893 = "T3a";
    zT_895 = 3;
    zT_894.ptr = zT_893;
    zT_894.len = zT_895;
    t3m = zT_894;
    zT_896 = t3m;
    zF_48AC7B3A_markerWrite(zT_896);
    zT_897 = at;
    zF_C8A36147_markerU32(zT_897);
    if ((unsigned char)(at != (unsigned int)(18))) goto z_bb_172; else goto z_bb_174;
    z_bb_171:
    zT_911 = 0;
    sz_is_inferred = zT_911;
    zT_912 = sz_node.kind;
    if ((unsigned char)(zT_912 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_175; else goto z_bb_176;
    z_bb_172:
    zT_901 = "A";
    zT_903 = 1;
    zT_902.ptr = zT_901;
    zT_902.len = zT_903;
    am = zT_902;
    zT_904 = am;
    zF_48AC7B3A_markerWrite(zT_904);
    goto z_bb_173;
    z_bb_173:
    return at;
    z_bb_174:
    zT_906 = "a";
    zT_908 = 1;
    zT_907.ptr = zT_906;
    zT_907.len = zT_908;
    am = zT_907;
    zT_909 = am;
    zF_48AC7B3A_markerWrite(zT_909);
    goto z_bb_173;
    z_bb_175:
    zT_917 = env->store;
    zT_918 = node.child_1;
    zT_921 = zF_53458827_astStoreIdentifier(zT_917, zT_918);
    sz_name = zT_921;
    zT_923 = env->interner;
    zT_924 = sz_name;
    zT_926 = zF_9134020D_stringInternerGet(zT_923, zT_924);
    sz_text = zT_926;
    zT_928 = sz_text.len;
    if ((unsigned char)(zT_928 == (unsigned int)(1))) goto z_bb_177; else goto z_bb_178;
    z_bb_176:
    if (sz_is_inferred) goto z_bb_182; else goto z_bb_184;
    z_bb_177:
    zT_932 = sz_text.ptr;
    zT_933 = 0;
    zT_934 = zT_932[zT_933];
    zT_931 = zT_934 == (unsigned char)(95);
    goto z_bb_179;
    z_bb_178:
    zT_931 = 0;
    goto z_bb_179;
    z_bb_179:
    if (zT_931) goto z_bb_180; else goto z_bb_181;
    z_bb_180:
    zT_937 = 1;
    sz_is_inferred = zT_937;
    goto z_bb_181;
    z_bb_181:
    goto z_bb_176;
    z_bb_182:
    zT_938 = env->diag;
    zT_939 = zT_938.has_value;
    if (zT_939) goto z_bb_185; else goto z_bb_186;
    z_bb_183:
    goto z_bb_167;
    z_bb_184:
    zT_964 = env->diag;
    zT_965 = zT_964.has_value;
    if (zT_965) goto z_bb_189; else goto z_bb_190;
    z_bb_185:
    dg = zT_938.value;
    zT_941 = dg;
    zT_942 = node_idx;
    zT_943 = zF_4DD9DB2D_diagnosticCollector(zT_941, zT_942);
    if (zT_943) goto z_bb_187; else goto z_bb_188;
    z_bb_186:
    goto z_bb_183;
    z_bb_187:
    zT_945 = "unable to infer array size";
    zT_947 = 26;
    zT_946.ptr = zT_945;
    zT_946.len = zT_947;
    ail_msg = zT_946;
    zT_948 = dg;
    zT_951 = env->source_file_id;
    zT_952 = sz_node.span_start;
    zT_959 = sz_node.span_start;
    zT_960 = sz_node.span_len;
    zT_954 = ail_msg;
    zT_963 = zF_C82559AC_diagnosticCollector(zT_948, (unsigned char)(0), (unsigned short)(3000), zT_951, zT_952, (unsigned int)(zT_959 + (unsigned int)((unsigned int)zT_960)), zT_954);
    (void)zT_963;
    goto z_bb_188;
    z_bb_188:
    goto z_bb_186;
    z_bb_189:
    dg = zT_964.value;
    zT_967 = dg;
    zT_968 = node_idx;
    zT_969 = zF_4DD9DB2D_diagnosticCollector(zT_967, zT_968);
    if (zT_969) goto z_bb_191; else goto z_bb_192;
    z_bb_190:
    goto z_bb_183;
    z_bb_191:
    zT_971 = "array size is not a constant expression";
    zT_973 = 39;
    zT_972.ptr = zT_971;
    zT_972.len = zT_973;
    asn_msg = zT_972;
    zT_974 = dg;
    zT_977 = env->source_file_id;
    zT_978 = sz_node.span_start;
    zT_987 = sz_node.span_start;
    zT_988 = sz_node.span_len;
    zT_980 = asn_msg;
    zT_991 = zF_C82559AC_diagnosticCollector(zT_974, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3050_ARRAY_SIZE_NOT_CONSTANT)), zT_977, zT_978, (unsigned int)(zT_987 + (unsigned int)((unsigned int)zT_988)), zT_980);
    (void)zT_991;
    goto z_bb_192;
    z_bb_192:
    goto z_bb_190;
}

/* resolveDeclAggregateFieldTypes */
void zF_F5C3193B_resolveDeclAggregat(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int mod_id, unsigned int decl_idx) {
    zT_6B0A7D14_AstStore* zT_4;
    unsigned int zT_5;
    zT_22A7C88B_AstNode zT_7 = {0};
    zT_6B0A7D14_AstStore* zT_9;
    unsigned int zT_10;
    zT_338B7C76_TypeRegistry* zT_15;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    zT_BAEE192E_Opt_10 zT_27 = {0};
    unsigned char zT_28;
    zT_338B7C76_TypeRegistry* zT_31;
    zT_D155D06D_Type* zT_32;
    unsigned int zT_33;
    zT_D155D06D_Type zT_34;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    int zT_42;
    unsigned int zT_43;
    zT_33EF6BFB_TypeKind zT_44;
    zT_338B7C76_TypeRegistry* zT_49;
    zT_406493CE_StructPayload* zT_50;
    unsigned int zT_51;
    unsigned int zT_52;
    zT_406493CE_StructPayload zT_53;
    unsigned short zT_54;
    zT_6B0A7D14_AstStore* zT_58;
    unsigned int zT_59;
    unsigned int zT_64 = 0;
    zT_6B0A7D14_AstStore* zT_66;
    unsigned int zT_67;
    zT_22A7C88B_AstNode zT_69 = {0};
    zT_8143F551_AstKind zT_70;
    unsigned char zT_74;
    unsigned int zT_75;
    int zT_76;
    zT_ABC1EBBE_TypeResolveEnv* zT_79;
    unsigned int zT_80;
    unsigned int zT_84 = 0;
    unsigned char* zT_86;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_87;
    unsigned int zT_88;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_89;
    unsigned int zT_90;
    zT_6B0A7D14_AstStore* zT_91;
    unsigned int zT_92;
    unsigned int zT_94 = 0;
    unsigned char* zT_96;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_97;
    unsigned int zT_98;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_99;
    unsigned int zT_100;
    zT_338B7C76_TypeRegistry* zT_103;
    zT_2DF01B61_FieldEntry* zT_104;
    unsigned int zT_105;
    zT_2DF01B61_FieldEntry* zT_108;
    unsigned char* zT_110;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_111;
    unsigned int zT_112;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_113;
    unsigned int zT_115;
    unsigned char* zT_120;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_121;
    unsigned int zT_122;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_123;
    unsigned int zT_124;
    int zT_125;
    unsigned int zT_127;
    zT_33EF6BFB_TypeKind zT_128;
    zT_338B7C76_TypeRegistry* zT_133;
    zT_666DC2E1_TuplePayload* zT_134;
    unsigned int zT_135;
    unsigned int zT_136;
    zT_666DC2E1_TuplePayload zT_137;
    unsigned short zT_138;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_143;
    unsigned int zT_148 = 0;
    zT_6B0A7D14_AstStore* zT_150;
    unsigned int zT_151;
    zT_22A7C88B_AstNode zT_153 = {0};
    zT_8143F551_AstKind zT_154;
    unsigned char zT_158;
    unsigned int zT_159;
    int zT_160;
    zT_ABC1EBBE_TypeResolveEnv* zT_163;
    unsigned int zT_164;
    unsigned int zT_168 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_171;
    unsigned int zT_172;
    unsigned int zT_173;
    unsigned char zT_174 = 0;
    zT_338B7C76_TypeRegistry* zT_175;
    unsigned int* zT_176;
    unsigned int zT_177;
    unsigned int zT_179;
    int zT_180;
    unsigned int zT_182;
    zT_33EF6BFB_TypeKind zT_183;
    zT_338B7C76_TypeRegistry* zT_188;
    zT_54FF90FA_TaggedUnionPayload* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_54FF90FA_TaggedUnionPayload zT_192;
    unsigned char* zT_194;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_195;
    unsigned int zT_196;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_197;
    unsigned int zT_199;
    unsigned char* zT_202;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_203;
    unsigned int zT_204;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_205;
    unsigned short zT_207;
    unsigned short zT_209;
    zT_6B0A7D14_AstStore* zT_213;
    unsigned int zT_214;
    zT_6B0A7D14_AstStore* zT_216;
    unsigned int zT_217;
    unsigned int zT_222 = 0;
    zT_22A7C88B_AstNode zT_223 = {0};
    zT_8143F551_AstKind zT_224;
    unsigned char zT_228;
    unsigned int zT_229;
    int zT_230;
    zT_ABC1EBBE_TypeResolveEnv* zT_233;
    unsigned int zT_234;
    unsigned int zT_238 = 0;
    unsigned char* zT_240;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_241;
    unsigned int zT_242;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_243;
    unsigned char* zT_247;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_248;
    unsigned int zT_249;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_250;
    unsigned int zT_251;
    unsigned char* zT_253;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_254;
    unsigned int zT_255;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_256;
    unsigned int zT_257;
    zT_6B0A7D14_AstStore* zT_258;
    unsigned int zT_259;
    zT_6B0A7D14_AstStore* zT_261;
    unsigned int zT_262;
    unsigned int zT_267 = 0;
    unsigned int zT_268 = 0;
    unsigned char* zT_270;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_271;
    unsigned int zT_272;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_273;
    unsigned int zT_274;
    unsigned char* zT_276;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_277;
    unsigned int zT_278;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_279;
    zT_338B7C76_TypeRegistry* zT_282;
    zT_2DF01B61_FieldEntry* zT_283;
    unsigned int zT_284;
    zT_2DF01B61_FieldEntry* zT_287;
    unsigned char* zT_289;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_290;
    unsigned int zT_291;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_292;
    unsigned int zT_294;
    unsigned char* zT_299;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_300;
    unsigned int zT_301;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_302;
    unsigned int zT_303;
    unsigned char* zT_305;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_306;
    unsigned int zT_307;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_308;
    int zT_309;
    unsigned int zT_311;
    zT_33EF6BFB_TypeKind zT_312;
    unsigned char zT_316;
    zT_33EF6BFB_TypeKind zT_317;
    zT_338B7C76_TypeRegistry* zT_322;
    zT_AF9231A2_UnionPayload* zT_323;
    unsigned int zT_324;
    unsigned int zT_325;
    zT_AF9231A2_UnionPayload zT_326;
    unsigned short zT_327;
    zT_6B0A7D14_AstStore* zT_331;
    unsigned int zT_332;
    zT_6B0A7D14_AstStore* zT_334;
    unsigned int zT_335;
    unsigned int zT_340 = 0;
    zT_22A7C88B_AstNode zT_341 = {0};
    zT_8143F551_AstKind zT_342;
    unsigned char zT_346;
    unsigned int zT_347;
    int zT_348;
    zT_ABC1EBBE_TypeResolveEnv* zT_351;
    unsigned int zT_352;
    unsigned int zT_356 = 0;
    zT_338B7C76_TypeRegistry* zT_359;
    zT_2DF01B61_FieldEntry* zT_360;
    unsigned int zT_361;
    zT_2DF01B61_FieldEntry* zT_364;
    int zT_365;
    unsigned int zT_367;
    zT_22A7C88B_AstNode decl;
    zT_BAEE192E_Opt_10 spid;
    unsigned int stid;
    zT_D155D06D_Type sty;
    unsigned int fi2;
    zT_406493CE_StructPayload sp;
    unsigned int fchild;
    zT_22A7C88B_AstNode fd;
    unsigned int ft;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_pn;
    zT_8F083A69_Slice_zT_0B42B2F8_u b2_tn;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u fsw_tm;
    zT_666DC2E1_TuplePayload tp_t;
    unsigned int tfchild;
    zT_22A7C88B_AstNode tfd;
    unsigned int tft;
    zT_54FF90FA_TaggedUnionPayload tp;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fsm;
    zT_8F083A69_Slice_zT_0B42B2F8_u tui_fcm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dft_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtwr_m;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_nm;
    zT_8F083A69_Slice_zT_0B42B2F8_u ftw_tm;
    zT_8F083A69_Slice_zT_0B42B2F8_u dtsk_m;
    zT_AF9231A2_UnionPayload up;
    env->module_id = mod_id;
    zT_4 = env->store;
    zT_5 = decl_idx;
    zT_7 = zF_FCDD1D35_astStoreNodeAt(zT_4, zT_5);
    decl = zT_7;
    zT_9 = env->store;
    zT_10 = decl.child_1;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_9, zT_10);
    zT_15 = env->typereg;
    zT_21 = env->store;
    zT_22 = decl_idx;
    zT_24 = zF_8BA26B9E_astStoreNodePayload(zT_21, zT_22);
    zT_27 = zF_0EB68360_nameCacheGet(zT_15, (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)mod_id) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_24)));
    spid = zT_27;
    zT_28 = spid.has_value;
    if (zT_28) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    stid = spid.value;
    zT_31 = env->typereg;
    zT_32 = zT_31->types_items;
    zT_33 = (unsigned int)stid;
    zT_34 = zT_32[zT_33];
    sty = zT_34;
    zT_36 = env->store;
    zT_37 = decl.child_1;
    (void)zF_152E19CB_astStoreNodeExtraCh(zT_36, zT_37);
    zT_42 = 0;
    zT_43 = (unsigned int)zT_42;
    fi2 = zT_43;
    zT_44 = sty.kind;
    if ((unsigned char)(zT_44 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_struct_type))) goto z_bb_3; else goto z_bb_5;
    z_bb_2:
    return;
    z_bb_3:
    zT_49 = env->typereg;
    zT_50 = zT_49->st_items;
    zT_51 = sty.payload_idx;
    zT_52 = (unsigned int)zT_51;
    zT_53 = zT_50[zT_52];
    sp = zT_53;
    goto z_bb_6;
    z_bb_4:
    goto z_bb_2;
    z_bb_5:
    zT_128 = sty.kind;
    if ((unsigned char)(zT_128 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tuple_type))) goto z_bb_17; else goto z_bb_19;
    z_bb_6:
    zT_54 = sp.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_54))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    zT_58 = env->store;
    zT_59 = decl.child_1;
    zT_64 = zF_B10B1BC1_astStoreNodeExtraCh(zT_58, zT_59, (unsigned int)((unsigned int)fi2));
    fchild = zT_64;
    zT_66 = env->store;
    zT_67 = fchild;
    zT_69 = zF_FCDD1D35_astStoreNodeAt(zT_66, zT_67);
    fd = zT_69;
    zT_70 = fd.kind;
    if ((unsigned char)(zT_70 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_10; else goto z_bb_11;
    z_bb_8:
    goto z_bb_4;
    z_bb_9:
    zT_125 = 1;
    zT_127 = fi2 + (unsigned int)((unsigned int)zT_125);
    fi2 = zT_127;
    goto z_bb_6;
    z_bb_10:
    zT_75 = fd.child_0;
    zT_76 = 0;
    zT_74 = zT_75 != (unsigned int)zT_76;
    goto z_bb_12;
    z_bb_11:
    zT_74 = 0;
    goto z_bb_12;
    z_bb_12:
    if (zT_74) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    zT_79 = env;
    zT_80 = fd.child_0;
    zT_84 = zF_F2107C15_resolveTypeExprFull(zT_79, zT_80, (unsigned int)(0));
    ft = zT_84;
    zT_86 = "B2:p";
    zT_88 = 4;
    zT_87.ptr = zT_86;
    zT_87.len = zT_88;
    b2_pn = zT_87;
    zT_89 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_89);
    zT_91 = env->store;
    zT_92 = fchild;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_91, zT_92);
    zT_90 = zT_94;
    zF_C8A36147_markerU32(zT_90);
    zT_96 = "t";
    zT_98 = 1;
    zT_97.ptr = zT_96;
    zT_97.len = zT_98;
    b2_tn = zT_97;
    zT_99 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_99);
    zT_100 = ft;
    zF_C8A36147_markerU32(zT_100);
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_15; else goto z_bb_16;
    z_bb_14:
    goto z_bb_9;
    z_bb_15:
    zT_103 = env->typereg;
    zT_104 = zT_103->fe_items;
    zT_105 = sp.fields_start;
    zT_108 = zT_104 + (unsigned int)((unsigned int)((unsigned int)zT_105) + fi2);
    zT_108->type_id = ft;
    zT_110 = "FSW:n";
    zT_112 = 5;
    zT_111.ptr = zT_110;
    zT_111.len = zT_112;
    fsw_nm = zT_111;
    zT_113 = fsw_nm;
    zT_115 = sp.fields_start;
    zF_C914CB83_markerWriteInt(zT_113, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_115) + fi2)));
    zT_120 = "FSW:t";
    zT_122 = 5;
    zT_121.ptr = zT_120;
    zT_121.len = zT_122;
    fsw_tm = zT_121;
    zT_123 = fsw_tm;
    zT_124 = ft;
    zF_C914CB83_markerWriteInt(zT_123, zT_124);
    goto z_bb_16;
    z_bb_16:
    goto z_bb_14;
    z_bb_17:
    zT_133 = env->typereg;
    zT_134 = zT_133->tup_items;
    zT_135 = sty.payload_idx;
    zT_136 = (unsigned int)zT_135;
    zT_137 = zT_134[zT_136];
    tp_t = zT_137;
    goto z_bb_20;
    z_bb_18:
    goto z_bb_4;
    z_bb_19:
    zT_183 = sty.kind;
    if ((unsigned char)(zT_183 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_tagged_union_type))) goto z_bb_31; else goto z_bb_33;
    z_bb_20:
    zT_138 = tp_t.elems_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_138))) goto z_bb_21; else goto z_bb_22;
    z_bb_21:
    zT_142 = env->store;
    zT_143 = decl.child_1;
    zT_148 = zF_B10B1BC1_astStoreNodeExtraCh(zT_142, zT_143, (unsigned int)((unsigned int)fi2));
    tfchild = zT_148;
    zT_150 = env->store;
    zT_151 = tfchild;
    zT_153 = zF_FCDD1D35_astStoreNodeAt(zT_150, zT_151);
    tfd = zT_153;
    zT_154 = tfd.kind;
    if ((unsigned char)(zT_154 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_24; else goto z_bb_25;
    z_bb_22:
    goto z_bb_18;
    z_bb_23:
    zT_180 = 1;
    zT_182 = fi2 + (unsigned int)((unsigned int)zT_180);
    fi2 = zT_182;
    goto z_bb_20;
    z_bb_24:
    zT_159 = tfd.child_0;
    zT_160 = 0;
    zT_158 = zT_159 != (unsigned int)zT_160;
    goto z_bb_26;
    z_bb_25:
    zT_158 = 0;
    goto z_bb_26;
    z_bb_26:
    if (zT_158) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_163 = env;
    zT_164 = tfd.child_0;
    zT_168 = zF_F2107C15_resolveTypeExprFull(zT_163, zT_164, (unsigned int)(0));
    tft = zT_168;
    if ((unsigned char)(tft != (unsigned int)(18))) goto z_bb_29; else goto z_bb_30;
    z_bb_28:
    goto z_bb_23;
    z_bb_29:
    zT_171 = env;
    zT_172 = tft;
    zT_173 = tfchild;
    zT_174 = zF_E2A017C6_tupleElemArrayUnsup(zT_171, zT_172, zT_173);
    (void)zT_174;
    zT_175 = env->typereg;
    zT_176 = zT_175->xt_items;
    zT_177 = tp_t.elems_start;
    zT_179 = (unsigned int)((unsigned int)zT_177) + fi2;
    zT_176[zT_179] = tft;
    goto z_bb_30;
    z_bb_30:
    goto z_bb_28;
    z_bb_31:
    zT_188 = env->typereg;
    zT_189 = zT_188->tu_items;
    zT_190 = sty.payload_idx;
    zT_191 = (unsigned int)zT_190;
    zT_192 = zT_189[zT_191];
    tp = zT_192;
    zT_194 = "TUI:fs";
    zT_196 = 6;
    zT_195.ptr = zT_194;
    zT_195.len = zT_196;
    tui_fsm = zT_195;
    zT_197 = tui_fsm;
    zT_199 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_197, (unsigned int)((unsigned int)zT_199));
    zT_202 = "TUI:fc";
    zT_204 = 6;
    zT_203.ptr = zT_202;
    zT_203.len = zT_204;
    tui_fcm = zT_203;
    zT_205 = tui_fcm;
    zT_207 = tp.fields_count;
    zF_C914CB83_markerWriteInt(zT_205, (unsigned int)((unsigned int)zT_207));
    goto z_bb_34;
    z_bb_32:
    goto z_bb_18;
    z_bb_33:
    zT_312 = sty.kind;
    if ((unsigned char)(zT_312 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_union_type))) goto z_bb_47; else goto z_bb_46;
    z_bb_34:
    zT_209 = tp.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_209))) goto z_bb_35; else goto z_bb_36;
    z_bb_35:
    zT_213 = env->store;
    zT_216 = env->store;
    zT_217 = decl.child_1;
    zT_222 = zF_B10B1BC1_astStoreNodeExtraCh(zT_216, zT_217, (unsigned int)((unsigned int)fi2));
    zT_214 = zT_222;
    zT_223 = zF_FCDD1D35_astStoreNodeAt(zT_213, zT_214);
    fd = zT_223;
    zT_224 = fd.kind;
    if ((unsigned char)(zT_224 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_38; else goto z_bb_39;
    z_bb_36:
    goto z_bb_32;
    z_bb_37:
    zT_309 = 1;
    zT_311 = fi2 + (unsigned int)((unsigned int)zT_309);
    fi2 = zT_311;
    goto z_bb_34;
    z_bb_38:
    zT_229 = fd.child_0;
    zT_230 = 0;
    zT_228 = zT_229 != (unsigned int)zT_230;
    goto z_bb_40;
    z_bb_39:
    zT_228 = 0;
    goto z_bb_40;
    z_bb_40:
    if (zT_228) goto z_bb_41; else goto z_bb_42;
    z_bb_41:
    zT_233 = env;
    zT_234 = fd.child_0;
    zT_238 = zF_F2107C15_resolveTypeExprFull(zT_233, zT_234, (unsigned int)(0));
    ft = zT_238;
    zT_240 = "DFT:n";
    zT_242 = 5;
    zT_241.ptr = zT_240;
    zT_241.len = zT_242;
    dft_nm = zT_241;
    zT_243 = dft_nm;
    zF_C914CB83_markerWriteInt(zT_243, (unsigned int)((unsigned int)fi2));
    zT_247 = "DFT:t";
    zT_249 = 5;
    zT_248.ptr = zT_247;
    zT_248.len = zT_249;
    dft_tm = zT_248;
    zT_250 = dft_tm;
    zT_251 = ft;
    zF_C914CB83_markerWriteInt(zT_250, zT_251);
    zT_253 = "B2:p";
    zT_255 = 4;
    zT_254.ptr = zT_253;
    zT_254.len = zT_255;
    b2_pn = zT_254;
    zT_256 = b2_pn;
    zF_48AC7B3A_markerWrite(zT_256);
    zT_258 = env->store;
    zT_261 = env->store;
    zT_262 = decl.child_1;
    zT_267 = zF_B10B1BC1_astStoreNodeExtraCh(zT_261, zT_262, (unsigned int)((unsigned int)fi2));
    zT_259 = zT_267;
    zT_268 = zF_8BA26B9E_astStoreNodePayload(zT_258, zT_259);
    zT_257 = zT_268;
    zF_C8A36147_markerU32(zT_257);
    zT_270 = "t";
    zT_272 = 1;
    zT_271.ptr = zT_270;
    zT_271.len = zT_272;
    b2_tn = zT_271;
    zT_273 = b2_tn;
    zF_48AC7B3A_markerWrite(zT_273);
    zT_274 = ft;
    zF_C8A36147_markerU32(zT_274);
    zT_276 = "DTWR\n";
    zT_278 = 5;
    zT_277.ptr = zT_276;
    zT_277.len = zT_278;
    dtwr_m = zT_277;
    zT_279 = dtwr_m;
    zF_48AC7B3A_markerWrite(zT_279);
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_43; else goto z_bb_45;
    z_bb_42:
    goto z_bb_37;
    z_bb_43:
    zT_282 = env->typereg;
    zT_283 = zT_282->fe_items;
    zT_284 = tp.fields_start;
    zT_287 = zT_283 + (unsigned int)((unsigned int)((unsigned int)zT_284) + fi2);
    zT_287->type_id = ft;
    zT_289 = "FTW:n";
    zT_291 = 5;
    zT_290.ptr = zT_289;
    zT_290.len = zT_291;
    ftw_nm = zT_290;
    zT_292 = ftw_nm;
    zT_294 = tp.fields_start;
    zF_C914CB83_markerWriteInt(zT_292, (unsigned int)((unsigned int)(unsigned int)((unsigned int)((unsigned int)zT_294) + fi2)));
    zT_299 = "FTW:t";
    zT_301 = 5;
    zT_300.ptr = zT_299;
    zT_300.len = zT_301;
    ftw_tm = zT_300;
    zT_302 = ftw_tm;
    zT_303 = ft;
    zF_C914CB83_markerWriteInt(zT_302, zT_303);
    goto z_bb_44;
    z_bb_44:
    goto z_bb_42;
    z_bb_45:
    zT_305 = "DTSK\n";
    zT_307 = 5;
    zT_306.ptr = zT_305;
    zT_306.len = zT_307;
    dtsk_m = zT_306;
    zT_308 = dtsk_m;
    zF_48AC7B3A_markerWrite(zT_308);
    goto z_bb_44;
    z_bb_46:
    zT_317 = sty.kind;
    zT_316 = zT_317 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_packed_union_type);
    goto z_bb_48;
    z_bb_47:
    zT_316 = 1;
    goto z_bb_48;
    z_bb_48:
    if (zT_316) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_322 = env->typereg;
    zT_323 = zT_322->un_items;
    zT_324 = sty.payload_idx;
    zT_325 = (unsigned int)zT_324;
    zT_326 = zT_323[zT_325];
    up = zT_326;
    goto z_bb_51;
    z_bb_50:
    goto z_bb_32;
    z_bb_51:
    zT_327 = up.fields_count;
    if ((unsigned char)(fi2 < (unsigned int)((unsigned int)zT_327))) goto z_bb_52; else goto z_bb_53;
    z_bb_52:
    zT_331 = env->store;
    zT_334 = env->store;
    zT_335 = decl.child_1;
    zT_340 = zF_B10B1BC1_astStoreNodeExtraCh(zT_334, zT_335, (unsigned int)((unsigned int)fi2));
    zT_332 = zT_340;
    zT_341 = zF_FCDD1D35_astStoreNodeAt(zT_331, zT_332);
    fd = zT_341;
    zT_342 = fd.kind;
    if ((unsigned char)(zT_342 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_decl))) goto z_bb_55; else goto z_bb_56;
    z_bb_53:
    goto z_bb_50;
    z_bb_54:
    zT_365 = 1;
    zT_367 = fi2 + (unsigned int)((unsigned int)zT_365);
    fi2 = zT_367;
    goto z_bb_51;
    z_bb_55:
    zT_347 = fd.child_0;
    zT_348 = 0;
    zT_346 = zT_347 != (unsigned int)zT_348;
    goto z_bb_57;
    z_bb_56:
    zT_346 = 0;
    goto z_bb_57;
    z_bb_57:
    if (zT_346) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_351 = env;
    zT_352 = fd.child_0;
    zT_356 = zF_F2107C15_resolveTypeExprFull(zT_351, zT_352, (unsigned int)(0));
    ft = zT_356;
    if ((unsigned char)(ft != (unsigned int)(18))) goto z_bb_60; else goto z_bb_61;
    z_bb_59:
    goto z_bb_54;
    z_bb_60:
    zT_359 = env->typereg;
    zT_360 = zT_359->fe_items;
    zT_361 = up.fields_start;
    zT_364 = zT_360 + (unsigned int)((unsigned int)((unsigned int)zT_361) + fi2);
    zT_364->type_id = ft;
    goto z_bb_61;
    z_bb_61:
    goto z_bb_59;
}

/* varDeclInitNeedsNameCache */
unsigned char zF_C7A2E0B8_varDeclInitNeedsNam(zT_8143F551_AstKind init_kind) {
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned char)(0);
    z_bb_2:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return (unsigned char)(0);
    z_bb_4:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_enum_decl))) goto z_bb_5; else goto z_bb_6;
    z_bb_5:
    return (unsigned char)(0);
    z_bb_6:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_set_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned char)(0);
    z_bb_8:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned char)(0);
    z_bb_10:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned char)(0);
    z_bb_12:
    if ((unsigned char)(init_kind == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    return (unsigned char)(0);
    z_bb_14:
    return (unsigned char)(1);
}

/* resolveNamedTypeExpressions */
void zF_D9A1E9B7_resolveNamedTypeExp(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6E8D187B_ModuleEntry* zT_17;
    zT_6E8D187B_ModuleEntry zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    zT_6B0A7D14_AstStore* zT_26;
    unsigned int zT_27;
    unsigned int zT_29 = 0;
    int zT_31;
    unsigned int zT_32;
    zT_6B0A7D14_AstStore* zT_36;
    unsigned int zT_37;
    unsigned int zT_41 = 0;
    zT_6B0A7D14_AstStore* zT_43;
    unsigned int zT_44;
    zT_22A7C88B_AstNode zT_46 = {0};
    zT_8143F551_AstKind zT_47;
    unsigned char zT_51;
    unsigned int zT_52;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    zT_22A7C88B_AstNode zT_60 = {0};
    zT_8143F551_AstKind zT_61;
    unsigned char zT_63 = 0;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    unsigned int zT_66;
    unsigned int zT_70 = 0;
    zT_6E8D187B_ModuleEntry* zT_74;
    zT_6E8D187B_ModuleEntry zT_75;
    unsigned int zT_76;
    zT_6B0A7D14_AstStore* zT_80;
    unsigned int zT_81;
    unsigned int zT_83 = 0;
    zT_79FAE712_u64 zT_85;
    zT_338B7C76_TypeRegistry* zT_86;
    zT_79FAE712_u64 zT_87;
    unsigned int zT_88;
    zT_3D7259E2_SymbolRegistry* zT_91;
    unsigned int zT_92;
    unsigned int zT_93;
    zT_6E8D187B_ModuleEntry* zT_95;
    zT_6E8D187B_ModuleEntry zT_96;
    zT_6B0A7D14_AstStore* zT_98;
    unsigned int zT_99;
    unsigned int zT_101 = 0;
    zT_6BEBA1C2_Opt_900 zT_102 = {0};
    unsigned char zT_103;
    int zT_105;
    unsigned int zT_107;
    int zT_108;
    unsigned int zT_110;
    unsigned int ci;
    unsigned int cr;
    unsigned int cd_n;
    unsigned int cdi;
    unsigned int cd_i;
    zT_22A7C88B_AstNode cdcl;
    zT_22A7C88B_AstNode cdinit;
    unsigned int cdtype;
    zT_79FAE712_u64 ck;
    zT_6BEBA1C2_Opt_900 cdsym;
    zT_3A105EF1_Symbol* sp;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    ci = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(ci < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[ci];
    zT_11 = zT_10.ast_root;
    cr = zT_11;
    if ((unsigned char)(cr == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_108 = 1;
    zT_110 = ci + (unsigned int)((unsigned int)zT_108);
    ci = zT_110;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[ci];
    zT_16 = zT_15.id;
    env->module_id = zT_16;
    zT_17 = mods.ptr;
    zT_18 = zT_17[ci];
    zT_19 = zT_18.source_file_id;
    env->source_file_id = zT_19;
    zT_21 = env->store;
    zT_22 = cr;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_21, zT_22);
    zT_26 = env->store;
    zT_27 = cr;
    zT_29 = zF_152E19CB_astStoreNodeExtraCh(zT_26, zT_27);
    cd_n = zT_29;
    zT_31 = 0;
    zT_32 = (unsigned int)zT_31;
    cdi = zT_32;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(cdi < (unsigned int)((unsigned int)cd_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_36 = env->store;
    zT_37 = cr;
    zT_41 = zF_B10B1BC1_astStoreNodeExtraCh(zT_36, zT_37, (unsigned int)((unsigned int)cdi));
    cd_i = zT_41;
    zT_43 = env->store;
    zT_44 = cd_i;
    zT_46 = zF_FCDD1D35_astStoreNodeAt(zT_43, zT_44);
    cdcl = zT_46;
    zT_47 = cdcl.kind;
    if ((unsigned char)(zT_47 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_105 = 1;
    zT_107 = cdi + (unsigned int)((unsigned int)zT_105);
    cdi = zT_107;
    goto z_bb_7;
    z_bb_11:
    zT_52 = cdcl.child_1;
    zT_51 = zT_52 != (unsigned int)(0);
    goto z_bb_13;
    z_bb_12:
    zT_51 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_51) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_56 = env->store;
    zT_57 = cdcl.child_1;
    zT_60 = zF_FCDD1D35_astStoreNodeAt(zT_56, zT_57);
    cdinit = zT_60;
    zT_61 = cdinit.kind;
    zT_63 = zF_C7A2E0B8_varDeclInitNeedsNam(zT_61);
    if (zT_63) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_65 = env;
    zT_66 = cdcl.child_1;
    zT_70 = zF_F2107C15_resolveTypeExprFull(zT_65, zT_66, (unsigned int)(0));
    cdtype = zT_70;
    if ((unsigned char)(cdtype != (unsigned int)(18))) goto z_bb_18; else goto z_bb_19;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_74 = mods.ptr;
    zT_75 = zT_74[ci];
    zT_76 = zT_75.id;
    zT_80 = env->store;
    zT_81 = cd_i;
    zT_83 = zF_8BA26B9E_astStoreNodePayload(zT_80, zT_81);
    zT_85 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_76) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_83);
    ck = zT_85;
    zT_86 = env->typereg;
    zT_87 = ck;
    zT_88 = cdtype;
    zF_5E95558D_nameCachePut(zT_86, zT_87, zT_88);
    zT_91 = env->symbol_reg;
    zT_95 = mods.ptr;
    zT_96 = zT_95[ci];
    zT_92 = zT_96.id;
    zT_98 = env->store;
    zT_99 = cd_i;
    zT_101 = zF_8BA26B9E_astStoreNodePayload(zT_98, zT_99);
    zT_93 = zT_101;
    zT_102 = zF_A398987E_symbolRegistryQuali(zT_91, zT_92, zT_93);
    cdsym = zT_102;
    zT_103 = cdsym.has_value;
    if (zT_103) goto z_bb_20; else goto z_bb_21;
    z_bb_19:
    goto z_bb_17;
    z_bb_20:
    sp = cdsym.value;
    sp->type_id = cdtype;
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
}

/* resolveImportFieldAlias */
unsigned int zF_E8C2AADA_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_072B53A6_ModuleRegistry* module_reg, unsigned int importer_mod_id, unsigned int target_mod_id, unsigned int field_name_id, unsigned int depth) {
    zT_3D7259E2_SymbolRegistry* zT_10;
    unsigned int zT_11;
    unsigned int zT_12;
    zT_6BEBA1C2_Opt_900 zT_14 = {0};
    unsigned char zT_15;
    unsigned int zT_17;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_22A7C88B_AstNode zT_26 = {0};
    zT_8143F551_AstKind zT_27;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    zT_22A7C88B_AstNode zT_37 = {0};
    zT_8143F551_AstKind zT_38;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_48 = {0};
    zT_8143F551_AstKind zT_49;
    zT_072B53A6_ModuleRegistry* zT_55;
    unsigned int zT_56;
    zT_6B0A7D14_AstStore* zT_57;
    unsigned int zT_58;
    unsigned int zT_61 = 0;
    zT_BAEE192E_Opt_10 zT_62 = {0};
    unsigned char zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_65;
    zT_072B53A6_ModuleRegistry* zT_66;
    unsigned int zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_6B0A7D14_AstStore* zT_71;
    unsigned int zT_72;
    unsigned int zT_75 = 0;
    unsigned int zT_77;
    zT_6BEBA1C2_Opt_900 fs;
    zT_3A105EF1_Symbol* fss;
    zT_22A7C88B_AstNode fd;
    zT_22A7C88B_AstNode fi;
    zT_22A7C88B_AstNode fb;
    zT_BAEE192E_Opt_10 t2;
    unsigned int m2;
    z_bb_0:
    if ((unsigned char)(depth > (unsigned int)(8))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return (unsigned int)(18);
    z_bb_2:
    zT_10 = env->symbol_reg;
    zT_11 = target_mod_id;
    zT_12 = field_name_id;
    zT_14 = zF_A398987E_symbolRegistryQuali(zT_10, zT_11, zT_12);
    fs = zT_14;
    zT_15 = fs.has_value;
    if (zT_15) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    fss = fs.value;
    zT_17 = fss->type_id;
    if ((unsigned char)(zT_17 != (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_4:
    return (unsigned int)(18);
    z_bb_5:
    zT_20 = fss->type_id;
    return zT_20;
    z_bb_6:
    zT_22 = env->store;
    zT_23 = fss->decl_node;
    zT_26 = zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    fd = zT_26;
    zT_27 = fd.kind;
    if ((unsigned char)(zT_27 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_7; else goto z_bb_8;
    z_bb_7:
    return (unsigned int)(18);
    z_bb_8:
    zT_33 = env->store;
    zT_34 = fd.child_1;
    zT_37 = zF_FCDD1D35_astStoreNodeAt(zT_33, zT_34);
    fi = zT_37;
    zT_38 = fi.kind;
    if ((unsigned char)(zT_38 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_9; else goto z_bb_10;
    z_bb_9:
    return (unsigned int)(18);
    z_bb_10:
    zT_44 = env->store;
    zT_45 = fi.child_0;
    zT_48 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    fb = zT_48;
    zT_49 = fb.kind;
    if ((unsigned char)(zT_49 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_11; else goto z_bb_12;
    z_bb_11:
    return (unsigned int)(18);
    z_bb_12:
    zT_55 = module_reg;
    zT_57 = env->store;
    zT_58 = fi.child_0;
    zT_61 = zF_8BA26B9E_astStoreNodePayload(zT_57, zT_58);
    zT_56 = zT_61;
    zT_62 = zF_A258E183_moduleRegistryPathT(zT_55, zT_56);
    t2 = zT_62;
    zT_63 = t2.has_value;
    if (zT_63) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    m2 = t2.value;
    zT_65 = env;
    zT_66 = module_reg;
    zT_67 = importer_mod_id;
    zT_68 = m2;
    zT_71 = env->store;
    zT_72 = fd.child_1;
    zT_75 = zF_8BA26B9E_astStoreNodePayload(zT_71, zT_72);
    zT_69 = zT_75;
    zT_77 = depth + (unsigned int)(1);
    env = zT_65;
    module_reg = zT_66;
    importer_mod_id = zT_67;
    target_mod_id = zT_68;
    field_name_id = zT_69;
    depth = zT_77;
    goto z_bb_0;
    z_bb_14:
    goto z_bb_4;
}

/* resolveImportFieldAliases */
void zF_1DB55B7A_resolveImportFieldA(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_072B53A6_ModuleRegistry* module_reg) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6B0A7D14_AstStore* zT_16;
    unsigned int zT_17;
    zT_6B0A7D14_AstStore* zT_21;
    unsigned int zT_22;
    unsigned int zT_24 = 0;
    int zT_26;
    unsigned int zT_27;
    zT_6B0A7D14_AstStore* zT_31;
    unsigned int zT_32;
    unsigned int zT_36 = 0;
    zT_6B0A7D14_AstStore* zT_38;
    unsigned int zT_39;
    zT_22A7C88B_AstNode zT_41 = {0};
    zT_8143F551_AstKind zT_42;
    unsigned int zT_46;
    zT_6B0A7D14_AstStore* zT_50;
    unsigned int zT_51;
    zT_22A7C88B_AstNode zT_54 = {0};
    zT_8143F551_AstKind zT_55;
    zT_6B0A7D14_AstStore* zT_60;
    unsigned int zT_61;
    zT_22A7C88B_AstNode zT_64 = {0};
    zT_8143F551_AstKind zT_65;
    zT_072B53A6_ModuleRegistry* zT_70;
    unsigned int zT_71;
    zT_6B0A7D14_AstStore* zT_72;
    unsigned int zT_73;
    unsigned int zT_76 = 0;
    zT_BAEE192E_Opt_10 zT_77 = {0};
    unsigned char zT_78;
    zT_ABC1EBBE_TypeResolveEnv* zT_81;
    zT_072B53A6_ModuleRegistry* zT_82;
    unsigned int zT_83;
    unsigned int zT_84;
    unsigned int zT_85;
    zT_6E8D187B_ModuleEntry* zT_87;
    zT_6E8D187B_ModuleEntry zT_88;
    zT_6B0A7D14_AstStore* zT_90;
    unsigned int zT_91;
    unsigned int zT_94 = 0;
    unsigned int zT_96 = 0;
    zT_3D7259E2_SymbolRegistry* zT_100;
    unsigned int zT_101;
    unsigned int zT_102;
    zT_6E8D187B_ModuleEntry* zT_104;
    zT_6E8D187B_ModuleEntry zT_105;
    zT_6B0A7D14_AstStore* zT_107;
    unsigned int zT_108;
    unsigned int zT_110 = 0;
    zT_6BEBA1C2_Opt_900 zT_111 = {0};
    unsigned char zT_112;
    zT_6E8D187B_ModuleEntry* zT_115;
    zT_6E8D187B_ModuleEntry zT_116;
    unsigned int zT_117;
    zT_6B0A7D14_AstStore* zT_121;
    unsigned int zT_122;
    unsigned int zT_124 = 0;
    zT_79FAE712_u64 zT_126;
    zT_338B7C76_TypeRegistry* zT_127;
    zT_79FAE712_u64 zT_128;
    unsigned int zT_129;
    int zT_131;
    unsigned int zT_133;
    int zT_134;
    unsigned int zT_136;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_22A7C88B_AstNode base;
    zT_BAEE192E_Opt_10 target;
    unsigned int mtid;
    unsigned int resolved;
    zT_6BEBA1C2_Opt_900 sym;
    zT_3A105EF1_Symbol* sp;
    zT_79FAE712_u64 ck;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((unsigned char)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_134 = 1;
    zT_136 = mi + (unsigned int)((unsigned int)zT_134);
    mi = zT_136;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_16 = env->store;
    zT_17 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_16, zT_17);
    zT_21 = env->store;
    zT_22 = root;
    zT_24 = zF_152E19CB_astStoreNodeExtraCh(zT_21, zT_22);
    decls_n = zT_24;
    zT_26 = 0;
    zT_27 = (unsigned int)zT_26;
    di = zT_27;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_31 = env->store;
    zT_32 = root;
    zT_36 = zF_B10B1BC1_astStoreNodeExtraCh(zT_31, zT_32, (unsigned int)((unsigned int)di));
    decl_idx = zT_36;
    zT_38 = env->store;
    zT_39 = decl_idx;
    zT_41 = zF_FCDD1D35_astStoreNodeAt(zT_38, zT_39);
    decl = zT_41;
    zT_42 = decl.kind;
    if ((unsigned char)(zT_42 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_131 = 1;
    zT_133 = di + (unsigned int)((unsigned int)zT_131);
    di = zT_133;
    goto z_bb_7;
    z_bb_11:
    goto z_bb_10;
    z_bb_12:
    zT_46 = decl.child_1;
    if ((unsigned char)(zT_46 == (unsigned int)(0))) goto z_bb_13; else goto z_bb_14;
    z_bb_13:
    goto z_bb_10;
    z_bb_14:
    zT_50 = env->store;
    zT_51 = decl.child_1;
    zT_54 = zF_FCDD1D35_astStoreNodeAt(zT_50, zT_51);
    init = zT_54;
    zT_55 = init.kind;
    if ((unsigned char)(zT_55 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_15; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_60 = env->store;
    zT_61 = init.child_0;
    zT_64 = zF_FCDD1D35_astStoreNodeAt(zT_60, zT_61);
    base = zT_64;
    zT_65 = base.kind;
    if ((unsigned char)(zT_65 != (zT_8143F551_AstKind)(zT_8143F551_AstKind_import_expr))) goto z_bb_17; else goto z_bb_18;
    z_bb_17:
    goto z_bb_10;
    z_bb_18:
    zT_70 = module_reg;
    zT_72 = env->store;
    zT_73 = init.child_0;
    zT_76 = zF_8BA26B9E_astStoreNodePayload(zT_72, zT_73);
    zT_71 = zT_76;
    zT_77 = zF_A258E183_moduleRegistryPathT(zT_70, zT_71);
    target = zT_77;
    zT_78 = target.has_value;
    if (zT_78) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    mtid = target.value;
    zT_81 = env;
    zT_82 = module_reg;
    zT_87 = mods.ptr;
    zT_88 = zT_87[mi];
    zT_83 = zT_88.id;
    zT_84 = mtid;
    zT_90 = env->store;
    zT_91 = decl.child_1;
    zT_94 = zF_8BA26B9E_astStoreNodePayload(zT_90, zT_91);
    zT_85 = zT_94;
    zT_96 = zF_E8C2AADA_resolveImportFieldA(zT_81, zT_82, zT_83, zT_84, zT_85, (unsigned int)(0));
    resolved = zT_96;
    if ((unsigned char)(resolved != (unsigned int)(18))) goto z_bb_21; else goto z_bb_22;
    z_bb_20:
    goto z_bb_10;
    z_bb_21:
    zT_100 = env->symbol_reg;
    zT_104 = mods.ptr;
    zT_105 = zT_104[mi];
    zT_101 = zT_105.id;
    zT_107 = env->store;
    zT_108 = decl_idx;
    zT_110 = zF_8BA26B9E_astStoreNodePayload(zT_107, zT_108);
    zT_102 = zT_110;
    zT_111 = zF_A398987E_symbolRegistryQuali(zT_100, zT_101, zT_102);
    sym = zT_111;
    zT_112 = sym.has_value;
    if (zT_112) goto z_bb_23; else goto z_bb_24;
    z_bb_22:
    goto z_bb_20;
    z_bb_23:
    sp = sym.value;
    sp->type_id = resolved;
    goto z_bb_24;
    z_bb_24:
    zT_115 = mods.ptr;
    zT_116 = zT_115[mi];
    zT_117 = zT_116.id;
    zT_121 = env->store;
    zT_122 = decl_idx;
    zT_124 = zF_8BA26B9E_astStoreNodePayload(zT_121, zT_122);
    zT_126 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_117) * (zT_79FAE712_u64)(4294967296ULL)) + (zT_79FAE712_u64)((zT_79FAE712_u64)zT_124);
    ck = zT_126;
    zT_127 = env->typereg;
    zT_128 = ck;
    zT_129 = resolved;
    zF_5E95558D_nameCachePut(zT_127, zT_128, zT_129);
    goto z_bb_22;
}

/* resolveAggregateFieldTypesAll */
void zF_E2882212_resolveAggregateFie(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods) {
    int zT_3;
    unsigned int zT_4;
    unsigned int zT_6;
    zT_6E8D187B_ModuleEntry* zT_9;
    zT_6E8D187B_ModuleEntry zT_10;
    unsigned int zT_11;
    zT_6E8D187B_ModuleEntry* zT_14;
    zT_6E8D187B_ModuleEntry zT_15;
    unsigned int zT_16;
    zT_6B0A7D14_AstStore* zT_18;
    unsigned int zT_19;
    zT_6B0A7D14_AstStore* zT_23;
    unsigned int zT_24;
    unsigned int zT_26 = 0;
    int zT_28;
    unsigned int zT_29;
    zT_6B0A7D14_AstStore* zT_33;
    unsigned int zT_34;
    unsigned int zT_38 = 0;
    zT_6B0A7D14_AstStore* zT_40;
    unsigned int zT_41;
    zT_22A7C88B_AstNode zT_43 = {0};
    zT_8143F551_AstKind zT_44;
    unsigned char zT_48;
    unsigned int zT_49;
    int zT_50;
    zT_6B0A7D14_AstStore* zT_53;
    unsigned int zT_54;
    zT_22A7C88B_AstNode zT_57 = {0};
    zT_8143F551_AstKind zT_58;
    unsigned char zT_62;
    zT_8143F551_AstKind zT_63;
    zT_ABC1EBBE_TypeResolveEnv* zT_67;
    unsigned int zT_68;
    unsigned int zT_69;
    zT_6E8D187B_ModuleEntry* zT_70;
    zT_6E8D187B_ModuleEntry zT_71;
    int zT_73;
    unsigned int zT_75;
    int zT_76;
    unsigned int zT_78;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_22A7C88B_AstNode init;
    zT_3 = 0;
    zT_4 = (unsigned int)zT_3;
    mi = zT_4;
    goto z_bb_1;
    z_bb_1:
    zT_6 = mods.len;
    if ((unsigned char)(mi < zT_6)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_9 = mods.ptr;
    zT_10 = zT_9[mi];
    zT_11 = zT_10.ast_root;
    root = zT_11;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_76 = 1;
    zT_78 = mi + (unsigned int)((unsigned int)zT_76);
    mi = zT_78;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_14 = mods.ptr;
    zT_15 = zT_14[mi];
    zT_16 = zT_15.source_file_id;
    env->source_file_id = zT_16;
    zT_18 = env->store;
    zT_19 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_18, zT_19);
    zT_23 = env->store;
    zT_24 = root;
    zT_26 = zF_152E19CB_astStoreNodeExtraCh(zT_23, zT_24);
    decls_n = zT_26;
    zT_28 = 0;
    zT_29 = (unsigned int)zT_28;
    di = zT_29;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_33 = env->store;
    zT_34 = root;
    zT_38 = zF_B10B1BC1_astStoreNodeExtraCh(zT_33, zT_34, (unsigned int)((unsigned int)di));
    decl_idx = zT_38;
    zT_40 = env->store;
    zT_41 = decl_idx;
    zT_43 = zF_FCDD1D35_astStoreNodeAt(zT_40, zT_41);
    decl = zT_43;
    zT_44 = decl.kind;
    if ((unsigned char)(zT_44 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_11; else goto z_bb_12;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_73 = 1;
    zT_75 = di + (unsigned int)((unsigned int)zT_73);
    di = zT_75;
    goto z_bb_7;
    z_bb_11:
    zT_49 = decl.child_1;
    zT_50 = 0;
    zT_48 = zT_49 != (unsigned int)zT_50;
    goto z_bb_13;
    z_bb_12:
    zT_48 = 0;
    goto z_bb_13;
    z_bb_13:
    if (zT_48) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    zT_53 = env->store;
    zT_54 = decl.child_1;
    zT_57 = zF_FCDD1D35_astStoreNodeAt(zT_53, zT_54);
    init = zT_57;
    zT_58 = init.kind;
    if ((unsigned char)(zT_58 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_struct_decl))) goto z_bb_17; else goto z_bb_16;
    z_bb_15:
    goto z_bb_10;
    z_bb_16:
    zT_63 = init.kind;
    zT_62 = zT_63 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_union_decl);
    goto z_bb_18;
    z_bb_17:
    zT_62 = 1;
    goto z_bb_18;
    z_bb_18:
    if (zT_62) goto z_bb_19; else goto z_bb_20;
    z_bb_19:
    zT_67 = env;
    zT_70 = mods.ptr;
    zT_71 = zT_70[mi];
    zT_68 = zT_71.id;
    zT_69 = decl_idx;
    zF_F5C3193B_resolveDeclAggregat(zT_67, zT_68, zT_69);
    goto z_bb_20;
    z_bb_20:
    goto z_bb_15;
}

/* reportUndefinedSymbol */
void zF_76A5E245_reportUndefinedSymb(zT_F85C5DED_DiagnosticCollector* diag, zT_D3EB6303_StringInterner* interner, unsigned int source_file_id, unsigned int span_start, unsigned int span_len, unsigned int name_id) {
    unsigned char* zT_7;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_8;
    unsigned int zT_9;
    unsigned char* zT_11;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_12;
    unsigned int zT_13;
    zT_D3EB6303_StringInterner* zT_15;
    unsigned int zT_16;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_17 = {0};
    zT_4C214FEE_Arr_zT_8F083A69_Sli zT_19;
    unsigned int zT_20;
    unsigned int zT_21;
    unsigned int zT_22;
    zT_D3EB6303_StringInterner* zT_24;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_25;
    int zT_27;
    zT_8F083A69_Slice_zT_0B42B2F8_u* zT_28;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_30 = {0};
    zT_F85C5DED_DiagnosticCollector* zT_31;
    unsigned int zT_34;
    unsigned int zT_35;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_37;
    unsigned int zT_43 = 0;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui1;
    zT_8F083A69_Slice_zT_0B42B2F8_u ui2;
    zT_8F083A69_Slice_zT_0B42B2F8_u uitext;
    zT_4C214FEE_Arr_zT_8F083A69_Sli uiparts;
    zT_8F083A69_Slice_zT_0B42B2F8_u uimsg;
    zT_7 = "identifier '";
    zT_9 = 12;
    zT_8.ptr = zT_7;
    zT_8.len = zT_9;
    ui1 = zT_8;
    zT_11 = "' is not declared or imported in this module";
    zT_13 = 44;
    zT_12.ptr = zT_11;
    zT_12.len = zT_13;
    ui2 = zT_12;
    zT_15 = interner;
    zT_16 = name_id;
    zT_17 = zF_9134020D_stringInternerGet(zT_15, zT_16);
    uitext = zT_17;
    zT_20 = 0;
    zT_19[zT_20] = ui1;
    zT_21 = 1;
    zT_19[zT_21] = uitext;
    zT_22 = 2;
    zT_19[zT_22] = ui2;
    {
    unsigned int _i = 0;
    while (_i < 3) {
        uiparts[_i] = zT_19[_i];
        _i++;
    }
}
    zT_24 = interner;
    zT_27 = 0;
    zT_28 = uiparts + zT_27;
    zT_25 = zT_28;
    zT_30 = zF_8C4BFF7C_diagnosticBuilderMa(zT_24, zT_25, (unsigned int)(3));
    uimsg = zT_30;
    zT_31 = diag;
    zT_34 = source_file_id;
    zT_35 = span_start;
    zT_37 = uimsg;
    zT_43 = zF_C82559AC_diagnosticCollector(zT_31, (unsigned char)(0), (unsigned short)((unsigned short)(zT_A210EB18_ErrorCode)(zT_A210EB18_ErrorCode_ERR_3001_UNDEFINED_SYMBOL)), zT_34, zT_35, (unsigned int)(span_start + span_len), zT_37);
    (void)zT_43;
    return;
}

/* typeResolverDiagnoseSignatureType */
void zF_2501AC4F_typeResolverDiagnos(zT_ABC1EBBE_TypeResolveEnv* env, unsigned int node_idx, unsigned int depth) {
    zT_6F32B01B_Opt_235 zT_8;
    unsigned char zT_9;
    zT_F85C5DED_DiagnosticCollector* zT_10;
    zT_6B0A7D14_AstStore* zT_13;
    unsigned int zT_14;
    zT_22A7C88B_AstNode zT_16 = {0};
    zT_8143F551_AstKind zT_17;
    zT_ABC1EBBE_TypeResolveEnv* zT_21;
    unsigned int zT_22;
    unsigned int zT_25 = 0;
    zT_6B0A7D14_AstStore* zT_29;
    unsigned int zT_30;
    unsigned int zT_32 = 0;
    unsigned char* zT_34;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_35;
    unsigned int zT_36;
    zT_D3EB6303_StringInterner* zT_38;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_39;
    unsigned int zT_41 = 0;
    unsigned char* zT_44;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_45;
    unsigned int zT_46;
    zT_D3EB6303_StringInterner* zT_48;
    zT_8F083A69_Slice_zT_0B42B2F8_u zT_49;
    unsigned int zT_51 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_53;
    unsigned int zT_54;
    unsigned char zT_55 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_57;
    zT_D3EB6303_StringInterner* zT_58;
    unsigned int zT_59;
    unsigned int zT_60;
    unsigned int zT_62;
    unsigned int zT_66;
    zT_8143F551_AstKind zT_68;
    unsigned int zT_73;
    zT_ABC1EBBE_TypeResolveEnv* zT_75;
    unsigned int zT_76;
    unsigned int zT_79 = 0;
    unsigned char zT_81;
    unsigned int zT_83;
    zT_338B7C76_TypeRegistry* zT_87;
    unsigned int zT_88;
    zT_338B7C76_TypeRegistry* zT_91;
    zT_D155D06D_Type* zT_92;
    unsigned int zT_93;
    zT_D155D06D_Type zT_94;
    zT_33EF6BFB_TypeKind zT_95;
    unsigned char zT_99;
    unsigned short zT_100;
    unsigned int zT_101;
    zT_6B0A7D14_AstStore* zT_103;
    unsigned int zT_104;
    zT_22A7C88B_AstNode zT_106 = {0};
    zT_8143F551_AstKind zT_107;
    zT_6B0A7D14_AstStore* zT_112;
    unsigned int zT_113;
    unsigned int zT_115 = 0;
    int zT_117;
    unsigned int zT_118;
    zT_3D7259E2_SymbolRegistry* zT_119;
    unsigned int zT_120;
    zT_3D7259E2_SymbolRegistry* zT_124;
    unsigned int zT_126;
    zT_6BEBA1C2_Opt_900 zT_129 = {0};
    unsigned char zT_130;
    zT_3C598AEF_SymbolKind zT_132;
    unsigned char zT_136;
    unsigned int zT_137;
    int zT_138;
    unsigned int zT_140;
    zT_6B0A7D14_AstStore* zT_142;
    unsigned int zT_143;
    unsigned int zT_145 = 0;
    zT_3D7259E2_SymbolRegistry* zT_147;
    unsigned int zT_148;
    unsigned int zT_149;
    zT_6BEBA1C2_Opt_900 zT_151 = {0};
    unsigned char zT_152;
    zT_F85C5DED_DiagnosticCollector* zT_154;
    unsigned int zT_155;
    unsigned char zT_156 = 0;
    zT_F85C5DED_DiagnosticCollector* zT_157;
    zT_D3EB6303_StringInterner* zT_158;
    unsigned int zT_159;
    unsigned int zT_160;
    unsigned int zT_162;
    unsigned int zT_166;
    zT_ABC1EBBE_TypeResolveEnv* zT_170;
    unsigned int zT_171;
    zT_8143F551_AstKind zT_175;
    unsigned int zT_179;
    int zT_180;
    zT_ABC1EBBE_TypeResolveEnv* zT_182;
    unsigned int zT_183;
    unsigned int zT_188;
    int zT_189;
    zT_ABC1EBBE_TypeResolveEnv* zT_191;
    unsigned int zT_192;
    zT_8143F551_AstKind zT_197;
    unsigned int zT_201;
    int zT_202;
    zT_ABC1EBBE_TypeResolveEnv* zT_204;
    unsigned int zT_205;
    zT_6B0A7D14_AstStore* zT_210;
    unsigned int zT_211;
    unsigned int zT_213 = 0;
    zT_6B0A7D14_AstStore* zT_217;
    unsigned int zT_218;
    unsigned int zT_220 = 0;
    int zT_222;
    unsigned int zT_223;
    zT_6B0A7D14_AstStore* zT_227;
    unsigned int zT_228;
    unsigned int zT_232 = 0;
    int zT_233;
    zT_ABC1EBBE_TypeResolveEnv* zT_235;
    unsigned int zT_236;
    int zT_240;
    unsigned int zT_242;
    zT_8143F551_AstKind zT_243;
    unsigned char zT_247;
    zT_8143F551_AstKind zT_248;
    unsigned char zT_252;
    zT_8143F551_AstKind zT_253;
    unsigned char zT_257;
    zT_8143F551_AstKind zT_258;
    unsigned char zT_262;
    zT_8143F551_AstKind zT_263;
    unsigned int zT_267;
    int zT_268;
    zT_ABC1EBBE_TypeResolveEnv* zT_270;
    unsigned int zT_271;
    zT_F85C5DED_DiagnosticCollector* diag;
    zT_22A7C88B_AstNode node;
    unsigned int name_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u nr_text;
    unsigned int nr_id;
    zT_8F083A69_Slice_zT_0B42B2F8_u at_text;
    unsigned int at_id;
    unsigned int fd_base;
    unsigned int fd_bt;
    unsigned char fd_is_mod;
    unsigned int fd_mod_id;
    zT_22A7C88B_AstNode fd_bn;
    zT_D155D06D_Type fd_ty;
    unsigned int fd_bname;
    unsigned int fd_mi;
    zT_6BEBA1C2_Opt_900 fd_bs;
    zT_3A105EF1_Symbol* fb;
    unsigned int fd_member;
    zT_6BEBA1C2_Opt_900 fd_ms;
    unsigned int ft_n;
    unsigned int ft_i;
    unsigned int ft_child;
    if ((unsigned char)(node_idx == (unsigned int)(0))) goto z_bb_1; else goto z_bb_2;
    z_bb_1:
    return;
    z_bb_2:
    if ((unsigned char)(depth > (unsigned int)(16))) goto z_bb_3; else goto z_bb_4;
    z_bb_3:
    return;
    z_bb_4:
    zT_8 = env->diag;
    zT_9 = zT_8.has_value;
    if (zT_9) goto z_bb_6; else goto z_bb_5;
    z_bb_5:
    return;
    z_bb_6:
    zT_10 = zT_8.value;
    goto z_bb_7;
    z_bb_7:
    diag = zT_10;
    zT_13 = env->store;
    zT_14 = node_idx;
    zT_16 = zF_FCDD1D35_astStoreNodeAt(zT_13, zT_14);
    node = zT_16;
    zT_17 = node.kind;
    if ((unsigned char)(zT_17 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_21 = env;
    zT_22 = node_idx;
    zT_25 = zF_F2107C15_resolveTypeExprFull(zT_21, zT_22, (unsigned int)(0));
    if ((unsigned char)(zT_25 != (unsigned int)(18))) goto z_bb_10; else goto z_bb_11;
    z_bb_9:
    zT_68 = node.kind;
    if ((unsigned char)(zT_68 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_field_access))) goto z_bb_18; else goto z_bb_19;
    z_bb_10:
    return;
    z_bb_11:
    zT_29 = env->store;
    zT_30 = node_idx;
    zT_32 = zF_53458827_astStoreIdentifier(zT_29, zT_30);
    name_id = zT_32;
    zT_34 = "noreturn";
    zT_36 = 8;
    zT_35.ptr = zT_34;
    zT_35.len = zT_36;
    nr_text = zT_35;
    zT_38 = env->interner;
    zT_39 = nr_text;
    zT_41 = zF_50C274AF_stringInternerInter(zT_38, zT_39);
    nr_id = zT_41;
    if ((unsigned char)(name_id == nr_id)) goto z_bb_12; else goto z_bb_13;
    z_bb_12:
    return;
    z_bb_13:
    zT_44 = "anytype";
    zT_46 = 7;
    zT_45.ptr = zT_44;
    zT_45.len = zT_46;
    at_text = zT_45;
    zT_48 = env->interner;
    zT_49 = at_text;
    zT_51 = zF_50C274AF_stringInternerInter(zT_48, zT_49);
    at_id = zT_51;
    if ((unsigned char)(name_id == at_id)) goto z_bb_14; else goto z_bb_15;
    z_bb_14:
    return;
    z_bb_15:
    zT_53 = diag;
    zT_54 = node_idx;
    zT_55 = zF_4DD9DB2D_diagnosticCollector(zT_53, zT_54);
    if ((unsigned char)(!zT_55)) goto z_bb_16; else goto z_bb_17;
    z_bb_16:
    return;
    z_bb_17:
    zT_57 = diag;
    zT_58 = env->interner;
    zT_59 = env->source_file_id;
    zT_60 = node.span_start;
    zT_66 = node.span_len;
    zT_62 = name_id;
    zF_76A5E245_reportUndefinedSymb(zT_57, zT_58, zT_59, zT_60, (unsigned int)((unsigned int)zT_66), zT_62);
    return;
    z_bb_18:
    zT_73 = node.child_0;
    fd_base = zT_73;
    zT_75 = env;
    zT_76 = fd_base;
    zT_79 = zF_F2107C15_resolveTypeExprFull(zT_75, zT_76, (unsigned int)(0));
    fd_bt = zT_79;
    zT_81 = 0;
    fd_is_mod = zT_81;
    zT_83 = 0;
    fd_mod_id = zT_83;
    if ((unsigned char)(fd_bt != (unsigned int)(18))) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    zT_175 = node.kind;
    if ((unsigned char)(zT_175 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_error_union_type))) goto z_bb_45; else goto z_bb_46;
    z_bb_20:
    zT_87 = env->typereg;
    zT_88 = zT_87->types_len;
    if ((unsigned char)((unsigned int)((unsigned int)fd_bt) < zT_88)) goto z_bb_23; else goto z_bb_24;
    z_bb_21:
    if (fd_is_mod) goto z_bb_37; else goto z_bb_38;
    z_bb_22:
    zT_103 = env->store;
    zT_104 = fd_base;
    zT_106 = zF_FCDD1D35_astStoreNodeAt(zT_103, zT_104);
    fd_bn = zT_106;
    zT_107 = fd_bn.kind;
    if ((unsigned char)(zT_107 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ident_expr))) goto z_bb_27; else goto z_bb_28;
    z_bb_23:
    zT_91 = env->typereg;
    zT_92 = zT_91->types_items;
    zT_93 = (unsigned int)fd_bt;
    zT_94 = zT_92[zT_93];
    fd_ty = zT_94;
    zT_95 = fd_ty.kind;
    if ((unsigned char)(zT_95 == (zT_33EF6BFB_TypeKind)(zT_33EF6BFB_TypeKind_module_type))) goto z_bb_25; else goto z_bb_26;
    z_bb_24:
    goto z_bb_21;
    z_bb_25:
    zT_99 = 1;
    fd_is_mod = zT_99;
    zT_100 = fd_ty.module_id;
    zT_101 = (unsigned int)zT_100;
    fd_mod_id = zT_101;
    goto z_bb_26;
    z_bb_26:
    goto z_bb_24;
    z_bb_27:
    zT_112 = env->store;
    zT_113 = fd_base;
    zT_115 = zF_53458827_astStoreIdentifier(zT_112, zT_113);
    fd_bname = zT_115;
    zT_117 = 0;
    zT_118 = (unsigned int)zT_117;
    fd_mi = zT_118;
    goto z_bb_29;
    z_bb_28:
    goto z_bb_21;
    z_bb_29:
    zT_119 = env->symbol_reg;
    zT_120 = zT_119->tables_len;
    if ((unsigned char)(fd_mi < (unsigned int)((unsigned int)zT_120))) goto z_bb_30; else goto z_bb_31;
    z_bb_30:
    zT_124 = env->symbol_reg;
    zT_126 = fd_bname;
    zT_129 = zF_A398987E_symbolRegistryQuali(zT_124, (unsigned int)((unsigned int)fd_mi), zT_126);
    fd_bs = zT_129;
    zT_130 = fd_bs.has_value;
    if (zT_130) goto z_bb_33; else goto z_bb_34;
    z_bb_31:
    goto z_bb_28;
    z_bb_32:
    zT_138 = 1;
    zT_140 = fd_mi + (unsigned int)((unsigned int)zT_138);
    fd_mi = zT_140;
    goto z_bb_29;
    z_bb_33:
    fb = fd_bs.value;
    zT_132 = fb->kind;
    if ((unsigned char)(zT_132 == (zT_3C598AEF_SymbolKind)(zT_3C598AEF_SymbolKind_module))) goto z_bb_35; else goto z_bb_36;
    z_bb_34:
    goto z_bb_32;
    z_bb_35:
    zT_136 = 1;
    fd_is_mod = zT_136;
    zT_137 = fb->module_id;
    fd_mod_id = zT_137;
    goto z_bb_36;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_142 = env->store;
    zT_143 = node_idx;
    zT_145 = zF_8BA26B9E_astStoreNodePayload(zT_142, zT_143);
    fd_member = zT_145;
    zT_147 = env->symbol_reg;
    zT_148 = fd_mod_id;
    zT_149 = fd_member;
    zT_151 = zF_A398987E_symbolRegistryQuali(zT_147, zT_148, zT_149);
    fd_ms = zT_151;
    zT_152 = fd_ms.has_value;
    if ((unsigned char)(!zT_152)) goto z_bb_39; else goto z_bb_40;
    z_bb_38:
    if ((unsigned char)(fd_bt == (unsigned int)(18))) goto z_bb_43; else goto z_bb_44;
    z_bb_39:
    zT_154 = diag;
    zT_155 = node_idx;
    zT_156 = zF_4DD9DB2D_diagnosticCollector(zT_154, zT_155);
    if (zT_156) goto z_bb_41; else goto z_bb_42;
    z_bb_40:
    return;
    z_bb_41:
    zT_157 = diag;
    zT_158 = env->interner;
    zT_159 = env->source_file_id;
    zT_160 = node.span_start;
    zT_166 = node.span_len;
    zT_162 = fd_member;
    zF_76A5E245_reportUndefinedSymb(zT_157, zT_158, zT_159, zT_160, (unsigned int)((unsigned int)zT_166), zT_162);
    goto z_bb_42;
    z_bb_42:
    goto z_bb_40;
    z_bb_43:
    zT_170 = env;
    zT_171 = fd_base;
    zF_2501AC4F_typeResolverDiagnos(zT_170, zT_171, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_44;
    z_bb_44:
    return;
    z_bb_45:
    zT_179 = node.child_0;
    zT_180 = 0;
    if ((unsigned char)(zT_179 != (unsigned int)zT_180)) goto z_bb_47; else goto z_bb_48;
    z_bb_46:
    zT_197 = node.kind;
    if ((unsigned char)(zT_197 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_type))) goto z_bb_51; else goto z_bb_52;
    z_bb_47:
    zT_182 = env;
    zT_183 = node.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_182, zT_183, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_48;
    z_bb_48:
    zT_188 = node.child_1;
    zT_189 = 0;
    if ((unsigned char)(zT_188 != (unsigned int)zT_189)) goto z_bb_49; else goto z_bb_50;
    z_bb_49:
    zT_191 = env;
    zT_192 = node.child_1;
    zF_2501AC4F_typeResolverDiagnos(zT_191, zT_192, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_50;
    z_bb_50:
    return;
    z_bb_51:
    zT_201 = node.child_0;
    zT_202 = 0;
    if ((unsigned char)(zT_201 != (unsigned int)zT_202)) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    zT_243 = node.kind;
    if ((unsigned char)(zT_243 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_ptr_type))) goto z_bb_64; else goto z_bb_63;
    z_bb_53:
    zT_204 = env;
    zT_205 = node.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_204, zT_205, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_54;
    z_bb_54:
    zT_210 = env->store;
    zT_211 = node_idx;
    zT_213 = zF_8BA26B9E_astStoreNodePayload(zT_210, zT_211);
    if ((unsigned char)(zT_213 != (unsigned int)(0))) goto z_bb_55; else goto z_bb_56;
    z_bb_55:
    zT_217 = env->store;
    zT_218 = node_idx;
    zT_220 = zF_152E19CB_astStoreNodeExtraCh(zT_217, zT_218);
    ft_n = zT_220;
    zT_222 = 0;
    zT_223 = (unsigned int)zT_222;
    ft_i = zT_223;
    goto z_bb_57;
    z_bb_56:
    return;
    z_bb_57:
    if ((unsigned char)(ft_i < (unsigned int)((unsigned int)ft_n))) goto z_bb_58; else goto z_bb_59;
    z_bb_58:
    zT_227 = env->store;
    zT_228 = node_idx;
    zT_232 = zF_B10B1BC1_astStoreNodeExtraCh(zT_227, zT_228, (unsigned int)((unsigned int)ft_i));
    ft_child = zT_232;
    zT_233 = 0;
    if ((unsigned char)(ft_child != (unsigned int)zT_233)) goto z_bb_61; else goto z_bb_62;
    z_bb_59:
    goto z_bb_56;
    z_bb_60:
    zT_240 = 1;
    zT_242 = ft_i + (unsigned int)((unsigned int)zT_240);
    ft_i = zT_242;
    goto z_bb_57;
    z_bb_61:
    zT_235 = env;
    zT_236 = ft_child;
    zF_2501AC4F_typeResolverDiagnos(zT_235, zT_236, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_62;
    z_bb_62:
    goto z_bb_60;
    z_bb_63:
    zT_248 = node.kind;
    zT_247 = zT_248 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_many_ptr_type);
    goto z_bb_65;
    z_bb_64:
    zT_247 = 1;
    goto z_bb_65;
    z_bb_65:
    if (zT_247) goto z_bb_67; else goto z_bb_66;
    z_bb_66:
    zT_253 = node.kind;
    zT_252 = zT_253 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_slice_type);
    goto z_bb_68;
    z_bb_67:
    zT_252 = 1;
    goto z_bb_68;
    z_bb_68:
    if (zT_252) goto z_bb_70; else goto z_bb_69;
    z_bb_69:
    zT_258 = node.kind;
    zT_257 = zT_258 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_optional_type);
    goto z_bb_71;
    z_bb_70:
    zT_257 = 1;
    goto z_bb_71;
    z_bb_71:
    if (zT_257) goto z_bb_73; else goto z_bb_72;
    z_bb_72:
    zT_263 = node.kind;
    zT_262 = zT_263 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_array_type);
    goto z_bb_74;
    z_bb_73:
    zT_262 = 1;
    goto z_bb_74;
    z_bb_74:
    if (zT_262) goto z_bb_75; else goto z_bb_76;
    z_bb_75:
    zT_267 = node.child_0;
    zT_268 = 0;
    if ((unsigned char)(zT_267 != (unsigned int)zT_268)) goto z_bb_77; else goto z_bb_78;
    z_bb_76:
    return;
    z_bb_77:
    zT_270 = env;
    zT_271 = node.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_270, zT_271, (unsigned int)(depth + (unsigned int)(1)));
    goto z_bb_78;
    z_bb_78:
    return;
}

/* resolveFnSignatures */
void zF_29FBFC7C_resolveFnSignatures(zT_ABC1EBBE_TypeResolveEnv* env, zT_DDCD424B_Slice_zT_6E8D187B_M mods, zT_8EED1867_ResolvedTypeTable* resolved_types) {
    int zT_4;
    unsigned int zT_5;
    unsigned int zT_7;
    zT_6E8D187B_ModuleEntry* zT_10;
    zT_6E8D187B_ModuleEntry zT_11;
    unsigned int zT_12;
    zT_6E8D187B_ModuleEntry* zT_15;
    zT_6E8D187B_ModuleEntry zT_16;
    unsigned int zT_17;
    zT_6E8D187B_ModuleEntry* zT_18;
    zT_6E8D187B_ModuleEntry zT_19;
    unsigned int zT_20;
    zT_6B0A7D14_AstStore* zT_22;
    unsigned int zT_23;
    zT_6B0A7D14_AstStore* zT_27;
    unsigned int zT_28;
    unsigned int zT_30 = 0;
    int zT_32;
    unsigned int zT_33;
    zT_6B0A7D14_AstStore* zT_37;
    unsigned int zT_38;
    unsigned int zT_42 = 0;
    zT_6B0A7D14_AstStore* zT_44;
    unsigned int zT_45;
    zT_22A7C88B_AstNode zT_47 = {0};
    zT_8143F551_AstKind zT_48;
    zT_6B0A7D14_AstStore* zT_53;
    zT_E2261874_anon_263683 zT_54;
    zT_243D6A41_FnProto* zT_55;
    zT_6B0A7D14_AstStore* zT_56;
    unsigned int zT_57;
    unsigned int zT_59 = 0;
    unsigned int zT_60;
    zT_243D6A41_FnProto zT_61;
    zT_3D7259E2_SymbolRegistry* zT_63;
    unsigned int zT_64;
    unsigned int zT_65;
    zT_6E8D187B_ModuleEntry* zT_67;
    zT_6E8D187B_ModuleEntry zT_68;
    zT_6BEBA1C2_Opt_900 zT_71 = {0};
    unsigned char zT_72;
    unsigned int zT_74;
    zT_939EE900_Arr_unsigned_int_1 zT_78;
    unsigned int zT_79;
    unsigned int zT_80;
    unsigned int zT_81;
    int zT_82;
    zT_ABC1EBBE_TypeResolveEnv* zT_85;
    unsigned int zT_86;
    unsigned int zT_90 = 0;
    int zT_93;
    zT_8EED1867_ResolvedTypeTable* zT_94;
    unsigned int zT_95;
    unsigned int zT_96;
    zT_ABC1EBBE_TypeResolveEnv* zT_98;
    unsigned int zT_99;
    unsigned char zT_104;
    unsigned char zT_105;
    unsigned char zT_110;
    unsigned char zT_112;
    unsigned char zT_113;
    unsigned char zT_118;
    zT_993A6923_Arr_unsigned_int_64 zT_120;
    unsigned int zT_122;
    unsigned short zT_123;
    char* zT_127;
    unsigned int zT_128;
    char* zT_129;
    unsigned int zT_130;
    char* zT_131;
    unsigned int zT_132;
    unsigned short zT_134;
    unsigned int zT_138;
    unsigned short zT_142;
    zT_79FAE712_u64 zT_144;
    zT_6B0A7D14_AstStore* zT_146;
    zT_79FAE712_u64 zT_147;
    unsigned int zT_149 = 0;
    int zT_151;
    unsigned int zT_152;
    zT_6B0A7D14_AstStore* zT_156;
    unsigned int zT_157;
    zT_6B0A7D14_AstStore* zT_159;
    zT_79FAE712_u64 zT_160;
    unsigned int zT_164 = 0;
    zT_22A7C88B_AstNode zT_165 = {0};
    unsigned int zT_166;
    int zT_167;
    zT_ABC1EBBE_TypeResolveEnv* zT_170;
    unsigned int zT_171;
    unsigned int zT_175 = 0;
    char* zT_178;
    unsigned int zT_179;
    char* zT_180;
    unsigned int zT_181;
    char* zT_182;
    unsigned int zT_183;
    unsigned int zT_186;
    zT_8EED1867_ResolvedTypeTable* zT_189;
    unsigned int zT_190;
    unsigned int zT_191;
    zT_ABC1EBBE_TypeResolveEnv* zT_193;
    unsigned int zT_194;
    int zT_198;
    unsigned int zT_200;
    zT_338B7C76_TypeRegistry* zT_202;
    unsigned int zT_203;
    unsigned int zT_204;
    unsigned int zT_206;
    zT_338B7C76_TypeRegistry* zT_208;
    unsigned int zT_209;
    int zT_212;
    unsigned int zT_214;
    zT_338B7C76_TypeRegistry* zT_216;
    unsigned int zT_217;
    unsigned int zT_218;
    unsigned char zT_219;
    unsigned char zT_220;
    unsigned int zT_221;
    unsigned short zT_222;
    unsigned int zT_223;
    unsigned char zT_224;
    zT_6E8D187B_ModuleEntry* zT_227;
    zT_6E8D187B_ModuleEntry zT_228;
    int zT_231;
    unsigned int zT_234 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_235;
    unsigned int zT_236;
    unsigned int zT_237;
    zT_3D7259E2_SymbolRegistry* zT_239;
    unsigned int zT_240;
    unsigned int zT_241;
    zT_6E8D187B_ModuleEntry* zT_243;
    zT_6E8D187B_ModuleEntry zT_244;
    zT_6BEBA1C2_Opt_900 zT_247 = {0};
    unsigned char zT_248;
    zT_8143F551_AstKind zT_250;
    unsigned char zT_254;
    unsigned int zT_255;
    int zT_256;
    zT_ABC1EBBE_TypeResolveEnv* zT_259;
    unsigned int zT_260;
    unsigned int zT_264 = 0;
    zT_8EED1867_ResolvedTypeTable* zT_267;
    unsigned int zT_268;
    unsigned int zT_269;
    zT_8EED1867_ResolvedTypeTable* zT_271;
    unsigned int zT_272;
    unsigned int zT_273;
    zT_3D7259E2_SymbolRegistry* zT_275;
    unsigned int zT_276;
    unsigned int zT_277;
    zT_6E8D187B_ModuleEntry* zT_279;
    zT_6E8D187B_ModuleEntry zT_280;
    zT_6B0A7D14_AstStore* zT_282;
    unsigned int zT_283;
    unsigned int zT_285 = 0;
    zT_6BEBA1C2_Opt_900 zT_286 = {0};
    unsigned char zT_287;
    int zT_289;
    unsigned int zT_291;
    int zT_292;
    unsigned int zT_294;
    unsigned int mi;
    unsigned int root;
    unsigned int decls_n;
    unsigned int di;
    unsigned int decl_idx;
    zT_22A7C88B_AstNode decl;
    zT_243D6A41_FnProto proto;
    zT_6BEBA1C2_Opt_900 sym_check;
    zT_3A105EF1_Symbol* sc;
    zT_939EE900_Arr_unsigned_int_1 rt_box;
    unsigned int rtype;
    unsigned char is_ext;
    unsigned char is_variadic;
    zT_993A6923_Arr_unsigned_int_64 ptypes_buf;
    unsigned int ptypes_n;
    zT_79FAE712_u64 p_payload;
    unsigned int pnodes_n;
    unsigned int pi;
    unsigned int fn_start;
    unsigned int pf;
    zT_22A7C88B_AstNode pnode;
    unsigned int ptype;
    unsigned int tid;
    zT_6BEBA1C2_Opt_900 sym;
    zT_3A105EF1_Symbol* sp;
    unsigned int vtype;
    zT_4 = 0;
    zT_5 = (unsigned int)zT_4;
    mi = zT_5;
    goto z_bb_1;
    z_bb_1:
    zT_7 = mods.len;
    if ((unsigned char)(mi < zT_7)) goto z_bb_2; else goto z_bb_3;
    z_bb_2:
    zT_10 = mods.ptr;
    zT_11 = zT_10[mi];
    zT_12 = zT_11.ast_root;
    root = zT_12;
    if ((unsigned char)(root == (unsigned int)(0))) goto z_bb_5; else goto z_bb_6;
    z_bb_3:
    return;
    z_bb_4:
    zT_292 = 1;
    zT_294 = mi + (unsigned int)((unsigned int)zT_292);
    mi = zT_294;
    goto z_bb_1;
    z_bb_5:
    goto z_bb_4;
    z_bb_6:
    zT_15 = mods.ptr;
    zT_16 = zT_15[mi];
    zT_17 = zT_16.id;
    env->module_id = zT_17;
    zT_18 = mods.ptr;
    zT_19 = zT_18[mi];
    zT_20 = zT_19.source_file_id;
    env->source_file_id = zT_20;
    zT_22 = env->store;
    zT_23 = root;
    (void)zF_FCDD1D35_astStoreNodeAt(zT_22, zT_23);
    zT_27 = env->store;
    zT_28 = root;
    zT_30 = zF_152E19CB_astStoreNodeExtraCh(zT_27, zT_28);
    decls_n = zT_30;
    zT_32 = 0;
    zT_33 = (unsigned int)zT_32;
    di = zT_33;
    goto z_bb_7;
    z_bb_7:
    if ((unsigned char)(di < (unsigned int)((unsigned int)decls_n))) goto z_bb_8; else goto z_bb_9;
    z_bb_8:
    zT_37 = env->store;
    zT_38 = root;
    zT_42 = zF_B10B1BC1_astStoreNodeExtraCh(zT_37, zT_38, (unsigned int)((unsigned int)di));
    decl_idx = zT_42;
    zT_44 = env->store;
    zT_45 = decl_idx;
    zT_47 = zF_FCDD1D35_astStoreNodeAt(zT_44, zT_45);
    decl = zT_47;
    zT_48 = decl.kind;
    if ((unsigned char)(zT_48 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_fn_decl))) goto z_bb_11; else goto z_bb_13;
    z_bb_9:
    goto z_bb_4;
    z_bb_10:
    zT_289 = 1;
    zT_291 = di + (unsigned int)((unsigned int)zT_289);
    di = zT_291;
    goto z_bb_7;
    z_bb_11:
    zT_53 = env->store;
    zT_54 = zT_53->fn_protos;
    zT_55 = zT_54.items;
    zT_56 = env->store;
    zT_57 = decl_idx;
    zT_59 = zF_8BA26B9E_astStoreNodePayload(zT_56, zT_57);
    zT_60 = (unsigned int)zT_59;
    zT_61 = zT_55[zT_60];
    proto = zT_61;
    zT_63 = env->symbol_reg;
    zT_67 = mods.ptr;
    zT_68 = zT_67[mi];
    zT_64 = zT_68.id;
    zT_65 = proto.name_id;
    zT_71 = zF_A398987E_symbolRegistryQuali(zT_63, zT_64, zT_65);
    sym_check = zT_71;
    zT_72 = sym_check.has_value;
    if (zT_72) goto z_bb_14; else goto z_bb_15;
    z_bb_12:
    goto z_bb_10;
    z_bb_13:
    zT_250 = decl.kind;
    if ((unsigned char)(zT_250 == (zT_8143F551_AstKind)(zT_8143F551_AstKind_var_decl))) goto z_bb_48; else goto z_bb_49;
    z_bb_14:
    sc = sym_check.value;
    zT_74 = sc->type_id;
    if ((unsigned char)(zT_74 != (unsigned int)(0))) goto z_bb_16; else goto z_bb_17;
    z_bb_15:
    zT_79 = 1;
    zT_80 = 0;
    zT_78[zT_80] = zT_79;
    {
    unsigned int _i = 0;
    while (_i < 1) {
        rt_box[_i] = zT_78[_i];
        _i++;
    }
}
    zT_81 = proto.return_type_node;
    zT_82 = 0;
    if ((unsigned char)(zT_81 != (unsigned int)zT_82)) goto z_bb_18; else goto z_bb_19;
    z_bb_16:
    goto z_bb_10;
    z_bb_17:
    goto z_bb_15;
    z_bb_18:
    zT_85 = env;
    zT_86 = proto.return_type_node;
    zT_90 = zF_F2107C15_resolveTypeExprFull(zT_85, zT_86, (unsigned int)(0));
    rtype = zT_90;
    if ((unsigned char)(rtype != (unsigned int)(18))) goto z_bb_20; else goto z_bb_22;
    z_bb_19:
    zT_104 = 0;
    is_ext = zT_104;
    zT_105 = decl.flags;
    if ((unsigned char)((unsigned char)(zT_105 & (unsigned char)(4)) != (unsigned char)(0))) goto z_bb_23; else goto z_bb_24;
    z_bb_20:
    zT_93 = 0;
    rt_box[zT_93] = rtype;
    zT_94 = resolved_types;
    zT_95 = proto.return_type_node;
    zT_96 = rtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_94, zT_95, zT_96);
    goto z_bb_21;
    z_bb_21:
    goto z_bb_19;
    z_bb_22:
    zT_98 = env;
    zT_99 = proto.return_type_node;
    zF_2501AC4F_typeResolverDiagnos(zT_98, zT_99, (unsigned int)(0));
    goto z_bb_21;
    z_bb_23:
    zT_110 = 1;
    is_ext = zT_110;
    goto z_bb_24;
    z_bb_24:
    zT_112 = 0;
    is_variadic = zT_112;
    zT_113 = decl.flags;
    if ((unsigned char)((unsigned char)(zT_113 & (unsigned char)(1)) != (unsigned char)(0))) goto z_bb_25; else goto z_bb_26;
    z_bb_25:
    zT_118 = 1;
    is_variadic = zT_118;
    goto z_bb_26;
    z_bb_26:
    {
    unsigned int _i = 0;
    while (_i < 64) {
        zT_120[_i] = 0;
        _i++;
    }
}
    {
    unsigned int _i = 0;
    while (_i < 64) {
        ptypes_buf[_i] = zT_120[_i];
        _i++;
    }
}
    zT_122 = 0;
    ptypes_n = zT_122;
    zT_123 = proto.params_count;
    if ((unsigned char)((unsigned int)((unsigned int)zT_123) > (unsigned int)(64))) goto z_bb_27; else goto z_bb_28;
    z_bb_27:
    zT_127 = "panic: ";
    zT_128 = 7;
    fwrite(zT_127, 1, zT_128, stderr);
    zT_129 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_130 = 72;
    fwrite(zT_129, 1, zT_130, stderr);
    zT_131 = "\n";
    zT_132 = 1;
    fwrite(zT_131, 1, zT_132, stderr);
    pal_trap();
    z_bb_28:
    zT_134 = proto.params_count;
    if ((unsigned char)(zT_134 > (unsigned short)(0))) goto z_bb_29; else goto z_bb_30;
    z_bb_29:
    zT_138 = proto.params_start;
    zT_142 = proto.params_count;
    zT_144 = (zT_79FAE712_u64)((zT_79FAE712_u64)((zT_79FAE712_u64)zT_138) << (zT_79FAE712_u64)(32)) | (zT_79FAE712_u64)((zT_79FAE712_u64)zT_142);
    p_payload = zT_144;
    zT_146 = env->store;
    zT_147 = p_payload;
    zT_149 = zF_03CE8CAB_astStoreGetExtraChi(zT_146, zT_147);
    pnodes_n = zT_149;
    zT_151 = 0;
    zT_152 = (unsigned int)zT_151;
    pi = zT_152;
    goto z_bb_31;
    z_bb_30:
    zT_202 = env->typereg;
    zT_203 = zT_202->xt_len;
    zT_204 = (unsigned int)zT_203;
    fn_start = zT_204;
    zT_206 = 0;
    pf = zT_206;
    goto z_bb_42;
    z_bb_31:
    if ((unsigned char)(pi < (unsigned int)((unsigned int)pnodes_n))) goto z_bb_32; else goto z_bb_33;
    z_bb_32:
    zT_156 = env->store;
    zT_159 = env->store;
    zT_160 = p_payload;
    zT_164 = zF_E5B10421_astStoreGetExtraChi(zT_159, zT_160, (unsigned int)((unsigned int)pi));
    zT_157 = zT_164;
    zT_165 = zF_FCDD1D35_astStoreNodeAt(zT_156, zT_157);
    pnode = zT_165;
    zT_166 = pnode.child_0;
    zT_167 = 0;
    if ((unsigned char)(zT_166 != (unsigned int)zT_167)) goto z_bb_35; else goto z_bb_36;
    z_bb_33:
    goto z_bb_30;
    z_bb_34:
    zT_198 = 1;
    zT_200 = pi + (unsigned int)((unsigned int)zT_198);
    pi = zT_200;
    goto z_bb_31;
    z_bb_35:
    zT_170 = env;
    zT_171 = pnode.child_0;
    zT_175 = zF_F2107C15_resolveTypeExprFull(zT_170, zT_171, (unsigned int)(0));
    ptype = zT_175;
    if ((unsigned char)(ptypes_n >= (unsigned int)(64))) goto z_bb_37; else goto z_bb_38;
    z_bb_36:
    goto z_bb_34;
    z_bb_37:
    zT_178 = "panic: ";
    zT_179 = 7;
    fwrite(zT_178, 1, zT_179, stderr);
    zT_180 = "async/type_resolver: function parameter count exceeds MAX_FN_PARAMS (64)";
    zT_181 = 72;
    fwrite(zT_180, 1, zT_181, stderr);
    zT_182 = "\n";
    zT_183 = 1;
    fwrite(zT_182, 1, zT_183, stderr);
    pal_trap();
    z_bb_38:
    ptypes_buf[ptypes_n] = ptype;
    zT_186 = ptypes_n + (unsigned int)(1);
    ptypes_n = zT_186;
    if ((unsigned char)(ptype != (unsigned int)(18))) goto z_bb_39; else goto z_bb_41;
    z_bb_39:
    zT_189 = resolved_types;
    zT_190 = pnode.child_0;
    zT_191 = ptype;
    zF_19B4A07D_resolvedTypeTableSe(zT_189, zT_190, zT_191);
    goto z_bb_40;
    z_bb_40:
    goto z_bb_36;
    z_bb_41:
    zT_193 = env;
    zT_194 = pnode.child_0;
    zF_2501AC4F_typeResolverDiagnos(zT_193, zT_194, (unsigned int)(0));
    goto z_bb_40;
    z_bb_42:
    if ((unsigned char)(pf < ptypes_n)) goto z_bb_43; else goto z_bb_44;
    z_bb_43:
    zT_208 = env->typereg;
    zT_209 = ptypes_buf[pf];
    zF_4C03AE3D_xtAppend(zT_208, zT_209);
    goto z_bb_45;
    z_bb_44:
    zT_216 = env->typereg;
    zT_217 = proto.name_id;
    zT_227 = mods.ptr;
    zT_228 = zT_227[mi];
    zT_218 = zT_228.id;
    zT_219 = is_ext;
    zT_220 = is_variadic;
    zT_221 = fn_start;
    zT_222 = proto.params_count;
    zT_231 = 0;
    zT_223 = rt_box[zT_231];
    zT_224 = proto.call_conv;
    zT_234 = zF_474336D7_typeRegistryGetOrCr(zT_216, zT_217, zT_218, zT_219, zT_220, zT_221, zT_222, zT_223, zT_224);
    tid = zT_234;
    zT_235 = resolved_types;
    zT_236 = decl_idx;
    zT_237 = tid;
    zF_19B4A07D_resolvedTypeTableSe(zT_235, zT_236, zT_237);
    zT_239 = env->symbol_reg;
    zT_243 = mods.ptr;
    zT_244 = zT_243[mi];
    zT_240 = zT_244.id;
    zT_241 = proto.name_id;
    zT_247 = zF_A398987E_symbolRegistryQuali(zT_239, zT_240, zT_241);
    sym = zT_247;
    zT_248 = sym.has_value;
    if (zT_248) goto z_bb_46; else goto z_bb_47;
    z_bb_45:
    zT_212 = 1;
    zT_214 = pf + (unsigned int)((unsigned int)zT_212);
    pf = zT_214;
    goto z_bb_42;
    z_bb_46:
    sp = sym.value;
    sp->type_id = tid;
    goto z_bb_47;
    z_bb_47:
    goto z_bb_12;
    z_bb_48:
    zT_255 = decl.child_0;
    zT_256 = 0;
    zT_254 = zT_255 != (unsigned int)zT_256;
    goto z_bb_50;
    z_bb_49:
    zT_254 = 0;
    goto z_bb_50;
    z_bb_50:
    if (zT_254) goto z_bb_51; else goto z_bb_52;
    z_bb_51:
    zT_259 = env;
    zT_260 = decl.child_0;
    zT_264 = zF_F2107C15_resolveTypeExprFull(zT_259, zT_260, (unsigned int)(0));
    vtype = zT_264;
    if ((unsigned char)(vtype != (unsigned int)(18))) goto z_bb_53; else goto z_bb_54;
    z_bb_52:
    goto z_bb_12;
    z_bb_53:
    zT_267 = resolved_types;
    zT_268 = decl.child_0;
    zT_269 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_267, zT_268, zT_269);
    zT_271 = resolved_types;
    zT_272 = decl_idx;
    zT_273 = vtype;
    zF_19B4A07D_resolvedTypeTableSe(zT_271, zT_272, zT_273);
    zT_275 = env->symbol_reg;
    zT_279 = mods.ptr;
    zT_280 = zT_279[mi];
    zT_276 = zT_280.id;
    zT_282 = env->store;
    zT_283 = decl_idx;
    zT_285 = zF_8BA26B9E_astStoreNodePayload(zT_282, zT_283);
    zT_277 = zT_285;
    zT_286 = zF_A398987E_symbolRegistryQuali(zT_275, zT_276, zT_277);
    sym = zT_286;
    zT_287 = sym.has_value;
    if (zT_287) goto z_bb_55; else goto z_bb_56;
    z_bb_54:
    goto z_bb_52;
    z_bb_55:
    sp = sym.value;
    sp->type_id = vtype;
    goto z_bb_56;
    z_bb_56:
    goto z_bb_54;
}

/* typeResolverResolveNames */
void zF_373A7BEF_typeResolverResolve(zT_6B0A7D14_AstStore* store, zT_338B7C76_TypeRegistry* typereg, zT_3D7259E2_SymbolRegistry* symbol_reg, zT_D3EB6303_StringInterner* interner, zT_8EED1867_ResolvedTypeTable* resolved_types, zT_072B53A6_ModuleRegistry* module_reg, zT_F85C5DED_DiagnosticCollector* diag, zT_3E40CD83_Sand* perm_alloc) {
    zT_072B53A6_ModuleRegistry* zT_9;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_10 = {0};
    zT_ABC1EBBE_TypeResolveEnv zT_12;
    unsigned int zT_14;
    zT_6F32B01B_Opt_235 zT_15;
    zT_0DCE6231_Opt_408 zT_16 = {0};
    zT_FFCC0D90_Opt_410 zT_17 = {0};
    zT_ABC1EBBE_TypeResolveEnv* zT_18;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_19;
    zT_ABC1EBBE_TypeResolveEnv* zT_21;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_22;
    zT_072B53A6_ModuleRegistry* zT_23;
    zT_ABC1EBBE_TypeResolveEnv* zT_25;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_26;
    zT_ABC1EBBE_TypeResolveEnv* zT_28;
    zT_DDCD424B_Slice_zT_6E8D187B_M zT_29;
    zT_8EED1867_ResolvedTypeTable* zT_30;
    zT_DDCD424B_Slice_zT_6E8D187B_M mods;
    zT_ABC1EBBE_TypeResolveEnv env;
    zT_9 = module_reg;
    zT_10 = zF_3452C137_moduleRegistryGetMo(zT_9);
    mods = zT_10;
    zT_12.store = store;
    zT_12.typereg = typereg;
    zT_12.symbol_reg = symbol_reg;
    zT_12.interner = interner;
    zT_12.module_id = zG_E6DB2ACE_MODULE_ID_NONE;
    zT_14 = 0;
    zT_12.source_file_id = zT_14;
    zT_15.has_value = 1;
    zT_15.value = diag;
    zT_12.diag = zT_15;
    zT_16.has_value = 0;
    zT_12.local_consts = zT_16;
    zT_17.has_value = 0;
    zT_12.local_types = zT_17;
    env = zT_12;
    (void)perm_alloc;
    zT_18 = &env;
    zT_19 = mods;
    zF_D9A1E9B7_resolveNamedTypeExp(zT_18, zT_19);
    zT_21 = &env;
    zT_22 = mods;
    zT_23 = module_reg;
    zF_1DB55B7A_resolveImportFieldA(zT_21, zT_22, zT_23);
    zT_25 = &env;
    zT_26 = mods;
    zF_E2882212_resolveAggregateFie(zT_25, zT_26);
    zT_28 = &env;
    zT_29 = mods;
    zT_30 = resolved_types;
    zF_29FBFC7C_resolveFnSignatures(zT_28, zT_29, zT_30);
    return;
}

/* __module_init */
void zF_780653D2___module_init_18(void) {
    zT_52CDA6EF_DepEdge zT_0 = {0};
    zT_D3EB6303_StringInterner zT_1 = {0};
    zT_3D7259E2_SymbolRegistry zT_2 = {0};
    zG_52CDA6EF_DepEdge = zT_0;
    zG_D3EB6303_StringInterner = zT_1;
    zG_3D7259E2_SymbolRegistry = zT_2;
    zG_E6DB2ACE_MODULE_ID_NONE = (unsigned int)(4294967295u);
    return;
}

/* EOF */
